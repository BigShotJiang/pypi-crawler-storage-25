# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

"""
ASCII-math-like parser → automathlib Node
=========================================

Entry point
-----------
  parse(s, mode='text', locale=None, normalize_ops=True) → Node

Mode
----
  'text' (default)
      The string is returned as a plain Text node, unless it contains
      mode-switching keywords (math{}, text{}, angle{}, table{}) at the
      top level, in which case it is split into a Row of mixed nodes.

  'math'
      Full mathematical parsing: fractions, superscripts, angle names, …
      Before tokenising, hyphens (-) and en-dashes (–) are converted to
      the true minus sign (−), and * is converted to ×.

Syntax reference — mode='text' (top-level)
------------------------------------------
  "Voir math{1/2} de la figure"
      → Row([Text("Voir "), Fraction("1","2"), Text(" de la figure")])

  "L'angle angle{ABC} vaut math{1/4}."
      → Row([Text("L'angle "), AngleName("ABC"), Text(" vaut "),
             Fraction("1","4"), Text(".")])

  "table{3; 4; 5; 6 | borders=none; baseline=top}"
      → Table([Text("3"), Text("4"), Text("5"), Text("6")],
              borders=None, baseline='top')

Syntax reference — mode='math' (inside math{...})
--------------------------------------------------
  Plain text
      math{3x + 1 = 19}  →  MathText("3x + 1 = 19")

  Fractions  —  '/' triggers a Fraction
      math{1/4}           →  Fraction("1", "4")
      math{x + 1/4}       →  Row([MathText("x + "), Fraction("1","4")])
      math{a/bc}          →  Fraction("a", "bc")     (collated tokens stay
                                                       together — convention A)
      math{a/b + c}       →  Row([Fraction("a","b"), MathText(" + c")])
      math{1/2×x}         →  Row([Fraction("1","2"), MathText(" × x")])
      math{1/2x}          →  Fraction("1", "2x")     (× stops, x doesn't)

  Grouping
      math{{x+1}/4}       →  Fraction("x+1", "4")    (invisible braces)
      math{(x+1)/4}       →  Fraction("(x+1)", "4")  (visible parentheses)
      math{a/{b+c}}       →  Fraction("a", "b+c")
      math{{1/2}x}        →  Row([Fraction("1","2"), MathText(" x")])

  Superscripts  —  '^' followed by a group or a collated token
      math{x^{2}}         →  Row([MathText("x"), Sup(MathText("2"))])
      math{x^2}           →  identical (braces optional for single token)
      math{x^{1/2}}       →  Row([MathText("x"), Sup(Fraction("1","2"))])
      math{3x^2/4}        →  Fraction(Row([MathText("3x"), Sup(...)]),
                                       MathText("4"))
      math{1/3x^{2}}      →  Fraction(MathText("1"),
                                       Row([MathText("3x"), Sup(...)]))

  Keywords usable inside math{}
      math{text{adj}/text{hyp}}
          → Fraction(Text("adj"), Text("hyp"))
      math{angle{ABC}/2}
          → Fraction(AngleName("ABC"), MathText("2"))

  Table  (also usable at text level)
      table{3; 4; 5; 6}
          → Table with four Text values, default options
      table{3; 4; 5; 6 | title1=Côté; title2=Résultat; borders=none}
          → Table with title and no borders
      table{math{1/4}; math{3/8} | bubble=math{×4}; baseline=top}
          → Table with Fraction values and a MathText bubble

Operator spacing
----------------
  Inside math{}, one space is added on each side of +, −, =, ×, ÷ unless
  normalize_ops=False is passed (used e.g. for bubble values).
  In text mode, spacing is left as-is except around math{} / angle{} / text{}
  and table{} boundaries.

Locale
------
  Controls which punctuation characters suppress the leading space when they
  appear immediately at certain places like after a math{} or angle{} block:
    'fr' : . , … (semicolons and ! ? keep their space)
    'en' : . , ; : ! ? …
  Defaults to CONFIG['locale'].

Errors
------
  ParseError (subclass of ValueError) is raised for:
    - empty or whitespace-only expression
    - unmatched { } or ( )
    - missing numerator or denominator around /
    - '^' not followed by a value or group
    - unknown keyword
    - invalid table option syntax
"""

import re

from automath.config_utils import load_config

from .nodes import Node, Text, MathText, Fraction, Row, AngleName
from .nodes import Table, Sup

_KEYWORDS = {'angle', 'text', 'math', 'table', 'frac'}
CONFIG = load_config("automath")

_PUNCTUATION_NO_SPACE = {
    'fr': frozenset('.,…'),
    'en': frozenset('.,;:!?…'),
}

_NUMBER_RE = re.compile(r'^\d+(\.\d+)?$')


# ── Public exception ─────────────────────────────────────────────────────────

class ParseError(ValueError):
    """Raised when the input string cannot be parsed."""


# ── Tokenizer ────────────────────────────────────────────────────────────────

# Structural characters each get their own token kind so they can act as
# delimiters for numerators, denominators, and superscripts:
#   SLASH   /     → fraction operator
#   PLUS    +     → additive operator (stops num/den)
#   MINUS   - – − → all normalised to true minus − in math mode
#   TIMES   × *   → multiplicative operator (stops num/den); * → × in math mode
#   DIV     ÷     → division sign (stops num/den)
#   EQUALS  =     → equality (stops num/den)
#   CARET   ^     → superscript operator
# Everything else that is not whitespace or a grouping delimiter is a WORD.
_TOKEN_RE = re.compile(
    r'(?P<SPACE>\s+)'
    r'|(?P<LBRACE>\{)'
    r'|(?P<RBRACE>\})'
    r'|(?P<LPAREN>\()'
    r'|(?P<RPAREN>\))'
    r'|(?P<SLASH>/)'
    r'|(?P<PLUS>\+)'
    r'|(?P<MINUS>[-–−])'
    r'|(?P<TIMES>[×*])'
    r'|(?P<DIV>÷)'
    r'|(?P<EQUALS>=)'
    r'|(?P<CARET>\^)'
    r'|(?P<WORD>[^/+\-–−{}\(\)\^\s=×÷*]+)'
)


def _tokenize(s: str) -> list[tuple[str, str]]:
    """
    Return a flat list of (kind, value) pairs covering the whole string.
    Raises ParseError if an unexpected character is encountered.
    """
    tokens = []
    pos = 0
    for m in _TOKEN_RE.finditer(s):
        if m.start() != pos:
            raise ParseError(
                f"Unexpected character {s[pos]!r} at position {pos}."
            )
        tokens.append((m.lastgroup, m.group()))
        pos = m.end()
    if pos != len(s):
        raise ParseError(
            f"Unexpected character {s[pos]!r} at position {pos}."
        )
    return tokens


# ── Compound token types (after grouping) ────────────────────────────────────

class _Tok:
    """
    Primitive token produced by the tokenizer.
    kind : WORD | SLASH | PLUS | MINUS | TIMES | DIV | EQUALS | CARET | SPACE
    """
    __slots__ = ('kind', 'value')

    def __init__(self, kind: str, value: str):
        self.kind = kind
        self.value = value

    def __repr__(self) -> str:
        return f"Tok({self.kind}, {self.value!r})"


class _Group:
    """
    An invisible brace group {...}.
    content is the raw string between the braces; it will be parsed
    recursively in math mode when the group is expanded.
    """
    __slots__ = ('content',)

    def __init__(self, content: str):
        self.content = content

    def __repr__(self) -> str:
        return f"Group({self.content!r})"


class _Parens:
    """
    A visible parenthesis group (...).
    content is the raw string between the parentheses (without the parens
    themselves). When converted to a Node the parentheses are prepended
    and appended so they remain visible in the rendered output.
    """
    __slots__ = ('content',)

    def __init__(self, content: str):
        self.content = content

    def __repr__(self) -> str:
        return f"Parens({self.content!r})"


class _Keyword:
    """
    A recognised keyword followed by a brace group: name{content}.
    Known keywords: 'angle', 'text', 'math', 'table', '^'.
    The '^' keyword is special: it is produced by the CARET token handler
    rather than by the WORD keyword-detection path.
    """
    __slots__ = ('name', 'content')

    def __init__(self, name: str, content: str):
        self.name = name
        self.content = content

    def __repr__(self) -> str:
        return f"Keyword({self.name!r}, {self.content!r})"


# ── Grouper (pass 2) ─────────────────────────────────────────────────────────

def _group(tokens: list[tuple[str, str]]) -> list:
    """
    Fold the flat token list into a structured list of compound tokens.

    Transformations performed:
      {…}            → _Group(inner)
      (…)            → _Parens(inner)
      keyword{…}     → _Keyword(name, inner)   (WORD in _KEYWORDS + LBRACE)
      ^{…} or ^WORD  → _Keyword('^', inner)

    Returns a list of _Tok | _Group | _Parens | _Keyword.
    Raises ParseError for unmatched or unexpected delimiters.
    """
    result = []
    i = 0
    while i < len(tokens):
        kind, val = tokens[i]

        if kind == 'LBRACE':
            depth, j = 1, i + 1
            while j < len(tokens) and depth:
                if tokens[j][0] == 'LBRACE':
                    depth += 1
                elif tokens[j][0] == 'RBRACE':
                    depth -= 1
                j += 1
            if depth:
                raise ParseError("Unmatched '{'.")
            inner = ''.join(v for _, v in tokens[i + 1: j - 1])
            result.append(_Group(inner))
            i = j

        elif kind == 'RBRACE':
            raise ParseError("Unexpected '}'.")

        elif kind == 'LPAREN':
            depth, j = 1, i + 1
            while j < len(tokens) and depth:
                if tokens[j][0] == 'LPAREN':
                    depth += 1
                elif tokens[j][0] == 'RPAREN':
                    depth -= 1
                j += 1
            if depth:
                raise ParseError("Unmatched '('.")
            inner = ''.join(v for _, v in tokens[i + 1: j - 1])
            result.append(_Parens(inner))
            i = j

        elif kind == 'RPAREN':
            raise ParseError("Unexpected ')'.")

        else:
            # ── Superscript operator ─────────────────────────────────────
            if kind == 'CARET':
                if (i + 1 < len(tokens)
                        and tokens[i + 1][0] == 'LBRACE'):
                    # ^{…} : find matching RBRACE
                    depth, j = 1, i + 2
                    while j < len(tokens) and depth:
                        if tokens[j][0] == 'LBRACE':
                            depth += 1
                        elif tokens[j][0] == 'RBRACE':
                            depth -= 1
                        j += 1
                    if depth:
                        raise ParseError("Unmatched '{' after '^'.")
                    inner = ''.join(v for _, v in tokens[i + 2: j - 1])
                    result.append(_Keyword('^', inner))
                    i = j
                    continue
                elif (i + 1 < len(tokens)
                        and tokens[i + 1][0] == 'WORD'):
                    # ^WORD : braces optional for a single collated token
                    result.append(_Keyword('^', tokens[i + 1][1]))
                    i += 2
                    continue
                else:
                    raise ParseError(
                        "'^' must be followed by a value or a group, "
                        "e.g. ^2 or ^{2}."
                    )

            # ── Named keyword detection ──────────────────────────────────
            if (kind == 'WORD'
                    and val in _KEYWORDS
                    and i + 1 < len(tokens)
                    and tokens[i + 1][0] == 'LBRACE'):
                # find matching RBRACE (handles nested braces correctly)
                depth, j = 1, i + 2
                while j < len(tokens) and depth:
                    if tokens[j][0] == 'LBRACE':
                        depth += 1
                    elif tokens[j][0] == 'RBRACE':
                        depth -= 1
                    j += 1
                if depth:
                    raise ParseError(f"Unmatched '{{' after '{val}'.")
                inner = ''.join(v for _, v in tokens[i + 2: j - 1])
                result.append(_Keyword(val, inner))
                i = j
                continue

            # ── Ordinary token ───────────────────────────────────────────
            result.append(_Tok(kind, val))
            i += 1

    return result


# ── Helpers ──────────────────────────────────────────────────────────────────

def _is_space(item) -> bool:
    return isinstance(item, _Tok) and item.kind == 'SPACE'


def _is_slash(item) -> bool:
    return isinstance(item, _Tok) and item.kind == 'SLASH'


def _items_to_raw(items: list) -> str:
    """Reconstruct the raw string from a list of grouped tokens."""
    parts = []
    for item in items:
        if isinstance(item, _Tok):
            parts.append(item.value)
        elif isinstance(item, _Group):
            parts.append('{' + item.content + '}')
        elif isinstance(item, _Parens):
            parts.append('(' + item.content + ')')
    return ''.join(parts)


def _normalise_ops(s: str, normalize_ops: bool = True) -> str:
    """
    Ensure exactly one space on each side of +, −, =, ×, ÷ operators.
    Uses literal space [ ] instead of \\s so that thin non-breaking spaces
    (\\u202f) used as thousands separators in numbers are preserved.
    When normalize_ops=False, only collapse multiple spaces (used for
    bubble values where spacing must be preserved as-is).
    """
    if not normalize_ops:
        return re.sub(r'[ ]+', ' ', s).strip()
    s = re.sub(r'[ ]*([+\-–−=×÷*])[ ]*', r' \1 ', s)
    return re.sub(r'[ ]+', ' ', s)


def _buf_to_text(buf: list, normalize_ops: bool = True) -> str:
    """Convert a token buffer to a normalised text string."""
    return _normalise_ops(
        re.sub(r' +', ' ', _items_to_raw(buf)),
        normalize_ops=normalize_ops,
    )


def _peek_next_non_space(items: list, start: int):
    """Return the first non-space item at or after *start*, or None."""
    for i in range(start, len(items)):
        if not _is_space(items[i]):
            return items[i]
    return None


def _split_respecting_groups(s: str, sep: str) -> list[str]:
    """
    Split s on sep, ignoring occurrences inside {…} or (…) groups.
    Used by _parse_table_content to split on ';' and '|'.
    """
    parts, current, depth = [], [], 0
    i = 0
    while i < len(s):
        c = s[i]
        if c in ('{', '('):
            depth += 1
            current.append(c)
        elif c in ('}', ')'):
            depth -= 1
            current.append(c)
        elif s[i:i + len(sep)] == sep and depth == 0:
            parts.append(''.join(current))
            current = []
            i += len(sep)
            continue
        else:
            current.append(c)
        i += 1
    parts.append(''.join(current))
    return parts


def _parse_options(options_str: str) -> dict:
    """
    Parse 'key=val; key=val; …' into a kwargs dict.
    """
    kwargs = {}
    for opt in _split_respecting_groups(options_str, ';'):
        opt = opt.strip()
        if not opt:
            continue
        if '=' not in opt:
            raise ParseError(f"Invalid option (missing '='): {opt!r}")
        key, _, val = opt.partition('=')
        key, val = key.strip(), val.strip()
        kwargs[key] = None if val == 'none' else val
    return kwargs


def _split_content(s: str) -> tuple[str, str]:
    """Split 'values | options' on the first '|', respecting groups."""
    pipe_parts = _split_respecting_groups(s, '|')
    values_str = pipe_parts[0]
    options_str = pipe_parts[1].strip() if len(pipe_parts) > 1 else ''
    return values_str, options_str


def _parse_table_content(s: str, locale: str) -> 'Table':
    """
    Parse table{…} content — any number of values + options.
    title1=/title2= → merged into title=[…].
    bubble= values are parsed with normalize_ops=False.
    """
    values_str, options_str = _split_content(s)
    values = [
        parse(v.strip(), mode='math', locale=locale)
        if _has_math_structure(v.strip())
        else parse(v.strip(), locale=locale)
        for v in _split_respecting_groups(values_str, ';')
        if v.strip()
    ]
    if not values:
        raise ParseError("table{} requires at least one value.")
    raw_options = _parse_options(options_str)

    title = {}
    kwargs = {}
    for key in raw_options:
        val = raw_options[key]
        if key == 'title1':
            title[0] = parse(val, locale=locale)
        elif key == 'title2':
            title[1] = parse(val, locale=locale)
        elif key == 'bubble':
            kwargs['bubble'] = parse(val, locale=locale, normalize_ops=False)
        else:
            kwargs[key] = val
    if title:
        kwargs['title'] = [title.get(0), title.get(1)]

    return Table(values, **kwargs)


def _is_number(s: str) -> bool:
    """Return True if s looks like a plain number (e.g. '42', '3.14')."""
    return bool(_NUMBER_RE.match(s))


def _format_number(s: str, locale: str) -> str:
    """
    Format a number string for display according to locale.
    Input must use English notation (dot as decimal separator, no thousands
    separator) — this is the parser's internal convention.

    Examples (locale='fr') : '1000' → '1\u202f000', '3.14' → '3,14'
    Examples (locale='en') : '1000' → '1,000',      '3.14' → '3.14'
    """
    if '.' in s:
        int_part, dec_part = s.split('.', 1)
    else:
        int_part, dec_part = s, None

    # Integer part — grouping by 3 from the right
    if len(int_part) >= 4:
        groups = []
        for i in range(len(int_part), 0, -3):
            groups.append(int_part[max(0, i - 3):i])
        groups.reverse()
        thousands_sep = '\u202f' if locale.startswith('fr') else ','
        int_part = thousands_sep.join(groups)

    if dec_part is None:
        return int_part

    if locale.startswith('fr'):
        # Decimal part grouped by 3 from the left
        groups = [dec_part[i:i + 3] for i in range(0, len(dec_part), 3)]
        dec_formatted = '\u202f'.join(groups)
        return int_part + ',' + dec_formatted
    else:
        # English: no grouping of decimal part
        return int_part + '.' + dec_part


def _localise_number_tokens(grouped: list, locale: str) -> list:
    """
    Walk the grouped token list and replace every WORD token that looks
    like a number with its locale-formatted version.
    Called once in math mode, after _group(), before any further parsing.
    """
    result = []
    for item in grouped:
        if (isinstance(item, _Tok)
                and item.kind == 'WORD'
                and _is_number(item.value)):
            result.append(_Tok(item.kind, _format_number(item.value, locale)))
        else:
            result.append(item)
    return result


def _has_math_structure(s: str) -> bool:
    """
    Return True if s contains any structure that requires math-mode parsing:
    a keyword (math{}, text{}, angle{}, ^, …), a fraction slash, a caret,
    or a bare number (which needs locale-aware formatting).
    """
    if _is_number(s):
        return True
    try:
        grouped = _group(_tokenize(s))
        return any(
            isinstance(item, _Keyword)
            or _is_slash(item)
            or (isinstance(item, _Tok) and item.kind == 'CARET')
            for item in grouped
        )
    except ParseError:
        return False


def _parse_frac_content(s: str, locale: str) -> 'Fraction':
    """
    Parse frac{num; den | options} content.

    If a value contains no keywords, it is passed as a raw string to
    Fraction so that Fraction can handle color propagation internally
    when constructing MathText children.
    """
    values_str, options_str = _split_content(s)
    raw_values = [v.strip()
                  for v in _split_respecting_groups(values_str, ';')
                  if v.strip()]
    if len(raw_values) != 2:
        raise ParseError(
            f"frac{{}} requires exactly 2 values (numerator; denominator), "
            f"got {len(raw_values)}."
        )
    # Pass as raw string if no keywords → Fraction handles color propagation.
    # Parse recursively only if there are keywords (math{}, text{}, ^, …).
    processed = [
        parse(v, mode='math', locale=locale)
        if _has_math_structure(v) else v
        for v in raw_values
    ]
    num, den = processed[0], processed[1]
    kwargs = _parse_options(options_str)
    return Fraction(num, den, **kwargs)


# ── Atom → Node conversion ───────────────────────────────────────────────

def _atom_to_node(atom, **options) -> Node:
    """
    Convert a single fraction operand or superscript base to a Node.

    Dispatch table
    --------------
      Node          → returned as-is (e.g. Row built by _extract_*)
      _Keyword('angle') → AngleName
      _Keyword('text')  → Text
      _Keyword('math')  → parse(content, mode='math')
      _Keyword('table') → _parse_table_content(…)
      _Keyword('^')     → Sup(parse(content, mode='math'))
      _Group            → parse(content, mode='math')   (recursive)
      _Parens           → MathText("(content)")          (visible parens)
      _Tok(WORD)        → MathText(value)
    """
    locale = options.get('locale', CONFIG['locale'])
    if isinstance(atom, Node):
        return atom
    if isinstance(atom, _Keyword):
        if atom.name == 'angle':
            values_str, options_str = _split_content(atom.content)
            kwargs = _parse_options(options_str)
            if _has_math_structure(values_str):
                value = parse(values_str, mode='math', locale=locale)
            else:
                value = values_str.strip()
            return AngleName(value, locale=locale, **kwargs)
        if atom.name == 'text':
            values_str, options_str = _split_content(atom.content)
            kwargs = _parse_options(options_str)
            return Text(values_str.strip(), **kwargs)
        if atom.name == 'math':
            values_str, options_str = _split_content(atom.content)
            kwargs = _parse_options(options_str)
            normalize_ops = options.get('normalize_ops', True)
            node = parse(values_str.strip(), mode='math',
                         locale=locale, normalize_ops=normalize_ops)
            return node.apply_options(**kwargs) if kwargs else node
        if atom.name == '^':
            values_str, options_str = _split_content(atom.content)
            kwargs = _parse_options(options_str)
            return Sup(parse(values_str.strip(), mode='math'), **kwargs)
        if atom.name == 'frac':
            return _parse_frac_content(atom.content, CONFIG['locale'])
        if atom.name == 'table':
            return _parse_table_content(atom.content, CONFIG['locale'])
        raise ParseError(f"Unknown keyword: {atom.name!r}.")
    if isinstance(atom, _Group):
        return parse(atom.content, mode='math')
    if isinstance(atom, _Parens):
        return MathText('(' + atom.content + ')')
    if isinstance(atom, _Tok) and atom.kind == 'WORD':
        return MathText(atom.value)
    raise ParseError(
        f"Unexpected token {atom!r} where a fraction operand was expected."
    )


# ── Numerator / denominator extraction ───────────────────────────────────────

def _extract_numerator(buf: list) -> tuple:
    """
    Extract the numerator atom from the right end of *buf*.

    The numerator is the last non-space item in the buffer.  If that item
    is a '^' keyword, we walk further left to collect the full base^exp
    cluster and return a Row([base, Sup(…), …]).

    Returns (atom_or_row, pre_items).
    """
    j = len(buf) - 1
    while j >= 0 and _is_space(buf[j]):
        j -= 1
    if j < 0:
        raise ParseError("Missing numerator before '/'.")
    atom = buf[j]
    if isinstance(atom, (_Group, _Parens)):
        return atom, buf[:j]
    if isinstance(atom, _Keyword) and atom.name != '^':
        return atom, buf[:j]
    if isinstance(atom, _Tok) and atom.kind == 'WORD':
        return atom, buf[:j]
    # Collect one or more trailing '^' keywords attached to a WORD base
    if isinstance(atom, _Keyword) and atom.name == '^':
        sup_nodes = []
        while j >= 0 and isinstance(buf[j], _Keyword) and buf[j].name == '^':
            sup_nodes.insert(0, buf[j])
            j -= 1
        if j >= 0 and isinstance(buf[j], _Tok) and buf[j].kind == 'WORD':
            base = MathText(buf[j].value)
            children = [base] + [_atom_to_node(s) for s in sup_nodes]
            return Row(children), buf[:j]
        raise ParseError("'^' must be preceded by a variable or number.")
    val = atom.value if isinstance(atom, _Tok) else repr(atom)
    raise ParseError(
        f"Invalid token {val!r} immediately before '/'. "
        "Expected a number, variable, or grouped expression."
    )


def _extract_denominator(items: list, i: int) -> tuple:
    """
    Extract the denominator atom starting at index *i*.

    Leading spaces are skipped.  If the atom is a WORD token, any
    immediately-following '^' keywords (no intervening space) are consumed
    and bundled into a Row([base, Sup(…), …]).

    Returns (atom_or_row, new_index).
    """
    while i < len(items) and _is_space(items[i]):
        i += 1
    if i >= len(items):
        raise ParseError("Missing denominator after '/'.")
    item = items[i]
    if isinstance(item, (_Group, _Parens, _Keyword)):
        return item, i + 1
    if isinstance(item, _Tok) and item.kind == 'WORD':
        # Consume any immediately-following '^' keywords (collated, no space)
        j = i + 1
        sup_nodes = []
        while (j < len(items)
               and isinstance(items[j], _Keyword)
               and items[j].name == '^'):
            sup_nodes.append(items[j])
            j += 1
        if sup_nodes:
            base = MathText(item.value)
            children = [base] + [_atom_to_node(s) for s in sup_nodes]
            return Row(children), j
        return item, i + 1
    val = item.value if isinstance(item, _Tok) else repr(item)
    raise ParseError(
        f"Invalid token {val!r} immediately after '/'. "
        "Expected a number, variable, or grouped expression."
    )


# ── Main parser ──────────────────────────────────────────────────────────────

def parse(s: str, mode: str = 'text', locale: str = None,
          normalize_ops: bool = True) -> Node:
    """
    Parse an ASCII-math string and return the corresponding Node.

    Parameters
    ----------
    s             : input string
    mode          : 'text' (default) or 'math'
    locale        : 'fr' | 'en' | …  (defaults to CONFIG['locale'])
                    Controls which punctuation characters suppress the
                    leading space after a math{}/angle{} block.
    normalize_ops : if True (default), ensure one space around +, −, =, ×, ÷.
                    Pass False for bubble values or other contexts where
                    original spacing must be preserved between an operator and
                    the operands.

    Returns
    -------
    Text     — plain string in text mode with no embedded keywords
    MathText — math mode with no fractions or special nodes
    Fraction — math mode with exactly one fraction and nothing else
    Sup      — math mode with exactly one superscript and nothing else
    Row      — anything that mixes two or more of the above

    Raises
    ------
    ParseError — empty expression, unmatched delimiters, missing operand, …
    """
    if not locale:
        locale = CONFIG['locale']
    no_space = _PUNCTUATION_NO_SPACE.get(locale, _PUNCTUATION_NO_SPACE['en'])
    s = s.strip()
    if not s:
        raise ParseError("Empty expression.")

    # Pre-processing in math mode: normalise minus signs and * → ×
    if mode == 'math':
        s = s.replace('-', '−').replace('–', '−').replace('*', '×')

    grouped = _group(_tokenize(s))

    if mode == 'math':
        grouped = _localise_number_tokens(grouped, locale)

    # ── Text mode ─────────────────────────────────────────────────────────
    # Return a plain Text node immediately unless there are mode-switching
    # keywords at the top level.
    if mode == 'text':
        has_mode_keyword = any(
            isinstance(item, _Keyword)
            and item.name in ('math', 'text', 'angle', 'table', 'frac')
            for item in grouped
        )
        if not has_mode_keyword:
            return Text(s)

        # Mixed content: interleave plain Text chunks with structured nodes.
        chunks = []
        text_buf = []

        def flush_text_buf():
            """Flush text_buf as a Text node, adding spacing around it."""
            raw = _items_to_raw(text_buf).strip()
            text_buf.clear()
            if not raw:
                return
            if chunks:
                raw = ' ' + raw
            chunks.append(Text(raw + ' '))

        for item in grouped:
            if isinstance(item, _Keyword) and item.name == 'math':
                flush_text_buf()
                chunks.append(_atom_to_node(item, locale=locale,
                                            normalize_ops=normalize_ops))
            elif isinstance(item, _Keyword) and item.name in ['angle', 'text']:
                flush_text_buf()
                chunks.append(_atom_to_node(item, locale=locale))
            elif isinstance(item, _Keyword) and item.name == 'table':
                flush_text_buf()
                chunks.append(_parse_table_content(item.content, locale))
            elif isinstance(item, _Keyword) and item.name == 'frac':
                flush_text_buf()
                chunks.append(_parse_frac_content(item.content, locale))
            else:
                text_buf.append(item)

        # Flush any trailing plain text, suppressing the leading space before
        # locale-specific punctuation (e.g. '.' in both locales).
        raw = _items_to_raw(text_buf).strip()
        if raw:
            if chunks and raw[0] not in no_space:
                raw = ' ' + raw
            chunks.append(Text(raw))
        if not chunks:
            raise ParseError("Empty expression.")
        return chunks[0] if len(chunks) == 1 else Row(chunks)

    # ── Math mode ─────────────────────────────────────────────────────────
    chunks: list[Node] = []  # fully-built nodes accumulated so far
    buf: list = []               # raw items not yet committed to a node

    i = 0
    while i < len(grouped):
        item = grouped[i]

        # ── Fraction operator ─────────────────────────────────────────────
        if _is_slash(item):
            num_atom, pre = _extract_numerator(buf)
            pre_text = _buf_to_text(pre, normalize_ops).strip()
            if pre_text:
                if chunks:
                    pre_text = ' ' + pre_text
                chunks.append(MathText(pre_text + ' '))
            i += 1
            den_atom, i = _extract_denominator(grouped, i)
            chunks.append(Fraction(_atom_to_node(num_atom),
                                   _atom_to_node(den_atom)))
            buf = []

        # ── Group / keyword ───────────────────────────────────────────────
        elif isinstance(item, (_Group, _Parens, _Keyword)):
            next_item = _peek_next_non_space(grouped, i + 1)
            if _is_slash(next_item):
                # Defer: this item will be the numerator of an upcoming slash
                buf.append(item)
            else:
                # Standalone: flush the text buffer, then expand the item
                text = _buf_to_text(buf, normalize_ops)
                if text:
                    chunks.append(MathText(text))
                buf = []
                if isinstance(item, _Group):
                    chunks.append(parse(item.content, mode='math',
                                        locale=locale,
                                        normalize_ops=normalize_ops))
                elif isinstance(item, _Keyword):
                    chunks.append(_atom_to_node(item))
                else:  # _Parens
                    chunks.append(MathText('(' + item.content + ')'))
            i += 1

        # ── Ordinary token ────────────────────────────────────────────────
        else:
            buf.append(item)
            i += 1

    # Flush remaining buffer
    remaining = _buf_to_text(buf, normalize_ops).strip()
    if remaining:
        if chunks:
            remaining = ' ' + remaining
        chunks.append(MathText(remaining))

    if not chunks:
        raise ParseError("Empty expression.")

    return chunks[0] if len(chunks) == 1 else Row(chunks)
