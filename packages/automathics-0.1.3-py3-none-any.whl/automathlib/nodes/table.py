# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

"""
Horizontal 2-row table node for proportionality tables and similar layouts.

Usage:
    Table(["1", "2", "3", "4", "6", "8"])
    Table(["1", "2", "3", "4", "6", "8"],
          title=[Text("x"), Text("y")],
          borders='full',
          bubble=MathText("×3"))
    Table([...], col_width='auto', baseline='top')

Layout:
    ┌────────┬──────┬──────┬──────┐
    │ title0 │  v0  │  v1  │  v2  │  ← row 1  (values[0:n])
    ├────────┼──────┼──────┼──────┤
    │ title1 │  v3  │  v4  │  v5  │  ← row 2  (values[n:])
    └────────┴──────┴──────┴──────┘
                                    ) ← optional bubble + curved arrow

The bubble+arrow sits to the right: a cubic Bézier curves from the vertical
centre of row 1 to the vertical centre of row 2, bowing rightward. The bubble
circle is centred to the right of the table, at a distance controlled by
_ARROW_EXTENT_RATIO. The arrow curve is split at its intersection with the
circle so no mask is needed (WeasyPrint compatibility). Its radius adapts to
the content.
"""

import math

from automath.config import CONFIG
from .node import Node
from .math_text import MathText
from .text import Text
from .utils import FontConfig

Point = tuple[float, float]
Cubic = tuple[Point, Point, Point, Point]

DEFAULT_COLOR = CONFIG.get('rendering', {}).get('color', '#222222')

# ── Proportional constants (relative to font_size) ───────────────────────────
# horizontal padding inside each cell
_CELL_PAD_H_RATIO = CONFIG['rendering']['tables']['cell_pad_h_ratio']
# vertical padding inside each cell
_CELL_PAD_V_RATIO = CONFIG['rendering']['tables']['cell_pad_v_ratio']
# px — border line stroke-width
_BORDER_THICKNESS = CONFIG['rendering']['tables']['border_thickness']
# gap between table right edge and arrow foot
_ARROW_GAP_RATIO = CONFIG['rendering']['tables']['arrow_gap_ratio']
# how far right the Bézier control point sits
_ARROW_EXTENT_RATIO = CONFIG['rendering']['tables']['arrow_extent_ratio']
# padding between bubble content and circle edge
_BUBBLE_PAD_RATIO = CONFIG['rendering']['tables']['bubble_pad_ratio']
# px — bubble stroke-width
_BUBBLE_THICKNESS = CONFIG['rendering']['tables']['bubble_thickness']
# auto resize ratio if bubble content is higher than a normal line
_BUBBLE_AUTO_RESIZE = CONFIG['rendering']['tables']['bubble_auto_resize']
# px — half-width/height of the arrowhead triangle
_ARROWHEAD_SIZE = CONFIG['rendering']['tables']['arrowhead_size']


class Table(Node):
    """
    Horizontal 2-row table, optionally with a title column and a bubble+arrow.

    Parameters
    ----------
    values: list of str | Text | MathText | Node
        Flat list of 2*n cell values, first half = row 1, second half = row 2.
        str is auto-converted to MathText.
    title: list of 2 elements, optional
        [title_row1, title_row2]. str is auto-converted to Text.
    borders: 'full' | 'inner' | None
        Border style for the data area.
    title_borders: 'full' | 'inner' | None
        Border style for the title column (ignored when title is None).
    col_width: 'equal' | 'auto'
        'equal' — all data columns share the width of the widest cell.
        'auto'  — each data column is as wide as its widest cell.
        Title column is always sized to its own content.
    row_height: 'equal' | 'auto'
        'equal' — both rows share the height of the tallest cell (including
                  title cells).
        'auto'  — each row is sized to its tallest cell.
    bubble: Node, optional
        Content of the circular bubble drawn to the right of the table.
        Can be Text, MathText, Fraction, Row, etc.
    baseline: 'middle' | 'top' | 'bottom'
        Where the math axis sits within the table, for alignment in a Row:
        'middle' — vertically centred on the full table height.
        'top'    — aligned with the vertical centre of row 1.
        'bottom' — aligned with the vertical centre of row 2.
    config: FontConfig, optional
    color: str
    """

    _supported_options = {"color", "border_color"}

    _VALID_BORDERS = {'full', 'inner', None}
    _VALID_COL_WIDTH = {'equal', 'auto'}
    _VALID_ROW_HEIGHT = {'equal', 'auto'}
    _VALID_BASELINE = {'middle', 'top', 'bottom'}

    def __init__(
        self,
        values: list,
        title: list = None,
        borders: str = 'full',
        title_borders: str = 'full',
        col_width: str = 'equal',
        row_height: str = 'equal',
        bubble: Node = None,
        baseline: str = 'middle',
        config: FontConfig = None,
        color: str = None,
        border_color: str = None
    ):
        # ── Config ────────────────────────────────────────────────────────
        from .utils import DEFAULT_FONTCONFIG
        self.config = config or DEFAULT_FONTCONFIG
        fs = self.config.font_size

        # ── Validate ──────────────────────────────────────────────────────
        if not values or len(values) % 2 != 0:
            raise ValueError(
                f"values must be a non-empty list with an even number of "
                f"elements, got {len(values)}."
            )
        if title is not None and len(title) != 2:
            raise ValueError(
                f"title must be a list of exactly 2 elements, "
                f"got {len(title)}."
            )
        if borders not in self._VALID_BORDERS:
            raise ValueError(
                f"borders must be one of {self._VALID_BORDERS}, "
                f"got {borders!r}."
            )
        if title_borders not in self._VALID_BORDERS:
            raise ValueError(
                f"title_borders must be one of {self._VALID_BORDERS}, "
                f"got {title_borders!r}."
            )
        if col_width not in self._VALID_COL_WIDTH:
            raise ValueError(
                f"col_width must be one of {self._VALID_COL_WIDTH}, "
                f"got {col_width!r}."
            )
        if row_height not in self._VALID_ROW_HEIGHT:
            raise ValueError(
                f"row_height must be one of {self._VALID_ROW_HEIGHT}, "
                f"got {row_height!r}."
            )
        if baseline not in self._VALID_BASELINE:
            raise ValueError(
                f"baseline must be one of {self._VALID_BASELINE}, "
                f"got {baseline!r}."
            )

        self.borders = borders
        self.title_borders = title_borders
        self.col_width_mode = col_width
        self.row_height_mode = row_height
        self.bubble = bubble
        # Auto-resize bubble content if taller than a normal text line
        # Reference height = what a single-line MathText may actually produce
        normal_h = max(self.config.text_metrics.line_height,
                       self.config.math_metrics.line_height) * 1.1
        if (bubble is not None
                and _BUBBLE_AUTO_RESIZE != 1.0
                and bubble.height() > normal_h):
            self._bubble_scale = _BUBBLE_AUTO_RESIZE
        else:
            self._bubble_scale = 1.0
        self.baseline = baseline
        self.color = color
        self.border_color = border_color
        self.bt = _BORDER_THICKNESS

        # ── Proportional spacings ─────────────────────────────────────────
        self._cell_pad_h = fs * _CELL_PAD_H_RATIO
        self._cell_pad_v = fs * _CELL_PAD_V_RATIO
        self._arrow_gap = fs * _ARROW_GAP_RATIO
        self._arrow_ext = fs * _ARROW_EXTENT_RATIO
        self._bubble_pad = fs * _BUBBLE_PAD_RATIO

        # ── Convert values to nodes ───────────────────────────────────────
        n = len(values) // 2

        def _to_data_node(v):
            if isinstance(v, str):
                return MathText(v, self.config, color=self.color)
            else:
                if v.color is None and self.color is not None:
                    v.apply_options(color=self.color)
                return v

        self._row1 = [_to_data_node(v) for v in values[:n]]
        self._row2 = [_to_data_node(v) for v in values[n:]]

        # ── Title column ──────────────────────────────────────────────────
        self._has_title = title is not None
        if self._has_title:
            def _to_title_node(v):
                return Text(v, self.config) if isinstance(v, str) else v
            self._title = [_to_title_node(t) for t in title]
        else:
            self._title = []

        # ── Column widths ─────────────────────────────────────────────────
        n_data = n  # number of data columns
        if col_width == 'equal':
            max_data_w = max(
                nd.width() for nd in self._row1 + self._row2
            )
            cw = max_data_w + 2 * self._cell_pad_h
            self._data_col_widths = [cw] * n_data
        else:  # 'auto'
            self._data_col_widths = [
                max(self._row1[i].width(), self._row2[i].width())
                + 2 * self._cell_pad_h
                for i in range(n_data)
            ]

        if self._has_title:
            tw = max(self._title[0].width(), self._title[1].width())
            self._title_col_width = tw + 2 * self._cell_pad_h
        else:
            self._title_col_width = 0.0

        # ── Row heights ───────────────────────────────────────────────────
        r1_nodes = self._row1 + ([self._title[0]] if self._has_title else [])
        r2_nodes = self._row2 + ([self._title[1]] if self._has_title else [])

        if row_height == 'equal':
            max_h = max(nd.height() for nd in r1_nodes + r2_nodes)
            rh = max_h + 2 * self._cell_pad_v
            self._row_heights = [rh, rh]
        else:  # 'auto'
            self._row_heights = [
                max(nd.height() for nd in r1_nodes) + 2 * self._cell_pad_v,
                max(nd.height() for nd in r2_nodes) + 2 * self._cell_pad_v,
            ]

        # ── Bubble radius ─────────────────────────────────────────────────
        if self.bubble is not None:
            bw = self.bubble.width() * self._bubble_scale
            # Use only the visually occupied height: above + below axis,
            # minus the descent of the main font (whitespace below baseline).
            descent = self.config.text_metrics.descent
            bh = (self.bubble.height() - descent) * self._bubble_scale
            self._bubble_r = (
                math.sqrt((bw / 2) ** 2 + (bh / 2) ** 2) + self._bubble_pad
            )
            # Ensure the bubble left edge stays at least _bubble_r away from
            # the table (i.e. bubble center at least 2 * _bubble_r from the
            # table border).
            # The base value from the ratio is used as a minimum visual "bow"
            # of the curve.
            self._arrow_ext = max(self._arrow_ext,
                                  self._bubble_r * _BUBBLE_THICKNESS)
        else:
            self._bubble_r = 0.0

    # ── Helpers to split Béziers curve ───────────────────────────────────────

    @staticmethod
    def _lerp(a: Point, b: Point, t: float) -> Point:
        return (a[0] + (b[0] - a[0]) * t,
                a[1] + (b[1] - a[1]) * t)

    @classmethod
    def _split_cubic(cls, cubic: Cubic, t: float) -> tuple[Cubic, Cubic]:
        """Split a cubic Bézier at t using de Casteljau."""
        p0, p1, p2, p3 = cubic
        p01 = cls._lerp(p0, p1, t)
        p12 = cls._lerp(p1, p2, t)
        p23 = cls._lerp(p2, p3, t)

        p012 = cls._lerp(p01, p12, t)
        p123 = cls._lerp(p12, p23, t)

        p0123 = cls._lerp(p012, p123, t)

        left: Cubic = (p0, p01, p012, p0123)
        right: Cubic = (p0123, p123, p23, p3)
        return left, right

    @classmethod
    def _cubic_point(cls, cubic: Cubic, t: float) -> Point:
        """Point on cubic Bézier at parameter t."""
        p0, p1, p2, p3 = cubic
        mt = 1.0 - t
        a = mt * mt * mt
        b = 3.0 * mt * mt * t
        c = 3.0 * mt * t * t
        d = t * t * t
        x = a * p0[0] + b * p1[0] + c * p2[0] + d * p3[0]
        y = a * p0[1] + b * p1[1] + c * p2[1] + d * p3[1]
        return x, y

    @classmethod
    def _cubic_circle_roots(
        cls,
        cubic: Cubic,
        cx: float,
        cy: float,
        r: float,
        samples: int = 200,
    ) -> list[float]:
        """
        Return approximate t values where the cubic intersects the circle.
        We bracket sign changes, then refine by bisection.
        """
        def f(t: float) -> float:
            x, y = cls._cubic_point(cubic, t)
            return (x - cx) * (x - cx) + (y - cy) * (y - cy) - r * r

        def bisect(a: float, b: float, fa: float, fb: float) -> float:
            for _ in range(60):
                m = (a + b) / 2.0
                fm = f(m)
                if fa == 0.0:
                    return a
                if fb == 0.0:
                    return b
                if fa * fm <= 0.0:
                    b, fb = m, fm
                else:
                    a, fa = m, fm
            return (a + b) / 2.0

        ts = [i / samples for i in range(samples + 1)]
        fs = [f(t) for t in ts]

        roots: list[float] = []

        # Near zero hits at sample points
        for t, ft in zip(ts, fs):
            if abs(ft) < 1e-10:
                roots.append(t)

        # Sign changes
        for i in range(samples):
            a, b = ts[i], ts[i + 1]
            fa, fb = fs[i], fs[i + 1]
            if fa * fb < 0.0:
                roots.append(bisect(a, b, fa, fb))

        # Deduplicate close roots
        roots.sort()
        deduped: list[float] = []
        for t in roots:
            if not deduped or abs(t - deduped[-1]) > 1e-4:
                deduped.append(t)
        return deduped

    @classmethod
    def _cubic_subcurve(cls, cubic: Cubic, t0: float, t1: float) -> Cubic:
        """Extract the cubic segment on [t0, t1]."""
        if t0 <= 0.0 and t1 >= 1.0:
            return cubic
        _, right = cls._split_cubic(cubic, t0)
        u = (t1 - t0) / (1.0 - t0)
        left, _ = cls._split_cubic(right, u)
        return left

    @staticmethod
    def _cubic_to_svg_path(cubic: Cubic) -> str:
        p0, p1, p2, p3 = cubic
        return (
            f'M {p0[0]:.3f},{p0[1]:.3f} '
            f'C {p1[0]:.3f},{p1[1]:.3f} '
            f'{p2[0]:.3f},{p2[1]:.3f} '
            f'{p3[0]:.3f},{p3[1]:.3f}'
        )

    # ── Internal geometry ────────────────────────────────────────────────────

    def _table_width(self) -> float:
        """Width of the grid, excluding the bubble."""
        return self._title_col_width + sum(self._data_col_widths)

    def _table_height(self) -> float:
        return sum(self._row_heights) + self.bt

    def _bubble_extra_width(self) -> float:
        if self.bubble is None:
            return 0.0
        # Bézier extent (= x of bubble centre relative to table right)
        # + bubble radius
        return self._arrow_ext + self._bubble_r + _BUBBLE_THICKNESS / 2

    # ── Node interface ───────────────────────────────────────────────────

    def width(self) -> float:
        return self.bt / 2 + self._table_width() + self._bubble_extra_width()

    def height(self) -> float:
        table_h = self._table_height()
        if self.bubble is None:
            return table_h
        # Bubble center is at table vertical midpoint; check for overhang.
        r = self._bubble_r
        bubble_top = table_h / 2 - r
        bubble_bottom = table_h / 2 + r
        return max(table_h, bubble_bottom) - min(0.0, bubble_top)

    def above_axis(self) -> float:
        """
        Distance from the top of the table to the math axis.
        Controlled by the baseline parameter:
        'middle' → centre of the full table
        'top'    → centre of row 1
        'bottom' → centre of row 2
        """
        rh0, rh1 = self._row_heights
        if self.baseline == 'middle':
            return self._table_height() / 2
        elif self.baseline == 'top':
            return self.bt / 2 + rh0 / 2
        else:  # 'bottom'
            return self.bt / 2 + rh0 + rh1 / 2

    # ── SVG rendering ────────────────────────────────────────────────────────

    def to_svg(self, x: float = 0.0, y: float = 0.0) -> str:
        parts = []

        # Top-left corner of the table grid in SVG space
        y_top = y - self.above_axis() + self.bt / 2

        # Offset by half border thickness so the left stroke doesn't bleed
        # outside the bounding box.
        x_offset = x + self.bt
        x_data_start = x_offset + self._title_col_width

        parts.append(self._render_contents(x, y_top, x_data_start))
        parts.append(self._render_borders(x, y_top, x_data_start))
        if self.bubble is not None:
            parts.append(self._render_bubble(x, y_top))

        return ''.join(parts)

    # ── Cell contents ────────────────────────────────────────────────────────

    def _render_contents(
        self,
        x_left: float,
        y_top: float,
        x_data_start: float,
    ) -> str:
        parts = []

        def place(node, cell_x, cell_y, cell_w, cell_h):
            """Centre node's bounding box within its cell."""
            content_x = cell_x + (cell_w - node.width()) / 2
            # Vertical: centre the bounding box, not the math axis
            content_y = cell_y + (cell_h - node.height()) / 2 \
                + node.above_axis()
            parts.append(node.to_svg(content_x, content_y))

        rh0, rh1 = self._row_heights

        # Title column
        if self._has_title:
            tw = self._title_col_width
            place(self._title[0], x_left, y_top,       tw, rh0)
            place(self._title[1], x_left, y_top + rh0, tw, rh1)

        # Data cells
        for r, (row_nodes, cell_y) in enumerate(
            [(self._row1, y_top), (self._row2, y_top + rh0)]
        ):
            cursor_x = x_data_start
            cell_h = self._row_heights[r]
            for i, node in enumerate(row_nodes):
                cw = self._data_col_widths[i]
                place(node, cursor_x, cell_y, cw, cell_h)
                cursor_x += cw

        return ''.join(parts)

    # ── Borders ──────────────────────────────────────────────────────────────

    def _render_borders(
        self,
        x_left: float,
        y_top: float,
        x_data_start: float,
    ) -> str:
        elems = []
        bc = self.border_color or DEFAULT_COLOR
        bt = self.bt
        rh0, rh1 = self._row_heights
        # content height, without border margins:
        table_h = sum(self._row_heights)
        x_right = x_left + self._table_width()
        y_bot = y_top + table_h
        y_mid = y_top + rh0

        def rect(rx, ry, rw, rh):
            """
            Outer frame as <rect> — perfect square corners, no overlap
            artefact.
            """
            return (
                f'<rect x="{rx:.3f}" y="{ry:.3f}" '
                f'width="{rw:.3f}" height="{rh:.3f}" '
                f'fill="none" stroke="{bc}" stroke-width="{bt:.1f}"/>'
            )

        def ln(x1, y1, x2, y2):
            """
            Inner separator with round linecap so it meets the outer frame
            cleanly.
            """
            return (
                f'<line x1="{x1:.3f}" y1="{y1:.3f}" '
                f'x2="{x2:.3f}" y2="{y2:.3f}" '
                f'stroke="{bc}" stroke-width="{bt:.1f}" '
                f'stroke-linecap="round"/>'
            )

        # ── Data area ────────────────────────────────────────────────────
        if self.borders == 'full':
            dw = x_right - x_data_start
            elems.append(rect(x_data_start, y_top, dw, table_h))

        if self.borders in ('full', 'inner'):
            elems.append(ln(x_data_start, y_mid, x_right, y_mid))  # h-sep
            cursor_x = x_data_start
            for cw in self._data_col_widths[:-1]:
                cursor_x += cw
                elems.append(ln(cursor_x, y_top, cursor_x, y_bot))

        # ── Title column ─────────────────────────────────────────────────
        if self._has_title:
            x_tr = x_data_start   # title right = data left
            x_tl = x_left         # title left
            tw = x_tr - x_tl

            if self.title_borders == 'full':
                elems.append(rect(x_tl, y_top, tw, table_h))
                elems.append(ln(x_tl, y_mid, x_tr, y_mid))   # h-sep
            elif self.title_borders == 'inner':
                elems.append(ln(x_tr, y_top, x_tr, y_bot))   # right separator
                elems.append(ln(x_tl, y_mid, x_tr, y_mid))   # h-sep

        return ''.join(elems)

    # ── Bubble + arrow ───────────────────────────────────────────────────────

    def _render_bubble(self, x_left: float, y_top: float) -> str:
        parts = []
        r = self._bubble_r
        bc = self.border_color or DEFAULT_COLOR
        rh0, rh1 = self._row_heights

        sw = _BUBBLE_THICKNESS                  # arrow stroke-width
        ah = _ARROWHEAD_SIZE
        x_foot = x_left + self._table_width()   # table right border
        x_bubble = x_foot + self._arrow_ext        # bubble centre x
        y_start = y_top + rh0 / 2                # centre of row 1
        y_end = y_top + rh0 + rh1 / 2          # centre of row 2
        y_mid = (y_start + y_end) / 2          # bubble centre y
        cx, cy = x_bubble, y_mid

        # Curve feet positions:
        #   top   : shift right by sw/2 so the round cap centre sits on the
        #           border (prevents the cap from bleeding left of the border
        #           line)
        #   bottom: shift right by ah so the stroke end is hidden under the
        #           arrowhead
        x_top_foot = x_foot + sw / 3
        x_bot_foot = x_foot + 0.75 * ah

        # Cubic Bézier with slight downward slope at start/end.
        slope = (y_end - y_start) / 4
        path = (
            f'M {x_top_foot:.3f},{y_start:.3f} '
            f'C {x_bubble:.3f},{y_start + slope:.3f} '
            f'{x_bubble:.3f},{y_end - slope:.3f} '
            f'{x_bot_foot:.3f},{y_end:.3f}'
        )

        cubic: Cubic = (
            (x_top_foot, y_start),
            (x_bubble, y_start + slope),
            (x_bubble, y_end - slope),
            (x_bot_foot, y_end),
        )

        # Small shrink so the round caps stay hidden under the bubble outline.
        r_cut = max(r, 0.1)

        roots = self._cubic_circle_roots(cubic, cx, cy, r_cut)

        if len(roots) >= 2:
            t1, t2 = roots[0], roots[-1]

            # Keep only the outer parts of the curve.
            left_cubic = self._cubic_subcurve(cubic, 0.0, t1)
            right_cubic = self._cubic_subcurve(cubic, t2, 1.0)

            parts.append(
                f'<path d="{self._cubic_to_svg_path(left_cubic)}" '
                f'stroke="{bc}" stroke-width="{_BUBBLE_THICKNESS}" '
                f'fill="none" stroke-linecap="round"/>'
            )
            parts.append(
                f'<path d="{self._cubic_to_svg_path(right_cubic)}" '
                f'stroke="{bc}" stroke-width="{_BUBBLE_THICKNESS}" '
                f'fill="none" stroke-linecap="round"/>'
            )
        else:
            # Fallback: if the intersection detection fails,
            # render the full curve.
            parts.append(
                f'<path d="{path}" stroke="{bc}" '
                f'stroke-width="{_BUBBLE_THICKNESS}" '
                f'fill="none" stroke-linecap="round"/>'
            )

        # Arrowhead tip at x_foot (table border), tangent from last control
        # point (x_bubble, y_end-slope) toward curve end (x_bot_foot, y_end).
        dx = x_bot_foot - x_bubble
        dy = slope
        length = math.sqrt(dx * dx + dy * dy)
        ux, uy = dx / length, dy / length          # unit tangent
        nx, ny = -uy, ux                           # normal (perpendicular)
        ah = _ARROWHEAD_SIZE

        tip = (x_foot, y_end + 0.75 * uy * ah)
        base1 = (tip[0] - ux * ah + nx * ah / 2,
                 tip[1] - uy * ah + ny * ah / 2)
        base2 = (tip[0] - ux * ah - nx * ah / 2,
                 tip[1] - uy * ah - ny * ah / 2)
        arrowhead = (
            f'M {tip[0]:.3f},{tip[1]:.3f} '
            f'L {base1[0]:.3f},{base1[1]:.3f} '
            f'L {base2[0]:.3f},{base2[1]:.3f} Z'
        )
        parts.append(f'<path d="{arrowhead}" fill="{bc}" stroke="none"/>')

        # Bubble circle (transparent fill)
        parts.append(
            f'<circle cx="{cx:.3f}" cy="{cy:.3f}" r="{r:.3f}" '
            f'fill="none" stroke="{bc}" stroke-width="{_BUBBLE_THICKNESS}"/>'
        )

        # Bubble content centred on (cx, cy)
        node = self.bubble
        s = self._bubble_scale
        bx = cx - node.width() / 2
        by = cy
        if s != 1.0:
            parts.append(
                f'<g transform="translate({cx:.3f},{cy:.3f}) '
                f'scale({s:.4f}) '
                f'translate({-cx:.3f},{-cy:.3f})">'
            )
            parts.append(node.to_svg(bx, by))
            parts.append('</g>')
        else:
            parts.append(node.to_svg(bx, by))

        return ''.join(parts)
