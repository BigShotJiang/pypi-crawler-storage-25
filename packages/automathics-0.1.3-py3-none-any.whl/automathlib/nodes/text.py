# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

import xml.sax.saxutils as saxutils

from automath.config import CONFIG
from .node import Node
from .utils import FontConfig, DEFAULT_FONTCONFIG


DEFAULT_COLOR = CONFIG.get('rendering', {}).get('color', '#222222')


class Text(Node):
    """
    Regular text rendered entirely in the main font.

    Parameters
    ----------
    text   : str
    config : FontConfig, optional
    bold   : bool
        If True, renders with font-weight bold.
    color  : str, optional
        SVG fill color. Defaults to the global rendering color.
    """

    _supported_options = {"color", "bold"}

    def __init__(self, text: str, config: FontConfig = None,
                 bold: bool = False, color: str = None):
        self.text = text
        self.config = config or DEFAULT_FONTCONFIG
        self.bold = bold
        self._metrics = self.config.text_metrics
        self.color = color

    def width(self) -> float:
        return self._metrics.string_width(self.text)

    def height(self) -> float:
        return self._metrics.line_height

    def above_axis(self) -> float:
        # The math axis sits math_axis pixels above the text baseline.
        # above_axis = distance from the math axis up to the top of the
        # bounding box = ascent - math_axis.
        # This ensures Row can mix Text and Fraction on a consistent axis.
        return self._metrics.ascent - self._metrics.math_axis

    def to_svg(self, x: float = 0.0, y: float = 0.0) -> str:
        # y is the math axis. Text baseline is math_axis below the math axis.
        baseline_y = y + self._metrics.math_axis
        font_weight = "bold" if self.bold else "normal"
        escaped = saxutils.escape(self.text)
        return (
            f'<text xml:space="preserve" '
            f'x="{x:.3f}" y="{baseline_y:.3f}" '
            f'font-family="{self.config.text_font_name}" '
            f'font-size="{self.config.font_size:.1f}" '
            f'font-weight="{font_weight}" '
            f'fill="{self.color or DEFAULT_COLOR}">'
            f'{escaped}'
            f'</text>'
        )
