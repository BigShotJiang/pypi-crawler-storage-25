# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

"""
Usage:
    Row([MathText("x + "), Fraction("3", "4"), MathText(" = "),
         Fraction("7", "8")])
    Row([Fraction("3", "4"), MathText(" + "), Fraction("1", "2")], config=cfg)
    Row([MathText("x + "), Fraction("3", "4")], spacing=2.0)
    Row([MathText("x"), Sup("2")])
"""

import copy

from .node import Node
from .utils import FontConfig


class Row(Node):
    """
    Horizontal sequence of Nodes aligned on a shared math axis.

    All children receive the same y coordinate (the common math axis), so
    each one positions itself correctly via its own above_axis()/below_axis().
    Row itself does not impose any vertical repositioning on its children.

    Parameters
    ----------
    children : list of Node
        Nodes to lay out from left to right.
    config   : FontConfig
        Used to access the math axis reference for vertical alignment.
        If None, the config of the first child that exposes one is used.
    spacing  : float
        Extra horizontal gap inserted between consecutive children (px).
        Default 0: children are placed immediately adjacent.
    """

    _supported_options = {"color"}

    def __init__(
        self,
        children: list[Node],
        config: FontConfig = None,
        spacing: float = 0.0,
        color: str = None
    ):
        if not children:
            raise ValueError("Row requires at least one child node.")
        self.children = [copy.deepcopy(c) for c in children]
        self.spacing = spacing

        self.color = color
        # Propagate color if not None and yet unset
        for child in self.children:
            if child.color is None and color is not None:
                child.apply_options(color=color)

        # Resolve config:
        # explicit > first child that has one > DEFAULT_FONTCONFIG
        if config is not None:
            self.config = config
        else:
            self.config = self._find_config()

    def apply_options(self, **options):
        super().apply_options(**options)
        for child in self.children:
            filtered = {k: v for k, v in options.items()
                        if k in child._supported_options
                        and getattr(child, k) is None}
            if filtered:
                child.apply_options(**filtered)
        return self

    def _find_config(self) -> FontConfig:
        """Return the first config found among children, or the default."""
        for child in self.children:
            if hasattr(child, 'config') and child.config is not None:
                return child.config
        from .utils import DEFAULT_FONTCONFIG
        return DEFAULT_FONTCONFIG

    # ── Dimensions ───────────────────────────────────────────────────────────

    def width(self) -> float:
        total = sum(c.width() for c in self.children)
        total += self.spacing * (len(self.children) - 1)
        return total

    def above_axis(self) -> float:
        """
        Common axis is set high enough to accommodate the tallest child above.
        """
        return max(c.above_axis() for c in self.children)

    def below_axis(self) -> float:
        """Common axis must also leave room for the deepest child below."""
        return max(c.below_axis() for c in self.children)

    def height(self) -> float:
        return self.above_axis() + self.below_axis()

    # ── SVG rendering ────────────────────────────────────────────────────────

    def to_svg(self, x: float = 0.0, y: float = 0.0) -> str:
        """
        x: left edge of the row
        y: shared math axis passed unchanged to every child
        """
        parts = []
        cursor_x = x
        for child in self.children:
            parts.append(child.to_svg(cursor_x, y))
            cursor_x += child.width() + self.spacing
        return "".join(parts)
