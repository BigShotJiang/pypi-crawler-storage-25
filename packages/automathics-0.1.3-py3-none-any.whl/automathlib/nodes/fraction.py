# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA


"""
Usage:
    Fraction(Text("3"), Text("4"))
    Fraction(MathText("2x"), Text("5"), config=cfg)
    Fraction("3", "4", config=cfg)          # shortcut: str → MathText auto
"""

#   ┌─ bar_pad_h ──── content ────── bar_pad_h ─┐

#       [    centered numerator   ]       ↑ num.height()
#   ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─   ↕ bar_pad_v
#    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━   ↕ bar_thickness ← math axis
#   ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─   ↕ bar_pad_v
#       [   centered denominator  ]       ↓ den.height()

from automath.config import CONFIG
from .node import Node
from .math_text import MathText
from .utils import FontConfig, DEFAULT_FONTCONFIG

DEFAULT_COLOR = CONFIG.get('rendering', {}).get('color', '#222222')

# Spacings proportional to font size.
# bar thickness (e.g. 0.085 × 20px → 1.7px, sub-pixel values accepted)
_BAR_THICKNESS_RATIO = CONFIG['rendering']['fractions']['bar_thickness_ratio']
# vertical space betwen bar and num/den
_BAR_PAD_V_RATIO = CONFIG['rendering']['fractions']['bar_pad_v_ratio']
# horizontal extension of the bar on each side
_BAR_PAD_H_RATIO = CONFIG['rendering']['fractions']['bar_pad_h_ratio']


class Fraction(Node):
    """
    Math fraction with numerator, denominator and horizontal bar.

    Parameters
    ----------
    numerator   : Node or str (converted to MathText if str)
    denominator : Node or str (converted to MathText if str)
    config      : FontConfig (used for str→MathText conversion and bar
                  proportions)
    color       : bar color (also propagated to numerator and denominator if
                  provided as str)
    """

    _supported_options = {"color"}

    def apply_options(self, **options):
        super().apply_options(**options)
        filtered = {k: v for k, v in options.items()
                    if k in self.numerator._supported_options
                    and getattr(self.numerator, k) is None}
        if filtered:
            self.numerator.apply_options(**filtered)
        filtered = {k: v for k, v in options.items()
                    if k in self.denominator._supported_options
                    and getattr(self.denominator, k) is None}
        if filtered:
            self.denominator.apply_options(**filtered)
        return self

    def __init__(
        self,
        numerator: "Node | str",
        denominator: "Node | str",
        config: FontConfig = None,
        color: str = None
    ):
        self.config = config or DEFAULT_FONTCONFIG

        self.color = color

        # str → MathText conversion
        self.numerator = (MathText(numerator, self.config, color=self.color)
                          if isinstance(numerator, str) else numerator)
        self.denominator = (MathText(denominator, self.config,
                                     color=self.color)
                            if isinstance(denominator, str) else denominator)

        # Propagate color if not yet set
        if self.numerator.color is None and color is not None:
            self.numerator.apply_options(color=color)
        if self.denominator.color is None and color is not None:
            self.denominator.apply_options(color=color)

        fs = self.config.font_size
        self.bar_thickness = max(1.0, fs * _BAR_THICKNESS_RATIO)
        self.bar_pad_v = fs * _BAR_PAD_V_RATIO
        self.bar_pad_h = fs * _BAR_PAD_H_RATIO

    # ── Dimensions ───────────────────────────────────────────────────────────

    def _bar_width(self) -> float:
        """Bar width = max(num, den) + 2 × horizontal overflow."""
        return (max(self.numerator.width(), self.denominator.width())
                + 2 * self.bar_pad_h)

    def width(self) -> float:
        return self._bar_width()

    def above_axis(self) -> float:
        """Height above math axis: num.height() + space + half-bar."""
        return (self.numerator.height()
                + self.bar_pad_v
                + self.bar_thickness / 2)

    def height(self) -> float:
        return (self.numerator.height()
                + self.bar_pad_v
                + self.bar_thickness
                + self.bar_pad_v
                + self.denominator.height())

    # ── SVG rendering ────────────────────────────────────────────────────────

    def to_svg(self, x: float = 0.0, y: float = 0.0) -> str:
        """
        x: fraction's left edge
        y: math axis (bar center)
        """
        bar_w = self._bar_width()

        # bar_top rounded to the nearest whole pixel: guarantees a constant
        # thickness regardless of the vertical position of the fraction.
        bar_center_y = round(y)
        bar_top = bar_center_y - self.bar_thickness / 2
        rx = self.bar_thickness / 2   # semicircular ends

        # Centred numerator, axis positioned above the line
        num_x = x + (bar_w - self.numerator.width()) / 2
        num_y = bar_top - self.bar_pad_v - self.numerator.below_axis()

        # Centred denominator, axis positioned below the line
        den_x = x + (bar_w - self.denominator.width()) / 2
        den_y = (bar_top + self.bar_thickness
                 + self.bar_pad_v
                 + self.denominator.above_axis())

        svg_bar = (
            f'<rect '
            f'x="{x:.3f}" y="{bar_top:.1f}" '
            f'width="{bar_w:.3f}" height="{self.bar_thickness:.1f}" '
            f'rx="{rx:.2f}" '
            f'fill="{self.color or DEFAULT_COLOR}"/>'
        )

        return (
            self.numerator.to_svg(num_x, num_y)
            + svg_bar
            + self.denominator.to_svg(den_x, den_y)
        )
