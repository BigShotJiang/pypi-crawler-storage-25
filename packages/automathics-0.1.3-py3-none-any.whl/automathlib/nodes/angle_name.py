# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

"""
Usage:
    AngleName("ABC")            # uses locale from CONFIG
    AngleName("B", config=cfg)
    AngleName("ABC", locale="fr")
    AngleName("ABC", locale="en")

English output : ∠ABC  (Text node with drawn ∠ symbol)
French output  : ABC with a hat drawn above as two straight segments (^),
                 spanning the full text width, peak centred horizontally.

Angle names are 1 or 3 letters, e.g. "B", "ABC", "ILW".

Hat geometry (French):

        /\\          ← peak: horizontally centred, hat_height above base
       /  \\
      /    \\
  ─ ─ ─ ─ ─ ─ ─ ─   ← base of the segments, hat_clearance below text top
  [ A    B    C ]
"""

from automath.config import CONFIG
from .node import Node
from .text import Text
from .math_text import MathText
from .utils import FontConfig

DEFAULT_COLOR = CONFIG.get('rendering', {}).get('color', '#222222')

# ── Hat geometry (proportional to font_size) ─────────────────────────────────
# height of the peak above the base line
_HAT_HEIGHT_RATIO = CONFIG['rendering']['angle']['hat_height_ratio']
# gap between text top and base of the hat
_HAT_CLEARANCE_RATIO = CONFIG['rendering']['angle']['hat_clearance_ratio']
# stroke width
_HAT_STROKE_RATIO = CONFIG['rendering']['angle']['hat_stroke_ratio']
# stroke width
_ANG_STROKE_RATIO = CONFIG['rendering']['angle']['ang_stroke_ratio']
# right margin of the top of the English angle symbol
_ANG_RIGHT_MARGIN = CONFIG['rendering']['angle']['ang_right_margin']
# width of the English angle symbol to draw
_ANG_WIDTH = CONFIG['rendering']['angle']['ang_width']
# right gap of the English angle symbol to draw
_ANG_GAP_RATIO = CONFIG['rendering']['angle']['ang_gap_ratio']


class AngleName(Node):
    """
    Angle name node.

    In English locale, renders as "∠<n>" drawing the ∠ with two straight
    segments starting from a common point.
    In French locale, renders the letters with a hat (^) drawn above,
    made of two straight segments meeting at a centered peak.

    Parameters
    ----------
    name      : str
        1 or 3 letters (e.g. "B", "ABC").
    config    : FontConfig, optional
    locale    : "en" | "fr", optional
        Overrides CONFIG['locale'] when provided.
    color : str
        SVG stroke colour for the hat (defaults to default color from config).
    """

    _supported_options = {"color"}

    _VALID_LENGTHS = {1, 3}

    @staticmethod
    def _validate(name: str | Text | MathText) -> None:
        if not isinstance(name, (str, Text, MathText)):
            raise TypeError(
                f"Angle name must be a str, Text or MathText, "
                f"got {type(name).__name__!r}."
            )
        name_length = len(name) if isinstance(name, str) else len(name.text)
        name_repr = name if isinstance(name, str) else name.text
        if name_length not in AngleName._VALID_LENGTHS:
            raise ValueError(
                f"Angle name must be 1 or 3 letters, got {name_length}: "
                f"{name_repr!r}."
            )

    def __init__(
        self,
        name: str,
        config: FontConfig = None,
        locale: str = None,
        color: str = None,
    ):
        self._validate(name)
        self.name = name
        self.color = color

        from .utils import DEFAULT_FONTCONFIG
        self.config = config or DEFAULT_FONTCONFIG

        self.locale = locale or CONFIG.get('locale', 'en')

        fs = self.config.font_size
        self.hat_height = fs * _HAT_HEIGHT_RATIO
        self.hat_clearance = fs * _HAT_CLEARANCE_RATIO
        self.hat_stroke = max(1.0, fs * _HAT_STROKE_RATIO)

        self.ang_stroke = max(1.0, fs * _ANG_STROKE_RATIO)
        self.ang_rm = _ANG_RIGHT_MARGIN
        # Symbol width based on width of 'O' in the main font
        self.ang_width = self.config.text_metrics.char_width('O') * _ANG_WIDTH
        self.ang_gap = self.config.font_size * _ANG_GAP_RATIO

        # Inner text node (letters only, used by both locales)
        self._text = ''
        if isinstance(name, str):
            self._text = MathText(name, self.config, color=self.color)
        elif isinstance(name, Text):
            self._text = Text(name.text, self.config, color=name.color)
        else:  # MathText
            self._text = MathText(name.text, self.config, color=name.color)

    # ── Dimensions ───────────────────────────────────────────────────────────

    def width(self) -> float:
        if self.locale == 'fr':
            return self._text.width() + self.hat_stroke
        else:  # fallback to 'en' locale
            return self.ang_width + 2 * self.ang_gap + self._text.width()

    def height(self) -> float:
        if self.locale == 'fr':
            return self.hat_height + self.hat_clearance + self._text.height() \
                + self.hat_stroke / 2
        else:  # fallback to 'en' locale
            return self._text.height()

    def above_axis(self) -> float:
        if self.locale == 'fr':
            # Hat sits entirely above the text, so the math axis is still
            # determined by the inner text; the hat just adds to above_axis.
            return self.hat_height + self.hat_clearance \
                + self._text.above_axis() + self.hat_stroke / 2
        else:  # fallback to 'en' locale
            return self._text.above_axis()

    # ── SVG rendering ────────────────────────────────────────────────────────

    def to_svg(self, x: float = 0.0, y: float = 0.0) -> str:
        if self.locale == 'fr':
            return self._render_fr(x, y)
        else:  # fallback to 'en' locale
            return self._render_en(x, y)

    def _render_en(self, x: float, y: float) -> str:
        """
        Render the English notation: ∠ symbol drawn with two SVG segments,
        followed by the angle name letters.

        The ∠ symbol is two straight segments:
        top vertex → bottom-left → bottom-right

        Coordinates:
        base_y     = y + math_axis        text baseline
        top_y      = y - text.above_axis()  top of bounding box
        x_left     = x                    left foot of horizontal bar
        x_right    = x + char_width('O')  right foot of horizontal bar
        x_topright = x_right - ang_rm    top vertex (slightly inset from right)

          x_left        x_right
            │               │
            │   x_topright  │
            │       ●       │  ← top_y  (top of bounding box)
            │      ╱        │
            │     ╱         │
            ●────────────●   ← base_y  (text baseline)
        x_left        x_right

        Coordinates:
          ...
        """
        # base_y = text baseline (not the math axis)
        base_y = y + self.config.text_metrics.x_height / 2
        # top_y = top of the bounding box (smaller y in SVG = higher on screen)
        # top_y = y - self._text.above_axis()
        top_y = y - self.config.text_metrics.char_top('A') \
            + self.config.text_metrics.math_axis

        x_left = x + self.ang_gap
        x_right = x + self.ang_gap + self.ang_width
        # top vertex slightly inset from right
        x_topright = x + self.ang_gap + self.ang_width * self.ang_rm

        path = (
            f'M {x_topright:.3f},{top_y:.3f} '
            f'L {x_left:.3f},{base_y:.3f} '
            f'L {x_right:.3f},{base_y:.3f}'
        )

        svg_ang = (
            f'<path '
            f'd="{path}" '
            f'stroke="{self.color or DEFAULT_COLOR}" '
            f'stroke-width="{self.ang_stroke:.1f}" '
            f'fill="none" '
            f'stroke-linecap="round" '
            f'stroke-linejoin="round"/>'
        )

        return svg_ang + self._text.to_svg(x + self.ang_width
                                           + 2 * self.ang_gap,
                                           y)

    def _render_fr(self, x: float, y: float) -> str:
        """
        Render the French notation: letters with a hat (^) above.

        The hat is two straight segments: left foot → peak → right foot.

        Coordinates:
          text_top = y - text.above_axis()      top of text bounding box
          base_y   = text_top - hat_clearance   feet of the segments
          peak_y   = base_y   - hat_height      peak of the hat
          x_left   = x                          left foot
          x_center = x + text.width() / 2       peak (centred)
          x_right  = x + text.width()           right foot
        """
        w = self._text.width()

        text_top = y - self._text.above_axis()
        base_y = text_top - self.hat_clearance
        peak_y = base_y - self.hat_height

        x_off = x + self.hat_stroke / 2   # compensate left bleed
        x_left = x_off
        x_center = x_off + w / 2
        x_right = x_off + w

        path = (
            f'M {x_left:.3f},{base_y:.3f} '
            f'L {x_center:.3f},{peak_y:.3f} '
            f'L {x_right:.3f},{base_y:.3f}'
        )

        svg_hat = (
            f'<path '
            f'd="{path}" '
            f'stroke="{self.color or DEFAULT_COLOR}" '
            f'stroke-width="{self.hat_stroke:.1f}" '
            f'fill="none" '
            f'stroke-linecap="round" '
            f'stroke-linejoin="round"/>'
        )

        return self._text.to_svg(x_off, y) + svg_hat
