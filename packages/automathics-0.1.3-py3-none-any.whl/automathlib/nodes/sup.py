# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

"""
Superscript node.  Used as a child of Row to attach an exponent to the
preceding node.

Usage:
    Row([MathText("x"), Sup("2")])          # x²
    Row([MathText("a"), Sup("n+1")])        # aⁿ⁺¹
    Sup("2", config=cfg)                    # standalone superscript

Layout (y = math axis):

    ┌────────┐
    │ "2"    │  ← exp_node (rendered at reduced font size)
    └────────┘
         ↑ raise  (bottom of exp_node above the math axis)
─────────────────  ← math axis (y)

Dimensions:
    above_axis = raise + exp_node.height()
    below_axis = 0
    width      = exp_node.width()
"""

from automath.config import CONFIG
from .node import Node
from .math_text import MathText
from .fraction import Fraction
from .text import Text
from .utils import FontConfig, DEFAULT_FONTCONFIG

DEFAULT_COLOR = CONFIG.get('rendering', {}).get('color', '#222222')

# ── Proportional constants (relative to main font_size) ──────────────────────
# Exponent font size as a fraction of the main font size.
_EXP_SIZE_RATIO = CONFIG['rendering']['sup']['size_ratio']
# How high the *bottom* of the exponent sits above the math axis,
# as a fraction of the main font size.
_EXP_RAISE_RATIO = CONFIG['rendering']['sup']['raise_ratio']


def resized(node: MathText | Fraction | Text, color: str = None):
    """
    Re-create node at a reduced font size (_EXP_SIZE_RATIO applied).
    The original node is not mutated.
    For Fraction, numerator and denominator are recursively resized.
    """
    if not isinstance(node, (MathText, Text, Fraction)):
        raise TypeError(f"Unsupported type {type(node).__name__}. "
                        "Expected MathText, Text or Fraction.")
    exp_config = FontConfig(
        text_font_name=node.config.text_font_name,
        math_font_name=node.config.math_font_name,
        font_size=node.config.font_size * _EXP_SIZE_RATIO,
        math_chars=node.config.math_chars,
    )
    if isinstance(node, MathText):
        return MathText(node.text, exp_config, color=node.color or color)

    elif isinstance(node, Text):
        return Text(node.text, exp_config, color=node.color or color)

    elif isinstance(node, Fraction):
        return Fraction(resized(node.numerator), resized(node.denominator),
                        exp_config, color=node.color or color)


class Sup(Node):
    """
    Superscript node.

    Parameters
    ----------
    exponent : str | MathText | Text | Fraction
        The exponent content. A str is auto-converted to MathText at the
        reduced font size. A MathText, Text or Fraction is re-created at
        the reduced font size via resized().
    config   : FontConfig, optional
        Used to derive the reduced font size when exponent is a str.
    color    : str, optional
    """

    _supported_options = {"color"}

    def apply_options(self, **options):
        super().apply_options(**options)
        filtered = {k: v for k, v in options.items()
                    if k in self.content._supported_options
                    and getattr(self.content, k) is None}
        if filtered:
            self.content.apply_options(**filtered)
        return self

    def __init__(
        self,
        exponent: str | MathText | Fraction | Text,
        config: FontConfig = None,
        color: str = None,
    ):
        self.config = config or DEFAULT_FONTCONFIG
        self.color = color

        fs = self.config.font_size
        self._raise = fs * _EXP_RAISE_RATIO

        if isinstance(exponent, str):
            # Build a reduced-size FontConfig for the exponent text.
            exp_config = FontConfig(
                text_font_name=self.config.text_font_name,
                math_font_name=self.config.math_font_name,
                font_size=fs * _EXP_SIZE_RATIO,
                math_chars=self.config.math_chars,
            )
            self.content = MathText(exponent, exp_config, color=self.color)
        else:
            self.content = resized(exponent, color=color)

    # ── Dimensions ───────────────────────────────────────────────────────────

    def width(self) -> float:
        return self.content.width()

    def above_axis(self) -> float:
        return self._raise + self.content.height()

    def below_axis(self) -> float:
        return 0.0

    def height(self) -> float:
        return self.above_axis()

    # ── SVG rendering ────────────────────────────────────────────────────────

    def to_svg(self, x: float = 0.0, y: float = 0.0) -> str:
        """
        x : left edge of the superscript
        y : main math axis

        We want the bottom of exp_node to sit at (y - raise).
        In our coordinate system the bottom of a node is at
        node_axis + node.below_axis(), so:
            exp_axis + exp_node.below_axis() = y - raise
            exp_axis = y - raise - exp_node.below_axis()
        """
        exp_axis_y = y - self._raise - self.content.below_axis()
        return self.content.to_svg(x, exp_axis_y)
