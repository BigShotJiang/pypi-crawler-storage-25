# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

import xml.sax.saxutils as saxutils

from automath.config import CONFIG
from .node import Node
from .utils import FontConfig, DEFAULT_FONTCONFIG

DEFAULT_COLOR = CONFIG.get('rendering', {}).get('color', '#222222')


class MathText(Node):
    """
    Text displaying certain characters (typically variables like x, y etc. to
    make them visually different from operators, especially x and × must be
    clearly different) in a dedicated font.
    See fonts -> math_chars settings in automath.yaml

    Other characters are displayed using the main text font.
    """

    _supported_options = {"color", "bold"}

    def __init__(self, text: str, config: FontConfig = None,
                 bold: bool = False, color: str = None):
        self.text = text
        self.config = config or DEFAULT_FONTCONFIG
        self.bold = bold
        self.color = color
        self._text = self.config.text_metrics
        self._math = self.config.math_metrics

    def _segments(self) -> list[tuple[str, bool]]:
        """
        Cut text in segments (text, is_math_char).
        Consecutive characters of the same type are merged into one segment.
        Returns a list of (substring, is_math) pairs where is_math indicates
        whether the substring should be rendered in the math font.
        (Narrow space) \u202f is treated as a zero-width separator between
        segments — it produces a gap of its configured width without being
        rendered.
        """
        if not self.text:
            return []
        segments = []
        current_text = ''
        current_is_math = None
        for char in self.text:
            if char == '\u202f':
                if current_text:
                    segments.append((current_text, current_is_math or False))
                segments.append(('\u202f', False))  # marker segment
                current_text = ''
                current_is_math = None
            else:
                is_math = char in self.config.math_chars
                if current_is_math is None:
                    current_is_math = is_math
                if is_math == current_is_math:
                    current_text += char
                else:
                    segments.append((current_text, current_is_math))
                    current_text = char
                    current_is_math = is_math
        if current_text:
            segments.append((current_text, current_is_math or False))
        return segments

    def width(self) -> float:
        total = 0.0
        for seg, is_math in self._segments():
            metrics = self._math if is_math else self._text
            total += metrics.string_width(seg)
        return total

    def height(self) -> float:
        # max of the two fonts
        return max(self._text.line_height, self._math.line_height)

    def above_axis(self) -> float:
        # Same convention as Text: math axis = math_axis above baseline.
        return max(self._text.ascent, self._math.ascent) \
            - self._text.math_axis

    def to_svg(self, x: float = 0.0, y: float = 0.0) -> str:
        segments = self._segments()
        if not segments:
            return ""

        font_weight = "bold" if self.bold else "normal"
        parts = []
        cursor_x = x

        for seg_text, is_math in segments:
            if seg_text == '\u202f':
                # no glyph, just move forward
                cursor_x += self.config.text_metrics.char_width('\u202f')
                continue
            metrics = self._math if is_math else self._text
            font_name = (self.config.math_font_name if is_math
                         else self.config.text_font_name)
            # All segments share the same baseline: math_axis below
            # the math axis.
            baseline_y = y + self._text.math_axis
            escaped = saxutils.escape(seg_text)
            parts.append(
                f'<text xml:space="preserve" '
                f'x="{cursor_x:.3f}" y="{baseline_y:.3f}" '
                f'font-family="{font_name}" '
                f'font-size="{metrics.font_size:.1f}" '
                f'font-weight="{font_weight}" '
                f'fill="{self.color or DEFAULT_COLOR}">'
                f'{escaped}'
                f'</text>'
            )
            cursor_x += metrics.string_width(seg_text)

        return "".join(parts)
