# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

import warnings
from pathlib import Path

from .font_metrics import FontMetrics

from automath.config import CONFIG

SRC_PATH = Path(__file__).parent.parent.parent.parent


class FontConfig:
    """
    Configuration shared by all MathNodes.
    """

    def __init__(
        self,
        # Text font (regular text, numbers, operators...)
        text_font_name: str = "", text_font_path: str = "",
        # Maths variables fonts (defined in automath.yaml) (x, y, z, ...)
        math_font_name: str = "", math_font_path: str = "",
        # Default size (pixels),
        font_size: float = 0,
        # Chars that must be displayed using math font
        math_chars: str = "",
    ):
        font_config = CONFIG["fonts"]
        if not font_size:
            font_size = font_config["size"]
        if not math_chars:
            math_chars = font_config["math_chars"]
        if not text_font_name:
            text_font_name = font_config["text_name"]
        if not text_font_path:
            text_font_path = font_config["text_path"]
        if not math_font_name:
            math_font_name = font_config["math_name"]
        if not math_font_path:
            math_font_path = font_config["math_path"]
        if (text_font_name == "Ubuntu"
           and not Path(str(text_font_path)).is_file()):
            text_font_path = SRC_PATH / "automath/fonts/Ubuntu-R.ttf"
        if (math_font_name == "lcmmi8mod"
           and not Path(str(math_font_path)).is_file()):
            math_font_path = SRC_PATH / "automath/fonts/lcmmi8mod.otf"
        if not text_font_path or not Path(str(text_font_path)).is_file():
            warnings.warn(f"Text font path not found (at: '{text_font_path}');"
                          f" falling back to default text font (Ubuntu).")
            text_font_path = SRC_PATH / "automath/fonts/Ubuntu-R.ttf"
        if not math_font_path or not Path(str(math_font_path)).is_file():
            warnings.warn(f"Math font path not found (at: '{math_font_path}');"
                          f" falling back to default math font (lcmmi8mod).")
            math_font_path = SRC_PATH / "automath/fonts/lcmmi8mod.otf"
        self.text_font_name = text_font_name
        self.text_font_path = text_font_path
        self.math_font_name = math_font_name
        self.math_font_path = math_font_path
        self.font_size = font_size
        self.math_chars = set(math_chars)

        # Load TTF metrics (once for one config)
        self._text_metrics = FontMetrics(text_font_path, font_size)
        self._math_metrics = FontMetrics(math_font_path, font_size)

    @property
    def text_metrics(self) -> "FontMetrics":
        return self._text_metrics

    @property
    def math_metrics(self) -> "FontMetrics":
        return self._math_metrics


DEFAULT_FONTCONFIG = FontConfig()
