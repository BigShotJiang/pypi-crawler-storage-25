# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

from fontTools.ttLib import TTFont

from automath.config_utils import load_config

NS_FALLBACK = load_config("automath")['fonts']['narrow_space_fallback_ratio']


class FontMetrics:
    """
    Read metrics from TTF or OTF file via fontTools.
    Compute glyphs widths matching a given size.
    """

    def __init__(self, font_path: str, font_size: float):
        self.font_path = font_path
        self.font_size = font_size
        self._font = TTFont(font_path)
        self._cmap = self._font.getBestCmap()
        self._hmtx = self._font["hmtx"].metrics
        self._units_per_em = self._font["head"].unitsPerEm

        os2 = self._font.get("OS/2")
        if os2:
            self.ascent = os2.sTypoAscender / self._units_per_em * font_size
            self.descent = -os2.sTypoDescender / self._units_per_em * font_size
            raw_x = getattr(os2, 'sxHeight', 0)
            self.x_height = (raw_x / self._units_per_em * font_size
                             if raw_x else self.ascent * 0.55)
        else:
            hhea = self._font["hhea"]
            self.ascent = hhea.ascent / self._units_per_em * font_size
            self.descent = -hhea.descent / self._units_per_em * font_size
            self.x_height = self.ascent * 0.55

        # Math axis = geometric centre of the '=' glyph, which is the true
        # optical centre for operators.
        # Falls back to x_height/2 if unavailable.
        glyf = self._font.get('glyf')
        cmap = self._font.getBestCmap()
        eq_name = cmap.get(ord('=')) if cmap else None
        if glyf and eq_name and eq_name in glyf:
            g = glyf[eq_name]
            g_y_mean = (g.yMin + g.yMax) / 2
            self.math_axis = g_y_mean / self._units_per_em * font_size
        else:
            self.math_axis = self.x_height / 2

        self.line_height = self.ascent + self.descent

    def char_width(self, char: str) -> float:
        codepoint = ord(char)
        glyph_name = self._cmap.get(codepoint)
        if glyph_name is None:
            if char == '\u202f':  # narrow no-break space
                space_glyph = self._cmap.get(ord(' '))
                if space_glyph is not None:
                    space_advance, _ = self._hmtx.get(
                        space_glyph, (self._units_per_em // 2, 0)
                    )
                    return (space_advance / self._units_per_em
                            * self.font_size) * NS_FALLBACK
                return self.font_size * 0.11
            return self.font_size * 0.5
        advance, _ = self._hmtx.get(glyph_name, (self._units_per_em // 2, 0))
        return advance / self._units_per_em * self.font_size

    def char_top(self, char: str) -> float:
        """Distance from baseline to the top of the glyph (yMax)."""
        glyf = self._font.get('glyf')
        cmap = self._font.getBestCmap()
        name = cmap.get(ord(char)) if cmap else None
        if glyf and name and name in glyf:
            return glyf[name].yMax / self._units_per_em * self.font_size
        return self.ascent  # fallback

    def string_width(self, text: str) -> float:
        return sum(self.char_width(c) for c in text)
