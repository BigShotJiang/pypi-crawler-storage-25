# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

from abc import ABC, abstractmethod


class Node(ABC):
    """
    Base node for all svg elements.

    Coordinates: x is left edge, y is math axis (visual center to align
    fractions, square roots, etc.).

    Each sub class must implement:
      - width()      → in pixels
      - height()     → total height (above + below baseline)
      - above_axis() → height above math axis
      - to_svg(x, y) → SVG bit located at (x, y)
    """

    _supported_options = set()
    color = None

    def apply_options(self, **options):
        for key, value in options.items():
            if key in self._supported_options:
                setattr(self, key, value)
            else:
                raise ValueError(f"Unsupported option {key!r} for "
                                 f"{self.__class__.__name__}")
        return self

    @abstractmethod
    def width(self) -> float: ...

    @abstractmethod
    def height(self) -> float: ...

    @abstractmethod
    def above_axis(self) -> float:
        """Height above math axis (fraction center, etc.)."""
        ...

    def below_axis(self) -> float:
        return self.height() - self.above_axis()

    @abstractmethod
    def to_svg(self, x: float = 0.0, y: float = 0.0) -> str:
        """
        Return SVG bit of that node.
        x: left edge
        y: math axis
        """
        ...

    def to_standalone_svg(self, tb_padding: float = 0.0,
                          lr_padding: float = 0.0) -> str:
        """
        Return a standalone <svg> element ready to insert inline in HTML.
        tb_padding: top/bottom padding in pixels (preserves vertical
                    alignment).
        lr_padding: left/right padding in pixels (default 0, no extra spacing).
        """
        w = self.width() + 2 * lr_padding
        h = self.height() + 2 * tb_padding
        axis = self.above_axis() + tb_padding
        inner = self.to_svg(x=lr_padding, y=axis)
        btb = round(self._baseline_to_bottom(tb_padding))
        va = -btb  # vertical-align value (positive = up, negative = down)
        return (
            f'<svg xmlns="http://www.w3.org/2000/svg" '
            f'width="{w:.2f}" height="{h:.2f}" '
            f'xml:space="preserve" '
            f'style="vertical-align: {va:.2f}px; overflow: visible;">'
            f'{inner}'
            f'</svg>'
        )

    def _baseline_to_bottom(self, tb_padding: float) -> float:
        """
        Distance (px) from the text baseline to the bottom of the SVG.
        Determines vertical-align for alignment with surrounding HTML text.

        Universal formula (valid for Text, MathText, Fraction, Row):
          baseline_to_bottom = below_axis() + padding - math_axis

        Derivation:
          The math axis is defined as math_axis above the text baseline.
          In the SVG, the math axis is at y = above_axis() + tb_padding.
          Text baseline = y + math_axis = above_axis() + tb_padding + math_axis
          SVG height h  = height() + 2·tb_padding
          distance      = h - baseline_y
                        = below_axis() + tb_padding - math_axis

        Subclasses must override config so that config.text_metrics is
        available.
        """
        return self.below_axis() + tb_padding \
            - self.config.text_metrics.math_axis
