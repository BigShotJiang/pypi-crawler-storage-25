"""CSV reporter — generates a CSV file of scan findings."""

from __future__ import annotations

import csv
import io

from guard.core.models import Finding
from guard.reporters.base import Reporter


class CsvReporter(Reporter):
    @property
    def extension(self) -> str:
        return ".csv"

    def render(self, findings: list[Finding]) -> str:
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow([
            "finding_id", "rule_id", "severity", "file", "lines",
            "message", "suggestion", "confidence", "standard",
            "clause", "is_obligation",
        ])
        for f in findings:
            lines_str = ";".join(str(ln) for ln in f.evidence.lines) if f.evidence.lines else ""
            writer.writerow([
                f.finding_id,
                f.rule_id,
                f.severity.value,
                f.evidence.file,
                lines_str,
                f.message,
                f.suggestion or "",
                f"{f.confidence:.0%}" if f.confidence is not None else "",
                f.standard or "",
                f.clause or "",
                str(f.is_obligation).lower(),
            ])
        return output.getvalue()
