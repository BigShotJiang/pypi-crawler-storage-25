"""Reporter plugins for generating output in various formats."""
