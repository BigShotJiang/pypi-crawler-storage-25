"""Trust center page generator.

Produces a public-safe static HTML page showing compliance posture
without exposing specific findings, file paths, or code snippets.
Designed for sharing with customers, auditors, or embedding on a
company website.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
from html import escape

from guard import __version__
from guard.core.models import Finding


_SEVERITY_COLORS: dict[str, str] = {
    "critical": "#d32f2f",
    "high": "#f57c00",
    "medium": "#fbc02d",
    "low": "#1976d2",
    "info": "#757575",
}

_STATUS_COLORS = {
    "healthy": "#4caf50",
    "needs_attention": "#fbc02d",
    "at_risk": "#d32f2f",
}


def _compute_framework_scores(
    findings: list[Finding],
) -> list[dict]:
    """Compute per-framework compliance scores.

    Returns a list of dicts with keys: name, score, rules_passed,
    rules_total, severity_counts.
    """
    # Group findings by framework
    by_framework: dict[str, list[Finding]] = defaultdict(list)
    for f in findings:
        if f.standard:
            by_framework[f.standard].append(f)

    results = []
    for fw_name in sorted(by_framework):
        fw_findings = by_framework[fw_name]
        code_findings = [f for f in fw_findings if not f.is_obligation]

        # Unique rule IDs in this framework
        all_rule_ids = {f.rule_id for f in fw_findings}
        failed_rule_ids = {f.rule_id for f in code_findings}
        rules_total = len(all_rule_ids) or 1
        rules_passed = rules_total - len(failed_rule_ids)
        score = round((rules_passed / rules_total) * 100, 1)

        # Severity counts (code findings only)
        sev_counts: dict[str, int] = defaultdict(int)
        for f in code_findings:
            sev_counts[f.severity.value] += 1

        results.append({
            "name": fw_name,
            "score": score,
            "rules_passed": rules_passed,
            "rules_total": rules_total,
            "severity_counts": dict(sev_counts),
            "obligations": sum(1 for f in fw_findings if f.is_obligation),
        })

    return results


def _overall_status(score: float) -> tuple[str, str, str]:
    """Return (status_label, status_color, status_icon) based on score."""
    if score >= 90:
        return "Healthy", _STATUS_COLORS["healthy"], "&#x2714;"  # checkmark
    elif score >= 70:
        return "Needs Attention", _STATUS_COLORS["needs_attention"], "&#x26A0;"  # warning
    else:
        return "At Risk", _STATUS_COLORS["at_risk"], "&#x2718;"  # cross


def generate_trust_center(
    findings: list[Finding],
    *,
    rules_total: int | None = None,
    org_name: str | None = None,
    scan_timestamp: str | None = None,
) -> str:
    """Generate a public-safe trust center HTML page.

    Args:
        findings: List of findings from the last scan.
        rules_total: Total number of rules evaluated (from scan_metrics).
        org_name: Optional organization name for the header.
        scan_timestamp: ISO timestamp of the scan. Defaults to now.

    Returns:
        Standalone HTML string.
    """
    now = scan_timestamp or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    display_name = escape(org_name) if org_name else "Project"

    # Overall compliance score
    code_findings = [f for f in findings if not f.is_obligation and f.standard]
    all_findings_with_std = [f for f in findings if f.standard]

    all_rule_ids = {f.rule_id for f in all_findings_with_std}
    failed_rule_ids = {f.rule_id for f in code_findings}

    if rules_total is None:
        rules_total = len(all_rule_ids) or 1

    rules_passed = rules_total - len(failed_rule_ids)
    overall_score = round((rules_passed / rules_total) * 100, 1)
    status_label, status_color, status_icon = _overall_status(overall_score)

    # Per-framework scores
    fw_scores = _compute_framework_scores(findings)

    # Overall severity distribution (code findings only, all frameworks)
    all_code = [f for f in findings if not f.is_obligation]
    sev_totals: dict[str, int] = defaultdict(int)
    for f in all_code:
        sev_totals[f.severity.value] += 1

    # Build HTML
    framework_cards = ""
    for fw in fw_scores:
        fw_status_label, fw_status_color, _ = _overall_status(fw["score"])
        sev_badges = ""
        for sev in ("critical", "high", "medium", "low", "info"):
            count = fw["severity_counts"].get(sev, 0)
            if count > 0:
                sev_badges += (
                    f'<span class="sev-badge" style="background:{_SEVERITY_COLORS[sev]}">'
                    f'{sev}: {count}</span> '
                )
        if not sev_badges:
            sev_badges = '<span class="sev-badge" style="background:#4caf50">No code findings</span>'

        obligation_note = ""
        if fw["obligations"] > 0:
            obligation_note = f'<div class="fw-obligations">{fw["obligations"]} documentation obligation(s)</div>'

        framework_cards += f"""
        <div class="fw-card">
            <div class="fw-header">
                <h3>{escape(fw["name"])}</h3>
                <span class="fw-status" style="color:{fw_status_color}">{fw_status_label}</span>
            </div>
            <div class="fw-score-bar">
                <div class="fw-score-fill" style="width:{fw['score']}%;background:{fw_status_color}"></div>
            </div>
            <div class="fw-details">
                <span class="fw-score-text">{fw['score']}% — {fw['rules_passed']}/{fw['rules_total']} rules passing</span>
            </div>
            <div class="fw-severities">{sev_badges}</div>
            {obligation_note}
        </div>
        """

    # Severity summary row
    sev_summary = ""
    for sev in ("critical", "high", "medium", "low", "info"):
        count = sev_totals.get(sev, 0)
        sev_summary += f"""
        <div class="sev-card">
            <div class="sev-count" style="color:{_SEVERITY_COLORS[sev]}">{count}</div>
            <div class="sev-label">{sev.capitalize()}</div>
        </div>
        """

    score_color = status_color

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{display_name} — Trust Center</title>
<style>
    :root {{
        --bg: #0f0e17;
        --surface: #1a1a2e;
        --border: #2a2a40;
        --text: #e0e0e0;
        --text-muted: #999;
        --primary: #7c3aed;
        --primary-light: #a78bfa;
    }}
    @media (prefers-color-scheme: light) {{
        :root {{
            --bg: #f8f9fa;
            --surface: #ffffff;
            --border: #dee2e6;
            --text: #212529;
            --text-muted: #6c757d;
        }}
    }}
    * {{ margin: 0; padding: 0; box-sizing: border-box; }}
    body {{
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        background: var(--bg);
        color: var(--text);
        line-height: 1.6;
    }}
    .container {{ max-width: 900px; margin: 0 auto; padding: 0 1.5rem; }}

    /* Header */
    .tc-header {{
        text-align: center;
        padding: 3rem 0 2rem;
        border-bottom: 1px solid var(--border);
    }}
    .tc-header h1 {{ font-size: 2rem; margin-bottom: 0.5rem; }}
    .tc-header .tc-sub {{ color: var(--text-muted); }}
    .tc-header .tc-updated {{
        color: var(--text-muted);
        font-size: 0.85rem;
        margin-top: 1rem;
    }}

    /* Overall status */
    .status-hero {{
        text-align: center;
        padding: 2.5rem 0;
    }}
    .status-icon {{
        font-size: 3rem;
        margin-bottom: 0.5rem;
    }}
    .status-label {{
        font-size: 1.3rem;
        font-weight: 700;
        margin-bottom: 0.25rem;
    }}
    .score-big {{
        font-size: 4rem;
        font-weight: 800;
        line-height: 1;
        margin-bottom: 0.25rem;
    }}
    .score-detail {{
        color: var(--text-muted);
        font-size: 0.95rem;
    }}

    /* Severity summary */
    .sev-row {{
        display: flex;
        justify-content: center;
        gap: 1.5rem;
        padding: 1.5rem 0;
        border-top: 1px solid var(--border);
        border-bottom: 1px solid var(--border);
    }}
    .sev-card {{ text-align: center; min-width: 70px; }}
    .sev-count {{ font-size: 1.8rem; font-weight: 700; }}
    .sev-label {{ font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase; }}

    /* Framework cards */
    .fw-section {{ padding: 2rem 0; }}
    .fw-section h2 {{
        font-size: 1.3rem;
        margin-bottom: 1.5rem;
        color: var(--primary-light);
    }}
    .fw-grid {{
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
        gap: 1rem;
    }}
    .fw-card {{
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 10px;
        padding: 1.25rem;
    }}
    .fw-header {{
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.75rem;
    }}
    .fw-header h3 {{ font-size: 1.05rem; }}
    .fw-status {{ font-size: 0.85rem; font-weight: 600; }}
    .fw-score-bar {{
        height: 6px;
        background: var(--border);
        border-radius: 3px;
        overflow: hidden;
        margin-bottom: 0.5rem;
    }}
    .fw-score-fill {{
        height: 100%;
        border-radius: 3px;
        transition: width 0.3s;
    }}
    .fw-details {{ margin-bottom: 0.5rem; }}
    .fw-score-text {{ font-size: 0.85rem; color: var(--text-muted); }}
    .fw-severities {{ display: flex; flex-wrap: wrap; gap: 0.4rem; }}
    .sev-badge {{
        display: inline-block;
        padding: 0.15rem 0.5rem;
        border-radius: 4px;
        font-size: 0.75rem;
        color: #fff;
        font-weight: 600;
    }}
    .fw-obligations {{
        margin-top: 0.5rem;
        font-size: 0.8rem;
        color: var(--text-muted);
        font-style: italic;
    }}

    /* Footer */
    .tc-footer {{
        text-align: center;
        padding: 2rem 0;
        border-top: 1px solid var(--border);
        color: var(--text-muted);
        font-size: 0.8rem;
    }}
    .tc-footer a {{ color: var(--primary-light); text-decoration: none; }}

    /* No frameworks fallback */
    .no-frameworks {{
        text-align: center;
        padding: 2rem;
        color: var(--text-muted);
        font-style: italic;
    }}

    @media print {{
        body {{ background: #fff; color: #000; }}
        .fw-card {{ border-color: #ccc; }}
    }}
    @media (max-width: 480px) {{
        .fw-grid {{ grid-template-columns: 1fr; }}
        .sev-row {{ flex-wrap: wrap; }}
        .score-big {{ font-size: 3rem; }}
    }}
</style>
</head>
<body>
<div class="container">

<div class="tc-header">
    <h1>{display_name} Trust Center</h1>
    <p class="tc-sub">Automated compliance posture powered by Sentrik</p>
    <p class="tc-updated">Last updated: {escape(now[:19].replace('T', ' '))} UTC</p>
</div>

<div class="status-hero">
    <div class="status-icon" style="color:{status_color}">{status_icon}</div>
    <div class="status-label" style="color:{status_color}">{status_label}</div>
    <div class="score-big" style="color:{score_color}">{overall_score}%</div>
    <div class="score-detail">{rules_passed} of {rules_total} rules passing</div>
</div>

<div class="sev-row">
    {sev_summary}
</div>

<div class="fw-section">
    <h2>Standards &amp; Frameworks</h2>
    {"" if fw_scores else '<p class="no-frameworks">No standards frameworks detected. Enable standards packs to see framework-level compliance.</p>'}
    <div class="fw-grid">
        {framework_cards}
    </div>
</div>

<div class="tc-footer">
    Generated by <a href="https://sentrik.dev">Sentrik</a> v{__version__} &mdash;
    This page contains no source code, file paths, or finding details.
</div>

</div>
</body>
</html>"""

    return html


def generate_trust_center_json(
    findings: list[Finding],
    *,
    rules_total: int | None = None,
    org_name: str | None = None,
    scan_timestamp: str | None = None,
) -> dict:
    """Return trust center data as a JSON-serializable dict.

    This is the machine-readable counterpart to the HTML page, useful for
    API responses or embedding in other systems.
    """
    now = scan_timestamp or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    code_findings = [f for f in findings if not f.is_obligation and f.standard]
    all_findings_with_std = [f for f in findings if f.standard]

    all_rule_ids = {f.rule_id for f in all_findings_with_std}
    failed_rule_ids = {f.rule_id for f in code_findings}

    if rules_total is None:
        rules_total = len(all_rule_ids) or 1

    rules_passed = rules_total - len(failed_rule_ids)
    overall_score = round((rules_passed / rules_total) * 100, 1)

    status_label, _, _ = _overall_status(overall_score)

    all_code = [f for f in findings if not f.is_obligation]
    sev_totals: dict[str, int] = defaultdict(int)
    for f in all_code:
        sev_totals[f.severity.value] += 1

    fw_scores = _compute_framework_scores(findings)

    return {
        "org_name": org_name,
        "timestamp": now,
        "overall": {
            "score": overall_score,
            "status": status_label.lower().replace(" ", "_"),
            "rules_passed": rules_passed,
            "rules_total": rules_total,
        },
        "severity_summary": {
            sev: sev_totals.get(sev, 0)
            for sev in ("critical", "high", "medium", "low", "info")
        },
        "frameworks": [
            {
                "name": fw["name"],
                "score": fw["score"],
                "rules_passed": fw["rules_passed"],
                "rules_total": fw["rules_total"],
                "severity_counts": fw["severity_counts"],
                "obligations": fw["obligations"],
            }
            for fw in fw_scores
        ],
        "sentrik_version": __version__,
    }
