"""Abstract base class for report format plugins."""

from __future__ import annotations

from abc import ABC, abstractmethod

from guard.core.models import Finding


class Reporter(ABC):
    """Render a list of findings into a specific output format."""

    @abstractmethod
    def render(self, findings: list[Finding]) -> str:
        """Return the formatted report as a string."""
        ...

    @property
    @abstractmethod
    def extension(self) -> str:
        """File extension for the report (e.g. ``'.html'``)."""
        ...
