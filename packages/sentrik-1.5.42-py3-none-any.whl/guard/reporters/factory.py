"""Reporter factory — builds reporter instances by name."""

from __future__ import annotations

import logging

from guard.reporters.base import Reporter

logger = logging.getLogger(__name__)

_REGISTRY: dict[str, type[Reporter]] = {}


def register(name: str, cls: type[Reporter]) -> None:
    """Register a reporter class under *name*."""
    _REGISTRY[name] = cls


def get_reporter(name: str) -> Reporter | None:
    """Instantiate a reporter by name, or ``None`` if unknown."""
    cls = _REGISTRY.get(name)
    if cls is None:
        logger.warning("Unknown reporter %r — skipped", name)
        return None
    return cls()


def available_reporters() -> list[str]:
    """Return the names of all registered reporters."""
    return sorted(_REGISTRY)


def build_reporters(names: list[str]) -> list[Reporter]:
    """Build a list of reporters from config names, skipping unknowns."""
    reporters: list[Reporter] = []
    for name in names:
        r = get_reporter(name)
        if r is not None:
            reporters.append(r)
    return reporters


# ------------------------------------------------------------------
# Auto-register built-in reporters on import
# ------------------------------------------------------------------

def _register_builtins() -> None:
    from guard.reporters.csv_reporter import CsvReporter
    from guard.reporters.html import HtmlReporter
    from guard.reporters.junit import JUnitReporter
    from guard.reporters.sarif_output import SarifOutputReporter

    register("csv", CsvReporter)
    register("html", HtmlReporter)
    register("junit", JUnitReporter)
    register("sarif", SarifOutputReporter)


_register_builtins()
