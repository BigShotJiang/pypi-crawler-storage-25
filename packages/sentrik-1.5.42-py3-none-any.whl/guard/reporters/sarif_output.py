"""SARIF output reporter — exports findings as SARIF v2.1.0 JSON.

This enables chaining Guard's output into other SARIF-aware tools and
uploading results to GitHub Code Scanning, Azure DevOps, etc.
"""

from __future__ import annotations

import json

from guard import __version__
from guard.core.models import Finding, Severity
from guard.reporters.base import Reporter

_SEVERITY_TO_LEVEL: dict[Severity, str] = {
    Severity.CRITICAL: "error",
    Severity.HIGH: "error",
    Severity.MEDIUM: "warning",
    Severity.LOW: "note",
    Severity.INFO: "none",
}


class SarifOutputReporter(Reporter):
    """Render findings as a SARIF v2.1.0 JSON document."""

    @property
    def extension(self) -> str:
        return ".sarif.json"

    def render(self, findings: list[Finding]) -> str:
        results = [self._convert_finding(f) for f in findings]
        rule_ids = sorted({f.rule_id for f in findings})
        rules = [{"id": rid} for rid in rule_ids]

        sarif = {
            "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/Schemata/sarif-schema-2.1.0.json",
            "version": "2.1.0",
            "runs": [
                {
                    "tool": {
                        "driver": {
                            "name": "ai-sdlc-guard",
                            "version": __version__,
                            "rules": rules,
                        }
                    },
                    "results": results,
                }
            ],
        }
        return json.dumps(sarif, indent=2)

    @staticmethod
    def _convert_finding(f: Finding) -> dict:
        level = _SEVERITY_TO_LEVEL.get(f.severity, "warning")

        location: dict = {
            "physicalLocation": {
                "artifactLocation": {"uri": f.evidence.file},
            }
        }

        region: dict = {}
        if f.evidence.lines:
            region["startLine"] = f.evidence.lines[0]
        if f.evidence.snippet:
            region["snippet"] = {"text": f.evidence.snippet}
        if region:
            location["physicalLocation"]["region"] = region

        result: dict = {
            "ruleId": f.rule_id,
            "level": level,
            "message": {"text": f.message},
            "locations": [location],
        }

        if f.suggestion:
            result["fixes"] = [
                {
                    "description": {"text": f.suggestion},
                }
            ]

        return result
