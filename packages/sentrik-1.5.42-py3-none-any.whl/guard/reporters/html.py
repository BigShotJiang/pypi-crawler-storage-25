"""HTML reporter — generates a standalone styled HTML report."""

from __future__ import annotations

import math
from collections import defaultdict
from datetime import datetime, timezone
from html import escape

from guard import __version__
from guard.core.models import Finding, Severity
from guard.reporters.base import Reporter

_SEVERITY_COLORS: dict[str, str] = {
    "critical": "#d32f2f",
    "high": "#f57c00",
    "medium": "#fbc02d",
    "low": "#1976d2",
    "info": "#757575",
}

_SEVERITY_ORDER = [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]


class HtmlReporter(Reporter):
    @property
    def extension(self) -> str:
        return ".html"

    def render(self, findings: list[Finding]) -> str:
        code_findings = [f for f in findings if not f.is_obligation]
        obligations = [f for f in findings if f.is_obligation]

        counts = {s: 0 for s in Severity}
        for f in code_findings:
            counts[f.severity] += 1

        summary_items = "".join(
            f'<span class="badge" style="background:{_SEVERITY_COLORS[s.value]}">'
            f"{s.value.upper()}: {counts[s]}</span> "
            for s in _SEVERITY_ORDER
            if counts[s] > 0
        )

        # Executive summary with severity donut
        donut_svg = self._render_donut(counts) if code_findings else ""
        filter_buttons = self._render_filter_buttons(counts) if code_findings else ""
        compliance_html = self._render_compliance_score(code_findings)

        if not code_findings and not obligations:
            body = "<p>No findings detected. All checks passed.</p>"
        else:
            body = ""
            if code_findings:
                body += self._render_findings(code_findings)
            if obligations:
                body += self._render_obligations(obligations)

        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        return _TEMPLATE.format(
            title="Guard Scan Report",
            summary=summary_items or "No findings",
            total=len(code_findings),
            body=body,
            donut=donut_svg,
            compliance=compliance_html,
            filters=filter_buttons,
            version=__version__,
            timestamp=timestamp,
        )

    @staticmethod
    def _render_donut(counts: dict[Severity, int]) -> str:
        total = sum(counts.values())
        if total == 0:
            return ""
        r, cx, cy = 40, 60, 60
        circumference = 2 * math.pi * r
        paths = []
        offset = 0
        for sev in _SEVERITY_ORDER:
            n = counts.get(sev, 0)
            if n == 0:
                continue
            pct = n / total
            dash = pct * circumference
            gap = circumference - dash
            color = _SEVERITY_COLORS[sev.value]
            paths.append(
                f'<circle r="{r}" cx="{cx}" cy="{cy}" fill="transparent" '
                f'stroke="{color}" stroke-width="16" '
                f'stroke-dasharray="{dash:.1f} {gap:.1f}" '
                f'stroke-dashoffset="{-offset:.1f}" />'
            )
            offset += dash
        return (
            f'<div class="donut">'
            f'<svg viewBox="0 0 120 120" width="120" height="120">'
            f'{"".join(paths)}'
            f'<text x="{cx}" y="{cy}" text-anchor="middle" dominant-baseline="central" '
            f'font-size="18" font-weight="700" fill="var(--text-color)">{total}</text>'
            f'</svg></div>'
        )

    @staticmethod
    def _render_filter_buttons(counts: dict[Severity, int]) -> str:
        buttons = []
        for sev in _SEVERITY_ORDER:
            n = counts.get(sev, 0)
            if n == 0:
                continue
            color = _SEVERITY_COLORS[sev.value]
            buttons.append(
                f'<button class="filter-btn active" data-sev="{sev.value}" '
                f'onclick="toggleFilter(this)" '
                f'style="background:{color};color:#fff">'
                f'{sev.value.upper()} ({n})</button>'
            )
        return '<div class="filter-bar">' + " ".join(buttons) + '</div>'

    @staticmethod
    def _render_compliance_score(code_findings: list[Finding]) -> str:
        """Render a compliance score box next to the donut chart.

        Reads the score from ``out/scan_metrics.json`` (written by the
        pipeline).  Falls back to showing only the rules-with-findings
        count when the metrics file is unavailable.
        """
        import json as _json
        from pathlib import Path as _Path

        score_data: dict | None = None
        for candidate in (_Path("out/scan_metrics.json"), _Path("scan_metrics.json")):
            if candidate.exists():
                try:
                    data = _json.loads(candidate.read_text(encoding="utf-8"))
                    if "compliance_score" in data:
                        score_data = data["compliance_score"]
                        break
                except (OSError, _json.JSONDecodeError, KeyError):
                    pass

        if score_data is None:
            # Derive a partial view: count distinct failed rule IDs
            failed_ids = {f.rule_id for f in code_findings}
            rules_failed = len(failed_ids)
            return (
                f'<div class="compliance-score">'
                f'<div style="font-size:1.4rem;font-weight:700;color:var(--text-color)">'
                f'{rules_failed} rule{"s" if rules_failed != 1 else ""} with findings</div>'
                f'</div>'
            )

        sc = score_data.get("score", 100.0)
        passed = score_data.get("rules_passed", 0)
        total = score_data.get("rules_total", 0)
        failed = score_data.get("rules_failed", 0)
        color = "#4caf50" if sc >= 90 else "#fbc02d" if sc >= 70 else "#d32f2f"

        return (
            f'<div class="compliance-score" style="text-align:center;min-width:120px">'
            f'<div style="font-size:2rem;font-weight:700;color:{color}">{sc}%</div>'
            f'<div style="font-size:0.85rem;color:var(--text-color);opacity:0.8">'
            f'{passed} of {total} rules passed</div>'
            f'<div style="font-size:0.75rem;color:var(--text-color);opacity:0.6">'
            f'{failed} failed</div>'
            f'</div>'
        )

    def _render_findings(self, findings: list[Finding]) -> str:
        sections: list[str] = []
        for sev in _SEVERITY_ORDER:
            sev_findings = [f for f in findings if f.severity == sev]
            if not sev_findings:
                continue
            color = _SEVERITY_COLORS[sev.value]
            rows = "".join(self._render_row(f) for f in sev_findings)
            sections.append(
                f'<div class="sev-section" data-sev="{sev.value}">'
                f'<h2 style="color:{color}">{sev.value.upper()} ({len(sev_findings)})</h2>\n'
                f"<table><thead><tr>"
                f"<th class=\"sortable\" onclick=\"sortTable(this,0)\">ID</th>"
                f"<th class=\"sortable\" onclick=\"sortTable(this,1)\">Rule</th>"
                f"<th class=\"sortable\" onclick=\"sortTable(this,2)\">File</th>"
                f"<th>Line</th>"
                f"<th>Message</th><th>Confidence</th>"
                f"</tr></thead><tbody>{rows}</tbody></table></div>"
            )
        return "\n".join(sections)

    def _render_obligations(self, obligations: list[Finding]) -> str:
        by_standard: dict[str, list[Finding]] = defaultdict(list)
        for o in obligations:
            key = o.standard or "General"
            by_standard[key].append(o)

        sections = ['<h2>Compliance Obligations</h2>']
        for std_name, items in by_standard.items():
            sections.append(f"<h3>{escape(std_name)}</h3>")
            rows = "".join(self._render_obligation_row(o) for o in items)
            sections.append(
                "<table><thead><tr>"
                "<th>Rule ID</th><th>Clause</th><th>Message</th><th>Remediation</th>"
                "</tr></thead><tbody>" + rows + "</tbody></table>"
            )
        return "\n".join(sections)

    @staticmethod
    def _render_row(f: Finding) -> str:
        lines_str = ", ".join(str(ln) for ln in f.evidence.lines) if f.evidence.lines else "-"
        det = "deterministic" if f.deterministic else "heuristic"
        msg = escape(f.message)
        if f.standard and f.clause:
            msg = f"<strong>{escape(f.standard)} {escape(f.clause)}</strong><br>" + msg
        if f.suggestion:
            msg += f"<br><em>{escape(f.suggestion)}</em>"
        return (
            f'<tr class="expandable-row" onclick="this.nextElementSibling.classList.toggle(\'open\')">'
            f"<td><code>{escape(f.finding_id)}</code></td>"
            f"<td><code>{escape(f.rule_id)}</code></td>"
            f"<td><code>{escape(f.evidence.file)}</code></td>"
            f"<td>{lines_str}</td>"
            f"<td>{msg}</td>"
            f"<td>{f.confidence:.0%} ({det})</td>"
            f"</tr>"
            f'<tr class="detail-row"><td colspan="6"><div class="detail-content">'
            f"<strong>Finding ID:</strong> {escape(f.finding_id)}<br>"
            f"<strong>Deterministic:</strong> {det}<br>"
            + (f"<strong>Standard:</strong> {escape(f.standard or '')}<br>" if f.standard else "")
            + f"</div></td></tr>"
        )

    @staticmethod
    def _render_obligation_row(o: Finding) -> str:
        clause = escape(o.clause) if o.clause else "-"
        msg = escape(o.message)
        remediation = escape(o.remediation_guidance) if o.remediation_guidance else "-"
        return (
            f"<tr>"
            f"<td><code>{escape(o.rule_id)}</code></td>"
            f"<td>{clause}</td>"
            f"<td>{msg}</td>"
            f"<td>{remediation}</td>"
            f"</tr>"
        )


_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{title}</title>
<style>
  :root {{ --text-color: #333; --bg-color: #fff; --border-color: #eee;
           --code-bg: #f0f0f0; --th-bg: #f5f5f5; }}
  @media (prefers-color-scheme: dark) {{
    :root {{ --text-color: #e2e8f0; --bg-color: #0f172a; --border-color: #334155;
             --code-bg: #1e293b; --th-bg: #1e293b; }}
  }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
         max-width: 960px; margin: 2rem auto; padding: 0 1rem; color: var(--text-color);
         background: var(--bg-color); }}
  h1 {{ border-bottom: 2px solid var(--border-color); padding-bottom: .5rem; }}
  .badge {{ display: inline-block; padding: 4px 10px; border-radius: 4px;
            color: #fff; font-weight: 600; font-size: 0.85rem; }}
  .executive-summary {{ display: flex; align-items: center; gap: 24px; margin: 1rem 0; }}
  .donut {{ flex-shrink: 0; }}
  .filter-bar {{ display: flex; gap: 8px; flex-wrap: wrap; margin: 1rem 0; }}
  .filter-btn {{ border: none; padding: 6px 14px; border-radius: 6px; cursor: pointer;
                 font-size: 0.8rem; font-weight: 600; opacity: 1; transition: opacity 0.2s; }}
  .filter-btn:not(.active) {{ opacity: 0.3; }}
  table {{ width: 100%; border-collapse: collapse; margin: 1rem 0; }}
  th, td {{ text-align: left; padding: 8px 12px; border-bottom: 1px solid var(--border-color); }}
  th {{ background: var(--th-bg); }}
  .sortable {{ cursor: pointer; user-select: none; }}
  .sortable:hover {{ text-decoration: underline; }}
  code {{ background: var(--code-bg); padding: 2px 4px; border-radius: 3px; font-size: 0.85em; }}
  em {{ color: #666; }}
  .expandable-row {{ cursor: pointer; }}
  .expandable-row:hover {{ background: var(--code-bg); }}
  .detail-row {{ display: none; }}
  .detail-row.open {{ display: table-row; }}
  .detail-content {{ padding: 8px; font-size: 0.85rem; color: var(--text-color); opacity: 0.8; }}
  .search-box {{ margin: 1rem 0; }}
  .search-box input {{ width: 100%; padding: 8px 12px; border: 1px solid var(--border-color);
                       border-radius: 6px; font-size: 0.9rem; background: var(--bg-color);
                       color: var(--text-color); }}
  .footer {{ margin-top: 2rem; padding-top: 1rem; border-top: 1px solid var(--border-color);
             font-size: 0.75rem; color: #999; }}
  @media print {{
    .filter-bar, .search-box {{ display: none; }}
    body {{ color: #000; background: #fff; }}
    .detail-row.open {{ display: table-row; }}
  }}
</style>
</head>
<body>
<h1>{title}</h1>
<div class="executive-summary">
  {donut}
  {compliance}
  <div><p><strong>Total findings:</strong> {total}</p><p>{summary}</p></div>
</div>
{filters}
<div class="search-box"><input type="text" placeholder="Filter findings..." oninput="filterFindings(this.value)"></div>
{body}
<div class="footer">Guard v{version} | {timestamp}</div>
<script>
function toggleFilter(btn) {{
  btn.classList.toggle('active');
  var sev = btn.dataset.sev;
  var sections = document.querySelectorAll('.sev-section[data-sev="'+sev+'"]');
  sections.forEach(function(s) {{ s.style.display = btn.classList.contains('active') ? '' : 'none'; }});
}}
function filterFindings(q) {{
  q = q.toLowerCase();
  document.querySelectorAll('tbody tr.expandable-row').forEach(function(row) {{
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    if (row.nextElementSibling && row.nextElementSibling.classList.contains('detail-row'))
      row.nextElementSibling.style.display = 'none';
  }});
}}
function sortTable(th, col) {{
  var table = th.closest('table');
  var tbody = table.querySelector('tbody');
  var rows = Array.from(tbody.querySelectorAll('tr.expandable-row'));
  var asc = th.dataset.asc !== 'true';
  th.dataset.asc = asc;
  rows.sort(function(a, b) {{
    var va = a.cells[col].textContent;
    var vb = b.cells[col].textContent;
    return asc ? va.localeCompare(vb) : vb.localeCompare(va);
  }});
  rows.forEach(function(row) {{
    var detail = row.nextElementSibling;
    tbody.appendChild(row);
    if (detail && detail.classList.contains('detail-row')) tbody.appendChild(detail);
  }});
}}
</script>
</body>
</html>
"""
