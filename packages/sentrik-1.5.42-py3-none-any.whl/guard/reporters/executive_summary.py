"""Executive risk summary — one-page HTML report for stakeholders."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def generate_executive_summary(
    findings: list[dict[str, Any]],
    metrics: dict[str, Any] | None = None,
    compliance_score: dict[str, Any] | None = None,
    org_name: str = "",
    packs_enabled: list[str] | None = None,
) -> str:
    """Generate a one-page HTML executive risk summary."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    # Severity counts
    sev_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    for f in findings:
        s = f.get("severity", "info")
        sev_counts[s] = sev_counts.get(s, 0) + 1
    total = len(findings)
    blocking = sev_counts["critical"] + sev_counts["high"]

    # Traffic light
    if sev_counts["critical"] > 0:
        status_color = "#ef4444"
        status_label = "CRITICAL"
        status_desc = f"{sev_counts['critical']} critical finding(s) require immediate action"
    elif sev_counts["high"] > 0:
        status_color = "#f59e0b"
        status_label = "AT RISK"
        status_desc = f"{sev_counts['high']} high-severity finding(s) need resolution"
    elif total > 0:
        status_color = "#eab308"
        status_label = "MONITOR"
        status_desc = f"{total} finding(s) — no critical or high severity"
    else:
        status_color = "#10b981"
        status_label = "CLEAR"
        status_desc = "No compliance findings detected"

    # Compliance score
    score_pct = ""
    if compliance_score:
        score_pct = f"{compliance_score.get('score', 0)}%"
        rules_passed = compliance_score.get("rules_passed", 0)
        rules_total = compliance_score.get("rules_total", 0)

    # Top rules
    rule_counts: dict[str, int] = {}
    for f in findings:
        rid = f.get("rule_id", "unknown")
        rule_counts[rid] = rule_counts.get(rid, 0) + 1
    top_rules = sorted(rule_counts.items(), key=lambda x: -x[1])[:5]

    # Top files
    file_counts: dict[str, int] = {}
    for f in findings:
        fp = f.get("evidence", {}).get("file", "")
        if fp and fp != "<project>":
            file_counts[fp] = file_counts.get(fp, 0) + 1
    top_files = sorted(file_counts.items(), key=lambda x: -x[1])[:5]

    # Packs
    packs_html = ""
    if packs_enabled:
        packs_html = ", ".join(packs_enabled)

    # Duration
    duration = ""
    if metrics:
        ms = metrics.get("total_duration_ms", 0)
        duration = f"{ms/1000:.1f}s"
        files_scanned = metrics.get("files_scanned", 0)

    header = f"<h1>{org_name + ' — ' if org_name else ''}Compliance Risk Summary</h1>"

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Executive Risk Summary{' — ' + org_name if org_name else ''}</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif; background: #0f0b1a; color: #e8e4f0; padding: 2rem; max-width: 900px; margin: 0 auto; }}
  h1 {{ font-size: 1.5rem; margin-bottom: 0.25rem; }}
  .date {{ color: #9e96b0; font-size: 0.85rem; margin-bottom: 2rem; }}
  .status {{ display: flex; align-items: center; gap: 1rem; padding: 1.5rem; border-radius: 12px; background: #1a1428; margin-bottom: 1.5rem; }}
  .status-light {{ width: 48px; height: 48px; border-radius: 50%; flex-shrink: 0; }}
  .status-label {{ font-size: 1.3rem; font-weight: 700; }}
  .status-desc {{ color: #9e96b0; font-size: 0.9rem; }}
  .grid {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-bottom: 1.5rem; }}
  .card {{ background: #1a1428; border-radius: 10px; padding: 1.25rem; }}
  .card h3 {{ font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: #9e96b0; margin-bottom: 0.5rem; }}
  .card .value {{ font-size: 1.8rem; font-weight: 700; }}
  .sev-critical {{ color: #ef4444; }}
  .sev-high {{ color: #f97316; }}
  .sev-medium {{ color: #eab308; }}
  .sev-low {{ color: #3b82f6; }}
  .sev-info {{ color: #9e96b0; }}
  .section {{ margin-bottom: 1.5rem; }}
  .section h2 {{ font-size: 1rem; margin-bottom: 0.75rem; border-bottom: 1px solid #362e4a; padding-bottom: 0.5rem; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 0.85rem; }}
  th, td {{ padding: 0.5rem 0.75rem; text-align: left; border-bottom: 1px solid #362e4a; }}
  th {{ color: #9e96b0; font-weight: 500; }}
  .bar {{ height: 8px; border-radius: 4px; background: #362e4a; overflow: hidden; }}
  .bar-fill {{ height: 100%; border-radius: 4px; }}
  .footer {{ margin-top: 2rem; padding-top: 1rem; border-top: 1px solid #362e4a; color: #9e96b0; font-size: 0.75rem; text-align: center; }}
  @media (max-width: 600px) {{ .grid {{ grid-template-columns: repeat(2, 1fr); }} }}
</style>
</head>
<body>
{header}
<div class="date">Generated {now}{' — ' + duration + ' scan' if duration else ''}{', ' + str(files_scanned) + ' files' if metrics else ''}</div>

<div class="status">
  <div class="status-light" style="background:{status_color}"></div>
  <div>
    <div class="status-label" style="color:{status_color}">{status_label}</div>
    <div class="status-desc">{status_desc}</div>
  </div>
</div>

<div class="grid">
  <div class="card"><h3>Total Findings</h3><div class="value">{total}</div></div>
  <div class="card"><h3>Blocking</h3><div class="value sev-critical">{blocking}</div></div>
  <div class="card"><h3>Compliance</h3><div class="value">{score_pct or 'N/A'}</div></div>
  <div class="card"><h3>Packs</h3><div class="value">{len(packs_enabled) if packs_enabled else 0}</div></div>
</div>

<div class="grid">
  <div class="card"><h3>Critical</h3><div class="value sev-critical">{sev_counts['critical']}</div></div>
  <div class="card"><h3>High</h3><div class="value sev-high">{sev_counts['high']}</div></div>
  <div class="card"><h3>Medium</h3><div class="value sev-medium">{sev_counts['medium']}</div></div>
  <div class="card"><h3>Low / Info</h3><div class="value sev-low">{sev_counts['low'] + sev_counts['info']}</div></div>
</div>

<div class="section">
  <h2>Top Violation Rules</h2>
  <table>
    <thead><tr><th>Rule</th><th style="text-align:right">Count</th><th style="width:40%"></th></tr></thead>
    <tbody>
    {''.join(f'<tr><td>{rid}</td><td style="text-align:right">{cnt}</td><td><div class="bar"><div class="bar-fill" style="width:{min(100, cnt*100//(top_rules[0][1] or 1))}%;background:#7c3aed"></div></div></td></tr>' for rid, cnt in top_rules) if top_rules else '<tr><td colspan="3" style="color:#9e96b0">No findings</td></tr>'}
    </tbody>
  </table>
</div>

<div class="section">
  <h2>Most Affected Files</h2>
  <table>
    <thead><tr><th>File</th><th style="text-align:right">Findings</th></tr></thead>
    <tbody>
    {''.join(f'<tr><td>{fp}</td><td style="text-align:right">{cnt}</td></tr>' for fp, cnt in top_files) if top_files else '<tr><td colspan="2" style="color:#9e96b0">No file-level findings</td></tr>'}
    </tbody>
  </table>
</div>

{f'<div class="section"><h2>Active Packs</h2><p style="color:#9e96b0;font-size:0.85rem">{packs_html}</p></div>' if packs_html else ''}

<div class="footer">
  Generated by Sentrik — sentrik.dev
</div>
</body>
</html>"""
    return html
