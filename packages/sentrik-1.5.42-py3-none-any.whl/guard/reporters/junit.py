"""JUnit XML reporter — generates JUnit-compatible XML for CI/CD systems."""

from __future__ import annotations

from xml.etree.ElementTree import Element, SubElement, tostring

from guard.core.models import Finding, Severity
from guard.reporters.base import Reporter

_FAILURE_SEVERITIES = {Severity.CRITICAL, Severity.HIGH}


class JUnitReporter(Reporter):
    """Produces JUnit XML where each finding is a test case.

    Findings with severity CRITICAL or HIGH are reported as ``<failure>``
    elements; others are reported as passing test cases with stdout
    containing the finding details.
    """

    @property
    def extension(self) -> str:
        return ".xml"

    def render(self, findings: list[Finding]) -> str:
        testsuite = Element("testsuite")
        testsuite.set("name", "guard-scan")
        testsuite.set("tests", str(len(findings)))

        failures = 0
        for f in findings:
            tc = SubElement(testsuite, "testcase")
            tc.set("name", f.finding_id)
            tc.set("classname", f.rule_id)
            tc.set("file", f.evidence.file)

            if f.severity in _FAILURE_SEVERITIES:
                failures += 1
                fail = SubElement(tc, "failure")
                fail.set("message", f.message)
                fail.set("type", f.severity.value)
                fail.text = _detail_text(f)
            else:
                out = SubElement(tc, "system-out")
                out.text = _detail_text(f)

        testsuite.set("failures", str(failures))

        xml_bytes = tostring(testsuite, encoding="unicode", xml_declaration=False)
        return '<?xml version="1.0" encoding="UTF-8"?>\n' + xml_bytes


def _detail_text(f: Finding) -> str:
    parts = [f"Message: {f.message}"]
    if f.evidence.lines:
        parts.append(f"Lines: {f.evidence.lines}")
    if f.evidence.snippet:
        parts.append(f"Snippet: {f.evidence.snippet}")
    if f.suggestion:
        parts.append(f"Suggestion: {f.suggestion}")
    det = "deterministic" if f.deterministic else "heuristic"
    parts.append(f"Confidence: {f.confidence} ({det})")
    return "\n".join(parts)
