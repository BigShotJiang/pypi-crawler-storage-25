"""Per-framework compliance report generator.

Produces standalone HTML compliance reports that map findings to regulatory
clauses, showing pass/fail status per clause and an overall framework
compliance summary.  Designed for QA meetings, auditor handoffs, and
regulatory submissions.
"""

from __future__ import annotations

import re
from collections import defaultdict
from datetime import datetime, timezone
from html import escape

from guard import __version__
from guard.core.models import Finding, Severity

_SEVERITY_COLORS: dict[str, str] = {
    "critical": "#d32f2f",
    "high": "#f57c00",
    "medium": "#fbc02d",
    "low": "#1976d2",
    "info": "#757575",
}


def _sev_sort_key(sev: str) -> int:
    return {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}.get(sev, 5)


def _clause_sort_key(clause: str) -> tuple:
    """Sort clauses numerically where possible (e.g. 5.1.1 < 5.5.5 < CC6.1)."""
    parts = re.split(r"[.\-]", clause)
    result: list = []
    for p in parts:
        try:
            result.append((0, int(p)))
        except ValueError:
            result.append((1, p))
    return tuple(result)


# ── public API ───────────────────────────────────────────────────────


def list_frameworks(findings: list[Finding]) -> list[str]:
    """Return sorted list of distinct framework/standard names in findings."""
    frameworks: set[str] = set()
    for f in findings:
        if f.standard:
            frameworks.add(f.standard)
    return sorted(frameworks)


def generate_compliance_report(
    findings: list[Finding],
    framework: str | None = None,
    rules_total: int | None = None,
) -> str:
    """Generate an HTML compliance report.

    If *framework* is given, only findings for that standard are included
    and the report is titled accordingly.  If ``None``, all findings are
    grouped by their ``standard`` field.

    *rules_total* is used to compute the overall compliance score.  When
    ``None`` we derive it from distinct rule IDs.
    """
    if framework:
        scoped = [f for f in findings if f.standard and f.standard.lower() == framework.lower()]
        title = f"{framework} Compliance Report"
    else:
        scoped = [f for f in findings if f.standard]
        title = "Compliance Report — All Frameworks"

    # Group by clause
    clause_map: dict[str, list[Finding]] = defaultdict(list)
    for f in scoped:
        key = f.clause or "Uncategorized"
        clause_map[key].append(f)

    # Separate obligations from code findings
    code_findings = [f for f in scoped if not f.is_obligation]
    obligations = [f for f in scoped if f.is_obligation]

    # Compute score
    # When filtering by framework, always derive rules_total from scoped
    # findings — the caller's rules_total covers ALL packs combined.
    failed_rule_ids = {f.rule_id for f in code_findings}
    all_rule_ids = {f.rule_id for f in scoped}
    if framework or rules_total is None:
        rules_total = len(all_rule_ids) or 1
    rules_passed = rules_total - len(failed_rule_ids)
    score = round((rules_passed / rules_total) * 100, 1) if rules_total else 100.0
    score_color = "#4caf50" if score >= 90 else "#fbc02d" if score >= 70 else "#d32f2f"

    # Count by severity
    sev_counts: dict[str, int] = defaultdict(int)
    for f in code_findings:
        sev_counts[f.severity.value] += 1

    # Build HTML sections
    clause_rows = _build_clause_rows(clause_map)
    findings_detail = _build_findings_detail(code_findings)

    obligations_section = ""
    if obligations:
        obligations_section = _OBLIGATIONS_SECTION.format(rows=_build_obligations(obligations))

    sev_badges = "".join(
        f'<span style="display:inline-block;padding:4px 12px;border-radius:4px;'
        f'background:{_SEVERITY_COLORS.get(s, "#757575")};color:#fff;margin-right:6px;'
        f'font-size:0.85rem;font-weight:600">{s.upper()}: {sev_counts[s]}</span>'
        for s in ("critical", "high", "medium", "low", "info")
        if sev_counts.get(s, 0) > 0
    )

    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    return _TEMPLATE.format(
        title=escape(title),
        framework_name=escape(framework or "All Frameworks"),
        score=score,
        score_color=score_color,
        rules_passed=rules_passed,
        rules_total=rules_total,
        rules_failed=len(failed_rule_ids),
        total_findings=len(code_findings),
        total_obligations=len(obligations),
        sev_badges=sev_badges,
        clause_rows=clause_rows,
        findings_detail=findings_detail,
        obligations_section=obligations_section,
        clauses_checked=len(clause_map),
        clauses_clean=sum(1 for fs in clause_map.values() if all(f.is_obligation for f in fs)),
        timestamp=timestamp,
        version=__version__,
    )


# ── HTML builders ────────────────────────────────────────────────────


def _build_clause_rows(clause_map: dict[str, list[Finding]]) -> str:
    rows: list[str] = []
    for clause in sorted(clause_map, key=_clause_sort_key):
        fs = clause_map[clause]
        code_fs = [f for f in fs if not f.is_obligation]
        obligs = [f for f in fs if f.is_obligation]

        if not code_fs:
            status = '<span class="status-pass">PASS</span>'
            worst = "—"
        else:
            status = '<span class="status-fail">FAIL</span>'
            worst_sev = min(code_fs, key=lambda f: _sev_sort_key(f.severity.value)).severity.value
            color = _SEVERITY_COLORS.get(worst_sev, "#757575")
            worst = f'<span style="color:{color};font-weight:600">{worst_sev.upper()}</span>'

        rule_ids = sorted({f.rule_id for f in fs})
        rules_cell = ", ".join(f"<code>{escape(r)}</code>" for r in rule_ids[:4])
        if len(rule_ids) > 4:
            rules_cell += f" <em>(+{len(rule_ids) - 4} more)</em>"

        rows.append(
            f"<tr>"
            f"<td><strong>{escape(clause)}</strong></td>"
            f"<td>{status}</td>"
            f"<td>{worst}</td>"
            f"<td>{len(code_fs)}</td>"
            f"<td>{len(obligs)}</td>"
            f"<td>{rules_cell}</td>"
            f"</tr>"
        )
    return "\n".join(rows)


def _build_findings_detail(findings: list[Finding]) -> str:
    if not findings:
        return '<tr><td colspan="6">No code findings — all rules passed.</td></tr>'

    findings_sorted = sorted(
        findings,
        key=lambda f: (_sev_sort_key(f.severity.value), f.clause or "", f.rule_id),
    )
    rows: list[str] = []
    for f in findings_sorted:
        sev = f.severity.value
        color = _SEVERITY_COLORS.get(sev, "#757575")
        file_display = escape(f.evidence.file) if f.evidence.file else "—"
        if f.evidence.lines:
            file_display += f":{f.evidence.lines[0]}"

        guidance = ""
        if f.remediation_guidance:
            guidance = escape(f.remediation_guidance)
        elif f.suggestion:
            guidance = escape(f.suggestion)

        rows.append(
            f"<tr>"
            f'<td style="color:{color};font-weight:600">{sev.upper()}</td>'
            f"<td><code>{escape(f.rule_id)}</code></td>"
            f"<td>{escape(f.clause or '—')}</td>"
            f"<td>{file_display}</td>"
            f"<td>{escape(f.message[:80])}</td>"
            f"<td>{guidance}</td>"
            f"</tr>"
        )
    return "\n".join(rows)


def _build_obligations(obligations: list[Finding]) -> str:
    rows: list[str] = []
    for f in sorted(obligations, key=lambda f: (f.clause or "", f.rule_id)):
        rows.append(
            f"<tr>"
            f"<td><code>{escape(f.rule_id)}</code></td>"
            f"<td>{escape(f.clause or '—')}</td>"
            f"<td>{escape(f.message)}</td>"
            f"<td>{escape(f.remediation_guidance or '—')}</td>"
            f"</tr>"
        )
    return "\n".join(rows)


# ── Templates ────────────────────────────────────────────────────────

_OBLIGATIONS_SECTION = """\
<h2>Documentation Obligations</h2>
<p style="margin-bottom:1rem">Non-code compliance items required by the standard. These do not fail the gate but must be addressed for full regulatory compliance.</p>
<table>
  <thead>
    <tr>
      <th>Rule</th>
      <th>Clause</th>
      <th>Obligation</th>
      <th>Guidance</th>
    </tr>
  </thead>
  <tbody>
    {rows}
  </tbody>
</table>
"""

_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>
  :root {{
    --bg: #fff; --text: #1a1a2e; --border: #e0e0e0; --card-bg: #f8f9fa;
    --table-stripe: #f5f5f5; --header-bg: #1a1a2e; --header-text: #fff;
  }}
  @media (prefers-color-scheme: dark) {{
    :root {{
      --bg: #0d1117; --text: #e6edf3; --border: #30363d; --card-bg: #161b22;
      --table-stripe: #161b22; --header-bg: #161b22; --header-text: #e6edf3;
    }}
  }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: var(--bg); color: var(--text); line-height: 1.6;
    padding: 2rem; max-width: 1200px; margin: 0 auto;
  }}
  h1 {{ font-size: 1.8rem; margin-bottom: 0.5rem; }}
  h2 {{ font-size: 1.3rem; margin: 2rem 0 1rem; border-bottom: 2px solid var(--border); padding-bottom: 0.5rem; }}

  .meta {{ color: #888; font-size: 0.85rem; margin-bottom: 1.5rem; }}

  .score-card {{
    display: inline-flex; align-items: center; gap: 1.5rem;
    background: var(--card-bg); border: 1px solid var(--border);
    border-radius: 8px; padding: 1.2rem 2rem; margin-bottom: 1.5rem;
  }}
  .score-number {{ font-size: 2.5rem; font-weight: 800; }}
  .score-detail {{ font-size: 0.9rem; }}
  .score-detail div {{ margin-bottom: 0.2rem; }}

  .summary-grid {{
    display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 1rem; margin-bottom: 1.5rem;
  }}
  .summary-card {{
    background: var(--card-bg); border: 1px solid var(--border);
    border-radius: 8px; padding: 1rem; text-align: center;
  }}
  .summary-card .num {{ font-size: 1.6rem; font-weight: 700; }}
  .summary-card .label {{ font-size: 0.8rem; color: #888; }}

  table {{
    width: 100%; border-collapse: collapse; font-size: 0.85rem; margin-bottom: 1.5rem;
  }}
  th {{
    background: var(--header-bg); color: var(--header-text);
    padding: 0.6rem 0.8rem; text-align: left; font-weight: 600;
  }}
  td {{ padding: 0.5rem 0.8rem; border-bottom: 1px solid var(--border); vertical-align: top; }}
  tr:nth-child(even) {{ background: var(--table-stripe); }}
  code {{ background: var(--card-bg); padding: 2px 6px; border-radius: 3px; font-size: 0.8rem; }}

  .status-pass {{ color: #4caf50; font-weight: 700; }}
  .status-fail {{ color: #d32f2f; font-weight: 700; }}

  .footer {{
    margin-top: 3rem; padding-top: 1rem; border-top: 1px solid var(--border);
    font-size: 0.75rem; color: #888; text-align: center;
  }}

  @media print {{
    body {{ padding: 0; font-size: 10pt; }}
    .score-card {{ break-inside: avoid; }}
    table {{ font-size: 8pt; }}
  }}
</style>
</head>
<body>

<h1>{title}</h1>
<div class="meta">
  Generated {timestamp} &mdash; Sentrik v{version}
</div>

<div class="score-card">
  <div class="score-number" style="color:{score_color}">{score}%</div>
  <div class="score-detail">
    <div><strong>{rules_passed}</strong> of <strong>{rules_total}</strong> rules passed</div>
    <div><strong>{rules_failed}</strong> rule(s) with findings</div>
    <div><strong>{clauses_checked}</strong> clauses checked, <strong>{clauses_clean}</strong> clean</div>
  </div>
</div>

<div class="summary-grid">
  <div class="summary-card">
    <div class="num">{total_findings}</div>
    <div class="label">Code Findings</div>
  </div>
  <div class="summary-card">
    <div class="num">{total_obligations}</div>
    <div class="label">Documentation Obligations</div>
  </div>
  <div class="summary-card">
    <div class="num">{clauses_checked}</div>
    <div class="label">Clauses Checked</div>
  </div>
  <div class="summary-card">
    <div class="num" style="color:{score_color}">{score}%</div>
    <div class="label">Compliance Score</div>
  </div>
</div>

<div style="margin-bottom:1.5rem">{sev_badges}</div>

<h2>Clause-by-Clause Status</h2>
<table>
  <thead>
    <tr>
      <th>Clause</th>
      <th>Status</th>
      <th>Worst Severity</th>
      <th>Findings</th>
      <th>Obligations</th>
      <th>Rules</th>
    </tr>
  </thead>
  <tbody>
    {clause_rows}
  </tbody>
</table>

<h2>Findings Detail</h2>
<table>
  <thead>
    <tr>
      <th>Severity</th>
      <th>Rule</th>
      <th>Clause</th>
      <th>File</th>
      <th>Message</th>
      <th>Remediation</th>
    </tr>
  </thead>
  <tbody>
    {findings_detail}
  </tbody>
</table>

{obligations_section}

<div class="footer">
  Sentrik v{version} &mdash; {framework_name} Compliance Report &mdash; {timestamp}
</div>

</body>
</html>
"""
