"""Language Server Protocol server for real-time compliance scanning.

Provides as-you-type compliance diagnostics in any LSP-compatible editor
(VS Code, Neovim, Sublime Text, etc.).  Only evaluates fast regex rules
for low-latency feedback; full scans should use ``sentrik scan``.

Start with: ``sentrik lsp-server``
"""

from __future__ import annotations

import logging
import re
import threading
import time
from pathlib import Path
from typing import Any

from lsprotocol import types as lsp
from pygls.server import LanguageServer

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Rule loading (fast subset only)
# ---------------------------------------------------------------------------

_rules_cache: list[dict[str, Any]] | None = None
_rules_lock = threading.Lock()


def _load_fast_rules() -> list[dict[str, Any]]:
    """Load regex rules from enabled packs (cached after first call)."""
    global _rules_cache
    with _rules_lock:
        if _rules_cache is not None:
            return _rules_cache

        try:
            from guard.config import GuardConfig
            from guard.providers.factory import _load_pack_rules

            config = GuardConfig.load()
            pack_rules = _load_pack_rules(
                config.standards_packs,
                config.pack_overrides,
                config.license_key,
            )

            # Also load user rules
            from guard.core.standards import StandardsProvider
            try:
                sp = StandardsProvider(config.standards_file)
                user_rules = sp.get_rules()
            except Exception:
                user_rules = []

            all_rules = user_rules + pack_rules

            # Filter to regex rules only (fast evaluation)
            fast = []
            for r in all_rules:
                if r.get("type") != "regex":
                    continue
                pattern = r.get("pattern", "")
                if not pattern:
                    continue
                try:
                    compiled = re.compile(pattern)
                    fast.append({**r, "_compiled": compiled})
                except re.error:
                    continue

            _rules_cache = fast
            logger.info("LSP: loaded %d fast regex rules", len(fast))
        except Exception as exc:
            logger.warning("LSP: failed to load rules: %s", exc)
            _rules_cache = []

        return _rules_cache


def _file_matches_glob(file_path: str, glob_pattern: str) -> bool:
    """Check if a file path matches a simplified glob pattern."""
    from fnmatch import fnmatch

    # Handle brace expansion: **/*.{py,js} → check each
    if "{" in glob_pattern and "}" in glob_pattern:
        prefix, rest = glob_pattern.split("{", 1)
        options, suffix = rest.split("}", 1)
        return any(
            fnmatch(file_path, prefix + opt + suffix)
            for opt in options.split(",")
        )
    return fnmatch(file_path, glob_pattern)


# ---------------------------------------------------------------------------
# Severity mapping
# ---------------------------------------------------------------------------

_SEVERITY_MAP = {
    "critical": lsp.DiagnosticSeverity.Error,
    "high": lsp.DiagnosticSeverity.Error,
    "medium": lsp.DiagnosticSeverity.Warning,
    "low": lsp.DiagnosticSeverity.Information,
    "info": lsp.DiagnosticSeverity.Hint,
}


# ---------------------------------------------------------------------------
# Diagnostic generation
# ---------------------------------------------------------------------------


def _analyze_text(uri: str, text: str) -> list[lsp.Diagnostic]:
    """Run fast regex rules against document text and return diagnostics."""
    rules = _load_fast_rules()
    if not rules:
        return []

    # Normalize URI to file path for glob matching
    file_path = uri
    if file_path.startswith("file:///"):
        file_path = file_path[8:]
    elif file_path.startswith("file://"):
        file_path = file_path[7:]
    # Normalize backslashes
    file_path = file_path.replace("\\", "/")

    diagnostics: list[lsp.Diagnostic] = []
    lines = text.split("\n")

    for rule in rules:
        # Check glob match
        glob = rule.get("file_glob", "**/*")
        if glob != "**/*" and not _file_matches_glob(file_path, glob):
            continue

        compiled: re.Pattern = rule["_compiled"]
        for line_no, line_text in enumerate(lines):
            for match in compiled.finditer(line_text):
                severity = _SEVERITY_MAP.get(
                    rule.get("severity", "medium"),
                    lsp.DiagnosticSeverity.Warning,
                )
                diagnostics.append(lsp.Diagnostic(
                    range=lsp.Range(
                        start=lsp.Position(line=line_no, character=match.start()),
                        end=lsp.Position(line=line_no, character=match.end()),
                    ),
                    severity=severity,
                    source="sentrik",
                    code=rule.get("id", ""),
                    message=f"[{rule.get('id', '')}] {rule.get('description', rule.get('name', ''))}",
                ))

    return diagnostics


# ---------------------------------------------------------------------------
# LSP Server
# ---------------------------------------------------------------------------

_DEBOUNCE_MS = 300
_debounce_timers: dict[str, threading.Timer] = {}


def create_lsp_server() -> LanguageServer:
    """Create and configure the Sentrik LSP server."""
    server = LanguageServer("sentrik-lsp", "v1")

    @server.feature(lsp.TEXT_DOCUMENT_DID_OPEN)
    def did_open(params: lsp.DidOpenTextDocumentParams):
        uri = params.text_document.uri
        text = params.text_document.text
        diagnostics = _analyze_text(uri, text)
        server.publish_diagnostics(uri, diagnostics)

    @server.feature(lsp.TEXT_DOCUMENT_DID_CHANGE)
    def did_change(params: lsp.DidChangeTextDocumentParams):
        uri = params.text_document.uri
        # Get full text from the last change event
        text = params.content_changes[-1].text if params.content_changes else ""

        # Debounce: cancel previous timer and schedule new analysis
        if uri in _debounce_timers:
            _debounce_timers[uri].cancel()

        def _run_analysis():
            diagnostics = _analyze_text(uri, text)
            server.publish_diagnostics(uri, diagnostics)

        timer = threading.Timer(_DEBOUNCE_MS / 1000, _run_analysis)
        _debounce_timers[uri] = timer
        timer.start()

    @server.feature(lsp.TEXT_DOCUMENT_DID_SAVE)
    def did_save(params: lsp.DidSaveTextDocumentParams):
        # Force immediate re-analysis on save
        uri = params.text_document.uri
        if uri in _debounce_timers:
            _debounce_timers[uri].cancel()
        # Read from disk on save (most reliable)
        try:
            file_path = uri
            if file_path.startswith("file:///"):
                file_path = file_path[8:]
            text = Path(file_path).read_text(encoding="utf-8", errors="replace")
            diagnostics = _analyze_text(uri, text)
            server.publish_diagnostics(uri, diagnostics)
        except OSError:
            pass

    @server.feature(lsp.TEXT_DOCUMENT_DID_CLOSE)
    def did_close(params: lsp.DidCloseTextDocumentParams):
        uri = params.text_document.uri
        # Clear diagnostics when file is closed
        server.publish_diagnostics(uri, [])
        if uri in _debounce_timers:
            _debounce_timers[uri].cancel()
            del _debounce_timers[uri]

    return server


def start_lsp_server():
    """Start the LSP server on stdio transport."""
    server = create_lsp_server()
    logger.info("Starting Sentrik LSP server (stdio)")
    server.start_io()
