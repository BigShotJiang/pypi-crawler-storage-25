"""ISO 14971 standards pack for medical device risk management."""
