"""MISRA C/C++ standards pack for safety-critical software."""
