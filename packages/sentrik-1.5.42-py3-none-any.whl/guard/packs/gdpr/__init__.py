"""EU General Data Protection Regulation (GDPR) standards pack."""
