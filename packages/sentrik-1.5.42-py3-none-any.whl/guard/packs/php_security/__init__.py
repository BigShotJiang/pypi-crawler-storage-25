"""PHP/Laravel security rules pack."""
