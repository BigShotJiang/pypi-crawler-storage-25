"""Pack discovery and loading for standards packs."""

from __future__ import annotations

import copy
import importlib.resources
import logging
import re
import shutil
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel

logger = logging.getLogger(__name__)

# Packs included in the permanent free tier (no license key required)
FREE_TIER_PACKS: set[str] = {
    "owasp-top-10",
    "python-security",
    "go-security",
    "supply-chain-security",
    "soc2",
    "misra-c",
    "do-178c",
    "iso-26262",
    "cpp-coding-standards",
}

# Packs that require Team tier or higher license
TEAM_TIER_PACKS: set[str] = {
    "fda-iec-62304",
    "hipaa",
    "pci-dss",
    "iso-27001",
    "nist-ai-rmf",
    "eu-ai-act",
    "php-security",
    "kotlin-security",
    "gdpr",
    "nist-800-53",
    "cmmc",
}

# Packs that require Organization tier or higher license
ORG_TIER_PACKS: set[str] = {
    "iec-81001-5-1",
    "fda-21cfr11",
    "iso-14971",
}


def pack_tier(pack_id: str) -> str:
    """Return the minimum tier required for a pack: Free, Team, or Org."""
    if pack_id in ORG_TIER_PACKS:
        return "Org"
    if pack_id in TEAM_TIER_PACKS:
        return "Team"
    return "Free"


def is_free_pack(pack_id: str) -> bool:
    """Return True if the pack is available in the free tier."""
    return pack_id in FREE_TIER_PACKS


def is_team_pack(pack_id: str) -> bool:
    """Return True if the pack requires Team tier or higher."""
    return pack_id in TEAM_TIER_PACKS


def is_org_pack(pack_id: str) -> bool:
    """Return True if the pack requires Organization tier or higher."""
    return pack_id in ORG_TIER_PACKS


# Built-in registry mapping pack IDs to their package paths
_BUILTIN_PACKS: dict[str, str] = {
    "fda-iec-62304": "guard.packs.fda_iec_62304",
    "owasp-top-10": "guard.packs.owasp_top_10",
    "soc2": "guard.packs.soc2",
    "hipaa": "guard.packs.hipaa",
    "pci-dss": "guard.packs.pci_dss",
    "iso-27001": "guard.packs.iso_27001",
    "iec-81001-5-1": "guard.packs.iec_81001_5_1",
    "fda-21cfr11": "guard.packs.fda_21cfr11",
    "misra-c": "guard.packs.misra_c",
    "iso-14971": "guard.packs.iso_14971",
    "do-178c": "guard.packs.do_178c",
    "iso-26262": "guard.packs.iso_26262",
    "php-security": "guard.packs.php_security",
    "kotlin-security": "guard.packs.kotlin_security",
    "supply-chain-security": "guard.packs.supply_chain_security",
    "nist-ai-rmf": "guard.packs.nist_ai_rmf",
    "eu-ai-act": "guard.packs.eu_ai_act",
    "go-security": "guard.packs.go_security",
    "python-security": "guard.packs.python_security",
    "gdpr": "guard.packs.gdpr",
    "nist-800-53": "guard.packs.nist_800_53",
    "cmmc": "guard.packs.cmmc",
    "cpp-coding-standards": "guard.packs.cpp_coding_standards",
}

CUSTOM_PACKS_DIR = ".guard/packs"
SENTRIK_RULES_DIR = ".sentrik/rules"

# Valid rule types for pack validation
_VALID_RULE_TYPES = {"regex", "required_pattern", "file_policy", "ast", "documentation_obligation", "requirement_verification"}


class PackInfo(BaseModel):
    """Metadata for an available standards pack."""

    pack_id: str
    name: str
    description: str = ""
    rule_count: int = 0
    source: str = "builtin"  # "builtin" or "custom"
    version: str = ""
    last_updated: str = ""


def _discover_custom_packs_dir(base_dir: Path | None = None) -> Path:
    """Return the path to the custom packs directory."""
    if base_dir is None:
        base_dir = Path(".")
    return base_dir / CUSTOM_PACKS_DIR


def _discover_sentrik_rules_dir(base_dir: Path | None = None) -> Path:
    """Return the path to the .sentrik/rules/ directory."""
    if base_dir is None:
        base_dir = Path(".")
    return base_dir / SENTRIK_RULES_DIR


def _discover_custom_pack_ids(base_dir: Path | None = None, *, enforce_limit: bool = False) -> list[str]:
    """Scan custom packs directories for packs containing pack.yaml.

    Supports two layouts:
    - Subdirectory: ``.sentrik/rules/<pack-name>/pack.yaml``
    - Flat file:    ``.sentrik/rules/<pack-name>.yaml``

    Checks both ``.sentrik/rules/`` (preferred) and ``.guard/packs/`` (legacy).
    When *enforce_limit* is True, caps the list to the tier's custom pack limit.
    """
    pack_ids: list[str] = []
    seen: set[str] = set()

    for dir_path in [_discover_sentrik_rules_dir(base_dir), _discover_custom_packs_dir(base_dir)]:
        if not dir_path.is_dir():
            continue
        for child in sorted(dir_path.iterdir()):
            # Subdirectory layout: <pack-name>/pack.yaml
            if child.is_dir() and (child / "pack.yaml").is_file() and child.name not in seen:
                pack_ids.append(child.name)
                seen.add(child.name)
            # Flat file layout: <pack-name>.yaml
            elif child.is_file() and child.suffix in {".yaml", ".yml"} and child.stem not in seen:
                pack_ids.append(child.stem)
                seen.add(child.stem)

    if enforce_limit:
        from guard.core.licensing import MAX_CUSTOM_PACKS, get_license_info

        license_info = get_license_info()
        max_packs = MAX_CUSTOM_PACKS.get(license_info.tier, 5)
        if len(pack_ids) > max_packs:
            logger.warning(
                "Custom pack limit reached: %d found, %d allowed on %s tier. "
                "Only the first %d will be loaded. Upgrade at https://sentrik.dev",
                len(pack_ids), max_packs, license_info.tier, max_packs,
            )
            pack_ids = pack_ids[:max_packs]

    return pack_ids


def _load_custom_pack_yaml(pack_id: str, base_dir: Path | None = None) -> dict[str, Any] | None:
    """Read and parse a custom pack's YAML from disk.

    Supports two layouts:
    - Subdirectory: ``.sentrik/rules/<pack-name>/pack.yaml``
    - Flat file:    ``.sentrik/rules/<pack-name>.yaml``

    Checks ``.sentrik/rules/`` first, then falls back to ``.guard/packs/``.
    """
    for dir_fn in [_discover_sentrik_rules_dir, _discover_custom_packs_dir]:
        packs_dir = dir_fn(base_dir)
        # Subdirectory layout
        subdir_path = packs_dir / pack_id / "pack.yaml"
        if subdir_path.is_file():
            try:
                raw = yaml.safe_load(subdir_path.read_text(encoding="utf-8"))
                return raw if isinstance(raw, dict) else None
            except (yaml.YAMLError, OSError, ValueError):
                logger.warning("Failed to read custom pack.yaml for %r", pack_id)
                return None
        # Flat file layout
        for ext in (".yaml", ".yml"):
            flat_path = packs_dir / f"{pack_id}{ext}"
            if flat_path.is_file():
                try:
                    raw = yaml.safe_load(flat_path.read_text(encoding="utf-8"))
                    return raw if isinstance(raw, dict) else None
                except (yaml.YAMLError, OSError, ValueError):
                    logger.warning("Failed to read custom pack file %r", str(flat_path))
                    return None
    return None


def is_known_pack(pack_id: str, base_dir: Path | None = None) -> bool:
    """Return True if the pack_id refers to a built-in or custom pack."""
    if pack_id in _BUILTIN_PACKS:
        return True
    return pack_id in _discover_custom_pack_ids(base_dir)


def list_available_packs(base_dir: Path | None = None) -> list[PackInfo]:
    """Discover all built-in and custom standards packs and return their metadata."""
    packs: list[PackInfo] = []

    # Built-in packs
    for pack_id, package_path in _BUILTIN_PACKS.items():
        try:
            rules = load_pack_rules(pack_id)
            pack_ref = importlib.resources.files(package_path)
            pack_yaml = pack_ref.joinpath("pack.yaml")
            raw = yaml.safe_load(pack_yaml.read_text(encoding="utf-8"))
            packs.append(PackInfo(
                pack_id=pack_id,
                name=raw.get("name", pack_id),
                description=raw.get("description", ""),
                rule_count=len(rules),
                source="builtin",
                version=raw.get("version", ""),
                last_updated=raw.get("last_updated", ""),
            ))
        except (yaml.YAMLError, OSError, ValueError):
            logger.warning("Failed to load pack %r — skipped", pack_id)

    # Custom packs (enforce tier limit)
    for pack_id in _discover_custom_pack_ids(base_dir, enforce_limit=True):
        try:
            raw = _load_custom_pack_yaml(pack_id, base_dir)
            if raw is None:
                continue
            rules = raw.get("rules", [])
            packs.append(PackInfo(
                pack_id=pack_id,
                name=raw.get("name", pack_id),
                description=raw.get("description", ""),
                rule_count=len(rules),
                source="custom",
                version=raw.get("version", ""),
                last_updated=raw.get("last_updated", ""),
            ))
        except (yaml.YAMLError, OSError, ValueError):
            logger.warning("Failed to load custom pack %r — skipped", pack_id)

    return packs


def load_pack_rules(pack_id: str, base_dir: Path | None = None) -> list[dict[str, Any]]:
    """Load rules from a standards pack YAML, stamping each with ``pack_id``.

    Returns an empty list if the pack is not found.
    """
    # Try built-in first
    package_path = _BUILTIN_PACKS.get(pack_id)
    if package_path is not None:
        try:
            pack_ref = importlib.resources.files(package_path)
            pack_yaml = pack_ref.joinpath("pack.yaml")
            raw = yaml.safe_load(pack_yaml.read_text(encoding="utf-8"))
        except (yaml.YAMLError, OSError, ValueError):
            logger.warning("Failed to read pack.yaml for %r", pack_id)
            return []

        rules: list[dict[str, Any]] = raw.get("rules", [])
        for rule in rules:
            rule["pack_id"] = pack_id
        return rules

    # Try custom pack
    raw = _load_custom_pack_yaml(pack_id, base_dir)
    if raw is not None:
        rules = raw.get("rules", [])
        for rule in rules:
            rule["pack_id"] = pack_id
        return rules

    logger.warning("Unknown standards pack %r", pack_id)
    return []


def apply_pack_overrides(
    rules: list[dict[str, Any]],
    pack_id: str,
    overrides: dict[str, dict[str, dict[str, Any]]],
) -> list[dict[str, Any]]:
    """Apply per-rule overrides for a pack without mutating the originals.

    ``overrides`` maps pack_id -> rule_id -> field overrides.
    Special override ``enabled: false`` removes the rule from the result.
    """
    pack_overrides = overrides.get(pack_id)
    if not pack_overrides:
        return rules

    result: list[dict[str, Any]] = []
    for rule in rules:
        rule_id = rule.get("id", "")
        rule_ovr = pack_overrides.get(rule_id)
        if rule_ovr is None:
            result.append(rule)
            continue

        # Check enabled flag
        if not rule_ovr.get("enabled", True):
            continue  # Rule disabled — skip it

        # Deep copy and apply overrides
        new_rule = copy.deepcopy(rule)
        for key, value in rule_ovr.items():
            if key == "enabled":
                continue
            new_rule[key] = value
        result.append(new_rule)

    return result


def validate_pack_yaml(raw: Any) -> list[str]:
    """Validate the structure of a pack YAML dict.

    Returns a list of error messages. Empty list means valid.
    """
    # Avoid circular import: VALID_SEVERITIES is in config.py which imports from this module
    from guard.config import VALID_SEVERITIES

    errors: list[str] = []

    if not isinstance(raw, dict):
        return ["Pack YAML must be a mapping"]

    if "name" not in raw:
        errors.append("Missing required field 'name'")

    if "rules" not in raw:
        errors.append("Missing required field 'rules'")
        return errors

    rules = raw["rules"]
    if not isinstance(rules, list):
        errors.append("'rules' must be a list")
        return errors

    seen_ids: set[str] = set()
    for i, rule in enumerate(rules):
        if not isinstance(rule, dict):
            errors.append(f"Rule at index {i} is not a mapping")
            continue

        rule_id = rule.get("id", f"<index {i}>")

        if "id" not in rule:
            errors.append(f"Rule at index {i} missing 'id'")
        elif rule["id"] in seen_ids:
            errors.append(f"Duplicate rule ID {rule['id']!r}")
        else:
            seen_ids.add(rule["id"])

        if "name" not in rule:
            errors.append(f"Rule {rule_id} missing 'name'")

        if "type" not in rule:
            errors.append(f"Rule {rule_id} missing 'type'")
        elif rule["type"] not in _VALID_RULE_TYPES:
            errors.append(f"Rule {rule_id} has invalid type {rule['type']!r}")

        if "severity" in rule and rule["severity"] not in VALID_SEVERITIES:
            errors.append(f"Rule {rule_id} has invalid severity {rule['severity']!r}")

        # Validate regex patterns compile and aren't excessively complex
        _MAX_PATTERN_LEN = 2000
        if rule.get("type") == "regex" and "pattern" in rule:
            pat_str = rule["pattern"]
            if len(pat_str) > _MAX_PATTERN_LEN:
                errors.append(f"Rule {rule_id} regex pattern exceeds {_MAX_PATTERN_LEN} chars")
            else:
                try:
                    re.compile(pat_str)
                except re.error as e:
                    errors.append(f"Rule {rule_id} has invalid regex pattern: {e}")

        for pat in rule.get("all_patterns", []):
            if len(pat) > _MAX_PATTERN_LEN:
                errors.append(f"Rule {rule_id} pattern in all_patterns exceeds {_MAX_PATTERN_LEN} chars")
            else:
                try:
                    re.compile(pat)
                except re.error as e:
                    errors.append(f"Rule {rule_id} has invalid pattern in all_patterns: {e}")

        # Validate ast rules: must have either ast_check (Python) or query+language (tree-sitter)
        if rule.get("type") == "ast":
            has_ast_check = bool(rule.get("ast_check"))
            has_query = bool(rule.get("query"))
            has_language = bool(rule.get("language"))
            if not has_ast_check and not has_query:
                errors.append(f"Rule {rule_id} of type 'ast' must specify either 'ast_check' or 'query'")
            if has_query and not has_language:
                errors.append(f"Rule {rule_id} with 'query' must also specify 'language'")

        # Sanitize string fields — prevent YAML injection in stored values
        for str_field in ("name", "description", "remediation_guidance", "standard", "clause", "language"):
            val = rule.get(str_field)
            if val is not None and not isinstance(val, str):
                errors.append(f"Rule {rule_id} field '{str_field}' must be a string")

    return errors


def import_pack(
    pack_id: str,
    raw: dict[str, Any],
    base_dir: Path | None = None,
    overwrite: bool = False,
) -> Path:
    """Write a pack to ``.sentrik/rules/{pack_id}/pack.yaml``.

    Falls back to ``.guard/packs/`` if ``.sentrik/`` directory doesn't exist.
    Raises ``ValueError`` if the pack_id collides with a built-in pack
    or already exists (unless ``overwrite=True``).
    Returns the path to the written pack.yaml.
    """
    if pack_id in _BUILTIN_PACKS:
        raise ValueError(f"Cannot import pack {pack_id!r}: collides with built-in pack")

    # Enforce custom pack limit (skip check for overwrites of existing packs)
    if not overwrite or not ((_discover_sentrik_rules_dir(base_dir) / pack_id).exists() or (_discover_custom_packs_dir(base_dir) / pack_id).exists()):
        from guard.core.licensing import MAX_CUSTOM_PACKS, get_license_info

        license_info = get_license_info()
        max_packs = MAX_CUSTOM_PACKS.get(license_info.tier, 5)
        existing = _discover_custom_pack_ids(base_dir)
        if len(existing) >= max_packs:
            raise ValueError(
                f"Custom pack limit reached: {len(existing)}/{max_packs} on {license_info.tier} tier. "
                f"Upgrade at https://sentrik.dev for more custom packs."
            )

    # Prefer .sentrik/rules/ if .sentrik/ exists, otherwise fall back to .guard/packs/
    sentrik_dir = _discover_sentrik_rules_dir(base_dir)
    guard_dir = _discover_custom_packs_dir(base_dir)
    packs_dir = sentrik_dir if sentrik_dir.parent.is_dir() else guard_dir
    pack_dir = packs_dir / pack_id
    if pack_dir.exists() and not overwrite:
        raise ValueError(f"Pack {pack_id!r} already exists. Use overwrite=True to replace.")

    pack_dir.mkdir(parents=True, exist_ok=True)
    pack_yaml_path = pack_dir / "pack.yaml"
    pack_yaml_path.write_text(
        yaml.dump(raw, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    return pack_yaml_path


def export_pack(pack_id: str, base_dir: Path | None = None) -> dict[str, Any]:
    """Return the full YAML dict for any pack (built-in or custom).

    Raises ``ValueError`` if the pack is not found.
    """
    # Try built-in
    package_path = _BUILTIN_PACKS.get(pack_id)
    if package_path is not None:
        pack_ref = importlib.resources.files(package_path)
        pack_yaml = pack_ref.joinpath("pack.yaml")
        raw = yaml.safe_load(pack_yaml.read_text(encoding="utf-8"))
        return raw

    # Try custom
    raw = _load_custom_pack_yaml(pack_id, base_dir)
    if raw is not None:
        return raw

    raise ValueError(f"Unknown pack {pack_id!r}")


def delete_custom_pack(pack_id: str, base_dir: Path | None = None) -> None:
    """Remove a custom pack directory.

    Raises ``ValueError`` for built-in packs or packs that don't exist.
    """
    if pack_id in _BUILTIN_PACKS:
        raise ValueError(f"Cannot delete built-in pack {pack_id!r}")

    packs_dir = _discover_custom_packs_dir(base_dir)
    pack_dir = packs_dir / pack_id
    if not pack_dir.exists():
        raise ValueError(f"Custom pack {pack_id!r} not found")

    shutil.rmtree(pack_dir)


def diff_pack_rules(
    old_rules: list[dict[str, Any]],
    new_rules: list[dict[str, Any]],
) -> dict[str, Any]:
    """Diff two sets of pack rules and return added/removed/modified/unchanged.

    Returns a dict with keys: added, removed, modified, unchanged (each a list of rule IDs),
    plus ``details`` with per-modified-rule change descriptions.
    """
    old_by_id = {r["id"]: r for r in old_rules if "id" in r}
    new_by_id = {r["id"]: r for r in new_rules if "id" in r}

    old_ids = set(old_by_id)
    new_ids = set(new_by_id)

    added = sorted(new_ids - old_ids)
    removed = sorted(old_ids - new_ids)
    common = old_ids & new_ids

    modified = []
    unchanged = []
    details: dict[str, list[str]] = {}

    # Fields to compare (skip pack_id which is stamped at load time)
    _COMPARE_FIELDS = (
        "name", "description", "type", "pattern", "severity",
        "file_glob", "standard", "clause", "compliance_category",
        "remediation_guidance", "tags", "all_patterns", "applies_when",
        "autofix", "autofix_replacement", "params",
    )

    for rule_id in sorted(common):
        old_r = old_by_id[rule_id]
        new_r = new_by_id[rule_id]
        changes = []
        for field in _COMPARE_FIELDS:
            old_val = old_r.get(field)
            new_val = new_r.get(field)
            if old_val != new_val:
                changes.append(f"{field}: {old_val!r} → {new_val!r}")
        if changes:
            modified.append(rule_id)
            details[rule_id] = changes
        else:
            unchanged.append(rule_id)

    return {
        "added": added,
        "removed": removed,
        "modified": modified,
        "unchanged": unchanged,
        "details": details,
    }
