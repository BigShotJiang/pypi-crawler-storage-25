"""Kotlin security rules pack."""
