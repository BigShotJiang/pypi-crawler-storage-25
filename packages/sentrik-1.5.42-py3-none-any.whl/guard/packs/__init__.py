"""Standards packs — pre-built industry regulatory rule sets."""
