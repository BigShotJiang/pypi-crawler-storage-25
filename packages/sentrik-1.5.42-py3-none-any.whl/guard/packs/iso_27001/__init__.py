"""ISO/IEC 27001:2022 standards pack."""
