"""SENTRIK MCP (Model Context Protocol) server.

Exposes Sentrik compliance tools to AI coding agents (Claude Code, Cursor, etc.)
via the MCP protocol over stdio transport.

Usage:
    sentrik mcp-server          # Start MCP server (stdio mode)
    pip install sentrik[mcp]    # Install MCP dependency
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Tool logic functions (testable without MCP transport)
# ---------------------------------------------------------------------------


def _resolve_project_root() -> Path:
    """Return the project root directory (cwd)."""
    return Path.cwd()


def _read_json_file(path: Path) -> dict | list | None:
    """Read and parse a JSON file, returning None if missing or invalid."""
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None


def tool_scan_file(file_path: str) -> str:
    """Scan a single file for compliance issues.

    Reads the file, runs the rules engine against it, and returns
    structured findings text.
    """
    from guard.sdk.checker import check_code

    abs_path = Path(file_path)
    if not abs_path.is_absolute():
        abs_path = _resolve_project_root() / file_path

    if not abs_path.is_file():
        return f"Error: File not found: {file_path}"

    try:
        code = abs_path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        return f"Error reading file: {exc}"

    result = check_code(code, file_path)

    if result.compliant:
        return f"No compliance issues found in {file_path}."

    lines: list[str] = [
        f"Found {len(result.findings)} issue(s) in {file_path}:",
        "",
    ]
    for f in result.findings:
        lines.append(
            f"- [{f.get('severity', 'medium').upper()}] {f.get('rule_id', '?')} "
            f"(line {f.get('line', '?')}): {f.get('message', '')}"
        )
        suggestion = f.get("suggestion", "")
        if suggestion:
            lines.append(f"  Suggestion: {suggestion}")
    return "\n".join(lines)


def tool_get_compliance_context(file_path: str) -> str:
    """Get applicable compliance rules and constraints for a file.

    Returns JSON with rules, frameworks, and human-readable constraints.
    """
    from guard.sdk.checker import get_compliance_context

    ctx = get_compliance_context(file_path)
    return json.dumps(ctx, indent=2)


def tool_check_code_snippet(code: str, filename: str) -> str:
    """Check a code snippet for compliance issues without writing to disk.

    The rules engine handles temp file creation internally.
    """
    from guard.sdk.checker import check_code

    if not code or not code.strip():
        return "No code provided."

    result = check_code(code, filename)

    if result.compliant:
        return f"No compliance issues found (confidence: {result.confidence:.0%})."

    lines: list[str] = [
        f"Found {len(result.findings)} issue(s):",
        "",
    ]
    for f in result.findings:
        lines.append(
            f"- [{f.get('severity', 'medium').upper()}] {f.get('rule_id', '?')} "
            f"(line {f.get('line', '?')}): {f.get('message', '')}"
        )
        suggestion = f.get("suggestion", "")
        if suggestion:
            lines.append(f"  Suggestion: {suggestion}")

    if result.suggestions:
        lines.append("")
        lines.append("Remediation suggestions:")
        for s in result.suggestions:
            lines.append(f"  - {s}")

    return "\n".join(lines)


def tool_get_scan_summary() -> str:
    """Get current project compliance status from the latest scan results.

    Reads from out/findings.json and out/scan_metrics.json.
    """
    from guard.config import GuardConfig

    try:
        config = GuardConfig.load()
    except Exception:
        config = GuardConfig()

    out_dir = Path(config.output_dir)
    findings_path = out_dir / "findings.json"
    metrics_path = out_dir / "scan_metrics.json"

    findings_data = _read_json_file(findings_path)
    metrics_data = _read_json_file(metrics_path)

    if findings_data is None and metrics_data is None:
        return (
            "No scan results found. Run 'sentrik scan' first to generate results."
        )

    result: dict[str, Any] = {}

    # Process findings
    if isinstance(findings_data, list):
        severity_counts: dict[str, int] = {}
        for f in findings_data:
            sev = f.get("severity", "medium")
            severity_counts[sev] = severity_counts.get(sev, 0) + 1
        result["total_findings"] = len(findings_data)
        result["by_severity"] = severity_counts

        # Gate status: check if any critical/high findings
        gate_blocking = severity_counts.get("critical", 0) + severity_counts.get("high", 0)
        result["gate_status"] = "FAIL" if gate_blocking > 0 else "PASS"
        result["gate_blocking_findings"] = gate_blocking

    # Process metrics
    if isinstance(metrics_data, dict):
        result["files_scanned"] = metrics_data.get("files_scanned", 0)
        result["scan_duration_ms"] = metrics_data.get("total_duration_ms", 0)
        result["rules_evaluated"] = metrics_data.get("rules_count", 0)
        if "compliance_score" in metrics_data:
            result["compliance_score"] = metrics_data["compliance_score"]

    return json.dumps(result, indent=2)


def tool_explain_rule(rule_id: str) -> str:
    """Explain a specific compliance rule by its ID.

    Returns the rule's name, description, standard, clause, severity,
    remediation guidance, and applicable file globs.
    """
    from guard.packs.registry import list_available_packs, load_pack_rules

    all_packs = list_available_packs()
    for pack in all_packs:
        rules = load_pack_rules(pack.pack_id)
        for rule in rules:
            if rule.get("id") == rule_id:
                info: dict[str, Any] = {
                    "id": rule["id"],
                    "name": rule.get("name", ""),
                    "description": rule.get("description", ""),
                    "type": rule.get("type", ""),
                    "severity": rule.get("severity", "medium"),
                    "standard": rule.get("standard", ""),
                    "clause": rule.get("clause", ""),
                    "file_glob": rule.get("file_glob", "**/*"),
                    "remediation_guidance": rule.get("remediation_guidance", ""),
                    "pack": pack.pack_id,
                }
                if rule.get("pattern"):
                    info["pattern"] = rule["pattern"]
                return json.dumps(info, indent=2)

    return f"Rule '{rule_id}' not found. Use get_compliance_context to see rules for a specific file."


def tool_get_vulnerabilities() -> str:
    """Get dependency vulnerability scan results.

    Reads from out/vulnerabilities.json.
    """
    from guard.config import GuardConfig

    try:
        config = GuardConfig.load()
    except Exception:
        config = GuardConfig()

    vuln_path = Path(config.output_dir) / "vulnerabilities.json"
    data = _read_json_file(vuln_path)

    if data is None:
        return "No vulnerability data found. Run 'sentrik vulns' first."

    if isinstance(data, list):
        if not data:
            return "No vulnerabilities found."
        return json.dumps(
            {"total_vulnerabilities": len(data), "vulnerabilities": data},
            indent=2,
        )
    elif isinstance(data, dict):
        return json.dumps(data, indent=2)
    return json.dumps(data, indent=2)


def tool_get_agent_status() -> str:
    """Get per-agent compliance status from the latest scan.

    Returns timing, finding counts, and error status for each
    compliance agent when agent_scan mode is enabled.
    """
    from guard.config import GuardConfig

    try:
        config = GuardConfig.load()
    except Exception:
        config = GuardConfig()

    metrics_path = Path(config.output_dir) / "scan_metrics.json"
    data = _read_json_file(metrics_path)

    if data is None:
        return "No scan metrics found. Run 'sentrik scan' first."

    agent_metrics = data.get("agent_metrics", [])
    if not agent_metrics:
        return "No agent metrics available. Enable agent_scan in config and run 'sentrik scan'."

    return json.dumps({"agents": agent_metrics}, indent=2)


def tool_get_design_constraints(file_path: str = "", intent: str = "") -> str:
    """Get design constraints and project conventions for AI code generation.

    Provides architectural context, framework patterns, ADRs, and coding
    conventions so the AI agent writes code consistent with the project.
    """
    from guard.config import GuardConfig
    from guard.core.project_profile import load_profile, build_project_profile, save_profile, get_design_constraints

    try:
        config = GuardConfig.load()
    except Exception:
        config = GuardConfig()

    profile = load_profile(config.output_dir)
    if not profile:
        profile = build_project_profile(str(_resolve_project_root()))
        save_profile(profile, config.output_dir)

    constraints = get_design_constraints(
        profile,
        file_path=file_path or None,
        intent=intent or None,
    )
    return json.dumps(constraints, indent=2)


def tool_review_design_decisions(file_path: str = "", git_range: str = "") -> str:
    """Review design decisions in code changes using LLM analysis."""
    from guard.config import GuardConfig
    from guard.core.design_reviewer import review_design, get_diff
    from guard.providers.factory import build_llm
    from guard.providers.llm_stub import LLMStub

    try:
        config = GuardConfig.load()
    except Exception:
        config = GuardConfig()

    llm = build_llm(config)
    if isinstance(llm, LLMStub):
        return "Design review requires an LLM. Set ANTHROPIC_API_KEY or configure llm_provider."

    diff = get_diff(
        git_range=git_range or None,
        file_path=file_path or None,
        repo_root=str(_resolve_project_root()),
    )
    if not diff.strip():
        return "No code changes found."

    decisions = review_design(llm, diff, config.output_dir)
    return json.dumps([d.to_dict() for d in decisions], indent=2)


def tool_run_scan(path: str | None = None) -> str:
    """Run a full project scan via subprocess.

    This is the heavy operation -- it runs the full sentrik scan pipeline
    and returns a summary of the results.
    """
    cmd = [sys.executable, "-m", "guard.cli", "scan"]

    scan_dir = path or str(_resolve_project_root())

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=scan_dir,
            timeout=300,
        )
    except subprocess.TimeoutExpired:
        return "Scan timed out after 5 minutes."
    except FileNotFoundError:
        return "Error: Could not run sentrik scan. Is sentrik installed?"
    except OSError as exc:
        return f"Error running scan: {exc}"

    # After running scan, read the summary
    summary = tool_get_scan_summary()
    if "No scan results found" not in summary:
        return f"Scan complete.\n\n{summary}"

    # Fallback to subprocess output
    output = proc.stdout or proc.stderr or "Scan completed (no output captured)."
    return output


# ---------------------------------------------------------------------------
# MCP Server setup
# ---------------------------------------------------------------------------

_TOOLS_SPEC = [
    {
        "name": "scan_file",
        "description": (
            "Scan a single file for compliance issues. Returns findings with "
            "rule_id, severity, line number, message, and remediation suggestions."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the file to scan (absolute or relative to project root).",
                },
            },
            "required": ["file_path"],
        },
    },
    {
        "name": "get_compliance_context",
        "description": (
            "Get applicable compliance rules and constraints for a file. "
            "Call this BEFORE reviewing code to understand what rules apply. "
            "Returns JSON with applicable rules, frameworks, and human-readable constraints."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the file to get compliance context for.",
                },
            },
            "required": ["file_path"],
        },
    },
    {
        "name": "check_code_snippet",
        "description": (
            "Check a code snippet for compliance issues without needing a file on disk. "
            "Useful for validating code during generation or review."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "code": {
                    "type": "string",
                    "description": "The source code to check.",
                },
                "filename": {
                    "type": "string",
                    "description": "Filename for language detection and rule matching (e.g., 'src/main.cpp').",
                },
            },
            "required": ["code", "filename"],
        },
    },
    {
        "name": "get_scan_summary",
        "description": (
            "Get current project compliance status from the latest scan. "
            "Returns finding counts by severity, gate status, and compliance score."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "explain_rule",
        "description": (
            "Explain a specific compliance rule. Returns the rule's name, description, "
            "standard, clause, severity, remediation guidance, and file patterns."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "rule_id": {
                    "type": "string",
                    "description": "The rule ID to explain (e.g., 'HIPAA-164.312-a2-CPP').",
                },
            },
            "required": ["rule_id"],
        },
    },
    {
        "name": "get_vulnerabilities",
        "description": (
            "Get dependency vulnerability scan results. "
            "Returns CVE data from the latest vulnerability scan."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "run_scan",
        "description": (
            "Run a full project scan. This is a heavy operation that runs the "
            "complete sentrik pipeline. Use sparingly -- prefer scan_file for "
            "individual files or get_scan_summary for cached results."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Project directory to scan (defaults to current directory).",
                },
            },
        },
    },
    {
        "name": "get_agent_status",
        "description": (
            "Get per-agent compliance status from the latest scan. "
            "Returns timing, finding counts, and error status for each "
            "compliance agent when agent_scan mode is enabled."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "get_design_constraints",
        "description": (
            "Get project design constraints and conventions BEFORE generating code. "
            "Returns established patterns, tech stack, architectural rules, ADRs, "
            "and coding conventions so generated code is consistent with the project."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "The file about to be created or modified.",
                },
                "intent": {
                    "type": "string",
                    "description": "What the AI is about to do (e.g., 'add user authentication').",
                },
            },
        },
    },
    {
        "name": "review_design_decisions",
        "description": (
            "Review design decisions in code changes. Uses LLM to identify "
            "implicit architectural choices, framework decisions, and tradeoffs "
            "in AI-generated code. Returns decisions as questions for developer review."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Specific file to review.",
                },
                "git_range": {
                    "type": "string",
                    "description": "Git range to review (e.g., 'origin/main...HEAD').",
                },
            },
        },
    },
]

_TOOL_DISPATCH = {
    "scan_file": lambda args: tool_scan_file(args["file_path"]),
    "get_compliance_context": lambda args: tool_get_compliance_context(args["file_path"]),
    "check_code_snippet": lambda args: tool_check_code_snippet(args["code"], args["filename"]),
    "get_scan_summary": lambda args: tool_get_scan_summary(),
    "explain_rule": lambda args: tool_explain_rule(args["rule_id"]),
    "get_vulnerabilities": lambda args: tool_get_vulnerabilities(),
    "run_scan": lambda args: tool_run_scan(args.get("path")),
    "get_agent_status": lambda args: tool_get_agent_status(),
    "get_design_constraints": lambda args: tool_get_design_constraints(args.get("file_path", ""), args.get("intent", "")),
    "review_design_decisions": lambda args: tool_review_design_decisions(args.get("file_path", ""), args.get("git_range", "")),
}


def _start_mcp_server() -> None:  # pragma: no cover
    """Start the MCP server over stdio transport.

    Requires the ``mcp`` package (``pip install sentrik[mcp]``).
    """
    try:
        from mcp.server import Server
        from mcp.server.stdio import stdio_server
        from mcp.types import TextContent, Tool
    except ImportError:
        print(
            "Error: The 'mcp' package is required for the MCP server.\n"
            "Install it with: pip install sentrik[mcp]\n"
            "Or: pip install mcp>=1.0.0",
            file=sys.stderr,
        )
        sys.exit(1)

    server = Server("sentrik")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name=spec["name"],
                description=spec["description"],
                inputSchema=spec["inputSchema"],
            )
            for spec in _TOOLS_SPEC
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        handler = _TOOL_DISPATCH.get(name)
        if handler is None:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]
        try:
            result = handler(arguments or {})
            return [TextContent(type="text", text=result)]
        except Exception as exc:
            return [TextContent(type="text", text=f"Error: {exc}")]

    async def _run() -> None:
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )

    asyncio.run(_run())


if __name__ == "__main__":  # pragma: no cover
    _start_mcp_server()
