"""Convert API specification files (OpenAPI, AsyncAPI, protobuf) into Sentrik rule packs.

Each parser reads the spec, extracts security-relevant declarations (endpoints,
auth schemes, schemas, channels, messages, fields), and generates regex /
required_pattern / documentation_obligation rules that enforce the spec's
contract in application code.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Format detection
# ---------------------------------------------------------------------------

SUPPORTED_FORMATS = ("openapi", "asyncapi", "protobuf")


def detect_format(path: Path) -> str | None:
    """Auto-detect spec format from file extension and content."""
    suffix = path.suffix.lower()

    if suffix == ".proto":
        return "protobuf"

    if suffix in (".yaml", ".yml", ".json"):
        try:
            raw = yaml.safe_load(path.read_text(encoding="utf-8"))
        except Exception:
            return None
        if not isinstance(raw, dict):
            return None
        if "openapi" in raw:
            return "openapi"
        if "asyncapi" in raw:
            return "asyncapi"
    return None


# ---------------------------------------------------------------------------
# OpenAPI → rules
# ---------------------------------------------------------------------------

_SENSITIVE_FIELDS = re.compile(
    r"(?i)(password|secret|token|ssn|credit.?card|card.?number|cvv|"
    r"social.?security|date.?of.?birth|dob|bank.?account|routing.?number|"
    r"api.?key|private.?key|auth.?token|access.?token|refresh.?token)"
)

# Common path parameter patterns (e.g. /users/{id})
_PATH_PARAM_RE = re.compile(r"\{(\w+)\}")


def _severity_for_method(method: str) -> str:
    """Higher severity for mutating methods."""
    return "high" if method in ("post", "put", "patch", "delete") else "medium"


def _file_glob_for_openapi() -> str:
    return "**/*.{py,js,ts,jsx,tsx,java,go,rs,rb,cs,php,kt}"


def import_openapi(path: Path) -> dict[str, Any]:
    """Parse an OpenAPI 3.x spec and generate a Sentrik rule pack."""
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    title = raw.get("info", {}).get("title", path.stem)
    version = raw.get("info", {}).get("version", "")
    pack_name = f"OpenAPI: {title}"
    description = f"Security rules derived from OpenAPI spec '{title}' v{version}"

    # Gather global security schemes
    security_schemes = (
        raw.get("components", {}).get("securitySchemes", {})
    )
    global_security = raw.get("security", [])

    rules: list[dict[str, Any]] = []
    rule_idx = 0
    paths = raw.get("paths", {})

    for path_str, path_item in paths.items():
        if not isinstance(path_item, dict):
            continue

        for method in ("get", "post", "put", "patch", "delete", "options", "head"):
            operation = path_item.get(method)
            if not isinstance(operation, dict):
                continue

            op_id = operation.get("operationId", f"{method}_{path_str}")
            op_security = operation.get("security", global_security)
            slug = re.sub(r"[^a-zA-Z0-9]", "_", op_id).strip("_").lower()
            route_pattern = _path_to_regex(path_str)

            # Rule 1: unauthenticated endpoints
            if not op_security or op_security == [{}]:
                rule_idx += 1
                rules.append({
                    "id": f"SPEC-AUTH-{rule_idx:03d}",
                    "name": f"auth-required-{slug}",
                    "description": f"Endpoint {method.upper()} {path_str} has no authentication in the spec — ensure route handler enforces auth",
                    "type": "documentation_obligation",
                    "severity": _severity_for_method(method),
                    "standard": pack_name,
                    "clause": f"{method.upper()} {path_str}",
                    "compliance_category": "code",
                    "remediation_guidance": f"Add authentication middleware to {method.upper()} {path_str} or declare security in the OpenAPI spec.",
                    "tags": ["spec-import", "openapi", "authentication"],
                })

            # Rule 2: input validation for request body schemas
            request_body = operation.get("requestBody", {})
            if isinstance(request_body, dict):
                schemas = _extract_schemas_from_content(
                    request_body.get("content", {}), raw
                )
                for schema_name, properties in schemas:
                    for prop_name, prop_def in properties.items():
                        if not isinstance(prop_def, dict):
                            continue
                        # Generate validation rule for required string fields
                        # without constraints
                        if (
                            prop_def.get("type") == "string"
                            and "maxLength" not in prop_def
                            and "pattern" not in prop_def
                            and "enum" not in prop_def
                        ):
                            rule_idx += 1
                            rules.append({
                                "id": f"SPEC-INPUT-{rule_idx:03d}",
                                "name": f"validate-{slug}-{_sanitize(prop_name)}",
                                "description": f"Field '{prop_name}' in {method.upper()} {path_str} is an unbounded string — add maxLength or pattern validation",
                                "type": "documentation_obligation",
                                "severity": "medium",
                                "standard": pack_name,
                                "clause": f"{method.upper()} {path_str} → {prop_name}",
                                "compliance_category": "code",
                                "remediation_guidance": f"Add maxLength, pattern, or enum constraint to '{prop_name}' in the schema, and validate input in the handler.",
                                "tags": ["spec-import", "openapi", "input-validation"],
                            })

            # Rule 3: sensitive data in responses
            for status_code, response in operation.get("responses", {}).items():
                if not isinstance(response, dict):
                    continue
                schemas = _extract_schemas_from_content(
                    response.get("content", {}), raw
                )
                for schema_name, properties in schemas:
                    for prop_name in properties:
                        if _SENSITIVE_FIELDS.search(prop_name):
                            rule_idx += 1
                            rules.append({
                                "id": f"SPEC-EXPOSE-{rule_idx:03d}",
                                "name": f"sensitive-response-{slug}-{_sanitize(prop_name)}",
                                "description": f"Response {status_code} of {method.upper()} {path_str} exposes sensitive field '{prop_name}'",
                                "type": "documentation_obligation",
                                "severity": "high",
                                "standard": pack_name,
                                "clause": f"{method.upper()} {path_str} → {status_code} → {prop_name}",
                                "compliance_category": "code",
                                "remediation_guidance": f"Review whether '{prop_name}' should be in the response. Consider removing it, masking it, or adding an explicit data classification.",
                                "tags": ["spec-import", "openapi", "data-exposure"],
                            })

            # Rule 4: path parameter injection — require validation in code
            path_params = _PATH_PARAM_RE.findall(path_str)
            for param in path_params:
                param_defs = operation.get("parameters", []) + path_item.get("parameters", [])
                param_def = next(
                    (p for p in param_defs if isinstance(p, dict) and p.get("name") == param),
                    None,
                )
                has_constraints = False
                if param_def:
                    schema = param_def.get("schema", {})
                    has_constraints = any(
                        k in schema for k in ("pattern", "enum", "minimum", "maximum", "maxLength", "format")
                    )
                if not has_constraints:
                    rule_idx += 1
                    rules.append({
                        "id": f"SPEC-PARAM-{rule_idx:03d}",
                        "name": f"validate-param-{slug}-{_sanitize(param)}",
                        "description": f"Path parameter '{{{param}}}' in {method.upper()} {path_str} has no validation constraints",
                        "type": "documentation_obligation",
                        "severity": "medium",
                        "standard": pack_name,
                        "clause": f"{method.upper()} {path_str} → {{{param}}}",
                        "compliance_category": "code",
                        "remediation_guidance": f"Add format, pattern, enum, or min/max constraints to parameter '{param}' in the spec, and validate in the route handler.",
                        "tags": ["spec-import", "openapi", "input-validation", "path-params"],
                    })

    # Rule: HTTPS enforcement
    servers = raw.get("servers", [])
    for server in servers:
        url = server.get("url", "") if isinstance(server, dict) else ""
        if url.startswith("http://"):
            rule_idx += 1
            rules.append({
                "id": f"SPEC-TLS-{rule_idx:03d}",
                "name": "require-https-server",
                "description": f"Server URL '{url}' uses HTTP instead of HTTPS",
                "type": "regex",
                "pattern": re.escape(url),
                "severity": "high",
                "file_glob": _file_glob_for_openapi(),
                "standard": pack_name,
                "clause": "servers",
                "compliance_category": "code",
                "remediation_guidance": "Change the server URL to use HTTPS. Never use plain HTTP for API traffic.",
                "tags": ["spec-import", "openapi", "tls"],
            })

    # Global: security scheme documentation obligations
    if not security_schemes:
        rule_idx += 1
        rules.append({
            "id": f"SPEC-SCHEME-{rule_idx:03d}",
            "name": "missing-security-schemes",
            "description": "The OpenAPI spec defines no security schemes — all endpoints are unauthenticated by default",
            "type": "documentation_obligation",
            "severity": "high",
            "standard": pack_name,
            "clause": "components.securitySchemes",
            "compliance_category": "process",
            "remediation_guidance": "Define security schemes (bearer token, OAuth2, API key) in the OpenAPI spec under components.securitySchemes.",
            "tags": ["spec-import", "openapi", "authentication"],
        })

    return {"name": pack_name, "description": description, "rules": rules}


def _path_to_regex(path_str: str) -> str:
    """Convert an OpenAPI path like /users/{id} to a regex."""
    parts = _PATH_PARAM_RE.sub(r"[^/]+", re.escape(path_str))
    return parts


def _sanitize(name: str) -> str:
    """Sanitize a name for use in rule IDs."""
    return re.sub(r"[^a-zA-Z0-9]", "-", name).strip("-").lower()[:40]


def _resolve_ref(ref: str, root: dict) -> dict[str, Any]:
    """Resolve a $ref pointer like '#/components/schemas/User'."""
    if not ref.startswith("#/"):
        return {}
    parts = ref[2:].split("/")
    node = root
    for part in parts:
        if isinstance(node, dict):
            node = node.get(part, {})
        else:
            return {}
    return node if isinstance(node, dict) else {}


def _extract_schemas_from_content(
    content: dict, root: dict
) -> list[tuple[str, dict[str, Any]]]:
    """Extract (schema_name, properties) from a content map."""
    results = []
    if not isinstance(content, dict):
        return results
    for media_type, media_obj in content.items():
        if not isinstance(media_obj, dict):
            continue
        schema = media_obj.get("schema", {})
        if "$ref" in schema:
            schema = _resolve_ref(schema["$ref"], root)
        props = schema.get("properties", {})
        name = schema.get("title", "")
        if props:
            results.append((name, props))
    return results


# ---------------------------------------------------------------------------
# AsyncAPI → rules
# ---------------------------------------------------------------------------


def import_asyncapi(path: Path) -> dict[str, Any]:
    """Parse an AsyncAPI 2.x/3.x spec and generate a Sentrik rule pack."""
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    title = raw.get("info", {}).get("title", path.stem)
    version = raw.get("info", {}).get("version", "")
    pack_name = f"AsyncAPI: {title}"
    description = f"Security rules derived from AsyncAPI spec '{title}' v{version}"

    rules: list[dict[str, Any]] = []
    rule_idx = 0
    channels = raw.get("channels", {})

    for channel_name, channel_def in channels.items():
        if not isinstance(channel_def, dict):
            continue

        slug = _sanitize(channel_name)

        # Check for missing security on channel bindings
        bindings = channel_def.get("bindings", {})
        has_security = bool(channel_def.get("security"))

        if not has_security:
            rule_idx += 1
            rules.append({
                "id": f"SPEC-ASYNC-AUTH-{rule_idx:03d}",
                "name": f"channel-auth-{slug}",
                "description": f"Channel '{channel_name}' has no security defined — messages may be unauthenticated",
                "type": "documentation_obligation",
                "severity": "high",
                "standard": pack_name,
                "clause": f"channels.{channel_name}",
                "compliance_category": "code",
                "remediation_guidance": f"Add security requirements to channel '{channel_name}' or enforce authentication in message handlers.",
                "tags": ["spec-import", "asyncapi", "authentication"],
            })

        # Check subscribe/publish operations for sensitive payload fields
        for op_key in ("subscribe", "publish", "send", "receive"):
            operation = channel_def.get(op_key, {})
            if not isinstance(operation, dict):
                continue
            message = operation.get("message", {})
            if "$ref" in message:
                message = _resolve_ref(message["$ref"], raw)
            payload = message.get("payload", {})
            if "$ref" in payload:
                payload = _resolve_ref(payload["$ref"], raw)
            properties = payload.get("properties", {})

            for prop_name in properties:
                if _SENSITIVE_FIELDS.search(prop_name):
                    rule_idx += 1
                    rules.append({
                        "id": f"SPEC-ASYNC-DATA-{rule_idx:03d}",
                        "name": f"sensitive-payload-{slug}-{_sanitize(prop_name)}",
                        "description": f"Message payload on '{channel_name}' ({op_key}) contains sensitive field '{prop_name}'",
                        "type": "documentation_obligation",
                        "severity": "high",
                        "standard": pack_name,
                        "clause": f"channels.{channel_name}.{op_key} → {prop_name}",
                        "compliance_category": "code",
                        "remediation_guidance": f"Ensure '{prop_name}' is encrypted in transit and at rest. Consider whether it should be in the message payload.",
                        "tags": ["spec-import", "asyncapi", "data-exposure"],
                    })

            # Unbounded string fields in payloads
            for prop_name, prop_def in properties.items():
                if not isinstance(prop_def, dict):
                    continue
                if (
                    prop_def.get("type") == "string"
                    and "maxLength" not in prop_def
                    and "pattern" not in prop_def
                    and "enum" not in prop_def
                ):
                    rule_idx += 1
                    rules.append({
                        "id": f"SPEC-ASYNC-INPUT-{rule_idx:03d}",
                        "name": f"validate-payload-{slug}-{_sanitize(prop_name)}",
                        "description": f"Field '{prop_name}' in '{channel_name}' ({op_key}) payload is an unbounded string",
                        "type": "documentation_obligation",
                        "severity": "medium",
                        "standard": pack_name,
                        "clause": f"channels.{channel_name}.{op_key} → {prop_name}",
                        "compliance_category": "code",
                        "remediation_guidance": f"Add maxLength or pattern constraint to '{prop_name}' and validate in the message handler.",
                        "tags": ["spec-import", "asyncapi", "input-validation"],
                    })

    # Server security checks
    servers = raw.get("servers", {})
    for server_name, server_def in servers.items():
        if not isinstance(server_def, dict):
            continue
        protocol = server_def.get("protocol", "")
        if protocol in ("mqtt", "amqp", "ws", "kafka") and not server_def.get("security"):
            rule_idx += 1
            rules.append({
                "id": f"SPEC-ASYNC-SRV-{rule_idx:03d}",
                "name": f"server-security-{_sanitize(server_name)}",
                "description": f"Server '{server_name}' uses {protocol} without security definitions",
                "type": "documentation_obligation",
                "severity": "high",
                "standard": pack_name,
                "clause": f"servers.{server_name}",
                "compliance_category": "process",
                "remediation_guidance": f"Add security scheme to server '{server_name}' or use the secure variant ({protocol}s/TLS).",
                "tags": ["spec-import", "asyncapi", "authentication", "tls"],
            })

    return {"name": pack_name, "description": description, "rules": rules}


# ---------------------------------------------------------------------------
# Protobuf → rules
# ---------------------------------------------------------------------------

# Lightweight .proto parser — no dependency on protoc/grpcio-tools
_PROTO_MESSAGE_RE = re.compile(r"message\s+(\w+)\s*\{([^}]*)\}", re.DOTALL)
_PROTO_FIELD_RE = re.compile(
    r"(?:repeated\s+|optional\s+|required\s+)?(\w+)\s+(\w+)\s*=\s*(\d+)"
)
_PROTO_SERVICE_RE = re.compile(r"service\s+(\w+)\s*\{([^}]*)\}", re.DOTALL)
_PROTO_RPC_RE = re.compile(
    r"rpc\s+(\w+)\s*\(\s*(\w+)\s*\)\s+returns\s*\(\s*(\w+)\s*\)"
)
_PROTO_PACKAGE_RE = re.compile(r"package\s+([\w.]+)\s*;")


def import_protobuf(path: Path) -> dict[str, Any]:
    """Parse a .proto file and generate a Sentrik rule pack."""
    text = path.read_text(encoding="utf-8")
    package = ""
    m = _PROTO_PACKAGE_RE.search(text)
    if m:
        package = m.group(1)
    pack_name = f"Protobuf: {package or path.stem}"
    description = f"Security rules derived from protobuf spec '{package or path.stem}'"

    rules: list[dict[str, Any]] = []
    rule_idx = 0

    # Parse messages for sensitive fields
    for msg_match in _PROTO_MESSAGE_RE.finditer(text):
        msg_name = msg_match.group(1)
        msg_body = msg_match.group(2)
        slug = _sanitize(msg_name)

        for field_match in _PROTO_FIELD_RE.finditer(msg_body):
            field_type = field_match.group(1)
            field_name = field_match.group(2)

            # Sensitive field detection
            if _SENSITIVE_FIELDS.search(field_name):
                rule_idx += 1
                rules.append({
                    "id": f"SPEC-PROTO-DATA-{rule_idx:03d}",
                    "name": f"sensitive-field-{slug}-{_sanitize(field_name)}",
                    "description": f"Message '{msg_name}' contains sensitive field '{field_name}' — ensure encryption and access control",
                    "type": "regex",
                    "pattern": f"\\b{re.escape(field_name)}\\b",
                    "severity": "medium",
                    "file_glob": "**/*.proto",
                    "standard": pack_name,
                    "clause": f"message {msg_name}.{field_name}",
                    "compliance_category": "code",
                    "remediation_guidance": f"Ensure '{field_name}' in message '{msg_name}' is encrypted in transit (TLS) and at rest. Consider using a wrapper type or field-level encryption.",
                    "tags": ["spec-import", "protobuf", "data-exposure"],
                })

            # Unbounded string fields
            if field_type == "string":
                rule_idx += 1
                rules.append({
                    "id": f"SPEC-PROTO-STR-{rule_idx:03d}",
                    "name": f"unbounded-string-{slug}-{_sanitize(field_name)}",
                    "description": f"String field '{field_name}' in message '{msg_name}' has no validation — may allow oversized payloads",
                    "type": "documentation_obligation",
                    "severity": "low",
                    "standard": pack_name,
                    "clause": f"message {msg_name}.{field_name}",
                    "compliance_category": "code",
                    "remediation_guidance": f"Add application-level validation for '{field_name}' length and format in service handlers.",
                    "tags": ["spec-import", "protobuf", "input-validation"],
                })

    # Parse services for RPC auth obligations
    for svc_match in _PROTO_SERVICE_RE.finditer(text):
        svc_name = svc_match.group(1)
        svc_body = svc_match.group(2)
        svc_slug = _sanitize(svc_name)

        for rpc_match in _PROTO_RPC_RE.finditer(svc_body):
            rpc_name = rpc_match.group(1)
            req_type = rpc_match.group(2)
            resp_type = rpc_match.group(3)
            rule_idx += 1
            rules.append({
                "id": f"SPEC-PROTO-RPC-{rule_idx:03d}",
                "name": f"rpc-auth-{svc_slug}-{_sanitize(rpc_name)}",
                "description": f"RPC '{svc_name}.{rpc_name}' must enforce authentication and authorization",
                "type": "documentation_obligation",
                "severity": "medium",
                "standard": pack_name,
                "clause": f"service {svc_name}.{rpc_name}",
                "compliance_category": "code",
                "remediation_guidance": f"Add authentication interceptor/middleware to '{rpc_name}'. Validate caller identity and permissions before processing {req_type}.",
                "tags": ["spec-import", "protobuf", "authentication"],
            })

    return {"name": pack_name, "description": description, "rules": rules}


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

_IMPORTERS = {
    "openapi": import_openapi,
    "asyncapi": import_asyncapi,
    "protobuf": import_protobuf,
}


def import_spec(path: Path, fmt: str | None = None) -> dict[str, Any]:
    """Import a spec file and return a pack dict.

    Raises ``ValueError`` if the format is unsupported or undetectable.
    """
    if fmt is None:
        fmt = detect_format(path)
    if fmt is None or fmt not in _IMPORTERS:
        raise ValueError(
            f"Cannot detect spec format for {path.name}. "
            f"Use --format with one of: {', '.join(SUPPORTED_FORMATS)}"
        )
    return _IMPORTERS[fmt](path)
