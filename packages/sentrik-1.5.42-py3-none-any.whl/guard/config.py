"""Configuration loading for AI SDLC Guard."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Optional

import yaml
from pydantic import BaseModel, Field

CONFIG_FILENAME = ".guard.yaml"
SENTRIK_CONFIG_DIR = ".sentrik"
SENTRIK_CONFIG_FILENAME = ".sentrik/config.yaml"

VALID_SEVERITIES = {"critical", "high", "medium", "low", "info"}
VALID_PROVIDERS = {"stub", "sarif", "composite"}
VALID_REPORTERS = {"html", "junit", "sarif", "csv"}
VALID_LLM_PROVIDERS = {"stub", "anthropic", "openai", "ollama"}
VALID_DEVOPS_PROVIDERS = {"stub", "azure", "github", "jira"}
VALID_STANDARDS_PROVIDERS = {"stub", "azure", "github", "jira"}


class ConfigWarning(BaseModel):
    """A single configuration validation warning."""

    field: str
    message: str
    level: str = "warning"  # "warning" or "error"
    hint: str = ""  # Plain-language explanation for non-technical users


def resolve_config_path(explicit: Path | None = None) -> Path | None:
    """Find the config file using resolution order.

    Order: explicit path → .sentrik/config.yaml → .guard.yaml → None (auto-detect).
    Returns ``None`` when no config file exists on disk (caller should auto-detect).
    """
    if explicit is not None:
        return explicit if explicit.exists() else explicit  # caller asked for it

    sentrik_path = Path(SENTRIK_CONFIG_FILENAME)
    if sentrik_path.exists():
        return sentrik_path

    guard_path = Path(CONFIG_FILENAME)
    if guard_path.exists():
        return guard_path

    return None  # no config on disk


def ensure_sentrik_dir(base_dir: Path | None = None) -> Path:
    """Create the ``.sentrik/`` directory structure and return its path.

    Creates:
      .sentrik/
        config.yaml   (caller writes this)
        rules/        (custom rules)
        .gitignore    (ignores local/)
        local/        (machine-local state, not committed)
    """
    if base_dir is None:
        base_dir = Path(".")
    sentrik_dir = base_dir / SENTRIK_CONFIG_DIR
    sentrik_dir.mkdir(exist_ok=True)
    (sentrik_dir / "rules").mkdir(exist_ok=True)
    (sentrik_dir / "local").mkdir(exist_ok=True)

    gitignore = sentrik_dir / ".gitignore"
    if not gitignore.exists():
        gitignore.write_text("local/\n", encoding="utf-8")

    return sentrik_dir


class GuardConfig(BaseModel):
    output_dir: str = "out"
    standards_file: str = "examples/sample_standards.yaml"
    work_items_file: str = "examples/sample_work_items.json"
    llm_enabled: bool = False
    llm_provider: str = "stub"
    llm_model: str = ""
    llm_base_url: str = ""
    confidence_scoring_enabled: bool = False
    confidence_scoring_max_findings: int = 50
    provider: str = "stub"
    sarif_files: list[str] = Field(default_factory=list)
    reporters: list[str] = Field(default_factory=list)
    cache_enabled: bool = False
    cache_dir: str = ".guard_cache"
    gate_fail_on: list[str] = Field(
        default_factory=lambda: ["critical", "high"]
    )
    devops_provider: str = "stub"
    azure_devops_org: str = ""
    azure_devops_project: str = ""
    azure_devops_team: str = ""
    azure_devops_iteration: str = ""
    azure_devops_repo: str = ""
    azure_devops_work_item_type: str = "Issue"
    azure_devops_work_item_types: list[str] = Field(default_factory=list)
    jira_issue_types: list[str] = Field(default_factory=list)
    standards_provider: str = "stub"
    azure_devops_standards_repo: str = ""
    azure_devops_standards_file: str = "standards.yaml"
    github_owner: str = ""
    github_repo: str = ""
    github_label: str = ""
    github_milestone: str = ""
    github_standards_repo: str = ""
    github_standards_file: str = "standards.yaml"
    github_standards_ref: str = "main"
    jira_base_url: str = ""
    jira_project_key: str = ""
    jira_jql: str = ""
    jira_standards_issue_key: str = ""
    standards_packs: list[str] = Field(default_factory=list)  # e.g. ["fda-iec-62304"]
    pack_overrides: dict[str, dict[str, dict[str, Any]]] = Field(default_factory=dict)
    severity_rescoring_enabled: bool = False
    ml_severity_enabled: bool = False  # backward-compat alias for severity_rescoring_enabled
    parallel_scan: bool = False
    max_workers: int = 4
    agent_scan: bool = False
    agent_max_concurrency: int = 0  # 0 = one thread per pack (auto)
    governance: dict[str, Any] = Field(default_factory=dict)
    license_key: str = ""
    auth: dict[str, Any] = Field(default_factory=dict)  # Auth0/Okta config
    scan_exclude: list[str] = Field(default_factory=lambda: [
        "node_modules/", "vcpkg/", "vendor/", "third_party/",
        ".venv/", "venv/", "__pycache__/", ".git/",
        "dist/", "build/", ".tox/", ".mypy_cache/",
    ])
    suppressions: list[dict[str, Any]] = Field(default_factory=list)
    oauth: dict[str, Any] = Field(default_factory=dict)  # OAuth config per provider
    async_approval: dict[str, Any] = Field(default_factory=dict)
    notifications: dict[str, Any] = Field(default_factory=lambda: {
        "slack_webhook_url": "",
        "teams_webhook_url": "",
        "notify_on": ["gate_failed"],
    })
    online_license_check: bool = True
    portal_url: str = "https://portal.sentrik.dev"
    requirements_output_file: str = "requirements.yaml"
    cpp_analysis_enabled: bool = False
    cpp_analysis_tool: str = "clang-tidy"  # "clang-tidy", "cppcheck", or "both"
    cpp_analysis_checks: str = ""  # empty = use defaults
    grc_webhook_url: str = ""
    grc_platform: str = "generic"
    grc_events: list[str] = Field(default_factory=list)
    requirement_coverage_enabled: bool = False
    requirement_coverage_exclude: list[str] = Field(default_factory=lambda: [
        "tests/*", "test_*", "*.md", "*.txt", "*.yaml", "*.yml",
        "*.json", "*.toml", "*.cfg", "*.ini", "*.lock",
        "__init__.py", "__pycache__/*", "*.pyc", "*.pyo",
        "*.db", "*.db-shm", "*.db-wal", "*.sqlite*",
        "out/*", "dist/*", "build/*", "*.egg-info/*",
        "*.patch", "*.html", "*.css", "*.min.*",
    ])

    @property
    def is_severity_rescoring_enabled(self) -> bool:
        """Whether severity rescoring is enabled.

        Returns True if either ``severity_rescoring_enabled`` (canonical) or
        ``ml_severity_enabled`` (legacy alias) is True, providing full
        backward compatibility.
        """
        return self.severity_rescoring_enabled or self.ml_severity_enabled

    @classmethod
    def from_profile(cls, profile) -> "GuardConfig":
        """Create a GuardConfig from a :class:`~guard.core.auto_detect.ProjectProfile`.

        Maps detected project characteristics to sensible config defaults.
        """
        data: dict[str, Any] = {
            "standards_packs": list(profile.suggested_packs),
            "governance": {"profile": profile.governance_profile},
        }

        if profile.ci_platform == "azure":
            data["devops_provider"] = "azure"
        elif profile.ci_platform == "github":
            data["devops_provider"] = "github"

        return cls(**data)

    @classmethod
    def load(cls, path: Optional[Path] = None) -> GuardConfig:
        resolved = resolve_config_path(path)
        if resolved is not None and resolved.exists():
            with open(resolved) as f:
                data = yaml.safe_load(f) or {}
        elif path is not None and path.exists():
            with open(path) as f:
                data = yaml.safe_load(f) or {}
        else:
            data = {}

        # Apply GUARD_* environment variable overrides
        env_map = {
            "GUARD_OUTPUT_DIR": "output_dir",
            "GUARD_STANDARDS_FILE": "standards_file",
            "GUARD_WORK_ITEMS_FILE": "work_items_file",
            "GUARD_PROVIDER": "provider",
            "GUARD_DEVOPS_PROVIDER": "devops_provider",
            "GUARD_AZURE_DEVOPS_ORG": "azure_devops_org",
            "GUARD_AZURE_DEVOPS_PROJECT": "azure_devops_project",
            "GUARD_AZURE_DEVOPS_TEAM": "azure_devops_team",
            "GUARD_AZURE_DEVOPS_ITERATION": "azure_devops_iteration",
            "GUARD_AZURE_DEVOPS_REPO": "azure_devops_repo",
            "GUARD_STANDARDS_PROVIDER": "standards_provider",
            "GUARD_AZURE_DEVOPS_STANDARDS_REPO": "azure_devops_standards_repo",
            "GUARD_AZURE_DEVOPS_STANDARDS_FILE": "azure_devops_standards_file",
            "GUARD_GITHUB_OWNER": "github_owner",
            "GUARD_GITHUB_REPO": "github_repo",
            "GUARD_GITHUB_LABEL": "github_label",
            "GUARD_GITHUB_MILESTONE": "github_milestone",
            "GUARD_GITHUB_STANDARDS_REPO": "github_standards_repo",
            "GUARD_GITHUB_STANDARDS_FILE": "github_standards_file",
            "GUARD_GITHUB_STANDARDS_REF": "github_standards_ref",
            "GUARD_JIRA_BASE_URL": "jira_base_url",
            "GUARD_JIRA_PROJECT_KEY": "jira_project_key",
            "GUARD_JIRA_JQL": "jira_jql",
            "GUARD_JIRA_STANDARDS_ISSUE_KEY": "jira_standards_issue_key",
            "GUARD_REQUIREMENTS_FILE": "requirements_output_file",
            "GUARD_AZURE_DEVOPS_WORK_ITEM_TYPE": "azure_devops_work_item_type",
        }
        for env_key, field_name in env_map.items():
            val = os.environ.get(env_key)
            if val is not None:
                data[field_name] = val

        gate_fail_on_env = os.environ.get("GUARD_GATE_FAIL_ON")
        if gate_fail_on_env is not None:
            data["gate_fail_on"] = [
                s.strip() for s in gate_fail_on_env.split(",") if s.strip()
            ]

        wi_types_env = os.environ.get("GUARD_AZURE_DEVOPS_WORK_ITEM_TYPES")
        if wi_types_env is not None:
            data["azure_devops_work_item_types"] = [
                s.strip() for s in wi_types_env.split(",") if s.strip()
            ]

        jira_types_env = os.environ.get("GUARD_JIRA_ISSUE_TYPES")
        if jira_types_env is not None:
            data["jira_issue_types"] = [
                s.strip() for s in jira_types_env.split(",") if s.strip()
            ]

        standards_packs_env = os.environ.get("GUARD_STANDARDS_PACKS")
        if standards_packs_env is not None:
            data["standards_packs"] = [
                s.strip() for s in standards_packs_env.split(",") if s.strip()
            ]

        # Severity rescoring: new canonical env var + legacy alias
        severity_rescoring_env = os.environ.get("GUARD_SEVERITY_RESCORING_ENABLED")
        if severity_rescoring_env is not None:
            data["severity_rescoring_enabled"] = severity_rescoring_env.lower() in ("1", "true", "yes")

        ml_severity_env = os.environ.get("GUARD_ML_SEVERITY_ENABLED")
        if ml_severity_env is not None:
            data["ml_severity_enabled"] = ml_severity_env.lower() in ("1", "true", "yes")

        parallel_env = os.environ.get("GUARD_PARALLEL_SCAN")
        if parallel_env is not None:
            data["parallel_scan"] = parallel_env.lower() in ("1", "true", "yes")

        max_workers_env = os.environ.get("GUARD_MAX_WORKERS")
        if max_workers_env is not None:
            try:
                data["max_workers"] = int(max_workers_env)
            except ValueError:
                pass

        agent_scan_env = os.environ.get("GUARD_AGENT_SCAN")
        if agent_scan_env is not None:
            data["agent_scan"] = agent_scan_env.lower() in ("1", "true", "yes")

        agent_concurrency_env = os.environ.get("GUARD_AGENT_MAX_CONCURRENCY")
        if agent_concurrency_env is not None:
            try:
                data["agent_max_concurrency"] = int(agent_concurrency_env)
            except ValueError:
                pass

        # LLM provider overrides
        llm_provider_env = os.environ.get("GUARD_LLM_PROVIDER")
        if llm_provider_env:
            data["llm_provider"] = llm_provider_env
        llm_model_env = os.environ.get("GUARD_LLM_MODEL")
        if llm_model_env:
            data["llm_model"] = llm_model_env
        llm_base_url_env = os.environ.get("GUARD_LLM_BASE_URL")
        if llm_base_url_env:
            data["llm_base_url"] = llm_base_url_env

        # Confidence scoring overrides
        cs_env = os.environ.get("GUARD_CONFIDENCE_SCORING_ENABLED")
        if cs_env is not None:
            data["confidence_scoring_enabled"] = cs_env.lower() in ("1", "true", "yes")
        cs_max_env = os.environ.get("GUARD_CONFIDENCE_SCORING_MAX_FINDINGS")
        if cs_max_env is not None:
            try:
                data["confidence_scoring_max_findings"] = int(cs_max_env)
            except ValueError:
                pass

        # Governance profile override
        gov_profile = os.environ.get("GUARD_GOVERNANCE_PROFILE")
        if gov_profile:
            gov = data.get("governance", {})
            if not isinstance(gov, dict):
                gov = {}
            gov["profile"] = gov_profile
            data["governance"] = gov

        # License key: env var → .sentrik/local/license.key file → config
        license_key_env = os.environ.get("GUARD_LICENSE_KEY")
        if license_key_env:
            data["license_key"] = license_key_env
        elif not data.get("license_key"):
            trial_key_path = Path(SENTRIK_CONFIG_DIR) / "local" / "license.key"
            if trial_key_path.exists():
                try:
                    key = trial_key_path.read_text(encoding="utf-8").strip()
                    if key:
                        data["license_key"] = key
                except OSError:
                    pass

        # Online license check
        online_check_env = os.environ.get("GUARD_ONLINE_LICENSE_CHECK")
        if online_check_env is not None:
            data["online_license_check"] = online_check_env.lower() in ("1", "true", "yes")

        portal_url_env = os.environ.get("GUARD_PORTAL_URL")
        if portal_url_env:
            data["portal_url"] = portal_url_env

        # C/C++ analysis overrides
        cpp_enabled_env = os.environ.get("GUARD_CPP_ANALYSIS_ENABLED")
        if cpp_enabled_env is not None:
            data["cpp_analysis_enabled"] = cpp_enabled_env.lower() in ("1", "true", "yes")

        cpp_tool_env = os.environ.get("GUARD_CPP_ANALYSIS_TOOL")
        if cpp_tool_env:
            data["cpp_analysis_tool"] = cpp_tool_env

        cpp_checks_env = os.environ.get("GUARD_CPP_ANALYSIS_CHECKS")
        if cpp_checks_env:
            data["cpp_analysis_checks"] = cpp_checks_env

        # GRC integration overrides
        grc_url_env = os.environ.get("GUARD_GRC_WEBHOOK_URL")
        if grc_url_env:
            data["grc_webhook_url"] = grc_url_env
        grc_platform_env = os.environ.get("GUARD_GRC_PLATFORM")
        if grc_platform_env:
            data["grc_platform"] = grc_platform_env
        grc_events_env = os.environ.get("GUARD_GRC_EVENTS")
        if grc_events_env:
            data["grc_events"] = [e.strip() for e in grc_events_env.split(",") if e.strip()]

        # Notification webhook overrides
        slack_url_env = os.environ.get("GUARD_SLACK_WEBHOOK_URL")
        teams_url_env = os.environ.get("GUARD_TEAMS_WEBHOOK_URL")
        if slack_url_env or teams_url_env:
            notif = data.get("notifications", {})
            if not isinstance(notif, dict):
                notif = {}
            if slack_url_env:
                notif["slack_webhook_url"] = slack_url_env
            if teams_url_env:
                notif["teams_webhook_url"] = teams_url_env
            data["notifications"] = notif

        # Auth configuration overrides
        auth_enabled_env = os.environ.get("GUARD_AUTH_ENABLED")
        if auth_enabled_env is not None:
            auth = data.get("auth", {})
            if not isinstance(auth, dict):
                auth = {}
            auth["enabled"] = auth_enabled_env.lower() in ("1", "true", "yes")
            data["auth"] = auth

        auth_env_map = {
            "GUARD_AUTH_PROVIDER": "provider",
            "GUARD_AUTH0_DOMAIN": "auth0_domain",
            "GUARD_AUTH0_CLIENT_ID": "auth0_client_id",
            "GUARD_AUTH0_AUDIENCE": "auth0_audience",
        }
        for env_key, field_name in auth_env_map.items():
            val = os.environ.get(env_key)
            if val is not None:
                auth = data.get("auth", {})
                if not isinstance(auth, dict):
                    auth = {}
                auth[field_name] = val
                data["auth"] = auth

        # Async approval configuration overrides
        approval_enabled_env = os.environ.get("GUARD_APPROVAL_ENABLED")
        if approval_enabled_env is not None:
            approval = data.get("async_approval", {})
            if not isinstance(approval, dict):
                approval = {}
            approval["enabled"] = approval_enabled_env.lower() in ("1", "true", "yes")
            data["async_approval"] = approval

        approval_timeout_env = os.environ.get("GUARD_APPROVAL_TIMEOUT")
        if approval_timeout_env is not None:
            approval = data.get("async_approval", {})
            if not isinstance(approval, dict):
                approval = {}
            try:
                approval["timeout_seconds"] = int(approval_timeout_env)
            except ValueError:
                pass
            data["async_approval"] = approval

        return cls(**data)

    def get_auth_config(self):
        """Build and return the AuthConfig from raw auth dict."""
        from guard.auth.models import AuthConfig
        return AuthConfig(**(self.auth if isinstance(self.auth, dict) else {}))

    def get_async_approval_config(self):
        """Build and return the AsyncApprovalConfig from raw async_approval dict."""
        from guard.core.approvals import AsyncApprovalConfig
        return AsyncApprovalConfig(**(self.async_approval if isinstance(self.async_approval, dict) else {}))

    def save(self, path: Optional[Path] = None) -> Path:
        if path is None:
            # Save back to whichever config file exists on disk,
            # defaulting to .sentrik/config.yaml for new projects.
            existing = resolve_config_path()
            path = existing if existing is not None else Path(SENTRIK_CONFIG_FILENAME)
        # Ensure parent directory exists
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            yaml.dump(
                self.model_dump(),
                f,
                default_flow_style=False,
                sort_keys=False,
            )
        return path

    def validate_config(self) -> list[ConfigWarning]:
        """Validate configuration and return a list of warnings/errors.

        Returns an empty list when everything is valid.
        """
        warnings: list[ConfigWarning] = []

        # Validate severity values in gate_fail_on
        for sev in self.gate_fail_on:
            if sev not in VALID_SEVERITIES:
                warnings.append(ConfigWarning(
                    field="gate_fail_on",
                    message=f"Unknown severity {sev!r}; valid: {', '.join(sorted(VALID_SEVERITIES))}",
                    level="error",
                    hint=f"The gate uses severity levels to decide pass/fail. '{sev}' is not a recognized level — check for typos in your config.",
                ))

        # Validate provider
        if self.provider not in VALID_PROVIDERS:
            warnings.append(ConfigWarning(
                field="provider",
                message=f"Unknown provider {self.provider!r}; valid: {', '.join(sorted(VALID_PROVIDERS))}",
                level="error",
                hint="The scanner provider controls how code is analyzed. Use 'stub' for built-in rules only, 'sarif' to import external tool results, or 'composite' for both.",
            ))

        # Validate llm_provider
        if self.llm_provider not in VALID_LLM_PROVIDERS:
            warnings.append(ConfigWarning(
                field="llm_provider",
                message=f"Unknown LLM provider {self.llm_provider!r}; valid: {', '.join(sorted(VALID_LLM_PROVIDERS))}",
                level="error",
                hint="The LLM provider is an optional AI-powered scanner. Most users don't need this — use 'stub' to disable it.",
            ))

        # Validate reporter names
        for name in self.reporters:
            if name not in VALID_REPORTERS:
                warnings.append(ConfigWarning(
                    field="reporters",
                    message=f"Unknown reporter {name!r}; valid: {', '.join(sorted(VALID_REPORTERS))}",
                    level="warning",
                    hint=f"Reporters generate output files in different formats (HTML, JUnit, SARIF, CSV). '{name}' is not recognized — check your config for typos.",
                ))

        # Validate devops_provider
        if self.devops_provider not in VALID_DEVOPS_PROVIDERS:
            warnings.append(ConfigWarning(
                field="devops_provider",
                message=f"Unknown devops provider {self.devops_provider!r}; valid: {', '.join(sorted(VALID_DEVOPS_PROVIDERS))}",
                level="error",
                hint="The DevOps provider connects to your project management tool (Azure DevOps, GitHub, or Jira) for work item tracking. Use 'stub' if you don't need this.",
            ))

        if self.devops_provider == "azure":
            if not self.azure_devops_org:
                warnings.append(ConfigWarning(
                    field="azure_devops_org",
                    message="Azure DevOps provider selected but azure_devops_org is empty",
                    level="warning",
                    hint="To connect to Azure DevOps for work item tracking, provide your organization name (e.g. 'mycompany'). You can set this in the DevOps tab or in your config file.",
                ))
            if not self.azure_devops_project:
                warnings.append(ConfigWarning(
                    field="azure_devops_project",
                    message="Azure DevOps provider selected but azure_devops_project is empty",
                    level="warning",
                    hint="Provide your Azure DevOps project name so SENTRIK can read and sync work items. Set this in the DevOps tab or config file.",
                ))

        # Validate standards_provider
        if self.standards_provider not in VALID_STANDARDS_PROVIDERS:
            warnings.append(ConfigWarning(
                field="standards_provider",
                message=f"Unknown standards provider {self.standards_provider!r}; valid: {', '.join(sorted(VALID_STANDARDS_PROVIDERS))}",
                level="error",
                hint="The standards provider determines where your coding rules come from. Use 'stub' to load rules from local files and built-in packs.",
            ))

        if self.standards_provider == "azure":
            if not self.azure_devops_standards_repo:
                warnings.append(ConfigWarning(
                    field="azure_devops_standards_repo",
                    message="Azure standards provider selected but azure_devops_standards_repo is empty",
                    level="warning",
                    hint="To load coding standards from an Azure DevOps repo, specify which repository contains your standards YAML file.",
                ))
            if not self.azure_devops_org:
                warnings.append(ConfigWarning(
                    field="azure_devops_org",
                    message="Azure standards provider selected but azure_devops_org is empty",
                    level="warning",
                    hint="Provide your Azure DevOps organization name so SENTRIK can fetch standards from your repo.",
                ))
            if not self.azure_devops_project:
                warnings.append(ConfigWarning(
                    field="azure_devops_project",
                    message="Azure standards provider selected but azure_devops_project is empty",
                    level="warning",
                    hint="Provide your Azure DevOps project name so SENTRIK can fetch standards from your repo.",
                ))

        if self.devops_provider == "github":
            if not self.github_owner:
                warnings.append(ConfigWarning(
                    field="github_owner",
                    message="GitHub devops provider selected but github_owner is empty",
                    level="warning",
                    hint="Provide the GitHub owner (user or organization) for the repository you want to track issues from. Set this in the DevOps tab or config file.",
                ))
            if not self.github_repo:
                warnings.append(ConfigWarning(
                    field="github_repo",
                    message="GitHub devops provider selected but github_repo is empty",
                    level="warning",
                    hint="Provide the GitHub repository name so SENTRIK can read and sync issues. Set this in the DevOps tab or config file.",
                ))

        if self.standards_provider == "github":
            if not self.github_owner:
                warnings.append(ConfigWarning(
                    field="github_owner",
                    message="GitHub standards provider selected but github_owner is empty",
                    level="warning",
                    hint="Provide the GitHub owner so SENTRIK can fetch your coding standards file from the repository.",
                ))
            if not self.github_standards_repo:
                warnings.append(ConfigWarning(
                    field="github_standards_repo",
                    message="GitHub standards provider selected but github_standards_repo is empty",
                    level="warning",
                    hint="Specify which GitHub repository contains your standards YAML file.",
                ))

        if self.devops_provider == "jira":
            if not self.jira_base_url:
                warnings.append(ConfigWarning(
                    field="jira_base_url",
                    message="Jira devops provider selected but jira_base_url is empty",
                    level="warning",
                    hint="Provide your Jira instance URL (e.g. 'https://yourteam.atlassian.net') so SENTRIK can connect to your project.",
                ))
            if not self.jira_project_key:
                warnings.append(ConfigWarning(
                    field="jira_project_key",
                    message="Jira devops provider selected but jira_project_key is empty",
                    level="warning",
                    hint="Provide your Jira project key (e.g. 'PROJ') so SENTRIK can read and sync issues from the right project.",
                ))

        if self.standards_provider == "jira":
            if not self.jira_base_url:
                warnings.append(ConfigWarning(
                    field="jira_base_url",
                    message="Jira standards provider selected but jira_base_url is empty",
                    level="warning",
                    hint="Provide your Jira instance URL so SENTRIK can fetch your coding standards from a Jira issue.",
                ))
            if not self.jira_standards_issue_key:
                warnings.append(ConfigWarning(
                    field="jira_standards_issue_key",
                    message="Jira standards provider selected but jira_standards_issue_key is empty",
                    level="warning",
                    hint="Specify the Jira issue key (e.g. 'PROJ-123') that contains your standards YAML in its description or attachment.",
                ))

        # Check file existence (warnings, not errors — files may be created later)
        if self.standards_provider not in ("azure", "github", "jira") and not Path(self.standards_file).exists():
            warnings.append(ConfigWarning(
                field="standards_file",
                message=f"Standards file not found: {self.standards_file}",
                level="warning",
                hint="This is fine if you're using standards packs (shown in the Packs tab). A custom standards file is only needed if you want to define your own rules beyond what the packs provide.",
            ))

        if self.devops_provider == "stub" and not Path(self.work_items_file).exists():
            warnings.append(ConfigWarning(
                field="work_items_file",
                message=f"Work items file not found: {self.work_items_file}",
                level="warning",
                hint="No work items file was found, but this is normal. Work items are only needed for traceability features that link findings to tasks. You can ignore this if you're just running scans.",
            ))

        for sarif_path in self.sarif_files:
            if not Path(sarif_path).exists():
                warnings.append(ConfigWarning(
                    field="sarif_files",
                    message=f"SARIF file not found: {sarif_path}",
                    level="warning",
                    hint="A SARIF file listed in your config doesn't exist on disk. Make sure external tools (e.g. ESLint, Semgrep) have run and produced output before scanning.",
                ))

        # Validate standards_packs
        from guard.packs.registry import _BUILTIN_PACKS, is_known_pack
        for pack_name in self.standards_packs:
            if not is_known_pack(pack_name):
                warnings.append(ConfigWarning(
                    field="standards_packs",
                    message=f"Unknown standards pack {pack_name!r}; available: {', '.join(sorted(_BUILTIN_PACKS))}",
                    level="warning",
                    hint=f"The pack '{pack_name}' is not recognized. Check for typos or visit the Packs tab to see available standards packs.",
                ))

        # Validate pack_overrides
        for pack_name, rule_overrides in self.pack_overrides.items():
            if not is_known_pack(pack_name):
                warnings.append(ConfigWarning(
                    field="pack_overrides",
                    message=f"Override references unknown pack {pack_name!r}",
                    level="warning",
                    hint=f"You have overrides configured for pack '{pack_name}', but that pack doesn't exist. The overrides will be ignored.",
                ))
            if not isinstance(rule_overrides, dict):
                continue
            for rule_id, overrides in rule_overrides.items():
                if not isinstance(overrides, dict):
                    continue
                if "severity" in overrides and overrides["severity"] not in VALID_SEVERITIES:
                    warnings.append(ConfigWarning(
                        field="pack_overrides",
                        message=f"Invalid severity {overrides['severity']!r} for rule {rule_id!r} in pack {pack_name!r}",
                        level="error",
                        hint=f"Severity must be one of: critical, high, medium, low, or info. Check the override for rule '{rule_id}' in your config.",
                    ))

        # Validate governance profile
        from guard.core.governance import VALID_PROFILES
        gov_data = self.governance
        if isinstance(gov_data, dict) and gov_data.get("profile"):
            if gov_data["profile"] not in VALID_PROFILES:
                warnings.append(ConfigWarning(
                    field="governance.profile",
                    message=f"Unknown governance profile {gov_data['profile']!r}; valid: {', '.join(sorted(VALID_PROFILES))}",
                    level="error",
                    hint="Governance profiles control how strictly the tool enforces rules. Choose 'strict' for maximum enforcement, 'standard' for balanced defaults, or 'permissive' for maximum flexibility.",
                ))

        # Validate composite provider has sources
        if self.provider == "composite" and not self.sarif_files and not self.llm_enabled:
            warnings.append(ConfigWarning(
                field="provider",
                message="Composite provider has no scanner sources (no sarif_files and llm_enabled=False)",
                level="warning",
                hint="The composite scanner combines results from external tools, but none are configured. Your built-in rules and standards packs still work fine. Change the provider to 'stub' in your config to remove this warning.",
            ))

        # Validate sarif provider has files
        if self.provider == "sarif" and not self.sarif_files:
            warnings.append(ConfigWarning(
                field="sarif_files",
                message="SARIF provider selected but no sarif_files configured",
                level="warning",
                hint="The SARIF provider imports results from external static analysis tools, but no SARIF files are listed. Add file paths to 'sarif_files' in your config, or change the provider to 'stub' if you only need built-in rules.",
            ))

        return warnings

    def get_governance(self):
        """Build and return the GovernanceConfig from raw governance dict."""
        from guard.core.governance import build_governance_config
        return build_governance_config(self.governance)
