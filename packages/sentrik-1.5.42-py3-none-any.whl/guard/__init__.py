"""SENTRIK — governance runtime for AI-generated code."""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("sentrik")
except PackageNotFoundError:
    __version__ = "0.0.0"
