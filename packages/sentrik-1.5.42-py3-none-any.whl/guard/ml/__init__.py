"""Heuristic severity rescoring modules for SENTRIK (no actual ML)."""
