"""Heuristic severity rescoring for findings.

Re-scores finding severity based on code context, security patterns,
file risk, and finding density using a weighted feature model.  This is
NOT a machine learning model — it uses deterministic heuristics with
configurable weights.  No external APIs, no neural networks, no model
files.  Runs entirely locally in pure Python.

The canonical config key is ``severity_rescoring_enabled`` and the
canonical env var is ``GUARD_SEVERITY_RESCORING_ENABLED``.  The legacy
names ``ml_severity_enabled`` / ``GUARD_ML_SEVERITY_ENABLED`` and the
``guard.ml`` package path are retained for backward compatibility.
"""

from __future__ import annotations

import logging
import math
import re
from dataclasses import dataclass, field
from typing import Any  # noqa: F401 — used in type annotations

from guard.core.models import Finding, Severity

logger = logging.getLogger(__name__)

# ── Feature weights (defaults) ─────────────────────────────────────────

DEFAULT_WEIGHTS: dict[str, float] = {
    "base_severity": 0.25,
    "confidence": 0.15,
    "code_context": 0.10,
    "pattern_risk": 0.10,
    "file_risk": 0.10,
    "density": 0.05,
    "exploitability": 0.15,
    "blast_radius": 0.10,
}

# ── Severity numeric mapping ───────────────────────────────────────────

_SEVERITY_SCORE: dict[str, float] = {
    "critical": 1.0,
    "high": 0.8,
    "medium": 0.5,
    "low": 0.25,
    "info": 0.1,
}

_SCORE_TO_SEVERITY: list[tuple[float, Severity]] = [
    (0.85, Severity.CRITICAL),
    (0.65, Severity.HIGH),
    (0.40, Severity.MEDIUM),
    (0.20, Severity.LOW),
    (0.0, Severity.INFO),
]

# ── High-risk patterns ─────────────────────────────────────────────────

_SECURITY_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"(?i)(password|secret|token|api.?key|credential)", re.IGNORECASE),
    re.compile(r"(?i)(sql|inject|xss|csrf)", re.IGNORECASE),
    re.compile(r"(?i)(eval|exec|subprocess|os\.system)", re.IGNORECASE),
    re.compile(r"(?i)(pickle|deserializ|marshal)", re.IGNORECASE),
]

_HIGH_RISK_FILE_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"(?i)(auth|login|session|crypt|secur)", re.IGNORECASE),
    re.compile(r"(?i)(payment|billing|checkout)", re.IGNORECASE),
    re.compile(r"(?i)(admin|config|settings)", re.IGNORECASE),
    re.compile(r"(?i)(api|endpoint|route|view)", re.IGNORECASE),
]


# ── Feature extraction ─────────────────────────────────────────────────


@dataclass
class FeatureVector:
    """Extracted features for a single finding."""

    base_severity: float = 0.0
    confidence: float = 0.5
    code_context: float = 0.0
    pattern_risk: float = 0.0
    file_risk: float = 0.0
    density: float = 0.0
    exploitability: float = 0.0
    blast_radius: float = 0.0

    def to_dict(self) -> dict[str, float]:
        return {
            "base_severity": self.base_severity,
            "confidence": self.confidence,
            "code_context": self.code_context,
            "pattern_risk": self.pattern_risk,
            "file_risk": self.file_risk,
            "density": self.density,
            "exploitability": self.exploitability,
            "blast_radius": self.blast_radius,
        }


def extract_features(
    finding: Finding,
    file_findings_count: int = 1,
    total_file_lines: int = 100,
) -> FeatureVector:
    """Extract feature vector from a finding and its context.

    Parameters
    ----------
    finding:
        The finding to extract features from.
    file_findings_count:
        Number of findings in the same file (for density calculation).
    total_file_lines:
        Total lines in the source file.
    """
    fv = FeatureVector()

    # Base severity score
    fv.base_severity = _SEVERITY_SCORE.get(finding.severity.value, 0.1)

    # Confidence pass-through
    fv.confidence = finding.confidence

    # Code context — estimate from snippet and evidence
    fv.code_context = _score_code_context(finding)

    # Pattern risk — match finding message/snippet against known risky patterns
    fv.pattern_risk = _score_pattern_risk(finding)

    # File risk — score based on file path
    fv.file_risk = _score_file_risk(finding.evidence.file)

    # Finding density — normalized count of findings in the same file
    fv.density = min(1.0, file_findings_count / max(total_file_lines / 50, 1))

    # Exploitability — how likely the finding can be reached by an attacker
    fv.exploitability = _score_exploitability(finding)

    # Blast radius — how many components/users could be affected
    fv.blast_radius = _score_blast_radius(finding)

    return fv


def _score_code_context(finding: Finding) -> float:
    """Score the code context based on evidence snippet."""
    snippet = finding.evidence.snippet
    if not snippet:
        return 0.3  # Unknown context, moderate default

    score = 0.3
    # Exception handlers suggest error-handling code (higher impact)
    if re.search(r"\bexcept\b", snippet):
        score += 0.2
    # Function definitions — issues in function signatures are impactful
    if re.search(r"\bdef\b", snippet):
        score += 0.1
    # Class definitions — affects entire class behavior
    if re.search(r"\bclass\b", snippet):
        score += 0.15
    # Import statements — affects dependencies
    if re.search(r"\bimport\b", snippet):
        score += 0.1
    # Return statements — affects control flow
    if re.search(r"\breturn\b", snippet):
        score += 0.1

    return min(1.0, score)


def _score_pattern_risk(finding: Finding) -> float:
    """Score based on whether the finding relates to known risky patterns."""
    text = f"{finding.message} {finding.evidence.snippet}"
    matches = sum(1 for pat in _SECURITY_PATTERNS if pat.search(text))
    if matches == 0:
        return 0.1
    return min(1.0, 0.3 + matches * 0.2)


def _score_file_risk(file_path: str) -> float:
    """Score based on file path (security-sensitive files score higher)."""
    matches = sum(1 for pat in _HIGH_RISK_FILE_PATTERNS if pat.search(file_path))
    if matches == 0:
        return 0.2
    return min(1.0, 0.3 + matches * 0.25)


# ── Exploitability indicators ──────────────────────────────────────

_USER_INPUT_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"(?i)(request\.(get|post|form|args|params|body|query|json))", re.IGNORECASE),
    re.compile(r"(?i)(sys\.argv|input\(|stdin)", re.IGNORECASE),
    re.compile(r"(?i)(getenv|environ\[)", re.IGNORECASE),
    re.compile(r"(?i)(req\.body|req\.params|req\.query|ctx\.request)", re.IGNORECASE),
    re.compile(r"(?i)(@RequestParam|@PathVariable|@RequestBody)", re.IGNORECASE),
]

_NETWORK_ENTRY_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"(?i)(@app\.(route|get|post|put|delete|patch))", re.IGNORECASE),
    re.compile(r"(?i)(router\.(get|post|put|delete|patch))", re.IGNORECASE),
    re.compile(r"(?i)(@(Get|Post|Put|Delete|Patch)Mapping)", re.IGNORECASE),
    re.compile(r"(?i)(def (get|post|put|delete|patch)\()", re.IGNORECASE),
    re.compile(r"(?i)(listen|bind|serve|handler)", re.IGNORECASE),
]

_PUBLIC_FACING_FILE_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"(?i)(controller|handler|view|endpoint|route|api)", re.IGNORECASE),
    re.compile(r"(?i)(public|external|gateway|webhook)", re.IGNORECASE),
]


def _score_exploitability(finding: Finding) -> float:
    """Score how easily the finding could be exploited.

    Higher score = more exploitable. Factors:
    - User-controllable input nearby (request params, argv, env vars)
    - Network entry point (route handlers, API endpoints)
    - File is public-facing (controllers, views, handlers)
    - Finding is in non-test code
    """
    score = 0.1  # baseline
    text = f"{finding.message} {finding.evidence.snippet}"
    file_path = finding.evidence.file

    # User input nearby — strongest exploitability signal
    if any(pat.search(text) for pat in _USER_INPUT_PATTERNS):
        score += 0.35

    # Network entry point
    if any(pat.search(text) for pat in _NETWORK_ENTRY_PATTERNS):
        score += 0.25

    # Public-facing file
    if any(pat.search(file_path) for pat in _PUBLIC_FACING_FILE_PATTERNS):
        score += 0.15

    # Test files are less exploitable
    if re.search(r"(?i)(test_|_test\.|/tests?/|spec_)", file_path):
        score *= 0.3

    return min(1.0, score)


# ── Blast radius indicators ──────────────────────────────────────

_SHARED_COMPONENT_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"(?i)(middleware|decorator|mixin|base|abstract|util|helper|common|shared)", re.IGNORECASE),
    re.compile(r"(?i)(interceptor|filter|plugin|hook|extension)", re.IGNORECASE),
]

_DATA_SENSITIVITY_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"(?i)(patient|medical|health|diagnosis|prescription)", re.IGNORECASE),
    re.compile(r"(?i)(payment|credit.?card|bank|financial|transaction)", re.IGNORECASE),
    re.compile(r"(?i)(personal|pii|ssn|passport|license.?number)", re.IGNORECASE),
    re.compile(r"(?i)(user|account|profile|identity|credential)", re.IGNORECASE),
]


def _score_blast_radius(finding: Finding) -> float:
    """Score how wide the impact of the finding could be.

    Higher score = larger blast radius. Factors:
    - Shared components (middleware, base classes, utils) affect many consumers
    - Data sensitivity (PII, financial, medical data)
    - File is an init/config/core module
    - Finding is in a widely-imported module
    """
    score = 0.1  # baseline
    text = f"{finding.message} {finding.evidence.snippet}"
    file_path = finding.evidence.file

    # Shared component — affects all consumers
    if any(pat.search(file_path) for pat in _SHARED_COMPONENT_PATTERNS):
        score += 0.3

    # Data sensitivity — PII/financial/medical data has regulatory blast radius
    if any(pat.search(text) for pat in _DATA_SENSITIVITY_PATTERNS):
        score += 0.25

    # Init/core modules affect the entire package
    if re.search(r"(__init__|core|main|app)\.(py|js|ts)$", file_path):
        score += 0.2

    # Config/settings files affect everything
    if re.search(r"(?i)(config|settings|env)\.(py|js|ts|yaml|yml|json)$", file_path):
        score += 0.2

    return min(1.0, score)


# ── Scoring engine ─────────────────────────────────────────────────────


def compute_score(
    features: FeatureVector,
    weights: dict[str, float] | None = None,
) -> float:
    """Compute a weighted severity score from features.

    Returns a value in [0.0, 1.0] where higher = more severe.
    """
    w = DEFAULT_WEIGHTS if weights is None else weights
    fv = features.to_dict()

    total_weight = sum(w.get(k, 0.0) for k in fv)
    if total_weight == 0:
        return 0.0

    raw_score = sum(w.get(k, 0.0) * v for k, v in fv.items()) / total_weight
    return max(0.0, min(1.0, raw_score))


def score_to_severity(score: float) -> Severity:
    """Convert a numeric score to a Severity enum."""
    for threshold, severity in _SCORE_TO_SEVERITY:
        if score >= threshold:
            return severity
    return Severity.INFO


# ── Main estimator class ───────────────────────────────────────────────


@dataclass
class SeverityEstimator:
    """Heuristic severity rescorer for findings.

    Uses a weighted feature scoring model to estimate or re-score
    finding severity.  Non-deterministic findings (e.g., from LLM
    scanners) are the primary target, but deterministic findings
    can optionally be re-scored.

    Note: The class name ``SeverityEstimator`` is retained for backward
    compatibility.  This is NOT a machine learning model.

    Parameters
    ----------
    weights:
        Custom feature weights (keys match :class:`FeatureVector` fields).
    re_score_deterministic:
        If True, also re-score deterministic findings.  Default False
        (only processes non-deterministic findings).
    min_confidence_delta:
        Minimum confidence change to trigger re-scoring.  Findings
        already at high confidence are left alone if delta is small.
    """

    weights: dict[str, float] = field(default_factory=lambda: dict(DEFAULT_WEIGHTS))
    re_score_deterministic: bool = False
    min_confidence_delta: float = 0.1

    def estimate(self, findings: list[Finding]) -> list[Finding]:
        """Re-score findings and return a new list with updated severities.

        The original finding list is not mutated.  Each finding gets:
        - Updated ``severity`` based on the ML score
        - Updated ``confidence`` reflecting the model's certainty
        - ``deterministic`` set to False (since rescoring is probabilistic)
        """
        if not findings:
            return []

        # Pre-compute per-file finding counts
        file_counts: dict[str, int] = {}
        for f in findings:
            path = f.evidence.file
            file_counts[path] = file_counts.get(path, 0) + 1

        result: list[Finding] = []
        for finding in findings:
            if finding.is_obligation:
                # Never re-score documentation obligations
                result.append(finding)
                continue

            if finding.deterministic and not self.re_score_deterministic:
                result.append(finding)
                continue

            estimated = self._estimate_single(finding, file_counts)
            result.append(estimated)

        return result

    def _estimate_single(
        self,
        finding: Finding,
        file_counts: dict[str, int],
    ) -> Finding:
        """Estimate severity for a single finding."""
        features = extract_features(
            finding,
            file_findings_count=file_counts.get(finding.evidence.file, 1),
        )

        score = compute_score(features, self.weights)
        new_severity = score_to_severity(score)
        new_confidence = _calibrate_confidence(score, finding.confidence)

        risk = {
            "score": round(score, 3),
            "exploitability": round(features.exploitability, 3),
            "blast_radius": round(features.blast_radius, 3),
            "pattern_risk": round(features.pattern_risk, 3),
            "file_risk": round(features.file_risk, 3),
        }

        # Only update severity if there's a meaningful change
        updates: dict[str, Any] = {"risk_score": risk}
        if (
            new_severity != finding.severity
            or abs(new_confidence - finding.confidence) >= self.min_confidence_delta
        ):
            updates["severity"] = new_severity
            updates["confidence"] = new_confidence
            updates["deterministic"] = False

        return finding.model_copy(update=updates)


def _calibrate_confidence(score: float, original_confidence: float) -> float:
    """Calibrate confidence based on model score and original value.

    The calibrated confidence blends the original finding confidence
    with the model's certainty (how far the score is from a threshold
    boundary).
    """
    # Distance from nearest threshold boundary
    min_dist = 1.0
    for threshold, _ in _SCORE_TO_SEVERITY:
        dist = abs(score - threshold)
        if dist < min_dist:
            min_dist = dist

    # Model certainty: farther from boundary = more certain
    model_certainty = min(1.0, min_dist * 5)

    # Blend: 60% original confidence, 40% model certainty
    blended = 0.6 * original_confidence + 0.4 * model_certainty
    return max(0.0, min(1.0, round(blended, 3)))
