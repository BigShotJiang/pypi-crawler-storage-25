"""Policy-as-Code engine — structured YAML policies beyond regex.

Evaluates scoped, multi-condition policies against repository files.
Supports conditions like "no function in src/safety/ may call malloc()"
or "all files must have a copyright header".
"""

from __future__ import annotations

import ast
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from guard.core.models import Evidence, Finding, Severity
from guard.core.repo_reader import list_files

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class PolicyCondition:
    """A single condition within a policy."""

    type: str  # must_not_contain, must_contain, must_not_import, max_lines,
    #              max_functions, requires_header, no_calls_to, custom_regex
    value: Any = None  # str | int | list — the parameter for the condition
    message: str = ""  # Optional custom message for this condition


@dataclass
class Policy:
    """A structured policy definition."""

    name: str
    description: str = ""
    severity: str = "medium"
    scope: str = "**/*"  # file glob pattern
    conditions: list[PolicyCondition] = field(default_factory=list)
    action: str = "deny"  # "deny" or "warn"


@dataclass
class PolicyResult:
    """Result of evaluating a single policy condition against a file."""

    policy_name: str
    file: str
    line: int  # 0 if not applicable
    message: str
    severity: str
    passed: bool


# ---------------------------------------------------------------------------
# Condition evaluators
# ---------------------------------------------------------------------------


def _eval_must_not_contain(content: str, value: Any, file_path: str) -> list[PolicyResult]:
    """Regex search — flags each match."""
    pattern_str = str(value) if value else ""
    if not pattern_str:
        return []
    try:
        pattern = re.compile(pattern_str)
    except re.error:
        logger.warning("Invalid regex in must_not_contain: %r", pattern_str)
        return []

    results: list[PolicyResult] = []
    for m in pattern.finditer(content):
        line_no = content[: m.start()].count("\n") + 1
        results.append(
            PolicyResult(
                policy_name="",
                file=file_path,
                line=line_no,
                message=f"Forbidden pattern found: {m.group()!r}",
                severity="",
                passed=False,
            )
        )
    return results


def _eval_must_contain(content: str, value: Any, file_path: str) -> list[PolicyResult]:
    """Inverse regex — flags if pattern NOT found."""
    pattern_str = str(value) if value else ""
    if not pattern_str:
        return []
    try:
        if re.search(pattern_str, content):
            return []
    except re.error:
        logger.warning("Invalid regex in must_contain: %r", pattern_str)
        return []

    return [
        PolicyResult(
            policy_name="",
            file=file_path,
            line=0,
            message=f"Required pattern not found: {pattern_str!r}",
            severity="",
            passed=False,
        )
    ]


def _eval_must_not_import(content: str, value: Any, file_path: str) -> list[PolicyResult]:
    """Check imports — Python (import/from) and C/C++ (#include)."""
    modules = value if isinstance(value, list) else [value] if value else []
    results: list[PolicyResult] = []

    for module in modules:
        module_str = str(module)
        # Python imports
        py_pattern = rf"(?:^import\s+{re.escape(module_str)}\b|^from\s+{re.escape(module_str)}\b)"
        for m in re.finditer(py_pattern, content, re.MULTILINE):
            line_no = content[: m.start()].count("\n") + 1
            results.append(
                PolicyResult(
                    policy_name="",
                    file=file_path,
                    line=line_no,
                    message=f"Forbidden import: {module_str}",
                    severity="",
                    passed=False,
                )
            )

        # C/C++ includes
        cpp_pattern = rf'^#\s*include\s*[<"]{re.escape(module_str)}[>"]'
        for m in re.finditer(cpp_pattern, content, re.MULTILINE):
            line_no = content[: m.start()].count("\n") + 1
            results.append(
                PolicyResult(
                    policy_name="",
                    file=file_path,
                    line=line_no,
                    message=f"Forbidden include: {module_str}",
                    severity="",
                    passed=False,
                )
            )

    return results


def _eval_max_lines(content: str, value: Any, file_path: str) -> list[PolicyResult]:
    """File exceeds N lines."""
    threshold = int(value) if value else 500
    count = len(content.splitlines())
    if count <= threshold:
        return []
    return [
        PolicyResult(
            policy_name="",
            file=file_path,
            line=0,
            message=f"File has {count} lines (max {threshold})",
            severity="",
            passed=False,
        )
    ]


def _eval_max_functions(content: str, value: Any, file_path: str) -> list[PolicyResult]:
    """More than N function definitions."""
    threshold = int(value) if value else 20

    # Try Python AST first
    count = 0
    try:
        tree = ast.parse(content)
        count = sum(
            1
            for node in ast.walk(tree)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        )
    except SyntaxError:
        # Fallback: count function-like patterns for other languages
        # Matches: def foo(, function foo(, fn foo(, func foo(, void foo(, int foo(, etc.
        func_pattern = re.compile(
            r"(?:^|\s)(?:def|function|fn|func|void|int|char|float|double|bool|auto)\s+\w+\s*\(",
            re.MULTILINE,
        )
        count = len(func_pattern.findall(content))

    if count <= threshold:
        return []
    return [
        PolicyResult(
            policy_name="",
            file=file_path,
            line=0,
            message=f"File has {count} functions (max {threshold})",
            severity="",
            passed=False,
        )
    ]


def _eval_requires_header(content: str, value: Any, file_path: str) -> list[PolicyResult]:
    """File must start with a specific pattern (copyright, license, etc.)."""
    pattern_str = str(value) if value else ""
    if not pattern_str:
        return []

    # Check the first few lines (allow blank lines before header)
    lines = content.splitlines()
    header_region = "\n".join(lines[:10])  # Check first 10 lines

    try:
        if re.search(pattern_str, header_region):
            return []
    except re.error:
        logger.warning("Invalid regex in requires_header: %r", pattern_str)
        return []

    return [
        PolicyResult(
            policy_name="",
            file=file_path,
            line=1,
            message=f"Required header not found: {pattern_str!r}",
            severity="",
            passed=False,
        )
    ]


def _eval_no_calls_to(content: str, value: Any, file_path: str) -> list[PolicyResult]:
    """Banned function/API calls in this scope."""
    functions = value if isinstance(value, list) else [value] if value else []
    results: list[PolicyResult] = []

    for func_name in functions:
        func_str = str(func_name)
        # Match function calls: malloc(, free(, new X, delete X
        # But not inside comments or strings (best effort)
        if func_str in ("new", "delete"):
            pattern = rf"\b{re.escape(func_str)}\b\s+\w+"
        else:
            pattern = rf"\b{re.escape(func_str)}\s*\("

        try:
            for m in re.finditer(pattern, content):
                line_no = content[: m.start()].count("\n") + 1
                line_text = content.splitlines()[line_no - 1].lstrip()

                # Skip matches in comments (basic heuristic)
                if line_text.startswith(("//", "#", "*", "/*")):
                    continue

                results.append(
                    PolicyResult(
                        policy_name="",
                        file=file_path,
                        line=line_no,
                        message=f"Banned call to {func_str}()",
                        severity="",
                        passed=False,
                    )
                )
        except re.error:
            logger.warning("Invalid regex for no_calls_to function: %r", func_str)

    return results


def _eval_custom_regex(content: str, value: Any, file_path: str) -> list[PolicyResult]:
    """Arbitrary regex with custom message."""
    if isinstance(value, dict):
        pattern_str = value.get("pattern", "")
        custom_msg = value.get("message", "Custom regex match")
    else:
        pattern_str = str(value) if value else ""
        custom_msg = f"Custom regex match: {pattern_str!r}"

    if not pattern_str:
        return []

    try:
        pattern = re.compile(pattern_str)
    except re.error:
        logger.warning("Invalid regex in custom_regex: %r", pattern_str)
        return []

    results: list[PolicyResult] = []
    for m in pattern.finditer(content):
        line_no = content[: m.start()].count("\n") + 1
        results.append(
            PolicyResult(
                policy_name="",
                file=file_path,
                line=line_no,
                message=custom_msg,
                severity="",
                passed=False,
            )
        )
    return results


# Condition type → evaluator function
_CONDITION_EVALUATORS: dict[str, Any] = {
    "must_not_contain": _eval_must_not_contain,
    "must_contain": _eval_must_contain,
    "must_not_import": _eval_must_not_import,
    "max_lines": _eval_max_lines,
    "max_functions": _eval_max_functions,
    "requires_header": _eval_requires_header,
    "no_calls_to": _eval_no_calls_to,
    "custom_regex": _eval_custom_regex,
}


# ---------------------------------------------------------------------------
# Core evaluation
# ---------------------------------------------------------------------------


def evaluate_policies(
    policies: list[Policy],
    repo_root: str,
    files: list[str] | None = None,
) -> list[PolicyResult]:
    """Evaluate all policies against matching files in the repo.

    Args:
        policies: List of Policy objects to evaluate.
        repo_root: Path to the repository root.
        files: Optional list of files to check (relative paths).
               If None, files are discovered via glob from repo_root.

    Returns:
        List of PolicyResult objects (both passed and failed).
    """
    root = Path(repo_root)
    all_results: list[PolicyResult] = []

    for policy in policies:
        # Normalize scope: "src/safety/**" → "src/safety/**/*" for proper glob matching
        scope = policy.scope
        if scope.endswith("/**"):
            scope = scope + "/*"

        # Collect files matching the policy scope
        if files is not None:
            matching_files = _filter_files_by_glob(files, scope, root)
        else:
            matching_files = list_files(root, scope)

        for rel_path in matching_files:
            abs_path = root / rel_path
            try:
                content = abs_path.read_text(encoding="utf-8")
            except (UnicodeDecodeError, PermissionError, OSError):
                continue

            file_results = _evaluate_policy_on_file(policy, rel_path, content)
            all_results.extend(file_results)

    return all_results


def _filter_files_by_glob(
    files: list[str], scope: str, root: Path
) -> list[str]:
    """Filter a file list by a glob pattern."""
    from fnmatch import fnmatch

    # Expand brace patterns like "**/*.{py,js}"
    patterns = _expand_braces(scope)
    result: list[str] = []
    for f in files:
        normalized = f.replace("\\", "/")
        if any(fnmatch(normalized, p) for p in patterns):
            result.append(f)
    return result


def _expand_braces(pattern: str) -> list[str]:
    """Expand simple brace patterns like '**/*.{py,js}' into multiple globs."""
    m = re.search(r"\{([^}]+)\}", pattern)
    if not m:
        return [pattern]
    prefix = pattern[: m.start()]
    suffix = pattern[m.end() :]
    alternatives = m.group(1).split(",")
    expanded: list[str] = []
    for alt in alternatives:
        expanded.extend(_expand_braces(prefix + alt.strip() + suffix))
    return expanded


def _evaluate_policy_on_file(
    policy: Policy, file_path: str, content: str
) -> list[PolicyResult]:
    """Evaluate all conditions of a policy against a single file."""
    results: list[PolicyResult] = []

    for condition in policy.conditions:
        evaluator = _CONDITION_EVALUATORS.get(condition.type)
        if evaluator is None:
            logger.warning(
                "Unknown condition type %r in policy %r — skipped",
                condition.type,
                policy.name,
            )
            continue

        condition_results = evaluator(content, condition.value, file_path)

        if not condition_results:
            # Condition passed
            continue

        # Condition failed — stamp policy metadata onto results
        for r in condition_results:
            r.policy_name = policy.name
            r.severity = policy.severity
            if condition.message:
                r.message = condition.message
        results.extend(condition_results)

    return results


# ---------------------------------------------------------------------------
# YAML loading
# ---------------------------------------------------------------------------


_TEMPLATE_YAML = """\
# Sentrik Policy-as-Code configuration
# See https://docs.sentrik.dev for full documentation
#
# Policies are structured rules that go beyond regex patterns.
# Each policy has a scope (file glob), conditions, and an action.

policies:
  - name: "No dynamic memory in safety-critical code"
    description: "Safety-critical modules must not use heap allocation"
    severity: critical
    scope: "src/safety/**"
    action: deny
    conditions:
      - type: no_calls_to
        value: ["malloc", "calloc", "realloc", "free", "new", "delete"]

  - name: "All source files must have copyright header"
    description: "Every source file must start with the company copyright notice"
    severity: medium
    scope: "src/**/*.{cpp,h,py,js}"
    action: deny
    conditions:
      - type: requires_header
        value: "Copyright.*MyCompany"

  - name: "Maximum file length"
    description: "No source file should exceed 500 lines"
    severity: low
    scope: "**/*.{cpp,py,js}"
    action: warn
    conditions:
      - type: max_lines
        value: 500

  - name: "No unsafe imports in production code"
    description: "Production code must not import debugging or test modules"
    severity: high
    scope: "src/**/*.py"
    action: deny
    conditions:
      - type: must_not_import
        value: ["pdb", "ipdb", "pudb"]

  - name: "Maximum function count per file"
    description: "Files with too many functions should be refactored"
    severity: low
    scope: "**/*.py"
    action: warn
    conditions:
      - type: max_functions
        value: 20
"""


def load_policies(path: str | Path | None = None) -> list[Policy]:
    """Load policies from a YAML file.

    Search order (if *path* is None):
        1. ``.sentrik/policies.yaml``
        2. ``policies.yaml``

    Returns an empty list if no policies file is found.
    """
    if path is not None:
        search_paths = [Path(path)]
    else:
        search_paths = [Path(".sentrik/policies.yaml"), Path("policies.yaml")]

    policies_path: Path | None = None
    for p in search_paths:
        if p.exists():
            policies_path = p
            break

    if policies_path is None:
        return []

    try:
        raw = yaml.safe_load(policies_path.read_text(encoding="utf-8"))
    except (yaml.YAMLError, OSError) as exc:
        logger.warning("Failed to load policies from %s: %s", policies_path, exc)
        return []

    if not isinstance(raw, dict) or "policies" not in raw:
        logger.warning("Invalid policies file %s — missing 'policies' key", policies_path)
        return []

    policies: list[Policy] = []
    for entry in raw["policies"]:
        if not isinstance(entry, dict):
            continue
        conditions: list[PolicyCondition] = []
        for c in entry.get("conditions", []):
            if isinstance(c, dict):
                conditions.append(
                    PolicyCondition(
                        type=c.get("type", ""),
                        value=c.get("value"),
                        message=c.get("message", ""),
                    )
                )
        policies.append(
            Policy(
                name=entry.get("name", "Unnamed Policy"),
                description=entry.get("description", ""),
                severity=entry.get("severity", "medium"),
                scope=entry.get("scope", "**/*"),
                conditions=conditions,
                action=entry.get("action", "deny"),
            )
        )

    return policies


def generate_template(path: str | Path | None = None) -> Path:
    """Write a template policies.yaml and return its path."""
    target = Path(path) if path else Path("policies.yaml")
    target.write_text(_TEMPLATE_YAML, encoding="utf-8")
    return target


# ---------------------------------------------------------------------------
# Conversion to Findings
# ---------------------------------------------------------------------------


def _slugify(name: str) -> str:
    """Convert a policy name to a slug suitable for a rule ID."""
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug[:60]  # Truncate long names


def policy_results_to_findings(results: list[PolicyResult]) -> list[Finding]:
    """Convert failed PolicyResults to Finding objects.

    Each failed result becomes a Finding with rule_id="POLICY-{name-slug}"
    and standard="Policy".
    """
    findings: list[Finding] = []

    for r in results:
        if r.passed:
            continue

        slug = _slugify(r.policy_name)
        rule_id = f"POLICY-{slug}"

        findings.append(
            Finding(
                finding_id=f"{rule_id}-{r.file}:{r.line}",
                rule_id=rule_id,
                severity=Severity(r.severity),
                message=f"[{r.policy_name}] {r.message}",
                evidence=Evidence(
                    file=r.file,
                    lines=[r.line] if r.line > 0 else [],
                    snippet="",
                ),
                suggestion=None,
                confidence=1.0,
                deterministic=True,
                standard="Policy",
            )
        )

    return findings
