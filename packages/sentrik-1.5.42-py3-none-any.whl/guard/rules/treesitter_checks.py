"""Tree-sitter AST query engine for multi-language rule evaluation.

Supports any language with a tree-sitter grammar installed as
``tree-sitter-<language>`` on PyPI. Parsers and compiled queries are
cached at module level so they are built once per process.

Grammar packages currently bundled in the ``sentrik[treesitter]`` extra:
  python, cpp, c, javascript, typescript, go, rust, java, kotlin, ruby, c_sharp

Usage in pack YAML::

    - id: MY-001
      type: ast
      language: python
      query: |
        (call function: (identifier) @fn (#eq? @fn "eval"))
      severity: critical
      file_glob: "**/*.py"
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

logger = logging.getLogger(__name__)

# Module-level caches — built once per process, shared across threads (read-only after init)
_parser_cache: dict[str, Any] = {}
_query_cache: dict[tuple[str, str], Any] = {}
_cache_lock = threading.Lock()

# Maps Sentrik language names → PyPI package import names
_LANGUAGE_MODULES: dict[str, str] = {
    "python": "tree_sitter_python",
    "cpp": "tree_sitter_cpp",
    "c++": "tree_sitter_cpp",
    "c": "tree_sitter_c",
    "javascript": "tree_sitter_javascript",
    "js": "tree_sitter_javascript",
    "typescript": "tree_sitter_typescript",
    "ts": "tree_sitter_typescript",
    "go": "tree_sitter_go",
    "golang": "tree_sitter_go",
    "rust": "tree_sitter_rust",
    "java": "tree_sitter_java",
    "kotlin": "tree_sitter_kotlin",
    "ruby": "tree_sitter_ruby",
    "rb": "tree_sitter_ruby",
    "c_sharp": "tree_sitter_c_sharp",
    "csharp": "tree_sitter_c_sharp",
    "cs": "tree_sitter_c_sharp",
}


@dataclass
class TreeSitterIssue:
    line: int          # 1-based
    col: int           # 1-based
    snippet: str
    capture_name: str
    node_text: str


def is_available() -> bool:
    """Return True if tree-sitter core is importable."""
    try:
        import tree_sitter  # noqa: F401
        return True
    except ImportError:
        return False


def language_available(language: str) -> bool:
    """Return True if a grammar package for *language* is installed."""
    module_name = _LANGUAGE_MODULES.get(language.lower())
    if module_name is None:
        return False
    try:
        __import__(module_name)
        return True
    except ImportError:
        return False


def _get_parser(language: str) -> Any | None:
    """Return a cached tree_sitter.Parser for *language*, or None if unavailable."""
    lang_key = language.lower()

    with _cache_lock:
        if lang_key in _parser_cache:
            return _parser_cache[lang_key]

    module_name = _LANGUAGE_MODULES.get(lang_key)
    if module_name is None:
        logger.warning("tree-sitter: no grammar mapping for language %r", language)
        with _cache_lock:
            _parser_cache[lang_key] = None
        return None

    try:
        mod = __import__(module_name)
        from tree_sitter import Language, Parser

        ts_language = Language(mod.language())
        parser = Parser(ts_language)

        with _cache_lock:
            _parser_cache[lang_key] = (parser, ts_language)
        return (parser, ts_language)

    except ImportError:
        logger.warning(
            "tree-sitter grammar for %r not installed. "
            "Install with: pip install %s",
            language, module_name,
        )
        with _cache_lock:
            _parser_cache[lang_key] = None
        return None
    except Exception as exc:
        logger.warning("tree-sitter: failed to load grammar for %r: %s", language, exc)
        with _cache_lock:
            _parser_cache[lang_key] = None
        return None


def _get_query(ts_language: Any, language: str, query_str: str) -> Any | None:
    """Return a cached compiled tree_sitter.Query, or None on error."""
    cache_key = (language.lower(), query_str)

    with _cache_lock:
        if cache_key in _query_cache:
            return _query_cache[cache_key]

    try:
        from tree_sitter import Query
        query = Query(ts_language, query_str)
        with _cache_lock:
            _query_cache[cache_key] = query
        return query

    except Exception as exc:
        logger.warning("tree-sitter: invalid query for language %r: %s\nQuery: %s", language, exc, query_str[:200])
        with _cache_lock:
            _query_cache[cache_key] = None
        return None


def run_query(
    language: str,
    query_str: str,
    content: str,
) -> list[TreeSitterIssue]:
    """Parse *content* as *language* and run *query_str* against it.

    Returns a list of :class:`TreeSitterIssue` for each captured node,
    with accurate line/column numbers and the matched source text.

    Returns an empty list if tree-sitter is unavailable, the grammar is
    missing, the query is invalid, or the file has parse errors that
    prevent evaluation.
    """
    entry = _get_parser(language)
    if entry is None:
        return []

    parser, ts_language = entry
    query = _get_query(ts_language, language, query_str)
    if query is None:
        return []

    try:
        source_bytes = content.encode("utf-8", errors="replace")
        tree = parser.parse(source_bytes)
    except Exception as exc:
        logger.debug("tree-sitter: parse failed for language %r: %s", language, exc)
        return []

    try:
        from tree_sitter import QueryCursor
        cursor = QueryCursor(query)
        matches = list(cursor.matches(tree.root_node))
    except Exception as exc:
        logger.debug("tree-sitter: query execution failed: %s", exc)
        return []

    source_lines = content.splitlines()
    issues: list[TreeSitterIssue] = []

    for _pattern_idx, capture_dict in matches:
        for capture_name, nodes in capture_dict.items():
            for node in nodes:
                line_0 = node.start_point[0]   # 0-based
                col_0 = node.start_point[1]    # 0-based
                line_1 = line_0 + 1            # 1-based for reporting
                snippet = source_lines[line_0] if line_0 < len(source_lines) else ""
                try:
                    node_text = source_bytes[node.start_byte:node.end_byte].decode("utf-8", errors="replace")
                except Exception:
                    node_text = ""
                issues.append(TreeSitterIssue(
                    line=line_1,
                    col=col_0 + 1,
                    snippet=snippet,
                    capture_name=capture_name,
                    node_text=node_text,
                ))

    return issues
