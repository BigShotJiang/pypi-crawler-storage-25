"""Built-in AST checks for the ast rule type."""

from __future__ import annotations

import ast
from dataclasses import dataclass


@dataclass
class ASTIssue:
    """A single issue found by an AST check."""
    line: int
    message: str
    snippet: str = ""


def no_mutable_defaults(tree: ast.Module, source_lines: list[str], params: dict | None = None) -> list[ASTIssue]:
    """Detect mutable default arguments in function definitions.

    Flags: def f(x=[]), def f(x={}), def f(x=set())
    """
    issues: list[ASTIssue] = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for default in node.args.defaults + node.args.kw_defaults:
            if default is None:
                continue
            if isinstance(default, (ast.List, ast.Dict, ast.Set)):
                line = default.lineno
                snippet = source_lines[line - 1].strip() if line <= len(source_lines) else ""
                issues.append(ASTIssue(
                    line=line,
                    message=f"Mutable default argument in function '{node.name}'",
                    snippet=snippet,
                ))
            elif isinstance(default, ast.Call):
                func_name = ""
                if isinstance(default.func, ast.Name):
                    func_name = default.func.id
                elif isinstance(default.func, ast.Attribute):
                    func_name = default.func.attr
                if func_name in ("list", "dict", "set"):
                    line = default.lineno
                    snippet = source_lines[line - 1].strip() if line <= len(source_lines) else ""
                    issues.append(ASTIssue(
                        line=line,
                        message=f"Mutable default argument in function '{node.name}'",
                        snippet=snippet,
                    ))
    return issues


def no_global_variables(tree: ast.Module, source_lines: list[str], params: dict | None = None) -> list[ASTIssue]:
    """Detect module-level mutable variable assignments.

    Flags assignments at the module level that are not constants
    (UPPER_CASE), type aliases, or __dunder__ assignments.
    """
    issues: list[ASTIssue] = []
    for node in tree.body:
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        targets: list[str] = []
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    targets.append(target.id)
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            targets.append(node.target.id)

        for name in targets:
            # Allow constants (UPPER_CASE), dunders, and type aliases
            if name.isupper() or name.startswith("_") and name.endswith("_"):
                continue
            if name.startswith("__") and name.endswith("__"):
                continue
            # Allow simple type alias patterns (Name = Type)
            if isinstance(node, ast.Assign) and isinstance(node.value, ast.Name):
                continue
            # Allow TypeAlias
            if isinstance(node, ast.AnnAssign):
                continue
            line = node.lineno
            snippet = source_lines[line - 1].strip() if line <= len(source_lines) else ""
            issues.append(ASTIssue(
                line=line,
                message=f"Module-level mutable variable '{name}' — consider making it a constant or moving it into a function",
                snippet=snippet,
            ))
    return issues


def no_nested_functions(tree: ast.Module, source_lines: list[str], params: dict | None = None) -> list[ASTIssue]:
    """Detect deeply nested function definitions (depth > max_depth).

    Flags functions defined inside other functions (closures) beyond
    the configured nesting depth, which can be hard to test and maintain.
    """
    max_depth = (params or {}).get("max_depth", 1)
    issues: list[ASTIssue] = []

    def _visit(node: ast.AST, depth: int) -> None:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if depth > max_depth:
                line = node.lineno
                snippet = source_lines[line - 1].strip() if line <= len(source_lines) else ""
                issues.append(ASTIssue(
                    line=line,
                    message=f"Deeply nested function '{node.name}' (depth {depth})",
                    snippet=snippet,
                ))
            for child in ast.iter_child_nodes(node):
                _visit(child, depth + 1)
        else:
            for child in ast.iter_child_nodes(node):
                _visit(child, depth)

    for top in tree.body:
        _visit(top, 0)
    return issues


def no_star_imports(tree: ast.Module, source_lines: list[str], params: dict | None = None) -> list[ASTIssue]:
    """Detect wildcard imports (from X import *).

    These pollute the namespace and make it hard to trace symbol origins.
    """
    issues: list[ASTIssue] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name == "*":
                    line = node.lineno
                    module = node.module or "<unknown>"
                    snippet = source_lines[line - 1].strip() if line <= len(source_lines) else ""
                    issues.append(ASTIssue(
                        line=line,
                        message=f"Wildcard import from '{module}'",
                        snippet=snippet,
                    ))
    return issues


def high_complexity(tree: ast.Module, source_lines: list[str], params: dict | None = None) -> list[ASTIssue]:
    """Detect functions with high cyclomatic complexity.

    Uses a simplified McCabe complexity calculation based on
    control flow statements.  Threshold is configurable via
    ``params["max_complexity"]`` (default 10).
    """
    threshold = (params or {}).get("max_complexity", 10)
    issues: list[ASTIssue] = []

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        complexity = _mccabe_complexity(node)
        if complexity > threshold:
            line = node.lineno
            snippet = source_lines[line - 1].strip() if line <= len(source_lines) else ""
            issues.append(ASTIssue(
                line=line,
                message=f"Function '{node.name}' has high complexity ({complexity})",
                snippet=snippet,
            ))
    return issues


def _mccabe_complexity(node: ast.AST) -> int:
    """Calculate simplified McCabe cyclomatic complexity for a function."""
    complexity = 1  # Base complexity
    for child in ast.walk(node):
        if isinstance(child, (ast.If, ast.While, ast.For, ast.AsyncFor)):
            complexity += 1
        elif isinstance(child, ast.ExceptHandler):
            complexity += 1
        elif isinstance(child, ast.BoolOp):
            # Each 'and'/'or' adds a decision point
            complexity += len(child.values) - 1
        elif isinstance(child, ast.Assert):
            complexity += 1
        elif isinstance(child, (ast.ListComp, ast.SetComp, ast.GeneratorExp, ast.DictComp)):
            complexity += 1
    return complexity


def max_function_length(tree: ast.Module, source_lines: list[str], params: dict | None = None) -> list[ASTIssue]:
    """Detect functions that exceed a maximum line count.

    Threshold is configurable via ``params["max_lines"]`` (default 50).
    """
    threshold = (params or {}).get("max_lines", 50)
    issues: list[ASTIssue] = []

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if node.end_lineno is None:
            continue
        length = node.end_lineno - node.lineno + 1
        if length > threshold:
            line = node.lineno
            snippet = source_lines[line - 1].strip() if line <= len(source_lines) else ""
            issues.append(ASTIssue(
                line=line,
                message=f"Function '{node.name}' is {length} lines long (max {threshold})",
                snippet=snippet,
            ))
    return issues


# Registry of available AST check functions
AST_CHECKS: dict[str, type(no_mutable_defaults)] = {
    "no_mutable_defaults": no_mutable_defaults,
    "no_global_variables": no_global_variables,
    "no_nested_functions": no_nested_functions,
    "no_star_imports": no_star_imports,
    "high_complexity": high_complexity,
    "max_function_length": max_function_length,
}
