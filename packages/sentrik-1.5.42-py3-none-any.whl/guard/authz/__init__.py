"""Fine-grained authorization and RBAC for Sentrik."""

from guard.authz.models import Permission, ResourceType, AuthzRequest, AuthzResult, ROLE_PERMISSIONS
from guard.authz.policy import LocalPolicyEngine, get_policy_engine, set_policy_engine
from guard.authz.checks import require_permission
from guard.authz.fga_client import OpenFGAClient
from guard.authz.sync import sync_roles_on_login, sync_repo_access

__all__ = [
    "Permission", "ResourceType", "AuthzRequest", "AuthzResult",
    "ROLE_PERMISSIONS", "LocalPolicyEngine", "get_policy_engine",
    "set_policy_engine", "require_permission", "OpenFGAClient",
    "sync_roles_on_login", "sync_repo_access",
]
