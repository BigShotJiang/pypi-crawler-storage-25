"""Policy engine backends for authorization decisions."""

from __future__ import annotations

import logging
from typing import Optional, Protocol, runtime_checkable

from guard.authz.models import (
    AuthzRequest,
    AuthzResult,
    Permission,
    ROLE_PERMISSIONS,
    ResourceType,
)

_logger = logging.getLogger(__name__)


@runtime_checkable
class PolicyBackend(Protocol):
    """Abstract protocol for authorization policy backends."""

    def check(self, request: AuthzRequest) -> AuthzResult:
        """Evaluate an authorization request and return a result."""
        ...


class LocalPolicyEngine:
    """Built-in RBAC policy engine using in-memory role→permission lookups.

    Zero external dependencies. Supports repo-scoped agent checks.
    """

    def check(self, request: AuthzRequest) -> AuthzResult:
        """Check if the user's roles grant the requested permission."""
        try:
            action = Permission(request.action)
        except ValueError:
            return AuthzResult(allowed=False, reason=f"Unknown permission: {request.action}")

        # Collect all permissions from all user roles (union)
        granted: set[Permission] = set()
        for role in request.roles:
            perms = ROLE_PERMISSIONS.get(role)
            if perms is not None:
                granted |= perms

        if action not in granted:
            return AuthzResult(
                allowed=False,
                reason=f"None of roles {request.roles} grant '{action.value}'",
            )

        # Repo-scoped check for agent role
        if "agent" in request.roles and len(request.roles) == 1:
            if (
                request.resource_type == ResourceType.REPO.value
                and request.resource_id
                and request.repo_access
                and request.resource_id not in request.repo_access
            ):
                return AuthzResult(
                    allowed=False,
                    reason=f"Agent lacks access to repo '{request.resource_id}'",
                )

        return AuthzResult(allowed=True)


# ── Singleton management ──────────────────────────────────────────────

_engine: Optional[PolicyBackend] = None


def get_policy_engine() -> PolicyBackend:
    """Return the current policy engine singleton, creating a LocalPolicyEngine if needed."""
    global _engine
    if _engine is None:
        _engine = LocalPolicyEngine()
    return _engine


def set_policy_engine(engine: Optional[PolicyBackend]) -> None:
    """Override the policy engine singleton (useful for testing or OpenFGA integration)."""
    global _engine
    _engine = engine
