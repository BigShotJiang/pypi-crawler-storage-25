"""Role and repo-access synchronization hooks.

These are no-ops for the built-in LocalPolicyEngine. When an external
identity provider (e.g. OpenFGA, SCIM) is integrated, implement real
sync logic here.
"""

from __future__ import annotations

import logging
from typing import Any

_logger = logging.getLogger(__name__)


def sync_roles_on_login(user_id: str, provider_roles: list[str], **kwargs: Any) -> list[str]:
    """Synchronize roles from an identity provider on login.

    Currently a pass-through: returns provider_roles unchanged.
    """
    _logger.debug("sync_roles_on_login: user=%s roles=%s (no-op)", user_id, provider_roles)
    return provider_roles


def sync_repo_access(user_id: str, org_id: str = "", **kwargs: Any) -> list[str]:
    """Fetch repo-level access for a user from an external source.

    Currently returns an empty list (no external source configured).
    """
    _logger.debug("sync_repo_access: user=%s org=%s (no-op)", user_id, org_id)
    return []
