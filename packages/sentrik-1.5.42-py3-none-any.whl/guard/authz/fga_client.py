"""OpenFGA client stub for future integration."""

from __future__ import annotations

import logging

from guard.authz.models import AuthzRequest, AuthzResult
from guard.authz.policy import LocalPolicyEngine

_logger = logging.getLogger(__name__)


class OpenFGAClient:
    """Stub OpenFGA client that delegates to LocalPolicyEngine.

    Replace the ``check`` method with real OpenFGA HTTP calls when
    an external authorization service is available.
    """

    def __init__(self, api_url: str = "", store_id: str = "", model_id: str = ""):
        self.api_url = api_url
        self.store_id = store_id
        self.model_id = model_id
        self._fallback = LocalPolicyEngine()
        if api_url:
            _logger.info("OpenFGA client configured (url=%s) — using fallback until implemented", api_url)

    def check(self, request: AuthzRequest) -> AuthzResult:
        """Delegate to LocalPolicyEngine (stub)."""
        return self._fallback.check(request)
