"""Authorization data models and RBAC permission matrix."""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class Permission(str, Enum):
    """Actions that can be authorized."""

    SCAN = "scan"
    GATE = "gate"
    RECONCILE = "reconcile"
    CONFIG_READ = "config:read"
    CONFIG_EDIT = "config:edit"
    FINDINGS_READ = "findings:read"
    FINDINGS_WRITE = "findings:write"
    AUDIT_READ = "audit:read"
    PACKS_READ = "packs:read"
    PACKS_MANAGE = "packs:manage"
    APPROVAL_REQUEST = "approval:request"
    APPROVAL_REVIEW = "approval:review"


class ResourceType(str, Enum):
    """Resource types for fine-grained checks."""

    GLOBAL = "global"
    REPO = "repo"
    FINDING = "finding"
    PACK = "pack"
    CONFIG = "config"


class AuthzRequest(BaseModel):
    """An authorization check request."""

    user_id: str
    action: str
    resource_type: str = ResourceType.GLOBAL.value
    resource_id: str = ""
    roles: list[str] = Field(default_factory=list)
    repo_access: list[str] = Field(default_factory=list)


class AuthzResult(BaseModel):
    """Result of an authorization check."""

    allowed: bool
    reason: str = ""


# Single source of truth for the RBAC matrix.
# Each role maps to a frozenset of Permission values.
ROLE_PERMISSIONS: dict[str, frozenset[Permission]] = {
    "admin": frozenset(Permission),  # all permissions
    "security-lead": frozenset([
        Permission.SCAN,
        Permission.GATE,
        Permission.RECONCILE,
        Permission.FINDINGS_READ,
        Permission.FINDINGS_WRITE,
        Permission.AUDIT_READ,
        Permission.PACKS_READ,
        Permission.APPROVAL_REVIEW,
    ]),
    "developer": frozenset([
        Permission.SCAN,
        Permission.GATE,
        Permission.FINDINGS_READ,
        Permission.PACKS_READ,
    ]),
    "viewer": frozenset([
        Permission.FINDINGS_READ,
        Permission.AUDIT_READ,
        Permission.PACKS_READ,
    ]),
    "agent": frozenset([
        Permission.SCAN,
        Permission.GATE,
        Permission.FINDINGS_READ,
        Permission.APPROVAL_REQUEST,
    ]),
}
