"""FastAPI dependency helpers for permission enforcement."""

from __future__ import annotations

from fastapi import HTTPException

from guard.auth.models import UserContext
from guard.authz.models import AuthzRequest, ResourceType
from guard.authz.policy import get_policy_engine


def require_permission(action: str, resource_type: str = ResourceType.GLOBAL.value):
    """Return a callable dependency that enforces a permission check.

    Backward compatibility:
    - Anonymous users (auth disabled) pass all checks.
    - API key users have admin role and pass all checks.
    """

    def _check(user: UserContext) -> UserContext:
        # Anonymous users (auth disabled) — no enforcement
        if not user.is_authenticated and user.auth_method == "none":
            return user

        engine = get_policy_engine()
        result = engine.check(AuthzRequest(
            user_id=user.user_id,
            action=action,
            resource_type=resource_type,
            roles=user.roles,
            repo_access=getattr(user, "repo_access", []),
        ))

        if not result.allowed:
            raise HTTPException(status_code=403, detail=result.reason)

        return user

    return _check
