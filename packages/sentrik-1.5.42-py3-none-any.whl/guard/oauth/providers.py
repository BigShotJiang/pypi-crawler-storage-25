"""OAuth flow implementations for Azure DevOps, GitHub, and Atlassian (Jira)."""

from __future__ import annotations

import logging
import secrets
import time
import urllib.parse
from typing import Any

from guard.oauth.models import OAuthConfig, OAuthToken

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Azure DevOps via Microsoft Entra ID (Azure AD) OAuth 2.0
# https://learn.microsoft.com/en-us/azure/devops/integrate/get-started/authentication/entra-oauth
# ---------------------------------------------------------------------------

# Azure DevOps resource ID — used as scope for Entra ID tokens
_AZURE_DEVOPS_RESOURCE = "499b84ac-1321-427f-aa17-267ca6975798"
_AZURE_SCOPES = f"{_AZURE_DEVOPS_RESOURCE}/.default offline_access"


def _azure_authorize_url(tenant: str) -> str:
    return f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize"


def _azure_token_url(tenant: str) -> str:
    return f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"


def azure_get_authorize_url(config: OAuthConfig, state: str = "") -> tuple[str, str]:
    """Build Microsoft Entra ID authorize URL for Azure DevOps access.

    Returns (url, state) — caller must store state for CSRF validation.
    """
    if not state:
        state = secrets.token_urlsafe(32)

    tenant = config.azure_tenant_id or "common"
    params = {
        "client_id": config.azure_client_id,
        "response_type": "code",
        "redirect_uri": config.azure_redirect_uri,
        "response_mode": "query",
        "scope": _AZURE_SCOPES,
        "state": state,
    }
    query = urllib.parse.urlencode(params)
    return f"{_azure_authorize_url(tenant)}?{query}", state


def azure_exchange_code(config: OAuthConfig, code: str) -> OAuthToken:
    """Exchange authorization code for Azure DevOps tokens via Entra ID."""
    import httpx

    tenant = config.azure_tenant_id or "common"
    resp = httpx.post(
        _azure_token_url(tenant),
        data={
            "client_id": config.azure_client_id,
            "client_secret": config.azure_client_secret,
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": config.azure_redirect_uri,
            "scope": _AZURE_SCOPES,
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        timeout=15,
    )
    resp.raise_for_status()
    data = resp.json()

    return OAuthToken(
        provider="azure",
        access_token=data["access_token"],
        refresh_token=data.get("refresh_token", ""),
        token_type=data.get("token_type", "Bearer"),
        expires_at=time.time() + int(data.get("expires_in", 3600)),
        scope=data.get("scope", _AZURE_SCOPES),
    )


def azure_refresh_token(config: OAuthConfig, token: OAuthToken) -> OAuthToken:
    """Refresh an expired Azure DevOps access token via Entra ID."""
    import httpx

    tenant = config.azure_tenant_id or "common"
    resp = httpx.post(
        _azure_token_url(tenant),
        data={
            "client_id": config.azure_client_id,
            "client_secret": config.azure_client_secret,
            "grant_type": "refresh_token",
            "refresh_token": token.refresh_token,
            "scope": _AZURE_SCOPES,
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        timeout=15,
    )
    resp.raise_for_status()
    data = resp.json()

    return OAuthToken(
        provider="azure",
        access_token=data["access_token"],
        refresh_token=data.get("refresh_token", token.refresh_token),
        token_type=data.get("token_type", "Bearer"),
        expires_at=time.time() + int(data.get("expires_in", 3600)),
        scope=token.scope,
    )


# ---------------------------------------------------------------------------
# GitHub OAuth 2.0
# https://docs.github.com/en/apps/oauth-apps/building-oauth-apps
# ---------------------------------------------------------------------------

_GITHUB_AUTHORIZE_URL = "https://github.com/login/oauth/authorize"
_GITHUB_TOKEN_URL = "https://github.com/login/oauth/access_token"
_GITHUB_SCOPES = "repo"


def github_get_authorize_url(config: OAuthConfig, state: str = "") -> tuple[str, str]:
    """Build GitHub OAuth authorize URL."""
    if not state:
        state = secrets.token_urlsafe(32)

    params = {
        "client_id": config.github_client_id,
        "redirect_uri": config.github_redirect_uri,
        "scope": _GITHUB_SCOPES,
        "state": state,
    }
    query = urllib.parse.urlencode(params)
    return f"{_GITHUB_AUTHORIZE_URL}?{query}", state


def github_exchange_code(config: OAuthConfig, code: str) -> OAuthToken:
    """Exchange authorization code for GitHub token."""
    import httpx

    resp = httpx.post(
        _GITHUB_TOKEN_URL,
        json={
            "client_id": config.github_client_id,
            "client_secret": config.github_client_secret,
            "code": code,
            "redirect_uri": config.github_redirect_uri,
        },
        headers={"Accept": "application/json"},
        timeout=15,
    )
    resp.raise_for_status()
    data = resp.json()

    if "error" in data:
        raise RuntimeError(f"GitHub OAuth error: {data['error_description']}")

    return OAuthToken(
        provider="github",
        access_token=data["access_token"],
        token_type=data.get("token_type", "bearer"),
        scope=data.get("scope", ""),
        # GitHub OAuth tokens don't expire (no refresh token)
        expires_at=0,
    )


# ---------------------------------------------------------------------------
# Atlassian (Jira Cloud) OAuth 2.0 (3LO)
# https://developer.atlassian.com/cloud/jira/platform/oauth-2-3lo-apps/
# ---------------------------------------------------------------------------

_JIRA_AUTHORIZE_URL = "https://auth.atlassian.com/authorize"
_JIRA_TOKEN_URL = "https://auth.atlassian.com/oauth/token"
_JIRA_RESOURCES_URL = "https://api.atlassian.com/oauth/token/accessible-resources"
_JIRA_SCOPES = "read:jira-work write:jira-work offline_access"


def jira_get_authorize_url(config: OAuthConfig, state: str = "") -> tuple[str, str]:
    """Build Atlassian/Jira OAuth authorize URL."""
    if not state:
        state = secrets.token_urlsafe(32)

    params = {
        "audience": "api.atlassian.com",
        "client_id": config.jira_client_id,
        "scope": _JIRA_SCOPES,
        "redirect_uri": config.jira_redirect_uri,
        "state": state,
        "response_type": "code",
        "prompt": "consent",
    }
    query = urllib.parse.urlencode(params)
    return f"{_JIRA_AUTHORIZE_URL}?{query}", state


def jira_exchange_code(config: OAuthConfig, code: str) -> OAuthToken:
    """Exchange authorization code for Jira/Atlassian tokens."""
    import httpx

    resp = httpx.post(
        _JIRA_TOKEN_URL,
        json={
            "grant_type": "authorization_code",
            "client_id": config.jira_client_id,
            "client_secret": config.jira_client_secret,
            "code": code,
            "redirect_uri": config.jira_redirect_uri,
        },
        timeout=15,
    )
    resp.raise_for_status()
    data = resp.json()

    token = OAuthToken(
        provider="jira",
        access_token=data["access_token"],
        refresh_token=data.get("refresh_token", ""),
        token_type=data.get("token_type", "Bearer"),
        expires_at=time.time() + int(data.get("expires_in", 3600)),
        scope=data.get("scope", ""),
    )

    # Fetch cloud ID for API calls
    try:
        resources_resp = httpx.get(
            _JIRA_RESOURCES_URL,
            headers={"Authorization": f"Bearer {token.access_token}"},
            timeout=10,
        )
        resources_resp.raise_for_status()
        resources = resources_resp.json()
        if resources:
            token.cloud_id = resources[0].get("id", "")
    except Exception as exc:
        logger.warning("Failed to fetch Jira cloud ID: %s", exc)

    return token


def jira_refresh_token(config: OAuthConfig, token: OAuthToken) -> OAuthToken:
    """Refresh an expired Jira/Atlassian access token."""
    import httpx

    resp = httpx.post(
        _JIRA_TOKEN_URL,
        json={
            "grant_type": "refresh_token",
            "client_id": config.jira_client_id,
            "client_secret": config.jira_client_secret,
            "refresh_token": token.refresh_token,
        },
        timeout=15,
    )
    resp.raise_for_status()
    data = resp.json()

    return OAuthToken(
        provider="jira",
        access_token=data["access_token"],
        refresh_token=data.get("refresh_token", token.refresh_token),
        token_type=data.get("token_type", "Bearer"),
        expires_at=time.time() + int(data.get("expires_in", 3600)),
        scope=token.scope,
        cloud_id=token.cloud_id,
    )
