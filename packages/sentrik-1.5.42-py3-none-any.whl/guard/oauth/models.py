"""OAuth data models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class OAuthConfig:
    """OAuth configuration for a DevOps provider."""

    # Azure DevOps via Microsoft Entra ID (Azure AD)
    azure_client_id: str = ""
    azure_client_secret: str = ""
    azure_tenant_id: str = "common"  # "common" for multi-tenant, or specific tenant ID
    azure_redirect_uri: str = ""

    # GitHub OAuth
    github_client_id: str = ""
    github_client_secret: str = ""
    github_redirect_uri: str = ""

    # Atlassian (Jira) OAuth
    jira_client_id: str = ""
    jira_client_secret: str = ""
    jira_redirect_uri: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OAuthConfig:
        known = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in data.items() if k in known})


@dataclass
class OAuthToken:
    """Stored OAuth token for a provider."""

    provider: str  # "azure", "github", "jira"
    access_token: str = ""
    refresh_token: str = ""
    token_type: str = "Bearer"
    expires_at: float = 0.0  # Unix timestamp
    scope: str = ""
    # Jira-specific: cloud ID for API calls
    cloud_id: str = ""

    def is_expired(self, buffer_seconds: int = 300) -> bool:
        """Check if token is expired or will expire within buffer."""
        import time
        if self.expires_at <= 0:
            return False  # No expiry (e.g. GitHub classic tokens)
        return time.time() >= (self.expires_at - buffer_seconds)
