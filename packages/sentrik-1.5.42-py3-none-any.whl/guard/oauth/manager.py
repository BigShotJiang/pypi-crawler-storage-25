"""OAuth manager — coordinates token lifecycle across providers."""

from __future__ import annotations

import logging
import os
from typing import Any

from guard.oauth.models import OAuthConfig, OAuthToken
from guard.oauth import store

logger = logging.getLogger(__name__)

# Maps provider name to the env vars that hold OAuth client credentials.
_ENV_KEYS: dict[str, dict[str, str]] = {
    "azure": {
        "client_id": "GUARD_AZURE_OAUTH_CLIENT_ID",
        "client_secret": "GUARD_AZURE_OAUTH_CLIENT_SECRET",
    },
    "github": {
        "client_id": "GUARD_GITHUB_OAUTH_CLIENT_ID",
        "client_secret": "GUARD_GITHUB_OAUTH_CLIENT_SECRET",
    },
    "jira": {
        "client_id": "GUARD_JIRA_OAUTH_CLIENT_ID",
        "client_secret": "GUARD_JIRA_OAUTH_CLIENT_SECRET",
    },
}

# Maps provider name to the legacy PAT env var names.
_LEGACY_PAT_KEYS: dict[str, list[str]] = {
    "azure": ["AZURE_DEVOPS_PAT"],
    "github": ["GITHUB_TOKEN"],
    "jira": ["JIRA_TOKEN", "JIRA_PAT"],
}


class OAuthManager:
    """High-level interface for OAuth credential management.

    Resolution order for each provider:
    1. Stored OAuth token (auto-refreshed if expired)
    2. Legacy PAT from environment variable
    """

    def __init__(self, config: OAuthConfig | None = None) -> None:
        self._config = config or OAuthConfig()

    @property
    def config(self) -> OAuthConfig:
        return self._config

    def get_access_token(self, provider: str) -> str | None:
        """Get a valid access token for a DevOps provider.

        Checks for stored OAuth token first (refreshing if needed),
        then falls back to legacy PAT env vars.
        """
        # 1. Try stored OAuth token
        token = store.load_token(provider)
        if token and token.access_token:
            if token.is_expired() and token.refresh_token:
                token = self._refresh(provider, token)
                if token:
                    store.save_token(token)
            if token and not token.is_expired():
                return token.access_token

        # 2. Fall back to legacy PAT env vars
        for key in _LEGACY_PAT_KEYS.get(provider, []):
            val = os.environ.get(key)
            if val:
                return val

        return None

    def get_token(self, provider: str) -> OAuthToken | None:
        """Get the full OAuthToken object (for providers that need extra fields like cloud_id)."""
        token = store.load_token(provider)
        if token and token.access_token:
            if token.is_expired() and token.refresh_token:
                token = self._refresh(provider, token)
                if token:
                    store.save_token(token)
            if token and not token.is_expired():
                return token
        return None

    def is_oauth_connected(self, provider: str) -> bool:
        """Check if a provider has a valid OAuth connection."""
        return store.has_token(provider)

    def disconnect(self, provider: str) -> None:
        """Remove stored OAuth tokens for a provider."""
        store.delete_token(provider)

    def get_authorize_url(self, provider: str, base_url: str = "") -> tuple[str, str]:
        """Build the OAuth authorize URL for a provider.

        Args:
            provider: "azure", "github", or "jira"
            base_url: The base URL of the SENTRIK server (for callback)

        Returns:
            (authorize_url, state) tuple.
        """
        from guard.oauth import providers as oauth_providers

        config = self._ensure_redirect_uris(base_url)

        if provider == "azure":
            return oauth_providers.azure_get_authorize_url(config)
        elif provider == "github":
            return oauth_providers.github_get_authorize_url(config)
        elif provider == "jira":
            return oauth_providers.jira_get_authorize_url(config)
        else:
            raise ValueError(f"Unknown OAuth provider: {provider}")

    def exchange_code(self, provider: str, code: str, base_url: str = "") -> OAuthToken:
        """Exchange an authorization code for tokens and store them.

        Args:
            provider: "azure", "github", or "jira"
            code: The authorization code from the callback.
            base_url: The base URL (for redirect_uri matching).

        Returns:
            The stored OAuthToken.
        """
        from guard.oauth import providers as oauth_providers

        config = self._ensure_redirect_uris(base_url)

        if provider == "azure":
            token = oauth_providers.azure_exchange_code(config, code)
        elif provider == "github":
            token = oauth_providers.github_exchange_code(config, code)
        elif provider == "jira":
            token = oauth_providers.jira_exchange_code(config, code)
        else:
            raise ValueError(f"Unknown OAuth provider: {provider}")

        store.save_token(token)
        logger.info("OAuth token exchanged and stored for provider=%s", provider)
        return token

    def _refresh(self, provider: str, token: OAuthToken) -> OAuthToken | None:
        """Attempt to refresh an expired token."""
        from guard.oauth import providers as oauth_providers

        try:
            if provider == "azure":
                return oauth_providers.azure_refresh_token(self._config, token)
            elif provider == "jira":
                return oauth_providers.jira_refresh_token(self._config, token)
            else:
                # GitHub OAuth tokens don't expire
                return token
        except Exception as exc:
            logger.error("OAuth token refresh failed for %s: %s", provider, exc)
            return None

    def _ensure_redirect_uris(self, base_url: str) -> OAuthConfig:
        """Fill in redirect URIs from base_url if not already configured."""
        import dataclasses
        config = dataclasses.replace(self._config)
        if base_url:
            base = base_url.rstrip("/")
            if not config.azure_redirect_uri:
                config.azure_redirect_uri = f"{base}/oauth/azure/callback"
            if not config.github_redirect_uri:
                config.github_redirect_uri = f"{base}/oauth/github/callback"
            if not config.jira_redirect_uri:
                config.jira_redirect_uri = f"{base}/oauth/jira/callback"
        return config

    def get_connection_status(self, provider: str) -> dict[str, Any]:
        """Get OAuth connection status for a provider."""
        token = store.load_token(provider)
        if not token or not token.access_token:
            # Check legacy PAT
            for key in _LEGACY_PAT_KEYS.get(provider, []):
                if os.environ.get(key):
                    return {
                        "connected": True,
                        "method": "pat",
                        "message": f"Connected via {key} environment variable",
                    }
            return {"connected": False, "method": None, "message": "Not connected"}

        expired = token.is_expired()
        can_refresh = bool(token.refresh_token)

        if expired and not can_refresh:
            return {
                "connected": False,
                "method": "oauth",
                "message": "OAuth token expired — reconnect required",
            }

        return {
            "connected": True,
            "method": "oauth",
            "message": "Connected via OAuth" + (" (token will auto-refresh)" if can_refresh else ""),
        }


def build_oauth_config() -> OAuthConfig:
    """Build OAuthConfig from environment variables."""
    return OAuthConfig(
        azure_client_id=os.environ.get("GUARD_AZURE_OAUTH_CLIENT_ID", ""),
        azure_client_secret=os.environ.get("GUARD_AZURE_OAUTH_CLIENT_SECRET", ""),
        azure_tenant_id=os.environ.get("GUARD_AZURE_OAUTH_TENANT_ID", "common"),
        azure_redirect_uri=os.environ.get("GUARD_AZURE_OAUTH_REDIRECT_URI", ""),
        github_client_id=os.environ.get("GUARD_GITHUB_OAUTH_CLIENT_ID", ""),
        github_client_secret=os.environ.get("GUARD_GITHUB_OAUTH_CLIENT_SECRET", ""),
        github_redirect_uri=os.environ.get("GUARD_GITHUB_OAUTH_REDIRECT_URI", ""),
        jira_client_id=os.environ.get("GUARD_JIRA_OAUTH_CLIENT_ID", ""),
        jira_client_secret=os.environ.get("GUARD_JIRA_OAUTH_CLIENT_SECRET", ""),
        jira_redirect_uri=os.environ.get("GUARD_JIRA_OAUTH_REDIRECT_URI", ""),
    )
