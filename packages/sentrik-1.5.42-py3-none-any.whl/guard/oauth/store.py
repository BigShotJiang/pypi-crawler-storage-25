"""Secure local storage for OAuth tokens in .sentrik/local/oauth_tokens.json.

Tokens are encrypted at rest using Fernet symmetric encryption with a
machine-derived key. The key is derived from a persistent random salt
stored alongside the token file, combined with a machine identifier.
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import platform
import threading
from pathlib import Path
from typing import Any

_token_lock = threading.Lock()

from guard.oauth.models import OAuthToken

logger = logging.getLogger(__name__)

_TOKEN_FILENAME = "oauth_tokens.json"
_SALT_FILENAME = ".token_salt"


def _get_token_path() -> Path:
    """Resolve the token storage path.

    Uses .sentrik/local/ (gitignored) in the project root,
    or falls back to ~/.sentrik/local/ for global tokens.
    """
    # Check for project-local .sentrik/local/
    sentrik_dir = Path(".sentrik", "local")
    if sentrik_dir.parent.exists():
        sentrik_dir.mkdir(parents=True, exist_ok=True)
        return sentrik_dir / _TOKEN_FILENAME

    # Fallback to user home
    home_dir = Path.home() / ".sentrik" / "local"
    home_dir.mkdir(parents=True, exist_ok=True)
    return home_dir / _TOKEN_FILENAME


def _get_machine_id() -> str:
    """Return a stable machine identifier for key derivation."""
    try:
        username = os.getlogin()
    except OSError:
        username = os.environ.get("USER") or os.environ.get("USERNAME") or "user"
    return f"{platform.node()}-{username}"


def _get_encryption_key(token_dir: Path) -> bytes:
    """Derive a Fernet encryption key from machine ID + persistent salt.

    The salt is stored in a file alongside the tokens. If it doesn't
    exist, a new random salt is generated and saved.
    """
    salt_path = token_dir / _SALT_FILENAME
    if salt_path.exists():
        salt = salt_path.read_bytes()
    else:
        salt = os.urandom(32)
        salt_path.write_bytes(salt)
        try:
            os.chmod(salt_path, 0o600)
        except (OSError, AttributeError):
            logger.warning("Could not set restricted permissions on %s — file may be world-readable", salt_path)

    machine_id = _get_machine_id().encode("utf-8")
    key_material = hashlib.pbkdf2_hmac("sha256", machine_id, salt, iterations=100_000)
    return base64.urlsafe_b64encode(key_material)


def _encrypt(plaintext: str, key: bytes) -> str:
    """Encrypt a string with Fernet and return base64-encoded ciphertext."""
    try:
        from cryptography.fernet import Fernet
        f = Fernet(key)
        return f.encrypt(plaintext.encode("utf-8")).decode("ascii")
    except ImportError:
        logger.error(
            "SECURITY: cryptography package not installed — refusing to store tokens as plaintext. "
            "Install with: pip install cryptography"
        )
        raise RuntimeError(
            "Cannot store OAuth tokens: 'cryptography' package is required. "
            "Install with: pip install cryptography"
        )


def _decrypt(ciphertext: str, key: bytes) -> str:
    """Decrypt a Fernet-encrypted string. Falls back to plaintext for migration."""
    try:
        from cryptography.fernet import Fernet, InvalidToken
        f = Fernet(key)
        try:
            return f.decrypt(ciphertext.encode("ascii")).decode("utf-8")
        except (InvalidToken, ValueError):
            # Likely a plaintext token from before encryption was added
            logger.info("Token appears unencrypted — will re-encrypt on next save")
            return ciphertext
    except ImportError:
        return ciphertext


def _load_all_tokens(path: Path) -> dict[str, Any]:
    """Load all tokens from disk, decrypting if necessary."""
    if not path.exists():
        return {}
    try:
        with open(path, "r") as f:
            raw = json.load(f)
    except (json.JSONDecodeError, OSError) as exc:
        logger.warning("Failed to read OAuth tokens: %s", exc)
        return {}

    key = _get_encryption_key(path.parent)
    result = {}
    for provider, token_data in raw.items():
        if isinstance(token_data, str):
            # Encrypted blob
            decrypted = _decrypt(token_data, key)
            try:
                result[provider] = json.loads(decrypted)
            except json.JSONDecodeError:
                logger.warning("Failed to decrypt token for %s", provider)
                continue
        else:
            # Legacy plaintext dict — will be re-encrypted on next save
            result[provider] = token_data
    return result


def _save_all_tokens(path: Path, data: dict[str, Any]) -> None:
    """Write all tokens to disk, encrypted with Fernet."""
    key = _get_encryption_key(path.parent)
    encrypted = {}
    for provider, token_data in data.items():
        plaintext = json.dumps(token_data)
        encrypted[provider] = _encrypt(plaintext, key)
    try:
        content = json.dumps(encrypted, indent=2)
        # Write with restricted permissions from the start (no world-readable window)
        try:
            fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w") as f:
                f.write(content)
        except (OSError, AttributeError):
            # Fallback for platforms that don't support os.open mode (Windows)
            with open(path, "w") as f:
                f.write(content)
            logger.warning("Could not set restricted file permissions on %s", path)
    except OSError as exc:
        logger.error("Failed to write OAuth tokens: %s", exc)


def save_token(token: OAuthToken) -> None:
    """Save an OAuth token for a provider (thread-safe)."""
    with _token_lock:
        path = _get_token_path()
        data = _load_all_tokens(path)
        data[token.provider] = {
            "provider": token.provider,
            "access_token": token.access_token,
            "refresh_token": token.refresh_token,
            "token_type": token.token_type,
            "expires_at": token.expires_at,
            "scope": token.scope,
            "cloud_id": token.cloud_id,
        }
        _save_all_tokens(path, data)
    logger.info("OAuth token saved for provider=%s", token.provider)


def load_token(provider: str) -> OAuthToken | None:
    """Load an OAuth token for a provider, or None if not found."""
    path = _get_token_path()
    data = _load_all_tokens(path)
    token_data = data.get(provider)
    if not token_data:
        return None
    return OAuthToken(
        provider=token_data.get("provider", provider),
        access_token=token_data.get("access_token", ""),
        refresh_token=token_data.get("refresh_token", ""),
        token_type=token_data.get("token_type", "Bearer"),
        expires_at=token_data.get("expires_at", 0),
        scope=token_data.get("scope", ""),
        cloud_id=token_data.get("cloud_id", ""),
    )


def delete_token(provider: str) -> None:
    """Remove a stored OAuth token for a provider (thread-safe)."""
    with _token_lock:
        path = _get_token_path()
        data = _load_all_tokens(path)
        if provider in data:
            del data[provider]
            _save_all_tokens(path, data)
            logger.info("OAuth token deleted for provider=%s", provider)


def has_token(provider: str) -> bool:
    """Check if an OAuth token exists for a provider."""
    path = _get_token_path()
    data = _load_all_tokens(path)
    return provider in data and bool(data[provider].get("access_token"))
