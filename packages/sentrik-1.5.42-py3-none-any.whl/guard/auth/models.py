"""Authentication data models for Sentrik."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


# Valid roles within the Sentrik platform
VALID_ROLES = {"admin", "security-lead", "developer", "viewer", "agent"}

# Valid auth providers
VALID_AUTH_PROVIDERS = {"auth0", "okta", "none"}


class TokenPayload(BaseModel):
    """Decoded JWT token claims from Auth0/Okta."""

    sub: str = ""  # Auth0 user ID (e.g. "auth0|abc123")
    email: str = ""
    email_verified: bool = False
    name: str = ""
    org_id: str = ""
    roles: list[str] = Field(default_factory=list)
    permissions: list[str] = Field(default_factory=list)
    iss: str = ""  # Issuer
    aud: str | list[str] = ""  # Audience
    exp: int = 0  # Expiry timestamp
    iat: int = 0  # Issued-at timestamp


class UserContext(BaseModel):
    """Authenticated user context passed through the request lifecycle.

    Created from either a JWT token or an API key. When auth is disabled
    or an API key is used, a minimal anonymous context is returned.
    """

    user_id: str = "anonymous"
    email: str = ""
    name: str = ""
    org_id: str = ""
    roles: list[str] = Field(default_factory=list)
    repo_access: list[str] = Field(default_factory=list)
    auth_method: str = "none"  # "jwt", "api_key", "session", "none"
    is_authenticated: bool = False

    @classmethod
    def anonymous(cls) -> UserContext:
        """Return an unauthenticated anonymous context."""
        return cls()

    @classmethod
    def from_api_key(cls) -> UserContext:
        """Return a context for API-key-authenticated requests."""
        return cls(
            user_id="api-key",
            auth_method="api_key",
            is_authenticated=True,
            roles=["admin"],  # API key holders get full access
        )

    @classmethod
    def from_token(cls, payload: TokenPayload) -> UserContext:
        """Build a UserContext from a decoded JWT payload."""
        return cls(
            user_id=payload.sub,
            email=payload.email,
            name=payload.name,
            org_id=payload.org_id,
            roles=payload.roles,
            auth_method="jwt",
            is_authenticated=True,
        )

    def has_role(self, role: str) -> bool:
        """Check if the user has a specific role."""
        return role in self.roles or "admin" in self.roles

    def has_any_role(self, *roles: str) -> bool:
        """Check if the user has any of the specified roles."""
        return any(self.has_role(r) for r in roles)

    def has_permission(self, action: str) -> bool:
        """Check if the user's roles grant a specific permission."""
        from guard.authz.models import Permission, ROLE_PERMISSIONS

        try:
            perm = Permission(action)
        except ValueError:
            return False
        granted: set[Permission] = set()
        for role in self.roles:
            perms = ROLE_PERMISSIONS.get(role)
            if perms is not None:
                granted |= perms
        return perm in granted


class AuthConfig(BaseModel):
    """Auth configuration section for .guard.yaml."""

    enabled: bool = False
    provider: str = "none"  # "auth0", "okta", "none"
    auth0_domain: str = ""
    auth0_client_id: str = ""
    auth0_audience: str = ""
    auth0_cli_client_id: str = ""
    jwt_algorithms: list[str] = Field(default_factory=lambda: ["RS256"])
    session_expiry_hours: int = 24
