"""JWT validation and decoding for Auth0/Okta tokens."""

from __future__ import annotations

import logging
import threading
import time
from typing import Any, Optional

from guard.auth.models import AuthConfig, TokenPayload, UserContext

logger = logging.getLogger(__name__)

# Cache for JWKS keys (refreshed every hour)
_jwks_cache: dict[str, Any] = {}
_jwks_cache_expiry: float = 0
_jwks_cache_fetched_at: float = 0
_JWKS_CACHE_TTL = 3600  # 1 hour
_JWKS_MAX_STALE_AGE = 86400  # 24 hours — refuse stale cache older than this
_jwks_lock = threading.Lock()


class JWTValidationError(Exception):
    """Raised when JWT validation fails."""


class JWTHandler:
    """Handles JWT token validation using Auth0/Okta JWKS endpoints."""

    def __init__(self, config: AuthConfig) -> None:
        self.config = config
        self._jwks_client: Any = None

    def _get_jwks_url(self) -> str:
        """Build the JWKS URI from the provider domain."""
        domain = self.config.auth0_domain.rstrip("/")
        if not domain.startswith("http"):
            domain = f"https://{domain}"
        return f"{domain}/.well-known/jwks.json"

    def _get_issuer(self) -> str:
        """Build the expected issuer URL."""
        domain = self.config.auth0_domain.rstrip("/")
        if not domain.startswith("http"):
            domain = f"https://{domain}"
        return f"{domain}/"

    def _fetch_jwks(self) -> dict[str, Any]:
        """Fetch and cache JWKS keys from the provider.

        Uses double-checked locking to prevent concurrent refresh attempts
        from corrupting the cache or making redundant network requests.
        """
        global _jwks_cache, _jwks_cache_expiry, _jwks_cache_fetched_at

        # Fast path: return valid cache without acquiring the lock
        now = time.time()
        if _jwks_cache and now < _jwks_cache_expiry:
            return _jwks_cache

        with _jwks_lock:
            # Double-check after acquiring lock — another thread may have refreshed
            now = time.time()
            if _jwks_cache and now < _jwks_cache_expiry:
                return _jwks_cache

            try:
                import httpx
                resp = httpx.get(self._get_jwks_url(), timeout=10)
                resp.raise_for_status()
                new_keys = resp.json()
                # Validate structure before committing to cache
                if not isinstance(new_keys, dict) or "keys" not in new_keys:
                    raise JWTValidationError("JWKS response missing 'keys' array")
                _jwks_cache = new_keys
                _jwks_cache_expiry = now + _JWKS_CACHE_TTL
                _jwks_cache_fetched_at = now
                return _jwks_cache
            except JWTValidationError:
                raise
            except Exception as exc:
                logger.error("Failed to fetch JWKS: %s", exc)
                # Return stale cache only if within max staleness window
                if _jwks_cache:
                    stale_age = now - _jwks_cache_fetched_at
                    if stale_age <= _JWKS_MAX_STALE_AGE:
                        logger.warning(
                            "Using stale JWKS cache (age: %.0fs). "
                            "Will reject after %ds.",
                            stale_age, _JWKS_MAX_STALE_AGE,
                        )
                        return _jwks_cache
                    logger.error(
                        "Stale JWKS cache exceeded max age (%ds). "
                        "Refusing to use expired keys for authentication.",
                        _JWKS_MAX_STALE_AGE,
                    )
                raise JWTValidationError(f"Cannot fetch JWKS keys: {exc}") from exc

    def _get_signing_key(self, token: str) -> Any:
        """Extract the signing key for the given token from JWKS."""
        try:
            from jose import jwt as jose_jwt
            from jose.utils import base64url_decode
        except ImportError:
            raise JWTValidationError(
                "python-jose is required for JWT auth. "
                "Install with: pip install 'ai-sdlc-guard[auth]'"
            )

        # Get the key ID from the token header
        unverified_header = jose_jwt.get_unverified_header(token)
        kid = unverified_header.get("kid")
        if not kid:
            raise JWTValidationError("Token header missing 'kid' claim")

        jwks = self._fetch_jwks()
        for key in jwks.get("keys", []):
            if key.get("kid") == kid:
                return key

        # Key not found — force refresh cache and retry once
        global _jwks_cache_expiry
        with _jwks_lock:
            _jwks_cache_expiry = 0
        jwks = self._fetch_jwks()
        for key in jwks.get("keys", []):
            if key.get("kid") == kid:
                return key

        raise JWTValidationError(f"No matching JWKS key for kid={kid!r}")

    def decode_token(self, token: str) -> TokenPayload:
        """Validate and decode a JWT Bearer token.

        Returns a TokenPayload with the decoded claims.
        Raises JWTValidationError on any validation failure.
        """
        try:
            from jose import jwt as jose_jwt, JWTError
        except ImportError:
            raise JWTValidationError(
                "python-jose is required for JWT auth. "
                "Install with: pip install 'ai-sdlc-guard[auth]'"
            )

        rsa_key = self._get_signing_key(token)

        try:
            payload = jose_jwt.decode(
                token,
                rsa_key,
                algorithms=self.config.jwt_algorithms,
                audience=self.config.auth0_audience,
                issuer=self._get_issuer(),
            )
        except JWTError as exc:
            raise JWTValidationError(f"JWT validation failed: {exc}") from exc

        # Extract Auth0 namespace claims (custom claims use namespace prefix)
        roles = payload.get("roles", [])
        if not roles:
            # Auth0 custom namespace pattern
            for key in payload:
                if key.endswith("/roles"):
                    roles = payload[key]
                    break

        permissions = payload.get("permissions", [])

        return TokenPayload(
            sub=payload.get("sub", ""),
            email=payload.get("email", ""),
            email_verified=payload.get("email_verified", False),
            name=payload.get("name", ""),
            org_id=payload.get("org_id", ""),
            roles=roles if isinstance(roles, list) else [],
            permissions=permissions if isinstance(permissions, list) else [],
            iss=payload.get("iss", ""),
            aud=payload.get("aud", ""),
            exp=payload.get("exp", 0),
            iat=payload.get("iat", 0),
        )

    def validate_and_get_user(self, token: str) -> UserContext:
        """Validate a JWT and return a UserContext.

        Convenience method that combines decode + user context creation.
        """
        payload = self.decode_token(token)
        return UserContext.from_token(payload)
