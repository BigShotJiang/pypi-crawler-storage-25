"""OAuth 2.0 Device Authorization Grant (RFC 8628) for SENTRIK CLI.

Implements the device flow for Auth0:
1. Request device code from Auth0
2. User visits URL and enters code
3. CLI polls for tokens
4. Tokens stored locally in .sentrik/local/auth.json
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass
from pathlib import Path

import httpx

logger = logging.getLogger(__name__)

AUTH_FILE = ".sentrik/local/auth.json"


@dataclass
class DeviceCodeResponse:
    device_code: str
    user_code: str
    verification_uri: str
    verification_uri_complete: str
    expires_in: int
    interval: int


@dataclass
class TokenResponse:
    access_token: str
    refresh_token: str
    id_token: str
    token_type: str
    expires_in: int
    scope: str


def _get_auth0_domain() -> str:
    return os.environ.get("GUARD_AUTH0_DOMAIN", "")


def _get_client_id() -> str:
    return os.environ.get("GUARD_AUTH0_CLI_CLIENT_ID", "")


def _get_audience() -> str:
    return os.environ.get("GUARD_AUTH0_AUDIENCE", "https://api.sentrik.dev")


def request_device_code(domain: str = "", client_id: str = "", audience: str = "") -> DeviceCodeResponse:
    """POST /oauth/device/code to get a device code + user code."""
    domain = domain or _get_auth0_domain()
    client_id = client_id or _get_client_id()
    audience = audience or _get_audience()

    if not domain or not client_id:
        raise ValueError("Auth0 domain and client ID are required. Set GUARD_AUTH0_DOMAIN and GUARD_AUTH0_CLI_CLIENT_ID.")

    # Validate domain to prevent SSRF — must be a valid hostname, no path/port/scheme
    import re
    if not re.match(r"^[a-zA-Z0-9]([a-zA-Z0-9\-]*\.)+[a-zA-Z]{2,}$", domain):
        raise ValueError(f"Invalid Auth0 domain format: {domain!r}. Expected a hostname like 'myapp.auth0.com'.")

    resp = httpx.post(
        f"https://{domain}/oauth/device/code",
        data={
            "client_id": client_id,
            "scope": "openid profile email offline_access",
            "audience": audience,
        },
    )
    resp.raise_for_status()
    data = resp.json()

    return DeviceCodeResponse(
        device_code=data["device_code"],
        user_code=data["user_code"],
        verification_uri=data["verification_uri"],
        verification_uri_complete=data.get("verification_uri_complete", data["verification_uri"]),
        expires_in=data["expires_in"],
        interval=data["interval"],
    )


def poll_for_tokens(
    domain: str = "",
    client_id: str = "",
    device_code: str = "",
    interval: int = 5,
    timeout: int = 300,
) -> TokenResponse:
    """Poll /oauth/token until the user authorizes or timeout."""
    domain = domain or _get_auth0_domain()
    client_id = client_id or _get_client_id()

    url = f"https://{domain}/oauth/token"
    elapsed = 0
    current_interval = interval

    while elapsed < timeout:
        time.sleep(current_interval)
        elapsed += max(current_interval, 1)

        resp = httpx.post(
            url,
            data={
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "device_code": device_code,
                "client_id": client_id,
            },
        )

        if resp.status_code == 200:
            data = resp.json()
            return TokenResponse(
                access_token=data["access_token"],
                refresh_token=data.get("refresh_token", ""),
                id_token=data.get("id_token", ""),
                token_type=data.get("token_type", "Bearer"),
                expires_in=data.get("expires_in", 86400),
                scope=data.get("scope", ""),
            )

        error_data = resp.json() if resp.status_code == 403 else {}
        error = error_data.get("error", "")

        if error == "authorization_pending":
            continue
        elif error == "slow_down":
            current_interval += 5
            continue
        elif error == "expired_token":
            raise TimeoutError("Device code expired. Please try again.")
        elif error == "access_denied":
            raise PermissionError("Authorization denied by user.")
        else:
            resp.raise_for_status()

    raise TimeoutError(f"Polling timed out after {timeout} seconds.")


def save_tokens(tokens: TokenResponse, auth_file: str = "") -> Path:
    """Save tokens to .sentrik/local/auth.json."""
    path = Path(auth_file or AUTH_FILE)
    path.parent.mkdir(parents=True, exist_ok=True)

    data = {
        "access_token": tokens.access_token,
        "refresh_token": tokens.refresh_token,
        "id_token": tokens.id_token,
        "token_type": tokens.token_type,
        "expires_in": tokens.expires_in,
        "scope": tokens.scope,
        "saved_at": int(time.time()),
    }

    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    logger.info("Tokens saved to %s", path)
    return path


def load_tokens(auth_file: str = "") -> dict | None:
    """Load tokens from disk. Returns None if not found."""
    path = Path(auth_file or AUTH_FILE)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def refresh_access_token(
    domain: str = "",
    client_id: str = "",
    refresh_token: str = "",
) -> TokenResponse:
    """Use refresh token to get new access token."""
    domain = domain or _get_auth0_domain()
    client_id = client_id or _get_client_id()

    resp = httpx.post(
        f"https://{domain}/oauth/token",
        data={
            "grant_type": "refresh_token",
            "client_id": client_id,
            "refresh_token": refresh_token,
        },
    )
    resp.raise_for_status()
    data = resp.json()

    return TokenResponse(
        access_token=data["access_token"],
        refresh_token=data.get("refresh_token", refresh_token),
        id_token=data.get("id_token", ""),
        token_type=data.get("token_type", "Bearer"),
        expires_in=data.get("expires_in", 86400),
        scope=data.get("scope", ""),
    )


def get_valid_token(domain: str = "", client_id: str = "", auth_file: str = "") -> str | None:
    """Load tokens, auto-refresh if < 5 min to expiry, return access_token or None."""
    tokens = load_tokens(auth_file)
    if not tokens:
        return None

    saved_at = tokens.get("saved_at", 0)
    expires_in = tokens.get("expires_in", 0)
    expiry_time = saved_at + expires_in

    # If more than 5 minutes remaining, use current token
    if time.time() < expiry_time - 300:
        return tokens["access_token"]

    # Try to refresh
    refresh_tok = tokens.get("refresh_token", "")
    if not refresh_tok:
        return None

    try:
        new_tokens = refresh_access_token(domain, client_id, refresh_tok)
        save_tokens(new_tokens, auth_file)
        return new_tokens.access_token
    except (httpx.HTTPError, OSError, KeyError):
        logger.warning("Token refresh failed")
        return None


def clear_tokens(auth_file: str = "") -> bool:
    """Delete stored tokens. Returns True if file was deleted."""
    path = Path(auth_file or AUTH_FILE)
    if path.exists():
        path.unlink()
        logger.info("Tokens cleared from %s", path)
        return True
    return False
