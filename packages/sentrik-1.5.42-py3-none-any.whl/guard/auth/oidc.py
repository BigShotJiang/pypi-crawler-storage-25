"""OIDC client for Auth0/Okta login flows."""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import secrets
import time
from base64 import urlsafe_b64decode, urlsafe_b64encode
from typing import Any, Optional

from guard.auth.models import AuthConfig

logger = logging.getLogger(__name__)


class OIDCError(Exception):
    """Raised on OIDC flow errors."""


class OIDCClient:
    """Handles Auth0/Okta OIDC authorization code flow for dashboard login."""

    def __init__(self, config: AuthConfig, client_secret: str = "",
                 redirect_uri: str = "") -> None:
        self.config = config
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri
        self._base_url = self._build_base_url()

    def _build_base_url(self) -> str:
        domain = self.config.auth0_domain.rstrip("/")
        if not domain.startswith("http"):
            domain = f"https://{domain}"
        return domain

    def get_authorize_url(self, state: str = "") -> str:
        """Build the Auth0 /authorize URL for the login redirect.

        Args:
            state: CSRF state parameter (generated if empty).

        Returns:
            The full authorization URL to redirect the user to.
        """
        if not state:
            state = secrets.token_urlsafe(32)

        params = {
            "response_type": "code",
            "client_id": self.config.auth0_client_id,
            "redirect_uri": self.redirect_uri,
            "scope": "openid profile email",
            "state": state,
        }
        if self.config.auth0_audience:
            params["audience"] = self.config.auth0_audience

        query = "&".join(f"{k}={_url_encode(v)}" for k, v in params.items())
        return f"{self._base_url}/authorize?{query}"

    def exchange_code(self, code: str) -> dict[str, Any]:
        """Exchange an authorization code for tokens.

        Args:
            code: The authorization code from the callback.

        Returns:
            Dict with access_token, id_token, token_type, expires_in.

        Raises:
            OIDCError: On token exchange failure.
        """
        try:
            import httpx
        except ImportError:
            raise OIDCError(
                "httpx is required for OIDC. "
                "Install with: pip install 'ai-sdlc-guard[auth]'"
            )

        token_url = f"{self._base_url}/oauth/token"
        payload = {
            "grant_type": "authorization_code",
            "client_id": self.config.auth0_client_id,
            "client_secret": self.client_secret,
            "code": code,
            "redirect_uri": self.redirect_uri,
        }

        try:
            resp = httpx.post(token_url, json=payload, timeout=15)
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPStatusError as exc:
            body = exc.response.text
            logger.error("Token exchange failed: %s — %s", exc, body)
            raise OIDCError(f"Token exchange failed: {body}") from exc
        except Exception as exc:
            logger.error("Token exchange error: %s", exc)
            raise OIDCError(f"Token exchange error: {exc}") from exc

    def get_logout_url(self, return_to: str = "") -> str:
        """Build the Auth0 logout URL.

        Args:
            return_to: URL to redirect after logout.

        Returns:
            The full logout URL.
        """
        params = {"client_id": self.config.auth0_client_id}
        if return_to:
            params["returnTo"] = return_to
        query = "&".join(f"{k}={_url_encode(v)}" for k, v in params.items())
        return f"{self._base_url}/v2/logout?{query}"

    def get_userinfo(self, access_token: str) -> dict[str, Any]:
        """Fetch user profile from the /userinfo endpoint.

        Args:
            access_token: A valid Auth0 access token.

        Returns:
            Dict with user profile fields.
        """
        try:
            import httpx
        except ImportError:
            raise OIDCError("httpx is required for OIDC.")

        try:
            resp = httpx.get(
                f"{self._base_url}/userinfo",
                headers={"Authorization": f"Bearer {access_token}"},
                timeout=10,
            )
            resp.raise_for_status()
            return resp.json()
        except Exception as exc:
            logger.error("Userinfo fetch failed: %s", exc)
            raise OIDCError(f"Userinfo fetch failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Session helpers (signed cookie-based sessions)
# ---------------------------------------------------------------------------

class SessionManager:
    """Simple signed-cookie session manager for dashboard authentication.

    Uses HMAC-SHA256 to sign session data stored in cookies.
    This avoids server-side session storage while preventing tampering.
    """

    def __init__(self, secret: str, expiry_hours: int = 24) -> None:
        if not secret:
            raise ValueError("Session secret must not be empty")
        self._secret = secret.encode()
        self._expiry_seconds = expiry_hours * 3600

    def create_session(self, data: dict[str, Any]) -> str:
        """Create a signed session cookie value.

        Args:
            data: Session data to encode (user_id, email, roles, etc.).

        Returns:
            Base64-encoded signed session string.
        """
        payload = {
            **data,
            "_exp": int(time.time()) + self._expiry_seconds,
        }
        raw = json.dumps(payload, separators=(",", ":")).encode()
        sig = hmac.new(self._secret, raw, hashlib.sha256).hexdigest()
        encoded = urlsafe_b64encode(raw).decode()
        return f"{encoded}.{sig}"

    def read_session(self, cookie_value: str) -> Optional[dict[str, Any]]:
        """Validate and decode a signed session cookie.

        Args:
            cookie_value: The raw cookie string.

        Returns:
            Session data dict, or None if invalid/expired.
        """
        if not cookie_value or "." not in cookie_value:
            return None

        try:
            encoded, sig = cookie_value.rsplit(".", 1)
            raw = urlsafe_b64decode(encoded.encode())
            expected_sig = hmac.new(self._secret, raw, hashlib.sha256).hexdigest()

            if not hmac.compare_digest(sig, expected_sig):
                logger.warning("Session cookie signature mismatch")
                return None

            data = json.loads(raw)

            # Check expiry
            if data.get("_exp", 0) < time.time():
                logger.debug("Session cookie expired")
                return None

            # Remove internal fields
            data.pop("_exp", None)
            return data

        except (json.JSONDecodeError, ValueError, KeyError, TypeError, UnicodeDecodeError) as exc:
            logger.debug("Session decode failed: %s", exc)
            return None


def _url_encode(value: str) -> str:
    """Minimal URL encoding for query parameters."""
    import urllib.parse
    return urllib.parse.quote(str(value), safe="")
