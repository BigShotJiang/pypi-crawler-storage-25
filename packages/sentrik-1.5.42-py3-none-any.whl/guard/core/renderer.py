"""Renders human-readable artifacts: report.md and next_actions.md."""

from __future__ import annotations

from collections import defaultdict

from guard.core.models import Finding, Severity


def render_report(findings: list[Finding]) -> str:
    """Render findings as a human-readable markdown report ordered by severity."""
    lines = ["# Guard Scan Report", ""]

    # Separate code findings from obligations
    code_findings = [f for f in findings if not f.is_obligation]
    obligations = [f for f in findings if f.is_obligation]

    if not code_findings and not obligations:
        lines.append("No findings detected. All checks passed.")
        return "\n".join(lines)

    severity_order = [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]

    # Render code findings by severity
    for sev in severity_order:
        sev_findings = [f for f in code_findings if f.severity == sev]
        if not sev_findings:
            continue
        lines.append(f"## {sev.value.upper()} ({len(sev_findings)})")
        lines.append("")
        for f in sev_findings:
            lines.append(f"### {f.finding_id} — {f.rule_id}")
            lines.append(f"**Message:** {f.message}")
            if f.standard and f.clause:
                lines.append(f"**Standard:** {f.standard} clause {f.clause}")
            elif f.standard:
                lines.append(f"**Standard:** {f.standard}")
            lines.append(f"**File:** `{f.evidence.file}`")
            if f.evidence.lines:
                lines.append(f"**Lines:** {f.evidence.lines}")
            if f.evidence.snippet:
                lines.append(f"```\n{f.evidence.snippet}\n```")
            if f.remediation_guidance:
                lines.append(f"**Remediation:** {f.remediation_guidance}")
            elif f.suggestion:
                lines.append(f"**Suggestion:** {f.suggestion}")
            det = "deterministic" if f.deterministic else "heuristic"
            lines.append(f"**Confidence:** {f.confidence} ({det})")
            if f.related_work_items:
                lines.append(f"**Related work items:** {', '.join(f.related_work_items)}")
            lines.append("")

    # Render compliance obligations section
    if obligations:
        lines.append("## Compliance Obligations")
        lines.append("")
        # Group by standard
        by_standard: dict[str, list[Finding]] = defaultdict(list)
        for o in obligations:
            key = o.standard or "General"
            by_standard[key].append(o)

        for std_name, std_obligations in by_standard.items():
            lines.append(f"### {std_name}")
            lines.append("")
            for o in std_obligations:
                clause_ref = f" (clause {o.clause})" if o.clause else ""
                lines.append(f"- **{o.rule_id}**{clause_ref}: {o.message}")
                if o.remediation_guidance:
                    lines.append(f"  - *Remediation:* {o.remediation_guidance}")
            lines.append("")

    return "\n".join(lines)


def render_next_actions(findings: list[Finding]) -> str:
    """Render an ordered action list for the agent."""
    lines = ["# Next Actions", ""]

    # Separate code findings from obligations
    code_findings = [f for f in findings if not f.is_obligation]
    obligations = [f for f in findings if f.is_obligation]

    if not code_findings and not obligations:
        lines.append("No actions required. All gates passed.")
        return "\n".join(lines)

    severity_order = [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]
    ordered = sorted(code_findings, key=lambda f: severity_order.index(f.severity))

    for i, f in enumerate(ordered, 1):
        action = f.suggestion if f.suggestion else f"Fix: {f.message}"
        lines.append(f"{i}. **[{f.severity.value.upper()}]** `{f.evidence.file}` — {action}")

    # Append obligation items
    if obligations:
        lines.append("")
        lines.append("## Compliance Obligations (non-code)")
        lines.append("")
        for o in obligations:
            clause_ref = f" clause {o.clause}" if o.clause else ""
            action = o.remediation_guidance if o.remediation_guidance else o.message
            lines.append(f"- **[OBLIGATION]** {o.rule_id}{clause_ref} — {action}")

    return "\n".join(lines)
