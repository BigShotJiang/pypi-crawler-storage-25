"""Reconciler engine — compares scan findings against work items and produces create/update/close actions."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

from guard.core.models import Finding, WorkItem
from guard.providers.devops_base import DevOpsProvider

logger = logging.getLogger(__name__)


@dataclass
class ReconcileAction:
    action: Literal["create", "update", "close"]
    rule_id: str
    work_item: WorkItem | None  # existing WI (for update/close) or None (for create)
    title: str
    description: str = ""
    acceptance_criteria: str = ""


@dataclass
class ReconcileResult:
    created: list[str] = field(default_factory=list)   # WI IDs created
    updated: list[str] = field(default_factory=list)   # WI IDs updated
    closed: list[str] = field(default_factory=list)    # WI IDs closed
    errors: list[str] = field(default_factory=list)    # error messages


def group_findings_by_rule(findings: list[Finding]) -> dict[str, list[Finding]]:
    """Group findings by their rule_id."""
    groups: dict[str, list[Finding]] = {}
    for f in findings:
        groups.setdefault(f.rule_id, []).append(f)
    return groups


def _build_title(rule_id: str, findings: list[Finding]) -> str:
    """Generate a work item title from a group of findings."""
    first = findings[0]
    name = first.message.split(".")[0].split(":")[0].strip()
    if len(name) > 80:
        name = name[:77] + "..."
    return f"[{rule_id}] {name}"


def _build_description(rule_id: str, findings: list[Finding]) -> str:
    """Generate an HTML work item description from a group of findings.

    Azure DevOps uses HTML for work item descriptions, not markdown.
    GitHub and Jira also accept HTML, so this is safe for all providers.
    """
    first = findings[0]
    import html as _html

    parts: list[str] = []
    parts.append(f"<b>Rule:</b> {_html.escape(rule_id)}<br>")
    parts.append(f"<b>Severity:</b> {_html.escape(first.severity.value)}<br>")
    parts.append(f"<b>Count:</b> {len(findings)} finding(s)<br>")

    if first.standard:
        parts.append(f"<b>Standard:</b> {_html.escape(first.standard)}<br>")
    if first.clause:
        parts.append(f"<b>Clause:</b> {_html.escape(first.clause)}<br>")
    if first.compliance_category:
        parts.append(f"<b>Category:</b> {_html.escape(first.compliance_category)}<br>")

    parts.append(f"<p>{_html.escape(first.message)}</p>")

    if first.remediation_guidance:
        parts.append(f"<p><b>Remediation:</b> {_html.escape(first.remediation_guidance)}</p>")

    # List affected files (up to 10)
    files = sorted({f.evidence.file for f in findings})
    if files:
        parts.append("<b>Affected files:</b>")
        parts.append("<ul>")
        for fp in files[:10]:
            parts.append(f"  <li><code>{_html.escape(fp)}</code></li>")
        if len(files) > 10:
            parts.append(f"  <li>... and {len(files) - 10} more</li>")
        parts.append("</ul>")

    return "\n".join(parts)


def _build_acceptance_criteria(rule_id: str, findings: list[Finding]) -> str:
    """Generate HTML acceptance criteria from findings."""
    import html as _html

    first = findings[0]
    items = [
        f"No {_html.escape(rule_id)} findings in sentrik scan",
        "sentrik gate passes with no critical/high findings",
    ]
    if first.suggestion:
        items.append(_html.escape(first.suggestion))
    li_items = "\n".join(f"  <li>{item}</li>" for item in items)
    return f"<ul>\n{li_items}\n</ul>"


def reconcile(
    findings: list[Finding],
    existing_items: list[WorkItem],
    skip_info: bool = True,
) -> list[ReconcileAction]:
    """Compute reconcile actions by comparing findings against existing work items.

    Returns a list of ReconcileAction (create/update/close).
    """
    actions: list[ReconcileAction] = []
    groups = group_findings_by_rule(findings)

    # Build lookup: rule_id -> existing work item
    rule_to_wi: dict[str, WorkItem] = {}
    for wi in existing_items:
        if wi.rule_id:
            rule_to_wi[wi.rule_id] = wi

    # Check each finding group
    for rule_id, rule_findings in groups.items():
        first = rule_findings[0]

        # Skip info-severity unless it's a documentation obligation
        if skip_info and first.severity.value == "info":
            if first.compliance_category != "documentation":
                continue

        title = _build_title(rule_id, rule_findings)
        desc = _build_description(rule_id, rule_findings)
        ac = _build_acceptance_criteria(rule_id, rule_findings)

        existing_wi = rule_to_wi.get(rule_id)

        if existing_wi is None:
            # No existing work item — create
            actions.append(ReconcileAction(
                action="create",
                rule_id=rule_id,
                work_item=None,
                title=title,
                description=desc,
                acceptance_criteria=ac,
            ))
        elif existing_wi.state == "closed":
            # WI was closed but findings re-appeared — re-open via update
            actions.append(ReconcileAction(
                action="update",
                rule_id=rule_id,
                work_item=existing_wi,
                title=title,
                description=desc,
                acceptance_criteria=ac,
            ))
        else:
            # WI exists and is active — update if description changed
            if existing_wi.description != desc:
                actions.append(ReconcileAction(
                    action="update",
                    rule_id=rule_id,
                    work_item=existing_wi,
                    title=title,
                    description=desc,
                    acceptance_criteria=ac,
                ))

    # Check for work items whose findings are now resolved
    active_rule_ids = set(groups.keys())
    for wi in existing_items:
        if wi.rule_id and wi.rule_id not in active_rule_ids and wi.state != "closed":
            actions.append(ReconcileAction(
                action="close",
                rule_id=wi.rule_id,
                work_item=wi,
                title=wi.title,
            ))

    return actions


def _next_wi_id(existing_items: list[WorkItem]) -> str:
    """Generate the next WI-XX identifier."""
    max_num = 0
    for wi in existing_items:
        if wi.id.startswith("WI-"):
            try:
                num = int(wi.id[3:])
                max_num = max(max_num, num)
            except ValueError:
                pass
    return f"WI-{max_num + 1}"


def execute_reconcile(
    actions: list[ReconcileAction],
    devops: DevOpsProvider,
    existing_items: list[WorkItem],
    wi_path: Path,
    output_dir: Path | None = None,
    work_item_type: str | None = None,
) -> ReconcileResult:
    """Execute reconcile actions: call DevOps provider + update work_items.json."""
    result = ReconcileResult()
    items = list(existing_items)  # copy to mutate

    for act in actions:
        if act.action == "create":
            create_kw = dict(
                title=act.title,
                description=act.description,
                acceptance_criteria=act.acceptance_criteria,
                tags=f"guard;{act.rule_id}",
            )
            if work_item_type:
                create_kw["work_item_type"] = work_item_type
            devops_id = devops.create_work_item(**create_kw)
            wi_id = _next_wi_id(items)
            ac_list = [
                line.lstrip("- ").strip()
                for line in (act.acceptance_criteria or "").splitlines()
                if line.strip()
            ]
            new_wi = WorkItem(
                id=wi_id,
                title=act.title,
                description=act.description,
                acceptance_criteria=ac_list,
                state="active",
                rule_id=act.rule_id,
                devops_id=devops_id,
            )
            items.append(new_wi)
            result.created.append(wi_id)
            if devops_id is None:
                result.errors.append(f"DevOps create failed for {act.rule_id}")

        elif act.action == "update":
            wi = act.work_item
            assert wi is not None
            ok = True
            if wi.devops_id:
                kw: dict = {"title": act.title, "description": act.description}
                if act.acceptance_criteria:
                    kw["acceptance_criteria"] = act.acceptance_criteria
                if wi.state == "closed":
                    kw["state"] = "Doing"
                ok = devops.update_work_item(wi.devops_id, **kw)

            # Update local copy
            wi.title = act.title
            wi.description = act.description
            if wi.state == "closed":
                wi.state = "active"
            result.updated.append(wi.id)
            if not ok:
                result.errors.append(f"DevOps update failed for {wi.id}")

        elif act.action == "close":
            wi = act.work_item
            assert wi is not None
            ok = True
            if wi.devops_id:
                ok = devops.close_work_item(wi.devops_id)
            wi.state = "closed"
            result.closed.append(wi.id)
            if not ok:
                result.errors.append(f"DevOps close failed for {wi.id}")

    # Write updated work_items.json
    data = [wi.model_dump(exclude_none=True) for wi in items]
    wi_path.parent.mkdir(parents=True, exist_ok=True)
    with open(wi_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")

    # Write reconcile summary artifact
    if output_dir:
        output_dir.mkdir(parents=True, exist_ok=True)
        summary = {
            "created": result.created,
            "updated": result.updated,
            "closed": result.closed,
            "errors": result.errors,
        }
        with open(output_dir / "reconcile_summary.json", "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
            f.write("\n")

    return result
