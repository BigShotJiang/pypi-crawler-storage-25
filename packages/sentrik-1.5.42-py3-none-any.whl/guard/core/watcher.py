"""File watcher and interval scheduler for continuous scanning.

Provides polling-based file change detection and periodic scan scheduling
using only the Python standard library (no watchdog/inotify dependencies).
"""

from __future__ import annotations

import fnmatch
import logging
import os

logger = logging.getLogger(__name__)
import time
import threading
from pathlib import Path
from typing import Callable

# Source file extensions that trigger a re-scan on change.
SOURCE_EXTENSIONS: frozenset[str] = frozenset({
    ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".c", ".cpp", ".cc",
    ".cxx", ".h", ".hpp", ".go", ".rb", ".rs", ".cs", ".swift", ".kt",
    ".kts", ".scala", ".php", ".lua", ".sh", ".bash", ".zsh", ".ps1",
    ".yaml", ".yml", ".json", ".toml", ".xml", ".sql",
    ".m", ".mm", ".pl", ".pm", ".dart", ".zig", ".nim", ".v", ".ex", ".r",
    ".exs", ".erl", ".hrl", ".hs", ".ml", ".mli", ".clj", ".cljs",
    ".vue", ".svelte",
})

# Default polling interval in seconds for checking file changes.
POLL_INTERVAL: float = 2.0

# Debounce delay in seconds — wait this long after the last change before
# triggering a scan.
DEBOUNCE_DELAY: float = 1.0


def _is_source_file(path: str) -> bool:
    """Return True if *path* has a recognised source file extension."""
    _, ext = os.path.splitext(path)
    return ext.lower() in SOURCE_EXTENSIONS


def _matches_exclude(path: str, excludes: list[str]) -> bool:
    """Return True if *path* matches any of the *excludes* glob patterns.

    Matching strategies per pattern:
    - Direct fnmatch (e.g. "*.pyc" matches "foo.pyc")
    - With **/ prefix (e.g. "*.pyc" matches "src/foo.pyc")
    - Directory prefix (e.g. "tests/" matches "tests/foo.py")
    """
    norm = path.replace("\\", "/")
    for pattern in excludes:
        pattern = pattern.replace("\\", "/")
        # Direct match
        if fnmatch.fnmatch(norm, pattern):
            return True
        # Match with **/ prefix (pattern anywhere in path)
        if fnmatch.fnmatch(norm, f"**/{pattern}"):
            return True
        # Directory-style match: "tests/" matches "tests/foo.py"
        stripped = pattern.rstrip("/")
        if norm.startswith(stripped + "/") or norm == stripped:
            return True
    return False


class FileWatcher:
    """Poll-based file watcher that detects new and modified source files.

    Parameters
    ----------
    root : str | Path
        Project root directory to monitor.
    excludes : list[str]
        Glob patterns for paths to exclude (from ``scan_exclude`` config).
    poll_interval : float
        Seconds between filesystem polls.
    debounce : float
        Seconds to wait after the last detected change before reporting.
    """

    def __init__(
        self,
        root: str | Path,
        excludes: list[str] | None = None,
        poll_interval: float = POLL_INTERVAL,
        debounce: float = DEBOUNCE_DELAY,
    ) -> None:
        self.root = Path(root).resolve()
        self.excludes = excludes or []
        self.poll_interval = poll_interval
        self.debounce = debounce
        # {relative_path: mtime} snapshot
        self._snapshot: dict[str, float] = {}

    def _scan_files(self) -> dict[str, float]:
        """Walk *self.root* and return ``{relpath: mtime}`` for source files."""
        result: dict[str, float] = {}
        for dirpath, dirnames, filenames in os.walk(self.root):
            # Prune hidden dirs and common non-source dirs early.
            dirnames[:] = [
                d for d in dirnames
                if not d.startswith(".") and d not in {"node_modules", "__pycache__", ".venv", "venv", ".git"}
            ]
            for fname in filenames:
                full = os.path.join(dirpath, fname)
                rel = os.path.relpath(full, self.root).replace("\\", "/")
                if not _is_source_file(rel):
                    continue
                if _matches_exclude(rel, self.excludes):
                    continue
                try:
                    result[rel] = os.path.getmtime(full)
                except OSError:
                    logger.debug("Could not stat file %s, skipping", rel)
        return result

    def take_snapshot(self) -> None:
        """Record the current filesystem state (used on startup)."""
        self._snapshot = self._scan_files()

    def detect_changes(self) -> list[str]:
        """Return list of changed/new files since the last snapshot.

        Also updates the internal snapshot so subsequent calls only return
        *new* changes.
        """
        current = self._scan_files()
        changed: list[str] = []
        for path, mtime in current.items():
            prev_mtime = self._snapshot.get(path)
            if prev_mtime is None or mtime > prev_mtime:
                changed.append(path)
        # Update snapshot to current state.
        self._snapshot = current
        return changed

    def poll_once(self) -> list[str]:
        """Single poll cycle: sleep, then detect changes."""
        time.sleep(self.poll_interval)
        return self.detect_changes()

    def wait_for_changes(self, stop_event: threading.Event) -> list[str]:
        """Block until file changes are detected (with debounce).

        Returns the list of changed files, or an empty list if *stop_event*
        is set before any changes occur.
        """
        while not stop_event.is_set():
            changes = self.poll_once()
            if changes:
                # Debounce: keep polling briefly to batch rapid saves.
                last_change_time = time.monotonic()
                all_changes = list(changes)
                while time.monotonic() - last_change_time < self.debounce:
                    if stop_event.is_set():
                        return []
                    time.sleep(min(0.2, self.debounce))
                    more = self.detect_changes()
                    if more:
                        all_changes.extend(more)
                        last_change_time = time.monotonic()
                return all_changes
        return []


class IntervalScheduler:
    """Triggers a callback at fixed intervals.

    Parameters
    ----------
    interval : float
        Seconds between triggers.
    """

    def __init__(self, interval: float) -> None:
        self.interval = interval
        self._last_trigger: float = 0.0

    def reset(self) -> None:
        """Reset the timer (e.g. after a manual trigger)."""
        self._last_trigger = time.monotonic()

    def is_due(self) -> bool:
        """Return True if enough time has elapsed since the last trigger."""
        if self.interval <= 0:
            return False
        return time.monotonic() - self._last_trigger >= self.interval

    def trigger(self) -> None:
        """Record that a trigger happened now."""
        self._last_trigger = time.monotonic()

    def seconds_until_next(self) -> float:
        """Seconds remaining until the next trigger (0 if already due)."""
        if self.interval <= 0:
            return float("inf")
        remaining = self.interval - (time.monotonic() - self._last_trigger)
        return max(0.0, remaining)


def _run_vuln_scan(
    config,
    quiet: bool = False,
    auto_fix: bool = False,
    create_pr: bool = False,
) -> tuple[int, int, list[str]]:
    """Run a vulnerability scan and optionally auto-fix.

    Returns ``(total_deps, vuln_count, new_cve_ids)``.
    """
    from guard.core.sbom import detect_manifests, parse_dependencies
    from guard.core.vuln_scanner import scan_dependencies, result_to_dict

    repo_root = "."
    try:
        from guard.core.repo_reader import find_repo_root
        repo_root = str(find_repo_root())
    except Exception as exc:
        logger.warning("Could not determine repo root for vuln scan: %s", exc)

    manifests = detect_manifests(repo_root)
    all_components = []
    for m in manifests:
        all_components.extend(parse_dependencies(m))

    if not all_components:
        return 0, 0, []

    result = scan_dependencies(all_components)
    cve_ids = [v.cve_id for v in result.vulnerabilities if v.cve_id]

    # Write results to output dir
    try:
        import json as _json
        out_dir = Path(config.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / "vulnerabilities.json"
        out_path.write_text(_json.dumps(result_to_dict(result), indent=2), encoding="utf-8")
    except OSError:
        pass

    # Auto-fix if requested
    if auto_fix and result.vulnerable_count > 0:
        try:
            from guard.core.vuln_fixer import FixAction, apply_fixes

            actions = []
            for v in result.vulnerabilities:
                if v.fixed_version:
                    actions.append(FixAction(
                        package=v.package,
                        current_version=v.installed_version,
                        fixed_version=v.fixed_version,
                        manifest_file=v.manifest_file if hasattr(v, "manifest_file") else "",
                    ))
            if actions:
                apply_fixes(actions)
                if not quiet:
                    print(f"  Auto-fixed {len(actions)} vulnerable package(s)")

                if create_pr:
                    try:
                        from guard.core.vuln_pr import create_fix_pr
                        create_fix_pr(config, actions)
                        if not quiet:
                            print("  Fix PR created")
                    except Exception as exc:
                        if not quiet:
                            print(f"  PR creation failed: {exc}")
        except ImportError:
            logger.warning("vuln_fixer module not available — auto-fix skipped. Install with: pip install sentrik[all]")

    return result.total_dependencies, result.vulnerable_count, cve_ids


def _run_scan(
    config,
    changed_files: list[str] | None = None,
    quiet: bool = False,
) -> tuple[bool, dict[str, int], int]:
    """Execute a scan and return ``(gate_passed, severity_counts, total)``.

    This is an internal helper that wraps the pipeline to avoid importing
    heavy modules at the top level.
    """
    from guard.core.pipeline import run_scan_and_write, build_autofix_map, build_replacement_map
    from guard.core.repo_reader import find_repo_root
    from guard.providers.factory import build_providers, _load_pack_rules

    repo_root = str(find_repo_root())
    devops, standards, scanner, rules_engine, _llm = build_providers(config)
    rules = standards.get_rules() + _load_pack_rules(
        config.standards_packs, license_key=config.license_key
    )
    autofix_map = build_autofix_map(rules)
    replacement_map = build_replacement_map(rules)

    findings, gate_result, _out = run_scan_and_write(
        repo_root,
        config,
        rules_engine,
        scanner,
        command="scan",
        changed_files=changed_files,
        autofix_map=autofix_map,
        replacement_map=replacement_map,
    )

    counts: dict[str, int] = {}
    for f in findings:
        sev = f.severity.value if hasattr(f.severity, "value") else str(f.severity)
        counts[sev] = counts.get(sev, 0) + 1

    return gate_result.passed, counts, len(findings)


def _print_scan_summary(
    passed: bool,
    counts: dict[str, int],
    total: int,
    quiet: bool = False,
) -> None:
    """Print a one-line scan result summary."""
    if quiet and passed:
        return

    parts: list[str] = []
    for sev in ("critical", "high", "medium", "low", "info"):
        n = counts.get(sev, 0)
        if n > 0:
            parts.append(f"{n} {sev}")

    detail = ", ".join(parts) if parts else "clean"

    if passed:
        print(f"\u2713 Gate passed ({total} findings: {detail})")
    else:
        print(f"\u2717 Gate failed ({detail})")


def run_watch_loop(
    config,
    interval: int = 0,
    quiet: bool = False,
    vulns: bool = False,
    vuln_interval: int = 3600,
    auto_fix: bool = False,
    create_pr: bool = False,
) -> None:
    """Main watch loop combining file watching and optional periodic scans.

    Parameters
    ----------
    config : GuardConfig
        Loaded configuration object.
    interval : int
        Seconds between periodic full scans (0 = file-watch only).
    quiet : bool
        Suppress output except gate failures.
    vulns : bool
        Enable periodic vulnerability scanning.
    vuln_interval : int
        Seconds between vulnerability scans (default: 3600 = 1 hour).
    auto_fix : bool
        Auto-patch vulnerable dependencies when vulns are found.
    create_pr : bool
        Create a PR with the fixes (requires auto_fix + DevOps provider).
    """
    stop_event = threading.Event()

    root = "."
    try:
        from guard.core.repo_reader import find_repo_root
        root = str(find_repo_root())
    except Exception as exc:
        logger.warning("Could not determine repo root for watch loop: %s", exc)

    watcher = FileWatcher(root, excludes=config.scan_exclude, poll_interval=POLL_INTERVAL)

    scheduler: IntervalScheduler | None = None
    if interval > 0:
        scheduler = IntervalScheduler(interval)

    vuln_scheduler: IntervalScheduler | None = None
    known_cves: set[str] = set()
    if vulns:
        vuln_scheduler = IntervalScheduler(vuln_interval)

    # --- Initial scan ---
    if not quiet:
        print("Running initial scan...")
    passed, counts, total = _run_scan(config, quiet=quiet)
    _print_scan_summary(passed, counts, total, quiet=quiet)

    # Initial vuln scan to establish baseline
    if vuln_scheduler:
        if not quiet:
            print("Running initial vulnerability scan...")
        total_deps, vuln_count, cve_ids = _run_vuln_scan(config, quiet=quiet)
        known_cves.update(cve_ids)
        if not quiet:
            print(f"  {total_deps} dependencies, {vuln_count} vulnerable ({len(cve_ids)} CVEs)")
        vuln_scheduler.reset()

    # Take snapshot *after* initial scan so we only detect new changes.
    watcher.take_snapshot()
    if scheduler:
        scheduler.reset()

    if not quiet:
        mode_parts: list[str] = []
        mode_parts.append("file-watch")
        if scheduler:
            mode_parts.append(f"interval={interval}s")
        if vuln_scheduler:
            mode_parts.append(f"vulns every {vuln_interval}s")
            if auto_fix:
                mode_parts.append("auto-fix")
            if create_pr:
                mode_parts.append("auto-pr")
        print(f"Watching for changes ({', '.join(mode_parts)})... Press Ctrl+C to stop")

    try:
        while not stop_event.is_set():
            # Check for file changes (short poll).
            changes = watcher.detect_changes()
            if changes:
                # Debounce: wait a bit for more rapid saves.
                last_change = time.monotonic()
                all_changes = list(changes)
                while time.monotonic() - last_change < watcher.debounce:
                    if stop_event.is_set():
                        return
                    time.sleep(min(0.2, watcher.debounce))
                    more = watcher.detect_changes()
                    if more:
                        all_changes.extend(more)
                        last_change = time.monotonic()

                # Deduplicate.
                unique_changes = list(dict.fromkeys(all_changes))
                if not quiet:
                    if len(unique_changes) <= 3:
                        print(f"Changed: {', '.join(unique_changes)}")
                    else:
                        print(f"Changed: {len(unique_changes)} file(s)")

                passed, counts, total = _run_scan(
                    config, changed_files=unique_changes, quiet=quiet,
                )
                _print_scan_summary(passed, counts, total, quiet=quiet)

                if scheduler:
                    scheduler.reset()
                continue

            # Check interval scheduler.
            if scheduler and scheduler.is_due():
                if not quiet:
                    print("Periodic scan triggered...")
                passed, counts, total = _run_scan(config, quiet=quiet)
                _print_scan_summary(passed, counts, total, quiet=quiet)
                scheduler.trigger()
                watcher.take_snapshot()

            # Check vuln scheduler.
            if vuln_scheduler and vuln_scheduler.is_due():
                if not quiet:
                    print("Periodic vulnerability scan...")
                total_deps, vuln_count, cve_ids = _run_vuln_scan(
                    config, quiet=quiet, auto_fix=auto_fix, create_pr=create_pr,
                )
                new_cves = set(cve_ids) - known_cves
                if new_cves:
                    print(f"  \u26a0 {len(new_cves)} NEW CVE(s) detected: {', '.join(sorted(new_cves))}")
                    known_cves.update(new_cves)
                    # Send notification for new CVEs
                    try:
                        from guard.core.notifications import notify_gate_failure
                        # Reuse gate failure notification with vuln context
                        from guard.core.models import GateResult
                        fake_gate = GateResult(
                            passed=False, total_findings=vuln_count,
                            critical=0, high=vuln_count, medium=0, low=0, info=0,
                        )
                        notify_gate_failure(config, fake_gate, [], context=f"New CVEs: {', '.join(sorted(new_cves))}")
                    except Exception as exc:
                        logger.warning("Failed to send CVE notification: %s", exc)
                elif not quiet:
                    print(f"  No new CVEs ({vuln_count} known)")
                vuln_scheduler.trigger()

            # Short sleep to avoid busy-wait.
            time.sleep(watcher.poll_interval)

    except KeyboardInterrupt:
        pass
    finally:
        stop_event.set()
        if not quiet:
            print("\nWatch stopped.")
