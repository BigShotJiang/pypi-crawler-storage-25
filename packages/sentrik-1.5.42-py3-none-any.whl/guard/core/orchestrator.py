"""Agent orchestrator — dispatches compliance agents in parallel."""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from guard.core.agent import AgentResult, ComplianceAgent
from guard.core.cache import ScanCache

logger = logging.getLogger(__name__)


class AgentOrchestrator:
    """Dispatch :class:`ComplianceAgent` instances in parallel and merge results.

    Drop-in replacement for ``RulesEngine`` in the scan pipeline when
    ``agent_scan`` is enabled.  Exposes the same ``files_scanned`` attribute
    so that ``pipeline.run_scan()`` can read it without branching.
    """

    def __init__(
        self,
        agents: list[ComplianceAgent],
        max_concurrency: int = 0,
    ) -> None:
        self._agents = agents
        self._max_concurrency = max_concurrency or len(agents) or 1
        self.agent_results: list[AgentResult] = []
        self.files_scanned: int = 0
        # Expose for pipeline compatibility (MetricsCollector reads this)
        self._max_workers = self._max_concurrency

    @property
    def agents(self) -> list[ComplianceAgent]:
        return list(self._agents)

    @property
    def _rules(self) -> list[Any]:
        """Combined rules from all agents (for pipeline compatibility)."""
        rules: list[Any] = []
        for agent in self._agents:
            rules.extend(agent._rules)
        return rules

    def evaluate(
        self,
        repo_root: str,
        changed_files: list[str] | None = None,
        cache: ScanCache | None = None,
        scan_exclude: list[str] | None = None,
        project_languages: list[str] | None = None,
    ) -> list[Any]:
        """Run all agents in parallel and return merged findings.

        This method signature matches ``RulesEngine.evaluate()`` so that
        the orchestrator can be used as a drop-in replacement.
        """
        self.agent_results = []

        if len(self._agents) == 0:
            return []

        # Single agent — skip thread overhead
        if len(self._agents) == 1:
            result = self._agents[0].evaluate(
                repo_root, changed_files, cache,
                scan_exclude, project_languages,
            )
            self.agent_results.append(result)
            self.files_scanned = result.files_scanned
            if result.error:
                logger.warning("Agent %s failed: %s", result.pack_id, result.error)
            return list(result.findings)

        with ThreadPoolExecutor(max_workers=self._max_concurrency) as pool:
            futures = {
                pool.submit(
                    agent.evaluate,
                    repo_root, changed_files, cache,
                    scan_exclude, project_languages,
                ): agent
                for agent in self._agents
            }
            for future in as_completed(futures):
                result = future.result()
                self.agent_results.append(result)
                if result.error:
                    logger.warning(
                        "Agent %s failed: %s", result.pack_id, result.error,
                    )

        self.files_scanned = max(
            (r.files_scanned for r in self.agent_results), default=0,
        )
        return self._merge_findings()

    def _merge_findings(self) -> list[Any]:
        """Merge findings from all agents, deduplicating by finding_id."""
        seen: set[str] = set()
        merged: list[Any] = []
        for result in self.agent_results:
            for finding in result.findings:
                fid = getattr(finding, "finding_id", None) or id(finding)
                if fid not in seen:
                    seen.add(fid)
                    merged.append(finding)
        return merged
