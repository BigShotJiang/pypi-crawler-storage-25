"""Signed compliance attestation — cryptographic proof of scan results."""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import platform
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _get_signing_key() -> bytes:
    """Return the attestation signing key.

    Resolution order:
    1. ``GUARD_ATTESTATION_KEY`` env var
    2. ``GUARD_AUDIT_HMAC_KEY`` env var (reuse audit key)
    3. Auto-generated key stored in ``.sentrik/local/attestation_key``
    """
    env_key = os.environ.get("GUARD_ATTESTATION_KEY") or os.environ.get("GUARD_AUDIT_HMAC_KEY")
    if env_key:
        return env_key.encode("utf-8")

    key_path = Path(".sentrik") / "local" / "attestation_key"
    if key_path.is_file():
        return key_path.read_bytes()

    key_path.parent.mkdir(parents=True, exist_ok=True)
    key = os.urandom(32)
    key_path.write_bytes(key)
    return key


def _get_git_sha() -> str | None:
    """Return the current HEAD commit SHA, or None if not in a git repo."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True, text=True, timeout=5,
        )
        return result.stdout.strip() if result.returncode == 0 else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def generate_attestation(
    findings_path: Path,
    metrics_path: Path,
    config_summary: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Generate a signed attestation from scan results.

    Returns a JSON-serializable dict with:
    - ``attestation``: scan summary, environment, and compliance status
    - ``signature``: HMAC-SHA256 of the attestation payload
    - ``algorithm``: signing algorithm identifier
    """
    # Load findings
    findings: list[dict] = []
    if findings_path.is_file():
        findings = json.loads(findings_path.read_text(encoding="utf-8"))

    # Load metrics
    metrics: dict[str, Any] = {}
    if metrics_path.is_file():
        metrics = json.loads(metrics_path.read_text(encoding="utf-8"))

    # Compute findings digest
    findings_bytes = json.dumps(findings, sort_keys=True).encode("utf-8")
    findings_sha256 = hashlib.sha256(findings_bytes).hexdigest()

    # Severity counts
    severity_counts: dict[str, int] = {}
    for f in findings:
        sev = f.get("severity", "unknown")
        severity_counts[sev] = severity_counts.get(sev, 0) + 1

    # Gate status
    gate_fail_on = (config_summary or {}).get("gate_fail_on", ["critical", "high"])
    blocking = sum(severity_counts.get(s, 0) for s in gate_fail_on)
    gate_passed = blocking == 0

    attestation = {
        "version": "1.0",
        "type": "sentrik.compliance.attestation",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "scan": {
            "total_findings": len(findings),
            "findings_sha256": findings_sha256,
            "severity_counts": severity_counts,
            "gate_passed": gate_passed,
            "gate_fail_on": gate_fail_on,
            "files_scanned": metrics.get("files_scanned", 0),
            "rules_evaluated": len(metrics.get("findings_by_rule", {})),
            "duration_ms": metrics.get("total_duration_ms", 0),
            "packs_enabled": (config_summary or {}).get("standards_packs", []),
        },
        "environment": {
            "tool": "sentrik",
            "tool_version": _get_tool_version(),
            "python_version": platform.python_version(),
            "platform": platform.platform(),
            "git_sha": _get_git_sha(),
        },
        "design_review": _get_design_review_status(
            Path(metrics_path).parent if metrics_path else Path("out"),
        ),
    }

    # Sign
    payload = json.dumps(attestation, sort_keys=True)
    key = _get_signing_key()
    signature = hmac.new(key, payload.encode("utf-8"), hashlib.sha256).hexdigest()

    return {
        "attestation": attestation,
        "signature": signature,
        "algorithm": "hmac-sha256",
    }


def verify_attestation(doc: dict[str, Any]) -> bool:
    """Verify the signature of an attestation document.

    Returns True if the signature matches, False otherwise.
    """
    attestation = doc.get("attestation")
    signature = doc.get("signature")
    algorithm = doc.get("algorithm")

    if not attestation or not signature or algorithm != "hmac-sha256":
        return False

    payload = json.dumps(attestation, sort_keys=True)
    key = _get_signing_key()
    expected = hmac.new(key, payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)


def _get_design_review_status(output_dir: Path) -> dict[str, Any]:
    """Get design decision acknowledgment status for the attestation."""
    decisions_path = output_dir / "design_decisions.json"
    if not decisions_path.is_file():
        return {"total": 0, "acknowledged": 0, "pending": 0, "all_acknowledged": True}

    try:
        decisions = json.loads(decisions_path.read_text(encoding="utf-8"))
        total = len(decisions)
        acked = sum(1 for d in decisions if d.get("acknowledged"))
        return {
            "total": total,
            "acknowledged": acked,
            "pending": total - acked,
            "all_acknowledged": acked == total,
        }
    except (json.JSONDecodeError, OSError):
        return {"total": 0, "acknowledged": 0, "pending": 0, "all_acknowledged": True}


def _get_tool_version() -> str:
    try:
        from guard import __version__
        return __version__
    except (ImportError, AttributeError):
        return "unknown"
