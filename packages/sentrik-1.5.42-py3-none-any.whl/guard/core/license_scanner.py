"""Dependency license scanner.

Detects license types on project dependencies and flags copyleft risk.
Queries PyPI and npm registries for license metadata.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

import requests

from guard.core.sbom import Component

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# License classification data
# ---------------------------------------------------------------------------

# Permissive licenses — no risk
_PERMISSIVE: set[str] = {
    "MIT",
    "Apache-2.0",
    "BSD-2-Clause",
    "BSD-3-Clause",
    "ISC",
    "Unlicense",
    "0BSD",
    "CC0-1.0",
}

# Strong copyleft — high risk
_STRONG_COPYLEFT: set[str] = {
    "GPL-2.0",
    "GPL-2.0-only",
    "GPL-2.0-or-later",
    "GPL-3.0",
    "GPL-3.0-only",
    "GPL-3.0-or-later",
    "AGPL-3.0",
    "AGPL-3.0-only",
    "AGPL-3.0-or-later",
    "SSPL-1.0",
    "EUPL-1.1",
    "EUPL-1.2",
    "CPAL-1.0",
}

# Weak copyleft — medium risk
_WEAK_COPYLEFT: set[str] = {
    "MPL-2.0",
    "LGPL-2.1",
    "LGPL-2.1-only",
    "LGPL-2.1-or-later",
    "LGPL-3.0",
    "LGPL-3.0-only",
    "LGPL-3.0-or-later",
}

# Mapping of common non-SPDX license strings to normalized SPDX identifiers
_LICENSE_ALIASES: dict[str, str] = {
    "mit": "MIT",
    "mit license": "MIT",
    "the mit license": "MIT",
    "apache 2.0": "Apache-2.0",
    "apache license 2.0": "Apache-2.0",
    "apache license, version 2.0": "Apache-2.0",
    "apache-2": "Apache-2.0",
    "apache software license": "Apache-2.0",
    "bsd": "BSD-3-Clause",
    "bsd license": "BSD-3-Clause",
    "bsd-2-clause": "BSD-2-Clause",
    "bsd-3-clause": "BSD-3-Clause",
    "isc": "ISC",
    "isc license": "ISC",
    "gpl-2.0": "GPL-2.0",
    "gpl-3.0": "GPL-3.0",
    "gplv2": "GPL-2.0",
    "gplv3": "GPL-3.0",
    "gnu general public license v2": "GPL-2.0",
    "gnu general public license v3": "GPL-3.0",
    "gnu gpl v3": "GPL-3.0",
    "agpl-3.0": "AGPL-3.0",
    "lgpl-2.1": "LGPL-2.1",
    "lgpl-3.0": "LGPL-3.0",
    "lgplv2.1": "LGPL-2.1",
    "lgplv3": "LGPL-3.0",
    "mpl-2.0": "MPL-2.0",
    "mozilla public license 2.0": "MPL-2.0",
    "unlicense": "Unlicense",
    "the unlicense": "Unlicense",
    "cc0-1.0": "CC0-1.0",
    "public domain": "Unlicense",
    "0bsd": "0BSD",
}


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class LicenseInfo:
    """License information for a single package."""

    package: str
    version: str
    ecosystem: str
    license: str  # e.g. "MIT", "GPL-3.0", "unknown"
    risk: str  # "none", "low", "medium", "high"
    copyleft: bool


@dataclass
class LicenseScanResult:
    """Aggregated result of scanning dependencies for license information."""

    total_packages: int
    scanned: int
    by_risk: dict[str, int] = field(default_factory=dict)
    licenses: list[LicenseInfo] = field(default_factory=list)
    copyleft_count: int = 0


# ---------------------------------------------------------------------------
# License classification
# ---------------------------------------------------------------------------


def _normalize_license(raw: str) -> str:
    """Normalize a raw license string to an SPDX-like identifier."""
    if not raw or not raw.strip():
        return "unknown"

    stripped = raw.strip()

    # Already a known SPDX id?
    if stripped in _PERMISSIVE or stripped in _STRONG_COPYLEFT or stripped in _WEAK_COPYLEFT:
        return stripped

    # Check aliases (case-insensitive)
    alias = _LICENSE_ALIASES.get(stripped.lower())
    if alias:
        return alias

    return stripped


def _classify_license(license_str: str) -> tuple[str, str, bool]:
    """Classify a license string.

    Returns:
        (normalized_name, risk, copyleft) where risk is one of
        "none", "low", "medium", "high".
    """
    normalized = _normalize_license(license_str)

    if normalized == "unknown":
        return ("unknown", "low", False)

    if normalized in _PERMISSIVE:
        return (normalized, "none", False)

    if normalized in _STRONG_COPYLEFT:
        return (normalized, "high", True)

    if normalized in _WEAK_COPYLEFT:
        return (normalized, "medium", True)

    # Fallback — unknown license text
    return (normalized, "low", False)


# ---------------------------------------------------------------------------
# Registry queries
# ---------------------------------------------------------------------------

# Simple in-memory cache: (ecosystem, name, version) -> raw license string
_license_cache: dict[tuple[str, str, str], str] = {}


def _fetch_pypi_license(name: str, version: str) -> str:
    """Query PyPI for a package's license."""
    cache_key = ("pypi", name, version)
    if cache_key in _license_cache:
        return _license_cache[cache_key]

    url = f"https://pypi.org/pypi/{name}/{version}/json"
    try:
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        info = data.get("info", {})

        # Try the license field first
        lic = (info.get("license") or "").strip()
        if lic and lic.upper() != "UNKNOWN":
            _license_cache[cache_key] = lic
            return lic

        # Fall back to classifiers
        for classifier in info.get("classifiers", []):
            if classifier.startswith("License :: OSI Approved :: "):
                parts = classifier.split(" :: ")
                lic = parts[-1].strip()
                _license_cache[cache_key] = lic
                return lic

        _license_cache[cache_key] = "unknown"
        return "unknown"
    except Exception:
        logger.debug("Failed to fetch license for PyPI package %s==%s", name, version)
        _license_cache[cache_key] = "unknown"
        return "unknown"


def _fetch_npm_license(name: str, version: str) -> str:
    """Query npm registry for a package's license."""
    cache_key = ("npm", name, version)
    if cache_key in _license_cache:
        return _license_cache[cache_key]

    url = f"https://registry.npmjs.org/{name}/{version}"
    try:
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        data = resp.json()

        # npm license can be a string or an object {"type": "MIT", "url": "..."}
        lic = data.get("license", "")
        if isinstance(lic, dict):
            lic = lic.get("type", "")
        lic = (lic or "").strip()

        if not lic:
            _license_cache[cache_key] = "unknown"
            return "unknown"

        _license_cache[cache_key] = lic
        return lic
    except Exception:
        logger.debug("Failed to fetch license for npm package %s@%s", name, version)
        _license_cache[cache_key] = "unknown"
        return "unknown"


# ---------------------------------------------------------------------------
# Main scan function
# ---------------------------------------------------------------------------


def scan_licenses(components: list[Component]) -> LicenseScanResult:
    """Scan a list of dependency components for license information.

    Queries PyPI for pypi packages, npm registry for npm packages.
    Other ecosystems are marked as unknown.

    Args:
        components: List of Component objects from SBOM parsing.

    Returns:
        LicenseScanResult with license details for each component.
    """
    if not components:
        return LicenseScanResult(total_packages=0, scanned=0)

    licenses: list[LicenseInfo] = []
    by_risk: dict[str, int] = {"none": 0, "low": 0, "medium": 0, "high": 0}
    copyleft_count = 0
    scanned = 0

    for comp in components:
        # Fetch raw license string
        if comp.ecosystem == "pypi":
            raw_license = _fetch_pypi_license(comp.name, comp.version)
            scanned += 1
        elif comp.ecosystem == "npm":
            raw_license = _fetch_npm_license(comp.name, comp.version)
            scanned += 1
        else:
            raw_license = "unknown"
            scanned += 1

        normalized, risk, copyleft = _classify_license(raw_license)

        info = LicenseInfo(
            package=comp.name,
            version=comp.version,
            ecosystem=comp.ecosystem,
            license=normalized,
            risk=risk,
            copyleft=copyleft,
        )
        licenses.append(info)
        by_risk[risk] = by_risk.get(risk, 0) + 1
        if copyleft:
            copyleft_count += 1

    return LicenseScanResult(
        total_packages=len(components),
        scanned=scanned,
        by_risk=by_risk,
        licenses=licenses,
        copyleft_count=copyleft_count,
    )


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------


def result_to_dict(result: LicenseScanResult) -> dict[str, Any]:
    """Convert a LicenseScanResult to a JSON-serializable dictionary."""
    return {
        "total_packages": result.total_packages,
        "scanned": result.scanned,
        "by_risk": result.by_risk,
        "copyleft_count": result.copyleft_count,
        "licenses": [
            {
                "package": li.package,
                "version": li.version,
                "ecosystem": li.ecosystem,
                "license": li.license,
                "risk": li.risk,
                "copyleft": li.copyleft,
            }
            for li in result.licenses
        ],
    }
