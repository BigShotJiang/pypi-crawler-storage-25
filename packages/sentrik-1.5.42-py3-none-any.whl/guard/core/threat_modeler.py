"""STRIDE-based Threat Modeling — LLM-powered threat analysis of code changes.

Uses LLM analysis to perform STRIDE threat modeling on code changes,
identifying potential security threats and recommending mitigations.
"""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from guard.core.design_reviewer import get_diff  # noqa: F401 — re-exported for CLI
from guard.core.project_profile import load_profile
from guard.providers.llm_base import LLMProvider

logger = logging.getLogger(__name__)

_STRIDE_CATEGORIES = [
    "spoofing",
    "tampering",
    "repudiation",
    "information_disclosure",
    "denial_of_service",
    "elevation_of_privilege",
]

_THREAT_MODEL_PROMPT = """\
You are a senior security architect performing STRIDE threat modeling on code changes. \
Analyze the code and identify potential security threats across all six STRIDE categories:

- **Spoofing**: Can an attacker pretend to be someone/something else?
- **Tampering**: Can an attacker modify data they shouldn't?
- **Repudiation**: Can an attacker deny performing an action?
- **Information Disclosure**: Can an attacker access data they shouldn't see?
- **Denial of Service**: Can an attacker disrupt service availability?
- **Elevation of Privilege**: Can an attacker gain unauthorized access or permissions?

Focus on realistic, actionable threats — not theoretical edge cases.

PROJECT CONTEXT:
{project_context}

CODE CHANGES:
{code_changes}

Return ONLY valid JSON:
{{
  "threats": [
    {{
      "category": "spoofing|tampering|repudiation|information_disclosure|denial_of_service|elevation_of_privilege",
      "component": "path/to/file.py or component name",
      "description": "What the threat is",
      "attack_vector": "How an attacker would exploit this",
      "impact": "What happens if exploited",
      "likelihood": "high|medium|low",
      "severity": "critical|high|medium|low",
      "mitigation": "Recommended fix or control"
    }}
  ]
}}

If no significant threats are found, return {{"threats": []}}.
"""


@dataclass
class Threat:
    threat_id: str
    category: str
    component: str
    description: str
    attack_vector: str = ""
    impact: str = ""
    likelihood: str = "medium"
    severity: str = "medium"
    mitigation: str = ""
    mitigated: bool = False
    mitigation_note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "threat_id": self.threat_id,
            "category": self.category,
            "component": self.component,
            "description": self.description,
            "attack_vector": self.attack_vector,
            "impact": self.impact,
            "likelihood": self.likelihood,
            "severity": self.severity,
            "mitigation": self.mitigation,
            "mitigated": self.mitigated,
            "mitigation_note": self.mitigation_note,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Threat:
        return cls(
            threat_id=data.get("threat_id", f"TM-{uuid.uuid4().hex[:6].upper()}"),
            category=data.get("category", "tampering"),
            component=data.get("component", ""),
            description=data.get("description", "Threat detected"),
            attack_vector=data.get("attack_vector", ""),
            impact=data.get("impact", ""),
            likelihood=data.get("likelihood", "medium"),
            severity=data.get("severity", "medium"),
            mitigation=data.get("mitigation", ""),
            mitigated=data.get("mitigated", False),
            mitigation_note=data.get("mitigation_note", ""),
        )


def generate_threat_model(
    llm: LLMProvider,
    code_changes: str,
    output_dir: str = "out",
    repo_root: str = ".",
) -> list[Threat]:
    """Analyze code changes for security threats using STRIDE and LLM."""
    if not code_changes.strip():
        return []

    # Build project context
    profile = load_profile(output_dir)
    if profile:
        ctx_parts = []
        if profile.get("frameworks"):
            ctx_parts.append(f"Frameworks: {', '.join(f['name'] for f in profile['frameworks'])}")
        if profile.get("architecture"):
            ctx_parts.append(f"Patterns: {', '.join(p['pattern'] for p in profile['architecture'])}")
        if profile.get("conventions"):
            ctx_parts.append(f"Conventions: {json.dumps(profile['conventions'])}")
        project_context = "\n".join(ctx_parts) or "No project profile available."
    else:
        project_context = "No project profile available. Run 'sentrik profile' to build one."

    prompt = _THREAT_MODEL_PROMPT.format(
        project_context=project_context,
        code_changes=code_changes,
    )

    try:
        response = llm.analyze(prompt, {"type": "threat_model"})
        return _parse_response(response)
    except Exception as exc:
        logger.warning("Threat modeling failed: %s", exc)
        return []


def _parse_response(response: dict[str, Any]) -> list[Threat]:
    """Parse LLM response into Threat objects."""
    data = response
    if "summary" in response and isinstance(response["summary"], str):
        try:
            data = json.loads(response["summary"])
        except (json.JSONDecodeError, TypeError):
            pass

    threats_raw = data.get("threats", [])
    threats = []

    for t in threats_raw:
        if not isinstance(t, dict):
            continue
        category = t.get("category", "tampering")
        if category not in _STRIDE_CATEGORIES:
            category = "tampering"

        likelihood = t.get("likelihood", "medium")
        if likelihood not in ("high", "medium", "low"):
            likelihood = "medium"

        severity = t.get("severity", "medium")
        if severity not in ("critical", "high", "medium", "low"):
            severity = "medium"

        threats.append(Threat(
            threat_id=f"TM-{uuid.uuid4().hex[:6].upper()}",
            category=category,
            component=t.get("component", ""),
            description=t.get("description", "Threat detected"),
            attack_vector=t.get("attack_vector", ""),
            impact=t.get("impact", ""),
            likelihood=likelihood,
            severity=severity,
            mitigation=t.get("mitigation", ""),
        ))

    return threats


def format_threats(threats: list[Threat]) -> str:
    """Format threats as human-readable text."""
    if not threats:
        return "\nNo security threats detected.\n"

    lines = [f"\n{len(threats)} threat(s) identified:\n"]

    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    sorted_threats = sorted(threats, key=lambda t: severity_order.get(t.severity, 2))

    for i, t in enumerate(sorted_threats, 1):
        status = "[MITIGATED]" if t.mitigated else ""
        lines.append(f"  {i}. [{t.severity.upper()}] [{t.category.upper()}] {t.description} {status}".rstrip())
        if t.component:
            lines.append(f"     Component: {t.component}")
        if t.attack_vector:
            lines.append(f"     Attack: {t.attack_vector}")
        if t.impact:
            lines.append(f"     Impact: {t.impact}")
        lines.append(f"     Likelihood: {t.likelihood}")
        if t.mitigation:
            lines.append(f"     Mitigation: {t.mitigation}")
        if t.mitigated and t.mitigation_note:
            lines.append(f"     Note: {t.mitigation_note}")
        lines.append("")

    return "\n".join(lines)


def save_threats(threats: list[Threat], output_dir: str = "out") -> Path:
    """Save threats to out/threat_model.json."""
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / "threat_model.json"
    data = [t.to_dict() for t in threats]
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return path


def load_threats(output_dir: str = "out") -> list[Threat]:
    """Load threats from out/threat_model.json."""
    path = Path(output_dir) / "threat_model.json"
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return [Threat.from_dict(d) for d in data]
    except (json.JSONDecodeError, OSError, TypeError):
        return []


def mitigate_threat(
    threat_id: str,
    note: str = "",
    output_dir: str = "out",
) -> bool:
    """Mark a threat as mitigated."""
    threats = load_threats(output_dir)
    for t in threats:
        if t.threat_id == threat_id:
            t.mitigated = True
            t.mitigation_note = note
            save_threats(threats, output_dir)
            return True
    return False
