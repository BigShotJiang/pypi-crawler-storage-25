"""Dependency vulnerability scanner using the OSV.dev API.

Checks project dependencies against the OSV.dev database for known CVEs
and reports known CVEs with severity, fix versions, and advisory links.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import requests

from guard.core.sbom import Component

logger = logging.getLogger(__name__)

# Maximum components per OSV batch request
_BATCH_SIZE = 100

# Map internal ecosystem names to OSV ecosystem identifiers
ECOSYSTEM_MAP: dict[str, str] = {
    "pypi": "PyPI",
    "npm": "npm",
    "cargo": "crates.io",
    "golang": "Go",
    "go": "Go",
    "maven": "Maven",
    "gem": "RubyGems",
    "composer": "Packagist",
}

# CMake packages often map to well-known OSV ecosystems
# (OSV.dev has no "cmake" ecosystem — C/C++ libs are tracked differently)
_CMAKE_PACKAGE_MAP: dict[str, tuple[str, str]] = {
    "openssl": ("OSS-Fuzz", "openssl"),
    "curl": ("OSS-Fuzz", "curl"),
    "boost": ("OSS-Fuzz", "boost"),
    "zlib": ("OSS-Fuzz", "zlib"),
    "libpng": ("OSS-Fuzz", "libpng"),
    "sqlite3": ("OSS-Fuzz", "sqlite3"),
    "protobuf": ("OSS-Fuzz", "protobuf"),
    "grpc": ("OSS-Fuzz", "grpc"),
    "abseil-cpp": ("OSS-Fuzz", "abseil-cpp"),
}

# ---------------------------------------------------------------------------
# CISA Known Exploited Vulnerabilities (KEV) — AI-related CVE patterns
#
# This is a lightweight, offline set of CVE IDs from the CISA KEV catalog
# that affect AI/ML tooling and common dependencies used in AI pipelines.
# Updated periodically; for real-time data, query https://www.cisa.gov/known-exploited-vulnerabilities-catalog
# ---------------------------------------------------------------------------
_CISA_KEV_AI_CVES: set[str] = {
    # PyTorch / Triton / model serving
    "CVE-2022-45907",  # PyTorch — arbitrary code execution via TorchScript
    "CVE-2024-5480",   # PyTorch Serve — SSRF / remote code execution
    # Jupyter / data science infra
    "CVE-2024-35178",  # Jupyter Server — authentication bypass
    "CVE-2023-44467",  # Jupyter — command injection via cell magic
    # TensorFlow
    "CVE-2023-25801",  # TensorFlow — heap OOB read
    "CVE-2022-29216",  # TensorFlow — code injection via saved models
    # LangChain / AI agent frameworks
    "CVE-2023-36188",  # LangChain — arbitrary code execution via DBRX
    "CVE-2023-44467",  # LangChain PALChain — code injection
    "CVE-2023-36095",  # LangChain — SSRF via arbitrary URL loading
    "CVE-2023-39631",  # LangChain — RCE via LLMMathChain
    # Hugging Face / Transformers
    "CVE-2023-43261",  # Hugging Face Transformers — deserialization RCE
    "CVE-2024-3568",   # Hugging Face Hub — arbitrary file overwrite
    # MLflow
    "CVE-2023-6977",   # MLflow — path traversal → arbitrary file read
    "CVE-2024-0520",   # MLflow — arbitrary file upload → RCE
    "CVE-2023-6753",   # MLflow — SSRF via model registry
    # Ray (distributed AI compute)
    "CVE-2023-48023",  # Ray — unauthenticated RCE (actively exploited)
    "CVE-2023-6019",   # Ray — command injection
    # Common infra deps used in AI stacks
    "CVE-2024-3094",   # xz-utils — backdoor (supply chain, affects AI build infra)
    "CVE-2023-44487",  # HTTP/2 Rapid Reset (gRPC / model serving)
    "CVE-2024-21626",  # runc — container escape (AI container workloads)
    "CVE-2023-38545",  # curl — heap buffer overflow (model downloads)
    "CVE-2023-5528",   # Kubernetes — privilege escalation (AI orchestration)
}


def _is_cisa_kev(cve_id: str) -> bool:
    """Check whether a CVE ID appears in the CISA KEV AI-related set."""
    return cve_id.upper() in {c.upper() for c in _CISA_KEV_AI_CVES}



@dataclass
class Vulnerability:
    """A single known vulnerability affecting a dependency."""

    id: str  # CVE or GHSA identifier
    summary: str
    severity: str  # critical, high, medium, low
    affected_package: str
    affected_version: str
    fixed_version: str | None = None
    references: list[str] = field(default_factory=list)
    kev_tagged: bool = False  # True if CVE matches CISA KEV catalog


@dataclass
class VulnScanResult:
    """Result of scanning dependencies for known vulnerabilities."""

    total_dependencies: int
    vulnerable_count: int
    vulnerabilities: list[Vulnerability]
    scan_timestamp: str
    by_severity: dict[str, int] = field(default_factory=dict)
    kev_count: int = 0  # Number of vulnerabilities matching CISA KEV catalog


def scan_dependencies(components: list[Component]) -> VulnScanResult:
    """Scan a list of dependency components for known vulnerabilities.

    Args:
        components: List of Component objects from SBOM parsing.

    Returns:
        VulnScanResult with all discovered vulnerabilities.
    """
    timestamp = datetime.now(timezone.utc).isoformat()

    if not components:
        return VulnScanResult(
            total_dependencies=0,
            vulnerable_count=0,
            vulnerabilities=[],
            scan_timestamp=timestamp,
            by_severity={"critical": 0, "high": 0, "medium": 0, "low": 0},
        )

    raw_results = _query_osv_batch(components)
    vulnerabilities: list[Vulnerability] = []
    vulnerable_packages: set[str] = set()

    # Collect vuln IDs that need full details
    vuln_ids_to_fetch: set[str] = set()
    comp_vuln_pairs: list[tuple[Component, dict]] = []
    for comp, vulns in zip(components, raw_results):
        if not vulns:
            continue
        for vuln_data in vulns:
            vuln_id = vuln_data.get("id", "")
            comp_vuln_pairs.append((comp, vuln_data))
            # If the batch response is missing key fields, fetch full details
            if vuln_id and not vuln_data.get("summary") and not vuln_data.get("severity"):
                vuln_ids_to_fetch.add(vuln_id)

    # Fetch full details for vulns that only returned IDs
    full_details = _fetch_vuln_details(vuln_ids_to_fetch) if vuln_ids_to_fetch else {}

    for comp, vuln_data in comp_vuln_pairs:
        vuln_id = vuln_data.get("id", "")
        # Merge full details if we fetched them
        if vuln_id in full_details:
            vuln_data = full_details[vuln_id]
        vuln = _parse_vuln(vuln_data, comp)
        # Tag CISA KEV matches
        if _is_cisa_kev(vuln.id):
            vuln.kev_tagged = True
        vulnerabilities.append(vuln)
        vulnerable_packages.add(f"{comp.ecosystem}/{comp.name}")

    by_severity: dict[str, int] = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    kev_count = 0
    for v in vulnerabilities:
        by_severity[v.severity] = by_severity.get(v.severity, 0) + 1
        if v.kev_tagged:
            kev_count += 1

    if kev_count > 0:
        logger.warning(
            "CISA KEV: %d vulnerabilit%s match the CISA Known Exploited Vulnerabilities catalog",
            kev_count,
            "y matches" if kev_count == 1 else "ies match",
        )

    return VulnScanResult(
        total_dependencies=len(components),
        vulnerable_count=len(vulnerable_packages),
        vulnerabilities=vulnerabilities,
        scan_timestamp=timestamp,
        by_severity=by_severity,
        kev_count=kev_count,
    )


def _query_osv_batch(components: list[Component]) -> list[list[dict[str, Any]]]:
    """Query the OSV.dev batch API for vulnerabilities.

    Splits into batches of _BATCH_SIZE and returns a list of vuln lists,
    one per input component (empty list if no vulns found).
    """
    all_results: list[list[dict[str, Any]]] = []

    for i in range(0, len(components), _BATCH_SIZE):
        batch = components[i : i + _BATCH_SIZE]
        queries = []
        for comp in batch:
            eco_lower = comp.ecosystem.lower()
            if eco_lower == "cmake":
                # CMake packages: try to map to a known OSV ecosystem
                mapped = _CMAKE_PACKAGE_MAP.get(comp.name.lower())
                if mapped:
                    ecosystem, pkg_name = mapped
                else:
                    # Skip unknown cmake packages — OSV has no cmake ecosystem
                    queries.append({"package": {"name": comp.name, "ecosystem": "GIT"}})
                    continue
                query: dict[str, Any] = {
                    "package": {"name": pkg_name, "ecosystem": ecosystem},
                }
            else:
                ecosystem = ECOSYSTEM_MAP.get(eco_lower, comp.ecosystem)
                query = {
                    "package": {"name": comp.name, "ecosystem": ecosystem},
                }
            if comp.version and comp.version != "0.0.0":
                query["version"] = comp.version
            queries.append(query)

        try:
            resp = requests.post(
                "https://api.osv.dev/v1/querybatch",
                json={"queries": queries},
                timeout=30,
            )
            resp.raise_for_status()
            data = resp.json()
            results = data.get("results", [])
            for result in results:
                all_results.append(result.get("vulns", []))
            # Pad if response is shorter than batch (shouldn't happen but be safe)
            while len(all_results) < i + len(batch):
                all_results.append([])
        except Exception:
            logger.warning("OSV.dev API request failed; skipping batch %d-%d", i, i + len(batch))
            all_results.extend([] for _ in batch)

    return all_results


def _fetch_vuln_details(vuln_ids: set[str]) -> dict[str, dict[str, Any]]:
    """Fetch full vulnerability details from OSV.dev for a set of vuln IDs.

    The batch API returns minimal data (just IDs). This fetches the full
    record including summary, severity, affected ranges, and references.
    """
    details: dict[str, dict[str, Any]] = {}
    for vuln_id in vuln_ids:
        try:
            resp = requests.get(
                f"https://api.osv.dev/v1/vulns/{vuln_id}",
                timeout=15,
            )
            if resp.status_code == 200:
                details[vuln_id] = resp.json()
        except Exception:
            logger.debug("Failed to fetch details for %s", vuln_id)
    return details


def _parse_vuln(vuln_data: dict[str, Any], comp: Component) -> Vulnerability:
    """Parse a single OSV vulnerability entry into our Vulnerability model."""
    vuln_id = vuln_data.get("id", "UNKNOWN")
    summary = vuln_data.get("summary", vuln_data.get("details", "No description available"))

    # Try database_specific.severity first (most reliable — e.g., "HIGH")
    db_specific = vuln_data.get("database_specific", {}) or {}
    db_severity = db_specific.get("severity", "")
    if isinstance(db_severity, str) and db_severity.lower() in ("critical", "high", "medium", "low"):
        severity = db_severity.lower()
    else:
        severity = _map_severity(vuln_data.get("severity", []))

    fixed_version = _extract_fixed_version(vuln_data)

    references: list[str] = []
    for ref in vuln_data.get("references", []):
        url = ref.get("url", "")
        if url:
            references.append(url)

    return Vulnerability(
        id=vuln_id,
        summary=summary if summary else "No description available",
        severity=severity,
        affected_package=comp.name,
        affected_version=comp.version,
        fixed_version=fixed_version,
        references=references,
    )


def _map_severity(osv_severity: list[dict[str, Any]]) -> str:
    """Convert OSV severity data to our severity levels.

    OSV severity entries look like:
        [{"type": "CVSS_V3", "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}]

    We extract the base score from the CVSS vector string.
    """
    if not osv_severity:
        return "medium"

    for entry in osv_severity:
        score_str = entry.get("score", "")
        # Try to extract numeric base score from CVSS vector
        # CVSS vectors end with metrics; we need the base score
        # Some OSV entries include a numeric score directly
        if isinstance(score_str, (int, float)):
            return _cvss_to_level(float(score_str))

        # Parse CVSS vector string — extract base score
        # Try the database_specific or ecosystem_specific score first
        base_score = _extract_cvss_base_score(score_str)
        if base_score is not None:
            return _cvss_to_level(base_score)

    return "medium"


def _extract_cvss_base_score(cvss_vector: str) -> float | None:
    """Extract the numeric base score from a CVSS vector string.

    Handles both CVSS v3 and v2 vectors. Falls back to a simplified
    heuristic if the full vector parsing is not needed.
    """
    if not cvss_vector:
        return None

    # Some entries directly provide a numeric score
    try:
        return float(cvss_vector)
    except (ValueError, TypeError):
        pass

    # For CVSS v3 vectors like "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"
    # We approximate the base score from the impact metrics
    if "CVSS:" not in cvss_vector:
        return None

    # Simplified scoring based on CIA impact values
    parts = cvss_vector.split("/")
    impact_values = {"N": 0.0, "L": 0.22, "H": 0.56}

    c_val = i_val = a_val = 0.0
    av_val = 0.85  # Default to Network
    ac_val = 0.77  # Default to Low
    pr_val = 0.85  # Default to None
    ui_val = 0.85  # Default to None

    for part in parts:
        if part.startswith("C:"):
            c_val = impact_values.get(part[2:], 0.0)
        elif part.startswith("I:"):
            i_val = impact_values.get(part[2:], 0.0)
        elif part.startswith("A:"):
            a_val = impact_values.get(part[2:], 0.0)
        elif part.startswith("AV:"):
            av_map = {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.20}
            av_val = av_map.get(part[3:], 0.85)
        elif part.startswith("AC:"):
            ac_map = {"L": 0.77, "H": 0.44}
            ac_val = ac_map.get(part[3:], 0.77)
        elif part.startswith("PR:"):
            pr_map = {"N": 0.85, "L": 0.62, "H": 0.27}
            pr_val = pr_map.get(part[3:], 0.85)
        elif part.startswith("UI:"):
            ui_map = {"N": 0.85, "R": 0.62}
            ui_val = ui_map.get(part[3:], 0.85)

    # Simplified CVSS v3 base score calculation
    isc_base = 1 - (1 - c_val) * (1 - i_val) * (1 - a_val)
    if isc_base <= 0:
        return 0.0

    impact = 6.42 * isc_base
    exploitability = 8.22 * av_val * ac_val * pr_val * ui_val
    base = min(impact + exploitability, 10.0)

    # Rough normalization — the real CVSS formula is more complex
    # but this gives a reasonable approximation for severity bucketing
    return round(min(base * 0.6, 10.0), 1)


def _cvss_to_level(score: float) -> str:
    """Map a numeric CVSS score to a severity level."""
    if score >= 9.0:
        return "critical"
    if score >= 7.0:
        return "high"
    if score >= 4.0:
        return "medium"
    return "low"


def _extract_fixed_version(vuln_data: dict[str, Any]) -> str | None:
    """Extract the earliest fixed version from OSV affected ranges."""
    for affected in vuln_data.get("affected", []):
        for rng in affected.get("ranges", []):
            for event in rng.get("events", []):
                fixed = event.get("fixed")
                if fixed:
                    return fixed
    return None



def result_to_dict(result: VulnScanResult) -> dict[str, Any]:
    """Convert VulnScanResult to a JSON-serializable dict."""
    return {
        "total_dependencies": result.total_dependencies,
        "vulnerable_count": result.vulnerable_count,
        "scan_timestamp": result.scan_timestamp,
        "by_severity": result.by_severity,
        "kev_count": result.kev_count,
        "vulnerabilities": [
            {
                "id": v.id,
                "summary": v.summary,
                "severity": v.severity,
                "affected_package": v.affected_package,
                "affected_version": v.affected_version,
                "fixed_version": v.fixed_version,
                "references": v.references,
                "kev_tagged": v.kev_tagged,
            }
            for v in result.vulnerabilities
        ],
    }


def generate_vuln_html_report(data: dict[str, Any]) -> str:
    """Generate a standalone HTML vulnerability report."""
    from html import escape

    sev_colors = {"critical": "#ef4444", "high": "#f97316", "medium": "#eab308", "low": "#6366f1"}
    vulns = data.get("vulnerabilities", [])
    by_sev = data.get("by_severity", {})
    total = data.get("total_dependencies", 0)
    vuln_count = data.get("vulnerable_count", 0)
    timestamp = data.get("scan_timestamp", "")

    kev_count = data.get("kev_count", 0)

    # Summary bar
    sev_pills = ""
    for s in ["critical", "high", "medium", "low"]:
        n = by_sev.get(s, 0)
        if n > 0:
            sev_pills += f'<span style="background:{sev_colors[s]}20;color:{sev_colors[s]};padding:3px 10px;border-radius:4px;font-weight:600;font-size:0.85rem">{n} {s}</span> '

    # Sort by severity (highest first), then by package name
    sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    vulns = sorted(vulns, key=lambda v: (sev_order.get(v.get("severity", "low"), 9), v.get("affected_package", "")))

    # KEV banner
    kev_banner = ""
    if kev_count > 0:
        kev_banner = (
            f'<div style="background:#ef444420;border:1px solid #ef4444;border-radius:6px;padding:12px 16px;margin-bottom:24px">'
            f'<strong style="color:#ef4444">CISA KEV:</strong> {kev_count} vulnerabilit{"y" if kev_count == 1 else "ies"} '
            f'match the <a href="https://www.cisa.gov/known-exploited-vulnerabilities-catalog" target="_blank" style="color:#6366f1">'
            f'CISA Known Exploited Vulnerabilities</a> catalog — prioritize remediation.</div>'
        )

    # Vuln rows
    rows = ""
    for v in vulns:
        sc = sev_colors.get(v.get("severity", "medium"), "#6b7280")
        refs = v.get("references", [])
        kev_badge = ' <span style="background:#ef4444;color:#fff;padding:1px 6px;border-radius:3px;font-size:0.7rem;font-weight:700">KEV</span>' if v.get("kev_tagged") else ""
        ref_link = (f'<a href="{escape(refs[0])}" target="_blank" style="color:#6366f1">{escape(v["id"])}</a>' if refs else escape(v.get("id", ""))) + kev_badge
        fix = escape(v.get("fixed_version") or "—")
        fix_style = 'color:#22c55e' if v.get("fixed_version") else 'color:#888'
        rows += f"""<tr>
            <td><span style="background:{sc}20;color:{sc};padding:2px 8px;border-radius:4px;font-size:0.75rem;font-weight:600">{escape(v.get('severity',''))}</span></td>
            <td style="font-family:monospace;font-weight:500">{escape(v.get('affected_package',''))}</td>
            <td style="font-family:monospace">{escape(v.get('affected_version',''))}</td>
            <td>{ref_link}</td>
            <td style="font-family:monospace;{fix_style}">{fix}</td>
        </tr>
        <tr><td colspan="5" style="padding:4px 12px 12px;font-size:0.8rem;color:#666;border-bottom:1px solid #e0e0e0">{escape(v.get('summary',''))}</td></tr>"""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Vulnerability Report — SENTRIK</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 24px; background: #fff; color: #1a1a2e; }}
  h1 {{ font-size: 1.4rem; margin-bottom: 4px; }}
  .meta {{ font-size: 0.8rem; color: #888; margin-bottom: 24px; }}
  .summary {{ display: flex; gap: 16px; align-items: center; margin-bottom: 24px; flex-wrap: wrap; }}
  .summary .big {{ font-size: 2rem; font-weight: 700; }}
  .summary .label {{ font-size: 0.8rem; color: #888; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 0.85rem; }}
  th {{ text-align: left; padding: 8px 12px; border-bottom: 2px solid #e0e0e0; color: #888; font-size: 0.75rem; text-transform: uppercase; }}
  td {{ padding: 8px 12px; border-bottom: 1px solid #f0f0f0; }}
  @media print {{ body {{ padding: 12px; }} }}
  @media (prefers-color-scheme: dark) {{
    body {{ background: #0d1117; color: #e6edf3; }}
    th {{ border-color: #2a2a3e; color: #8888a0; }}
    td {{ border-color: #1a1a2e; }}
    .meta {{ color: #8888a0; }}
    .summary .label {{ color: #8888a0; }}
  }}
</style>
</head>
<body>
<h1>Vulnerability Report</h1>
<div class="meta">Generated by SENTRIK &middot; {escape(timestamp)}</div>

<div class="summary">
  <div><div class="big">{total}</div><div class="label">dependencies scanned</div></div>
  <div><div class="big" style="color:{'#ef4444' if vuln_count > 0 else '#22c55e'}">{vuln_count}</div><div class="label">vulnerable</div></div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">{sev_pills}</div>
</div>

{kev_banner}

{'<table><thead><tr><th>Severity</th><th>Package</th><th>Version</th><th>Advisory</th><th>Fix</th></tr></thead><tbody>' + rows + '</tbody></table>' if vulns else '<p style="text-align:center;padding:32px;color:#22c55e;font-weight:600">No known vulnerabilities found.</p>'}

</body>
</html>"""
