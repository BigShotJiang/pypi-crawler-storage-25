"""Expertise-Gap Escalation — flag code outside developer's comfort zone.

Analyzes git history to build per-developer profiles (languages, modules,
frameworks) and escalates review when AI-generated code falls outside
their expertise area.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class DeveloperProfile:
    email: str
    name: str = ""
    languages: dict[str, int] = field(default_factory=dict)  # lang → commit count
    modules: dict[str, int] = field(default_factory=dict)  # top-level dir → commit count
    total_commits: int = 0

    def strength_ratio(self, language: str) -> float:
        """Return 0.0-1.0 ratio of commits in this language vs total."""
        if self.total_commits == 0:
            return 0.0
        return self.languages.get(language, 0) / self.total_commits

    def module_ratio(self, module: str) -> float:
        """Return 0.0-1.0 ratio of commits in this module vs total."""
        if self.total_commits == 0:
            return 0.0
        return self.modules.get(module, 0) / self.total_commits

    def to_dict(self) -> dict[str, Any]:
        return {
            "email": self.email,
            "name": self.name,
            "languages": self.languages,
            "modules": self.modules,
            "total_commits": self.total_commits,
        }


@dataclass
class ExpertiseGap:
    file: str
    language: str
    module: str
    developer_ratio: float  # 0.0-1.0, how much experience in this area
    message: str
    severity: str = "info"

    def to_dict(self) -> dict[str, Any]:
        return {
            "file": self.file,
            "language": self.language,
            "module": self.module,
            "developer_ratio": round(self.developer_ratio, 2),
            "message": self.message,
            "severity": self.severity,
        }


_EXT_LANG = {
    ".py": "Python", ".js": "JavaScript", ".ts": "TypeScript",
    ".go": "Go", ".rs": "Rust", ".java": "Java", ".kt": "Kotlin",
    ".rb": "Ruby", ".php": "PHP", ".cs": "C#", ".cpp": "C++",
    ".c": "C", ".swift": "Swift", ".dart": "Dart",
    ".jsx": "JavaScript", ".tsx": "TypeScript",
    ".vue": "Vue", ".svelte": "Svelte",
}


def build_developer_profile(
    email: str,
    repo_root: str = ".",
    lookback_days: int = 180,
) -> DeveloperProfile:
    """Build a developer profile from git history."""
    profile = DeveloperProfile(email=email)

    try:
        result = subprocess.run(
            ["git", "log", f"--author={email}", f"--since={lookback_days} days ago",
             "--name-only", "--pretty=format:%an", "--diff-filter=ACMR"],
            capture_output=True, text=True, timeout=30, cwd=repo_root,
        )
        if result.returncode != 0:
            return profile
    except (OSError, subprocess.TimeoutExpired):
        return profile

    lines = result.stdout.strip().split("\n")
    current_name = ""
    lang_counter: Counter[str] = Counter()
    module_counter: Counter[str] = Counter()
    commits = 0

    for line in lines:
        line = line.strip()
        if not line:
            commits += 1
            continue
        if "." not in line and "/" not in line:
            current_name = line
            continue

        # It's a file path
        ext = Path(line).suffix.lower()
        lang = _EXT_LANG.get(ext)
        if lang:
            lang_counter[lang] += 1

        parts = Path(line).parts
        if parts:
            module_counter[parts[0]] += 1

    profile.name = current_name
    profile.languages = dict(lang_counter.most_common())
    profile.modules = dict(module_counter.most_common())
    profile.total_commits = max(commits, 1)

    return profile


def get_current_user(repo_root: str = ".") -> str | None:
    """Get the current git user's email."""
    try:
        result = subprocess.run(
            ["git", "config", "user.email"],
            capture_output=True, text=True, timeout=5, cwd=repo_root,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        pass
    return None


def check_expertise_gaps(
    profile: DeveloperProfile,
    changed_files: list[str],
    threshold: float = 0.3,
    severity: str = "info",
) -> list[ExpertiseGap]:
    """Check if changed files fall outside the developer's expertise."""
    gaps = []

    for file_path in changed_files:
        ext = Path(file_path).suffix.lower()
        lang = _EXT_LANG.get(ext, "")
        parts = Path(file_path).parts
        module = parts[0] if parts else ""

        if not lang:
            continue

        ratio = profile.strength_ratio(lang)
        if ratio < threshold:
            pct = int(ratio * 100)
            gaps.append(ExpertiseGap(
                file=file_path,
                language=lang,
                module=module,
                developer_ratio=ratio,
                message=(
                    f"{lang} code is outside your usual expertise "
                    f"({pct}% of your commits). Consider requesting "
                    f"review from a {lang} specialist."
                ),
                severity=severity,
            ))

    return gaps


def get_changed_files(git_range: str | None = None, staged: bool = False, repo_root: str = ".") -> list[str]:
    """Get list of changed files."""
    if staged:
        cmd = ["git", "diff", "--cached", "--name-only"]
    elif git_range:
        cmd = ["git", "diff", "--name-only", git_range]
    else:
        cmd = ["git", "diff", "--name-only", "HEAD~1..HEAD"]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10, cwd=repo_root)
        if result.returncode == 0:
            return [f.strip() for f in result.stdout.strip().split("\n") if f.strip()]
    except (OSError, subprocess.TimeoutExpired):
        pass
    return []


def format_gaps(gaps: list[ExpertiseGap], profile: DeveloperProfile) -> str:
    """Format expertise gaps as human-readable text."""
    if not gaps:
        return f"\nNo expertise gaps detected for {profile.email}.\n"

    lines = [f"\n{len(gaps)} expertise gap(s) for {profile.name or profile.email}:\n"]
    lines.append(f"  Your strengths: {', '.join(profile.languages.keys()) or 'unknown'}\n")

    for g in gaps:
        lines.append(f"  [{g.severity.upper()}] {g.file}")
        lines.append(f"    {g.message}")
        lines.append("")

    return "\n".join(lines)


def save_profiles(profiles: dict[str, DeveloperProfile], output_dir: str = "out") -> Path:
    """Save developer profiles to out/developer_profiles.json."""
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / "developer_profiles.json"
    data = {email: p.to_dict() for email, p in profiles.items()}
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return path


def load_profiles(output_dir: str = "out") -> dict[str, DeveloperProfile]:
    """Load cached developer profiles."""
    path = Path(output_dir) / "developer_profiles.json"
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return {email: DeveloperProfile(**p) for email, p in data.items()}
    except (json.JSONDecodeError, OSError, TypeError):
        return {}
