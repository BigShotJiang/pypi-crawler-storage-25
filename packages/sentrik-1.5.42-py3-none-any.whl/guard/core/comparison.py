"""Run comparison — detects new, resolved, and unchanged findings between runs."""

from __future__ import annotations

import json
import logging
from pathlib import Path

from guard.core.models import Evidence, Finding, RunComparison, Severity

logger = logging.getLogger(__name__)


def compare_runs(
    current: list[Finding],
    previous: list[Finding],
) -> RunComparison:
    """Compare *current* findings against *previous* findings.

    Matching is done by ``finding_id``.  Findings present in *current*
    but not *previous* are ``new``.  Findings present in *previous* but
    not *current* are ``resolved``.  The rest are ``unchanged``.
    """
    prev_ids = {f.finding_id for f in previous}
    curr_ids = {f.finding_id for f in current}

    new = [f for f in current if f.finding_id not in prev_ids]
    resolved = [f for f in previous if f.finding_id not in curr_ids]
    unchanged = [f for f in current if f.finding_id in prev_ids]

    return RunComparison(
        new_findings=new,
        resolved_findings=resolved,
        unchanged_findings=unchanged,
    )


def load_findings(findings_path: Path) -> list[Finding]:
    """Load findings from a JSON file, returning an empty list on failure."""
    if not findings_path.exists():
        return []
    try:
        with open(findings_path, encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError) as exc:
        logger.warning("Failed to load findings from %s: %s", findings_path, exc)
        return []

    if not isinstance(data, list):
        return []

    findings: list[Finding] = []
    for item in data:
        try:
            findings.append(Finding(**item))
        except (ValueError, TypeError, KeyError):
            continue
    return findings


def render_comparison(comp: RunComparison) -> str:
    """Render a run comparison as a concise markdown summary."""
    lines = ["# Run Comparison", ""]
    lines.append(f"- **New findings:** {len(comp.new_findings)}")
    lines.append(f"- **Resolved findings:** {len(comp.resolved_findings)}")
    lines.append(f"- **Unchanged findings:** {len(comp.unchanged_findings)}")
    lines.append("")

    if comp.new_findings:
        lines.append("## New Findings")
        lines.append("")
        for f in comp.new_findings:
            lines.append(
                f"- **[{f.severity.value.upper()}]** `{f.evidence.file}` — "
                f"{f.message} ({f.finding_id})"
            )
        lines.append("")

    if comp.resolved_findings:
        lines.append("## Resolved Findings")
        lines.append("")
        for f in comp.resolved_findings:
            lines.append(
                f"- ~~`{f.evidence.file}` — {f.message} ({f.finding_id})~~"
            )
        lines.append("")

    return "\n".join(lines)
