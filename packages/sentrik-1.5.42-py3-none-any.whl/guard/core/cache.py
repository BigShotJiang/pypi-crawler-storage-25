"""Scan cache — skip unchanged files using content hashes."""

from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path
from typing import Any

from guard.core.models import Finding

logger = logging.getLogger(__name__)


class ScanCache:
    """Content-hash based cache for deterministic scan findings.

    Stores a mapping of ``(file_path, content_hash, rules_hash) → findings``
    so that unchanged files with unchanged rules can skip re-evaluation.

    Only deterministic findings are cached.  Heuristic/LLM findings must
    always be re-evaluated.
    """

    def __init__(self, cache_dir: str | Path):
        self._cache_dir = Path(cache_dir)
        self._cache_file = self._cache_dir / "findings_cache.json"
        self._data: dict[str, Any] = {}
        self._load()

    def _load(self) -> None:
        """Load cache from disk."""
        if not self._cache_file.exists():
            self._data = {}
            return
        try:
            with open(self._cache_file, encoding="utf-8") as f:
                self._data = json.load(f)
        except (json.JSONDecodeError, OSError):
            logger.warning("Corrupted cache file — starting fresh")
            self._data = {}

    def save(self) -> None:
        """Persist cache to disk."""
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        with open(self._cache_file, "w", encoding="utf-8") as f:
            json.dump(self._data, f, indent=2)

    def get(self, file_path: str, content_hash: str, rules_hash: str, rule_id: str = "") -> list[Finding] | None:
        """Return cached findings for *file_path* + *rule_id* if hashes match, else ``None``."""
        cache_key = f"{file_path}::{rule_id}" if rule_id else file_path
        entry = self._data.get(cache_key)
        if entry is None:
            return None
        if entry.get("content_hash") != content_hash:
            return None
        if entry.get("rules_hash") != rules_hash:
            return None
        try:
            return [Finding(**f) for f in entry.get("findings", [])]
        except (ValueError, TypeError, KeyError):
            return None

    def put(
        self,
        file_path: str,
        content_hash: str,
        rules_hash: str,
        findings: list[Finding],
        rule_id: str = "",
    ) -> None:
        """Store findings for *file_path* + *rule_id* with the given hashes."""
        cache_key = f"{file_path}::{rule_id}" if rule_id else file_path
        self._data[cache_key] = {
            "content_hash": content_hash,
            "rules_hash": rules_hash,
            "findings": [f.model_dump() for f in findings],
        }

    def invalidate(self, file_path: str) -> None:
        """Remove a single file from the cache."""
        self._data.pop(file_path, None)

    def clear(self) -> None:
        """Clear the entire cache."""
        self._data = {}

    @property
    def size(self) -> int:
        """Number of cached file entries."""
        return len(self._data)


def content_hash(text: str) -> str:
    """Compute a SHA-256 hex digest of *text*."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def rules_hash(rules: list[dict]) -> str:
    """Compute a hash representing the current rule set."""
    serialized = json.dumps(rules, sort_keys=True)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()
