"""Dedicated secrets scanner — detects hardcoded credentials, API keys,
tokens, and private keys in source files.

More precise than generic regex rules: uses provider-specific patterns
(AWS, GitHub, Stripe, etc.) with entropy checks to reduce false positives.
"""

from __future__ import annotations

import math
import os
import re
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class SecretFinding:
    """A detected secret in a source file."""

    file: str
    line: int
    rule: str
    description: str
    severity: str  # critical, high, medium
    match: str  # redacted match (first 4 + last 4 chars)
    entropy: float = 0.0


@dataclass
class SecretsScanResult:
    """Results from a secrets scan."""

    findings: list[SecretFinding] = field(default_factory=list)
    files_scanned: int = 0

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "critical")

    @property
    def high_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "high")

    def to_dict(self) -> dict[str, Any]:
        return {
            "findings_count": len(self.findings),
            "files_scanned": self.files_scanned,
            "by_severity": {
                "critical": self.critical_count,
                "high": self.high_count,
                "medium": sum(1 for f in self.findings if f.severity == "medium"),
            },
            "findings": [
                {
                    "file": f.file,
                    "line": f.line,
                    "rule": f.rule,
                    "description": f.description,
                    "severity": f.severity,
                    "match": f.match,
                    "entropy": round(f.entropy, 2),
                }
                for f in self.findings
            ],
        }


# --- Secret patterns ---
# Each pattern: (rule_id, description, regex, severity, min_entropy)
# min_entropy=0 means no entropy check (pattern is specific enough)

_SECRET_PATTERNS: list[tuple[str, str, re.Pattern, str, float]] = [
    # AWS
    ("SECRET-AWS-KEY", "AWS Access Key ID",
     re.compile(r"(?:^|[\"'`\s=:])(?P<secret>AKIA[0-9A-Z]{16})(?:[\"'`\s]|$)"), "critical", 0),
    ("SECRET-AWS-SECRET", "AWS Secret Access Key",
     re.compile(r"(?i)aws[_\-]?secret[_\-]?access[_\-]?key[\s]*[=:]+[\s]*[\"']?(?P<secret>[A-Za-z0-9/+=]{40})[\"']?"), "critical", 3.5),

    # GitHub
    ("SECRET-GH-PAT", "GitHub Personal Access Token",
     re.compile(r"(?P<secret>ghp_[A-Za-z0-9]{36})"), "critical", 0),
    ("SECRET-GH-OAUTH", "GitHub OAuth Access Token",
     re.compile(r"(?P<secret>gho_[A-Za-z0-9]{36})"), "critical", 0),
    ("SECRET-GH-APP", "GitHub App Token",
     re.compile(r"(?P<secret>(?:ghs|ghr)_[A-Za-z0-9]{36})"), "high", 0),

    # Stripe
    ("SECRET-STRIPE-LIVE", "Stripe Live Secret Key",
     re.compile(r"(?P<secret>sk_live_[A-Za-z0-9]{24,})"), "critical", 0),
    ("SECRET-STRIPE-TEST", "Stripe Test Secret Key",
     re.compile(r"(?P<secret>sk_test_[A-Za-z0-9]{24,})"), "medium", 0),

    # Slack
    ("SECRET-SLACK-TOKEN", "Slack Bot/User Token",
     re.compile(r"(?P<secret>xox[bpors]-[A-Za-z0-9\-]{10,})"), "high", 0),
    ("SECRET-SLACK-WEBHOOK", "Slack Webhook URL",
     re.compile(r"(?P<secret>https://hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[A-Za-z0-9]+)"), "high", 0),

    # Private keys
    ("SECRET-PRIVATE-KEY", "Private Key (PEM format)",
     re.compile(r"(?P<secret>-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----)"), "critical", 0),

    # JWT
    ("SECRET-JWT", "JSON Web Token",
     re.compile(r"(?P<secret>eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})"), "high", 0),

    # Generic high-entropy secrets
    ("SECRET-GENERIC-KEY", "Generic API key assignment",
     re.compile(r"(?i)(?:api[_\-]?key|api[_\-]?secret|auth[_\-]?token|secret[_\-]?key|access[_\-]?token|client[_\-]?secret)[\s]*[=:]+[\s]*[\"'](?P<secret>[A-Za-z0-9+/=_\-]{16,})[\"']"), "high", 3.5),

    # Database connection strings
    ("SECRET-DB-URI", "Database connection string with credentials",
     re.compile(r"(?P<secret>(?:mysql|postgres|postgresql|mongodb|redis|amqp)://[^:]+:[^@]+@[^\s\"']+)"), "critical", 0),

    # Hardcoded passwords
    ("SECRET-PASSWORD", "Hardcoded password assignment",
     re.compile(r"(?i)(?:password|passwd|pwd)\s*[=:]+\s*[\"'](?P<secret>[^\"']{8,})[\"']"), "high", 3.0),
]

# Files to always skip
_SKIP_EXTENSIONS = frozenset({
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg", ".woff", ".woff2",
    ".ttf", ".eot", ".mp3", ".mp4", ".zip", ".tar", ".gz", ".exe",
    ".dll", ".so", ".dylib", ".pyc", ".pyo", ".class", ".o", ".obj",
})

_SKIP_FILENAMES = frozenset({
    "package-lock.json", "yarn.lock", "poetry.lock", "Cargo.lock",
    "go.sum", "composer.lock", "Gemfile.lock",
})


def _shannon_entropy(s: str) -> float:
    """Calculate Shannon entropy of a string."""
    if not s:
        return 0.0
    freq: dict[str, int] = {}
    for c in s:
        freq[c] = freq.get(c, 0) + 1
    length = len(s)
    return -sum((count / length) * math.log2(count / length) for count in freq.values())


def _redact(secret: str) -> str:
    """Redact a secret, showing only first 4 and last 4 characters."""
    if len(secret) <= 12:
        return secret[:4] + "****"
    return secret[:4] + "****" + secret[-4:]


def _is_likely_example(line: str) -> bool:
    """Check if a line is likely a documentation example, not a real secret."""
    lower = line.lower()
    return any(marker in lower for marker in (
        "example", "placeholder", "your_", "xxx", "todo",
        "replace_me", "changeme", "insert_", "dummy", "<your",
    ))


def scan_file(file_path: str | Path) -> list[SecretFinding]:
    """Scan a single file for hardcoded secrets."""
    path = Path(file_path)

    # Skip binary and lock files
    if path.suffix.lower() in _SKIP_EXTENSIONS:
        return []
    if path.name in _SKIP_FILENAMES:
        return []

    try:
        content = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return []

    findings: list[SecretFinding] = []
    lines = content.splitlines()

    for line_num, line in enumerate(lines, start=1):
        # Skip empty/short lines
        if len(line.strip()) < 10:
            continue

        # Skip likely examples
        if _is_likely_example(line):
            continue

        for rule_id, description, pattern, severity, min_entropy in _SECRET_PATTERNS:
            match = pattern.search(line)
            if not match:
                continue

            secret = match.group("secret")

            # Entropy check for generic patterns
            if min_entropy > 0:
                entropy = _shannon_entropy(secret)
                if entropy < min_entropy:
                    continue
            else:
                entropy = _shannon_entropy(secret)

            findings.append(SecretFinding(
                file=str(path),
                line=line_num,
                rule=rule_id,
                description=description,
                severity=severity,
                match=_redact(secret),
                entropy=entropy,
            ))
            break  # One finding per line (highest priority pattern wins)

    return findings


def scan_directory(
    root: str | Path,
    file_paths: list[str] | None = None,
    excludes: list[str] | None = None,
) -> SecretsScanResult:
    """Scan a directory for hardcoded secrets.

    Args:
        root: Project root directory.
        file_paths: If provided, only scan these files (relative paths).
        excludes: Glob patterns for paths to skip.
    """
    import fnmatch

    root_path = Path(root).resolve()
    result = SecretsScanResult()
    excludes = excludes or []

    if file_paths:
        paths = [root_path / fp for fp in file_paths]
    else:
        paths = []
        for dirpath, dirnames, filenames in os.walk(root_path):
            # Skip hidden dirs and common non-source dirs
            dirnames[:] = [
                d for d in dirnames
                if not d.startswith(".") and d not in {
                    "node_modules", "__pycache__", ".venv", "venv",
                    ".git", "dist", "build", ".sentrik",
                }
            ]
            for fname in filenames:
                full = Path(dirpath) / fname
                rel = str(full.relative_to(root_path)).replace("\\", "/")
                if any(fnmatch.fnmatch(rel, pat) for pat in excludes):
                    continue
                paths.append(full)

    for path in paths:
        if not path.is_file():
            continue
        result.files_scanned += 1
        findings = scan_file(path)
        for f in findings:
            # Convert absolute path to relative
            try:
                f.file = str(Path(f.file).relative_to(root_path))
            except ValueError:
                pass
        result.findings.extend(findings)

    # Sort by severity (critical first)
    sev_order = {"critical": 0, "high": 1, "medium": 2}
    result.findings.sort(key=lambda f: sev_order.get(f.severity, 3))

    return result
