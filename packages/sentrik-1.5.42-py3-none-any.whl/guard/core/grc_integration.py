"""GRC platform integration — push compliance evidence to external platforms.

Supports Drata, Vanta, Secureframe, and any generic webhook endpoint.
"""

from __future__ import annotations

import json
import logging
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from guard import __version__

logger = logging.getLogger(__name__)


@dataclass
class GRCConfig:
    """Configuration for GRC webhook integration."""

    webhook_url: str = ""
    api_key: str = ""
    platform: str = "generic"  # "generic", "drata", "vanta", "secureframe"
    events: list[str] = field(default_factory=list)


@dataclass
class GRCPayload:
    """Payload to send to the GRC webhook endpoint."""

    event: str
    timestamp: str
    project_name: str
    data: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "event": self.event,
            "timestamp": self.timestamp,
            "project_name": self.project_name,
            "data": self.data,
        }


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _validate_webhook_url(url: str) -> bool:
    """Validate that a webhook URL is safe to send to.

    Rejects non-HTTPS schemes (except localhost for dev), private/internal
    IPs, and file:// URLs to prevent SSRF attacks.
    """
    from urllib.parse import urlparse

    parsed = urlparse(url)

    # Only allow http and https schemes
    if parsed.scheme not in ("http", "https"):
        logger.warning("GRC webhook rejected: scheme %r not allowed (use https)", parsed.scheme)
        return False

    # Require https in production (allow http only for localhost/127.0.0.1)
    hostname = parsed.hostname or ""
    is_local = hostname in ("localhost", "127.0.0.1", "::1")
    if parsed.scheme == "http" and not is_local:
        logger.warning("GRC webhook rejected: http not allowed for non-localhost URL %r (use https)", hostname)
        return False

    # Block private/internal IP ranges
    if hostname:
        import ipaddress
        try:
            ip = ipaddress.ip_address(hostname)
            if ip.is_private and not is_local:
                logger.warning("GRC webhook rejected: private IP address %s", hostname)
                return False
            if ip.is_loopback and not is_local:
                logger.warning("GRC webhook rejected: loopback address %s", hostname)
                return False
        except ValueError:
            pass  # Not an IP — it's a hostname, which is fine

    # Block obviously dangerous patterns
    if not hostname:
        logger.warning("GRC webhook rejected: no hostname in URL")
        return False

    return True


def push_event(config: GRCConfig, payload: GRCPayload) -> bool:
    """POST the payload as JSON to the configured webhook URL.

    Returns True on 2xx, False otherwise. Never raises.
    """
    if not config.webhook_url:
        return False

    if not _validate_webhook_url(config.webhook_url):
        return False

    headers: dict[str, str] = {
        "Content-Type": "application/json",
        "X-Sentrik-Event": payload.event,
        "X-Sentrik-Version": __version__,
    }
    if config.api_key:
        headers["Authorization"] = f"Bearer {config.api_key}"

    body = _transform_payload(config.platform, payload)
    data = json.dumps(body).encode("utf-8")

    try:
        req = urllib.request.Request(
            config.webhook_url,
            data=data,
            headers=headers,
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            status = resp.status
            return 200 <= status < 300
    except urllib.error.HTTPError as exc:
        logger.warning(
            "GRC webhook returned HTTP %s for event %s: %s",
            exc.code, payload.event, exc.reason,
        )
        return False
    except Exception as exc:
        logger.warning(
            "GRC webhook request failed for event %s: %s",
            payload.event, exc,
        )
        return False


def _transform_payload(platform: str, payload: GRCPayload) -> dict[str, Any]:
    """Transform the payload for platform-specific schemas."""
    raw = payload.to_dict()

    if platform == "drata":
        return _transform_drata(raw)
    elif platform == "vanta":
        return _transform_vanta(raw)
    elif platform == "secureframe":
        return _transform_secureframe(raw)
    return raw


def _transform_drata(raw: dict[str, Any]) -> dict[str, Any]:
    """Transform payload to Drata evidence format."""
    data = raw.get("data", {})
    return {
        "evidenceType": "AUTOMATED",
        "source": "sentrik",
        "sourceEvent": raw.get("event", ""),
        "collectedAt": raw.get("timestamp", ""),
        "projectName": raw.get("project_name", ""),
        "result": "PASS" if data.get("gate_passed", data.get("compliance_score", 0) >= 80) else "FAIL",
        "details": {
            "compliance_score": data.get("compliance_score"),
            "findings_summary": data.get("findings_summary", {}),
            "gate_result": data.get("gate_result", {}),
            "version": __version__,
        },
    }


def _transform_vanta(raw: dict[str, Any]) -> dict[str, Any]:
    """Transform payload to Vanta evidence format."""
    data = raw.get("data", {})
    return {
        "integration": "sentrik",
        "type": raw.get("event", ""),
        "timestamp": raw.get("timestamp", ""),
        "resource": {
            "name": raw.get("project_name", ""),
            "type": "repository",
        },
        "outcome": "pass" if data.get("gate_passed", data.get("compliance_score", 0) >= 80) else "fail",
        "evidence": {
            "compliance_score": data.get("compliance_score"),
            "findings_by_severity": data.get("findings_summary", {}),
            "gate_result": data.get("gate_result", {}),
        },
    }


def _transform_secureframe(raw: dict[str, Any]) -> dict[str, Any]:
    """Transform payload to Secureframe evidence format."""
    data = raw.get("data", {})
    return {
        "source": "sentrik",
        "event_type": raw.get("event", ""),
        "collected_at": raw.get("timestamp", ""),
        "asset": {
            "name": raw.get("project_name", ""),
            "asset_type": "code_repository",
        },
        "status": "passing" if data.get("gate_passed", data.get("compliance_score", 0) >= 80) else "failing",
        "metadata": {
            "compliance_score": data.get("compliance_score"),
            "findings_summary": data.get("findings_summary", {}),
            "gate_result": data.get("gate_result", {}),
            "sentrik_version": __version__,
        },
    }


def build_scan_payload(
    findings_summary: dict[str, Any],
    compliance_score: float | dict[str, Any],
    project_name: str,
) -> GRCPayload:
    """Build a scan_complete payload from scan results."""
    score = compliance_score
    if isinstance(compliance_score, dict):
        score = compliance_score.get("score", 0.0)

    return GRCPayload(
        event="scan_complete",
        timestamp=_now_iso(),
        project_name=project_name,
        data={
            "findings_summary": findings_summary,
            "compliance_score": score,
            "total_findings": sum(findings_summary.values()) if isinstance(findings_summary, dict) else 0,
        },
    )


def build_gate_payload(
    gate_result: Any,
    project_name: str,
) -> GRCPayload:
    """Build a gate_passed or gate_failed payload from a GateResult."""
    passed = getattr(gate_result, "passed", False)
    event = "gate_passed" if passed else "gate_failed"

    return GRCPayload(
        event=event,
        timestamp=_now_iso(),
        project_name=project_name,
        data={
            "gate_passed": passed,
            "gate_result": {
                "passed": passed,
                "total_findings": getattr(gate_result, "total_findings", 0),
                "critical": getattr(gate_result, "critical", 0),
                "high": getattr(gate_result, "high", 0),
                "medium": getattr(gate_result, "medium", 0),
                "low": getattr(gate_result, "low", 0),
                "info": getattr(gate_result, "info", 0),
            },
        },
    )


def build_vuln_payload(
    vuln_result: dict[str, Any],
    project_name: str,
) -> GRCPayload:
    """Build a vuln_scan payload from vulnerability scan results."""
    return GRCPayload(
        event="vuln_scan",
        timestamp=_now_iso(),
        project_name=project_name,
        data={
            "vulnerabilities": vuln_result.get("vulnerabilities", []),
            "total_vulnerabilities": vuln_result.get("total", 0),
            "critical": vuln_result.get("critical", 0),
            "high": vuln_result.get("high", 0),
            "medium": vuln_result.get("medium", 0),
            "low": vuln_result.get("low", 0),
        },
    )


def build_grc_config_from_guard_config(config: Any) -> GRCConfig:
    """Build a GRCConfig from a GuardConfig instance."""
    import os

    url = getattr(config, "grc_webhook_url", "") or os.environ.get("GUARD_GRC_WEBHOOK_URL", "")
    api_key = os.environ.get("GUARD_GRC_API_KEY", "") or getattr(config, "grc_api_key", "")
    platform = getattr(config, "grc_platform", "generic") or os.environ.get("GUARD_GRC_PLATFORM", "generic")

    events_raw = getattr(config, "grc_events", [])
    if not events_raw:
        events_env = os.environ.get("GUARD_GRC_EVENTS", "")
        if events_env:
            events_raw = [e.strip() for e in events_env.split(",") if e.strip()]

    return GRCConfig(
        webhook_url=url,
        api_key=api_key,
        platform=platform,
        events=events_raw,
    )


def maybe_push_grc_event(
    config: Any,
    event: str,
    payload: GRCPayload,
) -> bool | None:
    """Push a GRC event if the config has a webhook URL and the event is enabled.

    Returns True on success, False on failure, None if GRC is not configured
    or the event is not in the enabled events list.
    """
    grc_config = build_grc_config_from_guard_config(config)

    if not grc_config.webhook_url:
        return None

    if grc_config.events and event not in grc_config.events:
        return None

    return push_event(grc_config, payload)
