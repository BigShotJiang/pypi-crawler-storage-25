"""Compliance agent — independent evaluation unit for a single standards pack."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from guard.core.cache import ScanCache
from guard.rules.engine import RulesEngine

logger = logging.getLogger(__name__)


@dataclass
class AgentResult:
    """Result from a single compliance agent evaluation."""

    pack_id: str
    findings: list[Any] = field(default_factory=list)
    duration_ms: float = 0.0
    files_scanned: int = 0
    rule_count: int = 0
    error: str | None = None


class ComplianceAgent:
    """Independent compliance evaluation unit for a single standards pack.

    Each agent wraps its own ``RulesEngine`` instance containing only the
    rules from one pack (or user-defined rules).  The orchestrator runs
    multiple agents in parallel.

    When ``drift_analyzer`` is provided, the agent runs context-aware
    requirement drift analysis after rule evaluation.
    """

    def __init__(
        self,
        pack_id: str,
        rules: list[dict[str, Any]],
        max_workers: int = 1,
        drift_analyzer: Any | None = None,
    ) -> None:
        self._pack_id = pack_id
        self._rules = rules
        self._engine = RulesEngine(rules, max_workers=max_workers)
        self._drift_analyzer = drift_analyzer

    @property
    def pack_id(self) -> str:
        return self._pack_id

    @property
    def rule_count(self) -> int:
        return len(self._rules)

    def evaluate(
        self,
        repo_root: str,
        changed_files: list[str] | None = None,
        cache: ScanCache | None = None,
        scan_exclude: list[str] | None = None,
        project_languages: list[str] | None = None,
    ) -> AgentResult:
        """Run this agent's rules and return an ``AgentResult``.

        Exceptions are caught and stored in ``AgentResult.error`` so that
        a single failing agent never crashes the entire scan.
        """
        start = time.perf_counter()
        try:
            findings = self._engine.evaluate(
                repo_root,
                changed_files,
                cache=cache,
                scan_exclude=scan_exclude,
                project_languages=project_languages,
            )

            # Run drift analysis if configured
            if self._drift_analyzer is not None:
                try:
                    drift_findings = self._drift_analyzer.analyze(
                        changed_files=changed_files,
                    )
                    findings.extend(drift_findings)
                except Exception as exc:
                    logger.warning("Drift analysis failed for agent %s: %s", self._pack_id, exc)

            duration = (time.perf_counter() - start) * 1000
            return AgentResult(
                pack_id=self._pack_id,
                findings=findings,
                duration_ms=duration,
                files_scanned=self._engine.files_scanned,
                rule_count=len(self._rules),
            )
        except Exception as exc:
            duration = (time.perf_counter() - start) * 1000
            logger.warning("Agent %s failed: %s", self._pack_id, exc)
            return AgentResult(
                pack_id=self._pack_id,
                findings=[],
                duration_ms=duration,
                files_scanned=0,
                rule_count=len(self._rules),
                error=str(exc),
            )
