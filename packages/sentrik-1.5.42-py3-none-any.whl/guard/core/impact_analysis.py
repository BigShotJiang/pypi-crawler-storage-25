"""Change impact analysis — map changed files to affected rules, requirements, and frameworks."""

from __future__ import annotations

import fnmatch
import subprocess
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from guard.core.models import GeneratedRequirement


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class ImpactItem:
    """Impact assessment for a single changed file."""

    file: str
    requirements: list[str] = field(default_factory=list)
    rules: list[str] = field(default_factory=list)
    frameworks: list[str] = field(default_factory=list)
    risk_level: str = "low"  # "high", "medium", "low"


@dataclass
class ImpactReport:
    """Aggregated impact report across all changed files."""

    changed_files: list[str] = field(default_factory=list)
    items: list[ImpactItem] = field(default_factory=list)
    total_requirements_affected: int = 0
    total_rules_affected: int = 0
    total_frameworks_affected: int = 0
    requires_revalidation: bool = False


# ---------------------------------------------------------------------------
# Severity → risk level mapping
# ---------------------------------------------------------------------------

_HIGH_SEVERITIES = {"critical", "high"}
_MEDIUM_SEVERITIES = {"medium"}


def _risk_level_from_severities(severities: set[str]) -> str:
    """Determine risk level from a set of rule severities."""
    if severities & _HIGH_SEVERITIES:
        return "high"
    if severities & _MEDIUM_SEVERITIES:
        return "medium"
    return "low"


# ---------------------------------------------------------------------------
# Core analysis
# ---------------------------------------------------------------------------


def _file_matches_glob(file_path: str, glob_pattern: str) -> bool:
    """Check if a file path matches a glob pattern.

    Handles common patterns like ``**/*.py``, ``*.cpp``, ``src/**/*.ts``.
    Uses ``fnmatch`` with forward-slash normalisation.
    """
    normalized = file_path.replace("\\", "/")
    pattern = glob_pattern.replace("\\", "/")

    # fnmatch doesn't handle ** well — expand manually
    if "**/" in pattern:
        # "**/*.py" should match "src/foo.py" and "foo.py"
        suffix = pattern.split("**/", 1)[1]
        # Match the suffix against the filename or any sub-path
        parts = normalized.split("/")
        for i in range(len(parts)):
            sub = "/".join(parts[i:])
            if fnmatch.fnmatch(sub, suffix):
                return True
        return False

    return fnmatch.fnmatch(normalized, pattern)


def analyze_impact(
    changed_files: list[str],
    rules: list[dict[str, Any]],
    requirements: list[GeneratedRequirement] | None = None,
) -> ImpactReport:
    """Analyze which rules, requirements, and frameworks are affected by changed files.

    Args:
        changed_files: List of file paths (relative to repo root).
        rules: List of rule dicts (as loaded from standards/packs).
        requirements: Optional list of GeneratedRequirement objects.

    Returns:
        An ImpactReport summarising the impact.
    """
    if not changed_files:
        return ImpactReport()

    reqs = requirements or []
    all_req_ids: set[str] = set()
    all_rule_ids: set[str] = set()
    all_frameworks: set[str] = set()
    any_high = False

    items: list[ImpactItem] = []

    for file_path in changed_files:
        matched_rules: list[str] = []
        matched_frameworks: set[str] = set()
        matched_requirements: list[str] = []
        severities: set[str] = set()

        # Match rules by file_glob
        for rule in rules:
            rule_id = rule.get("id", "")
            file_glob = rule.get("file_glob", "**/*")
            severity = rule.get("severity", "low")
            standard = rule.get("standard")

            if _file_matches_glob(file_path, file_glob):
                matched_rules.append(rule_id)
                severities.add(severity)
                if standard:
                    matched_frameworks.add(standard)

        # Match requirements by source_files
        for req in reqs:
            if not req.source_files:
                continue
            for sf in req.source_files:
                sf_norm = sf.replace("\\", "/")
                file_norm = file_path.replace("\\", "/")
                if sf_norm == file_norm:
                    matched_requirements.append(req.req_id)
                    break

        risk = _risk_level_from_severities(severities)
        if risk == "high":
            any_high = True

        all_rule_ids.update(matched_rules)
        all_req_ids.update(matched_requirements)
        all_frameworks.update(matched_frameworks)

        items.append(ImpactItem(
            file=file_path,
            requirements=matched_requirements,
            rules=matched_rules,
            frameworks=sorted(matched_frameworks),
            risk_level=risk,
        ))

    return ImpactReport(
        changed_files=list(changed_files),
        items=items,
        total_requirements_affected=len(all_req_ids),
        total_rules_affected=len(all_rule_ids),
        total_frameworks_affected=len(all_frameworks),
        requires_revalidation=any_high,
    )


# ---------------------------------------------------------------------------
# Git integration
# ---------------------------------------------------------------------------


def get_changed_files_from_git(
    git_range: str | None = None,
    repo_root: str | None = None,
) -> list[str]:
    """Get changed files from git.

    If *git_range* is provided, runs ``git diff --name-only <range>``.
    If *git_range* is None, returns staged files (``git diff --cached --name-only``).
    """
    cmd = ["git", "diff", "--name-only"]
    if git_range:
        cmd.append(git_range)
    else:
        cmd.append("--cached")

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=repo_root,
        )
        if result.returncode != 0:
            return []
        return [f for f in result.stdout.strip().splitlines() if f]
    except FileNotFoundError:
        return []


# ---------------------------------------------------------------------------
# Serialisation
# ---------------------------------------------------------------------------


def report_to_dict(report: ImpactReport) -> dict:
    """Convert an ImpactReport to a JSON-serializable dict."""
    return asdict(report)
