"""Governance engine — policy profiles, human-in-the-loop gates, and audit logging."""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import threading
from datetime import datetime, timezone
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path

def _get_audit_hmac_key() -> bytes:
    """Return the audit HMAC key, auto-generating if not configured."""
    env_key = os.environ.get("GUARD_AUDIT_HMAC_KEY")
    if env_key:
        return env_key.encode("utf-8")
    # Auto-generate and persist
    key_path = Path(".sentrik") / "local" / "audit_hmac_key"
    if key_path.exists():
        return key_path.read_text(encoding="utf-8").strip().encode("utf-8")
    import secrets as _secrets
    key = _secrets.token_hex(32)
    try:
        key_path.parent.mkdir(parents=True, exist_ok=True)
        key_path.write_text(key, encoding="utf-8")
        try:
            os.chmod(key_path, 0o600)
        except (OSError, AttributeError):
            pass
    except OSError:
        pass
    return key.encode("utf-8")


_AUDIT_HMAC_KEY = _get_audit_hmac_key()
from typing import Any, Literal

from pydantic import BaseModel, Field as PydanticField

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Governance config schema (nested inside GuardConfig)
# ---------------------------------------------------------------------------

VALID_PROFILES = {"strict", "standard", "permissive"}
VALID_SEVERITIES_SET = {"critical", "high", "medium", "low", "info"}


class HumanReviewConfig(BaseModel):
    on_requirement_change: bool = True
    on_critical_finding: bool = True
    on_auto_patch_above: str = "medium"  # severity threshold or "" to disable


class AutoPatchConfig(BaseModel):
    enabled: bool = True
    max_severity: str = "low"


class GateConfig(BaseModel):
    fail_on: list[str] = PydanticField(default_factory=lambda: ["critical", "high"])
    block_merge_on_obligations: bool = False


class SyncConfig(BaseModel):
    auto_close_work_items: bool = True
    require_sign_off: bool = False


class AuditConfig(BaseModel):
    enabled: bool = True
    log_file: str = "out/agent_audit.jsonl"


class GovernanceConfig(BaseModel):
    profile: str = "standard"
    human_review_required: HumanReviewConfig = PydanticField(
        default_factory=HumanReviewConfig,
    )
    auto_patch: AutoPatchConfig = PydanticField(default_factory=AutoPatchConfig)
    gate: GateConfig = PydanticField(default_factory=GateConfig)
    sync: SyncConfig = PydanticField(default_factory=SyncConfig)
    audit: AuditConfig = PydanticField(default_factory=AuditConfig)


# ---------------------------------------------------------------------------
# Profile defaults
# ---------------------------------------------------------------------------

_PROFILE_DEFAULTS: dict[str, dict[str, Any]] = {
    "strict": {
        "human_review_required": {
            "on_requirement_change": True,
            "on_critical_finding": True,
            "on_auto_patch_above": "low",
        },
        "auto_patch": {"enabled": True, "max_severity": "low"},
        "gate": {"fail_on": ["critical", "high", "medium"], "block_merge_on_obligations": True},
        "sync": {"auto_close_work_items": False, "require_sign_off": True},
        "audit": {"enabled": True, "log_file": "out/agent_audit.jsonl"},
    },
    "standard": {
        "human_review_required": {
            "on_requirement_change": True,
            "on_critical_finding": True,
            "on_auto_patch_above": "medium",
        },
        "auto_patch": {"enabled": True, "max_severity": "low"},
        "gate": {"fail_on": ["critical", "high"], "block_merge_on_obligations": False},
        "sync": {"auto_close_work_items": True, "require_sign_off": False},
        "audit": {"enabled": True, "log_file": "out/agent_audit.jsonl"},
    },
    "permissive": {
        "human_review_required": {
            "on_requirement_change": False,
            "on_critical_finding": False,
            "on_auto_patch_above": "",
        },
        "auto_patch": {"enabled": True, "max_severity": "high"},
        "gate": {"fail_on": ["critical"], "block_merge_on_obligations": False},
        "sync": {"auto_close_work_items": True, "require_sign_off": False},
        "audit": {"enabled": True, "log_file": "out/agent_audit.jsonl"},
    },
}


def get_profile_defaults(profile: str) -> dict[str, Any]:
    """Return the default settings for a governance profile."""
    return _PROFILE_DEFAULTS.get(profile, _PROFILE_DEFAULTS["standard"])


def build_governance_config(raw: dict[str, Any] | None) -> GovernanceConfig:
    """Build a GovernanceConfig from raw YAML data, applying profile defaults first."""
    if not raw:
        return GovernanceConfig()

    profile = raw.get("profile", "standard")
    defaults = get_profile_defaults(profile)

    # Merge: profile defaults, then user overrides
    merged: dict[str, Any] = {"profile": profile}
    for key in ("human_review_required", "auto_patch", "gate", "sync", "audit"):
        base = dict(defaults.get(key, {}))
        override = raw.get(key, {})
        if isinstance(override, dict):
            base.update(override)
        merged[key] = base

    return GovernanceConfig(**merged)


# ---------------------------------------------------------------------------
# Policy engine — evaluate governance policies against events
# ---------------------------------------------------------------------------

SEVERITY_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}


@dataclass
class PolicyDecision:
    """Result of a policy evaluation."""
    action: str  # what was attempted
    allowed: bool  # whether the policy allows it
    reason: str  # human-readable explanation
    require_human_review: bool = False  # if True, a human must review


class PolicyEngine:
    """Evaluates governance policies against events."""

    def __init__(self, governance: GovernanceConfig) -> None:
        self.gov = governance

    def check_auto_patch(self, finding_severity: str) -> PolicyDecision:
        """Check if auto-patching is allowed for a finding at the given severity."""
        if not self.gov.auto_patch.enabled:
            return PolicyDecision(
                action="auto_patch",
                allowed=False,
                reason="Auto-patching is disabled by governance policy",
            )

        max_sev = self.gov.auto_patch.max_severity
        if SEVERITY_ORDER.get(finding_severity, 0) > SEVERITY_ORDER.get(max_sev, 0):
            # Check if human review is needed
            threshold = self.gov.human_review_required.on_auto_patch_above
            needs_review = bool(
                threshold
                and SEVERITY_ORDER.get(finding_severity, 0) > SEVERITY_ORDER.get(threshold, 0)
            )
            return PolicyDecision(
                action="auto_patch",
                allowed=False,
                reason=f"Finding severity '{finding_severity}' exceeds auto-patch max '{max_sev}'",
                require_human_review=needs_review,
            )

        return PolicyDecision(
            action="auto_patch",
            allowed=True,
            reason=f"Auto-patch allowed for severity '{finding_severity}'",
        )

    def check_requirement_change(self) -> PolicyDecision:
        """Check if a requirement change requires human review (PR)."""
        if self.gov.human_review_required.on_requirement_change:
            return PolicyDecision(
                action="requirement_change",
                allowed=True,
                reason=(
                    "Work items were created/updated. Governance requires a human-reviewed PR "
                    "before merging. Submit a pull request and assign a reviewer."
                ),
                require_human_review=True,
            )
        return PolicyDecision(
            action="requirement_change",
            allowed=True,
            reason="Requirement changes do not require human review",
            require_human_review=False,
        )

    def check_gate_failure(self, has_critical: bool) -> PolicyDecision:
        """Check if a gate failure with critical findings requires human review."""
        if has_critical and self.gov.human_review_required.on_critical_finding:
            return PolicyDecision(
                action="gate_failure",
                allowed=False,
                reason="Gate failed with critical findings — human review required",
                require_human_review=True,
            )
        return PolicyDecision(
            action="gate_failure",
            allowed=False,
            reason="Gate failed",
            require_human_review=False,
        )

    def check_work_item_close(self) -> PolicyDecision:
        """Check if work item state transitions require sign-off."""
        if self.gov.sync.require_sign_off:
            return PolicyDecision(
                action="work_item_close",
                allowed=True,
                reason="Work item close requires sign-off",
                require_human_review=True,
            )
        return PolicyDecision(
            action="work_item_close",
            allowed=True,
            reason="Work item close allowed without sign-off",
            require_human_review=False,
        )

    def check_merge_with_obligations(self, has_unresolved: bool) -> PolicyDecision:
        """Check if merge is allowed when documentation obligations are unresolved."""
        if has_unresolved and self.gov.gate.block_merge_on_obligations:
            return PolicyDecision(
                action="merge",
                allowed=False,
                reason="Merge blocked — unresolved documentation obligations",
            )
        return PolicyDecision(
            action="merge",
            allowed=True,
            reason="Merge allowed",
        )

    def get_gate_fail_on(self) -> list[str]:
        """Return the list of severities that fail the gate."""
        return self.gov.gate.fail_on


# ---------------------------------------------------------------------------
# Audit log engine
# ---------------------------------------------------------------------------

@dataclass
class AuditEntry:
    """A single entry in the agent action audit log."""
    timestamp: str
    action: str
    actor: str  # "agent", "human", "system"
    details: dict[str, Any] = field(default_factory=dict)
    policy_decision: dict[str, Any] | None = None
    result: str = ""  # "success", "blocked", "requires_review"
    # Identity fields (populated when auth is enabled)
    user_id: str = ""
    email: str = ""
    org_id: str = ""


class AuditLog:
    """Writes audit entries to a JSONL file."""

    def __init__(self, config: AuditConfig) -> None:
        self.enabled = config.enabled
        self.log_path = Path(config.log_file)
        self._write_lock = threading.Lock()

    def log(
        self,
        action: str,
        actor: str = "agent",
        details: dict[str, Any] | None = None,
        decision: PolicyDecision | None = None,
        result: str = "success",
        user_id: str = "",
        email: str = "",
        org_id: str = "",
    ) -> AuditEntry | None:
        """Write an audit entry. Returns the entry or None if disabled."""
        if not self.enabled:
            return None

        entry = AuditEntry(
            timestamp=datetime.now(timezone.utc).isoformat(),
            action=action,
            actor=actor,
            details=details or {},
            policy_decision=asdict(decision) if decision else None,
            result=result,
            user_id=user_id,
            email=email,
            org_id=org_id,
        )

        try:
            self.log_path.parent.mkdir(parents=True, exist_ok=True)
            entry_dict = asdict(entry)
            payload = json.dumps(entry_dict, sort_keys=True)
            signature = hmac.new(_AUDIT_HMAC_KEY, payload.encode("utf-8"), hashlib.sha256).hexdigest()
            signed_entry = {**entry_dict, "_integrity": signature}
            with self._write_lock:
                with open(self.log_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(signed_entry) + "\n")
        except OSError:
            logger.exception("Failed to write audit log entry")

        return entry

    def read(self, limit: int = 100) -> list[dict]:
        """Read the most recent audit entries, verifying integrity signatures."""
        if not self.log_path.exists():
            return []
        entries = []
        try:
            with open(self.log_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    entry = json.loads(line)
                    # Verify integrity if signature present
                    stored_sig = entry.pop("_integrity", None)
                    if stored_sig:
                        payload = json.dumps(entry, sort_keys=True)
                        expected = hmac.new(_AUDIT_HMAC_KEY, payload.encode("utf-8"), hashlib.sha256).hexdigest()
                        entry["_verified"] = hmac.compare_digest(stored_sig, expected)
                    else:
                        entry["_verified"] = False  # Legacy entry without signature
                    entries.append(entry)
        except (json.JSONDecodeError, OSError):
            logger.exception("Failed to read audit log")
        # Return most recent entries
        return entries[-limit:]
