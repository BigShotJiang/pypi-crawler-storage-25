"""CI status reporting — create check-runs (GitHub) or commit statuses (Azure)."""

from __future__ import annotations

import base64
import json
import logging
import os
import urllib.error
import urllib.request

from guard.core.models import GateResult

logger = logging.getLogger(__name__)


class GitHubStatusReporter:
    """Creates GitHub Check Runs via the Checks API."""

    def __init__(self, owner: str, repo: str) -> None:
        self._owner = owner
        self._repo = repo

    def report_status(self, gate_result: GateResult, commit_sha: str) -> bool:
        """Create a check-run on *commit_sha*. Returns True on success."""
        token = os.environ.get("GITHUB_TOKEN", "")
        if not token:
            logger.warning("GITHUB_TOKEN not set — cannot create check-run")
            return False

        conclusion = "success" if gate_result.passed else "failure"
        title = "Guard Gate PASSED" if gate_result.passed else "Guard Gate FAILED"
        summary = (
            f"Findings: {gate_result.total_findings} "
            f"(critical={gate_result.critical}, high={gate_result.high}, "
            f"medium={gate_result.medium}, low={gate_result.low}, "
            f"info={gate_result.info})"
        )

        url = (
            f"https://api.github.com/repos/{self._owner}/{self._repo}/check-runs"
        )
        headers = {
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        payload = {
            "name": "ai-sdlc-guard/gate",
            "head_sha": commit_sha,
            "status": "completed",
            "conclusion": conclusion,
            "output": {"title": title, "summary": summary},
        }
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status in (200, 201)
        except urllib.error.HTTPError as exc:
            logger.error(
                "GitHub check-run error: %s %s", exc.code, exc.reason,
            )
            return False
        except urllib.error.URLError as exc:
            logger.error("Network error creating check-run: %s", exc.reason)
            return False


class AzureStatusReporter:
    """Creates commit statuses via the Azure DevOps Git Status API."""

    def __init__(self, org: str, project: str, repo: str) -> None:
        self._org = org
        self._project = project
        self._repo = repo

    def report_status(self, gate_result: GateResult, commit_sha: str) -> bool:
        """Post a commit status on *commit_sha*. Returns True on success."""
        pat = os.environ.get("AZURE_DEVOPS_PAT", "")
        if not pat:
            logger.warning("AZURE_DEVOPS_PAT not set — cannot create commit status")
            return False

        state = "succeeded" if gate_result.passed else "failed"
        description = (
            f"Guard gate {'passed' if gate_result.passed else 'failed'}: "
            f"{gate_result.total_findings} finding(s)"
        )

        url = (
            f"https://dev.azure.com/{self._org}/{self._project}"
            f"/_apis/git/repositories/{self._repo}"
            f"/commits/{commit_sha}/statuses?api-version=7.1"
        )
        token_bytes = base64.b64encode(f":{pat}".encode("utf-8")).decode("ascii")
        headers = {
            "Authorization": f"Basic {token_bytes}",
            "Content-Type": "application/json",
        }
        payload = {
            "state": state,
            "description": description,
            "context": {
                "name": "ai-sdlc-guard/gate",
                "genre": "continuous-integration",
            },
        }
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status in (200, 201)
        except urllib.error.HTTPError as exc:
            logger.error(
                "Azure commit status error: %s %s", exc.code, exc.reason,
            )
            return False
        except urllib.error.URLError as exc:
            logger.error("Network error creating Azure commit status: %s", exc.reason)
            return False


def _detect_commit_sha() -> str | None:
    """Auto-detect commit SHA from CI environment variables."""
    return os.environ.get("GITHUB_SHA") or os.environ.get("BUILD_SOURCEVERSION") or None


def report_status(
    gate_result: GateResult,
    *,
    owner: str | None = None,
    repo: str | None = None,
    org: str | None = None,
    project: str | None = None,
    azure_repo: str | None = None,
    commit_sha: str | None = None,
) -> bool:
    """Auto-detect CI platform and post a status check.

    Checks for Azure first (via BUILD_SOURCEVERSION), then GitHub.
    Returns True if the status was posted successfully.
    """
    sha = commit_sha or _detect_commit_sha()
    if not sha:
        logger.warning("No commit SHA available — skipping status check")
        return False

    # --- Azure DevOps path ---
    if os.environ.get("BUILD_SOURCEVERSION"):
        org = org or os.environ.get("GUARD_AZURE_DEVOPS_ORG", "")
        project = project or os.environ.get("GUARD_AZURE_DEVOPS_PROJECT", "")
        azure_repo = azure_repo or os.environ.get("BUILD_REPOSITORY_NAME", "") or os.environ.get("GUARD_AZURE_DEVOPS_REPO", "")
        if not org or not project or not azure_repo:
            logger.warning("Azure org/project/repo not configured — skipping status check")
            return False
        reporter = AzureStatusReporter(org, project, azure_repo)
        return reporter.report_status(gate_result, sha)

    # --- GitHub path ---
    owner = owner or os.environ.get("GUARD_GITHUB_OWNER", "")
    repo = repo or os.environ.get("GUARD_GITHUB_REPO", "")
    if not owner or not repo:
        logger.warning("GitHub owner/repo not configured — skipping status check")
        return False
    reporter = GitHubStatusReporter(owner, repo)
    return reporter.report_status(gate_result, sha)
