"""PR decoration — post findings summary as a PR comment."""

from __future__ import annotations

import base64
import json
import logging
import os
import urllib.error
import urllib.request
from typing import Any

from guard.core.models import Finding, GateResult

logger = logging.getLogger(__name__)

_BADGE_PASS = "\u2705"  # green check
_BADGE_FAIL = "\u274C"  # red cross


def _build_compliance_summary(findings: list[Finding]) -> list[str]:
    """Build a per-framework compliance summary table from findings."""
    # Group findings by standard/framework
    frameworks: dict[str, dict[str, int]] = {}
    all_rules_by_fw: dict[str, set[str]] = {}
    for f in findings:
        fw = f.standard or "Custom"
        if f.is_obligation:
            continue
        if fw not in frameworks:
            frameworks[fw] = {"total": 0, "passed": 0}
            all_rules_by_fw[fw] = set()
        all_rules_by_fw[fw].add(f.rule_id)
        frameworks[fw]["total"] += 1

    if not frameworks:
        return []

    lines = [
        "### Compliance Summary",
        "",
        "| Framework | Findings | Rules Triggered |",
        "|-----------|:--------:|:---------------:|",
    ]
    for fw in sorted(frameworks.keys()):
        count = frameworks[fw]["total"]
        rules = len(all_rules_by_fw.get(fw, set()))
        lines.append(f"| {fw} | {count} | {rules} |")
    lines.append("")
    return lines


def format_findings_comment(findings: list[Finding], gate_result: GateResult) -> str:
    """Build a Markdown comment summarising findings and gate result."""
    badge = _BADGE_PASS if gate_result.passed else _BADGE_FAIL
    status = "PASSED" if gate_result.passed else "FAILED"
    blocking = gate_result.critical + gate_result.high
    lines: list[str] = [
        f"## {badge} Sentrik Gate {status}",
        "",
        f"**{gate_result.total_findings}** findings · **{blocking}** blocking"
        + (" · all clear" if gate_result.passed else ""),
        "",
        "| Severity | Count |",
        "|----------|:-----:|",
        f"| Critical | {gate_result.critical} |",
        f"| High | {gate_result.high} |",
        f"| Medium | {gate_result.medium} |",
        f"| Low | {gate_result.low} |",
        f"| Info | {gate_result.info} |",
        "",
    ]

    # Compliance framework breakdown
    lines.extend(_build_compliance_summary(findings))

    if findings:
        top = [f for f in findings if not f.is_obligation][:10]
        if top:
            lines.append("### Top Findings")
            lines.append("")
            for f in top:
                lines.append(
                    f"- **[{f.severity.value.upper()}]** `{f.rule_id}` — {f.message} "
                    f"(`{f.evidence.file}`)"
                )
            non_obligation = [f for f in findings if not f.is_obligation]
            if len(non_obligation) > 10:
                lines.append(f"- ... and {len(non_obligation) - 10} more")
            lines.append("")

    lines.append("---")
    lines.append("*Posted by [SENTRIK](https://sentrik.dev)*")
    return "\n".join(lines)


class GitHubPRDecorator:
    """Posts PR comments via the GitHub API."""

    def __init__(self, owner: str, repo: str) -> None:
        self._owner = owner
        self._repo = repo

    def post_comment(self, body: str, pr_number: int) -> bool:
        """Post a comment on a GitHub pull request. Returns True on success."""
        token = os.environ.get("GITHUB_TOKEN", "")
        if not token:
            logger.warning("GITHUB_TOKEN not set — cannot post PR comment")
            return False

        url = (
            f"https://api.github.com/repos/{self._owner}/{self._repo}"
            f"/issues/{pr_number}/comments"
        )
        headers = {
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        data = json.dumps({"body": body}).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status in (200, 201)
        except urllib.error.HTTPError as exc:
            logger.error(
                "GitHub PR comment error: %s %s for PR #%s",
                exc.code, exc.reason, pr_number,
            )
            return False
        except urllib.error.URLError as exc:
            logger.error("Network error posting PR comment: %s", exc.reason)
            return False


class AzurePRDecorator:
    """Posts PR thread comments via the Azure DevOps API."""

    def __init__(self, org: str, project: str, repo: str) -> None:
        self._org = org
        self._project = project
        self._repo = repo

    def post_comment(self, body: str, pr_id: int) -> bool:
        """Post a comment thread on an Azure DevOps pull request. Returns True on success."""
        pat = os.environ.get("AZURE_DEVOPS_PAT", "")
        if not pat:
            logger.warning("AZURE_DEVOPS_PAT not set — cannot post PR comment")
            return False

        url = (
            f"https://dev.azure.com/{self._org}/{self._project}"
            f"/_apis/git/repositories/{self._repo}"
            f"/pullrequests/{pr_id}/threads?api-version=7.1"
        )
        token_bytes = base64.b64encode(f":{pat}".encode("utf-8")).decode("ascii")
        headers = {
            "Authorization": f"Basic {token_bytes}",
            "Content-Type": "application/json",
        }
        payload = {
            "comments": [{"content": body, "commentType": 1}],
            "status": 1,
        }
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status in (200, 201)
        except urllib.error.HTTPError as exc:
            logger.error(
                "Azure PR comment error: %s %s for PR #%s",
                exc.code, exc.reason, pr_id,
            )
            return False
        except urllib.error.URLError as exc:
            logger.error("Network error posting Azure PR comment: %s", exc.reason)
            return False


def _detect_azure_pr_id() -> int | None:
    """Auto-detect PR ID from SYSTEM_PULLREQUEST_PULLREQUESTID (set by Azure Pipelines)."""
    raw = os.environ.get("SYSTEM_PULLREQUEST_PULLREQUESTID")
    if not raw:
        return None
    try:
        return int(raw)
    except (ValueError, TypeError):
        return None


def _detect_azure_repo() -> str | None:
    """Auto-detect repo name from BUILD_REPOSITORY_NAME (set by Azure Pipelines)."""
    return os.environ.get("BUILD_REPOSITORY_NAME") or None


def _detect_github_pr_number() -> int | None:
    """Auto-detect PR number from GITHUB_EVENT_PATH (set in GitHub Actions)."""
    event_path = os.environ.get("GITHUB_EVENT_PATH")
    if not event_path:
        return None
    try:
        with open(event_path) as fh:
            event = json.load(fh)
        pr = event.get("pull_request") or event.get("issue") or {}
        number = pr.get("number")
        return int(number) if number is not None else None
    except (OSError, ValueError, json.JSONDecodeError, TypeError):
        logger.debug("Could not read PR number from GITHUB_EVENT_PATH")
        return None


def decorate_pr(
    findings: list[Finding],
    gate_result: GateResult,
    *,
    owner: str | None = None,
    repo: str | None = None,
    pr_number: int | None = None,
    org: str | None = None,
    project: str | None = None,
) -> bool:
    """Auto-detect platform and post a findings summary comment on the PR.

    Checks for Azure Pipelines first (via SYSTEM_PULLREQUEST_PULLREQUESTID),
    then falls through to GitHub.  Returns True if the comment was posted.
    """
    comment = format_findings_comment(findings, gate_result)

    # --- Azure DevOps path ---
    azure_pr_id = _detect_azure_pr_id()
    if azure_pr_id is not None:
        org = org or os.environ.get("GUARD_AZURE_DEVOPS_ORG", "")
        project = project or os.environ.get("GUARD_AZURE_DEVOPS_PROJECT", "")
        if not org or not project:
            logger.warning("Azure org/project not configured — skipping PR decoration")
            return False
        azure_repo = _detect_azure_repo() or os.environ.get("GUARD_AZURE_DEVOPS_REPO", "")
        if not azure_repo:
            logger.warning("Azure repo not configured — skipping PR decoration")
            return False
        decorator = AzurePRDecorator(org, project, azure_repo)
        return decorator.post_comment(comment, azure_pr_id)

    # --- GitHub path ---
    owner = owner or os.environ.get("GUARD_GITHUB_OWNER", "")
    repo = repo or os.environ.get("GUARD_GITHUB_REPO", "")
    if not owner or not repo:
        logger.warning("GitHub owner/repo not configured — skipping PR decoration")
        return False

    if pr_number is None:
        pr_number = _detect_github_pr_number()
    if pr_number is None:
        logger.warning("Could not determine PR number — skipping PR decoration")
        return False

    gh_decorator = GitHubPRDecorator(owner, repo)
    return gh_decorator.post_comment(comment, pr_number)
