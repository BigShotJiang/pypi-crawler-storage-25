"""Pull requirements from DevOps providers into requirements.yaml."""

from __future__ import annotations

import re
from pathlib import Path

from guard.core.models import GeneratedRequirement, WorkItem
from guard.core.requirements_generator import write_requirements_yaml
from guard.providers.devops_base import DevOpsProvider


def _provider_prefix(provider: str) -> str:
    """Return the ID prefix for a DevOps provider."""
    prefixes = {
        "azure": "ADO",
        "github": "GH",
        "jira": "JIRA",
        "stub": "STUB",
    }
    return prefixes.get(provider, provider.upper())


def convert_work_items_to_requirements(
    work_items: list[WorkItem],
    provider: str,
) -> list[GeneratedRequirement]:
    """Convert a list of WorkItem objects to GeneratedRequirement objects.

    Each work item gets a req_id based on the provider prefix and the
    work item's DevOps ID (e.g. ADO-123, GH-45, JIRA-PRJ-67).
    """
    prefix = _provider_prefix(provider)
    results: list[GeneratedRequirement] = []

    for wi in work_items:
        # Build req_id from provider prefix + devops/work-item ID
        devops_id = wi.devops_id if wi.devops_id is not None else wi.id
        req_id = f"{prefix}-{devops_id}"

        results.append(GeneratedRequirement(
            req_id=req_id,
            title=wi.title,
            description=wi.description or "",
            acceptance_criteria=wi.acceptance_criteria or [],
            source_files=[],
            status="draft",
            devops_id=wi.devops_id,
        ))

    return results


def auto_map_files(
    requirements: list[GeneratedRequirement],
    source_files: list[str],
    min_token_length: int = 3,
) -> list[GeneratedRequirement]:
    """Auto-map source files to requirements by matching title tokens to filenames.

    For each requirement title, tokenize it (split on spaces/punctuation, lowercase).
    For each source file, check if any meaningful title tokens match the filename stem
    (without extension). This is best-effort -- users should review and adjust.
    """
    # Pre-compute filename stems for all source files
    file_stems: dict[str, set[str]] = {}
    for fp in source_files:
        stem = Path(fp).stem.lower()
        # Split stem on common separators
        tokens = set(re.split(r"[_\-.]", stem))
        tokens = {t for t in tokens if len(t) >= min_token_length}
        if tokens:
            file_stems[fp] = tokens

    updated: list[GeneratedRequirement] = []
    for req in requirements:
        # Tokenize the title
        title_tokens = set(re.split(r"[\s_\-/.,;:!?()]+", req.title.lower()))
        title_tokens = {t for t in title_tokens if len(t) >= min_token_length}

        if not title_tokens:
            updated.append(req)
            continue

        matched_files: list[str] = []
        for fp, stem_tokens in file_stems.items():
            # Match if any title token matches a filename token
            if title_tokens & stem_tokens:
                matched_files.append(fp)

        if matched_files:
            updated.append(req.model_copy(update={"source_files": sorted(matched_files)}))
        else:
            updated.append(req)

    return updated


def merge_requirements(
    existing: list[GeneratedRequirement],
    incoming: list[GeneratedRequirement],
) -> list[GeneratedRequirement]:
    """Merge incoming requirements with existing ones.

    - New items (by devops_id or req_id) are added.
    - Existing items get title/description updated if changed in DevOps,
      but source_files and other manual edits are preserved.
    """
    # Index existing by devops_id and req_id
    by_devops_id: dict[str, int] = {}
    by_req_id: dict[str, int] = {}
    merged = list(existing)

    for idx, req in enumerate(merged):
        if req.devops_id is not None:
            by_devops_id[str(req.devops_id)] = idx
        by_req_id[req.req_id] = idx

    for inc in incoming:
        # Find existing entry by devops_id first, then req_id
        existing_idx = None
        if inc.devops_id is not None:
            existing_idx = by_devops_id.get(str(inc.devops_id))
        if existing_idx is None:
            existing_idx = by_req_id.get(inc.req_id)

        if existing_idx is not None:
            # Update title and description, preserve everything else
            old = merged[existing_idx]
            merged[existing_idx] = old.model_copy(update={
                "title": inc.title,
                "description": inc.description,
                "acceptance_criteria": inc.acceptance_criteria or old.acceptance_criteria,
            })
        else:
            # New requirement
            merged.append(inc)
            if inc.devops_id is not None:
                by_devops_id[str(inc.devops_id)] = len(merged) - 1
            by_req_id[inc.req_id] = len(merged) - 1

    return merged


def pull_requirements(
    devops: DevOpsProvider,
    provider: str,
    output_path: Path,
    merge: bool = False,
    map_files: bool = False,
    source_files: list[str] | None = None,
) -> list[GeneratedRequirement]:
    """Pull requirements from a DevOps provider and write to YAML.

    Args:
        devops: The DevOps provider instance.
        provider: Provider name (azure, github, jira, stub).
        output_path: Path to write requirements.yaml.
        merge: If True, merge with existing file instead of overwriting.
        map_files: If True, auto-map source files by matching titles.
        source_files: List of source files in the repo (needed for map_files).

    Returns:
        List of pulled requirements.
    """
    import yaml

    work_items = devops.get_work_items()
    if not work_items:
        return []

    reqs = convert_work_items_to_requirements(work_items, provider)

    if map_files and source_files:
        reqs = auto_map_files(reqs, source_files)

    if merge and output_path.exists():
        # Load existing requirements
        existing: list[GeneratedRequirement] = []
        try:
            with open(output_path, encoding="utf-8") as f:
                loaded = yaml.safe_load(f)
            entries = []
            if isinstance(loaded, dict) and "requirements" in loaded:
                entries = loaded["requirements"]
            elif isinstance(loaded, list):
                entries = loaded
            for entry in entries:
                if isinstance(entry, dict):
                    existing.append(GeneratedRequirement(**entry))
        except (yaml.YAMLError, OSError, ValueError):
            pass

        reqs = merge_requirements(existing, reqs)

    write_requirements_yaml(reqs, output_path)
    return reqs
