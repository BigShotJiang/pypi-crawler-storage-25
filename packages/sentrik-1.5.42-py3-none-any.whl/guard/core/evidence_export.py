"""Evidence export generator for compliance audit packages.

Collects evidence from scan findings, audit logs, and scan metrics,
maps them to specific compliance framework controls, and produces
structured JSON packages and standalone HTML reports for auditors.
"""

from __future__ import annotations

import json
import re
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from html import escape
from pathlib import Path

from guard import __version__
from guard.core.models import Finding, Severity

# ── Data model ────────────────────────────────────────────────────────


@dataclass
class EvidenceItem:
    control_id: str  # e.g. "CC6.1"
    control_name: str
    framework: str  # e.g. "SOC2"
    evidence_type: str  # "scan_result" | "gate_pass" | "approval" | "audit_entry"
    timestamp: str
    summary: str
    details: dict = field(default_factory=dict)
    status: str = "pass"  # "pass" | "fail" | "partial"


# ── Framework control mappings ────────────────────────────────────────

_SOC2_CONTROLS: dict[str, str] = {
    "CC6.1": "Logical Access Controls",
    "CC6.6": "System Boundary Protection",
    "CC7.1": "Monitoring Activities",
    "CC7.2": "Anomaly Detection",
    "CC8.1": "Change Management",
}

_IEC62304_CONTROLS: dict[str, str] = {
    "5.1": "Software Development Planning",
    "5.5": "Software Detailed Design and Unit Implementation",
    "5.7": "Software Verification",
}

_HIPAA_CONTROLS: dict[str, str] = {
    "164.308": "Administrative Safeguards",
    "164.310": "Physical Safeguards",
    "164.312": "Technical Safeguards",
}

_OWASP_CONTROLS: dict[str, str] = {
    "A01": "Broken Access Control",
    "A02": "Cryptographic Failures",
    "A03": "Injection",
    "A04": "Insecure Design",
    "A05": "Security Misconfiguration",
    "A06": "Vulnerable and Outdated Components",
    "A07": "Identification and Authentication Failures",
    "A08": "Software and Data Integrity Failures",
    "A09": "Security Logging and Monitoring Failures",
    "A10": "Server-Side Request Forgery",
}

_FRAMEWORK_CONTROLS: dict[str, dict[str, str]] = {
    "soc2": _SOC2_CONTROLS,
    "soc 2": _SOC2_CONTROLS,
    "iec 62304": _IEC62304_CONTROLS,
    "iec62304": _IEC62304_CONTROLS,
    "fda iec 62304": _IEC62304_CONTROLS,
    "fda iec62304": _IEC62304_CONTROLS,
    "hipaa": _HIPAA_CONTROLS,
    "hipaa security rule": _HIPAA_CONTROLS,
    "owasp": _OWASP_CONTROLS,
    "owasp top 10": _OWASP_CONTROLS,
    "owasp top 10 2021": _OWASP_CONTROLS,
}

# Rule ID prefix → OWASP control mapping
_OWASP_RULE_MAP: dict[str, str] = {
    "access": "A01",
    "auth": "A01",
    "crypto": "A02",
    "hash": "A02",
    "md5": "A02",
    "sha1": "A02",
    "inject": "A03",
    "sql": "A03",
    "xss": "A03",
    "eval": "A03",
    "exec": "A03",
    "deserializ": "A08",
    "log": "A09",
    "ssrf": "A10",
}

AVAILABLE_FRAMEWORKS = ["SOC2", "IEC 62304", "HIPAA", "OWASP"]

# ── Severity helpers ──────────────────────────────────────────────────

_SEV_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}


def _worst_severity(findings: list[Finding]) -> str | None:
    if not findings:
        return None
    return min(findings, key=lambda f: _SEV_ORDER.get(f.severity.value, 5)).severity.value


def _control_status(findings: list[Finding]) -> str:
    """Determine control status from associated findings."""
    if not findings:
        return "pass"
    worst = _worst_severity(findings)
    if worst in ("critical", "high"):
        return "fail"
    return "partial"


# ── Clause-to-control mapping ────────────────────────────────────────


def _normalize_framework(name: str) -> str:
    return name.strip().lower()


def _clause_matches_control(clause: str, control_id: str) -> bool:
    """Check if a finding clause maps to a framework control."""
    clause_lower = clause.lower().strip()
    control_lower = control_id.lower().strip()
    # Exact match
    if clause_lower == control_lower:
        return True
    # Clause starts with control (e.g. "5.1.1" matches "5.1")
    if clause_lower.startswith(control_lower + ".") or clause_lower.startswith(control_lower):
        # Make sure "5.1" matches "5.1.x" but not "5.10"
        rest = clause_lower[len(control_lower):]
        if rest == "" or rest.startswith("."):
            return True
    # Section reference (e.g. "§164.312" matches "164.312")
    stripped = clause_lower.lstrip("§").strip()
    if stripped == control_lower or stripped.startswith(control_lower + "."):
        return True
    return False


def _map_owasp_rule(rule_id: str) -> str | None:
    """Map a rule ID to an OWASP control based on keywords."""
    rule_lower = rule_id.lower()
    for keyword, control in _OWASP_RULE_MAP.items():
        if keyword in rule_lower:
            return control
    return None


# ── Core collection functions ─────────────────────────────────────────


def collect_evidence(output_dir: str, framework: str) -> list[EvidenceItem]:
    """Gather evidence items from scan outputs for a given framework.

    Reads findings.json, agent_audit.jsonl, and scan_metrics.json from
    the output directory and maps them to framework controls.

    In addition to negative evidence (findings), this also collects
    **positive evidence** from rules that produced zero findings,
    proving what was checked and passed.
    """
    out = Path(output_dir)
    findings = _load_findings(out / "findings.json")
    audit_entries = _load_audit_log(out / "agent_audit.jsonl")
    metrics = _load_metrics(out / "scan_metrics.json")

    return map_to_controls(framework, findings, audit_entries, metrics)


def _load_findings(path: Path) -> list[Finding]:
    if not path.exists():
        return []
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        return [Finding.model_validate(f) for f in raw]
    except (json.JSONDecodeError, OSError, ValueError):
        return []


def _load_audit_log(path: Path) -> list[dict]:
    if not path.exists():
        return []
    entries = []
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
    except OSError:
        pass
    return entries


def _load_metrics(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def map_to_controls(
    framework: str,
    findings: list[Finding],
    audit_entries: list[dict],
    metrics: dict | None = None,
) -> list[EvidenceItem]:
    """Map findings and audit entries to framework controls.

    Returns a list of EvidenceItem objects grouped by control.
    Includes positive evidence from rules that produced zero findings.
    """
    fw_norm = _normalize_framework(framework)
    controls = _FRAMEWORK_CONTROLS.get(fw_norm)

    if controls:
        return _map_known_framework(framework, controls, findings, audit_entries, metrics or {})
    else:
        return _map_generic_framework(framework, findings, audit_entries, metrics or {})


def _collect_positive_evidence(
    metrics: dict,
    findings: list[Finding],
    framework: str,
    now: str,
) -> list[EvidenceItem]:
    """Build positive evidence items for rules that produced zero findings.

    Uses ``rule_metrics`` from scan_metrics.json to identify rules that
    were evaluated but generated no findings — proof of compliance.
    """
    items: list[EvidenceItem] = []
    rule_metrics_list = metrics.get("rule_metrics", [])
    if not rule_metrics_list:
        return items

    # Set of rule_ids that have findings (negative evidence)
    finding_rule_ids = {f.rule_id for f in findings}

    for rm in rule_metrics_list:
        rule_id = rm.get("rule_id", "")
        rule_type = rm.get("rule_type", "")
        files_evaluated = rm.get("files_evaluated", 0)
        findings_count = rm.get("findings_count", 0)

        if findings_count > 0 or rule_id in finding_rule_ids:
            continue  # Skip rules that produced findings

        if rule_type == "required_pattern":
            summary = f"Required pattern found in {files_evaluated} file(s) — rule {rule_id} satisfied"
        else:
            summary = f"Rule {rule_id} checked across {files_evaluated} file(s) — no violations found"

        items.append(EvidenceItem(
            control_id="",  # Will be mapped to a control later or stay generic
            control_name="",
            framework=framework,
            evidence_type="rule_passed",
            timestamp=now,
            summary=summary,
            details={
                "rule_id": rule_id,
                "rule_type": rule_type,
                "files_scanned": files_evaluated,
            },
            status="pass",
        ))

    return items


def _map_known_framework(
    framework: str,
    controls: dict[str, str],
    findings: list[Finding],
    audit_entries: list[dict],
    metrics: dict,
) -> list[EvidenceItem]:
    """Map to a well-known framework with predefined controls."""
    items: list[EvidenceItem] = []
    fw_norm = _normalize_framework(framework)
    is_owasp = fw_norm in ("owasp", "owasp top 10")

    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    for control_id, control_name in controls.items():
        # Find matching findings
        matched_findings: list[Finding] = []
        for f in findings:
            if is_owasp:
                mapped = _map_owasp_rule(f.rule_id)
                if mapped and mapped.upper() == control_id.upper():
                    matched_findings.append(f)
            elif f.clause and _clause_matches_control(f.clause, control_id):
                matched_findings.append(f)
            elif f.standard and _normalize_framework(f.standard) == fw_norm and f.clause and _clause_matches_control(f.clause, control_id):
                matched_findings.append(f)

        # Add scan result evidence
        status = _control_status(matched_findings)
        if matched_findings:
            for finding in matched_findings:
                items.append(EvidenceItem(
                    control_id=control_id,
                    control_name=control_name,
                    framework=framework,
                    evidence_type="scan_result",
                    timestamp=now,
                    summary=f"Finding: {finding.message[:100]}",
                    details={
                        "rule_id": finding.rule_id,
                        "severity": finding.severity.value,
                        "file": finding.evidence.file,
                        "lines": finding.evidence.lines,
                        "message": finding.message,
                    },
                    status=status,
                ))
        else:
            # No findings = pass
            items.append(EvidenceItem(
                control_id=control_id,
                control_name=control_name,
                framework=framework,
                evidence_type="scan_result",
                timestamp=now,
                summary="No findings — control requirements satisfied",
                details={},
                status="pass",
            ))

        # Map audit entries to controls
        for entry in audit_entries:
            action = entry.get("action", "")
            if action in ("gate_pass", "gate_fail"):
                items.append(EvidenceItem(
                    control_id=control_id,
                    control_name=control_name,
                    framework=framework,
                    evidence_type="gate_pass" if action == "gate_pass" else "audit_entry",
                    timestamp=entry.get("timestamp", now),
                    summary=f"Gate {'passed' if action == 'gate_pass' else 'failed'}",
                    details=entry,
                    status="pass" if action == "gate_pass" else "fail",
                ))
            elif action in ("approval_granted", "approval_requested"):
                items.append(EvidenceItem(
                    control_id=control_id,
                    control_name=control_name,
                    framework=framework,
                    evidence_type="approval",
                    timestamp=entry.get("timestamp", now),
                    summary=f"Approval {action.replace('approval_', '')}",
                    details=entry,
                    status="pass" if action == "approval_granted" else "partial",
                ))

    # Collect positive evidence from rules with zero findings
    positive_items = _collect_positive_evidence(metrics, findings, framework, now)
    for pos_item in positive_items:
        rule_id = pos_item.details.get("rule_id", "")
        mapped_to_control = False

        if is_owasp:
            owasp_ctrl = _map_owasp_rule(rule_id)
            if owasp_ctrl and owasp_ctrl.upper() in {cid.upper() for cid in controls}:
                # Find the canonical control_id casing
                for cid, cname in controls.items():
                    if cid.upper() == owasp_ctrl.upper():
                        pos_item.control_id = cid
                        pos_item.control_name = cname
                        items.append(pos_item)
                        mapped_to_control = True
                        break

        if not mapped_to_control:
            # Add as generic positive evidence under a RULES_PASSED control
            pos_item.control_id = "RULES_PASSED"
            pos_item.control_name = "Passing Rules"
            items.append(pos_item)

    # Add scan metadata evidence if metrics available
    if metrics:
        items.append(EvidenceItem(
            control_id="META",
            control_name="Scan Metadata",
            framework=framework,
            evidence_type="audit_entry",
            timestamp=metrics.get("timestamp", now),
            summary=f"Scan completed: {metrics.get('files_scanned', '?')} files in {metrics.get('total_duration_ms', '?')}ms",
            details=metrics,
            status="pass",
        ))

    return items


def _map_generic_framework(
    framework: str,
    findings: list[Finding],
    audit_entries: list[dict],
    metrics: dict,
) -> list[EvidenceItem]:
    """Map by standard + clause from findings (generic fallback)."""
    items: list[EvidenceItem] = []
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    # Group findings by clause
    by_clause: dict[str, list[Finding]] = defaultdict(list)
    for f in findings:
        if f.standard and _normalize_framework(f.standard) == _normalize_framework(framework):
            key = f.clause or "Uncategorized"
            by_clause[key].append(f)

    for clause, clause_findings in sorted(by_clause.items()):
        status = _control_status(clause_findings)
        for finding in clause_findings:
            items.append(EvidenceItem(
                control_id=clause,
                control_name=f"{framework} — {clause}",
                framework=framework,
                evidence_type="scan_result",
                timestamp=now,
                summary=f"Finding: {finding.message[:100]}",
                details={
                    "rule_id": finding.rule_id,
                    "severity": finding.severity.value,
                    "file": finding.evidence.file,
                    "lines": finding.evidence.lines,
                    "message": finding.message,
                },
                status=status,
            ))

    # Audit entries as generic evidence
    for entry in audit_entries:
        action = entry.get("action", "")
        if action in ("gate_pass", "gate_fail"):
            items.append(EvidenceItem(
                control_id="GATE",
                control_name="Gate Execution",
                framework=framework,
                evidence_type="gate_pass" if action == "gate_pass" else "audit_entry",
                timestamp=entry.get("timestamp", now),
                summary=f"Gate {'passed' if action == 'gate_pass' else 'failed'}",
                details=entry,
                status="pass" if action == "gate_pass" else "fail",
            ))

    # Collect positive evidence from rules with zero findings
    positive_items = _collect_positive_evidence(metrics, findings, framework, now)
    for pos_item in positive_items:
        pos_item.control_id = "RULES_PASSED"
        pos_item.control_name = "Passing Rules"
        items.append(pos_item)

    if metrics:
        items.append(EvidenceItem(
            control_id="META",
            control_name="Scan Metadata",
            framework=framework,
            evidence_type="audit_entry",
            timestamp=metrics.get("timestamp", now),
            summary=f"Scan completed: {metrics.get('files_scanned', '?')} files",
            details=metrics,
            status="pass",
        ))

    return items


# ── Package generation ────────────────────────────────────────────────


def generate_evidence_package(
    evidence_items: list[EvidenceItem],
    *,
    framework: str,
    project_name: str = "Project",
) -> dict:
    """Produce a structured JSON evidence package.

    Returns a dict with:
      - generated_at, framework, project_name, sentrik_version
      - summary: total controls, controls_passing, controls_with_findings,
        rules_checked, rules_passing, positive_evidence_count
      - controls[]: each control with evidence items, status, finding count
    """
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    # Group by control_id
    by_control: dict[str, list[EvidenceItem]] = defaultdict(list)
    for item in evidence_items:
        by_control[item.control_id].append(item)

    controls: list[dict] = []
    controls_passing = 0
    controls_with_findings = 0

    for control_id in sorted(by_control):
        items = by_control[control_id]
        control_name = items[0].control_name

        # Determine overall control status — consider both scan_result and rule_passed
        scan_items = [i for i in items if i.evidence_type in ("scan_result", "rule_passed")]
        statuses = {i.status for i in scan_items} if scan_items else {i.status for i in items}

        if "fail" in statuses:
            overall = "fail"
            controls_with_findings += 1
        elif "partial" in statuses:
            overall = "partial"
            controls_with_findings += 1
        else:
            overall = "pass"
            controls_passing += 1

        finding_count = sum(
            1 for i in items
            if i.evidence_type == "scan_result" and i.details.get("rule_id")
        )

        controls.append({
            "control_id": control_id,
            "control_name": control_name,
            "status": overall,
            "finding_count": finding_count,
            "evidence": [asdict(i) for i in items],
        })

    total_controls = len(by_control)

    # Count positive evidence (rules that passed)
    positive_evidence_count = sum(
        1 for i in evidence_items if i.evidence_type == "rule_passed"
    )
    # Rules checked = rules with findings + rules without findings
    rules_with_findings = len({
        i.details.get("rule_id") for i in evidence_items
        if i.evidence_type == "scan_result" and i.details.get("rule_id")
    })
    rules_checked = rules_with_findings + positive_evidence_count
    rules_passing = positive_evidence_count

    return {
        "generated_at": now,
        "framework": framework,
        "project_name": project_name,
        "sentrik_version": __version__,
        "summary": {
            "total_controls": total_controls,
            "controls_passing": controls_passing,
            "controls_with_findings": controls_with_findings,
            "rules_checked": rules_checked,
            "rules_passing": rules_passing,
            "positive_evidence_count": positive_evidence_count,
        },
        "controls": controls,
    }


# ── HTML report generation ────────────────────────────────────────────

_SEVERITY_COLORS: dict[str, str] = {
    "critical": "#d32f2f",
    "high": "#f57c00",
    "medium": "#fbc02d",
    "low": "#1976d2",
    "info": "#757575",
}

_STATUS_BADGE: dict[str, tuple[str, str]] = {
    "pass": ("#4caf50", "PASS"),
    "fail": ("#d32f2f", "FAIL"),
    "partial": ("#fbc02d", "PARTIAL"),
}


def generate_evidence_html(package: dict) -> str:
    """Generate a standalone HTML evidence report from a package dict."""
    framework = escape(package.get("framework", "Unknown"))
    project = escape(package.get("project_name", "Project"))
    version = escape(package.get("sentrik_version", __version__))
    generated = escape(package.get("generated_at", "")[:19].replace("T", " "))
    summary = package.get("summary", {})
    controls = package.get("controls", [])

    total = summary.get("total_controls", 0)
    passing = summary.get("controls_passing", 0)
    with_findings = summary.get("controls_with_findings", 0)
    rules_checked = summary.get("rules_checked", 0)
    rules_passing = summary.get("rules_passing", 0)
    rules_failing = rules_checked - rules_passing

    # Build summary bar
    rules_summary = ""
    if rules_checked > 0:
        rules_summary = f"""
        <div class="summary-card">
            <div class="num">{rules_checked}</div>
            <div class="label">Rules Checked</div>
        </div>
        <div class="summary-card">
            <div class="num" style="color:#4caf50">{rules_passing}</div>
            <div class="label">Rules Passing</div>
        </div>
        <div class="summary-card">
            <div class="num" style="color:#d32f2f">{rules_failing}</div>
            <div class="label">Rules Failing</div>
        </div>
        """

    summary_html = f"""
    <div class="summary-bar">
        <div class="summary-card">
            <div class="num">{total}</div>
            <div class="label">Controls Evaluated</div>
        </div>
        <div class="summary-card">
            <div class="num" style="color:#4caf50">{passing}</div>
            <div class="label">Controls Passing</div>
        </div>
        <div class="summary-card">
            <div class="num" style="color:#d32f2f">{with_findings}</div>
            <div class="label">Controls with Findings</div>
        </div>
        {rules_summary}
    </div>
    """
    if rules_checked > 0:
        summary_html += f"""
    <div class="rules-summary">
        {rules_checked} rules checked, {rules_passing} passing, {rules_failing} failing
    </div>
        """

    # Build control sections
    controls_html = ""
    for ctrl in controls:
        ctrl_id = escape(ctrl.get("control_id", ""))
        ctrl_name = escape(ctrl.get("control_name", ""))
        ctrl_status = ctrl.get("status", "pass")
        badge_color, badge_text = _STATUS_BADGE.get(ctrl_status, ("#757575", "UNKNOWN"))
        finding_count = ctrl.get("finding_count", 0)

        passing_rule_count = sum(
            1 for ev in ctrl.get("evidence", [])
            if ev.get("evidence_type") == "rule_passed"
        )

        evidence_rows = ""
        for ev in ctrl.get("evidence", []):
            ev_type = escape(ev.get("evidence_type", ""))
            ev_ts = escape(ev.get("timestamp", "")[:19].replace("T", " "))
            ev_summary = escape(ev.get("summary", ""))
            ev_status = ev.get("status", "pass")
            ev_badge_color, ev_badge_text = _STATUS_BADGE.get(ev_status, ("#757575", "?"))

            details = ev.get("details", {})
            detail_html = ""
            ev_type_raw = ev.get("evidence_type", "")
            if ev_type_raw == "rule_passed":
                # Positive evidence — green checkmark
                rule_id_val = escape(details.get("rule_id", ""))
                files_scanned = details.get("files_scanned", 0)
                detail_html = (
                    f'<div class="ev-details">'
                    f'<span class="status-icon pass-icon">&#10003;</span> '
                    f'<code>{rule_id_val}</code> '
                    f'<span class="ev-file">{files_scanned} file(s) checked</span>'
                    f'</div>'
                )
            elif details.get("rule_id"):
                sev = details.get("severity", "")
                sev_color = _SEVERITY_COLORS.get(sev, "#757575")
                file_info = escape(details.get("file", ""))
                if details.get("lines"):
                    file_info += f":{details['lines'][0]}"
                detail_html = (
                    f'<div class="ev-details">'
                    f'<span class="status-icon fail-icon">&#10007;</span> '
                    f'<code>{escape(details.get("rule_id", ""))}</code> '
                    f'<span style="color:{sev_color};font-weight:600">{sev.upper()}</span> '
                    f'<span class="ev-file">{file_info}</span>'
                    f'</div>'
                )

            evidence_rows += f"""
            <tr>
                <td><span class="ev-type">{ev_type}</span></td>
                <td>{ev_ts}</td>
                <td>{ev_summary}{detail_html}</td>
                <td><span class="status-badge" style="background:{ev_badge_color}">{ev_badge_text}</span></td>
            </tr>
            """

        controls_html += f"""
        <div class="control-section">
            <div class="control-header">
                <div>
                    <span class="control-id">{ctrl_id}</span>
                    <span class="control-name">{ctrl_name}</span>
                </div>
                <span class="status-badge" style="background:{badge_color}">{badge_text}</span>
            </div>
            <div class="control-meta">
                {finding_count} finding(s){f', {passing_rule_count} rule(s) passing' if passing_rule_count else ''}
            </div>
            <table class="evidence-table">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Timestamp</th>
                        <th>Evidence</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {evidence_rows}
                </tbody>
            </table>
        </div>
        """

    return _HTML_TEMPLATE.format(
        framework=framework,
        project=project,
        version=version,
        generated=generated,
        summary_html=summary_html,
        controls_html=controls_html,
        total=total,
        passing=passing,
        with_findings=with_findings,
        rules_checked=rules_checked,
        rules_passing=rules_passing,
    )


_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{framework} Evidence Package — {project}</title>
<style>
  :root {{
    --bg: #fff; --text: #1a1a2e; --border: #e0e0e0; --card-bg: #f8f9fa;
    --table-stripe: #f5f5f5; --header-bg: #1a1a2e; --header-text: #fff;
    --surface: #ffffff;
  }}
  @media (prefers-color-scheme: dark) {{
    :root {{
      --bg: #0d1117; --text: #e6edf3; --border: #30363d; --card-bg: #161b22;
      --table-stripe: #161b22; --header-bg: #161b22; --header-text: #e6edf3;
      --surface: #161b22;
    }}
  }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: var(--bg); color: var(--text); line-height: 1.6;
    padding: 2rem; max-width: 1200px; margin: 0 auto;
  }}
  h1 {{ font-size: 1.8rem; margin-bottom: 0.25rem; }}
  h2 {{ font-size: 1.3rem; margin: 2rem 0 1rem; border-bottom: 2px solid var(--border); padding-bottom: 0.5rem; }}
  .meta {{ color: #888; font-size: 0.85rem; margin-bottom: 1.5rem; }}

  .summary-bar {{
    display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 1rem; margin-bottom: 2rem;
  }}
  .summary-card {{
    background: var(--card-bg); border: 1px solid var(--border);
    border-radius: 8px; padding: 1.2rem; text-align: center;
  }}
  .summary-card .num {{ font-size: 2rem; font-weight: 800; }}
  .summary-card .label {{ font-size: 0.8rem; color: #888; text-transform: uppercase; }}

  .control-section {{
    background: var(--surface); border: 1px solid var(--border);
    border-radius: 8px; padding: 1.25rem; margin-bottom: 1.25rem;
  }}
  .control-header {{
    display: flex; justify-content: space-between; align-items: center;
    margin-bottom: 0.5rem;
  }}
  .control-id {{
    font-weight: 700; font-size: 1.05rem; margin-right: 0.75rem;
  }}
  .control-name {{ color: var(--text); font-size: 0.95rem; }}
  .control-meta {{ font-size: 0.8rem; color: #888; margin-bottom: 0.75rem; }}

  .status-badge {{
    display: inline-block; padding: 3px 10px; border-radius: 4px;
    color: #fff; font-size: 0.75rem; font-weight: 700; text-transform: uppercase;
  }}

  .evidence-table {{
    width: 100%; border-collapse: collapse; font-size: 0.83rem;
  }}
  .evidence-table th {{
    background: var(--header-bg); color: var(--header-text);
    padding: 0.5rem 0.7rem; text-align: left; font-weight: 600;
  }}
  .evidence-table td {{
    padding: 0.45rem 0.7rem; border-bottom: 1px solid var(--border); vertical-align: top;
  }}
  .evidence-table tr:nth-child(even) {{ background: var(--table-stripe); }}

  .ev-type {{
    display: inline-block; padding: 2px 8px; border-radius: 3px;
    background: var(--card-bg); font-size: 0.75rem; font-weight: 600;
  }}
  .ev-details {{
    margin-top: 0.3rem; font-size: 0.8rem;
  }}
  .ev-file {{ color: #888; }}

  code {{
    background: var(--card-bg); padding: 2px 6px; border-radius: 3px; font-size: 0.8rem;
  }}

  .status-icon {{
    display: inline-block; width: 1.2em; font-weight: 700; font-size: 1rem;
  }}
  .pass-icon {{ color: #4caf50; }}
  .fail-icon {{ color: #d32f2f; }}

  .rules-summary {{
    text-align: center; font-size: 0.85rem; color: #888;
    margin-bottom: 1.5rem; margin-top: -0.5rem;
  }}

  .footer {{
    margin-top: 3rem; padding-top: 1rem; border-top: 1px solid var(--border);
    font-size: 0.75rem; color: #888; text-align: center;
  }}

  @media print {{
    body {{ padding: 0; font-size: 10pt; }}
    .control-section {{ break-inside: avoid; }}
    .evidence-table {{ font-size: 8pt; }}
  }}
  @media (max-width: 600px) {{
    .summary-bar {{ grid-template-columns: 1fr; }}
  }}
</style>
</head>
<body>

<h1>{framework} Evidence Package</h1>
<div class="meta">
  {project} &mdash; Generated {generated} UTC &mdash; Sentrik v{version}
</div>

{summary_html}

<h2>Controls</h2>
{controls_html}

<div class="footer">
  Sentrik v{version} &mdash; {framework} Evidence Package &mdash;
  {total} controls evaluated, {passing} passing, {with_findings} with findings &mdash;
  {rules_checked} rules checked, {rules_passing} passing
</div>

</body>
</html>
"""


def list_available_frameworks() -> list[str]:
    """Return the list of well-known frameworks."""
    return list(AVAILABLE_FRAMEWORKS)
