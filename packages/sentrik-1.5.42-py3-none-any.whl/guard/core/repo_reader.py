"""Utilities for reading repository information."""

from __future__ import annotations

import logging
import re
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)


def get_git_repo_name(start: Path | None = None) -> str | None:
    """Extract the repository name from the git remote origin URL.

    Returns the repo name (without .git suffix) or *None* if unavailable.
    """
    cwd = str(start) if start else None
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            cwd=cwd,
        )
        if result.returncode == 0:
            url = result.stdout.strip()
            # Handle SSH (git@host:owner/repo.git) and HTTPS (https://host/owner/repo.git)
            name = url.rstrip("/").rsplit("/", 1)[-1].rsplit(":", 1)[-1]
            if name.endswith(".git"):
                name = name[:-4]
            return name if name else None
    except FileNotFoundError:
        pass
    return None


def find_repo_root(start: Path | None = None) -> Path:
    """Find the git repository root, or fall back to cwd."""
    if start is None:
        start = Path.cwd()
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            cwd=str(start),
        )
        if result.returncode == 0:
            return Path(result.stdout.strip())
    except FileNotFoundError:
        pass
    return start


_DEFAULT_EXCLUDE_DIRS = {
    ".venv", "venv", ".env", "env",
    "node_modules",
    ".git",
    "__pycache__",
    ".tox", ".nox", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "dist", "build", ".eggs",
    "out",
}


def _expand_braces(pattern: str) -> list[str]:
    """Expand bash-style brace patterns into multiple glob patterns.

    e.g. '**/*.{py,js,ts}' -> ['**/*.py', '**/*.js', '**/*.ts']
    Supports one level of braces. Patterns without braces are returned as-is.
    """
    m = re.search(r'\{([^}]+)\}', pattern)
    if not m:
        return [pattern]
    prefix = pattern[:m.start()]
    suffix = pattern[m.end():]
    return [prefix + alt + suffix for alt in m.group(1).split(',')]


def list_files(repo_root: Path, glob_pattern: str = "**/*") -> list[str]:
    """List files in the repo matching a glob pattern.

    Supports bash-style brace expansion (e.g. '**/*.{py,js,ts}').
    Automatically excludes common non-source directories (.venv, node_modules,
    .git, __pycache__, out, dist, build, etc.).
    """
    patterns = _expand_braces(glob_pattern)
    seen: set[str] = set()
    result: list[str] = []
    for pat in patterns:
        try:
            matches = list(repo_root.glob(pat))
        except (ValueError, OSError) as exc:
            logger.debug("Glob pattern %r skipped: %s", pat, exc)
            continue
        for p in matches:
            if not p.is_file():
                continue
            rel = str(p.relative_to(repo_root))
            if rel in seen:
                continue
            parts = p.relative_to(repo_root).parts
            if any(part in _DEFAULT_EXCLUDE_DIRS or part.startswith(".") for part in parts):
                continue
            seen.add(rel)
            result.append(rel)
    return result
