"""License key validation for SENTRIK.

Supports offline key validation using HMAC-based keys.
Key format: GUARD-<tier>-<expiry_yyyymmdd>-<hmac_hex[:16]>
Example:    GUARD-TEAM-20261231-a1b2c3d4e5f67890

Tiers: FREE, TRIAL, TEAM, ORG, ENTERPRISE
"""

from __future__ import annotations

import functools
import hashlib
import hmac
import logging
import os
import threading
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

logger = logging.getLogger(__name__)

def _get_license_secret() -> str:
    """Return the license HMAC secret, auto-generating if not configured.

    Priority: GUARD_LICENSE_SECRET env var > persisted file > auto-generate.
    """
    from pathlib import Path

    env_secret = os.environ.get("GUARD_LICENSE_SECRET")
    if env_secret:
        return env_secret

    # Auto-generate and persist per-installation
    secret_path = Path(".sentrik") / "local" / "license_secret"
    if secret_path.exists():
        try:
            return secret_path.read_text(encoding="utf-8").strip()
        except OSError:
            pass

    import secrets
    secret = secrets.token_hex(32)
    try:
        secret_path.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(str(secret_path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(secret)
    except (OSError, AttributeError):
        try:
            secret_path.write_text(secret, encoding="utf-8")
        except OSError:
            logger.warning("Could not persist license secret — using ephemeral key")
    return secret


_LICENSE_SECRET = _get_license_secret()

VALID_TIERS = {"FREE", "TRIAL", "TEAM", "ORG", "ENTERPRISE"}
TIER_DISPLAY = {
    "FREE": "Free",
    "TRIAL": "Trial (30 days)",
    "TEAM": "Team",
    "ORG": "Organization",
    "ENTERPRISE": "Enterprise",
}

# Feature gates per tier
TIER_FEATURES: dict[str, set[str]] = {
    "FREE": {"scan", "gate", "dashboard", "api", "custom_packs"},
    "TRIAL": {"scan", "gate", "reconcile", "dashboard", "packs", "api", "custom_packs"},
    "TEAM": {"scan", "gate", "reconcile", "dashboard", "packs", "api", "custom_packs"},
    "ORG": {"scan", "gate", "reconcile", "dashboard", "packs", "api", "parallel", "ml", "custom_packs"},
    "ENTERPRISE": {"scan", "gate", "reconcile", "dashboard", "packs", "api", "parallel", "ml", "governance", "audit", "async_approval", "custom_packs"},
}

# Maximum custom packs allowed per tier
MAX_CUSTOM_PACKS: dict[str, int] = {
    "FREE": 5,
    "TRIAL": 25,
    "TEAM": 25,
    "ORG": 100,
    "ENTERPRISE": 9999,
}


@dataclass
class LicenseInfo:
    """Parsed and validated license information."""
    valid: bool
    tier: str
    expiry: date | None
    expired: bool
    features: set[str]
    message: str


def _compute_hmac(tier: str, expiry_str: str) -> str:
    """Compute HMAC signature for a tier+expiry combo."""
    payload = f"{tier}-{expiry_str}"
    sig = hmac.new(
        _LICENSE_SECRET.encode("utf-8"),
        payload.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()[:16]
    return sig


def generate_key(tier: str, expiry: date) -> str:
    """Generate a license key for testing/admin purposes."""
    if tier not in VALID_TIERS:
        raise ValueError(f"Invalid tier: {tier}. Valid: {sorted(VALID_TIERS)}")
    expiry_str = expiry.strftime("%Y%m%d")
    sig = _compute_hmac(tier, expiry_str)
    return f"GUARD-{tier}-{expiry_str}-{sig}"


def generate_trial_key(days: int = 30) -> str:
    """Generate a 30-day ENTERPRISE trial key for evaluation.

    Uses the ENTERPRISE tier so all features are unlocked during the trial.
    """
    expiry = date.today() + timedelta(days=days)
    return generate_key("ENTERPRISE", expiry)


def validate_key(key: str) -> LicenseInfo:
    """Validate a license key and return license info."""
    if not key or not key.strip():
        return LicenseInfo(
            valid=False, tier="", expiry=None, expired=False,
            features=set(), message="No license key provided",
        )

    key = key.strip()
    parts = key.split("-")

    # Expected: GUARD-TIER-YYYYMMDD-HMAC
    if len(parts) != 4 or parts[0] != "GUARD":
        return LicenseInfo(
            valid=False, tier="", expiry=None, expired=False,
            features=set(), message="Invalid key format",
        )

    _, tier, expiry_str, provided_sig = parts

    if tier not in VALID_TIERS:
        return LicenseInfo(
            valid=False, tier=tier, expiry=None, expired=False,
            features=set(), message=f"Unknown tier: {tier}",
        )

    # Validate expiry date format
    try:
        expiry = datetime.strptime(expiry_str, "%Y%m%d").date()
    except ValueError:
        return LicenseInfo(
            valid=False, tier=tier, expiry=None, expired=False,
            features=set(), message="Invalid expiry date format",
        )

    # Validate HMAC signature
    expected_sig = _compute_hmac(tier, expiry_str)
    if not hmac.compare_digest(provided_sig, expected_sig):
        return LicenseInfo(
            valid=False, tier=tier, expiry=expiry, expired=False,
            features=set(), message="Invalid key signature",
        )

    # Check expiry
    is_expired = date.today() > expiry
    features = TIER_FEATURES.get(tier, set())

    if is_expired:
        return LicenseInfo(
            valid=True, tier=tier, expiry=expiry, expired=True,
            features=set(),  # No features when expired
            message=f"License expired on {expiry.isoformat()}",
        )

    return LicenseInfo(
        valid=True, tier=tier, expiry=expiry, expired=False,
        features=features,
        message=f"{TIER_DISPLAY.get(tier, tier)} license valid until {expiry.isoformat()}",
    )


def get_license_info(config_key: str = "") -> LicenseInfo:
    """Get license info from config key or GUARD_LICENSE_KEY env var."""
    key = config_key or os.environ.get("GUARD_LICENSE_KEY", "")
    if not key:
        # Check for persisted trial key
        from pathlib import Path
        trial_key_path = Path(".sentrik") / "local" / "license.key"
        if trial_key_path.exists():
            try:
                persisted = trial_key_path.read_text(encoding="utf-8").strip()
                if persisted:
                    return validate_key(persisted)
            except OSError:
                pass
        # No key = permanent free tier (limited packs, never expires)
        return LicenseInfo(
            valid=True, tier="FREE", expiry=None, expired=False,
            features=TIER_FEATURES["FREE"],
            message="Free tier — upgrade at https://sentrik.dev for more packs",
        )
    return validate_key(key)


def check_feature(license_info: LicenseInfo, feature: str) -> bool:
    """Check if a feature is available with the current license."""
    return feature in license_info.features


# ---------------------------------------------------------------------------
# License enforcement
# ---------------------------------------------------------------------------

# Ordered from lowest to highest tier
_TIER_ORDER = ["FREE", "TRIAL", "TEAM", "ORG", "ENTERPRISE"]


class LicenseError(Exception):
    """Raised when a feature is not available at the current license tier."""

    def __init__(self, feature: str, tier: str, message: str = ""):
        self.feature = feature
        self.tier = tier
        if not message:
            min_tier = _minimum_tier_for_feature(feature)
            message = (
                f"Feature '{feature}' requires {TIER_DISPLAY.get(min_tier, min_tier)} tier or higher. "
                f"Current tier: {TIER_DISPLAY.get(tier, tier) if tier else 'none'}."
            )
        super().__init__(message)


def _minimum_tier_for_feature(feature: str) -> str:
    """Return the lowest tier that includes a given feature."""
    for tier in _TIER_ORDER:
        if feature in TIER_FEATURES.get(tier, set()):
            return tier
    return "ENTERPRISE"


def require_license(feature: str, config_key: str = "") -> LicenseInfo:
    """Check that *feature* is available; raise ``LicenseError`` if not.

    Returns the ``LicenseInfo`` on success so callers can inspect it.
    """
    info = get_license_info(config_key)
    if not check_feature(info, feature):
        if info.tier and not info.valid:
            # Key was provided but rejected (bad signature, format, etc.)
            raise LicenseError(
                feature=feature, tier=info.tier,
                message=f"License error: {info.message}. "
                        f"Remove GUARD_LICENSE_KEY to use evaluation mode, "
                        f"or generate a valid key with the correct installation secret.",
            )
        raise LicenseError(feature=feature, tier=info.tier)
    return info


# ---------------------------------------------------------------------------
# Online license check (soft layer on top of offline HMAC validation)
# ---------------------------------------------------------------------------

_CACHE_FILE = ".sentrik/local/license_cache.json"
_CACHE_TTL_SECONDS = 86400  # 24 hours
_cache_lock = threading.Lock()


@dataclass
class OnlineLicenseStatus:
    """Result from portal.sentrik.dev/api/license/check."""
    checked: bool
    valid: bool
    tier: str
    expiry: str
    days_remaining: int
    cached: bool
    error: str


def _load_cache() -> dict | None:
    """Load cached online check result."""
    import json
    from pathlib import Path

    with _cache_lock:
        path = Path(_CACHE_FILE)
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            cached_at = data.get("cached_at", 0)
            import time
            if time.time() - cached_at > _CACHE_TTL_SECONDS:
                return None  # expired
            return data
        except (json.JSONDecodeError, OSError):
            return None


def _save_cache(result: dict) -> None:
    """Save online check result to cache."""
    import json
    import time
    from pathlib import Path

    with _cache_lock:
        path = Path(_CACHE_FILE)
        path.parent.mkdir(parents=True, exist_ok=True)
        result["cached_at"] = time.time()
        path.write_text(json.dumps(result, indent=2), encoding="utf-8")


def check_license_online(key: str, portal_url: str = "") -> OnlineLicenseStatus:
    """Check license key against portal API with 24-hour cache.

    Falls back gracefully on network errors — never blocks the user.
    """
    if not key:
        return OnlineLicenseStatus(
            checked=False, valid=False, tier="", expiry="",
            days_remaining=0, cached=False, error="No key provided",
        )

    # Check cache first
    cached = _load_cache()
    if cached and cached.get("key") == key:
        return OnlineLicenseStatus(
            checked=True,
            valid=cached.get("valid", False),
            tier=cached.get("tier", ""),
            expiry=cached.get("expiry", ""),
            days_remaining=cached.get("days_remaining", 0),
            cached=True,
            error="",
        )

    # Call portal API
    portal_url = portal_url or os.environ.get(
        "GUARD_PORTAL_URL", "https://portal.sentrik.dev"
    )
    url = f"{portal_url.rstrip('/')}/api/license/check?key={key}"

    try:
        import httpx
        resp = httpx.get(url, timeout=5.0)
        resp.raise_for_status()
        data = resp.json()
    except Exception as exc:
        logger.debug("Online license check failed: %s", exc)
        # Fall back to cached result if available (even expired)
        return OnlineLicenseStatus(
            checked=False, valid=False, tier="", expiry="",
            days_remaining=0, cached=False,
            error=f"Portal unreachable: {exc}",
        )

    # Cache the result
    cache_data = {
        "key": key,
        "valid": data.get("valid", False),
        "tier": data.get("tier", ""),
        "expiry": data.get("expiry", ""),
        "days_remaining": data.get("days_remaining", 0),
    }
    _save_cache(cache_data)

    return OnlineLicenseStatus(
        checked=True,
        valid=data.get("valid", False),
        tier=data.get("tier", ""),
        expiry=data.get("expiry", ""),
        days_remaining=data.get("days_remaining", 0),
        cached=False,
        error="",
    )


def enforce_license(feature: str):
    """Decorator that gates a function behind a license check.

    The decorated function's first positional argument (or ``config_key``
    keyword argument) is used as the license key.  If neither is present
    the check falls back to the environment variable / trial mode.
    """

    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            config_key = kwargs.get("config_key", "")
            if not config_key and args:
                config_key = args[0] if isinstance(args[0], str) else ""
            require_license(feature, config_key)
            return fn(*args, **kwargs)

        return wrapper

    return decorator
