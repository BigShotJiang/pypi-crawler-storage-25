"""Pydantic models for AI SDLC Guard artifacts."""

from __future__ import annotations

from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class Evidence(BaseModel):
    file: str
    lines: list[int] = []
    snippet: str = ""


class Finding(BaseModel):
    finding_id: str
    rule_id: str
    severity: Severity
    message: str
    evidence: Evidence
    suggestion: Optional[str] = None
    confidence: float = Field(ge=0.0, le=1.0)
    deterministic: bool = True
    related_work_items: list[str] = []
    standard: Optional[str] = None
    clause: Optional[str] = None
    compliance_category: Optional[str] = None
    remediation_guidance: Optional[str] = None
    tags: list[str] = Field(default_factory=list)
    is_obligation: bool = False
    risk_score: Optional[dict[str, Any]] = None


class WorkItem(BaseModel):
    id: str
    title: str
    description: str = ""
    acceptance_criteria: list[str] = []
    state: str = "active"
    rule_id: Optional[str] = None
    devops_id: Optional[int | str] = None


class FileScope(BaseModel):
    allowed: list[str] = Field(default_factory=lambda: ["**/*"])
    blocked: list[str] = Field(default_factory=list)


class DefinitionOfDone(BaseModel):
    gate_must_pass: bool = True
    required_rules: list[str] = Field(default_factory=list)


class AgentContext(BaseModel):
    repo_root: str
    work_items: list[WorkItem] = Field(default_factory=list)
    file_scope: FileScope = Field(default_factory=FileScope)
    standards_rule_ids: list[str] = Field(default_factory=list)
    commands: dict[str, str] = Field(default_factory=dict)
    definition_of_done: DefinitionOfDone = Field(default_factory=DefinitionOfDone)
    governance: dict = Field(default_factory=dict)


class RunMetadata(BaseModel):
    run_id: str
    timestamp: str
    guard_version: str
    command: str
    exit_code: int
    findings_count: int
    duration_ms: float
    scoped_files: list[str] | None = None


class DiffHunk(BaseModel):
    src_start: int
    src_count: int
    tgt_start: int
    tgt_count: int
    lines: list[str]


class FileDiff(BaseModel):
    old_path: str
    new_path: str
    is_binary: bool = False
    is_rename: bool = False
    is_new: bool = False
    is_deleted: bool = False
    hunks: list[DiffHunk] = Field(default_factory=list)

    @property
    def path(self) -> str:
        return self.new_path or self.old_path


class GateResult(BaseModel):
    passed: bool
    total_findings: int
    critical: int = 0
    high: int = 0
    medium: int = 0
    low: int = 0
    info: int = 0
    approval_id: str = ""
    pending_approval: bool = False


class GeneratedRequirement(BaseModel):
    req_id: str                              # "REQ-GEN-001"
    title: str                               # Short requirement title
    description: str = ""                    # What the code does
    acceptance_criteria: list[str] = Field(default_factory=list)
    source_files: list[str] = Field(default_factory=list)
    status: str = "draft"                    # draft | approved | rejected
    work_item_id: Optional[str] = None       # Local WI ID after creation
    devops_id: Optional[int | str] = None    # Remote DevOps ID


class RunComparison(BaseModel):
    new_findings: list[Finding] = Field(default_factory=list)
    resolved_findings: list[Finding] = Field(default_factory=list)
    unchanged_findings: list[Finding] = Field(default_factory=list)
