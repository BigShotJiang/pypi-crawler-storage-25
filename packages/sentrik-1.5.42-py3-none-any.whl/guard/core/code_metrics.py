"""Language-agnostic code metrics for source files.

Provides per-file metrics: lines of code, blank lines, comment lines,
max nesting depth, and function count. Works across all languages
using heuristic pattern matching.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


@dataclass
class FileMetrics:
    """Metrics for a single source file."""

    file: str
    total_lines: int = 0
    code_lines: int = 0
    blank_lines: int = 0
    comment_lines: int = 0
    max_nesting: int = 0
    function_count: int = 0


# Comment line patterns by file extension
_COMMENT_PATTERNS: dict[str, re.Pattern] = {
    ".py": re.compile(r"^\s*#"),
    ".rb": re.compile(r"^\s*#"),
    ".sh": re.compile(r"^\s*#"),
    ".yaml": re.compile(r"^\s*#"),
    ".yml": re.compile(r"^\s*#"),
    ".toml": re.compile(r"^\s*#"),
    ".js": re.compile(r"^\s*//"),
    ".ts": re.compile(r"^\s*//"),
    ".jsx": re.compile(r"^\s*//"),
    ".tsx": re.compile(r"^\s*//"),
    ".java": re.compile(r"^\s*//"),
    ".c": re.compile(r"^\s*//"),
    ".cpp": re.compile(r"^\s*//"),
    ".cc": re.compile(r"^\s*//"),
    ".h": re.compile(r"^\s*//"),
    ".hpp": re.compile(r"^\s*//"),
    ".cs": re.compile(r"^\s*//"),
    ".go": re.compile(r"^\s*//"),
    ".rs": re.compile(r"^\s*//"),
    ".swift": re.compile(r"^\s*//"),
    ".kt": re.compile(r"^\s*//"),
    ".kts": re.compile(r"^\s*//"),
    ".php": re.compile(r"^\s*(//|#)"),
}

# Function definition patterns by extension
_FUNCTION_PATTERNS: dict[str, re.Pattern] = {
    ".py": re.compile(r"^\s*def\s+\w+"),
    ".js": re.compile(r"(?:function\s+\w+|(?:const|let|var)\s+\w+\s*=\s*(?:async\s+)?(?:\([^)]*\)|[^=])\s*=>)"),
    ".ts": re.compile(r"(?:function\s+\w+|(?:const|let|var)\s+\w+\s*=\s*(?:async\s+)?(?:\([^)]*\)|[^=])\s*=>)"),
    ".jsx": re.compile(r"(?:function\s+\w+|(?:const|let|var)\s+\w+\s*=\s*(?:async\s+)?(?:\([^)]*\)|[^=])\s*=>)"),
    ".tsx": re.compile(r"(?:function\s+\w+|(?:const|let|var)\s+\w+\s*=\s*(?:async\s+)?(?:\([^)]*\)|[^=])\s*=>)"),
    ".java": re.compile(r"(?:public|private|protected|static|\s)+[\w<>\[\]]+\s+\w+\s*\("),
    ".c": re.compile(r"^[\w\s*]+\w+\s*\([^;]*\)\s*\{"),
    ".cpp": re.compile(r"^[\w\s*:&]+\w+\s*\([^;]*\)\s*\{?"),
    ".go": re.compile(r"^func\s+"),
    ".rs": re.compile(r"^\s*(?:pub\s+)?fn\s+\w+"),
    ".rb": re.compile(r"^\s*def\s+\w+"),
    ".php": re.compile(r"^\s*(?:public|private|protected|static|\s)*function\s+\w+"),
    ".kt": re.compile(r"^\s*(?:fun|suspend\s+fun)\s+\w+"),
    ".kts": re.compile(r"^\s*(?:fun|suspend\s+fun)\s+\w+"),
    ".cs": re.compile(r"(?:public|private|protected|internal|static|\s)+[\w<>\[\]]+\s+\w+\s*\("),
    ".swift": re.compile(r"^\s*func\s+\w+"),
}

# Nesting increase characters
_OPEN_BRACES = re.compile(r"[{(]")
_CLOSE_BRACES = re.compile(r"[})]")


def analyze_file(file_path: str | Path) -> FileMetrics:
    """Compute code metrics for a single file."""
    path = Path(file_path)
    metrics = FileMetrics(file=str(path))

    try:
        content = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return metrics

    lines = content.splitlines()
    ext = path.suffix.lower()
    comment_pat = _COMMENT_PATTERNS.get(ext)
    func_pat = _FUNCTION_PATTERNS.get(ext)

    metrics.total_lines = len(lines)
    current_nesting = 0

    # Python uses indentation for nesting
    is_indent_language = ext in (".py", ".rb", ".yaml", ".yml")

    for line in lines:
        stripped = line.strip()

        if not stripped:
            metrics.blank_lines += 1
            continue

        if comment_pat and comment_pat.match(line):
            metrics.comment_lines += 1
            continue

        metrics.code_lines += 1

        # Function count
        if func_pat and func_pat.search(line):
            metrics.function_count += 1

        # Nesting depth
        if is_indent_language:
            indent = len(line) - len(line.lstrip())
            level = indent // 4  # assume 4-space indent
            if level > metrics.max_nesting:
                metrics.max_nesting = level
        else:
            current_nesting += len(_OPEN_BRACES.findall(stripped))
            current_nesting -= len(_CLOSE_BRACES.findall(stripped))
            current_nesting = max(0, current_nesting)
            if current_nesting > metrics.max_nesting:
                metrics.max_nesting = current_nesting

    return metrics


def analyze_directory(
    root: str | Path,
    file_paths: list[str] | None = None,
    extensions: set[str] | None = None,
) -> list[FileMetrics]:
    """Analyze multiple files and return sorted metrics.

    If *file_paths* is provided, only those files are analyzed.
    Otherwise, all source files under *root* are scanned.
    """
    root_path = Path(root)
    if extensions is None:
        extensions = set(_COMMENT_PATTERNS.keys())

    results: list[FileMetrics] = []

    if file_paths:
        for fp in file_paths:
            full = root_path / fp if not Path(fp).is_absolute() else Path(fp)
            if full.suffix.lower() in extensions and full.is_file():
                results.append(analyze_file(full))
    else:
        for ext in extensions:
            for fp in root_path.rglob(f"*{ext}"):
                if any(p.startswith(".") for p in fp.relative_to(root_path).parts):
                    continue
                if "node_modules" in fp.parts or "__pycache__" in fp.parts:
                    continue
                results.append(analyze_file(fp))

    return sorted(results, key=lambda m: m.code_lines, reverse=True)
