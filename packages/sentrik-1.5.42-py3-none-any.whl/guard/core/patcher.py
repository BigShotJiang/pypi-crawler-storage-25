"""Patch generation and application for auto-fixable findings."""

from __future__ import annotations

import logging
from pathlib import Path

from guard.core.models import Finding

logger = logging.getLogger(__name__)

# Autofix strategies supported by the patcher.
STRATEGY_REMOVE_LINE = "remove_line"
STRATEGY_REPLACE_MATCH = "replace_match"
STRATEGY_COMMENT_OUT = "comment_out"


def generate_patches(
    findings: list[Finding],
    repo_root: str,
    autofix_map: dict[str, str] | None = None,
    replacement_map: dict[str, str] | None = None,
) -> list[str]:
    """Generate unified diff patches for auto-fixable findings.

    *autofix_map* maps ``rule_id`` to an autofix strategy string
    (e.g. ``"remove_line"``).  Only findings whose ``rule_id``
    appears in the map with a recognised strategy will be patched.

    *replacement_map* maps ``rule_id`` to replacement text for the
    ``replace_match`` strategy.

    Returns a list of unified-diff patch strings (one per affected file).
    """
    if not autofix_map:
        return []

    root = Path(repo_root)

    # Group fixable findings by file
    file_findings: dict[str, list[Finding]] = {}
    for f in findings:
        strategy = autofix_map.get(f.rule_id)
        if not strategy:
            continue
        if strategy not in _STRATEGY_HANDLERS:
            logger.warning("Unknown autofix strategy %r for rule %s — skipped", strategy, f.rule_id)
            continue
        file_findings.setdefault(f.evidence.file, []).append(f)

    patches: list[str] = []
    for rel_path, file_findings_list in sorted(file_findings.items()):
        abs_path = root / rel_path
        try:
            original = abs_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue

        fixed = _apply_strategies(original, file_findings_list, autofix_map, replacement_map, rel_path)
        if fixed == original:
            continue

        patch = _make_unified_diff(rel_path, original, fixed)
        if patch:
            patches.append(patch)

    return patches


def write_patches(patches: list[str], patches_dir: Path) -> list[Path]:
    """Write patch strings to individual ``.patch`` files.

    Returns the list of written file paths.
    """
    patches_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    for i, patch in enumerate(patches, 1):
        path = patches_dir / f"{i:04d}.patch"
        path.write_text(patch, encoding="utf-8")
        written.append(path)
    return written


def apply_patches(patches_dir: Path, repo_root: str) -> int:
    """Apply ``.patch`` files from *patches_dir* to *repo_root*.

    Returns the number of patches successfully applied.
    """
    root = Path(repo_root)
    if not patches_dir.exists():
        return 0

    patch_files = sorted(patches_dir.glob("*.patch"))
    applied = 0
    for pf in patch_files:
        try:
            patch_text = pf.read_text(encoding="utf-8")
        except OSError:
            continue
        if _apply_patch(patch_text, root):
            applied += 1
    return applied


# ------------------------------------------------------------------
# Private helpers
# ------------------------------------------------------------------

_COMMENT_PREFIX = {
    ".py": "# ", ".rb": "# ", ".sh": "# ", ".bash": "# ", ".yaml": "# ", ".yml": "# ",
    ".toml": "# ", ".cfg": "# ", ".ini": "# ", ".r": "# ", ".pl": "# ",
    ".cpp": "// ", ".c": "// ", ".h": "// ", ".hpp": "// ", ".cc": "// ", ".cxx": "// ",
    ".java": "// ", ".js": "// ", ".ts": "// ", ".tsx": "// ", ".jsx": "// ",
    ".cs": "// ", ".go": "// ", ".rs": "// ", ".swift": "// ", ".kt": "// ",
    ".m": "// ", ".mm": "// ", ".scala": "// ", ".dart": "// ", ".php": "// ",
}


def _apply_strategies(
    content: str,
    findings: list[Finding],
    autofix_map: dict[str, str],
    replacement_map: dict[str, str] | None = None,
    file_path: str = "",
) -> str:
    """Apply autofix strategies to *content*, returning the fixed version."""
    replacement_map = replacement_map or {}
    lines = content.splitlines(keepends=True)

    # Collect 0-based line indices to remove (from remove_line strategy)
    lines_to_remove: set[int] = set()
    # Collect 0-based line indices to comment out
    lines_to_comment: set[int] = set()
    # Collect line-level replacements: {0-based index: (pattern, replacement)}
    line_replacements: dict[int, tuple[str, str]] = {}

    for f in findings:
        strategy = autofix_map.get(f.rule_id)
        if strategy == STRATEGY_REMOVE_LINE:
            for line_no in f.evidence.lines:
                lines_to_remove.add(line_no - 1)
        elif strategy == STRATEGY_COMMENT_OUT:
            for line_no in f.evidence.lines:
                lines_to_comment.add(line_no - 1)
        elif strategy == STRATEGY_REPLACE_MATCH:
            replacement = replacement_map.get(f.rule_id, "")
            if f.evidence.snippet:
                for line_no in f.evidence.lines:
                    line_replacements[line_no - 1] = (f.evidence.snippet, replacement)

    # Apply comment_out (before removals so indices are still valid)
    if lines_to_comment:
        # Pick comment prefix based on file extension
        ext = ""
        if file_path:
            from pathlib import PurePosixPath
            ext = PurePosixPath(file_path).suffix.lower()
        comment = _COMMENT_PREFIX.get(ext, "# ")
        for idx in lines_to_comment:
            if 0 <= idx < len(lines):
                line = lines[idx]
                # Preserve leading whitespace
                stripped = line.lstrip()
                indent = line[: len(line) - len(stripped)]
                lines[idx] = f"{indent}{comment}{stripped}"

    # Apply replace_match
    if line_replacements:
        import re
        for idx, (pattern, replacement) in line_replacements.items():
            if 0 <= idx < len(lines):
                lines[idx] = re.sub(re.escape(pattern), replacement, lines[idx])

    # Apply remove_line last
    if lines_to_remove:
        lines = [line for i, line in enumerate(lines) if i not in lines_to_remove]

    return "".join(lines)


def _make_unified_diff(rel_path: str, original: str, fixed: str) -> str:
    """Produce a unified diff between *original* and *fixed*."""
    import difflib

    orig_lines = original.splitlines(keepends=True)
    fixed_lines = fixed.splitlines(keepends=True)
    diff = difflib.unified_diff(
        orig_lines,
        fixed_lines,
        fromfile=f"a/{rel_path}",
        tofile=f"b/{rel_path}",
    )
    return "".join(diff)


def _apply_patch(patch_text: str, repo_root: Path) -> bool:
    """Apply a single unified diff patch to *repo_root*.

    Performs a simple line-based patch application: parses hunks and
    applies removals/additions at the indicated positions.
    """
    # Parse the patch to extract file path and hunks
    lines = patch_text.splitlines(keepends=True)
    if len(lines) < 3:
        return False

    # Find the target file from the +++ line
    target_file: str | None = None
    for line in lines:
        if line.startswith("+++ "):
            raw = line[4:].strip()
            # Strip b/ prefix
            if raw.startswith("b/"):
                raw = raw[2:]
            target_file = raw
            break

    if not target_file:
        return False

    abs_path = repo_root / target_file
    if not abs_path.exists():
        return False

    try:
        original = abs_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return False

    orig_lines = original.splitlines(keepends=True)
    result_lines: list[str] = []
    orig_idx = 0  # current position in original file (0-based)

    # Parse hunks
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("@@ "):
            # Parse hunk header: @@ -src_start,src_count +tgt_start,tgt_count @@
            hunk_info = line.split("@@")[1].strip()
            parts = hunk_info.split()
            src_part = parts[0]  # e.g. "-1,5"
            src_start = int(src_part.split(",")[0].lstrip("-"))
            # Copy lines before this hunk
            while orig_idx < src_start - 1:
                if orig_idx < len(orig_lines):
                    result_lines.append(orig_lines[orig_idx])
                orig_idx += 1

            # Process hunk lines
            i += 1
            while i < len(lines) and not lines[i].startswith("@@ ") and not lines[i].startswith("diff "):
                hline = lines[i]
                if hline.startswith("-"):
                    # Remove line from original
                    orig_idx += 1
                elif hline.startswith("+"):
                    # Add line to result
                    result_lines.append(hline[1:])
                elif hline.startswith(" "):
                    # Context line
                    result_lines.append(hline[1:])
                    orig_idx += 1
                elif hline.startswith("\\"):
                    # "\ No newline at end of file" — skip
                    pass
                else:
                    break
                i += 1
            continue
        i += 1

    # Copy remaining lines
    while orig_idx < len(orig_lines):
        result_lines.append(orig_lines[orig_idx])
        orig_idx += 1

    new_content = "".join(result_lines)
    if new_content == original:
        return False

    try:
        abs_path.write_text(new_content, encoding="utf-8")
    except OSError:
        return False

    return True


_STRATEGY_HANDLERS = {
    STRATEGY_REMOVE_LINE,
    STRATEGY_REPLACE_MATCH,
    STRATEGY_COMMENT_OUT,
}
