"""Verify that requirements match actual code behavior (drift detection)."""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any

import yaml

from guard.core.models import Evidence, Finding, GeneratedRequirement
from guard.providers.llm_base import LLMProvider


# ---------------------------------------------------------------------------
# LLM prompt
# ---------------------------------------------------------------------------

_VERIFICATION_PROMPT = """\
You are a software verification engineer. Compare the requirement below \
against the actual source code and identify any drift — places where the \
requirement description or acceptance criteria do not match what the code \
actually does.

Return ONLY valid JSON with this structure:
{{
  "matches": true/false,
  "drifts": [
    {{
      "description": "What the requirement says vs what the code does",
      "severity": "low" or "medium",
      "file": "path/to/file.py",
      "suggestion": "How to fix the drift"
    }}
  ]
}}

If the requirement fully matches the code, return {{"matches": true, "drifts": []}}.
Only flag genuine behavioral mismatches, not stylistic differences.

REQUIREMENT:
  ID: {req_id}
  Title: {title}
  Description: {description}
  Acceptance Criteria:
{acceptance_criteria}

SOURCE CODE:
"""


def _build_verification_prompt(
    req: GeneratedRequirement,
    file_contents: dict[str, str],
) -> tuple[str, dict[str, Any]]:
    """Build the LLM prompt for requirement verification."""
    ac_text = "\n".join(f"    - {ac}" for ac in req.acceptance_criteria) or "    (none)"
    prompt = _VERIFICATION_PROMPT.format(
        req_id=req.req_id,
        title=req.title,
        description=req.description,
        acceptance_criteria=ac_text,
    )
    for path, content in file_contents.items():
        prompt += f"\n--- {path} ---\n{content}\n"

    context = {"req_id": req.req_id, "files": list(file_contents.keys())}
    return prompt, context


# ---------------------------------------------------------------------------
# Loading requirements
# ---------------------------------------------------------------------------

def load_requirements(path: Path) -> list[GeneratedRequirement]:
    """Load requirements from a YAML file."""
    if not path.exists():
        return []
    try:
        with open(path, encoding="utf-8") as f:
            loaded = yaml.safe_load(f)
    except (yaml.YAMLError, OSError):
        return []

    entries: list[dict] = []
    if isinstance(loaded, dict) and "requirements" in loaded:
        entries = loaded["requirements"]
    elif isinstance(loaded, list):
        entries = loaded

    results: list[GeneratedRequirement] = []
    for entry in entries:
        if isinstance(entry, dict) and "req_id" in entry:
            try:
                results.append(GeneratedRequirement(**entry))
            except (TypeError, ValueError):
                continue
    return results


# ---------------------------------------------------------------------------
# Core verification
# ---------------------------------------------------------------------------

_MAX_CONTENT_BYTES = 50_000


def verify_requirements(
    requirements: list[GeneratedRequirement],
    repo_root: str,
    llm: LLMProvider,
) -> list[Finding]:
    """Verify requirements against source code using an LLM.

    Returns findings for each detected drift.
    """
    findings: list[Finding] = []

    for req in requirements:
        if req.status == "rejected":
            continue
        if not req.source_files:
            continue

        # Read source files
        file_contents: dict[str, str] = {}
        total_bytes = 0
        for fp in req.source_files:
            full = Path(repo_root) / fp
            if not full.is_file():
                continue
            try:
                text = full.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            if total_bytes + len(text.encode()) > _MAX_CONTENT_BYTES:
                break
            file_contents[fp] = text
            total_bytes += len(text.encode())

        if not file_contents:
            continue

        try:
            prompt, context = _build_verification_prompt(req, file_contents)
            response = llm.analyze(prompt, context)
            req_findings = _parse_verification_response(response, req)
            findings.extend(req_findings)
        except (ValueError, TypeError, KeyError, json.JSONDecodeError):
            continue

    return findings


def _parse_verification_response(
    response: dict[str, Any],
    req: GeneratedRequirement,
) -> list[Finding]:
    """Parse LLM verification response into findings."""
    # Handle response formats
    matches = response.get("matches", True)
    drifts = response.get("drifts", [])

    # Try parsing summary field if direct fields are missing
    if "summary" in response and not drifts:
        summary = response["summary"]
        try:
            parsed = json.loads(summary) if isinstance(summary, str) else summary
            if isinstance(parsed, dict):
                matches = parsed.get("matches", matches)
                drifts = parsed.get("drifts", drifts)
        except (json.JSONDecodeError, TypeError):
            pass

    if matches and not drifts:
        return []

    findings: list[Finding] = []
    for drift in drifts:
        if not isinstance(drift, dict):
            continue

        description = drift.get("description", "Requirement drift detected")
        severity = drift.get("severity", "low")
        if severity not in ("critical", "high", "medium", "low", "info"):
            severity = "low"
        file_path = drift.get("file", req.source_files[0] if req.source_files else "")
        suggestion = drift.get("suggestion", "")

        finding = Finding(
            finding_id=f"DRIFT-{uuid.uuid4().hex[:8]}",
            rule_id=f"REQ-DRIFT-{req.req_id}",
            severity=severity,
            message=f"[{req.req_id}] {description}",
            evidence=Evidence(
                file=file_path,
                lines=[],
                snippet="",
            ),
            suggestion=suggestion,
            confidence=0.7,
            deterministic=False,
            remediation_guidance=f"Update the requirement or the code to resolve the drift. Requirement: '{req.title}'",
            tags=["requirement-drift", "verification"],
        )
        findings.append(finding)

    return findings


# ---------------------------------------------------------------------------
# Stub verification (no LLM)
# ---------------------------------------------------------------------------

def verify_requirements_stub(
    requirements: list[GeneratedRequirement],
    repo_root: str,
) -> list[Finding]:
    """Basic drift detection without LLM.

    Checks that source_files still exist and are non-empty.
    Cannot detect semantic drift — only structural issues.
    """
    findings: list[Finding] = []

    for req in requirements:
        if req.status == "rejected":
            continue
        if not req.source_files:
            continue

        for fp in req.source_files:
            full = Path(repo_root) / fp
            if not full.exists():
                findings.append(Finding(
                    finding_id=f"DRIFT-{uuid.uuid4().hex[:8]}",
                    rule_id=f"REQ-DRIFT-{req.req_id}",
                    severity="medium",
                    message=f"[{req.req_id}] Source file '{fp}' referenced in requirement no longer exists",
                    evidence=Evidence(file=fp, lines=[], snippet=""),
                    suggestion=f"Remove '{fp}' from the requirement's source_files, or restore the file",
                    confidence=1.0,
                    deterministic=True,
                    remediation_guidance=f"Requirement '{req.title}' references a missing file",
                    tags=["requirement-drift", "missing-file"],
                ))
            elif full.stat().st_size == 0:
                findings.append(Finding(
                    finding_id=f"DRIFT-{uuid.uuid4().hex[:8]}",
                    rule_id=f"REQ-DRIFT-{req.req_id}",
                    severity="low",
                    message=f"[{req.req_id}] Source file '{fp}' is empty but referenced in requirement",
                    evidence=Evidence(file=fp, lines=[], snippet=""),
                    suggestion="File may have been cleared — verify the requirement still applies",
                    confidence=1.0,
                    deterministic=True,
                    remediation_guidance=f"Requirement '{req.title}' references an empty file",
                    tags=["requirement-drift", "empty-file"],
                ))

    return findings
