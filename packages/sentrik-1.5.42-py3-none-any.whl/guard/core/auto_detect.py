"""Zero-config project detection for SENTRIK.

Scans the current directory for filesystem clues and returns a ProjectProfile
with detected languages, CI platform, suggested standards packs, and governance.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class ProjectProfile:
    """Auto-detected project characteristics."""

    languages: list[str] = field(default_factory=list)
    ci_platform: str | None = None
    suggested_packs: list[str] = field(default_factory=list)
    governance_profile: str = "standard"


def detect_project(base_dir: Path | None = None) -> ProjectProfile:
    """Detect project characteristics from filesystem clues.

    Inspects file markers in *base_dir* (defaults to CWD) and returns a
    :class:`ProjectProfile` with detected languages, CI platform, and
    suggested standards packs.
    """
    if base_dir is None:
        base_dir = Path(".")

    profile = ProjectProfile()

    # --- Language detection ---
    _detect_languages(base_dir, profile)

    # --- CI platform detection ---
    _detect_ci_platform(base_dir, profile)

    # --- Standards packs from README keywords ---
    _detect_packs_from_readme(base_dir, profile)

    # Always include owasp-top-10 as a baseline
    if "owasp-top-10" not in profile.suggested_packs:
        profile.suggested_packs.append("owasp-top-10")

    return profile


def _detect_languages(base_dir: Path, profile: ProjectProfile) -> None:
    """Detect programming languages from file markers."""
    lang_markers: list[tuple[list[str], list[str], str]] = [
        # (file markers, glob patterns, language name)
        (["pyproject.toml", "setup.py", "requirements.txt", "Pipfile"], ["*.py"], "python"),
        (["package.json", "tsconfig.json"], ["*.ts", "*.js"], "javascript"),
        (["tsconfig.json"], [], "typescript"),
        (["pom.xml", "build.gradle", "build.gradle.kts"], ["*.java"], "java"),
        (["go.mod"], ["*.go"], "go"),
        (["Cargo.toml"], ["*.rs"], "rust"),
        (["*.csproj", "*.sln"], ["*.cs"], "csharp"),
        (["CMakeLists.txt", "Makefile"], ["*.cpp", "*.cc", "*.cxx"], "cpp"),
        ([], ["*.c"], "c"),
        (["composer.json", "artisan"], ["*.php"], "php"),
        (["build.gradle.kts"], ["*.kt", "*.kts"], "kotlin"),
    ]

    for file_markers, glob_patterns, lang in lang_markers:
        found = False
        for marker in file_markers:
            if "*" in marker:
                if any(base_dir.glob(marker)):
                    found = True
                    break
            elif (base_dir / marker).exists():
                found = True
                break

        if not found:
            for pattern in glob_patterns:
                if any(base_dir.glob(pattern)):
                    found = True
                    break

        if found and lang not in profile.languages:
            profile.languages.append(lang)

    # Deduplicate: if typescript detected via tsconfig, javascript may also match
    if "typescript" in profile.languages and "javascript" in profile.languages:
        # Keep both — project uses both TS and JS
        pass


def _detect_ci_platform(base_dir: Path, profile: ProjectProfile) -> None:
    """Detect CI/CD platform from directory markers."""
    if (base_dir / ".github" / "workflows").is_dir() or (base_dir / ".github").is_dir():
        profile.ci_platform = "github"
    elif (base_dir / "azure-pipelines.yml").exists():
        profile.ci_platform = "azure"
    elif (base_dir / ".gitlab-ci.yml").exists():
        profile.ci_platform = "gitlab"


def _detect_packs_from_readme(base_dir: Path, profile: ProjectProfile) -> None:
    """Suggest standards packs based on README content."""
    readme_names = ("README.md", "README.rst", "README.txt", "README")
    text = ""
    for name in readme_names:
        readme_path = base_dir / name
        if readme_path.exists():
            try:
                text = readme_path.read_text(encoding="utf-8", errors="ignore").upper()
            except OSError:
                pass
            break

    if any(kw in text for kw in ("IEC 62304", "IEC62304", "MEDICAL DEVICE", "MEDICAL DEVICES", "FDA", "EU MDR")):
        if "fda-iec-62304" not in profile.suggested_packs:
            profile.suggested_packs.append("fda-iec-62304")

    if any(kw in text for kw in ("SOC2", "SOC 2", "SOC-2")):
        if "soc2" not in profile.suggested_packs:
            profile.suggested_packs.append("soc2")

    # Auto-suggest php-security for PHP/Laravel projects
    if "php" in profile.languages:
        if "php-security" not in profile.suggested_packs:
            profile.suggested_packs.append("php-security")

    # Auto-suggest kotlin-security for Kotlin projects
    if "kotlin" in profile.languages:
        if "kotlin-security" not in profile.suggested_packs:
            profile.suggested_packs.append("kotlin-security")
