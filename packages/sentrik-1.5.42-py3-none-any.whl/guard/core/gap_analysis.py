"""Regulatory gap analysis — identify compliance gaps when standards change."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from guard.packs.registry import (
    diff_pack_rules,
    export_pack,
    list_available_packs,
    load_pack_rules,
)


def analyze_gap(
    pack_id: str,
    old_pack_path: Path | None = None,
    old_pack_data: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Generate a gap analysis for a single pack.

    Compares old pack rules against current rules and categorizes the
    compliance impact of each change.

    Either ``old_pack_path`` or ``old_pack_data`` must be provided.
    If neither is provided, returns a baseline report (all rules are "new").
    """
    import yaml

    current_rules = load_pack_rules(pack_id)
    if not current_rules:
        raise ValueError(f"Pack {pack_id!r} not found")

    # Load old rules
    if old_pack_path and old_pack_path.is_file():
        raw = yaml.safe_load(old_pack_path.read_text(encoding="utf-8"))
        old_rules = raw.get("rules", [])
        old_version = raw.get("version", "unknown")
    elif old_pack_data:
        old_rules = old_pack_data.get("rules", [])
        old_version = old_pack_data.get("version", "unknown")
    else:
        old_rules = []
        old_version = "none"

    # Get current pack metadata
    current_pack = export_pack(pack_id)
    current_version = current_pack.get("version", "unknown")

    # Diff rules
    diff = diff_pack_rules(old_rules, current_rules)

    # Categorize impact
    new_obligations = []
    removed_obligations = []
    strengthened_rules = []
    relaxed_rules = []

    old_by_id = {r["id"]: r for r in old_rules if "id" in r}
    new_by_id = {r["id"]: r for r in current_rules if "id" in r}

    for rule_id in diff["added"]:
        rule = new_by_id.get(rule_id, {})
        new_obligations.append({
            "rule_id": rule_id,
            "name": rule.get("name", ""),
            "type": rule.get("type", ""),
            "severity": rule.get("severity", ""),
            "clause": rule.get("clause", ""),
            "action_required": "Implement new control" if rule.get("type") != "documentation_obligation" else "Create documentation",
        })

    for rule_id in diff["removed"]:
        rule = old_by_id.get(rule_id, {})
        removed_obligations.append({
            "rule_id": rule_id,
            "name": rule.get("name", ""),
            "clause": rule.get("clause", ""),
        })

    _SEVERITY_RANK = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}

    for rule_id in diff["modified"]:
        old_sev = old_by_id.get(rule_id, {}).get("severity", "info")
        new_sev = new_by_id.get(rule_id, {}).get("severity", "info")
        old_rank = _SEVERITY_RANK.get(old_sev, 0)
        new_rank = _SEVERITY_RANK.get(new_sev, 0)

        changes = diff["details"].get(rule_id, [])
        entry = {
            "rule_id": rule_id,
            "name": new_by_id.get(rule_id, {}).get("name", ""),
            "changes": changes,
        }

        if new_rank > old_rank:
            entry["severity_change"] = f"{old_sev} → {new_sev}"
            strengthened_rules.append(entry)
        elif new_rank < old_rank:
            entry["severity_change"] = f"{old_sev} → {new_sev}"
            relaxed_rules.append(entry)
        else:
            strengthened_rules.append(entry)

    # Summary
    total_gaps = len(new_obligations) + len(strengthened_rules)
    blocking_gaps = sum(
        1 for o in new_obligations
        if o["severity"] in ("critical", "high")
    )

    return {
        "pack_id": pack_id,
        "pack_name": current_pack.get("name", pack_id),
        "old_version": old_version,
        "current_version": current_version,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "summary": {
            "total_gaps": total_gaps,
            "blocking_gaps": blocking_gaps,
            "new_obligations": len(new_obligations),
            "removed_obligations": len(removed_obligations),
            "strengthened_rules": len(strengthened_rules),
            "relaxed_rules": len(relaxed_rules),
            "unchanged_rules": len(diff["unchanged"]),
        },
        "new_obligations": new_obligations,
        "removed_obligations": removed_obligations,
        "strengthened_rules": strengthened_rules,
        "relaxed_rules": relaxed_rules,
    }


def format_gap_report(analysis: dict[str, Any]) -> str:
    """Format a gap analysis result as a human-readable report."""
    lines = []
    s = analysis["summary"]

    lines.append(f"Gap Analysis: {analysis['pack_name']}")
    lines.append(f"  Old version: {analysis['old_version']} → Current: {analysis['current_version']}")
    lines.append(f"  Generated: {analysis['timestamp'][:19]}Z")
    lines.append("")
    lines.append(f"  Total gaps:        {s['total_gaps']}")
    lines.append(f"  Blocking (crit/high): {s['blocking_gaps']}")
    lines.append(f"  New obligations:   {s['new_obligations']}")
    lines.append(f"  Removed:           {s['removed_obligations']}")
    lines.append(f"  Strengthened:      {s['strengthened_rules']}")
    lines.append(f"  Relaxed:           {s['relaxed_rules']}")
    lines.append(f"  Unchanged:         {s['unchanged_rules']}")

    if analysis["new_obligations"]:
        lines.append("")
        lines.append("  NEW OBLIGATIONS (action required):")
        for o in analysis["new_obligations"]:
            sev = o["severity"].upper()
            lines.append(f"    [{sev}] {o['rule_id']} — {o['name']}")
            lines.append(f"      Clause: {o['clause']}")
            lines.append(f"      Action: {o['action_required']}")

    if analysis["strengthened_rules"]:
        lines.append("")
        lines.append("  STRENGTHENED RULES:")
        for r in analysis["strengthened_rules"]:
            lines.append(f"    ~ {r['rule_id']} — {r['name']}")
            if "severity_change" in r:
                lines.append(f"      Severity: {r['severity_change']}")

    if analysis["relaxed_rules"]:
        lines.append("")
        lines.append("  RELAXED RULES:")
        for r in analysis["relaxed_rules"]:
            lines.append(f"    ~ {r['rule_id']} — {r['name']}")
            if "severity_change" in r:
                lines.append(f"      Severity: {r['severity_change']}")

    if analysis["removed_obligations"]:
        lines.append("")
        lines.append("  REMOVED OBLIGATIONS:")
        for o in analysis["removed_obligations"]:
            lines.append(f"    - {o['rule_id']} — {o['name']}")

    lines.append("")
    return "\n".join(lines)
