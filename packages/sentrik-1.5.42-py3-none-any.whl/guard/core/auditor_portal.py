"""Auditor portal — time-boxed, read-only access for external auditors.

Generates secure tokens that grant auditors a scoped, expiring view of
compliance state without exposing source code, secrets, or full file paths.
"""

from __future__ import annotations

import json
import secrets
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

# ── Default scopes ────────────────────────────────────────────────────

ALL_SCOPES = ["findings", "compliance", "audit_log", "evidence", "trends"]

# ── Storage path ──────────────────────────────────────────────────────

_TOKEN_FILENAME = "auditor_tokens.json"


def _storage_path() -> Path:
    """Return the path to the auditor tokens file (.sentrik/local/)."""
    local_dir = Path(".sentrik") / "local"
    local_dir.mkdir(parents=True, exist_ok=True)
    return local_dir / _TOKEN_FILENAME


# ── Data model ────────────────────────────────────────────────────────


@dataclass
class AuditorToken:
    token: str
    created_at: str
    expires_at: str
    auditor_name: str
    auditor_email: str
    access_scope: list[str] = field(default_factory=lambda: list(ALL_SCOPES))


# ── Persistence helpers ───────────────────────────────────────────────


def _load_tokens(path: Optional[Path] = None) -> list[dict]:
    p = path or _storage_path()
    if not p.exists():
        return []
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []


def _save_tokens(tokens: list[dict], path: Optional[Path] = None) -> None:
    p = path or _storage_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(tokens, indent=2), encoding="utf-8")


# ── Public API ────────────────────────────────────────────────────────


def generate_auditor_token(
    auditor_name: str,
    auditor_email: str,
    expires_hours: int = 72,
    scope: Optional[list[str]] = None,
    *,
    _storage: Optional[Path] = None,
) -> AuditorToken:
    """Create a new auditor access token and persist it.

    Args:
        auditor_name: Display name of the auditor.
        auditor_email: Email address of the auditor.
        expires_hours: Token lifetime in hours (default 72).
        scope: List of data scopes the auditor can view. Defaults to all.
        _storage: Override storage path (for testing).

    Returns:
        The newly created ``AuditorToken``.
    """
    now = datetime.now(timezone.utc)
    token = AuditorToken(
        token=secrets.token_urlsafe(32),
        created_at=now.strftime("%Y-%m-%dT%H:%M:%SZ"),
        expires_at=(now + timedelta(hours=expires_hours)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        auditor_name=auditor_name,
        auditor_email=auditor_email,
        access_scope=scope if scope is not None else list(ALL_SCOPES),
    )
    tokens = _load_tokens(_storage)
    tokens.append(asdict(token))
    _save_tokens(tokens, _storage)
    return token


def validate_auditor_token(
    token: str,
    *,
    _storage: Optional[Path] = None,
) -> Optional[AuditorToken]:
    """Look up a token and return it if valid and not expired.

    Returns ``None`` for unknown, expired, or malformed tokens.
    """
    tokens = _load_tokens(_storage)
    now = datetime.now(timezone.utc)
    for t in tokens:
        if t.get("token") == token:
            try:
                expires = datetime.strptime(t["expires_at"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
            except (KeyError, ValueError):
                return None
            if now >= expires:
                return None
            return AuditorToken(**{k: t[k] for k in AuditorToken.__dataclass_fields__ if k in t})
    return None


def revoke_auditor_token(
    token: str,
    *,
    _storage: Optional[Path] = None,
) -> bool:
    """Remove a token from storage. Returns ``True`` if found and removed."""
    tokens = _load_tokens(_storage)
    original_len = len(tokens)
    tokens = [t for t in tokens if t.get("token") != token]
    if len(tokens) == original_len:
        return False
    _save_tokens(tokens, _storage)
    return True


def revoke_by_prefix(
    prefix: str,
    *,
    _storage: Optional[Path] = None,
) -> int:
    """Revoke all tokens whose token string starts with *prefix*.

    Returns the number of tokens revoked.
    """
    tokens = _load_tokens(_storage)
    original_len = len(tokens)
    tokens = [t for t in tokens if not t.get("token", "").startswith(prefix)]
    removed = original_len - len(tokens)
    if removed:
        _save_tokens(tokens, _storage)
    return removed


def list_auditor_tokens(*, _storage: Optional[Path] = None) -> list[AuditorToken]:
    """Return all active (non-expired) tokens."""
    tokens = _load_tokens(_storage)
    now = datetime.now(timezone.utc)
    result: list[AuditorToken] = []
    for t in tokens:
        try:
            expires = datetime.strptime(t["expires_at"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        except (KeyError, ValueError):
            continue
        if now < expires:
            result.append(AuditorToken(**{k: t[k] for k in AuditorToken.__dataclass_fields__ if k in t}))
    return result
