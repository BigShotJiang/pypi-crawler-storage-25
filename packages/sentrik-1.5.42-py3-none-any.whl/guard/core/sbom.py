"""Software Bill of Materials (SBOM) generator.

Detects dependency manifests, parses them, and generates CycloneDX 1.5 or SPDX 2.3 JSON.
"""

from __future__ import annotations

import json
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# Manifest filenames to look for
MANIFEST_FILENAMES: list[str] = [
    "package.json",
    "package-lock.json",
    "requirements.txt",
    "Pipfile.lock",
    "poetry.lock",
    "pyproject.toml",
    "Cargo.toml",
    "Cargo.lock",
    "go.mod",
    "go.sum",
    "pom.xml",
    "build.gradle",
    "Gemfile.lock",
    "composer.json",
    "CMakeLists.txt",
    "conanfile.txt",
    "conanfile.py",
    "vcpkg.json",
]


@dataclass
class Component:
    """A single dependency component."""

    name: str
    version: str
    ecosystem: str  # npm, pypi, cargo, golang, maven, gem, composer
    scope: str = "required"  # required | optional | dev

    @property
    def purl(self) -> str:
        """Package URL per https://github.com/package-url/purl-spec."""
        # Encode name: npm uses "/" for scoped packages
        name = self.name
        if self.ecosystem == "golang":
            # Go modules use the full module path
            return f"pkg:golang/{name}@{self.version}"
        return f"pkg:{self.ecosystem}/{name}@{self.version}"


@dataclass
class SBOMMetadata:
    """Metadata about the project being scanned."""

    name: str = "unknown"
    version: str = "0.0.0"
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


def detect_manifests(repo_root: str | Path) -> list[Path]:
    """Find dependency manifest files in the repo root (non-recursive, top-level only)."""
    root = Path(repo_root)
    found: list[Path] = []
    for name in MANIFEST_FILENAMES:
        p = root / name
        if p.is_file():
            found.append(p)
    return sorted(found, key=lambda p: p.name)


def parse_dependencies(manifest_path: str | Path) -> list[Component]:
    """Parse a manifest file and extract dependency components.

    Supports: package.json, package-lock.json, requirements.txt, pyproject.toml,
    poetry.lock, Cargo.toml, Cargo.lock, go.mod, CMakeLists.txt.
    Other formats return an empty list for now.
    """
    path = Path(manifest_path)
    name = path.name

    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return []

    if name == "package.json":
        return _parse_package_json(text)
    if name == "requirements.txt":
        return _parse_requirements_txt(text)
    if name == "pyproject.toml":
        return _parse_pyproject_toml(text)
    if name == "Cargo.toml":
        return _parse_cargo_toml(text)
    if name == "go.mod":
        return _parse_go_mod(text)
    if name == "package-lock.json":
        return _parse_package_lock_json(text)
    if name == "poetry.lock":
        return _parse_poetry_lock(text)
    if name == "Cargo.lock":
        return _parse_cargo_lock(text)
    if name == "CMakeLists.txt":
        return _parse_cmake(text)
    if name == "conanfile.txt":
        return _parse_conanfile_txt(text)
    if name == "conanfile.py":
        return _parse_conanfile_py(text)
    if name == "vcpkg.json":
        return _parse_vcpkg_json(text)

    return []


def generate_cyclonedx(components: list[Component], metadata: SBOMMetadata | None = None) -> dict[str, Any]:
    """Generate a CycloneDX 1.5 JSON SBOM."""
    meta = metadata or SBOMMetadata()
    serial = f"urn:uuid:{uuid.uuid4()}"

    cdx_components = []
    for c in components:
        entry: dict[str, Any] = {
            "type": "library",
            "name": c.name,
            "version": c.version,
            "purl": c.purl,
        }
        if c.scope == "dev":
            entry["scope"] = "optional"
        cdx_components.append(entry)

    return {
        "bomFormat": "CycloneDX",
        "specVersion": "1.5",
        "serialNumber": serial,
        "version": 1,
        "metadata": {
            "timestamp": meta.timestamp,
            "component": {
                "type": "application",
                "name": meta.name,
                "version": meta.version,
            },
        },
        "components": cdx_components,
    }


def generate_spdx(components: list[Component], metadata: SBOMMetadata | None = None) -> dict[str, Any]:
    """Generate an SPDX 2.3 JSON SBOM."""
    meta = metadata or SBOMMetadata()
    doc_namespace = f"https://spdx.org/spdxdocs/{meta.name}-{uuid.uuid4()}"

    packages: list[dict[str, Any]] = []
    # The root package
    packages.append({
        "SPDXID": "SPDXRef-RootPackage",
        "name": meta.name,
        "versionInfo": meta.version,
        "downloadLocation": "NOASSERTION",
        "filesAnalyzed": False,
    })

    for i, c in enumerate(components):
        spdx_id = f"SPDXRef-Package-{i + 1}"
        packages.append({
            "SPDXID": spdx_id,
            "name": c.name,
            "versionInfo": c.version,
            "downloadLocation": "NOASSERTION",
            "externalRefs": [
                {
                    "referenceCategory": "PACKAGE-MANAGER",
                    "referenceType": "purl",
                    "referenceLocator": c.purl,
                }
            ],
        })

    return {
        "spdxVersion": "SPDX-2.3",
        "dataLicense": "CC0-1.0",
        "SPDXID": "SPDXRef-DOCUMENT",
        "name": meta.name,
        "documentNamespace": doc_namespace,
        "creationInfo": {
            "created": meta.timestamp,
            "creators": ["Tool: sentrik"],
        },
        "packages": packages,
    }


# ---------------------------------------------------------------------------
# Internal parsers
# ---------------------------------------------------------------------------


def _parse_package_json(text: str) -> list[Component]:
    """Parse package.json dependencies + devDependencies."""
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return []

    components: list[Component] = []

    for dep_key, scope in [("dependencies", "required"), ("devDependencies", "dev")]:
        deps = data.get(dep_key, {})
        if not isinstance(deps, dict):
            continue
        for name, version_spec in deps.items():
            # Strip leading ^, ~, >=, etc. to get a clean version
            version = re.sub(r"^[\^~>=<!\s]+", "", str(version_spec))
            if not version:
                version = "0.0.0"
            components.append(Component(name=name, version=version, ecosystem="npm", scope=scope))

    return components


def _parse_requirements_txt(text: str) -> list[Component]:
    """Parse requirements.txt lines like 'package==1.2.3'."""
    components: list[Component] = []
    for line in text.splitlines():
        line = line.strip()
        # Skip comments, blank lines, options, includes
        if not line or line.startswith("#") or line.startswith("-") or line.startswith("http"):
            continue
        # Handle name==version, name>=version, name~=version
        match = re.match(r"^([A-Za-z0-9_][A-Za-z0-9_.+-]*)\s*([=~!<>]=?)\s*(.+)", line)
        if match:
            name = match.group(1)
            version = match.group(3).split(",")[0].strip()
            components.append(Component(name=name, version=version, ecosystem="pypi"))
        else:
            # Just a name with no version
            name_only = re.match(r"^([A-Za-z0-9_][A-Za-z0-9_.+-]*)", line)
            if name_only:
                components.append(Component(name=name_only.group(1), version="0.0.0", ecosystem="pypi"))

    return components


def _parse_pyproject_toml(text: str) -> list[Component]:
    """Parse pyproject.toml [project.dependencies] (PEP 621)."""
    components: list[Component] = []

    # Simple TOML parser for the [project] dependencies array
    # Look for dependencies = [...] under [project]
    in_project = False
    in_deps = False
    bracket_depth = 0

    for line in text.splitlines():
        stripped = line.strip()

        # Track sections
        if re.match(r"^\[project\]\s*$", stripped):
            in_project = True
            in_deps = False
            continue
        if re.match(r"^\[", stripped) and not re.match(r"^\[project\]", stripped):
            if in_project:
                in_project = False
                in_deps = False
            continue

        if not in_project:
            continue

        # Look for dependencies = [
        if stripped.startswith("dependencies") and "=" in stripped:
            in_deps = True
            # Check for inline array
            after_eq = stripped.split("=", 1)[1].strip()
            if "[" in after_eq:
                bracket_depth += after_eq.count("[") - after_eq.count("]")
                # Parse items on this line
                _extract_pep621_deps(after_eq, components)
                if bracket_depth <= 0:
                    in_deps = False
            continue

        if in_deps:
            bracket_depth += stripped.count("[") - stripped.count("]")
            _extract_pep621_deps(stripped, components)
            if bracket_depth <= 0:
                in_deps = False

    return components


def _extract_pep621_deps(line: str, components: list[Component]) -> None:
    """Extract PEP 621 dependency specs from a line within the dependencies array."""
    # Find quoted strings: "requests>=2.31.0" or 'flask~=3.0'
    for match in re.finditer(r'["\']([^"\']+)["\']', line):
        spec = match.group(1).strip()
        if not spec:
            continue
        # Parse: name (optional extras) version-spec
        m = re.match(r"^([A-Za-z0-9_][A-Za-z0-9_.+-]*)(?:\[.*?\])?\s*([=~!<>]+)\s*(.+)", spec)
        if m:
            name = m.group(1)
            version = m.group(3).split(",")[0].strip()
            components.append(Component(name=name, version=version, ecosystem="pypi"))
        else:
            # Name only
            name_m = re.match(r"^([A-Za-z0-9_][A-Za-z0-9_.+-]*)", spec)
            if name_m:
                components.append(Component(name=name_m.group(1), version="0.0.0", ecosystem="pypi"))


def _parse_cargo_toml(text: str) -> list[Component]:
    """Parse Cargo.toml [dependencies] section."""
    components: list[Component] = []
    in_deps = False

    for line in text.splitlines():
        stripped = line.strip()

        # Track sections
        if re.match(r"^\[dependencies\]\s*$", stripped):
            in_deps = True
            continue
        if re.match(r"^\[", stripped) and stripped != "[dependencies]":
            in_deps = False
            continue

        if not in_deps:
            continue

        # name = "version" or name = { version = "..." }
        m = re.match(r'^([a-zA-Z0-9_-]+)\s*=\s*"([^"]*)"', stripped)
        if m:
            components.append(Component(name=m.group(1), version=m.group(2), ecosystem="cargo"))
            continue

        # name = { version = "..." ... }
        m2 = re.match(r'^([a-zA-Z0-9_-]+)\s*=\s*\{.*?version\s*=\s*"([^"]*)"', stripped)
        if m2:
            components.append(Component(name=m2.group(1), version=m2.group(2), ecosystem="cargo"))

    return components


def _parse_go_mod(text: str) -> list[Component]:
    """Parse go.mod require blocks."""
    components: list[Component] = []
    in_require = False

    for line in text.splitlines():
        stripped = line.strip()

        # Single-line require
        m = re.match(r"^require\s+(\S+)\s+(v\S+)", stripped)
        if m:
            components.append(Component(name=m.group(1), version=m.group(2), ecosystem="golang"))
            continue

        # Multi-line require block
        if stripped.startswith("require (") or stripped == "require (":
            in_require = True
            continue
        if in_require and stripped == ")":
            in_require = False
            continue

        if in_require:
            parts = stripped.split()
            if len(parts) >= 2 and parts[1].startswith("v"):
                # Skip lines with // indirect marker — still include them
                components.append(Component(name=parts[0], version=parts[1], ecosystem="golang"))

    return components


def _parse_package_lock_json(text: str) -> list[Component]:
    """Parse package-lock.json for the full transitive dependency tree.

    Supports npm v7+ (``packages`` field) and npm v6 (``dependencies`` field).
    """
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return []

    components: list[Component] = []
    seen: set[tuple[str, str]] = set()

    # npm v7+ uses "packages" — keys are node_modules paths, root is ""
    packages = data.get("packages")
    if isinstance(packages, dict):
        for key, info in packages.items():
            if key == "":
                # Root package — skip
                continue
            if not isinstance(info, dict):
                continue
            version = info.get("version", "")
            # Extract package name from the key (last node_modules/... segment)
            # e.g. "node_modules/@scope/pkg" -> "@scope/pkg"
            #      "node_modules/a/node_modules/b" -> "b"
            parts = key.split("node_modules/")
            name = parts[-1] if parts else key
            if not name or not version:
                continue
            if (name, version) not in seen:
                seen.add((name, version))
                dev = info.get("dev", False)
                scope = "dev" if dev else "required"
                components.append(Component(name=name, version=version, ecosystem="npm", scope=scope))
        return components

    # npm v6 fallback — flat "dependencies" object
    deps = data.get("dependencies")
    if isinstance(deps, dict):
        _extract_npm_v6_deps(deps, components, seen)

    return components


def _extract_npm_v6_deps(
    deps: dict[str, Any],
    components: list[Component],
    seen: set[tuple[str, str]],
) -> None:
    """Recursively extract dependencies from npm v6 lockfile format."""
    for name, info in deps.items():
        if not isinstance(info, dict):
            continue
        version = info.get("version", "")
        if not version:
            continue
        if (name, version) not in seen:
            seen.add((name, version))
            dev = info.get("dev", False)
            scope = "dev" if dev else "required"
            components.append(Component(name=name, version=version, ecosystem="npm", scope=scope))
        # Recurse into nested dependencies
        nested = info.get("dependencies")
        if isinstance(nested, dict):
            _extract_npm_v6_deps(nested, components, seen)


def _parse_poetry_lock(text: str) -> list[Component]:
    """Parse poetry.lock ``[[package]]`` sections using regex (no toml library needed)."""
    components: list[Component] = []

    # Split on [[package]] headers and parse each block
    blocks = re.split(r"^\[\[package\]\]\s*$", text, flags=re.MULTILINE)
    for block in blocks:
        name_m = re.search(r'^name\s*=\s*"([^"]+)"', block, re.MULTILINE)
        version_m = re.search(r'^version\s*=\s*"([^"]+)"', block, re.MULTILINE)
        if name_m and version_m:
            components.append(
                Component(
                    name=name_m.group(1),
                    version=version_m.group(1),
                    ecosystem="pypi",
                )
            )

    return components


def _parse_cargo_lock(text: str) -> list[Component]:
    """Parse Cargo.lock ``[[package]]`` sections using regex (no toml library needed).

    Skips the root package (typically the first entry whose source is not set).
    """
    components: list[Component] = []

    blocks = re.split(r"^\[\[package\]\]\s*$", text, flags=re.MULTILINE)
    for block in blocks:
        name_m = re.search(r'^name\s*=\s*"([^"]+)"', block, re.MULTILINE)
        version_m = re.search(r'^version\s*=\s*"([^"]+)"', block, re.MULTILINE)
        if name_m and version_m:
            # Skip entries without a source — they are the root crate
            source_m = re.search(r'^source\s*=', block, re.MULTILINE)
            if not source_m:
                continue
            components.append(
                Component(
                    name=name_m.group(1),
                    version=version_m.group(1),
                    ecosystem="cargo",
                )
            )

    return components


def _parse_cmake(text: str) -> list[Component]:
    """Parse CMakeLists.txt for find_package and FetchContent_Declare dependencies."""
    components: list[Component] = []

    # find_package(Name) or find_package(Name VERSION REQUIRED ...)
    # Version is optional and appears right after the name as a bare version number.
    for m in re.finditer(
        r"find_package\s*\(\s*(\w+)(?:\s+(\d[\d.]*))?",
        text,
    ):
        name = m.group(1)
        version = m.group(2) or ""
        components.append(Component(name=name, version=version, ecosystem="cmake"))

    # FetchContent_Declare — may span multiple lines.
    # Collect the full parenthesised block, handling multiline.
    for m in re.finditer(
        r"FetchContent_Declare\s*\(([^)]+)\)",
        text,
        re.DOTALL,
    ):
        block = m.group(1).strip()
        tokens = block.split()
        if not tokens:
            continue
        dep_name = tokens[0]
        version = ""

        # Try GIT_TAG first
        git_tag_match = re.search(r"GIT_TAG\s+(\S+)", block)
        if git_tag_match:
            version = git_tag_match.group(1)
        else:
            # Try URL with version tag pattern: /v1.2.3.tar.gz or /v1.2.3.zip
            url_match = re.search(r"URL\s+(\S+)", block)
            if url_match:
                url = url_match.group(1)
                ver_match = re.search(r"/v?(\d+(?:\.\d+)+)", url)
                if ver_match:
                    version = ver_match.group(1)

        components.append(Component(name=dep_name, version=version, ecosystem="cmake"))

    return components


def _parse_conanfile_txt(text: str) -> list[Component]:
    """Parse conanfile.txt for Conan C/C++ dependencies.

    Format:
        [requires]
        openssl/3.2.0
        zlib/1.3.1
        boost/1.84.0

    Each line under [requires] is name/version.
    """
    components: list[Component] = []
    in_requires = False

    for line in text.splitlines():
        stripped = line.strip()
        if stripped.lower() == "[requires]":
            in_requires = True
            continue
        if stripped.startswith("[") and stripped.endswith("]"):
            in_requires = False
            continue
        if not in_requires or not stripped or stripped.startswith("#"):
            continue

        # name/version or name/version@user/channel
        parts = stripped.split("@")[0].split("/")
        if len(parts) >= 2:
            name = parts[0]
            version = parts[1]
            components.append(Component(name=name, version=version, ecosystem="conan"))

    return components


def _parse_conanfile_py(text: str) -> list[Component]:
    """Parse conanfile.py for Conan C/C++ dependencies.

    Looks for:
        requires = "openssl/3.2.0", "zlib/1.3.1"
        self.requires("boost/1.84.0")
    """
    components: list[Component] = []

    # Match self.requires("name/version") or self.requires("name/version@user/channel")
    for m in re.finditer(r'self\.requires\s*\(\s*["\']([^"\']+/[^"\']+)["\']', text):
        ref = m.group(1).split("@")[0]
        parts = ref.split("/")
        if len(parts) >= 2:
            components.append(Component(name=parts[0], version=parts[1], ecosystem="conan"))

    # Match requires = "name/version", "name/version" (class-level attribute)
    for m in re.finditer(r'requires\s*=\s*(.+)', text):
        line = m.group(1)
        for ref_match in re.finditer(r'["\']([^"\']+/[^"\']+)["\']', line):
            ref = ref_match.group(1).split("@")[0]
            parts = ref.split("/")
            if len(parts) >= 2:
                components.append(Component(name=parts[0], version=parts[1], ecosystem="conan"))

    return components


def _parse_vcpkg_json(text: str) -> list[Component]:
    """Parse vcpkg.json for vcpkg C/C++ dependencies.

    Format:
        {
          "dependencies": [
            "openssl",
            { "name": "boost", "version>=": "1.84.0" },
            { "name": "zlib" }
          ],
          "overrides": [
            { "name": "openssl", "version": "3.2.0" }
          ]
        }
    """
    components: list[Component] = []
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return []

    # Build version map from overrides (most precise)
    version_map: dict[str, str] = {}
    for override in data.get("overrides", []):
        if isinstance(override, dict):
            name = override.get("name", "")
            version = override.get("version", "")
            if name and version:
                version_map[name] = version

    # Parse dependencies
    for dep in data.get("dependencies", []):
        if isinstance(dep, str):
            name = dep
            version = version_map.get(name, "")
            components.append(Component(name=name, version=version, ecosystem="vcpkg"))
        elif isinstance(dep, dict):
            name = dep.get("name", "")
            if not name:
                continue
            version = dep.get("version>=", dep.get("version", version_map.get(name, "")))
            components.append(Component(name=name, version=version, ecosystem="vcpkg"))

    return components
