"""SQLite-based metrics storage for long-term scan trend analysis."""

from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_DEFAULT_DB_PATH = ".sentrik/local/metrics.db"


class MetricsDB:
    """Persistent SQLite store for scan and vulnerability scan results.

    Records are appended after every scan so the dashboard can display
    historical trends without relying on the file-based history directory.
    """

    def __init__(self, db_path: str | Path | None = None):
        self._db_path = Path(db_path) if db_path else Path(_DEFAULT_DB_PATH)
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._db_path))
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------

    def _init_schema(self) -> None:
        """Create tables if they do not already exist."""
        with self._conn:
            self._conn.executescript(
                """\
                CREATE TABLE IF NOT EXISTS scan_runs (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id          TEXT UNIQUE,
                    timestamp       TEXT NOT NULL,
                    command         TEXT,
                    findings_total  INTEGER NOT NULL DEFAULT 0,
                    critical        INTEGER NOT NULL DEFAULT 0,
                    high            INTEGER NOT NULL DEFAULT 0,
                    medium          INTEGER NOT NULL DEFAULT 0,
                    low             INTEGER NOT NULL DEFAULT 0,
                    info            INTEGER NOT NULL DEFAULT 0,
                    compliance_score REAL,
                    rules_total     INTEGER NOT NULL DEFAULT 0,
                    rules_passed    INTEGER NOT NULL DEFAULT 0,
                    files_scanned   INTEGER NOT NULL DEFAULT 0,
                    duration_ms     REAL NOT NULL DEFAULT 0.0,
                    gate_passed     INTEGER
                );

                CREATE TABLE IF NOT EXISTS vuln_scans (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp       TEXT NOT NULL,
                    total_deps      INTEGER NOT NULL DEFAULT 0,
                    vulnerable_count INTEGER NOT NULL DEFAULT 0,
                    critical        INTEGER NOT NULL DEFAULT 0,
                    high            INTEGER NOT NULL DEFAULT 0,
                    medium          INTEGER NOT NULL DEFAULT 0,
                    low             INTEGER NOT NULL DEFAULT 0
                );
                """
            )

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def record_scan(
        self,
        run_metadata: dict[str, Any],
        findings_summary: dict[str, int],
        compliance_score: float | None = None,
        gate_passed: bool | None = None,
    ) -> None:
        """Insert a scan run record.

        Args:
            run_metadata: Dict with keys ``run_id``, ``timestamp``,
                ``command``, ``duration_ms``, ``findings_count``.
            findings_summary: Severity breakdown, e.g.
                ``{"critical": 2, "high": 1, ...}``.
            compliance_score: Overall compliance score (0-100).
            gate_passed: Whether the quality gate passed.
        """
        run_id = run_metadata.get("run_id", "")
        timestamp = run_metadata.get("timestamp", datetime.now(timezone.utc).isoformat())
        command = run_metadata.get("command", "")
        duration_ms = run_metadata.get("duration_ms", 0.0)
        findings_total = run_metadata.get("findings_count", 0)
        files_scanned = run_metadata.get("files_scanned", 0)
        rules_total = run_metadata.get("rules_total", 0)
        rules_passed = run_metadata.get("rules_passed", 0)

        # If compliance_score is a dict (from calculate_compliance_score),
        # extract the numeric score and rule counts.
        if isinstance(compliance_score, dict):
            rules_total = compliance_score.get("rules_total", rules_total)
            rules_passed = compliance_score.get("rules_passed", rules_passed)
            compliance_score = compliance_score.get("score")

        try:
            with self._conn:
                self._conn.execute(
                    """\
                    INSERT OR IGNORE INTO scan_runs
                        (run_id, timestamp, command, findings_total,
                         critical, high, medium, low, info,
                         compliance_score, rules_total, rules_passed,
                         files_scanned, duration_ms, gate_passed)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_id,
                        timestamp,
                        command,
                        findings_total,
                        findings_summary.get("critical", 0),
                        findings_summary.get("high", 0),
                        findings_summary.get("medium", 0),
                        findings_summary.get("low", 0),
                        findings_summary.get("info", 0),
                        compliance_score,
                        rules_total,
                        rules_passed,
                        files_scanned,
                        duration_ms,
                        int(gate_passed) if gate_passed is not None else None,
                    ),
                )
        except sqlite3.Error:
            logger.warning("Failed to record scan to metrics DB", exc_info=True)

    def record_vuln_scan(self, vuln_result: dict[str, Any]) -> None:
        """Insert a vulnerability scan record.

        Args:
            vuln_result: Dict from ``result_to_dict()`` with keys
                ``total_dependencies``, ``vulnerable_count``,
                ``by_severity``, ``scan_timestamp``.
        """
        timestamp = vuln_result.get(
            "scan_timestamp", datetime.now(timezone.utc).isoformat()
        )
        total_deps = vuln_result.get("total_dependencies", 0)
        vulnerable_count = vuln_result.get("vulnerable_count", 0)
        by_sev = vuln_result.get("by_severity", {})

        try:
            with self._conn:
                self._conn.execute(
                    """\
                    INSERT INTO vuln_scans
                        (timestamp, total_deps, vulnerable_count,
                         critical, high, medium, low)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        timestamp,
                        total_deps,
                        vulnerable_count,
                        by_sev.get("critical", 0),
                        by_sev.get("high", 0),
                        by_sev.get("medium", 0),
                        by_sev.get("low", 0),
                    ),
                )
        except sqlite3.Error:
            logger.warning("Failed to record vuln scan to metrics DB", exc_info=True)

    # ------------------------------------------------------------------
    # Read operations
    # ------------------------------------------------------------------

    def get_scan_history(self, limit: int = 100) -> list[dict[str, Any]]:
        """Return recent scan runs ordered by timestamp descending."""
        cursor = self._conn.execute(
            "SELECT * FROM scan_runs ORDER BY timestamp DESC LIMIT ?",
            (limit,),
        )
        return [dict(row) for row in cursor.fetchall()]

    def get_trend_data(self, days: int = 90) -> list[dict[str, Any]]:
        """Return scan data grouped by day for trend charts.

        Each entry contains the date, total findings by severity
        (summed across all scans that day), scan count, and average
        compliance score.
        """
        cursor = self._conn.execute(
            """\
            SELECT
                date(timestamp) AS day,
                COUNT(*)        AS scan_count,
                SUM(findings_total) AS total_findings,
                SUM(critical)   AS critical,
                SUM(high)       AS high,
                SUM(medium)     AS medium,
                SUM(low)        AS low,
                SUM(info)       AS info,
                AVG(compliance_score) AS avg_compliance,
                AVG(duration_ms)      AS avg_duration_ms
            FROM scan_runs
            WHERE timestamp >= date('now', ?)
            GROUP BY date(timestamp)
            ORDER BY day ASC
            """,
            (f"-{days} days",),
        )
        return [dict(row) for row in cursor.fetchall()]

    def get_compliance_trend(self, days: int = 90) -> list[dict[str, Any]]:
        """Return compliance scores over time for trend charts."""
        cursor = self._conn.execute(
            """\
            SELECT
                run_id,
                timestamp,
                compliance_score,
                findings_total,
                command
            FROM scan_runs
            WHERE timestamp >= date('now', ?)
              AND compliance_score IS NOT NULL
            ORDER BY timestamp ASC
            """,
            (f"-{days} days",),
        )
        return [dict(row) for row in cursor.fetchall()]

    def get_stats(self) -> dict[str, Any]:
        """Return aggregate statistics across all recorded scans."""
        row = self._conn.execute(
            """\
            SELECT
                COUNT(*)              AS total_scans,
                AVG(compliance_score) AS avg_compliance,
                MIN(compliance_score) AS min_compliance,
                MAX(compliance_score) AS max_compliance,
                AVG(findings_total)   AS avg_findings,
                SUM(findings_total)   AS total_findings,
                AVG(duration_ms)      AS avg_duration_ms,
                MIN(timestamp)        AS first_scan,
                MAX(timestamp)        AS last_scan,
                SUM(CASE WHEN gate_passed = 1 THEN 1 ELSE 0 END) AS gates_passed,
                SUM(CASE WHEN gate_passed = 0 THEN 1 ELSE 0 END) AS gates_failed
            FROM scan_runs
            """
        ).fetchone()

        if row is None or row["total_scans"] == 0:
            return {
                "total_scans": 0,
                "avg_compliance": None,
                "min_compliance": None,
                "max_compliance": None,
                "avg_findings": 0,
                "total_findings": 0,
                "avg_duration_ms": 0,
                "first_scan": None,
                "last_scan": None,
                "gates_passed": 0,
                "gates_failed": 0,
            }

        return dict(row)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Close the database connection."""
        self._conn.close()

    def __enter__(self) -> "MetricsDB":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
