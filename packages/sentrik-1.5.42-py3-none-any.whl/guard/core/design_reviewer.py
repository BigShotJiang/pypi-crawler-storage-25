"""Design Decision Auditing — surface implicit design decisions in AI-generated code.

Uses LLM analysis to identify significant design decisions (framework choices,
data structures, auth patterns, API design tradeoffs) and present them as
questions for developer review rather than pass/fail findings.
"""

from __future__ import annotations

import json
import logging
import subprocess
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from guard.core.project_profile import load_profile
from guard.providers.llm_base import LLMProvider

logger = logging.getLogger(__name__)

_CATEGORIES = [
    "architecture",
    "data-model",
    "security-pattern",
    "dependency-choice",
    "performance-tradeoff",
    "error-handling",
    "state-management",
]

_REVIEW_PROMPT = """\
You are a senior software architect reviewing code changes. Identify significant \
design decisions — choices that a thoughtful engineer would want to consciously \
make rather than accept from AI-generated code.

Focus on decisions that:
- Choose one approach over reasonable alternatives
- Have implications at scale or over time
- Affect security, performance, or maintainability
- Introduce new patterns not established in the project

Do NOT flag:
- Trivial formatting or naming choices
- Standard library usage
- Obvious best practices

PROJECT CONTEXT:
{project_context}

CODE CHANGES:
{code_changes}

Return ONLY valid JSON (no markdown fences):
{{
  "decisions": [
    {{
      "category": "architecture|data-model|security-pattern|dependency-choice|performance-tradeoff|error-handling|state-management",
      "summary": "One-line description of the decision",
      "file": "path/to/file.py",
      "line_start": 10,
      "line_end": 25,
      "alternatives": ["Alternative approach 1", "Alternative approach 2"],
      "risk": "What could go wrong with this choice at scale or over time",
      "question": "A specific question to prompt developer review"
    }}
  ]
}}

If no significant decisions are found, return {{"decisions": []}}.
"""

_FILE_REVIEW_PROMPT = """\
You are a senior software architect auditing an existing codebase. Surface the most \
significant design decisions embedded in this code — choices a thoughtful engineer \
would want to be consciously aware of and potentially revisit.

Focus on decisions that:
- Choose one architectural approach over reasonable alternatives
- Have long-term implications for security, performance, or maintainability
- Introduce patterns that define how the system fundamentally works
- Represent meaningful tradeoffs (simplicity vs flexibility, coupling vs decoupling, etc.)
- Depend on a library or technology in a way that creates significant coupling

Do NOT flag:
- Trivial formatting or naming conventions
- Standard library usage with no meaningful alternatives
- Obvious well-established best practices

PROJECT CONTEXT:
{project_context}

SOURCE FILES:
{file_contents}

Return ONLY valid JSON (no markdown fences):
{{
  "decisions": [
    {{
      "category": "architecture|data-model|security-pattern|dependency-choice|performance-tradeoff|error-handling|state-management",
      "summary": "One-line description of the decision made",
      "file": "path/to/file.py",
      "line_start": 10,
      "line_end": 25,
      "alternatives": ["Alternative approach 1", "Alternative approach 2"],
      "risk": "What could go wrong with this choice at scale or over time",
      "question": "A specific question to prompt developer reflection on this decision"
    }}
  ]
}}

Find 5-15 significant decisions across the files. Focus on the most architecturally important choices.
If there are truly no noteworthy decisions, return {{"decisions": []}}.
"""


@dataclass
class DesignDecision:
    decision_id: str
    category: str
    summary: str
    file: str
    line_start: int = 0
    line_end: int = 0
    alternatives: list[str] = field(default_factory=list)
    risk: str = ""
    question: str = ""
    acknowledged: bool = False
    acknowledgment_note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "decision_id": self.decision_id,
            "category": self.category,
            "summary": self.summary,
            "file": self.file,
            "line_start": self.line_start,
            "line_end": self.line_end,
            "alternatives": self.alternatives,
            "risk": self.risk,
            "question": self.question,
            "acknowledged": self.acknowledged,
            "acknowledgment_note": self.acknowledgment_note,
        }


_MAX_DIFF_BYTES = 50_000


def get_diff(git_range: str | None = None, file_path: str | None = None, repo_root: str = ".") -> str:
    """Get code changes as a diff string."""
    if file_path:
        path = Path(repo_root) / file_path
        if path.is_file():
            return f"--- {file_path} ---\n{path.read_text(encoding='utf-8', errors='replace')}"
        return ""

    if git_range:
        try:
            result = subprocess.run(
                ["git", "diff", git_range],
                capture_output=True, text=True, timeout=15, cwd=repo_root,
            )
            if result.returncode == 0:
                diff = result.stdout
                if len(diff.encode()) > _MAX_DIFF_BYTES:
                    diff = diff[:_MAX_DIFF_BYTES] + "\n... (truncated)"
                return diff
        except (OSError, subprocess.TimeoutExpired):
            pass

    # Default: staged changes
    try:
        result = subprocess.run(
            ["git", "diff", "--cached"],
            capture_output=True, text=True, timeout=15, cwd=repo_root,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout[:_MAX_DIFF_BYTES]
    except (OSError, subprocess.TimeoutExpired):
        pass

    # Fallback: unstaged changes
    try:
        result = subprocess.run(
            ["git", "diff"],
            capture_output=True, text=True, timeout=15, cwd=repo_root,
        )
        if result.returncode == 0:
            return result.stdout[:_MAX_DIFF_BYTES]
    except (OSError, subprocess.TimeoutExpired):
        pass

    return ""


def review_design(
    llm: LLMProvider,
    code_changes: str,
    output_dir: str = "out",
    repo_root: str = ".",
) -> list[DesignDecision]:
    """Analyze code changes for design decisions using LLM."""
    if not code_changes.strip():
        return []

    # Build project context
    profile = load_profile(output_dir)
    if profile:
        ctx_parts = []
        if profile.get("frameworks"):
            ctx_parts.append(f"Frameworks: {', '.join(f['name'] for f in profile['frameworks'])}")
        if profile.get("architecture"):
            ctx_parts.append(f"Patterns: {', '.join(p['pattern'] for p in profile['architecture'])}")
        if profile.get("conventions"):
            ctx_parts.append(f"Conventions: {json.dumps(profile['conventions'])}")
        project_context = "\n".join(ctx_parts) or "No project profile available."
    else:
        project_context = "No project profile available. Run 'sentrik profile' to build one."

    prompt = _REVIEW_PROMPT.format(
        project_context=project_context,
        code_changes=code_changes,
    )

    try:
        # Use chat() directly — analyze() is designed for file scanning and appends
        # "File: (unknown)" noise that confuses the design review prompt.
        raw_text = llm.chat([{"role": "user", "content": prompt}])
        return _parse_chat_response(raw_text)
    except Exception as exc:
        logger.warning("Design review failed: %s", exc)
        return []


def _parse_decisions(decisions_raw: list[Any]) -> list[DesignDecision]:
    """Convert a list of raw dicts into DesignDecision objects."""
    decisions = []
    for d in decisions_raw:
        if not isinstance(d, dict):
            continue
        category = d.get("category", "architecture")
        if category not in _CATEGORIES:
            category = "architecture"
        decisions.append(DesignDecision(
            decision_id=f"DD-{uuid.uuid4().hex[:6].upper()}",
            category=category,
            summary=d.get("summary", "Design decision detected"),
            file=d.get("file", ""),
            line_start=d.get("line_start", 0),
            line_end=d.get("line_end", 0),
            alternatives=d.get("alternatives", []),
            risk=d.get("risk", ""),
            question=d.get("question", ""),
        ))
    return decisions


def _parse_chat_response(text: str) -> list[DesignDecision]:
    """Parse raw LLM chat text into DesignDecision objects."""
    start = text.find("{")
    end = text.rfind("}") + 1
    if start == -1 or end == 0:
        return []
    try:
        data = json.loads(text[start:end])
    except json.JSONDecodeError:
        return []
    return _parse_decisions(data.get("decisions", []))


def _parse_response(response: dict[str, Any]) -> list[DesignDecision]:
    """Parse LLM analyze() response dict into DesignDecision objects (legacy CLI path)."""
    data = response
    if "summary" in response and isinstance(response["summary"], str):
        try:
            data = json.loads(response["summary"])
        except (json.JSONDecodeError, TypeError):
            pass
    return _parse_decisions(data.get("decisions", []))


def format_decisions(decisions: list[DesignDecision]) -> str:
    """Format design decisions as human-readable text."""
    if not decisions:
        return "\nNo significant design decisions detected.\n"

    lines = [f"\n{len(decisions)} design decision(s) found:\n"]

    for i, d in enumerate(decisions, 1):
        lines.append(f"  {i}. [{d.category.upper()}] {d.summary}")
        if d.file:
            loc = d.file
            if d.line_start:
                loc += f":{d.line_start}"
                if d.line_end and d.line_end != d.line_start:
                    loc += f"-{d.line_end}"
            lines.append(f"     File: {loc}")
        if d.alternatives:
            lines.append(f"     Alternatives:")
            for alt in d.alternatives:
                lines.append(f"       - {alt}")
        if d.risk:
            lines.append(f"     Risk: {d.risk}")
        if d.question:
            lines.append(f"     ? {d.question}")
        lines.append("")

    return "\n".join(lines)


def review_design_from_files(
    llm: LLMProvider,
    files: list[Path],
    root: str | Path = ".",
    output_dir: str = "out",
    max_files: int = 22,
) -> list[DesignDecision]:
    """Analyze codebase source files for embedded design decisions.

    Used by the dashboard "Run Review" button to scan the full project
    rather than just a recent diff.
    """
    root = Path(root)

    # Exclude test/spec/migration/generated files — decisions live in production code
    _skip_name_kws = ("test", "spec", "mock", "stub", "fixture", "migration", "seed", "generated")
    _skip_dirs = {"tests", "test", "spec", "specs", "migrations", "fixtures", "__pycache__",
                  "node_modules", ".venv", "venv", "dist", "build", "out"}

    core_files = [
        f for f in files
        if not any(part in _skip_dirs for part in f.parts)
        and not any(kw in f.stem.lower() for kw in _skip_name_kws)
    ]

    # Sort by file size descending — bigger files tend to have richer decisions
    try:
        core_files.sort(key=lambda f: f.stat().st_size, reverse=True)
    except OSError:
        pass

    sampled = core_files[:max_files] or files[:max_files]

    # Build file content corpus, capping each file at 3 KB and total at 50 KB
    content_parts: list[str] = []
    total_bytes = 0
    for f in sampled:
        if total_bytes >= 50_000:
            break
        try:
            rel = str(f.relative_to(root)).replace("\\", "/")
            text = f.read_text(encoding="utf-8", errors="replace")[:3000]
            chunk = f"=== {rel} ===\n{text}\n"
            content_parts.append(chunk)
            total_bytes += len(chunk)
        except (OSError, ValueError):
            continue

    if not content_parts:
        return []

    # Build project context from saved profile
    profile = load_profile(output_dir)
    if profile:
        ctx_parts = []
        if profile.get("frameworks"):
            ctx_parts.append(f"Frameworks: {', '.join(f['name'] for f in profile['frameworks'])}")
        if profile.get("architecture"):
            ctx_parts.append(f"Architecture patterns: {', '.join(p['pattern'] for p in profile['architecture'])}")
        if profile.get("conventions"):
            ctx_parts.append(f"Conventions: {json.dumps(profile['conventions'])}")
        project_context = "\n".join(ctx_parts) or "No project profile available."
    else:
        project_context = "No project profile available. Run 'sentrik profile' to build one."

    prompt = _FILE_REVIEW_PROMPT.format(
        project_context=project_context,
        file_contents="\n".join(content_parts),
    )

    try:
        raw_text = llm.chat([{"role": "user", "content": prompt}])
        return _parse_chat_response(raw_text)
    except Exception as exc:
        logger.warning("Design review (codebase mode) failed: %s", exc)
        return []


def save_decisions(decisions: list[DesignDecision], output_dir: str = "out") -> Path:
    """Save decisions to out/design_decisions.json."""
    import datetime
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / "design_decisions.json"
    data = {
        "generated_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "decisions": [d.to_dict() for d in decisions],
    }
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return path


def load_decisions(output_dir: str = "out") -> list[DesignDecision]:
    """Load decisions from out/design_decisions.json."""
    path = Path(output_dir) / "design_decisions.json"
    if not path.is_file():
        return []
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        # Support both old bare-list format and new {generated_at, decisions} format
        items = raw if isinstance(raw, list) else raw.get("decisions", [])
        return [DesignDecision(**d) for d in items]
    except (json.JSONDecodeError, OSError, TypeError):
        return []


def load_decisions_with_meta(output_dir: str = "out") -> dict:
    """Load decisions file including metadata (generated_at)."""
    path = Path(output_dir) / "design_decisions.json"
    if not path.is_file():
        return {"generated_at": None, "decisions": []}
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(raw, list):
            return {"generated_at": None, "decisions": [d.to_dict() for d in load_decisions(output_dir)]}
        return {
            "generated_at": raw.get("generated_at"),
            "decisions": raw.get("decisions", []),
        }
    except (json.JSONDecodeError, OSError):
        return {"generated_at": None, "decisions": []}


def acknowledge_decision(
    decision_id: str,
    note: str = "",
    output_dir: str = "out",
) -> bool:
    """Mark a decision as acknowledged."""
    decisions = load_decisions(output_dir)
    for d in decisions:
        if d.decision_id == decision_id:
            d.acknowledged = True
            d.acknowledgment_note = note
            save_decisions(decisions, output_dir)
            return True
    return False
