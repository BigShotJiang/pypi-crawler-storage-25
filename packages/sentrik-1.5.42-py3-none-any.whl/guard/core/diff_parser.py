"""Diff parsing utilities for scoping analysis to changed files."""

from __future__ import annotations

import re
import subprocess

from guard.core.models import DiffHunk, FileDiff

_DIFF_HEADER = re.compile(r"^diff --git ", re.MULTILINE)
_HUNK_HEADER = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", re.MULTILINE)


def parse_diff(diff_text: str) -> list[FileDiff]:
    """Parse a unified diff into structured FileDiff objects."""
    if not diff_text or not diff_text.strip():
        return []

    # Split on diff headers, keeping the header with each block
    parts = _DIFF_HEADER.split(diff_text)
    # First element is anything before the first 'diff --git' — discard it
    blocks = parts[1:]

    results: list[FileDiff] = []
    for block in blocks:
        # Re-add the stripped prefix for consistent parsing
        full_block = "diff --git " + block
        file_diff = _parse_single_diff(full_block)
        if file_diff is not None:
            results.append(file_diff)

    return results


def _parse_single_diff(block: str) -> FileDiff | None:
    """Parse a single file's diff block."""
    lines = block.split("\n")
    if not lines:
        return None

    old_path = ""
    new_path = ""
    is_binary = False
    is_rename = False
    is_new = False
    is_deleted = False

    # Parse the 'diff --git a/X b/Y' header
    header = lines[0]
    match = re.match(r"diff --git a/(.*?) b/(.*)", header)
    if match:
        old_path = match.group(1)
        new_path = match.group(2)

    # Scan metadata lines before hunks
    for line in lines[1:]:
        if line.startswith("--- "):
            path = line[4:].strip()
            if path == "/dev/null":
                is_new = True
            elif path.startswith("a/"):
                old_path = path[2:]
        elif line.startswith("+++ "):
            path = line[4:].strip()
            if path == "/dev/null":
                is_deleted = True
            elif path.startswith("b/"):
                new_path = path[2:]
        elif line.startswith("Binary files"):
            is_binary = True
        elif line.startswith("rename from "):
            is_rename = True
        elif line.startswith("rename to "):
            is_rename = True
        elif line.startswith("@@"):
            break  # stop scanning metadata, hunks follow

    # Parse hunks
    hunks: list[DiffHunk] = []
    if not is_binary:
        block_text = "\n".join(lines)
        for hunk_match in _HUNK_HEADER.finditer(block_text):
            src_start = int(hunk_match.group(1))
            src_count = int(hunk_match.group(2)) if hunk_match.group(2) else 1
            tgt_start = int(hunk_match.group(3))
            tgt_count = int(hunk_match.group(4)) if hunk_match.group(4) else 1

            # Collect lines belonging to this hunk (until next hunk or end)
            hunk_start = hunk_match.end()
            # Find the next hunk header or end of block
            next_hunk = _HUNK_HEADER.search(block_text, hunk_start)
            hunk_end = next_hunk.start() if next_hunk else len(block_text)
            hunk_body = block_text[hunk_start:hunk_end]

            hunk_lines: list[str] = []
            for hline in hunk_body.split("\n"):
                if hline.startswith(("+", "-", " ")):
                    hunk_lines.append(hline)
                elif hline.startswith("\\"):
                    # "\ No newline at end of file" — skip
                    continue

            hunks.append(DiffHunk(
                src_start=src_start,
                src_count=src_count,
                tgt_start=tgt_start,
                tgt_count=tgt_count,
                lines=hunk_lines,
            ))

    return FileDiff(
        old_path=old_path,
        new_path=new_path,
        is_binary=is_binary,
        is_rename=is_rename,
        is_new=is_new,
        is_deleted=is_deleted,
        hunks=hunks,
    )


def get_staged_files(repo_root: str) -> list[str]:
    """Get list of staged (cached) files via ``git diff --cached --name-only``."""
    result = subprocess.run(
        ["git", "diff", "--cached", "--name-only"],
        capture_output=True,
        text=True,
        cwd=repo_root,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"git diff --cached --name-only failed: {result.stderr.strip()}"
        )
    return [f for f in result.stdout.strip().split("\n") if f]


def get_changed_files_from_range(git_range: str, repo_root: str) -> list[str]:
    """Get list of changed files from a git range via ``git diff --name-only``."""
    result = subprocess.run(
        ["git", "diff", git_range, "--name-only"],
        capture_output=True,
        text=True,
        cwd=repo_root,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"git diff {git_range} --name-only failed: {result.stderr.strip()}"
        )
    return [f for f in result.stdout.strip().split("\n") if f]


def extract_changed_files_from_diff(diff_text: str) -> list[str]:
    """Parse a unified diff and return a deduplicated list of changed file paths."""
    file_diffs = parse_diff(diff_text)
    seen: set[str] = set()
    paths: list[str] = []
    for fd in file_diffs:
        p = fd.path
        if p not in seen:
            seen.add(p)
            paths.append(p)
    return paths
