"""Project profile builder — analyzes codebase to extract design constraints.

Scans the full source tree (respecting scan_exclude) to detect frameworks,
architectural patterns, coding conventions, compliance signals, and ADRs.
Used by the MCP ``get_design_constraints`` tool and the dashboard profile tab.
"""

from __future__ import annotations

import json
import logging
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Language → extensions
# ---------------------------------------------------------------------------

_LANG_EXTENSIONS: dict[str, list[str]] = {
    "Python":     [".py"],
    "TypeScript": [".ts", ".tsx"],
    "JavaScript": [".js", ".jsx", ".mjs"],
    "Go":         [".go"],
    "Rust":       [".rs"],
    "Java":       [".java"],
    "Kotlin":     [".kt"],
    "C#":         [".cs"],
    "C++":        [".cpp", ".cxx", ".cc", ".hpp"],
    "C":          [".c", ".h"],
    "Ruby":       [".rb"],
    "PHP":        [".php"],
    "Swift":      [".swift"],
    "Dart":       [".dart"],
}

_EXT_TO_LANG: dict[str, str] = {
    ext: lang for lang, exts in _LANG_EXTENSIONS.items() for ext in exts
}

# Directories always excluded from scanning
_ALWAYS_SKIP: set[str] = {
    "node_modules", "__pycache__", ".venv", "venv", "env",
    ".git", ".svn", ".hg",
    "out", "dist", "build", "target",
    ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "bin", "obj", ".idea", ".vs",
}

# ---------------------------------------------------------------------------
# Framework detection
# ---------------------------------------------------------------------------

_PYTHON_FRAMEWORKS: dict[str, list[str]] = {
    "FastAPI":        ["fastapi"],
    "Django":         ["django"],
    "Flask":          ["flask"],
    "SQLAlchemy":     ["sqlalchemy"],
    "Pydantic":       ["pydantic"],
    "Celery":         ["celery"],
    "Pytest":         ["pytest"],
    "NumPy":          ["numpy"],
    "Pandas":         ["pandas"],
    "PyTorch":        ["torch"],
    "TensorFlow":     ["tensorflow"],
    "Scikit-learn":   ["scikit-learn", "sklearn"],
    "Requests":       ["requests"],
    "httpx":          ["httpx"],
    "Typer":          ["typer"],
    "Click":          ["click"],
    "Rich":           ["rich"],
    "aiohttp":        ["aiohttp"],
    "Alembic":        ["alembic"],
    "Motor":          ["motor"],
    "Redis":          ["redis"],
    "Kafka":          ["confluent-kafka", "kafka-python"],
    "RabbitMQ":       ["pika"],
    "Boto3 (AWS)":    ["boto3"],
    "Azure SDK":      ["azure-core", "azure-identity"],
    "Google Cloud":   ["google-cloud"],
    "MCP":            ["mcp"],
    "LangChain":      ["langchain"],
    "OpenAI SDK":     ["openai"],
    "Anthropic SDK":  ["anthropic"],
    "uvicorn":        ["uvicorn"],
    "gunicorn":       ["gunicorn"],
}

_JS_FRAMEWORKS: dict[str, list[str]] = {
    "React":       ["react"],
    "Next.js":     ["next"],
    "Vue":         ["vue"],
    "Angular":     ["@angular/core"],
    "Svelte":      ["svelte"],
    "Express":     ["express"],
    "Fastify":     ["fastify"],
    "NestJS":      ["@nestjs/core"],
    "Prisma":      ["@prisma/client"],
    "TypeORM":     ["typeorm"],
    "Mongoose":    ["mongoose"],
    "Drizzle ORM": ["drizzle-orm"],
    "Jest":        ["jest"],
    "Vitest":      ["vitest"],
    "Playwright":  ["@playwright/test"],
    "Tailwind CSS":["tailwindcss"],
    "Redux":       ["redux", "@reduxjs/toolkit"],
    "Zustand":     ["zustand"],
    "tRPC":        ["@trpc/server"],
    "Zod":         ["zod"],
    "Supabase":    ["@supabase/supabase-js"],
    "Socket.IO":   ["socket.io"],
    "GraphQL":     ["graphql", "apollo-server"],
    "OpenAI SDK":  ["openai"],
    "Anthropic SDK": ["@anthropic-ai/sdk"],
    "Vite":        ["vite"],
}

_GO_FRAMEWORKS: dict[str, str] = {
    "Gin":    "github.com/gin-gonic/gin",
    "Echo":   "github.com/labstack/echo",
    "GORM":   "gorm.io/gorm",
    "Cobra":  "github.com/spf13/cobra",
    "Fiber":  "github.com/gofiber/fiber",
    "Chi":    "github.com/go-chi/chi",
    "Go-kit": "github.com/go-kit/kit",
}

# C/C++ package name → display name (vcpkg IDs, CMake package names, Conan refs)
_VCPKG_DISPLAY_NAMES: dict[str, str] = {
    # Computer vision / imaging
    "opencv":         "OpenCV",
    "opencv4":        "OpenCV",
    "opencv2":        "OpenCV",
    # Linear algebra / math
    "eigen3":         "Eigen3",
    "eigen":          "Eigen3",
    "armadillo":      "Armadillo",
    "lapack":         "LAPACK",
    "blas":           "BLAS",
    "fftw3":          "FFTW",
    # General purpose
    "boost":          "Boost",
    "abseil":         "Abseil",
    "abseil-cpp":     "Abseil",
    # Networking / comms
    "grpc":           "gRPC",
    "protobuf":       "Protobuf",
    "zeromq":         "ZeroMQ",
    "libzmq":         "ZeroMQ",
    "czmq":           "ZeroMQ",
    "mqtt":           "MQTT",
    "mosquitto":      "Mosquitto (MQTT)",
    "paho-mqtt":      "Paho MQTT",
    # Serialisation / config
    "nlohmann-json":  "nlohmann/json",
    "nlohmann_json":  "nlohmann/json",
    "rapidjson":      "RapidJSON",
    "yaml-cpp":       "yaml-cpp",
    "tinyxml2":       "TinyXML2",
    "pugixml":        "pugixml",
    "flatbuffers":    "FlatBuffers",
    # Logging
    "spdlog":         "spdlog",
    "glog":           "Google glog",
    "log4cxx":        "log4cxx",
    # Testing
    "gtest":          "GoogleTest",
    "googletest":     "GoogleTest",
    "catch2":         "Catch2",
    "doctest":        "doctest",
    "benchmark":      "Google Benchmark",
    # Crypto / security
    "openssl":        "OpenSSL",
    "libsodium":      "libsodium",
    "mbedtls":        "mbedTLS",
    "botan":          "Botan",
    # Robotics / embedded
    "ros":            "ROS",
    "ros2":           "ROS 2",
    "orocos-kdl":     "Orocos KDL",
    "pcl":            "PCL (Point Cloud Library)",
    "vtk":            "VTK",
    "itk":            "ITK",
    # Database
    "sqlite3":        "SQLite",
    "libpq":          "PostgreSQL (libpq)",
    # GPU / compute
    "cuda":           "CUDA",
    "opencl":         "OpenCL",
    # UI / rendering
    "qt5":            "Qt5",
    "qt6":            "Qt6",
    "sfml":           "SFML",
    "sdl2":           "SDL2",
    "glfw3":          "GLFW",
    "imgui":          "ImGui",
    # Threading
    "tbb":            "Intel TBB",
    "openmp":         "OpenMP",
}

# ---------------------------------------------------------------------------
# Architectural pattern detection
# (name, directory_keywords, file_suffix_keywords, description)
# ---------------------------------------------------------------------------

_ARCH_PATTERNS: list[tuple[str, list[str], list[str], str]] = [
    (
        "Layered Architecture",
        ["core", "domain", "infrastructure", "presentation", "application", "usecases", "usecase"],
        [],
        "Codebase is organized into distinct layers — core/domain logic separated from infrastructure and presentation",
    ),
    (
        "Provider / Plugin Pattern",
        ["providers", "provider", "plugins", "plugin", "backends", "backend"],
        ["_provider", "provider_", ".provider.", "Provider"],
        "Extensible system with interchangeable providers or plugins — improves testability and modularity",
    ),
    (
        "Adapter / Ports & Adapters",
        ["adapters", "adapter", "ports", "port", "inbound", "outbound"],
        ["_adapter", "Adapter", "_port", "Port"],
        "Application core isolated from external systems via adapters — enables swapping implementations without touching business logic",
    ),
    (
        "Repository Pattern",
        ["repositories", "repository", "repos", "repo"],
        ["_repository", "_repo", "Repository"],
        "Data access abstracted behind repository interfaces — improves testability and decouples storage technology",
    ),
    (
        "Service Layer",
        ["services", "service"],
        ["_service", ".service.", "Service"],
        "Business logic encapsulated in dedicated service classes, separate from controllers and data access",
    ),
    (
        "Factory Pattern",
        ["factories", "factory"],
        ["_factory", "factory_", ".factory.", "Factory"],
        "Object creation centralized in factory functions or classes — used for provider selection and dependency wiring",
    ),
    (
        "MVC / Router Pattern",
        ["controllers", "controller", "routes", "router", "routers", "views"],
        ["_controller", ".controller.", "Controller", "_router", ".router.", "Router", "_routes", "routes_"],
        "Request routing and controller separation — standard MVC or API router structure",
    ),
    (
        "Middleware",
        ["middleware", "middlewares", "interceptors", "interceptor", "filters", "guards"],
        ["_middleware", ".middleware.", "Middleware", "_interceptor", "_guard", ".guard.", "Guard"],
        "Cross-cutting concerns (auth, logging, rate limiting) handled in middleware layers",
    ),
    (
        "Schema / Data Model Layer",
        ["schemas", "schema", "models", "model", "entities", "entity", "dto", "dtos", "types"],
        ["_schema", ".schema.", "Schema", "_model", ".model.", "Model", "_entity", "Entity", "_dto", "Dto"],
        "Structured data modeling with validation schemas or ORM models — important for input validation and type safety",
    ),
    (
        "Event-Driven Architecture",
        ["events", "handlers", "listeners", "subscribers", "emitters", "publishers", "consumers"],
        ["_event", "Event_", "_handler", ".handler.", "Handler", "_listener", "Listener", "_subscriber", "Consumer"],
        "Components communicate through events rather than direct calls — improves decoupling and auditability",
    ),
    (
        "Command / Query Separation (CQRS)",
        ["commands", "command", "queries", "query"],
        ["_command", "Command_", "_query", "Query_"],
        "Read and write operations separated — improves clarity, scalability, and audit trail",
    ),
    (
        "Pipeline / Chain of Responsibility",
        ["pipeline", "pipelines", "steps", "stages", "processors", "processor"],
        ["_pipeline", "Pipeline", "_step", "_stage", "_processor", "Processor"],
        "Processing steps chained sequentially — common in scan engines, ETL, and CI/CD systems",
    ),
    (
        "Rule Engine",
        ["rules", "rule", "engine", "checkers", "checker", "validators", "validator", "policies", "policy"],
        ["_rule", "_rules", "rules_", "_engine", "Engine", "_checker", "_validator", "_policy", "Policy"],
        "Declarative rules evaluated against data — common in compliance, governance, and policy enforcement systems",
    ),
    (
        "Plugin / Standards Pack System",
        ["packs", "pack", "plugins", "extensions", "extension", "modules", "addons", "addon"],
        ["_pack", "pack_", "_plugin", "Plugin", "_extension", "Extension"],
        "Modular, loadable rule packs or feature extensions — enables per-project compliance customization",
    ),
    (
        "API Gateway / Facade",
        ["gateway", "gateways", "facade", "proxy", "proxies"],
        ["_gateway", "Gateway", "_facade", "Facade"],
        "Single entry point routing to downstream services — important for API security boundaries",
    ),
    (
        "Observer / Pub-Sub",
        ["pubsub", "pub_sub", "broker", "brokers", "dispatcher", "bus", "eventbus"],
        ["_broker", "Broker", "_dispatcher", "Dispatcher", "_bus", "Bus"],
        "Publishers and subscribers decoupled through a message broker",
    ),
    (
        "State Machine",
        ["states", "state", "transitions", "transition", "statemachine", "fsm"],
        ["_state", "State_", "_fsm", "_transition"],
        "Explicit state management — useful for workflow, device, or process lifecycle modeling",
    ),
]

# ---------------------------------------------------------------------------
# Compliance / regulatory signals
# (label, directory/module keywords, description)
# ---------------------------------------------------------------------------

_COMPLIANCE_SIGNALS: list[tuple[str, list[str], str]] = [
    (
        "Audit Logging",
        ["audit", "audit_log", "audit_trail", "auditlog", "activity_log", "event_log", "eventlog", "logging"],
        "Audit trail module detected — required by SOC 2, HIPAA, IEC 62304, and most regulatory frameworks",
    ),
    (
        "Authentication & Authorization",
        ["auth", "authentication", "authorization", "oauth", "jwt", "session", "permissions", "rbac", "acl", "iam",
         "access_control", "accesscontrol", "login", "credential"],
        "Auth module detected — verify OWASP authentication controls, session management, and least-privilege access",
    ),
    (
        "Input Validation",
        ["validation", "validators", "sanitize", "sanitizers", "sanitization", "input_check", "bounds_check",
         "boundary_check", "range_check", "parameter_check"],
        "Input validation layer detected — reduces injection, XSS, and data integrity risk",
    ),
    (
        "Secrets & Configuration Management",
        ["secrets", "vault", "keystore", "credentials", "env", "config_mgmt", "configuration_management",
         "secure_config", "parameter_store"],
        "Secrets/config module detected — verify no hardcoded credentials (Sentrik `secrets` scan covers this)",
    ),
    (
        "Error & Fault Handling",
        ["errors", "error", "exceptions", "exception", "fault", "faults", "fault_handler", "error_handler",
         "safe_state", "failsafe", "fail_safe", "fault_recovery", "error_recovery", "watchdog"],
        "Error/fault handling module detected — centralized handling improves traceability and failure auditability",
    ),
    (
        "Cryptography",
        ["crypto", "cryptography", "encryption", "signing", "hash", "hmac", "cipher", "tls", "ssl",
         "certificate", "checksum", "crc", "integrity_check"],
        "Cryptographic module detected — verify algorithm compliance (FIPS 140-2, NIST approved algorithms)",
    ),
    (
        "Evidence & Traceability",
        ["evidence", "traceability", "trace", "attestation", "compliance", "lineage", "requirements",
         "req_trace", "tracing", "change_control", "change_log"],
        "Evidence or compliance traceability module detected — supports SOC 2 audit evidence and IEC 62304 traceability",
    ),
    (
        "Data Privacy / PII",
        ["privacy", "pii", "gdpr", "anonymize", "anonymization", "redact", "consent", "data_protection"],
        "Data privacy module detected — verify GDPR/CCPA controls for data subject rights and consent management",
    ),
    (
        "Safety-Critical Control",
        ["safety", "safe_state", "watchdog", "watchdog_timer", "interlock", "interlocks", "emergency_stop",
         "estop", "safety_monitor", "safety_controller", "fail_safe", "failsafe", "protection",
         "safety_function", "plausibility"],
        "Safety-critical control module detected — verify IEC 62304, ISO 13485, or ISO 26262 safety requirements",
    ),
    (
        "Risk Management",
        ["risk", "hazard", "hazards", "fmea", "fmeca", "risk_analysis", "risk_assessment", "risk_control",
         "hazard_analysis", "harm", "severity_analysis", "risk_management"],
        "Risk management module detected — required by ISO 14971 for medical devices and IEC 61508 for safety systems",
    ),
    (
        "Verification & Validation",
        ["verification", "validation", "test_report", "test_protocol", "qualification", "ivv",
         "acceptance_test", "system_test", "integration_test", "unit_test", "test_suite"],
        "Verification/validation module detected — required by IEC 62304 §5.7 and FDA 21 CFR Part 11",
    ),
    (
        "Rate Limiting / Throttling",
        ["rate_limit", "throttle", "ratelimit", "limiter", "quota"],
        "Rate limiting detected — important for API security, availability, and abuse prevention",
    ),
    (
        "Dependency / Supply Chain",
        ["sbom", "supply_chain", "dependencies", "lockfile", "provenance"],
        "Supply chain or SBOM module detected — use `sentrik sbom` and `sentrik vulns` to track CVEs",
    ),
]

# ---------------------------------------------------------------------------
# Framework → recommended Sentrik packs
# ---------------------------------------------------------------------------

_FRAMEWORK_PACK_RECS: dict[str, list[str]] = {
    "FastAPI":       ["owasp-top-10", "python-security"],
    "Django":        ["owasp-top-10", "python-security"],
    "Flask":         ["owasp-top-10", "python-security"],
    "Express":       ["owasp-top-10"],
    "NestJS":        ["owasp-top-10"],
    "Next.js":       ["owasp-top-10"],
    "React":         ["owasp-top-10"],
    "Angular":       ["owasp-top-10"],
    "Vue":           ["owasp-top-10"],
    "SQLAlchemy":    ["owasp-top-10"],
    "Prisma":        ["owasp-top-10"],
    "TypeORM":       ["owasp-top-10"],
    "Mongoose":      ["owasp-top-10"],
    "Drizzle ORM":   ["owasp-top-10"],
    "PyTorch":       ["nist-ai-rmf", "eu-ai-act"],
    "TensorFlow":    ["nist-ai-rmf", "eu-ai-act"],
    "Scikit-learn":  ["nist-ai-rmf"],
    "LangChain":     ["nist-ai-rmf", "eu-ai-act"],
    "OpenAI SDK":    ["nist-ai-rmf", "eu-ai-act"],
    "Anthropic SDK": ["nist-ai-rmf", "eu-ai-act"],
    "Boto3 (AWS)":   ["supply-chain-security"],
    "Azure SDK":     ["supply-chain-security"],
    "Google Cloud":  ["supply-chain-security"],
    "Kafka":         ["supply-chain-security"],
    "RabbitMQ":      ["supply-chain-security"],
}

_LANG_PACK_RECS: dict[str, list[str]] = {
    "Python": ["python-security"],
    "C++":    ["misra-c"],
    "C":      ["misra-c"],
    "Go":     ["go-security"],
    "PHP":    ["php-security"],
    "Kotlin": ["kotlin-security"],
}

# Keyword → pack suggestions based on project name/description
_KEYWORD_PACK_RECS: list[tuple[list[str], str, str]] = [
    # Medical / health — checked first so calibration/device are caught before aviation
    (["medical", "hipaa", "ehr", "hl7", "fhir", "clinical", "patient",
      "surgical", "therapy", "diagnosis", "radiology", "imaging"],        "hipaa",        "Medical/health keywords"),
    (["medical device", "fda", "iec62304", "iec 62304", "510k", "pma",
      "predicate device", "device calibration", "robot calibration",
      "surgical robot", "medical robot", "implant", "prosthetic",
      "sterilization", "biomedical", "in vitro", "in vivo"],              "fda-iec-62304","Medical device keywords"),
    (["health software", "iec 81001", "iec81001"],                        "iec-81001-5-1","Health software keywords"),
    (["pci", "payment", "cardholder", "stripe", "braintree", "acquirer"], "pci-dss",      "Payment processing keywords"),
    (["gdpr", "personal data", "pii", "data subject", "right to erasure"],"gdpr",         "GDPR/PII keywords"),
    (["cmmc", "cui", "defense contractor", "dod ", "itar", "nist 800"],   "cmmc",         "Defense/government keywords"),
    (["iso27001", "iso 27001", "information security management", "isms"],"iso-27001",    "ISO 27001 keywords"),
    # Automotive — only fire on explicit automotive terms, not generic "functional safety"
    (["automotive", "iso26262", "iso 26262", "asil", "misra", "autosar",
      "vehicle", "ecu ", "powertrain", "adas"],                           "iso-26262",    "Automotive safety keywords"),
    # Aviation — require explicit aviation terms; "calibration" alone does not qualify
    (["aviation", "do-178", "do178", "dal level", "airborne system",
      "aerospace", "avionics", "flight software"],                        "do-178c",      "Aviation/avionics keywords"),
    (["artificial intelligence", "machine learning", "neural network",
      "deep learning", "llm", "foundation model"],                        "nist-ai-rmf",  "AI/ML components"),
]

# ---------------------------------------------------------------------------
# Import extraction regexes by file extension
# ---------------------------------------------------------------------------

# C/C++ standard library headers — excluded from "core dependencies" display
_C_STDLIB_HEADERS: frozenset[str] = frozenset({
    "algorithm", "array", "atomic", "bitset", "cassert", "ccomplex", "cctype",
    "cerrno", "cfenv", "cfloat", "chrono", "cinttypes", "ciso646", "climits",
    "clocale", "cmath", "complex", "condition_variable", "csetjmp", "csignal",
    "cstdalign", "cstdarg", "cstdbool", "cstddef", "cstdint", "cstdio",
    "cstdlib", "cstring", "ctgmath", "ctime", "cuchar", "cwchar", "cwctype",
    "deque", "exception", "execution", "filesystem", "forward_list", "fstream",
    "functional", "future", "initializer_list", "iomanip", "ios", "iosfwd",
    "iostream", "istream", "iterator", "limits", "list", "locale", "map",
    "memory", "mutex", "new", "numeric", "optional", "ostream", "queue",
    "random", "ratio", "regex", "scoped_allocator", "set", "shared_mutex",
    "sstream", "stack", "stdexcept", "streambuf", "string", "string_view",
    "strstream", "system_error", "thread", "tuple", "type_traits", "typeindex",
    "typeinfo", "unordered_map", "unordered_set", "utility", "valarray",
    "variant", "vector", "version",
    # C headers
    "assert", "complex", "ctype", "errno", "fenv", "float", "inttypes",
    "iso646", "limits", "locale", "math", "setjmp", "signal", "stdalign",
    "stdarg", "stdbool", "stddef", "stdint", "stdio", "stdlib", "stdnoreturn",
    "string", "tgmath", "threads", "time", "uchar", "wchar", "wctype",
    # Windows / POSIX
    "windows", "winbase", "windef", "winsock2", "ws2tcpip", "winerror",
    "unistd", "fcntl", "sys", "pthread",
})

_IMPORT_RES: dict[str, list[re.Pattern[str]]] = {
    ".py":  [re.compile(r"^(?:from|import)\s+([\w.]+)", re.MULTILINE)],
    ".ts":  [re.compile(r"""(?:import|from)\s+['"]([^'"]+)['"]"""), re.compile(r"""require\(['"]([^'"]+)['"]\)""")],
    ".tsx": [re.compile(r"""(?:import|from)\s+['"]([^'"]+)['"]""")],
    ".js":  [re.compile(r"""(?:import|from)\s+['"]([^'"]+)['"]"""), re.compile(r"""require\(['"]([^'"]+)['"]\)""")],
    ".jsx": [re.compile(r"""(?:import|from)\s+['"]([^'"]+)['"]""")],
    ".mjs": [re.compile(r"""(?:import|from)\s+['"]([^'"]+)['"]""")],
    ".go":  [re.compile(r'"([a-zA-Z][^"]+)"')],
    ".java":[re.compile(r"^import\s+([\w.]+);", re.MULTILINE)],
    ".kt":  [re.compile(r"^import\s+([\w.]+)", re.MULTILINE)],
    ".cs":  [re.compile(r"^using\s+([\w.]+);", re.MULTILINE)],
    ".rs":  [re.compile(r"^use\s+([\w:]+)", re.MULTILINE)],
    ".rb":  [re.compile(r"""^require(?:_relative)?\s+['"]([^'"]+)['"]""", re.MULTILINE)],
    ".php": [re.compile(r"""(?:require|include)(?:_once)?\s+['"]([^'"]+)['"]""", re.MULTILINE)],
    # C/C++ — capture angle-bracket (system/library) includes only; skip local "quoted" includes
    ".cpp": [re.compile(r'#include\s*<([^>]+)>', re.MULTILINE)],
    ".cxx": [re.compile(r'#include\s*<([^>]+)>', re.MULTILINE)],
    ".cc":  [re.compile(r'#include\s*<([^>]+)>', re.MULTILINE)],
    ".c":   [re.compile(r'#include\s*<([^>]+)>', re.MULTILINE)],
    ".hpp": [re.compile(r'#include\s*<([^>]+)>', re.MULTILINE)],
    ".h":   [re.compile(r'#include\s*<([^>]+)>', re.MULTILINE)],
}

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_project_profile(
    repo_root: str,
    scan_exclude: list[str] | None = None,
    enabled_packs: list[str] | None = None,
) -> dict[str, Any]:
    """Analyze the codebase and return a project profile.

    Scans the full source tree (excluding ``scan_exclude`` patterns and
    standard noise dirs) to detect languages, frameworks, architectural
    patterns, compliance signals, conventions, and module structure.

    Args:
        repo_root: Path to the repository root.
        scan_exclude: Directory/path patterns to skip (from config).
        enabled_packs: Pack IDs already enabled — excluded from recommendations.
    """
    root = Path(repo_root)
    exclude_patterns: list[str] = scan_exclude or []
    already_enabled: set[str] = set(enabled_packs or [])

    print("  Collecting source files...")
    files = _collect_source_files(root, exclude_patterns)
    all_dirs = _collect_all_dirs(root, exclude_patterns)

    print(f"  Scanning imports across {len(files)} source files...")
    import_counter, internal_importers, external_counter = _scan_imports(files, root)

    print("  Detecting languages and frameworks...")
    languages = _detect_languages(files)
    frameworks = _detect_frameworks(root, import_counter, exclude_patterns=exclude_patterns)

    print("  Detecting architectural patterns...")
    architecture = _detect_architecture(root, files, all_dirs, import_counter, internal_importers)
    compliance_signals = _detect_compliance_signals(all_dirs, files, root)

    print("  Analyzing conventions...")
    conventions = _detect_conventions(files)

    print("  Building module map...")
    module_map = _build_module_map(root, files, exclude_patterns)
    adrs = _find_adrs(root)
    identity = _extract_identity(root)

    print("  Computing pack recommendations...")
    all_recs = _recommend_packs(frameworks, languages, identity, files=files)
    recommended_packs = [r for r in all_recs if r["pack"] not in already_enabled]

    print("  Building top-dependency summary...")
    # Show external library imports (what the project actually depends on),
    # not internal modules (which aren't useful to the user as "core dependencies").
    top_imports = [
        {"module": mod, "importers": count}
        for mod, count in external_counter.most_common(15)
        if count >= 2
    ]

    return {
        "name":               identity.get("name", ""),
        "description":        identity.get("description", ""),
        "version":            identity.get("version", ""),
        "languages":          languages,
        "frameworks":         frameworks,
        "architecture":       architecture,
        "compliance_signals": compliance_signals,
        "adrs":               adrs,
        "conventions":        conventions,
        "module_map":         module_map,
        "top_imports":        top_imports,
        "recommended_packs":  recommended_packs,
        "tech_stack":         languages + [f["name"] for f in frameworks],
        "file_count":         len(files),
    }


# ---------------------------------------------------------------------------
# File collection
# ---------------------------------------------------------------------------


def _should_skip_dir(d: Path, exclude_patterns: list[str], root: Path) -> bool:
    if d.name in _ALWAYS_SKIP:
        return True
    rel = str(d.relative_to(root))
    return any(pat.rstrip("/") in rel for pat in exclude_patterns)


def _collect_source_files(root: Path, exclude_patterns: list[str]) -> list[Path]:
    """Walk the full tree and return all source code files."""
    files: list[Path] = []
    source_exts = set(_EXT_TO_LANG.keys())

    def _walk(path: Path) -> None:
        try:
            for child in sorted(path.iterdir()):
                if child.is_dir():
                    if not _should_skip_dir(child, exclude_patterns, root):
                        _walk(child)
                elif child.is_file() and child.suffix.lower() in source_exts:
                    files.append(child)
        except PermissionError:
            pass

    _walk(root)
    return files


def _collect_all_dirs(root: Path, exclude_patterns: list[str]) -> set[str]:
    """Return a set of all (lowercase) directory names found anywhere in the tree."""
    dirs: set[str] = set()

    def _walk(path: Path) -> None:
        try:
            for child in path.iterdir():
                if child.is_dir():
                    if not _should_skip_dir(child, exclude_patterns, root):
                        dirs.add(child.name.lower())
                        _walk(child)
        except PermissionError:
            pass

    _walk(root)
    return dirs


# ---------------------------------------------------------------------------
# Import scanning
# ---------------------------------------------------------------------------


# Python standard library top-level module names — excluded from "core dependencies" display
_STDLIB_MODULES: frozenset[str] = frozenset({
    "os", "sys", "re", "io", "abc", "ast", "dis", "gc", "typing", "types",
    "math", "time", "enum", "copy", "uuid", "json", "csv", "xml", "html",
    "http", "urllib", "email", "socket", "ssl", "struct", "array", "queue",
    "collections", "itertools", "functools", "operator", "contextlib",
    "dataclasses", "pathlib", "shutil", "glob", "fnmatch", "tempfile",
    "subprocess", "threading", "multiprocessing", "concurrent", "asyncio",
    "logging", "warnings", "traceback", "inspect", "importlib", "pkgutil",
    "unittest", "doctest", "argparse", "configparser", "datetime", "calendar",
    "random", "statistics", "decimal", "fractions", "hashlib", "hmac",
    "secrets", "base64", "binascii", "codecs", "string", "textwrap",
    "pprint", "reprlib", "weakref", "gc", "platform", "signal", "errno",
    "ctypes", "mmap", "select", "selectors", "pty", "tty", "termios",
    "readline", "rlcompleter", "zipfile", "tarfile", "gzip", "bz2", "lzma",
    "sqlite3", "dbm", "shelve", "pickle", "marshal", "builtins", "__future__",
})


def _scan_imports(
    files: list[Path],
    root: Path,
) -> tuple[Counter[str], dict[str, set[str]], Counter[str]]:
    """Extract import statements from all source files.

    Returns:
        internal_counter    — Counter of internal module paths by number of files importing them
        internal_importers  — map from internal module → set of files that import it
        external_counter    — Counter of external library imports (stdlib excluded), for top_imports display
    """
    all_imports: Counter[str] = Counter()
    internal_importers: dict[str, set[str]] = defaultdict(set)

    # Derive the package root name(s) for "internal" import detection
    # A module is internal if it starts with a top-level source directory name
    top_src_dirs = {
        d.name for d in root.iterdir()
        if d.is_dir() and d.name not in _ALWAYS_SKIP and not d.name.startswith(".")
    }
    src_dir = root / "src"
    if src_dir.is_dir():
        for d in src_dir.iterdir():
            if d.is_dir() and not d.name.startswith("."):
                top_src_dirs.add(d.name)

    for fpath in files:
        ext = fpath.suffix.lower()
        patterns = _IMPORT_RES.get(ext)
        if not patterns:
            continue
        try:
            text = fpath.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        for pat in patterns:
            for m in pat.finditer(text):
                mod = m.group(1).strip()
                if not mod:
                    continue
                # Normalize: take the top-level component for counting
                top = mod.split(".")[0].split("/")[0].lstrip(".")
                if not top:
                    continue
                all_imports[top] += 1
                # Track which are internal (imported from our own source tree)
                if top in top_src_dirs:
                    # For Python: record full module path
                    full = mod.split(".")[0] if ext == ".py" else top
                    internal_importers[full].add(str(fpath.relative_to(root)))

    # Internal module counter (used for architecture detection / import centrality)
    internal_counter: Counter[str] = Counter()
    for mod, importers in internal_importers.items():
        internal_counter[mod] = len(importers)

    # External counter: all imports that are NOT internal AND NOT stdlib (Python or C/C++)
    external_counter: Counter[str] = Counter({
        mod: count
        for mod, count in all_imports.items()
        if mod not in top_src_dirs
        and mod not in _STDLIB_MODULES
        and mod not in _C_STDLIB_HEADERS
        and not mod.startswith("_")
    })

    return internal_counter, internal_importers, external_counter


# ---------------------------------------------------------------------------
# Language detection
# ---------------------------------------------------------------------------


def _detect_languages(files: list[Path]) -> list[str]:
    counts: Counter[str] = Counter()
    for f in files:
        lang = _EXT_TO_LANG.get(f.suffix.lower())
        if lang:
            counts[lang] += 1
    return [lang for lang, _ in counts.most_common()]


# ---------------------------------------------------------------------------
# Framework detection
# ---------------------------------------------------------------------------


def _detect_frameworks(
    root: Path,
    import_counter: Counter[str],
    exclude_patterns: list[str] | None = None,
) -> list[dict[str, str]]:
    _excl = exclude_patterns or []
    frameworks: list[dict[str, str]] = []
    seen: set[str] = set()

    def _add(name: str, source: str) -> None:
        if name not in seen:
            frameworks.append({"name": name, "source": source})
            seen.add(name)

    def _is_excluded(p: Path) -> bool:
        """Return True if any part of the path matches an always-skip or exclude pattern."""
        parts = p.parts
        if any(part in _ALWAYS_SKIP for part in parts):
            return True
        rel = str(p.relative_to(root))
        return any(pat.rstrip("/") in rel for pat in _excl)

    # Python manifests
    for req_file in ("requirements.txt", "pyproject.toml", "setup.cfg", "Pipfile", "setup.py"):
        path = root / req_file
        if path.is_file():
            try:
                content = path.read_text(encoding="utf-8", errors="replace").lower()
                for name, patterns in _PYTHON_FRAMEWORKS.items():
                    if any(p in content for p in patterns):
                        _add(name, req_file)
            except OSError:
                pass

    # package.json (root and common subdirectories — respecting excludes)
    for pkg_path in root.rglob("package.json"):
        if _is_excluded(pkg_path):
            continue
        try:
            pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
            all_deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            rel = str(pkg_path.relative_to(root))
            for name, patterns in _JS_FRAMEWORKS.items():
                if any(p in all_deps for p in patterns):
                    _add(name, rel)
        except (json.JSONDecodeError, OSError, ValueError):
            pass

    # go.mod
    go_mod = root / "go.mod"
    if go_mod.is_file():
        try:
            content = go_mod.read_text(encoding="utf-8", errors="replace")
            for name, pattern in _GO_FRAMEWORKS.items():
                if pattern in content:
                    _add(name, "go.mod")
        except OSError:
            pass

    # vcpkg.json — C/C++ package manifest
    vcpkg_json = root / "vcpkg.json"
    if vcpkg_json.is_file():
        try:
            data = json.loads(vcpkg_json.read_text(encoding="utf-8"))
            deps = data.get("dependencies", [])
            for dep in deps:
                # deps can be strings or {"name": "..."} objects
                dep_name = dep if isinstance(dep, str) else dep.get("name", "")
                if dep_name:
                    # Normalise to title-case display name
                    display = _VCPKG_DISPLAY_NAMES.get(dep_name.lower(), dep_name)
                    _add(display, "vcpkg.json")
        except (json.JSONDecodeError, OSError):
            pass

    # CMakeLists.txt — find_package() and FetchContent calls
    for cmake_name in ("CMakeLists.txt", "CMakeLists.cmake"):
        cmake_path = root / cmake_name
        if cmake_path.is_file():
            try:
                content = cmake_path.read_text(encoding="utf-8", errors="replace")
                # find_package(OpenCV REQUIRED) or find_package(Boost 1.70 COMPONENTS ...)
                for m in re.finditer(r"find_package\s*\(\s*([\w]+)", content, re.IGNORECASE):
                    pkg = m.group(1)
                    display = _VCPKG_DISPLAY_NAMES.get(pkg.lower(), pkg)
                    _add(display, cmake_name)
                # FetchContent_Declare(googletest ...)
                for m in re.finditer(r"FetchContent_Declare\s*\(\s*([\w]+)", content, re.IGNORECASE):
                    pkg = m.group(1)
                    display = _VCPKG_DISPLAY_NAMES.get(pkg.lower(), pkg)
                    _add(display, cmake_name)
            except OSError:
                pass

    # Conan — conanfile.txt [requires] section or conanfile.py
    for conan_name in ("conanfile.txt", "conanfile.py"):
        conan_path = root / conan_name
        if conan_path.is_file():
            try:
                content = conan_path.read_text(encoding="utf-8", errors="replace")
                # [requires]\nboost/1.82.0\nopenssl/3.1.0
                for m in re.finditer(r"^([\w\-]+)/[\d.]+", content, re.MULTILINE):
                    pkg = m.group(1)
                    display = _VCPKG_DISPLAY_NAMES.get(pkg.lower(), pkg)
                    _add(display, conan_name)
            except OSError:
                pass

    return frameworks


# ---------------------------------------------------------------------------
# Architecture detection
# ---------------------------------------------------------------------------


def _detect_architecture(
    root: Path,
    files: list[Path],
    all_dirs: set[str],
    import_counter: Counter[str],
    internal_importers: dict[str, set[str]],
) -> list[dict[str, Any]]:
    """Detect architectural patterns from directory names, file names, and import graph."""

    # Build file stem set for naming pattern matching (all languages)
    file_stems = [f.stem for f in files]
    file_names = [f.name for f in files]

    # Highly-imported internal modules (centrality signals)
    central_modules = {mod for mod, count in import_counter.items() if count >= 3}

    patterns: list[dict[str, Any]] = []
    seen: set[str] = set()

    for pattern_name, dir_keywords, file_keywords, description in _ARCH_PATTERNS:
        if pattern_name in seen:
            continue

        evidence: list[str] = []

        # 1. Directory signal
        matched_dirs = [kw for kw in dir_keywords if kw in all_dirs]
        if matched_dirs:
            evidence.append(f"directory: {', '.join(matched_dirs)}")

        # 2. File naming signal (works for all languages — matches stems and full names)
        file_hits: list[str] = []
        matched_source_files: list[str] = []
        seen_paths: set[str] = set()
        for kw in file_keywords:
            matches = [f for f in files if kw.lower() in f.name.lower()]
            if matches:
                file_hits.append(f"{kw} ({len(matches)} file{'s' if len(matches) != 1 else ''})")
                for f in matches[:3]:
                    try:
                        rel = str(f.relative_to(root)).replace("\\", "/")
                    except ValueError:
                        rel = f.name
                    if rel not in seen_paths:
                        matched_source_files.append(rel)
                        seen_paths.add(rel)
                    if len(matched_source_files) >= 10:
                        break
        if file_hits:
            evidence.append(f"files: {', '.join(file_hits[:3])}")

        # 3. Import centrality signal — if a module matching a dir/file keyword is heavily imported
        for kw in dir_keywords + file_keywords:
            kw_clean = kw.strip("_.")
            for mod in central_modules:
                if kw_clean.lower() in mod.lower():
                    count = import_counter[mod]
                    evidence.append(f"import hub: {mod} ({count} importers)")
                    # Add files that import this hub as source references
                    for imp_file in list(internal_importers.get(mod, set()))[:5]:
                        if imp_file not in seen_paths:
                            matched_source_files.append(imp_file.replace("\\", "/"))
                            seen_paths.add(imp_file)
                    break

        if evidence:
            seen.add(pattern_name)
            patterns.append({
                "pattern":      pattern_name,
                "evidence":     "; ".join(evidence),
                "description":  description,
                "source_files": matched_source_files[:10],
            })

    return patterns


# ---------------------------------------------------------------------------
# Compliance signals
# ---------------------------------------------------------------------------


def _detect_compliance_signals(
    all_dirs: set[str],
    files: list[Path] | None = None,
    root: Path | None = None,
) -> list[dict[str, Any]]:
    """Detect compliance-relevant structural signals from directory names and file names."""
    signals: list[dict[str, Any]] = []

    # Build stem→file map for source file lookup
    stem_to_files: dict[str, list[Path]] = defaultdict(list)
    if files:
        for f in files:
            stem_to_files[f.stem.lower()].append(f)
            stem_to_files[f.name.lower()].append(f)

    file_stems = set(stem_to_files.keys())

    def _rel(p: Path) -> str:
        if root:
            try:
                return str(p.relative_to(root)).replace("\\", "/")
            except ValueError:
                pass
        return p.name

    for label, keywords, description in _COMPLIANCE_SIGNALS:
        dir_matches = [kw for kw in keywords if kw in all_dirs]
        file_matches = [kw for kw in keywords if any(kw in stem for stem in file_stems)]

        evidence_parts: list[str] = []
        matched_files: list[str] = []

        if dir_matches:
            evidence_parts.append(f"directory: {', '.join(dir_matches)}")
        if file_matches:
            novel = [kw for kw in file_matches if kw not in dir_matches]
            if novel:
                evidence_parts.append(f"files: {', '.join(novel)}")
            # Collect up to 8 example source files
            seen: set[str] = set()
            for kw in file_matches:
                for stem, fpaths in stem_to_files.items():
                    if kw in stem:
                        for fp in fpaths[:3]:
                            rel = _rel(fp)
                            if rel not in seen:
                                matched_files.append(rel)
                                seen.add(rel)
                            if len(matched_files) >= 8:
                                break
                    if len(matched_files) >= 8:
                        break

        if evidence_parts:
            signals.append({
                "signal":       label,
                "evidence":     "; ".join(evidence_parts),
                "description":  description,
                "source_files": matched_files,
            })
    return signals


# ---------------------------------------------------------------------------
# Convention detection
# ---------------------------------------------------------------------------


def _detect_conventions(files: list[Path]) -> dict[str, Any]:
    """Analyze actual source code to infer coding conventions."""
    conventions: dict[str, Any] = {}

    # Detect convention/config files
    roots_checked: set[Path] = {f.parent for f in files}
    all_parents: set[Path] = set()
    for p in roots_checked:
        all_parents.add(p)
        all_parents.add(p.parent)  # also check parent
    convention_files = []
    for parent in all_parents:
        for name in (".editorconfig", ".prettierrc", ".prettierrc.js", ".eslintrc",
                     ".eslintrc.js", ".eslintrc.json", "CONVENTIONS.md", "CONTRIBUTING.md",
                     "styleguide.md", ".flake8", "pyproject.toml", ".ruff.toml",
                     ".clang-format", ".clang-tidy", "CMakePresets.json", ".cmake-format.yaml"):
            if (parent / name).is_file():
                convention_files.append(name)
    if convention_files:
        conventions["convention_files"] = sorted(set(convention_files))

    # Python-specific analysis
    py_files = [f for f in files if f.suffix == ".py"][:60]
    if py_files:
        type_hint_count = 0
        docstring_count = 0
        async_count = 0
        dataclass_count = 0
        pydantic_count = 0
        camel_fn_count = 0
        snake_fn_count = 0
        total_fns = 0

        fn_re = re.compile(r"^\s*(?:async\s+)?def\s+(\w+)\s*\(([^)]*)\)\s*(?:->\s*\S+)?", re.MULTILINE)
        async_re = re.compile(r"^\s*async\s+def\s+", re.MULTILINE)
        doc_re = re.compile(r'^\s*"""', re.MULTILINE)
        camel_re = re.compile(r"^[a-z]+[A-Z]")

        for f in py_files:
            try:
                text = f.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue

            if '"""' in text or "'''" in text:
                docstring_count += 1
            if "->" in text:
                type_hint_count += 1
            if "async def " in text:
                async_count += 1
            if "@dataclass" in text:
                dataclass_count += 1
            if "BaseModel" in text or "pydantic" in text.lower():
                pydantic_count += 1

            for m in fn_re.finditer(text):
                fn_name = m.group(1)
                if fn_name.startswith("_") or fn_name in ("__init__", "__str__", "__repr__"):
                    continue
                total_fns += 1
                if camel_re.match(fn_name):
                    camel_fn_count += 1
                else:
                    snake_fn_count += 1

        n = len(py_files)
        if total_fns > 0:
            if camel_fn_count / total_fns > 0.3:
                conventions["naming_style"] = "camelCase (mixed)"
            else:
                conventions["naming_style"] = "snake_case"

        if type_hint_count > n // 2:
            conventions["type_hints"] = f"widely used ({type_hint_count}/{n} files)"
        elif type_hint_count > 0:
            conventions["type_hints"] = f"partial ({type_hint_count}/{n} files)"

        if docstring_count > n // 2:
            conventions["docstrings"] = f"widely used ({docstring_count}/{n} files)"

        if async_count > n // 3:
            conventions["async_style"] = f"async-heavy ({async_count}/{n} Python files)"

        if pydantic_count > 0:
            conventions["data_modeling"] = f"Pydantic ({pydantic_count} files)"
        elif dataclass_count > 0:
            conventions["data_modeling"] = f"dataclasses ({dataclass_count} files)"

    # TypeScript/JavaScript analysis
    ts_files = [f for f in files if f.suffix in (".ts", ".tsx")][:30]
    if ts_files:
        interface_count = 0
        type_count = 0
        for f in ts_files:
            try:
                text = f.read_text(encoding="utf-8", errors="replace")
                if re.search(r"\binterface\s+\w+", text):
                    interface_count += 1
                if re.search(r"\btype\s+\w+\s*=", text):
                    type_count += 1
            except OSError:
                continue
        if interface_count + type_count > len(ts_files) // 2:
            conventions["ts_typing"] = f"typed ({interface_count} interfaces, {type_count} type aliases)"

    # C/C++ analysis
    cpp_files = [f for f in files if f.suffix.lower() in (".cpp", ".cxx", ".cc", ".c", ".hpp", ".h")][:60]
    if cpp_files:
        pragma_once = 0
        header_guard = 0
        smart_ptr = 0
        raw_ptr_new = 0
        doxygen = 0
        namespace_count = 0
        snake_fn = 0
        camel_fn = 0
        pascal_fn = 0
        total_cpp_fns = 0
        const_ref = 0
        raii_patterns = 0

        fn_re = re.compile(
            r"(?:^|\s)(?:[\w:<>*&]+\s+)+(\w+)\s*\([^;{]*\)\s*(?:const\s*)?(?:override\s*)?(?:noexcept\s*)?\{",
            re.MULTILINE,
        )
        camel_re = re.compile(r"^[a-z][a-zA-Z0-9]*[A-Z]")
        pascal_re = re.compile(r"^[A-Z][a-zA-Z0-9]+")
        snake_re  = re.compile(r"^[a-z][a-z0-9_]+$")

        for f in cpp_files:
            try:
                text = f.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue

            if "#pragma once" in text:
                pragma_once += 1
            elif re.search(r"#ifndef\s+\w+_H", text, re.IGNORECASE):
                header_guard += 1

            if re.search(r"\bstd::(unique_ptr|shared_ptr|weak_ptr|make_unique|make_shared)\b", text):
                smart_ptr += 1
            if re.search(r"\bnew\s+\w+", text):
                raw_ptr_new += 1

            if re.search(r"/\*\*|///<|//!", text):
                doxygen += 1

            if re.search(r"\bnamespace\s+\w+", text):
                namespace_count += 1

            if re.search(r"\bconst\s+\w+\s*&", text):
                const_ref += 1

            # RAII: constructors/destructors that manage resources
            if re.search(r"~\w+\s*\(\s*\)", text):
                raii_patterns += 1

            for m in fn_re.finditer(text):
                name = m.group(1)
                if name in ("if", "for", "while", "switch", "catch", "return", "else",
                            "do", "case", "class", "struct", "namespace", "template"):
                    continue
                total_cpp_fns += 1
                if pascal_re.match(name):
                    pascal_fn += 1
                elif camel_re.match(name):
                    camel_fn += 1
                elif snake_re.match(name):
                    snake_fn += 1

        n = len(cpp_files)

        # Naming style
        if total_cpp_fns > 0:
            dominant = max(
                [("snake_case", snake_fn), ("camelCase", camel_fn), ("PascalCase", pascal_fn)],
                key=lambda x: x[1],
            )
            if dominant[1] > total_cpp_fns * 0.4:
                conventions["naming_style"] = dominant[0]

        # Header style
        if pragma_once + header_guard > 0:
            if pragma_once >= header_guard:
                conventions["header_style"] = f"#pragma once ({pragma_once}/{pragma_once + header_guard} headers)"
            else:
                conventions["header_style"] = f"include guards ({header_guard}/{pragma_once + header_guard} headers)"

        # Memory management
        if smart_ptr > 0 and raw_ptr_new > 0:
            conventions["memory_management"] = f"mixed smart/raw pointers ({smart_ptr} smart, {raw_ptr_new} raw new)"
        elif smart_ptr > 0:
            conventions["memory_management"] = f"smart pointers ({smart_ptr} files)"
        elif raw_ptr_new > 0:
            conventions["memory_management"] = f"raw pointers ({raw_ptr_new} files with new)"

        if raii_patterns > n // 4:
            conventions["raii"] = f"RAII pattern used ({raii_patterns} classes with destructors)"

        if doxygen > n // 3:
            conventions["documentation"] = f"Doxygen comments ({doxygen}/{n} files)"

        if namespace_count > n // 2:
            conventions["namespaces"] = f"widely used ({namespace_count}/{n} files)"

        if const_ref > n // 3:
            conventions["const_correctness"] = f"const& usage detected ({const_ref}/{n} files)"

    # Test naming pattern (language-aware)
    test_files = [f for f in files if "test" in f.name.lower() or "spec" in f.name.lower()]
    if test_files:
        prefix_py   = sum(1 for f in test_files if f.name.startswith("test_"))
        suffix_py   = sum(1 for f in test_files if f.name.endswith(("_test.py", "_test.ts")))
        suffix_ts   = sum(1 for f in test_files if f.name.endswith((".test.ts", ".spec.ts")))
        suffix_cpp  = sum(1 for f in test_files if f.suffix.lower() in (".cpp", ".cc", ".cxx")
                          and ("test" in f.stem.lower() or "spec" in f.stem.lower()))
        if prefix_py > max(suffix_py, suffix_ts, suffix_cpp):
            conventions["test_naming"] = f"test_* prefix ({prefix_py} files)"
        elif suffix_ts > 0:
            conventions["test_naming"] = f"*.test.ts / *.spec.ts ({suffix_ts} files)"
        elif suffix_py > 0:
            conventions["test_naming"] = f"*_test suffix ({suffix_py} files)"
        elif suffix_cpp > 0:
            conventions["test_naming"] = f"*_test.cpp / *_spec.cpp ({suffix_cpp} files)"
        conventions["test_file_count"] = len(test_files)

    return conventions


# ---------------------------------------------------------------------------
# ADR detection
# ---------------------------------------------------------------------------


def _find_adrs(root: Path) -> list[dict[str, str]]:
    adrs: list[dict[str, str]] = []
    for adr_dir in ("docs/adr", "docs/decisions", "adr", "decisions", "docs/architecture"):
        path = root / adr_dir
        if path.is_dir():
            for f in sorted(path.iterdir()):
                if f.suffix.lower() == ".md":
                    try:
                        title = f.read_text(encoding="utf-8", errors="replace").split("\n")[0].lstrip("# ").strip()
                    except OSError:
                        title = f.stem
                    adrs.append({"file": str(f.relative_to(root)), "title": title})
    for pattern in ("ADR-*.md", "adr-*.md"):
        for f in root.glob(pattern):
            adrs.append({"file": f.name, "title": f.stem})
    return adrs


# ---------------------------------------------------------------------------
# Module map
# ---------------------------------------------------------------------------


_KNOWN_DIR_PURPOSES: dict[str, str] = {
    # General
    "src":            "Source code root",
    "lib":            "Library code",
    "app":            "Application entry",
    "api":            "API endpoints",
    "tests":          "Test suite",
    "test":           "Test suite",
    "spec":           "Test specifications",
    "docs":           "Documentation",
    "scripts":        "Build / utility scripts",
    "config":         "Configuration files",
    "migrations":     "Database migrations",
    "static":         "Static assets",
    "public":         "Public assets",
    "templates":      "HTML templates",
    "frontend":       "Frontend application",
    "backend":        "Backend application",
    "cli":            "Command-line interface",
    "core":           "Core business logic",
    "services":       "Service layer",
    "models":         "Data models",
    "providers":      "Provider implementations",
    "adapters":       "Adapter implementations",
    "handlers":       "Request / event handlers",
    "middleware":     "Middleware components",
    "utils":          "Utility functions",
    "helpers":        "Helper functions",
    "common":         "Shared / common code",
    "shared":         "Shared modules",
    "types":          "Type definitions",
    "schemas":        "Data schemas",
    "routes":         "Route definitions",
    "controllers":    "Controller layer",
    "repositories":   "Data access repositories",
    "packs":          "Standards packs",
    "rules":          "Rule definitions",
    "reporters":      "Output formatters",
    "infra":          "Infrastructure code",
    "deploy":         "Deployment configuration",
    "docker":         "Docker configuration",
    "k8s":            "Kubernetes manifests",
    "ci":             "CI/CD configuration",
    "tools":          "Developer tooling",
    "examples":       "Example code",
    "demos":          "Demo applications",
    # C / C++ specific
    "include":        "Header files",
    "inc":            "Header files",
    "headers":        "Header files",
    "hal":            "Hardware abstraction layer",
    "drivers":        "Device drivers",
    "driver":         "Device drivers",
    "safety":         "Safety-critical components",
    "hardware":       "Hardware interface",
    "hw":             "Hardware interface",
    "io":             "I/O handling",
    "ipc":            "Inter-process communication",
    "rtos":           "Real-time OS components",
    "platform":       "Platform-specific code",
    "bsp":            "Board support package",
    "boards":         "Board support packages",
    "firmware":       "Firmware",
    "boot":           "Boot loader",
    "kernel":         "Kernel / OS layer",
    "net":            "Networking",
    "network":        "Networking",
    "protocol":       "Protocol implementations",
    "protocols":      "Protocol implementations",
    "diagnostics":    "Diagnostics",
    "diag":           "Diagnostics",
    "logging":        "Logging",
    "log":            "Logging",
    "communication":  "Communication layer",
    "comm":           "Communication layer",
    "sensor":         "Sensor interfaces",
    "sensors":        "Sensor interfaces",
    "actuator":       "Actuator control",
    "actuators":      "Actuator control",
    "motion":         "Motion control",
    "vision":         "Computer vision",
    "imaging":        "Image processing",
    "image":          "Image processing",
    "calibration":    "Calibration",
    "simulation":     "Simulation",
    "sim":            "Simulation",
    "math":           "Mathematical utilities",
    "geometry":       "Geometric computation",
    "planning":       "Path / task planning",
    "planner":        "Path / task planning",
    "control":        "Control algorithms",
    "controller":     "Control algorithms",
    "estimation":     "State estimation",
    "slam":           "SLAM algorithms",
    "navigation":     "Navigation",
    "nav":            "Navigation",
    "watchdog":       "Watchdog / fault monitoring",
    "fault":          "Fault handling",
    "recovery":       "Error recovery",
    "crypto":         "Cryptography",
    "security":       "Security",
    "auth":           "Authentication & authorization",
    "storage":        "Data storage",
    "database":       "Database",
    "db":             "Database",
    "audio":          "Audio processing",
    "video":          "Video processing",
    "display":        "Display / rendering",
    "ui":             "User interface",
    "gui":            "Graphical user interface",
    "cmake":          "CMake build files",
    "third_party":    "Third-party dependencies",
    "external":       "External dependencies",
    "vendor":         "Vendored dependencies",
    "generated":      "Auto-generated code",
    "gen":            "Auto-generated code",
    "proto":          "Protobuf definitions",
    "protos":         "Protobuf definitions",
}


def _infer_dir_purpose(d: Path, src_files_in_dir: list[Path]) -> str:
    """Infer a human-readable purpose for a directory when it's not in _KNOWN_DIR_PURPOSES."""
    # Try a subdirectory README first
    for readme in ("README.md", "readme.md", "README.rst"):
        readme_path = d / readme
        if readme_path.is_file():
            try:
                lines = readme_path.read_text(encoding="utf-8", errors="replace").splitlines()
                for line in lines:
                    line = line.strip().lstrip("#").strip()
                    if line and not line.startswith("!"):
                        return line[:80]
            except OSError:
                pass

    if not src_files_in_dir:
        return ""

    # Infer from file naming patterns
    names = [f.name.lower() for f in src_files_in_dir]
    stems = [f.stem.lower() for f in src_files_in_dir]
    test_count = sum(
        1 for n in names
        if n.startswith("test_")
        or n.endswith(("_test.py", "_test.cpp", "_test.cc", "_test.cxx",
                        ".test.ts", ".spec.ts", "_spec.cpp"))
        or "test" in n.split(".")[0]
    )
    if test_count > len(src_files_in_dir) // 2:
        return "Test suite"

    # Infer from common stem patterns (web + embedded/C++)
    for kw, label in (
        ("model", "Data models"), ("schema", "Data schemas"), ("route", "Route definitions"),
        ("handler", "Request handlers"), ("controller", "Controllers"), ("service", "Services"),
        ("util", "Utilities"), ("helper", "Helper functions"), ("config", "Configuration"),
        ("migration", "Database migrations"), ("middleware", "Middleware"),
        ("plugin", "Plugins"), ("command", "CLI commands"), ("task", "Background tasks"),
        ("event", "Event handlers"), ("hook", "Hooks"), ("store", "State management"),
        ("component", "UI components"), ("page", "Pages"), ("view", "Views"),
        ("seed", "Database seeds"), ("fixture", "Test fixtures"),
        # C/C++ / embedded patterns
        ("driver", "Device drivers"), ("hal", "Hardware abstraction"),
        ("safety", "Safety-critical"), ("watchdog", "Watchdog / fault monitoring"),
        ("calibrat", "Calibration"), ("sensor", "Sensor interfaces"),
        ("actuator", "Actuator control"), ("motion", "Motion control"),
        ("vision", "Computer vision"), ("imag", "Image processing"),
        ("protocol", "Protocol implementations"), ("network", "Networking"),
        ("ipc", "Inter-process communication"), ("serial", "Serial communication"),
        ("crypto", "Cryptography"), ("fault", "Fault handling"),
        ("logger", "Logging"), ("diagnos", "Diagnostics"),
        ("parser", "Parsers"), ("codec", "Codec"),
        ("planner", "Planning"), ("estimat", "State estimation"),
        ("thread", "Threading"), ("mutex", "Synchronization"),
    ):
        if sum(1 for s in stems if kw in s) > max(1, len(stems) // 3):
            return label

    return ""


def _build_module_map(root: Path, files: list[Path], exclude_patterns: list[str]) -> list[dict[str, Any]]:
    module_map: list[dict[str, Any]] = []

    for d in sorted(root.iterdir()):
        if not d.is_dir():
            continue
        if d.name.startswith(".") or d.name in _ALWAYS_SKIP:
            continue
        if _should_skip_dir(d, exclude_patterns, root):
            continue

        # Prefer the known-purposes table; fall back to content inference
        purpose = _KNOWN_DIR_PURPOSES.get(d.name.lower(), "")
        src_files_in_dir = [f for f in files if str(f).startswith(str(d))]
        if not purpose:
            purpose = _infer_dir_purpose(d, src_files_in_dir)

        src_count = len(src_files_in_dir)
        all_count = sum(1 for _ in d.rglob("*") if _.is_file())
        if all_count > 0:
            module_map.append({
                "directory":    d.name,
                "purpose":      purpose,
                "files":        all_count,
                "source_files": src_count,
            })

    return module_map


# ---------------------------------------------------------------------------
# Project identity extraction
# ---------------------------------------------------------------------------


def _extract_identity(root: Path) -> dict[str, str]:
    identity: dict[str, str] = {"name": "", "description": "", "version": ""}

    # pyproject.toml
    pyproject = root / "pyproject.toml"
    if pyproject.is_file():
        try:
            text = pyproject.read_text(encoding="utf-8", errors="replace")
            for field in ("name", "version", "description"):
                m = re.search(rf'^{field}\s*=\s*["\']([^"\']+)["\']', text, re.MULTILINE)
                if m and not identity[field]:
                    identity[field] = m.group(1).strip()
        except OSError:
            pass

    # package.json (root)
    pkg_json = root / "package.json"
    if pkg_json.is_file():
        try:
            pkg = json.loads(pkg_json.read_text(encoding="utf-8"))
            for field in ("name", "version", "description"):
                if not identity[field] and pkg.get(field):
                    identity[field] = str(pkg[field])
        except (json.JSONDecodeError, OSError):
            pass

    # README.md — grab the first non-heading paragraph
    for readme_name in ("README.md", "readme.md", "README.rst"):
        readme = root / readme_name
        if readme.is_file():
            try:
                lines = readme.read_text(encoding="utf-8", errors="replace").splitlines()
                for line in lines:
                    line = line.strip()
                    if line and not line.startswith("#") and not line.startswith("!") and not identity["description"]:
                        identity["description"] = line[:200]
                        break
            except OSError:
                pass
            break

    return identity


# ---------------------------------------------------------------------------
# Pack recommendations
# ---------------------------------------------------------------------------


def _recommend_packs(
    frameworks: list[dict[str, str]],
    languages: list[str],
    identity: dict[str, str],
    files: list[Path] | None = None,
) -> list[dict[str, str]]:
    """Return deterministic Sentrik pack recommendations based on detected stack.

    Scans manifest identity fields AND a sample of source file content so that
    domain context buried in code (e.g. "robot calibration" in a medical device
    project) is found even when it doesn't appear in pyproject.toml or README.
    """
    recs: dict[str, str] = {}  # pack_id → reason

    framework_names = {f["name"] for f in frameworks}

    for fw in framework_names:
        for pack in _FRAMEWORK_PACK_RECS.get(fw, []):
            recs.setdefault(pack, f"{fw} detected")

    for lang in languages:
        for pack in _LANG_PACK_RECS.get(lang, []):
            recs.setdefault(pack, f"{lang} codebase")

    # Build a corpus for keyword matching: manifest identity + sample of source content.
    # We read up to 50 source files (first 4 KB each) so we catch domain terms that
    # only appear in actual code rather than the project description.
    corpus_parts = [
        identity.get("name", ""),
        identity.get("description", ""),
    ]
    if files:
        sampled = files[:50]
        for fpath in sampled:
            try:
                corpus_parts.append(fpath.read_text(encoding="utf-8", errors="replace")[:4096])
            except OSError:
                pass

    corpus = " ".join(corpus_parts).lower()

    for keywords, pack, reason in _KEYWORD_PACK_RECS:
        if any(kw in corpus for kw in keywords):
            recs.setdefault(pack, reason)

    return [{"pack": pack, "reason": reason} for pack, reason in sorted(recs.items())]


# ---------------------------------------------------------------------------
# Design constraints (MCP tool support)
# ---------------------------------------------------------------------------


def get_design_constraints(
    profile: dict[str, Any],
    file_path: str | None = None,
    intent: str | None = None,
) -> dict[str, Any]:
    """Return design constraints for a specific file or intent (used by MCP tool)."""
    frameworks = {f["name"] for f in profile.get("frameworks", [])}
    arch_patterns = [p["pattern"] for p in profile.get("architecture", [])]

    constraints: dict[str, Any] = {
        "tech_stack":          profile.get("tech_stack", []),
        "established_patterns": list(arch_patterns),
        "architectural_rules": profile.get("architecture", []),
        "adrs":                profile.get("adrs", []),
        "conventions":         profile.get("conventions", {}),
        "tech_stack_warnings": [],
    }

    # File-path-specific guidance
    if file_path:
        parts = Path(file_path).parts
        if any(p in ("api", "routes", "endpoints", "views") for p in parts):
            if "FastAPI" in frameworks:
                constraints["established_patterns"].append(
                    "Use FastAPI APIRouter, Depends() for DI, and Pydantic models for request/response."
                )
            elif "Express" in frameworks:
                constraints["established_patterns"].append(
                    "Use Express Router, middleware pattern, and async error handling."
                )
            elif "Django" in frameworks:
                constraints["established_patterns"].append(
                    "Use class-based views or DRF serializers for API endpoints."
                )
        if any(p in ("db", "database", "repositories", "models") for p in parts):
            if "SQLAlchemy" in frameworks:
                constraints["established_patterns"].append(
                    "Use the existing SQLAlchemy session pattern and declarative models."
                )
            elif "Prisma" in frameworks:
                constraints["established_patterns"].append(
                    "Use the Prisma client for all database operations."
                )

    # Intent-based guidance
    if intent:
        intent_lower = intent.lower()
        if "auth" in intent_lower:
            constraints["established_patterns"].append(
                "Check existing auth patterns before implementing authentication. Do not introduce a second auth system."
            )
        if "database" in intent_lower or "migration" in intent_lower:
            constraints["established_patterns"].append(
                "Use the project's established ORM/database library. Do not introduce a new one."
            )

    if frameworks:
        constraints["tech_stack_warnings"].append(
            f"Project uses: {', '.join(sorted(frameworks))}. Do not introduce conflicting frameworks."
        )

    return constraints


# ---------------------------------------------------------------------------
# Profile-context — three-layer persistent understanding
# ---------------------------------------------------------------------------


def _read_scan_insights(output_dir: str = "out") -> dict[str, Any]:
    """Extract actionable insights from the most recent findings.json.

    Returns a dict with:
    - severity_counts: {critical, high, medium, low, info} tallies
    - top_rules: [(rule_id, count), ...] up to 10 most-fired rules
    - risk_modules: [path, ...] top directories with most findings
    - frameworks_flagged: [standard, ...] distinct compliance standards hit
    - total: total finding count
    """
    path = Path(output_dir) / "findings.json"
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}

    findings = data if isinstance(data, list) else data.get("findings", [])
    if not findings:
        return {}

    severity_counts: Counter[str] = Counter()
    rule_counts: Counter[str] = Counter()
    module_counts: Counter[str] = Counter()
    standards: set[str] = set()

    for f in findings:
        sev = (f.get("severity") or "info").lower()
        severity_counts[sev] += 1

        rule_id = f.get("rule_id", "")
        if rule_id:
            rule_counts[rule_id] += 1

        # Top-level path component as module proxy
        evidence = f.get("evidence") or {}
        file_path = evidence.get("file", "") if isinstance(evidence, dict) else ""
        if not file_path:
            file_path = f.get("file", "")
        if file_path:
            parts = Path(file_path).parts
            if parts:
                module_counts[parts[0]] += 1

        std = f.get("standard", "")
        if std:
            standards.add(std)

    return {
        "total": len(findings),
        "severity_counts": dict(severity_counts),
        "top_rules": rule_counts.most_common(10),
        "risk_modules": [mod for mod, _ in module_counts.most_common(5)],
        "frameworks_flagged": sorted(standards),
    }


def _read_profile_context(root: str = ".") -> str:
    """Read the existing .sentrik/profile-context.md if present."""
    path = Path(root) / ".sentrik" / "profile-context.md"
    if not path.is_file():
        return ""
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def save_profile_context(content: str, root: str = ".") -> Path:
    """Write the LLM-generated profile-context.md to .sentrik/."""
    sentrik_dir = Path(root) / ".sentrik"
    sentrik_dir.mkdir(parents=True, exist_ok=True)
    path = sentrik_dir / "profile-context.md"
    path.write_text(content, encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------


def save_profile(profile: dict[str, Any], output_dir: str = "out") -> Path:
    import datetime
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    profile["generated_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    path = out / "project-profile.json"
    path.write_text(json.dumps(profile, indent=2), encoding="utf-8")
    return path


def load_profile(output_dir: str = "out") -> dict[str, Any] | None:
    path = Path(output_dir) / "project-profile.json"
    if path.is_file():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None
    return None
