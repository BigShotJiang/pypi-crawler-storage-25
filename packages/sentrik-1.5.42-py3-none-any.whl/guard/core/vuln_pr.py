"""Phase 2 auto-remediation: create a PR with vulnerability fixes.

After ``vuln_fixer`` patches manifest files in-place, this module:
1. Creates a git branch (``sentrik/fix-vulns-{date}``)
2. Stages and commits the modified manifests
3. Pushes the branch to the remote
4. Opens a pull request via the configured DevOps provider
"""

from __future__ import annotations

import logging
import subprocess
from datetime import date
from typing import Any

from guard.core.vuln_fixer import FixAction, FixReport
from guard.core.vuln_scanner import Vulnerability

logger = logging.getLogger(__name__)


def _run_git(args: list[str], cwd: str) -> str:
    """Run a git command and return stdout.  Raises on failure."""
    result = subprocess.run(
        ["git"] + args,
        capture_output=True,
        text=True,
        cwd=cwd,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"git {' '.join(args)} failed (rc={result.returncode}): "
            f"{result.stderr.strip()}"
        )
    return result.stdout.strip()


def _get_default_branch(cwd: str) -> str:
    """Detect the default branch (main or master)."""
    try:
        ref = _run_git(["symbolic-ref", "refs/remotes/origin/HEAD"], cwd)
        # e.g. "refs/remotes/origin/main"
        return ref.rsplit("/", 1)[-1]
    except RuntimeError:
        pass
    # Fallback: check if main exists
    try:
        _run_git(["rev-parse", "--verify", "origin/main"], cwd)
        return "main"
    except RuntimeError:
        return "master"


def _generate_pr_body(
    actions: list[FixAction],
    vulns: list[Vulnerability] | None = None,
) -> str:
    """Build a markdown PR body with a table of changes.

    If *vulns* are provided, the CVE/GHSA IDs resolved by each package
    upgrade are listed in the last column.
    """
    # Build a mapping: package (lower) -> list of vuln IDs
    vuln_map: dict[str, list[str]] = {}
    if vulns:
        for v in vulns:
            key = v.affected_package.lower()
            vuln_map.setdefault(key, []).append(v.id)

    lines: list[str] = [
        "## Vulnerable Dependencies Updated",
        "",
        "| Package | Previous | Updated | CVEs Resolved |",
        "|---------|----------|---------|---------------|",
    ]
    for a in actions:
        if not a.applied:
            continue
        cve_ids = vuln_map.get(a.package.lower(), [])
        cve_str = ", ".join(sorted(set(cve_ids))) if cve_ids else "-"
        lines.append(
            f"| {a.package} | {a.current_version} | {a.fixed_version} | {cve_str} |"
        )

    lines.append("")
    lines.append("Updated by [SENTRIK](https://sentrik.dev) vulnerability scanner.")
    return "\n".join(lines)


def _create_pr_via_provider(
    provider: Any,
    title: str,
    body: str,
    source_branch: str,
    target_branch: str,
) -> dict:
    """Dispatch PR creation to the DevOps provider's ``create_pull_request`` method.

    Returns ``{"pr_url": ..., "pr_id": ...}`` or empty dict on failure/stub.
    """
    if hasattr(provider, "create_pull_request"):
        return provider.create_pull_request(title, body, source_branch, target_branch)
    logger.info("DevOps provider does not support PR creation; skipping.")
    return {}


def create_fix_pr(
    fix_report: FixReport,
    config: Any,
    repo_root: str,
    vulns: list[Vulnerability] | None = None,
    devops_provider: Any | None = None,
) -> dict:
    """Create a branch, commit patched manifests, push, and open a PR.

    Parameters
    ----------
    fix_report:
        The report from ``apply_fixes`` — only ``applied=True`` actions are included.
    config:
        A ``GuardConfig`` instance (used to build the DevOps provider if not given).
    repo_root:
        Absolute path to the git repository root.
    vulns:
        Optional list of ``Vulnerability`` objects for the PR body CVE column.
    devops_provider:
        Optional pre-built DevOps provider instance.

    Returns
    -------
    dict with keys: ``branch``, ``pr_url``, ``pr_id``, ``changes_count``.
    """
    applied = [a for a in fix_report.actions if a.applied]
    if not applied:
        raise ValueError("No applied fixes to commit")

    today = date.today().strftime("%Y%m%d")
    branch_name = f"sentrik/fix-vulns-{today}"

    # 1. Create branch
    _run_git(["checkout", "-b", branch_name], repo_root)

    # 2. Stage modified manifests (deduplicate paths)
    manifest_files = sorted({a.manifest_file for a in applied})
    for mf in manifest_files:
        _run_git(["add", mf], repo_root)

    # 3. Commit
    count = len(applied)
    summary_lines = [f"- {a.package}: {a.current_version} -> {a.fixed_version}" for a in applied]
    commit_msg = (
        f"fix: update {count} vulnerable dependenc{'y' if count == 1 else 'ies'}\n\n"
        + "\n".join(summary_lines)
    )
    _run_git(["commit", "-m", commit_msg], repo_root)

    # 4. Push
    _run_git(["push", "-u", "origin", branch_name], repo_root)

    # 5. Create PR via DevOps provider
    if devops_provider is None:
        from guard.providers.factory import build_devops
        devops_provider = build_devops(config)

    target_branch = _get_default_branch(repo_root)
    title = f"fix: Update {count} vulnerable dependenc{'y' if count == 1 else 'ies'}"
    body = _generate_pr_body(applied, vulns)

    pr_info = _create_pr_via_provider(
        devops_provider, title, body, branch_name, target_branch,
    )

    return {
        "branch": branch_name,
        "pr_url": pr_info.get("pr_url", ""),
        "pr_id": pr_info.get("pr_id"),
        "changes_count": count,
    }
