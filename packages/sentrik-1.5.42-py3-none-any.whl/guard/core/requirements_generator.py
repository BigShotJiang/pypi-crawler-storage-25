"""Auto-generate structured requirements from untracked source files."""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from guard.core.models import GeneratedRequirement, WorkItem
from guard.providers.devops_base import DevOpsProvider
from guard.providers.llm_base import LLMProvider

_REQ_GEN_RE = re.compile(r"^REQ-GEN-(\d+)$")


# ---------------------------------------------------------------------------
# Deduplication — files already covered
# ---------------------------------------------------------------------------

def get_already_covered_files(
    requirements_path: Path,
    work_items: list[WorkItem],
) -> set[str]:
    """Return the set of files already covered by existing requirements or work items.

    Checks two sources:
    1. ``requirements.yaml`` — any entry with ``source_files`` (regardless of status)
    2. Work items whose description or title mentions source file paths
    """
    covered: set[str] = set()

    # 1. From requirements.yaml
    if requirements_path.exists():
        try:
            with open(requirements_path, encoding="utf-8") as f:
                loaded = yaml.safe_load(f)
            entries = []
            if isinstance(loaded, dict) and "requirements" in loaded:
                entries = loaded["requirements"]
            elif isinstance(loaded, list):
                entries = loaded
            for entry in entries:
                if isinstance(entry, dict) and "source_files" in entry:
                    for sf in entry["source_files"]:
                        covered.add(sf)
        except (yaml.YAMLError, OSError, ValueError):
            pass

    # 2. From work items — check for source file paths in descriptions
    for wi in work_items:
        if not wi.description:
            continue
        desc = wi.description
        # Work items created by generate-reqs include "Source files:" sections
        # or <code>path</code> HTML tags
        if "Source files:" not in desc and "<code>" not in desc:
            continue
        # Extract paths from <code>path</code> HTML tags
        for m in re.finditer(r"<code>([^<]+)</code>", desc):
            path = m.group(1).strip()
            if "/" in path:
                covered.add(path)
        # Extract file paths from "- path/to/file.py" lines
        for line in desc.splitlines():
            line = line.strip().lstrip("- ")
            if "/" in line and not line.startswith("#") and not line.startswith("<"):
                covered.add(line)

    return covered


# ---------------------------------------------------------------------------
# File grouping
# ---------------------------------------------------------------------------

def _group_files_by_module(files: list[str]) -> dict[str, list[str]]:
    """Group file paths by their parent directory.

    Related files in the same directory get a single requirement.
    """
    groups: dict[str, list[str]] = {}
    for f in files:
        parent = str(Path(f).parent).replace("\\", "/")
        if parent == ".":
            parent = "(root)"
        groups.setdefault(parent, []).append(f)
    return groups


# ---------------------------------------------------------------------------
# LLM prompt
# ---------------------------------------------------------------------------

_GENERATION_PROMPT = """\
You are a requirements engineer. Given source code files, draft a structured \
software requirement that describes what the code implements.

Return ONLY valid JSON with these fields:
{
  "title": "Short requirement title (max 80 chars)",
  "description": "What the code does, 1-3 sentences",
  "acceptance_criteria": ["Testable criterion 1", "Testable criterion 2"]
}

Source files:
"""


def _build_generation_prompt(
    file_paths: list[str], contents: list[str],
) -> tuple[str, dict[str, Any]]:
    """Build the LLM prompt and context dict for requirement generation."""
    body = _GENERATION_PROMPT
    for path, content in zip(file_paths, contents):
        body += f"\n--- {path} ---\n{content}\n"
    context = {"files": file_paths}
    return body, context


# ---------------------------------------------------------------------------
# Core generation
# ---------------------------------------------------------------------------

_MAX_CONTENT_BYTES = 50_000  # cap per group to avoid token overflows


def generate_requirements(
    files: list[str],
    repo_root: str,
    llm: LLMProvider,
) -> list[GeneratedRequirement]:
    """Generate requirements for a list of untracked files using an LLM.

    Files are grouped by parent directory; each group produces one requirement.
    Falls back to stub generation on LLM error.
    """
    groups = _group_files_by_module(files)
    results: list[GeneratedRequirement] = []
    seq = 1

    for _module, group_files in sorted(groups.items()):
        # Read file contents (cap total size)
        paths: list[str] = []
        contents: list[str] = []
        total = 0
        for fp in group_files:
            full = Path(repo_root) / fp
            if not full.is_file():
                continue
            try:
                text = full.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            if total + len(text.encode()) > _MAX_CONTENT_BYTES:
                break
            paths.append(fp)
            contents.append(text)
            total += len(text.encode())

        if not paths:
            continue

        req_id = f"REQ-GEN-{seq:03d}"

        try:
            prompt, context = _build_generation_prompt(paths, contents)
            response = llm.analyze(prompt, context)
            req = _parse_llm_response(response, req_id, paths)
        except (ValueError, TypeError, KeyError):
            req = _stub_requirement(req_id, paths)

        results.append(req)
        seq += 1

    return results


def _parse_llm_response(
    response: dict[str, Any], req_id: str, source_files: list[str],
) -> GeneratedRequirement:
    """Parse an LLM response dict into a GeneratedRequirement."""
    # The LLM may return findings-style or direct fields.
    # Try the direct fields first, then look in summary.
    title = response.get("title", "")
    description = response.get("description", "")
    acceptance_criteria = response.get("acceptance_criteria", [])

    # If LLM returned a "summary" field with JSON-like content, try to parse it.
    if not title and "summary" in response:
        summary = response["summary"]
        try:
            parsed = json.loads(summary) if isinstance(summary, str) else summary
            if isinstance(parsed, dict):
                title = parsed.get("title", title)
                description = parsed.get("description", description)
                acceptance_criteria = parsed.get("acceptance_criteria", acceptance_criteria)
        except (json.JSONDecodeError, TypeError):
            pass

    if not title:
        # Derive title from files
        title = _title_from_files(source_files)

    if not isinstance(acceptance_criteria, list):
        acceptance_criteria = [str(acceptance_criteria)]

    return GeneratedRequirement(
        req_id=req_id,
        title=title,
        description=description,
        acceptance_criteria=acceptance_criteria,
        source_files=source_files,
    )


def _title_from_files(files: list[str]) -> str:
    """Derive a short title from a list of file paths."""
    if not files:
        return "Untitled requirement"
    first = Path(files[0])
    stem = first.stem.replace("_", " ").replace("-", " ").title()
    parent = first.parent.name
    if parent and parent not in (".", "(root)"):
        return f"Implement {parent}/{stem}"
    return f"Implement {stem}"


# ---------------------------------------------------------------------------
# Stub fallback (no LLM)
# ---------------------------------------------------------------------------

def generate_requirements_stub(
    files: list[str], repo_root: str | None = None,
) -> list[GeneratedRequirement]:
    """Generate template-based requirements when LLM is unavailable.

    When *repo_root* is provided, files are read to extract docstrings,
    class names, and function names for richer descriptions.
    """
    groups = _group_files_by_module(files)
    results: list[GeneratedRequirement] = []
    seq = 1

    for _module, group_files in sorted(groups.items()):
        req_id = f"REQ-GEN-{seq:03d}"
        results.append(_stub_requirement(req_id, group_files, repo_root))
        seq += 1

    return results


def _extract_code_summary(file_path: str, repo_root: str | None) -> dict:
    """Extract docstring, class names, and function names from a source file."""
    summary: dict = {"docstring": "", "classes": [], "functions": []}
    if not repo_root:
        return summary
    full = Path(repo_root) / file_path
    if not full.is_file() or not file_path.endswith(".py"):
        return summary
    try:
        import ast
        source = full.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source, filename=file_path)
        # Module docstring
        if (tree.body and isinstance(tree.body[0], ast.Expr)
                and isinstance(tree.body[0].value, ast.Constant)
                and isinstance(tree.body[0].value.value, str)):
            summary["docstring"] = tree.body[0].value.value.strip()
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, ast.ClassDef):
                summary["classes"].append(node.name)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if not node.name.startswith("_"):
                    summary["functions"].append(node.name)
    except (SyntaxError, ValueError):
        pass
    return summary


def _stub_requirement(
    req_id: str, source_files: list[str], repo_root: str | None = None,
) -> GeneratedRequirement:
    """Build a single stub requirement from file paths and code analysis."""
    title = _title_from_files(source_files)
    file_list = ", ".join(Path(f).name for f in source_files[:5])

    # Extract code info for richer descriptions
    all_docstrings: list[str] = []
    all_classes: list[str] = []
    all_functions: list[str] = []
    for fp in source_files:
        info = _extract_code_summary(fp, repo_root)
        if info["docstring"]:
            all_docstrings.append(info["docstring"])
        all_classes.extend(info["classes"])
        all_functions.extend(info["functions"])

    # Build description from extracted info
    desc_parts: list[str] = []
    if all_docstrings:
        desc_parts.append(". ".join(all_docstrings[:3]))
    else:
        desc_parts.append(f"Requirement covering: {file_list}")
    if all_classes:
        desc_parts.append(f"Key components: {', '.join(all_classes[:8])}")
    if all_functions:
        desc_parts.append(f"Key functions: {', '.join(all_functions[:8])}")
    description = "\n\n".join(desc_parts)

    # Build acceptance criteria from code info
    acceptance_criteria: list[str] = []
    for cls in all_classes[:5]:
        acceptance_criteria.append(f"{cls} behaves correctly under normal and error conditions")
    for fn in all_functions[:5]:
        if not acceptance_criteria or len(acceptance_criteria) < 6:
            acceptance_criteria.append(f"{fn}() produces correct output for valid and invalid inputs")
    if not acceptance_criteria:
        acceptance_criteria = [
            f"Code in {file_list} is reviewed and tested",
        ]
    acceptance_criteria.append("Unit tests pass for all covered modules")

    return GeneratedRequirement(
        req_id=req_id,
        title=title,
        description=description,
        acceptance_criteria=acceptance_criteria,
        source_files=source_files,
    )


# ---------------------------------------------------------------------------
# YAML writer
# ---------------------------------------------------------------------------

def write_requirements_yaml(
    requirements: list[GeneratedRequirement], path: Path,
) -> Path:
    """Write (or merge) requirements to a YAML file.

    If the file already exists, new drafts are appended; approved/rejected
    entries are preserved unchanged.
    """
    existing: list[dict] = []
    if path.exists():
        try:
            with open(path, encoding="utf-8") as f:
                loaded = yaml.safe_load(f)
            if isinstance(loaded, dict) and "requirements" in loaded:
                existing = loaded["requirements"]
            elif isinstance(loaded, list):
                existing = loaded
        except (yaml.YAMLError, OSError, ValueError):
            pass

    # Index existing by req_id for merge
    existing_by_id: dict[str, dict] = {}
    for entry in existing:
        if isinstance(entry, dict) and "req_id" in entry:
            existing_by_id[entry["req_id"]] = entry

    # Index existing by source_files to detect true duplicates
    existing_by_files: set[str] = set()
    for entry in existing:
        if isinstance(entry, dict) and "source_files" in entry:
            existing_by_files.add(",".join(sorted(entry["source_files"])))

    # Find the next available sequence number
    max_seq = 0
    for rid in existing_by_id:
        m = _REQ_GEN_RE.match(rid)
        if m:
            max_seq = max(max_seq, int(m.group(1)))

    merged: list[dict] = []

    # Preserve all existing entries
    for entry in existing:
        if isinstance(entry, dict):
            merged.append(entry)

    # Add new requirements — renumber if ID conflicts
    for req in requirements:
        files_key = ",".join(sorted(req.source_files))
        if files_key in existing_by_files:
            continue  # Same files already have a requirement
        if req.req_id in existing_by_id:
            # Renumber to avoid collision
            max_seq += 1
            req = req.model_copy(update={"req_id": f"REQ-GEN-{max_seq:03d}"})
        merged.append(req.model_dump(exclude_none=True))

    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    doc = {
        "generated_at": now,
        "requirements": merged,
    }

    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"# Auto-generated requirements — {now}\n")
        f.write("# Status: draft | approved | rejected\n")
        yaml.dump(doc, f, default_flow_style=False, sort_keys=False, allow_unicode=True)

    return path


# ---------------------------------------------------------------------------
# DevOps push
# ---------------------------------------------------------------------------

def _format_html_description(req: GeneratedRequirement) -> str:
    """Format a requirement as HTML for Azure DevOps work item descriptions."""
    parts: list[str] = []
    if req.description:
        # Convert newlines in description to paragraphs
        for para in req.description.split("\n\n"):
            para = para.strip()
            if para.startswith("Key components:") or para.startswith("Key functions:"):
                parts.append(f"<p><strong>{para.split(':')[0]}:</strong>{para.split(':', 1)[1]}</p>")
            elif para:
                parts.append(f"<p>{para}</p>")
    if req.acceptance_criteria:
        parts.append("<h3>Acceptance Criteria</h3><ul>")
        for ac in req.acceptance_criteria:
            parts.append(f"<li>{ac}</li>")
        parts.append("</ul>")
    if req.source_files:
        parts.append("<h3>Source Files</h3><ul>")
        for f in req.source_files:
            parts.append(f"<li><code>{f}</code></li>")
        parts.append("</ul>")
    parts.append(f'<p><em>Auto-generated by SENTRIK ({req.req_id})</em></p>')
    return "\n".join(parts)


def push_requirements_to_devops(
    requirements: list[GeneratedRequirement],
    devops: DevOpsProvider,
    existing_items: list[WorkItem],
    wi_path: Path,
    work_item_type: str = "Issue",
) -> list[GeneratedRequirement]:
    """Push generated requirements to DevOps as work items.

    Updates ``devops_id`` and ``work_item_id`` on returned objects.
    Appends new entries to ``work_items.json``.
    """
    items = list(existing_items)
    updated_reqs: list[GeneratedRequirement] = []

    for req in requirements:
        if req.status != "draft":
            updated_reqs.append(req)
            continue

        html_desc = _format_html_description(req)
        ac_html = "<ul>" + "".join(f"<li>{c}</li>" for c in req.acceptance_criteria) + "</ul>"

        devops_id = devops.create_work_item(
            title=req.title,
            description=html_desc,
            acceptance_criteria=ac_html,
            tags="guard;auto-generated",
            work_item_type=work_item_type,
        )

        wi_id = _next_wi_id(items)
        new_wi = WorkItem(
            id=wi_id,
            title=req.title,
            description=req.description,
            acceptance_criteria=req.acceptance_criteria,
            state="active",
            devops_id=devops_id,
        )
        items.append(new_wi)

        updated_req = req.model_copy(update={
            "work_item_id": wi_id,
            "devops_id": devops_id,
        })
        updated_reqs.append(updated_req)

    # Write updated work_items.json
    data = [wi.model_dump(exclude_none=True) for wi in items]
    wi_path.parent.mkdir(parents=True, exist_ok=True)
    with open(wi_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")

    return updated_reqs


def _next_wi_id(existing_items: list[WorkItem]) -> str:
    """Generate the next WI-XX identifier."""
    max_num = 0
    for wi in existing_items:
        if wi.id.startswith("WI-"):
            try:
                num = int(wi.id[3:])
                max_num = max(max_num, num)
            except ValueError:
                pass
    return f"WI-{max_num + 1}"
