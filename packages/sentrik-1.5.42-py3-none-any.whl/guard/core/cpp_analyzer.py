"""C/C++ semantic analysis via clang-tidy and cppcheck.

Integrates with external static analysis tools to provide AST-level
findings for MISRA, CERT C, C++ Core Guidelines, and security checks.
"""

from __future__ import annotations

import logging
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from guard.core.models import Evidence, Finding, Severity

logger = logging.getLogger(__name__)

# File extensions recognized as C/C++ source
CPP_EXTENSIONS = {".c", ".cpp", ".cc", ".cxx", ".h", ".hpp", ".hxx", ".hh"}

DEFAULT_CLANG_TIDY_CHECKS = (
    "bugprone-*,cert-*,cppcoreguidelines-*,misc-*,"
    "modernize-*,performance-*,readability-*"
)


@dataclass
class CppAnalyzerResult:
    """Result from running a C/C++ static analysis tool."""

    findings: list[Finding] = field(default_factory=list)
    tool: str = ""
    files_analyzed: int = 0
    errors: list[str] = field(default_factory=list)


# ------------------------------------------------------------------
# Availability checks
# ------------------------------------------------------------------


def is_clang_tidy_available() -> bool:
    """Return True if clang-tidy is on PATH."""
    return shutil.which("clang-tidy") is not None


def is_cppcheck_available() -> bool:
    """Return True if cppcheck is on PATH."""
    return shutil.which("cppcheck") is not None


# ------------------------------------------------------------------
# Severity mapping
# ------------------------------------------------------------------


def _map_clang_tidy_severity(level: str) -> Severity:
    """Map clang-tidy diagnostic level to our Severity enum."""
    level_lower = level.strip().lower()
    if level_lower == "error":
        return Severity.HIGH
    if level_lower == "warning":
        return Severity.MEDIUM
    if level_lower == "note":
        return Severity.LOW
    return Severity.INFO


def _map_cppcheck_severity(level: str) -> Severity:
    """Map cppcheck severity to our Severity enum."""
    level_lower = level.strip().lower()
    if level_lower == "error":
        return Severity.HIGH
    if level_lower == "warning":
        return Severity.MEDIUM
    if level_lower in ("style", "performance", "portability"):
        return Severity.LOW
    if level_lower == "information":
        return Severity.INFO
    return Severity.INFO


def _map_check_to_standard(check_name: str) -> str:
    """Map a clang-tidy check name prefix to a standards name."""
    prefixes = {
        "cert-": "CERT C",
        "bugprone-": "C++ Core Guidelines",
        "cppcoreguidelines-": "C++ Core Guidelines",
        "misc-": "Best Practices",
        "modernize-": "C++ Modernization",
        "performance-": "C++ Performance",
        "readability-": "C++ Readability",
        "misra-": "MISRA C/C++",
        "clang-analyzer-": "Clang Static Analyzer",
        "hicpp-": "High Integrity C++",
    }
    for prefix, standard in prefixes.items():
        if check_name.startswith(prefix):
            return standard
    return "C/C++ Analysis"


# ------------------------------------------------------------------
# clang-tidy
# ------------------------------------------------------------------

# Pattern: file.cpp:line:col: warning: message [check-name]
_CLANG_TIDY_RE = re.compile(
    r"^(?P<file>[^:]+):(?P<line>\d+):(?P<col>\d+):\s+"
    r"(?P<level>warning|error|note):\s+"
    r"(?P<message>.+?)\s+\[(?P<check>[^\]]+)\]$"
)


def _parse_clang_tidy_output(output: str, repo_root: str) -> list[Finding]:
    """Parse clang-tidy stdout into Finding objects."""
    findings: list[Finding] = []
    root = Path(repo_root).resolve()

    for line in output.splitlines():
        m = _CLANG_TIDY_RE.match(line.strip())
        if not m:
            continue

        file_path = m.group("file")
        line_no = int(m.group("line"))
        level = m.group("level")
        message = m.group("message")
        check_name = m.group("check")

        # Make path relative to repo root
        try:
            rel_path = str(Path(file_path).resolve().relative_to(root))
        except (ValueError, OSError):
            rel_path = file_path
        rel_path = rel_path.replace("\\", "/")

        severity = _map_clang_tidy_severity(level)
        standard = _map_check_to_standard(check_name)

        findings.append(
            Finding(
                finding_id=f"clang-tidy-{check_name}-{rel_path}:{line_no}",
                rule_id=check_name,
                severity=severity,
                message=message,
                evidence=Evidence(
                    file=rel_path,
                    lines=[line_no],
                    snippet=message,
                ),
                confidence=1.0,
                deterministic=True,
                standard=standard,
            )
        )

    return findings


def run_clang_tidy(
    files: list[str],
    checks: str = "",
    repo_root: str = ".",
) -> CppAnalyzerResult:
    """Run clang-tidy on the given files and return parsed results.

    Args:
        files: List of C/C++ file paths (relative or absolute).
        checks: Comma-separated clang-tidy checks (empty = defaults).
        repo_root: Repository root for making paths relative.

    Returns:
        CppAnalyzerResult with findings and metadata.
    """
    result = CppAnalyzerResult(tool="clang-tidy", files_analyzed=len(files))

    if not is_clang_tidy_available():
        result.errors.append(
            "clang-tidy is not installed or not on PATH. "
            "Install: apt install clang-tidy (Linux), "
            "brew install llvm (macOS), or download from llvm.org (Windows)."
        )
        return result

    if not files:
        return result

    effective_checks = checks or DEFAULT_CLANG_TIDY_CHECKS

    cmd = [
        "clang-tidy",
        f"--checks={effective_checks}",
        "--",
    ] + files

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=300,
            cwd=repo_root,
        )
        # clang-tidy returns non-zero when there are warnings, that's normal
        output = proc.stdout + proc.stderr
        result.findings = _parse_clang_tidy_output(output, repo_root)
    except subprocess.TimeoutExpired:
        result.errors.append("clang-tidy timed out after 300 seconds.")
    except OSError as exc:
        result.errors.append(f"Failed to run clang-tidy: {exc}")

    return result


# ------------------------------------------------------------------
# cppcheck
# ------------------------------------------------------------------

# Pattern: file:line:severity:id:message
_CPPCHECK_RE = re.compile(
    r"^(?P<file>[^:]+):(?P<line>\d+):(?P<severity>[^:]+):(?P<id>[^:]+):(?P<message>.+)$"
)


def _parse_cppcheck_output(output: str, repo_root: str) -> list[Finding]:
    """Parse cppcheck output into Finding objects."""
    findings: list[Finding] = []
    root = Path(repo_root).resolve()

    for line in output.splitlines():
        m = _CPPCHECK_RE.match(line.strip())
        if not m:
            continue

        file_path = m.group("file")
        line_no = int(m.group("line"))
        sev_str = m.group("severity")
        check_id = m.group("id")
        message = m.group("message")

        # Make path relative to repo root
        try:
            rel_path = str(Path(file_path).resolve().relative_to(root))
        except (ValueError, OSError):
            rel_path = file_path
        rel_path = rel_path.replace("\\", "/")

        severity = _map_cppcheck_severity(sev_str)

        findings.append(
            Finding(
                finding_id=f"cppcheck-{check_id}-{rel_path}:{line_no}",
                rule_id=f"cppcheck-{check_id}",
                severity=severity,
                message=message,
                evidence=Evidence(
                    file=rel_path,
                    lines=[line_no],
                    snippet=message,
                ),
                confidence=1.0,
                deterministic=True,
                standard="C/C++ Analysis",
            )
        )

    return findings


def run_cppcheck(
    files: list[str],
    repo_root: str = ".",
) -> CppAnalyzerResult:
    """Run cppcheck on the given files and return parsed results.

    Args:
        files: List of C/C++ file paths (relative or absolute).
        repo_root: Repository root for making paths relative.

    Returns:
        CppAnalyzerResult with findings and metadata.
    """
    result = CppAnalyzerResult(tool="cppcheck", files_analyzed=len(files))

    if not is_cppcheck_available():
        result.errors.append(
            "cppcheck is not installed or not on PATH. "
            "Install: apt install cppcheck (Linux), "
            "brew install cppcheck (macOS), or download from cppcheck.net (Windows)."
        )
        return result

    if not files:
        return result

    cmd = [
        "cppcheck",
        "--enable=all",
        "--template={file}:{line}:{severity}:{id}:{message}",
        "--quiet",
    ] + files

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=300,
            cwd=repo_root,
        )
        # cppcheck writes diagnostics to stderr
        output = proc.stderr + proc.stdout
        result.findings = _parse_cppcheck_output(output, repo_root)
    except subprocess.TimeoutExpired:
        result.errors.append("cppcheck timed out after 300 seconds.")
    except OSError as exc:
        result.errors.append(f"Failed to run cppcheck: {exc}")

    return result


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def collect_cpp_files(repo_root: str, specific_files: list[str] | None = None) -> list[str]:
    """Collect C/C++ source files from the repo.

    If *specific_files* is provided, returns only those that have C/C++
    extensions. Otherwise walks the repo root.
    """
    if specific_files:
        return [
            f for f in specific_files
            if Path(f).suffix.lower() in CPP_EXTENSIONS
        ]

    root = Path(repo_root)
    cpp_files: list[str] = []
    for ext in CPP_EXTENSIONS:
        for p in root.rglob(f"*{ext}"):
            # Skip hidden dirs and common vendor dirs
            parts = p.relative_to(root).parts
            if any(part.startswith(".") for part in parts):
                continue
            if any(part in ("node_modules", "__pycache__", "build", "dist") for part in parts):
                continue
            cpp_files.append(str(p.relative_to(root)).replace("\\", "/"))

    return sorted(cpp_files)


def run_cpp_analysis(
    repo_root: str,
    tool: str = "clang-tidy",
    checks: str = "",
    files: list[str] | None = None,
) -> list[CppAnalyzerResult]:
    """Run C/C++ analysis with the specified tool(s).

    Args:
        repo_root: Repository root path.
        tool: "clang-tidy", "cppcheck", or "both".
        checks: clang-tidy checks string (only for clang-tidy).
        files: Specific files to analyze (None = auto-detect).

    Returns:
        List of CppAnalyzerResult (one per tool).
    """
    cpp_files = collect_cpp_files(repo_root, files)
    results: list[CppAnalyzerResult] = []

    if tool in ("clang-tidy", "both"):
        results.append(run_clang_tidy(cpp_files, checks=checks, repo_root=repo_root))

    if tool in ("cppcheck", "both"):
        results.append(run_cppcheck(cpp_files, repo_root=repo_root))

    return results
