"""Architecture rules enforcement — detects dependency violations between modules.

Provides import/include analysis for Python, C/C++, JavaScript/TypeScript, and Go.
Rules are defined in YAML (e.g. ``.sentrik/architecture.yaml``) specifying which
module groups must not depend on each other.
"""

from __future__ import annotations

import fnmatch
import logging
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from guard.core.models import Evidence, Finding, Severity

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class ArchRule:
    """A single architecture dependency rule."""

    name: str
    from_pattern: str  # glob, e.g. "src/ui/**"
    must_not_import: list[str]  # list of globs, e.g. ["src/drivers/**"]
    severity: str = "high"
    description: str = ""


@dataclass
class ArchViolation:
    """A single detected architecture violation."""

    rule_name: str
    source_file: str
    imported_module: str
    line: int
    severity: str = "high"


@dataclass
class ArchReport:
    """Summary report for an architecture check run."""

    violations: list[ArchViolation] = field(default_factory=list)
    files_analyzed: int = 0
    rules_checked: int = 0


# ---------------------------------------------------------------------------
# Language-specific import extraction
# ---------------------------------------------------------------------------

# File extension → language mapping
_LANG_MAP: dict[str, str] = {
    ".py": "python",
    ".pyw": "python",
    ".c": "c",
    ".h": "c",
    ".cpp": "cpp",
    ".cxx": "cpp",
    ".cc": "cpp",
    ".hpp": "cpp",
    ".hxx": "cpp",
    ".hh": "cpp",
    ".js": "javascript",
    ".jsx": "javascript",
    ".mjs": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".go": "go",
}

# Python: import X / from X import Y
_PY_IMPORT_RE = re.compile(
    r"^\s*import\s+([\w.]+)", re.MULTILINE,
)
_PY_FROM_RE = re.compile(
    r"^\s*from\s+([\w.]+)\s+import\b", re.MULTILINE,
)

# C/C++: #include "path" or #include <path>
_C_INCLUDE_RE = re.compile(
    r'^\s*#\s*include\s+[<"](.*?)[>"]', re.MULTILINE,
)

# JavaScript/TypeScript: import ... from 'path' / require('path')
_JS_IMPORT_RE = re.compile(
    r"""^\s*import\s+.*?\s+from\s+['"](.+?)['"]""", re.MULTILINE,
)
_JS_IMPORT_PLAIN_RE = re.compile(
    r"""^\s*import\s+['"](.+?)['"]""", re.MULTILINE,
)
_JS_REQUIRE_RE = re.compile(
    r"""\brequire\s*\(\s*['"](.+?)['"]\s*\)""", re.MULTILINE,
)

# Go: import "path" or import ( "path" )
_GO_IMPORT_RE = re.compile(
    r'^\s*import\s+"(.+?)"', re.MULTILINE,
)
_GO_IMPORT_GROUP_RE = re.compile(
    r'^\s*import\s*\((.*?)\)', re.MULTILINE | re.DOTALL,
)
_GO_IMPORT_LINE_RE = re.compile(
    r'^\s*(?:\w+\s+)?"(.+?)"', re.MULTILINE,
)


def extract_imports(file_path: str, content: str) -> list[tuple[str, int]]:
    """Extract imported module paths and their line numbers from source code.

    Returns a list of ``(module_path, line_number)`` tuples.
    The language is detected from the file extension.
    """
    ext = Path(file_path).suffix.lower()
    lang = _LANG_MAP.get(ext)

    if lang == "python":
        return _extract_python_imports(content)
    elif lang in ("c", "cpp"):
        return _extract_c_imports(content)
    elif lang in ("javascript", "typescript"):
        return _extract_js_imports(content)
    elif lang == "go":
        return _extract_go_imports(content)

    return []


def _line_number_of(content: str, pos: int) -> int:
    """Return 1-based line number for a character position."""
    return content[:pos].count("\n") + 1


def _extract_python_imports(content: str) -> list[tuple[str, int]]:
    imports: list[tuple[str, int]] = []
    for m in _PY_IMPORT_RE.finditer(content):
        module = m.group(1)
        imports.append((module.replace(".", "/"), _line_number_of(content, m.start())))
    for m in _PY_FROM_RE.finditer(content):
        module = m.group(1)
        imports.append((module.replace(".", "/"), _line_number_of(content, m.start())))
    return imports


def _extract_c_imports(content: str) -> list[tuple[str, int]]:
    imports: list[tuple[str, int]] = []
    for m in _C_INCLUDE_RE.finditer(content):
        imports.append((m.group(1), _line_number_of(content, m.start())))
    return imports


def _extract_js_imports(content: str) -> list[tuple[str, int]]:
    imports: list[tuple[str, int]] = []
    seen: set[tuple[str, int]] = set()

    for m in _JS_IMPORT_RE.finditer(content):
        entry = (m.group(1), _line_number_of(content, m.start()))
        if entry not in seen:
            imports.append(entry)
            seen.add(entry)

    for m in _JS_IMPORT_PLAIN_RE.finditer(content):
        entry = (m.group(1), _line_number_of(content, m.start()))
        if entry not in seen:
            imports.append(entry)
            seen.add(entry)

    for m in _JS_REQUIRE_RE.finditer(content):
        entry = (m.group(1), _line_number_of(content, m.start()))
        if entry not in seen:
            imports.append(entry)
            seen.add(entry)

    return imports


def _extract_go_imports(content: str) -> list[tuple[str, int]]:
    imports: list[tuple[str, int]] = []

    # Single imports: import "path"
    for m in _GO_IMPORT_RE.finditer(content):
        imports.append((m.group(1), _line_number_of(content, m.start())))

    # Grouped imports: import ( ... )
    for group_m in _GO_IMPORT_GROUP_RE.finditer(content):
        group_start = group_m.start(1)
        group_text = group_m.group(1)
        for line_m in _GO_IMPORT_LINE_RE.finditer(group_text):
            line_no = _line_number_of(content, group_start + line_m.start())
            imports.append((line_m.group(1), line_no))

    return imports


# ---------------------------------------------------------------------------
# Import resolution
# ---------------------------------------------------------------------------


def _resolve_import_path(
    imported: str,
    source_file: str,
    repo_root: str,
) -> str | None:
    """Try to resolve an import string to a repo-relative path.

    Returns the resolved path (forward-slash separated, relative to repo root)
    or None if no resolution could be made.
    """
    # Already looks like a relative path (starts with . or ..)
    if imported.startswith("."):
        source_dir = str(Path(source_file).parent)
        resolved = os.path.normpath(os.path.join(source_dir, imported))
        return resolved.replace("\\", "/")

    # Check if the import path (or a suffix of it) matches a file in the repo
    # For Python: "guard.core.models" → "guard/core/models" → could be "src/guard/core/models.py"
    # For C: "drivers/motor.h" → directly usable
    # For JS: "./utils/helper" → already relative
    normalized = imported.replace("\\", "/")

    # Try the import path as-is (useful for C includes, JS paths)
    root = Path(repo_root)
    candidates = [
        normalized,
        normalized + ".py",
        normalized + ".js",
        normalized + ".ts",
        normalized + ".tsx",
        normalized + ".jsx",
        normalized + "/index.js",
        normalized + "/index.ts",
        normalized + "/__init__.py",
    ]
    for candidate in candidates:
        if (root / candidate).exists():
            return candidate

    # For Python dotted imports, try with src/ prefix
    if "/" in normalized:
        for prefix in ("src/", "lib/", ""):
            prefixed = prefix + normalized
            for suffix in ("", ".py", "/__init__.py"):
                path = prefixed + suffix
                if (root / path).exists():
                    return path

    return normalized


def _matches_any_glob(path: str, patterns: list[str]) -> bool:
    """Check if a path matches any of the given glob patterns."""
    normalized = path.replace("\\", "/")
    for pattern in patterns:
        pattern = pattern.replace("\\", "/")
        if fnmatch.fnmatch(normalized, pattern):
            return True
        # Also try without trailing extension for module-level matches
        if "/" in normalized:
            # Check if the path starts with the pattern's directory prefix
            prefix = pattern.rstrip("*").rstrip("/")
            if prefix and normalized.startswith(prefix + "/"):
                return True
            if prefix and normalized == prefix:
                return True
    return False


# ---------------------------------------------------------------------------
# Architecture checking
# ---------------------------------------------------------------------------


def check_architecture(
    rules: list[ArchRule],
    repo_root: str,
    files: list[str] | None = None,
) -> ArchReport:
    """Check architecture rules against source files.

    Args:
        rules: Architecture rules to enforce.
        repo_root: Absolute path to repository root.
        files: Optional list of files to check (relative paths). If None,
            all source files under repo_root are discovered.

    Returns:
        An ArchReport with violations, file count, and rule count.
    """
    root = Path(repo_root)
    report = ArchReport(rules_checked=len(rules))

    if not rules:
        return report

    # Collect files if not provided
    if files is None:
        files = _discover_source_files(root)

    analyzed: set[str] = set()

    for rule in rules:
        for file_path in files:
            normalized = file_path.replace("\\", "/")
            if not fnmatch.fnmatch(normalized, rule.from_pattern):
                continue

            analyzed.add(normalized)
            abs_path = root / file_path
            try:
                content = abs_path.read_text(encoding="utf-8")
            except (UnicodeDecodeError, PermissionError, OSError):
                continue

            imports = extract_imports(file_path, content)
            for imported, line_no in imports:
                resolved = _resolve_import_path(imported, file_path, repo_root)
                check_path = resolved if resolved else imported
                if _matches_any_glob(check_path, rule.must_not_import):
                    report.violations.append(
                        ArchViolation(
                            rule_name=rule.name,
                            source_file=normalized,
                            imported_module=imported,
                            line=line_no,
                            severity=rule.severity,
                        )
                    )

    report.files_analyzed = len(analyzed)
    return report


def _discover_source_files(root: Path) -> list[str]:
    """Discover source files with supported extensions under root."""
    files: list[str] = []
    for dirpath, dirnames, filenames in os.walk(root):
        # Skip hidden directories and common non-source dirs
        dirnames[:] = [
            d for d in dirnames
            if not d.startswith(".") and d not in ("node_modules", "__pycache__", ".venv", "venv")
        ]
        for fname in filenames:
            ext = Path(fname).suffix.lower()
            if ext in _LANG_MAP:
                rel = os.path.relpath(os.path.join(dirpath, fname), root)
                files.append(rel.replace("\\", "/"))
    return files


# ---------------------------------------------------------------------------
# YAML loading
# ---------------------------------------------------------------------------


_TEMPLATE_YAML = """\
# Architecture rules — define module dependency constraints
# Docs: https://docs.sentrik.dev/guides/architecture-rules
#
# Each rule specifies:
#   - name: Human-readable rule name
#   - from: Glob pattern for source files to check
#   - must_not_import: List of glob patterns for forbidden dependencies
#   - severity: critical | high | medium | low | info (default: high)
#   - description: Why this constraint exists

architecture_rules:
  - name: "UI must not access hardware drivers"
    from: "src/ui/**"
    must_not_import:
      - "src/drivers/**"
      - "src/hardware/**"
    severity: high
    description: "UI layer should communicate with hardware through the service layer, not directly."

  - name: "Tests must not import production secrets"
    from: "tests/**"
    must_not_import:
      - "src/config/secrets/**"
    severity: critical
    description: "Test code must never reference production secret management modules."
"""


def load_arch_rules(config_path: str | Path | None = None) -> list[ArchRule]:
    """Load architecture rules from a YAML file.

    Searches for ``architecture.yaml`` in ``.sentrik/`` first, then repo root.
    Returns an empty list if no file is found.
    """
    if config_path is not None:
        path = Path(config_path)
        if not path.exists():
            return []
        return _parse_arch_yaml(path)

    # Default search order
    candidates = [
        Path(".sentrik/architecture.yaml"),
        Path("architecture.yaml"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return _parse_arch_yaml(candidate)

    return []


def _parse_arch_yaml(path: Path) -> list[ArchRule]:
    """Parse an architecture YAML file into ArchRule objects."""
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (yaml.YAMLError, OSError) as exc:
        logger.warning("Failed to parse architecture rules from %s: %s", path, exc)
        return []

    if not isinstance(data, dict):
        return []

    raw_rules = data.get("architecture_rules", [])
    if not isinstance(raw_rules, list):
        return []

    rules: list[ArchRule] = []
    for entry in raw_rules:
        if not isinstance(entry, dict):
            continue
        name = entry.get("name", "")
        from_pattern = entry.get("from", "")
        must_not = entry.get("must_not_import", [])
        if not name or not from_pattern or not must_not:
            logger.warning("Skipping incomplete architecture rule: %s", entry)
            continue
        rules.append(
            ArchRule(
                name=name,
                from_pattern=from_pattern,
                must_not_import=must_not if isinstance(must_not, list) else [must_not],
                severity=entry.get("severity", "high"),
                description=entry.get("description", ""),
            )
        )

    return rules


def generate_template(output_path: str | Path | None = None) -> Path:
    """Write a template architecture.yaml file.

    Returns the path to the generated file.
    """
    if output_path is None:
        sentrik_dir = Path(".sentrik")
        sentrik_dir.mkdir(exist_ok=True)
        output_path = sentrik_dir / "architecture.yaml"

    path = Path(output_path)
    path.write_text(_TEMPLATE_YAML, encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# Conversion to Finding objects
# ---------------------------------------------------------------------------


def _slugify(name: str) -> str:
    """Convert a rule name to a slug suitable for rule_id."""
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", name.lower()).strip("-")
    return slug[:60]  # Cap length


def violations_to_findings(violations: list[ArchViolation]) -> list[Finding]:
    """Convert architecture violations to Finding objects for pipeline integration."""
    findings: list[Finding] = []
    for v in violations:
        slug = _slugify(v.rule_name)
        rule_id = f"ARCH-{slug}"
        findings.append(
            Finding(
                finding_id=f"{rule_id}-{v.source_file}:{v.line}",
                rule_id=rule_id,
                severity=Severity(v.severity),
                message=f"Architecture violation: {v.rule_name} — {v.source_file} imports {v.imported_module}",
                evidence=Evidence(
                    file=v.source_file,
                    lines=[v.line],
                    snippet=f"import {v.imported_module}",
                ),
                suggestion=f"Remove or refactor the dependency on {v.imported_module} to comply with architecture rules.",
                confidence=1.0,
                deterministic=True,
                standard="Architecture",
            )
        )
    return findings
