"""Context-aware requirement drift analysis.

Goes beyond tag-matching to detect four types of drift:
1. Behavioral — requirement description/criteria vs actual code behavior
2. Structural — security-critical code patterns removed or weakened
3. Cross-file — requirement coverage when code moves between files
4. Acceptance criteria — per-criterion pass/fail validation

Uses LLM for semantic analysis when available, falls back to heuristic
checks when no LLM is configured.
"""

from __future__ import annotations

import json
import logging
import re
import uuid
from pathlib import Path
from typing import Any

from guard.core.models import Evidence, Finding, GeneratedRequirement, Severity
from guard.core.requirements_verifier import load_requirements
from guard.providers.llm_base import LLMProvider

logger = logging.getLogger(__name__)

_MAX_FILE_BYTES = 30_000
_MAX_TOTAL_BYTES = 100_000


# ---------------------------------------------------------------------------
# LLM Prompts
# ---------------------------------------------------------------------------

_BEHAVIORAL_DRIFT_PROMPT = """\
You are a compliance verification engineer. Analyze whether the source code \
still satisfies the requirement below. Focus on BEHAVIORAL differences — \
does the code do what the requirement says it should?

Return ONLY valid JSON:
{{
  "satisfies": true/false,
  "confidence": 0.0-1.0,
  "drifts": [
    {{
      "type": "behavioral",
      "description": "What changed or is missing",
      "severity": "critical|high|medium|low",
      "file": "path/to/file.py",
      "line_hint": 0,
      "suggestion": "How to fix"
    }}
  ]
}}

REQUIREMENT:
  ID: {req_id}
  Title: {title}
  Description: {description}

SOURCE CODE:
{source_code}
"""

_STRUCTURAL_DRIFT_PROMPT = """\
You are a security engineer. Check if any security-critical patterns have been \
removed or weakened in the source code relative to the requirement. Look for:
- Removed authentication/authorization checks
- Weakened encryption (algorithm downgrade, removed encryption)
- Removed input validation or sanitization
- Disabled security headers or CORS restrictions
- Removed error handling that could leak information

Return ONLY valid JSON:
{{
  "issues": [
    {{
      "type": "structural",
      "description": "What security pattern was removed or weakened",
      "severity": "critical|high|medium|low",
      "file": "path/to/file.py",
      "line_hint": 0,
      "suggestion": "How to restore the security control"
    }}
  ]
}}

If no structural issues found, return {{"issues": []}}.

REQUIREMENT:
  ID: {req_id}
  Title: {title}
  Security expectations: {description}

SOURCE CODE:
{source_code}
"""

_ACCEPTANCE_CRITERIA_PROMPT = """\
You are a test engineer. For each acceptance criterion below, determine \
whether the source code satisfies it. Be precise — only mark a criterion \
as failed if the code clearly does NOT implement it.

Return ONLY valid JSON:
{{
  "criteria_results": [
    {{
      "criterion": "The original criterion text",
      "satisfied": true/false,
      "confidence": 0.0-1.0,
      "evidence": "Brief explanation of why it passes or fails",
      "file": "path/to/file.py",
      "line_hint": 0
    }}
  ]
}}

REQUIREMENT: {req_id} — {title}
ACCEPTANCE CRITERIA:
{criteria}

SOURCE CODE:
{source_code}
"""


# ---------------------------------------------------------------------------
# Core analyzer
# ---------------------------------------------------------------------------


class DriftAnalyzer:
    """Context-aware requirement drift detection.

    Parameters
    ----------
    repo_root:
        Path to the repository root.
    llm:
        LLM provider for semantic analysis.  When ``None``, only
        heuristic/structural checks run.
    requirements:
        Pre-loaded requirements.  If not supplied, loaded from
        ``requirements_path``.
    requirements_path:
        Path to ``requirements.yaml``.
    """

    def __init__(
        self,
        repo_root: str,
        llm: LLMProvider | None = None,
        requirements: list[GeneratedRequirement] | None = None,
        requirements_path: Path | None = None,
    ) -> None:
        self._root = Path(repo_root)
        self._llm = llm

        if requirements is not None:
            self._requirements = requirements
        elif requirements_path and requirements_path.is_file():
            self._requirements = load_requirements(requirements_path)
        else:
            # Try default locations
            for candidate in [
                self._root / "requirements.yaml",
                self._root / ".sentrik" / "requirements.yaml",
            ]:
                if candidate.is_file():
                    self._requirements = load_requirements(candidate)
                    break
            else:
                self._requirements = []

    @property
    def has_requirements(self) -> bool:
        return len(self._requirements) > 0

    @property
    def has_llm(self) -> bool:
        return self._llm is not None

    def analyze(
        self,
        changed_files: list[str] | None = None,
    ) -> list[Finding]:
        """Run all drift detection passes and return findings.

        Parameters
        ----------
        changed_files:
            If provided, only analyze requirements that touch these files.
            When ``None``, analyze all requirements.
        """
        if not self._requirements:
            return []

        findings: list[Finding] = []
        reqs = self._filter_requirements(changed_files)

        for req in reqs:
            file_contents = self._read_source_files(req)

            # 1. Cross-file tracking (always runs, no LLM needed)
            findings.extend(self._check_cross_file(req, file_contents))

            if not file_contents:
                continue

            if self._llm:
                # 2. Behavioral drift (LLM)
                findings.extend(self._check_behavioral(req, file_contents))

                # 3. Structural drift (LLM)
                findings.extend(self._check_structural(req, file_contents))

                # 4. Acceptance criteria validation (LLM)
                if req.acceptance_criteria:
                    findings.extend(self._check_acceptance_criteria(req, file_contents))
            else:
                # Heuristic fallbacks when no LLM
                findings.extend(self._check_structural_heuristic(req, file_contents))

        return findings

    # ------------------------------------------------------------------
    # Requirement filtering
    # ------------------------------------------------------------------

    def _filter_requirements(
        self, changed_files: list[str] | None,
    ) -> list[GeneratedRequirement]:
        """Filter to active requirements, optionally scoped to changed files."""
        active = [r for r in self._requirements if r.status != "rejected" and r.source_files]
        if changed_files is None:
            return active
        changed_set = set(changed_files)
        return [r for r in active if any(f in changed_set for f in r.source_files)]

    def _read_source_files(self, req: GeneratedRequirement) -> dict[str, str]:
        """Read source files for a requirement, respecting size limits."""
        contents: dict[str, str] = {}
        total = 0
        for fp in req.source_files:
            full = self._root / fp
            if not full.is_file():
                continue
            try:
                text = full.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            size = len(text.encode("utf-8"))
            if size > _MAX_FILE_BYTES:
                text = text[:_MAX_FILE_BYTES] + "\n... (truncated)"
            if total + size > _MAX_TOTAL_BYTES:
                break
            contents[fp] = text
            total += size
        return contents

    def _format_source(self, file_contents: dict[str, str]) -> str:
        parts = []
        for path, content in file_contents.items():
            parts.append(f"--- {path} ---\n{content}")
        return "\n\n".join(parts)

    # ------------------------------------------------------------------
    # 1. Cross-file tracking
    # ------------------------------------------------------------------

    def _check_cross_file(
        self, req: GeneratedRequirement, file_contents: dict[str, str],
    ) -> list[Finding]:
        """Detect when requirement source files are missing or moved."""
        findings: list[Finding] = []

        for fp in req.source_files:
            full = self._root / fp
            if full.is_file():
                continue

            # File is missing — try to find where it moved
            name = Path(fp).name
            candidates = list(self._root.rglob(name))
            # Filter out obvious non-matches (test files, build artifacts)
            candidates = [
                c for c in candidates
                if "node_modules" not in str(c)
                and "__pycache__" not in str(c)
                and "dist/" not in str(c)
                and ".git/" not in str(c)
            ]

            if candidates:
                new_path = str(candidates[0].relative_to(self._root))
                suggestion = (
                    f"File appears to have moved to '{new_path}'. "
                    f"Update source_files in requirement {req.req_id}."
                )
                severity = "medium"
            else:
                suggestion = (
                    f"File '{fp}' no longer exists and no candidate replacement was found. "
                    f"The requirement may need to be updated or retired."
                )
                severity = "high"

            findings.append(Finding(
                finding_id=f"DRIFT-XFILE-{uuid.uuid4().hex[:8]}",
                rule_id=f"REQ-DRIFT-{req.req_id}",
                severity=severity,
                message=f"[{req.req_id}] Source file '{fp}' is missing — requirement '{req.title}' may be unimplemented",
                evidence=Evidence(file=fp, lines=[], snippet=""),
                suggestion=suggestion,
                confidence=1.0,
                deterministic=True,
                remediation_guidance=f"Update or retire requirement '{req.title}'",
                tags=["requirement-drift", "cross-file", "verification"],
            ))

        return findings

    # ------------------------------------------------------------------
    # 2. Behavioral drift (LLM)
    # ------------------------------------------------------------------

    def _check_behavioral(
        self, req: GeneratedRequirement, file_contents: dict[str, str],
    ) -> list[Finding]:
        """Use LLM to detect behavioral drift between requirement and code."""
        prompt = _BEHAVIORAL_DRIFT_PROMPT.format(
            req_id=req.req_id,
            title=req.title,
            description=req.description,
            source_code=self._format_source(file_contents),
        )
        try:
            response = self._llm.analyze(prompt, {
                "req_id": req.req_id,
                "files": list(file_contents.keys()),
            })
            return self._parse_drift_response(response, req, "behavioral")
        except Exception as exc:
            logger.warning("Behavioral drift check failed for %s: %s", req.req_id, exc)
            return []

    # ------------------------------------------------------------------
    # 3. Structural drift (LLM + heuristic)
    # ------------------------------------------------------------------

    def _check_structural(
        self, req: GeneratedRequirement, file_contents: dict[str, str],
    ) -> list[Finding]:
        """Use LLM to detect removed or weakened security patterns."""
        prompt = _STRUCTURAL_DRIFT_PROMPT.format(
            req_id=req.req_id,
            title=req.title,
            description=req.description,
            source_code=self._format_source(file_contents),
        )
        try:
            response = self._llm.analyze(prompt, {
                "req_id": req.req_id,
                "files": list(file_contents.keys()),
            })
            return self._parse_structural_response(response, req)
        except Exception as exc:
            logger.warning("Structural drift check failed for %s: %s", req.req_id, exc)
            return []

    # Heuristic patterns for structural drift without LLM
    _SECURITY_REMOVALS = [
        (re.compile(r"(?i)#.*TODO.*remove.*auth|#.*disable.*auth|#.*skip.*auth"), "authentication bypass comment"),
        (re.compile(r"(?i)verify\s*=\s*False|SSL_VERIFY\s*=\s*False"), "TLS verification disabled"),
        (re.compile(r"(?i)CORS\(.*origins\s*=\s*\[?\s*['\"]?\*"), "CORS allows all origins"),
        (re.compile(r"(?i)password\s*=\s*['\"][^'\"]{0,3}['\"]"), "hardcoded weak password"),
        (re.compile(r"(?i)algorithm\s*=\s*['\"]?(md5|sha1|des|rc4)"), "weak cryptographic algorithm"),
    ]

    def _check_structural_heuristic(
        self, req: GeneratedRequirement, file_contents: dict[str, str],
    ) -> list[Finding]:
        """Heuristic structural drift detection (no LLM)."""
        findings: list[Finding] = []
        for fp, content in file_contents.items():
            for pattern, desc in self._SECURITY_REMOVALS:
                for match in pattern.finditer(content):
                    line_no = content[:match.start()].count("\n") + 1
                    findings.append(Finding(
                        finding_id=f"DRIFT-STRUCT-{uuid.uuid4().hex[:8]}",
                        rule_id=f"REQ-DRIFT-{req.req_id}",
                        severity="high",
                        message=f"[{req.req_id}] Structural concern in '{fp}': {desc}",
                        evidence=Evidence(
                            file=fp,
                            lines=[line_no],
                            snippet=content[max(0, match.start()-40):match.end()+40].strip(),
                        ),
                        suggestion=f"Review whether this weakens requirement '{req.title}'",
                        confidence=0.6,
                        deterministic=False,
                        remediation_guidance=f"Potential security regression for requirement '{req.title}'",
                        tags=["requirement-drift", "structural", "verification"],
                    ))
        return findings

    # ------------------------------------------------------------------
    # 4. Acceptance criteria validation (LLM)
    # ------------------------------------------------------------------

    def _check_acceptance_criteria(
        self, req: GeneratedRequirement, file_contents: dict[str, str],
    ) -> list[Finding]:
        """Validate each acceptance criterion against the code."""
        criteria_text = "\n".join(f"  {i+1}. {ac}" for i, ac in enumerate(req.acceptance_criteria))
        prompt = _ACCEPTANCE_CRITERIA_PROMPT.format(
            req_id=req.req_id,
            title=req.title,
            criteria=criteria_text,
            source_code=self._format_source(file_contents),
        )
        try:
            response = self._llm.analyze(prompt, {
                "req_id": req.req_id,
                "files": list(file_contents.keys()),
            })
            return self._parse_criteria_response(response, req)
        except Exception as exc:
            logger.warning("Acceptance criteria check failed for %s: %s", req.req_id, exc)
            return []

    # ------------------------------------------------------------------
    # Response parsers
    # ------------------------------------------------------------------

    def _parse_drift_response(
        self, response: dict[str, Any], req: GeneratedRequirement, drift_type: str,
    ) -> list[Finding]:
        """Parse LLM behavioral/generic drift response."""
        data = self._extract_json(response)
        if data.get("satisfies", True) and not data.get("drifts"):
            return []

        findings: list[Finding] = []
        for drift in data.get("drifts", []):
            if not isinstance(drift, dict):
                continue
            sev = drift.get("severity", "medium")
            if sev not in ("critical", "high", "medium", "low", "info"):
                sev = "medium"
            file_path = drift.get("file", req.source_files[0] if req.source_files else "")
            line_hint = drift.get("line_hint", 0)
            findings.append(Finding(
                finding_id=f"DRIFT-{drift_type.upper()[:4]}-{uuid.uuid4().hex[:8]}",
                rule_id=f"REQ-DRIFT-{req.req_id}",
                severity=sev,
                message=f"[{req.req_id}] {drift.get('description', 'Behavioral drift detected')}",
                evidence=Evidence(
                    file=file_path,
                    lines=[line_hint] if line_hint else [],
                    snippet="",
                ),
                suggestion=drift.get("suggestion", ""),
                confidence=data.get("confidence", 0.7),
                deterministic=False,
                remediation_guidance=f"Requirement '{req.title}' may not be satisfied",
                tags=["requirement-drift", drift_type, "verification"],
            ))
        return findings

    def _parse_structural_response(
        self, response: dict[str, Any], req: GeneratedRequirement,
    ) -> list[Finding]:
        """Parse LLM structural drift response."""
        data = self._extract_json(response)
        findings: list[Finding] = []
        for issue in data.get("issues", []):
            if not isinstance(issue, dict):
                continue
            sev = issue.get("severity", "high")
            if sev not in ("critical", "high", "medium", "low", "info"):
                sev = "high"
            file_path = issue.get("file", req.source_files[0] if req.source_files else "")
            line_hint = issue.get("line_hint", 0)
            findings.append(Finding(
                finding_id=f"DRIFT-STRC-{uuid.uuid4().hex[:8]}",
                rule_id=f"REQ-DRIFT-{req.req_id}",
                severity=sev,
                message=f"[{req.req_id}] {issue.get('description', 'Structural concern')}",
                evidence=Evidence(
                    file=file_path,
                    lines=[line_hint] if line_hint else [],
                    snippet="",
                ),
                suggestion=issue.get("suggestion", ""),
                confidence=0.75,
                deterministic=False,
                remediation_guidance=f"Security control may be weakened for requirement '{req.title}'",
                tags=["requirement-drift", "structural", "verification"],
            ))
        return findings

    def _parse_criteria_response(
        self, response: dict[str, Any], req: GeneratedRequirement,
    ) -> list[Finding]:
        """Parse LLM acceptance criteria response."""
        data = self._extract_json(response)
        findings: list[Finding] = []
        for cr in data.get("criteria_results", []):
            if not isinstance(cr, dict):
                continue
            if cr.get("satisfied", True):
                continue
            file_path = cr.get("file", req.source_files[0] if req.source_files else "")
            line_hint = cr.get("line_hint", 0)
            criterion = cr.get("criterion", "")
            evidence_text = cr.get("evidence", "")
            findings.append(Finding(
                finding_id=f"DRIFT-AC-{uuid.uuid4().hex[:8]}",
                rule_id=f"REQ-DRIFT-{req.req_id}",
                severity="medium",
                message=f"[{req.req_id}] Acceptance criterion not met: {criterion}",
                evidence=Evidence(
                    file=file_path,
                    lines=[line_hint] if line_hint else [],
                    snippet=evidence_text,
                ),
                suggestion=f"Implement or update code to satisfy: {criterion}",
                confidence=cr.get("confidence", 0.7),
                deterministic=False,
                remediation_guidance=f"Acceptance criterion for '{req.title}' is not satisfied",
                tags=["requirement-drift", "acceptance-criteria", "verification"],
            ))
        return findings

    def _extract_json(self, response: dict[str, Any]) -> dict[str, Any]:
        """Extract JSON from LLM response, handling summary wrapping."""
        if "summary" in response and isinstance(response["summary"], str):
            try:
                return json.loads(response["summary"])
            except (json.JSONDecodeError, TypeError):
                pass
        return response
