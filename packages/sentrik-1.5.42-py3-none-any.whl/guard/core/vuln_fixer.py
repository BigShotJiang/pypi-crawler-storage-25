"""Auto-remediation for vulnerable dependencies.

Patches manifest files in-place with fixed versions from vulnerability scan results.
Supports requirements.txt, package.json, pyproject.toml, and Cargo.toml.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from guard.core.vuln_scanner import Vulnerability

logger = logging.getLogger(__name__)


@dataclass
class FixAction:
    """A single proposed version fix for a vulnerable package."""

    package: str
    current_version: str
    fixed_version: str
    manifest_file: str
    applied: bool = False
    error: str | None = None


@dataclass
class FixReport:
    """Summary of applied fixes."""

    actions: list[FixAction] = field(default_factory=list)

    @property
    def applied_count(self) -> int:
        return sum(1 for a in self.actions if a.applied)

    @property
    def skipped_count(self) -> int:
        return sum(1 for a in self.actions if not a.applied)


def _parse_version_tuple(version: str) -> tuple[int, ...]:
    """Parse a version string into a tuple of ints for comparison.

    Non-numeric segments are treated as 0.
    """
    parts: list[int] = []
    for segment in version.split("."):
        # Strip pre-release suffixes like "1.2.3a1"
        num = re.match(r"(\d+)", segment)
        parts.append(int(num.group(1)) if num else 0)
    return tuple(parts)


def generate_fix_actions(
    vulns: list[Vulnerability],
    manifest_paths: list[Path],
) -> list[FixAction]:
    """Generate fix actions for vulnerabilities that have a known fixed version.

    Deduplicates: if the same package appears in multiple vulns, the highest
    fixed_version is used.  Each action maps to the manifest file that actually
    contains the package.
    """
    if not vulns or not manifest_paths:
        return []

    # Build a map of package -> (current_version, highest_fixed_version)
    # keyed by package name (case-insensitive for safety)
    best_fix: dict[str, tuple[str, str]] = {}  # pkg_lower -> (current, fixed)
    for v in vulns:
        if not v.fixed_version:
            continue
        # Skip commit hashes and non-version strings — require at least one dot (e.g., "5.4", "42.0.0")
        if not re.match(r"^\d+\.\d+", v.fixed_version):
            continue
        key = v.affected_package.lower()
        if key in best_fix:
            existing_fixed = best_fix[key][1]
            if _parse_version_tuple(v.fixed_version) > _parse_version_tuple(existing_fixed):
                best_fix[key] = (v.affected_version, v.fixed_version)
        else:
            best_fix[key] = (v.affected_version, v.fixed_version)

    if not best_fix:
        return []

    # Build package -> manifest file mapping by reading manifests
    pkg_to_manifest: dict[str, tuple[str, Path]] = {}  # pkg_lower -> (original_name, path)
    for mp in manifest_paths:
        packages_in_manifest = _list_packages_in_manifest(mp)
        for pkg_name in packages_in_manifest:
            pkg_lower = pkg_name.lower()
            if pkg_lower in best_fix and pkg_lower not in pkg_to_manifest:
                pkg_to_manifest[pkg_lower] = (pkg_name, mp)

    actions: list[FixAction] = []
    for pkg_lower, (current, fixed) in sorted(best_fix.items()):
        if pkg_lower in pkg_to_manifest:
            original_name, manifest = pkg_to_manifest[pkg_lower]
            actions.append(FixAction(
                package=original_name,
                current_version=current,
                fixed_version=fixed,
                manifest_file=str(manifest),
            ))
        else:
            # Package not found in any manifest — skip silently
            pass

    return actions


def _list_packages_in_manifest(manifest_path: Path) -> list[str]:
    """Return the list of package names found in a manifest file."""
    try:
        text = manifest_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return []

    name = manifest_path.name
    packages: list[str] = []

    if name == "requirements.txt":
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("-") or line.startswith("http"):
                continue
            m = re.match(r"^([A-Za-z0-9_][A-Za-z0-9_.+-]*)", line)
            if m:
                packages.append(m.group(1))

    elif name == "package.json":
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return []
        for dep_key in ("dependencies", "devDependencies"):
            deps = data.get(dep_key, {})
            if isinstance(deps, dict):
                packages.extend(deps.keys())

    elif name == "pyproject.toml":
        in_project = False
        in_deps = False
        bracket_depth = 0
        for line in text.splitlines():
            stripped = line.strip()
            if re.match(r"^\[project\]\s*$", stripped):
                in_project = True
                in_deps = False
                continue
            if re.match(r"^\[", stripped) and not re.match(r"^\[project\]", stripped):
                if in_project:
                    in_project = False
                    in_deps = False
                continue
            if not in_project:
                continue
            if stripped.startswith("dependencies") and "=" in stripped:
                in_deps = True
                after_eq = stripped.split("=", 1)[1].strip()
                if "[" in after_eq:
                    bracket_depth += after_eq.count("[") - after_eq.count("]")
                    for m in re.finditer(r'["\']([^"\']+)["\']', after_eq):
                        spec = m.group(1).strip()
                        nm = re.match(r"^([A-Za-z0-9_][A-Za-z0-9_.+-]*)", spec)
                        if nm:
                            packages.append(nm.group(1))
                    if bracket_depth <= 0:
                        in_deps = False
                continue
            if in_deps:
                bracket_depth += stripped.count("[") - stripped.count("]")
                for m in re.finditer(r'["\']([^"\']+)["\']', stripped):
                    spec = m.group(1).strip()
                    nm = re.match(r"^([A-Za-z0-9_][A-Za-z0-9_.+-]*)", spec)
                    if nm:
                        packages.append(nm.group(1))
                if bracket_depth <= 0:
                    in_deps = False

    elif name == "Cargo.toml":
        in_deps = False
        for line in text.splitlines():
            stripped = line.strip()
            if re.match(r"^\[dependencies\]\s*$", stripped):
                in_deps = True
                continue
            if re.match(r"^\[", stripped) and stripped != "[dependencies]":
                in_deps = False
                continue
            if not in_deps:
                continue
            m = re.match(r"^([a-zA-Z0-9_-]+)\s*=", stripped)
            if m:
                packages.append(m.group(1))

    return packages


def apply_fixes(actions: list[FixAction]) -> FixReport:
    """Apply all fix actions by patching manifest files in-place.

    Returns a FixReport with per-action success/failure status.
    """
    for action in actions:
        manifest = Path(action.manifest_file)
        name = manifest.name

        try:
            if name == "requirements.txt":
                ok = _patch_requirements_txt(manifest, action.package, action.fixed_version)
            elif name == "package.json":
                ok = _patch_package_json(manifest, action.package, action.fixed_version)
            elif name == "pyproject.toml":
                ok = _patch_pyproject_toml(manifest, action.package, action.fixed_version)
            elif name == "Cargo.toml":
                ok = _patch_cargo_toml(manifest, action.package, action.fixed_version)
            else:
                action.error = f"Unsupported manifest type: {name}"
                continue

            if ok:
                action.applied = True
            else:
                action.error = f"Package '{action.package}' not found or unchanged in {name}"
        except FileNotFoundError:
            action.error = f"File not found: {action.manifest_file}"
        except Exception as exc:
            action.error = str(exc)

    return FixReport(actions=actions)


# ---------------------------------------------------------------------------
# Per-manifest patchers
# ---------------------------------------------------------------------------


def _patch_requirements_txt(file_path: Path, package: str, new_version: str) -> bool:
    """Patch a package version in requirements.txt.

    Handles pinned (==), minimum (>=), compatible (~=), and other operators.
    Packages listed without any version specifier are left unchanged.
    """
    text = file_path.read_text(encoding="utf-8")
    lines = text.splitlines(keepends=True)
    changed = False

    # Pattern: package_name (optional spaces) operator version (optional extras after comma)
    pattern = re.compile(
        r"^(" + re.escape(package) + r")\s*([=~!<>]=?)\s*(\S+)",
        re.IGNORECASE,
    )

    new_lines: list[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("#") or stripped.startswith("-") or not stripped:
            new_lines.append(line)
            continue

        m = pattern.match(stripped)
        if m:
            pkg_name = m.group(1)
            operator = m.group(2)
            # Rebuild the line preserving the operator
            # Preserve leading whitespace
            leading = line[: len(line) - len(line.lstrip())]
            # Preserve trailing content (comments, newline)
            rest_start = m.end()
            trailing = stripped[rest_start:]
            new_line = f"{leading}{pkg_name}{operator}{new_version}{trailing}"
            # Preserve original line ending
            if line.endswith("\n"):
                new_line = new_line.rstrip("\n") + "\n"
            new_lines.append(new_line)
            changed = True
        else:
            new_lines.append(line)

    if changed:
        file_path.write_text("".join(new_lines), encoding="utf-8")

    return changed


def _patch_package_json(file_path: Path, package: str, new_version: str) -> bool:
    """Patch a package version in package.json (dependencies or devDependencies)."""
    text = file_path.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return False

    changed = False
    for dep_key in ("dependencies", "devDependencies"):
        deps = data.get(dep_key)
        if not isinstance(deps, dict):
            continue
        if package in deps:
            old = deps[package]
            # Preserve prefix characters (^, ~, >=, etc.)
            prefix = re.match(r"^[\^~>=<!\s]*", str(old))
            prefix_str = prefix.group(0) if prefix else ""
            deps[package] = f"{prefix_str}{new_version}"
            changed = True

    if changed:
        file_path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")

    return changed


def _patch_pyproject_toml(file_path: Path, package: str, new_version: str) -> bool:
    """Patch a package version in pyproject.toml [project.dependencies].

    Uses line-level regex replacement to avoid needing a TOML library.
    """
    text = file_path.read_text(encoding="utf-8")
    # Match the package spec inside quotes: "package>=1.2.3" or "package==1.2.3"
    # The version operator and version number are captured for replacement.
    pattern = re.compile(
        r'(["\'])(' + re.escape(package) + r'(?:\[.*?\])?\s*[=~!<>]=?\s*)(\S+?)(["\'])',
        re.IGNORECASE,
    )

    new_text, count = pattern.subn(
        lambda m: f"{m.group(1)}{m.group(2)}{new_version}{m.group(4)}",
        text,
    )

    if count > 0:
        file_path.write_text(new_text, encoding="utf-8")
        return True

    return False


def _patch_cargo_toml(file_path: Path, package: str, new_version: str) -> bool:
    """Patch a package version in Cargo.toml [dependencies].

    Handles both `name = "version"` and `name = { version = "..." }` forms.
    """
    text = file_path.read_text(encoding="utf-8")
    lines = text.splitlines(keepends=True)
    in_deps = False
    changed = False

    new_lines: list[str] = []
    for line in lines:
        stripped = line.strip()

        if re.match(r"^\[dependencies\]\s*$", stripped):
            in_deps = True
            new_lines.append(line)
            continue
        if re.match(r"^\[", stripped) and stripped != "[dependencies]":
            in_deps = False
            new_lines.append(line)
            continue

        if in_deps:
            # Simple form: name = "version"
            m = re.match(
                r'^(' + re.escape(package) + r'\s*=\s*)"([^"]*)"(.*)$',
                stripped,
            )
            if m:
                leading = line[: len(line) - len(line.lstrip())]
                new_line = f'{leading}{m.group(1)}"{new_version}"{m.group(3)}'
                if line.endswith("\n"):
                    new_line = new_line.rstrip("\n") + "\n"
                new_lines.append(new_line)
                changed = True
                continue

            # Table form: name = { version = "...", ... }
            m2 = re.match(
                r'^(' + re.escape(package) + r'\s*=\s*\{.*?version\s*=\s*)"([^"]*)"(.*)$',
                stripped,
            )
            if m2:
                leading = line[: len(line) - len(line.lstrip())]
                new_line = f'{leading}{m2.group(1)}"{new_version}"{m2.group(3)}'
                if line.endswith("\n"):
                    new_line = new_line.rstrip("\n") + "\n"
                new_lines.append(new_line)
                changed = True
                continue

        new_lines.append(line)

    if changed:
        file_path.write_text("".join(new_lines), encoding="utf-8")

    return changed
