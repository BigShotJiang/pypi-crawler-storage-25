"""Quality Gradient Scoring — continuous 0-100 quality assessment.

Evaluates code quality across six dimensions:
1. Compliance (25%) — inverse of finding density from scan results
2. Complexity (20%) — cyclomatic complexity, nesting depth, function length
3. Test coverage (15%) — ratio of test files to source files
4. Documentation (10%) — docstring/comment coverage
5. Consistency (15%) — naming conventions, pattern uniformity
6. Dependency health (15%) — vulnerability count, outdated deps, license risk
"""

from __future__ import annotations

import json
import re
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_WEIGHTS = {
    "compliance": 25,
    "complexity": 20,
    "test_coverage": 15,
    "documentation": 10,
    "consistency": 15,
    "dependency_health": 15,
}

DEFAULT_THRESHOLDS = {
    "complexity_max_cyclomatic": 15,
    "complexity_max_nesting": 4,
    "function_max_lines": 50,
}


@dataclass
class DimensionScore:
    name: str
    score: int  # 0-100
    details: str = ""
    issues: list[str] = field(default_factory=list)


@dataclass
class QualityScore:
    overall: int  # 0-100
    dimensions: list[DimensionScore] = field(default_factory=list)
    trend: int | None = None  # delta from last scan

    def to_dict(self) -> dict[str, Any]:
        return {
            "overall": self.overall,
            "trend": self.trend,
            "dimensions": [
                {
                    "name": d.name,
                    "score": d.score,
                    "details": d.details,
                    "issues": d.issues,
                }
                for d in self.dimensions
            ],
        }


def score_compliance(
    findings_path: Path,
    total_files: int = 100,
) -> DimensionScore:
    """Score based on finding density (fewer findings = higher score)."""
    if not findings_path.is_file():
        return DimensionScore("compliance", 100, "No scan data")

    findings = json.loads(findings_path.read_text(encoding="utf-8"))
    # Exclude obligations
    code_findings = [f for f in findings if not f.get("is_obligation")]
    total = len(code_findings)

    if total == 0:
        return DimensionScore("compliance", 100, "No code findings")

    # Score: 100 for 0 findings, drops with density
    critical = sum(1 for f in code_findings if f.get("severity") == "critical")
    high = sum(1 for f in code_findings if f.get("severity") == "high")
    medium = sum(1 for f in code_findings if f.get("severity") == "medium")
    low = sum(1 for f in code_findings if f.get("severity") == "low")

    # Weighted penalty: critical=10, high=5, medium=2, low=0.5
    penalty = critical * 10 + high * 5 + medium * 2 + low * 0.5
    score = max(0, min(100, int(100 - penalty)))

    issues = []
    if critical > 0:
        issues.append(f"{critical} critical finding(s)")
    if high > 0:
        issues.append(f"{high} high finding(s)")
    if medium > 0:
        issues.append(f"{medium} medium finding(s)")

    return DimensionScore("compliance", score, f"{total} code findings", issues)


def score_complexity(repo_root: Path) -> DimensionScore:
    """Score based on code complexity metrics."""
    issues = []
    total_functions = 0
    long_functions = 0
    deep_functions = 0

    src_files = list(repo_root.rglob("*.py"))
    src_files = [f for f in src_files if "node_modules" not in str(f)
                 and "__pycache__" not in str(f) and ".venv" not in str(f)
                 and "out/" not in str(f)]

    for file_path in src_files[:200]:
        try:
            content = file_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        lines = content.split("\n")
        in_function = False
        func_lines = 0
        max_indent = 0
        func_base_indent = 0

        for line in lines:
            stripped = line.strip()
            if stripped.startswith("def ") or stripped.startswith("async def "):
                if in_function and func_lines > 0:
                    total_functions += 1
                    if func_lines > DEFAULT_THRESHOLDS["function_max_lines"]:
                        long_functions += 1
                    relative_depth = (max_indent - func_base_indent) // 4
                    if relative_depth > DEFAULT_THRESHOLDS["complexity_max_nesting"]:
                        deep_functions += 1
                in_function = True
                func_lines = 0
                func_base_indent = len(line) - len(line.lstrip())
                max_indent = func_base_indent
            elif in_function:
                if stripped:
                    func_lines += 1
                    indent = len(line) - len(line.lstrip())
                    if indent > max_indent:
                        max_indent = indent

        if in_function and func_lines > 0:
            total_functions += 1
            if func_lines > DEFAULT_THRESHOLDS["function_max_lines"]:
                long_functions += 1
            relative_depth = (max_indent - func_base_indent) // 4
            if relative_depth > DEFAULT_THRESHOLDS["complexity_max_nesting"]:
                deep_functions += 1

    if total_functions == 0:
        return DimensionScore("complexity", 85, "No functions analyzed")

    long_pct = (long_functions / total_functions) * 100
    deep_pct = (deep_functions / total_functions) * 100
    score = max(0, min(100, int(100 - long_pct * 2 - deep_pct * 1.5)))

    if long_functions > 0:
        issues.append(f"{long_functions} function(s) over {DEFAULT_THRESHOLDS['function_max_lines']} lines")
    if deep_functions > 0:
        issues.append(f"{deep_functions} function(s) with deep nesting (>{DEFAULT_THRESHOLDS['complexity_max_nesting']} levels)")

    return DimensionScore("complexity", score,
                          f"{total_functions} functions analyzed", issues)


def score_test_coverage(repo_root: Path) -> DimensionScore:
    """Score based on test file ratio."""
    src_files = []
    test_files = []

    for f in repo_root.rglob("*.py"):
        s = str(f)
        if any(skip in s for skip in ("node_modules", "__pycache__", ".venv", "out/")):
            continue
        name = f.name
        if name.startswith("test_") or name.endswith("_test.py") or "/tests/" in s or "\\tests\\" in s:
            test_files.append(f)
        elif not name.startswith("__"):
            src_files.append(f)

    if not src_files:
        return DimensionScore("test_coverage", 50, "No source files found")

    ratio = len(test_files) / len(src_files)
    score = min(100, int(ratio * 200))  # 0.5 ratio = 100

    issues = []
    untested = len(src_files) - len(test_files)
    if untested > 0 and ratio < 0.5:
        issues.append(f"{untested} source file(s) without corresponding tests")

    return DimensionScore("test_coverage", score,
                          f"{len(test_files)} test files / {len(src_files)} source files",
                          issues)


def score_documentation(repo_root: Path) -> DimensionScore:
    """Score based on docstring and comment coverage."""
    total_functions = 0
    documented_functions = 0
    has_readme = (repo_root / "README.md").is_file()

    for f in repo_root.rglob("*.py"):
        s = str(f)
        if any(skip in s for skip in ("node_modules", "__pycache__", ".venv", "out/", "test")):
            continue
        try:
            content = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        lines = content.split("\n")
        for i, line in enumerate(lines):
            stripped = line.strip()
            if stripped.startswith("def ") or stripped.startswith("async def "):
                total_functions += 1
                # Check if next non-empty line is a docstring
                for j in range(i + 1, min(i + 3, len(lines))):
                    next_line = lines[j].strip()
                    if next_line.startswith('"""') or next_line.startswith("'''"):
                        documented_functions += 1
                        break
                    elif next_line and not next_line.startswith("#"):
                        break

    if total_functions == 0:
        score = 70 if has_readme else 50
        return DimensionScore("documentation", score, "No functions to analyze")

    doc_ratio = documented_functions / total_functions
    score = int(doc_ratio * 80) + (20 if has_readme else 0)
    score = min(100, score)

    issues = []
    undocumented = total_functions - documented_functions
    if undocumented > 0:
        issues.append(f"{undocumented} public function(s) without docstrings")
    if not has_readme:
        issues.append("No README.md found")

    return DimensionScore("documentation", score,
                          f"{documented_functions}/{total_functions} functions documented",
                          issues)


def score_consistency(repo_root: Path) -> DimensionScore:
    """Score based on naming convention and pattern consistency."""
    issues = []
    total_names = 0
    snake_case = 0
    camel_case = 0
    mixed = 0

    _SNAKE = re.compile(r"^[a-z_][a-z0-9_]*$")
    _CAMEL = re.compile(r"^[a-z][a-zA-Z0-9]*$")

    for f in repo_root.rglob("*.py"):
        s = str(f)
        if any(skip in s for skip in ("node_modules", "__pycache__", ".venv", "out/")):
            continue
        try:
            content = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        for line in content.split("\n"):
            stripped = line.strip()
            # Check function names
            if stripped.startswith("def ") or stripped.startswith("async def "):
                name = stripped.split("(")[0].replace("def ", "").replace("async ", "").strip()
                if name.startswith("_"):
                    name = name.lstrip("_")
                if not name:
                    continue
                total_names += 1
                if _SNAKE.match(name):
                    snake_case += 1
                elif _CAMEL.match(name):
                    camel_case += 1
                else:
                    mixed += 1

    if total_names == 0:
        return DimensionScore("consistency", 80, "No names analyzed")

    # In Python, snake_case is the convention
    dominant = max(snake_case, camel_case)
    consistency_ratio = dominant / total_names
    score = int(consistency_ratio * 100)

    if mixed > 0:
        issues.append(f"{mixed} inconsistent naming pattern(s)")
    if camel_case > 0 and snake_case > 0:
        issues.append(f"Mixed conventions: {snake_case} snake_case, {camel_case} camelCase")

    return DimensionScore("consistency", score,
                          f"{total_names} names analyzed, {int(consistency_ratio*100)}% consistent",
                          issues)


def score_dependency_health(
    vulns_path: Path,
    licenses_path: Path | None = None,
) -> DimensionScore:
    """Score based on vulnerability count and license risk."""
    issues = []
    vuln_penalty = 0

    if vulns_path.is_file():
        try:
            data = json.loads(vulns_path.read_text(encoding="utf-8"))
            vulns = data if isinstance(data, list) else data.get("vulnerabilities", [])
            critical = sum(1 for v in vulns if v.get("severity") in ("critical", "CRITICAL"))
            high = sum(1 for v in vulns if v.get("severity") in ("high", "HIGH"))
            medium = sum(1 for v in vulns if v.get("severity") in ("medium", "MEDIUM"))
            vuln_penalty = critical * 15 + high * 8 + medium * 3
            if critical:
                issues.append(f"{critical} critical CVE(s)")
            if high:
                issues.append(f"{high} high CVE(s)")
            if medium:
                issues.append(f"{medium} medium CVE(s)")
        except (json.JSONDecodeError, OSError):
            pass

    license_penalty = 0
    if licenses_path and licenses_path.is_file():
        try:
            data = json.loads(licenses_path.read_text(encoding="utf-8"))
            licenses = data if isinstance(data, list) else data.get("licenses", [])
            copyleft = sum(1 for lic in licenses if lic.get("risk") in ("high", "copyleft"))
            if copyleft:
                license_penalty = copyleft * 5
                issues.append(f"{copyleft} copyleft/high-risk license(s)")
        except (json.JSONDecodeError, OSError):
            pass

    score = max(0, min(100, 100 - vuln_penalty - license_penalty))
    if not vulns_path.is_file():
        return DimensionScore("dependency_health", 70,
                              "No vulnerability data — run sentrik vulns")

    return DimensionScore("dependency_health", score,
                          f"Penalty: {vuln_penalty + license_penalty} points", issues)


def calculate_quality_score(
    repo_root: str,
    output_dir: str = "out",
    weights: dict[str, int] | None = None,
) -> QualityScore:
    """Calculate overall quality score across all dimensions."""
    root = Path(repo_root)
    out = Path(output_dir)
    w = weights or DEFAULT_WEIGHTS

    dimensions = [
        score_compliance(out / "findings.json"),
        score_complexity(root),
        score_test_coverage(root),
        score_documentation(root),
        score_consistency(root),
        score_dependency_health(
            out / "vulnerabilities.json",
            out / "licenses.json",
        ),
    ]

    # Weighted average
    total_weight = sum(w.get(d.name, 0) for d in dimensions)
    if total_weight == 0:
        overall = 0
    else:
        overall = int(sum(d.score * w.get(d.name, 0) for d in dimensions) / total_weight)

    # Check trend from scan history
    trend = None
    history_path = out / "quality_history.json"
    if history_path.is_file():
        try:
            history = json.loads(history_path.read_text(encoding="utf-8"))
            if history:
                last = history[-1].get("overall", overall)
                trend = overall - last
        except (json.JSONDecodeError, OSError):
            pass

    result = QualityScore(overall=overall, dimensions=dimensions, trend=trend)

    # Save to history
    try:
        history = []
        if history_path.is_file():
            history = json.loads(history_path.read_text(encoding="utf-8"))
        from datetime import datetime, timezone
        history.append({
            "overall": overall,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "dimensions": {d.name: d.score for d in dimensions},
        })
        # Keep last 100 entries
        history = history[-100:]
        history_path.parent.mkdir(parents=True, exist_ok=True)
        history_path.write_text(json.dumps(history, indent=2), encoding="utf-8")
    except (OSError, json.JSONDecodeError):
        pass

    return result


def format_quality_report(score: QualityScore) -> str:
    """Format quality score as a human-readable report."""
    lines = [f"\nSentrik Quality Score: {score.overall}/100\n"]

    for d in score.dimensions:
        bar_len = d.score // 5
        bar = "#" * bar_len + " " * (20 - bar_len)
        lines.append(f"  {d.name:20s} {d.score:3d}/100  {bar}  ({d.details})")
        for issue in d.issues:
            lines.append(f"    - {issue}")

    if score.trend is not None:
        if score.trend > 0:
            lines.append(f"\n  Trend: +{score.trend} from last scan (improving)")
        elif score.trend < 0:
            lines.append(f"\n  Trend: {score.trend} from last scan (degrading)")
        else:
            lines.append(f"\n  Trend: stable")

    lines.append("")
    return "\n".join(lines)
