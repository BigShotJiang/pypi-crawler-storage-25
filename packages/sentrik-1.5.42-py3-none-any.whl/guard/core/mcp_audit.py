"""MCP security auditing — scans MCP server configurations for security risks.

Checks for overly permissive tool definitions, dangerous file system operations,
credential exposure, and missing access controls in MCP server configurations.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Known dangerous tool patterns that MCP servers should restrict
_DANGEROUS_TOOL_PATTERNS = {
    "file_write": {
        "keywords": ["write_file", "write", "create_file", "overwrite", "save_file", "edit_file"],
        "severity": "high",
        "message": "Tool can write/modify files — ensure path restrictions are enforced",
    },
    "file_delete": {
        "keywords": ["delete_file", "remove_file", "rm", "unlink"],
        "severity": "critical",
        "message": "Tool can delete files — ensure deletion is scoped to safe directories",
    },
    "shell_exec": {
        "keywords": ["exec", "execute", "run_command", "shell", "bash", "subprocess", "system"],
        "severity": "critical",
        "message": "Tool can execute shell commands — high risk of command injection",
    },
    "network": {
        "keywords": ["fetch", "http_request", "curl", "download", "upload", "send_request"],
        "severity": "medium",
        "message": "Tool makes network requests — verify URL allowlisting and SSRF protection",
    },
    "credential": {
        "keywords": ["api_key", "password", "secret", "token", "credential", "auth"],
        "severity": "high",
        "message": "Tool handles credentials — ensure secrets are not logged or exposed in responses",
    },
    "database": {
        "keywords": ["query", "sql", "execute_sql", "db_query", "raw_query"],
        "severity": "high",
        "message": "Tool executes database queries — ensure parameterized queries and access controls",
    },
}


@dataclass
class MCPAuditFinding:
    """A security finding from MCP configuration audit."""

    severity: str  # critical, high, medium, low, info
    category: str
    message: str
    source: str  # file path or config key
    tool_name: str = ""
    recommendation: str = ""


@dataclass
class MCPAuditResult:
    """Results of an MCP security audit."""

    findings: list[MCPAuditFinding] = field(default_factory=list)
    servers_scanned: int = 0
    tools_scanned: int = 0

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "critical")

    @property
    def high_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "high")

    @property
    def passed(self) -> bool:
        return self.critical_count == 0 and self.high_count == 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "passed": self.passed,
            "servers_scanned": self.servers_scanned,
            "tools_scanned": self.tools_scanned,
            "findings_count": len(self.findings),
            "by_severity": {
                "critical": self.critical_count,
                "high": self.high_count,
                "medium": sum(1 for f in self.findings if f.severity == "medium"),
                "low": sum(1 for f in self.findings if f.severity == "low"),
                "info": sum(1 for f in self.findings if f.severity == "info"),
            },
            "findings": [
                {
                    "severity": f.severity,
                    "category": f.category,
                    "message": f.message,
                    "source": f.source,
                    "tool_name": f.tool_name,
                    "recommendation": f.recommendation,
                }
                for f in self.findings
            ],
        }


def audit_mcp_config(config_paths: list[Path] | None = None) -> MCPAuditResult:
    """Audit MCP server configurations for security risks.

    Scans common MCP config locations:
    - .mcp.json (project root)
    - .claude/mcp_servers.json
    - .cursor/mcp.json
    - .vscode/mcp.json
    """
    result = MCPAuditResult()

    if config_paths is None:
        config_paths = _discover_mcp_configs()

    for path in config_paths:
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            result.servers_scanned += 1
            _audit_config(data, str(path), result)
        except (json.JSONDecodeError, OSError) as exc:
            result.findings.append(MCPAuditFinding(
                severity="low",
                category="config_error",
                message=f"Failed to parse MCP config: {exc}",
                source=str(path),
            ))

    return result


def _discover_mcp_configs() -> list[Path]:
    """Find MCP configuration files in standard locations."""
    base = Path(".")
    candidates = [
        base / ".mcp.json",
        base / ".claude" / "mcp_servers.json",
        base / ".cursor" / "mcp.json",
        base / ".vscode" / "mcp.json",
        Path.home() / ".claude" / "mcp_servers.json",
    ]
    return [p for p in candidates if p.exists()]


def _audit_config(data: dict[str, Any], source: str, result: MCPAuditResult) -> None:
    """Audit a parsed MCP configuration dict."""
    servers = data.get("mcpServers", data.get("servers", {}))
    if not isinstance(servers, dict):
        return

    for server_name, server_config in servers.items():
        if not isinstance(server_config, dict):
            continue

        # Check command-based servers
        command = server_config.get("command", "")
        args = server_config.get("args", [])

        # Check for dangerous commands
        if command in ("bash", "sh", "cmd", "powershell", "pwsh"):
            result.findings.append(MCPAuditFinding(
                severity="critical",
                category="shell_exec",
                message=f"Server '{server_name}' uses raw shell as command — any tool call can execute arbitrary commands",
                source=source,
                tool_name=server_name,
                recommendation="Use a dedicated MCP server binary instead of a raw shell",
            ))

        # Check for env vars that might contain secrets
        env = server_config.get("env", {})
        if isinstance(env, dict):
            for key, value in env.items():
                if isinstance(value, str) and len(value) > 8 and not value.startswith("$"):
                    key_lower = key.lower()
                    if any(s in key_lower for s in ("key", "secret", "password", "token", "pat")):
                        result.findings.append(MCPAuditFinding(
                            severity="high",
                            category="credential_exposure",
                            message=f"Server '{server_name}' has hardcoded credential in env var '{key}'",
                            source=source,
                            tool_name=server_name,
                            recommendation=f"Use environment variable reference instead of hardcoding: set {key} in your shell environment",
                        ))

        # Check for unrestricted file system access in args
        args_str = " ".join(str(a) for a in args) if isinstance(args, list) else str(args)
        if "/" == args_str.strip() or "C:\\" == args_str.strip():
            result.findings.append(MCPAuditFinding(
                severity="high",
                category="excessive_scope",
                message=f"Server '{server_name}' has root filesystem as scope — restrict to project directory",
                source=source,
                tool_name=server_name,
                recommendation="Scope file access to the project directory instead of the filesystem root",
            ))

        # Audit tool definitions if present
        tools = server_config.get("tools", [])
        if isinstance(tools, list):
            for tool in tools:
                if isinstance(tool, dict):
                    result.tools_scanned += 1
                    _audit_tool(tool, server_name, source, result)


def _audit_tool(tool: dict[str, Any], server_name: str, source: str, result: MCPAuditResult) -> None:
    """Audit a single MCP tool definition for security risks."""
    tool_name = tool.get("name", "unknown")
    description = (tool.get("description", "") or "").lower()

    for category, check in _DANGEROUS_TOOL_PATTERNS.items():
        for keyword in check["keywords"]:
            if keyword in tool_name.lower() or keyword in description:
                # Check if input schema has any restrictions
                schema = tool.get("inputSchema", tool.get("input_schema", {}))
                has_restrictions = bool(
                    schema.get("enum")
                    or schema.get("pattern")
                    or any(
                        prop.get("enum") or prop.get("pattern") or prop.get("maxLength")
                        for prop in schema.get("properties", {}).values()
                        if isinstance(prop, dict)
                    )
                )

                if not has_restrictions:
                    result.findings.append(MCPAuditFinding(
                        severity=check["severity"],
                        category=category,
                        message=f"{check['message']} (tool: {tool_name}, server: {server_name})",
                        source=source,
                        tool_name=tool_name,
                        recommendation=f"Add input validation constraints (enum, pattern, maxLength) to the tool's input schema",
                    ))
                break  # Only report once per category per tool
