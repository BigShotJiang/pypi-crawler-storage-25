"""Multi-repo organization dashboard — aggregation logic.

Discovers projects under an organization root directory, collects
compliance data from each, and produces aggregated org-level reports.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from html import escape
from pathlib import Path

from guard import __version__


@dataclass
class OrgProject:
    """Summary data for a single project within the organization."""

    name: str
    path: str
    last_scan: datetime | None = None
    compliance_score: float = 0.0
    findings_by_severity: dict[str, int] = field(default_factory=dict)
    total_findings: int = 0
    frameworks: list[str] = field(default_factory=list)
    gate_status: str = "unknown"  # "passed" | "failed" | "unknown"


def discover_projects(root_dir: str | Path) -> list[Path]:
    """Walk subdirectories looking for ``.sentrik/config.yaml`` or ``.guard.yaml``.

    Each match is treated as a project root.  Hidden directories (starting
    with ``.``) are skipped during traversal to avoid scanning ``.git``,
    ``.venv``, etc.

    Returns:
        Sorted list of project root paths.
    """
    root = Path(root_dir).resolve()
    projects: list[Path] = []

    if not root.is_dir():
        return projects

    for dirpath, dirnames, _filenames in os.walk(root):
        # Skip hidden directories
        dirnames[:] = [d for d in dirnames if not d.startswith(".")]

        dp = Path(dirpath)
        sentrik_config = dp / ".sentrik" / "config.yaml"
        guard_config = dp / ".guard.yaml"

        if sentrik_config.is_file() or guard_config.is_file():
            projects.append(dp)
            # Don't recurse into sub-projects
            dirnames.clear()

    return sorted(projects)


def collect_project_data(project_path: str | Path) -> OrgProject:
    """Read ``out/findings.json`` and ``out/scan_metrics.json`` from a project.

    Returns an ``OrgProject`` populated with whatever data is available.
    Missing output files result in zero-valued defaults.
    """
    pp = Path(project_path).resolve()
    name = pp.name

    proj = OrgProject(name=name, path=str(pp))

    findings_path = pp / "out" / "findings.json"
    metrics_path = pp / "out" / "scan_metrics.json"

    # Load findings
    findings_data: list[dict] = []
    if findings_path.is_file():
        try:
            raw = json.loads(findings_path.read_text(encoding="utf-8"))
            if isinstance(raw, list):
                findings_data = raw
        except (json.JSONDecodeError, OSError):
            pass

    # Count findings by severity
    sev_counts: dict[str, int] = {}
    for f in findings_data:
        sev = f.get("severity", "info")
        if isinstance(sev, str):
            sev_counts[sev] = sev_counts.get(sev, 0) + 1

    proj.findings_by_severity = sev_counts
    proj.total_findings = sum(sev_counts.values())

    # Determine gate status from findings
    if findings_data or findings_path.is_file():
        blocking = sev_counts.get("critical", 0) + sev_counts.get("high", 0)
        proj.gate_status = "failed" if blocking > 0 else "passed"

    # Load metrics
    if metrics_path.is_file():
        try:
            metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
            ts = metrics.get("timestamp")
            if ts:
                try:
                    proj.last_scan = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                except (ValueError, AttributeError):
                    pass

            cs = metrics.get("compliance_score", {})
            if isinstance(cs, dict) and "score" in cs:
                proj.compliance_score = float(cs["score"])
            elif isinstance(cs, (int, float)):
                proj.compliance_score = float(cs)
        except (json.JSONDecodeError, OSError):
            pass

    # Extract frameworks from config
    proj.frameworks = _read_frameworks(pp)

    return proj


def _read_frameworks(project_path: Path) -> list[str]:
    """Read standards_packs from the project config file."""
    import yaml  # type: ignore[import-untyped]

    for config_file in (
        project_path / ".sentrik" / "config.yaml",
        project_path / ".guard.yaml",
    ):
        if config_file.is_file():
            try:
                data = yaml.safe_load(config_file.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    packs = data.get("standards_packs", [])
                    if isinstance(packs, list):
                        return [str(p) for p in packs]
            except Exception:
                pass
    return []


def aggregate_org_data(projects: list[OrgProject]) -> dict:
    """Compute org-level statistics from a list of project summaries.

    Returns a dict with:
        total_projects, total_findings, avg_compliance_score,
        projects_passing, projects_failing,
        findings_by_severity, worst_projects, frameworks_coverage
    """
    total_projects = len(projects)
    total_findings = sum(p.total_findings for p in projects)

    scores = [p.compliance_score for p in projects]
    avg_compliance_score = round(sum(scores) / len(scores), 1) if scores else 0.0

    projects_passing = sum(1 for p in projects if p.gate_status == "passed")
    projects_failing = sum(1 for p in projects if p.gate_status == "failed")

    # Sum severity counts across all projects
    findings_by_severity: dict[str, int] = {}
    for p in projects:
        for sev, count in p.findings_by_severity.items():
            findings_by_severity[sev] = findings_by_severity.get(sev, 0) + count

    # Worst projects by total findings (desc), top 5
    worst_projects = sorted(projects, key=lambda p: p.total_findings, reverse=True)[:5]

    # Framework coverage: which frameworks are enabled across how many projects
    fw_coverage: dict[str, int] = {}
    for p in projects:
        for fw in p.frameworks:
            fw_coverage[fw] = fw_coverage.get(fw, 0) + 1

    return {
        "total_projects": total_projects,
        "total_findings": total_findings,
        "avg_compliance_score": avg_compliance_score,
        "projects_passing": projects_passing,
        "projects_failing": projects_failing,
        "findings_by_severity": findings_by_severity,
        "worst_projects": worst_projects,
        "frameworks_coverage": fw_coverage,
    }


# ---------------------------------------------------------------------------
# JSON serialization
# ---------------------------------------------------------------------------

def org_data_to_json(projects: list[OrgProject], agg: dict) -> dict:
    """Return a JSON-serializable dict of the org dashboard data."""
    return {
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "sentrik_version": __version__,
        "summary": {
            "total_projects": agg["total_projects"],
            "total_findings": agg["total_findings"],
            "avg_compliance_score": agg["avg_compliance_score"],
            "projects_passing": agg["projects_passing"],
            "projects_failing": agg["projects_failing"],
            "findings_by_severity": agg["findings_by_severity"],
            "frameworks_coverage": agg["frameworks_coverage"],
        },
        "projects": [
            {
                "name": p.name,
                "path": p.path,
                "last_scan": p.last_scan.isoformat() if p.last_scan else None,
                "compliance_score": p.compliance_score,
                "findings_by_severity": p.findings_by_severity,
                "total_findings": p.total_findings,
                "frameworks": p.frameworks,
                "gate_status": p.gate_status,
            }
            for p in projects
        ],
    }


# ---------------------------------------------------------------------------
# HTML report generator
# ---------------------------------------------------------------------------

_SEVERITY_COLORS: dict[str, str] = {
    "critical": "#d32f2f",
    "high": "#f57c00",
    "medium": "#fbc02d",
    "low": "#1976d2",
    "info": "#757575",
}

_GATE_COLORS: dict[str, str] = {
    "passed": "#4caf50",
    "failed": "#d32f2f",
    "unknown": "#757575",
}


def generate_org_html_report(projects: list[OrgProject], agg: dict) -> str:
    """Generate a standalone HTML org dashboard report.

    Returns a complete HTML string with inline CSS, dark/light theme support,
    sortable project table, severity distribution bar, and expandable rows.
    """
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    # Severity distribution bar segments
    total_f = agg["total_findings"] or 1
    sev_bar_segments = ""
    for sev in ("critical", "high", "medium", "low", "info"):
        count = agg["findings_by_severity"].get(sev, 0)
        if count > 0:
            pct = round((count / total_f) * 100, 1)
            color = _SEVERITY_COLORS.get(sev, "#757575")
            sev_bar_segments += (
                f'<div class="sev-seg" style="width:{pct}%;background:{color}" '
                f'title="{sev.capitalize()}: {count} ({pct}%)">'
                f'{count}</div>'
            )

    if not sev_bar_segments:
        sev_bar_segments = '<div class="sev-seg" style="width:100%;background:#4caf50">No findings</div>'

    # Severity badges
    sev_badges = ""
    for sev in ("critical", "high", "medium", "low", "info"):
        count = agg["findings_by_severity"].get(sev, 0)
        color = _SEVERITY_COLORS.get(sev, "#757575")
        sev_badges += (
            f'<div class="sev-card">'
            f'<div class="sev-count" style="color:{color}">{count}</div>'
            f'<div class="sev-label">{sev.capitalize()}</div>'
            f'</div>'
        )

    # Score color
    avg = agg["avg_compliance_score"]
    score_color = "#4caf50" if avg >= 90 else "#fbc02d" if avg >= 70 else "#d32f2f"

    # Project rows
    project_rows = ""
    for p in projects:
        gate_color = _GATE_COLORS.get(p.gate_status, "#757575")
        gate_label = p.gate_status.upper()
        sc = p.compliance_score
        sc_color = "#4caf50" if sc >= 90 else "#fbc02d" if sc >= 70 else "#d32f2f"
        last = p.last_scan.strftime("%Y-%m-%d %H:%M") if p.last_scan else "Never"
        fw_tags = " ".join(
            f'<span class="fw-tag">{escape(fw)}</span>' for fw in p.frameworks
        ) or '<span class="fw-tag dim">None</span>'

        sev_cells = ""
        for sev in ("critical", "high", "medium", "low", "info"):
            count = p.findings_by_severity.get(sev, 0)
            color = _SEVERITY_COLORS.get(sev, "#757575")
            style = f' style="color:{color};font-weight:700"' if count > 0 else ""
            sev_cells += f"<td{style}>{count}</td>"

        project_rows += f"""
        <tr class="project-row" onclick="this.nextElementSibling.classList.toggle('expanded')">
            <td><strong>{escape(p.name)}</strong></td>
            <td style="color:{sc_color};font-weight:700">{sc}%</td>
            {sev_cells}
            <td><span class="gate-badge" style="background:{gate_color}">{gate_label}</span></td>
            <td class="last-scan">{escape(last)}</td>
        </tr>
        <tr class="detail-row">
            <td colspan="9">
                <div class="detail-content">
                    <div><strong>Path:</strong> {escape(p.path)}</div>
                    <div><strong>Frameworks:</strong> {fw_tags}</div>
                    <div><strong>Total findings:</strong> {p.total_findings}</div>
                </div>
            </td>
        </tr>
        """

    # Frameworks coverage
    fw_coverage_rows = ""
    for fw, count in sorted(agg["frameworks_coverage"].items(), key=lambda x: -x[1]):
        pct = round((count / agg["total_projects"]) * 100) if agg["total_projects"] else 0
        fw_coverage_rows += f"""
        <div class="fw-cov-item">
            <div class="fw-cov-name">{escape(fw)}</div>
            <div class="fw-cov-bar"><div class="fw-cov-fill" style="width:{pct}%"></div></div>
            <div class="fw-cov-count">{count}/{agg['total_projects']} projects</div>
        </div>
        """

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Organization Dashboard</title>
<style>
    :root {{
        --bg: #0f0e17;
        --surface: #1a1a2e;
        --border: #2a2a40;
        --text: #e0e0e0;
        --text-muted: #999;
        --primary: #7c3aed;
        --primary-light: #a78bfa;
    }}
    @media (prefers-color-scheme: light) {{
        :root {{
            --bg: #f8f9fa;
            --surface: #ffffff;
            --border: #dee2e6;
            --text: #212529;
            --text-muted: #6c757d;
        }}
    }}
    * {{ margin: 0; padding: 0; box-sizing: border-box; }}
    body {{
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        background: var(--bg);
        color: var(--text);
        line-height: 1.6;
    }}
    .container {{ max-width: 1100px; margin: 0 auto; padding: 0 1.5rem; }}

    .header {{
        text-align: center;
        padding: 3rem 0 2rem;
        border-bottom: 1px solid var(--border);
    }}
    .header h1 {{ font-size: 2rem; margin-bottom: 0.5rem; }}
    .header .sub {{ color: var(--text-muted); }}
    .header .updated {{ color: var(--text-muted); font-size: 0.85rem; margin-top: 0.5rem; }}

    .stats-grid {{
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
        gap: 1rem;
        padding: 2rem 0;
    }}
    .stat-card {{
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 10px;
        padding: 1.2rem;
        text-align: center;
    }}
    .stat-num {{ font-size: 2rem; font-weight: 800; }}
    .stat-label {{ font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase; }}

    .sev-row {{
        display: flex;
        justify-content: center;
        gap: 1.5rem;
        padding: 1rem 0 1.5rem;
    }}
    .sev-card {{ text-align: center; min-width: 70px; }}
    .sev-count {{ font-size: 1.8rem; font-weight: 700; }}
    .sev-label {{ font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase; }}

    .sev-bar {{
        display: flex;
        height: 24px;
        border-radius: 6px;
        overflow: hidden;
        margin-bottom: 2rem;
    }}
    .sev-seg {{
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 0.75rem;
        font-weight: 600;
        min-width: 20px;
    }}

    .section {{ padding: 1.5rem 0; }}
    .section h2 {{
        font-size: 1.3rem;
        margin-bottom: 1rem;
        color: var(--primary-light);
    }}

    table {{
        width: 100%;
        border-collapse: collapse;
        font-size: 0.85rem;
        margin-bottom: 1.5rem;
    }}
    th {{
        background: var(--surface);
        padding: 0.6rem 0.8rem;
        text-align: left;
        font-weight: 600;
        border-bottom: 2px solid var(--border);
        cursor: pointer;
    }}
    th:hover {{ color: var(--primary-light); }}
    td {{ padding: 0.5rem 0.8rem; border-bottom: 1px solid var(--border); }}
    .project-row {{ cursor: pointer; }}
    .project-row:hover {{ background: var(--surface); }}

    .detail-row {{ display: none; }}
    .detail-row.expanded {{ display: table-row; }}
    .detail-content {{
        padding: 0.8rem;
        background: var(--surface);
        border-radius: 6px;
        font-size: 0.85rem;
    }}
    .detail-content div {{ margin-bottom: 0.3rem; }}

    .gate-badge {{
        display: inline-block;
        padding: 0.15rem 0.5rem;
        border-radius: 4px;
        font-size: 0.75rem;
        color: #fff;
        font-weight: 600;
    }}
    .fw-tag {{
        display: inline-block;
        padding: 0.1rem 0.4rem;
        border-radius: 3px;
        font-size: 0.75rem;
        background: var(--primary);
        color: #fff;
        margin: 0.1rem;
    }}
    .fw-tag.dim {{ background: var(--border); color: var(--text-muted); }}
    .last-scan {{ font-size: 0.8rem; color: var(--text-muted); }}

    .fw-cov-item {{
        display: flex;
        align-items: center;
        gap: 0.8rem;
        margin-bottom: 0.5rem;
    }}
    .fw-cov-name {{ width: 180px; font-size: 0.85rem; font-weight: 600; }}
    .fw-cov-bar {{
        flex: 1;
        height: 8px;
        background: var(--border);
        border-radius: 4px;
        overflow: hidden;
    }}
    .fw-cov-fill {{
        height: 100%;
        background: var(--primary);
        border-radius: 4px;
    }}
    .fw-cov-count {{ font-size: 0.8rem; color: var(--text-muted); width: 120px; text-align: right; }}

    .footer {{
        text-align: center;
        padding: 2rem 0;
        border-top: 1px solid var(--border);
        color: var(--text-muted);
        font-size: 0.8rem;
    }}
    .footer a {{ color: var(--primary-light); text-decoration: none; }}

    @media print {{
        body {{ background: #fff; color: #000; }}
        .detail-row.expanded {{ display: table-row; }}
    }}
    @media (max-width: 600px) {{
        .stats-grid {{ grid-template-columns: repeat(2, 1fr); }}
        .sev-row {{ flex-wrap: wrap; }}
    }}
</style>
</head>
<body>
<div class="container">

<div class="header">
    <h1>Organization Dashboard</h1>
    <p class="sub">Multi-repo compliance overview powered by Sentrik</p>
    <p class="updated">Generated: {escape(now)}</p>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-num">{agg['total_projects']}</div>
        <div class="stat-label">Projects</div>
    </div>
    <div class="stat-card">
        <div class="stat-num" style="color:{score_color}">{avg}%</div>
        <div class="stat-label">Avg Compliance</div>
    </div>
    <div class="stat-card">
        <div class="stat-num" style="color:#4caf50">{agg['projects_passing']}</div>
        <div class="stat-label">Passing</div>
    </div>
    <div class="stat-card">
        <div class="stat-num" style="color:#d32f2f">{agg['projects_failing']}</div>
        <div class="stat-label">Failing</div>
    </div>
    <div class="stat-card">
        <div class="stat-num">{agg['total_findings']}</div>
        <div class="stat-label">Total Findings</div>
    </div>
</div>

<div class="sev-row">
    {sev_badges}
</div>

<div class="section">
    <h2>Severity Distribution</h2>
    <div class="sev-bar">
        {sev_bar_segments}
    </div>
</div>

<div class="section">
    <h2>Projects</h2>
    <p style="color:var(--text-muted);font-size:0.85rem;margin-bottom:0.8rem">Click a row to expand details</p>
    <table>
        <thead>
            <tr>
                <th>Project</th>
                <th>Score</th>
                <th>Crit</th>
                <th>High</th>
                <th>Med</th>
                <th>Low</th>
                <th>Info</th>
                <th>Gate</th>
                <th>Last Scan</th>
            </tr>
        </thead>
        <tbody>
            {project_rows if project_rows else '<tr><td colspan="9" style="text-align:center;color:var(--text-muted)">No projects found</td></tr>'}
        </tbody>
    </table>
</div>

{"" if not fw_coverage_rows else f'''
<div class="section">
    <h2>Framework Coverage</h2>
    {fw_coverage_rows}
</div>
'''}

<div class="footer">
    Generated by <a href="https://sentrik.dev">Sentrik</a> v{__version__}
</div>

</div>
</body>
</html>"""

    return html
