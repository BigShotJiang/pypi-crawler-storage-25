"""Actionable error messaging system for AI SDLC Guard CLI.

Provides rich, contextual error messages with root causes, suggested fixes,
and example commands so users always know what went wrong and what to do next.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class ErrorCategory(str, Enum):
    """Categories of errors for grouping and filtering."""

    CONFIG = "config"
    CREDENTIALS = "credentials"
    DEVOPS = "devops"
    GOVERNANCE = "governance"
    LICENSE = "license"
    FILE = "file"
    SCAN = "scan"


@dataclass
class ErrorContext:
    """Rich error context with actionable guidance."""

    category: ErrorCategory
    message: str
    root_cause: str
    suggested_actions: list[str] = field(default_factory=list)
    example_command: str = ""
    docs_hint: str = ""


# ---------------------------------------------------------------------------
# Error catalog — maps error keys to rich context
# ---------------------------------------------------------------------------

ERROR_CATALOG: dict[str, ErrorContext] = {
    # Credential errors
    "azure_no_pat": ErrorContext(
        category=ErrorCategory.CREDENTIALS,
        message="Azure DevOps Personal Access Token not configured",
        root_cause="The AZURE_DEVOPS_PAT environment variable is not set.",
        suggested_actions=[
            "1. Create a PAT in Azure DevOps → User Settings → Personal Access Tokens",
            "2. Grant 'Work Items (Read & Write)' scope",
            "3. Set the variable:",
            "     Bash:       export AZURE_DEVOPS_PAT='your-pat-here'",
            "     PowerShell: $env:AZURE_DEVOPS_PAT = 'your-pat-here'",
            "4. Re-run your command",
        ],
        example_command="export AZURE_DEVOPS_PAT='pat_xyz' && sentrik scan",
    ),
    "azure_missing_config": ErrorContext(
        category=ErrorCategory.CONFIG,
        message="Azure DevOps organization or project not configured",
        root_cause="azure_devops_org and azure_devops_project must both be set in .guard.yaml.",
        suggested_actions=[
            "Add to .guard.yaml:",
            "  azure_devops_org: your-org-name",
            "  azure_devops_project: your-project-name",
            "Or re-run: sentrik init",
        ],
        example_command="sentrik init",
    ),
    "github_no_token": ErrorContext(
        category=ErrorCategory.CREDENTIALS,
        message="GitHub token not configured",
        root_cause="The GITHUB_TOKEN environment variable is not set.",
        suggested_actions=[
            "1. Generate a token: https://github.com/settings/tokens/new",
            "2. Required scopes: 'repo', 'read:org'",
            "3. Set the variable:",
            "     Bash:       export GITHUB_TOKEN='<token>'",
            "     PowerShell: $env:GITHUB_TOKEN = '<token>'",
            "4. Re-run your command",
        ],
        example_command="export GITHUB_TOKEN='<token>' && sentrik reconcile --dry-run",
    ),
    "github_missing_config": ErrorContext(
        category=ErrorCategory.CONFIG,
        message="GitHub owner or repository not configured",
        root_cause="github_owner and github_repo must both be set in .guard.yaml.",
        suggested_actions=[
            "Add to .guard.yaml:",
            "  github_owner: your-username-or-org",
            "  github_repo: your-repo-name",
            "Or re-run: sentrik init",
        ],
        example_command="sentrik init",
    ),
    "jira_no_credentials": ErrorContext(
        category=ErrorCategory.CREDENTIALS,
        message="Jira credentials not configured",
        root_cause="Neither JIRA_USER+JIRA_TOKEN nor JIRA_PAT environment variables are set.",
        suggested_actions=[
            "For Jira Cloud:",
            "  1. Create an API token: https://id.atlassian.com/manage-profile/security/api-tokens",
            "  2. Set variables:",
            "       export JIRA_USER='<your-email>'",
            "       export JIRA_TOKEN='<your-token>'",
            "For Jira Data Center/Server:",
            "  1. Create a PAT in your Jira profile",
            "  2. Set variable: export JIRA_PAT='your-pat'",
        ],
    ),
    "jira_missing_config": ErrorContext(
        category=ErrorCategory.CONFIG,
        message="Jira base URL not configured",
        root_cause="jira_base_url must be set in .guard.yaml.",
        suggested_actions=[
            "Add to .guard.yaml:",
            "  jira_base_url: https://your-instance.atlassian.net",
            "  jira_project_key: PROJ",
            "Or re-run: sentrik init",
        ],
    ),
    # File errors
    "no_findings": ErrorContext(
        category=ErrorCategory.FILE,
        message="No scan findings found",
        root_cause="findings.json does not exist. A scan must be run first.",
        suggested_actions=[
            "Run a scan: sentrik scan",
            "Then retry your command.",
        ],
        example_command="sentrik scan && sentrik gate",
    ),
    "no_patches": ErrorContext(
        category=ErrorCategory.FILE,
        message="No patches available to apply",
        root_cause="No .patch files found in the output directory. Patches are generated during scan when auto-fix rules match.",
        suggested_actions=[
            "Run a scan first: sentrik scan",
            "Auto-fix patches are created when rules have 'autofix' patterns.",
            "Check your standards for rules with autofix enabled.",
        ],
        example_command="sentrik scan",
    ),
    "work_items_not_found": ErrorContext(
        category=ErrorCategory.FILE,
        message="Work items file not found",
        root_cause="The configured work_items_file does not exist.",
        suggested_actions=[
            "Create work_items.json or update the path in .guard.yaml:",
            "  work_items_file: path/to/work_items.json",
            "Or run: sentrik reconcile --dry-run  (to auto-generate from findings)",
        ],
    ),
    "config_not_found": ErrorContext(
        category=ErrorCategory.CONFIG,
        message="No .guard.yaml configuration found",
        root_cause="SENTRIK could not find a configuration file in the current directory.",
        suggested_actions=[
            "Run the setup wizard: sentrik init",
            "Or create a minimal .guard.yaml manually.",
        ],
        example_command="sentrik init",
    ),
    # License errors
    "license_expired": ErrorContext(
        category=ErrorCategory.LICENSE,
        message="License has expired",
        root_cause="Your GUARD_LICENSE_KEY has passed its expiry date.",
        suggested_actions=[
            "Contact your administrator to renew the license.",
            "Set a new key: export GUARD_LICENSE_KEY='GUARD-TIER-YYYYMMDD-HMAC'",
            "Core features (scan, gate) continue to work in trial mode.",
        ],
    ),
    "license_feature_unavailable": ErrorContext(
        category=ErrorCategory.LICENSE,
        message="Feature not available at your license tier",
        root_cause="This feature requires a higher-tier license.",
        suggested_actions=[
            "Check available features: sentrik license",
            "Contact your administrator to upgrade.",
            "Trial mode includes: scan, gate, basic reporting.",
        ],
        example_command="sentrik license",
    ),
    # Governance errors
    "governance_blocked": ErrorContext(
        category=ErrorCategory.GOVERNANCE,
        message="Action blocked by governance policy",
        root_cause="Your governance profile requires human review for this action.",
        suggested_actions=[
            "1. Submit a pull request with these changes",
            "2. Assign a reviewer for approval",
            "3. Once approved, the gate will pass",
            "View current policy: sentrik dashboard → Policies tab",
        ],
        docs_hint="See https://docs.sentrik.dev for governance profile details.",
    ),
    "governance_patch_blocked": ErrorContext(
        category=ErrorCategory.GOVERNANCE,
        message="Auto-patching blocked by governance policy",
        root_cause="The severity of findings exceeds your governance profile's auto-patch limit.",
        suggested_actions=[
            "1. Review patches manually before applying",
            "2. Submit changes via a reviewed PR",
            "3. Or adjust governance.auto_patch.max_severity in .guard.yaml",
        ],
    ),
    # Scan errors
    "mutually_exclusive_flags": ErrorContext(
        category=ErrorCategory.SCAN,
        message="Conflicting scope flags",
        root_cause="--staged, --git-range, and --diff cannot be used together.",
        suggested_actions=[
            "Choose one scoping method:",
            "  sentrik scan --staged                    (git-staged files)",
            "  sentrik scan --git-range origin/main..HEAD  (branch diff)",
            "  sentrik scan --diff '<diff text>'         (raw diff)",
            "  sentrik scan                              (full project)",
        ],
    ),
    # Server errors
    "server_missing_deps": ErrorContext(
        category=ErrorCategory.CONFIG,
        message="Server dependencies not installed",
        root_cause="FastAPI and Uvicorn are required for the REST API server.",
        suggested_actions=[
            "Install server dependencies:",
            "  pip install sentrik[server]",
            "Or install individually:",
            "  pip install fastapi uvicorn",
        ],
        example_command="pip install sentrik[server]",
    ),
    # Connection errors
    "devops_connection_failed": ErrorContext(
        category=ErrorCategory.DEVOPS,
        message="DevOps connection test failed",
        root_cause="Could not connect to the configured DevOps provider.",
        suggested_actions=[
            "1. Verify your credentials are set (check environment variables)",
            "2. Verify your config values (org, project, repo names)",
            "3. Check network connectivity to the provider API",
            "4. Run: sentrik test-connection  (for detailed diagnostics)",
        ],
        example_command="sentrik test-connection",
    ),
}


def get_error_context(key: str, **overrides: str) -> ErrorContext | None:
    """Look up an error context by key, with optional field overrides."""
    ctx = ERROR_CATALOG.get(key)
    if ctx is None:
        return None
    if overrides:
        # Create a copy with overrides applied
        return ErrorContext(
            category=ctx.category,
            message=overrides.get("message", ctx.message),
            root_cause=overrides.get("root_cause", ctx.root_cause),
            suggested_actions=ctx.suggested_actions,
            example_command=overrides.get("example_command", ctx.example_command),
            docs_hint=overrides.get("docs_hint", ctx.docs_hint),
        )
    return ctx


def categorize_error(exc: Exception, context: str = "") -> str | None:
    """Attempt to categorize an exception into an error catalog key.

    Returns the error key if matched, None otherwise.
    """
    msg = str(exc).lower()

    if "azure_devops_pat" in msg:
        return "azure_no_pat"
    if "github_token" in msg:
        return "github_no_token"
    if "jira_user" in msg or "jira_token" in msg or "jira_pat" in msg:
        return "jira_no_credentials"
    if "license" in msg and "expired" in msg:
        return "license_expired"
    if "license" in msg and ("feature" in msg or "tier" in msg):
        return "license_feature_unavailable"
    if "findings.json" in msg and "not found" in msg:
        return "no_findings"

    # Context-based matching
    if context == "azure_sync" and ("org" in msg or "project" in msg):
        return "azure_missing_config"
    if context == "github_sync" and ("owner" in msg or "repo" in msg):
        return "github_missing_config"

    return None
