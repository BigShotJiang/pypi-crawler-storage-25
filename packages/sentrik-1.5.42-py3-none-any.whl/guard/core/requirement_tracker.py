"""Requirement coverage checking for AI SDLC Guard.

Compares modified/new files against active work items and flags
untracked files as findings needing a new work item.
"""

from __future__ import annotations

import fnmatch
import re
import uuid
from typing import Optional

from guard.core.models import Evidence, Finding, Severity, WorkItem

STOP_WORDS = frozenset({
    "the", "a", "an", "and", "or", "of", "to", "in", "for", "is", "on",
    "at", "by", "with", "from", "as", "it", "be", "that", "this",
    # Common path/extension tokens
    "src", "lib", "app", "py", "js", "ts", "tsx", "jsx", "css", "html",
    "go", "rs", "java", "cpp", "c", "h", "hpp", "rb", "php",
    "core", "utils", "util", "helpers", "helper", "index", "main",
    "init", "__init__",
})

DEFAULT_EXCLUDE_PATTERNS = [
    "tests/*", "test_*", "*.md", "*.txt", "*.yaml", "*.yml",
    "*.json", "*.toml", "*.cfg", "*.ini", "*.lock", "*.git*",
    "__init__.py", "__pycache__/*", "*.pyc", "*.pyo",
    "*.db", "*.db-shm", "*.db-wal", "*.sqlite*",
    "out/*", "dist/*", "build/*", "*.egg-info/*",
    "*.patch", "*.html", "*.css", "*.min.*",
]


def _tokenize(text: str) -> set[str]:
    """Split text on separators and return lowercase tokens, filtering stop words."""
    raw = re.split(r"[/\\_.\-\s]+", text.lower())
    return {t for t in raw if t and t not in STOP_WORDS and len(t) > 1}


def _is_covered(
    file_tokens: set[str],
    work_items_tokens: list[set[str]],
    file_path: str,
    work_item_ids: list[str],
) -> bool:
    """Check if a file is covered by any work item.

    A file is covered if:
    - Any work item's tokens share meaningful tokens with the file, OR
    - The file path contains a work item ID (case-insensitive).

    The overlap threshold adapts: 1 token suffices when the file has
    few meaningful tokens (common for short filenames like ``audit_log.cpp``).
    """
    file_lower = file_path.lower()

    # Check if any work item ID appears in the file path
    for wi_id in work_item_ids:
        if wi_id.lower() in file_lower:
            return True

    # Check token overlap — adaptive threshold
    # Short filenames (1-2 tokens) need only 1 overlap; longer need 2+.
    threshold = 1 if len(file_tokens) <= 2 else 2
    for wi_tokens in work_items_tokens:
        overlap = file_tokens & wi_tokens
        if len(overlap) >= threshold:
            return True

    return False


def check_requirement_coverage(
    files: list[str],
    work_items: list[WorkItem],
    exclude_patterns: Optional[list[str]] = None,
) -> list[Finding]:
    """Check which files lack traceability to any active work item.

    Args:
        files: List of file paths to check.
        work_items: Active work items from the DevOps provider.
        exclude_patterns: Glob patterns for files to skip (tests, config, etc.).

    Returns:
        List of findings for untracked files.
    """
    if exclude_patterns is None:
        exclude_patterns = DEFAULT_EXCLUDE_PATTERNS

    # Filter out excluded files
    filtered: list[str] = []
    for f in files:
        basename = f.rsplit("/", 1)[-1] if "/" in f else f
        excluded = False
        for pat in exclude_patterns:
            if fnmatch.fnmatch(f, pat) or fnmatch.fnmatch(basename, pat):
                excluded = True
                break
        if not excluded:
            filtered.append(f)

    if not filtered:
        return []

    # Only consider active work items
    active_items = [wi for wi in work_items if wi.state != "closed"]

    # Pre-compute tokens and IDs for all work items
    wi_tokens_list = [
        _tokenize(wi.title) | _tokenize(wi.description) for wi in active_items
    ]
    wi_ids = [wi.id for wi in active_items]

    findings: list[Finding] = []
    for path in filtered:
        file_tokens = _tokenize(path)
        # Files with no meaningful tokens (e.g. main.cpp, index.js, app.py)
        # are generic infrastructure and should not generate coverage findings.
        if not file_tokens:
            continue
        if not _is_covered(file_tokens, wi_tokens_list, path, wi_ids):
            findings.append(Finding(
                finding_id=f"REQ-COV-{uuid.uuid4().hex[:8]}",
                rule_id="GUARD-REQ-COVERAGE",
                severity=Severity.MEDIUM,
                message=f"File '{path}' is not traced to any active work item",
                evidence=Evidence(file=path, lines=[1], snippet=""),
                confidence=1.0,
                deterministic=True,
                compliance_category="traceability",
            ))

    return findings
