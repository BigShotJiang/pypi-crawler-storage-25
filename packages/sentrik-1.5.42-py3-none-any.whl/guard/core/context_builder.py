"""Builds the agent_context.json artifact."""

from __future__ import annotations

from guard.config import GuardConfig
from guard.core.models import AgentContext, DefinitionOfDone
from guard.providers.devops_base import DevOpsProvider
from guard.providers.standards_base import StandardsProvider


def build_agent_context(
    repo_root: str,
    config: GuardConfig,
    devops: DevOpsProvider,
    standards: StandardsProvider,
) -> AgentContext:
    work_items = devops.get_work_items()
    rule_ids = standards.get_rule_ids()

    # Build governance summary for agent context
    gov = config.get_governance()
    governance_summary = {
        "profile": gov.profile,
        "human_review_required": gov.human_review_required.model_dump(),
        "auto_patch": gov.auto_patch.model_dump(),
        "gate": gov.gate.model_dump(),
        "sync": gov.sync.model_dump(),
    }

    return AgentContext(
        repo_root=repo_root,
        work_items=work_items,
        standards_rule_ids=rule_ids,
        definition_of_done=DefinitionOfDone(
            gate_must_pass=True,
            required_rules=rule_ids,
        ),
        commands={
            "scan": "guard scan",
            "gate": "guard gate",
            "apply_patches": "guard apply-patches",
            "reconcile": "guard reconcile",
            "report": "guard report --format html",
            "compare": "guard compare --previous <path>",
            "list_rules": "guard list-rules",
            "validate_config": "guard validate-config",
        },
        governance=governance_summary,
    )
