"""Scan metrics collection for performance monitoring and dashboard."""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class RuleMetrics:
    """Timing and counts for a single rule evaluation."""

    rule_id: str
    rule_type: str
    files_evaluated: int = 0
    findings_count: int = 0
    duration_ms: float = 0.0


@dataclass
class AgentMetrics:
    """Timing and counts for a single compliance agent."""

    pack_id: str
    duration_ms: float = 0.0
    findings_count: int = 0
    files_scanned: int = 0
    rule_count: int = 0
    error: str | None = None


@dataclass
class ScanMetrics:
    """Aggregated metrics for a complete scan run."""

    total_duration_ms: float = 0.0
    rules_engine_ms: float = 0.0
    scanner_ms: float = 0.0
    rescorer_ms: float = 0.0
    ml_estimator_ms: float = 0.0  # backward-compat alias for rescorer_ms
    files_scanned: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    total_findings: int = 0
    findings_by_severity: dict[str, int] = field(default_factory=dict)
    findings_by_rule: dict[str, int] = field(default_factory=dict)
    rule_metrics: list[RuleMetrics] = field(default_factory=list)
    agent_metrics: list[AgentMetrics] = field(default_factory=list)
    parallel_workers: int = 1
    suppressed_count: int = 0
    total_before_suppression: int = 0

    @property
    def false_positive_rate(self) -> float:
        """Suppression/false-positive rate as percentage (0-100)."""
        if self.total_before_suppression == 0:
            return 0.0
        return (self.suppressed_count / self.total_before_suppression) * 100

    @property
    def cache_hit_rate(self) -> float:
        """Cache hit rate as a percentage (0-100)."""
        total = self.cache_hits + self.cache_misses
        if total == 0:
            return 0.0
        return (self.cache_hits / total) * 100

    @property
    def effective_rescorer_ms(self) -> float:
        """Return the effective rescorer time, considering both fields."""
        return self.rescorer_ms or self.ml_estimator_ms

    def to_dict(self) -> dict[str, Any]:
        """Serialize metrics to a dictionary."""
        eff_rescorer = self.effective_rescorer_ms
        return {
            "total_duration_ms": round(self.total_duration_ms, 2),
            "rules_engine_ms": round(self.rules_engine_ms, 2),
            "scanner_ms": round(self.scanner_ms, 2),
            "rescorer_ms": round(eff_rescorer, 2),
            "ml_estimator_ms": round(eff_rescorer, 2),  # backward compat
            "files_scanned": self.files_scanned,
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses,
            "cache_hit_rate": round(self.cache_hit_rate, 1),
            "total_findings": self.total_findings,
            "findings_by_severity": self.findings_by_severity,
            "findings_by_rule": self.findings_by_rule,
            "parallel_workers": self.parallel_workers,
            "suppressed_count": self.suppressed_count,
            "total_before_suppression": self.total_before_suppression,
            "false_positive_rate": round(self.false_positive_rate, 1),
            "rule_metrics": [
                {
                    "rule_id": rm.rule_id,
                    "rule_type": rm.rule_type,
                    "files_evaluated": rm.files_evaluated,
                    "findings_count": rm.findings_count,
                    "duration_ms": round(rm.duration_ms, 2),
                }
                for rm in self.rule_metrics
            ],
            "agent_metrics": [
                {
                    "pack_id": am.pack_id,
                    "duration_ms": round(am.duration_ms, 2),
                    "findings_count": am.findings_count,
                    "files_scanned": am.files_scanned,
                    "rule_count": am.rule_count,
                    "error": am.error,
                }
                for am in self.agent_metrics
            ],
        }

    def save(self, output_dir: str | Path) -> Path:
        """Write metrics to a JSON file in the output directory."""
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        path = out / "scan_metrics.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)
        return path


class MetricsCollector:
    """Collects metrics during a scan run.

    Usage::

        collector = MetricsCollector()
        collector.start()

        with collector.time_rules_engine():
            findings = rules_engine.evaluate(...)

        with collector.time_scanner():
            scanner_findings = scanner.scan(...)

        collector.record_findings(all_findings)
        collector.stop()
        metrics = collector.metrics
    """

    def __init__(self, parallel_workers: int = 1):
        self._metrics = ScanMetrics(parallel_workers=parallel_workers)
        self._start_time: float = 0.0

    @property
    def metrics(self) -> ScanMetrics:
        return self._metrics

    def start(self) -> None:
        """Mark the start of the scan."""
        self._start_time = time.perf_counter()

    def stop(self) -> None:
        """Mark the end of the scan and compute total duration."""
        self._metrics.total_duration_ms = (
            time.perf_counter() - self._start_time
        ) * 1000

    def time_rules_engine(self) -> _Timer:
        """Context manager to time the rules engine phase."""
        return _Timer(self._metrics, "rules_engine_ms")

    def time_scanner(self) -> _Timer:
        """Context manager to time the scanner phase."""
        return _Timer(self._metrics, "scanner_ms")

    def time_rescorer(self) -> _Timer:
        """Context manager to time the severity rescoring phase."""
        return _DualTimer(self._metrics, "rescorer_ms", "ml_estimator_ms")

    def time_ml_estimator(self) -> _Timer:
        """Context manager to time the severity rescoring phase (legacy alias)."""
        return _DualTimer(self._metrics, "rescorer_ms", "ml_estimator_ms")

    def record_cache_hit(self) -> None:
        self._metrics.cache_hits += 1

    def record_cache_miss(self) -> None:
        self._metrics.cache_misses += 1

    def record_file_scanned(self) -> None:
        self._metrics.files_scanned += 1

    def record_findings(self, findings: list) -> None:
        """Record finding counts by severity and rule."""
        self._metrics.total_findings = len(findings)
        sev_counts: dict[str, int] = {}
        rule_counts: dict[str, int] = {}
        for f in findings:
            sev = f.severity.value if hasattr(f.severity, "value") else str(f.severity)
            sev_counts[sev] = sev_counts.get(sev, 0) + 1
            rule_counts[f.rule_id] = rule_counts.get(f.rule_id, 0) + 1
        self._metrics.findings_by_severity = sev_counts
        self._metrics.findings_by_rule = rule_counts

    def add_rule_metrics(self, rule_metrics: RuleMetrics) -> None:
        self._metrics.rule_metrics.append(rule_metrics)


class _Timer:
    """Simple context manager that records elapsed time to a metrics attribute."""

    def __init__(self, metrics: ScanMetrics, attr: str):
        self._metrics = metrics
        self._attr = attr
        self._start: float = 0.0

    def __enter__(self) -> _Timer:
        self._start = time.perf_counter()
        return self

    def __exit__(self, *args: Any) -> None:
        elapsed = (time.perf_counter() - self._start) * 1000
        setattr(self._metrics, self._attr, elapsed)


class _DualTimer:
    """Context manager that records elapsed time to two metrics attributes."""

    def __init__(self, metrics: ScanMetrics, attr1: str, attr2: str):
        self._metrics = metrics
        self._attr1 = attr1
        self._attr2 = attr2
        self._start: float = 0.0

    def __enter__(self) -> _DualTimer:
        self._start = time.perf_counter()
        return self

    def __exit__(self, *args: Any) -> None:
        elapsed = (time.perf_counter() - self._start) * 1000
        setattr(self._metrics, self._attr1, elapsed)
        setattr(self._metrics, self._attr2, elapsed)
