"""Finding suppression — filter findings based on suppression rules."""

from __future__ import annotations

import fnmatch
from datetime import date, datetime
from typing import Any

from guard.core.models import Finding


def is_suppressed(finding: Finding, suppression: dict[str, Any]) -> bool:
    """Check if a single finding matches a suppression rule.

    A suppression dict may contain:
      - rule_id: str — exact match or glob pattern (required)
      - file_pattern: str — glob pattern for file path (optional)
      - expires: str — ISO date (YYYY-MM-DD) after which suppression is inactive (optional)
      - reason: str — human-readable reason (informational only)
    """
    # Check expiry
    expires = suppression.get("expires")
    if expires:
        try:
            expiry_date = datetime.strptime(expires, "%Y-%m-%d").date()
            if date.today() > expiry_date:
                return False
        except ValueError:
            pass  # Invalid date format — treat as non-expired

    # Check rule_id (required)
    rule_pattern = suppression.get("rule_id", "")
    if not rule_pattern:
        return False
    if not fnmatch.fnmatch(finding.rule_id, rule_pattern):
        return False

    # Check file_pattern (optional — if present, must match)
    file_pattern = suppression.get("file_pattern")
    if file_pattern:
        file_path = finding.evidence.file if finding.evidence else ""
        if not fnmatch.fnmatch(file_path, file_pattern):
            return False

    return True


def filter_suppressed(
    findings: list[Finding],
    suppressions: list[dict[str, Any]],
) -> tuple[list[Finding], list[Finding]]:
    """Split findings into (active, suppressed) based on suppression rules.

    Returns:
        Tuple of (active_findings, suppressed_findings).
    """
    if not suppressions:
        return findings, []

    active: list[Finding] = []
    suppressed: list[Finding] = []

    for finding in findings:
        if any(is_suppressed(finding, s) for s in suppressions):
            suppressed.append(finding)
        else:
            active.append(finding)

    return active, suppressed
