"""Traceability linking — extracts work item IDs and associates findings."""

from __future__ import annotations

import re
import subprocess

from guard.core.models import Finding

# Default pattern matches WI-123 style identifiers.
DEFAULT_WORK_ITEM_PATTERN = r"WI-\d+"


def extract_work_item_ids(
    text: str,
    pattern: str = DEFAULT_WORK_ITEM_PATTERN,
) -> list[str]:
    """Extract work item IDs from *text* using *pattern*.

    Searches branch names, commit messages, or any free-form text and
    returns a deduplicated list of matched IDs in the order they first
    appear.
    """
    if not text:
        return []
    try:
        matches = re.findall(pattern, text)
    except re.error:
        return []
    # Deduplicate while preserving order
    seen: set[str] = set()
    result: list[str] = []
    for m in matches:
        if m not in seen:
            seen.add(m)
            result.append(m)
    return result


def link_findings_to_work_items(
    findings: list[Finding],
    work_item_ids: list[str],
) -> list[Finding]:
    """Populate ``related_work_items`` on each finding.

    Every finding in the list is associated with the supplied
    *work_item_ids* (typically derived from the current branch name or
    commit message).  Existing ``related_work_items`` are preserved and
    new IDs are appended without duplicates.

    Returns the same list (mutated in-place) for convenience.
    """
    if not work_item_ids:
        return findings

    for finding in findings:
        existing = set(finding.related_work_items)
        merged = list(finding.related_work_items)
        for wid in work_item_ids:
            if wid not in existing:
                merged.append(wid)
                existing.add(wid)
        finding.related_work_items = merged

    return findings


REQ_COMMENT_PATTERN = re.compile(
    r"(?://|#|--|/\*)\s*(REQ-\d+|SRS-\d+)",
    re.IGNORECASE,
)


def scan_files_for_reqs(
    repo_root: str,
    file_globs: list[str] | None = None,
    scan_exclude: list[str] | None = None,
) -> dict[str, list[str]]:
    """Scan source files for ``// REQ-xxx`` or ``# REQ-xxx`` traceability comments.

    Returns a dict mapping each file (relative path) to its list of
    referenced requirement IDs, e.g. ``{"src/main.cpp": ["REQ-001", "REQ-002"]}``.
    """
    from guard.core.repo_reader import list_files

    root = __import__("pathlib").Path(repo_root)
    globs = file_globs or ["**/*"]
    exclude = scan_exclude or []

    file_reqs: dict[str, list[str]] = {}
    for glob in globs:
        for rel_path in list_files(root, glob):
            # Apply scan_exclude (directory prefix matching)
            if any(rel_path.replace("\\", "/").startswith(ex.rstrip("/")) for ex in exclude):
                continue
            full = root / rel_path
            try:
                content = full.read_text(encoding="utf-8", errors="ignore")
            except (OSError, UnicodeDecodeError):
                continue

            seen: set[str] = set()
            reqs: list[str] = []
            for match in REQ_COMMENT_PATTERN.finditer(content):
                req_id = match.group(1).upper()
                if req_id not in seen:
                    seen.add(req_id)
                    reqs.append(req_id)
            if reqs:
                file_reqs[rel_path.replace("\\", "/")] = reqs

    return file_reqs


def build_traceability_matrix(
    file_reqs: dict[str, list[str]],
    work_items: list[dict],
) -> dict:
    """Build a traceability matrix cross-referencing requirements and files.

    Returns a dict with:
    - ``requirements``: list of dicts per requirement with implementing files
    - ``unlinked_files``: source files with REQ refs that don't match any work item
    - ``unimplemented``: work items with no implementing code
    - ``summary``: counts
    """
    # Build lookup of known requirement IDs from work items
    wi_by_id: dict[str, dict] = {}
    for wi in work_items:
        wid = wi.get("id", "").upper()
        if wid:
            wi_by_id[wid] = wi

    # Invert: requirement → files
    req_to_files: dict[str, list[str]] = {}
    for fpath, req_ids in file_reqs.items():
        for rid in req_ids:
            req_to_files.setdefault(rid, []).append(fpath)

    # Build per-requirement entries
    requirements = []
    implemented_ids: set[str] = set()
    for rid in sorted(set(list(req_to_files.keys()) + list(wi_by_id.keys()))):
        files = req_to_files.get(rid, [])
        wi = wi_by_id.get(rid)
        entry: dict = {
            "id": rid,
            "title": wi.get("title", "") if wi else "",
            "files": sorted(files),
            "defined": rid in wi_by_id,
            "implemented": len(files) > 0,
        }
        requirements.append(entry)
        if files:
            implemented_ids.add(rid)

    # Files referencing unknown requirements
    all_known = set(wi_by_id.keys())
    unlinked: list[dict] = []
    for fpath, req_ids in sorted(file_reqs.items()):
        unknown = [r for r in req_ids if r not in all_known]
        if unknown:
            unlinked.append({"file": fpath, "unknown_refs": unknown})

    # Work items with no implementing code
    unimplemented = [
        {"id": rid, "title": wi.get("title", "")}
        for rid, wi in wi_by_id.items()
        if rid not in implemented_ids
    ]

    total_reqs = len(wi_by_id)
    implemented_count = len(implemented_ids & set(wi_by_id.keys()))

    return {
        "requirements": requirements,
        "unlinked_files": unlinked,
        "unimplemented": unimplemented,
        "summary": {
            "total_requirements": total_reqs,
            "implemented": implemented_count,
            "unimplemented": total_reqs - implemented_count,
            "total_files_with_refs": len(file_reqs),
            "coverage_pct": round(100 * implemented_count / total_reqs, 1) if total_reqs else 0.0,
        },
    }


def get_current_branch() -> str | None:
    """Return the current git branch name, or *None* outside a repo."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            branch = result.stdout.strip()
            if branch and branch != "HEAD":
                return branch
    except FileNotFoundError:
        pass
    return None
