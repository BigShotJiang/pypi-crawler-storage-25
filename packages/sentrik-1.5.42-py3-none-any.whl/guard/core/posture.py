"""Security posture scoring — aggregates compliance, vulnerability, and trend data
into a single Application Security Posture Management (ASPM) score.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class PostureScore:
    """Aggregate security posture with component breakdown."""

    overall: float  # 0-100
    compliance: float  # 0-100
    vulnerability: float  # 0-100
    trend: float  # 0-100 (improving = higher)
    gate_reliability: float  # 0-100
    status: str  # "healthy", "needs_attention", "at_risk", "critical"
    components: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "overall": round(self.overall, 1),
            "status": self.status,
            "components": {
                "compliance": {"score": round(self.compliance, 1), "weight": 0.35},
                "vulnerability": {"score": round(self.vulnerability, 1), "weight": 0.30},
                "trend": {"score": round(self.trend, 1), "weight": 0.15},
                "gate_reliability": {"score": round(self.gate_reliability, 1), "weight": 0.20},
            },
            "details": self.components,
        }


def calculate_posture(output_dir: str = "out", metrics_db_path: Path | None = None) -> PostureScore:
    """Calculate the aggregate security posture score.

    Components:
    - Compliance (35%): Latest compliance score from scan metrics
    - Vulnerability (30%): Inverse of vulnerability ratio
    - Trend (15%): Score improvement over recent scans
    - Gate reliability (20%): Gate pass rate over recent history
    """
    out = Path(output_dir)
    details: dict[str, Any] = {}

    # --- Compliance component (35%) ---
    compliance_score = 50.0  # default if no scan data
    scan_metrics_path = out / "scan_metrics.json"
    if scan_metrics_path.exists():
        try:
            metrics = json.loads(scan_metrics_path.read_text(encoding="utf-8"))
            cs = metrics.get("compliance_score")
            if isinstance(cs, dict):
                compliance_score = cs.get("score", 50.0)
            elif isinstance(cs, (int, float)):
                compliance_score = float(cs)
            details["compliance"] = {
                "score": compliance_score,
                "rules_total": cs.get("rules_total", 0) if isinstance(cs, dict) else 0,
                "rules_passed": cs.get("rules_passed", 0) if isinstance(cs, dict) else 0,
                "blocking_findings": cs.get("blocking_findings", 0) if isinstance(cs, dict) else 0,
            }
        except (json.JSONDecodeError, OSError):
            pass

    # --- Vulnerability component (30%) ---
    vuln_score = 100.0  # perfect if no vulns
    vulns_path = out / "vulnerabilities.json"
    if vulns_path.exists():
        try:
            vulns = json.loads(vulns_path.read_text(encoding="utf-8"))
            total_deps = vulns.get("total_dependencies", 1)
            vuln_count = vulns.get("vulnerable_count", 0)
            critical_vulns = sum(
                1 for v in vulns.get("vulnerabilities", [])
                if v.get("severity", "").lower() in ("critical", "high")
            )
            if total_deps > 0:
                vuln_ratio = vuln_count / total_deps
                vuln_score = max(0.0, 100.0 * (1.0 - vuln_ratio * 3))  # 33% vuln = 0 score
            if critical_vulns > 0:
                vuln_score = max(0.0, vuln_score - critical_vulns * 10)
            details["vulnerability"] = {
                "total_dependencies": total_deps,
                "vulnerable_count": vuln_count,
                "critical_high_count": critical_vulns,
            }
        except (json.JSONDecodeError, OSError):
            pass

    # --- Trend component (15%) ---
    trend_score = 50.0  # neutral default
    gate_score = 50.0  # neutral default

    if metrics_db_path is None:
        metrics_db_path = Path(".sentrik") / "local" / "metrics.db"

    if metrics_db_path.exists():
        try:
            from guard.core.metrics_db import MetricsDB
            db = MetricsDB(metrics_db_path)
            try:
                history = db.get_scan_history(limit=20)
                stats = db.get_stats()
            finally:
                db.close()

            # Trend: compare recent compliance to older
            if len(history) >= 2:
                recent = [h.get("compliance_score", 0) for h in history[:5] if h.get("compliance_score") is not None]
                older = [h.get("compliance_score", 0) for h in history[5:] if h.get("compliance_score") is not None]
                if recent and older:
                    avg_recent = sum(recent) / len(recent)
                    avg_older = sum(older) / len(older)
                    delta = avg_recent - avg_older
                    # Map delta to 0-100: -20 = 0, 0 = 50, +20 = 100
                    trend_score = max(0.0, min(100.0, 50.0 + delta * 2.5))
                details["trend"] = {
                    "recent_avg": round(sum(recent) / len(recent), 1) if recent else None,
                    "older_avg": round(sum(older) / len(older), 1) if older else None,
                    "direction": "improving" if trend_score > 55 else "declining" if trend_score < 45 else "stable",
                    "scans_analyzed": len(history),
                }

            # Gate reliability
            total_scans = stats.get("total_scans", 0)
            gates_passed = stats.get("gates_passed", 0)
            if total_scans > 0:
                gate_score = (gates_passed / total_scans) * 100.0
            details["gate_reliability"] = {
                "total_scans": total_scans,
                "gates_passed": gates_passed,
                "gates_failed": stats.get("gates_failed", 0),
                "pass_rate": round(gate_score, 1),
            }
        except (ImportError, OSError):
            logger.debug("Metrics DB not available for posture scoring")

    # --- Weighted aggregate ---
    overall = (
        compliance_score * 0.35
        + vuln_score * 0.30
        + trend_score * 0.15
        + gate_score * 0.20
    )

    # Determine status
    if overall >= 80:
        status = "healthy"
    elif overall >= 60:
        status = "needs_attention"
    elif overall >= 40:
        status = "at_risk"
    else:
        status = "critical"

    return PostureScore(
        overall=overall,
        compliance=compliance_score,
        vulnerability=vuln_score,
        trend=trend_score,
        gate_reliability=gate_score,
        status=status,
        components=details,
    )
