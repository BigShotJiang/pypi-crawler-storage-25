"""Async Approval Gates — block gate results until security-lead approves."""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, Field

from guard.core.models import GateResult

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

class AsyncApprovalConfig(BaseModel):
    """Configuration for async approval gates."""

    enabled: bool = False
    timeout_seconds: int = 3600  # 1 hour default TTL
    notify_roles: list[str] = Field(default_factory=lambda: ["security-lead", "admin"])


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class ApprovalRequest(BaseModel):
    """A pending gate approval request."""

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    status: str = "pending"  # pending | approved | rejected | expired
    gate_result: dict = Field(default_factory=dict)  # GateResult summary
    findings_summary: dict = Field(default_factory=dict)  # severity counts
    requested_by: str = ""
    requested_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    resolved_by: str = ""
    resolved_at: datetime | None = None
    comment: str = ""

    def is_expired(self, timeout_seconds: int = 3600) -> bool:
        """Check if this request has exceeded its TTL."""
        if self.status != "pending":
            return False
        elapsed = (datetime.now(timezone.utc) - self.requested_at).total_seconds()
        return elapsed > timeout_seconds


# ---------------------------------------------------------------------------
# Store protocol + in-memory implementation
# ---------------------------------------------------------------------------

@runtime_checkable
class ApprovalStore(Protocol):
    """Protocol for approval request persistence."""

    def create(self, request: ApprovalRequest) -> ApprovalRequest: ...
    def get(self, request_id: str) -> ApprovalRequest | None: ...
    def resolve(self, request_id: str, action: str, by: str, comment: str = "") -> ApprovalRequest | None: ...
    def list_pending(self) -> list[ApprovalRequest]: ...


class MemoryApprovalStore:
    """In-memory approval store (default — suitable for single-instance deployments).

    Thread-safe: all mutations are guarded by a lock to prevent race
    conditions when concurrent API requests resolve the same approval.
    """

    def __init__(self) -> None:
        import threading
        self._store: dict[str, ApprovalRequest] = {}
        self._lock = threading.Lock()

    def create(self, request: ApprovalRequest) -> ApprovalRequest:
        with self._lock:
            self._store[request.id] = request
        return request

    def get(self, request_id: str) -> ApprovalRequest | None:
        with self._lock:
            return self._store.get(request_id)

    def resolve(self, request_id: str, action: str, by: str, comment: str = "") -> ApprovalRequest | None:
        with self._lock:
            req = self._store.get(request_id)
            if req is None:
                return None
            if req.status != "pending":
                return req  # Already resolved
            req.status = action  # "approved" or "rejected"
            req.resolved_by = by
            req.resolved_at = datetime.now(timezone.utc)
            req.comment = comment
            return req

    def list_pending(self) -> list[ApprovalRequest]:
        with self._lock:
            return [r for r in self._store.values() if r.status == "pending"]


# ---------------------------------------------------------------------------
# Singleton management (matches policy engine pattern)
# ---------------------------------------------------------------------------

_approval_store: ApprovalStore | None = None


def get_approval_store() -> ApprovalStore:
    """Return the global approval store (creates MemoryApprovalStore on first call)."""
    global _approval_store
    if _approval_store is None:
        _approval_store = MemoryApprovalStore()
    return _approval_store


def set_approval_store(store: ApprovalStore) -> None:
    """Replace the global approval store (for testing or custom backends)."""
    global _approval_store
    _approval_store = store


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def create_approval_request(
    gate_result: GateResult,
    config: AsyncApprovalConfig,
    user_id: str = "",
) -> ApprovalRequest:
    """Create and store a new approval request for a failed gate."""
    request = ApprovalRequest(
        gate_result=gate_result.model_dump(),
        findings_summary={
            "critical": gate_result.critical,
            "high": gate_result.high,
            "medium": gate_result.medium,
            "low": gate_result.low,
            "info": gate_result.info,
            "total": gate_result.total_findings,
        },
        requested_by=user_id,
    )
    store = get_approval_store()
    store.create(request)
    logger.info(
        "approval: created request id=%s by=%s critical=%d high=%d",
        request.id,
        user_id,
        gate_result.critical,
        gate_result.high,
    )
    return request
