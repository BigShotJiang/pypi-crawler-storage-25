"""Webhook notifications for gate failures (Slack and Microsoft Teams)."""

from __future__ import annotations

import json
import logging
import os
import urllib.request
import urllib.error
from typing import Any

logger = logging.getLogger(__name__)


def _severity_breakdown(gate_result: Any) -> dict[str, int]:
    """Extract severity counts from a GateResult."""
    return {
        "critical": getattr(gate_result, "critical", 0),
        "high": getattr(gate_result, "high", 0),
        "medium": getattr(gate_result, "medium", 0),
        "low": getattr(gate_result, "low", 0),
        "info": getattr(gate_result, "info", 0),
    }


def _top_failing_rules(findings: list[Any], limit: int = 3) -> list[dict[str, Any]]:
    """Return the top N rules by finding count (critical/high only)."""
    rule_counts: dict[str, int] = {}
    for f in findings:
        sev = getattr(f, "severity", None)
        if sev is None:
            d = f if isinstance(f, dict) else {}
            sev = d.get("severity", "")
        else:
            sev = str(sev)
        if sev in ("critical", "high"):
            rid = getattr(f, "rule_id", None)
            if rid is None:
                rid = f.get("rule_id", "unknown") if isinstance(f, dict) else "unknown"
            rule_counts[rid] = rule_counts.get(rid, 0) + 1
    sorted_rules = sorted(rule_counts.items(), key=lambda x: x[1], reverse=True)
    return [{"rule_id": r, "count": c} for r, c in sorted_rules[:limit]]


def _compliance_score(findings: list[Any]) -> float | None:
    """Compute a simple compliance score if possible.

    Returns a percentage (0-100) or None if not computable.
    """
    if not findings:
        return 100.0
    total = len(findings)
    passing = sum(
        1 for f in findings
        if (getattr(f, "severity", None) or (f.get("severity") if isinstance(f, dict) else "")) in ("info", "low")
    )
    if total == 0:
        return 100.0
    return round((passing / total) * 100, 1)


def _validate_webhook_url(url: str) -> bool:
    """Validate that a webhook URL is safe to POST to (SSRF prevention)."""
    from urllib.parse import urlparse
    import ipaddress as _ipaddress

    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        logger.warning("Webhook rejected: scheme %r not allowed", parsed.scheme)
        return False

    hostname = parsed.hostname or ""
    is_local = hostname in ("localhost", "127.0.0.1", "::1")
    if parsed.scheme == "http" and not is_local:
        logger.warning("Webhook rejected: http not allowed for non-localhost %r", hostname)
        return False

    if not hostname:
        logger.warning("Webhook rejected: no hostname in URL")
        return False

    try:
        ip = _ipaddress.ip_address(hostname)
        if ip.is_private and not is_local:
            logger.warning("Webhook rejected: private IP %s", hostname)
            return False
    except ValueError:
        pass  # hostname, not IP — fine

    return True


def _post_json(url: str, payload: dict, timeout: int = 10) -> bool:
    """POST a JSON payload to a webhook URL. Returns True on success."""
    if not _validate_webhook_url(url):
        return False

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return 200 <= resp.status < 300
    except (urllib.error.URLError, urllib.error.HTTPError, OSError, ValueError) as exc:
        logger.warning("Webhook POST to %s failed: %s", url, exc)
        return False


# ---------------------------------------------------------------------------
# Slack Block Kit message
# ---------------------------------------------------------------------------

def build_slack_payload(
    gate_result: Any,
    findings_summary: list[Any],
) -> dict:
    """Build a Slack Block Kit message payload for a gate failure."""
    severity = _severity_breakdown(gate_result)
    top_rules = _top_failing_rules(findings_summary)
    score = _compliance_score(findings_summary)
    total = getattr(gate_result, "total_findings", 0)

    sev_parts = []
    for level in ("critical", "high", "medium", "low", "info"):
        count = severity.get(level, 0)
        if count > 0:
            sev_parts.append(f"*{level.capitalize()}:* {count}")
    sev_text = "  |  ".join(sev_parts) if sev_parts else "None"

    rules_text = ""
    if top_rules:
        lines = [f"• `{r['rule_id']}` ({r['count']} finding{'s' if r['count'] != 1 else ''})" for r in top_rules]
        rules_text = "\n".join(lines)
    else:
        rules_text = "No critical/high findings by rule."

    blocks: list[dict] = [
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": ":x: SENTRIK Gate Failed",
                "emoji": True,
            },
        },
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": f"*Total findings:* {total}\n{sev_text}",
            },
        },
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": f"*Top failing rules:*\n{rules_text}",
            },
        },
    ]

    if score is not None:
        blocks.append({
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": f"*Compliance score:* {score}%",
            },
        })

    blocks.append({
        "type": "section",
        "text": {
            "type": "mrkdwn",
            "text": ":mag: *View full report* — check the `out/` directory or dashboard for details.",
        },
    })

    return {"blocks": blocks}


def send_slack_notification(
    webhook_url: str,
    gate_result: Any,
    findings_summary: list[Any],
) -> bool:
    """Send a Slack Block Kit message to the given webhook URL.

    Returns True if the message was delivered successfully.
    """
    payload = build_slack_payload(gate_result, findings_summary)
    return _post_json(webhook_url, payload)


# ---------------------------------------------------------------------------
# Microsoft Teams Adaptive Card
# ---------------------------------------------------------------------------

def build_teams_payload(
    gate_result: Any,
    findings_summary: list[Any],
) -> dict:
    """Build a Microsoft Teams Adaptive Card payload for a gate failure."""
    severity = _severity_breakdown(gate_result)
    top_rules = _top_failing_rules(findings_summary)
    score = _compliance_score(findings_summary)
    total = getattr(gate_result, "total_findings", 0)

    sev_parts = []
    for level in ("critical", "high", "medium", "low", "info"):
        count = severity.get(level, 0)
        if count > 0:
            sev_parts.append(f"**{level.capitalize()}:** {count}")
    sev_text = "  |  ".join(sev_parts) if sev_parts else "None"

    rules_lines = []
    if top_rules:
        for r in top_rules:
            rules_lines.append(f"- `{r['rule_id']}` ({r['count']} finding{'s' if r['count'] != 1 else ''})")
    rules_text = "\n".join(rules_lines) if rules_lines else "No critical/high findings by rule."

    body_items: list[dict] = [
        {
            "type": "TextBlock",
            "size": "Large",
            "weight": "Bolder",
            "text": "SENTRIK Gate Failed",
            "color": "Attention",
        },
        {
            "type": "TextBlock",
            "text": f"**Total findings:** {total}",
            "wrap": True,
        },
        {
            "type": "TextBlock",
            "text": sev_text,
            "wrap": True,
        },
        {
            "type": "TextBlock",
            "text": f"**Top failing rules:**\n\n{rules_text}",
            "wrap": True,
        },
    ]

    if score is not None:
        body_items.append({
            "type": "TextBlock",
            "text": f"**Compliance score:** {score}%",
            "wrap": True,
        })

    body_items.append({
        "type": "TextBlock",
        "text": "View full report -- check the `out/` directory or dashboard for details.",
        "wrap": True,
        "isSubtle": True,
    })

    card = {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content": {
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "type": "AdaptiveCard",
                    "version": "1.4",
                    "body": body_items,
                },
            }
        ],
    }
    return card


def send_teams_notification(
    webhook_url: str,
    gate_result: Any,
    findings_summary: list[Any],
) -> bool:
    """Send a Microsoft Teams Adaptive Card to the given webhook URL.

    Returns True if the message was delivered successfully.
    """
    payload = build_teams_payload(gate_result, findings_summary)
    return _post_json(webhook_url, payload)


# ---------------------------------------------------------------------------
# Dispatcher — reads config and sends to the right provider(s)
# ---------------------------------------------------------------------------

def notify_gate_failure(
    config: Any,
    gate_result: Any,
    findings: list[Any],
) -> dict[str, bool]:
    """Dispatch gate-failure notifications based on config.

    Checks ``config.notifications`` dict for webhook URLs and ``notify_on`` list.
    Also checks env vars ``GUARD_SLACK_WEBHOOK_URL`` and ``GUARD_TEAMS_WEBHOOK_URL``.

    Returns a dict like ``{"slack": True, "teams": False}`` indicating delivery status.
    Only sends when the ``gate_failed`` event is in ``notify_on``.
    """
    results: dict[str, bool] = {}

    notif = getattr(config, "notifications", {}) or {}
    if not isinstance(notif, dict):
        notif = {}

    notify_on = notif.get("notify_on", ["gate_failed"])
    if "gate_failed" not in notify_on:
        return results

    # Resolve Slack webhook URL: config → env var
    slack_url = notif.get("slack_webhook_url", "") or os.environ.get("GUARD_SLACK_WEBHOOK_URL", "")
    if slack_url:
        results["slack"] = send_slack_notification(slack_url, gate_result, findings)

    # Resolve Teams webhook URL: config → env var
    teams_url = notif.get("teams_webhook_url", "") or os.environ.get("GUARD_TEAMS_WEBHOOK_URL", "")
    if teams_url:
        results["teams"] = send_teams_notification(teams_url, gate_result, findings)

    return results
