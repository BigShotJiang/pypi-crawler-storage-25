"""Provider factory — builds provider instances from configuration."""

from __future__ import annotations

import logging

from guard.config import GuardConfig
from guard.providers.devops_base import DevOpsProvider
from guard.providers.devops_stub import DevOpsStub
from guard.providers.llm_base import LLMProvider
from guard.providers.llm_stub import LLMStub
from guard.providers.scanners_base import ScannersProvider
from guard.providers.scanners_composite import ScannersComposite
from guard.providers.scanners_llm import ScannersLLM
from guard.providers.scanners_sarif import ScannersSarif
from guard.providers.scanners_stub import ScannersStub
from guard.providers.standards_base import StandardsProvider
from guard.providers.standards_stub import StandardsStub
from guard.rules.engine import RulesEngine

logger = logging.getLogger(__name__)


def build_devops(config: GuardConfig) -> DevOpsProvider:
    """Build the DevOps provider from config."""
    if config.devops_provider == "azure":
        from guard.providers.devops_azure import DevOpsAzure

        return DevOpsAzure(
            org=config.azure_devops_org,
            project=config.azure_devops_project,
            team=config.azure_devops_team,
            iteration=config.azure_devops_iteration,
            work_item_types=config.azure_devops_work_item_types,
        )
    if config.devops_provider == "github":
        from guard.providers.devops_github import DevOpsGitHub

        return DevOpsGitHub(
            owner=config.github_owner,
            repo=config.github_repo,
            label=config.github_label,
            milestone=config.github_milestone,
        )
    if config.devops_provider == "jira":
        from guard.providers.devops_jira import DevOpsJira

        return DevOpsJira(
            base_url=config.jira_base_url,
            project_key=config.jira_project_key,
            jql=config.jira_jql,
            issue_types=config.jira_issue_types,
        )
    return DevOpsStub(config.work_items_file)


def build_standards(config: GuardConfig) -> StandardsProvider:
    """Build the standards provider from config."""
    if config.standards_provider == "azure":
        from guard.providers.standards_azure import StandardsAzure

        return StandardsAzure(
            org=config.azure_devops_org,
            project=config.azure_devops_project,
            repo=config.azure_devops_standards_repo,
            file_path=config.azure_devops_standards_file,
        )
    if config.standards_provider == "github":
        from guard.providers.standards_github import StandardsGitHub

        return StandardsGitHub(
            owner=config.github_owner,
            repo=config.github_standards_repo or config.github_repo,
            file_path=config.github_standards_file,
            ref=config.github_standards_ref,
        )
    if config.standards_provider == "jira":
        from guard.providers.standards_jira import StandardsJira

        return StandardsJira(
            base_url=config.jira_base_url,
            issue_key=config.jira_standards_issue_key,
        )
    return StandardsStub(config.standards_file)


def build_llm(config: GuardConfig) -> LLMProvider:
    """Build the LLM provider from config."""
    model = config.llm_model or None
    base_url = config.llm_base_url or None

    if config.llm_provider == "anthropic":
        from guard.providers.llm_anthropic import LLMAnthropic

        return LLMAnthropic(model=model)

    if config.llm_provider == "openai":
        from guard.providers.llm_openai import LLMOpenAI

        return LLMOpenAI(model=model, base_url=base_url)

    if config.llm_provider == "ollama":
        from guard.providers.llm_ollama import LLMOllama

        return LLMOllama(model=model, base_url=base_url)

    return LLMStub()


def build_scanner(config: GuardConfig, llm: LLMProvider | None = None) -> ScannersProvider:
    """Build the scanner provider from config.

    The ``config.provider`` field drives scanner selection:

    - ``"stub"`` (default) — :class:`ScannersStub` (no-op).
    - ``"sarif"`` — :class:`ScannersSarif` reading ``config.sarif_files``.
    - ``"composite"`` — :class:`ScannersComposite` combining SARIF + LLM
      (when ``llm_enabled``) scanners.

    Legacy behaviour: when ``config.provider`` is ``"stub"`` but
    ``config.llm_enabled`` is True, the LLM scanner is returned directly
    for backwards compatibility with Phase 6 tests.
    """
    provider = config.provider

    if provider == "composite":
        return _build_composite(config, llm)

    if provider == "sarif":
        return ScannersSarif(config.sarif_files)

    # Default "stub" path — preserves Phase 6 LLM behaviour
    if config.llm_enabled and llm is not None:
        return ScannersLLM(llm)
    return ScannersStub()


def _build_composite(config: GuardConfig, llm: LLMProvider | None) -> ScannersProvider:
    """Assemble a composite scanner from config options."""
    scanners: list[ScannersProvider] = []

    if config.sarif_files:
        scanners.append(ScannersSarif(config.sarif_files))

    if config.llm_enabled and llm is not None:
        scanners.append(ScannersLLM(llm))

    if not scanners:
        logger.warning("Composite scanner has no active sub-scanners; falling back to stub.")
        return ScannersStub()

    if len(scanners) == 1:
        return scanners[0]

    return ScannersComposite(scanners)


def _pack_allowed(pack_id: str, license_info, license_key: str) -> bool:
    """Check whether the current license allows loading *pack_id*.

    Tier hierarchy: FREE < TEAM < ORG.
    - FREE tier: only free packs (owasp-top-10, python-security, go-security,
      supply-chain-security, soc2).
    - TEAM+: all free packs + team packs.
    - ORG+: all packs including org-tier packs.
    """
    from guard.packs.registry import is_free_pack, is_org_pack, is_team_pack

    if is_free_pack(pack_id):
        return True  # Always allowed

    if not license_info.valid or license_info.expired:
        return False

    tier = license_info.tier

    if is_team_pack(pack_id):
        # TEAM, ORG, ENTERPRISE, or active TRIAL can access team packs
        return tier in {"TEAM", "ORG", "ENTERPRISE", "TRIAL"}

    if is_org_pack(pack_id):
        # ORG, ENTERPRISE, or active TRIAL can access org packs
        return tier in {"ORG", "ENTERPRISE", "TRIAL"}

    # Unknown pack (custom) — allow if license is valid
    return True


def _load_pack_rules(
    pack_ids: list[str],
    pack_overrides: dict | None = None,
    license_key: str = "",
) -> list[dict]:
    """Load and merge rules from all requested standards packs.

    Packs are gated by tier: FREE users get 5 packs, TEAM gets all
    standard packs, ORG/ENTERPRISE get everything including specialty packs.
    """
    from guard.core.licensing import get_license_info
    from guard.packs.registry import apply_pack_overrides, load_pack_rules, pack_tier

    license_info = get_license_info(license_key)

    all_pack_rules: list[dict] = []
    for pack_id in pack_ids:
        if not _pack_allowed(pack_id, license_info, license_key):
            tier_needed = pack_tier(pack_id)
            logger.warning(
                "Pack %r requires a %s-tier license or higher — skipped. "
                "Run 'sentrik license' for details or visit https://sentrik.dev",
                pack_id, tier_needed,
            )
            continue
        rules = load_pack_rules(pack_id)
        if pack_overrides:
            rules = apply_pack_overrides(rules, pack_id, pack_overrides)
        all_pack_rules.extend(rules)
    return all_pack_rules


def _load_pack_rules_grouped(
    pack_ids: list[str],
    pack_overrides: dict | None = None,
    license_key: str = "",
) -> dict[str, list[dict]]:
    """Load rules grouped by pack ID (for agent-mode scanning)."""
    from guard.core.licensing import get_license_info
    from guard.packs.registry import apply_pack_overrides, load_pack_rules, pack_tier

    license_info = get_license_info(license_key)

    grouped: dict[str, list[dict]] = {}
    for pack_id in pack_ids:
        if not _pack_allowed(pack_id, license_info, license_key):
            tier_needed = pack_tier(pack_id)
            logger.warning(
                "Pack %r requires a %s-tier license or higher — skipped. "
                "Run 'sentrik license' for details or visit https://sentrik.dev",
                pack_id, tier_needed,
            )
            continue
        rules = load_pack_rules(pack_id)
        if pack_overrides:
            rules = apply_pack_overrides(rules, pack_id, pack_overrides)
        grouped[pack_id] = rules
    return grouped


def build_providers(config: GuardConfig):
    """Build all providers from config.

    Returns ``(devops, standards, scanner, rules_engine, llm)``.

    When ``config.agent_scan`` is enabled, ``rules_engine`` is an
    :class:`~guard.core.orchestrator.AgentOrchestrator` that dispatches
    one :class:`~guard.core.agent.ComplianceAgent` per pack in parallel.
    """
    devops = build_devops(config)
    standards = build_standards(config)
    llm = build_llm(config)
    scanner = build_scanner(config, llm)
    user_rules = standards.get_rules()
    max_workers = config.max_workers if config.parallel_scan else 1

    if config.agent_scan:
        from guard.core.agent import ComplianceAgent
        from guard.core.orchestrator import AgentOrchestrator

        # Build drift analyzer if requirements exist and LLM is configured
        drift_analyzer = None
        try:
            from guard.core.drift_analyzer import DriftAnalyzer
            from guard.providers.llm_stub import LLMStub
            # Only use drift analysis with a real LLM, not the stub
            if llm is not None and not isinstance(llm, LLMStub):
                drift_analyzer = DriftAnalyzer(repo_root=".", llm=llm)
                if not drift_analyzer.has_requirements:
                    drift_analyzer = None  # No requirements file found
        except Exception:
            drift_analyzer = None

        agents: list[ComplianceAgent] = []
        # Only the user_rules agent gets drift analysis (avoid duplicate findings)
        if user_rules:
            agents.append(ComplianceAgent(
                "__user_rules__", user_rules, max_workers=max_workers,
                drift_analyzer=drift_analyzer,
            ))
        pack_groups = _load_pack_rules_grouped(
            config.standards_packs, config.pack_overrides, config.license_key,
        )
        for pack_id, rules in pack_groups.items():
            agents.append(ComplianceAgent(pack_id, rules, max_workers=max_workers))
        orchestrator = AgentOrchestrator(agents, config.agent_max_concurrency)
        return devops, standards, scanner, orchestrator, llm

    pack_rules = _load_pack_rules(config.standards_packs, config.pack_overrides, config.license_key)
    all_rules = user_rules + pack_rules
    rules_engine = RulesEngine(all_rules, max_workers=max_workers)
    return devops, standards, scanner, rules_engine, llm
