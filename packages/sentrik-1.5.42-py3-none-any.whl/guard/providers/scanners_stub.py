"""Stub scanner provider — no-op scanner that returns no findings.

Used as the default scanner when no real scanner is configured.
"""

from __future__ import annotations

from guard.core.models import Finding
from guard.providers.scanners_base import ScannersProvider


class ScannersStub(ScannersProvider):
    def scan(self, repo_root: str, changed_files: list[str] | None = None) -> list[Finding]:
        return []
