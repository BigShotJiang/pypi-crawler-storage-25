"""Stub LLM provider — returns deterministic canned responses."""

from __future__ import annotations

from typing import Any

from guard.providers.llm_base import LLMProvider


class LLMStub(LLMProvider):
    def analyze(self, prompt: str, context: dict[str, Any]) -> dict[str, Any]:
        return {
            "findings": [],
            "summary": "LLM analysis is disabled (stub provider).",
            "confidence": 0.0,
        }

    def chat(self, messages: list[dict[str, str]], system: str = "") -> str:
        return "LLM chat is disabled (stub provider)."
