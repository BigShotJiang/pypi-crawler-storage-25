"""Base interface for external scanner providers."""

from __future__ import annotations

from abc import ABC, abstractmethod

from guard.core.models import Finding


class ScannersProvider(ABC):
    @abstractmethod
    def scan(self, repo_root: str, changed_files: list[str] | None = None) -> list[Finding]:
        """Run external scanners and return findings."""
        ...
