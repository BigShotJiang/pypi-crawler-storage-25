"""LLM-augmented scanner — uses an LLM provider for heuristic code analysis."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from guard.core.models import Evidence, Finding, Severity
from guard.core.repo_reader import list_files
from guard.providers.llm_base import LLMProvider
from guard.providers.scanners_base import ScannersProvider

logger = logging.getLogger(__name__)

# Maximum file size (in characters) to send to the LLM.
_MAX_FILE_SIZE = 50_000


class ScannersLLM(ScannersProvider):
    """Scanner that delegates code analysis to an :class:`LLMProvider`.

    Each file matching the glob is sent to the LLM with a prompt asking
    for potential issues.  Findings produced by this scanner carry
    ``deterministic=False`` and a confidence value returned by the LLM.
    """

    def __init__(
        self,
        llm: LLMProvider,
        file_glob: str = "**/*.py",
    ):
        self._llm = llm
        self._file_glob = file_glob

    def scan(
        self,
        repo_root: str,
        changed_files: list[str] | None = None,
    ) -> list[Finding]:
        root = Path(repo_root)
        files = list_files(root, self._file_glob)

        if changed_files is not None:
            changed_set = set(changed_files)
            files = [f for f in files if f in changed_set or f.replace("\\", "/") in changed_set]

        findings: list[Finding] = []
        for rel_path in files:
            abs_path = root / rel_path
            try:
                content = abs_path.read_text(encoding="utf-8")
            except (UnicodeDecodeError, PermissionError, OSError):
                continue

            if len(content) > _MAX_FILE_SIZE:
                content = content[:_MAX_FILE_SIZE]

            file_findings = self._analyze_file(rel_path, content)
            findings.extend(file_findings)

        return findings

    # ------------------------------------------------------------------

    def _analyze_file(self, rel_path: str, content: str) -> list[Finding]:
        """Send *content* to the LLM and parse its response into findings."""
        prompt = (
            "Analyze the following source file for potential issues such as "
            "bugs, security vulnerabilities, code smells, and style problems. "
            "Return a JSON object with a 'findings' list where each item has: "
            "rule_id (str), severity (critical/high/medium/low/info), "
            "message (str), line (int or null), snippet (str or ''), "
            "suggestion (str or null), confidence (float 0-1)."
        )
        context: dict[str, Any] = {
            "file": rel_path,
            "content": content,
        }

        try:
            result = self._llm.analyze(prompt, context)
        except (OSError, ValueError, KeyError):
            logger.warning("LLM analysis failed for %s — skipped", rel_path)
            return []

        raw_findings = result.get("findings", [])
        if not isinstance(raw_findings, list):
            return []

        findings: list[Finding] = []
        for i, raw in enumerate(raw_findings):
            if not isinstance(raw, dict):
                continue
            try:
                sev_str = str(raw.get("severity", "info")).lower()
                if sev_str not in {s.value for s in Severity}:
                    sev_str = "info"

                line = raw.get("line")
                lines = [int(line)] if line is not None else []

                confidence = float(raw.get("confidence", 0.5))
                confidence = max(0.0, min(1.0, confidence))

                findings.append(
                    Finding(
                        finding_id=f"LLM-{rel_path}:{i + 1}",
                        rule_id=str(raw.get("rule_id", "llm-heuristic")),
                        severity=Severity(sev_str),
                        message=str(raw.get("message", "LLM-detected issue")),
                        evidence=Evidence(
                            file=rel_path,
                            lines=lines,
                            snippet=str(raw.get("snippet", "")),
                        ),
                        suggestion=raw.get("suggestion"),
                        confidence=confidence,
                        deterministic=False,
                    )
                )
            except (ValueError, TypeError, KeyError):
                logger.warning("Skipping malformed LLM finding #%d for %s", i, rel_path)

        return findings
