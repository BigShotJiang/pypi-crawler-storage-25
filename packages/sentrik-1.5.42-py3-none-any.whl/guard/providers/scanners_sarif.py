"""SARIF scanner — imports findings from pre-generated SARIF JSON files.

This allows integrating external tools (bandit, semgrep, ESLint, etc.)
by pointing Guard at their SARIF output files.

SARIF spec: https://docs.oasis-open.org/sarif/sarif/v2.1.0/
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from guard.core.models import Evidence, Finding, Severity
from guard.providers.scanners_base import ScannersProvider

logger = logging.getLogger(__name__)

_SARIF_SEVERITY_MAP: dict[str, str] = {
    "error": "high",
    "warning": "medium",
    "note": "low",
    "none": "info",
}


class ScannersSarif(ScannersProvider):
    """Scanner that reads SARIF v2.1.0 JSON files and converts results to findings.

    Parameters
    ----------
    sarif_files:
        List of paths (strings) pointing to SARIF JSON files.
    """

    def __init__(self, sarif_files: list[str]):
        self._sarif_files = [Path(p) for p in sarif_files]

    def scan(
        self,
        repo_root: str,
        changed_files: list[str] | None = None,
    ) -> list[Finding]:
        findings: list[Finding] = []
        changed_set = set(changed_files) if changed_files is not None else None

        for sarif_path in self._sarif_files:
            file_findings = self._read_sarif_file(sarif_path, changed_set)
            findings.extend(file_findings)

        return findings

    # ------------------------------------------------------------------

    def _read_sarif_file(
        self,
        sarif_path: Path,
        changed_set: set[str] | None,
    ) -> list[Finding]:
        """Parse a single SARIF file and return findings."""
        if not sarif_path.exists():
            logger.warning("SARIF file not found: %s", sarif_path)
            return []

        try:
            with open(sarif_path, encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning("Failed to read SARIF file %s: %s", sarif_path, exc)
            return []

        if not isinstance(data, dict):
            logger.warning("SARIF file %s is not a JSON object", sarif_path)
            return []

        runs = data.get("runs", [])
        if not isinstance(runs, list):
            return []

        findings: list[Finding] = []
        for run_idx, run in enumerate(runs):
            if not isinstance(run, dict):
                continue
            tool_name = _extract_tool_name(run)
            results = run.get("results", [])
            if not isinstance(results, list):
                continue
            for res_idx, result in enumerate(results):
                finding = self._convert_result(
                    result, tool_name, run_idx, res_idx, changed_set,
                )
                if finding is not None:
                    findings.append(finding)

        return findings

    def _convert_result(
        self,
        result: dict,
        tool_name: str,
        run_idx: int,
        res_idx: int,
        changed_set: set[str] | None,
    ) -> Finding | None:
        """Convert a single SARIF result to a Finding, or None if skipped."""
        if not isinstance(result, dict):
            return None

        rule_id = result.get("ruleId", f"{tool_name}-{res_idx}")

        # Extract location
        file_path, line = _extract_location(result)

        # Scope check
        if changed_set is not None:
            normalized = file_path.replace("\\", "/")
            if normalized not in changed_set and file_path not in changed_set:
                return None

        # Severity
        level = str(result.get("level", "warning")).lower()
        severity_str = _SARIF_SEVERITY_MAP.get(level, "medium")

        # Message
        message_obj = result.get("message", {})
        if isinstance(message_obj, dict):
            message = message_obj.get("text", f"Issue detected by {tool_name}")
        else:
            message = str(message_obj)

        # Snippet
        snippet = _extract_snippet(result)

        finding_id = f"SARIF-{tool_name}-{run_idx}-{res_idx}"

        return Finding(
            finding_id=finding_id,
            rule_id=str(rule_id),
            severity=Severity(severity_str),
            message=message,
            evidence=Evidence(
                file=file_path,
                lines=[line] if line else [],
                snippet=snippet,
            ),
            suggestion=None,
            confidence=0.9,
            deterministic=True,
        )


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def _extract_tool_name(run: dict) -> str:
    """Extract the tool name from a SARIF run object."""
    tool = run.get("tool", {})
    if isinstance(tool, dict):
        driver = tool.get("driver", {})
        if isinstance(driver, dict):
            return driver.get("name", "unknown-tool")
    return "unknown-tool"


def _extract_location(result: dict) -> tuple[str, int]:
    """Extract file path and line number from a SARIF result.

    Returns ``(file_path, line)`` where *line* may be 0 if unknown.
    """
    locations = result.get("locations", [])
    if not isinstance(locations, list) or not locations:
        return ("unknown", 0)

    loc = locations[0]
    if not isinstance(loc, dict):
        return ("unknown", 0)

    phys = loc.get("physicalLocation", {})
    if not isinstance(phys, dict):
        return ("unknown", 0)

    artifact = phys.get("artifactLocation", {})
    uri = artifact.get("uri", "unknown") if isinstance(artifact, dict) else "unknown"

    region = phys.get("region", {})
    line = 0
    if isinstance(region, dict):
        line = int(region.get("startLine", 0))

    return (uri, line)


def _extract_snippet(result: dict) -> str:
    """Extract a code snippet from the first location's region."""
    locations = result.get("locations", [])
    if not isinstance(locations, list) or not locations:
        return ""

    loc = locations[0]
    if not isinstance(loc, dict):
        return ""

    phys = loc.get("physicalLocation", {})
    if not isinstance(phys, dict):
        return ""

    region = phys.get("region", {})
    if isinstance(region, dict):
        snippet_obj = region.get("snippet", {})
        if isinstance(snippet_obj, dict):
            return snippet_obj.get("text", "")

    return ""
