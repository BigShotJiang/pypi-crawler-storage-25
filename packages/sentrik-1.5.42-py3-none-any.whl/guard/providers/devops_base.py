"""Base interface for DevOps work item providers."""

from __future__ import annotations

from abc import ABC, abstractmethod

from guard.core.models import WorkItem


class DevOpsProvider(ABC):
    @abstractmethod
    def get_work_items(self, ids: list[str] | None = None) -> list[WorkItem]:
        """Retrieve work items, optionally filtered by IDs."""
        ...

    def create_work_item(
        self,
        title: str,
        description: str = "",
        acceptance_criteria: str = "",
        **kw,
    ) -> int | str | None:
        """Create a work item and return its ID, or None on failure."""
        return None

    def update_work_item(self, devops_id: int | str, **kw) -> bool:
        """Update fields on an existing work item. Returns True on success."""
        return False

    def close_work_item(self, devops_id: int | str) -> bool:
        """Close a work item by setting its state to Done. Returns True on success."""
        return False

    def create_pull_request(
        self,
        title: str,
        body: str,
        source_branch: str,
        target_branch: str,
    ) -> dict:
        """Create a pull request and return info dict with pr_id and pr_url.

        Returns an empty dict if the provider does not support PR creation.
        """
        return {}
