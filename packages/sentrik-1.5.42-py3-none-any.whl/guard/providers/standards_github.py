"""GitHub standards provider — fetches rules from a GitHub repository."""

from __future__ import annotations

import logging
import os
import urllib.error
import urllib.request
import json
from base64 import b64decode
from typing import Any

import yaml

from guard.providers.standards_base import StandardsProvider

logger = logging.getLogger(__name__)


class StandardsGitHub(StandardsProvider):
    """Fetches coding-standards YAML from a GitHub repository."""

    def __init__(
        self,
        owner: str,
        repo: str,
        file_path: str = "standards.yaml",
        ref: str = "main",
    ) -> None:
        self._owner = owner
        self._repo = repo
        self._file_path = file_path
        self._ref = ref

    def get_rules(self) -> list[dict[str, Any]]:
        content = self._fetch_file()
        if not content:
            return []
        data = yaml.safe_load(content) or {}
        return data.get("rules", [])

    def get_rule_ids(self) -> list[str]:
        return [r["id"] for r in self.get_rules() if "id" in r]

    def _fetch_file(self) -> str:
        """Fetch file content from GitHub Contents API."""
        encoded_path = urllib.request.quote(self._file_path, safe="/")
        url = (
            f"https://api.github.com/repos/{self._owner}/{self._repo}"
            f"/contents/{encoded_path}?ref={urllib.request.quote(self._ref)}"
        )

        headers: dict[str, str] = {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        token = os.environ.get("GITHUB_TOKEN")
        if token:
            headers["Authorization"] = f"Bearer {token}"

        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                # GitHub returns base64-encoded content
                content_b64 = data.get("content", "")
                return b64decode(content_b64).decode("utf-8")
        except urllib.error.HTTPError as exc:
            logger.error(
                "Failed to fetch standards from GitHub: %s %s",
                exc.code, exc.reason,
            )
            return ""
        except urllib.error.URLError as exc:
            logger.error("Network error fetching standards from GitHub: %s", exc.reason)
            return ""
