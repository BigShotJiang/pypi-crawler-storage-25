"""Jira DevOps provider — fetches work items from Jira Issues."""

from __future__ import annotations

import json
import logging
import os
import re
import urllib.error
import urllib.request
from base64 import b64encode
from typing import Any

from guard.core.models import WorkItem
from guard.providers.devops_base import DevOpsProvider

logger = logging.getLogger(__name__)

_BATCH_SIZE = 50  # Jira REST API max results default

_STATE_MAP: dict[str, str] = {
    "to do": "active",
    "open": "active",
    "in progress": "active",
    "in review": "active",
    "reopened": "active",
    "backlog": "active",
    "selected for development": "active",
    "done": "closed",
    "closed": "closed",
    "resolved": "closed",
    "removed": "removed",
    "cancelled": "removed",
    "won't do": "removed",
    "won't fix": "removed",
}


def _normalize_state(status_name: str | None) -> str:
    """Normalize Jira issue status to guard's state vocabulary."""
    if not status_name:
        return "active"
    return _STATE_MAP.get(status_name.lower(), "active")


def _extract_acceptance_criteria(description: str | None) -> list[str]:
    """Extract acceptance criteria from Jira issue description.

    Looks for a heading containing 'acceptance criteria' (case-insensitive)
    and collects list items beneath it until the next heading or end of text.
    Handles both markdown and Jira wiki markup formats.
    """
    if not description:
        return []
    lines = description.splitlines()
    in_section = False
    items: list[str] = []
    for line in lines:
        stripped = line.strip()
        lower = stripped.lower()
        # Detect heading: markdown (## ...) or Jira wiki (h2. ...)
        if "acceptance criteria" in lower and (
            stripped.startswith("#") or re.match(r"h[1-6]\.", stripped)
        ):
            in_section = True
            continue
        if in_section:
            # Stop at next heading (markdown ## or Jira h2.)
            # But not Jira ordered list items (# item)
            if re.match(r"h[1-6]\.", stripped):
                break
            if stripped.startswith("##"):
                break
            # Collect list items: - item, * item, # item (Jira ordered), numbered
            for prefix in ("- ", "* ", "# "):
                if stripped.startswith(prefix):
                    items.append(stripped[len(prefix):].strip())
                    break
            else:
                # Numbered items (1. item, 2. item, etc.)
                if stripped and stripped[0].isdigit() and ". " in stripped:
                    idx = stripped.index(". ")
                    items.append(stripped[idx + 2:].strip())
    return [i for i in items if i]


def _sanitize_jql(jql: str) -> str:
    """Sanitize a JQL query string to prevent injection.

    Rejects queries containing dangerous characters or keywords that could
    be used for JQL injection (e.g., unbalanced quotes, semicolons, comment
    sequences).  Allowed JQL operators and field names pass through.
    """
    if not jql:
        return jql
    # Reject null bytes
    if "\x00" in jql:
        raise ValueError("JQL contains invalid null bytes")
    # Reject semicolons (statement separator — not valid in JQL)
    if ";" in jql:
        raise ValueError("JQL contains invalid character: ';'")
    # Reject unbalanced quotes (could allow escaping out of a string context)
    single_quotes = jql.count("'") - jql.count("\\'")
    double_quotes = jql.count('"') - jql.count('\\"')
    if single_quotes % 2 != 0 or double_quotes % 2 != 0:
        raise ValueError("JQL contains unbalanced quotes")
    # Reject common injection tokens
    _DANGEROUS_PATTERNS = ["{", "}", "/*", "*/", "--", "\\n", "\\r"]
    lower = jql.lower()
    for pat in _DANGEROUS_PATTERNS:
        if pat in lower:
            raise ValueError(f"JQL contains disallowed pattern: {pat!r}")
    return jql


class DevOpsJira(DevOpsProvider):
    """Fetches work items from Jira Issues via REST API."""

    def __init__(
        self,
        base_url: str,
        project_key: str,
        jql: str = "",
        issue_types: list[str] | None = None,
        access_token: str = "",
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._project_key = project_key
        self._jql = _sanitize_jql(jql)
        self._issue_types = issue_types or []
        self._access_token = access_token
        self._oauth_cloud_id = ""

    def _resolve_oauth(self) -> tuple[str, str]:
        """Try to resolve OAuth token and cloud_id for Jira Cloud.

        Returns (access_token, cloud_id) or ("", "").
        """
        if self._access_token:
            return self._access_token, ""
        try:
            from guard.oauth.manager import OAuthManager, build_oauth_config
            mgr = OAuthManager(build_oauth_config())
            token = mgr.get_token("jira")
            if token and token.access_token:
                return token.access_token, token.cloud_id
        except (ImportError, OSError, ValueError):
            pass
        return "", ""

    def _get_auth_headers(self) -> dict[str, str]:
        """Build request headers with authentication.

        Resolution order:
        1. OAuth token (from stored tokens or explicit access_token)
        2. API token: JIRA_USER + JIRA_TOKEN (Jira Cloud)
        3. Personal access token: JIRA_PAT (Jira Data Center/Server)
        """
        headers: dict[str, str] = {
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

        # 1. OAuth
        oauth_token, cloud_id = self._resolve_oauth()
        if oauth_token:
            headers["Authorization"] = f"Bearer {oauth_token}"
            if cloud_id:
                self._oauth_cloud_id = cloud_id
            return headers

        # 2. Basic auth (Jira Cloud API token)
        user = os.environ.get("JIRA_USER", "")
        token = os.environ.get("JIRA_TOKEN", "")
        pat = os.environ.get("JIRA_PAT", "")

        if user and token:
            credentials = b64encode(f"{user}:{token}".encode()).decode()
            headers["Authorization"] = f"Basic {credentials}"
        elif pat:
            headers["Authorization"] = f"Bearer {pat}"
        return headers

    def _api_base(self) -> str:
        """Return the API base URL.

        When connected via OAuth to Jira Cloud, uses the Atlassian Cloud API
        format: https://api.atlassian.com/ex/jira/{cloud_id}
        Otherwise uses the configured base_url.
        """
        if self._oauth_cloud_id:
            return f"https://api.atlassian.com/ex/jira/{self._oauth_cloud_id}"
        return self._base_url

    def get_work_items(self, ids: list[str] | None = None) -> list[WorkItem]:
        """Retrieve work items by ID (issue key) or by JQL query."""
        if ids is not None:
            return self._fetch_by_keys(ids)
        return self._fetch_by_jql()

    def _fetch_by_keys(self, keys: list[str]) -> list[WorkItem]:
        """Fetch individual issues by their Jira issue keys."""
        results: list[WorkItem] = []
        headers = self._get_auth_headers()
        for key in keys:
            url = f"{self._api_base()}/rest/api/2/issue/{key}"
            try:
                data = self._api_get(url, headers)
                if data:
                    results.append(self._map_issue(data))
            except (urllib.error.URLError, OSError, ValueError, KeyError):
                logger.warning("Failed to fetch Jira issue %s", key)
        return results

    def _fetch_by_jql(self) -> list[WorkItem]:
        """Fetch issues using JQL query."""
        if self._jql:
            jql = self._jql
        else:
            jql = f"project = {self._project_key}"
            if self._issue_types:
                type_list = ", ".join(f'"{t}"' for t in self._issue_types)
                jql += f" AND issuetype IN ({type_list})"
            # Jira sprint = current sprint
            jql += " AND sprint IN openSprints()"
            jql += " ORDER BY created DESC"
        params = urllib.request.quote(jql)
        url = (
            f"{self._api_base()}/rest/api/2/search"
            f"?jql={params}&maxResults={_BATCH_SIZE}"
            f"&fields=summary,description,status"
        )
        headers = self._get_auth_headers()
        data = self._api_get(url, headers)
        if not data or not isinstance(data, dict):
            return []

        issues = data.get("issues", [])
        return [self._map_issue(issue) for issue in issues]

    def _api_get(self, url: str, headers: dict[str, str]) -> Any:
        """Make a GET request to the Jira REST API."""
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            logger.error(
                "Jira API error: %s %s for %s",
                exc.code, exc.reason, url,
            )
            return None
        except urllib.error.URLError as exc:
            logger.error("Network error fetching from Jira: %s", exc.reason)
            return None

    def _api_request(
        self, url: str, headers: dict[str, str], method: str = "POST", data: dict | None = None,
    ) -> Any:
        """Make a POST/PUT request to the Jira REST API.

        Returns parsed JSON, or True for 204 No Content, or None on failure.
        """
        body = json.dumps(data or {}).encode("utf-8") if data else None
        req = urllib.request.Request(url, data=body, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req) as resp:
                if resp.status == 204:
                    return True
                raw = resp.read()
                if not raw:
                    return True
                return json.loads(raw.decode("utf-8"))
        except urllib.error.HTTPError as exc:
            logger.error(
                "Jira API %s error: %s %s for %s",
                method, exc.code, exc.reason, url,
            )
            return None
        except urllib.error.URLError as exc:
            logger.error("Network error in Jira %s: %s", method, exc.reason)
            return None

    # ------------------------------------------------------------------
    # Write operations (create / update / close)
    # ------------------------------------------------------------------

    def create_work_item(
        self,
        title: str,
        description: str = "",
        acceptance_criteria: str = "",
        **kw,
    ) -> int | str | None:
        """Create a Jira issue and return its key (e.g. 'PROJ-42'), or None on failure."""
        headers = self._get_auth_headers()
        url = f"{self._api_base()}/rest/api/2/issue"

        desc_parts: list[str] = []
        if description:
            desc_parts.append(description)
        if acceptance_criteria:
            desc_parts.append(f"\nh2. Acceptance Criteria\n{acceptance_criteria}")

        fields: dict[str, Any] = {
            "project": {"key": self._project_key},
            "summary": title,
            "description": "\n".join(desc_parts),
            "issuetype": {"name": "Task"},
        }
        labels = ["guard"]
        tags = kw.get("tags")
        if tags:
            labels.extend(t.strip() for t in tags.split(",") if t.strip())
        fields["labels"] = labels

        result = self._api_request(url, headers, method="POST", data={"fields": fields})
        if result and isinstance(result, dict) and "key" in result:
            return result["key"]
        return None

    def update_work_item(self, devops_id: int | str, **kw) -> bool:
        """Update a Jira issue. Supports title, description, and tags."""
        headers = self._get_auth_headers()
        url = f"{self._api_base()}/rest/api/2/issue/{devops_id}"

        fields: dict[str, Any] = {}
        if "title" in kw:
            fields["summary"] = kw["title"]
        if "description" in kw:
            fields["description"] = kw["description"]
        if "tags" in kw:
            fields["labels"] = [t.strip() for t in kw["tags"].split(",") if t.strip()]

        if not fields:
            return True  # nothing to update

        result = self._api_request(url, headers, method="PUT", data={"fields": fields})
        return result is not None

    def close_work_item(self, devops_id: int | str) -> bool:
        """Close a Jira issue by transitioning to a 'Done'/'Close'/'Resolve' state."""
        headers = self._get_auth_headers()
        transitions_url = f"{self._api_base()}/rest/api/2/issue/{devops_id}/transitions"

        transitions_data = self._api_get(transitions_url, headers)
        if not transitions_data or not isinstance(transitions_data, dict):
            logger.error("Failed to fetch transitions for %s", devops_id)
            return False

        close_names = {"done", "close", "closed", "resolve", "resolved"}
        transition_id: str | None = None
        for t in transitions_data.get("transitions", []):
            name = (t.get("name") or "").lower()
            to_name = (t.get("to", {}).get("name") or "").lower()
            if name in close_names or to_name in close_names:
                transition_id = t["id"]
                break

        if not transition_id:
            logger.error("No close/done transition found for %s", devops_id)
            return False

        result = self._api_request(
            transitions_url, headers, method="POST",
            data={"transition": {"id": transition_id}},
        )
        return result is not None

    def _map_issue(self, data: dict[str, Any]) -> WorkItem:
        """Map a Jira issue JSON object to a WorkItem."""
        fields = data.get("fields", {})
        description = fields.get("description") or ""
        status_name = ""
        status = fields.get("status")
        if isinstance(status, dict):
            status_name = status.get("name", "")

        # Use first paragraph of description as summary
        desc_lines: list[str] = []
        for line in description.splitlines():
            if not line.strip():
                if desc_lines:
                    break
                continue
            desc_lines.append(line.strip())
        short_desc = " ".join(desc_lines)

        return WorkItem(
            id=data.get("key", ""),
            title=fields.get("summary", ""),
            description=short_desc,
            acceptance_criteria=_extract_acceptance_criteria(description),
            state=_normalize_state(status_name),
        )
