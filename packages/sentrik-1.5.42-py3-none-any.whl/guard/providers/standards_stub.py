"""Stub standards provider — loads rules from a local YAML file."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from guard.providers.standards_base import StandardsProvider


class StandardsStub(StandardsProvider):
    def __init__(self, standards_file: str = "examples/sample_standards.yaml"):
        self._path = Path(standards_file)

    def get_rules(self) -> list[dict[str, Any]]:
        if not self._path.exists():
            return []
        with open(self._path) as f:
            data = yaml.safe_load(f) or {}
        return data.get("rules", [])

    def get_rule_ids(self) -> list[str]:
        return [r["id"] for r in self.get_rules() if "id" in r]
