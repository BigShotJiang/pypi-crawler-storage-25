"""Azure DevOps provider — fetches and manages work items via Azure DevOps Services."""

from __future__ import annotations

import logging
import os
import re
from html.parser import HTMLParser

import requests as _requests_mod

from guard.core.models import WorkItem
from guard.providers.devops_base import DevOpsProvider

logger = logging.getLogger(__name__)

_BATCH_SIZE = 200

# WIQL injection prevention: only allow safe characters in query parameters
_WIQL_SAFE_RE = re.compile(r"^[@\w\s/\\.-]+$")


def _validate_wiql_param(value: str, param_name: str) -> str:
    """Validate a string before interpolation into a WIQL query.

    Allows alphanumeric, spaces, slashes, backslashes, dots, hyphens,
    and the ``@`` prefix (for ``@CurrentIteration``).  Rejects quotes,
    semicolons, and other characters that could alter query semantics.
    """
    if not value:
        return value
    if not _WIQL_SAFE_RE.match(value):
        raise ValueError(
            f"Invalid {param_name} value {value!r} — "
            f"contains characters not allowed in WIQL parameters"
        )
    return value

_STATE_MAP: dict[str, str] = {
    "new": "active",
    "to do": "active",
    "active": "active",
    "doing": "active",
    "resolved": "active",
    "committed": "active",
    "done": "closed",
    "closed": "closed",
    "removed": "removed",
}


class _HTMLTextExtractor(HTMLParser):
    """Strip HTML tags and return plain text."""

    def __init__(self) -> None:
        super().__init__()
        self._parts: list[str] = []

    def handle_data(self, data: str) -> None:
        self._parts.append(data)

    def get_text(self) -> str:
        return "".join(self._parts).strip()


class _HTMLListExtractor(HTMLParser):
    """Extract list items from HTML, handling <li>, <br>, and numbered lists."""

    def __init__(self) -> None:
        super().__init__()
        self._items: list[str] = []
        self._in_li = False
        self._current: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "li":
            self._in_li = True
            self._current = []
        elif tag == "br":
            # <br> outside <li> acts as a separator
            if not self._in_li:
                text = "".join(self._current).strip()
                if text:
                    self._items.append(text)
                self._current = []

    def handle_endtag(self, tag: str) -> None:
        if tag == "li":
            self._in_li = False
            text = "".join(self._current).strip()
            if text:
                self._items.append(text)
            self._current = []

    def handle_data(self, data: str) -> None:
        self._current.append(data)

    def get_items(self) -> list[str]:
        # Flush remaining text
        text = "".join(self._current).strip()
        if text:
            self._items.append(text)
            self._current = []
        return self._items


def _strip_html(html: str | None) -> str:
    """Strip HTML tags and return plain text."""
    if not html:
        return ""
    extractor = _HTMLTextExtractor()
    extractor.feed(html)
    return extractor.get_text()


def _parse_acceptance_criteria(html: str | None) -> list[str]:
    """Parse acceptance criteria from HTML into a list of strings."""
    if not html:
        return []
    extractor = _HTMLListExtractor()
    extractor.feed(html)
    items = extractor.get_items()
    if items:
        # Strip leading numbering like "1. ", "2) ", etc.
        cleaned = []
        for item in items:
            cleaned.append(re.sub(r"^\d+[.)]\s*", "", item).strip())
        return [c for c in cleaned if c]
    # Fallback: just return stripped text as single item
    text = _strip_html(html)
    return [text] if text else []


def _normalize_state(state: str | None) -> str:
    """Normalize Azure DevOps state to guard's state vocabulary."""
    if not state:
        return "active"
    return _STATE_MAP.get(state.lower(), "active")


class DevOpsAzure(DevOpsProvider):
    """Fetches work items from Azure DevOps Services via REST API."""

    def __init__(
        self,
        org: str,
        project: str,
        team: str = "",
        iteration: str = "",
        work_item_types: list[str] | None = None,
        access_token: str = "",
    ) -> None:
        self._org = org
        self._project = project
        self._team = team
        self._iteration = _validate_wiql_param(iteration, "iteration") if iteration else ""
        self._work_item_types = [
            _validate_wiql_param(t, "work_item_type") for t in (work_item_types or [])
        ]
        self._access_token = access_token
        self._client = None

    def _resolve_token(self) -> tuple[str, bool]:
        """Resolve access token: explicit > OAuth store > PAT env var.

        Returns (token, is_bearer) — is_bearer=True for OAuth/Entra tokens,
        False for PATs (which use Basic auth).
        """
        if self._access_token:
            # Explicit tokens: assume Bearer if JWT-shaped
            is_bearer = self._access_token.startswith("eyJ")
            return self._access_token, is_bearer
        # Try stored OAuth token directly (Bearer)
        try:
            from guard.oauth import store as oauth_store
            from guard.oauth.manager import OAuthManager, build_oauth_config
            token_obj = oauth_store.load_token("azure")
            if token_obj and token_obj.access_token:
                if token_obj.is_expired() and token_obj.refresh_token:
                    mgr = OAuthManager(build_oauth_config())
                    refreshed = mgr._refresh("azure", token_obj)
                    if refreshed:
                        oauth_store.save_token(refreshed)
                        return refreshed.access_token, True
                if not token_obj.is_expired():
                    return token_obj.access_token, True
        except (ImportError, OSError, ValueError):
            pass
        # PAT fallback (uses Basic auth)
        pat = os.environ.get("AZURE_DEVOPS_PAT", "")
        return pat, False

    def _get_client(self):
        """Lazily initialise the Azure DevOps work-item tracking client."""
        if self._client is not None:
            return self._client

        try:
            from azure.devops.connection import Connection
            from msrest.authentication import BasicAuthentication
        except ImportError:
            raise ImportError(
                "Azure DevOps SDK is not installed. "
                "Install it with: pip install ai-sdlc-guard[azure]"
            )

        org_url = f"https://dev.azure.com/{self._org}"
        token, is_bearer = self._resolve_token()

        if token and is_bearer:
            # OAuth / Entra ID token — use Bearer authentication
            from azure.devops.credentials import BasicTokenAuthentication
            credentials = BasicTokenAuthentication({"access_token": token})
            connection = Connection(base_url=org_url, creds=credentials)
        elif token:
            # PAT — use Basic authentication
            credentials = BasicAuthentication("", token)
            connection = Connection(base_url=org_url, creds=credentials)
        else:
            try:
                from azure.identity import DefaultAzureCredential

                credential = DefaultAzureCredential()
                from azure.devops.credentials import BasicTokenAuthentication

                az_token = credential.get_token("499b84ac-1321-427f-aa17-267ca6975798/.default")
                credentials = BasicTokenAuthentication({"access_token": az_token.token})
                connection = Connection(base_url=org_url, creds=credentials)
            except ImportError:
                raise ImportError(
                    "No Azure DevOps credentials available. "
                    "Connect via OAuth in the dashboard, set AZURE_DEVOPS_PAT, "
                    "or install azure-identity."
                )

        self._client = connection.clients.get_work_item_tracking_client()
        return self._client

    def get_work_items(self, ids: list[str] | None = None) -> list[WorkItem]:
        """Retrieve work items by ID or by iteration query."""
        client = self._get_client()

        if ids is not None:
            return self._fetch_by_ids(client, [int(i) for i in ids])

        return self._fetch_by_iteration(client)

    def _fetch_by_ids(self, client, int_ids: list[int]) -> list[WorkItem]:
        """Fetch work items by their numeric IDs in batches."""
        results: list[WorkItem] = []
        for start in range(0, len(int_ids), _BATCH_SIZE):
            batch = int_ids[start : start + _BATCH_SIZE]
            raw_items = client.get_work_items(
                ids=batch,
                project=self._project,
                fields=[
                    "System.Id",
                    "System.Title",
                    "System.Description",
                    "System.State",
                    "Microsoft.VSTS.Common.AcceptanceCriteria",
                ],
            )
            results.extend(self._map_items(raw_items))
        return results

    def _fetch_by_iteration(self, client) -> list[WorkItem]:
        """Run a WIQL query scoped to the configured iteration."""
        iteration = self._iteration or "@CurrentIteration"

        from azure.devops.v7_1.work_item_tracking.models import Wiql

        try:
            from azure.devops.v7_1.work_item_tracking.models import TeamContext
        except ImportError:
            from azure.devops.v7_0.work_item_tracking.models import TeamContext

        # @CurrentIteration macro requires a team context — fall back to all
        # active items when neither team nor explicit iteration is configured.
        if iteration == "@CurrentIteration" and not self._team:
            logger.info(
                "No team or iteration configured — fetching all active work items"
            )
            wiql_query = (
                "SELECT [System.Id] FROM WorkItems "
                "WHERE [System.State] <> 'Removed'"
            )
            if self._work_item_types:
                type_list = ", ".join(f"'{t}'" for t in self._work_item_types)
                wiql_query += f" AND [System.WorkItemType] IN ({type_list})"
            team_context = TeamContext(project=self._project)
            wiql = Wiql(query=wiql_query)
            try:
                result = client.query_by_wiql(wiql, team_context=team_context)
            except Exception as exc:
                raise RuntimeError(
                    f"WIQL query failed: {exc}. "
                    "Check your Azure DevOps project configuration."
                ) from exc
            if not result.work_items:
                return []
            wi_ids = [wi.id for wi in result.work_items]
            return self._fetch_by_ids(client, wi_ids)

        if iteration == "@CurrentIteration" and self._team:
            team_context = TeamContext(project=self._project, team=self._team)
        else:
            team_context = TeamContext(project=self._project)

        wiql_query = (
            "SELECT [System.Id] FROM WorkItems "
            f"WHERE [System.IterationPath] UNDER '{iteration}' "
            "AND [System.State] <> 'Removed'"
        )
        if self._work_item_types:
            type_list = ", ".join(f"'{t}'" for t in self._work_item_types)
            wiql_query += f" AND [System.WorkItemType] IN ({type_list})"

        wiql = Wiql(query=wiql_query)
        try:
            result = client.query_by_wiql(wiql, team_context=team_context)
        except Exception as exc:
            msg = str(exc)
            if iteration == "@CurrentIteration":
                raise RuntimeError(
                    f"WIQL query with @CurrentIteration failed: {msg}. "
                    f"Team '{self._team}' may not have an active iteration configured. "
                    "Check your team's iteration settings in Azure DevOps, or use a "
                    "specific iteration path (e.g. 'MyProject\\Sprint 1')."
                ) from exc
            else:
                raise RuntimeError(
                    f"WIQL query for iteration '{iteration}' failed: {msg}. "
                    "Check that the iteration path is correct in Azure DevOps."
                ) from exc

        if not result.work_items:
            return []

        wi_ids = [wi.id for wi in result.work_items]
        return self._fetch_by_ids(client, wi_ids)

    def _map_items(self, raw_items) -> list[WorkItem]:
        """Map Azure DevOps work item objects to guard WorkItem models."""
        items: list[WorkItem] = []
        for raw in raw_items:
            fields = raw.fields or {}
            wi_id = fields.get("System.Id", raw.id)
            title = fields.get("System.Title", "")
            # Extract rule_id from reconcile-created titles like "[IEC62304-CODE-001] ..."
            rule_id = None
            m = re.match(r"^\[([A-Za-z0-9._-]+)\]\s", title)
            if m:
                rule_id = m.group(1)
            items.append(WorkItem(
                id=str(wi_id),
                title=title,
                description=_strip_html(fields.get("System.Description")),
                acceptance_criteria=_parse_acceptance_criteria(
                    fields.get("Microsoft.VSTS.Common.AcceptanceCriteria")
                ),
                state=_normalize_state(fields.get("System.State")),
                rule_id=rule_id,
                devops_id=int(wi_id) if isinstance(wi_id, int) else wi_id,
            ))
        return items

    # ------------------------------------------------------------------
    # Write operations (create / update / close)
    # ------------------------------------------------------------------

    def _rest_base(self) -> tuple[str, str, bool]:
        """Return (base_url, token, is_bearer) for REST API calls."""
        token, is_bearer = self._resolve_token()
        base = f"https://dev.azure.com/{self._org}/{self._project}"
        return base, token, is_bearer

    def _rest_request_kwargs(self, token: str, is_bearer: bool) -> dict:
        """Build auth kwargs for requests library calls."""
        headers = {"Content-Type": "application/json-patch+json"}
        if is_bearer:
            headers["Authorization"] = f"Bearer {token}"
            return {"headers": headers}
        else:
            return {"headers": headers, "auth": ("", token)}

    def create_work_item(
        self,
        title: str,
        description: str = "",
        acceptance_criteria: str = "",
        **kw,
    ) -> int | None:
        base, token, is_bearer = self._rest_base()
        if not token:
            logger.warning("No Azure DevOps credentials — cannot create work item")
            return None

        wi_type = kw.get("work_item_type", "Issue")
        url = f"{base}/_apis/wit/workitems/${wi_type}?api-version=7.1"
        patch_doc: list[dict] = [
            {"op": "add", "path": "/fields/System.Title", "value": title},
        ]
        if description:
            patch_doc.append(
                {"op": "add", "path": "/fields/System.Description", "value": description},
            )
        if acceptance_criteria:
            patch_doc.append(
                {"op": "add", "path": "/fields/Microsoft.VSTS.Common.AcceptanceCriteria",
                 "value": acceptance_criteria},
            )
        tags = kw.get("tags")
        if tags:
            patch_doc.append(
                {"op": "add", "path": "/fields/System.Tags", "value": tags},
            )
        iteration = kw.get("iteration") or self._iteration
        if iteration:
            patch_doc.append(
                {"op": "add", "path": "/fields/System.IterationPath", "value": iteration},
            )

        try:
            kwargs = self._rest_request_kwargs(token, is_bearer)
            resp = _requests_mod.post(url, json=patch_doc, timeout=30, **kwargs)
            if resp.status_code in (200, 201):
                return resp.json().get("id")
            logger.error("Create work item failed (%s): %s", resp.status_code, resp.text)
        except (_requests_mod.RequestException, OSError):
            logger.exception("Create work item request failed")
        return None

    def update_work_item(self, devops_id: int, **kw) -> bool:
        base, token, is_bearer = self._rest_base()
        if not token:
            logger.warning("No Azure DevOps credentials — cannot update work item")
            return False

        url = f"{base}/_apis/wit/workitems/{devops_id}?api-version=7.1"
        patch_doc: list[dict] = []
        field_map = {
            "title": "System.Title",
            "description": "System.Description",
            "acceptance_criteria": "Microsoft.VSTS.Common.AcceptanceCriteria",
            "state": "System.State",
            "tags": "System.Tags",
        }
        for key, field in field_map.items():
            if key in kw:
                patch_doc.append(
                    {"op": "replace", "path": f"/fields/{field}", "value": kw[key]},
                )
        if not patch_doc:
            return True  # nothing to update

        try:
            kwargs = self._rest_request_kwargs(token, is_bearer)
            resp = _requests_mod.patch(url, json=patch_doc, timeout=30, **kwargs)
            if resp.status_code == 200:
                return True
            logger.error("Update work item %d failed (%s): %s", devops_id, resp.status_code, resp.text)
        except (_requests_mod.RequestException, OSError):
            logger.exception("Update work item request failed")
        return False

    def close_work_item(self, devops_id: int) -> bool:
        return self.update_work_item(devops_id, state="Done")

    def create_pull_request(
        self,
        title: str,
        body: str,
        source_branch: str,
        target_branch: str,
    ) -> dict:
        """Create a pull request in Azure DevOps.

        Returns dict with ``pr_id`` and ``pr_url``, or empty dict on failure.
        """
        base, token, is_bearer = self._rest_base()
        if not token:
            logger.warning("No Azure DevOps credentials — cannot create PR")
            return {}

        # Use explicitly configured repo name, fall back to project name
        repo_name = getattr(self, "_azure_repo", None) or self._project

        url = (
            f"{base}/_apis/git/repositories/{repo_name}"
            f"/pullrequests?api-version=7.1"
        )
        payload = {
            "sourceRefName": f"refs/heads/{source_branch}",
            "targetRefName": f"refs/heads/{target_branch}",
            "title": title,
            "description": body,
        }
        headers = {"Content-Type": "application/json"}
        if is_bearer:
            headers["Authorization"] = f"Bearer {token}"
            kwargs: dict = {"headers": headers}
        else:
            kwargs = {"headers": headers, "auth": ("", token)}

        try:
            resp = _requests_mod.post(url, json=payload, timeout=30, **kwargs)
            if resp.status_code in (200, 201):
                data = resp.json()
                pr_id = data.get("pullRequestId")
                pr_url = (
                    f"https://dev.azure.com/{self._org}/{self._project}"
                    f"/_git/{repo_name}/pullrequest/{pr_id}"
                )
                return {"pr_id": pr_id, "pr_url": pr_url}
            logger.error(
                "Create PR failed (%s): %s", resp.status_code, resp.text,
            )
        except (_requests_mod.RequestException, OSError):
            logger.exception("Create PR request failed")
        return {}

    def get_available_work_item_types(self) -> list[str]:
        """Query Azure DevOps for work item types available in the project."""
        base, token, is_bearer = self._rest_base()
        if not token:
            return []
        url = f"{base}/_apis/wit/workitemtypes?api-version=7.1"
        headers = {"Accept": "application/json"}
        if is_bearer:
            headers["Authorization"] = f"Bearer {token}"
            kwargs: dict = {"headers": headers}
        else:
            kwargs = {"headers": headers, "auth": ("", token)}
        try:
            resp = _requests_mod.get(url, timeout=15, **kwargs)
            if resp.status_code == 200:
                data = resp.json()
                return sorted(
                    item["name"] for item in data.get("value", [])
                    if not item.get("isDisabled", False)
                )
        except (_requests_mod.RequestException, OSError, ValueError):
            logger.exception("Failed to fetch work item types")
        return []
