"""Composite scanner — aggregates findings from multiple scanner providers."""

from __future__ import annotations

import logging
from typing import Sequence

from guard.core.models import Finding
from guard.providers.scanners_base import ScannersProvider

logger = logging.getLogger(__name__)


class ScannersComposite(ScannersProvider):
    """Runs multiple :class:`ScannersProvider` instances and merges findings.

    Duplicate findings (same ``finding_id``) are removed — the first
    occurrence wins.  Scanners that raise are logged and skipped so a
    single failing scanner does not abort the entire run.
    """

    def __init__(self, scanners: Sequence[ScannersProvider]):
        self._scanners = list(scanners)

    @property
    def scanners(self) -> list[ScannersProvider]:
        return list(self._scanners)

    def scan(
        self,
        repo_root: str,
        changed_files: list[str] | None = None,
    ) -> list[Finding]:
        all_findings: list[Finding] = []
        seen_ids: set[str] = set()

        for scanner in self._scanners:
            try:
                findings = scanner.scan(repo_root, changed_files)
            except (OSError, ValueError, KeyError):
                logger.warning(
                    "Scanner %s raised an exception — skipped",
                    type(scanner).__name__,
                )
                continue

            for f in findings:
                if f.finding_id not in seen_ids:
                    seen_ids.add(f.finding_id)
                    all_findings.append(f)

        return all_findings
