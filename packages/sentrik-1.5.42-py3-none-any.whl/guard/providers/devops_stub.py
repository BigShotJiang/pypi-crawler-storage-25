"""Stub DevOps provider — loads work items from a local JSON file."""

from __future__ import annotations

import json
from pathlib import Path

from guard.core.models import WorkItem
from guard.providers.devops_base import DevOpsProvider


class DevOpsStub(DevOpsProvider):
    def __init__(self, work_items_file: str = "examples/sample_work_items.json"):
        self._path = Path(work_items_file)

    def get_work_items(self, ids: list[str] | None = None) -> list[WorkItem]:
        if not self._path.exists():
            return []
        with open(self._path) as f:
            raw = json.load(f)
        items = [WorkItem(**wi) for wi in raw]
        if ids is not None:
            items = [wi for wi in items if wi.id in ids]
        return items
