"""Base interface for LLM providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class LLMProvider(ABC):
    @abstractmethod
    def analyze(self, prompt: str, context: dict[str, Any]) -> dict[str, Any]:
        """Send a prompt with context to the LLM and return structured results."""
        ...

    def chat(self, messages: list[dict[str, str]], system: str = "") -> str:
        """Send a multi-turn conversation and return the assistant's text reply.

        *messages* is a list of ``{"role": "user"|"assistant", "content": "..."}``.
        *system* is an optional system prompt.

        The default implementation concatenates everything into a single
        ``analyze()`` call — concrete providers should override for a
        proper multi-turn experience.
        """
        parts: list[str] = []
        if system:
            parts.append(f"[System]\n{system}")
        for m in messages:
            role = m.get("role", "user").capitalize()
            parts.append(f"[{role}]\n{m.get('content', '')}")
        combined = "\n\n".join(parts)
        result = self.analyze(combined, {"file": "(chat)", "content": ""})
        return result.get("summary", "")
