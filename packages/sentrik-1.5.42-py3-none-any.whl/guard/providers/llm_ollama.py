"""Ollama LLM provider for local model inference."""

from __future__ import annotations

import json
import logging
import os
from typing import Any

from guard.providers.llm_base import LLMProvider

logger = logging.getLogger(__name__)

_DEFAULT_MODEL = "llama3"
_DEFAULT_BASE_URL = "http://localhost:11434"


class LLMOllama(LLMProvider):
    """LLM provider that calls a local Ollama server."""

    def __init__(
        self,
        model: str | None = None,
        base_url: str | None = None,
    ) -> None:
        self._model = model or os.environ.get("OLLAMA_MODEL", _DEFAULT_MODEL)
        self._base_url = (
            base_url or os.environ.get("OLLAMA_BASE_URL", _DEFAULT_BASE_URL)
        ).rstrip("/")

    def analyze(self, prompt: str, context: dict[str, Any]) -> dict[str, Any]:
        import requests as _requests

        user_message = (
            f"{prompt}\n\nFile: {context.get('file', '(unknown)')}"
            f"\n\n```\n{context.get('content', '')}\n```"
        )

        body = {
            "model": self._model,
            "prompt": user_message,
            "stream": False,
            "format": "json",
        }

        try:
            resp = _requests.post(
                f"{self._base_url}/api/generate",
                json=body,
                timeout=120,
            )
        except _requests.RequestException as exc:
            logger.warning("Ollama request failed: %s", exc)
            return {"findings": [], "summary": f"Ollama error: {exc}", "confidence": 0.0}

        if resp.status_code != 200:
            logger.warning("Ollama returned %d: %s", resp.status_code, resp.text[:200])
            return {"findings": [], "summary": f"Ollama error ({resp.status_code})", "confidence": 0.0}

        data = resp.json()
        text = data.get("response", "")
        return self._parse_response(text)

    def chat(self, messages: list[dict[str, str]], system: str = "") -> str:
        """Multi-turn chat via Ollama's chat API."""
        import requests as _requests

        api_messages: list[dict[str, str]] = []
        if system:
            api_messages.append({"role": "system", "content": system})
        api_messages.extend({"role": m["role"], "content": m["content"]} for m in messages)

        body = {
            "model": self._model,
            "messages": api_messages,
            "stream": False,
        }

        try:
            resp = _requests.post(
                f"{self._base_url}/api/chat",
                json=body,
                timeout=120,
            )
        except _requests.RequestException as exc:
            return f"Error communicating with Ollama: {exc}"

        if resp.status_code != 200:
            return f"Ollama error ({resp.status_code}): {resp.text[:200]}"

        data = resp.json()
        return data.get("message", {}).get("content", "")

    @staticmethod
    def _parse_response(text: str) -> dict[str, Any]:
        start = text.find("{")
        end = text.rfind("}") + 1
        if start == -1 or end == 0:
            return {"findings": [], "summary": text[:500], "confidence": 0.0}
        try:
            result = json.loads(text[start:end])
        except json.JSONDecodeError:
            return {"findings": [], "summary": text[:500], "confidence": 0.0}
        if "findings" not in result:
            result["findings"] = []
        return result
