"""Base interface for coding standards providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class StandardsProvider(ABC):
    @abstractmethod
    def get_rules(self) -> list[dict[str, Any]]:
        """Return a list of rule definitions."""
        ...

    @abstractmethod
    def get_rule_ids(self) -> list[str]:
        """Return all available rule IDs."""
        ...
