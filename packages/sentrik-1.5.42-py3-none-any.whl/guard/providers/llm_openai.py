"""OpenAI-compatible LLM provider for AI-augmented code scanning."""

from __future__ import annotations

import json
import logging
import os
from typing import Any

from guard.providers.llm_base import LLMProvider

logger = logging.getLogger(__name__)

_DEFAULT_MODEL = "gpt-4o-mini"


class LLMOpenAI(LLMProvider):
    """LLM provider that calls the OpenAI Chat Completions API.

    Also works with any OpenAI-compatible endpoint (Azure OpenAI, Together, etc.)
    by setting ``base_url``.
    """

    def __init__(
        self,
        model: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
    ) -> None:
        self._model = model or os.environ.get("OPENAI_MODEL", _DEFAULT_MODEL)
        self._api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self._base_url = (
            base_url
            or os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1")
        ).rstrip("/")
        # When using a local proxy (e.g. VS Code Copilot proxy), no real API key
        # is required — the proxy ignores the Authorization header entirely.
        if not self._api_key and "api.openai.com" not in self._base_url:
            self._api_key = "proxy-no-key-required"

    def analyze(self, prompt: str, context: dict[str, Any]) -> dict[str, Any]:
        if not self._api_key:
            logger.warning("OPENAI_API_KEY not set — returning empty results")
            return {"findings": [], "summary": "No API key configured.", "confidence": 0.0}

        import requests as _requests

        user_message = (
            f"{prompt}\n\nFile: {context.get('file', '(unknown)')}"
            f"\n\n```\n{context.get('content', '')}\n```"
        )

        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }
        body = {
            "model": self._model,
            "max_tokens": 4096,
            "messages": [{"role": "user", "content": user_message}],
            "temperature": 0,
        }

        try:
            resp = _requests.post(
                f"{self._base_url}/chat/completions",
                json=body,
                headers=headers,
                timeout=120,
            )
        except _requests.RequestException as exc:
            logger.warning("OpenAI API request failed: %s", exc)
            return {"findings": [], "summary": f"API error: {exc}", "confidence": 0.0}

        if resp.status_code != 200:
            logger.warning("OpenAI API returned %d: %s", resp.status_code, resp.text[:200])
            return {"findings": [], "summary": f"API error ({resp.status_code})", "confidence": 0.0}

        data = resp.json()
        text = data.get("choices", [{}])[0].get("message", {}).get("content", "")
        return self._parse_response(text)

    def chat(self, messages: list[dict[str, str]], system: str = "") -> str:
        """Multi-turn chat via the OpenAI Chat Completions API."""
        if not self._api_key:
            return "Error: OPENAI_API_KEY not set. Please configure your API key."

        import requests as _requests

        api_messages: list[dict[str, str]] = []
        if system:
            api_messages.append({"role": "system", "content": system})
        api_messages.extend({"role": m["role"], "content": m["content"]} for m in messages)

        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }
        body = {
            "model": self._model,
            "max_tokens": 4096,
            "messages": api_messages,
            "temperature": 0,
        }

        try:
            resp = _requests.post(
                f"{self._base_url}/chat/completions",
                json=body,
                headers=headers,
                timeout=120,
            )
        except _requests.RequestException as exc:
            return f"Error communicating with OpenAI API: {exc}"

        if resp.status_code != 200:
            return f"OpenAI API error ({resp.status_code}): {resp.text[:200]}"

        data = resp.json()
        return data.get("choices", [{}])[0].get("message", {}).get("content", "")

    @staticmethod
    def _parse_response(text: str) -> dict[str, Any]:
        start = text.find("{")
        end = text.rfind("}") + 1
        if start == -1 or end == 0:
            return {"findings": [], "summary": text[:500], "confidence": 0.0}
        try:
            result = json.loads(text[start:end])
        except json.JSONDecodeError:
            return {"findings": [], "summary": text[:500], "confidence": 0.0}
        if "findings" not in result:
            result["findings"] = []
        return result
