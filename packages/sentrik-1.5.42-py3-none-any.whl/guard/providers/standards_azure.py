"""Azure DevOps standards provider — fetches rules from an Azure DevOps repo."""

from __future__ import annotations

import logging
import os
import urllib.request
import urllib.error
from typing import Any
from base64 import b64encode

import yaml

from guard.providers.standards_base import StandardsProvider

logger = logging.getLogger(__name__)


class StandardsAzure(StandardsProvider):
    """Fetches coding-standards YAML from an Azure DevOps Git repository."""

    def __init__(
        self,
        org: str,
        project: str,
        repo: str,
        file_path: str = "standards.yaml",
    ) -> None:
        self._org = org
        self._project = project
        self._repo = repo
        self._file_path = file_path

    def get_rules(self) -> list[dict[str, Any]]:
        content = self._fetch_file()
        if not content:
            return []
        data = yaml.safe_load(content) or {}
        return data.get("rules", [])

    def get_rule_ids(self) -> list[str]:
        return [r["id"] for r in self.get_rules() if "id" in r]

    def _fetch_file(self) -> str:
        """Fetch file content from Azure DevOps Git Items API."""
        _quote = urllib.request.quote
        encoded_org = _quote(self._org, safe="")
        encoded_project = _quote(self._project, safe="")
        encoded_repo = _quote(self._repo, safe="")
        encoded_path = _quote(self._file_path, safe="/")
        url = (
            f"https://dev.azure.com/{encoded_org}/{encoded_project}"
            f"/_apis/git/repositories/{encoded_repo}"
            f"/items?path={encoded_path}&api-version=7.1"
        )

        req = urllib.request.Request(url)
        req.add_header("Accept", "application/octet-stream")

        pat = os.environ.get("AZURE_DEVOPS_PAT")
        if pat:
            token = b64encode(f":{pat}".encode()).decode()
            req.add_header("Authorization", f"Basic {token}")
        else:
            try:
                from azure.identity import DefaultAzureCredential

                credential = DefaultAzureCredential()
                token = credential.get_token(
                    "499b84ac-1321-427f-aa17-267ca6975798/.default"
                )
                req.add_header("Authorization", f"Bearer {token.token}")
            except ImportError:
                raise ImportError(
                    "Neither AZURE_DEVOPS_PAT is set nor azure-identity is installed. "
                    "Set the AZURE_DEVOPS_PAT env var or install azure-identity."
                )

        try:
            with urllib.request.urlopen(req) as resp:
                return resp.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            logger.error(
                "Failed to fetch standards from Azure DevOps: %s %s",
                exc.code,
                exc.reason,
            )
            return ""
        except urllib.error.URLError as exc:
            logger.error("Network error fetching standards: %s", exc.reason)
            return ""
