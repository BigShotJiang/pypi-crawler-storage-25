"""GitHub DevOps provider — fetches work items from GitHub Issues."""

from __future__ import annotations

import logging
import os
import urllib.error
import urllib.request
import json
from typing import Any

from guard.core.models import WorkItem
from guard.providers.devops_base import DevOpsProvider

logger = logging.getLogger(__name__)

_BATCH_SIZE = 100  # GitHub API max per_page

_STATE_MAP: dict[str, str] = {
    "open": "active",
    "closed": "closed",
}


def _normalize_state(state: str | None) -> str:
    """Normalize GitHub issue state to guard's state vocabulary."""
    if not state:
        return "active"
    return _STATE_MAP.get(state.lower(), "active")


def _extract_acceptance_criteria(body: str | None) -> list[str]:
    """Extract acceptance criteria from issue body markdown.

    Looks for a section headed '## Acceptance Criteria' (case-insensitive)
    and collects bullet/numbered list items beneath it until the next
    heading or end of text.
    """
    if not body:
        return []
    lines = body.splitlines()
    in_section = False
    items: list[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped.lower().startswith("## acceptance criteria"):
            in_section = True
            continue
        if in_section:
            # Stop at next heading
            if stripped.startswith("##"):
                break
            # Collect list items (- item, * item, 1. item)
            for prefix in ("- ", "* ", "1. ", "2. ", "3. ", "4. ", "5. ",
                           "6. ", "7. ", "8. ", "9. ", "0. "):
                if stripped.startswith(prefix):
                    items.append(stripped[len(prefix):].strip())
                    break
            else:
                # Numbered items beyond single digit
                if stripped and stripped[0].isdigit() and ". " in stripped:
                    idx = stripped.index(". ")
                    items.append(stripped[idx + 2:].strip())
    return [i for i in items if i]


class DevOpsGitHub(DevOpsProvider):
    """Fetches work items from GitHub Issues via REST API."""

    def __init__(
        self,
        owner: str,
        repo: str,
        label: str = "",
        milestone: str = "",
        access_token: str = "",
    ) -> None:
        self._owner = owner
        self._repo = repo
        self._label = label
        self._milestone = milestone
        self._access_token = access_token

    def _resolve_token(self) -> str:
        """Resolve access token: explicit > OAuth > env var."""
        if self._access_token:
            return self._access_token
        try:
            from guard.oauth.manager import OAuthManager, build_oauth_config
            mgr = OAuthManager(build_oauth_config())
            token = mgr.get_access_token("github")
            if token:
                return token
        except (ImportError, OSError, ValueError):
            pass
        return os.environ.get("GITHUB_TOKEN", "")

    def _get_headers(self) -> dict[str, str]:
        """Build request headers with authentication."""
        headers: dict[str, str] = {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        token = self._resolve_token()
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    def get_work_items(self, ids: list[str] | None = None) -> list[WorkItem]:
        """Retrieve work items by ID or by label/milestone query."""
        if ids is not None:
            return self._fetch_by_ids(ids)
        return self._fetch_by_query()

    def _fetch_by_ids(self, ids: list[str]) -> list[WorkItem]:
        """Fetch individual issues by their numeric IDs."""
        results: list[WorkItem] = []
        headers = self._get_headers()
        for issue_id in ids:
            url = (
                f"https://api.github.com/repos/{self._owner}/{self._repo}"
                f"/issues/{issue_id}"
            )
            try:
                data = self._api_get(url, headers)
                if data:
                    results.append(self._map_issue(data))
            except (urllib.error.URLError, OSError, ValueError, KeyError):
                logger.warning("Failed to fetch GitHub issue %s", issue_id)
        return results

    def _fetch_by_query(self) -> list[WorkItem]:
        """Fetch issues by label and/or milestone."""
        params: list[str] = ["state=all", f"per_page={_BATCH_SIZE}"]
        if self._label:
            params.append(f"labels={urllib.request.quote(self._label)}")
        if self._milestone:
            params.append(f"milestone={urllib.request.quote(self._milestone)}")

        query = "&".join(params)
        url = (
            f"https://api.github.com/repos/{self._owner}/{self._repo}"
            f"/issues?{query}"
        )
        headers = self._get_headers()
        data = self._api_get(url, headers)
        if not data or not isinstance(data, list):
            return []

        results: list[WorkItem] = []
        for item in data:
            # Skip pull requests (GitHub API returns PRs in issues endpoint)
            if "pull_request" in item:
                continue
            results.append(self._map_issue(item))
        return results

    def _api_get(self, url: str, headers: dict[str, str]) -> Any:
        """Make a GET request to the GitHub API."""
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            logger.error(
                "GitHub API error: %s %s for %s",
                exc.code, exc.reason, url,
            )
            return None
        except urllib.error.URLError as exc:
            logger.error("Network error fetching from GitHub: %s", exc.reason)
            return None

    def _api_request(
        self, url: str, headers: dict[str, str], method: str = "POST", data: dict | None = None,
    ) -> Any:
        """Make a POST/PATCH request to the GitHub API."""
        body = json.dumps(data or {}).encode("utf-8")
        req = urllib.request.Request(url, data=body, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            logger.error(
                "GitHub API %s error: %s %s for %s",
                method, exc.code, exc.reason, url,
            )
            return None
        except urllib.error.URLError as exc:
            logger.error("Network error in GitHub %s: %s", method, exc.reason)
            return None

    # ------------------------------------------------------------------
    # Write operations (create / update / close)
    # ------------------------------------------------------------------

    def create_work_item(
        self,
        title: str,
        description: str = "",
        acceptance_criteria: str = "",
        **kw,
    ) -> int | str | None:
        """Create a GitHub issue and return its number, or None on failure."""
        headers = self._get_headers()
        headers["Content-Type"] = "application/json"
        url = f"https://api.github.com/repos/{self._owner}/{self._repo}/issues"

        body_parts: list[str] = []
        if description:
            body_parts.append(description)
        if acceptance_criteria:
            body_parts.append(f"\n## Acceptance Criteria\n{acceptance_criteria}")

        payload: dict[str, Any] = {
            "title": title,
            "body": "\n".join(body_parts),
            "labels": ["guard"],
        }
        tags = kw.get("tags")
        if tags:
            extra_labels = [t.strip() for t in tags.split(",") if t.strip()]
            payload["labels"] = payload["labels"] + extra_labels

        result = self._api_request(url, headers, method="POST", data=payload)
        if result and "number" in result:
            return result["number"]
        return None

    def update_work_item(self, devops_id: int | str, **kw) -> bool:
        """Update a GitHub issue. Supports title, description, state, tags."""
        headers = self._get_headers()
        headers["Content-Type"] = "application/json"
        url = (
            f"https://api.github.com/repos/{self._owner}/{self._repo}"
            f"/issues/{devops_id}"
        )

        payload: dict[str, Any] = {}
        if "title" in kw:
            payload["title"] = kw["title"]
        if "description" in kw:
            payload["body"] = kw["description"]
        if "state" in kw:
            # Map guard states to GitHub: "closed" → "closed", anything else → "open"
            gh_state = "closed" if kw["state"].lower() in ("closed", "done") else "open"
            payload["state"] = gh_state
        if "tags" in kw:
            payload["labels"] = [t.strip() for t in kw["tags"].split(",") if t.strip()]

        if not payload:
            return True  # nothing to update

        result = self._api_request(url, headers, method="PATCH", data=payload)
        return result is not None

    def close_work_item(self, devops_id: int | str) -> bool:
        """Close a GitHub issue."""
        return self.update_work_item(devops_id, state="closed")

    def create_pull_request(
        self,
        title: str,
        body: str,
        source_branch: str,
        target_branch: str,
    ) -> dict:
        """Create a pull request on GitHub.

        Returns dict with ``pr_id`` and ``pr_url``, or empty dict on failure.
        """
        headers = self._get_headers()
        headers["Content-Type"] = "application/json"
        url = (
            f"https://api.github.com/repos/{self._owner}/{self._repo}/pulls"
        )
        payload = {
            "title": title,
            "body": body,
            "head": source_branch,
            "base": target_branch,
        }
        result = self._api_request(url, headers, method="POST", data=payload)
        if result:
            return {
                "pr_id": result.get("number"),
                "pr_url": result.get("html_url", ""),
            }
        return {}

    def _map_issue(self, data: dict[str, Any]) -> WorkItem:
        """Map a GitHub issue JSON object to a WorkItem."""
        body = data.get("body") or ""
        # Use first paragraph of body as description (up to blank line)
        desc_lines: list[str] = []
        for line in body.splitlines():
            if not line.strip():
                if desc_lines:
                    break
                continue
            desc_lines.append(line.strip())
        description = " ".join(desc_lines)

        return WorkItem(
            id=str(data.get("number", "")),
            title=data.get("title", ""),
            description=description,
            acceptance_criteria=_extract_acceptance_criteria(body),
            state=_normalize_state(data.get("state")),
        )
