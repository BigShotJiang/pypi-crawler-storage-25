"""Jira standards provider — fetches rules from a Jira issue description."""

from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request
from base64 import b64encode
from typing import Any

import yaml

from guard.providers.standards_base import StandardsProvider

logger = logging.getLogger(__name__)


class StandardsJira(StandardsProvider):
    """Fetches coding-standards YAML from a Jira issue description field.

    The issue description should contain a YAML code block with the
    standards rules, e.g.::

        ```yaml
        rules:
          - id: STD-001
            ...
        ```

    Alternatively, the entire description can be raw YAML.
    """

    def __init__(
        self,
        base_url: str,
        issue_key: str,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._issue_key = issue_key

    def get_rules(self) -> list[dict[str, Any]]:
        content = self._fetch_standards()
        if not content:
            return []
        data = yaml.safe_load(content) or {}
        return data.get("rules", [])

    def get_rule_ids(self) -> list[str]:
        return [r["id"] for r in self.get_rules() if "id" in r]

    def _fetch_standards(self) -> str:
        """Fetch the issue description and extract YAML content."""
        url = (
            f"{self._base_url}/rest/api/2/issue/{self._issue_key}"
            f"?fields=description"
        )
        headers: dict[str, str] = {
            "Accept": "application/json",
        }
        user = os.environ.get("JIRA_USER", "")
        token = os.environ.get("JIRA_TOKEN", "")
        pat = os.environ.get("JIRA_PAT", "")

        if user and token:
            credentials = b64encode(f"{user}:{token}".encode()).decode()
            headers["Authorization"] = f"Basic {credentials}"
        elif pat:
            headers["Authorization"] = f"Bearer {pat}"

        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                description = (data.get("fields") or {}).get("description") or ""
                return _extract_yaml(description)
        except urllib.error.HTTPError as exc:
            logger.error(
                "Failed to fetch standards from Jira: %s %s",
                exc.code, exc.reason,
            )
            return ""
        except urllib.error.URLError as exc:
            logger.error("Network error fetching standards from Jira: %s", exc.reason)
            return ""


def _extract_yaml(text: str) -> str:
    """Extract YAML content from text.

    If the text contains a ```yaml code block, extract that.
    Otherwise, return the full text (assumes raw YAML).
    """
    # Look for ```yaml ... ``` fenced code block
    lines = text.splitlines()
    in_block = False
    yaml_lines: list[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("```yaml") or stripped.startswith("```yml"):
            in_block = True
            continue
        if in_block:
            if stripped == "```":
                break
            yaml_lines.append(line)

    if yaml_lines:
        return "\n".join(yaml_lines)
    # No code block found — return raw text
    return text
