"""CLI entry point for AI SDLC Guard."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import typer

from guard.cli_output import (
    SEV_STYLES,
    compliance_score_panel,
    console,
    gate_result_panel,
    print_error,
    print_error_context,
    print_header,
    print_hint,
    print_post_hint,
    print_success,
    print_warning,
    rules_table,
    scan_summary_table,
    top_files_table,
    top_findings_table,
    traceability_table,
    suggest_suppressions,
    compliance_file_map,
)
from guard.core.error_helper import get_error_context
from guard.config import GuardConfig
from guard.core.comparison import compare_runs, load_findings, render_comparison
from guard.core.context_builder import build_agent_context
from guard.core.diff_parser import extract_changed_files_from_diff, get_changed_files_from_range, get_staged_files
from guard.core.governance import AuditLog, PolicyEngine, build_governance_config
from guard.core.models import WorkItem
from guard.core.patcher import apply_patches as do_apply_patches
from guard.core.pipeline import build_autofix_map, build_replacement_map, calculate_compliance_score, export_audit_bundle, get_current_run_id, list_historical_runs, load_historical_findings, load_historical_metadata, run_scan_and_write
from guard.core.reconciler import execute_reconcile, reconcile as compute_reconcile_actions
from guard.core.repo_reader import find_repo_root
from guard.core.traceability import get_current_branch
from guard.packs.registry import (
    is_known_pack,
    list_available_packs,
    load_pack_rules,
    import_pack as registry_import_pack,
    export_pack as registry_export_pack,
    validate_pack_yaml,
)
from guard.providers.factory import build_providers, _load_pack_rules
from guard.reporters.factory import build_reporters

def _version_callback(value: bool) -> None:
    if value:
        from guard import __version__
        typer.echo(f"sentrik {__version__}")
        raise typer.Exit()


def _app_callback(
    version: bool = typer.Option(False, "--version", "-V", callback=_version_callback, is_eager=True, help="Print version and exit."),
) -> None:
    pass


app = typer.Typer(
    help="SENTRIK — governance runtime for AI coding agents.",
    rich_markup_mode="rich",
    no_args_is_help=True,
    callback=_app_callback,
)


@app.command()
def version():
    """Print the SENTRIK version."""
    from guard import __version__
    typer.echo(f"sentrik {__version__}")


def _load_config(config_path: str | None) -> tuple:
    """Load config, returning (config, profile) where profile is set only when auto-detected."""
    path = Path(config_path) if config_path else None
    try:
        config = GuardConfig.load(path)
    except Exception as exc:
        print_error(f"Failed to load config: {exc}")
        config = GuardConfig()
    profile = None

    # If no config file exists on disk and no explicit path was given,
    # auto-detect the project and apply sensible defaults in memory.
    if config_path is None:
        from guard.config import resolve_config_path
        resolved = resolve_config_path(None)
        if resolved is None or not resolved.exists():
            from guard.core.auto_detect import detect_project
            profile = detect_project()
            config = GuardConfig.from_profile(profile)
    return config, profile


def _build_providers(config: GuardConfig):
    devops, standards, scanner, rules_engine, _llm = build_providers(config)
    return devops, standards, scanner, rules_engine


def _warn_project_mismatch(config: GuardConfig) -> None:
    """Warn if the configured DevOps project doesn't match the local git repo name."""
    from guard.core.repo_reader import get_git_repo_name

    if config.devops_provider == "stub":
        return
    local_name = get_git_repo_name()
    if not local_name:
        return
    local_lower = local_name.lower()
    remote = ""
    if config.devops_provider == "azure" and config.azure_devops_project:
        remote = config.azure_devops_project
    elif config.devops_provider == "github" and config.github_repo:
        remote = config.github_repo
    elif config.devops_provider == "jira" and config.jira_project_key:
        remote = config.jira_project_key
    if remote and remote.lower() != local_lower:
        typer.echo(
            f"  Warning: local git repo '{local_name}' does not match "
            f"{config.devops_provider} project '{remote}'. "
            f"Verify you are syncing to the correct project.",
            err=True,
        )


def _resolve_changed_files(
    git_range: str | None, diff: str | None, repo_root: str,
    staged: bool = False,
) -> list[str] | None:
    """Resolve changed files from --staged, --git-range, or --diff flags (mutually exclusive)."""
    flags_set = sum(bool(x) for x in [git_range, diff, staged])
    if flags_set > 1:
        ctx = get_error_context("mutually_exclusive_flags")
        if ctx:
            print_error_context(ctx)
        else:
            typer.echo("Error: --staged, --git-range, and --diff are mutually exclusive.", err=True)
        raise typer.Exit(1)
    if staged:
        files = get_staged_files(repo_root)
        typer.echo(f"Scope: {len(files)} staged file(s)")
        return files
    if git_range:
        files = get_changed_files_from_range(git_range, repo_root)
        typer.echo(f"Scope: {len(files)} file(s) from git range {git_range}")
        return files
    if diff:
        files = extract_changed_files_from_diff(diff)
        typer.echo(f"Scope: {len(files)} file(s) from provided diff")
        return files
    return None


def _warn_license_expiry(config):
    """Show warning if license expires within 7 days (online or offline)."""
    from guard.core.licensing import get_license_info, check_license_online
    from datetime import date

    info = get_license_info(config.license_key)
    days_remaining = None

    # Try online check if enabled
    if config.online_license_check and config.license_key:
        online = check_license_online(config.license_key, config.portal_url)
        if online.checked and online.days_remaining > 0:
            days_remaining = online.days_remaining

    # Fall back to offline expiry
    if days_remaining is None and info.expiry:
        days_remaining = (info.expiry - date.today()).days

    if days_remaining is not None and 0 < days_remaining <= 7:
        typer.echo(f"\n  WARNING: License expires in {days_remaining} day(s). Renew at {config.portal_url}/license")


def _generate_trial_key_file() -> str | None:
    """Generate a 30-day ENTERPRISE trial key and store it in .sentrik/local/license.key.

    Returns the key string, or None if a key already exists.
    """
    from guard.core.licensing import generate_trial_key

    key_path = Path(".sentrik") / "local" / "license.key"
    if key_path.exists() and key_path.read_text(encoding="utf-8").strip():
        return None  # already has a key

    key_path.parent.mkdir(parents=True, exist_ok=True)
    key = generate_trial_key(days=30)
    key_path.write_text(key + "\n", encoding="utf-8")
    return key


_MODE_PRESETS: dict[str, dict] = {
    "developer": {
        "gate_fail_on": ["critical"],
        "severity_rescoring_enabled": True,
        "parallel_scan": True,
        "scan_exclude": ["tests/", "docs/", "*.md"],
        "governance": {"profile": "permissive"},
    },
    "compliance": {
        "gate_fail_on": ["critical", "high"],
        "severity_rescoring_enabled": True,
        "parallel_scan": True,
        "agent_scan": True,
        "governance": {"profile": "strict", "human_review_required": {"on_critical_finding": True}},
    },
    "ci": {
        "gate_fail_on": ["critical", "high"],
        "parallel_scan": True,
        "agent_scan": True,
        "governance": {"profile": "standard"},
    },
}


@app.command(rich_help_panel="Core")
def init(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    interactive: bool = typer.Option(True, "--interactive/--no-interactive", help="Run guided setup wizard."),
    mode: str = typer.Option(None, "--mode", "-m", help="Config preset: developer, compliance, or ci."),
):
    """Initialize project config (creates .sentrik/ directory)."""
    if not interactive:
        from guard.core.auto_detect import detect_project
        from guard.config import ensure_sentrik_dir

        profile = detect_project()
        config = GuardConfig.from_profile(profile)

        # Apply mode preset
        if mode and mode in _MODE_PRESETS:
            preset = _MODE_PRESETS[mode]
            for k, v in preset.items():
                setattr(config, k, v)
            typer.echo(f"  Mode: {mode}")
        elif mode:
            typer.echo(f"  Unknown mode '{mode}'. Available: {', '.join(_MODE_PRESETS)}")

        ensure_sentrik_dir()
        path = config.save(Path(config_path) if config_path else None)
        trial_key = _generate_trial_key_file()
        typer.echo(f"Initialized config at {path}")
        if profile.languages:
            typer.echo(f"  Detected: {', '.join(profile.languages)}")
        if profile.suggested_packs:
            typer.echo(f"  Packs: {', '.join(profile.suggested_packs)}")
        if profile.ci_platform:
            typer.echo(f"  CI: {profile.ci_platform}")
        if trial_key:
            typer.echo("  Trial:  30-day Enterprise trial activated (all features unlocked)")
        return

    _run_init_wizard(config_path)


def _detect_project_context() -> dict:
    """Scan CWD for filesystem clues and return detection hints."""
    hints: dict[str, str | None] = {"platform": None, "language": None, "project_type": None}
    cwd = Path(".")

    # Platform detection
    if (cwd / "azure-pipelines.yml").exists():
        hints["platform"] = "azure"
    elif (cwd / ".github").is_dir():
        hints["platform"] = "github"

    # Language detection
    if any((cwd / f).exists() for f in ("pyproject.toml", "setup.py", "requirements.txt")):
        hints["language"] = "python"
    elif (cwd / "package.json").exists():
        hints["language"] = "node"

    # Project type detection from README
    for readme_name in ("README.md", "README.rst", "README.txt", "README"):
        readme = cwd / readme_name
        if readme.exists():
            try:
                text = readme.read_text(encoding="utf-8", errors="ignore").upper()
                if any(kw in text for kw in ("IEC 62304", "MEDICAL DEVICE", "FDA")):
                    hints["project_type"] = "2"
                elif any(kw in text for kw in ("SOC2", "SOC 2")):
                    hints["project_type"] = "3"
            except OSError:
                pass
            break

    return hints


def _create_precommit_config() -> bool:
    """Create a .pre-commit-config.yaml with a sentrik scan hook. Returns True if created."""
    path = Path(".pre-commit-config.yaml")
    if path.exists():
        print_warning(".pre-commit-config.yaml already exists — skipping.")
        return False
    path.write_text(
        "repos:\n"
        "  - repo: local\n"
        "    hooks:\n"
        "      - id: sentrik-scan\n"
        "        name: SENTRIK scan\n"
        "        entry: sentrik pre-commit-scan\n"
        "        language: system\n"
        "        pass_filenames: false\n"
        "        stages: [pre-commit]\n",
        encoding="utf-8",
    )
    return True


def _create_env_example(provider: str) -> bool:
    """Create a .env.example with placeholder credentials. Returns True if created."""
    path = Path(".env.example")
    if path.exists():
        return False
    lines: list[str] = []
    if provider == "azure":
        lines.append("AZURE_DEVOPS_PAT=your-personal-access-token")
    elif provider == "github":
        lines.append("GITHUB_TOKEN=your-personal-access-token")
    elif provider == "jira":
        lines.append("JIRA_USER=your-email@example.com")
        lines.append("JIRA_TOKEN=your-api-token")
    if not lines:
        return False
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return True


def _run_init_wizard(config_path: str | None) -> None:
    """Interactive setup wizard for guard init."""
    from guard.config import ensure_sentrik_dir
    from guard.core.auto_detect import detect_project

    typer.echo("\n  SENTRIK — Setup Wizard\n")

    # Auto-detect project context (new auto_detect module)
    profile = detect_project()
    detected = _detect_project_context()

    if profile.languages:
        typer.echo(f"  Auto-detected: {', '.join(profile.languages)}")
        if profile.ci_platform:
            typer.echo(f"  CI platform: {profile.ci_platform}")
        typer.echo("")

    # Step 1: DevOps platform
    platform_default = "1"
    platform_hint = ""
    if detected.get("platform") == "azure":
        platform_default = "2"
        platform_hint = " (detected: Azure DevOps)"
    elif detected.get("platform") == "github":
        platform_default = "3"
        platform_hint = " (detected: GitHub)"
    typer.echo(f"Step 1/5: DevOps Platform{platform_hint}")
    typer.echo("  [1] None (local/stub)")
    typer.echo("  [2] Azure DevOps")
    typer.echo("  [3] GitHub")
    typer.echo("  [4] Jira")
    platform_choice = typer.prompt("  Select platform", default=platform_default)

    platform_map = {"1": "stub", "2": "azure", "3": "github", "4": "jira"}
    devops_provider = platform_map.get(platform_choice, "stub")

    config_data: dict = {"devops_provider": devops_provider}

    if devops_provider == "azure":
        config_data["azure_devops_org"] = typer.prompt("  Azure DevOps organization")
        config_data["azure_devops_project"] = typer.prompt("  Azure DevOps project")
        config_data["azure_devops_team"] = typer.prompt("  Azure DevOps team (optional)", default="")
    elif devops_provider == "github":
        config_data["github_owner"] = typer.prompt("  GitHub owner (user or org)")
        config_data["github_repo"] = typer.prompt("  GitHub repository")
    elif devops_provider == "jira":
        config_data["jira_base_url"] = typer.prompt("  Jira base URL (e.g. https://jira.example.com)")
        config_data["jira_project_key"] = typer.prompt("  Jira project key (e.g. PROJ)")

    # Step 2: Project type -> suggest packs
    project_default = detected.get("project_type") or "1"
    typer.echo("\nStep 2/5: Project Type")
    typer.echo("  [1] General / Web application")
    typer.echo("  [2] Medical device software (IEC 62304)")
    typer.echo("  [3] Enterprise / SOC2 compliance")
    typer.echo("  [4] All packs")
    typer.echo("  [5] None (custom rules only)")
    project_choice = typer.prompt("  Select project type", default=project_default)

    pack_map = {
        "1": ["owasp-top-10"],
        "2": ["fda-iec-62304", "owasp-top-10"],
        "3": ["soc2", "owasp-top-10"],
        "4": ["fda-iec-62304", "owasp-top-10", "soc2"],
        "5": [],
    }
    packs = pack_map.get(project_choice, [])
    if packs:
        config_data["standards_packs"] = packs
        typer.echo(f"  Enabling packs: {', '.join(packs)}")

    # Step 3: Governance profile
    typer.echo("\nStep 3/5: Governance Profile")
    typer.echo("  [1] Standard — balanced defaults (recommended)")
    typer.echo("  [2] Strict — human review for all changes, tighter gates")
    typer.echo("  [3] Permissive — minimal friction, maximum agent autonomy")
    gov_choice = typer.prompt("  Select profile", default="1")

    gov_map = {"1": "standard", "2": "strict", "3": "permissive"}
    gov_profile = gov_map.get(gov_choice, "standard")
    config_data["governance"] = {"profile": gov_profile}

    # Step 4: Output settings
    typer.echo("\nStep 4/5: Output Settings")
    output_dir = typer.prompt("  Output directory", default="out")
    config_data["output_dir"] = output_dir

    reporters_input = typer.prompt("  Report formats (comma-separated: html,junit,sarif)", default="html")
    reporters = [r.strip() for r in reporters_input.split(",") if r.strip()]
    if reporters:
        config_data["reporters"] = reporters

    # Step 5: Pre-commit hook
    typer.echo("\nStep 5/5: Pre-commit Hook")
    precommit_created = False
    if typer.confirm("  Install a pre-commit hook to scan on every commit?", default=False):
        precommit_created = _create_precommit_config()
        if precommit_created:
            print_success("  Created .pre-commit-config.yaml")

    # Build and save — create .sentrik/ directory
    config = GuardConfig(**config_data)
    ensure_sentrik_dir()
    path = config.save(Path(config_path) if config_path else None)

    # Generate 30-day trial key
    trial_key = _generate_trial_key_file()

    # Create .env.example for credential guidance
    _create_env_example(devops_provider)

    # Rich summary panel
    from rich.panel import Panel

    summary_lines = [
        f"  Config:       {path}",
        f"  DevOps:       {devops_provider}",
        f"  Packs:        {', '.join(packs) if packs else 'none'}",
        f"  Governance:   {gov_profile}",
        f"  Output:       {output_dir}",
        f"  Pre-commit:   {'installed' if precommit_created else 'skipped'}",
        f"  Trial:        {'30-day Enterprise trial activated' if trial_key else 'existing key preserved'}",
    ]
    console.print(Panel("\n".join(summary_lines), title="Setup Complete", border_style="green"))

    # Credential hint based on platform — show both shell syntaxes
    _cred_hints = {
        "azure": (
            "Azure DevOps",
            "AZURE_DEVOPS_PAT",
            "your-personal-access-token",
            "In Azure Pipelines, add this as a secret variable",
        ),
        "github": (
            "GitHub",
            "GITHUB_TOKEN",
            "your-personal-access-token",
            "In GitHub Actions, use ${{ secrets.GITHUB_TOKEN }}",
        ),
        "jira": (
            "Jira",
            "JIRA_USER",
            None,  # handled specially below
            "Or use JIRA_PAT for Data Center/Server",
        ),
    }
    hint = _cred_hints.get(devops_provider)
    if hint:
        label, var, _val, ci_note = hint
        typer.echo(f"\n  Before running scans, set your {label} credentials:")
        if devops_provider == "jira":
            typer.echo(f'    Bash:       export JIRA_USER="<your-email>" JIRA_TOKEN="<your-token>"')
            typer.echo(f'    PowerShell: $env:JIRA_USER = "<your-email>"; $env:JIRA_TOKEN = "<your-token>"')
        else:
            typer.echo(f'    Bash:       export {var}="{_val}"')
            typer.echo(f'    PowerShell: $env:{var} = "{_val}"')
        typer.echo(f"    ({ci_note})")

    typer.echo("\n  Community & support:")
    typer.echo("    Docs:    https://docs.sentrik.dev")
    typer.echo("    GitHub:  https://github.com/maxgerhardson/sentrik")

    print_post_hint("init")


@app.command(rich_help_panel="Admin")
def migrate():
    """Migrate .guard.yaml -> .sentrik/config.yaml."""
    from guard.config import CONFIG_FILENAME, SENTRIK_CONFIG_FILENAME, ensure_sentrik_dir

    old_path = Path(CONFIG_FILENAME)
    new_path = Path(SENTRIK_CONFIG_FILENAME)

    if not old_path.exists():
        typer.echo(f"No {CONFIG_FILENAME} found — nothing to migrate.")
        raise typer.Exit(0)

    if new_path.exists():
        typer.echo(f"{SENTRIK_CONFIG_FILENAME} already exists — aborting to avoid overwrite.")
        raise typer.Exit(1)

    ensure_sentrik_dir()

    import shutil
    shutil.copy2(str(old_path), str(new_path))
    typer.echo(f"Copied {CONFIG_FILENAME} -> {SENTRIK_CONFIG_FILENAME}")
    typer.echo(f"You can now remove {CONFIG_FILENAME} if desired.")
    print_post_hint("migrate")


@app.command(rich_help_panel="Core")
def context(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
):
    """Generate agent_context.json for the AI coding agent."""
    config, _profile = _load_config(config_path)
    devops, standards, _, _ = _build_providers(config)
    repo_root = str(find_repo_root())

    ctx = build_agent_context(repo_root, config, devops, standards)

    out = Path(config.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    ctx_path = out / "agent_context.json"
    with open(ctx_path, "w") as f:
        json.dump(ctx.model_dump(), f, indent=2)

    typer.echo(f"Wrote {ctx_path}")
    print_post_hint("context")


@app.command(rich_help_panel="Core")
def scan(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    git_range: str = typer.Option(None, "--git-range", help="Git range for scoping (e.g. HEAD~1..HEAD)."),
    diff: str = typer.Option(None, "--diff", help="Raw unified diff text for scoping."),
    staged: bool = typer.Option(False, "--staged", help="Scope to git-staged files only."),
    files: list[str] = typer.Option(None, "--files", "-f", help="Specific file or folder paths to scan."),
    branch: str = typer.Option(None, "--branch", help="Branch name for work-item traceability (auto-detected if omitted)."),
    actionable_only: bool = typer.Option(False, "--actionable-only", help="Only show findings with auto-fix or remediation guidance."),
):
    """Run a scan and write findings, report, and next actions."""
    config, _profile = _load_config(config_path)

    # Show auto-detected project info when no config file was found
    if _profile is not None:
        langs = " · ".join(_profile.languages) if _profile.languages else "unknown"
        ci = _profile.ci_platform or "none"
        packs = ", ".join(_profile.suggested_packs) if _profile.suggested_packs else "none"
        typer.echo(f"Detected: {langs} · CI: {ci} · Packs: {packs}")

    _, standards, scanner, rules_engine = _build_providers(config)
    repo_root = str(find_repo_root())

    changed_files = _resolve_changed_files(git_range, diff, repo_root, staged=staged)

    # --files flag: resolve explicit file/folder paths to a file list
    if files:
        import glob as globmod
        resolved_files: list[str] = []
        for f in files:
            f = f.replace("\\", "/")
            abs_f = os.path.join(repo_root, f) if not os.path.isabs(f) else f
            if os.path.isdir(abs_f):
                for walk_root, _dirs, fnames in os.walk(abs_f):
                    for fname in fnames:
                        full = os.path.join(walk_root, fname)
                        resolved_files.append(os.path.relpath(full, repo_root).replace("\\", "/"))
            elif os.path.isfile(abs_f):
                resolved_files.append(os.path.relpath(abs_f, repo_root).replace("\\", "/"))
            else:
                for match in globmod.glob(abs_f, recursive=True):
                    if os.path.isfile(match):
                        resolved_files.append(os.path.relpath(match, repo_root).replace("\\", "/"))
        typer.echo(f"Scope: {len(resolved_files)} file(s) from --files")
        changed_files = resolved_files if resolved_files else changed_files

    resolved_branch = branch or get_current_branch()
    rules = standards.get_rules() + _load_pack_rules(config.standards_packs, license_key=config.license_key)
    autofix_map = build_autofix_map(rules)
    replacement_map = build_replacement_map(rules)
    # Progress bar for interactive terminals
    progress_callback = None
    _progress = None
    if console.is_terminal:
        from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
        _progress = Progress(
            SpinnerColumn(), TextColumn("[bold]{task.description}"),
            BarColumn(), TextColumn("{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console,
        )
        _task_id = None

        def _make_callback(prog, tid_ref):
            def cb(phase, pct):
                if tid_ref[0] is None:
                    tid_ref[0] = prog.add_task("Scanning...", total=100)
                prog.update(tid_ref[0], completed=int(pct * 100), description=phase)
            return cb

        _tid_ref = [None]
        progress_callback = _make_callback(_progress, _tid_ref)
        _progress.start()

    try:
        findings, gate, out = run_scan_and_write(
            repo_root, config, rules_engine, scanner, command="scan",
            changed_files=changed_files, branch=resolved_branch,
            autofix_map=autofix_map, replacement_map=replacement_map,
            progress_callback=progress_callback,
        )
    finally:
        if _progress is not None:
            _progress.stop()

    # License expiry warning
    _warn_license_expiry(config)

    # Rich scan summary
    print_header("Scan Complete")
    by_sev: dict[str, int] = {}
    finding_dicts: list[dict] = []
    for f in findings:
        d = f.model_dump() if hasattr(f, "model_dump") else {}
        finding_dicts.append(d)
        sev = f.severity.value if hasattr(f.severity, "value") else str(f.severity)
        by_sev[sev] = by_sev.get(sev, 0) + 1

    # Filter display when --actionable-only
    display_dicts = finding_dicts
    if actionable_only:
        display_dicts = [
            d for d in finding_dicts
            if d.get("suggestion") or d.get("remediation_guidance")
        ]
        if len(display_dicts) < len(finding_dicts):
            typer.echo(f"  Showing {len(display_dicts)} actionable of {len(finding_dicts)} total findings\n")

    scan_summary_table(by_sev)
    compliance = calculate_compliance_score(findings, len(rules))
    compliance_score_panel(compliance)
    top_files_table(display_dicts)
    top_findings_table(display_dicts)
    print_success(f"{len(findings)} finding(s) written to {out}/")

    # Audit log: record scan event
    try:
        gov = config.get_governance()
        audit_log = AuditLog(gov.audit)
        audit_log.log("scan", details={
            "findings_count": len(findings),
            "compliance_score": compliance.get("percentage", 0),
            "rules_evaluated": len(rules),
            "output_dir": str(out),
        })
    except Exception:
        pass  # Audit logging should never break the scan

    # Smart hint with context
    autofixable = sum(1 for d in finding_dicts if d.get("suggestion"))
    print_post_hint("scan", context={
        "findings_count": len(findings),
        "autofixable_count": autofixable,
    })


@app.command(rich_help_panel="Core")
def gate(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    git_range: str = typer.Option(None, "--git-range", help="Git range for scoping (e.g. HEAD~1..HEAD)."),
    diff: str = typer.Option(None, "--diff", help="Raw unified diff text for scoping."),
    staged: bool = typer.Option(False, "--staged", help="Scope to git-staged files only."),
    branch: str = typer.Option(None, "--branch", help="Branch name for work-item traceability (auto-detected if omitted)."),
    decorate_pr: bool = typer.Option(False, "--decorate-pr", help="Post findings summary as a PR comment."),
    pr_number: int = typer.Option(None, "--pr-number", help="PR number for decoration (auto-detected in CI)."),
    status_check: bool = typer.Option(False, "--status-check", help="Create a PR status check (check-run / commit status)."),
    commit_sha: str = typer.Option(None, "--commit-sha", help="Commit SHA for status check (auto-detected in CI)."),
    require_approval: bool = typer.Option(False, "--require-approval", help="Block on async approval when gate fails (requires async_approval enabled)."),
    approval_timeout: int = typer.Option(None, "--approval-timeout", help="Seconds to wait for approval before timing out."),
):
    """Run scan and enforce gate — exits 0 (pass) or 1 (fail)."""
    config, _profile = _load_config(config_path)
    _, standards, scanner, rules_engine = _build_providers(config)
    repo_root = str(find_repo_root())

    changed_files = _resolve_changed_files(git_range, diff, repo_root, staged=staged)
    resolved_branch = branch or get_current_branch()
    rules = standards.get_rules() + _load_pack_rules(config.standards_packs, license_key=config.license_key)
    autofix_map = build_autofix_map(rules)
    replacement_map = build_replacement_map(rules)
    findings, gate_result, out = run_scan_and_write(
        repo_root, config, rules_engine, scanner, command="gate",
        changed_files=changed_files, branch=resolved_branch,
        autofix_map=autofix_map, replacement_map=replacement_map,
    )

    # Build finding dicts and hint context for smart post-command hints
    finding_dicts: list[dict] = []
    for f in findings:
        d = f.model_dump() if hasattr(f, "model_dump") else {}
        finding_dicts.append(d)

    # Count top rule IDs for failed gate hint
    _rule_counts: dict[str, int] = {}
    for d in finding_dicts:
        if d.get("severity") in ("critical", "high"):
            rid = d.get("rule_id", "unknown")
            _rule_counts[rid] = _rule_counts.get(rid, 0) + 1
    _top_rules = sorted(_rule_counts, key=lambda r: _rule_counts[r], reverse=True)[:3]
    _autofixable = sum(1 for d in finding_dicts if d.get("suggestion"))

    gate_counts = {
        "critical": gate_result.critical, "high": gate_result.high,
        "medium": gate_result.medium, "low": gate_result.low, "info": gate_result.info,
    }

    # Compliance score
    compliance = calculate_compliance_score(findings, len(rules))
    compliance_score_panel(compliance)

    # Show which files are covered by which compliance frameworks (PR/diff mode)
    if changed_files:
        compliance_file_map(finding_dicts, changed_files)

    # License expiry warning
    _warn_license_expiry(config)

    # Governance policy evaluation (requires governance feature — skip silently if tier too low)
    from guard.core.licensing import LicenseError, require_license

    _governance_blocked = False
    _governance_reason = ""

    try:
        require_license("governance", config.license_key)

        gov = config.get_governance()
        policy = PolicyEngine(gov)
        audit = AuditLog(gov.audit)

        _run_id = get_current_run_id(config.output_dir)
        _blocked_sevs = [s for s in ("critical", "high", "medium", "low") if getattr(gate_result, s, 0) > 0]
        gate_result_panel(gate_result.passed, gate_counts)
        if gate_result.passed:
            audit.log("gate", details={
                "result": "passed", "passed": True, "findings_count": len(findings),
                "blocked_severities": _blocked_sevs, "run_id": _run_id,
            })
            print_post_hint("gate_passed")
        else:
            decision = policy.check_gate_failure(has_critical=gate_result.critical > 0)
            audit.log(
                "gate", details={
                    "result": "failed", "passed": False, "findings_count": len(findings),
                    "blocked_severities": _blocked_sevs, "run_id": _run_id,
                },
                decision=decision, result="blocked",
            )
            if decision.require_human_review:
                _governance_blocked = True
                _governance_reason = "Human review required — submit a PR and assign a reviewer"
                typer.echo(f"  GOVERNANCE: {_governance_reason}")
            top_findings_table(finding_dicts)
            suggest_suppressions(finding_dicts)
            print_post_hint("gate_failed", context={
                "critical": gate_result.critical,
                "high": gate_result.high,
                "top_rules": _top_rules,
                "autofixable_count": _autofixable,
                "governance_blocked": _governance_blocked,
                "governance_reason": _governance_reason,
            })
    except LicenseError:
        # Governance not available at this tier — basic gate still works
        # Still log audit event for gate even without governance license
        try:
            gov = config.get_governance()
            _audit = AuditLog(gov.audit)
            _audit.log("gate", details={
                "passed": gate_result.passed,
                "findings_count": len(findings),
                "blocked_severities": [s for s in ("critical", "high", "medium", "low") if getattr(gate_result, s, 0) > 0],
            }, result="success" if gate_result.passed else "blocked")
        except Exception:
            pass  # Audit logging should never break the gate

        gate_result_panel(gate_result.passed, gate_counts)
        if gate_result.passed:
            print_post_hint("gate_passed")
        else:
            top_findings_table(finding_dicts)
            suggest_suppressions(finding_dicts)
            print_post_hint("gate_failed", context={
                "critical": gate_result.critical,
                "high": gate_result.high,
                "top_rules": _top_rules,
                "autofixable_count": _autofixable,
            })

    if decorate_pr:
        from guard.core.pr_decorator import decorate_pr as do_decorate_pr

        posted = do_decorate_pr(findings, gate_result, pr_number=pr_number)
        if posted:
            typer.echo("PR comment posted successfully.")
        else:
            typer.echo("PR decoration skipped (missing config or PR number).")

    if status_check:
        from guard.core.status_reporter import report_status as do_report_status

        reported = do_report_status(gate_result, commit_sha=commit_sha)
        if reported:
            typer.echo("Status check posted successfully.")
        else:
            typer.echo("Status check skipped (missing config or commit SHA).")

    # Async approval gate
    if not gate_result.passed and (require_approval or gate_result.pending_approval):
        if gate_result.approval_id:
            typer.echo(f"\n  APPROVAL REQUIRED: {gate_result.approval_id}")
            typer.echo("  Resolve via: sentrik approve <id> --action approved")
            typer.echo("  Check status: sentrik approval-status <id>")

    # Webhook notifications on gate failure
    if not gate_result.passed:
        try:
            from guard.core.notifications import notify_gate_failure
            notif_results = notify_gate_failure(config, gate_result, findings)
            for provider, success in notif_results.items():
                if success:
                    typer.echo(f"  {provider.capitalize()} notification sent.")
                else:
                    typer.echo(f"  {provider.capitalize()} notification failed.", err=True)
        except Exception:
            pass  # Notifications should never break the gate

    typer.echo(f"Artifacts written to {out}/")

    # Check for pending design acknowledgments (exit code 2)
    if gate_result.passed:
        try:
            from guard.core.design_reviewer import load_decisions
            decisions = load_decisions(config.output_dir)
            pending = [d for d in decisions if not d.acknowledged]
            if pending and config.governance.get("design_review", {}).get("require_acknowledgment"):
                typer.echo(f"\n  {len(pending)} design decision(s) pending acknowledgment.")
                typer.echo(f"  Run: sentrik review-design --pending")
                sys.exit(2)
        except Exception:
            pass

    sys.exit(0 if gate_result.passed else 1)


@app.command(rich_help_panel="Admin")
def approve(
    approval_id: str = typer.Argument(..., help="Approval request ID to resolve."),
    action: str = typer.Option("approved", "--action", help="Action: approved or rejected."),
    comment: str = typer.Option("", "--comment", help="Justification for the decision (required for approvals)."),
    user: str = typer.Option("cli-user", "--user", help="User resolving the approval."),
):
    """Approve or reject an async gate approval request."""
    from guard.core.approvals import get_approval_store

    if action == "approved" and not comment.strip():
        typer.echo("Error: --comment is required when approving. Provide a justification for the audit trail.", err=True)
        raise typer.Exit(1)

    store = get_approval_store()
    result = store.resolve(approval_id, action, user, comment)
    if result is None:
        typer.echo(f"Approval request {approval_id} not found.", err=True)
        raise typer.Exit(1)
    typer.echo(f"Approval {approval_id}: {result.status}")
    if result.comment:
        typer.echo(f"  Comment: {result.comment}")
    print_post_hint("approve")


@app.command(rich_help_panel="Admin")
def approval_status(
    approval_id: str = typer.Argument(..., help="Approval request ID to check."),
):
    """Check the status of an async gate approval request."""
    from guard.core.approvals import get_approval_store

    store = get_approval_store()
    req = store.get(approval_id)
    if req is None:
        typer.echo(f"Approval request {approval_id} not found.", err=True)
        raise typer.Exit(1)
    typer.echo(f"ID:        {req.id}")
    typer.echo(f"Status:    {req.status}")
    typer.echo(f"Requested: {req.requested_at.isoformat()}")
    if req.resolved_by:
        typer.echo(f"Resolved:  {req.resolved_at.isoformat() if req.resolved_at else 'N/A'}")
        typer.echo(f"By:        {req.resolved_by}")
    if req.comment:
        typer.echo(f"Comment:   {req.comment}")


@app.command(rich_help_panel="Governance")
def reconcile(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    git_range: str = typer.Option(None, "--git-range", help="Git range for scoping (e.g. HEAD~1..HEAD)."),
    diff: str = typer.Option(None, "--diff", help="Raw unified diff text for scoping."),
    staged: bool = typer.Option(False, "--staged", help="Scope to git-staged files only."),
    branch: str = typer.Option(None, "--branch", help="Branch name for work-item traceability (auto-detected if omitted)."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview actions without calling APIs or writing files."),
    work_items: str = typer.Option(None, "--work-items", help="Override path to work_items.json."),
    work_item_type: str = typer.Option(None, "--work-item-type", "-t", help="Work item type to create (e.g. 'User Story', 'Bug', 'Task'). Overrides config."),
):
    """Reconcile scan findings with work items — create, update, or close as needed."""
    from guard.core.licensing import LicenseError, require_license

    config, _profile = _load_config(config_path)

    try:
        require_license("reconcile", config.license_key)
    except LicenseError:
        ctx = get_error_context("license_feature_unavailable")
        if ctx:
            print_error_context(ctx)
        else:
            typer.echo("Upgrade your license to use the reconcile feature.", err=True)
        raise typer.Exit(1)

    devops, standards, scanner, rules_engine = _build_providers(config)
    repo_root = str(find_repo_root())

    # Warn if DevOps project doesn't match local git repo
    _warn_project_mismatch(config)

    changed_files = _resolve_changed_files(git_range, diff, repo_root, staged=staged)
    resolved_branch = branch or get_current_branch()
    rules = standards.get_rules() + _load_pack_rules(config.standards_packs, license_key=config.license_key)
    autofix_map = build_autofix_map(rules)
    replacement_map = build_replacement_map(rules)
    findings, _gate, out_dir = run_scan_and_write(
        repo_root, config, rules_engine, scanner, command="reconcile",
        changed_files=changed_files, branch=resolved_branch,
        autofix_map=autofix_map, replacement_map=replacement_map,
    )

    # Load existing work items
    wi_path = Path(work_items) if work_items else Path(config.work_items_file)
    existing: list[WorkItem] = []
    if wi_path.exists():
        with wi_path.open() as f:
            raw = json.load(f)
        existing = [WorkItem(**item) for item in raw]

    actions = compute_reconcile_actions(findings, existing)

    if dry_run:
        if not actions:
            typer.echo("No reconcile actions needed.")
        else:
            for act in actions:
                typer.echo(f"  [{act.action.upper()}] {act.rule_id}: {act.title}")
            typer.echo(f"\nDry run: {len(actions)} action(s) would be taken.")
        return

    # Governance policy evaluation
    gov = config.get_governance()
    policy = PolicyEngine(gov)
    audit = AuditLog(gov.audit)

    wi_type = work_item_type or config.azure_devops_work_item_type
    result = execute_reconcile(
        actions, devops, existing, wi_path, output_dir=Path(out_dir),
        work_item_type=wi_type,
    )

    total_synced = len(result.created) + len(result.updated) + len(result.closed)
    typer.echo(
        f"Reconcile complete: {len(result.created)} created, "
        f"{len(result.updated)} updated, {len(result.closed)} closed"
    )
    print_post_hint("reconcile", count=total_synced)
    typer.echo("  Docs: https://docs.sentrik.dev/guides/ci-cd-integration")

    # Check if requirement changes need human review
    has_changes = bool(result.created or result.updated or result.closed)
    if has_changes:
        decision = policy.check_requirement_change()
        # Build enriched details: map WI IDs to full action metadata
        finding_groups = {a.rule_id: a for a in actions}

        def _enrich(wi_id: str, action: "ReconcileAction | None") -> dict:
            if not action:
                return {"id": wi_id}
            ac_list = [
                line.lstrip("- ").strip()
                for line in (action.acceptance_criteria or "").splitlines()
                if line.strip()
            ]
            # Extract severity and count from findings
            from guard.core.reconciler import group_findings_by_rule as _grp
            groups = _grp(findings)
            rule_findings = groups.get(action.rule_id, [])
            severity = rule_findings[0].severity.value if rule_findings else "unknown"
            return {
                "id": wi_id,
                "rule_id": action.rule_id,
                "title": action.title,
                "severity": severity,
                "finding_count": len(rule_findings),
                "description": action.description,
                "acceptance_criteria": ac_list,
            }

        create_actions = [a for a in actions if a.action == "create"]
        created_detail = [
            _enrich(wi_id, create_actions[i] if i < len(create_actions) else None)
            for i, wi_id in enumerate(result.created)
        ]
        update_actions = [a for a in actions if a.action == "update"]
        updated_detail = [
            _enrich(wi_id, update_actions[i] if i < len(update_actions) else None)
            for i, wi_id in enumerate(result.updated)
        ]
        audit.log(
            "reconcile",
            details={
                "created": created_detail,
                "updated": updated_detail,
                "closed": result.closed,
                "summary": (
                    f"{len(result.created)} created, "
                    f"{len(result.updated)} updated, "
                    f"{len(result.closed)} closed"
                ),
            },
            decision=decision,
        )
        if decision.require_human_review:
            typer.echo("  GOVERNANCE: Requirement changes require human-reviewed PR")

    if result.errors:
        for err in result.errors:
            typer.echo(f"  WARNING: {err}", err=True)
    typer.echo(f"Artifacts written to {out_dir}/")


@app.command(name="generate-reqs", rich_help_panel="Governance")
def generate_reqs(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    output: str = typer.Option(None, "--output", "-o", help="Output YAML file path."),
    push: bool = typer.Option(False, "--push", help="Push generated requirements to DevOps as work items."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview generated requirements without writing files."),
    work_item_type: str = typer.Option(None, "--work-item-type", "-t", help="Work item type to create (e.g. 'User Story', 'Bug', 'Task'). Overrides config."),
):
    """Auto-generate requirements from untracked source files using LLM."""
    from guard.core.requirement_tracker import check_requirement_coverage
    from guard.core.requirements_generator import (
        generate_requirements,
        generate_requirements_stub,
        get_already_covered_files,
        push_requirements_to_devops,
        write_requirements_yaml,
    )
    from guard.providers.factory import build_devops, build_llm

    config, _profile = _load_config(config_path)
    output_path = Path(output) if output else Path(config.requirements_output_file)

    # Get work items — prefer local file, fall back to DevOps API
    work_items: list[WorkItem] = []
    wi_path = Path(config.work_items_file)
    if wi_path.exists():
        with wi_path.open() as f:
            raw = json.load(f)
        work_items = [WorkItem(**item) for item in raw]
    else:
        devops = build_devops(config)
        try:
            work_items = devops.get_work_items()
        except (OSError, ValueError, KeyError):
            work_items = []

    # Walk project files (respecting scan_exclude + default exclusions)
    from guard.core.repo_reader import list_files
    scan_excludes = config.scan_exclude or []
    all_files = list_files(Path("."))
    files: list[str] = []
    for f in all_files:
        norm = f.replace("\\", "/")
        if any(norm.startswith(ex.rstrip("/")) for ex in scan_excludes):
            continue
        files.append(norm)

    exclude = config.requirement_coverage_exclude if config.requirement_coverage_exclude else None
    findings = check_requirement_coverage(files, work_items, exclude)

    if not findings:
        typer.echo("All source files are traced to work items. Nothing to generate.")
        return

    untracked = [f.evidence.file for f in findings]

    # Filter out files already covered by existing requirements or work items
    already_covered = get_already_covered_files(output_path, work_items)
    untracked = [f for f in untracked if f not in already_covered]

    if not untracked:
        typer.echo("All untracked files already have generated requirements. Nothing new to generate.")
        return

    typer.echo(f"Found {len(untracked)} untracked file(s).")

    # Generate requirements via LLM (or stub fallback)
    llm = build_llm(config)
    repo_root = str(find_repo_root())

    if config.llm_provider != "stub" and config.llm_enabled:
        reqs = generate_requirements(untracked, repo_root, llm)
    else:
        reqs = generate_requirements_stub(untracked, repo_root)

    if dry_run:
        for req in reqs:
            typer.echo(f"\n  [{req.req_id}] {req.title}")
            if req.description:
                typer.echo(f"    {req.description}")
            for ac in req.acceptance_criteria:
                typer.echo(f"    - {ac}")
            typer.echo(f"    Files: {', '.join(req.source_files)}")
        typer.echo(f"\nDry run: {len(reqs)} requirement(s) would be generated.")
        return

    # Write YAML
    written = write_requirements_yaml(reqs, output_path)
    typer.echo(f"Requirements written to {written}")

    # Optionally push to DevOps
    if push:
        wi_path = Path(config.work_items_file)
        existing: list[WorkItem] = []
        if wi_path.exists():
            with wi_path.open() as f:
                raw = json.load(f)
            existing = [WorkItem(**item) for item in raw]

        wi_type = work_item_type or config.azure_devops_work_item_type
        reqs = push_requirements_to_devops(reqs, devops, existing, wi_path, work_item_type=wi_type)
        created_ids = [r.work_item_id for r in reqs if r.work_item_id]
        typer.echo(f"Created {len(created_ids)} {wi_type} work item(s): {', '.join(created_ids)}")

    typer.echo(f"Generated {len(reqs)} requirement(s).")
    print_post_hint("generate_reqs")


@app.command(name="quality-score", rich_help_panel="Reports")
def quality_score_cmd(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    path: str = typer.Option(None, "--path", "-p", help="Specific path to score (default: whole project)."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON."),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show dimension breakdown with issues."),
    min_quality: int = typer.Option(None, "--min-quality", help="Fail if quality score is below this threshold."),
):
    """Evaluate code quality on a continuous 0-100 scale.

    Scores across six dimensions: compliance, complexity, test coverage,
    documentation, consistency, and dependency health. Tracks trends over time.
    """
    from guard.core.quality_scorer import calculate_quality_score, format_quality_report

    config, _profile = _load_config(config_path)
    repo_root = path or str(Path("."))

    score = calculate_quality_score(repo_root, config.output_dir)

    if json_output:
        typer.echo(json.dumps(score.to_dict(), indent=2))
    else:
        typer.echo(format_quality_report(score))

    if min_quality is not None and score.overall < min_quality:
        print_error(f"Quality score {score.overall} is below minimum {min_quality}")
        raise typer.Exit(1)


@app.command(name="quality-trend", rich_help_panel="Reports")
def quality_trend_cmd(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    last: int = typer.Option(10, "--last", "-n", help="Number of entries to show."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON."),
):
    """Show quality score trend over time."""
    config, _profile = _load_config(config_path)
    history_path = Path(config.output_dir) / "quality_history.json"

    if not history_path.is_file():
        print_error("No quality history. Run 'sentrik quality-score' first.")
        raise typer.Exit(1)

    history = json.loads(history_path.read_text(encoding="utf-8"))
    recent = history[-last:]

    if json_output:
        typer.echo(json.dumps(recent, indent=2))
        return

    typer.echo(f"\nQuality trend (last {len(recent)} scores):\n")
    prev = None
    for entry in recent:
        ts = entry.get("timestamp", "")[:19].replace("T", " ")
        score = entry.get("overall", 0)
        delta = ""
        if prev is not None:
            diff = score - prev
            delta = f"  (+{diff})" if diff > 0 else f"  ({diff})" if diff < 0 else "  (=)"
        bar = "#" * (score // 5)
        typer.echo(f"  {ts}  {score:3d}/100  {bar}{delta}")
        prev = score

    first = recent[0].get("overall", 0)
    last_score = recent[-1].get("overall", 0)
    overall = last_score - first
    if overall > 0:
        typer.echo(f"\n  Overall: +{overall} (improving)")
    elif overall < 0:
        typer.echo(f"\n  Overall: {overall} (degrading)")
    else:
        typer.echo(f"\n  Overall: stable")
    typer.echo("")


@app.command(name="check-expertise", rich_help_panel="Analysis")
def check_expertise_cmd(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    email: str = typer.Option(None, "--email", "-e", help="Developer email (default: git user.email)."),
    git_range: str = typer.Option(None, "--git-range", help="Git range to check."),
    staged: bool = typer.Option(False, "--staged", help="Check staged files only."),
    threshold: float = typer.Option(0.3, "--threshold", "-t", help="Expertise threshold (0.0-1.0)."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON."),
    show_profile: bool = typer.Option(False, "--profile", help="Show developer profile instead of checking gaps."),
):
    """Check if code changes fall outside your expertise.

    Analyzes git history to build your developer profile, then flags
    code in languages or modules you rarely work in. Helps catch
    AI-generated code outside your comfort zone.
    """
    from guard.core.expertise_tracker import (
        build_developer_profile, get_current_user, check_expertise_gaps,
        get_changed_files, format_gaps, save_profiles, load_profiles,
    )

    config, _profile = _load_config(config_path)
    dev_email = email or get_current_user()
    if not dev_email:
        print_error("Could not determine developer email. Use --email or set git user.email.")
        raise typer.Exit(1)

    # Build or load profile
    profiles = load_profiles(config.output_dir)
    if dev_email not in profiles:
        profile = build_developer_profile(dev_email)
        profiles[dev_email] = profile
        save_profiles(profiles, config.output_dir)
    else:
        profile = profiles[dev_email]

    if show_profile:
        if json_output:
            typer.echo(json.dumps(profile.to_dict(), indent=2))
        else:
            typer.echo(f"\nDeveloper Profile: {profile.name or profile.email}")
            typer.echo(f"  Commits: {profile.total_commits}")
            typer.echo(f"  Languages: {', '.join(f'{k} ({v})' for k, v in profile.languages.items())}")
            typer.echo(f"  Modules: {', '.join(f'{k} ({v})' for k, v in list(profile.modules.items())[:10])}")
            typer.echo("")
        return

    # Get changed files
    files = get_changed_files(git_range=git_range, staged=staged)
    if not files:
        print_warning("No changed files found. Use --git-range or --staged.")
        raise typer.Exit()

    gaps = check_expertise_gaps(profile, files, threshold)

    if json_output:
        typer.echo(json.dumps([g.to_dict() for g in gaps], indent=2))
    else:
        typer.echo(format_gaps(gaps, profile))


@app.command(name="review-design", rich_help_panel="Analysis")
def review_design_cmd(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    git_range: str = typer.Option(None, "--git-range", help="Git range to review (e.g. origin/main...HEAD)."),
    file: str = typer.Option(None, "--file", "-f", help="Specific file to review."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON."),
    ack: str = typer.Option(None, "--ack", help="Acknowledge a decision by ID (e.g. DD-ABC123)."),
    ack_note: str = typer.Option("", "--note", help="Note for acknowledgment."),
    pending: bool = typer.Option(False, "--pending", help="Show only unacknowledged decisions."),
):
    """Review design decisions in AI-generated code.

    Uses LLM to identify implicit design decisions — framework choices,
    data structure selection, auth patterns, API tradeoffs — and presents
    them as questions for developer review.

    Requires LLM configuration (ANTHROPIC_API_KEY or other provider).
    """
    from guard.core.design_reviewer import (
        review_design, get_diff, format_decisions,
        save_decisions, load_decisions, acknowledge_decision,
    )
    from guard.providers.llm_stub import LLMStub

    config, _profile = _load_config(config_path)

    # Handle acknowledgment
    if ack:
        if acknowledge_decision(ack, ack_note, config.output_dir):
            print_success(f"Acknowledged {ack}" + (f": {ack_note}" if ack_note else ""))
        else:
            print_error(f"Decision {ack} not found")
            raise typer.Exit(1)
        return

    # Show pending decisions
    if pending:
        decisions = load_decisions(config.output_dir)
        unacked = [d for d in decisions if not d.acknowledged]
        if json_output:
            typer.echo(json.dumps([d.to_dict() for d in unacked], indent=2))
        elif not unacked:
            print_success("No pending design decisions.")
        else:
            typer.echo(format_decisions(unacked))
        return

    # Build LLM
    from guard.providers.factory import build_llm
    llm = build_llm(config)
    if isinstance(llm, LLMStub):
        print_error("Design review requires an LLM. Set ANTHROPIC_API_KEY or configure llm_provider.")
        raise typer.Exit(1)

    # Get code changes
    diff = get_diff(git_range=git_range, file_path=file)
    if not diff.strip():
        print_warning("No code changes found. Use --git-range or --file to specify what to review.")
        raise typer.Exit()

    # Review
    decisions = review_design(llm, diff, config.output_dir)
    save_decisions(decisions, config.output_dir)

    if json_output:
        typer.echo(json.dumps([d.to_dict() for d in decisions], indent=2))
    else:
        typer.echo(format_decisions(decisions))
        if decisions:
            typer.echo(f"  Acknowledge: sentrik review-design --ack <ID> --note \"reason\"")


@app.command(name="threat-model", rich_help_panel="Analysis")
def threat_model_cmd(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    git_range: str = typer.Option(None, "--git-range", help="Git range to analyze (e.g. origin/main...HEAD)."),
    file: str = typer.Option(None, "--file", "-f", help="Specific file to analyze."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON."),
    stride: str = typer.Option(None, "--stride", help="Filter by STRIDE category (e.g. spoofing, tampering)."),
    mitigate: str = typer.Option(None, "--mitigate", help="Mark a threat as mitigated by ID (e.g. TM-ABC123)."),
    note: str = typer.Option("", "--note", help="Note for mitigation."),
    pending: bool = typer.Option(False, "--pending", help="Show only unmitigated threats."),
):
    """STRIDE-based threat modeling of code changes.

    Uses LLM to perform STRIDE analysis — identifying spoofing, tampering,
    repudiation, information disclosure, denial of service, and elevation
    of privilege threats in your code.

    Requires LLM configuration (ANTHROPIC_API_KEY or other provider).
    """
    from guard.core.threat_modeler import (
        generate_threat_model, get_diff, format_threats,
        save_threats, load_threats, mitigate_threat,
    )
    from guard.providers.llm_stub import LLMStub

    config, _profile = _load_config(config_path)

    # Handle mitigation
    if mitigate:
        if mitigate_threat(mitigate, note, config.output_dir):
            print_success(f"Mitigated {mitigate}" + (f": {note}" if note else ""))
        else:
            print_error(f"Threat {mitigate} not found")
            raise typer.Exit(1)
        return

    # Show pending (unmitigated) threats
    if pending:
        threats = load_threats(config.output_dir)
        unmitigated = [t for t in threats if not t.mitigated]
        if stride:
            unmitigated = [t for t in unmitigated if t.category == stride]
        if json_output:
            typer.echo(json.dumps([t.to_dict() for t in unmitigated], indent=2))
        elif not unmitigated:
            print_success("No pending threats.")
        else:
            typer.echo(format_threats(unmitigated))
        return

    # Build LLM
    from guard.providers.factory import build_llm
    llm = build_llm(config)
    if isinstance(llm, LLMStub):
        print_error("Threat modeling requires an LLM. Set ANTHROPIC_API_KEY or configure llm_provider.")
        raise typer.Exit(1)

    # Get code changes
    diff = get_diff(git_range=git_range, file_path=file)
    if not diff.strip():
        print_warning("No code changes found. Use --git-range or --file to specify what to analyze.")
        raise typer.Exit()

    # Generate threat model
    threats = generate_threat_model(llm, diff, config.output_dir)

    # Filter by STRIDE category if requested
    if stride:
        threats = [t for t in threats if t.category == stride]

    save_threats(threats, config.output_dir)

    if json_output:
        typer.echo(json.dumps([t.to_dict() for t in threats], indent=2))
    else:
        typer.echo(format_threats(threats))
        if threats:
            typer.echo(f"  Mitigate: sentrik threat-model --mitigate <ID> --note \"reason\"")


@app.command(name="profile", rich_help_panel="Analysis")
def profile_cmd(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    show: bool = typer.Option(False, "--show", help="Show current cached profile."),
    for_path: str = typer.Option(None, "--for", help="Show constraints for a specific file or directory."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON."),
):
    """Build or view the project profile (frameworks, patterns, ADRs, conventions).

    The profile is used by the MCP get_design_constraints tool to provide
    architectural context to AI agents before they generate code.
    """
    from guard.core.project_profile import (
        build_project_profile, save_profile, load_profile, get_design_constraints,
    )

    config, _profile = _load_config(config_path)

    if show:
        profile = load_profile(config.output_dir)
        if not profile:
            print_error("No profile cached. Run 'sentrik profile' to build one.")
            raise typer.Exit(1)
        if json_output:
            typer.echo(json.dumps(profile, indent=2))
        else:
            typer.echo(f"\nProject Profile:")
            typer.echo(f"  Languages: {', '.join(profile.get('languages', []))}")
            typer.echo(f"  Frameworks: {', '.join(f['name'] for f in profile.get('frameworks', []))}")
            typer.echo(f"  Architecture: {', '.join(p['pattern'] for p in profile.get('architecture', []))}")
            typer.echo(f"  ADRs: {len(profile.get('adrs', []))}")
            typer.echo(f"  Conventions: {json.dumps(profile.get('conventions', {}))}")
            typer.echo(f"  Modules: {len(profile.get('module_map', []))}")
            typer.echo("")
        return

    if for_path:
        profile = load_profile(config.output_dir)
        if not profile:
            profile = build_project_profile(str(Path(".")), scan_exclude=config.scan_exclude, enabled_packs=config.standards_packs)
            save_profile(profile, config.output_dir)
        constraints = get_design_constraints(profile, file_path=for_path)
        if json_output:
            typer.echo(json.dumps(constraints, indent=2))
        else:
            typer.echo(f"\nDesign constraints for {for_path}:")
            for p in constraints.get("established_patterns", []):
                typer.echo(f"  - {p}")
            if constraints.get("tech_stack_warnings"):
                for w in constraints["tech_stack_warnings"]:
                    typer.echo(f"  ! {w}")
            if constraints.get("adrs"):
                typer.echo(f"  ADRs: {len(constraints['adrs'])}")
            typer.echo("")
        return

    # Build profile
    print_header("Building project profile...")
    profile = build_project_profile(str(Path(".")), scan_exclude=config.scan_exclude, enabled_packs=config.standards_packs)
    path = save_profile(profile, config.output_dir)
    print_success(f"Profile saved to {path}")
    typer.echo(f"  Languages: {', '.join(profile.get('languages', []))}")
    typer.echo(f"  Frameworks: {', '.join(f['name'] for f in profile.get('frameworks', []))}")
    typer.echo(f"  Patterns: {', '.join(p['pattern'] for p in profile.get('architecture', []))}")
    typer.echo(f"  ADRs: {len(profile.get('adrs', []))}")
    typer.echo(f"  Modules: {len(profile.get('module_map', []))}")
    typer.echo("")


@app.command(name="risk-summary", rich_help_panel="Reports")
def risk_summary_cmd(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    output: str = typer.Option(None, "--output", "-o", help="Output file path (default: out/risk-summary.html)."),
    org_name: str = typer.Option(None, "--org", help="Organization name for the header."),
):
    """Generate a one-page executive risk summary (HTML).

    Traffic light status, severity breakdown, top violation rules, and
    most affected files — designed for stakeholders and engineering managers.
    """
    from guard.reporters.executive_summary import generate_executive_summary

    config, _profile = _load_config(config_path)
    findings_path = Path(config.output_dir) / "findings.json"
    metrics_path = Path(config.output_dir) / "scan_metrics.json"

    if not findings_path.is_file():
        print_error("No findings.json found. Run 'sentrik scan' first.")
        raise typer.Exit(1)

    finding_dicts = json.loads(findings_path.read_text(encoding="utf-8"))
    metrics = None
    if metrics_path.is_file():
        metrics = json.loads(metrics_path.read_text(encoding="utf-8"))

    # Read compliance score from metrics
    compliance_score = None
    if metrics and "compliance_score" in metrics:
        compliance_score = metrics["compliance_score"]

    html = generate_executive_summary(
        finding_dicts,
        metrics=metrics,
        compliance_score=compliance_score,
        org_name=org_name or "",
        packs_enabled=config.standards_packs,
    )

    out_path = Path(output) if output else Path(config.output_dir) / "risk-summary.html"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html, encoding="utf-8")
    print_success(f"Executive risk summary written to {out_path}")


@app.command(name="compliance-trend", rich_help_panel="Reports")
def compliance_trend_cmd(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    last: int = typer.Option(10, "--last", "-n", help="Number of recent runs to show."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON."),
):
    """Show compliance score trend from historical scan data."""
    config, _profile = _load_config(config_path)
    manifest_path = Path(config.output_dir) / "history" / "manifest.jsonl"

    if not manifest_path.is_file():
        print_error("No scan history found. Run 'sentrik scan' a few times to build history.")
        raise typer.Exit(1)

    runs = []
    for line in manifest_path.read_text(encoding="utf-8").strip().split("\n"):
        if not line.strip():
            continue
        try:
            runs.append(json.loads(line))
        except json.JSONDecodeError:
            continue

    if not runs:
        print_error("No scan runs in history.")
        raise typer.Exit(1)

    recent = runs[-last:]

    if json_output:
        data = []
        for r in recent:
            data.append({
                "timestamp": r.get("timestamp", ""),
                "findings_count": r.get("findings_count", 0),
                "command": r.get("command", ""),
                "run_id": r.get("run_id", ""),
            })
        typer.echo(json.dumps(data, indent=2))
        return

    typer.echo(f"\nCompliance trend (last {len(recent)} runs):\n")
    prev_count = None
    for r in recent:
        ts = r.get("timestamp", "")[:19].replace("T", " ")
        count = r.get("findings_count", 0)
        delta = ""
        if prev_count is not None:
            diff = count - prev_count
            if diff > 0:
                delta = f"  (+{diff})"
            elif diff < 0:
                delta = f"  ({diff})"
            else:
                delta = "  (=)"
        # Simple bar
        bar_len = min(count, 40)
        bar = "#" * bar_len
        typer.echo(f"  {ts}  {count:>4} findings  {bar}{delta}")
        prev_count = count

    # Overall trend
    first = recent[0].get("findings_count", 0)
    last_count = recent[-1].get("findings_count", 0)
    overall = last_count - first
    if overall < 0:
        typer.echo(f"\n  Trend: {overall} findings (improving)")
    elif overall > 0:
        typer.echo(f"\n  Trend: +{overall} findings (degrading)")
    else:
        typer.echo(f"\n  Trend: stable")
    typer.echo("")


@app.command(name="drift-scan", rich_help_panel="Governance")
def drift_scan_cmd(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    requirements: str = typer.Option(None, "--requirements", "-r", help="Path to requirements.yaml."),
    staged: bool = typer.Option(False, "--staged", help="Scope to staged files only."),
    output: str = typer.Option(None, "--output", "-o", help="Output file path for drift findings."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON."),
):
    """Context-aware requirement drift analysis.

    Goes beyond tag-matching to detect four types of drift:

    1. Behavioral — requirement description vs actual code behavior (LLM)
    2. Structural — security-critical patterns removed or weakened
    3. Cross-file — requirement coverage when code moves between files
    4. Acceptance criteria — per-criterion pass/fail validation (LLM)

    Requires requirements.yaml with source_files mapped to requirements.
    LLM analysis requires ANTHROPIC_API_KEY (or other LLM provider config).
    Structural and cross-file checks work without LLM.
    """
    from guard.core.drift_analyzer import DriftAnalyzer
    from guard.providers.llm_stub import LLMStub

    config, _profile = _load_config(config_path)

    # Build LLM
    llm = None
    try:
        from guard.providers.factory import build_llm
        llm_instance = build_llm(config)
        if not isinstance(llm_instance, LLMStub):
            llm = llm_instance
    except Exception:
        pass

    req_path = Path(requirements) if requirements else None
    analyzer = DriftAnalyzer(
        repo_root=str(Path(".")),
        llm=llm,
        requirements_path=req_path,
    )

    if not analyzer.has_requirements:
        print_error("No requirements found. Create requirements.yaml or run 'sentrik generate-reqs' first.")
        raise typer.Exit(1)

    if not analyzer.has_llm:
        print_warning("No LLM configured — only structural and cross-file checks will run.")
        print_warning("Set ANTHROPIC_API_KEY for full behavioral and acceptance criteria analysis.")

    changed_files = None
    if staged:
        from guard.core.diff_parser import get_staged_files
        changed_files = get_staged_files()

    findings = analyzer.analyze(changed_files=changed_files)

    if json_output:
        import json as _json
        data = [f.model_dump(mode="json") for f in findings]
        content = _json.dumps(data, indent=2)
        if output:
            Path(output).write_text(content, encoding="utf-8")
            typer.echo(f"Drift findings written to {output}")
        else:
            typer.echo(content)
    else:
        if not findings:
            print_success("No requirement drift detected.")
        else:
            typer.echo(f"\n{len(findings)} drift finding(s):\n")
            for f in findings:
                sev = f.severity.value.upper()
                typer.echo(f"  [{sev}] {f.message}")
                if f.evidence.file:
                    loc = f.evidence.file
                    if f.evidence.lines:
                        loc += f":{f.evidence.lines[0]}"
                    typer.echo(f"    File: {loc}")
                if f.suggestion:
                    typer.echo(f"    Fix: {f.suggestion}")
                typer.echo("")

        if output:
            import json as _json
            data = [f.model_dump(mode="json") for f in findings]
            Path(output).write_text(_json.dumps(data, indent=2), encoding="utf-8")
            typer.echo(f"Drift findings written to {output}")


@app.command(name="verify-reqs", rich_help_panel="Governance")
def verify_reqs(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    requirements_file: str = typer.Option(None, "--requirements", "-r", help="Path to requirements.yaml."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview drift findings without writing files."),
):
    """Verify requirements match actual code behavior (drift detection)."""
    from guard.core.requirements_verifier import (
        load_requirements,
        verify_requirements,
        verify_requirements_stub,
    )
    from guard.providers.factory import build_llm

    config, _profile = _load_config(config_path)
    req_path = Path(requirements_file) if requirements_file else Path(config.requirements_output_file)

    if not req_path.exists():
        # Try pulling requirements from DevOps provider
        if config.devops_provider != "stub":
            from guard.core.models import GeneratedRequirement
            from guard.core.requirements_generator import write_requirements_yaml
            from guard.providers.factory import build_devops as _build_devops
            try:
                devops = _build_devops(config)
                work_items = devops.get_work_items()
                if work_items:
                    typer.echo(f"No local {req_path} found — pulled {len(work_items)} work item(s) from {config.devops_provider}.")
                    reqs = [
                        GeneratedRequirement(
                            req_id=wi.id or f"WI-{i+1}",
                            title=wi.title,
                            description=wi.description or "",
                            source_files=[],
                            status="draft",
                            devops_id=wi.devops_id,
                        )
                        for i, wi in enumerate(work_items)
                    ]
                    write_requirements_yaml(reqs, req_path)
                    typer.echo(f"  Written to {req_path} — edit source_files to map requirements to code.")
            except (OSError, ValueError, KeyError) as exc:
                print_error(f"Failed to pull from {config.devops_provider}: {exc}")

        if not req_path.exists():
            print_error(f"Requirements file not found: {req_path}")
            print_hint("Generate requirements first: sentrik generate-reqs")
            raise typer.Exit(1)

    requirements = load_requirements(req_path)
    if not requirements:
        typer.echo("No requirements found in file.")
        return

    reqs_with_files = [r for r in requirements if r.source_files and r.status != "rejected"]
    typer.echo(f"Verifying {len(reqs_with_files)} requirement(s) against source code...")

    repo_root = str(find_repo_root())

    # Use LLM if available, otherwise stub
    if config.llm_provider != "stub" and config.llm_enabled:
        llm = build_llm(config)
        findings = verify_requirements(reqs_with_files, repo_root, llm)
    else:
        findings = verify_requirements_stub(reqs_with_files, repo_root)

    if not findings:
        print_success("No drift detected — all requirements match code.")
        return

    # Display findings
    for f in findings:
        sev = f.severity.upper() if isinstance(f.severity, str) else f.severity.value.upper()
        typer.echo(f"\n  [{sev}] {f.message}")
        if f.evidence.file:
            typer.echo(f"    File: {f.evidence.file}")
        if f.suggestion:
            typer.echo(f"    Fix: {f.suggestion}")

    typer.echo(f"\n{len(findings)} drift finding(s) detected.")

    if not dry_run:
        # Write drift findings to output
        out_dir = Path(config.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        drift_path = out_dir / "drift_findings.json"
        drift_data = [f.model_dump(mode="json") for f in findings]
        drift_path.write_text(json.dumps(drift_data, indent=2), encoding="utf-8")
        typer.echo(f"Drift findings written to {drift_path}")

    print_post_hint("verify_reqs")


@app.command(name="pull-reqs", rich_help_panel="Governance")
def pull_reqs(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    provider: str = typer.Option(None, "--provider", "-p", help="Override DevOps provider (azure, github, jira)."),
    output: str = typer.Option(None, "--output", "-o", help="Output YAML file path."),
    merge: bool = typer.Option(False, "--merge", help="Merge with existing requirements.yaml instead of overwriting."),
    map_files: bool = typer.Option(False, "--map-files", help="Auto-map source_files by matching work item titles to filenames."),
):
    """Pull requirements from a DevOps provider into requirements.yaml."""
    from guard.core.pull_reqs import pull_requirements
    from guard.core.repo_reader import list_files
    from guard.providers.factory import build_devops

    config, _profile = _load_config(config_path)

    # Override provider if specified
    if provider:
        config.devops_provider = provider

    if config.devops_provider == "stub":
        print_warning("No DevOps provider configured. Use --provider or set devops_provider in config.")
        print_hint("Example: sentrik pull-reqs --provider azure")
        raise typer.Exit(1)

    output_path = Path(output) if output else Path(config.requirements_output_file)

    devops = build_devops(config)

    # Gather source files for auto-mapping
    source_files: list[str] | None = None
    if map_files:
        source_files = [f.replace("\\", "/") for f in list_files(Path("."))]

    try:
        reqs = pull_requirements(
            devops=devops,
            provider=config.devops_provider,
            output_path=output_path,
            merge=merge,
            map_files=map_files,
            source_files=source_files,
        )
    except (OSError, ValueError, RuntimeError) as exc:
        print_error(f"Failed to pull from {config.devops_provider}: {exc}")
        raise typer.Exit(1)

    if not reqs:
        typer.echo("No work items found in the DevOps provider.")
        return

    typer.echo(f"Pulled {len(reqs)} requirement(s) from {config.devops_provider}.")
    typer.echo(f"Written to {output_path}")

    mapped_count = sum(1 for r in reqs if r.source_files)
    if map_files and mapped_count:
        typer.echo(f"Auto-mapped source files for {mapped_count} requirement(s).")

    print_post_hint("pull_reqs")


@app.command(rich_help_panel="Governance")
def trace(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    work_items: str = typer.Option(None, "--work-items", help="Override path to work_items.json."),
    output: str = typer.Option(None, "--output", "-o", help="Output JSON file path."),
    file_glob: str = typer.Option(None, "--glob", help="File glob pattern (e.g. '**/*.cpp')."),
):
    """Generate a traceability matrix from REQ-xxx comments in source files."""
    from guard.core.traceability import build_traceability_matrix, scan_files_for_reqs

    config, _profile = _load_config(config_path)
    repo_root = str(find_repo_root())

    # Resolve work items
    wi_path = Path(work_items) if work_items else Path(config.work_items_file)
    work_item_list: list[dict] = []
    if wi_path.exists():
        try:
            with wi_path.open(encoding="utf-8") as f:
                work_item_list = json.load(f)
        except (json.JSONDecodeError, OSError) as exc:
            print_warning(f"Could not read work items: {exc}")

    # Determine file globs
    globs = [file_glob] if file_glob else None

    # Scan files for REQ-xxx comments
    typer.echo(f"Scanning source files for traceability references...")
    file_reqs = scan_files_for_reqs(
        repo_root,
        file_globs=globs,
        scan_exclude=config.scan_exclude,
    )

    if not file_reqs and not work_item_list:
        print_warning("No traceability references found and no work items defined.")
        print_hint("Add // REQ-xxx comments to source files and define requirements in work_items.json")
        raise typer.Exit(1)

    typer.echo(f"Found references in {len(file_reqs)} file(s)")

    # Build the matrix
    matrix = build_traceability_matrix(file_reqs, work_item_list)

    # Print Rich table
    traceability_table(matrix)

    # Write JSON output
    out_dir = Path(output).parent if output else Path(config.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = Path(output) if output else out_dir / "traceability.json"
    out_path.write_text(json.dumps(matrix, indent=2), encoding="utf-8")
    typer.echo(f"Traceability matrix written to {out_path}")

    # Check for source files with no REQ-xxx reference at all
    from guard.core.repo_reader import list_files

    source_globs = [file_glob] if file_glob else ["**/*.py", "**/*.cpp", "**/*.c", "**/*.h", "**/*.hpp",
                     "**/*.cs", "**/*.java", "**/*.js", "**/*.ts", "**/*.go", "**/*.rs", "**/*.rb"]
    all_source: set[str] = set()
    for g in source_globs:
        for f in list_files(Path(repo_root), g):
            norm = f.replace("\\", "/")
            if not any(norm.startswith(ex.rstrip("/")) for ex in (config.scan_exclude or [])):
                all_source.add(norm)

    traced_files = set(file_reqs.keys())
    untraced = sorted(all_source - traced_files)
    if untraced:
        print_warning(f"{len(untraced)} source file(s) have no REQ-xxx traceability reference:")
        for f in untraced:
            typer.echo(f"    {f}")

    # Summary
    summary = matrix["summary"]
    if summary["unimplemented"] > 0:
        print_warning(f"{summary['unimplemented']} requirement(s) have no implementing code.")
    if matrix["unlinked_files"]:
        print_warning(f"{len(matrix['unlinked_files'])} file(s) reference undefined requirements.")
    if summary["coverage_pct"] == 100.0 and not matrix["unlinked_files"] and not untraced:
        print_success("Full traceability — all requirements have implementing code.")
    print_post_hint("trace")


@app.command(name="apply-patches", rich_help_panel="Governance")
def apply_patches(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
):
    """Apply auto-generated patches from the most recent scan."""
    config, _profile = _load_config(config_path)
    patches_dir = Path(config.output_dir) / "patches"
    if not patches_dir.exists() or not list(patches_dir.glob("*.patch")):
        ctx = get_error_context("no_patches")
        if ctx:
            print_error_context(ctx)
        else:
            typer.echo("No patches found. Run 'sentrik scan' first.")
        raise typer.Exit(1)

    # Governance policy check — determine max severity of findings being patched
    gov = config.get_governance()
    policy = PolicyEngine(gov)
    audit = AuditLog(gov.audit)

    findings_path = Path(config.output_dir) / "findings.json"
    max_severity = "low"
    if findings_path.exists():
        raw_findings = json.loads(findings_path.read_text(encoding="utf-8"))
        fixable_severities = [f.get("severity", "info") for f in raw_findings if f.get("suggestion")]
        from guard.core.governance import SEVERITY_ORDER
        for sev in fixable_severities:
            if SEVERITY_ORDER.get(sev, 0) > SEVERITY_ORDER.get(max_severity, 0):
                max_severity = sev

    decision = policy.check_auto_patch(max_severity)
    if not decision.allowed:
        ctx = get_error_context("governance_patch_blocked")
        if ctx:
            print_error_context(ctx)
        else:
            typer.echo(f"GOVERNANCE: {decision.reason}")
        audit.log("apply_patches", details={"max_severity": max_severity}, decision=decision, result="blocked")
        raise typer.Exit(1)

    repo_root = str(find_repo_root())
    applied = do_apply_patches(patches_dir, repo_root)
    audit.log("apply_patches", details={"applied": applied, "max_severity": max_severity}, decision=decision)
    typer.echo(f"Applied {applied} patch(es).")
    print_post_hint("apply_patches")


@app.command(name="list-rules", rich_help_panel="Admin")
def list_rules(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
):
    """List all available rules with descriptions and severities."""
    config, _profile = _load_config(config_path)
    _, standards, _, _ = _build_providers(config)
    rules = standards.get_rules()
    pack_rules = _load_pack_rules(config.standards_packs, license_key=config.license_key)

    from guard.rules.builtins import BUILTIN_RULES
    all_rules = BUILTIN_RULES + rules + pack_rules

    if not all_rules:
        typer.echo("No rules configured.")
        return

    # Deduplicate by id (standards rules override builtins)
    seen: set[str] = set()
    unique: list[dict] = []
    for r in reversed(all_rules):
        rid = r.get("id", "")
        if rid not in seen:
            seen.add(rid)
            unique.append(r)
    unique.reverse()

    rules_table(unique)


@app.command(name="validate-config", rich_help_panel="Core")
def validate_config(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
):
    """Validate the .guard.yaml configuration file."""
    config, _profile = _load_config(config_path)
    warnings = config.validate_config()

    if not warnings:
        print_success("Configuration is valid.")
        print_post_hint("validate_config")
        return

    errors = [w for w in warnings if w.level == "error"]
    warns = [w for w in warnings if w.level == "warning"]

    for w in errors:
        print_error(f"ERROR  [{w.field}] {w.message}")
    for w in warns:
        print_warning(f"WARN   [{w.field}] {w.message}")

    if errors:
        typer.echo(f"\n{len(errors)} error(s), {len(warns)} warning(s)")
        raise typer.Exit(1)
    else:
        typer.echo(f"\n{len(warns)} warning(s), no errors")


@app.command(rich_help_panel="Admin")
def report(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    format: str = typer.Option("html", "--format", "-f", help="Report format: html, junit, sarif."),
    output: str = typer.Option(None, "--output", "-o", help="Output file path (default: auto)."),
):
    """Generate a report from the most recent scan findings."""
    config, _profile = _load_config(config_path)
    findings_path = Path(config.output_dir) / "findings.json"
    if not findings_path.exists():
        ctx = get_error_context("no_findings")
        if ctx:
            print_error_context(ctx)
        else:
            typer.echo("No findings.json found. Run 'sentrik scan' first.")
        raise typer.Exit(1)

    findings = load_findings(findings_path)

    reporters = build_reporters([format])
    if not reporters:
        typer.echo(f"Unknown report format: {format}")
        raise typer.Exit(1)

    reporter = reporters[0]
    content = reporter.render(findings)

    if output:
        out_path = Path(output)
    else:
        out_path = Path(config.output_dir) / f"report{reporter.extension}"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(content)

    typer.echo(f"Report written to {out_path}")


@app.command(rich_help_panel="Admin")
def compare(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    previous: str = typer.Option(None, "--previous", "-p", help="Path to previous findings.json (auto-detects from history if omitted)."),
    run_id: str = typer.Option(None, "--run-id", help="Compare against a specific historical run ID."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON."),
):
    """Compare current findings against a previous run (delta analysis).

    Auto-detects the most recent historical run if --previous and --run-id
    are both omitted. Shows new, resolved, and unchanged findings with
    severity breakdown.
    """
    config, _profile = _load_config(config_path)
    current_path = Path(config.output_dir) / "findings.json"
    if not current_path.exists():
        print_error("No findings.json found. Run 'sentrik scan' first.")
        raise typer.Exit(1)

    current_findings = load_findings(current_path)
    previous_findings: list = []

    if previous:
        previous_path = Path(previous)
        if not previous_path.exists():
            print_error(f"Previous findings file not found: {previous}")
            raise typer.Exit(1)
        previous_findings = load_findings(previous_path)
    elif run_id:
        from guard.core.pipeline import load_historical_findings
        hist = load_historical_findings(config.output_dir, run_id)
        if hist is None:
            print_error(f"Run ID not found: {run_id}")
            raise typer.Exit(1)
        previous_findings = hist
    else:
        # Auto-detect most recent historical run
        from guard.core.pipeline import list_historical_runs, load_historical_findings
        runs = list_historical_runs(config.output_dir)
        if runs:
            latest = runs[0]
            latest_id = latest.get("run_id", "")
            if latest_id:
                hist = load_historical_findings(config.output_dir, latest_id)
                if hist is not None:
                    previous_findings = hist
                    if not json_output:
                        console.print(f"[dim]Comparing against run {latest_id}[/dim]")

    comp = compare_runs(current_findings, previous_findings)

    if json_output:
        import json as _json
        result = {
            "new": len(comp.new_findings),
            "resolved": len(comp.resolved_findings),
            "unchanged": len(comp.unchanged_findings),
            "new_findings": [{"rule_id": f.rule_id, "severity": f.severity.value,
                              "file": f.evidence.file, "message": f.message}
                             for f in comp.new_findings],
            "resolved_findings": [{"rule_id": f.rule_id, "severity": f.severity.value,
                                   "file": f.evidence.file, "message": f.message}
                                  for f in comp.resolved_findings],
        }
        console.print(_json.dumps(result, indent=2))
    else:
        # Rich summary
        from rich.table import Table

        new_by_sev = {}
        for f in comp.new_findings:
            s = f.severity.value
            new_by_sev[s] = new_by_sev.get(s, 0) + 1
        resolved_by_sev = {}
        for f in comp.resolved_findings:
            s = f.severity.value
            resolved_by_sev[s] = resolved_by_sev.get(s, 0) + 1

        tbl = Table(title="Delta Analysis", show_header=True)
        tbl.add_column("", style="bold")
        tbl.add_column("Count", justify="right")
        tbl.add_column("Breakdown", style="dim")

        new_detail = ", ".join(f"{v} {k}" for k, v in sorted(new_by_sev.items())) or "—"
        resolved_detail = ", ".join(f"{v} {k}" for k, v in sorted(resolved_by_sev.items())) or "—"

        tbl.add_row("[red]+ New[/red]", str(len(comp.new_findings)), new_detail)
        tbl.add_row("[green]- Resolved[/green]", str(len(comp.resolved_findings)), resolved_detail)
        tbl.add_row("[dim]= Unchanged[/dim]", str(len(comp.unchanged_findings)), "")
        console.print(tbl)

        if comp.new_findings:
            console.print("\n[bold red]New findings:[/bold red]")
            for f in comp.new_findings[:10]:
                sev_style = SEV_STYLES.get(f.severity.value, "")
                console.print(f"  [{sev_style}]{f.severity.value.upper():8s}[/{sev_style}] "
                              f"`{f.rule_id}` {f.evidence.file} — {f.message}")
            if len(comp.new_findings) > 10:
                console.print(f"  [dim]... and {len(comp.new_findings) - 10} more[/dim]")

        if comp.resolved_findings:
            console.print(f"\n[bold green]Resolved: {len(comp.resolved_findings)} finding(s) fixed[/bold green]")

    # Write comparison report
    summary = render_comparison(comp)
    out = Path(config.output_dir)
    comp_path = out / "comparison.md"
    with open(comp_path, "w", encoding="utf-8") as f:
        f.write(summary)

    print_post_hint("compare")


@app.command(rich_help_panel="Governance")
def sync(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
):
    """Sync local work item states to the configured DevOps provider (Azure DevOps, GitHub, or Jira)."""
    config, _profile = _load_config(config_path)

    # Governance policy check — does sync require sign-off?
    gov = config.get_governance()
    policy = PolicyEngine(gov)
    audit = AuditLog(gov.audit)

    decision = policy.check_work_item_close()
    if decision.require_human_review:
        typer.echo("GOVERNANCE: Work item state changes require sign-off before syncing.")
        typer.echo("  Ensure changes have been reviewed and approved before running sync.")

    audit.log("sync_start", details={"provider": config.devops_provider}, decision=decision)

    if config.devops_provider == "github":
        _sync_github(config)
    elif config.devops_provider == "jira":
        _sync_jira(config)
    else:
        _sync_azure(config)

    audit.log("sync_complete", details={"provider": config.devops_provider})


def _sync_azure(config: GuardConfig) -> None:
    """Sync work item states to Azure DevOps."""
    import requests

    pat = os.environ.get("AZURE_DEVOPS_PAT")
    if not pat:
        ctx = get_error_context("azure_no_pat")
        if ctx:
            print_error_context(ctx)
        raise typer.Exit(1)

    org = config.azure_devops_org
    project = config.azure_devops_project
    if not org or not project:
        ctx = get_error_context("azure_missing_config")
        if ctx:
            print_error_context(ctx)
        raise typer.Exit(1)

    wi_path = Path(config.work_items_file)
    if not wi_path.exists():
        ctx = get_error_context("work_items_not_found")
        if ctx:
            print_error_context(ctx)
        raise typer.Exit(1)

    with wi_path.open() as f:
        items = json.load(f)

    state_map = {"active": "Doing", "closed": "Done", "new": "To Do"}
    updated = 0
    skipped = 0
    failed = 0

    for item in items:
        title = item["title"]
        desired = state_map.get(item["state"])
        if desired is None:
            typer.echo(f"[SKIP] Unknown state '{item['state']}' for: {title}")
            skipped += 1
            continue

        typer.echo(f"[SYNC] {title}")

        # WIQL query by title
        wiql_url = f"https://dev.azure.com/{org}/{project}/_apis/wit/wiql?api-version=7.1"
        wiql = {"query": f"SELECT [System.Id], [System.State] FROM WorkItems WHERE [System.Title] = '{title}'"}
        resp = requests.post(wiql_url, json=wiql, auth=("", pat), timeout=30)
        if resp.status_code != 200:
            typer.echo(f"  WIQL query failed ({resp.status_code}): {resp.text}")
            failed += 1
            continue

        work_items = resp.json().get("workItems", [])
        if len(work_items) == 0:
            typer.echo(f"  No DevOps work item found for title: {title}")
            skipped += 1
            continue
        if len(work_items) > 1:
            typer.echo(f"  Multiple matches ({len(work_items)}) for title: {title} — skipping")
            skipped += 1
            continue

        wi_id = work_items[0]["id"]

        # Fetch current state
        detail_url = f"https://dev.azure.com/{org}/{project}/_apis/wit/workitems/{wi_id}?api-version=7.1"
        detail_resp = requests.get(detail_url, auth=("", pat), timeout=30)
        if detail_resp.status_code != 200:
            typer.echo(f"  Failed to fetch work item {wi_id} ({detail_resp.status_code})")
            failed += 1
            continue

        current_state = detail_resp.json()["fields"]["System.State"]
        if current_state == desired:
            typer.echo(f"  Already '{desired}' — no change needed")
            skipped += 1
            continue

        # PATCH state
        typer.echo(f"  Updating {wi_id}: '{current_state}' -> '{desired}'")
        patch_url = f"https://dev.azure.com/{org}/{project}/_apis/wit/workitems/{wi_id}?api-version=7.1"
        payload = [{"op": "replace", "path": "/fields/System.State", "value": desired}]
        patch_resp = requests.patch(
            patch_url, json=payload, auth=("", pat),
            headers={"Content-Type": "application/json-patch+json"}, timeout=30,
        )
        if patch_resp.status_code == 200:
            updated += 1
        else:
            typer.echo(f"  PATCH failed ({patch_resp.status_code}): {patch_resp.text}")
            failed += 1

    typer.echo(f"\nDone: {updated} updated, {skipped} skipped, {failed} failed")


def _sync_github(config: GuardConfig) -> None:
    """Sync work item states to GitHub Issues."""
    import urllib.request
    import urllib.error

    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        typer.echo("Error: GITHUB_TOKEN environment variable is not set.", err=True)
        raise typer.Exit(1)

    owner = config.github_owner
    repo = config.github_repo
    if not owner or not repo:
        typer.echo("Error: github_owner and github_repo must be set in config.", err=True)
        raise typer.Exit(1)

    wi_path = Path(config.work_items_file)
    if not wi_path.exists():
        typer.echo(f"Error: work items file not found: {wi_path}", err=True)
        raise typer.Exit(1)

    with wi_path.open() as f:
        items = json.load(f)

    updated = 0
    skipped = 0
    failed = 0

    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}",
        "X-GitHub-Api-Version": "2022-11-28",
    }

    for item in items:
        title = item["title"]
        local_state = item["state"]

        # Map guard state to GitHub state
        if local_state == "closed":
            desired = "closed"
        elif local_state in ("active", "new"):
            desired = "open"
        else:
            typer.echo(f"[SKIP] Unknown state '{local_state}' for: {title}")
            skipped += 1
            continue

        typer.echo(f"[SYNC] {title}")

        # Search for issue by title
        search_url = (
            f"https://api.github.com/search/issues?"
            f"q={urllib.request.quote(f'repo:{owner}/{repo} is:issue in:title {title}')}"
        )
        req = urllib.request.Request(search_url, headers=headers)
        try:
            with urllib.request.urlopen(req) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except (urllib.error.HTTPError, urllib.error.URLError) as exc:
            typer.echo(f"  Search failed: {exc}")
            failed += 1
            continue

        matches = data.get("items", [])
        # Filter to exact title match
        exact = [m for m in matches if m.get("title") == title]
        if len(exact) == 0:
            typer.echo(f"  No GitHub issue found for title: {title}")
            skipped += 1
            continue
        if len(exact) > 1:
            typer.echo(f"  Multiple matches ({len(exact)}) for title: {title} — skipping")
            skipped += 1
            continue

        issue = exact[0]
        issue_number = issue["number"]
        current_state = issue["state"]

        if current_state == desired:
            typer.echo(f"  Already '{desired}' — no change needed")
            skipped += 1
            continue

        # PATCH issue state
        typer.echo(f"  Updating #{issue_number}: '{current_state}' -> '{desired}'")
        patch_url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}"
        patch_data = json.dumps({"state": desired}).encode("utf-8")
        patch_req = urllib.request.Request(
            patch_url, data=patch_data, headers=headers, method="PATCH",
        )
        try:
            with urllib.request.urlopen(patch_req) as resp:
                if resp.status == 200:
                    updated += 1
                else:
                    typer.echo(f"  PATCH returned status {resp.status}")
                    failed += 1
        except (urllib.error.HTTPError, urllib.error.URLError) as exc:
            typer.echo(f"  PATCH failed: {exc}")
            failed += 1

    typer.echo(f"\nDone: {updated} updated, {skipped} skipped, {failed} failed")


def _sync_jira(config: GuardConfig) -> None:
    """Sync work item states to Jira Issues."""
    import urllib.request
    import urllib.error
    from base64 import b64encode

    user = os.environ.get("JIRA_USER", "")
    token = os.environ.get("JIRA_TOKEN", "")
    pat = os.environ.get("JIRA_PAT", "")

    if not (user and token) and not pat:
        typer.echo("Error: JIRA_USER + JIRA_TOKEN or JIRA_PAT environment variables must be set.", err=True)
        raise typer.Exit(1)

    base_url = config.jira_base_url
    if not base_url:
        typer.echo("Error: jira_base_url must be set in config.", err=True)
        raise typer.Exit(1)

    wi_path = Path(config.work_items_file)
    if not wi_path.exists():
        typer.echo(f"Error: work items file not found: {wi_path}", err=True)
        raise typer.Exit(1)

    with wi_path.open() as f:
        items = json.load(f)

    headers: dict[str, str] = {
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    if user and token:
        credentials = b64encode(f"{user}:{token}".encode()).decode()
        headers["Authorization"] = f"Basic {credentials}"
    elif pat:
        headers["Authorization"] = f"Bearer {pat}"

    # Map guard states to Jira transition targets
    state_map = {"active": "In Progress", "closed": "Done", "new": "To Do"}
    updated = 0
    skipped = 0
    failed = 0

    for item in items:
        title = item["title"]
        desired = state_map.get(item["state"])
        if desired is None:
            typer.echo(f"[SKIP] Unknown state '{item['state']}' for: {title}")
            skipped += 1
            continue

        typer.echo(f"[SYNC] {title}")

        # Search for issue by summary
        project_key = config.jira_project_key
        jql = urllib.request.quote(
            f'project = {project_key} AND summary ~ "{title}"'
        )
        search_url = (
            f"{base_url.rstrip('/')}/rest/api/2/search"
            f"?jql={jql}&maxResults=5&fields=summary,status"
        )
        req = urllib.request.Request(search_url, headers=headers)
        try:
            with urllib.request.urlopen(req) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except (urllib.error.HTTPError, urllib.error.URLError) as exc:
            typer.echo(f"  Search failed: {exc}")
            failed += 1
            continue

        issues = data.get("issues", [])
        exact = [i for i in issues if (i.get("fields", {}).get("summary") or "") == title]
        if len(exact) == 0:
            typer.echo(f"  No Jira issue found for title: {title}")
            skipped += 1
            continue
        if len(exact) > 1:
            typer.echo(f"  Multiple matches ({len(exact)}) for title: {title} — skipping")
            skipped += 1
            continue

        issue = exact[0]
        issue_key = issue["key"]
        current_status = (issue.get("fields", {}).get("status") or {}).get("name", "")

        if current_status.lower() == desired.lower():
            typer.echo(f"  Already '{desired}' — no change needed")
            skipped += 1
            continue

        # Get available transitions
        trans_url = f"{base_url.rstrip('/')}/rest/api/2/issue/{issue_key}/transitions"
        req = urllib.request.Request(trans_url, headers=headers)
        try:
            with urllib.request.urlopen(req) as resp:
                trans_data = json.loads(resp.read().decode("utf-8"))
        except (urllib.error.HTTPError, urllib.error.URLError) as exc:
            typer.echo(f"  Failed to get transitions: {exc}")
            failed += 1
            continue

        transitions = trans_data.get("transitions", [])
        target = None
        for t in transitions:
            if t.get("name", "").lower() == desired.lower():
                target = t
                break
            if t.get("to", {}).get("name", "").lower() == desired.lower():
                target = t
                break

        if target is None:
            typer.echo(f"  No transition to '{desired}' available for {issue_key}")
            skipped += 1
            continue

        # Execute transition
        typer.echo(f"  Transitioning {issue_key}: '{current_status}' -> '{desired}'")
        payload = json.dumps({"transition": {"id": target["id"]}}).encode("utf-8")
        trans_req = urllib.request.Request(
            trans_url, data=payload, headers=headers, method="POST",
        )
        try:
            with urllib.request.urlopen(trans_req) as resp:
                if resp.status in (200, 204):
                    updated += 1
                else:
                    typer.echo(f"  Transition returned status {resp.status}")
                    failed += 1
        except (urllib.error.HTTPError, urllib.error.URLError) as exc:
            typer.echo(f"  Transition failed: {exc}")
            failed += 1

    typer.echo(f"\nDone: {updated} updated, {skipped} skipped, {failed} failed")


@app.command(name="gap-analysis", rich_help_panel="Reports")
def gap_analysis_cmd(
    pack_id: str = typer.Argument(help="Pack ID to analyze (e.g. 'owasp-top-10')."),
    old_file: str = typer.Argument(help="Path to the previous version of the pack YAML."),
    output: str = typer.Option(None, "--output", "-o", help="Output file path (default: stdout)."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON."),
):
    """Generate a regulatory gap analysis between pack versions.

    Compares the current pack against a previous version and identifies
    new obligations, strengthened rules, relaxed rules, and removed
    controls. Useful when regulatory standards are updated.
    """
    from guard.core.gap_analysis import analyze_gap, format_gap_report

    old_path = Path(old_file)
    if not old_path.is_file():
        typer.echo(f"Error: file not found: {old_file}", err=True)
        raise typer.Exit(1)

    try:
        analysis = analyze_gap(pack_id, old_pack_path=old_path)
    except ValueError as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(1)

    if json_output:
        content = json.dumps(analysis, indent=2)
    else:
        content = format_gap_report(analysis)

    if output:
        Path(output).write_text(content, encoding="utf-8")
        typer.echo(f"Gap analysis written to {output}")
    else:
        typer.echo(content)


@app.command(name="diff-packs", rich_help_panel="Standards")
def diff_packs_cmd(
    pack_id: str = typer.Argument(help="Pack ID to diff (e.g. 'owasp-top-10')."),
    old_file: str = typer.Argument(help="Path to the old version of the pack YAML."),
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON."),
):
    """Diff a standards pack against an older version.

    Compares the current built-in or custom pack against a previous version
    YAML file and reports added, removed, and modified rules.
    """
    import yaml as _yaml
    from guard.packs.registry import diff_pack_rules, load_pack_rules

    old_path = Path(old_file)
    if not old_path.is_file():
        typer.echo(f"Error: file not found: {old_file}", err=True)
        raise typer.Exit(1)

    try:
        old_raw = _yaml.safe_load(old_path.read_text(encoding="utf-8"))
    except Exception as exc:
        typer.echo(f"Error: failed to parse YAML: {exc}", err=True)
        raise typer.Exit(1)

    old_rules = old_raw.get("rules", [])
    new_rules = load_pack_rules(pack_id)
    if not new_rules:
        typer.echo(f"Error: pack {pack_id!r} not found.", err=True)
        raise typer.Exit(1)

    result = diff_pack_rules(old_rules, new_rules)

    if json_output:
        typer.echo(json.dumps(result, indent=2))
        return

    old_ver = old_raw.get("version", "?")
    typer.echo(f"\nPack: {pack_id}  (old: v{old_ver} -> current)")
    typer.echo(f"  Added:     {len(result['added'])} rules")
    typer.echo(f"  Removed:   {len(result['removed'])} rules")
    typer.echo(f"  Modified:  {len(result['modified'])} rules")
    typer.echo(f"  Unchanged: {len(result['unchanged'])} rules")

    if result["added"]:
        typer.echo("\n  New rules:")
        for rid in result["added"]:
            typer.echo(f"    + {rid}")
    if result["removed"]:
        typer.echo("\n  Removed rules:")
        for rid in result["removed"]:
            typer.echo(f"    - {rid}")
    if result["modified"]:
        typer.echo("\n  Modified rules:")
        for rid in result["modified"]:
            typer.echo(f"    ~ {rid}")
            for change in result["details"].get(rid, []):
                typer.echo(f"      {change}")
    typer.echo("")


@app.command(name="list-packs", rich_help_panel="Standards")
def list_packs(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """List available standards packs and their enabled status."""
    config, _profile = _load_config(config_path)
    packs = list_available_packs()

    if not packs:
        if json_output:
            typer.echo("[]")
        else:
            typer.echo("No standards packs available.")
        return

    from guard.packs.registry import pack_tier

    enabled_set = set(config.standards_packs)

    if json_output:
        import json
        data = []
        for p in packs:
            data.append({
                "id": p.pack_id,
                "name": p.name,
                "description": p.description,
                "source": p.source,
                "rules": p.rule_count,
                "tier": pack_tier(p.pack_id).lower(),
                "enabled": p.pack_id in enabled_set,
                "custom": p.source == "custom",
            })
        typer.echo(json.dumps(data, indent=2))
        return

    typer.echo(f"{'PACK ID':<25} {'SOURCE':<10} {'STATUS':<10} {'TIER':<8} {'RULES':<8} {'NAME'}")
    typer.echo("-" * 90)
    for p in packs:
        status = "ENABLED" if p.pack_id in enabled_set else "available"
        tier = pack_tier(p.pack_id)
        typer.echo(f"{p.pack_id:<25} {p.source:<10} {status:<10} {tier:<8} {p.rule_count:<8} {p.name}")

    typer.echo(f"\nTotal: {len(packs)} pack(s), {len(enabled_set)} enabled")
    print_post_hint("list_packs")


@app.command(name="add-pack", rich_help_panel="Standards")
def add_pack(
    pack_id: str = typer.Argument(help="Standards pack ID to enable (e.g. fda-iec-62304)."),
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
):
    """Enable a standards pack by adding it to .guard.yaml."""
    config, _profile = _load_config(config_path)

    if pack_id in config.standards_packs:
        typer.echo(f"Pack {pack_id!r} is already enabled.")
        return

    # Validate the pack exists (built-in or custom)
    if not is_known_pack(pack_id):
        available = [p.pack_id for p in list_available_packs()]
        typer.echo(f"Error: unknown pack {pack_id!r}. Available: {', '.join(sorted(available))}", err=True)
        raise typer.Exit(1)

    # License-gate packs by tier
    from guard.packs.registry import pack_tier as _pack_tier
    from guard.providers.factory import _pack_allowed
    from guard.core.licensing import get_license_info
    license_info = get_license_info(config.license_key)
    if not _pack_allowed(pack_id, license_info, config.license_key or ""):
        tier_needed = _pack_tier(pack_id)
        typer.echo(
            f"Error: pack {pack_id!r} requires a {tier_needed}-tier license or higher.\n"
            "  Run 'sentrik license' for details or visit https://sentrik.dev",
            err=True,
        )
        raise typer.Exit(1)

    config.standards_packs.append(pack_id)
    path = config.save(Path(config_path) if config_path else None)
    typer.echo(f"Added pack {pack_id!r} to {path}")
    print_post_hint("add_pack")


@app.command(name="remove-pack", rich_help_panel="Standards")
def remove_pack(
    pack_id: str = typer.Argument(help="Standards pack ID to disable."),
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
):
    """Disable a standards pack by removing it from .guard.yaml."""
    config, _profile = _load_config(config_path)

    if pack_id not in config.standards_packs:
        typer.echo(f"Pack {pack_id!r} is not currently enabled.")
        return

    config.standards_packs.remove(pack_id)
    path = config.save(Path(config_path) if config_path else None)
    typer.echo(f"Removed pack {pack_id!r} from {path}")
    print_post_hint("remove_pack")


@app.command(name="import-pack", rich_help_panel="Standards")
def import_pack_cmd(
    file: str = typer.Argument(help="Path to YAML file to import as a standards pack."),
    pack_id: str = typer.Option(None, "--id", help="Pack ID (defaults to directory/file stem)."),
    overwrite: bool = typer.Option(False, "--overwrite", help="Overwrite existing pack."),
    enable: bool = typer.Option(False, "--enable", help="Enable pack in config after import."),
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
):
    """Import a custom standards pack from a YAML file."""
    from guard.core.licensing import LicenseError, require_license
    import yaml as _yaml

    config, _profile = _load_config(config_path)
    try:
        require_license("custom_packs", config.license_key)
    except LicenseError as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(1)

    file_path = Path(file)
    if not file_path.is_file():
        typer.echo(f"Error: file not found: {file}", err=True)
        raise typer.Exit(1)

    try:
        raw = _yaml.safe_load(file_path.read_text(encoding="utf-8"))
    except Exception as exc:
        typer.echo(f"Error: failed to parse YAML: {exc}", err=True)
        raise typer.Exit(1)

    errors = validate_pack_yaml(raw)
    if errors:
        typer.echo("Validation errors:", err=True)
        for e in errors:
            typer.echo(f"  - {e}", err=True)
        raise typer.Exit(1)

    resolved_id = pack_id or file_path.stem
    try:
        dest = registry_import_pack(resolved_id, raw, overwrite=overwrite)
    except ValueError as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(1)

    typer.echo(f"Imported pack {resolved_id!r} to {dest}")

    if enable:
        config, _profile = _load_config(config_path)
        if resolved_id not in config.standards_packs:
            config.standards_packs.append(resolved_id)
            cfg_path = config.save(Path(config_path) if config_path else None)
            typer.echo(f"Enabled pack {resolved_id!r} in {cfg_path}")


@app.command(name="export-pack", rich_help_panel="Standards")
def export_pack_cmd(
    pack_id: str = typer.Argument(help="Standards pack ID to export."),
    output: str = typer.Option(None, "--output", "-o", help="Output file path (default: stdout)."),
):
    """Export a standards pack to YAML."""
    import yaml as _yaml

    try:
        raw = registry_export_pack(pack_id)
    except ValueError as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(1)

    content = _yaml.dump(raw, default_flow_style=False, sort_keys=False)
    if output:
        Path(output).write_text(content, encoding="utf-8")
        typer.echo(f"Exported pack {pack_id!r} to {output}")
    else:
        typer.echo(content)


@app.command(name="import-spec", rich_help_panel="Standards")
def import_spec_cmd(
    file: str = typer.Argument(help="Path to API spec file (OpenAPI YAML, AsyncAPI YAML, or .proto)."),
    fmt: str = typer.Option(None, "--format", "-f", help="Spec format: openapi, asyncapi, protobuf (auto-detected if omitted)."),
    pack_id: str = typer.Option(None, "--id", help="Pack ID (defaults to spec title/package name)."),
    overwrite: bool = typer.Option(False, "--overwrite", help="Overwrite existing pack."),
    enable: bool = typer.Option(False, "--enable", help="Enable pack in config after import."),
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
):
    """Generate security rules from an API specification file.

    Reads an OpenAPI 3.x, AsyncAPI 2.x/3.x, or protobuf spec and generates
    a Sentrik rule pack that enforces the spec's security contract:

    - Authentication requirements per endpoint/channel/RPC
    - Input validation for unbounded string fields
    - Sensitive data exposure in responses/payloads
    - TLS/HTTPS enforcement
    - Path parameter validation
    """
    from guard.spec_importer import import_spec, detect_format, SUPPORTED_FORMATS

    file_path = Path(file)
    if not file_path.is_file():
        typer.echo(f"Error: file not found: {file}", err=True)
        raise typer.Exit(1)

    try:
        pack_data = import_spec(file_path, fmt=fmt)
    except ValueError as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(1)
    except Exception as exc:
        typer.echo(f"Error: failed to parse spec: {exc}", err=True)
        raise typer.Exit(1)

    rule_count = len(pack_data.get("rules", []))
    if rule_count == 0:
        typer.echo("No rules generated — the spec may be empty or contain no security-relevant declarations.")
        raise typer.Exit()

    # Validate generated pack
    errors = validate_pack_yaml(pack_data)
    if errors:
        typer.echo("Generated pack has validation errors:", err=True)
        for e in errors:
            typer.echo(f"  - {e}", err=True)
        raise typer.Exit(1)

    # Resolve pack ID
    resolved_id = pack_id or _sanitize_pack_id(pack_data.get("name", file_path.stem))

    try:
        dest = registry_import_pack(resolved_id, pack_data, overwrite=overwrite)
    except ValueError as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(1)

    typer.echo(f"Generated {rule_count} rules from {file_path.name}")
    typer.echo(f"Imported pack {resolved_id!r} to {dest}")

    if enable:
        config, _profile = _load_config(config_path)
        if resolved_id not in config.standards_packs:
            config.standards_packs.append(resolved_id)
            cfg_path = config.save(Path(config_path) if config_path else None)
            typer.echo(f"Enabled pack {resolved_id!r} in {cfg_path}")


def _sanitize_pack_id(name: str) -> str:
    """Convert a pack name to a valid kebab-case pack ID."""
    import re as _re
    slug = _re.sub(r"[^a-zA-Z0-9]+", "-", name).strip("-").lower()
    return slug[:60]


def _pidfile_path(port: int) -> Path:
    """Return the PID file path for a server on the given port."""
    return Path(".sentrik", "local", f"server-{port}.pid")


def _read_pid(port: int) -> int | None:
    """Read PID from pidfile. Returns None if missing or invalid."""
    pf = _pidfile_path(port)
    if not pf.exists():
        return None
    try:
        return int(pf.read_text().strip())
    except (ValueError, OSError):
        return None


def _is_pid_alive(pid: int) -> bool:
    """Check if a process with the given PID is running."""
    import signal
    if sys.platform == "win32":
        import ctypes
        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if handle:
            kernel32.CloseHandle(handle)
            return True
        return False
    else:
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False


def _kill_pid(pid: int) -> bool:
    """Kill a process by PID. Returns True on success."""
    import signal
    try:
        if sys.platform == "win32":
            import subprocess
            subprocess.run(["taskkill", "/F", "/PID", str(pid)],
                           capture_output=True, check=True)
        else:
            os.kill(pid, signal.SIGTERM)
        return True
    except (OSError, subprocess.CalledProcessError):
        return False


def _write_pid(port: int) -> None:
    """Write current PID to pidfile."""
    pf = _pidfile_path(port)
    pf.parent.mkdir(parents=True, exist_ok=True)
    pf.write_text(str(os.getpid()))


def _remove_pid(port: int) -> None:
    """Remove the pidfile."""
    pf = _pidfile_path(port)
    try:
        pf.unlink(missing_ok=True)
    except OSError:
        pass


@app.command(name="dashboard", rich_help_panel="Core")
def serve(
    host: str = typer.Option("127.0.0.1", "--host", help="Host to bind to (use 0.0.0.0 for network access)."),
    port: int = typer.Option(8000, "--port", "-p", help="Port to bind to."),
    reload: bool = typer.Option(False, "--reload", help="Enable auto-reload for development."),
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    project_dir: str = typer.Option(None, "--dir", "-d", help="Project directory to serve from."),
    stop: bool = typer.Option(False, "--stop", help="Stop a running server on this port."),
    force: bool = typer.Option(False, "--force", help="Kill existing server and restart."),
    open_browser: bool = typer.Option(True, "--open/--no-open", help="Open the dashboard in a browser window."),
):
    """Start the REST API server."""
    import atexit
    import os

    if project_dir:
        project_dir = os.path.abspath(project_dir)
        os.environ["SENTRIK_PROJECT_DIR"] = project_dir
        os.chdir(project_dir)
        typer.echo(f"Working directory: {project_dir}")

    # --stop: kill existing server and exit
    if stop:
        pid = _read_pid(port)
        if pid and _is_pid_alive(pid):
            if _kill_pid(pid):
                _remove_pid(port)
                typer.echo(f"Stopped SENTRIK server (PID {pid}) on port {port}.")
            else:
                print_error(f"Failed to stop server (PID {pid}).")
                raise typer.Exit(1)
        else:
            _remove_pid(port)
            typer.echo(f"No running server found on port {port}.")
        return

    # Check for existing server on this port
    existing_pid = _read_pid(port)
    if existing_pid and _is_pid_alive(existing_pid):
        if force:
            typer.echo(f"Stopping existing server (PID {existing_pid}) on port {port}...")
            _kill_pid(existing_pid)
            _remove_pid(port)
            import time
            time.sleep(1)
        else:
            print_error(f"Server already running on port {port} (PID {existing_pid}).")
            print_hint("Use --force to restart, or --stop to shut it down.")
            raise typer.Exit(1)
    elif existing_pid:
        # Stale pidfile — process is gone
        _remove_pid(port)

    from guard.core.licensing import LicenseError, require_license

    # License check — api feature is available on all tiers; catches expired keys
    config, _profile = _load_config(config_path)
    try:
        require_license("api", config.license_key)
    except LicenseError as exc:
        typer.echo(f"License error: {exc}", err=True)
        raise typer.Exit(1)

    try:
        import uvicorn
    except ImportError:
        ctx = get_error_context("server_missing_deps")
        if ctx:
            print_error_context(ctx)
        else:
            print_error("Server requires FastAPI + Uvicorn.")
            print_hint("Install with: pip install sentrik[server]")
        raise typer.Exit(1)

    # Write PID file and register cleanup
    _write_pid(port)
    atexit.register(_remove_pid, port)

    # Security: auto-generate API key when exposed to network without auth
    is_network_exposed = host not in ("127.0.0.1", "localhost", "::1")
    api_key = os.environ.get("GUARD_API_KEY")
    if is_network_exposed and not api_key:
        import secrets as _secrets
        generated_key = _secrets.token_urlsafe(24)
        os.environ["GUARD_API_KEY"] = generated_key
        typer.echo(f"\n⚠  Binding to {host} without GUARD_API_KEY — auto-generated key:")
        typer.echo(f"   X-API-Key: {generated_key}")
        typer.echo(f"   Set GUARD_API_KEY to use a persistent key.\n")

    display_host = "localhost" if host in ("0.0.0.0", "::") else host
    dashboard_url = f"http://{display_host}:{port}/dashboard"
    typer.echo(f"Starting SENTRIK server on {host}:{port}")
    typer.echo(f"SENTRIK Dashboard: {dashboard_url}")

    if open_browser:
        import subprocess as _sp
        import shutil
        import threading

        def _open_dashboard():
            import time
            time.sleep(1.5)  # wait for uvicorn to start
            # Try app mode (Chrome/Edge) for a native-app feel
            browsers = [
                shutil.which("msedge") or r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                shutil.which("chrome") or shutil.which("google-chrome"),
                shutil.which("chromium"),
            ]
            for browser in browsers:
                if browser and Path(browser).exists():
                    try:
                        _sp.Popen([browser, f"--app={dashboard_url}"], stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)
                        return
                    except OSError:
                        continue
            # Fallback: open in default browser
            import webbrowser
            webbrowser.open(dashboard_url)

        threading.Thread(target=_open_dashboard, daemon=True).start()

    try:
        uvicorn.run("guard.server:app", host=host, port=port, reload=reload)
    finally:
        _remove_pid(port)


@app.command(name="metrics", rich_help_panel="Analysis")
def code_metrics(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    top: int = typer.Option(20, "--top", "-n", help="Number of files to show."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON."),
):
    """Show code metrics per file: lines, complexity, nesting, functions.

    Analyzes all source files in the project and shows the largest/most
    complex files first.
    """
    from rich.table import Table
    from guard.core.code_metrics import analyze_directory
    from guard.core.repo_reader import find_repo_root

    config, _profile = _load_config(config_path)
    repo_root = str(find_repo_root())
    results = analyze_directory(repo_root)

    if json_output:
        import json as _json
        data = [{"file": m.file, "total_lines": m.total_lines, "code_lines": m.code_lines,
                 "blank_lines": m.blank_lines, "comment_lines": m.comment_lines,
                 "max_nesting": m.max_nesting, "function_count": m.function_count}
                for m in results[:top]]
        console.print(_json.dumps(data, indent=2))
    else:
        tbl = Table(title=f"Code Metrics (top {min(top, len(results))} of {len(results)} files)")
        tbl.add_column("File", style="cyan", max_width=50)
        tbl.add_column("Lines", justify="right")
        tbl.add_column("Code", justify="right")
        tbl.add_column("Comments", justify="right")
        tbl.add_column("Nesting", justify="right")
        tbl.add_column("Functions", justify="right")

        for m in results[:top]:
            rel = m.file
            try:
                rel = str(Path(m.file).relative_to(repo_root))
            except ValueError:
                pass
            nesting_style = "bold red" if m.max_nesting > 6 else "yellow" if m.max_nesting > 4 else ""
            tbl.add_row(
                rel, str(m.total_lines), str(m.code_lines),
                str(m.comment_lines),
                f"[{nesting_style}]{m.max_nesting}[/{nesting_style}]" if nesting_style else str(m.max_nesting),
                str(m.function_count),
            )

        console.print(tbl)

        # Summary
        total_code = sum(m.code_lines for m in results)
        total_funcs = sum(m.function_count for m in results)
        max_nest = max((m.max_nesting for m in results), default=0)
        console.print(f"\n[dim]{len(results)} files · {total_code:,} lines of code · "
                      f"{total_funcs} functions · max nesting: {max_nest}[/dim]")

    print_post_hint("metrics")


@app.command(name="install-check", rich_help_panel="Admin")
def install_check(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
):
    """Verify installation and display system information for customer onboarding."""
    import platform

    from guard import __version__
    from guard.core.licensing import get_license_info, TIER_DISPLAY

    typer.echo("\n  SENTRIK — Installation Check\n")

    # Version info
    typer.echo(f"  Version:  {__version__}")
    typer.echo(f"  Python:   {sys.version.split()[0]}")
    typer.echo(f"  Platform: {platform.system()} {platform.machine()}")

    # License status
    try:
        config, _profile = _load_config(config_path)
        info = get_license_info(config.license_key)
    except (OSError, ValueError, KeyError):
        config = None
        info = get_license_info("")

    typer.echo(f"\n  License:  {info.message}")
    if info.tier:
        typer.echo(f"  Tier:     {TIER_DISPLAY.get(info.tier, info.tier)}")
    if info.expired:
        typer.echo("  STATUS:   EXPIRED")

    # Config detection
    config_found = False
    for name in [".guard.yaml", ".guard.yml"]:
        if Path(name).exists():
            typer.echo(f"\n  Config:   {name} (found)")
            config_found = True
            break
    if not config_found:
        typer.echo("\n  Config:   not found (run 'sentrik init' to create)")

    # Optional dependencies check
    typer.echo("\n  Optional Dependencies:")
    for dep, label in [
        ("fastapi", "FastAPI (server)"),
        ("uvicorn", "Uvicorn (server)"),
        ("httpx", "httpx (testing)"),
    ]:
        try:
            __import__(dep)
            typer.echo(f"    {label:<25} installed")
        except ImportError:
            typer.echo(f"    {label:<25} not installed")

    # Quick start guide
    typer.echo("\n  Quick Start:")
    typer.echo("    sentrik init            — create configuration")
    typer.echo("    sentrik scan            — run your first scan")
    typer.echo("    sentrik gate            — enforce quality gate")
    typer.echo("    sentrik dashboard           — start API server")
    typer.echo(f"\n  Docs: https://docs.sentrik.dev")
    typer.echo()


@app.command(rich_help_panel="Admin")
def license(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """Show license status and feature availability."""
    from guard.core.licensing import get_license_info, check_license_online, TIER_DISPLAY, TIER_FEATURES

    config, _profile = _load_config(config_path)
    info = get_license_info(config.license_key)

    if json_output:
        import json
        data = {
            "valid": info.valid,
            "tier": info.tier,
            "expiry": info.expiry.isoformat() if info.expiry else None,
            "expired": info.expired,
            "features": sorted(info.features),
            "message": info.message,
        }
        typer.echo(json.dumps(data, indent=2))
        return

    typer.echo(f"\n  License Status")
    typer.echo(f"  {'Valid' if info.valid else 'Invalid'}: {info.message}")
    if info.tier:
        typer.echo(f"  Tier: {TIER_DISPLAY.get(info.tier, info.tier)}")
    if info.expiry:
        typer.echo(f"  Expires: {info.expiry.isoformat()}")
    if info.expired:
        typer.echo("  STATUS: EXPIRED")
    typer.echo(f"\n  Features: {', '.join(sorted(info.features)) if info.features else 'none'}")

    # Online status
    if config.online_license_check and config.license_key:
        online = check_license_online(config.license_key, config.portal_url)
        if online.checked:
            status = "valid" if online.valid else "invalid/expired"
            cached = " (cached)" if online.cached else ""
            typer.echo(f"\n  Online: {status}, {online.days_remaining} day(s) remaining{cached}")
        elif online.error:
            typer.echo(f"\n  Online: unavailable ({online.error})")

    # Auth status
    from guard.auth.device_flow import load_tokens
    tokens = load_tokens()
    if tokens:
        typer.echo("  Auth: logged in")
    else:
        typer.echo("  Auth: not logged in (run 'sentrik login')")
    print_post_hint("license")


@app.command(rich_help_panel="Admin")
def login():
    """Authenticate with SENTRIK platform via browser (Auth0 device flow)."""
    from guard.auth.device_flow import (
        request_device_code, poll_for_tokens, save_tokens,
    )
    import webbrowser

    try:
        device = request_device_code()
    except ValueError as e:
        typer.echo(f"Error: {e}")
        raise typer.Exit(1)

    typer.echo(f"\n  Open this URL in your browser:\n    {device.verification_uri_complete}")
    typer.echo(f"\n  Or go to {device.verification_uri} and enter code: {device.user_code}\n")

    # Try to open browser automatically
    try:
        webbrowser.open(device.verification_uri_complete)
    except (OSError, webbrowser.Error):
        pass

    typer.echo("  Waiting for authorization...")
    try:
        tokens = poll_for_tokens(device_code=device.device_code, interval=device.interval)
        save_tokens(tokens)
        typer.echo("  Logged in successfully.")
    except TimeoutError:
        typer.echo("  Authorization timed out. Please try again.")
        raise typer.Exit(1)
    except PermissionError:
        typer.echo("  Authorization denied.")
        raise typer.Exit(1)


@app.command(rich_help_panel="Admin")
def logout():
    """Clear stored authentication tokens."""
    from guard.auth.device_flow import clear_tokens

    if clear_tokens():
        typer.echo("  Logged out — tokens cleared.")
    else:
        typer.echo("  No stored tokens found.")




@app.command(name="next-action", rich_help_panel="Core")
def next_action_cmd(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    count: int = typer.Option(3, "--count", "-n", help="Number of actions to show."),
):
    """Show the top fixable findings from the latest scan.

    Prioritizes by: severity (critical first), then auto-fixable, then
    those with remediation guidance. Shows only actionable items.
    """
    config, _profile = _load_config(config_path)
    findings_path = Path(config.output_dir) / "findings.json"

    if not findings_path.is_file():
        print_error("No findings.json found. Run 'sentrik scan' first.")
        raise typer.Exit(1)

    raw = json.loads(findings_path.read_text(encoding="utf-8"))

    # Filter to actionable (non-obligation, has file)
    actionable = [
        f for f in raw
        if not f.get("is_obligation")
        and f.get("evidence", {}).get("file", "") != "<project>"
    ]

    if not actionable:
        print_success("No actionable findings. Your code is clean!")
        raise typer.Exit()

    # Score and sort: severity weight + autofix bonus + guidance bonus
    _SEV_WEIGHT = {"critical": 100, "high": 80, "medium": 50, "low": 20, "info": 5}

    def _score(f):
        s = _SEV_WEIGHT.get(f.get("severity", "info"), 0)
        if f.get("suggestion"):
            s += 10
        if f.get("remediation_guidance"):
            s += 5
        return s

    actionable.sort(key=_score, reverse=True)
    top = actionable[:count]

    typer.echo(f"\nTop {len(top)} action(s) from {len(actionable)} fixable findings:\n")
    for i, f in enumerate(top, 1):
        sev = f.get("severity", "info").upper()
        file_path = f["evidence"].get("file", "")
        lines = f["evidence"].get("lines", [])
        loc = file_path
        if lines:
            loc += f":{lines[0]}"

        typer.echo(f"  {i}. [{sev}] {f.get('rule_id', '')} — {f.get('message', '')[:120]}")
        typer.echo(f"     File: {loc}")
        if f.get("suggestion"):
            typer.echo(f"     Fix: {f['suggestion'][:150]}")
        elif f.get("remediation_guidance"):
            typer.echo(f"     Guidance: {f['remediation_guidance'][:150]}")
        typer.echo("")

    remaining = len(actionable) - len(top)
    if remaining > 0:
        typer.echo(f"  ...and {remaining} more. Run 'sentrik scan' for full list.")
    typer.echo("  Apply auto-fixes: sentrik apply-patches")


@app.command(rich_help_panel="Core")
def guide():
    """Interactive command guide — shows workflow, command groups, and quick-start examples."""
    from rich.panel import Panel as RichPanel

    console.print(RichPanel(
        "[bold]SENTRIK[/bold] — Governance runtime for AI coding agents",
        border_style="blue",
    ))

    console.print("\n[bold]Typical Workflow[/bold]\n")
    workflow = [
        ("1.", "[bold]sentrik init[/bold]", "Create .sentrik/config.yaml configuration"),
        ("2.", "[bold]sentrik scan[/bold]", "Scan code against rules and standards"),
        ("3.", "[bold]sentrik gate[/bold]", "Enforce quality gate (CI/CD exit code)"),
        ("4.", "[bold]sentrik reconcile[/bold]", "Sync findings to DevOps work items"),
        ("5.", "[bold]sentrik dashboard[/bold]", "Open the management dashboard"),
    ]
    for num, cmd, desc in workflow:
        console.print(f"  {num} {cmd:<30} {desc}")

    console.print("\n[bold]Command Groups[/bold]\n")
    groups = [
        ("[cyan]Core[/cyan]", "init, scan, gate, validate-config, context, guide"),
        ("[cyan]Governance[/cyan]", "reconcile, sync, apply-patches, generate-reqs"),
        ("[cyan]Standards[/cyan]", "list-packs, add-pack, remove-pack, import-pack, export-pack"),
        ("[cyan]Admin[/cyan]", "serve, list-rules, report, compare, license, install-check"),
    ]
    for group, cmds in groups:
        console.print(f"  {group:<20} {cmds}")

    console.print("\n[bold]Quick Start[/bold]\n")
    console.print("  sentrik init                       # Guided setup wizard")
    console.print("  sentrik scan                       # Run your first scan")
    console.print("  sentrik scan --staged              # Scan only staged files")
    console.print("  sentrik gate --decorate-pr         # Gate with PR decoration")
    console.print("  sentrik dashboard                      # Dashboard at http://localhost:8000")
    console.print("  sentrik test-connection             # Verify DevOps connectivity")

    console.print("\n[bold]Common Options[/bold]\n")
    console.print("  --config, -c PATH                  # Use a specific config file")
    console.print("  --staged                           # Scope to git-staged files")
    console.print("  --git-range RANGE                  # Scope to a git range")
    console.print("  --dry-run                          # Preview without side effects")

    console.print(f"\n[bold]Documentation[/bold]: [link=https://docs.sentrik.dev]docs.sentrik.dev[/link]")
    print_hint("\nRun 'sentrik <command> --help' for detailed usage of any command.")


@app.command(name="test-connection", rich_help_panel="Core")
def test_connection(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
):
    """Test connectivity to the configured DevOps provider."""
    config, _profile = _load_config(config_path)
    provider = config.devops_provider

    if provider == "stub":
        print_success("DevOps provider is 'stub' (local mode) — no connection needed.")
        print_hint("To connect to a real provider, run: sentrik init")
        return

    typer.echo(f"\nTesting {provider} connection...\n")

    # Check environment variables first
    env_checks: list[tuple[str, str]] = []
    if provider == "azure":
        env_checks = [
            ("AZURE_DEVOPS_PAT", "Personal Access Token"),
        ]
        config_checks = [
            ("azure_devops_org", config.azure_devops_org),
            ("azure_devops_project", config.azure_devops_project),
        ]
    elif provider == "github":
        env_checks = [
            ("GITHUB_TOKEN", "Personal Access Token"),
        ]
        config_checks = [
            ("github_owner", config.github_owner),
            ("github_repo", config.github_repo),
        ]
    elif provider == "jira":
        env_checks = [
            ("JIRA_USER", "Username/email"),
            ("JIRA_TOKEN", "API token"),
        ]
        config_checks = [
            ("jira_base_url", config.jira_base_url),
            ("jira_project_key", config.jira_project_key),
        ]
    else:
        typer.echo(f"Unknown provider: {provider}")
        raise typer.Exit(1)

    # Check env vars
    all_ok = True
    for var, label in env_checks:
        if os.environ.get(var):
            print_success(f"  {var:<30} set")
        else:
            print_error(f"  {var:<30} NOT SET — {label}")
            all_ok = False

    # Check config values
    for field, value in config_checks:
        if value:
            print_success(f"  {field:<30} {value}")
        else:
            print_error(f"  {field:<30} NOT SET")
            all_ok = False

    if not all_ok:
        typer.echo()
        ctx = get_error_context(f"{provider}_no_pat") or get_error_context(f"{provider}_no_token") or get_error_context(f"{provider}_no_credentials")
        if ctx:
            print_error_context(ctx)
        print_hint("Fix the issues above, then re-run: sentrik test-connection")
        raise typer.Exit(1)

    # Try actual API connection
    typer.echo()
    try:
        from guard.providers.factory import build_devops
        devops = build_devops(config)
        items = devops.get_work_items()
        print_success(f"Connection successful! Found {len(items)} work item(s).")
    except Exception as exc:
        print_error(f"Connection failed: {exc}")
        ctx = get_error_context("devops_connection_failed")
        if ctx:
            print_error_context(ctx)
        raise typer.Exit(1)


@app.command(rich_help_panel="Core")
def export_audit(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    output: str = typer.Option(None, "--output", "-o", help="Custom path for the audit bundle zip."),
):
    """Export a zip bundle of all scan artifacts for auditors."""
    config, _profile = _load_config(config_path)
    output_dir = Path(config.output_dir)
    if not output_dir.exists():
        print_error(f"Output directory '{output_dir}' does not exist. Run a scan first.")
        raise typer.Exit(1)

    bundle_path = Path(output) if output else None
    result = export_audit_bundle(output_dir, bundle_path=bundle_path)
    print_success(f"Audit bundle created: {result}")
    print_post_hint("export_audit")


@app.command(name="check-arch", rich_help_panel="Governance")
def check_arch(
    config: str = typer.Option(None, "--config", "-c", help="Path to architecture.yaml file."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output results as JSON."),
    init: bool = typer.Option(False, "--init", help="Generate a template architecture.yaml file."),
):
    """Check architecture rules — detect forbidden module dependencies."""
    from guard.core.architecture import (
        ArchReport,
        check_architecture,
        generate_template,
        load_arch_rules,
        violations_to_findings,
    )

    if init:
        out_path = generate_template()
        print_success(f"Template architecture rules written to {out_path}")
        print_hint("Edit the rules, then run: sentrik check-arch")
        return

    rules = load_arch_rules(config)
    if not rules:
        print_warning("No architecture rules found. Create one with: sentrik check-arch --init")
        return

    repo_root = find_repo_root()
    report = check_architecture(rules, repo_root)

    if json_output:
        import json as json_mod
        data = {
            "rules_checked": report.rules_checked,
            "files_analyzed": report.files_analyzed,
            "violations_count": len(report.violations),
            "violations": [
                {
                    "rule_name": v.rule_name,
                    "source_file": v.source_file,
                    "imported_module": v.imported_module,
                    "line": v.line,
                    "severity": v.severity,
                }
                for v in report.violations
            ],
        }
        typer.echo(json_mod.dumps(data, indent=2))
    else:
        print_header(f"Architecture Check — {report.rules_checked} rule(s), {report.files_analyzed} file(s) analyzed")
        if report.violations:
            from rich.table import Table
            table = Table(show_header=True, header_style="bold")
            table.add_column("Rule")
            table.add_column("File")
            table.add_column("Line")
            table.add_column("Imports")
            table.add_column("Severity")
            for v in report.violations:
                sev_style = SEV_STYLES.get(v.severity, "")
                table.add_row(
                    v.rule_name,
                    v.source_file,
                    str(v.line),
                    v.imported_module,
                    f"[{sev_style}]{v.severity}[/{sev_style}]",
                )
            console.print(table)
            print_error(f"{len(report.violations)} architecture violation(s) found.")
            raise typer.Exit(1)
        else:
            print_success("No architecture violations found.")

    print_post_hint("check_arch")


@app.command(name="compliance-map", rich_help_panel="Core")
def compliance_map(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    framework: str = typer.Option(None, "--framework", "-f", help="Filter by standard/framework."),
    output: str = typer.Option(None, "--output", "-o", help="Output file path."),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """Show where your code satisfies compliance requirements (evidence map).

    Scans the codebase for evidence that requirements are implemented —
    not just violations, but proof of compliance. Useful for audits.
    """
    from guard.core.evidence_mapper import build_compliance_map, generate_evidence_html
    from guard.core.comparison import load_findings

    config, _profile = _load_config(config_path)
    _, _, _, rules_engine, _ = build_providers(config)

    # Load findings from last scan (run 'sentrik scan' first if needed)
    repo_root = str(Path.cwd())
    findings_path = Path(config.output_dir) / "findings.json"
    if findings_path.exists():
        findings = load_findings(findings_path)
    else:
        # No cached findings — run a scan
        from guard.providers.factory import build_scanner, build_llm
        from guard.core.pipeline import run_scan
        findings = run_scan(repo_root, config, rules_engine, build_scanner(config, build_llm(config)))

    # Build evidence map
    cmap = build_compliance_map(
        repo_root=repo_root,
        rules=rules_engine._rules,
        findings=findings,
        scan_exclude=config.scan_exclude,
    )

    # Filter by framework if specified
    if framework:
        fw_lower = framework.lower()
        cmap.rules = [r for r in cmap.rules if fw_lower in (r.standard or "").lower()]

    if json_output:
        import json
        data = json.dumps(cmap.to_dict(), indent=2)
        if output:
            Path(output).write_text(data, encoding="utf-8")
            console.print(f"[green]Evidence map written to {output}[/green]")
        else:
            typer.echo(data)
        return

    # HTML output
    html = generate_evidence_html(cmap)
    out_path = Path(output) if output else Path(config.output_dir) / "compliance-map.html"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html, encoding="utf-8")

    # Console summary
    console.print(f"\n[bold]Compliance Evidence Map[/bold]")
    console.print(f"  Coverage: [bold]{cmap.coverage_percent}%[/bold]")
    console.print(f"  [green]Met:[/green] {cmap.met_count}  [red]Violated:[/red] {cmap.violated_count}  [yellow]Manual:[/yellow] {cmap.manual_count}  Not applicable: {cmap.not_applicable_count}")
    console.print(f"  Report: [link=file://{out_path.absolute()}]{out_path}[/link]\n")


@app.command(name="compliance-report", rich_help_panel="Core")
def compliance_report(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    framework: str = typer.Option(None, "--framework", "-f", help="Standard/framework to report on (e.g. 'IEC 62304', 'SOC2'). Omit for all."),
    output: str = typer.Option(None, "--output", "-o", help="Output file path (default: out/compliance-report.html)."),
    list_frameworks: bool = typer.Option(False, "--list", "-l", help="List available frameworks from the last scan and exit."),
):
    """Generate a per-framework compliance report mapping findings to regulatory clauses."""
    from guard.reporters.compliance_report import (
        generate_compliance_report,
        list_frameworks as _list_frameworks,
    )

    config, _profile = _load_config(config_path)
    findings_path = Path(config.output_dir) / "findings.json"
    if not findings_path.exists():
        print_error("No findings.json found. Run 'sentrik scan' first.")
        raise typer.Exit(1)

    raw = json.loads(findings_path.read_text(encoding="utf-8"))
    from guard.core.models import Finding as FindingModel
    findings = [FindingModel.model_validate(f) for f in raw]

    # List mode
    if list_frameworks:
        fws = _list_frameworks(findings)
        if not fws:
            typer.echo("No frameworks found in findings. Ensure standards packs are enabled.")
            return
        typer.echo("Frameworks in last scan:")
        for fw in fws:
            count = sum(1 for f in findings if f.standard == fw)
            typer.echo(f"  {fw} ({count} finding(s))")
        typer.echo(f"\nGenerate a report: sentrik compliance-report --framework \"{fws[0]}\"")
        return

    # Read rules_total from scan_metrics if available
    rules_total = None
    metrics_path = Path(config.output_dir) / "scan_metrics.json"
    if metrics_path.exists():
        try:
            metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
            cs = metrics.get("compliance_score", {})
            rules_total = cs.get("rules_total")
        except (json.JSONDecodeError, OSError):
            pass

    html = generate_compliance_report(findings, framework=framework, rules_total=rules_total)

    # Write output
    if output:
        out_path = Path(output)
    else:
        out_dir = Path(config.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        suffix = f"-{framework.lower().replace(' ', '-')}" if framework else ""
        out_path = out_dir / f"compliance-report{suffix}.html"

    out_path.write_text(html, encoding="utf-8")
    print_success(f"Compliance report written to {out_path}")

    # Show summary
    if framework:
        scoped = [f for f in findings if f.standard and f.standard.lower() == framework.lower()]
    else:
        scoped = [f for f in findings if f.standard]
    code_count = sum(1 for f in scoped if not f.is_obligation)
    oblig_count = sum(1 for f in scoped if f.is_obligation)
    typer.echo(f"  {code_count} code finding(s), {oblig_count} documentation obligation(s)")
    print_post_hint("compliance_report")


@app.command(name="history-report", rich_help_panel="Core")
def history_report(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    run_id: str = typer.Option(None, "--run-id", "-r", help="Run ID to generate report for."),
    list_runs: bool = typer.Option(False, "--list", "-l", help="List available historical runs."),
    framework: str = typer.Option(None, "--framework", "-f", help="Framework filter for compliance report."),
    output: str = typer.Option(None, "--output", "-o", help="Output file path."),
):
    """Generate a report from a historical scan run."""
    config, _profile = _load_config(config_path)

    if list_runs:
        runs = list_historical_runs(config.output_dir)
        if not runs:
            typer.echo("No historical runs found. Run 'sentrik scan' or 'sentrik gate' first.")
            return
        typer.echo(f"{'Run ID':<40} {'Date':<26} {'Command':<10} {'Findings':>8}")
        typer.echo("-" * 88)
        for r in runs:
            rid = r.get("run_id", "?")[:36]
            ts = r.get("timestamp", "?")[:25]
            cmd = r.get("command", "?")
            cnt = r.get("findings_count", "?")
            typer.echo(f"{rid:<40} {ts:<26} {cmd:<10} {cnt:>8}")
        typer.echo(f"\nGenerate a report: sentrik history-report --run-id <RUN_ID>")
        return

    if not run_id:
        print_error("Specify --run-id or use --list to see available runs.")
        raise typer.Exit(1)

    # Load historical findings
    findings = load_historical_findings(config.output_dir, run_id)
    if findings is None:
        print_error(f"Run ID '{run_id}' not found. Use 'sentrik history-report --list' to see available runs.")
        raise typer.Exit(1)

    metadata = load_historical_metadata(config.output_dir, run_id)

    # Generate compliance report if findings have standards, otherwise HTML report
    from guard.reporters.compliance_report import generate_compliance_report
    has_standards = any(f.standard for f in findings)

    if has_standards:
        html = generate_compliance_report(findings, framework=framework)
    else:
        # Fall back to basic HTML findings report
        from guard.core.renderer import render_report
        html = render_report(findings)

    # Inject run metadata header into the report
    if metadata and has_standards:
        meta_banner = (
            f'<div style="background:#1e1b4b;color:#c4b5fd;padding:12px 20px;'
            f'border-radius:8px;margin-bottom:20px;font-family:monospace;font-size:13px">'
            f'<strong>Historical Run</strong> &mdash; '
            f'ID: {metadata.get("run_id", "?")[:8]}… &nbsp;|&nbsp; '
            f'{metadata.get("timestamp", "")[:19]} &nbsp;|&nbsp; '
            f'Command: {metadata.get("command", "?")} &nbsp;|&nbsp; '
            f'{metadata.get("findings_count", "?")} findings'
            f'</div>'
        )
        html = html.replace("<body>", f"<body>\n{meta_banner}", 1)

    # Write output
    if output:
        out_path = Path(output)
    else:
        out_dir = Path(config.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        short_id = run_id[:8]
        out_path = out_dir / f"report-{short_id}.html"

    out_path.write_text(html, encoding="utf-8")
    print_success(f"Historical report written to {out_path}")

    # Summary
    code_count = sum(1 for f in findings if not f.is_obligation)
    oblig_count = sum(1 for f in findings if f.is_obligation)
    if metadata:
        typer.echo(f"  Run: {run_id[:8]}… | {metadata.get('timestamp', '')[:19]} | {metadata.get('command', '?')}")
    typer.echo(f"  {code_count} code finding(s), {oblig_count} documentation obligation(s)")
    print_post_hint("history_report")


@app.command(name="trust-center", rich_help_panel="Core")
def trust_center(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    output: str = typer.Option(None, "--output", "-o", help="Output file path (default: out/trust-center.html)."),
    org_name: str = typer.Option(None, "--org", help="Organization name for the header."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output JSON instead of HTML."),
):
    """Generate a public-safe trust center page showing compliance posture."""
    from guard.reporters.trust_center import (
        generate_trust_center,
        generate_trust_center_json,
    )

    config, _profile = _load_config(config_path)
    findings_path = Path(config.output_dir) / "findings.json"
    if not findings_path.exists():
        print_error("No findings.json found. Run 'sentrik scan' first.")
        raise typer.Exit(1)

    raw = json.loads(findings_path.read_text(encoding="utf-8"))
    from guard.core.models import Finding as FindingModel
    findings = [FindingModel.model_validate(f) for f in raw]

    # Read rules_total and timestamp from scan_metrics
    rules_total = None
    scan_timestamp = None
    metrics_path = Path(config.output_dir) / "scan_metrics.json"
    if metrics_path.exists():
        try:
            metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
            cs = metrics.get("compliance_score", {})
            rules_total = cs.get("rules_total")
            scan_timestamp = metrics.get("timestamp")
        except (json.JSONDecodeError, OSError):
            pass

    if json_output:
        data = generate_trust_center_json(
            findings, rules_total=rules_total, org_name=org_name,
            scan_timestamp=scan_timestamp,
        )
        if output:
            out_path = Path(output)
        else:
            out_dir = Path(config.output_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            out_path = out_dir / "trust-center.json"
        out_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        print_success(f"Trust center JSON written to {out_path}")
    else:
        html = generate_trust_center(
            findings, rules_total=rules_total, org_name=org_name,
            scan_timestamp=scan_timestamp,
        )
        if output:
            out_path = Path(output)
        else:
            out_dir = Path(config.output_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            out_path = out_dir / "trust-center.html"
        out_path.write_text(html, encoding="utf-8")
        print_success(f"Trust center page written to {out_path}")

    print_post_hint("trust_center")


@app.command(rich_help_panel="Reports")
def attest(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    output: str = typer.Option(None, "--output", "-o", help="Output file path (default: out/attestation.json)."),
    verify: str = typer.Option(None, "--verify", help="Verify an existing attestation file instead of generating one."),
):
    """Generate or verify a signed compliance attestation.

    Creates a cryptographically signed JSON document proving scan results,
    gate status, and environment at point in time. Use --verify to validate
    an existing attestation.
    """
    from guard.core.attestation import generate_attestation, verify_attestation

    if verify:
        verify_path = Path(verify)
        if not verify_path.is_file():
            print_error(f"File not found: {verify}")
            raise typer.Exit(1)
        doc = json.loads(verify_path.read_text(encoding="utf-8"))
        if verify_attestation(doc):
            print_success("Attestation signature is valid.")
            att = doc["attestation"]
            typer.echo(f"  Timestamp: {att['timestamp']}")
            typer.echo(f"  Gate: {'PASSED' if att['scan']['gate_passed'] else 'FAILED'}")
            typer.echo(f"  Findings: {att['scan']['total_findings']}")
            typer.echo(f"  Git SHA: {att['environment'].get('git_sha', 'N/A')}")
        else:
            print_error("Attestation signature is INVALID — the document may have been tampered with.")
            raise typer.Exit(1)
        return

    config, _profile = _load_config(config_path)
    findings_path = Path(config.output_dir) / "findings.json"
    metrics_path = Path(config.output_dir) / "scan_metrics.json"

    if not findings_path.is_file():
        print_error("No findings.json found. Run 'sentrik scan' first.")
        raise typer.Exit(1)

    config_summary = {
        "gate_fail_on": config.gate_fail_on,
        "standards_packs": config.standards_packs,
    }
    doc = generate_attestation(findings_path, metrics_path, config_summary)

    out_path = Path(output) if output else Path(config.output_dir) / "attestation.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(doc, indent=2), encoding="utf-8")

    att = doc["attestation"]
    print_success(f"Attestation written to {out_path}")
    typer.echo(f"  Gate: {'PASSED' if att['scan']['gate_passed'] else 'FAILED'}")
    typer.echo(f"  Findings: {att['scan']['total_findings']} ({att['scan']['findings_sha256'][:12]}...)")
    typer.echo(f"  Signature: {doc['signature'][:16]}...")
    typer.echo(f"  Verify with: sentrik attest --verify {out_path}")


@app.command(rich_help_panel="Reports")
def evidence_export(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    framework: str = typer.Option(None, "--framework", "-f", help="Framework to export evidence for (e.g. 'SOC2', 'IEC 62304')."),
    output: str = typer.Option(None, "--output", "-o", help="Output directory or file path."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output JSON instead of HTML."),
    list_frameworks: bool = typer.Option(False, "--list", "-l", help="List available frameworks."),
    all_frameworks: bool = typer.Option(False, "--all", "-a", help="Export evidence for all available frameworks."),
):
    """Generate audit evidence packages mapped to compliance framework controls."""
    from guard.core.evidence_export import (
        AVAILABLE_FRAMEWORKS,
        collect_evidence,
        generate_evidence_html,
        generate_evidence_package,
        list_available_frameworks,
    )

    if list_frameworks:
        typer.echo("Available frameworks for evidence export:")
        for fw in list_available_frameworks():
            typer.echo(f"  {fw}")
        typer.echo(f"\nExport evidence: sentrik evidence-export --framework \"SOC2\"")
        return

    config, _profile = _load_config(config_path)

    if not all_frameworks and not framework:
        print_error("Specify --framework or use --all for all frameworks. Use --list to see options.")
        raise typer.Exit(1)

    frameworks_to_export = AVAILABLE_FRAMEWORKS if all_frameworks else [framework]

    for fw in frameworks_to_export:
        evidence_items = collect_evidence(config.output_dir, fw)

        package = generate_evidence_package(
            evidence_items,
            framework=fw,
            project_name=Path(".").resolve().name,
        )

        fw_slug = fw.lower().replace(" ", "-")

        if json_output:
            if output:
                out_path = Path(output)
                if out_path.is_dir() or (all_frameworks and not out_path.suffix):
                    out_path.mkdir(parents=True, exist_ok=True)
                    out_path = out_path / f"evidence-{fw_slug}.json"
            else:
                out_dir = Path(config.output_dir)
                out_dir.mkdir(parents=True, exist_ok=True)
                out_path = out_dir / f"evidence-{fw_slug}.json"
            out_path.write_text(json.dumps(package, indent=2), encoding="utf-8")
            print_success(f"Evidence JSON written to {out_path}")
        else:
            html = generate_evidence_html(package)
            if output:
                out_path = Path(output)
                if out_path.is_dir() or (all_frameworks and not out_path.suffix):
                    out_path.mkdir(parents=True, exist_ok=True)
                    out_path = out_path / f"evidence-{fw_slug}.html"
            else:
                out_dir = Path(config.output_dir)
                out_dir.mkdir(parents=True, exist_ok=True)
                out_path = out_dir / f"evidence-{fw_slug}.html"
            out_path.write_text(html, encoding="utf-8")
            print_success(f"Evidence report written to {out_path}")

    print_post_hint("evidence_export")


@app.command(hidden=True, rich_help_panel="Hooks")
def pre_commit_scan(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
):
    """Pre-commit hook wrapper — scans staged files with recovery hints on failure."""
    config, _profile = _load_config(config_path)
    _, standards, scanner, rules_engine = _build_providers(config)
    repo_root = str(find_repo_root())
    changed_files = get_staged_files(repo_root)

    if not changed_files:
        print_success("No staged files — skipping scan.")
        raise typer.Exit(0)

    findings, gate_result, out = run_scan_and_write(
        repo_root, config, rules_engine, scanner, command="pre-commit",
        changed_files=changed_files,
    )

    if gate_result.passed:
        print_success(f"Pre-commit scan passed ({len(findings)} findings)")
        raise typer.Exit(0)

    # Rich failure output with recovery hints
    print_error(f"Pre-commit scan FAILED — {gate_result.total_findings} findings")
    by_sev: dict[str, int] = {}
    for f in findings:
        sev = f.severity.value if hasattr(f.severity, "value") else str(f.severity)
        by_sev[sev] = by_sev.get(sev, 0) + 1
    scan_summary_table(by_sev)

    # Top violations
    rule_counts: dict[str, int] = {}
    for f in findings:
        if f.severity.value in ("critical", "high"):
            rule_counts[f.rule_id] = rule_counts.get(f.rule_id, 0) + 1
    if rule_counts:
        top = sorted(rule_counts, key=lambda r: rule_counts[r], reverse=True)[:5]
        typer.echo("\nTop violations:")
        for rid in top:
            typer.echo(f"  {rid}: {rule_counts[rid]} finding(s)")

    typer.echo("\nRecovery options:")
    typer.echo("  1. Fix the issues and re-stage: git add <files>")
    autofixable = sum(1 for f in findings if f.suggestion)
    if autofixable:
        typer.echo(f"  2. Auto-fix {autofixable} finding(s): sentrik fix-hook")
    typer.echo("  3. Bypass (not recommended): git commit --no-verify")
    raise typer.Exit(1)


@app.command(rich_help_panel="Hooks")
def fix_hook(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
):
    """Auto-fix staged file findings, re-stage, and re-run gate."""
    config, _profile = _load_config(config_path)
    _, standards, scanner, rules_engine = _build_providers(config)
    repo_root = str(find_repo_root())
    changed_files = get_staged_files(repo_root)

    if not changed_files:
        print_success("No staged files to fix.")
        raise typer.Exit(0)

    rules = standards.get_rules() + _load_pack_rules(config.standards_packs, license_key=config.license_key)
    autofix_map = build_autofix_map(rules)
    replacement_map = build_replacement_map(rules)

    findings, gate_result, out = run_scan_and_write(
        repo_root, config, rules_engine, scanner, command="fix-hook",
        changed_files=changed_files,
        autofix_map=autofix_map, replacement_map=replacement_map,
    )

    # Apply patches if available
    patches_dir = out / "patches"
    applied = do_apply_patches(str(patches_dir), repo_root)
    if applied:
        print_success(f"Applied {applied} auto-fix patch(es)")
        # Re-stage fixed files
        import subprocess
        for cf in changed_files:
            subprocess.run(["git", "add", cf], cwd=repo_root, capture_output=True)
        print_success("Re-staged fixed files")
    else:
        print_warning("No auto-fix patches available")

    # Re-run gate
    findings2, gate2, _ = run_scan_and_write(
        repo_root, config, rules_engine, scanner, command="fix-hook-verify",
        changed_files=get_staged_files(repo_root),
    )
    if gate2.passed:
        print_success("Gate now passes after fixes!")
    else:
        print_error(f"Gate still fails: {gate2.total_findings} findings remain")
    raise typer.Exit(0 if gate2.passed else 1)


@app.command(rich_help_panel="Core")
def impact(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    git_range: str = typer.Option(None, "--git-range", help="Git range for scoping (e.g. origin/main...HEAD)."),
    files: list[str] = typer.Option(None, "--files", "-f", help="Specific files to analyse."),
    staged: bool = typer.Option(False, "--staged", help="Analyse staged files."),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """Analyse which compliance controls and requirements are affected by changed files."""
    from guard.core.impact_analysis import (
        analyze_impact,
        get_changed_files_from_git,
        report_to_dict,
    )
    from guard.core.requirements_verifier import load_requirements

    config, _profile = _load_config(config_path)
    repo_root = str(find_repo_root())

    # Resolve changed files
    if files:
        changed = list(files)
    elif staged:
        changed = get_changed_files_from_git(git_range=None, repo_root=repo_root)
    elif git_range:
        changed = get_changed_files_from_git(git_range=git_range, repo_root=repo_root)
    else:
        # Default: staged files
        changed = get_changed_files_from_git(git_range=None, repo_root=repo_root)

    if not changed:
        if json_output:
            typer.echo(json.dumps(report_to_dict(analyze_impact([], [])), indent=2))
        else:
            print_warning("No changed files found. Use --files, --staged, or --git-range to specify scope.")
            print_post_hint("impact")
        return

    # Load rules from standards + packs
    _, standards, _scanner, _rules_engine = _build_providers(config)
    rules = standards.get_rules() + _load_pack_rules(config.standards_packs, license_key=config.license_key)

    # Load requirements if available
    from pathlib import Path as _Path
    req_path = _Path(repo_root) / "requirements.yaml"
    requirements = load_requirements(req_path) if req_path.exists() else []

    # Run analysis
    report = analyze_impact(changed, rules, requirements)

    if json_output:
        typer.echo(json.dumps(report_to_dict(report), indent=2))
    else:
        # Rich formatted output
        print_header(f"Change Impact Analysis — {len(changed)} file(s)")

        from rich.table import Table

        # Summary panel
        console.print(f"\n  Files changed:          {len(report.changed_files)}")
        console.print(f"  Rules affected:         {report.total_rules_affected}")
        console.print(f"  Requirements affected:  {report.total_requirements_affected}")
        console.print(f"  Frameworks affected:    {report.total_frameworks_affected}")

        if report.requires_revalidation:
            print_warning("\n  REVALIDATION REQUIRED — critical/high-severity rules are affected")
        else:
            print_success("\n  No revalidation required — only low/medium-severity rules affected")

        # Per-file details
        if report.items:
            console.print()
            table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
            table.add_column("File", style="cyan")
            table.add_column("Risk", width=8)
            table.add_column("Rules", justify="right", width=6)
            table.add_column("Reqs", justify="right", width=6)
            table.add_column("Frameworks")

            for item in report.items:
                risk_style = {"high": "bold red", "medium": "yellow", "low": "green"}.get(item.risk_level, "dim")
                table.add_row(
                    item.file,
                    f"[{risk_style}]{item.risk_level}[/{risk_style}]",
                    str(len(item.rules)),
                    str(len(item.requirements)),
                    ", ".join(item.frameworks) if item.frameworks else "-",
                )
            console.print(table)

        # Show affected requirements
        all_reqs = set()
        for item in report.items:
            all_reqs.update(item.requirements)
        if all_reqs:
            console.print(f"\n  Affected requirements: {', '.join(sorted(all_reqs))}")

    if not json_output:
        print_post_hint("impact")


@app.command(name="analyze-cpp", rich_help_panel="Core")
def analyze_cpp(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    tool: str = typer.Option("auto", "--tool", "-t", help="Tool to use: clang-tidy, cppcheck, both, or auto."),
    checks: str = typer.Option("", "--checks", help="Clang-tidy checks (comma-separated, e.g. 'cert-*,misra-*')."),
    files: list[str] = typer.Option(None, "--files", "-f", help="Specific files to analyze."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output JSON instead of Rich table."),
    output: str = typer.Option(None, "--output", "-o", help="Output file path (default: out/cpp_findings.json)."),
):
    """Run semantic C/C++ analysis with clang-tidy and/or cppcheck."""
    from guard.core.cpp_analyzer import (
        CppAnalyzerResult,
        collect_cpp_files,
        is_clang_tidy_available,
        is_cppcheck_available,
        run_cpp_analysis,
    )

    config, _profile = _load_config(config_path)
    repo_root = str(find_repo_root())

    # Auto-detect tools if "auto"
    if tool == "auto":
        has_ct = is_clang_tidy_available()
        has_cc = is_cppcheck_available()
        if has_ct and has_cc:
            tool = "both"
        elif has_ct:
            tool = "clang-tidy"
        elif has_cc:
            tool = "cppcheck"
        else:
            print_error("No C/C++ analysis tools found.")
            print_hint(
                "Install clang-tidy: apt install clang-tidy (Linux), "
                "brew install llvm (macOS), or download from llvm.org\n"
                "Install cppcheck: apt install cppcheck (Linux), "
                "brew install cppcheck (macOS), or download from cppcheck.net"
            )
            raise typer.Exit(1)

    # Collect files
    file_list = list(files) if files else None
    cpp_files = collect_cpp_files(repo_root, file_list)

    if not cpp_files:
        print_warning("No C/C++ files found in the project.")
        return

    effective_checks = checks or config.cpp_analysis_checks
    print_header(f"Analyzing {len(cpp_files)} C/C++ file(s) with {tool}...")

    results = run_cpp_analysis(
        repo_root,
        tool=tool,
        checks=effective_checks,
        files=file_list,
    )

    # Merge all findings
    all_findings = []
    for r in results:
        all_findings.extend(r.findings)
        for err in r.errors:
            print_warning(f"[{r.tool}] {err}")

    # Write output
    if output:
        out_path = Path(output)
    else:
        out_dir = Path(config.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / "cpp_findings.json"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps([f.model_dump() for f in all_findings], indent=2, default=str),
        encoding="utf-8",
    )

    if json_output:
        typer.echo(json.dumps([f.model_dump() for f in all_findings], indent=2, default=str))
    else:
        # Summary table
        from rich.table import Table as RichTable

        tbl = RichTable(title=f"C/C++ Analysis Results ({len(all_findings)} findings)")
        tbl.add_column("Severity", style="bold")
        tbl.add_column("Rule")
        tbl.add_column("File")
        tbl.add_column("Line")
        tbl.add_column("Message")

        for f in all_findings[:50]:  # Show top 50
            sev_style = SEV_STYLES.get(f.severity.value, "")
            tbl.add_row(
                f"[{sev_style}]{f.severity.value}[/{sev_style}]",
                f.rule_id,
                f.evidence.file,
                str(f.evidence.lines[0]) if f.evidence.lines else "-",
                f.message[:80],
            )

        console.print(tbl)

        if len(all_findings) > 50:
            print_hint(f"... and {len(all_findings) - 50} more. See {out_path}")

        for r in results:
            print_success(f"{r.tool}: {len(r.findings)} findings from {r.files_analyzed} file(s)")

    print_post_hint("analyze_cpp")


@app.command(rich_help_panel="Core")
def watch(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    interval: int = typer.Option(0, "--interval", "-i", help="Seconds between periodic full scans (0 = file-watch only)."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output except gate failures."),
    vulns: bool = typer.Option(False, "--vulns", help="Enable periodic vulnerability scanning."),
    vuln_interval: int = typer.Option(3600, "--vuln-interval", help="Seconds between vulnerability scans (default: 3600)."),
    fix: bool = typer.Option(False, "--fix", help="Auto-patch vulnerable dependencies when CVEs are found (requires --vulns)."),
    create_pr: bool = typer.Option(False, "--create-pr", help="Create a PR with fixes (requires --fix and a DevOps provider)."),
):
    """Watch for file changes and re-scan automatically.

    With --vulns, also periodically checks dependencies for new CVEs
    and optionally auto-fixes and creates PRs.
    """
    config, _profile = _load_config(config_path)

    if fix and not vulns:
        print_error("--fix requires --vulns. Run: sentrik watch --vulns --fix")
        raise typer.Exit(1)
    if create_pr and not fix:
        print_error("--create-pr requires --fix. Run: sentrik watch --vulns --fix --create-pr")
        raise typer.Exit(1)

    if not quiet:
        print_post_hint("watch")

    from guard.core.watcher import run_watch_loop

    run_watch_loop(
        config, interval=interval, quiet=quiet,
        vulns=vulns, vuln_interval=vuln_interval,
        auto_fix=fix, create_pr=create_pr,
    )


@app.command(rich_help_panel="Core")
def secrets(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    staged: bool = typer.Option(False, "--staged", help="Scan only git-staged files."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON."),
    output: str = typer.Option(None, "--output", "-o", help="Output file path."),
):
    """Scan for hardcoded secrets: API keys, tokens, passwords, private keys.

    Detects provider-specific patterns (AWS, GitHub, Stripe, Slack, etc.)
    with entropy checks to reduce false positives. Secrets are redacted
    in output.
    """
    from rich.table import Table
    from guard.core.secrets_scanner import scan_directory
    from guard.core.repo_reader import find_repo_root

    config, _profile = _load_config(config_path)
    repo_root = str(find_repo_root())

    changed_files = None
    if staged:
        from guard.core.diff_parser import get_staged_files
        changed_files = get_staged_files(repo_root)

    result = scan_directory(
        repo_root,
        file_paths=changed_files,
        excludes=config.scan_exclude,
    )

    if json_output:
        import json as _json
        out_text = _json.dumps(result.to_dict(), indent=2)
        if output:
            Path(output).write_text(out_text, encoding="utf-8")
            print_success(f"Results written to {output}")
        else:
            console.print(out_text)
    else:
        if not result.findings:
            print_success(f"No secrets found ({result.files_scanned} files scanned)")
        else:
            tbl = Table(title=f"Secrets Detected ({len(result.findings)} findings)")
            tbl.add_column("Severity", style="bold")
            tbl.add_column("File", style="cyan")
            tbl.add_column("Line", justify="right")
            tbl.add_column("Type")
            tbl.add_column("Match", style="dim")

            for f in result.findings:
                sev_style = SEV_STYLES.get(f.severity, "")
                tbl.add_row(
                    f"[{sev_style}]{f.severity.upper()}[/{sev_style}]",
                    f.file, str(f.line), f.description, f.match,
                )
            console.print(tbl)

            console.print(f"\n[bold]{result.critical_count} critical[/bold], "
                          f"{result.high_count} high, "
                          f"{len(result.findings) - result.critical_count - result.high_count} medium")

    # Write to output dir
    if not output:
        import json as _json
        out_dir = Path(config.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / "secrets.json").write_text(
            _json.dumps(result.to_dict(), indent=2), encoding="utf-8",
        )

    print_post_hint("secrets")


@app.command(rich_help_panel="Core")
def sbom(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    format: str = typer.Option("cyclonedx", "--format", "-f", help="SBOM format: cyclonedx (default) or spdx."),
    output: str = typer.Option(None, "--output", "-o", help="Output file path (default: out/sbom.json)."),
    list_manifests: bool = typer.Option(False, "--list", "-l", help="List detected manifests and exit."),
):
    """Generate a Software Bill of Materials (SBOM) from dependency manifests."""
    from guard.core.sbom import (
        Component,
        SBOMMetadata,
        detect_manifests,
        generate_cyclonedx,
        generate_spdx,
        parse_dependencies,
    )

    config, _profile = _load_config(config_path)
    repo_root = str(find_repo_root())
    manifests = detect_manifests(repo_root)

    if list_manifests:
        if not manifests:
            typer.echo("No dependency manifests found.")
        else:
            typer.echo(f"Found {len(manifests)} manifest(s):")
            for m in manifests:
                typer.echo(f"  {m.relative_to(repo_root)}")
        return

    if not manifests:
        print_warning("No dependency manifests found in project root.")
        return

    # Parse all manifests
    all_components: list[Component] = []
    seen: set[tuple[str, str, str]] = set()
    for m in manifests:
        for comp in parse_dependencies(m):
            key = (comp.ecosystem, comp.name, comp.version)
            if key not in seen:
                seen.add(key)
                all_components.append(comp)

    # Build metadata
    project_name = Path(repo_root).name
    meta = SBOMMetadata(name=project_name, version=config.project_version if hasattr(config, "project_version") else "0.0.0")

    # Generate
    fmt = format.lower()
    if fmt == "spdx":
        doc = generate_spdx(all_components, meta)
    elif fmt in ("cyclonedx", "cdx"):
        doc = generate_cyclonedx(all_components, meta)
    else:
        print_error(f"Unknown format '{format}'. Use 'cyclonedx' or 'spdx'.")
        raise typer.Exit(1)

    # Write output
    if output:
        out_path = Path(output)
    else:
        out_dir = Path(config.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / "sbom.json"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(doc, indent=2), encoding="utf-8")

    print_success(f"SBOM ({fmt}) written to {out_path} — {len(all_components)} component(s)")
    print_post_hint("sbom")


@app.command(rich_help_panel="Core")
def vulns(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output JSON instead of Rich table."),
    output: str = typer.Option(None, "--output", "-o", help="Output file path (default: out/vulnerabilities.json)."),
    fix: bool = typer.Option(False, "--fix", help="Auto-patch manifest files with fixed versions."),
    fix_preview: bool = typer.Option(False, "--fix-preview", help="Show what --fix would change without modifying files."),
    create_pr: bool = typer.Option(False, "--create-pr", help="Create a branch and PR with the fixes (requires --fix and a DevOps provider)."),
):
    """Scan project dependencies for known vulnerabilities (CVEs) via OSV.dev."""
    from rich.table import Table

    from guard.core.sbom import Component, detect_manifests, parse_dependencies
    from guard.core.vuln_scanner import result_to_dict, scan_dependencies

    if create_pr and not fix:
        print_error("--create-pr requires --fix. Run: sentrik vulns --fix --create-pr")
        raise typer.Exit(1)

    config, _profile = _load_config(config_path)

    if create_pr and config.devops_provider in ("stub", ""):
        print_error(
            "--create-pr requires a DevOps provider (azure or github). "
            "Configure devops_provider in .sentrik/config.yaml or set GUARD_DEVOPS_PROVIDER."
        )
        raise typer.Exit(1)

    repo_root = str(find_repo_root())
    manifests = detect_manifests(repo_root)

    if not manifests:
        print_warning("No dependency manifests found in project root.")
        return

    # Parse all manifests and deduplicate
    all_components: list[Component] = []
    seen: set[tuple[str, str, str]] = set()
    for m in manifests:
        for comp in parse_dependencies(m):
            key = (comp.ecosystem, comp.name, comp.version)
            if key not in seen:
                seen.add(key)
                all_components.append(comp)

    if not json_output:
        print_header(f"Scanning {len(all_components)} dependencies for known vulnerabilities...")
    result = scan_dependencies(all_components)
    result_dict = result_to_dict(result)

    # Write output file
    if output:
        out_path = Path(output)
    else:
        out_dir = Path(config.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / "vulnerabilities.json"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result_dict, indent=2), encoding="utf-8")

    # Record to long-term metrics DB
    try:
        from guard.core.metrics_db import MetricsDB

        db = MetricsDB(Path(".sentrik") / "local" / "metrics.db")
        try:
            db.record_vuln_scan(result_dict)
        finally:
            db.close()
    except Exception:
        pass  # DB failures must not break the command

    if json_output:
        typer.echo(json.dumps(result_dict, indent=2))
        return

    # Rich summary table
    if not result.vulnerabilities:
        print_success(f"No known vulnerabilities found in {result.total_dependencies} dependencies.")
    else:
        console.print(f"\n[warning]Found {len(result.vulnerabilities)} vulnerability(ies) "
                       f"in {result.vulnerable_count} of {result.total_dependencies} packages[/warning]\n")

        sev_parts = []
        for sev in ("critical", "high", "medium", "low"):
            count = result.by_severity.get(sev, 0)
            if count:
                sev_parts.append(f"[sev.{sev}]{count} {sev}[/sev.{sev}]")
        if sev_parts:
            console.print("  " + " | ".join(sev_parts) + "\n")

        if result.kev_count > 0:
            console.print(
                f"  [bold red]CISA KEV:[/bold red] {result.kev_count} vulnerabilit{'y' if result.kev_count == 1 else 'ies'} "
                f"match the CISA Known Exploited Vulnerabilities catalog — prioritize remediation.\n"
            )

        table = Table(title="Vulnerable Dependencies", show_lines=True)
        table.add_column("Package", style="bold")
        table.add_column("Version")
        table.add_column("Vuln ID", style="cyan")
        table.add_column("Severity")
        table.add_column("Fixed In", style="green")
        table.add_column("Summary", max_width=50)

        for v in result.vulnerabilities:
            sev_style = SEV_STYLES.get(v.severity, "")
            vuln_id_display = f"{v.id} [bold red]KEV[/bold red]" if v.kev_tagged else v.id
            table.add_row(
                v.affected_package,
                v.affected_version,
                vuln_id_display,
                f"[{sev_style}]{v.severity}[/{sev_style}]",
                v.fixed_version or "-",
                v.summary[:80] if v.summary else "-",
            )

        console.print(table)

    console.print(f"\n  Results written to [bold]{out_path}[/bold]")

    # --fix / --fix-preview: auto-remediation
    if fix or fix_preview:
        from guard.core.vuln_fixer import apply_fixes, generate_fix_actions

        actions = generate_fix_actions(result.vulnerabilities, manifests)

        if not actions:
            console.print("\n  No auto-fixable vulnerabilities (no fixed versions available).")
        else:
            # Preview table
            preview_table = Table(title="Proposed Fixes", show_lines=True)
            preview_table.add_column("Package", style="bold")
            preview_table.add_column("Current", style="red")
            preview_table.add_column("Fixed", style="green")
            preview_table.add_column("Manifest")

            for a in actions:
                manifest_display = Path(a.manifest_file).name
                preview_table.add_row(a.package, a.current_version, a.fixed_version, manifest_display)

            console.print()
            console.print(preview_table)

            if fix_preview:
                console.print(f"\n  [bold]{len(actions)}[/bold] fix(es) available. Run with [bold]--fix[/bold] to apply.")
            else:
                report = apply_fixes(actions)
                console.print(f"\n  Applied [bold green]{report.applied_count}[/bold green] fix(es), "
                               f"[bold yellow]{report.skipped_count}[/bold yellow] skipped.")
                for a in report.actions:
                    if a.error:
                        console.print(f"    [red]SKIP[/red] {a.package}: {a.error}")
                if report.applied_count > 0:
                    if create_pr:
                        from guard.core.vuln_pr import create_fix_pr
                        from guard.providers.factory import build_devops

                        try:
                            devops = build_devops(config)
                            pr_result = create_fix_pr(
                                fix_report=report,
                                config=config,
                                repo_root=repo_root,
                                vulns=result.vulnerabilities,
                                devops_provider=devops,
                            )
                            console.print(f"\n  [bold green]Branch:[/bold green] {pr_result['branch']}")
                            if pr_result.get("pr_url"):
                                console.print(f"  [bold green]PR:[/bold green] {pr_result['pr_url']}")
                            else:
                                console.print("  [dim]PR creation skipped (provider does not support PRs).[/dim]")
                        except Exception as exc:
                            print_error(f"Failed to create PR: {exc}")
                    else:
                        console.print("\n  [dim]Tip: re-run [bold]sentrik vulns[/bold] to verify fixes.[/dim]")

    print_post_hint("vulns")


@app.command(rich_help_panel="Core")
def licenses(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output JSON instead of Rich table."),
    copyleft_only: bool = typer.Option(False, "--copyleft-only", help="Show only copyleft-licensed packages."),
    output: str = typer.Option(None, "--output", "-o", help="Output file path (default: out/licenses.json)."),
):
    """Scan project dependencies for license types and flag copyleft risk."""
    from rich.table import Table

    from guard.core.sbom import Component, detect_manifests, parse_dependencies
    from guard.core.license_scanner import result_to_dict, scan_licenses

    config, _profile = _load_config(config_path)
    repo_root = str(find_repo_root())
    manifests = detect_manifests(repo_root)

    if not manifests:
        print_warning("No dependency manifests found in project root.")
        return

    # Parse all manifests and deduplicate
    all_components: list[Component] = []
    seen: set[tuple[str, str, str]] = set()
    for m in manifests:
        for comp in parse_dependencies(m):
            key = (comp.ecosystem, comp.name, comp.version)
            if key not in seen:
                seen.add(key)
                all_components.append(comp)

    print_header(f"Scanning {len(all_components)} dependencies for license information...")
    result = scan_licenses(all_components)
    result_dict = result_to_dict(result)

    # Write output file
    if output:
        out_path = Path(output)
    else:
        out_dir = Path(config.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / "licenses.json"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result_dict, indent=2), encoding="utf-8")

    # Apply copyleft filter for display
    display_licenses = result.licenses
    if copyleft_only:
        display_licenses = [li for li in result.licenses if li.copyleft]

    if json_output:
        if copyleft_only:
            filtered_dict = dict(result_dict)
            filtered_dict["licenses"] = [
                l for l in result_dict["licenses"] if l["copyleft"]
            ]
            typer.echo(json.dumps(filtered_dict, indent=2))
        else:
            typer.echo(json.dumps(result_dict, indent=2))
        return

    # Rich summary
    risk_parts = []
    for risk in ("high", "medium", "low", "none"):
        count = result.by_risk.get(risk, 0)
        if count:
            style = {"high": "bold red", "medium": "yellow", "low": "blue", "none": "green"}.get(risk, "dim")
            risk_parts.append(f"[{style}]{count} {risk}[/{style}]")
    if risk_parts:
        console.print("  " + " | ".join(risk_parts))

    if result.copyleft_count:
        console.print(f"\n  [warning]Copyleft licenses detected: {result.copyleft_count} package(s)[/warning]\n")
    else:
        console.print()

    # Rich table
    if display_licenses:
        table = Table(title="Dependency Licenses", show_lines=False)
        table.add_column("Package", style="bold")
        table.add_column("Version")
        table.add_column("Ecosystem")
        table.add_column("License", style="cyan")
        table.add_column("Risk")
        table.add_column("Copyleft")

        risk_styles = {"high": "bold red", "medium": "yellow", "low": "blue", "none": "green"}

        for li in display_licenses:
            style = risk_styles.get(li.risk, "dim")
            copyleft_str = "[bold red]Yes[/bold red]" if li.copyleft else "No"
            table.add_row(
                li.package,
                li.version,
                li.ecosystem,
                li.license,
                f"[{style}]{li.risk}[/{style}]",
                copyleft_str,
            )

        console.print(table)
    elif copyleft_only:
        print_success("No copyleft-licensed packages found.")

    console.print(f"\n  Results written to [bold]{out_path}[/bold]")
    print_post_hint("licenses")


@app.command(name="org-dashboard", rich_help_panel="Core")
def org_dashboard(
    root: str = typer.Option(None, "--root", "-r", help="Organization root directory containing sub-projects. Defaults to current directory."),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output JSON instead of Rich table."),
    output: str = typer.Option(None, "--output", "-o", help="Write HTML report to this file path."),
):
    """Aggregate compliance data across multiple repositories."""
    from rich.table import Table

    from guard.core.org_dashboard import (
        OrgProject,
        aggregate_org_data,
        collect_project_data,
        discover_projects,
        generate_org_html_report,
        org_data_to_json,
    )

    root_dir = Path(root) if root else Path(".")
    if not root_dir.is_dir():
        print_error(f"Root directory not found: {root_dir}")
        raise typer.Exit(1)

    print_header(f"Organization Dashboard — {root_dir.resolve()}")

    project_paths = discover_projects(root_dir)
    if not project_paths:
        print_warning("No projects found. Looking for .sentrik/config.yaml or .guard.yaml in subdirectories.")
        raise typer.Exit(0)

    projects: list[OrgProject] = []
    for pp in project_paths:
        projects.append(collect_project_data(pp))

    agg = aggregate_org_data(projects)

    if json_output:
        data = org_data_to_json(projects, agg)
        console.print_json(json.dumps(data, indent=2))
        if output:
            Path(output).write_text(json.dumps(data, indent=2), encoding="utf-8")
            print_success(f"JSON written to {output}")
        return

    if output:
        html = generate_org_html_report(projects, agg)
        out_path = Path(output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(html, encoding="utf-8")
        print_success(f"Org dashboard HTML report written to {out_path}")
        return

    # Rich table output (default)
    console.print(f"\n  [bold]{agg['total_projects']}[/bold] projects | "
                  f"[green]{agg['projects_passing']}[/green] passing | "
                  f"[red]{agg['projects_failing']}[/red] failing | "
                  f"Avg compliance: [bold]{agg['avg_compliance_score']}%[/bold] | "
                  f"Total findings: [bold]{agg['total_findings']}[/bold]\n")

    table = Table(show_header=True, header_style="bold white")
    table.add_column("Project", style="bold")
    table.add_column("Score", justify="right")
    table.add_column("Crit", justify="right", style="sev.critical")
    table.add_column("High", justify="right", style="sev.high")
    table.add_column("Med", justify="right", style="sev.medium")
    table.add_column("Low", justify="right", style="sev.low")
    table.add_column("Info", justify="right", style="sev.info")
    table.add_column("Gate")
    table.add_column("Frameworks")

    for p in projects:
        sc = p.compliance_score
        sc_style = "green" if sc >= 90 else "yellow" if sc >= 70 else "red"
        gate_style = "green" if p.gate_status == "passed" else "red" if p.gate_status == "failed" else "dim"
        fw_str = ", ".join(p.frameworks) if p.frameworks else "-"
        table.add_row(
            p.name,
            f"[{sc_style}]{sc}%[/{sc_style}]",
            str(p.findings_by_severity.get("critical", 0)),
            str(p.findings_by_severity.get("high", 0)),
            str(p.findings_by_severity.get("medium", 0)),
            str(p.findings_by_severity.get("low", 0)),
            str(p.findings_by_severity.get("info", 0)),
            f"[{gate_style}]{p.gate_status.upper()}[/{gate_style}]",
            fw_str,
        )

    console.print(table)

    if agg["frameworks_coverage"]:
        console.print("\n[bold]Framework Coverage:[/bold]")
        for fw, count in sorted(agg["frameworks_coverage"].items(), key=lambda x: -x[1]):
            console.print(f"  {fw}: {count}/{agg['total_projects']} projects")

    print_post_hint("org_dashboard")


@app.command(name="grc-push", rich_help_panel="Governance")
def grc_push(
    config_path: str = typer.Option(None, "--config", "-c", help="Config file path."),
    event: str = typer.Option("scan_complete", "--event", "-e", help="Event type to push: scan_complete, gate_passed, gate_failed, vuln_scan."),
    test: bool = typer.Option(False, "--test", help="Send a test payload to verify webhook connectivity."),
):
    """Push compliance evidence to a GRC platform (Drata, Vanta, Secureframe, or webhook)."""
    from datetime import datetime as _dt, timezone as _tz

    from guard.core.grc_integration import (
        GRCPayload,
        build_grc_config_from_guard_config,
        build_gate_payload,
        build_scan_payload,
        push_event as do_push,
    )
    from guard.core.repo_reader import find_repo_root

    config, _profile = _load_config(config_path)
    grc_config = build_grc_config_from_guard_config(config)

    if not grc_config.webhook_url:
        print_error("No GRC webhook URL configured.")
        print_hint("Set grc_webhook_url in your config or GUARD_GRC_WEBHOOK_URL env var.")
        raise typer.Exit(1)

    repo_root = str(find_repo_root())
    project_name = Path(repo_root).name

    if test:
        payload = GRCPayload(
            event="test",
            timestamp=_dt.now(_tz.utc).isoformat(),
            project_name=project_name,
            data={"message": "SENTRIK GRC integration test", "status": "ok"},
        )
        ok = do_push(grc_config, payload)
        if ok:
            print_success(f"Test payload sent successfully to {grc_config.webhook_url}")
        else:
            print_error("Test payload failed — check webhook URL and credentials.")
            raise typer.Exit(1)
        print_post_hint("grc_push")
        return

    # Load latest scan results
    out = Path(config.output_dir)
    if event == "scan_complete":
        metrics_path = out / "scan_metrics.json"
        if not metrics_path.exists():
            print_error("No scan results found. Run 'sentrik scan' first.")
            raise typer.Exit(1)
        metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
        findings_summary = metrics.get("findings_by_severity", {})
        compliance = metrics.get("compliance_score", {})
        payload = build_scan_payload(findings_summary, compliance, project_name)

    elif event in ("gate_passed", "gate_failed"):
        metadata_path = out / "run_metadata.json"
        if not metadata_path.exists():
            print_error("No gate results found. Run 'sentrik gate' first.")
            raise typer.Exit(1)
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        from types import SimpleNamespace
        gate_data = SimpleNamespace(
            passed=(event == "gate_passed"),
            total_findings=metadata.get("findings_count", 0),
            critical=0, high=0, medium=0, low=0, info=0,
        )
        metrics_path = out / "scan_metrics.json"
        if metrics_path.exists():
            metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
            sev = metrics.get("findings_by_severity", {})
            gate_data.critical = sev.get("critical", 0)
            gate_data.high = sev.get("high", 0)
            gate_data.medium = sev.get("medium", 0)
            gate_data.low = sev.get("low", 0)
            gate_data.info = sev.get("info", 0)
        payload = build_gate_payload(gate_data, project_name)

    elif event == "vuln_scan":
        from guard.core.grc_integration import build_vuln_payload
        vuln_path = out / "vulnerabilities.json"
        if not vuln_path.exists():
            print_error("No vulnerability scan results found. Run 'sentrik vulns' first.")
            raise typer.Exit(1)
        vuln_data = json.loads(vuln_path.read_text(encoding="utf-8"))
        payload = build_vuln_payload(vuln_data, project_name)
    else:
        print_error(f"Unknown event type: {event}")
        print_hint("Supported events: scan_complete, gate_passed, gate_failed, vuln_scan")
        raise typer.Exit(1)

    ok = do_push(grc_config, payload)
    if ok:
        print_success(f"Event '{event}' pushed to {grc_config.platform} webhook.")
    else:
        print_error(f"Failed to push event '{event}' — check webhook URL and credentials.")
        raise typer.Exit(1)

    print_post_hint("grc_push")


# ---------------------------------------------------------------------------
# Auditor Portal — token management
# ---------------------------------------------------------------------------

auditor_app = typer.Typer(help="Manage auditor portal tokens.", rich_markup_mode="rich")
app.add_typer(auditor_app, name="auditor", rich_help_panel="Reports")


@auditor_app.command("create")
def auditor_create(
    name: str = typer.Option(..., "--name", "-n", help="Auditor's name."),
    email: str = typer.Option(..., "--email", "-e", help="Auditor's email address."),
    hours: int = typer.Option(72, "--hours", "-H", help="Token lifetime in hours (default 72)."),
    port: int = typer.Option(8000, "--port", "-p", help="Server port for the portal URL."),
    scope: str = typer.Option(
        None, "--scope", "-s",
        help="Comma-separated scopes (findings,compliance,audit_log,evidence,trends). Default: all.",
    ),
):
    """Create an auditor portal access token."""
    from guard.core.auditor_portal import generate_auditor_token

    scope_list = None
    if scope:
        scope_list = [s.strip() for s in scope.split(",") if s.strip()]

    tok = generate_auditor_token(name, email, expires_hours=hours, scope=scope_list)

    url = f"http://localhost:{port}/auditor?token={tok.token}"
    print_success(f"Auditor token created for {tok.auditor_name} <{tok.auditor_email}>")
    typer.echo(f"\n  Token:   {tok.token}")
    typer.echo(f"  Expires: {tok.expires_at}")
    typer.echo(f"  Scope:   {', '.join(tok.access_scope)}")
    typer.echo(f"\n  Portal URL: {url}\n")
    print_hint("Share the portal URL with the auditor. Start the server with 'sentrik dashboard'.")


@auditor_app.command("list")
def auditor_list():
    """List active auditor portal tokens."""
    from guard.core.auditor_portal import list_auditor_tokens

    tokens = list_auditor_tokens()
    if not tokens:
        typer.echo("No active auditor tokens.")
        return

    typer.echo(f"\n  {'Name':<25} {'Email':<30} {'Expires':<22} {'Token Prefix':<15}")
    typer.echo(f"  {'-' * 25} {'-' * 30} {'-' * 22} {'-' * 15}")
    for t in tokens:
        prefix = t.token[:12] + "..."
        typer.echo(f"  {t.auditor_name:<25} {t.auditor_email:<30} {t.expires_at:<22} {prefix:<15}")
    typer.echo()


@auditor_app.command("revoke")
def auditor_revoke(
    token_prefix: str = typer.Argument(help="Token or prefix of the token to revoke."),
):
    """Revoke an auditor portal token by prefix match."""
    from guard.core.auditor_portal import revoke_by_prefix

    count = revoke_by_prefix(token_prefix)
    if count:
        print_success(f"Revoked {count} token(s) matching prefix '{token_prefix}'.")
    else:
        print_error(f"No tokens found matching prefix '{token_prefix}'.")


@app.command(rich_help_panel="Analysis")
def check_policies(
    config: str = typer.Option(None, "--config", help="Path to policies YAML file."),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON."),
    init: bool = typer.Option(False, "--init", help="Generate a template policies.yaml file."),
):
    """Evaluate Policy-as-Code rules against the repository."""
    from guard.rules.policy_engine import (
        evaluate_policies,
        generate_template,
        load_policies,
        policy_results_to_findings,
    )

    if init:
        path = generate_template(config)
        print_success(f"Template policies file created: {path}")
        print_post_hint("check_policies")
        return

    policies = load_policies(config)
    if not policies:
        print_warning("No policies found. Run 'sentrik check-policies --init' to create a template.")
        return

    repo_root = str(find_repo_root())
    results = evaluate_policies(policies, repo_root)
    failed = [r for r in results if not r.passed]
    findings = policy_results_to_findings(failed)

    if json_output:
        import json as json_mod
        output = [
            {
                "policy_name": r.policy_name,
                "file": r.file,
                "line": r.line,
                "message": r.message,
                "severity": r.severity,
                "passed": r.passed,
            }
            for r in results
            if not r.passed
        ]
        typer.echo(json_mod.dumps(output, indent=2))
        return

    if not failed:
        print_success(f"All {len(policies)} policies passed.")
        print_post_hint("check_policies")
        return

    print_header("Policy Violations")

    from rich.table import Table
    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    table.add_column("Severity", width=10)
    table.add_column("Policy", style="cyan", width=30)
    table.add_column("File", width=35)
    table.add_column("Message", no_wrap=False)

    from guard.cli_output import severity_label

    for r in failed:
        file_display = f"{r.file}:{r.line}" if r.line > 0 else r.file
        table.add_row(
            severity_label(r.severity),
            r.policy_name[:30],
            file_display,
            r.message[:60],
        )

    console.print(table)
    console.print(f"\n  {len(failed)} violation(s) across {len(policies)} policies.")
    print_post_hint("check_policies")


@app.command("check-inline")
def check_inline(
    file: str = typer.Option("", "--file", "-f", help="Filename for language detection and rule matching."),
    code: str = typer.Option("", "--code", "-c", help="Code string to check."),
    stdin: bool = typer.Option(False, "--stdin", help="Read code from stdin."),
    context: str = typer.Option("", "--context", help="Print compliance context for the given filename as JSON."),
    frameworks: str = typer.Option("", "--frameworks", help="Comma-separated framework names to filter rules."),
):
    """Check code compliance inline (for AI agents).

    Examples:
        sentrik check-inline --file src/main.cpp --code "strcpy(dest, src);"
        sentrik check-inline --file src/main.cpp --stdin
        sentrik check-inline --context src/main.cpp
    """
    import json as _json

    fw_list = [f.strip() for f in frameworks.split(",") if f.strip()] or None

    # Context mode: print compliance context as JSON
    if context:
        from guard.sdk.checker import get_compliance_context
        ctx = get_compliance_context(context, fw_list)
        typer.echo(_json.dumps(ctx, indent=2))
        print_post_hint("check_inline")
        return

    # Determine the code to check
    if stdin:
        code_text = sys.stdin.read()
    elif code:
        code_text = code
    else:
        print_error("Provide --code, --stdin, or --context.")
        raise typer.Exit(1)

    if not file:
        print_error("--file is required for language detection.")
        raise typer.Exit(1)

    from guard.sdk.checker import check_code
    result = check_code(code_text, file, fw_list)

    if result.compliant:
        print_success(f"Compliant (confidence: {result.confidence:.0%})")
    else:
        print_warning(f"Non-compliant: {len(result.findings)} finding(s)")
        for f in result.findings:
            sev = f.get("severity", "medium")
            rule_id = f.get("rule_id", "")
            msg = f.get("message", "")
            console.print(f"  [{SEV_STYLES.get(sev, 'dim')}]{sev}[/] {rule_id}: {msg}")

        if result.suggestions:
            console.print("\n[hint]Suggestions:[/hint]")
            for s in result.suggestions:
                console.print(f"  - {s}")

    print_post_hint("check_inline")
    if not result.compliant:
        raise typer.Exit(1)


@app.command(name="mcp-server", rich_help_panel="Admin")
def mcp_server():
    """Start the MCP (Model Context Protocol) server for AI coding agents.

    Runs over stdio — configure this command in your AI tool's MCP settings.

    Example (Claude Code / .claude/claude_desktop_config.json):
        {"mcpServers": {"sentrik": {"command": "sentrik", "args": ["mcp-server"]}}}
    """
    from guard.mcp_server import _start_mcp_server
    _start_mcp_server()


@app.command(name="lsp-server", rich_help_panel="Admin")
def lsp_server_cmd():
    """Start the Language Server Protocol server for real-time scanning.

    Provides as-you-type compliance diagnostics in any LSP-compatible
    editor (VS Code, Neovim, Sublime Text). Runs fast regex rules only
    for low-latency feedback. Communicates over stdio.

    VS Code settings.json example:
        {"sentrik.lsp.enabled": true}
    """
    try:
        from guard.lsp_server import start_lsp_server
    except ImportError:
        print_error("LSP server requires pygls. Install with: pip install sentrik[lsp]")
        raise typer.Exit(1)
    start_lsp_server()


@app.command(name="audit-mcp", rich_help_panel="Analysis")
def audit_mcp(
    config: str = typer.Option("", help="Path to MCP config file (auto-discovers if not set)"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Audit MCP server configurations for security risks.

    Scans .mcp.json, .claude/mcp_servers.json, .cursor/mcp.json, and
    .vscode/mcp.json for dangerous tool definitions, hardcoded credentials,
    excessive filesystem scope, and shell execution risks.
    """
    from pathlib import Path as _Path
    from guard.core.mcp_audit import audit_mcp_config

    config_paths = [_Path(config)] if config else None
    result = audit_mcp_config(config_paths=config_paths)

    if json_output:
        import json as _json
        console.print(_json.dumps(result.to_dict(), indent=2))
    else:
        console.print(f"\n[bold]MCP Security Audit[/bold]")
        console.print(f"  Servers scanned: {result.servers_scanned}")
        console.print(f"  Tools scanned:   {result.tools_scanned}")
        console.print(f"  Findings:        {len(result.findings)}")
        console.print()

        if not result.findings:
            if result.servers_scanned == 0:
                console.print("[dim]No MCP configurations found.[/dim]")
            else:
                console.print("[green]✓ No security issues found.[/green]")
        else:
            for f in result.findings:
                color = {"critical": "red", "high": "yellow", "medium": "blue", "low": "dim"}.get(f.severity, "white")
                console.print(f"  [{color}]{f.severity.upper():8s}[/{color}]  {f.message}")
                if f.recommendation:
                    console.print(f"            -> {f.recommendation}")
            console.print()
            if result.passed:
                console.print("[green]✓ Audit passed (no critical/high findings).[/green]")
            else:
                console.print(f"[red]✗ Audit failed: {result.critical_count} critical, {result.high_count} high[/red]")
                raise typer.Exit(1)


if __name__ == "__main__":
    app()
