"""Allow running guard as ``python -m guard``."""
from guard.cli import app

if __name__ == "__main__":
    app()
