"""Compliance-aware AI agent SDK.

A lightweight library that AI coding agents can call during code generation
to check compliance *before* writing code.

Usage::

    from guard.sdk import check_code, check_diff, get_rules_for_file, get_compliance_context

    # Check a code snippet for compliance violations
    result = check_code("strcpy(dest, src);", "src/main.cpp", frameworks=["OWASP Top 10"])
    if not result.compliant:
        print(result.suggestions)

    # Get compliance context for an AI agent prompt
    ctx = get_compliance_context("src/patient_data.cpp")
    # Include ctx in your LLM prompt so it knows the rules before generating code
"""

from guard.sdk.checker import (
    ComplianceResult,
    check_code,
    check_diff,
    get_compliance_context,
    get_rules_for_file,
)

__all__ = [
    "ComplianceResult",
    "check_code",
    "check_diff",
    "get_compliance_context",
    "get_rules_for_file",
]
