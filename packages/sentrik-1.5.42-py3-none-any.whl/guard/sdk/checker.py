"""Core compliance checker for AI coding agents.

Provides a fast, lightweight API for checking code compliance without
file I/O, pipeline orchestration, or config loading. Designed to be
called per-file during code generation.
"""

from __future__ import annotations

import re
import tempfile
from dataclasses import dataclass, field
from fnmatch import fnmatch
from pathlib import Path
from typing import Any

from guard.packs.registry import load_pack_rules, list_available_packs
from guard.rules.engine import RulesEngine
from guard.rules.rule_schema import RuleDefinition


@dataclass
class ComplianceResult:
    """Result of a compliance check against code."""

    compliant: bool
    findings: list[dict] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)
    confidence: float = 1.0


def _get_all_pack_ids() -> list[str]:
    """Return all available pack IDs."""
    return [p.pack_id for p in list_available_packs()]


def _load_rules(frameworks: list[str] | None = None) -> list[dict[str, Any]]:
    """Load rules from packs, optionally filtered by framework names.

    If *frameworks* is ``None``, loads rules from all available packs.
    Framework names are matched case-insensitively against both the pack's
    ``standard`` field on rules and the pack ID itself.
    """
    # Load rules from enabled packs (respects project config)
    from guard.config import GuardConfig
    config = GuardConfig.load()
    enabled_packs = config.standards_packs if config.standards_packs else []

    if not enabled_packs and frameworks is None:
        # No config and no framework filter — load all packs as fallback
        all_packs = list_available_packs()
        enabled_packs = [p.pack_id for p in all_packs]

    all_rules: list[dict[str, Any]] = []
    for pid in enabled_packs:
        all_rules.extend(load_pack_rules(pid))

    if frameworks is None:
        return all_rules

    # Filter rules to those matching requested frameworks
    fw_lower = [f.lower() for f in frameworks]
    filtered: list[dict[str, Any]] = []
    for rule in all_rules:
        standard = (rule.get("standard") or "").lower()
        pack_id = (rule.get("pack_id") or "").lower()
        rule_id = (rule.get("id") or "").lower()
        if any(
            fw in standard or fw in pack_id or fw in rule_id
            for fw in fw_lower
        ):
            filtered.append(rule)
    return filtered


def _rules_matching_file(rules: list[dict[str, Any]], filename: str) -> list[dict[str, Any]]:
    """Filter rules whose file_glob matches *filename*."""
    matched: list[dict[str, Any]] = []
    for rule in rules:
        glob_pattern = rule.get("file_glob", "**/*")
        # fnmatch doesn't handle **/ well, so use a simple approach:
        # expand brace patterns like *.{py,cpp} and check each
        if _glob_matches(glob_pattern, filename):
            matched.append(rule)
    return matched


def _glob_matches(pattern: str, filename: str) -> bool:
    """Check if *filename* matches a glob *pattern*.

    Handles brace expansion (``*.{py,cpp}``) and ``**/`` prefixes.
    """
    # Strip leading **/ for fnmatch (it matches any directory depth)
    clean_pattern = pattern
    if clean_pattern.startswith("**/"):
        clean_pattern = clean_pattern[3:]

    # Handle brace expansion: *.{py,cpp,h} -> [*.py, *.cpp, *.h]
    brace_match = re.search(r"\{([^}]+)\}", clean_pattern)
    if brace_match:
        alternatives = brace_match.group(1).split(",")
        prefix = clean_pattern[: brace_match.start()]
        suffix = clean_pattern[brace_match.end() :]
        return any(
            fnmatch(Path(filename).name, f"{prefix}{alt.strip()}{suffix}")
            or fnmatch(filename, f"**/{prefix}{alt.strip()}{suffix}")
            or fnmatch(filename, f"{prefix}{alt.strip()}{suffix}")
            for alt in alternatives
        )

    # Simple glob
    basename = Path(filename).name
    return fnmatch(basename, clean_pattern) or fnmatch(filename, clean_pattern)


def _simplify_finding(finding: Any) -> dict:
    """Convert a Finding model to a simplified dict for SDK output."""
    if hasattr(finding, "model_dump"):
        d = finding.model_dump()
    elif isinstance(finding, dict):
        d = finding
    else:
        d = {"message": str(finding)}

    return {
        "rule_id": d.get("rule_id", ""),
        "severity": d.get("severity", "medium"),
        "message": d.get("message", ""),
        "file": d.get("evidence", {}).get("file", ""),
        "line": (d.get("evidence", {}).get("lines") or [0])[0],
        "suggestion": d.get("suggestion") or d.get("remediation_guidance") or "",
        "confidence": d.get("confidence", 1.0),
        "standard": d.get("standard"),
        "clause": d.get("clause"),
    }


def _generate_suggestions(findings: list[Any]) -> list[str]:
    """Extract unique, non-empty suggestions from findings."""
    seen: set[str] = set()
    suggestions: list[str] = []
    for f in findings:
        if hasattr(f, "model_dump"):
            d = f.model_dump()
        elif isinstance(f, dict):
            d = f
        else:
            continue
        s = d.get("suggestion") or d.get("remediation_guidance") or ""
        if s and s not in seen:
            seen.add(s)
            suggestions.append(s)
    return suggestions


def check_code(
    code: str,
    filename: str,
    frameworks: list[str] | None = None,
) -> ComplianceResult:
    """Check a code string for compliance violations.

    Args:
        code: The source code to check.
        filename: Filename for language detection and rule matching
            (e.g. ``"src/main.cpp"``).
        frameworks: Optional list of framework names to filter rules
            (e.g. ``["OWASP Top 10", "IEC 62304"]``). If ``None``,
            all available packs are checked.

    Returns:
        A :class:`ComplianceResult` with compliance status, findings,
        and remediation suggestions.
    """
    if not code or not code.strip():
        return ComplianceResult(compliant=True, confidence=1.0)

    rules = _load_rules(frameworks)
    rules = _rules_matching_file(rules, filename)

    if not rules:
        return ComplianceResult(compliant=True, confidence=1.0)

    # Write code to a temp file so the rules engine can evaluate it
    with tempfile.TemporaryDirectory() as tmpdir:
        file_path = Path(tmpdir) / filename
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(code, encoding="utf-8")

        engine = RulesEngine(rules)
        findings = engine.evaluate(tmpdir)

    # Filter out documentation obligations
    real_findings = [f for f in findings if not f.is_obligation]

    simplified = [_simplify_finding(f) for f in real_findings]
    suggestions = _generate_suggestions(real_findings)

    # Confidence is the minimum confidence across findings, or 1.0 if clean
    if real_findings:
        confidence = min(f.confidence for f in real_findings)
    else:
        confidence = 1.0

    return ComplianceResult(
        compliant=len(real_findings) == 0,
        findings=simplified,
        suggestions=suggestions,
        confidence=confidence,
    )


def check_diff(
    diff: str,
    frameworks: list[str] | None = None,
) -> ComplianceResult:
    """Check only the added lines in a unified diff for compliance violations.

    Args:
        diff: A unified diff string (output of ``git diff``).
        frameworks: Optional list of framework names to filter rules.

    Returns:
        A :class:`ComplianceResult` for the new/added code only.
    """
    if not diff or not diff.strip():
        return ComplianceResult(compliant=True, confidence=1.0)

    # Parse the diff to extract added lines per file
    files: dict[str, list[str]] = {}
    current_file: str | None = None

    for line in diff.splitlines():
        if line.startswith("+++ b/"):
            current_file = line[6:]
        elif line.startswith("+++ "):
            # Handle +++ a/path or +++ path
            current_file = line[4:].lstrip("/")
        elif line.startswith("+") and not line.startswith("+++"):
            if current_file:
                files.setdefault(current_file, [])
                files[current_file].append(line[1:])  # Strip leading +

    if not files:
        return ComplianceResult(compliant=True, confidence=1.0)

    # Check each file's added code
    all_findings: list[dict] = []
    all_suggestions: list[str] = []
    min_confidence = 1.0

    for filename, added_lines in files.items():
        code = "\n".join(added_lines)
        result = check_code(code, filename, frameworks)
        all_findings.extend(result.findings)
        all_suggestions.extend(result.suggestions)
        if result.confidence < min_confidence:
            min_confidence = result.confidence

    # Deduplicate suggestions
    seen: set[str] = set()
    unique_suggestions: list[str] = []
    for s in all_suggestions:
        if s not in seen:
            seen.add(s)
            unique_suggestions.append(s)

    return ComplianceResult(
        compliant=len(all_findings) == 0,
        findings=all_findings,
        suggestions=unique_suggestions,
        confidence=min_confidence,
    )


def get_rules_for_file(
    filename: str,
    frameworks: list[str] | None = None,
) -> list[dict]:
    """Return the rules that would apply to a file, by glob matching.

    Useful for AI agents to understand what constraints apply to a file
    before generating code for it.

    Args:
        filename: File path for matching (e.g. ``"src/main.cpp"``).
        frameworks: Optional list of framework names to filter rules.

    Returns:
        List of simplified rule dicts with ``id``, ``name``, ``description``,
        ``severity``, ``pattern``, ``standard``, ``clause``, and
        ``remediation_guidance``.
    """
    rules = _load_rules(frameworks)
    matched = _rules_matching_file(rules, filename)

    simplified: list[dict] = []
    for rule in matched:
        entry: dict[str, Any] = {
            "id": rule.get("id", ""),
            "name": rule.get("name", ""),
            "description": rule.get("description", ""),
            "severity": rule.get("severity", "medium"),
            "type": rule.get("type", ""),
        }
        if rule.get("pattern"):
            entry["pattern"] = rule["pattern"]
        if rule.get("all_patterns"):
            entry["patterns"] = rule["all_patterns"]
        if rule.get("standard"):
            entry["standard"] = rule["standard"]
        if rule.get("clause"):
            entry["clause"] = rule["clause"]
        if rule.get("remediation_guidance"):
            entry["remediation_guidance"] = rule["remediation_guidance"]
        simplified.append(entry)

    return simplified


def get_compliance_context(
    filename: str,
    frameworks: list[str] | None = None,
) -> dict:
    """Return a compliance context object for an AI agent to include in its prompt.

    This is the key SDK feature: an AI agent calls this *before* generating
    code to understand what compliance rules apply to the target file.

    Args:
        filename: Target file path (e.g. ``"src/patient_data.cpp"``).
        frameworks: Optional list of framework names to filter rules.

    Returns:
        A dict with::

            {
                "file": "src/patient_data.cpp",
                "applicable_rules": [...],
                "frameworks": ["HIPAA", "IEC 62304"],
                "constraints": ["Do not use printf with patient data", ...]
            }
    """
    rules = get_rules_for_file(filename, frameworks)

    # Extract unique framework names
    fw_set: set[str] = set()
    for rule in rules:
        if rule.get("standard"):
            fw_set.add(rule["standard"])

    # Generate human-readable constraints from rules
    constraints: list[str] = []
    for rule in rules:
        constraint = _rule_to_constraint(rule)
        if constraint:
            constraints.append(constraint)

    # Simplify rules for prompt inclusion (keep only essential fields)
    prompt_rules: list[dict] = []
    for rule in rules:
        entry: dict[str, Any] = {
            "id": rule["id"],
            "description": rule.get("description") or rule.get("name", ""),
        }
        if rule.get("pattern"):
            entry["pattern"] = rule["pattern"]
        if rule.get("patterns"):
            entry["patterns"] = rule["patterns"]
        prompt_rules.append(entry)

    return {
        "file": filename,
        "applicable_rules": prompt_rules,
        "frameworks": sorted(fw_set),
        "constraints": constraints,
    }


def _rule_to_constraint(rule: dict) -> str:
    """Convert a rule dict into a human-readable constraint string."""
    guidance = rule.get("remediation_guidance", "")
    description = rule.get("description", "")
    name = rule.get("name", "")
    rule_type = rule.get("type", "")

    # Prefer remediation_guidance as it's the most actionable
    if guidance:
        return guidance

    # For regex rules with patterns, describe what to avoid
    if rule_type == "regex" and description:
        return f"Avoid: {description}"

    # For required_pattern rules, describe what's needed
    if rule_type == "required_pattern" and description:
        return f"Required: {description}"

    # Fall back to description or name
    if description:
        return description
    if name:
        return name

    return ""
