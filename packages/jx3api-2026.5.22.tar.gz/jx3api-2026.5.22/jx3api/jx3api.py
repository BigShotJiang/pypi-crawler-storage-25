import logging
import os
from functools import wraps
from http import HTTPStatus
from typing import Any, Callable

import httpx

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s][%(levelname)s][%(module)s:%(funcName)s:%(lineno)d]: %(message)s",
)


class APIError(BaseException):
    def __init__(self, *, code: int, msg: str) -> None:
        self.code = code
        self.msg = msg


class JX3API:
    def __init__(
        self,
        *,
        token: str | None = None,
        ticket: str | None = None,
        base_url="https://www.jx3api.com",
        **kwargs,
    ):
        self.token = token or os.getenv("JX3API_TOKEN")
        self.ticket = ticket or os.getenv("JX3API_TICKET")

        self.client = httpx.Client(base_url=base_url, **kwargs)

        if not self.token:
            logging.warning(
                "The `token` parameter is not specified, only the free API can be used."
            )

    def request(self, *, endpoint: str, **kwargs):
        logging.debug(f"requesting: {endpoint=}, {kwargs=}")

        headers = {}

        if self.token:
            headers["token"] = self.token

        payload = {key: value for key, value in kwargs.items() if value is not None}

        if self.ticket:
            payload["ticket"] = self.ticket

        try:
            resp = self.client.post(endpoint, json=payload, headers=headers)
        except httpx.RequestError as exc:
            raise APIError(code=0, msg=str(exc)) from exc

        try:
            resp.raise_for_status()
            data = resp.json()

        except httpx.HTTPStatusError as exc:
            raise APIError(
                code=exc.response.status_code, msg=exc.response.text
            ) from exc

        except ValueError as exc:
            raise APIError(code=resp.status_code, msg="Invalid JSON response.") from exc

        if data.get("code") != HTTPStatus.OK:
            raise APIError(
                code=data.get("code", resp.status_code),
                msg=data.get("msg", "Unknown API error."),
            )

        return data.get("data")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.client.close()

    @staticmethod
    def require_token(func: Callable[..., Any]):
        @wraps(func)
        def decorator(self, *args, **kwargs):
            if not self.token:
                raise ValueError(
                    "The `token` parameter is not specified, only the free API can be used."
                )

            return func(self, *args, **kwargs)

        return decorator

    @staticmethod
    def require_ticket(func: Callable[..., Any]):
        @wraps(func)
        def decorator(self, *args, **kwargs):
            if not self.ticket:
                raise ValueError("The `ticket` parameter must be specified.")

            return func(self, *args, **kwargs)

        return decorator

    def active_calendar(self, *, server=None, num=0):
        return self.request(endpoint="/data/active/calendar", server=server, num=num)

    def active_celebs(self, *, name):
        return self.request(endpoint="/data/active/celebs", name=name)

    def active_list_calendar(self, *, num=15):
        return self.request(endpoint="/data/active/list/calendar", num=num)

    def exam_search(self, *, subject, limit=10):
        return self.request(endpoint="/data/exam/search", subject=subject, limit=limit)

    def home_furniture(self, *, name):
        return self.request(endpoint="/data/home/furniture", name=name)

    def home_travel(self, *, name):
        return self.request(endpoint="/data/home/travel", name=name)

    def news_allnews(self, *, limit=10):
        return self.request(endpoint="/data/news/allnews", limit=limit)

    def news_announce(self, *, limit=10):
        return self.request(endpoint="/data/news/announce", limit=limit)

    def master_search(self, *, name):
        return self.request(endpoint="/data/master/search", name=name)

    def status_check(self, *, server, type=1):
        return self.request(endpoint="/data/status/check", type=type, server=server)

    def home_flower(self, *, server, name=None, map=None):
        return self.request(
            endpoint="/data/home/flower", server=server, name=name, map=map
        )

    def skill_rework(self):
        return self.request(endpoint="/data/skill/rework")

    def school_foods(self):
        return self.request(endpoint="/data/school/foods")

    ##########
    # VIP  I #
    ##########

    @require_token
    @require_ticket
    def role_detail(self, *, server, name):
        return self.request(endpoint="/data/role/detail", server=server, name=name)

    @require_token
    @require_ticket
    def school_matrix(self, *, name):
        return self.request(endpoint="/data/school/matrix", name=name)

    @require_token
    @require_ticket
    def school_talent(self, *, name):
        return self.request(endpoint="/data/school/talent", name=name)

    @require_token
    @require_ticket
    def school_skills(self, *, name):
        return self.request(endpoint="/data/school/skills", name=name)

    @require_token
    def tieba_random(self, *, tags, server="-", limit=10):
        return self.request(
            endpoint="/data/tieba/random", tags=tags, server=server, limit=limit
        )

    @require_token
    @require_ticket
    def event_records(self, *, server, name):
        return self.request(endpoint="/data/event/records", server=server, name=name)

    @require_token
    def event_statistics(self, *, server=None, name, limit=50):
        return self.request(
            endpoint="/data/event/statistics", server=server, name=name, limit=limit
        )

    @require_token
    def event_collect(self, *, server, num=7):
        return self.request(endpoint="/data/event/collect", server=server, num=num)

    @require_token
    @require_ticket
    def arena_recent(self, *, server, name, mode=None):
        return self.request(
            endpoint="/data/arena/recent", server=server, name=name, mode=mode
        )

    @require_token
    @require_ticket
    def arena_awesome(self, *, mode=33, limit=20):
        return self.request(endpoint="/data/arena/awesome", mode=mode, limit=limit)

    @require_token
    @require_ticket
    def arena_schools(self, *, mode=33):
        return self.request(endpoint="/data/arena/schools", mode=mode)

    @require_token
    def recruit_search(self, *, server, keyword=None, type=1):
        return self.request(
            endpoint="/data/recruit/search", server=server, keyword=keyword, type=type
        )

    @require_token
    def mentor_search(self, *, type, server, keyword=None):
        return self.request(
            endpoint="/data/mentor/search", type=type, server=server, keyword=keyword
        )

    @require_token
    def sand_records(self, *, server):
        return self.request(endpoint="/data/sand/records", server=server)

    @require_token
    def fenxian_records(self):
        return self.request(endpoint="/data/fenxian/records")

    @require_token
    def trade_demon(self, *, server=None, limit=10):
        return self.request(endpoint="/data/trade/demon", server=server, limit=limit)

    @require_token
    def trade_records(self, *, name, server=None):
        return self.request(endpoint="/data/trade/records", server=server, name=name)

    @require_token
    def tieba_item_records(self, *, server="-", name, limit=10):
        return self.request(
            endpoint="/data/tieba/item/records", server=server, name=name, limit=limit
        )

    @require_token
    def reward_statistics(self, *, server=None, name, limit=20):
        return self.request(
            endpoint="/data/reward/statistics", server=server, name=name, limit=limit
        )

    @require_token
    def smite_records(self):
        return self.request(endpoint="/data/smite/records")

    @require_token
    def rank_statistics(self, *, server=None, name):
        return self.request(endpoint="/data/rank/statistics", server=server, name=name)

    @require_token
    @require_ticket
    def school_seniority(self, *, school=None, server=None):
        return self.request(
            endpoint="/data/school/seniority", school=school, server=server
        )

    @require_token
    def fraud_detail(self, *, uid):
        return self.request(endpoint="/data/fraud/detail", uid=uid)

    ##########
    # VIP II #
    ##########

    @require_token
    def active_monster(self):
        return self.request(endpoint="/data/active/monster")

    @require_token
    def active_next_event(self, *, server=None):
        return self.request(endpoint="/data/active/next/event", server=server)

    @require_token
    def auction_records(self, *, server, name=None, limit=50):
        return self.request(
            endpoint="/data/auction/records", server=server, name=name, limit=limit
        )

    @require_token
    def steed_records(self, *, server):
        return self.request(endpoint="/data/steed/records", server=server)

    @require_token
    def ranch_records(self, *, server):
        return self.request(endpoint="/data/ranch/records", server=server)

    @require_token
    def show_records(self, *, server, name):
        return self.request(endpoint="/data/show/records", server=server, name=name)

    @require_token
    def card_record(self, *, server, name):
        return self.request(endpoint="/data/card/record", server=server, name=name)

    @require_token
    def card_cached(self, *, server, name):
        return self.request(endpoint="/data/card/cached", server=server, name=name)

    @require_token
    def card_records(self, *, server, name):
        return self.request(endpoint="/data/card/records", server=server, name=name)

    @require_token
    def card_random(self, *, server, body=None, force=None):
        return self.request(
            endpoint="/data/card/random", server=server, body=body, force=force
        )

    @require_token
    def role_monster(self, *, server, name):
        return self.request(endpoint="/data/role/monster", server=server, name=name)

    @require_token
    def mine_cart(self):
        return self.request(endpoint="/data/mine/cart")

    @require_token
    def chitu_records(self):
        return self.request(endpoint="/data/chitu/records")

    @require_token
    def chitu_week_records(self):
        return self.request(endpoint="/data/chitu/week/records")

    @require_token
    def rank_trials(self, *, name, server=None):
        return self.request(endpoint="/data/rank/trials", server=server, name=name)

    @require_token
    def trade_item_search(self, *, name):
        return self.request(endpoint="/data/trade/item/search", name=name)

    @require_token
    def trade_item_records(self, *, name, server=None):
        return self.request(
            endpoint="/data/trade/item/records", server=server, name=name
        )

    @require_token
    def battle_records(self, *, server):
        return self.request(endpoint="/data/battle/records", server=server)

    def mech_calculator(self):
        return self.request(endpoint="/data/mech/calculator")

    @require_token
    def duowan_statistics(self, *, server):
        return self.request(endpoint="/data/duowan/statistics", server=server)

    #############
    #    VRF    #
    #############
    def saohua_random(self):
        return self.request(endpoint="/data/saohua/random")

    def saohua_content(self):
        return self.request(endpoint="/data/saohua/content")

    def sound_converter(
        self,
        *,
        appkey,
        access,
        secret,
        text,
        voice="Aitong",
        format="MP3",
        sample_rate=16000,
        volume=50,
        speech_rate=0,
        pitch_rate=0,
    ):
        return self.request(
            endpoint="/data/sound/converter",
            appkey=appkey,
            access=access,
            secret=secret,
            text=text,
            voice=voice,
            format=format,
            sample_rate=sample_rate,
            volume=volume,
            speech_rate=speech_rate,
            pitch_rate=pitch_rate,
        )


class AsyncJX3API:
    def __init__(
        self,
        *,
        token: str | None = None,
        ticket: str | None = None,
        base_url: str = "https://www.jx3api.com",
        **kwargs,
    ):
        self.token = token or os.getenv("JX3API_TOKEN")
        self.ticket = ticket or os.getenv("JX3API_TICKET")

        self.client = httpx.AsyncClient(base_url=base_url, **kwargs)

        if not self.token:
            logging.warning(
                "The `token` parameter is not specified, only the free API can be used."
            )

    async def request(self, *, endpoint: str, **kwargs):
        logging.debug(f"requesting: {endpoint=}, {kwargs=}")

        headers = {}

        payload = {key: value for key, value in kwargs.items() if value is not None}

        if self.token:
            headers["token"] = self.token

        if self.ticket:
            payload["ticket"] = self.ticket

        try:
            resp = await self.client.post(endpoint, json=payload, headers=headers)
        except httpx.RequestError as exc:
            raise APIError(code=0, msg=str(exc)) from exc

        try:
            resp.raise_for_status()
            data = resp.json()
        except httpx.HTTPStatusError as exc:
            raise APIError(
                code=exc.response.status_code, msg=exc.response.text
            ) from exc
        except ValueError as exc:
            raise APIError(code=resp.status_code, msg="Invalid JSON response.") from exc

        if not isinstance(data, dict):
            raise APIError(code=resp.status_code, msg="Unexpected API response.")

        if data.get("code") != HTTPStatus.OK:
            raise APIError(
                code=data.get("code", resp.status_code),
                msg=data.get("msg", "Unknown API error."),
            )

        return data.get("data")

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_value, traceback):
        await self.client.aclose()

    @staticmethod
    def require_token(func: Callable[..., Any]):
        @wraps(func)
        async def decorator(self, *args, **kwargs):
            if not self.token:
                raise ValueError(
                    "The `token` parameter is not specified, only the free API can be used."
                )

            return await func(self, *args, **kwargs)

        return decorator

    @staticmethod
    def require_ticket(func: Callable[..., Any]):
        @wraps(func)
        async def decorator(self, *args, **kwargs):
            if not self.ticket:
                raise ValueError("The `ticket` parameter must be specified.")

            return await func(self, *args, **kwargs)

        return decorator

    async def active_calendar(self, *, server=None, num=0):
        return await self.request(
            endpoint="/data/active/calendar", server=server, num=num
        )

    async def active_celebs(self, *, name):
        return await self.request(endpoint="/data/active/celebs", name=name)

    async def active_list_calendar(self, *, num=15):
        return await self.request(endpoint="/data/active/list/calendar", num=num)

    async def exam_search(self, *, subject, limit=10):
        return await self.request(
            endpoint="/data/exam/search", subject=subject, limit=limit
        )

    async def home_furniture(self, *, name):
        return await self.request(endpoint="/data/home/furniture", name=name)

    async def home_travel(self, *, name):
        return await self.request(endpoint="/data/home/travel", name=name)

    async def news_allnews(self, *, limit=10):
        return await self.request(endpoint="/data/news/allnews", limit=limit)

    async def news_announce(self, *, limit=10):
        return await self.request(endpoint="/data/news/announce", limit=limit)

    async def master_search(self, *, name):
        return await self.request(endpoint="/data/master/search", name=name)

    async def status_check(self, *, server, type=1):
        return await self.request(
            endpoint="/data/status/check", type=type, server=server
        )

    async def home_flower(self, *, server, name=None, map=None):
        return await self.request(
            endpoint="/data/home/flower", server=server, name=name, map=map
        )

    async def skill_rework(self):
        return await self.request(endpoint="/data/skill/rework")

    async def school_foods(self):
        return await self.request(endpoint="/data/school/foods")

    ##########
    # VIP  I #
    ##########

    @require_token
    @require_ticket
    async def role_detail(self, *, server, name):
        return await self.request(
            endpoint="/data/role/detail", server=server, name=name
        )

    @require_token
    @require_ticket
    async def school_matrix(self, *, name):
        return await self.request(endpoint="/data/school/matrix", name=name)

    @require_token
    @require_ticket
    async def school_talent(self, *, name):
        return await self.request(endpoint="/data/school/talent", name=name)

    @require_token
    @require_ticket
    async def school_skills(self, *, name):
        return await self.request(endpoint="/data/school/skills", name=name)

    @require_token
    async def tieba_random(self, *, tags, server="-", limit=10):
        return await self.request(
            endpoint="/data/tieba/random", tags=tags, server=server, limit=limit
        )

    @require_token
    @require_ticket
    async def event_records(self, *, server, name):
        return await self.request(
            endpoint="/data/event/records", server=server, name=name
        )

    @require_token
    async def event_statistics(self, *, server=None, name, limit=50):
        return await self.request(
            endpoint="/data/event/statistics", server=server, name=name, limit=limit
        )

    @require_token
    async def event_collect(self, *, server, num=7):
        return await self.request(
            endpoint="/data/event/collect", server=server, num=num
        )

    @require_token
    @require_ticket
    async def arena_recent(self, *, server, name, mode=None):
        return await self.request(
            endpoint="/data/arena/recent", server=server, name=name, mode=mode
        )

    @require_token
    @require_ticket
    async def arena_awesome(self, *, mode=33, limit=20):
        return await self.request(
            endpoint="/data/arena/awesome", mode=mode, limit=limit
        )

    @require_token
    @require_ticket
    async def arena_schools(self, *, mode=33):
        return await self.request(endpoint="/data/arena/schools", mode=mode)

    @require_token
    async def recruit_search(self, *, server, keyword=None, type=1):
        return await self.request(
            endpoint="/data/recruit/search", server=server, keyword=keyword, type=type
        )

    @require_token
    async def mentor_search(self, *, type, server, keyword=None):
        return await self.request(
            endpoint="/data/mentor/search", type=type, server=server, keyword=keyword
        )

    @require_token
    async def sand_records(self, *, server):
        return await self.request(endpoint="/data/sand/records", server=server)

    @require_token
    async def fenxian_records(self):
        return await self.request(endpoint="/data/fenxian/records")

    @require_token
    async def trade_demon(self, *, server=None, limit=10):
        return await self.request(
            endpoint="/data/trade/demon", server=server, limit=limit
        )

    @require_token
    async def trade_records(self, *, name, server=None):
        return await self.request(
            endpoint="/data/trade/records", server=server, name=name
        )

    @require_token
    async def tieba_item_records(self, *, server="-", name, limit=10):
        return await self.request(
            endpoint="/data/tieba/item/records", server=server, name=name, limit=limit
        )

    @require_token
    async def reward_statistics(self, *, server=None, name, limit=20):
        return await self.request(
            endpoint="/data/reward/statistics", server=server, name=name, limit=limit
        )

    @require_token
    async def smite_records(self):
        return await self.request(endpoint="/data/smite/records")

    @require_token
    async def rank_statistics(self, *, server=None, name):
        return await self.request(
            endpoint="/data/rank/statistics", server=server, name=name
        )

    @require_token
    @require_ticket
    async def school_seniority(self, *, school=None, server=None):
        return await self.request(
            endpoint="/data/school/seniority", school=school, server=server
        )

    @require_token
    async def fraud_detail(self, *, uid):
        return await self.request(endpoint="/data/fraud/detail", uid=uid)

    ##########
    # VIP II #
    ##########

    @require_token
    async def active_monster(
        self,
    ):
        return await self.request(endpoint="/data/active/monster")

    @require_token
    async def active_next_event(self, *, server=None):
        return await self.request(endpoint="/data/active/next/event", server=server)

    @require_token
    async def auction_records(self, *, server, name=None, limit=50):
        return await self.request(
            endpoint="/data/auction/records", server=server, name=name, limit=limit
        )

    @require_token
    async def steed_records(self, *, server):
        return await self.request(endpoint="/data/steed/records", server=server)

    @require_token
    async def ranch_records(self, *, server):
        return await self.request(endpoint="/data/ranch/records", server=server)

    @require_token
    async def show_records(self, *, server, name):
        return await self.request(
            endpoint="/data/show/records", server=server, name=name
        )

    @require_token
    async def card_record(self, *, server, name):
        return await self.request(
            endpoint="/data/card/record", server=server, name=name
        )

    @require_token
    async def card_cached(self, *, server, name):
        return await self.request(
            endpoint="/data/card/cached", server=server, name=name
        )

    @require_token
    async def card_records(self, *, server, name):
        return await self.request(
            endpoint="/data/card/records", server=server, name=name
        )

    @require_token
    async def card_random(self, *, server, body=None, force=None):
        return await self.request(
            endpoint="/data/card/random", server=server, body=body, force=force
        )

    @require_token
    async def role_monster(self, *, server, name):
        return await self.request(
            endpoint="/data/role/monster", server=server, name=name
        )

    @require_token
    async def mine_cart(self):
        return await self.request(endpoint="/data/mine/cart")

    @require_token
    async def chitu_records(self):
        return await self.request(endpoint="/data/chitu/records")

    @require_token
    async def chitu_week_records(self):
        return await self.request(endpoint="/data/chitu/week/records")

    @require_token
    async def rank_trials(self, *, name, server=None):
        return await self.request(
            endpoint="/data/rank/trials", server=server, name=name
        )

    @require_token
    async def trade_item_search(self, *, name):
        return await self.request(endpoint="/data/trade/item/search", name=name)

    @require_token
    async def trade_item_records(self, *, name, server=None):
        return await self.request(
            endpoint="/data/trade/item/records", server=server, name=name
        )

    @require_token
    async def battle_records(self, *, server):
        return await self.request(endpoint="/data/battle/records", server=server)

    async def mech_calculator(self):
        return await self.request(endpoint="/data/mech/calculator")

    @require_token
    async def duowan_statistics(self, *, server):
        return await self.request(endpoint="/data/duowan/statistics", server=server)

    #############
    #    VRF    #
    #############
    async def saohua_random(self):
        return await self.request(endpoint="/data/saohua/random")

    async def saohua_content(self):
        return await self.request(endpoint="/data/saohua/content")

    async def sound_converter(
        self,
        *,
        appkey,
        access,
        secret,
        text,
        voice="Aitong",
        format="MP3",
        sample_rate=16000,
        volume=50,
        speech_rate=0,
        pitch_rate=0,
    ):
        return await self.request(
            endpoint="/data/sound/converter",
            appkey=appkey,
            access=access,
            secret=secret,
            text=text,
            voice=voice,
            format=format,
            sample_rate=sample_rate,
            volume=volume,
            speech_rate=speech_rate,
            pitch_rate=pitch_rate,
        )
