"""Bodhisattva MCP: pause the agent before it sends something it'll regret."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

try:
    __version__ = _pkg_version("bodhisattva-mcp")
except PackageNotFoundError:  # pragma: no cover — source checkout without install
    __version__ = "0.0.0+dev"
