"""Unit tests for ravimail.Client + error mapping + signature verification."""
from __future__ import annotations

import hashlib
import hmac

import pytest
import requests_mock

from ravimail import (
    ApiError,
    AuthenticationError,
    Client,
    RateLimitError,
    ValidationError,
    verify_signature,
)

VALID_TOKEN = "rvm_test_" + "a" * 32


class TestClientConstructor:
    def test_accepts_valid_token(self) -> None:
        Client(VALID_TOKEN)  # should not raise

    def test_rejects_garbage(self) -> None:
        with pytest.raises(ValueError, match="Invalid token format"):
            Client("garbage")

    def test_rejects_wrong_prefix(self) -> None:
        with pytest.raises(ValueError):
            Client("rvm_prod_" + "a" * 32)

    def test_rejects_short_hex(self) -> None:
        with pytest.raises(ValueError):
            Client("rvm_test_abc")


class TestRequestMapping:
    def test_200_returns_decoded_body(self) -> None:
        rm = Client(VALID_TOKEN)
        with requests_mock.Mocker() as m:
            m.post(
                "https://api.ravimail.com.br/v1/transactional/send",
                json={"data": {"message_id": "msg_x", "status": "sent"}},
                status_code=200,
            )
            resp = rm.transactional.send(
                to="a@b.com", from_="c@d.com", subject="X", html="<p>hi</p>"
            )
            assert resp["data"]["message_id"] == "msg_x"
            assert m.last_request.headers["Authorization"] == f"Bearer {VALID_TOKEN}"

    def test_401_raises_authentication_error(self) -> None:
        rm = Client(VALID_TOKEN)
        with requests_mock.Mocker() as m:
            m.get(
                "https://api.ravimail.com.br/v1/me",
                json={"title": "Invalid", "detail": "revoked"},
                status_code=401,
            )
            with pytest.raises(AuthenticationError):
                rm.me.get()

    def test_422_raises_validation_error_with_detail(self) -> None:
        rm = Client(VALID_TOKEN)
        with requests_mock.Mocker() as m:
            m.post(
                "https://api.ravimail.com.br/v1/transactional/send",
                json={"title": "Validation", "detail": "`to` is required"},
                status_code=422,
            )
            with pytest.raises(ValidationError) as exc:
                rm.transactional.send(to="", from_="c@d.com", subject="X")
            assert exc.value.detail == "`to` is required"

    def test_429_raises_rate_limit_with_retry_after(self) -> None:
        rm = Client(VALID_TOKEN)
        with requests_mock.Mocker() as m:
            m.get(
                "https://api.ravimail.com.br/v1/me",
                json={"title": "Slow down"},
                status_code=429,
                headers={"Retry-After": "7"},
            )
            with pytest.raises(RateLimitError) as exc:
                rm.me.get()
            assert exc.value.retry_after_seconds == 7

    def test_503_raises_generic_api_error(self) -> None:
        rm = Client(VALID_TOKEN)
        with requests_mock.Mocker() as m:
            m.get(
                "https://api.ravimail.com.br/v1/me",
                json={"title": "Server boom"},
                status_code=503,
            )
            with pytest.raises(ApiError) as exc:
                rm.me.get()
            assert exc.value.status == 503


class TestWebhookSignature:
    def test_valid_signature(self) -> None:
        secret = "whsec_test"
        body = b'{"event":"test"}'
        expected = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        assert verify_signature(expected, body, secret) is True

    def test_valid_signature_string_body(self) -> None:
        secret = "whsec_test"
        body = '{"event":"test"}'
        expected = "sha256=" + hmac.new(secret.encode(), body.encode(), hashlib.sha256).hexdigest()
        assert verify_signature(expected, body, secret) is True

    def test_tampered_signature(self) -> None:
        assert verify_signature("sha256=" + "a" * 64, b'{"event":"test"}', "whsec_test") is False

    def test_empty_signature(self) -> None:
        assert verify_signature("", b"{}", "whsec_test") is False
