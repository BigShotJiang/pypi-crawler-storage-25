# Contributing to ravimail (Python SDK)

This SDK is the Python port of [`ravimail-php`](https://github.com/ravisystems/ravimail-php)
and [`ravimail-node`](https://github.com/ravisystems/ravimail-node). We keep all
three feature-symmetric.

## Quick start

```bash
git clone https://github.com/ravisystems/ravimail-python
cd ravimail-python
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest
```

**Requirements:** Python 3.9+.

## What we welcome

- **Bug reports** with a minimal reproducer.
- **New endpoint coverage** — add a method to the matching
  `src/ravimail/resources/*.py` class.
- **Type narrowing** — replacing `Any` with concrete `TypedDict` / dataclass.
- **Examples** in `examples/`.

## What we don't want

- **Heavy dependencies.** Just `requests`. No `httpx`, no `aiohttp`, no `pydantic`.
- **Breaking changes without a major version bump.**

## Style

- 4-space indentation.
- `from __future__ import annotations` at top of every file.
- Strict mypy (`mypy --strict`).
- Ruff with `line-length = 100`.

## Submitting a PR

1. Fork → branch → commit → push → PR against `main`.
2. Run `pytest && mypy src && ruff check .` and make sure all green.
3. Include a snippet showing the new public API in use.

## Releasing (maintainers)

1. Bump `version` in `pyproject.toml` and `VERSION`/`__version__`.
2. Update `CHANGELOG.md`.
3. `git tag vX.Y.Z && git push --tags`.
4. `python -m build && twine upload dist/*` (or use GitHub Actions).

Report incidents to `dev@ravimail.com.br`.
