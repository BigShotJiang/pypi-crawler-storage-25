from __future__ import annotations

from typing import Any, Iterable, Mapping

from ._base import Resource


class Webhooks(Resource):
    def list_endpoints(self) -> Any:
        return self._client.request("GET", "/v1/webhooks/endpoints")

    def create_endpoint(
        self, *, url: str, events: Iterable[str], description: str = ""
    ) -> Any:
        return self._client.request(
            "POST", "/v1/webhooks/endpoints",
            json={"url": url, "events": list(events), "description": description},
        )

    def get_endpoint(self, endpoint_id: int) -> Any:
        return self._client.request("GET", f"/v1/webhooks/endpoints/{endpoint_id}")

    def update_endpoint(self, endpoint_id: int, **patch: Any) -> Any:
        return self._client.request("PUT", f"/v1/webhooks/endpoints/{endpoint_id}", json=patch)

    def delete_endpoint(self, endpoint_id: int) -> Any:
        return self._client.request("DELETE", f"/v1/webhooks/endpoints/{endpoint_id}")

    def test_endpoint(self, endpoint_id: int, **data: Any) -> Any:
        return self._client.request("POST", f"/v1/webhooks/endpoints/{endpoint_id}/test", json=data or None)

    def rotate_secret(self, endpoint_id: int) -> Any:
        return self._client.request("POST", f"/v1/webhooks/endpoints/{endpoint_id}/rotate-secret")

    def list_deliveries(self, **filters: Any) -> Any:
        return self._client.request("GET", "/v1/webhooks/deliveries", params=filters or None)

    def replay_delivery(self, delivery_id: int) -> Any:
        return self._client.request("POST", f"/v1/webhooks/deliveries/{delivery_id}/replay")
