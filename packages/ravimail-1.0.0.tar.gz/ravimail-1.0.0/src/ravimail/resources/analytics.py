from __future__ import annotations

from typing import Any

from ._base import Resource


class Analytics(Resource):
    def summary(self, range: str = "24h") -> Any:     return self._client.request("GET", "/v1/analytics/summary",   params={"range": range})
    def timeseries(self, metric: str, range: str = "24h") -> Any:
        return self._client.request("GET", "/v1/analytics/timeseries", params={"metric": metric, "range": range})
    def by_domain(self, range: str = "24h") -> Any:   return self._client.request("GET", "/v1/analytics/by-domain", params={"range": range})
    def by_ip(self, range: str = "24h") -> Any:       return self._client.request("GET", "/v1/analytics/by-ip",     params={"range": range})
    def by_node(self, range: str = "24h") -> Any:     return self._client.request("GET", "/v1/analytics/by-node",   params={"range": range})
    def by_isp(self, range: str = "24h") -> Any:      return self._client.request("GET", "/v1/analytics/by-isp",    params={"range": range})
    def by_device(self, range: str = "24h") -> Any:   return self._client.request("GET", "/v1/analytics/by-device", params={"range": range})
    def by_country(self, range: str = "24h") -> Any:  return self._client.request("GET", "/v1/analytics/by-country", params={"range": range})
    def clicks_heatmap(self, **filters: Any) -> Any:
        return self._client.request("GET", "/v1/analytics/clicks/heatmap", params=filters or None)
