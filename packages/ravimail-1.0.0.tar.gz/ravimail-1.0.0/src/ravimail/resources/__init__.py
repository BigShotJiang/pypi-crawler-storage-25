"""All resource classes — instantiated by Client and exposed as attributes."""
from .account import Account
from .analytics import Analytics
from .campaigns import Campaigns
from .contacts import Contacts
from .custom_fields import CustomFields
from .domains import Domains
from .drips import Drips
from .events import Events
from .exports import Exports
from .files import Files
from .inbound_routes import InboundRoutes
from .lists import Lists
from .me import Me
from .reports import Reports
from .reputation import Reputation
from .segments import Segments
from .smtp_relay import SmtpRelay
from .subaccounts import Subaccounts
from .suppression import Suppression
from .templates import Templates
from .transactional import Transactional
from .verification import Verification
from .webhooks import Webhooks

__all__ = [
    "Account", "Analytics", "Campaigns", "Contacts", "CustomFields", "Domains", "Drips",
    "Events", "Exports", "Files", "InboundRoutes", "Lists", "Me", "Reports", "Reputation",
    "Segments", "SmtpRelay", "Subaccounts", "Suppression", "Templates", "Transactional",
    "Verification", "Webhooks",
]
