from __future__ import annotations

from typing import Any, Iterable, Mapping, Optional, Union

from ._base import Resource


class Transactional(Resource):
    def send(
        self,
        *,
        to: Union[str, Iterable[str]],
        from_: str,
        subject: str,
        html: Optional[str] = None,
        text: Optional[str] = None,
        reply_to: Optional[str] = None,
        cc: Optional[Union[str, Iterable[str]]] = None,
        bcc: Optional[Union[str, Iterable[str]]] = None,
        attachments: Optional[Iterable[Mapping[str, Any]]] = None,
        headers: Optional[Mapping[str, str]] = None,
        tags: Optional[Iterable[str]] = None,
        metadata: Optional[Mapping[str, Any]] = None,
        idempotency_key: Optional[str] = None,
        **extra: Any,
    ) -> Any:
        """Send a single transactional message.

        Note: ``from_`` is the parameter name (``from`` is a Python reserved word);
        the request body uses ``from``.
        """
        payload: dict[str, Any] = {"to": to, "from": from_, "subject": subject, **extra}
        if html is not None:        payload["html"] = html
        if text is not None:        payload["text"] = text
        if reply_to is not None:    payload["reply_to"] = reply_to
        if cc is not None:          payload["cc"] = cc
        if bcc is not None:         payload["bcc"] = bcc
        if attachments is not None: payload["attachments"] = list(attachments)
        if headers is not None:     payload["headers"] = dict(headers)
        if tags is not None:        payload["tags"] = list(tags)
        if metadata is not None:    payload["metadata"] = dict(metadata)

        extra_headers = {"Idempotency-Key": idempotency_key} if idempotency_key else None
        return self._client.request("POST", "/v1/transactional/send", json=payload, extra_headers=extra_headers)

    def batch(self, messages: Iterable[Mapping[str, Any]], idempotency_key: Optional[str] = None) -> Any:
        extra_headers = {"Idempotency-Key": idempotency_key} if idempotency_key else None
        return self._client.request(
            "POST", "/v1/transactional/batch",
            json={"messages": list(messages)},
            extra_headers=extra_headers,
        )

    def list(self, **filters: Any) -> Any:
        return self._client.request("GET", "/v1/transactional/messages", params=filters or None)

    def get(self, message_id: str) -> Any:
        from urllib.parse import quote
        return self._client.request("GET", f"/v1/transactional/messages/{quote(message_id, safe='')}")
