from __future__ import annotations

from typing import Any, Mapping

from ._base import Resource


class Templates(Resource):
    def list(self, **filters: Any) -> Any:
        return self._client.request("GET", "/v1/templates", params=filters or None)
    def create(self, **data: Any) -> Any:
        return self._client.request("POST", "/v1/templates", json=data)
    def get(self, template_id: int) -> Any:
        return self._client.request("GET", f"/v1/templates/{template_id}")
    def update(self, template_id: int, **patch: Any) -> Any:
        return self._client.request("PUT", f"/v1/templates/{template_id}", json=patch)
    def delete(self, template_id: int) -> Any:
        return self._client.request("DELETE", f"/v1/templates/{template_id}")
    def render(self, template_id: int, variables: Mapping[str, Any] = {}) -> Any:
        return self._client.request("POST", f"/v1/templates/{template_id}/render", json={"variables": dict(variables)})
    def list_versions(self, template_id: int) -> Any:
        return self._client.request("GET", f"/v1/templates/{template_id}/versions")
    def get_version(self, template_id: int, version: int) -> Any:
        return self._client.request("GET", f"/v1/templates/{template_id}/versions/{version}")
    def rollback(self, template_id: int, version: int) -> Any:
        return self._client.request("POST", f"/v1/templates/{template_id}/versions/{version}/rollback")
