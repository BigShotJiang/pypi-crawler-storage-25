from __future__ import annotations

from typing import Any, Iterable

from ._base import Resource


class Verification(Resource):
    def email(self, email: str, *, refresh: bool = False) -> Any:
        params: dict[str, Any] = {"email": email}
        if refresh:
            params["refresh"] = "1"
        return self._client.request("GET", "/v1/verify/email", params=params)

    def batch(self, emails: Iterable[str]) -> Any:
        return self._client.request("POST", "/v1/verify/batch", json={"emails": list(emails)})
