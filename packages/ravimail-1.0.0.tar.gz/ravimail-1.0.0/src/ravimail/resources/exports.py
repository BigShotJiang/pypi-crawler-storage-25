from __future__ import annotations

from typing import Any, Mapping

from ._base import Resource


class Exports(Resource):
    def list(self) -> Any:
        return self._client.request("GET", "/v1/exports")
    def create(self, *, type: str, filters: Mapping[str, Any] = {}) -> Any:
        return self._client.request("POST", "/v1/exports", json={"type": type, "filters": dict(filters)})
    def get(self, export_id: int) -> Any:
        return self._client.request("GET", f"/v1/exports/{export_id}")
