from __future__ import annotations

from typing import Any

from ._base import Resource


class SmtpRelay(Resource):
    def info(self) -> Any:
        return self._client.request("GET", "/v1/smtp/info")

    def log(self, **filters: Any) -> Any:
        return self._client.request("GET", "/v1/smtp/log", params=filters or None)
