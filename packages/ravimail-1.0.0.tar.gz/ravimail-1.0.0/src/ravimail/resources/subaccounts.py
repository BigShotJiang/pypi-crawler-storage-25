from __future__ import annotations

from typing import Any

from ._base import Resource


class Subaccounts(Resource):
    def list(self) -> Any:                                  return self._client.request("GET", "/v1/subaccounts")
    def create(self, **data: Any) -> Any:                   return self._client.request("POST", "/v1/subaccounts", json=data)
    def get(self, sub_id: int) -> Any:                      return self._client.request("GET", f"/v1/subaccounts/{sub_id}")
    def update(self, sub_id: int, **patch: Any) -> Any:
        return self._client.request("PUT", f"/v1/subaccounts/{sub_id}", json=patch)
    def suspend(self, sub_id: int, reason: str = "") -> Any:
        return self._client.request("POST", f"/v1/subaccounts/{sub_id}/suspend", json={"reason": reason})
    def unsuspend(self, sub_id: int) -> Any:                return self._client.request("POST", f"/v1/subaccounts/{sub_id}/unsuspend")
    def delete(self, sub_id: int) -> Any:                   return self._client.request("DELETE", f"/v1/subaccounts/{sub_id}")

    def create_token(self, sub_id: int, **data: Any) -> Any:
        return self._client.request("POST", f"/v1/subaccounts/{sub_id}/tokens", json=data)
    def list_tokens(self, sub_id: int) -> Any:              return self._client.request("GET",  f"/v1/subaccounts/{sub_id}/tokens")
