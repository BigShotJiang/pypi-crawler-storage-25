from __future__ import annotations

from typing import Any

from ._base import Resource


class Suppression(Resource):
    def list(self, **filters: Any) -> Any:
        return self._client.request("GET", "/v1/suppression", params=filters or None)

    def suppress(self, email: str, reason: str = "") -> Any:
        return self._client.request("POST", "/v1/suppression", json={"email": email, "reason": reason})

    def unsuppress(self, email: str) -> Any:
        from urllib.parse import quote
        return self._client.request("DELETE", f"/v1/suppression/{quote(email, safe='')}")
