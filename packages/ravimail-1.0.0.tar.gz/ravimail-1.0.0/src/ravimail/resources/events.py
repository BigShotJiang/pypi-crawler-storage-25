from __future__ import annotations

from typing import Any

from ._base import Resource


class Events(Resource):
    def list(self, **filters: Any) -> Any:
        return self._client.request("GET", "/v1/events", params=filters or None)

    def stream_url(self) -> str:
        """Return the full URL of the SSE stream.

        Use it with the ``sseclient-py`` package:

            import requests
            from sseclient import SSEClient

            res = requests.get(
                rm.events.stream_url(),
                headers={"Authorization": f"Bearer {token}", "Accept": "text/event-stream"},
                stream=True,
            )
            for evt in SSEClient(res).events():
                print(evt.data)
        """
        return self._client.base_url + "/v1/events/stream"
