from __future__ import annotations

from typing import Any

from ._base import Resource


class Segments(Resource):
    def list(self) -> Any:                       return self._client.request("GET", "/v1/segments")
    def create(self, **data: Any) -> Any:        return self._client.request("POST", "/v1/segments", json=data)
    def get(self, segment_id: int) -> Any:       return self._client.request("GET", f"/v1/segments/{segment_id}")
    def update(self, segment_id: int, **patch: Any) -> Any:
        return self._client.request("PUT", f"/v1/segments/{segment_id}", json=patch)
    def delete(self, segment_id: int) -> Any:    return self._client.request("DELETE", f"/v1/segments/{segment_id}")
    def compute(self, segment_id: int, *, preview: bool = False) -> Any:
        return self._client.request("GET", f"/v1/segments/{segment_id}/compute", params={"preview": "1"} if preview else None)
