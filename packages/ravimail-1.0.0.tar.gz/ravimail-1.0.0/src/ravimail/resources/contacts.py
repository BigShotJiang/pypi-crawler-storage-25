from __future__ import annotations

from typing import Any, Iterable, Mapping

from ._base import Resource


class Contacts(Resource):
    def list(self, **filters: Any) -> Any:
        return self._client.request("GET", "/v1/contacts", params=filters or None)

    def create(self, **contact: Any) -> Any:
        return self._client.request("POST", "/v1/contacts", json=contact)

    def get(self, contact_id: int) -> Any:
        return self._client.request("GET", f"/v1/contacts/{contact_id}")

    def update(self, contact_id: int, **patch: Any) -> Any:
        return self._client.request("PUT", f"/v1/contacts/{contact_id}", json=patch)

    def delete(self, contact_id: int) -> Any:
        return self._client.request("DELETE", f"/v1/contacts/{contact_id}")

    def add_tags(self, contact_id: int, tags: Iterable[str]) -> Any:
        return self._client.request("POST", f"/v1/contacts/{contact_id}/tags", json={"tags": list(tags)})

    def remove_tags(self, contact_id: int, tags: Iterable[str]) -> Any:
        return self._client.request("DELETE", f"/v1/contacts/{contact_id}/tags", json={"tags": list(tags)})

    def suppress(self, contact_id: int, reason: str = "") -> Any:
        return self._client.request("POST", f"/v1/contacts/{contact_id}/suppress", json={"reason": reason})

    def import_(self, list_id: int, contacts: Iterable[Mapping[str, Any]]) -> Any:
        """Bulk import — max 1000 per request, automatic dedup."""
        return self._client.request(
            "POST", "/v1/contacts/import",
            json={"list_id": list_id, "contacts": list(contacts)},
        )
