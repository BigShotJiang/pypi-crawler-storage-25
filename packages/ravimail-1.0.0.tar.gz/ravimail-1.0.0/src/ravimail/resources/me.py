from __future__ import annotations

from typing import Any

from ._base import Resource


class Me(Resource):
    def get(self) -> Any:
        return self._client.request("GET", "/v1/me")
