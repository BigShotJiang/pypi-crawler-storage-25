from __future__ import annotations

from typing import Any

from ._base import Resource


class InboundRoutes(Resource):
    def list(self) -> Any:                            return self._client.request("GET", "/v1/inbound/routes")
    def create(self, **data: Any) -> Any:             return self._client.request("POST", "/v1/inbound/routes", json=data)
    def get(self, route_id: int) -> Any:              return self._client.request("GET", f"/v1/inbound/routes/{route_id}")
    def update(self, route_id: int, **patch: Any) -> Any:
        return self._client.request("PUT", f"/v1/inbound/routes/{route_id}", json=patch)
    def delete(self, route_id: int) -> Any:           return self._client.request("DELETE", f"/v1/inbound/routes/{route_id}")
