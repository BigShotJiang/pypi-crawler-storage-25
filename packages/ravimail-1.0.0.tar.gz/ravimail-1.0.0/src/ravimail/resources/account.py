from __future__ import annotations

from typing import Any

from ._base import Resource


class Account(Resource):
    def balance(self) -> Any:                    return self._client.request("GET",  "/v1/account/balance")
    def usage(self, period: str = "current_month") -> Any:
        return self._client.request("GET", "/v1/account/usage", params={"period": period})
    def transactions(self, **filters: Any) -> Any:
        return self._client.request("GET", "/v1/account/transactions", params=filters or None)
    def packages(self) -> Any:                   return self._client.request("GET",  "/v1/account/packages")
    def top_up(self, package_id: int) -> Any:    return self._client.request("POST", "/v1/account/top-up", json={"package_id": package_id})
    def payments(self, **filters: Any) -> Any:
        return self._client.request("GET", "/v1/account/payments", params=filters or None)
    def subscription(self) -> Any:               return self._client.request("GET",  "/v1/account/subscription")
