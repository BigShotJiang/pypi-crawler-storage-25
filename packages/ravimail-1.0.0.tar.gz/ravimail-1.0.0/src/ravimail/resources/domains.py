from __future__ import annotations

from typing import Any, Literal

from ._base import Resource


class Domains(Resource):
    def list(self) -> Any:
        return self._client.request("GET", "/v1/domains")
    def create(self, *, domain: str, dns_provider: Literal["manual", "ravidns"] = "manual") -> Any:
        return self._client.request("POST", "/v1/domains", json={"domain": domain, "dns_provider": dns_provider})
    def get(self, domain_id: int) -> Any:
        return self._client.request("GET", f"/v1/domains/{domain_id}")
    def verify(self, domain_id: int) -> Any:
        return self._client.request("POST", f"/v1/domains/{domain_id}/verify")
    def dns_check(self, domain_id: int) -> Any:
        return self._client.request("GET", f"/v1/domains/{domain_id}/dns-check")
    def upgrade_to_panel(self, domain_id: int) -> Any:
        return self._client.request("POST", f"/v1/domains/{domain_id}/upgrade-to-panel")
    def delete(self, domain_id: int, *, force: bool = False) -> Any:
        return self._client.request("DELETE", f"/v1/domains/{domain_id}", params={"force": "1"} if force else None)
