from __future__ import annotations

from typing import Any, Literal, Mapping

from ._base import Resource


class Campaigns(Resource):
    def list(self, **filters: Any) -> Any:
        return self._client.request("GET", "/v1/campaigns", params=filters or None)
    def create(self, **data: Any) -> Any:
        return self._client.request("POST", "/v1/campaigns", json=data)
    def get(self, campaign_id: int) -> Any:
        return self._client.request("GET", f"/v1/campaigns/{campaign_id}")
    def delete(self, campaign_id: int, *, force: bool = False) -> Any:
        return self._client.request("DELETE", f"/v1/campaigns/{campaign_id}", params={"force": "1"} if force else None)

    def start(self, campaign_id: int) -> Any:     return self._client.request("POST", f"/v1/campaigns/{campaign_id}/start")
    def pause(self, campaign_id: int) -> Any:     return self._client.request("POST", f"/v1/campaigns/{campaign_id}/pause")
    def resume(self, campaign_id: int) -> Any:    return self._client.request("POST", f"/v1/campaigns/{campaign_id}/resume")
    def cancel(self, campaign_id: int) -> Any:    return self._client.request("POST", f"/v1/campaigns/{campaign_id}/cancel")
    def duplicate(self, campaign_id: int) -> Any: return self._client.request("POST", f"/v1/campaigns/{campaign_id}/duplicate")

    def ab_test_status(self, campaign_id: int) -> Any:
        return self._client.request("GET", f"/v1/campaigns/{campaign_id}/ab-test")
    def config_ab_test(self, campaign_id: int, **config: Any) -> Any:
        return self._client.request("POST", f"/v1/campaigns/{campaign_id}/ab-test", json=config)
    def force_ab_winner(self, campaign_id: int, winner: Literal["a", "b"]) -> Any:
        return self._client.request("POST", f"/v1/campaigns/{campaign_id}/ab-test/force-winner", json={"winner": winner})
