"""Base Resource class shared by all resources."""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import Client


class Resource:
    """Each public method maps 1:1 to a REST endpoint."""

    def __init__(self, client: "Client") -> None:
        self._client = client
