from __future__ import annotations

from typing import Any

from ._base import Resource


class CustomFields(Resource):
    def list(self) -> Any:                       return self._client.request("GET", "/v1/custom-fields")
    def create(self, **data: Any) -> Any:        return self._client.request("POST", "/v1/custom-fields", json=data)
    def delete(self, field_id: int) -> Any:      return self._client.request("DELETE", f"/v1/custom-fields/{field_id}")
