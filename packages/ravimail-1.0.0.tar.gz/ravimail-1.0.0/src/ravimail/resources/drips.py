from __future__ import annotations

from typing import Any

from ._base import Resource


class Drips(Resource):
    def list(self) -> Any:                       return self._client.request("GET", "/v1/drips")
    def create(self, **data: Any) -> Any:        return self._client.request("POST", "/v1/drips", json=data)
    def get(self, drip_id: int) -> Any:          return self._client.request("GET", f"/v1/drips/{drip_id}")
    def update(self, drip_id: int, **patch: Any) -> Any:
        return self._client.request("PUT", f"/v1/drips/{drip_id}", json=patch)
    def delete(self, drip_id: int) -> Any:       return self._client.request("DELETE", f"/v1/drips/{drip_id}")

    def list_steps(self, drip_id: int) -> Any:   return self._client.request("GET",  f"/v1/drips/{drip_id}/steps")
    def add_step(self, drip_id: int, **step: Any) -> Any:
        return self._client.request("POST", f"/v1/drips/{drip_id}/steps", json=step)
    def delete_step(self, drip_id: int, step_id: int) -> Any:
        return self._client.request("DELETE", f"/v1/drips/{drip_id}/steps/{step_id}")

    def subscribe(self, drip_id: int, contact_id: int) -> Any:
        """Idempotent — repeating with same contact_id returns the same subscription."""
        return self._client.request("POST", f"/v1/drips/{drip_id}/subscribe", json={"contact_id": contact_id})

    def unsubscribe(self, drip_id: int, contact_id: int) -> Any:
        return self._client.request("POST", f"/v1/drips/{drip_id}/unsubscribe", json={"contact_id": contact_id})
