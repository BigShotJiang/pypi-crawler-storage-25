from __future__ import annotations

from pathlib import Path
from typing import Any, BinaryIO, Optional, Union

import requests

from ._base import Resource


class Files(Resource):
    def list(self, **filters: Any) -> Any:
        return self._client.request("GET", "/v1/files", params=filters or None)

    def get(self, file_id: str) -> Any:
        from urllib.parse import quote
        return self._client.request("GET", f"/v1/files/{quote(file_id, safe='')}")

    def delete(self, file_id: str) -> Any:
        from urllib.parse import quote
        return self._client.request("DELETE", f"/v1/files/{quote(file_id, safe='')}")

    def upload(
        self,
        file: Union[str, Path, BinaryIO],
        *,
        filename: Optional[str] = None,
        content_type: Optional[str] = None,
    ) -> Any:
        """Upload a file (attachment). Pass a path, an open file handle, or any binary stream."""
        opened_here = False
        if isinstance(file, (str, Path)):
            p = Path(file)
            fh: BinaryIO = open(p, "rb")
            filename = filename or p.name
            opened_here = True
        else:
            fh = file
            filename = filename or "file"

        try:
            files = {"file": (filename, fh, content_type or "application/octet-stream")}
            url = self._client.base_url + "/v1/files"
            # Multipart upload uses requests directly (json= won't work).
            from .._internal import _multipart_headers  # type: ignore
            headers = _multipart_headers(self._client)
            resp = requests.post(url, headers=headers, files=files, timeout=60)
            resp.raise_for_status()
            return resp.json()
        finally:
            if opened_here:
                fh.close()
