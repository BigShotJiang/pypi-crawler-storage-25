from __future__ import annotations

from typing import Any

from ._base import Resource


class Reports(Resource):
    def list(self) -> Any:                       return self._client.request("GET", "/v1/reports")
    def create(self, **data: Any) -> Any:        return self._client.request("POST", "/v1/reports", json=data)
    def get(self, report_id: int) -> Any:        return self._client.request("GET", f"/v1/reports/{report_id}")
    def update(self, report_id: int, **patch: Any) -> Any:
        return self._client.request("PUT", f"/v1/reports/{report_id}", json=patch)
    def delete(self, report_id: int) -> Any:     return self._client.request("DELETE", f"/v1/reports/{report_id}")
