from __future__ import annotations

from typing import Any

from ._base import Resource


class Reputation(Resource):
    def summary(self) -> Any: return self._client.request("GET", "/v1/reputation/summary")
    def domains(self) -> Any: return self._client.request("GET", "/v1/reputation/domains")
    def ips(self) -> Any:     return self._client.request("GET", "/v1/reputation/ips")
    def nodes(self) -> Any:   return self._client.request("GET", "/v1/reputation/nodes")
