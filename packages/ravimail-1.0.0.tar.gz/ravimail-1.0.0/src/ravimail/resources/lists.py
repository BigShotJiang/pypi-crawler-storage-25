from __future__ import annotations

from typing import Any

from ._base import Resource


class Lists(Resource):
    def list(self, **filters: Any) -> Any:
        return self._client.request("GET", "/v1/lists", params=filters or None)

    def create(self, *, name: str, description: str = "") -> Any:
        return self._client.request("POST", "/v1/lists", json={"name": name, "description": description})

    def get(self, list_id: int) -> Any:
        return self._client.request("GET", f"/v1/lists/{list_id}")

    def update(self, list_id: int, **patch: Any) -> Any:
        return self._client.request("PUT", f"/v1/lists/{list_id}", json=patch)

    def delete(self, list_id: int) -> Any:
        return self._client.request("DELETE", f"/v1/lists/{list_id}")
