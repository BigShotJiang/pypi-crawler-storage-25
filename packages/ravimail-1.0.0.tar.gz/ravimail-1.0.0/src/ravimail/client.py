"""Main RaviMail API client."""
from __future__ import annotations

import re
from typing import Any, Mapping, Optional

import requests

from .errors import (
    ApiError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
)
from .resources.account import Account
from .resources.analytics import Analytics
from .resources.campaigns import Campaigns
from .resources.contacts import Contacts
from .resources.custom_fields import CustomFields
from .resources.domains import Domains
from .resources.drips import Drips
from .resources.events import Events
from .resources.exports import Exports
from .resources.files import Files
from .resources.inbound_routes import InboundRoutes
from .resources.lists import Lists
from .resources.me import Me
from .resources.reports import Reports
from .resources.reputation import Reputation
from .resources.segments import Segments
from .resources.smtp_relay import SmtpRelay
from .resources.subaccounts import Subaccounts
from .resources.suppression import Suppression
from .resources.templates import Templates
from .resources.transactional import Transactional
from .resources.verification import Verification
from .resources.webhooks import Webhooks

_TOKEN_RE = re.compile(r"^rvm_(live|test)_[a-f0-9]{32}$")
VERSION = "1.0.0"
DEFAULT_BASE_URL = "https://api.ravimail.com.br"


class Client:
    """RaviMail REST API v1 client.

    Example:
        >>> from ravimail import Client
        >>> rm = Client("rvm_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
        >>> rm.transactional.send(
        ...     to="someone@example.com",
        ...     from_="you@yourdomain.com",
        ...     subject="Hello",
        ...     html="<h1>Hi!</h1>",
        ... )
    """

    def __init__(
        self,
        token: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        session: Optional[requests.Session] = None,
    ) -> None:
        if not _TOKEN_RE.match(token):
            raise ValueError("Invalid token format. Expected rvm_(live|test)_{32hex}.")

        self._token = token
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._session = session or requests.Session()

        self.me = Me(self)
        self.transactional = Transactional(self)
        self.contacts = Contacts(self)
        self.lists = Lists(self)
        self.templates = Templates(self)
        self.campaigns = Campaigns(self)
        self.domains = Domains(self)
        self.files = Files(self)
        self.webhooks = Webhooks(self)
        self.suppression = Suppression(self)
        self.analytics = Analytics(self)
        self.events = Events(self)
        self.verification = Verification(self)
        self.segments = Segments(self)
        self.exports = Exports(self)
        self.inbound_routes = InboundRoutes(self)
        self.drips = Drips(self)
        self.subaccounts = Subaccounts(self)
        self.reputation = Reputation(self)
        self.custom_fields = CustomFields(self)
        self.reports = Reports(self)
        self.account = Account(self)
        self.smtp_relay = SmtpRelay(self)

    @property
    def base_url(self) -> str:
        return self._base_url

    def request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[Mapping[str, Any]] = None,
        params: Optional[Mapping[str, Any]] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
    ) -> Any:
        """Internal — used by Resource subclasses. Not part of the public contract."""
        url = self._base_url + path
        headers = {
            "Authorization": f"Bearer {self._token}",
            "Accept": "application/json",
            "User-Agent": f"ravimail-python/{VERSION}",
        }
        if extra_headers:
            headers.update(extra_headers)

        try:
            resp = self._session.request(
                method=method.upper(),
                url=url,
                params=params,
                json=json,
                headers=headers,
                timeout=self._timeout,
            )
        except requests.RequestException as exc:
            raise ApiError(f"Network error: {exc}", 0) from exc

        if resp.status_code == 204:
            return None

        try:
            decoded = resp.json() if resp.text else None
        except ValueError:
            decoded = None

        if 200 <= resp.status_code < 300:
            return decoded if decoded is not None else {}

        title = (decoded or {}).get("title", f"HTTP {resp.status_code}") if isinstance(decoded, dict) else f"HTTP {resp.status_code}"
        detail = (decoded or {}).get("detail") if isinstance(decoded, dict) else None

        if resp.status_code == 401:
            raise AuthenticationError(title, detail)
        if resp.status_code == 422:
            raise ValidationError(title, detail)
        if resp.status_code == 429:
            try:
                ra = int(resp.headers.get("Retry-After", "0")) or None
            except (ValueError, TypeError):
                ra = None
            raise RateLimitError(title, ra, detail)
        raise ApiError(title, resp.status_code, detail)
