"""
RaviMail Python SDK.

Quickstart:
    from ravimail import Client

    rm = Client("rvm_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
    resp = rm.transactional.send(
        to="someone@example.com",
        from_="you@yourdomain.com",
        subject="Hello",
        html="<h1>Hi!</h1>",
    )
"""
from .client import Client
from .errors import (
    ApiError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
)
from .webhooks_verify import verify_signature

__version__ = "1.0.0"
__all__ = [
    "Client",
    "ApiError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "verify_signature",
    "__version__",
]
