"""Standalone webhook signature verification — does NOT require a Client instance."""
from __future__ import annotations

import hashlib
import hmac
from typing import Union


def verify_signature(
    signature: str,
    raw_body: Union[str, bytes],
    secret: str,
) -> bool:
    """Verify an X-Ravimail-Signature header against the raw request body.

    Uses constant-time comparison via ``hmac.compare_digest`` to avoid timing leaks.

    Args:
        signature: Value of the ``X-Ravimail-Signature`` header (``sha256=<hex>``).
        raw_body:  Raw bytes/string of the request body (NOT parsed JSON).
        secret:    The endpoint's ``signing_secret`` (``whsec_...``).

    Returns:
        True if the signature is valid, False otherwise.

    Example:
        >>> from ravimail import verify_signature
        >>> verify_signature(request.headers["X-Ravimail-Signature"], request.get_data(), secret)
    """
    if not signature:
        return False
    body_bytes = raw_body.encode() if isinstance(raw_body, str) else raw_body
    expected = "sha256=" + hmac.new(secret.encode(), body_bytes, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)
