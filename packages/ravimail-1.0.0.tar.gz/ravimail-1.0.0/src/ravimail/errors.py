"""Exception hierarchy for the RaviMail Python SDK."""
from __future__ import annotations

from typing import Optional


class ApiError(Exception):
    """Base class for all RaviMail API failures.

    Attributes:
        status: HTTP status code (0 if network error).
        detail: Server-provided ``detail`` field, if any.
    """

    def __init__(self, message: str, status: int, detail: Optional[str] = None) -> None:
        full = f"{message} — {detail}" if detail else message
        super().__init__(full)
        self.status = status
        self.detail = detail


class AuthenticationError(ApiError):
    """401 — token invalid, revoked, or wrong environment."""

    def __init__(self, message: str, detail: Optional[str] = None) -> None:
        super().__init__(message, 401, detail)


class ValidationError(ApiError):
    """422 — payload validation failed. Check ``detail`` for field-level info."""

    def __init__(self, message: str, detail: Optional[str] = None) -> None:
        super().__init__(message, 422, detail)


class RateLimitError(ApiError):
    """429 — rate limited. Respect ``retry_after_seconds`` if present."""

    def __init__(
        self,
        message: str,
        retry_after_seconds: Optional[int] = None,
        detail: Optional[str] = None,
    ) -> None:
        super().__init__(message, 429, detail)
        self.retry_after_seconds = retry_after_seconds
