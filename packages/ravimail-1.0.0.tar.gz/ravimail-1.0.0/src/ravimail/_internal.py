"""Internal helpers — NOT part of the public API."""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .client import Client


def _multipart_headers(client: "Client") -> dict[str, str]:
    """Build auth headers for a multipart upload (don't set Content-Type — requests will)."""
    from .client import VERSION
    return {
        "Authorization": f"Bearer {client._token}",
        "Accept": "application/json",
        "User-Agent": f"ravimail-python/{VERSION}",
    }
