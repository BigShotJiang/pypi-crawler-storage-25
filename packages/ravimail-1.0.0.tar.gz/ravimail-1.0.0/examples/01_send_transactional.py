"""Example 01 — Send a single transactional email.

Run:
    RAVIMAIL_TOKEN=rvm_test_... python examples/01_send_transactional.py
"""
from __future__ import annotations

import os
import sys
from datetime import datetime

from ravimail import ApiError, Client

token = os.environ.get("RAVIMAIL_TOKEN")
if not token:
    sys.exit("Set RAVIMAIL_TOKEN env var")

rm = Client(token)

try:
    resp = rm.transactional.send(
        to="success@simulator.ravimail.com.br",
        from_="noreply@yourdomain.com",
        subject="Hello from the Python SDK",
        html="<h1>It works!</h1>",
        text="It works!",
        idempotency_key=f"example-01-{datetime.utcnow().strftime('%Y%m%d-%H%M')}",
    )
    print(f"✓ Sent. message_id: {resp['data']['message_id']}")
except ApiError as e:
    print(f"✗ API error ({e.status}): {e}", file=sys.stderr)
    sys.exit(1)
