# SPDX-FileCopyrightText: Copyright (c) 2025-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import json
import logging

import aiohttp
from pydantic import ValidationError
from tqdm import tqdm

from nat.data_models.api_server import ResponseIntermediateStep
from nat.data_models.evaluate_runtime import EvaluationRunConfig
from nat.data_models.evaluator import EvalInput
from nat.data_models.evaluator import EvalInputItem
from nat.data_models.intermediate_step import IntermediateStep
from nat.data_models.intermediate_step import IntermediateStepPayload
from nat.data_models.invocation_node import InvocationNode

logger = logging.getLogger(__name__)

# Constants for streaming response prefixes
DATA_PREFIX = "data: "
INTERMEDIATE_DATA_PREFIX = "intermediate_data: "


class EvaluationRemoteWorkflowHandler:

    def __init__(self, config: EvaluationRunConfig, max_concurrency: int):
        self.config = config
        # Run metadata
        self.semaphore = asyncio.Semaphore(max_concurrency)

    async def run_workflow_remote_single(self, session: aiohttp.ClientSession, item: EvalInputItem) -> None:
        """
        Sends a single input to the endpoint hosting the workflow and retrieves the response.
        """
        question: str = item.input_obj
        payload: dict = {"input_message": question}

        retry_attempts: int = (self.config.endpoint_retry.max_retries
                               if self.config.endpoint_retry.do_auto_retry else 1)

        for attempt in range(retry_attempts):
            try:
                endpoint: str = f"{self.config.endpoint}/generate/full"
                async with session.post(endpoint, json=payload) as response:
                    # Check if retriable HTTP error
                    if response.status in self.config.endpoint_retry.retry_status_codes:
                        logger.warning(f"Received retriable HTTP {response.status} from {endpoint}")
                        if await self._retry_request(attempt, retry_attempts):
                            continue

                    response.raise_for_status()

                    final_response: str | None = None
                    intermediate_steps: list[IntermediateStep] = []

                    async for line in response.content:
                        line = line.decode('utf-8').strip()
                        if not line:
                            continue

                        if line.startswith(DATA_PREFIX):
                            try:
                                chunk_data: dict = json.loads(line[len(DATA_PREFIX):])
                                if chunk_data.get("value"):
                                    final_response = chunk_data.get("value")
                            except json.JSONDecodeError:
                                logger.exception("Failed to parse generate response chunk")
                                continue
                        elif line.startswith(INTERMEDIATE_DATA_PREFIX):
                            try:
                                step_data: dict = json.loads(line[len(INTERMEDIATE_DATA_PREFIX):])
                                response_intermediate = ResponseIntermediateStep.model_validate(step_data)
                                payload_obj: IntermediateStepPayload = IntermediateStepPayload.model_validate_json(
                                    response_intermediate.payload)
                                intermediate_step: IntermediateStep = IntermediateStep(
                                    parent_id="remote",
                                    function_ancestry=InvocationNode(function_name=payload_obj.name
                                                                     or "remote_function",
                                                                     function_id=payload_obj.UUID
                                                                     or "remote_function_id"),
                                    payload=payload_obj)
                                intermediate_steps.append(intermediate_step)
                            except (json.JSONDecodeError, ValidationError):
                                logger.exception("Failed to parse intermediate step")
                                continue

                item.output_obj = final_response
                item.trajectory = intermediate_steps
                return

            except aiohttp.ClientError:
                logger.exception("Request failed for question %s", question)
                item.output_obj = None
                item.trajectory = []
                return

    async def run_workflow_remote_with_limits(self,
                                              session: aiohttp.ClientSession,
                                              item: EvalInputItem,
                                              progress_bar: tqdm) -> None:
        """
        Sends limited number of concurrent requests to a remote workflow and retrieves responses.
        """
        async with self.semaphore:
            await self.run_workflow_remote_single(session=session, item=item)
            progress_bar.update(1)

    async def run_workflow_remote(self, eval_input: EvalInput) -> EvalInput:
        """
        Sends inputs to a workflow hosted on a remote endpoint.
        """
        timeout: aiohttp.ClientTimeout = aiohttp.ClientTimeout(total=self.config.endpoint_timeout)
        try:
            progress_bar: tqdm = tqdm(total=len(eval_input.eval_input_items), desc="Running workflow", unit="item")
            async with aiohttp.ClientSession(timeout=timeout) as session:
                # get the questions from the eval_input
                tasks: list = [
                    self.run_workflow_remote_with_limits(session, item, progress_bar)
                    for item in eval_input.eval_input_items
                ]
                await asyncio.gather(*tasks)

        finally:
            progress_bar.close()

        return eval_input

    async def _retry_request(self, attempt: int, max_retries: int) -> bool:
        """
        Sleep with exponential backoff if retry attempts remain.

        Returns True if should retry, False if last attempt.
        """
        if attempt < max_retries - 1:
            backoff: float = min(2.0**attempt, 30.0)
            logger.info(f"Retrying after {backoff:.1f}s backoff (attempt {attempt + 1}/{max_retries})")
            await asyncio.sleep(backoff)
            return True
        logger.warning(f"Max retries reached ({max_retries}), failing request")
        return False
