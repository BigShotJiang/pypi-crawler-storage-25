from datetime import timedelta
from os import PathLike
from typing import Any, BinaryIO, Callable, Iterable, Mapping, Protocol, TypeAlias

ContentType: TypeAlias = bytes | str | BinaryIO
DeleteTarget: TypeAlias = str | list[str]


class AdapterProtocol(Protocol):
    def put(self, path: str, content: ContentType, **kwargs: Any) -> bool: ...

    def fput(self, path: str, file: str | PathLike[str], **kwargs: Any) -> bool: ...

    def get(self, path: str) -> bytes: ...

    def exists(self, path: str) -> bool: ...

    def delete(self, paths: DeleteTarget) -> bool: ...

    def url(self, path: str) -> str: ...

    def internal_url(self, path: str) -> str: ...

    def presigned_upload_url(
        self,
        path: str,
        *,
        expires: int | timedelta = 3600,
        upload_id: str | None = None,
        part_number: int | None = None,
    ) -> str: ...

    def presigned_upload_urls(
        self,
        paths: Mapping[str, str],
        *,
        expires: int | timedelta = 3600,
        upload_id: str | None = None,
    ) -> dict[str, str]: ...

    def initiate_multipart_upload(
        self,
        path: str,
        *,
        content_type: str | None = None,
        metadata: Mapping[str, str] | None = None,
    ) -> str: ...

    def complete_multipart_upload(
        self,
        path: str,
        *,
        upload_id: str,
        parts: Iterable[Mapping[str, Any] | tuple[int, str]],
    ) -> dict[str, Any]: ...

    def abort_multipart_upload(self, path: str, *, upload_id: str) -> bool: ...

    async def aput(self, path: str, content: ContentType, **kwargs: Any) -> bool: ...

    async def afput(self, path: str, file: str | PathLike[str], **kwargs: Any) -> bool: ...

    async def ainternal_url(self, path: str) -> str: ...

    async def apresigned_upload_url(
        self,
        path: str,
        *,
        expires: int | timedelta = 3600,
        upload_id: str | None = None,
        part_number: int | None = None,
    ) -> str: ...

    async def apresigned_upload_urls(
        self,
        paths: Mapping[str, str],
        *,
        expires: int | timedelta = 3600,
        upload_id: str | None = None,
    ) -> dict[str, str]: ...

    async def ainitiate_multipart_upload(
        self,
        path: str,
        *,
        content_type: str | None = None,
        metadata: Mapping[str, str] | None = None,
    ) -> str: ...

    async def acomplete_multipart_upload(
        self,
        path: str,
        *,
        upload_id: str,
        parts: Iterable[Mapping[str, Any] | tuple[int, str]],
    ) -> dict[str, Any]: ...

    async def aabort_multipart_upload(self, path: str, *, upload_id: str) -> bool: ...


DriverFactory: TypeAlias = Callable[[Any], AdapterProtocol]
