from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import timedelta
import functools
import os
from pathlib import Path
from typing import Any, BinaryIO, Iterable, Mapping
from urllib.parse import urljoin

import anyio

from fastapi_storage.types import ContentType, DeleteTarget


class PathPrefixer:
    def __init__(self, prefix: str = "", separator: str = "/") -> None:
        self.separator = separator
        normalized = prefix.strip("\\/")
        self.prefix = f"{normalized}{separator}" if normalized else ""

    def prefix_path(self, path: str) -> str:
        normalized = path.strip("/")
        return f"{self.prefix}{normalized}" if normalized else self.prefix.rstrip(self.separator)


class StorageAdapter(ABC):
    def __init__(self, config: object) -> None:
        self.config = config
        root = getattr(config, "root", "") or ""
        separator = getattr(config, "directory_separator", "/") or "/"
        self.prefixer = PathPrefixer(root, separator=separator)

    def normalize_path(self, path: str) -> str:
        return path.strip("/")

    def prefixed_key(self, path: str) -> str:
        return self.prefixer.prefix_path(self.normalize_path(path))

    def to_bytes(self, content: ContentType) -> bytes:
        if isinstance(content, bytes):
            return content
        if isinstance(content, str):
            return content.encode("utf-8")
        if hasattr(content, "read"):
            value = content.read()
            if isinstance(value, bytes):
                return value
            if isinstance(value, str):
                return value.encode("utf-8")
        raise TypeError("Unsupported content type for put operation.")

    def build_url(self, path: str) -> str:
        base_url = getattr(self.config, "url", None)
        if not base_url:
            return f"/storage/{self.normalize_path(path)}"
        return urljoin(base_url.rstrip("/") + "/", self.normalize_path(path))

    def internal_url(self, path: str) -> str:
        # Compatible fallback: build an app/config-based URL (not provider-native).
        return self.build_url(path)

    def presigned_upload_url(
        self,
        path: str,
        *,
        expires: int | timedelta = 3600,
        upload_id: str | None = None,
        part_number: int | None = None,
    ) -> str:
        raise NotImplementedError(f"{self.__class__.__name__} does not support presigned upload URLs.")

    def presigned_upload_urls(
        self,
        paths: Mapping[str, str],
        *,
        expires: int | timedelta = 3600,
        upload_id: str | None = None,
    ) -> dict[str, str]:
        return {
            key: self.presigned_upload_url(path, expires=expires, upload_id=upload_id)
            for key, path in paths.items()
        }

    def initiate_multipart_upload(
        self,
        path: str,
        *,
        content_type: str | None = None,
        metadata: Mapping[str, str] | None = None,
    ) -> str:
        raise NotImplementedError(f"{self.__class__.__name__} does not support multipart uploads.")

    def complete_multipart_upload(
        self,
        path: str,
        *,
        upload_id: str,
        parts: Iterable[Mapping[str, Any] | tuple[int, str]],
    ) -> dict[str, Any]:
        raise NotImplementedError(f"{self.__class__.__name__} does not support multipart uploads.")

    def abort_multipart_upload(self, path: str, *, upload_id: str) -> bool:
        raise NotImplementedError(f"{self.__class__.__name__} does not support multipart uploads.")

    def fput(self, path: str, file: str | os.PathLike[str], **kwargs: object) -> bool:
        data = Path(file).read_bytes()
        return self.put(path, data, **kwargs)

    @abstractmethod
    def put(self, path: str, content: ContentType, **kwargs: object) -> bool:
        raise NotImplementedError

    @abstractmethod
    def get(self, path: str) -> bytes:
        raise NotImplementedError

    @abstractmethod
    def exists(self, path: str) -> bool:
        raise NotImplementedError

    @abstractmethod
    def delete(self, paths: DeleteTarget) -> bool:
        raise NotImplementedError

    @abstractmethod
    def url(self, path: str) -> str:
        raise NotImplementedError

    @abstractmethod
    def size(self, path: str) -> int:
        raise NotImplementedError

    @abstractmethod
    def copy(self, src: str, dst: str) -> bool:
        raise NotImplementedError

    @abstractmethod
    def move(self, src: str, dst: str) -> bool:
        raise NotImplementedError

    async def aput(self, path: str, content: ContentType, **kwargs: object) -> bool:
        call = functools.partial(self.put, path, content, **kwargs)
        return await anyio.to_thread.run_sync(call)

    async def afput(self, path: str, file: str | os.PathLike[str], **kwargs: object) -> bool:
        call = functools.partial(self.fput, path, file, **kwargs)
        return await anyio.to_thread.run_sync(call)

    async def ainternal_url(self, path: str) -> str:
        return await anyio.to_thread.run_sync(self.internal_url, path)

    async def apresigned_upload_url(
        self,
        path: str,
        *,
        expires: int | timedelta = 3600,
        upload_id: str | None = None,
        part_number: int | None = None,
    ) -> str:
        call = functools.partial(
            self.presigned_upload_url,
            path,
            expires=expires,
            upload_id=upload_id,
            part_number=part_number,
        )
        return await anyio.to_thread.run_sync(call)

    async def apresigned_upload_urls(
        self,
        paths: Mapping[str, str],
        *,
        expires: int | timedelta = 3600,
        upload_id: str | None = None,
    ) -> dict[str, str]:
        call = functools.partial(self.presigned_upload_urls, paths, expires=expires, upload_id=upload_id)
        return await anyio.to_thread.run_sync(call)

    async def ainitiate_multipart_upload(
        self,
        path: str,
        *,
        content_type: str | None = None,
        metadata: Mapping[str, str] | None = None,
    ) -> str:
        call = functools.partial(
            self.initiate_multipart_upload,
            path,
            content_type=content_type,
            metadata=metadata,
        )
        return await anyio.to_thread.run_sync(call)

    async def acomplete_multipart_upload(
        self,
        path: str,
        *,
        upload_id: str,
        parts: Iterable[Mapping[str, Any] | tuple[int, str]],
    ) -> dict[str, Any]:
        call = functools.partial(self.complete_multipart_upload, path, upload_id=upload_id, parts=parts)
        return await anyio.to_thread.run_sync(call)

    async def aabort_multipart_upload(self, path: str, *, upload_id: str) -> bool:
        call = functools.partial(self.abort_multipart_upload, path, upload_id=upload_id)
        return await anyio.to_thread.run_sync(call)

    async def aget(self, path: str) -> bytes:
        return await anyio.to_thread.run_sync(self.get, path)

    async def aexists(self, path: str) -> bool:
        return await anyio.to_thread.run_sync(self.exists, path)

    async def adelete(self, paths: DeleteTarget) -> bool:
        return await anyio.to_thread.run_sync(self.delete, paths)

    async def asize(self, path: str) -> int:
        return await anyio.to_thread.run_sync(self.size, path)

    async def acopy(self, src: str, dst: str) -> bool:
        return await anyio.to_thread.run_sync(self.copy, src, dst)

    async def amove(self, src: str, dst: str) -> bool:
        return await anyio.to_thread.run_sync(self.move, src, dst)

    def resolve_local_path(self, path: str) -> Path:
        root = Path(getattr(self.config, "root", "") or "")
        return root / self.normalize_path(path)
