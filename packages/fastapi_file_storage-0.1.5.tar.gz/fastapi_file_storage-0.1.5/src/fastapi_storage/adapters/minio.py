from __future__ import annotations

import functools
from datetime import timedelta
from io import BytesIO
from typing import Any, Iterable, Mapping
from urllib.parse import urljoin, urlparse

import anyio

from fastapi_storage.adapters.base import StorageAdapter
from fastapi_storage.exceptions import DependencyMissingError, ObjectNotFoundError
from fastapi_storage.types import ContentType, DeleteTarget


class MinioAdapter(StorageAdapter):
    def __init__(self, config: object, client: object | None = None) -> None:
        super().__init__(config)
        self.bucket = getattr(config, "bucket")
        self.client = client or self._build_client(config)
        self._presign_client: object | None = None

    @staticmethod
    def _build_client(config: object) -> object:
        try:
            from minio import Minio
        except ImportError as exc:
            raise DependencyMissingError("Install minio extra: pip install fastapi-file-storage[minio]") from exc

        return Minio(
            endpoint=getattr(config, "endpoint"),
            access_key=getattr(config, "access_key"),
            secret_key=getattr(config, "secret_key"),
            region=getattr(config, "region", None),
            secure=getattr(config, "secure", False),
        )

    @staticmethod
    def _build_domain_endpoint(domain: str) -> tuple[str, bool]:
        parsed = urlparse(domain if "://" in domain else f"https://{domain}")
        endpoint = parsed.netloc or parsed.path
        return endpoint.rstrip("/"), parsed.scheme == "https"

    def _public_base_url(self) -> str | None:
        domain = getattr(self.config, "domain", None)
        if not domain:
            return None

        base = domain.rstrip("/")
        if "://" not in base:
            base = f"https://{base}"
        return base

    def _get_presign_client(self) -> object:
        domain = getattr(self.config, "domain", None)
        if not domain:
            return self.client

        if self._presign_client is not None:
            return self._presign_client

        try:
            from minio import Minio
        except ImportError as exc:
            raise DependencyMissingError("Install minio extra: pip install fastapi-file-storage[minio]") from exc

        endpoint, secure = self._build_domain_endpoint(domain)
        self._presign_client = Minio(
            endpoint=endpoint,
            access_key=getattr(self.config, "access_key"),
            secret_key=getattr(self.config, "secret_key"),
            region=getattr(self.config, "region", None),
            secure=secure,
        )
        return self._presign_client

    @staticmethod
    def _normalize_expiry(expires: int | timedelta) -> timedelta:
        if isinstance(expires, timedelta):
            return expires
        return timedelta(seconds=expires)

    @staticmethod
    def _part_number(part: Mapping[str, Any] | tuple[int, str]) -> int:
        if isinstance(part, tuple):
            return int(part[0])
        if "partNumber" in part:
            return int(part["partNumber"])
        return int(part["part_number"])

    @staticmethod
    def _part_etag(part: Mapping[str, Any] | tuple[int, str]) -> str:
        if isinstance(part, tuple):
            return part[1]
        return str(part["etag"])

    def put(self, path: str, content: ContentType, **kwargs: object) -> bool:
        key = self.prefixed_key(path)
        data = self.to_bytes(content)
        stream = BytesIO(data)
        content_type = kwargs.get("content_type") or "application/octet-stream"
        self.client.put_object(self.bucket, key, stream, len(data), content_type=content_type)
        return True

    def get(self, path: str) -> bytes:
        key = self.prefixed_key(path)
        try:
            response = self.client.get_object(self.bucket, key)
        except Exception as exc:
            raise ObjectNotFoundError(f"Object '{path}' not found.") from exc

        try:
            return response.read()
        finally:
            if hasattr(response, "close"):
                response.close()
            if hasattr(response, "release_conn"):
                response.release_conn()

    def exists(self, path: str) -> bool:
        key = self.prefixed_key(path)
        try:
            self.client.stat_object(self.bucket, key)
            return True
        except Exception:
            return False

    def delete(self, paths: DeleteTarget) -> bool:
        targets = [paths] if isinstance(paths, str) else paths
        for target in targets:
            self.client.remove_object(self.bucket, self.prefixed_key(target))
        return True

    def url(self, path: str) -> str:
        normalized = self.normalize_path(path)
        if not normalized:
            return ""

        public_base = self._public_base_url()
        if public_base:
            return urljoin(f"{public_base}/", f"{self.bucket}/{normalized}")

        endpoint = getattr(self.config, "endpoint")
        return f"http://{endpoint.rstrip('/')}/{self.bucket}/{normalized}"

    def internal_url(self, path: str) -> str:
        normalized = self.normalize_path(path)
        if not normalized:
            return ""

        endpoint = getattr(self.config, "endpoint")
        return f"http://{endpoint.rstrip('/')}/{self.bucket}/{normalized}"

    def size(self, path: str) -> int:
        stat = self.client.stat_object(self.bucket, self.prefixed_key(path))
        return int(getattr(stat, "size"))

    def copy(self, src: str, dst: str) -> bool:
        try:
            from minio.commonconfig import CopySource
        except ImportError as exc:
            raise DependencyMissingError("Install minio extra: pip install fastapi-file-storage[minio]") from exc

        source = CopySource(self.bucket, self.prefixed_key(src))
        self.client.copy_object(self.bucket, self.prefixed_key(dst), source)
        return True

    def move(self, src: str, dst: str) -> bool:
        self.copy(src, dst)
        self.delete(src)
        return True

    def presigned_upload_url(
        self,
        path: str,
        *,
        expires: int | timedelta = 3600,
        upload_id: str | None = None,
        part_number: int | None = None,
    ) -> str:
        """
        Build a presigned PUT URL for direct client uploads.

        If ``domain`` is configured, the URL is signed against that public
        domain instead of the internal MinIO endpoint.
        """
        key = self.prefixed_key(path)
        expiry = self._normalize_expiry(expires)
        client = self._get_presign_client()

        if upload_id is not None and part_number is not None:
            return client.get_presigned_url(
                "PUT",
                self.bucket,
                key,
                expires=expiry,
                extra_query_params={
                    "uploadId": upload_id,
                    "partNumber": str(part_number),
                },
            )

        return client.presigned_put_object(self.bucket, key, expires=expiry)

    def presigned_upload_urls(
        self,
        paths: Mapping[str, str],
        *,
        expires: int | timedelta = 3600,
        upload_id: str | None = None,
    ) -> dict[str, str]:
        """
        Build multiple presigned PUT URLs.

        When ``upload_id`` is provided, each mapping key is treated as the
        multipart ``partNumber`` and each mapping value is the object path.
        """
        urls: dict[str, str] = {}
        for part_id, path in paths.items():
            part_number = int(part_id) if upload_id is not None else None
            urls[part_id] = self.presigned_upload_url(
                path,
                expires=expires,
                upload_id=upload_id,
                part_number=part_number,
            )
        return urls

    async def apresigned_upload_url(
        self,
        path: str,
        *,
        expires: int | timedelta = 3600,
        upload_id: str | None = None,
        part_number: int | None = None,
    ) -> str:
        call = functools.partial(
            self.presigned_upload_url,
            path,
            expires=expires,
            upload_id=upload_id,
            part_number=part_number,
        )
        return await anyio.to_thread.run_sync(call)

    async def apresigned_upload_urls(
        self,
        paths: Mapping[str, str],
        *,
        expires: int | timedelta = 3600,
        upload_id: str | None = None,
    ) -> dict[str, str]:
        call = functools.partial(self.presigned_upload_urls, paths, expires=expires, upload_id=upload_id)
        return await anyio.to_thread.run_sync(call)

    def initiate_multipart_upload(
        self,
        path: str,
        *,
        content_type: str | None = None,
        metadata: Mapping[str, str] | None = None,
    ) -> str:
        """
        Start a MinIO multipart upload and return the upload ID.

        The returned upload ID can be used with ``presigned_upload_url`` or
        ``presigned_upload_urls`` to sign individual part uploads.
        """
        headers = dict(metadata or {})
        if content_type:
            headers["Content-Type"] = content_type
        return self.client._create_multipart_upload(self.bucket, self.prefixed_key(path), headers=headers)

    def complete_multipart_upload(
        self,
        path: str,
        *,
        upload_id: str,
        parts: Iterable[Mapping[str, Any] | tuple[int, str]],
    ) -> dict[str, Any]:
        """
        Complete a MinIO multipart upload from uploaded part numbers and ETags.

        ``parts`` accepts either ``{"partNumber": 1, "etag": "..."}``,
        ``{"part_number": 1, "etag": "..."}``, or ``(1, "...")`` entries.
        """
        try:
            from minio.datatypes import Part
        except ImportError as exc:
            raise DependencyMissingError("Install minio extra: pip install fastapi-file-storage[minio]") from exc

        completed_parts = [
            Part(self._part_number(part), self._part_etag(part))
            for part in sorted(parts, key=self._part_number)
        ]
        result = self.client._complete_multipart_upload(
            self.bucket,
            self.prefixed_key(path),
            upload_id,
            completed_parts,
        )
        return {
            "bucket": getattr(result, "bucket_name", self.bucket),
            "key": getattr(result, "object_name", self.prefixed_key(path)),
            "etag": getattr(result, "etag", None),
            "version_id": getattr(result, "version_id", None),
            "location": getattr(result, "location", None),
            "file_url": self.url(path),
        }

    def abort_multipart_upload(self, path: str, *, upload_id: str) -> bool:
        """Abort a MinIO multipart upload and discard uploaded parts."""
        self.client._abort_multipart_upload(self.bucket, self.prefixed_key(path), upload_id)
        return True

    async def ainitiate_multipart_upload(
        self,
        path: str,
        *,
        content_type: str | None = None,
        metadata: Mapping[str, str] | None = None,
    ) -> str:
        call = functools.partial(
            self.initiate_multipart_upload,
            path,
            content_type=content_type,
            metadata=metadata,
        )
        return await anyio.to_thread.run_sync(call)

    async def acomplete_multipart_upload(
        self,
        path: str,
        *,
        upload_id: str,
        parts: Iterable[Mapping[str, Any] | tuple[int, str]],
    ) -> dict[str, Any]:
        call = functools.partial(self.complete_multipart_upload, path, upload_id=upload_id, parts=parts)
        return await anyio.to_thread.run_sync(call)

    async def aabort_multipart_upload(self, path: str, *, upload_id: str) -> bool:
        call = functools.partial(self.abort_multipart_upload, path, upload_id=upload_id)
        return await anyio.to_thread.run_sync(call)
