from datetime import timedelta
import sys
import types

import anyio

from fastapi_storage.adapters.minio import MinioAdapter
from fastapi_storage.config.models import MinioDiskConfig


class DummyMinioClient:
    def __init__(self) -> None:
        self.calls = []

    def presigned_put_object(self, bucket, key, expires):
        self.calls.append(("presigned_put_object", bucket, key, expires))
        return f"http://127.0.0.1:9000/{bucket}/{key}?signature=endpoint"

    def get_presigned_url(self, method, bucket, key, expires, extra_query_params):
        self.calls.append(("get_presigned_url", method, bucket, key, expires, extra_query_params))
        part_number = extra_query_params["partNumber"]
        upload_id = extra_query_params["uploadId"]
        return f"http://127.0.0.1:9000/{bucket}/{key}?partNumber={part_number}&uploadId={upload_id}"

    def _create_multipart_upload(self, bucket, key, headers):
        self.calls.append(("_create_multipart_upload", bucket, key, headers))
        return "upload-1"

    def _complete_multipart_upload(self, bucket, key, upload_id, parts):
        self.calls.append(("_complete_multipart_upload", bucket, key, upload_id, parts))
        return types.SimpleNamespace(
            bucket_name=bucket,
            object_name=key,
            etag="complete-etag",
            version_id="v1",
            location=f"/{bucket}/{key}",
        )

    def _abort_multipart_upload(self, bucket, key, upload_id):
        self.calls.append(("_abort_multipart_upload", bucket, key, upload_id))


def test_minio_url_uses_domain_when_present() -> None:
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
        domain="minio.example.com",
    )
    adapter = MinioAdapter(config, client=DummyMinioClient())
    assert adapter.url("audio/a.mp3") == "https://minio.example.com/uploads/audio/a.mp3"


def test_minio_url_uses_endpoint_when_domain_missing() -> None:
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
    )
    adapter = MinioAdapter(config, client=DummyMinioClient())
    assert adapter.url("audio/a.mp3") == "http://127.0.0.1:9000/uploads/audio/a.mp3"


def test_minio_internal_url_always_uses_endpoint() -> None:
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
        domain="minio.example.com",
    )
    adapter = MinioAdapter(config, client=DummyMinioClient())
    assert adapter.internal_url("audio/a.mp3") == "http://127.0.0.1:9000/uploads/audio/a.mp3"


def test_minio_url_empty_path_returns_empty_string() -> None:
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
        domain="minio.example.com",
    )
    adapter = MinioAdapter(config, client=DummyMinioClient())
    assert adapter.url("") == ""
    assert adapter.internal_url("") == ""


def test_minio_url_preserves_domain_scheme_when_present() -> None:
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
        domain="http://minio.example.com",
    )
    adapter = MinioAdapter(config, client=DummyMinioClient())
    assert adapter.url("audio/a.mp3") == "http://minio.example.com/uploads/audio/a.mp3"


def test_minio_presigned_upload_url_uses_endpoint_without_domain() -> None:
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
        root="tenant-a",
    )
    client = DummyMinioClient()
    adapter = MinioAdapter(config, client=client)

    url = adapter.presigned_upload_url("audio/a.mp3", expires=timedelta(minutes=5))

    assert url == "http://127.0.0.1:9000/uploads/tenant-a/audio/a.mp3?signature=endpoint"
    assert client.calls == [
        ("presigned_put_object", "uploads", "tenant-a/audio/a.mp3", timedelta(minutes=5)),
    ]


def test_minio_presigned_upload_url_signs_against_domain(monkeypatch) -> None:
    created = {}

    class FakeMinio:
        def __init__(self, endpoint, access_key, secret_key, region, secure):
            created["client"] = self
            created["args"] = {
                "endpoint": endpoint,
                "access_key": access_key,
                "secret_key": secret_key,
                "region": region,
                "secure": secure,
            }

        def presigned_put_object(self, bucket, key, expires):
            return f"https://minio.example.com/{bucket}/{key}?signature=domain"

    monkeypatch.setitem(sys.modules, "minio", types.SimpleNamespace(Minio=FakeMinio))
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
        domain="minio.example.com",
    )
    adapter = MinioAdapter(config, client=DummyMinioClient())

    assert adapter.presigned_upload_url("audio/a.mp3") == (
        "https://minio.example.com/uploads/audio/a.mp3?signature=domain"
    )
    assert created["args"] == {
        "endpoint": "minio.example.com",
        "access_key": "ak",
        "secret_key": "sk",
        "region": None,
        "secure": True,
    }


def test_minio_presigned_upload_urls_support_multipart_parts() -> None:
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
    )
    adapter = MinioAdapter(config, client=DummyMinioClient())

    urls = adapter.presigned_upload_urls({"1": "audio/a.mp3", "2": "audio/a.mp3"}, upload_id="upload-1")

    assert urls == {
        "1": "http://127.0.0.1:9000/uploads/audio/a.mp3?partNumber=1&uploadId=upload-1",
        "2": "http://127.0.0.1:9000/uploads/audio/a.mp3?partNumber=2&uploadId=upload-1",
    }


def test_minio_async_presigned_upload_url() -> None:
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
    )
    adapter = MinioAdapter(config, client=DummyMinioClient())

    async def run() -> str:
        return await adapter.apresigned_upload_url("audio/a.mp3")

    assert anyio.run(run) == "http://127.0.0.1:9000/uploads/audio/a.mp3?signature=endpoint"


def test_minio_initiate_multipart_upload_returns_upload_id() -> None:
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
        root="tenant-a",
    )
    client = DummyMinioClient()
    adapter = MinioAdapter(config, client=client)

    upload_id = adapter.initiate_multipart_upload(
        "video/source.mp4",
        content_type="video/mp4",
        metadata={"x-amz-meta-record-id": "123"},
    )

    assert upload_id == "upload-1"
    assert client.calls[-1] == (
        "_create_multipart_upload",
        "uploads",
        "tenant-a/video/source.mp4",
        {"x-amz-meta-record-id": "123", "Content-Type": "video/mp4"},
    )


def test_minio_complete_multipart_upload_sorts_parts_and_returns_file_url(monkeypatch) -> None:
    class FakePart:
        def __init__(self, part_number, etag):
            self.part_number = part_number
            self.etag = etag

    monkeypatch.setitem(sys.modules, "minio.datatypes", types.SimpleNamespace(Part=FakePart))
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
        domain="cdn.example.com",
    )
    client = DummyMinioClient()
    adapter = MinioAdapter(config, client=client)

    result = adapter.complete_multipart_upload(
        "video/source.mp4",
        upload_id="upload-1",
        parts=[
            {"partNumber": 2, "etag": "etag-2"},
            {"part_number": 1, "etag": "etag-1"},
            (3, "etag-3"),
        ],
    )

    call = client.calls[-1]
    assert call[:4] == ("_complete_multipart_upload", "uploads", "video/source.mp4", "upload-1")
    assert [(part.part_number, part.etag) for part in call[4]] == [
        (1, "etag-1"),
        (2, "etag-2"),
        (3, "etag-3"),
    ]
    assert result == {
        "bucket": "uploads",
        "key": "video/source.mp4",
        "etag": "complete-etag",
        "version_id": "v1",
        "location": "/uploads/video/source.mp4",
        "file_url": "https://cdn.example.com/uploads/video/source.mp4",
    }


def test_minio_abort_multipart_upload() -> None:
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
    )
    client = DummyMinioClient()
    adapter = MinioAdapter(config, client=client)

    assert adapter.abort_multipart_upload("video/source.mp4", upload_id="upload-1") is True
    assert client.calls[-1] == ("_abort_multipart_upload", "uploads", "video/source.mp4", "upload-1")


def test_minio_async_multipart_lifecycle(monkeypatch) -> None:
    class FakePart:
        def __init__(self, part_number, etag):
            self.part_number = part_number
            self.etag = etag

    monkeypatch.setitem(sys.modules, "minio.datatypes", types.SimpleNamespace(Part=FakePart))
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
    )
    adapter = MinioAdapter(config, client=DummyMinioClient())

    async def run() -> tuple[str, dict, bool]:
        upload_id = await adapter.ainitiate_multipart_upload("video/source.mp4")
        result = await adapter.acomplete_multipart_upload(
            "video/source.mp4",
            upload_id=upload_id,
            parts=[{"partNumber": 1, "etag": "etag-1"}],
        )
        aborted = await adapter.aabort_multipart_upload("video/source.mp4", upload_id=upload_id)
        return upload_id, result, aborted

    upload_id, result, aborted = anyio.run(run)

    assert upload_id == "upload-1"
    assert result["etag"] == "complete-etag"
    assert aborted is True
