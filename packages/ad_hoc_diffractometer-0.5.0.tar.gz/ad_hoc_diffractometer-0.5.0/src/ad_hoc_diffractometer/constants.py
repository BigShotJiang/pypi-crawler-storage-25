# Copyright (c) 2026 Pete R. Jemian <prjemian+ad_hoc_diffractometer@gmail.com>
# SPDX-License-Identifier: CC-BY-4.0
"""
constants.py — shared Cartesian basis vectors.

These are the internal numpy representations used throughout the package.
The caller-facing notation (+x, -z, etc.) is handled in axes.py.

Default coordinate convention (You 1999):

- XHAT (+x) — vertical (opposite to gravitational acceleration)
- YHAT (+y) — longitudinal (a chosen direction in the plane perpendicular to vertical, conventionally along the nominal beam)
- ZHAT (+z) — lateral (completes the right-handed system: vertical × longitudinal)
"""

import logging

import numpy as np

logger = logging.getLogger(__name__)

XHAT = np.array([1.0, 0.0, 0.0])
"""Unit vector along the +x axis.

In the You (1999) convention this is the **vertical** direction
(opposite to gravitational acceleration).
In the Busing & Levy (1967) convention this is the **lateral** direction.
"""

YHAT = np.array([0.0, 1.0, 0.0])
"""Unit vector along the +y axis.

**Longitudinal** direction — a chosen direction in the plane perpendicular
to vertical, conventionally aligned with the nominal incident beam.
Consistent across both the You (1999) and Busing & Levy (1967) conventions.
"""

ZHAT = np.array([0.0, 0.0, 1.0])
"""Unit vector along the +z axis.

In the You (1999) convention this is the **lateral** direction
(completes the right-handed system: vertical × longitudinal).
In the Busing & Levy (1967) convention this is the **vertical** direction.
"""
