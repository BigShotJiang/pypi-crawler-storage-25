"""HTTP command buffer for the docx-studio SDK.

The buffer sits between SDK call sites and the HTTP transport. Every SDK
mutation routes through it; we flush eagerly for queries, and idle-batch
all other ops — including Create* — so a burst of ``add_paragraph`` calls
ships as one HTTP request instead of N.

Create* commands are deferred because the SDK pre-mints a client-side
UUID for every new node (see ``Document._mint_client_node_id``). The
proxy returned to the caller is stamped with that UUID; the applier
resolves UUIDs to real SuperDoc ids via ``clientIdMap`` and echoes the
mapping back, at which point the buffer rewrites each proxy's
``_node_id``. This makes batching invisible at the call site — user
code looks like python-docx, runs at python-docx-batched speed.

Concurrency model: the SDK serializes calls through ``_batching.run_sync``
(one persistent event-loop thread), so the buffer's primary thread is the
loop thread. The auto-flush timer fires on a *different* thread, so we
guard the pending list with an RLock and treat the timer flush as a
best-effort coalesce — if the loop thread races us we just flush twice
(or zero times; the next loop-thread call drains it).

`flush_all` is a process-wide hook used by the Daytona sandbox prelude to
make sure pending writes hit Keryx before the sandbox is suspended. It walks
a weak-ref registry so dead Workbook instances don't keep their buffers
alive.
"""

from __future__ import annotations

import sys
import threading
import weakref
from typing import TYPE_CHECKING, Any

from docx import _ptc
from docx.commands import Command, is_response_bearing, must_flush_immediately

if TYPE_CHECKING:
    from docx._http_doc import HttpClient


def _ptc_emit_end_batch(cmds: list[Command], *, is_error: bool) -> None:
    """Emit a PTC ``end`` event for every cmd that received a ``begin``.

    Tolerant: missing call_ids (cmd was added before PTC env was set) and
    PTC client exceptions both silently no-op.
    """
    for c in cmds:
        call_id = getattr(c, "_ptc_call_id", None)
        if not call_id:
            continue
        try:
            _ptc.emit_end(
                call_id=call_id,
                tool_name=type(c).__name__,
                result={"ok": not is_error}
                if not is_error
                else {"ok": False, "error": "command batch failed"},
                is_error=is_error,
            )
        except Exception:  # noqa: BLE001
            pass


# ---------------------------------------------------------------------------
# Process-wide registry for flush_all()
# ---------------------------------------------------------------------------

_active_buffers: list[weakref.ref["CommandBuffer"]] = []
_registry_lock = threading.Lock()


def _register(buffer: "CommandBuffer") -> None:
    with _registry_lock:
        _active_buffers.append(weakref.ref(buffer))


def _unregister(buffer: "CommandBuffer") -> None:
    """Drop ``buffer`` from the active-registry list.

    Called from :meth:`CommandBuffer.close` so a long-lived process that
    opens and closes many Documents doesn't accumulate dead weak-refs in
    the registry between ``flush_all`` calls.
    """
    with _registry_lock:
        _active_buffers[:] = [
            ref
            for ref in _active_buffers
            if (b := ref()) is not None and b is not buffer
        ]


def flush_all() -> None:
    """Flush every live CommandBuffer in this process.

    Used by the Daytona sandbox prelude after user code returns, so
    buffered mutations make it to Keryx before the sandbox is suspended.
    Safe to call when no Buffers exist (no-op). Failures are logged and
    swallowed — we don't want one stuck buffer to mask the rest.
    """
    with _registry_lock:
        snapshot = list(_active_buffers)
        # Compact dead refs while we hold the lock.
        live = [ref for ref in snapshot if ref() is not None]
        _active_buffers[:] = live

    for ref in live:
        buf = ref()
        if buf is None:
            continue
        try:
            buf.flush()
        except Exception as e:  # noqa: BLE001
            sys.stderr.write(
                f"[docx-sdk] flush_all: buffer {buf.asset_id} flush failed: {e}\n",
            )


# ---------------------------------------------------------------------------
# CommandBuffer
# ---------------------------------------------------------------------------

# Idle window before a pure-mutation buffer auto-flushes. Short by design —
# the SDK's main consumer is agent code that fires sequential property
# setters within milliseconds of each other; we just need to coalesce those
# without holding writes back from Keryx for human-perceptible time.
DEFAULT_AUTO_FLUSH_SECONDS: float = 0.1


class CommandBuffer:
    """Buffers commands for one Document/asset.

    Behaviour:
    - Queries (BlocksList, Find, GetNodeById, …) flush immediately and
      drain any pending mutations in the same batch so ordering is preserved.
    - Every other op — formatters, setters, AND Create* — queues. The idle
      timer flushes after :data:`DEFAULT_AUTO_FLUSH_SECONDS` of inactivity,
      the next eager (query) call drains, or explicit ``flush()`` drains.

    Create* commands defer because the SDK pre-mints a client-side UUID
    (``client_node_id`` / ``client_entity_id``); the applier translates
    the UUID to a real SuperDoc id in a per-batch ``clientIdMap`` and
    echoes the mapping back so the SDK can rewrite each proxy's
    ``_node_id`` on flush.
    """

    def __init__(
        self,
        client: "HttpClient",
        asset_id: str,
        *,
        auto_flush_seconds: float = DEFAULT_AUTO_FLUSH_SECONDS,
    ) -> None:
        self._client: "HttpClient" = client
        self._asset_id: str = asset_id
        self._pending: list[Command] = []
        self._lock: threading.RLock = threading.RLock()
        self._timer: threading.Timer | None = None
        self._auto_flush_seconds: float = auto_flush_seconds
        self._closed: bool = False
        # Track-changes envelope state — propagated as request-level
        # ``changeMode`` and ``user`` on every batch. ``Document``
        # mutates these via :meth:`set_change_mode` / :meth:`set_user`,
        # which flush before changing so prior buffered ops keep their
        # original semantics.
        self._change_mode: str | None = None
        self._user: dict[str, str] | None = None
        # client_node_id → list of (proxy, attr) pairs to update with the
        # real nodeId after flush. Populated by ``add_paragraph`` /
        # ``add_heading`` / etc. when they queue a Create with a
        # client-assigned id. Drained on every flush.
        self._proxy_id_refs: dict[
            str, list[tuple[object, str]]
        ] = {}
        _register(self)

    def register_proxy_id_ref(
        self, client_id: str, proxy: object, attr: str = "_node_id"
    ) -> None:
        """Register that ``proxy.<attr>`` should be rewritten from
        ``client_id`` to the real node id once the queue flushes.

        Called by ``Document.add_paragraph`` (and equivalents) when they
        queue a Create with a ``client_node_id``. The flush loop walks
        the per-cmd result for ``real_node_id`` / ``real_entity_id``
        echoes and applies setattr to every registered ref.
        """
        with self._lock:
            self._proxy_id_refs.setdefault(client_id, []).append((proxy, attr))

    @property
    def asset_id(self) -> str:
        return self._asset_id

    @property
    def pending_count(self) -> int:
        with self._lock:
            return len(self._pending)

    @property
    def change_mode(self) -> str | None:
        return self._change_mode

    @property
    def user(self) -> "dict[str, str] | None":
        return None if self._user is None else dict(self._user)

    def set_change_mode(self, mode: str | None) -> None:
        """Set the batch-level change mode and flush prior pending ops.

        Flushing first means commands queued under the previous mode
        retain those semantics — switching modes mid-stream doesn't
        retro-actively re-tag earlier mutations. ``mode`` is one of
        ``"direct"``, ``"tracked"``, or ``None`` to clear.
        """
        if mode is not None and mode not in ("direct", "tracked"):
            raise ValueError(
                f"change_mode must be 'direct', 'tracked', or None; got {mode!r}"
            )
        with self._lock:
            current = self._change_mode
        if current == mode:
            return
        # Drain any queued commands with the *previous* mode before
        # adopting the new one.
        self.flush()
        with self._lock:
            self._change_mode = mode

    def set_user(self, name: str | None, email: str | None = None) -> None:
        """Set the batch-level user identity.

        Sent on every commands request envelope. SuperDoc honors the
        identity at session-open time only — subsequent batches against
        a pooled session ignore the value, but the payload is still
        included so a fresh session picks it up.
        """
        if name is None:
            with self._lock:
                self._user = None
            return
        if not name:
            raise ValueError("user name must be a non-empty string")
        with self._lock:
            self._user = {"name": name}
            if email:
                self._user["email"] = email

    def call(self, cmd: Command) -> Any:
        """Execute or buffer ``cmd``.

        For queries (``BlocksList``, ``Find``, ``GetNodeById``, …)
        AND response-bearing commands that don't carry a client-side
        id, drains the pending queue and runs ``cmd`` in the same
        batch; returns the per-cmd result dict.

        Otherwise — pure mutations (formatters, setters) AND Create*
        commands that carry a pre-minted ``client_node_id`` /
        ``client_entity_id`` — appends to the queue, resets the idle
        timer, and returns ``None``. Caller MUST NOT rely on the return
        value of a buffered mutation. For deferred Creates, the
        applier resolves the client UUID to a real SuperDoc id via
        ``clientIdMap`` on flush and the buffer rewrites each registered
        proxy's ``_node_id`` in-place.
        """
        if self._closed:
            raise RuntimeError(
                f"CommandBuffer for {self._asset_id} is closed",
            )

        # PTC begin: one event per user-facing method call, before any
        # batching. Failures here can't crash the user's code path.
        try:
            cmd._ptc_call_id = _ptc.emit_begin(  # type: ignore[attr-defined]
                type(cmd).__name__,
                cmd.to_dict(),
                asset_id=self._asset_id,
            )
        except Exception:  # noqa: BLE001
            pass

        if must_flush_immediately(cmd) and not self._has_client_id(cmd):
            return self._eager_flush_with(cmd)

        with self._lock:
            self._pending.append(cmd)
            self._reset_timer_locked()
        return None

    @staticmethod
    def _has_client_id(cmd: Command) -> bool:
        """Return ``True`` iff this command carries a pre-minted
        client-side id (``client_node_id`` for nodes,
        ``client_entity_id`` for comments).

        Used by :meth:`call` to decide whether a response-bearing
        Create can defer. Pure response-bearing ops without a client
        id (``Insert``, ``CommentsPatch``, ``TrackChangesDecide``,
        legacy callers) keep their eager-flush semantics so callers
        that read the response still see real data.
        """
        return (
            is_response_bearing(cmd)
            and (
                getattr(cmd, "client_node_id", None) is not None
                or getattr(cmd, "client_entity_id", None) is not None
            )
        )

    def flush(self) -> list[Any]:
        """Flush pending commands as one HTTP batch.

        Returns the list of per-command result dicts. Empty list if nothing
        was pending. Cancels any active idle timer.

        After the batch returns, walks per-cmd results for
        ``real_node_id`` / ``real_entity_id`` echoes and updates any
        proxies registered via :meth:`register_proxy_id_ref` with the
        resolved server ids. This completes the round-trip for the
        always-on transparent batching path — the SDK's caller-facing
        proxies pick up real ids without the caller ever seeing the
        UUID swap.
        """
        with self._lock:
            self._cancel_timer_locked()
            pending = self._pending
            self._pending = []
            change_mode = self._change_mode
            user = None if self._user is None else dict(self._user)
            proxy_id_refs = self._proxy_id_refs
            self._proxy_id_refs = {}
        if not pending:
            return []
        try:
            results = self._client.execute_batch(
                self._asset_id,
                pending,
                change_mode=change_mode,
                user=user,
            )
        except Exception:
            _ptc_emit_end_batch(pending, is_error=True)
            raise
        _ptc_emit_end_batch(pending, is_error=False)
        # Rewrite registered proxies from client-side UUIDs to the real
        # SuperDoc ids the applier echoed back. Defensive: tolerate
        # missing fields (legacy or transitional applier without the
        # client-id support).
        if proxy_id_refs:
            for result in results:
                if not isinstance(result, dict):
                    continue
                for cli_key, real_key in (
                    ("client_node_id", "real_node_id"),
                    ("client_entity_id", "real_entity_id"),
                ):
                    cli = result.get(cli_key)
                    real = result.get(real_key)
                    if not (isinstance(cli, str) and isinstance(real, str)):
                        continue
                    refs = proxy_id_refs.pop(cli, [])
                    for proxy, attr in refs:
                        try:
                            setattr(proxy, attr, real)
                        except Exception:  # noqa: BLE001
                            # A proxy that rejected setattr (slots without
                            # the attr, frozen dataclass, etc.) silently
                            # keeps its client_id — the rewriter in the
                            # applier will still resolve it correctly
                            # for the next batch.
                            pass
        return results

    def close(self) -> None:
        """Flush and disable. Idempotent."""
        if self._closed:
            return
        try:
            self.flush()
        finally:
            self._closed = True
            _unregister(self)

    # ----- internals -----

    def _eager_flush_with(self, cmd: Command) -> Any:
        """Drain pending + run ``cmd`` in one batch; return cmd's result.

        When pending commands include Creates with registered proxy
        refs (queries mid-stream cause this — the caller is awaiting
        their result and the queue must drain first), the proxies
        still get their real ids written back via the same flush-time
        rewrite that :meth:`flush` does.
        """
        with self._lock:
            self._cancel_timer_locked()
            pending = self._pending
            self._pending = []
            change_mode = self._change_mode
            user = None if self._user is None else dict(self._user)
            proxy_id_refs = self._proxy_id_refs
            self._proxy_id_refs = {}
        all_cmds: list[Command] = [*pending, cmd]
        try:
            results: list[Any] = self._client.execute_batch(
                self._asset_id,
                all_cmds,
                change_mode=change_mode,
                user=user,
            )
        except Exception:
            _ptc_emit_end_batch(all_cmds, is_error=True)
            raise
        _ptc_emit_end_batch(all_cmds, is_error=False)
        # Apply the same proxy-rewrite pass as ``flush()`` — see comment
        # there for the contract.
        if proxy_id_refs:
            for result in results:
                if not isinstance(result, dict):
                    continue
                for cli_key, real_key in (
                    ("client_node_id", "real_node_id"),
                    ("client_entity_id", "real_entity_id"),
                ):
                    cli = result.get(cli_key)
                    real = result.get(real_key)
                    if not (isinstance(cli, str) and isinstance(real, str)):
                        continue
                    refs = proxy_id_refs.pop(cli, [])
                    for proxy, attr in refs:
                        try:
                            setattr(proxy, attr, real)
                        except Exception:  # noqa: BLE001
                            pass
        if not results:
            return {}
        return results[-1]

    def _reset_timer_locked(self) -> None:
        # Caller must hold self._lock.
        self._cancel_timer_locked()
        if self._auto_flush_seconds <= 0:
            return  # disabled (e.g. inside batch())
        self._timer = threading.Timer(
            self._auto_flush_seconds,
            self._auto_flush,
        )
        self._timer.daemon = True
        self._timer.start()

    def _cancel_timer_locked(self) -> None:
        # Caller must hold self._lock.
        if self._timer is not None:
            self._timer.cancel()
            self._timer = None

    def _auto_flush(self) -> None:
        try:
            self.flush()
        except Exception as e:  # noqa: BLE001
            sys.stderr.write(
                f"[docx-sdk] auto-flush failed for {self._asset_id}: {e}\n",
            )


__all__ = ["CommandBuffer", "flush_all", "DEFAULT_AUTO_FLUSH_SECONDS"]
