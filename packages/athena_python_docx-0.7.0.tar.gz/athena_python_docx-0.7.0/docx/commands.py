"""Typed command dataclasses for the docx-studio HTTP wire format.

Mirrors `apps/api/src/commands/types.ts`. Every command serializes to a flat
JSON object with a `type` discriminator (PascalCase, matching the class name)
and the rest of its fields converted from snake_case to camelCase.

Design notes:
- These are internal — they aren't part of the python-docx parity surface
  and aren't re-exported from `docx.__init__`. Call sites construct them
  directly and hand them to the session, which serializes + ships them.
- Anchor / target / inline-format leaves are typed as `dict[str, Any]` on
  purpose. SuperDoc owns those vocabularies; we transit them.
- `None`-valued fields are dropped on the wire so the server can apply
  schema defaults (e.g. `count=1` for InsertRow).
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from typing import Any


def _snake_to_camel(s: str) -> str:
    """snake_case → camelCase. Trailing underscore is treated as no-op
    so Python keyword-collision suffixes (``in_`` → ``in``) round-trip
    cleanly on the wire."""
    parts = s.rstrip("_").split("_")
    return parts[0] + "".join(p[:1].upper() + p[1:] for p in parts[1:])


@dataclass
class Command:
    """Base class for all wire commands.

    Subclasses are dataclasses; their class name is used verbatim as the
    `type` discriminator. `to_dict()` walks the dataclass fields, converts
    names to camelCase, and drops `None` values.
    """

    @property
    def type(self) -> str:
        return self.__class__.__name__

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"type": self.type}
        for f in dataclasses.fields(self):
            value = getattr(self, f.name)
            if value is None:
                continue
            out[_snake_to_camel(f.name)] = value
        return out


# ---------------------------------------------------------------------------
# Block-creation commands
# ---------------------------------------------------------------------------


# --- Create* commands carry an optional client-assigned node id ---
#
# The SDK pre-generates a UUID for every new Paragraph/Heading/Table/
# Image and stamps the proxy with it. The applier translates
# ``client_node_id`` → real SuperDoc nodeId in a per-batch map (see
# ``apps/api/src/commands/applier.ts``), so subsequent commands in the
# same batch can target the new block by its client-side id before the
# response has even returned. After flush, the buffer reads the
# resolved ``real_node_id`` out of each Create's response and updates
# the proxy in-place.
#
# Direct internal callers that bypass ``Document`` (legacy helpers,
# fidelity tests) may leave the field unset; the buffer then eager-
# flushes the Create immediately so callers that read the response
# still see real data.
#
# The field is ``client_node_id`` on the Python side and arrives at
# the server as ``clientNodeId`` via ``_snake_to_camel`` — matches the
# Zod schema's ``clientNodeId`` field.


@dataclass
class CreateParagraph(Command):
    text: str
    at: dict[str, Any]
    # Optional `in` story locator for targeting header/footer slots.
    # Renamed ``in_`` on the Python side to avoid the keyword collision;
    # ``_snake_to_camel`` strips the trailing underscore so ``in_``
    # serialises as ``in`` on the wire (see top-of-module helper).
    in_: dict[str, Any] | None = None
    client_node_id: str | None = None


@dataclass
class CreateHeading(Command):
    text: str
    level: int
    at: dict[str, Any]
    # See CreateParagraph.in_ comment above.
    in_: dict[str, Any] | None = None
    client_node_id: str | None = None


@dataclass
class CreateTable(Command):
    rows: int
    columns: int
    at: dict[str, Any]
    in_: dict[str, Any] | None = None
    client_node_id: str | None = None


@dataclass
class CreateImage(Command):
    src: str
    size: dict[str, Any]
    at: dict[str, Any]
    client_node_id: str | None = None


@dataclass
class CreateSectionBreak(Command):
    break_type: str
    at: dict[str, Any]


# ---------------------------------------------------------------------------
# Inline mutations
# ---------------------------------------------------------------------------


@dataclass
class Insert(Command):
    target: dict[str, Any]
    value: str | None = None
    # `value_type` becomes `valueType` on the wire and is mapped to `type`
    # on the SuperDoc call (renamed in transit so it doesn't collide with our
    # discriminator).
    value_type: str | None = None
    placement: str | None = None
    content: dict[str, Any] | None = None


@dataclass
class Replace(Command):
    target: dict[str, Any]
    text: str


@dataclass
class InsertLineBreak(Command):
    block_id: str
    offset: int


@dataclass
class InsertTab(Command):
    block_id: str
    offset: int


@dataclass
class FormatApply(Command):
    target: dict[str, Any]
    inline: dict[str, Any]


@dataclass
class SetParagraphAlignment(Command):
    target: dict[str, Any]
    alignment: str  # "left" | "center" | "right" | "justify" | "start" | "end"


@dataclass
class ClearParagraphAlignment(Command):
    target: dict[str, Any]


@dataclass
class SetParagraphStyle(Command):
    target: dict[str, Any]
    style_id: str


@dataclass
class SetParagraphIndentation(Command):
    target: dict[str, Any]
    left: float | None = None
    right: float | None = None
    first_line: float | None = None
    hanging: float | None = None


@dataclass
class ClearParagraphIndentation(Command):
    target: dict[str, Any]


@dataclass
class SetParagraphSpacing(Command):
    target: dict[str, Any]
    before: float | None = None
    after: float | None = None
    line: float | None = None
    line_rule: str | None = None


@dataclass
class ClearParagraphSpacing(Command):
    target: dict[str, Any]


@dataclass
class SetParagraphKeepOptions(Command):
    target: dict[str, Any]
    keep_next: bool | None = None
    keep_lines: bool | None = None
    widow_control: bool | None = None


@dataclass
class SetParagraphFlowOptions(Command):
    target: dict[str, Any]
    page_break_before: bool | None = None


@dataclass
class SetParagraphTabStop(Command):
    target: dict[str, Any]
    position: float
    alignment: str | None = None
    leader: str | None = None


@dataclass
class ClearParagraphTabStops(Command):
    target: dict[str, Any]


# ---------------------------------------------------------------------------
# Sections
# ---------------------------------------------------------------------------


@dataclass
class SetSectionPageMargins(Command):
    target: dict[str, Any]
    left: float | None = None
    right: float | None = None
    top: float | None = None
    bottom: float | None = None
    gutter: float | None = None


@dataclass
class SetSectionPageSetup(Command):
    target: dict[str, Any]
    width: float | None = None
    height: float | None = None
    orientation: str | None = None  # "portrait" | "landscape"


@dataclass
class SetSectionHeaderFooterMargins(Command):
    target: dict[str, Any]
    header: float | None = None
    footer: float | None = None


@dataclass
class SetSectionBreakType(Command):
    target: dict[str, Any]
    break_type: str


@dataclass
class SetSectionTitlePage(Command):
    """Toggle the ``different first page header/footer`` flag.

    SuperDoc's ``DocSectionsSetTitlePageParams`` requires ``enabled``,
    not ``titlePage``. The earlier dataclass field name made every
    call silently land no-op'd at SuperDoc.
    """

    target: dict[str, Any]
    enabled: bool


@dataclass
class SetSectionsOddEvenHeadersFooters(Command):
    """Toggle the document-level ``<w:evenAndOddHeaders/>`` setting.

    Despite living under the ``sections.*`` namespace on the SuperDoc
    bound-doc API, this op carries no ``target`` — it sets a single
    doc-level flag that applies to every section. Word stores the
    underlying value on ``word/settings.xml`` as
    ``<w:evenAndOddHeaders/>``, which is what python-docx's
    ``Settings.odd_and_even_pages_header_footer`` writes to.

    Available since SuperDoc 1.8.1 (``DocSectionsSetOddEvenHeadersFooters``).
    """

    enabled: bool


@dataclass
class SetSectionLinkToPrevious(Command):
    """Toggle the section-side ``linked-to-previous`` flag for one
    header/footer slot.

    SuperDoc's ``DocSectionsSetLinkToPreviousParams`` requires
    ``target`` (a ``{kind: section, sectionId}``), ``kind`` (``"header"
    | "footer"``), ``variant`` (``"default" | "first" | "even"``), and
    ``linked`` (the boolean). The previous version of this dataclass
    used ``linked_to_previous`` (which serialised as
    ``linkedToPrevious``) and didn't carry ``variant`` at all — so
    every call was silently malformed against SuperDoc's wire schema.
    """

    target: dict[str, Any]
    kind: str  # "header" | "footer"
    variant: str  # "default" | "first" | "even"
    linked: bool


# ---------------------------------------------------------------------------
# Tables (mutations)
# ---------------------------------------------------------------------------


@dataclass
class TablesInsertRow(Command):
    node_id: str
    row_index: int
    position: str  # "above" | "below"
    count: int = 1


@dataclass
class TablesInsertColumn(Command):
    node_id: str
    column_index: int
    position: str  # "left" | "right"
    count: int = 1


@dataclass
class TablesMergeCells(Command):
    node_id: str
    start: dict[str, Any]  # {rowIndex, columnIndex}
    end: dict[str, Any]


@dataclass
class TablesSetStyle(Command):
    node_id: str
    style_id: str


@dataclass
class TablesSetLayout(Command):
    """Table-level layout properties.

    Mirrors SuperDoc's ``DocTablesSetLayoutParams``. ``alignment``
    (left|center|right) and ``table_direction`` (ltr|rtl) live here,
    NOT on ``TablesSetTableOptions`` — the previous split was wrong
    and silently dropped both fields at SuperDoc.

    ``auto_fit_mode`` was previously named ``auto_fit``; SuperDoc's
    wire field is ``autoFitMode``, so calls were silently rejected
    until now.
    """

    node_id: str
    auto_fit_mode: str | None = None  # "fitContents" | "fixedWidth"
    alignment: str | None = None  # "left" | "center" | "right"
    table_direction: str | None = None  # "ltr" | "rtl"
    preferred_width: float | None = None
    left_indent_pt: float | None = None


@dataclass
class TablesSetTableOptions(Command):
    """Table-wide *cell-spacing* and default cell-margin overrides.

    Mirrors SuperDoc's ``DocTablesSetTableOptionsParams`` — alignment
    and direction were moved to :class:`TablesSetLayout` to match
    SuperDoc's actual surface.
    """

    node_id: str
    default_cell_margins: dict[str, Any] | None = None
    cell_spacing_pt: float | None = None


@dataclass
class TablesSetCellProperties(Command):
    target: dict[str, Any]
    vertical_align: str | None = None
    preferred_width_pt: float | None = None


@dataclass
class TablesSetColumnWidth(Command):
    node_id: str
    column_index: int
    width_pt: float


@dataclass
class TablesSetRowHeight(Command):
    node_id: str
    row_index: int
    height_pt: float
    rule: str | None = None  # "auto" | "exact" | "atLeast"


# ---------------------------------------------------------------------------
# Images (mutations)
# ---------------------------------------------------------------------------


@dataclass
class SetImageSize(Command):
    """Resize an inline image.

    Mirrors SuperDoc's ``DocImagesSetSizeParams``. Earlier shape
    (``nodeId, widthPt, heightPt``) was silently rejected — the wire
    schema needs ``imageId`` and a nested ``size: {width, height,
    unit?}`` object. ``unit`` defaults to ``"pt"`` to match athena's
    convention; pass ``"px"`` or ``"twip"`` to override.
    """

    image_id: str
    size: dict[str, Any]


@dataclass
class SetImageAltText(Command):
    """Set alt-text on an inline image. Mirrors SuperDoc's
    ``doc.images.setAltText``. Used by accessibility flows that need
    a text alternative for screen readers."""

    image_id: str
    alt_text: str


@dataclass
class SetImageDecorative(Command):
    """Mark an image as purely decorative so it's skipped by screen
    readers. Mirrors SuperDoc's ``doc.images.setDecorative``."""

    image_id: str
    decorative: bool


@dataclass
class ImagesGet(Command):
    """Read an image's binary / metadata payload by its node id.
    Mirrors SuperDoc's ``doc.images.get``. Backs
    :class:`docx.shape.Picture` accessors."""

    image_id: str


# ---------------------------------------------------------------------------
# Queries
# ---------------------------------------------------------------------------


@dataclass
class BlocksList(Command):
    node_types: list[str] | None = None
    include_text: bool | None = None


@dataclass
class Find(Command):
    # `node_type` on the wire is `nodeType`; mapped to `type` on the
    # SuperDoc call by the server (renamed in transit to avoid colliding
    # with our discriminator).
    node_type: str


@dataclass
class GetNodeById(Command):
    id: str
    node_type: str | None = None


@dataclass
class GetNode(Command):
    target: dict[str, Any]


@dataclass
class ImagesList(Command):
    pass


@dataclass
class Info(Command):
    pass


@dataclass
class SectionsList(Command):
    pass


@dataclass
class SectionsGet(Command):
    target: dict[str, Any]


@dataclass
class TablesGet(Command):
    node_id: str


@dataclass
class TablesGetCells(Command):
    node_id: str
    row_index: int
    column_index: int


@dataclass
class TablesGetProperties(Command):
    node_id: str


@dataclass
class MarkdownToFragment(Command):
    markdown: str


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


@dataclass
class CommentsCreate(Command):
    """Create a new comment, optionally anchored to a text range.

    Mirrors SuperDoc's ``doc.comments.create`` — ``target`` is the
    optional ``{kind: "text", blockId, range}`` anchor, ``text`` is the
    comment body. ``parentId`` threads a reply onto an existing comment.
    """

    text: str | None = None
    target: dict[str, Any] | None = None
    parent_id: str | None = None
    # Optional client-assigned entity id for transparent-batched
    # CommentsCreate (parallel to ``client_node_id`` on Create*; the
    # server applier resolves UUIDs via the same per-batch
    # ``clientIdMap``). ``Comments.add_comment`` currently leaves this
    # unset, so CommentsCreate eager-flushes — left in place for
    # future callers that want to defer comment creates alongside
    # other ops.
    client_entity_id: str | None = None


@dataclass
class CommentsPatch(Command):
    """Update an existing comment's text and/or anchor target."""

    id: str = ""
    text: str | None = None
    target: dict[str, Any] | None = None


@dataclass
class CommentsDelete(Command):
    id: str = ""


@dataclass
class CommentsGet(Command):
    id: str = ""


@dataclass
class CommentsList(Command):
    include_resolved: bool | None = None
    limit: int | None = None
    offset: int | None = None


# ---------------------------------------------------------------------------
# Headers & Footers
# ---------------------------------------------------------------------------


@dataclass
class HeaderFootersList(Command):
    """List header/footer parts in the document, optionally scoped to
    a section or filtered by header/footer kind."""

    kind: str | None = None  # "header" | "footer"
    section: dict[str, Any] | None = None
    limit: int | None = None
    offset: int | None = None


@dataclass
class HeaderFootersGet(Command):
    """Get a specific header/footer slot by section + kind + variant.

    ``target = {kind: "headerFooterSlot", section: {sectionId}, headerFooterKind, variant}``.
    """

    target: dict[str, Any] = dataclasses.field(default_factory=dict)


@dataclass
class HeaderFootersResolve(Command):
    """Resolve a slot to the actual header/footer part — handles
    "linked to previous" inheritance to land on the part that owns
    the rendered content."""

    target: dict[str, Any] = dataclasses.field(default_factory=dict)


@dataclass
class HeaderFootersRefsSetLinkedToPrevious(Command):
    """Toggle the "linked to previous" flag on a header/footer slot."""

    target: dict[str, Any] = dataclasses.field(default_factory=dict)
    linked: bool = True


# ---------------------------------------------------------------------------
# Lists & Selection (SuperDoc 1.8.1 additions)
# ---------------------------------------------------------------------------

# These ops have no direct python-docx parity surface (python-docx
# doesn't expose list-manipulation primitives — list items are just
# paragraphs with "List Bullet"/"List Number" styles). The typed
# Command dataclasses are registered here for bus completeness and so
# advanced callers reaching for ``doc.lists.merge`` / ``doc.lists.split``
# / ``doc.selection.current`` go through the same retry-aware path as
# every other op.


@dataclass
class ListsCreate(Command):
    """Create a new list — either an empty list at an anchor, or by
    converting an existing paragraph (range) into a list.

    SuperDoc: ``doc.lists.create``.

    - ``mode="empty"`` requires ``at`` (BlockAddress).
    - ``mode="fromParagraphs"`` requires ``target`` (BlockAddressOrRange).
    - ``kind`` is ``"bullet"`` or ``"ordered"``.
    """

    mode: str = "fromParagraphs"
    at: dict[str, Any] | None = None
    target: dict[str, Any] | None = None
    kind: str | None = None
    level: int | None = None
    preset: str | None = None


@dataclass
class ListsAttach(Command):
    """Attach an existing paragraph to an existing list as a new item.

    SuperDoc: ``doc.lists.attach``. ``attach_to`` is the list item to
    attach next to (defines list membership); ``target`` is the
    paragraph being converted.
    """

    attach_to: dict[str, Any] = dataclasses.field(default_factory=dict)
    target: dict[str, Any] = dataclasses.field(default_factory=dict)
    level: int | None = None


@dataclass
class ListsMerge(Command):
    """Merge a list item with an adjacent list / list item.

    SuperDoc 1.8.1: ``doc.lists.merge``. ``direction`` selects the
    sibling to merge into ("previous" | "next" | "list").
    """

    target: dict[str, Any] = dataclasses.field(default_factory=dict)
    direction: str = "previous"


@dataclass
class ListsSplit(Command):
    """Split a list at a list item, optionally restarting numbering."""

    target: dict[str, Any] = dataclasses.field(default_factory=dict)
    restart_numbering: bool | None = None


@dataclass
class SelectionCurrent(Command):
    """Read the current selection. Returns a snapshot dict including
    cursor/range info; pass ``include_text=True`` for the selection's
    plain text."""

    include_text: bool | None = None


# ---------------------------------------------------------------------------
# Track Changes
# ---------------------------------------------------------------------------


@dataclass
class TrackChangesList(Command):
    """List tracked changes (insertions, deletions, formatting marks).

    Mirrors SuperDoc's ``doc.trackChanges.list``. The wire field for
    "filter by change type" is ``type`` on SuperDoc's side; we send
    ``changeType`` instead and the server applier renames in transit so
    it doesn't collide with our top-level Command discriminator
    (``type: "TrackChangesList"``).

    ``in_`` accepts either the literal string ``"all"`` (apply across
    every story — body, headers, footnotes, ...) or a story locator
    dict ``{kind: "story", storyType, ...}``. Trailing-underscore on
    the field name avoids the Python keyword collision; the
    ``_snake_to_camel`` helper strips it for the wire.
    """

    change_type: str | None = None  # "insert" | "delete" | "format"
    limit: int | None = None
    offset: int | None = None
    in_: dict[str, Any] | str | None = None


@dataclass
class TrackChangesGet(Command):
    """Read a single tracked change by id.

    Returns ``{address, id, type, author, authorEmail, date, excerpt,
    wordRevisionIds?}``. ``story`` narrows the lookup to a specific
    body/header/footnote scope when the change id might collide across
    stories (rare, but supported).
    """

    id: str = ""
    story: dict[str, Any] | None = None


@dataclass
class TrackChangesDecide(Command):
    """Accept or reject one or all tracked changes.

    Mirrors SuperDoc's ``doc.trackChanges.decide``. ``decision`` is
    ``"accept"`` or ``"reject"``. ``target`` is either a single change
    address (``{id, story?}``) or the bulk sentinel
    (``{scope: "all"}``).

    ``change_mode`` overrides the batch-level mode for *this one
    decide* — useful when you want to decide a change that itself was
    made under tracked mode without recursively producing more
    changes. Default behaviour: omit and let SuperDoc apply ``direct``.
    """

    decision: str = "accept"  # "accept" | "reject"
    target: dict[str, Any] = dataclasses.field(default_factory=dict)
    force: bool | None = None
    expected_revision: int | None = None
    change_mode: str | None = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# Set of commands that mutate the doc. Inverse is "queries". Used by the
# CommandBuffer to decide whether to flush before issuing (queries always
# flush; pure mutations may be buffered).
_QUERY_TYPES: frozenset[str] = frozenset(
    {
        "BlocksList",
        "Find",
        "GetNodeById",
        "GetNode",
        "ImagesList",
        "Info",
        "SectionsList",
        "SectionsGet",
        "TablesGet",
        "TablesGetCells",
        "TablesGetProperties",
        "MarkdownToFragment",
        "CommentsGet",
        "CommentsList",
        "HeaderFootersList",
        "HeaderFootersGet",
        "HeaderFootersResolve",
        "SelectionCurrent",
        # Track-changes reads — never mutate, always flush.
        "TrackChangesList",
        "TrackChangesGet",
    }
)

# Mutating commands whose response carries data the caller needs (a new
# node id, typically). These must be flushed immediately rather than
# deferred — the caller is about to read the response.
_RESPONSE_BEARING_TYPES: frozenset[str] = frozenset(
    {
        "CreateParagraph",
        "CreateHeading",
        "CreateTable",
        # CreateImage returns {image: {nodeId}}; SetImageSize and the
        # InlineShape proxy both need that nodeId, so it must flush.
        "CreateImage",
        # Insert sometimes returns an id; treat as response-bearing for safety.
        "Insert",
        # CreateSectionBreak intentionally NOT here — it returns no node id;
        # the caller resolves the new section via sections.list afterwards.
        # CommentsCreate returns the new comment's entityId — caller wraps
        # it in a Comment proxy.
        "CommentsCreate",
        "CommentsPatch",
        # TrackChangesDecide returns {success, inserted, updated, removed}
        # describing the entities affected by accept/reject — callers
        # need that synchronously to invalidate their Revision proxies.
        "TrackChangesDecide",
        # ListsCreate / ListsAttach return {item: {nodeId: <listItemId>}}.
        # Document.add_paragraph reads listItemId to (1) update the
        # Paragraph proxy's node_id so subsequent ops target the
        # listItem, and (2) chain the next list item via lists.attach.
        "ListsCreate",
        "ListsAttach",
    }
)


def is_query(cmd: Command) -> bool:
    return cmd.type in _QUERY_TYPES


def is_response_bearing(cmd: Command) -> bool:
    return cmd.type in _RESPONSE_BEARING_TYPES


def must_flush_immediately(cmd: Command) -> bool:
    """A command that can't be buffered — caller will read the response."""
    return is_query(cmd) or is_response_bearing(cmd)


__all__ = [
    "Command",
    # Block creation
    "CreateParagraph",
    "CreateHeading",
    "CreateTable",
    "CreateImage",
    "CreateSectionBreak",
    # Inline mutations
    "Insert",
    "Replace",
    "InsertLineBreak",
    "InsertTab",
    "FormatApply",
    "SetParagraphAlignment",
    "ClearParagraphAlignment",
    "SetParagraphStyle",
    "SetParagraphIndentation",
    "ClearParagraphIndentation",
    "SetParagraphSpacing",
    "ClearParagraphSpacing",
    "SetParagraphKeepOptions",
    "SetParagraphFlowOptions",
    "SetParagraphTabStop",
    "ClearParagraphTabStops",
    # Sections
    "SetSectionPageMargins",
    "SetSectionPageSetup",
    "SetSectionHeaderFooterMargins",
    "SetSectionBreakType",
    "SetSectionTitlePage",
    "SetSectionsOddEvenHeadersFooters",
    "SetSectionLinkToPrevious",
    # Tables (mutations)
    "TablesInsertRow",
    "TablesInsertColumn",
    "TablesMergeCells",
    "TablesSetStyle",
    "TablesSetLayout",
    "TablesSetTableOptions",
    "TablesSetCellProperties",
    "TablesSetColumnWidth",
    "TablesSetRowHeight",
    # Images (mutations)
    "SetImageSize",
    # Queries
    "BlocksList",
    "Find",
    "GetNodeById",
    "GetNode",
    "ImagesList",
    "Info",
    "SectionsList",
    "SectionsGet",
    "TablesGet",
    "TablesGetCells",
    "TablesGetProperties",
    "MarkdownToFragment",
    # Track Changes
    "TrackChangesList",
    "TrackChangesGet",
    "TrackChangesDecide",
    # Helpers
    "is_query",
    "is_response_bearing",
    "must_flush_immediately",
]
