"""Document class — mirrors python-docx's Document.

Phase 1 supported methods:
    .paragraphs        -> list[Paragraph]  (snapshot on access)
    .tables            -> list[Table]
    .add_paragraph(text, style=None) -> Paragraph
    .add_heading(text, level=1) -> Paragraph
    .add_table(rows, cols, style=None) -> Table
    .add_picture(image_path_or_stream, width=None, height=None) -> None
    .add_page_break() -> None
    .save(path=None) -> None  (path ignored; always in-place)
    .close() -> None
"""

from __future__ import annotations

import base64
import io
import sys
import warnings
from contextlib import contextmanager
from typing import TYPE_CHECKING, BinaryIO, Generator, Iterator

from docx._batching import run_sync
from docx.client import Session
from docx.errors import DocumentClosedError, ValidationError
# python-docx re-exports a subset of symbols at docx.document; mirror those
# so `from docx.document import Emu` etc. works.
from docx.enum.section import WD_SECTION, WD_SECTION_START  # noqa: F401
from docx.enum.text import WD_BREAK  # noqa: F401
from docx.section import Section, Sections  # noqa: F401
from docx.shared import Cm, Emu, Inches, Length, Mm, Pt, RGBColor, Twips  # noqa: F401
from docx.text.run import Run  # noqa: F401

if TYPE_CHECKING:
    from collections.abc import Sequence

    from docx.comments import Comment, Comments
    from docx.revisions import Revisions
    from docx.shape import InlineShape
    from docx.styles.style import ParagraphStyle, TableStyle
    from docx.table import Table
    from docx.text.paragraph import Paragraph


def _log_warn(msg: str) -> None:
    print(f"[docx-sdk] WARN: {msg}", file=sys.stderr)


class _InlineShapeIdAdapter:
    """Adapter that lets the CommandBuffer rewrite an InlineShape's
    node id after a batched ``add_picture`` resolves.

    ``InlineShape`` stores its id at ``_info["nodeId"]`` rather than a
    top-level attribute, so the buffer's ``setattr(proxy, attr, real)``
    can't directly target the right key. This adapter accepts
    ``setattr(_, "node_id", real)`` and writes ``shape._info["nodeId"]``
    on the underlying shape. Lives at module scope so the buffer can
    hold a stable reference even if the user code drops the shape
    (the adapter keeps a strong ref to the shape).
    """

    __slots__ = ("_shape",)

    def __init__(self, shape: object) -> None:
        self._shape = shape

    def __setattr__(self, name: str, value: object) -> None:
        if name == "_shape":
            object.__setattr__(self, name, value)
            return
        if name == "node_id":
            info = getattr(self._shape, "_info", None)
            if isinstance(info, dict):
                info["nodeId"] = value
            return
        raise AttributeError(
            f"_InlineShapeIdAdapter only supports node_id; got {name!r}"
        )


def _classify_list_style(style_id: str | None) -> tuple[str, int] | None:
    """Map a python-docx list-style id to a SuperDoc (kind, level) pair.

    Returns ``None`` for non-list styles. Recognized styles:

    - ``"List Bullet"``    → ``("bullet", 0)``
    - ``"List Bullet 2"``  → ``("bullet", 1)``     (... up to ``5`` → level 4)
    - ``"List Number"``    → ``("ordered", 0)``
    - ``"List Number 2"``  → ``("ordered", 1)``    (... up to ``5`` → level 4)

    Accepts both display-name (``"List Bullet 2"``) and style-id
    (``"ListBullet2"``) forms. ``"List Paragraph"`` and ``"List Continue"``
    are intentionally NOT classified as bullet/number lists — those styles
    indicate "indented body text", not a numbered/bulleted list, and Word
    renders them without a marker. Callers wanting those effects should
    use the style as-is via the generic ``setStyle`` path.
    """
    if not isinstance(style_id, str) or not style_id:
        return None
    # Normalize: lower-case, strip spaces.
    norm = style_id.lower().replace(" ", "")
    if norm.startswith("listbullet"):
        suffix = norm[len("listbullet"):]
        kind = "bullet"
    elif norm.startswith("listnumber"):
        suffix = norm[len("listnumber"):]
        kind = "ordered"
    else:
        return None
    if suffix == "":
        level = 0
    else:
        try:
            n = int(suffix)
        except ValueError:
            return None
        if n < 1 or n > 9:
            return None
        # "List Bullet 2" → level 1 (zero-indexed depth).
        level = n - 1
    return (kind, level)


class IgnoredSaveTargetWarning(UserWarning):
    """Emitted when ``Document.save(path_or_stream=...)`` is called with a
    non-None argument.

    The SDK is asset-backed: edits are flushed in place against the
    Y.Doc, and the ``path_or_stream`` parameter is accepted only for
    parity-friendly call sites (see :meth:`Document.save`). A caller
    passing a path or stream almost certainly expects a local-file
    export, which this SDK cannot perform. Surfacing a warning makes
    the silent gap visible without breaking agent-generated code that
    reflexively calls ``doc.save()`` with no args.
    """


class Document:
    """A Word document backed by a Superdoc/Keryx Y.Doc.

    Construct via :func:`docx.api.Document` (recommended) — do not
    instantiate this class directly in user code.
    """

    def __init__(
        self,
        *,
        asset_id: str,
        http_base_url: str | None = None,
        http_api_key: str | None = None,
        user_name: str | None = None,
        user_email: str | None = None,
        track_revisions: bool = False,
    ) -> None:
        self._session: Session = Session(
            asset_id=asset_id,
            http_base_url=http_base_url,
            http_api_key=http_api_key,
        )
        self._saved: bool = False
        self._closed: bool = False
        # Track-changes state. Defaults are deferred to the buffer (set
        # only when non-default) so existing callers retain the
        # baseline "no envelope changeMode/user" behavior.
        self._pending_user_name: str | None = user_name
        self._pending_user_email: str | None = user_email
        self._pending_track_revisions: bool = bool(track_revisions)
        # List-chain state. When the most-recent ``add_paragraph`` call
        # produced a list item, subsequent ``add_paragraph(..., style="List
        # Bullet"|"List Number")`` calls attach to it (lists.attach)
        # instead of starting a new list (lists.create). Any non-list
        # ``add_paragraph`` / ``add_heading`` / ``add_table`` resets this.
        self._last_list_item_id: str | None = None
        self._last_list_kind: str | None = None

    @classmethod
    def create(
        cls,
        name: str | None = None,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        parent_folder_id: str | None = None,
        workspace_id: str | None = None,
        user_name: str | None = None,
        user_email: str | None = None,
        track_revisions: bool = False,
    ) -> "Document":
        """Create a new SuperDocument asset and return an opened Document.

        Hits ``POST {base_url}/docs/empty`` on docx-studio with the
        provided Athena API key, then returns a Document bound to the
        new asset.

        Args:
            name: Display title for the new document. Defaults to the
                Athena naming convention if omitted.
            base_url: docx-studio API base URL. Falls back to
                ``$ATHENA_DOCX_BASE_URL``.
            api_key: Athena API key (PropelAuth user API key) or
                access token. Falls back to ``$ATHENA_DOCX_API_KEY``.
            parent_folder_id: Optional parent folder; defaults to
                workspace root.
            workspace_id: Optional workspace UUID; defaults to the
                caller's current workspace as resolved by Agora.

        Returns:
            A Document bound to the newly-created asset.

        Raises:
            SessionError: missing base_url, or docx-studio is unreachable.
            AuthenticationError: missing api_key, or 401/403 from server.
            DocxError: any other server-side failure.

        DEVIATION FROM python-docx: stock python-docx returns a blank
        in-memory document for ``Document(None)``. Our SDK is backed by
        an Athena asset, so we expose a separate ``create()`` factory
        rather than overloading the constructor.
        """
        from docx._http import create_empty_document

        result = create_empty_document(
            base_url=base_url,
            api_key=api_key,
            name=name,
            parent_folder_id=parent_folder_id,
            workspace_id=workspace_id,
        )
        return cls(
            asset_id=result["asset_id"],
            http_base_url=base_url,
            http_api_key=api_key,
            user_name=user_name,
            user_email=user_email,
            track_revisions=track_revisions,
        )

    # ---- Public properties ----

    @property
    def paragraphs(self) -> list["Paragraph"]:
        """Return all paragraphs in document order.

        python-docx returns a live list; we return a snapshot. For a
        live-ish list, call this again.
        """
        from docx.text.paragraph import Paragraph

        self._ensure_open()
        # doc.blocks.list takes `nodeTypes: list[str]` (not `type: str`).
        # Include "heading" too so iterating over paragraphs covers both —
        # python-docx does not distinguish headings from paragraphs at the
        # Document.paragraphs level either (they're all Paragraph instances).
        raw: object = run_sync(
            self._session.doc.blocks.list(
                {"nodeTypes": ["paragraph", "heading"], "includeText": True},
            ),
        )
        # Real shape: {"blocks": [{"kind":"block","nodeType":..,"nodeId":..,"text":..}], ...}
        if isinstance(raw, dict):
            blocks_obj: object = raw.get("blocks", [])
            blocks: list = blocks_obj if isinstance(blocks_obj, list) else []
        elif isinstance(raw, list):
            blocks = raw
        else:
            blocks = []
        out: list["Paragraph"] = []
        for b in blocks:
            if not isinstance(b, dict):
                continue
            node_id: str = str(b.get("nodeId", ""))
            if node_id:
                nt_raw = b.get("nodeType")
                nt: str = nt_raw if isinstance(nt_raw, str) and nt_raw else "paragraph"
                out.append(
                    Paragraph(
                        session=self._session,
                        node_id=node_id,
                        node_type=nt,
                    ),
                )
        return out

    @property
    def tables(self) -> list["Table"]:
        """Return all tables in document order."""
        from docx.table import Table

        self._ensure_open()
        find_result: dict = run_sync(
            self._session.doc.find({"type": "table"}),
        )
        items: list[dict] = find_result.get("items", [])
        return [
            Table(session=self._session, node_id=item["address"]["nodeId"])
            for item in items
        ]

    @property
    def sections(self):
        """Return the document's sections collection."""

        self._ensure_open()
        return Sections(session=self._session)

    def iter_inner_content(self) -> "Iterator[Paragraph | Table]":
        """Yield each top-level Paragraph or Table in document order.

        Mirrors python-docx 1.x. Order follows the SuperDoc block list,
        which is document order. Paragraphs include both ``paragraph`` and
        ``heading`` node types — python-docx surfaces both as ``Paragraph``
        instances at this level.
        """
        from docx.table import Table
        from docx.text.paragraph import Paragraph

        self._ensure_open()
        raw: object = run_sync(
            self._session.doc.blocks.list(
                {
                    "nodeTypes": ["paragraph", "heading", "table"],
                    "includeText": False,
                },
            ),
        )
        blocks: list = []
        if isinstance(raw, dict):
            blocks_obj: object = raw.get("blocks", [])
            if isinstance(blocks_obj, list):
                blocks = blocks_obj
        elif isinstance(raw, list):
            blocks = raw
        for b in blocks:
            if not isinstance(b, dict):
                continue
            node_id: str = str(b.get("nodeId", ""))
            if not node_id:
                continue
            nt = b.get("nodeType")
            if nt == "table":
                yield Table(session=self._session, node_id=node_id)
            else:
                yield Paragraph(
                    session=self._session,
                    node_id=node_id,
                    node_type=nt if isinstance(nt, str) else "paragraph",
                )

    @property
    def inline_shapes(self):
        """Return the document's inline-shape collection."""
        from docx.shape import InlineShapes

        self._ensure_open()
        return InlineShapes(session=self._session)

    @property
    def styles(self):
        """Return the document's styles collection."""
        from docx.styles.styles import Styles

        self._ensure_open()
        return Styles(session=self._session)

    @property
    def core_properties(self):
        """Return a minimal CoreProperties proxy.

        Most python-docx fields aren't surfaced by Superdoc; accessing an
        unsupported field returns None rather than raising.
        """
        from docx.opc.coreprops import CoreProperties

        return CoreProperties(session=self._session)

    @property
    def settings(self):
        """Return a minimal Settings proxy.

        Most Word app settings aren't surfaced by Superdoc.
        ``Settings.track_revisions`` is wired through to
        :attr:`Document.track_revisions` so python-docx-style call sites
        (``doc.settings.track_revisions = True``) work end-to-end.
        """
        from docx.settings import Settings

        return Settings(session=self._session, document=self)

    @property
    def element(self):
        """The underlying document element.

        Not surfaced by athena-python-docx — the SDK is HTTP-only and
        doesn't expose lxml elements. Raises ``AttributeError`` so
        callers fail loudly rather than crashing on
        ``NoneType.append`` further downstream. See python-sdk/CLAUDE.md
        § 'Intentionally omitted'.
        """
        raise AttributeError(
            "Document.element is not surfaced by athena-python-docx — "
            "the SDK is HTTP-only and doesn't expose lxml elements. "
            "See python-sdk/CLAUDE.md § 'Intentionally omitted'."
        )

    @property
    def part(self):
        """The OPC document part. Not surfaced — see :attr:`element`."""
        raise AttributeError(
            "Document.part is not surfaced by athena-python-docx — "
            "the SDK is HTTP-only and doesn't expose OPC parts. "
            "See python-sdk/CLAUDE.md § 'Intentionally omitted'."
        )

    # ---- Track changes (Athena extension — see docx.revisions) ----

    @property
    def track_revisions(self) -> bool:
        """Whether subsequent mutations are recorded as tracked
        revisions instead of direct edits.

        Setting this to ``True`` flushes any pending buffered commands
        (so they retain their previous semantics) before switching the
        mode for new commands. Toggling repeatedly is safe — a no-op
        when the value doesn't change.

        DEVIATION FROM python-docx: upstream has no top-level
        ``track_revisions`` property. The closest thing is
        ``Document.settings.element`` carrying ``<w:trackChanges/>``.
        We expose this as a Document-level toggle for ergonomics; the
        ``Document.settings.track_revisions`` alias gives parity-
        friendly call sites the same surface.
        """
        return self._pending_track_revisions

    @track_revisions.setter
    def track_revisions(self, value: bool) -> None:
        new_value = bool(value)
        if new_value == self._pending_track_revisions:
            return
        self._pending_track_revisions = new_value
        # If the session is open, push immediately so subsequent
        # mutations land under the new mode. Otherwise the value is
        # captured and synced at session-open time.
        buffer = self._buffer()
        if buffer is not None:
            buffer.set_change_mode("tracked" if new_value else None)

    @contextmanager
    def tracked_revisions(self) -> "Generator[None, None, None]":
        """Scope ``track_revisions=True`` to a ``with`` block.

        Restores the previous value (typically ``False``) on exit, even
        if the body raises. Useful for "make these specific edits as
        tracked changes" without leaking the mode to surrounding code::

            with doc.tracked_revisions():
                doc.add_paragraph("Reviewer note: please verify.")
                # ...

        The mode change forces a buffer flush at entry and exit, so
        prior buffered ops keep their original mode.
        """
        previous: bool = self._pending_track_revisions
        self.track_revisions = True
        try:
            yield
        finally:
            self.track_revisions = previous

    @property
    def user_name(self) -> "str | None":
        """The author identity threaded through to SuperDoc on
        session-open, used for tracked-change attribution.

        ``None`` means "fall back to the docx-studio service account".
        Setting after the session is open does not retro-actively
        rename existing changes — SuperDoc honors the value at session
        creation.
        """
        return self._pending_user_name

    @user_name.setter
    def user_name(self, value: "str | None") -> None:
        if value is not None and not isinstance(value, str):
            raise ValidationError(
                f"user_name must be a string or None; got {type(value)!r}"
            )
        self._pending_user_name = value or None
        buffer = self._buffer()
        if buffer is not None:
            buffer.set_user(self._pending_user_name, self._pending_user_email)

    @property
    def user_email(self) -> "str | None":
        """Optional email displayed alongside the author name in
        tracked-change tooltips. Same lifecycle caveats as
        :attr:`user_name`."""
        return self._pending_user_email

    @user_email.setter
    def user_email(self, value: "str | None") -> None:
        if value is not None and not isinstance(value, str):
            raise ValidationError(
                f"user_email must be a string or None; got {type(value)!r}"
            )
        self._pending_user_email = value or None
        buffer = self._buffer()
        if buffer is not None:
            buffer.set_user(self._pending_user_name, self._pending_user_email)

    @property
    def revisions(self) -> "Revisions":
        """Return the document's tracked-changes collection.

        Iterating yields :class:`docx.revisions.Revision` proxies.
        Bulk-resolve via :meth:`Revisions.accept_all` /
        :meth:`Revisions.reject_all`; per-change resolve via
        :meth:`Revision.accept` / :meth:`Revision.reject`.

        DEVIATION FROM python-docx: upstream has no track-changes API
        whatsoever. This is an Athena extension wired to SuperDoc's
        ``doc.trackChanges.{list,get,decide}``.
        """
        from docx.revisions import Revisions

        self._ensure_open()
        return Revisions(session=self._session)

    # ---- Comments (stubbed — see docx-studio/PYTHON_DOCX_PARITY_GAPS.md § 3.1) ----

    @property
    def comments(self) -> "Comments":
        """Return a :class:`Comments` collection for the document.

        Stub — yields an empty collection and accepts ``isinstance``
        checks. ``add_comment`` raises until backend support lands.
        """
        from docx.comments import Comments

        return Comments(session=self._session)

    def add_comment(
        self,
        runs: "Run | Sequence[Run]",
        text: "str | None" = "",
        author: str = "",
        initials: "str | None" = "",
    ) -> "Comment":
        """Insert a comment anchored to one or more runs.

        Mirrors python-docx ``Document.add_comment(runs, text, author,
        initials) -> Comment``. The runs must be co-located in a single
        block (Word can't anchor a comment to disjoint blocks); if they
        span multiple blocks the comment is created unanchored.
        """
        from docx.comments import _create_anchored_comment

        return _create_anchored_comment(
            self._session,
            runs,
            text=text or "",
            author=author,
            initials=initials or "",
        )

    # ---- Append operations ----

    @staticmethod
    def _normalize_text(text: str) -> str:
        """Normalize line endings like python-docx: \\r\\n → \\n\\n, lone \\r → \\n."""
        # python-docx's text IO strips \r and converts \r to \n.
        if not text:
            return text
        # \r\n → \n\n (preserves paragraph-break semantics)
        return text.replace("\r\n", "\n\n").replace("\r", "\n")

    def add_paragraph(
        self,
        text: str = "",
        style: "str | ParagraphStyle | None" = None,
    ) -> "Paragraph":
        """Append a new paragraph at the end of the document.

        Args:
            text: The paragraph text.
            style: Style name string (e.g. "Heading 1", "Normal") or a
                   :class:`ParagraphStyle` instance. ``None`` uses the
                   default style.

        Returns:
            The newly-created Paragraph.
        """
        from docx.styles.style import ParagraphStyle
        from docx.text.paragraph import Paragraph

        self._ensure_open()

        # Coerce ParagraphStyle instances to their style id so the rest
        # of this method can treat `style` as an Optional[str].
        # python-docx 1.x accepts ``str | ParagraphStyle | None`` and
        # raises ``TypeError`` at the style-lookup layer for anything
        # else. Mirror that — the previous code accepted ``style`` as
        # the literal value when it wasn't a ParagraphStyle, so e.g.
        # ``add_paragraph(style=42)`` shipped ``42`` as the style id.
        style_str: str | None
        if style is None:
            style_str = None
        elif isinstance(style, ParagraphStyle):
            style_str = style.style_id
        elif isinstance(style, str):
            style_str = style
        else:
            raise TypeError(
                f"Document.add_paragraph style requires str, "
                f"ParagraphStyle, or None; got "
                f"{type(style).__name__} {style!r}",
            )

        # Use Superdoc's canonical primitive `doc.create.paragraph`. It
        # accepts an `at` anchor and a `text` body; an empty `text` creates
        # a truly-empty paragraph (no markdown-parser edge case).
        #
        # For heading styles we still dispatch to add_heading, which uses
        # `doc.create.heading` (also canonical, takes `level`).
        if style_str and style_str.lower().startswith("heading"):
            try:
                level: int = int(style_str.rsplit(" ", 1)[-1])
            except ValueError:
                level = 1
            return self.add_heading(text=text, level=level)
        if style_str and style_str.lower() == "title":
            return self.add_heading(text=text, level=0)

        # python-docx parity: tabs and line breaks in `text` must
        # round-trip as Word ``<w:tab/>`` / ``<w:br/>`` elements, not
        # literal characters. SuperDoc's ``create.paragraph(text=…)``
        # stores them as literal text, so when control chars are
        # present we create an EMPTY paragraph and let
        # ``Paragraph.add_run`` (which segments tabs/breaks) do the
        # heavy lifting.
        normalized: str = self._normalize_text(text)
        has_control_chars = any(ch in "\t\n\r" for ch in normalized)
        wire_text: str = "" if has_control_chars else normalized
        # Pre-assign a client-side UUID so the Create can buffer
        # alongside subsequent mutations (style, runs, list-promote).
        # The applier resolves ``client_node_id`` → real SuperDoc id
        # via per-batch ``clientIdMap`` on flush, and the buffer
        # rewrites the proxy's ``_node_id`` from its UUID to the
        # resolved id. Net result: one HTTP POST for N create + format
        # ops, exactly like python-docx's in-memory write + .save() flow.
        client_node_id = self._mint_client_node_id("p")
        params: dict = {
            "text": wire_text,
            "at": {"kind": "documentEnd"},
            "client_node_id": client_node_id,
        }
        run_sync(self._session.doc.create.paragraph(params))
        node_id = client_node_id
        # Seed the text-length cache so the next ``p.add_run(...)``
        # call can skip its ``get_node_by_id`` HTTP round-trip.
        para = Paragraph(
            session=self._session,
            node_id=node_id,
            node_type="paragraph",
            text_len=len(wire_text),
        )
        self._register_proxy_id(client_node_id, para)
        if has_control_chars and normalized:
            # Use the segment-aware path on Paragraph.add_run so each
            # tab/newline lands as a real inline.
            para.add_run(normalized)
        # Apply non-heading paragraph styles via setStyle. python-docx
        # does this implicitly when you pass `style=...` — we mirror by
        # routing through Paragraph.style which calls
        # doc.styles.paragraph.setStyle on Superdoc.
        if style_str:
            # Don't swallow style-application failures — a bad styleId
            # or transport error otherwise leaves the user with a
            # paragraph that quietly missed the style they asked for.
            para.style = style_str

        # python-docx parity: ``add_paragraph(text, style="List Bullet")``
        # is the canonical way to author a bulleted/numbered list (the
        # upstream library exposes no separate list primitive — the style
        # is the list). On Word/OOXML the style's ``<w:numPr/>`` makes
        # bullets appear; on SuperDoc/ProseMirror the style attribute
        # alone does NOT, because lists are a distinct node type
        # (``bulletList > listItem > paragraph``) rather than a flat
        # paragraph with a style.
        #
        # To make the python-docx contract render correctly we follow
        # up the paragraph create + setStyle with SuperDoc's
        # ``doc.lists.create`` / ``doc.lists.attach`` so the paragraph
        # is structurally converted into a list item under a real
        # bulletList / orderedList node. Consecutive list-styled
        # ``add_paragraph`` calls (of the same kind) chain into a
        # single list via ``lists.attach``; the first one starts a new
        # list via ``lists.create(mode="fromParagraphs")``.
        list_info = _classify_list_style(style_str)
        if list_info is not None:
            kind, level = list_info
            self._convert_paragraph_to_list_item(
                paragraph_node_id=node_id,
                kind=kind,
                level=level,
            )
        else:
            # Any non-list paragraph breaks the chain — the next list
            # item will start a fresh list.
            self._last_list_item_id = None
            self._last_list_kind = None
        return para

    def _convert_paragraph_to_list_item(
        self,
        *,
        paragraph_node_id: str,
        kind: str,
        level: int,
    ) -> None:
        """Promote a flat paragraph into a list item.

        Chains with the previous list (same ``kind``) via
        ``lists.attach``; otherwise starts a new list via
        ``lists.create(mode="fromParagraphs")``. Updates the
        ``_last_list_item_id`` / ``_last_list_kind`` chain state so the
        next list-styled ``add_paragraph`` call attaches to this item.

        Failures don't raise — the paragraph + setStyle already
        landed, and surfacing a structural-promotion error here would
        roll back work the caller can't undo. We emit a console warning
        and reset the chain so subsequent items start fresh rather than
        attaching to an orphaned id.
        """
        para_target: dict = {
            "kind": "block",
            "nodeType": "paragraph",
            "nodeId": paragraph_node_id,
        }
        try:
            if (
                self._last_list_item_id is not None
                and self._last_list_kind == kind
            ):
                result = run_sync(
                    self._session.doc.lists.attach(
                        {
                            "attach_to": {
                                "kind": "block",
                                "nodeType": "listItem",
                                "nodeId": self._last_list_item_id,
                            },
                            "target": para_target,
                            "level": level,
                        },
                    ),
                )
            else:
                result = run_sync(
                    self._session.doc.lists.create(
                        {
                            "mode": "fromParagraphs",
                            "target": para_target,
                            "kind": kind,
                            "level": level,
                        },
                    ),
                )
        except Exception as e:  # noqa: BLE001
            _log_warn(
                f"list-item promotion failed for paragraph "
                f"{paragraph_node_id!r} ({kind}, level {level}): {e}; "
                f"paragraph remains flat with the style attribute set.",
            )
            self._last_list_item_id = None
            self._last_list_kind = None
            return

        item_id = self._extract_list_item_id(result)
        if item_id:
            self._last_list_item_id = item_id
            self._last_list_kind = kind
        else:
            # Couldn't read back the listItem id — break the chain so the
            # next call doesn't attach to a stale or missing target.
            _log_warn(
                f"list op returned no item.nodeId for paragraph "
                f"{paragraph_node_id!r}; list chain reset. Response: "
                f"{result!r}",
            )
            self._last_list_item_id = None
            self._last_list_kind = None

    def _reset_list_chain(self) -> None:
        """Break the consecutive-list-items chain. Called by any block
        insertion that isn't a list-styled paragraph (heading, table,
        picture, page break, section break) so the next list item
        starts a fresh list rather than attaching to a stale predecessor.
        """
        self._last_list_item_id = None
        self._last_list_kind = None

    @staticmethod
    def _extract_list_item_id(result: object) -> str | None:
        """Pull ``item.nodeId`` out of a ``lists.create`` / ``lists.attach``
        SuperDoc response. Returns ``None`` if the shape is unexpected."""
        if not isinstance(result, dict):
            return None
        item = result.get("item")
        if not isinstance(item, dict):
            return None
        node_id = item.get("nodeId") or item.get("node_id")
        if isinstance(node_id, str) and node_id:
            return node_id
        return None

    def add_heading(
        self,
        text: str = "",
        level: int = 1,
    ) -> "Paragraph":
        """Append a heading via Superdoc's canonical `doc.create.heading`."""
        from docx.text.paragraph import Paragraph

        self._ensure_open()
        self._reset_list_chain()
        if not 0 <= level <= 9:
            raise ValidationError(
                f"level must be in 0..9; got {level}",
            )

        # python-docx parity: tabs/newlines in `text` must round-trip
        # as Word inlines, not literal characters. SuperDoc's
        # create.heading / create.paragraph store the `text` parameter
        # as a single text run, so when control chars are present we
        # create an empty block and let Paragraph.add_run segment the
        # text into proper tab/lineBreak inlines.
        normalized = self._normalize_text(text)
        has_control_chars = any(ch in "\t\n\r" for ch in normalized)
        wire_text = "" if has_control_chars else normalized

        # python-docx semantics: level=0 is Title, 1..9 are Heading N.
        # Superdoc's doc.create.heading only accepts integer levels 1..6,
        # so Title (level=0) routes through create.paragraph followed by a
        # style change to "Title". Levels 7..9 fall through to create.heading
        # and will raise a SuperDocError if the runtime rejects them — that
        # mirrors python-docx's tolerance without silently degrading.
        if level == 0:
            client_node_id = self._mint_client_node_id("p")
            title_params: dict = {
                "text": wire_text,
                "at": {"kind": "documentEnd"},
                "client_node_id": client_node_id,
            }
            run_sync(self._session.doc.create.paragraph(title_params))
            node_id = client_node_id
            paragraph = Paragraph(
                session=self._session,
                node_id=node_id,
                node_type="paragraph",
                text_len=len(wire_text),
            )
            self._register_proxy_id(client_node_id, paragraph)
            paragraph.style = "Title"
            if has_control_chars and normalized:
                paragraph.add_run(normalized)
            return paragraph

        client_node_id = self._mint_client_node_id("h")
        params: dict = {
            "text": wire_text,
            "level": level,
            "at": {"kind": "documentEnd"},
            "client_node_id": client_node_id,
        }
        run_sync(self._session.doc.create.heading(params))
        node_id = client_node_id
        heading = Paragraph(
            session=self._session,
            node_id=node_id,
            node_type="heading",
            text_len=len(wire_text),
        )
        self._register_proxy_id(client_node_id, heading)
        if has_control_chars and normalized:
            heading.add_run(normalized)
        return heading

    def add_table(
        self,
        rows: int,
        cols: int,
        style: "str | TableStyle | None" = None,
    ) -> "Table":
        """Append a table with the given dimensions via `doc.create.table`."""
        from docx.table import Table

        self._ensure_open()
        self._reset_list_chain()
        if rows < 1 or cols < 1:
            raise ValidationError(
                f"rows and cols must be >= 1; got rows={rows} cols={cols}",
            )

        # The real param is `columns` (not `cols`). `at` is required to
        # position the table; we always append to document end. The
        # client-side UUID lets the create + (optional) set_style ship
        # in one HTTP batch — the applier rewrites the UUID to the real
        # SuperDoc id via per-batch ``clientIdMap``, so any subsequent
        # ``set_style({nodeId: cli_id})`` resolves correctly server-side.
        client_node_id = self._mint_client_node_id("t")
        table_params: dict = {
            "rows": rows,
            "columns": cols,
            "at": {"kind": "documentEnd"},
            "client_node_id": client_node_id,
        }
        run_sync(self._session.doc.create.table(table_params))
        node_id: str = client_node_id

        if style:
            from docx.styles.style import BaseStyle

            style_id = style.style_id if isinstance(style, BaseStyle) else str(style)
            run_sync(
                self._session.doc.tables.set_style(
                    {"nodeId": node_id, "styleId": style_id},
                ),
            )

        tbl = Table(session=self._session, node_id=node_id)
        self._register_proxy_id(client_node_id, tbl)
        return tbl

    def add_picture(
        self,
        image_path_or_stream: str | BinaryIO,
        width: "int | Length | None" = None,
        height: "int | Length | None" = None,
    ) -> "InlineShape":
        """Append an inline image via ``doc.create.image``.

        Mirrors python-docx ``Document.add_picture`` — returns the new
        :class:`InlineShape` proxy.
        """
        from docx._image_utils import sniff_content_type
        from docx.shape import InlineShape
        from docx.text.run import _build_inline_shape_info

        self._ensure_open()
        self._reset_list_chain()

        image_bytes: bytes
        fallback_path: str = ""
        if isinstance(image_path_or_stream, str):
            with open(image_path_or_stream, "rb") as f:
                image_bytes = f.read()
            fallback_path = image_path_or_stream
        elif isinstance(image_path_or_stream, io.IOBase):
            image_bytes = image_path_or_stream.read()
        else:
            raise TypeError(
                "Expected path str or binary stream, "
                f"got {type(image_path_or_stream).__name__}",
            )
        # An empty payload (closed file, empty BytesIO, truncated stream
        # that's already been read to EOF) would silently produce a
        # ``data:image/png;base64,`` URI — SuperDoc accepts that and
        # creates an image with no payload, which renders as a broken
        # placeholder. Fail loudly instead so callers learn at the
        # call site rather than at render time.
        if not image_bytes:
            raise ValueError(
                "Cannot add_picture from empty bytes — the file at "
                f"{image_path_or_stream!r} was empty or the stream was "
                "exhausted before .add_picture was called. Pass a fresh "
                "stream or a non-empty file path."
            )
        # Magic-byte sniff first (catches mistyped extensions and bytes
        # streams without filenames); extension is the fallback only
        # for unknown/off-format payloads. Mirrors python-docx's
        # Pillow-based detection without requiring Pillow.
        content_type: str = sniff_content_type(
            image_bytes, fallback_path=fallback_path
        )

        b64: str = base64.b64encode(image_bytes).decode("ascii")
        data_uri: str = f"data:{content_type};base64,{b64}"

        w_px: float = _emu_to_px(width) if width is not None else 576.0
        h_px: float = _emu_to_px(height) if height is not None else 432.0

        # Pre-mint the client-side UUID so the create can buffer and
        # the InlineShape proxy hands the caller a stable id without
        # waiting for the server response.
        client_node_id = self._mint_client_node_id("img")
        image_params: dict = {
            "src": data_uri,
            "size": {"width": w_px, "height": h_px},
            "at": {"kind": "documentEnd"},
            "client_node_id": client_node_id,
        }
        result: object = run_sync(self._session.doc.create.image(image_params))
        # InlineShape stores its id under ``_info["nodeId"]`` rather than
        # a top-level ``_node_id`` attribute, so route the flush-time
        # rewrite through a small setattr-adapter wrapper.
        info = _build_inline_shape_info(result, width=w_px, height=h_px)
        info["nodeId"] = client_node_id
        shape = InlineShape(session=self._session, info=info)
        buffer = self._buffer()
        if buffer is not None:
            buffer.register_proxy_id_ref(
                client_node_id,
                _InlineShapeIdAdapter(shape),
                attr="node_id",
            )
        return shape

    def add_section(self, start_type: "WD_SECTION_START" = WD_SECTION_START.NEW_PAGE):  # type: ignore[name-defined]
        """Append a new section and return its Section proxy.

        Mirrors python-docx: creating a section adds a trailing empty
        paragraph that marks the section boundary.

        Raises ``ValueError`` if ``start_type`` is a string that doesn't
        match a :class:`WD_SECTION_START` member value. python-docx
        upstream coerces ``start_type`` through the enum and raises
        ``ValueError`` on garbage; previously this SDK passed the raw
        string through to SuperDoc which silently accepted any value
        and produced a section break with an unknown ``breakType``.
        """

        self._ensure_open()
        # python-docx always inserts an anchor paragraph at the section break
        self.add_paragraph("")
        break_type: str = "nextPage"
        if start_type is not None:
            if isinstance(start_type, WD_SECTION_START):
                break_type = start_type.to_superdoc()
            elif isinstance(start_type, str):
                # python-docx coerces strings through the enum, raising
                # ``ValueError`` for non-member values. Mirror that here
                # instead of letting arbitrary strings flow to SuperDoc,
                # where the applier accepts any string and produces a
                # section break with an unknown ``breakType``.
                try:
                    break_type = WD_SECTION_START(start_type).to_superdoc()
                except (ValueError, TypeError) as exc:
                    raise ValueError(
                        f"{start_type!r} is not a valid WD_SECTION_START"
                    ) from exc
            else:
                raise ValueError(
                    f"{start_type!r} is not a valid WD_SECTION_START"
                )
        run_sync(
            self._session.doc.create.section_break(
                {"at": {"kind": "documentEnd"}, "breakType": break_type},
            ),
        )
        info: object = run_sync(self._session.doc.sections.list({}))
        items: list = []
        if isinstance(info, dict):
            items_obj = info.get("items", [])
            if isinstance(items_obj, list):
                items = items_obj
        if not items:
            raise RuntimeError(
                "Superdoc did not return any sections after add_section",
            )
        last = items[-1]
        addr = last.get("address", {}) if isinstance(last, dict) else {}
        return Section(session=self._session, address=addr if isinstance(addr, dict) else {})

    def add_page_break(self) -> None:
        """Append a page break at the end of the document.

        python-docx appends an empty paragraph with a page-break run inside;
        `doc.paragraphs` includes that new paragraph. We mirror by adding
        an anchor paragraph first, then the section break.
        """
        self._ensure_open()
        # Anchor paragraph so doc.paragraphs reflects the break visually.
        self.add_paragraph("")
        run_sync(
            self._session.doc.create.section_break(
                {"at": {"kind": "documentEnd"}, "breakType": "nextPage"},
            ),
        )

    # ---- Lifecycle ----

    def _flush(self) -> None:
        """Internal: drain pending mutations to Keryx without requiring
        a path (used by ``__exit__`` and lifecycle teardown)."""
        self._ensure_open()
        run_sync(self._session.save(in_place=True))
        self._saved = True

    def save(self, path_or_stream: "str | BinaryIO | None" = None) -> None:
        """Flush pending edits to Keryx.

        Intentional deviation from python-docx: ``path_or_stream`` is
        optional. Stock python-docx requires it and raises ``TypeError``
        on ``save()`` no-arg, but in this asset-backed SDK there is no
        local file to write to — writes are always in-place against the
        Y.Doc. Agent-generated code reflexively calls ``doc.save()`` and
        forcing the upstream signature broke every such invocation
        (`Untitled Word Document` session
        ``thread_3f6b59e0-ae25-4f6e-8391-c286b17a3334``). The argument
        is accepted for parity-friendly call sites but ignored at
        runtime. To export to a local file, use the Olympus UI's
        Export DOCX.

        When ``path_or_stream`` is non-None, an
        :class:`IgnoredSaveTargetWarning` is emitted so the silent gap
        is visible to callers. The flush still happens — the call does
        not raise — but the user-supplied path/stream is not written
        to. Previously a caller passing a string path got a fully
        silent success and no file on disk.
        """
        if path_or_stream is not None:
            warnings.warn(
                "Document.save(path_or_stream=...) ignores its argument — "
                "athena-python-docx is asset-backed and cannot write to a "
                "local file or stream. The flush completed in-place against "
                "the Y.Doc; no bytes were written to "
                f"{path_or_stream!r}. To export, use Olympus's Export DOCX.",
                IgnoredSaveTargetWarning,
                stacklevel=2,
            )
        self._flush()

    def close(self) -> None:
        """Close the session. Not strictly needed (context-managed)."""
        if self._closed:
            return
        try:
            run_sync(self._session.close())
        finally:
            self._closed = True

    def __enter__(self) -> "Document":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # noqa: ANN001
        if exc_type is None and not self._saved and self._session.is_open:
            try:
                # Drain via _flush() directly — save() works no-arg as
                # an intentional deviation, but skipping it avoids the
                # public-API hop on the autosave path.
                self._flush()
            except Exception as e:
                _log_warn(f"autosave failed for {self._session.asset_id}: {e}")
        self.close()

    # ---- Internals ----

    def _ensure_open(self) -> None:
        if self._closed:
            raise DocumentClosedError(
                f"Document {self._session.asset_id} is closed.",
            )
        if not self._session.is_open:
            run_sync(self._session.open())
            # Propagate pending track-changes state to the freshly-built
            # buffer. Done here (and not at construction) because the
            # buffer doesn't exist until session.open() runs.
            self._sync_track_changes_state()

    def _buffer(self):
        """Return the live :class:`CommandBuffer`, or ``None`` if the
        session hasn't been opened yet."""
        handle = getattr(self._session, "_doc_handle", None)
        return getattr(handle, "buffer", None) if handle is not None else None

    def _mint_client_node_id(self, prefix: str) -> str:
        """Generate a fresh client-side UUID for a new node.

        Returns ``f"{prefix}_<hex12>"``. ``prefix`` is a short type tag
        (``"p"`` for paragraph, ``"h"`` for heading, ``"t"`` for table,
        ``"img"`` for image, ``"c"`` for comment) — purely cosmetic,
        used for debugging / log inspection. The applier doesn't parse
        it.

        The SDK uses this UUID as the new Paragraph/Heading/Table/Image
        proxy's ``_node_id`` so user code can keep editing the proxy
        before the buffer flushes. On flush, the applier resolves the
        UUID to the real SuperDoc id via ``clientIdMap`` and the buffer
        rewrites the proxy's ``_node_id`` in-place.
        """
        import uuid

        return f"{prefix}_{uuid.uuid4().hex[:12]}"

    def _register_proxy_id(self, client_id: str, proxy: object) -> None:
        """Register ``proxy._node_id`` for flush-time rewrite.

        After the buffer flushes, it walks per-cmd results for the
        matching ``real_node_id`` echo and ``setattr(proxy, "_node_id",
        real)`` so subsequent ops on the same proxy use the real id. See
        :meth:`docx._buffer.CommandBuffer.register_proxy_id_ref`.
        """
        buffer = self._buffer()
        if buffer is not None:
            buffer.register_proxy_id_ref(client_id, proxy, "_node_id")

    def _sync_track_changes_state(self) -> None:
        """Push pending track-changes state into the buffer.

        Called when the session is opened (deferred init) and on
        subsequent property setters. Idempotent — applying twice with
        the same values is cheap (the buffer skips the flush when the
        value didn't change).
        """
        buffer = self._buffer()
        if buffer is None:
            return
        if self._pending_user_name is not None or self._pending_user_email is not None:
            buffer.set_user(
                self._pending_user_name,
                self._pending_user_email,
            )
        buffer.set_change_mode(
            "tracked" if self._pending_track_revisions else None
        )


# ---- Module-level helpers ----

def _extract_inserted_node_id(result: dict, *, expected_type: str) -> str:
    """Parse Superdoc create/insert response to find the new node's blockId.

    Real observed shapes (superdoc-sdk 1.6.0.dev29):

      doc.create.paragraph/heading/table returns
          {"success": True, "<paragraph|heading|table>": {"nodeId": "..."}}

      doc.insert (markdown/text) returns
          {"receipt": {"resolution": {"target": {"blockId": "..."}}}, ...}

    We probe create-shape first (nested by expected_type), then insert-shape.
    Returns "" if nothing matches.
    """
    if not isinstance(result, dict):
        return ""

    # Shape 1 — doc.create.paragraph/heading/table/image: top-level key
    # named by the result type holds `{kind, nodeType, nodeId}`.
    for key in (expected_type, "paragraph", "heading", "table", "image"):
        obj = result.get(key)
        if isinstance(obj, dict):
            node_id = obj.get("nodeId")
            if isinstance(node_id, str) and node_id:
                return node_id

    # Shape 2 — doc.insert: receipt.resolution.target.blockId.
    receipt: object = result.get("receipt")
    if isinstance(receipt, dict):
        resolution: object = receipt.get("resolution")
        if isinstance(resolution, dict):
            target: object = resolution.get("target")
            if isinstance(target, dict):
                block_id: str = str(target.get("blockId", ""))
                if block_id:
                    return block_id

    # Shape 3 — top-level blockId or target.blockId.
    top_block: object = result.get("blockId")
    if isinstance(top_block, str) and top_block:
        return top_block
    top_target: object = result.get("target")
    if isinstance(top_target, dict):
        tb: str = str(top_target.get("blockId", ""))
        if tb:
            return tb

    # Shape 4 (legacy): nested result.result.insertedNodes[] / nodes[].
    data_obj: object = result.get("result", {})
    data: dict = data_obj if isinstance(data_obj, dict) else {}
    nodes_obj: object = data.get("insertedNodes", data.get("nodes", []))
    nodes: list = nodes_obj if isinstance(nodes_obj, list) else []
    for node in nodes:
        if not isinstance(node, dict):
            continue
        if node.get("type") == expected_type:
            return str(node.get("nodeId", ""))
    if nodes and isinstance(nodes[-1], dict):
        return str(nodes[-1].get("nodeId", ""))

    return ""


def _emu_to_px(emu: object) -> float:
    """EMU → px at 96 DPI. 914400 EMU = 1 inch.

    Accepts Emu/Inches/Pt subclasses (all of which are int) or plain int.
    """
    val: float = float(emu) if not hasattr(emu, "emu") else float(emu.emu)  # type: ignore[union-attr]
    return val / 914400.0 * 96.0
