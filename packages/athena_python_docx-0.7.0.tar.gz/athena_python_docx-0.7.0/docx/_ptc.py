"""Programmatic Tool Calling (PTC) — client side.

Activated only when ``ATHENA_PTC_URL`` is set. The URL is a presigned
endpoint URL with an HMAC-signed token embedded as ``?t=…``; the token
carries the (thread, parent_tool_call_id, run) triple and an expiry.
The SDK doesn't need to know that triple — it just POSTs to the URL
verbatim, and the server derives identity from the token.

Without ``ATHENA_PTC_URL`` set, every call here is a no-op.

Emits are fire-and-forget on a background daemon thread:

- Never raise into user code.
- Never block the calling thread.
- Re-read ``ATHENA_PTC_URL`` on every emit so updates between sandbox
  executions take effect immediately (the SDK module itself is cached
  across runs).
- Snapshot the URL at ``emit_begin`` time and carry it to ``emit_end``
  so late end events can't be misattributed if a new sandbox run
  swapped in a different URL between begin and end.

This module is *intentionally byte-identical* across the docx / pptx /
xlsx SDKs — the three SDKs have no shared base. Duplicating ~100 LOC
of stdlib code is cheaper than spinning up a 4th release pipeline.
"""

from __future__ import annotations

import json
import os
import queue
import threading
import time
import urllib.error
import urllib.request
import uuid
from typing import Any

_MAX_QUEUE = 4096
_MAX_BODY = 64 * 1024
_HTTP_TIMEOUT = 2.0

# Singleton state. PTC has exactly one outbox per process.
_outbox: queue.Queue[tuple[str, dict[str, Any]]] = queue.Queue(maxsize=_MAX_QUEUE)
_thread_lock = threading.Lock()
_thread_started = False
# call_id -> URL snapshot at begin time; lets emit_end target the
# original run's endpoint even if ATHENA_PTC_URL changed since.
_call_url: dict[str, str] = {}


def _drain() -> None:
    while True:
        item = _outbox.get()
        if item is None:
            return
        url, body = item
        try:
            raw = json.dumps(body).encode("utf-8")
            if len(raw) > _MAX_BODY:
                key = "args" if body.get("phase") == "begin" else "result"
                body[key] = {"__truncated__": True}
                raw = json.dumps(body).encode("utf-8")
            req = urllib.request.Request(
                url,
                data=raw,
                method="POST",
                headers={"Content-Type": "application/json"},
            )
            urllib.request.urlopen(req, timeout=_HTTP_TIMEOUT).close()
        except (urllib.error.URLError, OSError, ValueError):
            pass  # never propagate


def _ensure_thread() -> None:
    global _thread_started
    if _thread_started:
        return
    with _thread_lock:
        if _thread_started:
            return
        threading.Thread(target=_drain, name="athena-ptc", daemon=True).start()
        _thread_started = True


def _send(url: str, body: dict[str, Any]) -> None:
    _ensure_thread()
    try:
        _outbox.put_nowait((url, body))
    except queue.Full:
        pass  # drop on backpressure; never block user code


def emit_begin(
    tool_name: str,
    args: dict[str, Any],
    *,
    asset_id: str | None = None,
) -> str:
    call_id = uuid.uuid4().hex
    url = os.environ.get("ATHENA_PTC_URL")
    if not url:
        return call_id
    _call_url[call_id] = url
    body: dict[str, Any] = {
        "callId": call_id,
        "toolName": tool_name,
        "phase": "begin",
        "args": args,
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime()),
    }
    if asset_id is not None:
        body["assetId"] = asset_id
    _send(url, body)
    return call_id


def emit_end(
    *,
    call_id: str,
    tool_name: str,
    result: dict[str, Any] | None,
    is_error: bool,
) -> None:
    url = _call_url.pop(call_id, None)
    if url is None:
        return  # PTC was disabled at begin, or begin wasn't emitted
    _send(
        url,
        {
            "callId": call_id,
            "toolName": tool_name,
            "phase": "end",
            "result": result,
            "isError": is_error,
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime()),
        },
    )
