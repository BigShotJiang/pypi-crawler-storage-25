"""Section — python-docx docx.section.Section parity.

Sections expose page geometry (size, margins, orientation), header/footer
references, and the start break type. Values are read from and persisted
to Superdoc via `doc.sections.*` ops.

Length values are stored in EMU in python-docx; we accept Length/Emu/Pt
instances for setters and round-trip via Superdoc (which takes point
or twip values depending on the op).
"""

from __future__ import annotations

import warnings
from collections.abc import Sequence
from typing import TYPE_CHECKING

from docx._batching import run_sync
from docx.shared import Length, Pt

if TYPE_CHECKING:
    from docx.client import Session
    from docx.enum.section import WD_ORIENTATION, WD_SECTION_START
    from docx.styles.style import ParagraphStyle
    from docx.table import Table
    from docx.text.paragraph import Paragraph


class PendingHeaderFooterTableWidthWarning(UserWarning):
    """Emitted when ``_HeaderFooter.add_table`` is called with a non-default
    width. SuperDoc doesn't propagate the width to the slot-level
    table — width is inherited from layout. Tracked in
    ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 3."""


class PendingHeaderFooterReadWarning(UserWarning):
    """Emitted when ``_HeaderFooter.paragraphs`` / ``.tables`` /
    ``.iter_inner_content`` is accessed.

    SuperDoc 1.8.1's ``blocks.list`` doesn't accept the
    ``in: {storyType: "headerFooterSlot", ...}`` parameter, so block-
    level enumeration of header/footer content isn't possible. Reads
    return empty collections. Tracked in
    ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 3."""


def _warn_hf_width(rows: int, cols: int) -> None:
    warnings.warn(
        f"_HeaderFooter.add_table(rows={rows}, cols={cols}, width=...) "
        f"silently discarded the `width` argument. SuperDoc takes "
        f"header/footer-table width from layout; per-cell width via "
        f"Table.width is not propagated either. Tracked in "
        f"docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md § 3.",
        PendingHeaderFooterTableWidthWarning,
        stacklevel=3,
    )


def _warn_hf_read(prop: str) -> None:
    warnings.warn(
        f"_HeaderFooter.{prop} returns an empty collection — SuperDoc "
        f"1.8.1 has no blocks.list({{in: {{storyType: 'headerFooterSlot'}}}}) "
        f"op. Reads will appear empty even when the header/footer "
        f"contains content. Tracked in "
        f"docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md § 3.",
        PendingHeaderFooterReadWarning,
        stacklevel=3,
    )


def _emu_from(value: object) -> int:
    """Coerce a length input to EMU."""
    if value is None:
        return 0
    if isinstance(value, Length):
        return int(value)
    if isinstance(value, (int, float)):
        return int(value)
    raise TypeError(f"Cannot convert {type(value).__name__} to EMU")


def _emu_to_pt(emu: int) -> float:
    return emu / 12700.0


def _reject_none_dimension(prop: str, value: object) -> None:
    """Raise ``TypeError`` if ``value`` is None for a dimension setter
    that python-docx 1.2.0 doesn't accept None for.

    Upstream ``Section.page_width = None`` (and every margin /
    header_distance / footer_distance / gutter setter) routes through
    ``Emu(value).twips`` which raises ``TypeError`` on ``None``. Our
    setters previously early-returned silently, swallowing the
    intent. Raise to match upstream behavior — callers who actually
    want a clear must pass ``Inches(0)`` (or similar) explicitly.
    """
    if value is None:
        raise TypeError(
            f"Section.{prop} = None is not supported. python-docx "
            f"1.2.0 raises TypeError here too — its Emu(None).twips "
            f"fails with the same shape. Pass an explicit Length "
            f"(e.g. Inches(0)) if you want to zero the dimension."
        )


class PendingSectionOnOffClearWarning(UserWarning):
    """Emitted when ``Section.different_first_page_header_footer = None``.

    python-docx 1.x semantics: ``None`` clears the OOXML
    ``<w:titlePg/>`` element back to inherited. SuperDoc 1.8's
    ``sections.set_title_page`` only accepts ``enabled: bool`` — the
    wire can't represent the clear-intent. The warning surfaces
    silent-divergence. Tracked in
    ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md``.
    """


def _warn_section_onoff_clear(prop: str) -> None:
    warnings.warn(
        f"Section.{prop} = None was IGNORED — SuperDoc 1.8 has no "
        f"clear-op for this OnOff property. The section keeps its "
        f"previous value. Tracked in "
        f"docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md.",
        PendingSectionOnOffClearWarning,
        stacklevel=3,
    )


def _require_section_bool(prop: str, value: object) -> bool:
    """Reject non-bool input on Section OnOff setters.

    python-docx 1.x's ``_OnOff`` typed-attribute setter raises
    ``ValueError`` for non-bool input. Our previous ``bool(value)``
    coercion silently turned ``"yes"`` / ``1`` / ``[]`` into True/False
    without surfacing the type mismatch.
    """
    if not isinstance(value, bool):
        raise TypeError(
            f"Section.{prop} requires bool or None; got "
            f"{type(value).__name__} {value!r}. python-docx 1.x's "
            f"``_OnOff`` setter rejects truthy non-bool here too.",
        )
    return value


class Section:
    """A document section — page size, margins, headers/footers, break type."""

    def __init__(self, *, session: "Session", address: dict) -> None:
        self._session: "Session" = session
        self._address: dict = address

    # ---- snapshot helpers ----
    def _fetch(self) -> dict:
        info: object = run_sync(
            self._session.doc.sections.get({"target": self._address}),
        )
        return info if isinstance(info, dict) else {}

    def _set_margins(self, **kwargs: float) -> None:
        run_sync(
            self._session.doc.sections.set_page_margins(
                {"target": self._address, **kwargs},
            ),
        )

    def _set_page_setup(self, **kwargs: object) -> None:
        run_sync(
            self._session.doc.sections.set_page_setup(
                {"target": self._address, **kwargs},
            ),
        )

    # ---- page size ----
    @property
    def page_width(self) -> "Length | None":
        data = self._fetch()
        ps = data.get("pageSetup", {}) if isinstance(data, dict) else {}
        w = ps.get("width") if isinstance(ps, dict) else None
        if isinstance(w, (int, float)):
            # returned in pt
            return Pt(float(w))
        return None

    @page_width.setter
    def page_width(self, value: "Length | int | None") -> None:
        _reject_none_dimension("page_width", value)
        pt = _emu_to_pt(_emu_from(value))
        self._set_page_setup(width=pt)

    @property
    def page_height(self) -> "Length | None":
        data = self._fetch()
        ps = data.get("pageSetup", {}) if isinstance(data, dict) else {}
        h = ps.get("height") if isinstance(ps, dict) else None
        if isinstance(h, (int, float)):
            return Pt(float(h))
        return None

    @page_height.setter
    def page_height(self, value: "Length | int | None") -> None:
        _reject_none_dimension("page_height", value)
        pt = _emu_to_pt(_emu_from(value))
        self._set_page_setup(height=pt)

    @property
    def orientation(self) -> "WD_ORIENTATION | None":
        from docx.enum.section import WD_ORIENTATION

        data = self._fetch()
        ps = data.get("pageSetup", {}) if isinstance(data, dict) else {}
        o = ps.get("orientation") if isinstance(ps, dict) else None
        if isinstance(o, str):
            try:
                return WD_ORIENTATION(o)
            except ValueError:
                return None
        return None

    @orientation.setter
    def orientation(self, value: "WD_ORIENTATION | str | None") -> None:
        from docx.enum.section import WD_ORIENTATION

        # python-docx 1.2.0 behavior: ``None`` falls through to PORTRAIT
        # (``pgSz.orient = value if value else WD_ORIENTATION.PORTRAIT``).
        # Previously this setter silently no-oped on ``None``, dropping
        # the upstream-mandated fallback.
        if value is None:
            v = WD_ORIENTATION.PORTRAIT.to_superdoc()
        elif isinstance(value, WD_ORIENTATION):
            v = value.to_superdoc()
        else:
            # python-docx raises ``ValueError`` for non-enum, non-None
            # input via the enum coercion on the underlying lxml setter
            # (``pgSz.orient = value`` → enum validation). Mirror that
            # behavior instead of letting an arbitrary string flow to
            # SuperDoc, where the applier punts strict types via
            # ``AnyDoc`` and silently accepts garbage.
            try:
                v = WD_ORIENTATION(value).to_superdoc()
            except (ValueError, TypeError) as exc:
                raise ValueError(
                    f"{value!r} is not a valid WD_ORIENTATION"
                ) from exc
        self._set_page_setup(orientation=v)

    # ---- margins ----
    def _margin(self, key: str) -> "Length | None":
        data = self._fetch()
        m = data.get("margins", {}) if isinstance(data, dict) else {}
        v = m.get(key) if isinstance(m, dict) else None
        if isinstance(v, (int, float)):
            return Pt(float(v))
        return None

    @property
    def left_margin(self) -> "Length | None":
        return self._margin("left")

    @left_margin.setter
    def left_margin(self, value: "Length | int | None") -> None:
        _reject_none_dimension("left_margin", value)
        self._set_margins(left=_emu_to_pt(_emu_from(value)))

    @property
    def right_margin(self) -> "Length | None":
        return self._margin("right")

    @right_margin.setter
    def right_margin(self, value: "Length | int | None") -> None:
        _reject_none_dimension("right_margin", value)
        self._set_margins(right=_emu_to_pt(_emu_from(value)))

    @property
    def top_margin(self) -> "Length | None":
        return self._margin("top")

    @top_margin.setter
    def top_margin(self, value: "Length | int | None") -> None:
        _reject_none_dimension("top_margin", value)
        self._set_margins(top=_emu_to_pt(_emu_from(value)))

    @property
    def bottom_margin(self) -> "Length | None":
        return self._margin("bottom")

    @bottom_margin.setter
    def bottom_margin(self, value: "Length | int | None") -> None:
        _reject_none_dimension("bottom_margin", value)
        self._set_margins(bottom=_emu_to_pt(_emu_from(value)))

    @property
    def gutter(self) -> "Length | None":
        return self._margin("gutter")

    @gutter.setter
    def gutter(self, value: "Length | int | None") -> None:
        _reject_none_dimension("gutter", value)
        self._set_margins(gutter=_emu_to_pt(_emu_from(value)))

    @property
    def header_distance(self) -> "Length | None":
        data = self._fetch()
        hfm = data.get("headerFooterMargins", {}) if isinstance(data, dict) else {}
        v = hfm.get("header") if isinstance(hfm, dict) else None
        if isinstance(v, (int, float)):
            return Pt(float(v))
        return None

    @header_distance.setter
    def header_distance(self, value: "Length | int | None") -> None:
        _reject_none_dimension("header_distance", value)
        run_sync(
            self._session.doc.sections.set_header_footer_margins(
                {"target": self._address, "header": _emu_to_pt(_emu_from(value))},
            ),
        )

    @property
    def footer_distance(self) -> "Length | None":
        data = self._fetch()
        hfm = data.get("headerFooterMargins", {}) if isinstance(data, dict) else {}
        v = hfm.get("footer") if isinstance(hfm, dict) else None
        if isinstance(v, (int, float)):
            return Pt(float(v))
        return None

    @footer_distance.setter
    def footer_distance(self, value: "Length | int | None") -> None:
        _reject_none_dimension("footer_distance", value)
        run_sync(
            self._session.doc.sections.set_header_footer_margins(
                {"target": self._address, "footer": _emu_to_pt(_emu_from(value))},
            ),
        )

    # ---- break type ----
    @property
    def start_type(self) -> "WD_SECTION_START | None":
        from docx.enum.section import WD_SECTION_START

        data = self._fetch()
        bt = data.get("breakType") if isinstance(data, dict) else None
        if not isinstance(bt, str):
            return None
        for member in WD_SECTION_START:
            if member.to_superdoc() == bt:
                return member
        return None

    @start_type.setter
    def start_type(self, value: "WD_SECTION_START | str | None") -> None:
        from docx.enum.section import WD_SECTION_START

        # python-docx 1.2.0 behavior: ``None`` and ``WD_SECTION_START.NEW_PAGE``
        # both reset to the default (``self._remove_type()``); any other
        # value is coerced through the enum (which raises ``ValueError``
        # for unknown strings/ints). Mirror both branches — previously
        # this setter accepted *any* string and shipped it raw to
        # SuperDoc, where ``AnyDoc`` punting meant garbage went through
        # silently.
        if value is None or value is WD_SECTION_START.NEW_PAGE:
            v = WD_SECTION_START.NEW_PAGE.to_superdoc()
        elif isinstance(value, WD_SECTION_START):
            v = value.to_superdoc()
        else:
            try:
                v = WD_SECTION_START(value).to_superdoc()
            except (ValueError, TypeError) as exc:
                raise ValueError(
                    f"{value!r} is not a valid WD_SECTION_START"
                ) from exc
        run_sync(
            self._session.doc.sections.set_break_type(
                {"target": self._address, "breakType": v},
            ),
        )

    # ---- header/footer presence flags ----
    @property
    def different_first_page_header_footer(self) -> bool | None:
        data = self._fetch()
        v = data.get("titlePage") if isinstance(data, dict) else None
        return bool(v) if isinstance(v, bool) else None

    @different_first_page_header_footer.setter
    def different_first_page_header_footer(self, value: bool | None) -> None:
        if value is None:
            _warn_section_onoff_clear("different_first_page_header_footer")
            return
        enabled = _require_section_bool(
            "different_first_page_header_footer", value
        )
        run_sync(
            self._session.doc.sections.set_title_page(
                # SuperDoc's wire field is ``enabled`` (DocSectionsSet
                # TitlePageParams). The earlier ``titlePage`` name was
                # rejected silently because the apps/api applier punts
                # SuperDoc's strict types via ``AnyDoc``.
                {"target": self._address, "enabled": enabled},
            ),
        )

    # python-docx also exposes .header and .footer but those return
    # Header/Footer objects with paragraphs. We return read-only stubs
    # to allow attribute access without AttributeError.
    @property
    def header(self) -> "_HeaderFooter":
        return _HeaderFooter(section=self, kind="header")

    @property
    def footer(self) -> "_HeaderFooter":
        return _HeaderFooter(section=self, kind="footer")

    @property
    def first_page_header(self) -> "_HeaderFooter":
        return _HeaderFooter(section=self, kind="header", first_page=True)

    @property
    def first_page_footer(self) -> "_HeaderFooter":
        return _HeaderFooter(section=self, kind="footer", first_page=True)

    @property
    def even_page_header(self) -> "_HeaderFooter":
        return _HeaderFooter(section=self, kind="header", even_page=True)

    @property
    def even_page_footer(self) -> "_HeaderFooter":
        return _HeaderFooter(section=self, kind="footer", even_page=True)

    def iter_inner_content(self):
        """Yield each top-level Paragraph or Table that falls inside this
        section's content range, in document order.

        Mirrors python-docx 1.x ``Section.iter_inner_content``. SuperDoc's
        ``sections.list`` response carries each section's
        ``range: {startParagraphIndex, endParagraphIndex}``. We pull the
        full block list (paragraphs + headings + tables) and slice by
        that index range. ``endParagraphIndex`` is exclusive.

        If the server doesn't return a range for our address (e.g.
        single-section docs where the index is implicit), we fall back
        to yielding every block — same as ``Document.iter_inner_content``.
        """
        from docx.table import Table
        from docx.text.paragraph import Paragraph

        # Find this section's range in the section list.
        listing: object = run_sync(self._session.doc.sections.list({}))
        start = 0
        end: int | None = None
        if isinstance(listing, dict):
            items = listing.get("items") or []
            if isinstance(items, list):
                for item in items:
                    if not isinstance(item, dict):
                        continue
                    addr = item.get("address") or {}
                    if not isinstance(addr, dict):
                        continue
                    if (
                        addr.get("sectionId") == self._address.get("sectionId")
                        or addr == self._address
                    ):
                        rng = item.get("range") or {}
                        if isinstance(rng, dict):
                            start = int(rng.get("startParagraphIndex", 0) or 0)
                            raw_end = rng.get("endParagraphIndex")
                            # 0 (or unset) means "no upper bound" — single-
                            # section docs and SuperDoc's `0` sentinel both
                            # land here, so we treat them identically.
                            end = (
                                int(raw_end)
                                if isinstance(raw_end, int) and raw_end > 0
                                else None
                            )
                        break

        # Walk the unified block list and slice by index. Paragraph
        # indices count both paragraphs and tables in document order
        # (matches how SuperDoc's blocks.list orders them).
        raw: object = run_sync(
            self._session.doc.blocks.list(
                {
                    "nodeTypes": ["paragraph", "heading", "table"],
                    "includeText": False,
                },
            ),
        )
        blocks: list = []
        if isinstance(raw, dict):
            obj = raw.get("blocks", [])
            if isinstance(obj, list):
                blocks = obj
        elif isinstance(raw, list):
            blocks = raw

        for i, block in enumerate(blocks):
            if not isinstance(block, dict):
                continue
            if i < start:
                continue
            if end is not None and i >= end:
                break
            node_id = str(block.get("nodeId", ""))
            if not node_id:
                continue
            nt = block.get("nodeType")
            if nt == "table":
                yield Table(session=self._session, node_id=node_id)
            else:
                yield Paragraph(
                    session=self._session,
                    node_id=node_id,
                    node_type=nt if isinstance(nt, str) else "paragraph",
                )


class _HeaderFooter:
    """Header/Footer base proxy. Mirrors python-docx's
    :class:`docx.section._Header` / :class:`docx.section._Footer`
    surface: ``is_linked_to_previous`` (read/write),
    ``add_paragraph`` / ``add_table`` (writes target the slot via
    SuperDoc's ``in: {storyType: "headerFooterSlot", …}`` parameter),
    ``paragraphs`` / ``tables`` (best-effort reads; see SuperDoc 1.8
    constraint note below), and ``iter_inner_content``.

    **Read-side note**: SuperDoc 1.8 doesn't expose a list-blocks-by-
    story op (``blocks.list`` has no ``in`` parameter), so block-level
    enumeration of header/footer content isn't supported yet. The
    ``paragraphs`` / ``tables`` properties return empty lists.
    Iteration parity (``for p in header.paragraphs: …`` doesn't
    raise) is preserved.
    """

    def __init__(
        self,
        *,
        section: Section,
        kind: str,
        first_page: bool = False,
        even_page: bool = False,
    ) -> None:
        self._section: Section = section
        self._kind: str = kind
        self._first_page: bool = first_page
        self._even_page: bool = even_page

    @property
    def _variant_key(self) -> str:
        """athena-internal discriminator used by ``set_link_to_previous``.

        ``header`` / ``footer``  → default H/F.
        ``firstPageHeader`` / ``firstPageFooter`` → first-page variant.
        ``evenPageHeader`` / ``evenPageFooter`` → even-page variant.
        """
        if self._first_page:
            return f"firstPage{self._kind.capitalize()}"
        if self._even_page:
            return f"evenPage{self._kind.capitalize()}"
        return self._kind

    @property
    def _superdoc_variant(self) -> str:
        """SuperDoc-side variant string ("default" | "first" | "even")."""
        if self._first_page:
            return "first"
        if self._even_page:
            return "even"
        return "default"

    @property
    def _section_locator(self) -> dict:
        """Build the ``{kind: section, sectionId}`` locator SuperDoc
        expects for header/footer ops."""
        addr = self._section._address
        section_id = (
            addr.get("sectionId") or addr.get("id") or ""
            if isinstance(addr, dict)
            else ""
        )
        return {"kind": "section", "sectionId": str(section_id)}

    def _slot_target(self) -> dict:
        """Build the SuperDoc ``headerFooterSlot`` target."""
        return {
            "kind": "headerFooterSlot",
            "section": self._section_locator,
            "headerFooterKind": self._kind,
            "variant": self._superdoc_variant,
        }

    def _story_locator(self) -> dict:
        """Build the SuperDoc ``story`` locator for create.* ``in`` arg."""
        return {
            "kind": "story",
            "storyType": "headerFooterSlot",
            "section": self._section_locator,
            "headerFooterKind": self._kind,
            "variant": self._superdoc_variant,
        }

    # ---- linked-to-previous ----
    @property
    def is_linked_to_previous(self) -> bool:
        data = self._section._fetch()
        linked = data.get("linkedToPrevious", {}) if isinstance(data, dict) else {}
        if isinstance(linked, dict):
            return bool(linked.get(self._variant_key, True))
        return True

    @is_linked_to_previous.setter
    def is_linked_to_previous(self, value: bool) -> None:
        run_sync(
            self._section._session.doc.sections.set_link_to_previous(
                {
                    "target": self._section._address,
                    # SuperDoc splits the slot key into a flat
                    # ``kind`` (header|footer) + ``variant``
                    # (default|first|even). The previous code
                    # collapsed them into a single mangled
                    # ``firstPageHeader``-style string and used
                    # ``linkedToPrevious`` as the bool field — both
                    # of which SuperDoc rejected silently because
                    # the applier punts SuperDoc's strict types via
                    # ``AnyDoc``. So *every* first/even-page link
                    # call was a no-op until now.
                    "kind": self._kind,
                    "variant": self._superdoc_variant,
                    "linked": bool(value),
                },
            ),
        )
        # Also tell SuperDoc's headerFooters subsystem so the doc's
        # canonical slot ref stays consistent with section.linkedToPrevious.
        # SuperDoc rejects the parallel update with a state-conflict /
        # already-current error when the slot ref already matches the
        # requested value — that's fine, the section call above is the
        # authoritative path. Surface anything else (transport, auth,
        # server-side) so silent inconsistencies don't accumulate.
        try:
            run_sync(
                self._section._session.doc.header_footers.refs.set_linked_to_previous(
                    {"target": self._slot_target(), "linked": bool(value)},
                ),
            )
        except Exception as exc:
            msg = str(exc).lower()
            benign = (
                "already" in msg
                or "no-op" in msg
                or "no change" in msg
                or "matches current" in msg
            )
            if not benign:
                raise

    # ---- block container surface ----
    def add_paragraph(
        self,
        text: str = "",
        style: "str | ParagraphStyle | None" = None,
    ) -> "Paragraph":
        """Append a paragraph to this header/footer's slot.

        Mirrors python-docx ``_Header.add_paragraph`` /
        ``_Footer.add_paragraph``. Routes through
        ``doc.create.paragraph`` with an ``in:
        {storyType: "headerFooterSlot", …}`` story locator so SuperDoc
        materializes the paragraph in the right part.
        """
        from docx.styles.style import ParagraphStyle
        from docx.text.paragraph import Paragraph

        style_str: str | None
        if style is None:
            style_str = None
        elif isinstance(style, ParagraphStyle):
            style_str = style.style_id
        elif isinstance(style, str):
            style_str = style
        else:
            # python-docx 1.x's ``add_paragraph(style=...)`` accepts
            # ``str | ParagraphStyle | None`` and raises ``TypeError``
            # at the style-lookup layer for anything else. The
            # previous ``str(style)`` silently shipped garbage like
            # ``<MyStyle object at 0x...>`` as a style id, which
            # SuperDoc would swallow or reject without a clear signal.
            raise TypeError(
                f"_HeaderFooter.add_paragraph style requires str, "
                f"ParagraphStyle, or None; got "
                f"{type(style).__name__} {style!r}",
            )

        result: object = run_sync(
            self._section._session.doc.create.paragraph(
                {
                    "text": text,
                    "at": {"kind": "documentEnd"},
                    "in": self._story_locator(),
                },
            ),
        )
        node_id: str = ""
        if isinstance(result, dict):
            from docx.document import _extract_inserted_node_id

            node_id = _extract_inserted_node_id(result, expected_type="paragraph")
        para = Paragraph(
            session=self._section._session,
            node_id=node_id,
            node_type="paragraph",
        )
        if style_str:
            # Apply the requested paragraph style. We DON'T swallow
            # failures here — a style assignment that crashes (bad
            # styleId, transport error) leaves the caller with a
            # paragraph that doesn't have the style they asked for; the
            # right behavior is to bubble so they can see the failure.
            para.style = style_str
        return para

    def add_table(
        self,
        rows: int,
        cols: int,
        width: "Length",
    ) -> "Table":
        """Append a table to this header/footer's slot.

        Mirrors python-docx ``_Header.add_table`` — ``width`` is
        required (positional, no default). Passing ``None`` upstream
        raises ``TypeError`` inside ``CT_Tbl.new_tbl(rows, cols, None)``
        (the ``CT_TblW`` setter rejects None). We mirror that signal at
        the call site so the silent-no-op path the previous impl
        allowed (``width=None`` round-tripping cleanly with no warning)
        is no longer reachable.
        """
        from docx.document import _extract_inserted_node_id
        from docx.table import Table

        if width is None:
            raise TypeError(
                "_HeaderFooter.add_table(rows, cols, width) requires a "
                "non-None width — pass a Length (e.g. Inches(4) or "
                "Length(0) for unspecified). Mirrors python-docx 1.x "
                "where CT_Tbl.new_tbl rejects None at the type-coercion "
                "layer."
            )

        result: object = run_sync(
            self._section._session.doc.create.table(
                {
                    "rows": rows,
                    "columns": cols,
                    "at": {"kind": "documentEnd"},
                    "in": self._story_locator(),
                },
            ),
        )
        node_id = ""
        if isinstance(result, dict):
            node_id = _extract_inserted_node_id(result, expected_type="table")
        tbl = Table(session=self._section._session, node_id=node_id)
        # `width` is recorded for parity but not propagated — Word's
        # native unit is twips, and our Table.width setter would only
        # set the body table's width on the wire; header/footer parts
        # take width from layout. Warn when caller passes a meaningful
        # width so the lossy round-trip is visible.
        if int(width) > 0:
            _warn_hf_width(rows, cols)
        return tbl

    @property
    def paragraphs(self) -> list:
        """List of paragraphs in this header/footer.

        SuperDoc 1.8 doesn't expose a per-story block listing, so this
        currently returns an empty list. Iteration / membership checks
        still work; reads of header/footer body content require a
        SuperDoc upstream change. See ``SUPERDOC_UPSTREAM_REQUESTS.md`` § 3.
        """
        _warn_hf_read("paragraphs")
        return []

    @property
    def tables(self) -> list:
        """List of tables in this header/footer. See :attr:`paragraphs`
        for the SuperDoc 1.8 read-side limitation."""
        _warn_hf_read("tables")
        return []

    def iter_inner_content(self):
        """Yield each paragraph or table in the header/footer in order.

        Same SuperDoc 1.8 read-side limitation as :attr:`paragraphs`.
        """
        _warn_hf_read("iter_inner_content")
        return iter(())


# python-docx exposes two distinct classes; we model them as aliases
# of the same backing implementation since header / footer share the
# entire surface (only the ``kind`` discriminator differs and that's
# already passed at construction).
_Header = _HeaderFooter
_Footer = _HeaderFooter


class Sections(Sequence["Section"]):
    """Ordered collection of sections in a document.

    Subclasses :class:`collections.abc.Sequence` so ``count``,
    ``index``, ``__contains__``, and ``__reversed__`` come for free —
    this matches python-docx's :class:`docx.section.Sections`.
    """

    def __init__(self, *, session: "Session") -> None:
        self._session: "Session" = session

    def _items(self) -> list[dict]:
        info: object = run_sync(self._session.doc.sections.list({}))
        if isinstance(info, dict):
            items: object = info.get("items", [])
            if isinstance(items, list):
                return [i for i in items if isinstance(i, dict)]
        return []

    def __iter__(self):
        for item in self._items():
            addr = item.get("address", {})
            if isinstance(addr, dict):
                yield Section(session=self._session, address=addr)

    def __len__(self) -> int:
        return len(self._items())

    def __getitem__(self, index: int) -> Section:
        items = self._items()
        addr = items[index].get("address", {})
        if not isinstance(addr, dict):
            raise IndexError(f"Section {index} has no address")
        return Section(session=self._session, address=addr)
