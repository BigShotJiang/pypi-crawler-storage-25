"""Object diagram renderer.

Pure functions that transform object diagram primitives to PlantUML text.
"""

from __future__ import annotations

from ..primitives.common import mirror_arrow_head, sanitize_ref
from ..primitives.styles import ObjectDiagramStyle
from ..primitives.object_ import (
    Map,
    Object,
    ObjectDiagram,
    ObjectDiagramElement,
    ObjectNote,
    Relationship,
)
from .common import (
    escape_quotes,
    needs_quotes,
    quote_ref,
    render_caption,
    render_color_hash,
    render_diagram_style,
    render_mainframe,
    render_embeddable_content,
    render_footer,
    render_header,
    render_label,
    render_layout_direction,
    render_layout_engine,
    render_legend,
    render_line_style_bracket,
    render_linetype,
    render_scale,
    render_stereotype,
    render_theme,
)


def render_object_diagram(diagram: ObjectDiagram) -> str:
    """Render a complete object diagram to PlantUML text."""
    lines: list[str] = ["@startuml"]

    if diagram.mainframe:
        lines.append(render_mainframe(diagram.mainframe))

    # Theme comes first
    theme_line = render_theme(diagram.theme)
    if theme_line:
        lines.append(theme_line)

    # Scale (affects output size)
    if diagram.scale:
        scale_str = render_scale(diagram.scale)
        if scale_str:
            lines.append(scale_str)

    if diagram.title:
        if "\n" in diagram.title:
            lines.append("title")
            for title_line in diagram.title.split("\n"):
                lines.append(f"  {escape_quotes(title_line)}")
            lines.append("end title")
        else:
            lines.append(f"title {escape_quotes(diagram.title)}")

    # Header and footer
    if diagram.header:
        lines.extend(render_header(diagram.header))
    if diagram.footer:
        lines.extend(render_footer(diagram.footer))

    # Caption (appears below diagram)
    if diagram.caption:
        lines.append(render_caption(diagram.caption))

    # Legend
    if diagram.legend:
        lines.extend(render_legend(diagram.legend))

    # Layout direction
    layout_line = render_layout_direction(diagram.layout)
    if layout_line:
        lines.append(layout_line)

    # Layout engine pragma
    engine_line = render_layout_engine(diagram.layout_engine)
    if engine_line:
        lines.append(engine_line)

    # Line routing style
    linetype_line = render_linetype(diagram.linetype)
    if linetype_line:
        lines.append(linetype_line)

    # Diagram-wide CSS styling
    if diagram.diagram_style:
        lines.extend(_render_object_diagram_style(diagram.diagram_style))

    # Render targeted notes last so their targets are defined first
    deferred_notes: list[ObjectNote] = []
    for elem in diagram.elements:
        if isinstance(elem, ObjectNote) and elem.target:
            deferred_notes.append(elem)
        else:
            lines.extend(_render_element(elem))
    for note in deferred_notes:
        lines.extend(_render_note(note))

    lines.append("@enduml")
    return "\n".join(lines)


def _render_element(elem: ObjectDiagramElement, indent: int = 0) -> list[str]:
    """Render a single diagram element."""

    if isinstance(elem, Object):
        return _render_object(elem, indent)
    if isinstance(elem, Map):
        return _render_map(elem, indent)
    if isinstance(elem, Relationship):
        return _render_relationship(elem, indent)
    if isinstance(elem, ObjectNote):
        return _render_note(elem, indent)
    raise TypeError(f"Unknown element type: {type(elem).__name__}")


def _render_object(obj: Object, indent: int = 0) -> list[str]:
    """Render an object."""
    prefix = "  " * indent
    lines: list[str] = []

    parts: list[str] = ["object"]

    # Name - quote if needed or if alias provided, add implicit alias when quoted
    quoted = needs_quotes(obj.name) or obj.alias is not None
    name = f'"{escape_quotes(obj.name)}"' if quoted else obj.name
    parts.append(name)

    if obj.alias:
        parts.append(f"as {obj.alias}")
    elif quoted:
        # Quoted names need implicit alias for references to work
        parts.append(f"as {sanitize_ref(obj.name)}")

    if obj.stereotype:
        parts.append(render_stereotype(obj.stereotype))

    # Style background as element color
    if obj.style and obj.style.background:
        parts.append(render_color_hash(obj.style.background))

    if obj.fields:
        lines.append(f"{prefix}{' '.join(parts)} {{")
        for field in obj.fields:
            value = escape_quotes(field.value)
            lines.append(f"{prefix}  {field.name} = {value}")
        lines.append(f"{prefix}}}")
    else:
        lines.append(f"{prefix}{' '.join(parts)}")

    return lines


def _render_map(map_obj: Map, indent: int = 0) -> list[str]:
    """Render a map."""
    prefix = "  " * indent
    lines: list[str] = []

    parts: list[str] = ["map"]

    # Name - quote if needed or if alias provided, add implicit alias when quoted
    quoted = needs_quotes(map_obj.name) or map_obj.alias is not None
    name = f'"{escape_quotes(map_obj.name)}"' if quoted else map_obj.name
    parts.append(name)

    if map_obj.alias:
        parts.append(f"as {map_obj.alias}")
    elif quoted:
        # Quoted names need implicit alias for references to work
        parts.append(f"as {sanitize_ref(map_obj.name)}")

    # Style background as element color
    if map_obj.style and map_obj.style.background:
        parts.append(render_color_hash(map_obj.style.background))

    lines.append(f"{prefix}{' '.join(parts)} {{")
    for entry in map_obj.entries:
        if entry.link:
            lines.append(f"{prefix}  {entry.key} *-> {entry.link}")
        else:
            lines.append(f"{prefix}  {entry.key} => {entry.value}")
    lines.append(f"{prefix}}}")

    return lines


def _render_relationship(rel: Relationship, indent: int = 0) -> list[str]:
    """Render a relationship."""
    prefix = "  " * indent
    lines: list[str] = []

    # Get the base arrow based on type
    arrow_map = {
        "association": "--",
        "arrow": "-->",
        "extension": "<|--",
        "implementation": "<|..",
        "composition": "*--",
        "aggregation": "o--",
        "dependency": "..>",
        "line": "--",
        "dotted": "..",
    }
    base_arrow = arrow_map.get(rel.type, "--")

    # When custom heads are specified, build arrow from parts
    if rel.left_head is not None or rel.right_head is not None:
        arrow = _build_custom_arrow(
            base_arrow, rel.direction, rel.style, rel.length,
            rel.left_head, rel.right_head,
        )
    else:
        # Build arrow with direction, style, and length
        arrow = _build_arrow(base_arrow, rel.direction, rel.style, rel.length)

    # Build the full relationship line
    parts: list[str] = [quote_ref(rel.source), arrow, quote_ref(rel.target)]

    # Relationship label
    if rel.label:
        label = render_label(rel.label, inline=True)
        parts.append(f": {label}")

    lines.append(f"{prefix}{' '.join(parts)}")

    # Note on link
    if rel.note:
        note_text = render_label(rel.note)
        if "\n" in note_text:
            lines.append(f"{prefix}note on link")
            for note_line in note_text.split("\n"):
                lines.append(f"{prefix}  {note_line}")
            lines.append(f"{prefix}end note")
        else:
            lines.append(f"{prefix}note on link: {note_text}")

    return lines


def _build_custom_arrow(
    base_arrow: str,
    direction: str | None,
    style,
    length: int | None,
    left_head: str | None,
    right_head: str | None,
) -> str:
    """Build arrow from custom head parts."""
    dir_mod = direction[0] if direction else ""
    style_mod = render_line_style_bracket(style) if style else ""
    dashes = length if length is not None else 2

    line_char = "." if ".." in base_arrow else "-"
    has_arrow = ">" in base_arrow
    left = mirror_arrow_head(left_head) if left_head else ""
    right = right_head or (">" if has_arrow else "")
    if style_mod or dir_mod:
        middle = f"{line_char}{style_mod}{dir_mod}{line_char * (dashes - 1)}"
    else:
        middle = line_char * dashes
    return f"{left}{middle}{right}"


def _build_arrow(
    base_arrow: str,
    direction: str | None,
    style,
    length: int | None = None,
) -> str:
    """Build arrow with direction, style, and length modifiers.

    The length parameter controls the dash/dot count in the arrow stem.
    Default (None) uses 2 dashes/dots matching PlantUML's standard arrows.
    """
    # Direction modifier (first letter: u, d, l, r)
    dir_mod = ""
    if direction:
        dir_mod = direction[0]

    # Style modifier
    style_mod = ""
    if style:
        style_mod = render_line_style_bracket(style)

    has_mods = bool(style_mod or dir_mod)

    # Effective dash/dot count (default 2 matches `--` / `..`)
    dashes = length if length is not None else 2

    # Split arrow into head/stem/tail and rebuild with length.
    # Check `--` before `->` since `-->` contains both patterns.
    # Same for `..` before `.>`.

    # Solid: --, <|--, *--, o--, -->
    if "--" in base_arrow:
        idx = base_arrow.index("--")
        head = base_arrow[:idx]
        tail = base_arrow[idx + 2:]
        if has_mods:
            return f"{head}-{style_mod}{dir_mod}{'-' * (dashes - 1)}{tail}"
        return f"{head}{'-' * dashes}{tail}"

    # Dotted: .., <|.., ..>
    if ".." in base_arrow:
        idx = base_arrow.index("..")
        head = base_arrow[:idx]
        tail = base_arrow[idx + 2:]
        if has_mods:
            return f"{head}.{style_mod}{dir_mod}{'.' * (dashes - 1)}{tail}"
        return f"{head}{'.' * dashes}{tail}"

    return base_arrow


def _render_note(note: ObjectNote, indent: int = 0) -> list[str]:
    """Render a note."""
    prefix = "  " * indent
    content = render_embeddable_content(note.content)

    if note.target:
        pos = f"note {note.position} of {note.target}"
    else:
        pos = f"note {note.position}"

    color_part = ""
    if note.color:
        color_part = f" {render_color_hash(note.color)}"

    if "\n" in content:
        lines = [f"{prefix}{pos}{color_part}"]
        for line in content.split("\n"):
            lines.append(f"{prefix}  {line}")
        lines.append(f"{prefix}end note")
        return lines

    return [f"{prefix}{pos}{color_part}: {content}"]


def _render_object_diagram_style(style: ObjectDiagramStyle) -> list[str]:
    """Render an ObjectDiagramStyle to PlantUML <style> block.

    Note: PlantUML ignores arrow and note CSS selectors for object diagrams.
    """
    return render_diagram_style(
        diagram_type="objectDiagram",
        root_background=style.background,
        root_font_name=style.font_name,
        root_font_size=style.font_size,
        root_font_color=style.font_color,
        element_styles=[
            ("object", style.object),
            ("map", style.map),
        ],
        arrow_style=None,  # PlantUML ignores arrow CSS for object diagrams
        title_style=style.title,
        stereotypes=style.stereotypes,
    )
