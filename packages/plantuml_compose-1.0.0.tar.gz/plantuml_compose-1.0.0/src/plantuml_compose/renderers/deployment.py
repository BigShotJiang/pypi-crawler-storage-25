"""Deployment diagram renderer.

Pure functions that transform deployment diagram primitives to PlantUML text.
"""

from __future__ import annotations

from ..primitives.common import mirror_arrow_head
from ..primitives.styles import DeploymentDiagramStyle
from ..primitives.deployment import (
    DeploymentDiagram,
    DeploymentDiagramElement,
    DeploymentElement,
    DeploymentNote,
    Relationship,
)
from .common import (
    escape_quotes,
    needs_quotes,
    quote_ref,
    render_caption,
    render_color_hash,
    render_diagram_style,
    render_embeddable_content,
    render_footer,
    render_header,
    render_label,
    render_layout_direction,
    render_layout_engine,
    render_legend,
    render_line_style_bracket,
    render_linetype,
    render_mainframe,
    render_scale,
    render_stereotype,
    render_theme,
)


def render_deployment_diagram(diagram: DeploymentDiagram) -> str:
    """Render a complete deployment diagram to PlantUML text."""
    lines: list[str] = ["@startuml"]

    if diagram.mainframe:
        lines.append(render_mainframe(diagram.mainframe))

    # Theme comes first
    theme_line = render_theme(diagram.theme)
    if theme_line:
        lines.append(theme_line)

    # Style block comes after theme
    if diagram.diagram_style:
        lines.extend(_render_deployment_diagram_style(diagram.diagram_style))

    # Scale (affects output size)
    if diagram.scale:
        scale_str = render_scale(diagram.scale)
        if scale_str:
            lines.append(scale_str)

    if diagram.title:
        if "\n" in diagram.title:
            lines.append("title")
            for title_line in diagram.title.split("\n"):
                lines.append(f"  {escape_quotes(title_line)}")
            lines.append("end title")
        else:
            lines.append(f"title {escape_quotes(diagram.title)}")

    # Header and footer
    if diagram.header:
        lines.extend(render_header(diagram.header))
    if diagram.footer:
        lines.extend(render_footer(diagram.footer))

    # Caption (appears below diagram)
    if diagram.caption:
        lines.append(render_caption(diagram.caption))

    # Legend
    if diagram.legend:
        lines.extend(render_legend(diagram.legend))

    # Layout direction
    layout_line = render_layout_direction(diagram.layout)
    if layout_line:
        lines.append(layout_line)

    # Layout engine pragma
    engine_line = render_layout_engine(diagram.layout_engine)
    if engine_line:
        lines.append(engine_line)

    # Line routing style
    linetype_line = render_linetype(diagram.linetype)
    if linetype_line:
        lines.append(linetype_line)

    # Render targeted notes last so their targets are defined first
    deferred_notes: list[DeploymentNote] = []
    for elem in diagram.elements:
        if isinstance(elem, DeploymentNote) and elem.target:
            deferred_notes.append(elem)
        else:
            lines.extend(_render_element(elem))
    for note in deferred_notes:
        lines.extend(_render_note(note))

    lines.append("@enduml")
    return "\n".join(lines)


def _render_deployment_diagram_style(style: DeploymentDiagramStyle) -> list[str]:
    """Render a DeploymentDiagramStyle to PlantUML <style> block.

    PlantUML deployment diagrams require style selectors at the top level
    of the <style> block, not nested inside deploymentDiagram { }.
    """
    return render_diagram_style(
        diagram_type="deploymentDiagram",
        root_background=style.background,
        root_font_name=style.font_name,
        root_font_size=style.font_size,
        root_font_color=style.font_color,
        element_styles=[
            ("node", style.node),
            ("artifact", style.artifact),
            ("database", style.database),
            ("cloud", style.cloud),
            ("component", style.component),
            ("frame", style.frame),
            ("storage", style.storage),
            ("folder", style.folder),
            ("package", style.package),
            ("rectangle", style.rectangle),
            ("queue", style.queue),
            ("stack", style.stack),
            ("note", style.note),
        ],
        arrow_style=style.arrow,
        title_style=style.title,
        stereotypes=style.stereotypes,
        top_level_selectors=True,
    )


def _render_element(
    elem: DeploymentDiagramElement, indent: int = 0
) -> list[str]:
    """Render a single diagram element."""

    if isinstance(elem, DeploymentElement):
        return _render_deployment_element(elem, indent)
    if isinstance(elem, Relationship):
        return _render_relationship(elem, indent)
    if isinstance(elem, DeploymentNote):
        return _render_note(elem, indent)
    raise TypeError(f"Unknown element type: {type(elem).__name__}")


def _render_deployment_element(
    elem: DeploymentElement, indent: int = 0
) -> list[str]:
    """Render a deployment element."""
    prefix = "  " * indent
    lines: list[str] = []

    # Port types render as simple single-line elements
    if elem.type in ("port", "portin", "portout"):
        name = (
            f'"{escape_quotes(elem.name)}"'
            if needs_quotes(elem.name)
            else elem.name
        )
        lines.append(f"{prefix}{elem.type} {name}")
        return lines

    parts: list[str] = [elem.type]

    # Name with possible alias
    quoted = needs_quotes(elem.name)

    # PlantUML bracket description syntax [..] doesn't work with quoted names.
    # For quoted names with descriptions, embed \n in the name string instead.
    use_bracket_desc = elem.description and not elem.elements and not quoted
    if quoted and elem.description and not elem.elements:
        desc_suffix = "\\n" + elem.description.replace("\n", "\\n")
        name = f'"{escape_quotes(elem.name)}{desc_suffix}"'
    else:
        name = (
            f'"{escape_quotes(elem.name)}"'
            if quoted
            else elem.name
        )
    parts.append(name)

    if elem.alias:
        parts.append(f"as {elem.alias}")

    if elem.stereotype:
        parts.append(render_stereotype(elem.stereotype))

    # Style background as element color
    if elem.style and elem.style.background:
        parts.append(render_color_hash(elem.style.background))

    if elem.elements:
        lines.append(f"{prefix}{' '.join(parts)} {{")
        for inner in elem.elements:
            lines.extend(_render_element(inner, indent + 1))
        lines.append(f"{prefix}}}")
    elif use_bracket_desc:
        lines.append(f"{prefix}{' '.join(parts)} [")
        for desc_line in elem.description.split("\n"):
            lines.append(f"{prefix}  {desc_line}")
        lines.append(f"{prefix}]")
    else:
        lines.append(f"{prefix}{' '.join(parts)}")

    return lines


def _render_relationship(rel: Relationship, indent: int = 0) -> list[str]:
    """Render a relationship between elements."""
    prefix = "  " * indent
    lines: list[str] = []

    # Build arrow based on type
    arrow_map = {
        "association": "--",
        "dependency": "..>",
        "arrow": "-->",
        "dotted_arrow": "..>",
        "line": "--",
        "dotted": "..",
    }
    base_arrow = arrow_map.get(rel.type, "--")

    # When custom heads are specified, build arrow from parts
    if rel.left_head is not None or rel.right_head is not None:
        arrow = _build_custom_arrow(
            base_arrow, rel.direction, rel.style, rel.length,
            rel.left_head, rel.right_head,
        )
    else:
        # Build arrow with direction, style, and length
        arrow = _build_arrow(base_arrow, rel.direction, rel.style, rel.length)

    # Build the full relationship line
    parts: list[str] = [quote_ref(rel.source), arrow, quote_ref(rel.target)]

    # Relationship label
    if rel.label:
        label = render_label(rel.label, inline=True)
        parts.append(f": {label}")

    lines.append(f"{prefix}{' '.join(parts)}")

    # Note on link
    if rel.note:
        note_text = render_label(rel.note)
        if "\n" in note_text:
            lines.append(f"{prefix}note on link")
            for note_line in note_text.split("\n"):
                lines.append(f"{prefix}  {note_line}")
            lines.append(f"{prefix}end note")
        else:
            lines.append(f"{prefix}note on link: {note_text}")

    return lines


def _build_custom_arrow(
    base_arrow: str,
    direction: str | None,
    style,
    length: int | None,
    left_head: str | None,
    right_head: str | None,
) -> str:
    """Build arrow from custom head parts."""
    dir_mod = direction[0] if direction else ""
    style_mod = render_line_style_bracket(style) if style else ""
    dashes = length if length is not None else 2

    line_char = "." if ".." in base_arrow else "-"
    has_arrow = ">" in base_arrow
    left = mirror_arrow_head(left_head) if left_head else ""
    right = right_head or (">" if has_arrow else "")
    if style_mod or dir_mod:
        middle = f"{line_char}{style_mod}{dir_mod}{line_char * (dashes - 1)}"
    else:
        middle = line_char * dashes
    return f"{left}{middle}{right}"


def _build_arrow(
    base_arrow: str,
    direction: str | None,
    style,
    length: int | None = None,
) -> str:
    """Build arrow with direction, style, and length modifiers.

    The length parameter controls the dash/dot count in the arrow stem.
    Default (None) uses 2 dashes/dots matching PlantUML's standard arrows.
    """
    # Direction modifier (first letter: u, d, l, r)
    dir_mod = ""
    if direction:
        dir_mod = direction[0]

    # Style modifier
    style_mod = ""
    if style:
        style_mod = render_line_style_bracket(style)

    has_mods = bool(style_mod or dir_mod)

    # Effective dash/dot count (default 2 matches `--` / `..`)
    dashes = length if length is not None else 2

    # Split arrow into head/stem/tail and rebuild with length.
    # Check `--` before `->` since `-->` contains both patterns.
    # Same for `..` before `.>`.
    if "--" in base_arrow:
        idx = base_arrow.index("--")
        head = base_arrow[:idx]
        tail = base_arrow[idx + 2:]
        if has_mods:
            return f"{head}-{style_mod}{dir_mod}{'-' * (dashes - 1)}{tail}"
        return f"{head}{'-' * dashes}{tail}"

    if ".." in base_arrow:
        idx = base_arrow.index("..")
        head = base_arrow[:idx]
        tail = base_arrow[idx + 2:]
        if has_mods:
            return f"{head}.{style_mod}{dir_mod}{'.' * (dashes - 1)}{tail}"
        return f"{head}{'.' * dashes}{tail}"

    return base_arrow


def _render_note(note: DeploymentNote, indent: int = 0) -> list[str]:
    """Render a note."""
    prefix = "  " * indent
    content = render_embeddable_content(note.content)

    if note.target:
        pos = f"note {note.position} of {note.target}"
    else:
        pos = f"note {note.position}"

    color_part = ""
    if note.color:
        color_part = f" {render_color_hash(note.color)}"

    if "\n" in content:
        lines = [f"{prefix}{pos}{color_part}"]
        for line in content.split("\n"):
            lines.append(f"{prefix}  {line}")
        lines.append(f"{prefix}end note")
        return lines

    return [f"{prefix}{pos}{color_part}: {content}"]
