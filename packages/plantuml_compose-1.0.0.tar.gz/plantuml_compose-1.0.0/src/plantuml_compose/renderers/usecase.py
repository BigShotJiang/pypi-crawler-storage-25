"""Use case diagram renderer.

Pure functions that transform use case diagram primitives to PlantUML text.
"""

from __future__ import annotations

from ..primitives.common import mirror_arrow_head
from ..primitives.styles import UseCaseDiagramStyle
from ..primitives.usecase import (
    Actor,
    Container,
    Relationship,
    UseCase,
    UseCaseDiagram,
    UseCaseDiagramElement,
    UseCaseNote,
)
from .common import (
    escape_quotes,
    needs_quotes,
    quote_ref,
    render_caption,
    render_color_hash,
    render_diagram_style,
    render_embeddable_content,
    render_footer,
    render_header,
    render_label,
    render_layout_direction,
    render_layout_engine,
    render_legend,
    render_line_style_bracket,
    render_linetype,
    render_mainframe,
    render_scale,
    render_stereotype,
    render_theme,
)


def render_usecase_diagram(diagram: UseCaseDiagram) -> str:
    """Render a complete use case diagram to PlantUML text."""
    lines: list[str] = ["@startuml"]

    if diagram.mainframe:
        lines.append(render_mainframe(diagram.mainframe))

    # Theme comes first
    theme_line = render_theme(diagram.theme)
    if theme_line:
        lines.append(theme_line)

    # Style block comes after theme
    if diagram.diagram_style:
        lines.extend(_render_usecase_diagram_style(diagram.diagram_style))

    # Scale (affects output size)
    if diagram.scale:
        scale_str = render_scale(diagram.scale)
        if scale_str:
            lines.append(scale_str)

    if diagram.title:
        if "\n" in diagram.title:
            lines.append("title")
            for title_line in diagram.title.split("\n"):
                lines.append(f"  {escape_quotes(title_line)}")
            lines.append("end title")
        else:
            lines.append(f"title {escape_quotes(diagram.title)}")

    # Header and footer
    if diagram.header:
        lines.extend(render_header(diagram.header))
    if diagram.footer:
        lines.extend(render_footer(diagram.footer))

    # Caption (appears below diagram)
    if diagram.caption:
        lines.append(render_caption(diagram.caption))

    # Legend
    if diagram.legend:
        lines.extend(render_legend(diagram.legend))

    # Layout direction
    layout_line = render_layout_direction(diagram.layout)
    if layout_line:
        lines.append(layout_line)

    # Layout engine pragma
    engine_line = render_layout_engine(diagram.layout_engine)
    if engine_line:
        lines.append(engine_line)

    # Line routing style
    linetype_line = render_linetype(diagram.linetype)
    if linetype_line:
        lines.append(linetype_line)

    if diagram.actor_style and diagram.actor_style != "default":
        lines.append(f"skinparam actorStyle {diagram.actor_style}")

    # Render targeted notes last so their targets are defined first
    deferred_notes: list[UseCaseNote] = []
    for elem in diagram.elements:
        if isinstance(elem, UseCaseNote) and elem.target:
            deferred_notes.append(elem)
        else:
            lines.extend(_render_element(elem))
    for note in deferred_notes:
        lines.extend(_render_note(note))

    lines.append("@enduml")
    return "\n".join(lines)


def _render_usecase_diagram_style(style: UseCaseDiagramStyle) -> list[str]:
    """Render a UseCaseDiagramStyle to PlantUML <style> block."""
    return render_diagram_style(
        diagram_type="usecaseDiagram",
        root_background=style.background,
        root_font_name=style.font_name,
        root_font_size=style.font_size,
        root_font_color=style.font_color,
        element_styles=[
            ("actor", style.actor),
            ("usecase", style.usecase),
            ("package", style.package),
            ("rectangle", style.rectangle),
            ("note", style.note),
        ],
        arrow_style=style.arrow,
        title_style=style.title,
        stereotypes=style.stereotypes,
    )


def _render_element(elem: UseCaseDiagramElement, indent: int = 0) -> list[str]:
    """Render a single diagram element."""
    prefix = "  " * indent

    if isinstance(elem, Actor):
        return [f"{prefix}{_render_actor(elem)}"]
    if isinstance(elem, UseCase):
        return [f"{prefix}{_render_usecase(elem)}"]
    if isinstance(elem, Container):
        return _render_container(elem, indent)
    if isinstance(elem, Relationship):
        return _render_relationship(elem, indent)
    if isinstance(elem, UseCaseNote):
        return _render_note(elem, indent)
    raise TypeError(f"Unknown element type: {type(elem).__name__}")


def _render_actor(actor: Actor) -> str:
    """Render an actor."""
    parts: list[str] = []

    # Actor type with optional business variant
    keyword = "actor/" if actor.business else "actor"
    parts.append(keyword)

    # Name — escape newlines to PlantUML's \n line break syntax
    escaped_name = actor.name.replace("\r", "").replace("\n", "\\n")
    if needs_quotes(actor.name) or "\n" in actor.name:
        name = f'"{escape_quotes(escaped_name)}"'
    else:
        name = escaped_name
    parts.append(name)

    if actor.alias:
        parts.append(f"as {actor.alias}")
    elif actor._ref != actor.name:
        # Add implicit alias when ref differs from name to prevent duplicates in containers
        parts.append(f"as {actor._ref}")

    if actor.stereotype:
        parts.append(render_stereotype(actor.stereotype))

    # Style background as element color
    if actor.style and actor.style.background:
        parts.append(render_color_hash(actor.style.background))

    return " ".join(parts)


def _render_usecase(usecase: UseCase) -> str:
    """Render a use case."""
    parts: list[str] = []

    # Usecase type with optional business variant
    keyword = "usecase/" if usecase.business else "usecase"
    parts.append(keyword)

    # Name — escape newlines to PlantUML's \n line break syntax
    escaped_name = usecase.name.replace("\r", "").replace("\n", "\\n")
    if needs_quotes(usecase.name) or "\n" in usecase.name:
        name = f'"{escape_quotes(escaped_name)}"'
    else:
        name = escaped_name
    parts.append(f"({name})")

    if usecase.alias:
        parts.append(f"as {usecase.alias}")
    elif usecase._ref != usecase.name:
        # Add implicit alias when ref differs from name to prevent duplicates in containers
        parts.append(f"as {usecase._ref}")

    if usecase.stereotype:
        parts.append(render_stereotype(usecase.stereotype))

    # Style background as element color
    if usecase.style and usecase.style.background:
        parts.append(render_color_hash(usecase.style.background))

    return " ".join(parts)


def _render_container(container: Container, indent: int = 0) -> list[str]:
    """Render a container (rectangle/package)."""
    prefix = "  " * indent
    lines: list[str] = []

    parts: list[str] = [container.type]

    name = (
        f'"{escape_quotes(container.name)}"'
        if needs_quotes(container.name)
        else container.name
    )
    parts.append(name)

    if container.stereotype:
        parts.append(render_stereotype(container.stereotype))

    # Style background as element color
    if container.style and container.style.background:
        parts.append(render_color_hash(container.style.background))

    parts.append("{")
    lines.append(f"{prefix}{' '.join(parts)}")

    for elem in container.elements:
        lines.extend(_render_element(elem, indent + 1))

    lines.append(f"{prefix}}}")
    return lines


def _render_relationship(rel: Relationship, indent: int = 0) -> list[str]:
    """Render a relationship."""
    prefix = "  " * indent
    lines: list[str] = []

    # Get the base arrow based on type
    arrow_map = {
        "association": "->",
        "arrow": "-->",
        "extension": "<|--",
        "include": ".>",
        "extends": ".>",
        "dependency": "..>",
        "line": "--",
    }
    base_arrow = arrow_map.get(rel.type, "->")

    # When custom heads are specified, build arrow from parts
    if rel.left_head is not None or rel.right_head is not None:
        arrow = _build_custom_arrow(
            base_arrow, rel.direction, rel.style, rel.length,
            rel.left_head, rel.right_head,
        )
    else:
        # Build arrow with direction, style, and length
        arrow = _build_arrow(base_arrow, rel.direction, rel.style, rel.length)

    # Build the full relationship line
    parts: list[str] = [quote_ref(rel.source), arrow, quote_ref(rel.target)]

    # Relationship label
    if rel.label:
        label = render_label(rel.label, inline=True)
        parts.append(f": {label}")
    elif rel.type == "include":
        parts.append(": <<include>>")
    elif rel.type == "extends":
        parts.append(": <<extends>>")

    lines.append(f"{prefix}{' '.join(parts)}")

    # Note on link
    if rel.note:
        note_text = render_label(rel.note)
        if "\n" in note_text:
            lines.append(f"{prefix}note on link")
            for note_line in note_text.split("\n"):
                lines.append(f"{prefix}  {note_line}")
            lines.append(f"{prefix}end note")
        else:
            lines.append(f"{prefix}note on link: {note_text}")

    return lines


def _build_custom_arrow(
    base_arrow: str,
    direction: str | None,
    style,
    length: int | None,
    left_head: str | None,
    right_head: str | None,
) -> str:
    """Build arrow from custom head parts."""
    dir_mod = direction[0] if direction else ""
    style_mod = render_line_style_bracket(style) if style else ""
    dashes = length if length is not None else 2

    line_char = "." if ".." in base_arrow or ".>" in base_arrow else "-"
    has_arrow = ">" in base_arrow
    left = mirror_arrow_head(left_head) if left_head else ""
    right = right_head or (">" if has_arrow else "")
    if style_mod or dir_mod:
        middle = f"{line_char}{style_mod}{dir_mod}{line_char * (dashes - 1)}"
    else:
        middle = line_char * dashes
    return f"{left}{middle}{right}"


def _build_arrow(
    base_arrow: str,
    direction: str | None,
    style,
    length: int | None = None,
) -> str:
    """Build arrow with direction, style, and length modifiers.

    The length parameter controls the dash/dot count in the arrow stem.
    Default (None) preserves the base arrow's original dash/dot count.

    Usecase arrows include both single-dash (-> for association) and
    double-dash (--> for arrow) forms. The default dash count is derived
    from the base arrow when length is None.
    """
    # Direction modifier (first letter: u, d, l, r)
    dir_mod = ""
    if direction:
        dir_mod = direction[0]

    # Style modifier
    style_mod = ""
    if style:
        style_mod = render_line_style_bracket(style)

    has_mods = bool(style_mod or dir_mod)

    # For arrows like -> or -->  (also matches <|--)
    if "->" in base_arrow:
        head = base_arrow.replace("->", "")
        # Count original dashes in head to determine default length
        orig_dashes = head.count("-") + 1  # +1 for the - in ->
        dashes = length if length is not None else orig_dashes
        if has_mods:
            return f"{head.rstrip('-')}-{style_mod}{dir_mod}{'-' * (dashes - 1)}>"
        return f"{head.rstrip('-')}{'-' * dashes}>"

    # For dotted arrows like .> or ..>
    if ".>" in base_arrow:
        head = base_arrow.replace(".>", "")
        orig_dots = head.count(".") + 1
        dashes = length if length is not None else orig_dots
        if has_mods:
            return f"{head.rstrip('.')}.{style_mod}{dir_mod}{'.' * (dashes - 1)}>"
        return f"{head.rstrip('.')}{'.' * dashes}>"

    # For plain lines like --
    if base_arrow == "--":
        dashes = length if length is not None else 2
        if has_mods:
            return f"-{style_mod}{dir_mod}{'-' * (dashes - 1)}"
        return "-" * dashes

    # For extension arrows like <|--
    if "--" in base_arrow:
        idx = base_arrow.index("--")
        head = base_arrow[:idx]
        tail = base_arrow[idx + 2:]
        dashes = length if length is not None else 2
        if has_mods:
            return f"{head}-{style_mod}{dir_mod}{'-' * (dashes - 1)}{tail}"
        return f"{head}{'-' * dashes}{tail}"

    return base_arrow


def _render_note(note: UseCaseNote, indent: int = 0) -> list[str]:
    """Render a note."""
    prefix = "  " * indent
    content = render_embeddable_content(note.content)

    if note.target:
        pos = f"note {note.position} of {note.target}"
    else:
        pos = f"note {note.position}"

    color_part = ""
    if note.color:
        color_part = f" {render_color_hash(note.color)}"

    if "\n" in content:
        lines = [f"{prefix}{pos}{color_part}"]
        for line in content.split("\n"):
            lines.append(f"{prefix}  {line}")
        lines.append(f"{prefix}end note")
        return lines

    return [f"{prefix}{pos}{color_part}: {content}"]
