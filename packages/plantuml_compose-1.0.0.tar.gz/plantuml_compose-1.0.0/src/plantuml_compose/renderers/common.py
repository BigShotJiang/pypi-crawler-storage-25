"""Common rendering utilities shared across all diagram types."""

from __future__ import annotations

import re

from ..primitives.common import (
    Color,
    DiagramArrowStyle,
    ElementStyle,
    EmbeddableContent,
    EmbeddedDiagram,
    ExternalTheme,
    Footer,
    Gradient,
    Header,
    Label,
    LayoutDirection,
    LayoutEngine,
    Legend,
    LineStyleLike,
    LineType,
    PlantUMLBuiltinTheme,
    Scale,
    Stereotype,
    StyleLike,
    ThemeLike,
    coerce_line_style,
    coerce_style,
)


def escape_quotes(text: str) -> str:
    """Replace double quotes with Unicode escape for PlantUML compatibility.

    We use <U+0022> which PlantUML renders as a literal double quote.
    """
    return text.replace('"', "<U+0022>")


def render_theme(theme: ThemeLike) -> str | None:
    """Render theme directive.

    PlantUML syntax:
        !theme cerulean                    (built-in theme)
        !theme mytheme from /path/to/dir   (local theme)
        !theme amiga from https://...      (remote theme)

    Returns None if theme is None or has empty/whitespace name.
    """
    if theme is None:
        return None

    if isinstance(theme, ExternalTheme):
        if not theme.name.strip():
            return None
        return f"!theme {theme.name} from {theme.source}"

    # Built-in theme (string)
    if not theme.strip():
        return None
    return f"!theme {theme}"


def render_layout_direction(layout: LayoutDirection | None) -> str | None:
    """Render diagram layout direction directive.

    PlantUML syntax:
        left to right direction   (horizontal flow)
        top to bottom direction   (vertical flow, default)

    Returns None if layout is None (use PlantUML default).
    """
    if layout is None:
        return None
    if layout == "left_to_right":
        return "left to right direction"
    if layout == "top_to_bottom":
        return "top to bottom direction"
    # Type system guarantees exhaustiveness, but explicit error for safety
    raise ValueError(f"Unknown layout direction: {layout}")


def render_layout_engine(engine: LayoutEngine | None) -> str | None:
    """Render layout engine pragma.

    PlantUML syntax:
        !pragma layout smetana   (use Smetana pure-Java layout engine)

    Returns None if engine is None (use default GraphViz).
    """
    if engine is None:
        return None
    if engine == "smetana":
        return "!pragma layout smetana"
    raise ValueError(f"Unknown layout engine: {engine}")


def render_linetype(linetype: LineType | None) -> str | None:
    """Render line routing style.

    PlantUML syntax:
        skinparam linetype ortho      (orthogonal/right-angle routing)
        skinparam linetype polyline   (polyline routing with bends)

    Returns None if linetype is None (use default spline routing).
    """
    if linetype is None:
        return None
    if linetype == "ortho":
        return "skinparam linetype ortho"
    if linetype == "polyline":
        return "skinparam linetype polyline"
    raise ValueError(f"Unknown linetype: {linetype}")


def link(url: str, *, label: str | None = None, tooltip: str | None = None) -> str:
    """
    Create a PlantUML hyperlink.

    Args:
        url: The URL to link to (must not be empty)
        label: Optional display text (defaults to showing the URL)
        tooltip: Optional tooltip text shown on hover

    Returns:
        PlantUML link syntax: [[url{tooltip} label]]

    Raises:
        ValueError: If url is empty

    Examples:
        link("http://example.com")
        # [[http://example.com]]

        link("http://example.com", label="Click here")
        # [[http://example.com Click here]]

        link("http://example.com", tooltip="More info")
        # [[http://example.com{More info}]]

        link("http://example.com", label="Click here", tooltip="More info")
        # [[http://example.com{More info} Click here]]

        link("http://example.com/path?foo={bar}", label="Click")
        # [["http://example.com/path?foo={bar}"{} Click]]
    """
    if not url:
        raise ValueError("url must not be empty")

    # URLs with { or } need quoting per PlantUML spec
    needs_quoting = "{" in url or "}" in url

    if needs_quoting:
        # Quoted URL format: [["url"{tooltip} label]]
        result = f'[["{url}"'
        if tooltip:
            result += f"{{{tooltip}}}"
        else:
            # Empty tooltip {} needed to separate quoted URL from label
            result += "{}"
    else:
        result = f"[[{url}"
        if tooltip:
            result += f"{{{tooltip}}}"

    if label:
        result += f" {label}"
    result += "]]"
    return result


# Pattern for valid hex color codes: #RGB, #ARGB, #RRGGBB, #AARRGGBB
_HEX_COLOR_PATTERN = re.compile(r"^#[0-9A-Fa-f]{3,4}$|^#[0-9A-Fa-f]{6}$|^#[0-9A-Fa-f]{8}$")


def _is_hex_color(value: str) -> bool:
    """Check if a string is a valid hex color code."""
    return bool(_HEX_COLOR_PATTERN.match(value))


def _normalize_color(value: str) -> str:
    """Normalize a color string to its canonical form.

    - Hex colors keep their # prefix: "#FF0000" -> "#FF0000"
    - Named colors have no # prefix: "red" -> "red"
    - Erroneous # on named colors is stripped: "#red" -> "red"
    """
    if value.startswith("#"):
        if _is_hex_color(value):
            return value  # Valid hex, keep #
        return value[1:]  # Not valid hex, strip erroneous #
    return value


def render_color(color: Color | Gradient | str) -> str:
    """Convert a color to PlantUML string in canonical form.

    Returns colors in their natural form:
    - Named colors: "red", "LightBlue" (no #)
    - Hex colors: "#FF0000", "#E3F2FD" (with #)

    Handles user input errors like "#red" by stripping the erroneous #.
    """
    if isinstance(color, str):
        return _normalize_color(color)
    if isinstance(color, Color):
        return _normalize_color(color.value)
    if isinstance(color, Gradient):
        sep = {
            "horizontal": "|",
            "vertical": "-",
            "diagonal_down": "/",
            "diagonal_up": "\\",
        }[color.direction]
        # End color must NOT have # prefix — PlantUML rejects #color1|#color2
        # but accepts #color1|color2 (or color1|color2)
        return f"{render_color(color.start)}{sep}{render_color_bare(color.end)}"
    raise TypeError(f"Unknown color type: {type(color)}")


def render_color_hash(color: Color | Gradient | str) -> str:
    """Convert a color to PlantUML string, ensuring # prefix.

    Returns colors with # prefix for contexts that require it:
    - Bracket syntax: [#color]
    - Stereotype spots: (C,#color)

    Named colors get # added: "red" -> "#red"
    Hex colors already have #: "#FF0000" -> "#FF0000"
    """
    value = render_color(color)
    return value if value.startswith("#") else f"#{value}"


def render_color_bare(color: Color | Gradient | str) -> str:
    """Convert a color to PlantUML string, stripping any # prefix.

    Returns colors without # prefix for contexts that don't want it:
    - Inline style syntax: back:FF0000, line:red

    Named colors stay as-is: "red" -> "red"
    Hex colors have # stripped: "#FF0000" -> "FF0000"
    """
    value = render_color(color)
    return value[1:] if value.startswith("#") else value


def render_label(label: Label | str | None, *, inline: bool = False) -> str:
    """
    Convert a label to string.

    Args:
        label: The label to render
        inline: If True, escape newlines to %n() for single-line PlantUML contexts
                (message labels, relationship labels, state descriptions, etc.)
                If False, preserve newlines for block contexts (notes, headers, etc.)
    """
    if label is None:
        return ""
    if isinstance(label, str):
        text = escape_quotes(label)
    else:
        text = escape_quotes(label.text)

    if inline:
        text = text.replace("\n", "%n()")

    return text


def render_embeddable_content(
    content: EmbeddableContent | None, *, inline: bool = False
) -> str:
    """Render content that may include embedded diagrams.

    This function handles str, Label, and EmbeddedDiagram uniformly,
    making it easy for renderers to support embedded sub-diagrams
    in notes, messages, legends, and other content fields.

    Args:
        content: The content to render (str, Label, or EmbeddedDiagram)
        inline: If True, use single-line format for EmbeddedDiagram
               (uses %breakline()) and escape newlines for regular text.
               If False, use multi-line format.

    Returns:
        Rendered string suitable for PlantUML output
    """
    if content is None:
        return ""
    if isinstance(content, EmbeddedDiagram):
        return content.render(inline=inline)
    return render_label(content, inline=inline)


def adjust_arrow_length(arrow: str, length: int | None) -> str:
    """Adjust the dash/dot count in an arrow string.

    PlantUML uses the number of dashes or dots as a layout hint for spacing:
    - `->` (1 dash) = short/close
    - `-->` (2 dashes) = normal (default)
    - `--->` (3 dashes) = longer spacing

    Same for dotted: `.>`, `..>`, `...>`, etc.

    This function finds the first run of consecutive `-` or `.` characters
    in the arrow and replaces it with `length` repetitions. If length is
    None, the arrow is returned unchanged.

    Args:
        arrow: Base arrow string (e.g., "-->", "<|--..", "..>")
        length: Desired dash/dot count, or None for no change

    Returns:
        Arrow with adjusted dash/dot count
    """
    if length is None:
        return arrow

    result = ""
    i = 0
    replaced = False
    while i < len(arrow):
        if not replaced and arrow[i] == "-":
            # Count consecutive dashes
            j = i
            while j < len(arrow) and arrow[j] == "-":
                j += 1
            result += "-" * length
            i = j
            replaced = True
        elif not replaced and arrow[i] == ".":
            # Count consecutive dots
            j = i
            while j < len(arrow) and arrow[j] == ".":
                j += 1
            result += "." * length
            i = j
            replaced = True
        else:
            result += arrow[i]
            i += 1
    return result


def render_line_style_bracket(style: LineStyleLike) -> str:
    """Render line style as bracket modifier: [#red,dashed,thickness=2]"""
    style = coerce_line_style(style)
    parts: list[str] = []

    if style.color:
        parts.append(render_color_hash(style.color))

    if style.pattern != "solid":
        parts.append(style.pattern)

    if style.bold:
        parts.append("bold")

    if style.thickness:
        parts.append(f"thickness={style.thickness}")

    return f"[{','.join(parts)}]" if parts else ""


def render_element_style(style: StyleLike) -> str:
    """Render Style as PlantUML inline format for any element.

    PlantUML element style syntax options:
    1. Background only: #color or #color1-color2 (gradient)
    2. Line/text/multiple: #back;line.pattern:color;text:color (semicolon-separated)

    The ## syntax for line-only styling doesn't work in component/deployment
    diagrams, so we always use semicolon format when line or text is specified.

    Works for states, components, interfaces, and other diagram elements.
    """
    style = coerce_style(style)

    # Coerce line style if present
    line = coerce_line_style(style.line) if style.line else None

    # Check what we have
    background = style.background
    text_color = style.text_color
    has_background = background is not None
    has_line = line is not None and (
        line.color is not None or line.pattern != "solid"
    )
    has_text = text_color is not None

    # Background only: use simple #color format
    if has_background and not has_line and not has_text:
        return render_color_hash(background)  # type: ignore[arg-type]

    # Line or text present: use semicolon format for compatibility
    props: list[str] = []

    if has_background:
        props.append(render_color_hash(background))  # type: ignore[arg-type]

    if has_line and line:
        if line.pattern != "solid":
            props.append(f"line.{line.pattern}")
        if line.color:
            props.append(f"line:{render_color_bare(line.color)}")

    if text_color is not None:
        props.append(f"text:{render_color_bare(text_color)}")

    # Join with semicolons, prefix with # if first part doesn't have one
    if props:
        result = ";".join(props)
        if not result.startswith("#"):
            result = f"#{result}"
        return result
    return ""


def render_stereotype(stereotype: Stereotype) -> str:
    """Render Stereotype as PlantUML format: <<name>> or << (C,color) name >>

    Spot colors use render_color() (not render_color_hash) because
    PlantUML spots accept bare named colors (DodgerBlue) or #hex (#0088FF)
    but NOT #namedColor (#DodgerBlue).
    """
    if stereotype.spot:
        color = render_color(stereotype.spot.color)
        return f"<< ({stereotype.spot.char},{color}) {stereotype.name} >>"
    return f"<<{stereotype.name}>>"


# =============================================================================
# Common Diagram Metadata Rendering
# =============================================================================


def render_header(header: Header) -> list[str]:
    """Render header directive.

    PlantUML syntax:
        header Text           (left-aligned, single line)
        center header Text    (centered, single line)
        right header Text     (right-aligned, single line)
        header\\n...\\nendheader  (multiline block)
    """
    text = render_label(header.content)

    if header.position == "center":
        prefix = "center header"
    elif header.position == "right":
        prefix = "right header"
    else:
        prefix = "header"

    if "\n" in text:
        lines = [prefix]
        lines.extend(f"  {line}" for line in text.split("\n"))
        lines.append("endheader")
        return lines
    return [f"{prefix} {text}"]


def render_footer(footer: Footer) -> list[str]:
    """Render footer directive.

    PlantUML syntax:
        footer Text           (left-aligned, single line)
        center footer Text    (centered, single line)
        right footer Text     (right-aligned, single line)
        footer\\n...\\nendfooter  (multiline block)

    Supports special variables like %page% and %lastpage%.
    """
    text = render_label(footer.content)

    if footer.position == "center":
        prefix = "center footer"
    elif footer.position == "right":
        prefix = "right footer"
    else:
        prefix = "footer"

    if "\n" in text:
        lines = [prefix]
        lines.extend(f"  {line}" for line in text.split("\n"))
        lines.append("endfooter")
        return lines
    return [f"{prefix} {text}"]


def render_legend(legend: Legend) -> list[str]:
    """Render legend block.

    PlantUML syntax:
        legend [left|right|top|bottom|center]
          content
        endlegend

    Legends are always multiline blocks in PlantUML.
    Supports embedded sub-diagrams in content.
    """
    text = render_embeddable_content(legend.content)

    # Build opening line with position
    if legend.position == "right":
        opening = "legend"  # right is default
    else:
        opening = f"legend {legend.position}"

    lines = [opening]
    for line in text.split("\n"):
        lines.append(f"  {line}")
    lines.append("endlegend")
    return lines


def render_scale(scale: Scale) -> str:
    """Render scale directive.

    PlantUML syntax:
        scale 1.5              (factor)
        scale 2/3              (fraction - but we use float)
        scale 200 width        (exact width)
        scale 100 height       (exact height)
        scale 200*100          (exact width and height)
        scale max 1024 width   (max width)
        scale max 768 height   (max height)
        scale max 1024*768     (max width and height)
    """
    # Max dimensions take priority
    if scale.max_width is not None and scale.max_height is not None:
        return f"scale max {scale.max_width}*{scale.max_height}"
    if scale.max_width is not None:
        return f"scale max {scale.max_width} width"
    if scale.max_height is not None:
        return f"scale max {scale.max_height} height"

    # Exact dimensions
    if scale.width is not None and scale.height is not None:
        return f"scale {scale.width}*{scale.height}"
    if scale.width is not None:
        return f"scale {scale.width} width"
    if scale.height is not None:
        return f"scale {scale.height} height"

    # Factor
    if scale.factor is not None:
        return f"scale {scale.factor}"

    return ""


def render_newpage(title: str | None = None) -> str:
    """Render newpage directive.

    PlantUML syntax:
        newpage                     (simple page break)
        newpage Title for new page  (page break with title)
    """
    if title:
        return f"newpage {escape_quotes(title)}"
    return "newpage"


def render_mainframe(text: str) -> str:
    """Render mainframe directive.

    PlantUML syntax:
        mainframe This is a **mainframe**

    Draws a labeled frame around the entire diagram.
    Supports Creole markup in the text.
    """
    return f"mainframe {escape_quotes(text)}"


def render_caption(caption: str) -> str:
    """Render caption directive.

    PlantUML syntax:
        caption Figure 1: Description

    Caption appears below the diagram.
    """
    return f"caption {escape_quotes(caption)}"


def needs_quotes(name: str) -> bool:
    """Check if a name needs to be quoted in PlantUML.

    Names need quotes if they:
    - Are empty
    - Don't start with a letter or underscore
    - Contain characters other than alphanumeric or underscore
    """
    if not name:
        return True
    if not name[0].isalpha() and name[0] != "_":
        return True
    for char in name:
        if not (char.isalnum() or char == "_"):
            return True
    return False


def quote_ref(ref: str) -> str:
    """Quote a reference if it contains special characters.

    Used when rendering relationship source/target refs that may contain
    spaces or other characters requiring quoting in PlantUML syntax.
    """
    if needs_quotes(ref):
        return f'"{escape_quotes(ref)}"'
    return ref


# =============================================================================
# Diagram Style Rendering (shared across all diagram types)
# =============================================================================


def render_element_style_block(
    selector: str, style: ElementStyle, indent: int = 2
) -> list[str]:
    """Render an ElementStyle as a nested CSS block.

    Args:
        selector: CSS selector name (e.g., "class", "participant", "node")
        style: The ElementStyle to render
        indent: Base indentation level (spaces)

    Returns:
        Lines for the style block, empty list if no properties set
    """
    props: list[str] = []
    prefix = " " * indent
    inner_prefix = " " * (indent + 2)

    if style.background:
        props.append(f"{inner_prefix}BackgroundColor {render_color(style.background)}")
    if style.line_color:
        props.append(f"{inner_prefix}LineColor {render_color(style.line_color)}")
    if style.font_color:
        props.append(f"{inner_prefix}FontColor {render_color(style.font_color)}")
    if style.font_name:
        props.append(f"{inner_prefix}FontName {style.font_name}")
    if style.font_size:
        props.append(f"{inner_prefix}FontSize {style.font_size}")
    if style.font_style:
        props.append(f"{inner_prefix}FontStyle {style.font_style}")
    if style.round_corner is not None:
        props.append(f"{inner_prefix}RoundCorner {style.round_corner}")
    if style.line_thickness is not None:
        props.append(f"{inner_prefix}LineThickness {style.line_thickness}")
    if style.line_style:
        props.append(f"{inner_prefix}LineStyle {style.line_style}")
    if style.padding is not None:
        props.append(f"{inner_prefix}Padding {style.padding}")
    if style.margin is not None:
        props.append(f"{inner_prefix}Margin {style.margin}")
    if style.horizontal_alignment:
        props.append(f"{inner_prefix}HorizontalAlignment {style.horizontal_alignment}")
    if style.max_width is not None:
        props.append(f"{inner_prefix}MaximumWidth {style.max_width}")
    if style.shadowing is not None:
        props.append(f"{inner_prefix}Shadowing {str(style.shadowing).lower()}")
    if style.diagonal_corner is not None:
        props.append(f"{inner_prefix}DiagonalCorner {style.diagonal_corner}")
    if style.word_wrap is not None:
        props.append(f"{inner_prefix}WordWrap {style.word_wrap}")
    if style.hyperlink_color:
        props.append(f"{inner_prefix}HyperLinkColor {render_color(style.hyperlink_color)}")

    if not props:
        return []

    return [f"{prefix}{selector} {{"] + props + [f"{prefix}}}"]


def render_arrow_style_block(style: DiagramArrowStyle, indent: int = 2) -> list[str]:
    """Render a DiagramArrowStyle as a nested CSS block.

    Args:
        style: The DiagramArrowStyle to render
        indent: Base indentation level (spaces)

    Returns:
        Lines for the arrow style block, empty list if no properties set
    """
    props: list[str] = []
    inner_prefix = " " * (indent + 2)

    if style.line_color:
        props.append(f"{inner_prefix}LineColor {render_color(style.line_color)}")
    if style.line_thickness is not None:
        props.append(f"{inner_prefix}LineThickness {style.line_thickness}")
    if style.line_pattern:
        props.append(f"{inner_prefix}LineStyle {style.line_pattern}")
    if style.font_color:
        props.append(f"{inner_prefix}FontColor {render_color(style.font_color)}")
    if style.font_name:
        props.append(f"{inner_prefix}FontName {style.font_name}")
    if style.font_size:
        props.append(f"{inner_prefix}FontSize {style.font_size}")

    if not props:
        return []

    prefix = " " * indent
    return [f"{prefix}arrow {{"] + props + [f"{prefix}}}"]


def render_diagram_style(
    diagram_type: str,
    root_background: Color | Gradient | str | None,
    root_font_name: str | None,
    root_font_size: int | None,
    root_font_color: Color | str | None,
    element_styles: list[tuple[str, ElementStyle | None]],
    arrow_style: DiagramArrowStyle | None,
    title_style: ElementStyle | None,
    depths: dict[int, ElementStyle] | None = None,
    stereotypes: dict[str, ElementStyle] | None = None,
    top_level_selectors: bool = False,
) -> list[str]:
    """Render a complete <style> block for any diagram type.

    Args:
        diagram_type: PlantUML diagram type name (e.g., "classDiagram", "sequenceDiagram")
        root_background: Diagram background color/gradient
        root_font_name: Default font name
        root_font_size: Default font size
        root_font_color: Default font color
        element_styles: List of (selector, ElementStyle) tuples for diagram elements
        arrow_style: Arrow/line styling
        title_style: Title element styling (rendered in document block)
        depths: Optional depth-level styles (for mindmap/WBS)
        stereotypes: Optional stereotype styles (for most diagram types)
        top_level_selectors: If True, emit selectors at the top level of the
            <style> block instead of nested inside a diagram-type wrapper.
            Required for deployment diagrams where PlantUML ignores the
            nested form.

    Returns:
        Lines for the complete <style>...</style> block, empty list if no styles set
    """
    # Collect diagram block content
    diagram_props: list[str] = []

    # Root-level properties
    if root_background:
        diagram_props.append(f"  BackgroundColor {render_color(root_background)}")
    if root_font_name:
        diagram_props.append(f"  FontName {root_font_name}")
    if root_font_size:
        diagram_props.append(f"  FontSize {root_font_size}")
    if root_font_color:
        diagram_props.append(f"  FontColor {render_color(root_font_color)}")

    # Element-specific styles
    for selector, elem_style in element_styles:
        if elem_style:
            diagram_props.extend(render_element_style_block(selector, elem_style))

    # Arrow styles
    if arrow_style:
        diagram_props.extend(render_arrow_style_block(arrow_style))

    # Depth-level styles (for mindmap/WBS)
    if depths:
        for depth_level in sorted(depths):
            depth_style = depths[depth_level]
            diagram_props.extend(
                render_element_style_block(f":depth({depth_level})", depth_style)
            )

    # Stereotype styles
    if stereotypes:
        for name in sorted(stereotypes):
            stereo_style = stereotypes[name]
            diagram_props.extend(
                render_element_style_block(f".{name}", stereo_style)
            )

    # Collect document block content (for title)
    document_props: list[str] = []
    if title_style:
        document_props.extend(render_element_style_block("title", title_style))

    # Only emit style block if there's content
    if not diagram_props and not document_props:
        return []

    lines: list[str] = ["<style>"]

    if top_level_selectors:
        # Emit selectors at top level (required for deployment diagrams)
        lines.extend(diagram_props)
    elif diagram_props:
        # Emit nested inside diagram-type wrapper (most diagram types)
        lines.append(f"{diagram_type} {{")
        lines.extend(diagram_props)
        lines.append("}")

    # Emit document block for title styling
    if document_props:
        lines.append("document {")
        lines.extend(document_props)
        lines.append("}")

    lines.append("</style>")
    return lines
