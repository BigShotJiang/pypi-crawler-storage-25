# `kanberoo-api` has been renamed

This package has been renamed to [`kanbaroo-api`](https://pypi.org/project/kanbaroo-api/). The name is a portmanteau of `kangaroo` + `kanban`; the middle letter should have been `a` from the start.

## What to install

```
pip install kanbaroo-api
```

Or, with the `web` extra:

```
pip install 'kanbaroo-api[web]'
```

## Compatibility

This `kanberoo-api` package remains on PyPI as a version-`0.2.2` compatibility stub that transitively installs `kanbaroo-api==0.2.2`. `pip install kanberoo-api` still works; the canonical name going forward is `kanbaroo-api`. Please update your requirements files and scripts.

## Links

- New package: https://pypi.org/project/kanbaroo-api/
- GitHub: https://github.com/areese801/kanbaroo
