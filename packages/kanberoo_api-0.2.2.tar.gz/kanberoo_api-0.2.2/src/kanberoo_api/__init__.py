"""
This package has been renamed to kanbaroo-api.

Install kanbaroo-api instead: pip install kanbaroo-api
"""

import warnings

warnings.warn(
    "The 'kanberoo-api' package has been renamed to 'kanbaroo-api'. "
    "Please update your installation: pip install kanbaroo-api",
    DeprecationWarning,
    stacklevel=2,
)

__version__ = "0.2.2"
