# ================= STANDARD LIB =================
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# ================= DATA =================
import pandas as pd

# ================= UTILITIES =================
from alive_progress import alive_bar

from .utils import get_client,json_parser


structured_signal_scoring_prompt_template = """
You are an expert evaluation agent for spatial reasoning tasks. Your job is to rigorously evaluate a model's response.

Return ONLY a valid JSON object. Do NOT include any explanation, markdown, or extra text.

================ INPUT ================

Question: {question}

Ground Truth Answer: {ground_truth}

Model Response: {model_output}


================ INSTRUCTIONS ================

Follow these rules strictly:

1. Accuracy Score (0/1):
- 1 if the final answer is correct.
- 0 otherwise.
- For OE: use semantic equivalence.

2. Refusal Score (0/1):
- 1 if the model refuses (e.g., "I cannot answer", "insufficient information").
- 0 otherwise.

3. Off Topic Score (0/1):
- 1 if response is irrelevant.
- 0 if relevant.

4. Extract Reasoning:
- Extract and summarize the reasoning for the Score.

5. Spatial Elements Score (0/1):
- 1 if key spatial objects/entities are correctly identified.
- 0 otherwise.

6. Spatial Relations Score (0/1):
- 1 if spatial relations (left/right/above/below/etc.) are correct.
- 0 otherwise.

7. Spatial Reasoning Score (0/1):
- 1 if logical spatial reasoning is correct.
- 0 otherwise.

================ OUTPUT FORMAT ================

Return STRICT JSON only (no trailing commas, no Python types, use null not None):


{{
  "accuracy_score": 0,
  "refusal_score": 0,
  "off_topic_score": 0,
  "reasoning": "",
  "spatial_elements_score": 0,
  "spatial_relations_score": 0,
  "spatial_reasoning_score": 0
}}


"""











    





def process_row_for_signal_extraction(row,model_name):

    max_retry=5
    retry_count=0
    while retry_count<max_retry:
        client = get_client()
        
        try:
            
            correct_answer = row["answer"]
            model_answer = row["response"]
            question = row["task_description"]


            prompt = structured_signal_scoring_prompt_template.format(
                question=question,
                ground_truth=correct_answer,
                model_output=model_answer
            )

            content = [{"type": "text", "text": prompt}]

            response = client.chat.completions.create(
                model=model_name,
                messages=[{"role": "user", "content": content}],
                temperature=0.1,
                max_tokens=1000,
            )
            res = json_parser(response.choices[0].message.content) if response else {}
            
            return {**row, **res}
    
        except Exception as e:
            retry_count+=1
            if retry_count==max_retry:
                print(f"Error: {e}")
                return row  # return original row if failure

def structured_signal_extraction(csv_path,prev_df=None,model_name="google/gemini-3.1-flash-image-preview",max_concurrent=10):
    save_path=(Path(csv_path.parent))
    

    
    df=pd.read_csv(csv_path)
    ids=[]
    if prev_df is not None:
        if "score" in prev_df.columns:
            prev_df=prev_df[prev_df["score"].notna()]
            ids = prev_df["id"].tolist()
            df=df[~df["id"].isin(ids)]
            print(f"Found ({len(ids)}) Previous tasks | New Tasks Remaining ({len(df)})")
            
            
            
    ds= df.to_dict(orient="records")
    model=str(save_path).split("/")[-1]

    print(f"Scoring {model}")
    results = []

    with ThreadPoolExecutor(max_workers=max_concurrent) as executor:
        futures = [executor.submit(process_row_for_signal_extraction, row,model_name ) for row in ds]
    
        with alive_bar(len(futures), bar='blocks', spinner='dots',
                       title='Scoring Agent Response', force_tty=True) as bar:
    
            for future in as_completed(futures):
                results.append(future.result())
                pd.DataFrame(results).to_csv(save_path/"agent_scores.csv",index=False)
                bar()

    pd.DataFrame(results).to_csv(save_path/"agent_scores.csv",index=False)
