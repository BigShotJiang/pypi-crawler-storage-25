from enum import IntFlag


class Keys(IntFlag):
    NONE = 0
    A = 1 << 0
    B = 1 << 1
    C = 1 << 2
    D = 1 << 3
    E = 1 << 4
    F = 1 << 5
    G = 1 << 6
    H = 1 << 7
    I = 1 << 8  # noqa: E741
    J = 1 << 9
    K = 1 << 10
    L = 1 << 11
    M = 1 << 12
    N = 1 << 13
    O = 1 << 14  # noqa: E741
    P = 1 << 15
    Q = 1 << 16
    R = 1 << 17
    S = 1 << 18
    T = 1 << 19
    U = 1 << 20
    V = 1 << 21
    W = 1 << 22
    X = 1 << 23
    Y = 1 << 24
    Z = 1 << 25
    D0 = 1 << 26
    D1 = 1 << 27
    D2 = 1 << 28
    D3 = 1 << 29
    D4 = 1 << 30
    D5 = 1 << 31
    D6 = 1 << 32
    D7 = 1 << 33
    D8 = 1 << 34
    D9 = 1 << 35
    SHIFT = 1 << 36
    ENTER = 1 << 37
    SPACE = 1 << 38
    SYMBOL_SHIFT = 1 << 39
