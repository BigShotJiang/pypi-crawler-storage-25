"""
Omnibackup - Universal Database Backup and Restore System

A production-ready Python library for backing up and restoring multiple database types
with asynchronous task processing, scheduling, and flexible storage backends.
"""

__version__ = "0.1.0"
__author__ = "Omnibackup Team"

from omnibackup.core.manager import BackupManager
from omnibackup.core.metadata import BackupMetadata

__all__ = ["BackupManager", "BackupMetadata"]
