"""Celery tasks for omnibackup."""

import logging
from celery import Celery
from celery.signals import task_failure, task_success
from omnibackup.config.celery_config import get_celery_config

logger = logging.getLogger(__name__)

# Create Celery app
celery_app = Celery("omnibackup")

# Load configuration
celery_config = get_celery_config()
celery_app.config_from_object(celery_config)


def get_manager():
    """Get configured BackupManager instance."""
    from omnibackup.core.manager import BackupManager
    from omnibackup.adapters import PostgreSQLAdapter, MySQLAdapter, MongoDBAdapter
    from omnibackup.storage import LocalStorageBackend, S3StorageBackend, GCSStorageBackend
    
    manager = BackupManager(
        storage_path=celery_config.backup_storage_path,
        metadata_backend=celery_config.metadata_backend,
        celery_app=celery_app,
    )
    
    # Register adapters
    manager.register_adapter("postgres", PostgreSQLAdapter)
    manager.register_adapter("postgresql", PostgreSQLAdapter)
    manager.register_adapter("mysql", MySQLAdapter)
    manager.register_adapter("mariadb", MySQLAdapter)
    manager.register_adapter("mongodb", MongoDBAdapter)
    manager.register_adapter("mongo", MongoDBAdapter)
    
    # Register storage backends
    manager.register_storage_backend("local", LocalStorageBackend)
    manager.register_storage_backend("s3", S3StorageBackend)
    manager.register_storage_backend("gcs", GCSStorageBackend)
    
    return manager


@celery_app.task(bind=True, max_retries=3, default_retry_delay=60)
def run_backup_task(self, database, uri, destination=None, storage_backend="local",
                    compress=True, retention_days=None, tags=None, **options):
    """
    Celery task to run a backup.
    
    Args:
        database: Database type
        uri: Database connection URI
        destination: Optional destination path
        storage_backend: Storage backend to use
        compress: Whether to compress the backup
        retention_days: Retention policy in days
        tags: Tags for the backup
        **options: Additional adapter options
        
    Returns:
        Dict with backup result information
    """
    logger.info(f"Starting backup task: {database} - Task ID: {self.request.id}")
    
    try:
        manager = get_manager()
        result = manager._run_sync(
            database=database,
            uri=uri,
            destination=destination,
            storage_backend=storage_backend,
            compress=compress,
            retention_days=retention_days,
            tags=tags,
            **options,
        )
        
        return {
            "backup_id": result.backup_id,
            "status": result.status.value,
            "size_bytes": result.size_bytes,
            "checksum": result.checksum,
            "path": str(result.path) if result.path else None,
            "error": result.error_message,
        }
        
    except Exception as exc:
        logger.error(f"Backup task failed: {exc}")
        # Retry on failure (max 3 retries with 60s delay)
        raise self.retry(exc=exc)


@celery_app.task(bind=True, max_retries=2, default_retry_delay=30)
def run_restore_task(self, backup_id, target_uri=None, **options):
    """
    Celery task to run a restore.
    
    Args:
        backup_id: ID of the backup to restore
        target_uri: Target database URI
        **options: Additional adapter options
        
    Returns:
        Dict with restore result information
    """
    logger.info(f"Starting restore task: {backup_id} - Task ID: {self.request.id}")
    
    try:
        manager = get_manager()
        result = manager._restore_sync(backup_id, target_uri, **options)
        
        return {
            "backup_id": result.backup_id,
            "status": result.status.value,
            "target_uri": result.target_uri,
            "error": result.error_message,
        }
        
    except Exception as exc:
        logger.error(f"Restore task failed: {exc}")
        raise self.retry(exc=exc)


@task_success.connect
def handle_task_success(sender=None, result=None, **kwargs):
    """Handle successful task completion."""
    logger.info(f"Task completed successfully: {sender.request.id if sender else 'unknown'}")


@task_failure.connect
def handle_task_failure(sender=None, task_id=None, exception=None, **kwargs):
    """Handle task failure."""
    logger.error(f"Task failed: {task_id} - {exception}")
