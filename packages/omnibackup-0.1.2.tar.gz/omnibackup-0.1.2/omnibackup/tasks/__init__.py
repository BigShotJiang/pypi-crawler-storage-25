"""Celery tasks for omnibackup."""

from omnibackup.tasks.backup import (
    celery_app,
    run_backup_task,
    run_restore_task,
)

__all__ = ["celery_app", "run_backup_task", "run_restore_task"]
