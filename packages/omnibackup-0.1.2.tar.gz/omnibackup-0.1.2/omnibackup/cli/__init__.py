"""CLI components for omnibackup."""

from omnibackup.cli.main import app, main

__all__ = ["app", "main"]
