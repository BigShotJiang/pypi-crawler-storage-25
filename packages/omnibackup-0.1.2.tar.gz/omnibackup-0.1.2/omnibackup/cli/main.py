"""Command-line interface for omnibackup using Typer."""

import logging
from pathlib import Path
from typing import List, Optional

import typer
from rich.console import Console
from rich.table import Table

from omnibackup.core.manager import BackupManager
from omnibackup.adapters import PostgreSQLAdapter, MySQLAdapter, MongoDBAdapter, SQLiteAdapter
from omnibackup.storage import LocalStorageBackend, S3StorageBackend, GCSStorageBackend
from omnibackup.scheduler import Scheduler, BackupSchedule
from omnibackup.tasks import celery_app
from omnibackup.config.settings import get_settings

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Typer app
app = typer.Typer(help="Omnibackup - Universal Database Backup and Restore System")
console = Console()

# Initialize components
def get_manager() -> BackupManager:
    """Get configured BackupManager instance."""
    settings = get_settings()
    manager = BackupManager(
        storage_path=settings.storage_path,
        metadata_backend=settings.metadata_backend,
        project_storage_path=settings.project_storage_path,
    )
    
    # Register adapters
    manager.register_adapter("postgres", PostgreSQLAdapter)
    manager.register_adapter("postgresql", PostgreSQLAdapter)
    manager.register_adapter("mysql", MySQLAdapter)
    manager.register_adapter("mariadb", MySQLAdapter)
    manager.register_adapter("mongodb", MongoDBAdapter)
    manager.register_adapter("mongo", MongoDBAdapter)
    manager.register_adapter("sqlite", SQLiteAdapter)
    
    # Register storage backends
    manager.register_storage_backend("local", LocalStorageBackend)
    manager.register_storage_backend("s3", S3StorageBackend)
    manager.register_storage_backend("gcs", GCSStorageBackend)
    
    return manager


def get_scheduler() -> Scheduler:
    """Get configured Scheduler instance."""
    settings = get_settings()
    return Scheduler(settings.storage_path / "schedules.db")


@app.command()
def run(
    database: str = typer.Argument(..., help="Database type (postgres, mysql, mongodb, sqlite)"),
    uri: str = typer.Argument(..., help="Database connection URI"),
    destination: Optional[str] = typer.Option(None, "--destination", "-d", help="Backup destination path"),
    storage: str = typer.Option("local", "--storage", "-s", help="Storage backend (local, s3, gcs)"),
    compress: bool = typer.Option(True, "--compress/--no-compress", help="Compress backup"),
    retention: Optional[int] = typer.Option(None, "--retention", "-r", help="Retention days"),
    tags: Optional[str] = typer.Option(None, "--tags", "-t", help="Tags (key=value,key2=value2)"),
    async_task: bool = typer.Option(False, "--async", help="Run as async Celery task"),
    wait: bool = typer.Option(False, "--wait", help="Wait for async task to complete"),
):
    """Run a backup."""
    manager = get_manager()
    
    # Parse tags
    tag_dict = {}
    if tags:
        for tag in tags.split(","):
            if "=" in tag:
                key, value = tag.split("=", 1)
                tag_dict[key.strip()] = value.strip()
    
    console.print(f"[bold blue]Starting backup:[/bold blue] {database}")
    console.print(f"URI: {uri[:uri.find('@')] if '@' in uri else uri[:20]}...")
    
    try:
        result = manager.run(
            database=database,
            uri=uri,
            destination=destination,
            storage_backend=storage,
            compress=compress,
            retention_days=retention,
            tags=tag_dict,
            async_task=async_task,
        )
        
        if async_task:
            console.print(f"[bold green]Backup task scheduled:[/bold green] {result.id}")
            
            if wait:
                console.print("Waiting for task completion...")
                result.get(timeout=3600)
                console.print("[bold green]Backup completed![/bold green]")
        else:
            console.print(f"[bold green]Backup completed:[/bold green] {result.backup_id}")
            console.print(f"  Size: {result.size_bytes:,} bytes")
            console.print(f"  Checksum: {result.checksum[:16]}...")
            console.print(f"  Path: {result.path}")
            
    except Exception as e:
        console.print(f"[bold red]Backup failed:[/bold red] {e}")
        raise typer.Exit(1)


@app.command()
def restore(
    backup_id: str = typer.Argument(..., help="Backup ID to restore"),
    target_uri: str = typer.Argument(..., help="Target database URI"),
    async_task: bool = typer.Option(False, "--async", help="Run as async Celery task"),
    wait: bool = typer.Option(False, "--wait", help="Wait for async task to complete"),
):
    """Restore from a backup."""
    manager = get_manager()
    
    console.print(f"[bold blue]Starting restore:[/bold blue] {backup_id}")
    
    try:
        result = manager.restore(
            backup_id=backup_id,
            target_uri=target_uri,
            async_task=async_task,
        )
        
        if async_task:
            console.print(f"[bold green]Restore task scheduled:[/bold green] {result.id}")
            
            if wait:
                console.print("Waiting for task completion...")
                result.get(timeout=3600)
                console.print("[bold green]Restore completed![/bold green]")
        else:
            console.print(f"[bold green]Restore completed:[/bold green] {result.backup_id}")
            console.print(f"  Status: {result.status.value}")
            
    except Exception as e:
        console.print(f"[bold red]Restore failed:[/bold red] {e}")
        raise typer.Exit(1)


@app.command()
def list_backups(
    database: Optional[str] = typer.Option(None, "--database", "-d", help="Filter by database type"),
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status"),
    limit: int = typer.Option(50, "--limit", "-n", help="Maximum number of results"),
):
    """List all backups."""
    manager = get_manager()
    
    backups = manager.list_backups(database=database, status=status, limit=limit)
    
    table = Table(title="Backups")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Database", style="green")
    table.add_column("Status", style="yellow")
    table.add_column("Size", justify="right")
    table.add_column("Started", style="dim")
    
    for backup in backups:
        size_str = f"{backup.size_bytes:,}" if backup.size_bytes else "N/A"
        table.add_row(
            backup.backup_id[:8],
            backup.database_type,
            backup.status,
            size_str,
            backup.started_at.strftime("%Y-%m-%d %H:%M"),
        )
    
    console.print(table)


@app.command()
def schedule(
    name: str = typer.Argument(..., help="Schedule name"),
    database: str = typer.Argument(..., help="Database type (postgres, mysql, mongodb, sqlite)"),
    uri: str = typer.Argument(..., help="Database connection URI"),
    frequency: str = typer.Option("daily", "--frequency", "-f", help="Schedule frequency (hourly, daily, weekly, custom)"),
    cron: Optional[str] = typer.Option(None, "--cron", "-c", help="Cron expression for custom frequency"),
    destination: Optional[str] = typer.Option(None, "--destination", "-d", help="Backup destination path"),
    storage: str = typer.Option("local", "--storage", "-s", help="Storage backend"),
    retention: Optional[int] = typer.Option(None, "--retention", "-r", help="Retention days"),
):
    """Create a backup schedule."""
    scheduler = get_scheduler()
    
    schedule_obj = BackupSchedule.create(
        name=name,
        database=database,
        uri=uri,
        frequency=frequency,
        cron_expression=cron,
        destination=destination,
        storage_backend=storage,
        retention_days=retention,
    )
    
    scheduler.add_schedule(schedule_obj)
    
    console.print(f"[bold green]Schedule created:[/bold green] {name}")
    console.print(f"  ID: {schedule_obj.schedule_id}")
    console.print(f"  Frequency: {frequency}")
    console.print(f"  Next run: {schedule_obj.next_run}")


@app.command(name="list-schedules")
def list_schedules(
    enabled_only: bool = typer.Option(False, "--enabled-only", "-e", help="Show only enabled schedules"),
):
    """List all backup schedules."""
    scheduler = get_scheduler()
    
    schedules = scheduler.list_schedules(enabled_only=enabled_only)
    
    table = Table(title="Backup Schedules")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="green")
    table.add_column("Database", style="blue")
    table.add_column("Frequency", style="yellow")
    table.add_column("Enabled", style="magenta")
    table.add_column("Next Run", style="dim")
    
    for sched in schedules:
        table.add_row(
            sched.schedule_id[:8],
            sched.name,
            sched.database,
            sched.frequency,
            "Yes" if sched.enabled else "No",
            sched.next_run.strftime("%Y-%m-%d %H:%M") if sched.next_run else "N/A",
        )
    
    console.print(table)


@app.command()
def delete_schedule(
    schedule_id: str = typer.Argument(..., help="Schedule ID to delete"),
):
    """Delete a backup schedule."""
    scheduler = get_scheduler()
    
    if scheduler.delete_schedule(schedule_id):
        console.print(f"[bold green]Schedule deleted:[/bold green] {schedule_id}")
    else:
        console.print(f"[bold red]Schedule not found:[/bold red] {schedule_id}")
        raise typer.Exit(1)


@app.command()
def status(
    task_id: Optional[str] = typer.Option(None, "--task", "-t", help="Check specific task status"),
):
    """Check Celery worker and task status."""
    if task_id:
        manager = get_manager()
        task_status = manager.task_manager.get_task_status(task_id)
        
        console.print(f"[bold]Task Status:[/bold] {task_id}")
        console.print(f"  Status: {task_status['status']}")
        console.print(f"  Ready: {task_status['ready']}")
        console.print(f"  Successful: {task_status['successful']}")
        if task_status['result']:
            console.print(f"  Result: {task_status['result']}")
        if task_status['error']:
            console.print(f"  Error: {task_status['error']}")
    else:
        # Show general Celery status
        inspector = celery_app.control.inspect()
        
        stats = inspector.stats()
        if stats:
            console.print("[bold green]Celery Workers:[/bold green]")
            for worker, info in stats.items():
                console.print(f"  {worker}: {info.get('total', {})}")
        else:
            console.print("[bold red]No Celery workers found[/bold red]")
        
        # Show active tasks
        active = inspector.active()
        if active:
            console.print("\n[bold]Active Tasks:[/bold]")
            for worker, tasks in active.items():
                for task in tasks:
                    console.print(f"  {task.get('id')}: {task.get('name')}")


@app.command()
def worker(
    loglevel: str = typer.Option("info", "--loglevel", "-l", help="Logging level"),
    concurrency: int = typer.Option(4, "--concurrency", "-c", help="Worker concurrency"),
):
    """Start Celery worker."""
    console.print("[bold blue]Starting Celery worker...[/bold blue]")
    
    argv = [
        "worker",
        "--loglevel", loglevel,
        "--concurrency", str(concurrency),
    ]
    
    celery_app.worker_main(argv)


def main():
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()
