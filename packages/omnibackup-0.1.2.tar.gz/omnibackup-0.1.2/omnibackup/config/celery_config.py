"""Celery configuration for omnibackup."""

import os
from dataclasses import dataclass
from typing import Optional


@dataclass
class CeleryConfig:
    """Celery configuration."""
    
    # Broker settings
    broker_url: str = "redis://localhost:6379/0"
    result_backend: str = "redis://localhost:6379/0"
    
    # Task settings
    task_serializer: str = "json"
    accept_content: list = None
    result_serializer: str = "json"
    timezone: str = "UTC"
    enable_utc: bool = True
    
    # Task execution
    task_track_started: bool = True
    task_time_limit: int = 3600  # 1 hour
    task_soft_time_limit: int = 3300  # 55 minutes
    
    # Result backend
    result_expires: int = 86400  # 1 day
    result_extended: bool = True
    
    # Worker settings
    worker_prefetch_multiplier: int = 1
    worker_max_tasks_per_child: int = 100
    
    # Omnibackup specific
    backup_storage_path: str = "/tmp/omnibackup"
    metadata_backend: str = "sqlite"
    
    def __post_init__(self):
        if self.accept_content is None:
            self.accept_content = ["json"]


def get_celery_config() -> CeleryConfig:
    """Get Celery configuration from environment variables."""
    return CeleryConfig(
        broker_url=os.getenv("CELERY_BROKER_URL", "redis://localhost:6379/0"),
        result_backend=os.getenv("CELERY_RESULT_BACKEND", "redis://localhost:6379/0"),
        backup_storage_path=os.getenv("OMNIBACKUP_STORAGE_PATH", "/tmp/omnibackup"),
        metadata_backend=os.getenv("OMNIBACKUP_METADATA_BACKEND", "sqlite"),
        timezone=os.getenv("CELERY_TIMEZONE", "UTC"),
    )
