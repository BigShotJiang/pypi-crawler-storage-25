"""MongoDB backup adapter using mongodump and mongorestore."""

import gzip
import hashlib
import logging
import shutil
import subprocess
import tarfile
from datetime import datetime
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from omnibackup.core.base import BaseBackupAdapter, BackupResult, BackupStatus, RestoreResult

logger = logging.getLogger(__name__)


class MongoDBAdapter(BaseBackupAdapter):
    """
    MongoDB backup adapter using mongodump and mongorestore.
    """
    
    def __init__(self, name: str, uri: str, **options):
        """
        Initialize MongoDB adapter.
        
        Args:
            name: Adapter name (should be 'mongodb' or 'mongo')
            uri: MongoDB connection URI
                Format: mongodb://user:password@host:port/database
            **options:
                - mongodump_path: Path to mongodump executable
                - mongorestore_path: Path to mongorestore executable
                - oplog: Include oplog for point-in-time recovery
                - gzip_mongodump: Use mongodump's built-in gzip compression
                - verbose: Enable verbose output
                - auth_database: Authentication database (default: admin)
        """
        super().__init__(name, uri, **options)
        self.mongodump_path = options.get("mongodump_path", "mongodump")
        self.mongorestore_path = options.get("mongorestore_path", "mongorestore")
        self.oplog = options.get("oplog", False)
        self.gzip_mongodump = options.get("gzip_mongodump", True)
        self.verbose = options.get("verbose", False)
        self.auth_database = options.get("auth_database", "admin")
        self._parsed_uri = self._parse_uri(uri)
    
    def _parse_uri(self, uri: str) -> dict:
        """Parse MongoDB URI into components."""
        parsed = urlparse(uri)
        
        # Extract database from path or options
        database = parsed.path.lstrip("/") if parsed.path else None
        
        # Parse query parameters
        options = {}
        if parsed.query:
            for param in parsed.query.split("&"):
                if "=" in param:
                    key, value = param.split("=", 1)
                    options[key] = value
        
        # Check for authSource/replicaSet in options
        auth_source = options.get("authSource", "admin")
        replica_set = options.get("replicaSet")
        
        return {
            "scheme": parsed.scheme,
            "user": parsed.username or "",
            "password": parsed.password or "",
            "host": parsed.hostname or "localhost",
            "port": parsed.port or 27017,
            "database": database,
            "auth_source": auth_source,
            "replica_set": replica_set,
            "options": options,
        }
    
    def validate_connection(self) -> bool:
        """Validate MongoDB connection using mongosh or mongo."""
        try:
            # Try mongosh first (MongoDB 5.0+), fallback to mongo
            clients = ["mongosh", "mongo"]
            
            for client in clients:
                if shutil.which(client):
                    cmd = [
                        client,
                        self.uri,
                        "--eval", "db.adminCommand('ping')",
                        "--quiet",
                    ]
                    
                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        timeout=30,
                    )
                    
                    if result.returncode == 0:
                        return True
            
            # Fallback: try mongodump --version as basic connectivity test
            cmd = [self.mongodump_path, "--version"]
            result = subprocess.run(cmd, capture_output=True, timeout=10)
            return result.returncode == 0
            
        except Exception as e:
            logger.error(f"MongoDB connection validation failed: {e}")
            return False
    
    def get_database_size(self) -> Optional[int]:
        """Get MongoDB database size in bytes."""
        try:
            client = "mongosh" if shutil.which("mongosh") else "mongo"
            
            script = f"""
                db = db.getSiblingDB("{self._parsed_uri['database'] or 'test'}");
                stats = db.stats();
                print(stats.dataSize + stats.indexSize);
            """
            
            cmd = [
                client,
                self.uri,
                "--eval", script,
                "--quiet",
            ]
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
            )
            
            if result.returncode == 0:
                try:
                    return int(result.stdout.strip().split("\n")[-1])
                except (ValueError, IndexError):
                    pass
        except Exception as e:
            logger.error(f"Failed to get database size: {e}")
        
        return None
    
    def backup(self, destination: Path, compress: bool = True) -> BackupResult:
        """
        Perform MongoDB backup using mongodump.
        
        Args:
            destination: Path where backup should be stored
            compress: Whether to gzip compress the output (tar.gz archive)
            
        Returns:
            BackupResult with operation details
        """
        started_at = datetime.utcnow()
        backup_id = destination.stem
        
        try:
            # Create temporary directory for dump
            temp_dir = destination.parent / f"temp_{backup_id}"
            temp_dir.mkdir(parents=True, exist_ok=True)
            
            # Build mongodump command
            cmd = [
                self.mongodump_path,
                "--uri", self.uri,
                "--out", str(temp_dir),
            ]
            
            if self.oplog:
                cmd.append("--oplog")
            
            if self.gzip_mongodump:
                cmd.append("--gzip")
            
            if self.verbose:
                cmd.append("--verbose")
            
            # Run mongodump
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=True,
            )
            
            # Package the dump directory
            destination.parent.mkdir(parents=True, exist_ok=True)
            
            if compress:
                # Create tar.gz archive
                with tarfile.open(str(destination), "w:gz") as tar:
                    tar.add(temp_dir, arcname=temp_dir.name)
            else:
                # Create uncompressed tar
                with tarfile.open(str(destination), "w") as tar:
                    tar.add(temp_dir, arcname=temp_dir.name)
            
            # Cleanup temp directory
            shutil.rmtree(temp_dir)
            
            # Calculate checksum
            checksum = self._calculate_checksum(destination)
            size_bytes = destination.stat().st_size if destination.exists() else 0
            
            return BackupResult(
                backup_id=backup_id,
                status=BackupStatus.SUCCESS,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                size_bytes=size_bytes,
                checksum=checksum,
                path=destination,
            )
            
        except subprocess.CalledProcessError as e:
            logger.error(f"mongodump failed: {e.stderr}")
            # Cleanup temp directory on failure
            if temp_dir.exists():
                shutil.rmtree(temp_dir)
            return BackupResult(
                backup_id=backup_id,
                status=BackupStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                error_message=f"mongodump failed: {e.stderr}",
            )
        except Exception as e:
            logger.error(f"Backup failed: {e}")
            if 'temp_dir' in locals() and temp_dir.exists():
                shutil.rmtree(temp_dir)
            return BackupResult(
                backup_id=backup_id,
                status=BackupStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                error_message=str(e),
            )
    
    def restore(self, backup_path: Path, target_uri: Optional[str] = None) -> RestoreResult:
        """
        Restore MongoDB database from backup.
        
        Args:
            backup_path: Path to the backup file (tar.gz or tar archive)
            target_uri: Optional target database URI
            
        Returns:
            RestoreResult with operation details
        """
        started_at = datetime.utcnow()
        backup_id = backup_path.stem
        
        restore_uri = target_uri or self.uri
        temp_dir = None
        
        try:
            # Create temporary directory for extraction
            temp_dir = backup_path.parent / f"restore_{backup_id}"
            temp_dir.mkdir(parents=True, exist_ok=True)
            
            # Extract archive
            with tarfile.open(str(backup_path), "r:gz" if str(backup_path).endswith(".gz") else "r") as tar:
                tar.extractall(temp_dir)
            
            # Find the dump directory (should be the first directory in temp_dir)
            dump_dirs = [d for d in temp_dir.iterdir() if d.is_dir()]
            if not dump_dirs:
                raise ValueError("No dump directory found in archive")
            
            dump_dir = dump_dirs[0]
            
            # Build mongorestore command
            cmd = [
                self.mongorestore_path,
                "--uri", restore_uri,
                "--dir", str(dump_dir),
                "--drop",  # Drop existing collections before restoring
            ]
            
            if self.gzip_mongodump or str(backup_path).endswith(".gz"):
                cmd.append("--gzip")
            
            if self.verbose:
                cmd.append("--verbose")
            
            # Run mongorestore
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=True,
            )
            
            # Cleanup temp directory
            shutil.rmtree(temp_dir)
            
            return RestoreResult(
                backup_id=backup_id,
                status=BackupStatus.SUCCESS,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                target_uri=restore_uri,
            )
            
        except subprocess.CalledProcessError as e:
            logger.error(f"mongorestore failed: {e.stderr}")
            if temp_dir and temp_dir.exists():
                shutil.rmtree(temp_dir)
            return RestoreResult(
                backup_id=backup_id,
                status=BackupStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                target_uri=restore_uri,
                error_message=f"mongorestore failed: {e.stderr}",
            )
        except Exception as e:
            logger.error(f"Restore failed: {e}")
            if temp_dir and temp_dir.exists():
                shutil.rmtree(temp_dir)
            return RestoreResult(
                backup_id=backup_id,
                status=BackupStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                target_uri=restore_uri,
                error_message=str(e),
            )
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """Calculate SHA256 checksum of a file."""
        sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256.update(chunk)
        return sha256.hexdigest()
