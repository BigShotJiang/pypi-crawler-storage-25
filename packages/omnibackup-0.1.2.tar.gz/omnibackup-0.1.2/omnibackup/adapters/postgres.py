"""PostgreSQL backup adapter using pg_dump and pg_restore."""

import gzip
import hashlib
import logging
import re
import shutil
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from omnibackup.core.base import BaseBackupAdapter, BackupResult, BackupStatus, RestoreResult

logger = logging.getLogger(__name__)


class PostgreSQLAdapter(BaseBackupAdapter):
    """
    PostgreSQL backup adapter using pg_dump and pg_restore.
    """
    
    def __init__(self, name: str, uri: str, **options):
        """
        Initialize PostgreSQL adapter.
        
        Args:
            name: Adapter name (should be 'postgres' or 'postgresql')
            uri: PostgreSQL connection URI
                Format: postgresql://user:password@host:port/database
            **options:
                - pg_dump_path: Path to pg_dump executable
                - pg_restore_path: Path to pg_restore executable
                - custom_format: Use custom format (-Fc) instead of plain SQL
                - verbose: Enable verbose output
        """
        super().__init__(name, uri, **options)
        self.pg_dump_path = options.get("pg_dump_path", "pg_dump")
        self.pg_restore_path = options.get("pg_restore_path", "pg_restore")
        self.custom_format = options.get("custom_format", False)
        self.verbose = options.get("verbose", False)
        self._parsed_uri = self._parse_uri(uri)
    
    def _parse_uri(self, uri: str) -> dict:
        """Parse PostgreSQL URI into components."""
        parsed = urlparse(uri)
        return {
            "scheme": parsed.scheme,
            "user": parsed.username or "",
            "password": parsed.password or "",
            "host": parsed.hostname or "localhost",
            "port": parsed.port or 5432,
            "database": parsed.path.lstrip("/") if parsed.path else "",
        }
    
    def _build_env(self) -> dict:
        """Build environment variables for pg_dump/pg_restore."""
        import os
        env = os.environ.copy()
        if self._parsed_uri["password"]:
            env["PGPASSWORD"] = self._parsed_uri["password"]
        return env
    
    def validate_connection(self) -> bool:
        """Validate PostgreSQL connection using psql."""
        try:
            cmd = [
                "psql",
                "-h", self._parsed_uri["host"],
                "-p", str(self._parsed_uri["port"]),
                "-U", self._parsed_uri["user"],
                "-d", self._parsed_uri["database"],
                "-c", "SELECT 1",
            ]
            
            result = subprocess.run(
                cmd,
                env=self._build_env(),
                capture_output=True,
                text=True,
                timeout=30,
            )
            return result.returncode == 0
        except Exception as e:
            logger.error(f"PostgreSQL connection validation failed: {e}")
            return False
    
    def get_database_size(self) -> Optional[int]:
        """Get PostgreSQL database size in bytes."""
        try:
            cmd = [
                "psql",
                "-h", self._parsed_uri["host"],
                "-p", str(self._parsed_uri["port"]),
                "-U", self._parsed_uri["user"],
                "-d", self._parsed_uri["database"],
                "-t",
                "-c", f"SELECT pg_database_size('{self._parsed_uri['database']}');",
            ]
            
            result = subprocess.run(
                cmd,
                env=self._build_env(),
                capture_output=True,
                text=True,
                timeout=30,
            )
            
            if result.returncode == 0:
                size_str = result.stdout.strip()
                return int(size_str)
        except Exception as e:
            logger.error(f"Failed to get database size: {e}")
        
        return None
    
    def backup(self, destination: Path, compress: bool = True) -> BackupResult:
        """
        Perform PostgreSQL backup using pg_dump.
        
        Args:
            destination: Path where backup should be stored
            compress: Whether to gzip compress the output
            
        Returns:
            BackupResult with operation details
        """
        started_at = datetime.utcnow()
        backup_id = destination.stem
        
        try:
            # Build pg_dump command
            cmd = [
                self.pg_dump_path,
                "-h", self._parsed_uri["host"],
                "-p", str(self._parsed_uri["port"]),
                "-U", self._parsed_uri["user"],
                "-d", self._parsed_uri["database"],
            ]
            
            if self.custom_format:
                cmd.append("-Fc")
            else:
                cmd.append("-Fp")  # Plain SQL format
            
            if self.verbose:
                cmd.append("-v")
            
            # Create backup
            destination.parent.mkdir(parents=True, exist_ok=True)
            
            if compress and not self.custom_format:
                # Use gzip compression for plain format
                with gzip.open(str(destination), "wb") as f:
                    result = subprocess.run(
                        cmd,
                        env=self._build_env(),
                        stdout=f,
                        stderr=subprocess.PIPE,
                        check=True,
                    )
            else:
                result = subprocess.run(
                    cmd,
                    env=self._build_env(),
                    stdout=subprocess.PIPE if self.custom_format else None,
                    stderr=subprocess.PIPE,
                    check=True,
                )
                
                if self.custom_format:
                    with open(str(destination), "wb") as f:
                        f.write(result.stdout)
            
            # Calculate checksum
            checksum = self._calculate_checksum(destination)
            size_bytes = destination.stat().st_size if destination.exists() else 0
            
            return BackupResult(
                backup_id=backup_id,
                status=BackupStatus.SUCCESS,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                size_bytes=size_bytes,
                checksum=checksum,
                path=destination,
            )
            
        except subprocess.CalledProcessError as e:
            logger.error(f"pg_dump failed: {e.stderr}")
            return BackupResult(
                backup_id=backup_id,
                status=BackupStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                error_message=f"pg_dump failed: {e.stderr}",
            )
        except Exception as e:
            logger.error(f"Backup failed: {e}")
            return BackupResult(
                backup_id=backup_id,
                status=BackupStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                error_message=str(e),
            )
    
    def restore(self, backup_path: Path, target_uri: Optional[str] = None) -> RestoreResult:
        """
        Restore PostgreSQL database from backup.
        
        Args:
            backup_path: Path to the backup file
            target_uri: Optional target database URI
            
        Returns:
            RestoreResult with operation details
        """
        started_at = datetime.utcnow()
        backup_id = backup_path.stem
        
        # Parse target URI
        if target_uri:
            target = self._parse_uri(target_uri)
        else:
            target = self._parsed_uri
        
        try:
            env = self._build_env()
            if target_uri and target["password"]:
                env["PGPASSWORD"] = target["password"]
            
            # Determine if backup is compressed
            is_compressed = str(backup_path).endswith(".gz")
            
            # Build pg_restore command (or psql for plain SQL)
            if self.custom_format or backup_path.suffix in [".dump", "custom"]:
                cmd = [
                    self.pg_restore_path,
                    "-h", target["host"],
                    "-p", str(target["port"]),
                    "-U", target["user"],
                    "-d", target["database"],
                    "-c",  # Clean (drop) objects before recreating
                    str(backup_path),
                ]
                
                result = subprocess.run(
                    cmd,
                    env=env,
                    capture_output=True,
                    text=True,
                    check=True,
                )
            else:
                # Plain SQL format - use psql
                input_stream = None
                if is_compressed:
                    # Decompress on the fly
                    cmd = ["gunzip", "-c", str(backup_path)]
                    gunzip_proc = subprocess.Popen(
                        cmd,
                        stdout=subprocess.PIPE,
                    )
                    input_stream = gunzip_proc.stdout
                
                psql_cmd = [
                    "psql",
                    "-h", target["host"],
                    "-p", str(target["port"]),
                    "-U", target["user"],
                    "-d", target["database"],
                    "-f", str(backup_path) if not is_compressed else "-",
                ]
                
                if is_compressed:
                    result = subprocess.run(
                        psql_cmd,
                        env=env,
                        stdin=input_stream,
                        capture_output=True,
                        text=True,
                        check=True,
                    )
                    gunzip_proc.wait()
                else:
                    result = subprocess.run(
                        psql_cmd,
                        env=env,
                        capture_output=True,
                        text=True,
                        check=True,
                    )
            
            return RestoreResult(
                backup_id=backup_id,
                status=BackupStatus.SUCCESS,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                target_uri=target_uri or self.uri,
            )
            
        except subprocess.CalledProcessError as e:
            logger.error(f"pg_restore/psql failed: {e.stderr}")
            return RestoreResult(
                backup_id=backup_id,
                status=BackupStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                target_uri=target_uri or self.uri,
                error_message=f"pg_restore failed: {e.stderr}",
            )
        except Exception as e:
            logger.error(f"Restore failed: {e}")
            return RestoreResult(
                backup_id=backup_id,
                status=BackupStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                target_uri=target_uri or self.uri,
                error_message=str(e),
            )
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """Calculate SHA256 checksum of a file."""
        sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256.update(chunk)
        return sha256.hexdigest()
