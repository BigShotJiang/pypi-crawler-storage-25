"""MySQL backup adapter using mysqldump and mysql."""

import gzip
import hashlib
import logging
import shutil
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from omnibackup.core.base import BaseBackupAdapter, BackupResult, BackupStatus, RestoreResult

logger = logging.getLogger(__name__)


class MySQLAdapter(BaseBackupAdapter):
    """
    MySQL/MariaDB backup adapter using mysqldump and mysql.
    """
    
    def __init__(self, name: str, uri: str, **options):
        """
        Initialize MySQL adapter.
        
        Args:
            name: Adapter name (should be 'mysql' or 'mariadb')
            uri: MySQL connection URI
                Format: mysql://user:password@host:port/database
            **options:
                - mysqldump_path: Path to mysqldump executable
                - mysql_path: Path to mysql executable
                - single_transaction: Use --single-transaction for consistent backup
                - lock_tables: Lock tables during backup
                - routines: Include stored routines
                - events: Include events
                - verbose: Enable verbose output
        """
        super().__init__(name, uri, **options)
        self.mysqldump_path = options.get("mysqldump_path", "mysqldump")
        self.mysql_path = options.get("mysql_path", "mysql")
        self.single_transaction = options.get("single_transaction", True)
        self.lock_tables = options.get("lock_tables", False)
        self.routines = options.get("routines", True)
        self.events = options.get("events", False)
        self.verbose = options.get("verbose", False)
        self._parsed_uri = self._parse_uri(uri)
    
    def _parse_uri(self, uri: str) -> dict:
        """Parse MySQL URI into components."""
        parsed = urlparse(uri)
        return {
            "scheme": parsed.scheme,
            "user": parsed.username or "",
            "password": parsed.password or "",
            "host": parsed.hostname or "localhost",
            "port": parsed.port or 3306,
            "database": parsed.path.lstrip("/") if parsed.path else "",
        }
    
    def _build_connection_args(self) -> list:
        """Build connection arguments for mysqldump/mysql."""
        args = [
            "-h", self._parsed_uri["host"],
            "-P", str(self._parsed_uri["port"]),
        ]
        
        if self._parsed_uri["user"]:
            args.extend(["-u", self._parsed_uri["user"]])
        
        if self._parsed_uri["password"]:
            args.extend([f"-p{self._parsed_uri['password']}"])
        
        return args
    
    def validate_connection(self) -> bool:
        """Validate MySQL connection."""
        try:
            cmd = [
                self.mysql_path,
                *self._build_connection_args(),
                "-e", "SELECT 1",
            ]
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
            )
            return result.returncode == 0
        except Exception as e:
            logger.error(f"MySQL connection validation failed: {e}")
            return False
    
    def get_database_size(self) -> Optional[int]:
        """Get MySQL database size in bytes."""
        try:
            query = f"""
                SELECT SUM(data_length + index_length) 
                FROM information_schema.tables 
                WHERE table_schema = '{self._parsed_uri['database']}';
            """
            
            cmd = [
                self.mysql_path,
                *self._build_connection_args(),
                "-e", query,
                "--skip-column-names",
            ]
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
            )
            
            if result.returncode == 0:
                size_str = result.stdout.strip()
                if size_str and size_str.isdigit():
                    return int(size_str)
        except Exception as e:
            logger.error(f"Failed to get database size: {e}")
        
        return None
    
    def backup(self, destination: Path, compress: bool = True) -> BackupResult:
        """
        Perform MySQL backup using mysqldump.
        
        Args:
            destination: Path where backup should be stored
            compress: Whether to gzip compress the output
            
        Returns:
            BackupResult with operation details
        """
        started_at = datetime.utcnow()
        backup_id = destination.stem
        
        try:
            # Build mysqldump command
            cmd = [
                self.mysqldump_path,
                *self._build_connection_args(),
            ]
            
            # Add options
            if self.single_transaction:
                cmd.append("--single-transaction")
            
            if not self.lock_tables:
                cmd.append("--lock-tables=false")
            
            if self.routines:
                cmd.append("--routines")
            
            if self.events:
                cmd.append("--events")
            
            if self.verbose:
                cmd.append("--verbose")
            
            # Add database
            cmd.append(self._parsed_uri["database"])
            
            # Create backup
            destination.parent.mkdir(parents=True, exist_ok=True)
            
            if compress:
                # Use gzip compression
                with gzip.open(str(destination), "wb") as f:
                    result = subprocess.run(
                        cmd,
                        stdout=f,
                        stderr=subprocess.PIPE,
                        check=True,
                    )
            else:
                with open(str(destination), "wb") as f:
                    result = subprocess.run(
                        cmd,
                        stdout=f,
                        stderr=subprocess.PIPE,
                        check=True,
                    )
            
            # Calculate checksum
            checksum = self._calculate_checksum(destination)
            size_bytes = destination.stat().st_size if destination.exists() else 0
            
            return BackupResult(
                backup_id=backup_id,
                status=BackupStatus.SUCCESS,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                size_bytes=size_bytes,
                checksum=checksum,
                path=destination,
            )
            
        except subprocess.CalledProcessError as e:
            logger.error(f"mysqldump failed: {e.stderr}")
            return BackupResult(
                backup_id=backup_id,
                status=BackupStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                error_message=f"mysqldump failed: {e.stderr}",
            )
        except Exception as e:
            logger.error(f"Backup failed: {e}")
            return BackupResult(
                backup_id=backup_id,
                status=BackupStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                error_message=str(e),
            )
    
    def restore(self, backup_path: Path, target_uri: Optional[str] = None) -> RestoreResult:
        """
        Restore MySQL database from backup.
        
        Args:
            backup_path: Path to the backup file
            target_uri: Optional target database URI
            
        Returns:
            RestoreResult with operation details
        """
        started_at = datetime.utcnow()
        backup_id = backup_path.stem
        
        # Parse target URI
        if target_uri:
            target = self._parse_uri(target_uri)
            target_args = [
                "-h", target["host"],
                "-P", str(target["port"]),
            ]
            if target["user"]:
                target_args.extend(["-u", target["user"]])
            if target["password"]:
                target_args.extend([f"-p{target['password']}"])
            target_db = target["database"]
        else:
            target_args = self._build_connection_args()
            target_db = self._parsed_uri["database"]
        
        try:
            # Determine if backup is compressed
            is_compressed = str(backup_path).endswith(".gz")
            
            if is_compressed:
                # Decompress and pipe to mysql
                gunzip_cmd = ["gunzip", "-c", str(backup_path)]
                gunzip_proc = subprocess.Popen(
                    gunzip_cmd,
                    stdout=subprocess.PIPE,
                )
                
                mysql_cmd = [
                    self.mysql_path,
                    *target_args,
                    target_db,
                ]
                
                result = subprocess.run(
                    mysql_cmd,
                    stdin=gunzip_proc.stdout,
                    capture_output=True,
                    text=True,
                    check=True,
                )
                gunzip_proc.wait()
            else:
                mysql_cmd = [
                    self.mysql_path,
                    *target_args,
                    target_db,
                ]
                
                with open(str(backup_path), "rb") as f:
                    result = subprocess.run(
                        mysql_cmd,
                        stdin=f,
                        capture_output=True,
                        text=True,
                        check=True,
                    )
            
            return RestoreResult(
                backup_id=backup_id,
                status=BackupStatus.SUCCESS,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                target_uri=target_uri or self.uri,
            )
            
        except subprocess.CalledProcessError as e:
            logger.error(f"mysql restore failed: {e.stderr}")
            return RestoreResult(
                backup_id=backup_id,
                status=BackupStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                target_uri=target_uri or self.uri,
                error_message=f"mysql restore failed: {e.stderr}",
            )
        except Exception as e:
            logger.error(f"Restore failed: {e}")
            return RestoreResult(
                backup_id=backup_id,
                status=BackupStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                target_uri=target_uri or self.uri,
                error_message=str(e),
            )
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """Calculate SHA256 checksum of a file."""
        sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256.update(chunk)
        return sha256.hexdigest()
