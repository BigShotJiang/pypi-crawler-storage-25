"""SQLite backup adapter using native SQLite operations."""

import gzip
import hashlib
import logging
import shutil
import sqlite3
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from omnibackup.core.base import BaseBackupAdapter, BackupResult, BackupStatus, RestoreResult

logger = logging.getLogger(__name__)


class SQLiteAdapter(BaseBackupAdapter):
    """
    SQLite backup adapter using native SQLite backup operations.
    
    Supports:
    - Online backups using SQLite's backup API (non-blocking)
    - File-based backups (simple copy)
    - SQL dump exports
    """
    
    BACKUP_MODE_COPY = "copy"           # Simple file copy
    BACKUP_MODE_ONLINE = "online"         # SQLite online backup
    BACKUP_MODE_SQL = "sql"               # SQL dump
    
    def __init__(self, name: str, uri: str, **options):
        """
        Initialize SQLite adapter.
        
        Args:
            name: Adapter name (should be 'sqlite')
            uri: SQLite database URI
                Format: sqlite:///path/to/database.db or just /path/to/database.db
            **options:
                - backup_mode: 'copy', 'online', or 'sql'
                - vacuum: Run VACUUM before backup (defragments database)
                - integrity_check: Run integrity check before backup
        """
        super().__init__(name, uri, **options)
        self.backup_mode = options.get("backup_mode", "online")
        self.vacuum = options.get("vacuum", False)
        self.integrity_check = options.get("integrity_check", True)
        self._db_path = self._parse_uri(uri)
    
    def _parse_uri(self, uri: str) -> Path:
        """Parse SQLite URI to get database path."""
        if uri.startswith("sqlite:///"):
            return Path(uri[10:])
        elif uri.startswith("file:"):
            parsed = urlparse(uri)
            return Path(parsed.path)
        else:
            return Path(uri)
    
    def validate_connection(self) -> bool:
        """Validate SQLite database connection."""
        try:
            if not self._db_path.exists():
                logger.error(f"Database file not found: {self._db_path}")
                return False
            
            conn = sqlite3.connect(str(self._db_path))
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            conn.close()
            return True
        except Exception as e:
            logger.error(f"SQLite connection validation failed: {e}")
            return False
    
    def get_database_size(self) -> Optional[int]:
        """Get SQLite database size in bytes."""
        try:
            if self._db_path.exists():
                return self._db_path.stat().st_size
        except Exception as e:
            logger.error(f"Failed to get database size: {e}")
        return None
    
    def _check_integrity(self) -> bool:
        """Run PRAGMA integrity_check on database."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            cursor = conn.cursor()
            cursor.execute("PRAGMA integrity_check")
            result = cursor.fetchone()
            conn.close()
            
            is_valid = result and result[0] == "ok"
            if not is_valid:
                logger.warning(f"Integrity check failed: {result}")
            return is_valid
        except Exception as e:
            logger.error(f"Integrity check error: {e}")
            return False
    
    def _run_vacuum(self) -> bool:
        """Run VACUUM to defragment database."""
        try:
            conn = sqlite3.connect(str(self._db_path))
            conn.execute("VACUUM")
            conn.close()
            logger.info("VACUUM completed successfully")
            return True
        except Exception as e:
            logger.error(f"VACUUM failed: {e}")
            return False
    
    def _backup_online(self, destination: Path) -> None:
        """
        Perform online backup using SQLite's backup API.
        This allows reading from the database while backing up.
        """
        source_conn = sqlite3.connect(str(self._db_path))
        dest_conn = sqlite3.connect(str(destination))
        
        with dest_conn:
            source_conn.backup(dest_conn, pages=100, progress=self._backup_progress)
        
        source_conn.close()
        dest_conn.close()
    
    def _backup_progress(self, status, remaining, total):
        """Callback for backup progress."""
        percent = (total - remaining) / total * 100 if total > 0 else 0
        if remaining % 10 == 0:  # Log every 10 pages
            logger.info(f"Backup progress: {percent:.1f}% ({remaining} pages remaining)")
    
    def _backup_copy(self, destination: Path) -> None:
        """Perform simple file copy backup."""
        shutil.copy2(str(self._db_path), str(destination))
    
    def _backup_sql_dump(self, destination: Path, compress: bool = True) -> None:
        """Create SQL dump of database."""
        conn = sqlite3.connect(str(self._db_path))
        
        def dump_generator():
            for line in conn.iterdump():
                yield line + "\n"
        
        if compress:
            with gzip.open(str(destination), "wt", encoding="utf-8") as f:
                for line in dump_generator():
                    f.write(line)
        else:
            with open(str(destination), "w", encoding="utf-8") as f:
                for line in dump_generator():
                    f.write(line)
        
        conn.close()
    
    def backup(self, destination: Path, compress: bool = True) -> BackupResult:
        """
        Perform SQLite backup.
        
        Args:
            destination: Path where backup should be stored
            compress: Whether to gzip compress (only for sql dump mode)
            
        Returns:
            BackupResult with operation details
        """
        started_at = datetime.utcnow()
        backup_id = destination.stem
        
        try:
            # Pre-backup checks
            if self.integrity_check and not self._check_integrity():
                return BackupResult(
                    backup_id=backup_id,
                    status=BackupStatus.FAILED,
                    started_at=started_at,
                    completed_at=datetime.utcnow(),
                    error_message="Database integrity check failed",
                )
            
            # Run VACUUM if requested
            if self.vacuum:
                if not self._run_vacuum():
                    logger.warning("VACUUM failed, continuing with backup")
            
            # Create destination directory
            destination.parent.mkdir(parents=True, exist_ok=True)
            
            # Determine actual destination based on mode and compression
            if self.backup_mode == "sql":
                actual_dest = destination
            else:
                # For copy and online modes, we work with .db files
                if compress and self.backup_mode != "sql":
                    actual_dest = destination.parent / (destination.stem + ".db")
                else:
                    actual_dest = destination
            
            # Perform backup
            logger.info(f"Starting {self.backup_mode} backup of {self._db_path}")
            
            if self.backup_mode == "online":
                self._backup_online(actual_dest)
            elif self.backup_mode == "copy":
                self._backup_copy(actual_dest)
            elif self.backup_mode == "sql":
                self._backup_sql_dump(destination, compress)
            else:
                raise ValueError(f"Unknown backup mode: {self.backup_mode}")
            
            # Compress if needed (for copy/online modes)
            final_path = actual_dest
            if compress and self.backup_mode in ("copy", "online"):
                compressed_path = destination.parent / (actual_dest.name + ".gz")
                with open(actual_dest, "rb") as f_in:
                    with gzip.open(str(compressed_path), "wb") as f_out:
                        shutil.copyfileobj(f_in, f_out)
                actual_dest.unlink()  # Remove uncompressed file
                final_path = compressed_path
            
            # Calculate checksum
            checksum = self._calculate_checksum(final_path)
            size_bytes = final_path.stat().st_size if final_path.exists() else 0
            
            logger.info(f"Backup completed: {final_path} ({size_bytes} bytes)")
            
            return BackupResult(
                backup_id=backup_id,
                status=BackupStatus.SUCCESS,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                size_bytes=size_bytes,
                checksum=checksum,
                path=final_path,
                metadata={
                    "backup_mode": self.backup_mode,
                    "vacuum": self.vacuum,
                    "integrity_checked": self.integrity_check,
                }
            )
            
        except Exception as e:
            logger.error(f"Backup failed: {e}")
            return BackupResult(
                backup_id=backup_id,
                status=BackupStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                error_message=str(e),
            )
    
    def restore(self, backup_path: Path, target_uri: Optional[str] = None) -> RestoreResult:
        """
        Restore SQLite database from backup.
        
        Args:
            backup_path: Path to the backup file
            target_uri: Optional target database URI (defaults to self.uri)
            
        Returns:
            RestoreResult with operation details
        """
        started_at = datetime.utcnow()
        backup_id = backup_path.stem
        
        # Determine target path
        if target_uri:
            target_path = self._parse_uri(target_uri)
        else:
            target_path = self._db_path
        
        try:
            # Create target directory
            target_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Determine if backup is compressed
            is_compressed = str(backup_path).endswith(".gz")
            is_sql_dump = str(backup_path).endswith(".sql") or str(backup_path).endswith(".sql.gz")
            
            if is_sql_dump:
                # Restore from SQL dump
                logger.info(f"Restoring from SQL dump: {backup_path}")
                
                # Remove existing database
                if target_path.exists():
                    target_path.unlink()
                
                conn = sqlite3.connect(str(target_path))
                
                if is_compressed:
                    with gzip.open(str(backup_path), "rt", encoding="utf-8") as f:
                        sql_script = f.read()
                else:
                    with open(str(backup_path), "r", encoding="utf-8") as f:
                        sql_script = f.read()
                
                conn.executescript(sql_script)
                conn.close()
                
            else:
                # Restore from database file backup
                logger.info(f"Restoring database file: {backup_path}")
                
                # Remove existing database
                if target_path.exists():
                    target_path.unlink()
                
                if is_compressed:
                    # Decompress
                    with gzip.open(str(backup_path), "rb") as f_in:
                        with open(str(target_path), "wb") as f_out:
                            shutil.copyfileobj(f_in, f_out)
                else:
                    shutil.copy2(str(backup_path), str(target_path))
            
            # Verify restored database
            if not self.validate_connection_with_path(target_path):
                raise RuntimeError("Restored database failed validation")
            
            logger.info(f"Restore completed: {target_path}")
            
            return RestoreResult(
                backup_id=backup_id,
                status=BackupStatus.SUCCESS,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                target_uri=str(target_uri) if target_uri else self.uri,
            )
            
        except Exception as e:
            logger.error(f"Restore failed: {e}")
            return RestoreResult(
                backup_id=backup_id,
                status=BackupStatus.FAILED,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                target_uri=str(target_uri) if target_uri else self.uri,
                error_message=str(e),
            )
    
    def validate_connection_with_path(self, db_path: Path) -> bool:
        """Validate connection using specific path."""
        try:
            conn = sqlite3.connect(str(db_path))
            cursor = conn.cursor()
            cursor.execute("PRAGMA integrity_check")
            result = cursor.fetchone()
            conn.close()
            return result and result[0] == "ok"
        except Exception as e:
            logger.error(f"Validation failed: {e}")
            return False
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """Calculate SHA256 checksum of a file."""
        sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256.update(chunk)
        return sha256.hexdigest()
