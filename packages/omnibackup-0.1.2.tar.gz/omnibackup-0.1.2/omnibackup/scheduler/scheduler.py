"""Backup scheduling system with cron-like support."""

import json
import logging
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional
from uuid import uuid4

from croniter import croniter

logger = logging.getLogger(__name__)


class ScheduleFrequency(Enum):
    """Schedule frequency types."""
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    HOURLY = "hourly"
    CUSTOM = "custom"


@dataclass
class BackupSchedule:
    """Backup schedule definition."""
    
    schedule_id: str
    name: str
    database: str
    uri: str
    frequency: str
    cron_expression: Optional[str] = None
    destination: Optional[str] = None
    storage_backend: str = "local"
    compress: bool = True
    retention_days: Optional[int] = None
    tags: Dict[str, str] = field(default_factory=dict)
    enabled: bool = True
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_run: Optional[datetime] = None
    next_run: Optional[datetime] = None
    
    @classmethod
    def create(
        cls,
        name: str,
        database: str,
        uri: str,
        frequency: str,
        cron_expression: Optional[str] = None,
        **kwargs
    ) -> "BackupSchedule":
        """Create a new schedule."""
        schedule = cls(
            schedule_id=str(uuid4()),
            name=name,
            database=database,
            uri=uri,
            frequency=frequency,
            cron_expression=cron_expression,
            **kwargs
        )
        schedule._calculate_next_run()
        return schedule
    
    def _calculate_next_run(self) -> Optional[datetime]:
        """Calculate the next run time based on frequency."""
        now = datetime.utcnow()
        
        if self.frequency == "daily":
            # Default: run at midnight
            from croniter import croniter
            itr = croniter("0 0 * * *", now)
            self.next_run = itr.get_next(datetime)
        elif self.frequency == "weekly":
            # Default: run Sundays at midnight
            from croniter import croniter
            itr = croniter("0 0 * * 0", now)
            self.next_run = itr.get_next(datetime)
        elif self.frequency == "hourly":
            # Run at the top of each hour
            from croniter import croniter
            itr = croniter("0 * * * *", now)
            self.next_run = itr.get_next(datetime)
        elif self.frequency == "custom" and self.cron_expression:
            try:
                from croniter import croniter
                itr = croniter(self.cron_expression, now)
                self.next_run = itr.get_next(datetime)
            except Exception as e:
                logger.error(f"Invalid cron expression: {self.cron_expression} - {e}")
                self.next_run = None
        else:
            self.next_run = None
        
        return self.next_run
    
    def should_run(self) -> bool:
        """Check if the schedule should run now."""
        if not self.enabled or not self.next_run:
            return False
        return datetime.utcnow() >= self.next_run
    
    def mark_run(self) -> None:
        """Mark the schedule as having run."""
        self.last_run = datetime.utcnow()
        self._calculate_next_run()


class Scheduler:
    """
    Backup scheduler with persistence.
    
    Manages backup schedules and triggers them when due.
    """
    
    def __init__(self, storage_path: Path):
        """
        Initialize the scheduler.
        
        Args:
            storage_path: Path for storing schedules database
        """
        self.storage_path = Path(storage_path)
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_database()
    
    def _init_database(self) -> None:
        """Initialize the schedules database."""
        conn = sqlite3.connect(str(self.storage_path))
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS schedules (
                schedule_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                database TEXT NOT NULL,
                uri TEXT NOT NULL,
                frequency TEXT NOT NULL,
                cron_expression TEXT,
                destination TEXT,
                storage_backend TEXT NOT NULL,
                compress INTEGER NOT NULL,
                retention_days INTEGER,
                tags TEXT,
                enabled INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                last_run TEXT,
                next_run TEXT
            )
        """)
        
        conn.commit()
        conn.close()
    
    def add_schedule(self, schedule: BackupSchedule) -> BackupSchedule:
        """Add a new schedule."""
        conn = sqlite3.connect(str(self.storage_path))
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO schedules VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            schedule.schedule_id,
            schedule.name,
            schedule.database,
            schedule.uri,
            schedule.frequency,
            schedule.cron_expression,
            schedule.destination,
            schedule.storage_backend,
            int(schedule.compress),
            schedule.retention_days,
            json.dumps(schedule.tags),
            int(schedule.enabled),
            schedule.created_at.isoformat(),
            schedule.last_run.isoformat() if schedule.last_run else None,
            schedule.next_run.isoformat() if schedule.next_run else None,
        ))
        
        conn.commit()
        conn.close()
        
        logger.info(f"Added schedule: {schedule.name} ({schedule.schedule_id})")
        return schedule
    
    def get_schedule(self, schedule_id: str) -> Optional[BackupSchedule]:
        """Get a schedule by ID."""
        conn = sqlite3.connect(str(self.storage_path))
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM schedules WHERE schedule_id = ?", (schedule_id,))
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return None
        
        return self._row_to_schedule(row)
    
    def list_schedules(
        self,
        enabled_only: bool = False,
        database: Optional[str] = None,
    ) -> List[BackupSchedule]:
        """List all schedules with optional filtering."""
        conn = sqlite3.connect(str(self.storage_path))
        cursor = conn.cursor()
        
        query = "SELECT * FROM schedules WHERE 1=1"
        params = []
        
        if enabled_only:
            query += " AND enabled = 1"
        if database:
            query += " AND database = ?"
            params.append(database)
        
        query += " ORDER BY created_at DESC"
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        conn.close()
        
        return [self._row_to_schedule(row) for row in rows]
    
    def update_schedule(self, schedule_id: str, **updates) -> Optional[BackupSchedule]:
        """Update a schedule."""
        schedule = self.get_schedule(schedule_id)
        if not schedule:
            return None
        
        # Update fields
        for key, value in updates.items():
            if hasattr(schedule, key):
                setattr(schedule, key, value)
        
        # Recalculate next run if frequency changed
        if "frequency" in updates or "cron_expression" in updates:
            schedule._calculate_next_run()
        
        # Save to database
        conn = sqlite3.connect(str(self.storage_path))
        cursor = conn.cursor()
        
        cursor.execute("""
            UPDATE schedules SET
                name = ?,
                database = ?,
                uri = ?,
                frequency = ?,
                cron_expression = ?,
                destination = ?,
                storage_backend = ?,
                compress = ?,
                retention_days = ?,
                tags = ?,
                enabled = ?,
                last_run = ?,
                next_run = ?
            WHERE schedule_id = ?
        """, (
            schedule.name,
            schedule.database,
            schedule.uri,
            schedule.frequency,
            schedule.cron_expression,
            schedule.destination,
            schedule.storage_backend,
            int(schedule.compress),
            schedule.retention_days,
            json.dumps(schedule.tags),
            int(schedule.enabled),
            schedule.last_run.isoformat() if schedule.last_run else None,
            schedule.next_run.isoformat() if schedule.next_run else None,
            schedule_id,
        ))
        
        conn.commit()
        conn.close()
        
        logger.info(f"Updated schedule: {schedule_id}")
        return schedule
    
    def delete_schedule(self, schedule_id: str) -> bool:
        """Delete a schedule."""
        conn = sqlite3.connect(str(self.storage_path))
        cursor = conn.cursor()
        
        cursor.execute("DELETE FROM schedules WHERE schedule_id = ?", (schedule_id,))
        conn.commit()
        deleted = cursor.rowcount > 0
        conn.close()
        
        if deleted:
            logger.info(f"Deleted schedule: {schedule_id}")
        
        return deleted
    
    def get_due_schedules(self) -> List[BackupSchedule]:
        """Get all schedules that are due to run."""
        now = datetime.utcnow().isoformat()
        
        conn = sqlite3.connect(str(self.storage_path))
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT * FROM schedules WHERE enabled = 1 AND next_run <= ?",
            (now,)
        )
        rows = cursor.fetchall()
        conn.close()
        
        return [self._row_to_schedule(row) for row in rows]
    
    def run_scheduler(self, backup_manager) -> List[str]:
        """
        Run the scheduler and execute due backups.
        
        Args:
            backup_manager: BackupManager instance to use for running backups
            
        Returns:
            List of task IDs for scheduled backups
        """
        due_schedules = self.get_due_schedules()
        task_ids = []
        
        for schedule in due_schedules:
            try:
                # Mark as running
                schedule.mark_run()
                self.update_schedule(
                    schedule.schedule_id,
                    last_run=schedule.last_run,
                    next_run=schedule.next_run,
                )
                
                # Run backup
                result = backup_manager.run(
                    database=schedule.database,
                    uri=schedule.uri,
                    destination=schedule.destination,
                    storage_backend=schedule.storage_backend,
                    compress=schedule.compress,
                    retention_days=schedule.retention_days,
                    tags=schedule.tags,
                    async_task=True,
                )
                
                task_ids.append(result.id)
                logger.info(f"Scheduled backup started: {result.id} for {schedule.name}")
                
            except Exception as e:
                logger.error(f"Failed to run scheduled backup {schedule.name}: {e}")
        
        return task_ids
    
    def _row_to_schedule(self, row: tuple) -> BackupSchedule:
        """Convert database row to BackupSchedule."""
        return BackupSchedule(
            schedule_id=row[0],
            name=row[1],
            database=row[2],
            uri=row[3],
            frequency=row[4],
            cron_expression=row[5],
            destination=row[6],
            storage_backend=row[7],
            compress=bool(row[8]),
            retention_days=row[9],
            tags=json.loads(row[10]) if row[10] else {},
            enabled=bool(row[11]),
            created_at=datetime.fromisoformat(row[12]),
            last_run=datetime.fromisoformat(row[13]) if row[13] else None,
            next_run=datetime.fromisoformat(row[14]) if row[14] else None,
        )
