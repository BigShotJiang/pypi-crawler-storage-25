"""Core abstractions and base classes for omnibackup."""

from omnibackup.core.base import (
    BackupStatus,
    BackupResult,
    RestoreResult,
    BaseBackupAdapter,
    StorageBackend,
)
from omnibackup.core.manager import BackupManager
from omnibackup.core.metadata import BackupMetadata, MetadataStore
from omnibackup.core.task_manager import TaskManager

__all__ = [
    "BackupStatus",
    "BackupResult",
    "RestoreResult",
    "BaseBackupAdapter",
    "StorageBackend",
    "BackupManager",
    "BackupMetadata",
    "MetadataStore",
    "TaskManager",
]
