"""Backup metadata tracking system."""

import json
import sqlite3
import hashlib
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
from uuid import uuid4


@dataclass
class BackupMetadata:
    """Metadata for a single backup operation."""
    
    backup_id: str
    database_type: str
    database_uri: str  # Stored in hashed form for security
    started_at: datetime
    completed_at: Optional[datetime] = None
    status: str = "pending"
    size_bytes: Optional[int] = None
    checksum: Optional[str] = None
    storage_path: Optional[str] = None
    storage_backend: str = "local"
    compressed: bool = True
    error_message: Optional[str] = None
    retention_days: Optional[int] = None
    tags: Dict[str, str] = field(default_factory=dict)
    extra: Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def create(
        cls,
        database_type: str,
        database_uri: str,
        storage_backend: str = "local",
        compressed: bool = True,
        retention_days: Optional[int] = None,
        tags: Optional[Dict[str, str]] = None,
    ) -> "BackupMetadata":
        """Create a new backup metadata instance."""
        return cls(
            backup_id=str(uuid4()),
            database_type=database_type,
            database_uri=cls._hash_uri(database_uri),
            started_at=datetime.utcnow(),
            storage_backend=storage_backend,
            compressed=compressed,
            retention_days=retention_days,
            tags=tags or {},
        )
    
    @staticmethod
    def _hash_uri(uri: str) -> str:
        """Hash the database URI for secure storage."""
        return hashlib.sha256(uri.encode()).hexdigest()[:16]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BackupMetadata":
        """Create from dictionary."""
        return cls(**data)


class MetadataStore:
    """
    Store for backup metadata.
    
    Supports both JSON file and SQLite backends.
    """
    
    def __init__(self, storage_path: Path, backend: str = "sqlite"):
        """
        Initialize the metadata store.
        
        Args:
            storage_path: Path to store metadata
            backend: Storage backend type ('json' or 'sqlite')
        """
        self.storage_path = Path(storage_path)
        self.backend = backend
        
        if backend == "sqlite":
            self._init_sqlite()
        else:
            self.storage_path.mkdir(parents=True, exist_ok=True)
    
    def _init_sqlite(self) -> None:
        """Initialize SQLite database."""
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self.storage_path))
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS backups (
                backup_id TEXT PRIMARY KEY,
                database_type TEXT NOT NULL,
                database_uri TEXT NOT NULL,
                started_at TEXT NOT NULL,
                completed_at TEXT,
                status TEXT NOT NULL,
                size_bytes INTEGER,
                checksum TEXT,
                storage_path TEXT,
                storage_backend TEXT NOT NULL,
                compressed INTEGER NOT NULL,
                error_message TEXT,
                retention_days INTEGER,
                tags TEXT,
                extra TEXT
            )
        """)
        
        conn.commit()
        conn.close()
    
    def save(self, metadata: BackupMetadata) -> None:
        """Save backup metadata."""
        if self.backend == "sqlite":
            self._save_sqlite(metadata)
        else:
            self._save_json(metadata)
    
    def _save_sqlite(self, metadata: BackupMetadata) -> None:
        """Save to SQLite database."""
        conn = sqlite3.connect(str(self.storage_path))
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT OR REPLACE INTO backups VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            )
        """, (
            metadata.backup_id,
            metadata.database_type,
            metadata.database_uri,
            metadata.started_at.isoformat(),
            metadata.completed_at.isoformat() if metadata.completed_at else None,
            metadata.status,
            metadata.size_bytes,
            metadata.checksum,
            metadata.storage_path,
            metadata.storage_backend,
            int(metadata.compressed),
            metadata.error_message,
            metadata.retention_days,
            json.dumps(metadata.tags),
            json.dumps(metadata.extra),
        ))
        
        conn.commit()
        conn.close()
    
    def _save_json(self, metadata: BackupMetadata) -> None:
        """Save to JSON file."""
        file_path = self.storage_path / f"{metadata.backup_id}.json"
        with open(file_path, "w") as f:
            json.dump(metadata.to_dict(), f, indent=2, default=str)
    
    def get(self, backup_id: str) -> Optional[BackupMetadata]:
        """Get metadata by backup ID."""
        if self.backend == "sqlite":
            return self._get_sqlite(backup_id)
        return self._get_json(backup_id)
    
    def _get_sqlite(self, backup_id: str) -> Optional[BackupMetadata]:
        """Get from SQLite database."""
        conn = sqlite3.connect(str(self.storage_path))
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM backups WHERE backup_id = ?", (backup_id,))
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return None
        
        return self._row_to_metadata(row)
    
    def _get_json(self, backup_id: str) -> Optional[BackupMetadata]:
        """Get from JSON file."""
        file_path = self.storage_path / f"{backup_id}.json"
        if not file_path.exists():
            return None
        
        with open(file_path) as f:
            data = json.load(f)
        
        return BackupMetadata.from_dict(data)
    
    def list_all(self, database_type: Optional[str] = None) -> List[BackupMetadata]:
        """List all backup metadata, optionally filtered by database type."""
        if self.backend == "sqlite":
            return self._list_sqlite(database_type)
        return self._list_json(database_type)
    
    def _list_sqlite(self, database_type: Optional[str] = None) -> List[BackupMetadata]:
        """List from SQLite database."""
        conn = sqlite3.connect(str(self.storage_path))
        cursor = conn.cursor()
        
        if database_type:
            cursor.execute(
                "SELECT * FROM backups WHERE database_type = ? ORDER BY started_at DESC",
                (database_type,)
            )
        else:
            cursor.execute("SELECT * FROM backups ORDER BY started_at DESC")
        
        rows = cursor.fetchall()
        conn.close()
        
        return [self._row_to_metadata(row) for row in rows]
    
    def _list_json(self, database_type: Optional[str] = None) -> List[BackupMetadata]:
        """List from JSON files."""
        results = []
        for file_path in self.storage_path.glob("*.json"):
            with open(file_path) as f:
                data = json.load(f)
                if database_type is None or data.get("database_type") == database_type:
                    results.append(BackupMetadata.from_dict(data))
        
        return sorted(results, key=lambda x: x.started_at, reverse=True)
    
    def delete(self, backup_id: str) -> bool:
        """Delete metadata by backup ID."""
        if self.backend == "sqlite":
            conn = sqlite3.connect(str(self.storage_path))
            cursor = conn.cursor()
            cursor.execute("DELETE FROM backups WHERE backup_id = ?", (backup_id,))
            conn.commit()
            deleted = cursor.rowcount > 0
            conn.close()
            return deleted
        else:
            file_path = self.storage_path / f"{backup_id}.json"
            if file_path.exists():
                file_path.unlink()
                return True
            return False
    
    def _row_to_metadata(self, row: tuple) -> BackupMetadata:
        """Convert SQLite row to BackupMetadata."""
        return BackupMetadata(
            backup_id=row[0],
            database_type=row[1],
            database_uri=row[2],
            started_at=datetime.fromisoformat(row[3]),
            completed_at=datetime.fromisoformat(row[4]) if row[4] else None,
            status=row[5],
            size_bytes=row[6],
            checksum=row[7],
            storage_path=row[8],
            storage_backend=row[9],
            compressed=bool(row[10]),
            error_message=row[11],
            retention_days=row[12],
            tags=json.loads(row[13]) if row[13] else {},
            extra=json.loads(row[14]) if row[14] else {},
        )
