"""Main BackupManager implementation."""

import gzip
import hashlib
import logging
import shutil
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Type

from omnibackup.core.base import BaseBackupAdapter, BackupResult, BackupStatus, RestoreResult, StorageBackend
from omnibackup.core.metadata import BackupMetadata, MetadataStore
from omnibackup.core.task_manager import TaskManager

logger = logging.getLogger(__name__)


class BackupManager:
    """
    Main manager class for backup and restore operations.
    
    Provides a unified API for:
    - Running backups synchronously or asynchronously
    - Restoring from backups
    - Managing retention policies
    - Tracking backup metadata
    """
    
    _adapters: Dict[str, Type[BaseBackupAdapter]] = {}
    _storage_backends: Dict[str, Type[StorageBackend]] = {}
    
    def __init__(
        self,
        storage_path: Optional[Path] = None,
        metadata_backend: str = "sqlite",
        celery_app: Optional[Any] = None,
        project_storage_path: Optional[Path] = None,
    ):
        """
        Initialize the backup manager.
        
        Args:
            storage_path: Base path for local storage and metadata
            metadata_backend: Backend for metadata storage ('sqlite' or 'json')
            celery_app: Optional Celery application for async tasks
            project_storage_path: Optional path for project-local backup storage
        """
        self.storage_path = Path(storage_path) if storage_path else Path("/tmp/omnibackup")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self.project_storage_path = Path(project_storage_path) if project_storage_path else None
        if self.project_storage_path:
            self.project_storage_path.mkdir(parents=True, exist_ok=True)
        
        # Initialize metadata store
        metadata_path = self.storage_path / "metadata.db" if metadata_backend == "sqlite" else self.storage_path / "metadata"
        self.metadata_store = MetadataStore(metadata_path, backend=metadata_backend)
        
        # Initialize task manager
        self.task_manager = TaskManager(celery_app)
        
        # Storage backends registry
        self._storage_instances: Dict[str, StorageBackend] = {}
        
        logger.info(f"BackupManager initialized with storage at {self.storage_path}")
    
    @classmethod
    def register_adapter(cls, name: str, adapter_class: Type[BaseBackupAdapter]) -> None:
        """
        Register a database adapter.
        
        Args:
            name: Adapter identifier (e.g., 'postgres', 'mysql')
            adapter_class: Adapter class inheriting from BaseBackupAdapter
        """
        cls._adapters[name] = adapter_class
        logger.info(f"Registered adapter: {name}")
    
    @classmethod
    def register_storage_backend(cls, name: str, backend_class: Type[StorageBackend]) -> None:
        """
        Register a storage backend.
        
        Args:
            name: Backend identifier (e.g., 'local', 's3')
            backend_class: Backend class inheriting from StorageBackend
        """
        cls._storage_backends[name] = backend_class
        logger.info(f"Registered storage backend: {name}")
    
    def get_storage_backend(self, name: str, **options) -> StorageBackend:
        """Get or create a storage backend instance."""
        if name not in self._storage_instances:
            if name not in self._storage_backends:
                raise ValueError(f"Storage backend '{name}' not registered")
            
            backend_class = self._storage_backends[name]
            self._storage_instances[name] = backend_class(name, **options)
        
        return self._storage_instances[name]
    
    def run(
        self,
        database: str,
        uri: str,
        destination: Optional[str] = None,
        storage_backend: str = "local",
        compress: bool = True,
        retention_days: Optional[int] = None,
        tags: Optional[Dict[str, str]] = None,
        async_task: bool = False,
        **options,
    ) -> Any:
        """
        Run a backup operation.
        
        Args:
            database: Database type (e.g., 'postgres', 'mysql', 'mongodb')
            uri: Database connection URI
            destination: Destination path (defaults to auto-generated)
            storage_backend: Storage backend to use
            compress: Whether to compress the backup
            retention_days: Number of days to retain the backup
            tags: Optional tags for the backup
            async_task: Whether to run asynchronously via Celery
            **options: Additional adapter-specific options
            
        Returns:
            BackupResult if sync, AsyncResult if async
        """
        if async_task:
            # Import here to avoid circular dependency
            from omnibackup.tasks.backup import run_backup_task
            
            return run_backup_task.delay(
                database=database,
                uri=uri,
                destination=destination,
                storage_backend=storage_backend,
                compress=compress,
                retention_days=retention_days,
                tags=tags,
                **options,
            )
        
        return self._run_sync(
            database=database,
            uri=uri,
            destination=destination,
            storage_backend=storage_backend,
            compress=compress,
            retention_days=retention_days,
            tags=tags,
            **options,
        )
    
    def _run_sync(
        self,
        database: str,
        uri: str,
        destination: Optional[str] = None,
        storage_backend: str = "local",
        compress: bool = True,
        retention_days: Optional[int] = None,
        tags: Optional[Dict[str, str]] = None,
        **options,
    ) -> BackupResult:
        """Run backup synchronously."""
        
        # Get adapter
        if database not in self._adapters:
            raise ValueError(f"Database adapter '{database}' not registered. Available: {list(self._adapters.keys())}")
        
        adapter_class = self._adapters[database]
        adapter = adapter_class(database, uri, **options)
        
        # Validate connection
        if not adapter.validate_connection():
            raise ConnectionError(f"Failed to connect to {database} database at {uri}")
        
        # Create metadata
        metadata = BackupMetadata.create(
            database_type=database,
            database_uri=uri,
            storage_backend=storage_backend,
            compressed=compress,
            retention_days=retention_days,
            tags=tags,
        )
        
        # Generate destination path
        if destination is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{database}_{timestamp}_{metadata.backup_id[:8]}"
            if compress:
                filename += ".sql.gz" if database != "mongodb" else ".archive.gz"
            else:
                filename += ".sql" if database != "mongodb" else ".archive"
            destination = str(self.storage_path / "backups" / filename)
        
        dest_path = Path(destination)
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Run backup
        logger.info(f"Starting backup: {metadata.backup_id} for {database}")
        metadata.status = "running"
        self.metadata_store.save(metadata)
        
        try:
            result = adapter.backup(dest_path, compress=compress)
            
            # Update metadata with results
            metadata.status = "success"
            metadata.completed_at = datetime.utcnow()
            metadata.size_bytes = result.size_bytes
            metadata.checksum = result.checksum
            metadata.storage_path = str(result.path)
            
            # Store in storage backend if not local
            if storage_backend != "local":
                backend = self.get_storage_backend(storage_backend)
                stored_path = backend.store(result.path, str(dest_path.name))
                metadata.storage_path = str(stored_path)
            
            # Copy to project storage if configured
            if self.project_storage_path:
                project_backup_path = self.project_storage_path / dest_path.name
                shutil.copy2(str(result.path), str(project_backup_path))
                logger.info(f"Backup also saved to project: {project_backup_path}")
            
            self.metadata_store.save(metadata)
            
            # Apply retention policy
            if retention_days:
                self._apply_retention(database, retention_days)
            
            logger.info(f"Backup completed: {metadata.backup_id}")
            return result
            
        except Exception as e:
            logger.error(f"Backup failed: {metadata.backup_id} - {e}")
            metadata.status = "failed"
            metadata.completed_at = datetime.utcnow()
            metadata.error_message = str(e)
            self.metadata_store.save(metadata)
            raise
    
    def restore(
        self,
        backup_id: str,
        target_uri: Optional[str] = None,
        async_task: bool = False,
        **options,
    ) -> Any:
        """
        Restore from a backup.
        
        Args:
            backup_id: ID of the backup to restore
            target_uri: Target database URI (defaults to original URI)
            async_task: Whether to run asynchronously via Celery
            **options: Additional adapter-specific options
            
        Returns:
            RestoreResult if sync, AsyncResult if async
        """
        if async_task:
            from omnibackup.tasks.backup import run_restore_task
            return run_restore_task.delay(backup_id, target_uri, **options)
        
        return self._restore_sync(backup_id, target_uri, **options)
    
    def _restore_sync(
        self,
        backup_id: str,
        target_uri: Optional[str] = None,
        **options,
    ) -> RestoreResult:
        """Restore synchronously."""
        
        # Get backup metadata
        metadata = self.metadata_store.get(backup_id)
        if not metadata:
            raise ValueError(f"Backup not found: {backup_id}")
        
        if metadata.status != "success":
            raise ValueError(f"Backup {backup_id} is not in success status")
        
        # Get adapter
        database = metadata.database_type
        if database not in self._adapters:
            raise ValueError(f"Database adapter '{database}' not registered")
        
        # Determine target URI
        # Note: In production, you'd need to decrypt/retrieve the original URI
        if target_uri is None:
            raise ValueError("target_uri is required for restore (original URI not stored for security)")
        
        adapter_class = self._adapters[database]
        adapter = adapter_class(database, target_uri, **options)
        
        # Get backup file path
        backup_path = Path(metadata.storage_path)
        
        # If stored in non-local backend, retrieve it first
        if metadata.storage_backend != "local":
            backend = self.get_storage_backend(metadata.storage_backend)
            temp_path = self.storage_path / "temp" / backup_path.name
            temp_path.parent.mkdir(parents=True, exist_ok=True)
            backup_path = backend.retrieve(str(backup_path), temp_path)
        
        logger.info(f"Starting restore: {backup_id} to {database}")
        
        try:
            result = adapter.restore(backup_path, target_uri)
            logger.info(f"Restore completed: {backup_id}")
            return result
        except Exception as e:
            logger.error(f"Restore failed: {backup_id} - {e}")
            raise
    
    def _apply_retention(self, database: str, retention_days: int) -> None:
        """Apply retention policy for a database type."""
        from datetime import timedelta
        
        cutoff_date = datetime.utcnow() - timedelta(days=retention_days)
        backups = self.metadata_store.list_all(database_type=database)
        
        for backup in backups:
            if backup.started_at < cutoff_date and backup.status == "success":
                try:
                    # Delete from storage
                    if backup.storage_path:
                        if backup.storage_backend == "local":
                            path = Path(backup.storage_path)
                            if path.exists():
                                path.unlink()
                        else:
                            backend = self.get_storage_backend(backup.storage_backend)
                            backend.delete(backup.storage_path)
                    
                    # Delete metadata
                    self.metadata_store.delete(backup.backup_id)
                    logger.info(f"Deleted old backup: {backup.backup_id}")
                except Exception as e:
                    logger.warning(f"Failed to delete old backup {backup.backup_id}: {e}")
    
    def list_backups(
        self,
        database: Optional[str] = None,
        status: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[BackupMetadata]:
        """
        List backups with optional filtering.
        
        Args:
            database: Filter by database type
            status: Filter by status
            limit: Maximum number of results
            
        Returns:
            List of backup metadata
        """
        backups = self.metadata_store.list_all(database_type=database)
        
        if status:
            backups = [b for b in backups if b.status == status]
        
        if limit:
            backups = backups[:limit]
        
        return backups
    
    def get_backup(self, backup_id: str) -> Optional[BackupMetadata]:
        """Get a single backup by ID."""
        return self.metadata_store.get(backup_id)
    
    def delete_backup(self, backup_id: str) -> bool:
        """Delete a backup and its metadata."""
        metadata = self.metadata_store.get(backup_id)
        if not metadata:
            return False
        
        # Delete from storage
        if metadata.storage_path:
            try:
                if metadata.storage_backend == "local":
                    path = Path(metadata.storage_path)
                    if path.exists():
                        path.unlink()
                else:
                    backend = self.get_storage_backend(metadata.storage_backend)
                    backend.delete(metadata.storage_path)
            except Exception as e:
                logger.warning(f"Failed to delete backup file {backup_id}: {e}")
        
        # Delete metadata
        return self.metadata_store.delete(backup_id)
