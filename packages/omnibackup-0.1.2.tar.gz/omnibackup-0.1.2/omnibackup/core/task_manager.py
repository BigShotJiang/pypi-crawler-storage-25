"""Task management for Celery integration."""

from typing import Any, Callable, Dict, Optional
from celery import Celery, Task
from celery.result import AsyncResult
from omnibackup.core.base import BackupResult, RestoreResult


class TaskManager:
    """
    Manager for Celery task operations.
    
    Handles task creation, status tracking, and result retrieval.
    """
    
    def __init__(self, celery_app: Optional[Celery] = None):
        """
        Initialize the task manager.
        
        Args:
            celery_app: Optional Celery application instance
        """
        self.celery = celery_app
        self._tasks: Dict[str, Task] = {}
    
    def register_celery_app(self, celery_app: Celery) -> None:
        """Register a Celery application instance."""
        self.celery = celery_app
    
    def get_task_status(self, task_id: str) -> Dict[str, Any]:
        """
        Get the status of a task.
        
        Args:
            task_id: Celery task ID
            
        Returns:
            Dictionary with task status information
        """
        if not self.celery:
            raise RuntimeError("Celery app not configured")
        
        result = AsyncResult(task_id, app=self.celery)
        return {
            "task_id": task_id,
            "status": result.status,
            "ready": result.ready(),
            "successful": result.successful() if result.ready() else None,
            "result": result.result if result.ready() and result.successful() else None,
            "error": str(result.result) if result.ready() and not result.successful() else None,
        }
    
    def revoke_task(self, task_id: str, terminate: bool = False) -> bool:
        """
        Revoke a running task.
        
        Args:
            task_id: Celery task ID
            terminate: Whether to terminate the task immediately
            
        Returns:
            True if revoked successfully
        """
        if not self.celery:
            raise RuntimeError("Celery app not configured")
        
        self.celery.control.revoke(task_id, terminate=terminate)
        return True
    
    def list_active_tasks(self) -> list:
        """
        List all active tasks.
        
        Returns:
            List of active task information
        """
        if not self.celery:
            raise RuntimeError("Celery app not configured")
        
        inspector = self.celery.control.inspect()
        active = inspector.active()
        
        tasks = []
        if active:
            for worker, worker_tasks in active.items():
                for task in worker_tasks:
                    tasks.append({
                        "task_id": task.get("id"),
                        "name": task.get("name"),
                        "worker": worker,
                        "args": task.get("args"),
                        "kwargs": task.get("kwargs"),
                    })
        return tasks
