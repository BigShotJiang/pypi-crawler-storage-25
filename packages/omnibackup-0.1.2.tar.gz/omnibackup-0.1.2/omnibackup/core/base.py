"""Core abstractions and base classes for omnibackup."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Optional


class BackupStatus(Enum):
    """Status of a backup operation."""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class BackupResult:
    """Result of a backup operation."""
    backup_id: str
    status: BackupStatus
    started_at: datetime
    completed_at: Optional[datetime] = None
    size_bytes: Optional[int] = None
    checksum: Optional[str] = None
    path: Optional[Path] = None
    error_message: Optional[str] = None
    metadata: Dict[str, Any] = None

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


@dataclass
class RestoreResult:
    """Result of a restore operation."""
    backup_id: str
    status: BackupStatus
    started_at: datetime
    completed_at: Optional[datetime] = None
    target_uri: Optional[str] = None
    error_message: Optional[str] = None


class BaseBackupAdapter(ABC):
    """
    Abstract base class for database backup adapters.
    
    All database-specific adapters must inherit from this class
    and implement the backup and restore methods.
    """
    
    def __init__(self, name: str, uri: str, **options):
        """
        Initialize the adapter.
        
        Args:
            name: Adapter identifier (e.g., 'postgres', 'mysql', 'mongodb')
            uri: Connection URI for the database
            **options: Additional adapter-specific options
        """
        self.name = name
        self.uri = uri
        self.options = options
    
    @abstractmethod
    def backup(self, destination: Path, compress: bool = True) -> BackupResult:
        """
        Perform a backup of the database.
        
        Args:
            destination: Path where the backup should be stored
            compress: Whether to compress the backup
            
        Returns:
            BackupResult with operation details
        """
        pass
    
    @abstractmethod
    def restore(self, backup_path: Path, target_uri: Optional[str] = None) -> RestoreResult:
        """
        Restore a database from a backup.
        
        Args:
            backup_path: Path to the backup file
            target_uri: Optional target database URI (defaults to self.uri)
            
        Returns:
            RestoreResult with operation details
        """
        pass
    
    @abstractmethod
    def validate_connection(self) -> bool:
        """
        Validate that the database connection is working.
        
        Returns:
            True if connection is valid, False otherwise
        """
        pass
    
    @abstractmethod
    def get_database_size(self) -> Optional[int]:
        """
        Get the size of the database in bytes.
        
        Returns:
            Database size in bytes, or None if not available
        """
        pass


class StorageBackend(ABC):
    """
    Abstract base class for storage backends.
    
    All storage backends (local, S3, GCS, etc.) must inherit from this class.
    """
    
    def __init__(self, name: str, **options):
        """
        Initialize the storage backend.
        
        Args:
            name: Backend identifier (e.g., 'local', 's3', 'gcs')
            **options: Backend-specific configuration options
        """
        self.name = name
        self.options = options
    
    @abstractmethod
    def store(self, source_path: Path, destination: str) -> Path:
        """
        Store a file in the backend.
        
        Args:
            source_path: Path to the local file to store
            destination: Destination path/key in the backend
            
        Returns:
            Path to the stored file
        """
        pass
    
    @abstractmethod
    def retrieve(self, source: str, destination_path: Path) -> Path:
        """
        Retrieve a file from the backend.
        
        Args:
            source: Source path/key in the backend
            destination_path: Local path where the file should be saved
            
        Returns:
            Path to the retrieved file
        """
        pass
    
    @abstractmethod
    def delete(self, path: str) -> bool:
        """
        Delete a file from the backend.
        
        Args:
            path: Path/key of the file to delete
            
        Returns:
            True if deleted successfully, False otherwise
        """
        pass
    
    @abstractmethod
    def list_files(self, prefix: Optional[str] = None) -> list:
        """
        List files in the backend.
        
        Args:
            prefix: Optional prefix to filter files
            
        Returns:
            List of file paths/keys
        """
        pass
    
    @abstractmethod
    def exists(self, path: str) -> bool:
        """
        Check if a file exists in the backend.
        
        Args:
            path: Path/key to check
            
        Returns:
            True if file exists, False otherwise
        """
        pass
    
    @abstractmethod
    def get_size(self, path: str) -> Optional[int]:
        """
        Get the size of a file in bytes.
        
        Args:
            path: Path/key of the file
            
        Returns:
            File size in bytes, or None if not available
        """
        pass
