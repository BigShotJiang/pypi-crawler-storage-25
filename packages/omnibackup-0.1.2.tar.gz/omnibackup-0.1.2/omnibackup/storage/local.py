"""Local filesystem storage backend."""

import logging
import shutil
from pathlib import Path
from typing import Optional

from omnibackup.core.base import StorageBackend

logger = logging.getLogger(__name__)


class LocalStorageBackend(StorageBackend):
    """
    Local filesystem storage backend.
    
    Stores backup files on the local filesystem.
    """
    
    def __init__(self, name: str = "local", base_path: Optional[str] = None, **options):
        """
        Initialize local storage backend.
        
        Args:
            name: Backend name (default: 'local')
            base_path: Base directory for storing files
            **options: Additional options
        """
        super().__init__(name, **options)
        self.base_path = Path(base_path) if base_path else Path("/tmp/omnibackup/backups")
        self.base_path.mkdir(parents=True, exist_ok=True)
    
    def store(self, source_path: Path, destination: str) -> Path:
        """
        Store a file locally.
        
        Args:
            source_path: Path to the source file
            destination: Relative destination path
            
        Returns:
            Full path to the stored file
        """
        dest_path = self.base_path / destination
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        
        shutil.copy2(str(source_path), str(dest_path))
        logger.info(f"Stored file at {dest_path}")
        
        return dest_path
    
    def retrieve(self, source: str, destination_path: Path) -> Path:
        """
        Retrieve a file from local storage.
        
        Args:
            source: Source path relative to base_path
            destination_path: Destination path for the file
            
        Returns:
            Path to the retrieved file
        """
        source_path = self.base_path / source
        
        if not source_path.exists():
            raise FileNotFoundError(f"File not found: {source_path}")
        
        destination_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(source_path), str(destination_path))
        
        return destination_path
    
    def delete(self, path: str) -> bool:
        """
        Delete a file from local storage.
        
        Args:
            path: Path to the file relative to base_path
            
        Returns:
            True if deleted, False otherwise
        """
        file_path = self.base_path / path
        
        if file_path.exists():
            if file_path.is_file():
                file_path.unlink()
            else:
                shutil.rmtree(file_path)
            logger.info(f"Deleted file: {file_path}")
            return True
        
        return False
    
    def list_files(self, prefix: Optional[str] = None) -> list:
        """
        List files in local storage.
        
        Args:
            prefix: Optional prefix to filter files
            
        Returns:
            List of file paths
        """
        if prefix:
            search_path = self.base_path / prefix
            if search_path.is_dir():
                files = list(search_path.rglob("*"))
            else:
                pattern = prefix + "*"
                files = list(self.base_path.glob(pattern))
        else:
            files = list(self.base_path.rglob("*"))
        
        # Return only files (not directories)
        return [str(f.relative_to(self.base_path)) for f in files if f.is_file()]
    
    def exists(self, path: str) -> bool:
        """
        Check if a file exists.
        
        Args:
            path: Path to check
            
        Returns:
            True if file exists
        """
        return (self.base_path / path).exists()
    
    def get_size(self, path: str) -> Optional[int]:
        """
        Get file size in bytes.
        
        Args:
            path: Path to the file
            
        Returns:
            File size in bytes or None
        """
        file_path = self.base_path / path
        if file_path.exists() and file_path.is_file():
            return file_path.stat().st_size
        return None
