"""
Example usage of omnibackup library.

This file demonstrates various ways to use the omnibackup library
for database backup and restore operations.
"""

from omnibackup import BackupManager


def example_basic_backup():
    """Example: Basic PostgreSQL backup."""
    backup = BackupManager(storage_path="/tmp/backups")
    
    result = backup.run(
        database="postgres",
        uri="postgresql://user:password@localhost/mydb",
        destination="/tmp/backups/postgres_backup.sql.gz",
        compress=True,
    )
    
    print(f"Backup completed: {result.backup_id}")
    print(f"Size: {result.size_bytes} bytes")
    print(f"Path: {result.path}")


def example_async_backup():
    """Example: Async backup with Celery."""
    backup = BackupManager(storage_path="/tmp/backups")
    
    # Run backup asynchronously
    async_result = backup.run(
        database="mysql",
        uri="mysql://user:password@localhost/mydb",
        async_task=True,
    )
    
    print(f"Task ID: {async_result.id}")
    
    # Wait for completion
    result = async_result.get(timeout=3600)
    print(f"Result: {result}")


def example_scheduled_backup():
    """Example: Creating a scheduled backup."""
    from omnibackup.scheduler import Scheduler, BackupSchedule
    
    backup = BackupManager(storage_path="/tmp/backups")
    scheduler = Scheduler("/tmp/backups/schedules.db")
    
    # Create daily backup schedule
    schedule = BackupSchedule.create(
        name="daily-postgres",
        database="postgres",
        uri="postgresql://user:password@localhost/mydb",
        frequency="daily",
        retention_days=30,
        tags={"env": "production", "db": "main"},
    )
    
    scheduler.add_schedule(schedule)
    print(f"Schedule created: {schedule.schedule_id}")
    print(f"Next run: {schedule.next_run}")
    
    # Run scheduler to check for due backups
    task_ids = scheduler.run_scheduler(backup)
    print(f"Started tasks: {task_ids}")


def example_restore():
    """Example: Restore from backup."""
    backup = BackupManager(storage_path="/tmp/backups")
    
    # List available backups
    backups = backup.list_backups(database="postgres", limit=5)
    for b in backups:
        print(f"{b.backup_id}: {b.status} - {b.started_at}")
    
    if backups:
        # Restore the most recent successful backup
        latest = [b for b in backups if b.status == "success"][0]
        
        result = backup.restore(
            backup_id=latest.backup_id,
            target_uri="postgresql://user:password@localhost/mydb_restored",
        )
        
        print(f"Restore completed: {result.status}")


def example_with_retention():
    """Example: Backup with retention policy."""
    backup = BackupManager(storage_path="/tmp/backups")
    
    result = backup.run(
        database="mongodb",
        uri="mongodb://localhost:27017/mydb",
        compress=True,
        retention_days=7,  # Keep only last 7 days
    )
    
    print(f"Backup with 7-day retention: {result.backup_id}")


def example_cli_usage():
    """Example commands for CLI usage."""
    print("""
# Run a backup
omnibackup run postgres postgresql://user:pass@localhost/db

# Run async backup
omnibackup run mysql mysql://user:pass@localhost/db --async --wait

# Schedule daily backup
omnibackup schedule "daily-backup" postgres postgresql://user:pass@localhost/db --frequency daily

# List backups
omnibackup list-backups --database postgres --status success

# Restore from backup
omnibackup restore <backup-id> postgresql://user:pass@localhost/newdb

# Start Celery worker
omnibackup worker --concurrency 4
    """)


if __name__ == "__main__":
    print("Omnibackup Example Usage")
    print("=" * 50)
    
    # Uncomment the examples you want to run:
    # example_basic_backup()
    # example_async_backup()
    # example_scheduled_backup()
    # example_restore()
    # example_with_retention()
    example_cli_usage()
