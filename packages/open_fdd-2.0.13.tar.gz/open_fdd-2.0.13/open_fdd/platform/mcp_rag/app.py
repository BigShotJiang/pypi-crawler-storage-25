from __future__ import annotations

import json
import os
import secrets
from pathlib import Path
from typing import Annotated, Any

import requests
from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field

from .retrieval import RagIndex


INDEX_PATH = Path(os.getenv("OFDD_MCP_RAG_INDEX_PATH", "/app/stack/mcp-rag/index/rag_index.json"))
OFDD_API_URL = os.getenv("OFDD_MCP_OFDD_API_URL", "http://api:8000").rstrip("/")
OFDD_API_KEY = os.getenv("OFDD_MCP_OFDD_API_KEY", "")
ENABLE_ACTION_TOOLS = os.getenv("OFDD_MCP_ENABLE_ACTION_TOOLS", "false").lower() == "true"
_timeout_value = os.getenv("OFDD_MCP_HTTP_TIMEOUT_SEC")
try:
    TIMEOUT = float(_timeout_value) if _timeout_value is not None else 20.0
except ValueError:
    TIMEOUT = 20.0

app = FastAPI(title="Open-FDD MCP RAG Service", version="1.0.0")
_idx: RagIndex | None = None


class SearchDocsRequest(BaseModel):
    query: str
    top_k: int = Field(default=6, ge=1, le=25)
    tags: list[str] | None = None


class SearchApiCapabilitiesRequest(BaseModel):
    """Query/top_k only; tags are always forced to ['api'] for this endpoint."""

    model_config = ConfigDict(extra="ignore")

    query: str
    top_k: int = Field(default=6, ge=1, le=25)


class GetSectionRequest(BaseModel):
    path_or_id: str


class PlaybookRequest(BaseModel):
    task_type: str


class ImportRequest(BaseModel):
    payload: dict[str, Any]


class SparqlRequest(BaseModel):
    query: str


def _load_index() -> RagIndex:
    global _idx
    if _idx is None:
        if not INDEX_PATH.exists():
            raise HTTPException(status_code=503, detail=f"RAG index missing: {INDEX_PATH}")
        try:
            _idx = RagIndex.from_path(INDEX_PATH)
        except (OSError, json.JSONDecodeError) as err:
            raise HTTPException(
                status_code=503,
                detail=f"RAG index unreadable: {INDEX_PATH} - {err}",
            ) from err
    return _idx


def _headers() -> dict[str, str]:
    h = {"Accept": "application/json"}
    if OFDD_API_KEY:
        h["Authorization"] = f"Bearer {OFDD_API_KEY}"
    return h


def require_action_tools_auth(
    authorization: Annotated[str | None, Header()] = None,
) -> None:
    if not ENABLE_ACTION_TOOLS:
        raise HTTPException(status_code=403, detail="Action tools disabled.")
    expected = OFDD_API_KEY.strip()
    if not expected:
        raise HTTPException(
            status_code=503,
            detail="Action tools enabled but OFDD_MCP_OFDD_API_KEY is empty; refusing unauthenticated proxy.",
        )
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=403, detail="Authorization Bearer token required for action tools.")
    _scheme, _sep, rest = authorization.partition(" ")
    token = rest.strip() if rest else ""
    if not secrets.compare_digest(token, expected):
        raise HTTPException(status_code=403, detail="Invalid API key for action tools.")


def _serialize_results(query: str, rows: list[Any]) -> dict[str, Any]:
    return {
        "query": query,
        "count": len(rows),
        "results": [
            {
                "chunk_id": r.chunk_id,
                "score": round(r.score, 5),
                "source": r.source,
                "section": r.section,
                "content": r.content,
                "endpoint_refs": r.endpoint_refs,
                "tags": r.tags,
            }
            for r in rows
        ],
    }


@app.get("/health", response_model=None)
def health() -> dict[str, Any] | JSONResponse:
    body: dict[str, Any] = {
        "index_exists": INDEX_PATH.exists(),
        "index_path": str(INDEX_PATH),
        "action_tools_enabled": ENABLE_ACTION_TOOLS,
    }
    try:
        _load_index()
    except HTTPException as exc:
        detail = exc.detail if isinstance(exc.detail, str) else str(exc.detail)
        return JSONResponse(
            status_code=exc.status_code,
            content={"ok": False, **body, "error": detail},
        )
    return {"ok": True, **body}


@app.get("/manifest")
def manifest() -> dict[str, Any]:
    return {
        "name": "open-fdd-mcp-rag",
        "version": "1.0.0",
        "tools": [
            {"name": "search_docs", "route": "/tools/search_docs", "mode": "read"},
            {"name": "get_doc_section", "route": "/tools/get_doc_section", "mode": "read"},
            {"name": "search_api_capabilities", "route": "/tools/search_api_capabilities", "mode": "read"},
            {"name": "get_operator_playbook", "route": "/tools/get_operator_playbook", "mode": "read"},
            {"name": "export_data_model", "route": "/tools/export_data_model", "mode": "write_guarded"},
            {"name": "import_data_model", "route": "/tools/import_data_model", "mode": "write_guarded"},
            {"name": "rules_sync_definitions", "route": "/tools/rules_sync_definitions", "mode": "write_guarded"},
            {"name": "sparql_validate", "route": "/tools/sparql_validate", "mode": "write_guarded"},
        ],
    }


@app.post("/tools/search_docs")
def search_docs(req: SearchDocsRequest) -> dict[str, Any]:
    idx = _load_index()
    rows = idx.search(req.query, top_k=req.top_k, tags=req.tags)
    return _serialize_results(req.query, rows)


@app.post("/tools/get_doc_section")
def get_doc_section(req: GetSectionRequest) -> dict[str, Any]:
    idx = _load_index()
    data = idx.get_section(req.path_or_id)
    if not data:
        raise HTTPException(status_code=404, detail="Section not found.")
    return data


@app.post("/tools/search_api_capabilities")
def search_api_capabilities(req: SearchApiCapabilitiesRequest) -> dict[str, Any]:
    """Search indexed API/OpenAPI chunks only (tags fixed to api)."""
    idx = _load_index()
    rows = idx.search(req.query, top_k=req.top_k, tags=["api"])
    return _serialize_results(req.query, rows)


@app.post("/tools/get_operator_playbook")
def get_operator_playbook(req: PlaybookRequest) -> dict[str, Any]:
    idx = _load_index()
    prompt = f"operator playbook {req.task_type} integrity sweep overnight review"
    rows = idx.search(prompt, top_k=8, tags=["docs", "markdown"])
    return {
        "task_type": req.task_type,
        "playbook": [r.content for r in rows],
        "sources": sorted({r.source for r in rows}),
    }


@app.post("/tools/export_data_model", dependencies=[Depends(require_action_tools_auth)])
def export_data_model() -> dict[str, Any]:
    try:
        resp = requests.get(
            f"{OFDD_API_URL}/data-model/export", headers=_headers(), timeout=TIMEOUT
        )
    except requests.exceptions.RequestException as exc:
        raise HTTPException(status_code=503, detail=f"Upstream request failed: {exc}") from exc
    if resp.status_code >= 400:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)
    if not (resp.text or "").strip():
        return {"ok": True}
    return resp.json()


@app.post("/tools/import_data_model", dependencies=[Depends(require_action_tools_auth)])
def import_data_model(req: ImportRequest) -> dict[str, Any]:
    try:
        resp = requests.put(
            f"{OFDD_API_URL}/data-model/import",
            headers={**_headers(), "Content-Type": "application/json"},
            json=req.payload,
            timeout=TIMEOUT,
        )
    except requests.exceptions.RequestException as exc:
        raise HTTPException(status_code=503, detail=f"Upstream request failed: {exc}") from exc
    if resp.status_code >= 400:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)
    if not (resp.text or "").strip():
        return {"ok": True}
    return resp.json()


@app.post("/tools/rules_sync_definitions", dependencies=[Depends(require_action_tools_auth)])
def rules_sync_definitions() -> dict[str, Any]:
    try:
        resp = requests.post(
            f"{OFDD_API_URL}/rules/sync-definitions",
            headers={**_headers(), "Content-Type": "application/json"},
            json={},
            timeout=TIMEOUT,
        )
    except requests.exceptions.RequestException as exc:
        raise HTTPException(status_code=503, detail=f"Upstream request failed: {exc}") from exc
    if resp.status_code >= 400:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)
    if not (resp.text or "").strip():
        return {"ok": True}
    return resp.json()


@app.post("/tools/sparql_validate", dependencies=[Depends(require_action_tools_auth)])
def sparql_validate(req: SparqlRequest) -> dict[str, Any]:
    try:
        resp = requests.post(
            f"{OFDD_API_URL}/data-model/sparql",
            headers={**_headers(), "Content-Type": "application/json"},
            json={"query": req.query},
            timeout=TIMEOUT,
        )
    except requests.exceptions.RequestException as exc:
        raise HTTPException(status_code=503, detail=f"Upstream request failed: {exc}") from exc
    if resp.status_code >= 400:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)
    if not (resp.text or "").strip():
        return {"ok": True}
    return resp.json()

