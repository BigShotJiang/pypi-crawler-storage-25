"""Server-side Python SDK for the 1st Flock Donations Embed API.

This package provides:

- :class:`Client` — async client for the Customer SDK endpoints
  (donations, recurring, webhook test).
- :func:`verify_webhook` / :func:`verify_webhook_async` — constant-time
  HMAC-SHA256 signature verification for inbound webhook deliveries,
  returning a parsed :data:`WebhookEvent`.
- :func:`idempotency_key` — convenience generator for ``Idempotency-Key``
  header values.
- A full set of typed Pydantic models for every documented request,
  response, and webhook payload.

Quickstart::

    >>> from donations_embed import Client, verify_webhook
    >>> async with Client(api_key="sk_test_…") as client:
    ...     donation = await client.get_donation("8a1b9c4d-1234-4321-9abc-def012345678")
    ...     refund = await client.refund_donation(donation.id, amount_cents=1000)

    >>> # In an inbound webhook handler
    >>> event = verify_webhook(
    ...     body=raw_body_bytes,
    ...     signature=request.headers["Flock-Signature"],
    ...     secret=os.environ["FLOCK_WEBHOOK_SECRET"],
    ... )

See the README for FastAPI / Starlette / script examples and detailed
error-handling guidance.
"""

from __future__ import annotations

from donations_embed._idempotency import idempotency_key
from donations_embed._version import __version__
from donations_embed.client import Client, Environment
from donations_embed.errors import (
    ApiError,
    AuthError,
    BadGatewayError,
    ConflictError,
    DonationsEmbedError,
    ForbiddenError,
    GoneError,
    NotFoundError,
    RateLimitError,
    ServiceUnavailableError,
    ValidationError,
    WebhookError,
    WebhookFormatError,
    WebhookSignatureError,
    WebhookTimestampError,
)
from donations_embed.models import (
    Donation,
    DonationCompletedEvent,
    DonationCreatedEvent,
    DonationCreatedEventObject,
    DonationEventDonor,
    DonationEventFundAllocation,
    DonationEventObject,
    DonationFailedEvent,
    DonationListResponse,
    DonationRefundedEvent,
    DonationRefundedEventObject,
    DonationStatus,
    EventPaymentMethod,
    FundAllocation,
    KeyFrozenEvent,
    KeyFrozenEventObject,
    KeyFrozenReason,
    PaymentMethodType,
    Recurring,
    RecurringActivatedEvent,
    RecurringCancelledEvent,
    RecurringCancelledEventObject,
    RecurringCancelResponse,
    RecurringEventObject,
    RecurringInterval,
    RecurringListResponse,
    RecurringPaymentFailedEvent,
    RecurringPaymentSucceededEvent,
    RecurringStatus,
    RefundRequest,
    RefundResponse,
    WebhookEnvelope,
    WebhookEvent,
    WebhookEventType,
    WebhookTestRequest,
    WebhookTestResponse,
)
from donations_embed.webhooks import (
    DEFAULT_TOLERANCE_SECONDS,
    verify_webhook,
    verify_webhook_async,
)

__all__ = [
    "DEFAULT_TOLERANCE_SECONDS",
    "ApiError",
    "AuthError",
    "BadGatewayError",
    "Client",
    "ConflictError",
    "Donation",
    "DonationCompletedEvent",
    "DonationCreatedEvent",
    "DonationCreatedEventObject",
    "DonationEventDonor",
    "DonationEventFundAllocation",
    "DonationEventObject",
    "DonationFailedEvent",
    "DonationListResponse",
    "DonationRefundedEvent",
    "DonationRefundedEventObject",
    "DonationStatus",
    "DonationsEmbedError",
    "Environment",
    "EventPaymentMethod",
    "ForbiddenError",
    "FundAllocation",
    "GoneError",
    "KeyFrozenEvent",
    "KeyFrozenEventObject",
    "KeyFrozenReason",
    "NotFoundError",
    "PaymentMethodType",
    "RateLimitError",
    "Recurring",
    "RecurringActivatedEvent",
    "RecurringCancelResponse",
    "RecurringCancelledEvent",
    "RecurringCancelledEventObject",
    "RecurringEventObject",
    "RecurringInterval",
    "RecurringListResponse",
    "RecurringPaymentFailedEvent",
    "RecurringPaymentSucceededEvent",
    "RecurringStatus",
    "RefundRequest",
    "RefundResponse",
    "ServiceUnavailableError",
    "ValidationError",
    "WebhookEnvelope",
    "WebhookError",
    "WebhookEvent",
    "WebhookEventType",
    "WebhookFormatError",
    "WebhookSignatureError",
    "WebhookTestRequest",
    "WebhookTestResponse",
    "WebhookTimestampError",
    "__version__",
    "idempotency_key",
    "verify_webhook",
    "verify_webhook_async",
]
