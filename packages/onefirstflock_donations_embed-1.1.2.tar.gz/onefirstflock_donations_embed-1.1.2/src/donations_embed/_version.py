"""Single source of truth for the SDK version.

Kept in its own module so internal modules (e.g. :mod:`donations_embed._http`)
can import it without dragging in the public API.
"""

from __future__ import annotations

__version__ = "1.1.0"
