"""Donation domain models — mirror of OpenAPI ``Donation``, ``RefundRequest``, etc."""

from __future__ import annotations

from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

DonationStatus = Literal["pending", "completed", "failed", "refunded", "partial_refund"]
"""Lifecycle state of a donation. Matches OpenAPI ``Donation.status``."""

PaymentMethodType = Literal["card", "ach"]
"""Payment instrument used for the donation."""


class FundAllocation(BaseModel):
    """One row of a donation's per-fund allocation."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    fund_id: UUID = Field(description="Fund identifier.")
    fund_name: str = Field(description="Human-readable fund label.")
    amount_cents: int = Field(ge=0, description="Allocated portion of the donation, in cents.")


class Donation(BaseModel):
    """A processed donation row, returned by ``GET /v1/embed/donations`` endpoints."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID = Field(description="Server-issued donation ID.")
    confirmation_id: str = Field(description="Human-readable receipt ID (e.g. ``don_8a1b9c4d``).")
    donor_name: str
    donor_email: str
    gross_amount_cents: int = Field(ge=0, description="Total charged including any cover-fees uplift.")
    fee_amount_cents: int = Field(ge=0, description="Processing fee component of ``gross_amount_cents``.")
    net_amount_cents: int = Field(ge=0, description="Amount the organization received after fees.")
    payment_method_type: PaymentMethodType
    payment_method_last4: str = Field(description="Last 4 digits of the card / bank account.")
    payment_method_brand: str | None = Field(
        default=None, description="Card brand (e.g. ``visa``); null for ACH."
    )
    funds: list[FundAllocation] = Field(default_factory=list, description="Per-fund allocations.")
    recurring_id: UUID | None = Field(
        default=None,
        description="Identifier of the recurring schedule that generated this charge, if any.",
    )
    refunded_amount_cents: int = Field(
        default=0,
        ge=0,
        description="Cumulative refunded amount; equals ``gross_amount_cents`` for a full refund.",
    )
    status: DonationStatus
    created_at: datetime


class DonationListResponse(BaseModel):
    """Paginated response from ``GET /v1/embed/donations``."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    donations: list[Donation]
    next_cursor: str | None = Field(
        default=None,
        description="Cursor for the next page; pass back as ``cursor`` query param. Null on the last page.",
    )


class RefundRequest(BaseModel):
    """Body of ``POST /v1/embed/donations/{donation_id}/refund``."""

    model_config = ConfigDict(extra="forbid")

    amount_cents: int | None = Field(
        default=None,
        ge=1,
        description="Refund amount in cents. Omit (or pass ``None``) to refund the full donation.",
    )
    reason: str | None = Field(
        default=None,
        max_length=500,
        description="Optional internal note attached to the refund record.",
    )


class RefundResponse(BaseModel):
    """Successful refund result."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    donation_id: UUID
    refund_amount_cents: int = Field(ge=1)
    refunded_at: datetime
    processor_refund_id: str = Field(description="Vendor-neutral refund identifier from the payment processor.")
