"""Webhook event payload models — discriminated union over ``type``.

Each concrete event class extends :class:`_WebhookEnvelopeBase` (the
canonical envelope) and adds a ``data`` field whose shape varies per event
type. ``WebhookEvent`` is a Pydantic ``Annotated[..., Field(discriminator="type")]``
union, so parsing a raw event dict resolves to the right concrete class
based on the ``type`` field.

Example::

    >>> from donations_embed.models import WebhookEvent
    >>> from pydantic import TypeAdapter
    >>> adapter = TypeAdapter(WebhookEvent)
    >>> ev = adapter.validate_python({
    ...     "id": "evt_x", "type": "donation.completed", "created": 1717881425,
    ...     "live_mode": True, "data": {"object": {...}},
    ... })
    >>> isinstance(ev, DonationCompletedEvent)
    True
    >>> ev.data.object.gross_amount_cents
    5175
"""

from __future__ import annotations

from datetime import datetime
from typing import Annotated, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from donations_embed.models.donations import DonationStatus, PaymentMethodType
from donations_embed.models.recurring import RecurringInterval, RecurringStatus

WebhookEventType = Literal[
    "donation.created",
    "donation.completed",
    "donation.failed",
    "donation.refunded",
    "recurring.activated",
    "recurring.payment_succeeded",
    "recurring.payment_failed",
    "recurring.cancelled",
    "key.frozen",
]
"""Stable union of every event type emitted by the platform."""

KeyFrozenReason = Literal["card_testing_detected"]
"""Reason a key pair was automatically frozen by abuse-detection."""


# ---------------------------------------------------------------------------
# Inline sub-objects shared by multiple event payloads
# ---------------------------------------------------------------------------


class DonationEventDonor(BaseModel):
    """Donor identity carried inside donation event payloads.

    Inline subset of the donor model; does not include the address since
    webhook payloads omit it for compactness.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    name: str
    email: str


class EventPaymentMethod(BaseModel):
    """Payment-method snapshot inside a donation event payload."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    type: PaymentMethodType
    last4: str
    brand: str | None = Field(default=None, description="Card brand; null for ACH.")


class DonationEventFundAllocation(BaseModel):
    """Per-fund allocation inside a donation event payload (no fund name)."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    fund_id: UUID
    amount_cents: int = Field(ge=0)


# ---------------------------------------------------------------------------
# Per-event ``data.object`` payload classes
# ---------------------------------------------------------------------------


class DonationEventObject(BaseModel):
    """Donation-shaped payload — used by completed / failed events."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    confirmation_id: str
    donor: DonationEventDonor
    gross_amount_cents: int = Field(ge=0)
    fee_amount_cents: int = Field(ge=0)
    net_amount_cents: int = Field(ge=0)
    payment_method: EventPaymentMethod
    processor_transaction_id: str | None = Field(default=None)
    status: DonationStatus
    created_at: datetime | None = Field(default=None)
    funds: list[DonationEventFundAllocation] = Field(default_factory=list)


class DonationRefundedEventObject(DonationEventObject):
    """Refund variant — extends donation payload with refund metadata."""

    refund_amount_cents: int = Field(ge=1)
    refund_transaction_id: str | None = Field(
        default=None,
        description="Vendor-neutral refund identifier.",
    )


class DonationCreatedEventObject(BaseModel):
    """Session-shaped payload for the ``donation.created`` event.

    Note: at this point there is no donation row yet — the embed has only
    just opened a session. Correlate to the eventual donation via the
    ``donation_id`` returned by ``/v1/embed/sessions/{id}/confirm``.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    session_id: UUID
    organization_id: UUID
    amount_cents: int | None = Field(default=None, ge=0)
    fund_ids: list[UUID] = Field(default_factory=list)


class RecurringEventObject(BaseModel):
    """Recurring-schedule payload — used by activated / payment_succeeded / payment_failed."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    donor: DonationEventDonor
    amount_cents: int = Field(ge=0)
    interval: RecurringInterval
    interval_count: int = Field(ge=1)
    status: RecurringStatus
    processor_subscription_id: str | None = Field(default=None)
    created_at: datetime | None = Field(default=None)


class RecurringCancelledEventObject(BaseModel):
    """Minimal payload for ``recurring.cancelled``."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    recurring_id: UUID
    processor_subscription_id: str | None = Field(default=None)


class KeyFrozenEventObject(BaseModel):
    """Payload for ``key.frozen`` — emitted by automatic protection."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    key_pair_id: UUID
    pk_prefix: str = Field(description="Truncated prefix of the publishable key (safe to log).")
    reason: KeyFrozenReason
    decline_count_window: int | None = Field(default=None, ge=0)
    window_seconds: int | None = Field(default=None, ge=0)
    frozen_at: datetime


# ---------------------------------------------------------------------------
# ``data`` wrapper classes — one per event type
# ---------------------------------------------------------------------------


class _DataWithObject(BaseModel):
    """Common ``data`` shape: ``{ "object": <payload> }`` (no extra siblings)."""

    model_config = ConfigDict(extra="forbid", frozen=True)


class _DonationCreatedData(_DataWithObject):
    object: DonationCreatedEventObject


class _DonationCompletedData(_DataWithObject):
    object: DonationEventObject


class _DonationFailedData(_DataWithObject):
    object: DonationEventObject


class _DonationRefundedData(_DataWithObject):
    object: DonationRefundedEventObject


class _RecurringActivatedData(_DataWithObject):
    object: RecurringEventObject
    donation: DonationEventObject | None = Field(
        default=None,
        description="The first underlying charge that activated this schedule.",
    )


class _RecurringPaymentSucceededData(_DataWithObject):
    object: RecurringEventObject
    donation: DonationEventObject | None = Field(
        default=None,
        description="The successful per-cycle charge.",
    )


class _RecurringPaymentFailedData(_DataWithObject):
    object: RecurringEventObject
    donation: DonationEventObject | None = Field(
        default=None,
        description="The failed per-cycle charge attempt, if available.",
    )


class _RecurringCancelledData(_DataWithObject):
    object: RecurringCancelledEventObject


class _KeyFrozenData(_DataWithObject):
    object: KeyFrozenEventObject


# ---------------------------------------------------------------------------
# Concrete event envelopes
# ---------------------------------------------------------------------------


class _WebhookEnvelopeBase(BaseModel):
    """Fields shared by every webhook event envelope.

    Mirrors OpenAPI ``WebhookEnvelope``. Concrete subclasses pin ``type``
    to a literal so the discriminator can route correctly.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: str = Field(description="Globally unique event ID. Echoed in ``Flock-Event-Id`` for dedup.")
    created: int = Field(description="Unix epoch seconds at event creation.")
    live_mode: bool = Field(description="True for live-mode events; false for test-mode.")


class DonationCreatedEvent(_WebhookEnvelopeBase):
    """Donor opened the embed and a session was created (no donation row yet)."""

    type: Literal["donation.created"]
    data: _DonationCreatedData


class DonationCompletedEvent(_WebhookEnvelopeBase):
    """Donation succeeded."""

    type: Literal["donation.completed"]
    data: _DonationCompletedData


class DonationFailedEvent(_WebhookEnvelopeBase):
    """Donation declined or terminated before completion."""

    type: Literal["donation.failed"]
    data: _DonationFailedData


class DonationRefundedEvent(_WebhookEnvelopeBase):
    """Refund (full or partial) succeeded."""

    type: Literal["donation.refunded"]
    data: _DonationRefundedData


class RecurringActivatedEvent(_WebhookEnvelopeBase):
    """Recurring schedule created and the first charge succeeded."""

    type: Literal["recurring.activated"]
    data: _RecurringActivatedData


class RecurringPaymentSucceededEvent(_WebhookEnvelopeBase):
    """Per-cycle charge against a recurring schedule succeeded."""

    type: Literal["recurring.payment_succeeded"]
    data: _RecurringPaymentSucceededData


class RecurringPaymentFailedEvent(_WebhookEnvelopeBase):
    """Per-cycle charge against a recurring schedule failed."""

    type: Literal["recurring.payment_failed"]
    data: _RecurringPaymentFailedData


class RecurringCancelledEvent(_WebhookEnvelopeBase):
    """Recurring schedule was cancelled (by the customer, donor, or platform)."""

    type: Literal["recurring.cancelled"]
    data: _RecurringCancelledData


class KeyFrozenEvent(_WebhookEnvelopeBase):
    """Key pair was automatically frozen by abuse-detection."""

    type: Literal["key.frozen"]
    data: _KeyFrozenData


WebhookEvent = Annotated[
    DonationCreatedEvent
    | DonationCompletedEvent
    | DonationFailedEvent
    | DonationRefundedEvent
    | RecurringActivatedEvent
    | RecurringPaymentSucceededEvent
    | RecurringPaymentFailedEvent
    | RecurringCancelledEvent
    | KeyFrozenEvent,
    Field(discriminator="type"),
]
"""Discriminated union of every concrete webhook event type.

Use :class:`pydantic.TypeAdapter` to parse a raw dict::

    >>> from pydantic import TypeAdapter
    >>> adapter = TypeAdapter(WebhookEvent)
    >>> event = adapter.validate_python(raw_dict)
    >>> match event:
    ...     case DonationCompletedEvent():
    ...         enqueue_receipt(event.data.object)
    ...     case DonationRefundedEvent():
    ...         reverse_receipt(event.data.object)
"""


# Backwards-compatible alias for callers that prefer the OpenAPI name.
WebhookEnvelope = WebhookEvent
"""Alias for :data:`WebhookEvent` matching the OpenAPI ``WebhookEnvelope`` name."""
