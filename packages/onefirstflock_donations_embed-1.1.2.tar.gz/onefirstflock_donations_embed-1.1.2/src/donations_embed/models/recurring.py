"""Recurring donation domain models — mirror of OpenAPI ``Recurring`` schemas."""

from __future__ import annotations

from datetime import date, datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

RecurringInterval = Literal["weekly", "monthly", "annual"]
"""Cadence between charges. Matches OpenAPI ``Recurring.interval``."""

RecurringStatus = Literal["active", "paused", "cancelled"]
"""Lifecycle state of a recurring schedule."""


class Recurring(BaseModel):
    """A single recurring donation schedule."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    donor_name: str
    donor_email: str
    amount_cents: int = Field(ge=0, description="Per-cycle charge amount, in cents.")
    interval: RecurringInterval
    interval_count: int = Field(ge=1, description="Number of intervals between charges (e.g. 1 = every month).")
    status: RecurringStatus
    next_charge_date: date | None = Field(
        default=None,
        description="Date of the next scheduled charge; null when status is not ``active``.",
    )
    created_at: datetime


class RecurringListResponse(BaseModel):
    """Paginated response from ``GET /v1/embed/recurring``."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    recurring: list[Recurring]
    next_cursor: str | None = Field(default=None)


class RecurringCancelResponse(BaseModel):
    """Result of ``POST /v1/embed/recurring/{recurring_id}/cancel``.

    The ``already_cancelled`` field is True when an idempotent replay
    against an already-cancelled schedule short-circuits without contacting
    the gateway again.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    status: Literal["cancelled"]
    already_cancelled: bool = Field(
        default=False,
        description="True when the schedule was already cancelled before this call.",
    )
