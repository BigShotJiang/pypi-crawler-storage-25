"""Public Pydantic v2 models for the Donations Embed SDK.

Models are grouped by domain (donations, recurring, webhook events) and
re-exported here for convenience. All models mirror the OpenAPI schemas
defined at ``openapi.yaml`` in the Node SDK package — that file is the
single source of truth for shapes; any drift is a bug.
"""

from __future__ import annotations

from donations_embed.models.donations import (
    Donation,
    DonationListResponse,
    DonationStatus,
    FundAllocation,
    PaymentMethodType,
    RefundRequest,
    RefundResponse,
)
from donations_embed.models.events import (
    DonationCompletedEvent,
    DonationCreatedEvent,
    DonationCreatedEventObject,
    DonationEventDonor,
    DonationEventFundAllocation,
    DonationEventObject,
    DonationFailedEvent,
    DonationRefundedEvent,
    DonationRefundedEventObject,
    EventPaymentMethod,
    KeyFrozenEvent,
    KeyFrozenEventObject,
    KeyFrozenReason,
    RecurringActivatedEvent,
    RecurringCancelledEvent,
    RecurringCancelledEventObject,
    RecurringEventObject,
    RecurringPaymentFailedEvent,
    RecurringPaymentSucceededEvent,
    WebhookEnvelope,
    WebhookEvent,
    WebhookEventType,
)
from donations_embed.models.recurring import (
    Recurring,
    RecurringCancelResponse,
    RecurringInterval,
    RecurringListResponse,
    RecurringStatus,
)
from donations_embed.models.webhook_test import (
    WebhookTestRequest,
    WebhookTestResponse,
)

__all__ = [
    "Donation",
    "DonationCompletedEvent",
    "DonationCreatedEvent",
    "DonationCreatedEventObject",
    "DonationEventDonor",
    "DonationEventFundAllocation",
    "DonationEventObject",
    "DonationFailedEvent",
    "DonationListResponse",
    "DonationRefundedEvent",
    "DonationRefundedEventObject",
    "DonationStatus",
    "EventPaymentMethod",
    "FundAllocation",
    "KeyFrozenEvent",
    "KeyFrozenEventObject",
    "KeyFrozenReason",
    "PaymentMethodType",
    "Recurring",
    "RecurringActivatedEvent",
    "RecurringCancelResponse",
    "RecurringCancelledEvent",
    "RecurringCancelledEventObject",
    "RecurringEventObject",
    "RecurringInterval",
    "RecurringListResponse",
    "RecurringPaymentFailedEvent",
    "RecurringPaymentSucceededEvent",
    "RecurringStatus",
    "RefundRequest",
    "RefundResponse",
    "WebhookEnvelope",
    "WebhookEvent",
    "WebhookEventType",
    "WebhookTestRequest",
    "WebhookTestResponse",
]
