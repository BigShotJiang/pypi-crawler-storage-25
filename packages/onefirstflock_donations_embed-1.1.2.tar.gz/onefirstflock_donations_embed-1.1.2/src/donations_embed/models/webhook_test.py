"""Models for the synthetic-event endpoint ``POST /v1/embed/webhooks/test``."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

# Note: the synthetic-event endpoint accepts a subset of the full webhook
# event types; ``key.frozen`` is excluded from the synthetic surface in the
# OpenAPI spec because it is only emitted by the automatic-protection
# subsystem and cannot meaningfully be replayed on demand.
TestableWebhookEventType = Literal[
    "donation.created",
    "donation.completed",
    "donation.failed",
    "donation.refunded",
    "recurring.activated",
    "recurring.payment_succeeded",
    "recurring.payment_failed",
    "recurring.cancelled",
]


class WebhookTestRequest(BaseModel):
    """Body of ``POST /v1/embed/webhooks/test``."""

    model_config = ConfigDict(extra="forbid")

    event_type: TestableWebhookEventType = Field(
        description="Which event type to fire as a synthetic delivery.",
    )


class WebhookTestResponse(BaseModel):
    """Acknowledgment of a queued synthetic event."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    event_id: str = Field(
        description="ID of the synthetic event; matches the ``Flock-Event-Id`` header on delivery.",
    )
    queued: bool
