"""Idempotency-key helper.

The platform's idempotency contract: replaying a request with the same
``Idempotency-Key`` returns the original response without performing the
side effect a second time. Keys are scoped per (``api_key``, ``endpoint``)
and persisted for 24 hours.

This module exposes :func:`idempotency_key`, a tiny convenience wrapper
that prefixes a fresh UUID4 with a use-case tag so observability tooling
can group related retries (e.g. all ``refund:*`` keys belong to the refund
flow). Callers MAY also supply their own keys directly.
"""

from __future__ import annotations

import re
import uuid

# Match the OpenAPI ``Idempotency-Key`` schema constraint (max 255 chars).
_MAX_KEY_LENGTH = 255

# Conservative validation for the use-case tag — keep it printable ASCII
# so the resulting key fits cleanly in HTTP headers and log lines.
_USE_CASE_RE = re.compile(r"^[a-z0-9][a-z0-9_\-.]*$")


def idempotency_key(use_case: str) -> str:
    """Generate a fresh idempotency key tagged with a use-case prefix.

    The returned key has the form ``"<use_case>:<uuid4>"``, e.g.
    ``"refund:1f2dab36-2a55-4f11-bdc8-2a2a4a95b001"``.

    Args:
        use_case: A short tag describing the operation
            (``"refund"``, ``"cancel-recurring"``, ``"replay-confirm"``).
            Must be lowercase ASCII letters, digits, ``_``, ``-``, or ``.``;
            an empty or oddly-shaped tag raises :class:`ValueError`.

    Returns:
        A string suitable for the ``Idempotency-Key`` HTTP header.
    """
    if not use_case or not _USE_CASE_RE.match(use_case):
        raise ValueError(
            "idempotency use_case must be a non-empty lowercase ASCII tag "
            "matching ^[a-z0-9][a-z0-9_\\-.]*$"
        )
    key = f"{use_case}:{uuid.uuid4()}"
    if len(key) > _MAX_KEY_LENGTH:
        # Practically impossible (use_case + UUID4 is well under 255), but
        # we enforce the contract explicitly so a future caller can't blow
        # past the limit by passing a 250-char tag.
        raise ValueError(f"generated idempotency key exceeds {_MAX_KEY_LENGTH} chars")
    return key
