"""Typed error hierarchy raised by the SDK.

The base type is :class:`ApiError`. All transport-level failures (4xx/5xx)
are surfaced as concrete subclasses so caller code can branch on type
rather than parsing status codes directly. Webhook verification has its own
dedicated exceptions (:class:`WebhookSignatureError`,
:class:`WebhookTimestampError`) so middleware can return a single
``401 Unauthorized`` without leaking which check failed.

Every exception captures the raw error code + message returned by the
service when one is available, so callers can pivot on
``error.code == "invalid_cursor"`` without re-deserializing the body.
"""

from __future__ import annotations

from typing import Any


class DonationsEmbedError(Exception):
    """Base class for every exception raised by this SDK.

    Catching this single class lets a caller back out of any SDK-originated
    failure in one ``except`` block.
    """


class ApiError(DonationsEmbedError):
    """Raised when the API returns a non-2xx status code.

    Attributes:
        status_code: HTTP status code (e.g. 500).
        code: Stable, machine-readable error identifier when present in the
            response body (``"invalid_cursor"``), else ``None``.
        message: Human-readable error description from the response body, or
            a fallback string built from the status line when the body is
            empty / non-JSON.
        details: Optional, error-specific extra data the service emitted.
        request_id: Server-issued correlation ID from the ``x-request-id``
            response header, useful when filing support tickets.
    """

    def __init__(
        self,
        status_code: int,
        message: str,
        *,
        code: str | None = None,
        details: dict[str, Any] | None = None,
        request_id: str | None = None,
    ) -> None:
        self.status_code = status_code
        self.code = code
        self.message = message
        self.details = details
        self.request_id = request_id
        prefix = f"[{status_code}]"
        if code is not None:
            prefix = f"[{status_code} {code}]"
        if request_id is not None:
            super().__init__(f"{prefix} {message} (request_id={request_id})")
        else:
            super().__init__(f"{prefix} {message}")


class AuthError(ApiError):
    """Raised on a ``401 Unauthorized`` response.

    Common causes: revoked secret key, malformed bearer token, expired
    session, or the token was issued for a different environment (test vs.
    live) than the URL being called.
    """


class ForbiddenError(ApiError):
    """Raised on a ``403 Forbidden`` response.

    Common causes: the secret key has been frozen by automatic protection,
    the caller's RBAC scope is insufficient, or the action is disabled for
    the organization.
    """


class NotFoundError(ApiError):
    """Raised on a ``404 Not Found`` response.

    Note: cross-organization lookups collapse to ``404`` to avoid
    confirming that an object exists in another tenant.
    """


class ValidationError(ApiError):
    """Raised on ``400 Bad Request`` or ``422 Unprocessable Entity``.

    The originating request body failed schema validation. Inspect
    ``details`` for the offending field path (e.g.
    ``{"loc": ["body", "amount_cents"]}``).
    """


class ConflictError(ApiError):
    """Raised on a ``409 Conflict`` response.

    Common causes: attempting to refund a donation that is already fully
    refunded, or cancelling a recurring schedule whose state forbids the
    transition.
    """


class GoneError(ApiError):
    """Raised on a ``410 Gone`` response (terminal session error)."""


class RateLimitError(ApiError):
    """Raised on a ``429 Too Many Requests`` response.

    The caller should wait ``retry_after`` seconds before retrying. The SDK
    will not auto-retry rate-limited requests by default — back-pressure is
    a caller-controlled concern.
    """

    def __init__(
        self,
        status_code: int,
        message: str,
        *,
        retry_after: float | None,
        code: str | None = None,
        details: dict[str, Any] | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            status_code,
            message,
            code=code,
            details=details,
            request_id=request_id,
        )
        self.retry_after = retry_after


class BadGatewayError(ApiError):
    """Raised on a ``502 Bad Gateway`` response.

    Indicates an upstream payment-processor failure. The original request
    is safe to retry — it has not been performed.
    """


class ServiceUnavailableError(ApiError):
    """Raised on a ``503 Service Unavailable`` response."""


class WebhookError(DonationsEmbedError):
    """Base class for webhook signature verification failures."""


class WebhookSignatureError(WebhookError):
    """Raised when webhook signature verification fails.

    This may indicate a wrong shared secret, a tampered request body, or
    that the signature header was not produced by 1st Flock. Callers MUST
    return an HTTP 401 (or drop the request) without enqueueing the event.
    """


class WebhookTimestampError(WebhookError):
    """Raised when the webhook timestamp is outside the 5-minute tolerance.

    This is a replay-prevention check; callers MUST treat it as a
    verification failure and return ``401`` without processing the event.
    """


class WebhookFormatError(WebhookError):
    """Raised when the signature header is structurally malformed.

    Examples: missing ``t=`` segment, no ``v1=`` segments, non-integer
    timestamp, etc. The request did not parse as a signed delivery.
    """
