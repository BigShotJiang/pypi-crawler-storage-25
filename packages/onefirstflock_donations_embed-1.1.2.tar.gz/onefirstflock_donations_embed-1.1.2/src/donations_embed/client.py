"""Async :class:`Client` — entry point for the Donations Embed Customer SDK.

Every call maps to a documented endpoint under the ``/v1/embed/`` path
prefix. All inputs and outputs are typed via Pydantic v2 models from
:mod:`donations_embed.models`. Errors surface as typed exceptions from
:mod:`donations_embed.errors`.

Example::

    >>> async with Client(api_key="sk_test_...") as client:
    ...     page = await client.list_donations(limit=20)
    ...     for donation in page.donations:
    ...         print(donation.id, donation.gross_amount_cents)

The client is safe to share across coroutines as long as the underlying
``httpx.AsyncClient`` (which it owns by default) is not closed
concurrently from elsewhere.
"""

from __future__ import annotations

import logging
from types import TracebackType
from typing import Any, Literal, Self
from uuid import UUID

import httpx
from pydantic import TypeAdapter

from donations_embed._http import (
    DEFAULT_BASE_URL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT_SECONDS,
    HttpTransport,
)
from donations_embed.models.donations import (
    Donation,
    DonationListResponse,
    RefundRequest,
    RefundResponse,
)
from donations_embed.models.recurring import (
    RecurringCancelResponse,
    RecurringListResponse,
    RecurringStatus,
)
from donations_embed.models.webhook_test import (
    TestableWebhookEventType,
    WebhookTestRequest,
    WebhookTestResponse,
)

#: Resolved environment for a :class:`Client`. Derived from the secret-key
#: prefix at construction time and surfaced via :attr:`Client.environment`.
Environment = Literal["live", "test"]

_DONATION_ADAPTER: TypeAdapter[Donation] = TypeAdapter(Donation)
_DONATION_LIST_ADAPTER: TypeAdapter[DonationListResponse] = TypeAdapter(DonationListResponse)
_REFUND_ADAPTER: TypeAdapter[RefundResponse] = TypeAdapter(RefundResponse)
_RECURRING_LIST_ADAPTER: TypeAdapter[RecurringListResponse] = TypeAdapter(RecurringListResponse)
_RECURRING_CANCEL_ADAPTER: TypeAdapter[RecurringCancelResponse] = TypeAdapter(RecurringCancelResponse)
_WEBHOOK_TEST_ADAPTER: TypeAdapter[WebhookTestResponse] = TypeAdapter(WebhookTestResponse)


def _environment_from_secret_key(api_key: str) -> Environment:
    """Reject pk keys, missing keys, and other obviously-wrong inputs.

    The customer SDK requires a secret key (``sk_live_*`` / ``sk_test_*``).
    We catch the wrong shape here so callers don't see a confusing 401
    from the platform — they see a :class:`ValueError` at construction
    time. On success, returns the resolved environment derived from the
    key prefix.

    Args:
        api_key: The secret key supplied by the caller.

    Returns:
        ``"live"`` when ``api_key`` starts with ``sk_live_``,
        ``"test"`` when it starts with ``sk_test_``.

    Raises:
        ValueError: When ``api_key`` is empty, not a string, or does not
            start with one of the accepted secret-key prefixes.
    """
    if not isinstance(api_key, str) or not api_key:
        raise ValueError("api_key must be a non-empty string")
    if api_key.startswith("sk_live_"):
        return "live"
    if api_key.startswith("sk_test_"):
        return "test"
    raise ValueError(
        "api_key must be a secret key (sk_live_… or sk_test_…); "
        "publishable keys (pk_…) are browser-only and not accepted server-side"
    )


class Client:
    """Async client for the 1st Flock Donations Embed API.

    The constructor parses the secret-key prefix and exposes the
    resolved environment via :attr:`environment`. The same API host
    (``api.1stflock.com``) is used in both environments — the platform
    routes between production and sandbox processors based on the
    supplied secret key.

    Args:
        api_key: A secret key issued by the platform (``sk_live_*`` or
            ``sk_test_*``). Publishable keys are rejected at construction
            with a :class:`ValueError`.
        base_url: API base URL. Defaults to ``https://api.1stflock.com``.
            Override only when targeting an internal staging host or a
            test fixture; production and sandbox both live on the
            default base URL.
        http_client: Optional pre-configured ``httpx.AsyncClient``. When
            supplied, the client is shared (and **not** closed by the
            transport on ``aclose``).
        max_retries: Number of retries on retryable failures (5xx +
            transient network errors). Defaults to 3.
        timeout: Per-request timeout in seconds. Defaults to 30.
        logger: Optional :class:`logging.Logger`. Used at DEBUG for
            transient transport errors that trigger a retry.

    Attributes:
        environment: Resolved environment (``"live"`` or ``"test"``)
            derived from the supplied secret key. Read-only.
    """

    environment: Environment

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        http_client: httpx.AsyncClient | None = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        logger: logging.Logger | None = None,
    ) -> None:
        self.environment = _environment_from_secret_key(api_key)
        self._transport = HttpTransport(
            api_key,
            base_url=base_url,
            http_client=http_client,
            max_retries=max_retries,
            timeout=timeout,
            logger=logger,
        )

    # ----------------------------------------------------------- async-context

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        """Close the underlying HTTP client (if owned by this transport)."""
        await self._transport.aclose()

    # ---------------------------------------------------------------- donations

    async def list_donations(
        self,
        *,
        cursor: str | None = None,
        limit: int | None = None,
        fund_id: UUID | str | None = None,
        donor_email: str | None = None,
    ) -> DonationListResponse:
        """List donations, ordered ``(created_at DESC, id DESC)``.

        Args:
            cursor: Opaque cursor returned by a previous response's
                ``next_cursor``. Omit on the first page.
            limit: Page size (1-200, default 50 server-side).
            fund_id: Filter to donations with at least one allocation to
                this fund.
            donor_email: Filter to donations from a specific donor email.

        Returns:
            A page of donations plus an optional ``next_cursor``.
        """
        params: dict[str, Any] = {
            "cursor": cursor,
            "limit": limit,
            "fund_id": str(fund_id) if fund_id is not None else None,
            "donor_email": donor_email,
        }
        payload = await self._transport.request("GET", "/v1/embed/donations", params=params)
        return _DONATION_LIST_ADAPTER.validate_python(payload)

    async def get_donation(self, donation_id: UUID | str) -> Donation:
        """Fetch a single donation by ID.

        Cross-organization access collapses to ``404`` (raises
        :class:`donations_embed.errors.NotFoundError`).
        """
        payload = await self._transport.request("GET", f"/v1/embed/donations/{donation_id}")
        return _DONATION_ADAPTER.validate_python(payload)

    async def refund_donation(
        self,
        donation_id: UUID | str,
        *,
        amount_cents: int | None = None,
        reason: str | None = None,
        idempotency_key: str | None = None,
    ) -> RefundResponse:
        """Refund a donation in full or part.

        Args:
            donation_id: The donation to refund.
            amount_cents: Partial refund amount. Omit (or pass ``None``)
                for a full refund.
            reason: Optional internal note attached to the refund record.
            idempotency_key: Optional ``Idempotency-Key`` header value.
                Use :func:`donations_embed.idempotency_key` to generate
                one tagged with a use-case prefix.

        Returns:
            The :class:`RefundResponse` describing the issued refund.
            Idempotent replays return the original response without
            re-contacting the gateway.
        """
        body = RefundRequest(amount_cents=amount_cents, reason=reason)
        payload = await self._transport.request(
            "POST",
            f"/v1/embed/donations/{donation_id}/refund",
            json_body=body.model_dump(mode="json", exclude_none=True),
            idempotency_key=idempotency_key,
        )
        return _REFUND_ADAPTER.validate_python(payload)

    # ----------------------------------------------------------------- recurring

    async def list_recurring(
        self,
        *,
        cursor: str | None = None,
        limit: int | None = None,
        status: RecurringStatus | None = None,
    ) -> RecurringListResponse:
        """List recurring schedules, ordered ``(created_at DESC, id DESC)``.

        Args:
            cursor: Opaque cursor for the next page.
            limit: Page size (1-200, default 50 server-side).
            status: Filter to a single SDK-canonical status.

        Returns:
            A page of recurring schedules plus an optional ``next_cursor``.
        """
        params: dict[str, Any] = {
            "cursor": cursor,
            "limit": limit,
            "status": status,
        }
        payload = await self._transport.request("GET", "/v1/embed/recurring", params=params)
        return _RECURRING_LIST_ADAPTER.validate_python(payload)

    async def cancel_recurring(
        self,
        recurring_id: UUID | str,
        *,
        idempotency_key: str | None = None,
    ) -> RecurringCancelResponse:
        """Cancel a recurring schedule.

        Idempotent: a second call against an already-cancelled schedule
        returns ``already_cancelled=True`` without re-emitting a webhook.

        Args:
            recurring_id: The schedule to cancel.
            idempotency_key: Optional ``Idempotency-Key`` header value.
        """
        payload = await self._transport.request(
            "POST",
            f"/v1/embed/recurring/{recurring_id}/cancel",
            idempotency_key=idempotency_key,
        )
        return _RECURRING_CANCEL_ADAPTER.validate_python(payload)

    # ------------------------------------------------------------------ webhooks

    async def test_webhook(
        self,
        event_type: TestableWebhookEventType = "donation.created",
    ) -> WebhookTestResponse:
        """Queue a synthetic webhook event for delivery.

        The synthetic event's ``data.object.synthetic`` flag is ``true`` so
        downstream code can branch on it during integration testing.

        Args:
            event_type: Which event type to fire. Defaults to
                ``"donation.created"``.

        Returns:
            Acknowledgment containing the synthetic event's ID (also sent
            in the ``Flock-Event-Id`` header on delivery).
        """
        body = WebhookTestRequest(event_type=event_type)
        payload = await self._transport.request(
            "POST",
            "/v1/embed/webhooks/test",
            json_body=body.model_dump(mode="json"),
        )
        return _WEBHOOK_TEST_ADAPTER.validate_python(payload)
