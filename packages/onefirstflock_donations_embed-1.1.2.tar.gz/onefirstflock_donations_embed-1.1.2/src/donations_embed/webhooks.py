"""HMAC-SHA256 webhook signature verification.

Wire format on the ``Flock-Signature`` header (per spec §6.7)::

    t=<unix_ts>,v1=<hex>[,v1=<hex>]

A second ``v1=`` segment is present during a key-rotation grace window so
verifiers MAY check either signature without coordinating with the
platform. A 5-minute timestamp tolerance prevents replay; payloads outside
that window are rejected even when the HMAC matches.

This module is byte-compatible with the platform-side signer at
``app/services/finance/embed/webhook_signer.py`` — any drift is a bug.

Two entry points:

- :func:`verify_webhook` — synchronous verifier. Use this from worker
  threads, sync routes, or anywhere outside the asyncio loop.
- :func:`verify_webhook_async` — thin coroutine wrapper. Signature
  verification itself is CPU-bound so the async variant simply calls the
  sync function under the hood; it exists so async middleware can ``await``
  the verifier without an explicit ``run_in_executor`` hop.

Both return a parsed :data:`WebhookEvent` (the discriminated union) or
raise a typed :class:`donations_embed.errors.WebhookError` subclass —
:class:`WebhookFormatError`, :class:`WebhookSignatureError`, or
:class:`WebhookTimestampError`.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time

from pydantic import TypeAdapter
from pydantic import ValidationError as PydanticValidationError

from donations_embed.errors import (
    WebhookFormatError,
    WebhookSignatureError,
    WebhookTimestampError,
)
from donations_embed.models.events import WebhookEvent

# Per spec §6.7. Customers should not need to override this in production;
# the parameter exists so unit tests can simulate clock drift.
DEFAULT_TOLERANCE_SECONDS = 300

_EVENT_ADAPTER: TypeAdapter[WebhookEvent] = TypeAdapter(WebhookEvent)


def _parse_signature_header(header: str) -> tuple[int, list[str]]:
    """Parse ``t=<ts>,v1=<hex>[,v1=<hex>]`` into ``(ts, [hex, ...])``.

    Raises :class:`WebhookFormatError` on any structural problem
    (missing ``t=``, missing ``v1=``, non-integer timestamp, etc.). We never
    silently downgrade to a "did not verify" outcome — a malformed header
    is its own failure mode the caller may want to log distinctly from a
    real signature mismatch.
    """
    if not header:
        raise WebhookFormatError("Flock-Signature header is missing or empty")

    timestamp: int | None = None
    digests: list[str] = []
    for raw in header.split(","):
        part = raw.strip()
        if part.startswith("t="):
            try:
                timestamp = int(part.removeprefix("t="))
            except ValueError as exc:
                raise WebhookFormatError(
                    f"timestamp segment in Flock-Signature is not an integer: {part!r}"
                ) from exc
        elif part.startswith("v1="):
            digests.append(part.removeprefix("v1="))
        # Unknown segments (e.g. future ``v2=``) are intentionally ignored.

    if timestamp is None:
        raise WebhookFormatError("Flock-Signature is missing the required t=<unix_ts> segment")
    if not digests:
        raise WebhookFormatError("Flock-Signature has no v1=<hex> segments")
    return timestamp, digests


def _compute_expected(secret: str, timestamp: int, body: bytes) -> str:
    """Compute ``HMAC-SHA256(secret, "<ts>." + body)`` as hex.

    The dot delimiter is concatenated as raw ASCII bytes so binary bodies
    do not pass through a str-decode step.
    """
    payload = f"{timestamp}.".encode() + body
    return hmac.new(secret.encode("utf-8"), payload, hashlib.sha256).hexdigest()


def verify_webhook(
    body: bytes,
    signature: str,
    secret: str,
    *,
    tolerance_seconds: int = DEFAULT_TOLERANCE_SECONDS,
    now: float | None = None,
) -> WebhookEvent:
    """Verify a webhook delivery and return the parsed event.

    Args:
        body: The raw request body as received off the wire. **Do not
            re-serialize** the JSON before passing it in — even a single
            whitespace difference will invalidate the signature. Frameworks
            that buffer the body (FastAPI: ``await request.body()``, Flask:
            ``request.get_data()``) provide the bytes directly.
        signature: Value of the ``Flock-Signature`` request header.
        secret: The HMAC signing secret returned by the platform when the
            webhook endpoint was created or its URL was last changed.
        tolerance_seconds: Maximum allowed clock skew between the platform
            and the receiver. Defaults to 5 minutes (per spec §6.7); only
            override for unit tests.
        now: Wall-clock seconds-since-epoch to compare against. Defaults to
            the current time; override in tests for determinism.

    Returns:
        The parsed :data:`WebhookEvent` (a concrete subclass selected by
        the ``type`` discriminator).

    Raises:
        WebhookFormatError: The signature header does not parse.
        WebhookTimestampError: The timestamp falls outside the tolerance
            window. Reject as a replay attempt.
        WebhookSignatureError: No ``v1=`` digest matched under the supplied
            secret. The body may have been tampered with, the secret may
            be wrong, or the request did not originate from 1st Flock.
    """
    timestamp, digests = _parse_signature_header(signature)

    current = now if now is not None else time.time()
    if abs(current - timestamp) > tolerance_seconds:
        raise WebhookTimestampError(
            f"webhook timestamp {timestamp} is outside the {tolerance_seconds}s tolerance "
            f"(current={int(current)})"
        )

    expected = _compute_expected(secret, timestamp, body)
    if not any(hmac.compare_digest(expected, d) for d in digests):
        raise WebhookSignatureError("webhook signature did not match — wrong secret or tampered body")

    # Decode the body only after the signature passes — never feed
    # untrusted JSON through a parser before authenticating it.
    try:
        payload = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise WebhookFormatError(f"webhook body did not parse as UTF-8 JSON: {exc}") from exc

    try:
        return _EVENT_ADAPTER.validate_python(payload)
    except PydanticValidationError as exc:
        # Keep the underlying error chained so debugging is easy, but raise
        # our own typed error so callers don't depend on Pydantic types.
        raise WebhookFormatError(f"webhook body did not match any known event schema: {exc}") from exc


async def verify_webhook_async(
    body: bytes,
    signature: str,
    secret: str,
    *,
    tolerance_seconds: int = DEFAULT_TOLERANCE_SECONDS,
    now: float | None = None,
) -> WebhookEvent:
    """Async wrapper around :func:`verify_webhook`.

    Signature verification is CPU-bound (HMAC-SHA256 over a small payload);
    this coroutine delegates directly to the sync function rather than
    spawning a thread, since the work completes in microseconds. It exists
    so async middleware can use ``await verify_webhook_async(...)`` without
    a ``run_in_executor`` indirection.

    For very large bodies (multi-MB) where you genuinely want to offload
    the work, wrap :func:`verify_webhook` in
    ``asyncio.to_thread(verify_webhook, ...)`` yourself.
    """
    return verify_webhook(
        body,
        signature,
        secret,
        tolerance_seconds=tolerance_seconds,
        now=now,
    )
