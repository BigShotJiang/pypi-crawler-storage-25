"""FastAPI example: receive + verify a 1st Flock donations webhook.

Run with::

    pip install fastapi uvicorn onefirstflock-donations-embed
    export FLOCK_WEBHOOK_SECRET=whsec_...
    uvicorn examples.verify_webhook:app --reload

Then point a webhook endpoint configured in the Hub at
``http://<your-host>/webhooks/donations``.
"""

from __future__ import annotations

import logging
import os

from fastapi import FastAPI, Header, HTTPException, Request

from donations_embed import (
    DonationCompletedEvent,
    DonationFailedEvent,
    DonationRefundedEvent,
    KeyFrozenEvent,
    RecurringActivatedEvent,
    RecurringCancelledEvent,
    RecurringPaymentFailedEvent,
    RecurringPaymentSucceededEvent,
    WebhookFormatError,
    WebhookSignatureError,
    WebhookTimestampError,
    verify_webhook,
)

log = logging.getLogger("examples.verify_webhook")
app = FastAPI()


def _webhook_secret() -> str:
    """Pull the signing secret from the environment, fail loudly if missing."""
    secret = os.environ.get("FLOCK_WEBHOOK_SECRET")
    if not secret:
        raise RuntimeError("FLOCK_WEBHOOK_SECRET environment variable is required")
    return secret


@app.post("/webhooks/donations")
async def receive_webhook(
    request: Request,
    flock_signature: str = Header(..., alias="Flock-Signature"),
    flock_event_id: str = Header(..., alias="Flock-Event-Id"),
) -> dict[str, str]:
    """Receive a single signed webhook delivery.

    Returns ``200`` on success — the platform retries any non-2xx response
    with exponential backoff. Always return ``401`` for any verification
    failure; never reveal which check failed.
    """
    body = await request.body()
    try:
        event = verify_webhook(body, flock_signature, _webhook_secret())
    except (WebhookSignatureError, WebhookTimestampError, WebhookFormatError) as exc:
        log.warning("rejected webhook %s: %s", flock_event_id, exc)
        raise HTTPException(status_code=401, detail="invalid signature") from None

    # Idempotency: persist Flock-Event-Id and short-circuit re-deliveries.
    # (Real implementations should atomically check + insert in their DB.)
    if await _already_seen(event.id):
        return {"status": "ok"}

    match event:
        case DonationCompletedEvent():
            await on_donation_completed(event)
        case DonationFailedEvent():
            await on_donation_failed(event)
        case DonationRefundedEvent():
            await on_donation_refunded(event)
        case RecurringActivatedEvent():
            await on_recurring_activated(event)
        case RecurringPaymentSucceededEvent():
            await on_recurring_payment_succeeded(event)
        case RecurringPaymentFailedEvent():
            await on_recurring_payment_failed(event)
        case RecurringCancelledEvent():
            await on_recurring_cancelled(event)
        case KeyFrozenEvent():
            await on_key_frozen(event)
        case _:
            log.info("ignored webhook event of type %s", event.type)

    await _record_seen(event.id)
    return {"status": "ok"}


# ----------------------------------------------------- Per-event-type handlers --

async def on_donation_completed(event: DonationCompletedEvent) -> None:
    log.info(
        "donation completed: %s gross=%s net=%s donor=%s",
        event.data.object.id,
        event.data.object.gross_amount_cents,
        event.data.object.net_amount_cents,
        event.data.object.donor.email,
    )


async def on_donation_failed(event: DonationFailedEvent) -> None:
    log.info("donation failed: %s donor=%s", event.data.object.id, event.data.object.donor.email)


async def on_donation_refunded(event: DonationRefundedEvent) -> None:
    log.info(
        "donation refunded: %s amount=%s",
        event.data.object.id,
        event.data.object.refund_amount_cents,
    )


async def on_recurring_activated(event: RecurringActivatedEvent) -> None:
    log.info("recurring activated: %s donor=%s", event.data.object.id, event.data.object.donor.email)


async def on_recurring_payment_succeeded(event: RecurringPaymentSucceededEvent) -> None:
    log.info("recurring payment succeeded: %s", event.data.object.id)


async def on_recurring_payment_failed(event: RecurringPaymentFailedEvent) -> None:
    log.info("recurring payment failed: %s", event.data.object.id)


async def on_recurring_cancelled(event: RecurringCancelledEvent) -> None:
    log.info("recurring cancelled: %s", event.data.object.recurring_id)


async def on_key_frozen(event: KeyFrozenEvent) -> None:
    log.warning(
        "key pair frozen: %s reason=%s pk_prefix=%s",
        event.data.object.key_pair_id,
        event.data.object.reason,
        event.data.object.pk_prefix,
    )


# ---------------------------------------------------------- Idempotency stub --

# Replace these with a real durable store (Postgres, Redis, etc.) so re-delivered
# events do not produce duplicate side effects. The platform delivers
# at-least-once.
_seen: set[str] = set()


async def _already_seen(event_id: str) -> bool:
    return event_id in _seen


async def _record_seen(event_id: str) -> None:
    _seen.add(event_id)
