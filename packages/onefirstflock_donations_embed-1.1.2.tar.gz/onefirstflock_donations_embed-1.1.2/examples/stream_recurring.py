"""Standalone script: paginate every recurring schedule and report status.

Run with::

    pip install onefirstflock-donations-embed
    export FLOCK_API_KEY=sk_live_...
    python -m examples.stream_recurring [--cancel-paused]

Lists every recurring schedule for the organization. Optionally cancels any
schedules in the ``paused`` state. Demonstrates cursor-pagination, idempotent
mutations, and graceful error handling.
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys

from donations_embed import (
    ApiError,
    Client,
    ConflictError,
    Recurring,
    idempotency_key,
)

log = logging.getLogger("examples.stream_recurring")


async def stream_all(client: Client) -> list[Recurring]:
    """Yield every recurring schedule by following ``next_cursor``."""
    out: list[Recurring] = []
    cursor: str | None = None
    while True:
        page = await client.list_recurring(cursor=cursor, limit=200)
        out.extend(page.recurring)
        if page.next_cursor is None:
            break
        cursor = page.next_cursor
    return out


async def cancel_paused(client: Client, schedules: list[Recurring]) -> None:
    """Cancel each paused schedule. Idempotent: replays return ``already_cancelled=True``."""
    for r in schedules:
        if r.status != "paused":
            continue
        try:
            result = await client.cancel_recurring(
                r.id,
                idempotency_key=idempotency_key("cancel-recurring"),
            )
        except ConflictError:
            log.warning("schedule %s is in a state that forbids cancellation", r.id)
            continue
        except ApiError as exc:
            log.error("failed to cancel %s: %s", r.id, exc)
            continue
        log.info(
            "cancelled %s (already_cancelled=%s)",
            result.id,
            result.already_cancelled,
        )


async def main(do_cancel_paused: bool) -> int:
    api_key = os.environ.get("FLOCK_API_KEY")
    if not api_key:
        log.error("FLOCK_API_KEY environment variable is required")
        return 2

    async with Client(api_key=api_key) as client:
        schedules = await stream_all(client)

    log.info("found %d recurring schedules", len(schedules))
    by_status: dict[str, int] = {}
    for r in schedules:
        by_status[r.status] = by_status.get(r.status, 0) + 1
    for status, count in sorted(by_status.items()):
        log.info("  %s: %d", status, count)

    if do_cancel_paused:
        async with Client(api_key=api_key) as client:
            await cancel_paused(client, schedules)

    return 0


def cli() -> None:
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser(description="Stream and (optionally) clean up recurring schedules")
    parser.add_argument(
        "--cancel-paused",
        action="store_true",
        help="Cancel every recurring schedule currently in the 'paused' state",
    )
    args = parser.parse_args()
    sys.exit(asyncio.run(main(args.cancel_paused)))


if __name__ == "__main__":
    cli()
