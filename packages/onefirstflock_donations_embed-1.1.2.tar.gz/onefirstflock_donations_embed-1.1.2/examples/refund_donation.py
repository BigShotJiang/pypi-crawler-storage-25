"""Standalone script: issue a partial refund and surface common errors.

Run with::

    pip install onefirstflock-donations-embed
    export FLOCK_API_KEY=sk_live_...
    python -m examples.refund_donation 8a1b9c4d-1234-4321-9abc-def012345678 1000
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys

from donations_embed import (
    ApiError,
    AuthError,
    Client,
    ConflictError,
    NotFoundError,
    RateLimitError,
    ValidationError,
    idempotency_key,
)

log = logging.getLogger("examples.refund_donation")


async def main(donation_id: str, amount_cents: int | None, reason: str | None) -> int:
    api_key = os.environ.get("FLOCK_API_KEY")
    if not api_key:
        log.error("FLOCK_API_KEY environment variable is required")
        return 2

    async with Client(api_key=api_key) as client:
        try:
            refund = await client.refund_donation(
                donation_id,
                amount_cents=amount_cents,
                reason=reason,
                idempotency_key=idempotency_key("refund"),
            )
        except NotFoundError:
            log.error("donation %s not found", donation_id)
            return 1
        except ValidationError as exc:
            log.error("invalid refund request: %s (details=%s)", exc.message, exc.details)
            return 1
        except ConflictError:
            log.error("donation %s is already fully refunded", donation_id)
            return 1
        except RateLimitError as exc:
            log.error("rate limited; retry after %s seconds", exc.retry_after)
            return 1
        except AuthError:
            log.error("API key is invalid or revoked")
            return 1
        except ApiError as exc:
            log.error(
                "refund failed: status=%s code=%s message=%s",
                exc.status_code, exc.code, exc.message,
            )
            return 1

    log.info(
        "refunded: donation_id=%s amount_cents=%s processor_refund_id=%s refunded_at=%s",
        refund.donation_id,
        refund.refund_amount_cents,
        refund.processor_refund_id,
        refund.refunded_at.isoformat(),
    )
    return 0


def cli() -> None:
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser(description="Refund a donation in full or part")
    parser.add_argument("donation_id", help="UUID of the donation to refund")
    parser.add_argument(
        "amount_cents",
        nargs="?",
        type=int,
        default=None,
        help="Partial refund amount in cents; omit for a full refund",
    )
    parser.add_argument("--reason", default=None, help="Optional internal note for the refund record")
    args = parser.parse_args()
    sys.exit(asyncio.run(main(args.donation_id, args.amount_cents, args.reason)))


if __name__ == "__main__":
    cli()
