"""Python SDK validation driver.

Reads the orchestrator-emitted descriptor at ``$SANDBOX_JSON`` (default
``/tmp/sandbox.json``), connects to the running main-api with the seeded
sandbox sk, and exercises the four customer-facing surfaces the
``donations-embed`` Python package vends:

  1. ``list_donations``  — must return the donation seeded by the
                           ``test_real_donor_flow.py`` card flow.
  2. ``get_donation``    — must round-trip the same row.
  3. ``refund_donation`` — partial refund (1c) against the real donation,
                           which the embed forwards to NMI sandbox; the
                           response carries a real ``processor_refund_id``.
  4. ``test_webhook``    — fires a synthetic ``donation.completed`` event;
                           the orchestrator's webhook sink captures the
                           delivery + the driver verifies the
                           ``Flock-Signature`` HMAC.

On success: prints PASS + key identifiers to stdout, exits 0.
On failure: raises (uncaught) + non-zero exit.

Run from the donations-embed package root::

    SANDBOX_JSON=/tmp/sandbox.json uv run python sandbox/validate.py

NETWORK BOUNDARY: the listed/get/refund all hit the live backend; the
refund cascades to a real ``sandbox.nmi.com`` partial-refund call.
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from pathlib import Path
from typing import TypedDict

from donations_embed import (
    Client,
    verify_webhook,
)


class _SandboxCfg(TypedDict):
    base_url: str
    publishable_key: str
    secret_key: str
    signing_secret: str
    webhook_sink_path: str
    organization_id: str
    fund_id: str


def _load_cfg() -> _SandboxCfg:
    path = Path(os.environ.get("SANDBOX_JSON", "/tmp/sandbox.json"))
    return json.loads(path.read_text())  # type: ignore[no-any-return]


def _wait_for_envelope(
    sink_path: Path,
    *,
    event_id: str,
    timeout_s: float = 15.0,
) -> dict[str, str]:
    """Poll the JSONL sink until an envelope with ``event_id`` lands."""
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if sink_path.exists():
            for line in sink_path.read_text().splitlines():
                if not line.strip():
                    continue
                rec = json.loads(line)
                try:
                    body_obj = json.loads(rec["body"])
                except json.JSONDecodeError:
                    continue
                if body_obj.get("id") == event_id:
                    return rec  # type: ignore[no-any-return]
        time.sleep(0.25)
    raise AssertionError(
        f"synthetic webhook {event_id!r} never landed at {sink_path} "
        f"within {timeout_s}s"
    )


def _wait_for_envelope_by_type(
    sink_path: Path,
    *,
    event_type: str,
    timeout_s: float = 15.0,
) -> dict[str, str]:
    """Poll the JSONL sink for the LATEST envelope matching ``event_type``."""
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if sink_path.exists():
            lines = sink_path.read_text().splitlines()
            for line in reversed(lines):
                if not line.strip():
                    continue
                rec = json.loads(line)
                try:
                    body_obj = json.loads(rec["body"])
                except json.JSONDecodeError:
                    continue
                if body_obj.get("type") == event_type:
                    return rec  # type: ignore[no-any-return]
        time.sleep(0.25)
    raise AssertionError(
        f"no envelope of type {event_type!r} at {sink_path} within {timeout_s}s"
    )


async def main() -> None:
    cfg = _load_cfg()
    print(f"[PY] base_url={cfg['base_url']}")
    print(f"[PY] sk_prefix={cfg['secret_key'][:12]}…")

    async with Client(api_key=cfg["secret_key"], base_url=cfg["base_url"]) as cli:
        # 1. list_donations — must show the donation the card-flow test wrote.
        page = await cli.list_donations(limit=10)
        print(f"[PY] list_donations → {len(page.donations)} items")
        if not page.donations:
            raise AssertionError(
                "expected at least 1 donation seeded by test_real_donor_flow.py; "
                "run the Plaid+card pytest BEFORE this driver"
            )
        target = page.donations[0]
        print(
            f"[PY] target donation id={target.id} "
            f"gross={target.gross_amount_cents} status={target.status}"
        )

        # 2. get_donation — round-trip the same row.
        detail = await cli.get_donation(target.id)
        if detail.id != target.id:
            raise AssertionError(
                f"get_donation id mismatch: {detail.id} vs {target.id}"
            )
        print(
            f"[PY] get_donation → confirmation_id={detail.confirmation_id} "
            f"gross={detail.gross_amount_cents} cents"
        )

        # 3. refund_donation — issue a real 1¢ partial refund. The embed
        # forwards this to sandbox.nmi.com/api/transact.php with type=refund;
        # the response carries a real processor_refund_id.
        refund = await cli.refund_donation(
            target.id,
            amount_cents=1,
            reason="py-sdk-validate",
        )
        print(
            f"[PY] refund_donation → processor_refund_id={refund.processor_refund_id} "
            f"refund_amount={refund.refund_amount_cents} cents"
        )

        # 4. test_webhook — fire a synthetic donation.completed event.
        # The embed's /webhooks/test endpoint emits a spec-compliant
        # envelope (every field on ``DonationEventObject`` populated with
        # synthetic-but-valid values) so the SDK's strict Pydantic schema
        # parses cleanly. Synthetic events are recognizable by their
        # all-zero-UUID donation id and ``synthetic@example.com`` donor.
        synthetic = await cli.test_webhook("donation.completed")
        print(f"[PY] test_webhook → event_id={synthetic.event_id}")

    # Wait for the synthetic test event to land on the sink, then verify
    # its HMAC-SHA256 signature + parse the envelope through the strict
    # Pydantic schema. A WebhookFormatError now indicates a real backend
    # bug (envelope drift from the OpenAPI spec) and is treated as a hard
    # fail — the special-case fallback that previously absorbed it has
    # been removed now that the backend emits spec-compliant envelopes.
    sink_path = Path(cfg["webhook_sink_path"])
    captured = _wait_for_envelope(sink_path, event_id=synthetic.event_id)
    sig = captured["signature"] or captured["signature_lower"]
    sig_v1_prefix = next(
        (p[3:19] for p in sig.split(",") if p.startswith("v1=")),
        "",
    )
    event = verify_webhook(
        body=captured["body"].encode("utf-8"),
        signature=sig,
        secret=cfg["signing_secret"],
    )
    print(
        f"[PY] verify_webhook → event.id={event.id} type={event.type} "
        f"sig_v1_prefix={sig_v1_prefix}…"
    )

    print("[PY] PASS")


if __name__ == "__main__":
    asyncio.run(main())
