"""Модуль для абстракції HTML парсерів.

Пріоритет: selectolax (5-10x) > lxml (2-3x) > html.parser

- get_default_parser() - singleton для найшвидшого доступного адаптера
- get_parser(name) - отримати конкретний парсер по імені
- Уникає створення нового об'єкта на кожну сторінку
"""
from __future__ import annotations

import logging

from graph_crawler.infrastructure.adapters.base import BaseTreeAdapter, TreeElement

logger = logging.getLogger(__name__)

# Singleton для default parser
_default_parser_instance: BaseTreeAdapter | None = None
_parser_type_used: str | None = None

def _detect_best_parser() -> str:
    """
    Визначає найшвидший доступний парсер.

    Пріоритет (ОНОВЛЕНО 2026):
    1. BeautifulSoup + lxml - найнадійніший, коректно парсить <template> теги
    2. BeautifulSoup + html.parser - стандартний fallback
    
    NOTE: selectolax Lexbor ВИМКНЕНО як default через баг з <template> тегами.
    Lexbor правильно ігнорує вміст <template> (HTML5 spec), але багато сайтів
    (Vue.js SSR, React SSR) використовують <template> для server-rendered контенту
    що повинен парситись. BeautifulSoup парсить <template> як звичайний тег.
    
    Користувачі можуть явно вказати selectolax через get_parser("selectolax")
    якщо їм потрібна швидкість і вони впевнені що сайт не використовує <template>.

    Returns:
        Назва найшвидшого НАДІЙНОГО парсера
    """
    # Пробуємо lxml (швидший backend для BeautifulSoup)
    try:
        import lxml

        logger.info("BeautifulSoup + lxml detected - using RELIABLE HTML parser")
        return "lxml"
    except ImportError:
        pass

    # Fallback на html.parser
    logger.info("Using BeautifulSoup + html.parser (consider installing lxml for 2-3x speed)")
    return "html.parser"

def get_default_parser() -> BaseTreeAdapter:
    """
    Повертає singleton найшвидшого доступного адаптера.

    ⚠️ УВАГА: Цей метод повертає SINGLETON!
    НЕ використовуйте для паралельного парсингу - буде race condition!
    Для паралельного парсингу використовуйте create_parser_instance().

    Пріоритет:
    1. BeautifulSoup + lxml - надійний та швидкий
    2. BeautifulSoup + html.parser - завжди доступний
    
    NOTE: selectolax вимкнено через проблеми з <template> тегами

    - Lazy initialization при першому виклику
    - Thread-safe (GIL захищає)

    Returns:
        BaseTreeAdapter instance (найнадійніший доступний)
    """
    global _default_parser_instance, _parser_type_used

    if _default_parser_instance is None:
        parser_type = _detect_best_parser()
        _parser_type_used = parser_type

        # NOTE: selectolax вимкнено як default через проблеми з <template> тегами
        # Завжди використовуємо BeautifulSoup для надійності
        from graph_crawler.infrastructure.adapters.beautifulsoup_adapter import (
            BeautifulSoupAdapter,
        )

        _default_parser_instance = BeautifulSoupAdapter(parser_backend=parser_type)

    return _default_parser_instance

def create_parser_instance() -> BaseTreeAdapter:
    """
    Створює НОВИЙ instance парсера для thread-safe паралельного парсингу.

    Returns:
        НОВИЙ BaseTreeAdapter instance (thread-safe)
    Example:
        >>> # В ThreadPoolExecutor
        >>> def parse_html(html):
        ...     parser = create_parser_instance()  # Новий instance!
        ...     tree = parser.parse(html)
        ...     return parser.find('title').text()
        >>>
        >>> with ThreadPoolExecutor() as executor:
        ...     results = executor.map(parse_html, html_list)
    """
    global _parser_type_used

    # Визначаємо тип парсера якщо ще не визначено
    if _parser_type_used is None:
        _parser_type_used = _detect_best_parser()

    parser_type = _parser_type_used

    # NOTE: selectolax вимкнено як default через проблеми з <template> тегами
    # Завжди використовуємо BeautifulSoup для надійності
    from graph_crawler.infrastructure.adapters.beautifulsoup_adapter import (
        BeautifulSoupAdapter,
    )

    return BeautifulSoupAdapter(parser_backend=parser_type)

def get_parser(name: str = "auto") -> BaseTreeAdapter:
    """
    Повертає парсер за іменем.

    Args:
        name: Ім'я парсера:
            - "auto" - найшвидший доступний (default)
            - "selectolax" - найшвидший (якщо встановлено)
            - "lxml" - швидкий стандарт
            - "beautifulsoup" або "html.parser" - стандартний

    Returns:
        BaseTreeAdapter instance

    Raises:
        ImportError: Якщо запитаний парсер не встановлено

    Example:
        >>> parser = get_parser("selectolax")  # Явно selectolax
        >>> parser = get_parser()  # Автовибір найшвидшого
    """
    if name == "auto":
        return get_default_parser()

    if name == "selectolax":
        from graph_crawler.infrastructure.adapters.selectolax_adapter import (
            SelectolaxAdapter,
        )

        return SelectolaxAdapter()

    if name in ("beautifulsoup", "html.parser", "lxml"):
        from graph_crawler.infrastructure.adapters.beautifulsoup_adapter import (
            BeautifulSoupAdapter,
        )

        backend = "lxml" if name == "lxml" else "html.parser"
        return BeautifulSoupAdapter(parser_backend=backend)

    raise ValueError(f"Unknown parser: {name}. Use: auto, selectolax, lxml, beautifulsoup")

def get_current_parser_type() -> str | None:
    """
    Повертає тип поточного default парсера.

    Returns:
        "selectolax", "lxml", "html.parser" або None якщо ще не ініціалізовано
    """
    return _parser_type_used

__all__ = [
    "BaseTreeAdapter",
    "TreeElement",
    "get_default_parser",
    "get_parser",
    "get_current_parser_type",
    "create_parser_instance",
]
