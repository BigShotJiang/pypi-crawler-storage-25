"""Плагіни для Async HTTP драйвера."""

from graph_crawler.infrastructure.transport.async_http.plugins.autothrottle import (
    AsyncAutoThrottlePlugin,
    AutoThrottleConfig,
    DomainSlot,
)
from graph_crawler.infrastructure.transport.async_http.plugins.autothrottle_v2 import (
    CircuitState,
    EnhancedAutoThrottleConfig,
    EnhancedAutoThrottlePlugin,
    EnhancedDomainSlot,
    ThrottleMode,
)
from graph_crawler.infrastructure.transport.async_http.plugins.headers import (
    AsyncHeadersPlugin,
)
from graph_crawler.infrastructure.transport.async_http.plugins.http_cache import (
    AsyncHTTPCachePlugin,
    CacheEntry,
    LRUCache,
)
from graph_crawler.infrastructure.transport.async_http.plugins.rate_limiter import (
    AsyncRateLimiterPlugin,
)
from graph_crawler.infrastructure.transport.async_http.plugins.retry import (
    AsyncRetryPlugin,
)

__all__ = [
    # Original AutoThrottle
    "AsyncAutoThrottlePlugin",
    "AutoThrottleConfig",
    "DomainSlot",
    # Enhanced AutoThrottle V2 (Production-Ready)
    "EnhancedAutoThrottlePlugin",
    "EnhancedAutoThrottleConfig",
    "EnhancedDomainSlot",
    "ThrottleMode",
    "CircuitState",
    # Other plugins
    "AsyncRetryPlugin",
    "AsyncHeadersPlugin",
    "AsyncRateLimiterPlugin",
    "AsyncHTTPCachePlugin",
    "CacheEntry",
    "LRUCache",
]
