"""
AsyncDriverHTTP2 - HTTP/2 драйвер на основі httpx.

Features:
- HTTP/2 multiplexing (багато запитів в одному з'єднанні)
- Header compression (економія 10-30% на headers)
- Binary protocol (менший overhead)
- Backward compatible з HTTP/1.1
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False
    httpx = None

from graph_crawler.domain.events.event_bus import EventBus
from graph_crawler.domain.value_objects.models import FetchResponse
from graph_crawler.infrastructure.transport.base_plugin import BaseDriverPlugin
from graph_crawler.infrastructure.transport.core.base_async import BaseAsyncDriver
from graph_crawler.infrastructure.transport.core.mixins import (
    PluginSupportMixin,
    RetryMixin,
)
from graph_crawler.shared.constants import (
    DEFAULT_BROWSER_HEADERS,
    DEFAULT_MAX_CONCURRENT_REQUESTS,
    DEFAULT_MAX_RETRIES,
    DEFAULT_REQUEST_TIMEOUT,
    DEFAULT_RETRY_DELAY,
    DEFAULT_USER_AGENT,
)

logger = logging.getLogger(__name__)

class AsyncDriverHTTP2(BaseAsyncDriver, PluginSupportMixin, RetryMixin):
    """
    Async HTTP/2 драйвер на основі httpx.

    Переваги над aiohttp:
    - ✅ HTTP/2 підтримка (multiplexing, header compression)
    - ✅ Автоматичний fallback на HTTP/1.1
    - ✅ Sync/async API
    - ✅ Кращий connection pooling

    Example:
        >>> async with AsyncDriverHTTP2() as driver:
        ...     response = await driver.fetch('https://example.com')
    """

    driver_name = "httpx"

    def __init__(
        self,
        config: dict[str, Any | None] = None,
        event_bus: EventBus | None = None,
        plugins: list[BaseDriverPlugin | None] = None,
    ):
        """
        Ініціалізація AsyncDriverHTTP2.

        Args:
            config: Конфігурація драйвера
            event_bus: EventBus для подій
            plugins: Список плагінів

        Raises:
            ImportError: Якщо httpx не встановлено
        """
        if not HTTPX_AVAILABLE:
            raise ImportError(
                "httpx is required for HTTP/2 support. Install with: pip install httpx[http2]"
            )

        BaseAsyncDriver.__init__(self, config, event_bus)
        self._init_plugin_support(plugins, is_async=True)

        # Client management
        self._client: "httpx.AsyncClient" | None = None

        # Basic settings
        self._timeout = self.config.get("timeout", DEFAULT_REQUEST_TIMEOUT)
        self._user_agent = self.config.get("user_agent", DEFAULT_USER_AGENT)
        self._max_retries = self.config.get("max_retries", DEFAULT_MAX_RETRIES)
        self._retry_delay = self.config.get("retry_delay", DEFAULT_RETRY_DELAY)

        # HTTP/2 settings
        self._http2 = self.config.get("http2", True)  # Включено за замовчуванням
        self._http1 = self.config.get("http1", True)  # Fallback на HTTP/1.1

        # SOCKS5h proxy settings (ОНОВЛЕНО 2026)
        # SOCKS5h = SOCKS5 з DNS resolution через proxy (анонімність!)
        self._proxy = self.config.get("proxy", None)
        self._socks5h = self.config.get("socks5h", None)  # e.g., "socks5h://127.0.0.1:9050"

        # Concurrency
        self.max_concurrent = self.config.get(
            "max_concurrent_requests", DEFAULT_MAX_CONCURRENT_REQUESTS
        )

        # Connection limits
        self._max_keepalive = self.config.get("max_keepalive_connections", 200)
        self._max_connections = self.config.get("max_connections", 500)
        self._keepalive_expiry = self.config.get("keepalive_expiry", 120)

        logger.info(
            f"AsyncDriverHTTP2: "
            f"concurrent={self.max_concurrent}, "
            f"http2={self._http2}, "
            f"connections={self._max_connections}/{self._max_keepalive}, "
            f"timeout={self._timeout}s"
        )

    async def _get_client(self) -> "httpx.AsyncClient":
        """
        Створює або повертає існуючий httpx client з HTTP/2.
        """
        if self._client is None or self._client.is_closed:
            # SSL/TLS Configuration
            ssl_verify = self.config.get("ssl_verify", True)

            # Custom headers з підтримкою zstd
            headers = {
                "User-Agent": self._user_agent,
                **DEFAULT_BROWSER_HEADERS,
            }
            # Оновлюємо Accept-Encoding для HTTP/2
            headers["Accept-Encoding"] = "gzip, deflate, br, zstd"

            # Timeout configuration
            timeout = httpx.Timeout(
                timeout=self._timeout,
                connect=min(5.0, self._timeout),
                read=self._timeout,
                write=self._timeout,
                pool=None,
            )

            # Limits configuration
            limits = httpx.Limits(
                max_keepalive_connections=self._max_keepalive,
                max_connections=self._max_connections,
                keepalive_expiry=self._keepalive_expiry,
            )

            # Proxy configuration (ОНОВЛЕНО 2026: SOCKS5h підтримка)
            proxy_url = self._socks5h or self._proxy

            self._client = httpx.AsyncClient(
                http2=self._http2,  # ✅ HTTP/2 підтримка!
                http1=self._http1,  # Fallback на HTTP/1.1
                headers=headers,
                timeout=timeout,
                limits=limits,
                verify=ssl_verify,
                follow_redirects=True,
                proxy=proxy_url,  # ✅ SOCKS5h для анонімного краулінгу через Tor
            )

            # Log HTTP version and proxy
            proxy_info = f", proxy={proxy_url}" if proxy_url else ""
            logger.debug(
                f"httpx client created: HTTP/2={self._http2}, HTTP/1.1={self._http1}{proxy_info}"
            )

        return self._client

    async def _do_fetch(self, url: str) -> FetchResponse:
        """Core fetch з retry support."""
        return await self._with_retry_async(
            self._fetch_simple,
            url,
            max_retries=self._max_retries,
            retry_delay=self._retry_delay,
            retry_on=(httpx.HTTPError, asyncio.TimeoutError) if HTTPX_AVAILABLE else (asyncio.TimeoutError,),
        )

    async def _fetch_simple(self, url: str) -> FetchResponse:
        """Простий fetch без плагінів."""
        client = await self._get_client()

        try:
            response = await client.get(url)

            # Логуємо HTTP версію
            if hasattr(response, 'http_version'):
                logger.debug("Response HTTP version: %s for %s", response.http_version, url)

            return FetchResponse(
                url=url,
                html=response.text,
                status_code=response.status_code,
                headers=dict(response.headers),
                final_url=str(response.url) if response.url != url else None,
            )

        except httpx.HTTPError as e:
            logger.warning("HTTP error for %s: %s", url, e)
            return FetchResponse(
                url=url,
                html=None,
                status_code=None,
                headers={},
                error="HTTPError: %s" % e,
            )
        except Exception as e:
            logger.error("Unexpected error for %s: %s", url, e)
            return FetchResponse(
                url=url,
                html=None,
                status_code=None,
                headers={},
                error="%s: %s" % (type(e).__name__, e),
            )

    async def fetch_many(self, urls: list[str]) -> list[FetchResponse]:
        """
        Паралельне завантаження з контролем concurrency.
        """
        if not urls:
            return []

        semaphore = asyncio.Semaphore(self.max_concurrent)

        async def fetch_limited(url: str) -> FetchResponse:
            async with semaphore:
                return await self.fetch(url)

        tasks = [fetch_limited(url) for url in urls]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        processed = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                processed.append(
                    self._create_error_response(urls[i], f"{type(result).__name__}: {result}")
                )
            else:
                processed.append(result)

        return processed

    async def fetch_fast(self, url: str) -> FetchResponse:
        """
        Ultra-fast fetch БЕЗ плагінів.

        Для максимальної швидкості коли не потрібні:
        - Rate limiting
        - Retry logic
        - Custom headers/cookies
        """
        client = await self._get_client()

        try:
            response = await client.get(url)

            return FetchResponse(
                url=url,
                html=response.text,
                status_code=response.status_code,
                headers=dict(response.headers),
                final_url=str(response.url) if response.url != url else None,
            )
        except Exception as e:
            return FetchResponse(
                url=url,
                html=None,
                status_code=None,
                headers={},
                error=f"{type(e).__name__}: {e}",
            )

    async def fetch_many_fast(self, urls: list[str]) -> list[FetchResponse]:
        """Ultra-fast batch fetch БЕЗ плагінів."""
        if not urls:
            return []

        semaphore = asyncio.Semaphore(self.max_concurrent)

        async def fetch_limited(url: str) -> FetchResponse:
            async with semaphore:
                return await self.fetch_fast(url)

        tasks = [asyncio.create_task(fetch_limited(url)) for url in urls]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        processed = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                processed.append(
                    FetchResponse(
                        url=urls[i],
                        html=None,
                        status_code=None,
                        headers={},
                        error=f"{type(result).__name__}: {result}",
                    )
                )
            else:
                processed.append(result)

        return processed

    async def _do_close(self) -> None:
        """Close client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()

        await asyncio.sleep(0.1)

        self._client = None

        await self._teardown_plugins_async()
