"""Контекст для Async HTTP драйвера.

Аналогічно HTTPContext, але з aiohttp.ClientSession.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import aiohttp

from graph_crawler.infrastructure.transport.context import DriverContext


@dataclass(slots=True)
class AsyncHTTPContext(DriverContext):
    """
    Контекст для Async HTTP драйвера (aiohttp). Memory-optimized with __slots__.

    Attributes:
        url: URL для запиту
        method: HTTP метод
        headers: HTTP headers
        cookies: Cookies
        params: Query parameters
        body: Request body
        session: aiohttp.ClientSession об'єкт (доступ!)
        timeout: Timeout

        # Після відповіді:
        response: aiohttp.ClientResponse
        status_code: HTTP статус
        response_headers: Response headers
        html: HTML контент
        error: Повідомлення про помилку
    """

    # Request параметри
    method: str = "GET"
    headers: dict[str, str] = field(default_factory=dict)
    cookies: dict[str, str] = field(default_factory=dict)
    params: dict[str, Any] = field(default_factory=dict)
    body: Any | None = None
    timeout: int = 30

    # Доступ до внутрішніх об'єктів
    session: aiohttp.ClientSession | None = None

    # Response дані
    response: aiohttp.ClientResponse | None = None
    status_code: int | None = None
    response_headers: dict[str, str] = field(default_factory=dict)
    html: str | None = None
    error: str | None = None
