"""Async HTTP Driver module - asynchronous aiohttp-based driver with plugin support.

Drivers:
- AsyncDriver (driver_v4.py): Main driver with adaptive DNS resolver (works on Windows!)
- AsyncDriverHTTP2 (driver_httpx.py): HTTP/2 support via httpx
"""

from graph_crawler.infrastructure.transport.async_http.config import AsyncDriverConfig
from graph_crawler.infrastructure.transport.async_http.context import AsyncHTTPContext
from graph_crawler.infrastructure.transport.async_http.driver_httpx import AsyncDriverHTTP2
from graph_crawler.infrastructure.transport.async_http.driver_v4 import AsyncDriver
from graph_crawler.infrastructure.transport.async_http.stages import AsyncHTTPStage

__all__ = [
    "AsyncDriver",
    "AsyncDriverHTTP2",
    "AsyncDriverConfig",
    "AsyncHTTPStage",
    "AsyncHTTPContext",
]
