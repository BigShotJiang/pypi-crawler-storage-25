"""
Adaptive Compression Strategy.

Вибирає оптимальний compression в залежності від:
- Типу контенту (HTML, JSON, binary)
- Розміру файлу
- Bandwidth/CPU trade-off
- Історичної ефективності
"""
from __future__ import annotations

from enum import Enum
from urllib.parse import urlparse


class CompressionAlgorithm(Enum):
    """Алгоритми стиснення."""
    IDENTITY = "identity"  # Без стиснення
    GZIP = "gzip"
    DEFLATE = "deflate"
    BROTLI = "br"
    ZSTD = "zstd"

class ContentTypeCategory(Enum):
    """Типи контенту."""
    HTML = "html"
    JSON = "json"
    XML = "xml"
    CSS = "css"
    JAVASCRIPT = "javascript"
    IMAGE = "image"
    VIDEO = "video"
    BINARY = "binary"

class AdaptiveCompressionStrategy:
    """
    Адаптивна стратегія вибору compression.

    Вчиться на історичних даних які алгоритми дають найкращий результат.
    """

    # Оптимальні compression для кожного типу контенту
    OPTIMAL_COMPRESSION = {
        ContentTypeCategory.HTML: [CompressionAlgorithm.BROTLI, CompressionAlgorithm.ZSTD, CompressionAlgorithm.GZIP],
        ContentTypeCategory.JSON: [CompressionAlgorithm.GZIP, CompressionAlgorithm.ZSTD],  # Швидкість важливіша
        ContentTypeCategory.XML: [CompressionAlgorithm.BROTLI, CompressionAlgorithm.GZIP],
        ContentTypeCategory.CSS: [CompressionAlgorithm.BROTLI, CompressionAlgorithm.GZIP],
        ContentTypeCategory.JAVASCRIPT: [CompressionAlgorithm.BROTLI, CompressionAlgorithm.GZIP],
        ContentTypeCategory.IMAGE: [CompressionAlgorithm.IDENTITY],  # Вже стиснуто
        ContentTypeCategory.VIDEO: [CompressionAlgorithm.IDENTITY],
        ContentTypeCategory.BINARY: [CompressionAlgorithm.GZIP],
    }

    def __init__(self):
        self.stats: dict[str, dict[str, dict]] = {}  # URL pattern → compression effectiveness

    def get_accept_encoding(self, url: str, content_hint: str | None = None) -> str:
        """
        Повертає оптимальний Accept-Encoding для URL.

        Args:
            url: URL для запиту
            content_hint: Підказка про тип контенту (опціонально)

        Returns:
            Accept-Encoding header value
        """
        content_type = self._detect_content_type(url, content_hint)
        algorithms = self.OPTIMAL_COMPRESSION.get(content_type, [CompressionAlgorithm.GZIP])

        # Конвертуємо в header
        return ", ".join(alg.value for alg in algorithms)

    def _detect_content_type(self, url: str, hint: str | None = None) -> ContentTypeCategory:
        """Детектує тип контенту з URL."""
        if hint:
            if "json" in hint.lower():
                return ContentTypeCategory.JSON
            if "xml" in hint.lower():
                return ContentTypeCategory.XML

        # З розширення файлу
        path = urlparse(url).path.lower()

        if path.endswith(('.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg')):
            return ContentTypeCategory.IMAGE
        if path.endswith(('.mp4', '.avi', '.mov', '.webm')):
            return ContentTypeCategory.VIDEO
        if path.endswith('.json'):
            return ContentTypeCategory.JSON
        if path.endswith('.xml'):
            return ContentTypeCategory.XML
        if path.endswith('.css'):
            return ContentTypeCategory.CSS
        if path.endswith(('.js', '.mjs')):
            return ContentTypeCategory.JAVASCRIPT

        # За замовчуванням - HTML
        return ContentTypeCategory.HTML

    def record_compression_stats(
        self,
        url: str,
        algorithm: str,
        original_size: int,
        compressed_size: int,
        decompress_time_ms: float
    ):
        """Записує статистику ефективності compression."""
        ratio = compressed_size / original_size if original_size > 0 else 1.0

        pattern = self._get_url_pattern(url)
        if pattern not in self.stats:
            self.stats[pattern] = {}

        if algorithm not in self.stats[pattern]:
            self.stats[pattern][algorithm] = {
                "total_requests": 0,
                "avg_ratio": 0.0,
                "avg_decompress_ms": 0.0,
            }

        stats = self.stats[pattern][algorithm]
        n = stats["total_requests"]

        # Exponential moving average
        stats["avg_ratio"] = (stats["avg_ratio"] * n + ratio) / (n + 1)
        stats["avg_decompress_ms"] = (stats["avg_decompress_ms"] * n + decompress_time_ms) / (n + 1)
        stats["total_requests"] += 1

    def _get_url_pattern(self, url: str) -> str:
        """Витягує pattern з URL (domain + path prefix)."""
        parsed = urlparse(url)
        # Беремо domain + перший рівень path
        path_parts = parsed.path.split('/')[:2]
        return f"{parsed.netloc}{'/'.join(path_parts)}"

    def get_best_algorithm(self, url: str) -> str | None:
        """Повертає найкращий compression на основі історії."""
        pattern = self._get_url_pattern(url)

        if pattern not in self.stats:
            return None

        best_algo = None
        best_score = float('inf')

        for algo, algo_stats in self.stats[pattern].items():
            # Score: compression ratio × decompress time
            # Нижче = краще
            score = algo_stats["avg_ratio"] * (1 + algo_stats["avg_decompress_ms"] / 100)

            if score < best_score:
                best_score = score
                best_algo = algo

        return best_algo

# Global instance
_compression_strategy: AdaptiveCompressionStrategy | None = None

def get_compression_strategy() -> AdaptiveCompressionStrategy:
    """Повертає глобальну стратегію."""
    global _compression_strategy
    if _compression_strategy is None:
        _compression_strategy = AdaptiveCompressionStrategy()
    return _compression_strategy
