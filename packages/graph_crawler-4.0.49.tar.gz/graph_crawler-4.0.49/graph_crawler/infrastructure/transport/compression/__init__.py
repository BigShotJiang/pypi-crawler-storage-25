"""Compression module for adaptive compression strategy."""

from graph_crawler.infrastructure.transport.compression.strategy import (
    AdaptiveCompressionStrategy,
    CompressionAlgorithm,
    ContentTypeCategory,
    get_compression_strategy,
)

__all__ = [
    "AdaptiveCompressionStrategy",
    "CompressionAlgorithm",
    "ContentTypeCategory",
    "get_compression_strategy",
]
