"""Контекст для Playwright драйвера.

Найважливіший контекст - дає доступ до:
- browser: Browser об'єкт
- context: BrowserContext об'єкт
- page: Page об'єкт

Це дозволяє плагінам виконувати будь-які операції з браузером!
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from graph_crawler.infrastructure.transport.context import DriverContext

# Type hints (для IDE, реальні імпорти в рантаймі)
try:
    from playwright.async_api import (  # type: ignore[import-not-found]
        Browser,
        Page,
        Response,
    )
    from playwright.async_api import BrowserContext as PWContext  # type: ignore[import-not-found]

    PLAYWRIGHT_TYPES_AVAILABLE = True
except ImportError:
    # Fallback якщо playwright не встановлено
    Browser = None  # type: ignore[misc,assignment]
    PWContext = None  # type: ignore[misc,assignment]
    Page = None  # type: ignore[misc,assignment]
    Response = None  # type: ignore[misc,assignment]
    PLAYWRIGHT_TYPES_AVAILABLE = False

@dataclass(slots=True)
class BrowserContext(DriverContext):
    """
    Контекст для Playwright драйвера.

    """

    # Доступ до Playwright об'єктів ( ГОЛОВНЕ!)
    browser: Any | None = None
    context: Any | None = None
    page: Any | None = None

    # Response дані
    response: Any | None = None
    status_code: int | None = None
    response_headers: dict[str, str] = field(default_factory=dict)
    html: str | None = None
    error: str | None = None

    # Додаткові налаштування
    wait_selector: str | None = None
    scroll_page: bool = False
    screenshot_path: str | None = None
    timeout: int = 30000  # мілісекунди
