"""Менеджер плагінів для драйверів.

Відповідає за:
- Реєстрацію плагінів
- Виклик хуків на етапах драйвера
- Підписку плагінів на події інших плагінів
- Обробку помилок плагінів
- Пріоритизацію виконання
- Перевірку сумісності плагінів
"""
from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict
from typing import Any

from graph_crawler.infrastructure.transport.base_plugin import BaseDriverPlugin
from graph_crawler.infrastructure.transport.context import DriverContext

logger = logging.getLogger(__name__)

class DriverPluginManager:
    """
    Менеджер плагінів для драйвера.

    Координує виконання плагінів на різних етапах роботи драйвера.
    Автоматично перевіряє сумісність плагінів при реєстрації.

    Приклад:
        manager = DriverPluginManager(is_async=True)
        manager.register(StealthPlugin())
        manager.register(CaptchaSolverPlugin())

        # Виконання хуків
        ctx = await manager.execute_hook('navigation_completed', ctx)
    """

    def __init__(self, is_async: bool = False, check_compatibility: bool = True):
        """
        Ініціалізація менеджера.

        Args:
            is_async: Чи плагіни асинхронні (залежить від драйвера)
            check_compatibility: Чи перевіряти сумісність плагінів (default: True)
        """
        self.is_async = is_async
        self.check_compatibility = check_compatibility
        self.plugins: list[BaseDriverPlugin] = []

        # Індексація плагінів по хукам для швидкого доступу
        self.hook_plugins: dict[str, list[BaseDriverPlugin]] = defaultdict(list)

        # Індексація плагінів по подіям
        self.event_plugins: dict[str, list[BaseDriverPlugin]] = defaultdict(list)

        logger.info(
            "DriverPluginManager initialized (async=%s, compat_check=%s)",
            is_async, check_compatibility
        )

    def register(self, plugin: BaseDriverPlugin):
        """
        Реєструє плагін у менеджері.

        Args:
            plugin: Екземпляр плагіна для реєстрації

        Raises:
            ValueError: Якщо плагін несумісний з вже зареєстрованими
        """
        if not plugin.enabled:
            logger.debug("Plugin '%s' is disabled, skipping registration", plugin.name)
            return

        # Перевіряємо сумісність з існуючими плагінами
        if self.check_compatibility and self.plugins:
            self._check_plugin_compatibility(plugin)

        # Додаємо в загальний список
        self.plugins.append(plugin)

        # Індексуємо по хукам - отримуємо value якщо це Enum
        for hook in plugin.get_hooks():
            hook_name = hook.value if hasattr(hook, "value") else str(hook)
            self.hook_plugins[hook_name].append(plugin)

        # Індексуємо по подіях
        for event in plugin.get_events():
            event_name = event.value if hasattr(event, "value") else str(event)
            self.event_plugins[event_name].append(plugin)

        # Сортуємо плагіни по пріоритету (менше число = вищий пріоритет)
        for hook_name in self.hook_plugins:
            self.hook_plugins[hook_name].sort(key=lambda p: p.priority)

        for event_name in self.event_plugins:
            self.event_plugins[event_name].sort(key=lambda p: p.priority)

        # Виконуємо setup
        try:
            plugin.setup()
            logger.info("Plugin '%s' registered successfully", plugin.name)
        except Exception as e:
            logger.error("Error in plugin '%s' setup: %s", plugin.name, e)
            plugin.enabled = False

    def _check_plugin_compatibility(self, new_plugin: BaseDriverPlugin):
        """
        Перевіряє сумісність нового плагіна з існуючими.

        Args:
            new_plugin: Новий плагін для перевірки

        Raises:
            ValueError: Якщо є несумісність
        """
        try:
            from graph_crawler.infrastructure.transport.playwright.plugins.compatibility import (
                check_plugin_compatibility,
            )

            # Перевіряємо новий плагін разом з існуючими
            all_plugins = self.plugins + [new_plugin]
            check_plugin_compatibility(all_plugins, raise_on_conflict=True)

        except ImportError:
            # Якщо модуль сумісності недоступний - пропускаємо перевірку
            logger.debug("Compatibility module not available, skipping check")
        except ValueError as e:
            # Логуємо попередження замість помилки (для м'якого режиму)
            logger.warning("Plugin compatibility issue: %s", e)
            # Можна розкоментувати для строгого режиму:
            # raise

    def setup_event_subscriptions(self, context: DriverContext):
        """
        Налаштовує підписки плагінів на події через контекст.

        Викликається перед виконанням запиту.

        Args:
            context: Контекст драйвера
        """
        for event_name, plugins in self.event_plugins.items():
            for plugin in plugins:
                if not plugin.enabled:
                    continue

                # Створюємо handler для події
                handler_name = f"on_{event_name}"
                if hasattr(plugin, handler_name):
                    handler = getattr(plugin, handler_name)
                    context.subscribe(event_name, handler)
                    logger.debug("Plugin '%s' subscribed to event '%s'", plugin.name, event_name)

    def execute_hook(self, hook_name: str, context: DriverContext) -> DriverContext:
        """
        Виконує всі плагіни для вказаного хуку (синхронна версія).

        Args:
            hook_name: Назва хуку (етапу) - може бути Enum або string
            context: Контекст драйвера

        Returns:
            Оновлений контекст
        """
        # Конвертуємо Enum в string якщо потрібно
        hook_key = hook_name.value if hasattr(hook_name, "value") else str(hook_name)
        plugins = self.hook_plugins.get(hook_key, [])

        if not plugins:
            return context

        logger.debug("Executing hook '%s' with %s plugin(s)", hook_key, len(plugins))

        for plugin in plugins:
            if not plugin.enabled:
                continue

            if context.cancelled:
                logger.info(
                    "Execution cancelled, skipping remaining plugins for '%s'",
                    hook_key
                )
                break

            # Перевіряємо наявність handler методу
            handler_name = "on_%s" % hook_key
            if not hasattr(plugin, handler_name):
                logger.warning("Plugin '%s' has no handler for '%s'", plugin.name, hook_key)
                continue

            handler = getattr(plugin, handler_name)

            try:
                start_time = time.time()
                context = handler(context)
                duration = time.time() - start_time

                plugin._record_execution(duration)
                logger.debug("Plugin '%s' executed '%s' in %.3fs", plugin.name, hook_key, duration)

            except Exception as e:
                logger.error(
                    "Error in plugin '%s' on hook '%s': %s",
                    plugin.name, hook_key, e, exc_info=True
                )
                context.errors.append(e)
                plugin._record_execution(0, error=True)

                context.emit("plugin_error", plugin_name=plugin.name, hook=hook_key, error=str(e))

        return context

    async def execute_hook_async(self, hook_name: str, context: DriverContext) -> DriverContext:
        """
        Виконує всі плагіни для вказаного хуку (асинхронна версія).

        Args:
            hook_name: Назва хуку (етапу) - може бути Enum або string
            context: Контекст драйвера

        Returns:
            Оновлений контекст
        """
        # Конвертуємо Enum в string якщо потрібно
        hook_key = hook_name.value if hasattr(hook_name, "value") else str(hook_name)
        plugins = self.hook_plugins.get(hook_key, [])

        if not plugins:
            return context

        logger.debug("Executing async hook '%s' with %s plugin(s)", hook_key, len(plugins))

        for plugin in plugins:
            if not plugin.enabled:
                continue

            if context.cancelled:
                logger.info(
                    "Execution cancelled, skipping remaining plugins for '%s'",
                    hook_key
                )
                break

            # Перевіряємо наявність handler методу
            handler_name = "on_%s" % hook_key
            if not hasattr(plugin, handler_name):
                logger.warning("Plugin '%s' has no handler for '%s'", plugin.name, hook_key)
                continue

            handler = getattr(plugin, handler_name)

            try:
                start_time = time.time()

                # Викликаємо async handler
                if asyncio.iscoroutinefunction(handler):
                    context = await handler(context)
                else:
                    # Fallback для sync методів в async контексті
                    context = handler(context)

                duration = time.time() - start_time

                plugin._record_execution(duration)
                logger.debug("Plugin '%s' executed '%s' in %.3fs", plugin.name, hook_key, duration)

            except Exception as e:
                logger.error(
                    "Error in plugin '%s' on hook '%s': %s",
                    plugin.name, hook_key, e, exc_info=True
                )
                context.errors.append(e)
                plugin._record_execution(0, error=True)

                context.emit("plugin_error", plugin_name=plugin.name, hook=hook_key, error=str(e))

        return context

    def get_plugin_by_name(self, name: str) -> BaseDriverPlugin | None:
        """
        Знаходить плагін за назвою.

        Args:
            name: Назва плагіна

        Returns:
            Екземпляр плагіна або None
        """
        for plugin in self.plugins:
            if plugin.name == name:
                return plugin
        return None

    def get_stats(self) -> dict[str, Any]:
        """
        Повертає статистику по всіх плагінах.

        Returns:
            Словник зі статистикою
        """
        return {
            "total_plugins": len(self.plugins),
            "enabled_plugins": sum(1 for p in self.plugins if p.enabled),
            "is_async": self.is_async,
            "plugins": [p.get_stats() for p in self.plugins],
        }

    def teardown_all(self):
        """Виконує teardown для всіх плагінів."""
        logger.info("Tearing down all plugins...")

        for plugin in self.plugins:
            try:
                # Перевіряємо чи teardown є coroutine
                if hasattr(plugin, "teardown") and asyncio.iscoroutinefunction(
                    plugin.teardown
                ):
                    # Для async teardown в sync контексті - створюємо новий event loop
                    try:
                        loop = asyncio.get_running_loop()
                        # Якщо вже є running loop - створюємо task
                        loop.create_task(plugin.teardown())
                    except RuntimeError:
                        # Немає running loop - запускаємо в новому
                        asyncio.run(plugin.teardown())
                else:
                    plugin.teardown()
            except Exception as e:
                logger.error("Error in plugin '%s' teardown: %s", plugin.name, e)

        logger.info("All plugins torn down")

    async def teardown_all_async(self):
        """Async виконує teardown для всіх плагінів."""
        logger.info("Tearing down all plugins (async)...")

        for plugin in self.plugins:
            try:
                if hasattr(plugin, "teardown_async") and asyncio.iscoroutinefunction(
                    plugin.teardown_async
                ):
                    await plugin.teardown_async()
                elif hasattr(plugin, "teardown") and asyncio.iscoroutinefunction(
                    plugin.teardown
                ):
                    # Якщо teardown є coroutine - await його
                    await plugin.teardown()
                else:
                    plugin.teardown()
            except Exception as e:
                logger.error("Error in plugin '%s' teardown: %s", plugin.name, e)

        logger.info("All plugins torn down")

    def __repr__(self):
        return "DriverPluginManager(plugins=%s, async=%s)" % (len(self.plugins), self.is_async)
