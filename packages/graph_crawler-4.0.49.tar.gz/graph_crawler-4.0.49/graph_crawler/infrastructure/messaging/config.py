"""Конфігурація для distributed crawling через YAML.

Цей модуль надає Pydantic схеми для налаштування розподіленого краулінгу.
"""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, model_validator

from graph_crawler.shared.constants import (
    DEFAULT_CELERY_TASK_TIME_LIMIT,
    DEFAULT_CELERY_WORKERS,
    DEFAULT_REDIS_DB,
    DEFAULT_REDIS_HOST,
    DEFAULT_REDIS_PORT,
    MAX_API_WORKERS,
    MAX_PAGES_DEFAULT,
)


class DistributedBrokerConfig(BaseModel):
    """Конфігурація Redis/RabbitMQ брокера для Celery.

    Attributes:
        type: Тип брокера ('redis' або 'rabbitmq')
        host: Адреса сервера брокера
        port: Порт брокера
        db: Номер бази даних (тільки для Redis)
        password: Пароль для підключення (опціонально)

    Example:
        broker = DistributedBrokerConfig(
            type="redis",
            host="server11.example.com",
            port=DEFAULT_REDIS_PORT,
            db=0
        )
    """

    type: Literal["redis", "rabbitmq"] = "redis"
    host: str = DEFAULT_REDIS_HOST
    port: int = DEFAULT_REDIS_PORT
    db: int = DEFAULT_REDIS_DB
    password: str | None = None

    @property
    def url(self) -> str:
        """Генерує URL для Celery.

        Returns:
            Connection string для Celery broker
        """
        if self.type == "redis":
            auth = f":{self.password}@" if self.password else ""
            return f"redis://{auth}{self.host}:{self.port}/{self.db}"
        else:
            auth = f":{self.password}@" if self.password else ""
            return f"amqp://{auth}{self.host}:{self.port}//"

class DistributedDatabaseConfig(BaseModel):
    """Конфігурація БД для збереження результатів.

    Підтримує три типи:
    Example:
        # Memory storage (локальне)
        db = DistributedDatabaseConfig(type="memory")
    """

    type: Literal["memory", "mongodb", "postgresql"]
    host: str | None = None
    port: int | None = None
    database: str | None = None
    username: str | None = None
    password: str | None = None

    @model_validator(mode="after")
    def validate_database_config(self):
        """Валідація конфігурації залежно від типу."""
        if self.type in ("mongodb", "postgresql"):
            if not self.host:
                raise ValueError(f"'host' is required for {self.type}")
            if not self.port:
                raise ValueError(f"'port' is required for {self.type}")
            if not self.database:
                raise ValueError(f"'database' is required for {self.type}")
        return self

    @property
    def connection_string(self) -> str | None:
        """Генерує connection string.

        Returns:
            Connection string для БД або None для memory
        """
        if self.type == "memory":
            return None
        elif self.type == "mongodb":
            auth = f"{self.username}:{self.password}@" if self.username else ""
            return f"mongodb://{auth}{self.host}:{self.port}/"
        else:
            auth = f"{self.username}:{self.password}@" if self.username else ""
            return f"postgresql://{auth}{self.host}:{self.port}/{self.database}"

class DistributedProxyConfig(BaseModel):
    """Конфігурація proxy rotation.

    Attributes:
        enabled: Чи використовувати proxy
        type: Тип джерела proxy ('file' або 'api')
        source: Шлях до файлу або API URL

    Example:
        proxy = DistributedProxyConfig(
            enabled=True,
            type="file",
            source="./proxies.txt"
        )
    """

    enabled: bool = False
    type: Literal["file", "api"] = "file"
    source: str = ""

class CrawlTaskConfig(BaseModel):
    """Конфігурація задачі краулінгу.

    Attributes:
    Example:
        # Використання aliases (зручно)
        task = CrawlTaskConfig(
            urls=["https://example.com"],
            extractors=["phones", "emails"]
        )
    """

    urls: list[str]
    max_depth: int = 3
    max_pages: int | None = MAX_PAGES_DEFAULT
    extractors: list[Literal["phones", "emails", "prices"]] = []  # Shortcut aliases
    plugins: list[str] = []  # Повні import paths (має пріоритет)

class DistributedCrawlConfig(BaseModel):
    """Головна конфігурація distributed crawling.

    Attributes:
    Example:
        # З memory storage (локально)
        config = DistributedCrawlConfig(
            broker=DistributedBrokerConfig(host="server.com"),
            database=DistributedDatabaseConfig(type="memory"),
            crawl_task=CrawlTaskConfig(urls=["https://example.com"])
        )
    """

    broker: DistributedBrokerConfig
    database: DistributedDatabaseConfig
    proxy: DistributedProxyConfig | None = None
    crawl_task: CrawlTaskConfig

    # Celery settings
    workers: int = Field(default=DEFAULT_CELERY_WORKERS, ge=1, le=MAX_API_WORKERS)
    task_time_limit: int = DEFAULT_CELERY_TASK_TIME_LIMIT
    worker_prefetch_multiplier: int = 4

def load_config(yaml_path: str) -> DistributedCrawlConfig:
    """Завантажити конфіг з YAML файлу.

    Args:
        yaml_path: Шлях до YAML файлу з конфігурацією

    Returns:
        DistributedCrawlConfig об'єкт

    Raises:
        FileNotFoundError: Якщо файл не знайдено
        yaml.YAMLError: Якщо помилка парсингу YAML
        pydantic.ValidationError: Якщо некоректна конфігурація

    Example:
        config = load_config("config.yaml")
        package_crawler = EasyDistributedCrawler(config)
    """
    from pathlib import Path

    import yaml

    path = Path(yaml_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {yaml_path}")

    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f)

    return DistributedCrawlConfig(**data)
