"""
Прискорення GraphCrawler.

Цей модуль надає прискорені версії критичних функцій:
- SimHash обчислення (Numba JIT)
- Hamming distance (Numba JIT)
- Memory-optimized data structures (__slots__)
- Memory-efficient generators

Автоматичний fallback на pure Python якщо Numba недоступна.

Usage:
    from graph_crawler.optimizations import (
        # SimHash
        compute_simhash_fast,
        hamming_distance_fast,
        is_numba_available,
        # Memory-optimized classes
        SlottedURLInfo,
        SlottedCrawlProgress,
        SlottedMemorySnapshot,
        CompactURLSet,
        # Generators
        chunked_iterator,
        streaming_filter,
        unique_by_hash,
    )
"""

from .generators import (
    async_chunked_iterator,
    batched_processor,
    chunked_iterator,
    flatten_iterator,
    lazy_map,
    limited_iterator,
    pairwise_iterator,
    streaming_filter,
    unique_by_hash,
    unique_iterator,
    windowed_iterator,
)
from .memory_slots import (
    CompactURLSet,
    SlottedBatchResult,
    SlottedCrawlProgress,
    SlottedMemorySnapshot,
    SlottedQueueItem,
    SlottedURLInfo,
    compare_memory_savings,
    measure_object_size,
)
from .simhash_numba import (
    benchmark_simhash,
    compute_simhash_fast,
    get_optimization_status,
    hamming_distance_fast,
    is_numba_available,
)

__all__ = [
    # SimHash optimizations
    "compute_simhash_fast",
    "hamming_distance_fast",
    "is_numba_available",
    "get_optimization_status",
    "benchmark_simhash",
    # Memory-optimized structures
    "SlottedURLInfo",
    "SlottedCrawlProgress",
    "SlottedMemorySnapshot",
    "SlottedBatchResult",
    "CompactURLSet",
    "SlottedQueueItem",
    "measure_object_size",
    "compare_memory_savings",
    # Generators
    "chunked_iterator",
    "streaming_filter",
    "lazy_map",
    "batched_processor",
    "unique_iterator",
    "unique_by_hash",
    "limited_iterator",
    "windowed_iterator",
    "pairwise_iterator",
    "flatten_iterator",
    "async_chunked_iterator",
]
