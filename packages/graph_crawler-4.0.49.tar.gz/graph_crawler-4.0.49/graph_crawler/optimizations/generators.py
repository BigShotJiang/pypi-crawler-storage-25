"""Memory-efficient generators for crawling operations.

Цей модуль містить generators для memory-efficient обробки великих колекцій.
Замість створення списків в RAM, дані обробляються потоково.

Економія пам'яті:
- List: весь вміст в RAM одночасно
- Generator: один елемент за раз
- Savings: 90%+ при обробці великих колекцій

Usage:
    >>> from graph_crawler.optimizations.generators import (
    ...     chunked_iterator,
    ...     streaming_filter,
    ...     lazy_map,
    ... )
    >>>
    >>> # Process URLs in chunks (memory-efficient)
    >>> for chunk in chunked_iterator(urls, chunk_size=100):
    ...     process_batch(chunk)
"""

from __future__ import annotations

from typing import (
    Any,
    Callable,
    Generator,
    Iterable,
    TypeVar,
)

T = TypeVar('T')
R = TypeVar('R')


def chunked_iterator(
    iterable: Iterable[T],
    chunk_size: int = 100,
) -> Generator[list[T], None, None]:
    """
    Yield successive chunks from an iterable.

    Memory-efficient alternative to slicing large lists.
    Each chunk is yielded and can be garbage collected before the next.

    Args:
        iterable: Source iterable
        chunk_size: Maximum size of each chunk

    Yields:
        Lists of up to chunk_size elements

    Example:
        >>> urls = ['url1', 'url2', ..., 'url1000']
        >>> for chunk in chunked_iterator(urls, 100):
        ...     # Process 100 URLs at a time
        ...     await process_batch(chunk)
    """
    chunk: list[T] = []
    for item in iterable:
        chunk.append(item)
        if len(chunk) >= chunk_size:
            yield chunk
            chunk = []
    if chunk:
        yield chunk


def streaming_filter(
    iterable: Iterable[T],
    predicate: Callable[[T], bool],
) -> Generator[T, None, None]:
    """
    Memory-efficient filter that yields items one at a time.

    Unlike built-in filter(), this explicitly documents memory behavior
    and works with any iterable without materializing it.

    Args:
        iterable: Source iterable
        predicate: Function that returns True for items to keep

    Yields:
        Items where predicate(item) is True

    Example:
        >>> urls = iter(large_url_list)  # Don't materialize
        >>> valid_urls = streaming_filter(urls, is_valid_url)
        >>> for url in valid_urls:
        ...     process(url)
    """
    for item in iterable:
        if predicate(item):
            yield item


def lazy_map(
    iterable: Iterable[T],
    func: Callable[[T], R],
) -> Generator[R, None, None]:
    """
    Memory-efficient map that yields results one at a time.

    Args:
        iterable: Source iterable
        func: Transformation function

    Yields:
        Transformed items

    Example:
        >>> nodes = iter(graph.nodes.values())
        >>> urls = lazy_map(nodes, lambda n: n.url)
        >>> for url in urls:
        ...     print(url)
    """
    for item in iterable:
        yield func(item)


def batched_processor(
    iterable: Iterable[T],
    processor: Callable[[list[T]], list[R]],
    batch_size: int = 100,
) -> Generator[R, None, None]:
    """
    Process items in batches but yield results individually.

    Useful for batch operations (DB inserts, API calls) while maintaining
    streaming interface for consumers.

    Args:
        iterable: Source iterable
        processor: Function that processes a batch and returns results
        batch_size: Size of batches for processor

    Yields:
        Individual results from processor

    Example:
        >>> def batch_fetch(urls):
        ...     return [fetch(url) for url in urls]
        >>>
        >>> for result in batched_processor(urls, batch_fetch, 50):
        ...     handle_result(result)
    """
    for chunk in chunked_iterator(iterable, batch_size):
        results = processor(chunk)
        for result in results:
            yield result


def unique_iterator(
    iterable: Iterable[T],
    key: Callable[[T | None, Any]] = None,
) -> Generator[T, None, None]:
    """
    Yield unique items from iterable (preserving order).

    Memory usage: O(n) for seen set, but only stores keys, not items.

    Args:
        iterable: Source iterable
        key: Optional function to extract comparison key

    Yields:
        Unique items (first occurrence of each)

    Example:
        >>> urls = ['url1', 'url2', 'url1', 'url3']
        >>> unique = list(unique_iterator(urls))
        >>> unique
        ['url1', 'url2', 'url3']
    """
    seen: set[Any] = set()
    key_func = key or (lambda x: x)

    for item in iterable:
        k = key_func(item)
        if k not in seen:
            seen.add(k)
            yield item


def unique_by_hash(
    iterable: Iterable[T],
    key: Callable[[T | None, Any]] = None,
) -> Generator[T, None, None]:
    """
    Yield unique items using hash set (more memory-efficient for large keys).

    Uses hash of key instead of full key value.
    WARNING: Hash collisions possible for extremely large sets.

    Memory usage: O(n) integers vs O(n) * key_size

    Args:
        iterable: Source iterable
        key: Optional function to extract comparison key

    Yields:
        Unique items (first occurrence of each)
    """
    seen_hashes: set[int] = set()
    key_func = key or (lambda x: x)

    for item in iterable:
        h = hash(key_func(item))
        if h not in seen_hashes:
            seen_hashes.add(h)
            yield item


def limited_iterator(
    iterable: Iterable[T],
    limit: int,
) -> Generator[T, None, None]:
    """
    Yield at most 'limit' items from iterable.

    Memory-efficient alternative to list(iterable)[:limit].

    Args:
        iterable: Source iterable
        limit: Maximum items to yield

    Yields:
        Up to 'limit' items
    """
    count = 0
    for item in iterable:
        if count >= limit:
            return
        yield item
        count += 1


def windowed_iterator(
    iterable: Iterable[T],
    window_size: int = 3,
) -> Generator[tuple[T, ...], None, None]:
    """
    Yield sliding windows over iterable.

    Memory: O(window_size) instead of O(n).

    Args:
        iterable: Source iterable
        window_size: Size of each window

    Yields:
        Tuples of window_size consecutive items

    Example:
        >>> items = [1, 2, 3, 4, 5]
        >>> list(windowed_iterator(items, 3))
        [(1, 2, 3), (2, 3, 4), (3, 4, 5)]
    """
    from collections import deque

    window: deque[T] = deque(maxlen=window_size)
    iterator = iter(iterable)

    # Fill initial window
    for item in iterator:
        window.append(item)
        if len(window) == window_size:
            break

    if len(window) == window_size:
        yield tuple(window)

        # Slide window
        for item in iterator:
            window.append(item)
            yield tuple(window)


def pairwise_iterator(iterable: Iterable[T]) -> Generator[tuple[T, T], None, None]:
    """
    Yield consecutive pairs from iterable.

    Args:
        iterable: Source iterable

    Yields:
        Tuples of consecutive items (a, b), (b, c), (c, d), ...

    Example:
        >>> list(pairwise_iterator([1, 2, 3, 4]))
        [(1, 2), (2, 3), (3, 4)]
    """
    iterator = iter(iterable)
    try:
        prev = next(iterator)
    except StopIteration:
        return

    for current in iterator:
        yield prev, current
        prev = current


def take_while_iterator(
    iterable: Iterable[T],
    predicate: Callable[[T], bool],
) -> Generator[T, None, None]:
    """
    Yield items while predicate is True.

    Args:
        iterable: Source iterable
        predicate: Condition function

    Yields:
        Items until predicate returns False
    """
    for item in iterable:
        if not predicate(item):
            return
        yield item


def drop_while_iterator(
    iterable: Iterable[T],
    predicate: Callable[[T], bool],
) -> Generator[T, None, None]:
    """
    Skip items while predicate is True, then yield all remaining.

    Args:
        iterable: Source iterable
        predicate: Condition function

    Yields:
        Items after predicate first returns False
    """
    iterator = iter(iterable)
    dropped = False

    for item in iterator:
        if not dropped and predicate(item):
            continue
        dropped = True
        yield item


def flatten_iterator(
    nested: Iterable[Iterable[T]],
) -> Generator[T, None, None]:
    """
    Flatten one level of nesting.

    Args:
        nested: Iterable of iterables

    Yields:
        Individual items from all sub-iterables

    Example:
        >>> nested = [[1, 2], [3, 4], [5]]
        >>> list(flatten_iterator(nested))
        [1, 2, 3, 4, 5]
    """
    for sub in nested:
        for item in sub:
            yield item


def interleave_iterators(*iterables: Iterable[T]) -> Generator[T, None, None]:
    """
    Interleave items from multiple iterables.

    Stops when shortest iterable is exhausted.

    Args:
        *iterables: Multiple iterables to interleave

    Yields:
        Items in round-robin order

    Example:
        >>> list(interleave_iterators([1, 2, 3], ['a', 'b', 'c']))
        [1, 'a', 2, 'b', 3, 'c']
    """
    iterators = [iter(it) for it in iterables]
    while iterators:
        for i, it in enumerate(iterators):
            try:
                yield next(it)
            except StopIteration:
                return


def groupby_key_iterator(
    iterable: Iterable[T],
    key: Callable[[T], Any],
) -> Generator[tuple[Any, list[T]], None, None]:
    """
    Group consecutive items by key.

    Unlike itertools.groupby, yields (key, list) instead of (key, iterator).
    Memory: O(group_size) per group instead of O(n) total.

    Args:
        iterable: Source iterable (should be sorted by key for expected behavior)
        key: Function to extract grouping key

    Yields:
        Tuples of (key_value, list_of_items)
    """
    iterator = iter(iterable)
    try:
        first = next(iterator)
    except StopIteration:
        return

    current_key = key(first)
    current_group: list[T] = [first]

    for item in iterator:
        item_key = key(item)
        if item_key == current_key:
            current_group.append(item)
        else:
            yield current_key, current_group
            current_key = item_key
            current_group = [item]

    yield current_key, current_group


# Async generators for async contexts

async def async_chunked_iterator(
    async_iterable: Any,  # AsyncIterable[T]
    chunk_size: int = 100,
) -> Any:  # AsyncGenerator[list[T], None]
    """
    Async version of chunked_iterator.

    Args:
        async_iterable: Async source iterable
        chunk_size: Maximum size of each chunk

    Yields:
        Lists of up to chunk_size elements
    """
    chunk: list[Any] = []
    async for item in async_iterable:
        chunk.append(item)
        if len(chunk) >= chunk_size:
            yield chunk
            chunk = []
    if chunk:
        yield chunk


__all__ = [
    'chunked_iterator',
    'streaming_filter',
    'lazy_map',
    'batched_processor',
    'unique_iterator',
    'unique_by_hash',
    'limited_iterator',
    'windowed_iterator',
    'pairwise_iterator',
    'take_while_iterator',
    'drop_while_iterator',
    'flatten_iterator',
    'interleave_iterators',
    'groupby_key_iterator',
    'async_chunked_iterator',
]
