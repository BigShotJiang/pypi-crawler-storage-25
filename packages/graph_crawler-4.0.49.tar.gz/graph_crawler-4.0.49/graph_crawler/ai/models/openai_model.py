"""OpenAI LLM — GPT-4o, GPT-4o-mini, GPT-4-turbo."""
from __future__ import annotations

import os
from typing import TypeVar

from pydantic import BaseModel

import graph_crawler.shared.utils.fast_json as json
from graph_crawler.domain.interfaces import (
    LLMError,
    LLMRateLimitError,
    LLMTimeoutError,
)

T = TypeVar("T", bound=BaseModel)


class OpenAIModel:
    """OpenAI LLM wrapper. Default: gpt-4o-mini."""

    def __init__(
        self,
        api_key: str | None = None,
        model: str = "gpt-4o-mini",
        temperature: float = 0.7,
        max_tokens: int = 4096,
        timeout: float = 60.0,
    ):
        """
        Ініціалізує OpenAI модель.

        Args:
            api_key: API ключ OpenAI (або з OPENAI_API_KEY env)
            model: Назва моделі
            temperature: Температура генерації
            max_tokens: Максимальна кількість токенів
            timeout: Таймаут запиту в секундах
        """
        self._api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if not self._api_key:
            raise ValueError(
                "OpenAI API key is required. "
                "Pass api_key parameter or set OPENAI_API_KEY environment variable."
            )

        self._model = model
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._timeout = timeout
        self._client = None

    def _get_client(self):
        """Lazy ініціалізація клієнта."""
        if self._client is None:
            try:
                from openai import AsyncOpenAI

                self._client = AsyncOpenAI(
                    api_key=self._api_key,
                    timeout=self._timeout,
                )
            except ImportError:
                raise LLMError(
                    "openai package is not installed. Install with: pip install openai",
                    model=self.model_name,
                )
        return self._client

    @property
    def model_name(self) -> str:
        """Унікальний ідентифікатор моделі."""
        return f"openai:{self._model}"

    async def complete(self, prompt: str) -> str:
        """
        Текстове завершення.

        Args:
            prompt: Текст запиту

        Returns:
            Відповідь моделі

        Raises:
            LLMError: При помилці API
            LLMRateLimitError: При rate limiting
            LLMTimeoutError: При таймауті
        """
        client = self._get_client()

        try:
            response = await client.chat.completions.create(
                model=self._model,
                messages=[{"role": "user", "content": prompt}],
                temperature=self._temperature,
                max_tokens=self._max_tokens,
            )
            return response.choices[0].message.content or ""

        except Exception as e:
            error_str = str(e).lower()

            if "rate_limit" in error_str or "rate limit" in error_str:
                raise LLMRateLimitError(f"OpenAI rate limit exceeded: {e}", model=self.model_name)
            elif "timeout" in error_str:
                raise LLMTimeoutError(
                    f"OpenAI request timed out: {e}", model=self.model_name, timeout=self._timeout
                )
            else:
                raise LLMError(f"OpenAI API error: {e}", model=self.model_name)

    async def complete_structured(
        self,
        prompt: str,
        output_schema: type[T],
    ) -> T:
        """
        Структуроване завершення з валідацією через Pydantic.

        Використовує function calling для отримання структурованої відповіді.

        Args:
            prompt: Текст запиту
            output_schema: Pydantic модель для валідації

        Returns:
            Об'єкт вказаного типу

        Raises:
            LLMError: При помилці API
            ValidationError: Якщо відповідь не відповідає схемі
        """
        client = self._get_client()

        # Генеруємо JSON schema з Pydantic моделі
        schema = output_schema.model_json_schema()

        # Видаляємо непідтримувані поля
        if "title" in schema:
            del schema["title"]
        if "$defs" in schema:
            del schema["$defs"]

        function_def = {
            "name": "extract_data",
            "description": f"Extract data according to {output_schema.__name__} schema",
            "parameters": schema,
        }

        try:
            response = await client.chat.completions.create(
                model=self._model,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "You are a data extraction assistant. "
                            "Extract the requested information and return it in the specified format. "
                            "Only include fields that you can confidently extract from the content."
                        ),
                    },
                    {"role": "user", "content": prompt},
                ],
                functions=[function_def],  # type: ignore[arg-type]
                function_call={"name": "extract_data"},
                temperature=0.1,  # Низька температура для точності
                max_tokens=self._max_tokens,
            )

            # Парсимо function call response
            function_call = response.choices[0].message.function_call
            if function_call and function_call.arguments:
                data = json.loads(function_call.arguments)

                # P1 FIX: Нормалізація відповіді LLM
                data = self._normalize_llm_response(data, output_schema)

                return output_schema.model_validate(data)
            else:
                raise LLMError("No function call in response", model=self.model_name)

        except json.JSONDecodeError as e:
            raise LLMError(f"Failed to parse JSON response: {e}", model=self.model_name)
        except Exception as e:
            if "ValidationError" in type(e).__name__:
                raise  # Re-raise Pydantic validation errors

            error_str = str(e).lower()
            if "rate_limit" in error_str or "rate limit" in error_str:
                raise LLMRateLimitError(f"OpenAI rate limit exceeded: {e}", model=self.model_name)
            elif "timeout" in error_str:
                raise LLMTimeoutError(
                    f"OpenAI request timed out: {e}", model=self.model_name, timeout=self._timeout
                )
            else:
                raise LLMError(f"OpenAI API error: {e}", model=self.model_name)

    def _normalize_llm_response(self, data: dict, schema: type[T]) -> dict:
        """
        P1 FIX: Нормалізація відповіді LLM до схеми Pydantic.
        
        Вирішує проблеми:
        1. None замість [] для list полів
        2. None замість 0 для int полів з default
        3. LLM використовує інші назви полів (quote -> text, item -> name)
        """
        if not isinstance(data, dict):
            return data

        # Словник можливих альтернативних назв полів
        field_aliases = {
            "text": ["quote", "content", "message", "body"],
            "name": ["title", "item", "product_name", "item_name"],
            "price": ["cost", "amount", "value"],
            "description": ["desc", "info", "details", "summary"],
        }

        for field_name, field_info in schema.model_fields.items():
            annotation = field_info.annotation
            origin = getattr(annotation, "__origin__", None)

            # Якщо поле відсутнє - шукаємо альтернативи
            if field_name not in data or data.get(field_name) is None:
                # Перевіряємо альтернативні назви
                if field_name in field_aliases:
                    for alias in field_aliases[field_name]:
                        if alias in data and data[alias] is not None:
                            data[field_name] = data.pop(alias)
                            break

            # Конвертуємо None в дефолтні значення
            if data.get(field_name) is None:
                if origin is list:
                    data[field_name] = []
                elif annotation is int:
                    if field_info.default is not None:
                        data[field_name] = field_info.default
                    else:
                        data[field_name] = 0

            # Рекурсивно обробляємо вкладені списки об'єктів
            if origin is list and field_name in data:
                args = getattr(annotation, "__args__", ())
                if args and hasattr(args[0], "model_fields"):
                    nested_schema = args[0]
                    data[field_name] = [
                        self._normalize_llm_response(item, nested_schema)
                        if isinstance(item, dict) else item
                        for item in data[field_name]
                    ]

        return data

    def __repr__(self) -> str:
        return f"OpenAIModel(model={self._model}, temperature={self._temperature})"
