"""AIExtractionPlugin - плагін для AI-based extraction даних.

Використовує LLM для витягування структурованих даних з HTML сторінок.

P1-7: Consolidated LLM calls - об'єднано extraction + link suggestion в один виклик.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Type
from urllib.parse import urljoin, urlparse

from pydantic import BaseModel, Field, create_model

from graph_crawler.domain.interfaces import ILanguageModel, LLMError
from graph_crawler.extensions.plugins.node.base import (
    BaseNodePlugin,
    NodePluginContext,
    NodePluginType,
)
from graph_crawler.shared.utils.markdown.generator import MarkdownGenerator
from graph_crawler.shared.utils.markdown.options import MarkdownOptions
from graph_crawler.shared.utils.markdown.result import MarkdownResult

logger = logging.getLogger(__name__)


class ExtractedLinks(BaseModel):
    """Структура для посилань зі сторінки."""

    relevant_links: list[str] = Field(
        default_factory=list, description="Посилання які варто відвідати для задачі"
    )
    reasoning: str = Field(default="", description="Чому ці посилання релевантні")


class LinkSuggestionFields(BaseModel):
    """Поля для link suggestion (P1-7: об'єднаний виклик)."""

    suggested_link_indices: list[int] = Field(
        default_factory=list,
        description="Indices (1-based) of most relevant links to visit next, max 5"
    )
    link_reasoning: str = Field(
        default="",
        description="Brief explanation why these links are relevant"
    )


class AIExtractionPlugin(BaseNodePlugin):
    """
    Плагін для AI-based extraction даних з HTML сторінок.

    Ключові особливості:
    - Використовує MarkdownGenerator для конвертації HTML -> Markdown
    - Фільтрує вже відвідані посилання
    - Пропонує LLM релевантні посилання для наступних кроків
    - Автоматично агрегує результати в CrawlContext
    - P1-7: Consolidated LLM calls - extraction + link suggestion в одному запиті

    Attributes:
        model: Реалізація ILanguageModel
        task: Завдання природною мовою
        output_schema: Pydantic схема для результату
        max_content_length: Максимальна довжина контенту для LLM
        suggest_links: Чи пропонувати посилання для відвідування
    """

    def __init__(
        self,
        model: ILanguageModel,
        task: str,
        output_schema: Type[BaseModel | None] = None,
        max_content_length: int = 12000,
        suggest_links: bool = True,
        markdown_options: MarkdownOptions | None = None,
        config: dict[str, Any | None] = None,
    ):
        """
        Ініціалізує AIExtractionPlugin.

        Args:
            model: LLM провайдер (OpenAIModel, AnthropicModel, etc.)
            task: Завдання природною мовою
            output_schema: Pydantic модель для валідації результату
            max_content_length: Максимальна кількість символів для LLM
            suggest_links: Пропонувати посилання для відвідування
            markdown_options: Налаштування MarkdownGenerator
            config: Додаткова конфігурація плагіна
        """
        super().__init__(config or {})
        self.model = model
        self.task = task
        self.output_schema = output_schema
        self.max_content_length = max_content_length
        self.suggest_links = suggest_links

        # Налаштування Markdown генератора
        self._md_options = markdown_options or MarkdownOptions(
            include_links=True,
            include_images=False,  # Зменшуємо розмір
            include_tables=True,
            include_lists=True,
            include_code_blocks=True,
            remove_nav=True,
            remove_header=True,
            remove_footer=True,
            remove_aside=False,  # Sidebar може містити важливу інфо
            remove_ads=True,
            generate_citations=False,  # Не потрібно для extraction
            normalize_whitespace=True,
        )
        self._md_generator = MarkdownGenerator(self._md_options)

        # P1-7: Кешована комбінована схема
        self._combined_schema_cache: Type[BaseModel] | None = None

    @property
    def plugin_type(self) -> NodePluginType:
        """Тип плагіну - виконується після парсингу HTML."""
        return NodePluginType.ON_HTML_PARSED

    @property
    def name(self) -> str:
        """Назва плагіну."""
        return "AIExtractionPlugin"

    def _create_combined_schema(
        self,
        base_schema: Type[BaseModel],
        include_links: bool
    ) -> Type[BaseModel]:
        """
        P1-7: Створює комбіновану схему для extraction + link suggestion.
        
        Args:
            base_schema: Основна схема для extraction
            include_links: Чи додавати поля для link suggestion
            
        Returns:
            Комбінована Pydantic модель
        """
        if not include_links:
            return base_schema

        # Якщо схема вже закешована - повертаємо її
        if self._combined_schema_cache is not None:
            return self._combined_schema_cache

        # Збираємо поля з base_schema
        fields: dict[str, Any] = {}
        for field_name, field_info in base_schema.model_fields.items():
            fields[field_name] = (field_info.annotation, field_info)

        # Додаємо поля для link suggestion
        fields["suggested_link_indices"] = (
            list[int],
            Field(
                default_factory=list,
                description="Indices (1-based) of most relevant links to visit next, max 5"
            )
        )
        fields["link_reasoning"] = (
            str,
            Field(
                default="",
                description="Brief explanation why these links are relevant"
            )
        )

        # Створюємо нову модель
        combined_name = f"{base_schema.__name__}WithLinks"
        self._combined_schema_cache = create_model(combined_name, **fields)  # type: ignore

        return self._combined_schema_cache

    async def execute(self, context: NodePluginContext) -> NodePluginContext:
        """
        Виконує AI extraction на HTML контенті.
        
        P1-7: Об'єднаний виклик - extraction + link suggestion в одному LLM запиті.

        Args:
            context: Контекст з HTML та метаданими

        Returns:
            Оновлений контекст з витягнутими даними
        """
        if not context.html:
            logger.debug("No HTML content for %s, skipping extraction", context.url)
            return context

        # 1. Конвертуємо HTML в Markdown
        md_result = self._md_generator.generate_from_html(context.html)

        if not md_result or not md_result.fit_markdown:
            logger.debug("Empty markdown for %s", context.url)
            return context

        # 2. Отримуємо відвідані URL для фільтрації
        visited_urls = self._get_visited_urls(context)

        # 3. Збираємо посилання зі сторінки
        page_links = self._extract_links_from_html(context.html, context.url)

        # 4. Фільтруємо вже відвідані
        unvisited_links = [url for url in page_links if url not in visited_urls]

        # 5. Визначаємо чи потрібні link suggestions
        need_link_suggestions = (
            self.suggest_links
            and unvisited_links
            and not (context.crawl_context and context.crawl_context.result_complete)
        )

        # 6. Формуємо контент для LLM з глобальним контекстом
        links_for_prompt = unvisited_links[:20] if need_link_suggestions else []
        content = self._prepare_content_for_llm(
            md_result=md_result,
            url=context.url,
            available_links=links_for_prompt,
            crawl_context=context.crawl_context,
        )

        # 7. Формуємо промпт
        prompt = self._build_combined_prompt(
            url=context.url,
            content=content,
            available_links=links_for_prompt,
            crawl_context=context.crawl_context,
            include_link_suggestion=need_link_suggestions,
        )

        try:
            # 8. P1-7: ОДИН виклик LLM для extraction + link suggestion
            if self.output_schema:
                # Створюємо комбіновану схему якщо потрібні link suggestions
                schema_to_use = self._create_combined_schema(
                    self.output_schema,
                    include_links=need_link_suggestions
                )

                extracted = await self.model.complete_structured(prompt, schema_to_use)
                full_data = extracted.model_dump(exclude_none=True)

                # Розділяємо extraction data та link suggestions
                suggested_indices = full_data.pop("suggested_link_indices", [])
                link_reasoning = full_data.pop("link_reasoning", "")
                data = full_data
            else:
                text_result = await self.model.complete(prompt)
                data = {"text_result": text_result}
                suggested_indices = []
                link_reasoning = ""

            # 9. Фільтруємо порожні значення
            data = {k: v for k, v in data.items() if v is not None and v != ""}

            if data:
                # Зберігаємо в глобальний контекст
                context.add_extracted_to_context(data)

                # Зберігаємо в user_data для локального доступу
                context.user_data["ai_extracted"] = data
                context.user_data["ai_model"] = self.model.model_name
                context.user_data["ai_content_type"] = "markdown"

                logger.info(
                    f"AI extracted {len(data)} fields from {context.url} "
                    f"using {self.model.model_name}"
                )

                # Phase 1: Агрегуємо результати в crawl_context.results
                if context.crawl_context:
                    # Додаємо в список results якщо є output_schema
                    if self.output_schema:
                        try:
                            result_item = self.output_schema.model_validate(data)
                            results = context.crawl_context.get("results", [])
                            results.append(result_item)
                            context.crawl_context.set("results", results)
                            logger.debug("Added result to context.results, total: %s", len(results))
                        except Exception as e:
                            logger.debug("Could not add to results list: %s", e)
                    if context.crawl_context.result_complete:
                        context.crawl_context.target_found = True
                        context.request_stop("All required data found by AI extraction")
                        logger.info("Result complete, requesting stop")
            else:
                logger.debug("No data extracted from %s", context.url)

            # 10. P1-7: Обробляємо link suggestions з того ж запиту
            if need_link_suggestions and suggested_indices:
                self._process_link_suggestions(
                    context=context,
                    suggested_indices=suggested_indices,
                    available_links=links_for_prompt,
                    reasoning=link_reasoning,
                )

        except LLMError as e:
            logger.error("LLM error for %s: %s", context.url, e)
            if context.crawl_context:
                context.crawl_context.add_error(
                    f"LLM extraction failed: {e}", url=context.url, model=self.model.model_name
                )
        except Exception as e:
            logger.error("Extraction error for %s: %s", context.url, e, exc_info=True)
            if context.crawl_context:
                context.crawl_context.add_error(f"Extraction error: {e}", url=context.url)

        return context

    def _process_link_suggestions(
        self,
        context: NodePluginContext,
        suggested_indices: list[int],
        available_links: list[str],
        reasoning: str = "",
    ) -> None:
        """
        P1-7: Обробляє link suggestions з об'єднаного LLM запиту.
        
        Args:
            context: NodePluginContext
            suggested_indices: Індекси посилань (1-based)
            available_links: Список доступних посилань
            reasoning: Пояснення вибору
        """
        suggested_links = []
        for idx in suggested_indices[:5]:  # Максимум 5
            # Індекси 1-based
            array_idx = idx - 1
            if 0 <= array_idx < len(available_links):
                suggested_links.append(available_links[array_idx])

        if suggested_links:
            context.user_data["ai_suggested_links"] = suggested_links
            if reasoning:
                context.user_data["ai_link_reasoning"] = reasoning
            logger.info("AI suggested %s links to visit", len(suggested_links))

            # Підвищуємо пріоритет цих посилань
            for link in suggested_links:
                context.reprioritize_url(link, new_priority=8)

    def _get_visited_urls(self, context: NodePluginContext) -> set[str]:
        """
        Отримує множину вже відвіданих URL.

        Args:
            context: NodePluginContext

        Returns:
            Set відвіданих URL
        """
        visited = set()

        if context.crawl_context:
            # З navigation_history
            history = context.crawl_context.navigation_history
            if history:
                visited.update(history)

            # Поточний URL також "відвіданий"
            visited.add(context.url)

        return visited

    def _extract_links_from_html(self, html: str, base_url: str) -> list[str]:
        """
        Витягує посилання з HTML.

        Args:
            html: HTML контент
            base_url: Базовий URL для відносних посилань

        Returns:
            Список абсолютних URL
        """
        try:
            from bs4 import BeautifulSoup  # type: ignore[import-not-found]

            soup = BeautifulSoup(html, "lxml")
        except Exception:
            return []  # bs4/lxml not available or parse failed

        links = []
        base_domain = urlparse(base_url).netloc

        for a in soup.find_all("a", href=True):
            href_val = a.get("href", "")
            # href може бути списком, беремо перший елемент
            href = href_val[0] if isinstance(href_val, list) else href_val
            href = str(href).strip() if href else ""

            if not href or href.startswith("#") or href.startswith("javascript:"):
                continue

            # Конвертуємо в абсолютний URL
            absolute_url = urljoin(base_url, href)

            # Фільтруємо зовнішні домени (опціонально)
            parsed = urlparse(absolute_url)
            if parsed.netloc == base_domain:
                # Нормалізуємо URL (без фрагментів)
                clean_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
                if parsed.query:
                    clean_url += f"?{parsed.query}"

                if clean_url not in links:
                    links.append(clean_url)

        return links

    def _prepare_content_for_llm(
        self,
        md_result: MarkdownResult,
        url: str,
        available_links: list[str],
        crawl_context: Any | None = None,
    ) -> str:
        """
        Готує контент для відправки в LLM.

        Args:
            md_result: Результат MarkdownGenerator
            url: Поточний URL
            available_links: Доступні посилання
            crawl_context: Глобальний контекст краулінгу

        Returns:
            Форматований контент
        """
        content_parts = []
        # Це дозволяє LLM розуміти "де він знаходиться" в контексті всього краулінгу
        if crawl_context:
            content_parts.append("## Crawl Context (Global State)")

            # Історія навігації - де вже були
            nav_history = crawl_context.navigation_history
            if nav_history:
                content_parts.append(f"**Pages visited ({len(nav_history)}):**")
                # Показуємо останні 10 сторінок
                recent_pages = nav_history[-10:] if len(nav_history) > 10 else nav_history
                for page_url in recent_pages:
                    content_parts.append(f"  - {page_url}")
                if len(nav_history) > 10:
                    content_parts.append(f"  ... and {len(nav_history) - 10} more")

            # Вже зібрані дані - що ми вже знайшли
            extracted = crawl_context.extracted_data
            if extracted:
                content_parts.append("\n**Already extracted data:**")
                for key, value in extracted.items():
                    if value:
                        # Обмежуємо довжину значення
                        str_value = str(value)
                        if len(str_value) > 100:
                            str_value = str_value[:100] + "..."
                        content_parts.append(f"  - {key}: {str_value}")

            # Прогрес виконання задачі
            if crawl_context.result_schema:
                completeness = crawl_context.result_completeness
                missing = crawl_context.get_missing_fields()
                content_parts.append(f"\n**Task progress:** {completeness:.0%} complete")
                if missing:
                    content_parts.append(f"**Still looking for:** {', '.join(missing)}")

            content_parts.append("")  # Пустий рядок
        content_parts.append("## Current Page")
        if md_result.title:
            content_parts.append(f"**Page Title:** {md_result.title}")
        if md_result.h1 and md_result.h1 != md_result.title:
            content_parts.append(f"**Main Heading:** {md_result.h1}")
        if md_result.description:
            content_parts.append(f"**Description:** {md_result.description}")

        content_parts.append("")  # Пустій рядок
        markdown = md_result.fit_markdown

        # Обрізаємо якщо занадто довгий
        if len(markdown) > self.max_content_length:
            markdown = markdown[: self.max_content_length] + "\n\n... [content truncated]"

        content_parts.append("## Page Content")
        content_parts.append(markdown)
        if available_links:
            content_parts.append("")
            content_parts.append("## Available Links (not yet visited)")
            for i, link in enumerate(available_links[:30], 1):  # Максимум 30 посилань
                content_parts.append(f"{i}. {link}")

        return "\n".join(content_parts)

    def _build_combined_prompt(
        self,
        url: str,
        content: str,
        available_links: list[str],
        crawl_context: Any | None = None,
        include_link_suggestion: bool = False,
    ) -> str:
        """
        P1-7: Створює об'єднаний промпт для extraction + link suggestion.

        Args:
            url: URL сторінки
            content: Підготовлений контент
            available_links: Доступні посилання
            crawl_context: Глобальний контекст краулінгу
            include_link_suggestion: Чи включати запит на link suggestions

        Returns:
            Сформований промпт
        """
        prompt_parts = [f"**Task:** {self.task}", "", f"**Current URL:** {url}"]

        if self.output_schema:
            fields = []
            for name, field in self.output_schema.model_fields.items():
                required = "required" if field.is_required() else "optional"
                field_type = str(field.annotation).replace("typing.", "")
                fields.append(f"  - {name} ({field_type}, {required})")
            prompt_parts.append("")
            prompt_parts.append("**Expected fields to extract:**")
            prompt_parts.extend(fields)

        # Додаємо контекст про прогрес задачі
        if crawl_context:
            missing = crawl_context.get_missing_fields()
            if missing:
                prompt_parts.append("")
                prompt_parts.append(f"**Priority:** Focus on finding these missing fields: {', '.join(missing)}")
            elif crawl_context.result_complete:
                prompt_parts.append("")
                prompt_parts.append(
                    "**Status:** All required data has been found. "
                    "Only extract if you find better/more complete information."
                )

        # P1-7: Додаємо інструкції для link suggestion в той самий промпт
        if include_link_suggestion and available_links:
            prompt_parts.append("")
            prompt_parts.append("**Link Selection Task:**")
            prompt_parts.append(
                "Additionally, select up to 5 most relevant links from the 'Available Links' "
                "section that are most likely to contain information needed for the task. "
                "Return their numbers (1-based indices) in the `suggested_link_indices` field. "
                "Briefly explain your selection in `link_reasoning`."
            )

        prompt_parts.append("")
        prompt_parts.append("---")
        prompt_parts.append(content)
        prompt_parts.append("---")
        prompt_parts.append("")
        prompt_parts.append("Extract the requested data from the page content above. Return only the structured data.")

        return "\n".join(prompt_parts)

    # Deprecated method kept for backward compatibility
    async def _suggest_relevant_links(
        self,
        context: NodePluginContext,
        available_links: list[str],
        md_result: MarkdownResult,
    ) -> None:
        """
        DEPRECATED: Link suggestions are now part of the combined LLM call (P1-7).
        
        This method is kept for backward compatibility but is no longer called.
        Use the combined extraction instead.
        """
        logger.warning(
            "_suggest_relevant_links is deprecated. "
            "Link suggestions are now part of the combined LLM call (P1-7)."
        )
        # Fallback implementation for edge cases
        if not available_links:
            return

        links_to_analyze = available_links[:20]

        prompt = f"""**Task context:** {self.task}

**Current page:** {context.url}
**Page title:** {md_result.title or "Unknown"}

**Available links to visit (not yet crawled):**
{chr(10).join(f"{i + 1}. {link}" for i, link in enumerate(links_to_analyze))}

**Question:** Which of these links are most likely to contain relevant information for the task?

Select up to 5 most relevant links. Return ONLY the numbers (e.g., "1, 3, 7") or "none" if no links seem relevant.
Consider URL structure and likely page content based on the URL path."""

        try:
            response = await self.model.complete(prompt)
            response = response.strip().lower()

            if response == "none" or not response:
                return

            numbers = re.findall(r"\d+", response)

            suggested_links = []
            for num_str in numbers[:5]:
                idx = int(num_str) - 1
                if 0 <= idx < len(links_to_analyze):
                    suggested_links.append(links_to_analyze[idx])

            if suggested_links:
                context.user_data["ai_suggested_links"] = suggested_links
                logger.info("AI suggested %s links to visit (legacy method)", len(suggested_links))

                for link in suggested_links:
                    context.reprioritize_url(link, new_priority=8)

        except Exception as e:
            logger.debug("Failed to get link suggestions: %s", e)

    def __repr__(self) -> str:
        return (
            f"AIExtractionPlugin("
            f"model={self.model.model_name}, "
            f"task='{self.task[:50]}...', "
            f"schema={self.output_schema.__name__ if self.output_schema else None}, "
            f"suggest_links={self.suggest_links})"
        )
