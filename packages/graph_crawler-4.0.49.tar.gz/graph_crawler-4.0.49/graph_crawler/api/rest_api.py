"""
REST API for Remote Control Використовує новий Sync-First Simple API.

ОНОВЛЕНО 2026: Додано Streaming JSON Lines для прогресу краулінгу (FastAPI 0.135+).
ОНОВЛЕНО Квітень 2026: P1-9 Redis state store для _crawler_state.

Features:
- Start/stop/pause/resume crawling
- Query package_crawler status
- Manage crawl configurations
- Export results
- **NEW**: Streaming progress updates via JSON Lines
- **NEW**: Redis/Memory state store abstraction (P1-9)
"""
from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime, timezone
from typing import Any, AsyncGenerator, Protocol

from fastapi import APIRouter, BackgroundTasks, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field, field_validator

# ОНОВЛЕНО 2026: orjson через fast_json wrapper
from graph_crawler.shared.utils.fast_json import dumps as json_dumps
from graph_crawler.shared.utils.fast_json import loads as json_loads

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1", tags=["package_crawler"])


# ============================================================================
# P1-9: State Store Abstraction
# ============================================================================


class ICrawlerStateStore(Protocol):
    """Protocol для state store (P1-9)."""

    async def get(self, key: str) -> Any:
        """Отримати значення за ключем."""
        ...

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        """Встановити значення."""
        ...

    async def delete(self, key: str) -> None:
        """Видалити ключ."""
        ...

    async def get_all(self) -> dict[str, Any]:
        """Отримати весь state."""
        ...

    async def clear(self) -> None:
        """Очистити весь state."""
        ...


class MemoryStateStore:
    """
    In-memory state store для development (P1-9).

    Thread-safe через asyncio lock.
    """

    def __init__(self) -> None:
        self._data: dict[str, Any] = {
            "status": "idle",
            "crawl_id": None,
            "crawler_instance": None,
            "config": None,
            "result_graph": None,
        }
        self._lock = asyncio.Lock()

    async def get(self, key: str) -> Any:
        async with self._lock:
            return self._data.get(key)

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        async with self._lock:
            self._data[key] = value

    async def delete(self, key: str) -> None:
        async with self._lock:
            self._data.pop(key, None)

    async def get_all(self) -> dict[str, Any]:
        async with self._lock:
            return dict(self._data)

    async def clear(self) -> None:
        async with self._lock:
            self._data = {
                "status": "idle",
                "crawl_id": None,
                "crawler_instance": None,
                "config": None,
                "result_graph": None,
            }


class RedisStateStore:
    """
    Redis state store для production (P1-9).

    Використовує redis.asyncio для async операцій.
    """

    def __init__(self, redis_url: str, prefix: str = "crawler:state:") -> None:
        """
        Ініціалізує Redis store.

        Args:
            redis_url: Redis connection URL (e.g., redis://localhost:6379/0)
            prefix: Prefix для ключів
        """
        try:
            import redis.asyncio as redis_async
            self._redis = redis_async.from_url(redis_url, decode_responses=True)
        except ImportError:
            raise ImportError(
                "redis package is required for RedisStateStore. "
                "Install it with: pip install redis"
            )
        self._prefix = prefix
        self._ttl_default = 3600  # 1 hour default TTL

    def _key(self, key: str) -> str:
        """Формує повний ключ з prefix."""
        return f"{self._prefix}{key}"

    async def get(self, key: str) -> Any:
        data = await self._redis.get(self._key(key))
        if data:
            try:
                return json_loads(data)
            except Exception:
                return data
        return None

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        # Не серіалізуємо crawler_instance (не можна зберігти в Redis)
        if key == "crawler_instance":
            return

        try:
            serialized = json_dumps(value)
        except (TypeError, ValueError):
            serialized = str(value)

        if ttl:
            await self._redis.setex(self._key(key), ttl, serialized)
        else:
            await self._redis.setex(self._key(key), self._ttl_default, serialized)

    async def delete(self, key: str) -> None:
        await self._redis.delete(self._key(key))

    async def get_all(self) -> dict[str, Any]:
        result = {}
        cursor = 0
        pattern = f"{self._prefix}*"

        while True:
            cursor, keys = await self._redis.scan(cursor, match=pattern, count=100)
            for full_key in keys:
                key = full_key.replace(self._prefix, "", 1)
                result[key] = await self.get(key)
            if cursor == 0:
                break

        return result

    async def clear(self) -> None:
        cursor = 0
        pattern = f"{self._prefix}*"

        while True:
            cursor, keys = await self._redis.scan(cursor, match=pattern, count=100)
            if keys:
                await self._redis.delete(*keys)
            if cursor == 0:
                break


def get_state_store() -> ICrawlerStateStore:
    """
    Factory для state store (P1-9).

    Вибирає Redis якщо REDIS_URL встановлено, інакше Memory.

    Returns:
        ICrawlerStateStore implementation
    """
    redis_url = os.environ.get("REDIS_URL")
    if redis_url:
        logger.info("Using RedisStateStore with URL: %s", redis_url.split("@")[-1])
        return RedisStateStore(redis_url)
    logger.info("Using MemoryStateStore (set REDIS_URL for production)")
    return MemoryStateStore()


# Global state store instance (P1-9)
_state_store: ICrawlerStateStore = get_state_store()

# Pydantic models для request/response
class CrawlRequest(BaseModel):
    """Request model для запуску краулінгу."""

    url: str = Field(..., description="Start URL для краулінгу")
    max_depth: int = Field(3, ge=1, le=10, description="Максимальна глибина краулінгу")
    max_pages: int = Field(100, ge=1, le=100000, description="Максимальна кількість сторінок")
    allowed_domains: list[str] = Field(
        default=["domain+subdomains"],
        description="Дозволені домени: '*', 'domain', 'subdomains', 'domain+subdomains'",
    )
    follow_robots_txt: bool = Field(True, description="Дотримуватись robots.txt")
    enable_rate_limiting: bool = Field(True, description="Увімкнути rate limiting")
    rate_limit_rps: float = Field(2.0, ge=0.1, le=100.0, description="Запитів на секунду")
    enable_proxy: bool = Field(False, description="Використовувати proxy rotation")
    enable_captcha_solver: bool = Field(False, description="Увімкнути CAPTCHA solving")

    @field_validator("url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        """Валідація URL."""
        if not v.startswith(("http://", "https://")):
            raise ValueError("URL must start with http:// or https://")
        return v

class CrawlResponse(BaseModel):
    """Response model для результатів краулінгу."""

    crawl_id: str
    status: str
    message: str
    stats: dict[str, Any | None] = None

class CrawlerStatus(BaseModel):
    """Status model для package_crawler state."""

    status: str  # idle, running, paused, stopped, error
    crawl_id: str | None = None
    start_time: str | None = None
    total_pages: int = 0
    queue_size: int = 0
    errors: int = 0
    pages_per_second: float = 0.0


# P1-9: Local cache for crawler_instance (cannot be stored in Redis)
_crawler_instance_cache: dict[str, Any] = {}


@router.post("/crawl/start", response_model=CrawlResponse)
async def start_crawl(request: CrawlRequest, background_tasks: BackgroundTasks):
    """
    Запустити новий краулінг.

    Args:
        request: Конфігурація краулінгу
        background_tasks: FastAPI background tasks

    Returns:
        CrawlResponse з crawl_id та статусом

    Raises:
        HTTPException: Якщо краулінг вже запущений
    """
    status = await _state_store.get("status")
    if status == "running":
        raise HTTPException(
            status_code=409,
            detail="Crawler is already running. Stop or wait for completion.",
        )

    # Генерувати crawl_id
    crawl_id = f"crawl_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    # Оновити state (P1-9)
    await _state_store.set("status", "running")
    await _state_store.set("crawl_id", crawl_id)
    await _state_store.set("config", request.model_dump())

    logger.info("Starting crawl %s for URL: %s", crawl_id, request.url)

    # Запустити краулінг у background (в production використовувати Celery)
    background_tasks.add_task(_run_crawl_background, crawl_id, request)

    return CrawlResponse(
        crawl_id=crawl_id,
        status="started",
        message=f"Crawl started successfully with ID: {crawl_id}",
        stats={
            "url": request.url,
            "max_depth": request.max_depth,
            "max_pages": request.max_pages,
        },
    )


@router.post("/crawl/{crawl_id}/pause")
async def pause_crawl(crawl_id: str):
    """
        Призупинити активний краулінг.

    Реалізовано pause logic через package_crawler.pause().

        Args:
            crawl_id: ID краулінгу

        Returns:
            Dict з підтвердженням

        Raises:
            HTTPException: Якщо краулінг не знайдено або не запущений
    """
    stored_crawl_id = await _state_store.get("crawl_id")
    if stored_crawl_id != crawl_id:
        raise HTTPException(status_code=404, detail="Crawl not found")

    status = await _state_store.get("status")
    if status != "running":
        raise HTTPException(
            status_code=400,
            detail=f"Cannot pause crawl in state: {status}",
        )

    # P1-9: Get crawler instance from local cache
    crawler = _crawler_instance_cache.get(crawl_id)
    if crawler and crawler.pause():
        await _state_store.set("status", "paused")
        logger.info("Crawl %s paused successfully", crawl_id)

        return {
            "crawl_id": crawl_id,
            "status": "paused",
            "message": "Crawl paused successfully",
        }
    else:
        raise HTTPException(status_code=500, detail="Failed to pause package_crawler")


@router.post("/crawl/{crawl_id}/resume")
async def resume_crawl(crawl_id: str):
    """
        Відновити призупинений краулінг.

    Реалізовано resume logic через package_crawler.resume().

        Args:
            crawl_id: ID краулінгу

        Returns:
            Dict з підтвердженням

        Raises:
            HTTPException: Якщо краулінг не призупинений
    """
    stored_crawl_id = await _state_store.get("crawl_id")
    if stored_crawl_id != crawl_id:
        raise HTTPException(status_code=404, detail="Crawl not found")

    status = await _state_store.get("status")
    if status != "paused":
        raise HTTPException(
            status_code=400,
            detail=f"Cannot resume crawl in state: {status}",
        )

    # P1-9: Get crawler instance from local cache
    crawler = _crawler_instance_cache.get(crawl_id)
    if crawler and crawler.resume():
        await _state_store.set("status", "running")
        logger.info("Crawl %s resumed successfully", crawl_id)

        return {
            "crawl_id": crawl_id,
            "status": "running",
            "message": "Crawl resumed successfully",
        }
    else:
        raise HTTPException(status_code=500, detail="Failed to resume package_crawler")


@router.post("/crawl/{crawl_id}/stop")
async def stop_crawl(crawl_id: str):
    """
        Зупинити активний краулінг.

    Реалізовано stop logic через package_crawler.stop().

        Args:
            crawl_id: ID краулінгу

        Returns:
            Dict з підтвердженням

        Raises:
            HTTPException: Якщо краулінг не знайдено
    """
    stored_crawl_id = await _state_store.get("crawl_id")
    if stored_crawl_id != crawl_id:
        raise HTTPException(status_code=404, detail="Crawl not found")

    previous_status = await _state_store.get("status")

    # P1-9: Get crawler instance from local cache
    crawler = _crawler_instance_cache.get(crawl_id)
    if crawler:
        crawler.stop()
        await _state_store.set("status", "stopped")
        # Cleanup local cache
        _crawler_instance_cache.pop(crawl_id, None)
        logger.info("Crawl %s stopped successfully", crawl_id)

        return {
            "crawl_id": crawl_id,
            "status": "stopped",
            "previous_status": previous_status,
            "message": "Crawl stopped successfully",
        }
    else:
        # Навіть якщо немає package_crawler instance, змінюємо стан
        await _state_store.set("status", "stopped")
        logger.warning("Crawl %s stopped (no active package_crawler)", crawl_id)

        return {
            "crawl_id": crawl_id,
            "status": "stopped",
            "previous_status": previous_status,
            "message": "Crawl stopped (no active package_crawler)",
        }


@router.get("/crawl/{crawl_id}/status", response_model=CrawlerStatus)
async def get_crawl_status(crawl_id: str):
    """
    Отримати статус краулінгу.

    Args:
        crawl_id: ID краулінгу

    Returns:
        CrawlerStatus з детальною інформацією

    Raises:
        HTTPException: Якщо краулінг не знайдено
    """
    stored_crawl_id = await _state_store.get("crawl_id")
    if stored_crawl_id != crawl_id:
        raise HTTPException(status_code=404, detail="Crawl not found")

    # Отримати статистику з monitor
    from graph_crawler.api.dashboard import monitor

    stats = monitor.get_current_stats()
    status = await _state_store.get("status")

    return CrawlerStatus(
        status=status or "unknown",
        crawl_id=crawl_id,
        start_time=stats.get("start_time"),
        total_pages=stats.get("total_pages", 0),
        queue_size=stats.get("queue_size", 0),
        errors=stats.get("errors", 0),
        pages_per_second=stats.get("pages_per_second", 0.0),
    )


@router.get("/crawl/list")
async def list_crawls(limit: int = Query(10, ge=1, le=100), offset: int = Query(0, ge=0)):
    """
    Список всіх краулінгів (history).

    Args:
        limit: Кількість записів
        offset: Offset для pagination
    Returns:
        List краулінгів
    """
    crawl_id = await _state_store.get("crawl_id")
    status = await _state_store.get("status")
    config = await _state_store.get("config")

    return {
        "total": 1 if crawl_id else 0,
        "limit": limit,
        "offset": offset,
        "crawls": (
            [
                {
                    "crawl_id": crawl_id,
                    "status": status,
                    "config": config,
                }
            ]
            if crawl_id
            else []
        ),
    }


async def _run_crawl_background(crawl_id: str, config: CrawlRequest):
    """
    Background task для запуску краулінгу. Використовує новий async_crawl API.

    Args:
        crawl_id: ID краулінгу
        config: Конфігурація

    Note:
        В production використовувати Celery для distributed tasks
    """
    try:
        logger.info("Background crawl %s started with URL: %s", crawl_id, config.url)

        from graph_crawler.api import async_crawl
        from graph_crawler.api.dashboard import monitor

        monitor.update_stats("crawl_started", {"crawl_id": crawl_id})

        request_delay = 1.0 / config.rate_limit_rps if config.enable_rate_limiting else 0.5

        graph = await async_crawl(
            url=config.url,
            max_depth=config.max_depth,
            max_pages=config.max_pages,
            same_domain=False,  # allowed_domains визначаються окремо
            request_delay=request_delay,
        )

        # P1-9: Store result in state store
        await _state_store.set("result_graph", graph.get_stats() if graph else None)
        await _state_store.set("status", "idle")

        # Статистика
        stats = graph.get_stats() if graph else {}
        logger.info("Crawl %s finished: %s", crawl_id, stats)
        monitor.update_stats("crawl_finished", {"crawl_id": crawl_id, "stats": stats})

    except Exception as e:
        logger.error("Error in background crawl %s: %s", crawl_id, e, exc_info=True)
        await _state_store.set("status", "error")

        from graph_crawler.api.dashboard import monitor

        monitor.update_stats(
            "error",
            {"crawl_id": crawl_id, "error": str(e), "error_type": type(e).__name__},
        )

# ============================================================================
# НОВИЙ ФУНКЦІОНАЛ 2026: Streaming JSON Lines для прогресу
# ============================================================================

@router.get("/crawl/{crawl_id}/progress/stream")
async def stream_crawl_progress(crawl_id: str):
    """
    Стрімінг прогресу краулінгу через JSON Lines (NDJSON).

    НОВИЙ ФУНКЦІОНАЛ FastAPI 0.135+: Streaming JSON Lines

    Клієнт отримує прогрес в реальному часі:
    ```
    {"status": "running", "pages": 10, "queue": 50, "pps": 2.5}
    {"status": "running", "pages": 15, "queue": 45, "pps": 2.7}
    {"status": "completed", "pages": 100, "queue": 0, "pps": 0}
    ```

    Args:
        crawl_id: ID краулінгу

    Returns:
        StreamingResponse з application/x-ndjson

    Raises:
        HTTPException: Якщо краулінг не знайдено

    Example (JavaScript client):
        ```javascript
        const response = await fetch('/api/v1/crawl/crawl_123/progress/stream');
        const reader = response.body.getReader();
        const decoder = new TextDecoder();

        while (true) {
            const {value, done} = await reader.read();
            if (done) break;
            const lines = decoder.decode(value).split('\\n');
            for (const line of lines) {
                if (line) {
                    const progress = JSON.parse(line);
                    console.log('Progress:', progress);
                }
            }
        }
        ```
    """
    stored_crawl_id = await _state_store.get("crawl_id")
    if stored_crawl_id != crawl_id:
        raise HTTPException(status_code=404, detail="Crawl not found")

    async def generate_progress() -> AsyncGenerator[str, None]:
        """Генератор прогресу для streaming."""
        import orjson

        from graph_crawler.api.dashboard import monitor

        while True:
            stats = monitor.get_current_stats()
            current_status = await _state_store.get("status") or "unknown"

            progress = {
                "status": current_status,
                "crawl_id": crawl_id,
                "pages": stats.get("total_pages", 0),
                "queue": stats.get("queue_size", 0),
                "errors": stats.get("errors", 0),
                "pps": round(stats.get("pages_per_second", 0.0), 2),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            # orjson швидше за json.dumps
            yield orjson.dumps(progress).decode() + "\n"

            # Завершуємо якщо краулінг закінчився
            if current_status in ("completed", "idle", "stopped", "error"):
                break

            await asyncio.sleep(0.5)  # Оновлення кожні 500ms

    return StreamingResponse(
        generate_progress(),
        media_type="application/x-ndjson",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",  # Вимикаємо буферизацію nginx
        }
    )

@router.get("/crawl/{crawl_id}/progress")
async def get_crawl_progress(crawl_id: str):
    """
    Отримати поточний прогрес краулінгу (одноразовий запит).

    Для реального часу використовуйте /progress/stream.

    Args:
        crawl_id: ID краулінгу

    Returns:
        Dict з прогресом
    """
    stored_crawl_id = await _state_store.get("crawl_id")
    if stored_crawl_id != crawl_id:
        raise HTTPException(status_code=404, detail="Crawl not found")

    from graph_crawler.api.dashboard import monitor

    stats = monitor.get_current_stats()
    status = await _state_store.get("status")

    return {
        "status": status or "unknown",
        "crawl_id": crawl_id,
        "pages": stats.get("total_pages", 0),
        "queue": stats.get("queue_size", 0),
        "errors": stats.get("errors", 0),
        "pps": round(stats.get("pages_per_second", 0.0), 2),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

