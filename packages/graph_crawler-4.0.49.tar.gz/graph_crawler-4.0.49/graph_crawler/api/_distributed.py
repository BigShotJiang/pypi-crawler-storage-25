"""
Distributed crawling через Celery workers.

"""
from __future__ import annotations

import logging
from typing import Any, cast

from graph_crawler.api._shared import DriverType
from graph_crawler.domain.entities.graph import Graph
from graph_crawler.domain.entities.node import Node
from graph_crawler.domain.value_objects.models import Rule

logger = logging.getLogger(__name__)

def distributed_crawl(
    url: str,
    max_depth: int,
    max_pages: int | None,
    wrapper_config: dict,
    driver: DriverType | None = None,
    driver_config: dict[str, Any | None] = None,
    plugins: list | None = None,
    node_class: type[Node | None] = None,
    url_rules: list[Rule | None] = None,
    edge_strategy: str = "all",
    timeout: int | None = None,
) -> Graph:
    """
    Розподілений краулінг через Celery workers.

    Returns:
        Graph з результатами (повний або частковий при timeout)
    """
    from graph_crawler.application.services.driver_factory import create_driver
    from graph_crawler.application.use_cases.crawling.celery_batch_spider import (
        CeleryBatchSpider,
    )
    from graph_crawler.domain.value_objects.configs import (
        CeleryConfig,
        CrawlerConfig,
        DriverConfig,
    )
    from graph_crawler.infrastructure.persistence.memory_storage import MemoryStorage
    from graph_crawler.infrastructure.persistence.mongodb_storage import MongoDBStorage
    from graph_crawler.infrastructure.persistence.postgresql_storage import (
        PostgreSQLStorage,
    )
    from graph_crawler.infrastructure.transport.sync import RequestsDriver as HTTPDriver

    logger.info("Starting DISTRIBUTED crawl for %s", url)
    logger.info("   Broker: %s", wrapper_config.get("broker", {}).get("type", "redis"))
    logger.info("   Database: %s", wrapper_config.get("database", {}).get("type", "memory"))
    broker_config = wrapper_config.get("broker", {})
    broker_type = broker_config.get("type", "redis")
    broker_host = broker_config.get("host", "localhost")
    broker_port = broker_config.get("port", 6379)
    broker_db = broker_config.get("db", 0)
    broker_password = broker_config.get("password")

    # Генеруємо broker URL
    if broker_type == "redis":
        auth = f":{broker_password}@" if broker_password else ""
        broker_url = f"redis://{auth}{broker_host}:{broker_port}/{broker_db}"
        backend_url = f"redis://{auth}{broker_host}:{broker_port}/{broker_db + 1}"
    elif broker_type == "rabbitmq":
        auth = f":{broker_password}@" if broker_password else ""
        broker_url = f"amqp://{auth}{broker_host}:{broker_port}//"
        backend_url = broker_url
    else:
        raise ValueError(f"Unsupported broker type: {broker_type}")
    db_config = wrapper_config.get("database", {})
    db_type = db_config.get("type", "memory")

    if db_type == "memory":
        storage = MemoryStorage()
    elif db_type == "mongodb":
        db_host = db_config.get("host", "localhost")
        db_port = db_config.get("port", 27017)
        db_name = db_config.get("database", "package_crawler")
        db_user = db_config.get("username")
        db_pass = db_config.get("password")

        auth = f"{db_user}:{db_pass}@" if db_user else ""
        connection_string = f"mongodb://{auth}{db_host}:{db_port}/"

        storage = MongoDBStorage(
            {
                "connection_string": connection_string,
                "database": db_name,
            }
        )
    elif db_type == "postgresql":
        db_host = db_config.get("host", "localhost")
        db_port = db_config.get("port", 5432)
        db_name = db_config.get("database", "package_crawler")
        db_user = db_config.get("username")
        db_pass = db_config.get("password")

        auth = f"{db_user}:{db_pass}@" if db_user else ""
        connection_string = f"postgresql://{auth}{db_host}:{db_port}/{db_name}"

        storage = PostgreSQLStorage({"connection_string": connection_string})
    else:
        raise ValueError(f"Unsupported database type: {db_type}")
    if driver is not None:
        if isinstance(driver, str):
            # Строка - створюємо через фабрику
            actual_driver = create_driver(driver, driver_config or {})
        elif isinstance(driver, type):
            # Передано клас, а не екземпляр - створюємо екземпляр
            logger.info("Creating driver instance from class: %s", driver.__name__)
            actual_driver = driver(driver_config or {})
        else:
            # Вже інстанс драйвера
            actual_driver = driver
    else:
        # Дефолтний HTTPDriver
        actual_driver = HTTPDriver({})
    crawler_config = CrawlerConfig(
        url=url,
        max_depth=max_depth,
        max_pages=max_pages,
        driver=DriverConfig(),
        node_plugins=plugins or [],
        custom_node_class=node_class,
        url_rules=url_rules or [],
        edge_strategy=edge_strategy,
        celery=CeleryConfig(
            enabled=True,
            broker_url=broker_url,
            backend_url=backend_url,
            workers=wrapper_config.get("workers", 10),
            task_time_limit=wrapper_config.get("task_time_limit", 600),
            worker_prefetch_multiplier=wrapper_config.get("worker_prefetch_multiplier", 4),
        ),
    )
    # batch_size можна задати через wrapper config, або буде взято з драйвера
    batch_size = wrapper_config.get("batch_size")

    if batch_size is None:
        # Визначаємо batch_size з драйвера (для max ефективності)
        # Використовуємо getattr для безпечного доступу до атрибутів
        max_concurrent = getattr(actual_driver, "max_concurrent", None)
        if max_concurrent is not None:
            batch_size = max_concurrent
        else:
            max_browsers = getattr(actual_driver, "max_browsers", None)
            max_tabs = getattr(actual_driver, "max_tabs_per_browser", None)
            if max_browsers is not None and max_tabs is not None:
                batch_size = max_browsers * max_tabs

    logger.info("   Batch size: %s", batch_size)

    # Передаємо timeout в spider для коректної обробки
    # Використовуємо Any для типу драйвера, оскільки CeleryBatchSpider
    # працює з різними типами драйверів
    spider = CeleryBatchSpider(
        crawler_config, cast(Any, actual_driver), storage, batch_size=batch_size, timeout=timeout
    )
    # Тепер timeout обробляється всередині spider
    try:
        graph = spider.crawl()

        logger.info("Distributed crawl completed: %d nodes", len(graph.nodes))
        return graph
    except Exception as e:
        logger.error("Distributed crawl failed: %s", e)
        # Повертаємо частковий граф якщо є
        graph = spider.get_partial_graph()
        if graph and len(graph.nodes) > 0:
            logger.info("Returning partial graph: %d nodes", len(graph.nodes))
            return graph
        raise

__all__ = ["distributed_crawl"]
