"""
Data Layer Backends.

Pluggable implementations of IGraphBackend for different storage needs.

Available:
- MemoryBackend: In-RAM storage (tests, <10K nodes) [PRODUCTION-READY]
- SQLiteBackend: Local SQLite file (<1M nodes) [PRODUCTION-READY]

Planned (not yet implemented):
- PostgreSQLBackend: Scalable PostgreSQL (100M+ nodes)
- MongoDBBackend: Flexible schema
"""

from graph_crawler.data.backends.memory import MemoryBackend

try:
    from graph_crawler.data.backends.sqlite import SQLiteBackend
    _has_sqlite = True
except ImportError:
    SQLiteBackend = None
    _has_sqlite = False

__all__ = [
    "MemoryBackend",
    "SQLiteBackend",
]
