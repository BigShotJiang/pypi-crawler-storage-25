"""Декоратор для кешування результатів.

ОПТИМІЗОВАНО 2026: Використовує orjson для серіалізації ключів (4-12x швидше).
"""
from __future__ import annotations

import functools
import hashlib
import logging
import time
from typing import Any, Callable

import orjson

# Local constant to avoid circular imports
DEFAULT_CACHE_TTL = 3600  # 1 hour in seconds

logger = logging.getLogger(__name__)


class SimpleCache:
    """
    Простий thread-safe in-memory кеш з TTL.

    Примітка: Це in-memory only кеш.
    - Дані зберігаються тільки в RAM
    - Кеш очищується при restart процесу
    - Немає персистентності на диск
    - Для персистентного кешу використовуйте diskcache або Redis

    Thread-safety: Використовує RLock для захисту від race conditions.
    """

    def __init__(self):
        import threading

        self._cache: dict[str, tuple[Any, float]] = {}
        self._lock = threading.RLock()

    def get(self, key: str, ttl: float | None = None) -> Any | None:
        """Отримує значення з кешу (thread-safe)."""
        with self._lock:
            if key not in self._cache:
                return None

            value, timestamp = self._cache[key]

            if ttl and (time.time() - timestamp) > ttl:
                del self._cache[key]
                return None

            return value

    def set(self, key: str, value: Any):
        """Зберігає значення у кеш (thread-safe)."""
        with self._lock:
            self._cache[key] = (value, time.time())

    def clear(self):
        """Очищує кеш (thread-safe)."""
        with self._lock:
            self._cache.clear()


_global_cache = SimpleCache()


def make_cache_key(func_name: str, args: tuple, kwargs: dict) -> str:
    """
    Створює надійний ключ кешу з використанням хешування.

    Args:
        func_name: Назва функції
        args: Позиційні аргументи
        kwargs: Іменовані аргументи

    Returns:
        Хеш-ключ для кешу
    """
    try:
        # Спроба серіалізації через orjson (4-12x швидше за json)
        key_data = {"func": func_name, "args": args, "kwargs": sorted(kwargs.items())}
        key_str = orjson.dumps(key_data, option=orjson.OPT_SORT_KEYS, default=str)
        return hashlib.md5(key_str, usedforsecurity=False).hexdigest()
    except (TypeError, ValueError):
        # Fallback для unhashable об'єктів
        return hashlib.md5(
            f"{func_name}:{repr(args)}:{repr(sorted(kwargs.items()))}".encode("utf-8"),
            usedforsecurity=False,
        ).hexdigest()


def cache(ttl: float | None = DEFAULT_CACHE_TTL):
    """
    Декоратор для кешування результатів функції.

    Args:
        ttl: Time to live (секунди). None = безкінечно

    Приклад:
        @cache(ttl=3600)  # 1 година
        def fetch_url(url):
            return requests.get(url)
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Створюємо надійний ключ з використанням хешування
            cache_key = make_cache_key(func.__name__, args, kwargs)

            # Перевіряємо кеш
            cached_value = _global_cache.get(cache_key, ttl)
            if cached_value is not None:
                logger.debug("Cache hit: %s", func.__name__)
                return cached_value

            # Виконуємо функцію
            result = func(*args, **kwargs)

            # Зберігаємо в кеш
            _global_cache.set(cache_key, result)

            return result

        return wrapper

    return decorator
