"""Extended diagnostics and runtime metrics.

Advanced metrics collection inspired by Scrapy Stats Collector and Crawlee AutoscaledPool.
Includes event loop diagnostics, network stats, and crawl session statistics.
"""
from __future__ import annotations

import asyncio
import logging
import socket
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class ResourceStatus(Enum):
    """System resource status levels."""
    OK = "ok"
    WARNING = "warning"
    CRITICAL = "critical"
    OVERLOADED = "overloaded"


@dataclass
class EventLoopMetrics:
    """Event loop diagnostics.
    
    Tracks event loop health - critical for async crawlers.
    High lag indicates blocking operations in the loop.
    """
    lag_ms: float  # Current lag in milliseconds
    lag_max_ms: float  # Maximum observed lag
    lag_avg_ms: float  # Average lag
    pending_tasks: int  # Number of pending asyncio tasks
    ready_callbacks: int  # Callbacks in _ready queue (if accessible)
    scheduled_callbacks: int  # Scheduled callbacks
    running_tasks: int  # Currently running tasks

    def is_healthy(self, max_lag_ms: float = 100.0) -> bool:
        """Check if event loop is healthy (lag below threshold)."""
        return self.lag_ms < max_lag_ms

    def get_status(self) -> ResourceStatus:
        """Get event loop status based on lag."""
        if self.lag_ms < 50:
            return ResourceStatus.OK
        elif self.lag_ms < 100:
            return ResourceStatus.WARNING
        elif self.lag_ms < 500:
            return ResourceStatus.CRITICAL
        return ResourceStatus.OVERLOADED


@dataclass
class NetworkCapabilities:
    """Network environment diagnostics.
    
    Collected once at startup to understand network constraints.
    """
    hostname: str
    fqdn: str  # Fully qualified domain name
    local_ips: List[str]
    has_ipv6: bool
    dns_servers: List[str]  # System DNS servers
    default_timeout_works: bool  # Can make outbound connections
    proxy_detected: bool  # HTTP_PROXY/HTTPS_PROXY set
    proxy_url: Optional[str]
    ssl_version: str  # OpenSSL version
    max_open_files: Optional[int]  # ulimit -n

    def to_dict(self) -> dict:
        return {
            "hostname": self.hostname,
            "fqdn": self.fqdn,
            "local_ips": self.local_ips,
            "has_ipv6": self.has_ipv6,
            "dns_servers": self.dns_servers,
            "proxy_detected": self.proxy_detected,
            "proxy_url": self.proxy_url if self.proxy_detected else None,
            "ssl_version": self.ssl_version,
            "max_open_files": self.max_open_files,
        }


@dataclass
class RuntimeEnvironment:
    """Runtime environment information.
    
    Useful for debugging and reproducing issues.
    """
    python_path: List[str]  # sys.path
    virtual_env: Optional[str]  # VIRTUAL_ENV
    working_directory: str
    user: str  # Current user
    pid: int  # Process ID
    ppid: int  # Parent process ID
    start_time: datetime
    timezone: str
    locale: str
    encoding: str  # Default encoding

    # Installed packages (crawler-related)
    installed_packages: Dict[str, str]  # package: version

    def to_dict(self) -> dict:
        return {
            "python_path_count": len(self.python_path),
            "virtual_env": self.virtual_env,
            "working_directory": self.working_directory,
            "user": self.user,
            "pid": self.pid,
            "ppid": self.ppid,
            "start_time": self.start_time.isoformat(),
            "timezone": self.timezone,
            "locale": self.locale,
            "encoding": self.encoding,
            "packages": self.installed_packages,
        }


@dataclass
class CrawlSessionStats:
    """Statistics for a single crawl session (like Scrapy Stats Collector).
    
    Tracks all metrics during a crawl run.
    """
    # Timing
    start_time: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    finish_time: Optional[datetime] = None

    # Request counts
    request_count: int = 0
    request_success_count: int = 0
    request_failed_count: int = 0
    request_retry_count: int = 0

    # Response stats
    response_status_counts: Dict[int, int] = field(default_factory=lambda: defaultdict(int))
    response_bytes_received: int = 0

    # Items/Data
    items_scraped: int = 0
    items_dropped: int = 0

    # Depth tracking
    max_depth_reached: int = 0
    requests_per_depth: Dict[int, int] = field(default_factory=lambda: defaultdict(int))

    # Timing stats
    request_durations: List[float] = field(default_factory=list)  # For percentile calc

    # Error tracking
    error_counts: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    last_errors: List[Dict[str, Any]] = field(default_factory=list)

    # Memory snapshots
    memory_peak_mb: float = 0.0
    memory_snapshots: List[float] = field(default_factory=list)

    # Custom stats (user-defined)
    custom: Dict[str, Any] = field(default_factory=dict)

    # Internal
    _max_duration_samples: int = 10000  # Limit samples for memory

    def record_request(
        self,
        success: bool,
        status_code: Optional[int] = None,
        duration_ms: Optional[float] = None,
        bytes_received: int = 0,
        depth: int = 0,
        error: Optional[str] = None,
    ) -> None:
        """Record a request completion."""
        self.request_count += 1

        if success:
            self.request_success_count += 1
        else:
            self.request_failed_count += 1
            if error:
                error_type = error.split(":")[0] if ":" in error else error[:50]
                self.error_counts[error_type] += 1
                self.last_errors.append({
                    "type": error_type,
                    "message": error[:200],
                    "time": datetime.now(timezone.utc).isoformat(),
                })
                # Keep only last 100 errors
                if len(self.last_errors) > 100:
                    self.last_errors = self.last_errors[-100:]

        if status_code:
            self.response_status_counts[status_code] += 1

        if duration_ms is not None:
            if len(self.request_durations) < self._max_duration_samples:
                self.request_durations.append(duration_ms)

        self.response_bytes_received += bytes_received

        if depth > self.max_depth_reached:
            self.max_depth_reached = depth
        self.requests_per_depth[depth] += 1

    def record_retry(self) -> None:
        """Record a retry attempt."""
        self.request_retry_count += 1

    def record_item(self, scraped: bool = True) -> None:
        """Record item processing."""
        if scraped:
            self.items_scraped += 1
        else:
            self.items_dropped += 1

    def set_value(self, key: str, value: Any) -> None:
        """Set custom stat value (Scrapy-compatible)."""
        self.custom[key] = value

    def inc_value(self, key: str, count: int = 1) -> None:
        """Increment custom stat (Scrapy-compatible)."""
        self.custom[key] = self.custom.get(key, 0) + count

    def max_value(self, key: str, value: float) -> None:
        """Set custom stat if greater than current (Scrapy-compatible)."""
        current = self.custom.get(key, float('-inf'))
        if value > current:
            self.custom[key] = value

    def min_value(self, key: str, value: float) -> None:
        """Set custom stat if less than current."""
        current = self.custom.get(key, float('inf'))
        if value < current:
            self.custom[key] = value

    def finish(self) -> None:
        """Mark session as finished."""
        self.finish_time = datetime.now(timezone.utc)

    @property
    def duration_seconds(self) -> float:
        """Total session duration in seconds."""
        end = self.finish_time or datetime.now(timezone.utc)
        return (end - self.start_time).total_seconds()

    @property
    def requests_per_minute(self) -> float:
        """Average requests per minute."""
        duration_min = self.duration_seconds / 60
        if duration_min > 0:
            return self.request_count / duration_min
        return 0.0

    @property
    def success_rate(self) -> float:
        """Success rate as percentage."""
        if self.request_count > 0:
            return (self.request_success_count / self.request_count) * 100
        return 0.0

    def get_latency_percentiles(self) -> Dict[str, float]:
        """Calculate latency percentiles (p50, p90, p95, p99)."""
        if not self.request_durations:
            return {"p50": 0, "p90": 0, "p95": 0, "p99": 0}

        sorted_durations = sorted(self.request_durations)
        n = len(sorted_durations)

        def percentile(p: float) -> float:
            idx = int(n * p / 100)
            return sorted_durations[min(idx, n - 1)]

        return {
            "p50": round(percentile(50), 2),
            "p90": round(percentile(90), 2),
            "p95": round(percentile(95), 2),
            "p99": round(percentile(99), 2),
        }

    def get_stats(self) -> Dict[str, Any]:
        """Get all stats as dictionary (Scrapy-compatible)."""
        latency = self.get_latency_percentiles()

        return {
            "start_time": self.start_time.isoformat(),
            "finish_time": self.finish_time.isoformat() if self.finish_time else None,
            "duration_seconds": round(self.duration_seconds, 2),
            "requests": {
                "total": self.request_count,
                "success": self.request_success_count,
                "failed": self.request_failed_count,
                "retry": self.request_retry_count,
                "per_minute": round(self.requests_per_minute, 2),
                "success_rate": round(self.success_rate, 2),
            },
            "responses": {
                "status_codes": dict(self.response_status_counts),
                "bytes_received": self.response_bytes_received,
                "bytes_received_mb": round(self.response_bytes_received / (1024 * 1024), 2),
            },
            "latency_ms": latency,
            "items": {
                "scraped": self.items_scraped,
                "dropped": self.items_dropped,
            },
            "depth": {
                "max_reached": self.max_depth_reached,
                "per_depth": dict(self.requests_per_depth),
            },
            "errors": {
                "counts": dict(self.error_counts),
                "last_errors": self.last_errors[-10:],  # Last 10
            },
            "memory": {
                "peak_mb": round(self.memory_peak_mb, 2),
            },
            "custom": self.custom,
        }


class EventLoopMonitor:
    """Monitors event loop lag (like Crawlee's SystemStatus).
    
    Usage:
        monitor = EventLoopMonitor()
        asyncio.create_task(monitor.start())
        # ... later ...
        metrics = monitor.get_metrics()
        await monitor.stop()
    """

    def __init__(
        self,
        interval_ms: float = 50,  # Check interval
        warn_threshold_ms: float = 100,  # Log warning if exceeded
        history_size: int = 100,  # Number of samples to keep
    ):
        self.interval_ms = interval_ms
        self.warn_threshold_ms = warn_threshold_ms
        self.history_size = history_size

        self._running = False
        self._task: Optional[asyncio.Task] = None
        self._lag_history: List[float] = []
        self._lag_max: float = 0.0

    async def start(self) -> None:
        """Start monitoring event loop."""
        if self._running:
            return

        self._running = True
        self._task = asyncio.create_task(self._monitor_loop())
        logger.debug("Event loop monitor started (interval=%dms)", self.interval_ms)

    async def stop(self) -> None:
        """Stop monitoring."""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.debug("Event loop monitor stopped")

    async def _monitor_loop(self) -> None:
        """Main monitoring loop."""
        interval_sec = self.interval_ms / 1000
        loop = asyncio.get_running_loop()

        while self._running:
            start = loop.time()
            await asyncio.sleep(interval_sec)
            end = loop.time()

            # Calculate lag (actual time - expected time)
            actual_ms = (end - start) * 1000
            lag_ms = max(0, actual_ms - self.interval_ms)

            # Update history
            self._lag_history.append(lag_ms)
            if len(self._lag_history) > self.history_size:
                self._lag_history.pop(0)

            # Track max
            if lag_ms > self._lag_max:
                self._lag_max = lag_ms

            # Warn if threshold exceeded
            if lag_ms > self.warn_threshold_ms:
                logger.warning(
                    "Event loop lag: %.1fms (threshold: %.1fms) - possible blocking operation",
                    lag_ms,
                    self.warn_threshold_ms,
                )

    def get_metrics(self) -> EventLoopMetrics:
        """Get current event loop metrics."""
        try:
            loop = asyncio.get_running_loop()
            all_tasks = asyncio.all_tasks(loop)
            pending = sum(1 for t in all_tasks if not t.done())
            running = sum(1 for t in all_tasks if not t.done() and not t.cancelled())

            # Try to access internal queues (may not be available)
            ready_callbacks = len(getattr(loop, '_ready', []))
            scheduled_callbacks = len(getattr(loop, '_scheduled', []))
        except RuntimeError:
            pending = 0
            running = 0
            ready_callbacks = 0
            scheduled_callbacks = 0

        current_lag = self._lag_history[-1] if self._lag_history else 0.0
        avg_lag = sum(self._lag_history) / len(self._lag_history) if self._lag_history else 0.0

        return EventLoopMetrics(
            lag_ms=current_lag,
            lag_max_ms=self._lag_max,
            lag_avg_ms=avg_lag,
            pending_tasks=pending,
            ready_callbacks=ready_callbacks,
            scheduled_callbacks=scheduled_callbacks,
            running_tasks=running,
        )


def collect_network_capabilities() -> NetworkCapabilities:
    """Collect network environment information.
    
    Called once at startup to understand network constraints.
    """
    import os
    import ssl

    # Hostname
    hostname = socket.gethostname()
    try:
        fqdn = socket.getfqdn()
    except Exception:
        fqdn = hostname

    # Local IPs
    local_ips = []
    try:
        # Get all addresses for hostname
        for info in socket.getaddrinfo(hostname, None):
            ip = info[4][0]
            if ip not in local_ips and not ip.startswith("127."):
                local_ips.append(ip)
    except Exception:
        pass

    # Check IPv6 support
    has_ipv6 = False
    try:
        socket.socket(socket.AF_INET6, socket.SOCK_STREAM).close()
        has_ipv6 = True
    except (OSError, socket.error):
        pass

    # DNS servers (platform-specific)
    dns_servers = []
    try:
        # Linux: /etc/resolv.conf
        if os.path.exists("/etc/resolv.conf"):
            with open("/etc/resolv.conf") as f:
                for line in f:
                    if line.strip().startswith("nameserver"):
                        parts = line.split()
                        if len(parts) >= 2:
                            dns_servers.append(parts[1])
    except Exception:
        pass

    # Proxy detection
    proxy_detected = False
    proxy_url = None
    for var in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"):
        val = os.environ.get(var)
        if val:
            proxy_detected = True
            proxy_url = val
            break

    # SSL version
    ssl_version = ssl.OPENSSL_VERSION

    # Max open files (ulimit -n)
    max_open_files = None
    try:
        import resource
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        max_open_files = soft
    except (ImportError, Exception):
        pass

    # Test outbound connectivity (quick check)
    default_timeout_works = True  # Assume true by default

    return NetworkCapabilities(
        hostname=hostname,
        fqdn=fqdn,
        local_ips=local_ips,
        has_ipv6=has_ipv6,
        dns_servers=dns_servers,
        default_timeout_works=default_timeout_works,
        proxy_detected=proxy_detected,
        proxy_url=proxy_url,
        ssl_version=ssl_version,
        max_open_files=max_open_files,
    )


def collect_runtime_environment() -> RuntimeEnvironment:
    """Collect runtime environment information."""
    import locale
    import os
    import sys

    # Installed packages (crawler-related only)
    packages = {}
    crawler_packages = [
        "aiohttp", "httpx", "requests", "beautifulsoup4", "lxml",
        "scrapy", "selenium", "playwright", "pyppeteer",
        "aiodns", "uvloop", "psutil", "orjson", "ujson",
        "pydantic", "graph-crawler",
    ]

    try:
        from importlib.metadata import PackageNotFoundError, version
        for pkg in crawler_packages:
            try:
                packages[pkg] = version(pkg)
            except PackageNotFoundError:
                pass
    except ImportError:
        pass

    # Locale and encoding
    try:
        current_locale = locale.getlocale()[0] or "unknown"
    except Exception:
        current_locale = "unknown"

    # Timezone
    try:
        from datetime import datetime
        tz_name = datetime.now().astimezone().tzname() or "unknown"
    except Exception:
        tz_name = "unknown"

    return RuntimeEnvironment(
        python_path=sys.path.copy(),
        virtual_env=os.environ.get("VIRTUAL_ENV"),
        working_directory=os.getcwd(),
        user=os.environ.get("USER", os.environ.get("USERNAME", "unknown")),
        pid=os.getpid(),
        ppid=os.getppid(),
        start_time=datetime.now(timezone.utc),
        timezone=tz_name,
        locale=current_locale,
        encoding=sys.getdefaultencoding(),
        installed_packages=packages,
    )


@dataclass
class SystemSnapshot:
    """Complete system snapshot at a point in time.
    
    Combines all diagnostics for debugging and optimization.
    """
    timestamp: datetime
    platform_info: Any  # PlatformInfo
    network: NetworkCapabilities
    environment: RuntimeEnvironment
    event_loop: Optional[EventLoopMetrics]

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization/logging."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "platform": self.platform_info.to_dict() if self.platform_info else None,
            "network": self.network.to_dict(),
            "environment": self.environment.to_dict(),
            "event_loop": {
                "lag_ms": self.event_loop.lag_ms,
                "lag_max_ms": self.event_loop.lag_max_ms,
                "pending_tasks": self.event_loop.pending_tasks,
                "status": self.event_loop.get_status().value,
            } if self.event_loop else None,
        }


def collect_system_snapshot(
    include_event_loop: bool = False,
    event_loop_monitor: Optional[EventLoopMonitor] = None,
) -> SystemSnapshot:
    """Collect complete system snapshot.
    
    Args:
        include_event_loop: Include event loop metrics (requires running loop)
        event_loop_monitor: Optional pre-existing monitor instance
    
    Returns:
        SystemSnapshot with all collected information.
    """
    from graph_crawler.shared.platform.detector import get_cached_platform_info

    platform_info = get_cached_platform_info()
    network = collect_network_capabilities()
    environment = collect_runtime_environment()

    event_loop_metrics = None
    if include_event_loop and event_loop_monitor:
        event_loop_metrics = event_loop_monitor.get_metrics()

    return SystemSnapshot(
        timestamp=datetime.now(timezone.utc),
        platform_info=platform_info,
        network=network,
        environment=environment,
        event_loop=event_loop_metrics,
    )


# Global stats instance (like Scrapy's crawler.stats)
_global_stats: Optional[CrawlSessionStats] = None


def get_global_stats() -> CrawlSessionStats:
    """Get or create global crawl stats instance."""
    global _global_stats
    if _global_stats is None:
        _global_stats = CrawlSessionStats()
    return _global_stats


def reset_global_stats() -> CrawlSessionStats:
    """Reset global stats and return new instance."""
    global _global_stats
    _global_stats = CrawlSessionStats()
    return _global_stats
