"""JSON серіалізація з orjson fallback.

orjson (Rust-based) забезпечує 5-10x прискорення порівняно зі стандартним json.
Fallback на стандартний json коли orjson недоступний.

Benchmark (1M об'єктів):
- orjson: ~0.5 сек
- json: ~2.5 сек
- ujson: ~1.2 сек

Usage:
    >>> from graph_crawler.shared.utils.fast_json import dumps, loads
    >>> data = {"url": "https://example.com", "depth": 1}
    >>> json_str = dumps(data)
    >>> restored = loads(json_str)

Installation:
    pip install orjson
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Union
from uuid import UUID

logger = logging.getLogger(__name__)

# Детекція orjson
_orjson_available = False
_orjson = None

try:
    import orjson as _orjson

    _orjson_available = True
    logger.info(" orjson available - using fastest JSON serialization (+50% speed)")
except ImportError:
    import json as _json_fallback

    logger.debug("orjson not installed. Install with: pip install orjson")


def _default_serializer(obj: Any) -> Any:
    """
    Default serializer для нестандартних типів.

    Підтримує:
    - datetime -> ISO format string
    - UUID -> string
    - set -> list
    - bytes -> string (utf-8)
    - Об'єкти з __dict__ -> dict
    """
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, UUID):
        return str(obj)
    if isinstance(obj, set):
        return list(obj)
    if isinstance(obj, bytes):
        return obj.decode("utf-8", errors="replace")
    if hasattr(obj, "__dict__"):
        return obj.__dict__
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def dumps(
    obj: Any,
    *,
    indent: int | None = None,
    sort_keys: bool = False,
    default: Any = None,
) -> str:
    """
    Серіалізує об'єкт в JSON string.

    Args:
        obj: Об'єкт для серіалізації
        indent: Відступ для pretty-print (None = compact)
        sort_keys: Сортувати ключі словника
        default: Функція для серіалізації нестандартних типів

    Returns:
        JSON string
    """
    serializer = default or _default_serializer

    if _orjson_available:
        # orjson options
        options = 0
        if indent is not None:
            options |= _orjson.OPT_INDENT_2
        if sort_keys:
            options |= _orjson.OPT_SORT_KEYS

        try:
            # orjson повертає bytes, конвертуємо в str
            return _orjson.dumps(obj, default=serializer, option=options).decode("utf-8")
        except TypeError as e:
            logger.warning("orjson serialization failed: %s, using fallback", e)

    # Fallback на стандартний json
    return _json_fallback.dumps(
        obj,
        indent=indent,
        sort_keys=sort_keys,
        default=serializer,
        ensure_ascii=False,
    )


def dumps_bytes(obj: Any, *, default: Any = None) -> bytes:
    """
    Серіалізує об'єкт в JSON bytes.

    Швидше ніж dumps() - уникає decode() виклику.

    Args:
        obj: Об'єкт для серіалізації
        default: Функція для серіалізації нестандартних типів

    Returns:
        JSON bytes
    """
    serializer = default or _default_serializer

    if _orjson_available:
        return _orjson.dumps(obj, default=serializer)

    # Fallback
    return _json_fallback.dumps(obj, default=serializer, ensure_ascii=False).encode("utf-8")


def loads(s: Union[str, bytes]) -> Any:
    """
    Десеріалізує JSON string/bytes в об'єкт.

    Args:
        s: JSON string або bytes

    Returns:
        Десеріалізований об'єкт
    """
    if _orjson_available:
        return _orjson.loads(s)

    # Fallback
    if isinstance(s, bytes):
        s = s.decode("utf-8")
    return _json_fallback.loads(s)


def is_orjson_available() -> bool:
    """
    Перевіряє чи orjson доступний.

    Returns:
        True якщо orjson встановлено
    """
    return _orjson_available


# Backward compatibility з стандартним json API
# File-based dump/load не підтримуються - використовуйте dumps/loads
dump = None
load = None

# JSONDecodeError для сумісності
# orjson не має свого JSONDecodeError, використовуємо стандартний json
from json import JSONDecodeError

__all__ = [
    "dumps",
    "dumps_bytes",
    "loads",
    "is_orjson_available",
    "JSONDecodeError",
]
