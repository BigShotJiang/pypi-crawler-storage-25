"""Markdown Generator - Core Implementation.

Standalone утиліта для генерації Markdown з HTML.
Швидка, асинхронна, налаштовувана.

Дизайн:
- Не плагін - викликається вибірково коли потрібно
- Працює з BaseTreeAdapter або з HTML string
- Thread-safe

ROADMAP Implementation:
- Vector 1: Оптимізовані проходи (_remove_noise_optimized)
- Vector 2: Selectolax як опція (fallback pattern)
- Vector 4: Dynamic Noise Patterns
- Vector 5: Lazy raw_markdown
"""
from __future__ import annotations

import logging
import re
import threading
from typing import Any, Union

from graph_crawler.shared.utils.markdown.options import MarkdownOptions
from graph_crawler.shared.utils.markdown.result import MarkdownResult

logger = logging.getLogger(__name__)

# Thread-safe lazy import з кешуванням
_parser_lock = threading.Lock()
_parser_cache = {}


def _get_bs4():
    """Thread-safe lazy import BeautifulSoup."""
    if "BeautifulSoup" not in _parser_cache:
        with _parser_lock:
            if "BeautifulSoup" not in _parser_cache:
                from bs4 import BeautifulSoup
                _parser_cache["BeautifulSoup"] = BeautifulSoup
    return _parser_cache["BeautifulSoup"]


# ======== VECTOR 2: Selectolax availability check ========
_selectolax_available = False
try:
    from selectolax.parser import HTMLParser as SelectolaxParser
    _selectolax_available = True
except ImportError:
    SelectolaxParser = None


class MarkdownGenerator:
    """
    Генератор Markdown з HTML.
    
    Підтримує:
    - BeautifulSoup (default fallback)
    - Selectolax (~5x швидший, якщо доступний)
    """

    __slots__ = ("options", "_use_selectolax")

    def __init__(self, options: MarkdownOptions | None = None):
        """
        Ініціалізує MarkdownGenerator.

        Args:
            options: Налаштування генерації (опціонально)
        """
        self.options = options or MarkdownOptions()
        
        # ======== VECTOR 2: Selectolax як опція ========
        self._use_selectolax = (
            _selectolax_available 
            and not self.options.force_beautifulsoup
        )

    @staticmethod
    def quick_generate(html: str) -> MarkdownResult:
        """
        Статичний метод для швидкої генерації з дефолтними опціями.

        Для простих випадків коли не потрібна кастомізація.

        Args:
            html: HTML string

        Returns:
            MarkdownResult
        """
        return MarkdownGenerator().generate_from_html(html)

    def generate(self, source: Union[str, Any]) -> MarkdownResult:
        """
        Генерує Markdown з HTML або adapter.

        Універсальний метод - автоматично визначає тип input.

        Args:
            source: HTML string або BaseTreeAdapter

        Returns:
            MarkdownResult з різними варіантами тексту
        """
        if isinstance(source, str):
            return self.generate_from_html(source)

        # Припускаємо що це adapter з методом parse
        if hasattr(source, "tree") and hasattr(source, "find_all"):
            return self.generate_from_adapter(source)

        logger.warning("Unknown source type: %s", type(source))
        return MarkdownResult.empty()

    def generate_from_html(self, html: str) -> MarkdownResult:
        """
        Генерує Markdown з HTML string.

        Основний метод для standalone використання.
        Використовує selectolax якщо доступний, інакше BeautifulSoup.

        Args:
            html: HTML string

        Returns:
            MarkdownResult
        """
        if not html or not html.strip():
            return MarkdownResult.empty()

        try:
            # ======== VECTOR 2: Вибір парсера ========
            if self._use_selectolax:
                return self._process_selectolax(html)
            else:
                return self._process_beautifulsoup(html)
        except (ValueError, AttributeError, TypeError) as e:
            logger.error("Error generating markdown: %s", e)
            return MarkdownResult.empty()

    def _process_beautifulsoup(self, html: str) -> MarkdownResult:
        """
        Обробляє HTML через BeautifulSoup.
        
        Args:
            html: HTML string
            
        Returns:
            MarkdownResult
        """
        BeautifulSoup = _get_bs4()

        try:
            soup = BeautifulSoup(html, "lxml")
        except ImportError:
            soup = BeautifulSoup(html, "html.parser")

        return self._process_soup(soup, html)

    def _process_selectolax(self, html: str) -> MarkdownResult:
        """
        Обробляє HTML через Selectolax (~5x швидше за BeautifulSoup).
        
        Args:
            html: HTML string
            
        Returns:
            MarkdownResult
        """
        try:
            tree = SelectolaxParser(html)
            
            # 1. Витягуємо метадані ДО очищення
            title = self._extract_title_selectolax(tree)
            h1 = self._extract_h1_selectolax(tree)
            description = self._extract_description_selectolax(tree)

            # 2. Для fit_markdown - очищаємо копію
            clean_tree = SelectolaxParser(html)
            self._remove_noise_selectolax(clean_tree)
            
            # 3. Генеруємо fit_markdown
            fit_markdown, stats = self._selectolax_to_markdown(clean_tree)

            # 4. Чистий текст
            text = self._extract_text_selectolax(clean_tree)

            # 5. Застосовуємо dynamic patterns
            text = self._apply_dynamic_patterns(text)
            fit_markdown = self._apply_dynamic_patterns(fit_markdown)

            # 6. Перевірка довжини
            is_truncated = False
            if len(text) > self.options.max_length:
                text = text[: self.options.max_length]
                is_truncated = True

            # 7. Створюємо результат з lazy raw_markdown
            result = MarkdownResult(
                text=text,
                fit_markdown=fit_markdown,
                title=title,
                h1=h1,
                description=description,
                word_count=len(text.split()),
                char_count=len(text),
                heading_count=stats.get("headings", 0),
                link_count=stats.get("links", 0),
                image_count=stats.get("images", 0),
                is_truncated=is_truncated,
            )
            
            # ======== VECTOR 5: Lazy raw_markdown ========
            result.set_lazy_raw_markdown(html, self)
            
            return result
            
        except Exception as e:
            logger.warning("Selectolax failed, falling back to BeautifulSoup: %s", e)
            return self._process_beautifulsoup(html)

    def _remove_noise_selectolax(self, tree) -> None:
        """
        Видаляє noise елементи з selectolax дерева.
        Оптимізовано: один прохід для всіх тегів.
        """
        # ======== VECTOR 1: Grouped removal ========
        # Прохід 1: Важкі теги (script, style, etc.)
        heavy_tags = list(self.options.noise_tags)
        for tag in heavy_tags:
            for node in tree.css(tag):
                node.decompose()

        # Прохід 2: Структурні елементи
        structural = []
        if self.options.remove_nav:
            structural.append('nav')
        if self.options.remove_header:
            structural.append('header')
        if self.options.remove_footer:
            structural.append('footer')
        if self.options.remove_aside:
            structural.append('aside')
        if self.options.remove_buttons:
            structural.append('button')

        for tag in structural:
            for node in tree.css(tag):
                node.decompose()

        # Прохід 3: По класам/id (ads, popups)
        if self.options.remove_ads:
            # Видаляємо елементи з noise класами
            for css_class in self.options.noise_classes:
                for node in tree.css(f'.{css_class}'):
                    node.decompose()
            # Видаляємо елементи з noise id
            for noise_id in self.options.noise_ids:
                for node in tree.css(f'#{noise_id}'):
                    node.decompose()

    def _selectolax_to_markdown(self, tree) -> tuple[str, dict[str, int]]:
        """Конвертує selectolax дерево в Markdown."""
        md_parts = []
        stats = {"headings": 0, "links": 0, "images": 0, "code": 0, "lists": 0}

        body = tree.css_first('body') or tree.root

        # Заголовки
        for level in range(1, 7):
            for h in tree.css(f'h{level}'):
                text = h.text(strip=True)
                if text and len(text) >= self.options.min_heading_length:
                    md_parts.append(f"\n{'#' * level} {text}\n")
                    stats["headings"] += 1

        # Параграфи
        for p in tree.css('p'):
            text = p.text(strip=True)
            if text and len(text) >= self.options.min_paragraph_length:
                md_parts.append(f"\n{text}\n")

        # Списки
        if self.options.include_lists:
            for ul in tree.css('ul'):
                for li in ul.css('li'):
                    text = li.text(strip=True)
                    if text:
                        md_parts.append(f"- {text}")
                stats["lists"] += 1
            for ol in tree.css('ol'):
                for i, li in enumerate(ol.css('li'), 1):
                    text = li.text(strip=True)
                    if text:
                        md_parts.append(f"{i}. {text}")
                stats["lists"] += 1

        # Посилання
        if self.options.include_links:
            for a in tree.css('a[href]'):
                stats["links"] += 1

        # Зображення
        if self.options.include_images:
            for img in tree.css('img[src]'):
                src = img.attributes.get('src', '')
                alt = img.attributes.get('alt', '')
                if src:
                    md_parts.append(f"\n![{alt}]({src})\n")
                    stats["images"] += 1

        # Код
        if self.options.include_code_blocks:
            for pre in tree.css('pre'):
                code = pre.text()
                if code and code.strip():
                    # Визначаємо мову
                    code_elem = pre.css_first('code')
                    lang = ""
                    if code_elem:
                        classes = code_elem.attributes.get('class', '')
                        if 'language-' in classes:
                            lang = classes.split('language-')[1].split()[0]
                    md_parts.append(f"\n```{lang}\n{code.strip()}\n```\n")
                    stats["code"] += 1

        markdown = "\n".join(md_parts)

        if self.options.normalize_whitespace:
            markdown = re.sub(r"\n{3,}", "\n\n", markdown)
            markdown = markdown.strip()

        return markdown, stats

    def _extract_title_selectolax(self, tree) -> str:
        """Витягує title з selectolax дерева."""
        title_node = tree.css_first('title')
        return title_node.text(strip=True) if title_node else ""

    def _extract_h1_selectolax(self, tree) -> str:
        """Витягує перший H1 з selectolax дерева."""
        h1_node = tree.css_first('h1')
        return h1_node.text(strip=True) if h1_node else ""

    def _extract_description_selectolax(self, tree) -> str:
        """Витягує meta description з selectolax дерева."""
        meta = tree.css_first('meta[name="description"]')
        if meta:
            return meta.attributes.get('content', '')
        og_meta = tree.css_first('meta[property="og:description"]')
        if og_meta:
            return og_meta.attributes.get('content', '')
        return ""

    def _extract_text_selectolax(self, tree) -> str:
        """Витягує чистий текст з selectolax дерева."""
        body = tree.css_first('body') or tree.root
        raw = body.text(separator=' ', strip=True) if body else ""
        if self.options.normalize_whitespace:
            return " ".join(raw.split())
        return raw

    def generate_from_adapter(self, adapter: Any) -> MarkdownResult:
        """
        Генерує Markdown з BaseTreeAdapter.

        Оптимальний метод - дерево вже парсоване!

        Args:
            adapter: BaseTreeAdapter instance

        Returns:
            MarkdownResult
        """
        try:
            tree = adapter.tree
            if hasattr(tree, "find_all"):  # BeautifulSoup
                html_str = str(tree)
                return self._process_soup(tree, html_str)
            elif hasattr(tree, "cssselect"):  # lxml
                return self._process_lxml(tree)
            else:
                # Fallback: витягуємо текст через adapter
                text = adapter.text if hasattr(adapter, "text") else ""
                return MarkdownResult(text=text, fit_markdown=text)

        except (ValueError, AttributeError, TypeError) as e:
            logger.error("Error generating markdown from adapter: %s", e)
            return MarkdownResult.empty()

    def _process_soup(self, soup, original_html: str) -> MarkdownResult:
        """
        Обробляє BeautifulSoup дерево.

        Args:
            soup: BeautifulSoup object
            original_html: Оригінальний HTML для raw_markdown

        Returns:
            MarkdownResult
        """
        BeautifulSoup = _get_bs4()

        # 1. Витягуємо метадані ДО очищення
        title = self._extract_title(soup)
        h1 = self._extract_h1(soup)
        description = self._extract_description(soup)

        # 2. Очищуємо soup для fit_markdown
        # ======== VECTOR 1: Оптимізовані проходи ========
        self._remove_noise_optimized(soup)

        # 3. Генеруємо fit_markdown
        fit_markdown, stats = self._soup_to_markdown(soup)

        # 4. Чистий текст
        text = self._extract_text(soup)

        # 5. Застосовуємо dynamic patterns
        # ======== VECTOR 4: Dynamic Noise Patterns ========
        text = self._apply_dynamic_patterns(text)
        fit_markdown = self._apply_dynamic_patterns(fit_markdown)

        # 6. Перевірка довжини
        is_truncated = False
        if len(text) > self.options.max_length:
            text = text[: self.options.max_length]
            is_truncated = True

        # 7. Citations (якщо потрібно) - НА КОПІЇ soup
        md_citations = ""
        references = []
        if self.options.generate_citations:
            citations_soup = BeautifulSoup(original_html, "lxml")
            self._remove_noise_optimized(citations_soup)
            md_citations, references = self._generate_citations(citations_soup)

        # ======== VECTOR 5: Lazy raw_markdown ========
        result = MarkdownResult(
            text=text,
            fit_markdown=fit_markdown,
            markdown_with_citations=md_citations,
            references=references,
            title=title,
            h1=h1,
            description=description,
            word_count=len(text.split()),
            char_count=len(text),
            heading_count=stats.get("headings", 0),
            link_count=stats.get("links", 0),
            image_count=stats.get("images", 0),
            is_truncated=is_truncated,
        )
        
        # Встановлюємо дані для lazy generation
        result.set_lazy_raw_markdown(original_html, self)
        
        return result

    def _generate_raw_markdown(self, html: str) -> str:
        """
        Генерує raw_markdown з HTML (для lazy generation).
        Видаляє тільки scripts, зберігає весь інший контент.
        
        Args:
            html: Оригінальний HTML
            
        Returns:
            Raw markdown string
        """
        BeautifulSoup = _get_bs4()
        
        try:
            raw_soup = BeautifulSoup(html, "lxml")
        except ImportError:
            raw_soup = BeautifulSoup(html, "html.parser")
            
        self._remove_scripts_only(raw_soup)
        raw_markdown, _ = self._soup_to_markdown(raw_soup)
        return raw_markdown

    def _process_lxml(self, tree) -> MarkdownResult:
        """
        Обробляє lxml дерево.

        Args:
            tree: lxml.html.HtmlElement

        Returns:
            MarkdownResult
        """
        try:
            from lxml import html

            html_str = html.tostring(tree, encoding="unicode")
            return self.generate_from_html(html_str)
        except ImportError:
            logger.error("lxml not available for processing")
            return MarkdownResult.empty()

    def _remove_scripts_only(self, soup) -> None:
        """
        Видаляє тільки технічні теги (scripts, styles).

        Для raw_markdown - зберігаємо весь контент крім скриптів.

        Args:
            soup: BeautifulSoup object
        """
        for tag_name in ("script", "style", "noscript", "template"):
            for tag in soup.find_all(tag_name):
                tag.decompose()

    def _remove_noise_optimized(self, soup) -> None:
        """
        ======== VECTOR 1: Оптимізовані проходи ========
        
        Видаляє noise елементи з soup оптимізовано.
        Групує видалення по типах для мінімізації проходів.

        Args:
            soup: BeautifulSoup object
        """
        # Прохід 1: Великі блоки (мають багато вкладень, видаляємо разом)
        heavy_tags = list(self.options.noise_tags)
        for tag in soup.find_all(heavy_tags):
            tag.decompose()

        # Прохід 2: Структурні елементи (якщо опції дозволяють)
        structural = []
        if self.options.remove_nav:
            structural.append('nav')
        if self.options.remove_header:
            structural.append('header')
        if self.options.remove_footer:
            structural.append('footer')
        if self.options.remove_aside:
            structural.append('aside')
        if self.options.remove_buttons:
            structural.append('button')
        if self.options.remove_forms:
            structural.append('form')

        if structural:
            for tag in soup.find_all(structural):
                tag.decompose()

        # Прохід 3: По класам/id (один прохід з фільтром)
        if self.options.remove_ads:
            def should_remove(tag):
                if not hasattr(tag, "get") or tag.get is None:
                    return False
                try:
                    # Перевірка класів
                    classes = tag.get("class", [])
                    if classes:
                        class_set = {c.lower() for c in classes}
                        if class_set & self.options.noise_classes:
                            return True
                    # Перевірка ID
                    tag_id = tag.get("id", "")
                    if tag_id:
                        id_lower = tag_id.lower()
                        if id_lower in self.options.noise_ids:
                            return True
                except (AttributeError, TypeError):
                    return False
                return False

            for tag in soup.find_all(
                lambda t: hasattr(t, "get") and (t.get("class") or t.get("id"))
            ):
                if should_remove(tag):
                    tag.decompose()

    def _apply_dynamic_patterns(self, text: str) -> str:
        """
        ======== VECTOR 4: Dynamic Noise Patterns ========
        
        Видаляє текст по regex патернам.
        
        Args:
            text: Текст для очищення
            
        Returns:
            Очищений текст
        """
        if not self.options.dynamic_noise_patterns:
            return text

        for pattern in self.options.dynamic_noise_patterns:
            try:
                text = re.sub(pattern, '', text)
            except re.error as e:
                logger.warning("Invalid regex pattern '%s': %s", pattern, e)

        # Нормалізуємо пробіли після видалення
        if self.options.normalize_whitespace:
            return ' '.join(text.split())
        return text

    def _soup_to_markdown(self, soup) -> tuple[str, dict[str, int]]:
        """
        Конвертує BeautifulSoup дерево в Markdown.

        Використовує set для відстеження оброблених елементів
        щоб уникнути дублювання.

        Args:
            soup: BeautifulSoup object

        Returns:
            tuple[markdown_string, stats_dict]
        """
        md_parts = []
        stats = {"headings": 0, "links": 0, "images": 0, "code": 0, "lists": 0}
        processed_elements = set()

        # Обробляємо весь body, включаючи aside, sidebar та інші елементи
        root = soup.find("body") or soup

        # Обробляємо елементи в порядку появи
        for element in root.descendants:
            if not hasattr(element, "name") or element.name is None:
                continue

            # Пропускаємо вже оброблені елементи
            elem_id = id(element)
            if elem_id in processed_elements:
                continue

            tag_name = element.name.lower()

            # Заголовки
            if tag_name in ("h1", "h2", "h3", "h4", "h5", "h6"):
                level = int(tag_name[1])
                text = element.get_text(strip=True)
                if text and len(text) >= self.options.min_heading_length:
                    md_parts.append(f"\n{'#' * level} {text}\n")
                    stats["headings"] += 1
                processed_elements.add(elem_id)

            # Параграфи
            elif tag_name == "p":
                text = element.get_text(strip=True)
                if text and len(text) >= self.options.min_paragraph_length:
                    # Обробка inline коду
                    md_text = self._process_inline_elements(element)
                    md_parts.append(f"\n{md_text}\n")
                processed_elements.add(elem_id)

            # Код (блоки)
            elif tag_name == "pre" and self.options.include_code_blocks:
                code = element.get_text()
                if code.strip():
                    # Визначаємо мову
                    code_tag = element.find("code")
                    lang = ""
                    if code_tag:
                        classes = code_tag.get("class", [])
                        for cls in classes:
                            if cls.startswith("language-"):
                                lang = cls[9:]
                                break
                            elif cls.startswith("lang-"):
                                lang = cls[5:]
                                break
                    md_parts.append(f"\n```{lang}\n{code.strip()}\n```\n")
                    stats["code"] += 1
                processed_elements.add(elem_id)
                # Маркуємо вкладений code як оброблений
                if code_tag:
                    processed_elements.add(id(code_tag))

            # Списки (ul/ol)
            elif tag_name in ("ul", "ol") and self.options.include_lists:
                list_md = self._process_list(element, tag_name)
                if list_md:
                    md_parts.append(f"\n{list_md}\n")
                    stats["lists"] += 1
                # Маркуємо всі вкладені елементи як оброблені
                for child in element.descendants:
                    if hasattr(child, "name"):
                        processed_elements.add(id(child))
                processed_elements.add(elem_id)

            # Blockquote
            elif tag_name == "blockquote" and self.options.include_blockquotes:
                text = element.get_text(strip=True)
                if text:
                    lines = text.split("\n")
                    quoted = "\n".join(f"> {line}" for line in lines if line.strip())
                    md_parts.append(f"\n{quoted}\n")
                processed_elements.add(elem_id)

            # Посилання
            elif tag_name == "a" and self.options.include_links:
                href = element.get("href", "")
                if href:
                    stats["links"] += 1

            # Зображення
            elif tag_name == "img" and self.options.include_images:
                src = element.get("src", "")
                alt = element.get("alt", "")
                if src:
                    md_parts.append(f"\n![{alt}]({src})\n")
                    stats["images"] += 1
                processed_elements.add(elem_id)

            # Таблиці
            elif tag_name == "table" and self.options.include_tables:
                table_md = self._table_to_markdown(element)
                if table_md:
                    md_parts.append(f"\n{table_md}\n")
                # Маркуємо всі вкладені елементи
                for child in element.descendants:
                    if hasattr(child, "name"):
                        processed_elements.add(id(child))
                processed_elements.add(elem_id)

            # Контейнери з текстом (div, section, aside, span)
            # Обробляємо тільки якщо містять прямий текст без вкладених блоків
            elif tag_name in ("div", "section", "aside", "span"):
                direct_text_parts = []
                has_block_children = False

                for child in element.children:
                    if child.name is None:
                        # Текстова нода (NavigableString)
                        text = str(child).strip()
                        if text:
                            direct_text_parts.append(text)
                    elif child.name in (
                        "p",
                        "h1",
                        "h2",
                        "h3",
                        "h4",
                        "h5",
                        "h6",
                        "ul",
                        "ol",
                        "table",
                        "pre",
                        "blockquote",
                    ):
                        has_block_children = True
                if direct_text_parts and not has_block_children:
                    text = " ".join(direct_text_parts)
                    if len(text) >= self.options.min_paragraph_length:
                        md_parts.append(f"\n{text}\n")
                    processed_elements.add(elem_id)

        # Очищуємо і об'єднуємо
        markdown = "\n".join(md_parts)

        # Нормалізуємо пробіли
        if self.options.normalize_whitespace:
            markdown = re.sub(r"\n{3,}", "\n\n", markdown)
            markdown = markdown.strip()

        return markdown, stats

    def _process_inline_elements(self, element) -> str:
        """
        Обробляє inline елементи в параграфі (code, strong, em).

        Args:
            element: BeautifulSoup element

        Returns:
            Markdown string з форматуванням
        """
        result = []
        for child in element.children:
            if hasattr(child, "name"):
                if child.name == "code":
                    result.append(f"`{child.get_text()}`")
                elif child.name in ("strong", "b"):
                    result.append(f"**{child.get_text()}**")
                elif child.name in ("em", "i"):
                    result.append(f"*{child.get_text()}*")
                elif child.name == "a" and self.options.include_links:
                    href = child.get("href", "")
                    text = child.get_text(strip=True)
                    if href and text:
                        result.append(f"[{text}]({href})")
                    else:
                        result.append(text)
                else:
                    result.append(child.get_text())
            else:
                # Текстова нода
                result.append(str(child))

        return "".join(result).strip()

    def _process_list(self, element, list_type: str, indent: int = 0) -> str:
        """
        Обробляє список з підтримкою вкладеності.

        Args:
            element: ul або ol елемент
            list_type: 'ul' або 'ol'
            indent: Рівень вкладеності

        Returns:
            Markdown string
        """
        lines = []
        indent_str = "  " * indent

        items = element.find_all("li", recursive=False)
        for i, li in enumerate(items):
            direct_text = ""
            for child in li.children:
                if not hasattr(child, "name"):
                    direct_text += str(child)
                elif child.name not in ("ul", "ol"):
                    direct_text += child.get_text()

            direct_text = " ".join(direct_text.split()).strip()

            if direct_text:
                if list_type == "ol":
                    lines.append(f"{indent_str}{i + 1}. {direct_text}")
                else:
                    lines.append(f"{indent_str}- {direct_text}")

            # Обробляємо вкладені списки
            for nested in li.find_all(["ul", "ol"], recursive=False):
                nested_md = self._process_list(nested, nested.name, indent + 1)
                if nested_md:
                    lines.append(nested_md)

        return "\n".join(lines)

    def _table_to_markdown(self, table) -> str:
        """
        Конвертує HTML таблицю в Markdown.

        Args:
            table: BeautifulSoup table element

        Returns:
            Markdown string
        """
        rows = []
        header_found = False

        # Спочатку шукаємо header в thead
        thead = table.find("thead")
        if thead:
            header_row = thead.find("tr")
            if header_row:
                cells = [th.get_text(strip=True) for th in header_row.find_all(["th", "td"])]
                if cells:
                    rows.append("| " + " | ".join(cells) + " |")
                    rows.append("| " + " | ".join(["---"] * len(cells)) + " |")
                    header_found = True

        # Body
        tbody = table.find("tbody") or table
        all_trs = tbody.find_all("tr")

        for _idx, tr in enumerate(all_trs):
            # Пропускаємо header rows з thead
            if tr.parent and tr.parent.name == "thead":
                continue

            cells = [td.get_text(strip=True) for td in tr.find_all(["td", "th"])]
            if not cells:
                continue
            if not header_found and not rows:
                if tr.find("th"):
                    rows.append("| " + " | ".join(cells) + " |")
                    rows.append("| " + " | ".join(["---"] * len(cells)) + " |")
                    header_found = True
                else:
                    rows.append(
                        "| " + " | ".join([f"Col {i + 1}" for i in range(len(cells))]) + " |"
                    )
                    rows.append("| " + " | ".join(["---"] * len(cells)) + " |")
                    rows.append("| " + " | ".join(cells) + " |")
                    header_found = True
            else:
                rows.append("| " + " | ".join(cells) + " |")

        return "\n".join(rows)

    def _extract_text(self, soup) -> str:
        """
        Витягує чистий текст з soup.

        Args:
            soup: BeautifulSoup object

        Returns:
            Clean text string
        """
        raw = soup.get_text(separator=" ", strip=True)

        if self.options.normalize_whitespace:
            return " ".join(raw.split())
        return raw

    def _extract_title(self, soup) -> str:
        """Витягує title."""
        title_tag = soup.find("title")
        return title_tag.get_text(strip=True) if title_tag else ""

    def _extract_h1(self, soup) -> str:
        """Витягує перший H1."""
        h1_tag = soup.find("h1")
        return h1_tag.get_text(strip=True) if h1_tag else ""

    def _extract_description(self, soup) -> str:
        """Витягує meta description."""
        meta = soup.find("meta", attrs={"name": "description"})
        if meta:
            return meta.get("content", "")

        # Fallback: og:description
        og_meta = soup.find("meta", attrs={"property": "og:description"})
        if og_meta:
            return og_meta.get("content", "")

        return ""

    def _generate_citations(self, soup) -> tuple[str, list[dict[str, str]]]:
        """
        Генерує Markdown з citations [1], [2].

        Працює на копії soup, не модифікує оригінал.

        Args:
            soup: BeautifulSoup object (копія)

        Returns:
            tuple[markdown_with_citations, references_list]
        """
        references = []
        ref_counter = 1

        # Знаходимо всі посилання
        for a in soup.find_all("a", href=True):
            href = a.get("href", "")
            text = a.get_text(strip=True)

            if href and text and not href.startswith("#"):
                references.append(
                    {
                        "id": ref_counter,
                        "text": text,
                        "url": href,
                    }
                )
                # Замінюємо посилання на citation
                a.replace_with(f"{text} [{ref_counter}]")
                ref_counter += 1

        # Генеруємо markdown
        md, _ = self._soup_to_markdown(soup)

        # Додаємо references в кінці
        if references:
            md += "\n\n## References\n\n"
            for ref in references:
                md += f"[{ref['id']}] {ref['url']}\n"

        return md, references


# Async версія для асинхронного використання
async def generate_markdown_async(
    html: str,
    options: MarkdownOptions | None = None,
) -> MarkdownResult:
    """
    Асинхронна генерація Markdown.

    Виконується в thread executor для non-blocking операції.
    Сумісно з Python 3.9+.

    Args:
        html: HTML string
        options: MarkdownOptions (опціонально)

    Returns:
        MarkdownResult
    """
    import asyncio

    generator = MarkdownGenerator(options)

    # Python 3.9+ compatible
    try:
        # Preferred method for Python 3.9+
        return await asyncio.to_thread(generator.generate_from_html, html)
    except AttributeError:
        # Fallback for older Python versions
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None,
            generator.generate_from_html,
            html,
        )
