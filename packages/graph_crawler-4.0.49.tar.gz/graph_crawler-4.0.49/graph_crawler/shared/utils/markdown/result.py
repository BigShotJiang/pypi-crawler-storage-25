"""Markdown Generation Result.

Pydantic модель для результату генерації Markdown.
Консистентно з іншими моделями проекту (ExtractedArticle).
"""

from typing import Any, TYPE_CHECKING

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr

if TYPE_CHECKING:
    from graph_crawler.shared.utils.markdown.generator import MarkdownGenerator


class MarkdownResult(BaseModel):
    """
    Результат генерації Markdown.

    Містить різні варіанти тексту для різних use cases:
    - text: Чистий текст (для пошуку, word count)
    - raw_markdown: Повний MD з усім контентом (LAZY - генерується на запит)
    - fit_markdown: Очищений MD (без nav, footer, ads) - ОСНОВНИЙ
    - markdown_with_citations: MD з посиланнями [1], [2]

    Приклад:
        >>> result = md_generator.generate(html)
        >>> print(result.text)           # Чистий текст
        >>> print(result.fit_markdown)   # Очищений Markdown
        >>> print(result.word_count)     # Кількість слів
    """

    model_config = ConfigDict(
        frozen=False,  # Дозволяємо модифікацію після створення
        validate_assignment=True,
    )

    # Основні варіанти тексту
    text: str = Field(default="", description="Чистий текст без форматування")
    fit_markdown: str = Field(default="", description="Очищений MD (основний output)")

    # ======== VECTOR 5: Lazy raw_markdown ========
    # raw_markdown тепер lazy - генерується тільки якщо запитують
    _raw_markdown: str | None = PrivateAttr(default=None)
    _raw_html: str | None = PrivateAttr(default=None)
    _generator_ref: Any = PrivateAttr(default=None)

    # Citations (опціонально)
    markdown_with_citations: str = Field(default="", description="MD з [1], [2] посиланнями")
    references: list[dict[str, Any]] = Field(default_factory=list, description="Список посилань")

    # Метадані
    title: str = Field(default="", description="Title сторінки")
    h1: str = Field(default="", description="Перший H1 заголовок")
    description: str = Field(default="", description="Meta description")

    # Статистика
    word_count: int = Field(default=0, ge=0, description="Кількість слів")
    char_count: int = Field(default=0, ge=0, description="Кількість символів")
    heading_count: int = Field(default=0, ge=0, description="Кількість заголовків")
    link_count: int = Field(default=0, ge=0, description="Кількість посилань")
    image_count: int = Field(default=0, ge=0, description="Кількість зображень")

    # Флаги
    is_truncated: bool = Field(default=False, description="Чи був обрізаний текст")

    def model_post_init(self, __context) -> None:
        """Обчислює статистику після створення."""
        if self.text and not self.word_count:
            object.__setattr__(self, "word_count", len(self.text.split()))
        if self.text and not self.char_count:
            object.__setattr__(self, "char_count", len(self.text))

    @property
    def raw_markdown(self) -> str:
        """
        Lazy generation - генерує raw_markdown тільки якщо запитують.
        
        Це економить час та пам'ять, якщо raw_markdown не потрібен.
        """
        if self._raw_markdown is None:
            if self._raw_html and self._generator_ref:
                # Генеруємо raw_markdown з оригінального HTML
                self._raw_markdown = self._generator_ref._generate_raw_markdown(self._raw_html)
            else:
                self._raw_markdown = ""
        return self._raw_markdown
    
    @raw_markdown.setter
    def raw_markdown(self, value: str) -> None:
        """Setter для прямого встановлення raw_markdown."""
        self._raw_markdown = value

    def set_lazy_raw_markdown(self, raw_html: str, generator: "MarkdownGenerator") -> None:
        """
        Встановлює дані для lazy генерації raw_markdown.
        
        Args:
            raw_html: Оригінальний HTML для генерації
            generator: MarkdownGenerator instance
        """
        self._raw_html = raw_html
        self._generator_ref = generator

    def to_dict(self) -> dict:
        """Конвертує в dictionary (alias для model_dump)."""
        data = self.model_dump()
        # Додаємо raw_markdown (може запустити lazy generation)
        data["raw_markdown"] = self.raw_markdown
        return data

    @classmethod
    def empty(cls) -> "MarkdownResult":
        """Повертає порожній результат."""
        return cls()

    def __bool__(self) -> bool:
        """Перевірка чи є контент."""
        return bool(self.text or self.fit_markdown)

    def __repr__(self) -> str:
        return f"MarkdownResult(words={self.word_count}, chars={self.char_count}, truncated={self.is_truncated})"
