"""
User-Agent Rotation Module.

Ця версія використовує EnterpriseUAGenerator для генерації актуальних User-Agents
з підтримкою Client Hints та реалістичних fingerprints.

Замінено застарілу fake-useragent бібліотеку (база даних з 2018!).
"""
from __future__ import annotations

import logging
import random
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from graph_crawler.shared.utils.enterprise_ua_generator import (
    EnterpriseUAGenerator,
    generate_realistic_ua,
)

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class UserAgentStats:
    """Статистика використання User-Agent"""

    total_requests: int = 0
    unique_user_agents: set = field(default_factory=set)
    last_used: str | None = None
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class UserAgentRotator:
    """
    User-Agent Rotator з використанням EnterpriseUAGenerator.

    Переваги над fake-useragent:
    - Актуальні версії браузерів (Chrome 131, Firefox 133 і т.д.)
    - Client Hints підтримка (Sec-CH-UA headers)
    - Консистентність headers (UA ↔ Sec-CH-UA ↔ Accept-Encoding)
    - Weighted distribution за реальною статистикою

    Args:
        browsers: Список браузерів для ротації (опціонально)
        rotation_strategy: Стратегія ("random", "round_robin", "weighted")
        fallback: Fallback User-Agent якщо генератор не працює

    Example:
        >>> rotator = UserAgentRotator()
        >>> ua = rotator.get_random()
        >>>
        >>> # З повним набором headers
        >>> ua, headers = rotator.get_with_headers()
        >>> requests.get(url, headers=headers)
        >>>
        >>> # Конкретний браузер
        >>> ua = rotator.get_chrome()
    """

    def __init__(
        self,
        browsers: list[str | None] = None,
        rotation_strategy: str = "weighted",  # Змінено default на weighted
        fallback: str | None = None,
    ):
        """Ініціалізує UserAgentRotator"""
        self.browsers = browsers or ["chrome", "firefox", "safari", "edge"]
        self.rotation_strategy = rotation_strategy

        # Fallback User-Agent (актуальний Chrome)
        self.fallback = fallback or (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        )

        # Ініціалізація EnterpriseUAGenerator
        try:
            self.generator = EnterpriseUAGenerator(
                strategy=rotation_strategy if rotation_strategy == "weighted" else "random"
            )
            logger.info("UserAgentRotator ініціалізовано з EnterpriseUAGenerator")
        except Exception as e:
            logger.warning("Помилка EnterpriseUAGenerator: %s. Використовую fallback.", e)
            self.generator = None

        # Статистика
        self.stats = UserAgentStats()

        # Round-robin state
        self._round_robin_index = 0
        self._lock = threading.Lock()

    def get_random(self) -> str:
        """
        Отримати випадковий User-Agent.

        Returns:
            str: Випадковий User-Agent
        """
        try:
            if self.generator is None:
                ua_string = self.fallback
            else:
                ua_string, _ = self.generator.generate()

            self._update_stats(ua_string)
            return ua_string

        except Exception as e:
            logger.warning("Помилка: %s. Використовую fallback.", e)
            self._update_stats(self.fallback)
            return self.fallback

    def get_with_headers(self) -> tuple[str, dict[str, str]]:
        """
        Отримати User-Agent з повним набором headers.

        Включає Client Hints та всі необхідні headers для обходу anti-bot.

        Returns:
            tuple[str, dict[str, str]]: (user_agent, headers_dict)

        Example:
            >>> ua, headers = rotator.get_with_headers()
            >>> response = requests.get(url, headers=headers)
        """
        try:
            if self.generator is None:
                return self.fallback, {"User-Agent": self.fallback}

            ua_string, headers = self.generator.generate()
            self._update_stats(ua_string)
            return ua_string, headers

        except Exception as e:
            logger.warning("Помилка: %s. Використовую fallback.", e)
            self._update_stats(self.fallback)
            return self.fallback, {"User-Agent": self.fallback}

    def get_chrome(self) -> str:
        """Отримати Chrome User-Agent"""
        return self._get_browser_ua("chrome")

    def get_firefox(self) -> str:
        """Отримати Firefox User-Agent"""
        return self._get_browser_ua("firefox")

    def get_safari(self) -> str:
        """Отримати Safari User-Agent"""
        return self._get_browser_ua("safari")

    def get_edge(self) -> str:
        """Отримати Edge User-Agent"""
        return self._get_browser_ua("edge")

    def _get_browser_ua(self, browser: str) -> str:
        """Внутрішній метод для отримання UA конкретного браузера"""
        try:
            if self.generator is None:
                return self.fallback

            ua_string, _ = self.generator.generate(browser=browser)
            self._update_stats(ua_string)
            return ua_string

        except Exception as e:
            logger.warning("Помилка браузера %s: %s", browser, e)
            self._update_stats(self.fallback)
            return self.fallback

    def get_browser_with_headers(self, browser: str) -> tuple[str, dict[str, str]]:
        """
        Отримати UA конкретного браузера з повними headers.

        Args:
            browser: Назва браузера ("chrome", "firefox", "safari", "edge")

        Returns:
            tuple[str, dict[str, str]]: (user_agent, headers_dict)
        """
        try:
            if self.generator is None:
                return self.fallback, {"User-Agent": self.fallback}

            ua_string, headers = self.generator.generate(browser=browser)
            self._update_stats(ua_string)
            return ua_string, headers

        except Exception as e:
            logger.warning("Помилка браузера %s: %s", browser, e)
            self._update_stats(self.fallback)
            return self.fallback, {"User-Agent": self.fallback}

    def get_next(self) -> str:
        """
        Отримати наступний User-Agent згідно стратегії.

        Returns:
            str: User-Agent рядок
        """
        if self.rotation_strategy == "random":
            return self.get_random()

        elif self.rotation_strategy == "round_robin":
            return self._get_round_robin()

        elif self.rotation_strategy == "weighted":
            return self.get_random()  # EnterpriseUAGenerator вже підтримує weighted

        else:
            return self.get_random()

    def _get_round_robin(self) -> str:
        """Round-robin вибір User-Agent"""
        with self._lock:
            browser = self.browsers[self._round_robin_index]
            self._round_robin_index = (self._round_robin_index + 1) % len(self.browsers)

        return self._get_browser_ua(browser)

    def _update_stats(self, ua_string: str):
        """Оновити статистику"""
        with self._lock:
            self.stats.total_requests += 1
            self.stats.unique_user_agents.add(ua_string)
            self.stats.last_used = ua_string

    def get_statistics(self) -> dict[str, Any]:
        """
        Отримати статистику використання.

        Returns:
            Dict: Словник зі статистикою
        """
        with self._lock:
            uptime = (datetime.now(timezone.utc) - self.stats.started_at).total_seconds()

            return {
                "total_requests": self.stats.total_requests,
                "unique_user_agents": len(self.stats.unique_user_agents),
                "last_used": self.stats.last_used,
                "uptime_seconds": uptime,
                "requests_per_second": (self.stats.total_requests / uptime if uptime > 0 else 0),
            }

    def get_summary(self) -> str:
        """Текстовий summary статистики"""
        stats = self.get_statistics()

        return f"""
User-Agent Rotator Summary (Enterprise)
{"=" * 50}

Statistics:
  - Total requests: {stats["total_requests"]}
  - Unique UAs: {stats["unique_user_agents"]}
  - Rate: {stats["requests_per_second"]:.2f} req/sec
  - Uptime: {stats["uptime_seconds"]:.1f}s

Last Used:
  {stats["last_used"][:80] if stats["last_used"] else "None"}...

Configuration:
  - Strategy: {self.rotation_strategy}
  - Browsers: {", ".join(self.browsers)}
  - Generator: EnterpriseUAGenerator (актуальні версії)
"""

    def reset_statistics(self):
        """Скинути статистику"""
        with self._lock:
            self.stats = UserAgentStats()
            logger.info("Статистика скинута")

    def validate_ua_consistency(self, ua: str, headers: dict[str, str]) -> bool:
        """
        Перевіряє консистентність UA і headers.

        Корисно для тестування та debug.

        Args:
            ua: User-Agent рядок
            headers: Словник headers

        Returns:
            bool: True якщо консистентні
        """
        if self.generator is None:
            return True
        return self.generator.validate_consistency(ua, headers)


def create_rotator(
    browsers: list[str | None] = None, strategy: str = "weighted"
) -> UserAgentRotator:
    """
    Factory функція для швидкого створення rotator.

    Args:
        browsers: Список браузерів
        strategy: Стратегія ротації ("random", "weighted", "round_robin")

    Returns:
        UserAgentRotator

    Example:
        >>> rotator = create_rotator(browsers=["chrome", "firefox"])
        >>> ua = rotator.get_random()
        >>>
        >>> # З headers для anti-bot обходу
        >>> ua, headers = rotator.get_with_headers()
    """
    return UserAgentRotator(browsers=browsers, rotation_strategy=strategy)


# Швидкий доступ до генерації
def get_realistic_ua() -> str:
    """
    Швидкий доступ до реалістичного User-Agent.

    Returns:
        str: Актуальний реалістичний User-Agent
    """
    ua, _ = generate_realistic_ua()
    return ua


def get_realistic_headers() -> dict[str, str]:
    """
    Швидкий доступ до повного набору headers.

    Returns:
        dict[str, str]: Headers з UA, Client Hints і т.д.
    """
    _, headers = generate_realistic_ua()
    return headers
