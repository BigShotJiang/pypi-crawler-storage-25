"""Утиліти сумісності asyncio для Python 3.12+.

Python 3.12+ deprecates asyncio.get_event_loop() без running loop.
Цей модуль надає безпечні обгортки.

Використання:
    # В async функціях:
    from graph_crawler.shared.utils.async_compat import get_loop
    loop = get_loop()  # Безпечно для 3.12+

    # Для sync→async wrapper:
    from graph_crawler.shared.utils.async_compat import run_sync
    result = run_sync(async_func())

Міграція:
    # БУЛО (deprecated в 3.12+):
    loop = asyncio.get_event_loop()
    loop.run_until_complete(coro)

    # СТАЛО:
    from graph_crawler.shared.utils.async_compat import run_sync
    result = run_sync(coro)
"""

import asyncio
import sys
from typing import Any, Coroutine, TypeVar

T = TypeVar("T")

# Python version check
_PY312_PLUS = sys.version_info >= (3, 12)


def get_loop() -> asyncio.AbstractEventLoop:
    """
    Отримує event loop безпечно для Python 3.12+.

    В async контексті повертає running loop.
    Поза async контекстом створює новий loop (для backward compat).

    Returns:
        asyncio.AbstractEventLoop

    Example:
        >>> async def my_func():
        ...     loop = get_loop()
        ...     await loop.run_in_executor(None, blocking_func)
    """
    try:
        # Спочатку пробуємо отримати running loop (async контекст)
        return asyncio.get_running_loop()
    except RuntimeError:
        # Немає running loop - ми в sync контексті
        if _PY312_PLUS:
            # Python 3.12+: створюємо новий loop
            return asyncio.new_event_loop()
        else:
            # Python 3.11: старий спосіб ще працює
            return asyncio.get_event_loop()


def run_sync(coro: Coroutine[Any, Any, T]) -> T:
    """
    Виконує coroutine синхронно (sync→async wrapper).

    Безпечна заміна для asyncio.get_event_loop().run_until_complete().

    Args:
        coro: Coroutine для виконання

    Returns:
        Результат виконання coroutine

    Example:
        >>> async def fetch_data():
        ...     return {"data": 42}
        >>>
        >>> # Sync wrapper
        >>> def fetch_data_sync():
        ...     return run_sync(fetch_data())

    Note:
        Не викликайте з async контексту - використовуйте await напряму!
    """
    try:
        # Перевіряємо чи є running loop
        loop = asyncio.get_running_loop()
        # Якщо є - ми в async контексті, не можемо run_until_complete
        raise RuntimeError(
            "run_sync() cannot be called from async context. Use 'await' instead."
        )
    except RuntimeError:
        pass

    # Немає running loop - безпечно запускати
    if _PY312_PLUS:
        # Python 3.12+: використовуємо asyncio.run() або новий loop
        try:
            return asyncio.run(coro)
        except RuntimeError:
            # Якщо asyncio.run() не працює (nested), створюємо loop вручну
            loop = asyncio.new_event_loop()
            try:
                asyncio.set_event_loop(loop)
                return loop.run_until_complete(coro)
            finally:
                loop.close()
                asyncio.set_event_loop(None)
    else:
        # Python 3.11: старий спосіб
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(coro)


def ensure_future(coro: Coroutine[Any, Any, T]) -> asyncio.Task[T]:
    """
    Створює Task з coroutine безпечно для Python 3.12+.

    Args:
        coro: Coroutine для обгортання в Task

    Returns:
        asyncio.Task
    """
    try:
        loop = asyncio.get_running_loop()
        return loop.create_task(coro)
    except RuntimeError:
        # Немає running loop
        if _PY312_PLUS:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        else:
            loop = asyncio.get_event_loop()
        return loop.create_task(coro)


__all__ = ["get_loop", "run_sync", "ensure_future"]
