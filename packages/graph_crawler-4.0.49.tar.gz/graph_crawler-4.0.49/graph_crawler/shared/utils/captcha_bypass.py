"""
CAPTCHA Bypass Strategies.

Цей модуль надає різні стратегії для спроби обійти CAPTCHA без використання
платних сервісів розв'язання. Якщо всі стратегії не спрацювали, можна
використовувати fallback на CAPTCHA solver.

Strategies:
1. Cookie Persistence - зберігання cookies між запитами
2. Session Reuse - переіспользування сесій
3. Delay Strategy - очікування перед повторною спробою
4. Alternative Endpoints - пошук API endpoints без CAPTCHA
5. Rotating Strategies - спроба різних підходів по черзі

Async версії методів доступні для неблокуючого виконання.
Використовується JSON (не pickle) для безпечної серіалізації.
fast_json (orjson) забезпечує швидку серіалізацію.
"""
from __future__ import annotations

import asyncio
import hashlib
import json  # For JSONDecodeError
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable

import aiohttp
import requests

from graph_crawler.shared.utils.fast_json import dumps as json_dumps
from graph_crawler.shared.utils.fast_json import loads as json_loads

logger = logging.getLogger(__name__)


class BypassStrategy(str, Enum):
    """Стратегії обходу CAPTCHA."""

    COOKIE_PERSISTENCE = "cookie_persistence"  # Зберігання cookies
    SESSION_REUSE = "session_reuse"  # Переіспользування сесій
    DELAY_STRATEGY = "delay_strategy"  # Очікування
    ALTERNATIVE_ENDPOINTS = "alternative_endpoints"  # Альтернативні endpoints
    ROTATING = "rotating"  # Ротація різних стратегій


class BypassResult(str, Enum):
    """Результати спроби обходу."""

    SUCCESS = "success"  # Успішно обійшли
    FAILED = "failed"  # Не вдалося обійти
    CAPTCHA_STILL_PRESENT = "captcha_still_present"  # CAPTCHA все ще є
    RETRY_NEEDED = "retry_needed"  # Потрібна повторна спроба


@dataclass(slots=True)
class BypassAttempt:
    """Результат спроби обходу CAPTCHA."""

    strategy: BypassStrategy
    result: BypassResult
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    response_status: int | None = None
    response_time: float | None = None
    error_message: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class SessionInfo:
    """Інформація про збережену сесію."""

    url: str
    cookies: dict[str, str]
    headers: dict[str, str]
    created_at: datetime
    last_used: datetime
    success_count: int = 0
    failure_count: int = 0

    def is_expired(self, max_age_hours: int = 24) -> bool:
        """Перевірка чи сесія прострочена."""
        age = datetime.now(timezone.utc) - self.created_at
        return age > timedelta(hours=max_age_hours)

    @property
    def success_rate(self) -> float:
        """Відсоток успішних запитів."""
        total = self.success_count + self.failure_count
        if total == 0:
            return 0.0
        return (self.success_count / total) * 100


class CaptchaBypassManager:
    """
    Менеджер для обходу CAPTCHA з різними стратегіями.

    """

    def __init__(
        self,
        cookie_storage_path: str | None = None,
        session_storage_path: str | None = None,
        max_retry_attempts: int = 3,
        default_delay: float = 5.0,
        min_delay: float = 2.0,
        max_delay: float = 60.0,
        delay_multiplier: float = 2.0,
        session_max_age_hours: int = 24,
        captcha_solver_fallback: Callable | None = None,
    ):
        """
        Ініціалізація менеджера обходу CAPTCHA.

        Args:
            cookie_storage_path: Шлях до папки для зберігання cookies
            session_storage_path: Шлях до папки для зберігання сесій
            max_retry_attempts: Максимальна кількість спроб обходу
            default_delay: Початкова затримка між спробами (секунди)
            min_delay: Мінімальна затримка (секунди)
            max_delay: Максимальна затримка (секунди)
            delay_multiplier: Множник для exponential backoff
            session_max_age_hours: Максимальний вік сесії (години)
            captcha_solver_fallback: Функція для розв'язання CAPTCHA якщо bypass не вдався
        """
        self.cookie_storage_path = Path(cookie_storage_path or "./cookies")
        self.session_storage_path = Path(session_storage_path or "./sessions")
        self.max_retry_attempts = max_retry_attempts
        self.default_delay = default_delay
        self.min_delay = min_delay
        self.max_delay = max_delay
        self.delay_multiplier = delay_multiplier
        self.session_max_age_hours = session_max_age_hours
        self.captcha_solver_fallback = captcha_solver_fallback

        # Створення папок для зберігання
        self.cookie_storage_path.mkdir(parents=True, exist_ok=True)
        self.session_storage_path.mkdir(parents=True, exist_ok=True)

        # Статистика
        self.attempts: list[BypassAttempt] = []
        self.sessions: dict[str, SessionInfo] = {}

        # Порядок стратегій для ротації
        self.strategy_order = [
            BypassStrategy.COOKIE_PERSISTENCE,
            BypassStrategy.SESSION_REUSE,
            BypassStrategy.DELAY_STRATEGY,
            BypassStrategy.ALTERNATIVE_ENDPOINTS,
        ]

        logger.info(
            f"CaptchaBypassManager ініціалізовано: cookie_path={self.cookie_storage_path}, session_path={self.session_storage_path}"
        )

    def _get_domain_hash(self, url: str) -> str:
        """Створити хеш домену для імені файлу."""
        from urllib.parse import urlparse

        domain = urlparse(url).netloc
        return hashlib.md5(domain.encode("utf-8"), usedforsecurity=False).hexdigest()

    def _get_cookie_file_path(self, url: str) -> Path:
        """Отримати шлях до файлу з cookies для домену."""
        domain_hash = self._get_domain_hash(url)
        return self.cookie_storage_path / f"{domain_hash}.cookies.json"

    def _get_session_file_path(self, url: str) -> Path:
        """Отримати шлях до файлу з session для домену."""
        domain_hash = self._get_domain_hash(url)
        return self.session_storage_path / f"{domain_hash}.session.json"

    def save_cookies(self, url: str, cookies: dict[str, str]) -> None:
        """
        Зберегти cookies в файл (JSON - безпечна серіалізація).

        Args:
            url: URL домену
            cookies: Dictionary з cookies
        """
        cookie_file = self._get_cookie_file_path(url)
        try:
            with open(cookie_file, "w", encoding="utf-8") as f:
                f.write(json_dumps(cookies, indent=2))
            logger.info(" Cookies збережено: %s", cookie_file)
        except Exception as e:
            logger.error(" Помилка збереження cookies: %s", e)

    def load_cookies(self, url: str) -> dict[str, str | None]:
        """
        Завантажити cookies з файлу (JSON - безпечна серіалізація).

        Args:
            url: URL домену

        Returns:
            Dictionary з cookies або None якщо файл не існує
        """
        cookie_file = self._get_cookie_file_path(url)
        if not cookie_file.exists():
            logger.debug(" Cookies не знайдено: %s", cookie_file)
            return None

        try:
            with open(cookie_file, "r", encoding="utf-8") as f:
                cookies = json_loads(f.read())
            logger.info(" Cookies завантажено: %s (%s items)", cookie_file, len(cookies))
            return cookies
        except Exception as e:
            logger.error(" Помилка завантаження cookies: %s", e)
            return None

    def save_session(self, url: str, session_info: SessionInfo) -> None:
        """
        Зберегти сесію в файл (JSON - безпечна серіалізація).

        Args:
            url: URL домену
            session_info: Інформація про сесію
        """
        session_file = self._get_session_file_path(url)
        try:
            with open(session_file, "w", encoding="utf-8") as f:
                f.write(json_dumps(session_info.to_dict(), indent=2))
            logger.info(" Session збережено: %s", session_file)
        except Exception as e:
            logger.error(" Помилка збереження session: %s", e)

    def load_session(self, url: str) -> SessionInfo | None:
        """
        Завантажити сесію з файлу (JSON - безпечна серіалізація).

        Args:
            url: URL домену

        Returns:
            SessionInfo або None якщо файл не існує або сесія прострочена
        """
        session_file = self._get_session_file_path(url)
        if not session_file.exists():
            logger.debug(" Session не знайдено: %s", session_file)
            return None

        try:
            with open(session_file, "r", encoding="utf-8") as f:
                data = json_loads(f.read())
            session_info = SessionInfo.from_dict(data)

            # Перевірка чи не прострочена сесія
            if session_info.is_expired(self.session_max_age_hours):
                logger.warning(" Session прострочена: %s", session_file)
                session_file.unlink()  # Видалити прострочену сесію
                return None

            logger.info(
                f" Session завантажено: {session_file} (success_rate={session_info.success_rate:.1f}%)"
            )
            return session_info
        except Exception as e:
            logger.error(" Помилка завантаження session: %s", e)
            return None

    def try_cookie_persistence(self, url: str, **request_kwargs) -> BypassAttempt:
        """
        Спроба обходу через збережені cookies.

        Args:
            url: URL для запиту
            **request_kwargs: Додаткові параметри для requests

        Returns:
            BypassAttempt з результатом
        """
        logger.info(" Спроба обходу через Cookie Persistence: %s", url)

        # Завантажити збережені cookies
        cookies = self.load_cookies(url)
        if not cookies:
            return BypassAttempt(
                strategy=BypassStrategy.COOKIE_PERSISTENCE,
                result=BypassResult.FAILED,
                error_message="No saved cookies found",
            )

        # Спроба запиту з cookies
        start_time = time.time()
        try:
            response = requests.get(url, cookies=cookies, timeout=30, **request_kwargs)
            response_time = time.time() - start_time

            # Перевірка чи є CAPTCHA в response
            has_captcha = self._detect_captcha_in_response(response)

            if not has_captcha and response.status_code == 200:
                logger.info("Cookie Persistence успішно: %s", url)
                return BypassAttempt(
                    strategy=BypassStrategy.COOKIE_PERSISTENCE,
                    result=BypassResult.SUCCESS,
                    response_status=response.status_code,
                    response_time=response_time,
                    metadata={"cookies_count": len(cookies)},
                )
            else:
                logger.warning(" CAPTCHA все ще присутня після Cookie Persistence")
                return BypassAttempt(
                    strategy=BypassStrategy.COOKIE_PERSISTENCE,
                    result=BypassResult.CAPTCHA_STILL_PRESENT,
                    response_status=response.status_code,
                    response_time=response_time,
                )

        except Exception as e:
            logger.error(" Помилка Cookie Persistence: %s", e)
            return BypassAttempt(
                strategy=BypassStrategy.COOKIE_PERSISTENCE,
                result=BypassResult.FAILED,
                error_message=str(e),
            )

    def try_session_reuse(self, url: str, **request_kwargs) -> BypassAttempt:
        """
        Спроба обходу через переіспользування сесії.

        Args:
            url: URL для запиту
            **request_kwargs: Додаткові параметри для requests

        Returns:
            BypassAttempt з результатом
        """
        logger.info(" Спроба обходу через Session Reuse: %s", url)

        # Завантажити збережену сесію
        session_info = self.load_session(url)
        if not session_info:
            return BypassAttempt(
                strategy=BypassStrategy.SESSION_REUSE,
                result=BypassResult.FAILED,
                error_message="No saved session found or session expired",
            )

        # Спроба запиту з session headers та cookies
        start_time = time.time()
        try:
            headers = {**session_info.headers, **request_kwargs.get("headers", {})}
            response = requests.get(
                url,
                cookies=session_info.cookies,
                headers=headers,
                timeout=30,
                **{k: v for k, v in request_kwargs.items() if k != "headers"},
            )
            response_time = time.time() - start_time

            has_captcha = self._detect_captcha_in_response(response)

            if not has_captcha and response.status_code == 200:
                logger.info("Session Reuse успішно: %s", url)
                # Оновити статистику сесії
                session_info.last_used = datetime.now(timezone.utc)
                session_info.success_count += 1
                self.save_session(url, session_info)

                return BypassAttempt(
                    strategy=BypassStrategy.SESSION_REUSE,
                    result=BypassResult.SUCCESS,
                    response_status=response.status_code,
                    response_time=response_time,
                    metadata={"session_success_rate": session_info.success_rate},
                )
            else:
                logger.warning(" CAPTCHA все ще присутня після Session Reuse")
                session_info.failure_count += 1
                self.save_session(url, session_info)

                return BypassAttempt(
                    strategy=BypassStrategy.SESSION_REUSE,
                    result=BypassResult.CAPTCHA_STILL_PRESENT,
                    response_status=response.status_code,
                    response_time=response_time,
                )

        except Exception as e:
            logger.error(" Помилка Session Reuse: %s", e)
            return BypassAttempt(
                strategy=BypassStrategy.SESSION_REUSE,
                result=BypassResult.FAILED,
                error_message=str(e),
            )

    def try_delay_strategy(self, url: str, retry_count: int = 0, **request_kwargs) -> BypassAttempt:
        """
        Спроба обходу через очікування (delay with exponential backoff).

        Іноді CAPTCHA автоматично зникає після очікування.

        WARNING: Ця sync версія блокує event loop. Для async контексту
        використовуйте try_delay_strategy_async().

        Args:
            url: URL для запиту
            retry_count: Номер поточної спроби (для backoff)
            **request_kwargs: Додаткові параметри для requests

        Returns:
            BypassAttempt з результатом
        """
        # Розрахувати затримку (exponential backoff)
        delay = min(self.default_delay * (self.delay_multiplier**retry_count), self.max_delay)
        delay = max(delay, self.min_delay)

        logger.info(
            f"⏰ Спроба обходу через Delay Strategy: {url} (delay={delay:.1f}s, attempt={retry_count + 1})"
        )

        # Очікування (sync - блокуюче)
        time.sleep(delay)

        # Спроба запиту після затримки
        start_time = time.time()
        try:
            response = requests.get(url, timeout=30, **request_kwargs)
            response_time = time.time() - start_time

            has_captcha = self._detect_captcha_in_response(response)

            if not has_captcha and response.status_code == 200:
                logger.info("Delay Strategy успішно після %.1fs очікування", delay)
                return BypassAttempt(
                    strategy=BypassStrategy.DELAY_STRATEGY,
                    result=BypassResult.SUCCESS,
                    response_status=response.status_code,
                    response_time=response_time,
                    metadata={"delay_seconds": delay, "retry_count": retry_count},
                )
            else:
                logger.warning(" CAPTCHA все ще присутня після %.1fs очікування", delay)

                # Перевірити чи потрібна повторна спроба
                if retry_count < self.max_retry_attempts - 1:
                    return BypassAttempt(
                        strategy=BypassStrategy.DELAY_STRATEGY,
                        result=BypassResult.RETRY_NEEDED,
                        response_status=response.status_code,
                        response_time=response_time,
                        metadata={"delay_seconds": delay, "retry_count": retry_count},
                    )
                else:
                    return BypassAttempt(
                        strategy=BypassStrategy.DELAY_STRATEGY,
                        result=BypassResult.CAPTCHA_STILL_PRESENT,
                        response_status=response.status_code,
                        response_time=response_time,
                        metadata={"delay_seconds": delay, "retry_count": retry_count},
                    )

        except Exception as e:
            logger.error(" Помилка Delay Strategy: %s", e)
            return BypassAttempt(
                strategy=BypassStrategy.DELAY_STRATEGY,
                result=BypassResult.FAILED,
                error_message=str(e),
                metadata={"delay_seconds": delay, "retry_count": retry_count},
            )

    async def try_delay_strategy_async(
        self, url: str, retry_count: int = 0, **request_kwargs
    ) -> BypassAttempt:
        """
        Async версія спроби обходу через очікування (delay with exponential backoff).

        Використовує asyncio.sleep() для неблокуючого очікування.
        Рекомендовано для async контексту.

        Args:
            url: URL для запиту
            retry_count: Номер поточної спроби (для backoff)
            **request_kwargs: Додаткові параметри для aiohttp

        Returns:
            BypassAttempt з результатом
        """
        # Розрахувати затримку (exponential backoff)
        delay = min(self.default_delay * (self.delay_multiplier**retry_count), self.max_delay)
        delay = max(delay, self.min_delay)

        logger.info(
            f"⏰ Async спроба обходу через Delay Strategy: {url} (delay={delay:.1f}s, attempt={retry_count + 1})"
        )

        # Неблокуюче очікування
        await asyncio.sleep(delay)

        # Спроба запиту після затримки
        start_time = time.time()
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=30, **request_kwargs) as response:
                    response_time = time.time() - start_time
                    response_text = await response.text()

                    # Перевірка чи є CAPTCHA в response
                    has_captcha = self._detect_captcha_in_text(response_text)

                    if not has_captcha and response.status == 200:
                        logger.info("Delay Strategy успішно після %.1fs очікування", delay)
                        return BypassAttempt(
                            strategy=BypassStrategy.DELAY_STRATEGY,
                            result=BypassResult.SUCCESS,
                            response_status=response.status,
                            response_time=response_time,
                            metadata={"delay_seconds": delay, "retry_count": retry_count},
                        )
                    else:
                        logger.warning(" CAPTCHA все ще присутня після %.1fs очікування", delay)

                        # Перевірити чи потрібна повторна спроба
                        if retry_count < self.max_retry_attempts - 1:
                            return BypassAttempt(
                                strategy=BypassStrategy.DELAY_STRATEGY,
                                result=BypassResult.RETRY_NEEDED,
                                response_status=response.status,
                                response_time=response_time,
                                metadata={"delay_seconds": delay, "retry_count": retry_count},
                            )
                        else:
                            return BypassAttempt(
                                strategy=BypassStrategy.DELAY_STRATEGY,
                                result=BypassResult.CAPTCHA_STILL_PRESENT,
                                response_status=response.status,
                                response_time=response_time,
                                metadata={"delay_seconds": delay, "retry_count": retry_count},
                            )

        except Exception as e:
            logger.error(" Помилка Async Delay Strategy: %s", e)
            return BypassAttempt(
                strategy=BypassStrategy.DELAY_STRATEGY,
                result=BypassResult.FAILED,
                error_message=str(e),
                metadata={"delay_seconds": delay, "retry_count": retry_count},
            )

    def _detect_captcha_in_text(self, content: str) -> bool:
        """Простий детектор CAPTCHA в тексті."""
        content_lower = content.lower()
        captcha_keywords = [
            "captcha",
            "recaptcha",
            "hcaptcha",
            "g-recaptcha",
            "h-captcha",
            "cf-captcha",
            "challenge-form",
        ]
        return any(keyword in content_lower for keyword in captcha_keywords)

    def try_alternative_endpoints(
        self, url: str, alternative_urls: list[str | None] = None, **request_kwargs
    ) -> BypassAttempt:
        """
        Спроба обходу через альтернативні endpoints (API без CAPTCHA).

        Деякі сайти мають API endpoints які не захищені CAPTCHA.

        Args:
            url: Основний URL
            alternative_urls: Список альтернативних URL для спроби
            **request_kwargs: Додаткові параметри для requests

        Returns:
            BypassAttempt з результатом
        """
        logger.info(" Спроба обходу через Alternative Endpoints: %s", url)
        if not alternative_urls:
            alternative_urls = self._generate_alternative_urls(url)

        if not alternative_urls:
            return BypassAttempt(
                strategy=BypassStrategy.ALTERNATIVE_ENDPOINTS,
                result=BypassResult.FAILED,
                error_message="No alternative endpoints found",
            )

        # Спроба кожного альтернативного URL
        for alt_url in alternative_urls:
            logger.info(" Спроба альтернативного endpoint: %s", alt_url)
            start_time = time.time()

            try:
                response = requests.get(alt_url, timeout=30, **request_kwargs)
                response_time = time.time() - start_time

                has_captcha = self._detect_captcha_in_response(response)

                if not has_captcha and response.status_code == 200:
                    logger.info("Alternative Endpoint успішно: %s", alt_url)
                    return BypassAttempt(
                        strategy=BypassStrategy.ALTERNATIVE_ENDPOINTS,
                        result=BypassResult.SUCCESS,
                        response_status=response.status_code,
                        response_time=response_time,
                        metadata={
                            "alternative_url": alt_url,
                            "tried_urls": alternative_urls,
                        },
                    )

            except Exception as e:
                logger.debug(" Альтернативний endpoint не спрацював: %s - %s", alt_url, e)
                continue

        logger.warning(" Жоден альтернативний endpoint не спрацював")
        return BypassAttempt(
            strategy=BypassStrategy.ALTERNATIVE_ENDPOINTS,
            result=BypassResult.FAILED,
            error_message="All alternative endpoints failed",
            metadata={"tried_urls": alternative_urls},
        )

    def try_bypass(
        self,
        url: str,
        strategy: BypassStrategy = BypassStrategy.COOKIE_PERSISTENCE,
        **request_kwargs,
    ) -> BypassAttempt:
        """
        Спроба обходу CAPTCHA використовуючи вказану стратегію.

        Args:
            url: URL для запиту
            strategy: Стратегія обходу
            **request_kwargs: Додаткові параметри для requests

        Returns:
            BypassAttempt з результатом
        """
        attempt = None

        if strategy == BypassStrategy.COOKIE_PERSISTENCE:
            attempt = self.try_cookie_persistence(url, **request_kwargs)
        elif strategy == BypassStrategy.SESSION_REUSE:
            attempt = self.try_session_reuse(url, **request_kwargs)
        elif strategy == BypassStrategy.DELAY_STRATEGY:
            attempt = self.try_delay_strategy(url, **request_kwargs)
        elif strategy == BypassStrategy.ALTERNATIVE_ENDPOINTS:
            attempt = self.try_alternative_endpoints(url, **request_kwargs)
        else:
            logger.error(" Невідома стратегія: %s", strategy)
            attempt = BypassAttempt(
                strategy=strategy,
                result=BypassResult.FAILED,
                error_message=f"Unknown strategy: {strategy}",
            )

        # Зберегти спробу в історію
        self.attempts.append(attempt)

        return attempt

    def try_all_strategies(
        self,
        url: str,
        strategies: list[BypassStrategy | None] = None,
        **request_kwargs,
    ) -> BypassAttempt:
        """
        Спроба обходу CAPTCHA використовуючи всі доступні стратегії по черзі.

        Args:
            url: URL для запиту
            strategies: Список стратегій (за замовчуванням використовує всі)
            **request_kwargs: Додаткові параметри для requests

        Returns:
            BypassAttempt з результатом першої успішної стратегії або останньої невдалої
        """
        logger.info(" Спроба всіх стратегій обходу для: %s", url)

        strategies = strategies or self.strategy_order
        last_attempt = None

        for strategy in strategies:
            attempt = self.try_bypass(url, strategy=strategy, **request_kwargs)
            last_attempt = attempt
            if attempt.result == BypassResult.SUCCESS:
                logger.info("Успішний bypass через %s", strategy)
                return attempt
            if attempt.result == BypassResult.RETRY_NEEDED:
                for retry in range(1, self.max_retry_attempts):
                    attempt = self.try_delay_strategy(url, retry_count=retry, **request_kwargs)
                    last_attempt = attempt
                    self.attempts.append(attempt)

                    if attempt.result == BypassResult.SUCCESS:
                        logger.info("Успішний bypass через Delay Strategy після %s спроб", retry + 1)
                        return attempt
        logger.warning(" Всі стратегії обходу не спрацювали для %s", url)

        # Fallback на CAPTCHA solver якщо є
        if self.captcha_solver_fallback:
            logger.info(" Використовую CAPTCHA solver fallback")
            try:
                solver_result = self.captcha_solver_fallback(url, **request_kwargs)
                return BypassAttempt(
                    strategy=BypassStrategy.ROTATING,
                    result=(BypassResult.SUCCESS if solver_result else BypassResult.FAILED),
                    metadata={"used_solver": True, "solver_result": solver_result},
                )
            except Exception as e:
                logger.error(" CAPTCHA solver fallback помилка: %s", e)

        return last_attempt or BypassAttempt(
            strategy=BypassStrategy.ROTATING,
            result=BypassResult.FAILED,
            error_message="All strategies failed",
        )

    def _detect_captcha_in_response(self, response: requests.Response) -> bool:
        """
        Простий детектор CAPTCHA в response.

        Шукає ключові слова: captcha, recaptcha, hcaptcha

        Args:
            response: requests.Response об'єкт

        Returns:
            True якщо CAPTCHA виявлена, False інакше
        """
        content = response.text.lower()

        # Ключові слова CAPTCHA
        captcha_keywords = [
            "captcha",
            "recaptcha",
            "hcaptcha",
            "g-recaptcha",
            "h-captcha",
            "cf-captcha",  # Cloudflare
            "challenge-form",
        ]

        for keyword in captcha_keywords:
            if keyword in content:
                logger.debug(" CAPTCHA виявлено: keyword='%s'", keyword)
                return True

        # Перевірка специфічних status codes
        if response.status_code in [403, 429, 503]:
            logger.debug(" CAPTCHA можлива: status_code=%s", response.status_code)
            # Додаткова перевірка в тексті
            if any(kw in content for kw in ["blocked", "access denied", "too many requests"]):
                return True

        return False

    def _generate_alternative_urls(self, url: str) -> list[str]:
        """
        Згенерувати альтернативні URLs (API endpoints) для спроби.

        Args:
            url: Основний URL

        Returns:
            Список альтернативних URLs
        """
        from urllib.parse import urlparse, urlunparse

        parsed = urlparse(url)
        alternatives = []

        # Спроба додати /api/ prefix
        if "/api/" not in parsed.path:
            new_path = "/api" + parsed.path
            alt_url = urlunparse((parsed.scheme, parsed.netloc, new_path, "", "", ""))
            alternatives.append(alt_url)

        # Спроба змінити розширення на .json
        if not parsed.path.endswith(".json"):
            new_path = parsed.path.rstrip("/") + ".json"
            alt_url = urlunparse((parsed.scheme, parsed.netloc, new_path, "", "", ""))
            alternatives.append(alt_url)

        # Спроба додати /v1/ або /v2/
        for version in ["v1", "v2", "v3"]:
            if f"/{version}/" not in parsed.path:
                new_path = f"/{version}" + parsed.path
                alt_url = urlunparse((parsed.scheme, parsed.netloc, new_path, "", "", ""))
                alternatives.append(alt_url)

        logger.debug(" Згенеровано %s альтернативних URLs", len(alternatives))
        return alternatives

    def get_statistics(self) -> dict[str, Any]:
        """
        Отримати статистику спроб обходу.

        Returns:
            Dictionary зі статистикою
        """
        if not self.attempts:
            return {
                "total_attempts": 0,
                "success_count": 0,
                "failed_count": 0,
                "success_rate": 0.0,
                "by_strategy": {},
            }

        total = len(self.attempts)
        success_count = sum(1 for a in self.attempts if a.result == BypassResult.SUCCESS)
        failed_count = sum(1 for a in self.attempts if a.result == BypassResult.FAILED)

        # Статистика по стратегіях
        by_strategy = {}
        for strategy in BypassStrategy:
            strategy_attempts = [a for a in self.attempts if a.strategy == strategy]
            if strategy_attempts:
                strategy_success = sum(
                    1 for a in strategy_attempts if a.result == BypassResult.SUCCESS
                )
                by_strategy[strategy.value] = {
                    "total": len(strategy_attempts),
                    "success": strategy_success,
                    "failed": len(strategy_attempts) - strategy_success,
                    "success_rate": (strategy_success / len(strategy_attempts)) * 100,
                }

        return {
            "total_attempts": total,
            "success_count": success_count,
            "failed_count": failed_count,
            "success_rate": (success_count / total) * 100 if total > 0 else 0.0,
            "by_strategy": by_strategy,
        }

    def get_summary(self) -> str:
        """
        Отримати текстовий звіт про роботу bypass manager.

        Returns:
            Відформатований текстовий звіт
        """
        stats = self.get_statistics()

        summary = [
            "\n" + "=" * 60,
            " CAPTCHA Bypass Manager - Статистика",
            "=" * 60,
            f" Загальна кількість спроб: {stats['total_attempts']}",
            f"Успішних обходів: {stats['success_count']}",
            f" Невдалих спроб: {stats['failed_count']}",
            f" Success Rate: {stats['success_rate']:.1f}%",
            "\n" + "-" * 60,
            " Статистика по стратегіях:",
            "-" * 60,
        ]

        for strategy, strategy_stats in stats["by_strategy"].items():
            summary.append(
                f"  • {strategy}:\n"
                f"    - Спроб: {strategy_stats['total']}\n"
                f"    - Успішних: {strategy_stats['success']}\n"
                f"    - Невдалих: {strategy_stats['failed']}\n"
                f"    - Success Rate: {strategy_stats['success_rate']:.1f}%"
            )

        summary.append("=" * 60)

        return "\n".join(summary)


def create_captcha_bypass_manager(
    cookie_storage_path: str | None = None,
    session_storage_path: str | None = None,
    max_retry_attempts: int = 3,
    captcha_solver_fallback: Callable | None = None,
) -> CaptchaBypassManager:
    """
    Factory функція для швидкого створення CaptchaBypassManager.

    Args:
        cookie_storage_path: Шлях до папки для cookies
        session_storage_path: Шлях до папки для sessions
        max_retry_attempts: Максимальна кількість спроб
        captcha_solver_fallback: Функція для CAPTCHA solver
    Returns:
        Налаштований CaptchaBypassManager
    Example:
        ```python
        from graph_crawler.shared.utils import create_captcha_bypass_manager
    """
    return CaptchaBypassManager(
        cookie_storage_path=cookie_storage_path,
        session_storage_path=session_storage_path,
        max_retry_attempts=max_retry_attempts,
        captcha_solver_fallback=captcha_solver_fallback,
    )
