"""Edge DTO — передача даних про зв'язки між нодами."""
from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class EdgeDTO(BaseModel):
    """DTO для Edge."""

    edge_id: str
    source_node_id: str = Field(description="ID ноди-джерела")
    target_node_id: str = Field(description="ID цільової ноди")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Метадані edge")
    created_at: datetime = Field(description="Час створення edge")

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "edge_id": "edge-550e8400-e29b-41d4-a716-446655440000",
                "source_node_id": "node-550e8400-e29b-41d4-a716-446655440001",
                "target_node_id": "node-550e8400-e29b-41d4-a716-446655440002",
                "metadata": {
                    "link_type": ["internal", "deeper"],
                    "depth_diff": 1,
                    "target_scanned": False,
                },
                "created_at": "2024-12-03T10:30:00",
            }
        }
    )


class CreateEdgeDTO(BaseModel):
    """DTO для створення Edge."""

    source_node_id: str
    target_node_id: str
    metadata: dict[str, Any | None] = None

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "source_node_id": "node-550e8400-e29b-41d4-a716-446655440001",
                "target_node_id": "node-550e8400-e29b-41d4-a716-446655440002",
                "metadata": {"link_type": ["internal", "deeper"]},
            }
        }
    )
