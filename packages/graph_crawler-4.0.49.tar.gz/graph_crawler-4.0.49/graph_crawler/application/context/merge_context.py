"""MergeContext - Контекст для динамічної зміни merge_strategy.

Дозволяє змінювати стратегію merge під час виконання:

P1-6: Мігровано з threading.local() на contextvars для async-safe операцій.
"""
from __future__ import annotations

import logging
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Callable

logger = logging.getLogger(__name__)

# ContextVar для async-safe стеку контекстів
_merge_context_stack: ContextVar[list["MergeContext"]] = ContextVar(
    "merge_context_stack", default=[]
)


@dataclass(slots=True)
class MergeContext:
    """
    Контекст для однієї merge операції.

    Attributes:
        strategy: Стратегія merge ('first', 'last', 'merge', 'newest', 'oldest', 'custom')
        custom_merge_fn: Кастомна функція для 'custom' стратегії
        source: Джерело контексту (для debugging)
    """

    strategy: str = "last"
    custom_merge_fn: Callable | None = None
    source: str = "default"

    def __post_init__(self):
        """Валідація після створення."""
        valid_strategies = ["first", "last", "merge", "newest", "oldest", "custom"]
        if self.strategy not in valid_strategies:
            raise ValueError(f"Invalid merge strategy: {self.strategy}. Valid: {valid_strategies}")

        if self.strategy == "custom" and self.custom_merge_fn is None:
            raise ValueError("custom_merge_fn is required for 'custom' strategy")


class MergeContextManager:
    """
    Async-safe стек контекстів для merge операцій.

    Дозволяє вкладені контексти:
    >>> with with_merge_strategy('merge'):
    ...     # Тут стратегія 'merge'
    ...     with with_merge_strategy('newest'):
    ...         # Тут стратегія 'newest'
    ...     # Знову 'merge'

    Async-safety (P1-6 migration):
    - Використовує contextvars замість threading.local()
    - Кожна async task має свій стек контекстів
    - Повна сумісність з asyncio та concurrent.futures
    """

    @classmethod
    def _get_stack(cls) -> list[MergeContext]:
        """Отримує стек контекстів для поточного async контексту."""
        stack = _merge_context_stack.get()
        if not stack:
            # Створюємо новий стек для цього контексту
            stack = []
            _merge_context_stack.set(stack)
        return stack

    @classmethod
    def push(cls, context: MergeContext) -> None:
        """
        Додає контекст на стек.

        Args:
            context: MergeContext для додавання
        """
        stack = cls._get_stack()
        stack.append(context)
        logger.debug(
            f"MergeContext pushed: {context.strategy} (source={context.source}, depth={len(stack)})"
        )

    @classmethod
    def pop(cls) -> MergeContext | None:
        """
        Знімає контекст зі стеку.

        Returns:
            Знятий MergeContext або None якщо стек порожній
        """
        stack = cls._get_stack()
        if stack:
            context = stack.pop()
            logger.debug(
                f"MergeContext popped: {context.strategy} "
                f"(source={context.source}, depth={len(stack)})"
            )
            return context
        return None

    @classmethod
    def current(cls) -> MergeContext | None:
        """
        Повертає поточний контекст (top of stack).

        Returns:
            Поточний MergeContext або None якщо стек порожній
        """
        stack = cls._get_stack()
        return stack[-1] if stack else None

    @classmethod
    def get_strategy(cls) -> str:
        """
        Отримує поточну стратегію merge.

        Пріоритет:
        1. Локальний контекст (якщо є)
        2. Глобальний дефолт з DependencyRegistry

        Returns:
            Назва стратегії
        """
        context = cls.current()
        if context:
            return context.strategy

        # Fallback до DependencyRegistry
        from graph_crawler.application.context.dependency_registry import DependencyRegistry

        return DependencyRegistry.get_default_merge_strategy()

    @classmethod
    def get_custom_merge_fn(cls) -> Callable | None:
        """
        Отримує кастомну функцію merge (якщо стратегія 'custom').

        Returns:
            Callable або None
        """
        context = cls.current()
        if context and context.strategy == "custom":
            return context.custom_merge_fn
        return None

    @classmethod
    def clear(cls) -> None:
        """
        Очищає стек контекстів для поточного async контексту.

        Корисно для тестування.
        """
        _merge_context_stack.set([])
        logger.debug("MergeContext stack cleared")

    @classmethod
    def depth(cls) -> int:
        """Повертає глибину стеку контекстів."""
        return len(cls._get_stack())


@contextmanager
def with_merge_strategy(
    strategy: str,
    custom_merge_fn: Callable | None = None,
    source: str = "with_merge_strategy",
):
    """
    Context manager для тимчасової зміни merge strategy.

    Args:
        strategy: Стратегія merge
        custom_merge_fn: Кастомна функція для 'custom' стратегії
        source: Джерело контексту (для debugging)
    """
    context = MergeContext(
        strategy=strategy,
        custom_merge_fn=custom_merge_fn,
        source=source,
    )

    MergeContextManager.push(context)
    try:
        yield context
    finally:
        MergeContextManager.pop()


def get_current_merge_strategy() -> str:
    """
    Shortcut для отримання поточної стратегії merge.

    Використовуйте в коді де потрібно знати поточну стратегію.

    Returns:
        Назва поточної стратегії

    Example:
        >>> strategy = get_current_merge_strategy()
        >>> print(f"Using merge strategy: {strategy}")
    """
    return MergeContextManager.get_strategy()


def get_current_custom_merge_fn() -> Callable | None:
    """
    Shortcut для отримання поточної кастомної функції merge.

    Returns:
        Callable або None
    """
    return MergeContextManager.get_custom_merge_fn()
