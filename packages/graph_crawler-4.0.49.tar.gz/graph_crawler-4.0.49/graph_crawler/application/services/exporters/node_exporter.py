"""Node Exporter - експорт нод з вибором полів та transform."""
from __future__ import annotations

import asyncio
import csv
import logging
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from typing import Any, Callable

import graph_crawler.shared.utils.fast_json as json
from graph_crawler.domain.entities.node import Node

logger = logging.getLogger(__name__)

# Thread pool для неблокуючих file I/O операцій
_node_exporter_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="node_export_")

import atexit

atexit.register(_node_exporter_executor.shutdown, wait=False)

class NodeExporter:
    """Експортер нод з підтримкою вибору полів та трансформації."""

    @staticmethod
    def export_to_json(
        nodes: list[Node],
        filepath: str,
        node_fields: list[str | None] = None,
        transform_node: Callable[[Node | None, dict[str, Any]]] = None,
        predicate: Callable[[Node | None, bool]] = None,
        pretty: bool = True,
    ) -> dict[str, Any]:
        """
        Експортує ноди в JSON формат.

        Args:
            nodes: Список нод для експорту
            filepath: Шлях до файлу
            node_fields: Список полів для включення (dot notation: 'metadata.title')
            transform_node: Функція трансформації ноди -> dict
            predicate: Фільтр нод (включає тільки де predicate(node) == True)
            pretty: Форматувати JSON з відступами
        Returns:
            Словник з результатами експорту
        Example:
            >>> NodeExporter.export_to_json(
            ...     graph.nodes.values(),
            ...     'jobs.json',
            ...     node_fields=['url', 'metadata.title', 'depth']
            ... )
        """
        logger.info("Exporting nodes to JSON: %s", filepath)

        # Фільтрація
        filtered_nodes = nodes
        if predicate:
            filtered_nodes = [n for n in nodes if predicate(n)]

        nodes_data = []
        for node in filtered_nodes:
            if transform_node:
                # Кастомна трансформація
                node_dict = transform_node(node)
            elif node_fields:
                # Вибрані поля
                node_dict = NodeExporter._extract_fields(node, node_fields)
            else:
                # Всі поля
                node_dict = node.model_dump()

            nodes_data.append(node_dict)

        result = {
            "total_nodes": len(nodes_data),
            "nodes": nodes_data,
            "export_options": {
                "node_fields": node_fields,
                "has_transform": transform_node is not None,
                "has_predicate": predicate is not None,
            },
        }

        # Зберігаємо
        with open(filepath, "w", encoding="utf-8") as f:
            if pretty:
                json.dump(result, f, ensure_ascii=False, indent=2, default=str)
            else:
                json.dump(result, f, ensure_ascii=False, default=str)

        logger.info("Exported %s nodes to %s", len(nodes_data), filepath)
        return result

    @staticmethod
    def export_to_csv(
        nodes: list[Node],
        filepath: str,
        node_fields: list[str | None] = None,
        transform_node: Callable[[Node | None, dict[str, Any]]] = None,
        predicate: Callable[[Node | None, bool]] = None,
    ) -> int:
        """
        Експортує ноди в CSV формат.

        Args:
            nodes: Список нод для експорту
            filepath: Шлях до CSV файлу
            node_fields: Список полів для включення
            transform_node: Функція трансформації ноди -> dict
            predicate: Фільтр нод
        Returns:
            Кількість експортованих нод
        Example:
            >>> NodeExporter.export_to_csv(
            ...     graph.nodes.values(),
            ...     'vacancies.csv',
            ...     transform_node=lambda n: {
            ...         'url': n.url,
            ...         'title': n.get_title(),
            ...         'schema_type': n.user_data.get('structured_data', {}).get_type(),
            ...     }
            ... )
        """
        logger.info("Exporting nodes to CSV: %s", filepath)

        # Фільтрація
        filtered_nodes = list(nodes)
        if predicate:
            filtered_nodes = [n for n in filtered_nodes if predicate(n)]

        if not filtered_nodes:
            logger.warning("No nodes to export")
            return 0

        # Визначаємо поля для CSV
        if transform_node:
            # Беремо поля з першої трансформованої ноди
            first_dict = transform_node(filtered_nodes[0])
            fields = list(first_dict.keys())
        elif node_fields:
            fields = node_fields
        else:
            # Базові поля
            fields = ["url", "node_id", "depth", "scanned", "response_status"]

        # Записуємо CSV
        with open(filepath, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()

            for node in filtered_nodes:
                if transform_node:
                    row = transform_node(node)
                elif node_fields:
                    row = NodeExporter._extract_fields(node, node_fields)
                else:
                    row = {
                        "url": node.url,
                        "node_id": node.node_id,
                        "depth": node.depth,
                        "scanned": node.scanned,
                        "response_status": node.response_status,
                    }

                # Конвертуємо складні типи в string
                for key, value in row.items():
                    if isinstance(value, (list, dict)):
                        row[key] = json.dumps(value, ensure_ascii=False)

                writer.writerow(row)

        logger.info("Exported %s nodes to %s", len(filtered_nodes), filepath)
        return len(filtered_nodes)

    @staticmethod
    def _extract_fields(node: Node, fields: list[str]) -> dict[str, Any]:
        """
        Витягує вказані поля з ноди.

        Підтримує dot notation: 'metadata.title', 'user_data.structured_data.primary_type'

        Args:
            node: Нода
            fields: Список полів

        Returns:
            Словник з вибраними полями
        """
        result = {}

        for field in fields:
            parts = field.split(".")
            value = node

            try:
                for part in parts:
                    if hasattr(value, part):
                        value = getattr(value, part)
                    elif isinstance(value, dict):
                        value = value.get(part)
                    else:
                        value = None
                        break

                # Використовуємо останню частину як ключ
                result[field] = value
            except Exception:
                result[field] = None

        return result

    @staticmethod
    def _flatten_key(prefix: str, key: str) -> str:
        """Створює плоский ключ з prefix.key."""
        return f"{prefix}.{key}" if prefix else key

    @staticmethod
    async def export_to_json_async(
        nodes: list[Node],
        filepath: str,
        node_fields: list[str | None] = None,
        transform_node: Callable[[Node | None, dict[str, Any]]] = None,
        predicate: Callable[[Node | None, bool]] = None,
        pretty: bool = True,
    ) -> dict[str, Any]:
        """
        Async версія експорту нод в JSON (неблокуюча).

        Args:
            nodes: Список нод для експорту
            filepath: Шлях до файлу
            node_fields: Список полів для включення
            transform_node: Функція трансформації
            predicate: Фільтр нод
            pretty: Форматувати JSON

        Returns:
            Словник з результатами експорту
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            _node_exporter_executor,
            partial(
                NodeExporter.export_to_json,
                nodes,
                filepath,
                node_fields,
                transform_node,
                predicate,
                pretty,
            ),
        )

    @staticmethod
    async def export_to_csv_async(
        nodes: list[Node],
        filepath: str,
        node_fields: list[str | None] = None,
        transform_node: Callable[[Node | None, dict[str, Any]]] = None,
        predicate: Callable[[Node | None, bool]] = None,
    ) -> int:
        """
        Async версія експорту нод в CSV (неблокуюча).

        Args:
            nodes: Список нод для експорту
            filepath: Шлях до CSV файлу
            node_fields: Список полів для включення
            transform_node: Функція трансформації
            predicate: Фільтр нод

        Returns:
            Кількість експортованих нод
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            _node_exporter_executor,
            partial(
                NodeExporter.export_to_csv, nodes, filepath, node_fields, transform_node, predicate
            ),
        )
