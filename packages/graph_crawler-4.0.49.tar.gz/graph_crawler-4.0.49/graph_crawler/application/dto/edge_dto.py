"""Edge Data Transfer Objects.

DTO для передачі даних про Edge між шарами.

Для Clean Architecture DTO знаходяться в shared/dto/.
Цей модуль реекспортує класи для backward compatibility.

Використання:
    # Рекомендовано (Clean Architecture):
    from graph_crawler.shared.dto import EdgeDTO, CreateEdgeDTO

    # Backward compatibility:
    from graph_crawler.application.dto import EdgeDTO, CreateEdgeDTO
"""

# Re-export from shared layer for backward compatibility
from graph_crawler.shared.dto.edge_dto import (
    CreateEdgeDTO,
    EdgeDTO,
)

__all__ = [
    "EdgeDTO",
    "CreateEdgeDTO",
]
