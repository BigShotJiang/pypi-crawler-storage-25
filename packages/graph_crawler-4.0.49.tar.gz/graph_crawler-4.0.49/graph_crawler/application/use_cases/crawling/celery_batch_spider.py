"""CeleryBatchSpider - ефективний distributed краулер з batch tasks.

Це оновлена версія CelerySpider, яка використовує batch tasks
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from celery import group  # type: ignore[import-not-found]

from graph_crawler.application.use_cases.crawling.serialization_mixin import (
    ConfigSerializationMixin,
)
from graph_crawler.application.use_cases.crawling.spider import GraphSpider
from graph_crawler.domain.entities.edge import Edge
from graph_crawler.domain.entities.graph import Graph
from graph_crawler.domain.entities.node import Node
from graph_crawler.domain.interfaces.distributed_spider import IDistributedSpider
from graph_crawler.domain.interfaces.driver import IDriver
from graph_crawler.domain.interfaces.storage import IStorage
from graph_crawler.domain.value_objects.configs import CrawlerConfig
from graph_crawler.shared.constants import (
    DEFAULT_CELERY_RESULTS_TIMEOUT,
    DEFAULT_MAX_CONCURRENT_REQUESTS,
)

logger = logging.getLogger(__name__)

# Константи для прогрес-логування
PROGRESS_LOG_INTERVAL = 5  # секунд

class CeleryBatchSpider(ConfigSerializationMixin, IDistributedSpider):
    """
    Ефективний distributed краулер з batch tasks.

    """

    def __init__(
        self,
        config: CrawlerConfig,
        driver: IDriver,
        storage: IStorage,
        batch_size: int | None = None,
        timeout: int | None = None,
    ):
        """
        Ініціалізує CeleryBatchSpider.

        Args:
            config: Конфігурація краулера (включає celery конфігурацію)
            driver: Драйвер для завантаження сторінок
            storage: Storage для зберігання графу
            batch_size: Розмір batch (якщо None - визначається з драйвера)
            timeout: Загальний timeout для краулінгу в секундах (опціонально)
        """
        self.config = config
        self.driver = driver
        self.storage = storage
        self.timeout = timeout
        self.start_time: float | None = None

        # Визначаємо batch_size з драйвера
        self.batch_size = batch_size or self._get_driver_batch_size()
        self._init_celery_app()

        # Локальний граф (для збірки результатів)
        self.graph = Graph()
        self.pages_crawled = 0
        self.visited_urls = set()

        # Статистика для прогресу
        self.total_batches_sent = 0
        self.total_batches_completed = 0
        self.total_urls_processed = 0
        self.last_progress_log = 0.0

        self._shutdown_requested = False
        self._pending_results = None
        self._setup_signal_handlers()

        logger.info(
            f"CeleryBatchSpider initialized: "
            f"batch_size={self.batch_size}, "
            f"broker={self._get_celery_broker_url()}" + (f", timeout={timeout}s" if timeout else "")
        )

    def _get_driver_batch_size(self) -> int:
        """
        Визначає оптимальний batch_size з драйвера.

        Логіка:
        - AsyncDriver: max_concurrent (default 24)
        - PooledPlaywrightDriver: browsers × tabs_per_browser
        - PlaywrightDriver: 1 (один браузер)
        - HTTPDriver/RequestsDriver: 1 (sync)

        Returns:
            Оптимальний batch size для драйвера
        """
        driver_class = self.driver.__class__.__name__

        # AsyncDriver - використовуємо max_concurrent
        if hasattr(self.driver, "max_concurrent"):
            batch_size = self.driver.max_concurrent
            logger.info("Batch size from %s.max_concurrent: %s", driver_class, batch_size)
            return batch_size

        # PooledPlaywrightDriver - browsers × tabs
        if hasattr(self.driver, "max_browsers") and hasattr(self.driver, "max_tabs_per_browser"):
            batch_size = self.driver.max_browsers * self.driver.max_tabs_per_browser
            logger.info("Batch size from %s pool: %s", driver_class, batch_size)
            return batch_size

        # Sync драйвери - batch size 1
        if "Sync" in driver_class or "Requests" in driver_class or "HTTP" in driver_class:
            logger.info("Sync driver %s: batch_size=1", driver_class)
            return 1

        # Default fallback
        logger.info("Using default batch_size for %s", driver_class)
        return DEFAULT_MAX_CONCURRENT_REQUESTS

    def _get_celery_broker_url(self) -> str:
        """Повертає URL брокера Celery."""
        return self.config.celery.broker_url

    def _get_max_depth(self) -> int:
        """Повертає максимальну глибину краулінгу."""
        return self.config.max_depth

    def _get_max_pages(self) -> int | None:
        """Повертає максимальну кількість сторінок."""
        return self.config.max_pages

    def _get_custom_node_class(self):
        """Повертає кастомний клас Node або дефолтний."""
        return self.config.custom_node_class if self.config.custom_node_class else Node

    def _get_start_url(self) -> str:
        """Повертає початковий URL."""
        return self.config.url

    def _init_celery_app(self):
        """Ініціалізує Celery app для batch tasks."""
        import os

        from graph_crawler.infrastructure.messaging.celery_unified import (
            celery,
            crawl_batch_task,
        )

        self.celery_app = celery
        self.crawl_batch_task = crawl_batch_task
        celery_config = self.config.celery
        os.environ["CELERY_BROKER_URL"] = celery_config.broker_url
        os.environ["CELERY_RESULT_BACKEND"] = celery_config.backend_url

        if celery_config.broker_url != celery.conf.broker_url:
            celery.conf.update(
                broker_url=celery_config.broker_url,
                result_backend=celery_config.backend_url,
            )

        logger.info("Celery unified app initialized")

    def _check_workers(self) -> dict[str, Any]:
        """
        Перевіряє стан Celery воркерів.

        Returns:
            Dict з інформацією про воркерів
        """
        try:
            inspect = self.celery_app.control.inspect()
            active = inspect.active() or {}
            stats = inspect.stats() or {}

            worker_count = len(stats)
            active_tasks = sum(len(tasks) for tasks in active.values())

            return {
                "workers": worker_count,
                "active_tasks": active_tasks,
                "worker_names": list(stats.keys()),
                "online": worker_count > 0,
            }
        except Exception as e:
            logger.warning(" Could not check workers: %s", e)
            return {
                "workers": 0,
                "active_tasks": 0,
                "worker_names": [],
                "online": False,
            }

    def _log_progress(self, force: bool = False):
        """
        Логує прогрес краулінгу (кожні PROGRESS_LOG_INTERVAL секунд).

        Args:
            force: Примусово залогувати (ігноруючи інтервал)
        """
        now = time.time()
        if not force and (now - self.last_progress_log) < PROGRESS_LOG_INTERVAL:
            return

        self.last_progress_log = now
        elapsed = now - self.start_time if self.start_time else 0

        # Формуємо статистику
        remaining = ""
        if self.timeout:
            time_left = self.timeout - elapsed
            remaining = f", залишилось {time_left:.0f}s" if time_left > 0 else ", timeout!"

        logger.info(
            f" Прогрес: {self.pages_crawled} сторінок | "
            f"{self.total_batches_completed}/{self.total_batches_sent} batches | "
            f"{elapsed:.1f}s{remaining}"
        )

    def _get_remaining_timeout(self) -> float | None:
        """
        Обчислює залишковий timeout.

        Returns:
            Залишковий час в секундах або None якщо timeout не встановлено
        """
        if not self.timeout or not self.start_time:
            return None

        elapsed = time.time() - self.start_time
        remaining = self.timeout - elapsed

        return max(remaining, 0.1)  # Мінімум 0.1 секунди

    def _is_timeout_reached(self) -> bool:
        """
        Перевіряє чи досягнуто timeout.

        Returns:
            True якщо timeout досягнуто
        """
        if not self.timeout or not self.start_time:
            return False

        return (time.time() - self.start_time) >= self.timeout

    def _setup_signal_handlers(self):
        """

        Обробляє SIGINT (Ctrl+C) та SIGTERM для коректного завершення:
        - Зупиняє відправку нових batch tasks
        - Відміняє pending tasks
        - Зберігає частковий граф
        """
        import signal

        def handle_shutdown(signum, frame):
            signal_name = "SIGINT" if signum == signal.SIGINT else "SIGTERM"
            logger.warning(" Shutdown signal received (%s), stopping gracefully...", signal_name)
            self._shutdown_requested = True

            # Відміняємо pending tasks
            if self._pending_results:
                try:
                    logger.info("Revoking pending tasks...")
                    self._pending_results.revoke(terminate=True)
                except Exception as e:
                    logger.warning("Error revoking tasks: %s", e)

        try:
            signal.signal(signal.SIGINT, handle_shutdown)
            signal.signal(signal.SIGTERM, handle_shutdown)
            logger.debug("Signal handlers installed for graceful shutdown")
        except ValueError:
            # signal.signal може викинути ValueError якщо не в main thread
            logger.debug("Cannot install signal handlers (not in main thread)")

    def _should_stop(self) -> bool:
        """
        Перевіряє чи потрібно зупинити crawl.

        Returns:
            True якщо shutdown requested або timeout reached
        """
        if self._shutdown_requested:
            return True
        if self._is_timeout_reached():
            return True
        return False

    def crawl(self) -> Graph:
        """
        Запускає ефективний розподілений краулінг з batch tasks (sync версія).

        Алгоритм:
        1. Ініціалізація - створюємо кореневий вузол
        2. Збираємо URLs в batches по batch_size
        3. Кожен batch → окрема Celery task
        4. Обробляємо результати, збираємо нові URLs
        5. Повторюємо поки є URLs та не досягнуто ліміту

        Returns:
            Побудований граф
        """
        import asyncio

        return asyncio.run(self.crawl_async())

    async def crawl_async(self) -> Graph:
        """
        Async версія crawl для підтримки timeout через asyncio.wait_for().

        Returns:
            Побудований граф
        """
        self.start_time = time.time()

        logger.info(" Starting CeleryBatchSpider crawl: %s", self._get_start_url())
        logger.info(
            f"Config: batch_size={self.batch_size}, "
            f"max_depth={self._get_max_depth()}, "
            f"max_pages={self._get_max_pages()}"
            + (f", timeout={self.timeout}s" if self.timeout else "")
        )
        worker_info = self._check_workers()
        if worker_info["online"]:
            worker_names = worker_info["worker_names"][:3]
            suffix = "..." if len(worker_info["worker_names"]) > 3 else ""
            logger.info(
                f" Workers online: {worker_info['workers']} ({', '.join(worker_names)}{suffix})"
            )
        else:
            logger.warning(
                " No workers detected! Tasks will be queued but may not "
                "execute until workers start."
            )

        # Крок 1: Ініціалізація
        urls_to_process = self._initialize_crawl()
        config_dict = self._serialize_config()

        # Додаємо timeout info в config для воркерів
        if self.timeout:
            config_dict["_crawl_timeout"] = self.timeout
            config_dict["_crawl_start_time"] = self.start_time

        round_num = 0
        while urls_to_process and self._should_continue():
            if self._should_stop():
                if self._shutdown_requested:
                    logger.warning(" Shutdown requested, stopping crawl gracefully")
                else:
                    logger.warning(" Timeout reached (%ss), stopping crawl", self.timeout)
                break

            round_num += 1

            # Крок 2: Групуємо URLs в batches
            batches = self._create_batches(urls_to_process)
            self.total_batches_sent += len(batches)

            logger.info(
                f" Round {round_num}: {len(urls_to_process)} URLs → "
                f"{len(batches)} batches (batch_size={self.batch_size})"
            )

            # Крок 3: Виконуємо batch tasks з timeout
            results = self._execute_batch_tasks(batches, config_dict)
            self.total_batches_completed += len([r for r in results if r])

            # Крок 4: Обробляємо результати
            urls_to_process = self._process_batch_results(results)

            # Логуємо прогрес
            self._log_progress()

            logger.info(
                f" Round {round_num} completed: "
                f"pages={self.pages_crawled}, queue={len(urls_to_process)}"
            )

            # Yield control для можливості timeout
            await asyncio.sleep(0)

        # Фінальний лог
        self._log_progress(force=True)
        elapsed = time.time() - self.start_time
        logger.info(" Crawl finished: %s pages in %.1fs", self.pages_crawled, elapsed)
        stats = self.graph.get_stats()
        logger.info("Graph stats: %s", stats)

        return self.graph

    def get_partial_graph(self) -> Graph:
        """
        Повертає частковий граф (для випадку timeout).

        Returns:
            Поточний стан графу
        """
        return self.graph

    def _create_batches(
        self, urls_to_process: list[tuple[str, int]]
    ) -> list[list[tuple[str, int]]]:
        """
        Групує URLs в batches відповідно до batch_size драйвера.

        Args:
            urls_to_process: Список (url, depth) для обробки

        Returns:
            Список batches, кожен batch = список (url, depth)
        """
        batches = []
        for i in range(0, len(urls_to_process), self.batch_size):
            batch = urls_to_process[i : i + self.batch_size]
            batches.append(batch)
        return batches

    def _execute_batch_tasks(
        self, batches: list[list[tuple[str, int]]], config_dict: dict
    ) -> list[dict]:
        """
        Виконує Celery batch tasks.

        Args:
            batches: Список batches URLs
            config_dict: Серіалізована конфігурація

        Returns:
            Список результатів від воркерів
        """
        from celery.exceptions import (
            TimeoutError as CeleryTimeoutError,  # type: ignore[import-not-found]
        )

        # Перевірка shutdown перед відправкою
        if self._shutdown_requested:
            logger.warning("Shutdown requested, skipping batch execution")
            return []
        tasks = []
        for batch in batches:
            task = self.crawl_batch_task.s(batch, config_dict, self.batch_size)
            tasks.append(task)

        # Запускаємо паралельно
        job = group(tasks)
        result_group = job.apply_async()

        self._pending_results = result_group

        logger.info(" Sent %s batch tasks to workers", len(tasks))

        # Визначаємо timeout для очікування результатів
        remaining_timeout = self._get_remaining_timeout()
        if remaining_timeout is not None:
            # Використовуємо залишковий timeout, але не більше дефолтного
            wait_timeout = min(remaining_timeout, DEFAULT_CELERY_RESULTS_TIMEOUT)
        else:
            wait_timeout = DEFAULT_CELERY_RESULTS_TIMEOUT

        logger.info(" Waiting for results (timeout=%.1fs)...", wait_timeout)

        # Чекаємо результати - простий підхід без polling
        try:
            results = result_group.get(timeout=wait_timeout)
            self._pending_results = None  # Очищаємо після успішного отримання
            logger.info(" Received %s batch results", len(results))
            return results

        except CeleryTimeoutError:
            logger.warning(
                f"⏱ Celery timeout ({wait_timeout:.1f}s), trying to get partial results..."
            )

            # Намагаємось отримати часткові результати
            partial_results = []
            for async_result in result_group.results:
                try:
                    if async_result.ready():
                        result = async_result.get(timeout=1)
                        partial_results.append(result)
                except Exception:
                    pass  # Non-critical: cleanup/fallback

            if partial_results:
                logger.info(" Got %s partial results", len(partial_results))
                return partial_results

            # Відміняємо незавершені tasks
            try:
                result_group.revoke(terminate=True)
            except Exception:
                pass  # Non-critical: cleanup/fallback

            return []

        except Exception as e:
            logger.error(" Error waiting for batch results: %s: %s", type(e).__name__, e)
            return []

    def _process_batch_results(self, batch_results: list[dict]) -> list[tuple[str, int]]:
        """
        Обробляє результати від batch tasks.

        Args:
            batch_results: Список результатів від batch tasks

        Returns:
            Нові URLs для наступного раунду
        """
        urls_to_process = []

        logger.debug("Processing %s batch results", len(batch_results))

        for batch_idx, batch_result in enumerate(batch_results):
            if not batch_result:
                logger.warning("Batch %s: empty result", batch_idx)
                continue

            results = batch_result.get("results", [])
            success_count = batch_result.get("success_count", 0)
            logger.debug("Batch %s: %s results, success=%s", batch_idx, len(results), success_count)

            for result in results:
                if not result.get("success"):
                    continue

                node_data = result.get("node_data")
                edges_data = result.get("edges_data", [])
                new_urls = result.get("new_urls", [])

                if node_data:
                    # Додаємо вузол в граф
                    node = self._deserialize_node(node_data)
                    if node.url not in self.graph.nodes:
                        self.graph.add_node(node)
                        self.pages_crawled += 1
                        if not self._should_continue():
                            logger.info("Limit reached at %s pages", self.pages_crawled)
                            break

                # Додаємо ребра
                for edge_data in edges_data:
                    edge = Edge(**edge_data)
                    self.graph.add_edge(edge)

                # Збираємо нові URLs
                for url, depth in new_urls:
                    if url not in self.visited_urls and depth <= self._get_max_depth():
                        urls_to_process.append((url, depth))
                        self.visited_urls.add(url)

            if not self._should_continue():
                break

        logger.debug(
            f"Processed: pages_crawled={self.pages_crawled}, new_urls={len(urls_to_process)}"
        )

        return urls_to_process

    def _initialize_crawl(self) -> list[tuple[str, int]]:
        """Ініціалізує краулінг - створює кореневий вузол."""
        temp_spider = self._create_temp_spider()

        node_class = self._get_custom_node_class()
        root_node = node_class(
            url=self._get_start_url(),
            depth=0,
            plugin_manager=temp_spider.node_plugin_manager,
        )
        self.graph.add_node(root_node)
        self.visited_urls.add(root_node.url)

        return [(root_node.url, 0)]

    # тепер наслідуються з ConfigSerializationMixin

    def _create_temp_spider(self) -> GraphSpider:
        """Створює тимчасовий spider."""
        return GraphSpider(self.config, self.driver, self.storage)

    def _deserialize_node(self, node_data: dict) -> Node:
        """Десеріалізує вузол."""
        node_class = self._get_custom_node_class()
        temp_spider = self._create_temp_spider()

        node = node_class.model_validate(node_data)
        node.plugin_manager = temp_spider.node_plugin_manager

        return node

    def _should_continue(self) -> bool:
        """Перевіряє чи треба продовжувати."""
        # Перевірка max_pages
        max_pages = self._get_max_pages()
        if max_pages and self.pages_crawled >= max_pages:
            logger.info("Reached max_pages limit: %s", max_pages)
            return False

        # Перевірка timeout
        if self._is_timeout_reached():
            logger.info("Reached timeout limit: %ss", self.timeout)
            return False

        return True

    def get_stats(self) -> dict[str, Any]:
        """Повертає статистику краулінгу."""
        stats: dict[str, Any] = self.graph.get_stats()
        stats["pages_crawled"] = self.pages_crawled
        stats["batch_size"] = self.batch_size
        stats["mode"] = "celery_batch"
        stats["total_batches_sent"] = self.total_batches_sent
        stats["total_batches_completed"] = self.total_batches_completed

        # Час роботи
        if self.start_time:
            stats["elapsed_time"] = time.time() - self.start_time
            if self.timeout:
                stats["timeout"] = self.timeout
                stats["timeout_reached"] = self._is_timeout_reached()

        return stats
