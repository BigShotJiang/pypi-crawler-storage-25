"""Protocol для HTML адаптерів."""
from __future__ import annotations

from typing import Any, Protocol


class ITreeAdapter(Protocol):
    """Інтерфейс для HTML адаптерів."""

    def parse(self, html: str) -> Any:
        """Парсить HTML в дерево."""
        ...

    def find(self, tree: Any, selector: str) -> Any | None:
        """Знаходить перший елемент."""
        ...

    def find_all(self, tree: Any, selector: str) -> list[Any]:
        """Знаходить всі елементи."""
        ...

    def get_text(self, element: Any) -> str:
        """Отримує текст елементу."""
        ...

    def get_attribute(self, element: Any, attr: str) -> str | None:
        """Отримує атрибут елементу."""
        ...
