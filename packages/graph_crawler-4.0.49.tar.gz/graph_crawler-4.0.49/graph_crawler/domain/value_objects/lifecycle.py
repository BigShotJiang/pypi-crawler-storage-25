"""Життєвий цикл Node - 4 етапи."""

from enum import Enum


class NodeLifecycle(str, Enum):
    """Життєвий цикл Node: URL_STAGE -> PROCESSING -> HTML_STAGE | FAILED."""

    # ЕТАП 1: Створення ноди (тільки URL)
    URL_STAGE = "url_stage"

    # ЕТАП 2: В процесі обробки HTML (P1-3 fix)
    PROCESSING = "processing"

    # ЕТАП 3: Успішно оброблено HTML
    HTML_STAGE = "html_stage"

    # ЕТАП 4: Помилка обробки (P1-3 fix)
    FAILED = "failed"

    # Не просканована (legacy)
    NOT_SCANNED = "not_scanned"


class NodeLifecycleError(Exception):
    """Помилка використання методу не на тому етапі життєвого циклу."""

    pass
