"""Cache Middleware - кешування відповідей.

ОПТИМІЗОВАНО 2026:
- Використовує orjson для серіалізації (4-12x швидше)
- Використовує aiofiles для async file I/O
"""
from __future__ import annotations

import hashlib
import logging
import time
from pathlib import Path

import orjson

from graph_crawler.extensions.middleware.base import (
    BaseMiddleware,
    MiddlewareContext,
    MiddlewareType,
)
from graph_crawler.shared.constants import DEFAULT_CACHE_TTL, HTTP_OK

try:
    import aiofiles
    import aiofiles.os

    AIOFILES_AVAILABLE = True
except ImportError:
    AIOFILES_AVAILABLE = False

logger = logging.getLogger(__name__)

class CacheMiddleware(BaseMiddleware):
    """
    Middleware для кешування HTTP відповідей у файлову систему.

    Конфіг:
        ttl: Time-to-live для кешу в секундах (default: 3600 = 1 година)
        cache_dir: Директорія для збереження кешу (default: /tmp/graph_crawler_cache)
        enabled: Увімкнути кеш (default: True)
    """

    def __init__(self, config: dict | None = None):
        super().__init__(config)
        self.cache_dir = Path(self.config.get("cache_dir", "/tmp/graph_crawler_cache"))
        self.ttl = self.config.get("ttl", DEFAULT_CACHE_TTL)
        self.enabled = self.config.get("enabled", True)
        self.setup()

    @property
    def middleware_type(self) -> MiddlewareType:
        return MiddlewareType.PRE_REQUEST

    @property
    def name(self) -> str:
        return "cache"

    def setup(self):
        """Створює директорію для кешу."""
        if self.enabled:
            try:
                self.cache_dir.mkdir(parents=True, exist_ok=True)
                logger.debug("Cache directory created: %s", self.cache_dir)
            except Exception as e:
                logger.error("Failed to create cache directory: %s", e)
                self.enabled = False

    def _get_cache_path(self, url: str) -> Path:
        """Генерує шлях до файлу кешу на основі URL."""
        # usedforsecurity=False - MD5 використовується для генерації імені файлу, не для безпеки
        url_hash = hashlib.md5(url.encode(), usedforsecurity=False).hexdigest()
        return self.cache_dir / f"{url_hash}.json"

    def _is_cache_valid(self, cache_path: Path) -> bool:
        """Перевіряє чи кеш ще валідний (не застарів)."""
        if not cache_path.exists():
            return False

        mtime = cache_path.stat().st_mtime
        age = time.time() - mtime

        return age < self.ttl

    async def _load_from_cache_async(self, url: str) -> dict | None:
        """Async завантажує відповідь з кешу (orjson для швидкості)."""
        cache_path = self._get_cache_path(url)

        if not self._is_cache_valid(cache_path):
            return None

        try:
            if AIOFILES_AVAILABLE:
                async with aiofiles.open(cache_path, "rb") as f:
                    content = await f.read()
                data = orjson.loads(content)
            else:
                with open(cache_path, "rb") as f:
                    data = orjson.loads(f.read())
            logger.debug("Cache HIT: %s", url)
            return data
        except Exception as e:
            logger.warning("Failed to load cache for %s: %s", url, e)
            return None

    async def _save_to_cache_async(self, url: str, response: dict):
        """Async зберігає відповідь у кеш (orjson для швидкості)."""
        cache_path = self._get_cache_path(url)

        try:
            content = orjson.dumps(response)
            if AIOFILES_AVAILABLE:
                async with aiofiles.open(cache_path, "wb") as f:
                    await f.write(content)
            else:
                with open(cache_path, "wb") as f:
                    f.write(content)
            logger.debug("Cached: %s", url)
        except Exception as e:
            logger.warning("Failed to save cache for %s: %s", url, e)

    def _load_from_cache(self, url: str) -> dict | None:
        """Sync завантажує відповідь з кешу (legacy, orjson)."""
        cache_path = self._get_cache_path(url)

        if not self._is_cache_valid(cache_path):
            return None

        try:
            with open(cache_path, "rb") as f:
                data = orjson.loads(f.read())
            logger.debug("Cache HIT: %s", url)
            return data
        except Exception as e:
            logger.warning("Failed to load cache for %s: %s", url, e)
            return None

    def _save_to_cache(self, url: str, response: dict):
        """Sync зберігає відповідь у кеш (legacy, orjson)."""
        cache_path = self._get_cache_path(url)

        try:
            with open(cache_path, "wb") as f:
                f.write(orjson.dumps(response))
            logger.debug("Cached: %s", url)
        except Exception as e:
            logger.warning("Failed to save cache for %s: %s", url, e)

    async def process(self, context: MiddlewareContext) -> MiddlewareContext:
        """
        Async перевіряє кеш перед запитом .

        Якщо є валідний кеш - встановлює skip_request і додає відповідь.
        Використовує aiofiles для async file I/O якщо доступний.

        Args:
            context: Контекст запиту

        Returns:
            Оновлений контекст
        """
        if not self.enabled:
            return context

        url = context.url

        cached_response = await self._load_from_cache_async(url)

        if cached_response:
            context.skip_request = True
            context.response = cached_response
            context.middleware_data["cache"] = {"hit": True}
        else:
            context.middleware_data["cache"] = {"hit": False}

        return context

    async def process_response_async(self, response: dict, **kwargs) -> dict:
        """
        Async зберігає відповідь у кеш після запиту .

        Args:
            response: Відповідь від драйвера
            **kwargs: Додаткові параметри

        Returns:
            Відповідь без змін
        """
        if not self.enabled:
            return response

        url = response.get("url")

        if url and response.get("status_code") == HTTP_OK and not response.get("error"):
            await self._save_to_cache_async(url, response)

        return response
