"""CAPTCHA Solving Services - інтеграція з сервісами.

Підтримується:
- 2captcha.com API
- AntiCaptcha.com API
- CapSolver API

Реалізація:
- Додано async версії методів solve_async() для неблокуючого виконання
- Використовується asyncio.sleep() замість time.sleep() в async контексті
- Збережено sync версії для зворотної сумісності
"""
from __future__ import annotations

import asyncio
import logging
import time
from abc import ABC, abstractmethod
from typing import Any

import aiohttp
import requests

from graph_crawler.extensions.plugins.engine.captcha.models import (
    CaptchaInfo,
    CaptchaService,
    CaptchaSolution,
    CaptchaType,
)

logger = logging.getLogger(__name__)

class BaseCaptchaSolver(ABC):
    """Базовий клас для CAPTCHA solvers."""

    def __init__(self, api_key: str, config: dict[str, Any | None] = None):
        self.api_key = api_key
        self.config = config or {}
        self.solve_timeout = self.config.get("solve_timeout", 120)
        self.min_score = self.config.get("min_score", 0.3)

    @abstractmethod
    def solve(self, captcha_info: CaptchaInfo) -> CaptchaSolution | None:
        """Розв'язує CAPTCHA (sync версія - блокуюча)."""
        pass

    @abstractmethod
    async def solve_async(self, captcha_info: CaptchaInfo) -> CaptchaSolution | None:
        """Розв'язує CAPTCHA (async версія - рекомендовано)."""
        pass

    @abstractmethod
    def check_balance(self) -> float | None:
        """Перевіряє баланс."""
        pass

class TwoCaptchaSolver(BaseCaptchaSolver):
    """2captcha.com solver."""

    BASE_URL = "http://2captcha.com"
    SERVICE_NAME = "2captcha"

    def _build_params(self, captcha_info: CaptchaInfo) -> dict[str, Any | None]:
        """Побудувати параметри запиту для типу CAPTCHA."""
        params = {"key": self.api_key, "json": 1}

        if captcha_info.captcha_type == CaptchaType.RECAPTCHA_V2:
            params.update(
                {
                    "method": "userrecaptcha",
                    "googlekey": captcha_info.site_key,
                    "pageurl": captcha_info.page_url,
                }
            )
            if captcha_info.data_s:
                params["data-s"] = captcha_info.data_s

        elif captcha_info.captcha_type == CaptchaType.RECAPTCHA_V3:
            params.update(
                {
                    "method": "userrecaptcha",
                    "version": "v3",
                    "googlekey": captcha_info.site_key,
                    "pageurl": captcha_info.page_url,
                    "action": captcha_info.action or "submit",
                    "min_score": self.min_score,
                }
            )

        elif captcha_info.captcha_type == CaptchaType.HCAPTCHA:
            params.update(
                {
                    "method": "hcaptcha",
                    "sitekey": captcha_info.site_key,
                    "pageurl": captcha_info.page_url,
                }
            )
        else:
            logger.warning("Unsupported CAPTCHA type: %s", captcha_info.captcha_type)
            return None

        return params

    def solve(self, captcha_info: CaptchaInfo) -> CaptchaSolution | None:
        """Sync версія solve (блокуюча - використовуйте solve_async)."""
        params = self._build_params(captcha_info)
        if params is None:
            return None

        try:
            response = requests.post(f"{self.BASE_URL}/in.php", data=params, timeout=30)
            result = response.json()

            if result.get("status") != 1:
                logger.error("2captcha error: %s", result.get('request'))
                return None

            captcha_id = result.get("request")
            elapsed = 0

            while elapsed < self.solve_timeout:
                time.sleep(5)  # Блокуюче очікування для sync версії
                elapsed += 5

                check_response = requests.get(
                    f"{self.BASE_URL}/res.php",
                    params={
                        "key": self.api_key,
                        "action": "get",
                        "id": captcha_id,
                        "json": 1,
                    },
                    timeout=30,
                )
                check_result = check_response.json()

                if check_result.get("status") == 1:
                    token = check_result.get("request")
                    cost = (
                        0.003
                        if captcha_info.captcha_type
                        in [CaptchaType.RECAPTCHA_V2, CaptchaType.RECAPTCHA_V3]
                        else 0.002
                    )

                    return CaptchaSolution(
                        token=token,
                        captcha_type=captcha_info.captcha_type,
                        solve_time=elapsed,
                        cost=cost,
                        service=self.SERVICE_NAME,
                    )
                elif check_result.get("request") != "CAPCHA_NOT_READY":
                    logger.error("2captcha error: %s", check_result.get('request'))
                    return None

            return None
        except Exception as e:
            logger.error("2captcha API error: %s", e)
            return None

    async def solve_async(self, captcha_info: CaptchaInfo) -> CaptchaSolution | None:
        """Async версія solve (рекомендовано для async контексту)."""
        params = self._build_params(captcha_info)
        if params is None:
            return None

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.BASE_URL}/in.php", data=params, timeout=30
                ) as response:
                    result = await response.json()

                if result.get("status") != 1:
                    logger.error("2captcha error: %s", result.get('request'))
                    return None

                captcha_id = result.get("request")
                elapsed = 0

                while elapsed < self.solve_timeout:
                    await asyncio.sleep(5)  # Неблокуюче очікування
                    elapsed += 5

                    async with session.get(
                        f"{self.BASE_URL}/res.php",
                        params={
                            "key": self.api_key,
                            "action": "get",
                            "id": captcha_id,
                            "json": 1,
                        },
                        timeout=30,
                    ) as check_response:
                        check_result = await check_response.json()

                    if check_result.get("status") == 1:
                        token = check_result.get("request")
                        cost = (
                            0.003
                            if captcha_info.captcha_type
                            in [CaptchaType.RECAPTCHA_V2, CaptchaType.RECAPTCHA_V3]
                            else 0.002
                        )

                        return CaptchaSolution(
                            token=token,
                            captcha_type=captcha_info.captcha_type,
                            solve_time=elapsed,
                            cost=cost,
                            service=self.SERVICE_NAME,
                        )
                    elif check_result.get("request") != "CAPCHA_NOT_READY":
                        logger.error("2captcha error: %s", check_result.get('request'))
                        return None

                return None
        except Exception as e:
            logger.error("2captcha API error: %s", e)
            return None

    def check_balance(self) -> float | None:
        try:
            response = requests.get(
                f"{self.BASE_URL}/res.php?key={self.api_key}&action=getbalance",
                timeout=10,
            )
            return float(response.text)
        except Exception as e:
            logger.debug("Error getting 2captcha balance: %s", e)
            return None

class AntiCaptchaSolver(BaseCaptchaSolver):
    """anticaptcha.com solver."""

    BASE_URL = "https://api.anti-captcha.com"
    SERVICE_NAME = "anticaptcha"

    def _build_task(self, captcha_info: CaptchaInfo) -> dict[str, Any | None]:
        """Побудувати task для типу CAPTCHA."""
        if captcha_info.captcha_type == CaptchaType.RECAPTCHA_V2:
            task = {
                "type": "RecaptchaV2TaskProxyless",
                "websiteURL": captcha_info.page_url,
                "websiteKey": captcha_info.site_key,
            }
            if captcha_info.data_s:
                task["recaptchaDataSValue"] = captcha_info.data_s
            return task

        elif captcha_info.captcha_type == CaptchaType.RECAPTCHA_V3:
            return {
                "type": "RecaptchaV3TaskProxyless",
                "websiteURL": captcha_info.page_url,
                "websiteKey": captcha_info.site_key,
                "pageAction": captcha_info.action or "submit",
                "minScore": self.min_score,
            }

        elif captcha_info.captcha_type == CaptchaType.HCAPTCHA:
            return {
                "type": "HCaptchaTaskProxyless",
                "websiteURL": captcha_info.page_url,
                "websiteKey": captcha_info.site_key,
            }

        return None

    def solve(self, captcha_info: CaptchaInfo) -> CaptchaSolution | None:
        """Sync версія solve (блокуюча - використовуйте solve_async)."""
        task = self._build_task(captcha_info)
        if task is None:
            return None

        try:
            response = requests.post(
                f"{self.BASE_URL}/createTask",
                json={"clientKey": self.api_key, "task": task},
                timeout=30,
            )
            result = response.json()

            if result.get("errorId", 0) != 0:
                logger.error("AntiCaptcha error: %s", result.get('errorDescription'))
                return None

            task_id = result.get("taskId")
            elapsed = 0

            while elapsed < self.solve_timeout:
                time.sleep(5)  # Блокуюче очікування для sync версії
                elapsed += 5

                check_response = requests.post(
                    f"{self.BASE_URL}/getTaskResult",
                    json={"clientKey": self.api_key, "taskId": task_id},
                    timeout=30,
                )
                check_result = check_response.json()

                if check_result.get("status") == "ready":
                    solution = check_result.get("solution", {})
                    token = solution.get("gRecaptchaResponse") or solution.get("token")
                    cost = 0.002

                    return CaptchaSolution(
                        token=token,
                        captcha_type=captcha_info.captcha_type,
                        solve_time=elapsed,
                        cost=cost,
                        service=self.SERVICE_NAME,
                    )
                elif check_result.get("errorId", 0) != 0:
                    return None

            return None
        except Exception as e:
            logger.error("AntiCaptcha API error: %s", e)
            return None

    async def solve_async(self, captcha_info: CaptchaInfo) -> CaptchaSolution | None:
        """Async версія solve (рекомендовано для async контексту)."""
        task = self._build_task(captcha_info)
        if task is None:
            return None

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.BASE_URL}/createTask",
                    json={"clientKey": self.api_key, "task": task},
                    timeout=30,
                ) as response:
                    result = await response.json()

                if result.get("errorId", 0) != 0:
                    logger.error("AntiCaptcha error: %s", result.get('errorDescription'))
                    return None

                task_id = result.get("taskId")
                elapsed = 0

                while elapsed < self.solve_timeout:
                    await asyncio.sleep(5)  # Неблокуюче очікування
                    elapsed += 5

                    async with session.post(
                        f"{self.BASE_URL}/getTaskResult",
                        json={"clientKey": self.api_key, "taskId": task_id},
                        timeout=30,
                    ) as check_response:
                        check_result = await check_response.json()

                    if check_result.get("status") == "ready":
                        solution = check_result.get("solution", {})
                        token = solution.get("gRecaptchaResponse") or solution.get("token")
                        cost = 0.002

                        return CaptchaSolution(
                            token=token,
                            captcha_type=captcha_info.captcha_type,
                            solve_time=elapsed,
                            cost=cost,
                            service=self.SERVICE_NAME,
                        )
                    elif check_result.get("errorId", 0) != 0:
                        return None

                return None
        except Exception as e:
            logger.error("AntiCaptcha API error: %s", e)
            return None

    def check_balance(self) -> float | None:
        try:
            response = requests.post(
                f"{self.BASE_URL}/getBalance",
                json={"clientKey": self.api_key},
                timeout=10,
            )
            return response.json().get("balance", 0.0)
        except Exception:
            return None

class CapSolverSolver(BaseCaptchaSolver):
    """capsolver.com solver."""

    BASE_URL = "https://api.capsolver.com"
    SERVICE_NAME = "capsolver"

    def _build_task(self, captcha_info: CaptchaInfo) -> dict[str, Any | None]:
        """Побудувати task для типу CAPTCHA."""
        task = {
            "websiteURL": captcha_info.page_url,
            "websiteKey": captcha_info.site_key,
        }

        if captcha_info.captcha_type == CaptchaType.RECAPTCHA_V2:
            task["type"] = "ReCaptchaV2TaskProxyLess"
        elif captcha_info.captcha_type == CaptchaType.RECAPTCHA_V3:
            task["type"] = "ReCaptchaV3TaskProxyLess"
            task["pageAction"] = captcha_info.action or "submit"
        elif captcha_info.captcha_type == CaptchaType.HCAPTCHA:
            task["type"] = "HCaptchaTaskProxyLess"
        else:
            return None

        return task

    def solve(self, captcha_info: CaptchaInfo) -> CaptchaSolution | None:
        """Sync версія solve (блокуюча - використовуйте solve_async)."""
        task = self._build_task(captcha_info)
        if task is None:
            return None

        try:
            response = requests.post(
                f"{self.BASE_URL}/createTask",
                json={"clientKey": self.api_key, "task": task},
                timeout=30,
            )
            result = response.json()

            if result.get("errorId", 0) != 0:
                return None

            task_id = result.get("taskId")
            elapsed = 0

            while elapsed < self.solve_timeout:
                time.sleep(5)  # Блокуюче очікування для sync версії
                elapsed += 5

                check_response = requests.post(
                    f"{self.BASE_URL}/getTaskResult",
                    json={"clientKey": self.api_key, "taskId": task_id},
                    timeout=30,
                )
                check_result = check_response.json()

                if check_result.get("status") == "ready":
                    solution = check_result.get("solution", {})
                    token = solution.get("gRecaptchaResponse") or solution.get("token")

                    return CaptchaSolution(
                        token=token,
                        captcha_type=captcha_info.captcha_type,
                        solve_time=elapsed,
                        cost=0.0025,
                        service=self.SERVICE_NAME,
                    )

            return None
        except Exception as e:
            logger.error("CapSolver API error: %s", e)
            return None

    async def solve_async(self, captcha_info: CaptchaInfo) -> CaptchaSolution | None:
        """Async версія solve (рекомендовано для async контексту)."""
        task = self._build_task(captcha_info)
        if task is None:
            return None

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.BASE_URL}/createTask",
                    json={"clientKey": self.api_key, "task": task},
                    timeout=30,
                ) as response:
                    result = await response.json()

                if result.get("errorId", 0) != 0:
                    return None

                task_id = result.get("taskId")
                elapsed = 0

                while elapsed < self.solve_timeout:
                    await asyncio.sleep(5)  # Неблокуюче очікування
                    elapsed += 5

                    async with session.post(
                        f"{self.BASE_URL}/getTaskResult",
                        json={"clientKey": self.api_key, "taskId": task_id},
                        timeout=30,
                    ) as check_response:
                        check_result = await check_response.json()

                    if check_result.get("status") == "ready":
                        solution = check_result.get("solution", {})
                        token = solution.get("gRecaptchaResponse") or solution.get("token")

                        return CaptchaSolution(
                            token=token,
                            captcha_type=captcha_info.captcha_type,
                            solve_time=elapsed,
                            cost=0.0025,
                            service=self.SERVICE_NAME,
                        )

                return None
        except Exception as e:
            logger.error("CapSolver API error: %s", e)
            return None

    def check_balance(self) -> float | None:
        try:
            response = requests.post(
                f"{self.BASE_URL}/getBalance",
                json={"clientKey": self.api_key},
                timeout=10,
            )
            return response.json().get("balance", 0.0)
        except Exception as e:
            logger.debug("Error getting CapSolver balance: %s", e)
            return None

def create_solver(service: str, api_key: str, config: dict[str, Any | None] = None) -> BaseCaptchaSolver:
    """Створює solver за назвою сервісу."""
    solvers = {
        CaptchaService.TWO_CAPTCHA: TwoCaptchaSolver,
        CaptchaService.ANTI_CAPTCHA: AntiCaptchaSolver,
        CaptchaService.CAPSOLVER: CapSolverSolver,
        "2captcha": TwoCaptchaSolver,
        "anticaptcha": AntiCaptchaSolver,
        "capsolver": CapSolverSolver,
    }

    solver_class = solvers.get(service)
    if not solver_class:
        raise ValueError(f"Unknown service: {service}")

    return solver_class(api_key, config)
