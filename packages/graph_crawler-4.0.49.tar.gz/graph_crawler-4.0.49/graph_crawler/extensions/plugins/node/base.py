"""Базові класи для Node плагінів.

Node плагіни виконуються на різних етапах життєвого циклу ноди:
- ЕТАП 1 (URL): ON_NODE_CREATED
- ЕТАП 2 (HTML): ON_BEFORE_SCAN, ON_HTML_PARSED, ON_AFTER_SCAN

PHASE 2 REFACTORING:
- NodePluginType та NodePluginContext тепер реекспортуються з domain.interfaces
- Це дотримання Dependency Inversion Principle (DIP)
"""
from __future__ import annotations

import inspect
import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

# PHASE 2: Re-export from domain interfaces (DIP compliance)
from graph_crawler.domain.interfaces.node_interfaces import (
    NodePluginContext,
    NodePluginType,
)

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from graph_crawler.domain.context.crawl_context import CrawlContext
    from graph_crawler.domain.interfaces.control_channel import (
        ControlMessage,
        CrawlCommand,
        IControlChannel,
    )



class BaseNodePlugin(ABC):
    """
    Базовий клас для Node плагінів.

    Node плагіни виконуються на різних етапах життєвого циклу ноди:
    - ЕТАП 1 (URL): ON_NODE_CREATED
    - ЕТАП 2 (HTML): ON_BEFORE_SCAN, ON_HTML_PARSED, ON_AFTER_SCAN

    Example:
        class MyPlugin(BaseNodePlugin):
            @property
            def plugin_type(self):
                return NodePluginType.ON_HTML_PARSED

            def execute(self, context: NodePluginContext) -> NodePluginContext:
                # Your logic here
                if context.html_tree:
                    context.user_data['my_data'] = 'value'
                return context
    """

    def __init__(self, config: dict[str, Any | None] = None):
        """Initialize the plugin with optional configuration."""
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)

    @property
    @abstractmethod
    def plugin_type(self) -> NodePluginType:
        """Return the plugin type (lifecycle stage)."""
        ...

    @property
    @abstractmethod
    def name(self) -> str:
        """Return the plugin name."""
        ...

    @abstractmethod
    def execute(self, context: NodePluginContext) -> "NodePluginContext | Any":
        """
        Execute the plugin logic.

        Can be sync or async (return coroutine).

        Args:
            context: Context with node data

        Returns:
            Updated context (or coroutine that returns context)
        """
        ...

    def setup(self):
        """Ініціалізація плагіну."""
        pass

    def teardown(self):
        """Очищення ресурсів."""
        pass

    def __repr__(self):
        return f"{self.__class__.__name__}(type={self.plugin_type.value}, enabled={self.enabled})"

class NodePluginManager:
    """
    Async менеджер для управління Node плагінами.

    Координує виконання плагінів на різних етапах життєвого циклу.
    Метод execute() є async для підтримки async плагінів.
    """

    def __init__(self, event_bus=None):
        """
        Ініціалізує NodePluginManager.

        Args:
            event_bus: EventBus для публікації подій (опціонально,)
        """
        self.plugins: dict[NodePluginType, list[BaseNodePlugin]] = {
            plugin_type: [] for plugin_type in NodePluginType
        }
        self.event_bus = event_bus

    def register(self, plugin: BaseNodePlugin):
        """Реєструє плагін."""
        if plugin.enabled:
            self.plugins[plugin.plugin_type].append(plugin)
            if hasattr(plugin, "setup") and callable(plugin.setup):
                plugin.setup()

    async def execute(
        self, plugin_type: NodePluginType, context: NodePluginContext
    ) -> NodePluginContext:
        """
        Async виконує всі плагіни вказаного типу .

        Плагіни виконуються послідовно, кожен отримує context від попереднього.
        Підтримує як sync, так і async плагіни.

        Args:
            plugin_type: Тип плагінів для виконання
            context: Контекст з даними

        Returns:
            Оновлений контекст
        """
        for plugin in self.plugins.get(plugin_type, []):
            if plugin.enabled:
                try:
                    # Подія перед виконанням плагіна
                    if self.event_bus:
                        from graph_crawler.domain.events import CrawlerEvent, EventType

                        self.event_bus.publish(
                            CrawlerEvent.create(
                                EventType.PLUGIN_STARTED,
                                data={
                                    "plugin_name": plugin.name,
                                    "plugin_type": plugin_type.value,
                                    "url": (context.url if hasattr(context, "url") else None),
                                },
                            )
                        )

                    result = plugin.execute(context)
                    if inspect.isawaitable(result):
                        context = await result
                    else:
                        context = result

                    # Подія після успішного виконання
                    if self.event_bus:
                        from graph_crawler.domain.events import CrawlerEvent, EventType

                        self.event_bus.publish(
                            CrawlerEvent.create(
                                EventType.PLUGIN_COMPLETED,
                                data={
                                    "plugin_name": plugin.name,
                                    "plugin_type": plugin_type.value,
                                    "url": (context.url if hasattr(context, "url") else None),
                                },
                            )
                        )

                except Exception as e:
                    # Логуємо помилку, але продовжуємо
                    logger.error("Plugin %s error: %s", plugin.name, e, exc_info=True)

                    # Подія про помилку
                    if self.event_bus:
                        from graph_crawler.domain.events import CrawlerEvent, EventType

                        self.event_bus.publish(
                            CrawlerEvent.create(
                                EventType.PLUGIN_FAILED,
                                data={
                                    "plugin_name": plugin.name,
                                    "plugin_type": plugin_type.value,
                                    "url": (context.url if hasattr(context, "url") else None),
                                    "error": str(e),
                                    "error_type": type(e).__name__,
                                },
                            )
                        )
        return context

    def has_plugins(self, plugin_type: NodePluginType) -> bool:
        """Перевіряє чи є плагіни вказаного типу."""
        return len(self.plugins.get(plugin_type, [])) > 0

    def execute_sync(
        self, plugin_type: NodePluginType, context: NodePluginContext
    ) -> NodePluginContext:
        """
        Синхронна версія execute() для виклику з sync коду.

        Примітка: Викликає тільки sync плагіни! Async плагіни будуть ігноровані
        з попередженням у логах.

        Args:
            plugin_type: Тип плагінів для виконання
            context: Контекст з даними

        Returns:
            Оновлений контекст
        """
        for plugin in self.plugins.get(plugin_type, []):
            if plugin.enabled:
                try:
                    result = plugin.execute(context)
                    if inspect.isawaitable(result):
                        # Async плагін в sync контексті - ігноруємо з попередженням
                        logger.warning(
                            "Plugin %s is async but called in sync context. "
                            "Skipping. Use execute() for async plugins.",
                            plugin.name
                        )
                        continue
                    context = result
                except Exception as e:
                    logger.error("Plugin %s failed: %s", plugin.name, e)
        return context

    async def teardown_all(self):
        """Async закриває всі плагіни."""
        for plugins_list in self.plugins.values():
            for plugin in plugins_list:
                teardown = plugin.teardown
                if callable(teardown):
                    result = teardown()
                    if inspect.isawaitable(result):
                        await result

    def __repr__(self):
        total = sum(len(plugins) for plugins in self.plugins.values())
        return f"NodePluginManager(total_plugins={total})"
