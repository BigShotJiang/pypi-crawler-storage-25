# 🔍 ID Generation - XXH3_64

## Поточна реалізація

Проект використовує **XXH3_64** для генерації ID:

| Параметр | Значення |
|----------|----------|
| Backend | xxhash.xxh3_64 |
| Output | 16-char hex string |
| Bits | 64 |
| Швидкість | ~5M ops/sec |
| Collision boundary | ~4 млрд записів |
| Детермінований | ✅ Так |

---

## Benchmark

```
UUID v4:  0.206s/100k (~485k ops/sec) - рандомний
UUID v5:  0.295s/100k (~340k ops/sec) - детермінований, SHA-1
XXH3_64:  0.020s/100k (~5M ops/sec)   - детермінований, швидкий ✅
```

**XXH3_64 в 15x швидший за UUID v5!**

---

## Використання

### Базове

```python
from graph_crawler.shared.utils.id_generator import generate_node_id, generate_edge_id

# Node ID з URL (детермінований)
node_id = generate_node_id("https://example.com")
# -> 'd2c7573f0c17fdfc'

# Edge ID
edge_id = generate_edge_id(source_id, target_id, anchor_hash)
# -> 'fe1419e6384f2bbe'
```

### Batch генерація

```python
from graph_crawler.shared.utils.id_generator import IdGenerator

gen = IdGenerator()

# Генератор для великих обсягів
for url, node_id in gen.node_ids(urls):
    process(url, node_id)

for src, tgt, edge_id in gen.edge_ids(edges):
    process(src, tgt, edge_id)
```

### INT версія (для BIGINT в PostgreSQL)

```python
from graph_crawler.shared.utils.id_generator import generate_node_id_int, generate_edge_id_int

# Повертає int64 замість hex string
node_id_int = generate_node_id_int("https://example.com")
# -> 15195842908732489212
```

---

## Файли

| Файл | Опис |
|------|------|
| `graph_crawler/shared/utils/id_generator.py` | Централізований модуль генерації ID |
| `graph_crawler/domain/entities/node.py` | Node.node_id - автогенерація з URL |
| `graph_crawler/domain/entities/edge.py` | Edge.edge_id - автогенерація з source+target |

---

## Collision Safety

При 600M edges (максимум):
- Collision boundary: 4 млрд
- Використання: 15%
- Ризик колізії: мінімальний

Birthday paradox формула: `P(collision) ≈ n²/2m`
- n = 600M, m = 2^64
- P ≈ (6×10⁸)² / (2 × 1.8×10¹⁹) ≈ 10⁻² = 1%

Для 100% безпеки при >1B записів - використовувати 128-bit hash.

---

## Не змінювались

- `error_tracing.py` - UUID v4 (рандомність потрібна для debug)
- `naming_strategy.py` - UUID v4 (рандомність для унікальних імен файлів)
