import asyncio
import os
from urllib.parse import quote

from .exceptions import AuthenticationError, MissingDependencyError, ScrapingError
from .schemas import LinkedInCredentials, LinkedInProfile


class AsyncLinkedInBot:
    def __init__(
        self,
        credentials: LinkedInCredentials,
        headless: bool = False,
        timeout_seconds: float = 30.0,
    ):
        self.credentials = credentials
        self.headless = headless
        self.timeout_ms = int(max(timeout_seconds, 1) * 1000)
        self.playwright = None
        self.browser = None
        self.page = None

    @classmethod
    def from_env(
        cls,
        email_var: str = "LINKEDIN_EMAIL",
        password_var: str = "LINKEDIN_PASSWORD",
        headless: bool = False,
        timeout_seconds: float = 30.0,
    ) -> "AsyncLinkedInBot":
        email = os.getenv(email_var, "").strip()
        password = os.getenv(password_var, "").strip()
        if not email or not password:
            raise ValueError(
                f"Missing LinkedIn credentials. Set `{email_var}` and `{password_var}`."
            )
        return cls(
            credentials=LinkedInCredentials(email=email, password=password),
            headless=headless,
            timeout_seconds=timeout_seconds,
        )

    async def __aenter__(self) -> "AsyncLinkedInBot":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    async def login(self) -> None:
        try:
            from playwright.async_api import Error as PlaywrightError
            from playwright.async_api import async_playwright
        except ImportError as exc:
            raise MissingDependencyError(
                "Playwright is not installed. Install with `pip install linkedin-autobot[automation]`."
            ) from exc

        self.playwright = await async_playwright().start()
        try:
            self.browser = await self.playwright.chromium.launch(headless=self.headless)
        except PlaywrightError as exc:
            await self.close()
            if self._is_browser_missing_error(exc):
                raise MissingDependencyError(
                    "Chromium browser is not installed for Playwright. "
                    "Run `python -m playwright install chromium`."
                ) from exc
            raise

        self.page = await self.browser.new_page()
        await self.page.goto("https://www.linkedin.com/login", wait_until="domcontentloaded")
        await self.page.fill("input#username", self.credentials.email)
        await self.page.fill("input#password", self.credentials.password)
        await self.page.click("button[type='submit']")
        await self.page.wait_for_load_state("domcontentloaded", timeout=self.timeout_ms)
        await asyncio.sleep(2)
        await self._assert_logged_in()

    async def visit_profile(self, profile_url: str) -> None:
        self._require_session()
        await self.page.goto(profile_url, wait_until="domcontentloaded")
        await asyncio.sleep(1)

    async def find_profile_url_by_name(self, name: str) -> str:
        self._require_session()
        search_url = f"https://www.linkedin.com/search/results/people/?keywords={quote(name)}"
        await self.page.goto(search_url, wait_until="domcontentloaded")
        await asyncio.sleep(2)

        selectors = [
            "a[href*='/in/']",
            ".entity-result__title-text a",
            ".linked-area[href*='/in/']",
        ]

        for selector in selectors:
            try:
                locator = self.page.locator(selector).first
                href = await locator.get_attribute("href")
                if href and "/in/" in href:
                    return href.split("?")[0]
            except Exception:
                continue

        raise ValueError(f"Could not find a LinkedIn profile for '{name}'.")

    async def _safe_text(self, selector: str) -> str:
        try:
            locator = self.page.locator(selector).first
            if await locator.count() == 0:
                return ""
            return " ".join((await locator.inner_text()).strip().split())
        except Exception:
            return ""

    async def _first_text(self, selectors: list[str]) -> str:
        for selector in selectors:
            value = await self._safe_text(selector)
            if value:
                return value
        return ""

    async def collect_profile(self, profile_url: str) -> LinkedInProfile:
        await self.visit_profile(profile_url)

        profile = LinkedInProfile(
            profile_url=profile_url,
            full_name=await self._first_text(["h1"]),
            title=await self._first_text(
                [
                    "div.text-body-medium.break-words",
                    ".pv-text-details__left-panel .text-body-medium",
                    ".text-body-medium",
                ]
            ),
            location=await self._first_text(
                [
                    ".pv-text-details__left-panel .text-body-small.inline",
                    ".text-body-small.inline.t-black--light.break-words",
                    ".text-body-small.inline",
                ]
            ),
            about=await self._first_text(
                [
                    "section.artdeco-card:has(#about) div.inline-show-more-text",
                    "section.artdeco-card:has(#about) .full-width[dir='ltr']",
                    "#about ~ div .inline-show-more-text",
                    "#about ~ *",
                ]
            ),
            experience=await self._first_text(
                [
                    "section.artdeco-card:has(#experience) .pvs-list__outer-container",
                    "#experience ~ div .pvs-list__outer-container",
                    "#experience ~ *",
                ]
            ),
        )
        if not profile.full_name and not profile.title:
            raise ScrapingError(
                "Could not extract profile data. LinkedIn page structure may have changed."
            )
        return profile

    async def collect_profile_by_name(self, name: str) -> LinkedInProfile:
        profile = await self.collect_profile(await self.find_profile_url_by_name(name))
        if not profile.full_name:
            profile.full_name = name
        return profile

    async def send_connection_request(self, profile_url: str, message: str | None = None) -> bool:
        await self.visit_profile(profile_url)
        try:
            await self.page.click("button[aria-label^='Connect']")
            await asyncio.sleep(1)
            if message:
                await self.page.click("button[aria-label='Add a note']")
                await self.page.fill("textarea[name='message']", message)
            await self.page.click("button[aria-label='Send now']")
            return True
        except Exception:
            return False

    async def close(self) -> None:
        if self.page:
            try:
                await self.page.close()
            except Exception:
                pass
        if self.browser:
            try:
                await self.browser.close()
            except Exception:
                pass
        if self.playwright:
            try:
                await self.playwright.stop()
            except Exception:
                pass
        self.page = None
        self.browser = None
        self.playwright = None

    def _require_session(self) -> None:
        if not self.page:
            raise RuntimeError("No active browser session. Call `login()` first.")

    async def _assert_logged_in(self) -> None:
        current_url = (self.page.url or "").lower()
        if "/checkpoint/challenge" in current_url:
            raise AuthenticationError(
                "LinkedIn blocked automated login with a security challenge. "
                "Connexion manuelle d’abord: ouvrez LinkedIn dans un navigateur normal, "
                "validez le challenge (CAPTCHA/SMS/email), puis relancez le bot."
            )
        if "/login" in current_url:
            error_banner = await self._first_text(
                [
                    "#error-for-password",
                    "#error-for-username",
                    ".alert.error",
                    ".form__label--error",
                ]
            )
            raise AuthenticationError(
                (
                    "LinkedIn login failed. "
                    "If LinkedIn is asking for verification, connexion manuelle d’abord: "
                    "ouvrez LinkedIn dans un navigateur normal, validez le challenge, "
                    "puis relancez le bot. "
                    f"{error_banner}"
                ).strip()
            )

    @staticmethod
    def _is_browser_missing_error(exc: Exception) -> bool:
        message = str(exc).lower()
        return (
            "executable doesn't exist" in message
            or "browsertype.launch" in message and "executable" in message
        )
