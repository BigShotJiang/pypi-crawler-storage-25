"""Gmail helper to fetch LinkedIn verification codes."""

import base64
import os
import re
import time
from typing import Optional


def fetch_verification_code(
    email: str,
    gmail_app_password: str,
    timeout_seconds: float = 60.0,
    max_retries: int = 5,
) -> str:
    """
    Fetch LinkedIn verification code from Gmail inbox.
    
    Args:
        email: Gmail email address
        gmail_app_password: Gmail App Password (NOT regular password)
        timeout_seconds: Maximum time to wait for email (seconds)
        max_retries: Number of times to check inbox
    
    Returns:
        The 6-digit verification code as a string
    
    Raises:
        ValueError: If code not found after timeout
        ImportError: If imaplib is not available
    
    Example:
        code = fetch_verification_code(
            email="you@gmail.com",
            gmail_app_password="xxxx xxxx xxxx xxxx"
        )
        # Returns: "123456"
    """
    try:
        import imaplib
    except ImportError:
        raise ImportError(
            "imaplib is part of Python stdlib and should be available. "
            "This error is unexpected. Ensure your Python installation is complete."
        )
    
    retry_interval = timeout_seconds / max_retries
    start_time = time.time()
    
    for attempt in range(max_retries):
        try:
            mail = imaplib.IMAP4_SSL("imap.gmail.com", 993)
            mail.login(email, gmail_app_password)
            mail.select("INBOX")
            
            # Search for recent LinkedIn emails
            status, messages = mail.search(None, 'UNSEEN FROM "security-noreply@linkedin.com"')
            
            if status == "OK" and messages and messages[0]:
                email_ids = messages[0].split()
                if email_ids:
                    # Get the most recent email
                    latest_email_id = email_ids[-1]
                    status, msg_data = mail.fetch(latest_email_id, "(RFC822)")
                    
                    for response_part in msg_data:
                        if isinstance(response_part, tuple):
                            msg = response_part[1]
                            if isinstance(msg, bytes):
                                msg_str = msg.decode("utf-8", errors="ignore")
                            else:
                                msg_str = msg
                            
                            # Extract 6-digit code
                            code_match = re.search(r"\b(\d{6})\b", msg_str)
                            if code_match:
                                code = code_match.group(1)
                                mail.close()
                                mail.logout()
                                return code
            
            mail.close()
            mail.logout()
        
        except Exception as exc:
            # Continue retrying on connection errors
            if attempt < max_retries - 1:
                time.sleep(retry_interval)
                continue
            raise ValueError(
                f"Failed to fetch LinkedIn verification code from Gmail: {exc}. "
                "Ensure you're using a Gmail App Password (not your regular password)."
            ) from exc
        
        # Wait before retrying
        if attempt < max_retries - 1:
            elapsed = time.time() - start_time
            if elapsed < timeout_seconds:
                time.sleep(min(retry_interval, timeout_seconds - elapsed))
    
    raise ValueError(
        f"LinkedIn verification code not found in Gmail after {timeout_seconds} seconds. "
        "Ensure you received the email and it contains a 6-digit code."
    )


def has_verification_email(email: str, gmail_app_password: str) -> bool:
    """
    Check if there are unread LinkedIn security emails.
    
    Args:
        email: Gmail email address
        gmail_app_password: Gmail App Password
    
    Returns:
        True if unread LinkedIn security email exists
    """
    try:
        import imaplib
    except ImportError:
        return False
    
    try:
        mail = imaplib.IMAP4_SSL("imap.gmail.com", 993)
        mail.login(email, gmail_app_password)
        mail.select("INBOX")
        
        status, messages = mail.search(None, 'UNSEEN FROM "security-noreply@linkedin.com"')
        result = status == "OK" and messages and messages[0]
        
        mail.close()
        mail.logout()
        return result
    except Exception:
        return False
