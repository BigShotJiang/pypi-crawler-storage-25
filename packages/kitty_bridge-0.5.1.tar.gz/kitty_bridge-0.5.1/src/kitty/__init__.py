"""Kitty Bridge — launch coding agents through a local API bridge."""

__version__ = "0.5.1"
__all__ = ["__version__"]
