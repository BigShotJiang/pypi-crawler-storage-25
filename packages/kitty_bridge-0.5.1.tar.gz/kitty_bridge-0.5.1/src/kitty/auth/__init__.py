"""OpenAI subscription OAuth authentication."""
