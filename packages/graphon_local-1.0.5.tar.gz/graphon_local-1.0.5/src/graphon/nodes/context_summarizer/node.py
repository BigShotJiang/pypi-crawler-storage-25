import logging
from collections.abc import Sequence

from typing import TYPE_CHECKING, Any, override

from graphon.enums import BuiltinNodeTypes, WorkflowNodeExecutionStatus
from graphon.node_events import NodeRunResult
from graphon.nodes.base.node import Node

from .entities import ContextSummarizerNodeData
from .exc import ContextSummarizerError
from .util import get_history_prompt_text
from ...entities.graph_config import NodeConfigDict
from ...model_runtime.entities import PromptMessage

logger = logging.getLogger(__name__)
if TYPE_CHECKING:
    from graphon.entities.graph_init_params import GraphInitParams
    from graphon.runtime.graph_runtime_state import GraphRuntimeState


class ContextSummarizerNode(Node[ContextSummarizerNodeData]):
    """
     summary history message
    """

    node_type = BuiltinNodeTypes.CONTEXT_SUMMARIZER

    @classmethod
    @override
    def version(cls) -> str:
        return "1"

    @override
    def __init__(
            self,
            node_id: str,
            config: NodeConfigDict,
            graph_init_params: "GraphInitParams",
            graph_runtime_state: "GraphRuntimeState",
            *,
            history_messages: Sequence[PromptMessage]
    ) -> None:
        super().__init__(
            node_id=node_id,
            config=config,
            graph_init_params=graph_init_params,
            graph_runtime_state=graph_runtime_state,
        )

        self._history = history_messages
    @override
    def _run(self) -> NodeRunResult:
        message_limit = self._node_data.message_limit
        conversation_id = self.graph_runtime_state.variable_pool.system_variables.to_dict()["conversation_id"]
        inputs = {"variable_selector": conversation_id,"message_limit": message_limit}
        if conversation_id is None:
            return NodeRunResult(
                status=WorkflowNodeExecutionStatus.FAILED,
                inputs=inputs,
                process_data={},
            )

        try:
            return NodeRunResult(
                status=WorkflowNodeExecutionStatus.SUCCEEDED,
                inputs=inputs,
                process_data={},
                outputs={"contextHistory": get_history_prompt_text(prompt_messages=self._history)},
            )
        except ContextSummarizerError as e:
            return NodeRunResult(
                status=WorkflowNodeExecutionStatus.FAILED,
                error=str(e),
                inputs=inputs,
                process_data={},
            )

