class ContextSummarizerError(ValueError):
    """Base exception for errors related to the ContextSummarizerNode."""
