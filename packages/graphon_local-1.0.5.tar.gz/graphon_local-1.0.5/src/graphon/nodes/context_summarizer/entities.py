from graphon.entities.base_node_data import BaseNodeData
from graphon.enums import BuiltinNodeTypes, NodeType


class ContextSummarizerNodeData(BaseNodeData):
    type: NodeType = BuiltinNodeTypes.DOCUMENT_CONVERTOR
    message_limit: int = 10
