from collections.abc import Sequence
from graphon.model_runtime.entities import (
    ImagePromptMessageContent,
    PromptMessage,
    PromptMessageRole,
    TextPromptMessageContent,
)


def get_history_prompt_text(
    prompt_messages: Sequence[PromptMessage],
    human_prefix: str = "Human",
    ai_prefix: str = "Assistant",
) -> str:
    string_messages = []
    for m in prompt_messages:
        if m.role == PromptMessageRole.USER:
            role = human_prefix
        elif m.role == PromptMessageRole.ASSISTANT:
            role = ai_prefix
        else:
            continue

        if isinstance(m.content, list):
            inner_msg = ""
            for content in m.content:
                if isinstance(content, TextPromptMessageContent):
                    inner_msg += f"{content.data}\n"
                elif isinstance(content, ImagePromptMessageContent):
                    inner_msg += "[image]\n"

            string_messages.append(f"{role}: {inner_msg.strip()}")
        else:
            message = f"{role}: {m.content}"
            string_messages.append(message)

    return "\n".join(string_messages)
