import base64
import logging
from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING, Any, override


import pypandoc
import pypdfium2
from graphon.file import File, file_manager
from graphon.file.enums import FileTransferMethod, FileType
from graphon.variables.segments import ArrayFileSegment, FileSegment
from graphon.enums import BuiltinNodeTypes, WorkflowNodeExecutionStatus
from graphon.node_events import NodeRunResult
from graphon.nodes.base.node import Node

# Add PIL imports for image processing
from PIL import Image
import io
import tempfile
import os

from .entities import DocumentConvertorNodeData
from .exc import DocumentConvertorError, FileDownloadError,  UnsupportedFileTypeError
from ...entities.graph_config import NodeConfigDict
from ...http import HttpClientProtocol, get_http_client

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from graphon.entities.graph_init_params import GraphInitParams
    from graphon.runtime.graph_runtime_state import GraphRuntimeState

class DocumentConvertorNode(Node[DocumentConvertorNodeData]):
    """
    Convert pdf/docx 2 png
    """

    node_type = BuiltinNodeTypes.DOCUMENT_CONVERTOR

    @classmethod
    @override
    def version(cls) -> str:
        return "1"

    @override
    def __init__(
        self,
        node_id: str,
        config: NodeConfigDict,
        graph_init_params: "GraphInitParams",
        graph_runtime_state: "GraphRuntimeState",
        *,
        http_client: HttpClientProtocol | None = None,
    ) -> None:
        super().__init__(
            node_id=node_id,
            config=config,
            graph_init_params=graph_init_params,
            graph_runtime_state=graph_runtime_state,
        )

        self._http_client = http_client or get_http_client()
    @override
    def _run(self) -> NodeRunResult:
        variable_selector = self._node_data.variable_selector
        variable = self.graph_runtime_state.variable_pool.get(variable_selector)

        if variable is None:
            error_message = f"File variable not found for selector: {variable_selector}"
            return NodeRunResult(status=WorkflowNodeExecutionStatus.FAILED, error=error_message)
        if variable.value and not isinstance(variable, ArrayFileSegment | FileSegment):
            error_message = f"Variable {variable_selector} is not an ArrayFileSegment"
            return NodeRunResult(status=WorkflowNodeExecutionStatus.FAILED, error=error_message)

        value = variable.value
        inputs = {"variable_selector": variable_selector}
        process_data = {"documents": value if isinstance(value, list) else [value]}

        try:
            if isinstance(value, list):
                converted_file_list = list(map(_convert_file_to_png, value))
                return NodeRunResult(
                    status=WorkflowNodeExecutionStatus.SUCCEEDED,
                    inputs=inputs,
                    process_data=process_data,
                    outputs={"files": ArrayFileSegment(value=converted_file_list)},
                )
            elif isinstance(value, File):
                converted_file = _convert_file_to_png(value)
                return NodeRunResult(
                    status=WorkflowNodeExecutionStatus.SUCCEEDED,
                    inputs=inputs,
                    process_data=process_data,
                    outputs={"files": ArrayFileSegment(value=[converted_file])},
                )
            else:
                raise DocumentConvertorError(f"Unsupported variable type: {type(value)}")
        except DocumentConvertorError as e:
            return NodeRunResult(
                status=WorkflowNodeExecutionStatus.FAILED,
                error=str(e),
                inputs=inputs,
                process_data=process_data,
            )

    @classmethod
    def _extract_variable_selector_to_variable_mapping(
        cls,
        *,
        graph_config: Mapping[str, Any],
        node_id: str,
        node_data: Mapping[str, Any],
    ) -> Mapping[str, Sequence[str]]:
        # Create typed NodeData from dict
        typed_node_data = DocumentConvertorNodeData.model_validate(node_data)

        return {node_id + ".files": typed_node_data.variable_selector}


def _download_file_content(http_client: HttpClientProtocol, file: File) -> bytes:
    """Download the content of a file based on its transfer method."""
    try:
        if file.transfer_method == FileTransferMethod.REMOTE_URL:
            if file.remote_url is None:
                raise FileDownloadError("Missing URL for remote file")
            response = http_client.get(file.remote_url)
            response.raise_for_status()
            return response.content
        else:
            return file_manager.download(file)
    except Exception as e:
        raise FileDownloadError(f"Error downloading file: {str(e)}") from e


def _convert_file_to_png(file: File):
    file_content = _download_file_content(file)
    # 去除后缀
    file_name = file.filename.split('.')[0]  # 去除后缀
    if file.extension:
        converted_file = _convert_file_by_extension(file_content=file_content, file_name=file_name, file_extension=file.extension)
    elif file.mime_type:
        converted_file = _convert_file_by_mime_type(file_content=file_content, file_name=file_name, mime_type=file.mime_type)
    else:
        raise UnsupportedFileTypeError("Unable to determine file type: MIME type or file extension is missing")
    return converted_file


def _convert_file_by_extension(file_content: bytes,file_name:str, file_extension: str) -> File:
    if file_extension == ".pdf":
        return _convert_pdf_to_png(file_content, file_name)
    elif file_extension in (".doc", ".docx"):
        return _convert_doc_to_png(file_content, file_name)
    else:
        raise UnsupportedFileTypeError(f"Unsupported Extension Type: {file_extension}")


def _convert_file_by_mime_type(file_content: bytes,file_name:str, mime_type: str) -> File:
    if mime_type == "application/pdf":
        return _convert_pdf_to_png(file_content, file_name)
    elif mime_type == "application/msword":
        return _convert_doc_to_png(file_content, file_name)
    elif mime_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        return _convert_doc_to_png(file_content, file_name)
    else:
        raise UnsupportedFileTypeError(f"Unsupported MIME type: {mime_type}")


def _convert_pdf_to_png(file_content: bytes,file_name:str) -> File:
    """Convert PDF file to PNG image."""
    try:
        # Load PDF document
        pdf_document = pypdfium2.PdfDocument(io.BytesIO(file_content))

        # Limit to first 5 pages
        page_count = min(len(pdf_document), 5)

        # Render pages as images
        images = []
        for page_index in range(page_count):
            page = pdf_document[page_index]
            # Render page to bitmap with 4x scaling for better quality
            pil_image = page.render(scale=2).to_pil()
            images.append(pil_image)

        # If we have multiple pages, combine them vertically
        if len(images) > 1:
            # Calculate the total height for all images
            total_height = sum(img.height for img in images)
            max_width = max(img.width for img in images)

            # Create a new image with enough space for all pages
            combined_image = Image.new('RGB', (max_width, total_height), 'white')

            # Paste each page image
            y_offset = 0
            for img in images:
                # Center the image if it's narrower than max width
                x_offset = (max_width - img.width) // 2
                combined_image.paste(img, (x_offset, y_offset))
                y_offset += img.height
        else:
            # Just use the single image
            combined_image = images[0] if images else Image.new('RGB', (100, 100), 'white')


        # Convert to PNG bytes
        png_bytes_io = io.BytesIO()
        combined_image.save(png_bytes_io, format='PNG')
        png_bytes = png_bytes_io.getvalue()

        # Create a new File object for the PNG
        # We'll need to save this to storage and create a proper File object
        import uuid

        # Generate a unique filename
        png_filename = f"converted_{file_name}.png"
        extension = ".png"
        mime_type = "image/png"

        # For now, we'll return a simplified File object
        # In a real implementation, this would need proper context for user/tenant IDs
        converted_file = File(
            tenant_id="system",
            type=FileType.IMAGE,
            transfer_method=FileTransferMethod.TEMP_FILE,  # Simplified for now
            filename=png_filename,
            extension=extension,
            mime_type=mime_type,
            size=len(png_bytes),
            remote_url= base64.b64encode(png_bytes).decode('utf-8'),
            related_id=None,  # Would need to be set properly in real implementation
            storage_key=""  # Would need to be set properly in real implementation
        )

        return converted_file
    except Exception as e:
        raise DocumentConvertorError(f"Failed to convert PDF to PNG: {str(e)}") from e


def _convert_doc_to_png(file_content: bytes, file_name:str) -> File:
    """Convert DOC/DOCX file to PNG image."""
    try:
        # For DOC/DOCX conversion, we'll first convert to PDF and then to PNG
        # Using pypandoc to convert DOC/DOCX to PDF
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as temp_input:
            temp_input.write(file_content)
            temp_input_path = temp_input.name

        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as temp_pdf:
            temp_pdf_path = temp_pdf.name

        try:
            # Convert DOC/DOCX to PDF using pypandoc
            pypandoc.convert_file(temp_input_path, 'pdf', outputfile=temp_pdf_path)

            # Now convert PDF to PNG
            with open(temp_pdf_path, 'rb') as pdf_file:
                pdf_content = pdf_file.read()

            # Use the PDF conversion function
            return _convert_pdf_to_png(pdf_content, file_name)
        finally:
            # Clean up temporary files
            if os.path.exists(temp_input_path):
                os.unlink(temp_input_path)
            if os.path.exists(temp_pdf_path):
                os.unlink(temp_pdf_path)

    except Exception as e:
        raise DocumentConvertorError(f"Failed to convert DOC/DOCX to PNG: {str(e)}") from e
