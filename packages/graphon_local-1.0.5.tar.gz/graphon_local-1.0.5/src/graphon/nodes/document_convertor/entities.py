from collections.abc import Sequence

from graphon.entities.base_node_data import BaseNodeData
from graphon.enums import BuiltinNodeTypes, NodeType

class DocumentConvertorNodeData(BaseNodeData):
    type: NodeType = BuiltinNodeTypes.DOCUMENT_CONVERTOR
    variable_selector: Sequence[str]
