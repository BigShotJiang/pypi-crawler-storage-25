"""Examples for Graphon."""
