"""dargslan-sysctl-audit — Sysctl parameter auditor.

Check kernel tuning parameters, security settings, network hardening, and get recommendations.
Part of the Dargslan Linux Sysadmin Toolkit: https://dargslan.com
"""

__version__ = "1.0.0"

import subprocess
import os


SECURITY_PARAMS = {
    "kernel.randomize_va_space": {"recommended": "2", "desc": "ASLR (Address Space Layout Randomization)"},
    "kernel.kptr_restrict": {"recommended": "1", "desc": "Restrict kernel pointer exposure"},
    "kernel.dmesg_restrict": {"recommended": "1", "desc": "Restrict dmesg access to root"},
    "kernel.yama.ptrace_scope": {"recommended": "1", "desc": "Restrict ptrace to parent processes"},
    "kernel.core_uses_pid": {"recommended": "1", "desc": "Include PID in core dump filenames"},
    "fs.suid_dumpable": {"recommended": "0", "desc": "Disable core dumps for SUID binaries"},
    "fs.protected_hardlinks": {"recommended": "1", "desc": "Protect hardlinks from exploitation"},
    "fs.protected_symlinks": {"recommended": "1", "desc": "Protect symlinks from exploitation"},
}

NETWORK_PARAMS = {
    "net.ipv4.ip_forward": {"recommended": "0", "desc": "IP forwarding (disable unless router)"},
    "net.ipv4.conf.all.send_redirects": {"recommended": "0", "desc": "Don't send ICMP redirects"},
    "net.ipv4.conf.all.accept_redirects": {"recommended": "0", "desc": "Don't accept ICMP redirects"},
    "net.ipv4.conf.all.accept_source_route": {"recommended": "0", "desc": "Reject source-routed packets"},
    "net.ipv4.conf.all.log_martians": {"recommended": "1", "desc": "Log packets with impossible addresses"},
    "net.ipv4.conf.all.rp_filter": {"recommended": "1", "desc": "Enable reverse path filtering"},
    "net.ipv4.icmp_echo_ignore_broadcasts": {"recommended": "1", "desc": "Ignore broadcast ping"},
    "net.ipv4.tcp_syncookies": {"recommended": "1", "desc": "Enable SYN cookies (SYN flood protection)"},
    "net.ipv6.conf.all.accept_redirects": {"recommended": "0", "desc": "Don't accept IPv6 redirects"},
}


def get_sysctl_value(param):
    """Get a single sysctl parameter value."""
    try:
        result = subprocess.run(["sysctl", "-n", param], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.SubprocessError, FileNotFoundError):
        path = f"/proc/sys/{param.replace('.', '/')}"
        try:
            with open(path, "r") as f:
                return f.read().strip()
        except (IOError, OSError):
            pass
    return None


def get_all_sysctl():
    """Get all sysctl parameters."""
    params = {}
    try:
        result = subprocess.run(["sysctl", "-a"], capture_output=True, text=True, timeout=15)
        if result.returncode == 0:
            for line in result.stdout.strip().split("\n"):
                if " = " in line:
                    key, val = line.split(" = ", 1)
                    params[key.strip()] = val.strip()
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    return params


def audit_security():
    """Audit security-related sysctl parameters."""
    results = []
    for param, info in SECURITY_PARAMS.items():
        value = get_sysctl_value(param)
        status = "PASS" if value == info["recommended"] else "FAIL" if value is not None else "N/A"
        results.append({
            "param": param,
            "current": value or "not found",
            "recommended": info["recommended"],
            "desc": info["desc"],
            "status": status,
        })
    return results


def audit_network():
    """Audit network-related sysctl parameters."""
    results = []
    for param, info in NETWORK_PARAMS.items():
        value = get_sysctl_value(param)
        status = "PASS" if value == info["recommended"] else "FAIL" if value is not None else "N/A"
        results.append({
            "param": param,
            "current": value or "not found",
            "recommended": info["recommended"],
            "desc": info["desc"],
            "status": status,
        })
    return results


def calculate_score():
    """Calculate overall sysctl security score."""
    security = audit_security()
    network = audit_network()
    total = len(security) + len(network)
    passed = sum(1 for r in security + network if r["status"] == "PASS")
    return {"score": round(passed / total * 100) if total > 0 else 0, "passed": passed, "total": total}


def generate_report():
    """Generate comprehensive sysctl audit report."""
    security = audit_security()
    network = audit_network()
    score = calculate_score()

    lines = []
    lines.append("=" * 60)
    lines.append("SYSCTL PARAMETER AUDIT REPORT")
    lines.append("=" * 60)
    lines.append(f"\nSecurity Score: {score['score']}% ({score['passed']}/{score['total']} checks passed)")

    lines.append("\n--- Kernel Security Parameters ---")
    for r in security:
        icon = "[OK]" if r["status"] == "PASS" else "[!!]" if r["status"] == "FAIL" else "[??]"
        lines.append(f"  {icon} {r['param']}")
        lines.append(f"      Current: {r['current']} | Recommended: {r['recommended']}")
        lines.append(f"      {r['desc']}")

    lines.append("\n--- Network Hardening Parameters ---")
    for r in network:
        icon = "[OK]" if r["status"] == "PASS" else "[!!]" if r["status"] == "FAIL" else "[??]"
        lines.append(f"  {icon} {r['param']}")
        lines.append(f"      Current: {r['current']} | Recommended: {r['recommended']}")
        lines.append(f"      {r['desc']}")

    failed = [r for r in security + network if r["status"] == "FAIL"]
    if failed:
        lines.append(f"\n--- Recommendations ({len(failed)} issues) ---")
        for r in failed:
            lines.append(f"  sysctl -w {r['param']}={r['recommended']}")

    lines.append("\n" + "=" * 60)
    lines.append("More tools: https://dargslan.com | pip install dargslan-toolkit")
    lines.append("=" * 60)
    return "\n".join(lines)
