"""CLI interface for dargslan-sysctl-audit."""

import sys
from dargslan_sysctl_audit import generate_report, audit_security, audit_network, calculate_score, get_sysctl_value


def main():
    args = sys.argv[1:]
    cmd = args[0] if args else "report"

    if cmd == "report":
        print(generate_report())
    elif cmd == "security":
        for r in audit_security():
            icon = "[OK]" if r["status"] == "PASS" else "[!!]"
            print(f"  {icon} {r['param']} = {r['current']} (recommended: {r['recommended']})")
    elif cmd == "network":
        for r in audit_network():
            icon = "[OK]" if r["status"] == "PASS" else "[!!]"
            print(f"  {icon} {r['param']} = {r['current']} (recommended: {r['recommended']})")
    elif cmd == "score":
        s = calculate_score()
        print(f"Sysctl Security Score: {s['score']}% ({s['passed']}/{s['total']})")
    elif cmd == "get":
        if len(args) < 2:
            print("Usage: dargslan-sysctl get <param>")
            sys.exit(1)
        val = get_sysctl_value(args[1])
        print(f"{args[1]} = {val}" if val else f"Parameter not found: {args[1]}")
    elif cmd in ("help", "--help", "-h"):
        print("dargslan-sysctl — Sysctl parameter auditor")
        print("Usage: dargslan-sysctl [command]")
        print("Commands: report, security, network, score, get <param>")
        print("More: https://dargslan.com")
    else:
        print(f"Unknown command: {cmd}. Use --help for usage.")
        sys.exit(1)


if __name__ == "__main__":
    main()
