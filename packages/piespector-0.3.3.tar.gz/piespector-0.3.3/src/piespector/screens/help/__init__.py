"""Help screen rendering helpers."""
