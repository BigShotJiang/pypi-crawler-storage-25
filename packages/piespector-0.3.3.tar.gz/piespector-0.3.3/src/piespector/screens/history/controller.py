from __future__ import annotations

from typing import TYPE_CHECKING

from textual import events

from piespector.domain.editor import HISTORY_DETAIL_BLOCK_REQUEST, TAB_HOME, TAB_LABELS
from piespector.domain.modes import MODE_HISTORY_RESPONSE_SELECT
from piespector.interactions.keys import (
    DOWN_KEYS,
    KEY_EDIT,
    KEY_ESCAPE,
    KEY_SCROLL_DOWN,
    KEY_SCROLL_UP,
    LEFT_KEYS,
    OPEN_KEYS,
    RESPONSE_SCROLL_KEYS,
    RIGHT_KEYS,
    UP_KEYS,
)

KEY_REPLAY = "r"
if TYPE_CHECKING:
    from piespector.app import PiespectorApp


class HistoryController:
    def __init__(self, app: PiespectorApp) -> None:
        self.app = app

    @property
    def state(self):
        return self.app.state

    def handle_history_view_key(self, event: events.Key) -> bool:
        if event.key in DOWN_KEYS:
            self.state.select_history_entry(1)
            self.app._refresh_screen()
            event.stop()
            return True

        if event.key in UP_KEYS:
            self.state.select_history_entry(-1)
            self.app._refresh_screen()
            event.stop()
            return True

        if event.key == KEY_REPLAY:
            replayed = self.state.replay_selected_history_entry()
            if replayed is not None:
                self.state.switch_tab(TAB_HOME, TAB_LABELS[TAB_HOME])
            self.app._refresh_screen()
            event.stop()
            return True

        if event.key in OPEN_KEYS:
            self.state.enter_history_response_select_mode()
            self.app._refresh_screen()
            event.stop()
            return True

        return False

    def handle_history_response_select_key(self, event: events.Key) -> None:
        if event.key == KEY_ESCAPE:
            self.state.leave_history_response_select_mode()
            self.app._refresh_screen()
            event.stop()
            return

        if event.key in UP_KEYS:
            self.state.cycle_history_detail_block(-1)
            self.app._refresh_viewport()
            event.stop()
            return

        if event.key in DOWN_KEYS:
            self.state.cycle_history_detail_block(1)
            self.app._refresh_viewport()
            event.stop()
            return

        if event.key in LEFT_KEYS:
            if self.state.selected_history_detail_block == HISTORY_DETAIL_BLOCK_REQUEST:
                self.state.cycle_history_request_tab(-1)
            else:
                self.state.cycle_history_response_tab(-1)
            self.app._refresh_viewport()
            event.stop()
            return

        if event.key in RIGHT_KEYS:
            if self.state.selected_history_detail_block == HISTORY_DETAIL_BLOCK_REQUEST:
                self.state.cycle_history_request_tab(1)
            else:
                self.state.cycle_history_response_tab(1)
            self.app._refresh_viewport()
            event.stop()
            return

        if event.key == KEY_EDIT:
            self.app._open_history_response_viewer(origin_mode=MODE_HISTORY_RESPONSE_SELECT)
            event.stop()
            return

        if event.key in RESPONSE_SCROLL_KEYS:
            step_size = self.app._history_detail_scroll_step()
            step = step_size if event.key == KEY_SCROLL_DOWN else -step_size
            if self.state.selected_history_detail_block == HISTORY_DETAIL_BLOCK_REQUEST:
                self.state.scroll_history_request(step)
            else:
                self.state.scroll_history_response(step)
            self.app._refresh_viewport()
            event.stop()
