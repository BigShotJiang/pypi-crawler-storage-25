var Zt = Array.isArray, Qt = Array.prototype.indexOf, _e = Array.prototype.includes, Xt = Array.from, Jt = Object.defineProperty, ye = Object.getOwnPropertyDescriptor, en = Object.getOwnPropertyDescriptors, tn = Object.prototype, nn = Array.prototype, ht = Object.getPrototypeOf, rt = Object.isExtensible;
const rn = () => {
};
function nr(e) {
  return e();
}
function sn(e) {
  for (var t = 0; t < e.length; t++)
    e[t]();
}
function dt() {
  var e, t, n = new Promise((r, s) => {
    e = r, t = s;
  });
  return { promise: n, resolve: e, reject: t };
}
const k = 2, he = 4, ke = 8, Ke = 1 << 24, q = 16, H = 32, Q = 64, qe = 128, P = 512, b = 1024, S = 2048, j = 4096, R = 8192, L = 16384, oe = 32768, st = 1 << 25, me = 65536, Be = 1 << 17, ln = 1 << 18, ve = 1 << 19, vt = 1 << 20, rr = 1 << 25, ae = 65536, Ne = 1 << 21, Te = 1 << 22, W = 1 << 23, se = /* @__PURE__ */ Symbol("$state"), sr = /* @__PURE__ */ Symbol("legacy props"), ir = /* @__PURE__ */ Symbol(""), z = new class extends Error {
  name = "StaleReactionError";
  message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}(), ar = (
  // We gotta write it like this because after downleveling the pure comment may end up in the wrong location
  !!globalThis.document?.contentType && /* @__PURE__ */ globalThis.document.contentType.includes("xml")
);
function an() {
  throw new Error("https://svelte.dev/e/async_derived_orphan");
}
function fr(e, t, n) {
  throw new Error("https://svelte.dev/e/each_key_duplicate");
}
function fn(e) {
  throw new Error("https://svelte.dev/e/effect_in_teardown");
}
function on() {
  throw new Error("https://svelte.dev/e/effect_in_unowned_derived");
}
function un(e) {
  throw new Error("https://svelte.dev/e/effect_orphan");
}
function cn() {
  throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
function or(e) {
  throw new Error("https://svelte.dev/e/props_invalid_value");
}
function _n() {
  throw new Error("https://svelte.dev/e/state_descriptors_fixed");
}
function hn() {
  throw new Error("https://svelte.dev/e/state_prototype_fixed");
}
function dn() {
  throw new Error("https://svelte.dev/e/state_unsafe_mutation");
}
function vn() {
  throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror");
}
const ur = 1, cr = 2, _r = 4, hr = 8, dr = 16, vr = 1, pr = 2, gr = 4, wr = 8, yr = 16, br = 1, Er = 2, m = /* @__PURE__ */ Symbol(), pn = "http://www.w3.org/1999/xhtml", mr = "http://www.w3.org/2000/svg", Tr = "http://www.w3.org/1998/Math/MathML", Sr = "@attach";
function gn() {
  console.warn("https://svelte.dev/e/derived_inert");
}
function kr() {
  console.warn("https://svelte.dev/e/select_multiple_invalid_value");
}
function wn() {
  console.warn("https://svelte.dev/e/svelte_boundary_reset_noop");
}
function pt(e) {
  return e === this.v;
}
function yn(e, t) {
  return e != e ? t == t : e !== t || e !== null && typeof e == "object" || typeof e == "function";
}
function gt(e) {
  return !yn(e, this.v);
}
let De = !1;
function Ar() {
  De = !0;
}
let E = null;
function de(e) {
  E = e;
}
function bn(e, t = !1, n) {
  E = {
    p: E,
    i: !1,
    c: null,
    e: null,
    s: e,
    x: null,
    r: (
      /** @type {Effect} */
      v
    ),
    l: De && !t ? { s: null, u: null, $: [] } : null
  };
}
function En(e) {
  var t = (
    /** @type {ComponentContext} */
    E
  ), n = t.e;
  if (n !== null) {
    t.e = null;
    for (var r of n)
      Ft(r);
  }
  return t.i = !0, E = t.p, /** @type {T} */
  {};
}
function Ae() {
  return !De || E !== null && E.l === null;
}
let ne = [];
function wt() {
  var e = ne;
  ne = [], sn(e);
}
function Z(e) {
  if (ne.length === 0 && !be) {
    var t = ne;
    queueMicrotask(() => {
      t === ne && wt();
    });
  }
  ne.push(e);
}
function mn() {
  for (; ne.length > 0; )
    wt();
}
function yt(e) {
  var t = v;
  if (t === null)
    return p.f |= W, e;
  if ((t.f & oe) === 0 && (t.f & he) === 0)
    throw e;
  $(e, t);
}
function $(e, t) {
  for (; t !== null; ) {
    if ((t.f & qe) !== 0) {
      if ((t.f & oe) === 0)
        throw e;
      try {
        t.b.error(e);
        return;
      } catch (n) {
        e = n;
      }
    }
    t = t.parent;
  }
  throw e;
}
const Tn = -7169;
function y(e, t) {
  e.f = e.f & Tn | t;
}
function We(e) {
  (e.f & P) !== 0 || e.deps === null ? y(e, b) : y(e, j);
}
function bt(e) {
  if (e !== null)
    for (const t of e)
      (t.f & k) === 0 || (t.f & ae) === 0 || (t.f ^= ae, bt(
        /** @type {Derived} */
        t.deps
      ));
}
function Et(e, t, n) {
  (e.f & S) !== 0 ? t.add(e) : (e.f & j) !== 0 && n.add(e), bt(e.deps), y(e, b);
}
const ee = /* @__PURE__ */ new Set();
let g = null, D = null, He = null, be = !1, Ve = !1, ce = null, Pe = null;
var it = 0;
let Sn = 1;
class X {
  id = Sn++;
  /**
   * The current values of any signals that are updated in this batch.
   * Tuple format: [value, is_derived] (note: is_derived is false for deriveds, too, if they were overridden via assignment)
   * They keys of this map are identical to `this.#previous`
   * @type {Map<Value, [any, boolean]>}
   */
  current = /* @__PURE__ */ new Map();
  /**
   * The values of any signals (sources and deriveds) that are updated in this batch _before_ those updates took place.
   * They keys of this map are identical to `this.#current`
   * @type {Map<Value, any>}
   */
  previous = /* @__PURE__ */ new Map();
  /**
   * When the batch is committed (and the DOM is updated), we need to remove old branches
   * and append new ones by calling the functions added inside (if/each/key/etc) blocks
   * @type {Set<(batch: Batch) => void>}
   */
  #r = /* @__PURE__ */ new Set();
  /**
   * If a fork is discarded, we need to destroy any effects that are no longer needed
   * @type {Set<(batch: Batch) => void>}
   */
  #d = /* @__PURE__ */ new Set();
  /**
   * Callbacks that should run only when a fork is committed.
   * @type {Set<(batch: Batch) => void>}
   */
  #n = /* @__PURE__ */ new Set();
  /**
   * Async effects that are currently in flight
   * @type {Map<Effect, number>}
   */
  #f = /* @__PURE__ */ new Map();
  /**
   * Async effects that are currently in flight, _not_ inside a pending boundary
   * @type {Map<Effect, number>}
   */
  #t = /* @__PURE__ */ new Map();
  /**
   * A deferred that resolves when the batch is committed, used with `settled()`
   * TODO replace with Promise.withResolvers once supported widely enough
   * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
   */
  #l = null;
  /**
   * The root effects that need to be flushed
   * @type {Effect[]}
   */
  #e = [];
  /**
   * Effects created while this batch was active.
   * @type {Effect[]}
   */
  #s = [];
  /**
   * Deferred effects (which run after async work has completed) that are DIRTY
   * @type {Set<Effect>}
   */
  #a = /* @__PURE__ */ new Set();
  /**
   * Deferred effects that are MAYBE_DIRTY
   * @type {Set<Effect>}
   */
  #o = /* @__PURE__ */ new Set();
  /**
   * A map of branches that still exist, but will be destroyed when this batch
   * is committed — we skip over these during `process`.
   * The value contains child effects that were dirty/maybe_dirty before being reset,
   * so they can be rescheduled if the branch survives.
   * @type {Map<Effect, { d: Effect[], m: Effect[] }>}
   */
  #i = /* @__PURE__ */ new Map();
  /**
   * Inverse of #skipped_branches which we need to tell prior batches to unskip them when committing
   * @type {Set<Effect>}
   */
  #c = /* @__PURE__ */ new Set();
  is_fork = !1;
  #h = !1;
  /** @type {Set<Batch>} */
  #_ = /* @__PURE__ */ new Set();
  #u() {
    return this.is_fork || this.#t.size > 0;
  }
  #g() {
    for (const r of this.#_)
      for (const s of r.#t.keys()) {
        for (var t = !1, n = s; n.parent !== null; ) {
          if (this.#i.has(n)) {
            t = !0;
            break;
          }
          n = n.parent;
        }
        if (!t)
          return !0;
      }
    return !1;
  }
  /**
   * Add an effect to the #skipped_branches map and reset its children
   * @param {Effect} effect
   */
  skip_effect(t) {
    this.#i.has(t) || this.#i.set(t, { d: [], m: [] }), this.#c.delete(t);
  }
  /**
   * Remove an effect from the #skipped_branches map and reschedule
   * any tracked dirty/maybe_dirty child effects
   * @param {Effect} effect
   * @param {(e: Effect) => void} callback
   */
  unskip_effect(t, n = (r) => this.schedule(r)) {
    var r = this.#i.get(t);
    if (r) {
      this.#i.delete(t);
      for (var s of r.d)
        y(s, S), n(s);
      for (s of r.m)
        y(s, j), n(s);
    }
    this.#c.add(t);
  }
  #v() {
    if (it++ > 1e3 && (ee.delete(this), An()), !this.#u()) {
      for (const a of this.#a)
        this.#o.delete(a), y(a, S), this.schedule(a);
      for (const a of this.#o)
        y(a, j), this.schedule(a);
    }
    const t = this.#e;
    this.#e = [], this.apply();
    var n = ce = [], r = [], s = Pe = [];
    for (const a of t)
      try {
        this.#w(a, n, r);
      } catch (l) {
        throw St(a), l;
      }
    if (g = null, s.length > 0) {
      var i = X.ensure();
      for (const a of s)
        i.schedule(a);
    }
    if (ce = null, Pe = null, this.#u() || this.#g()) {
      this.#p(r), this.#p(n);
      for (const [a, l] of this.#i)
        Tt(a, l);
    } else {
      this.#f.size === 0 && ee.delete(this), this.#a.clear(), this.#o.clear();
      for (const a of this.#r) a(this);
      this.#r.clear(), lt(r), lt(n), this.#l?.resolve();
    }
    var u = (
      /** @type {Batch | null} */
      /** @type {unknown} */
      g
    );
    if (this.#e.length > 0) {
      const a = u ??= this;
      a.#e.push(...this.#e.filter((l) => !a.#e.includes(l)));
    }
    u !== null && (ee.add(u), u.#v());
  }
  /**
   * Traverse the effect tree, executing effects or stashing
   * them for later execution as appropriate
   * @param {Effect} root
   * @param {Effect[]} effects
   * @param {Effect[]} render_effects
   */
  #w(t, n, r) {
    t.f ^= b;
    for (var s = t.first; s !== null; ) {
      var i = s.f, u = (i & (H | Q)) !== 0, a = u && (i & b) !== 0, l = a || (i & R) !== 0 || this.#i.has(s);
      if (!l && s.fn !== null) {
        u ? s.f ^= b : (i & he) !== 0 ? n.push(s) : pe(s) && ((i & q) !== 0 && this.#o.add(s), fe(s));
        var o = s.first;
        if (o !== null) {
          s = o;
          continue;
        }
      }
      for (; s !== null; ) {
        var f = s.next;
        if (f !== null) {
          s = f;
          break;
        }
        s = s.parent;
      }
    }
  }
  /**
   * @param {Effect[]} effects
   */
  #p(t) {
    for (var n = 0; n < t.length; n += 1)
      Et(t[n], this.#a, this.#o);
  }
  /**
   * Associate a change to a given source with the current
   * batch, noting its previous and current values
   * @param {Value} source
   * @param {any} value
   * @param {boolean} [is_derived]
   */
  capture(t, n, r = !1) {
    t.v !== m && !this.previous.has(t) && this.previous.set(t, t.v), (t.f & W) === 0 && (this.current.set(t, [n, r]), D?.set(t, n)), this.is_fork || (t.v = n);
  }
  activate() {
    g = this;
  }
  deactivate() {
    g = null, D = null;
  }
  flush() {
    try {
      Ve = !0, g = this, this.#v();
    } finally {
      it = 0, He = null, ce = null, Pe = null, Ve = !1, g = null, D = null, ie.clear();
    }
  }
  discard() {
    for (const t of this.#d) t(this);
    this.#d.clear(), this.#n.clear(), ee.delete(this);
  }
  /**
   * @param {Effect} effect
   */
  register_created_effect(t) {
    this.#s.push(t);
  }
  #y() {
    for (const f of ee) {
      var t = f.id < this.id, n = [];
      for (const [c, [_, d]] of this.current) {
        if (f.current.has(c)) {
          var r = (
            /** @type {[any, boolean]} */
            f.current.get(c)[0]
          );
          if (t && _ !== r)
            f.current.set(c, [_, d]);
          else
            continue;
        }
        n.push(c);
      }
      var s = [...f.current.keys()].filter((c) => !this.current.has(c));
      if (s.length === 0)
        t && f.discard();
      else if (n.length > 0) {
        if (t)
          for (const c of this.#c)
            f.unskip_effect(c, (_) => {
              (_.f & (q | Te)) !== 0 ? f.schedule(_) : f.#p([_]);
            });
        f.activate();
        var i = /* @__PURE__ */ new Set(), u = /* @__PURE__ */ new Map();
        for (var a of n)
          mt(a, s, i, u);
        u = /* @__PURE__ */ new Map();
        var l = [...f.current.keys()].filter(
          (c) => this.current.has(c) ? (
            /** @type {[any, boolean]} */
            this.current.get(c)[0] !== c
          ) : !0
        );
        for (const c of this.#s)
          (c.f & (L | R | Be)) === 0 && Ze(c, l, u) && ((c.f & (Te | q)) !== 0 ? (y(c, S), f.schedule(c)) : f.#a.add(c));
        if (f.#e.length > 0) {
          f.apply();
          for (var o of f.#e)
            f.#w(o, [], []);
          f.#e = [];
        }
        f.deactivate();
      }
    }
    for (const f of ee)
      f.#_.has(this) && (f.#_.delete(this), f.#_.size === 0 && !f.#u() && (f.activate(), f.#v()));
  }
  /**
   * @param {boolean} blocking
   * @param {Effect} effect
   */
  increment(t, n) {
    let r = this.#f.get(n) ?? 0;
    if (this.#f.set(n, r + 1), t) {
      let s = this.#t.get(n) ?? 0;
      this.#t.set(n, s + 1);
    }
  }
  /**
   * @param {boolean} blocking
   * @param {Effect} effect
   * @param {boolean} skip - whether to skip updates (because this is triggered by a stale reaction)
   */
  decrement(t, n, r) {
    let s = this.#f.get(n) ?? 0;
    if (s === 1 ? this.#f.delete(n) : this.#f.set(n, s - 1), t) {
      let i = this.#t.get(n) ?? 0;
      i === 1 ? this.#t.delete(n) : this.#t.set(n, i - 1);
    }
    this.#h || r || (this.#h = !0, Z(() => {
      this.#h = !1, this.flush();
    }));
  }
  /**
   * @param {Set<Effect>} dirty_effects
   * @param {Set<Effect>} maybe_dirty_effects
   */
  transfer_effects(t, n) {
    for (const r of t)
      this.#a.add(r);
    for (const r of n)
      this.#o.add(r);
    t.clear(), n.clear();
  }
  /** @param {(batch: Batch) => void} fn */
  oncommit(t) {
    this.#r.add(t);
  }
  /** @param {(batch: Batch) => void} fn */
  ondiscard(t) {
    this.#d.add(t);
  }
  /** @param {(batch: Batch) => void} fn */
  on_fork_commit(t) {
    this.#n.add(t);
  }
  run_fork_commit_callbacks() {
    for (const t of this.#n) t(this);
    this.#n.clear();
  }
  settled() {
    return (this.#l ??= dt()).promise;
  }
  static ensure() {
    if (g === null) {
      const t = g = new X();
      Ve || (ee.add(g), be || Z(() => {
        g === t && t.flush();
      }));
    }
    return g;
  }
  apply() {
    {
      D = null;
      return;
    }
  }
  /**
   *
   * @param {Effect} effect
   */
  schedule(t) {
    if (He = t, t.b?.is_pending && (t.f & (he | ke | Ke)) !== 0 && (t.f & oe) === 0) {
      t.b.defer_effect(t);
      return;
    }
    for (var n = t; n.parent !== null; ) {
      n = n.parent;
      var r = n.f;
      if (ce !== null && n === v && (p === null || (p.f & k) === 0))
        return;
      if ((r & (Q | H)) !== 0) {
        if ((r & b) === 0)
          return;
        n.f ^= b;
      }
    }
    this.#e.push(n);
  }
}
function kn(e) {
  var t = be;
  be = !0;
  try {
    for (var n; ; ) {
      if (mn(), g === null)
        return (
          /** @type {T} */
          n
        );
      g.flush();
    }
  } finally {
    be = t;
  }
}
function An() {
  try {
    cn();
  } catch (e) {
    $(e, He);
  }
}
let Y = null;
function lt(e) {
  var t = e.length;
  if (t !== 0) {
    for (var n = 0; n < t; ) {
      var r = e[n++];
      if ((r.f & (L | R)) === 0 && pe(r) && (Y = /* @__PURE__ */ new Set(), fe(r), r.deps === null && r.first === null && r.nodes === null && r.teardown === null && r.ac === null && jt(r), Y?.size > 0)) {
        ie.clear();
        for (const s of Y) {
          if ((s.f & (L | R)) !== 0) continue;
          const i = [s];
          let u = s.parent;
          for (; u !== null; )
            Y.has(u) && (Y.delete(u), i.push(u)), u = u.parent;
          for (let a = i.length - 1; a >= 0; a--) {
            const l = i[a];
            (l.f & (L | R)) === 0 && fe(l);
          }
        }
        Y.clear();
      }
    }
    Y = null;
  }
}
function mt(e, t, n, r) {
  if (!n.has(e) && (n.add(e), e.reactions !== null))
    for (const s of e.reactions) {
      const i = s.f;
      (i & k) !== 0 ? mt(
        /** @type {Derived} */
        s,
        t,
        n,
        r
      ) : (i & (Te | q)) !== 0 && (i & S) === 0 && Ze(s, t, r) && (y(s, S), Qe(
        /** @type {Effect} */
        s
      ));
    }
}
function Ze(e, t, n) {
  const r = n.get(e);
  if (r !== void 0) return r;
  if (e.deps !== null)
    for (const s of e.deps) {
      if (_e.call(t, s))
        return !0;
      if ((s.f & k) !== 0 && Ze(
        /** @type {Derived} */
        s,
        t,
        n
      ))
        return n.set(
          /** @type {Derived} */
          s,
          !0
        ), !0;
    }
  return n.set(e, !1), !1;
}
function Qe(e) {
  g.schedule(e);
}
function Tt(e, t) {
  if (!((e.f & H) !== 0 && (e.f & b) !== 0)) {
    (e.f & S) !== 0 ? t.d.push(e) : (e.f & j) !== 0 && t.m.push(e), y(e, b);
    for (var n = e.first; n !== null; )
      Tt(n, t), n = n.next;
  }
}
function St(e) {
  y(e, b);
  for (var t = e.first; t !== null; )
    St(t), t = t.next;
}
function xn(e) {
  let t = 0, n = xe(0), r;
  return () => {
    et() && (K(n), tt(() => (t === 0 && (r = Kt(() => e(() => Ee(n)))), t += 1, () => {
      Z(() => {
        t -= 1, t === 0 && (r?.(), r = void 0, Ee(n));
      });
    })));
  };
}
var Mn = me | ve;
function Pn(e, t, n, r) {
  new Rn(e, t, n, r);
}
class Rn {
  /** @type {Boundary | null} */
  parent;
  is_pending = !1;
  /**
   * API-level transformError transform function. Transforms errors before they reach the `failed` snippet.
   * Inherited from parent boundary, or defaults to identity.
   * @type {(error: unknown) => unknown}
   */
  transform_error;
  /** @type {TemplateNode} */
  #r;
  /** @type {TemplateNode | null} */
  #d = null;
  /** @type {BoundaryProps} */
  #n;
  /** @type {((anchor: Node) => void)} */
  #f;
  /** @type {Effect} */
  #t;
  /** @type {Effect | null} */
  #l = null;
  /** @type {Effect | null} */
  #e = null;
  /** @type {Effect | null} */
  #s = null;
  /** @type {DocumentFragment | null} */
  #a = null;
  #o = 0;
  #i = 0;
  #c = !1;
  /** @type {Set<Effect>} */
  #h = /* @__PURE__ */ new Set();
  /** @type {Set<Effect>} */
  #_ = /* @__PURE__ */ new Set();
  /**
   * A source containing the number of pending async deriveds/expressions.
   * Only created if `$effect.pending()` is used inside the boundary,
   * otherwise updating the source results in needless `Batch.ensure()`
   * calls followed by no-op flushes
   * @type {Source<number> | null}
   */
  #u = null;
  #g = xn(() => (this.#u = xe(this.#o), () => {
    this.#u = null;
  }));
  /**
   * @param {TemplateNode} node
   * @param {BoundaryProps} props
   * @param {((anchor: Node) => void)} children
   * @param {((error: unknown) => unknown) | undefined} [transform_error]
   */
  constructor(t, n, r, s) {
    this.#r = t, this.#n = n, this.#f = (i) => {
      var u = (
        /** @type {Effect} */
        v
      );
      u.b = this, u.f |= qe, r(i);
    }, this.parent = /** @type {Effect} */
    v.b, this.transform_error = s ?? this.parent?.transform_error ?? ((i) => i), this.#t = zn(() => {
      this.#y();
    }, Mn);
  }
  #v() {
    try {
      this.#l = te(() => this.#f(this.#r));
    } catch (t) {
      this.error(t);
    }
  }
  /**
   * @param {unknown} error The deserialized error from the server's hydration comment
   */
  #w(t) {
    const n = this.#n.failed;
    n && (this.#s = te(() => {
      n(
        this.#r,
        () => t,
        () => () => {
        }
      );
    }));
  }
  #p() {
    const t = this.#n.pending;
    t && (this.is_pending = !0, this.#e = te(() => t(this.#r)), Z(() => {
      var n = this.#a = document.createDocumentFragment(), r = Nt();
      n.append(r), this.#l = this.#E(() => te(() => this.#f(r))), this.#i === 0 && (this.#r.before(n), this.#a = null, Re(
        /** @type {Effect} */
        this.#e,
        () => {
          this.#e = null;
        }
      ), this.#b(
        /** @type {Batch} */
        g
      ));
    }));
  }
  #y() {
    try {
      if (this.is_pending = this.has_pending_snippet(), this.#i = 0, this.#o = 0, this.#l = te(() => {
        this.#f(this.#r);
      }), this.#i > 0) {
        var t = this.#a = document.createDocumentFragment();
        $n(this.#l, t);
        const n = (
          /** @type {(anchor: Node) => void} */
          this.#n.pending
        );
        this.#e = te(() => n(this.#r));
      } else
        this.#b(
          /** @type {Batch} */
          g
        );
    } catch (n) {
      this.error(n);
    }
  }
  /**
   * @param {Batch} batch
   */
  #b(t) {
    this.is_pending = !1, t.transfer_effects(this.#h, this.#_);
  }
  /**
   * Defer an effect inside a pending boundary until the boundary resolves
   * @param {Effect} effect
   */
  defer_effect(t) {
    Et(t, this.#h, this.#_);
  }
  /**
   * Returns `false` if the effect exists inside a boundary whose pending snippet is shown
   * @returns {boolean}
   */
  is_rendered() {
    return !this.is_pending && (!this.parent || this.parent.is_rendered());
  }
  has_pending_snippet() {
    return !!this.#n.pending;
  }
  /**
   * @template T
   * @param {() => T} fn
   */
  #E(t) {
    var n = v, r = p, s = E;
    I(this.#t), N(this.#t), de(this.#t.ctx);
    try {
      return X.ensure(), t();
    } catch (i) {
      return yt(i), null;
    } finally {
      I(n), N(r), de(s);
    }
  }
  /**
   * Updates the pending count associated with the currently visible pending snippet,
   * if any, such that we can replace the snippet with content once work is done
   * @param {1 | -1} d
   * @param {Batch} batch
   */
  #m(t, n) {
    if (!this.has_pending_snippet()) {
      this.parent && this.parent.#m(t, n);
      return;
    }
    this.#i += t, this.#i === 0 && (this.#b(n), this.#e && Re(this.#e, () => {
      this.#e = null;
    }), this.#a && (this.#r.before(this.#a), this.#a = null));
  }
  /**
   * Update the source that powers `$effect.pending()` inside this boundary,
   * and controls when the current `pending` snippet (if any) is removed.
   * Do not call from inside the class
   * @param {1 | -1} d
   * @param {Batch} batch
   */
  update_pending_count(t, n) {
    this.#m(t, n), this.#o += t, !(!this.#u || this.#c) && (this.#c = !0, Z(() => {
      this.#c = !1, this.#u && Ce(this.#u, this.#o);
    }));
  }
  get_effect_pending() {
    return this.#g(), K(
      /** @type {Source<number>} */
      this.#u
    );
  }
  /** @param {unknown} error */
  error(t) {
    if (!this.#n.onerror && !this.#n.failed)
      throw t;
    g?.is_fork ? (this.#l && g.skip_effect(this.#l), this.#e && g.skip_effect(this.#e), this.#s && g.skip_effect(this.#s), g.on_fork_commit(() => {
      this.#T(t);
    })) : this.#T(t);
  }
  /**
   * @param {unknown} error
   */
  #T(t) {
    this.#l && (B(this.#l), this.#l = null), this.#e && (B(this.#e), this.#e = null), this.#s && (B(this.#s), this.#s = null);
    var n = this.#n.onerror;
    let r = this.#n.failed;
    var s = !1, i = !1;
    const u = () => {
      if (s) {
        wn();
        return;
      }
      s = !0, i && vn(), this.#s !== null && Re(this.#s, () => {
        this.#s = null;
      }), this.#E(() => {
        this.#y();
      });
    }, a = (l) => {
      try {
        i = !0, n?.(l, u), i = !1;
      } catch (o) {
        $(o, this.#t && this.#t.parent);
      }
      r && (this.#s = this.#E(() => {
        try {
          return te(() => {
            var o = (
              /** @type {Effect} */
              v
            );
            o.b = this, o.f |= qe, r(
              this.#r,
              () => l,
              () => u
            );
          });
        } catch (o) {
          return $(
            o,
            /** @type {Effect} */
            this.#t.parent
          ), null;
        }
      }));
    };
    Z(() => {
      var l;
      try {
        l = this.transform_error(t);
      } catch (o) {
        $(o, this.#t && this.#t.parent);
        return;
      }
      l !== null && typeof l == "object" && typeof /** @type {any} */
      l.then == "function" ? l.then(
        a,
        /** @param {unknown} e */
        (o) => $(o, this.#t && this.#t.parent)
      ) : a(l);
    });
  }
}
function On(e, t, n, r) {
  const s = Ae() ? Xe : Cn;
  var i = e.filter((_) => !_.settled);
  if (n.length === 0 && i.length === 0) {
    r(t.map(s));
    return;
  }
  var u = (
    /** @type {Effect} */
    v
  ), a = Nn(), l = i.length === 1 ? i[0].promise : i.length > 1 ? Promise.all(i.map((_) => _.promise)) : null;
  function o(_) {
    a();
    try {
      r(_);
    } catch (d) {
      (u.f & L) === 0 && $(d, u);
    }
    Ie();
  }
  if (n.length === 0) {
    l.then(() => o(t.map(s)));
    return;
  }
  var f = kt();
  function c() {
    Promise.all(n.map((_) => /* @__PURE__ */ In(_))).then((_) => o([...t.map(s), ..._])).catch((_) => $(_, u)).finally(() => f());
  }
  l ? l.then(() => {
    a(), c(), Ie();
  }) : c();
}
function Nn() {
  var e = (
    /** @type {Effect} */
    v
  ), t = p, n = E, r = (
    /** @type {Batch} */
    g
  );
  return function(i = !0) {
    I(e), N(t), de(n), i && (e.f & L) === 0 && (r?.activate(), r?.apply());
  };
}
function Ie(e = !0) {
  I(null), N(null), de(null), e && g?.deactivate();
}
function kt() {
  var e = (
    /** @type {Effect} */
    v
  ), t = (
    /** @type {Boundary} */
    e.b
  ), n = (
    /** @type {Batch} */
    g
  ), r = t.is_rendered();
  return t.update_pending_count(1, n), n.increment(r, e), (s = !1) => {
    t.update_pending_count(-1, n), n.decrement(r, e, s);
  };
}
// @__NO_SIDE_EFFECTS__
function Xe(e) {
  var t = k | S;
  return v !== null && (v.f |= ve), {
    ctx: E,
    deps: null,
    effects: null,
    equals: pt,
    f: t,
    fn: e,
    reactions: null,
    rv: 0,
    v: (
      /** @type {V} */
      m
    ),
    wv: 0,
    parent: v,
    ac: null
  };
}
// @__NO_SIDE_EFFECTS__
function In(e, t, n) {
  let r = (
    /** @type {Effect | null} */
    v
  );
  r === null && an();
  var s = (
    /** @type {Promise<V>} */
    /** @type {unknown} */
    void 0
  ), i = xe(
    /** @type {V} */
    m
  ), u = !p, a = /* @__PURE__ */ new Map();
  return Yn(() => {
    var l = (
      /** @type {Effect} */
      v
    ), o = dt();
    s = o.promise;
    try {
      Promise.resolve(e()).then(o.resolve, o.reject).finally(Ie);
    } catch (d) {
      o.reject(d), Ie();
    }
    var f = (
      /** @type {Batch} */
      g
    );
    if (u) {
      if ((l.f & oe) !== 0)
        var c = kt();
      if (
        /** @type {Boundary} */
        r.b.is_rendered()
      )
        a.get(f)?.reject(z), a.delete(f);
      else {
        for (const d of a.values())
          d.reject(z);
        a.clear();
      }
      a.set(f, o);
    }
    const _ = (d, h = void 0) => {
      if (c) {
        var w = h === z;
        c(w);
      }
      if (!(h === z || (l.f & L) !== 0)) {
        if (f.activate(), h)
          i.f |= W, Ce(i, h);
        else {
          (i.f & W) !== 0 && (i.f ^= W), Ce(i, d);
          for (const [T, C] of a) {
            if (a.delete(T), T === f) break;
            C.reject(z);
          }
        }
        f.deactivate();
      }
    };
    o.promise.then(_, (d) => _(null, d || "unknown"));
  }), Dt(() => {
    for (const l of a.values())
      l.reject(z);
  }), new Promise((l) => {
    function o(f) {
      function c() {
        f === s ? l(i) : o(s);
      }
      f.then(c, c);
    }
    o(s);
  });
}
// @__NO_SIDE_EFFECTS__
function xr(e) {
  const t = /* @__PURE__ */ Xe(e);
  return Bt(t), t;
}
// @__NO_SIDE_EFFECTS__
function Cn(e) {
  const t = /* @__PURE__ */ Xe(e);
  return t.equals = gt, t;
}
function Dn(e) {
  var t = e.effects;
  if (t !== null) {
    e.effects = null;
    for (var n = 0; n < t.length; n += 1)
      B(
        /** @type {Effect} */
        t[n]
      );
  }
}
function Je(e) {
  var t, n = v, r = e.parent;
  if (!J && r !== null && (r.f & (L | R)) !== 0)
    return gn(), e.v;
  I(r);
  try {
    e.f &= ~ae, Dn(e), t = Ut(e);
  } finally {
    I(n);
  }
  return t;
}
function At(e) {
  var t = Je(e);
  if (!e.equals(t) && (e.wv = Yt(), (!g?.is_fork || e.deps === null) && (g !== null ? g.capture(e, t, !0) : e.v = t, e.deps === null))) {
    y(e, b);
    return;
  }
  J || (D !== null ? (et() || g?.is_fork) && D.set(e, t) : We(e));
}
function Fn(e) {
  if (e.effects !== null)
    for (const t of e.effects)
      (t.teardown || t.ac) && (t.teardown?.(), t.ac?.abort(z), t.teardown = rn, t.ac = null, Se(t, 0), nt(t));
}
function xt(e) {
  if (e.effects !== null)
    for (const t of e.effects)
      t.teardown && fe(t);
}
let Ye = /* @__PURE__ */ new Set();
const ie = /* @__PURE__ */ new Map();
let Mt = !1;
function xe(e, t) {
  var n = {
    f: 0,
    // TODO ideally we could skip this altogether, but it causes type errors
    v: e,
    reactions: null,
    equals: pt,
    rv: 0,
    wv: 0
  };
  return n;
}
// @__NO_SIDE_EFFECTS__
function U(e, t) {
  const n = xe(e);
  return Bt(n), n;
}
// @__NO_SIDE_EFFECTS__
function Mr(e, t = !1, n = !0) {
  const r = xe(e);
  return t || (r.equals = gt), De && n && E !== null && E.l !== null && (E.l.s ??= []).push(r), r;
}
function G(e, t, n = !1) {
  p !== null && // since we are untracking the function inside `$inspect.with` we need to add this check
  // to ensure we error if state is set inside an inspect effect
  (!F || (p.f & Be) !== 0) && Ae() && (p.f & (k | q | Te | Be)) !== 0 && (O === null || !_e.call(O, e)) && dn();
  let r = n ? ge(t) : t;
  return Ce(e, r, Pe);
}
function Ce(e, t, n = null) {
  if (!e.equals(t)) {
    ie.set(e, J ? t : e.v);
    var r = X.ensure();
    if (r.capture(e, t), (e.f & k) !== 0) {
      const s = (
        /** @type {Derived} */
        e
      );
      (e.f & S) !== 0 && Je(s), D === null && We(s);
    }
    e.wv = Yt(), Pt(e, S, n), Ae() && v !== null && (v.f & b) !== 0 && (v.f & (H | Q)) === 0 && (M === null ? Kn([e]) : M.push(e)), !r.is_fork && Ye.size > 0 && !Mt && Ln();
  }
  return t;
}
function Ln() {
  Mt = !1;
  for (const e of Ye)
    (e.f & b) !== 0 && y(e, j), pe(e) && fe(e);
  Ye.clear();
}
function Pr(e, t = 1) {
  var n = K(e), r = t === 1 ? n++ : n--;
  return G(e, n), r;
}
function Ee(e) {
  G(e, e.v + 1);
}
function Pt(e, t, n) {
  var r = e.reactions;
  if (r !== null)
    for (var s = Ae(), i = r.length, u = 0; u < i; u++) {
      var a = r[u], l = a.f;
      if (!(!s && a === v)) {
        var o = (l & S) === 0;
        if (o && y(a, t), (l & k) !== 0) {
          var f = (
            /** @type {Derived} */
            a
          );
          D?.delete(f), (l & ae) === 0 && (l & P && (v === null || (v.f & Ne) === 0) && (a.f |= ae), Pt(f, j, n));
        } else if (o) {
          var c = (
            /** @type {Effect} */
            a
          );
          (l & q) !== 0 && Y !== null && Y.add(c), n !== null ? n.push(c) : Qe(c);
        }
      }
    }
}
function ge(e) {
  if (typeof e != "object" || e === null || se in e)
    return e;
  const t = ht(e);
  if (t !== tn && t !== nn)
    return e;
  var n = /* @__PURE__ */ new Map(), r = Zt(e), s = /* @__PURE__ */ U(0), i = le, u = (a) => {
    if (le === i)
      return a();
    var l = p, o = le;
    N(null), ct(i);
    var f = a();
    return N(l), ct(o), f;
  };
  return r && n.set("length", /* @__PURE__ */ U(
    /** @type {any[]} */
    e.length
  )), new Proxy(
    /** @type {any} */
    e,
    {
      defineProperty(a, l, o) {
        (!("value" in o) || o.configurable === !1 || o.enumerable === !1 || o.writable === !1) && _n();
        var f = n.get(l);
        return f === void 0 ? u(() => {
          var c = /* @__PURE__ */ U(o.value);
          return n.set(l, c), c;
        }) : G(f, o.value, !0), !0;
      },
      deleteProperty(a, l) {
        var o = n.get(l);
        if (o === void 0) {
          if (l in a) {
            const f = u(() => /* @__PURE__ */ U(m));
            n.set(l, f), Ee(s);
          }
        } else
          G(o, m), Ee(s);
        return !0;
      },
      get(a, l, o) {
        if (l === se)
          return e;
        var f = n.get(l), c = l in a;
        if (f === void 0 && (!c || ye(a, l)?.writable) && (f = u(() => {
          var d = ge(c ? a[l] : m), h = /* @__PURE__ */ U(d);
          return h;
        }), n.set(l, f)), f !== void 0) {
          var _ = K(f);
          return _ === m ? void 0 : _;
        }
        return Reflect.get(a, l, o);
      },
      getOwnPropertyDescriptor(a, l) {
        var o = Reflect.getOwnPropertyDescriptor(a, l);
        if (o && "value" in o) {
          var f = n.get(l);
          f && (o.value = K(f));
        } else if (o === void 0) {
          var c = n.get(l), _ = c?.v;
          if (c !== void 0 && _ !== m)
            return {
              enumerable: !0,
              configurable: !0,
              value: _,
              writable: !0
            };
        }
        return o;
      },
      has(a, l) {
        if (l === se)
          return !0;
        var o = n.get(l), f = o !== void 0 && o.v !== m || Reflect.has(a, l);
        if (o !== void 0 || v !== null && (!f || ye(a, l)?.writable)) {
          o === void 0 && (o = u(() => {
            var _ = f ? ge(a[l]) : m, d = /* @__PURE__ */ U(_);
            return d;
          }), n.set(l, o));
          var c = K(o);
          if (c === m)
            return !1;
        }
        return f;
      },
      set(a, l, o, f) {
        var c = n.get(l), _ = l in a;
        if (r && l === "length")
          for (var d = o; d < /** @type {Source<number>} */
          c.v; d += 1) {
            var h = n.get(d + "");
            h !== void 0 ? G(h, m) : d in a && (h = u(() => /* @__PURE__ */ U(m)), n.set(d + "", h));
          }
        if (c === void 0)
          (!_ || ye(a, l)?.writable) && (c = u(() => /* @__PURE__ */ U(void 0)), G(c, ge(o)), n.set(l, c));
        else {
          _ = c.v !== m;
          var w = u(() => ge(o));
          G(c, w);
        }
        var T = Reflect.getOwnPropertyDescriptor(a, l);
        if (T?.set && T.set.call(f, o), !_) {
          if (r && typeof l == "string") {
            var C = (
              /** @type {Source<number>} */
              n.get("length")
            ), ue = Number(l);
            Number.isInteger(ue) && ue >= C.v && G(C, ue + 1);
          }
          Ee(s);
        }
        return !0;
      },
      ownKeys(a) {
        K(s);
        var l = Reflect.ownKeys(a).filter((c) => {
          var _ = n.get(c);
          return _ === void 0 || _.v !== m;
        });
        for (var [o, f] of n)
          f.v !== m && !(o in a) && l.push(o);
        return l;
      },
      setPrototypeOf() {
        hn();
      }
    }
  );
}
function at(e) {
  try {
    if (e !== null && typeof e == "object" && se in e)
      return e[se];
  } catch {
  }
  return e;
}
function Rr(e, t) {
  return Object.is(at(e), at(t));
}
var ft, jn, Rt, Ot;
function Vn() {
  if (ft === void 0) {
    ft = window, jn = /Firefox/.test(navigator.userAgent);
    var e = Element.prototype, t = Node.prototype, n = Text.prototype;
    Rt = ye(t, "firstChild").get, Ot = ye(t, "nextSibling").get, rt(e) && (e.__click = void 0, e.__className = void 0, e.__attributes = null, e.__style = void 0, e.__e = void 0), rt(n) && (n.__t = void 0);
  }
}
function Nt(e = "") {
  return document.createTextNode(e);
}
// @__NO_SIDE_EFFECTS__
function It(e) {
  return (
    /** @type {TemplateNode | null} */
    Rt.call(e)
  );
}
// @__NO_SIDE_EFFECTS__
function Fe(e) {
  return (
    /** @type {TemplateNode | null} */
    Ot.call(e)
  );
}
function Or(e, t) {
  return /* @__PURE__ */ It(e);
}
function Nr(e, t = !1) {
  {
    var n = /* @__PURE__ */ It(e);
    return n instanceof Comment && n.data === "" ? /* @__PURE__ */ Fe(n) : n;
  }
}
function Ir(e, t = 1, n = !1) {
  let r = e;
  for (; t--; )
    r = /** @type {TemplateNode} */
    /* @__PURE__ */ Fe(r);
  return r;
}
function Cr(e) {
  e.textContent = "";
}
function Dr() {
  return !1;
}
function Fr(e, t, n) {
  return (
    /** @type {T extends keyof HTMLElementTagNameMap ? HTMLElementTagNameMap[T] : Element} */
    document.createElementNS(t ?? pn, e, void 0)
  );
}
function Lr(e, t) {
  if (t) {
    const n = document.body;
    e.autofocus = !0, Z(() => {
      document.activeElement === n && e.focus();
    });
  }
}
let ot = !1;
function qn() {
  ot || (ot = !0, document.addEventListener(
    "reset",
    (e) => {
      Promise.resolve().then(() => {
        if (!e.defaultPrevented)
          for (
            const t of
            /**@type {HTMLFormElement} */
            e.target.elements
          )
            t.__on_r?.();
      });
    },
    // In the capture phase to guarantee we get noticed of it (no possibility of stopPropagation)
    { capture: !0 }
  ));
}
function Le(e) {
  var t = p, n = v;
  N(null), I(null);
  try {
    return e();
  } finally {
    N(t), I(n);
  }
}
function jr(e, t, n, r = n) {
  e.addEventListener(t, () => Le(n));
  const s = e.__on_r;
  s ? e.__on_r = () => {
    s(), r(!0);
  } : e.__on_r = () => r(!0), qn();
}
function Ct(e) {
  v === null && (p === null && un(), on()), J && fn();
}
function Bn(e, t) {
  var n = t.last;
  n === null ? t.last = t.first = e : (n.next = e, e.prev = n, t.last = e);
}
function V(e, t) {
  var n = v;
  n !== null && (n.f & R) !== 0 && (e |= R);
  var r = {
    ctx: E,
    deps: null,
    nodes: null,
    f: e | S | P,
    first: null,
    fn: t,
    last: null,
    next: null,
    parent: n,
    b: n && n.b,
    prev: null,
    teardown: null,
    wv: 0,
    ac: null
  };
  g?.register_created_effect(r);
  var s = r;
  if ((e & he) !== 0)
    ce !== null ? ce.push(r) : X.ensure().schedule(r);
  else if (t !== null) {
    try {
      fe(r);
    } catch (u) {
      throw B(r), u;
    }
    s.deps === null && s.teardown === null && s.nodes === null && s.first === s.last && // either `null`, or a singular child
    (s.f & ve) === 0 && (s = s.first, (e & q) !== 0 && (e & me) !== 0 && s !== null && (s.f |= me));
  }
  if (s !== null && (s.parent = n, n !== null && Bn(s, n), p !== null && (p.f & k) !== 0 && (e & Q) === 0)) {
    var i = (
      /** @type {Derived} */
      p
    );
    (i.effects ??= []).push(s);
  }
  return r;
}
function et() {
  return p !== null && !F;
}
function Dt(e) {
  const t = V(ke, null);
  return y(t, b), t.teardown = e, t;
}
function Vr(e) {
  Ct();
  var t = (
    /** @type {Effect} */
    v.f
  ), n = !p && (t & H) !== 0 && (t & oe) === 0;
  if (n) {
    var r = (
      /** @type {ComponentContext} */
      E
    );
    (r.e ??= []).push(e);
  } else
    return Ft(e);
}
function Ft(e) {
  return V(he | vt, e);
}
function qr(e) {
  return Ct(), V(ke | vt, e);
}
function Hn(e) {
  X.ensure();
  const t = V(Q | ve, e);
  return (n = {}) => new Promise((r) => {
    n.outro ? Re(t, () => {
      B(t), r(void 0);
    }) : (B(t), r(void 0));
  });
}
function Br(e) {
  return V(he, e);
}
function Hr(e, t) {
  var n = (
    /** @type {ComponentContextLegacy} */
    E
  ), r = { effect: null, ran: !1, deps: e };
  n.l.$.push(r), r.effect = tt(() => {
    if (e(), !r.ran) {
      r.ran = !0;
      var s = (
        /** @type {Effect} */
        v
      );
      try {
        I(s.parent), Kt(t);
      } finally {
        I(s);
      }
    }
  });
}
function Yr() {
  var e = (
    /** @type {ComponentContextLegacy} */
    E
  );
  tt(() => {
    for (var t of e.l.$) {
      t.deps();
      var n = t.effect;
      (n.f & b) !== 0 && n.deps !== null && y(n, j), pe(n) && fe(n), t.ran = !1;
    }
  });
}
function Yn(e) {
  return V(Te | ve, e);
}
function tt(e, t = 0) {
  return V(ke | t, e);
}
function zr(e, t = [], n = [], r = []) {
  On(r, t, n, (s) => {
    V(ke, () => e(...s.map(K)));
  });
}
function zn(e, t = 0) {
  var n = V(q | t, e);
  return n;
}
function Ur(e, t = 0) {
  var n = V(Ke | t, e);
  return n;
}
function te(e) {
  return V(H | ve, e);
}
function Lt(e) {
  var t = e.teardown;
  if (t !== null) {
    const n = J, r = p;
    ut(!0), N(null);
    try {
      t.call(null);
    } finally {
      ut(n), N(r);
    }
  }
}
function nt(e, t = !1) {
  var n = e.first;
  for (e.first = e.last = null; n !== null; ) {
    const s = n.ac;
    s !== null && Le(() => {
      s.abort(z);
    });
    var r = n.next;
    (n.f & Q) !== 0 ? n.parent = null : B(n, t), n = r;
  }
}
function Un(e) {
  for (var t = e.first; t !== null; ) {
    var n = t.next;
    (t.f & H) === 0 && B(t), t = n;
  }
}
function B(e, t = !0) {
  var n = !1;
  (t || (e.f & ln) !== 0) && e.nodes !== null && e.nodes.end !== null && (Gn(
    e.nodes.start,
    /** @type {TemplateNode} */
    e.nodes.end
  ), n = !0), y(e, st), nt(e, t && !n), Se(e, 0);
  var r = e.nodes && e.nodes.t;
  if (r !== null)
    for (const i of r)
      i.stop();
  Lt(e), e.f ^= st, e.f |= L;
  var s = e.parent;
  s !== null && s.first !== null && jt(e), e.next = e.prev = e.teardown = e.ctx = e.deps = e.fn = e.nodes = e.ac = e.b = null;
}
function Gn(e, t) {
  for (; e !== null; ) {
    var n = e === t ? null : /* @__PURE__ */ Fe(e);
    e.remove(), e = n;
  }
}
function jt(e) {
  var t = e.parent, n = e.prev, r = e.next;
  n !== null && (n.next = r), r !== null && (r.prev = n), t !== null && (t.first === e && (t.first = r), t.last === e && (t.last = n));
}
function Re(e, t, n = !0) {
  var r = [];
  Vt(e, r, !0);
  var s = () => {
    n && B(e), t && t();
  }, i = r.length;
  if (i > 0) {
    var u = () => --i || s();
    for (var a of r)
      a.out(u);
  } else
    s();
}
function Vt(e, t, n) {
  if ((e.f & R) === 0) {
    e.f ^= R;
    var r = e.nodes && e.nodes.t;
    if (r !== null)
      for (const a of r)
        (a.is_global || n) && t.push(a);
    for (var s = e.first; s !== null; ) {
      var i = s.next;
      if ((s.f & Q) === 0) {
        var u = (s.f & me) !== 0 || // If this is a branch effect without a block effect parent,
        // it means the parent block effect was pruned. In that case,
        // transparency information was transferred to the branch effect.
        (s.f & H) !== 0 && (e.f & q) !== 0;
        Vt(s, t, u ? n : !1);
      }
      s = i;
    }
  }
}
function Gr(e) {
  qt(e, !0);
}
function qt(e, t) {
  if ((e.f & R) !== 0) {
    e.f ^= R, (e.f & b) === 0 && (y(e, S), X.ensure().schedule(e));
    for (var n = e.first; n !== null; ) {
      var r = n.next, s = (n.f & me) !== 0 || (n.f & H) !== 0;
      qt(n, s ? t : !1), n = r;
    }
    var i = e.nodes && e.nodes.t;
    if (i !== null)
      for (const u of i)
        (u.is_global || t) && u.in();
  }
}
function $n(e, t) {
  if (e.nodes)
    for (var n = e.nodes.start, r = e.nodes.end; n !== null; ) {
      var s = n === r ? null : /* @__PURE__ */ Fe(n);
      t.append(n), n = s;
    }
}
let Oe = !1, J = !1;
function ut(e) {
  J = e;
}
let p = null, F = !1;
function N(e) {
  p = e;
}
let v = null;
function I(e) {
  v = e;
}
let O = null;
function Bt(e) {
  p !== null && (O === null ? O = [e] : O.push(e));
}
let A = null, x = 0, M = null;
function Kn(e) {
  M = e;
}
let Ht = 1, re = 0, le = re;
function ct(e) {
  le = e;
}
function Yt() {
  return ++Ht;
}
function pe(e) {
  var t = e.f;
  if ((t & S) !== 0)
    return !0;
  if (t & k && (e.f &= ~ae), (t & j) !== 0) {
    for (var n = (
      /** @type {Value[]} */
      e.deps
    ), r = n.length, s = 0; s < r; s++) {
      var i = n[s];
      if (pe(
        /** @type {Derived} */
        i
      ) && At(
        /** @type {Derived} */
        i
      ), i.wv > e.wv)
        return !0;
    }
    (t & P) !== 0 && // During time traveling we don't want to reset the status so that
    // traversal of the graph in the other batches still happens
    D === null && y(e, b);
  }
  return !1;
}
function zt(e, t, n = !0) {
  var r = e.reactions;
  if (r !== null && !(O !== null && _e.call(O, e)))
    for (var s = 0; s < r.length; s++) {
      var i = r[s];
      (i.f & k) !== 0 ? zt(
        /** @type {Derived} */
        i,
        t,
        !1
      ) : t === i && (n ? y(i, S) : (i.f & b) !== 0 && y(i, j), Qe(
        /** @type {Effect} */
        i
      ));
    }
}
function Ut(e) {
  var t = A, n = x, r = M, s = p, i = O, u = E, a = F, l = le, o = e.f;
  A = /** @type {null | Value[]} */
  null, x = 0, M = null, p = (o & (H | Q)) === 0 ? e : null, O = null, de(e.ctx), F = !1, le = ++re, e.ac !== null && (Le(() => {
    e.ac.abort(z);
  }), e.ac = null);
  try {
    e.f |= Ne;
    var f = (
      /** @type {Function} */
      e.fn
    ), c = f();
    e.f |= oe;
    var _ = e.deps, d = g?.is_fork;
    if (A !== null) {
      var h;
      if (d || Se(e, x), _ !== null && x > 0)
        for (_.length = x + A.length, h = 0; h < A.length; h++)
          _[x + h] = A[h];
      else
        e.deps = _ = A;
      if (et() && (e.f & P) !== 0)
        for (h = x; h < _.length; h++)
          (_[h].reactions ??= []).push(e);
    } else !d && _ !== null && x < _.length && (Se(e, x), _.length = x);
    if (Ae() && M !== null && !F && _ !== null && (e.f & (k | j | S)) === 0)
      for (h = 0; h < /** @type {Source[]} */
      M.length; h++)
        zt(
          M[h],
          /** @type {Effect} */
          e
        );
    if (s !== null && s !== e) {
      if (re++, s.deps !== null)
        for (let w = 0; w < n; w += 1)
          s.deps[w].rv = re;
      if (t !== null)
        for (const w of t)
          w.rv = re;
      M !== null && (r === null ? r = M : r.push(.../** @type {Source[]} */
      M));
    }
    return (e.f & W) !== 0 && (e.f ^= W), c;
  } catch (w) {
    return yt(w);
  } finally {
    e.f ^= Ne, A = t, x = n, M = r, p = s, O = i, de(u), F = a, le = l;
  }
}
function Wn(e, t) {
  let n = t.reactions;
  if (n !== null) {
    var r = Qt.call(n, e);
    if (r !== -1) {
      var s = n.length - 1;
      s === 0 ? n = t.reactions = null : (n[r] = n[s], n.pop());
    }
  }
  if (n === null && (t.f & k) !== 0 && // Destroying a child effect while updating a parent effect can cause a dependency to appear
  // to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
  // allows us to skip the expensive work of disconnecting and immediately reconnecting it
  (A === null || !_e.call(A, t))) {
    var i = (
      /** @type {Derived} */
      t
    );
    (i.f & P) !== 0 && (i.f ^= P, i.f &= ~ae), i.v !== m && We(i), Fn(i), Se(i, 0);
  }
}
function Se(e, t) {
  var n = e.deps;
  if (n !== null)
    for (var r = t; r < n.length; r++)
      Wn(e, n[r]);
}
function fe(e) {
  var t = e.f;
  if ((t & L) === 0) {
    y(e, b);
    var n = v, r = Oe;
    v = e, Oe = !0;
    try {
      (t & (q | Ke)) !== 0 ? Un(e) : nt(e), Lt(e);
      var s = Ut(e);
      e.teardown = typeof s == "function" ? s : null, e.wv = Ht;
      var i;
    } finally {
      Oe = r, v = n;
    }
  }
}
async function $r() {
  await Promise.resolve(), kn();
}
function K(e) {
  var t = e.f, n = (t & k) !== 0;
  if (p !== null && !F) {
    var r = v !== null && (v.f & L) !== 0;
    if (!r && (O === null || !_e.call(O, e))) {
      var s = p.deps;
      if ((p.f & Ne) !== 0)
        e.rv < re && (e.rv = re, A === null && s !== null && s[x] === e ? x++ : A === null ? A = [e] : A.push(e));
      else {
        (p.deps ??= []).push(e);
        var i = e.reactions;
        i === null ? e.reactions = [p] : _e.call(i, p) || i.push(p);
      }
    }
  }
  if (J && ie.has(e))
    return ie.get(e);
  if (n) {
    var u = (
      /** @type {Derived} */
      e
    );
    if (J) {
      var a = u.v;
      return ((u.f & b) === 0 && u.reactions !== null || $t(u)) && (a = Je(u)), ie.set(u, a), a;
    }
    var l = (u.f & P) === 0 && !F && p !== null && (Oe || (p.f & P) !== 0), o = (u.f & oe) === 0;
    pe(u) && (l && (u.f |= P), At(u)), l && !o && (xt(u), Gt(u));
  }
  if (D?.has(e))
    return D.get(e);
  if ((e.f & W) !== 0)
    throw e.v;
  return e.v;
}
function Gt(e) {
  if (e.f |= P, e.deps !== null)
    for (const t of e.deps)
      (t.reactions ??= []).push(e), (t.f & k) !== 0 && (t.f & P) === 0 && (xt(
        /** @type {Derived} */
        t
      ), Gt(
        /** @type {Derived} */
        t
      ));
}
function $t(e) {
  if (e.v === m) return !0;
  if (e.deps === null) return !1;
  for (const t of e.deps)
    if (ie.has(t) || (t.f & k) !== 0 && $t(
      /** @type {Derived} */
      t
    ))
      return !0;
  return !1;
}
function Kt(e) {
  var t = F;
  try {
    return F = !0, e();
  } finally {
    F = t;
  }
}
function Kr(e) {
  if (!(typeof e != "object" || !e || e instanceof EventTarget)) {
    if (se in e)
      ze(e);
    else if (!Array.isArray(e))
      for (let t in e) {
        const n = e[t];
        typeof n == "object" && n && se in n && ze(n);
      }
  }
}
function ze(e, t = /* @__PURE__ */ new Set()) {
  if (typeof e == "object" && e !== null && // We don't want to traverse DOM elements
  !(e instanceof EventTarget) && !t.has(e)) {
    t.add(e), e instanceof Date && e.getTime();
    for (let r in e)
      try {
        ze(e[r], t);
      } catch {
      }
    const n = ht(e);
    if (n !== Object.prototype && n !== Array.prototype && n !== Map.prototype && n !== Set.prototype && n !== Date.prototype) {
      const r = en(n);
      for (let s in r) {
        const i = r[s].get;
        if (i)
          try {
            i.call(e);
          } catch {
          }
      }
    }
  }
}
function Wr(e) {
  return e.endsWith("capture") && e !== "gotpointercapture" && e !== "lostpointercapture";
}
const Zn = [
  "beforeinput",
  "click",
  "change",
  "dblclick",
  "contextmenu",
  "focusin",
  "focusout",
  "input",
  "keydown",
  "keyup",
  "mousedown",
  "mousemove",
  "mouseout",
  "mouseover",
  "mouseup",
  "pointerdown",
  "pointermove",
  "pointerout",
  "pointerover",
  "pointerup",
  "touchend",
  "touchmove",
  "touchstart"
];
function Zr(e) {
  return Zn.includes(e);
}
const Qn = {
  // no `class: 'className'` because we handle that separately
  formnovalidate: "formNoValidate",
  ismap: "isMap",
  nomodule: "noModule",
  playsinline: "playsInline",
  readonly: "readOnly",
  defaultvalue: "defaultValue",
  defaultchecked: "defaultChecked",
  srcobject: "srcObject",
  novalidate: "noValidate",
  allowfullscreen: "allowFullscreen",
  disablepictureinpicture: "disablePictureInPicture",
  disableremoteplayback: "disableRemotePlayback"
};
function Qr(e) {
  return e = e.toLowerCase(), Qn[e] ?? e;
}
const Xn = ["touchstart", "touchmove"];
function Jn(e) {
  return Xn.includes(e);
}
const we = /* @__PURE__ */ Symbol("events"), Wt = /* @__PURE__ */ new Set(), Ue = /* @__PURE__ */ new Set();
function er(e, t, n, r = {}) {
  function s(i) {
    if (r.capture || Ge.call(t, i), !i.cancelBubble)
      return Le(() => n?.call(this, i));
  }
  return e.startsWith("pointer") || e.startsWith("touch") || e === "wheel" ? Z(() => {
    t.addEventListener(e, s, r);
  }) : t.addEventListener(e, s, r), s;
}
function Xr(e, t, n, r, s) {
  var i = { capture: r, passive: s }, u = er(e, t, n, i);
  (t === document.body || // @ts-ignore
  t === window || // @ts-ignore
  t === document || // Firefox has quirky behavior, it can happen that we still get "canplay" events when the element is already removed
  t instanceof HTMLMediaElement) && Dt(() => {
    t.removeEventListener(e, u, i);
  });
}
function Jr(e, t, n) {
  (t[we] ??= {})[e] = n;
}
function es(e) {
  for (var t = 0; t < e.length; t++)
    Wt.add(e[t]);
  for (var n of Ue)
    n(e);
}
let _t = null;
function Ge(e) {
  var t = this, n = (
    /** @type {Node} */
    t.ownerDocument
  ), r = e.type, s = e.composedPath?.() || [], i = (
    /** @type {null | Element} */
    s[0] || e.target
  );
  _t = e;
  var u = 0, a = _t === e && e[we];
  if (a) {
    var l = s.indexOf(a);
    if (l !== -1 && (t === document || t === /** @type {any} */
    window)) {
      e[we] = t;
      return;
    }
    var o = s.indexOf(t);
    if (o === -1)
      return;
    l <= o && (u = l);
  }
  if (i = /** @type {Element} */
  s[u] || e.target, i !== t) {
    Jt(e, "currentTarget", {
      configurable: !0,
      get() {
        return i || n;
      }
    });
    var f = p, c = v;
    N(null), I(null);
    try {
      for (var _, d = []; i !== null; ) {
        var h = i.assignedSlot || i.parentNode || /** @type {any} */
        i.host || null;
        try {
          var w = i[we]?.[r];
          w != null && (!/** @type {any} */
          i.disabled || // DOM could've been updated already by the time this is reached, so we check this as well
          // -> the target could not have been disabled because it emits the event in the first place
          e.target === i) && w.call(i, e);
        } catch (T) {
          _ ? d.push(T) : _ = T;
        }
        if (e.cancelBubble || h === t || h === null)
          break;
        i = h;
      }
      if (_) {
        for (let T of d)
          queueMicrotask(() => {
            throw T;
          });
        throw _;
      }
    } finally {
      e[we] = t, delete e.currentTarget, N(f), I(c);
    }
  }
}
function ts(e, t) {
  var n = t == null ? "" : typeof t == "object" ? `${t}` : t;
  n !== (e.__t ??= e.nodeValue) && (e.__t = n, e.nodeValue = `${n}`);
}
function ns(e, t) {
  return tr(e, t);
}
const Me = /* @__PURE__ */ new Map();
function tr(e, { target: t, anchor: n, props: r = {}, events: s, context: i, intro: u = !0, transformError: a }) {
  Vn();
  var l = void 0, o = Hn(() => {
    var f = n ?? t.appendChild(Nt());
    Pn(
      /** @type {TemplateNode} */
      f,
      {
        pending: () => {
        }
      },
      (d) => {
        bn({});
        var h = (
          /** @type {ComponentContext} */
          E
        );
        i && (h.c = i), s && (r.$$events = s), l = e(d, r) || {}, En();
      },
      a
    );
    var c = /* @__PURE__ */ new Set(), _ = (d) => {
      for (var h = 0; h < d.length; h++) {
        var w = d[h];
        if (!c.has(w)) {
          c.add(w);
          var T = Jn(w);
          for (const je of [t, document]) {
            var C = Me.get(je);
            C === void 0 && (C = /* @__PURE__ */ new Map(), Me.set(je, C));
            var ue = C.get(w);
            ue === void 0 ? (je.addEventListener(w, Ge, { passive: T }), C.set(w, 1)) : C.set(w, ue + 1);
          }
        }
      }
    };
    return _(Xt(Wt)), Ue.add(_), () => {
      for (var d of c)
        for (const T of [t, document]) {
          var h = (
            /** @type {Map<string, number>} */
            Me.get(T)
          ), w = (
            /** @type {number} */
            h.get(d)
          );
          --w == 0 ? (T.removeEventListener(d, Ge), h.delete(d), h.size === 0 && Me.delete(T)) : h.set(d, w);
        }
      Ue.delete(_), f !== n && f.parentNode?.removeChild(f);
    };
  });
  return $e.set(l, o), l;
}
let $e = /* @__PURE__ */ new WeakMap();
function rs(e, t) {
  const n = $e.get(e);
  return n ? ($e.delete(e), n(t)) : Promise.resolve();
}
const ss = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null
}, Symbol.toStringTag, { value: "Module" })), is = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null
}, Symbol.toStringTag, { value: "Module" }));
export {
  Kr as $,
  Dr as A,
  zn as B,
  _r as C,
  Ce as D,
  me as E,
  rr as F,
  fr as G,
  Cn as H,
  Xt as I,
  ur as J,
  dr as K,
  xe as L,
  cr as M,
  L as N,
  R as O,
  Z as P,
  H as Q,
  hr as R,
  Cr as S,
  br as T,
  Fe as U,
  zr as V,
  Gn as W,
  mr as X,
  Tr as Y,
  Br as Z,
  tt as _,
  Kt as a,
  Ur as a0,
  kr as a1,
  Rr as a2,
  ir as a3,
  pn as a4,
  ar as a5,
  en as a6,
  On as a7,
  Sr as a8,
  Wr as a9,
  sr as aA,
  Pr as aB,
  I as aC,
  U as aD,
  Ar as aE,
  bn as aF,
  En as aG,
  Nr as aH,
  Ir as aI,
  Or as aJ,
  ts as aK,
  Xr as aL,
  xr as aM,
  Hr as aN,
  Yr as aO,
  ft as aP,
  ss as aQ,
  is as aR,
  Jr as aa,
  es as ab,
  er as ac,
  Lr as ad,
  Qr as ae,
  m as af,
  Zr as ag,
  jr as ah,
  $r as ai,
  E as aj,
  st as ak,
  se as al,
  qr as am,
  Vr as an,
  nr as ao,
  Xe as ap,
  ye as aq,
  or as ar,
  gr as as,
  ge as at,
  wr as au,
  De as av,
  pr as aw,
  vr as ax,
  yr as ay,
  J as az,
  Mr as b,
  G as c,
  K as d,
  Jt as e,
  Fr as f,
  ht as g,
  It as h,
  Zt as i,
  jn as j,
  Er as k,
  v as l,
  ns as m,
  rn as n,
  tn as o,
  Nt as p,
  Gr as q,
  sn as r,
  yn as s,
  Dt as t,
  rs as u,
  B as v,
  Re as w,
  te as x,
  g as y,
  $n as z
};
