import { i as sr, g as Ai, o as No, n as kn, a as ct, s as Ii, r as ra, t as Oi, b as Un, c as _, d as i, e as Ro, f as Ci, h as tn, j as Bo, T as Li, k as Mo, l as zn, p as In, q as ba, v as On, w as ya, x as Cn, y as An, z as Pi, A as Hi, B as Pr, E as wa, C as Ni, D as Fa, F as sn, G as Do, H as Dn, I as xa, J as Uo, K as jo, L as aa, M as Fo, N as Ri, O as jr, P as Go, Q as zo, R as Wo, S as Vo, U as qo, V as F, W as Xo, X as Zo, Y as Jo, Z as lr, _ as ka, $ as xt, a0 as Bi, a1 as Yo, a2 as Qo, a3 as Ko, a4 as $o, a5 as Ea, a6 as es, a7 as ts, a8 as ns, a9 as rs, aa as z, ab as un, ac as as, ad as $n, ae as is, af as os, ag as ss, ah as ls, ai as Rn, aj as Ta, ak as us, al as Mi, am as Di, an as Jt, ao as cs, ap as Ui, aq as ds, ar as fs, as as ji, at as zt, au as hs, av as vs, aw as ps, ax as gs, ay as ms, az as _s, aA as bs, aB as Ga, aC as za, aD as ne, aE as ys, aF as Wt, aG as Vt, aH as be, aI as I, aJ as k, aK as Y, aL as Oe, aM as pe, aN as ws, aO as xs, aP as ks } from "./FileBlob-7MRLQ6TG-DtQ5hfc_.js";
function Es(e) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
const Ts = [];
function Ss(e, t = !1, n = !1) {
  return yr(e, /* @__PURE__ */ new Map(), "", Ts, null, n);
}
function yr(e, t, n, r, a = null, o = !1) {
  if (typeof e == "object" && e !== null) {
    var s = t.get(e);
    if (s !== void 0) return s;
    if (e instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(e)
    );
    if (e instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(e)
    );
    if (sr(e)) {
      var l = (
        /** @type {Snapshot<any>} */
        Array(e.length)
      );
      t.set(e, l), a !== null && t.set(a, l);
      for (var u = 0; u < e.length; u += 1) {
        var c = e[u];
        u in e && (l[u] = yr(c, t, n, r, null, o));
      }
      return l;
    }
    if (Ai(e) === No) {
      l = {}, t.set(e, l), a !== null && t.set(a, l);
      for (var v of Object.keys(e))
        l[v] = yr(
          // @ts-expect-error
          e[v],
          t,
          n,
          r,
          null,
          o
        );
      return l;
    }
    if (e instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(e)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    e.toJSON == "function" && !o)
      return yr(
        /** @type {T & { toJSON(): any } } */
        e.toJSON(),
        t,
        n,
        r,
        // Associate the instance with the toJSON clone
        e
      );
  }
  if (e instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      e
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(e)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      e
    );
  }
}
function Sa(e, t, n) {
  if (e == null)
    return t(void 0), n && n(void 0), kn;
  const r = ct(
    () => e.subscribe(
      t,
      // @ts-expect-error
      n
    )
  );
  return r.unsubscribe ? () => r.unsubscribe() : r;
}
const Nn = [];
function As(e, t) {
  return {
    subscribe: ur(e, t).subscribe
  };
}
function ur(e, t = kn) {
  let n = null;
  const r = /* @__PURE__ */ new Set();
  function a(l) {
    if (Ii(e, l) && (e = l, n)) {
      const u = !Nn.length;
      for (const c of r)
        c[1](), Nn.push(c, e);
      if (u) {
        for (let c = 0; c < Nn.length; c += 2)
          Nn[c][0](Nn[c + 1]);
        Nn.length = 0;
      }
    }
  }
  function o(l) {
    a(l(
      /** @type {T} */
      e
    ));
  }
  function s(l, u = kn) {
    const c = [l, u];
    return r.add(c), r.size === 1 && (n = t(a, o) || kn), l(
      /** @type {T} */
      e
    ), () => {
      r.delete(c), r.size === 0 && n && (n(), n = null);
    };
  }
  return { set: a, update: o, subscribe: s };
}
function Wn(e, t, n) {
  const r = !Array.isArray(e), a = r ? [e] : e;
  if (!a.every(Boolean))
    throw new Error("derived() expects stores as input, got a falsy value");
  const o = t.length < 2;
  return As(n, (s, l) => {
    let u = !1;
    const c = [];
    let v = 0, T = kn;
    const f = () => {
      if (v)
        return;
      T();
      const C = t(r ? c[0] : c, s, l);
      o ? s(C) : T = typeof C == "function" ? C : kn;
    }, p = a.map(
      (C, S) => Sa(
        C,
        (h) => {
          c[S] = h, v &= ~(1 << S), u && f();
        },
        () => {
          v |= 1 << S;
        }
      )
    );
    return u = !0, f(), function() {
      ra(p), T(), u = !1;
    };
  });
}
function Is(e) {
  let t;
  return Sa(e, (n) => t = n)(), t;
}
let gr = !1, ia = /* @__PURE__ */ Symbol();
function Fi(e, t, n) {
  const r = n[t] ??= {
    store: null,
    source: Un(void 0),
    unsubscribe: kn
  };
  if (r.store !== e && !(ia in n))
    if (r.unsubscribe(), r.store = e ?? null, e == null)
      r.source.v = void 0, r.unsubscribe = kn;
    else {
      var a = !0;
      r.unsubscribe = Sa(e, (o) => {
        a ? r.source.v = o : _(r.source, o);
      }), a = !1;
    }
  return e && ia in n ? Is(e) : i(r.source);
}
function Gi() {
  const e = {};
  function t() {
    Oi(() => {
      for (var n in e)
        e[n].unsubscribe();
      Ro(e, ia, {
        enumerable: !1,
        value: !0
      });
    });
  }
  return [e, t];
}
function Os(e) {
  var t = gr;
  try {
    return gr = !1, [e(), gr];
  } finally {
    gr = t;
  }
}
const Cs = (
  // We gotta write it like this because after downleveling the pure comment may end up in the wrong location
  globalThis?.window?.trustedTypes && /* @__PURE__ */ globalThis.window.trustedTypes.createPolicy("svelte-trusted-html", {
    /** @param {string} html */
    createHTML: (e) => e
  })
);
function Ls(e) {
  return (
    /** @type {string} */
    Cs?.createHTML(e) ?? e
  );
}
function zi(e) {
  var t = Ci("template");
  return t.innerHTML = Ls(e.replaceAll("<!>", "<!---->")), t.content;
}
function En(e, t) {
  var n = (
    /** @type {Effect} */
    zn
  );
  n.nodes === null && (n.nodes = { start: e, end: t, a: null, t: null });
}
// @__NO_SIDE_EFFECTS__
function P(e, t) {
  var n = (t & Li) !== 0, r = (t & Mo) !== 0, a, o = !e.startsWith("<!>");
  return () => {
    a === void 0 && (a = zi(o ? e : "<!>" + e), n || (a = /** @type {TemplateNode} */
    tn(a)));
    var s = (
      /** @type {TemplateNode} */
      r || Bo ? document.importNode(a, !0) : a.cloneNode(!0)
    );
    if (n) {
      var l = (
        /** @type {TemplateNode} */
        tn(s)
      ), u = (
        /** @type {TemplateNode} */
        s.lastChild
      );
      En(l, u);
    } else
      En(s, s);
    return s;
  };
}
// @__NO_SIDE_EFFECTS__
function Ps(e, t, n = "svg") {
  var r = !e.startsWith("<!>"), a = (t & Li) !== 0, o = `<${n}>${r ? e : "<!>" + e}</${n}>`, s;
  return () => {
    if (!s) {
      var l = (
        /** @type {DocumentFragment} */
        zi(o)
      ), u = (
        /** @type {Element} */
        tn(l)
      );
      if (a)
        for (s = document.createDocumentFragment(); tn(u); )
          s.appendChild(
            /** @type {TemplateNode} */
            tn(u)
          );
      else
        s = /** @type {Element} */
        tn(u);
    }
    var c = (
      /** @type {TemplateNode} */
      s.cloneNode(!0)
    );
    if (a) {
      var v = (
        /** @type {TemplateNode} */
        tn(c)
      ), T = (
        /** @type {TemplateNode} */
        c.lastChild
      );
      En(v, T);
    } else
      En(c, c);
    return c;
  };
}
// @__NO_SIDE_EFFECTS__
function Qt(e, t) {
  return /* @__PURE__ */ Ps(e, t, "svg");
}
function Ar(e = "") {
  {
    var t = In(e + "");
    return En(t, t), t;
  }
}
function Et() {
  var e = document.createDocumentFragment(), t = document.createComment(""), n = In();
  return e.append(t, n), En(t, n), e;
}
function w(e, t) {
  e !== null && e.before(
    /** @type {Node} */
    t
  );
}
class Aa {
  /** @type {TemplateNode} */
  anchor;
  /** @type {Map<Batch, Key>} */
  #e = /* @__PURE__ */ new Map();
  /**
   * Map of keys to effects that are currently rendered in the DOM.
   * These effects are visible and actively part of the document tree.
   * Example:
   * ```
   * {#if condition}
   * 	foo
   * {:else}
   * 	bar
   * {/if}
   * ```
   * Can result in the entries `true->Effect` and `false->Effect`
   * @type {Map<Key, Effect>}
   */
  #n = /* @__PURE__ */ new Map();
  /**
   * Similar to #onscreen with respect to the keys, but contains branches that are not yet
   * in the DOM, because their insertion is deferred.
   * @type {Map<Key, Branch>}
   */
  #t = /* @__PURE__ */ new Map();
  /**
   * Keys of effects that are currently outroing
   * @type {Set<Key>}
   */
  #r = /* @__PURE__ */ new Set();
  /**
   * Whether to pause (i.e. outro) on change, or destroy immediately.
   * This is necessary for `<svelte:element>`
   */
  #a = !0;
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(t, n = !0) {
    this.anchor = t, this.#a = n;
  }
  /**
   * @param {Batch} batch
   */
  #i = (t) => {
    if (this.#e.has(t)) {
      var n = (
        /** @type {Key} */
        this.#e.get(t)
      ), r = this.#n.get(n);
      if (r)
        ba(r), this.#r.delete(n);
      else {
        var a = this.#t.get(n);
        a && (this.#n.set(n, a.effect), this.#t.delete(n), a.fragment.lastChild.remove(), this.anchor.before(a.fragment), r = a.effect);
      }
      for (const [o, s] of this.#e) {
        if (this.#e.delete(o), o === t)
          break;
        const l = this.#t.get(s);
        l && (On(l.effect), this.#t.delete(s));
      }
      for (const [o, s] of this.#n) {
        if (o === n || this.#r.has(o)) continue;
        const l = () => {
          if (Array.from(this.#e.values()).includes(o)) {
            var c = document.createDocumentFragment();
            Pi(s, c), c.append(In()), this.#t.set(o, { effect: s, fragment: c });
          } else
            On(s);
          this.#r.delete(o), this.#n.delete(o);
        };
        this.#a || !r ? (this.#r.add(o), ya(s, l, !1)) : l();
      }
    }
  };
  /**
   * @param {Batch} batch
   */
  #o = (t) => {
    this.#e.delete(t);
    const n = Array.from(this.#e.values());
    for (const [r, a] of this.#t)
      n.includes(r) || (On(a.effect), this.#t.delete(r));
  };
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(t, n) {
    var r = (
      /** @type {Batch} */
      An
    ), a = Hi();
    if (n && !this.#n.has(t) && !this.#t.has(t))
      if (a) {
        var o = document.createDocumentFragment(), s = In();
        o.append(s), this.#t.set(t, {
          effect: Cn(() => n(s)),
          fragment: o
        });
      } else
        this.#n.set(
          t,
          Cn(() => n(this.anchor))
        );
    if (this.#e.set(r, t), a) {
      for (const [l, u] of this.#n)
        l === t ? r.unskip_effect(u) : r.skip_effect(u);
      for (const [l, u] of this.#t)
        l === t ? r.unskip_effect(u.effect) : r.skip_effect(u.effect);
      r.oncommit(this.#i), r.ondiscard(this.#o);
    } else
      this.#i(r);
  }
}
function W(e, t, n = !1) {
  var r = new Aa(e), a = n ? wa : 0;
  function o(s, l) {
    r.ensure(s, l);
  }
  Pr(() => {
    var s = !1;
    t((l, u = 0) => {
      s = !0, o(u, l);
    }), s || o(-1, null);
  }, a);
}
function Lt(e, t) {
  return t;
}
function Hs(e, t, n) {
  for (var r = [], a = t.length, o, s = t.length, l = 0; l < a; l++) {
    let T = t[l];
    ya(
      T,
      () => {
        if (o) {
          if (o.pending.delete(T), o.done.add(T), o.pending.size === 0) {
            var f = (
              /** @type {Set<EachOutroGroup>} */
              e.outrogroups
            );
            oa(e, xa(o.done)), f.delete(o), f.size === 0 && (e.outrogroups = null);
          }
        } else
          s -= 1;
      },
      !1
    );
  }
  if (s === 0) {
    var u = r.length === 0 && n !== null;
    if (u) {
      var c = (
        /** @type {Element} */
        n
      ), v = (
        /** @type {Element} */
        c.parentNode
      );
      Vo(v), v.append(c), e.items.clear();
    }
    oa(e, t, !u);
  } else
    o = {
      pending: new Set(t),
      done: /* @__PURE__ */ new Set()
    }, (e.outrogroups ??= /* @__PURE__ */ new Set()).add(o);
}
function oa(e, t, n = !0) {
  var r;
  if (e.pending.size > 0) {
    r = /* @__PURE__ */ new Set();
    for (const s of e.pending.values())
      for (const l of s)
        r.add(
          /** @type {EachItem} */
          e.items.get(l).e
        );
  }
  for (var a = 0; a < t.length; a++) {
    var o = t[a];
    if (r?.has(o)) {
      o.f |= sn;
      const s = document.createDocumentFragment();
      Pi(o, s);
    } else
      On(t[a], n);
  }
}
var Wa;
function _t(e, t, n, r, a, o = null) {
  var s = e, l = /* @__PURE__ */ new Map(), u = (t & Ni) !== 0;
  if (u) {
    var c = (
      /** @type {Element} */
      e
    );
    s = c.appendChild(In());
  }
  var v = null, T = Dn(() => {
    var m = n();
    return sr(m) ? m : m == null ? [] : xa(m);
  }), f, p = /* @__PURE__ */ new Map(), C = !0;
  function S(m) {
    (O.effect.f & Ri) === 0 && (O.pending.delete(m), O.fallback = v, Ns(O, f, s, t, r), v !== null && (f.length === 0 ? (v.f & sn) === 0 ? ba(v) : (v.f ^= sn, er(v, null, s)) : ya(v, () => {
      v = null;
    })));
  }
  function h(m) {
    O.pending.delete(m);
  }
  var g = Pr(() => {
    f = /** @type {V[]} */
    i(T);
    for (var m = f.length, L = /* @__PURE__ */ new Set(), A = (
      /** @type {Batch} */
      An
    ), N = Hi(), q = 0; q < m; q += 1) {
      var K = f[q], j = r(K, q), de = C ? null : l.get(j);
      de ? (de.v && Fa(de.v, K), de.i && Fa(de.i, q), N && A.unskip_effect(de.e)) : (de = Rs(
        l,
        C ? s : Wa ??= In(),
        K,
        j,
        q,
        a,
        t,
        n
      ), C || (de.e.f |= sn), l.set(j, de)), L.add(j);
    }
    if (m === 0 && o && !v && (C ? v = Cn(() => o(s)) : (v = Cn(() => o(Wa ??= In())), v.f |= sn)), m > L.size && Do(), !C)
      if (p.set(A, L), N) {
        for (const [re, ce] of l)
          L.has(re) || A.skip_effect(ce.e);
        A.oncommit(S), A.ondiscard(h);
      } else
        S(A);
    i(T);
  }), O = { effect: g, items: l, pending: p, outrogroups: null, fallback: v };
  C = !1;
}
function Jn(e) {
  for (; e !== null && (e.f & zo) === 0; )
    e = e.next;
  return e;
}
function Ns(e, t, n, r, a) {
  var o = (r & Wo) !== 0, s = t.length, l = e.items, u = Jn(e.effect.first), c, v = null, T, f = [], p = [], C, S, h, g;
  if (o)
    for (g = 0; g < s; g += 1)
      C = t[g], S = a(C, g), h = /** @type {EachItem} */
      l.get(S).e, (h.f & sn) === 0 && (h.nodes?.a?.measure(), (T ??= /* @__PURE__ */ new Set()).add(h));
  for (g = 0; g < s; g += 1) {
    if (C = t[g], S = a(C, g), h = /** @type {EachItem} */
    l.get(S).e, e.outrogroups !== null)
      for (const de of e.outrogroups)
        de.pending.delete(h), de.done.delete(h);
    if ((h.f & jr) !== 0 && (ba(h), o && (h.nodes?.a?.unfix(), (T ??= /* @__PURE__ */ new Set()).delete(h))), (h.f & sn) !== 0)
      if (h.f ^= sn, h === u)
        er(h, null, n);
      else {
        var O = v ? v.next : u;
        h === e.effect.last && (e.effect.last = h.prev), h.prev && (h.prev.next = h.next), h.next && (h.next.prev = h.prev), yn(e, v, h), yn(e, h, O), er(h, O, n), v = h, f = [], p = [], u = Jn(v.next);
        continue;
      }
    if (h !== u) {
      if (c !== void 0 && c.has(h)) {
        if (f.length < p.length) {
          var m = p[0], L;
          v = m.prev;
          var A = f[0], N = f[f.length - 1];
          for (L = 0; L < f.length; L += 1)
            er(f[L], m, n);
          for (L = 0; L < p.length; L += 1)
            c.delete(p[L]);
          yn(e, A.prev, N.next), yn(e, v, A), yn(e, N, m), u = m, v = N, g -= 1, f = [], p = [];
        } else
          c.delete(h), er(h, u, n), yn(e, h.prev, h.next), yn(e, h, v === null ? e.effect.first : v.next), yn(e, v, h), v = h;
        continue;
      }
      for (f = [], p = []; u !== null && u !== h; )
        (c ??= /* @__PURE__ */ new Set()).add(u), p.push(u), u = Jn(u.next);
      if (u === null)
        continue;
    }
    (h.f & sn) === 0 && f.push(h), v = h, u = Jn(h.next);
  }
  if (e.outrogroups !== null) {
    for (const de of e.outrogroups)
      de.pending.size === 0 && (oa(e, xa(de.done)), e.outrogroups?.delete(de));
    e.outrogroups.size === 0 && (e.outrogroups = null);
  }
  if (u !== null || c !== void 0) {
    var q = [];
    if (c !== void 0)
      for (h of c)
        (h.f & jr) === 0 && q.push(h);
    for (; u !== null; )
      (u.f & jr) === 0 && u !== e.fallback && q.push(u), u = Jn(u.next);
    var K = q.length;
    if (K > 0) {
      var j = (r & Ni) !== 0 && s === 0 ? n : null;
      if (o) {
        for (g = 0; g < K; g += 1)
          q[g].nodes?.a?.measure();
        for (g = 0; g < K; g += 1)
          q[g].nodes?.a?.fix();
      }
      Hs(e, q, j);
    }
  }
  o && Go(() => {
    if (T !== void 0)
      for (h of T)
        h.nodes?.a?.apply();
  });
}
function Rs(e, t, n, r, a, o, s, l) {
  var u = (s & Uo) !== 0 ? (s & jo) === 0 ? Un(n, !1, !1) : aa(n) : null, c = (s & Fo) !== 0 ? aa(a) : null;
  return {
    v: u,
    i: c,
    e: Cn(() => (o(t, u ?? n, c ?? a, l), () => {
      e.delete(r);
    }))
  };
}
function er(e, t, n) {
  if (e.nodes)
    for (var r = e.nodes.start, a = e.nodes.end, o = t && (t.f & sn) === 0 ? (
      /** @type {EffectNodes} */
      t.nodes.start
    ) : n; r !== null; ) {
      var s = (
        /** @type {TemplateNode} */
        qo(r)
      );
      if (o.before(r), r === a)
        return;
      r = s;
    }
}
function yn(e, t, n) {
  t === null ? e.effect.first = n : t.next = n, n === null ? e.effect.last = t : n.prev = t;
}
function Bs(e, t, n = !1, r = !1, a = !1, o = !1) {
  var s = e, l = "";
  if (n)
    var u = (
      /** @type {Element} */
      e
    );
  F(() => {
    var c = (
      /** @type {Effect} */
      zn
    );
    if (l !== (l = t() ?? "")) {
      if (n) {
        c.nodes = null, u.innerHTML = /** @type {string} */
        l, l !== "" && En(
          /** @type {TemplateNode} */
          tn(u),
          /** @type {TemplateNode} */
          u.lastChild
        );
        return;
      }
      if (c.nodes !== null && (Xo(
        c.nodes.start,
        /** @type {TemplateNode} */
        c.nodes.end
      ), c.nodes = null), l !== "") {
        var v = r ? Zo : a ? Jo : void 0, T = (
          /** @type {HTMLTemplateElement | SVGElement | MathMLElement} */
          Ci(r ? "svg" : a ? "math" : "template", v)
        );
        T.innerHTML = /** @type {any} */
        l;
        var f = r || a ? T : (
          /** @type {HTMLTemplateElement} */
          T.content
        );
        if (En(
          /** @type {TemplateNode} */
          tn(f),
          /** @type {TemplateNode} */
          f.lastChild
        ), r || a)
          for (; tn(f); )
            s.before(
              /** @type {TemplateNode} */
              tn(f)
            );
        else
          s.before(f);
      }
    }
  });
}
function Ia(e, t, n, r, a) {
  var o = t.$$slots?.[n], s = !1;
  o === !0 && (o = t.children, s = !0), o === void 0 || o(e, s ? () => r : r);
}
function Wi(e, t, ...n) {
  var r = new Aa(e);
  Pr(() => {
    const a = t() ?? null;
    r.ensure(a, a && ((o) => a(o, ...n)));
  }, wa);
}
function Ms(e, t, n) {
  var r = new Aa(e);
  Pr(() => {
    var a = t() ?? null;
    r.ensure(a, a && ((o) => n(o, a)));
  }, wa);
}
function Ds(e, t, n) {
  lr(() => {
    var r = ct(() => t(e, n?.()) || {});
    if (n && r?.update) {
      var a = !1, o = (
        /** @type {any} */
        {}
      );
      ka(() => {
        var s = n();
        xt(s), a && Ii(o, s) && (o = s, r.update(s));
      }), a = !0;
    }
    if (r?.destroy)
      return () => (
        /** @type {Function} */
        r.destroy()
      );
  });
}
function Us(e, t) {
  var n = void 0, r;
  Bi(() => {
    n !== (n = t()) && (r && (On(r), r = null), n && (r = Cn(() => {
      lr(() => (
        /** @type {(node: Element) => void} */
        n(e)
      ));
    })));
  });
}
function Vi(e) {
  var t, n, r = "";
  if (typeof e == "string" || typeof e == "number") r += e;
  else if (typeof e == "object") if (Array.isArray(e)) {
    var a = e.length;
    for (t = 0; t < a; t++) e[t] && (n = Vi(e[t])) && (r && (r += " "), r += n);
  } else for (n in e) e[n] && (r && (r += " "), r += n);
  return r;
}
function js() {
  for (var e, t, n = 0, r = "", a = arguments.length; n < a; n++) (e = arguments[n]) && (t = Vi(e)) && (r && (r += " "), r += t);
  return r;
}
function Fs(e) {
  return typeof e == "object" ? js(e) : e ?? "";
}
const Va = [...` 	
\r\f \v\uFEFF`];
function Gs(e, t, n) {
  var r = e == null ? "" : "" + e;
  if (t && (r = r ? r + " " + t : t), n) {
    for (var a of Object.keys(n))
      if (n[a])
        r = r ? r + " " + a : a;
      else if (r.length)
        for (var o = a.length, s = 0; (s = r.indexOf(a, s)) >= 0; ) {
          var l = s + o;
          (s === 0 || Va.includes(r[s - 1])) && (l === r.length || Va.includes(r[l])) ? r = (s === 0 ? "" : r.substring(0, s)) + r.substring(l + 1) : s = l;
        }
  }
  return r === "" ? null : r;
}
function qa(e, t = !1) {
  var n = t ? " !important;" : ";", r = "";
  for (var a of Object.keys(e)) {
    var o = e[a];
    o != null && o !== "" && (r += " " + a + ": " + o + n);
  }
  return r;
}
function Fr(e) {
  return e[0] !== "-" || e[1] !== "-" ? e.toLowerCase() : e;
}
function zs(e, t) {
  if (t) {
    var n = "", r, a;
    if (Array.isArray(t) ? (r = t[0], a = t[1]) : r = t, e) {
      e = String(e).replaceAll(/\s*\/\*.*?\*\/\s*/g, "").trim();
      var o = !1, s = 0, l = !1, u = [];
      r && u.push(...Object.keys(r).map(Fr)), a && u.push(...Object.keys(a).map(Fr));
      var c = 0, v = -1;
      const S = e.length;
      for (var T = 0; T < S; T++) {
        var f = e[T];
        if (l ? f === "/" && e[T - 1] === "*" && (l = !1) : o ? o === f && (o = !1) : f === "/" && e[T + 1] === "*" ? l = !0 : f === '"' || f === "'" ? o = f : f === "(" ? s++ : f === ")" && s--, !l && o === !1 && s === 0) {
          if (f === ":" && v === -1)
            v = T;
          else if (f === ";" || T === S - 1) {
            if (v !== -1) {
              var p = Fr(e.substring(c, v).trim());
              if (!u.includes(p)) {
                f !== ";" && T++;
                var C = e.substring(c, T).trim();
                n += " " + C + ";";
              }
            }
            c = T + 1, v = -1;
          }
        }
      }
    }
    return r && (n += qa(r)), a && (n += qa(a, !0)), n = n.trim(), n === "" ? null : n;
  }
  return e == null ? null : String(e);
}
function We(e, t, n, r, a, o) {
  var s = e.__className;
  if (s !== n || s === void 0) {
    var l = Gs(n, r, o);
    l == null ? e.removeAttribute("class") : t ? e.className = l : e.setAttribute("class", l), e.__className = n;
  } else if (o && a !== o)
    for (var u in o) {
      var c = !!o[u];
      (a == null || c !== !!a[u]) && e.classList.toggle(u, c);
    }
  return o;
}
function Gr(e, t = {}, n, r) {
  for (var a in n) {
    var o = n[a];
    t[a] !== o && (n[a] == null ? e.style.removeProperty(a) : e.style.setProperty(a, o, r));
  }
}
function kt(e, t, n, r) {
  var a = e.__style;
  if (a !== t) {
    var o = zs(t, r);
    o == null ? e.removeAttribute("style") : e.style.cssText = o, e.__style = t;
  } else r && (Array.isArray(r) ? (Gr(e, n?.[0], r[0]), Gr(e, n?.[1], r[1], "important")) : Gr(e, n, r));
  return r;
}
function sa(e, t, n = !1) {
  if (e.multiple) {
    if (t == null)
      return;
    if (!sr(t))
      return Yo();
    for (var r of e.options)
      r.selected = t.includes(Xa(r));
    return;
  }
  for (r of e.options) {
    var a = Xa(r);
    if (Qo(a, t)) {
      r.selected = !0;
      return;
    }
  }
  (!n || t !== void 0) && (e.selectedIndex = -1);
}
function Ws(e) {
  var t = new MutationObserver(() => {
    sa(e, e.__value);
  });
  t.observe(e, {
    // Listen to option element changes
    childList: !0,
    subtree: !0,
    // because of <optgroup>
    // Listen to option element value attribute changes
    // (doesn't get notified of select value changes,
    // because that property is not reflected as an attribute)
    attributes: !0,
    attributeFilter: ["value"]
  }), Oi(() => {
    t.disconnect();
  });
}
function Xa(e) {
  return "__value" in e ? e.__value : e.value;
}
const Yn = /* @__PURE__ */ Symbol("class"), Bn = /* @__PURE__ */ Symbol("style"), qi = /* @__PURE__ */ Symbol("is custom element"), Xi = /* @__PURE__ */ Symbol("is html"), Vs = Ea ? "option" : "OPTION", qs = Ea ? "select" : "SELECT", Xs = Ea ? "progress" : "PROGRESS";
function vn(e, t) {
  var n = Hr(e);
  n.value === (n.value = // treat null and undefined the same for the initial value
  t ?? void 0) || // @ts-expect-error
  // `progress` elements always need their value set when it's `0`
  e.value === t && (t !== 0 || e.nodeName !== Xs) || (e.value = t ?? "");
}
function Za(e, t) {
  var n = Hr(e);
  n.checked !== (n.checked = // treat null and undefined the same for the initial value
  t ?? void 0) && (e.checked = t);
}
function Zs(e, t) {
  t ? e.hasAttribute("selected") || e.setAttribute("selected", "") : e.removeAttribute("selected");
}
function M(e, t, n, r) {
  var a = Hr(e);
  a[t] !== (a[t] = n) && (t === "loading" && (e[Ko] = n), n == null ? e.removeAttribute(t) : typeof n != "string" && Ji(e).includes(t) ? e[t] = n : e.setAttribute(t, n));
}
function Js(e, t, n, r, a = !1, o = !1) {
  var s = Hr(e), l = s[qi], u = !s[Xi], c = t || {}, v = e.nodeName === Vs;
  for (var T in t)
    T in n || (n[T] = null);
  n.class ? n.class = Fs(n.class) : (r || n[Yn]) && (n.class = null), n[Bn] && (n.style ??= null);
  var f = Ji(e);
  for (const m in n) {
    let L = n[m];
    if (v && m === "value" && L == null) {
      e.value = e.__value = "", c[m] = L;
      continue;
    }
    if (m === "class") {
      var p = e.namespaceURI === "http://www.w3.org/1999/xhtml";
      We(e, p, L, r, t?.[Yn], n[Yn]), c[m] = L, c[Yn] = n[Yn];
      continue;
    }
    if (m === "style") {
      kt(e, L, t?.[Bn], n[Bn]), c[m] = L, c[Bn] = n[Bn];
      continue;
    }
    var C = c[m];
    if (!(L === C && !(L === void 0 && e.hasAttribute(m)))) {
      c[m] = L;
      var S = m[0] + m[1];
      if (S !== "$$")
        if (S === "on") {
          const A = {}, N = "$$" + m;
          let q = m.slice(2);
          var h = ss(q);
          if (rs(q) && (q = q.slice(0, -7), A.capture = !0), !h && C) {
            if (L != null) continue;
            e.removeEventListener(q, c[N], A), c[N] = null;
          }
          if (h)
            z(q, e, L), un([q]);
          else if (L != null) {
            let K = function(j) {
              c[m].call(this, j);
            };
            c[N] = as(q, e, K, A);
          }
        } else if (m === "style")
          M(e, m, L);
        else if (m === "autofocus")
          $n(
            /** @type {HTMLElement} */
            e,
            !!L
          );
        else if (!l && (m === "__value" || m === "value" && L != null))
          e.value = e.__value = L;
        else if (m === "selected" && v)
          Zs(
            /** @type {HTMLOptionElement} */
            e,
            L
          );
        else {
          var g = m;
          u || (g = is(g));
          var O = g === "defaultValue" || g === "defaultChecked";
          if (L == null && !l && !O)
            if (s[m] = null, g === "value" || g === "checked") {
              let A = (
                /** @type {HTMLInputElement} */
                e
              );
              const N = t === void 0;
              if (g === "value") {
                let q = A.defaultValue;
                A.removeAttribute(g), A.defaultValue = q, A.value = A.__value = N ? q : null;
              } else {
                let q = A.defaultChecked;
                A.removeAttribute(g), A.defaultChecked = q, A.checked = N ? q : !1;
              }
            } else
              e.removeAttribute(m);
          else O || f.includes(g) && (l || typeof L != "string") ? (e[g] = L, g in s && (s[g] = os)) : typeof L != "function" && M(e, g, L);
        }
    }
  }
  return c;
}
function Zi(e, t, n = [], r = [], a = [], o, s = !1, l = !1) {
  ts(a, n, r, (u) => {
    var c = void 0, v = {}, T = e.nodeName === qs, f = !1;
    if (Bi(() => {
      var C = t(...u.map(i)), S = Js(
        e,
        c,
        C,
        o,
        s,
        l
      );
      f && T && "value" in C && sa(
        /** @type {HTMLSelectElement} */
        e,
        C.value
      );
      for (let g of Object.getOwnPropertySymbols(v))
        C[g] || On(v[g]);
      for (let g of Object.getOwnPropertySymbols(C)) {
        var h = C[g];
        g.description === ns && (!c || h !== c[g]) && (v[g] && On(v[g]), v[g] = Cn(() => Us(e, () => h))), S[g] = h;
      }
      c = S;
    }), T) {
      var p = (
        /** @type {HTMLSelectElement} */
        e
      );
      lr(() => {
        sa(
          p,
          /** @type {Record<string | symbol, any>} */
          c.value,
          !0
        ), Ws(p);
      });
    }
    f = !0;
  });
}
function Hr(e) {
  return (
    /** @type {Record<string | symbol, unknown>} **/
    // @ts-expect-error
    e.__attributes ??= {
      [qi]: e.nodeName.includes("-"),
      [Xi]: e.namespaceURI === $o
    }
  );
}
var Ja = /* @__PURE__ */ new Map();
function Ji(e) {
  var t = e.getAttribute("is") || e.nodeName, n = Ja.get(t);
  if (n) return n;
  Ja.set(t, n = []);
  for (var r, a = e, o = Element.prototype; o !== a; ) {
    r = es(a);
    for (var s in r)
      r[s].set && n.push(s);
    a = Ai(a);
  }
  return n;
}
function tr(e, t, n = t) {
  var r = /* @__PURE__ */ new WeakSet();
  ls(e, "input", async (a) => {
    var o = a ? e.defaultValue : e.value;
    if (o = zr(e) ? Wr(o) : o, n(o), An !== null && r.add(An), await Rn(), o !== (o = t())) {
      var s = e.selectionStart, l = e.selectionEnd, u = e.value.length;
      if (e.value = o ?? "", l !== null) {
        var c = e.value.length;
        s === l && l === u && c > u ? (e.selectionStart = c, e.selectionEnd = c) : (e.selectionStart = s, e.selectionEnd = Math.min(l, c));
      }
    }
  }), // If we are hydrating and the value has since changed,
  // then use the updated value from the input instead.
  // If defaultValue is set, then value == defaultValue
  // TODO Svelte 6: remove input.value check and set to empty string?
  ct(t) == null && e.value && (n(zr(e) ? Wr(e.value) : e.value), An !== null && r.add(An)), ka(() => {
    var a = t();
    if (e === document.activeElement) {
      var o = (
        /** @type {Batch} */
        An
      );
      if (r.has(o))
        return;
    }
    zr(e) && a === Wr(e.value) || e.type === "date" && !a && !e.value || a !== e.value && (e.value = a ?? "");
  });
}
function zr(e) {
  var t = e.type;
  return t === "number" || t === "range";
}
function Wr(e) {
  return e === "" ? null : +e;
}
function Ya(e, t) {
  return e === t || e?.[Mi] === t;
}
function ln(e = {}, t, n, r) {
  var a = (
    /** @type {ComponentContext} */
    Ta.r
  ), o = (
    /** @type {Effect} */
    zn
  );
  return lr(() => {
    var s, l;
    return ka(() => {
      s = l, l = [], ct(() => {
        e !== n(...l) && (t(e, ...l), s && Ya(n(...s), e) && t(null, ...s));
      });
    }), () => {
      let u = o;
      for (; u !== a && u.parent !== null && u.parent.f & us; )
        u = u.parent;
      const c = () => {
        l && Ya(n(...l), e) && t(null, ...l);
      }, v = u.teardown;
      u.teardown = () => {
        c(), v?.();
      };
    };
  }), e;
}
function cr(e = !1) {
  const t = (
    /** @type {ComponentContextLegacy} */
    Ta
  ), n = t.l.u;
  if (!n) return;
  let r = () => xt(t.s);
  if (e) {
    let a = 0, o = (
      /** @type {Record<string, any>} */
      {}
    );
    const s = Ui(() => {
      let l = !1;
      const u = t.s;
      for (const c in u)
        u[c] !== o[c] && (o[c] = u[c], l = !0);
      return l && a++, a;
    });
    r = () => i(s);
  }
  n.b.length && Di(() => {
    Qa(t, r), ra(n.b);
  }), Jt(() => {
    const a = ct(() => n.m.map(cs));
    return () => {
      for (const o of a)
        typeof o == "function" && o();
    };
  }), n.a.length && Jt(() => {
    Qa(t, r), ra(n.a);
  });
}
function Qa(e, t) {
  if (e.l.s)
    for (const n of e.l.s) i(n);
  t();
}
function wr(e, t) {
  var n = (
    /** @type {Record<string, Function[] | Function>} */
    e.$$events?.[t.type]
  ), r = sr(n) ? n.slice() : n == null ? [] : [n];
  for (var a of r)
    a.call(this, t);
}
const Ys = {
  get(e, t) {
    if (!e.exclude.includes(t))
      return e.props[t];
  },
  set(e, t) {
    return !1;
  },
  getOwnPropertyDescriptor(e, t) {
    if (!e.exclude.includes(t) && t in e.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: e.props[t]
      };
  },
  has(e, t) {
    return e.exclude.includes(t) ? !1 : t in e.props;
  },
  ownKeys(e) {
    return Reflect.ownKeys(e.props).filter((t) => !e.exclude.includes(t));
  }
};
// @__NO_SIDE_EFFECTS__
function Qs(e, t, n) {
  return new Proxy(
    { props: e, exclude: t },
    Ys
  );
}
const Ks = {
  get(e, t) {
    if (!e.exclude.includes(t))
      return i(e.version), t in e.special ? e.special[t]() : e.props[t];
  },
  set(e, t, n) {
    if (!(t in e.special)) {
      var r = zn;
      try {
        za(e.parent_effect), e.special[t] = Z(
          {
            get [t]() {
              return e.props[t];
            }
          },
          /** @type {string} */
          t,
          ji
        );
      } finally {
        za(r);
      }
    }
    return e.special[t](n), Ga(e.version), !0;
  },
  getOwnPropertyDescriptor(e, t) {
    if (!e.exclude.includes(t) && t in e.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: e.props[t]
      };
  },
  deleteProperty(e, t) {
    return e.exclude.includes(t) || (e.exclude.push(t), Ga(e.version)), !0;
  },
  has(e, t) {
    return e.exclude.includes(t) ? !1 : t in e.props;
  },
  ownKeys(e) {
    return Reflect.ownKeys(e.props).filter((t) => !e.exclude.includes(t));
  }
};
function Ka(e, t) {
  return new Proxy(
    {
      props: e,
      exclude: t,
      special: {},
      version: aa(0),
      // TODO this is only necessary because we need to track component
      // destruction inside `prop`, because of `bind:this`, but it
      // seems likely that we can simplify `bind:this` instead
      parent_effect: (
        /** @type {Effect} */
        zn
      )
    },
    Ks
  );
}
function Z(e, t, n, r) {
  var a = !vs || (n & ps) !== 0, o = (n & hs) !== 0, s = (n & ms) !== 0, l = (
    /** @type {V} */
    r
  ), u = !0, c = () => (u && (u = !1, l = s ? ct(
    /** @type {() => V} */
    r
  ) : (
    /** @type {V} */
    r
  )), l);
  let v;
  if (o) {
    var T = Mi in e || bs in e;
    v = ds(e, t)?.set ?? (T && t in e ? (m) => e[t] = m : void 0);
  }
  var f, p = !1;
  o ? [f, p] = Os(() => (
    /** @type {V} */
    e[t]
  )) : f = /** @type {V} */
  e[t], f === void 0 && r !== void 0 && (f = c(), v && (a && fs(), v(f)));
  var C;
  if (a ? C = () => {
    var m = (
      /** @type {V} */
      e[t]
    );
    return m === void 0 ? c() : (u = !0, m);
  } : C = () => {
    var m = (
      /** @type {V} */
      e[t]
    );
    return m !== void 0 && (l = /** @type {V} */
    void 0), m === void 0 ? l : m;
  }, a && (n & ji) === 0)
    return C;
  if (v) {
    var S = e.$$legacy;
    return (
      /** @type {() => V} */
      (function(m, L) {
        return arguments.length > 0 ? ((!a || !L || S || p) && v(L ? C() : m), m) : C();
      })
    );
  }
  var h = !1, g = ((n & gs) !== 0 ? Ui : Dn)(() => (h = !1, C()));
  o && i(g);
  var O = (
    /** @type {Effect} */
    zn
  );
  return (
    /** @type {() => V} */
    (function(m, L) {
      if (arguments.length > 0) {
        const A = L ? i(g) : a && o ? zt(m) : m;
        return _(g, A), h = !0, l !== void 0 && (l = A), m;
      }
      return _s && h || (O.f & Ri) !== 0 ? g.v : i(g);
    })
  );
}
function $s(e, t, { bubbles: n = !1, cancelable: r = !1 } = {}) {
  return new CustomEvent(e, { detail: t, bubbles: n, cancelable: r });
}
function Oa() {
  const e = Ta;
  return e === null && Es(), (t, n, r) => {
    const a = (
      /** @type {Record<string, Function | Function[]>} */
      e.s.$$events?.[
        /** @type {string} */
        t
      ]
    );
    if (a) {
      const o = sr(a) ? a.slice() : [a], s = $s(
        /** @type {string} */
        t,
        n,
        r
      );
      for (const l of o)
        l.call(e.x, s);
      return !s.defaultPrevented;
    }
    return !0;
  };
}
const el = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], $a = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
el.reduce((e, { color: t, primary: n, secondary: r }) => ({
  ...e,
  [t]: {
    primary: $a[t][n],
    secondary: $a[t][r]
  }
}), {});
function tl(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var Vr, ei;
function nl() {
  if (ei) return Vr;
  ei = 1;
  var e = function(O) {
    return t(O) && !n(O);
  };
  function t(g) {
    return !!g && typeof g == "object";
  }
  function n(g) {
    var O = Object.prototype.toString.call(g);
    return O === "[object RegExp]" || O === "[object Date]" || o(g);
  }
  var r = typeof Symbol == "function" && Symbol.for, a = r ? /* @__PURE__ */ Symbol.for("react.element") : 60103;
  function o(g) {
    return g.$$typeof === a;
  }
  function s(g) {
    return Array.isArray(g) ? [] : {};
  }
  function l(g, O) {
    return O.clone !== !1 && O.isMergeableObject(g) ? S(s(g), g, O) : g;
  }
  function u(g, O, m) {
    return g.concat(O).map(function(L) {
      return l(L, m);
    });
  }
  function c(g, O) {
    if (!O.customMerge)
      return S;
    var m = O.customMerge(g);
    return typeof m == "function" ? m : S;
  }
  function v(g) {
    return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(g).filter(function(O) {
      return Object.propertyIsEnumerable.call(g, O);
    }) : [];
  }
  function T(g) {
    return Object.keys(g).concat(v(g));
  }
  function f(g, O) {
    try {
      return O in g;
    } catch {
      return !1;
    }
  }
  function p(g, O) {
    return f(g, O) && !(Object.hasOwnProperty.call(g, O) && Object.propertyIsEnumerable.call(g, O));
  }
  function C(g, O, m) {
    var L = {};
    return m.isMergeableObject(g) && T(g).forEach(function(A) {
      L[A] = l(g[A], m);
    }), T(O).forEach(function(A) {
      p(g, A) || (f(g, A) && m.isMergeableObject(O[A]) ? L[A] = c(A, m)(g[A], O[A], m) : L[A] = l(O[A], m));
    }), L;
  }
  function S(g, O, m) {
    m = m || {}, m.arrayMerge = m.arrayMerge || u, m.isMergeableObject = m.isMergeableObject || e, m.cloneUnlessOtherwiseSpecified = l;
    var L = Array.isArray(O), A = Array.isArray(g), N = L === A;
    return N ? L ? m.arrayMerge(g, O, m) : C(g, O, m) : l(O, m);
  }
  S.all = function(O, m) {
    if (!Array.isArray(O))
      throw new Error("first argument should be an array");
    return O.reduce(function(L, A) {
      return S(L, A, m);
    }, {});
  };
  var h = S;
  return Vr = h, Vr;
}
var rl = nl();
const al = /* @__PURE__ */ tl(rl);
var la = function(e, t) {
  return la = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(n, r) {
    n.__proto__ = r;
  } || function(n, r) {
    for (var a in r) Object.prototype.hasOwnProperty.call(r, a) && (n[a] = r[a]);
  }, la(e, t);
};
function Nr(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
  la(e, t);
  function n() {
    this.constructor = e;
  }
  e.prototype = t === null ? Object.create(t) : (n.prototype = t.prototype, new n());
}
var Be = function() {
  return Be = Object.assign || function(t) {
    for (var n, r = 1, a = arguments.length; r < a; r++) {
      n = arguments[r];
      for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (t[o] = n[o]);
    }
    return t;
  }, Be.apply(this, arguments);
};
function il(e, t) {
  var n = {};
  for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var a = 0, r = Object.getOwnPropertySymbols(e); a < r.length; a++)
      t.indexOf(r[a]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[a]) && (n[r[a]] = e[r[a]]);
  return n;
}
function qr(e, t, n) {
  if (n || arguments.length === 2) for (var r = 0, a = t.length, o; r < a; r++)
    (o || !(r in t)) && (o || (o = Array.prototype.slice.call(t, 0, r)), o[r] = t[r]);
  return e.concat(o || Array.prototype.slice.call(t));
}
function Xr(e, t) {
  var n = t && t.cache ? t.cache : fl, r = t && t.serializer ? t.serializer : cl, a = t && t.strategy ? t.strategy : ll;
  return a(e, {
    cache: n,
    serializer: r
  });
}
function ol(e) {
  return e == null || typeof e == "number" || typeof e == "boolean";
}
function sl(e, t, n, r) {
  var a = ol(r) ? r : n(r), o = t.get(a);
  return typeof o > "u" && (o = e.call(this, r), t.set(a, o)), o;
}
function Yi(e, t, n) {
  var r = Array.prototype.slice.call(arguments, 3), a = n(r), o = t.get(a);
  return typeof o > "u" && (o = e.apply(this, r), t.set(a, o)), o;
}
function Qi(e, t, n, r, a) {
  return n.bind(t, e, r, a);
}
function ll(e, t) {
  var n = e.length === 1 ? sl : Yi;
  return Qi(e, this, n, t.cache.create(), t.serializer);
}
function ul(e, t) {
  return Qi(e, this, Yi, t.cache.create(), t.serializer);
}
var cl = function() {
  return JSON.stringify(arguments);
}, dl = (
  /** @class */
  (function() {
    function e() {
      this.cache = /* @__PURE__ */ Object.create(null);
    }
    return e.prototype.get = function(t) {
      return this.cache[t];
    }, e.prototype.set = function(t, n) {
      this.cache[t] = n;
    }, e;
  })()
), fl = {
  create: function() {
    return new dl();
  }
}, Zr = {
  variadic: ul
}, Ie;
(function(e) {
  e[e.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", e[e.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", e[e.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", e[e.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", e[e.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", e[e.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", e[e.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", e[e.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", e[e.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", e[e.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", e[e.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", e[e.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", e[e.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", e[e.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", e[e.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", e[e.INVALID_TAG = 23] = "INVALID_TAG", e[e.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", e[e.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", e[e.UNCLOSED_TAG = 27] = "UNCLOSED_TAG";
})(Ie || (Ie = {}));
var st;
(function(e) {
  e[e.literal = 0] = "literal", e[e.argument = 1] = "argument", e[e.number = 2] = "number", e[e.date = 3] = "date", e[e.time = 4] = "time", e[e.select = 5] = "select", e[e.plural = 6] = "plural", e[e.pound = 7] = "pound", e[e.tag = 8] = "tag";
})(st || (st = {}));
var jn;
(function(e) {
  e[e.number = 0] = "number", e[e.dateTime = 1] = "dateTime";
})(jn || (jn = {}));
function ti(e) {
  return e.type === st.literal;
}
function hl(e) {
  return e.type === st.argument;
}
function Ki(e) {
  return e.type === st.number;
}
function $i(e) {
  return e.type === st.date;
}
function eo(e) {
  return e.type === st.time;
}
function to(e) {
  return e.type === st.select;
}
function no(e) {
  return e.type === st.plural;
}
function vl(e) {
  return e.type === st.pound;
}
function ro(e) {
  return e.type === st.tag;
}
function ao(e) {
  return !!(e && typeof e == "object" && e.type === jn.number);
}
function ua(e) {
  return !!(e && typeof e == "object" && e.type === jn.dateTime);
}
var io = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/, pl = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
function gl(e) {
  var t = {};
  return e.replace(pl, function(n) {
    var r = n.length;
    switch (n[0]) {
      // Era
      case "G":
        t.era = r === 4 ? "long" : r === 5 ? "narrow" : "short";
        break;
      // Year
      case "y":
        t.year = r === 2 ? "2-digit" : "numeric";
        break;
      case "Y":
      case "u":
      case "U":
      case "r":
        throw new RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
      // Quarter
      case "q":
      case "Q":
        throw new RangeError("`q/Q` (quarter) patterns are not supported");
      // Month
      case "M":
      case "L":
        t.month = ["numeric", "2-digit", "short", "long", "narrow"][r - 1];
        break;
      // Week
      case "w":
      case "W":
        throw new RangeError("`w/W` (week) patterns are not supported");
      case "d":
        t.day = ["numeric", "2-digit"][r - 1];
        break;
      case "D":
      case "F":
      case "g":
        throw new RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
      // Weekday
      case "E":
        t.weekday = r === 4 ? "long" : r === 5 ? "narrow" : "short";
        break;
      case "e":
        if (r < 4)
          throw new RangeError("`e..eee` (weekday) patterns are not supported");
        t.weekday = ["short", "long", "narrow", "short"][r - 4];
        break;
      case "c":
        if (r < 4)
          throw new RangeError("`c..ccc` (weekday) patterns are not supported");
        t.weekday = ["short", "long", "narrow", "short"][r - 4];
        break;
      // Period
      case "a":
        t.hour12 = !0;
        break;
      case "b":
      // am, pm, noon, midnight
      case "B":
        throw new RangeError("`b/B` (period) patterns are not supported, use `a` instead");
      // Hour
      case "h":
        t.hourCycle = "h12", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "H":
        t.hourCycle = "h23", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "K":
        t.hourCycle = "h11", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "k":
        t.hourCycle = "h24", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "j":
      case "J":
      case "C":
        throw new RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
      // Minute
      case "m":
        t.minute = ["numeric", "2-digit"][r - 1];
        break;
      // Second
      case "s":
        t.second = ["numeric", "2-digit"][r - 1];
        break;
      case "S":
      case "A":
        throw new RangeError("`S/A` (second) patterns are not supported, use `s` instead");
      // Zone
      case "z":
        t.timeZoneName = r < 4 ? "short" : "long";
        break;
      case "Z":
      // 1..3, 4, 5: The ISO8601 varios formats
      case "O":
      // 1, 4: milliseconds in day short, long
      case "v":
      // 1, 4: generic non-location format
      case "V":
      // 1, 2, 3, 4: time zone ID or city
      case "X":
      // 1, 2, 3, 4: The ISO8601 varios formats
      case "x":
        throw new RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead");
    }
    return "";
  }), t;
}
var ml = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
function _l(e) {
  if (e.length === 0)
    throw new Error("Number skeleton cannot be empty");
  for (var t = e.split(ml).filter(function(f) {
    return f.length > 0;
  }), n = [], r = 0, a = t; r < a.length; r++) {
    var o = a[r], s = o.split("/");
    if (s.length === 0)
      throw new Error("Invalid number skeleton");
    for (var l = s[0], u = s.slice(1), c = 0, v = u; c < v.length; c++) {
      var T = v[c];
      if (T.length === 0)
        throw new Error("Invalid number skeleton");
    }
    n.push({ stem: l, options: u });
  }
  return n;
}
function bl(e) {
  return e.replace(/^(.*?)-/, "");
}
var ni = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g, oo = /^(@+)?(\+|#+)?[rs]?$/g, yl = /(\*)(0+)|(#+)(0+)|(0+)/g, so = /^(0+)$/;
function ri(e) {
  var t = {};
  return e[e.length - 1] === "r" ? t.roundingPriority = "morePrecision" : e[e.length - 1] === "s" && (t.roundingPriority = "lessPrecision"), e.replace(oo, function(n, r, a) {
    return typeof a != "string" ? (t.minimumSignificantDigits = r.length, t.maximumSignificantDigits = r.length) : a === "+" ? t.minimumSignificantDigits = r.length : r[0] === "#" ? t.maximumSignificantDigits = r.length : (t.minimumSignificantDigits = r.length, t.maximumSignificantDigits = r.length + (typeof a == "string" ? a.length : 0)), "";
  }), t;
}
function lo(e) {
  switch (e) {
    case "sign-auto":
      return {
        signDisplay: "auto"
      };
    case "sign-accounting":
    case "()":
      return {
        currencySign: "accounting"
      };
    case "sign-always":
    case "+!":
      return {
        signDisplay: "always"
      };
    case "sign-accounting-always":
    case "()!":
      return {
        signDisplay: "always",
        currencySign: "accounting"
      };
    case "sign-except-zero":
    case "+?":
      return {
        signDisplay: "exceptZero"
      };
    case "sign-accounting-except-zero":
    case "()?":
      return {
        signDisplay: "exceptZero",
        currencySign: "accounting"
      };
    case "sign-never":
    case "+_":
      return {
        signDisplay: "never"
      };
  }
}
function wl(e) {
  var t;
  if (e[0] === "E" && e[1] === "E" ? (t = {
    notation: "engineering"
  }, e = e.slice(2)) : e[0] === "E" && (t = {
    notation: "scientific"
  }, e = e.slice(1)), t) {
    var n = e.slice(0, 2);
    if (n === "+!" ? (t.signDisplay = "always", e = e.slice(2)) : n === "+?" && (t.signDisplay = "exceptZero", e = e.slice(2)), !so.test(e))
      throw new Error("Malformed concise eng/scientific notation");
    t.minimumIntegerDigits = e.length;
  }
  return t;
}
function ai(e) {
  var t = {}, n = lo(e);
  return n || t;
}
function xl(e) {
  for (var t = {}, n = 0, r = e; n < r.length; n++) {
    var a = r[n];
    switch (a.stem) {
      case "percent":
      case "%":
        t.style = "percent";
        continue;
      case "%x100":
        t.style = "percent", t.scale = 100;
        continue;
      case "currency":
        t.style = "currency", t.currency = a.options[0];
        continue;
      case "group-off":
      case ",_":
        t.useGrouping = !1;
        continue;
      case "precision-integer":
      case ".":
        t.maximumFractionDigits = 0;
        continue;
      case "measure-unit":
      case "unit":
        t.style = "unit", t.unit = bl(a.options[0]);
        continue;
      case "compact-short":
      case "K":
        t.notation = "compact", t.compactDisplay = "short";
        continue;
      case "compact-long":
      case "KK":
        t.notation = "compact", t.compactDisplay = "long";
        continue;
      case "scientific":
        t = Be(Be(Be({}, t), { notation: "scientific" }), a.options.reduce(function(u, c) {
          return Be(Be({}, u), ai(c));
        }, {}));
        continue;
      case "engineering":
        t = Be(Be(Be({}, t), { notation: "engineering" }), a.options.reduce(function(u, c) {
          return Be(Be({}, u), ai(c));
        }, {}));
        continue;
      case "notation-simple":
        t.notation = "standard";
        continue;
      // https://github.com/unicode-org/icu/blob/master/icu4c/source/i18n/unicode/unumberformatter.h
      case "unit-width-narrow":
        t.currencyDisplay = "narrowSymbol", t.unitDisplay = "narrow";
        continue;
      case "unit-width-short":
        t.currencyDisplay = "code", t.unitDisplay = "short";
        continue;
      case "unit-width-full-name":
        t.currencyDisplay = "name", t.unitDisplay = "long";
        continue;
      case "unit-width-iso-code":
        t.currencyDisplay = "symbol";
        continue;
      case "scale":
        t.scale = parseFloat(a.options[0]);
        continue;
      case "rounding-mode-floor":
        t.roundingMode = "floor";
        continue;
      case "rounding-mode-ceiling":
        t.roundingMode = "ceil";
        continue;
      case "rounding-mode-down":
        t.roundingMode = "trunc";
        continue;
      case "rounding-mode-up":
        t.roundingMode = "expand";
        continue;
      case "rounding-mode-half-even":
        t.roundingMode = "halfEven";
        continue;
      case "rounding-mode-half-down":
        t.roundingMode = "halfTrunc";
        continue;
      case "rounding-mode-half-up":
        t.roundingMode = "halfExpand";
        continue;
      // https://unicode-org.github.io/icu/userguide/format_parse/numbers/skeletons.html#integer-width
      case "integer-width":
        if (a.options.length > 1)
          throw new RangeError("integer-width stems only accept a single optional option");
        a.options[0].replace(yl, function(u, c, v, T, f, p) {
          if (c)
            t.minimumIntegerDigits = v.length;
          else {
            if (T && f)
              throw new Error("We currently do not support maximum integer digits");
            if (p)
              throw new Error("We currently do not support exact integer digits");
          }
          return "";
        });
        continue;
    }
    if (so.test(a.stem)) {
      t.minimumIntegerDigits = a.stem.length;
      continue;
    }
    if (ni.test(a.stem)) {
      if (a.options.length > 1)
        throw new RangeError("Fraction-precision stems only accept a single optional option");
      a.stem.replace(ni, function(u, c, v, T, f, p) {
        return v === "*" ? t.minimumFractionDigits = c.length : T && T[0] === "#" ? t.maximumFractionDigits = T.length : f && p ? (t.minimumFractionDigits = f.length, t.maximumFractionDigits = f.length + p.length) : (t.minimumFractionDigits = c.length, t.maximumFractionDigits = c.length), "";
      });
      var o = a.options[0];
      o === "w" ? t = Be(Be({}, t), { trailingZeroDisplay: "stripIfInteger" }) : o && (t = Be(Be({}, t), ri(o)));
      continue;
    }
    if (oo.test(a.stem)) {
      t = Be(Be({}, t), ri(a.stem));
      continue;
    }
    var s = lo(a.stem);
    s && (t = Be(Be({}, t), s));
    var l = wl(a.stem);
    l && (t = Be(Be({}, t), l));
  }
  return t;
}
var mr = {
  "001": [
    "H",
    "h"
  ],
  419: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AD: [
    "H",
    "hB"
  ],
  AE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  AF: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  AG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AL: [
    "h",
    "H",
    "hB"
  ],
  AM: [
    "H",
    "hB"
  ],
  AO: [
    "H",
    "hB"
  ],
  AR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AS: [
    "h",
    "H"
  ],
  AT: [
    "H",
    "hB"
  ],
  AU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AW: [
    "H",
    "hB"
  ],
  AX: [
    "H"
  ],
  AZ: [
    "H",
    "hB",
    "h"
  ],
  BA: [
    "H",
    "hB",
    "h"
  ],
  BB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BD: [
    "h",
    "hB",
    "H"
  ],
  BE: [
    "H",
    "hB"
  ],
  BF: [
    "H",
    "hB"
  ],
  BG: [
    "H",
    "hB",
    "h"
  ],
  BH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  BI: [
    "H",
    "h"
  ],
  BJ: [
    "H",
    "hB"
  ],
  BL: [
    "H",
    "hB"
  ],
  BM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BN: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  BO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  BQ: [
    "H"
  ],
  BR: [
    "H",
    "hB"
  ],
  BS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BT: [
    "h",
    "H"
  ],
  BW: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BY: [
    "H",
    "h"
  ],
  BZ: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CA: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  CC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CD: [
    "hB",
    "H"
  ],
  CF: [
    "H",
    "h",
    "hB"
  ],
  CG: [
    "H",
    "hB"
  ],
  CH: [
    "H",
    "hB",
    "h"
  ],
  CI: [
    "H",
    "hB"
  ],
  CK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CL: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  CM: [
    "H",
    "h",
    "hB"
  ],
  CN: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  CO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  CP: [
    "H"
  ],
  CR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  CU: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  CV: [
    "H",
    "hB"
  ],
  CW: [
    "H",
    "hB"
  ],
  CX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CY: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  CZ: [
    "H"
  ],
  DE: [
    "H",
    "hB"
  ],
  DG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  DJ: [
    "h",
    "H"
  ],
  DK: [
    "H"
  ],
  DM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  DO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  DZ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  EC: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  EE: [
    "H",
    "hB"
  ],
  EG: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  ER: [
    "h",
    "H"
  ],
  ES: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  ET: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  FI: [
    "H"
  ],
  FJ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  FM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FO: [
    "H",
    "h"
  ],
  FR: [
    "H",
    "hB"
  ],
  GA: [
    "H",
    "hB"
  ],
  GB: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GD: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GE: [
    "H",
    "hB",
    "h"
  ],
  GF: [
    "H",
    "hB"
  ],
  GG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GH: [
    "h",
    "H"
  ],
  GI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GL: [
    "H",
    "h"
  ],
  GM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GN: [
    "H",
    "hB"
  ],
  GP: [
    "H",
    "hB"
  ],
  GQ: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  GR: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  GT: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  GU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GW: [
    "H",
    "hB"
  ],
  GY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  HK: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  HN: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  HR: [
    "H",
    "hB"
  ],
  HU: [
    "H",
    "h"
  ],
  IC: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  ID: [
    "H"
  ],
  IE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IL: [
    "H",
    "hB"
  ],
  IM: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IN: [
    "h",
    "H"
  ],
  IO: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IQ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  IR: [
    "hB",
    "H"
  ],
  IS: [
    "H"
  ],
  IT: [
    "H",
    "hB"
  ],
  JE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  JM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  JO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  JP: [
    "H",
    "K",
    "h"
  ],
  KE: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  KG: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KH: [
    "hB",
    "h",
    "H",
    "hb"
  ],
  KI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KM: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KN: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KP: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KW: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  KY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KZ: [
    "H",
    "hB"
  ],
  LA: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  LB: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LI: [
    "H",
    "hB",
    "h"
  ],
  LK: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  LR: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LS: [
    "h",
    "H"
  ],
  LT: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  LU: [
    "H",
    "h",
    "hB"
  ],
  LV: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  LY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MC: [
    "H",
    "hB"
  ],
  MD: [
    "H",
    "hB"
  ],
  ME: [
    "H",
    "hB",
    "h"
  ],
  MF: [
    "H",
    "hB"
  ],
  MG: [
    "H",
    "h"
  ],
  MH: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ML: [
    "H"
  ],
  MM: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  MN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MP: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MQ: [
    "H",
    "hB"
  ],
  MR: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MS: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MT: [
    "H",
    "h"
  ],
  MU: [
    "H",
    "h"
  ],
  MV: [
    "H",
    "h"
  ],
  MW: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MX: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  MY: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  MZ: [
    "H",
    "hB"
  ],
  NA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NC: [
    "H",
    "hB"
  ],
  NE: [
    "H"
  ],
  NF: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NI: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NL: [
    "H",
    "hB"
  ],
  NO: [
    "H",
    "h"
  ],
  NP: [
    "H",
    "h",
    "hB"
  ],
  NR: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NU: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  OM: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PF: [
    "H",
    "h",
    "hB"
  ],
  PG: [
    "h",
    "H"
  ],
  PH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PK: [
    "h",
    "hB",
    "H"
  ],
  PL: [
    "H",
    "h"
  ],
  PM: [
    "H",
    "hB"
  ],
  PN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  PR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PS: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PT: [
    "H",
    "hB"
  ],
  PW: [
    "h",
    "H"
  ],
  PY: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  QA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  RE: [
    "H",
    "hB"
  ],
  RO: [
    "H",
    "hB"
  ],
  RS: [
    "H",
    "hB",
    "h"
  ],
  RU: [
    "H"
  ],
  RW: [
    "H",
    "h"
  ],
  SA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SC: [
    "H",
    "h",
    "hB"
  ],
  SD: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SE: [
    "H"
  ],
  SG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SH: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SI: [
    "H",
    "hB"
  ],
  SJ: [
    "H"
  ],
  SK: [
    "H"
  ],
  SL: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SM: [
    "H",
    "h",
    "hB"
  ],
  SN: [
    "H",
    "h",
    "hB"
  ],
  SO: [
    "h",
    "H"
  ],
  SR: [
    "H",
    "hB"
  ],
  SS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ST: [
    "H",
    "hB"
  ],
  SV: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  SX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  TC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TD: [
    "h",
    "H",
    "hB"
  ],
  TF: [
    "H",
    "h",
    "hB"
  ],
  TG: [
    "H",
    "hB"
  ],
  TH: [
    "H",
    "h"
  ],
  TJ: [
    "H",
    "h"
  ],
  TL: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  TM: [
    "H",
    "h"
  ],
  TN: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  TO: [
    "h",
    "H"
  ],
  TR: [
    "H",
    "hB"
  ],
  TT: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TW: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  TZ: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UA: [
    "H",
    "hB",
    "h"
  ],
  UG: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  US: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  UY: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  UZ: [
    "H",
    "hB",
    "h"
  ],
  VA: [
    "H",
    "h",
    "hB"
  ],
  VC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  VG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VN: [
    "H",
    "h"
  ],
  VU: [
    "h",
    "H"
  ],
  WF: [
    "H",
    "hB"
  ],
  WS: [
    "h",
    "H"
  ],
  XK: [
    "H",
    "hB",
    "h"
  ],
  YE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  YT: [
    "H",
    "hB"
  ],
  ZA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ZM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ZW: [
    "H",
    "h"
  ],
  "af-ZA": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "ar-001": [
    "h",
    "hB",
    "hb",
    "H"
  ],
  "ca-ES": [
    "H",
    "h",
    "hB"
  ],
  "en-001": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-HK": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-IL": [
    "H",
    "h",
    "hb",
    "hB"
  ],
  "en-MY": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "es-BR": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-ES": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-GQ": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "fr-CA": [
    "H",
    "h",
    "hB"
  ],
  "gl-ES": [
    "H",
    "h",
    "hB"
  ],
  "gu-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "hi-IN": [
    "hB",
    "h",
    "H"
  ],
  "it-CH": [
    "H",
    "h",
    "hB"
  ],
  "it-IT": [
    "H",
    "h",
    "hB"
  ],
  "kn-IN": [
    "hB",
    "h",
    "H"
  ],
  "ml-IN": [
    "hB",
    "h",
    "H"
  ],
  "mr-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "pa-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "ta-IN": [
    "hB",
    "h",
    "hb",
    "H"
  ],
  "te-IN": [
    "hB",
    "h",
    "H"
  ],
  "zu-ZA": [
    "H",
    "hB",
    "hb",
    "h"
  ]
};
function kl(e, t) {
  for (var n = "", r = 0; r < e.length; r++) {
    var a = e.charAt(r);
    if (a === "j") {
      for (var o = 0; r + 1 < e.length && e.charAt(r + 1) === a; )
        o++, r++;
      var s = 1 + (o & 1), l = o < 2 ? 1 : 3 + (o >> 1), u = "a", c = El(t);
      for ((c == "H" || c == "k") && (l = 0); l-- > 0; )
        n += u;
      for (; s-- > 0; )
        n = c + n;
    } else a === "J" ? n += "H" : n += a;
  }
  return n;
}
function El(e) {
  var t = e.hourCycle;
  if (t === void 0 && // @ts-ignore hourCycle(s) is not identified yet
  e.hourCycles && // @ts-ignore
  e.hourCycles.length && (t = e.hourCycles[0]), t)
    switch (t) {
      case "h24":
        return "k";
      case "h23":
        return "H";
      case "h12":
        return "h";
      case "h11":
        return "K";
      default:
        throw new Error("Invalid hourCycle");
    }
  var n = e.language, r;
  n !== "root" && (r = e.maximize().region);
  var a = mr[r || ""] || mr[n || ""] || mr["".concat(n, "-001")] || mr["001"];
  return a[0];
}
var Jr, Tl = new RegExp("^".concat(io.source, "*")), Sl = new RegExp("".concat(io.source, "*$"));
function Le(e, t) {
  return { start: e, end: t };
}
var Al = !!String.prototype.startsWith && "_a".startsWith("a", 1), Il = !!String.fromCodePoint, Ol = !!Object.fromEntries, Cl = !!String.prototype.codePointAt, Ll = !!String.prototype.trimStart, Pl = !!String.prototype.trimEnd, Hl = !!Number.isSafeInteger, Nl = Hl ? Number.isSafeInteger : function(e) {
  return typeof e == "number" && isFinite(e) && Math.floor(e) === e && Math.abs(e) <= 9007199254740991;
}, ca = !0;
try {
  var Rl = co("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  ca = ((Jr = Rl.exec("a")) === null || Jr === void 0 ? void 0 : Jr[0]) === "a";
} catch {
  ca = !1;
}
var ii = Al ? (
  // Native
  function(t, n, r) {
    return t.startsWith(n, r);
  }
) : (
  // For IE11
  function(t, n, r) {
    return t.slice(r, r + n.length) === n;
  }
), da = Il ? String.fromCodePoint : (
  // IE11
  function() {
    for (var t = [], n = 0; n < arguments.length; n++)
      t[n] = arguments[n];
    for (var r = "", a = t.length, o = 0, s; a > o; ) {
      if (s = t[o++], s > 1114111)
        throw RangeError(s + " is not a valid code point");
      r += s < 65536 ? String.fromCharCode(s) : String.fromCharCode(((s -= 65536) >> 10) + 55296, s % 1024 + 56320);
    }
    return r;
  }
), oi = (
  // native
  Ol ? Object.fromEntries : (
    // Ponyfill
    function(t) {
      for (var n = {}, r = 0, a = t; r < a.length; r++) {
        var o = a[r], s = o[0], l = o[1];
        n[s] = l;
      }
      return n;
    }
  )
), uo = Cl ? (
  // Native
  function(t, n) {
    return t.codePointAt(n);
  }
) : (
  // IE 11
  function(t, n) {
    var r = t.length;
    if (!(n < 0 || n >= r)) {
      var a = t.charCodeAt(n), o;
      return a < 55296 || a > 56319 || n + 1 === r || (o = t.charCodeAt(n + 1)) < 56320 || o > 57343 ? a : (a - 55296 << 10) + (o - 56320) + 65536;
    }
  }
), Bl = Ll ? (
  // Native
  function(t) {
    return t.trimStart();
  }
) : (
  // Ponyfill
  function(t) {
    return t.replace(Tl, "");
  }
), Ml = Pl ? (
  // Native
  function(t) {
    return t.trimEnd();
  }
) : (
  // Ponyfill
  function(t) {
    return t.replace(Sl, "");
  }
);
function co(e, t) {
  return new RegExp(e, t);
}
var fa;
if (ca) {
  var si = co("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  fa = function(t, n) {
    var r;
    si.lastIndex = n;
    var a = si.exec(t);
    return (r = a[1]) !== null && r !== void 0 ? r : "";
  };
} else
  fa = function(t, n) {
    for (var r = []; ; ) {
      var a = uo(t, n);
      if (a === void 0 || fo(a) || Fl(a))
        break;
      r.push(a), n += a >= 65536 ? 2 : 1;
    }
    return da.apply(void 0, r);
  };
var Dl = (
  /** @class */
  (function() {
    function e(t, n) {
      n === void 0 && (n = {}), this.message = t, this.position = { offset: 0, line: 1, column: 1 }, this.ignoreTag = !!n.ignoreTag, this.locale = n.locale, this.requiresOtherClause = !!n.requiresOtherClause, this.shouldParseSkeletons = !!n.shouldParseSkeletons;
    }
    return e.prototype.parse = function() {
      if (this.offset() !== 0)
        throw Error("parser can only be used once");
      return this.parseMessage(0, "", !1);
    }, e.prototype.parseMessage = function(t, n, r) {
      for (var a = []; !this.isEOF(); ) {
        var o = this.char();
        if (o === 123) {
          var s = this.parseArgument(t, r);
          if (s.err)
            return s;
          a.push(s.val);
        } else {
          if (o === 125 && t > 0)
            break;
          if (o === 35 && (n === "plural" || n === "selectordinal")) {
            var l = this.clonePosition();
            this.bump(), a.push({
              type: st.pound,
              location: Le(l, this.clonePosition())
            });
          } else if (o === 60 && !this.ignoreTag && this.peek() === 47) {
            if (r)
              break;
            return this.error(Ie.UNMATCHED_CLOSING_TAG, Le(this.clonePosition(), this.clonePosition()));
          } else if (o === 60 && !this.ignoreTag && ha(this.peek() || 0)) {
            var s = this.parseTag(t, n);
            if (s.err)
              return s;
            a.push(s.val);
          } else {
            var s = this.parseLiteral(t, n);
            if (s.err)
              return s;
            a.push(s.val);
          }
        }
      }
      return { val: a, err: null };
    }, e.prototype.parseTag = function(t, n) {
      var r = this.clonePosition();
      this.bump();
      var a = this.parseTagName();
      if (this.bumpSpace(), this.bumpIf("/>"))
        return {
          val: {
            type: st.literal,
            value: "<".concat(a, "/>"),
            location: Le(r, this.clonePosition())
          },
          err: null
        };
      if (this.bumpIf(">")) {
        var o = this.parseMessage(t + 1, n, !0);
        if (o.err)
          return o;
        var s = o.val, l = this.clonePosition();
        if (this.bumpIf("</")) {
          if (this.isEOF() || !ha(this.char()))
            return this.error(Ie.INVALID_TAG, Le(l, this.clonePosition()));
          var u = this.clonePosition(), c = this.parseTagName();
          return a !== c ? this.error(Ie.UNMATCHED_CLOSING_TAG, Le(u, this.clonePosition())) : (this.bumpSpace(), this.bumpIf(">") ? {
            val: {
              type: st.tag,
              value: a,
              children: s,
              location: Le(r, this.clonePosition())
            },
            err: null
          } : this.error(Ie.INVALID_TAG, Le(l, this.clonePosition())));
        } else
          return this.error(Ie.UNCLOSED_TAG, Le(r, this.clonePosition()));
      } else
        return this.error(Ie.INVALID_TAG, Le(r, this.clonePosition()));
    }, e.prototype.parseTagName = function() {
      var t = this.offset();
      for (this.bump(); !this.isEOF() && jl(this.char()); )
        this.bump();
      return this.message.slice(t, this.offset());
    }, e.prototype.parseLiteral = function(t, n) {
      for (var r = this.clonePosition(), a = ""; ; ) {
        var o = this.tryParseQuote(n);
        if (o) {
          a += o;
          continue;
        }
        var s = this.tryParseUnquoted(t, n);
        if (s) {
          a += s;
          continue;
        }
        var l = this.tryParseLeftAngleBracket();
        if (l) {
          a += l;
          continue;
        }
        break;
      }
      var u = Le(r, this.clonePosition());
      return {
        val: { type: st.literal, value: a, location: u },
        err: null
      };
    }, e.prototype.tryParseLeftAngleBracket = function() {
      return !this.isEOF() && this.char() === 60 && (this.ignoreTag || // If at the opening tag or closing tag position, bail.
      !Ul(this.peek() || 0)) ? (this.bump(), "<") : null;
    }, e.prototype.tryParseQuote = function(t) {
      if (this.isEOF() || this.char() !== 39)
        return null;
      switch (this.peek()) {
        case 39:
          return this.bump(), this.bump(), "'";
        // '{', '<', '>', '}'
        case 123:
        case 60:
        case 62:
        case 125:
          break;
        case 35:
          if (t === "plural" || t === "selectordinal")
            break;
          return null;
        default:
          return null;
      }
      this.bump();
      var n = [this.char()];
      for (this.bump(); !this.isEOF(); ) {
        var r = this.char();
        if (r === 39)
          if (this.peek() === 39)
            n.push(39), this.bump();
          else {
            this.bump();
            break;
          }
        else
          n.push(r);
        this.bump();
      }
      return da.apply(void 0, n);
    }, e.prototype.tryParseUnquoted = function(t, n) {
      if (this.isEOF())
        return null;
      var r = this.char();
      return r === 60 || r === 123 || r === 35 && (n === "plural" || n === "selectordinal") || r === 125 && t > 0 ? null : (this.bump(), da(r));
    }, e.prototype.parseArgument = function(t, n) {
      var r = this.clonePosition();
      if (this.bump(), this.bumpSpace(), this.isEOF())
        return this.error(Ie.EXPECT_ARGUMENT_CLOSING_BRACE, Le(r, this.clonePosition()));
      if (this.char() === 125)
        return this.bump(), this.error(Ie.EMPTY_ARGUMENT, Le(r, this.clonePosition()));
      var a = this.parseIdentifierIfPossible().value;
      if (!a)
        return this.error(Ie.MALFORMED_ARGUMENT, Le(r, this.clonePosition()));
      if (this.bumpSpace(), this.isEOF())
        return this.error(Ie.EXPECT_ARGUMENT_CLOSING_BRACE, Le(r, this.clonePosition()));
      switch (this.char()) {
        // Simple argument: `{name}`
        case 125:
          return this.bump(), {
            val: {
              type: st.argument,
              // value does not include the opening and closing braces.
              value: a,
              location: Le(r, this.clonePosition())
            },
            err: null
          };
        // Argument with options: `{name, format, ...}`
        case 44:
          return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(Ie.EXPECT_ARGUMENT_CLOSING_BRACE, Le(r, this.clonePosition())) : this.parseArgumentOptions(t, n, a, r);
        default:
          return this.error(Ie.MALFORMED_ARGUMENT, Le(r, this.clonePosition()));
      }
    }, e.prototype.parseIdentifierIfPossible = function() {
      var t = this.clonePosition(), n = this.offset(), r = fa(this.message, n), a = n + r.length;
      this.bumpTo(a);
      var o = this.clonePosition(), s = Le(t, o);
      return { value: r, location: s };
    }, e.prototype.parseArgumentOptions = function(t, n, r, a) {
      var o, s = this.clonePosition(), l = this.parseIdentifierIfPossible().value, u = this.clonePosition();
      switch (l) {
        case "":
          return this.error(Ie.EXPECT_ARGUMENT_TYPE, Le(s, u));
        case "number":
        case "date":
        case "time": {
          this.bumpSpace();
          var c = null;
          if (this.bumpIf(",")) {
            this.bumpSpace();
            var v = this.clonePosition(), T = this.parseSimpleArgStyleIfPossible();
            if (T.err)
              return T;
            var f = Ml(T.val);
            if (f.length === 0)
              return this.error(Ie.EXPECT_ARGUMENT_STYLE, Le(this.clonePosition(), this.clonePosition()));
            var p = Le(v, this.clonePosition());
            c = { style: f, styleLocation: p };
          }
          var C = this.tryParseArgumentClose(a);
          if (C.err)
            return C;
          var S = Le(a, this.clonePosition());
          if (c && ii(c?.style, "::", 0)) {
            var h = Bl(c.style.slice(2));
            if (l === "number") {
              var T = this.parseNumberSkeletonFromString(h, c.styleLocation);
              return T.err ? T : {
                val: { type: st.number, value: r, location: S, style: T.val },
                err: null
              };
            } else {
              if (h.length === 0)
                return this.error(Ie.EXPECT_DATE_TIME_SKELETON, S);
              var g = h;
              this.locale && (g = kl(h, this.locale));
              var f = {
                type: jn.dateTime,
                pattern: g,
                location: c.styleLocation,
                parsedOptions: this.shouldParseSkeletons ? gl(g) : {}
              }, O = l === "date" ? st.date : st.time;
              return {
                val: { type: O, value: r, location: S, style: f },
                err: null
              };
            }
          }
          return {
            val: {
              type: l === "number" ? st.number : l === "date" ? st.date : st.time,
              value: r,
              location: S,
              style: (o = c?.style) !== null && o !== void 0 ? o : null
            },
            err: null
          };
        }
        case "plural":
        case "selectordinal":
        case "select": {
          var m = this.clonePosition();
          if (this.bumpSpace(), !this.bumpIf(","))
            return this.error(Ie.EXPECT_SELECT_ARGUMENT_OPTIONS, Le(m, Be({}, m)));
          this.bumpSpace();
          var L = this.parseIdentifierIfPossible(), A = 0;
          if (l !== "select" && L.value === "offset") {
            if (!this.bumpIf(":"))
              return this.error(Ie.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, Le(this.clonePosition(), this.clonePosition()));
            this.bumpSpace();
            var T = this.tryParseDecimalInteger(Ie.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, Ie.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE);
            if (T.err)
              return T;
            this.bumpSpace(), L = this.parseIdentifierIfPossible(), A = T.val;
          }
          var N = this.tryParsePluralOrSelectOptions(t, l, n, L);
          if (N.err)
            return N;
          var C = this.tryParseArgumentClose(a);
          if (C.err)
            return C;
          var q = Le(a, this.clonePosition());
          return l === "select" ? {
            val: {
              type: st.select,
              value: r,
              options: oi(N.val),
              location: q
            },
            err: null
          } : {
            val: {
              type: st.plural,
              value: r,
              options: oi(N.val),
              offset: A,
              pluralType: l === "plural" ? "cardinal" : "ordinal",
              location: q
            },
            err: null
          };
        }
        default:
          return this.error(Ie.INVALID_ARGUMENT_TYPE, Le(s, u));
      }
    }, e.prototype.tryParseArgumentClose = function(t) {
      return this.isEOF() || this.char() !== 125 ? this.error(Ie.EXPECT_ARGUMENT_CLOSING_BRACE, Le(t, this.clonePosition())) : (this.bump(), { val: !0, err: null });
    }, e.prototype.parseSimpleArgStyleIfPossible = function() {
      for (var t = 0, n = this.clonePosition(); !this.isEOF(); ) {
        var r = this.char();
        switch (r) {
          case 39: {
            this.bump();
            var a = this.clonePosition();
            if (!this.bumpUntil("'"))
              return this.error(Ie.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE, Le(a, this.clonePosition()));
            this.bump();
            break;
          }
          case 123: {
            t += 1, this.bump();
            break;
          }
          case 125: {
            if (t > 0)
              t -= 1;
            else
              return {
                val: this.message.slice(n.offset, this.offset()),
                err: null
              };
            break;
          }
          default:
            this.bump();
            break;
        }
      }
      return {
        val: this.message.slice(n.offset, this.offset()),
        err: null
      };
    }, e.prototype.parseNumberSkeletonFromString = function(t, n) {
      var r = [];
      try {
        r = _l(t);
      } catch {
        return this.error(Ie.INVALID_NUMBER_SKELETON, n);
      }
      return {
        val: {
          type: jn.number,
          tokens: r,
          location: n,
          parsedOptions: this.shouldParseSkeletons ? xl(r) : {}
        },
        err: null
      };
    }, e.prototype.tryParsePluralOrSelectOptions = function(t, n, r, a) {
      for (var o, s = !1, l = [], u = /* @__PURE__ */ new Set(), c = a.value, v = a.location; ; ) {
        if (c.length === 0) {
          var T = this.clonePosition();
          if (n !== "select" && this.bumpIf("=")) {
            var f = this.tryParseDecimalInteger(Ie.EXPECT_PLURAL_ARGUMENT_SELECTOR, Ie.INVALID_PLURAL_ARGUMENT_SELECTOR);
            if (f.err)
              return f;
            v = Le(T, this.clonePosition()), c = this.message.slice(T.offset, this.offset());
          } else
            break;
        }
        if (u.has(c))
          return this.error(n === "select" ? Ie.DUPLICATE_SELECT_ARGUMENT_SELECTOR : Ie.DUPLICATE_PLURAL_ARGUMENT_SELECTOR, v);
        c === "other" && (s = !0), this.bumpSpace();
        var p = this.clonePosition();
        if (!this.bumpIf("{"))
          return this.error(n === "select" ? Ie.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT : Ie.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT, Le(this.clonePosition(), this.clonePosition()));
        var C = this.parseMessage(t + 1, n, r);
        if (C.err)
          return C;
        var S = this.tryParseArgumentClose(p);
        if (S.err)
          return S;
        l.push([
          c,
          {
            value: C.val,
            location: Le(p, this.clonePosition())
          }
        ]), u.add(c), this.bumpSpace(), o = this.parseIdentifierIfPossible(), c = o.value, v = o.location;
      }
      return l.length === 0 ? this.error(n === "select" ? Ie.EXPECT_SELECT_ARGUMENT_SELECTOR : Ie.EXPECT_PLURAL_ARGUMENT_SELECTOR, Le(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !s ? this.error(Ie.MISSING_OTHER_CLAUSE, Le(this.clonePosition(), this.clonePosition())) : { val: l, err: null };
    }, e.prototype.tryParseDecimalInteger = function(t, n) {
      var r = 1, a = this.clonePosition();
      this.bumpIf("+") || this.bumpIf("-") && (r = -1);
      for (var o = !1, s = 0; !this.isEOF(); ) {
        var l = this.char();
        if (l >= 48 && l <= 57)
          o = !0, s = s * 10 + (l - 48), this.bump();
        else
          break;
      }
      var u = Le(a, this.clonePosition());
      return o ? (s *= r, Nl(s) ? { val: s, err: null } : this.error(n, u)) : this.error(t, u);
    }, e.prototype.offset = function() {
      return this.position.offset;
    }, e.prototype.isEOF = function() {
      return this.offset() === this.message.length;
    }, e.prototype.clonePosition = function() {
      return {
        offset: this.position.offset,
        line: this.position.line,
        column: this.position.column
      };
    }, e.prototype.char = function() {
      var t = this.position.offset;
      if (t >= this.message.length)
        throw Error("out of bound");
      var n = uo(this.message, t);
      if (n === void 0)
        throw Error("Offset ".concat(t, " is at invalid UTF-16 code unit boundary"));
      return n;
    }, e.prototype.error = function(t, n) {
      return {
        val: null,
        err: {
          kind: t,
          message: this.message,
          location: n
        }
      };
    }, e.prototype.bump = function() {
      if (!this.isEOF()) {
        var t = this.char();
        t === 10 ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += t < 65536 ? 1 : 2);
      }
    }, e.prototype.bumpIf = function(t) {
      if (ii(this.message, t, this.offset())) {
        for (var n = 0; n < t.length; n++)
          this.bump();
        return !0;
      }
      return !1;
    }, e.prototype.bumpUntil = function(t) {
      var n = this.offset(), r = this.message.indexOf(t, n);
      return r >= 0 ? (this.bumpTo(r), !0) : (this.bumpTo(this.message.length), !1);
    }, e.prototype.bumpTo = function(t) {
      if (this.offset() > t)
        throw Error("targetOffset ".concat(t, " must be greater than or equal to the current offset ").concat(this.offset()));
      for (t = Math.min(t, this.message.length); ; ) {
        var n = this.offset();
        if (n === t)
          break;
        if (n > t)
          throw Error("targetOffset ".concat(t, " is at invalid UTF-16 code unit boundary"));
        if (this.bump(), this.isEOF())
          break;
      }
    }, e.prototype.bumpSpace = function() {
      for (; !this.isEOF() && fo(this.char()); )
        this.bump();
    }, e.prototype.peek = function() {
      if (this.isEOF())
        return null;
      var t = this.char(), n = this.offset(), r = this.message.charCodeAt(n + (t >= 65536 ? 2 : 1));
      return r ?? null;
    }, e;
  })()
);
function ha(e) {
  return e >= 97 && e <= 122 || e >= 65 && e <= 90;
}
function Ul(e) {
  return ha(e) || e === 47;
}
function jl(e) {
  return e === 45 || e === 46 || e >= 48 && e <= 57 || e === 95 || e >= 97 && e <= 122 || e >= 65 && e <= 90 || e == 183 || e >= 192 && e <= 214 || e >= 216 && e <= 246 || e >= 248 && e <= 893 || e >= 895 && e <= 8191 || e >= 8204 && e <= 8205 || e >= 8255 && e <= 8256 || e >= 8304 && e <= 8591 || e >= 11264 && e <= 12271 || e >= 12289 && e <= 55295 || e >= 63744 && e <= 64975 || e >= 65008 && e <= 65533 || e >= 65536 && e <= 983039;
}
function fo(e) {
  return e >= 9 && e <= 13 || e === 32 || e === 133 || e >= 8206 && e <= 8207 || e === 8232 || e === 8233;
}
function Fl(e) {
  return e >= 33 && e <= 35 || e === 36 || e >= 37 && e <= 39 || e === 40 || e === 41 || e === 42 || e === 43 || e === 44 || e === 45 || e >= 46 && e <= 47 || e >= 58 && e <= 59 || e >= 60 && e <= 62 || e >= 63 && e <= 64 || e === 91 || e === 92 || e === 93 || e === 94 || e === 96 || e === 123 || e === 124 || e === 125 || e === 126 || e === 161 || e >= 162 && e <= 165 || e === 166 || e === 167 || e === 169 || e === 171 || e === 172 || e === 174 || e === 176 || e === 177 || e === 182 || e === 187 || e === 191 || e === 215 || e === 247 || e >= 8208 && e <= 8213 || e >= 8214 && e <= 8215 || e === 8216 || e === 8217 || e === 8218 || e >= 8219 && e <= 8220 || e === 8221 || e === 8222 || e === 8223 || e >= 8224 && e <= 8231 || e >= 8240 && e <= 8248 || e === 8249 || e === 8250 || e >= 8251 && e <= 8254 || e >= 8257 && e <= 8259 || e === 8260 || e === 8261 || e === 8262 || e >= 8263 && e <= 8273 || e === 8274 || e === 8275 || e >= 8277 && e <= 8286 || e >= 8592 && e <= 8596 || e >= 8597 && e <= 8601 || e >= 8602 && e <= 8603 || e >= 8604 && e <= 8607 || e === 8608 || e >= 8609 && e <= 8610 || e === 8611 || e >= 8612 && e <= 8613 || e === 8614 || e >= 8615 && e <= 8621 || e === 8622 || e >= 8623 && e <= 8653 || e >= 8654 && e <= 8655 || e >= 8656 && e <= 8657 || e === 8658 || e === 8659 || e === 8660 || e >= 8661 && e <= 8691 || e >= 8692 && e <= 8959 || e >= 8960 && e <= 8967 || e === 8968 || e === 8969 || e === 8970 || e === 8971 || e >= 8972 && e <= 8991 || e >= 8992 && e <= 8993 || e >= 8994 && e <= 9e3 || e === 9001 || e === 9002 || e >= 9003 && e <= 9083 || e === 9084 || e >= 9085 && e <= 9114 || e >= 9115 && e <= 9139 || e >= 9140 && e <= 9179 || e >= 9180 && e <= 9185 || e >= 9186 && e <= 9254 || e >= 9255 && e <= 9279 || e >= 9280 && e <= 9290 || e >= 9291 && e <= 9311 || e >= 9472 && e <= 9654 || e === 9655 || e >= 9656 && e <= 9664 || e === 9665 || e >= 9666 && e <= 9719 || e >= 9720 && e <= 9727 || e >= 9728 && e <= 9838 || e === 9839 || e >= 9840 && e <= 10087 || e === 10088 || e === 10089 || e === 10090 || e === 10091 || e === 10092 || e === 10093 || e === 10094 || e === 10095 || e === 10096 || e === 10097 || e === 10098 || e === 10099 || e === 10100 || e === 10101 || e >= 10132 && e <= 10175 || e >= 10176 && e <= 10180 || e === 10181 || e === 10182 || e >= 10183 && e <= 10213 || e === 10214 || e === 10215 || e === 10216 || e === 10217 || e === 10218 || e === 10219 || e === 10220 || e === 10221 || e === 10222 || e === 10223 || e >= 10224 && e <= 10239 || e >= 10240 && e <= 10495 || e >= 10496 && e <= 10626 || e === 10627 || e === 10628 || e === 10629 || e === 10630 || e === 10631 || e === 10632 || e === 10633 || e === 10634 || e === 10635 || e === 10636 || e === 10637 || e === 10638 || e === 10639 || e === 10640 || e === 10641 || e === 10642 || e === 10643 || e === 10644 || e === 10645 || e === 10646 || e === 10647 || e === 10648 || e >= 10649 && e <= 10711 || e === 10712 || e === 10713 || e === 10714 || e === 10715 || e >= 10716 && e <= 10747 || e === 10748 || e === 10749 || e >= 10750 && e <= 11007 || e >= 11008 && e <= 11055 || e >= 11056 && e <= 11076 || e >= 11077 && e <= 11078 || e >= 11079 && e <= 11084 || e >= 11085 && e <= 11123 || e >= 11124 && e <= 11125 || e >= 11126 && e <= 11157 || e === 11158 || e >= 11159 && e <= 11263 || e >= 11776 && e <= 11777 || e === 11778 || e === 11779 || e === 11780 || e === 11781 || e >= 11782 && e <= 11784 || e === 11785 || e === 11786 || e === 11787 || e === 11788 || e === 11789 || e >= 11790 && e <= 11798 || e === 11799 || e >= 11800 && e <= 11801 || e === 11802 || e === 11803 || e === 11804 || e === 11805 || e >= 11806 && e <= 11807 || e === 11808 || e === 11809 || e === 11810 || e === 11811 || e === 11812 || e === 11813 || e === 11814 || e === 11815 || e === 11816 || e === 11817 || e >= 11818 && e <= 11822 || e === 11823 || e >= 11824 && e <= 11833 || e >= 11834 && e <= 11835 || e >= 11836 && e <= 11839 || e === 11840 || e === 11841 || e === 11842 || e >= 11843 && e <= 11855 || e >= 11856 && e <= 11857 || e === 11858 || e >= 11859 && e <= 11903 || e >= 12289 && e <= 12291 || e === 12296 || e === 12297 || e === 12298 || e === 12299 || e === 12300 || e === 12301 || e === 12302 || e === 12303 || e === 12304 || e === 12305 || e >= 12306 && e <= 12307 || e === 12308 || e === 12309 || e === 12310 || e === 12311 || e === 12312 || e === 12313 || e === 12314 || e === 12315 || e === 12316 || e === 12317 || e >= 12318 && e <= 12319 || e === 12320 || e === 12336 || e === 64830 || e === 64831 || e >= 65093 && e <= 65094;
}
function va(e) {
  e.forEach(function(t) {
    if (delete t.location, to(t) || no(t))
      for (var n in t.options)
        delete t.options[n].location, va(t.options[n].value);
    else Ki(t) && ao(t.style) || ($i(t) || eo(t)) && ua(t.style) ? delete t.style.location : ro(t) && va(t.children);
  });
}
function Gl(e, t) {
  t === void 0 && (t = {}), t = Be({ shouldParseSkeletons: !0, requiresOtherClause: !0 }, t);
  var n = new Dl(e, t).parse();
  if (n.err) {
    var r = SyntaxError(Ie[n.err.kind]);
    throw r.location = n.err.location, r.originalMessage = n.err.message, r;
  }
  return t?.captureLocation || va(n.val), n.val;
}
var Fn;
(function(e) {
  e.MISSING_VALUE = "MISSING_VALUE", e.INVALID_VALUE = "INVALID_VALUE", e.MISSING_INTL_API = "MISSING_INTL_API";
})(Fn || (Fn = {}));
var Rr = (
  /** @class */
  (function(e) {
    Nr(t, e);
    function t(n, r, a) {
      var o = e.call(this, n) || this;
      return o.code = r, o.originalMessage = a, o;
    }
    return t.prototype.toString = function() {
      return "[formatjs Error: ".concat(this.code, "] ").concat(this.message);
    }, t;
  })(Error)
), li = (
  /** @class */
  (function(e) {
    Nr(t, e);
    function t(n, r, a, o) {
      return e.call(this, 'Invalid values for "'.concat(n, '": "').concat(r, '". Options are "').concat(Object.keys(a).join('", "'), '"'), Fn.INVALID_VALUE, o) || this;
    }
    return t;
  })(Rr)
), zl = (
  /** @class */
  (function(e) {
    Nr(t, e);
    function t(n, r, a) {
      return e.call(this, 'Value for "'.concat(n, '" must be of type ').concat(r), Fn.INVALID_VALUE, a) || this;
    }
    return t;
  })(Rr)
), Wl = (
  /** @class */
  (function(e) {
    Nr(t, e);
    function t(n, r) {
      return e.call(this, 'The intl string context variable "'.concat(n, '" was not provided to the string "').concat(r, '"'), Fn.MISSING_VALUE, r) || this;
    }
    return t;
  })(Rr)
), Gt;
(function(e) {
  e[e.literal = 0] = "literal", e[e.object = 1] = "object";
})(Gt || (Gt = {}));
function Vl(e) {
  return e.length < 2 ? e : e.reduce(function(t, n) {
    var r = t[t.length - 1];
    return !r || r.type !== Gt.literal || n.type !== Gt.literal ? t.push(n) : r.value += n.value, t;
  }, []);
}
function ql(e) {
  return typeof e == "function";
}
function xr(e, t, n, r, a, o, s) {
  if (e.length === 1 && ti(e[0]))
    return [
      {
        type: Gt.literal,
        value: e[0].value
      }
    ];
  for (var l = [], u = 0, c = e; u < c.length; u++) {
    var v = c[u];
    if (ti(v)) {
      l.push({
        type: Gt.literal,
        value: v.value
      });
      continue;
    }
    if (vl(v)) {
      typeof o == "number" && l.push({
        type: Gt.literal,
        value: n.getNumberFormat(t).format(o)
      });
      continue;
    }
    var T = v.value;
    if (!(a && T in a))
      throw new Wl(T, s);
    var f = a[T];
    if (hl(v)) {
      (!f || typeof f == "string" || typeof f == "number") && (f = typeof f == "string" || typeof f == "number" ? String(f) : ""), l.push({
        type: typeof f == "string" ? Gt.literal : Gt.object,
        value: f
      });
      continue;
    }
    if ($i(v)) {
      var p = typeof v.style == "string" ? r.date[v.style] : ua(v.style) ? v.style.parsedOptions : void 0;
      l.push({
        type: Gt.literal,
        value: n.getDateTimeFormat(t, p).format(f)
      });
      continue;
    }
    if (eo(v)) {
      var p = typeof v.style == "string" ? r.time[v.style] : ua(v.style) ? v.style.parsedOptions : r.time.medium;
      l.push({
        type: Gt.literal,
        value: n.getDateTimeFormat(t, p).format(f)
      });
      continue;
    }
    if (Ki(v)) {
      var p = typeof v.style == "string" ? r.number[v.style] : ao(v.style) ? v.style.parsedOptions : void 0;
      p && p.scale && (f = f * (p.scale || 1)), l.push({
        type: Gt.literal,
        value: n.getNumberFormat(t, p).format(f)
      });
      continue;
    }
    if (ro(v)) {
      var C = v.children, S = v.value, h = a[S];
      if (!ql(h))
        throw new zl(S, "function", s);
      var g = xr(C, t, n, r, a, o), O = h(g.map(function(A) {
        return A.value;
      }));
      Array.isArray(O) || (O = [O]), l.push.apply(l, O.map(function(A) {
        return {
          type: typeof A == "string" ? Gt.literal : Gt.object,
          value: A
        };
      }));
    }
    if (to(v)) {
      var m = v.options[f] || v.options.other;
      if (!m)
        throw new li(v.value, f, Object.keys(v.options), s);
      l.push.apply(l, xr(m.value, t, n, r, a));
      continue;
    }
    if (no(v)) {
      var m = v.options["=".concat(f)];
      if (!m) {
        if (!Intl.PluralRules)
          throw new Rr(`Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`, Fn.MISSING_INTL_API, s);
        var L = n.getPluralRules(t, { type: v.pluralType }).select(f - (v.offset || 0));
        m = v.options[L] || v.options.other;
      }
      if (!m)
        throw new li(v.value, f, Object.keys(v.options), s);
      l.push.apply(l, xr(m.value, t, n, r, a, f - (v.offset || 0)));
      continue;
    }
  }
  return Vl(l);
}
function Xl(e, t) {
  return t ? Be(Be(Be({}, e || {}), t || {}), Object.keys(e).reduce(function(n, r) {
    return n[r] = Be(Be({}, e[r]), t[r] || {}), n;
  }, {})) : e;
}
function Zl(e, t) {
  return t ? Object.keys(e).reduce(function(n, r) {
    return n[r] = Xl(e[r], t[r]), n;
  }, Be({}, e)) : e;
}
function Yr(e) {
  return {
    create: function() {
      return {
        get: function(t) {
          return e[t];
        },
        set: function(t, n) {
          e[t] = n;
        }
      };
    }
  };
}
function Jl(e) {
  return e === void 0 && (e = {
    number: {},
    dateTime: {},
    pluralRules: {}
  }), {
    getNumberFormat: Xr(function() {
      for (var t, n = [], r = 0; r < arguments.length; r++)
        n[r] = arguments[r];
      return new ((t = Intl.NumberFormat).bind.apply(t, qr([void 0], n, !1)))();
    }, {
      cache: Yr(e.number),
      strategy: Zr.variadic
    }),
    getDateTimeFormat: Xr(function() {
      for (var t, n = [], r = 0; r < arguments.length; r++)
        n[r] = arguments[r];
      return new ((t = Intl.DateTimeFormat).bind.apply(t, qr([void 0], n, !1)))();
    }, {
      cache: Yr(e.dateTime),
      strategy: Zr.variadic
    }),
    getPluralRules: Xr(function() {
      for (var t, n = [], r = 0; r < arguments.length; r++)
        n[r] = arguments[r];
      return new ((t = Intl.PluralRules).bind.apply(t, qr([void 0], n, !1)))();
    }, {
      cache: Yr(e.pluralRules),
      strategy: Zr.variadic
    })
  };
}
var Yl = (
  /** @class */
  (function() {
    function e(t, n, r, a) {
      n === void 0 && (n = e.defaultLocale);
      var o = this;
      if (this.formatterCache = {
        number: {},
        dateTime: {},
        pluralRules: {}
      }, this.format = function(u) {
        var c = o.formatToParts(u);
        if (c.length === 1)
          return c[0].value;
        var v = c.reduce(function(T, f) {
          return !T.length || f.type !== Gt.literal || typeof T[T.length - 1] != "string" ? T.push(f.value) : T[T.length - 1] += f.value, T;
        }, []);
        return v.length <= 1 ? v[0] || "" : v;
      }, this.formatToParts = function(u) {
        return xr(o.ast, o.locales, o.formatters, o.formats, u, void 0, o.message);
      }, this.resolvedOptions = function() {
        var u;
        return {
          locale: ((u = o.resolvedLocale) === null || u === void 0 ? void 0 : u.toString()) || Intl.NumberFormat.supportedLocalesOf(o.locales)[0]
        };
      }, this.getAst = function() {
        return o.ast;
      }, this.locales = n, this.resolvedLocale = e.resolveLocale(n), typeof t == "string") {
        if (this.message = t, !e.__parse)
          throw new TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
        var s = a || {};
        s.formatters;
        var l = il(s, ["formatters"]);
        this.ast = e.__parse(t, Be(Be({}, l), { locale: this.resolvedLocale }));
      } else
        this.ast = t;
      if (!Array.isArray(this.ast))
        throw new TypeError("A message must be provided as a String or AST.");
      this.formats = Zl(e.formats, r), this.formatters = a && a.formatters || Jl(this.formatterCache);
    }
    return Object.defineProperty(e, "defaultLocale", {
      get: function() {
        return e.memoizedDefaultLocale || (e.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale), e.memoizedDefaultLocale;
      },
      enumerable: !1,
      configurable: !0
    }), e.memoizedDefaultLocale = null, e.resolveLocale = function(t) {
      if (!(typeof Intl.Locale > "u")) {
        var n = Intl.NumberFormat.supportedLocalesOf(t);
        return n.length > 0 ? new Intl.Locale(n[0]) : new Intl.Locale(typeof t == "string" ? t : t[0]);
      }
    }, e.__parse = Gl, e.formats = {
      number: {
        integer: {
          maximumFractionDigits: 0
        },
        currency: {
          style: "currency"
        },
        percent: {
          style: "percent"
        }
      },
      date: {
        short: {
          month: "numeric",
          day: "numeric",
          year: "2-digit"
        },
        medium: {
          month: "short",
          day: "numeric",
          year: "numeric"
        },
        long: {
          month: "long",
          day: "numeric",
          year: "numeric"
        },
        full: {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric"
        }
      },
      time: {
        short: {
          hour: "numeric",
          minute: "numeric"
        },
        medium: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric"
        },
        long: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        },
        full: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        }
      }
    }, e;
  })()
);
function Ql(e, t) {
  if (t == null)
    return;
  if (t in e)
    return e[t];
  const n = t.split(".");
  let r = e;
  for (let a = 0; a < n.length; a++)
    if (typeof r == "object") {
      if (a > 0) {
        const o = n.slice(a, n.length).join(".");
        if (o in r) {
          r = r[o];
          break;
        }
      }
      r = r[n[a]];
    } else
      r = void 0;
  return r;
}
const xn = {}, Kl = (e, t, n) => n && (t in xn || (xn[t] = {}), e in xn[t] || (xn[t][e] = n), n), ho = (e, t) => {
  if (t == null)
    return;
  if (t in xn && e in xn[t])
    return xn[t][e];
  const n = Br(t);
  for (let r = 0; r < n.length; r++) {
    const a = n[r], o = eu(a, e);
    if (o)
      return Kl(e, t, o);
  }
};
let Ca;
const dr = ur({});
function $l(e) {
  return Ca[e] || null;
}
function vo(e) {
  return e in Ca;
}
function eu(e, t) {
  if (!vo(e))
    return null;
  const n = $l(e);
  return Ql(n, t);
}
function tu(e) {
  if (e == null)
    return;
  const t = Br(e);
  for (let n = 0; n < t.length; n++) {
    const r = t[n];
    if (vo(r))
      return r;
  }
}
function nu(e, ...t) {
  delete xn[e], dr.update((n) => (n[e] = al.all([n[e] || {}, ...t]), n));
}
Wn(
  [dr],
  ([e]) => Object.keys(e)
);
dr.subscribe((e) => Ca = e);
const kr = {};
function ru(e, t) {
  kr[e].delete(t), kr[e].size === 0 && delete kr[e];
}
function po(e) {
  return kr[e];
}
function au(e) {
  return Br(e).map((t) => {
    const n = po(t);
    return [t, n ? [...n] : []];
  }).filter(([, t]) => t.length > 0);
}
function pa(e) {
  return e == null ? !1 : Br(e).some(
    (t) => {
      var n;
      return (n = po(t)) == null ? void 0 : n.size;
    }
  );
}
function iu(e, t) {
  return Promise.all(
    t.map((r) => (ru(e, r), r().then((a) => a.default || a)))
  ).then((r) => nu(e, ...r));
}
const Qn = {};
function go(e) {
  if (!pa(e))
    return e in Qn ? Qn[e] : Promise.resolve();
  const t = au(e);
  return Qn[e] = Promise.all(
    t.map(
      ([n, r]) => iu(n, r)
    )
  ).then(() => {
    if (pa(e))
      return go(e);
    delete Qn[e];
  }), Qn[e];
}
const ou = {
  number: {
    scientific: { notation: "scientific" },
    engineering: { notation: "engineering" },
    compactLong: { notation: "compact", compactDisplay: "long" },
    compactShort: { notation: "compact", compactDisplay: "short" }
  },
  date: {
    short: { month: "numeric", day: "numeric", year: "2-digit" },
    medium: { month: "short", day: "numeric", year: "numeric" },
    long: { month: "long", day: "numeric", year: "numeric" },
    full: { weekday: "long", month: "long", day: "numeric", year: "numeric" }
  },
  time: {
    short: { hour: "numeric", minute: "numeric" },
    medium: { hour: "numeric", minute: "numeric", second: "numeric" },
    long: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    },
    full: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    }
  }
}, su = {
  fallbackLocale: null,
  loadingDelay: 200,
  formats: ou,
  warnOnMissingMessages: !0,
  handleMissingMessage: void 0,
  ignoreTag: !0
}, lu = su;
function Gn() {
  return lu;
}
const Qr = ur(!1);
var uu = Object.defineProperty, cu = Object.defineProperties, du = Object.getOwnPropertyDescriptors, ui = Object.getOwnPropertySymbols, fu = Object.prototype.hasOwnProperty, hu = Object.prototype.propertyIsEnumerable, ci = (e, t, n) => t in e ? uu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, vu = (e, t) => {
  for (var n in t || (t = {}))
    fu.call(t, n) && ci(e, n, t[n]);
  if (ui)
    for (var n of ui(t))
      hu.call(t, n) && ci(e, n, t[n]);
  return e;
}, pu = (e, t) => cu(e, du(t));
let ga;
const Ir = ur(null);
function di(e) {
  return e.split("-").map((t, n, r) => r.slice(0, n + 1).join("-")).reverse();
}
function Br(e, t = Gn().fallbackLocale) {
  const n = di(e);
  return t ? [.../* @__PURE__ */ new Set([...n, ...di(t)])] : n;
}
function Ln() {
  return ga ?? void 0;
}
Ir.subscribe((e) => {
  ga = e ?? void 0, typeof window < "u" && e != null && document.documentElement.setAttribute("lang", e);
});
const gu = (e) => {
  if (e && tu(e) && pa(e)) {
    const { loadingDelay: t } = Gn();
    let n;
    return typeof window < "u" && Ln() != null && t ? n = window.setTimeout(
      () => Qr.set(!0),
      t
    ) : Qr.set(!0), go(e).then(() => {
      Ir.set(e);
    }).finally(() => {
      clearTimeout(n), Qr.set(!1);
    });
  }
  return Ir.set(e);
}, Vn = pu(vu({}, Ir), {
  set: gu
}), Mr = (e) => {
  const t = /* @__PURE__ */ Object.create(null);
  return (r) => {
    const a = JSON.stringify(r);
    return a in t ? t[a] : t[a] = e(r);
  };
};
var mu = Object.defineProperty, Or = Object.getOwnPropertySymbols, mo = Object.prototype.hasOwnProperty, _o = Object.prototype.propertyIsEnumerable, fi = (e, t, n) => t in e ? mu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, La = (e, t) => {
  for (var n in t || (t = {}))
    mo.call(t, n) && fi(e, n, t[n]);
  if (Or)
    for (var n of Or(t))
      _o.call(t, n) && fi(e, n, t[n]);
  return e;
}, qn = (e, t) => {
  var n = {};
  for (var r in e)
    mo.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
  if (e != null && Or)
    for (var r of Or(e))
      t.indexOf(r) < 0 && _o.call(e, r) && (n[r] = e[r]);
  return n;
};
const rr = (e, t) => {
  const { formats: n } = Gn();
  if (e in n && t in n[e])
    return n[e][t];
  throw new Error(`[svelte-i18n] Unknown "${t}" ${e} format.`);
}, _u = Mr(
  (e) => {
    var t = e, { locale: n, format: r } = t, a = qn(t, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format numbers');
    return r && (a = rr("number", r)), new Intl.NumberFormat(n, a);
  }
), bu = Mr(
  (e) => {
    var t = e, { locale: n, format: r } = t, a = qn(t, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format dates');
    return r ? a = rr("date", r) : Object.keys(a).length === 0 && (a = rr("date", "short")), new Intl.DateTimeFormat(n, a);
  }
), yu = Mr(
  (e) => {
    var t = e, { locale: n, format: r } = t, a = qn(t, ["locale", "format"]);
    if (n == null)
      throw new Error(
        '[svelte-i18n] A "locale" must be set to format time values'
      );
    return r ? a = rr("time", r) : Object.keys(a).length === 0 && (a = rr("time", "short")), new Intl.DateTimeFormat(n, a);
  }
), wu = (e = {}) => {
  var t = e, {
    locale: n = Ln()
  } = t, r = qn(t, [
    "locale"
  ]);
  return _u(La({ locale: n }, r));
}, xu = (e = {}) => {
  var t = e, {
    locale: n = Ln()
  } = t, r = qn(t, [
    "locale"
  ]);
  return bu(La({ locale: n }, r));
}, ku = (e = {}) => {
  var t = e, {
    locale: n = Ln()
  } = t, r = qn(t, [
    "locale"
  ]);
  return yu(La({ locale: n }, r));
}, Eu = Mr(
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  (e, t = Ln()) => new Yl(e, t, Gn().formats, {
    ignoreTag: Gn().ignoreTag
  })
), Tu = (e, t = {}) => {
  var n, r, a, o;
  let s = t;
  typeof e == "object" && (s = e, e = s.id);
  const {
    values: l,
    locale: u = Ln(),
    default: c
  } = s;
  if (u == null)
    throw new Error(
      "[svelte-i18n] Cannot format a message without first setting the initial locale."
    );
  let v = ho(e, u);
  if (!v)
    v = (o = (a = (r = (n = Gn()).handleMissingMessage) == null ? void 0 : r.call(n, { locale: u, id: e, defaultValue: c })) != null ? a : c) != null ? o : e;
  else if (typeof v != "string")
    return console.warn(
      `[svelte-i18n] Message with id "${e}" must be of type "string", found: "${typeof v}". Gettin its value through the "$format" method is deprecated; use the "json" method instead.`
    ), v;
  if (!l)
    return v;
  let T = v;
  try {
    T = Eu(v, u).format(l);
  } catch (f) {
    f instanceof Error && console.warn(
      `[svelte-i18n] Message "${e}" has syntax error:`,
      f.message
    );
  }
  return T;
}, Su = (e, t) => ku(t).format(e), Au = (e, t) => xu(t).format(e), Iu = (e, t) => wu(t).format(e), Ou = (e, t = Ln()) => ho(e, t);
Wn([Vn, dr], () => Tu);
Wn([Vn], () => Su);
Wn([Vn], () => Au);
Wn([Vn], () => Iu);
Wn([Vn, dr], () => Ou);
const Cu = "__i18n__", Lu = [
  "label",
  "info",
  "placeholder",
  "description",
  "title",
  "value"
];
class Er extends Error {
  constructor(t) {
    super(t), this.name = "ShareError";
  }
}
async function Pu(e, t) {
  if (window.__gradio_space__ == null)
    throw new Er("Must be on Spaces to share.");
  let n, r, a;
  {
    let u;
    if (typeof e == "object" && e.url)
      u = e.url;
    else if (typeof e == "string")
      u = e;
    else
      throw new Error("Invalid data format for URL type");
    const c = await fetch(u);
    n = await c.blob(), r = c.headers.get("content-type") || "", a = c.headers.get("content-disposition") || "";
  }
  const o = new File([n], a, { type: r }), s = await fetch("https://huggingface.co/uploads", {
    method: "POST",
    body: o,
    headers: {
      "Content-Type": o.type,
      "X-Requested-With": "XMLHttpRequest"
    }
  });
  if (!s.ok) {
    if (s.headers.get("content-type")?.includes("application/json")) {
      const u = await s.json();
      throw new Er(`Upload failed: ${u.error}`);
    }
    throw new Er("Upload failed.");
  }
  return await s.text();
}
const Hu = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events",
  "register_component",
  "dispatcher"
];
function Nu(e) {
  return typeof e == "string" && e.includes(Cu);
}
class Ru {
  load_component;
  #e = ne(zt({}));
  get shared() {
    return i(this.#e);
  }
  set shared(t) {
    _(this.#e, t, !0);
  }
  #n = ne(zt({}));
  get props() {
    return i(this.#n);
  }
  set props(t) {
    _(this.#n, t, !0);
  }
  #t = ne((t) => t);
  get i18n() {
    return i(this.#t);
  }
  set i18n(t) {
    _(this.#t, t, !0);
  }
  translatable_props = {};
  dispatcher;
  last_update = null;
  shared_props = Hu;
  mounted = !1;
  old_value;
  register_component;
  constructor(t, n) {
    for (const r in t.shared_props)
      this.shared[r] = t.shared_props[r];
    for (const r in t.props)
      this.props[r] = t.props[r];
    if (n)
      for (const r in n)
        this.props[r] === void 0 && (this.props[r] = n[r]);
    this.i18n = this.props.i18n ?? ((r) => r);
    for (const r of Lu)
      this.shared[r] = this._translate_and_store(
        "shared",
        r,
        // @ts-ignore
        t.shared_props[r]
      ), this.props[r] = this._translate_and_store(
        "props",
        r,
        // @ts-ignore
        t.props[r]
      );
    this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {
    }), this.dispatcher = this.shared.dispatcher || (() => {
    }), this.register_component(
      t.shared_props.id,
      // @ts-ignore
      this.set_data.bind(this),
      this.get_data.bind(this)
    ), Jt(() => {
      for (const r in t.shared_props)
        this._is_i18n_managed(`shared.${r}`, t.shared_props[r]) || (this.shared[r] = t.shared_props[r]);
      for (const r in t.props)
        this._is_i18n_managed(`props.${r}`, t.props[r]) || (this.props[r] = t.props[r]);
      this.register_component(
        t.shared_props.id,
        // @ts-ignore
        this.set_data.bind(this),
        this.get_data.bind(this)
      ), ct(() => {
        this.shared.id = t.shared_props.id;
      });
    }), Object.keys(this.translatable_props).length > 0 && Vn.subscribe(() => {
      for (const [r, a] of Object.entries(this.translatable_props)) {
        const [o, s] = r.split("."), l = this.i18n(a);
        o === "shared" ? this.shared[s] = l : this.props[s] = l;
      }
    });
  }
  // check if props are translatable
  _is_i18n_managed(t, n) {
    const r = this.translatable_props[t];
    return r ? n === r ? !0 : (delete this.translatable_props[t], !1) : !1;
  }
  _translate_and_store(t, n, r) {
    if (typeof r != "string") return r;
    const a = this.i18n(r);
    return a !== r && (this.translatable_props[`${t}.${n}`] = r), a;
  }
  dispatch(t, n) {
    this.dispatcher(this.shared.id, t, n);
  }
  async get_data() {
    return Ss(this.props);
  }
  update(t) {
    this.set_data(t);
  }
  set_data(t) {
    for (const n in t) {
      const r = t[n], a = Nu(r) ? this._translate_and_store(this.shared_props.includes(n) ? "shared" : "props", n, r) : r;
      if (this.shared_props.includes(n)) {
        const o = n;
        this.shared[o] = a;
        continue;
      }
      this.props[n] = a;
    }
  }
  watch_for_change() {
    Jt(() => {
      this.mounted || (this.old_value = this.props.value, this.mounted = !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
    });
  }
}
const nt = {
  image: "#4fd1a5",
  text: "#8b83e8",
  audio: "#f5a623",
  video: "#4d9cf5",
  number: "#e879a8",
  boolean: "#f59e0b",
  file: "#94a3b8",
  json: "#22d3ee",
  gallery: "#34d399",
  model3d: "#a78bfa",
  any: "#6b6e78"
}, Bu = {
  image: "rgba(79, 209, 165, 0.15)",
  text: "rgba(139, 131, 232, 0.15)",
  audio: "rgba(245, 166, 35, 0.15)",
  video: "rgba(77, 156, 245, 0.15)",
  number: "rgba(232, 121, 168, 0.15)",
  boolean: "rgba(245, 158, 11, 0.15)",
  file: "rgba(148, 163, 184, 0.15)",
  json: "rgba(34, 211, 238, 0.15)",
  gallery: "rgba(52, 211, 153, 0.15)",
  model3d: "rgba(167, 139, 250, 0.15)",
  any: "rgba(107, 110, 120, 0.10)"
}, hi = {
  input: "IN",
  transform: "FN",
  output: "OUT",
  component: "IO"
};
function bo() {
  return crypto.randomUUID();
}
const vi = {
  version: "1",
  name: "My workflow",
  nodes: [
    {
      id: "node_default",
      kind: "component",
      label: "Image",
      source: "local",
      inputs: [{ id: "in", label: "Image", type: "image" }],
      outputs: [{ id: "out", label: "Image", type: "image" }],
      x: 80,
      y: 120,
      width: 200,
      height: 160,
      data: {}
    }
  ],
  edges: []
};
function Mu() {
  if (typeof localStorage > "u") return vi;
  try {
    const e = localStorage.getItem("gradio_workflow");
    if (e) {
      const t = JSON.parse(e);
      return t.nodes = t.nodes.map((n) => {
        if (n.kind === "output" && (!n.outputs || n.outputs.length === 0) && n.inputs?.[0] && (n.outputs = [{ id: "out", label: n.inputs[0].label, type: n.inputs[0].type }]), (n.kind === "input" || n.kind === "output") && n.source === "local") {
          const r = n.outputs[0]?.type ?? n.inputs[0]?.type ?? "any", a = n.outputs[0]?.label ?? n.inputs[0]?.label ?? n.label;
          n.kind = "component", (!n.inputs || n.inputs.length === 0) && (n.inputs = [{ id: "in", label: a, type: r }]), (!n.outputs || n.outputs.length === 0) && (n.outputs = [{ id: "out", label: a, type: r }]);
        }
        return { ...n, data: n.data ?? {} };
      }), t;
    }
  } catch {
  }
  return vi;
}
const Ot = ur(Mu());
Ot.subscribe((e) => {
  if (typeof localStorage < "u") {
    const t = {
      ...e,
      nodes: e.nodes.map((n) => ({
        ...n,
        data: Object.fromEntries(
          Object.entries(n.data ?? {}).map(([r, a]) => [
            r,
            typeof a == "string" || typeof a == "number" || typeof a == "boolean" ? a : null
          ])
        )
      }))
    };
    localStorage.setItem("gradio_workflow", JSON.stringify(t, null, 2));
  }
});
function _r(e, t, n) {
  const r = bo(), a = {};
  for (const o of e.inputs)
    o.default_value !== void 0 && (a[o.id] = o.default_value);
  return Ot.update((o) => ({
    ...o,
    nodes: [...o.nodes, { ...e, id: r, x: t, y: n, data: a }]
  })), r;
}
function Du(e, t, n) {
  Ot.update((r) => ({
    ...r,
    nodes: r.nodes.map((a) => a.id === e ? { ...a, x: t, y: n } : a)
  }));
}
function Kr(e) {
  Ot.update((t) => ({
    ...t,
    edges: [...t.edges, { ...e, id: bo() }]
  }));
}
function Uu(e) {
  Ot.update((t) => ({
    ...t,
    edges: t.edges.filter((n) => n.id !== e)
  }));
}
function pi(e) {
  Ot.update((t) => {
    const n = t.nodes.find((r) => r.id === e);
    return n && Object.values(n.data ?? {}).forEach((r) => {
      r && typeof r == "object" && r.url?.startsWith("blob:") && URL.revokeObjectURL(r.url);
    }), {
      ...t,
      nodes: t.nodes.filter((r) => r.id !== e),
      edges: t.edges.filter(
        (r) => r.from_node_id !== e && r.to_node_id !== e
      )
    };
  });
}
function gi(e, t, n) {
  Ot.update((r) => ({
    ...r,
    nodes: r.nodes.map(
      (a) => a.id === e ? { ...a, data: { ...a.data, [t]: n } } : a
    )
  }));
}
function ju(e, t, n) {
  Ot.update((r) => ({
    ...r,
    nodes: r.nodes.map(
      (a) => a.id === e ? { ...a, width: t, height: n } : a
    )
  }));
}
ys();
const Fu = /`([^`]+)`/g, Gu = /\[([^\]]+)\]\(([^)]+)\)/g, zu = /\*\*(.+?)\*\*/g, Wu = /__(.+?)__/g, Vu = /\*(.+?)\*/g, qu = new RegExp("(?<!\\w)_(.+?)_(?!\\w)", "g"), Xu = /^\w+:/;
function Zu(e) {
  return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function Ju(e, t, n) {
  const r = n.trim();
  return Xu.test(r) ? /^https?:/i.test(r) ? `<a href="${r}" target="_blank" rel="noopener noreferrer">${t}</a>` : t : `<a href="${r}" target="_blank" rel="noopener noreferrer">${t}</a>`;
}
function mi(e) {
  let t = Zu(e);
  return t = t.replace(Fu, "<code>$1</code>"), t = t.replace(Gu, Ju), t = t.replace(zu, "<strong>$1</strong>"), t = t.replace(Wu, "<strong>$1</strong>"), t = t.replace(Vu, "<em>$1</em>"), t = t.replace(qu, "<em>$1</em>"), t = t.replace(/\n/g, "<br>"), t;
}
var Yu = /* @__PURE__ */ P('<div class="info-text svelte-wxcmx3"></div>');
function Qu(e, t) {
  Wt(t, !1);
  let n = Z(t, "info", 8);
  cr();
  var r = Yu();
  Bs(
    r,
    () => (xt(mi), xt(n()), ct(() => mi(n()))),
    !0
  ), w(e, r), Vt();
}
var Ku = /* @__PURE__ */ P('<span data-testid="block-info"><!></span> <!>', 1);
function $u(e, t) {
  let n = Z(t, "show_label", 8, !0), r = Z(t, "info", 8, void 0), a = Z(t, "rtl", 8, !1);
  var o = Ku(), s = be(o);
  let l;
  var u = k(s);
  Ia(u, t, "default", {});
  var c = I(s, 2);
  {
    var v = (T) => {
      Qu(T, {
        get info() {
          return r();
        }
      });
    };
    W(c, (T) => {
      r() && T(v);
    });
  }
  F(() => {
    M(s, "dir", a() ? "rtl" : "ltr"), l = We(s, 1, "svelte-p6t3tw", null, l, {
      hide: !n(),
      "has-info": r() != null,
      "sr-only": !n()
    }), s.dir = s.dir;
  }), w(e, o);
}
var ec = /* @__PURE__ */ P('<label for="" data-testid="block-label"><span class="svelte-1cbxd8k"><!></span> </label>');
function tc(e, t) {
  let n = Z(t, "label", 8, null), r = Z(t, "Icon", 8), a = Z(t, "show_label", 8, !0), o = Z(t, "disable", 8, !1), s = Z(t, "float", 8, !0), l = Z(t, "rtl", 8, !1);
  var u = ec();
  let c;
  var v = k(u), T = k(v);
  r()(T, {});
  var f = I(v);
  F(() => {
    M(u, "dir", l() ? "rtl" : "ltr"), c = We(u, 1, "svelte-1cbxd8k", null, c, {
      hide: !a(),
      "sr-only": !a(),
      float: s(),
      "hide-label": o()
    }), Y(f, ` ${n() ?? ""}`), u.dir = u.dir;
  }), w(e, u);
}
var nc = /* @__PURE__ */ P("<a><!></a>");
function rc(e, t) {
  const n = Ka(t, ["children", "$$slots", "$$events", "$$legacy"]), r = Ka(n, ["href", "download"]);
  Wt(t, !1);
  let a = Z(t, "href", 8, void 0), o = Z(t, "download", 8);
  const s = Oa();
  cr();
  var l = nc(), u = pe(() => s.bind(null, "click"));
  Zi(
    l,
    () => ({
      class: "download-link",
      "data-testid": "download-link",
      href: a(),
      target: ct(() => typeof window < "u" && window.__is_colab__ ? "_blank" : null),
      rel: "noopener noreferrer",
      download: o(),
      ...r,
      [Bn]: { position: "relative" }
    }),
    void 0,
    void 0,
    void 0,
    "svelte-1cddrz"
  );
  var c = k(l);
  Ia(c, t, "default", {}), Oe("click", l, function(...v) {
    i(u)?.apply(this, v);
  }), w(e, l), Vt();
}
var ac = /* @__PURE__ */ P('<span class="svelte-17yj618"> </span>'), ic = /* @__PURE__ */ P("<button><!> <div><!> <!></div></button>");
function ar(e, t) {
  let n = Z(t, "label", 3, ""), r = Z(t, "show_label", 3, !1), a = Z(t, "pending", 3, !1), o = Z(t, "size", 3, "small"), s = Z(t, "padded", 3, !0), l = Z(t, "highlight", 3, !1), u = Z(t, "disabled", 3, !1), c = Z(t, "hasPopup", 3, !1), v = Z(t, "color", 3, "var(--block-label-text-color)"), T = Z(t, "transparent", 3, !1), f = Z(t, "background", 3, "var(--block-background-fill)"), p = Z(t, "border", 3, "transparent"), C = pe(() => l() ? "var(--color-accent)" : v());
  var S = ic();
  let h, g;
  var O = k(S);
  {
    var m = (j) => {
      var de = ac(), re = k(de);
      F(() => Y(re, n())), w(j, de);
    };
    W(O, (j) => {
      r() && j(m);
    });
  }
  var L = I(O, 2);
  let A;
  var N = k(L);
  Ms(N, () => t.Icon, (j, de) => {
    de(j, {});
  });
  var q = I(N, 2);
  {
    var K = (j) => {
      var de = Et(), re = be(de);
      Wi(re, () => t.children), w(j, de);
    };
    W(q, (j) => {
      t.children && j(K);
    });
  }
  F(() => {
    h = We(S, 1, "icon-button svelte-17yj618", null, h, {
      pending: a(),
      padded: s(),
      highlight: l(),
      transparent: T()
    }), S.disabled = u(), M(S, "aria-label", n()), M(S, "aria-haspopup", c()), M(S, "title", n()), g = kt(S, "", g, {
      "--border-color": p(),
      color: !u() && i(C) ? i(C) : "var(--block-label-text-color)",
      "--bg-color": u() ? "auto" : f()
    }), A = We(L, 1, "svelte-17yj618", null, A, {
      "x-small": o() === "x-small",
      small: o() === "small",
      large: o() === "large",
      medium: o() === "medium"
    });
  }), z("click", S, function(...j) {
    t.onclick?.apply(this, j);
  }), w(e, S);
}
un(["click"]);
var oc = /* @__PURE__ */ P('<div aria-label="Empty value"><div class="icon svelte-l6gsuy"><!></div></div>');
function sc(e, t) {
  Wt(t, !1);
  const n = Un();
  let r = Z(t, "size", 8, "small"), a = Z(t, "unpadded_box", 8, !1), o = Un();
  function s(T) {
    var f;
    if (!T) return !1;
    const { height: p } = T.getBoundingClientRect(), { height: C } = ((f = T.parentElement) === null || f === void 0 ? void 0 : f.getBoundingClientRect()) || { height: p };
    return p > C + 2;
  }
  ws(() => i(o), () => {
    _(n, s(i(o)));
  }), xs();
  var l = oc();
  let u;
  var c = k(l), v = k(c);
  Ia(v, t, "default", {}), ln(l, (T) => _(o, T), () => i(o)), F(() => u = We(l, 1, "empty svelte-l6gsuy", null, u, {
    small: r() === "small",
    large: r() === "large",
    unpadded_box: a(),
    small_parent: i(n)
  })), w(e, l), Vt();
}
var lc = /* @__PURE__ */ Qt('<svg width="100%" height="100%" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="currentColor"><path d="M5 13L9 17L19 7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>');
function uc(e) {
  var t = lc();
  w(e, t);
}
var cc = /* @__PURE__ */ Qt('<svg id="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="100%" height="100%"><path d="M23,20a5,5,0,0,0-3.89,1.89L11.8,17.32a4.46,4.46,0,0,0,0-2.64l7.31-4.57A5,5,0,1,0,18,7a4.79,4.79,0,0,0,.2,1.32l-7.31,4.57a5,5,0,1,0,0,6.22l7.31,4.57A4.79,4.79,0,0,0,18,25a5,5,0,1,0,5-5ZM23,4a3,3,0,1,1-3,3A3,3,0,0,1,23,4ZM7,19a3,3,0,1,1,3-3A3,3,0,0,1,7,19Zm16,9a3,3,0,1,1,3-3A3,3,0,0,1,23,28Z" fill="currentColor"></path></svg>');
function dc(e) {
  var t = cc();
  w(e, t);
}
var fc = /* @__PURE__ */ Qt('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 33 33" color="currentColor" aria-hidden="true" width="100%" height="100%"><path fill="currentColor" d="M28 10v18H10V10h18m0-2H10a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2Z"></path><path fill="currentColor" d="M4 18H2V4a2 2 0 0 1 2-2h14v2H4Z"></path></svg>');
function hc(e) {
  var t = fc();
  w(e, t);
}
var vc = /* @__PURE__ */ Qt('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 32 32"><path fill="currentColor" d="M26 24v4H6v-4H4v4a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-4zm0-10l-1.41-1.41L17 20.17V2h-2v18.17l-7.59-7.58L6 14l10 10l10-10z"></path></svg>');
function pc(e) {
  var t = vc();
  w(e, t);
}
var gc = /* @__PURE__ */ Qt('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-image"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>');
function _i(e) {
  var t = gc();
  w(e, t);
}
var mc = /* @__PURE__ */ Qt('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-maximize" width="100%" height="100%"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path></svg>');
function _c(e) {
  var t = mc();
  w(e, t);
}
var bc = /* @__PURE__ */ Qt('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minimize" width="100%" height="100%"><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"></path></svg>');
function yc(e) {
  var t = bc();
  w(e, t);
}
var wc = /* @__PURE__ */ Qt('<svg viewBox="0 0 22 24" width="100%" height="100%" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><path d="M19.1168 12.1484C19.474 12.3581 19.9336 12.2384 20.1432 11.8811C20.3528 11.5238 20.2331 11.0643 19.8758 10.8547L19.1168 12.1484ZM6.94331 4.13656L6.55624 4.77902L6.56378 4.78344L6.94331 4.13656ZM5.92408 4.1598L5.50816 3.5357L5.50816 3.5357L5.92408 4.1598ZM5.51031 5.09156L4.76841 5.20151C4.77575 5.25101 4.78802 5.29965 4.80505 5.34671L5.51031 5.09156ZM7.12405 11.7567C7.26496 12.1462 7.69495 12.3477 8.08446 12.2068C8.47397 12.0659 8.67549 11.6359 8.53458 11.2464L7.12405 11.7567ZM19.8758 12.1484C20.2331 11.9388 20.3528 11.4793 20.1432 11.122C19.9336 10.7648 19.474 10.6451 19.1168 10.8547L19.8758 12.1484ZM6.94331 18.8666L6.56375 18.2196L6.55627 18.2241L6.94331 18.8666ZM5.92408 18.8433L5.50815 19.4674H5.50815L5.92408 18.8433ZM5.51031 17.9116L4.80505 17.6564C4.78802 17.7035 4.77575 17.7521 4.76841 17.8016L5.51031 17.9116ZM8.53458 11.7567C8.67549 11.3672 8.47397 10.9372 8.08446 10.7963C7.69495 10.6554 7.26496 10.8569 7.12405 11.2464L8.53458 11.7567ZM19.4963 12.2516C19.9105 12.2516 20.2463 11.9158 20.2463 11.5016C20.2463 11.0873 19.9105 10.7516 19.4963 10.7516V12.2516ZM7.82931 10.7516C7.4151 10.7516 7.07931 11.0873 7.07931 11.5016C7.07931 11.9158 7.4151 12.2516 7.82931 12.2516V10.7516ZM19.8758 10.8547L7.32284 3.48968L6.56378 4.78344L19.1168 12.1484L19.8758 10.8547ZM7.33035 3.49414C6.76609 3.15419 6.05633 3.17038 5.50816 3.5357L6.34 4.78391C6.40506 4.74055 6.4893 4.73863 6.55627 4.77898L7.33035 3.49414ZM5.50816 3.5357C4.95998 3.90102 4.67184 4.54987 4.76841 5.20151L6.25221 4.98161C6.24075 4.90427 6.27494 4.82727 6.34 4.78391L5.50816 3.5357ZM4.80505 5.34671L7.12405 11.7567L8.53458 11.2464L6.21558 4.83641L4.80505 5.34671ZM19.1168 10.8547L6.56378 18.2197L7.32284 19.5134L19.8758 12.1484L19.1168 10.8547ZM6.55627 18.2241C6.4893 18.2645 6.40506 18.2626 6.34 18.2192L5.50815 19.4674C6.05633 19.8327 6.76609 19.8489 7.33035 19.509L6.55627 18.2241ZM6.34 18.2192C6.27494 18.1759 6.24075 18.0988 6.25221 18.0215L4.76841 17.8016C4.67184 18.4532 4.95998 19.1021 5.50815 19.4674L6.34 18.2192ZM6.21558 18.1667L8.53458 11.7567L7.12405 11.2464L4.80505 17.6564L6.21558 18.1667ZM19.4963 10.7516H7.82931V12.2516H19.4963V10.7516Z" fill="currentColor"></path></g></svg>');
function xc(e) {
  var t = wc();
  w(e, t);
}
var kc = /* @__PURE__ */ Qt('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" class="feather feather-square"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect></svg>');
function Ec(e, t) {
  let n = Z(t, "fill", 8, "currentColor"), r = Z(t, "stroke_width", 8, 1.5);
  var a = kc();
  F(() => {
    M(a, "fill", n()), M(a, "stroke-width", `${r()}`);
  }), w(e, a);
}
function Tc(e, t) {
  Wt(t, !1);
  const n = Oa();
  let r = Z(t, "formatter", 8), a = Z(t, "value", 8), o = Z(t, "i18n", 8), s = Un(!1);
  cr();
  {
    let l = Dn(() => (xt(o()), ct(() => o()("common.share"))));
    ar(e, {
      get Icon() {
        return dc;
      },
      get label() {
        return i(l);
      },
      get pending() {
        return i(s);
      },
      onclick: async () => {
        try {
          _(s, !0);
          const u = await r()(a());
          n("share", { description: u });
        } catch (u) {
          console.error(u);
          let c = u instanceof Er ? u.message : "Share failed.";
          n("error", c);
        } finally {
          _(s, !1);
        }
      }
    });
  }
  Vt();
}
un(["click"]);
var Sc = /* @__PURE__ */ P('<span class="custom-button-label svelte-11nh9a6"> </span>'), Ac = /* @__PURE__ */ P('<button class="custom-button svelte-11nh9a6"><!></button>');
function Ic(e, t) {
  Wt(t, !1);
  let n = Z(t, "button", 8), r = Z(t, "on_click", 8);
  cr();
  var a = Ac(), o = k(a);
  {
    var s = (l) => {
      var u = Sc(), c = k(u);
      F(() => Y(c, (xt(n()), ct(() => n().value)))), w(l, u);
    };
    W(o, (l) => {
      xt(n()), ct(() => n().value) && l(s);
    });
  }
  F(() => {
    M(a, "title", (xt(n()), ct(() => n().value || ""))), M(a, "aria-label", (xt(n()), ct(() => n().value || "Custom action")));
  }), Oe("click", a, () => r()(n().id)), w(e, a), Vt();
}
var Oc = /* @__PURE__ */ P("<div><!> <!></div>");
function yo(e, t) {
  Wt(t, !0);
  let n = Z(t, "top_panel", 3, !0), r = Z(t, "display_top_corner", 3, !1), a = Z(t, "show_background", 3, !0), o = Z(t, "buttons", 3, null), s = Z(t, "on_custom_button_click", 3, null);
  var l = Oc(), u = k(l);
  {
    var c = (f) => {
      var p = Et(), C = be(p);
      Wi(C, () => t.children), w(f, p);
    };
    W(u, (f) => {
      t.children && f(c);
    });
  }
  var v = I(u, 2);
  {
    var T = (f) => {
      var p = Et(), C = be(p);
      _t(C, 17, o, Lt, (S, h) => {
        var g = Et(), O = be(g);
        {
          var m = (L) => {
            Ic(L, {
              get button() {
                return i(h);
              },
              on_click: (A) => {
                s() && s()(A);
              }
            });
          };
          W(O, (L) => {
            typeof i(h) != "string" && L(m);
          });
        }
        w(S, g);
      }), w(f, p);
    };
    W(v, (f) => {
      o() && f(T);
    });
  }
  F(() => We(l, 1, `icon-button-wrapper ${n() ? "top-panel" : ""} ${r() ? "display-top-corner" : "hide-top-corner"} ${a() ? "" : "no-background"}`, "svelte-gm9ixz")), w(e, l), Vt();
}
function Cc(e, t) {
  Wt(t, !0);
  var n = Et(), r = be(n);
  {
    var a = (s) => {
      ar(s, {
        get Icon() {
          return yc;
        },
        label: "Exit fullscreen mode",
        onclick: () => t.onclick(!1)
      });
    }, o = (s) => {
      ar(s, {
        get Icon() {
          return _c;
        },
        label: "Fullscreen",
        onclick: () => t.onclick(!0)
      });
    };
    W(r, (s) => {
      t.fullscreen ? s(a) : s(o, -1);
    });
  }
  w(e, n), Vt();
}
var Lc = /* @__PURE__ */ P('<div class="validation-error svelte-b061ct"> </div>'), Pc = /* @__PURE__ */ P(" <!>", 1), Hc = /* @__PURE__ */ P('<input data-testid="textbox" type="text"/>'), Nc = /* @__PURE__ */ P('<input data-testid="password" type="password" autocomplete=""/>'), Rc = /* @__PURE__ */ P('<input data-testid="textbox" type="email" autocomplete="email"/>'), Bc = /* @__PURE__ */ P('<textarea data-testid="textbox"></textarea>'), Mc = /* @__PURE__ */ P('<button data-testid="submit-button"><!></button>'), Dc = /* @__PURE__ */ P('<button data-testid="stop-button"><!></button>'), Uc = /* @__PURE__ */ P('<label><!> <!> <div class="input-container svelte-b061ct"><!> <!> <!></div></label>');
function jc(e, t) {
  Wt(t, !0);
  var n = this && this.__awaiter || function(ie, V, we, xe) {
    function Ke(D) {
      return D instanceof we ? D : new we(function(B) {
        B(D);
      });
    }
    return new (we || (we = Promise))(function(D, B) {
      function y(U) {
        try {
          E(xe.next(U));
        } catch (X) {
          B(X);
        }
      }
      function x(U) {
        try {
          E(xe.throw(U));
        } catch (X) {
          B(X);
        }
      }
      function E(U) {
        U.done ? D(U.value) : Ke(U.value).then(y, x);
      }
      E((xe = xe.apply(ie, V || [])).next());
    });
  };
  let r = Z(t, "value", 15, ""), a = Z(t, "value_is_output", 15, !1), o = Z(t, "lines", 3, 1), s = Z(t, "placeholder", 3, ""), l = Z(t, "info", 3, void 0), u = Z(t, "disabled", 3, !1), c = Z(t, "show_label", 3, !0), v = Z(t, "container", 3, !0), T = Z(t, "max_lines", 3, void 0), f = Z(t, "type", 3, "text"), p = Z(t, "buttons", 3, null), C = Z(t, "oncustombuttonclick", 3, null), S = Z(t, "submit_btn", 3, null), h = Z(t, "stop_btn", 3, null), g = Z(t, "rtl", 3, !1), O = Z(t, "autofocus", 3, !1), m = Z(t, "text_align", 3, void 0), L = Z(t, "autoscroll", 3, !0), A = Z(t, "max_length", 3, void 0), N = Z(t, "html_attributes", 3, null), q = Z(t, "validation_error", 3, void 0), K, j = ne(!1), de, re = ne(!1), ce = ne(0), _e = ne(!1), Pe = ne(1);
  const qe = !S();
  Jt(() => {
    T() === void 0 || T() === null ? f() === "text" ? _(Pe, Math.max(o(), 20), !0) : _(Pe, 1) : _(Pe, Math.max(T(), o()), !0);
  }), Jt(() => {
    r(), q(), K && o() !== i(Pe) && i(Pe) > 1 && Qe({ target: K });
  }), Jt(() => {
    r() === null && r("");
  }), Di(() => {
    !i(_e) && K && K.offsetHeight + K.scrollTop > K.scrollHeight - 100 && _(re, !0);
  });
  const Me = () => {
    i(re) && L() && !i(_e) && K.scrollTo(0, K.scrollHeight);
  };
  function Tt() {
    return n(this, void 0, void 0, function* () {
      yield Rn(), t.onchange === null || t.onchange === void 0 || t.onchange(r());
    });
  }
  Jt(() => {
    O() && K && K.focus(), i(re) && L() && Me(), a(!1);
  }), Jt(() => {
    r(), Tt();
  });
  function rt() {
    return n(this, void 0, void 0, function* () {
      if ("clipboard" in navigator) {
        try {
          yield navigator.clipboard.writeText(r()), t.oncopy === null || t.oncopy === void 0 || t.oncopy({ value: r() });
        } catch (ie) {
          console.error("COPYING CLIPBOARD FAILED", ie);
        }
        bt();
      }
    });
  }
  function bt() {
    _(j, !0), de && clearTimeout(de), de = setTimeout(
      () => {
        _(j, !1);
      },
      1e3
    );
  }
  function Rt(ie) {
    const V = ie.target, we = V.value, xe = [V.selectionStart, V.selectionEnd];
    t.onselect === null || t.onselect === void 0 || t.onselect({ value: we.substring(...xe), index: xe });
  }
  function yt(ie) {
    return n(this, void 0, void 0, function* () {
      ie.key === "Enter" && ie.shiftKey && o() > 1 ? (ie.preventDefault(), yield Rn(), t.onsubmit === null || t.onsubmit === void 0 || t.onsubmit()) : ie.key === "Enter" && !ie.shiftKey && o() === 1 && i(Pe) >= 1 && (ie.preventDefault(), yield Rn(), t.onsubmit === null || t.onsubmit === void 0 || t.onsubmit()), yield Rn(), t.oninput === null || t.oninput === void 0 || t.oninput(r());
    });
  }
  function Xe(ie) {
    const V = ie.target, we = V.scrollTop;
    we < i(ce) && _(_e, !0), _(ce, we, !0);
    const xe = V.scrollHeight - V.clientHeight;
    we >= xe && _(_e, !1);
  }
  function ye() {
    t.onstop === null || t.onstop === void 0 || t.onstop();
  }
  function Fe() {
    t.onsubmit === null || t.onsubmit === void 0 || t.onsubmit();
  }
  function Qe(ie) {
    return n(this, void 0, void 0, function* () {
      if (yield Rn(), o() === i(Pe)) return;
      const V = ie.target, we = window.getComputedStyle(V), xe = parseFloat(we.paddingTop), Ke = parseFloat(we.paddingBottom), D = parseFloat(we.lineHeight);
      let B = i(Pe) === void 0 ? !1 : xe + Ke + D * i(Pe), y = xe + Ke + o() * D;
      V.style.height = "1px";
      let x;
      B && V.scrollHeight > B ? x = B : V.scrollHeight < y ? x = y : x = V.scrollHeight, V.style.height = `${x}px`, Ge(V);
    });
  }
  function Ge(ie) {
    const V = ie.scrollHeight, we = ie.clientHeight, xe = parseFloat(window.getComputedStyle(ie).lineHeight);
    V > we + xe ? ie.style.overflowY = "scroll" : ie.style.overflowY = "hidden";
  }
  function Ae(ie, V) {
    if (!(o() === i(Pe) || o() === 1 && i(Pe) === 1))
      return ie.addEventListener("input", Qe), V.trim() && (ie.style.overflowY = "scroll", Qe({ target: ie })), { destroy: () => ie.removeEventListener("input", Qe) };
  }
  var lt = Uc();
  let He;
  var Bt = k(lt);
  {
    var Yt = (ie) => {
      yo(ie, {
        get buttons() {
          return p();
        },
        get on_custom_button_click() {
          return C();
        },
        children: (V, we) => {
          var xe = Et(), Ke = be(xe);
          {
            var D = (y) => {
              {
                let x = pe(() => i(j) ? uc : hc), E = pe(() => i(j) ? "Copied" : "Copy");
                ar(y, {
                  get Icon() {
                    return i(x);
                  },
                  onclick: rt,
                  get label() {
                    return i(E);
                  }
                });
              }
            }, B = pe(() => p().some((y) => typeof y == "string" && y === "copy"));
            W(Ke, (y) => {
              i(B) && y(D);
            });
          }
          w(V, xe);
        },
        $$slots: { default: !0 }
      });
    };
    W(Bt, (ie) => {
      c() && p() && p().length > 0 && ie(Yt);
    });
  }
  var qt = I(Bt, 2);
  {
    let ie = pe(() => q() ? !0 : c());
    $u(qt, {
      get show_label() {
        return i(ie);
      },
      get info() {
        return l();
      },
      children: (V, we) => {
        var xe = Pc(), Ke = be(xe), D = I(Ke);
        {
          var B = (y) => {
            var x = Lc(), E = k(x);
            F(() => Y(E, q())), w(y, x);
          };
          W(D, (y) => {
            q() && y(B);
          });
        }
        F(() => Y(Ke, `${t.label ?? ""} `)), w(V, xe);
      },
      $$slots: { default: !0 }
    });
  }
  var $t = I(qt, 2), cn = k($t);
  {
    var dn = (ie) => {
      var V = Et(), we = be(V);
      {
        var xe = (B) => {
          var y = Hc();
          let x;
          $n(y, O()), ln(y, (E) => K = E, () => K), F(() => {
            x = We(y, 1, "scroll-hide svelte-b061ct", null, x, { "validation-error": q() }), M(y, "dir", g() ? "rtl" : "ltr"), M(y, "placeholder", s()), y.disabled = u(), M(y, "maxlength", A()), kt(y, m() ? "text-align: " + m() : ""), M(y, "autocapitalize", N()?.autocapitalize), M(y, "autocorrect", N()?.autocorrect), M(y, "spellcheck", N()?.spellcheck), M(y, "autocomplete", N()?.autocomplete), M(y, "tabindex", N()?.tabindex), M(y, "enterkeyhint", N()?.enterkeyhint), M(y, "lang", N()?.lang), y.dir = y.dir;
          }), Oe("keypress", y, yt), Oe("blur", y, () => t.onblur?.()), Oe("select", y, Rt), Oe("focus", y, () => t.onfocus?.()), tr(y, r), w(B, y);
        }, Ke = (B) => {
          var y = Nc();
          let x;
          $n(y, O()), ln(y, (E) => K = E, () => K), F(() => {
            x = We(y, 1, "scroll-hide svelte-b061ct", null, x, { "validation-error": q() }), M(y, "placeholder", s()), y.disabled = u(), M(y, "maxlength", A()), M(y, "autocapitalize", N()?.autocapitalize), M(y, "autocorrect", N()?.autocorrect), M(y, "spellcheck", N()?.spellcheck), M(y, "tabindex", N()?.tabindex), M(y, "enterkeyhint", N()?.enterkeyhint), M(y, "lang", N()?.lang);
          }), Oe("keypress", y, yt), Oe("blur", y, () => t.onblur?.()), Oe("select", y, Rt), Oe("focus", y, () => t.onfocus?.()), tr(y, r), w(B, y);
        }, D = (B) => {
          var y = Rc();
          let x;
          $n(y, O()), ln(y, (E) => K = E, () => K), F(() => {
            x = We(y, 1, "scroll-hide svelte-b061ct", null, x, { "validation-error": q() }), M(y, "placeholder", s()), y.disabled = u(), M(y, "maxlength", A()), M(y, "autocapitalize", N()?.autocapitalize), M(y, "autocorrect", N()?.autocorrect), M(y, "spellcheck", N()?.spellcheck), M(y, "tabindex", N()?.tabindex), M(y, "enterkeyhint", N()?.enterkeyhint), M(y, "lang", N()?.lang);
          }), Oe("keypress", y, yt), Oe("blur", y, () => t.onblur?.()), Oe("select", y, Rt), Oe("focus", y, () => t.onfocus?.()), tr(y, r), w(B, y);
        };
        W(we, (B) => {
          f() === "text" ? B(xe) : f() === "password" ? B(Ke, 1) : f() === "email" && B(D, 2);
        });
      }
      w(ie, V);
    }, pn = (ie) => {
      var V = Bc();
      $n(V, O());
      let we;
      Ds(V, (xe, Ke) => Ae?.(xe, Ke), r), lr(() => tr(V, r)), ln(V, (xe) => K = xe, () => K), F(() => {
        M(V, "dir", g() ? "rtl" : "ltr"), M(V, "placeholder", s()), M(V, "rows", o()), V.disabled = u(), M(V, "maxlength", A()), kt(V, m() ? "text-align: " + m() : ""), M(V, "autocapitalize", N()?.autocapitalize), M(V, "autocorrect", N()?.autocorrect), M(V, "spellcheck", N()?.spellcheck), M(V, "autocomplete", N()?.autocomplete), M(V, "tabindex", N()?.tabindex), M(V, "enterkeyhint", N()?.enterkeyhint), M(V, "lang", N()?.lang), we = We(V, 1, "svelte-b061ct", null, we, {
          "no-label": !c() && (S() || h()),
          "validation-error": q()
        }), V.dir = V.dir;
      }), Oe("keypress", V, yt), Oe("blur", V, () => t.onblur?.()), Oe("select", V, Rt), Oe("focus", V, () => t.onfocus?.()), Oe("scroll", V, Xe), w(ie, V);
    };
    W(cn, (ie) => {
      o() === 1 && i(Pe) === 1 ? ie(dn) : ie(pn, -1);
    });
  }
  var en = I(cn, 2);
  {
    var fn = (ie) => {
      var V = Mc();
      let we;
      var xe = k(V);
      {
        var Ke = (B) => {
          xc(B);
        }, D = (B) => {
          var y = Ar();
          F(() => Y(y, S())), w(B, y);
        };
        W(xe, (B) => {
          S() === !0 ? B(Ke) : B(D, -1);
        });
      }
      F(() => we = We(V, 1, "submit-button svelte-b061ct", null, we, { "padded-button": S() !== !0 })), z("click", V, Fe), w(ie, V);
    };
    W(en, (ie) => {
      S() && ie(fn);
    });
  }
  var gn = I(en, 2);
  {
    var nn = (ie) => {
      var V = Dc();
      let we;
      var xe = k(V);
      {
        var Ke = (B) => {
          Ec(B, { fill: "none", stroke_width: 2.5 });
        }, D = (B) => {
          var y = Ar();
          F(() => Y(y, h())), w(B, y);
        };
        W(xe, (B) => {
          h() === !0 ? B(Ke) : B(D, -1);
        });
      }
      F(() => we = We(V, 1, "stop-button svelte-b061ct", null, we, { "padded-button": h() !== !0 })), z("click", V, ye), w(ie, V);
    };
    W(gn, (ie) => {
      h() && ie(nn);
    });
  }
  F(() => He = We(lt, 1, "svelte-b061ct", null, He, { container: v(), show_textbox_border: qe })), w(e, lt), Vt();
}
un(["click"]);
const Fc = (e) => {
  const t = {};
  for (let n = 0, r = e.length; n < r; n++) {
    const a = e[n];
    for (const o in a)
      t[o] ? t[o] = t[o].concat(a[o]) : t[o] = a[o];
  }
  return t;
}, Gc = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], zc = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], Wc = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
Fc([
  Object.fromEntries(Gc.map((e) => [e, ["*"]])),
  Object.fromEntries(zc.map((e) => [e, ["svg:*"]])),
  Object.fromEntries(Wc.map((e) => [e, ["math:*"]]))
]);
un(["touchstart", "touchmove", "touchend", "click", "keydown"]);
const Vc = (e) => {
  let t;
  if (e.currentTarget instanceof Element)
    t = e.currentTarget.querySelector("img");
  else
    return [NaN, NaN];
  const n = t.getBoundingClientRect(), r = t.naturalWidth / n.width, a = t.naturalHeight / n.height;
  if (r > a) {
    const l = t.naturalHeight / r, u = (n.height - l) / 2;
    var o = Math.round((e.clientX - n.left) * r), s = Math.round((e.clientY - n.top - u) * r);
  } else {
    const l = t.naturalWidth / a, u = (n.width - l) / 2;
    var o = Math.round((e.clientX - n.left - u) * a), s = Math.round((e.clientY - n.top) * a);
  }
  return o < 0 || o >= t.naturalWidth || s < 0 || s >= t.naturalHeight ? null : [o, s];
};
var qc = /* @__PURE__ */ P("<img/>");
function Xc(e, t) {
  Wt(t, !0);
  var n = qc();
  Zi(
    n,
    (r) => ({
      src: t.src,
      class: r,
      "data-testid": t.data_testid,
      ...t.restProps
    }),
    [() => (t.class_names || []).join(" ")],
    void 0,
    void 0,
    "svelte-7p3emg"
  ), Oe("load", n, function(r) {
    wr.call(this, t, r);
  }), w(e, n), Vt();
}
var Zc = /* @__PURE__ */ P("<!> <!> <!>", 1), Jc = /* @__PURE__ */ P('<div class="image-container svelte-1wbnwxk"><!> <button class="svelte-1wbnwxk"><div><!></div></button></div>'), Yc = /* @__PURE__ */ P("<!> <!>", 1);
function Qc(e, t) {
  Wt(t, !1);
  let n = Z(t, "value", 8), r = Z(t, "label", 8, void 0), a = Z(t, "show_label", 8), o = Z(t, "buttons", 24, () => []), s = Z(t, "on_custom_button_click", 8, null), l = Z(t, "selectable", 8, !1), u = Z(t, "i18n", 8), c = Z(t, "display_icon_button_wrapper_top_corner", 8, !1), v = Z(t, "fullscreen", 12, !1), T = Z(t, "show_button_background", 8, !0);
  const f = Oa(), p = (L) => {
    let A = Vc(L);
    A && f("select", { index: A, value: null });
  };
  let C = Un();
  cr();
  var S = Yc(), h = be(S);
  {
    let L = Dn(() => (xt(a()), xt(r()), xt(u()), ct(() => a() ? r() || u()("image.image") : "")));
    tc(h, {
      get show_label() {
        return a();
      },
      get Icon() {
        return _i;
      },
      get label() {
        return i(L);
      }
    });
  }
  var g = I(h, 2);
  {
    var O = (L) => {
      sc(L, {
        unpadded_box: !0,
        size: "large",
        children: (A, N) => {
          _i(A);
        },
        $$slots: { default: !0 }
      });
    }, m = (L) => {
      var A = Jc(), N = k(A);
      yo(N, {
        get display_top_corner() {
          return c();
        },
        get show_background() {
          return T();
        },
        get buttons() {
          return o();
        },
        get on_custom_button_click() {
          return s();
        },
        children: (re, ce) => {
          var _e = Zc(), Pe = be(_e);
          {
            var qe = (ye) => {
              Cc(ye, {
                get fullscreen() {
                  return v();
                },
                onclick: (Fe) => {
                  v(Fe), f("fullscreen", Fe);
                }
              });
            }, Me = pe(() => (xt(o()), ct(() => o().some((ye) => typeof ye == "string" && ye === "fullscreen"))));
            W(Pe, (ye) => {
              i(Me) && ye(qe);
            });
          }
          var Tt = I(Pe, 2);
          {
            var rt = (ye) => {
              {
                let Fe = Dn(() => (xt(n()), ct(() => n().orig_name || "image")));
                rc(ye, {
                  get href() {
                    return xt(n()), ct(() => n().url);
                  },
                  get download() {
                    return i(Fe);
                  },
                  children: (Qe, Ge) => {
                    {
                      let Ae = Dn(() => (xt(u()), ct(() => u()("common.download"))));
                      ar(Qe, {
                        get Icon() {
                          return pc;
                        },
                        get label() {
                          return i(Ae);
                        }
                      });
                    }
                  },
                  $$slots: { default: !0 }
                });
              }
            }, bt = pe(() => (xt(o()), ct(() => o().some((ye) => typeof ye == "string" && ye === "download"))));
            W(Tt, (ye) => {
              i(bt) && ye(rt);
            });
          }
          var Rt = I(Tt, 2);
          {
            var yt = (ye) => {
              Tc(ye, {
                get i18n() {
                  return u();
                },
                formatter: async (Fe) => Fe ? `<img src="${await Pu(Fe)}" />` : "",
                get value() {
                  return n();
                },
                $$events: {
                  share(Fe) {
                    wr.call(this, t, Fe);
                  },
                  error(Fe) {
                    wr.call(this, t, Fe);
                  }
                }
              });
            }, Xe = pe(() => (xt(o()), ct(() => o().some((ye) => typeof ye == "string" && ye === "share"))));
            W(Rt, (ye) => {
              i(Xe) && ye(yt);
            });
          }
          w(re, _e);
        },
        $$slots: { default: !0 }
      });
      var q = I(N, 2), K = k(q);
      let j;
      var de = k(K);
      Xc(de, {
        get src() {
          return xt(n()), ct(() => n().url);
        },
        restProps: { loading: "lazy", alt: "" },
        $$events: {
          load(re) {
            wr.call(this, t, re);
          }
        }
      }), ln(A, (re) => _(C, re), () => i(C)), F(() => j = We(K, 1, "image-frame svelte-1wbnwxk", null, j, { selectable: l() })), Oe("click", q, p), w(L, A);
    };
    W(g, (L) => {
      xt(n()), ct(() => n() == null || !n()?.url) ? L(O) : L(m, -1);
    });
  }
  w(e, S), Vt();
}
typeof process < "u" && process.versions && process.versions.node;
class Th extends TransformStream {
  #e = "";
  /** Constructs a new instance. */
  constructor(t = { allowCR: !1 }) {
    super({
      transform: (n, r) => {
        for (n = this.#e + n; ; ) {
          const a = n.indexOf(`
`), o = t.allowCR ? n.indexOf("\r") : -1;
          if (o !== -1 && o !== n.length - 1 && (a === -1 || a - 1 > o)) {
            r.enqueue(n.slice(0, o)), n = n.slice(o + 1);
            continue;
          }
          if (a === -1)
            break;
          const s = n[a - 1] === "\r" ? a - 1 : a;
          r.enqueue(n.slice(0, s)), n = n.slice(a + 1);
        }
        this.#e = n;
      },
      flush: (n) => {
        if (this.#e === "")
          return;
        const r = t.allowCR && this.#e.endsWith("\r") ? this.#e.slice(0, -1) : this.#e;
        n.enqueue(r);
      }
    });
  }
}
un(["click"]);
var Kc = /* @__PURE__ */ P('<span class="node-status-spinner svelte-enf4d0"></span>'), $c = /* @__PURE__ */ P('<input class="node-label-input svelte-enf4d0"/>'), ed = /* @__PURE__ */ P('<span class="node-label svelte-enf4d0"> </span>'), td = /* @__PURE__ */ P('<a class="source-badge svelte-enf4d0" target="_blank" rel="noopener"> </a>'), nd = /* @__PURE__ */ P('<button class="port-auto-btn svelte-enf4d0">+</button>'), rd = /* @__PURE__ */ P('<input class="inline-input inline-number svelte-enf4d0" type="number" step="any"/>'), ad = /* @__PURE__ */ P('<label class="inline-checkbox svelte-enf4d0"><input type="checkbox" class="svelte-enf4d0"/> <span class="svelte-enf4d0"> </span></label>'), id = /* @__PURE__ */ P('<input class="inline-input svelte-enf4d0" type="text"/>'), od = /* @__PURE__ */ P('<div class="port-inline-config svelte-enf4d0"><!></div>'), sd = /* @__PURE__ */ P('<div class="port-row input-row svelte-enf4d0"><!> <span role="button" tabindex="-1"></span> <span> </span> <span class="port-type-tag svelte-enf4d0"> </span></div> <!>', 1), ld = /* @__PURE__ */ P('<button class="ports-toggle svelte-enf4d0"><!></button>'), ud = /* @__PURE__ */ P('<div class="ports svelte-enf4d0"><!> <!></div>'), cd = /* @__PURE__ */ P('<div class="widget-gradio-wrap svelte-enf4d0"><!></div>'), dd = /* @__PURE__ */ P('<div class="widget-text-display svelte-enf4d0"> </div>'), fd = /* @__PURE__ */ P('<input class="widget-number svelte-enf4d0" type="number" step="any"/>'), hd = /* @__PURE__ */ P('<label class="widget-checkbox-row svelte-enf4d0"><input class="widget-checkbox svelte-enf4d0" type="checkbox"/> <span class="widget-checkbox-label svelte-enf4d0"> </span></label>'), vd = /* @__PURE__ */ P('<div class="widget-gradio-wrap widget-gradio-image svelte-enf4d0"><!></div>'), pd = /* @__PURE__ */ P('<img class="widget-img svelte-enf4d0"/>'), gd = /* @__PURE__ */ P('<audio class="widget-audio svelte-enf4d0" controls=""></audio>'), md = /* @__PURE__ */ P('<video class="widget-video svelte-enf4d0" controls=""></video>', 2), _d = /* @__PURE__ */ P('<div class="widget-file-info svelte-enf4d0"><span class="widget-file-name svelte-enf4d0"> </span></div>'), bd = /* @__PURE__ */ P('<button class="widget-clear svelte-enf4d0">&times;</button>'), yd = /* @__PURE__ */ P('<div class="widget-preview svelte-enf4d0"><!> <!></div>'), wd = /* @__PURE__ */ P('<div class="widget-placeholder svelte-enf4d0">Waiting for output...</div>'), xd = /* @__PURE__ */ P('<label class="widget-file-drop svelte-enf4d0"><input type="file" class="svelte-enf4d0"/> <span class="widget-drop-text svelte-enf4d0"> </span></label>'), kd = /* @__PURE__ */ P('<div class="widget-zone svelte-enf4d0"><!></div>'), Ed = /* @__PURE__ */ P('<button class="port-auto-btn svelte-enf4d0">+</button>'), Td = /* @__PURE__ */ P('<div class="port-row output-row svelte-enf4d0"><span class="port-type-tag svelte-enf4d0"> </span> <span class="port-label svelte-enf4d0"> </span> <span class="port-dot output-dot svelte-enf4d0" role="button" tabindex="-1"></span> <!></div>'), Sd = /* @__PURE__ */ P('<div class="ports svelte-enf4d0"></div>'), Ad = /* @__PURE__ */ P('<div class="node-error-banner svelte-enf4d0"> </div>'), Id = /* @__PURE__ */ P('<div><div class="node-top-accent svelte-enf4d0"></div> <div class="node-header svelte-enf4d0" role="button" tabindex="-1"><div class="node-header-top svelte-enf4d0"><!> <span class="kind-tag svelte-enf4d0"> </span> <!> <button class="node-delete svelte-enf4d0" title="Delete node">&times;</button></div> <!></div> <!> <!> <!> <!></div>');
function Od(e, t) {
  Wt(t, !0), this && this.__awaiter;
  var n, r, a, o, s, l, u, c, v, T, f, p;
  let C, S = ne(!1), h, g = ne(!1);
  const O = 3;
  function m(x) {
    const E = x.trim();
    E && E !== t.node.label && Ot.update((U) => Object.assign(Object.assign({}, U), {
      nodes: U.nodes.map((X) => X.id === t.node.id ? Object.assign(Object.assign({}, X), { label: E }) : X)
    })), _(S, !1);
  }
  const L = (o = (r = (n = t.node.outputs[0]) === null || n === void 0 ? void 0 : n.type) !== null && r !== void 0 ? r : (a = t.node.inputs[0]) === null || a === void 0 ? void 0 : a.type) !== null && o !== void 0 ? o : "any", A = nt[L], N = Bu[L], q = t.node.kind === "component", K = q && t.node.inputs[0] ? t.connectedPorts.has(`${t.node.id}:${t.node.inputs[0].id}:input`) : !1, j = q ? K ? "output" : "input" : t.node.kind, de = j === "input" || j === "output", re = j === "input" ? (l = (s = t.node.outputs[0]) === null || s === void 0 ? void 0 : s.id) !== null && l !== void 0 ? l : null : j === "output" && (c = (u = t.node.inputs[0]) === null || u === void 0 ? void 0 : u.id) !== null && c !== void 0 ? c : null, ce = j === "input" ? (T = (v = t.node.outputs[0]) === null || v === void 0 ? void 0 : v.type) !== null && T !== void 0 ? T : null : j === "output" && (p = (f = t.node.inputs[0]) === null || f === void 0 ? void 0 : f.type) !== null && p !== void 0 ? p : null, _e = j === "output";
  function Pe() {
    var x;
    if (!re) return "";
    const E = (x = t.node.data) === null || x === void 0 ? void 0 : x[re];
    return typeof E == "string" ? E : "";
  }
  function qe() {
    var x;
    if (!re) return null;
    const E = (x = t.node.data) === null || x === void 0 ? void 0 : x[re];
    return E && typeof E == "object" ? E : null;
  }
  function Me() {
    var x;
    if (!re) return 0;
    const E = (x = t.node.data) === null || x === void 0 ? void 0 : x[re];
    return typeof E == "number" ? E : 0;
  }
  function Tt() {
    var x;
    if (!re) return !1;
    const E = (x = t.node.data) === null || x === void 0 ? void 0 : x[re];
    return typeof E == "boolean" ? E : !1;
  }
  function rt() {
    var x;
    if (!re) return "";
    const E = (x = t.node.data) === null || x === void 0 ? void 0 : x[re];
    return typeof E == "string" ? E : "";
  }
  function bt(x) {
    const E = x.currentTarget;
    re && t.ondatachange(t.node.id, re, parseFloat(E.value) || 0);
  }
  function Rt(x) {
    const E = x.currentTarget;
    re && t.ondatachange(t.node.id, re, E.checked);
  }
  function yt(x) {
    var E, U;
    const ue = (E = x.currentTarget.files) === null || E === void 0 ? void 0 : E[0];
    if (!ue || !re) return;
    const fe = qe();
    !((U = fe?.url) === null || U === void 0) && U.startsWith("blob:") && URL.revokeObjectURL(fe.url), t.ondatachange(t.node.id, re, {
      name: ue.name,
      url: URL.createObjectURL(ue),
      mime: ue.type
    });
  }
  function Xe(x) {
    var E, U, X;
    x.preventDefault(), x.stopPropagation();
    const ue = (U = (E = x.dataTransfer) === null || E === void 0 ? void 0 : E.files) === null || U === void 0 ? void 0 : U[0];
    if (!ue || !re) return;
    const fe = qe();
    !((X = fe?.url) === null || X === void 0) && X.startsWith("blob:") && URL.revokeObjectURL(fe.url), t.ondatachange(t.node.id, re, {
      name: ue.name,
      url: URL.createObjectURL(ue),
      mime: ue.type
    });
  }
  function ye() {
    var x;
    if (!re) return;
    const E = qe();
    !((x = E?.url) === null || x === void 0) && x.startsWith("blob:") && URL.revokeObjectURL(E.url), t.ondatachange(t.node.id, re, null);
  }
  const Fe = (x) => x;
  function Qe(x) {
    x.preventDefault();
    const E = x.clientX, U = x.clientY, X = t.node.x, ue = t.node.y;
    function fe(he) {
      const G = (he.clientX - E) / t.zoom, De = (he.clientY - U) / t.zoom;
      t.onmove(t.node.id, X + G, ue + De);
    }
    function Ve() {
      window.removeEventListener("mousemove", fe), window.removeEventListener("mouseup", Ve);
    }
    window.addEventListener("mousemove", fe), window.addEventListener("mouseup", Ve);
  }
  function Ge(x, E) {
    return x === "any" || E === "any" || x === E;
  }
  Jt(() => {
    if (!C) return;
    const x = new ResizeObserver(([E]) => {
      const U = Math.ceil(E.borderBoxSize[0].blockSize);
      Math.abs(U - t.node.height) > 1 && ju(t.node.id, t.node.width, U);
    });
    return x.observe(C), () => x.disconnect();
  });
  var Ae = Id();
  let lt;
  var He = I(k(Ae), 2), Bt = k(He), Yt = k(Bt);
  {
    var qt = (x) => {
      var E = Kc();
      w(x, E);
    };
    W(Yt, (x) => {
      t.status === "running" && x(qt);
    });
  }
  var $t = I(Yt, 2), cn = k($t), dn = I($t, 2);
  {
    var pn = (x) => {
      var E = $c();
      ln(E, (U) => h = U, () => h), F(() => vn(E, t.node.label)), Oe("blur", E, (U) => m(U.currentTarget.value)), z("keydown", E, (U) => {
        U.key === "Enter" && m(U.currentTarget.value), U.key === "Escape" && _(S, !1), U.stopPropagation();
      }), z("mousedown", E, (U) => U.stopPropagation()), w(x, E);
    }, en = (x) => {
      var E = ed(), U = k(E);
      F(() => Y(U, t.node.label)), z("dblclick", E, (X) => {
        X.stopPropagation(), _(S, !0), requestAnimationFrame(() => h?.select());
      }), w(x, E);
    };
    W(dn, (x) => {
      i(S) ? x(pn) : x(en, -1);
    });
  }
  var fn = I(dn, 2), gn = I(Bt, 2);
  {
    var nn = (x) => {
      var E = td(), U = k(E);
      F(() => {
        M(E, "href", `https://huggingface.co/spaces/${t.node.space_id ?? ""}`), M(E, "title", t.node.space_id), Y(U, t.node.space_id);
      }), z("mousedown", E, (X) => X.stopPropagation()), w(x, E);
    };
    W(gn, (x) => {
      t.node.source === "space" && t.node.space_id && x(nn);
    });
  }
  var ie = I(He, 2);
  {
    var V = (x) => {
      const E = pe(() => t.node.inputs.length > O), U = pe(() => t.node.inputs.length - O);
      var X = ud(), ue = k(X);
      _t(ue, 17, () => t.node.inputs, Lt, (he, G, De) => {
        const Ne = pe(() => t.connectedPorts.has(`${t.node.id}:${i(G).id}:input`)), Ce = pe(() => i(g) || De < O || i(Ne));
        var ke = Et(), me = be(ke);
        {
          var Ze = (dt) => {
            var Pt = sd(), Mt = be(Pt), ft = k(Mt);
            {
              var Dt = ($e) => {
                var it = nd();
                F(() => {
                  kt(it, `--port-color: ${nt[i(G).type] ?? ""}`), M(it, "title", `Add ${i(G).type ?? ""} input`);
                }), z("mousedown", it, (Ht) => Ht.stopPropagation()), z("click", it, () => t.onautoconnect(t.node.id, i(G).id, i(G).type, "input")), w($e, it);
              };
              W(ft, ($e) => {
                !i(Ne) && !t.pending && $e(Dt);
              });
            }
            var Ut = I(ft, 2);
            let rn;
            var Je = I(Ut, 2);
            let ve;
            var Ee = k(Je), mt = I(Je, 2), Ye = k(mt), at = I(Mt, 2);
            {
              var ht = ($e) => {
                var it = od(), Ht = k(it);
                {
                  var et = (Se) => {
                    var Re = rd();
                    F(
                      (ae) => {
                        M(Re, "placeholder", ae), vn(Re, t.node.data?.[i(G).id] ?? "");
                      },
                      [
                        () => i(G).default_value != null ? String(i(G).default_value) : "0"
                      ]
                    ), z("input", Re, (ae) => t.ondatachange(t.node.id, i(G).id, parseFloat(ae.currentTarget.value) || 0)), w(Se, Re);
                  }, Ue = (Se) => {
                    var Re = ad(), ae = k(Re), se = I(ae, 2), ot = k(se);
                    F(() => {
                      Za(ae, !!t.node.data?.[i(G).id]), Y(ot, t.node.data?.[i(G).id] ? "On" : "Off");
                    }), z("change", ae, (je) => t.ondatachange(t.node.id, i(G).id, je.currentTarget.checked)), w(Se, Re);
                  }, Te = (Se) => {
                    var Re = id();
                    F(
                      (ae) => {
                        M(Re, "placeholder", ae), vn(Re, typeof t.node.data?.[i(G).id] == "string" ? t.node.data[i(G).id] : "");
                      },
                      [
                        () => i(G).default_value != null ? String(i(G).default_value) : i(G).label
                      ]
                    ), z("input", Re, (ae) => t.ondatachange(t.node.id, i(G).id, ae.currentTarget.value)), w(Se, Re);
                  };
                  W(Ht, (Se) => {
                    i(G).type === "number" ? Se(et) : i(G).type === "boolean" ? Se(Ue, 1) : Se(Te, -1);
                  });
                }
                z("mousedown", it, (Se) => Se.stopPropagation()), w($e, it);
              };
              W(at, ($e) => {
                !i(Ne) && t.node.kind === "transform" && (i(G).type === "text" || i(G).type === "number" || i(G).type === "boolean" || i(G).type === "any" || i(G).type === "json") && $e(ht);
              });
            }
            F(
              ($e) => {
                rn = We(Ut, 1, "port-dot input-dot svelte-enf4d0", null, rn, $e), kt(Ut, `--port-color: ${nt[i(G).type] ?? ""}`), M(Ut, "data-port-id", `${t.node.id ?? ""}:${i(G).id ?? ""}:input`), ve = We(Je, 1, "port-label svelte-enf4d0", null, ve, { "port-label-optional": i(G).required === !1 }), Y(Ee, i(G).label), kt(mt, `color: ${nt[i(G).type] ?? ""}`), Y(Ye, i(G).type);
              },
              [
                () => ({
                  "port-optional": i(G).required === !1,
                  "port-filled": i(G).required !== !1,
                  incompatible: t.pending !== null && !Ge(t.pending.type, i(G).type),
                  pulse: t.pending !== null && Ge(t.pending.type, i(G).type)
                })
              ]
            ), z("mouseup", Ut, () => t.oncompleteconnection(t.node.id, i(G).id, i(G).type)), w(dt, Pt);
          };
          W(me, (dt) => {
            i(Ce) && dt(Ze);
          });
        }
        w(he, ke);
      });
      var fe = I(ue, 2);
      {
        var Ve = (he) => {
          var G = ld(), De = k(G);
          {
            var Ne = (ke) => {
              var me = Ar("▴ show less");
              w(ke, me);
            }, Ce = (ke) => {
              var me = Ar();
              F(() => Y(me, `▾ ${i(U) ?? ""} more params`)), w(ke, me);
            };
            W(De, (ke) => {
              i(g) ? ke(Ne) : ke(Ce, -1);
            });
          }
          z("mousedown", G, (ke) => ke.stopPropagation()), z("click", G, () => _(g, !i(g))), w(he, G);
        };
        W(fe, (he) => {
          i(E) && he(Ve);
        });
      }
      w(x, X);
    };
    W(ie, (x) => {
      t.node.inputs.length > 0 && x(V);
    });
  }
  var we = I(ie, 2);
  {
    var xe = (x) => {
      var E = kd(), U = k(E);
      {
        var X = (he) => {
          var G = cd(), De = k(G);
          {
            let Ne = pe(() => Pe() || rt()), Ce = pe(() => ce === "json" ? 4 : 3), ke = pe(() => _e ? "Waiting for output..." : ce === "json" ? '{"key": "value"}' : "Enter text...");
            jc(De, {
              get value() {
                return i(Ne);
              },
              label: "text",
              show_label: !1,
              get lines() {
                return i(Ce);
              },
              max_lines: 8,
              get placeholder() {
                return i(ke);
              },
              get disabled() {
                return _e;
              },
              oninput: (me) => {
                re && t.ondatachange(t.node.id, re, me);
              }
            });
          }
          w(he, G);
        }, ue = (he) => {
          var G = Et(), De = be(G);
          {
            var Ne = (ke) => {
              var me = dd(), Ze = k(me);
              F((dt) => Y(Ze, dt), [() => Me()]), w(ke, me);
            }, Ce = (ke) => {
              var me = fd();
              F((Ze) => vn(me, Ze), [() => Me()]), z("input", me, bt), w(ke, me);
            };
            W(De, (ke) => {
              _e ? ke(Ne) : ke(Ce, -1);
            });
          }
          w(he, G);
        }, fe = (he) => {
          var G = hd(), De = k(G), Ne = I(De, 2), Ce = k(Ne);
          F(
            (ke, me) => {
              Za(De, ke), De.disabled = _e, Y(Ce, me);
            },
            [
              () => Tt(),
              () => Tt() ? "On" : "Off"
            ]
          ), z("change", De, Rt), w(he, G);
        }, Ve = (he) => {
          const G = pe(qe);
          var De = Et(), Ne = be(De);
          {
            var Ce = (me) => {
              var Ze = yd(), dt = k(Ze);
              {
                var Pt = (ve) => {
                  var Ee = vd(), mt = k(Ee);
                  {
                    let Ye = pe(() => ({
                      url: i(G).url,
                      orig_name: i(G).name,
                      path: i(G).url,
                      mime_type: i(G).mime
                    }));
                    Qc(mt, {
                      get value() {
                        return i(Ye);
                      },
                      show_label: !1,
                      i18n: Fe,
                      buttons: []
                    });
                  }
                  w(ve, Ee);
                }, Mt = (ve) => {
                  var Ee = pd();
                  F(() => {
                    M(Ee, "src", i(G).url), M(Ee, "alt", i(G).name);
                  }), w(ve, Ee);
                }, ft = (ve) => {
                  var Ee = gd();
                  F(() => M(Ee, "src", i(G).url)), w(ve, Ee);
                }, Dt = (ve) => {
                  var Ee = md();
                  F(() => M(Ee, "src", i(G).url)), w(ve, Ee);
                }, Ut = (ve) => {
                  var Ee = _d(), mt = k(Ee), Ye = k(mt);
                  F(() => Y(Ye, i(G).name)), w(ve, Ee);
                };
                W(dt, (ve) => {
                  (ce === "image" || ce === "gallery") && _e ? ve(Pt) : ce === "image" || ce === "gallery" ? ve(Mt, 1) : ce === "audio" ? ve(ft, 2) : ce === "video" ? ve(Dt, 3) : ve(Ut, -1);
                });
              }
              var rn = I(dt, 2);
              {
                var Je = (ve) => {
                  var Ee = bd();
                  z("click", Ee, ye), w(ve, Ee);
                };
                W(rn, (ve) => {
                  _e || ve(Je);
                });
              }
              w(me, Ze);
            }, ke = (me) => {
              var Ze = Et(), dt = be(Ze);
              {
                var Pt = (ft) => {
                  var Dt = wd();
                  w(ft, Dt);
                }, Mt = (ft) => {
                  var Dt = xd(), Ut = k(Dt), rn = I(Ut, 2), Je = k(rn);
                  F(() => {
                    M(Ut, "accept", ce === "image" ? "image/*" : ce === "audio" ? "audio/*" : ce === "video" ? "video/*" : ce === "model3d" ? ".glb,.gltf,.obj,.stl" : "*"), Y(Je, `Drop ${ce ?? ""} or click`);
                  }), Oe("dragover", Dt, (ve) => {
                    ve.preventDefault(), ve.stopPropagation();
                  }), Oe("drop", Dt, Xe), z("change", Ut, yt), w(ft, Dt);
                };
                W(dt, (ft) => {
                  _e ? ft(Pt) : ft(Mt, -1);
                });
              }
              w(me, Ze);
            };
            W(Ne, (me) => {
              i(G) ? me(Ce) : me(ke, -1);
            });
          }
          w(he, De);
        };
        W(U, (he) => {
          ce === "text" || ce === "json" ? he(X) : ce === "number" ? he(ue, 1) : ce === "boolean" ? he(fe, 2) : (ce === "image" || ce === "audio" || ce === "video" || ce === "file" || ce === "gallery" || ce === "model3d") && he(Ve, 3);
        });
      }
      z("mousedown", E, (he) => he.stopPropagation()), w(x, E);
    };
    W(we, (x) => {
      de && re && ce && x(xe);
    });
  }
  var Ke = I(we, 2);
  {
    var D = (x) => {
      var E = Sd();
      _t(E, 21, () => t.node.outputs, Lt, (U, X) => {
        const ue = pe(() => t.connectedPorts.has(`${t.node.id}:${i(X).id}:output`));
        var fe = Td(), Ve = k(fe), he = k(Ve), G = I(Ve, 2), De = k(G), Ne = I(G, 2), Ce = I(Ne, 2);
        {
          var ke = (me) => {
            var Ze = Ed();
            F(() => {
              kt(Ze, `--port-color: ${nt[i(X).type] ?? ""}`), M(Ze, "title", `Add ${i(X).type ?? ""} output`);
            }), z("mousedown", Ze, (dt) => dt.stopPropagation()), z("click", Ze, () => t.onautoconnect(t.node.id, i(X).id, i(X).type, "output")), w(me, Ze);
          };
          W(Ce, (me) => {
            !i(ue) && !t.pending && me(ke);
          });
        }
        F(() => {
          kt(Ve, `color: ${nt[i(X).type] ?? ""}`), Y(he, i(X).type), Y(De, i(X).label), kt(Ne, `--port-color: ${nt[i(X).type] ?? ""}`), M(Ne, "data-port-id", `${t.node.id ?? ""}:${i(X).id ?? ""}:output`);
        }), z("mousedown", Ne, (me) => t.onstartconnection(t.node.id, i(X).id, i(X).type, me)), w(U, fe);
      }), w(x, E);
    };
    W(Ke, (x) => {
      t.node.outputs.length > 0 && x(D);
    });
  }
  var B = I(Ke, 2);
  {
    var y = (x) => {
      var E = Ad(), U = k(E);
      F(() => Y(U, t.error)), w(x, E);
    };
    W(B, (x) => {
      t.status === "error" && t.error && x(y);
    });
  }
  ln(Ae, (x) => C = x, () => C), F(() => {
    lt = We(Ae, 1, "wf-node svelte-enf4d0", null, lt, {
      "node-running": t.status === "running",
      "node-done": t.status === "done",
      "node-error": t.status === "error",
      "node-selected": t.selected
    }), kt(Ae, `
		left: ${t.node.x ?? ""}px;
		top: ${t.node.y ?? ""}px;
		width: ${t.node.width ?? ""}px;
		--accent: ${A ?? ""};
		--accent-dim: ${N ?? ""};
	`), Y(cn, hi[j] ?? hi[t.node.kind] ?? "?");
  }), z("click", Ae, () => t.onselect(t.node.id)), z("mousedown", He, Qe), z("mousedown", fn, (x) => x.stopPropagation()), z("click", fn, () => t.onremove(t.node.id)), w(e, Ae), Vt();
}
un([
  "click",
  "mousedown",
  "keydown",
  "dblclick",
  "mouseup",
  "input",
  "change"
]);
var Cd = /* @__PURE__ */ Qt('<linearGradient x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stop-opacity="0.9"></stop><stop offset="100%" stop-opacity="0.4"></stop></linearGradient>'), Ld = /* @__PURE__ */ Qt('<path fill="none" stroke-opacity="0.08" style="pointer-events: none"></path><path class="wire-hitbox svelte-m0h81u" fill="none" stroke="transparent" role="button" tabindex="-1"></path><path class="wire" fill="none" style="pointer-events: none"></path><path class="wire-flow svelte-m0h81u" fill="none" stroke-opacity="0.5" style="pointer-events: none"></path><rect style="pointer-events: none"></rect>', 1), Pd = /* @__PURE__ */ Qt('<path fill="none" stroke-opacity="0.6" style="pointer-events: none"></path><circle fill="none" stroke-opacity="0.5" style="pointer-events: none"></circle>', 1), Hd = /* @__PURE__ */ Qt('<svg class="edge-layer svelte-m0h81u"><defs></defs><!><!></svg>');
function Nd(e, t) {
  Wt(t, !0);
  const n = () => Fi(Ot, "$workflow", r), [r, a] = Gi();
  function o(f, p, C, S) {
    const h = Math.max(Math.abs(C - f) * 0.5, 60);
    return `M ${f} ${p} C ${f + h} ${p}, ${C - h} ${S}, ${C} ${S}`;
  }
  function s(f, p, C, S) {
    const h = document.querySelector(`[data-port-id="${p}:${C}:${S}"]`), g = document.querySelector(".canvas-transform");
    if (h && g) {
      const K = h.getBoundingClientRect(), j = g.getBoundingClientRect();
      return {
        x: (K.left + K.width / 2 - j.left) / t.zoom,
        y: (K.top + K.height / 2 - j.top) / t.zoom
      };
    }
    const O = f.find((K) => K.id === p);
    if (!O) return { x: 0, y: 0 };
    const m = S === "output" ? O.outputs : O.inputs, L = m.findIndex((K) => K.id === C), A = L >= 0 ? L : 0, N = S === "output" ? O.x + O.width : O.x, q = O.source === "space" && O.space_id ? 60 : 44;
    if (S === "input")
      return { x: N, y: O.y + q + A * 26 };
    {
      const K = m.length * 26;
      return {
        x: N,
        y: O.y + O.height - K + A * 26 - 2
      };
    }
  }
  var l = Hd(), u = k(l);
  _t(u, 5, () => n().edges, (f) => f.id, (f, p) => {
    var C = Cd(), S = k(C), h = I(S);
    F(() => {
      M(C, "id", `grad-${i(p).id ?? ""}`), M(S, "stop-color", nt[i(p).type]), M(h, "stop-color", nt[i(p).type]);
    }), w(f, C);
  });
  var c = I(u);
  _t(c, 1, () => n().edges, (f) => f.id, (f, p) => {
    const C = pe(() => s(n().nodes, i(p).from_node_id, i(p).from_port_id, "output")), S = pe(() => s(n().nodes, i(p).to_node_id, i(p).to_port_id, "input")), h = pe(() => 3.5 / t.zoom);
    var g = Ld(), O = be(g), m = I(O), L = I(m), A = I(L), N = I(A);
    F(
      (q, K, j, de) => {
        M(O, "d", q), M(O, "stroke", nt[i(p).type]), M(O, "stroke-width", 6 / t.zoom), M(m, "d", K), M(m, "stroke-width", 16 / t.zoom), M(L, "d", j), M(L, "stroke", `url(#grad-${i(p).id ?? ""})`), M(L, "stroke-width", 2 / t.zoom), M(A, "d", de), M(A, "stroke", nt[i(p).type]), M(A, "stroke-width", 2 / t.zoom), M(A, "stroke-dasharray", `${4 / t.zoom} ${12 / t.zoom}`), M(N, "x", i(S).x - i(h)), M(N, "y", i(S).y - i(h)), M(N, "width", i(h) * 2), M(N, "height", i(h) * 2), M(N, "rx", 1 / t.zoom), M(N, "fill", nt[i(p).type]), M(N, "transform", `rotate(45 ${i(S).x ?? ""} ${i(S).y ?? ""})`);
      },
      [
        () => o(i(C).x, i(C).y, i(S).x, i(S).y),
        () => o(i(C).x, i(C).y, i(S).x, i(S).y),
        () => o(i(C).x, i(C).y, i(S).x, i(S).y),
        () => o(i(C).x, i(C).y, i(S).x, i(S).y)
      ]
    ), z("click", m, () => t.onremove(i(p).id)), w(f, g);
  });
  var v = I(c);
  {
    var T = (f) => {
      const p = pe(() => s(n().nodes, t.pending.from_node_id, t.pending.from_port_id, "output"));
      var C = Pd(), S = be(C), h = I(S);
      F(
        (g) => {
          M(S, "d", g), M(S, "stroke", nt[t.pending.type] ?? "#5c5e6a"), M(S, "stroke-width", 2 / t.zoom), M(S, "stroke-dasharray", `${6 / t.zoom} ${4 / t.zoom}`), M(h, "cx", t.pending.x), M(h, "cy", t.pending.y), M(h, "r", 4 / t.zoom), M(h, "stroke", nt[t.pending.type] ?? "#5c5e6a"), M(h, "stroke-width", 1.5 / t.zoom);
        },
        [
          () => o(i(p).x, i(p).y, t.pending.x, t.pending.y)
        ]
      ), w(f, C);
    };
    W(v, (f) => {
      t.pending && f(T);
    });
  }
  w(e, l), Vt(), a();
}
un(["click"]);
const $r = {
  // Text → Text
  "text-generation": {
    inputs: [{ id: "in_0", label: "Prompt", type: "text" }],
    outputs: [{ id: "out_0", label: "Text", type: "text" }]
  },
  "text2text-generation": {
    inputs: [{ id: "in_0", label: "Text", type: "text" }],
    outputs: [{ id: "out_0", label: "Text", type: "text" }]
  },
  summarization: {
    inputs: [{ id: "in_0", label: "Text", type: "text" }],
    outputs: [{ id: "out_0", label: "Summary", type: "text" }]
  },
  translation: {
    inputs: [{ id: "in_0", label: "Text", type: "text" }],
    outputs: [{ id: "out_0", label: "Translation", type: "text" }]
  },
  "fill-mask": {
    inputs: [{ id: "in_0", label: "Text", type: "text" }],
    outputs: [{ id: "out_0", label: "Result", type: "json" }]
  },
  conversational: {
    inputs: [{ id: "in_0", label: "Message", type: "text" }],
    outputs: [{ id: "out_0", label: "Reply", type: "text" }]
  },
  // Text → Classification
  "text-classification": {
    inputs: [{ id: "in_0", label: "Text", type: "text" }],
    outputs: [{ id: "out_0", label: "Labels", type: "json" }]
  },
  "token-classification": {
    inputs: [{ id: "in_0", label: "Text", type: "text" }],
    outputs: [{ id: "out_0", label: "Entities", type: "json" }]
  },
  "zero-shot-classification": {
    inputs: [
      { id: "in_0", label: "Text", type: "text" },
      { id: "in_1", label: "Labels", type: "text" }
    ],
    outputs: [{ id: "out_0", label: "Scores", type: "json" }]
  },
  "sentence-similarity": {
    inputs: [
      { id: "in_0", label: "Source", type: "text" },
      { id: "in_1", label: "Sentences", type: "text" }
    ],
    outputs: [{ id: "out_0", label: "Scores", type: "json" }]
  },
  "question-answering": {
    inputs: [
      { id: "in_0", label: "Question", type: "text" },
      { id: "in_1", label: "Context", type: "text" }
    ],
    outputs: [{ id: "out_0", label: "Answer", type: "text" }]
  },
  "feature-extraction": {
    inputs: [{ id: "in_0", label: "Text", type: "text" }],
    outputs: [{ id: "out_0", label: "Embeddings", type: "json" }]
  },
  // Text → Image
  "text-to-image": {
    inputs: [{ id: "in_0", label: "Prompt", type: "text" }],
    outputs: [{ id: "out_0", label: "Image", type: "image" }]
  },
  // Text → Audio
  "text-to-speech": {
    inputs: [{ id: "in_0", label: "Text", type: "text" }],
    outputs: [{ id: "out_0", label: "Audio", type: "audio" }]
  },
  "text-to-audio": {
    inputs: [{ id: "in_0", label: "Prompt", type: "text" }],
    outputs: [{ id: "out_0", label: "Audio", type: "audio" }]
  },
  // Text → Video
  "text-to-video": {
    inputs: [{ id: "in_0", label: "Prompt", type: "text" }],
    outputs: [{ id: "out_0", label: "Video", type: "video" }]
  },
  // Image → *
  "image-classification": {
    inputs: [{ id: "in_0", label: "Image", type: "image" }],
    outputs: [{ id: "out_0", label: "Labels", type: "json" }]
  },
  "object-detection": {
    inputs: [{ id: "in_0", label: "Image", type: "image" }],
    outputs: [{ id: "out_0", label: "Detections", type: "json" }]
  },
  "image-segmentation": {
    inputs: [{ id: "in_0", label: "Image", type: "image" }],
    outputs: [{ id: "out_0", label: "Segments", type: "json" }]
  },
  "image-to-text": {
    inputs: [{ id: "in_0", label: "Image", type: "image" }],
    outputs: [{ id: "out_0", label: "Text", type: "text" }]
  },
  "image-to-image": {
    inputs: [
      { id: "in_0", label: "Image", type: "image" },
      { id: "in_1", label: "Prompt", type: "text" }
    ],
    outputs: [{ id: "out_0", label: "Image", type: "image" }]
  },
  "image-to-video": {
    inputs: [{ id: "in_0", label: "Image", type: "image" }],
    outputs: [{ id: "out_0", label: "Video", type: "video" }]
  },
  "depth-estimation": {
    inputs: [{ id: "in_0", label: "Image", type: "image" }],
    outputs: [{ id: "out_0", label: "Depth", type: "image" }]
  },
  "image-text-to-text": {
    inputs: [
      { id: "in_0", label: "Image", type: "image" },
      { id: "in_1", label: "Prompt", type: "text" }
    ],
    outputs: [{ id: "out_0", label: "Text", type: "text" }]
  },
  // Audio → *
  "automatic-speech-recognition": {
    inputs: [{ id: "in_0", label: "Audio", type: "audio" }],
    outputs: [{ id: "out_0", label: "Text", type: "text" }]
  },
  "audio-classification": {
    inputs: [{ id: "in_0", label: "Audio", type: "audio" }],
    outputs: [{ id: "out_0", label: "Labels", type: "json" }]
  },
  "audio-to-audio": {
    inputs: [{ id: "in_0", label: "Audio", type: "audio" }],
    outputs: [{ id: "out_0", label: "Audio", type: "audio" }]
  },
  // Multimodal
  "visual-question-answering": {
    inputs: [
      { id: "in_0", label: "Image", type: "image" },
      { id: "in_1", label: "Question", type: "text" }
    ],
    outputs: [{ id: "out_0", label: "Answer", type: "text" }]
  },
  "document-question-answering": {
    inputs: [
      { id: "in_0", label: "Document", type: "image" },
      { id: "in_1", label: "Question", type: "text" }
    ],
    outputs: [{ id: "out_0", label: "Answer", type: "text" }]
  }
}, Cr = {
  components: [
    {
      label: "Image",
      kind: "component",
      source: "local",
      inputs: [{ id: "in", label: "Image", type: "image" }],
      outputs: [{ id: "out", label: "Image", type: "image" }],
      width: 220,
      height: 160
    },
    {
      label: "Textbox",
      kind: "component",
      source: "local",
      inputs: [{ id: "in", label: "Text", type: "text" }],
      outputs: [{ id: "out", label: "Text", type: "text" }],
      width: 220,
      height: 160
    },
    {
      label: "Audio",
      kind: "component",
      source: "local",
      inputs: [{ id: "in", label: "Audio", type: "audio" }],
      outputs: [{ id: "out", label: "Audio", type: "audio" }],
      width: 220,
      height: 160
    },
    {
      label: "Video",
      kind: "component",
      source: "local",
      inputs: [{ id: "in", label: "Video", type: "video" }],
      outputs: [{ id: "out", label: "Video", type: "video" }],
      width: 220,
      height: 160
    },
    {
      label: "Number",
      kind: "component",
      source: "local",
      inputs: [{ id: "in", label: "Number", type: "number" }],
      outputs: [{ id: "out", label: "Number", type: "number" }],
      width: 220,
      height: 130
    },
    {
      label: "File",
      kind: "component",
      source: "local",
      inputs: [{ id: "in", label: "File", type: "file" }],
      outputs: [{ id: "out", label: "File", type: "file" }],
      width: 220,
      height: 160
    },
    {
      label: "JSON",
      kind: "component",
      source: "local",
      inputs: [{ id: "in", label: "JSON", type: "json" }],
      outputs: [{ id: "out", label: "JSON", type: "json" }],
      width: 220,
      height: 160
    },
    {
      label: "Gallery",
      kind: "component",
      source: "local",
      inputs: [{ id: "in", label: "Gallery", type: "gallery" }],
      outputs: [{ id: "out", label: "Gallery", type: "gallery" }],
      width: 220,
      height: 160
    },
    {
      label: "Model3D",
      kind: "component",
      source: "local",
      inputs: [{ id: "in", label: "Model", type: "model3d" }],
      outputs: [{ id: "out", label: "Model", type: "model3d" }],
      width: 220,
      height: 160
    }
  ],
  spaces: []
}, wo = [
  { key: "image", label: "Image" },
  { key: "audio", label: "Audio" },
  { key: "text", label: "Text" },
  { key: "video", label: "Video" },
  { key: "multimodal", label: "Multimodal" },
  { key: "3d", label: "3D" },
  { key: "chat", label: "Chat" },
  { key: "code", label: "Code" }
], br = {
  // Image
  "text-to-image": "image",
  "image-to-image": "image",
  "image-classification": "image",
  "image-segmentation": "image",
  "object-detection": "image",
  "unconditional-image-generation": "image",
  "image-feature-extraction": "image",
  "depth-estimation": "image",
  "image-to-text": "image",
  // Audio
  "text-to-speech": "audio",
  "automatic-speech-recognition": "audio",
  "audio-to-audio": "audio",
  "audio-classification": "audio",
  "voice-activity-detection": "audio",
  // Text
  "text-generation": "text",
  "text2text-generation": "text",
  translation: "text",
  summarization: "text",
  "text-classification": "text",
  "question-answering": "text",
  "fill-mask": "text",
  "token-classification": "text",
  "sentence-similarity": "text",
  "feature-extraction": "text",
  "zero-shot-classification": "text",
  "table-question-answering": "text",
  // Video
  "text-to-video": "video",
  "image-to-video": "video",
  "video-classification": "video",
  // 3D
  "text-to-3d": "3d",
  "image-to-3d": "3d",
  // Multimodal
  "visual-question-answering": "multimodal",
  "image-text-to-text": "multimodal",
  "document-question-answering": "multimodal",
  "zero-shot-image-classification": "multimodal",
  "video-text-to-text": "multimodal",
  // Chat
  conversational: "chat"
}, Rd = [
  // Video — check before image since "image to video" should be video
  [/\b(video|animate|animation|motion|film|movie)\b/i, "video"],
  // 3D
  [/\b(3d|mesh|point.?cloud|nerf|gaussian.?splat|triposr)\b/i, "3d"],
  // Audio
  [/\b(audio|voice|speech|tts|whisper|music|sound|sing|talk)\b/i, "audio"],
  // Chat
  [/\b(chat|conversation|assistant|llm|gpt|gemma|llama|mistral|qwen(?!.*(?:image|edit|video)))\b/i, "chat"],
  // Multimodal
  [/\b(multimodal|vision.?language|vqa|document.?q|ocr)\b/i, "multimodal"],
  // Code
  [/\b(code|program|compiler|debug|ide)\b/i, "code"],
  // Image — broad, check last
  [/\b(image|photo|picture|paint|draw|sketch|pixel|diffus|flux|stable|edit.*image|image.*edit|face|swap|background|segm|detect|caption|upscal|super.?res|inpaint|outpaint|style.?transfer|lora|controlnet)\b/i, "image"]
];
function xo(e, t, n, r) {
  if (e && br[e])
    return br[e];
  if (t) {
    for (const o of t)
      if (br[o]) return br[o];
  }
  const a = [n ?? "", r ?? ""].join(" ");
  if (a.trim()) {
    for (const [o, s] of Rd)
      if (o.test(a)) return s;
  }
  return null;
}
function bi(e, t) {
  const n = e.toLowerCase();
  if (n === "image" || n === "imageeditor" || n === "imageslider") return "image";
  if (n === "gallery") return "gallery";
  if (n === "audio") return "audio";
  if (n === "video") return "video";
  if (n === "number" || n === "slider") return "number";
  if (n === "checkbox") return "boolean";
  if (n === "file" || n === "uploadbutton" || n === "downloadbutton") return "file";
  if (n === "model3d") return "model3d";
  if (n === "json" || n === "dataframe") return "json";
  if (n === "state") return "__skip__";
  if (n === "textbox" || n === "text" || n === "markdown" || n === "chatbot" || n === "label" || n === "code" || n === "highlightedtext" || n === "dropdown" || n === "radio" || n === "checkboxgroup" || n === "colorpicker" || n === "html") return "text";
  if (t) {
    const r = typeof t == "string" ? t.toLowerCase() : "";
    if (r.includes("image") || r.includes("pil")) return "image";
    if (r.includes("video") || r.includes("mp4")) return "video";
    if (r.includes("audio") || r.includes("wav") || r.includes("mp3")) return "audio";
    if (r.includes("filepath") || r.includes("file")) return "file";
    if (r === "number" || r === "float" || r === "int" || r === "integer") return "number";
    if (r === "bool" || r === "boolean") return "boolean";
    if (r === "str" || r === "string") return "text";
  }
  return "any";
}
const Bd = ["/predict", "/infer", "/generate", "/run", "/process", "/translate"], ko = ["/on_", "/handle_", "/update_", "/prepare_", "/load_", "/clear_", "/reset_"], Md = /* @__PURE__ */ new Set(["video", "image", "imageeditor", "imageslider", "audio", "file", "uploadbutton", "gallery", "model3d"]);
function yi(e) {
  return (e.returns ?? []).reduce((t, n) => {
    const r = (n.component ?? "").toLowerCase();
    return t + (Md.has(r) ? 10 : 1);
  }, 0);
}
function Dd(e) {
  const t = Object.keys(e), n = t.filter((a) => !ko.some((o) => a.startsWith(o))), r = n.length > 0 ? n : t;
  for (const a of Bd)
    if (r.includes(a)) return a;
  return r.slice().sort((a, o) => yi(e[o]) - yi(e[a]))[0];
}
const wi = /* @__PURE__ */ new Map();
async function ma(e) {
  const t = wi.get(e);
  if (t) return t;
  const n = e.startsWith("http") ? e : `https://${e.replace("/", "-").replaceAll(".", "-").toLowerCase()}.hf.space`;
  let r = null;
  for (const h of ["/gradio_api/info", "/info", "/api/info"])
    try {
      const g = await Promise.race([
        fetch(`${n}${h}`),
        new Promise(
          (O, m) => setTimeout(() => m(new Error("Timed out")), 1e4)
        )
      ]);
      if (g.ok) {
        r = g;
        break;
      }
    } catch {
    }
  if (!r) throw new Error("Could not connect to Space — it may be sleeping or have no Gradio API");
  const a = await r.json(), o = a.named_endpoints ?? {}, s = a.unnamed_endpoints ?? {};
  if (Object.keys(o).length === 0 && Object.keys(s).length === 0)
    throw new Error("No API endpoints found");
  let l, u;
  const c = Object.keys(o).length > 0 ? Dd(o) : null;
  if (c && !ko.some((h) => c.startsWith(h)))
    l = c, u = o[l];
  else if (s[0])
    l = "0", u = s[0];
  else if (o["/predict"])
    l = "/predict", u = o["/predict"];
  else if (c)
    l = c, u = o[l];
  else
    throw new Error("No suitable endpoint found");
  const v = (u.parameters ?? []).map((h, g) => {
    const O = bi(h.component ?? "", typeof h.type == "string" ? h.type : "");
    if (O === "__skip__") return null;
    const m = h.parameter_has_default === !0;
    return {
      id: `in_${g}`,
      label: h.label || h.parameter_name || `Input ${g}`,
      type: O,
      required: !m,
      default_value: m && h.default !== void 0 ? h.default : void 0
    };
  }).filter(Boolean), T = (u.returns ?? []).map((h, g) => {
    const O = bi(h.component ?? "", typeof h.type == "string" ? h.type : "");
    return O === "__skip__" ? null : {
      id: `out_${g}`,
      label: h.label || `Output ${g}`,
      type: O
    };
  }).filter(Boolean);
  v.length === 0 && v.push({ id: "in", label: "Input", type: "any" }), T.length === 0 && T.push({ id: "out", label: "Output", type: "any" });
  const f = e.split("/").pop() ?? e, p = Math.max(
    ...v.map((h) => h.label.length),
    ...T.map((h) => h.label.length),
    f.length
  ), C = Math.max(280, Math.min(400, p * 9 + 100)), S = { endpoint: l, inputs: v, outputs: T, width: C };
  return wi.set(e, S), S;
}
var Ud = /* @__PURE__ */ P('<div class="trending-status svelte-5hsmvk"><span class="space-loading-spinner svelte-5hsmvk"></span> <span class="trending-status-text svelte-5hsmvk">Loading trending spaces...</span></div>'), jd = /* @__PURE__ */ P('<div class="space-card-desc svelte-5hsmvk"> </div>'), Fd = /* @__PURE__ */ P('<div draggable="true" class="space-card svelte-5hsmvk"><div class="space-card-header svelte-5hsmvk"><span></span> <span class="space-card-name svelte-5hsmvk"> </span> <span class="space-card-likes svelte-5hsmvk"> </span> <a class="space-card-link svelte-5hsmvk" target="_blank" rel="noopener" title="Open on HuggingFace">&#x2197;</a></div> <div class="space-card-id svelte-5hsmvk"> </div> <!></div>'), Gd = /* @__PURE__ */ P('<div class="category-header svelte-5hsmvk"><span class="category-label svelte-5hsmvk"> </span> <span class="category-count svelte-5hsmvk"> </span></div> <!>', 1), zd = /* @__PURE__ */ P("<!> <!>", 1), Wd = /* @__PURE__ */ P("<button> </button>"), Vd = /* @__PURE__ */ P('<div class="space-loading svelte-5hsmvk"><span class="space-loading-spinner svelte-5hsmvk"></span> <span class="space-loading-text svelte-5hsmvk">Searching...</span></div>'), qd = /* @__PURE__ */ P('<div draggable="true" class="space-card svelte-5hsmvk"><div class="space-card-header svelte-5hsmvk"><span class="chip-dot svelte-5hsmvk"></span> <span class="space-card-name svelte-5hsmvk"> </span> <span class="space-card-likes svelte-5hsmvk"> </span></div> <div class="space-card-id svelte-5hsmvk"> </div> <div class="space-card-desc svelte-5hsmvk"> </div></div>'), Xd = /* @__PURE__ */ P('<div class="trending-status svelte-5hsmvk"><span class="trending-status-text svelte-5hsmvk">No models found</span></div>'), Zd = /* @__PURE__ */ P("<!> <!>", 1), Jd = /* @__PURE__ */ P('<div class="trending-status svelte-5hsmvk"><span class="space-loading-spinner svelte-5hsmvk"></span> <span class="trending-status-text svelte-5hsmvk">Loading trending models...</span></div>'), Yd = /* @__PURE__ */ P('<div draggable="true" class="space-card svelte-5hsmvk"><div class="space-card-header svelte-5hsmvk"><span class="chip-dot svelte-5hsmvk"></span> <span class="space-card-name svelte-5hsmvk"> </span> <span class="space-card-likes svelte-5hsmvk"> </span></div> <div class="space-card-id svelte-5hsmvk"> </div></div>'), Qd = /* @__PURE__ */ P('<div class="category-header svelte-5hsmvk"><span class="category-label svelte-5hsmvk"> </span> <span class="category-count svelte-5hsmvk"> </span></div> <!>', 1), Kd = /* @__PURE__ */ P('<div class="add-space-wrapper svelte-5hsmvk"><div class="add-space svelte-5hsmvk"><input class="space-input svelte-5hsmvk" type="text" placeholder="Search models..."/></div></div> <div class="model-task-filters svelte-5hsmvk"></div> <!>', 1), $d = /* @__PURE__ */ P('<div class="search-result-desc svelte-5hsmvk"> </div>'), ef = /* @__PURE__ */ P('<button class="search-result svelte-5hsmvk"><div class="search-result-top svelte-5hsmvk"><span class="search-result-name svelte-5hsmvk"> </span> <span class="search-result-likes svelte-5hsmvk"> </span></div> <!></button>'), tf = /* @__PURE__ */ P('<div class="search-dropdown svelte-5hsmvk"></div>'), nf = /* @__PURE__ */ P('<div class="search-dropdown svelte-5hsmvk"><div class="search-searching svelte-5hsmvk">Searching...</div></div>'), rf = /* @__PURE__ */ P('<div class="space-loading svelte-5hsmvk"><span class="space-loading-spinner svelte-5hsmvk"></span> <span class="space-loading-text svelte-5hsmvk"> </span></div>'), af = /* @__PURE__ */ P('<span class="space-error svelte-5hsmvk"> </span>'), of = /* @__PURE__ */ P('<div class="add-space-wrapper svelte-5hsmvk"><div class="add-space svelte-5hsmvk"><input class="space-input svelte-5hsmvk" type="text" placeholder="Search datasets..."/></div> <!></div> <!> <!> <div class="trending-status svelte-5hsmvk"><span class="trending-status-text svelte-5hsmvk">Search for a dataset by name</span></div>', 1), sf = /* @__PURE__ */ P('<div draggable="true" class="chip svelte-5hsmvk"><span class="chip-dot svelte-5hsmvk"></span> <span class="chip-label svelte-5hsmvk"> </span></div>'), lf = /* @__PURE__ */ P('<a class="chip-link svelte-5hsmvk" target="_blank" rel="noopener" title="Open on HuggingFace">&#x2197;</a>'), uf = /* @__PURE__ */ P('<div draggable="true" class="chip svelte-5hsmvk"><span class="chip-dot svelte-5hsmvk"></span> <span class="chip-label svelte-5hsmvk"> </span> <!> <button class="chip-remove svelte-5hsmvk" title="Remove">&times;</button></div>'), cf = /* @__PURE__ */ P('<div class="search-result-desc svelte-5hsmvk"> </div>'), df = /* @__PURE__ */ P('<button class="search-result svelte-5hsmvk"><div class="search-result-top svelte-5hsmvk"><span></span> <span class="search-result-name svelte-5hsmvk"> </span> <span class="search-result-likes svelte-5hsmvk"> </span> <a class="search-result-link svelte-5hsmvk" target="_blank" rel="noopener" title="Open on HuggingFace">&#x2197;</a></div> <!></button>'), ff = /* @__PURE__ */ P('<div class="search-dropdown svelte-5hsmvk"></div>'), hf = /* @__PURE__ */ P('<div class="search-dropdown svelte-5hsmvk"><div class="search-searching svelte-5hsmvk">Searching...</div></div>'), vf = /* @__PURE__ */ P('<div class="space-loading svelte-5hsmvk"><span class="space-loading-spinner svelte-5hsmvk"></span> <span class="space-loading-text svelte-5hsmvk"> </span></div>'), pf = /* @__PURE__ */ P('<span class="space-error svelte-5hsmvk"> </span>'), gf = /* @__PURE__ */ P('<!> <div class="add-space-wrapper svelte-5hsmvk"><div class="add-space svelte-5hsmvk"><input class="space-input svelte-5hsmvk" type="text" placeholder="Search Spaces..."/> <button class="space-add-btn svelte-5hsmvk"> </button></div> <!></div> <!> <!>', 1), mf = /* @__PURE__ */ P('<div class="section-items svelte-5hsmvk"><!> <!></div>'), _f = /* @__PURE__ */ P('<button><span class="section-label svelte-5hsmvk"> </span> <span class="section-count svelte-5hsmvk"> </span> <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg></button> <!>', 1), bf = /* @__PURE__ */ P('<!> <div class="sidebar-footer svelte-5hsmvk"><span class="hint svelte-5hsmvk">Drag to canvas</span></div>', 1), yf = /* @__PURE__ */ P('<div class="resize-handle svelte-5hsmvk"></div>'), wf = /* @__PURE__ */ P('<aside><div class="sidebar-header svelte-5hsmvk"><button><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg></button></div> <!> <!></aside>');
function xf(e, t) {
  Wt(t, !0);
  var n = this && this.__awaiter || function(D, B, y, x) {
    function E(U) {
      return U instanceof y ? U : new y(function(X) {
        X(U);
      });
    }
    return new (y || (y = Promise))(function(U, X) {
      function ue(he) {
        try {
          Ve(x.next(he));
        } catch (G) {
          X(G);
        }
      }
      function fe(he) {
        try {
          Ve(x.throw(he));
        } catch (G) {
          X(G);
        }
      }
      function Ve(he) {
        he.done ? U(he.value) : E(he.value).then(ue, fe);
      }
      Ve((x = x.apply(D, B || [])).next());
    });
  }, r;
  let a = Z(t, "onadd", 3, void 0), o = ne("spaces"), s = ne(!1), l = ne(240), u = ne(!1), c = ne(zt(typeof localStorage < "u" ? JSON.parse((r = localStorage.getItem("gradio_custom_spaces")) !== null && r !== void 0 ? r : "[]") : []));
  Jt(() => {
    typeof localStorage < "u" && localStorage.setItem("gradio_custom_spaces", JSON.stringify(i(c)));
  });
  function v(D) {
    D.preventDefault(), _(u, !0);
    const B = D.clientX, y = i(l);
    function x(U) {
      _(l, Math.max(160, Math.min(400, y + (U.clientX - B))), !0);
    }
    function E() {
      _(u, !1), window.removeEventListener("mousemove", x), window.removeEventListener("mouseup", E);
    }
    window.addEventListener("mousemove", x), window.addEventListener("mouseup", E);
  }
  let T = ne(""), f = ne(!1), p = ne(""), C = ne("");
  function S(D) {
    const B = D.target;
    i(A).length > 0 && !B.closest(".add-space-wrapper") && _(A, [], !0);
  }
  let h = ne(zt([])), g = ne(!0);
  function O() {
    return n(this, void 0, void 0, function* () {
      try {
        const D = yield fetch("https://huggingface.co/api/spaces?filter=gradio&limit=48&sort=trendingScore&direction=-1&expand[]=likes&expand[]=cardData&expand[]=runtime");
        if (!D.ok) throw new Error("Failed");
        const B = yield D.json();
        _(
          h,
          B.map((y) => {
            var x, E, U, X, ue, fe;
            const Ve = ((x = y.cardData) === null || x === void 0 ? void 0 : x.short_description) || "";
            return {
              id: y.id,
              title: ((E = y.cardData) === null || E === void 0 ? void 0 : E.title) || y.id.split("/").pop() || y.id,
              description: Ve,
              likes: (U = y.likes) !== null && U !== void 0 ? U : 0,
              running: ((X = y.runtime) === null || X === void 0 ? void 0 : X.stage) === "RUNNING",
              category: xo((ue = y.cardData) === null || ue === void 0 ? void 0 : ue.pipeline_tag, (fe = y.cardData) === null || fe === void 0 ? void 0 : fe.tags, Ve, y.id)
            };
          }).filter((y) => y.category !== null && y.running),
          !0
        );
      } catch {
        _(h, [], !0);
      } finally {
        _(g, !1);
      }
    });
  }
  typeof window < "u" && O();
  function m(D) {
    var B;
    return {
      label: D.id.split("/").pop() || D.id,
      kind: "transform",
      source: "space",
      space_id: D.id,
      category: (B = D.category) !== null && B !== void 0 ? B : void 0,
      inputs: [],
      outputs: [],
      width: 280,
      height: 90
    };
  }
  function L(D) {
    return i(h).filter((B) => B.category === D);
  }
  let A = ne(zt([])), N = ne(!1), q = null;
  function K(D) {
    const B = D.currentTarget.value;
    if (_(T, B, !0), _(C, ""), q && clearTimeout(q), B.length < 2) {
      _(A, [], !0), _(N, !1);
      return;
    }
    if (B.includes("/") && !B.endsWith("/")) {
      _(A, [], !0);
      return;
    }
    _(N, !0), q = setTimeout(
      () => n(this, void 0, void 0, function* () {
        try {
          const y = yield fetch(`https://huggingface.co/api/spaces/semantic-search?q=${encodeURIComponent(B)}&limit=8`);
          if (!y.ok) {
            _(A, [], !0);
            return;
          }
          const x = yield y.json();
          _(
            A,
            x.filter((E) => E.sdk === "gradio").slice(0, 6).map((E) => {
              var U, X;
              return {
                id: E.id,
                likes: (U = E.likes) !== null && U !== void 0 ? U : 0,
                title: E.title || E.id.split("/").pop(),
                description: E.ai_short_description || "",
                running: ((X = E.runtime) === null || X === void 0 ? void 0 : X.stage) === "RUNNING"
              };
            }),
            !0
          );
        } catch {
          _(A, [], !0);
        } finally {
          _(N, !1);
        }
      }),
      300
    );
  }
  function j(D) {
    _(T, D, !0), _(A, [], !0), ce();
  }
  function de(D) {
    var B, y, x, E;
    return (E = (y = (B = D.outputs[0]) === null || B === void 0 ? void 0 : B.type) !== null && y !== void 0 ? y : (x = D.inputs[0]) === null || x === void 0 ? void 0 : x.type) !== null && E !== void 0 ? E : "any";
  }
  function re(D) {
    _(o, i(o) === D ? null : D, !0);
  }
  function ce() {
    return n(this, void 0, void 0, function* () {
      var D;
      const B = i(T).trim();
      if (!(!B || !B.includes("/"))) {
        if (i(c).some((y) => y.space_id === B)) {
          _(T, "");
          return;
        }
        _(f, !0), _(p, B, !0), _(C, ""), _(T, "");
        try {
          const y = yield ma(B), x = (D = B.split("/").pop()) !== null && D !== void 0 ? D : B;
          _(
            c,
            [
              ...i(c),
              {
                label: x,
                kind: "transform",
                source: "space",
                space_id: B,
                endpoint: y.endpoint,
                inputs: y.inputs,
                outputs: y.outputs,
                width: y.width,
                height: 90
              }
            ],
            !0
          ), _(T, "");
        } catch (y) {
          _(C, y instanceof Error ? y.message : "Failed to connect", !0);
        } finally {
          _(f, !1);
        }
      }
    });
  }
  const _e = [
    { key: "text-to-image", label: "Text → Image" },
    { key: "text-generation", label: "Text Generation" },
    { key: "image-to-text", label: "Image → Text" },
    { key: "image-classification", label: "Image Classification" },
    { key: "object-detection", label: "Object Detection" },
    { key: "automatic-speech-recognition", label: "Speech → Text" },
    { key: "text-to-speech", label: "Text → Speech" },
    { key: "translation", label: "Translation" },
    { key: "summarization", label: "Summarization" },
    { key: "text-classification", label: "Text Classification" },
    { key: "image-to-image", label: "Image → Image" },
    { key: "depth-estimation", label: "Depth Estimation" },
    { key: "image-segmentation", label: "Image Segmentation" },
    { key: "text-to-video", label: "Text → Video" },
    { key: "image-text-to-text", label: "Image+Text → Text" },
    { key: "feature-extraction", label: "Embeddings" }
  ];
  let Pe = ne(""), qe = ne(zt([])), Me = ne(!1), Tt = null, rt = ne(""), bt = ne(zt([])), Rt = ne(!0);
  function yt() {
    return n(this, void 0, void 0, function* () {
      try {
        const D = yield fetch("https://huggingface.co/api/models?sort=trendingScore&direction=-1&limit=30&expand[]=likes&expand[]=downloads&expand[]=pipeline_tag");
        if (!D.ok) throw new Error("Failed");
        const B = yield D.json();
        _(
          bt,
          B.filter((y) => y.pipeline_tag && $r[y.pipeline_tag]).map((y) => {
            var x, E;
            return {
              id: y.id,
              pipeline_tag: y.pipeline_tag,
              likes: (x = y.likes) !== null && x !== void 0 ? x : 0,
              downloads: (E = y.downloads) !== null && E !== void 0 ? E : 0
            };
          }),
          !0
        );
      } catch {
        _(bt, [], !0);
      } finally {
        _(Rt, !1);
      }
    });
  }
  typeof window < "u" && yt();
  function Xe(D) {
    const B = D.currentTarget.value;
    if (_(Pe, B, !0), Tt && clearTimeout(Tt), B.length < 2 && !i(rt)) {
      _(qe, [], !0), _(Me, !1);
      return;
    }
    _(Me, !0), Tt = setTimeout(
      () => n(this, void 0, void 0, function* () {
        try {
          let y = "https://huggingface.co/api/models?sort=likes&direction=-1&limit=12&expand[]=likes&expand[]=downloads&expand[]=pipeline_tag";
          B.length >= 2 && (y += `&search=${encodeURIComponent(B)}`), i(rt) && (y += `&pipeline_tag=${i(rt)}`);
          const x = yield fetch(y);
          if (!x.ok) {
            _(qe, [], !0);
            return;
          }
          const E = yield x.json();
          _(
            qe,
            E.filter((U) => U.pipeline_tag && $r[U.pipeline_tag]).map((U) => {
              var X, ue;
              return {
                id: U.id,
                pipeline_tag: U.pipeline_tag,
                likes: (X = U.likes) !== null && X !== void 0 ? X : 0,
                downloads: (ue = U.downloads) !== null && ue !== void 0 ? ue : 0
              };
            }),
            !0
          );
        } catch {
          _(qe, [], !0);
        } finally {
          _(Me, !1);
        }
      }),
      300
    );
  }
  function ye(D) {
    _(rt, i(rt) === D ? "" : D, !0), Xe({ currentTarget: { value: i(Pe) } });
  }
  function Fe(D) {
    var B, y;
    const x = $r[D.pipeline_tag];
    return {
      label: D.id.split("/").pop() || D.id,
      kind: "transform",
      source: "model",
      model_id: D.id,
      pipeline_tag: D.pipeline_tag,
      inputs: (B = x?.inputs) !== null && B !== void 0 ? B : [],
      outputs: (y = x?.outputs) !== null && y !== void 0 ? y : [],
      width: 280,
      height: 90
    };
  }
  function Qe(D) {
    return i(bt).filter((B) => B.pipeline_tag === D);
  }
  let Ge = ne(""), Ae = ne(zt([])), lt = ne(!1), He = null, Bt = ne(!1), Yt = ne(""), qt = ne(""), $t = ne(0);
  function cn(D) {
    const B = D.currentTarget.value;
    if (_(Ge, B, !0), _(qt, ""), He && clearTimeout(He), B.length < 2) {
      _(Ae, [], !0), _(lt, !1);
      return;
    }
    _(lt, !0), He = setTimeout(
      () => n(this, void 0, void 0, function* () {
        try {
          const y = yield fetch(`https://huggingface.co/api/datasets?search=${encodeURIComponent(B)}&sort=likes&direction=-1&limit=8`);
          if (!y.ok) {
            _(Ae, [], !0);
            return;
          }
          const x = yield y.json();
          _(
            Ae,
            x.map((E) => {
              var U, X, ue, fe;
              return {
                id: E.id,
                likes: (U = E.likes) !== null && U !== void 0 ? U : 0,
                downloads: (X = E.downloads) !== null && X !== void 0 ? X : 0,
                description: ((fe = (ue = E.cardData) === null || ue === void 0 ? void 0 : ue.description) === null || fe === void 0 ? void 0 : fe.slice(0, 80)) || ""
              };
            }),
            !0
          );
        } catch {
          _(Ae, [], !0);
        } finally {
          _(lt, !1);
        }
      }),
      300
    );
  }
  function dn(D) {
    return n(this, void 0, void 0, function* () {
      var B, y, x;
      _(Bt, !0), _(Yt, D, !0), _(qt, "");
      try {
        const E = yield fetch(`https://datasets-server.huggingface.co/splits?dataset=${encodeURIComponent(D)}`);
        if (!E.ok) throw new Error("Could not load dataset — it may not be viewer-compatible");
        const X = (B = (yield E.json()).splits) !== null && B !== void 0 ? B : [];
        if (X.length === 0) throw new Error("No available splits found for this dataset");
        const ue = (y = X.find((Ce) => Ce.split === "train")) !== null && y !== void 0 ? y : X[0], fe = yield fetch(`https://datasets-server.huggingface.co/first-rows?dataset=${encodeURIComponent(D)}&config=${encodeURIComponent(ue.config)}&split=${encodeURIComponent(ue.split)}`);
        if (!fe.ok) throw new Error("Could not load dataset — it may not be viewer-compatible");
        const he = (x = (yield fe.json()).features) !== null && x !== void 0 ? x : [], G = (Ce) => {
          var ke, me, Ze, dt, Pt, Mt;
          const ft = ((ke = Ce.type) === null || ke === void 0 ? void 0 : ke.dtype) || ((me = Ce.type) === null || me === void 0 ? void 0 : me._type) || "";
          return ft === "string" || ((Ze = Ce.type) === null || Ze === void 0 ? void 0 : Ze._type) === "Value" && ((dt = Ce.type) === null || dt === void 0 ? void 0 : dt.dtype) === "string" ? "text" : ft === "float32" || ft === "float64" || ft === "int32" || ft === "int64" ? "number" : ((Pt = Ce.type) === null || Pt === void 0 ? void 0 : Pt._type) === "Image" ? "image" : ((Mt = Ce.type) === null || Mt === void 0 ? void 0 : Mt._type) === "Audio" ? "audio" : "json";
        }, De = he.slice(0, 6).map((Ce, ke) => ({ id: `out_${ke}`, label: Ce.name, type: G(Ce) })), Ne = {
          label: D.split("/").pop() || D,
          kind: "input",
          source: "dataset",
          dataset_id: D,
          dataset_config: ue.config,
          dataset_split: ue.split,
          inputs: [],
          outputs: De,
          width: 280,
          height: Math.max(90, 50 + De.length * 22)
        };
        a() === null || a() === void 0 || a()(Ne), _($t, i($t) + 1);
      } catch (E) {
        _(qt, E instanceof Error ? E.message : "Failed to load dataset", !0);
      } finally {
        _(Bt, !1);
      }
    });
  }
  const pn = [
    {
      key: "spaces",
      label: "Spaces",
      icon: "hub",
      items: Cr.spaces
    },
    { key: "models", label: "Models", icon: "model", items: [] },
    { key: "datasets", label: "Datasets", icon: "data", items: [] },
    {
      key: "components",
      label: "Components",
      icon: "layers",
      items: Cr.components
    }
  ];
  var en = wf();
  Oe("click", ks, S);
  let fn;
  var gn = k(en), nn = k(gn);
  let ie;
  var V = I(gn, 2);
  {
    var we = (D) => {
      var B = bf(), y = be(B);
      _t(y, 17, () => pn, Lt, (x, E) => {
        var U = _f(), X = be(U);
        let ue;
        var fe = k(X), Ve = k(fe), he = I(fe, 2), G = k(he), De = I(he, 2);
        let Ne;
        var Ce = I(X, 2);
        {
          var ke = (me) => {
            var Ze = mf(), dt = k(Ze);
            {
              var Pt = (Je) => {
                var ve = zd(), Ee = be(ve);
                {
                  var mt = (at) => {
                    var ht = Ud();
                    w(at, ht);
                  };
                  W(Ee, (at) => {
                    i(g) && at(mt);
                  });
                }
                var Ye = I(Ee, 2);
                _t(Ye, 17, () => wo, Lt, (at, ht) => {
                  const $e = pe(() => L(i(ht).key));
                  var it = Et(), Ht = be(it);
                  {
                    var et = (Ue) => {
                      var Te = Gd(), Se = be(Te), Re = k(Se), ae = k(Re), se = I(Re, 2), ot = k(se), je = I(Se, 2);
                      _t(je, 17, () => i($e), Lt, (ut, ze) => {
                        var vt = Fd(), Nt = k(vt), St = k(Nt);
                        let wt;
                        var At = I(St, 2), pt = k(At), It = I(At, 2), Xt = k(It), Kt = I(It, 2), Ct = I(Nt, 2), Zt = k(Ct), mn = I(Ct, 2);
                        {
                          var _n = (jt) => {
                            var hn = jd(), Ft = k(hn);
                            F(() => Y(Ft, i(ze).description)), w(jt, hn);
                          };
                          W(mn, (jt) => {
                            i(ze).description && jt(_n);
                          });
                        }
                        F(() => {
                          wt = We(St, 1, "space-card-status svelte-5hsmvk", null, wt, { "space-card-running": i(ze).running }), M(St, "title", i(ze).running ? "Running" : "Sleeping"), Y(pt, i(ze).title), Y(Xt, `♥ ${i(ze).likes ?? ""}`), M(Kt, "href", `https://huggingface.co/spaces/${i(ze).id ?? ""}`), Y(Zt, i(ze).id);
                        }), z("click", vt, () => a()?.(m(i(ze)))), Oe("dragstart", vt, (jt) => {
                          const hn = m(i(ze));
                          jt.dataTransfer.setData("node-template", JSON.stringify(hn));
                          const Ft = document.createElement("div");
                          Ft.textContent = i(ze).title, Ft.style.cssText = "background:#f97316;color:#0c0d10;padding:4px 10px;border-radius:5px;font-family:Manrope,sans-serif;font-size:11px;font-weight:600;position:fixed;top:-100px", document.body.appendChild(Ft), jt.dataTransfer.setDragImage(Ft, 0, 0), setTimeout(() => document.body.removeChild(Ft), 0);
                        }), z("click", Kt, (jt) => jt.stopPropagation()), w(ut, vt);
                      }), F(() => {
                        Y(ae, i(ht).label), Y(ot, i($e).length);
                      }), w(Ue, Te);
                    };
                    W(Ht, (Ue) => {
                      i($e).length > 0 && Ue(et);
                    });
                  }
                  w(at, it);
                }), w(Je, ve);
              }, Mt = (Je) => {
                var ve = Kd(), Ee = be(ve), mt = k(Ee), Ye = k(mt), at = I(Ee, 2);
                _t(at, 21, () => _e, Lt, (et, Ue) => {
                  var Te = Wd();
                  let Se;
                  var Re = k(Te);
                  F(() => {
                    Se = We(Te, 1, "model-task-tag svelte-5hsmvk", null, Se, {
                      "model-task-tag-active": i(rt) === i(Ue).key
                    }), Y(Re, i(Ue).label);
                  }), z("click", Te, () => ye(i(Ue).key)), w(et, Te);
                });
                var ht = I(at, 2);
                {
                  var $e = (et) => {
                    var Ue = Vd();
                    w(et, Ue);
                  }, it = (et) => {
                    var Ue = Zd(), Te = be(Ue);
                    _t(Te, 17, () => i(qe), Lt, (ae, se) => {
                      const ot = pe(() => Fe(i(se))), je = pe(() => i(ot).outputs[0]?.type ?? i(ot).inputs[0]?.type ?? "any");
                      var ut = qd(), ze = k(ut), vt = k(ze), Nt = I(vt, 2), St = k(Nt), wt = I(Nt, 2), At = k(wt), pt = I(ze, 2), It = k(pt), Xt = I(pt, 2), Kt = k(Xt);
                      F(
                        (Ct) => {
                          kt(vt, `background: ${nt[i(je)] ?? ""}; box-shadow: 0 0 6px ${nt[i(je)] ?? ""}40`), Y(St, Ct), Y(At, `♥ ${i(se).likes ?? ""}`), Y(It, i(se).id), Y(Kt, i(se).pipeline_tag);
                        },
                        [() => i(se).id.split("/").pop()]
                      ), z("click", ut, () => a()?.(i(ot))), Oe("dragstart", ut, (Ct) => {
                        Ct.dataTransfer.setData("node-template", JSON.stringify(i(ot)));
                        const Zt = document.createElement("div");
                        Zt.textContent = i(se).id, Zt.style.cssText = `background:${nt[i(je)]};color:#0c0d10;padding:4px 10px;border-radius:5px;font-family:Manrope,sans-serif;font-size:11px;font-weight:600;position:fixed;top:-100px`, document.body.appendChild(Zt), Ct.dataTransfer.setDragImage(Zt, 0, 0), setTimeout(() => document.body.removeChild(Zt), 0);
                      }), w(ae, ut);
                    });
                    var Se = I(Te, 2);
                    {
                      var Re = (ae) => {
                        var se = Xd();
                        w(ae, se);
                      };
                      W(Se, (ae) => {
                        i(qe).length === 0 && ae(Re);
                      });
                    }
                    w(et, Ue);
                  }, Ht = (et) => {
                    var Ue = Et(), Te = be(Ue);
                    {
                      var Se = (ae) => {
                        var se = Jd();
                        w(ae, se);
                      }, Re = (ae) => {
                        var se = Et(), ot = be(se);
                        _t(ot, 17, () => _e.slice(0, 6), Lt, (je, ut) => {
                          const ze = pe(() => Qe(i(ut).key));
                          var vt = Et(), Nt = be(vt);
                          {
                            var St = (wt) => {
                              var At = Qd(), pt = be(At), It = k(pt), Xt = k(It), Kt = I(It, 2), Ct = k(Kt), Zt = I(pt, 2);
                              _t(Zt, 17, () => i(ze).slice(0, 3), Lt, (mn, _n) => {
                                const jt = pe(() => Fe(i(_n))), hn = pe(() => i(jt).outputs[0]?.type ?? i(jt).inputs[0]?.type ?? "any");
                                var Ft = Yd(), fr = k(Ft), hr = k(fr), vr = I(hr, 2), d = k(vr), b = I(vr, 2), H = k(b), R = I(fr, 2), J = k(R);
                                F(
                                  ($) => {
                                    kt(hr, `background: ${nt[i(hn)] ?? ""}; box-shadow: 0 0 6px ${nt[i(hn)] ?? ""}40`), Y(d, $), Y(H, `♥ ${i(_n).likes ?? ""}`), Y(J, i(_n).id);
                                  },
                                  [() => i(_n).id.split("/").pop()]
                                ), z("click", Ft, () => a()?.(i(jt))), Oe("dragstart", Ft, ($) => {
                                  $.dataTransfer.setData("node-template", JSON.stringify(i(jt)));
                                }), w(mn, Ft);
                              }), F(() => {
                                Y(Xt, i(ut).label), Y(Ct, i(ze).length);
                              }), w(wt, At);
                            };
                            W(Nt, (wt) => {
                              i(ze).length > 0 && wt(St);
                            });
                          }
                          w(je, vt);
                        }), w(ae, se);
                      };
                      W(Te, (ae) => {
                        i(Rt) ? ae(Se) : ae(Re, -1);
                      });
                    }
                    w(et, Ue);
                  };
                  W(ht, (et) => {
                    i(Me) ? et($e) : i(Pe).length >= 2 || i(rt) ? et(it, 1) : et(Ht, -1);
                  });
                }
                F(() => vn(Ye, i(Pe))), z("input", Ye, Xe), w(Je, ve);
              }, ft = (Je) => {
                var ve = of(), Ee = be(ve), mt = k(Ee), Ye = k(mt), at = I(mt, 2);
                {
                  var ht = (Te) => {
                    var Se = tf();
                    _t(Se, 21, () => i(Ae), Lt, (Re, ae) => {
                      var se = ef(), ot = k(se), je = k(ot), ut = k(je), ze = I(je, 2), vt = k(ze), Nt = I(ot, 2);
                      {
                        var St = (wt) => {
                          var At = $d(), pt = k(At);
                          F(() => Y(pt, i(ae).description)), w(wt, At);
                        };
                        W(Nt, (wt) => {
                          i(ae).description && wt(St);
                        });
                      }
                      F(() => {
                        Y(ut, i(ae).id), Y(vt, `♥ ${i(ae).likes ?? ""}`);
                      }), z("click", se, () => {
                        const wt = i(ae).id;
                        _(Ae, [], !0), _(Ge, ""), dn(wt);
                      }), w(Re, se);
                    }), w(Te, Se);
                  }, $e = (Te) => {
                    var Se = nf();
                    w(Te, Se);
                  };
                  W(at, (Te) => {
                    i(Ae).length > 0 ? Te(ht) : i(lt) && Te($e, 1);
                  });
                }
                var it = I(Ee, 2);
                {
                  var Ht = (Te) => {
                    var Se = rf(), Re = I(k(Se), 2), ae = k(Re);
                    F(() => Y(ae, `Loading ${i(Yt) ?? ""}...`)), w(Te, Se);
                  };
                  W(it, (Te) => {
                    i(Bt) && Te(Ht);
                  });
                }
                var et = I(it, 2);
                {
                  var Ue = (Te) => {
                    var Se = af(), Re = k(Se);
                    F(() => Y(Re, i(qt))), w(Te, Se);
                  };
                  W(et, (Te) => {
                    i(qt) && Te(Ue);
                  });
                }
                F(() => {
                  vn(Ye, i(Ge)), Ye.disabled = i(Bt);
                }), z("input", Ye, cn), z("keydown", Ye, (Te) => {
                  Te.key === "Enter" && i(Ge).includes("/") && (_(Ae, [], !0), dn(i(Ge).trim())), Te.key === "Escape" && _(Ae, [], !0);
                }), w(Je, ve);
              }, Dt = (Je) => {
                var ve = Et(), Ee = be(ve);
                _t(Ee, 17, () => i(E).items, Lt, (mt, Ye) => {
                  const at = pe(() => de(i(Ye)));
                  var ht = sf(), $e = k(ht), it = I($e, 2), Ht = k(it);
                  F(() => {
                    kt($e, `background: ${nt[i(at)] ?? ""}; box-shadow: 0 0 6px ${nt[i(at)] ?? ""}40`), Y(Ht, i(Ye).label);
                  }), z("click", ht, () => a()?.(i(Ye))), Oe("dragstart", ht, (et) => {
                    et.dataTransfer.setData("node-template", JSON.stringify(i(Ye)));
                    const Ue = document.createElement("div");
                    Ue.textContent = i(Ye).label, Ue.style.cssText = `background:${nt[i(at)]};color:#0c0d10;padding:4px 10px;border-radius:5px;font-family:Manrope,sans-serif;font-size:11px;font-weight:600;position:fixed;top:-100px`, document.body.appendChild(Ue), et.dataTransfer.setDragImage(Ue, 0, 0), setTimeout(() => document.body.removeChild(Ue), 0);
                  }), w(mt, ht);
                }), w(Je, ve);
              };
              W(dt, (Je) => {
                i(E).key === "spaces" ? Je(Pt) : i(E).key === "models" ? Je(Mt, 1) : i(E).key === "datasets" ? Je(ft, 2) : Je(Dt, -1);
              });
            }
            var Ut = I(dt, 2);
            {
              var rn = (Je) => {
                var ve = gf(), Ee = be(ve);
                _t(Ee, 17, () => i(c), Lt, (ae, se, ot) => {
                  const je = pe(() => de(i(se)));
                  var ut = uf(), ze = k(ut), vt = I(ze, 2), Nt = k(vt), St = I(vt, 2);
                  {
                    var wt = (pt) => {
                      var It = lf();
                      F(() => M(It, "href", `https://huggingface.co/spaces/${i(se).space_id ?? ""}`)), z("click", It, (Xt) => Xt.stopPropagation()), w(pt, It);
                    };
                    W(St, (pt) => {
                      i(se).space_id && pt(wt);
                    });
                  }
                  var At = I(St, 2);
                  F(() => {
                    kt(ze, `background: ${nt[i(je)] ?? ""}; box-shadow: 0 0 6px ${nt[i(je)] ?? ""}40`), Y(Nt, i(se).label);
                  }), z("click", ut, () => a()?.(i(se))), Oe("dragstart", ut, (pt) => pt.dataTransfer.setData("node-template", JSON.stringify(i(se)))), z("click", At, (pt) => {
                    pt.stopPropagation(), _(c, i(c).filter((It, Xt) => Xt !== ot), !0);
                  }), w(ae, ut);
                });
                var mt = I(Ee, 2), Ye = k(mt), at = k(Ye), ht = I(at, 2), $e = k(ht), it = I(Ye, 2);
                {
                  var Ht = (ae) => {
                    var se = ff();
                    _t(se, 21, () => i(A), Lt, (ot, je) => {
                      var ut = df(), ze = k(ut), vt = k(ze);
                      let Nt;
                      var St = I(vt, 2), wt = k(St), At = I(St, 2), pt = k(At), It = I(At, 2), Xt = I(ze, 2);
                      {
                        var Kt = (Ct) => {
                          var Zt = cf(), mn = k(Zt);
                          F(() => Y(mn, i(je).description)), w(Ct, Zt);
                        };
                        W(Xt, (Ct) => {
                          i(je).description && Ct(Kt);
                        });
                      }
                      F(() => {
                        Nt = We(vt, 1, "search-result-status svelte-5hsmvk", null, Nt, { "search-result-running": i(je).running }), M(vt, "title", i(je).running ? "Running" : "Not running"), Y(wt, i(je).id), Y(pt, `♥ ${i(je).likes ?? ""}`), M(It, "href", `https://huggingface.co/spaces/${i(je).id ?? ""}`);
                      }), z("click", ut, () => j(i(je).id)), z("click", It, (Ct) => Ct.stopPropagation()), w(ot, ut);
                    }), w(ae, se);
                  }, et = (ae) => {
                    var se = hf();
                    w(ae, se);
                  };
                  W(it, (ae) => {
                    i(A).length > 0 ? ae(Ht) : i(N) && ae(et, 1);
                  });
                }
                var Ue = I(mt, 2);
                {
                  var Te = (ae) => {
                    var se = vf(), ot = I(k(se), 2), je = k(ot);
                    F(() => Y(je, `Connecting to ${i(p) ?? ""}...`)), w(ae, se);
                  };
                  W(Ue, (ae) => {
                    i(f) && ae(Te);
                  });
                }
                var Se = I(Ue, 2);
                {
                  var Re = (ae) => {
                    var se = pf(), ot = k(se);
                    F(() => Y(ot, i(C))), w(ae, se);
                  };
                  W(Se, (ae) => {
                    i(C) && ae(Re);
                  });
                }
                F(
                  (ae) => {
                    vn(at, i(T)), at.disabled = i(f), ht.disabled = ae, Y($e, i(f) ? "..." : "+");
                  },
                  [
                    () => i(f) || !i(T).trim().includes("/")
                  ]
                ), z("input", at, K), z("keydown", at, (ae) => {
                  ae.key === "Enter" && i(T).includes("/") && (_(A, [], !0), ce()), ae.key === "Escape" && _(A, [], !0);
                }), z("click", ht, () => {
                  _(A, [], !0), ce();
                }), w(Je, ve);
              };
              W(Ut, (Je) => {
                i(E).key === "spaces" && Je(rn);
              });
            }
            w(me, Ze);
          };
          W(Ce, (me) => {
            i(o) === i(E).key && me(ke);
          });
        }
        F(() => {
          ue = We(X, 1, "section-toggle svelte-5hsmvk", null, ue, { expanded: i(o) === i(E).key }), Y(Ve, i(E).label), Y(G, i(E).key === "spaces" ? i(c).length + i(h).length : i(E).key === "models" ? i(bt).length : i(E).key === "datasets" ? i($t) : i(E).items.length), Ne = We(De, 0, "section-chevron svelte-5hsmvk", null, Ne, { expanded: i(o) === i(E).key });
        }), z("click", X, () => re(i(E).key)), w(x, U);
      }), w(D, B);
    };
    W(V, (D) => {
      i(s) || D(we);
    });
  }
  var xe = I(V, 2);
  {
    var Ke = (D) => {
      var B = yf();
      z("mousedown", B, v), w(D, B);
    };
    W(xe, (D) => {
      i(s) || D(Ke);
    });
  }
  F(() => {
    fn = We(en, 1, "sidebar svelte-5hsmvk", null, fn, { "sidebar-collapsed": i(s) }), kt(en, `width: ${(i(s) ? 40 : i(l)) ?? ""}px; min-width: ${(i(s) ? 40 : i(l)) ?? ""}px;`), ie = We(nn, 1, "sidebar-collapse-btn svelte-5hsmvk", null, ie, { collapsed: i(s) });
  }), z("click", nn, () => _(s, !i(s))), w(e, en), Vt();
}
un(["click", "input", "keydown", "mousedown"]);
function kf(e, t) {
  const n = new Map(e.map((o) => [o.id, 0]));
  for (const o of t)
    n.set(o.to_node_id, (n.get(o.to_node_id) ?? 0) + 1);
  const r = e.filter((o) => n.get(o.id) === 0), a = [];
  for (; r.length; ) {
    const o = r.shift();
    a.push(o);
    for (const s of t.filter((l) => l.from_node_id === o.id)) {
      const l = (n.get(s.to_node_id) ?? 1) - 1;
      n.set(s.to_node_id, l), l === 0 && r.push(e.find((u) => u.id === s.to_node_id));
    }
  }
  return a;
}
function xi(e, t, n) {
  const r = {};
  for (const a of e.inputs) {
    const o = t.find(
      (s) => s.to_node_id === e.id && s.to_port_id === a.id
    );
    o ? r[a.id] = n[o.from_node_id]?.[o.from_port_id] ?? null : r[a.id] = e.data?.[a.id] ?? a.default_value ?? null;
  }
  return r;
}
async function Ef(e) {
  if (e === null) return null;
  if (typeof e == "string" || typeof e == "number" || typeof e == "boolean") return e;
  const t = e;
  if (t.url.startsWith("blob:") || t.url.startsWith("data:"))
    try {
      const n = await fetch(t.url);
      if (!n.ok) throw new Error(`Blob fetch failed: ${n.status}`);
      const r = await n.blob(), a = new FormData();
      a.append("files", r, t.name || "file");
      for (const o of ["/gradio_api/upload", "/upload"]) {
        const s = await fetch(o, { method: "POST", body: a });
        if (s.ok) {
          const l = await s.json();
          return { path: l[0], url: l[0] };
        }
      }
      throw new Error("Upload failed");
    } catch (n) {
      throw console.error("[Executor] File upload error:", n), new Error(`Failed to upload file: ${n instanceof Error ? n.message : n}`);
    }
  return { url: t.url };
}
function _a(e, t) {
  if (e == null) return null;
  if (Array.isArray(e))
    return e.length === 0 ? null : _a(e[e.length - 1], t);
  if (typeof e == "number" || typeof e == "boolean") return e;
  if (typeof e == "string")
    return t !== "text" && (e.startsWith("http://") || e.startsWith("https://") || e.startsWith("blob:") || e.startsWith("data:")) ? { name: "output", url: e, mime: t === "image" ? "image/png" : t === "audio" ? "audio/wav" : "video/mp4" } : e;
  if (typeof e == "object" && "url" in e) {
    const n = e;
    return {
      name: n.orig_name ?? "output",
      url: n.url,
      mime: n.mime_type ?? "application/octet-stream"
    };
  }
  return String(e);
}
async function Tf(e, t, n, r, a, o, s) {
  const { nodes: l, edges: u } = e, c = {};
  for (const p of l.filter((C) => C.kind === "input" ? !0 : C.kind === "component" ? !u.some((S) => S.to_node_id === C.id) : !1))
    c[p.id] = { ...p.data ?? {} };
  const v = kf(l, u), T = [];
  for (const p of v) {
    const S = u.filter((h) => h.to_node_id === p.id).map((h) => T.findIndex((g) => g.some((O) => O.id === h.from_node_id))).reduce((h, g) => Math.max(h, g), -1) + 1;
    for (; T.length <= S; ) T.push([]);
    T[S].push(p);
  }
  async function f(p) {
    if (r?.aborted) return;
    const C = p.kind === "component" && !u.some((h) => h.to_node_id === p.id);
    if (p.source === "dataset" && p.dataset_id) {
      t(p.id, "running");
      try {
        if (!s) throw new Error("Dataset fetch function not available");
        const h = await s(
          p.dataset_id,
          p.dataset_config ?? "default",
          p.dataset_split ?? "train",
          "0",
          "1"
        ), g = JSON.parse(h);
        if (g.error) throw new Error(g.error);
        const O = g.rows?.[0] ?? {};
        c[p.id] = {};
        for (const m of p.outputs) {
          const L = O[m.label] ?? null;
          if (L && typeof L == "object" && "src" in L) {
            const A = { name: m.label, url: L.src, mime: "application/octet-stream" };
            c[p.id][m.id] = A, n(p.id, m.id, A);
          } else
            c[p.id][m.id] = L, n(p.id, m.id, L);
        }
        t(p.id, "done");
      } catch (h) {
        const g = h instanceof Error ? h.message : String(h);
        t(p.id, "error", g), c[p.id] = {}, p.outputs.forEach((O) => {
          c[p.id][O.id] = null;
        });
      }
      return;
    }
    if (p.kind === "input" || C) {
      t(p.id, "done");
      return;
    }
    const S = p.kind === "component" && u.some((h) => h.to_node_id === p.id);
    if (p.kind === "output" || S) {
      const h = xi(p, u, c), g = p.inputs[0];
      if (g) {
        const O = h[g.id];
        c[p.id] = { [g.id]: O }, n(p.id, g.id, O);
        const m = p.outputs[0];
        m && (c[p.id][m.id] = O);
      }
      t(p.id, "done");
      return;
    }
    if (p.kind === "transform" && (p.space_id || p.model_id)) {
      t(p.id, "running");
      try {
        const h = xi(p, u, c), g = await Promise.all(p.inputs.map((A) => Ef(h[A.id])));
        let O;
        if (p.source === "model" && p.model_id) {
          if (console.log(`[Executor] Calling model ${p.model_id} task="${p.pipeline_tag}" args:`, JSON.stringify(g)), !o)
            throw new Error("Model call function not available");
          O = await Promise.race([
            o(p.model_id, p.pipeline_tag ?? "text-generation", JSON.stringify(g)),
            new Promise(
              (A, N) => setTimeout(() => N(new Error("Request timed out — model may be loading")), 3e5)
            )
          ]);
        } else {
          const A = p.endpoint ?? "/predict";
          if (console.log(`[Executor] Calling ${p.space_id} endpoint="${A}" args:`, JSON.stringify(g)), !a)
            throw new Error("Server call function not available");
          O = await Promise.race([
            a(p.space_id, A, JSON.stringify(g)),
            new Promise(
              (N, q) => setTimeout(() => q(new Error("Request timed out — Space may be overloaded")), 3e5)
            )
          ]);
        }
        const m = JSON.parse(O);
        if (m && typeof m == "object" && "error" in m) {
          const A = m.title, N = m.suggestion, q = m.error_type;
          let K = A ? `${A}: ${m.error}` : m.error;
          N && (K += ` — ${N}`);
          const j = new Error(K);
          throw j.errorType = q, j;
        }
        c[p.id] = {};
        const L = Array.isArray(m) ? m : [m];
        if (p.outputs.length === 1 && L.length > 1) {
          const A = _a(L[L.length - 1], p.outputs[0].type);
          c[p.id][p.outputs[0].id] = A, n(p.id, p.outputs[0].id, A);
        } else
          p.outputs.forEach((A, N) => {
            const q = _a(L[N] ?? null, A.type);
            c[p.id][A.id] = q, n(p.id, A.id, q);
          });
        t(p.id, "done");
      } catch (h) {
        const g = h instanceof Error ? h.message : String(h), O = h?.errorType;
        t(p.id, "error", g, O), c[p.id] = {}, p.outputs.forEach((m) => {
          c[p.id][m.id] = null;
        });
      }
    }
  }
  for (const p of T) {
    if (r?.aborted) break;
    await Promise.all(p.map(f));
  }
}
var Sf = Object.defineProperty, Af = (e, t, n) => t in e ? Sf(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, on = (e, t, n) => (Af(e, typeof t != "symbol" ? t + "" : t, n), n), nr = "https://huggingface.co";
async function wn(e, t) {
  var n, r;
  const a = new Eo(e.url, e.status, (n = e.headers.get("X-Request-Id")) != null ? n : t?.requestId);
  a.message = `Api error with status ${a.statusCode}${t?.message ? `. ${t.message}` : ""}`;
  const o = [`URL: ${a.url}`, a.requestId ? `Request ID: ${a.requestId}` : void 0].filter(Boolean).join(". ");
  if ((r = e.headers.get("Content-Type")) != null && r.startsWith("application/json")) {
    const s = await e.json();
    a.message = s.error || s.message || a.message, s.error_description && (a.message = a.message ? a.message + `: ${s.error_description}` : s.error_description), a.data = s;
  } else
    a.data = { message: await e.text() };
  throw a.message += `. ${o}`, a;
}
var Eo = class extends Error {
  constructor(e, t, n, r) {
    super(r), on(this, "statusCode"), on(this, "url"), on(this, "requestId"), on(this, "data"), this.statusCode = t, this.requestId = n, this.url = e;
  }
}, If = class extends Error {
};
function ki(e) {
  if (!e.startsWith("hf_"))
    throw new TypeError("Your access token must start with 'hf_'");
}
function Pa(e) {
  var t;
  if (e.accessToken)
    return ki(e.accessToken), e.accessToken;
  if ((t = e.credentials) != null && t.accessToken)
    return ki(e.credentials.accessToken), e.credentials.accessToken;
}
function To(e) {
  if (typeof e != "string")
    return e;
  if (e.startsWith("model/") || e.startsWith("models/"))
    throw new TypeError(
      "A repo designation for a model should not start with 'models/', directly specify the model namespace / name"
    );
  if (e.startsWith("space/"))
    throw new TypeError("Spaces should start with 'spaces/', plural, not 'space/'");
  if (e.startsWith("dataset/"))
    throw new TypeError("Datasets should start with 'dataset/', plural, not 'dataset/'");
  const t = e.split("/").length - 1;
  if (e.startsWith("spaces/")) {
    if (t !== 2)
      throw new TypeError("Space Id must include namespace and name of the space");
    return {
      type: "space",
      name: e.slice(7)
    };
  }
  if (e.startsWith("datasets/")) {
    if (t > 2)
      throw new TypeError("Too many slashes in repo designation: " + e);
    return {
      type: "dataset",
      name: e.slice(9)
    };
  }
  if (t > 1)
    throw new TypeError("Too many slashes in repo designation: " + e);
  return {
    type: "model",
    name: e
  };
}
function Of(e, t) {
  return t ? Array(t - e).fill(0).map((n, r) => e + r) : Array(e).fill(0).map((n, r) => r);
}
function Ei(e, t) {
  if (isNaN(t) || t < 1)
    throw new RangeError("Invalid chunk size: " + t);
  return e.length ? e.length <= t ? [e] : Of(Math.ceil(e.length / t)).map((n) => e.slice(n * t, (n + 1) * t)) : [];
}
async function Cf(e, t) {
  const n = [], r = /* @__PURE__ */ new Set();
  let a = 0;
  for (const o of e) {
    const s = a++, l = o().then((u) => {
      n[s] = u, r.delete(l);
    });
    r.add(l), r.size >= t && await Promise.race(r);
  }
  return await Promise.all(r), n;
}
async function Ti(e, t) {
  const n = [];
  for await (const r of e) {
    const a = r().then(() => {
      n.splice(n.indexOf(a), 1);
    });
    n.push(a), n.length >= t && await Promise.race(n);
  }
  await Promise.all(n);
}
async function* Tr(e) {
  const t = [];
  function n() {
    let a, o;
    const s = new Promise((l, u) => {
      a = l, o = u;
    });
    t.push({ p: s, resolve: a, reject: o });
  }
  n();
  const r = Promise.resolve().then(
    () => e(
      (a) => {
        var o;
        n(), (o = t.at(-2)) == null || o.resolve({ done: !1, value: a });
      },
      (a) => {
        var o;
        n(), (o = t.at(-2)) == null || o.resolve({ done: !0, value: a });
      },
      (a) => {
        var o;
        return (o = t.shift()) == null ? void 0 : o.reject(a);
      }
    )
  ).catch((a) => {
    var o;
    return (o = t.shift()) == null ? void 0 : o.reject(a);
  });
  for (; ; ) {
    const a = t[0];
    if (!a)
      throw new Error("Logic error in eventGenerator, promises should never be empty");
    const o = await a.p;
    if (t.shift(), o.done)
      return await r, o.value;
    yield o.value;
  }
  throw new Error("Unreachable");
}
function Lf(e) {
  if (globalThis.Buffer)
    return globalThis.Buffer.from(e).toString("hex");
  {
    const t = [];
    return e.forEach((n) => {
      t.push(n.toString(16).padStart(2, "0"));
    }), t.join("");
  }
}
var Pf = typeof window < "u" && typeof window.document < "u", Hf = typeof self == "object" && self.constructor && self.constructor.name === "DedicatedWorkerGlobalScope", Nf = !Pf && !Hf, Lr = !Nf;
async function Si() {
  const e = await import("./sha256-wrapper-GDBS2T5O-C--_DOwM.js");
  return URL.createObjectURL(new Blob([e.createSHA256WorkerCode()]));
}
var So = [], Mn = /* @__PURE__ */ new Set(), ir, Ha = new Promise((e) => {
  ir = e;
});
async function Rf(e) {
  {
    const n = So.pop();
    if (n)
      return Mn.add(n), n;
  }
  if (!e) {
    const n = new Worker(await Si());
    return Mn.add(n), n;
  }
  if (e <= 0)
    throw new TypeError("Invalid webworker pool size: " + e);
  for (; Mn.size >= e; )
    await Ha;
  const t = new Worker(await Si());
  return Mn.add(t), t;
}
async function Bf(e, t) {
  if (!t)
    return Sr(e);
  Mn.delete(e), So.push(e);
  const n = ir;
  Ha = new Promise((r) => {
    ir = r;
  }), n();
}
function Sr(e) {
  Mn.delete(e), e.terminate();
  const t = ir;
  Ha = new Promise((n) => {
    ir = n;
  }), t();
}
async function* Mf(e, t) {
  var n, r;
  yield 0;
  const a = typeof t?.useWebWorker == "object" && t?.useWebWorker.minSize !== void 0 ? t.useWebWorker.minSize : 1e7;
  if (e.size < a && ((n = globalThis.crypto) != null && n.subtle)) {
    const o = Lf(
      new Uint8Array(
        await globalThis.crypto.subtle.digest("SHA-256", e instanceof Blob ? await e.arrayBuffer() : e)
      )
    );
    return yield 1, o;
  }
  if (Lr) {
    if (t?.useWebWorker)
      try {
        const c = typeof t?.useWebWorker == "object" ? t.useWebWorker.poolSize : void 0, v = await Rf(c);
        return yield* Tr((T, f, p) => {
          v.addEventListener("message", (C) => {
            var S;
            if (C.data.sha256)
              Bf(v, c), f(C.data.sha256);
            else if (C.data.progress) {
              T(C.data.progress);
              try {
                (S = t.abortSignal) == null || S.throwIfAborted();
              } catch (h) {
                Sr(v), p(h);
              }
            } else
              Sr(v), p(C);
          }), v.addEventListener("error", (C) => {
            Sr(v), p(C.error);
          }), v.postMessage({ file: e });
        });
      } catch (c) {
        console.warn("Failed to use web worker for sha256", c);
      }
    ta || (ta = await import("./sha256-wrapper-GDBS2T5O-C--_DOwM.js"));
    const o = await ta.createSHA256();
    o.init();
    const s = e.stream().getReader(), l = e.size;
    let u = 0;
    for (; ; ) {
      const { done: c, value: v } = await s.read();
      if (c)
        break;
      o.update(v), u += v.length, yield u / l, (r = t?.abortSignal) == null || r.throwIfAborted();
    }
    return o.digest("hex");
  }
  return ea || (ea = await import("./FileBlob-7MRLQ6TG-DtQ5hfc_.js").then((o) => o.aQ)), yield* ea.sha256Node(e, { abortSignal: t?.abortSignal });
}
var ea, ta, or = class extends Blob {
  constructor(e, t, n, r, a, o) {
    super([]), on(this, "url"), on(this, "start"), on(this, "end"), on(this, "contentType"), on(this, "full"), on(this, "fetch"), this.url = e, this.start = t, this.end = n, this.contentType = r, this.full = a, this.fetch = o;
  }
  static async create(e, t) {
    var n, r;
    const a = (n = t?.fetch) != null ? n : fetch, o = await a(e, { method: "HEAD" }), s = Number(o.headers.get("content-length")), l = o.headers.get("content-type") || "";
    return !(o.headers.get("accept-ranges") === "bytes") || s < ((r = t?.cacheBelow) != null ? r : 1e6) ? await (await a(e)).blob() : new or(e, 0, s, l, !0, a);
  }
  get size() {
    return this.end - this.start;
  }
  get type() {
    return this.contentType;
  }
  slice(e = 0, t = this.size) {
    return new or(
      this.url,
      this.start + e,
      Math.min(this.start + t, this.end),
      this.contentType,
      e === 0 && t === this.size ? this.full : !1,
      this.fetch
    );
  }
  async arrayBuffer() {
    return (await this.fetchRange()).arrayBuffer();
  }
  async text() {
    return (await this.fetchRange()).text();
  }
  stream() {
    const e = new TransformStream();
    return this.fetchRange().then((t) => {
      var n;
      return (n = t.body) == null ? void 0 : n.pipeThrough(e);
    }).catch((t) => e.writable.abort(t.message)), e.readable;
  }
  fetchRange() {
    const e = this.fetch;
    return this.full ? e(this.url) : e(this.url, {
      headers: {
        Range: `bytes=${this.start}-${this.end - 1}`
      }
    });
  }
};
async function Df(e, t) {
  if (e.protocol === "http:" || e.protocol === "https:")
    return or.create(e, { fetch: t?.fetch });
  if (Lr)
    throw new TypeError(`Unsupported URL protocol "${e.protocol}"`);
  if (e.protocol === "file:") {
    const { FileBlob: n } = await import("./FileBlob-7MRLQ6TG-DtQ5hfc_.js").then((r) => r.aR);
    return n.create(e);
  }
  throw new TypeError(`Unsupported URL protocol "${e.protocol}"`);
}
function Na(e) {
  if (globalThis.Buffer)
    return globalThis.Buffer.from(e).toString("base64");
  {
    const t = [];
    return e.forEach((n) => {
      t.push(String.fromCharCode(n));
    }), globalThis.btoa(t.join(""));
  }
}
var Uf = 5, jf = 5, Ff = 5;
function Kn(e) {
  const t = e.operation === "addOrUpdate";
  if (t && !(e.content instanceof Blob))
    throw new TypeError("Precondition failed: op.content should be a Blob");
  return t;
}
async function* Gf(e) {
  var t, n, r, a, o, s, l;
  const u = Pa(e), c = To(e.repo);
  yield { event: "phase", phase: "preuploading" };
  const v = /* @__PURE__ */ new Map(), T = new AbortController(), f = T.signal;
  f.throwIfAborted || (f.throwIfAborted = () => {
    if (f.aborted)
      throw new DOMException("Aborted", "AbortError");
  }), e.abortSignal && e.abortSignal.addEventListener("abort", () => T.abort());
  try {
    const p = await Promise.all(
      e.operations.map(async (S) => {
        if (S.operation !== "addOrUpdate")
          return S;
        if (!(S.content instanceof URL))
          return { ...S, content: S.content };
        const h = await Df(S.content, { fetch: e.fetch });
        return f?.throwIfAborted(), {
          ...S,
          content: h
        };
      })
    ), C = (t = p.filter(Kn).find((S) => S.path === ".gitattributes")) == null ? void 0 : t.content;
    for (const S of Ei(p.filter(Kn), 100)) {
      const h = {
        gitAttributes: C && await C.text(),
        files: await Promise.all(
          S.map(async (m) => ({
            path: m.path,
            size: m.content.size,
            sample: Na(new Uint8Array(await m.content.slice(0, 512).arrayBuffer()))
          }))
        )
      };
      f?.throwIfAborted();
      const g = await ((n = e.fetch) != null ? n : fetch)(
        `${(r = e.hubUrl) != null ? r : nr}/api/${c.type}s/${c.name}/preupload/${encodeURIComponent(
          (a = e.branch) != null ? a : "main"
        )}` + (e.isPullRequest ? "?create_pr=1" : ""),
        {
          method: "POST",
          headers: {
            ...u && { Authorization: `Bearer ${u}` },
            "Content-Type": "application/json"
          },
          body: JSON.stringify(h),
          signal: f
        }
      );
      if (!g.ok)
        throw await wn(g);
      const O = await g.json();
      for (const m of O.files)
        m.uploadMode === "lfs" && v.set(m.path, null);
    }
    yield { event: "phase", phase: "uploadingLargeFiles" };
    for (const S of Ei(
      p.filter(Kn).filter((h) => v.has(h.path)),
      100
    )) {
      const h = yield* Tr((N, q, K) => Cf(
        S.map((j) => async () => {
          const de = Mf(j.content, { useWebWorker: e.useWebWorkers, abortSignal: f });
          let re;
          do
            re = await de.next(), re.done || N({ event: "fileProgress", path: j.path, progress: re.value, state: "hashing" });
          while (!re.done);
          const ce = re.value;
          return v.set(j.path, re.value), ce;
        }),
        Uf
      ).then(q, K));
      f?.throwIfAborted();
      const g = {
        operation: "upload",
        // multipart is a custom protocol for HF
        transfers: ["basic", "multipart"],
        hash_algo: "sha_256",
        ...!e.isPullRequest && {
          ref: {
            name: (o = e.branch) != null ? o : "main"
          }
        },
        objects: S.map((N, q) => ({
          oid: h[q],
          size: N.content.size
        }))
      }, O = await ((s = e.fetch) != null ? s : fetch)(
        `${(l = e.hubUrl) != null ? l : nr}/${c.type === "model" ? "" : c.type + "s/"}${c.name}.git/info/lfs/objects/batch`,
        {
          method: "POST",
          headers: {
            ...u && { Authorization: `Bearer ${u}` },
            Accept: "application/vnd.git-lfs+json",
            "Content-Type": "application/vnd.git-lfs+json"
          },
          body: JSON.stringify(g),
          signal: f
        }
      );
      if (!O.ok)
        throw await wn(O);
      const m = await O.json(), L = O.headers.get("X-Request-Id") || void 0, A = new Map(S.map((N, q) => [h[q], N]));
      yield* Tr((N, q, K) => Ti(
        m.objects.map((j) => async () => {
          var de, re, ce;
          const _e = A.get(j.oid);
          if (!_e)
            throw new If("Unrequested object ID in response");
          if (f?.throwIfAborted(), j.error) {
            const Me = `Error while doing LFS batch call for ${S[h.indexOf(j.oid)].path}: ${j.error.message}${L ? ` - Request ID: ${L}` : ""}`;
            throw new Eo(O.url, j.error.code, L, Me);
          }
          if (!((de = j.actions) != null && de.upload)) {
            N({
              event: "fileProgress",
              path: _e.path,
              progress: 1,
              state: "uploading"
            });
            return;
          }
          N({
            event: "fileProgress",
            path: _e.path,
            progress: 0,
            state: "uploading"
          });
          const Pe = _e.content, qe = j.actions.upload.header;
          if (qe?.chunk_size) {
            const Me = parseInt(qe.chunk_size), Tt = j.actions.upload.href, rt = Object.keys(qe).filter((Xe) => /^[0-9]+$/.test(Xe));
            if (rt.length !== Math.ceil(Pe.size / Me))
              throw new Error("Invalid server response to upload large LFS file, wrong number of parts");
            const bt = {
              oid: j.oid,
              parts: rt.map((Xe) => ({
                partNumber: +Xe,
                etag: ""
              }))
            }, Rt = (Xe) => N({ event: "fileProgress", path: _e.path, progress: Xe, state: "uploading" });
            await Ti(
              rt.map((Xe) => async () => {
                var ye;
                f?.throwIfAborted();
                const Fe = parseInt(Xe) - 1, Qe = Pe.slice(Fe * Me, (Fe + 1) * Me), Ge = await ((ye = e.fetch) != null ? ye : fetch)(qe[Xe], {
                  method: "PUT",
                  /** Unfortunately, browsers don't support our inherited version of Blob in fetch calls */
                  body: Qe instanceof or && Lr ? await Qe.arrayBuffer() : Qe,
                  signal: f,
                  progressHint: {
                    path: _e.path,
                    part: Fe,
                    numParts: rt.length,
                    progressCallback: Rt
                  }
                });
                if (!Ge.ok)
                  throw await wn(Ge, {
                    requestId: L,
                    message: `Error while uploading part ${Xe} of ${S[h.indexOf(j.oid)].path} to LFS storage`
                  });
                const Ae = Ge.headers.get("ETag");
                if (!Ae)
                  throw new Error("Cannot get ETag of part during multipart upload");
                bt.parts[Number(Xe) - 1].etag = Ae;
              }),
              Ff
            ), f?.throwIfAborted();
            const yt = await ((re = e.fetch) != null ? re : fetch)(Tt, {
              method: "POST",
              body: JSON.stringify(bt),
              headers: {
                Accept: "application/vnd.git-lfs+json",
                "Content-Type": "application/vnd.git-lfs+json"
              },
              signal: f
            });
            if (!yt.ok)
              throw await wn(yt, {
                requestId: L,
                message: `Error completing multipart upload of ${S[h.indexOf(j.oid)].path} to LFS storage`
              });
            N({
              event: "fileProgress",
              path: _e.path,
              progress: 1,
              state: "uploading"
            });
          } else {
            const Me = await ((ce = e.fetch) != null ? ce : fetch)(j.actions.upload.href, {
              method: "PUT",
              headers: {
                ...L ? { "X-Request-Id": L } : void 0
              },
              /** Unfortunately, browsers don't support our inherited version of Blob in fetch calls */
              body: Pe instanceof or && Lr ? await Pe.arrayBuffer() : Pe,
              signal: f,
              progressHint: {
                path: _e.path,
                progressCallback: (Tt) => N({
                  event: "fileProgress",
                  path: _e.path,
                  progress: Tt,
                  state: "uploading"
                })
              }
            });
            if (!Me.ok)
              throw await wn(Me, {
                requestId: L,
                message: `Error while uploading ${S[h.indexOf(j.oid)].path} to LFS storage`
              });
            N({
              event: "fileProgress",
              path: _e.path,
              progress: 1,
              state: "uploading"
            });
          }
        }),
        jf
      ).then(q, K));
    }
    return f?.throwIfAborted(), yield { event: "phase", phase: "committing" }, yield* Tr(
      async (S, h, g) => {
        var O, m, L;
        return ((O = e.fetch) != null ? O : fetch)(
          `${(m = e.hubUrl) != null ? m : nr}/api/${c.type}s/${c.name}/commit/${encodeURIComponent(
            (L = e.branch) != null ? L : "main"
          )}` + (e.isPullRequest ? "?create_pr=1" : ""),
          {
            method: "POST",
            headers: {
              ...u && { Authorization: `Bearer ${u}` },
              "Content-Type": "application/x-ndjson"
            },
            body: [
              {
                key: "header",
                value: {
                  summary: e.title,
                  description: e.description,
                  parentCommit: e.parentCommit
                }
              },
              ...await Promise.all(
                p.map((A) => {
                  if (Kn(A)) {
                    const N = v.get(A.path);
                    if (N)
                      return {
                        key: "lfsFile",
                        value: {
                          path: A.path,
                          algo: "sha256",
                          size: A.content.size,
                          oid: N
                        }
                      };
                  }
                  return Wf(A);
                })
              )
            ].map((A) => JSON.stringify(A)).join(`
`),
            signal: f,
            progressHint: {
              progressCallback: (A) => {
                for (const N of p)
                  Kn(N) && !v.has(N.path) && S({
                    event: "fileProgress",
                    path: N.path,
                    progress: A,
                    state: "uploading"
                  });
              }
            }
          }
        ).then(async (A) => {
          if (!A.ok)
            throw await wn(A);
          const N = await A.json();
          h({
            pullRequestUrl: N.pullRequestUrl,
            commit: {
              oid: N.commitOid,
              url: N.commitUrl
            },
            hookOutput: N.hookOutput
          });
        }).catch(g);
      }
    );
  } catch (p) {
    throw T.abort(), p;
  }
}
async function zf(e) {
  const t = Gf(e);
  let n = await t.next();
  for (; !n.done; )
    n = await t.next();
  return n.value;
}
async function Wf(e) {
  switch (e.operation) {
    case "addOrUpdate":
      return {
        key: "file",
        value: {
          content: Na(new Uint8Array(await e.content.arrayBuffer())),
          path: e.path,
          encoding: "base64"
        }
      };
    case "delete":
      return {
        key: "deletedFile",
        value: {
          path: e.path
        }
      };
    default:
      throw new TypeError("Unknown operation: " + e.operation);
  }
}
async function Vf(e) {
  var t, n;
  const r = Pa(e), a = To(e.repo), [o, s] = a.name.split("/");
  if (!o || !s)
    throw new TypeError(
      `"${a.name}" is not a fully qualified repo name. It should be of the form "{namespace}/{repoName}".`
    );
  const l = await ((t = e.fetch) != null ? t : fetch)(`${(n = e.hubUrl) != null ? n : nr}/api/repos/create`, {
    method: "POST",
    body: JSON.stringify({
      name: s,
      private: e.private,
      organization: o,
      license: e.license,
      ...a.type === "space" ? {
        type: "space",
        sdk: "static"
      } : {
        type: a.type
      },
      files: e.files ? await Promise.all(
        e.files.map(async (c) => ({
          encoding: "base64",
          path: c.path,
          content: Na(
            new Uint8Array(c.content instanceof Blob ? await c.content.arrayBuffer() : c.content)
          )
        }))
      ) : void 0
    }),
    headers: {
      Authorization: `Bearer ${r}`,
      "Content-Type": "application/json"
    }
  });
  if (!l.ok)
    throw await wn(l);
  return { repoUrl: (await l.json()).url };
}
function qf(e) {
  var t;
  return zf({
    ...e.accessToken ? { accessToken: e.accessToken } : { credentials: e.credentials },
    repo: e.repo,
    operations: e.files.map((n) => {
      var r;
      return {
        operation: "addOrUpdate",
        path: n instanceof URL ? (r = n.pathname.split("/").at(-1)) != null ? r : "file" : "path" in n ? n.path : n.name,
        content: "content" in n ? n.content : n
      };
    }),
    title: (t = e.commitTitle) != null ? t : `Add ${e.files.length} files`,
    description: e.commitDescription,
    hubUrl: e.hubUrl,
    branch: e.branch,
    isPullRequest: e.isPullRequest,
    parentCommit: e.parentCommit,
    fetch: e.fetch,
    useWebWorkers: e.useWebWorkers,
    abortSignal: e.abortSignal
  });
}
async function Xf(e) {
  var t, n, r;
  const a = Pa(e), o = await ((t = e.fetch) != null ? t : fetch)(`${(n = e.hubUrl) != null ? n : nr}/api/whoami-v2`, {
    headers: {
      Authorization: `Bearer ${a}`
    }
  });
  if (!o.ok)
    throw await wn(o);
  const s = await o.json();
  return typeof ((r = s.auth.accessToken) == null ? void 0 : r.createdAt) == "string" && (s.auth.accessToken.createdAt = new Date(s.auth.accessToken.createdAt)), s;
}
var na = 65536;
Zf();
function Zf() {
  try {
    return new Uint32Array(na);
  } catch {
    const t = new Array(na);
    for (let n = 0; n < na; n++)
      t[n] = 0;
    return t;
  }
}
function Jf() {
  return `import gradio_workflowcanvas

gradio_workflowcanvas.show()
`;
}
function Yf(e) {
  return `---
title: ${e.name}
emoji: 🔀
colorFrom: blue
colorTo: indigo
sdk: gradio
sdk_version: 6.12.0
app_file: app.py
pinned: false
hf_oauth: true
hf_oauth_scopes:
- inference-api
tags:
  - gradio-workflow
---

# ${e.name}

An AI workflow built and hosted with [Gradio Workflow Builder](https://huggingface.co/spaces/hmb/workflow).
`;
}
function Qf() {
  return `gradio_workflowcanvas>=0.0.10
`;
}
async function Kf(e, t, n, r) {
  r("Checking identity...");
  const o = (await Xf({ accessToken: t })).name, s = n.replace(/[^a-zA-Z0-9_-]/g, "-").toLowerCase(), l = `${o}/${s}`;
  r("Creating Space...");
  try {
    await Vf({
      repo: { type: "space", name: l },
      accessToken: t,
      spaceSdk: "gradio"
    });
  } catch (f) {
    if (!f.message?.includes("already")) throw f;
  }
  r("Uploading files...");
  const u = Jf(), c = Yf(e), v = Qf(), T = JSON.stringify(e, null, 2);
  return await qf({
    repo: { type: "space", name: l },
    accessToken: t,
    files: [
      { path: "app.py", content: new Blob([u], { type: "text/plain" }) },
      { path: "requirements.txt", content: new Blob([v], { type: "text/plain" }) },
      { path: "README.md", content: new Blob([c], { type: "text/plain" }) },
      { path: "workflow.json", content: new Blob([T], { type: "application/json" }) }
    ],
    commitTitle: "Deploy from Gradio Workflow Builder"
  }), r("Done!"), `https://huggingface.co/spaces/${l}`;
}
var $f = /* @__PURE__ */ P('<input class="name-input svelte-16twpg4"/>'), eh = /* @__PURE__ */ P('<button class="name-btn svelte-16twpg4"><span class="name-text svelte-16twpg4"> </span> <span class="name-edit-icon svelte-16twpg4">&#x270E;</span></button>'), th = /* @__PURE__ */ P('<span class="toolbar-user-info svelte-16twpg4">Logged in as <strong class="svelte-16twpg4"> </strong></span> <button class="toolbar-login-btn logged-in svelte-16twpg4">Log out</button>', 1), nh = /* @__PURE__ */ P('<button class="toolbar-login-btn svelte-16twpg4">Sign in with 🤗</button>'), rh = /* @__PURE__ */ P('<form><input class="toolbar-token-input svelte-16twpg4" type="password" placeholder="Paste HF token (hf_...)" title="HuggingFace token for GPU access"/></form>'), ah = /* @__PURE__ */ P('<button class="run-btn stop svelte-16twpg4"><span class="run-icon svelte-16twpg4">&#x25A0;</span> Stop</button>'), ih = /* @__PURE__ */ P('<button class="run-btn svelte-16twpg4"><span class="run-icon svelte-16twpg4">&#x25B6;</span> Run</button>'), oh = /* @__PURE__ */ P('<div class="run-overlay svelte-16twpg4"></div>'), sh = /* @__PURE__ */ P('<button class="template-card svelte-16twpg4"><span class="template-name svelte-16twpg4"> </span> <span class="template-desc svelte-16twpg4"> </span></button>'), lh = /* @__PURE__ */ P('<div class="trending-loading-row svelte-16twpg4"><span class="trending-spinner svelte-16twpg4"></span> <span class="trending-loading-text svelte-16twpg4">Loading...</span></div>'), uh = /* @__PURE__ */ P('<div class="trending-card-desc svelte-16twpg4"> </div>'), ch = /* @__PURE__ */ P('<button class="trending-card svelte-16twpg4"><div class="trending-card-top svelte-16twpg4"><span></span> <span class="trending-card-title svelte-16twpg4"> </span> <span class="trending-card-likes svelte-16twpg4"> </span></div> <!> <div class="trending-card-id svelte-16twpg4"> </div></button>'), dh = /* @__PURE__ */ P('<div class="trending-cat-label svelte-16twpg4"> </div> <div class="trending-grid svelte-16twpg4"></div>', 1), fh = /* @__PURE__ */ P('<div class="empty-state svelte-16twpg4"><div class="empty-title svelte-16twpg4">Start building</div> <div class="empty-hint svelte-16twpg4">Drag components from the sidebar, or try a template</div> <div class="template-grid svelte-16twpg4"></div> <div class="trending-section svelte-16twpg4"><div class="trending-header svelte-16twpg4">Trending Spaces</div> <!></div></div>'), hh = /* @__PURE__ */ P('<div class="shortcuts-panel svelte-16twpg4"><div class="shortcuts-title svelte-16twpg4">Keyboard shortcuts</div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Cmd+Enter</kbd> <span>Run workflow</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Cmd+S</kbd> <span>Export JSON</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Cmd+D</kbd> <span>Duplicate node</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">F</kbd> <span>Zoom to fit</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Cmd+0</kbd> <span>Reset zoom</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Delete</kbd> <span>Remove node</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Escape</kbd> <span>Deselect</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Scroll</kbd> <span>Zoom</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Drag canvas</kbd> <span>Pan</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Double-click</kbd> <span>Rename node</span></div></div>'), vh = /* @__PURE__ */ P('<div class="connection-badge svelte-16twpg4"> </div>'), ph = /* @__PURE__ */ P("<div> </div>"), gh = /* @__PURE__ */ P('<div class="wf-toast-stack svelte-16twpg4"></div>'), mh = /* @__PURE__ */ P('<p class="deploy-status svelte-16twpg4"> </p>'), _h = /* @__PURE__ */ P('<label class="deploy-label svelte-16twpg4" for="deploy-name">Space name</label> <input id="deploy-name" class="deploy-input svelte-16twpg4" type="text" placeholder="my-workflow"/> <p class="deploy-hint svelte-16twpg4">Deploys to <strong class="svelte-16twpg4"> </strong> — a full editable workflow canvas with your current workflow pre-loaded.</p> <!> <div class="deploy-modal-actions svelte-16twpg4"><button class="deploy-cancel-btn svelte-16twpg4">Cancel</button> <button class="deploy-confirm-btn svelte-16twpg4"> </button></div>', 1), bh = /* @__PURE__ */ P('<p class="deploy-success svelte-16twpg4">Your Space is live! It may take a minute to build.</p> <a class="deploy-link svelte-16twpg4" target="_blank" rel="noopener"> </a> <div class="deploy-modal-actions svelte-16twpg4"><button class="deploy-confirm-btn svelte-16twpg4">Done</button></div>', 1), yh = /* @__PURE__ */ P('<div class="deploy-overlay svelte-16twpg4"><div class="deploy-modal svelte-16twpg4"><div class="deploy-modal-header svelte-16twpg4"><span class="deploy-modal-title svelte-16twpg4">Deploy to HF Space</span> <button class="deploy-modal-close svelte-16twpg4">✕</button></div> <div class="deploy-modal-body svelte-16twpg4"><!></div></div></div>'), wh = /* @__PURE__ */ P('<div class="workflow-root svelte-16twpg4"><div class="toolbar svelte-16twpg4"><div class="toolbar-left svelte-16twpg4"><!> <span class="toolbar-stat svelte-16twpg4"> </span></div> <div class="toolbar-right svelte-16twpg4"><!> <button class="tool-btn svelte-16twpg4" title="Export workflow.json (Cmd+S)">Export</button> <button class="tool-btn svelte-16twpg4" title="Import workflow.json">Import</button> <button class="tool-btn deploy-btn svelte-16twpg4" title="Deploy as your own HF Space">Deploy</button> <div class="toolbar-divider svelte-16twpg4"></div> <button class="tool-btn svelte-16twpg4" title="Auto-arrange nodes">Layout</button> <button class="tool-btn svelte-16twpg4">Clear</button> <div class="toolbar-divider svelte-16twpg4"></div> <!></div></div> <div class="editor svelte-16twpg4"><!> <div role="application" tabindex="0"><div class="canvas-transform svelte-16twpg4"><!> <!></div> <!> <!> <div class="zoom-controls svelte-16twpg4"><button class="zoom-ctrl-btn svelte-16twpg4" title="Keyboard shortcuts">?</button> <button class="zoom-ctrl-btn svelte-16twpg4" title="Fit all (F)">&#x2922;</button> <button class="zoom-ctrl-btn svelte-16twpg4">−</button> <button class="zoom-btn svelte-16twpg4"> </button> <button class="zoom-ctrl-btn svelte-16twpg4">+</button></div> <!> <!></div></div> <!> <!></div>');
function xh(e, t) {
  Wt(t, !0);
  const n = () => Fi(Ot, "$workflow", r), [r, a] = Gi();
  var o = this && this.__awaiter || function(d, b, H, R) {
    function J($) {
      return $ instanceof H ? $ : new H(function(Q) {
        Q($);
      });
    }
    return new (H || (H = Promise))(function($, Q) {
      function te(le) {
        try {
          oe(R.next(le));
        } catch (ge) {
          Q(ge);
        }
      }
      function ee(le) {
        try {
          oe(R.throw(le));
        } catch (ge) {
          Q(ge);
        }
      }
      function oe(le) {
        le.done ? $(le.value) : J(le.value).then(te, ee);
      }
      oe((R = R.apply(d, b || [])).next());
    });
  }, s = this && this.__rest || function(d, b) {
    var H = {};
    for (var R in d) Object.prototype.hasOwnProperty.call(d, R) && b.indexOf(R) < 0 && (H[R] = d[R]);
    if (d != null && typeof Object.getOwnPropertySymbols == "function") for (var J = 0, R = Object.getOwnPropertySymbols(d); J < R.length; J++)
      b.indexOf(R[J]) < 0 && Object.prototype.propertyIsEnumerable.call(d, R[J]) && (H[R[J]] = d[R[J]]);
    return H;
  }, l;
  let u = ne(zt([])), c = ne(!0);
  function v() {
    return o(this, void 0, void 0, function* () {
      try {
        const d = yield fetch("https://huggingface.co/api/spaces?filter=gradio&limit=48&sort=trendingScore&direction=-1&expand[]=likes&expand[]=cardData&expand[]=runtime");
        if (!d.ok) throw new Error("Failed");
        const b = yield d.json();
        _(
          u,
          b.map((H) => {
            var R, J, $, Q, te, ee;
            const oe = ((R = H.cardData) === null || R === void 0 ? void 0 : R.short_description) || "";
            return {
              id: H.id,
              title: ((J = H.cardData) === null || J === void 0 ? void 0 : J.title) || H.id.split("/").pop() || H.id,
              description: oe,
              likes: ($ = H.likes) !== null && $ !== void 0 ? $ : 0,
              running: ((Q = H.runtime) === null || Q === void 0 ? void 0 : Q.stage) === "RUNNING",
              category: xo((te = H.cardData) === null || te === void 0 ? void 0 : te.pipeline_tag, (ee = H.cardData) === null || ee === void 0 ? void 0 : ee.tags, oe, H.id)
            };
          }).filter((H) => H.category !== null && H.running),
          !0
        );
      } catch {
        _(u, [], !0);
      } finally {
        _(c, !1);
      }
    });
  }
  function T(d) {
    var b;
    return {
      label: d.id.split("/").pop() || d.id,
      kind: "transform",
      source: "space",
      space_id: d.id,
      category: (b = d.category) !== null && b !== void 0 ? b : void 0,
      inputs: [],
      outputs: [],
      width: 280,
      height: 90
    };
  }
  typeof window < "u" && v();
  let f = Z(t, "server", 19, () => ({})), p = Z(t, "initialValue", 3, null);
  Jt(() => {
    if (p())
      try {
        const d = JSON.parse(p());
        d.nodes && d.edges && !localStorage.getItem("gradio_workflow") && (d.nodes = d.nodes.map((b) => {
          var H;
          return Object.assign(Object.assign({}, b), { data: (H = b.data) !== null && H !== void 0 ? H : {} });
        }), Ot.set(d));
      } catch {
      }
  });
  let C = ne(""), S = ne(!1), h = ne(zt(typeof localStorage < "u" && (l = localStorage.getItem("hf_token")) !== null && l !== void 0 ? l : ""));
  function g(d) {
    _(h, d.trim(), !0), typeof localStorage < "u" && (i(h) ? localStorage.setItem("hf_token", i(h)) : localStorage.removeItem("hf_token"));
  }
  function O() {
    return o(this, void 0, void 0, function* () {
      if (!(f() === null || f() === void 0) && f().get_token)
        try {
          return (yield f().get_token()) || "";
        } catch {
          return "";
        }
      return "";
    });
  }
  function m() {
    return o(this, void 0, void 0, function* () {
      if (_(S, window.location.hostname.endsWith(".hf.space"), !0), !i(S)) return;
      const d = yield O();
      if (d)
        try {
          const b = yield fetch("https://huggingface.co/api/whoami-v2", { headers: { Authorization: `Bearer ${d}` } });
          if (b.ok) {
            const H = yield b.json();
            _(C, H.name || "User", !0);
          }
        } catch {
          _(C, "User");
        }
      else
        _(C, "");
    });
  }
  function L() {
    const d = encodeURIComponent(window.location.pathname + window.location.search);
    window.location.assign(`/login/huggingface?_target_url=${d}`);
  }
  function A() {
    const d = encodeURIComponent(window.location.pathname + window.location.search);
    window.location.assign(`/logout?_target_url=${d}`);
  }
  Jt(() => {
    m();
  }), Jt(() => (window.addEventListener("keydown", G), () => window.removeEventListener("keydown", G)));
  const N = [
    {
      name: "not-lain/background-removal",
      desc: "Image → background removal → clean image",
      build: () => ({
        version: "1",
        name: "not-lain/background-removal",
        nodes: [
          {
            id: "t1",
            kind: "input",
            label: "Image",
            source: "local",
            inputs: [],
            outputs: [{ id: "out", label: "Image", type: "image" }],
            x: 80,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          },
          {
            id: "t2",
            kind: "transform",
            label: "Remove background",
            source: "space",
            space_id: "not-lain/background-removal",
            endpoint: "/image",
            inputs: [{ id: "in", label: "Image", type: "image", required: !0 }],
            outputs: [{ id: "out", label: "Image", type: "image" }],
            x: 420,
            y: 120,
            width: 200,
            height: 90,
            data: {}
          },
          {
            id: "t3",
            kind: "output",
            label: "Image",
            source: "local",
            inputs: [{ id: "in", label: "Image", type: "image" }],
            outputs: [{ id: "out", label: "Image", type: "image" }],
            x: 740,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          }
        ],
        edges: [
          {
            id: "e1",
            from_node_id: "t1",
            from_port_id: "out",
            to_node_id: "t2",
            to_port_id: "in",
            type: "image"
          },
          {
            id: "e2",
            from_node_id: "t2",
            from_port_id: "out",
            to_node_id: "t3",
            to_port_id: "in",
            type: "image"
          }
        ]
      })
    },
    {
      name: "black-forest-labs/FLUX.1-schnell",
      desc: "Prompt → FLUX → generated image",
      build: () => ({
        version: "1",
        name: "black-forest-labs/FLUX.1-schnell",
        nodes: [
          {
            id: "t1",
            kind: "input",
            label: "Textbox",
            source: "local",
            inputs: [],
            outputs: [{ id: "out", label: "Text", type: "text" }],
            x: 80,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          },
          {
            id: "t2",
            kind: "transform",
            label: "Generate image",
            source: "space",
            space_id: "black-forest-labs/FLUX.1-schnell",
            inputs: [{ id: "in", label: "Prompt", type: "text", required: !0 }],
            outputs: [{ id: "out", label: "Image", type: "image" }],
            x: 420,
            y: 120,
            width: 200,
            height: 90,
            data: {}
          },
          {
            id: "t3",
            kind: "output",
            label: "Image",
            source: "local",
            inputs: [{ id: "in", label: "Image", type: "image" }],
            outputs: [{ id: "out", label: "Image", type: "image" }],
            x: 740,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          }
        ],
        edges: [
          {
            id: "e1",
            from_node_id: "t1",
            from_port_id: "out",
            to_node_id: "t2",
            to_port_id: "in",
            type: "text"
          },
          {
            id: "e2",
            from_node_id: "t2",
            from_port_id: "out",
            to_node_id: "t3",
            to_port_id: "in",
            type: "image"
          }
        ]
      })
    },
    {
      name: "hf-audio/whisper-large-v3-turbo",
      desc: "Audio → Whisper → transcript text",
      build: () => ({
        version: "1",
        name: "hf-audio/whisper-large-v3-turbo",
        nodes: [
          {
            id: "t1",
            kind: "input",
            label: "Audio",
            source: "local",
            inputs: [],
            outputs: [{ id: "out", label: "Audio", type: "audio" }],
            x: 80,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          },
          {
            id: "t2",
            kind: "transform",
            label: "Transcribe",
            source: "space",
            space_id: "hf-audio/whisper-large-v3-turbo",
            inputs: [{ id: "in", label: "Audio", type: "audio", required: !0 }],
            outputs: [{ id: "out", label: "Text", type: "text" }],
            x: 420,
            y: 120,
            width: 200,
            height: 90,
            data: {}
          },
          {
            id: "t3",
            kind: "output",
            label: "Textbox",
            source: "local",
            inputs: [{ id: "in", label: "Text", type: "text" }],
            outputs: [{ id: "out", label: "Text", type: "text" }],
            x: 740,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          }
        ],
        edges: [
          {
            id: "e1",
            from_node_id: "t1",
            from_port_id: "out",
            to_node_id: "t2",
            to_port_id: "in",
            type: "audio"
          },
          {
            id: "e2",
            from_node_id: "t2",
            from_port_id: "out",
            to_node_id: "t3",
            to_port_id: "in",
            type: "text"
          }
        ]
      })
    },
    {
      name: "vikhyatk/moondream1",
      desc: "Image → caption → text description",
      build: () => ({
        version: "1",
        name: "vikhyatk/moondream1",
        nodes: [
          {
            id: "t1",
            kind: "input",
            label: "Image",
            source: "local",
            inputs: [],
            outputs: [{ id: "out", label: "Image", type: "image" }],
            x: 80,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          },
          {
            id: "t2",
            kind: "transform",
            label: "Describe image",
            source: "space",
            space_id: "vikhyatk/moondream1",
            inputs: [{ id: "in", label: "Image", type: "image", required: !0 }],
            outputs: [{ id: "out", label: "Caption", type: "text" }],
            x: 420,
            y: 120,
            width: 200,
            height: 90,
            data: {}
          },
          {
            id: "t3",
            kind: "output",
            label: "Textbox",
            source: "local",
            inputs: [{ id: "in", label: "Text", type: "text" }],
            outputs: [{ id: "out", label: "Text", type: "text" }],
            x: 740,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          }
        ],
        edges: [
          {
            id: "e1",
            from_node_id: "t1",
            from_port_id: "out",
            to_node_id: "t2",
            to_port_id: "in",
            type: "image"
          },
          {
            id: "e2",
            from_node_id: "t2",
            from_port_id: "out",
            to_node_id: "t3",
            to_port_id: "in",
            type: "text"
          }
        ]
      })
    }
  ];
  function q(d) {
    return o(this, void 0, void 0, function* () {
      V(n().nodes);
      const b = d.build();
      Ot.set(b), ue(), Ge(`Loading "${d.name}"...`);
      const H = b.nodes.filter(($) => $.source === "space" && $.space_id), R = yield Promise.allSettled(H.map(($) => o(this, void 0, void 0, function* () {
        const Q = yield ma($.space_id);
        return { nodeId: $.id, apiInfo: Q };
      })));
      Ot.update(($) => Object.assign(Object.assign({}, $), {
        nodes: $.nodes.map((Q) => {
          const te = R.find((ee) => ee.status === "fulfilled" && ee.value.nodeId === Q.id);
          if (te && te.status === "fulfilled") {
            const { apiInfo: ee } = te.value;
            return Object.assign(Object.assign({}, Q), {
              inputs: ee.inputs,
              outputs: ee.outputs,
              endpoint: ee.endpoint,
              width: ee.width
            });
          }
          return Q;
        }),
        // Remap edges to use new port IDs
        edges: $.edges.map((Q) => {
          const te = R.find((le) => le.status === "fulfilled" && le.value.nodeId === Q.from_node_id), ee = R.find((le) => le.status === "fulfilled" && le.value.nodeId === Q.to_node_id);
          let oe = Object.assign({}, Q);
          if (te && te.status === "fulfilled") {
            const le = te.value.apiInfo.outputs[0];
            le && oe.from_port_id === "out" && (oe = Object.assign(Object.assign({}, oe), { from_port_id: le.id }));
          }
          if (ee && ee.status === "fulfilled") {
            const le = ee.value.apiInfo.inputs[0];
            le && oe.to_port_id === "in" && (oe = Object.assign(Object.assign({}, oe), { to_port_id: le.id }));
          }
          return oe;
        })
      })), R.filter(($) => $.status === "rejected").length > 0 ? Ge("Some Spaces could not be reached", 5e3, "warning") : Ge(`Loaded "${d.name}"`, 3e3, "success");
    });
  }
  let K, j = ne(null), de = ne(zt({ x: 0, y: 0 })), re = ne(!1), ce = null, _e = ne(zt({})), Pe = ne(zt({})), qe = ne(!1), Me = ne(null), Tt = ne(!1), rt = ne(!1), bt = ne(zt([])), Rt = 0, yt = ne(!1), Xe = ne(""), ye = ne(""), Fe = ne(""), Qe = ne(!1);
  function Ge(d, b = 3e3, H = "info") {
    const R = ++Rt;
    _(bt, [...i(bt), { id: R, message: d, type: H }].slice(-3), !0), b > 0 && setTimeout(
      () => {
        _(bt, i(bt).filter((J) => J.id !== R), !0);
      },
      b
    );
  }
  let Ae = ne(0), lt = ne(0), He = ne(1), Bt = ne(!1), Yt = { x: 0, y: 0, panX: 0, panY: 0 }, qt, $t = pe(() => n().nodes.length), cn = pe(() => n().nodes.some((d) => d.kind === "transform")), dn = pe(() => n().edges.length);
  function pn(d) {
    const b = K.getBoundingClientRect();
    return {
      x: (d.clientX - b.left - i(Ae)) / i(He),
      y: (d.clientY - b.top - i(lt)) / i(He)
    };
  }
  function en(d, b, H, R) {
    _(j, Object.assign({ from_node_id: d, from_port_id: b, type: H }, pn(R)), !0);
  }
  function fn(d, b, H) {
    if (!i(j)) return;
    if (!gn(i(j).type, H)) {
      _(j, null);
      return;
    }
    Kr({
      from_node_id: i(j).from_node_id,
      from_port_id: i(j).from_port_id,
      to_node_id: d,
      to_port_id: b,
      type: i(j).type
    }), _(j, null);
    const R = document.querySelector(`[data-port-id="${d}:${b}:input"]`);
    R && (R.classList.add("port-snap"), setTimeout(() => R.classList.remove("port-snap"), 400));
  }
  function gn(d, b) {
    return d === "any" || b === "any" || d === b;
  }
  function nn(d, b, H) {
    return o(this, void 0, void 0, function* () {
      if (d.source === "space" && d.space_id && d.inputs.length === 0) {
        Ge(`Connecting to ${d.space_id}...`);
        try {
          const R = yield ma(d.space_id);
          d.inputs = R.inputs, d.outputs = R.outputs, d.endpoint = R.endpoint, d.width = R.width;
        } catch (R) {
          Ge(R instanceof Error ? R.message : "Failed to connect to Space", 5e3, "error");
          return;
        }
      }
      if (b === void 0 || H === void 0) {
        const R = n().nodes;
        b = R.length > 0 ? Math.max(...R.map((J) => J.x + J.width)) + 80 : 200, H = R.length > 0 ? R[R.length - 1].y : 150;
      }
      _r(d, b, H);
    });
  }
  function ie(d) {
    return o(this, void 0, void 0, function* () {
      var b;
      d.preventDefault();
      const H = (b = d.dataTransfer) === null || b === void 0 ? void 0 : b.getData("node-template");
      if (!H) return;
      const R = JSON.parse(H), J = K.getBoundingClientRect(), $ = (d.clientX - J.left - i(Ae)) / i(He) - 100, Q = (d.clientY - J.top - i(lt)) / i(He) - 45;
      yield nn(R, $, Q);
    });
  }
  function V(d) {
    var b, H;
    for (const R of d)
      for (const J of Object.values((b = R.data) !== null && b !== void 0 ? b : {}))
        J && typeof J == "object" && "url" in J && (!((H = J.url) === null || H === void 0) && H.startsWith("blob:")) && URL.revokeObjectURL(J.url);
  }
  function we() {
    n().nodes.length !== 0 && confirm("Clear all nodes and edges?") && (V(n().nodes), Ot.set({ version: "1", name: n().name, nodes: [], edges: [] }));
  }
  function xe() {
    var d;
    const b = Ke(n().nodes, n().edges), H = n().edges, R = /* @__PURE__ */ new Map();
    for (const oe of b) {
      const le = H.filter((ge) => ge.to_node_id === oe.id).map((ge) => {
        var tt;
        return (tt = R.get(ge.from_node_id)) !== null && tt !== void 0 ? tt : 0;
      }).reduce((ge, tt) => Math.max(ge, tt + 1), 0);
      R.set(oe.id, le);
    }
    const J = /* @__PURE__ */ new Map();
    for (const oe of b) {
      const le = (d = R.get(oe.id)) !== null && d !== void 0 ? d : 0;
      J.has(le) || J.set(le, []), J.get(le).push(oe);
    }
    const $ = 30, Q = 80, te = [];
    let ee = 80;
    for (const [oe, le] of [...J.entries()].sort((ge, tt) => ge[0] - tt[0])) {
      let ge = 80, tt = 0;
      for (const gt of le)
        te.push(Object.assign(Object.assign({}, gt), { x: ee, y: ge })), ge += gt.height + $, tt = Math.max(tt, gt.width);
      ee += tt + Q;
    }
    Ot.update((oe) => Object.assign(Object.assign({}, oe), { nodes: te }));
  }
  function Ke(d, b) {
    var H, R;
    const J = new Map(d.map((te) => [te.id, 0]));
    for (const te of b) J.set(te.to_node_id, ((H = J.get(te.to_node_id)) !== null && H !== void 0 ? H : 0) + 1);
    const $ = d.filter((te) => J.get(te.id) === 0), Q = [];
    for (; $.length; ) {
      const te = $.shift();
      Q.push(te);
      for (const ee of b.filter((oe) => oe.from_node_id === te.id)) {
        const oe = ((R = J.get(ee.to_node_id)) !== null && R !== void 0 ? R : 1) - 1;
        J.set(ee.to_node_id, oe), oe === 0 && $.push(d.find((le) => le.id === ee.to_node_id));
      }
    }
    return Q;
  }
  function D() {
    return o(this, void 0, void 0, function* () {
      if (i(re)) return;
      _(re, !0), _(_e, {}, !0), _(Pe, {}, !0), ce = new AbortController();
      const d = yield O();
      n().nodes.some((Q) => Q.source === "space" && Q.space_id) && !d && Ge("Running as guest — GPU Spaces may hit quota limits. Sign in with HuggingFace for your own compute.", 5e3, "warning");
      const H = !(f() === null || f() === void 0) && f().call_space ? (Q, te, ee) => o(this, void 0, void 0, function* () {
        return f().call_space([Q, te, ee, i(h) || ""]);
      }) : void 0, R = !(f() === null || f() === void 0) && f().call_model ? (Q, te, ee) => o(this, void 0, void 0, function* () {
        return f().call_model([Q, te, ee, i(h) || ""]);
      }) : void 0, J = !(f() === null || f() === void 0) && f().fetch_dataset ? (Q, te, ee, oe, le) => o(this, void 0, void 0, function* () {
        return f().fetch_dataset([
          Q,
          te,
          ee,
          oe,
          le,
          i(h) || ""
        ]);
      }) : void 0;
      yield Tf(
        n(),
        (Q, te, ee, oe) => {
          var le, ge, tt;
          if (_(_e, Object.assign(Object.assign({}, i(_e)), { [Q]: te }), !0), ee) {
            _(Pe, Object.assign(Object.assign({}, i(Pe)), { [Q]: ee }), !0);
            const gt = n().nodes.find((Pn) => Pn.id === Q), bn = (tt = (ge = (le = gt?.label) !== null && le !== void 0 ? le : gt?.space_id) !== null && ge !== void 0 ? ge : gt?.model_id) !== null && tt !== void 0 ? tt : "Node";
            oe === "quota" || oe === "gpu" ? Ge(`${bn}: ${ee}`, 0, "error") : Ge(`${bn}: ${ee}`, 5e3, "error");
          }
        },
        (Q, te, ee) => {
          gi(Q, te, ee);
        },
        ce.signal,
        H,
        R,
        J
      ), _(re, !1), ce = null, Object.values(i(_e)).some((Q) => Q === "error") ? Ge("Workflow finished with errors", 5e3, "error") : Ge("Workflow complete", 3e3, "success"), setTimeout(
        () => {
          _(_e, Object.fromEntries(Object.entries(i(_e)).filter(([Q, te]) => te === "error")), !0);
        },
        3e3
      );
    });
  }
  function B() {
    ce?.abort(), _(re, !1), ce = null, _(_e, Object.fromEntries(Object.entries(i(_e)).map(([d, b]) => [d, b === "running" ? "idle" : b])), !0), Ge("Stopped", 3e3, "warning");
  }
  function y(d) {
    const b = d.target;
    i(Tt) && !b?.closest(".toolbar-dropdown-wrap") && _(Tt, !1), i(rt) && !b?.closest(".shortcuts-panel") && !b?.closest(".zoom-controls") && _(rt, !1);
  }
  function x(d) {
    var b;
    if (!((b = d.target) === null || b === void 0) && b.closest(".empty-state")) return;
    d.preventDefault();
    const H = K.getBoundingClientRect(), R = d.clientX - H.left, J = d.clientY - H.top, $ = 1 + Math.min(Math.abs(d.deltaY) * 1e-3, 0.05), Q = d.deltaY > 0 ? 1 / $ : $, te = Math.min(Math.max(i(He) * Q, 0.15), 4), ee = te / i(He);
    _(Ae, R - (R - i(Ae)) * ee), _(lt, J - (J - i(lt)) * ee), _(He, te, !0);
  }
  function E(d) {
    (d.button === 1 || d.button === 0 && d.target === K) && (d.preventDefault(), _(Me, null), _(Bt, !0), Yt = {
      x: d.clientX,
      y: d.clientY,
      panX: i(Ae),
      panY: i(lt)
    });
  }
  function U(d) {
    if (i(Bt) && (_(Ae, Yt.panX + (d.clientX - Yt.x)), _(lt, Yt.panY + (d.clientY - Yt.y))), i(j)) {
      _(j, Object.assign(Object.assign({}, i(j)), pn(d)), !0);
      const b = K.getBoundingClientRect();
      _(de, { x: d.clientX - b.left, y: d.clientY - b.top }, !0);
    }
  }
  function X(d) {
    _(Bt, !1), _(j, null);
  }
  function ue() {
    _(Ae, 0), _(lt, 0), _(He, 1);
  }
  function fe() {
    const d = n().nodes;
    if (d.length === 0) {
      ue();
      return;
    }
    const b = 60, H = Math.min(...d.map((ge) => ge.x)), R = Math.min(...d.map((ge) => ge.y)), J = Math.max(...d.map((ge) => ge.x + ge.width)), $ = Math.max(...d.map((ge) => ge.y + ge.height)), Q = J - H + b * 2, te = $ - R + b * 2;
    if (!K) {
      ue();
      return;
    }
    const ee = K.getBoundingClientRect(), oe = ee.width / Q, le = ee.height / te;
    _(He, Math.min(Math.max(Math.min(oe, le), 0.15), 2), !0), _(Ae, (ee.width - Q * i(He)) / 2 - (H - b) * i(He)), _(lt, (ee.height - te * i(He)) / 2 - (R - b) * i(He));
  }
  function Ve(d) {
    _(Me, d, !0);
  }
  function he(d) {
    const b = n().nodes.find((Q) => Q.id === d);
    if (!b) return;
    const { id: H, data: R } = b, J = s(b, ["id", "data"]), $ = _r(J, b.x + 40, b.y + 40);
    _(Me, $, !0);
  }
  function G(d) {
    var b;
    if (d.key === "s" && (d.metaKey || d.ctrlKey)) {
      d.preventDefault(), Ce();
      return;
    }
    if (d.key === "Enter" && (d.metaKey || d.ctrlKey) && !i(re) && i(cn)) {
      d.preventDefault(), D();
      return;
    }
    const H = (b = d.target) === null || b === void 0 ? void 0 : b.tagName;
    if (!(H === "INPUT" || H === "TEXTAREA" || H === "SELECT")) {
      if ((d.key === "Delete" || d.key === "Backspace") && i(Me)) {
        d.preventDefault();
        const R = i(Me);
        _(Me, null), requestAnimationFrame(() => pi(R));
      }
      d.key === "d" && (d.metaKey || d.ctrlKey) && i(Me) && (d.preventDefault(), he(i(Me))), d.key === "f" && !d.metaKey && !d.ctrlKey && (d.preventDefault(), fe()), d.key === "0" && (d.metaKey || d.ctrlKey) && (d.preventDefault(), ue()), d.key === "Escape" && (_(Me, null), _(j, null));
    }
  }
  let De = pe(() => () => {
    const d = /* @__PURE__ */ new Set();
    for (const b of n().edges)
      d.add(`${b.from_node_id}:${b.from_port_id}:output`), d.add(`${b.to_node_id}:${b.to_port_id}:input`);
    return d;
  });
  function Ne(d, b, H, R) {
    var J;
    const $ = n().nodes.find((ee) => ee.id === d);
    if (!$) return;
    const Q = H === "any" ? "text" : H, te = (J = Cr.components.find((ee) => {
      var oe;
      return ((oe = ee.outputs[0]) === null || oe === void 0 ? void 0 : oe.type) === Q;
    })) !== null && J !== void 0 ? J : Cr.components[0];
    if (R === "input") {
      const ee = _r(te, $.x - te.width - 80, $.y);
      Kr({
        from_node_id: ee,
        from_port_id: te.outputs[0].id,
        to_node_id: d,
        to_port_id: b,
        type: Q
      });
    } else {
      const ee = _r(te, $.x + $.width + 80, $.y);
      Kr({
        from_node_id: d,
        from_port_id: b,
        to_node_id: ee,
        to_port_id: te.inputs[0].id,
        type: Q
      });
    }
  }
  function Ce() {
    const d = JSON.stringify(n(), null, 2), b = new Blob([d], { type: "application/json" }), H = URL.createObjectURL(b), R = document.createElement("a");
    R.href = H, R.download = `${n().name.replace(/[^a-zA-Z0-9_-]/g, "_")}.workflow.json`, R.click(), URL.revokeObjectURL(H), Ge("Exported workflow.json");
  }
  function ke() {
    const d = document.createElement("input");
    d.type = "file", d.accept = ".json", d.onchange = () => o(this, void 0, void 0, function* () {
      var b;
      const H = (b = d.files) === null || b === void 0 ? void 0 : b[0];
      if (H)
        try {
          const R = yield H.text(), J = JSON.parse(R);
          J.nodes && J.edges && (V(n().nodes), J.nodes = J.nodes.map(($) => {
            var Q;
            return Object.assign(Object.assign({}, $), { data: (Q = $.data) !== null && Q !== void 0 ? Q : {} });
          }), Ot.set(J), Ge("Imported workflow"));
        } catch {
        }
    }), d.click();
  }
  function me() {
    _(Xe, n().name.replace(/[^a-zA-Z0-9_-]/g, "-").toLowerCase() || "my-workflow", !0), _(ye, ""), _(Fe, ""), _(Qe, !1), _(yt, !0);
  }
  function Ze() {
    return o(this, void 0, void 0, function* () {
      var d;
      const b = i(S) ? yield O() : i(h);
      if (!b) {
        _(ye, "Sign in first to deploy.");
        return;
      }
      _(Qe, !0), _(Fe, "");
      try {
        const H = yield Kf(n(), b, i(Xe), (R) => {
          _(ye, R, !0);
        });
        _(Fe, H, !0);
      } catch (H) {
        _(ye, `Error: ${(d = H.message) !== null && d !== void 0 ? d : String(H)}`);
      } finally {
        _(Qe, !1);
      }
    });
  }
  function dt(d) {
    Ot.update((b) => Object.assign(Object.assign({}, b), { name: d })), _(qe, !1);
  }
  var Pt = wh(), Mt = k(Pt), ft = k(Mt), Dt = k(ft);
  {
    var Ut = (d) => {
      var b = $f();
      ln(b, (H) => qt = H, () => qt), F(() => vn(b, n().name)), Oe("blur", b, (H) => dt(H.currentTarget.value)), z("keydown", b, (H) => {
        H.key === "Enter" && dt(H.currentTarget.value), H.key === "Escape" && _(qe, !1);
      }), w(d, b);
    }, rn = (d) => {
      var b = eh(), H = k(b), R = k(H);
      F(() => Y(R, n().name)), z("click", b, () => {
        _(qe, !0), requestAnimationFrame(() => qt?.focus());
      }), w(d, b);
    };
    W(Dt, (d) => {
      i(qe) ? d(Ut) : d(rn, -1);
    });
  }
  var Je = I(Dt, 2), ve = k(Je), Ee = I(ft, 2), mt = k(Ee);
  {
    var Ye = (d) => {
      var b = Et(), H = be(b);
      {
        var R = ($) => {
          var Q = th(), te = be(Q), ee = I(k(te)), oe = k(ee), le = I(te, 2);
          F(() => Y(oe, i(C))), z("click", le, A), w($, Q);
        }, J = ($) => {
          var Q = nh();
          z("click", Q, L), w($, Q);
        };
        W(H, ($) => {
          i(C) ? $(R) : $(J, -1);
        });
      }
      w(d, b);
    }, at = (d) => {
      var b = rh(), H = k(b);
      F(() => vn(H, i(h))), Oe("submit", b, (R) => R.preventDefault()), z("change", H, (R) => g(R.currentTarget.value)), w(d, b);
    };
    W(mt, (d) => {
      i(S) ? d(Ye) : d(at, -1);
    });
  }
  var ht = I(mt, 2), $e = I(ht, 2), it = I($e, 2), Ht = I(it, 4), et = I(Ht, 2), Ue = I(et, 4);
  {
    var Te = (d) => {
      var b = ah();
      z("click", b, B), w(d, b);
    }, Se = (d) => {
      var b = ih();
      F(() => b.disabled = !i(cn)), z("click", b, D), w(d, b);
    };
    W(Ue, (d) => {
      i(re) ? d(Te) : d(Se, -1);
    });
  }
  var Re = I(Mt, 2), ae = k(Re);
  xf(ae, { onadd: (d) => nn(d) });
  var se = I(ae, 2);
  let ot;
  var je = k(se), ut = k(je);
  _t(ut, 1, () => n().nodes, (d) => d.id, (d, b) => {
    {
      let H = pe(() => i(De)()), R = pe(() => i(_e)[i(b).id] ?? "idle"), J = pe(() => i(Pe)[i(b).id] ?? ""), $ = pe(() => i(Me) === i(b).id);
      Od(d, {
        get node() {
          return i(b);
        },
        get pending() {
          return i(j);
        },
        onstartconnection: en,
        oncompleteconnection: fn,
        get onmove() {
          return Du;
        },
        get ondatachange() {
          return gi;
        },
        get onremove() {
          return pi;
        },
        onautoconnect: Ne,
        get connectedPorts() {
          return i(H);
        },
        get status() {
          return i(R);
        },
        get error() {
          return i(J);
        },
        get zoom() {
          return i(He);
        },
        get selected() {
          return i($);
        },
        onselect: Ve
      });
    }
  });
  var ze = I(ut, 2);
  Nd(ze, {
    get pending() {
      return i(j);
    },
    get onremove() {
      return Uu;
    },
    get zoom() {
      return i(He);
    },
    get panX() {
      return i(Ae);
    },
    get panY() {
      return i(lt);
    }
  });
  var vt = I(je, 2);
  {
    var Nt = (d) => {
      var b = oh();
      w(d, b);
    };
    W(vt, (d) => {
      i(re) && d(Nt);
    });
  }
  var St = I(vt, 2);
  {
    var wt = (d) => {
      var b = fh(), H = I(k(b), 4);
      _t(H, 21, () => N, Lt, (te, ee) => {
        var oe = sh(), le = k(oe), ge = k(le), tt = I(le, 2), gt = k(tt);
        F(() => {
          Y(ge, i(ee).name), Y(gt, i(ee).desc);
        }), z("click", oe, () => q(i(ee))), w(te, oe);
      });
      var R = I(H, 2), J = I(k(R), 2);
      {
        var $ = (te) => {
          var ee = lh();
          w(te, ee);
        }, Q = (te) => {
          var ee = Et(), oe = be(ee);
          _t(oe, 17, () => wo, Lt, (le, ge) => {
            const tt = pe(() => i(u).filter((Tn) => Tn.category === i(ge).key));
            var gt = Et(), bn = be(gt);
            {
              var Pn = (Tn) => {
                var pr = dh(), Hn = be(pr), Xn = k(Hn), Dr = I(Hn, 2);
                _t(Dr, 21, () => i(tt).slice(0, 4), Lt, (Sn, an) => {
                  var Zn = ch(), Ra = k(Zn), Ba = k(Ra);
                  let Ma;
                  var Da = I(Ba, 2), Ao = k(Da), Io = I(Da, 2), Oo = k(Io), Ua = I(Ra, 2);
                  {
                    var Co = (Ur) => {
                      var ja = uh(), Ho = k(ja);
                      F(() => Y(Ho, i(an).description)), w(Ur, ja);
                    };
                    W(Ua, (Ur) => {
                      i(an).description && Ur(Co);
                    });
                  }
                  var Lo = I(Ua, 2), Po = k(Lo);
                  F(() => {
                    Ma = We(Ba, 1, "trending-dot svelte-16twpg4", null, Ma, { "trending-dot-running": i(an).running }), Y(Ao, i(an).title), Y(Oo, `♥ ${i(an).likes ?? ""}`), Y(Po, i(an).id);
                  }), z("click", Zn, () => nn(T(i(an)))), w(Sn, Zn);
                }), F(() => Y(Xn, i(ge).label)), w(Tn, pr);
              };
              W(bn, (Tn) => {
                i(tt).length > 0 && Tn(Pn);
              });
            }
            w(le, gt);
          }), w(te, ee);
        };
        W(J, (te) => {
          i(c) ? te($) : i(u).length > 0 && te(Q, 1);
        });
      }
      w(d, b);
    };
    W(St, (d) => {
      i($t) === 0 && d(wt);
    });
  }
  var At = I(St, 2), pt = k(At), It = I(pt, 2), Xt = I(It, 2), Kt = I(Xt, 2), Ct = k(Kt), Zt = I(Kt, 2), mn = I(At, 2);
  {
    var _n = (d) => {
      var b = hh();
      w(d, b);
    };
    W(mn, (d) => {
      i(rt) && d(_n);
    });
  }
  var jt = I(mn, 2);
  {
    var hn = (d) => {
      var b = vh(), H = k(b);
      F(() => {
        kt(b, `left: ${i(de).x + 14}px; top: ${i(de).y - 10}px; --badge-color: ${nt[i(j).type] ?? ""}`), Y(H, i(j).type);
      }), w(d, b);
    };
    W(jt, (d) => {
      i(j) && d(hn);
    });
  }
  ln(se, (d) => K = d, () => K);
  var Ft = I(Re, 2);
  {
    var fr = (d) => {
      var b = gh();
      _t(b, 21, () => i(bt), (H) => H.id, (H, R) => {
        var J = ph(), $ = k(J);
        F(() => {
          We(J, 1, `wf-toast wf-toast-${i(R).type ?? ""}`, "svelte-16twpg4"), Y($, i(R).message);
        }), w(H, J);
      }), w(d, b);
    };
    W(Ft, (d) => {
      i(bt).length > 0 && d(fr);
    });
  }
  var hr = I(Ft, 2);
  {
    var vr = (d) => {
      var b = yh(), H = k(b), R = k(H), J = I(k(R), 2), $ = I(R, 2), Q = k($);
      {
        var te = (oe) => {
          var le = _h(), ge = I(be(le), 2), tt = I(ge, 2), gt = I(k(tt)), bn = k(gt), Pn = I(tt, 2);
          {
            var Tn = (Sn) => {
              var an = mh(), Zn = k(an);
              F(() => Y(Zn, i(ye))), w(Sn, an);
            };
            W(Pn, (Sn) => {
              i(ye) && Sn(Tn);
            });
          }
          var pr = I(Pn, 2), Hn = k(pr), Xn = I(Hn, 2), Dr = k(Xn);
          F(() => {
            ge.disabled = i(Qe), Y(bn, `huggingface.co/spaces/you/${(i(Xe) || "my-workflow") ?? ""}`), Hn.disabled = i(Qe), Xn.disabled = i(Qe) || !i(Xe), Y(Dr, i(Qe) ? i(ye) || "Deploying…" : "Deploy");
          }), tr(ge, () => i(Xe), (Sn) => _(Xe, Sn)), z("click", Hn, () => _(yt, !1)), z("click", Xn, Ze), w(oe, le);
        }, ee = (oe) => {
          var le = bh(), ge = I(be(le), 2), tt = k(ge), gt = I(ge, 2), bn = k(gt);
          F(() => {
            M(ge, "href", i(Fe)), Y(tt, i(Fe));
          }), z("click", bn, () => _(yt, !1)), w(oe, le);
        };
        W(Q, (oe) => {
          i(Fe) ? oe(ee, -1) : oe(te);
        });
      }
      z("click", b, () => {
        i(Qe) || _(yt, !1);
      }), z("click", H, (oe) => oe.stopPropagation()), z("click", J, () => {
        i(Qe) || _(yt, !1);
      }), w(d, b);
    };
    W(hr, (d) => {
      i(yt) && d(vr);
    });
  }
  F(
    (d) => {
      Y(ve, `${i($t) ?? ""} nodes · ${i(dn) ?? ""} edges`), ot = We(se, 1, "canvas svelte-16twpg4", null, ot, { panning: i(Bt) }), kt(se, `--zoom: ${i(He) ?? ""}; --pan-x: ${i(Ae) ?? ""}px; --pan-y: ${i(lt) ?? ""}px`), kt(je, `transform: translate(${i(Ae) ?? ""}px, ${i(lt) ?? ""}px) scale(${i(He) ?? ""})`), Y(Ct, `${d ?? ""}%`);
    },
    [() => Math.round(i(He) * 100)]
  ), z("click", Pt, y), z("click", ht, Ce), z("click", $e, ke), z("click", it, me), z("click", Ht, xe), z("click", et, we), Oe("dragover", se, (d) => d.preventDefault()), Oe("drop", se, ie), Oe("wheel", se, x), z("mousedown", se, E), z("mousemove", se, U), z("mouseup", se, X), z("keydown", se, G), z("click", pt, () => _(rt, !i(rt))), z("click", It, fe), z("click", Xt, () => {
    _(He, Math.max(0.15, i(He) / 1.2), !0);
  }), z("click", Kt, ue), z("click", Zt, () => {
    _(He, Math.min(4, i(He) * 1.2), !0);
  }), w(e, Pt), Vt(), a();
}
un([
  "click",
  "keydown",
  "change",
  "mousedown",
  "mousemove",
  "mouseup"
]);
var kh = /* @__PURE__ */ P('<div class="workflow-fullscreen svelte-r41nsf"><!></div>');
function Sh(e, t) {
  Wt(t, !0);
  var n, r, a;
  let o = /* @__PURE__ */ Qs(t, ["$$slots", "$$events", "$$legacy"]);
  const s = new Ru(o);
  let l = pe(() => (r = (n = s.shared) === null || n === void 0 ? void 0 : n.server) !== null && r !== void 0 ? r : {}), u = pe(() => (a = s.value) !== null && a !== void 0 ? a : null);
  var c = kh(), v = k(c);
  xh(v, {
    get server() {
      return i(l);
    },
    get initialValue() {
      return i(u);
    }
  }), w(e, c), Vt();
}
export {
  Sh as default
};
