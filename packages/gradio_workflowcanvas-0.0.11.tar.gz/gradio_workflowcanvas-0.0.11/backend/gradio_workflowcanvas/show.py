from __future__ import annotations

import json
import os
import tempfile
from typing import Optional


def show(workflow_file: str | None = None) -> None:
    """Launch the workflow canvas app.

    Looks for workflow.json next to the calling script (or at workflow_file)
    and passes it as the initial canvas state.

    Args:
        workflow_file: Path to a workflow JSON file. Defaults to workflow.json
            in the same directory as the calling script.
    """
    import gradio as gr
    from gradio.oauth import OAuthToken
    from gradio_client import Client, handle_file

    from gradio_workflowcanvas import WorkflowCanvas

    if workflow_file is None:
        import inspect
        frame = inspect.stack()[1]
        caller_dir = os.path.dirname(os.path.abspath(frame.filename))
        workflow_file = os.path.join(caller_dir, "workflow.json")

    initial_workflow: str | None = None
    if os.path.exists(workflow_file):
        with open(workflow_file, encoding="utf-8") as f:
            initial_workflow = f.read()

    def get_token(data=None, token: Optional[OAuthToken] = None) -> str:
        if token is None:
            return ""
        return token.token

    def _classify_error(e: Exception) -> dict:
        title = getattr(e, "title", None) or ""
        message = getattr(e, "message", None) or str(e)
        full = f"{title} {message}".lower()
        if "zerogpu" in full or ("gpu" in full and "worker" in full):
            return {"error_type": "gpu", "suggestion": "GPU unavailable — try again or log in with your HF account"}
        if "quota" in full or "rate limit" in full:
            return {"error_type": "quota", "suggestion": "GPU quota exceeded — log in with your HF account for more compute"}
        if "sleeping" in full or "paused" in full:
            return {"error_type": "sleeping", "suggestion": "Space is sleeping or paused — try again in a minute"}
        if "api_key" in full or "api key" in full or "unauthorized" in full or "401" in full or "authentication" in full or "log in" in full:
            return {"error_type": "auth", "suggestion": "Sign in with your HF account to use this model"}
        if "not found" in full or "404" in full or "repository not found" in full:
            return {"error_type": "not_found", "suggestion": "Space not found — it may have been deleted or renamed"}
        if "build_error" in full or "build error" in full:
            return {"error_type": "build_error", "suggestion": "Space has a build error — contact the Space owner"}
        if "timed out" in full or "timeout" in full or "connection" in full:
            return {"error_type": "connection", "suggestion": "Could not connect to the Space — it may be down"}
        return {"error_type": "unknown", "suggestion": ""}

    def call_space(data, token: Optional[OAuthToken] = None) -> str:
        try:
            import re
            space_id = data[0]
            endpoint = data[1] if len(data) > 1 else None
            args_json = data[2] if len(data) > 2 else "[]"
            manual_token = data[3] if len(data) > 3 else None
            if not re.fullmatch(r"[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+", space_id or ""):
                return json.dumps({"error": "Invalid Space ID", "error_type": "not_found", "suggestion": "Space ID must be in owner/repo format"})
            hf_token = manual_token or (token.token if token else None)
            client = Client(space_id, token=hf_token)
            args = json.loads(args_json)
            if not endpoint or endpoint == "/predict":
                api_info = client.view_api(return_format="dict")
                named = list(api_info.get("named_endpoints", {}).keys())
                if endpoint and endpoint in named:
                    pass
                elif named:
                    endpoint = named[0]
                else:
                    endpoint = "/predict"
            processed = []
            for arg in args:
                if arg is None:
                    processed.append(None)
                elif isinstance(arg, dict) and ("url" in arg or "path" in arg):
                    url = arg.get("url") or arg.get("path", "")
                    processed.append(handle_file(url) if url else None)
                else:
                    processed.append(arg)
            while processed and processed[-1] is None:
                processed.pop()
            result = client.predict(*processed, api_name=endpoint)
            if not isinstance(result, (list, tuple)):
                result = [result]
            else:
                result = list(result)

            def make_file_url(filepath: str) -> dict:
                return {"path": filepath, "url": f"/gradio_api/file={filepath}", "is_file": True}

            def process_item(item):
                if isinstance(item, dict):
                    path = item.get("path") or item.get("value")
                    if isinstance(path, str) and os.path.exists(path):
                        return make_file_url(path)
                    return item
                if isinstance(item, str) and os.path.exists(item):
                    return make_file_url(item)
                if isinstance(item, (list, tuple)):
                    return [process_item(s) for s in item]
                return item

            return json.dumps([process_item(i) for i in result])
        except Exception as e:
            title = getattr(e, "title", None)
            message = getattr(e, "message", None) or str(e)
            classified = _classify_error(e)
            if classified.get("error_type") == "auth":
                message = "Authentication required"
                title = None
            err = {"error": message, **classified}
            if title:
                err["title"] = title
            return json.dumps(err)

    def call_model(data, token: Optional[OAuthToken] = None) -> str:
        try:
            from huggingface_hub import InferenceClient
            model_id = data[0]
            pipeline_tag = data[1] if len(data) > 1 else None
            args_json = data[2] if len(data) > 2 else "[]"
            manual_token = data[3] if len(data) > 3 else None
            hf_token = manual_token or (token.token if token else None)
            client = InferenceClient(model=model_id, token=hf_token)
            args = json.loads(args_json)
            task = pipeline_tag or "text-generation"
            if task in ("text-generation", "text2text-generation", "conversational"):
                try:
                    result = client.text_generation(args[0] if args else "", max_new_tokens=512)
                except Exception as inner:
                    msg = str(inner).lower()
                    if "not supported" in msg and "conversational" in msg:
                        r = client.chat_completion([{"role": "user", "content": args[0] if args else ""}], max_tokens=512)
                        result = r.choices[0].message.content
                    else:
                        raise
                return json.dumps([result])
            if task == "summarization":
                return json.dumps([client.summarization(args[0] if args else "").summary_text])
            if task == "translation":
                return json.dumps([client.translation(args[0] if args else "").translation_text])
            if task in ("text-classification", "zero-shot-classification"):
                return json.dumps([[{"label": r.label, "score": r.score} for r in client.text_classification(args[0] if args else "")]])
            if task == "token-classification":
                return json.dumps([[{"entity_group": r.entity_group, "word": r.word, "score": r.score} for r in client.token_classification(args[0] if args else "")]])
            if task == "fill-mask":
                return json.dumps([[{"token_str": r.token_str, "score": r.score, "sequence": r.sequence} for r in client.fill_mask(args[0] if args else "")]])
            if task == "question-answering":
                r = client.question_answering(question=args[0] if args else "", context=args[1] if len(args) > 1 else "")
                return json.dumps([r.answer])
            if task == "feature-extraction":
                r = client.feature_extraction(args[0] if args else "")
                return json.dumps([r.tolist() if hasattr(r, "tolist") else r])
            if task == "sentence-similarity":
                sentences = args[1].split("\n") if len(args) > 1 and args[1] else []
                return json.dumps([client.sentence_similarity(args[0] if args else "", sentences)])
            if task == "text-to-image":
                img = client.text_to_image(args[0] if args else "")
                path = os.path.join(tempfile.gettempdir(), f"hf_model_{os.urandom(8).hex()}.png")
                img.save(path)
                return json.dumps([{"path": path, "url": f"/gradio_api/file={path}", "is_file": True}])
            if task in ("text-to-speech", "text-to-audio"):
                audio = client.text_to_speech(args[0] if args else "")
                path = os.path.join(tempfile.gettempdir(), f"hf_model_{os.urandom(8).hex()}.wav")
                with open(path, "wb") as f:
                    f.write(audio)
                return json.dumps([{"path": path, "url": f"/gradio_api/file={path}", "is_file": True}])
            if task == "text-to-video":
                video = client.text_to_video(args[0] if args else "")
                path = os.path.join(tempfile.gettempdir(), f"hf_model_{os.urandom(8).hex()}.mp4")
                with open(path, "wb") as f:
                    f.write(video)
                return json.dumps([{"path": path, "url": f"/gradio_api/file={path}", "is_file": True}])

            def _img_url(a):
                return a.get("url") or a.get("path", "") if isinstance(a, dict) else a

            if task == "image-classification":
                return json.dumps([[{"label": r.label, "score": r.score} for r in client.image_classification(_img_url(args[0] if args else ""))]])
            if task == "object-detection":
                return json.dumps([[{"label": r.label, "score": r.score, "box": r.box} for r in client.object_detection(_img_url(args[0] if args else ""))]])
            if task == "image-segmentation":
                return json.dumps([[{"label": r.label, "score": r.score} for r in client.image_segmentation(_img_url(args[0] if args else ""))]])
            if task == "image-to-text":
                r = client.image_to_text(_img_url(args[0] if args else ""))
                return json.dumps([r.generated_text if hasattr(r, "generated_text") else str(r)])
            if task == "image-to-image":
                img = client.image_to_image(_img_url(args[0] if args else ""), prompt=args[1] if len(args) > 1 else "")
                path = os.path.join(tempfile.gettempdir(), f"hf_model_{os.urandom(8).hex()}.png")
                img.save(path)
                return json.dumps([{"path": path, "url": f"/gradio_api/file={path}", "is_file": True}])
            if task == "automatic-speech-recognition":
                r = client.automatic_speech_recognition(_img_url(args[0] if args else ""))
                return json.dumps([r.text if hasattr(r, "text") else str(r)])
            if task == "audio-classification":
                return json.dumps([[{"label": r.label, "score": r.score} for r in client.audio_classification(_img_url(args[0] if args else ""))]])
            if task in ("visual-question-answering", "document-question-answering", "image-text-to-text"):
                r = client.visual_question_answering(_img_url(args[0] if args else ""), args[1] if len(args) > 1 else "")
                return json.dumps([r[0].answer if r else ""])
            if task == "depth-estimation":
                r = client.depth_estimation(_img_url(args[0] if args else ""))
                path = os.path.join(tempfile.gettempdir(), f"hf_model_{os.urandom(8).hex()}.png")
                r.depth.save(path)
                return json.dumps([{"path": path, "url": f"/gradio_api/file={path}", "is_file": True}])
            return json.dumps({"error": f"Unsupported task: {task}", "error_type": "unknown", "suggestion": ""})
        except Exception as e:
            title = getattr(e, "title", None)
            message = getattr(e, "message", None) or str(e)
            classified = _classify_error(e)
            if classified.get("error_type") == "auth":
                message = "Authentication required"
                title = None
            err = {"error": message, **classified}
            if title:
                err["title"] = title
            return json.dumps(err)

    def fetch_dataset(data, token: Optional[OAuthToken] = None) -> str:
        try:
            import urllib.parse
            import urllib.request
            dataset_id = data[0]
            config = data[1] if len(data) > 1 and data[1] else "default"
            split = data[2] if len(data) > 2 and data[2] else "train"
            offset = int(data[3]) if len(data) > 3 and data[3] else 0
            length = int(data[4]) if len(data) > 4 and data[4] else 10
            params = urllib.parse.urlencode({
                "dataset": dataset_id, "config": config, "split": split,
                "offset": offset, "length": min(length, 100),
            })
            req = urllib.request.Request(f"https://datasets-server.huggingface.co/rows?{params}")
            manual_token = data[5] if len(data) > 5 else None
            hf_token = manual_token or (token.token if token else None)
            if hf_token:
                req.add_header("Authorization", f"Bearer {hf_token}")
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read().decode())
            return json.dumps({
                "features": result.get("features", []),
                "rows": [r.get("row", {}) for r in result.get("rows", [])],
                "num_rows_total": result.get("num_rows_total", 0),
            })
        except Exception as e:
            return json.dumps({"error": str(e), "error_type": "unknown", "suggestion": ""})

    with gr.Blocks() as demo:
        gr.LoginButton(visible=False)
        WorkflowCanvas(
            value=initial_workflow,
            server_functions=[get_token, call_space, call_model, fetch_dataset],
        )

    demo.launch(allowed_paths=[tempfile.gettempdir()])
