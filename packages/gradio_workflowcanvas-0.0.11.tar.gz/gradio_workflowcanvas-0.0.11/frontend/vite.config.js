import { defineConfig } from 'vite';
import { svelte } from 'vite-plugin-svelte';

export default defineConfig({
  plugins: [svelte()],
  build: {
    lib: {
      entry: 'Index.svelte',
      name: 'WorkflowCanvas',
      fileName: 'index',
      formats: ['es']
    },
    outDir: 'dist',
    target: 'es2020'
  }
});
