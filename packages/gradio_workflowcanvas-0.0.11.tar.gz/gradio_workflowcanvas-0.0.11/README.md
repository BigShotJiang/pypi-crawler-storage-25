---
title: Workflow
app_file: app.py
sdk: gradio
sdk_version: 6.12.0
hf_oauth: true
hf_oauth_scopes:
- inference-api
- write-repos
---

# Workflow

Build and run AI pipelines. 
