import gradio as gr
from gradio.oauth import OAuthToken
from gradio_workflowcanvas import WorkflowCanvas
from gradio_client import Client, handle_file
from typing import Optional
import json
import os


def get_token(token: Optional[OAuthToken] = None) -> str:
    """Return the user's HF token if logged in, empty string otherwise."""
    if token is None:
        return ""
    return token.token


def classify_error(e: Exception) -> dict:
    """Classify an error into a type and suggestion for the frontend."""
    title = getattr(e, 'title', None) or ""
    message = getattr(e, 'message', None) or str(e)
    full = f"{title} {message}".lower()

    if "zerogpu" in full or "gpu" in full and "worker" in full:
        return {"error_type": "gpu", "suggestion": "GPU unavailable — try again or log in with your HF account"}
    if "quota" in full or "rate limit" in full:
        return {"error_type": "quota", "suggestion": "GPU quota exceeded — log in with your HF account for more compute"}
    if "sleeping" in full or "paused" in full:
        return {"error_type": "sleeping", "suggestion": "Space is sleeping or paused — try again in a minute"}
    if "api_key" in full or "api key" in full or "unauthorized" in full or "401" in full or "authentication" in full or "log in" in full:
        return {"error_type": "auth", "suggestion": "Sign in with your HF account to use this model"}
    if "not found" in full or "404" in full or "repository not found" in full:
        return {"error_type": "not_found", "suggestion": "Space not found — it may have been deleted or renamed"}
    if "build_error" in full or "build error" in full:
        return {"error_type": "build_error", "suggestion": "Space has a build error — contact the Space owner"}
    if "timed out" in full or "timeout" in full or "connection" in full:
        return {"error_type": "connection", "suggestion": "Could not connect to the Space — it may be down"}

    return {"error_type": "unknown", "suggestion": ""}


def call_space(data, token: Optional[OAuthToken] = None) -> str:
    """Call a Gradio Space. Receives [space_id, endpoint, args_json, manual_token] from frontend."""
    try:
        import re
        space_id = data[0]
        endpoint = data[1] if len(data) > 1 else None
        args_json = data[2] if len(data) > 2 else "[]"
        manual_token = data[3] if len(data) > 3 else None

        if not re.fullmatch(r'[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+', space_id or ""):
            return json.dumps({"error": "Invalid Space ID", "error_type": "not_found", "suggestion": "Space ID must be in owner/repo format"})

        # Use manual token if provided (local dev), otherwise OAuth token (HF Spaces)
        hf_token = manual_token or (token.token if token else None)
        client = Client(space_id, token=hf_token)

        # Auto-discover endpoint if not specified or /predict doesn't exist
        if not endpoint or endpoint == "/predict":
            api = client.view_api(return_format="dict")
            named = list(api.get("named_endpoints", {}).keys())
            if endpoint and endpoint in named:
                pass
            elif named:
                endpoint = named[0]
            else:
                endpoint = "/predict"
        args = json.loads(args_json)

        processed = []
        for arg in args:
            if arg is None:
                processed.append(None)
            elif isinstance(arg, dict) and ("url" in arg or "path" in arg):
                url = arg.get("url") or arg.get("path", "")
                if url:
                    processed.append(handle_file(url))
                else:
                    processed.append(None)
            else:
                processed.append(arg)

        # Strip trailing None args so the Space uses its own defaults
        while processed and processed[-1] is None:
            processed.pop()

        result = client.predict(*processed, api_name=endpoint)

        if not isinstance(result, (list, tuple)):
            result = [result]
        else:
            result = list(result)

        output = []
        for item in result:
            if isinstance(item, str) and os.path.exists(item):
                output.append({"path": item, "url": item, "is_file": True})
            elif isinstance(item, dict):
                output.append(item)
            elif isinstance(item, (list, tuple)):
                sub = []
                for s in item:
                    if isinstance(s, str) and os.path.exists(s):
                        sub.append({"path": s, "url": s, "is_file": True})
                    elif isinstance(s, dict):
                        sub.append(s)
                    else:
                        sub.append(s)
                output.append(sub)
            else:
                output.append(item)

        return json.dumps(output)
    except Exception as e:
        title = getattr(e, 'title', None)
        message = getattr(e, 'message', None) or str(e)
        classified = classify_error(e)
        if classified.get("error_type") == "auth":
            message = "Authentication required"
            title = None
        error_info = {
            "error": message,
            **classified,
        }
        if title:
            error_info["title"] = title
        return json.dumps(error_info)


def call_model(data, token: Optional[OAuthToken] = None) -> str:
    """Call an HF model via the Inference API. Receives [model_id, pipeline_tag, args_json, manual_token]."""
    try:
        from huggingface_hub import InferenceClient
        import tempfile

        model_id = data[0]
        pipeline_tag = data[1] if len(data) > 1 else None
        args_json = data[2] if len(data) > 2 else "[]"
        manual_token = data[3] if len(data) > 3 else None

        hf_token = manual_token or (token.token if token else None)
        client = InferenceClient(model=model_id, token=hf_token)
        args = json.loads(args_json)

        task = pipeline_tag or "text-generation"

        if task in ("text-generation", "text2text-generation", "conversational"):
            result = client.text_generation(args[0] if args else "", max_new_tokens=512)
            return json.dumps([result])

        elif task == "summarization":
            result = client.summarization(args[0] if args else "")
            return json.dumps([result.summary_text])

        elif task == "translation":
            result = client.translation(args[0] if args else "")
            return json.dumps([result.translation_text])

        elif task in ("text-classification", "zero-shot-classification"):
            result = client.text_classification(args[0] if args else "")
            return json.dumps([[{"label": r.label, "score": r.score} for r in result]])

        elif task == "token-classification":
            result = client.token_classification(args[0] if args else "")
            return json.dumps([[{"entity_group": r.entity_group, "word": r.word, "score": r.score} for r in result]])

        elif task == "question-answering":
            question = args[0] if args else ""
            context = args[1] if len(args) > 1 else ""
            result = client.question_answering(question=question, context=context)
            return json.dumps([result.answer])

        elif task == "feature-extraction":
            result = client.feature_extraction(args[0] if args else "")
            return json.dumps([result.tolist() if hasattr(result, 'tolist') else result])

        elif task == "text-to-image":
            image = client.text_to_image(args[0] if args else "")
            path = os.path.join(tempfile.gettempdir(), f"hf_model_{os.urandom(8).hex()}.png")
            image.save(path)
            return json.dumps([{"path": path, "url": path, "is_file": True}])

        elif task in ("text-to-speech", "text-to-audio"):
            audio_bytes = client.text_to_speech(args[0] if args else "")
            path = os.path.join(tempfile.gettempdir(), f"hf_model_{os.urandom(8).hex()}.wav")
            with open(path, "wb") as f:
                f.write(audio_bytes)
            return json.dumps([{"path": path, "url": path, "is_file": True}])

        elif task == "text-to-video":
            video_bytes = client.text_to_video(args[0] if args else "")
            path = os.path.join(tempfile.gettempdir(), f"hf_model_{os.urandom(8).hex()}.mp4")
            with open(path, "wb") as f:
                f.write(video_bytes)
            return json.dumps([{"path": path, "url": path, "is_file": True}])

        elif task == "image-classification":
            image_url = args[0] if args else ""
            if isinstance(image_url, dict):
                image_url = image_url.get("url") or image_url.get("path", "")
            result = client.image_classification(image_url)
            return json.dumps([[{"label": r.label, "score": r.score} for r in result]])

        elif task == "object-detection":
            image_url = args[0] if args else ""
            if isinstance(image_url, dict):
                image_url = image_url.get("url") or image_url.get("path", "")
            result = client.object_detection(image_url)
            return json.dumps([[{"label": r.label, "score": r.score, "box": r.box} for r in result]])

        elif task == "image-to-text":
            image_url = args[0] if args else ""
            if isinstance(image_url, dict):
                image_url = image_url.get("url") or image_url.get("path", "")
            result = client.image_to_text(image_url)
            return json.dumps([result.generated_text if hasattr(result, 'generated_text') else str(result)])

        elif task == "image-to-image":
            image_url = args[0] if args else ""
            prompt = args[1] if len(args) > 1 else ""
            if isinstance(image_url, dict):
                image_url = image_url.get("url") or image_url.get("path", "")
            image = client.image_to_image(image_url, prompt=prompt)
            path = os.path.join(tempfile.gettempdir(), f"hf_model_{os.urandom(8).hex()}.png")
            image.save(path)
            return json.dumps([{"path": path, "url": path, "is_file": True}])

        elif task == "automatic-speech-recognition":
            audio_url = args[0] if args else ""
            if isinstance(audio_url, dict):
                audio_url = audio_url.get("url") or audio_url.get("path", "")
            result = client.automatic_speech_recognition(audio_url)
            return json.dumps([result.text if hasattr(result, 'text') else str(result)])

        elif task == "audio-classification":
            audio_url = args[0] if args else ""
            if isinstance(audio_url, dict):
                audio_url = audio_url.get("url") or audio_url.get("path", "")
            result = client.audio_classification(audio_url)
            return json.dumps([[{"label": r.label, "score": r.score} for r in result]])

        elif task in ("visual-question-answering", "document-question-answering", "image-text-to-text"):
            image_url = args[0] if args else ""
            question = args[1] if len(args) > 1 else ""
            if isinstance(image_url, dict):
                image_url = image_url.get("url") or image_url.get("path", "")
            result = client.visual_question_answering(image_url, question)
            return json.dumps([result[0].answer if result else ""])

        elif task == "depth-estimation":
            image_url = args[0] if args else ""
            if isinstance(image_url, dict):
                image_url = image_url.get("url") or image_url.get("path", "")
            result = client.depth_estimation(image_url)
            path = os.path.join(tempfile.gettempdir(), f"hf_model_{os.urandom(8).hex()}.png")
            result.depth.save(path)
            return json.dumps([{"path": path, "url": path, "is_file": True}])

        else:
            return json.dumps({"error": f"Unsupported task: {task}", "error_type": "unknown", "suggestion": ""})

    except Exception as e:
        title = getattr(e, 'title', None)
        message = getattr(e, 'message', None) or str(e)
        classified = classify_error(e)
        if classified.get("error_type") == "auth":
            message = "Authentication required"
            title = None
        error_info = {"error": message, **classified}
        if title:
            error_info["title"] = title
        return json.dumps(error_info)


def fetch_dataset(data, token: Optional[OAuthToken] = None) -> str:
    """Fetch rows from an HF dataset. Receives [dataset_id, config, split, offset, length]."""
    try:
        import urllib.request
        import urllib.parse

        dataset_id = data[0]
        config = data[1] if len(data) > 1 and data[1] else "default"
        split = data[2] if len(data) > 2 and data[2] else "train"
        offset = int(data[3]) if len(data) > 3 and data[3] else 0
        length = int(data[4]) if len(data) > 4 and data[4] else 10

        params = urllib.parse.urlencode({
            "dataset": dataset_id,
            "config": config,
            "split": split,
            "offset": offset,
            "length": min(length, 100),
        })
        url = f"https://datasets-server.huggingface.co/rows?{params}"
        req = urllib.request.Request(url)
        manual_token = data[5] if len(data) > 5 else None
        hf_token = manual_token or (token.token if token else None)
        if hf_token:
            req.add_header("Authorization", f"Bearer {hf_token}")

        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode())

        return json.dumps({
            "features": result.get("features", []),
            "rows": [r.get("row", {}) for r in result.get("rows", [])],
            "num_rows_total": result.get("num_rows_total", 0),
        })
    except Exception as e:
        return json.dumps({"error": str(e), "error_type": "unknown", "suggestion": ""})


with gr.Blocks(css=".toast-wrap { display: none !important; }") as demo:
    with gr.Row():
        gr.LoginButton(size="sm", scale=0)
    canvas = WorkflowCanvas(server_functions=[get_token, call_space, call_model, fetch_dataset])

if __name__ == "__main__":
    demo.launch()
