
import gradio as gr
from app import demo as app
import os

_docs = {'WorkflowCanvas': {'description': 'Creates a component with arbitrary WorkflowCanvas. Can include CSS and JavaScript to create highly customized and interactive components.\n    ```python\n    import gradio as gr\n\n    with gr.Blocks() as demo:\n        basic_html = gr.HTML("<h2>This is a basic WorkflowCanvas component</h2>")\n\n        button_set = gr.HTML(["Option 1", "Option 2", "Option 3"],\n                       html_template="{{#each value}}<button class=\'option-btn\'>{{this}}</button>{{/each}}",\n                       css_template="button { margin: 5px; padding: 10px; }",\n                       js_on_load="element.querySelectorAll(\'.option-btn\').forEach(btn => { btn.addEventListener(\'click\', () => { trigger(\'click\', {option: btn.innerText}); }); });")\n        clicked_option = gr.Textbox(label="Clicked Option")\n        def on_button_click(evt: gr.EventData):\n            return evt.option\n        button_set.click(on_button_click, outputs=clicked_option)\n\n    demo.launch()\n    ```', 'members': {'__init__': {'value': {'type': 'Any | Callable | None', 'default': 'None', 'description': 'The WorkflowCanvas content in the ${value} tag in the html_template. For example, if html_template="<p>${value}</p>" and value="Hello, world!", the component will render as `"<p>Hello, world!</p>"`.'}, 'label': {'type': 'str | I18nData | None', 'default': 'None', 'description': 'The label for this component. Is used as the header if there are a table of examples for this component. If None and used in a `gr.Interface`, the label will be the name of the parameter this component is assigned to.'}, 'html_template': {'type': 'str', 'default': '"${value}"', 'description': 'A string representing the WorkflowCanvas template for this component as a JS template string and Handlebars template. The `${value}` tag will be replaced with the `value` parameter, and all other tags will be filled in with the values from `props`. This element can have children when used in a `with gr.HTML(...):` context, and the children will be rendered to replace `@children` substring, which cannot be nested inside any WorkflowCanvas tags.'}, 'css_template': {'type': 'str', 'default': '""', 'description': "A string representing the CSS template for this component as a JS template string and Handlebars template. The CSS will be automatically scoped to this component, and rules outside a block will target the component's root element. The `${value}` tag will be replaced with the `value` parameter, and all other tags will be filled in with the values from `props`."}, 'js_on_load': {'type': 'str | None', 'default': '"element.addEventListener(\'click\', function() { trigger(\'click\') });"', 'description': 'A string representing the JavaScript code that will be executed when the component is loaded. The `element` variable refers to the WorkflowCanvas element of this component, and can be used to access children such as `element.querySelector()`. The `trigger` function can be used to trigger events, such as `trigger(\'click\')`. The value and other props can be edited through `props`, e.g. `props.value = "new value"` which will re-render the WorkflowCanvas template. If `server_functions` is provided, a `server` object is also available in `js_on_load`, where each function is accessible as an async method, e.g. `server.list_files(path).then(files => ...)` or `const files = await server.list_files(path)`. The `upload` async function can be used to upload a JavaScript `File` object to the Gradio server, returning a dictionary with `path` (the server-side file path) and `url` (the public URL to access the file), e.g. `const { path, url } = await upload(file)`. The `watch` function can be used to observe prop changes when the component is an output to a Python event listener: `watch(\'value\', () => { ... })` runs the callback after the template re-renders whenever `value` changes, or `watch([\'value\', \'color\'], () => { ... })` to watch multiple props.`.'}, 'apply_default_css': {'type': 'bool', 'default': 'True', 'description': 'If True, default Gradio CSS styles will be applied to the WorkflowCanvas component.'}, 'every': {'type': 'Timer | float | None', 'default': 'None', 'description': 'Continously calls `value` to recalculate it if `value` is a function (has no effect otherwise). Can provide a Timer whose tick resets `value`, or a float that provides the regular interval for the reset Timer.'}, 'inputs': {'type': 'Component | Sequence[Component] | set[Component] | None', 'default': 'None', 'description': 'Components that are used as inputs to calculate `value` if `value` is a function (has no effect otherwise). `value` is recalculated any time the inputs change.'}, 'show_label': {'type': 'bool', 'default': 'False', 'description': 'If True, the label will be displayed. If False, the label will be hidden.'}, 'visible': {'type': 'bool | Literal["hidden"]', 'default': 'True', 'description': 'If False, component will be hidden. If "hidden", component will be visually hidden and not take up space in the layout but still exist in the DOM'}, 'elem_id': {'type': 'str | None', 'default': 'None', 'description': 'An optional string that is assigned as the id of this component in the WorkflowCanvas DOM. Can be used for targeting CSS styles.'}, 'elem_classes': {'type': 'list[str] | str | None', 'default': 'None', 'description': 'An optional list of strings that are assigned as the classes of this component in the WorkflowCanvas DOM. Can be used for targeting CSS styles.'}, 'render': {'type': 'bool', 'default': 'True', 'description': 'If False, component will not render be rendered in the Blocks context. Should be used if the intention is to assign event listeners now but render the component later.'}, 'key': {'type': 'int | str | tuple[int | str, ...] | None', 'default': 'None', 'description': "in a gr.render, Components with the same key across re-renders are treated as the same component, not a new component. Properties set in 'preserved_by_key' are not reset across a re-render."}, 'preserved_by_key': {'type': 'list[str] | str | None', 'default': '"value"', 'description': "A list of parameters from this component's constructor. Inside a gr.render() function, if a component is re-rendered with the same key, these (and only these) parameters will be preserved in the UI (if they have been changed by the user or an event listener) instead of re-rendered based on the values provided during constructor."}, 'min_height': {'type': 'int | None', 'default': 'None', 'description': 'The minimum height of the component, specified in pixels if a number is passed, or in CSS units if a string is passed. If WorkflowCanvas content exceeds the height, the component will expand to fit the content.'}, 'max_height': {'type': 'int | None', 'default': 'None', 'description': 'The maximum height of the component, specified in pixels if a number is passed, or in CSS units if a string is passed. If content exceeds the height, the component will scroll.'}, 'container': {'type': 'bool', 'default': 'False', 'description': 'If True, the WorkflowCanvas component will be displayed in a container. Default is False.'}, 'padding': {'type': 'bool', 'default': 'False', 'description': 'If True, the WorkflowCanvas component will have a certain padding (set by the `--block-padding` CSS variable) in all directions. Default is False.'}, 'autoscroll': {'type': 'bool', 'default': 'False', 'description': 'If True, will automatically scroll to the bottom of the component when the content changes, unless the user has scrolled up. If False, will not scroll to the bottom when the content changes.'}, 'buttons': {'type': 'list[Button] | None', 'default': 'None', 'description': 'A list of gr.Button() instances to show in the top right corner of the component. Custom buttons will appear in the toolbar with their configured icon and/or label, and clicking them will trigger any .click() events registered on the button.'}, 'head': {'type': 'str | None', 'default': 'None', 'description': "A raw WorkflowCanvas string to inject into the document `<head>` before `js_on_load` runs. Typically used for `<script>` and `<link>` tags to load third-party libraries. Scripts are deduplicated by `src` and links by `href`, so multiple components requiring the same library won't load it twice."}, 'server_functions': {'type': 'list[Callable] | None', 'default': 'None', 'description': 'A list of Python functions that can be called from `js_on_load` via the `server` object. For example, if you pass `server_functions=[my_func]`, you can call `server.my_func(arg1, arg2)` in your `js_on_load` code. Each function becomes an async method that sends the call to the Python backend and returns the result.'}, 'props': {'type': 'Any', 'description': 'Additional keyword arguments to pass into the WorkflowCanvas and CSS templates for rendering.'}}, 'postprocess': {'value': {'type': 'str | None', 'description': 'Expects a `str` consisting of valid WorkflowCanvas.'}}, 'preprocess': {'return': {'type': 'str | None', 'description': '(Rarely used) passes the WorkflowCanvas as a `str`.'}, 'value': None}}, 'events': {'change': {'type': None, 'default': None, 'description': 'Triggered when the value of the WorkflowCanvas changes either because of user input (e.g. a user types in a textbox) OR because of a function update (e.g. an image receives a value from the output of an event trigger). See `.input()` for a listener that is only triggered by user input.'}, 'input': {'type': None, 'default': None, 'description': 'This listener is triggered when the user changes the value of the WorkflowCanvas.'}, 'click': {'type': None, 'default': None, 'description': 'Triggered when the WorkflowCanvas is clicked.'}, 'double_click': {'type': None, 'default': None, 'description': 'Triggered when the WorkflowCanvas is double clicked.'}, 'submit': {'type': None, 'default': None, 'description': 'This listener is triggered when the user presses the Enter key while the WorkflowCanvas is focused.'}, 'stop': {'type': None, 'default': None, 'description': 'This listener is triggered when the user reaches the end of the media playing in the WorkflowCanvas.'}, 'edit': {'type': None, 'default': None, 'description': 'This listener is triggered when the user edits the WorkflowCanvas (e.g. image) using the built-in editor.'}, 'clear': {'type': None, 'default': None, 'description': 'This listener is triggered when the user clears the WorkflowCanvas using the clear button for the component.'}, 'play': {'type': None, 'default': None, 'description': 'This listener is triggered when the user plays the media in the WorkflowCanvas.'}, 'pause': {'type': None, 'default': None, 'description': 'This listener is triggered when the media in the WorkflowCanvas stops for any reason.'}, 'end': {'type': None, 'default': None, 'description': 'This listener is triggered when the user reaches the end of the media playing in the WorkflowCanvas.'}, 'start_recording': {'type': None, 'default': None, 'description': 'This listener is triggered when the user starts recording with the WorkflowCanvas.'}, 'pause_recording': {'type': None, 'default': None, 'description': 'This listener is triggered when the user pauses recording with the WorkflowCanvas.'}, 'stop_recording': {'type': None, 'default': None, 'description': 'This listener is triggered when the user stops recording with the WorkflowCanvas.'}, 'focus': {'type': None, 'default': None, 'description': 'This listener is triggered when the WorkflowCanvas is focused.'}, 'blur': {'type': None, 'default': None, 'description': 'This listener is triggered when the WorkflowCanvas is unfocused/blurred.'}, 'upload': {'type': None, 'default': None, 'description': 'This listener is triggered when the user uploads a file into the WorkflowCanvas.'}, 'release': {'type': None, 'default': None, 'description': 'This listener is triggered when the user releases the mouse on this WorkflowCanvas.'}, 'select': {'type': None, 'default': None, 'description': 'Event listener for when the user selects or deselects the WorkflowCanvas. Uses event data gradio.SelectData to carry `value` referring to the label of the WorkflowCanvas, and `selected` to refer to state of the WorkflowCanvas. See https://www.gradio.app/main/docs/gradio/eventdata for more details.'}, 'stream': {'type': None, 'default': None, 'description': 'This listener is triggered when the user streams the WorkflowCanvas.'}, 'like': {'type': None, 'default': None, 'description': 'This listener is triggered when the user likes/dislikes from within the WorkflowCanvas. This event has EventData of type gradio.LikeData that carries information, accessible through LikeData.index and LikeData.value. See EventData documentation on how to use this event data.'}, 'example_select': {'type': None, 'default': None, 'description': 'This listener is triggered when the user clicks on an example from within the WorkflowCanvas. This event has SelectData of type gradio.SelectData that carries information, accessible through SelectData.index and SelectData.value. See SelectData documentation on how to use this event data.'}, 'option_select': {'type': None, 'default': None, 'description': 'This listener is triggered when the user clicks on an option from within the WorkflowCanvas. This event has SelectData of type gradio.SelectData that carries information, accessible through SelectData.index and SelectData.value. See SelectData documentation on how to use this event data.'}, 'load': {'type': None, 'default': None, 'description': 'This listener is triggered when the WorkflowCanvas initially loads in the browser.'}, 'key_up': {'type': None, 'default': None, 'description': 'This listener is triggered when the user presses a key while the WorkflowCanvas is focused.'}, 'apply': {'type': None, 'default': None, 'description': 'This listener is triggered when the user applies changes to the WorkflowCanvas through an integrated UI action.'}, 'delete': {'type': None, 'default': None, 'description': 'This listener is triggered when the user deletes and item from the WorkflowCanvas. Uses event data gradio.DeletedFileData to carry `value` referring to the file that was deleted as an instance of FileData. See EventData documentation on how to use this event data'}, 'tick': {'type': None, 'default': None, 'description': 'This listener is triggered at regular intervals defined by the WorkflowCanvas.'}, 'undo': {'type': None, 'default': None, 'description': 'This listener is triggered when the user clicks the undo button in the chatbot message.'}, 'retry': {'type': None, 'default': None, 'description': 'This listener is triggered when the user clicks the retry button in the chatbot message.'}, 'expand': {'type': None, 'default': None, 'description': 'This listener is triggered when the WorkflowCanvas is expanded.'}, 'collapse': {'type': None, 'default': None, 'description': 'This listener is triggered when the WorkflowCanvas is collapsed.'}, 'download': {'type': None, 'default': None, 'description': 'This listener is triggered when the user downloads a file from the WorkflowCanvas. Uses event data gradio.DownloadData to carry information about the downloaded file as a FileData object. See EventData documentation on how to use this event data'}, 'copy': {'type': None, 'default': None, 'description': 'This listener is triggered when the user copies content from the WorkflowCanvas. Uses event data gradio.CopyData to carry information about the copied content. See EventData documentation on how to use this event data'}}}, '__meta__': {'additional_interfaces': {}, 'user_fn_refs': {'WorkflowCanvas': []}}}

abs_path = os.path.join(os.path.dirname(__file__), "css.css")

with gr.Blocks(
    css=abs_path,
    theme=gr.themes.Default(
        font_mono=[
            gr.themes.GoogleFont("Inconsolata"),
            "monospace",
        ],
    ),
) as demo:
    gr.Markdown(
"""
# `gradio_workflowcanvas`

<div style="display: flex; gap: 7px;">
<a href="https://pypi.org/project/gradio_workflowcanvas/" target="_blank"><img alt="PyPI - Version" src="https://img.shields.io/pypi/v/gradio_workflowcanvas"></a>  
</div>

Visual workflow builder for connecting Hugging Face Spaces into AI pipelines
""", elem_classes=["md-custom"], header_links=True)
    app.render()
    gr.Markdown(
"""
## Installation

```bash
pip install gradio_workflowcanvas
```

## Usage

```python
import gradio as gr
from gradio.oauth import OAuthToken
from gradio_workflowcanvas import WorkflowCanvas
from gradio_client import Client, handle_file
from typing import Optional
import json
import os


def get_token(token: Optional[OAuthToken] = None) -> str:
    \"\"\"Return the user's HF token if logged in, empty string otherwise.\"\"\"
    if token is None:
        return ""
    return token.token


def classify_error(e: Exception) -> dict:
    \"\"\"Classify an error into a type and suggestion for the frontend.\"\"\"
    title = getattr(e, 'title', None) or ""
    message = getattr(e, 'message', None) or str(e)
    full = f"{title} {message}".lower()

    if "zerogpu" in full or "gpu" in full and "worker" in full:
        return {"error_type": "gpu", "suggestion": "GPU unavailable — try again or log in with your HF account"}
    if "quota" in full or "rate limit" in full:
        return {"error_type": "quota", "suggestion": "GPU quota exceeded — log in with your HF account for more compute"}
    if "sleeping" in full or "paused" in full:
        return {"error_type": "sleeping", "suggestion": "Space is sleeping or paused — try again in a minute"}
    if "not found" in full or "404" in full or "repository not found" in full:
        return {"error_type": "not_found", "suggestion": "Space not found — it may have been deleted or renamed"}
    if "build_error" in full or "build error" in full:
        return {"error_type": "build_error", "suggestion": "Space has a build error — contact the Space owner"}
    if "timed out" in full or "timeout" in full or "connection" in full:
        return {"error_type": "connection", "suggestion": "Could not connect to the Space — it may be down"}

    return {"error_type": "unknown", "suggestion": ""}


def call_space(data, token: Optional[OAuthToken] = None) -> str:
    \"\"\"Call a Gradio Space. Receives [space_id, endpoint, args_json] from frontend.\"\"\"
    try:
        space_id = data[0]
        endpoint = data[1] if len(data) > 1 else None
        args_json = data[2] if len(data) > 2 else "[]"

        hf_token = token.token if token else None
        client = Client(space_id, token=hf_token)

        # Auto-discover endpoint if not specified or /predict doesn't exist
        if not endpoint or endpoint == "/predict":
            api = client.view_api(return_format="dict")
            named = list(api.get("named_endpoints", {}).keys())
            if endpoint and endpoint in named:
                pass
            elif named:
                endpoint = named[0]
            else:
                endpoint = "/predict"
        args = json.loads(args_json)

        processed = []
        for arg in args:
            if arg is None:
                processed.append(None)
            elif isinstance(arg, dict) and ("url" in arg or "path" in arg):
                url = arg.get("url") or arg.get("path", "")
                if url:
                    processed.append(handle_file(url))
                else:
                    processed.append(None)
            else:
                processed.append(arg)

        result = client.predict(*processed, api_name=endpoint)

        if not isinstance(result, (list, tuple)):
            result = [result]
        else:
            result = list(result)

        output = []
        for item in result:
            if isinstance(item, str) and os.path.exists(item):
                output.append({"path": item, "url": item, "is_file": True})
            elif isinstance(item, dict):
                output.append(item)
            elif isinstance(item, (list, tuple)):
                sub = []
                for s in item:
                    if isinstance(s, str) and os.path.exists(s):
                        sub.append({"path": s, "url": s, "is_file": True})
                    elif isinstance(s, dict):
                        sub.append(s)
                    else:
                        sub.append(s)
                output.append(sub)
            else:
                output.append(item)

        return json.dumps(output)
    except Exception as e:
        title = getattr(e, 'title', None)
        message = getattr(e, 'message', None) or str(e)
        classified = classify_error(e)
        error_info = {
            "error": message,
            **classified,
        }
        if title:
            error_info["title"] = title
        return json.dumps(error_info)


with gr.Blocks(css=".toast-wrap { display: none !important; }") as demo:
    with gr.Row():
        gr.LoginButton(size="sm", scale=0)
    canvas = WorkflowCanvas(server_functions=[get_token, call_space])

if __name__ == "__main__":
    demo.launch()

```
""", elem_classes=["md-custom"], header_links=True)


    gr.Markdown("""
## `WorkflowCanvas`

### Initialization
""", elem_classes=["md-custom"], header_links=True)

    gr.ParamViewer(value=_docs["WorkflowCanvas"]["members"]["__init__"], linkify=[])


    gr.Markdown("### Events")
    gr.ParamViewer(value=_docs["WorkflowCanvas"]["events"], linkify=['Event'])




    gr.Markdown("""

### User function

The impact on the users predict function varies depending on whether the component is used as an input or output for an event (or both).

- When used as an Input, the component only impacts the input signature of the user function.
- When used as an output, the component only impacts the return signature of the user function.

The code snippet below is accurate in cases where the component is used as both an input and an output.

- **As input:** Is passed, (Rarely used) passes the WorkflowCanvas as a `str`.
- **As output:** Should return, expects a `str` consisting of valid WorkflowCanvas.

 ```python
def predict(
    value: str | None
) -> str | None:
    return value
```
""", elem_classes=["md-custom", "WorkflowCanvas-user-fn"], header_links=True)




    demo.load(None, js=r"""function() {
    const refs = {};
    const user_fn_refs = {
          WorkflowCanvas: [], };
    requestAnimationFrame(() => {

        Object.entries(user_fn_refs).forEach(([key, refs]) => {
            if (refs.length > 0) {
                const el = document.querySelector(`.${key}-user-fn`);
                if (!el) return;
                refs.forEach(ref => {
                    el.innerHTML = el.innerHTML.replace(
                        new RegExp("\\b"+ref+"\\b", "g"),
                        `<a href="#h-${ref.toLowerCase()}">${ref}</a>`
                    );
                })
            }
        })

        Object.entries(refs).forEach(([key, refs]) => {
            if (refs.length > 0) {
                const el = document.querySelector(`.${key}`);
                if (!el) return;
                refs.forEach(ref => {
                    el.innerHTML = el.innerHTML.replace(
                        new RegExp("\\b"+ref+"\\b", "g"),
                        `<a href="#h-${ref.toLowerCase()}">${ref}</a>`
                    );
                })
            }
        })
    })
}

""")

demo.launch()
