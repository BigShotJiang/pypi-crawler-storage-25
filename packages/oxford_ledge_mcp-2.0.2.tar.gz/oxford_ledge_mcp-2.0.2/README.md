> **Last Updated:** 2026-04-24 ET — 2.0.1 yfinance excision

# Oxford Ledge MCP Server

Financial data tools for [Claude Desktop](https://claude.ai/download) via the [Model Context Protocol](https://modelcontextprotocol.io/).

36 tools for stocks, SEC filings, bonds, credit data, BDC holdings, macro indicators, and more. **Best experienced with `OXFORD_LEDGE_URL` set** — routes through a running Oxford Ledge instance that has the full data pipeline (FMP, SEC EDGAR, FRED, FINRA TRACE, Finnhub). A small subset of tools also works standalone against keyless public APIs.

**Upgrading from 1.x or 2.0.0?** See [MIGRATING.md](./MIGRATING.md). Short version: tool names, arg schemas, and config are unchanged. Two substantive changes:
1. 2.0 extracted the shared tool registry into an `oxford_ledge_mcp_core` subpackage consumed by both the pip-installable server and Oxford Ledge's in-tree server. No user-visible behavior change.
2. 2.0.1 removed yfinance from this package (it was a ToS-violating scraper dependency). 11 tools that used to work standalone now require `OXFORD_LEDGE_URL`.

## Data sources (after 2.0.1)

Nothing in this package scrapes Yahoo Finance. Oxford Ledge sources data from:
- **FMP** (Financial Modeling Prep) — stock quotes, fundamentals, analyst estimates
- **SEC EDGAR** — 10-K/Q filings, Form 4 insider transactions, 13F institutional holdings
- **FRED** — Treasury yields, macroeconomic series
- **FINRA TRACE** — bond issuer search + CUSIP lookup
- **Finnhub** — supplementary quotes + profile data

The `oxford-ledge-mcp` pip package itself has **zero runtime dependencies** on any of the above — all data is fetched through the Oxford Ledge server over `OXFORD_LEDGE_URL`. Standalone mode (no server) is limited to FRED + FINRA TRACE + static reference tools.

## Install

```bash
pip install oxford-ledge-mcp
```

## Claude Desktop Setup

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "oxford-ledge": {
      "command": "oxford-ledge-mcp"
    }
  }
}
```

Restart Claude Desktop. You'll see 36 financial tools available.

### API Mode (recommended)

For all 36 tools, connect to a running Oxford Ledge instance:

```json
{
  "mcpServers": {
    "oxford-ledge": {
      "command": "oxford-ledge-mcp",
      "env": {
        "OXFORD_LEDGE_URL": "https://www.oxfordledge.com"
      }
    }
  }
}
```

### Environment Variables

| Variable | Description |
|----------|-------------|
| `OXFORD_LEDGE_URL` | Oxford Ledge API URL (enables all 36 tools) |
| `FRED_API_KEY` | FRED API key for yield curve and economic data |

## Available Tools

### Standalone Tools (18 tools, no server needed)

| Tool | Description |
|------|-------------|
| `get_stock_quote` | Current price, P/E, EV/EBITDA, market cap, beta |
| `get_financials` | Income statement (revenue, net income, EBITDA) |
| `get_balance_sheet` | Assets, liabilities, equity, debt, cash |
| `get_cash_flow` | Operating, investing, financing cash flows, FCF |
| `get_analyst_recommendations` | Buy/hold/sell counts, price targets |
| `get_holders` | Top institutional shareholders |
| `get_company_info` | Sector, industry, employees, description |
| `compare_stocks` | Side-by-side comparison of 2-5 stocks |
| `get_sec_filings` | Recent 10-K, 10-Q, 8-K filings from EDGAR |
| `get_insider_trades` | Recent insider buy/sell transactions |
| `get_options_chain` | Calls and puts with expiry filtering |
| `screen_stocks` | Filter by sector, market cap, P/E, dividend yield |
| `get_fundamentals` | 10-year XBRL financials from SEC EDGAR |
| `search_bonds` | Search bond issuers via FINRA TRACE |
| `get_bond_data` | Look up bonds by CUSIP |
| `get_yield_curve` | Treasury yield curve from FRED |
| `get_fred_data` | Any FRED series (GDP, UNRATE, CPI, etc.) |
| `get_short_interest` | Short percent of float, days to cover |

### API-Mode Tools (18 additional tools, require OXFORD_LEDGE_URL)

| Tool | Description |
|------|-------------|
| `get_company_data` | Full company data with valuation multiples |
| `search_company` | Fuzzy search by name, ticker, or industry |
| `get_company_profile` | Business description, CEO, founding year |
| `get_corporate_events` | M&A, executive changes, restructurings |
| `get_market_indicators` | S&P 500, VIX, Treasury yields, gold, oil |
| `search_bdc_borrower` | Search BDC portfolio holdings by borrower |
| `get_bdc_list` | All tracked BDCs with AUM and holdings |
| `calculate_intrinsic_value` | DCF, EPV, Graham fair value models |
| `get_anomaly_flags` | 15 automated red flag checks |
| `get_debt_maturities` | Maturity schedule from 10-K footnotes |
| `get_capital_allocation` | 10-year buyback/dividend/debt scorecard |
| `get_peer_comparison` | Peer valuation and financial metrics |
| `get_news` | News archive search with sentiment scores |
| `get_price_history` | OHLCV price history |
| `get_13f_holdings` | Institutional 13F holdings from EDGAR |
| `get_value_investing_fact` | Buffett/Graham/Munger quotes and principles |
| `get_valuation_history` | Historical P/E, EV/EBITDA, P/B, P/S |
| `get_economic_calendar` | FOMC, CPI, GDP, jobs report dates |

## Data Sources

All data in 2.0.1+ flows through Oxford Ledge's licensed providers or keyless public APIs. **Nothing in this package scrapes Yahoo Finance** (the previous 1.x / 2.0.0 `yfinance` path was removed in the 2.0.1 Y1 excision sprint).

- **FMP** (Financial Modeling Prep) — real-time quotes, financials, analyst estimates, company profiles, historical prices. Routed through `OXFORD_LEDGE_URL` (API mode) — pip package doesn't carry FMP keys.
- **SEC EDGAR** — XBRL fundamentals, 10-K/10-Q/8-K filings, Form 4 insider transactions, 13F institutional holdings. Keyless public API.
- **FINRA TRACE** — corporate bond search + CUSIP lookup. Keyless public API.
- **FRED** — Treasury yields, economic indicators, data-release calendar. Optional `FRED_API_KEY` for higher rate limits.
- **Finnhub** — supplementary quotes + profile. Paid legitimate API (not scraper); routed through `OXFORD_LEDGE_URL`.
- **Oxford Ledge proprietary data** — BDC holdings (54 BDCs, 9K+ borrowers), news archive, 176K+ Form 4 transactions, valuations history. API mode only.

## Full Terminal

For the complete experience with 45+ databases, news archive, credit analysis, BDC data, and AI-powered analysis, visit [www.oxfordledge.com](https://www.oxfordledge.com).

## Standalone mode (without `OXFORD_LEDGE_URL`)

A small subset of tools works without an Oxford Ledge instance — the ones backed by keyless public APIs:

- **FRED macro:** `get_yield_curve`, `get_fred_data`
- **FINRA bond search:** `search_bonds`, `get_bond_data`
- **SEC EDGAR directly:** `get_sec_filings`, `get_fundamentals`
- **Static reference:** `get_value_investing_fact`

Everything else (stock quotes, financials, analyst data, portfolio tools, screener, etc.) requires `OXFORD_LEDGE_URL`. Without it, those tools raise `ToolError.API_REQUIRED` with a pointer to this README.

**This is a change from 1.x / 2.0.0**, which used yfinance to cover 18 standalone tools. That path was removed in 2.0.1 — see [MIGRATING.md](./MIGRATING.md) for the rationale.

## License

MIT
