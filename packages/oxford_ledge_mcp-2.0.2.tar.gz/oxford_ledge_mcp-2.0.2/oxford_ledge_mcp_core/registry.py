"""Declarative tool registry — the @mcp_tool decorator + cache TTL
tiers + the legacy-compat views that existing dispatcher code reads.

Extracted 2026-04-24 from `mcp_server.py` as part of the M1 twin-
dedup sprint. F2 MCP Dedup Phase 4 (2026-04-24) introduced this
pattern; M1 makes it the shared primitive both servers use.

## Usage

    from oxford_ledge_mcp_core import mcp_tool, MARKET, FUNDAMENTAL, NEVER

    @mcp_tool(name="get_company_data", cache=MARKET)
    def tool_get_company_data(args):
        ...

    @mcp_tool(name="run_screener", cache=NEVER, heavy=True)
    def tool_run_screener(args):
        ...

## How the legacy views are populated

`TOOL_DISPATCH`, `_TOOL_TTL`, and `_MCP_HEAVY_TOOLS` are denormalized
views of `REGISTRY`. The decorator populates them at function-
definition time. Existing dispatcher code iterates them directly;
keeping them in sync with `REGISTRY` avoids a disruptive API break
during the migration.

## Invariants

- `REGISTRY` is the single source of truth. Never mutate the three
  views directly — only via `mcp_tool(...)`.
- Tool names must be unique across the process. Duplicate
  registration raises `ValueError`.
- `cache` default is `MARKET` (60s). Override with FUNDAMENTAL
  (3600s), STATIC (86400s), NEVER (0), or an explicit integer.
- `heavy=True` marks a tool as acquiring the heavy-concurrency
  semaphore (max 2 in-flight) in addition to the general semaphore.
"""
from __future__ import annotations

# ── TTL tier aliases ───────────────────────────────────────────────
# Seconds. Exposed as constants so callers can write:
#   @mcp_tool(name="X", cache=MARKET)
# instead of
#   @mcp_tool(name="X", cache=60)
MARKET = 60           # Market data: prices change fast
FUNDAMENTAL = 3600    # Fundamentals: change infrequently
STATIC = 86400        # Static reference: glossary, facts, etc.
NEVER = 0             # Never cache: portfolio mutations, user-specific


# ── Primary registry ───────────────────────────────────────────────
# tool_name -> {"handler": callable, "cache_ttl": int, "heavy": bool}
REGISTRY: dict = {}


# ── Denormalized legacy views ──────────────────────────────────────
# Populated by the decorator at function-definition time. Existing
# dispatcher code in mcp_server.py iterates these directly (via
# `name in TOOL_DISPATCH`, `_TOOL_TTL.get(name, 60)`, etc.) — keeping
# them in sync avoids a disruptive API break during migration.
TOOL_DISPATCH: dict = {}  # name -> handler
_TOOL_TTL: dict = {}       # name -> int (seconds)
_MCP_HEAVY_TOOLS: set = set()  # names of heavy-concurrency tools


def mcp_tool(*, name: str, cache: int = MARKET, heavy: bool = False):
    """Decorator: register an MCP tool handler with its cache TTL and
    concurrency class.

    Args:
        name: The tool name as Claude Desktop sees it. Must be unique.
        cache: TTL in seconds. Use MARKET / FUNDAMENTAL / STATIC / NEVER
               tier constants or a literal int.
        heavy: If True, the tool acquires the heavy semaphore in
               addition to the general one. Default False.

    Raises:
        ValueError if `name` is already registered.
    """

    def decorator(fn):
        if name in REGISTRY:
            raise ValueError(f"Duplicate MCP tool registration: {name}")
        REGISTRY[name] = {"handler": fn, "cache_ttl": cache, "heavy": heavy}
        # Keep the legacy views in sync. See the module docstring for
        # why they exist.
        TOOL_DISPATCH[name] = fn
        _TOOL_TTL[name] = cache
        if heavy:
            _MCP_HEAVY_TOOLS.add(name)
        return fn

    return decorator
