"""Tool-partition declaration — which MCP tools live in which server.

M1 Phase 2 (2026-04-24). The two MCP servers (in-tree `mcp_server.py`
+ pip `mcp_package/oxford_ledge_mcp/server.py`) have overlapping but
not identical tool surfaces. Phase 0 of the M1 sprint documented the
split as intentional:

  - **Shared (25 tools)** — implemented by both servers. In-tree uses
    direct-Python calls into data_providers / pg_db / oxford_ledge_db /
    edgar / market_data / fmp_api. Pip uses HTTP calls against
    `OXFORD_LEDGE_URL` in API mode.
  - **In-tree only (13 tools)** — call Oxford Ledge-specific internals
    (portfolio, screener, ai_question, etc.) that would require pip
    to replicate significant service-layer logic over HTTP. Not
    cost-effective; pip users who need these can run the in-tree
    server from a local OL checkout.
  - **Pip only (11 tools)** — yfinance-backed standalone tools that
    work without `OXFORD_LEDGE_URL`. In-tree doesn't implement them
    because it has always had richer data via the data_providers
    layer; duplicating the yfinance path would be dead code.

This file is the REGRESSION GATE: `tests/test_mcp_tool_partition.py`
imports these sets and compares against the live `REGISTRY` from
each server. If someone adds a tool to one side without updating
this file, the test fails loudly.

If a legitimate change moves a tool (e.g. M1 Phase 3 wires Tradier
and `get_options_chain` graduates from pip-only to shared), update
this file IN THE SAME COMMIT that changes the server code.
"""
from __future__ import annotations

# Tools present in BOTH servers.
SHARED_TOOLS: frozenset[str] = frozenset({
    "calculate_intrinsic_value",
    "get_13f_holdings",
    "get_anomaly_flags",
    "get_bdc_list",
    "get_bond_data",
    "get_capital_allocation",
    "get_company_data",
    "get_company_profile",
    "get_corporate_events",
    "get_debt_maturities",
    "get_economic_calendar",
    "get_fred_data",
    "get_fundamentals",
    "get_market_indicators",
    "get_news",
    "get_options_chain",
    "get_peer_comparison",
    "get_price_history",
    "get_short_interest",
    "get_valuation_history",
    "get_value_investing_fact",
    "get_yield_curve",
    "search_bdc_borrower",
    "search_bonds",
    "search_company",
})

# Tools present ONLY in the in-tree server (mcp_server.py).
# These call OL-codebase internals that the pip package doesn't
# vendor. See module docstring for rationale.
IN_TREE_ONLY_TOOLS: frozenset[str] = frozenset({
    "batch_get_ticker_data",
    "bulk_get_fundamentals",
    "get_ai_question",
    "get_analyst_estimates",
    "get_calendar",
    "get_estimate_revisions",
    "get_index_movers",
    "get_insider_activity",
    "get_portfolio_analytics",
    "get_portfolio_positions",
    "get_sector_breakdown",
    "run_screener",
    "search_news_archive",
})

# Tools present ONLY in the pip-installable server. These are the
# yfinance standalone tools — they work without OXFORD_LEDGE_URL.
# In-tree server doesn't implement them because its data layer
# (data_providers) already provides richer versions.
PIP_ONLY_TOOLS: frozenset[str] = frozenset({
    "compare_stocks",
    "get_analyst_recommendations",
    "get_balance_sheet",
    "get_cash_flow",
    "get_company_info",
    "get_financials",
    "get_holders",
    "get_insider_trades",
    "get_sec_filings",
    "get_stock_quote",
    "screen_stocks",
})


# Convenience views for consumers.
IN_TREE_TOOLS: frozenset[str] = SHARED_TOOLS | IN_TREE_ONLY_TOOLS
PIP_TOOLS: frozenset[str] = SHARED_TOOLS | PIP_ONLY_TOOLS


def summary() -> dict:
    """Return a summary dict for logging / diagnostics."""
    return {
        "shared": len(SHARED_TOOLS),
        "in_tree_only": len(IN_TREE_ONLY_TOOLS),
        "pip_only": len(PIP_ONLY_TOOLS),
        "in_tree_total": len(IN_TREE_TOOLS),
        "pip_total": len(PIP_TOOLS),
    }
