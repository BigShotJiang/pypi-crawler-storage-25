#!/usr/bin/env python
"""
mcp-google-drive — Parafin internal MCP server for Google Drive, Sheets, and Docs.
"""

import json
import re
import sys
from dataclasses import dataclass
from contextlib import asynccontextmanager
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any, Dict, List, Optional

from mcp.server.fastmcp import FastMCP, Context
from mcp.types import ToolAnnotations

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# --- Config ---

CONFIG_DIR = Path.home() / ".config" / "mcp-google-drive"
CREDENTIALS_PATH = CONFIG_DIR / "credentials.json"
TOKEN_PATH = CONFIG_DIR / "token.json"

SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
    "https://www.googleapis.com/auth/documents",
]


# --- Context ---

@dataclass
class GoogleContext:
    sheets_service: Any
    drive_service: Any
    docs_service: Any


# --- Lifespan ---

@asynccontextmanager
async def google_lifespan(server: FastMCP) -> AsyncIterator[GoogleContext]:
    """Manage Google API connection lifecycle with inline OAuth."""
    if not CREDENTIALS_PATH.exists():
        sys.exit(
            f"credentials.json not found at {CREDENTIALS_PATH}. "
            "Contact #llm in Slack to obtain it."
        )

    creds = None
    if TOKEN_PATH.exists():
        creds = Credentials.from_authorized_user_info(
            json.loads(TOKEN_PATH.read_text()), SCOPES
        )

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
                TOKEN_PATH.write_text(creds.to_json())
            except Exception:
                creds = None

        if not creds:
            flow = InstalledAppFlow.from_client_secrets_file(str(CREDENTIALS_PATH), SCOPES)
            creds = flow.run_local_server(port=0)
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            TOKEN_PATH.write_text(creds.to_json())

    sheets_service = build("sheets", "v4", credentials=creds)
    drive_service = build("drive", "v3", credentials=creds)
    docs_service = build("docs", "v1", credentials=creds)

    yield GoogleContext(
        sheets_service=sheets_service,
        drive_service=drive_service,
        docs_service=docs_service,
    )


# --- Server ---

mcp = FastMCP(
    "mcp-google-drive",
    dependencies=["google-auth", "google-auth-oauthlib", "google-api-python-client"],
    lifespan=google_lifespan,
)


# =============================================================================
# Sheets — Read
# =============================================================================

@mcp.tool(annotations=ToolAnnotations(title="Get Sheet Data", readOnlyHint=True))
def get_sheet_data(
    spreadsheet_id: str,
    sheet: str,
    range: Optional[str] = None,
    include_grid_data: bool = False,
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Get data from a specific sheet in a Google Spreadsheet.

    Args:
        spreadsheet_id: The ID of the spreadsheet (found in the URL)
        sheet: The name of the sheet
        range: Optional cell range in A1 notation (e.g., 'A1:C10'). If not provided, gets all data.
        include_grid_data: If True, includes cell formatting and other metadata in the response.
            Note: Setting this to True will significantly increase the response size and token usage.
            Default is False (returns values only, more efficient).

    Returns:
        Grid data structure with either full metadata or just values from Google Sheets API.
    """
    sheets_service = ctx.request_context.lifespan_context.sheets_service

    if range:
        full_range = f"{sheet}!{range}"
    else:
        full_range = sheet

    if include_grid_data:
        result = sheets_service.spreadsheets().get(
            spreadsheetId=spreadsheet_id,
            ranges=[full_range],
            includeGridData=True,
        ).execute()
    else:
        values_result = sheets_service.spreadsheets().values().get(
            spreadsheetId=spreadsheet_id,
            range=full_range,
        ).execute()
        result = {
            "spreadsheetId": spreadsheet_id,
            "valueRanges": [{"range": full_range, "values": values_result.get("values", [])}],
        }

    return result


@mcp.tool(annotations=ToolAnnotations(title="Get Sheet Formulas", readOnlyHint=True))
def get_sheet_formulas(
    spreadsheet_id: str,
    sheet: str,
    range: Optional[str] = None,
    ctx: Context = None,
) -> List[List[Any]]:
    """
    Get formulas from a specific sheet in a Google Spreadsheet.

    Args:
        spreadsheet_id: The ID of the spreadsheet (found in the URL)
        sheet: The name of the sheet
        range: Optional cell range in A1 notation (e.g., 'A1:C10'). If not provided, gets all formulas.

    Returns:
        A 2D array of the sheet formulas.
    """
    sheets_service = ctx.request_context.lifespan_context.sheets_service

    full_range = f"{sheet}!{range}" if range else sheet

    result = sheets_service.spreadsheets().values().get(
        spreadsheetId=spreadsheet_id,
        range=full_range,
        valueRenderOption="FORMULA",
    ).execute()

    return result.get("values", [])


@mcp.tool(annotations=ToolAnnotations(title="List Sheets", readOnlyHint=True))
def list_sheets(spreadsheet_id: str, ctx: Context = None) -> List[str]:
    """
    List all sheets in a Google Spreadsheet.

    Args:
        spreadsheet_id: The ID of the spreadsheet (found in the URL)

    Returns:
        List of sheet names
    """
    sheets_service = ctx.request_context.lifespan_context.sheets_service
    spreadsheet = sheets_service.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
    return [sheet["properties"]["title"] for sheet in spreadsheet["sheets"]]


@mcp.tool(annotations=ToolAnnotations(title="Get Multiple Sheet Data", readOnlyHint=True))
def get_multiple_sheet_data(
    queries: Any,
    ctx: Context = None,
) -> List[Dict[str, Any]]:
    """
    Get data from multiple specific ranges in Google Spreadsheets.

    Args:
        queries: A list of dicts, each with 'spreadsheet_id', 'sheet', and 'range' keys.
                 Example: [{'spreadsheet_id': 'abc', 'sheet': 'Sheet1', 'range': 'A1:B5'}]

    Returns:
        A list of dicts, each containing the original query parameters and fetched 'data' or 'error'.
    """
    sheets_service = ctx.request_context.lifespan_context.sheets_service
    results = []

    if isinstance(queries, str):
        queries = json.loads(queries)

    for query in queries:
        spreadsheet_id = query.get("spreadsheet_id")
        sheet = query.get("sheet")
        range_str = query.get("range")

        if not all([spreadsheet_id, sheet, range_str]):
            results.append({**query, "error": "Missing required keys (spreadsheet_id, sheet, range)"})
            continue

        try:
            full_range = f"{sheet}!{range_str}"
            result = sheets_service.spreadsheets().values().get(
                spreadsheetId=spreadsheet_id,
                range=full_range,
            ).execute()
            results.append({**query, "data": result.get("values", [])})
        except Exception as e:
            results.append({**query, "error": str(e)})

    return results


@mcp.tool(annotations=ToolAnnotations(title="Get Multiple Spreadsheet Summary", readOnlyHint=True))
def get_multiple_spreadsheet_summary(
    spreadsheet_ids: List[str],
    rows_to_fetch: int = 5,
    ctx: Context = None,
) -> List[Dict[str, Any]]:
    """
    Get a summary of multiple Google Spreadsheets, including sheet names, headers,
    and the first few rows of data for each sheet.

    Args:
        spreadsheet_ids: A list of spreadsheet IDs to summarize.
        rows_to_fetch: The number of rows (including header) to fetch for the summary (default: 5).

    Returns:
        A list of dicts, each representing a spreadsheet summary.
    """
    sheets_service = ctx.request_context.lifespan_context.sheets_service
    summaries = []

    for spreadsheet_id in spreadsheet_ids:
        summary_data = {"spreadsheet_id": spreadsheet_id, "title": None, "sheets": [], "error": None}
        try:
            spreadsheet = sheets_service.spreadsheets().get(
                spreadsheetId=spreadsheet_id,
                fields="properties.title,sheets(properties(title,sheetId))",
            ).execute()

            summary_data["title"] = spreadsheet.get("properties", {}).get("title", "Unknown Title")
            sheet_summaries = []

            for sheet in spreadsheet.get("sheets", []):
                sheet_title = sheet.get("properties", {}).get("title")
                sheet_id = sheet.get("properties", {}).get("sheetId")
                sheet_summary = {
                    "title": sheet_title,
                    "sheet_id": sheet_id,
                    "headers": [],
                    "first_rows": [],
                    "error": None,
                }

                if not sheet_title:
                    sheet_summary["error"] = "Sheet title not found"
                    sheet_summaries.append(sheet_summary)
                    continue

                try:
                    max_row = max(1, rows_to_fetch)
                    range_to_get = f"{sheet_title}!A1:{max_row}"
                    result = sheets_service.spreadsheets().values().get(
                        spreadsheetId=spreadsheet_id,
                        range=range_to_get,
                    ).execute()
                    values = result.get("values", [])
                    if values:
                        sheet_summary["headers"] = values[0]
                        if len(values) > 1:
                            sheet_summary["first_rows"] = values[1:max_row]
                except Exception as sheet_e:
                    sheet_summary["error"] = f"Error fetching data for sheet {sheet_title}: {sheet_e}"

                sheet_summaries.append(sheet_summary)

            summary_data["sheets"] = sheet_summaries
        except Exception as e:
            summary_data["error"] = f"Error fetching spreadsheet {spreadsheet_id}: {e}"

        summaries.append(summary_data)

    return summaries


@mcp.tool(annotations=ToolAnnotations(title="List Spreadsheets", readOnlyHint=True))
def list_spreadsheets(folder_id: Optional[str] = None, ctx: Context = None) -> List[Dict[str, str]]:
    """
    List all spreadsheets in the specified Google Drive folder.
    If no folder is specified, lists from 'My Drive'.

    Args:
        folder_id: Optional Google Drive folder ID to search in.

    Returns:
        List of spreadsheets with their ID and title
    """
    drive_service = ctx.request_context.lifespan_context.drive_service

    query = "mimeType='application/vnd.google-apps.spreadsheet'"
    if folder_id:
        query += f" and '{_escape_drive_query(folder_id)}' in parents"

    results = drive_service.files().list(
        q=query,
        spaces="drive",
        includeItemsFromAllDrives=True,
        supportsAllDrives=True,
        fields="files(id, name)",
        orderBy="modifiedTime desc",
    ).execute()

    return [{"id": f["id"], "title": f["name"]} for f in results.get("files", [])]


@mcp.tool(annotations=ToolAnnotations(title="Search Spreadsheets by Name or Content", readOnlyHint=True))
def search_spreadsheets(
    query: str,
    max_results: int = 20,
    ctx: Context = None,
) -> List[Dict[str, Any]]:
    """
    Search for spreadsheets in Google Drive by name or content.

    Args:
        query: Search query string. Searches in file name and content.
        max_results: Maximum number of results to return (default 20, max 100)

    Returns:
        List of matching spreadsheets with their ID, name, and metadata
    """
    drive_service = ctx.request_context.lifespan_context.drive_service
    max_results = min(max(1, max_results), 100)

    escaped = _escape_drive_query(query)
    search_query = (
        f"mimeType='application/vnd.google-apps.spreadsheet' and "
        f"(name contains '{escaped}' or fullText contains '{escaped}')"
    )

    try:
        results = drive_service.files().list(
            q=search_query,
            pageSize=max_results,
            spaces="drive",
            includeItemsFromAllDrives=True,
            supportsAllDrives=True,
            fields="files(id, name, createdTime, modifiedTime, owners, webViewLink)",
            orderBy="modifiedTime desc",
        ).execute()

        return [
            {
                "id": f["id"],
                "name": f["name"],
                "created_time": f.get("createdTime"),
                "modified_time": f.get("modifiedTime"),
                "owners": [owner.get("emailAddress") for owner in f.get("owners", [])],
                "web_link": f.get("webViewLink"),
            }
            for f in results.get("files", [])
        ]
    except Exception as e:
        return [{"error": f"Search failed: {str(e)}"}]


@mcp.tool(annotations=ToolAnnotations(title="Find Cells", readOnlyHint=True))
def find_in_spreadsheet(
    spreadsheet_id: str,
    query: str,
    sheet: Optional[str] = None,
    case_sensitive: bool = False,
    max_results: int = 50,
    ctx: Context = None,
) -> List[Dict[str, Any]]:
    """
    Find cells containing a specific value in a Google Spreadsheet.

    Args:
        spreadsheet_id: The ID of the spreadsheet (found in the URL)
        query: The text to search for in cell values
        sheet: Optional sheet name to search in. If not provided, searches all sheets.
        case_sensitive: Whether the search should be case-sensitive (default False)
        max_results: Maximum number of results to return (default 50)

    Returns:
        List of found cells with their location (sheet, cell in A1 notation) and value
    """
    sheets_service = ctx.request_context.lifespan_context.sheets_service
    results = []

    try:
        spreadsheet = sheets_service.spreadsheets().get(
            spreadsheetId=spreadsheet_id,
            fields="sheets(properties(title,sheetId))",
        ).execute()

        sheets_to_search = [
            s["properties"]["title"]
            for s in spreadsheet.get("sheets", [])
            if sheet is None or s["properties"]["title"] == sheet
        ]

        if not sheets_to_search:
            return [{"error": f"Sheet '{sheet}' not found"}]

        search_query = query if case_sensitive else query.lower()

        for sheet_name in sheets_to_search:
            if len(results) >= max_results:
                break

            response = sheets_service.spreadsheets().values().get(
                spreadsheetId=spreadsheet_id,
                range=sheet_name,
            ).execute()

            for row_idx, row in enumerate(response.get("values", [])):
                if len(results) >= max_results:
                    break
                for col_idx, cell_value in enumerate(row):
                    if len(results) >= max_results:
                        break
                    cell_str = str(cell_value)
                    compare_value = cell_str if case_sensitive else cell_str.lower()
                    if search_query in compare_value:
                        results.append({
                            "sheet": sheet_name,
                            "cell": f"{_column_index_to_letter(col_idx)}{row_idx + 1}",
                            "value": cell_value,
                        })

        return results
    except Exception as e:
        return [{"error": f"Search failed: {str(e)}"}]


# =============================================================================
# Sheets — Write / Create
# =============================================================================

@mcp.tool(annotations=ToolAnnotations(title="Update Cells", destructiveHint=True))
def update_cells(
    spreadsheet_id: str,
    sheet: str,
    range: str,
    data: List[List[Any]],
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Update cells in a Google Spreadsheet.

    Args:
        spreadsheet_id: The ID of the spreadsheet (found in the URL)
        sheet: The name of the sheet
        range: Cell range in A1 notation (e.g., 'A1:C10')
        data: 2D array of values to update

    Returns:
        Result of the update operation
    """
    sheets_service = ctx.request_context.lifespan_context.sheets_service

    result = sheets_service.spreadsheets().values().update(
        spreadsheetId=spreadsheet_id,
        range=f"{sheet}!{range}",
        valueInputOption="USER_ENTERED",
        body={"values": data},
    ).execute()

    return result


@mcp.tool(annotations=ToolAnnotations(title="Batch Update Cells", destructiveHint=True))
def batch_update_cells(
    spreadsheet_id: str,
    sheet: str,
    ranges: Any,
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Batch update multiple ranges in a Google Spreadsheet.

    Args:
        spreadsheet_id: The ID of the spreadsheet (found in the URL)
        sheet: The name of the sheet
        ranges: Dict mapping range strings to 2D arrays of values
                e.g., {'A1:B2': [[1, 2], [3, 4]], 'D1:E2': [['a', 'b'], ['c', 'd']]}

    Returns:
        Result of the batch update operation
    """
    sheets_service = ctx.request_context.lifespan_context.sheets_service

    if isinstance(ranges, str):
        ranges = json.loads(ranges)

    data = [
        {"range": f"{sheet}!{range_str}", "values": values}
        for range_str, values in ranges.items()
    ]

    result = sheets_service.spreadsheets().values().batchUpdate(
        spreadsheetId=spreadsheet_id,
        body={"valueInputOption": "USER_ENTERED", "data": data},
    ).execute()

    return result


@mcp.tool(annotations=ToolAnnotations(title="Add Rows", destructiveHint=True))
def add_rows(
    spreadsheet_id: str,
    sheet: str,
    count: int,
    start_row: Optional[int] = None,
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Add rows to a sheet in a Google Spreadsheet.

    Args:
        spreadsheet_id: The ID of the spreadsheet (found in the URL)
        sheet: The name of the sheet
        count: Number of rows to add
        start_row: 0-based row index to start adding. If not provided, adds at the beginning.

    Returns:
        Result of the operation
    """
    sheets_service = ctx.request_context.lifespan_context.sheets_service

    spreadsheet = sheets_service.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
    sheet_id = next(
        (s["properties"]["sheetId"] for s in spreadsheet["sheets"] if s["properties"]["title"] == sheet),
        None,
    )
    if sheet_id is None:
        return {"error": f"Sheet '{sheet}' not found"}

    start = start_row if start_row is not None else 0
    result = sheets_service.spreadsheets().batchUpdate(
        spreadsheetId=spreadsheet_id,
        body={
            "requests": [{
                "insertDimension": {
                    "range": {
                        "sheetId": sheet_id,
                        "dimension": "ROWS",
                        "startIndex": start,
                        "endIndex": start + count,
                    },
                    "inheritFromBefore": start_row is not None and start_row > 0,
                }
            }]
        },
    ).execute()

    return result


@mcp.tool(annotations=ToolAnnotations(title="Add Columns", destructiveHint=True))
def add_columns(
    spreadsheet_id: str,
    sheet: str,
    count: int,
    start_column: Optional[int] = None,
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Add columns to a sheet in a Google Spreadsheet.

    Args:
        spreadsheet_id: The ID of the spreadsheet (found in the URL)
        sheet: The name of the sheet
        count: Number of columns to add
        start_column: 0-based column index to start adding. If not provided, adds at the beginning.

    Returns:
        Result of the operation
    """
    sheets_service = ctx.request_context.lifespan_context.sheets_service

    spreadsheet = sheets_service.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
    sheet_id = next(
        (s["properties"]["sheetId"] for s in spreadsheet["sheets"] if s["properties"]["title"] == sheet),
        None,
    )
    if sheet_id is None:
        return {"error": f"Sheet '{sheet}' not found"}

    start = start_column if start_column is not None else 0
    result = sheets_service.spreadsheets().batchUpdate(
        spreadsheetId=spreadsheet_id,
        body={
            "requests": [{
                "insertDimension": {
                    "range": {
                        "sheetId": sheet_id,
                        "dimension": "COLUMNS",
                        "startIndex": start,
                        "endIndex": start + count,
                    },
                    "inheritFromBefore": start_column is not None and start_column > 0,
                }
            }]
        },
    ).execute()

    return result


@mcp.tool(annotations=ToolAnnotations(title="Copy Sheet", destructiveHint=True))
def copy_sheet(
    src_spreadsheet: str,
    src_sheet: str,
    dst_spreadsheet: str,
    dst_sheet: str,
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Copy a sheet from one spreadsheet to another.

    Args:
        src_spreadsheet: Source spreadsheet ID
        src_sheet: Source sheet name
        dst_spreadsheet: Destination spreadsheet ID
        dst_sheet: Destination sheet name

    Returns:
        Result of the operation
    """
    sheets_service = ctx.request_context.lifespan_context.sheets_service

    src = sheets_service.spreadsheets().get(spreadsheetId=src_spreadsheet).execute()
    src_sheet_id = next(
        (s["properties"]["sheetId"] for s in src["sheets"] if s["properties"]["title"] == src_sheet),
        None,
    )
    if src_sheet_id is None:
        return {"error": f"Source sheet '{src_sheet}' not found"}

    copy_result = sheets_service.spreadsheets().sheets().copyTo(
        spreadsheetId=src_spreadsheet,
        sheetId=src_sheet_id,
        body={"destinationSpreadsheetId": dst_spreadsheet},
    ).execute()

    if "title" in copy_result and copy_result["title"] != dst_sheet:
        rename_result = sheets_service.spreadsheets().batchUpdate(
            spreadsheetId=dst_spreadsheet,
            body={
                "requests": [{
                    "updateSheetProperties": {
                        "properties": {"sheetId": copy_result["sheetId"], "title": dst_sheet},
                        "fields": "title",
                    }
                }]
            },
        ).execute()
        return {"copy": copy_result, "rename": rename_result}

    return {"copy": copy_result}


@mcp.tool(annotations=ToolAnnotations(title="Rename Sheet", destructiveHint=True))
def rename_sheet(
    spreadsheet: str,
    sheet: str,
    new_name: str,
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Rename a sheet in a Google Spreadsheet.

    Args:
        spreadsheet: Spreadsheet ID
        sheet: Current sheet name
        new_name: New sheet name

    Returns:
        Result of the operation
    """
    sheets_service = ctx.request_context.lifespan_context.sheets_service

    spreadsheet_data = sheets_service.spreadsheets().get(spreadsheetId=spreadsheet).execute()
    sheet_id = next(
        (s["properties"]["sheetId"] for s in spreadsheet_data["sheets"] if s["properties"]["title"] == sheet),
        None,
    )
    if sheet_id is None:
        return {"error": f"Sheet '{sheet}' not found"}

    result = sheets_service.spreadsheets().batchUpdate(
        spreadsheetId=spreadsheet,
        body={
            "requests": [{
                "updateSheetProperties": {
                    "properties": {"sheetId": sheet_id, "title": new_name},
                    "fields": "title",
                }
            }]
        },
    ).execute()

    return result


@mcp.tool(annotations=ToolAnnotations(title="Create Spreadsheet", destructiveHint=True))
def create_spreadsheet(
    title: str,
    folder_id: Optional[str] = None,
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Create a new Google Spreadsheet.

    Args:
        title: The title of the new spreadsheet
        folder_id: Optional Google Drive folder ID where the spreadsheet should be created.

    Returns:
        Information about the newly created spreadsheet including its ID
    """
    drive_service = ctx.request_context.lifespan_context.drive_service

    file_body = {
        "name": title,
        "mimeType": "application/vnd.google-apps.spreadsheet",
    }
    if folder_id:
        file_body["parents"] = [folder_id]

    spreadsheet = drive_service.files().create(
        supportsAllDrives=True,
        body=file_body,
        fields="id, name, parents",
    ).execute()

    parents = spreadsheet.get("parents")
    return {
        "spreadsheetId": spreadsheet.get("id"),
        "title": spreadsheet.get("name", title),
        "folder": parents[0] if parents else "root",
    }


@mcp.tool(annotations=ToolAnnotations(title="Create Sheet", destructiveHint=True))
def create_sheet(
    spreadsheet_id: str,
    title: str,
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Create a new sheet tab in an existing Google Spreadsheet.

    Args:
        spreadsheet_id: The ID of the spreadsheet
        title: The title for the new sheet

    Returns:
        Information about the newly created sheet
    """
    sheets_service = ctx.request_context.lifespan_context.sheets_service

    result = sheets_service.spreadsheets().batchUpdate(
        spreadsheetId=spreadsheet_id,
        body={"requests": [{"addSheet": {"properties": {"title": title}}}]},
    ).execute()

    new_sheet_props = result["replies"][0]["addSheet"]["properties"]
    return {
        "sheetId": new_sheet_props["sheetId"],
        "title": new_sheet_props["title"],
        "index": new_sheet_props.get("index"),
        "spreadsheetId": spreadsheet_id,
    }


@mcp.tool(annotations=ToolAnnotations(title="Share Spreadsheet", destructiveHint=True))
def share_spreadsheet(
    spreadsheet_id: str,
    recipients: Any,
    send_notification: bool = True,
    ctx: Context = None,
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Share a Google Spreadsheet with multiple users via email, assigning specific roles.

    Args:
        spreadsheet_id: The ID of the spreadsheet to share.
        recipients: A list of dicts, each with 'email_address' and 'role'.
                    Role must be one of: 'reader', 'commenter', 'writer'.
        send_notification: Whether to send a notification email to the users. Defaults to True.

    Returns:
        A dict with lists of 'successes' and 'failures'.
    """
    drive_service = ctx.request_context.lifespan_context.drive_service
    successes = []
    failures = []

    if isinstance(recipients, str):
        recipients = json.loads(recipients)

    for recipient in recipients:
        email_address = recipient.get("email_address")
        role = recipient.get("role", "writer")

        if not email_address:
            failures.append({"email_address": None, "error": "Missing email_address in recipient entry."})
            continue

        if role not in ["reader", "commenter", "writer"]:
            failures.append({"email_address": email_address, "error": f"Invalid role '{role}'."})
            continue

        try:
            result = drive_service.permissions().create(
                fileId=spreadsheet_id,
                body={"type": "user", "role": role, "emailAddress": email_address},
                sendNotificationEmail=send_notification,
                fields="id",
            ).execute()
            successes.append({"email_address": email_address, "role": role, "permissionId": result.get("id")})
        except Exception as e:
            error_details = str(e)
            if hasattr(e, "content"):
                try:
                    error_content = json.loads(e.content)
                    error_details = error_content.get("error", {}).get("message", error_details)
                except json.JSONDecodeError:
                    pass
            failures.append({"email_address": email_address, "error": f"Failed to share: {error_details}"})

    return {"successes": successes, "failures": failures}


@mcp.tool(annotations=ToolAnnotations(title="Batch Update", destructiveHint=True))
def batch_update(
    spreadsheet_id: str,
    requests: Any,
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Execute a batch update on a Google Spreadsheet using the full batchUpdate endpoint.
    Supports all batchUpdate operations: adding sheets, updating properties,
    inserting/deleting dimensions, formatting, and more.

    Args:
        spreadsheet_id: The ID of the spreadsheet (found in the URL)
        requests: A list of request objects. Each can contain any valid batchUpdate operation.

    Returns:
        Result of the batch update operation, including replies for each request
    """
    sheets_service = ctx.request_context.lifespan_context.sheets_service

    if isinstance(requests, str):
        requests = json.loads(requests)
    if not requests:
        return {"error": "requests list cannot be empty"}
    if not all(isinstance(req, dict) for req in requests):
        return {"error": "Each request must be a dictionary"}

    return sheets_service.spreadsheets().batchUpdate(
        spreadsheetId=spreadsheet_id,
        body={"requests": requests},
    ).execute()


@mcp.tool(annotations=ToolAnnotations(title="Add Chart", destructiveHint=True))
def add_chart(
    spreadsheet_id: str,
    sheet: str,
    chart_type: str,
    data_range: str,
    title: Optional[str] = None,
    x_axis_label: Optional[str] = None,
    y_axis_label: Optional[str] = None,
    position_x: int = 0,
    position_y: int = 0,
    width: int = 600,
    height: int = 400,
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Add a chart to a Google Spreadsheet.

    Args:
        spreadsheet_id: The ID of the spreadsheet (found in the URL)
        sheet: The name of the sheet containing the data
        chart_type: Type of chart: COLUMN, BAR, LINE, AREA, PIE, SCATTER, COMBO, HISTOGRAM
        data_range: A1 notation range for chart data (e.g., 'A1:C10')
        title: Optional title for the chart
        x_axis_label: Optional label for the X axis
        y_axis_label: Optional label for the Y axis
        position_x: Horizontal pixel offset (default: 0)
        position_y: Vertical pixel offset (default: 0)
        width: Width in pixels (default: 600)
        height: Height in pixels (default: 400)

    Returns:
        Result of the chart creation operation
    """
    sheets_service = ctx.request_context.lifespan_context.sheets_service

    valid_chart_types = ["COLUMN", "BAR", "LINE", "AREA", "PIE", "SCATTER", "COMBO", "HISTOGRAM"]
    if chart_type.upper() not in valid_chart_types:
        return {"error": f"Invalid chart type '{chart_type}'. Must be one of: {', '.join(valid_chart_types)}"}

    chart_type = chart_type.upper()
    sheet_id = _get_sheet_id(sheets_service, spreadsheet_id, sheet)
    if sheet_id is None:
        return {"error": f"Sheet '{sheet}' not found in spreadsheet"}

    try:
        range_indices = _parse_a1_notation(data_range)
    except ValueError as e:
        return {"error": str(e)}

    start_row = range_indices.get("startRowIndex", 0)
    end_row = range_indices.get("endRowIndex")
    start_col = range_indices.get("startColumnIndex", 0)
    end_col = range_indices.get("endColumnIndex")

    def _col_range(col_start: int, col_end: int) -> Dict:
        r = {"sheetId": sheet_id, "startColumnIndex": col_start, "endColumnIndex": col_end}
        if start_row is not None:
            r["startRowIndex"] = start_row
        if end_row is not None:
            r["endRowIndex"] = end_row
        return r

    domain_range = _col_range(start_col, start_col + 1)

    if end_col is not None and end_col > start_col + 1:
        series_ranges = [
            _col_range(col, col + 1)
            for col in range(start_col + 1, end_col)
        ]
    else:
        series_ranges = [_col_range(start_col + 1, start_col + 2)]

    def _series_entry(r: Dict) -> Dict:
        return {"series": {"sourceRange": {"sources": [r]}}, "targetAxis": "LEFT_AXIS"}

    if chart_type == "PIE":
        chart_spec = {
            "pieChart": {
                "legendPosition": "RIGHT_LEGEND",
                "domain": {"sourceRange": {"sources": [domain_range]}},
                "series": {"sourceRange": {"sources": [series_ranges[0]]}},
            }
        }
        if title:
            chart_spec["title"] = title
    else:
        chart_spec = {
            "basicChart": {
                "chartType": chart_type,
                "legendPosition": "RIGHT_LEGEND",
                "axis": [],
                "domains": [{"domain": {"sourceRange": {"sources": [domain_range]}}}],
                "series": [_series_entry(r) for r in series_ranges],
                "headerCount": 1,
            }
        }
        if title:
            chart_spec["title"] = title

        chart_spec["basicChart"]["axis"].append(
            {"position": "BOTTOM_AXIS", "title": x_axis_label} if x_axis_label else {"position": "BOTTOM_AXIS"}
        )
        chart_spec["basicChart"]["axis"].append(
            {"position": "LEFT_AXIS", "title": y_axis_label} if y_axis_label else {"position": "LEFT_AXIS"}
        )

    try:
        result = sheets_service.spreadsheets().batchUpdate(
            spreadsheetId=spreadsheet_id,
            body={
                "requests": [{
                    "addChart": {
                        "chart": {
                            "spec": chart_spec,
                            "position": {
                                "overlayPosition": {
                                    "anchorCell": {"sheetId": sheet_id, "rowIndex": 0, "columnIndex": 0},
                                    "offsetXPixels": position_x,
                                    "offsetYPixels": position_y,
                                    "widthPixels": width,
                                    "heightPixels": height,
                                }
                            },
                        }
                    }
                }]
            },
        ).execute()

        return {
            "success": True,
            "message": f"Chart '{title or chart_type}' added successfully",
            "chartId": result.get("replies", [{}])[0].get("addChart", {}).get("chart", {}).get("chartId"),
            "result": result,
        }
    except Exception as e:
        return {"error": f"Failed to add chart: {str(e)}"}


# =============================================================================
# Drive — Read
# =============================================================================

@mcp.tool(annotations=ToolAnnotations(title="List Files", readOnlyHint=True))
def list_files(
    folder_id: Optional[str] = None,
    mime_type: Optional[str] = None,
    ctx: Context = None,
) -> List[Dict[str, Any]]:
    """
    List files in Google Drive, optionally filtered by folder and/or MIME type.

    Args:
        folder_id: Optional folder ID to list files from.
        mime_type: Optional MIME type filter (e.g., 'application/vnd.google-apps.spreadsheet').

    Returns:
        List of files with id, name, mimeType, modifiedTime, size, and webViewLink.
    """
    drive_service = ctx.request_context.lifespan_context.drive_service

    conditions = ["trashed=false"]
    if folder_id:
        conditions.append(f"'{_escape_drive_query(folder_id)}' in parents")
    if mime_type:
        conditions.append(f"mimeType='{_escape_drive_query(mime_type)}'")

    results = drive_service.files().list(
        q=" and ".join(conditions),
        spaces="drive",
        includeItemsFromAllDrives=True,
        supportsAllDrives=True,
        fields="files(id, name, mimeType, modifiedTime, size, webViewLink)",
        orderBy="modifiedTime desc",
    ).execute()

    return results.get("files", [])


@mcp.tool(annotations=ToolAnnotations(title="Get File Metadata", readOnlyHint=True))
def get_file_metadata(file_id: str, ctx: Context = None) -> Dict[str, Any]:
    """
    Get metadata for a file in Google Drive.

    Args:
        file_id: The ID of the file.

    Returns:
        File metadata including id, name, mimeType, modifiedTime, createdTime, size, owners, webViewLink, parents.
    """
    drive_service = ctx.request_context.lifespan_context.drive_service

    return drive_service.files().get(
        fileId=file_id,
        supportsAllDrives=True,
        fields="id, name, mimeType, modifiedTime, createdTime, size, owners, webViewLink, parents",
    ).execute()


@mcp.tool(annotations=ToolAnnotations(title="Search Files", readOnlyHint=True))
def search_files(query: str, ctx: Context = None) -> List[Dict[str, Any]]:
    """
    Search files in Google Drive using a Drive query string.

    See https://developers.google.com/workspace/drive/api/guides/search-files for query syntax.

    Args:
        query: Full Drive query string (e.g., "name contains 'budget' and trashed=false").

    Returns:
        List of matching files with id, name, mimeType, modifiedTime, and webViewLink.
    """
    drive_service = ctx.request_context.lifespan_context.drive_service

    results = drive_service.files().list(
        q=query,
        spaces="drive",
        includeItemsFromAllDrives=True,
        supportsAllDrives=True,
        fields="files(id, name, mimeType, modifiedTime, webViewLink)",
        orderBy="modifiedTime desc",
    ).execute()

    return results.get("files", [])


@mcp.tool(annotations=ToolAnnotations(title="List Folders", readOnlyHint=True))
def list_folders(parent_folder_id: Optional[str] = None, ctx: Context = None) -> List[Dict[str, str]]:
    """
    List all folders in the specified Google Drive folder.
    If no parent folder is specified, lists folders from 'My Drive' root.

    Args:
        parent_folder_id: Optional folder ID to search within.

    Returns:
        List of folders with their ID, name, and parent.
    """
    drive_service = ctx.request_context.lifespan_context.drive_service

    query = "mimeType='application/vnd.google-apps.folder'"
    if parent_folder_id:
        query += f" and '{parent_folder_id}' in parents"
    else:
        query += " and 'root' in parents"

    results = drive_service.files().list(
        q=query,
        spaces="drive",
        includeItemsFromAllDrives=True,
        supportsAllDrives=True,
        fields="files(id, name, parents)",
        orderBy="name",
    ).execute()

    return [
        {
            "id": folder["id"],
            "name": folder["name"],
            "parent": folder.get("parents", ["root"])[0] if folder.get("parents") else "root",
        }
        for folder in results.get("files", [])
    ]


# =============================================================================
# Drive — Download
# =============================================================================

@mcp.tool(annotations=ToolAnnotations(title="Get File Content", readOnlyHint=True))
def get_file_content(file_id: str, ctx: Context = None) -> str:
    """
    Download the raw text content of a file in Google Drive (e.g. CSV, TXT).

    Args:
        file_id: The ID of the file.

    Returns:
        The file content as a string.
    """
    drive_service = ctx.request_context.lifespan_context.drive_service

    request = drive_service.files().get_media(fileId=file_id)
    content = request.execute()
    if isinstance(content, bytes):
        return content.decode("utf-8")
    return content


# =============================================================================
# Drive — Write / Create
# =============================================================================


@mcp.tool(annotations=ToolAnnotations(title="Create Folder", destructiveHint=True))
def create_folder(
    name: str,
    parent_folder_id: Optional[str] = None,
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Create a new folder in Google Drive.

    Args:
        name: The name of the new folder.
        parent_folder_id: Optional parent folder ID. Creates in root if not specified.

    Returns:
        Folder metadata including id, name, and webViewLink.
    """
    drive_service = ctx.request_context.lifespan_context.drive_service

    metadata: Dict[str, Any] = {
        "name": name,
        "mimeType": "application/vnd.google-apps.folder",
    }
    if parent_folder_id:
        metadata["parents"] = [parent_folder_id]

    return drive_service.files().create(
        body=metadata,
        supportsAllDrives=True,
        fields="id, name, webViewLink",
    ).execute()


@mcp.tool(annotations=ToolAnnotations(title="Move File", destructiveHint=True))
def move_file(
    file_id: str,
    new_folder_id: str,
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Move a file to a different folder in Google Drive.

    Args:
        file_id: The ID of the file to move.
        new_folder_id: The ID of the destination folder.

    Returns:
        Updated file metadata including id, name, and parents.
    """
    drive_service = ctx.request_context.lifespan_context.drive_service

    file = drive_service.files().get(
        fileId=file_id,
        supportsAllDrives=True,
        fields="parents",
    ).execute()

    previous_parents = ",".join(file.get("parents", []))

    return drive_service.files().update(
        fileId=file_id,
        addParents=new_folder_id,
        removeParents=previous_parents,
        supportsAllDrives=True,
        fields="id, name, parents",
    ).execute()


# =============================================================================
# Docs — Read
# =============================================================================

@mcp.tool(annotations=ToolAnnotations(title="Get Document", readOnlyHint=True))
def get_document(document_id: str, ctx: Context = None) -> Dict[str, Any]:
    """
    Get the full text content of a Google Doc.

    Args:
        document_id: The ID of the document (found in the URL).

    Returns:
        Dict with document_id, title, and plain text content.
    """
    docs_service = ctx.request_context.lifespan_context.docs_service

    doc = docs_service.documents().get(documentId=document_id).execute()

    text_parts = []
    for element in doc.get("body", {}).get("content", []):
        if "paragraph" in element:
            for pe in element["paragraph"].get("elements", []):
                if "textRun" in pe:
                    text_parts.append(pe["textRun"].get("content", ""))

    return {
        "document_id": document_id,
        "title": doc.get("title", ""),
        "content": "".join(text_parts),
    }


@mcp.tool(annotations=ToolAnnotations(title="List Documents", readOnlyHint=True))
def list_documents(
    folder_id: Optional[str] = None,
    ctx: Context = None,
) -> List[Dict[str, Any]]:
    """
    List Google Docs in Drive or a specific folder.

    Args:
        folder_id: Optional folder ID to list documents from.

    Returns:
        List of documents with id, name, modifiedTime, and webViewLink.
    """
    drive_service = ctx.request_context.lifespan_context.drive_service

    query = "mimeType='application/vnd.google-apps.document' and trashed=false"
    if folder_id:
        query += f" and '{folder_id}' in parents"

    results = drive_service.files().list(
        q=query,
        spaces="drive",
        includeItemsFromAllDrives=True,
        supportsAllDrives=True,
        fields="files(id, name, modifiedTime, webViewLink)",
        orderBy="modifiedTime desc",
    ).execute()

    return results.get("files", [])


# =============================================================================
# Docs — Write / Create
# =============================================================================

@mcp.tool(annotations=ToolAnnotations(title="Create Document", destructiveHint=True))
def create_document(
    title: str,
    folder_id: Optional[str] = None,
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Create a new Google Doc.

    Args:
        title: The title of the new document.
        folder_id: Optional folder ID to place the document in.

    Returns:
        Dict with document_id, title, and webViewLink.
    """
    docs_service = ctx.request_context.lifespan_context.docs_service
    drive_service = ctx.request_context.lifespan_context.drive_service

    doc = docs_service.documents().create(body={"title": title}).execute()
    document_id = doc["documentId"]

    if folder_id:
        file = drive_service.files().get(fileId=document_id, fields="parents").execute()
        previous_parents = ",".join(file.get("parents", []))
        drive_service.files().update(
            fileId=document_id,
            addParents=folder_id,
            removeParents=previous_parents,
            fields="id, parents",
        ).execute()

    file_meta = drive_service.files().get(
        fileId=document_id, fields="webViewLink"
    ).execute()

    return {
        "document_id": document_id,
        "title": title,
        "web_link": file_meta.get("webViewLink"),
    }


@mcp.tool(annotations=ToolAnnotations(title="Update Document", destructiveHint=True))
def update_document(
    document_id: str,
    requests: Any,
    ctx: Context = None,
) -> Dict[str, Any]:
    """
    Apply a list of update requests to a Google Doc via batchUpdate.

    See https://developers.google.com/workspace/docs/api/reference/rest/v1/documents/batchUpdate
    for the full list of supported request types (insertText, deleteContentRange, etc.).

    Args:
        document_id: The ID of the document.
        requests: List of Docs API request objects.

    Returns:
        Result of the batchUpdate operation.
    """
    docs_service = ctx.request_context.lifespan_context.docs_service

    if isinstance(requests, str):
        requests = json.loads(requests)

    return docs_service.documents().batchUpdate(
        documentId=document_id,
        body={"requests": requests},
    ).execute()


# =============================================================================
# Resources
# =============================================================================

@mcp.resource("spreadsheet://{spreadsheet_id}/info")
def get_spreadsheet_info(spreadsheet_id: str, ctx: Context = None) -> str:
    """Get basic information about a Google Spreadsheet."""
    sheets_service = ctx.request_context.lifespan_context.sheets_service

    spreadsheet = sheets_service.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
    info = {
        "title": spreadsheet.get("properties", {}).get("title", "Unknown"),
        "sheets": [
            {
                "title": sheet["properties"]["title"],
                "sheetId": sheet["properties"]["sheetId"],
                "gridProperties": sheet["properties"].get("gridProperties", {}),
            }
            for sheet in spreadsheet.get("sheets", [])
        ],
    }
    return json.dumps(info, indent=2)


# =============================================================================
# Helpers
# =============================================================================

def _column_index_to_letter(index: int) -> str:
    """Convert 0-based column index to A1 notation letter (0='A', 25='Z', 26='AA', etc.)"""
    result = ""
    while index >= 0:
        result = chr(index % 26 + ord("A")) + result
        index = index // 26 - 1
    return result


def _letter_to_column_index(letter: str) -> int:
    """Convert A1 notation letter to 0-based column index ('A'=0, 'Z'=25, 'AA'=26, etc.)"""
    result = 0
    for char in letter.upper():
        result = result * 26 + (ord(char) - ord("A") + 1)
    return result - 1


def _parse_a1_notation(range_str: str) -> Dict[str, int]:
    """Parse A1 notation range to row/column indices for the Sheets API."""
    match = re.match(r"^([A-Z]+)?(\d+)?(?::([A-Z]+)?(\d+)?)?$", range_str.upper())
    if not match:
        raise ValueError(f"Invalid A1 notation: {range_str}")

    start_col, start_row, end_col, end_row = match.groups()
    result: Dict[str, int] = {}

    if start_col:
        result["startColumnIndex"] = _letter_to_column_index(start_col)
    if start_row:
        result["startRowIndex"] = int(start_row) - 1
    if end_col:
        result["endColumnIndex"] = _letter_to_column_index(end_col) + 1
    elif start_col:
        result["endColumnIndex"] = result["startColumnIndex"] + 1
    if end_row:
        result["endRowIndex"] = int(end_row)
    elif start_row:
        result["endRowIndex"] = result["startRowIndex"] + 1

    return result


def _escape_drive_query(value: str) -> str:
    """Escape single quotes in Drive API query string values."""
    return value.replace("\\", "\\\\").replace("'", "\\'")


def _get_sheet_id(sheets_service: Any, spreadsheet_id: str, sheet_name: str) -> Optional[int]:
    """Get the sheet ID for a given sheet name."""
    try:
        spreadsheet = sheets_service.spreadsheets().get(
            spreadsheetId=spreadsheet_id,
            fields="sheets(properties(title,sheetId))",
        ).execute()
        for sheet in spreadsheet.get("sheets", []):
            if sheet["properties"]["title"] == sheet_name:
                return sheet["properties"]["sheetId"]
        return None
    except Exception:
        return None


# =============================================================================
# Entry point
# =============================================================================

def main():
    mcp.run(transport="stdio")
