# Examples

This directory contains example projects to help you get started with Plane Compose.

## Directory Structure

### `hello/`
A complete example project demonstrating the basic structure of a Plane Compose project:
- **`plane.yaml`** - Project configuration
- **`schema/`** - Work item types, workflows, and labels definitions
- **`work/`** - Sample work items

This is a ready-to-use template. You can copy this folder and customize it for your own projects.

## Getting Started

### Use the hello project as a template:

```bash
# Copy the example project
cp -r examples/hello my-project
cd my-project

# Edit configuration
vim plane.yaml

# Authenticate
plane auth login

# Push schema and work items
plane schema push
plane push
```

## Learn More

- [Examples Guide](../docs/examples.md) - More usage examples
- [Plane Compose Reference](../docs/plane-compose.md) - Comprehensive documentation

## Tips

1. **Start simple** - Begin with the `hello/` project and customize from there
2. **Customize schemas** - Modify work item types and workflows to match your process
3. **Test locally** - Use `--dry-run` flags to preview changes before applying
4. **Version control** - Keep your project configurations in Git for tracking changes
