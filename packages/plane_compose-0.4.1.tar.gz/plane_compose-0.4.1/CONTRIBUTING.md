# Contributing to Plane Compose

Thanks for your interest in contributing! This guide covers everything you need to get started.

## Development Setup

```bash
# Clone the repo
git clone https://github.com/makeplane/compose.git
cd compose

# Install in development mode with dev dependencies
pip install -e ".[dev]"

# Verify installation
plane --version
```

## Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=planecompose --cov-report=html

# Run a specific test file
pytest tests/test_models.py

# Run a specific test
pytest tests/test_models.py::TestWorkItem::test_work_item_basic
```

## Code Quality

We use the following tools (all run in CI):

```bash
# Lint
ruff check src/

# Auto-fix lint issues
ruff check --fix src/

# Type checking
mypy src/planecompose/
```

### Pre-commit Hooks (Recommended)

```bash
pip install pre-commit
pre-commit install
```

This runs ruff and basic checks automatically on every commit.

## Pull Request Process

1. Fork the repository and create a branch from `main`
2. Make your changes, adding tests for new functionality
3. Ensure all tests pass: `pytest`
4. Ensure lint passes: `ruff check src/`
5. Open a PR against `main` with a clear description

### PR Guidelines

- Keep PRs focused on a single concern
- Add tests for new features and bug fixes
- Follow existing code patterns and architecture (see `CLAUDE.md` for details)
- CLI commands go in `cli/`, business logic in `sync/` or `backend/`
- All API calls must go through `backend/client.py`

## Reporting Issues

Open an issue at [github.com/makeplane/compose/issues](https://github.com/makeplane/compose/issues) with:

- Steps to reproduce
- Expected vs actual behavior
- Python version and OS
- Relevant error output

## Architecture Overview

See `CLAUDE.md` for a detailed architecture guide. The key principle: **CLI is thin, logic lives in backend/sync/state modules.**

## License

By contributing, you agree that your contributions will be licensed under the AGPL-3.0-or-later license.
