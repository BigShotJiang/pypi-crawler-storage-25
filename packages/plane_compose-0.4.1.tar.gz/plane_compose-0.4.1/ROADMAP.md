# Plane Compose Enterprise Roadmap

This roadmap outlines the path from current capabilities to enterprise-scale features supporting migrations, multi-project management, and bulk operations.

## Current State (v0.4.0)

- Single project management via `plane.yaml`
- Schema versioning (types, workflows, labels)
- Work item sync (push/pull/apply)
- Clone existing projects to YAML

---

## Phase 1: Multi-Project Foundation

**Goal**: Enable managing multiple Plane projects from a single codebase without complexity overhead.

### 1.1 Path-Based Operations
```bash
# Operate on specific project by path
plane push ./projects/backend
plane pull ./projects/frontend
plane status ./projects/api

# Current directory behavior unchanged
plane push  # operates on ./plane.yaml
```

**Implementation**:
- Add optional `path` argument to push/pull/apply/status commands
- Resolve `plane.yaml` from provided path
- Maintain current behavior when no path specified

### 1.2 Batch Operations (`--all`)
```bash
# Discover and operate on all projects
plane push --all
plane status --all
plane schema push --all

# With filters
plane push --all --workspace=engineering
plane status --all --filter="projects/*"
```

**Implementation**:
- Project discovery: recursively find `plane.yaml` files
- Parallel execution with configurable concurrency
- Aggregate reporting (success/failure summary)
- Respect `.planeignore` for exclusions

### 1.3 Schema Inheritance (`extends`)
```yaml
# projects/backend/plane.yaml
workspace: myteam
project:
  key: BACKEND
extends: ../../shared/base-schema.yaml
```

```yaml
# shared/base-schema.yaml (partial schema)
defaults:
  type: Story
  workflow: default

# Types, workflows, labels defined here are inherited
```

**Implementation**:
- Parse `extends` field during config loading
- Deep merge: local overrides inherited
- Support relative paths
- Circular dependency detection

### 1.4 Affected Detection
```bash
# Only operate on projects with changes since last sync
plane push --affected
plane push --affected --base=main
```

**Implementation**:
- Track content hashes in `.plane/state.json`
- Git integration: detect changed files since base
- Map file changes to affected projects

---

## Phase 2: Migration Tooling

**Goal**: Enable migrations from Jira and support M&A project consolidation.

### 2.1 Jira Import Module
```bash
# Import Jira project to Plane Compose format
plane migrate jira \
  --jira-url=https://company.atlassian.net \
  --jira-project=PROJ \
  --output=./projects/migrated

# Options
--include-attachments    # Download and reference attachments
--include-history        # Import change history as comments
--field-mapping=map.yaml # Custom field mapping file
--dry-run               # Preview without writing
```

**Field Mapping File**:
```yaml
# map.yaml - Custom field mappings
fields:
  customfield_10001: severity      # Map Jira custom field to Plane property
  customfield_10042: team

status_mapping:
  "To Do": Backlog
  "In Progress": "In Progress"
  "Done": Done

priority_mapping:
  Highest: urgent
  High: high
  Medium: medium
  Low: low
  Lowest: none
```

**Implementation**:
- Jira REST API client (v2 and v3)
- JQL support for selective import
- Attachment handling (download + reference)
- Rate limiting and resumable imports
- Progress reporting for large imports

### 2.2 Schema Merge Tool (M&A Support)
```bash
# Analyze schemas from multiple projects
plane schema analyze ./acquired-company ./parent-company

# Output: compatibility report
# - Conflicting type definitions
# - Duplicate states with different meanings
# - Property type mismatches
# - Recommended unified schema

# Generate merged schema
plane schema merge \
  ./acquired/* ./parent/* \
  --output=./unified-schema \
  --strategy=union  # union|intersection|manual
```

**Merge Strategies**:
- `union`: Include all types/fields from all sources (may need deduplication)
- `intersection`: Only keep common elements
- `manual`: Generate diff for manual resolution

**Implementation**:
- Schema comparison engine
- Conflict detection and reporting
- Namespace support for disambiguation (`acquired:Bug` vs `parent:Bug`)
- Migration scripts generation

### 2.3 Bulk Issue Migration
```bash
# Migrate work items between projects
plane migrate issues \
  --from=OLD_PROJECT \
  --to=NEW_PROJECT \
  --query="state:backlog AND type:Bug" \
  --remap-types=migration-rules.yaml

# Cross-workspace migration
plane migrate issues \
  --from=workspace1/PROJECT \
  --to=workspace2/PROJECT
```

**Implementation**:
- Query-based selection
- Type/state/label remapping
- Link preservation where possible
- Batch API operations
- Rollback support

---

## Phase 3: Bulk Operations & Query Language

**Goal**: Enable efficient operations on large issue sets without manual YAML editing.

### 3.1 Query Command
```bash
# Query work items using familiar syntax
plane query "state:backlog AND priority:high"
plane query "type:Bug AND labels:frontend"
plane query "created:>2024-01-01 AND assignee:@me"

# Output formats
plane query "..." --format=table   # Default
plane query "..." --format=yaml    # Export to YAML
plane query "..." --format=json    # JSON export
plane query "..." --format=ids     # Just IDs for piping
```

**Query Syntax**:
```
field:value           # Exact match
field:~pattern        # Regex match
field:>value          # Greater than (dates, numbers)
field:<value          # Less than
AND, OR, NOT          # Boolean operators
(...)                 # Grouping
```

### 3.2 Bulk Update
```bash
# Update multiple items
plane update "state:backlog AND priority:none" --set priority=low
plane update "type:task" --set type=Story
plane update "labels:old-label" --remove-label=old-label --add-label=new-label

# Preview changes
plane update "..." --set ... --dry-run

# From file (for complex updates)
plane update --from=updates.yaml
```

**Implementation**:
- Query parsing and validation
- Batch API calls with rate limiting
- Transaction-like behavior (all or nothing per batch)
- Detailed change reporting

### 3.3 Schema Rationalization
```bash
# Analyze schema usage across projects
plane schema audit --all

# Output:
# - Unused types (defined but no issues)
# - Unused states (never transitioned to)
# - Unused labels
# - Inconsistent naming across projects
# - Custom fields with low usage

# Generate cleanup recommendations
plane schema audit --all --recommend
```

**Implementation**:
- Usage statistics collection
- Cross-project analysis
- Safe cleanup suggestions (never auto-delete)

---

## Phase 4: Enterprise Infrastructure

**Goal**: Support enterprise deployment patterns and compliance requirements.

### 5.1 Audit Logging
```bash
# All CLI operations logged
plane push  # Logged: who, when, what changed

# Query audit log
plane audit --since=2024-01-01 --user=alice
plane audit --project=BACKEND --action=schema.push
```

### 5.2 Policy Enforcement
```yaml
# .plane/policies.yaml
policies:
  - name: require-severity-on-bugs
    type: Bug
    require:
      - properties.severity
    message: "Bugs must have severity set"

  - name: no-direct-done
    deny:
      transition:
        from: Backlog
        to: Done
    message: "Issues must go through In Progress"
```

### 5.3 SSO/SAML Integration
```bash
# Enterprise authentication
plane auth login --sso
plane auth login --saml --provider=okta
```

### 5.4 Offline Mode
```bash
# Work without network (for air-gapped environments)
plane push --offline  # Queue changes locally
plane sync --when-online  # Sync when connected
```

---

## Implementation Priority Matrix

| Phase | Feature | Effort | Impact | Priority |
|-------|---------|--------|--------|----------|
| 1.1 | Path-based operations | Low | High | P0 |
| 1.2 | --all batch operations | Medium | High | P0 |
| 1.3 | Schema extends | Medium | High | P1 |
| 1.4 | Affected detection | Medium | Medium | P2 |
| 2.1 | Jira import | High | High | P1 |
| 2.2 | Schema merge | High | Medium | P2 |
| 2.3 | Bulk issue migration | Medium | Medium | P2 |
| 3.1 | Query command | Medium | High | P1 |
| 3.2 | Bulk update | Medium | High | P1 |
| 3.3 | Schema audit | Low | Medium | P2 |
| 4.x | Enterprise infra | High | High | P3 |

---

## Success Metrics

### Small Teams (1-10 projects)
- Project init to first push: < 5 minutes
- Learning curve: productive in 1 hour
- No required configuration beyond `plane.yaml`

### Medium Organizations (10-100 projects)
- Cross-project operations: < 30 seconds
- Schema inheritance reduces duplication by 70%+
- Affected detection speeds CI by 50%+

### Enterprise (100+ projects, M&A scenarios)
- Jira migration: 10,000 issues/hour
- Schema merge: handle 3000+ custom fields
- Audit compliance: 100% operation tracking
- Zero-downtime migrations

---

## Non-Goals (Plane Platform Responsibility)

These capabilities require Plane platform changes, not Plane Compose:
- Real-time collaboration
- Search indexing at scale
- Permission management
- Storage/attachment handling
- API performance at 10K concurrent users
- Cross-datacenter replication

Plane Compose focuses on the developer experience layer: schema-as-code, migrations, and bulk operations.
