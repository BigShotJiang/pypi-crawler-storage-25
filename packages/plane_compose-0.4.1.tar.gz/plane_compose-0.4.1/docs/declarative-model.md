# Plane Compose Declarative Model

Plane Compose follows a **declarative, infrastructure-as-code** approach inspired by Terraform. This document explains the core principles and how each command fits into the model.

## Core Principle: Local is Source of Truth

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         DECLARATIVE MODEL                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│   LOCAL FILES                    STATE FILE              REMOTE (Plane)  │
│   ───────────                    ──────────              ──────────────  │
│   schema/types.yaml              .plane/state.json       Work Item Types │
│   schema/workflows.yaml    ◄───► (ID mappings)     ◄───► States          │
│   schema/labels.yaml             (sync tracking)         Labels          │
│   work/inbox.yaml                                        Work Items      │
│                                                                          │
│   ▲                                                                      │
│   │                                                                      │
│   └── SOURCE OF TRUTH                                                    │
│       (You edit these files)                                             │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

**Key insight**: Your local YAML files define the desired state. Plane Compose makes the remote match your local definition.

## How It Works (Compared to Terraform)

| Terraform | Plane Compose | Purpose |
|-----------|---------------|---------|
| `.tf` files | `schema/*.yaml`, `work/*.yaml` | Define desired state |
| `terraform.tfstate` | `.plane/state.json` | Track remote IDs & sync status |
| `terraform plan` | `plane schema diff` | Show what would change |
| `terraform apply` | `plane push`, `plane schema push` | Make remote match local |
| `terraform import` | `plane schema import` | Connect local to existing remote |
| `terraform refresh` | `plane schema import` (default) | Update state from remote |

## Command Reference

### Schema Commands

#### `plane schema push`
**Purpose**: Make remote schema match local (create new items)

```bash
plane schema push           # Push types, states, labels to Plane
plane schema push --dry-run # Preview what would be created
plane schema push --force   # Skip confirmation
```

**Behavior**:
- Creates types/states/labels that exist locally but not in remote
- Does NOT delete items that exist only in remote (additive)
- Updates `.plane/state.json` with new remote IDs

#### `plane schema import`
**Purpose**: Connect local schema to remote (Terraform-style import)

```bash
# Default: State-only (no file changes)
plane schema import

# Merge: Add missing items from remote (additive)
plane schema import --merge

# Force: Replace local with remote (destructive)
plane schema import --force
```

**Modes**:

| Mode | Files Changed? | Use Case |
|------|---------------|----------|
| Default | NO | Connect existing local schema to remote IDs |
| `--merge` | Adds only | Get new types/states from remote without losing local changes |
| `--force` | Full overwrite | Reset local to match remote (use with caution) |

**Default mode output**:
```
✓ State updated (local files unchanged)
  Types: 3/3 matched
  States: 7/7 matched
  Labels: 5/5 matched

Only in remote (not in local schema):
  Types: Epic, Hotfix

Run 'plane schema import --merge' to add these locally
```

#### `plane schema diff`
**Purpose**: Show differences between local and remote (read-only)

```bash
plane schema diff
```

**Output**:
```
Schema Comparison: Local ↔ Remote

Types:
  + Only in local: CustomType
  - Only in remote: LegacyType
  = In both: 5 types

States:
  = In both: 8 states

Labels:
  + Only in local: urgent
```

#### `plane schema sync`
**Purpose**: Declarative sync - make remote EXACTLY match local

```bash
plane schema sync           # Full sync (would delete remote-only items)
plane schema sync --dry-run # Preview changes
```

**Warning**: This command will delete states and labels in remote that don't exist locally. Use `--dry-run` to preview before applying.

### Work Item Commands

#### `plane push`
**Purpose**: Push work items from local to Plane

```bash
plane push                    # Push current directory
plane push ./projects/api     # Push specific project
plane push --all              # Push all projects
plane push --dry-run          # Preview what would be pushed
plane push --schema-only      # Only push schema, not work items
plane push --work-only        # Only push work items, not schema
```

**Behavior**:
- Creates new work items from `work/inbox.yaml`
- Updates existing work items if content changed
- Tracks synced items in `.plane/state.json`

#### `plane pull`
**Purpose**: Fetch work items from Plane to local

```bash
plane pull                    # Pull to .plane/remote/items.yaml
plane pull --output=my.yaml   # Custom output file
plane pull --merge            # Merge with existing file
plane pull --work-only        # Skip schema pull
```

**Note**: This fetches work items for review, not for editing. Edit `work/inbox.yaml` for changes you want to push.

#### `plane status`
**Purpose**: Show project sync status

```bash
plane status                  # Current directory
plane status ./projects/api   # Specific project
plane status --all            # All projects
```

### Multi-Project Commands

#### Path-based operations
```bash
plane push ./projects/api       # Operate on specific project
plane pull ./projects/frontend
plane status ./projects/backend
```

#### Batch operations
```bash
plane push --all                        # All projects
plane push --all --workspace=myteam     # Filter by workspace
plane status --all --filter="projects/*" # Filter by path pattern
```

## File Structure

```
myproject/
├── plane.yaml              # Project configuration
├── schema/
│   ├── types.yaml          # Work item type definitions
│   ├── workflows.yaml      # State definitions
│   └── labels.yaml         # Label definitions
├── work/
│   └── inbox.yaml          # Work items to push
└── .plane/
    ├── state.json          # Sync state (ID mappings, hashes)
    └── remote/
        └── items.yaml      # Pulled items (read-only reference)
```

## State File (`.plane/state.json`)

The state file tracks the connection between local and remote:

```json
{
  "last_sync": "2024-01-15T10:30:00Z",
  "types": {
    "Bug": "uuid-123",
    "Feature": "uuid-456"
  },
  "states": {
    "Backlog": "uuid-789",
    "In Progress": "uuid-abc"
  },
  "labels": {
    "Frontend": "uuid-def"
  },
  "work_items": {
    "PROJ-1": {
      "remote_id": "uuid-work-1",
      "content_hash": "abc123",
      "source": "work/inbox.yaml:0"
    }
  }
}
```

**Important**: Never edit this file manually. It's managed by Plane Compose.

## Workflow Examples

### Starting a New Project

```bash
# Initialize project structure
plane init MYPROJ -w myteam

# Edit schema files as needed
vim schema/types.yaml

# Push schema to Plane
plane schema push

# Add work items
vim work/inbox.yaml

# Push work items
plane push
```

### Connecting to Existing Project

```bash
# Clone the project
plane clone <project-uuid> --workspace myteam

# Or if you have local schema already:
plane schema import  # Connect local to remote IDs
```

### Adding Remote Types to Local

```bash
# See what's different
plane schema diff

# Add missing items from remote (safe, additive)
plane schema import --merge
```

### Resetting Local to Match Remote

```bash
# WARNING: This overwrites local files
plane schema import --force
```

### Multi-Project Workflow

```bash
# Check status of all projects
plane status --all

# Push all projects
plane push --all

# Push only specific workspace
plane push --all --workspace=engineering
```

## Best Practices

### 1. Local Files are Source of Truth
- Make changes in your YAML files, then push
- Don't make changes in Plane UI if you want them tracked in code
- Use `plane schema import --merge` to bring UI changes into local

### 2. Use Dry-Run First
```bash
plane push --dry-run
plane schema push --dry-run
```

### 3. Commit State File
The `.plane/state.json` should be committed to git. It tracks:
- Which items have been synced
- Remote UUIDs for local items
- Content hashes for change detection

### 4. Use Clone for New Projects
```bash
# Get someone else's project
plane clone <uuid> --workspace team

# Don't use schema import --force for this
```

### 5. Understand the Modes

| I want to... | Command |
|-------------|---------|
| Push my local changes | `plane push` |
| See what's different | `plane schema diff` |
| Connect local to remote IDs | `plane schema import` |
| Add remote items locally | `plane schema import --merge` |
| Reset local to remote | `plane schema import --force` |
| Get a fresh copy | `plane clone <uuid>` |

---

## Workspace-Level Declarative Sync

Plane Compose also supports **workspace-level** configuration management alongside project-level sync. This allows you to manage workspace infrastructure (releases, initiatives, custom properties) as code.

### Workspace Declarative Model

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    WORKSPACE DECLARATIVE MODEL                           │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│   LOCAL FILES                    STATE FILE              REMOTE (Plane)  │
│   ───────────                    ──────────              ──────────────  │
│   schema/releases.yaml           .plane/state.json      Releases        │
│   schema/initiatives.yaml  ◄───► (workspace mappings)   Initiatives    │
│   schema/workitemtypes.yaml      (sync tracking)        Custom Props    │
│                                                                          │
│   ▲                                                                      │
│   │                                                                      │
│   └── SOURCE OF TRUTH (workspace configuration)                          │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

**Key difference from projects**:
- Workspace sync is **additive only** (never deletes)
- Focuses on shared configuration, not work items
- Separate `.plane/state.json` per workspace

### Workspace Commands

| Goal | Command |
|------|---------|
| Clone workspace | `plane ws clone <workspace>` |
| Push releases/initiatives/states/relations | `plane ws push` |
| Pull updates | `plane ws pull` |
| Show differences | `plane ws diff` |
| Preview without changes | `plane ws push --dry-run` |
| Remove remote-only entries | `plane ws push --prune` |
| Merge mode (preserve local) | `plane ws pull --merge` |
| Overwrite with remote | `plane ws pull --force` |

### Workspace Sync Model

**Additive push** (default):
```bash
plane ws push
# Adds/updates releases, initiatives, project states, project labels, relation definitions
# Never deletes items from remote
# Safe for team collaboration
```

**Prune push** (explicit delete):
```bash
plane ws push --prune
# Additionally deletes remote entries absent from local YAML
# Supports: project states, project labels, custom relation definitions
# System-default relations (is_default: true) are always skipped
```

**No full declarative sync mode**: Unlike projects, workspace sync has no `ws sync` mode. Deletes are opt-in via `--prune`.

**Why?** Workspace configuration changes less frequently and accidental deletes of shared resources (states used by all projects) are high-impact.

### When to Use Workspace vs Project Sync

| Use Case | Level | Command |
|----------|-------|---------|
| Manage work items | Project | `plane push`, `plane pull` |
| Define project schema | Project | `plane schema push/import` |
| Manage releases | Workspace | `plane ws push` |
| Define initiatives | Workspace | `plane ws push` |
| Add custom properties | Workspace | `plane ws push` |
| Share type definitions | Workspace | `plane ws push` |

### See Also

- [Workspace Configuration](workspace-config.md) — Full reference
- [Workspace Recipes](workspace-recipes.md) — Step-by-step examples

---

## Comparison with Other Tools

### vs Terraform
- Same declarative model
- Local config → State file → Remote
- `import` connects existing resources
- `push` is like `apply`

### vs Git
- `push` sends local to remote
- `pull` fetches for review (not for editing)
- `clone` creates new local copy
- No automatic merge conflicts (you control the source of truth)

### vs Ansible
- Declarative (desired state) not imperative (steps)
- Idempotent - running twice has same result
- State tracking for change detection
