# Workspace Configuration Management

Plane Compose lets you manage workspace-level configuration as code — features, members, work item types, releases, initiatives, and more — alongside your project definitions.

---

## Table of Contents

1. [Overview](#overview)
2. [Workspace vs Project](#workspace-vs-project)
3. [Workspace Directory Structure](#workspace-directory-structure)
4. [Workspace YAML Files](#workspace-yaml-files)
5. [Workspace Sync Commands](#workspace-sync-commands)
6. [Configuration Examples](#configuration-examples)
7. [Best Practices](#best-practices)

---

## Overview

A **workspace** in Plane Compose is a directory containing workspace-level configuration synced from (or to) your Plane instance. Unlike projects, which represent individual work streams, a workspace represents your entire team's shared infrastructure:

- **Features**: Which features are enabled (modules, cycles, pages, etc.)
- **Members**: Who has access and their roles
- **Work Item Types**: Bug, Feature, Task, Chore, and custom types available to all projects
- **Releases**: Versioned product releases managed at the workspace level
- **Initiatives**: Strategic initiatives for organizing work across projects
- **Relations**: How work items can relate to each other
- **Webhooks**: Event integrations for the entire workspace
- **Project Labels**: Shared labels for workspace-level projects

---

## Workspace vs Project

### Project Level (`type: project`)
```yaml
type: project
workspace: myteam
project:
  key: API
  name: API Service
```

**Managed with:**
- `plane init` - Create new project
- `plane clone` - Clone existing project
- `plane push` / `plane pull` - Sync work items
- `plane schema push/pull/diff/sync` - Manage project schema

**Contains:**
- Work items (bugs, features, tasks)
- Project-specific states and workflows
- Project-specific labels
- Modules and cycles
- Custom properties for work items

### Workspace Level (`type: workspace`)
```yaml
type: workspace
workspace: myteam
connection: connection-1
```

**Managed with:**
- `plane ws clone` - Clone workspace configuration
- `plane ws push` / `plane ws pull` - Sync workspace settings
- `plane ws diff` - Review changes

**Contains:**
- Workspace feature flags
- Workspace members and roles
- Work item types (used by all projects)
- Custom properties for work items
- Releases and release tags
- Initiatives and their labels
- Work item relation definitions
- Webhooks and event integrations

### Typical Workflow
1. **Team lead** clones workspace: `plane ws clone myteam`
2. **Team lead** customizes workspace YAML (releases, initiatives)
3. **Team lead** pushes updates: `plane ws push`
4. **Individual developers** clone projects: `plane clone API -w myteam`
5. **Developers** work on projects independently

---

## Workspace Directory Structure

After `plane ws clone myteam`, you get:

```
myteam/
├── plane.yaml                    # Workspace context (type: workspace)
├── schema/
│   ├── features.yaml            # Feature flags (read-only)
│   ├── members.yaml             # Members with roles (read-only)
│   ├── workitemtypes.yaml       # Work item types, properties, hierarchy
│   ├── project.yaml             # Shared project states + labels (push/pull/prune)
│   ├── initiatives.yaml         # Initiative labels
│   ├── releases.yaml            # Release tags + release labels (config only)
│   ├── relations.yaml           # Work item relation definitions (push/pull/prune)
│   └── webhooks.yaml            # Webhook configurations (stub — no API key auth yet)
├── work/
│   └── releases.yaml            # Actual releases (operational data)
└── .plane/
    └── state.json               # Sync state (do NOT edit manually)
```

**`schema/` vs `work/` split**:
- **`schema/`** — configuration that defines *how* the workspace works (types, states, labels, relation types). Changes rarely.
- **`work/`** — operational data that changes frequently (actual releases). Maps to the Plane UI "Details" tab, not Settings.

### plane.yaml

The workspace context file. **Do not edit** — it's managed by `plane ws` commands:

```yaml
# Plane Workspace Configuration
# This is a workspace-level configuration file.
# Use 'plane workspace' commands to manage this file.

type: workspace
workspace: myteam
connection: connection-2
```

---

## Workspace YAML Files

### 1. features.yaml — Feature Flags

**Purpose**: Enables/disables workspace features.

**Status**: Read-only (managed via Plane UI under Workspace Settings).

**Example**:
```yaml
# Workspace Feature Flags
# Controls which features are enabled in the workspace.
# These flags are set via Plane's workspace settings and are read-only here.

features:
  project_grouping: true
  initiatives: true
  teams: true
  customers: true
  wiki: true
  pi: true
  work_item_types: true
```

**Edit via**: Plane Web UI → Workspace Settings → Features.

---

### 2. members.yaml — Workspace Members

**Purpose**: Lists all members and their roles in the workspace.

**Status**: Read-only (managed via Plane UI under Members).

**Example**:
```yaml
# Workspace Members
# Lists all members in the workspace with their roles.
# This information is synced from Plane and is read-only here.
#
# Example:
# members:
#   - email: user1@example.com
#     id: <uuid>
#     display_name: User One
#   - email: user2@example.com
#     id: <uuid>
#     display_name: User Two

members:
  - id: 77e8c6ce-ca96-45cc-a73c-ac3fac887438
    email: alice@company.com
    display_name: Alice Chen
  - id: a9f2e4b1-d8c3-4f2a-8e5c-1b3d7a9c2e4f
    email: bob@company.com
    display_name: Bob Smith
```

**Edit via**: Plane Web UI → Members.

---

### 3. workitemtypes.yaml — Work Item Types and Properties

**Purpose**: Defines work item types (Bug, Feature, Task, etc.) and custom properties available to all projects.

**Status**: Partially editable (can add custom properties).

**Sections**:
- `work_item_types`: Type definitions with icons, levels, and descriptions
- `properties`: Workspace-level custom property definitions
- `hierarchy`: Type hierarchy (parent-child relationships based on levels)

**Example**:
```yaml
# Workspace Work Item Types
# Defines work item types available across all projects in the workspace.
# This information is synced from Plane and is read-only here.
#
# Sections:
# - work_item_types: Type definitions with icons, levels, and descriptions
# - properties: Workspace-level custom property definitions
# - hierarchy: Type hierarchy (parent-child relationships based on levels)

work_item_types:
  Bug:
    id: ee6639e2-5bfc-41c9-b7ed-94b6ec287e7a
    description: A defect or issue requiring fix
    is_default: true
    is_active: true
    level: 0
    icon:
      name: bug
      color: '#eb144c'
  
  Feature:
    id: f1a2b3c4-d5e6-7f8g-9h0i-j1k2l3m4n5o6
    description: Net-new functionality or capability
    is_default: true
    is_active: true
    level: 0
    icon:
      name: sparkles
      color: '#0693e3'

properties:
  - id: prop-123
    name: Customer Priority
    type: OPTION
    options:
      - name: Critical
        color: '#eb144c'
      - name: High
        color: '#fcb900'
      - name: Medium
        color: '#7bdcb5'
      - name: Low
        color: '#a3e635'

hierarchy:
  - type: Epic
    level: 0
  - type: Feature
    level: 1
    parent_types:
      - Epic
  - type: Task
    level: 2
    parent_types:
      - Feature
```

**Edit via**:
- Plane Web UI → Workspace Settings → Work Item Types (for custom properties)
- Or manage custom properties in this YAML file

---

### 4. project.yaml — Shared Project Labels

**Purpose**: Labels shared across workspace-level projects.

**Status**: Partially editable (can add labels locally).

**Example**:
```yaml
# Workspace Project Configuration
# Shared labels and states for workspace-level projects.
# This information is synced from Plane and is read-only here.

labels:
  - id: 780d448c-4159-4999-8905-f7503131af05
    name: Marketing
    color: '#8ED1FC'
    sort_order: 25.0
  - id: 754710b2-6924-4089-b283-6e20bd0b86c5
    name: Design
    color: '#9900EF'
    sort_order: 35.0
  - id: f5e9c2d8-1a3b-4c5d-6e7f-8a9b0c1d2e3f
    name: Engineering
    color: '#00D084'
    sort_order: 45.0

states: []
```

**Supported operations**: pull (fetched on `plane ws clone/pull`), push (create/update via `plane ws push`), prune (delete via `plane ws push --prune`).

---

### 5. initiatives.yaml — Initiative Labels

**Purpose**: Labels for organizing strategic initiatives.

**Status**: Editable (add/update labels).

**Example**:
```yaml
# Workspace Initiatives Configuration
# Labels for organizing and tracking workspace-level strategic initiatives.
# This information is synced from Plane and is read-only here.

labels:
  - id: ef212cb0-767c-4540-a7e5-b059d0fa6455
    name: Q1 Growth
    color: '#8ED1FC'
    sort_order: 65535.0
  - id: e0cfd37f-21ac-467f-b49a-18480bf8d243
    name: Tech Debt Reduction
    color: '#9900EF'
    sort_order: 75535.0
  - id: d1e8c9f6-4b2a-4d3e-5f6g-7h8i9j0k1l2m
    name: Infrastructure Upgrade
    color: '#00D084'
    sort_order: 85535.0
```

**How to use**:
1. Add labels to `initiatives.yaml`
2. Run `plane ws push` to create them in Plane
3. Assign initiatives to work items in projects

---

### 6. releases.yaml — Releases and Release Tags

**Purpose**: Product releases managed at the workspace level.

**Status**: Editable (add/update releases and tags).

**Example**:
```yaml
# Workspace Releases Configuration
# Manages product releases, release tags, and associated labels.
# This information is synced from Plane and is read-only here.

releases:
  - id: 80877da5-0097-4bb4-babe-73f3ad5d731c
    name: v1.0.0
    status: released
    is_latest: true
    is_prerelease: false
    tag: v1.0.0
    description: First stable release

  - id: 9b988eb6-1f08-5cc5-cbcf-84g4be6e842d
    name: v1.1.0-beta
    status: unreleased
    is_latest: false
    is_prerelease: true
    tag: v1.1.0-beta
    description: Beta release with new features

release_tags:
  - id: tag-001
    name: Major
    color: '#eb144c'
  - id: tag-002
    name: Minor
    color: '#fcb900'
  - id: tag-003
    name: Patch
    color: '#7bdcb5'

labels:
  - id: release-label-001
    name: Documentation
    color: '#0693e3'
  - id: release-label-002
    name: Breaking Changes
    color: '#ff0000'
```

**How to use**:
1. Define releases in this file
2. Run `plane ws push` to sync to Plane
3. Assign work items to releases in projects
4. Track feature completeness by release

---

### 7. relations.yaml — Work Item Relations

**Purpose**: Defines how work items can relate to each other (e.g., "implements", "depends on").

**Status**: Fully supported — pull, push (create/update), and prune (delete) all available.

**Example**:
```yaml
# Workspace Work Item Relations
# System-default relations (is_default: true) cannot be deleted.
# Custom relations can be created, updated, or removed via plane ws push [--prune].
#
# IMPORTANT: name, outward, and inward must each be unique across all relations.

relations:
  - id: 891cbc15-4a40-46a3-ace5-0472001ed6e6
    name: Relates to
    outward: relates to
    inward: relates to
    is_default: true
    sort_order: 65535.0
  - id: 29f6ae4d-cd50-4e18-b550-85c110b3500d
    name: Implements
    outward: implements
    inward: implemented by
    is_default: true
    sort_order: 196605.0
  - id: <uuid>
    name: Depends on
    outward: blocks
    inward: is blocked by
    sort_order: 262140.0
```

**System default relations** (`is_default: true` — cannot be deleted):
- `Relates to` — General bidirectional relationship
- `Duplicate` — Duplicate issue reference
- `Implements` — Implementation relationship

**Custom relations**: Add entries without `id` and run `plane ws push` to create them. Remove entries and run `plane ws push --prune` to delete them.

**Constraint**: `name`, `outward`, and `inward` must each be unique across all relations in the workspace.

---

### 8. webhooks.yaml — Webhooks

**Purpose**: Configure webhooks to receive notifications about workspace events.

**Status**: Mostly stub (no v1 API route for API key auth yet).

**Example**:
```yaml
# Workspace Webhooks
# Configure webhooks to receive notifications about workspace events.
# This information is synced from Plane and is read-only here.
# Secrets are never stored locally; manage them via the Plane web interface.

webhooks: []
```

**Typical webhook events**:
- Work item created/updated/deleted
- Cycle started/ended
- Module created/completed
- Comment added

**Note**: Webhooks require session auth (no v1 API route yet). Manage via Plane Web UI.

---

## Workspace Sync Commands

### Clone a Workspace

**Purpose**: Get a local copy of workspace configuration.

```bash
# Interactive (choose workspace)
plane ws clone

# Specific workspace
plane ws clone myteam -c connection-2

# Into a specific directory
plane ws clone myteam -c connection-2 --path ./workspaces/
```

**Creates**:
- `myteam/` directory with all workspace YAML files
- `.plane/state.json` to track sync state
- All files include descriptive headers explaining structure

---

### Pull Workspace Changes

**Purpose**: Fetch latest workspace config from Plane.

**Three modes**:

**Default** (prompt on conflicts):
```bash
cd myteam/
plane ws pull
```
Shows which files differ and prompts before overwriting.

**Merge** (preserve local additions):
```bash
plane ws pull --merge
```
- Remote data overwrites existing entries
- Local-only entries (e.g., releases you added) are kept
- No confirmation prompt

**Force** (remote always wins):
```bash
plane ws pull --force
```
Discards all local changes. Use for CI/CD or clean reset.

---

### Push Workspace Changes

**Purpose**: Share workspace additions with Plane.

**Behavior**: Only additive (never deletes remote items).

```bash
# Default (prompt for confirmation)
cd myteam/
plane ws push

# Preview without making changes
plane ws push --dry-run

# Push without confirmation
plane ws push --force
```

**What gets pushed**:
- ✅ `releases.yaml` — New releases, tags, labels
- ✅ `initiatives.yaml` — New/updated initiative labels
- ✅ `project.yaml` — New/updated project states and labels (+ `--prune` to delete)
- ✅ `relations.yaml` — New/updated custom relation definitions (+ `--prune` to delete)
- ⏭️ `workitemtypes.yaml` — Use `plane schema push` instead
- ❌ `features.yaml` — Use Plane UI (admin settings)
- ❌ `members.yaml` — Use Plane UI (team management)
- ❌ `webhooks.yaml` — No API key auth support yet

---

### Show Differences

**Purpose**: Review changes before pulling.

```bash
cd myteam/
plane ws diff
```

Shows what would change if you pulled from Plane.

---

### Manage Sync State

**Purpose**: Inspect and reset workspace sync tracking.

```bash
# Show state
plane ws state show

# Reset state (forget what's synced)
plane ws state reset
```

---

## Configuration Examples

### Example 1: Team Onboarding

**Scenario**: New team member joins. Set up their workspace.

```bash
# 1. Lead clones workspace
plane ws clone myteam -c connection-2

# 2. Review current state
cd myteam/
plane ws diff

# 3. Member pulls to stay in sync
plane ws pull

# 4. Member clones a project
cd ..
plane clone API -w myteam

# 5. Member starts working
cd api/
plane schema push
plane push
```

### Example 2: Managing Releases

**Scenario**: Product team manages releases in code.

**File**: `myteam/schema/releases.yaml`
```yaml
releases:
  - name: v2.0.0
    status: planning
    tag: v2.0.0
    description: Major update with breaking changes
    is_prerelease: true
  - name: v1.5.1
    status: released
    tag: v1.5.1
    description: Patch release
```

```bash
# Push new releases
plane ws push

# Now projects can assign work items to v2.0.0
# See progress in Plane UI
```

### Example 3: Custom Work Item Properties

**Scenario**: Add company-specific field (e.g., "Customer Priority").

**File**: `myteam/schema/workitemtypes.yaml`
```yaml
work_item_types:
  Feature:
    # ... existing config ...
    properties:
      - Customer Priority
      - OKR Alignment

properties:
  - id: prop-cust-priority
    name: Customer Priority
    type: OPTION
    options:
      - name: Enterprise
        color: '#eb144c'
      - name: High Value
        color: '#fcb900'
      - name: Standard
        color: '#7bdcb5'
```

```bash
# Sync to all projects
plane ws push
plane schema push
```

---

## Best Practices

### 1. **Commit `.plane/state.json` to Git**

Keep your team in sync:
```bash
git add myteam/.plane/state.json
git commit -m "Sync workspace state"
```

### 2. **Use `--merge` by Default**

Preserve local customizations:
```bash
plane ws pull --merge
```

### 3. **Use `--dry-run` Before Push**

Preview changes:
```bash
plane ws push --dry-run
```

### 4. **Document Workspace Decisions**

Add comments to YAML files explaining your choices:
```yaml
# Custom property added for compliance tracking (2024-01-15)
properties:
  - name: Compliance Checkbox
    type: BOOLEAN
```

### 5. **Keep Features and Members as Single Source of Truth in UI**

Don't try to manage these in YAML:
- ✅ Manage features in Plane UI → Workspace Settings
- ✅ Manage members in Plane UI → Members
- ❌ Don't try to edit them locally

### 6. **Use Releases for Product Planning**

Track feature completeness by release:
```yaml
releases:
  - name: Q1 2024 Release
    status: planning
```

### 7. **Use Initiatives for Strategy**

Organize cross-project work:
```yaml
# initiatives.yaml
labels:
  - name: "Strategic: API Overhaul"
  - name: "Strategic: Mobile App"
  - name: "Tech Debt: Legacy Code"
```

---

## Troubleshooting

### Q: I edited `features.yaml` but changes won't push.
**A**: Features are admin-only. Manage in Plane UI → Workspace Settings → Features.

### Q: Members I added locally don't show up.
**A**: Members are managed in Plane UI only. Local additions are ignored on pull.

### Q: Can I push custom relations?
**A**: Yes! Add a new entry to `relations.yaml` (without `id`) and run `plane ws push`. To delete a relation, remove it from the YAML and run `plane ws push --prune`. Note: system-default relations (`is_default: true`) cannot be deleted.

### Q: State file got messed up. How do I reset?
**A**: 
```bash
plane ws state reset
plane ws pull --force
```

### Q: Can I manage workspace for multiple Plane instances?
**A**: Yes! Use different connections:
```bash
plane ws clone myteam -c connection-cloud
plane ws clone myteam -c connection-self-hosted
```

---

## See Also

- [Workspace Recipes](workspace-recipes.md) — Step-by-step workflows
- [Plane Compose Reference](plane-compose.md) — Full command reference
- [Declarative Model](declarative-model.md) — How sync works under the hood
