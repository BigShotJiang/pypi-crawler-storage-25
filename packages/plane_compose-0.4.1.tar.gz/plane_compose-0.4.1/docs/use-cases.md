# Use Cases

Real-world scenarios showing how different teams use Plane Compose to manage projects as code.

---

## Table of Contents

1. [Startup: Bootstrap a Product from Day One](#1-startup-bootstrap-a-product-from-day-one)
2. [Agency: Templatize Client Projects](#2-agency-templatize-client-projects)
3. [Open-Source: Community-Driven Project Management](#3-open-source-community-driven-project-management)
4. [Platform Team: Manage Services Across a Monorepo](#4-platform-team-manage-services-across-a-monorepo)
5. [DevOps: Infrastructure Change Tracking](#5-devops-infrastructure-change-tracking)
6. [Remote Team: Git-Based Sprint Planning](#6-remote-team-git-based-sprint-planning)
7. [Migration: Moving from Another Tool](#7-migration-moving-from-another-tool)
8. [Compliance: Auditable Work Tracking](#8-compliance-auditable-work-tracking)
9. [Product Team: Manage Releases and Product Roadmap](#9-product-team-manage-releases-and-product-roadmap) — **NEW**: Workspace-level release and initiative management

---

## 1. Startup: Bootstrap a Product from Day One

**Situation**: You're starting a new product. You want project management that lives with your code, not in a separate tool that nobody opens.

### The Setup

```bash
plane auth login
plane init CORE -w acme
cd core/
```

Customize the schema for your product:

```yaml
# schema/types.yaml
Feature:
  description: User-facing capability
  workflow: default
  properties:
    - name: target_release
      type: option
      options: [mvp, v1.1, v1.2, backlog]
    - name: customer_impact
      type: option
      options: [low, medium, high, critical]

Bug:
  description: Something broken
  workflow: default
  properties:
    - name: severity
      type: option
      required: true
      options: [cosmetic, minor, major, critical]
    - name: environment
      type: option
      options: [dev, staging, production]

Spike:
  description: Research or investigation task
  workflow: default
  properties:
    - name: timebox_hours
      type: number
```

```yaml
# schema/workflows.yaml
default:
  states:
    - name: Icebox
      group: backlog
      color: "#94a3b8"
    - name: Next Up
      group: unstarted
      color: "#3b82f6"
    - name: In Progress
      group: started
      color: "#f59e0b"
    - name: In Review
      group: started
      color: "#8b5cf6"
    - name: Shipped
      group: completed
      color: "#22c55e"
    - name: Won't Fix
      group: cancelled
      color: "#ef4444"
```

### Populate your first sprint

```yaml
# work/mvp.yaml
- id: MVP-1
  title: User registration and login
  type: Feature
  state: In Progress
  priority: urgent
  labels:
    - Backend
  properties:
    target_release: mvp
    customer_impact: critical
  children:
    - id: MVP-1a
      title: Email/password registration
      type: Feature
      state: In Progress
    - id: MVP-1b
      title: OAuth with Google
      type: Feature
      state: Next Up
    - id: MVP-1c
      title: Password reset flow
      type: Feature
      state: Icebox

- id: MVP-2
  title: Dashboard with key metrics
  type: Feature
  state: Next Up
  priority: high
  labels:
    - Frontend
  properties:
    target_release: mvp
    customer_impact: high

- id: SPIKE-1
  title: Evaluate Stripe vs Paddle for payments
  type: Spike
  state: In Progress
  priority: medium
  properties:
    timebox_hours: 8
```

```bash
plane schema push
plane push
```

### Why this works

- **Schema in git**: New engineers clone the repo and immediately understand your workflow, types, and states.
- **Work items reviewable**: Sprint planning is a PR. "Here are the 12 items for this sprint" — reviewable, commentable, approvable.
- **No drift**: The schema in Plane always matches what's in code. No one silently renames states in the UI.

---

## 2. Agency: Templatize Client Projects

**Situation**: You run a dev agency. Every client project needs the same structure — types, workflows, labels — but different work items.

### Create a template

```bash
plane init TEMPLATE -w agency
cd template/
```

Define your agency's standard schema:

```yaml
# schema/types.yaml
Story:
  description: User-facing feature
  workflow: default
  properties:
    - name: estimate_hours
      type: decimal
    - name: billable
      type: boolean

Bug:
  description: Defect
  workflow: default
  properties:
    - name: severity
      type: option
      options: [low, medium, high, critical]
    - name: client_reported
      type: boolean

Design:
  description: Design task
  workflow: default
  properties:
    - name: figma_link
      type: url

DevOps:
  description: Infrastructure or deployment task
  workflow: default
```

```yaml
# schema/workflows.yaml
default:
  states:
    - name: Backlog
      group: backlog
      color: "#64748b"
    - name: Approved
      group: unstarted
      color: "#3b82f6"
    - name: In Progress
      group: started
      color: "#f59e0b"
    - name: Client Review
      group: started
      color: "#8b5cf6"
    - name: Deployed
      group: completed
      color: "#22c55e"
    - name: On Hold
      group: cancelled
      color: "#f97316"
```

```yaml
# schema/labels.yaml
- name: Phase 1
  color: "#3b82f6"
- name: Phase 2
  color: "#8b5cf6"
- name: Phase 3
  color: "#f97316"
- name: Blocker
  color: "#ef4444"
- name: Client-Facing
  color: "#10b981"
```

### Start a new client project

Copy the template directory:

```bash
cp -r template/ clients/acme-corp
cd clients/acme-corp
```

Edit `plane.yaml`:

```yaml
workspace: agency
project:
  key: ACME
  name: Acme Corp Website Redesign
defaults:
  type: Story
  workflow: default
```

Add client-specific work:

```yaml
# work/phase-1.yaml
- id: ACME-1
  title: Wireframe homepage layout
  type: Design
  state: Approved
  labels: [Phase 1, Client-Facing]
  properties:
    estimate_hours: 12
    billable: true

- id: ACME-2
  title: Implement responsive nav component
  type: Story
  state: Backlog
  labels: [Phase 1]
  properties:
    estimate_hours: 8
    billable: true
```

```bash
plane schema push
plane push
```

Every client project starts with the same structure. Consistent reporting, consistent workflow.

---

## 3. Open-Source: Community-Driven Project Management

**Situation**: You maintain an open-source project. You want contributors to propose work items via PRs — triageable, reviewable, merged like code.

### Project structure

```bash
plane init MYLIB -w oss
cd mylib/
```

```yaml
# schema/types.yaml
Bug:
  description: Confirmed defect
  workflow: default
  properties:
    - name: severity
      type: option
      options: [low, medium, high, critical]
    - name: reproducible
      type: boolean

Feature:
  description: New feature request (approved)
  workflow: default
  properties:
    - name: rfc_link
      type: url
    - name: breaking_change
      type: boolean

Enhancement:
  description: Improvement to existing functionality
  workflow: default

Docs:
  description: Documentation update
  workflow: default
```

```yaml
# schema/labels.yaml
- name: good-first-issue
  color: "#7c3aed"
- name: help-wanted
  color: "#2563eb"
- name: breaking
  color: "#dc2626"
- name: needs-rfc
  color: "#f59e0b"
- name: v2.0
  color: "#059669"
- name: v2.1
  color: "#0891b2"
```

### Contributors propose items via PR

A contributor creates a PR adding to `work/community.yaml`:

```yaml
- id: COMMUNITY-47
  title: Add TOML config file support
  type: Feature
  state: Backlog
  labels:
    - help-wanted
  description: |
    Support loading configuration from `config.toml` in addition
    to the existing YAML and JSON formats.

    Ref: https://github.com/mylib/mylib/discussions/234
  properties:
    breaking_change: false
```

The maintainer reviews the PR, adjusts priority/labels/assignees, merges, and the item syncs to Plane automatically via CI.

### CI config

```yaml
# .github/workflows/plane-sync.yml
name: Sync to Plane
on:
  push:
    branches: [main]
    paths: ['work/**', 'schema/**']
jobs:
  sync:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: pipx install plane-compose
      - run: plane push --force
        env:
          PLANE_API_KEY: ${{ secrets.PLANE_API_KEY }}
```

---

## 4. Platform Team: Manage Services Across a Monorepo

**Situation**: Your platform team manages 5 microservices. Each has its own project in Plane, but they share a repository.

### Monorepo layout

```
platform/
├── services/
│   ├── auth/
│   │   ├── plane.yaml
│   │   ├── schema/
│   │   └── work/
│   ├── billing/
│   │   ├── plane.yaml
│   │   ├── schema/
│   │   └── work/
│   ├── notifications/
│   │   ├── plane.yaml
│   │   ├── schema/
│   │   └── work/
│   ├── gateway/
│   │   ├── plane.yaml
│   │   ├── schema/
│   │   └── work/
│   └── analytics/
│       ├── plane.yaml
│       ├── schema/
│       └── work/
```

Each service has its own `plane.yaml`:

```yaml
# services/auth/plane.yaml
workspace: platform
project:
  key: AUTH
  name: Auth Service
```

```yaml
# services/billing/plane.yaml
workspace: platform
project:
  key: BILLING
  name: Billing Service
```

### Batch operations

```bash
# Status for all services
plane status --all --workspace=platform

# Push all at once
plane push --all --workspace=platform

# Push only gateway
plane push ./services/gateway

# Pull everything
plane pull --all
```

### Cross-service dependencies

In `services/gateway/work/inbox.yaml`:

```yaml
- id: GW-12
  title: Rate limit per-service API keys
  type: Feature
  state: Backlog
  priority: high
  description: |
    Depends on AUTH-45 (API key scoping) being completed first.
    Cross-service dependency — coordinate with auth team.
```

### Why this works

- Each service team owns their `work/` files.
- Shared schema across services (or per-service customization — your choice).
- `plane push --all` in CI keeps everything in sync.
- One repo, one `git log`, full traceability.

---

## 5. DevOps: Infrastructure Change Tracking

**Situation**: Track infrastructure changes, incidents, and runbook items alongside your Terraform/Pulumi code.

```bash
plane init INFRA -w ops
cd infra/
```

```yaml
# schema/types.yaml
Incident:
  description: Production incident requiring response
  workflow: default
  properties:
    - name: severity
      type: option
      required: true
      options: [sev1, sev2, sev3, sev4]
    - name: affected_service
      type: option
      options: [api, web, database, cdn, auth]
    - name: incident_commander
      type: relation
      relation_type: user
    - name: postmortem_link
      type: url

Change:
  description: Infrastructure change request
  workflow: default
  properties:
    - name: risk_level
      type: option
      options: [low, medium, high]
    - name: rollback_plan
      type: text
    - name: maintenance_window
      type: datetime

Runbook:
  description: Operational runbook or procedure
  workflow: default

Alert:
  description: Monitoring alert to investigate
  workflow: default
  properties:
    - name: source
      type: option
      options: [datadog, pagerduty, cloudwatch, custom]
```

```yaml
# work/changes.yaml
- id: CHG-101
  title: Upgrade RDS from db.r5 to db.r6g
  type: Change
  state: Ready
  priority: medium
  labels:
    - Database
  properties:
    risk_level: medium
    rollback_plan: "Snapshot before upgrade. Failover to read replica if needed."
    maintenance_window: "2026-03-15T02:00:00"

- id: CHG-102
  title: Enable WAF on CloudFront distributions
  type: Change
  state: Backlog
  labels:
    - Security
  properties:
    risk_level: low
```

---

## 6. Remote Team: Git-Based Sprint Planning

**Situation**: Your team is fully remote across time zones. Sprint planning happens asynchronously via PRs.

### The workflow

1. **Tech lead** creates the sprint file as a PR:

```yaml
# work/sprint-22.yaml
- id: S22-1
  title: Implement search indexing pipeline
  type: Feature
  state: Ready
  priority: high
  assignees:
    - alice@example.com
  due_date: "2026-03-14"

- id: S22-2
  title: Fix memory leak in worker process
  type: Bug
  state: Ready
  priority: urgent
  assignees:
    - bob@example.com
  due_date: "2026-03-07"
  properties:
    severity: major

- id: S22-3
  title: Add Prometheus metrics to gateway
  type: Improvement
  state: Ready
  priority: medium
  due_date: "2026-03-14"
  # No assignee yet — up for grabs
```

2. **Team members** review the PR, comment, request changes:
   - "I think S22-2 is a sev:critical, not major"
   - "I can take S22-3"
   - "S22-1 needs to be split — it's too big for one sprint"

3. **Updates are made** in the PR, then merged.

4. **CI pushes** to Plane automatically.

5. **Mid-sprint updates**: Engineers update states in the YAML and push, or update in the Plane UI directly.

### Pull remote changes back

If someone updates items in the Plane UI:

```bash
plane pull
# Items saved to .plane/remote/items.yaml
```

Review what changed and decide whether to update your `work/` files.

---

## 7. Migration: Moving from Another Tool

**Situation**: You're migrating from Jira, Linear, Asana, or Trello to Plane. Use Plane Compose to set up the structure first.

### Step 1: Define your target schema

Map your old tool's concepts to Plane Compose:

```yaml
# schema/types.yaml — map from old tool
Story:                    # Jira: Story, Linear: Feature
  description: User story
  workflow: default
  properties:
    - name: story_points
      type: number
    - name: original_key     # Track the old Jira key
      type: text

Bug:                      # Same across tools
  description: Defect
  workflow: default
  properties:
    - name: severity
      type: option
      options: [low, medium, high, critical]
    - name: original_key
      type: text

Epic:                     # Jira: Epic, Linear: Project
  description: Large initiative
  workflow: default
  is_epic: true
  properties:
    - name: target_quarter
      type: option
      options: [Q1, Q2, Q3, Q4]
    - name: original_key
      type: text

Task:                     # Jira: Task, Linear: Task
  description: Technical task
  workflow: default
  properties:
    - name: original_key
      type: text
```

### Step 2: Push the schema

```bash
plane schema push
```

### Step 3: Export from old tool and convert to YAML

Export your items from the old tool (CSV, JSON, API), then convert to Plane Compose YAML format. Example for items exported from Jira:

```yaml
# work/migrated.yaml
- id: MIG-1
  title: User authentication flow
  type: Story
  state: In Progress
  priority: high
  labels:
    - Backend
  properties:
    story_points: 8
    original_key: "JIRA-1234"
  description: |
    Migrated from Jira.
    Original: https://yourcompany.atlassian.net/browse/JIRA-1234

- id: MIG-2
  title: Dashboard performance regression
  type: Bug
  state: Backlog
  priority: medium
  properties:
    severity: major
    original_key: "JIRA-1567"
```

### Step 4: Push

```bash
plane push
```

The `original_key` property preserves traceability back to the old tool.

---

## 8. Compliance: Auditable Work Tracking

**Situation**: Your organization requires auditable change tracking for work items — who changed what, when, and why.

### Why Plane Compose helps

- Every change to work items is a **git commit** with author, timestamp, and message.
- Sprint plans are **PRs** with review trails.
- Schema changes are version-controlled — no one silently modifies workflows.
- `.plane/state.json` in git provides a complete mapping of local → remote IDs.

### Structure

```yaml
# schema/types.yaml
Requirement:
  description: Tracked requirement with compliance metadata
  workflow: default
  properties:
    - name: compliance_ref
      type: text
    - name: risk_level
      type: option
      options: [low, medium, high]
    - name: approved_by
      type: relation
      relation_type: user
    - name: approval_date
      type: date
    - name: review_status
      type: option
      options: [draft, in_review, approved, rejected]
```

```yaml
# work/requirements.yaml
- id: REQ-001
  title: All PII must be encrypted at rest
  type: Requirement
  state: Approved
  priority: urgent
  labels:
    - Security
    - Compliance
  properties:
    compliance_ref: "SOC2-CC6.1"
    risk_level: high
    review_status: approved
    approval_date: "2026-01-15"
  description: |
    All personally identifiable information stored in databases
    must use AES-256 encryption at rest.

    References:
    - SOC2 CC6.1
    - Internal policy SEC-003
```

### The audit trail

```bash
git log --oneline work/requirements.yaml
# a1b2c3d Add REQ-001 through REQ-010 (alice, 2026-01-15)
# d4e5f6g Update REQ-003 risk level to high (bob, 2026-02-01)
# g7h8i9j Add REQ-011 through REQ-015 (carol, 2026-02-10)
```

Every change is traceable. The commit history *is* the audit log.

---

## 9. Product Team: Manage Releases and Product Roadmap

**Situation**: You have multiple projects (mobile, backend, frontend) but releases, initiatives, and custom properties should be shared and managed centrally as code.

### Why Plane Compose helps

- **Workspace configuration** lets you manage releases, initiatives, and custom properties in code
- **Multiple projects** can share releases and reference them consistently
- **Git-based roadmap** makes planning transparent and auditable
- **Team alignment** — releases defined once, used everywhere

### Structure

**Workspace configuration** (managed separately from projects):

```bash
plane ws clone acme -c connection-1
cd acme/
```

**Releases** (defined once for entire product):

```yaml
# schema/releases.yaml
releases:
  - name: v2.0.0
    status: planning
    tag: v2.0.0
    description: |
      Major release with:
      - New authentication system
      - Improved mobile experience
      - Performance optimizations

  - name: v1.5.1
    status: released
    tag: v1.5.1
    is_latest: true
    description: Patch release

release_tags:
  - name: Breaking Changes
    color: '#ff0000'
  - name: Performance
    color: '#9900EF'
  - name: Security
    color: '#FF6900'
```

**Product roadmap** (initiatives across all projects):

```yaml
# schema/initiatives.yaml
labels:
  - name: "Q1 2026: Platform Reliability"
    description: Focus on uptime and performance
  
  - name: "Q1 2026: User Experience"
    description: Mobile-first improvements
  
  - name: "Q2 2026: Enterprise Features"
    description: Multi-tenant, SSO, audit logs
  
  - name: "Tech Debt: Refactor Auth"
    description: Modernize authentication
```

**Custom properties** (shared across projects):

```yaml
# schema/workitemtypes.yaml
properties:
  - name: Release Target
    type: option
    options: [v1.5.1, v2.0.0, v2.1.0, backlog]
  
  - name: Initiative
    type: option
    options: [Q1 Platform Reliability, Q1 User Experience, Q2 Enterprise, Tech Debt]
  
  - name: Customer Impact
    type: option
    options: [Enterprise Critical, High Value, Standard, Internal]
```

### Use in Projects

Each project references workspace releases and initiatives:

```bash
cd ../frontend/  # One of multiple projects
```

```yaml
# work/features.yaml
- id: FE-1
  title: Mobile app redesign
  type: Feature
  state: In Progress
  release: v2.0.0          # From workspace releases.yaml
  properties:
    Initiative: Q1 User Experience      # From workspace initiatives.yaml
    Release Target: v2.0.0
    Customer Impact: High Value

- id: FE-2
  title: Fix iOS list scrolling
  type: Bug
  state: In Progress
  release: v1.5.1
  properties:
    Initiative: Q1 Platform Reliability
    Release Target: v1.5.1
    Customer Impact: Standard

- id: FE-3
  title: Modernize auth module
  type: Chore
  state: Backlog
  properties:
    Initiative: Tech Debt: Refactor Auth
    Release Target: backlog
    Customer Impact: Internal
```

```bash
plane push
```

### Managing the Roadmap

**Product manager updates the roadmap**:

```bash
cd ../acme/  # Back to workspace

# Edit releases for next quarter
vim schema/releases.yaml

# Commit and push
git add schema/releases.yaml
git commit -m "Plan v3.0.0 release with enterprise features"
git push

# Sync to Plane
plane ws push
```

**All projects immediately see new releases**:

```bash
cd ../frontend/
plane schema push

# Now developers can assign work to v3.0.0
```

### View Progress

In Plane UI:
- Go to **Releases** section
- See all work items assigned to each release across all projects
- Track feature completeness by release
- View initiative progress across the entire product

### Key Workflow

```
1. PM edits workspace releases/initiatives in Git
   ↓
2. PM pushes to Plane (plane ws push)
   ↓
3. Team syncs latest (git pull, plane schema push)
   ↓
4. Developers assign work to releases/initiatives
   ↓
5. Team tracks progress in Plane UI
   ↓
6. At release time, all work mapped to release is visible
```

### See Also

- [Workspace Configuration](workspace-config.md) — Full reference
- [Workspace Recipes](workspace-recipes.md) — Step-by-step examples
- [Recipe: Manage Product Releases](workspace-recipes.md#3-manage-product-releases) — Detailed walkthrough
