# Plane Compose

**Project as Code for [Plane](https://plane.so)** — a Terraform-like CLI for managing projects, schemas, and work items via YAML files with declarative sync.

```bash
pipx install plane-compose
```

---

## Quick Start

Get a project running in Plane in under 2 minutes:

```bash
# 1. Authenticate (one-time setup)
plane auth login
# → Enter Plane URL (default: https://app.plane.so) and API key

# 2. Initialize a project (stores workspace + connection in plane.yaml)
plane init MYPROJ -w myteam
# → Creates: myproj/ directory with all scaffolding

# 3. Navigate to project
cd myproj/
```

This creates the following structure:

```
myproj/
├── plane.yaml              # Project configuration (workspace + connection)
├── schema/                 # Configuration — types, states, labels (Settings)
│   ├── features.yaml       # Feature toggles (cycles, modules, pages, etc.)
│   ├── types.yaml          # Work item types (Bug, Feature, Improvement, Chore)
│   ├── workflows.yaml      # States (Icebox → Backlog → Ready → In Progress → Done)
│   └── labels.yaml         # Labels (Frontend, Backend, Infrastructure, etc.)
├── work/                   # Operational data — work items, cycles, modules
│   ├── workitems.yaml      # Work items go here
│   ├── cycles.yaml         # (optional) Cycle definitions
│   └── modules.yaml        # (optional) Module definitions
└── .plane/
    └── state.json          # Sync state (tracks remote IDs)
```

All subsequent commands automatically use workspace + connection from `plane.yaml` — no flags needed!

Now add a work item. Edit `work/workitems.yaml`:

```yaml
- id: API-1
  title: Set up authentication middleware
  type: Feature
  state: Backlog
  priority: high
  labels:
    - Backend
  description: |
    Add JWT-based auth middleware for all API routes.
```

Push everything to Plane:

```bash
# Push schema (creates project, types, states, labels)
plane schema push

# Push work items
plane push
```

Open Plane — your project and items are live.

---

## Core Concepts

### Project Structure

Every Plane Compose project lives in a directory with this layout:

```
my-project/
├── plane.yaml              # Project config (workspace, project key, defaults)
├── schema/                 # Configuration — defines structure (Settings tab)
│   ├── features.yaml       # Feature toggles (cycles, modules, pages, etc.)
│   ├── types.yaml          # Work item type definitions + custom properties
│   ├── workflows.yaml      # Workflow states grouped by lifecycle stage
│   └── labels.yaml         # Project labels with colors
├── work/                   # Operational data (Details tab — changes frequently)
│   ├── workitems.yaml      # Work items (default file — add more as needed)
│   ├── cycles.yaml         # (optional) Cycle definitions
│   └── modules.yaml        # (optional) Module definitions
├── .plane/
│   └── state.json          # Sync state — maps local names to remote UUIDs
└── .gitignore
```

### Declarative Model

Plane Compose follows a **local-is-source-of-truth** model, like Terraform:

```
LOCAL FILES (schema/ + work/)  →  STATE (.plane/state.json)  →  REMOTE (Plane)
     ▲
     └── SOURCE OF TRUTH (you edit these)
```

- **Local files** are what you author and commit to git.
- **State** maps local names to remote UUIDs — it's the bridge between your YAML and Plane's database.
- **Remote** is the Plane instance.

### Sync Modes

| Mode | Command | Behavior |
|------|---------|----------|
| **Additive push** | `plane schema push` | Creates missing items in remote. Never deletes. Safe default. |
| **Declarative sync** | `plane schema sync` | Makes remote match local exactly — creates, updates, and deletes. |
| **Work item push** | `plane push` | Creates/updates work items in remote. |
| **Pull** | `plane pull` | Fetches remote work items to `work/workitems.yaml`. |

### State Tracking

The `.plane/state.json` file tracks:

- **Schema mappings**: local name → remote UUID for types, states, and labels
- **Work item tracking**: stable ID → remote UUID + content hash + source file
- **Last sync time**: when the state was last updated

Content hashing detects changes — if you modify a work item, the next `plane push` knows to update it rather than create a duplicate.

**Commit `.plane/state.json` to git** so your team shares the same sync state.

---

## Project Configuration — `plane.yaml`

```yaml
# Connection & Workspace (created by plane init)
workspace: myteam                 # Workspace slug (from your Plane URL)
connection: connection-1          # Connection name (auto-generated: connection-1, connection-2, etc.)
                                  # Auto-populated by plane init

# Project Info
project:
  key: API                        # Short project key (uppercase)
  name: API Service               # Human-readable project name
  # uuid: <auto-populated>        # Filled after first schema push

# Defaults for work items
defaults:
  type: Story                     # Default type for work items without a type field
  workflow: default               # Default workflow name

# Optional
api_url: https://api.plane.so     # API endpoint (default; change for self-hosted)
```

**After `plane init`**: `workspace` and `connection` are automatically populated. Subsequent commands inherit these values, so you don't need `-w` or `-c` flags.

**After first `plane schema push`**: `project.uuid` is automatically added.

**Notes:**
- `workspace` and `connection` are auto-populated by `plane init` — no manual edits needed
- All subsequent commands inherit these values automatically

### Self-Hosted Plane

Point `api_url` to your instance:

```yaml
api_url: https://plane.yourcompany.com
```

Or set the environment variable:

```bash
export PLANE_API_URL=https://plane.yourcompany.com
```

Then run `plane auth login` — it will use your custom server URL.

---

## Workspace Configuration (Optional)

In addition to managing individual projects, Plane Compose lets you manage **workspace-level configuration** — features, releases, initiatives, custom properties, and more.

### When to Use Workspace Management

**Use `plane ws` commands when you need to:**
- Define workspace releases as code (v1.0, v2.0, etc.)
- Create strategic initiatives (OKRs, quarterly goals)
- Add custom work item properties (customer priority, compliance fields, etc.)
- Share work item types across multiple projects
- Manage workspace configuration in a version-controlled repository

**Skip workspace management if you:**
- Only have one project
- Don't need shared configuration
- Prefer managing everything in Plane UI

### Workspace Directory Structure

```
myteam/                          # Workspace directory
├── plane.yaml                   # Workspace context (type: workspace)
├── schema/                      # Configuration — defines structure (Settings tab)
│   ├── features.yaml           # Feature flags (read-only)
│   ├── members.yaml            # Team members (read-only)
│   ├── workitemtypes.yaml      # Work item types + custom properties
│   ├── project.yaml            # Shared project states + labels (push/pull/prune)
│   ├── initiatives.yaml        # Initiative labels
│   ├── releases.yaml           # Release tags + release labels (config only)
│   ├── relations.yaml          # Work item relation definitions (push/pull/prune)
│   └── webhooks.yaml           # Webhooks (stub — no API key auth)
├── work/                        # Operational data — changes frequently (Details tab)
│   └── releases.yaml           # Actual releases (versions, dates, status)
└── .plane/
    └── state.json              # Sync state (tracks mappings)
```

### Workspace plane.yaml

Different from project `plane.yaml` — includes `type: workspace`:

```yaml
# Plane Workspace Configuration
type: workspace
workspace: myteam
connection: connection-2
```

### Basic Workflow

```bash
# 1. Clone workspace (get local copy)
plane ws clone myteam -c connection-2

# 2. Customize workspace YAML
cd myteam/
vim schema/releases.yaml
vim schema/initiatives.yaml

# 3. Sync changes
plane ws pull      # Get latest from Plane
plane ws push      # Push local changes

# 4. Keep in sync with team
git add schema/
git commit -m "Add v2.0 release"
git push
```

### Key Differences: Project vs Workspace

| Aspect | Project | Workspace |
|--------|---------|-----------|
| **Directory** | `api/`, `frontend/`, etc. | `myteam/` |
| **plane.yaml** | `type: project` | `type: workspace` |
| **Contains** | Work items, project schema | Shared configuration |
| **Clone** | `plane clone API -w myteam` | `plane ws clone myteam -c connection-1` |
| **Sync** | `push`, `pull`, `schema push/pull` | `ws push`, `ws pull` |
| **Examples** | Features, bugs, tasks | Releases, initiatives, properties |

### See Also

For complete workspace documentation, see:
- [Workspace Configuration](workspace-config.md) — Full reference guide
- [Workspace Recipes](workspace-recipes.md) — Step-by-step workflows

---

## Schema Reference

### types.yaml

Defines work item types and their custom properties. Supports two formats:

**Dict format** (recommended for authoring):

```yaml
Bug:
  description: A defect or issue requiring fix
  workflow: default
  properties:
    - name: severity
      type: option
      required: true
      options:
        - cosmetic
        - minor
        - major
        - critical
    - name: environment
      type: option
      options:
        - development
        - staging
        - production
    - name: is_regression
      type: boolean

Feature:
  description: Net-new functionality or capability
  workflow: default
  properties:
    - name: design_link
      type: url
    - name: target_date
      type: datetime
    - name: customer_requested
      type: boolean

Improvement:
  description: Enhancement to existing functionality
  workflow: default

Chore:
  description: Maintenance, ops, or housekeeping work
  workflow: default
```

**List format** (produced by import):

```yaml
- name: Bug
  description: A defect or issue requiring fix
  workflow: default
  properties:
    - name: severity
      type: option
      options: [cosmetic, minor, major, critical]
```

Both formats are accepted. Dict format is cleaner for hand-editing.

#### Type Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `description` | string | — | Human-readable description |
| `workflow` | string | `"default"` | Associated workflow name |
| `properties` | list | `[]` | Custom field definitions (see below) |
| `logo_props` | object | — | Icon configuration (`icon`, `background_color`, `emoji`) |
| `is_epic` | boolean | `false` | Whether this is an epic type |
| `is_default` | boolean | `false` | Default type for new work items |
| `level` | number | `0.0` | Hierarchy level for display ordering |
| `parent_types` | list | `[]` | Which types this can be a child of |

#### Custom Property Types

| Type | Description | Extra Fields |
|------|-------------|--------------|
| `text` | Free-text input | — |
| `number` | Integer value | — |
| `decimal` | Decimal/float value | — |
| `date` | Date picker (YYYY-MM-DD) | — |
| `datetime` | Date and time picker | — |
| `option` | Dropdown select | `options` (list of values), `is_multi` (allow multiple) |
| `relation` | User or issue picker | `relation_type`: `"user"` or `"issue"` |
| `boolean` | True/false toggle | — |
| `url` | URL field | — |
| `email` | Email field | — |
| `file` | File attachment | — |

Aliases: `string` → `text`, `enum` → `option`, `user` → `relation`.

#### Property Definition Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `name` | string | required | Field identifier |
| `display_name` | string | — | Human-readable label for UI |
| `type` | string | required | One of the property types above |
| `required` | boolean | `false` | Whether field must have a value |
| `default` | any | — | Default value |
| `options` | list | — | Allowed values (for `option` type) |
| `is_multi` | boolean | `false` | Allow multiple selections |
| `is_active` | boolean | `true` | Whether field is enabled |
| `relation_type` | string | — | `"user"` or `"issue"` (for `relation` type) |

#### Case-Insensitive Matching

Type, state, and label names are matched **case-insensitively** when syncing with Plane. If your remote has `"bug"` and your local has `"Bug"`, they'll be recognized as the same item.

---

### workflows.yaml

Defines workflows as named sets of states. Each state belongs to a **state group** that controls its lifecycle behavior.

```yaml
default:
  states:
    # Backlog group — items not yet prioritized
    - name: Icebox
      group: backlog
      color: "#94a3b8"
    - name: Backlog
      group: backlog
      color: "#64748b"

    # Unstarted group — ready to work on
    - name: Ready
      group: unstarted
      color: "#3b82f6"

    # Started group — actively being worked on
    - name: In Progress
      group: started
      color: "#f59e0b"
    - name: In Review
      group: started
      color: "#8b5cf6"
    - name: Testing
      group: started
      color: "#06b6d4"

    # Completed group
    - name: Done
      group: completed
      color: "#22c55e"

    # Cancelled group
    - name: Cancelled
      group: cancelled
      color: "#ef4444"
```

#### State Groups

| Group | Purpose |
|-------|---------|
| `backlog` | Not yet prioritized |
| `unstarted` | Ready to start |
| `started` | Actively in progress |
| `completed` | Done |
| `cancelled` | Cancelled/abandoned |
| `triage` | System-managed by Plane — **ignored during push** |

> **Note on triage**: Plane manages a default triage state automatically. You don't need to define it in your workflow, and it's skipped during schema push.

#### State Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `name` | string | required | State name |
| `description` | string | — | State description |
| `color` | string | — | Hex color code (e.g., `"#22c55e"`) |
| `group` | string | `"unstarted"` | State group (see table above) |

---

### labels.yaml

Defines project labels. **Flat list format** (recommended):

```yaml
- name: Frontend
  color: "#3b82f6"

- name: Backend
  color: "#10b981"

- name: Infrastructure
  color: "#6366f1"

- name: Documentation
  color: "#8b5cf6"

- name: Urgent
  color: "#ef4444"
```

#### Label Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `name` | string | required | Label name |
| `color` | string | `"#858585"` | Hex color code |

---

## Work Items — `work/*.yaml`

Work items are defined as YAML lists in any file under `work/`. Every `*.yaml` file in `work/` is treated as a work items file except the two reserved operational files: **`cycles.yaml`** and **`modules.yaml`**. All other files are loaded together on every `push`/`diff`.

```
work/
├── workitems.yaml     # Canonical default — clone/pull always write here
├── bugs.yaml          # (optional) Organize by type
├── sprint-12.yaml     # (optional) Sprint-specific items
└── q3-roadmap.yaml   # (optional) Organize by theme/release
```

> **Note**: `cycles.yaml` and `modules.yaml` are reserved — they hold cycle and module definitions respectively, not work items. Any other name is yours to use.

### Full Example

```yaml
- id: API-1
  title: Set up authentication middleware
  type: Feature
  state: Backlog
  priority: high
  start_date: "2026-03-01"
  due_date: "2026-03-15"
  labels:
    - Backend
  assignees:
    - alice@example.com
  watchers:
    - bob@example.com
  description: |
    Add JWT-based authentication middleware.

    ## Acceptance Criteria
    - Token validation on all /api routes
    - Refresh token support
  properties:
    design_link: https://figma.com/file/abc123
    customer_requested: true
  children:
    - id: API-1a
      title: Implement token validation
      type: Chore
      state: Ready
    - id: API-1b
      title: Add refresh token endpoint
      type: Chore
      state: Ready

- id: API-2
  title: Fix rate limiting bypass on /health
  type: Bug
  state: In Progress
  priority: urgent
  labels:
    - Backend
    - Urgent
  blocked_by:
    - API-1
  properties:
    severity: critical
    environment: production
    is_regression: true
```

### Field Reference

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `id` | string | No | — | Stable identifier for tracking (e.g., `"API-1"`). Highly recommended. |
| `title` | string | **Yes** | — | Work item title |
| `description` | string | No | — | Markdown description |
| `type` | string | No | `"Story"` | Work item type (must match a type in `types.yaml`) |
| `state` | string | No | — | Current state (must match a state in `workflows.yaml`) |
| `priority` | string | No | — | Priority level (e.g., `none`, `low`, `medium`, `high`, `urgent`) |
| `start_date` | string | No | — | Start date in `YYYY-MM-DD` format |
| `due_date` | string | No | — | Due date in `YYYY-MM-DD` format |
| `labels` | list | No | `[]` | Label names (must match labels in `labels.yaml`) |
| `assignees` | list | No | `[]` | Email addresses or user UUIDs |
| `watchers` | list | No | `[]` | Email addresses or user UUIDs to notify |
| `parent` | string | No | — | Parent work item ID (e.g., `"API-1"`) |
| `children` | list | No | `[]` | Nested child work items (inline hierarchy) |
| `blocked_by` | list | No | `[]` | IDs of work items blocking this one |
| `blocking` | list | No | `[]` | IDs of work items this one blocks |
| `duplicate_of` | string | No | — | ID of the original item if this is a duplicate |
| `relates_to` | list | No | `[]` | IDs of related work items |
| `properties` | dict | No | `{}` | Custom field values matching schema properties |

### Stable IDs

The `id` field is how Plane Compose tracks items across pushes:

- **With `id`**: The item is tracked by this key. Editing the title or description and running `plane push` will **update** the existing remote item.
- **Without `id`**: The item is tracked by content hash. If you change anything, Plane Compose treats it as a **new** item, potentially creating duplicates.

**Always use stable IDs** for items you plan to update over time.

### Multi-File Organization

All `.yaml` files under `work/` are automatically discovered. Use this for organization:

```yaml
# work/features.yaml
- id: FEAT-1
  title: OAuth2 integration
  type: Feature

# work/bugs.yaml
- id: BUG-1
  title: Login page 500 error
  type: Bug
```

---

## Command Reference

### Project Commands

#### `plane init`

Initialize a new Plane project structure. Stores workspace and connection in `plane.yaml`.

```bash
plane init                                          # Interactive mode
plane init MYPROJ -w myteam                        # Create with workspace flag
plane init MYPROJ -w myteam -c connection-1        # Specify connection
plane init MYPROJ -w myteam --path /projects       # Create in specific directory
```

| Argument | Description |
|----------|-------------|
| `PROJECT` | Project identifier/key (uppercase, e.g., `API`, `MYPROJ`) |

| Option | Short | Description |
|--------|-------|-------------|
| `--workspace` | `-w` | Workspace slug (required if PROJECT is provided) |
| `--connection` | `-c` | Connection ID (optional, required only if workspace exists on multiple connections) |
| `--path` | — | Parent directory for the project folder (default: current directory) |
| `--template` | `-t` | Template source (built-in, local path, or Git URL) |

**Template Sources**:

- **Built-in (default)**: `plane init MYPROJ -w myteam`
- **Local folder**: `plane init MYPROJ -w myteam --template ./my-templates/template1`
- **Git HTTPS**: `plane init MYPROJ -w myteam --template https://github.com/org/repo/templates/template1`
- **Git SSH**: `plane init MYPROJ -w myteam --template git@github.com:org/repo.git/templates/template1`

**Examples**:
```bash
# Built-in template
plane init MYPROJ -w myteam

# Local template
plane init MYPROJ -w myteam --template ./templates/custom
plane init MYPROJ -w myteam -t ~/plane-templates/agency

# Git template (HTTPS)
plane init MYPROJ -w myteam --template https://github.com/makeplane/templates/tree/main/agency-template

# Git template (SSH)
plane init MYPROJ -w myteam --template git@github.com:makeplane/templates.git/agency-template

# Interactive mode
plane init                          # Prompts for project, workspace, optionally template

# Specify connection explicitly
plane init MYPROJ -w myteam -c connection-1
```

Creates a directory named after the lowercase project key with scaffold files and `plane.yaml`.

**Using Custom Templates**:

Templates define the initial schema (types, workflows, labels) and work item structure for your project. You can use:

1. **Built-in template** (default):
   - Pre-configured schema: task, bug, feature, improvement, chore
   - Standard workflows: backlog, todo, in progress, done
   - Empty work directory

2. **Local template** (folder on disk):
   ```bash
   plane init MYPROJ -w myteam --template ./my-template-folder
   # Structure:
   # my-template-folder/
   # ├── schema/
   # │   ├── features.yaml
   # │   ├── types.yaml
   # │   ├── workflows.yaml
   # │   └── labels.yaml
   # └── work/
   #     └── workitems.yaml
   ```

3. **Git template** (GitHub or GitLab):
   ```bash
   # HTTPS
   plane init MYPROJ -w myteam --template https://github.com/org/repo/path/to/template
   
   # SSH
   plane init MYPROJ -w myteam --template git@github.com:org/repo.git/path/to/template
   ```

Templates are useful for:
- **Team standardization**: Same schema across all projects
- **Project types**: Agency/SaaS/product-specific templates
- **Best practices**: Pre-configured workflows and labels
- **Bulk initialization**: Clone templates across multiple projects

---

#### `plane upgrade`

Upgrade an existing project's schema (and optionally its data) to match a template.

Useful for standardizing schemas across multiple projects, or rolling out new schema conventions from a central template. The upgrade is **non-destructive**: local-only items (types, states, labels) are always preserved — the template only adds or updates.

```bash
plane upgrade -t ./my-template                                          # Schema upgrade, current dir
plane upgrade MYPROJ -t ./my-template                                   # Specific project folder
plane upgrade MYPROJ -t ./my-template --include-data                    # Schema + cycles/modules/workitems
plane upgrade MYPROJ -t https://github.com/org/repo/templates/standard # Remote template
plane upgrade MYPROJ -t ./my-template --dry-run                         # Preview without changes
plane upgrade MYPROJ -t ./my-template --schema-only                     # Apply locally, don't push
```

| Option | Short | Description |
|--------|-------|-------------|
| `--template` | `-t` | Template path or Git URL **(required)** |
| `--path` | — | Parent directory containing the project (default: current directory) |
| `--include-data` | — | Also copy cycles, modules, and work items from template |
| `--dry-run` | `-n` | Show upgrade plan only — make no changes |
| `--force` | `-f` | Skip confirmation prompts |
| `--skip-pull` | — | Skip pulling latest schema from Plane before computing diff |
| `--schema-only` | — | Update local YAML files only — do not push to Plane |

**What gets upgraded:**

| Category | Default (`--schema-only` or without `--include-data`) | With `--include-data` |
|----------|------------------------------------------------------|----------------------|
| Work Item Types | ✅ Added / updated | ✅ Added / updated |
| States | ✅ Added / updated | ✅ Added / updated |
| Labels | ✅ Added / updated | ✅ Added / updated |
| Features | ✅ Updated | ✅ Updated |
| Cycles | ❌ Skipped | ✅ New cycles added to `work/cycles.yaml` |
| Modules | ❌ Skipped | ✅ New modules added to `work/modules.yaml` |
| Work Items | ❌ Skipped | ✅ New items added to `work/workitems.yaml` |

> Local-only items are always preserved (shown as `LOCAL ONLY — will be preserved` in the plan).
> Duplicate detection by name/title — items that already exist locally are not re-added.

**Upgrade flow:**

1. Pulls latest schema from Plane (refreshes local state — skippable with `--skip-pull`)
2. Clones the template (local path or Git URL)
3. Computes diff between template and local
4. Shows the **Upgrade Plan** — additions, updates, preserved items, summary
5. Prompts for confirmation (skippable with `--force`)
6. Applies changes to local YAML files
7. Optionally pushes to Plane (full push when `--include-data`, schema push otherwise)

---

#### `plane clone <PROJECT>`

Clone an existing Plane project locally. Like `git clone` for Plane projects.

```bash
plane clone myteam/API                              # Workspace/key shorthand
plane clone API --workspace=myteam                   # Key with workspace flag
plane clone 8cee0da2-1b5b-4699-b11a-e3c8b26dd55d --workspace=myteam  # UUID
```

| Argument/Option | Description |
|-----------------|-------------|
| `PROJECT` | Project identifier — UUID, key, or `workspace/KEY` |
| `--workspace`, `-w` | Workspace slug (required for UUID or key formats) |
| `--directory`, `-d` | Directory name to clone into (default: project name) |
| `--with-properties` | Fetch custom property values (slower — requires extra API calls) |

**Identifier formats**:

| Format | Example | Requires `--workspace`? |
|--------|---------|------------------------|
| `workspace/KEY` | `myteam/API` | No |
| `KEY` | `API` | Yes |
| UUID | `8cee0da2-...` | Yes |

---

#### `plane status`

Show project sync status — schema counts, pending work items, last sync time.

```bash
plane status                          # Current project
plane status --all                    # All projects recursively
plane status --all --workspace=myteam # Filter by workspace
```

| Option | Short | Description |
|--------|-------|-------------|
| `--all` | — | Show status for all projects found recursively |
| `--workspace` | `-w` | Filter projects by workspace (with `--all`) |
| `--filter` | — | Filter projects by glob pattern (with `--all`) |

---

### Auth Commands

#### `plane auth login`

Authenticate with a Plane instance. Creates a new connection and links a workspace.

Supports three modes: fully interactive, semi-interactive, and fully non-interactive.

**Mode 1: Fully Interactive** (default):

```bash
plane auth login
```

**Prompts for:**
1. **Server URL** (default: `https://api.plane.so`)
2. **Auth type** — `(1) Personal Access Token (PAT)` or `(2) Workspace Token`
3. **Token/API Key** from your Plane workspace
4. **Workspace slug** (e.g., `myteam`)
5. **Connection name** (default: auto-generated as `connection-1`, `connection-2`, etc.)

**Mode 2: Semi-Interactive** (provide workspace + some flags):

When you provide `--workspace` and one or more flags, missing values are prompted. Environment variables are checked before prompting.

```bash
# Provide workspace, prompt for everything
plane auth login --workspace myteam
# → Prompts for: Server URL, Auth type, Token, Connection name

# Provide workspace and auth type, prompt for token
plane auth login \
  --server-url https://api.plane.so \
  --auth-type pat \
  --workspace myteam
# → Prompts for: Token, Connection name

# Use environment variables (no prompts for those values)
export PLANE_AUTH_TOKEN=$MY_TOKEN
plane auth login --workspace myteam --auth-type pat
# → Prompts for: Server URL, Connection name
# → Uses token from $PLANE_AUTH_TOKEN automatically

# Pure environment-based (no prompts if all env vars set)
export PLANE_SERVER_URL=https://api.plane.so
export PLANE_AUTH_TYPE=pat
export PLANE_AUTH_TOKEN=$MY_TOKEN
export PLANE_WORKSPACE=myteam
plane auth login
# → Only prompts for: Connection name (or uses $PLANE_CONNECTION if set)
```

**Mode 3: Fully Non-Interactive** (all flags provided):

```bash
plane auth login \
  --server-url https://api.plane.so \
  --auth-type pat \
  --token YOUR_API_KEY \
  --workspace myteam \
  [--connection my-conn]
```

**Options:**
- `--server-url` — Plane instance URL (default: `https://api.plane.so`)
- `--auth-type` — `pat`, `workspace`, `1`, or `2`
- `--token` — API key/token (prompted if not provided)
- `--workspace`, `-w` — Workspace slug (required to enable non-interactive/semi-interactive)
- `--connection`, `-c` — Connection name (optional; auto-generated if not provided)

**Environment Variables** (used as fallback if flags not provided):
- `PLANE_SERVER_URL` — Plane instance URL
- `PLANE_AUTH_TYPE` — Auth type: `pat`, `workspace`, `1`, or `2`
- `PLANE_AUTH_TOKEN` — API key/token (**standard for CI/CD**)
- `PLANE_WORKSPACE` — Workspace slug
- `PLANE_CONNECTION` — Connection name

**Output:**
- **Interactive modes**: Success/error messages with rich formatting
- **Non-interactive mode** (all flags + output mode): Only connection name on success (for CI/CD capture), error message on failure with exit code 1

**Examples:**

```bash
# Fully interactive
plane auth login
# → Prompts for: Server URL, Auth type, Token, Workspace, Connection name

# Semi-interactive: provide workspace, prompt for token
plane auth login --workspace myteam --auth-type pat
# → Prompts for: Server URL, Token, Connection name

# Semi-interactive with environment variable
export PLANE_AUTH_TOKEN=your_api_key
plane auth login --workspace myteam --auth-type pat --server-url https://api.plane.so
# → No prompts for token (uses $PLANE_AUTH_TOKEN)
# → Prompts for: Connection name

# Fully non-interactive with flags (CI/CD)
plane auth login \
  --server-url https://api.plane.so \
  --auth-type pat \
  --token $PLANE_API_KEY \
  --workspace myteam
# → Returns: connection-1

# Fully non-interactive with environment variables (Recommended for CI/CD)
export PLANE_SERVER_URL=https://api.plane.so
export PLANE_AUTH_TYPE=pat
export PLANE_AUTH_TOKEN=$PLANE_API_KEY
export PLANE_WORKSPACE=myteam
plane auth login
# → Returns: connection-1 (auto-generated)

# Or with custom connection name
export PLANE_CONNECTION=production
plane auth login
# → Returns: production

# Capture connection in CI/CD
CONNECTION=$(plane auth login)
echo "Using connection: $CONNECTION"
```

**Result:** Connection is created and saved to `~/.config/plane-compose/config.json`

---

#### `plane auth logout`

Remove a connection and all its linked workspaces.

```bash
plane auth logout <connection-id> [--force | -f]
```

**Options:**
- `--force` / `-f` — Skip confirmation prompt (useful for CI/CD scripts)

**Examples:**

Interactive mode (with confirmation):
```bash
plane auth logout connection-1
# Prompts: This will remove connection-1 and X workspace(s). Continue? [y/N]
```

Non-interactive mode (skip confirmation):
```bash
plane auth logout connection-1 --force
# Removes immediately without prompting
```

Or using short flag:
```bash
plane auth logout connection-1 -f
```

---

#### `plane auth list-connections`

Display all connections and their linked workspaces.

```bash
plane auth list-connections
```

**Output shows:**
- Connection ID (e.g., `connection-1`, `connection-2`)
- Auth type (PAT or workspace)
- Server URL
- Linked workspaces (marked with ★ if default)

---

### Schema Commands

#### `plane schema validate [PATH]`

Validate local schema files without connecting to Plane.

```bash
plane schema validate                 # Current directory
plane schema validate ./projects/api  # Specific project
```

---

#### `plane schema push [PATH]`

Push schema to Plane. Creates the project if it doesn't exist, then creates types, states, and labels that are missing from remote.

**Additive only** — never deletes or modifies existing remote items.

```bash
plane schema push                     # Current directory (inside project folder)
plane schema push --dry-run           # Preview changes
plane schema push --force             # Skip confirmation
plane schema push <project-dir>       # Specify project directory (from parent folder)
```

| Option | Short | Description |
|--------|-------|-------------|
| `--dry-run` | `-n` | Show what would be pushed without making changes |
| `--force` | `-f` | Push without confirmation prompt |

---

#### `plane schema import [PATH]`

Import schema from Plane with three modes:

```bash
# Default: state-only — map local names to remote UUIDs (no file changes)
plane schema import

# Merge: add missing remote items to local files (additive, safe)
plane schema import --merge

# Force: overwrite local schema files with remote (DESTRUCTIVE)
plane schema import --force
```

| Option | Short | Description |
|--------|-------|-------------|
| `--merge` | `-m` | Add missing items from remote to local (additive, no overwrites) |
| `--force` | `-f` | Replace local schema files with remote data (destructive, requires confirmation) |

**Mode comparison**:

| Mode | Modifies local files? | Modifies state? | Use case |
|------|-----------------------|-----------------|----------|
| Default | No | Yes | Connect local schema to remote IDs |
| `--merge` | Yes (additive) | Yes | Pick up types/states/labels created in the Plane UI |
| `--force` | Yes (destructive) | Yes | Start fresh from remote — writes types, states, workflows, labels, cycles, modules, members |

---

#### `plane schema diff [PATH]`

Compare local schema with remote. Shows items only in local, only in remote, and in both.

```bash
plane schema diff
plane schema diff ./projects/api
```

---

#### `plane schema sync [PATH]`

Declarative schema sync — makes remote match local **exactly**. Creates missing items, updates changed items, and flags items for deletion.

```bash
plane schema sync                     # Current directory
plane schema sync --dry-run           # Preview changes
plane schema sync --force             # Skip confirmation
```

| Option | Short | Description |
|--------|-------|-------------|
| `--dry-run` | `-n` | Show what would be synced without making changes |
| `--force` | `-f` | Sync without confirmation prompt |

> **Note**: Delete operations for states and labels are supported via the v1 API (available since 2026-05-04). `plane schema sync` will actually remove states and labels that exist only in remote.

For additive-only sync (no deletions), use `plane schema push` instead.

---

### Work Item Commands

#### `plane push [PATH]`

Push schema and work items to Plane.

```bash
plane push                            # Push schema + work items (inside project folder)
plane push --work-only                # Only push work items (skip schema)
plane push --schema-only              # Only push schema (skip work items)
plane push --dry-run                  # Preview changes
plane push <project-dir>              # Push specific project (from parent folder)
plane push --all                      # Push all projects recursively (from parent folder)
plane push --all --workspace=myteam   # Filter by workspace (with `--all`)
```

| Option | Short | Description |
|--------|-------|-------------|
| `--dry-run` | `-n` | Show what would be pushed without making changes |
| `--force` | `-f` | Push without confirmation |
| `--schema-only` | — | Only push schema (types, states, labels, cycles, modules) |
| `--work-only` | — | Only push work items |
| `--all` | — | Push all projects found recursively |
| `--workspace` | `-w` | Filter projects by workspace (with `--all`) |
| `--filter` | — | Filter projects by glob pattern (with `--all`) |

---

#### `plane pull [PATH]`

Fetch work items (and optionally schema) from Plane.

```bash
plane pull                             # Pull to work/workitems.yaml (inside project folder)
plane pull --output work/remote.yaml   # Custom output file
plane pull --work-only                 # Skip schema, only pull work items
plane pull --no-properties             # Skip custom property values (faster)
plane pull <project-dir>               # Pull specific project (from parent folder)
plane pull --all                       # Pull all projects recursively (from parent folder)
```

| Option | Short | Description |
|--------|-------|-------------|
| `--output` | `-o` | Output file path (default: `work/workitems.yaml`) |
| `--merge` | — | Merge with existing items in output file |
| `--force` | `-f` | Overwrite without confirmation |
| `--with-properties` / `--no-properties` | — | Fetch custom property values (default: yes) |
| `--work-only` | — | Pull only work items (skip schema) |
| `--all` | — | Pull all projects found recursively |
| `--workspace` | `-w` | Filter projects by workspace (with `--all`) |
| `--filter` | — | Filter projects by glob pattern (with `--all`) |

---

### State Commands

#### `plane state show`

Inspect the current sync state — tracked types, states, labels, and work items.

```bash
plane state show                      # Summary view
plane state show --verbose            # Detailed work item info
plane state show --json               # JSON output
```

| Option | Short | Description |
|--------|-------|-------------|
| `--verbose` | `-v` | Show all tracked work items (default shows first 20) |
| `--json` | — | Output as raw JSON |

---

#### `plane state reset`

Delete `.plane/state.json` entirely. The next push will treat all items as new.

```bash
plane state reset                     # With confirmation prompt
plane state reset --force             # Skip confirmation
```

> **Warning**: This may create duplicate work items if remote already has data. Use `plane schema import` after reset to reconnect state.

---

#### `plane state clear-items`

Clear only work item tracking while keeping schema mappings (types, states, labels).

```bash
plane state clear-items               # With confirmation prompt
plane state clear-items --force       # Skip confirmation
```

Useful for re-syncing work items without recreating schema.

---

#### `plane state remove <KEY>`

Remove a specific item from tracking.

```bash
plane state show                      # Find the tracking key
plane state remove API-1              # Remove it
```

---

### Rate Limit Commands

#### `plane rate stats`

Display rate limit statistics — total requests, utilization, wait times — for the current project's connection.

```bash
plane rate stats                      # Stats for connection in plane.yaml (inside project folder)
```

Statistics are tracked per-connection and persisted to disk.

#### `plane rate reset`

Reset rate limit counters for the current project's connection (does not reset actual rate limiting).

```bash
plane rate reset                      # Reset counters for connection in plane.yaml (inside project folder)
```

---

## Multi-Project Support

Manage multiple projects from a single parent directory:

```
projects/
├── api/
│   ├── plane.yaml
│   ├── schema/
│   └── work/
├── web/
│   ├── plane.yaml
│   ├── schema/
│   └── work/
└── mobile/
    ├── plane.yaml
    ├── schema/
    └── work/
```

Use `--all` to operate on all projects:

```bash
plane push --all                           # Push all projects
plane pull --all                           # Pull all projects
plane status --all                         # Status for all projects
```

Filter by workspace or glob pattern:

```bash
plane push --all --workspace=myteam        # Only projects in 'myteam' workspace
plane status --all --filter="api*"         # Only projects matching pattern
```

---

## Recipes

### Clone a Teammate's Project

```bash
plane clone myteam/API
cd api/
plane status
```

### Import an Existing Plane Project into Code

```bash
# Create local scaffold
plane init EXISTING -w myteam

cd existing/

# Import remote schema (overwrites scaffold with actual remote schema)
plane schema import --force

# Pull work items
plane pull
```

### Organize Work Across Multiple YAML Files

```yaml
# work/features.yaml — planned features
- id: FEAT-1
  title: OAuth2 integration
  type: Feature
  state: Backlog

# work/bugs.yaml — active bugs
- id: BUG-1
  title: Login 500 error
  type: Bug
  state: In Progress
  priority: urgent

# work/tech-debt.yaml — cleanup tasks
- id: CHORE-1
  title: Migrate to async handlers
  type: Chore
  state: Icebox
```

All files under `work/` are automatically discovered by `plane push`.

### Set Up a Monorepo with Multiple Projects

```bash
mkdir projects && cd projects
plane init API -w myteam
plane init WEB -w myteam
plane init MOBILE -w myteam

# Push all at once (each uses its own workspace + connection from plane.yaml)
plane push --all
```

### Self-Hosted Plane Setup

**Option 1: Interactive Setup**

```bash
# Authenticate against your self-hosted instance
plane auth login
# → Server URL: https://plane.yourcompany.com
# → Auth type: (1) Personal Access Token or (2) Workspace Token
# → Token: <paste your token>
# → Workspace slug: myteam
# → Connection name: connection-1 (auto-generated)

# Verify connection was created
plane auth list-connections

# Create a project
plane init API -w myteam
# → Uses connection-1 automatically

# Continue as normal (plane.yaml stores the connection)
cd api
plane schema push
plane push
```

**Option 2: Environment Variables (CI/CD)**

```bash
export PLANE_SERVER_URL=https://plane.yourcompany.com
export PLANE_AUTH_TYPE=pat
export PLANE_AUTH_TOKEN=YOUR_API_KEY
export PLANE_WORKSPACE=myteam

# Authenticate and initialize
plane auth login
# → No prompts, returns: connection-1

# Create a project
plane init API -w myteam
cd api
plane push
```

**Option 3: Non-interactive Flags**

```bash
plane auth login \
  --server-url https://plane.yourcompany.com \
  --auth-type pat \
  --token YOUR_API_KEY \
  --workspace myteam

# Initialize and push
plane init API -w myteam
cd api
plane push
```

### CI/CD Integration — Push on Merge

Two approaches for CI/CD: environment variables (recommended) or flags.

**Option 1: Environment Variables (Recommended)**

Cleanest approach - set env vars and plane-compose automatically picks them up:

```yaml
# .github/workflows/plane-sync.yaml
name: Sync to Plane
on:
  push:
    branches: [main]
    paths:
      - 'work/**'
      - 'schema/**'

jobs:
  sync:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Install plane-compose
        run: pipx install plane-compose
      
      - name: Authenticate and Push
        env:
          PLANE_SERVER_URL: https://api.plane.so
          PLANE_AUTH_TYPE: pat
          PLANE_AUTH_TOKEN: ${{ secrets.PLANE_API_KEY }}
          PLANE_WORKSPACE: ${{ secrets.PLANE_WORKSPACE }}
        run: |
          # Authenticate (creates connection automatically)
          plane auth login
          
          # Initialize project (if not in repo)
          if [ ! -f "plane.yaml" ]; then
            plane init PROJECT -w ${{ secrets.PLANE_WORKSPACE }}
          fi
          
          # Push to Plane
          plane push --force
```

**Option 2: Flag-based Authentication**

For explicit control:

```yaml
# .github/workflows/plane-sync.yaml
name: Sync to Plane
on:
  push:
    branches: [main]
    paths:
      - 'work/**'
      - 'schema/**'

jobs:
  sync:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Install plane-compose
        run: pipx install plane-compose
      
      - name: Authenticate with Plane
        run: |
          plane auth login \
            --server-url https://api.plane.so \
            --auth-type pat \
            --token ${{ secrets.PLANE_API_KEY }} \
            --workspace ${{ secrets.PLANE_WORKSPACE }}
      
      - name: Initialize project (if not in repo)
        run: |
          if [ ! -f "plane.yaml" ]; then
            plane init PROJECT -w ${{ secrets.PLANE_WORKSPACE }}
          fi
      
      - name: Push to Plane
        run: plane push --force
```

**Environment variables:**
- `PLANE_SERVER_URL` — Plane instance URL (default: https://api.plane.so)
- `PLANE_AUTH_TYPE` — Auth type: `pat` or `workspace` (default: `pat`)
- `PLANE_AUTH_TOKEN` — API token (required)
- `PLANE_WORKSPACE` — Workspace slug (required)
- `PLANE_CONNECTION` — Connection name (optional; auto-generated if not set)

**Required secrets:**
- `PLANE_API_KEY` — Your Plane API key from settings/account/api-tokens/
- `PLANE_WORKSPACE` — Your workspace slug

---

## Environment Variables

All environment variables use the `PLANE_` prefix.

| Variable | Default | Description |
|----------|---------|-------------|
| `PLANE_API_URL` | `https://api.plane.so` | Plane API endpoint |
| `PLANE_API_VERSION` | `v1` | API version |
| `PLANE_API_TIMEOUT` | `30` | API request timeout in seconds |
| `PLANE_API_RETRY_ATTEMPTS` | `3` | Number of retry attempts for failed requests |
| `PLANE_RATE_LIMIT_PER_MINUTE` | `50` | Max requests per minute |
| `PLANE_RATE_LIMIT_PER_HOUR` | `3000` | Max requests per hour |
| `PLANE_DEBUG` | `false` | Enable debug logging |
| `PLANE_VERBOSE` | `false` | Enable verbose output |
| `PLANE_LOG_TO_FILE` | `false` | Write logs to `~/.config/plane-compose/plane.log` |
| `PLANE_USE_RICH_OUTPUT` | `true` | Use rich text formatting |
| `PLANE_SHOW_PROGRESS_BARS` | `true` | Show progress bars |

---

## Troubleshooting

### Duplicate Work Items After Push

**Cause**: Items without stable `id` fields are tracked by content hash. Any change creates a "new" item.

**Fix**: Add `id` fields to your work items:

```yaml
- id: API-1          # <-- add this
  title: My item
```

Then run `plane state clear-items` and `plane push` to re-sync.

### "Type Not Found" Errors

**Cause**: Type names are case-insensitive. `bug` and `Bug` are the same type.

**Fix**: Ensure your `type` field matches a name in `schema/types.yaml`. Run `plane schema validate` to check.

### Rate Limit Errors

**Cause**: Default limit is 50 requests/minute.

**Fix**: Increase the limit:

```bash
export PLANE_RATE_LIMIT_PER_MINUTE=100
```

Check current usage with `plane rate stats`.

### Stale State / Out-of-Sync

**Cause**: State file references items that no longer exist remotely, or was corrupted.

**Fix**:

```bash
# Nuclear option — reset everything
plane state reset
plane schema import    # Re-link schema
plane push             # Re-push work items (may create duplicates)
```

Or selectively clear work items while keeping schema:

```bash
plane state clear-items
plane push
```

### Schema Push Creates Nothing

**Cause**: Items already exist in remote (case-insensitive match).

**Fix**: Run `plane schema diff` to see what's different. Run `plane schema import` to sync state with remote IDs.
