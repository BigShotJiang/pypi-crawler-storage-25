# Self-Hosted Plane Configuration

This guide explains how to use `plane-compose` with your own self-hosted Plane instance.

## Quick Start

### Option 1: Environment Variable (Global)

Set the `PLANE_API_URL` environment variable to point to your self-hosted instance:

```bash
# Add to ~/.zshrc, ~/.bashrc, or ~/.profile
export PLANE_API_URL="http://localhost:8000"
# OR
export PLANE_API_URL="https://plane.yourcompany.com"
```

Then reload your shell:
```bash
source ~/.zshrc  # or ~/.bashrc
```

Now all `plane` commands will use your self-hosted instance:

**Interactive:**
```bash
plane auth login
plane init my-project
plane schema push
```

**Non-interactive (CI/CD):**
```bash
export PLANE_AUTH_TOKEN="your-api-key"
export PLANE_WORKSPACE="myteam"
plane auth login
plane init my-project
plane schema push
```

### Option 2: Per-Project Configuration

Add `api_url` to your project's `plane.yaml`:

```yaml
workspace: my-workspace
api_url: http://localhost:8000  # Your self-hosted Plane URL
project:
  key: PROJ
  name: My Project

defaults:
  type: task
  workflow: standard
```

This allows different projects to use different Plane instances.

### Option 3: One-Time Override

Set the environment variable for a single command:

```bash
PLANE_API_URL="http://localhost:8000" plane schema push
```

## Getting Your API Key

For self-hosted Plane, get your API key from:

```
https://your-plane-url/<workspace-slug>/settings/account/api-tokens/
```

For example:
- `http://localhost:8000/myteam/settings/account/api-tokens/`
- `https://plane.yourcompany.com/engineering/settings/account/api-tokens/`

Then authenticate:

**Interactive:**
```bash
plane auth login
# Paste your API key when prompted
```

**Non-interactive:**
```bash
export PLANE_AUTH_TOKEN="your-api-key"
export PLANE_WORKSPACE="myteam"
plane auth login
```

## Common Self-Hosted URLs

### Local Development
```bash
export PLANE_API_URL="http://localhost:8000"
```

### Docker Compose
```bash
export PLANE_API_URL="http://localhost:8000"
# OR if using custom port
export PLANE_API_URL="http://localhost:3000"
```

### Self-Hosted with Domain
```bash
export PLANE_API_URL="https://plane.yourcompany.com"
```

### Behind Reverse Proxy
```bash
export PLANE_API_URL="https://plane.internal.company.com"
# OR with custom path
export PLANE_API_URL="https://company.com/plane"
```

## Verification

Check which API URL is being used:

```bash
# Method 1: Check environment
echo $PLANE_API_URL

# Method 2: Check plane.yaml
cat plane.yaml | grep api_url

# Method 3: Try authentication
plane auth whoami
```

## Troubleshooting

### Connection Refused

```bash
# Check if Plane is running
curl http://localhost:8000/api/v1/

# Check Docker containers (if using Docker)
docker ps | grep plane
```

### SSL Certificate Issues

For self-signed certificates in development:

```bash
# Option 1: Use HTTP instead of HTTPS
export PLANE_API_URL="http://localhost:8000"

# Option 2: Set Python to ignore SSL (NOT recommended for production)
export PYTHONHTTPSVERIFY=0
```

### Wrong API URL

If you're getting 404 errors, verify your API URL format:

```bash
# Correct formats:
export PLANE_API_URL="http://localhost:8000"          # ✅
export PLANE_API_URL="https://plane.company.com"      # ✅

# Incorrect formats (don't include /api/):
export PLANE_API_URL="http://localhost:8000/api"      # ❌
export PLANE_API_URL="http://localhost:8000/api/v1"   # ❌
```

The `/api/v1` path is added automatically by plane-compose.

### Network/Firewall Issues

```bash
# Test connectivity
curl -v http://localhost:8000/api/v1/

# Check firewall rules
sudo ufw status  # Ubuntu/Debian
sudo firewall-cmd --list-all  # CentOS/RHEL
```

## Multiple Instances

You can work with multiple Plane instances by using different projects:

```bash
# Project A uses cloud Plane
cd project-a
cat plane.yaml
# workspace: team-cloud
# api_url: https://api.plane.so

# Project B uses self-hosted
cd ../project-b
cat plane.yaml
# workspace: team-internal
# api_url: http://localhost:8000
```

Or use environment variables per command:

```bash
# Push to cloud
PLANE_API_URL="https://api.plane.so" plane push

# Push to self-hosted
PLANE_API_URL="http://localhost:8000" plane push
```

## Docker Compose Example

If you're running Plane with Docker Compose:

```yaml
# docker-compose.yml
services:
  plane-web:
    image: makeplane/plane-frontend
    ports:
      - "3000:3000"
  
  plane-api:
    image: makeplane/plane-backend
    ports:
      - "8000:8000"
```

Then configure plane-compose:

**Interactive:**
```bash
export PLANE_API_URL="http://localhost:8000"
plane auth login
```

**Non-interactive:**
```bash
export PLANE_API_URL="http://localhost:8000"
export PLANE_AUTH_TOKEN="your-api-key"
export PLANE_WORKSPACE="myteam"
plane auth login
```

## Support

For more help:
- [Main Documentation](../README.md)
- [Troubleshooting Guide](troubleshooting.md)
- [Plane Self-Hosted Docs](https://docs.plane.so/self-hosting)
- [GitHub Issues](https://github.com/makeplane/compose/issues)

