# Rearchitecture: `schema/` + `work/` Folder Split

**Status**: In Progress
**Branch**: `refactor/rearchitecture` (based on `feat/full-clone`)

---

## Progress

### Workspace side ✅ DONE

- [x] `work/releases.yaml` split from `schema/releases.yaml`
- [x] `--skip releases` on all 4 `plane ws` commands (clone, pull, push, diff)
- [x] `state.json` restructured: `releases.{tags,labels}` (schema) + `work.releases` (operational)
- [x] `plane ws state show` redesigned: flat `dotted.path = value` output, copy-paste into remove
- [x] `plane ws state remove` uses schema-based path resolver, handles dotted names

### Project side — Phase 1: Move cycles + modules ✅ DONE

- [x] `schema/cycles.yaml` → `work/cycles.yaml`
- [x] `schema/modules.yaml` → `work/modules.yaml`
- [x] Update clone, pull, push, diff to read/write from `work/`
- [x] Update all display messages
- [x] Backward-compat fallback: try `work/X.yaml` first, fall back to `schema/X.yaml`
- [x] Default template: `work/inbox.yaml` renamed to `work/workitems.yaml` with `workitems: []` root key
- [x] Parser: supports `workitems:` root key in addition to bare list format

### Project side — Phase 2: `--skip` flag ✅ DONE

- [x] `--skip workitems|cycles|modules` repeatable option on clone, pull, push, diff
- [x] `--schema-only` kept as alias for `--skip workitems --skip cycles --skip modules`
- [x] Filesystem-as-state rule: if `work/cycles.yaml` absent → push/diff skip cycles automatically

### Project side — Phase 3: `work/workitems.yaml` ✅ DONE

- [x] Clone/pull: write to `work/workitems.yaml` (`workitems:` root key format) instead of `.plane/remote/items.yaml`
- [x] `.plane/` becomes internal-only — `remote/` subdirectory no longer created
- [x] Push: reads from `work/workitems.yaml`, IDs backfilled in-place on POST
- [x] Large-project safety net (>10k items warning before pull, `--force` to suppress)
- [x] Backward compat: `parse_work_items` falls back to `.plane/remote/items.yaml` for pre-Phase 3 projects
- [x] State pre-populated at clone time: cloned items get `id:P103-1 → {remote_id, content_hash: ""}` so first push does PATCH not POST (no duplicates)
- [x] Pull no longer applies filesystem-as-state auto-skip — pull always fetches all sections; filesystem-as-state only applies to push/diff
- [x] Pull summary unified: always shows all three sections (workitems/cycles/modules) with counts; preview table removed; cycles/modules fetched inside progress block
- [x] Removed `--output` flag from `plane pull` (always writes to `work/workitems.yaml`)
- [x] Enterprise fix: properties skipped in `state.json` when workspace-level WIT is enabled (properties belong to workspace types, not project types)

### Project side — Phase 4: `schema/features.yaml` (project-level) ✅ DONE

- [x] New file written by clone/pull: project feature toggles (cycles, modules, pages, views, intakes, epics, work_item_types, workflows)
- [x] Push via `plane schema push` — `set_features()` is authoritative (replaces `enable_features()` when file present)
- [x] Pull via `plane pull` / `plane clone` — always written from remote (non-blocking)
- [x] Data gating: `cycles: false` → cycles data silently skipped on push; same for modules
- [x] `plane schema import` default mode: read-only (shows conflicts, never writes); `--force`/`--merge` writes
- [x] `plane diff` shows Features section (schema diff first, then work items diff)
- [x] `plane upgrade` Phase 4 support:
  - pull step now fetches + writes `features.yaml` (same as clone)
  - cycles/modules sections skipped when feature is disabled in local `features.yaml`
  - template `features.yaml` parsed and diffed against local (template wins)
  - `_apply_features_upgrade` merges template feature changes into local file
  - Default template (`templates/default/schema/features.yaml`) created

### Project side — Phase 5: `plane state show/remove` redesign ✅ DONE

Mirror what was done for `plane ws state show/remove`:
- [x] `plane state show` — flat `dotted.path = value` output (copy-paste into remove); `--json` flag for raw dump
- [x] `plane state remove` — schema-based path resolver, handles dotted names in keys (spaces, colons, etc.)
- [x] Sections covered: `types`, `states`, `labels`, `cycles`, `modules`, `work_items`
- [x] `plane state reset` — warning now lists cycles + modules counts (was missing before)
- [x] Old verbose table / prefix-parsing (`if tracking_key.startswith("labels.")`) removed
- [ ] Paths cover: `states.*`, `labels.*`, `types.*`, `cycles.*`, `modules.*`, `work_items.*`

---

## Problem

The current folder layout conflates two very different kinds of data under `schema/`:

1. **Configuration** — types, states, labels, workflows. Rarely changes. Defines *how* the project works.
2. **Operational data** — cycles, modules, work items. Changes frequently. Managed in the "Details" or "UI" view, not the "Settings" view.

Additionally:

- `.plane/remote/items.yaml` is conceptually a read-only remote snapshot but is currently the *only* place work items are stored — making it both the remote reference and the user-editable source of truth. This is contradictory.
- Projects have no `features.yaml` (unlike workspaces), so there is no way to toggle project-level features (cycles, modules, pages, inbox, etc.) from the CLI.
- `schema/releases.yaml` mixes configuration (release tags, release labels) with operational data (actual releases with dates/versions/status).

---

## Guiding Principle

> **`schema/` = Settings tab** (rarely changes, defines structure)
> **`work/` = Details/UI tab** (changes frequently, operational data)

This mirrors how Plane's own UI is organised:
- Cycles and Modules live in **Project Details**, not Project Settings.
- Releases (the actual release objects) live in **Workspace UI**, not Workspace Settings.
- Release tags and labels are configuration that belongs in Settings → `schema/`.

---

## Proposed Structure

### Project

```
project-dir/
  plane.yaml
  schema/
    features.yaml      ← NEW: project-level feature toggles
    types.yaml
    states.yaml
    labels.yaml
    workflows.yaml
    members.yaml
  work/
    workitems.yaml     ← replaces .plane/remote/items.yaml
    cycles.yaml        ← moved from schema/cycles.yaml
    modules.yaml       ← moved from schema/modules.yaml
  .plane/
    state.json         ← internal only, never hand-edited
```

### Workspace ✅ DONE

```
workspace-slug/
  plane.yaml
  schema/
    features.yaml
    members.yaml
    workitemtypes.yaml
    project.yaml         ← shared project states + labels (push/pull/prune) ✅
    initiatives.yaml
    releases.yaml        ← release_tags + release_labels only (configuration)
    relations.yaml       ← relation type definitions (push/pull/prune) ✅
    webhooks.yaml
  work/
    releases.yaml        ← actual releases (split from schema/releases.yaml) ✅
  .plane/
    state.json           ← internal only ✅
```

---

## What Changes

### `schema/features.yaml` (project-level) — new

Mirrors `schema/features.yaml` that already exists at workspace level.

```yaml
# Project Features
# Toggle project-level features on or off.

cycles: true
modules: true
pages: true
inbox: true
views: true
time_tracking: false
```

Pushed via `plane schema push`. Pulled via `plane schema pull` / `plane pull --schema-only`.

---

### `work/workitems.yaml` — replaces `.plane/remote/items.yaml`

Single source of truth for work items. User-editable. Pushed via `plane push`.

```yaml
workitems:
  - title: Fix login bug
    type: Bug
    state: In Progress
    assignees: [manish@plane.so]
    # id is absent for new items → POST on push, id written back in-place
  - id: abc-123
    title: Add dark mode
    type: Feature
    state: Todo
    # id present → PATCH on push if content changed
```

**`.plane/` becomes internal-only.** `state.json` tracks sync metadata. Nothing in `.plane/` is hand-edited.

---

### `work/cycles.yaml` — moved from `schema/cycles.yaml`

No content change — just location. Pushed via `plane push`.

---

### `work/modules.yaml` — moved from `schema/modules.yaml`

No content change — just location. Pushed via `plane push`.

---

### `schema/releases.yaml` (workspace) — split ✅ DONE

**After — `schema/releases.yaml`** (config only):
```yaml
release_tags:
  - version: v1.2.0
    ...
labels:
  - name: Hotfix
    ...
```

**After — `work/releases.yaml`** (operational data):
```yaml
releases:
  - name: v1.2.0
    tag: v1.2.0
    status: released
    ...
```

---

## Command Alignment

| Command | Scope |
|:--------|:------|
| `plane schema push/pull/diff` | `schema/` only |
| `plane push/pull/diff` | `work/` — all components present locally (default) |
| `plane push/pull/diff --skip X` | `work/` minus skipped component |
| `plane clone` | `schema/` + `work/` |
| `plane clone --schema-only` | `schema/` only (no `work/` created) |
| `plane clone --skip workitems` | `schema/` + `work/cycles.yaml` + `work/modules.yaml` |
| `plane ws push/pull/diff` | workspace `schema/` + `work/` ✅ |

### Filesystem-as-state rule

`push` and `diff` only operate on files that **exist locally**. `--skip` overrides this per invocation.

```
work/workitems.yaml absent  → push/diff silently skips workitems
work/workitems.yaml present → push/diff includes workitems (unless --skip workitems)
```

Clone with `--skip workitems`, later run `plane pull` (no skip) to get `work/workitems.yaml`,
and from that point all operations include workitems automatically — no config needed.

### Large project safety net

`plane pull` and `plane clone` warn before fetching large workitem sets:

```
⚠  Remote has 94,320 work items. Pull all into work/workitems.yaml? [y/N]:
```

Default threshold: 10,000 items. Use `--force` to suppress the prompt.

---

## `--skip` Flag

`--skip` is a universal flag across **all four operations** — clone, pull, push, diff.
Each command is fully independent. No state is persisted between invocations.

```bash
# clone
plane clone myteam/PROJ                                   # everything
plane clone myteam/PROJ --schema-only                     # schema/ only
plane clone myteam/PROJ --skip workitems                  # schema/ + cycles + modules
plane clone myteam/PROJ --skip workitems --skip modules   # schema/ + cycles only
plane clone myteam/PROJ --skip cycles --skip modules      # schema/ + workitems only

# pull — same flags, same effect
plane pull --skip workitems        # refresh cycles + modules, leave workitems alone
plane pull --skip cycles           # refresh workitems + modules, leave cycles alone

# push — same flags, even if file exists locally
plane push --skip workitems        # push cycles + modules only this time
plane push --skip cycles           # push workitems + modules only this time

# diff — same flags
plane diff --skip workitems        # compare cycles + modules only
plane diff --skip cycles           # compare workitems + modules only
```

`--schema-only` is a convenience alias for `--skip workitems --skip cycles --skip modules`
on all four commands.

Valid `--skip` values for **projects**: `workitems`, `cycles`, `modules`
Valid `--skip` values for **workspaces**: `releases` ✅

---

## Push: ID Backfill (no re-pull needed)

`plane push` never triggers a re-fetch of remote data. IDs come from push responses directly.

**Flow:**
1. Item in `work/workitems.yaml` has **no `id`** → `POST` → server returns `{ "id": "uuid", ... }` → write ID back in-place to `work/workitems.yaml`
2. Item has **`id`** and content changed → `PATCH` → no ID update needed
3. Item has **`id`** and unchanged → skip entirely

This means a project with 1M remote items has zero impact on a push of 10 local new items. The push only touches what is local and changed.

Same applies to cycles and modules.

---

## `.plane/` — Internal Only

After this change, `.plane/state.json` is the only file in `.plane/`. It is:
- Auto-managed by the CLI
- Never hand-edited by users
- Not committed to version control (should be in `.gitignore`)

Users no longer need to know `.plane/` exists.

---

## Open Questions

1. **`.gitignore` default** — `work/workitems.yaml` can be very large. Should the default `.gitignore` template exclude it, leaving users to opt in to tracking it?
2. **Large-project warning threshold** — 10k items before prompting. Is that the right default?

---
