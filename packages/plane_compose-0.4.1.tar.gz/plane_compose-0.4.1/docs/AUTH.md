# Authentication & Multi-Connection Setup

Plane Compose supports working with **multiple Plane instances** — Plane Cloud and/or self-hosted — simultaneously. Each connection is independently authenticated and can be linked to one or more workspaces.

---

## Quick Start

### Initial Setup (One-Time)

```bash
# 1. Install plane-compose
pipx install plane-compose

# 2. Log in to Plane Cloud (or your self-hosted instance)
plane auth login
# → Interactive prompts for: Server URL, auth type, token, workspace slug
# → Creates a connection (auto-named: connection-1, connection-2, etc.)

# 3. Create a project (stores workspace + connection in plane.yaml)
plane init MYPROJ -w myteam

# 4. Subsequent commands inherit context from plane.yaml — no flags needed
cd myproj
plane schema push
plane push
plane pull
```

### Multi-Instance Setup

```bash
# 1. Log in to first Plane instance (Plane Cloud)
plane auth login
# → Server URL: https://api.plane.so (press Enter)
# → Creates connection-1

# 2. Log in to second Plane instance (self-hosted)
plane auth login
# → Server URL: https://plane.mycompany.com
# → Creates connection-2

# 3. List all connections
plane auth list-connections

# 4. Create projects against each instance
plane init API -w myteam -c connection-1    # Plane Cloud
plane init API -w myteam -c connection-2    # Self-hosted

# 5. Each project stores its connection in plane.yaml
cd api
cat plane.yaml  # Shows: connection: connection-1
```

---

## Authentication System

Plane Compose stores credentials **securely** per connection in `~/.config/plane-compose/config.json`.

### Credentials Storage

- **Location**: `~/.config/plane-compose/config.json`
- **Format**: JSON with connections array and workspace mappings
- **Security**: File stored with restricted permissions (0600), credentials never logged in plaintext
- **Backup**: Automatically migrates legacy credentials from `~/.config/plane-cli/`

### Connection Concept

A **connection** is an authenticated session to a Plane instance:

- Each connection stores: Server URL, auth token (PAT or workspace), token type
- Connections are **independent** — you can authenticate to the same or different Plane instances
- Connection IDs are **auto-generated**: `connection-1`, `connection-2`, etc.
- Workspaces are **linked** to connections — each workspace slug can only be linked to one connection
- You can link multiple different workspaces to the same connection

### Workspace Concept

A **workspace** is a Plane team/workspace slug linked to a specific connection:

- Identified by slug (e.g., `myteam`, `api-team`)
- Each workspace linked to exactly one connection
- You can have the same workspace slug linked to multiple connections (for different Plane instances)
- One workspace is marked as **default** (used if no workspace is specified)

---

## Authentication Commands

### `plane auth login`

Authenticate with a Plane instance. Creates a new connection and links a workspace interactively.

```bash
plane auth login
```

**Interactive prompts (in order):**

1. **Server URL** (default: `https://api.plane.so`)
   - Press Enter for Plane Cloud
   - Type your self-hosted URL (e.g., `https://plane.mycompany.com`)

2. **Connection name** (default: auto-generated `connection-N`)
   - Press Enter to accept auto-generated name
   - Or type a custom name (must be unique)

3. **Auth type** (choose 1 or 2)
   - `(1) Personal Access Token` — PAT from Plane settings
   - `(2) Workspace Token` — workspace-specific token

4. **Token** (hidden input)
   - Paste your API key/token

5. **Workspace slug**
   - Enter the workspace slug (e.g., `myteam`)
   - Must match workspace in the Plane instance

**Result**: 
- Connection is created and saved to `config.json`
- Workspace is linked to the connection
- If it's your first workspace, it's set as default

**Output example:**
```
✓ Connection connection-1 created.
✓ Workspace myteam linked.
✓ Set as default workspace.
```

---

### `plane auth list-connections`

Display all connections and their linked workspaces.

```bash
plane auth list-connections
```

**Output shows:**
- Connection ID
- Auth type (PAT or workspace)
- Server URL
- Linked workspaces (marked with ★ if default)

**Example output:**
```
  ID            Type       Server                        Workspaces
  connection-1  workspace  https://api.plane.so          myteam ★, api-team
  connection-2  PAT        https://plane.mycompany.com   infrastructure
```

---

### `plane auth connect-workspace`

Link an existing workspace to an existing connection.

```bash
plane auth connect-workspace <connection-id> <workspace-slug>
```

**Example:**
```bash
plane auth connect-workspace connection-1 staging-team
```

**Use case**: You have a connection already authenticated, and want to link another workspace from that Plane instance.

---

### `plane auth disconnect-workspace`

Unlink a workspace from its connection.

```bash
plane auth disconnect-workspace <workspace-slug>
```

**With optional verification:**
```bash
plane auth disconnect-workspace <workspace-slug> -c <connection-id>
```

**Example:**
```bash
plane auth disconnect-workspace myteam
plane auth disconnect-workspace myteam -c connection-1  # With verification
```

**Result**: Workspace is unlinked. If it was the default, a new default is selected from remaining workspaces.

---

### `plane auth logout`

Remove a connection and all its linked workspaces.

```bash
plane auth logout <connection-id> [--force | -f]
```

**Options:**
- `--force` / `-f` — Skip confirmation prompt (useful for CI/CD or automation)

**Examples:**

Interactive (with confirmation):
```bash
plane auth logout connection-1
# Prompts: This will remove connection-1 and X workspace(s). Continue? [y/N]
```

Non-interactive (skip confirmation):
```bash
plane auth logout connection-1 --force
# or
plane auth logout connection-1 -f
```

**Result**: Connection is deleted from `config.json`, all workspaces linked to it are unlinked.

> **Warning**: If `plane.yaml` references this connection, commands will fail with "Connection not found".

---

## Connection Context in plane.yaml

### When Creating a Project

The `plane init` command saves **workspace** and **connection** to `plane.yaml`:

```bash
plane init MYPROJ -w myteam
```

Creates `myproj/plane.yaml`:
```yaml
workspace: myteam
connection: connection-1  # <-- Connection that has myteam linked
project:
  key: MYPROJ
  name: Myproj
```

The connection is chosen automatically:
- If `myteam` is linked to only one connection, that connection is used
- If `myteam` is linked to multiple connections, the default workspace's connection is used

You can specify the connection explicitly:
```bash
plane init MYPROJ -w myteam -c connection-2
```

### After plane.yaml Exists

All subsequent commands **inherit** workspace and connection from `plane.yaml`:

```bash
cd myproj

# These commands automatically use:
# - workspace: myteam (from plane.yaml)
# - connection: connection-1 (from plane.yaml)
# No flags needed!

plane schema push
plane push
plane pull
plane status
```

### Overriding the Stored Connection

You can override the stored connection with `-c` for any command:

```bash
cd myproj

# Use connection-2 instead of stored connection-1
plane push -c connection-2

# Pull from connection-2
plane pull -c connection-2

# Back to stored connection
plane push
```

**Use case**: Temporarily sync against a different Plane instance without editing `plane.yaml`.

---

## Common Workflows

### Scenario 1: Single Plane Instance, Multiple Workspaces

```bash
# Log in once
plane auth login
# → Creates connection-1, links myteam

# Link another workspace to same connection
plane auth connect-workspace connection-1 api-team

# Create projects in each workspace
plane init WEB -w myteam
plane init API -w api-team

# Each project has its own plane.yaml with same connection
cd web && plane push
cd ../api && plane push
```

### Scenario 2: Plane Cloud + Self-Hosted

```bash
# Log in to Plane Cloud
plane auth login
# → Server URL: https://api.plane.so
# → Workspace: myteam
# → Creates connection-1

# Log in to self-hosted instance
plane auth login
# → Server URL: https://plane.mycompany.com
# → Workspace: prod-team
# → Creates connection-2

# Create projects
plane init CLOUD -w myteam                  # Uses connection-1
plane init PROD -w prod-team -c connection-2  # Uses connection-2

# Sync independently
cd cloud && plane push
cd ../prod && plane push
```

### Scenario 3: Dev / Staging / Production (Same Instance)

```bash
# All on same Plane instance
plane auth login
# → Server URL: https://api.plane.so
# → Workspace: dev
# → Creates connection-1

# Link staging and production workspaces to same connection
plane auth connect-workspace connection-1 staging
plane auth connect-workspace connection-1 production

# Create projects
plane init DEV -w dev
plane init STAG -w staging
plane init PROD -w production

# Each uses connection-1 but different workspace
cd dev && plane push
cd ../stag && plane push
cd ../prod && plane push
```

---

## Troubleshooting

### "Connection not found" Error

```
Error: Connection 'connection-1' not found
```

**Cause**: `plane.yaml` references a connection that doesn't exist (was removed with `plane auth logout`).

**Fix**:
```bash
# Check what connections exist
plane auth list-connections

# Create a new connection if needed
plane auth login

# Update plane.yaml with correct connection ID
vim plane.yaml  # Change connection: connection-1 to a valid one
```

---

### "Workspace not found" Error

```
Error: Workspace 'myteam' not found
```

**Cause**: The workspace slug in `plane.yaml` is not linked to the connection specified.

**Fix**:
```bash
# Check what workspaces are linked to your connection
plane auth list-connections

# If workspace isn't linked, link it
plane auth connect-workspace connection-1 myteam

# Or use a different connection that has the workspace
vim plane.yaml  # Change connection ID
```

---

### "Unauthorized (401)" Error

```
Error: Unauthorized (401)
```

**Cause**: Invalid or expired token.

**Fix**:
```bash
# Remove the bad connection
plane auth logout connection-1

# Create a new connection with fresh token
plane auth login

# Update plane.yaml to use new connection
vim plane.yaml
```

---

### Lost Credentials

```bash
# If credentials are corrupted, recreate the connection
plane auth logout <connection-id>
plane auth login
```

---

## Environment Variables (Advanced)

For scripting or CI/CD without interactive prompts, you can set credentials via environment:

```bash
export PLANE_API_URL="https://api.plane.so"
export PLANE_API_KEY="<your-api-key>"

plane push
```

| Variable | Purpose |
|----------|---------|
| `PLANE_API_URL` | Plane instance URL |
| `PLANE_API_KEY` | Personal API key or token |
| `PLANE_API_TIMEOUT` | Request timeout in seconds |

> **Note**: Environment variables work for one-off commands but don't create persistent connections in `config.json`.

---

## Best Practices

1. **Use `plane auth list-connections` frequently** to verify your setup:
   ```bash
   plane auth list-connections
   ```

2. **Document connections in your project README**:
   ```markdown
   # API Project
   - Connection: `connection-1`
   - Workspace: `api-team`
   - Instance: https://api.plane.so
   ```

3. **Never commit `~/.config/plane-compose/`** — credentials are user-local and must not be checked in.

4. **Use plane.yaml for team collaboration**:
   ```bash
   git clone <repo>
   cd <project>
   plane push  # Works immediately if connection is set up
   ```

5. **Link workspaces to connections carefully** — each workspace can only be linked to one connection. If you need the same workspace on two instances, set up two connections.

---

## See Also

- [Installation Guide](INSTALL.md) — Setting up plane-compose
- [Quick Start](plane-compose.md#quick-start) — Getting started with a project
- [Command Reference](plane-compose.md#command-reference) — All available commands
- [Troubleshooting](troubleshooting.md) — Common issues and solutions
