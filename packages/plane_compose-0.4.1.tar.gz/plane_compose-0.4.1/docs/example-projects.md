# Example Projects

Complete, copy-paste-ready project configurations for common project types. Each example includes the full `plane.yaml`, schema files, and sample work items.

---

## Table of Contents

1. [SaaS API Backend](#1-saas-api-backend)
2. [Frontend Web Application](#2-frontend-web-application)
3. [Mobile App](#3-mobile-app)
4. [Data Pipeline / ML Project](#4-data-pipeline--ml-project)
5. [Design System / Component Library](#5-design-system--component-library)
6. [Open-Source Library](#6-open-source-library)
7. [Minimal Starter](#7-minimal-starter)

---

## 1. SaaS API Backend

A REST API project with deployment tracking, SLA properties, and a multi-stage workflow.

### plane.yaml

```yaml
workspace: mycompany
project:
  key: API
  name: Core API
defaults:
  type: Feature
  workflow: default
```

### schema/types.yaml

```yaml
Feature:
  description: New API capability or endpoint
  workflow: default
  properties:
    - name: api_version
      type: option
      options: [v1, v2, v3]
    - name: breaking_change
      type: boolean
    - name: design_doc
      type: url

Bug:
  description: API defect or incorrect behavior
  workflow: default
  properties:
    - name: severity
      type: option
      required: true
      options: [cosmetic, minor, major, critical]
    - name: affected_endpoint
      type: text
    - name: environment
      type: option
      options: [development, staging, production]
    - name: is_regression
      type: boolean
    - name: sla_breach
      type: boolean

Performance:
  description: Performance optimization work
  workflow: default
  properties:
    - name: current_p99_ms
      type: number
    - name: target_p99_ms
      type: number
    - name: affected_endpoint
      type: text

Chore:
  description: Maintenance, ops, or housekeeping
  workflow: default

Security:
  description: Security-related work
  workflow: default
  properties:
    - name: cve_id
      type: text
    - name: cvss_score
      type: decimal
    - name: disclosure_deadline
      type: date
```

### schema/workflows.yaml

```yaml
default:
  states:
    - name: Triage
      group: backlog
      color: "#94a3b8"
    - name: Backlog
      group: backlog
      color: "#64748b"
    - name: Ready
      group: unstarted
      color: "#3b82f6"
    - name: In Development
      group: started
      color: "#f59e0b"
    - name: In Review
      group: started
      color: "#8b5cf6"
    - name: QA
      group: started
      color: "#06b6d4"
    - name: Staging
      group: started
      color: "#14b8a6"
    - name: Shipped
      group: completed
      color: "#22c55e"
    - name: Won't Fix
      group: cancelled
      color: "#ef4444"
```

### schema/labels.yaml

```yaml
- name: auth
  color: "#dc2626"
- name: payments
  color: "#16a34a"
- name: search
  color: "#2563eb"
- name: notifications
  color: "#9333ea"
- name: infrastructure
  color: "#64748b"
- name: database
  color: "#ca8a04"
- name: p0-hotfix
  color: "#ef4444"
- name: tech-debt
  color: "#f97316"
```

### work/features.yaml

```yaml
- id: API-1
  title: Implement webhook delivery system
  type: Feature
  state: In Development
  priority: high
  start_date: "2026-03-01"
  due_date: "2026-03-21"
  labels:
    - notifications
  assignees:
    - alice@company.com
  description: |
    Build a reliable webhook delivery system with:
    - At-least-once delivery guarantee
    - Exponential backoff on failure
    - Delivery logs accessible via API
    - HMAC signature verification
  properties:
    api_version: v2
    breaking_change: false
    design_doc: https://docs.google.com/document/d/abc123
  children:
    - id: API-1a
      title: Webhook event queue (SQS)
      type: Chore
      state: In Development
    - id: API-1b
      title: Delivery worker with retry logic
      type: Feature
      state: Ready
    - id: API-1c
      title: Webhook management API endpoints
      type: Feature
      state: Backlog
    - id: API-1d
      title: Delivery log query endpoint
      type: Feature
      state: Backlog

- id: API-2
  title: Add cursor-based pagination to all list endpoints
  type: Feature
  state: Ready
  priority: medium
  labels:
    - tech-debt
  properties:
    api_version: v2
    breaking_change: true
    design_doc: https://docs.google.com/document/d/def456
```

### work/bugs.yaml

```yaml
- id: BUG-1
  title: Race condition in concurrent payment processing
  type: Bug
  state: In Development
  priority: urgent
  labels:
    - payments
    - p0-hotfix
  assignees:
    - bob@company.com
  properties:
    severity: critical
    affected_endpoint: "POST /v1/payments"
    environment: production
    is_regression: true
    sla_breach: false
  description: |
    When two payment requests arrive within 10ms for the same user,
    both can succeed, resulting in double-charge.

    Reproduce: Send concurrent POST /v1/payments with same idempotency key.

- id: BUG-2
  title: Search results include deleted items
  type: Bug
  state: Backlog
  priority: medium
  labels:
    - search
  properties:
    severity: major
    affected_endpoint: "GET /v1/search"
    environment: production
    is_regression: false
```

---

## 2. Frontend Web Application

A React/Next.js project with design integration, browser compatibility tracking, and accessibility requirements.

### plane.yaml

```yaml
workspace: mycompany
project:
  key: WEB
  name: Customer Portal
defaults:
  type: Story
  workflow: default
```

### schema/types.yaml

```yaml
Story:
  description: User-facing feature or flow
  workflow: default
  properties:
    - name: figma_link
      type: url
    - name: affected_pages
      type: text
    - name: needs_responsive
      type: boolean

Bug:
  description: Visual or functional defect
  workflow: default
  properties:
    - name: severity
      type: option
      options: [cosmetic, minor, major, critical]
    - name: browser
      type: option
      is_multi: true
      options: [Chrome, Firefox, Safari, Edge, Mobile Safari, Mobile Chrome]
    - name: screenshot_url
      type: url

Accessibility:
  description: WCAG compliance item
  workflow: default
  properties:
    - name: wcag_criteria
      type: text
    - name: wcag_level
      type: option
      options: [A, AA, AAA]
    - name: affected_component
      type: text

Improvement:
  description: Enhancement to existing UI/UX
  workflow: default
  properties:
    - name: figma_link
      type: url

Chore:
  description: Build, tooling, or dependency work
  workflow: default
```

### schema/workflows.yaml

```yaml
default:
  states:
    - name: Backlog
      group: backlog
      color: "#64748b"
    - name: Design Review
      group: unstarted
      color: "#ec4899"
    - name: Ready to Build
      group: unstarted
      color: "#3b82f6"
    - name: In Development
      group: started
      color: "#f59e0b"
    - name: In Review
      group: started
      color: "#8b5cf6"
    - name: QA / Browser Testing
      group: started
      color: "#06b6d4"
    - name: Done
      group: completed
      color: "#22c55e"
    - name: Cancelled
      group: cancelled
      color: "#ef4444"
```

### schema/labels.yaml

```yaml
- name: dashboard
  color: "#3b82f6"
- name: onboarding
  color: "#8b5cf6"
- name: settings
  color: "#64748b"
- name: billing-ui
  color: "#16a34a"
- name: design-system
  color: "#ec4899"
- name: performance
  color: "#f97316"
- name: a11y
  color: "#0891b2"
```

### work/stories.yaml

```yaml
- id: WEB-1
  title: Redesign dashboard overview page
  type: Story
  state: Design Review
  priority: high
  labels:
    - dashboard
  assignees:
    - designer@company.com
  description: |
    Redesign the main dashboard with:
    - Key metrics cards (MRR, active users, churn)
    - Activity feed
    - Quick action buttons
  properties:
    figma_link: https://figma.com/file/abc123/Dashboard-v2
    affected_pages: "/dashboard, /dashboard/overview"
    needs_responsive: true

- id: WEB-2
  title: Implement multi-step onboarding wizard
  type: Story
  state: Ready to Build
  priority: high
  labels:
    - onboarding
  properties:
    figma_link: https://figma.com/file/def456/Onboarding
    affected_pages: "/onboarding/*"
    needs_responsive: true
  children:
    - id: WEB-2a
      title: Step 1 — Workspace setup
      type: Story
      state: Ready to Build
    - id: WEB-2b
      title: Step 2 — Team invites
      type: Story
      state: Backlog
    - id: WEB-2c
      title: Step 3 — First project creation
      type: Story
      state: Backlog
    - id: WEB-2d
      title: Progress indicator component
      type: Story
      state: Backlog
      labels:
        - design-system
```

### work/bugs.yaml

```yaml
- id: WEB-BUG-1
  title: Modal overlay doesn't close on Escape key
  type: Bug
  state: In Development
  priority: medium
  labels:
    - a11y
  properties:
    severity: minor
    browser:
      - Chrome
      - Firefox
      - Safari
    screenshot_url: https://screenshots.company.com/bug-1.png

- id: WEB-A11Y-1
  title: Form inputs missing visible focus indicators
  type: Accessibility
  state: Ready to Build
  priority: high
  labels:
    - a11y
    - design-system
  properties:
    wcag_criteria: "2.4.7 Focus Visible"
    wcag_level: AA
    affected_component: "Input, Select, Textarea, Button"
```

---

## 3. Mobile App

An iOS/Android project with platform-specific tracking and release management.

### plane.yaml

```yaml
workspace: mycompany
project:
  key: MOBILE
  name: Mobile App
defaults:
  type: Feature
  workflow: default
```

### schema/types.yaml

```yaml
Feature:
  description: New mobile feature
  workflow: default
  properties:
    - name: platform
      type: option
      is_multi: true
      options: [iOS, Android, Both]
    - name: min_os_version
      type: text
    - name: design_link
      type: url
    - name: target_release
      type: option
      options: [v3.0, v3.1, v3.2, backlog]

Bug:
  description: Mobile defect
  workflow: default
  properties:
    - name: severity
      type: option
      required: true
      options: [cosmetic, minor, major, critical]
    - name: platform
      type: option
      is_multi: true
      options: [iOS, Android]
    - name: os_version
      type: text
    - name: device_model
      type: text
    - name: crash_log_url
      type: url

Chore:
  description: Build, CI, or maintenance task
  workflow: default
```

### schema/workflows.yaml

```yaml
default:
  states:
    - name: Backlog
      group: backlog
      color: "#64748b"
    - name: Ready
      group: unstarted
      color: "#3b82f6"
    - name: In Development
      group: started
      color: "#f59e0b"
    - name: In Review
      group: started
      color: "#8b5cf6"
    - name: QA
      group: started
      color: "#06b6d4"
    - name: Beta
      group: started
      color: "#14b8a6"
    - name: Released
      group: completed
      color: "#22c55e"
    - name: Won't Fix
      group: cancelled
      color: "#ef4444"
```

### schema/labels.yaml

```yaml
- name: iOS
  color: "#3b82f6"
- name: Android
  color: "#16a34a"
- name: push-notifications
  color: "#f59e0b"
- name: offline-mode
  color: "#64748b"
- name: app-store
  color: "#8b5cf6"
- name: performance
  color: "#f97316"
- name: crash
  color: "#ef4444"
```

### work/v3.0.yaml

```yaml
- id: MOB-1
  title: Implement biometric authentication
  type: Feature
  state: In Development
  priority: high
  labels:
    - iOS
    - Android
  properties:
    platform:
      - iOS
      - Android
    min_os_version: "iOS 15+ / Android 10+"
    target_release: v3.0
  children:
    - id: MOB-1a
      title: Face ID / Touch ID integration (iOS)
      type: Feature
      state: In Development
      labels: [iOS]
    - id: MOB-1b
      title: Fingerprint / Face unlock (Android)
      type: Feature
      state: Ready
      labels: [Android]

- id: MOB-2
  title: Offline mode — cache recent data
  type: Feature
  state: Ready
  priority: medium
  labels:
    - offline-mode
  properties:
    platform:
      - Both
    target_release: v3.0

- id: MOB-BUG-1
  title: App crashes on rotation during video playback
  type: Bug
  state: In Development
  priority: urgent
  labels:
    - Android
    - crash
  properties:
    severity: critical
    platform:
      - Android
    os_version: "Android 14"
    device_model: "Pixel 8 Pro"
    crash_log_url: https://crashlytics.google.com/report/abc123
```

---

## 4. Data Pipeline / ML Project

A data engineering or machine learning project with experiment tracking and dataset management.

### plane.yaml

```yaml
workspace: datateam
project:
  key: PIPELINE
  name: Data Pipeline
defaults:
  type: Task
  workflow: default
```

### schema/types.yaml

```yaml
Task:
  description: General data engineering task
  workflow: default

Pipeline:
  description: New data pipeline or ETL job
  workflow: default
  properties:
    - name: source_system
      type: option
      options: [postgres, s3, kafka, api, bigquery]
    - name: destination
      type: option
      options: [warehouse, lake, feature_store, elasticsearch]
    - name: schedule
      type: text
    - name: estimated_volume_gb
      type: decimal

Experiment:
  description: ML experiment or model iteration
  workflow: default
  properties:
    - name: hypothesis
      type: text
    - name: dataset_version
      type: text
    - name: baseline_metric
      type: decimal
    - name: target_metric
      type: decimal
    - name: notebook_link
      type: url
    - name: model_registry_id
      type: text

Bug:
  description: Data quality issue or pipeline failure
  workflow: default
  properties:
    - name: severity
      type: option
      options: [low, medium, high, critical]
    - name: affected_pipeline
      type: text
    - name: data_loss
      type: boolean
    - name: affected_date_range
      type: text
```

### schema/labels.yaml

```yaml
- name: ingestion
  color: "#3b82f6"
- name: transformation
  color: "#8b5cf6"
- name: ml-model
  color: "#ec4899"
- name: data-quality
  color: "#f59e0b"
- name: monitoring
  color: "#64748b"
- name: cost-optimization
  color: "#16a34a"
```

### work/pipelines.yaml

```yaml
- id: PIPE-1
  title: Build real-time clickstream ingestion pipeline
  type: Pipeline
  state: In Progress
  priority: high
  labels:
    - ingestion
  properties:
    source_system: kafka
    destination: warehouse
    schedule: "real-time (streaming)"
    estimated_volume_gb: 50.0
  children:
    - id: PIPE-1a
      title: Kafka consumer with Avro deserialization
      type: Task
      state: In Progress
    - id: PIPE-1b
      title: Schema registry integration
      type: Task
      state: Ready
    - id: PIPE-1c
      title: Warehouse sink with deduplication
      type: Task
      state: Backlog

- id: EXP-1
  title: Test transformer model for churn prediction
  type: Experiment
  state: In Progress
  labels:
    - ml-model
  properties:
    hypothesis: "Transformer architecture will improve churn prediction AUC by 5% over XGBoost baseline"
    dataset_version: "v2.3 (2026-02 snapshot)"
    baseline_metric: 0.82
    target_metric: 0.87
    notebook_link: https://colab.research.google.com/drive/abc123
```

---

## 5. Design System / Component Library

Track components, patterns, and design tokens.

### plane.yaml

```yaml
workspace: designteam
project:
  key: DS
  name: Design System
defaults:
  type: Component
  workflow: default
```

### schema/types.yaml

```yaml
Component:
  description: UI component to build or update
  workflow: default
  properties:
    - name: figma_link
      type: url
    - name: storybook_link
      type: url
    - name: complexity
      type: option
      options: [atom, molecule, organism, template]
    - name: has_tests
      type: boolean
    - name: has_docs
      type: boolean

Pattern:
  description: Reusable design pattern or guideline
  workflow: default
  properties:
    - name: doc_link
      type: url

Token:
  description: Design token change (colors, spacing, typography)
  workflow: default

Bug:
  description: Component defect
  workflow: default
  properties:
    - name: affected_component
      type: text
    - name: severity
      type: option
      options: [cosmetic, minor, major, critical]
```

### work/components.yaml

```yaml
- id: DS-1
  title: "Button: Add loading state variant"
  type: Component
  state: In Development
  priority: high
  labels:
    - core
  properties:
    figma_link: https://figma.com/file/abc/Button-States
    storybook_link: https://storybook.company.com/?path=/story/button
    complexity: atom
    has_tests: false
    has_docs: false
  description: |
    Add a `loading` prop to Button that shows a spinner
    and disables click events.

    Variants needed:
    - Primary loading
    - Secondary loading
    - Ghost loading

- id: DS-2
  title: "DataTable: Sortable columns"
  type: Component
  state: Ready
  priority: medium
  properties:
    complexity: organism
    figma_link: https://figma.com/file/def/DataTable-v2
  children:
    - id: DS-2a
      title: Column header sort indicators
      type: Component
    - id: DS-2b
      title: Multi-column sort logic
      type: Component
    - id: DS-2c
      title: Sort persistence in URL params
      type: Component

- id: DS-3
  title: "Typography scale: Migrate to fluid type"
  type: Token
  state: Backlog
  priority: low
  labels:
    - tokens
  description: |
    Replace fixed font sizes with clamp()-based fluid typography.
    See: https://utopia.fyi/type/calculator
```

---

## 6. Open-Source Library

A library with community contribution support, RFC tracking, and release management.

### plane.yaml

```yaml
workspace: oss
project:
  key: MYLIB
  name: MyLib
defaults:
  type: Enhancement
  workflow: default
```

### schema/types.yaml

```yaml
Bug:
  description: Confirmed defect
  workflow: default
  properties:
    - name: severity
      type: option
      options: [low, medium, high, critical]
    - name: reproducible
      type: boolean
    - name: min_version
      type: text

Feature:
  description: New feature (approved via RFC)
  workflow: default
  properties:
    - name: rfc_link
      type: url
    - name: breaking_change
      type: boolean
    - name: target_version
      type: option
      options: [v2.0, v2.1, v3.0, unscheduled]

Enhancement:
  description: Improvement to existing functionality
  workflow: default
  properties:
    - name: breaking_change
      type: boolean

Docs:
  description: Documentation update
  workflow: default
  properties:
    - name: doc_section
      type: option
      options: [getting-started, api-reference, guides, migration, changelog]
```

### schema/labels.yaml

```yaml
- name: good-first-issue
  color: "#7c3aed"
- name: help-wanted
  color: "#2563eb"
- name: breaking
  color: "#dc2626"
- name: needs-rfc
  color: "#f59e0b"
- name: documentation
  color: "#059669"
- name: performance
  color: "#f97316"
- name: security
  color: "#dc2626"
- name: community
  color: "#8b5cf6"
```

### work/v2.0.yaml

```yaml
- id: v2-1
  title: Add streaming API support
  type: Feature
  state: In Development
  priority: high
  labels:
    - breaking
  properties:
    rfc_link: https://github.com/mylib/rfcs/blob/main/002-streaming.md
    breaking_change: true
    target_version: v2.0
  description: |
    Implement streaming response support.
    RFC: https://github.com/mylib/rfcs/blob/main/002-streaming.md

- id: v2-2
  title: Migrate from callbacks to async/await
  type: Feature
  state: Ready
  priority: high
  labels:
    - breaking
  properties:
    breaking_change: true
    target_version: v2.0

- id: v2-3
  title: Write migration guide from v1 to v2
  type: Docs
  state: Backlog
  priority: medium
  labels:
    - documentation
  properties:
    doc_section: migration
  blocked_by:
    - v2-1
    - v2-2
```

### work/community.yaml

```yaml
- id: COMMUNITY-1
  title: Add TOML config file support
  type: Enhancement
  state: Backlog
  labels:
    - good-first-issue
    - help-wanted
  properties:
    breaking_change: false
  description: |
    Support TOML as a config format alongside YAML and JSON.
    Community request: https://github.com/mylib/discussions/234

- id: COMMUNITY-2
  title: Improve error messages for invalid config
  type: Enhancement
  state: Backlog
  labels:
    - good-first-issue
  properties:
    breaking_change: false
```

---

## 7. Minimal Starter

The simplest possible project — just the essentials.

### plane.yaml

```yaml
workspace: myteam
project:
  key: PROJ
  name: My Project
```

### schema/types.yaml

```yaml
Task:
  description: A task
  workflow: default

Bug:
  description: A bug
  workflow: default
```

### schema/workflows.yaml

```yaml
default:
  states:
    - name: Todo
      group: unstarted
      color: "#3b82f6"
    - name: In Progress
      group: started
      color: "#f59e0b"
    - name: Done
      group: completed
      color: "#22c55e"
```

### schema/labels.yaml

```yaml
[]
```

### work/inbox.yaml

```yaml
- id: PROJ-1
  title: First task
  type: Task
  state: Todo

- id: PROJ-2
  title: Second task
  type: Task
  state: Todo
```

```bash
plane schema push && plane push
```

That's it. Two types, three states, no labels, two items. Expand from here.
