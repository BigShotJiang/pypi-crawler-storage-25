# Installation Guide

## Installation

### Prerequisites

- Python 3.10 or higher
- pip (Python package manager)
- pipx (recommended for isolated installation)

### Install pipx (if not already installed)

```bash
python3 -m pip install --user pipx
python3 -m pipx ensurepath
```

### Install Plane Compose

```bash
pipx install plane-compose
```

### Upgrade

```bash
pipx upgrade plane-compose
```

### Uninstall

```bash
pipx uninstall plane-compose
```

---

## Verify Installation

```bash
plane --version
```

You should see output like:
```
plane version 1.0.0
```

---

## Post-Installation Setup

### 1. Authenticate with Plane

**Interactive Mode (Recommended for First-Time Setup):**
```bash
plane auth login
```

When prompted, enter:
1. **Server URL** (default: `https://api.plane.so`)
   - Press Enter for Plane Cloud
   - Or type your self-hosted URL (e.g., `https://plane.mycompany.com`)

2. **Connection name** (optional)
   - Press Enter to accept auto-generated name (e.g., `connection-1`)
   - Or provide a custom name

3. **Auth type** (choose 1 or 2)
   - `(1) Personal Access Token` — PAT from Plane settings
   - `(2) Workspace Token` — workspace-specific token

4. **API Key** from your Plane workspace
   - Plane Cloud: `https://app.plane.so/<workspace-slug>/settings/account/api-tokens/`
   - Self-hosted: `https://your-plane-url/<workspace-slug>/settings/account/api-tokens/`

5. **Workspace slug**
   - Enter the workspace slug (e.g., `myteam`)

This creates a connection with an auto-generated name (e.g., `connection-1`).

**Non-Interactive Mode (CI/CD):**

Using environment variables:
```bash
export PLANE_SERVER_URL="https://api.plane.so"
export PLANE_AUTH_TYPE="pat"  # or "workspace"
export PLANE_AUTH_TOKEN="your-api-key"
export PLANE_WORKSPACE="myteam"
plane auth login
```

Or with all required flags:
```bash
plane auth login \
  --server-url https://api.plane.so \
  --auth-type pat \
  --token your-api-key \
  --workspace myteam
```

### 2. Verify Authentication

```bash
plane auth whoami
```

Shows your email, workspace, and server URL.

### 3. (Optional) Use a Custom Template

Initialize a project with a custom template:

```bash
# Built-in template (default)
plane init MYPROJ -w myteam

# Local template folder
plane init MYPROJ -w myteam --template ./templates/agency

# Git template (HTTPS)
plane init MYPROJ -w myteam --template https://github.com/org/repo/templates/my-template

# Git template (SSH)
plane init MYPROJ -w myteam --template git@github.com:org/repo.git/templates/my-template
```

See [Templates documentation](plane-compose.md#using-custom-templates) for details.

### 4. (Optional) Add Another Connection

If you work with multiple Plane instances, run `plane auth login` again:

```bash
# Create connection-2
plane auth login

# Create connection-3
plane auth login
```

Each login creates a new connection with an auto-generated name.

List all connections:
```bash
plane auth list-connections
```

Remove a connection:
```bash
# Interactive (with confirmation)
plane auth logout connection-1

# Non-interactive (skip confirmation, useful for scripts)
plane auth logout connection-1 --force
```

See [Authentication & Multi-Connection Setup](AUTH.md) for more details.

---

## Shell Completion (Optional)

### Bash

Add to `~/.bashrc`:
```bash
eval "$(plane --show-completion bash)"
```

### Zsh

Add to `~/.zshrc`:
```bash
eval "$(plane --show-completion zsh)"
```

### Fish

```fish
plane --show-completion fish > ~/.config/fish/completions/plane.fish
```

---

## Troubleshooting

### Command not found after installation

If `plane` command is not found after installation, ensure pipx's bin directory is in your PATH:

```bash
export PATH="$HOME/.local/bin:$PATH"
```

Add this to your `~/.bashrc`, `~/.zshrc`, or `~/.profile` to make it permanent.

### Permission denied errors

If you encounter permission errors during installation:

1. Ensure you have write permissions to `~/.local/`
2. Use pipx instead of pip for global installations
3. Avoid using `sudo` with pip/pipx

### Python version issues

Check your Python version:
```bash
python3 --version
```

Plane Compose requires Python 3.10 or higher. Update Python if needed:

**macOS (Homebrew):**
```bash
brew install python@3.11
```

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install python3.11
```

**Windows:**
Download from [python.org](https://www.python.org/downloads/)

---

## Advanced Installation Options

### Install in a Virtual Environment

```bash
python3 -m venv plane-env
source plane-env/bin/activate  # On Windows: plane-env\Scripts\activate
pip install plane-compose
```

### Install Specific Version

```bash
pipx install plane-compose==1.0.0
```

### Install with Development Dependencies

```bash
git clone https://github.com/makeplane/compose.git
cd compose
pip install -e ".[dev]"
```

---

## CI/CD Installation

### GitHub Actions

```yaml
- name: Install Plane Compose
  run: pipx install plane-compose
```

### GitLab CI

```yaml
install_plane:
  script:
    - pip install pipx
    - pipx install plane-compose
```

### Jenkins

```groovy
sh 'pipx install plane-compose'
```

---

## Support

- **Issues**: https://github.com/makeplane/compose/issues
- **Documentation**: https://github.com/makeplane/compose#readme
- **Plane Support**: https://plane.so/support
