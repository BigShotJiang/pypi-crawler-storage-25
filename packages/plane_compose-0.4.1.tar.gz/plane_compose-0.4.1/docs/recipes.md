# Recipes

Step-by-step workflows for common Plane Compose tasks.

**Note**: For workspace-level configuration recipes (managing releases, initiatives, custom properties), see [Workspace Recipes](workspace-recipes.md).

---

## Table of Contents

### Project-Level Recipes

1. [Start a New Project from Scratch](#1-start-a-new-project-from-scratch)
2. [Clone a Teammate's Project](#2-clone-a-teammates-project)
3. [Import an Existing Plane Project into Code](#3-import-an-existing-plane-project-into-code)
4. [Evolve Your Schema Over Time](#4-evolve-your-schema-over-time)
5. [Organize Work Across Multiple Files](#5-organize-work-across-multiple-files)
6. [Set Up a Monorepo with Multiple Projects](#6-set-up-a-monorepo-with-multiple-projects)
6a. [Use a Custom Template](#6a-use-a-custom-template)
7. [Push on Merge with GitHub Actions](#7-push-on-merge-with-github-actions)
8. [Push on Merge with GitLab CI](#8-push-on-merge-with-gitlab-ci)
9. [Self-Hosted Plane Setup](#9-self-hosted-plane-setup)
10. [Sprint Planning Workflow](#10-sprint-planning-workflow)
11. [Bulk Create Items from a Template](#11-bulk-create-items-from-a-template)
12. [Sync Schema Bidirectionally](#12-sync-schema-bidirectionally)
13. [Audit What's Tracked vs What's Remote](#13-audit-whats-tracked-vs-whats-remote)
14. [Recover from a Bad State](#14-recover-from-a-bad-state)
15. [Custom Property Workflows](#15-custom-property-workflows)

---

## 1. Start a New Project from Scratch

**Goal**: Create a brand-new project in Plane, defined entirely in code.

**Interactive:**
```bash
# Authenticate (one-time)
plane auth login

# Scaffold the project
plane init API -w myteam
cd api/
```

**Non-interactive (CI/CD):**
```bash
# Set environment variables
export PLANE_AUTH_TOKEN="your-api-key"
export PLANE_WORKSPACE="myteam"

# Authenticate (uses env vars, no prompts)
plane auth login

# Scaffold the project
plane init API -w myteam
cd api/
```

Review the generated files:

```
api/
├── plane.yaml
├── schema/
│   ├── types.yaml          # Bug, Feature, Improvement, Chore
│   ├── workflows.yaml      # Icebox → Backlog → Ready → In Progress → Done
│   └── labels.yaml         # Frontend, Backend, Infrastructure, etc.
├── work/
│   └── inbox.yaml          # Empty — add items here
└── .plane/
    └── state.json
```

Customize the schema to your needs, then push:

```bash
# Validate schema before pushing
plane schema validate

# Create the project and push schema to Plane
plane schema push

# Add work items to work/inbox.yaml, then push
plane push
```

Verify everything landed:

```bash
plane status
```

---

## 2. Clone a Teammate's Project

**Goal**: Get a local copy of an existing Plane project to work with as code.

```bash
# Using workspace/key shorthand (preferred)
plane clone myteam/API

# Or using key + workspace flag
plane clone API --workspace=myteam

# Or using UUID
plane clone 8cee0da2-1b5b-4699-b11a-e3c8b26dd55d --workspace=myteam
```

Include custom property values (slower but complete):

```bash
plane clone myteam/API --with-properties
```

Clone into a specific directory:

```bash
plane clone myteam/API --directory=my-api-project
```

After cloning:

```bash
cd api/
plane status          # See what you have
ls .plane/remote/     # Remote items are here
ls schema/            # Schema was pulled automatically
```

The cloned project is ready. Add your own work items to `work/inbox.yaml` and run `plane push`.

---

## 3. Import an Existing Plane Project into Code

**Goal**: You have an existing Plane project (with types, states, labels already configured in the UI). Bring it under code management.

```bash
# Step 1: Create the local scaffold
plane init EXISTING -w myteam
cd existing/

# Step 2: Replace scaffold schema with actual remote schema
plane schema import --force
```

This overwrites the generated `schema/types.yaml`, `schema/workflows.yaml`, and `schema/labels.yaml` with whatever exists in Plane.

```bash
# Step 3: Pull existing work items for reference
plane pull

# Step 4: Verify the import
plane status
plane schema diff     # Should show "Schemas are in sync"
```

Now your project is managed by code. Edit `schema/` files and `plane schema push` to update Plane.

**Alternative — additive import** (keeps your scaffold, adds anything missing from remote):

```bash
plane schema import --merge
```

---

## 4. Evolve Your Schema Over Time

**Goal**: Add new types, states, or labels to an existing project.

### Add a new work item type

Edit `schema/types.yaml`:

```yaml
# Existing types...
Bug:
  description: A defect
  workflow: default

Feature:
  description: New functionality
  workflow: default

# Add a new type
Epic:
  description: Large body of work spanning multiple features
  workflow: default
  is_epic: true
  properties:
    - name: target_quarter
      type: option
      options:
        - Q1
        - Q2
        - Q3
        - Q4
    - name: business_value
      type: option
      options:
        - low
        - medium
        - high
        - critical
```

### Add new workflow states

Edit `schema/workflows.yaml`:

```yaml
default:
  states:
    - name: Icebox
      group: backlog
      color: "#94a3b8"
    - name: Backlog
      group: backlog
      color: "#64748b"
    - name: Ready
      group: unstarted
      color: "#3b82f6"
    - name: In Progress
      group: started
      color: "#f59e0b"
    - name: In Review          # New state
      group: started
      color: "#8b5cf6"
    - name: Done
      group: completed
      color: "#22c55e"
    - name: Cancelled
      group: cancelled
      color: "#ef4444"
```

### Add new labels

Append to `schema/labels.yaml`:

```yaml
- name: Frontend
  color: "#3b82f6"
- name: Backend
  color: "#10b981"
- name: Security            # New label
  color: "#dc2626"
- name: Performance         # New label
  color: "#f97316"
```

### Push the changes

```bash
# Preview what will change
plane schema push --dry-run

# Apply
plane schema push
```

`plane schema push` is additive — it only creates missing items. It never deletes or renames.

### Make remote match local exactly

If you renamed or removed items and want remote to match:

```bash
# Preview changes (creates + updates + would-delete)
plane schema sync --dry-run

# Apply creates and updates (deletes are flagged but not executed — API limitation)
plane schema sync
```

---

## 5. Organize Work Across Multiple Files

**Goal**: Keep work items organized by theme, sprint, or type instead of one big file.

Create multiple files under `work/`:

```
work/
├── inbox.yaml           # Unsorted new items
├── features.yaml        # Planned features
├── bugs.yaml            # Active bugs
├── tech-debt.yaml       # Cleanup tasks
└── sprint-14.yaml       # Current sprint items
```

**work/features.yaml**:

```yaml
- id: FEAT-1
  title: OAuth2 integration
  type: Feature
  state: Backlog
  priority: high
  labels:
    - Backend
  assignees:
    - alice@example.com
  description: |
    Add OAuth2 support with Google and GitHub providers.

- id: FEAT-2
  title: Dark mode support
  type: Feature
  state: Ready
  labels:
    - Frontend
  assignees:
    - bob@example.com
```

**work/bugs.yaml**:

```yaml
- id: BUG-1
  title: Login page 500 error on Safari
  type: Bug
  state: In Progress
  priority: urgent
  labels:
    - Frontend
    - Urgent
  properties:
    severity: critical
    environment: production
    is_regression: true

- id: BUG-2
  title: Email notifications sent twice
  type: Bug
  state: Backlog
  priority: medium
  labels:
    - Backend
  properties:
    severity: major
    environment: production
```

**work/tech-debt.yaml**:

```yaml
- id: CHORE-1
  title: Migrate to async request handlers
  type: Chore
  state: Icebox

- id: CHORE-2
  title: Upgrade React to v19
  type: Chore
  state: Backlog
  labels:
    - Frontend
```

All files are picked up automatically by `plane push`. No configuration needed.

---

## 6. Set Up a Monorepo with Multiple Projects

**Goal**: Manage multiple Plane projects from a single git repository.

```bash
mkdir projects && cd projects

# Create each project
plane init API -w myteam
plane init WEB -w myteam
plane init MOBILE -w myteam
```

Directory structure:

```
projects/
├── api/
│   ├── plane.yaml        # workspace: myteam, project.key: API
│   ├── schema/
│   └── work/
├── web/
│   ├── plane.yaml        # workspace: myteam, project.key: WEB
│   ├── schema/
│   └── work/
└── mobile/
    ├── plane.yaml        # workspace: myteam, project.key: MOBILE
    ├── schema/
    └── work/
```

Operate on all projects at once:

```bash
# Push all projects
plane push --all

# Push only projects in a specific workspace
plane push --all --workspace=myteam

# Push only projects matching a pattern
plane push --all --filter="api*"

# Status for all
plane status --all

# Pull all
plane pull --all
```

Or operate on a single project by path:

```bash
plane push ./api
plane status ./web
plane schema diff ./mobile
```

---

## 6a. Use a Custom Template

**Goal**: Initialize projects with a standardized schema and work item structure.

Templates let you bootstrap projects with pre-configured types, workflows, labels, and even example work items.

### Create Your Own Template

Create a template directory with schema and work files:

```
my-template/
├── schema/
│   ├── types.yaml          # Your custom types
│   ├── workflows.yaml      # Your workflows
│   └── labels.yaml         # Your labels
└── work/
    └── inbox.yaml          # Example or starter items
```

**schema/types.yaml**:
```yaml
Epic:
  description: Large body of work
  workflow: standard
  is_epic: true

Feature:
  description: New functionality
  workflow: standard

Bug:
  description: Defect or issue
  workflow: standard
```

**schema/workflows.yaml**:
```yaml
standard:
  states:
    - name: Backlog
      group: backlog
      color: "#94a3b8"
    - name: Ready
      group: unstarted
      color: "#3b82f6"
    - name: In Progress
      group: started
      color: "#f59e0b"
    - name: Done
      group: completed
      color: "#22c55e"
```

**schema/labels.yaml**:
```yaml
- name: Frontend
  color: "#3b82f6"
- name: Backend
  color: "#10b981"
- name: Infrastructure
  color: "#6366f1"
```

### Use a Local Template

```bash
plane init MYPROJ -w myteam --template ./my-template
# or short form
plane init MYPROJ -w myteam -t ~/templates/custom-template
```

### Use a Git Template

**GitHub HTTPS**:
```bash
plane init MYPROJ -w myteam --template https://github.com/org/templates/tree/main/agency-template
```

**GitHub SSH**:
```bash
plane init MYPROJ -w myteam --template git@github.com:org/templates.git/agency-template
```

### Bulk Initialize with Template

Create multiple projects with the same template:

```bash
# Use a loop to create multiple projects
for proj in API WEB MOBILE; do
  plane init $proj -w myteam --template ./standard-template
done
```

### Share Templates in Git

Commit templates to a shared repository:

```bash
git clone https://github.com/org/plane-templates
cd plane-templates

plane init MYPROJ -w myteam --template ./templates/agency
```

Templates are ideal for:
- **Teams**: Ensure all projects follow the same structure
- **Agencies**: Standardized templates for each client
- **SaaS products**: Pre-configured schemas for feature areas
- **Best practices**: Share proven workflows across the organization

---

## 7. Push on Merge with GitHub Actions

**Goal**: Automatically sync work items to Plane when changes merge to main.

**.github/workflows/plane-sync.yml**:

```yaml
name: Sync to Plane
on:
  push:
    branches: [main]
    paths:
      - 'work/**'
      - 'schema/**'
      - 'plane.yaml'

jobs:
  sync:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install Plane Compose
        run: pipx install plane-compose

      - name: Push to Plane
        run: plane push --force
        env:
          PLANE_API_KEY: ${{ secrets.PLANE_API_KEY }}
          PLANE_API_URL: ${{ secrets.PLANE_API_URL }}
```

**For monorepo** (push all projects):

```yaml
      - name: Push all projects
        run: plane push --all --force
        env:
          PLANE_API_KEY: ${{ secrets.PLANE_API_KEY }}
```

Set `PLANE_API_KEY` in your repository's Settings > Secrets.

---

## 8. Push on Merge with GitLab CI

**.gitlab-ci.yml**:

```yaml
plane-sync:
  stage: deploy
  image: python:3.11-slim
  only:
    refs:
      - main
    changes:
      - work/**
      - schema/**
      - plane.yaml
  before_script:
    - pip install plane-compose
  script:
    - plane push --force
  variables:
    PLANE_API_KEY: $PLANE_API_KEY
    PLANE_API_URL: $PLANE_API_URL
```

---

## 9. Self-Hosted Plane Setup

**Goal**: Use Plane Compose with your own Plane instance.

### Option A: Environment variable (global, interactive)

```bash
export PLANE_API_URL=https://plane.yourcompany.com
plane auth login
```

### Option B: Environment variable (global, non-interactive)

```bash
export PLANE_API_URL=https://plane.yourcompany.com
export PLANE_AUTH_TOKEN="your-api-key"
export PLANE_WORKSPACE="myteam"
plane auth login
```

### Option C: Per-project in plane.yaml

```yaml
workspace: myteam
project:
  key: API
  name: API Service
api_url: https://plane.yourcompany.com
```

### Option D: Login directly with flags

```bash
plane auth login \
  --server-url https://plane.yourcompany.com \
  --auth-type pat \
  --token your-api-key \
  --workspace myteam
```

### Option E: Interactive prompt

When you run `plane auth login`, it prompts for the server URL:

```
Server URL [https://api.plane.so]: https://plane.yourcompany.com
Connection name [connection-1]: 
Auth type [(1) Personal Access Token, (2) Workspace Token]: 1
API Key: ********
Workspace slug: myteam
```

### Get your API key

Navigate to: `https://plane.yourcompany.com/<workspace>/settings/account/api-tokens/`

### Verify

```bash
plane auth whoami
# Shows: server: https://plane.yourcompany.com, user: you@company.com
```

### Multiple instances

Different projects can point to different servers:

```yaml
# projects/internal/plane.yaml
workspace: internal
api_url: https://plane.internal.com

# projects/client/plane.yaml
workspace: client
api_url: https://plane.client.com
```

---

## 10. Sprint Planning Workflow

**Goal**: Use Plane Compose for structured sprint planning.

### Before the sprint

Create a sprint file:

```yaml
# work/sprint-14.yaml
- id: S14-1
  title: Implement payment webhooks
  type: Feature
  state: Ready
  priority: high
  due_date: "2026-03-14"
  labels:
    - Backend
  assignees:
    - alice@example.com
  description: |
    Handle Stripe webhook events for payment confirmation.

- id: S14-2
  title: Fix cart total rounding error
  type: Bug
  state: Ready
  priority: urgent
  due_date: "2026-03-07"
  labels:
    - Backend
  assignees:
    - bob@example.com
  properties:
    severity: major
    environment: production

- id: S14-3
  title: Add order confirmation email template
  type: Chore
  state: Ready
  priority: medium
  due_date: "2026-03-14"
  labels:
    - Frontend
  assignees:
    - carol@example.com
```

### Push the sprint

```bash
plane push
```

### During the sprint — update states

Edit `work/sprint-14.yaml` as work progresses:

```yaml
- id: S14-1
  title: Implement payment webhooks
  type: Feature
  state: In Progress          # Changed from Ready
  # ...rest unchanged

- id: S14-2
  title: Fix cart total rounding error
  type: Bug
  state: Done                 # Completed!
  # ...rest unchanged
```

```bash
plane push    # Updates are detected via content hash
```

### After the sprint — archive

Move completed items or just leave them. Plane Compose tracks by ID, so items stay linked regardless of which file they're in.

---

## 11. Bulk Create Items from a Template

**Goal**: Quickly scaffold a large set of related items.

### Onboarding checklist

```yaml
# work/onboarding.yaml
- id: ONBOARD-1
  title: Set up development environment
  type: Chore
  state: Ready
  labels:
    - Documentation
  children:
    - id: ONBOARD-1a
      title: Install required tooling (Node, Python, Docker)
      type: Chore
    - id: ONBOARD-1b
      title: Clone all service repositories
      type: Chore
    - id: ONBOARD-1c
      title: Run local environment setup script
      type: Chore

- id: ONBOARD-2
  title: Complete access requests
  type: Chore
  state: Ready
  children:
    - id: ONBOARD-2a
      title: Request AWS console access
      type: Chore
    - id: ONBOARD-2b
      title: Request database read access
      type: Chore
    - id: ONBOARD-2c
      title: Set up VPN credentials
      type: Chore

- id: ONBOARD-3
  title: Review architecture documentation
  type: Chore
  state: Ready
  labels:
    - Documentation
  description: |
    Read through:
    - System architecture doc
    - API design guidelines
    - Deployment runbook
```

```bash
plane push    # Creates all items with parent-child hierarchy
```

### Release checklist

```yaml
# work/release-v2.yaml
- id: REL-2.0-1
  title: "Release v2.0: Feature freeze"
  type: Chore
  state: Ready
  due_date: "2026-03-01"

- id: REL-2.0-2
  title: "Release v2.0: QA regression pass"
  type: Chore
  state: Ready
  due_date: "2026-03-05"
  blocked_by:
    - REL-2.0-1

- id: REL-2.0-3
  title: "Release v2.0: Performance benchmarks"
  type: Chore
  state: Ready
  due_date: "2026-03-07"
  blocked_by:
    - REL-2.0-1

- id: REL-2.0-4
  title: "Release v2.0: Staging deploy"
  type: Chore
  state: Ready
  due_date: "2026-03-10"
  blocked_by:
    - REL-2.0-2
    - REL-2.0-3

- id: REL-2.0-5
  title: "Release v2.0: Production deploy"
  type: Chore
  state: Ready
  due_date: "2026-03-14"
  blocked_by:
    - REL-2.0-4
```

Dependencies (`blocked_by`) create a clear execution order in Plane.

---

## 12. Sync Schema Bidirectionally

**Goal**: Someone added types/labels in the Plane UI. Pull those changes into your code.

### See what's different

```bash
plane schema diff
```

Output:

```
Types:
  + Only in local: Epic
  - Only in remote: Spike
  = In both: 4 types

Labels:
  - Only in remote: P0, P1
  = In both: 5 labels
```

### Add remote-only items to local (safe, additive)

```bash
plane schema import --merge
```

This adds `Spike` to your `types.yaml` and `P0`/`P1` to your `labels.yaml` without touching existing entries.

### Or replace local with remote entirely

```bash
plane schema import --force     # Destructive — overwrites local files
```

### Then push your local additions

```bash
plane schema push     # Creates "Epic" in remote
```

---

## 13. Audit What's Tracked vs What's Remote

**Goal**: Understand the current sync state.

### Quick overview

```bash
plane status
```

Shows: project info, schema counts (local vs synced), work item counts, last sync time.

### Detailed state inspection

```bash
plane state show              # Summary with tables
plane state show --verbose    # All tracked items
plane state show --json       # Machine-readable
```

### Compare local vs remote

```bash
plane schema diff             # Schema differences
```

### Remove stale tracking entries

If an item was deleted remotely but still tracked locally:

```bash
plane state remove API-42     # Remove specific item
```

---

## 14. Recover from a Bad State

**Goal**: Fix sync state issues — duplicates, mismatches, corruption.

### Scenario: Duplicate items after push

Items without stable `id` fields got duplicated.

```bash
# Clear work item tracking (keep schema)
plane state clear-items

# Add id fields to your work items, then re-push
plane push
```

### Scenario: State file is out of sync with remote

```bash
# Nuclear reset
plane state reset --force

# Re-link schema to remote IDs
plane schema import

# Re-push work items (may create duplicates if no stable IDs)
plane push
```

### Scenario: Recover schema from remote

```bash
# Replace local schema with remote
plane schema import --force

# Verify
plane schema diff     # Should show "in sync"
```

### Scenario: Start completely fresh

```bash
# Reset state
plane state reset --force

# Re-import everything from remote
plane schema import --force
plane pull
```

---

## 15. Custom Property Workflows

**Goal**: Use custom fields to track project-specific metadata.

### Define properties in schema

```yaml
# schema/types.yaml
Bug:
  description: A defect
  workflow: default
  properties:
    - name: severity
      type: option
      required: true
      options:
        - cosmetic
        - minor
        - major
        - critical
    - name: environment
      type: option
      options:
        - development
        - staging
        - production
    - name: is_regression
      type: boolean
    - name: found_in_version
      type: text
    - name: reported_by
      type: relation
      relation_type: user

Feature:
  description: New functionality
  workflow: default
  properties:
    - name: design_link
      type: url
    - name: target_release
      type: option
      options:
        - v2.0
        - v2.1
        - v3.0
    - name: t_shirt_size
      type: option
      options:
        - XS
        - S
        - M
        - L
        - XL
    - name: customer_requested
      type: boolean
    - name: requested_by
      type: email
```

### Use properties in work items

```yaml
# work/bugs.yaml
- id: BUG-1
  title: Payment form validation bypass
  type: Bug
  state: In Progress
  priority: urgent
  properties:
    severity: critical
    environment: production
    is_regression: true
    found_in_version: "2.3.1"
```

### Multi-select properties

Define with `is_multi: true`:

```yaml
# In schema/types.yaml
Bug:
  properties:
    - name: affected_browsers
      type: option
      is_multi: true
      options:
        - Chrome
        - Firefox
        - Safari
        - Edge
```

Use as a list in work items:

```yaml
- id: BUG-2
  title: Layout broken on mobile
  type: Bug
  properties:
    affected_browsers:
      - Safari
      - Chrome
```

### Clone with properties

To pull custom property values when cloning:

```bash
plane clone myteam/API --with-properties
```

This is slower (requires extra API calls per item) but gives you the full picture.
