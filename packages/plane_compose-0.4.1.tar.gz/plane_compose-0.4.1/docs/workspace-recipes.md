# Workspace Recipes

Step-by-step workflows for managing workspace-level configuration in Plane Compose.

---

## Table of Contents

1. [Clone and Manage Workspace as Code](#1-clone-and-manage-workspace-as-code)
2. [Sync Workspace Across Team](#2-sync-workspace-across-team)
3. [Manage Product Releases](#3-manage-product-releases)
4. [Define Strategic Initiatives](#4-define-strategic-initiatives)
5. [Add Custom Work Item Properties](#5-add-custom-work-item-properties)
6. [Manage Workspace for Multiple Planes](#6-manage-workspace-for-multiple-planes)
7. [Audit Workspace vs Project Responsibilities](#7-audit-workspace-vs-project-responsibilities)
8. [Sync Workspace Between Environments](#8-sync-workspace-between-environments)

---

## 1. Clone and Manage Workspace as Code

**Goal**: Get a local, version-controlled copy of your workspace configuration.

**When to use**: Team lead setting up infrastructure-as-code, centralizing workspace config.

### Step 1: Clone the Workspace

```bash
# Interactive (choose workspace)
plane ws clone

# Or specific workspace
plane ws clone myteam -c connection-2

# Into a specific directory
plane ws clone myteam -c connection-2 --path ./infra/
```

**Result**: Creates `myteam/` with:
```
myteam/
├── plane.yaml              # Workspace context
├── schema/                 # Configuration (Settings tab — changes rarely)
│   ├── features.yaml       # Feature flags (read-only)
│   ├── members.yaml        # Members (read-only)
│   ├── workitemtypes.yaml  # Types and properties
│   ├── project.yaml        # Shared project states + labels (push/pull/prune)
│   ├── initiatives.yaml    # Initiative labels
│   ├── releases.yaml       # Release tags + release labels (config)
│   ├── relations.yaml      # Relation type definitions (push/pull/prune)
│   └── webhooks.yaml       # Webhook configs (stub)
├── work/                   # Operational data (Details tab — changes frequently)
│   └── releases.yaml       # Actual releases
└── .plane/
    └── state.json          # Sync state
```

### Step 2: Review Generated Files

Examine each YAML file. Each has a descriptive header:

```bash
head -20 myteam/schema/features.yaml
head -20 myteam/schema/workitemtypes.yaml
head -20 myteam/schema/releases.yaml
```

### Step 3: Commit to Git

```bash
cd myteam/
git init
git add .gitignore
git add plane.yaml
git add schema/
git add .plane/state.json
git commit -m "Initial workspace configuration"
git remote add origin https://github.com/myorg/workspace-config.git
git push -u origin main
```

### Step 4: Make Changes

Edit workspace YAML files locally:

```yaml
# myteam/schema/releases.yaml
releases:
  - name: v2.0.0
    status: planning
    tag: v2.0.0

  - name: v1.5.0
    status: released
    tag: v1.5.0
```

### Step 5: Preview Changes

Before pushing, review what will change:

```bash
plane ws diff
```

### Step 6: Push to Plane

```bash
plane ws push --dry-run    # Preview first
plane ws push              # Or push directly
```

### Step 7: Share with Team

```bash
git add schema/
git commit -m "Add v2.0.0 release"
git push
```

Team members pull your changes:
```bash
cd myteam/
git pull
plane ws pull
```

---

## 2. Sync Workspace Across Team

**Goal**: Keep your team's workspace config in sync across local copies.

**When to use**: Multiple team members working with the same workspace.

### Scenario

- **Alice** (lead) manages releases in code
- **Bob** (developer) works on projects
- Both need to stay in sync

### Alice's Workflow: Push Changes

```bash
cd workspace-config/myteam/

# 1. Make changes
vim schema/releases.yaml

# 2. Preview
plane ws diff

# 3. Push to Plane
plane ws push

# 4. Commit and push to git
git add schema/releases.yaml
git commit -m "Add Q2 release cycle"
git push
```

### Bob's Workflow: Pull Changes

```bash
cd workspace-config/myteam/

# 1. Fetch latest from git
git pull

# 2. Sync from Plane
plane ws pull --merge

# 3. Now releases are available in his projects
cd ../api-project/
plane schema push
```

### Handle Conflicts

If both Alice and Bob edited locally:

```bash
cd myteam/

# Check differences
plane ws diff

# Option 1: Preserve local changes
plane ws pull --merge

# Option 2: Take remote (overwrite local)
plane ws pull --force

# Option 3: Manual merge
git diff schema/releases.yaml
vim schema/releases.yaml
git add schema/releases.yaml
plane ws pull --merge
```

---

## 3. Manage Product Releases

**Goal**: Define and track product releases in code, synchronized with Plane.

**When to use**: Coordinating releases across projects, tracking feature completeness.

### Step 1: Set Up Releases

**File**: `myteam/schema/releases.yaml`

```yaml
releases:
  - name: v1.0.0
    status: released
    tag: v1.0.0
    is_latest: true
    is_prerelease: false
    description: |
      Stable release with core features:
      - User authentication
      - Project management
      - Basic workflow

  - name: v1.1.0
    status: planning
    tag: v1.1.0
    is_latest: false
    is_prerelease: false
    description: |
      Planned release with enhancements:
      - Advanced permissions
      - Custom workflows
      - API v2

  - name: v2.0.0-alpha
    status: unreleased
    tag: v2.0.0-alpha
    is_latest: false
    is_prerelease: true
    description: Alpha release for early testing

release_tags:
  - name: Performance
    color: '#9900EF'
  - name: Security
    color: '#ff0000'
  - name: UI/UX
    color: '#00D084'
  - name: Backend
    color: '#0693e3'

labels:
  - name: Breaking Changes
    color: '#eb144c'
  - name: Deprecation
    color: '#fcb900'
```

### Step 2: Push to Plane

```bash
plane ws push --dry-run
# Verify output looks correct

plane ws push
# Creates releases in Plane
```

### Step 3: Assign Features to Releases

In Plane UI or via project YAML:

```bash
cd api-project/

# Edit work items
vim work/inbox.yaml
```

```yaml
- title: Implement OAuth2
  type: Feature
  priority: high
  release: v1.1.0      # Assign to release
  labels:
    - Security
    - Backend

- title: Custom workflow builder
  type: Feature
  priority: high
  release: v1.1.0
  labels:
    - Backend
```

Push to Plane:
```bash
plane push
```

### Step 4: Track Progress

In Plane UI:
- Navigate to Releases
- See feature count per release
- Track completion percentage

### Step 5: Keep Releases Updated

As you plan new releases, update the YAML:

```bash
cd myteam/

# Add v1.2.0 to the roadmap
vim schema/releases.yaml

# Push to Plane
plane ws push

# Commit
git add schema/releases.yaml
git commit -m "Plan v1.2.0 release"
git push
```

---

## 4. Define Strategic Initiatives

**Goal**: Organize work across projects using strategic initiatives.

**When to use**: Tracking OKRs, quarterly goals, long-term initiatives.

### Step 1: Define Initiatives

**File**: `myteam/schema/initiatives.yaml`

```yaml
labels:
  - name: "Q1 2024: Platform Stability"
    color: '#0693e3'
    description: Focus on reliability and performance
  
  - name: "Q1 2024: User Growth"
    color: '#00D084'
    description: Improve onboarding and feature discovery
  
  - name: "Tech Debt: Legacy Refactor"
    color: '#fcb900'
    description: Modernize old codebase
  
  - name: "Security: Compliance"
    color: '#eb144c'
    description: GDPR, SOC 2 preparation
```

### Step 2: Push to Plane

```bash
cd myteam/

plane ws push --dry-run
plane ws push
```

### Step 3: Tag Work Items with Initiatives

Across all projects, assign work items to initiatives:

```bash
cd api-project/
vim work/features.yaml

- title: Response time optimization
  type: Feature
  state: In Progress
  labels:
    - "Q1 2024: Platform Stability"  # Assigned to initiative

- title: OAuth2 provider integration
  type: Feature
  state: Backlog
  labels:
    - "Q1 2024: User Growth"

- title: Remove deprecated API endpoints
  type: Chore
  state: Backlog
  labels:
    - "Tech Debt: Legacy Refactor"
```

Push across projects:
```bash
plane push

cd ../other-project/
plane push
```

### Step 4: Review Initiative Progress

In Plane UI:
- Navigate to Initiatives section
- See all work items tagged per initiative
- Track completion across projects

---

## 5. Add Custom Work Item Properties

**Goal**: Add company-specific fields to work items (e.g., customer priority, OKR alignment).

**When to use**: Tracking domain-specific metadata (compliance, customer impact, etc.).

### Step 1: Define Properties

**File**: `myteam/schema/workitemtypes.yaml`

```yaml
properties:
  - name: Customer Priority
    type: OPTION
    description: How important this is to our customers
    options:
      - name: Enterprise Critical
        color: '#eb144c'
      - name: Strategic Customer
        color: '#fcb900'
      - name: Feedback
        color: '#7bdcb5'
  
  - name: OKR Alignment
    type: OPTION
    description: Which OKR this work supports
    options:
      - name: Revenue Growth
        color: '#0693e3'
      - name: Platform Reliability
        color: '#00D084'
      - name: Developer Experience
        color: '#9900EF'
      - name: None
        color: '#d4d4d8'
  
  - name: Estimation Confidence
    type: OPTION
    description: How confident we are in the estimate
    options:
      - name: High (±10%)"
        color: '#00D084'
      - name: Medium (±25%)"
        color: '#fcb900'
      - name: Low (±50%)"
        color: '#eb144c'
```

### Step 2: Sync to All Projects

```bash
cd myteam/

# Push workspace properties
plane ws push

# In each project, sync
cd ../api-project/
plane schema push

cd ../frontend-project/
plane schema push
```

### Step 3: Use Properties in Work Items

```bash
cd api-project/
vim work/features.yaml

- title: Implement GraphQL API
  type: Feature
  state: In Progress
  priority: high
  properties:
    Customer Priority: Enterprise Critical
    OKR Alignment: Developer Experience
    Estimation Confidence: High
  description: |
    Build GraphQL endpoint for mobile clients

- title: Email notification system
  type: Feature
  state: Backlog
  properties:
    Customer Priority: Strategic Customer
    OKR Alignment: Revenue Growth
    Estimation Confidence: Medium
```

Push:
```bash
plane push
```

### Step 4: Filter by Properties

In Plane UI:
- Filter work items by property values
- Build views showing high-confidence estimates
- Track enterprise customer work separately

---

## 6. Manage Workspace for Multiple Planes

**Goal**: Maintain identical configuration across multiple Plane instances (cloud + self-hosted).

**When to use**: Disaster recovery, multi-region deployment, testing setup.

### Step 1: Clone from Both Instances

```bash
# From Plane Cloud
plane ws clone myteam -c connection-cloud --path ./plane-cloud/

# From Self-Hosted
plane ws clone myteam -c connection-selfhosted --path ./plane-selfhosted/
```

### Step 2: Sync Local to Both

```bash
# Edit main config
vim plane-cloud/myteam/schema/releases.yaml

# Copy to self-hosted
cp plane-cloud/myteam/schema/releases.yaml plane-selfhosted/myteam/schema/

# Push to both
cd plane-cloud/myteam/ && plane ws push

cd ../../plane-selfhosted/myteam/ && plane ws push
```

### Step 3: Keep in Sync

Use a script to sync regularly:

```bash
#!/bin/bash
# sync-workspaces.sh

set -e

CLOUD="plane-cloud/myteam"
SELF_HOSTED="plane-selfhosted/myteam"

# Pull latest from both
cd "$CLOUD" && plane ws pull --merge
cd "../../$SELF_HOSTED" && plane ws pull --merge

# Copy from cloud to self-hosted
cp "$CLOUD/schema/"* "$SELF_HOSTED/schema/"

# Push self-hosted
cd "$SELF_HOSTED" && plane ws push

echo "✓ Workspaces synced"
```

Run periodically:
```bash
./sync-workspaces.sh
```

---

## 7. Audit Workspace vs Project Responsibilities

**Goal**: Ensure your team knows what's managed where.

**When to use**: Onboarding new team members, establishing process clarity.

### Create Documentation

**File**: `WORKSPACE_ADMIN.md`

```markdown
# Workspace Administration Guide

## What's Managed Here (In Code)

### ✅ Releases (`schema/releases.yaml`)
- Product release definitions
- Version numbering
- Release status and dates
- **Responsible**: Tech Lead / Product Manager

### ✅ Initiatives (`schema/initiatives.yaml`)
- Strategic initiatives
- OKR alignment
- Quarterly focus areas
- **Responsible**: Product Manager

### ✅ Work Item Types (`schema/workitemtypes.yaml`)
- Custom work item properties
- Type hierarchy
- **Responsible**: Tech Lead

## What's NOT in Code

### ❌ Features (`features.yaml`)
- **Why**: Admin settings
- **Manage via**: Plane UI → Workspace Settings
- **Responsible**: Workspace Admin

### ❌ Members (`members.yaml`)
- **Why**: Team management
- **Manage via**: Plane UI → Members
- **Responsible**: Workspace Admin

### ✅ Relations (`relations.yaml`)
- **Supported**: pull, push (create/update), prune (delete with `--prune`)
- **Manage via**: Edit `relations.yaml` + `plane ws push` / `plane ws push --prune`
- **Note**: System-default relations (`is_default: true`) cannot be deleted
- **Constraint**: `name`, `outward`, and `inward` must each be unique across the workspace

### ❌ Webhooks (`webhooks.yaml`)
- **Why**: Waiting for API key auth support
- **Manage via**: Plane UI → Webhooks
- **Responsible**: Infrastructure Team

## Project vs Workspace

| Item | Level | Who | How |
|------|-------|-----|-----|
| Features | Project | Developer | `plane schema push` |
| Work Items | Project | Developer | `plane push` |
| Labels | Project | Developer | `schema/labels.yaml` |
| Cycles | Project | Developer | `plane schema push` |
| Modules | Project | Developer | `plane schema push` |
| Custom Properties | Workspace | Tech Lead | `schema/workitemtypes.yaml` |
| Releases | Workspace | Product Manager | `schema/releases.yaml` |
| Initiatives | Workspace | Product Manager | `schema/initiatives.yaml` |
| Work Item Types | Workspace | Tech Lead | `schema/workitemtypes.yaml` |
```

### Share with Team

```bash
git add WORKSPACE_ADMIN.md
git commit -m "Add workspace administration guide"
git push

# Notify team
# Send link: docs/WORKSPACE_ADMIN.md
```

---

## 8. Sync Workspace Between Environments

**Goal**: Maintain workspace config across dev, staging, and production environments.

**When to use**: CI/CD, multi-environment deployments.

### Step 1: Set Up Three Workspaces

```bash
plane ws clone myteam-dev -c dev --path ./envs/dev/
plane ws clone myteam-staging -c staging --path ./envs/staging/
plane ws clone myteam-prod -c prod --path ./envs/prod/
```

### Step 2: Use Single Source of Truth

Keep main config in `main/`:

```
workspace-config/
├── main/myteam/                # Source of truth
│   └── schema/
├── envs/dev/myteam/           # Dev environment
├── envs/staging/myteam/       # Staging environment
└── envs/prod/myteam/          # Production environment
```

### Step 3: Deploy Script

```bash
#!/bin/bash
# deploy-workspace.sh

set -e

MAIN="main/myteam"
ENVS=("dev" "staging" "prod")

# Copy from main to all environments
for ENV in "${ENVS[@]}"; do
  TARGET="envs/$ENV/myteam"
  cp "$MAIN/schema/"* "$TARGET/schema/"
  
  # Push to environment
  cd "$TARGET"
  plane ws push --force
  cd ../../../
done

echo "✓ Workspace deployed to all environments"
```

### Step 4: CI/CD Integration

**.github/workflows/workspace-deploy.yml**:
```yaml
name: Deploy Workspace Config

on:
  push:
    paths:
      - 'main/myteam/schema/**'
    branches:
      - main

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Plane CLI
        run: |
          pipx install plane-compose
      
      - name: Configure Auth
        env:
          PLANE_AUTH_TOKEN: ${{ secrets.PLANE_AUTH_TOKEN_DEV }}
        run: plane auth login -w myteam-dev --server-url ${{ secrets.PLANE_SERVER_URL_DEV }}
      
      - name: Deploy to Dev
        run: |
          cd envs/dev/myteam
          plane ws push --force
      
      - name: Configure Auth (Prod)
        env:
          PLANE_AUTH_TOKEN: ${{ secrets.PLANE_AUTH_TOKEN_PROD }}
        run: plane auth login -w myteam-prod --server-url ${{ secrets.PLANE_SERVER_URL_PROD }}
      
      - name: Deploy to Prod
        run: |
          cd envs/prod/myteam
          plane ws push --force
```

### Step 5: Verify Deployments

```bash
# Check dev
cd envs/dev/myteam && plane ws diff

# Check staging
cd ../../staging/myteam && plane ws diff

# Check prod
cd ../../prod/myteam && plane ws diff
```

---

## See Also

- [Workspace Configuration](workspace-config.md) — Complete reference
- [Recipes](recipes.md) — Project-level workflows
- [Plane Compose Reference](plane-compose.md) — Full command documentation
