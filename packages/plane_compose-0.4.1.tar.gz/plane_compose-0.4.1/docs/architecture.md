# Plane Compose Architecture

## Overview

Plane Compose is a project-as-code framework for scaffolding and syncing projects with Plane.so. It follows a clean layered architecture with clear separation of concerns.

```
┌─────────────────────────────────────────────────────┐
│                  CLI Layer (Typer)                   │
│   User Commands: init, push, pull, clone, status    │
└─────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────┐
│              Business Logic Layer                    │
│      Sync, Diff, Validation, State Management       │
└─────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────┐
│              Backend Abstraction Layer               │
│         (Backend interface + implementations)        │
└─────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────┐
│                  External APIs                       │
│              (Plane SDK, HTTP Client)                │
└─────────────────────────────────────────────────────┘
```

## Layers

### 1. CLI Layer (`src/planecompose/cli/`)

**Purpose**: Presentation layer for user interaction

**Responsibilities**:
- Parse command-line arguments
- Display rich output to users
- Handle interactive prompts
- Coordinate business logic

**Key Files**:
- `root.py` - Main CLI entry point and command registration
- `init.py` - Project scaffolding
- `push.py` - Push schema and work items to Plane
- `pull.py` - Pull work items from Plane
- `clone.py` - Clone existing projects
- `schema.py` - Schema management (validate, push, import, diff, sync)
- `ws.py` - Workspace management (clone, pull, push, diff, state)
- `auth.py` - Authentication
- `status.py` - Sync status display
- `state_cmd.py` - State inspection and management
- `rate_stats.py` - Rate limit monitoring

### 2. Business Logic Layer (`src/planecompose/`)

**Purpose**: Core domain logic

**Responsibilities**:
- Work item diff calculation
- State synchronization
- Validation rules
- Content hashing
- Change detection and plan generation

**Key Modules**:
- `sync/planner.py` - Change detection, generates sync plans (create/update/skip)
- `sync/executor.py` - Parallel batch execution via asyncio.gather
- `sync/writer.py` - Converts remote data to local YAML format
- `parser/` - YAML parsing
- `utils/` - Shared utilities (rate limiting, errors, logging)

### 3. Backend Layer (`src/planecompose/backend/`)

**Purpose**: Data access abstraction

**Responsibilities**:
- Abstract API interactions
- Rate limiting (token bucket)
- Error handling and translation to typed exceptions
- Schema caching with O(1) lookups

**Key Files**:
- `base.py` - Abstract Backend interface
- `plane.py` - Plane SDK implementation
- `client.py` - PlaneApiClient with rate limiting and error translation
- `cache.py` - SchemaCache for O(1) lookups of types/states/labels

**Design Pattern**: Strategy pattern for swappable backends

```python
class Backend(ABC):
    @abstractmethod
    async def create_work_item(self, item: WorkItem) -> str:
        pass

class PlaneBackend(Backend):
    # Real implementation using Plane SDK
    pass

class MockBackend(Backend):
    # Test implementation
    pass
```

### 4. Data Layer (`src/planecompose/core/`)

**Purpose**: Domain models and data structures

**Responsibilities**:
- Define all data models
- Type validation with Pydantic
- Serialization/deserialization

**Key File**:
- `models.py` - All Pydantic models (WorkItem, SyncState, ProjectConfig, etc.)

### 5. State Layer (`src/planecompose/state/`)

**Purpose**: Terraform-style state management

**Key File**:
- `manager.py` - StateManager with file locking for concurrent safety

## Key Concepts

### State Management

Plane Compose uses a **Terraform-style state file** (`.plane/state.json`) to track:
- Remote IDs for local entities (types, states, labels, work items)
- Content hashes for change detection
- Last sync timestamps
- Mapping between local names and remote UUIDs

**Why?**
- Keeps local YAML files clean (no metadata pollution)
- Enables efficient change detection via content hashing
- Supports collaborative workflows

### Push vs Schema Sync

Plane Compose supports **two sync modes**:

1. **Push Mode** (`plane push`, `plane schema push`):
   - Additive only (create/update, never delete)
   - Safe for team collaboration
   - Multiple sources of truth can coexist

2. **Declarative Mode** (`plane schema sync`):
   - Makes remote schema match local exactly
   - Creates, updates, and deletes (states and labels)
   - Single source of truth for schema

### Workspace vs Project Sync

Plane Compose supports **two levels** of sync:

1. **Project-Level** (`plane push`, `plane pull`, `plane schema push/pull`):
   - Manages work items, project schema, cycles, modules
   - One `.plane/state.json` per project
   - Local source of truth for all project data

2. **Workspace-Level** (`plane ws clone/push/pull`):
   - Manages workspace configuration (features, members, releases, initiatives, work item types)
   - One `.plane/state.json` per workspace
   - Separate sync state from projects
   - Features optional (not required for project management)
   - Additive push (never deletes)

**Key Differences**:
| Aspect | Project | Workspace |
|--------|---------|-----------|
| Scope | Individual work stream | Shared infrastructure |
| State | Per-project | Per-workspace |
| Sync | `push`, `pull`, `schema push/pull/sync` | `ws push`, `ws pull`, `ws diff` |
| Merge Modes | `push` (additive) or `schema sync` (declarative) | `ws pull --merge` (preserve local additions) |
| Content | Work items, types, states, labels, cycles, modules | Features, members, releases, initiatives, custom properties |

### Rate Limiting

All API interactions go through a **token bucket rate limiter**:
- 50 requests per minute (configurable via `PLANE_RATE_LIMIT_PER_MINUTE`)
- 3000 requests per hour (configurable via `PLANE_RATE_LIMIT_PER_HOUR`)
- Automatic throttling with wait
- HTTP 429 handling
- Statistics tracking (`plane rate stats`)

### Content Hashing

Work items are tracked by:
1. **User-provided ID** (if specified via `id` field in YAML)
2. **Content hash** (SHA-256 fallback for items without IDs)

This enables:
- Stable tracking across renames
- Duplicate detection
- Change detection (hash comparison)

## Data Flow

### Push Flow

```
Local YAML Files (work/*.yaml)
      │
      ▼
Parse + Validate
      │
      ▼
Load State (.plane/state.json)
      │
      ▼
SyncPlanner: Calculate Diff (create/update/skip)
      │
      ▼
Display Plan → User Confirms
      │
      ▼
SyncExecutor: Parallel Batch API Calls (5 at a time)
      │
      ▼
Batch Update State + Save
```

### Pull Flow

```
API Request (rate-limited)
      │
      ▼
Fetch Work Items + Schema
      │
      ▼
PullWriter: Transform to Local Format
      │
      ▼
Write to .plane/remote/items.yaml
      │
      ▼
Update State with Schema Mappings
```

### Schema Sync Flow

```
Parse Local Schema (types, states, labels)
      │
      ▼
Fetch Remote Schema
      │
      ▼
Compare (case-insensitive matching)
      │
      ▼
Calculate Changes (create/update/delete)
      │
      ▼
Display Plan → User Confirms
      │
      ▼
Execute Creates + Updates + Deletes (states and labels)
      │
      ▼
Update State
```

## Design Principles

### 1. Dependency Inversion

High-level modules (CLI) don't depend on low-level modules (API). Both depend on abstractions (Backend interface).

### 2. Single Responsibility

Each module has one clear purpose:
- `cli/` - User interaction
- `backend/` - API calls
- `sync/` - Change detection and execution
- `state/` - State persistence
- `parser/` - YAML parsing

### 3. Type Safety

- Pydantic models everywhere
- Type hints on all functions
- Runtime validation

### 4. Separation of Concerns

- Configuration in `config/`
- Logging in `utils/logger.py`
- Rate limiting in `utils/rate_limit.py`
- Error handling via custom exceptions

### 5. Testability

- Mock backend for testing
- Fixtures for test data
- No global state (except singletons like logger/settings)

## Configuration

### Settings (`config/settings.py`)

All settings support environment variables with `PLANE_` prefix:

```bash
PLANE_API_URL=https://custom.plane.so
PLANE_RATE_LIMIT_PER_MINUTE=30
PLANE_DEBUG=true
```

### Project Config (`plane.yaml`)

```yaml
workspace: my-workspace
project:
  key: PROJ
  uuid: abc-123    # Auto-populated after first push
  name: My Project
defaults:
  type: Story
  workflow: default
```

## Error Handling

Custom exception hierarchy:

```
PlaneComposeError (base)
├── APIError (with status_code)
│   ├── RateLimitError (429)
│   ├── AuthenticationError (401)
│   ├── PermissionError (403)
│   └── NotFoundError (404)
├── ConfigError
├── ValidationError (with field)
├── StateError
├── NetworkError (with original_error)
└── ParserError (with file_path, line)
```

All exceptions include:
- Clear error messages
- Contextual details
- Proper HTTP status codes (for API errors)

All SDK errors are caught and translated in `backend/client.py` — the single place for error translation.

## Extension Points

### Adding New Commands

1. Create file in `cli/` (e.g., `cli/export.py`)
2. Define command using Typer
3. Register in `cli/root.py` via `_register_commands()`

### Adding New Backends

1. Implement `Backend` interface from `backend/base.py`
2. Add to `backend/` directory
3. Update CLI to support selection

### Adding New Parsers

1. Add parser in `parser/` directory
2. Update models in `core/models.py` if needed
3. Integrate into sync flow

## Security

### API Key Storage

- Stored in `~/.config/plane-compose/credentials`
- Permissions: 600 (owner read/write only)
- Never logged or displayed (masked in `plane auth whoami`)

### Rate Limiting

- Prevents API abuse
- Respects Plane's limits
- Automatic backoff

### Input Validation

- All user input validated with Pydantic
- YAML parsing with safe loader
- No arbitrary code execution

## Contributing

See `docs/development.md` for:
- Setting up development environment
- Running tests
- Code style guidelines
- Pull request process
