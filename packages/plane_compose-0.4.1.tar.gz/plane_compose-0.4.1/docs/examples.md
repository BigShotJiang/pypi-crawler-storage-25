# Plane Compose Examples

## Basic Workflows

### 1. Starting a New Project

**Interactive Setup:**
```bash
# Authenticate
plane auth login

# Initialize project structure
plane init API -w myteam
cd api/

# Push schema to create project in Plane
plane schema push

# Add work items in work/inbox.yaml
vim work/inbox.yaml

# Push work items
plane push

# Check status
plane status
```

**Non-interactive Setup (CI/CD):**
```bash
# Set environment variables
export PLANE_AUTH_TOKEN="your-api-key"
export PLANE_WORKSPACE="myteam"

# Authenticate (uses env vars, no prompts)
plane auth login

# Initialize project structure
plane init API -w myteam
cd api/

# Push schema and work items
plane schema push
plane push

# Check status
plane status
```

### 2. Cloning an Existing Project

```bash
# Clone using workspace/key shorthand
plane clone myteam/API

# Or by key with workspace flag
plane clone API --workspace=myteam

# Or by UUID
plane clone ba251175-682e-4e59-aa0c-0d37f59f1a54 --workspace=myteam

# Navigate to cloned project
cd api/

# Check what was pulled
ls .plane/remote/items.yaml

# Make changes
vim work/inbox.yaml

# Push changes
plane push
```

### 3. Collaborative Workflow

```bash
# Pull latest items from Plane
plane pull

# Make local changes
vim work/features.yaml

# Preview what would change
plane push --dry-run

# Push only your changes (additive — never deletes)
plane push
```

## Schema Examples

### 4. Custom Work Item Types with Properties

```yaml
# schema/types.yaml
Feature:
  description: Net-new functionality or capability
  workflow: default
  properties:
    - name: target_release
      display_name: Target Release
      type: text
    - name: priority_tier
      display_name: Priority
      type: option
      required: true
      options:
        - p0
        - p1
        - p2
        - p3

Bug:
  description: Software defect
  workflow: default
  properties:
    - name: severity
      type: option
      options:
        - critical
        - major
        - minor
      required: true
    - name: affected_version
      type: text
    - name: is_regression
      type: boolean
    - name: environment
      type: option
      options:
        - development
        - staging
        - production

Improvement:
  description: Enhancement to existing functionality
  workflow: default

Chore:
  description: Maintenance, ops, or housekeeping work
  workflow: default
```

### 5. Workflow Definitions

```yaml
# schema/workflows.yaml
default:
  states:
    - name: Backlog
      group: backlog
      color: "#94a3b8"
    - name: Todo
      group: unstarted
      color: "#3b82f6"
    - name: In Progress
      group: started
      color: "#f59e0b"
    - name: In Review
      group: started
      color: "#8b5cf6"
    - name: Done
      group: completed
      color: "#22c55e"
    - name: Cancelled
      group: cancelled
      color: "#ef4444"
```

**Note**: Triage is a system-managed state in Plane — you don't need to define it, and it's ignored during push.

### 6. Label Definitions

```yaml
# schema/labels.yaml — flat list format (recommended)
- name: Frontend
  color: "#3b82f6"

- name: Backend
  color: "#10b981"

- name: Infrastructure
  color: "#6366f1"

- name: Documentation
  color: "#8b5cf6"

- name: Urgent
  color: "#ef4444"

- name: Blocked
  color: "#f97316"
```

## Work Item Structures

### 7. Epic with Child Tasks

```yaml
# work/features.yaml
- id: feat-auth
  title: User Authentication System
  description: |
    Implement complete user authentication with OAuth2,
    email verification, and password reset.
  type: Feature
  state: In Progress
  priority: high
  labels:
    - Backend
  assignees:
    - tech-lead@example.com
  watchers:
    - pm@example.com
    - qa@example.com

  children:
    - id: task-auth-oauth
      title: Implement OAuth2 login
      description: Add Google, GitHub OAuth
      type: Feature
      state: In Progress
      priority: high
      assignees:
        - dev1@example.com
      labels:
        - Backend

    - id: task-auth-email
      title: Email verification flow
      type: Feature
      state: Todo
      priority: high
      assignees:
        - dev2@example.com
      labels:
        - Backend

    - id: task-auth-reset
      title: Password reset functionality
      type: Feature
      state: Todo
      priority: medium
      labels:
        - Backend
```

### 8. Bugs with Rich Metadata

```yaml
# work/bugs.yaml
- id: bug-001
  title: Login fails on Safari
  description: |
    ## Steps to Reproduce
    1. Open Safari browser
    2. Navigate to /login
    3. Enter credentials
    4. Click Login button

    ## Expected
    User should be logged in

    ## Actual
    Error message: "Network request failed"

    ## Environment
    - Safari 17.0
    - macOS Sonoma
  type: Bug
  state: In Progress
  priority: urgent
  labels:
    - Frontend
    - Urgent
  assignees:
    - frontend-lead@example.com
  watchers:
    - qa@example.com
    - pm@example.com
  properties:
    severity: critical
    affected_version: "1.2.3"
    environment: production
    is_regression: true
```

### 9. Dependencies and Blocking

```yaml
# work/release.yaml
- id: REL-1
  title: Feature freeze
  type: Chore
  state: Done
  due_date: "2026-03-01"

- id: REL-2
  title: QA regression pass
  type: Chore
  state: In Progress
  due_date: "2026-03-05"
  blocked_by:
    - REL-1

- id: REL-3
  title: Performance benchmarks
  type: Chore
  state: Todo
  blocked_by:
    - REL-1

- id: REL-4
  title: Staging deploy
  type: Chore
  state: Backlog
  blocked_by:
    - REL-2
    - REL-3

- id: REL-5
  title: Production deploy
  type: Chore
  state: Backlog
  blocked_by:
    - REL-4
```

## Team-Based Workflows

### 10. Frontend Team

```yaml
# work/frontend.yaml
- id: fe-001
  title: Redesign dashboard UI
  type: Feature
  state: In Progress
  labels:
    - Frontend
  assignees:
    - designer@example.com
  priority: high

- id: fe-002
  title: Add dark mode support
  type: Improvement
  state: Todo
  labels:
    - Frontend
  assignees:
    - fe-dev@example.com
  priority: medium
```

### 11. Backend Team

```yaml
# work/backend.yaml
- id: be-001
  title: Optimize database queries
  type: Improvement
  state: In Progress
  labels:
    - Backend
  assignees:
    - backend-dev@example.com
  priority: high

- id: be-002
  title: Add API rate limiting
  type: Feature
  state: Todo
  labels:
    - Backend
  assignees:
    - backend-lead@example.com
  priority: high
```

### 12. Using Labels for Sprint Organization

```yaml
# work/sprint-current.yaml
- id: sp23-001
  title: Implement user profile page
  type: Feature
  state: In Progress
  labels:
    - Frontend
  assignees:
    - dev1@example.com
  priority: high

- id: sp23-002
  title: Fix memory leak in background worker
  type: Bug
  state: In Progress
  labels:
    - Backend
    - Urgent
  assignees:
    - dev2@example.com
  priority: urgent
  properties:
    severity: major

- id: sp23-003
  title: Update API documentation
  type: Chore
  state: Todo
  labels:
    - Documentation
  assignees:
    - tech-writer@example.com
  priority: low
```

## Schema Management

### 13. Schema Diff and Sync

```bash
# Compare local schema with remote
plane schema diff

# Output:
# Types:
#   + Only in local: Epic
#   - Only in remote: Spike
#   = In both: 4 types
#
# States:
#   = In both: 8 states
#
# Labels:
#   - Only in remote: P0, P1
#   = In both: 5 labels

# Import missing items from remote (additive)
plane schema import --merge

# Push your local additions to remote
plane schema push

# Or make remote match local exactly (declarative)
plane schema sync --dry-run    # Preview first
plane schema sync              # Apply
```

### 14. Rate Limit Management

```bash
# Check rate limit statistics
plane rate stats

# Output:
# Rate Limit Statistics
# ┏━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━┓
# ┃ Metric              ┃ Value  ┃
# ┡━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━┩
# │ Total Requests      │ 145    │
# │ Last Minute         │ 12     │
# │ Last Hour           │ 145    │
# │ Rate Limit (minute) │ 50     │
# │ Rate Limit (hour)   │ 3000   │
# │ Utilization (min)   │ 24%    │
# │ Total Wait Time     │ 2.3s   │
# └─────────────────────┴────────┘

# Reset stats
plane rate reset

# Configure via environment
export PLANE_RATE_LIMIT_PER_MINUTE=30
plane push
```

## Common Patterns

### Pattern 1: Feature Branch Workflow

```bash
# Create feature branch
git checkout -b feature/new-dashboard

# Add work items for feature
cat > work/dashboard.yaml << 'EOF'
- id: dash-001
  title: Design dashboard mockups
  type: Chore
  state: Done

- id: dash-002
  title: Implement dashboard components
  type: Feature
  state: In Progress
EOF

# Push to Plane
plane push

# When feature is done, merge to main
git checkout main
git merge feature/new-dashboard
```

### Pattern 2: Sprint Planning

```bash
# Pull all items at start of sprint
plane pull

# Review remote items
cat .plane/remote/items.yaml

# Create sprint file
vim work/sprint-24.yaml

# Push sprint items
plane push

# Track sprint status
plane status
```

### Pattern 3: Bug Triage

```bash
# Pull latest from Plane
plane pull

# Create bugs file with stable IDs
cat > work/bugs-nov.yaml << 'EOF'
- id: bug-nov-001
  title: Payment form validation bypass
  type: Bug
  state: Backlog
  priority: urgent
  labels:
    - Urgent
    - Backend
  properties:
    severity: critical
    environment: production
EOF

# Push bugs
plane push
```

### Pattern 4: Release Management

```yaml
# work/v1.2.0.yaml
- id: rel-120-1
  title: "v1.2.0: Feature A"
  type: Feature
  state: Done
  labels:
    - Backend

- id: rel-120-2
  title: "v1.2.0: Feature B"
  type: Feature
  state: In Review
  labels:
    - Frontend
```

```bash
plane push
plane status
```

## Environment Variables

```bash
# API Configuration
export PLANE_API_URL="https://custom.plane.so"
export PLANE_API_TIMEOUT=60

# Rate Limiting
export PLANE_RATE_LIMIT_PER_MINUTE=30

# Debugging
export PLANE_DEBUG=true
export PLANE_VERBOSE=true

# Logging
export PLANE_LOG_TO_FILE=true
```

## Tips & Tricks

### Tip 1: Use Descriptive IDs

```yaml
# Good — descriptive and stable
- id: auth-oauth-google
  title: Add Google OAuth

# Avoid — not meaningful
- id: task-001
  title: Add Google OAuth
```

### Tip 2: Organize by Feature or Team

```
work/
├── features.yaml
├── bugs.yaml
├── tech-debt.yaml
└── sprint-24.yaml
```

All `.yaml` files under `work/` are automatically discovered.

### Tip 3: Preview Before Pushing

```bash
# Always preview first
plane push --dry-run

# Then apply
plane push
```

### Tip 4: Automate with Scripts

```bash
#!/bin/bash
# daily-sync.sh

# Pull latest
plane pull

# Push changes
plane push

# Commit state
git add .plane/state.json work/
git commit -m "Daily sync: $(date)"
```

### Tip 5: Use Watchers for Visibility

```yaml
- title: Launch new feature
  type: Feature
  assignees:
    - dev@example.com
  watchers:
    - pm@example.com
    - qa@example.com
    - marketing@example.com
```

## Troubleshooting Examples

### Issue: Duplicate Work Items

```bash
# Check state
plane state show

# Clear work item tracking (keeps schema)
plane state clear-items

# Add id fields to your work items, then re-push
plane push
```

### Issue: Sync Conflicts

```bash
# Pull latest
plane pull

# Review remote items
cat .plane/remote/items.yaml

# Compare with your local
diff work/inbox.yaml .plane/remote/items.yaml

# Resolve manually, then push
plane push
```

### Issue: Rate Limit Errors

```bash
# Check rate limit
plane rate stats

# Wait or reduce rate
export PLANE_RATE_LIMIT_PER_MINUTE=20

# Retry
plane push
```
