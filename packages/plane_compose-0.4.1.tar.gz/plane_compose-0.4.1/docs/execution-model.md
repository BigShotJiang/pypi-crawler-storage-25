# Execution Model

How Plane Compose plans, previews, and executes sync operations. Understanding this model helps you predict what will happen before it happens.

---

## Table of Contents

1. [The Plan → Confirm → Execute Loop](#the-plan--confirm--execute-loop)
2. [How Changes Are Detected](#how-changes-are-detected)
3. [Schema Operations](#schema-operations)
4. [Work Item Operations](#work-item-operations)
5. [The Sync Plan](#the-sync-plan)
6. [Dry Run Mode](#dry-run-mode)
7. [Execution: Parallel Batch Processing](#execution-parallel-batch-processing)
8. [State Updates](#state-updates)
9. [What You See: Command Output Walkthrough](#what-you-see-command-output-walkthrough)
10. [Error Handling](#error-handling)
11. [Idempotency and Safety](#idempotency-and-safety)

---

## The Plan → Confirm → Execute Loop

Every mutating command in Plane Compose follows the same three-phase pattern:

```
┌──────────┐     ┌──────────┐     ┌──────────┐
│  1. PLAN  │ ──→ │2. CONFIRM│ ──→ │3. EXECUTE│
│           │     │          │     │          │
│ Compare   │     │ Show the │     │ Apply    │
│ local vs  │     │ plan and │     │ changes  │
│ state vs  │     │ ask user │     │ to Plane │
│ remote    │     │          │     │          │
└──────────┘     └──────────┘     └──────────┘
                       │
                  ┌────┴────┐
                  │ --dry-run│ stops here
                  │ --force  │ skips confirm
                  └─────────┘
```

1. **Plan**: Read local files, load state, compare with remote. Determine what to create, update, skip, or delete.
2. **Confirm**: Display the plan as tables. Ask the user to confirm (unless `--force`).
3. **Execute**: Apply the changes to Plane via API. Update local state.

`--dry-run` stops after phase 1 (shows the plan, makes no changes).
`--force` skips phase 2 (no confirmation prompt).

---

## How Changes Are Detected

### Content Hashing

Every work item is hashed (SHA-256) based on its content — title, description, type, state, priority, labels, properties, etc. This hash is stored in `.plane/state.json`.

On the next `plane push`, each item's current hash is compared to the stored hash:

```
Item in YAML  →  Calculate hash  →  Compare with state
                                          │
                                    ┌─────┴─────┐
                                    │            │
                              Hash matches   Hash differs
                                    │            │
                                  SKIP        UPDATE
```

Items not in state at all → **CREATE**.

### Tracking Keys

Each item is identified by a **tracking key**:

- If the item has an `id` field → the `id` is the tracking key (e.g., `"API-1"`)
- If the item has no `id` → a content-derived hash is used

This is why stable IDs matter: without them, any content change makes the item look "new" instead of "updated."

### Schema Matching

Schema items (types, states, labels) are matched **by name, case-insensitively**:

- Local `"Bug"` matches remote `"bug"` → recognized as same item
- Local `"In Progress"` matches remote `"in progress"` → same item
- Local `"Epic"` with no remote match → needs to be created

---

## Schema Operations

### `plane schema push` (Additive)

Compares local schema names with remote schema names. Only creates what's missing:

```
Local types:  [Bug, Feature, Epic]
Remote types: [Bug, Feature]
─────────────────────────────────
Action:       Create Epic
```

Never updates or deletes existing remote items. This is the safe default.

### `plane schema sync` (Declarative)

Makes remote match local exactly:

```
Local types:  [Bug, Feature, Epic]
Remote types: [Bug, Feature, Task]
──────────────────────────────────────
Actions:      Create Epic
              Delete Task (flagged, not executed — API limitation)
              Skip Bug, Feature (already match)
```

Additionally detects attribute differences (description, color, etc.) and updates them.

### `plane schema import` (Remote → Local)

Three modes, all reading from remote:

| Mode | What it does | Modifies files? |
|------|-------------|-----------------|
| Default | Maps local names → remote UUIDs in state | No |
| `--merge` | Adds remote-only items to local files | Yes (additive) |
| `--force` | Replaces local files with remote data | Yes (destructive) |

### `plane schema diff` (Read-Only)

Shows the comparison without doing anything:

```
Types:
  + Only in local: Epic
  - Only in remote: Task
  = In both: 2 types
```

---

## Work Item Operations

### `plane push`

The planner classifies each work item in `work/*.yaml`:

| Condition | Action | Reason |
|-----------|--------|--------|
| Tracking key not in state | **CREATE** | New item |
| Tracking key in state, hash changed | **UPDATE** | Content modified |
| Tracking key in state, hash unchanged | **SKIP** | No changes |

`plane push` never deletes items. If you remove an item from your YAML, it stays in Plane (and in state). This is intentional — push is collaborative and safe.

### `plane pull`

Fetches remote items and writes them to `.plane/remote/items.yaml`. Does not modify your `work/` files.

---

## The Sync Plan

The planner produces a structured plan:

```
SyncPlan
├── creates: [SyncItem, ...]     # Items to create in Plane
├── updates: [SyncItem, ...]     # Items to update in Plane
├── deletes: [SyncItem, ...]     # Items to delete (apply mode only)
└── skipped: [SyncItem, ...]     # Unchanged items (informational)
```

Each `SyncItem` carries:

| Field | Description |
|-------|-------------|
| `action` | CREATE, UPDATE, DELETE, or SKIP |
| `item` | The full WorkItem from YAML |
| `tracking_key` | Stable ID or content hash |
| `source_file` | Which YAML file (e.g., `work/bugs.yaml`) |
| `index` | Position in that file |
| `remote_id` | Remote UUID (for updates/deletes) |
| `reason` | Human-readable explanation |

---

## Dry Run Mode

Every mutating command supports `--dry-run` / `-n`. In dry run:

1. The plan is generated (reads local files, loads state, connects to Plane for remote comparison).
2. The plan is displayed to the user in the same format as a real run.
3. **No API calls are made** to create, update, or delete.
4. **State is not modified.**
5. The message `"Dry run mode - no changes applied"` is shown.

```bash
# See what schema push would do
plane schema push --dry-run

# See what work item push would do
plane push --dry-run

# See what declarative sync would do
plane schema sync --dry-run
```

Dry run is **always safe** — it only reads.

---

## Execution: Parallel Batch Processing

When the plan is confirmed, the executor processes items in parallel batches for performance.

### Batch Strategy

```
Plan: [CREATE item1, CREATE item2, ..., CREATE item15, UPDATE item16, UPDATE item17]

Execution order:
  Batch 1 (creates):  [item1, item2, item3, item4, item5]    ← parallel
  Batch 2 (creates):  [item6, item7, item8, item9, item10]   ← parallel
  Batch 3 (creates):  [item11, item12, item13, item14, item15] ← parallel
  Batch 4 (updates):  [item16, item17]                        ← parallel
```

- **Batch size**: 5 items per batch (default)
- **Within a batch**: All items execute concurrently via `asyncio.gather()`
- **Between batches**: Sequential (wait for one batch to complete before starting the next)
- **Creates before updates**: All creates run first, then all updates

This provides roughly **5x throughput** compared to sequential processing, while staying within rate limits.

### Rate Limiting

The API client enforces rate limits (default: 50 requests/minute). If a batch would exceed the limit, the client automatically waits before sending the next request. You'll see this as a brief pause in the progress bar.

Check current utilization:

```bash
plane rate stats
```

---

## State Updates

State is updated **once** after all operations complete — not per-item:

```
Execute all items
       │
       ▼
Collect results (successes + failures)
       │
       ▼
Batch update state file (single lock acquisition)
       │
       ▼
Release lock
```

For each successful create:
```json
{
  "API-1": {
    "remote_id": "uuid-from-plane",
    "content_hash": "sha256:abc123...",
    "source": "work/features.yaml:0",
    "last_synced": "2026-02-24T10:30:00Z"
  }
}
```

For each successful update: the `content_hash` and `last_synced` are refreshed.

Failed items are **not** written to state — they remain in their previous state (or absent), so the next push will retry them.

---

## What You See: Command Output Walkthrough

### `plane push` — Full Flow

**Phase 1: Connection**

```
⠙ Connecting to Plane...
⠹ Fetching project details...
```

**Phase 2: Schema push** (if not `--work-only`)

```
Schema Push Plan

  Work Item Types (1 to create)
┏━━━━━━━┳━━━━━━━━━━━━━━┓
┃ Name  ┃ Description  ┃
┡━━━━━━━╇━━━━━━━━━━━━━━┩
│ Epic  │ Large body...│
└───────┴──────────────┘

Summary: 1 items to create

Apply these changes? [y/N]:
```

**Phase 3: Work items plan**

```
Work Items Push Plan

  Items to Create (3)
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━━━┓
┃ Title                          ┃ Type    ┃ Priority ┃ Labels       ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━━━┩
│ Implement webhook system       │ Feature │ high     │ notifications│
│ Fix race condition             │ Bug     │ urgent   │ payments     │
│ Add cursor pagination          │ Feature │ medium   │ tech-debt    │
└────────────────────────────────┴─────────┴──────────┴──────────────┘

  Items to Update (1)
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Title                          ┃ Type    ┃ Reason                  ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ Update error handling          │ Chore   │ content changed         │
└────────────────────────────────┴─────────┴─────────────────────────┘

Create 3, Update 1 work items? [y/N]:
```

**Phase 4: Execution**

```
⠙ Syncing 4 work items... ████████░░░ 3/4 — Fix race condition
```

The progress bar shows the current item title for context.

**Phase 5: Summary**

```
✓ Pushed schema (1.8s)
✓ Created 3 work items
✓ Updated 1 work item
  Total time: 4.2s
```

### `plane push --dry-run`

Same as above through Phase 3, then:

```
Dry run mode - no changes applied
```

### `plane clone`

```
Cloning myteam/API...

⠋ Looking up project API...
⠙ Fetching project details...
⠹ Fetching work item types...
⠸ Building property maps for 4 types...
⠼ Fetching workflow states...
⠴ Fetching labels...
⠦ Fetching workflows...
⠧ Fetching members...
⠇ Fetching cycles...
⠏ Fetching modules...
⠋ Fetching work items...
⠙ Processing 128 work items...

┌─────────────────────────────────────────────┐
│ ✓ Successfully cloned project: Core API     │
│                                             │
│ Directory: api/                             │
│ Project: API (8cee0da2-...)                 │
│ Members: 4 in schema/members.yaml           │
│ Workflows: 2 in schema/workflows.yaml       │
│ Work items: 128 in .plane/remote/items.yaml │
│ Cycles: 3 in schema/cycles.yaml             │
│ Modules: 5 in schema/modules.yaml           │
│ Time: 12.4s                                 │
│                                             │
│ Timing Breakdown:                           │
│   Types: 0.8s                               │
│   States: 0.4s                              │
│   Labels: 0.3s                              │
│   Cycles: 0.2s                              │
│   Modules: 0.3s                             │
│   Work Items: 3.2s                          │
│                                             │
│ Next steps:                                 │
│   1. cd api                                 │
│   2. Review items in .plane/remote/items.yaml│
│   3. Review cycles/modules in schema/       │
│   4. Add your own items to work/inbox.yaml  │
│   5. plane push to sync your changes        │
└─────────────────────────────────────────────┘
```

### `plane status`

```
Project: API (Core API)
  Workspace: mycompany
  UUID: 8cee0da2-1b5b-4699-b11a-e3c8b26dd55d
  Root: /home/user/projects/api

Schema:
  Types:  4 local, 4 synced  ✓
  States: 9 local, 9 synced  ✓
  Labels: 8 local, 8 synced  ✓

Work Items:
  Pending: 2 items (not yet pushed)
  Synced:  15 items

Last sync: 2026-02-24T10:30:00Z

Next steps:
  plane push    Push 2 pending items
```

---

## Error Handling

### Per-Item Resilience

If one item fails during execution, others continue:

```
⠙ Syncing 5 work items... ████████░░ 4/5

✓ Created 4 work items
✗ 1 item failed
  - "Invalid label name": Label 'nonexistent' not found in project
```

The 4 successful items are saved to state. The failed item remains un-synced and will be retried on the next `plane push`.

### Common Failure Reasons

| Error | Cause | Fix |
|-------|-------|-----|
| `Type 'X' not found` | Type name doesn't match remote | Run `plane schema push` first, or check case |
| `State 'X' not found` | State name doesn't match remote | Run `plane schema push` first |
| `Label 'X' not found` | Label doesn't exist in project | Add to `labels.yaml` and `plane schema push` |
| `Rate limit exceeded` | Too many API calls | Increase `PLANE_RATE_LIMIT_PER_MINUTE` |
| `Authentication error` | API key invalid or expired | Run `plane auth login` |
| `Permission denied` | Insufficient project access | Check workspace membership |

### Retrying Failed Items

Failed items are not tracked in state. On the next `plane push`, they appear as CREATE actions again — the system automatically retries them.

---

## Idempotency and Safety

### Push is Safe to Repeat

Running `plane push` multiple times is harmless:

- Items already created (in state) with unchanged content → **SKIP**
- Items already created with changed content → **UPDATE**
- New items → **CREATE**

No duplicates are created as long as items have stable `id` fields.

### Schema Push is Additive

`plane schema push` only creates what's missing. Running it twice does nothing the second time. It never modifies or deletes existing remote schema items.

### State is the Bridge

The state file (`.plane/state.json`) is the single source of truth for what's been synced:

```
                ┌─────────────┐
                │ state.json  │
                │             │
  Local YAML ──→│ tracking_key│──→ Remote UUID
                │ content_hash│
                │ last_synced │
                └─────────────┘
```

If state is lost (deleted or reset), the system loses track of what's been pushed. The next push will attempt to create everything again — which may create duplicates for items without stable IDs.

**Always commit `.plane/state.json` to git.**

### Force Flag Behavior

| Command | `--force` effect |
|---------|-----------------|
| `plane push --force` | Skip confirmation prompt |
| `plane schema push --force` | Skip confirmation prompt |
| `plane schema sync --force` | Skip confirmation prompt |
| `plane schema import --force` | Overwrite local files with remote data |
| `plane state reset --force` | Delete state file without confirmation |
| `plane state clear-items --force` | Clear work item tracking without confirmation |

`--force` never means "overwrite remote" — it means "don't ask me, just do it" (for most commands) or "replace local with remote" (for import).
