# Plane Compose Documentation

Welcome to the Plane Compose documentation! This guide helps you get the most out of this project-as-code framework.

## Quick Links

| Document | Description |
|----------|-------------|
| [Plane Compose Reference](plane-compose.md) | Comprehensive single-page reference |
| [Installation](INSTALL.md) | Installation via pipx |
| [Architecture](architecture.md) | System design and technical overview |
| [Declarative Model](declarative-model.md) | How the Terraform-style sync model works |
| [Execution Model](execution-model.md) | How plan, confirm, and execute works |
| [Development](development.md) | Contributing guide and development setup |
| [Workspace Configuration](workspace-config.md) | **NEW**: Manage workspace-level settings as code |
| [Workspace Recipes](workspace-recipes.md) | **NEW**: Step-by-step workspace workflows |
| [Examples](examples.md) | Common workflows and usage patterns |
| [Example Projects](example-projects.md) | Copy-paste-ready project configurations |
| [Recipes](recipes.md) | Step-by-step guides for common tasks |
| [Use Cases](use-cases.md) | Real-world scenarios by team type |
| [Troubleshooting](troubleshooting.md) | Common issues and solutions |
| [Work Item Fields](WORK_ITEM_FIELDS.md) | Available fields and properties |
| [Self-Hosted Setup](SELF_HOSTED.md) | Configure for self-hosted Plane |

## Getting Started

The fastest way to get started is in the main [README](../README.md).

**Interactive Mode:**
```bash
# Install
pipx install plane-compose

# Authenticate
plane auth login

# Initialize a project
plane init API -w myteam
cd api/

# Push your schema
plane schema push

# Add work items to work/inbox.yaml, then push
plane push
```

**Non-Interactive Mode (CI/CD):**
```bash
# Set environment variables
export PLANE_AUTH_TOKEN="your-api-key"
export PLANE_WORKSPACE="myteam"

# Authenticate (uses env vars, no prompts)
plane auth login

# Initialize and push
plane init API -w myteam
cd api/ && plane schema push && plane push
```

**Workspace-Level Configuration (Optional):**
```bash
# Clone workspace config (features, releases, initiatives, work item types)
plane ws clone myteam -c connection-1

# Manage workspace settings as code
cd myteam/
vim schema/releases.yaml
vim schema/initiatives.yaml

# Sync with Plane
plane ws pull    # Get latest from Plane
plane ws push    # Push local changes
```

See [Workspace Configuration](workspace-config.md) for complete guide.

## Command Reference

```bash
plane --help              # Show all commands
plane <command> --help    # Show command help

# Project Commands
plane init                        # Initialize new project
plane init <project> -w <ws>      # Create project in specific workspace
plane init <project> -t <template># Initialize with custom template (local path or Git URL)
plane clone <PROJECT>             # Clone existing project (UUID, KEY, or workspace/KEY)
plane status                      # Show sync status

# Schema Commands
plane schema validate     # Validate local schema files
plane schema push         # Push schema to Plane (additive)
plane schema import       # Import schema from Plane (state-only, --merge, or --force)
plane schema diff         # Compare local vs remote schema
plane schema sync         # Declarative sync — make remote match local exactly

# Work Item Commands
plane push                # Push schema + work items to Plane
plane pull                # Pull work items from Plane

# Workspace Commands (Manage workspace-level config)
plane ws clone <WS>               # Clone workspace configuration locally
plane ws pull [WS]                # Pull workspace updates from Plane
plane ws push [WS]                # Push workspace additions to Plane
plane ws diff [WS]                # Show differences between local and remote
plane ws state [WS]               # Inspect/manage workspace sync state

# Auth Commands
plane auth login                      # Authenticate (interactive by default)
plane auth login -w <workspace>       # Semi-interactive (prompt for missing values)
plane auth login --server-url X       # Non-interactive with flags (provide all required)
plane auth whoami                     # Show current user
plane auth logout <connection-id>     # Remove credentials (with confirmation)
plane auth logout <connection-id> -f  # Remove credentials (skip confirmation)

# State Commands
plane state show          # Inspect sync state
plane state reset         # Reset state file
plane state clear-items   # Clear work item tracking (keep schema)
plane state remove <KEY>  # Remove specific item from tracking

# Rate Limit Commands
plane rate stats          # Show rate limit statistics
plane rate reset          # Reset rate limit counters

# Multi-Project
plane push --all          # Push all projects recursively
plane pull --all          # Pull all projects
plane status --all        # Status for all projects

# Global Options
--version, -V             # Show version
--verbose, -v             # Verbose output
--debug                   # Debug logging
```

## Getting Help

- **Issues**: [GitHub Issues](https://github.com/makeplane/compose/issues)
- **API Docs**: [Plane API Documentation](https://docs.plane.so/api)
