# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Plane Compose is a "Project as Code" framework for [Plane](https://plane.so) - a Terraform-like CLI for managing projects, schemas, and work items via YAML files with declarative sync.

**Key Documentation**:
- [Declarative Model](docs/declarative-model.md) - How the Terraform-style sync model works
- [Roadmap](ROADMAP.md) - Enterprise features and multi-project support

## Declarative Model (v0.4.0)

Plane Compose follows a **local-is-source-of-truth** model like Terraform:

```
LOCAL FILES (schema/*.yaml)  →  STATE (.plane/state.json)  →  REMOTE (Plane)
     ▲
     └── SOURCE OF TRUTH (you edit these)
```

### Core Commands

| Command | Purpose | Modifies Local? |
|---------|---------|-----------------|
| `plane schema push` | Make remote match local | No |
| `plane schema import` | Connect local to remote IDs | No (state only) |
| `plane schema import --merge` | Add missing from remote | Yes (additive) |
| `plane schema import --force` | Replace local with remote | Yes (destructive) |
| `plane schema diff` | Show differences | No |
| `plane push` | Push work items | No |
| `plane clone <uuid>` | Create new project from remote | Creates new |

### Multi-Project Support (v0.4.0)

```bash
plane push ./projects/api       # Path-based operations
plane push --all                # Batch operations
plane status --all --workspace=myteam  # With filters
```

## Development Commands

```bash
# Install in development mode
pip install -e ".[dev]"

# Run all tests
pytest

# Run tests with coverage
pytest --cov=planecompose --cov-report=html

# Run single test file
pytest tests/test_models.py

# Run specific test
pytest tests/test_models.py::test_work_item_basic

# Linting
ruff check src/

# Auto-fix lint issues
ruff check --fix src/

# Type checking
mypy src/planecompose/

# Format code
black src/ tests/
```

## Architecture

The codebase follows a layered architecture with clear separation of concerns:

```
src/planecompose/
├── cli/              # Presentation layer - Typer commands (thin orchestration)
│   ├── root.py       # Entry point, command registration
│   ├── push.py       # Push command (uses sync module)
│   ├── pull.py       # Pull command
│   ├── state_cmd.py  # State inspection/management commands
│   └── ...           # Other commands
├── backend/          # Data access layer - API abstraction
│   ├── base.py       # Abstract Backend interface
│   ├── client.py     # PlaneApiClient - rate limiting, error translation
│   ├── cache.py      # SchemaCache - O(1) lookups for types/states/labels
│   └── plane.py      # PlaneBackend - main implementation
├── sync/             # Business logic - sync orchestration
│   ├── planner.py    # SyncPlanner - change detection, plan generation
│   └── executor.py   # SyncExecutor - parallel batch execution
├── state/            # State management with file locking
│   └── manager.py    # StateManager - thread-safe state operations
├── core/             # Domain models (Pydantic)
│   └── models.py     # WorkItem, SyncState, etc.
├── parser/           # YAML parsing
├── config/           # Settings via pydantic-settings
├── utils/            # Shared utilities
│   ├── errors.py     # User-friendly error display
│   ├── rate_limit.py # Token bucket rate limiter
│   └── ...
├── diff/             # Reserved for advanced diff features
├── validation/       # Reserved for advanced validation
└── exceptions.py     # Custom exception hierarchy
```

### Key Design Patterns

- **Backend Abstraction**: `backend/base.py` defines abstract interface; `backend/plane.py` implements it
- **Centralized Error Handling**: `backend/client.py` translates all SDK errors to typed exceptions
- **O(1) Schema Lookups**: `backend/cache.py` pre-builds lookup maps for types/states/labels
- **Parallel Batch Processing**: `sync/executor.py` uses asyncio.gather for 5x faster syncs
- **File Locking**: `state/manager.py` prevents concurrent state corruption
- **State Management**: Terraform-style `.plane/state.json` tracks remote IDs and content hashes

### Module Responsibilities

| Module | Responsibility |
|--------|----------------|
| `cli/*` | User interaction, argument parsing, display (NO business logic) |
| `backend/client.py` | Rate limiting, error translation (SINGLE place for SDK errors) |
| `backend/cache.py` | Schema caching with O(1) lookups |
| `backend/plane.py` | High-level API operations |
| `sync/planner.py` | Determine what needs to create/update/delete |
| `sync/executor.py` | Execute sync plan with parallel batches |
| `state/manager.py` | Load/save state with file locking |

### Entry Points

- CLI entry: `src/planecompose/main.py` → `plane` command
- Commands registered in `cli/root.py`
- New commands: create in `cli/`, register via `app.add_typer()` or `app.command()`

### Exception Hierarchy

```
PlaneComposeError (base)
├── APIError (with status_code)
│   ├── RateLimitError (429)
│   ├── AuthenticationError (401)
│   ├── PermissionError (403)
│   └── NotFoundError (404)
├── ConfigError
├── ValidationError (with field)
├── StateError
├── NetworkError (with original_error)
└── ParserError (with file_path, line)
```

## Configuration

Config directory: `~/.config/plane-compose/` (migrates from `~/.config/plane-cli/` if exists)

Environment variables (prefix `PLANE_`):
- `PLANE_API_URL` - API endpoint (defaults to `https://api.plane.so`)
- `PLANE_RATE_LIMIT_PER_MINUTE` - Rate limit (default 50)
- `PLANE_DEBUG`, `PLANE_VERBOSE`, `PLANE_LOG_TO_FILE`

Project config in `plane.yaml`, schema in `schema/`, work items in `work/`.

## Adding New Features

### Adding a New CLI Command

1. Create file in `cli/` (e.g., `cli/mycommand.py`)
2. Register in `cli/root.py` under `_register_commands()`
3. Keep CLI thin - delegate to sync/backend modules

### Adding API Operations

1. All API calls go through `backend/client.py` (PlaneApiClient.call())
2. Errors are automatically translated to typed exceptions
3. Rate limiting is automatic

### Working with State

```python
from planecompose.state.manager import StateManager

manager = StateManager(project_root)

# Read (no lock needed)
state = manager.load()

# Write (auto-locks)
with manager.lock():
    state = manager.load()
    state.work_items["key"] = new_state
    manager.save(state)
```

