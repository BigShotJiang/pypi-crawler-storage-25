"""Tests for work item validation against schema cache."""
import pytest

from planecompose.backend.cache import SchemaCache
from planecompose.core.models import (
    FieldDefinition,
    FieldType,
    WorkItem,
    WorkItemTypeDefinition,
    StateDefinition,
    LabelDefinition,
)
from planecompose.validation.work_items import validate_work_items


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def make_loaded_cache():
    """Create a loaded schema cache for testing."""
    cache = SchemaCache()

    async def fetch_types():
        return [
            WorkItemTypeDefinition(name="Task", workflow="default", remote_id="t-1"),
            WorkItemTypeDefinition(name="Bug", workflow="default", remote_id="t-2"),
        ]

    async def fetch_states():
        return [
            StateDefinition(name="backlog", group="unstarted", remote_id="s-1"),
            StateDefinition(name="in_progress", group="started", remote_id="s-2"),
            StateDefinition(name="done", group="completed", remote_id="s-3"),
        ]

    async def fetch_labels():
        return [
            LabelDefinition(name="frontend", color="#3b82f6", remote_id="l-1"),
            LabelDefinition(name="backend", color="#22c55e", remote_id="l-2"),
        ]

    await cache.load(fetch_types, fetch_states, fetch_labels)
    return cache


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestValidateWorkItems:
    """Test validate_work_items function."""

    @pytest.mark.asyncio
    async def test_valid_items_pass(self):
        cache = await make_loaded_cache()
        items = [
            WorkItem(title="Valid task", type="Task", state="backlog", labels=["frontend"]),
            WorkItem(title="Valid bug", type="Bug", state="in_progress"),
        ]
        result = validate_work_items(items, cache)
        assert result.is_valid
        assert result.error_count == 0

    @pytest.mark.asyncio
    async def test_invalid_type_detected(self):
        cache = await make_loaded_cache()
        items = [WorkItem(title="Bad type", type="NonExistent")]
        result = validate_work_items(items, cache)
        assert not result.is_valid
        assert result.error_count == 1
        errors = [i for i in result.issues if i.severity == "error"]
        assert "Unknown type" in errors[0].message

    @pytest.mark.asyncio
    async def test_invalid_state_detected(self):
        cache = await make_loaded_cache()
        items = [WorkItem(title="Bad state", type="Task", state="nonexistent")]
        result = validate_work_items(items, cache)
        assert not result.is_valid
        errors = [i for i in result.issues if i.severity == "error"]
        assert "Unknown state" in errors[0].message

    @pytest.mark.asyncio
    async def test_invalid_label_detected(self):
        cache = await make_loaded_cache()
        items = [WorkItem(title="Bad label", type="Task", labels=["nonexistent"])]
        result = validate_work_items(items, cache)
        assert not result.is_valid
        errors = [i for i in result.issues if i.severity == "error"]
        assert "Unknown label" in errors[0].message

    @pytest.mark.asyncio
    async def test_multiple_errors(self):
        cache = await make_loaded_cache()
        items = [
            WorkItem(title="Multi-error", type="BadType", state="badstate", labels=["badlabel"]),
        ]
        result = validate_work_items(items, cache)
        assert result.error_count == 3

    @pytest.mark.asyncio
    async def test_empty_items_pass(self):
        cache = await make_loaded_cache()
        result = validate_work_items([], cache)
        assert result.is_valid
        assert result.error_count == 0

    @pytest.mark.asyncio
    async def test_unloaded_cache_gives_warning(self):
        cache = SchemaCache()  # Not loaded
        items = [WorkItem(title="Test", type="Task")]
        result = validate_work_items(items, cache)
        assert result.is_valid  # Warnings don't count as errors
        assert result.warning_count >= 1
        assert "not loaded" in result.issues[0].message

    @pytest.mark.asyncio
    async def test_valid_date_format(self):
        cache = await make_loaded_cache()
        items = [
            WorkItem(
                title="With dates",
                type="Task",
                start_date="2024-01-15",
                due_date="2024-02-28",
            ),
        ]
        result = validate_work_items(items, cache)
        assert result.is_valid

    @pytest.mark.asyncio
    async def test_invalid_date_format(self):
        """Invalid date formats are now caught at model creation via Pydantic validators."""
        import pydantic
        with pytest.raises(pydantic.ValidationError, match="YYYY-MM-DD"):
            WorkItem(
                title="Bad dates",
                type="Task",
                start_date="01/15/2024",
                due_date="2024-2-28",
            )

    @pytest.mark.asyncio
    async def test_children_validated_too(self):
        cache = await make_loaded_cache()
        parent = WorkItem(
            title="Parent",
            type="Task",
            children=[
                WorkItem(title="Child with bad type", type="NonExistent"),
            ],
        )
        result = validate_work_items([parent], cache)
        assert result.error_count == 2
        errors = [i for i in result.issues if i.severity == "error"]
        assert any("Unknown type" in error.message for error in errors)
        assert any("children" == error.field for error in errors)

    @pytest.mark.asyncio
    async def test_watchers_are_rejected(self):
        cache = await make_loaded_cache()
        items = [WorkItem(title="Has watchers", type="Task", watchers=["pm@example.com"])]
        result = validate_work_items(items, cache)
        errors = [issue for issue in result.issues if issue.severity == "error"]
        assert len(errors) == 1
        assert errors[0].field == "watchers"

    @pytest.mark.asyncio
    async def test_unknown_property_detected(self):
        cache = await make_loaded_cache()
        task_type = next(type_def for type_def in cache.types if type_def.name == "Task")
        task_type.fields = []

        items = [WorkItem(title="Bad property", type="Task", properties={"severity": "high"})]
        result = validate_work_items(items, cache)
        errors = [issue for issue in result.issues if issue.severity == "error"]
        assert len(errors) == 1
        assert "Unknown property" in errors[0].message

    @pytest.mark.asyncio
    async def test_unknown_property_option_detected(self):
        cache = await make_loaded_cache()
        task_type = next(type_def for type_def in cache.types if type_def.name == "Task")
        task_type.fields = [
            FieldDefinition(
                name="severity",
                type=FieldType.OPTION,
                options=["low", "high"],
            )
        ]

        items = [WorkItem(title="Bad option", type="Task", properties={"severity": "critical"})]
        result = validate_work_items(items, cache)
        errors = [issue for issue in result.issues if issue.severity == "error"]
        assert len(errors) == 1
        assert "Unknown option" in errors[0].message

    @pytest.mark.asyncio
    async def test_no_state_is_valid(self):
        """Items with no state should pass (state is optional)."""
        cache = await make_loaded_cache()
        items = [WorkItem(title="No state", type="Task")]
        result = validate_work_items(items, cache)
        assert result.is_valid

    @pytest.mark.asyncio
    async def test_case_insensitive_type_lookup(self):
        """Type lookup is case-insensitive via SchemaCache."""
        cache = await make_loaded_cache()
        items = [WorkItem(title="Case test", type="task")]  # lowercase
        result = validate_work_items(items, cache)
        assert result.is_valid

    @pytest.mark.asyncio
    async def test_case_insensitive_state_lookup(self):
        """State lookup is now case-insensitive."""
        cache = await make_loaded_cache()
        items = [WorkItem(title="State case", type="Task", state="Backlog")]
        result = validate_work_items(items, cache)
        assert result.is_valid

    @pytest.mark.asyncio
    async def test_case_insensitive_label_lookup(self):
        """Label lookup is now case-insensitive."""
        cache = await make_loaded_cache()
        items = [WorkItem(title="Label case", type="Task", labels=["Frontend"])]
        result = validate_work_items(items, cache)
        assert result.is_valid

    @pytest.mark.asyncio
    async def test_invalid_priority(self):
        """Invalid priority values are detected."""
        cache = await make_loaded_cache()
        items = [WorkItem(title="Bad priority", type="Task", priority="critical")]
        result = validate_work_items(items, cache)
        errors = [i for i in result.issues if i.severity == "error"]
        assert len(errors) == 1
        assert "Invalid priority" in errors[0].message

    @pytest.mark.asyncio
    async def test_valid_priorities(self):
        """All valid priority values pass."""
        cache = await make_loaded_cache()
        for priority in ["urgent", "high", "medium", "low", "none"]:
            items = [WorkItem(id=f"p-{priority}", title=f"P {priority}", type="Task", priority=priority)]
            result = validate_work_items(items, cache)
            assert result.error_count == 0, f"Priority '{priority}' should be valid"

    @pytest.mark.asyncio
    async def test_duplicate_ids_detected(self):
        """Duplicate user-provided IDs are flagged."""
        cache = await make_loaded_cache()
        items = [
            WorkItem(id="DUPE-1", title="First", type="Task"),
            WorkItem(id="DUPE-1", title="Second", type="Task"),
        ]
        result = validate_work_items(items, cache)
        errors = [i for i in result.issues if i.severity == "error"]
        assert len(errors) == 1
        assert "Duplicate ID" in errors[0].message

    @pytest.mark.asyncio
    async def test_missing_id_warning(self):
        """Items without an ID get a warning about hash-key drift."""
        cache = await make_loaded_cache()
        items = [WorkItem(title="No id item", type="Task")]
        result = validate_work_items(items, cache)
        warnings = [i for i in result.issues if i.severity == "warning"]
        assert any("No 'id'" in w.message for w in warnings)

    @pytest.mark.asyncio
    async def test_validate_without_cache(self):
        """Validation without cache still checks non-schema fields."""
        items = [
            WorkItem(id="ok", title="Good", type="Task", priority="invalid_prio"),
        ]
        result = validate_work_items(items, cache=None)
        errors = [i for i in result.issues if i.severity == "error"]
        assert len(errors) == 1
        assert "Invalid priority" in errors[0].message

    @pytest.mark.asyncio
    async def test_date_range_validation(self):
        """Due date before start date is an error."""
        cache = await make_loaded_cache()
        items = [WorkItem(
            id="dates", title="Bad range", type="Task",
            start_date="2024-06-01", due_date="2024-01-01",
        )]
        result = validate_work_items(items, cache)
        errors = [i for i in result.issues if i.severity == "error"]
        assert any("before start date" in e.message for e in errors)

    @pytest.mark.asyncio
    async def test_valid_date_range_passes(self):
        """Valid date range (start before due) passes."""
        cache = await make_loaded_cache()
        items = [WorkItem(
            id="dates-ok", title="Good range", type="Task",
            start_date="2024-01-01", due_date="2024-06-01",
        )]
        result = validate_work_items(items, cache)
        assert result.error_count == 0

    @pytest.mark.asyncio
    async def test_invalid_assignee_format_warning(self):
        """Non-UUID non-email assignees get a warning."""
        cache = await make_loaded_cache()
        items = [WorkItem(
            id="assign", title="Bad assignee", type="Task",
            assignees=["not-a-uuid-or-email"],
        )]
        result = validate_work_items(items, cache)
        warnings = [i for i in result.issues if i.severity == "warning"]
        assert any("Invalid assignee" in w.message for w in warnings)

    @pytest.mark.asyncio
    async def test_valid_assignee_formats(self):
        """UUID and email assignees pass validation."""
        cache = await make_loaded_cache()
        items = [WorkItem(
            id="assign-ok", title="Good assignee", type="Task",
            assignees=[
                "550e8400-e29b-41d4-a716-446655440000",
                "user@example.com",
            ],
        )]
        result = validate_work_items(items, cache)
        warnings = [i for i in result.issues if i.severity == "warning" and "assignee" in i.field]
        assert len(warnings) == 0

    @pytest.mark.asyncio
    async def test_self_parenthood_detected(self):
        """Item referencing itself as parent is an error."""
        cache = await make_loaded_cache()
        items = [WorkItem(id="SELF-1", title="Self parent", type="Task", parent="SELF-1")]
        result = validate_work_items(items, cache)
        errors = [i for i in result.issues if i.severity == "error" and i.field == "parent"]
        assert len(errors) == 1
        assert "itself" in errors[0].message

    @pytest.mark.asyncio
    async def test_circular_parent_detected(self):
        """Circular parent chain (A->B->A) is an error."""
        cache = await make_loaded_cache()
        items = [
            WorkItem(id="A", title="Item A", type="Task", parent="B"),
            WorkItem(id="B", title="Item B", type="Task", parent="A"),
        ]
        result = validate_work_items(items, cache)
        errors = [i for i in result.issues if i.severity == "error" and i.field == "parent"]
        assert len(errors) >= 1
        assert any("Circular" in e.message for e in errors)

    @pytest.mark.asyncio
    async def test_valid_parent_passes(self):
        """Non-circular parent references pass."""
        cache = await make_loaded_cache()
        items = [
            WorkItem(id="PARENT-1", title="Parent", type="Task"),
            WorkItem(id="CHILD-1", title="Child", type="Task", parent="PARENT-1"),
        ]
        result = validate_work_items(items, cache)
        errors = [i for i in result.issues if i.severity == "error" and i.field == "parent"]
        assert len(errors) == 0
