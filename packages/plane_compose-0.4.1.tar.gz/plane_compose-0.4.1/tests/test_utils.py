"""Tests for utility modules."""
import pytest
from datetime import datetime

from planecompose.cli.helpers import find_schema_changes
from planecompose.core.models import (
    FieldDefinition,
    FieldType,
    LabelDefinition,
    StateDefinition,
    WorkItem,
    WorkItemTypeDefinition,
)
from planecompose.utils.work_items import (
    generate_id_from_title,
    calculate_content_hash,
    get_tracking_key,
    make_work_item_state,
    parse_source,
    CONTENT_HASH_VERSION,
)
from planecompose.utils.rate_limit import RateLimiter


class TestWorkItemUtils:
    """Tests for work item utilities."""
    
    def test_generate_id_from_title_basic(self):
        """Test basic ID generation from title."""
        title = "Implement user authentication"
        id_ = generate_id_from_title(title)
        
        assert id_ == "implement-user-authentication"
        assert " " not in id_
        assert id_.islower()
    
    def test_generate_id_from_title_special_chars(self):
        """Test ID generation removes special characters."""
        title = "Fix bug #123 - CSS issue!"
        id_ = generate_id_from_title(title)
        
        assert "#" not in id_
        assert "!" not in id_
        assert "-" in id_
    
    def test_generate_id_from_title_long(self):
        """Test ID generation truncates long titles."""
        title = "This is a very long title that should be truncated because it exceeds the maximum length"
        id_ = generate_id_from_title(title)
        
        assert len(id_) <= 50
    
    def test_generate_id_from_title_empty(self):
        """Test ID generation with empty/weird title."""
        assert generate_id_from_title("") == "item"
        assert generate_id_from_title("!!!") == "item"
    
    def test_calculate_content_hash_deterministic(self, sample_work_item):
        """Test that content hash is deterministic."""
        hash1 = calculate_content_hash(sample_work_item)
        hash2 = calculate_content_hash(sample_work_item)
        
        assert hash1 == hash2
        assert len(hash1) == 16  # SHA256 truncated to 16 chars
    
    def test_calculate_content_hash_changes_with_content(self):
        """Test that hash changes when content changes."""
        item1 = WorkItem(title="Task A", type="task")
        item2 = WorkItem(title="Task B", type="task")
        
        hash1 = calculate_content_hash(item1)
        hash2 = calculate_content_hash(item2)
        
        assert hash1 != hash2
    
    def test_get_tracking_key_with_id(self, sample_work_item):
        """Test tracking key uses user-provided ID with namespace prefix."""
        key = get_tracking_key(sample_work_item, "work/inbox.yaml", 0)

        assert key == "id:test-item-001"
    
    def test_get_tracking_key_without_id(self):
        """Test tracking key uses content hash when no ID."""
        item = WorkItem(title="Task without ID", type="task")
        key = get_tracking_key(item, "work/inbox.yaml", 0)
        
        assert key.startswith("hash:")
        assert len(key) > 5
    
    def test_make_work_item_state(self, sample_work_item):
        """Test creating work item state."""
        state = make_work_item_state(
            remote_id="remote-123",
            item=sample_work_item,
            source="work/inbox.yaml",
            index=0,
        )

        assert state.remote_id == "remote-123"
        assert state.source == "work/inbox.yaml:0"
        assert state.content_hash is not None
        assert "Z" in state.last_synced  # ISO format with Z
        assert state.hash_version == CONTENT_HASH_VERSION

    def test_content_hash_includes_version(self):
        """Content hash changes when CONTENT_HASH_VERSION changes."""
        item = WorkItem(title="Test", type="task")
        hash_val = calculate_content_hash(item)
        # The hash includes the version prefix, so it is deterministic
        # but would change if CONTENT_HASH_VERSION is bumped.
        assert isinstance(hash_val, str)
        assert len(hash_val) == 16

    def test_parse_source_normal(self):
        """Parse standard source string."""
        path, index = parse_source("work/inbox.yaml:3")
        assert path == "work/inbox.yaml"
        assert index == 3

    def test_parse_source_no_index(self):
        """Parse source without index falls back safely."""
        path, index = parse_source("work/inbox.yaml")
        assert path == "work/inbox.yaml"
        assert index == 0

    def test_parse_source_windows_path(self):
        """Parse source with Windows drive letter doesn't break."""
        path, index = parse_source("C:\\Users\\dev\\work\\inbox.yaml:5")
        assert path == "C:\\Users\\dev\\work\\inbox.yaml"
        assert index == 5

    def test_parse_source_colon_in_path(self):
        """Parse source with colons in path (not followed by digits)."""
        path, index = parse_source("remote:snapshot")
        assert path == "remote:snapshot"
        assert index == 0


class TestRateLimiter:
    """Tests for rate limiter."""
    
    def test_rate_limiter_init(self):
        """Test rate limiter initialization."""
        limiter = RateLimiter(requests_per_minute=60)
        
        assert limiter.requests_per_minute == 60
        assert limiter.total_requests == 0
    
    def test_rate_limiter_stats_initial(self):
        """Test initial stats are zero."""
        limiter = RateLimiter()
        stats = limiter.get_stats()
        
        assert stats['total_requests'] == 0
        assert stats['requests_last_minute'] == 0
    
    def test_rate_limiter_reset(self):
        """Test reset clears counters."""
        limiter = RateLimiter()
        limiter.total_requests = 100
        limiter.total_wait_time = 10.0
        
        limiter.reset()
        
        assert limiter.total_requests == 0
        assert limiter.total_wait_time == 0.0
    
    @pytest.mark.asyncio
    async def test_rate_limiter_acquire(self):
        """Test acquiring a slot."""
        limiter = RateLimiter(requests_per_minute=60)

        await limiter.acquire()

        assert limiter.total_requests == 1
        assert len(limiter.request_times) == 1

    @pytest.mark.asyncio
    async def test_rate_limiter_concurrent_safety(self):
        """Concurrent acquire() calls don't exceed the limit."""
        import asyncio
        limiter = RateLimiter(requests_per_minute=1000)

        # Fire 10 concurrent acquires
        await asyncio.gather(*[limiter.acquire() for _ in range(10)])

        assert limiter.total_requests == 10
        assert len(limiter.request_times) == 10


class TestSchemaDiffHelpers:
    """Tests for schema diff helper signatures."""

    def test_find_schema_changes_ignores_equal_types(self):
        local = [
            WorkItemTypeDefinition(
                name="Task",
                workflow="default",
                description="Same",
                fields=[
                    FieldDefinition(
                        name="severity",
                        type=FieldType.OPTION,
                        options=["low", "high"],
                    ),
                ],
            )
        ]
        remote = [
            WorkItemTypeDefinition(
                name="Task",
                workflow="default",
                description="Same",
                fields=[
                    FieldDefinition(
                        name="severity",
                        type=FieldType.OPTION,
                        options=["low", "high"],
                    ),
                ],
                remote_id="type-1",
            )
        ]

        to_create, to_update, to_delete = find_schema_changes(local, remote)

        assert to_create == []
        assert to_update == []
        assert to_delete == []

    def test_find_schema_changes_detects_state_changes(self):
        local = [StateDefinition(name="Backlog", color="#111111", group="unstarted")]
        remote = [StateDefinition(name="Backlog", color="#222222", group="unstarted", remote_id="state-1")]

        to_create, to_update, to_delete = find_schema_changes(local, remote)

        assert to_create == []
        assert [state.name for state in to_update] == ["Backlog"]
        assert to_delete == []

    def test_find_schema_changes_detects_label_deletes(self):
        local = [LabelDefinition(name="frontend", color="#111111")]
        remote = [
            LabelDefinition(name="frontend", color="#111111", remote_id="label-1"),
            LabelDefinition(name="backend", color="#222222", remote_id="label-2"),
        ]

        to_create, to_update, to_delete = find_schema_changes(local, remote)

        assert to_create == []
        assert to_update == []
        assert [label.name for label in to_delete] == ["backend"]


class TestExceptions:
    """Tests for custom exceptions."""
    
    def test_api_error(self):
        """Test APIError creation."""
        from planecompose.exceptions import APIError
        
        error = APIError(message="Test error", status_code=500)
        
        assert error.status_code == 500
        assert error.message == "Test error"
        assert error.is_server_error()
        assert not error.is_client_error()
    
    def test_rate_limit_error(self):
        """Test RateLimitError creation."""
        from planecompose.exceptions import RateLimitError
        
        error = RateLimitError(retry_after=60)
        
        assert error.status_code == 429
        assert error.retry_after == 60
        assert error.is_rate_limit_error()
    
    def test_authentication_error(self):
        """Test AuthenticationError creation."""
        from planecompose.exceptions import AuthenticationError
        
        error = AuthenticationError()
        
        assert error.status_code == 401
        assert "authentication" in error.message.lower() or "api key" in error.message.lower()
    
    def test_not_found_error(self):
        """Test NotFoundError creation."""
        from planecompose.exceptions import NotFoundError

        error = NotFoundError(resource="Project")

        assert error.status_code == 404
        assert "Project" in error.message

    def test_sync_conflict_error(self):
        """Test SyncConflictError creation."""
        from planecompose.exceptions import SyncConflictError

        error = SyncConflictError(
            message="2 conflicts detected",
            conflicts=[("id:PROJ-1", "My Task"), ("id:PROJ-2", "Other Task")],
        )

        assert isinstance(error, SyncConflictError)
        assert len(error.conflicts) == 2
        assert "2 conflicts" in error.message

    def test_timeout_error(self):
        """Test TimeoutError creation."""
        from planecompose.exceptions import TimeoutError as PlaneTimeoutError, NetworkError

        error = PlaneTimeoutError(message="Request timed out after 30s")

        assert isinstance(error, PlaneTimeoutError)
        assert isinstance(error, NetworkError)  # inherits from NetworkError
        assert "timed out" in error.message

    def test_file_system_error(self):
        """Test FileSystemError creation."""
        from planecompose.exceptions import FileSystemError

        error = FileSystemError(message="Permission denied", path="/tmp/state.json")

        assert error.path == "/tmp/state.json"
        assert "Permission denied" in error.message

    def test_config_error_accepts_details(self):
        """Test ConfigError accepts details parameter."""
        from planecompose.exceptions import ConfigError

        error = ConfigError(message="Bad config", details={"field": "workspace"})

        assert error.details == {"field": "workspace"}

    def test_state_error_accepts_details(self):
        """Test StateError accepts details parameter."""
        from planecompose.exceptions import StateError

        error = StateError(message="Corrupt state", details={"version": 2})

        assert error.details == {"version": 2}


class TestContentHashEdgeCases:
    """Tests for content hash stability with edge cases."""

    def test_hash_with_empty_lists(self):
        """Hash is stable with empty labels, assignees, etc."""
        item = WorkItem(title="Test", type="task")
        hash1 = calculate_content_hash(item)
        hash2 = calculate_content_hash(item)
        assert hash1 == hash2

    def test_hash_with_empty_properties(self):
        """Hash is stable with empty properties dict."""
        item1 = WorkItem(title="Test", type="task", properties={})
        item2 = WorkItem(title="Test", type="task")
        assert calculate_content_hash(item1) == calculate_content_hash(item2)

    def test_hash_changes_with_labels(self):
        """Hash changes when labels differ."""
        item1 = WorkItem(title="Test", type="task", labels=["bug"])
        item2 = WorkItem(title="Test", type="task", labels=["feature"])
        assert calculate_content_hash(item1) != calculate_content_hash(item2)

    def test_hash_stable_regardless_of_label_order(self):
        """Hash is the same regardless of label order (sorted internally)."""
        item1 = WorkItem(title="Test", type="task", labels=["a", "b", "c"])
        item2 = WorkItem(title="Test", type="task", labels=["c", "a", "b"])
        assert calculate_content_hash(item1) == calculate_content_hash(item2)


class TestErrorDisplay:
    """Tests for error display functions."""

    def test_handle_api_error_auth(self, capsys):
        """handle_api_error shows auth help for AuthenticationError."""
        from planecompose.exceptions import AuthenticationError
        from planecompose.utils.errors import handle_api_error

        error = AuthenticationError()
        handle_api_error(error, "push")
        # Should not raise — just prints to console

    def test_handle_api_error_generic(self, capsys):
        """handle_api_error handles unknown exceptions gracefully."""
        from planecompose.utils.errors import handle_api_error

        error = RuntimeError("something went wrong")
        handle_api_error(error, "push")
        # Should not raise

    def test_handle_api_error_network(self, capsys):
        """handle_api_error handles NetworkError."""
        from planecompose.exceptions import NetworkError
        from planecompose.utils.errors import handle_api_error

        error = NetworkError("Connection refused")
        handle_api_error(error, "connect")
        # Should not raise

    def test_handle_api_error_timeout(self, capsys):
        """handle_api_error shows timeout-specific help."""
        from planecompose.exceptions import TimeoutError as PlaneTimeoutError
        from planecompose.utils.errors import handle_api_error

        error = PlaneTimeoutError("Request timed out after 30s")
        handle_api_error(error, "fetch")
        # Should not raise

    def test_handle_api_error_sync_conflict(self, capsys):
        """handle_api_error shows conflict-specific help."""
        from planecompose.exceptions import SyncConflictError
        from planecompose.utils.errors import handle_api_error

        error = SyncConflictError("2 conflicts", conflicts=[("id:X", "Title")])
        handle_api_error(error, "push")
        # Should not raise
