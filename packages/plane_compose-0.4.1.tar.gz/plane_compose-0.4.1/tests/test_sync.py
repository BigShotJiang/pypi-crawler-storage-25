"""Tests for the sync module (planner, executor, writer)."""
import pytest
import json
import yaml
from pathlib import Path
from datetime import datetime

from planecompose.core.models import (
    WorkItem,
    WorkItemState,
    SyncState,
    WorkItemTypeDefinition,
    StateDefinition,
    LabelDefinition,
)
from planecompose.sync.planner import SyncPlanner, SyncPlan, SyncAction, ConflictItem
from planecompose.sync.executor import SyncExecutor, SyncResult
from planecompose.sync.writer import PullWriter, PullResult
from planecompose.parser.work_yaml import WorkItemWithMeta
from planecompose.utils.work_items import calculate_content_hash, get_tracking_key, CONTENT_HASH_VERSION


# -----------------------------------------------------------------------------
# SyncPlanner Tests
# -----------------------------------------------------------------------------

class TestSyncPlanner:
    """Tests for SyncPlanner."""

    def test_plan_push_new_items(self, sample_work_items):
        """Test planning push with all new items."""
        planner = SyncPlanner()
        state = SyncState()

        # Convert to WorkItemWithMeta
        items_with_meta = [
            WorkItemWithMeta(item=item, source_file=Path("work/inbox.yaml"), index=i)
            for i, item in enumerate(sample_work_items)
        ]

        plan = planner.plan_push(items_with_meta, state)

        assert len(plan.creates) == 3
        assert len(plan.updates) == 0
        assert len(plan.deletes) == 0
        assert len(plan.skipped) == 0
        assert plan.total_changes == 3

    def test_plan_push_with_existing_unchanged(self, sample_work_items):
        """Test planning push with existing unchanged items."""
        planner = SyncPlanner()

        # Create state with existing items (must use current hash_version)
        state = SyncState()
        for i, item in enumerate(sample_work_items):
            # Use the same tracking key logic as SyncPlanner
            tracking_key = get_tracking_key(item, "work/inbox.yaml", i)
            state.work_items[tracking_key] = WorkItemState(
                remote_id=f"remote-{i}",
                content_hash=calculate_content_hash(item),
                source=f"work/inbox.yaml:{i}",
                last_synced=datetime.now().isoformat(),
                hash_version=CONTENT_HASH_VERSION,
            )

        items_with_meta = [
            WorkItemWithMeta(item=item, source_file=Path("work/inbox.yaml"), index=i)
            for i, item in enumerate(sample_work_items)
        ]

        plan = planner.plan_push(items_with_meta, state)

        assert len(plan.creates) == 0
        assert len(plan.updates) == 0
        assert len(plan.skipped) == 3
        assert plan.is_empty

    def test_plan_push_with_changed_items(self, sample_work_items):
        """Test planning push with changed items."""
        planner = SyncPlanner()

        # Create state with old content hash
        state = SyncState()
        for i, item in enumerate(sample_work_items):
            # Use the same tracking key logic as SyncPlanner
            tracking_key = get_tracking_key(item, "work/inbox.yaml", i)
            state.work_items[tracking_key] = WorkItemState(
                remote_id=f"remote-{i}",
                content_hash="old-hash-that-doesnt-match",
                source=f"work/inbox.yaml:{i}",
                last_synced=datetime.now().isoformat(),
            )

        items_with_meta = [
            WorkItemWithMeta(item=item, source_file=Path("work/inbox.yaml"), index=i)
            for i, item in enumerate(sample_work_items)
        ]

        plan = planner.plan_push(items_with_meta, state)

        assert len(plan.creates) == 0
        assert len(plan.updates) == 3
        assert len(plan.skipped) == 0
        assert plan.total_changes == 3

    def test_plan_push_mixed(self, sample_work_items):
        """Test planning push with mix of new, changed, and unchanged items."""
        planner = SyncPlanner()

        # Create state: item 0 unchanged, item 1 changed, item 2 new
        state = SyncState()

        # Item 0: unchanged (must match current hash_version)
        item0 = sample_work_items[0]
        key0 = get_tracking_key(item0, "work/inbox.yaml", 0)
        state.work_items[key0] = WorkItemState(
            remote_id="remote-0",
            content_hash=calculate_content_hash(item0),
            source="work/inbox.yaml:0",
            last_synced=datetime.now().isoformat(),
            hash_version=CONTENT_HASH_VERSION,
        )

        # Item 1: changed (old hash)
        item1 = sample_work_items[1]
        key1 = get_tracking_key(item1, "work/inbox.yaml", 1)
        state.work_items[key1] = WorkItemState(
            remote_id="remote-1",
            content_hash="old-hash",
            source="work/inbox.yaml:1",
            last_synced=datetime.now().isoformat(),
        )

        # Item 2: not in state (new)

        items_with_meta = [
            WorkItemWithMeta(item=item, source_file=Path("work/inbox.yaml"), index=i)
            for i, item in enumerate(sample_work_items)
        ]

        plan = planner.plan_push(items_with_meta, state)

        assert len(plan.creates) == 1  # Item 2
        assert len(plan.updates) == 1  # Item 1
        assert len(plan.skipped) == 1  # Item 0
        assert plan.total_changes == 2

    def test_plan_apply_with_deletes(self, sample_work_items):
        """Test planning apply mode includes deletes."""
        planner = SyncPlanner()

        # Create state with extra item that's not in local
        state = SyncState()
        state.work_items["orphan-item"] = WorkItemState(
            remote_id="remote-orphan",
            content_hash="some-hash",
            source="work/inbox.yaml:99",
            last_synced=datetime.now().isoformat(),
        )

        items_with_meta = [
            WorkItemWithMeta(item=item, source_file=Path("work/inbox.yaml"), index=i)
            for i, item in enumerate(sample_work_items)
        ]

        plan = planner.plan_apply(items_with_meta, state)

        assert len(plan.creates) == 3
        assert len(plan.deletes) == 1
        assert plan.deletes[0].tracking_key == "orphan-item"

    def test_plan_apply_ignores_remote_snapshot_entries(self):
        """Read-only `.plane/remote` items must not be treated as declarative deletes."""
        planner = SyncPlanner()
        state = SyncState()
        state.work_items["id:TEST-1"] = WorkItemState(
            remote_id="remote-1",
            content_hash="some-hash",
            source=".plane/remote/items.yaml:0",
            last_synced=datetime.now().isoformat(),
        )

        plan = planner.plan_apply([], state)

        assert len(plan.creates) == 0
        assert len(plan.deletes) == 0

    def test_plan_push_stale_hash_version_triggers_update(self, sample_work_items):
        """Items with old hash_version are always treated as 'changed'."""
        planner = SyncPlanner()

        state = SyncState()
        item = sample_work_items[0]
        tracking_key = get_tracking_key(item, "work/inbox.yaml", 0)
        state.work_items[tracking_key] = WorkItemState(
            remote_id="remote-0",
            content_hash=calculate_content_hash(item),
            source="work/inbox.yaml:0",
            last_synced=datetime.now().isoformat(),
            hash_version=1,  # Older than current CONTENT_HASH_VERSION
        )

        items_with_meta = [
            WorkItemWithMeta(item=item, source_file=Path("work/inbox.yaml"), index=0)
        ]

        plan = planner.plan_push(items_with_meta, state)

        # Even though the hash matches, old hash_version triggers update
        assert len(plan.updates) == 1
        assert plan.updates[0].reason == "hash version upgraded"

    def test_plan_summary(self, sample_work_items):
        """Test plan summary generation."""
        planner = SyncPlanner()
        state = SyncState()

        items_with_meta = [
            WorkItemWithMeta(item=item, source_file=Path("work/inbox.yaml"), index=i)
            for i, item in enumerate(sample_work_items)
        ]

        plan = planner.plan_push(items_with_meta, state)
        summary = plan.summary()

        assert summary['creates'] == 3
        assert summary['updates'] == 0
        assert summary['deletes'] == 0
        assert summary['total_changes'] == 3


# -----------------------------------------------------------------------------
# SyncExecutor Tests
# -----------------------------------------------------------------------------

class TestSyncExecutor:
    """Tests for SyncExecutor."""

    @pytest.mark.asyncio
    async def test_execute_creates(self, mock_backend, sample_work_items):
        """Test executing creates."""
        executor = SyncExecutor(mock_backend, state_manager=None, batch_size=2)

        # Create plan with items to create
        plan = SyncPlan()
        for i, item in enumerate(sample_work_items):
            from planecompose.sync.planner import SyncItem
            plan.creates.append(SyncItem(
                action=SyncAction.CREATE,
                item=item,
                tracking_key=item.id or f"item-{i}",
                source_file="work/inbox.yaml",
                index=i,
                reason="new item",
            ))

        # Connect mock backend
        from planecompose.core.models import ProjectConfig
        config = ProjectConfig(workspace="test", project_key="TEST")
        await mock_backend.connect(config, "test-key")

        result = await executor.execute(plan)

        assert result.created_count == 3
        assert result.updated_count == 0
        assert result.failed_count == 0
        assert len(mock_backend._work_items) == 3

    @pytest.mark.asyncio
    async def test_execute_dry_run(self, mock_backend, sample_work_items):
        """Test dry run doesn't execute."""
        executor = SyncExecutor(mock_backend, state_manager=None)

        plan = SyncPlan()
        for i, item in enumerate(sample_work_items):
            from planecompose.sync.planner import SyncItem
            plan.creates.append(SyncItem(
                action=SyncAction.CREATE,
                item=item,
                tracking_key=item.id or f"item-{i}",
                source_file="work/inbox.yaml",
                index=i,
                reason="new item",
            ))

        result = await executor.execute(plan, dry_run=True)

        assert result.created_count == 0
        assert len(mock_backend._work_items) == 0

    @pytest.mark.asyncio
    async def test_execute_with_progress_callback(self, mock_backend, sample_work_items):
        """Test progress callback is called."""
        executor = SyncExecutor(mock_backend, state_manager=None, batch_size=1)

        plan = SyncPlan()
        for i, item in enumerate(sample_work_items):
            from planecompose.sync.planner import SyncItem
            plan.creates.append(SyncItem(
                action=SyncAction.CREATE,
                item=item,
                tracking_key=item.id or f"item-{i}",
                source_file="work/inbox.yaml",
                index=i,
                reason="new item",
            ))

        # Connect mock backend
        from planecompose.core.models import ProjectConfig
        config = ProjectConfig(workspace="test", project_key="TEST")
        await mock_backend.connect(config, "test-key")

        progress_calls = []

        async def on_progress(current, total, title):
            progress_calls.append((current, total, title))

        result = await executor.execute(plan, progress_callback=on_progress)

        assert len(progress_calls) == 3
        assert progress_calls[-1][0] == 3  # Final progress is 3

    @pytest.mark.asyncio
    async def test_execute_deletes(self, mock_backend, sample_work_items):
        """Test executing deletes actually removes items."""
        from planecompose.sync.planner import SyncItem
        from planecompose.core.models import ProjectConfig

        config = ProjectConfig(workspace="test", project_key="TEST")
        await mock_backend.connect(config, "test-key")

        # Pre-populate backend with items
        item_ids = []
        for item in sample_work_items:
            item_id = await mock_backend.create_work_item(item)
            item_ids.append(item_id)

        assert len(mock_backend._work_items) == 3

        executor = SyncExecutor(mock_backend, state_manager=None)

        # Create plan with one delete
        plan = SyncPlan()
        plan.deletes.append(SyncItem(
            action=SyncAction.DELETE,
            item=sample_work_items[0],
            tracking_key="id:item-001",
            source_file="work/inbox.yaml",
            index=0,
            remote_id=item_ids[0],
            reason="not in local",
        ))

        result = await executor.execute(plan)

        assert result.deleted_count == 1
        assert result.failed_count == 0
        assert len(mock_backend._work_items) == 2

    def test_result_summary(self):
        """Test SyncResult summary."""
        result = SyncResult()
        from planecompose.sync.planner import SyncItem
        from planecompose.sync.executor import SyncItemResult

        # Add some results
        result.created.append(SyncItemResult(
            item=SyncItem(SyncAction.CREATE, WorkItem(title="Test", type="task"), "key", "file", 0),
            success=True,
            remote_id="remote-1",
        ))
        result.failed.append(SyncItemResult(
            item=SyncItem(SyncAction.CREATE, WorkItem(title="Failed", type="task"), "key2", "file", 1),
            success=False,
            error="API Error",
        ))

        summary = result.summary()
        assert summary['created'] == 1
        assert summary['failed'] == 1
        assert summary['total_processed'] == 2


# -----------------------------------------------------------------------------
# PullWriter Tests
# -----------------------------------------------------------------------------

class TestPullWriter:
    """Tests for PullWriter."""

    def test_write_schema(self, temp_project):
        """Test writing schema files."""
        writer = PullWriter(temp_project)

        types = [
            WorkItemTypeDefinition(name="task", description="A task", workflow="standard"),
            WorkItemTypeDefinition(name="bug", description="A bug", workflow="standard"),
        ]
        states = [
            StateDefinition(name="backlog", group="unstarted", color="#808080"),
            StateDefinition(name="done", group="completed", color="#22c55e"),
        ]
        labels = [
            LabelDefinition(name="frontend", color="#3b82f6"),
            LabelDefinition(name="backend", color="#10b981"),
        ]

        writer.write_schema(types, states, labels)

        # Verify types.yaml (rooted under work_item_types key)
        types_file = temp_project / "schema" / "types.yaml"
        assert types_file.exists()
        types_data = yaml.safe_load(types_file.read_text())
        assert 'work_item_types' in types_data
        assert len(types_data['work_item_types']) == 2
        assert 'task' in types_data['work_item_types']
        assert 'bug' in types_data['work_item_types']

        # Verify labels.yaml (rooted under labels key)
        labels_file = temp_project / "schema" / "labels.yaml"
        assert labels_file.exists()
        labels_data = yaml.safe_load(labels_file.read_text())
        assert 'labels' in labels_data
        assert len(labels_data['labels']) == 2
        assert labels_data['labels'][0]['name'] == 'frontend'

    def test_write_work_items(self, temp_project, sample_work_items):
        """Test writing work items to YAML."""
        writer = PullWriter(temp_project)

        output_path = ".plane/remote/items.yaml"
        count = writer.write_work_items(sample_work_items, output_path)

        assert count == 3

        output_file = temp_project / output_path
        assert output_file.exists()

        items_data = yaml.safe_load(output_file.read_text())
        assert len(items_data) == 3
        assert items_data[0]['title'] == 'First task'
        assert items_data[0]['id'] == 'item-001'

    def test_write_work_items_with_properties(self, temp_project, sample_work_items):
        """Test writing work items with custom properties."""
        writer = PullWriter(temp_project)

        # Mock raw items with IDs
        class MockRawItem:
            def __init__(self, id):
                self.id = id

        raw_items = [MockRawItem(f"uuid-{i}") for i in range(3)]
        properties = {
            "uuid-0": {"Priority": "High", "Team": "Backend"},
            "uuid-1": {"Priority": "Low"},
        }

        output_path = ".plane/remote/items.yaml"
        writer.write_work_items(
            sample_work_items, output_path,
            properties=properties, raw_items=raw_items
        )

        output_file = temp_project / output_path
        items_data = yaml.safe_load(output_file.read_text())

        assert 'properties' in items_data[0]
        assert items_data[0]['properties']['Priority'] == 'High'
        assert 'properties' in items_data[1]
        assert 'properties' not in items_data[2]

    def test_write_work_items_merge(self, temp_project, sample_work_items):
        """Test merging with existing items."""
        writer = PullWriter(temp_project)
        output_path = ".plane/remote/items.yaml"
        output_file = temp_project / output_path

        # Write initial items
        output_file.parent.mkdir(parents=True, exist_ok=True)
        existing = [{'id': 'existing-1', 'title': 'Existing Item', 'type': 'task'}]
        output_file.write_text(yaml.dump(existing))

        # Write with merge
        writer.write_work_items(sample_work_items, output_path, merge_existing=True)

        items_data = yaml.safe_load(output_file.read_text())
        assert len(items_data) == 4  # 1 existing + 3 new
        assert items_data[0]['id'] == 'existing-1'

    def test_work_item_to_dict_minimal(self, temp_project):
        """Test converting minimal work item to dict."""
        writer = PullWriter(temp_project)

        item = WorkItem(title="Minimal", type="task")
        item_dict = writer._work_item_to_dict(item)

        assert item_dict['title'] == 'Minimal'
        assert item_dict['type'] == 'task'
        assert 'id' not in item_dict
        assert 'description' not in item_dict

    def test_work_item_to_dict_full(self, temp_project):
        """Test converting full work item to dict."""
        writer = PullWriter(temp_project)

        item = WorkItem(
            id="PROJ-123",
            title="Full Item",
            description="Description here",
            type="bug",
            state="in_progress",
            priority="high",
            labels=["urgent", "backend"],
            start_date="2024-01-01",
            due_date="2024-01-15",
            assignees=["user-1", "user-2"],
            parent="PROJ-100",
            blocked_by=["PROJ-101"],
        )
        item_dict = writer._work_item_to_dict(item)

        assert item_dict['id'] == 'PROJ-123'
        assert item_dict['title'] == 'Full Item'
        assert item_dict['description'] == 'Description here'
        assert item_dict['type'] == 'bug'
        assert item_dict['state'] == 'in_progress'
        assert item_dict['priority'] == 'high'
        assert item_dict['labels'] == ['urgent', 'backend']
        assert item_dict['start_date'] == '2024-01-01'
        assert item_dict['due_date'] == '2024-01-15'
        assert item_dict['assignees'] == ['user-1', 'user-2']
        assert item_dict['parent'] == 'PROJ-100'
        assert item_dict['blocked_by'] == ['PROJ-101']


# -----------------------------------------------------------------------------
# Integration Tests
# -----------------------------------------------------------------------------

class TestSyncIntegration:
    """Integration tests for sync workflow."""

    @pytest.mark.asyncio
    async def test_full_push_workflow(self, temp_project, mock_backend, sample_work_items):
        """Test complete push workflow: plan -> execute."""
        from planecompose.state.manager import StateManager

        # Setup
        planner = SyncPlanner()
        state_manager = StateManager(temp_project)
        state = state_manager.load()

        # Plan
        items_with_meta = [
            WorkItemWithMeta(item=item, source_file=Path("work/inbox.yaml"), index=i)
            for i, item in enumerate(sample_work_items)
        ]
        plan = planner.plan_push(items_with_meta, state)

        assert plan.total_changes == 3

        # Execute
        from planecompose.core.models import ProjectConfig
        config = ProjectConfig(workspace="test", project_key="TEST")
        await mock_backend.connect(config, "test-key")

        executor = SyncExecutor(mock_backend, state_manager=None, batch_size=2)
        result = await executor.execute(plan)

        assert result.created_count == 3
        assert result.failed_count == 0

        # Verify items in backend
        assert len(mock_backend._work_items) == 3


# -----------------------------------------------------------------------------
# Conflict Detection Tests
# -----------------------------------------------------------------------------

class TestConflictDetection:
    """Tests for SyncPlanner.detect_conflicts()."""

    def _make_plan_with_updates(self, items, state):
        """Helper to create a plan with updates for testing conflicts."""
        from planecompose.sync.planner import SyncItem
        plan = SyncPlan()
        for i, item in enumerate(items):
            tracking_key = get_tracking_key(item, "work/inbox.yaml", i)
            item_state = state.work_items.get(tracking_key)
            if item_state:
                plan.updates.append(SyncItem(
                    action=SyncAction.UPDATE,
                    item=item,
                    tracking_key=tracking_key,
                    source_file="work/inbox.yaml",
                    index=i,
                    remote_id=item_state.remote_id,
                    reason="content changed",
                ))
        return plan

    def test_no_conflicts_when_remote_unchanged(self, sample_work_items):
        """No conflicts when remote matches state."""
        planner = SyncPlanner()

        item = sample_work_items[0]
        tracking_key = get_tracking_key(item, "work/inbox.yaml", 0)
        content_hash = calculate_content_hash(item)

        state = SyncState()
        state.work_items[tracking_key] = WorkItemState(
            remote_id="remote-0",
            content_hash=content_hash,
            source="work/inbox.yaml:0",
            last_synced=datetime.now().isoformat(),
            hash_version=CONTENT_HASH_VERSION,
        )

        # Modify item locally (so it becomes an update)
        modified_item = WorkItem(
            id=item.id,
            title="First task - modified locally",
            type=item.type,
            state=item.state,
        )

        plan = self._make_plan_with_updates([modified_item], state)

        # Remote is same as what we last synced (no one changed it remotely)
        remote_items = {"remote-0": item}

        conflicts = planner.detect_conflicts(plan, state, remote_items)
        assert len(conflicts) == 0

    def test_conflict_when_remote_changed(self, sample_work_items):
        """Conflict detected when remote differs from state hash."""
        planner = SyncPlanner()

        item = sample_work_items[0]
        tracking_key = get_tracking_key(item, "work/inbox.yaml", 0)
        content_hash = calculate_content_hash(item)

        state = SyncState()
        state.work_items[tracking_key] = WorkItemState(
            remote_id="remote-0",
            content_hash=content_hash,
            source="work/inbox.yaml:0",
            last_synced=datetime.now().isoformat(),
            hash_version=CONTENT_HASH_VERSION,
        )

        # Local modification
        modified_item = WorkItem(
            id=item.id,
            title="First task - modified locally",
            type=item.type,
            state=item.state,
        )

        plan = self._make_plan_with_updates([modified_item], state)

        # Remote was changed by someone else (different from state)
        remote_changed = WorkItem(
            id=item.id,
            title="First task - changed in Plane UI",
            type=item.type,
            state=item.state,
        )
        remote_items = {"remote-0": remote_changed}

        conflicts = planner.detect_conflicts(plan, state, remote_items)
        assert len(conflicts) == 1
        assert conflicts[0].tracking_key == tracking_key
        assert conflicts[0].item_title == "First task - modified locally"
        assert conflicts[0].state_hash == content_hash
        assert conflicts[0].remote_hash == calculate_content_hash(remote_changed)
        assert conflicts[0].local_hash == calculate_content_hash(modified_item)

    def test_no_conflict_when_remote_item_missing(self, sample_work_items):
        """No conflict if remote item was deleted (not in remote_items dict)."""
        planner = SyncPlanner()

        item = sample_work_items[0]
        tracking_key = get_tracking_key(item, "work/inbox.yaml", 0)

        state = SyncState()
        state.work_items[tracking_key] = WorkItemState(
            remote_id="remote-0",
            content_hash=calculate_content_hash(item),
            source="work/inbox.yaml:0",
            last_synced=datetime.now().isoformat(),
            hash_version=CONTENT_HASH_VERSION,
        )

        plan = self._make_plan_with_updates([item], state)

        # Remote item not present (deleted remotely)
        remote_items = {}

        conflicts = planner.detect_conflicts(plan, state, remote_items)
        assert len(conflicts) == 0

    def test_no_conflict_when_state_hash_version_is_stale(self, sample_work_items):
        """Old state hash versions should not trigger bogus conflicts."""
        planner = SyncPlanner()

        item = sample_work_items[0]
        tracking_key = get_tracking_key(item, "work/inbox.yaml", 0)

        state = SyncState()
        state.work_items[tracking_key] = WorkItemState(
            remote_id="remote-0",
            content_hash="old-hash-version-value",
            source="work/inbox.yaml:0",
            last_synced=datetime.now().isoformat(),
            hash_version=1,
        )

        modified_item = WorkItem(
            id=item.id,
            title="First task - modified locally",
            type=item.type,
            state=item.state,
        )
        plan = self._make_plan_with_updates([modified_item], state)

        remote_items = {"remote-0": item}
        conflicts = planner.detect_conflicts(plan, state, remote_items)

        assert conflicts == []

    def test_no_conflict_for_creates(self, sample_work_items):
        """Creates should not trigger conflict detection."""
        planner = SyncPlanner()

        plan = SyncPlan()
        from planecompose.sync.planner import SyncItem
        plan.creates.append(SyncItem(
            action=SyncAction.CREATE,
            item=sample_work_items[0],
            tracking_key="id:new-item",
            source_file="work/inbox.yaml",
            index=0,
            reason="new item",
        ))

        state = SyncState()
        remote_items = {}

        conflicts = planner.detect_conflicts(plan, state, remote_items)
        assert len(conflicts) == 0

    def test_multiple_conflicts(self, sample_work_items):
        """Multiple items can have conflicts simultaneously."""
        planner = SyncPlanner()

        state = SyncState()
        for i, item in enumerate(sample_work_items[:2]):
            tracking_key = get_tracking_key(item, "work/inbox.yaml", i)
            state.work_items[tracking_key] = WorkItemState(
                remote_id=f"remote-{i}",
                content_hash=calculate_content_hash(item),
                source=f"work/inbox.yaml:{i}",
                last_synced=datetime.now().isoformat(),
                hash_version=CONTENT_HASH_VERSION,
            )

        # Both items modified locally
        modified_items = [
            WorkItem(id=sample_work_items[0].id, title="Modified A", type="task", state="backlog"),
            WorkItem(id=sample_work_items[1].id, title="Modified B", type="bug", state="in_progress"),
        ]

        plan = self._make_plan_with_updates(modified_items, state)

        # Both items also changed remotely
        remote_items = {
            "remote-0": WorkItem(id=sample_work_items[0].id, title="Remote A", type="task", state="backlog"),
            "remote-1": WorkItem(id=sample_work_items[1].id, title="Remote B", type="bug", state="in_progress"),
        }

        conflicts = planner.detect_conflicts(plan, state, remote_items)
        assert len(conflicts) == 2

    def test_conflict_item_dataclass_fields(self):
        """ConflictItem has all expected fields."""
        conflict = ConflictItem(
            tracking_key="id:test-item",
            item_title="Test Item",
            local_hash="abc123",
            state_hash="def456",
            remote_hash="ghi789",
        )
        assert conflict.tracking_key == "id:test-item"
        assert conflict.item_title == "Test Item"
        assert conflict.local_hash == "abc123"
        assert conflict.state_hash == "def456"
        assert conflict.remote_hash == "ghi789"

    def test_no_conflict_when_update_has_no_remote_id(self):
        """Updates without remote_id are skipped (edge case)."""
        planner = SyncPlanner()
        from planecompose.sync.planner import SyncItem

        plan = SyncPlan()
        plan.updates.append(SyncItem(
            action=SyncAction.UPDATE,
            item=WorkItem(title="No Remote ID", type="task"),
            tracking_key="id:orphan",
            source_file="work/inbox.yaml",
            index=0,
            remote_id=None,  # No remote ID
            reason="content changed",
        ))

        state = SyncState()
        state.work_items["id:orphan"] = WorkItemState(
            remote_id="remote-x",
            content_hash="old-hash",
            source="work/inbox.yaml:0",
            last_synced=datetime.now().isoformat(),
        )

        remote_items = {"remote-x": WorkItem(title="Different", type="task")}

        conflicts = planner.detect_conflicts(plan, state, remote_items)
        assert len(conflicts) == 0

    def test_empty_plan_no_conflicts(self):
        """Empty plan has no conflicts."""
        planner = SyncPlanner()
        plan = SyncPlan()
        state = SyncState()
        remote_items = {}

        conflicts = planner.detect_conflicts(plan, state, remote_items)
        assert len(conflicts) == 0

    def test_plan_push_deduplicates_tracking_keys(self, sample_work_items):
        """Duplicate tracking keys in local items are skipped."""
        planner = SyncPlanner()
        state = SyncState()

        item = sample_work_items[0]
        # Same item appears twice with same source/index (produces same tracking key)
        local_items = [
            WorkItemWithMeta(item=item, source_file="work/inbox.yaml", index=0),
            WorkItemWithMeta(item=item, source_file="work/inbox.yaml", index=0),
        ]

        plan = planner.plan_push(local_items, state)

        # First occurrence creates, second is skipped as duplicate
        assert len(plan.creates) == 1
        assert len(plan.skipped) == 1
        assert plan.skipped[0].reason == "duplicate tracking key"
