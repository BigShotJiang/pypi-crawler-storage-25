"""Tests for YAML parsers."""
import pytest
from pathlib import Path

from planecompose.parser.plane_yaml import parse_plane_yaml
from planecompose.parser.types_yaml import parse_types_yaml
from planecompose.parser.workflows_yaml import parse_workflows_yaml
from planecompose.parser.labels_yaml import parse_labels_yaml
from planecompose.parser.work_yaml import parse_work_items
from planecompose.parser.members_yaml import (
    read_members_yaml,
    write_members_yaml,
    merge_member_roles,
)


class TestMembersYamlParser:
    """Tests for members_yaml read/write/merge."""

    def _project(self, tmp_path: Path) -> Path:
        """Set up a minimal project dir with a schema/ folder."""
        (tmp_path / "schema").mkdir()
        return tmp_path

    # ── write_members_yaml ────────────────────────────────────────────────────

    def test_write_system_role_slugs(self, tmp_path):
        """System role slugs (admin/member/guest) are written as-is."""
        project = self._project(tmp_path)
        members = [
            {"id": "uuid-1", "email": "owner@example.com", "display_name": "Owner", "role": "owner"},
            {"id": "uuid-2", "email": "admin@example.com", "display_name": "Admin", "role": "admin"},
            {"id": "uuid-3", "email": "member@example.com", "display_name": "Member", "role": "member"},
            {"id": "uuid-4", "email": "guest@example.com", "display_name": "Guest", "role": "guest"},
        ]
        write_members_yaml(project, members)

        result = read_members_yaml(project)
        roles = {m["email"]: m["role"] for m in result}
        assert roles["owner@example.com"] == "owner"
        assert roles["admin@example.com"] == "admin"
        assert roles["member@example.com"] == "member"
        assert roles["guest@example.com"] == "guest"

    def test_write_custom_role_slug(self, tmp_path):
        """Custom role slugs (from RBAC UI) are written and round-trip unchanged."""
        project = self._project(tmp_path)
        members = [
            {"id": "uuid-1", "email": "dev@example.com", "display_name": "Dev", "role": "developer"},
            {"id": "uuid-2", "email": "pm@example.com", "display_name": "PM", "role": "product-manager"},
        ]
        write_members_yaml(project, members)

        result = read_members_yaml(project)
        roles = {m["email"]: m["role"] for m in result}
        assert roles["dev@example.com"] == "developer"
        assert roles["pm@example.com"] == "product-manager"

    def test_write_legacy_integer_role_converted_to_slug(self, tmp_path):
        """Legacy integer roles (5/15/20) are converted to their canonical slug."""
        project = self._project(tmp_path)
        members = [
            {"id": "uuid-1", "email": "a@example.com", "role": 20},
            {"id": "uuid-2", "email": "b@example.com", "role": 15},
            {"id": "uuid-3", "email": "c@example.com", "role": 5},
        ]
        write_members_yaml(project, members)

        result = read_members_yaml(project)
        roles = {m["email"]: m["role"] for m in result}
        assert roles["a@example.com"] == "admin"
        assert roles["b@example.com"] == "member"
        assert roles["c@example.com"] == "guest"

    def test_write_member_without_role(self, tmp_path):
        """Members without a role field are written without a role key."""
        project = self._project(tmp_path)
        members = [{"id": "uuid-1", "email": "norole@example.com", "display_name": "No Role"}]
        write_members_yaml(project, members)

        result = read_members_yaml(project)
        assert result[0]["email"] == "norole@example.com"
        assert "role" not in result[0]

    def test_write_members_empty_list(self, tmp_path):
        """Writing an empty list produces a valid file that reads back as empty."""
        project = self._project(tmp_path)
        write_members_yaml(project, [])
        assert read_members_yaml(project) == []

    # ── merge_member_roles ────────────────────────────────────────────────────

    def test_merge_preserves_system_role_from_file(self, tmp_path):
        """Existing system role from local file is preserved on freshly-fetched members."""
        project = self._project(tmp_path)
        # Simulate existing members.yaml with roles
        write_members_yaml(project, [
            {"email": "user@example.com", "role": "admin"},
        ])
        # Freshly fetched members (e.g. from older server without role_slug)
        fetched = [{"id": "uuid-1", "email": "user@example.com", "display_name": "User"}]

        merged = merge_member_roles(fetched, project)
        assert merged[0]["role"] == "admin"

    def test_merge_preserves_custom_role_from_file(self, tmp_path):
        """Custom role slug in local file is preserved — not limited to 3 hardcoded slugs."""
        project = self._project(tmp_path)
        write_members_yaml(project, [
            {"email": "dev@example.com", "role": "developer"},
        ])
        fetched = [{"id": "uuid-1", "email": "dev@example.com", "display_name": "Dev"}]

        merged = merge_member_roles(fetched, project)
        assert merged[0]["role"] == "developer"

    def test_merge_api_role_not_overwritten_when_api_returns_role(self, tmp_path):
        """When the API already returns role_slug, merge does not overwrite it."""
        project = self._project(tmp_path)
        write_members_yaml(project, [
            {"email": "user@example.com", "role": "guest"},
        ])
        # API now returns role_slug directly — fetch_project_members stores it as "role"
        fetched = [{"id": "uuid-1", "email": "user@example.com", "role": "admin"}]

        merged = merge_member_roles(fetched, project)
        # merge_member_roles overwrites with local value (it's a fallback for old servers)
        # This is expected behaviour — caller decides whether to call merge or not
        assert merged[0]["role"] == "guest"

    def test_merge_new_member_has_no_role(self, tmp_path):
        """Members not in local file pass through without a role added."""
        project = self._project(tmp_path)
        write_members_yaml(project, [])
        fetched = [{"id": "uuid-1", "email": "new@example.com", "display_name": "New"}]

        merged = merge_member_roles(fetched, project)
        assert "role" not in merged[0]


class TestPlaneYamlParser:
    """Tests for plane.yaml parser."""
    
    def test_parse_plane_yaml(self, temp_project):
        """Test parsing plane.yaml."""
        config = parse_plane_yaml(temp_project / "plane.yaml")
        
        assert config.workspace == "test-workspace"
        assert config.project_key == "TEST"
        assert config.project_name == "Test Project"
        assert config.default_type == "task"
    
    def test_parse_plane_yaml_with_uuid(self, tmp_path):
        """Test parsing plane.yaml with UUID."""
        plane_yaml = """
workspace: myteam
project:
  key: PROJ
  uuid: abc-123-def-456
  name: My Project
"""
        yaml_path = tmp_path / "plane.yaml"
        yaml_path.write_text(plane_yaml)
        
        config = parse_plane_yaml(yaml_path)
        
        assert config.project_uuid == "abc-123-def-456"
    
    def test_parse_plane_yaml_minimal(self, tmp_path):
        """Test parsing minimal plane.yaml."""
        plane_yaml = """
workspace: test
project:
  key: T
"""
        yaml_path = tmp_path / "plane.yaml"
        yaml_path.write_text(plane_yaml)
        
        config = parse_plane_yaml(yaml_path)
        
        assert config.workspace == "test"
        assert config.project_key == "T"


class TestTypesYamlParser:
    """Tests for types.yaml parser."""
    
    def test_parse_types_yaml(self, temp_project):
        """Test parsing types.yaml."""
        types = parse_types_yaml(temp_project / "schema" / "types.yaml")
        
        assert len(types) == 2
        
        task_type = next(t for t in types if t.name == "task")
        assert task_type.description == "A single unit of work"
        assert task_type.workflow == "standard"
    
    def test_parse_types_yaml_with_fields(self, tmp_path):
        """Test parsing types with custom fields."""
        types_yaml = """
feature:
  description: A feature request
  workflow: standard
  fields:
    - name: title
      type: string
      required: true
    - name: priority
      type: enum
      options: [low, medium, high]
"""
        yaml_path = tmp_path / "types.yaml"
        yaml_path.write_text(types_yaml)
        
        types = parse_types_yaml(yaml_path)
        
        assert len(types) == 1
        assert types[0].name == "feature"
        assert len(types[0].fields) == 2
        assert types[0].fields[1].options == ["low", "medium", "high"]
    
    def test_parse_types_yaml_preserves_casing(self, tmp_path):
        """Test that type names preserve original casing."""
        types_yaml = """
Bug:
  description: A defect
  workflow: default

Feature:
  description: A new feature
  workflow: default
"""
        yaml_path = tmp_path / "types.yaml"
        yaml_path.write_text(types_yaml)

        types = parse_types_yaml(yaml_path)

        assert len(types) == 2
        assert types[0].name == "Bug"
        assert types[1].name == "Feature"

    def test_parse_types_yaml_empty(self, tmp_path):
        """Test parsing empty types.yaml."""
        yaml_path = tmp_path / "types.yaml"
        yaml_path.write_text("")

        types = parse_types_yaml(yaml_path)

        assert types == []


class TestWorkflowsYamlParser:
    """Tests for workflows.yaml parser."""
    
    def test_parse_workflows_yaml(self, temp_project):
        """Test parsing workflows.yaml."""
        workflows = parse_workflows_yaml(temp_project / "schema" / "workflows.yaml")
        
        assert len(workflows) == 1
        assert workflows[0].name == "standard"
        assert workflows[0].initial == "backlog"
        assert "done" in workflows[0].terminal
    
    def test_parse_workflows_yaml_states(self, temp_project):
        """Test parsing workflow states."""
        workflows = parse_workflows_yaml(temp_project / "schema" / "workflows.yaml")
        
        states = workflows[0].states
        assert len(states) == 3
        
        backlog = next(s for s in states if s.name == "backlog")
        assert backlog.group == "unstarted"
        assert backlog.color == "#858585"
    
    def test_parse_workflows_yaml_empty(self, tmp_path):
        """Test parsing empty workflows.yaml."""
        yaml_path = tmp_path / "workflows.yaml"
        yaml_path.write_text("")
        
        workflows = parse_workflows_yaml(yaml_path)
        
        assert workflows == []


class TestLabelsYamlParser:
    """Tests for labels.yaml parser."""
    
    def test_parse_labels_yaml_groups(self, temp_project):
        """Test parsing labels.yaml with groups."""
        labels = parse_labels_yaml(temp_project / "schema" / "labels.yaml")
        
        assert len(labels) == 2
        
        frontend_label = next(l for l in labels if l.name == "frontend")
        assert frontend_label.color == "#3b82f6"
    
    def test_parse_labels_yaml_flat(self, tmp_path):
        """Test parsing flat labels.yaml."""
        labels_yaml = """
- name: bug
  color: "#ef4444"
- name: feature
  color: "#22c55e"
"""
        yaml_path = tmp_path / "labels.yaml"
        yaml_path.write_text(labels_yaml)
        
        labels = parse_labels_yaml(yaml_path)
        
        assert len(labels) == 2
        assert labels[0].name == "bug"
    
    def test_parse_labels_yaml_empty(self, tmp_path):
        """Test parsing empty labels.yaml."""
        yaml_path = tmp_path / "labels.yaml"
        yaml_path.write_text("")
        
        labels = parse_labels_yaml(yaml_path)
        
        assert labels == []


class TestWorkYamlParser:
    """Tests for work/*.yaml parser."""
    
    def test_parse_work_items_empty(self, temp_project):
        """Test parsing empty work items."""
        items = list(parse_work_items(temp_project / "work"))
        
        assert len(items) == 0
    
    def test_parse_work_items_list(self, tmp_path):
        """Test parsing list of work items."""
        work_dir = tmp_path / "work"
        work_dir.mkdir()
        
        work_yaml = """
- title: First task
  type: task
  state: backlog

- title: Second task
  type: bug
  priority: high
"""
        (work_dir / "inbox.yaml").write_text(work_yaml)
        
        items = list(parse_work_items(work_dir, tmp_path))
        
        assert len(items) == 2
        assert items[0].item.title == "First task"
        assert items[1].item.priority == "high"
    
    def test_parse_work_items_with_ids(self, tmp_path):
        """Test parsing work items with stable IDs."""
        work_dir = tmp_path / "work"
        work_dir.mkdir()
        
        work_yaml = """
- id: task-001
  title: Task with ID
  type: task

- title: Task without ID
  type: task
"""
        (work_dir / "inbox.yaml").write_text(work_yaml)
        
        items = list(parse_work_items(work_dir, tmp_path))
        
        assert items[0].item.id == "task-001"
        assert items[1].item.id is None
    
    def test_parse_work_items_metadata(self, tmp_path):
        """Test that parser captures source metadata."""
        work_dir = tmp_path / "work"
        work_dir.mkdir()
        
        work_yaml = """
- title: Test task
  type: task
"""
        (work_dir / "inbox.yaml").write_text(work_yaml)
        
        items = list(parse_work_items(work_dir, tmp_path))
        
        assert items[0].source_file == "work/inbox.yaml"
        assert items[0].index == 0
    
    def test_parse_work_items_multiple_files(self, tmp_path):
        """Test parsing work items from multiple files."""
        work_dir = tmp_path / "work"
        work_dir.mkdir()
        
        (work_dir / "a_features.yaml").write_text("- title: Feature 1\n  type: task")
        (work_dir / "b_bugs.yaml").write_text("- title: Bug 1\n  type: bug")
        
        items = list(parse_work_items(work_dir, tmp_path))
        
        assert len(items) == 2
        # Should be sorted by filename
        assert items[0].item.title == "Feature 1"
        assert items[1].item.title == "Bug 1"

