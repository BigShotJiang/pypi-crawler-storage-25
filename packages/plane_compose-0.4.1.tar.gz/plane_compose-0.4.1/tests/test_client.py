"""Tests for PlaneApiClient error translation, retry logic, and detect_error_type."""
import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from planecompose.backend.client import PlaneApiClient, detect_error_type
from planecompose.exceptions import (
    APIError,
    AuthenticationError,
    PermissionError,
    NotFoundError,
    RateLimitError,
    NetworkError,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_http_error(status_code: int, message: str = "error"):
    """Create a mock HttpError with the given status code."""
    error = MagicMock()
    error.__class__.__name__ = "HttpError"
    error.status_code = status_code
    error.response = None
    error.__str__ = lambda self: message
    # Make it raise-able
    real_error = type("HttpError", (Exception,), {
        "status_code": status_code,
        "response": None,
    })(message)
    return real_error


# ---------------------------------------------------------------------------
# Tests: Error Translation
# ---------------------------------------------------------------------------

class TestErrorTranslation:
    """Test _translate_http_error maps status codes correctly."""

    @pytest.fixture(autouse=True)
    def setup_client(self):
        """Create a client with mocked SDK."""
        with patch("planecompose.backend.client.PlaneClient"):
            with patch("planecompose.backend.client.PlaneApiClient._get_or_create_rate_limiter"):
                self.client = PlaneApiClient.__new__(PlaneApiClient)
                self.client._api_url = "https://test.plane.so"
                self.client._api_key = "test-key"

    def _make_http_error(self, status_code, detail=None):
        """Create a fake HttpError for translation."""
        from plane import HttpError
        err = MagicMock(spec=HttpError)
        err.status_code = status_code
        err.response = None
        err.__str__ = lambda self: f"HTTP {status_code}"
        # Make it a proper HttpError instance for isinstance checks
        return err

    def test_401_returns_authentication_error(self):
        err = self._make_http_error(401)
        result = self.client._translate_http_error(err, "test")
        assert isinstance(result, AuthenticationError)
        assert result.status_code == 401

    def test_403_returns_permission_error(self):
        err = self._make_http_error(403)
        result = self.client._translate_http_error(err, "list_items")
        assert isinstance(result, PermissionError)
        assert result.status_code == 403

    def test_404_returns_not_found_error(self):
        err = self._make_http_error(404)
        result = self.client._translate_http_error(err, "get_item")
        assert isinstance(result, NotFoundError)
        assert result.status_code == 404

    def test_429_returns_rate_limit_error(self):
        err = self._make_http_error(429)
        result = self.client._translate_http_error(err, "create_item")
        assert isinstance(result, RateLimitError)
        assert result.status_code == 429

    def test_500_returns_api_error(self):
        err = self._make_http_error(500)
        result = self.client._translate_http_error(err, "update_item")
        assert isinstance(result, APIError)
        assert result.status_code == 500

    def test_502_returns_api_error(self):
        err = self._make_http_error(502)
        result = self.client._translate_http_error(err, "")
        assert isinstance(result, APIError)
        assert result.status_code == 502


class TestExtractErrorDetail:
    """Test _extract_error_detail extracts message from response."""

    @pytest.fixture(autouse=True)
    def setup_client(self):
        with patch("planecompose.backend.client.PlaneClient"):
            with patch("planecompose.backend.client.PlaneApiClient._get_or_create_rate_limiter"):
                self.client = PlaneApiClient.__new__(PlaneApiClient)

    def test_no_response_returns_str(self):
        err = MagicMock()
        err.response = None
        err.__str__ = lambda self: "plain error"
        assert self.client._extract_error_detail(err) == "plain error"

    def test_response_with_detail(self):
        # SDK passes already-parsed dict as error.response (not a response object)
        err = MagicMock()
        err.response = {"detail": "Item not found"}
        result = self.client._extract_error_detail(err)
        assert result == "Item not found"

    def test_response_with_error_key(self):
        err = MagicMock()
        err.response = {"error": "Bad request"}
        result = self.client._extract_error_detail(err)
        assert result == "Bad request"

    def test_response_with_drf_field_errors(self):
        # DRF field-level validation: {"field": ["msg1", "msg2"]}
        err = MagicMock()
        err.response = {"identifier": ["Ensure this field has no more than 10 characters."]}
        result = self.client._extract_error_detail(err)
        assert "identifier" in result
        assert "10 characters" in result

    def test_response_json_raises_falls_back(self):
        # response is a plain string (non-JSON body from SDK)
        err = MagicMock()
        err.response = None
        err.__str__ = lambda self: "fallback message"
        result = self.client._extract_error_detail(err)
        assert result == "fallback message"


# ---------------------------------------------------------------------------
# Tests: detect_error_type
# ---------------------------------------------------------------------------

class TestDetectErrorType:
    """Test detect_error_type function."""

    def test_already_authentication_error(self):
        err = AuthenticationError()
        assert detect_error_type(err) is AuthenticationError

    def test_already_permission_error(self):
        err = PermissionError(resource="test")
        assert detect_error_type(err) is PermissionError

    def test_already_not_found_error(self):
        err = NotFoundError(resource="Item")
        assert detect_error_type(err) is NotFoundError

    def test_already_rate_limit_error(self):
        err = RateLimitError()
        assert detect_error_type(err) is RateLimitError

    def test_already_api_error(self):
        err = APIError(message="fail", status_code=500)
        assert detect_error_type(err) is APIError

    def test_already_network_error(self):
        err = NetworkError(message="timeout")
        assert detect_error_type(err) is NetworkError

    def test_generic_exception_returns_api_error(self):
        # String-based detection was removed to avoid false positives
        # (e.g., "Processed 401 items" being treated as auth error).
        # Generic exceptions now always map to APIError.
        err = Exception("got 401 unauthorized response")
        assert detect_error_type(err) is APIError

    def test_generic_exception_with_403_returns_api_error(self):
        err = Exception("403 forbidden access")
        assert detect_error_type(err) is APIError

    def test_generic_exception_with_404_returns_api_error(self):
        err = Exception("resource not found")
        assert detect_error_type(err) is APIError

    def test_generic_exception_with_429_returns_api_error(self):
        err = Exception("rate limit exceeded")
        assert detect_error_type(err) is APIError

    def test_connection_error_returns_network_error(self):
        err = ConnectionError("connection refused")
        assert detect_error_type(err) is NetworkError

    def test_timeout_error_returns_network_error(self):
        err = TimeoutError("timed out")
        assert detect_error_type(err) is NetworkError

    def test_os_error_returns_network_error(self):
        err = OSError("network unreachable")
        assert detect_error_type(err) is NetworkError

    def test_unknown_error_returns_api_error(self):
        err = Exception("something unexpected")
        assert detect_error_type(err) is APIError


class TestExtractRetryAfter:
    """Test _extract_retry_after extracts header value."""

    @pytest.fixture(autouse=True)
    def setup_client(self):
        with patch("planecompose.backend.client.PlaneClient"):
            with patch("planecompose.backend.client.PlaneApiClient._get_or_create_rate_limiter"):
                self.client = PlaneApiClient.__new__(PlaneApiClient)

    def test_valid_retry_after(self):
        err = MagicMock()
        err.response.headers = {"Retry-After": "30"}
        assert self.client._extract_retry_after(err) == 30

    def test_no_response(self):
        err = MagicMock()
        err.response = None
        assert self.client._extract_retry_after(err) is None

    def test_no_header(self):
        err = MagicMock()
        err.response.headers = {}
        assert self.client._extract_retry_after(err) is None

    def test_invalid_value(self):
        err = MagicMock()
        err.response.headers = {"Retry-After": "not-a-number"}
        assert self.client._extract_retry_after(err) is None
