"""Tests for workspace schema writer functions (cli/ws.py).

Covers _write_customers_yaml, _render_remote_section("customers"),
_merge_ws_section("customers"), _DIFF_LISTS["customers"],
_build_push_payload / _push_endpoint / _patch_local_id for the customers section.
"""
import yaml
import pytest
from pathlib import Path

from planecompose.cli.ws import (
    _write_customers_yaml,
    _render_remote_section,
    _merge_ws_section,
    _DIFF_LISTS,
    _build_push_payload,
    _push_endpoint,
    _patch_local_id,
    _compute_semantic_diff,
    _format_push_item,
)


# ---------------------------------------------------------------------------
# Sample data
# ---------------------------------------------------------------------------

_PROPS_RAW = [
    {
        "id": "aaa-111",
        "name": "country",
        "display_name": "Country",
        "property_type": "TEXT",
        "is_required": False,
        "settings": {"display_format": "single-line"},
        "is_active": True,
        "is_multi": False,
        "sort_order": 95535.0,
    },
    {
        "id": "bbb-222",
        "name": "city",
        "display_name": "City",
        "property_type": "TEXT",
        "is_required": True,
        "settings": {"display_format": "single-line"},
        "is_active": True,
        "is_multi": False,
        "sort_order": 85535.0,
    },
]


# ---------------------------------------------------------------------------
# _write_customers_yaml
# ---------------------------------------------------------------------------

class TestWriteCustomersYaml:
    """Tests for _write_customers_yaml."""

    def test_writes_properties_list(self, tmp_path: Path):
        path = tmp_path / "customers.yaml"
        _write_customers_yaml(path, _PROPS_RAW)
        data = yaml.safe_load(path.read_text())
        props = data["properties"]
        assert len(props) == 2

    def test_maps_api_fields_to_yaml_fields(self, tmp_path: Path):
        path = tmp_path / "customers.yaml"
        _write_customers_yaml(path, _PROPS_RAW)
        data = yaml.safe_load(path.read_text())
        country = data["properties"][0]
        assert country["id"] == "aaa-111"
        assert country["name"] == "country"
        assert country["display_name"] == "Country"
        assert country["type"] == "TEXT"          # property_type → type
        assert country["required"] is False        # is_required → required
        assert country["settings"] == {"display_format": "single-line"}

    def test_required_true_preserved(self, tmp_path: Path):
        path = tmp_path / "customers.yaml"
        _write_customers_yaml(path, _PROPS_RAW)
        data = yaml.safe_load(path.read_text())
        city = data["properties"][1]
        assert city["required"] is True

    def test_empty_list_writes_empty_properties(self, tmp_path: Path):
        path = tmp_path / "customers.yaml"
        _write_customers_yaml(path, [])
        data = yaml.safe_load(path.read_text())
        assert data == {"properties": []}

    def test_none_writes_empty_properties(self, tmp_path: Path):
        path = tmp_path / "customers.yaml"
        _write_customers_yaml(path, None)
        data = yaml.safe_load(path.read_text())
        assert data == {"properties": []}

    def test_ignores_entries_without_name(self, tmp_path: Path):
        path = tmp_path / "customers.yaml"
        props = [{"id": "x-1", "property_type": "TEXT", "is_required": False}]  # no name
        _write_customers_yaml(path, props)
        data = yaml.safe_load(path.read_text())
        assert data["properties"] == []

    def test_file_has_header_comment(self, tmp_path: Path):
        path = tmp_path / "customers.yaml"
        _write_customers_yaml(path, [])
        text = path.read_text()
        assert "Customer Property Definitions" in text

    def test_does_not_include_api_noise_fields(self, tmp_path: Path):
        """API internal fields should not bleed through; user-facing names are used instead."""
        path = tmp_path / "customers.yaml"
        _write_customers_yaml(path, _PROPS_RAW)
        data = yaml.safe_load(path.read_text())
        for prop in data["properties"]:
            assert "is_active" not in prop    # mapped to "active"
            assert "is_multi" not in prop
            assert "sort_order" not in prop
            assert "property_type" not in prop   # mapped to "type"
            assert "is_required" not in prop      # mapped to "required"

    def test_inactive_property_shown_with_active_false(self, tmp_path: Path):
        """Properties with is_active=false are included in YAML with active: false."""
        path = tmp_path / "customers.yaml"
        props = [
            {**_PROPS_RAW[0], "is_active": True},   # country — active
            {**_PROPS_RAW[1], "is_active": False},  # city — disabled
        ]
        _write_customers_yaml(path, props)
        data = yaml.safe_load(path.read_text())
        by_name = {p["name"]: p for p in data["properties"]}
        assert "country" in by_name
        assert "city" in by_name, "inactive property should still appear in YAML"
        assert by_name["country"]["active"] is True
        assert by_name["city"]["active"] is False

    def test_active_field_present_for_all_properties(self, tmp_path: Path):
        """Every property entry must have an 'active' field."""
        path = tmp_path / "customers.yaml"
        _write_customers_yaml(path, _PROPS_RAW)
        data = yaml.safe_load(path.read_text())
        for prop in data["properties"]:
            assert "active" in prop, f"'active' missing from property '{prop.get('name')}'"

    def test_inactive_options_excluded(self, tmp_path: Path):
        """Soft-deleted options (is_active=false) must not appear in customers.yaml."""
        path = tmp_path / "customers.yaml"
        props = [
            {
                "id": "p-1",
                "name": "zone",
                "display_name": "Zone",
                "property_type": "OPTION",
                "is_required": False,
                "is_active": True,
                "options": [
                    {"id": "o-1", "name": "East", "is_active": True},
                    {"id": "o-2", "name": "West", "is_active": False},  # soft-deleted
                ],
            }
        ]
        _write_customers_yaml(path, props)
        data = yaml.safe_load(path.read_text())
        opts = data["properties"][0]["options"]
        opt_names = [o["name"] for o in opts]
        assert "East" in opt_names
        assert "West" not in opt_names, "soft-deleted option 'West' should be excluded"


# ---------------------------------------------------------------------------
# _render_remote_section("customers")
# ---------------------------------------------------------------------------

class TestRenderRemoteSectionCustomers:
    """_render_remote_section("customers", data) roundtrip."""

    def _data(self, props):
        return {"customer_properties": props}

    def test_renders_properties(self):
        text = _render_remote_section("customers", self._data(_PROPS_RAW))
        data = yaml.safe_load(text)
        assert len(data["properties"]) == 2
        names = {p["name"] for p in data["properties"]}
        assert names == {"country", "city"}

    def test_renders_empty_when_no_properties(self):
        text = _render_remote_section("customers", self._data([]))
        data = yaml.safe_load(text)
        assert data["properties"] == []

    def test_renders_empty_when_none(self):
        text = _render_remote_section("customers", self._data(None))
        data = yaml.safe_load(text)
        assert data["properties"] == []


# ---------------------------------------------------------------------------
# _merge_ws_section("customers")
# ---------------------------------------------------------------------------

class TestMergeWsSectionCustomers:
    """_merge_ws_section merges customer properties by id."""

    def _props(self, entries):
        return {"properties": entries}

    def test_remote_only_items_included(self):
        local = self._props([
            {"id": "aaa-111", "name": "country", "display_name": "Country", "type": "TEXT", "required": False},
        ])
        remote = self._props([
            {"id": "aaa-111", "name": "country", "display_name": "Country", "type": "TEXT", "required": False},
            {"id": "bbb-222", "name": "city", "display_name": "City", "type": "TEXT", "required": False},
        ])
        merged = _merge_ws_section("customers", local, remote)
        assert merged is not None
        ids = {p["id"] for p in merged["properties"]}
        assert "aaa-111" in ids
        assert "bbb-222" in ids

    def test_local_only_items_preserved(self):
        """Items in local but not in remote (new local entry without id) are kept."""
        local = self._props([
            {"id": "aaa-111", "name": "country", "display_name": "Country", "type": "TEXT", "required": False},
            {"name": "industry", "display_name": "Industry", "type": "TEXT", "required": False},
        ])
        remote = self._props([
            {"id": "aaa-111", "name": "country", "display_name": "Country", "type": "TEXT", "required": False},
        ])
        merged = _merge_ws_section("customers", local, remote)
        assert merged is not None
        names = [p["name"] for p in merged["properties"]]
        assert "country" in names
        assert "industry" in names  # preserved as local-only

    def test_remote_wins_for_existing(self):
        """For items that exist in both, the remote version is used."""
        local = self._props([
            {"id": "aaa-111", "name": "country", "display_name": "OLD NAME", "type": "TEXT", "required": False},
        ])
        remote = self._props([
            {"id": "aaa-111", "name": "country", "display_name": "Country", "type": "TEXT", "required": False},
        ])
        merged = _merge_ws_section("customers", local, remote)
        assert merged is not None
        assert merged["properties"][0]["display_name"] == "Country"  # remote wins

    def test_empty_local_returns_remote(self):
        remote = self._props([
            {"id": "aaa-111", "name": "country", "display_name": "Country", "type": "TEXT", "required": False},
        ])
        merged = _merge_ws_section("customers", self._props([]), remote)
        assert merged is not None
        assert len(merged["properties"]) == 1

    def test_empty_remote_preserves_local(self):
        local = self._props([
            {"name": "industry", "display_name": "Industry", "type": "TEXT", "required": False},
        ])
        merged = _merge_ws_section("customers", local, self._props([]))
        assert merged is not None
        assert len(merged["properties"]) == 1


# ---------------------------------------------------------------------------
# _DIFF_LISTS["customers"]
# ---------------------------------------------------------------------------

class TestDiffListsCustomers:
    """Verify _DIFF_LISTS has a valid customers entry."""

    def test_customers_in_diff_lists(self):
        assert "customers" in _DIFF_LISTS

    def test_customers_diff_list_shape(self):
        configs = _DIFF_LISTS["customers"]
        assert len(configs) == 1
        yaml_key, merge_key, display_fields = configs[0]
        assert yaml_key == "properties"
        assert merge_key == "id"
        assert "name" in display_fields          # shown in diff (immutable — push ignores changes)
        assert "display_name" in display_fields
        assert "type" in display_fields          # shown in diff (immutable — push ignores changes)
        assert "required" in display_fields
        assert "active" in display_fields


# ---------------------------------------------------------------------------
# _compute_semantic_diff for customers
# ---------------------------------------------------------------------------

class TestComputeSemanticDiffCustomers:
    """Semantic diff for customers.yaml uses _DIFF_LISTS["customers"]."""

    def _props_yaml(self, entries):
        return {"properties": entries}

    def test_no_diff_when_identical(self):
        data = self._props_yaml([
            {"id": "aaa-111", "name": "country", "display_name": "Country", "type": "TEXT", "required": False},
        ])
        blocks = _compute_semantic_diff("customers", data, data)
        assert blocks == []

    def test_detects_remote_only(self):
        local = self._props_yaml([])
        remote = self._props_yaml([
            {"id": "aaa-111", "name": "country", "display_name": "Country", "type": "TEXT", "required": False},
        ])
        blocks = _compute_semantic_diff("customers", local, remote)
        assert len(blocks) == 1
        block = blocks[0]
        assert block["type"] == "list"
        assert block["yaml_key"] == "properties"
        assert len(block["remote_only"]) == 1

    def test_detects_local_only(self):
        local = self._props_yaml([
            {"id": "aaa-111", "name": "country", "display_name": "Country", "type": "TEXT", "required": False},
        ])
        remote = self._props_yaml([])
        blocks = _compute_semantic_diff("customers", local, remote)
        assert len(blocks) == 1
        assert len(blocks[0]["local_only"]) == 1

    def test_detects_changed(self):
        local = self._props_yaml([
            {"id": "aaa-111", "name": "country", "display_name": "OLD", "type": "TEXT", "required": False},
        ])
        remote = self._props_yaml([
            {"id": "aaa-111", "name": "country", "display_name": "Country", "type": "TEXT", "required": False},
        ])
        blocks = _compute_semantic_diff("customers", local, remote)
        assert len(blocks) == 1
        assert len(blocks[0]["changed"]) == 1
        assert "display_name" in blocks[0]["changed"][0]["diff_fields"]

    def test_detects_new_option_in_local(self):
        """Adding an option locally (no id) should appear as a changed property with options diff."""
        remote_opts = [{"id": "opt-1", "name": "East"}]
        local_opts = [{"id": "opt-1", "name": "East"}, {"name": "AP"}]  # AP has no id yet
        local = self._props_yaml([
            {"id": "p-1", "name": "zone", "display_name": "Zone", "type": "OPTION", "required": False,
             "options": local_opts},
        ])
        remote = self._props_yaml([
            {"id": "p-1", "name": "zone", "display_name": "Zone", "type": "OPTION", "required": False,
             "options": remote_opts},
        ])
        blocks = _compute_semantic_diff("customers", local, remote)
        assert len(blocks) == 1
        changed = blocks[0]["changed"]
        assert len(changed) == 1
        assert "options" in changed[0]["diff_fields"]
        remote_val, local_val = changed[0]["diff_fields"]["options"]
        assert remote_val == remote_opts
        assert local_val == local_opts

    def test_detects_deleted_option_in_local(self):
        """Removing an option locally should appear as a changed property."""
        remote_opts = [{"id": "opt-1", "name": "East"}, {"id": "opt-2", "name": "West"}]
        local_opts = [{"id": "opt-1", "name": "East"}]  # West removed locally
        local = self._props_yaml([
            {"id": "p-1", "name": "zone", "display_name": "Zone", "type": "OPTION", "required": False,
             "options": local_opts},
        ])
        remote = self._props_yaml([
            {"id": "p-1", "name": "zone", "display_name": "Zone", "type": "OPTION", "required": False,
             "options": remote_opts},
        ])
        blocks = _compute_semantic_diff("customers", local, remote)
        assert len(blocks) == 1
        changed = blocks[0]["changed"]
        assert len(changed) == 1
        assert "options" in changed[0]["diff_fields"]

    def test_detects_renamed_option(self):
        """Renaming an option locally should appear as a changed property."""
        remote_opts = [{"id": "opt-1", "name": "East"}]
        local_opts = [{"id": "opt-1", "name": "East Asia"}]  # renamed
        local = self._props_yaml([
            {"id": "p-1", "name": "zone", "display_name": "Zone", "type": "OPTION", "required": False,
             "options": local_opts},
        ])
        remote = self._props_yaml([
            {"id": "p-1", "name": "zone", "display_name": "Zone", "type": "OPTION", "required": False,
             "options": remote_opts},
        ])
        blocks = _compute_semantic_diff("customers", local, remote)
        assert len(blocks) == 1
        assert "options" in blocks[0]["changed"][0]["diff_fields"]

    def test_no_diff_when_options_identical(self):
        """Identical options lists should produce no diff."""
        opts = [{"id": "opt-1", "name": "East"}, {"id": "opt-2", "name": "West"}]
        data = self._props_yaml([
            {"id": "p-1", "name": "zone", "display_name": "Zone", "type": "OPTION", "required": False,
             "options": opts},
        ])
        blocks = _compute_semantic_diff("customers", data, data)
        assert blocks == []


# ---------------------------------------------------------------------------
# _push_endpoint for customers
# ---------------------------------------------------------------------------

class TestPushEndpointCustomers:
    """_push_endpoint returns correct URL for customers/properties."""

    def test_properties_endpoint(self):
        url = _push_endpoint("customers", "properties", "my-ws", "https://app.plane.so/api/v1")
        assert url == "https://app.plane.so/api/v1/workspaces/my-ws/customer-properties/"

    def test_other_yaml_key_raises(self):
        with pytest.raises(ValueError):
            _push_endpoint("customers", "unknown_key", "my-ws", "https://app.plane.so/api/v1")


# ---------------------------------------------------------------------------
# _build_push_payload for customers
# ---------------------------------------------------------------------------

class TestBuildPushPayloadCustomers:
    """_build_push_payload builds correct POST body for new customer properties."""

    def test_basic_text_property(self):
        item = {"name": "industry", "display_name": "Industry", "type": "TEXT", "required": False}
        payload = _build_push_payload("customers", "properties", item)
        assert payload["name"] == "industry"
        assert payload["display_name"] == "Industry"
        assert payload["property_type"] == "TEXT"   # mapped from "type"
        assert payload["is_required"] is False       # mapped from "required"
        assert payload["is_active"] is True          # defaults to True when 'active' not set
        assert "settings" not in payload

    def test_inactive_property_payload(self):
        """When active: false is set, is_active: false should be sent to the API."""
        item = {"name": "old_field", "display_name": "Old Field", "type": "TEXT", "required": False, "active": False}
        payload = _build_push_payload("customers", "properties", item)
        assert payload["is_active"] is False

    def test_with_settings(self):
        item = {
            "name": "bio",
            "display_name": "Bio",
            "type": "TEXT",
            "required": False,
            "settings": {"display_format": "multi-line"},
        }
        payload = _build_push_payload("customers", "properties", item)
        assert payload["settings"] == {"display_format": "multi-line"}

    def test_required_true(self):
        item = {"name": "email", "display_name": "Work Email", "type": "TEXT", "required": True}
        payload = _build_push_payload("customers", "properties", item)
        assert payload["is_required"] is True

    def test_display_name_falls_back_to_name(self):
        """If display_name is missing, falls back to name."""
        item = {"name": "notes", "type": "TEXT", "required": False}
        payload = _build_push_payload("customers", "properties", item)
        assert payload["display_name"] == "notes"

    def test_number_property_type(self):
        item = {"name": "revenue", "display_name": "Revenue", "type": "NUMBER", "required": False}
        payload = _build_push_payload("customers", "properties", item)
        assert payload["property_type"] == "NUMBER"


# ---------------------------------------------------------------------------
# _patch_local_id for customer properties
# ---------------------------------------------------------------------------

class TestPatchLocalIdCustomers:
    """_patch_local_id writes a server-assigned id into the matching local property entry."""

    def test_id_written_by_name_match(self):
        local_yaml = {
            "properties": [
                {"name": "industry", "display_name": "Industry", "type": "TEXT", "required": False},
            ]
        }
        _patch_local_id(local_yaml, "properties", {"name": "industry"}, "new-uuid-123")
        assert local_yaml["properties"][0]["id"] == "new-uuid-123"

    def test_id_first_in_field_order(self):
        """After patching, id should appear as the first field."""
        local_yaml = {
            "properties": [
                {"name": "industry", "display_name": "Industry", "type": "TEXT", "required": False},
            ]
        }
        _patch_local_id(local_yaml, "properties", {"name": "industry"}, "new-uuid-123")
        keys = list(local_yaml["properties"][0].keys())
        assert keys[0] == "id"

    def test_no_patch_if_already_has_id(self):
        """Items that already have an id should not be re-patched."""
        local_yaml = {
            "properties": [
                {"id": "existing-id", "name": "industry", "display_name": "Industry"},
            ]
        }
        _patch_local_id(local_yaml, "properties", {"name": "industry"}, "new-uuid-123")
        assert local_yaml["properties"][0]["id"] == "existing-id"

    def test_no_match_is_noop(self):
        local_yaml = {
            "properties": [
                {"name": "country", "display_name": "Country"},
            ]
        }
        _patch_local_id(local_yaml, "properties", {"name": "industry"}, "new-uuid-123")
        assert "id" not in local_yaml["properties"][0]


# ---------------------------------------------------------------------------
# _format_push_item for properties
# ---------------------------------------------------------------------------

class TestFormatPushItemProperties:
    """_format_push_item returns display_name for customer properties."""

    def test_uses_display_name(self):
        item = {"name": "country", "display_name": "Country", "type": "TEXT"}
        label = _format_push_item("properties", item)
        assert label == "Country"

    def test_falls_back_to_name(self):
        item = {"name": "country", "type": "TEXT"}
        label = _format_push_item("properties", item)
        assert label == "country"

    def test_returns_question_mark_for_empty(self):
        label = _format_push_item("properties", {})
        assert label == "?"
