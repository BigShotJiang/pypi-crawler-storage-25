"""Tests for project identifier parsing utilities."""

import pytest
from planecompose.utils.identifiers import (
    is_uuid,
    is_project_key,
    is_workspace_key_format,
    parse_project_identifier,
    validate_identifier,
    format_identifier_help,
    IdentifierFormat,
    ProjectIdentifier,
)


class TestIsUUID:
    """Tests for UUID detection."""

    def test_valid_uuid(self):
        """Valid UUIDs should be recognized."""
        assert is_uuid("8cee0da2-1b5b-4699-b11a-e3c8b26dd55d")
        assert is_uuid("00000000-0000-0000-0000-000000000000")
        assert is_uuid("AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE")

    def test_invalid_uuid(self):
        """Non-UUIDs should be rejected."""
        assert not is_uuid("MYPROJ")
        assert not is_uuid("myteam/MYPROJ")
        assert not is_uuid("8cee0da2-1b5b-4699-b11a")  # Too short
        assert not is_uuid("not-a-uuid")
        assert not is_uuid("")


class TestIsProjectKey:
    """Tests for project key detection."""

    def test_valid_project_keys(self):
        """Valid project keys should be recognized."""
        assert is_project_key("MYPROJ")
        assert is_project_key("API")
        assert is_project_key("BACKEND_V2")
        assert is_project_key("P1")

    def test_invalid_project_keys(self):
        """Invalid project keys should be rejected."""
        assert not is_project_key("myproj")  # Lowercase
        assert not is_project_key("my-proj")  # Hyphen
        assert not is_project_key("myteam/MYPROJ")  # Contains slash
        assert not is_project_key("")
        assert not is_project_key("1PROJ")  # Starts with number


class TestIsWorkspaceKeyFormat:
    """Tests for workspace/key shorthand detection."""

    def test_valid_shorthand(self):
        """Valid workspace/key formats should be recognized."""
        assert is_workspace_key_format("myteam/MYPROJ")
        assert is_workspace_key_format("acme-corp/API")
        assert is_workspace_key_format("team_alpha/BACKEND")

    def test_invalid_shorthand(self):
        """Invalid formats should be rejected."""
        assert not is_workspace_key_format("MYPROJ")  # No workspace
        assert not is_workspace_key_format("myteam/myproj")  # Lowercase key
        assert not is_workspace_key_format("MYTEAM/MYPROJ")  # Uppercase workspace
        assert not is_workspace_key_format("")


class TestParseProjectIdentifier:
    """Tests for the main parsing function."""

    def test_parse_uuid_with_workspace(self):
        """UUID with workspace flag should be parsed correctly."""
        result = parse_project_identifier(
            "8cee0da2-1b5b-4699-b11a-e3c8b26dd55d",
            workspace_flag="myteam"
        )
        assert result.format == IdentifierFormat.UUID
        assert result.project_uuid == "8cee0da2-1b5b-4699-b11a-e3c8b26dd55d"
        assert result.project_key is None
        assert result.workspace == "myteam"

    def test_parse_uuid_without_workspace(self):
        """UUID without workspace should still parse (validation catches it)."""
        result = parse_project_identifier("8cee0da2-1b5b-4699-b11a-e3c8b26dd55d")
        assert result.format == IdentifierFormat.UUID
        assert result.project_uuid == "8cee0da2-1b5b-4699-b11a-e3c8b26dd55d"
        assert result.workspace is None

    def test_parse_project_key_with_workspace(self):
        """Project key with workspace flag should be parsed correctly."""
        result = parse_project_identifier("MYPROJ", workspace_flag="myteam")
        assert result.format == IdentifierFormat.PROJECT_KEY
        assert result.project_uuid is None
        assert result.project_key == "MYPROJ"
        assert result.workspace == "myteam"

    def test_parse_workspace_key_shorthand(self):
        """Workspace/key shorthand should be parsed correctly."""
        result = parse_project_identifier("myteam/MYPROJ")
        assert result.format == IdentifierFormat.WORKSPACE_KEY
        assert result.project_uuid is None
        assert result.project_key == "MYPROJ"
        assert result.workspace == "myteam"

    def test_shorthand_with_conflicting_workspace_flag(self):
        """When shorthand and flag both provided, flag takes precedence."""
        result = parse_project_identifier("team1/MYPROJ", workspace_flag="team2")
        assert result.format == IdentifierFormat.WORKSPACE_KEY
        assert result.workspace == "team2"  # Flag wins

    def test_lowercase_key_is_uppercased(self):
        """Lowercase project key should be auto-uppercased."""
        result = parse_project_identifier("myproj", workspace_flag="myteam")
        assert result.project_key == "MYPROJ"

    def test_whitespace_is_trimmed(self):
        """Whitespace around identifier should be trimmed."""
        result = parse_project_identifier("  MYPROJ  ", workspace_flag="myteam")
        assert result.project_key == "MYPROJ"


class TestValidateIdentifier:
    """Tests for identifier validation."""

    def test_valid_uuid_identifier(self):
        """Valid UUID identifier should pass validation."""
        identifier = ProjectIdentifier(
            format=IdentifierFormat.UUID,
            project_uuid="8cee0da2-1b5b-4699-b11a-e3c8b26dd55d",
            project_key=None,
            workspace="myteam"
        )
        errors = validate_identifier(identifier)
        assert errors == []

    def test_uuid_missing_workspace(self):
        """UUID without workspace should fail validation."""
        identifier = ProjectIdentifier(
            format=IdentifierFormat.UUID,
            project_uuid="8cee0da2-1b5b-4699-b11a-e3c8b26dd55d",
            project_key=None,
            workspace=None
        )
        errors = validate_identifier(identifier)
        assert len(errors) == 1
        assert "workspace" in errors[0].lower()

    def test_key_missing_workspace(self):
        """Project key without workspace should fail with helpful hint."""
        identifier = ProjectIdentifier(
            format=IdentifierFormat.PROJECT_KEY,
            project_uuid=None,
            project_key="MYPROJ",
            workspace=None
        )
        errors = validate_identifier(identifier)
        assert len(errors) >= 2  # Error + hint
        assert any("workspace" in e.lower() for e in errors)
        assert any("shorthand" in e.lower() for e in errors)  # Hint about shorthand

    def test_valid_shorthand_identifier(self):
        """Valid workspace/key identifier should pass validation."""
        identifier = ProjectIdentifier(
            format=IdentifierFormat.WORKSPACE_KEY,
            project_uuid=None,
            project_key="MYPROJ",
            workspace="myteam"
        )
        errors = validate_identifier(identifier)
        assert errors == []


class TestDisplayName:
    """Tests for ProjectIdentifier.display_name property."""

    def test_uuid_display_name(self):
        """UUID display name should be truncated."""
        identifier = ProjectIdentifier(
            format=IdentifierFormat.UUID,
            project_uuid="8cee0da2-1b5b-4699-b11a-e3c8b26dd55d",
            project_key=None,
            workspace="myteam"
        )
        assert "8cee0da2" in identifier.display_name
        assert "..." in identifier.display_name

    def test_key_with_workspace_display_name(self):
        """Key with workspace should show workspace/key format."""
        identifier = ProjectIdentifier(
            format=IdentifierFormat.PROJECT_KEY,
            project_uuid=None,
            project_key="MYPROJ",
            workspace="myteam"
        )
        assert "myteam/MYPROJ" in identifier.display_name


class TestFormatIdentifierHelp:
    """Tests for help text generation."""

    def test_help_includes_all_formats(self):
        """Help text should document all three formats."""
        help_text = format_identifier_help()
        assert "UUID" in help_text
        assert "workspace" in help_text.lower()
        assert "shorthand" in help_text.lower() or "/" in help_text
