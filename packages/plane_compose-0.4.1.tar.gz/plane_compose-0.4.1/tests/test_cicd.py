"""Tests for CI/CD improvements: --exit-code flag and --resume flag."""
import json
import pytest
from pathlib import Path
from datetime import datetime, timezone

from planecompose.core.models import WorkItem, WorkItemState, SyncState
from planecompose.sync.planner import SyncPlanner, SyncPlan, SyncAction, SyncItem
from planecompose.sync.executor import SyncExecutor, SyncResult, SyncItemResult
from planecompose.parser.work_yaml import WorkItemWithMeta
from planecompose.utils.work_items import calculate_content_hash, get_tracking_key, CONTENT_HASH_VERSION


# ---------------------------------------------------------------------------
# Resume state helpers (unit tests)
# ---------------------------------------------------------------------------


class TestResumeState:
    """Tests for resume state save/load/filter/cleanup helpers."""

    def test_save_resume_state(self, tmp_path):
        """Test saving resume state writes correct JSON."""
        from planecompose.cli.push import _save_resume_state

        root = tmp_path / "project"
        root.mkdir()
        (root / ".plane").mkdir()

        # Build a fake SyncResult with failures
        result = SyncResult()
        failed_item = SyncItem(
            action=SyncAction.CREATE,
            item=WorkItem(title="Failing task", type="task"),
            tracking_key="id:fail-001",
            source_file="work/inbox.yaml",
            index=0,
            reason="new item",
        )
        result.failed.append(SyncItemResult(
            item=failed_item,
            success=False,
            error="API timeout",
        ))

        _save_resume_state(root, result)

        resume_path = root / ".plane" / "resume.json"
        assert resume_path.exists()

        data = json.loads(resume_path.read_text())
        assert "timestamp" in data
        assert data["failed_keys"] == ["id:fail-001"]
        assert data["total_attempted"] == 1
        assert data["total_failed"] == 1

    def test_save_resume_state_multiple_failures(self, tmp_path):
        """Test saving resume state with multiple failed items."""
        from planecompose.cli.push import _save_resume_state

        root = tmp_path / "project"
        root.mkdir()
        (root / ".plane").mkdir()

        result = SyncResult()
        for i in range(3):
            item = SyncItem(
                action=SyncAction.CREATE,
                item=WorkItem(title=f"Task {i}", type="task"),
                tracking_key=f"id:fail-{i:03d}",
                source_file="work/inbox.yaml",
                index=i,
                reason="new item",
            )
            result.failed.append(SyncItemResult(
                item=item, success=False, error=f"Error {i}",
            ))

        # Also add one success
        ok_item = SyncItem(
            action=SyncAction.CREATE,
            item=WorkItem(title="OK task", type="task"),
            tracking_key="id:ok-001",
            source_file="work/inbox.yaml",
            index=3,
            reason="new item",
        )
        result.created.append(SyncItemResult(
            item=ok_item, success=True, remote_id="remote-ok",
        ))

        _save_resume_state(root, result)

        data = json.loads((root / ".plane" / "resume.json").read_text())
        assert len(data["failed_keys"]) == 3
        assert data["total_attempted"] == 4
        assert data["total_failed"] == 3

    def test_load_resume_state_exists(self, tmp_path):
        """Test loading an existing resume file."""
        from planecompose.cli.push import _load_resume_state

        root = tmp_path / "project"
        (root / ".plane").mkdir(parents=True)

        resume_data = {
            "timestamp": "2024-01-15T10:30:00+00:00",
            "failed_keys": ["id:auth-task", "id:db-task"],
            "total_attempted": 10,
            "total_failed": 2,
        }
        (root / ".plane" / "resume.json").write_text(json.dumps(resume_data))

        loaded = _load_resume_state(root)
        assert loaded is not None
        assert loaded["failed_keys"] == ["id:auth-task", "id:db-task"]
        assert loaded["total_attempted"] == 10
        assert loaded["total_failed"] == 2

    def test_load_resume_state_missing(self, tmp_path):
        """Test loading when no resume file exists returns None."""
        from planecompose.cli.push import _load_resume_state

        root = tmp_path / "project"
        root.mkdir()

        result = _load_resume_state(root)
        assert result is None

    def test_load_resume_state_corrupted(self, tmp_path):
        """Test loading a corrupted resume file returns None."""
        from planecompose.cli.push import _load_resume_state

        root = tmp_path / "project"
        (root / ".plane").mkdir(parents=True)
        (root / ".plane" / "resume.json").write_text("not valid json {{{")

        result = _load_resume_state(root)
        assert result is None

    def test_filter_plan_for_resume(self):
        """Test filtering a plan to only include failed items."""
        from planecompose.cli.push import _filter_plan_for_resume

        plan = SyncPlan()

        # Add 3 creates, 2 of which are in the resume
        for i, key in enumerate(["id:pass-1", "id:fail-1", "id:fail-2"]):
            plan.creates.append(SyncItem(
                action=SyncAction.CREATE,
                item=WorkItem(title=f"Item {i}", type="task"),
                tracking_key=key,
                source_file="work/inbox.yaml",
                index=i,
                reason="new item",
            ))

        # Add 1 update that is in the resume
        plan.updates.append(SyncItem(
            action=SyncAction.UPDATE,
            item=WorkItem(title="Update item", type="task"),
            tracking_key="id:fail-3",
            source_file="work/inbox.yaml",
            index=3,
            remote_id="remote-3",
            reason="content changed",
        ))

        # Add 1 update that is NOT in the resume
        plan.updates.append(SyncItem(
            action=SyncAction.UPDATE,
            item=WorkItem(title="Update pass", type="task"),
            tracking_key="id:pass-2",
            source_file="work/inbox.yaml",
            index=4,
            remote_id="remote-4",
            reason="content changed",
        ))

        resume_data = {
            "failed_keys": ["id:fail-1", "id:fail-2", "id:fail-3"],
        }

        filtered = _filter_plan_for_resume(plan, resume_data)

        assert len(filtered.creates) == 2
        assert filtered.creates[0].tracking_key == "id:fail-1"
        assert filtered.creates[1].tracking_key == "id:fail-2"
        assert len(filtered.updates) == 1
        assert filtered.updates[0].tracking_key == "id:fail-3"
        assert len(filtered.deletes) == 0

    def test_filter_plan_for_resume_empty_result(self):
        """Test filtering when no items match the resume keys."""
        from planecompose.cli.push import _filter_plan_for_resume

        plan = SyncPlan()
        plan.creates.append(SyncItem(
            action=SyncAction.CREATE,
            item=WorkItem(title="Item", type="task"),
            tracking_key="id:different",
            source_file="work/inbox.yaml",
            index=0,
            reason="new item",
        ))

        resume_data = {"failed_keys": ["id:not-in-plan"]}

        filtered = _filter_plan_for_resume(plan, resume_data)
        assert filtered.is_empty

    def test_cleanup_resume_state(self, tmp_path):
        """Test cleanup deletes the resume file."""
        from planecompose.cli.push import _cleanup_resume_state

        root = tmp_path / "project"
        (root / ".plane").mkdir(parents=True)
        resume_path = root / ".plane" / "resume.json"
        resume_path.write_text('{"failed_keys": []}')

        assert resume_path.exists()
        _cleanup_resume_state(root)
        assert not resume_path.exists()

    def test_cleanup_resume_state_no_file(self, tmp_path):
        """Test cleanup is a no-op when no resume file exists."""
        from planecompose.cli.push import _cleanup_resume_state

        root = tmp_path / "project"
        root.mkdir()

        # Should not raise
        _cleanup_resume_state(root)


# ---------------------------------------------------------------------------
# Exit code tests (unit-level, testing the SyncResult logic)
# ---------------------------------------------------------------------------


class TestExitCodeLogic:
    """Tests for the exit code differentiation logic.

    These test the conditions that determine exit codes in _push(),
    without running the full CLI stack.
    """

    def test_no_changes_result(self):
        """Empty result means no changes applied (exit 0 path)."""
        result = SyncResult()
        changes_applied = (result.created_count + result.updated_count + result.deleted_count) > 0
        assert not changes_applied
        assert result.failed_count == 0

    def test_changes_applied_result(self):
        """Result with creates means changes were applied (exit 2 path)."""
        result = SyncResult()
        result.created.append(SyncItemResult(
            item=SyncItem(SyncAction.CREATE, WorkItem(title="T", type="task"), "k", "f", 0),
            success=True,
            remote_id="r1",
        ))
        changes_applied = (result.created_count + result.updated_count + result.deleted_count) > 0
        assert changes_applied
        assert result.failed_count == 0

    def test_failures_result(self):
        """Result with failures means error (exit 1 path)."""
        result = SyncResult()
        result.failed.append(SyncItemResult(
            item=SyncItem(SyncAction.CREATE, WorkItem(title="T", type="task"), "k", "f", 0),
            success=False,
            error="fail",
        ))
        assert result.failed_count > 0

    def test_mixed_success_and_failure(self):
        """Result with both successes and failures still has failures (exit 1 path)."""
        result = SyncResult()
        result.created.append(SyncItemResult(
            item=SyncItem(SyncAction.CREATE, WorkItem(title="OK", type="task"), "k1", "f", 0),
            success=True,
            remote_id="r1",
        ))
        result.failed.append(SyncItemResult(
            item=SyncItem(SyncAction.CREATE, WorkItem(title="Fail", type="task"), "k2", "f", 1),
            success=False,
            error="fail",
        ))
        changes_applied = (result.created_count + result.updated_count + result.deleted_count) > 0
        assert changes_applied
        assert result.failed_count > 0
        # exit 1 takes precedence over exit 2

    def test_plan_is_empty_means_no_changes(self):
        """An empty plan means no changes needed (exit 0 path)."""
        plan = SyncPlan()
        assert plan.is_empty

    def test_dry_run_with_changes_detected(self):
        """A non-empty plan in dry-run means changes detected (exit 2 path with --exit-code)."""
        plan = SyncPlan()
        plan.creates.append(SyncItem(
            action=SyncAction.CREATE,
            item=WorkItem(title="New", type="task"),
            tracking_key="id:new",
            source_file="work/inbox.yaml",
            index=0,
            reason="new item",
        ))
        assert not plan.is_empty
        assert plan.total_changes == 1


# ---------------------------------------------------------------------------
# Integration: resume with executor
# ---------------------------------------------------------------------------


class TestResumeIntegration:
    """Integration tests for resume with the executor."""

    @pytest.mark.asyncio
    async def test_executor_result_produces_valid_resume(self, mock_backend, sample_work_items):
        """Test that a partial failure produces resume data that can be loaded."""
        from planecompose.cli.push import _save_resume_state, _load_resume_state, _filter_plan_for_resume
        from planecompose.core.models import ProjectConfig
        import tempfile

        config = ProjectConfig(workspace="test", project_key="TEST")
        await mock_backend.connect(config, "test-key")

        # Make backend fail on the second item
        original_create = mock_backend.create_work_item
        call_count = 0

        async def failing_create(work_item):
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                raise RuntimeError("Simulated API error")
            return await original_create(work_item)

        mock_backend.create_work_item = failing_create

        # Create plan
        plan = SyncPlan()
        for i, item in enumerate(sample_work_items):
            plan.creates.append(SyncItem(
                action=SyncAction.CREATE,
                item=item,
                tracking_key=item.id or f"pos:work/inbox.yaml:{i}",
                source_file="work/inbox.yaml",
                index=i,
                reason="new item",
            ))

        # Execute (one item will fail)
        executor = SyncExecutor(mock_backend, state_manager=None, batch_size=1)
        result = await executor.execute(plan)

        assert result.created_count == 2
        assert result.failed_count == 1

        # Save resume state
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            (root / ".plane").mkdir()

            _save_resume_state(root, result)

            # Load it back
            resume_data = _load_resume_state(root)
            assert resume_data is not None
            assert len(resume_data["failed_keys"]) == 1
            assert resume_data["total_failed"] == 1

            # Filter a new plan to only include the failed item
            new_plan = SyncPlan()
            for i, item in enumerate(sample_work_items):
                new_plan.creates.append(SyncItem(
                    action=SyncAction.CREATE,
                    item=item,
                    tracking_key=item.id or f"pos:work/inbox.yaml:{i}",
                    source_file="work/inbox.yaml",
                    index=i,
                    reason="new item",
                ))

            filtered = _filter_plan_for_resume(new_plan, resume_data)
            assert filtered.total_changes == 1
            # The filtered plan contains only the item that failed
            assert filtered.creates[0].tracking_key == resume_data["failed_keys"][0]
