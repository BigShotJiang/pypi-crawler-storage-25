"""Tests for SchemaCache — O(1) lookups, invalidation, edge cases."""
import pytest

from planecompose.backend.cache import SchemaCache
from planecompose.core.models import (
    WorkItemTypeDefinition,
    StateDefinition,
    LabelDefinition,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_types():
    return [
        WorkItemTypeDefinition(name="Task", workflow="default", remote_id="type-1"),
        WorkItemTypeDefinition(name="Bug", workflow="default", remote_id="type-2"),
        WorkItemTypeDefinition(name="Epic", workflow="default", remote_id="type-3"),
    ]


def make_states():
    return [
        StateDefinition(name="backlog", group="unstarted", remote_id="state-1"),
        StateDefinition(name="in_progress", group="started", remote_id="state-2"),
        StateDefinition(name="done", group="completed", remote_id="state-3"),
    ]


def make_labels():
    return [
        LabelDefinition(name="frontend", color="#3b82f6", remote_id="label-1"),
        LabelDefinition(name="backend", color="#22c55e", remote_id="label-2"),
    ]


async def fetch_types():
    return make_types()


async def fetch_states():
    return make_states()


async def fetch_labels():
    return make_labels()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestSchemaCacheLoad:
    """Test loading and basic state."""

    @pytest.mark.asyncio
    async def test_not_loaded_initially(self):
        cache = SchemaCache()
        assert cache.is_loaded is False

    @pytest.mark.asyncio
    async def test_load_populates_cache(self):
        cache = SchemaCache()
        await cache.load(fetch_types, fetch_states, fetch_labels)
        assert cache.is_loaded is True
        assert len(cache.types) == 3
        assert len(cache.states) == 3
        assert len(cache.labels) == 2

    @pytest.mark.asyncio
    async def test_load_is_idempotent(self):
        cache = SchemaCache()
        await cache.load(fetch_types, fetch_states, fetch_labels)
        # Second load should be a no-op (already loaded)
        await cache.load(fetch_types, fetch_states, fetch_labels)
        assert len(cache.types) == 3

    @pytest.mark.asyncio
    async def test_accessing_types_before_load_raises(self):
        cache = SchemaCache()
        with pytest.raises(RuntimeError, match="not loaded"):
            _ = cache.types

    @pytest.mark.asyncio
    async def test_accessing_states_before_load_raises(self):
        cache = SchemaCache()
        with pytest.raises(RuntimeError, match="not loaded"):
            _ = cache.states

    @pytest.mark.asyncio
    async def test_accessing_labels_before_load_raises(self):
        cache = SchemaCache()
        with pytest.raises(RuntimeError, match="not loaded"):
            _ = cache.labels


class TestSchemaCacheLookups:
    """Test O(1) name ↔ ID lookups."""

    @pytest.fixture(autouse=True)
    async def setup_cache(self):
        self.cache = SchemaCache()
        await self.cache.load(fetch_types, fetch_states, fetch_labels)

    def test_get_type_id(self):
        assert self.cache.get_type_id("task") == "type-1"
        assert self.cache.get_type_id("bug") == "type-2"
        assert self.cache.get_type_id("epic") == "type-3"

    def test_get_type_id_case_insensitive(self):
        assert self.cache.get_type_id("Task") == "type-1"
        assert self.cache.get_type_id("TASK") == "type-1"
        assert self.cache.get_type_id("BUG") == "type-2"

    def test_get_type_id_missing(self):
        assert self.cache.get_type_id("nonexistent") is None

    def test_get_state_id(self):
        assert self.cache.get_state_id("backlog") == "state-1"
        assert self.cache.get_state_id("in_progress") == "state-2"
        assert self.cache.get_state_id("done") == "state-3"

    def test_get_state_id_missing(self):
        assert self.cache.get_state_id("unknown") is None

    def test_get_label_id(self):
        assert self.cache.get_label_id("frontend") == "label-1"
        assert self.cache.get_label_id("backend") == "label-2"

    def test_get_label_id_missing(self):
        assert self.cache.get_label_id("unknown") is None

    def test_get_label_ids(self):
        result = self.cache.get_label_ids(["frontend", "backend", "nonexistent"])
        assert result == ["label-1", "label-2"]

    def test_get_label_ids_empty(self):
        assert self.cache.get_label_ids([]) == []

    # Reverse lookups
    def test_get_type_name(self):
        assert self.cache.get_type_name("type-1") == "Task"
        assert self.cache.get_type_name("type-2") == "Bug"

    def test_get_type_name_missing(self):
        assert self.cache.get_type_name("nonexistent") is None

    def test_get_state_name(self):
        assert self.cache.get_state_name("state-1") == "backlog"

    def test_get_label_name(self):
        assert self.cache.get_label_name("label-1") == "frontend"

    def test_get_label_names(self):
        result = self.cache.get_label_names(["label-1", "label-2", "bad-id"])
        assert result == ["frontend", "backend"]

    # Existence checks
    def test_has_type(self):
        assert self.cache.has_type("task") is True
        assert self.cache.has_type("Task") is True
        assert self.cache.has_type("TASK") is True
        assert self.cache.has_type("nonexistent") is False

    def test_has_state(self):
        assert self.cache.has_state("backlog") is True
        assert self.cache.has_state("nonexistent") is False

    def test_has_label(self):
        assert self.cache.has_label("frontend") is True
        assert self.cache.has_label("nonexistent") is False


class TestSchemaCacheInvalidation:
    """Test cache invalidation."""

    @pytest.fixture(autouse=True)
    async def setup_cache(self):
        self.cache = SchemaCache()
        await self.cache.load(fetch_types, fetch_states, fetch_labels)

    def test_invalidate_clears_all(self):
        self.cache.invalidate()
        assert self.cache.is_loaded is False
        assert self.cache.get_type_id("task") is None
        assert self.cache.get_state_id("backlog") is None
        assert self.cache.get_label_id("frontend") is None

    def test_invalidate_types_only(self):
        self.cache.invalidate_types()
        assert self.cache.is_loaded is False  # types is None
        assert self.cache.get_type_id("task") is None
        # States and labels still work
        assert self.cache.get_state_id("backlog") == "state-1"
        assert self.cache.get_label_id("frontend") == "label-1"

    def test_invalidate_states_only(self):
        self.cache.invalidate_states()
        assert self.cache.get_state_id("backlog") is None
        assert self.cache.get_type_id("task") == "type-1"

    def test_invalidate_labels_only(self):
        self.cache.invalidate_labels()
        assert self.cache.get_label_id("frontend") is None
        assert self.cache.get_type_id("task") == "type-1"

    @pytest.mark.asyncio
    async def test_reload_after_invalidate(self):
        self.cache.invalidate()
        await self.cache.load(fetch_types, fetch_states, fetch_labels)
        assert self.cache.is_loaded is True
        assert self.cache.get_type_id("task") == "type-1"


class TestSchemaCacheUnloaded:
    """Test lookups on unloaded cache return None (not crash)."""

    def test_get_type_id_unloaded(self):
        cache = SchemaCache()
        assert cache.get_type_id("task") is None

    def test_get_state_id_unloaded(self):
        cache = SchemaCache()
        assert cache.get_state_id("backlog") is None

    def test_get_label_id_unloaded(self):
        cache = SchemaCache()
        assert cache.get_label_id("frontend") is None

    def test_has_type_unloaded(self):
        cache = SchemaCache()
        assert cache.has_type("task") is False

    def test_has_state_unloaded(self):
        cache = SchemaCache()
        assert cache.has_state("backlog") is False

    def test_has_label_unloaded(self):
        cache = SchemaCache()
        assert cache.has_label("frontend") is False

    def test_get_label_ids_unloaded(self):
        cache = SchemaCache()
        assert cache.get_label_ids(["frontend"]) == []

    def test_get_label_names_unloaded(self):
        cache = SchemaCache()
        assert cache.get_label_names(["label-1"]) == []
