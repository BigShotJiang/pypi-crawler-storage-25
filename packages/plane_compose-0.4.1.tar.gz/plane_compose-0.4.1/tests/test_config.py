"""Tests for Settings, env var overrides, and singleton pattern."""
import pytest

from planecompose.config.settings import Settings, get_settings, reset_settings


class TestSettingsDefaults:
    """Test default setting values."""

    def test_default_api_url(self):
        s = Settings()
        assert s.plane_api_url == "https://api.plane.so"

    def test_default_api_version(self):
        s = Settings()
        assert s.plane_api_version == "v1"

    def test_default_timeout(self):
        s = Settings()
        assert s.plane_api_timeout == 30

    def test_default_retry_attempts(self):
        s = Settings()
        assert s.plane_api_retry_attempts == 3

    def test_default_rate_limit(self):
        s = Settings()
        assert s.rate_limit_per_minute == 50
        assert s.rate_limit_per_hour == 3000

    def test_default_debug_off(self):
        s = Settings()
        assert s.debug is False
        assert s.verbose is False

    def test_default_rich_output_on(self):
        s = Settings()
        assert s.use_rich_output is True
        assert s.show_progress_bars is True

    def test_full_api_url(self):
        s = Settings()
        assert s.full_api_url == "https://api.plane.so/api/v1"

    def test_credentials_file_computed(self):
        s = Settings()
        assert s.credentials_file is not None
        assert str(s.credentials_file).endswith("credentials")


class TestSettingsEnvOverrides:
    """Test that environment variables override defaults."""

    def test_api_url_override(self, monkeypatch):
        monkeypatch.setenv("PLANE_PLANE_API_URL", "http://localhost:8000")
        reset_settings()
        s = Settings()
        assert s.plane_api_url == "http://localhost:8000"

    def test_rate_limit_override(self, monkeypatch):
        monkeypatch.setenv("PLANE_RATE_LIMIT_PER_MINUTE", "100")
        reset_settings()
        s = Settings()
        assert s.rate_limit_per_minute == 100

    def test_debug_override(self, monkeypatch):
        monkeypatch.setenv("PLANE_DEBUG", "true")
        reset_settings()
        s = Settings()
        assert s.debug is True

    def test_timeout_override(self, monkeypatch):
        monkeypatch.setenv("PLANE_PLANE_API_TIMEOUT", "60")
        reset_settings()
        s = Settings()
        assert s.plane_api_timeout == 60


class TestSettingsSingleton:
    """Test get_settings/reset_settings singleton pattern."""

    def setup_method(self):
        reset_settings()

    def teardown_method(self):
        reset_settings()

    def test_get_settings_returns_same_instance(self):
        s1 = get_settings()
        s2 = get_settings()
        assert s1 is s2

    def test_reset_settings_creates_new_instance(self):
        s1 = get_settings()
        reset_settings()
        s2 = get_settings()
        assert s1 is not s2

    def test_get_settings_returns_settings_type(self):
        s = get_settings()
        assert isinstance(s, Settings)
