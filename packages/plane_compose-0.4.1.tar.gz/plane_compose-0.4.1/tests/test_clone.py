"""Tests for clone command — identifier parsing, directory logic, state population."""
import json
import pytest

from planecompose.cli.clone_helpers import build_clone_state
from planecompose.utils.identifiers import (
    parse_project_identifier,
    validate_identifier,
    IdentifierFormat,
)


# ---------------------------------------------------------------------------
# Identifier Parsing
# ---------------------------------------------------------------------------

class TestIdentifierParsing:
    """Test parse_project_identifier handles all formats."""

    def test_uuid_format(self):
        ident = parse_project_identifier(
            "8cee0da2-1b5b-4699-b11a-e3c8b26dd55d",
            workspace_flag="myteam",
        )
        assert ident.format == IdentifierFormat.UUID
        assert ident.project_uuid == "8cee0da2-1b5b-4699-b11a-e3c8b26dd55d"
        assert ident.workspace == "myteam"

    def test_project_key_format(self):
        ident = parse_project_identifier("MYPROJ", workspace_flag="myteam")
        assert ident.format == IdentifierFormat.PROJECT_KEY
        assert ident.project_key == "MYPROJ"
        assert ident.workspace == "myteam"

    def test_workspace_key_format(self):
        ident = parse_project_identifier("myteam/MYPROJ")
        assert ident.format == IdentifierFormat.WORKSPACE_KEY
        assert ident.workspace == "myteam"
        assert ident.project_key == "MYPROJ"

    def test_uuid_without_workspace_fails_validation(self):
        ident = parse_project_identifier(
            "8cee0da2-1b5b-4699-b11a-e3c8b26dd55d",
            workspace_flag=None,
        )
        errors = validate_identifier(ident)
        assert len(errors) > 0

    def test_project_key_without_workspace_fails_validation(self):
        ident = parse_project_identifier("MYPROJ", workspace_flag=None)
        errors = validate_identifier(ident)
        assert len(errors) > 0

    def test_workspace_key_needs_no_extra_workspace(self):
        ident = parse_project_identifier("team/PROJ")
        errors = validate_identifier(ident)
        assert len(errors) == 0


class TestIdentifierValidation:
    """Test validate_identifier catches errors."""

    def test_valid_uuid_passes(self):
        ident = parse_project_identifier(
            "8cee0da2-1b5b-4699-b11a-e3c8b26dd55d",
            workspace_flag="myteam",
        )
        assert validate_identifier(ident) == []

    def test_valid_shorthand_passes(self):
        ident = parse_project_identifier("myteam/PROJ")
        assert validate_identifier(ident) == []


# ---------------------------------------------------------------------------
# Clone State Population
# ---------------------------------------------------------------------------

class TestCloneStatePopulation:
    """Test that clone populates state.json correctly."""

    def test_state_json_keeps_schema_mappings_but_not_remote_snapshot_items(self, tmp_path):
        """Clone state should track schema mappings, not read-only remote snapshot items."""
        from datetime import datetime, timezone

        types_data = [
            {"id": "type-1", "name": "Task"},
            {"id": "type-2", "name": "Bug"},
        ]

        class FakeState:
            def __init__(self, id_val, name):
                self.id = id_val
                self.name = name

        class FakeLabel:
            def __init__(self, id_val, name):
                self.id = id_val
                self.name = name

        now_iso = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        state_json = build_clone_state(
            types_data=types_data,
            states_list=[FakeState("state-1", "backlog"), FakeState("state-2", "in_progress")],
            labels_list=[FakeLabel("label-1", "frontend")],
            last_sync=now_iso,
        )

        # Write and verify
        state_file = tmp_path / "state.json"
        with open(state_file, 'w') as f:
            json.dump(state_json, f, indent=2)

        # Load and verify
        loaded = json.loads(state_file.read_text())
        assert loaded["last_sync"] == now_iso
        assert loaded["work_items"] == {}
        assert loaded["types"]["Task"] == "type-1"
        assert loaded["states"]["backlog"] == "state-1"
        assert loaded["labels"]["frontend"] == "label-1"

    def test_empty_clone_produces_empty_work_items(self, tmp_path):
        """If no work items are cloned, state still has structure."""
        state_json = {
            "last_sync": "2024-01-01T00:00:00Z",
            "types": {},
            "states": {},
            "labels": {},
            "work_items": {},
        }

        state_file = tmp_path / "state.json"
        with open(state_file, 'w') as f:
            json.dump(state_json, f, indent=2)

        loaded = json.loads(state_file.read_text())
        assert loaded["work_items"] == {}


# ---------------------------------------------------------------------------
# Directory Creation Logic
# ---------------------------------------------------------------------------

class TestCloneDirectoryCreation:
    """Test directory structure created by clone."""

    def test_clone_creates_all_dirs(self, tmp_path):
        target = tmp_path / "myproject"
        target.mkdir()
        (target / "schema").mkdir()
        (target / "work").mkdir()
        (target / ".plane" / "remote").mkdir(parents=True)

        assert target.exists()
        assert (target / "schema").is_dir()
        assert (target / "work").is_dir()
        assert (target / ".plane" / "remote").is_dir()

    def test_clone_gitignore(self, tmp_path):
        target = tmp_path / "myproject"
        target.mkdir()
        (target / ".gitignore").write_text(".plane/\n")

        assert (target / ".gitignore").read_text() == ".plane/\n"
