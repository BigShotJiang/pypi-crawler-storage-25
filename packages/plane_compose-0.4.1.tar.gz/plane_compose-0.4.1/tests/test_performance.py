"""Performance tests for planecompose.

These tests verify that performance optimizations are working correctly.
"""
import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

from planecompose.core.models import (
    WorkItem,
    WorkItemTypeDefinition,
    StateDefinition,
    LabelDefinition,
    ProjectConfig,
)


class TestBackendCaching:
    """Tests for backend caching optimizations."""

    @pytest.mark.asyncio
    async def test_caches_types_states_labels(self):
        """Test that types, states, labels are fetched once and cached."""
        from planecompose.backend.plane import PlaneBackend

        backend = PlaneBackend()

        # Track API call counts
        fetch_counts = {'types': 0, 'states': 0, 'labels': 0}

        async def mock_fetch_types():
            fetch_counts['types'] += 1
            return [WorkItemTypeDefinition(name="task", workflow="standard", remote_id="type-123")]

        async def mock_fetch_states():
            fetch_counts['states'] += 1
            return [StateDefinition(name="backlog", group="unstarted", remote_id="state-123")]

        async def mock_fetch_labels():
            fetch_counts['labels'] += 1
            return [LabelDefinition(name="frontend", remote_id="label-123")]

        # Load cache with mocked fetch functions
        await backend._cache.load(mock_fetch_types, mock_fetch_states, mock_fetch_labels)

        # First call should have fetched from API
        assert fetch_counts['types'] == 1
        assert fetch_counts['states'] == 1
        assert fetch_counts['labels'] == 1

        # Access data (should use cache, not refetch)
        types1 = backend._cache.types
        states1 = backend._cache.states
        labels1 = backend._cache.labels

        # API should NOT have been called again
        assert fetch_counts['types'] == 1
        assert fetch_counts['states'] == 1
        assert fetch_counts['labels'] == 1

        # Verify data was cached
        assert len(types1) == 1
        assert len(states1) == 1
        assert len(labels1) == 1

    @pytest.mark.asyncio
    async def test_lookup_maps_are_built(self):
        """Test that O(1) lookup maps are built correctly."""
        from planecompose.backend.plane import PlaneBackend

        backend = PlaneBackend()

        async def mock_fetch_types():
            return [WorkItemTypeDefinition(name="task", workflow="standard", remote_id="type-123")]

        async def mock_fetch_states():
            return [StateDefinition(name="backlog", group="unstarted", remote_id="state-456")]

        async def mock_fetch_labels():
            return [LabelDefinition(name="frontend", remote_id="label-789")]

        # Load cache
        await backend._cache.load(mock_fetch_types, mock_fetch_states, mock_fetch_labels)

        # Verify O(1) lookups work via cache
        assert backend._cache.get_type_id("task") == "type-123"
        assert backend._cache.get_state_id("backlog") == "state-456"
        assert backend._cache.get_label_id("frontend") == "label-789"

        # Verify reverse lookups work
        assert backend._cache.get_type_name("type-123") == "task"
        assert backend._cache.get_state_name("state-456") == "backlog"
        assert backend._cache.get_label_name("label-789") == "frontend"

    @pytest.mark.asyncio
    async def test_cache_invalidation_on_create(self):
        """Test that caches are invalidated when new items are created."""
        from planecompose.backend.plane import PlaneBackend

        backend = PlaneBackend()

        async def mock_fetch_types():
            return [WorkItemTypeDefinition(name="task", workflow="standard", remote_id="type-123")]

        async def mock_fetch_states():
            return [StateDefinition(name="backlog", group="unstarted", remote_id="state-123")]

        async def mock_fetch_labels():
            return [LabelDefinition(name="frontend", remote_id="label-123")]

        # Load cache
        await backend._cache.load(mock_fetch_types, mock_fetch_states, mock_fetch_labels)
        assert backend._cache.is_loaded

        # Simulate invalidation (as would happen when creating new types)
        backend._cache.invalidate_types()

        # Types cache should be invalidated but states/labels preserved
        assert backend._cache.get_type_id("task") is None  # Invalidated
        assert backend._cache.get_state_id("backlog") == "state-123"  # Preserved


class TestWorkItemCreationPerformance:
    """Tests for work item creation performance."""

    @pytest.mark.asyncio
    async def test_create_multiple_items_uses_cache(self):
        """
        Test that creating multiple work items uses cached lookups.

        BEFORE: 100 items = 400 API calls (1 create + 3 lookups each)
        AFTER: 100 items = 103 API calls (3 lookups + 100 creates)
        """
        from planecompose.backend.plane import PlaneBackend
        from planecompose.backend.client import PlaneApiClient

        backend = PlaneBackend()

        # Pre-populate cache directly
        async def mock_fetch_types():
            return [WorkItemTypeDefinition(name="task", workflow="standard", remote_id="type-123")]

        async def mock_fetch_states():
            return [StateDefinition(name="backlog", group="unstarted", remote_id="state-456")]

        async def mock_fetch_labels():
            return [LabelDefinition(name="frontend", remote_id="label-789")]

        await backend._cache.load(mock_fetch_types, mock_fetch_states, mock_fetch_labels)

        # Track create calls
        create_call_count = 0

        async def mock_create(*args, **kwargs):
            nonlocal create_call_count
            create_call_count += 1
            mock_response = MagicMock()
            mock_response.id = f"work-item-{create_call_count:03d}"
            return mock_response

        # Create a mock PlaneApiClient
        mock_api_client = MagicMock(spec=PlaneApiClient)
        mock_api_client.call = mock_create
        backend._client = mock_api_client
        backend._config = ProjectConfig(workspace="test", project_key="TEST")

        # Create work items
        items = [
            WorkItem(title=f"Task {i}", type="task", state="backlog", labels=["frontend"])
            for i in range(10)
        ]

        for item in items:
            await backend.create_work_item(item)

        # Verify: Only create calls were made (cache was used for lookups)
        assert create_call_count == 10


class TestHTTPClientPerformance:
    """Tests for HTTP client performance."""
    
    def test_client_initialization(self):
        """Test that HTTP client initializes correctly."""
        from planecompose.utils.http_client import RateLimitedHTTPClient
        
        client = RateLimitedHTTPClient(api_key="test-key")
        
        # Verify essential attributes are set
        assert client.api_key == "test-key"
        assert client.base_url == "https://api.plane.so"
        assert client._rate_limiter is not None
    
    @pytest.mark.asyncio
    async def test_shared_rate_limiter(self):
        """Test that HTTP clients share the same rate limiter."""
        from planecompose.utils.http_client import RateLimitedHTTPClient
        
        client1 = RateLimitedHTTPClient(api_key="test-key")
        client2 = RateLimitedHTTPClient(api_key="test-key")
        
        # Both should use the same shared rate limiter
        assert client1._rate_limiter is client2._rate_limiter
    
    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        """Test that HTTP client works as async context manager."""
        from planecompose.utils.http_client import RateLimitedHTTPClient
        
        async with RateLimitedHTTPClient(api_key="test-key") as client:
            assert client is not None
            assert client.api_key == "test-key"


class TestImportPerformance:
    """Tests for import/startup performance."""
    
    def test_lazy_imports(self):
        """Test that heavy imports are done lazily where possible."""
        import time
        
        start = time.perf_counter()
        
        # Import the main module
        from planecompose.main import app
        
        elapsed = time.perf_counter() - start
        
        # Should import quickly (under 1 second on most systems)
        # This is a sanity check, not a strict requirement
        assert elapsed < 2.0, f"Import took {elapsed:.2f}s, which is too slow"
    
    def test_cli_help_fast(self):
        """Test that CLI help is fast (no heavy initialization)."""
        import time
        from typer.testing import CliRunner
        from planecompose.main import app
        
        runner = CliRunner()
        
        start = time.perf_counter()
        result = runner.invoke(app, ["--help"])
        elapsed = time.perf_counter() - start
        
        assert result.exit_code == 0
        # Help should be nearly instant
        assert elapsed < 1.0, f"Help took {elapsed:.2f}s, which is too slow"

