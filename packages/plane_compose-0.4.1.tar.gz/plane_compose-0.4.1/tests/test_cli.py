"""Tests for CLI commands."""
import json
import pytest
from unittest.mock import AsyncMock, patch
from typer.testing import CliRunner

from planecompose.main import app
from planecompose import __version__


runner = CliRunner(env={"NO_COLOR": "1"})


class TestCLIRoot:
    """Tests for root CLI commands."""
    
    def test_help(self):
        """Test --help flag."""
        result = runner.invoke(app, ["--help"])
        
        assert result.exit_code == 0
        assert "Plane CLI" in result.stdout
        assert "init" in result.stdout
        assert "push" in result.stdout
        assert "pull" in result.stdout
    
    def test_version(self):
        """Test --version flag."""
        result = runner.invoke(app, ["--version"])
        
        assert result.exit_code == 0
        assert __version__ in result.stdout
    
    def test_version_short(self):
        """Test -V short flag."""
        result = runner.invoke(app, ["-V"])
        
        assert result.exit_code == 0
        assert __version__ in result.stdout
    
    def test_no_args_shows_help(self):
        """Test that no arguments shows help."""
        result = runner.invoke(app, [])
        
        # Exit code 2 is standard for typer when showing help due to missing args
        assert result.exit_code in [0, 2]
        assert "Usage:" in result.stdout

    def test_sync_alias_registered(self):
        """Test the sync alias is registered (hidden) and shows help."""
        result = runner.invoke(app, ["sync", "--help"])

        assert result.exit_code == 0
        assert "Push schema and work items" in result.stdout


class TestInitCommand:
    """Tests for init command."""
    
    def test_init_help(self):
        """Test init --help."""
        result = runner.invoke(app, ["init", "--help"])
        
        assert result.exit_code == 0
        assert "Initialize" in result.stdout
    
    def test_init_creates_structure(self, tmp_path, monkeypatch):
        """Test that init creates proper directory structure."""
        # Change to temp directory
        monkeypatch.chdir(tmp_path)

        # Mock resolve_workspace so the test doesn't need real auth config
        with patch(
            "planecompose.cli.init.resolve_workspace",
            return_value=("test", "conn-1", "https://api.plane.so", "fake-key"),
        ):
            result = runner.invoke(
                app,
                ["init", "MYPROJ", "--workspace", "test"],
            )

        assert result.exit_code == 0

        # Directory is created from project key (lowercase)
        project_path = tmp_path / "myproj"
        assert project_path.exists()
        assert (project_path / "plane.yaml").exists()
        assert (project_path / "schema").is_dir()
        assert (project_path / "schema" / "types.yaml").exists()
        assert (project_path / "schema" / "workflows.yaml").exists()
        assert (project_path / "schema" / "labels.yaml").exists()
        assert (project_path / "work").is_dir()
        assert (project_path / ".plane").is_dir()


class TestAuthCommands:
    """Tests for auth commands."""
    
    def test_auth_help(self):
        """Test auth --help."""
        result = runner.invoke(app, ["auth", "--help"])
        
        assert result.exit_code == 0
        assert "login" in result.stdout
        assert "logout" in result.stdout
        assert "list-connections" in result.stdout
    
    def test_auth_login_help(self):
        """Test auth login --help."""
        result = runner.invoke(app, ["auth", "login", "--help"])
        
        assert result.exit_code == 0
        assert "API key" in result.stdout


class TestSchemaCommands:
    """Tests for schema commands."""
    
    def test_schema_help(self):
        """Test schema --help."""
        result = runner.invoke(app, ["schema", "--help"])
        
        assert result.exit_code == 0
        assert "validate" in result.stdout
        assert "push" in result.stdout
    
    def test_schema_validate_no_project(self, tmp_path, monkeypatch):
        """Test schema validate outside a project."""
        monkeypatch.chdir(tmp_path)
        
        result = runner.invoke(app, ["schema", "validate"])
        
        assert result.exit_code == 1
        assert "plane init" in result.stdout or "Error" in result.stdout

    def test_schema_validate_offline_without_auth(self, temp_project, tmp_path, monkeypatch):
        """Offline schema validation should not require stored credentials."""
        from planecompose.cli import auth as auth_cmd

        missing_config = tmp_path / "missing-config.json"
        missing_token = tmp_path / "missing-credentials"
        monkeypatch.setattr(auth_cmd, "_get_config_file", lambda: missing_config)
        monkeypatch.setattr(auth_cmd, "_get_token_file", lambda: missing_token)
        monkeypatch.chdir(temp_project)

        result = runner.invoke(app, ["schema", "validate"])

        assert result.exit_code == 0


class TestPushCommand:
    """Tests for push command."""
    
    def test_push_help(self):
        """Test push --help."""
        result = runner.invoke(app, ["push", "--help"])
        
        assert result.exit_code == 0
        assert "--dry-run" in result.stdout
        assert "--force" in result.stdout
    
    def test_push_no_project(self, tmp_path, monkeypatch):
        """Test push outside a project."""
        monkeypatch.chdir(tmp_path)
        
        result = runner.invoke(app, ["push"])
        
        assert result.exit_code == 1


class TestPullCommand:
    """Tests for pull command."""
    
    def test_pull_help(self):
        """Test pull --help."""
        result = runner.invoke(app, ["pull", "--help"])

        assert result.exit_code == 0
        assert "--merge" in result.stdout
        assert "work/workitems.yaml" in result.stdout


class TestStatusCommand:
    """Tests for status command."""
    
    def test_status_help(self):
        """Test status --help."""
        result = runner.invoke(app, ["status", "--help"])
        
        assert result.exit_code == 0

    def test_status_without_auth(self, temp_project, tmp_path, monkeypatch):
        """Status should work without stored credentials."""
        from planecompose.cli import auth as auth_cmd

        missing_config = tmp_path / "missing-config.json"
        missing_token = tmp_path / "missing-credentials"
        monkeypatch.setattr(auth_cmd, "_get_config_file", lambda: missing_config)
        monkeypatch.setattr(auth_cmd, "_get_token_file", lambda: missing_token)
        monkeypatch.chdir(temp_project)

        result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "Project Info" in result.stdout


class TestRateStatsCommands:
    """Tests for rate stats commands."""

    def test_rate_help(self):
        """Test rate --help."""
        result = runner.invoke(app, ["rate", "--help"])

        assert result.exit_code == 0
        assert "stats" in result.stdout
        assert "reset" in result.stdout

    def test_rate_stats(self):
        """Test rate stats command."""
        result = runner.invoke(app, ["rate", "stats"])

        assert result.exit_code == 0
        assert "Rate Limit" in result.stdout

    def test_rate_reset(self):
        """Test rate reset command."""
        result = runner.invoke(app, ["rate", "reset"])

        assert result.exit_code == 0
        assert "reset" in result.stdout.lower()


class TestStateCommands:
    """Tests for state commands."""

    def test_state_help(self):
        """Test state --help."""
        result = runner.invoke(app, ["state", "--help"])
        assert result.exit_code == 0

    def test_state_show_no_project(self, tmp_path, monkeypatch):
        """Test state show outside a project."""
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["state", "show"])
        # May exit 0 or 1 depending on whether state command requires a project
        assert result.exit_code in (0, 1)

    def test_state_show_with_project(self, tmp_path, monkeypatch):
        """Test state show in a valid project."""
        import json
        project_path = tmp_path / "proj"
        project_path.mkdir()
        (project_path / "schema").mkdir()
        (project_path / "work").mkdir()
        (project_path / ".plane").mkdir()
        (project_path / "plane.yaml").write_text(
            "workspace: test\nproject:\n  key: TEST\n  name: Test\ndefaults:\n  type: task\n  workflow: default\n"
        )
        (project_path / "schema" / "types.yaml").write_text("task:\n  workflow: default\n")
        (project_path / "schema" / "workflows.yaml").write_text(
            "default:\n  states:\n    - name: backlog\n      group: unstarted\n"
        )
        (project_path / "schema" / "labels.yaml").write_text("[]")
        (project_path / ".plane" / "state.json").write_text(
            json.dumps({"last_sync": None, "types": {}, "states": {}, "labels": {}, "work_items": {}})
        )
        monkeypatch.chdir(project_path)
        result = runner.invoke(app, ["state", "show"])
        assert result.exit_code == 0

    def test_state_reset_no_project(self, tmp_path, monkeypatch):
        """Test state reset outside a project."""
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["state", "reset"])
        # May exit 0 or 1 depending on implementation
        assert result.exit_code in (0, 1)


class TestCloneCommand:
    """Tests for clone command."""

    def test_clone_help(self):
        """Test clone --help."""
        result = runner.invoke(app, ["clone", "--help"])
        assert result.exit_code == 0
        assert "PROJECT" in result.stdout
        assert "--workspace" in result.stdout

    def test_clone_no_args(self):
        """Test clone without arguments fails."""
        result = runner.invoke(app, ["clone"])
        assert result.exit_code == 2  # Missing required argument


class TestPushDryRun:
    """Tests for push --dry-run."""

    def test_push_dry_run_help(self):
        result = runner.invoke(app, ["push", "--help"])
        assert "--dry-run" in result.stdout

    def test_push_all_help(self):
        result = runner.invoke(app, ["push", "--help"])
        assert "--all" in result.stdout


class TestPullOptions:
    """Tests for pull command options."""

    def test_pull_output_option(self):
        """Verify pull writes to work/workitems.yaml (no --output flag needed)."""
        result = runner.invoke(app, ["pull", "--help"])
        assert "work/workitems.yaml" in result.stdout

    def test_pull_merge_option(self):
        result = runner.invoke(app, ["pull", "--help"])
        assert "--merge" in result.stdout

    def test_pull_properties_option(self):
        result = runner.invoke(app, ["pull", "--help"])
        assert "--with-properties" in result.stdout

    def test_pull_all_option(self):
        result = runner.invoke(app, ["pull", "--help"])
        assert "--all" in result.stdout


class TestSchemaSubcommands:
    """Tests for all schema subcommands."""

    def test_schema_import_help(self):
        result = runner.invoke(app, ["schema", "import", "--help"])
        assert result.exit_code == 0
        assert "--merge" in result.stdout
        assert "--force" in result.stdout

    def test_schema_sync_help(self):
        result = runner.invoke(app, ["schema", "sync", "--help"])
        assert result.exit_code == 0
        assert "DECLARATIVE" in result.stdout.upper() or "declarative" in result.stdout.lower()

    def test_schema_diff_help(self):
        result = runner.invoke(app, ["schema", "diff", "--help"])
        assert result.exit_code == 0
        assert "Compare" in result.stdout or "compare" in result.stdout


class TestJsonOutputFlag:
    """Tests for --json output flag on push, pull, and status commands."""

    def test_push_json_flag_in_help(self):
        """Test that push --help shows the --json flag."""
        result = runner.invoke(app, ["push", "--help"])
        assert result.exit_code == 0
        assert "--json" in result.stdout

    def test_pull_json_flag_in_help(self):
        """Test that pull --help shows the --json flag."""
        result = runner.invoke(app, ["pull", "--help"])
        assert result.exit_code == 0
        assert "--json" in result.stdout

    def test_status_json_flag_in_help(self):
        """Test that status --help shows the --json flag."""
        result = runner.invoke(app, ["status", "--help"])
        assert result.exit_code == 0
        assert "--json" in result.stdout

    def test_push_json_no_project(self, tmp_path, monkeypatch):
        """Test push --json outside a project still exits with code 1."""
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["push", "--json"])
        assert result.exit_code == 1

    def test_pull_json_no_project(self, tmp_path, monkeypatch):
        """Test pull --json outside a project still exits with code 1."""
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["pull", "--json"])
        assert result.exit_code == 1

    def test_status_json_no_project(self, tmp_path, monkeypatch):
        """Test status --json outside a project outputs JSON error and exits 1."""
        import json as json_mod
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["status", "--json"])
        assert result.exit_code == 1
        # Output should be valid JSON with an error field
        data = json_mod.loads(result.stdout)
        assert data["command"] == "status"
        assert data["success"] is False
        assert "error" in data

    def test_status_json_with_project(self, tmp_path, monkeypatch):
        """Test status --json in a valid project outputs proper JSON."""
        import json as json_mod
        project_path = tmp_path / "proj"
        project_path.mkdir()
        (project_path / "schema").mkdir()
        (project_path / "work").mkdir()
        (project_path / ".plane").mkdir()
        (project_path / "plane.yaml").write_text(
            "workspace: test\nproject:\n  key: TEST\n  name: Test\ndefaults:\n  type: task\n  workflow: default\n"
        )
        (project_path / "schema" / "types.yaml").write_text("task:\n  workflow: default\n")
        (project_path / "schema" / "workflows.yaml").write_text(
            "default:\n  states:\n    - name: backlog\n      group: unstarted\n"
        )
        (project_path / "schema" / "labels.yaml").write_text("[]")
        (project_path / ".plane" / "state.json").write_text(
            json_mod.dumps({"last_sync": None, "types": {}, "states": {}, "labels": {}, "work_items": {}})
        )
        monkeypatch.chdir(project_path)
        result = runner.invoke(app, ["status", "--json"])
        assert result.exit_code == 0
        data = json_mod.loads(result.stdout)
        assert data["command"] == "status"
        assert data["project"] == "TEST"
        assert data["workspace"] == "test"
        assert "tracked_items" in data
        assert "state_file" in data
        assert "schema" in data

    def test_validate_offline_without_auth(self, temp_project, tmp_path, monkeypatch):
        """Work item validation in offline mode should not require auth."""
        from planecompose.cli import auth as auth_cmd

        missing_config = tmp_path / "missing-config.json"
        missing_token = tmp_path / "missing-credentials"
        monkeypatch.setattr(auth_cmd, "_get_config_file", lambda: missing_config)
        monkeypatch.setattr(auth_cmd, "_get_token_file", lambda: missing_token)
        monkeypatch.chdir(temp_project)

        result = runner.invoke(app, ["validate", "--offline"])

        assert result.exit_code == 0


class TestDiffCommand:
    """Tests for diff command."""

    def test_diff_help(self):
        """Test diff --help."""
        result = runner.invoke(app, ["diff", "--help"])

        assert result.exit_code == 0
        assert "differences" in result.stdout.lower()
        assert "--json" in result.stdout

    def test_diff_registered(self):
        """Test diff command appears in main help."""
        result = runner.invoke(app, ["--help"])

        assert result.exit_code == 0
        assert "diff" in result.stdout

    def test_diff_no_project(self, tmp_path, monkeypatch):
        """Test diff outside a project."""
        monkeypatch.chdir(tmp_path)

        result = runner.invoke(app, ["diff"])

        assert result.exit_code == 1

    def _make_mock_backend(self):
        """Create a mock backend for diff tests (avoids real network calls)."""
        mock_backend = AsyncMock()
        mock_backend.get_project_features = AsyncMock(return_value={})
        mock_backend.get_work_item = AsyncMock(return_value=None)
        mock_backend.disconnect = AsyncMock()
        return mock_backend

    def _diff_patches(self, mock_backend):
        """Return context manager stack that mocks diff's network dependencies."""
        from planecompose.config.context import load_project_context

        def _no_auth_ctx(path=None, require_auth=True):
            return load_project_context(path, require_auth=False)

        async def _mock_connect(ctx, progress=None, task=None):
            return ctx, mock_backend

        return (
            patch("planecompose.cli.diff.require_project_context", side_effect=_no_auth_ctx),
            patch("planecompose.cli.diff.connect_backend", new=_mock_connect),
            patch(
                "planecompose.cli.diff.fetch_remote_schema",
                new=AsyncMock(return_value=([], [], [], [], [], [])),
            ),
        )

    def test_diff_empty_project(self, tmp_path, monkeypatch):
        """Test diff in a project with no work items."""
        project_path = tmp_path / "proj"
        project_path.mkdir()
        (project_path / "schema").mkdir()
        (project_path / "work").mkdir()
        (project_path / ".plane").mkdir()
        (project_path / "plane.yaml").write_text(
            "workspace: test\nproject:\n  key: TEST\n  name: Test\ndefaults:\n  type: task\n  workflow: default\n"
        )
        (project_path / "schema" / "types.yaml").write_text("task:\n  workflow: default\n")
        (project_path / "schema" / "workflows.yaml").write_text(
            "default:\n  states:\n    - name: backlog\n      group: unstarted\n"
        )
        (project_path / "schema" / "labels.yaml").write_text("[]")
        (project_path / ".plane" / "state.json").write_text(
            json.dumps({"last_sync": None, "types": {}, "states": {}, "labels": {}, "work_items": {}})
        )
        monkeypatch.chdir(project_path)

        mock_backend = self._make_mock_backend()
        p1, p2, p3 = self._diff_patches(mock_backend)
        with p1, p2, p3:
            result = runner.invoke(app, ["diff"])

        assert result.exit_code == 0
        assert "Work Items: Local" in result.stdout
        assert "All items are in sync" in result.stdout

    def test_diff_with_new_items(self, tmp_path, monkeypatch):
        """Test diff shows new items to create."""
        project_path = tmp_path / "proj"
        project_path.mkdir()
        (project_path / "schema").mkdir()
        (project_path / "work").mkdir()
        (project_path / ".plane").mkdir()
        (project_path / "plane.yaml").write_text(
            "workspace: test\nproject:\n  key: TEST\n  name: Test\ndefaults:\n  type: task\n  workflow: default\n"
        )
        (project_path / "schema" / "types.yaml").write_text("task:\n  workflow: default\n")
        (project_path / "schema" / "workflows.yaml").write_text(
            "default:\n  states:\n    - name: backlog\n      group: unstarted\n"
        )
        (project_path / "schema" / "labels.yaml").write_text("[]")
        (project_path / ".plane" / "state.json").write_text(
            json.dumps({"last_sync": None, "types": {}, "states": {}, "labels": {}, "work_items": {}})
        )
        (project_path / "work" / "inbox.yaml").write_text(
            "- title: Implement auth\n  type: task\n  priority: high\n"
            "- title: Fix login bug\n  type: task\n  priority: medium\n"
        )
        monkeypatch.chdir(project_path)

        mock_backend = self._make_mock_backend()
        p1, p2, p3 = self._diff_patches(mock_backend)
        with p1, p2, p3:
            result = runner.invoke(app, ["diff"])

        assert result.exit_code == 0
        assert "New Locally" in result.stdout
        assert "Implement auth" in result.stdout
        assert "Fix login bug" in result.stdout

    def test_diff_json_output(self, tmp_path, monkeypatch):
        """Test diff --json outputs valid JSON."""
        project_path = tmp_path / "proj"
        project_path.mkdir()
        (project_path / "schema").mkdir()
        (project_path / "work").mkdir()
        (project_path / ".plane").mkdir()
        (project_path / "plane.yaml").write_text(
            "workspace: test\nproject:\n  key: TEST\n  name: Test\ndefaults:\n  type: task\n  workflow: default\n"
        )
        (project_path / "schema" / "types.yaml").write_text("task:\n  workflow: default\n")
        (project_path / "schema" / "workflows.yaml").write_text(
            "default:\n  states:\n    - name: backlog\n      group: unstarted\n"
        )
        (project_path / "schema" / "labels.yaml").write_text("[]")
        (project_path / ".plane" / "state.json").write_text(
            json.dumps({"last_sync": None, "types": {}, "states": {}, "labels": {}, "work_items": {}})
        )
        (project_path / "work" / "inbox.yaml").write_text(
            "- title: New feature\n  type: task\n"
        )
        monkeypatch.chdir(project_path)

        mock_backend = self._make_mock_backend()
        p1, p2, p3 = self._diff_patches(mock_backend)
        with p1, p2, p3:
            result = runner.invoke(app, ["diff", "--json"])

        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert data["command"] == "diff"
        assert data["success"] is True
        assert data["summary"]["new_local"] == 1
        assert data["summary"]["modified_local"] == 0
        assert data["summary"]["in_sync"] == 0
        assert len(data["items"]) == 1
        assert data["items"][0]["category"] == "new_local"
        assert data["items"][0]["title"] == "New feature"

    def test_diff_json_no_project(self, tmp_path, monkeypatch):
        """Test diff --json outside a project exits with code 1."""
        monkeypatch.chdir(tmp_path)

        result = runner.invoke(app, ["diff", "--json"])

        assert result.exit_code == 1

    def test_diff_all_synced(self, tmp_path, monkeypatch):
        """Test diff when all items are already synced."""
        from planecompose.utils.work_items import calculate_content_hash, get_tracking_key
        from planecompose.core.models import WorkItem

        project_path = tmp_path / "proj"
        project_path.mkdir()
        (project_path / "schema").mkdir()
        (project_path / "work").mkdir()
        (project_path / ".plane").mkdir()
        (project_path / "plane.yaml").write_text(
            "workspace: test\nproject:\n  key: TEST\n  name: Test\ndefaults:\n  type: task\n  workflow: default\n"
        )
        (project_path / "schema" / "types.yaml").write_text("task:\n  workflow: default\n")
        (project_path / "schema" / "workflows.yaml").write_text(
            "default:\n  states:\n    - name: backlog\n      group: unstarted\n"
        )
        (project_path / "schema" / "labels.yaml").write_text("[]")

        # Create a work item and matching state entry
        item = WorkItem(title="Already synced", type="task", priority="high")
        content_hash = calculate_content_hash(item)
        tracking_key = get_tracking_key(item, "work/inbox.yaml", 0)

        from planecompose.utils.work_items import CONTENT_HASH_VERSION

        state = {
            "last_sync": "2025-01-01T00:00:00",
            "types": {},
            "states": {},
            "labels": {},
            "work_items": {
                tracking_key: {
                    "remote_id": "abc-123",
                    "content_hash": content_hash,
                    "source": "work/inbox.yaml:0",
                    "last_synced": "2025-01-01T00:00:00",
                    "hash_version": CONTENT_HASH_VERSION,
                }
            },
        }
        (project_path / ".plane" / "state.json").write_text(json.dumps(state))
        (project_path / "work" / "inbox.yaml").write_text(
            "- title: Already synced\n  type: task\n  priority: high\n"
        )
        monkeypatch.chdir(project_path)

        # Return the matching WorkItem so the tracked item is classified as in_sync
        from planecompose.core.models import WorkItem as _WorkItem
        mock_backend = self._make_mock_backend()
        mock_backend.get_work_item = AsyncMock(
            return_value=_WorkItem(title="Already synced", type="task", priority="high")
        )
        p1, p2, p3 = self._diff_patches(mock_backend)
        with p1, p2, p3:
            result = runner.invoke(app, ["diff"])

        assert result.exit_code == 0
        assert "1 in sync" in result.stdout
        assert "All tracked items are in sync" in result.stdout
