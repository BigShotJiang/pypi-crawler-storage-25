"""Focused tests for PlaneBackend behavior."""
from types import SimpleNamespace

import pytest

from planecompose.backend.plane import PlaneBackend
from planecompose.core.models import ProjectConfig
from planecompose.exceptions import NotFoundError


def _make_backend():
    backend = PlaneBackend()
    values = SimpleNamespace(
        create=object(),
        update=object(),
        delete=object(),
    )
    work_items = SimpleNamespace(retrieve=object())
    client = SimpleNamespace(
        sdk=SimpleNamespace(
            work_item_properties=SimpleNamespace(values=values),
            work_items=work_items,
        ),
        handlers={},
        calls=[],
    )

    async def call(func, *args, **kwargs):
        client.calls.append((func, kwargs))
        handler = client.handlers.get(func)
        if handler is None:
            return None
        if isinstance(handler, BaseException):
            raise handler
        return handler(*args, **kwargs) if callable(handler) else handler

    client.call = call

    backend._client = client
    backend._config = ProjectConfig(workspace="test", project_key="TEST")
    backend._project_id = "project-1"
    return backend, client


class TestPlaneBackendProperties:
    @pytest.mark.asyncio
    async def test_get_work_item_includes_custom_properties(self, monkeypatch):
        backend, client = _make_backend()

        raw_item = SimpleNamespace(
            id="remote-1",
            name="Remote item",
            sequence_id=7,
            type=SimpleNamespace(name="Task", id="type-1"),
            state=SimpleNamespace(name="Backlog", id="state-1"),
            labels=[],
            assignees=[],
        )
        client.handlers[client.sdk.work_items.retrieve] = raw_item

        async def ensure_schema_loaded():
            return None

        async def get_relations(_remote_id):
            return {}

        async def fetch_properties(work_item_id, type_id):
            assert work_item_id == "remote-1"
            assert type_id == "type-1"
            return {"severity": "high"}

        monkeypatch.setattr(backend, "_ensure_caches_loaded", ensure_schema_loaded)
        monkeypatch.setattr(backend, "_get_work_item_relations", get_relations)
        monkeypatch.setattr(backend, "_fetch_work_item_properties_for_item", fetch_properties)

        item = await backend.get_work_item("remote-1")

        assert item.id == "TEST-7"
        assert item.properties == {"severity": "high"}

    @pytest.mark.asyncio
    async def test_set_work_item_properties_creates_missing_values(self, monkeypatch):
        backend, client = _make_backend()

        async def get_property_map(_type_id):
            return {
                "severity": {
                    "property_id": "prop-1",
                    "property_type": "text",
                    "is_multi": False,
                    "display_name": "Severity",
                },
            }

        async def call(func, *args, **kwargs):
            client.calls.append((func, kwargs))
            if func is client.sdk.work_item_properties.values.update:
                raise NotFoundError(resource="property value")
            return None

        client.call = call
        monkeypatch.setattr(backend, "_get_property_map", get_property_map)

        await backend._set_work_item_properties(
            "remote-1",
            "type-1",
            {"severity": "high"},
            replace_existing=False,
        )

        assert [func for func, _ in client.calls] == [
            client.sdk.work_item_properties.values.update,
            client.sdk.work_item_properties.values.create,
        ]

    @pytest.mark.asyncio
    async def test_set_work_item_properties_replaces_and_clears_missing_values(self, monkeypatch):
        backend, client = _make_backend()

        async def get_property_map(_type_id):
            return {
                "severity": {
                    "property_id": "prop-1",
                    "property_type": "text",
                    "is_multi": False,
                    "display_name": "Severity",
                },
                "notes": {
                    "property_id": "prop-2",
                    "property_type": "text",
                    "is_multi": False,
                    "display_name": "Notes",
                },
            }

        monkeypatch.setattr(backend, "_get_property_map", get_property_map)

        await backend._set_work_item_properties(
            "remote-1",
            "type-1",
            {"severity": "high"},
            replace_existing=True,
        )

        operations = [
            (func, kwargs["property_id"])
            for func, kwargs in client.calls
        ]
        assert operations == [
            (client.sdk.work_item_properties.values.update, "prop-1"),
            (client.sdk.work_item_properties.values.delete, "prop-2"),
        ]

    @pytest.mark.asyncio
    async def test_set_work_item_properties_clears_all_when_local_properties_removed(self, monkeypatch):
        backend, client = _make_backend()

        async def get_property_map(_type_id):
            return {
                "severity": {
                    "property_id": "prop-1",
                    "property_type": "text",
                    "is_multi": False,
                    "display_name": "Severity",
                },
            }

        monkeypatch.setattr(backend, "_get_property_map", get_property_map)

        await backend._set_work_item_properties(
            "remote-1",
            "type-1",
            {},
            replace_existing=True,
        )

        assert [
            (func, kwargs["property_id"])
            for func, kwargs in client.calls
        ] == [
            (client.sdk.work_item_properties.values.delete, "prop-1"),
        ]
