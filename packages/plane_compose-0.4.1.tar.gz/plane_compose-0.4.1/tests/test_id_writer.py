"""Tests for auto-write ID functionality (id_writer module)."""
import pytest
import yaml
from pathlib import Path

from planecompose.core.models import WorkItem
from planecompose.sync.planner import SyncItem, SyncAction
from planecompose.sync.executor import SyncItemResult
from planecompose.utils.id_writer import (
    write_ids_to_yaml,
    write_ids_to_yaml_with_remaps,
    _insert_id_single_item,
    _insert_ids_list,
    _format_yaml_value,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_sync_item(
    title: str,
    source_file: str,
    index: int,
    item_id: str | None = None,
) -> SyncItem:
    """Create a SyncItem for testing."""
    return SyncItem(
        action=SyncAction.CREATE,
        item=WorkItem(title=title, type="task", id=item_id),
        tracking_key=f"id:{item_id}" if item_id else f"hash:abc{index}",
        source_file=source_file,
        index=index,
        reason="new item",
    )


def _make_result(
    title: str,
    source_file: str,
    index: int,
    sequence_id: int | None,
    item_id: str | None = None,
    success: bool = True,
) -> SyncItemResult:
    """Create a SyncItemResult for testing."""
    return SyncItemResult(
        item=_make_sync_item(title, source_file, index, item_id=item_id),
        success=success,
        remote_id=f"uuid-{index}",
        sequence_id=sequence_id,
    )


# ---------------------------------------------------------------------------
# Tests: _format_yaml_value
# ---------------------------------------------------------------------------

class TestFormatYamlValue:
    """Tests for YAML value formatting."""

    def test_simple_id(self):
        assert _format_yaml_value("PROJ-123") == "PROJ-123"

    def test_alphanumeric_with_hyphens(self):
        assert _format_yaml_value("my-project-42") == "my-project-42"

    def test_value_with_spaces(self):
        assert _format_yaml_value("has space") == '"has space"'

    def test_value_with_colon(self):
        assert _format_yaml_value("key:value") == '"key:value"'

    def test_empty_string(self):
        assert _format_yaml_value("") == '""'


# ---------------------------------------------------------------------------
# Tests: _insert_id_single_item
# ---------------------------------------------------------------------------

class TestInsertIdSingleItem:
    """Tests for inserting ID into single-item (dict) YAML."""

    def test_basic_dict(self):
        content = "title: My Task\ntype: task\n"
        result = _insert_id_single_item(content, "PROJ-42")
        parsed = yaml.safe_load(result)
        assert parsed['id'] == 'PROJ-42'
        assert parsed['title'] == 'My Task'
        assert 'id: PROJ-42' in result

    def test_with_comment_header(self):
        content = "# Work item\ntitle: My Task\ntype: task\n"
        result = _insert_id_single_item(content, "PROJ-1")
        parsed = yaml.safe_load(result)
        assert parsed['id'] == 'PROJ-1'
        assert parsed['title'] == 'My Task'
        # Comment should be preserved
        assert '# Work item' in result

    def test_with_document_separator(self):
        content = "---\ntitle: My Task\ntype: task\n"
        result = _insert_id_single_item(content, "PROJ-99")
        parsed = yaml.safe_load(result)
        assert parsed['id'] == 'PROJ-99'
        assert parsed['title'] == 'My Task'


# ---------------------------------------------------------------------------
# Tests: _insert_ids_list
# ---------------------------------------------------------------------------

class TestInsertIdsList:
    """Tests for inserting IDs into list-style YAML."""

    def test_single_item_list(self):
        content = "- title: First task\n  type: task\n"
        result = _insert_ids_list(content, [(0, "PROJ-1")])
        parsed = yaml.safe_load(result)
        assert parsed[0]['id'] == 'PROJ-1'
        assert parsed[0]['title'] == 'First task'

    def test_multiple_items_some_need_ids(self):
        content = (
            "- title: First\n"
            "  type: task\n"
            "- title: Second\n"
            "  type: bug\n"
            "- title: Third\n"
            "  type: task\n"
        )
        # Only items 0 and 2 need IDs (descending order)
        result = _insert_ids_list(content, [(2, "PROJ-3"), (0, "PROJ-1")])
        parsed = yaml.safe_load(result)
        assert parsed[0]['id'] == 'PROJ-1'
        assert parsed[1].get('id') is None
        assert parsed[2]['id'] == 'PROJ-3'

    def test_preserves_existing_content(self):
        content = (
            "- title: My task\n"
            "  type: task\n"
            "  priority: high\n"
            "  labels:\n"
            "    - frontend\n"
            "    - backend\n"
        )
        result = _insert_ids_list(content, [(0, "PROJ-7")])
        parsed = yaml.safe_load(result)
        assert parsed[0]['id'] == 'PROJ-7'
        assert parsed[0]['title'] == 'My task'
        assert parsed[0]['priority'] == 'high'
        assert parsed[0]['labels'] == ['frontend', 'backend']

    def test_all_items_in_list(self):
        content = (
            "- title: A\n"
            "  type: task\n"
            "- title: B\n"
            "  type: task\n"
        )
        result = _insert_ids_list(content, [(1, "PROJ-2"), (0, "PROJ-1")])
        parsed = yaml.safe_load(result)
        assert parsed[0]['id'] == 'PROJ-1'
        assert parsed[1]['id'] == 'PROJ-2'


# ---------------------------------------------------------------------------
# Tests: write_ids_to_yaml (integration)
# ---------------------------------------------------------------------------

class TestWriteIdsToYaml:
    """Integration tests for write_ids_to_yaml."""

    def test_writes_ids_for_items_without_id(self, tmp_path):
        """Items without a user-provided ID should get IDs written back."""
        work_dir = tmp_path / "work"
        work_dir.mkdir()

        inbox = work_dir / "inbox.yaml"
        inbox.write_text(
            "- title: Task without ID\n"
            "  type: task\n"
            "- title: Another task\n"
            "  type: bug\n"
        )

        results = [
            _make_result("Task without ID", "work/inbox.yaml", 0, sequence_id=42),
            _make_result("Another task", "work/inbox.yaml", 1, sequence_id=43),
        ]

        written = write_ids_to_yaml(results, "TEST", tmp_path)
        assert written == 2

        # Verify the file was updated
        data = yaml.safe_load(inbox.read_text())
        assert data[0]['id'] == 'TEST-42'
        assert data[1]['id'] == 'TEST-43'

    def test_skips_items_with_existing_id(self, tmp_path):
        """Items that already have a user-provided ID should not be modified."""
        work_dir = tmp_path / "work"
        work_dir.mkdir()

        inbox = work_dir / "inbox.yaml"
        inbox.write_text(
            "- id: MY-ID\n"
            "  title: Has ID\n"
            "  type: task\n"
        )

        results = [
            _make_result("Has ID", "work/inbox.yaml", 0, sequence_id=1, item_id="MY-ID"),
        ]

        written = write_ids_to_yaml(results, "TEST", tmp_path)
        assert written == 0

        # File should be unchanged
        data = yaml.safe_load(inbox.read_text())
        assert data[0]['id'] == 'MY-ID'

    def test_skips_failed_results(self, tmp_path):
        """Failed create results should not trigger ID writeback."""
        work_dir = tmp_path / "work"
        work_dir.mkdir()

        inbox = work_dir / "inbox.yaml"
        inbox.write_text("- title: Failed task\n  type: task\n")

        results = [
            _make_result("Failed task", "work/inbox.yaml", 0, sequence_id=1, success=False),
        ]

        written = write_ids_to_yaml(results, "TEST", tmp_path)
        assert written == 0

    def test_skips_items_without_sequence_id(self, tmp_path):
        """Items without sequence_id should not trigger ID writeback."""
        work_dir = tmp_path / "work"
        work_dir.mkdir()

        inbox = work_dir / "inbox.yaml"
        inbox.write_text("- title: No seq\n  type: task\n")

        results = [
            _make_result("No seq", "work/inbox.yaml", 0, sequence_id=None),
        ]

        written = write_ids_to_yaml(results, "TEST", tmp_path)
        assert written == 0

    def test_returns_state_remaps_for_written_ids(self, tmp_path):
        """Written IDs should also return hash->id remaps for state migration."""
        work_dir = tmp_path / "work"
        work_dir.mkdir()

        inbox = work_dir / "inbox.yaml"
        inbox.write_text("- title: Needs remap\n  type: task\n")

        results = [
            _make_result("Needs remap", "work/inbox.yaml", 0, sequence_id=42),
        ]

        written, remaps = write_ids_to_yaml_with_remaps(results, "TEST", tmp_path)

        assert written == 1
        assert remaps == [("hash:abc0", "id:TEST-42")]

    def test_handles_single_item_dict_file(self, tmp_path):
        """Single-item (dict) YAML files should work too."""
        work_dir = tmp_path / "work"
        work_dir.mkdir()

        task_file = work_dir / "single.yaml"
        task_file.write_text("title: Solo task\ntype: task\n")

        results = [
            _make_result("Solo task", "work/single.yaml", 0, sequence_id=99),
        ]

        written = write_ids_to_yaml(results, "PROJ", tmp_path)
        assert written == 1

        data = yaml.safe_load(task_file.read_text())
        assert data['id'] == 'PROJ-99'
        assert data['title'] == 'Solo task'

    def test_multiple_files(self, tmp_path):
        """Items from different files should all get IDs written."""
        work_dir = tmp_path / "work"
        work_dir.mkdir()

        file_a = work_dir / "a.yaml"
        file_a.write_text("- title: Task A\n  type: task\n")

        file_b = work_dir / "b.yaml"
        file_b.write_text("- title: Task B\n  type: bug\n")

        results = [
            _make_result("Task A", "work/a.yaml", 0, sequence_id=10),
            _make_result("Task B", "work/b.yaml", 0, sequence_id=11),
        ]

        written = write_ids_to_yaml(results, "X", tmp_path)
        assert written == 2

        data_a = yaml.safe_load(file_a.read_text())
        assert data_a[0]['id'] == 'X-10'

        data_b = yaml.safe_load(file_b.read_text())
        assert data_b[0]['id'] == 'X-11'

    def test_mixed_items_some_with_id(self, tmp_path):
        """Only items without IDs get writeback; items with IDs are skipped."""
        work_dir = tmp_path / "work"
        work_dir.mkdir()

        inbox = work_dir / "inbox.yaml"
        inbox.write_text(
            "- id: existing-1\n"
            "  title: Has ID\n"
            "  type: task\n"
            "- title: Needs ID\n"
            "  type: task\n"
        )

        results = [
            _make_result("Has ID", "work/inbox.yaml", 0, sequence_id=1, item_id="existing-1"),
            _make_result("Needs ID", "work/inbox.yaml", 1, sequence_id=2),
        ]

        written = write_ids_to_yaml(results, "P", tmp_path)
        assert written == 1

        data = yaml.safe_load(inbox.read_text())
        assert data[0]['id'] == 'existing-1'
        assert data[1]['id'] == 'P-2'

    def test_preserves_comments(self, tmp_path):
        """Comments in YAML files should be preserved."""
        work_dir = tmp_path / "work"
        work_dir.mkdir()

        inbox = work_dir / "inbox.yaml"
        inbox.write_text(
            "# Sprint 1 tasks\n"
            "- title: First\n"
            "  type: task\n"
        )

        results = [
            _make_result("First", "work/inbox.yaml", 0, sequence_id=5),
        ]

        write_ids_to_yaml(results, "SP", tmp_path)

        content = inbox.read_text()
        assert "# Sprint 1 tasks" in content
        data = yaml.safe_load(content)
        assert data[0]['id'] == 'SP-5'

    def test_empty_results_returns_zero(self, tmp_path):
        """Empty results list should return 0."""
        written = write_ids_to_yaml([], "TEST", tmp_path)
        assert written == 0

    def test_missing_source_file_logs_warning(self, tmp_path):
        """Missing source file should not raise, just skip."""
        results = [
            _make_result("Ghost", "work/nonexistent.yaml", 0, sequence_id=1),
        ]

        written = write_ids_to_yaml(results, "TEST", tmp_path)
        assert written == 0

    def test_empty_yaml_file(self, tmp_path):
        """Empty YAML file should not raise."""
        work_dir = tmp_path / "work"
        work_dir.mkdir()

        empty = work_dir / "empty.yaml"
        empty.write_text("")

        results = [
            _make_result("Task", "work/empty.yaml", 0, sequence_id=1),
        ]

        written = write_ids_to_yaml(results, "TEST", tmp_path)
        assert written == 0


# ---------------------------------------------------------------------------
# Tests: SyncItemResult.sequence_id field
# ---------------------------------------------------------------------------

class TestSyncItemResultSequenceId:
    """Tests for the sequence_id field on SyncItemResult."""

    def test_default_is_none(self):
        """sequence_id defaults to None."""
        result = SyncItemResult(
            item=_make_sync_item("Test", "file.yaml", 0),
            success=True,
            remote_id="uuid-1",
        )
        assert result.sequence_id is None

    def test_can_set_sequence_id(self):
        """sequence_id can be set."""
        result = SyncItemResult(
            item=_make_sync_item("Test", "file.yaml", 0),
            success=True,
            remote_id="uuid-1",
            sequence_id=42,
        )
        assert result.sequence_id == 42
