"""Tests for the state module (StateManager)."""
import pytest
import json
import time
import threading
from pathlib import Path
from datetime import datetime

from planecompose.core.models import (
    WorkItem,
    WorkItemState,
    SyncState,
)
from planecompose.state.manager import StateManager, STATE_VERSION
from planecompose.exceptions import StateError


class TestStateManager:
    """Tests for StateManager."""

    def test_init(self, temp_project):
        """Test StateManager initialization."""
        manager = StateManager(temp_project)

        assert manager.root_path == temp_project
        assert manager.state_dir == temp_project / ".plane"
        assert manager.state_file == temp_project / ".plane" / "state.json"
        assert manager.lock_file == temp_project / ".plane" / "state.lock"

    def test_exists(self, temp_project):
        """Test checking if state file exists."""
        manager = StateManager(temp_project)

        # State file exists from fixture
        assert manager.exists()

        # Remove it
        manager.state_file.unlink()
        assert not manager.exists()

    def test_load_empty_state(self, tmp_path):
        """Test loading when no state file exists."""
        project = tmp_path / "empty-project"
        project.mkdir()

        manager = StateManager(project)
        state = manager.load()

        assert isinstance(state, SyncState)
        assert state.last_sync is None
        assert state.types == {}
        assert state.work_items == {}

    def test_load_existing_state(self, temp_project):
        """Test loading existing state."""
        # Write some state
        state_data = {
            "_version": STATE_VERSION,
            "last_sync": "2024-01-01T00:00:00Z",
            "types": {"task": "type-uuid-1"},
            "states": {"backlog": "state-uuid-1"},
            "labels": {"frontend": "label-uuid-1"},
            "work_items": {
                "item-1": {
                    "remote_id": "remote-uuid-1",
                    "content_hash": "abc123",
                    "source": "work/inbox.yaml:0",
                    "last_synced": "2024-01-01T00:00:00Z",
                }
            },
        }
        (temp_project / ".plane" / "state.json").write_text(json.dumps(state_data))

        manager = StateManager(temp_project)
        state = manager.load()

        assert state.last_sync == "2024-01-01T00:00:00Z"
        assert state.types == {"task": "type-uuid-1"}
        assert "item-1" in state.work_items
        assert state.work_items["item-1"].remote_id == "remote-uuid-1"

    def test_load_corrupted_state(self, temp_project):
        """Test loading corrupted state raises error."""
        (temp_project / ".plane" / "state.json").write_text("not valid json {{{")

        manager = StateManager(temp_project)

        with pytest.raises(StateError):
            manager.load()

    def test_save_state(self, temp_project):
        """Test saving state."""
        manager = StateManager(temp_project)

        state = SyncState(
            last_sync="2024-01-15T12:00:00Z",
            types={"task": "type-1", "bug": "type-2"},
            states={"backlog": "state-1"},
            labels={"urgent": "label-1"},
        )

        manager.save(state)

        # Reload and verify
        loaded = manager.load()
        assert loaded.last_sync == "2024-01-15T12:00:00Z"
        assert loaded.types == {"task": "type-1", "bug": "type-2"}

    def test_save_includes_version(self, temp_project):
        """Test that saved state includes version."""
        manager = StateManager(temp_project)
        manager.save(SyncState())

        raw_data = json.loads(manager.state_file.read_text())
        assert "_version" in raw_data
        assert raw_data["_version"] == STATE_VERSION

    def test_lock_context_manager(self, temp_project):
        """Test lock as context manager."""
        manager = StateManager(temp_project)

        with manager.lock() as lock:
            assert lock.lock_file == manager.lock_file
            assert lock.acquired_at > 0

        # Lock released after context

    def test_update_work_item(self, temp_project):
        """Test updating a single work item."""
        manager = StateManager(temp_project)

        item = WorkItem(id="TEST-1", title="Test Item", type="task")

        manager.update_work_item(
            tracking_key="TEST-1",
            work_item=item,
            remote_id="remote-uuid-123",
            source_file="work/inbox.yaml",
            index=0,
        )

        state = manager.load()
        assert "TEST-1" in state.work_items
        assert state.work_items["TEST-1"].remote_id == "remote-uuid-123"
        assert state.work_items["TEST-1"].source == "work/inbox.yaml:0"

    def test_update_work_items_batch(self, temp_project):
        """Test batch updating work items."""
        manager = StateManager(temp_project)

        updates = [
            ("key-1", WorkItemState(
                remote_id="remote-1",
                content_hash="hash-1",
                source="file:0",
                last_synced=datetime.now().isoformat(),
            )),
            ("key-2", WorkItemState(
                remote_id="remote-2",
                content_hash="hash-2",
                source="file:1",
                last_synced=datetime.now().isoformat(),
            )),
        ]

        manager.update_work_items_batch(updates)

        state = manager.load()
        assert "key-1" in state.work_items
        assert "key-2" in state.work_items
        assert state.work_items["key-1"].remote_id == "remote-1"

    def test_update_work_items_batch_updates_last_sync(self, temp_project):
        """Batch updates can update the top-level last_sync timestamp."""
        manager = StateManager(temp_project)
        updates = [
            ("key-1", WorkItemState(
                remote_id="remote-1",
                content_hash="hash-1",
                source="file:0",
                last_synced=datetime.now().isoformat(),
            )),
        ]

        manager.update_work_items_batch(updates, update_last_sync=True)

        state = manager.load()
        assert state.last_sync is not None

    def test_get_work_item(self, temp_project):
        """Test getting a specific work item."""
        manager = StateManager(temp_project)

        # Add an item
        item = WorkItem(id="TEST-1", title="Test", type="task")
        manager.update_work_item("TEST-1", item, "remote-1", "file.yaml", 0)

        # Get it
        result = manager.get_work_item("TEST-1")
        assert result is not None
        assert result.remote_id == "remote-1"

        # Get non-existent
        result = manager.get_work_item("non-existent")
        assert result is None

    def test_remove_work_item(self, temp_project):
        """Test removing a work item."""
        manager = StateManager(temp_project)

        # Add an item
        item = WorkItem(id="TEST-1", title="Test", type="task")
        manager.update_work_item("TEST-1", item, "remote-1", "file.yaml", 0)

        # Remove it
        assert manager.remove_work_item("TEST-1") is True
        assert manager.get_work_item("TEST-1") is None

        # Remove non-existent
        assert manager.remove_work_item("non-existent") is False

    def test_remap_work_item_tracking_keys(self, temp_project):
        """Tracked items can be moved from hash keys to stable ID keys."""
        manager = StateManager(temp_project)
        item = WorkItem(title="Needs remap", type="task")
        manager.update_work_item("hash:abc", item, "remote-1", "work/inbox.yaml", 0)

        moved = manager.remap_work_item_tracking_keys([("hash:abc", "id:TEST-42")])

        state = manager.load()
        assert moved == 1
        assert "hash:abc" not in state.work_items
        assert state.work_items["id:TEST-42"].remote_id == "remote-1"

    def test_clear(self, temp_project):
        """Test clearing all state."""
        manager = StateManager(temp_project)

        # Add some data
        item = WorkItem(id="TEST-1", title="Test", type="task")
        manager.update_work_item("TEST-1", item, "remote-1", "file.yaml", 0)
        manager.update_schema_state(types={"task": "type-1"})

        # Clear
        manager.clear()

        state = manager.load()
        assert state.types == {}
        assert state.work_items == {}

    def test_reset(self, temp_project):
        """Test resetting (deleting) state file."""
        manager = StateManager(temp_project)

        assert manager.exists()
        manager.reset()
        assert not manager.exists()

    def test_update_schema_state(self, temp_project):
        """Test updating schema state."""
        manager = StateManager(temp_project)

        manager.update_schema_state(
            types={"task": "type-1", "bug": "type-2"},
            states={"backlog": "state-1"},
        )

        state = manager.load()
        assert state.types == {"task": "type-1", "bug": "type-2"}
        assert state.states == {"backlog": "state-1"}

        # Update just labels
        manager.update_schema_state(labels={"urgent": "label-1"})

        state = manager.load()
        assert state.types == {"task": "type-1", "bug": "type-2"}  # Preserved
        assert state.labels == {"urgent": "label-1"}

    def test_mark_last_sync(self, temp_project):
        """mark_last_sync updates only the top-level timestamp."""
        manager = StateManager(temp_project)
        manager.mark_last_sync("2025-01-01T00:00:00Z")

        state = manager.load()
        assert state.last_sync == "2025-01-01T00:00:00Z"

    def test_get_summary(self, temp_project):
        """Test getting state summary."""
        manager = StateManager(temp_project)

        manager.update_schema_state(
            types={"task": "t1", "bug": "t2"},
            states={"backlog": "s1"},
            labels={"urgent": "l1", "feature": "l2"},
        )
        item = WorkItem(id="TEST-1", title="Test", type="task")
        manager.update_work_item("TEST-1", item, "remote-1", "file.yaml", 0)

        summary = manager.get_summary()

        assert summary['types_count'] == 2
        assert summary['states_count'] == 1
        assert summary['labels_count'] == 2
        assert summary['work_items_count'] == 1
        assert 'state_file' in summary

    def test_get_work_items_summary(self, temp_project):
        """Test getting work items summary."""
        manager = StateManager(temp_project)

        # Add items
        for i in range(3):
            item = WorkItem(id=f"TEST-{i}", title=f"Test {i}", type="task")
            manager.update_work_item(f"TEST-{i}", item, f"remote-{i}", "file.yaml", i)

        summary = manager.get_work_items_summary()

        assert len(summary) == 3
        assert any(s['tracking_key'] == 'TEST-0' for s in summary)


class TestStateLocking:
    """Tests for state file locking."""

    def test_concurrent_writes_are_serialized(self, temp_project):
        """Test that concurrent writes are properly serialized."""
        manager = StateManager(temp_project)
        results = []
        errors = []

        def writer(value):
            try:
                with manager.lock(timeout=5.0):
                    state = manager.load()
                    # Simulate some work
                    time.sleep(0.1)
                    state.types[f"type-{value}"] = f"id-{value}"
                    manager.save(state)
                    results.append(value)
            except Exception as e:
                errors.append(e)

        # Start multiple threads
        threads = [threading.Thread(target=writer, args=(i,)) for i in range(3)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # All should succeed
        assert len(errors) == 0
        assert len(results) == 3

        # All types should be saved
        state = manager.load()
        assert len(state.types) == 3

    def test_lock_timeout(self, temp_project):
        """Test that lock times out if held too long."""
        manager = StateManager(temp_project)

        # Hold lock in one context
        with manager.lock():
            # Try to acquire in another with short timeout
            manager2 = StateManager(temp_project)
            with pytest.raises(StateError) as exc_info:
                with manager2.lock(timeout=0.5):
                    pass

            assert "Could not acquire" in str(exc_info.value)

    def test_fallback_lock_timeout_does_not_remove_active_lock(self, temp_project, monkeypatch):
        """Timeout while waiting must not delete another process's fallback lock."""
        monkeypatch.setattr("planecompose.state.manager.HAS_FCNTL", False)
        monkeypatch.setattr(StateManager, "_fallback_warning_shown", False)

        manager = StateManager(temp_project)
        waiting_manager = StateManager(temp_project)

        with manager.lock(timeout=1.0):
            assert manager.lock_file.exists()

            with pytest.raises(StateError) as exc_info:
                with waiting_manager.lock(timeout=0.2):
                    pass

            assert "Could not acquire" in str(exc_info.value)
            assert manager.lock_file.exists()

        assert not manager.lock_file.exists()

    def test_remove_work_items_batch(self, temp_project):
        """Batch removal removes multiple items in single lock."""
        manager = StateManager(temp_project)

        # Add items
        state = SyncState()
        for i in range(5):
            state.work_items[f"id:ITEM-{i}"] = WorkItemState(
                remote_id=f"remote-{i}",
                content_hash=f"hash-{i}",
                source=f"work/inbox.yaml:{i}",
                last_synced="2024-01-01T00:00:00Z",
            )
        with manager.lock():
            manager.save(state)

        # Remove 3 of 5
        removed = manager.remove_work_items_batch(["id:ITEM-0", "id:ITEM-2", "id:ITEM-4"])
        assert removed == 3

        state = manager.load()
        assert len(state.work_items) == 2
        assert "id:ITEM-1" in state.work_items
        assert "id:ITEM-3" in state.work_items

    def test_remove_work_items_batch_empty(self, temp_project):
        """Batch removal with empty list does nothing."""
        manager = StateManager(temp_project)
        removed = manager.remove_work_items_batch([])
        assert removed == 0

    def test_remove_work_items_batch_missing_keys(self, temp_project):
        """Batch removal with non-existent keys returns 0."""
        manager = StateManager(temp_project)
        removed = manager.remove_work_items_batch(["id:NONEXISTENT"])
        assert removed == 0
