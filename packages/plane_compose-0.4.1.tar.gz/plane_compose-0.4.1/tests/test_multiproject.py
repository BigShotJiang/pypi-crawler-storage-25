"""Tests for multi-project discovery and batch operations."""
import pytest
from pathlib import Path
from planecompose.utils.multiproject import (
    discover_projects,
    ProjectInfo,
    _should_ignore,
    _load_ignore_patterns,
)


class TestProjectDiscovery:
    """Tests for project discovery functionality."""

    def test_discover_projects_empty_dir(self, tmp_path):
        """Test discovering projects in empty directory."""
        projects = discover_projects(tmp_path)
        assert projects == []

    def test_discover_single_project(self, tmp_path):
        """Test discovering a single project."""
        # Create a project
        project_dir = tmp_path / "myproject"
        project_dir.mkdir()
        (project_dir / "plane.yaml").write_text("""
workspace: test-workspace
project:
  key: TEST
  name: Test Project
""")

        projects = discover_projects(tmp_path)
        assert len(projects) == 1
        assert projects[0].workspace == "test-workspace"
        assert projects[0].project_key == "TEST"
        assert projects[0].project_name == "Test Project"

    def test_discover_multiple_projects(self, tmp_path):
        """Test discovering multiple projects."""
        # Create two projects
        for name, key in [("api", "API"), ("web", "WEB")]:
            project_dir = tmp_path / name
            project_dir.mkdir()
            (project_dir / "plane.yaml").write_text(f"""
workspace: myteam
project:
  key: {key}
""")

        projects = discover_projects(tmp_path)
        assert len(projects) == 2
        keys = {p.project_key for p in projects}
        assert keys == {"API", "WEB"}

    def test_discover_nested_projects(self, tmp_path):
        """Test discovering nested projects."""
        # Create nested structure
        (tmp_path / "projects" / "backend").mkdir(parents=True)
        (tmp_path / "projects" / "frontend").mkdir(parents=True)

        (tmp_path / "projects" / "backend" / "plane.yaml").write_text("""
workspace: eng
project:
  key: BACKEND
""")
        (tmp_path / "projects" / "frontend" / "plane.yaml").write_text("""
workspace: eng
project:
  key: FRONTEND
""")

        projects = discover_projects(tmp_path)
        assert len(projects) == 2

    def test_filter_by_workspace(self, tmp_path):
        """Test filtering projects by workspace."""
        # Create projects in different workspaces
        for ws, key in [("eng", "API"), ("marketing", "LANDING")]:
            project_dir = tmp_path / key.lower()
            project_dir.mkdir()
            (project_dir / "plane.yaml").write_text(f"""
workspace: {ws}
project:
  key: {key}
""")

        # Filter by workspace
        projects = discover_projects(tmp_path, filter_workspace="eng")
        assert len(projects) == 1
        assert projects[0].project_key == "API"

    def test_filter_by_pattern(self, tmp_path):
        """Test filtering projects by glob pattern."""
        # Create projects
        (tmp_path / "projects" / "api").mkdir(parents=True)
        (tmp_path / "tools" / "cli").mkdir(parents=True)

        (tmp_path / "projects" / "api" / "plane.yaml").write_text("""
workspace: eng
project:
  key: API
""")
        (tmp_path / "tools" / "cli" / "plane.yaml").write_text("""
workspace: eng
project:
  key: CLI
""")

        # Filter by pattern
        projects = discover_projects(tmp_path, filter_pattern="projects/*")
        assert len(projects) == 1
        assert projects[0].project_key == "API"


class TestIgnorePatterns:
    """Tests for .planeignore functionality."""

    def test_load_ignore_patterns(self, tmp_path):
        """Test loading patterns from .planeignore."""
        (tmp_path / ".planeignore").write_text("""
# Comment
node_modules
*.bak
temp/
""")
        patterns = _load_ignore_patterns(tmp_path)
        assert "node_modules" in patterns
        assert "*.bak" in patterns
        assert "temp/" in patterns
        assert len(patterns) == 3  # Comment excluded

    def test_load_ignore_patterns_no_file(self, tmp_path):
        """Test loading patterns when no .planeignore exists."""
        patterns = _load_ignore_patterns(tmp_path)
        assert patterns == []

    def test_should_ignore(self):
        """Test ignore pattern matching."""
        patterns = ["node_modules", "*.bak", "temp/*"]

        assert _should_ignore(Path("node_modules"), patterns)
        assert _should_ignore(Path("file.bak"), patterns)
        assert _should_ignore(Path("temp/cache"), patterns)
        assert not _should_ignore(Path("src"), patterns)
        assert not _should_ignore(Path("file.txt"), patterns)

    def test_discover_respects_planeignore(self, tmp_path):
        """Test that discovery respects .planeignore."""
        # Create .planeignore
        (tmp_path / ".planeignore").write_text("ignored/*")

        # Create projects
        (tmp_path / "included").mkdir()
        (tmp_path / "ignored").mkdir()

        (tmp_path / "included" / "plane.yaml").write_text("""
workspace: test
project:
  key: INCLUDED
""")
        (tmp_path / "ignored" / "plane.yaml").write_text("""
workspace: test
project:
  key: IGNORED
""")

        projects = discover_projects(tmp_path)
        assert len(projects) == 1
        assert projects[0].project_key == "INCLUDED"


class TestProjectInfo:
    """Tests for ProjectInfo dataclass."""

    def test_project_info_basic(self):
        """Test creating ProjectInfo."""
        info = ProjectInfo(
            path=Path("/projects/api"),
            workspace="eng",
            project_key="API",
            project_name="API Service",
        )
        assert info.path == Path("/projects/api")
        assert info.workspace == "eng"
        assert info.project_key == "API"
        assert info.project_name == "API Service"

    def test_project_info_optional_name(self):
        """Test ProjectInfo with optional name."""
        info = ProjectInfo(
            path=Path("/projects/api"),
            workspace="eng",
            project_key="API",
        )
        assert info.project_name is None
