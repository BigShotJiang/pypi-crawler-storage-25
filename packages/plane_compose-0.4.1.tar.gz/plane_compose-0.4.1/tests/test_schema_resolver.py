"""Tests for schema inheritance resolver."""
import pytest
from pathlib import Path

from planecompose.parser.schema_resolver import (
    resolve_schema_inheritance,
    _merge_types,
    _merge_workflows,
    _merge_labels,
)
from planecompose.core.models import (
    WorkItemTypeDefinition,
    WorkflowDefinition,
    StateDefinition,
    LabelDefinition,
    FieldDefinition,
    FieldType,
)
from planecompose.exceptions import ConfigError


# ---------------------------------------------------------------------------
# Helpers to create schema file structures on disk
# ---------------------------------------------------------------------------

def _write_types(schema_dir: Path, content: str):
    schema_dir.mkdir(parents=True, exist_ok=True)
    (schema_dir / "types.yaml").write_text(content)


def _write_workflows(schema_dir: Path, content: str):
    schema_dir.mkdir(parents=True, exist_ok=True)
    (schema_dir / "workflows.yaml").write_text(content)


def _write_labels(schema_dir: Path, content: str):
    schema_dir.mkdir(parents=True, exist_ok=True)
    (schema_dir / "labels.yaml").write_text(content)


def _write_plane_yaml(project_dir: Path, content: str):
    project_dir.mkdir(parents=True, exist_ok=True)
    (project_dir / "plane.yaml").write_text(content)


# ---------------------------------------------------------------------------
# Tests: no inheritance (extends=None)
# ---------------------------------------------------------------------------

class TestNoInheritance:
    """When extends is None, child schema is returned unchanged."""

    def test_returns_child_schema_unchanged(self, tmp_path):
        child_schema = tmp_path / "child" / "schema"
        _write_types(child_schema, """
Bug:
  description: A defect
  workflow: default
""")
        _write_workflows(child_schema, """
default:
  states:
    - name: open
      group: unstarted
""")
        _write_labels(child_schema, """
- name: critical
  color: "#ff0000"
""")

        types, workflows, labels = resolve_schema_inheritance(child_schema, None)

        assert len(types) == 1
        assert types[0].name == "Bug"
        assert len(workflows) == 1
        assert workflows[0].name == "default"
        assert len(labels) == 1
        assert labels[0].name == "critical"

    def test_missing_schema_files_returns_empty(self, tmp_path):
        child_schema = tmp_path / "child" / "schema"
        child_schema.mkdir(parents=True)

        types, workflows, labels = resolve_schema_inheritance(child_schema, None)

        assert types == []
        assert workflows == []
        assert labels == []


# ---------------------------------------------------------------------------
# Tests: basic inheritance
# ---------------------------------------------------------------------------

class TestBasicInheritance:
    """Parent + child merge with child-wins semantics."""

    def test_child_inherits_parent_types(self, tmp_path):
        """Child inherits types from parent that it doesn't define."""
        parent_schema = tmp_path / "base-project" / "schema"
        _write_types(parent_schema, """
Task:
  description: A task
  workflow: default
Bug:
  description: A defect
  workflow: default
""")
        _write_workflows(parent_schema, "")
        _write_labels(parent_schema, "")

        child_schema = tmp_path / "child-project" / "schema"
        _write_types(child_schema, """
Feature:
  description: A feature
  workflow: default
""")
        _write_workflows(child_schema, "")
        _write_labels(child_schema, "")

        types, _, _ = resolve_schema_inheritance(
            child_schema, "../base-project/schema"
        )

        type_names = {t.name for t in types}
        assert "Task" in type_names
        assert "Bug" in type_names
        assert "Feature" in type_names
        assert len(types) == 3

    def test_child_overrides_parent_type(self, tmp_path):
        """Child type with same name replaces parent type."""
        parent_schema = tmp_path / "base-project" / "schema"
        _write_types(parent_schema, """
Bug:
  description: Parent bug
  workflow: default
""")
        _write_workflows(parent_schema, "")
        _write_labels(parent_schema, "")

        child_schema = tmp_path / "child-project" / "schema"
        _write_types(child_schema, """
Bug:
  description: Child bug with more detail
  workflow: custom
""")
        _write_workflows(child_schema, "")
        _write_labels(child_schema, "")

        types, _, _ = resolve_schema_inheritance(
            child_schema, "../base-project/schema"
        )

        assert len(types) == 1
        assert types[0].name == "Bug"
        assert types[0].description == "Child bug with more detail"
        assert types[0].workflow == "custom"

    def test_child_omitting_metadata_preserves_parent_type_settings(self, tmp_path):
        """Child overrides should not reset inherited metadata back to defaults."""
        parent_schema = tmp_path / "base-project" / "schema"
        _write_types(parent_schema, """
Bug:
  description: Parent bug
  workflow: custom
  parent_types: [Work]
  is_epic: true
  is_default: true
  level: 2
""")
        _write_workflows(parent_schema, "")
        _write_labels(parent_schema, "")

        child_schema = tmp_path / "child-project" / "schema"
        _write_types(child_schema, """
Bug:
  description: Child bug with more detail
""")
        _write_workflows(child_schema, "")
        _write_labels(child_schema, "")

        types, _, _ = resolve_schema_inheritance(
            child_schema, "../base-project/schema"
        )

        assert len(types) == 1
        assert types[0].description == "Child bug with more detail"
        assert types[0].workflow == "custom"
        assert types[0].parent_types == ["Work"]
        assert types[0].is_epic is True
        assert types[0].is_default is True
        assert types[0].level == 2

    def test_child_inherits_parent_workflows(self, tmp_path):
        parent_schema = tmp_path / "base-project" / "schema"
        _write_types(parent_schema, "")
        _write_workflows(parent_schema, """
standard:
  states:
    - name: backlog
      group: unstarted
    - name: done
      group: completed
""")
        _write_labels(parent_schema, "")

        child_schema = tmp_path / "child-project" / "schema"
        _write_types(child_schema, "")
        _write_workflows(child_schema, """
agile:
  states:
    - name: todo
      group: unstarted
    - name: in_progress
      group: started
""")
        _write_labels(child_schema, "")

        _, workflows, _ = resolve_schema_inheritance(
            child_schema, "../base-project/schema"
        )

        wf_names = {w.name for w in workflows}
        assert "standard" in wf_names
        assert "agile" in wf_names
        assert len(workflows) == 2

    def test_child_replaces_parent_workflow(self, tmp_path):
        """Child workflow replaces parent workflow entirely (not merged)."""
        parent_schema = tmp_path / "base-project" / "schema"
        _write_types(parent_schema, "")
        _write_workflows(parent_schema, """
standard:
  states:
    - name: backlog
      group: unstarted
    - name: done
      group: completed
""")
        _write_labels(parent_schema, "")

        child_schema = tmp_path / "child-project" / "schema"
        _write_types(child_schema, "")
        _write_workflows(child_schema, """
standard:
  states:
    - name: todo
      group: unstarted
    - name: in_progress
      group: started
    - name: completed
      group: completed
""")
        _write_labels(child_schema, "")

        _, workflows, _ = resolve_schema_inheritance(
            child_schema, "../base-project/schema"
        )

        assert len(workflows) == 1
        assert workflows[0].name == "standard"
        assert len(workflows[0].states) == 3
        state_names = [s.name for s in workflows[0].states]
        assert "todo" in state_names
        assert "backlog" not in state_names

    def test_child_inherits_parent_labels(self, tmp_path):
        parent_schema = tmp_path / "base-project" / "schema"
        _write_types(parent_schema, "")
        _write_workflows(parent_schema, "")
        _write_labels(parent_schema, """
- name: backend
  color: "#0000ff"
- name: frontend
  color: "#00ff00"
""")

        child_schema = tmp_path / "child-project" / "schema"
        _write_types(child_schema, "")
        _write_workflows(child_schema, "")
        _write_labels(child_schema, """
- name: api
  color: "#ff0000"
""")

        _, _, labels = resolve_schema_inheritance(
            child_schema, "../base-project/schema"
        )

        label_names = {l.name for l in labels}
        assert "backend" in label_names
        assert "frontend" in label_names
        assert "api" in label_names
        assert len(labels) == 3

    def test_child_overrides_parent_label(self, tmp_path):
        parent_schema = tmp_path / "base-project" / "schema"
        _write_types(parent_schema, "")
        _write_workflows(parent_schema, "")
        _write_labels(parent_schema, """
- name: bug
  color: "#ff0000"
""")

        child_schema = tmp_path / "child-project" / "schema"
        _write_types(child_schema, "")
        _write_workflows(child_schema, "")
        _write_labels(child_schema, """
- name: Bug
  color: "#cc0000"
""")

        _, _, labels = resolve_schema_inheritance(
            child_schema, "../base-project/schema"
        )

        assert len(labels) == 1
        assert labels[0].name == "Bug"
        assert labels[0].color == "#cc0000"


# ---------------------------------------------------------------------------
# Tests: field-level deep merge for types
# ---------------------------------------------------------------------------

class TestFieldLevelMerge:
    """Type fields are merged by field name; child fields override parent."""

    def test_child_inherits_parent_fields(self, tmp_path):
        parent_schema = tmp_path / "base-project" / "schema"
        _write_types(parent_schema, """
Bug:
  description: A defect
  workflow: default
  fields:
    - name: severity
      type: enum
      options: [low, medium, high]
    - name: component
      type: string
""")
        _write_workflows(parent_schema, "")
        _write_labels(parent_schema, "")

        child_schema = tmp_path / "child-project" / "schema"
        _write_types(child_schema, """
Bug:
  description: A defect
  workflow: default
  fields:
    - name: platform
      type: string
""")
        _write_workflows(child_schema, "")
        _write_labels(child_schema, "")

        types, _, _ = resolve_schema_inheritance(
            child_schema, "../base-project/schema"
        )

        assert len(types) == 1
        field_names = {f.name for f in types[0].fields}
        assert "severity" in field_names
        assert "component" in field_names
        assert "platform" in field_names
        assert len(types[0].fields) == 3

    def test_child_field_overrides_parent_field(self, tmp_path):
        parent_schema = tmp_path / "base-project" / "schema"
        _write_types(parent_schema, """
Bug:
  description: A defect
  workflow: default
  fields:
    - name: severity
      type: enum
      options: [low, medium, high]
""")
        _write_workflows(parent_schema, "")
        _write_labels(parent_schema, "")

        child_schema = tmp_path / "child-project" / "schema"
        _write_types(child_schema, """
Bug:
  description: A defect
  workflow: default
  fields:
    - name: severity
      type: enum
      options: [low, medium, high, critical]
""")
        _write_workflows(child_schema, "")
        _write_labels(child_schema, "")

        types, _, _ = resolve_schema_inheritance(
            child_schema, "../base-project/schema"
        )

        assert len(types) == 1
        severity_field = next(f for f in types[0].fields if f.name == "severity")
        assert severity_field.options == ["low", "medium", "high", "critical"]


# ---------------------------------------------------------------------------
# Tests: case-insensitive matching
# ---------------------------------------------------------------------------

class TestCaseInsensitive:
    """Names are matched case-insensitively but original casing is preserved."""

    def test_type_override_case_insensitive(self, tmp_path):
        parent_schema = tmp_path / "base-project" / "schema"
        _write_types(parent_schema, """
bug:
  description: lowercase parent
  workflow: default
""")
        _write_workflows(parent_schema, "")
        _write_labels(parent_schema, "")

        child_schema = tmp_path / "child-project" / "schema"
        _write_types(child_schema, """
BUG:
  description: uppercase child
  workflow: default
""")
        _write_workflows(child_schema, "")
        _write_labels(child_schema, "")

        types, _, _ = resolve_schema_inheritance(
            child_schema, "../base-project/schema"
        )

        assert len(types) == 1
        # Child casing wins
        assert types[0].name == "BUG"
        assert types[0].description == "uppercase child"

    def test_label_override_case_insensitive(self, tmp_path):
        parent_schema = tmp_path / "base-project" / "schema"
        _write_types(parent_schema, "")
        _write_workflows(parent_schema, "")
        _write_labels(parent_schema, """
- name: Frontend
  color: "#00ff00"
""")

        child_schema = tmp_path / "child-project" / "schema"
        _write_types(child_schema, "")
        _write_workflows(child_schema, "")
        _write_labels(child_schema, """
- name: frontend
  color: "#0000ff"
""")

        _, _, labels = resolve_schema_inheritance(
            child_schema, "../base-project/schema"
        )

        assert len(labels) == 1
        assert labels[0].name == "frontend"
        assert labels[0].color == "#0000ff"

    def test_workflow_override_case_insensitive(self, tmp_path):
        parent_schema = tmp_path / "base-project" / "schema"
        _write_types(parent_schema, "")
        _write_workflows(parent_schema, """
Standard:
  states:
    - name: open
      group: unstarted
""")
        _write_labels(parent_schema, "")

        child_schema = tmp_path / "child-project" / "schema"
        _write_types(child_schema, "")
        _write_workflows(child_schema, """
standard:
  states:
    - name: todo
      group: unstarted
    - name: done
      group: completed
""")
        _write_labels(child_schema, "")

        _, workflows, _ = resolve_schema_inheritance(
            child_schema, "../base-project/schema"
        )

        assert len(workflows) == 1
        assert workflows[0].name == "standard"
        assert len(workflows[0].states) == 2


# ---------------------------------------------------------------------------
# Tests: multi-level inheritance
# ---------------------------------------------------------------------------

class TestMultiLevelInheritance:
    """Grandparent -> Parent -> Child chain."""

    def test_three_level_inheritance(self, tmp_path):
        # Grandparent
        gp_schema = tmp_path / "grandparent" / "schema"
        _write_types(gp_schema, """
Task:
  description: Grandparent task
  workflow: default
""")
        _write_workflows(gp_schema, """
default:
  states:
    - name: open
      group: unstarted
""")
        _write_labels(gp_schema, """
- name: core
  color: "#111111"
""")
        _write_plane_yaml(tmp_path / "grandparent", """
workspace: test
project:
  key: GP
""")

        # Parent (extends grandparent)
        parent_schema = tmp_path / "parent" / "schema"
        _write_types(parent_schema, """
Bug:
  description: Parent bug
  workflow: default
""")
        _write_workflows(parent_schema, "")
        _write_labels(parent_schema, """
- name: backend
  color: "#222222"
""")
        _write_plane_yaml(tmp_path / "parent", """
workspace: test
project:
  key: PAR
schema:
  extends: ../grandparent/schema
""")

        # Child (extends parent)
        child_schema = tmp_path / "child" / "schema"
        _write_types(child_schema, """
Feature:
  description: Child feature
  workflow: default
""")
        _write_workflows(child_schema, "")
        _write_labels(child_schema, """
- name: api
  color: "#333333"
""")

        types, workflows, labels = resolve_schema_inheritance(
            child_schema, "../parent/schema"
        )

        # Should have all three types
        type_names = {t.name for t in types}
        assert "Task" in type_names      # from grandparent
        assert "Bug" in type_names       # from parent
        assert "Feature" in type_names   # from child

        # Should have workflow from grandparent
        assert len(workflows) == 1
        assert workflows[0].name == "default"

        # Should have all three labels
        label_names = {l.name for l in labels}
        assert "core" in label_names     # from grandparent
        assert "backend" in label_names  # from parent
        assert "api" in label_names      # from child

    def test_grandchild_overrides_grandparent(self, tmp_path):
        """Child can override something defined in grandparent."""
        gp_schema = tmp_path / "grandparent" / "schema"
        _write_types(gp_schema, """
Task:
  description: Grandparent version
  workflow: default
""")
        _write_workflows(gp_schema, "")
        _write_labels(gp_schema, "")
        _write_plane_yaml(tmp_path / "grandparent", """
workspace: test
project:
  key: GP
""")

        parent_schema = tmp_path / "parent" / "schema"
        _write_types(parent_schema, "")
        _write_workflows(parent_schema, "")
        _write_labels(parent_schema, "")
        _write_plane_yaml(tmp_path / "parent", """
workspace: test
project:
  key: PAR
schema:
  extends: ../grandparent/schema
""")

        child_schema = tmp_path / "child" / "schema"
        _write_types(child_schema, """
Task:
  description: Child override
  workflow: custom
""")
        _write_workflows(child_schema, "")
        _write_labels(child_schema, "")

        types, _, _ = resolve_schema_inheritance(
            child_schema, "../parent/schema"
        )

        assert len(types) == 1
        assert types[0].description == "Child override"
        assert types[0].workflow == "custom"


# ---------------------------------------------------------------------------
# Tests: error cases
# ---------------------------------------------------------------------------

class TestErrorCases:
    """Error handling for invalid configurations."""

    def test_circular_dependency_raises_config_error(self, tmp_path):
        """Circular extends chain is detected and raises ConfigError."""
        # Project A extends B, B extends A
        a_schema = tmp_path / "project-a" / "schema"
        a_schema.mkdir(parents=True)
        _write_types(a_schema, "")
        _write_workflows(a_schema, "")
        _write_labels(a_schema, "")
        _write_plane_yaml(tmp_path / "project-a", """
workspace: test
project:
  key: A
schema:
  extends: ../project-b/schema
""")

        b_schema = tmp_path / "project-b" / "schema"
        b_schema.mkdir(parents=True)
        _write_types(b_schema, "")
        _write_workflows(b_schema, "")
        _write_labels(b_schema, "")
        _write_plane_yaml(tmp_path / "project-b", """
workspace: test
project:
  key: B
schema:
  extends: ../project-a/schema
""")

        with pytest.raises(ConfigError, match="Circular schema inheritance"):
            resolve_schema_inheritance(a_schema, "../project-b/schema")

    def test_missing_parent_path_raises_config_error(self, tmp_path):
        """Missing parent schema directory raises ConfigError."""
        child_schema = tmp_path / "child" / "schema"
        child_schema.mkdir(parents=True)

        with pytest.raises(ConfigError, match="Parent schema directory not found"):
            resolve_schema_inheritance(
                child_schema, "../nonexistent/schema"
            )

    def test_self_reference_raises_config_error(self, tmp_path):
        """A project extending its own schema dir raises ConfigError."""
        proj_schema = tmp_path / "project" / "schema"
        proj_schema.mkdir(parents=True)
        _write_types(proj_schema, "")
        _write_workflows(proj_schema, "")
        _write_labels(proj_schema, "")

        with pytest.raises(ConfigError, match="Circular schema inheritance"):
            resolve_schema_inheritance(proj_schema, "schema")


# ---------------------------------------------------------------------------
# Tests: unit tests for merge functions
# ---------------------------------------------------------------------------

class TestMergeTypesUnit:
    """Unit tests for _merge_types."""

    def test_empty_parent_returns_child(self):
        child = [WorkItemTypeDefinition(name="Task", workflow="default")]
        result = _merge_types([], child)
        assert len(result) == 1
        assert result[0].name == "Task"

    def test_empty_child_returns_parent(self):
        parent = [WorkItemTypeDefinition(name="Task", workflow="default")]
        result = _merge_types(parent, [])
        assert len(result) == 1
        assert result[0].name == "Task"

    def test_both_empty_returns_empty(self):
        result = _merge_types([], [])
        assert result == []

    def test_child_adds_new_type(self):
        parent = [WorkItemTypeDefinition(name="Task", workflow="default")]
        child = [WorkItemTypeDefinition(name="Bug", workflow="default")]
        result = _merge_types(parent, child)
        assert len(result) == 2
        names = {t.name for t in result}
        assert "Task" in names
        assert "Bug" in names

    def test_child_overrides_parent(self):
        parent = [WorkItemTypeDefinition(name="Task", description="old", workflow="default")]
        child = [WorkItemTypeDefinition(name="Task", description="new", workflow="custom")]
        result = _merge_types(parent, child)
        assert len(result) == 1
        assert result[0].description == "new"
        assert result[0].workflow == "custom"

    def test_child_omitted_scalars_preserve_parent_metadata(self):
        parent = [WorkItemTypeDefinition(
            name="Task",
            description="old",
            workflow="custom",
            parent_types=["Epic"],
            is_epic=True,
            is_default=True,
            level=2.0,
        )]
        child = [WorkItemTypeDefinition(name="Task", description="new")]
        result = _merge_types(parent, child)
        assert len(result) == 1
        assert result[0].description == "new"
        assert result[0].workflow == "custom"
        assert result[0].parent_types == ["Epic"]
        assert result[0].is_epic is True
        assert result[0].is_default is True
        assert result[0].level == 2.0


class TestMergeWorkflowsUnit:
    """Unit tests for _merge_workflows."""

    def test_empty_parent(self):
        child = [WorkflowDefinition(name="agile", states=[])]
        result = _merge_workflows([], child)
        assert len(result) == 1

    def test_child_replaces_parent(self):
        parent = [WorkflowDefinition(
            name="default",
            states=[StateDefinition(name="open", group="unstarted")],
        )]
        child = [WorkflowDefinition(
            name="default",
            states=[
                StateDefinition(name="todo", group="unstarted"),
                StateDefinition(name="done", group="completed"),
            ],
        )]
        result = _merge_workflows(parent, child)
        assert len(result) == 1
        assert len(result[0].states) == 2
        assert result[0].states[0].name == "todo"


class TestMergeLabelsUnit:
    """Unit tests for _merge_labels."""

    def test_empty_parent(self):
        child = [LabelDefinition(name="bug", color="#ff0000")]
        result = _merge_labels([], child)
        assert len(result) == 1

    def test_child_replaces_parent(self):
        parent = [LabelDefinition(name="bug", color="#ff0000")]
        child = [LabelDefinition(name="bug", color="#cc0000")]
        result = _merge_labels(parent, child)
        assert len(result) == 1
        assert result[0].color == "#cc0000"

    def test_child_adds_new(self):
        parent = [LabelDefinition(name="bug", color="#ff0000")]
        child = [LabelDefinition(name="feature", color="#00ff00")]
        result = _merge_labels(parent, child)
        assert len(result) == 2


# ---------------------------------------------------------------------------
# Tests: plane.yaml parsing with schema.extends
# ---------------------------------------------------------------------------

class TestPlaneYamlExtends:
    """Test that plane.yaml parser extracts schema.extends."""

    def test_parse_schema_extends(self, tmp_path):
        from planecompose.parser.plane_yaml import parse_plane_yaml

        plane_yaml = """
workspace: myteam
project:
  key: API
  name: API Service
schema:
  extends: ../base-project/schema
defaults:
  type: Task
"""
        yaml_path = tmp_path / "plane.yaml"
        yaml_path.write_text(plane_yaml)

        config = parse_plane_yaml(yaml_path)

        assert config.schema_extends == "../base-project/schema"

    def test_parse_no_schema_extends(self, tmp_path):
        from planecompose.parser.plane_yaml import parse_plane_yaml

        plane_yaml = """
workspace: myteam
project:
  key: API
  name: API Service
"""
        yaml_path = tmp_path / "plane.yaml"
        yaml_path.write_text(plane_yaml)

        config = parse_plane_yaml(yaml_path)

        assert config.schema_extends is None

    def test_parse_schema_without_extends(self, tmp_path):
        from planecompose.parser.plane_yaml import parse_plane_yaml

        plane_yaml = """
workspace: myteam
project:
  key: API
schema: {}
"""
        yaml_path = tmp_path / "plane.yaml"
        yaml_path.write_text(plane_yaml)

        config = parse_plane_yaml(yaml_path)

        assert config.schema_extends is None
