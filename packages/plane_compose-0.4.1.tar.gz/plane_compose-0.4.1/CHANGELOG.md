# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-02-24

### Added
- CI/CD with GitHub Actions (test matrix for Python 3.10-3.12, lint, PyPI publish)
- mypy configuration in pyproject.toml
- Platform-aware file locking (Windows fallback for fcntl)
- Graceful signal handling (Ctrl+C shows clean message, cleans up connections)
- New tests: client error translation, schema cache, config settings, clone state, validation (~70 new tests)

### Fixed
- **Clone state gap**: `plane clone` now populates `state.json` with tracking entries for cloned items, preventing duplicate pushes
- Connection cleanup: all async commands use try/finally to guarantee `backend.disconnect()`
- Narrowed broad `except Exception` handlers in client, state manager, and multiproject discovery
- CHANGELOG entries for v0.1.0 now reference correct command names

### Changed
- Version bumped to 1.0.0 (Production/Stable)
- Development Status classifier updated to "5 - Production/Stable"

## [0.4.0] - 2026-01-15

### Added
- **Multi-project support**: `--all`, `--workspace`, `--filter` flags for push/pull
- **Terraform-style schema import**: `plane schema import` with `--merge` and `--force` modes
- **Schema diff**: `plane schema diff` to compare local vs remote schema
- **Schema sync**: `plane schema sync` for declarative schema management
- **Batch operations**: `run_batch()` with configurable concurrency
- Project discovery with `.planeignore` support

## [0.3.0] - 2025-12-30

### Added
- **Backend refactor**: PlaneApiClient with centralized rate limiting and error translation
- **SchemaCache**: O(1) lookups for types, states, and labels
- **SyncPlanner/SyncExecutor**: Parallel batch processing for 5x faster syncs
- **State management**: File locking with `StateManager`, atomic writes, backup/restore
- **State CLI**: `plane state show`, `plane state reset`, `plane state clear-items`
- Custom exception hierarchy (APIError, AuthenticationError, etc.)

## [0.2.0] - 2025-12-20

### Added
- Support for self-hosted Plane editions
- Configurable API URL via `PLANE_API_URL` environment variable

## [0.1.0] - 2025-12-15

### Added
- Initial release of Plane Compose
- **Core Features:**
  - Local-first workflow with YAML-based project definitions
  - Bidirectional sync between local files and Plane platform
  - Auto-create projects during schema push
  - Secure API key authentication
  - Beautiful CLI with Rich terminal UI

- **Schema Management:**
  - Work item types with custom properties
  - Workflow definitions with states and transitions
  - Label management with groups and colors
  - Schema validation and push commands

- **Work Item Management:**
  - Collaborative mode (`plane push`) - additive-only, team-friendly
  - Intelligent content-based change detection
  - Stable ID support via user-defined IDs or content hashing
  - State tracking with `.plane/state.json`

- **CLI Commands:**
  - `plane init` - Initialize new project structure
  - `plane auth login/logout/whoami` - Authentication management
  - `plane schema validate/push` - Schema operations
  - `plane push` - Push work items to Plane
  - `plane pull` - Pull work items from Plane
  - `plane clone` - Clone existing projects from Plane
  - `plane status` - Show sync status
  - `plane rate stats/reset` - Rate limit monitoring

- **Advanced Features:**
  - Built-in rate limiting (50 req/min by default)
  - Respects Plane API rate limits with automatic throttling
  - Debug mode with comprehensive logging
  - Environment variable configuration support
  - Dry-run support for preview before changes

- **Documentation:**
  - Comprehensive README with quick start guide
  - Architecture documentation
  - Development guide
  - Troubleshooting guide

### Technical Details
- Python 3.10+ support
- Built with Typer, Rich, Pydantic, and Plane SDK
- Clean architecture with separation of concerns
- Type hints throughout codebase
- Formatted with Black, linted with Ruff

[1.0.0]: https://github.com/makeplane/compose/releases/tag/v1.0.0
[0.4.0]: https://github.com/makeplane/compose/releases/tag/v0.4.0
[0.3.0]: https://github.com/makeplane/compose/releases/tag/v0.3.0
[0.2.0]: https://github.com/makeplane/compose/releases/tag/v0.2.0
[0.1.0]: https://github.com/makeplane/compose/releases/tag/v0.1.0
