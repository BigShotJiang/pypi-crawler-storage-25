"""
End-to-end tests for project-level commands and schema management.

Run inside the Docker container:
    cd /code && pytest e2e-tests/test_project.py -v -x

Tests are sequential — each builds on state left by the previous one.
Use -x (stop on first failure) to avoid cascading failures.

Template markers used for assertions:
    template-v1 → "Release Pending" state, all features disabled
    template-v2 → "Icebox" state, features enabled, adds "Production" label

No pre-existing project is needed in test.env.  The test suite:
    1. init     — create a fresh project from template-v1 in /workspace/<KEY>/
    2. push     — create the project on Plane (reads connection from plane.yaml)
    3. upgrade  — upgrade to template-v2 locally + push schema
    4. clone    — clone the remote project into /workspace/clones/<KEY>/
    5. schema   — validate / diff / push / import / sync on the init'd project
"""

from __future__ import annotations

import shutil
import time
from pathlib import Path

import pytest
import yaml

from helpers import run_plane

# ── Constants ─────────────────────────────────────────────────────────────────
TEST_CONN   = "e2e-proj-conn"
WORKSPACE   = Path("/workspace")

# Unique project key per run: "ET" + zero-padded 5-digit epoch tail → e.g. ET09153
PROJECT_KEY = f"ET{int(time.time()) % 100000:05d}"

# Separate parent for all clone operations — avoids collision with the init dir
CLONE_BASE  = WORKSPACE / "clones"

# Unique names for schema objects added during the schema test section
E2E_STATE    = "E2E-Test-State"
E2E_LABEL    = "E2E-Test-Label"
E2E_TYPE     = "E2ETask"
E2E_WORKFLOW = "E2E Workflow"

# ── Mutable state shared across tests ─────────────────────────────────────────
_proj: dict = {}


# ── YAML mutation helpers (used by schema test section) ───────────────────────

def _states_path() -> Path:
    return _proj["init_dir"] / "schema" / "states.yaml"

def _labels_path() -> Path:
    return _proj["init_dir"] / "schema" / "labels.yaml"

def _types_path() -> Path:
    return _proj["init_dir"] / "schema" / "types.yaml"

def _workflows_path() -> Path:
    return _proj["init_dir"] / "schema" / "workflows.yaml"


def _add_state(name: str, group: str = "started", color: str = "#FF6600") -> None:
    path = _states_path()
    data = yaml.safe_load(path.read_text())
    data["states"][name] = {
        "group": group,
        "color": color,
        "allow_issue_creation": False,
        "is_default": False,
    }
    path.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))


def _edit_state_color(name: str, color: str) -> None:
    path = _states_path()
    data = yaml.safe_load(path.read_text())
    data["states"][name]["color"] = color
    path.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))


def _add_label(name: str, color: str = "#FF0000") -> None:
    path = _labels_path()
    data = yaml.safe_load(path.read_text())
    data["labels"].append({"name": name, "color": color})
    path.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))


def _edit_label_color(name: str, color: str) -> None:
    path = _labels_path()
    data = yaml.safe_load(path.read_text())
    for label in data["labels"]:
        if label["name"] == name:
            label["color"] = color
            break
    path.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))


def _add_type(name: str) -> None:
    path = _types_path()
    data = yaml.safe_load(path.read_text())
    if not data.get("work_item_types"):
        data["work_item_types"] = {}
    data["work_item_types"][name] = {
        "description": f"Custom type added by e2e tests ({name})",
        "properties": [
            {"name": "severity", "type": "option", "options": ["low", "medium", "high"]},
            {"name": "notes",    "type": "text"},
        ],
    }
    path.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))


def _add_workflow(name: str) -> None:
    path = _workflows_path()
    data = yaml.safe_load(path.read_text())
    if not data.get("workflows"):
        data["workflows"] = {}
    data["workflows"][name] = {
        "description": "E2E test workflow",
        "is_active": False,
        "is_default": False,
        "work_item_types": ["Bug"],
        "states": ["Backlog", "In Progress", "Done"],
        "transitions": {
            "Backlog":     [{"to": "In Progress", "type": "transition"}],
            "In Progress": [{"to": "Done",        "type": "transition"},
                            {"to": "Backlog",     "type": "transition"}],
            "Done": {},
        },
    }
    path.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))


# ── Module-scoped setup / teardown ────────────────────────────────────────────

@pytest.fixture(autouse=True, scope="module")
def proj_setup(project_env):
    """Login and wipe /workspace before the suite; logout and clean up after."""
    run_plane("auth", "logout", TEST_CONN, "--force")
    for child in WORKSPACE.iterdir():
        shutil.rmtree(child) if child.is_dir() else child.unlink()
    CLONE_BASE.mkdir(parents=True, exist_ok=True)

    code, out = run_plane(
        "auth", "login",
        "--server-url", project_env["PLANE_SERVER_URL"],
        "--auth-type",  project_env["PLANE_AUTH_TYPE"],
        "--token",      project_env["PLANE_TOKEN"],
        "--workspace",  project_env["PLANE_WORKSPACE"],
        "--connection", TEST_CONN,
    )
    assert code == 0, f"auth login failed during proj_setup\n{out}"

    yield

    run_plane("auth", "logout", TEST_CONN, "--force")
    for child in WORKSPACE.iterdir():
        shutil.rmtree(child) if child.is_dir() else child.unlink()


# =============================================================================
# 1. plane init
# =============================================================================

def test_init_basic_exits_0(project_env):
    """init with template-v1, no --path → project created in cwd (/workspace)."""
    code, out = run_plane(
        "init", PROJECT_KEY,
        "--workspace",  project_env["PLANE_WORKSPACE"],
        "--connection", TEST_CONN,
        "--template",   project_env["PLANE_INIT_TEMPLATE"],
        cwd=WORKSPACE,
    )
    _proj["init_dir"] = WORKSPACE / PROJECT_KEY.lower()   # plane lowercases the dir name
    assert code == 0, f"expected exit 0\n{out}"


def test_init_project_folder_created():
    assert _proj["init_dir"].exists(), f"{_proj['init_dir']} not created"


def test_init_plane_yaml_exists():
    assert (_proj["init_dir"] / "plane.yaml").exists()


def test_init_plane_yaml_non_empty():
    assert (_proj["init_dir"] / "plane.yaml").stat().st_size > 0


def test_init_schema_dir_exists():
    assert (_proj["init_dir"] / "schema").is_dir()


def test_init_work_dir_exists():
    assert (_proj["init_dir"] / "work").is_dir()


@pytest.mark.parametrize("filename", [
    "states.yaml", "labels.yaml",
    "types.yaml", "workflows.yaml", "members.yaml",
])
def test_init_schema_file_exists(filename):
    assert (_proj["init_dir"] / "schema" / filename).exists(), (
        f"schema/{filename} missing after init"
    )


def test_init_template_v1_state_present():
    """template-v1 includes a 'Release Pending' state — confirms template was applied."""
    content = (_proj["init_dir"] / "schema" / "states.yaml").read_text()
    assert "Release Pending" in content, (
        f"'Release Pending' state not found — template-v1 may not have been applied\n{content}"
    )


# ── 1. plane init — --path flag ───────────────────────────────────────────────

def test_init_custom_path_exits_0(project_env):
    """--path directs the project into a specific parent directory."""
    code, out = run_plane(
        "init", PROJECT_KEY,
        "--workspace",  project_env["PLANE_WORKSPACE"],
        "--connection", TEST_CONN,
        "--template",   project_env["PLANE_INIT_TEMPLATE"],
        "--path",       str(WORKSPACE / "custom-init"),
    )
    _proj["custom_init_dir"] = WORKSPACE / "custom-init" / PROJECT_KEY.lower()
    assert code == 0, f"expected exit 0\n{out}"


def test_init_custom_path_plane_yaml_exists():
    assert (_proj["custom_init_dir"] / "plane.yaml").exists()


# ── 1. plane init — negative cases ───────────────────────────────────────────

def test_init_without_workspace_fails():
    code, out = run_plane("init", PROJECT_KEY, cwd=WORKSPACE)
    assert code != 0, f"expected non-zero exit without --workspace\n{out}"


def test_init_into_existing_directory_fails(project_env):
    """Re-running init for the same key in the same cwd should fail."""
    code, out = run_plane(
        "init", PROJECT_KEY,
        "--workspace",  project_env["PLANE_WORKSPACE"],
        "--connection", TEST_CONN,
        "--template",   project_env["PLANE_INIT_TEMPLATE"],
        cwd=WORKSPACE,
    )
    assert code != 0, f"expected non-zero exit — directory already exists\n{out}"


# =============================================================================
# 2. plane push  (creates the project on remote for the first time)
#    Connection is read from plane.yaml — no --connection needed after init.
# =============================================================================

def test_push_creates_project_on_remote():
    code, out = run_plane(
        "push", PROJECT_KEY.lower(),   # dir name is lowercased by plane init
        "--path",  str(WORKSPACE),
        "--force",
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_push_plane_yaml_still_valid():
    """plane.yaml must be non-empty valid YAML after push (no corruption)."""
    content = (_proj["init_dir"] / "plane.yaml").read_text()
    assert yaml.safe_load(content) is not None


# =============================================================================
# 3. plane upgrade  (apply template-v2 to the existing project)
# =============================================================================

def test_upgrade_dry_run_exits_0(project_env):
    """Dry-run should show a diff without modifying any files."""
    code, out = run_plane(
        "upgrade", PROJECT_KEY.lower(),
        "--path",     str(WORKSPACE),
        "--template", project_env["PLANE_UPGRADE_TEMPLATE"],
        "--dry-run",
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_upgrade_applies_template_v2(project_env):
    """Apply template-v2 locally; --skip-pull + --schema-only avoids a push at this step."""
    code, out = run_plane(
        "upgrade", PROJECT_KEY.lower(),
        "--path",      str(WORKSPACE),
        "--template",  project_env["PLANE_UPGRADE_TEMPLATE"],
        "--force",
        "--skip-pull",
        "--schema-only",
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_upgrade_template_v2_state_present():
    """template-v2 introduces an 'Icebox' state."""
    content = (_proj["init_dir"] / "schema" / "states.yaml").read_text()
    assert "Icebox" in content, (
        f"'Icebox' state not found after upgrade to template-v2\n{content}"
    )


def test_upgrade_template_v2_label_present():
    """template-v2 adds 'Production' and 'Development' labels."""
    content = (_proj["init_dir"] / "schema" / "labels.yaml").read_text()
    assert "Production" in content, (
        f"'Production' label not found after upgrade to template-v2\n{content}"
    )


def test_upgrade_include_data_copies_cycles(project_env):
    """--include-data also copies work data from the template.

    template-v2 ships a 'Sprint 0' cycle (template-v1 has an empty cycles list),
    so after upgrade with --include-data the cycle must appear in work/cycles.yaml.
    """
    code, out = run_plane(
        "upgrade", PROJECT_KEY.lower(),
        "--path",         str(WORKSPACE),
        "--template",     project_env["PLANE_UPGRADE_TEMPLATE"],
        "--force",
        "--skip-pull",
        "--include-data",
    )
    assert code == 0, f"expected exit 0\n{out}"
    content = (_proj["init_dir"] / "work" / "cycles.yaml").read_text()
    assert "Sprint 0" in content, (
        f"'Sprint 0' cycle not found after upgrade with --include-data\n{content}"
    )


def test_upgrade_push_upgraded_schema():
    """Push the upgraded schema to remote so clone tests see template-v2.
    Connection is read from plane.yaml — no --connection needed after init.
    """
    code, out = run_plane(
        "push", PROJECT_KEY.lower(),
        "--path",        str(WORKSPACE),
        "--schema-only",
        "--force",
    )
    assert code == 0, f"expected exit 0\n{out}"


# =============================================================================
# 4. plane clone  (clone the remote project that was just created + upgraded)
#
# All clone variants go into CLONE_BASE (/workspace/clones/) so they never
# conflict with the init'd project at /workspace/<KEY>/.
# =============================================================================

def test_clone_by_shorthand_exits_0(project_env):
    """Clone using workspace/KEY shorthand, no --path → clones into cwd (CLONE_BASE)."""
    shorthand = f"{project_env['PLANE_WORKSPACE']}/{PROJECT_KEY}"
    code, out = run_plane(
        "clone", shorthand,
        "--connection", TEST_CONN,
        cwd=CLONE_BASE,
    )
    # Resolve actual clone directory — plane may use the remote key or lowercase it
    for candidate in (CLONE_BASE / PROJECT_KEY, CLONE_BASE / PROJECT_KEY.lower()):
        if candidate.exists():
            _proj["clone_dir"] = candidate
            break
    else:
        pytest.fail(f"clone directory not found under {CLONE_BASE}")
    assert code == 0, f"expected exit 0\n{out}"


def test_clone_plane_yaml_exists():
    assert (_proj["clone_dir"] / "plane.yaml").exists()


def test_clone_schema_dir_exists():
    assert (_proj["clone_dir"] / "schema").is_dir()


def test_clone_work_dir_exists():
    assert (_proj["clone_dir"] / "work").is_dir()


def test_clone_reflects_upgraded_schema():
    """Cloned project should have the Icebox state from the template-v2 upgrade."""
    content = (_proj["clone_dir"] / "schema" / "states.yaml").read_text()
    assert "Icebox" in content, (
        f"'Icebox' not found in cloned project — upgrade push may not have landed\n{content}"
    )


# ── 4. plane clone — --path flag ─────────────────────────────────────────────

def test_clone_with_path(project_env):
    """--path directs the clone into a specific parent directory."""
    shorthand = f"{project_env['PLANE_WORKSPACE']}/{PROJECT_KEY}"
    code, out = run_plane(
        "clone", shorthand,
        "--connection", TEST_CONN,
        "--path",       str(CLONE_BASE / "custom"),
    )
    for candidate in (CLONE_BASE / "custom" / PROJECT_KEY, CLONE_BASE / "custom" / PROJECT_KEY.lower()):
        if candidate.exists():
            _proj["clone_path_dir"] = candidate
            break
    else:
        pytest.fail(f"clone directory not found under {CLONE_BASE / 'custom'}")
    assert code == 0, f"expected exit 0\n{out}"


def test_clone_with_path_plane_yaml_exists():
    assert (_proj["clone_path_dir"] / "plane.yaml").exists()


# ── 4. plane clone — --schema-only ───────────────────────────────────────────

def test_clone_schema_only(project_env):
    shorthand = f"{project_env['PLANE_WORKSPACE']}/{PROJECT_KEY}"
    code, out = run_plane(
        "clone", shorthand,
        "--connection",  TEST_CONN,
        "--path",        str(CLONE_BASE / "schema-only"),
        "--schema-only",
    )
    for candidate in (CLONE_BASE / "schema-only" / PROJECT_KEY, CLONE_BASE / "schema-only" / PROJECT_KEY.lower()):
        if candidate.exists():
            _proj["clone_schema_dir"] = candidate
            break
    else:
        pytest.fail(f"clone directory not found under {CLONE_BASE / 'schema-only'}")
    assert code == 0, f"expected exit 0\n{out}"


def test_clone_schema_only_plane_yaml_exists():
    assert (_proj["clone_schema_dir"] / "plane.yaml").exists()


# ── 4. plane clone — --skip workitems ────────────────────────────────────────

def test_clone_skip_workitems(project_env):
    shorthand = f"{project_env['PLANE_WORKSPACE']}/{PROJECT_KEY}"
    code, out = run_plane(
        "clone", shorthand,
        "--connection", TEST_CONN,
        "--path",       str(CLONE_BASE / "skip-wi"),
        "--skip",       "workitems",
    )
    for candidate in (CLONE_BASE / "skip-wi" / PROJECT_KEY, CLONE_BASE / "skip-wi" / PROJECT_KEY.lower()):
        if candidate.exists():
            _proj["clone_skip_dir"] = candidate
            break
    else:
        pytest.fail(f"clone directory not found under {CLONE_BASE / 'skip-wi'}")
    assert code == 0, f"expected exit 0\n{out}"


def test_clone_skip_workitems_plane_yaml_exists():
    assert (_proj["clone_skip_dir"] / "plane.yaml").exists()


# ── 4. plane clone — negative cases ──────────────────────────────────────────

def test_clone_nonexistent_project_fails(project_env):
    code, out = run_plane(
        "clone", f"{project_env['PLANE_WORKSPACE']}/PROJDOESNOTEXIST",
        "--connection", TEST_CONN,
        "--path",       str(CLONE_BASE / "neg"),
    )
    assert code == 1, f"expected exit 1\n{out}"


def test_clone_into_existing_directory_fails(project_env):
    """Cloning the same project into an already-cloned cwd should fail."""
    shorthand = f"{project_env['PLANE_WORKSPACE']}/{PROJECT_KEY}"
    code, out = run_plane(
        "clone", shorthand,
        "--connection", TEST_CONN,
        cwd=CLONE_BASE,   # CLONE_BASE/PROJECT_KEY already exists from test_clone_by_shorthand
    )
    assert code != 0, f"expected non-zero exit — directory already exists\n{out}"


# =============================================================================
# 5. plane schema validate
#    Run on the init'd project (which is at template-v2 after upgrade).
#    schema commands read connection from plane.yaml — no --connection needed.
# =============================================================================

def test_schema_validate_baseline_exits_0():
    """Valid schema (template-v2) should pass offline validation."""
    code, out = run_plane(
        "schema", "validate", PROJECT_KEY.lower(),
        "--path", str(WORKSPACE),
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_schema_validate_detects_invalid_yaml():
    """Corrupt states.yaml should cause validate to exit non-zero."""
    states_file = _states_path()
    original = states_file.read_text()
    states_file.write_text("states:\n  - bad: [unclosed\n")
    try:
        code, out = run_plane(
            "schema", "validate", PROJECT_KEY.lower(),
            "--path", str(WORKSPACE),
        )
        assert code != 0, f"expected non-zero exit for invalid YAML\n{out}"
    finally:
        states_file.write_text(original)   # always restore


def test_schema_validate_after_restore_exits_0():
    """After restoring states.yaml, validation should pass again."""
    code, out = run_plane(
        "schema", "validate", PROJECT_KEY.lower(),
        "--path", str(WORKSPACE),
    )
    assert code == 0, f"expected exit 0 after restore\n{out}"


# =============================================================================
# 6. plane schema diff — baseline (just pushed via upgrade, should be in sync)
# =============================================================================

def test_schema_diff_baseline_exits_0():
    code, out = run_plane(
        "schema", "diff", PROJECT_KEY.lower(),
        "--path", str(WORKSPACE),
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_schema_diff_baseline_no_local_only_items():
    """After push, nothing should be 'only in local'.

    Plane may auto-create default work item types (e.g. 'Task') on the remote
    during project creation — those show as 'only in remote' and are expected.
    What we verify is that no local items were missed by push.
    """
    code, out = run_plane(
        "schema", "diff", PROJECT_KEY.lower(),
        "--path", str(WORKSPACE),
    )
    assert code == 0, f"expected exit 0\n{out}"
    assert "Only in local" not in out, (
        f"Unexpected local-only items in baseline diff — push may have missed something\n{out}"
    )


# =============================================================================
# 7. Mutate all schema objects locally (YAML only — no API calls)
# =============================================================================

def test_mutate_add_state():
    _add_state(E2E_STATE, group="started", color="#FF6600")
    assert E2E_STATE in _states_path().read_text()


def test_mutate_edit_state_color():
    _edit_state_color("Icebox", "#123456")   # Icebox is present after template-v2
    data = yaml.safe_load(_states_path().read_text())
    assert data["states"]["Icebox"]["color"] == "#123456"


def test_mutate_add_label():
    _add_label(E2E_LABEL, color="#FF0000")
    assert E2E_LABEL in _labels_path().read_text()


def test_mutate_edit_label_color():
    _edit_label_color("Production", "#AABBCC")   # Production is added by template-v2
    data = yaml.safe_load(_labels_path().read_text())
    prod = next(lb for lb in data["labels"] if lb["name"] == "Production")
    assert prod["color"] == "#AABBCC"


def test_mutate_add_type():
    _add_type(E2E_TYPE)
    assert E2E_TYPE in _types_path().read_text()


def test_mutate_add_workflow():
    _add_workflow(E2E_WORKFLOW)
    assert E2E_WORKFLOW in _workflows_path().read_text()


# =============================================================================
# 8. plane schema validate — after mutations (all still valid YAML)
# =============================================================================

def test_schema_validate_after_mutations():
    code, out = run_plane(
        "schema", "validate", PROJECT_KEY.lower(),
        "--path", str(WORKSPACE),
    )
    assert code == 0, f"schema invalid after mutations\n{out}"


# =============================================================================
# 9. plane schema diff — detects mutations
# =============================================================================

def test_schema_diff_detects_mutations():
    code, out = run_plane(
        "schema", "diff", PROJECT_KEY.lower(),
        "--path", str(WORKSPACE),
    )
    assert code == 0, f"expected exit 0\n{out}"
    # Output should mention at least one of our changed objects
    assert any(token in out for token in (E2E_STATE, E2E_LABEL, E2E_TYPE, "diff", "change")), (
        f"expected diff output to mention schema changes\n{out}"
    )


def test_schema_diff_exit_code_shows_diff():
    """--exit-code exits 2 when there are differences."""
    code, out = run_plane(
        "schema", "diff", PROJECT_KEY.lower(),
        "--path",      str(WORKSPACE),
        "--exit-code",
    )
    assert code == 2, f"expected exit 2 (differences found)\n{out}"


# =============================================================================
# 10. plane schema push
# =============================================================================

def test_schema_push_dry_run():
    code, out = run_plane(
        "schema", "push", PROJECT_KEY.lower(),
        "--path",    str(WORKSPACE),
        "--dry-run",
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_schema_push_applies_changes():
    code, out = run_plane(
        "schema", "push", PROJECT_KEY.lower(),
        "--path",  str(WORKSPACE),
        "--force",
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_schema_push_states_labels_synced():
    """After push, states and labels should be in sync (not 'only in local').

    Note: types and workflows may remain local-only — they are fully synced
    by schema sync rather than schema push.
    """
    code, out = run_plane(
        "schema", "diff", PROJECT_KEY.lower(),
        "--path", str(WORKSPACE),
    )
    assert code == 0, f"expected exit 0\n{out}"
    # E2E_STATE should no longer appear as "only in local"
    assert E2E_STATE not in out, (
        f"'{E2E_STATE}' still showing in diff after push — states not synced\n{out}"
    )
    # E2E_LABEL should no longer appear as "only in local"
    assert E2E_LABEL not in out, (
        f"'{E2E_LABEL}' still showing in diff after push — labels not synced\n{out}"
    )


# =============================================================================
# 11. plane schema import
# =============================================================================

def test_schema_import_default_exits_0():
    """Default import: map local schema names to remote UUIDs (state.json only)."""
    code, out = run_plane(
        "schema", "import", PROJECT_KEY.lower(),
        "--path", str(WORKSPACE),
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_schema_import_merge_exits_0():
    """--merge: add missing remote items to local (additive, no overwrites)."""
    code, out = run_plane(
        "schema", "import", PROJECT_KEY.lower(),
        "--path",  str(WORKSPACE),
        "--merge",
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_schema_import_merge_preserves_local_additions():
    """Local-only additions (E2E-Test-Label) must survive a --merge import."""
    assert E2E_LABEL in _labels_path().read_text(), (
        f"'{E2E_LABEL}' was wiped by schema import --merge"
    )


def test_schema_import_force_exits_0():
    """--force: overwrite local schema files with remote (DESTRUCTIVE)."""
    code, out = run_plane(
        "schema", "import", PROJECT_KEY.lower(),
        "--path",  str(WORKSPACE),
        "--force",
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_schema_import_force_no_local_only_items():
    """After --force import, no local-only items should remain.

    Plane may retain platform-internal types with empty names on the remote
    that schema import intentionally does not pull locally — those are safe to
    ignore.  What we verify is that nothing is 'only in local'.
    """
    code, out = run_plane(
        "schema", "diff", PROJECT_KEY.lower(),
        "--path", str(WORKSPACE),
    )
    assert code == 0, f"expected exit 0\n{out}"
    assert "Only in local" not in out, (
        f"Local-only items found after import --force\n{out}"
    )


# =============================================================================
# 12. plane schema sync
# =============================================================================

def test_schema_sync_dry_run_exits_0():
    """Dry-run sync shows what would change without modifying anything."""
    code, out = run_plane(
        "schema", "sync", PROJECT_KEY.lower(),
        "--path",    str(WORKSPACE),
        "--dry-run",
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_schema_sync_force_exits_0():
    """Declarative sync — make remote match local exactly."""
    code, out = run_plane(
        "schema", "sync", PROJECT_KEY.lower(),
        "--path",  str(WORKSPACE),
        "--force",
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_schema_sync_diff_after_sync():
    """After sync, no local-only items should remain.

    Plane may retain platform-internal types with empty names on the remote
    that schema sync cannot remove — those are system-managed and safe to
    ignore.  What we verify is that nothing is 'only in local'.
    """
    code, out = run_plane(
        "schema", "diff", PROJECT_KEY.lower(),
        "--path", str(WORKSPACE),
    )
    assert code == 0, f"expected exit 0\n{out}"
    assert "Only in local" not in out, (
        f"Local-only items found after sync\n{out}"
    )
