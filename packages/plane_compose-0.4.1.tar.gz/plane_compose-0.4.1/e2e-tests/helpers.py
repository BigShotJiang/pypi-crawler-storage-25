"""Shared helpers for the plane-compose e2e test suite."""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Union

E2E_DIR = Path(__file__).parent

# Last command record — populated by run_plane(), read by the log plugin.
# Stored as a module-level dict so conftest.py can import and inspect it
# without circular dependencies.
last_call: dict[str, object] = {
    "cmd": [],    # list[str]      — the full command that was run
    "cwd": None,  # str | None     — working directory (None = default)
    "code": 0,    # int            — exit code
    "out": "",    # str            — combined stdout + stderr
}


def run_plane(*args: str, cwd: Union[str, Path, None] = None) -> tuple[int, str]:
    """Run `plane <args>` and return (exit_code, combined stdout+stderr).

    ``cwd`` sets the working directory for the subprocess — useful for testing
    commands that rely on the current directory (e.g. ``plane ws clone`` without
    an explicit ``--path``).

    Also writes the command, cwd, exit code, and output into ``last_call`` so
    the log plugin in conftest.py can include them in the test log.
    """
    cmd = ["plane", *args]
    result = subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)
    out = (result.stdout + result.stderr).strip()

    last_call["cmd"] = cmd
    last_call["cwd"] = str(cwd) if cwd is not None else None
    last_call["code"] = result.returncode
    last_call["out"] = out

    return result.returncode, out


def load_env() -> dict[str, str]:
    """Parse ``e2e-tests/test.env``, stripping inline comments.

    Returns a plain dict of key→value pairs.  Raises ``FileNotFoundError``
    if the file is missing (callers should surface a helpful message).
    """
    env_file = E2E_DIR / "test.env"
    if not env_file.exists():
        raise FileNotFoundError(
            f"test.env not found at {env_file}\n"
            "Copy e2e-tests/test.env.example and fill in your credentials."
        )
    parsed: dict[str, str] = {}
    for raw in env_file.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        parsed[key.strip()] = val.split("#")[0].strip()
    return parsed
