"""pytest configuration and shared fixtures for the e2e test suite."""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import IO

import pytest

from helpers import E2E_DIR, last_call, load_env, run_plane


# ── Log file plugin ───────────────────────────────────────────────────────────

_ANSI = re.compile(r"\x1b\[[0-9;]*[mA-Z]")


class _E2ELogPlugin:
    """Write a plain-text (ANSI-stripped) copy of every test result to a file.

    Hooks used:
      pytest_runtest_logreport  — called after setup / call / teardown phases
      pytest_sessionfinish      — write the summary line and close the file
    """

    def __init__(self, log_path: Path) -> None:
        self._path = log_path
        self._f: IO[str] = log_path.open("w", encoding="utf-8")
        self._results: list[tuple[str, str]] = []  # [(nodeid, status)]
        self._started_at = datetime.now()
        self._f.write(
            f"plane-compose e2e — {self._started_at.strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"{'=' * 70}\n\n"
        )

    def _strip(self, text: str) -> str:
        return _ANSI.sub("", text)

    def pytest_runtest_logreport(self, report: pytest.TestReport) -> None:  # type: ignore[override]
        if report.when != "call":
            return
        if report.passed:
            status = "PASS"
        elif report.failed:
            status = "FAIL"
        else:
            status = "SKIP"

        # Grab a snapshot of what run_plane() ran (may be empty for tests that
        # don't call run_plane — e.g. pure-Python assertions).
        cmd: list = last_call.get("cmd", [])   # type: ignore[assignment]
        out: str  = last_call.get("out", "")   # type: ignore[assignment]
        code: int = last_call.get("code", 0)   # type: ignore[assignment]

        # ── Write shell-script-style block ───────────────────────────────────
        # Strip module prefix from node id for a shorter, readable label
        label = report.nodeid.split("::")[-1]
        self._f.write(f"\n  ▶ {label}\n")

        if cmd:
            cwd: str | None = last_call.get("cwd")  # type: ignore[assignment]
            if cwd:
                self._f.write(f"  [cwd: {cwd}]\n")
            self._f.write(f"  $ {' '.join(str(c) for c in cmd)}\n")
            if out:
                for line in out.splitlines():
                    self._f.write(f"      {self._strip(line)}\n")
            self._f.write(f"  exit: {code}\n")

        self._f.write(f"  {status}  {report.nodeid}\n\n")
        self._results.append((report.nodeid, status))

        # On failure, append the assertion traceback for quick diagnosis.
        if report.failed:
            if report.capstdout:
                self._f.write("  --- captured stdout ---\n")
                for line in report.capstdout.splitlines():
                    self._f.write(f"  {self._strip(line)}\n")
            if report.capstderr:
                self._f.write("  --- captured stderr ---\n")
                for line in report.capstderr.splitlines():
                    self._f.write(f"  {self._strip(line)}\n")
            if hasattr(report, "longreprtext"):
                self._f.write("  --- traceback ---\n")
                for line in report.longreprtext.splitlines():
                    self._f.write(f"  {self._strip(line)}\n")

    def pytest_sessionfinish(self, exitstatus: int) -> None:
        passed = sum(1 for _, s in self._results if s == "PASS")
        failed = sum(1 for _, s in self._results if s == "FAIL")
        skipped = sum(1 for _, s in self._results if s == "SKIP")
        elapsed = datetime.now() - self._started_at
        total_s = int(elapsed.total_seconds())
        duration = f"{total_s // 60}m {total_s % 60}s"
        self._f.write(
            f"\n{'=' * 70}\n"
            f"PASS: {passed}  FAIL: {failed}  SKIP: {skipped}\n"
            f"Time: {duration}  ({total_s}s total)\n"
        )
        self._f.close()
        print(f"\n[log] Written to {self._path}")


def pytest_configure(config: pytest.Config) -> None:
    """Register the log-file plugin as early as possible."""
    log_dir = E2E_DIR / "logs"
    log_dir.mkdir(exist_ok=True)

    # Derive a short suffix from the test paths / files being collected so the
    # log filename makes it obvious what was tested.
    # e.g. "pytest e2e-tests/test_auth.py" → "auth"
    #      "pytest e2e-tests/"             → "all"
    args = config.args  # list of paths/files passed on the CLI
    suffixes = []
    for arg in args:
        name = Path(arg).stem          # "test_auth" from "e2e-tests/test_auth.py"
        if name.startswith("test_"):
            suffixes.append(name[len("test_"):])   # → "auth"
    suffix = "_".join(suffixes) if suffixes else "all"

    log_path = log_dir / f"pytest_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{suffix}.log"
    config.pluginmanager.register(_E2ELogPlugin(log_path), name="e2e-log-plugin")


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def env() -> dict[str, str]:
    """Load and validate test.env, failing fast with a clear message."""
    try:
        data = load_env()
    except FileNotFoundError as exc:
        pytest.exit(f"\n[ERROR] {exc}")

    required = ("PLANE_SERVER_URL", "PLANE_AUTH_TYPE", "PLANE_TOKEN", "PLANE_WORKSPACE")
    for var in required:
        if not data.get(var) or "your_" in data[var]:
            pytest.exit(
                f"\n[ERROR] {var} is not set (or still a placeholder) in test.env"
            )
    return data


@pytest.fixture(scope="session")
def project_env(env: dict[str, str]) -> dict[str, str]:
    """Extend env with template URLs required for test_project.py."""
    required = ("PLANE_INIT_TEMPLATE", "PLANE_UPGRADE_TEMPLATE")
    for var in required:
        if not env.get(var) or "your_" in env[var]:
            pytest.exit(
                f"\n[ERROR] {var} is not set (or still a placeholder) in test.env\n"
                f"        Copy the values from test.env.example."
            )
    return env


@pytest.fixture(autouse=True)
def reset_last_call():
    """Clear last_call before each test.

    Ensures tests that don't call run_plane() (e.g. file-existence checks)
    don't inherit the previous test's command and output in the log.
    """
    last_call["cmd"] = []
    last_call["cwd"] = None
    last_call["code"] = 0
    last_call["out"] = ""
    yield


@pytest.fixture(scope="session", autouse=True)
def global_cleanup():
    """Best-effort cleanup of any stale e2e connections before the full suite."""
    for conn in ("e2e-pytest-conn", "e2e-other-conn", "e2e-bad-conn", "e2e-ws-conn"):
        run_plane("auth", "logout", conn, "--force")
    yield
    # post-suite cleanup handled by individual test modules
