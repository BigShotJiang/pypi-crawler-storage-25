"""
End-to-end tests for `plane ws` commands.

Run inside the Docker container:
    cd /workspace && pytest e2e-tests/test_ws.py -v -x

Tests are intentionally sequential — each builds on state left by the previous
one (clone → diff → push → pull → prune).  Run with ``pytest -x`` (stop on
first failure) to avoid cascading failures when an early step breaks.

Sections:
    1. ws clone  — basic, --path, --skip, negatives
    2. ws diff   — baseline after clone, local mutation detection
    3. ws push   — dry-run, real push, id writeback
    4. ws pull   — --force, --skip releases, --merge
    5. ws push --prune — cleanup / delete remote entries
"""

from __future__ import annotations

import shutil
import time
from pathlib import Path

import pytest
import yaml

from helpers import run_plane

# ── Constants ─────────────────────────────────────────────────────────────────
TEST_CONN  = "e2e-ws-conn"
WORKSPACE  = Path("/workspace")   # empty dir in the container — our "cwd"
TEST_LABEL  = f"E2E-{int(time.time())}"
MERGE_LABEL = f"{TEST_LABEL}-merge"

# ── Mutable state shared across tests ─────────────────────────────────────────
# Mirrors the global variables in test_ws.sh — populated as tests run.
_ws: dict = {}

# ── Unique label / property names for this test run ──────────────────────────
TEST_CUST_PROP      = f"e2e-prop-{int(time.time())}"          # customer TEXT property name
TEST_CUST_OPT_PROP  = f"e2e-optprop-{int(time.time())}"      # customer OPTION property name


# ── YAML helpers ──────────────────────────────────────────────────────────────

def add_project_label(yaml_path: Path, label_name: str, color: str = "#FF0000") -> None:
    """Append a label entry to project.yaml (pure Python, no subprocess)."""
    data = yaml.safe_load(yaml_path.read_text())
    data["labels"].append({"name": label_name, "color": color})
    yaml_path.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))


def remove_project_label(yaml_path: Path, label_name: str) -> None:
    """Remove a label entry from project.yaml by name."""
    data = yaml.safe_load(yaml_path.read_text())
    data["labels"] = [lb for lb in data["labels"] if lb.get("name") != label_name]
    yaml_path.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))


# ── Module-scoped setup / teardown ────────────────────────────────────────────

@pytest.fixture(autouse=True, scope="module")
def ws_setup(env):
    """Login and wipe /workspace before the suite; logout and clean up after."""
    # pre-run cleanup
    run_plane("auth", "logout", TEST_CONN, "--force")
    for child in WORKSPACE.iterdir():
        shutil.rmtree(child) if child.is_dir() else child.unlink()

    code, out = run_plane(
        "auth", "login",
        "--server-url", env["PLANE_SERVER_URL"],
        "--auth-type",  env["PLANE_AUTH_TYPE"],
        "--token",      env["PLANE_TOKEN"],
        "--workspace",  env["PLANE_WORKSPACE"],
        "--connection", TEST_CONN,
    )
    assert code == 0, f"auth login failed during ws_setup\n{out}"

    yield

    # post-run cleanup
    run_plane("auth", "logout", TEST_CONN, "--force")
    for child in WORKSPACE.iterdir():
        shutil.rmtree(child) if child.is_dir() else child.unlink()


# =============================================================================
# 1. ws clone — basic
# =============================================================================

def test_clone_basic_exits_0(env):
    # No --path: plane clones into cwd (/workspace/<slug>)
    code, out = run_plane(
        "ws", "clone", env["PLANE_WORKSPACE"],
        "--connection", TEST_CONN,
        cwd=WORKSPACE,
    )
    _ws["clone_dir"] = WORKSPACE / env["PLANE_WORKSPACE"]
    assert code == 0, f"expected exit 0\n{out}"
    assert "cloned successfully" in out


# ── 1. ws clone — file structure ──────────────────────────────────────────────

def test_clone_workspace_folder_created():
    assert _ws["clone_dir"].exists()


def test_clone_plane_yaml_exists():
    assert (_ws["clone_dir"] / "plane.yaml").exists()


def test_clone_plane_yaml_non_empty():
    assert (_ws["clone_dir"] / "plane.yaml").stat().st_size > 0


def test_clone_schema_dir_exists():
    assert (_ws["clone_dir"] / "schema").is_dir()


def test_clone_work_dir_exists():
    assert (_ws["clone_dir"] / "work").is_dir()


def test_clone_state_json_written():
    assert (_ws["clone_dir"] / ".plane" / "state.json").stat().st_size > 0


def test_clone_detects_customers_feature():
    """Detect whether the customers feature is enabled in the test workspace.

    Sets ``_ws["customers_enabled"]`` so later tests can skip gracefully if
    the feature is not enabled for this workspace.
    """
    features_path = _ws["clone_dir"] / "schema" / "features.yaml"
    if not features_path.exists():
        _ws["customers_enabled"] = False
        return
    data = yaml.safe_load(features_path.read_text()) or {}
    _ws["customers_enabled"] = bool(data.get("features", {}).get("customers", False))


@pytest.mark.parametrize("filename", [
    "features.yaml",
    "members.yaml",
    "workitemtypes.yaml",
    "project.yaml",
    "initiatives.yaml",
    "releases.yaml",
    "relations.yaml",
    "webhooks.yaml",
])
def test_clone_schema_file_exists(filename):
    assert (_ws["clone_dir"] / "schema" / filename).exists(), (
        f"schema/{filename} missing after clone"
    )


def test_clone_work_releases_yaml_exists():
    assert (_ws["clone_dir"] / "work" / "releases.yaml").exists()


def test_clone_plane_yaml_contains_workspace_type():
    assert "type: workspace" in (_ws["clone_dir"] / "plane.yaml").read_text()


def test_clone_plane_yaml_contains_workspace_slug(env):
    assert env["PLANE_WORKSPACE"] in (_ws["clone_dir"] / "plane.yaml").read_text()


# ── 1. ws clone — --path flag ─────────────────────────────────────────────────

def test_clone_custom_path(env):
    # --path: plane clones into the specified directory instead of cwd
    code, out = run_plane(
        "ws", "clone", env["PLANE_WORKSPACE"],
        "--connection", TEST_CONN,
        "--path", str(WORKSPACE / "custom"),
    )
    _ws["custom_dir"] = WORKSPACE / "custom" / env["PLANE_WORKSPACE"]
    assert code == 0, f"expected exit 0\n{out}"


def test_clone_custom_path_workspace_folder_created():
    assert _ws["custom_dir"].exists()


def test_clone_custom_path_plane_yaml_exists():
    assert (_ws["custom_dir"] / "plane.yaml").exists()


# ── 1. ws clone — --skip releases ────────────────────────────────────────────

def test_clone_skip_releases_exits_0(env):
    code, out = run_plane(
        "ws", "clone", env["PLANE_WORKSPACE"],
        "--connection", TEST_CONN,
        "--path", str(WORKSPACE / "skip"),
        "--skip", "releases",
    )
    _ws["skip_dir"] = WORKSPACE / "skip" / env["PLANE_WORKSPACE"]
    assert code == 0, f"expected exit 0\n{out}"


def test_clone_skip_releases_yaml_still_created():
    # The file is created as an empty scaffold even when releases are skipped.
    assert (_ws["skip_dir"] / "work" / "releases.yaml").exists()


# ── 1. ws clone — negative cases ─────────────────────────────────────────────

def test_clone_without_connection_fails(env):
    code, out = run_plane("ws", "clone", env["PLANE_WORKSPACE"])
    assert code == 2, f"expected exit 2 (missing required option)\n{out}"


def test_clone_nonexistent_workspace_fails():
    code, out = run_plane(
        "ws", "clone", "workspace-xyz-does-not-exist",
        "--connection", TEST_CONN,
        "--path", str(WORKSPACE / "neg"),
    )
    assert code == 1, f"expected exit 1\n{out}"


def test_clone_into_existing_directory_fails(env):
    # /workspace/<slug> already exists from test_clone_basic_exits_0
    code, out = run_plane(
        "ws", "clone", env["PLANE_WORKSPACE"],
        "--connection", TEST_CONN,
        cwd=WORKSPACE,
    )
    assert code == 1
    assert "already exists" in out, f"expected 'already exists'\n{out}"


# =============================================================================
# 2. ws diff
# =============================================================================

def test_diff_after_clone_exits_0():
    # A freshly-cloned workspace may have remote-only diffs (features, member
    # roles, etc.) so we only assert exit 0 + workspace slug in output.
    code, out = run_plane("ws", "diff", str(_ws["clone_dir"]))
    assert code == 0, f"expected exit 0\n{out}"


# ── 2. ws diff — after local mutation ────────────────────────────────────────

def test_diff_add_label_to_yaml():
    """Add TEST_LABEL to project.yaml (no API call)."""
    project_yaml = _ws["clone_dir"] / "schema" / "project.yaml"
    _ws["project_yaml"] = project_yaml
    add_project_label(project_yaml, TEST_LABEL)
    assert TEST_LABEL in project_yaml.read_text(), "label not written to project.yaml"


def test_diff_detects_local_add():
    """Run diff ONCE after mutation; store output for the next test."""
    code, out = run_plane("ws", "diff", str(_ws["clone_dir"]))
    _ws["diff_after_mutate"] = out
    assert code == 0, f"expected exit 0\n{out}"
    assert "local adds" in out, f"expected 'local adds' in diff output\n{out}"


def test_diff_names_changed_file():
    assert "project.yaml" in _ws["diff_after_mutate"], (
        "diff output did not mention project.yaml"
    )


# =============================================================================
# 3. ws push
# =============================================================================

def test_push_dry_run_mentions_new_label():
    code, out = run_plane(
        "ws", "push", str(_ws["clone_dir"]),
        "--dry-run", "--force",
    )
    assert code == 0, f"expected exit 0\n{out}"
    assert TEST_LABEL in out, f"expected '{TEST_LABEL}' in dry-run output\n{out}"


def test_push_creates_label_on_remote():
    code, out = run_plane(
        "ws", "push", str(_ws["clone_dir"]),
        "--force",
    )
    assert code == 0, f"expected exit 0\n{out}"
    assert "label" in out.lower(), f"expected 'label' in push output\n{out}"


def test_push_id_written_back_to_yaml():
    assert "id:" in _ws["project_yaml"].read_text(), (
        "remote id not written back to project.yaml after push"
    )


def test_push_label_name_still_in_yaml():
    assert TEST_LABEL in _ws["project_yaml"].read_text()


def test_push_label_absent_from_local_adds():
    """After push, TEST_LABEL must not appear under '→ local adds'."""
    code, out = run_plane("ws", "diff", str(_ws["clone_dir"]))
    assert code == 0
    in_local_adds = False
    for line in out.splitlines():
        if "local adds" in line:
            in_local_adds = True
        if in_local_adds and TEST_LABEL in line:
            pytest.fail(f"'{TEST_LABEL}' still under local adds after push\n{out}")


# =============================================================================
# 4. ws pull
# =============================================================================

def test_pull_force_exits_0():
    time.sleep(8)   # let API rate-limit window (429) reset before pull burst
    code, out = run_plane("ws", "pull", str(_ws["clone_dir"]), "--force")
    assert code == 0, f"expected exit 0\n{out}"


def test_pull_force_label_still_in_yaml():
    assert TEST_LABEL in _ws["project_yaml"].read_text()


def test_pull_label_not_local_add_after_pull():
    """After pull, TEST_LABEL must not appear under '→ local adds'."""
    code, out = run_plane("ws", "diff", str(_ws["clone_dir"]))
    assert code == 0
    in_local_adds = False
    for line in out.splitlines():
        if "local adds" in line:
            in_local_adds = True
        if in_local_adds and TEST_LABEL in line:
            pytest.fail(f"'{TEST_LABEL}' still under local adds after pull\n{out}")


def test_pull_skip_releases_exits_0():
    code, out = run_plane(
        "ws", "pull", str(_ws["clone_dir"]),
        "--force", "--skip", "releases",
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_pull_merge_exits_0():
    add_project_label(_ws["project_yaml"], MERGE_LABEL, "#00FF00")
    time.sleep(8)   # let API rate-limit window reset before merge pull burst
    code, out = run_plane("ws", "pull", str(_ws["clone_dir"]), "--merge")
    assert code == 0, f"expected exit 0\n{out}"


def test_pull_merge_preserves_local_label():
    assert MERGE_LABEL in _ws["project_yaml"].read_text(), (
        f"'{MERGE_LABEL}' was wiped by pull --merge"
    )


# =============================================================================
# 5. ws push --prune  (cleanup: delete both test labels from remote)
# =============================================================================

def test_prune_remove_labels_from_local_yaml():
    remove_project_label(_ws["project_yaml"], TEST_LABEL)
    remove_project_label(_ws["project_yaml"], MERGE_LABEL)
    content = _ws["project_yaml"].read_text()
    assert TEST_LABEL  not in content
    assert MERGE_LABEL not in content


def test_prune_diff_shows_remote_only_exits_0():
    code, out = run_plane("ws", "diff", str(_ws["clone_dir"]))
    assert code == 0, f"expected exit 0\n{out}"


def test_prune_push_deletes_labels_from_remote():
    code, out = run_plane(
        "ws", "push", str(_ws["clone_dir"]),
        "--prune", "--force",
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_prune_labels_absent_from_diff_after_prune():
    code, out = run_plane("ws", "diff", str(_ws["clone_dir"]))
    assert code == 0
    assert TEST_LABEL  not in out, f"'{TEST_LABEL}' still appears in diff after prune"
    assert MERGE_LABEL not in out, f"'{MERGE_LABEL}' still appears in diff after prune"


# =============================================================================
# 6. schema/customers.yaml  (skipped when customers feature is not enabled)
# =============================================================================

# ── Customer YAML helpers ─────────────────────────────────────────────────────

def add_customer_property(yaml_path: Path, name: str, display_name: str) -> None:
    """Append a TEXT customer property entry to customers.yaml."""
    data = yaml.safe_load(yaml_path.read_text()) if yaml_path.exists() else {"properties": []}
    data.setdefault("properties", []).append({
        "name": name,
        "display_name": display_name,
        "type": "TEXT",
        "required": False,
    })
    yaml_path.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))


def remove_customer_property(yaml_path: Path, name: str) -> None:
    """Remove a customer property entry from customers.yaml by name."""
    data = yaml.safe_load(yaml_path.read_text()) if yaml_path.exists() else {"properties": []}
    data["properties"] = [p for p in data.get("properties", []) if p.get("name") != name]
    yaml_path.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))


def add_option_property(
    yaml_path: Path, prop_name: str, display_name: str, initial_option_names: list
) -> None:
    """Append an OPTION-type customer property with initial option values (no ids)."""
    data = yaml.safe_load(yaml_path.read_text()) if yaml_path.exists() else {"properties": []}
    data.setdefault("properties", []).append({
        "name": prop_name,
        "display_name": display_name,
        "type": "OPTION",
        "required": False,
        "options": [{"name": n} for n in initial_option_names],
    })
    yaml_path.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))


def add_option_to_property(yaml_path: Path, prop_name: str, option_name: str) -> None:
    """Add a new option (no id) to an existing OPTION property."""
    data = yaml.safe_load(yaml_path.read_text()) if yaml_path.exists() else {"properties": []}
    for prop in data.get("properties", []):
        if isinstance(prop, dict) and prop.get("name") == prop_name:
            prop.setdefault("options", []).append({"name": option_name})
            break
    yaml_path.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))


def remove_option_from_property(yaml_path: Path, prop_name: str, option_name: str) -> None:
    """Remove an option entry by name from an existing OPTION property."""
    data = yaml.safe_load(yaml_path.read_text()) if yaml_path.exists() else {"properties": []}
    for prop in data.get("properties", []):
        if isinstance(prop, dict) and prop.get("name") == prop_name:
            prop["options"] = [
                o for o in prop.get("options", []) if o.get("name") != option_name
            ]
            break
    yaml_path.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))


def rename_option_in_property(
    yaml_path: Path, prop_name: str, old_name: str, new_name: str
) -> None:
    """Rename an option (matched by name) inside an existing OPTION property."""
    data = yaml.safe_load(yaml_path.read_text()) if yaml_path.exists() else {"properties": []}
    for prop in data.get("properties", []):
        if isinstance(prop, dict) and prop.get("name") == prop_name:
            for opt in prop.get("options", []):
                if isinstance(opt, dict) and opt.get("name") == old_name:
                    opt["name"] = new_name
                    break
            break
    yaml_path.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))


# ── 6a. clone: customers.yaml present (feature-gated) ────────────────────────

def test_customers_feature_check():
    """Gate: skip all customers tests when the feature is not enabled."""
    if not _ws.get("customers_enabled", False):
        pytest.skip("customers feature not enabled in test workspace")


def test_customers_yaml_created_after_clone():
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    customers_path = _ws["clone_dir"] / "schema" / "customers.yaml"
    _ws["customers_yaml"] = customers_path
    assert customers_path.exists(), "schema/customers.yaml not found after clone"


def test_customers_yaml_parseable():
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    data = yaml.safe_load(_ws["customers_yaml"].read_text())
    assert "properties" in data, "customers.yaml missing 'properties' key"
    assert isinstance(data["properties"], list), "'properties' is not a list"


def test_customers_yaml_has_no_api_noise_fields():
    """is_active, is_multi, sort_order, property_type should not appear in YAML."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    text = _ws["customers_yaml"].read_text()
    for bad_field in ("is_active:", "is_multi:", "sort_order:", "property_type:", "is_required:"):
        assert bad_field not in text, (
            f"API noise field '{bad_field}' found in customers.yaml — should be mapped/excluded"
        )


def test_customers_option_property_has_options():
    """OPTION-type properties must include their option values."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    data = yaml.safe_load(_ws["customers_yaml"].read_text())
    option_props = [p for p in data["properties"] if p.get("type") in ("OPTION", "MULTI_OPTION")]
    if not option_props:
        pytest.skip("no OPTION/MULTI_OPTION properties in test workspace")
    for prop in option_props:
        assert "options" in prop, (
            f"OPTION property '{prop.get('name')}' missing 'options' list in customers.yaml"
        )
        assert len(prop["options"]) > 0, (
            f"OPTION property '{prop.get('name')}' has empty 'options' list"
        )
        # Each option must have id and name
        for opt in prop["options"]:
            assert "id" in opt, f"option in '{prop.get('name')}' missing 'id'"
            assert "name" in opt, f"option in '{prop.get('name')}' missing 'name'"


# ── 6b. diff: baseline ────────────────────────────────────────────────────────

def test_customers_diff_clean_after_clone():
    """diff should show customers.yaml as up-to-date immediately after clone."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    code, out = run_plane("ws", "diff", str(_ws["clone_dir"]))
    assert code == 0, f"diff failed\n{out}"
    # customers.yaml should appear in the "Compared" list (up-to-date)
    assert "customers.yaml" in out, (
        f"customers.yaml not compared in diff output\n{out}"
    )


# ── 6c. push: add a new customer property ────────────────────────────────────

def test_customers_push_add_local_property():
    """Add a local-only TEXT property then push it."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    add_customer_property(
        _ws["customers_yaml"],
        TEST_CUST_PROP,
        "E2E Test Property",
    )
    assert TEST_CUST_PROP in _ws["customers_yaml"].read_text()


def test_customers_push_dry_run_shows_new_property():
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    code, out = run_plane(
        "ws", "push", str(_ws["clone_dir"]),
        "--dry-run", "--force",
    )
    assert code == 0, f"push --dry-run failed\n{out}"
    assert TEST_CUST_PROP in out or "E2E Test Property" in out, (
        f"new customer property not shown in dry-run output\n{out}"
    )


def test_customers_push_creates_property_on_remote():
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    code, out = run_plane(
        "ws", "push", str(_ws["clone_dir"]),
        "--force",
    )
    assert code == 0, f"push failed\n{out}"
    # push output should mention the property
    assert "properties" in out.lower(), f"expected 'properties' in push output\n{out}"


def test_customers_push_id_written_back_to_yaml():
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    data = yaml.safe_load(_ws["customers_yaml"].read_text())
    pushed_prop = next(
        (p for p in data["properties"] if p.get("name") == TEST_CUST_PROP), None
    )
    assert pushed_prop is not None, f"'{TEST_CUST_PROP}' missing from customers.yaml after push"
    assert pushed_prop.get("id"), (
        f"server-assigned id not written back for '{TEST_CUST_PROP}'"
    )


# ── 6d. pull: verify round-trip ───────────────────────────────────────────────

def test_customers_pull_force_exits_0():
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    time.sleep(3)   # small pause to avoid rate-limit burst
    code, out = run_plane("ws", "pull", str(_ws["clone_dir"]), "--force")
    assert code == 0, f"pull --force failed\n{out}"


def test_customers_pull_property_still_in_yaml():
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    assert TEST_CUST_PROP in _ws["customers_yaml"].read_text(), (
        f"'{TEST_CUST_PROP}' missing from customers.yaml after pull"
    )


def test_customers_diff_clean_after_pull():
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    code, out = run_plane("ws", "diff", str(_ws["clone_dir"]))
    assert code == 0, f"diff failed\n{out}"
    # After pull, should not appear as a local-only item
    in_local_adds = False
    for line in out.splitlines():
        if "local adds" in line:
            in_local_adds = True
        if in_local_adds and TEST_CUST_PROP in line:
            pytest.fail(f"'{TEST_CUST_PROP}' still under local adds after pull\n{out}")


# ── 6e. prune: delete the test property from remote ──────────────────────────

def test_customers_prune_remove_from_local_yaml():
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    remove_customer_property(_ws["customers_yaml"], TEST_CUST_PROP)
    assert TEST_CUST_PROP not in _ws["customers_yaml"].read_text()


def test_customers_prune_diff_shows_remote_only():
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    code, out = run_plane("ws", "diff", str(_ws["clone_dir"]))
    assert code == 0, f"diff failed\n{out}"


def test_customers_prune_push_deletes_from_remote():
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    code, out = run_plane(
        "ws", "push", str(_ws["clone_dir"]),
        "--prune", "--force",
    )
    assert code == 0, f"push --prune failed\n{out}"


def test_customers_prune_property_absent_from_diff():
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    code, out = run_plane("ws", "diff", str(_ws["clone_dir"]))
    assert code == 0
    assert TEST_CUST_PROP not in out, (
        f"'{TEST_CUST_PROP}' still in diff after prune"
    )


# =============================================================================
# 6f. OPTION-type customer property — options push (create / add / delete / rename)
# =============================================================================

def test_customers_option_prop_add_local():
    """Add an OPTION property with two initial option values to customers.yaml."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    add_option_property(
        _ws["customers_yaml"],
        TEST_CUST_OPT_PROP,
        "E2E Option Prop",
        ["Opt-Alpha", "Opt-Beta"],
    )
    text = _ws["customers_yaml"].read_text()
    assert TEST_CUST_OPT_PROP in text
    assert "Opt-Alpha" in text
    assert "Opt-Beta" in text


def test_customers_option_prop_push_created():
    """Push the new OPTION property — must exit 0."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    code, out = run_plane("ws", "push", str(_ws["clone_dir"]), "--force")
    assert code == 0, f"push failed\n{out}"
    assert "properties" in out.lower(), f"expected 'properties' in output\n{out}"


def test_customers_option_prop_id_written_back():
    """After push, the OPTION property must have a server-assigned id in YAML."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    data = yaml.safe_load(_ws["customers_yaml"].read_text())
    prop = next((p for p in data["properties"] if p.get("name") == TEST_CUST_OPT_PROP), None)
    assert prop is not None, f"'{TEST_CUST_OPT_PROP}' not found in customers.yaml after push"
    assert prop.get("id"), "server-assigned id not written back for OPTION property"


def test_customers_option_prop_initial_options_have_ids():
    """After push, the initial options (Opt-Alpha, Opt-Beta) must have server-assigned ids."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    data = yaml.safe_load(_ws["customers_yaml"].read_text())
    prop = next((p for p in data["properties"] if p.get("name") == TEST_CUST_OPT_PROP), None)
    if prop is None:
        pytest.skip("OPTION property not found — prior test may have failed")
    # Options are populated by the server — they may not have ids immediately
    # after creating the property (options are set via a subsequent step in some
    # backends). Do a pull to fetch the latest state.
    run_plane("ws", "pull", str(_ws["clone_dir"]), "--force")
    data = yaml.safe_load(_ws["customers_yaml"].read_text())
    prop = next((p for p in data["properties"] if p.get("name") == TEST_CUST_OPT_PROP), None)
    assert prop is not None
    opts = prop.get("options", [])
    assert len(opts) >= 2, f"expected at least 2 options after pull, got: {opts}"
    for opt in opts:
        assert opt.get("id"), f"option '{opt.get('name')}' missing id after pull"
    # Store option names for next tests
    _ws["opt_prop_options"] = {o["name"]: o["id"] for o in opts}


def test_customers_option_prop_add_new_option():
    """Add a third option (Opt-Gamma, no id) to the local YAML."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    add_option_to_property(_ws["customers_yaml"], TEST_CUST_OPT_PROP, "Opt-Gamma")
    text = _ws["customers_yaml"].read_text()
    assert "Opt-Gamma" in text


def test_customers_option_prop_push_new_option():
    """Push the new option — must exit 0 and report option creation."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    code, out = run_plane("ws", "push", str(_ws["clone_dir"]), "--force")
    assert code == 0, f"push failed\n{out}"
    # The push output should mention option creation
    assert "option" in out.lower(), f"expected 'option' in push output\n{out}"


def test_customers_option_prop_new_option_has_id():
    """After pushing Opt-Gamma, it must have a server-assigned id in YAML."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    data = yaml.safe_load(_ws["customers_yaml"].read_text())
    prop = next((p for p in data["properties"] if p.get("name") == TEST_CUST_OPT_PROP), None)
    assert prop is not None
    gamma = next((o for o in prop.get("options", []) if o.get("name") == "Opt-Gamma"), None)
    assert gamma is not None, "Opt-Gamma not found in options after push"
    assert gamma.get("id"), "Opt-Gamma has no server-assigned id after push"


def test_customers_option_prop_remove_option():
    """Remove Opt-Beta from local YAML (soft-delete on push)."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    remove_option_from_property(_ws["customers_yaml"], TEST_CUST_OPT_PROP, "Opt-Beta")
    text = _ws["customers_yaml"].read_text()
    assert "Opt-Beta" not in text, "Opt-Beta should be removed from local YAML"
    assert "Opt-Alpha" in text, "Opt-Alpha should still be in local YAML"


def test_customers_option_prop_push_deleted_option():
    """Push the deletion of Opt-Beta — must exit 0."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    code, out = run_plane("ws", "push", str(_ws["clone_dir"]), "--force")
    assert code == 0, f"push failed\n{out}"


def test_customers_option_prop_deleted_option_gone_after_pull():
    """After pull, Opt-Beta must not appear (was soft-deleted on remote)."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    time.sleep(2)  # brief pause before pull
    run_plane("ws", "pull", str(_ws["clone_dir"]), "--force")
    data = yaml.safe_load(_ws["customers_yaml"].read_text())
    prop = next((p for p in data["properties"] if p.get("name") == TEST_CUST_OPT_PROP), None)
    assert prop is not None
    opt_names = [o.get("name") for o in prop.get("options", [])]
    assert "Opt-Beta" not in opt_names, (
        f"Opt-Beta still present after soft-delete + pull; options: {opt_names}"
    )


def test_customers_option_prop_rename_option():
    """Rename Opt-Alpha to Opt-Alpha2 in local YAML."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    rename_option_in_property(_ws["customers_yaml"], TEST_CUST_OPT_PROP, "Opt-Alpha", "Opt-Alpha2")
    text = _ws["customers_yaml"].read_text()
    assert "Opt-Alpha2" in text
    assert "Opt-Alpha" not in text.replace("Opt-Alpha2", "")


def test_customers_option_prop_push_renamed_option():
    """Push the rename of Opt-Alpha → Opt-Alpha2 — must exit 0."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    code, out = run_plane("ws", "push", str(_ws["clone_dir"]), "--force")
    assert code == 0, f"push failed\n{out}"


def test_customers_option_prop_renamed_option_after_pull():
    """After pull, Opt-Alpha2 should appear and Opt-Alpha should be gone."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    time.sleep(2)
    run_plane("ws", "pull", str(_ws["clone_dir"]), "--force")
    data = yaml.safe_load(_ws["customers_yaml"].read_text())
    prop = next((p for p in data["properties"] if p.get("name") == TEST_CUST_OPT_PROP), None)
    assert prop is not None
    opt_names = [o.get("name") for o in prop.get("options", [])]
    assert "Opt-Alpha2" in opt_names, (
        f"Opt-Alpha2 not found after rename + pull; options: {opt_names}"
    )


# ── 6g. cleanup: prune the test OPTION property ──────────────────────────────

def test_customers_option_prop_cleanup():
    """Remove test OPTION property from local YAML and prune it from remote."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    remove_customer_property(_ws["customers_yaml"], TEST_CUST_OPT_PROP)
    assert TEST_CUST_OPT_PROP not in _ws["customers_yaml"].read_text()
    code, out = run_plane(
        "ws", "push", str(_ws["clone_dir"]),
        "--prune", "--force",
    )
    assert code == 0, f"prune failed\n{out}"


def test_customers_option_prop_absent_from_diff_after_cleanup():
    """After prune, the OPTION property must not appear in diff."""
    if not _ws.get("customers_enabled"):
        pytest.skip("customers feature not enabled")
    code, out = run_plane("ws", "diff", str(_ws["clone_dir"]))
    assert code == 0
    assert TEST_CUST_OPT_PROP not in out, (
        f"'{TEST_CUST_OPT_PROP}' still in diff after prune"
    )
