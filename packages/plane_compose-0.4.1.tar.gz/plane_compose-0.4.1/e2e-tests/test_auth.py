"""
End-to-end tests for `plane auth` commands.

Run inside the Docker container:
    cd /workspace && pytest e2e-tests/test_auth.py -v

Tests are intentionally sequential — each builds on the state left by the
previous one (login → list → disconnect → reconnect → logout).  Run with
``pytest -x`` (stop on first failure) to avoid cascading failures when
an early step breaks.
"""

from __future__ import annotations

import pytest

from helpers import run_plane

# Connection name used throughout this module
TEST_CONN = "e2e-pytest-conn"


# ── Module-scoped setup / teardown ────────────────────────────────────────────

@pytest.fixture(autouse=True, scope="module")
def clean_test_conn():
    """Ensure TEST_CONN doesn't exist before or after this test module."""
    run_plane("auth", "logout", TEST_CONN, "--force")   # pre-run
    yield
    run_plane("auth", "logout", TEST_CONN, "--force")   # post-run


# ── 1. Login ──────────────────────────────────────────────────────────────────

def test_login_valid_credentials_exits_0(env):
    code, out = run_plane(
        "auth", "login",
        "--server-url", env["PLANE_SERVER_URL"],
        "--auth-type",  env["PLANE_AUTH_TYPE"],
        "--token",      env["PLANE_TOKEN"],
        "--workspace",  env["PLANE_WORKSPACE"],
        "--connection", TEST_CONN,
    )
    assert code == 0, f"expected exit 0, got {code}\n{out}"


def test_login_prints_connection_name(env):
    # Connection should already exist from the previous test.
    # We just verify the connection name appears in list-connections.
    code, out = run_plane("auth", "list-connections")
    assert code == 0
    assert TEST_CONN in out


# ── 2. List connections ───────────────────────────────────────────────────────

def test_list_connections_shows_workspace(env):
    code, out = run_plane("auth", "list-connections")
    assert code == 0
    assert env["PLANE_WORKSPACE"] in out


# ── 3. Duplicate login (same workspace, different connection name) ─────────────

def test_login_workspace_already_linked_fails(env):
    code, out = run_plane(
        "auth", "login",
        "--server-url", env["PLANE_SERVER_URL"],
        "--auth-type",  env["PLANE_AUTH_TYPE"],
        "--token",      env["PLANE_TOKEN"],
        "--workspace",  env["PLANE_WORKSPACE"],
        "--connection", "e2e-other-conn",
    )
    assert code == 1
    assert "already linked" in out, f"expected 'already linked' in output\n{out}"


# ── 4. Invalid credentials ────────────────────────────────────────────────────

def test_login_invalid_token_fails(env):
    code, out = run_plane(
        "auth", "login",
        "--server-url", env["PLANE_SERVER_URL"],
        "--auth-type",  env["PLANE_AUTH_TYPE"],
        "--token",      "invalid_token_abc123",
        "--workspace",  env["PLANE_WORKSPACE"],
        "--connection", "e2e-bad-conn",
    )
    assert code == 1, f"expected exit 1, got {code}\n{out}"


def test_login_nonexistent_workspace_fails(env):
    code, out = run_plane(
        "auth", "login",
        "--server-url", env["PLANE_SERVER_URL"],
        "--auth-type",  env["PLANE_AUTH_TYPE"],
        "--token",      env["PLANE_TOKEN"],
        "--workspace",  "this-workspace-xyz-does-not-exist",
        "--connection", "e2e-bad-conn",
    )
    assert code == 1, f"expected exit 1, got {code}\n{out}"


# ── 5. Disconnect / reconnect workspace ───────────────────────────────────────

def test_disconnect_workspace_exits_0(env):
    code, out = run_plane(
        "auth", "disconnect-workspace", env["PLANE_WORKSPACE"],
        "--connection", TEST_CONN,
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_workspace_absent_from_list_after_disconnect(env):
    _, out = run_plane("auth", "list-connections")
    assert env["PLANE_WORKSPACE"] not in out, (
        f"workspace '{env['PLANE_WORKSPACE']}' should not appear after disconnect\n{out}"
    )


def test_connect_workspace_exits_0(env):
    code, out = run_plane(
        "auth", "connect-workspace", env["PLANE_WORKSPACE"],
        "--connection", TEST_CONN,
    )
    assert code == 0, f"expected exit 0\n{out}"


def test_workspace_present_in_list_after_reconnect(env):
    code, out = run_plane("auth", "list-connections")
    assert code == 0
    assert env["PLANE_WORKSPACE"] in out


# ── 6. Logout ─────────────────────────────────────────────────────────────────

def test_logout_with_force_exits_0():
    code, out = run_plane("auth", "logout", TEST_CONN, "--force")
    assert code == 0, f"expected exit 0\n{out}"


def test_connection_absent_from_list_after_logout():
    _, out = run_plane("auth", "list-connections")
    assert TEST_CONN not in out, (
        f"connection '{TEST_CONN}' should not appear after logout\n{out}"
    )


def test_logout_nonexistent_connection_fails():
    code, out = run_plane("auth", "logout", TEST_CONN, "--force")
    assert code == 1, f"expected exit 1, got {code}\n{out}"
