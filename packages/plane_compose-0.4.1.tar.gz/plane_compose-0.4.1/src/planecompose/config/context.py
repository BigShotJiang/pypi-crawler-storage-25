"""Project context management."""
from pathlib import Path

from pydantic import BaseModel, ConfigDict

from planecompose.core.models import (
    ProjectConfig,
    WorkspaceConfig,
    WorkItemTypeDefinition,
    WorkflowDefinition,
    StateDefinition,
    LabelDefinition,
    ModuleDefinition,
    CycleDefinition,
    SyncState,
)
from planecompose.parser.plane_yaml import parse_plane_yaml, parse_workspace_yaml
from planecompose.parser.schema_resolver import resolve_schema_inheritance
from planecompose.state.manager import StateManager
from planecompose.constants import (
    DEFAULT_API_URL,
    DIR_SCHEMA,
    DIR_WORK,
    DIR_PLANE,
    FILE_PLANE_YAML,
    FILE_STATE_JSON,
)


def _resolve_credentials(
    workspace_slug: str,
    require_auth: bool = True,
    connection_id: str | None = None,
) -> tuple[str, str, str]:
    """
    Resolve credentials for a workspace slug.

    Returns: (token, token_type, server_url)

    Resolution order:
    1. If connection_id provided → use it directly (explicit, set in plane.yaml)
    2. Find workspace entry by slug
    3. Fall back to default workspace connection
    4. Fall back to first available connection (migration path)

    Backward compat fallback:
    - Old format (api_key at root): treat as workspace token
    - Plain credentials file: treat as workspace token
    """
    from planecompose.cli.auth import _load_config

    config = _load_config()
    workspaces = config.get("workspaces", [])
    connections = {c["id"]: c for c in config.get("connections", [])}

    # 1. Explicit connection_id from plane.yaml — use directly
    if connection_id:
        conn = connections.get(connection_id)
        if conn:
            return conn["token"], conn.get("token_type", "workspace"), conn["server_url"]
        # connection_id set but not found — warn and fall through
        import warnings
        warnings.warn(
            f"Connection '{connection_id}' from plane.yaml not found in config. "
            "Falling back to workspace slug lookup."
        )

    # 2. Look up by workspace slug
    for ws in workspaces:
        if ws["slug"] == workspace_slug:
            conn = connections.get(ws["connection_id"])
            if conn:
                return conn["token"], conn.get("token_type", "workspace"), conn["server_url"]

    # 3. Default workspace
    default_slug = config.get("default_workspace")
    if default_slug:
        for ws in workspaces:
            if ws["slug"] == default_slug:
                conn = connections.get(ws["connection_id"])
                if conn:
                    return conn["token"], conn.get("token_type", "workspace"), conn["server_url"]

    # 4. First available connection (migration path)
    if connections:
        conn = next(iter(connections.values()))
        return conn["token"], conn.get("token_type", "workspace"), conn["server_url"]

    if require_auth:
        raise FileNotFoundError("Not authenticated. Run 'plane auth login' first")

    return "", "workspace", "https://api.plane.so"


def _load_yaml_list(yaml_file: Path, root_key: str | None = None) -> list:
    """Load a YAML list from file, return empty list if not found or invalid.

    Handles both bare list format and dict-with-root-key format:
      - Bare list:  [- name: foo, ...]
      - Dict:       cycles: [- name: foo, ...]
    """
    import yaml
    if not yaml_file.exists():
        return []
    try:
        content = yaml.safe_load(yaml_file.read_text())
        if content is None:
            return []
        if isinstance(content, list):
            return content
        if isinstance(content, dict):
            # Try the provided root_key first, then derive from file stem
            key = root_key or yaml_file.stem  # e.g. "cycles.yaml" → "cycles"
            items = content.get(key) or []
            return items if isinstance(items, list) else []
    except Exception:
        pass
    return []


def _load_modules(schema_dir: Path) -> list[ModuleDefinition]:
    """Load module definitions from work/modules.yaml (operational data).

    Falls back to schema/modules.yaml for backward compatibility with
    projects created before the schema/work split.
    """
    from planecompose.exceptions import ConfigError
    from pydantic import ValidationError

    work_dir = schema_dir.parent / "work"
    modules_file = work_dir / "modules.yaml"
    if not modules_file.exists():
        # Backward compat: pre-rearchitecture projects have schema/modules.yaml
        modules_file = schema_dir / "modules.yaml"
    modules_data = _load_yaml_list(modules_file)
    modules = []

    for idx, m in enumerate(modules_data):
        if not isinstance(m, dict):
            continue
        try:
            # 'id' in YAML is the remote UUID (written by schema_writer/clone_helpers)
            # map it to the model field name before Pydantic sees it.
            # 'work_items' is a YAML-only membership list (written by write_modules_yaml)
            # that has no corresponding model field — strip it before validation.
            m = dict(m)
            if 'id' in m and 'remote_id' not in m:
                m['remote_id'] = m.pop('id')
            m.pop('work_items', None)
            modules.append(ModuleDefinition(**m))
        except ValidationError as e:
            # Format Pydantic validation errors concisely
            errors_by_msg: dict[str, list[str]] = {}
            for error in e.errors():
                field = ".".join(str(x) for x in error["loc"])
                msg = error["msg"]
                if msg not in errors_by_msg:
                    errors_by_msg[msg] = []
                errors_by_msg[msg].append(field)

            error_lines = []
            for msg, fields in errors_by_msg.items():
                fields_str = ", ".join(fields)
                error_lines.append(f"[{msg}] {fields_str}")

            raise ConfigError(
                f"Invalid module definition at index {idx} in modules.yaml: " + " | ".join(error_lines)
            )
        except Exception as e:
            raise ConfigError(f"Error loading module at index {idx} in modules.yaml: {e}")

    return modules


def _load_cycles(schema_dir: Path) -> list[CycleDefinition]:
    """Load cycle definitions from work/cycles.yaml (operational data).

    Falls back to schema/cycles.yaml for backward compatibility with
    projects created before the schema/work split.
    """
    from planecompose.exceptions import ConfigError
    from pydantic import ValidationError

    work_dir = schema_dir.parent / "work"
    cycles_file = work_dir / "cycles.yaml"
    if not cycles_file.exists():
        # Backward compat: pre-rearchitecture projects have schema/cycles.yaml
        cycles_file = schema_dir / "cycles.yaml"
    cycles_data = _load_yaml_list(cycles_file)
    cycles = []

    for idx, c in enumerate(cycles_data):
        if not isinstance(c, dict):
            continue
        try:
            # 'id' in YAML is the remote UUID — map to model field name.
            # 'work_items' is a YAML-only membership list (written by write_cycles_yaml)
            # that has no corresponding model field — strip it before validation.
            c = dict(c)
            if 'id' in c and 'remote_id' not in c:
                c['remote_id'] = c.pop('id')
            c.pop('work_items', None)
            cycles.append(CycleDefinition(**c))
        except ValidationError as e:
            # Format Pydantic validation errors concisely
            errors_by_msg: dict[str, list[str]] = {}
            for error in e.errors():
                field = ".".join(str(x) for x in error["loc"])
                msg = error["msg"]
                if msg not in errors_by_msg:
                    errors_by_msg[msg] = []
                errors_by_msg[msg].append(field)

            error_lines = []
            for msg, fields in errors_by_msg.items():
                fields_str = ", ".join(fields)
                error_lines.append(f"[{msg}] {fields_str}")

            raise ConfigError(
                f"Invalid cycle definition at index {idx} in cycles.yaml: " + " | ".join(error_lines)
            )
        except Exception as e:
            raise ConfigError(f"Error loading cycle at index {idx} in cycles.yaml: {e}")

    return cycles


class ProjectContext(BaseModel):
    """Context for a Plane project."""
    model_config = ConfigDict(arbitrary_types_allowed=True)

    root_path: Path
    config: ProjectConfig
    workspace_config: WorkspaceConfig | None = None  # Workspace-level config (optional)
    types: list[WorkItemTypeDefinition]
    workflows: list[WorkflowDefinition]
    labels: list[LabelDefinition]
    # Populated once at load time (see _compute_states). Holding this as a
    # regular field — not a @property — is important so that in-memory
    # mutations during push (e.g., state.remote_id = <new_id>) survive until
    # the post-push schema rebuild writes states.yaml.
    states: list[StateDefinition] = []
    modules: list = []  # list[ModuleDefinition]
    cycles: list = []   # list[CycleDefinition]
    state: SyncState
    api_key: str
    token_type: str = "workspace"

    @property
    def schema_path(self) -> Path:
        return self.root_path / DIR_SCHEMA

    @property
    def work_path(self) -> Path:
        return self.root_path / DIR_WORK

    @property
    def state_path(self) -> Path:
        return self.root_path / DIR_PLANE / FILE_STATE_JSON

    def save_state(self):
        """Save sync state to disk."""
        manager = StateManager(self.root_path)
        with manager.lock():
            manager.save(self.state)


def load_project_context(path: Path | None = None, require_auth: bool = True) -> ProjectContext:
    """
    Load project context from a directory.
    
    ONLY checks the specified directory (or current directory if not specified).
    Does NOT search parent directories.
    
    Args:
        path: Directory to check for plane.yaml (defaults to current directory)
    
    Returns:
        ProjectContext: The loaded project context
        
    Raises:
        FileNotFoundError: If plane.yaml is not found in the specified directory
    """
    if path is None:
        path = Path.cwd()
    
    # ONLY check the specified directory (no parent directory search!)
    root_path = path.resolve()
    plane_yaml_path = root_path / FILE_PLANE_YAML

    if not plane_yaml_path.exists():
        raise FileNotFoundError(
            f"Not a Plane project (no {FILE_PLANE_YAML} found in {root_path})"
        )

    # Load configuration
    config = parse_plane_yaml(plane_yaml_path)

    # Load workspace configuration (optional)
    workspace_yaml_path = root_path / "workspace.yaml"
    workspace_config = None
    if workspace_yaml_path.exists():
        workspace_config = parse_workspace_yaml(workspace_yaml_path)

    # Load schema (with inheritance if extends is set)
    schema_dir = root_path / DIR_SCHEMA
    types, workflows, labels = resolve_schema_inheritance(
        schema_dir, config.schema_extends
    )

    # Load modules and cycles
    modules = _load_modules(schema_dir)
    cycles = _load_cycles(schema_dir)

    # Compute the canonical state list once (states.yaml merged with any
    # state names referenced by workflows). Storing this as a field rather
    # than recomputing on each access lets push code mutate state.remote_id
    # in-memory and have those changes survive into the post-push writeback.
    states = _compute_states(schema_dir, workflows)

    # Load sync state
    state = StateManager(root_path).load()

    # Resolve credentials — prefer explicit connection_id from plane.yaml
    api_key, token_type, auth_server_url = _resolve_credentials(
        config.workspace,
        require_auth=require_auth,
        connection_id=config.connection_id,
    )

    # Resolve API URL priority:
    # 1. Explicit api_url in plane.yaml (if different from default)
    # 2. server_url from global auth config (what user authenticated with)
    # 3. Default (https://api.plane.so)
    if config.api_url == DEFAULT_API_URL and auth_server_url and auth_server_url != DEFAULT_API_URL:
        # plane.yaml uses default, but user authenticated with a different server
        # Use the authenticated server URL
        config.api_url = auth_server_url

    return ProjectContext(
        root_path=root_path,
        config=config,
        workspace_config=workspace_config,
        types=types,
        workflows=workflows,
        labels=labels,
        states=states,
        modules=modules,
        cycles=cycles,
        state=state,
        api_key=api_key or "",
        token_type=token_type,
    )


def _compute_states(schema_dir: Path, workflows: list[WorkflowDefinition]) -> list[StateDefinition]:
    """Merge schema/states.yaml with states referenced inside workflows.

    states.yaml is the canonical source of state definitions (name, group,
    color, remote_id). Workflows may contribute StateDefinitions with
    transition info that states.yaml doesn't carry; we overlay those here.

    Dedup is by name (case-insensitive). states.yaml entries win on core
    attributes; workflow-contributed entries supply transitions when the
    states.yaml entry doesn't have any.
    """
    from planecompose.parser.workflows_yaml import parse_states_yaml
    from planecompose.constants import FILE_STATES_YAML

    states_by_name: dict[str, StateDefinition] = {}

    states_yaml_path = schema_dir / FILE_STATES_YAML
    if states_yaml_path.exists():
        try:
            raw = parse_states_yaml(states_yaml_path)
            for name, attrs in (raw or {}).items():
                if not name:
                    continue
                try:
                    states_by_name[name.lower()] = StateDefinition(
                        name=name,
                        description=attrs.get('description'),
                        color=attrs.get('color'),
                        group=attrs.get('group', 'unstarted'),
                        remote_id=attrs.get('id'),
                        allow_issue_creation=attrs.get('allow_issue_creation', True),
                        is_default=attrs.get('is_default', False),
                        type=attrs.get('type', 'transition'),
                    )
                except Exception:
                    continue
        except Exception:
            pass

    for workflow in workflows:
        for state in workflow.states:
            key = state.name.lower()
            if key not in states_by_name:
                states_by_name[key] = state
            elif state.transitions and not states_by_name[key].transitions:
                states_by_name[key].transitions = state.transitions

    return list(states_by_name.values())

