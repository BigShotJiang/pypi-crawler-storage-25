"""Workspace feature detection and synchronization."""

import time
from typing import Any, cast

from planecompose.backend.client import PlaneApiClient
from planecompose.config.context import ProjectContext
from planecompose.core.models import WorkspaceConfig
from planecompose.utils.logger import get_logger

logger = get_logger()

# ── Retry configuration for HTTP 429 (Too Many Requests) ─────────────────────
_RETRY_MAX = 3           # maximum number of retries after the initial attempt
_RETRY_INITIAL_DELAY = 2.0   # seconds to wait before the first retry
_RETRY_BACKOFF = 2.0     # multiply delay by this factor on each retry


def _http_get_with_retry(
    session: Any,
    url: str,
    headers: dict[str, str],
    timeout: float,
) -> tuple[Any, bool]:
    """Perform a GET request with automatic 429 retry and exponential backoff.

    Returns ``(response, success)`` where:
    - ``success`` is False only when the request raised a network exception.
    - ``response`` is the final response object (which may still be non-200,
      e.g. 404 or 429 after max retries); callers must check ``.status_code``.

    This lets callers inspect the status code (e.g. to treat 404 differently
    from 429) while still benefiting from centralised retry logic.
    """
    delay = _RETRY_INITIAL_DELAY
    response = None
    for attempt in range(_RETRY_MAX + 1):  # 0 = initial, 1..N = retries
        try:
            response = session.get(url, headers=headers, timeout=timeout)
        except Exception as e:
            logger.warning(f"GET {url} failed: {e}")
            return None, False

        if response.status_code != 429:
            return response, True  # success (even if non-200 — caller decides)

        # ── 429 handling ──────────────────────────────────────────────────────
        if attempt >= _RETRY_MAX:
            logger.warning(
                f"GET {url} returned HTTP 429 — max retries ({_RETRY_MAX}) exhausted"
            )
            return response, True  # return the 429 so caller can log/record it

        # Honour Retry-After header when the server sends one.
        retry_after_hdr = response.headers.get("Retry-After")
        wait = float(retry_after_hdr) if retry_after_hdr else delay
        logger.warning(
            f"GET {url} returned HTTP 429 — retrying in {wait:.0f}s "
            f"(attempt {attempt + 1}/{_RETRY_MAX})"
        )
        time.sleep(wait)
        delay *= _RETRY_BACKOFF

    return response, True  # unreachable — loop always returns inside


def workspace_http_get(client: PlaneApiClient, url: str) -> list | dict | None:
    """Direct GET via the SDK session, returning parsed JSON.

    Centralises the repeated boilerplate of building headers / timeout from the
    SDK config.  Automatically unwraps Plane's paginated envelope: if the
    response body is ``{"results": [...], "total_count": N, ...}`` only the
    list under ``results`` is returned.  Raw-list responses (e.g.
    work-item-properties) are returned as-is.

    Handles HTTP 429 (Too Many Requests) transparently via ``_http_get_with_retry``.
    Returns ``None`` only when all retries are exhausted or a network error
    occurs — callers should treat ``None`` as "data unavailable, preserve local".
    """
    headers = {
        "X-Api-Key": client.sdk.config.api_key,
        "Content-Type": "application/json",
    }
    response, ok = _http_get_with_retry(
        client.sdk.workspaces.session,
        url,
        headers,
        client.sdk.config.timeout,
    )

    if not ok or response is None:
        return None  # network error — already logged

    if response.status_code != 200:
        logger.warning(f"GET {url} returned HTTP {response.status_code}")
        return None

    data = response.json()
    if isinstance(data, dict) and "results" in data:
        return cast(list[Any], data["results"])
    return cast(list[Any] | dict[Any, Any], data)


def fetch_workspace_features(client: PlaneApiClient, workspace_slug: str) -> dict[str, bool]:
    """
    Fetch workspace features from the Plane API.

    Args:
        client: PlaneApiClient instance
        workspace_slug: Workspace slug to fetch features for

    Returns:
        Dictionary of feature flags, or empty dict if API call fails
    """
    try:
        # Call the SDK method to get workspace features
        workspace_features = client.sdk.workspaces.get_features(workspace_slug=workspace_slug)

        # Convert WorkspaceFeature model to dict
        # Include work_item_types flag if available (Enterprise feature)
        features = {
            "project_grouping": workspace_features.project_grouping,
            "initiatives": workspace_features.initiatives,
            "teams": workspace_features.teams,
            "customers": workspace_features.customers,
            "wiki": workspace_features.wiki,
            "pi": workspace_features.pi,
        }

        # Add work_item_types if available (Enterprise only)
        if hasattr(workspace_features, "work_item_types"):
            features["work_item_types"] = workspace_features.work_item_types

        logger.debug(f"Fetched workspace features for {workspace_slug}: {features}")
        return features

    except Exception as e:
        logger.warning(f"Failed to fetch workspace features for {workspace_slug}: {e}")
        # Return empty dict on failure — commands will proceed without feature checks
        return {}


def sync_workspace_features(context: ProjectContext, client: PlaneApiClient | None = None) -> bool:
    """
    Sync workspace features from the API and update context.

    Args:
        context: ProjectContext to update
        client: Optional PlaneApiClient instance. If None, will be created.

    Returns:
        True if features were updated, False if no changes
    """
    # Initialize workspace_config if not present
    if context.workspace_config is None:
        context.workspace_config = WorkspaceConfig(workspace=context.config.workspace)

    if client is None:
        # Create a client for the context
        client = PlaneApiClient(
            api_url=context.config.api_url,
            api_key=context.api_key,
            token_type=context.token_type,
            connection_id=context.config.connection_id or "default",
        )

    # Fetch current features from API
    new_features = fetch_workspace_features(client, context.config.workspace)

    if not new_features:
        # API call failed or returned empty — don't update
        return False

    # Check if features have changed
    old_features = context.workspace_config.workspace_features or {}
    if old_features == new_features:
        logger.debug(f"Workspace features unchanged for {context.config.workspace}")
        return False

    # Update context with new features
    logger.info(f"Updated workspace features for {context.config.workspace}")
    if old_features:
        # Log what changed
        for key, new_val in new_features.items():
            old_val = old_features.get(key)
            if old_val != new_val:
                logger.debug(f"  {key}: {old_val} → {new_val}")

    context.workspace_config.workspace_features = new_features
    return True


def get_feature_flag(context: ProjectContext, feature_name: str) -> bool:
    """
    Get a workspace feature flag value.

    Args:
        context: ProjectContext
        feature_name: Name of the feature (e.g., "work_item_types", "initiatives")

    Returns:
        True if feature is enabled, False otherwise (default)
    """
    if not context.workspace_config or not context.workspace_config.workspace_features:
        return False

    return context.workspace_config.workspace_features.get(feature_name, False)


def fetch_workspace_work_item_types(client: PlaneApiClient, workspace_slug: str) -> dict[str, Any]:
    """
    Fetch workspace-level work item types from the Plane API.

    The endpoint is not yet exposed in the SDK, so we make a direct HTTP call.
    Endpoint: GET /api/v1/workspaces/{slug}/work-item-types/

    # TODO(sdk-refactor): SDK has work_item_types.list() but it is project-scoped.
    # Replace with client.sdk.work_item_types.list(workspace_slug=...) once the
    # SDK adds workspace-level list support.

    Args:
        client: PlaneApiClient instance
        workspace_slug: Workspace slug to fetch types for

    Returns:
        Dictionary mapping type ID to type data, or empty dict if API call fails or feature disabled
    """
    base_url = client.sdk.config.base_path  # e.g., https://phoenix.plane.town/api/v1
    url = f"{base_url}/workspaces/{workspace_slug}/work-item-types/"
    logger.debug(f"Fetching workspace work item types from: {url}")

    headers = {
        "X-Api-Key": client.sdk.config.api_key,
        "Content-Type": "application/json",
    }
    response, ok = _http_get_with_retry(
        client.sdk.work_item_types.session,
        url,
        headers,
        client.sdk.config.timeout,
    )

    if not ok or response is None:
        # Network-level failure — already logged by _http_get_with_retry.
        return {}

    logger.debug(f"API response status: {response.status_code}")

    if response.status_code == 200:
        types_list = response.json()
        # Convert flat list to dict keyed by type ID for easier lookup.
        types_dict = {wit["id"]: wit for wit in types_list}
        logger.info(
            f"✓ Fetched {len(types_dict)} workspace work item types for {workspace_slug}"
        )
        return types_dict

    if response.status_code == 404:
        # Endpoint might not exist on non-Enterprise plans or older Plane versions.
        logger.info(
            "Workspace work item types endpoint returned 404 — feature may not be enabled"
        )
        return {}

    logger.warning(
        f"Failed to fetch workspace work item types for {workspace_slug}: "
        f"HTTP {response.status_code}"
    )
    logger.debug(f"Response body: {response.text[:200]}")
    return {}


_OPTION_PROPERTY_TYPES = frozenset({"OPTION", "MULTI_OPTION"})


def fetch_customer_properties(client: PlaneApiClient, workspace_slug: str) -> list[dict] | None:
    """
    Fetch customer property definitions from the Plane API.

    Only call when the workspace has the ``customers`` feature enabled.

    The list endpoint (``GET /customer-properties/``) omits ``options`` for
    OPTION / MULTI_OPTION properties.  For those, we make an additional call to
    the detail endpoint (``GET /customer-properties/{id}/``) which includes the
    full ``options`` list.

    Endpoints used:
        GET /api/v1/workspaces/{slug}/customer-properties/
        GET /api/v1/workspaces/{slug}/customer-properties/{id}/   (OPTION types only)

    Args:
        client: PlaneApiClient instance
        workspace_slug: Workspace slug to fetch properties for

    Returns:
        List of customer property dicts (options populated for OPTION/MULTI_OPTION),
        empty list if none exist, or None on error.
    """
    base_url = client.sdk.config.base_path
    url = f"{base_url}/workspaces/{workspace_slug}/customer-properties/"
    logger.debug(f"Fetching customer properties from: {url}")

    data = workspace_http_get(client, url)

    if data is None:
        logger.warning(f"Customer properties fetch failed for {workspace_slug}")
        return None

    if not isinstance(data, list):
        logger.warning(
            f"Unexpected customer properties response type: {type(data)!r} for {workspace_slug}"
        )
        return []

    # For OPTION / MULTI_OPTION properties the list endpoint does not include
    # the option values — fetch the detail endpoint to populate them.
    for i, prop in enumerate(data):
        if not isinstance(prop, dict):
            continue
        prop_type = prop.get("property_type", "")
        if prop_type not in _OPTION_PROPERTY_TYPES:
            continue
        prop_id = prop.get("id")
        if not prop_id:
            continue
        detail_url = f"{base_url}/workspaces/{workspace_slug}/customer-properties/{prop_id}/"
        logger.debug(f"Fetching options for OPTION property '{prop.get('name')}' from: {detail_url}")
        detail = workspace_http_get(client, detail_url)
        if detail and isinstance(detail, dict) and "options" in detail:
            # Filter out soft-deleted options (is_active: false) before storing.
            # The PATCH endpoint uses is_active: false to soft-delete options, but
            # subsequent GETs still return those entries in the list.
            detail["options"] = [
                o for o in detail["options"]
                if isinstance(o, dict) and o.get("is_active", True)
            ]
            data[i] = detail  # replace list-level entry with detail (has options)
            logger.debug(
                f"  ✓ Populated {len(detail['options'])} active options for '{prop.get('name')}'"
            )

    logger.info(f"✓ Fetched {len(data)} active customer properties for {workspace_slug}")
    return data


def fetch_workspace_members(client: PlaneApiClient, workspace_slug: str) -> list[dict]:
    """
    Fetch workspace members from the Plane API.

    Uses the SDK's workspaces.get_members() call which maps to:
    GET /api/v1/workspaces/{slug}/members/

    Args:
        client: PlaneApiClient instance
        workspace_slug: Workspace slug to fetch members for

    Returns:
        List of member dicts (id, email, display_name), or empty list if fetch failed
    """
    try:
        members = client.sdk.workspaces.get_members(workspace_slug=workspace_slug)
        result = []
        for m in members or []:
            # Skip bot users (e.g. bot_user123@plane.so)
            if m.email and m.email.startswith("bot_user"):
                logger.debug(f"Skipping bot user: {m.email}")
                continue
            entry: dict = {}
            if m.id:
                entry["id"] = m.id
            if m.email:
                entry["email"] = m.email
            if m.display_name:
                entry["display_name"] = m.display_name
            if entry:
                result.append(entry)
        logger.info(f"✓ Fetched {len(result)} workspace members for {workspace_slug}")
        return result
    except Exception as e:
        logger.warning(f"Failed to fetch workspace members for {workspace_slug}: {e}")
        return []


def sync_workspace_members(context: ProjectContext, client: PlaneApiClient | None = None) -> bool:
    """
    Sync workspace members from the API and update context.

    Members are always fetched — they are not behind a feature flag.

    Args:
        context: ProjectContext to update
        client: Optional PlaneApiClient instance. If None, will be created.

    Returns:
        True if members were fetched and stored, False if fetch failed or returned empty
    """
    if context.workspace_config is None:
        context.workspace_config = WorkspaceConfig(workspace=context.config.workspace)

    if client is None:
        client = PlaneApiClient(
            api_url=context.config.api_url,
            api_key=context.api_key,
            token_type=context.token_type,
            connection_id=context.config.connection_id or "default",
        )

    members = fetch_workspace_members(client, context.config.workspace)

    if not members:
        logger.debug(f"No workspace members returned from API for {context.config.workspace}")
        return False

    context.workspace_config.members = members
    logger.info(f"✓ Synced {len(members)} workspace members")
    return True


def sync_workspace_work_item_types(
    context: ProjectContext, client: PlaneApiClient | None = None
) -> bool:
    """
    Sync workspace-level work item types from the API and update context.

    Only fetches if the workspace has work_item_types feature enabled.

    Args:
        context: ProjectContext to update
        client: Optional PlaneApiClient instance. If None, will be created.

    Returns:
        True if types were fetched, False if skipped or fetch failed
    """
    # Initialize workspace_config if not present
    if context.workspace_config is None:
        context.workspace_config = WorkspaceConfig(workspace=context.config.workspace)

    # Check if feature is enabled first
    workspace_features = context.workspace_config.workspace_features or {}
    feature_enabled = workspace_features.get("work_item_types", False)
    logger.info(
        f"Checking workspace_work_item_types feature for {context.config.workspace}: {feature_enabled}"
    )
    logger.debug(f"Available features: {workspace_features}")

    if not feature_enabled:
        logger.debug(
            f"Workspace work_item_types feature not enabled for {context.config.workspace} — skipping fetch"
        )
        return False

    if client is None:
        # Create a client for the context
        client = PlaneApiClient(
            api_url=context.config.api_url,
            api_key=context.api_key,
            token_type=context.token_type,
            connection_id=context.config.connection_id or "default",
        )

    # Fetch workspace work item types from API
    logger.debug("Fetching workspace work item types from API...")
    workspace_types = fetch_workspace_work_item_types(client, context.config.workspace)

    if not workspace_types:
        # API call failed or returned empty
        logger.debug("No workspace work item types returned from API")
        return False

    # Convert dict (keyed by id) back to list for storage
    workspace_types_list = list(workspace_types.values()) if workspace_types else []

    # Store in workspace config (will be persisted to workspace.yaml)
    context.workspace_config.work_item_types = workspace_types_list
    logger.info(f"✓ Synced {len(workspace_types_list)} workspace work item types")
    for wit_data in workspace_types_list:
        logger.debug(f"  - {wit_data.get('name', 'Unknown')} ({wit_data.get('id', 'unknown-id')})")
    return True
