"""Plane API client wrapper with rate limiting, retry, and error translation.

This module provides a thin wrapper around the Plane SDK client that:
- Applies rate limiting to all API calls
- Retries transient errors with exponential backoff
- Translates SDK exceptions to planecompose exceptions
- Provides logging for debugging

All API calls in the application should go through this wrapper.
"""
import asyncio
import inspect
import random
from typing import Callable, TypeVar

from plane import PlaneClient, HttpError

from planecompose.exceptions import (
    APIError,
    AuthenticationError,
    PermissionError,
    NotFoundError,
    RateLimitError,
    NetworkError,
    TimeoutError as PlaneTimeoutError,
)
from planecompose.utils.rate_limit import RateLimiter
from planecompose.utils.rate_limit_state import RateLimitState
from planecompose.utils.logger import get_logger

logger = get_logger()

T = TypeVar('T')


class PlaneApiClient:
    """
    Wrapper around PlaneClient with rate limiting and error translation.

    This is the ONLY place that should directly interact with PlaneClient.
    All other code should use this wrapper.

    Rate limiting is PER CONNECTION to support multi-connection setups where
    different Plane instances may have different rate limits.

    Usage:
        client = PlaneApiClient(api_url, api_key, connection_id="my-connection")
        result = await client.call(
            client.sdk.work_items.list,
            workspace_slug="my-workspace",
            project_id="project-uuid",
        )
    """

    # Rate limiters per connection (initialized lazily from Settings)
    _rate_limiters: dict[str, RateLimiter] = {}
    _persistent_state: RateLimitState | None = None

    @classmethod
    def _get_persistent_state(cls) -> RateLimitState:
        """Get or create persistent state manager for rate limits."""
        if cls._persistent_state is None:
            from planecompose.config.settings import get_settings
            settings = get_settings()
            state_file = settings.config_dir / "rate-limits.json"
            cls._persistent_state = RateLimitState(state_file)
        return cls._persistent_state

    @classmethod
    def _get_or_create_rate_limiter(cls, connection_id: str) -> RateLimiter:
        """Get or create a rate limiter for the given connection."""
        if connection_id not in cls._rate_limiters:
            from planecompose.config.settings import get_settings
            settings = get_settings()
            persistent_state = cls._get_persistent_state()
            cls._rate_limiters[connection_id] = RateLimiter(
                requests_per_minute=settings.rate_limit_per_minute,
                persistent_state=persistent_state,
                connection_id=connection_id,
            )
        return cls._rate_limiters[connection_id]

    def __init__(self, api_url: str, api_key: str, token_type: str = "workspace", connection_id: str = "default"):
        """
        Initialize the API client.

        Args:
            api_url: Plane API base URL (e.g., "https://api.plane.so")
            api_key: API key for authentication
            token_type: "pat" for Personal Access Token, "workspace" for Workspace Token
            connection_id: Unique identifier for this connection (for per-connection rate limiting)
        """
        self._api_url = api_url
        self._api_key = api_key
        self._token_type = token_type
        self._connection_id = connection_id
        # Both PAT and workspace tokens use X-Api-Key header in the Plane API.
        # Bearer/access_token is not supported for plane_api_xxx tokens.
        self._client = PlaneClient(base_url=api_url, api_key=api_key)
        # Ensure rate limiter is initialized for this connection
        self._get_or_create_rate_limiter(connection_id)

    @property
    def sdk(self) -> PlaneClient:
        """Access the underlying SDK client for method references."""
        return self._client

    @classmethod
    def get_rate_limiter(cls, connection_id: str = "default") -> RateLimiter:
        """Get the rate limiter for a specific connection."""
        return cls._get_or_create_rate_limiter(connection_id)

    @classmethod
    def get_all_rate_limiters(cls) -> dict[str, RateLimiter]:
        """Get all rate limiters for all connections (for debugging)."""
        return cls._rate_limiters.copy()

    # Status codes that are safe to retry (transient errors)
    _RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}

    async def call(self, func: Callable[..., T], *args, **kwargs) -> T:
        """
        Execute an API call with rate limiting, retry, and error translation.

        Retries transient errors (429, 5xx) with exponential backoff and jitter.

        Args:
            func: The SDK method to call (e.g., client.sdk.work_items.list)
            *args: Positional arguments for the method
            **kwargs: Keyword arguments for the method

        Returns:
            The result from the SDK method

        Raises:
            AuthenticationError: For 401 errors
            PermissionError: For 403 errors
            NotFoundError: For 404 errors
            RateLimitError: For 429 errors (after retries exhausted)
            APIError: For other HTTP errors
            NetworkError: For connection failures (after retries exhausted)
        """
        from planecompose.config.settings import get_settings
        max_retries = get_settings().plane_api_retry_attempts

        func_name = getattr(func, '__name__', str(func))
        last_error: Exception | None = None

        for attempt in range(max_retries + 1):
            await self._get_or_create_rate_limiter(self._connection_id).acquire()

            if attempt > 0:
                logger.debug(f"API call retry {attempt}/{max_retries}: {func_name}")

            try:
                if inspect.iscoroutinefunction(func):
                    result = await func(*args, **kwargs)
                else:
                    result = func(*args, **kwargs)

                logger.debug(f"API call successful: {func_name}")
                return result  # type: ignore[no-any-return]

            except HttpError as e:
                translated = self._translate_http_error(e, func_name)
                last_error = translated
                status_code = getattr(e, 'status_code', 500)

                if status_code in self._RETRYABLE_STATUS_CODES and attempt < max_retries:
                    # Use Retry-After header for 429, otherwise exponential backoff
                    if status_code == 429 and isinstance(translated, RateLimitError) and translated.retry_after:
                        delay = translated.retry_after
                    else:
                        delay = min(2 ** attempt + random.uniform(0, 1), 30)
                    logger.warning(
                        f"Retryable error {status_code} on {func_name}, "
                        f"retrying in {delay:.1f}s (attempt {attempt + 1}/{max_retries})"
                    )
                    await asyncio.sleep(delay)
                    continue

                raise translated

            except (ConnectionError, TimeoutError) as e:
                last_error = e
                if attempt < max_retries:
                    delay = min(2 ** attempt + random.uniform(0, 1), 30)
                    logger.warning(
                        f"Network error on {func_name}, "
                        f"retrying in {delay:.1f}s (attempt {attempt + 1}/{max_retries})"
                    )
                    await asyncio.sleep(delay)
                    continue

                if isinstance(e, TimeoutError):
                    raise PlaneTimeoutError(
                        message=f"Request timed out: {e}",
                        original_error=e,
                    )
                raise NetworkError(
                    message=f"Connection failed: {e}",
                    original_error=e,
                )

        # Should not reach here, but just in case
        raise last_error  # type: ignore[misc]

    def _translate_http_error(self, error: HttpError, context: str = "") -> APIError:
        """
        Translate SDK HttpError to appropriate planecompose exception.

        This is the SINGLE place where HTTP status codes are mapped to exceptions.
        No string-based detection needed anywhere else.
        """
        status_code = getattr(error, 'status_code', 500)
        error_detail = self._extract_error_detail(error)

        logger.error(f"API error {status_code}: {error_detail}")

        if status_code == 401:
            return AuthenticationError()
        elif status_code == 402:
            return APIError(
                message=(
                    "This feature requires a paid Plane plan. "
                    "The /work-items/ API is available on Pro and above. "
                    "If you are on the free tier, this endpoint is not accessible."
                ),
                status_code=status_code,
                endpoint=context,
            )
        elif status_code == 403:
            return PermissionError(resource=context)
        elif status_code == 404:
            return NotFoundError(resource=context or "Resource")
        elif status_code == 429:
            retry_after = self._extract_retry_after(error)
            return RateLimitError(retry_after=retry_after)
        else:
            return APIError(
                message=error_detail,
                status_code=status_code,
                endpoint=context,
            )

    def _extract_error_detail(self, error: HttpError) -> str:
        """Extract detailed error message from SDK error.

        The SDK raises HttpError with `response` set to the already-parsed
        payload — either a dict (JSON) or a raw string. It is NOT an httpx
        response object, so we must not call .json() on it.
        """
        payload = getattr(error, 'response', None)
        if payload is not None:
            try:
                if isinstance(payload, dict):
                    # Simple top-level message fields
                    simple = (
                        payload.get('detail') or
                        payload.get('error') or
                        payload.get('message')
                    )
                    if simple:
                        return str(simple)
                    # DRF field-level validation errors: {"field": ["msg", ...], ...}
                    parts = []
                    for field, msgs in payload.items():
                        if isinstance(msgs, list):
                            parts.append(f"{field}: {', '.join(str(m) for m in msgs)}")
                        else:
                            parts.append(f"{field}: {msgs}")
                    if parts:
                        return "; ".join(parts)
                    return str(payload)
                if isinstance(payload, str) and payload:
                    return payload[:300]
            except (AttributeError, KeyError, TypeError, ValueError):
                pass
        return str(error)

    def _extract_retry_after(self, error: HttpError) -> int | None:
        """Extract retry-after header from rate limit error."""
        if hasattr(error, 'response') and error.response:
            retry_after = error.response.headers.get('Retry-After')
            if retry_after:
                try:
                    return int(retry_after)
                except ValueError:
                    pass
        return None

    def close(self):
        """Close the client connection."""
        self._client = None


def detect_error_type(error: Exception) -> type:
    """
    Detect the type of error from an exception.

    This function provides CENTRALIZED error type detection for cases
    where we receive an exception that wasn't translated (e.g., from
    external code or edge cases).

    For most cases, use PlaneApiClient.call() which handles translation
    automatically. This function is a fallback for edge cases.

    Args:
        error: The exception to analyze

    Returns:
        The appropriate exception class to use
    """
    # If it's already one of our exceptions, return its type
    if isinstance(error, AuthenticationError):
        return AuthenticationError
    if isinstance(error, PermissionError):
        return PermissionError
    if isinstance(error, NotFoundError):
        return NotFoundError
    if isinstance(error, RateLimitError):
        return RateLimitError
    if isinstance(error, APIError):
        return APIError
    if isinstance(error, NetworkError):
        return NetworkError

    # Check for HttpError from SDK
    if isinstance(error, HttpError):
        status_code = getattr(error, 'status_code', 500)
        if status_code == 401:
            return AuthenticationError
        elif status_code == 403:
            return PermissionError
        elif status_code == 404:
            return NotFoundError
        elif status_code == 429:
            return RateLimitError
        else:
            return APIError

    # Check for common network errors by type (not by string matching,
    # which can produce false positives like "Processed 401 items").
    if isinstance(error, (ConnectionError, TimeoutError, OSError)):
        return NetworkError

    return APIError
