"""Workflow management and synchronization with Plane API.

This module provides:
- WorkflowContext: Data structure for managing workflows with state/transition mappings
- Workflow fetching from Plane API
- State name ↔ ID mapping utilities
- Sync helpers for workflow comparison and updates
"""
from typing import Any
from dataclasses import dataclass, field

from planecompose.utils.mapping import build_name_id_map
from planecompose.core.models import (
    WorkflowDefinition,
    StateDefinition,
    TransitionDefinition,
    RuleDefinition,
)
from planecompose.utils.logger import get_logger

logger = get_logger()


@dataclass
class WorkflowContext:
    """Context for a single workflow with state and transition mappings.

    Maintains bidirectional mappings between state names and IDs,
    which are essential for syncing workflows with Plane API.
    """
    workflow: WorkflowDefinition

    # State name → remote_id mapping (from Plane API)
    state_name_to_id: dict[str, str] = field(default_factory=dict)

    # State remote_id → name mapping (reverse lookup)
    state_id_to_name: dict[str, str] = field(default_factory=dict)

    # Script name → remote_id mapping (for rule resolution)
    script_name_to_id: dict[str, str] = field(default_factory=dict)

    # User email → remote_id mapping (for approver resolution)
    user_email_to_id: dict[str, str] = field(default_factory=dict)

    def add_state_mapping(self, name: str, remote_id: str) -> None:
        """Register a state name ↔ ID mapping."""
        self.state_name_to_id[name] = remote_id
        self.state_id_to_name[remote_id] = name

    def add_script_mapping(self, name: str, remote_id: str) -> None:
        """Register a script name → ID mapping."""
        self.script_name_to_id[name] = remote_id

    def add_user_mapping(self, email: str, remote_id: str) -> None:
        """Register a user email → ID mapping."""
        self.user_email_to_id[email] = remote_id

    def resolve_state_id(self, state_name: str) -> str | None:
        """Resolve a state name to its remote ID."""
        return self.state_name_to_id.get(state_name)

    def resolve_script_id(self, script_name: str) -> str | None:
        """Resolve a script name to its remote ID."""
        return self.script_name_to_id.get(script_name)

    def resolve_user_id(self, email: str) -> str | None:
        """Resolve a user email to its remote ID."""
        return self.user_email_to_id.get(email)

    def __repr__(self) -> str:
        return f"WorkflowContext({self.workflow.name}, {len(self.state_name_to_id)} states)"


@dataclass
class ProjectWorkflowContext:
    """Context for all workflows in a project.

    Maintains a collection of WorkflowContext objects and handles
    workflow-level operations (fetch, build mappings, etc).
    """
    project_id: str
    workspace_slug: str

    # Workflow name → WorkflowContext mapping
    workflows: dict[str, WorkflowContext] = field(default_factory=dict)

    # Shared script and user mappings (project-wide)
    script_name_to_id: dict[str, str] = field(default_factory=dict)
    user_email_to_id: dict[str, str] = field(default_factory=dict)

    def add_workflow(self, workflow_context: WorkflowContext) -> None:
        """Register a workflow context."""
        self.workflows[workflow_context.workflow.name] = workflow_context

    def get_workflow(self, name: str) -> WorkflowContext | None:
        """Get workflow context by name."""
        return self.workflows.get(name)

    def add_script_mapping(self, name: str, remote_id: str) -> None:
        """Register a project-wide script mapping."""
        self.script_name_to_id[name] = remote_id

    def add_user_mapping(self, email: str, remote_id: str) -> None:
        """Register a project-wide user mapping."""
        self.user_email_to_id[email] = remote_id

    def __repr__(self) -> str:
        return f"ProjectWorkflowContext({self.project_id}, {len(self.workflows)} workflows)"


def build_state_mapping(states_raw: list[dict[str, Any]]) -> tuple[dict[str, str], dict[str, str]]:
    """Build bidirectional state name ↔ ID mappings from API response.

    Args:
        states_raw: List of state dicts from Plane API

    Returns:
        Tuple of (name_to_id, id_to_name) mappings
    """
    name_to_id = build_name_id_map(states_raw)
    id_to_name = build_name_id_map(states_raw, id_key='name', name_key='id')
    return name_to_id, id_to_name


def build_script_mapping(scripts_raw: list[dict[str, Any]]) -> dict[str, str]:
    """Build script name → ID mapping from API response.

    Args:
        scripts_raw: List of script dicts from Plane API

    Returns:
        Dict of script_name -> script_id mappings
    """
    return build_name_id_map(scripts_raw)


def build_user_mapping(members_raw: list[dict[str, Any]]) -> dict[str, str]:
    """Build user email → ID mapping from API response.

    Args:
        members_raw: List of member dicts from Plane API

    Returns:
        Dict of email -> user_id mappings
    """
    return build_name_id_map(members_raw, name_key='email')


def parse_workflow_from_api(
    workflow_raw: dict[str, Any],
    state_name_to_id: dict[str, str],
    state_id_to_name: dict[str, str],
    type_id_to_name: dict[str, str] | None = None,
    user_id_to_email: dict[str, str] | None = None,
) -> WorkflowDefinition | None:
    """Parse a workflow from Plane API response into WorkflowDefinition.

    Args:
        workflow_raw: Raw workflow dict from Plane API
        state_name_to_id: State name → ID mapping
        state_id_to_name: State ID → name mapping (for reverse lookup)
        type_id_to_name: Optional Work item type UUID → name mapping for converting IDs to names
        user_id_to_email: Optional user UUID → email mapping for resolving approver member_ids

    Returns:
        WorkflowDefinition or None if parsing fails
    """
    try:
        workflow_id = str(workflow_raw.get('id', ''))
        workflow_name = workflow_raw.get('name', '')
        workflow_description = workflow_raw.get('description')
        is_active = workflow_raw.get('is_active', False)
        is_default = workflow_raw.get('is_default', False)
        work_item_type_ids = workflow_raw.get('work_item_type_ids', [])

        # Convert work_item_type_ids (UUIDs) to names if mapping is provided
        work_item_types = []
        if work_item_type_ids and type_id_to_name:
            for wit_id in work_item_type_ids:
                if wit_id in type_id_to_name:
                    work_item_types.append(type_id_to_name[wit_id])
                else:
                    # Keep the UUID if no mapping found
                    work_item_types.append(wit_id)

        if not workflow_name:
            logger.warning(f"Skipping workflow with missing name: {workflow_raw}")
            return None

        # Parse states and transitions.
        #
        # State entries come in two shapes depending on the endpoint:
        #   Public /api/v1/ WorkflowSerializer → no states at all (historic).
        #   Internal /api/ WorkspaceWorkflowEndpoint → compact objects:
        #       {id, allow_issue_creation, is_default, transitions, type}
        #     (no name/group/color — those live in the project's state list).
        #
        # We resolve the name from state_id_to_name when the raw entry lacks
        # it; otherwise we'd skip every state and end up with empty workflows.
        states: list[StateDefinition] = []
        states_raw = workflow_raw.get('states', []) or []

        for state_raw in states_raw:
            # When the payload comes from /workflows/{id}/states/ the row is
            # a WorkflowState junction record: `id` is the junction row, and
            # `state_id` is the actual State FK. Prefer `state_id` so we can
            # resolve the name via state_id_to_name (which is keyed on State
            # UUIDs). Fall back to `id` only for the legacy shape where the
            # workflow payload embeds full state objects directly.
            state_id = str(state_raw.get('state_id') or state_raw.get('id') or '')
            state_name = state_raw.get('name') or ''

            # If the entry doesn't carry a name, resolve it via the project
            # state map we already built.
            if state_id and not state_name:
                state_name = state_id_to_name.get(state_id, '') or state_id_to_name.get(str(state_id), '')

            # Skip only if we still have no usable identifier.
            if not state_id or not state_name:
                logger.warning(f"Skipping state with missing id/name: {state_raw}")
                continue

            # Parse transitions for this state
            transitions: list[TransitionDefinition] = []
            transitions_raw = state_raw.get('transitions', [])

            for trans_raw in transitions_raw:
                # Target state comes in several forms across endpoints:
                #   to_state_id       — legacy public shape
                #   transition_state_id — internal WorkspaceWorkflowEndpoint
                #   to                — already-resolved name (from another writer)
                target_state_id = (
                    trans_raw.get('to_state_id')
                    or trans_raw.get('transition_state_id')
                )
                target_state_name = None
                if target_state_id:
                    target_state_name = state_id_to_name.get(str(target_state_id))

                # Fall back to an explicit 'to' field if the id→name lookup
                # failed (e.g. the writer produced a name-keyed transition list).
                if not target_state_name:
                    target_state_name = trans_raw.get('to')

                if not target_state_name:
                    logger.warning(f"Skipping transition with missing target state: {trans_raw}")
                    continue

                # Resolve rejection state (approval workflows only).
                # API returns rejection_state_id as a UUID; resolve to name.
                rejection_state: str | None = None
                rejection_state_id = trans_raw.get('rejection_state_id')
                if rejection_state_id:
                    rejection_state = state_id_to_name.get(str(rejection_state_id))

                # Resolve approvers.
                # Internal endpoint returns member_ids (UUIDs); public endpoint
                # returns approvers (already emails or names). Try both.
                approvers: list[str] = []
                member_ids = trans_raw.get('member_ids') or []
                if member_ids and user_id_to_email:
                    # Resolve UUIDs → emails; skip any unmapped IDs
                    for uid in member_ids:
                        email = user_id_to_email.get(str(uid))
                        if email:
                            approvers.append(email)
                        else:
                            approvers.append(str(uid))  # Keep UUID as fallback
                elif not member_ids:
                    # Public endpoint may already provide email-keyed approvers
                    approvers = list(trans_raw.get('approvers', []))

                # Parse transition rules.
                # Internal endpoint → pre_rules / post_rules
                # Public endpoint  → pre_hooks  / post_hooks
                # Accept both so the parser works regardless of which endpoint
                # was reachable. config.script_id holds the script UUID.
                pre_rules: list[RuleDefinition] = []
                post_rules: list[RuleDefinition] = []

                for rule_raw in (trans_raw.get('pre_rules') or trans_raw.get('pre_hooks') or []):
                    handler = rule_raw.get('handler_name') or rule_raw.get('handler', 'run_script')
                    config = rule_raw.get('config') or {}
                    # Prefer explicit 'script' field (YAML round-trip); fall back
                    # to config.script_id (UUID from API — push resolves it).
                    pre_rules.append(RuleDefinition(
                        handler=handler,
                        script_id=config.get('script_id', ''),
                        config=config,
                    ))

                for rule_raw in (trans_raw.get('post_rules') or trans_raw.get('post_hooks') or []):
                    handler = rule_raw.get('handler_name') or rule_raw.get('handler', 'run_script')
                    config = rule_raw.get('config') or {}
                    post_rules.append(RuleDefinition(
                        handler=handler,
                        script_id=config.get('script_id', ''),
                        config=config,
                    ))

                # flow_type lives on the WorkflowState row, not on individual
                # WorkflowTransition rows. Read it from the parent state_raw.
                trans_type = state_raw.get('type', 'transition')

                # Create transition — capture the remote ID so we can PATCH
                # conditions on existing transitions via update_workflow_transition().
                trans_remote_id = trans_raw.get('id')

                transitions.append(TransitionDefinition(
                    to=target_state_name,
                    type=trans_type,
                    required_approvals=trans_raw.get('required_approvals'),
                    approvers=approvers,
                    rejection_state=rejection_state,
                    pre_rules=pre_rules,
                    post_rules=post_rules,
                    remote_id=str(trans_remote_id) if trans_remote_id else None,
                ))

            # Create state
            states.append(StateDefinition(
                name=state_name,
                description=state_raw.get('description'),
                color=state_raw.get('color'),
                group=state_raw.get('group', 'unstarted'),
                remote_id=state_id,
                allow_issue_creation=state_raw.get('allow_issue_creation', True),
                is_default=state_raw.get('is_default', False),
                type=state_raw.get('type', 'transition'),
                transitions=transitions,
            ))

        # Create workflow
        return WorkflowDefinition(
            name=workflow_name,
            description=workflow_description,
            states=states,
            is_active=is_active,
            is_default=is_default,
            work_item_types=work_item_types,
            remote_id=workflow_id,
            created_by=workflow_raw.get('created_by'),
            updated_by=workflow_raw.get('updated_by'),
        )

    except Exception as e:
        logger.error(f"Error parsing workflow from API: {e}", exc_info=True)
        return None


def normalize_workflow_definition(
    workflow: WorkflowDefinition,
    state_name_to_id: dict[str, str],
) -> WorkflowDefinition:
    """Normalize a WorkflowDefinition with remote state IDs.

    This function ensures all transitions reference valid states
    and resolves state names to IDs where needed.

    Args:
        workflow: The workflow to normalize
        state_name_to_id: State name → ID mapping

    Returns:
        Normalized WorkflowDefinition
    """
    # Validate all states and transitions reference known states
    known_state_names = {s.name for s in workflow.states}

    for state in workflow.states:
        for transition in state.transitions:
            if transition.to not in known_state_names:
                logger.warning(
                    f"Transition from {state.name} to {transition.to} "
                    f"references unknown state (valid: {known_state_names})"
                )

    # Enrich states with remote IDs where available
    for state in workflow.states:
        if not state.remote_id and state.name in state_name_to_id:
            state.remote_id = state_name_to_id[state.name]

    return workflow
