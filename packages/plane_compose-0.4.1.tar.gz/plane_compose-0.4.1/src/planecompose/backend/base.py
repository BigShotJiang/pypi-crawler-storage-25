"""Abstract backend interface.

This module defines the abstract Backend class that all backend implementations
must inherit from. The interface provides a consistent API for:
- Connection management
- Schema operations (types, states, labels)
- Work item CRUD operations
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from planecompose.core.models import (
    WorkItemTypeDefinition,
    StateDefinition,
    LabelDefinition,
    WorkItem,
    ProjectConfig,
)

if TYPE_CHECKING:
    from planecompose.backend.cache import SchemaCache


class Backend(ABC):
    """Abstract interface for project management backends.

    All backend implementations (e.g., PlaneBackend) must implement these methods.
    This enables testing with mock backends and potential support for other
    project management systems in the future.
    """

    @abstractmethod
    async def connect(self, config: ProjectConfig, api_key: str) -> None:
        """Establish connection to the backend.

        Args:
            config: Project configuration including workspace, project key, and API URL
            api_key: Authentication token for the backend API

        Raises:
            AuthenticationError: If the API key is invalid
            NetworkError: If connection cannot be established
        """
        pass

    @abstractmethod
    async def disconnect(self) -> None:
        """Close connection and release resources.

        Should be called when done with the backend to clean up connections
        and invalidate any cached data.
        """
        pass

    @abstractmethod
    async def list_types(self) -> list[WorkItemTypeDefinition]:
        """List all work item types from remote.

        Returns:
            List of work item type definitions (e.g., bug, task, feature)
        """
        pass

    @abstractmethod
    async def create_type(self, type_def: WorkItemTypeDefinition) -> str:
        """Create a new work item type.

        Args:
            type_def: Definition of the type to create

        Returns:
            Remote ID of the created type

        Raises:
            APIError: If creation fails
        """
        pass

    @abstractmethod
    async def list_states(self) -> list[StateDefinition]:
        """List all workflow states from remote.

        Returns:
            List of state definitions (e.g., backlog, in_progress, done)
        """
        pass

    @abstractmethod
    async def create_state(self, state: StateDefinition) -> str:
        """Create a new workflow state.

        Args:
            state: Definition of the state to create

        Returns:
            Remote ID of the created state

        Raises:
            APIError: If creation fails
        """
        pass

    @abstractmethod
    async def list_labels(self) -> list[LabelDefinition]:
        """List all labels from remote.

        Returns:
            List of label definitions
        """
        pass

    @abstractmethod
    async def create_label(self, label: LabelDefinition) -> str:
        """Create a new label.

        Args:
            label: Definition of the label to create

        Returns:
            Remote ID of the created label

        Raises:
            APIError: If creation fails
        """
        pass

    @abstractmethod
    async def create_work_item(self, work_item: WorkItem) -> str:
        """Create a new work item.

        Args:
            work_item: Work item to create

        Returns:
            Remote ID of the created work item

        Raises:
            APIError: If creation fails
            ValidationError: If work item data is invalid
        """
        pass

    @abstractmethod
    async def update_work_item(self, remote_id: str, work_item: WorkItem) -> None:
        """Update an existing work item.

        Args:
            remote_id: Remote ID of the work item to update
            work_item: Updated work item data

        Raises:
            APIError: If update fails
            NotFoundError: If work item doesn't exist
        """
        pass

    @abstractmethod
    async def delete_work_item(self, remote_id: str) -> None:
        """Delete a work item from remote.

        Args:
            remote_id: Remote ID of the work item to delete

        Raises:
            APIError: If deletion fails
            NotFoundError: If work item doesn't exist
        """
        pass

    @abstractmethod
    def get_cache(self) -> SchemaCache:
        """Return the schema cache.

        The cache must have been populated by a prior call to
        :meth:`ensure_schema_loaded` or a connect/list operation.
        """
        pass

    @abstractmethod
    async def ensure_schema_loaded(self) -> None:
        """Load and cache schema data (types, states, labels) if not already loaded.

        Implementations should make this idempotent -- calling it multiple
        times should not re-fetch data that is already cached.
        """
        pass

    @abstractmethod
    async def list_work_items(self) -> list[WorkItem]:
        """List all work items from remote.

        Returns:
            List of work items in the project
        """
        pass
