"""Caching manager for types, states, and labels.

This module provides in-memory caching with O(1) lookups for:
- Work item types (name -> ID)
- States (name -> ID)
- Labels (name -> ID)

The cache is loaded lazily on first access and can be invalidated
when schema changes are made.
"""
import asyncio
from dataclasses import dataclass
from typing import Callable, Awaitable

from planecompose.core.models import (
    WorkItemTypeDefinition,
    StateDefinition,
    LabelDefinition,
)
from planecompose.utils.logger import get_logger

logger = get_logger()


@dataclass
class CacheEntry:
    """A cached item with its remote ID."""
    name: str
    remote_id: str


class SchemaCache:
    """
    In-memory cache for types, states, and labels with O(1) lookups.

    This cache dramatically improves performance by:
    1. Loading all schema data once at startup
    2. Pre-building lookup maps for instant name -> ID resolution
    3. Allowing batch loading in parallel

    Usage:
        cache = SchemaCache()
        await cache.load(fetch_types, fetch_states, fetch_labels)

        type_id = cache.get_type_id("task")  # O(1) lookup
        state_id = cache.get_state_id("in_progress")  # O(1) lookup
    """

    def __init__(self):
        # Cached data
        self._types: list[WorkItemTypeDefinition] | None = None
        self._states: list[StateDefinition] | None = None
        self._labels: list[LabelDefinition] | None = None

        # O(1) lookup maps
        self._type_name_to_id: dict[str, str] | None = None
        self._state_name_to_id: dict[str, str] | None = None
        self._label_name_to_id: dict[str, str] | None = None

        # Reverse maps (ID -> name)
        self._type_id_to_name: dict[str, str] | None = None
        self._state_id_to_name: dict[str, str] | None = None
        self._label_id_to_name: dict[str, str] | None = None

    @property
    def is_loaded(self) -> bool:
        """Check if cache has been fully loaded (all three data types)."""
        return (
            self._types is not None
            and self._states is not None
            and self._labels is not None
        )

    @property
    def types(self) -> list[WorkItemTypeDefinition]:
        """Get cached types. Raises if not loaded."""
        if self._types is None:
            raise RuntimeError("Cache not loaded. Call load() first.")
        return self._types

    @property
    def states(self) -> list[StateDefinition]:
        """Get cached states. Raises if not loaded."""
        if self._states is None:
            raise RuntimeError("Cache not loaded. Call load() first.")
        return self._states

    @property
    def labels(self) -> list[LabelDefinition]:
        """Get cached labels. Raises if not loaded."""
        if self._labels is None:
            raise RuntimeError("Cache not loaded. Call load() first.")
        return self._labels

    async def load(
        self,
        fetch_types: Callable[[], Awaitable[list[WorkItemTypeDefinition]]],
        fetch_states: Callable[[], Awaitable[list[StateDefinition]]],
        fetch_labels: Callable[[], Awaitable[list[LabelDefinition]]],
    ) -> None:
        """
        Load cache data from provided fetch functions.

        Fetches all three data types in parallel for maximum speed.

        Args:
            fetch_types: Async function that returns list of types
            fetch_states: Async function that returns list of states
            fetch_labels: Async function that returns list of labels
        """
        if self.is_loaded:
            return  # Already loaded

        # Load all three in parallel into temp vars.
        # If any fetch fails, none are assigned -- prevents partial cache state.
        types, states, labels = await asyncio.gather(
            fetch_types(),
            fetch_states(),
            fetch_labels(),
        )

        # Assign atomically only after all fetches succeed
        self._types = types
        self._states = states
        self._labels = labels

        # Build lookup maps
        self._build_lookup_maps()

        logger.debug(
            f"Cached {len(self._types)} types, "
            f"{len(self._states)} states, "
            f"{len(self._labels)} labels"
        )

    def _build_lookup_maps(self) -> None:
        """Build O(1) lookup maps from cached data.

        All name->ID lookups are case-insensitive (keys stored in lowercase)
        so that "In Progress" and "in progress" resolve identically.
        """
        if self._types is None or self._states is None or self._labels is None:
            raise RuntimeError(
                "Cannot build lookup maps: cache data incomplete. Call load() first."
            )

        # Name -> ID maps (all use lowercase keys for case-insensitive lookup)
        self._type_name_to_id = {t.name.lower(): t.remote_id or "" for t in self._types}
        self._state_name_to_id = {s.name.lower(): s.remote_id or "" for s in self._states}
        self._label_name_to_id = {lbl.name.lower(): lbl.remote_id or "" for lbl in self._labels}

        # ID -> Name maps (preserve original casing for display)
        self._type_id_to_name = {t.remote_id or "": t.name for t in self._types}
        self._state_id_to_name = {s.remote_id or "": s.name for s in self._states}
        self._label_id_to_name = {lbl.remote_id or "": lbl.name for lbl in self._labels}

    def invalidate(self) -> None:
        """
        Clear all cached data.

        Call this after making schema changes (creating types, states, labels).
        """
        self._types = None
        self._states = None
        self._labels = None
        self._type_name_to_id = None
        self._state_name_to_id = None
        self._label_name_to_id = None
        self._type_id_to_name = None
        self._state_id_to_name = None
        self._label_id_to_name = None

    def invalidate_types(self) -> None:
        """Invalidate only types cache."""
        self._types = None
        self._type_name_to_id = None
        self._type_id_to_name = None

    def invalidate_states(self) -> None:
        """Invalidate only states cache."""
        self._states = None
        self._state_name_to_id = None
        self._state_id_to_name = None

    def invalidate_labels(self) -> None:
        """Invalidate only labels cache."""
        self._labels = None
        self._label_name_to_id = None
        self._label_id_to_name = None

    # ----- Name -> ID lookups (O(1)) -----

    def get_type_id(self, name: str) -> str | None:
        """Get type ID by name (case-insensitive). Returns None if not found."""
        if self._type_name_to_id is None:
            return None
        return self._type_name_to_id.get(name.lower())

    def get_state_id(self, name: str) -> str | None:
        """Get state ID by name (case-insensitive). Returns None if not found."""
        if self._state_name_to_id is None:
            return None
        return self._state_name_to_id.get(name.lower())

    def get_label_id(self, name: str) -> str | None:
        """Get label ID by name (case-insensitive). Returns None if not found."""
        if self._label_name_to_id is None:
            return None
        return self._label_name_to_id.get(name.lower())

    def get_label_ids(self, names: list[str]) -> list[str]:
        """Get label IDs for a list of names (case-insensitive). Skips unknown names."""
        if self._label_name_to_id is None:
            return []
        return [
            self._label_name_to_id[name.lower()]
            for name in names
            if name.lower() in self._label_name_to_id
        ]

    # ----- ID -> Name lookups (O(1)) -----

    def get_type_name(self, remote_id: str) -> str | None:
        """Get type name by ID. Returns None if not found."""
        if self._type_id_to_name is None:
            return None
        return self._type_id_to_name.get(remote_id)

    def get_state_name(self, remote_id: str) -> str | None:
        """Get state name by ID. Returns None if not found."""
        if self._state_id_to_name is None:
            return None
        return self._state_id_to_name.get(remote_id)

    def get_label_name(self, remote_id: str) -> str | None:
        """Get label name by ID. Returns None if not found."""
        if self._label_id_to_name is None:
            return None
        return self._label_id_to_name.get(remote_id)

    def get_label_names(self, remote_ids: list[str]) -> list[str]:
        """Get label names for a list of IDs. Skips unknown IDs."""
        if self._label_id_to_name is None:
            return []
        return [
            self._label_id_to_name[rid]
            for rid in remote_ids
            if rid in self._label_id_to_name
        ]

    # ----- Existence checks (O(1)) -----

    def has_type(self, name: str) -> bool:
        """Check if a type exists (case-insensitive).
        Returns True when the types cache is empty (e.g. 402 on free tier)
        so validation does not block pushes when types cannot be fetched.
        """
        if self._type_name_to_id is None:
            return False
        if not self._type_name_to_id:
            return True  # types unavailable (402) — skip validation
        return name.lower() in self._type_name_to_id

    def has_state(self, name: str) -> bool:
        """Check if a state exists (case-insensitive)."""
        return self._state_name_to_id is not None and name.lower() in self._state_name_to_id

    def has_label(self, name: str) -> bool:
        """Check if a label exists (case-insensitive)."""
        return self._label_name_to_id is not None and name.lower() in self._label_name_to_id
