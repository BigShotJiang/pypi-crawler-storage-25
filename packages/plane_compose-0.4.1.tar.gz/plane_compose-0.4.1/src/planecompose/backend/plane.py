"""Plane SDK backend implementation.

This module provides the main backend interface for interacting with Plane API.
It delegates to specialized modules for:
- API calls: backend/client.py (rate limiting, error translation)
- Caching: backend/cache.py (types, states, labels)

Usage:
    backend = PlaneBackend()
    await backend.connect(config, api_key)
    types = await backend.list_types()
"""

import asyncio
from types import SimpleNamespace
from typing import Any

from planecompose.backend.base import Backend
from planecompose.backend.cache import SchemaCache
from planecompose.backend.client import PlaneApiClient
from planecompose.constants import DEFAULT_COLOR
from planecompose.core.models import (
    CycleDefinition,
    FieldDefinition,
    FieldType,
    LabelDefinition,
    LogoProps,
    ModuleDefinition,
    ProjectConfig,
    StateDefinition,
    WorkflowDefinition,
    WorkItem,
    WorkItemTypeDefinition,
)
from planecompose.exceptions import APIError, AuthenticationError, NetworkError, ValidationError
from planecompose.utils.logger import get_logger

logger = get_logger()


def _get_enum_value(obj) -> str:
    """Extract string value from an enum or return lowercased string."""
    if obj is None:
        return ""
    return obj.value if hasattr(obj, "value") else str(obj).lower()


def _get_results(response) -> list:
    """Extract results list from paginated response or return as list."""
    results = getattr(response, "results", None)
    if results is not None:
        return list(results)
    return list(response)


def _normalize_property_type(field_type: str) -> str:
    """Normalize Plane property types to our FieldType enum values."""
    aliases = {
        "string": "text",
        "number": "decimal",
        "enum": "option",
        "user": "relation",
    }
    return aliases.get(field_type.lower(), field_type.lower())


def _extract_id(value: Any) -> str | None:
    """Extract a remote ID from SDK objects, strings, or raw values."""
    if value is None:
        return None
    if isinstance(value, str):
        return value
    raw_id = getattr(value, "id", None)
    if raw_id is not None:
        return str(raw_id)
    return str(value)


def _extract_name(value: Any) -> str | None:
    """Extract a display name from SDK objects when available."""
    if value is None:
        return None
    if isinstance(value, str):
        return value
    raw_name = getattr(value, "name", None)
    if raw_name is not None:
        return str(raw_name)
    return None


def _unique_strings(values: list[str]) -> list[str]:
    """Return unique non-empty strings while preserving order."""
    seen: set[str] = set()
    unique: list[str] = []
    for value in values:
        if not value or value in seen:
            continue
        seen.add(value)
        unique.append(value)
    return unique


class PlaneBackend(Backend):
    """
    Plane SDK implementation of the backend interface.

    Provides high-level operations for:
    - Schema management (types, states, labels)
    - Work item CRUD
    - Project operations

    All API calls go through PlaneApiClient for rate limiting and error handling.
    Schema lookups use SchemaCache for O(1) performance.
    """

    # Maximum number of type property maps to cache before evicting oldest entries
    _PROPERTY_CACHE_MAX_SIZE = 100

    def __init__(self):
        self._client: PlaneApiClient | None = None
        self._config: ProjectConfig | None = None
        self._project_id: str | None = None
        self._cache = SchemaCache()
        # Cache: type_id -> {prop_name: {property_id, is_multi, property_type}}
        self._property_cache: dict[str, dict[str, dict[str, Any]]] = {}
        # Mapping of remote_id -> sequence_id from recently created items
        self._sequence_ids: dict[str, int] = {}

    def get_sequence_id(self, remote_id: str) -> int | None:
        """Get the sequence ID for a recently created work item.

        Returns the Plane sequence number (e.g., 123 for PROJ-123) if available.
        Only populated after create_work_item() calls.
        """
        return self._sequence_ids.get(remote_id)

    @property
    def _require_client(self) -> PlaneApiClient:
        """Get client, raising if not connected."""
        if self._client is None:
            raise APIError("Backend not connected. Call connect() first.", status_code=0)
        return self._client

    @property
    def _require_config(self) -> ProjectConfig:
        """Get config, raising if not connected."""
        if self._config is None:
            raise APIError("Backend not configured. Call connect() first.", status_code=0)
        return self._config

    async def connect(
        self, config: ProjectConfig, api_key: str, token_type: str = "workspace"
    ) -> None:
        """Establish connection to Plane.

        Uses connection_id from config for per-connection rate limiting.
        Falls back to a derived connection_id if not explicitly set.
        """
        self._config = config
        self._project_id = config.project_uuid or config.project_key
        # Use explicit connection_id, or derive one from workspace + api_url
        connection_id = config.connection_id or f"{config.workspace}@{config.api_url}"
        self._client = PlaneApiClient(
            config.api_url, api_key, token_type=token_type, connection_id=connection_id
        )
        self._cache.invalidate()

    @classmethod
    def create_client(
        cls,
        api_url: str,
        api_key: str,
        token_type: str = "workspace",
        connection_id: str | None = None,
    ) -> "PlaneBackend":
        """
        Create a backend instance without full project context.

        Use for operations that don't require a project (e.g., listing projects, clone).

        Args:
            api_url: Plane API URL
            api_key: API key for authentication
            token_type: Token type ("workspace" or "pat")
            connection_id: Optional connection ID for per-connection rate limiting (defaults to "default")
        """
        backend = cls()
        backend._client = PlaneApiClient(
            api_url, api_key, token_type=token_type, connection_id=connection_id or "default"
        )
        return backend

    async def disconnect(self) -> None:
        """Close connection and clear caches."""
        if self._client:
            self._client.close()
        self._client = None
        self._cache.invalidate()
        self._property_cache.clear()

    async def discover_rate_limit(self) -> int | None:
        """Discover actual rate limit from the Plane instance.

        Attempts to fetch workspace metadata to determine the actual
        server-side rate limit. Returns requests per second.

        Returns:
            Requests per second limit (e.g., 200 for 200/sec), or None if unknown.
        """
        client = self._require_client
        config = self._require_config

        try:
            # Try to get workspace info - may include rate limit in metadata
            response = await client.call(
                client.sdk.workspaces.retrieve,
                slug=config.workspace,
            )

            # Check if response includes rate limit info
            if hasattr(response, "rate_limit"):
                rate_limit = getattr(response, "rate_limit", None)
                if rate_limit:
                    # If it's requests per second, return as-is
                    # If it's per minute, convert to per second
                    if isinstance(rate_limit, dict):
                        val = rate_limit.get("per_second")
                        return int(val) if val is not None else None
                    return int(rate_limit) if rate_limit is not None else None

            logger.debug("Workspace metadata does not include rate limit info")
            return None

        except Exception as e:
            logger.debug(f"Could not discover rate limit from workspace info: {e}")
            # Fallback: If we can't get it, return None
            # Caller will use default or configured limits
            return None

    # -------------------------------------------------------------------------
    # Cache Management
    # -------------------------------------------------------------------------

    def get_cache(self) -> SchemaCache:
        """Return the schema cache."""
        return self._cache

    async def ensure_schema_loaded(self) -> None:
        """Load schema caches if not already loaded.

        Wraps the parallel fetch with user-friendly error messages
        when the API is unreachable or returns persistent errors.
        """
        await self._ensure_caches_loaded()

    async def _ensure_caches_loaded(self):
        """Load caches if not already loaded."""
        if not self._cache.is_loaded:
            try:
                await self._cache.load(
                    fetch_types=self._fetch_types,
                    fetch_states=self._fetch_states,
                    fetch_labels=self._fetch_labels,
                )
            except AuthenticationError:
                raise
            except (APIError, NetworkError) as e:
                if isinstance(e, APIError):
                    raise APIError(
                        message=(
                            f"Failed to load project schema: {e}. "
                            "Check your network connection and API credentials, "
                            "then retry."
                        ),
                        status_code=e.status_code,
                        endpoint=getattr(e, "endpoint", None),
                    ) from e
                raise NetworkError(
                    message=(
                        f"Failed to load project schema: {e}. "
                        "Check your network connection and API credentials, "
                        "then retry."
                    ),
                    original_error=e,
                ) from e

    async def _fetch_types(self) -> list[WorkItemTypeDefinition]:
        """Fetch types from API (internal).

        Raises on failure so callers see the real error instead of silently
        operating against an empty schema (which can cause duplicate creation).
        Returns empty list on 402 (free tier — work item types not available).
        """
        client = self._require_client
        config = self._require_config
        try:
            response = await client.call(
                client.sdk.work_item_types.list,
                workspace_slug=config.workspace,
                project_id=self._project_id,
            )
        except APIError as e:
            if e.status_code == 402:
                logger.warning(
                    "Work item types not available on this plan (402) — using empty types list"
                )
                return []
            raise
        raw_types = _get_results(response)
        detailed_types: list[WorkItemTypeDefinition] = []

        for raw_type in raw_types:
            type_id = str(raw_type.id)
            # Extract workspace type ID if this type is linked to a workspace-level type
            ws_workitemtype_id = None
            if hasattr(raw_type, "workspace_item_type_id") and raw_type.workspace_item_type_id:
                ws_workitemtype_id = str(raw_type.workspace_item_type_id)

            detailed_types.append(
                WorkItemTypeDefinition(
                    name=raw_type.name,
                    description=getattr(raw_type, "description", None),
                    workflow="default",
                    fields=await self._build_field_definitions(type_id),
                    remote_id=type_id,
                    logo_props=self._extract_logo_props(getattr(raw_type, "logo_props", None)),
                    is_epic=getattr(raw_type, "is_epic", False),
                    is_default=getattr(raw_type, "is_default", False),
                    level=float(getattr(raw_type, "level", 0.0) or 0.0),
                    ws_workitemtype_id=ws_workitemtype_id,
                )
            )

        return detailed_types

    async def _fetch_states(self) -> list[StateDefinition]:
        """Fetch states from API (internal).

        Raises on failure so callers see the real error instead of silently
        operating against an empty schema (which can cause duplicate creation).
        """
        client = self._require_client
        config = self._require_config
        response = await client.call(
            client.sdk.states.list,
            workspace_slug=config.workspace,
            project_id=self._project_id,
        )
        states_data = getattr(response, "results", response)
        return [
            StateDefinition(
                name=s.name,
                description=getattr(s, "description", None),
                color=getattr(s, "color", None),
                group=getattr(s, "group", "unstarted"),
                remote_id=str(s.id),
            )
            for s in states_data
        ]

    async def _fetch_labels(self) -> list[LabelDefinition]:
        """Fetch labels from API (internal).

        Raises on failure so callers see the real error instead of silently
        operating against an empty schema (which can cause duplicate creation).
        """
        client = self._require_client
        config = self._require_config
        response = await client.call(
            client.sdk.labels.list,
            workspace_slug=config.workspace,
            project_id=self._project_id,
        )
        labels_data = getattr(response, "results", response)
        return [
            LabelDefinition(
                name=lbl.name,
                color=getattr(lbl, "color", None),
                remote_id=str(lbl.id),
            )
            for lbl in labels_data
        ]

    async def fetch_workflows(
        self, workspace: str | None = None, project_id: str | None = None
    ) -> list[WorkflowDefinition]:
        """Fetch workflows from Plane API.

        Fetches all workflows for the current project along with their states
        and transitions. Returns a list of WorkflowDefinition objects.

        Note: Uses direct HTTP calls since SDK doesn't expose workflows resource yet.

        Args:
            workspace: Workspace slug (uses config if not provided)
            project_id: Project UUID (uses instance project_id if not provided)

        Returns:
            List of WorkflowDefinition objects
        """
        from planecompose.backend.workflows import (
            build_state_mapping,
            parse_workflow_from_api,
        )

        client = self._require_client
        config = self._require_config

        # Use provided values or fall back to instance values
        ws = workspace or config.workspace
        proj_id = project_id or self._project_id

        # First, fetch all states to build state name↔ID mapping
        states_response = await client.call(
            client.sdk.states.list,
            workspace_slug=ws,
            project_id=proj_id,
        )
        states_raw = _get_results(states_response)
        state_name_to_id, state_id_to_name = build_state_mapping(
            [{"id": str(s.id), "name": s.name} for s in states_raw]
        )

        # Build user ID → email mapping for resolving approver member_ids
        user_id_to_email: dict[str, str] = {}
        try:
            members_raw = await self.fetch_project_members(ws, proj_id)  # type: ignore[arg-type]
            for m in members_raw:
                uid = m.get("id")
                email = m.get("email")
                if uid and email:
                    user_id_to_email[uid] = email
        except Exception as e:
            logger.debug(f"Could not build user_id_to_email mapping: {e}")

        # Build type ID → name mapping for workflow work_item_types conversion
        type_id_to_name = {}
        try:
            types_response = await client.call(
                client.sdk.work_item_types.list,
                workspace_slug=ws,
                project_id=proj_id,
            )
            types_raw = _get_results(types_response)

            for t in types_raw:
                type_id_to_name[str(t.id)] = t.name
        except Exception as e:
            logger.debug(f"Could not fetch work item types for conversion: {e}")

        # Fetch workflows via direct HTTP call (SDK doesn't expose workflows yet).
        #
        # The public API (/api/v1/.../workflows/) does NOT include workflow
        # states in the response — it only returns workflow metadata and
        # work_item_type_ids. The internal workspace-level endpoint
        # (/api/workspaces/{slug}/workflows/) returns every workflow with its
        # full state list and transitions, which is what the web UI uses.
        #
        # We try the internal endpoint first (filtering client-side by
        # project_id) and fall back to the public API if it rejects our
        # credentials. This keeps clone/push round-trips lossless whenever
        # the workspace endpoint is reachable.
        import httpx

        # Normalise base URL — config.api_url may have a trailing slash.
        base_url = config.api_url.rstrip("/")
        internal_workflows_url = f"{base_url}/api/workspaces/{ws}/workflows/"
        public_workflows_url = f"{base_url}/api/v1/workspaces/{ws}/projects/{proj_id}/workflows/"

        workflows: list[WorkflowDefinition] = []
        workflows_raw: list = []
        used_internal_endpoint = False

        try:
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http_client:
                internal_resp = await http_client.get(internal_workflows_url)
                if internal_resp.status_code == 200:
                    data = internal_resp.json()
                    raw = data.get("results", data) if isinstance(data, dict) else data
                    if isinstance(raw, list):
                        workflows_raw = [
                            w
                            for w in raw
                            if isinstance(w, dict) and str(w.get("project_id", "")) == str(proj_id)
                        ]
                        used_internal_endpoint = True
                else:
                    logger.debug(
                        f"Internal workflow endpoint returned {internal_resp.status_code}; "
                        "falling back to public API + per-workflow states."
                    )
        except Exception as e:
            logger.debug(f"Internal workflow endpoint unreachable: {e}; falling back.")

        if not used_internal_endpoint:
            try:
                async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http_client:
                    response = await http_client.get(public_workflows_url)
                    response.raise_for_status()
                    data = response.json()
                    raw = data.get("results", data) if isinstance(data, dict) else data
                    if isinstance(raw, list):
                        workflows_raw = raw
            except Exception as e:
                logger.warning(f"Could not fetch workflows from API: {e}")
                return workflows

        # The public workflows endpoint does not include states — they live
        # behind a per-workflow GET at /api/v1/.../workflows/{id}/states/
        # (returns WorkflowState junction rows with state_id foreign keys).
        # Fetch each workflow's state list and merge it into the raw dict
        # before parsing, so parse_workflow_from_api sees the expected shape.
        #
        # Also fetch transitions using the newly available GET endpoint
        # (commit 6fe8c5558a) so we have the complete workflow definition.
        if not used_internal_endpoint and workflows_raw:
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http_client:
                for workflow_raw in workflows_raw:
                    if not isinstance(workflow_raw, dict):
                        continue
                    wf_id = workflow_raw.get("id")
                    if not wf_id:
                        continue

                    # Fetch states
                    states_url = f"{base_url}/api/v1/workspaces/{ws}/projects/{proj_id}/workflows/{wf_id}/states/"
                    try:
                        st_resp = await http_client.get(states_url)
                        if st_resp.status_code == 200:
                            st_data = st_resp.json()
                            st_list = (
                                st_data.get("results", st_data)
                                if isinstance(st_data, dict)
                                else st_data
                            )
                            if isinstance(st_list, list):
                                workflow_raw["states"] = st_list
                        else:
                            logger.debug(
                                f"Workflow states endpoint returned {st_resp.status_code} for {wf_id}"
                            )
                    except Exception as e:
                        logger.debug(f"Workflow states endpoint unreachable for {wf_id}: {e}")

                    # Fetch state transitions via GET endpoint (added by backend team 2026-04-29).
                    #
                    # Transition shape:
                    #   workflow_state_id  — junction row id (workflow_state.id, NOT state UUID)
                    #   transition_state_id — target project state UUID
                    #
                    # Workflow state junction row shape:
                    #   id       — junction row primary key (referenced by workflow_state_id)
                    #   state_id — actual project state UUID
                    #
                    # So we group transitions by workflow_state_id (junction row id),
                    # then merge into each state using state["id"] (also the junction row id).
                    trans_url = f"{base_url}/api/v1/workspaces/{ws}/projects/{proj_id}/workflows/{wf_id}/state-transitions/"
                    try:
                        trans_resp = await http_client.get(trans_url)
                        if trans_resp.status_code == 200:
                            trans_data = trans_resp.json()
                            trans_list = (
                                trans_data.get("results", trans_data)
                                if isinstance(trans_data, dict)
                                else trans_data
                            )
                            if isinstance(trans_list, list):
                                # Group transitions by workflow_state_id (junction row id)
                                transitions_by_state: dict[str, list] = {}
                                for trans in trans_list:
                                    if isinstance(trans, dict):
                                        wf_state_id = str(trans.get("workflow_state_id") or "")
                                        if wf_state_id:
                                            if wf_state_id not in transitions_by_state:
                                                transitions_by_state[wf_state_id] = []
                                            transitions_by_state[wf_state_id].append(trans)

                                # Merge transitions into workflow states using the junction row id
                                states_to_update = workflow_raw.get("states", [])
                                if isinstance(states_to_update, list):
                                    for state in states_to_update:
                                        if isinstance(state, dict):
                                            junction_id = str(state.get("id") or "")
                                            if junction_id in transitions_by_state:
                                                state["transitions"] = transitions_by_state[junction_id]
                                            else:
                                                state["transitions"] = []
                        else:
                            logger.debug(
                                f"Workflow transitions endpoint returned {trans_resp.status_code} for {wf_id}"
                            )
                    except Exception as e:
                        logger.debug(f"Workflow transitions endpoint error for {wf_id}: {e}")

        # Parse the raw workflows (from either the internal or public endpoint)
        # into WorkflowDefinition objects. Preserve the remote's actual state
        # list as-is — do NOT fall back to all project states.
        for workflow_raw in workflows_raw:
            if not isinstance(workflow_raw, dict):
                continue
            try:
                parsed_workflow = parse_workflow_from_api(
                    workflow_raw,
                    state_name_to_id,
                    state_id_to_name,
                    type_id_to_name=type_id_to_name,
                    user_id_to_email=user_id_to_email,
                )
                if parsed_workflow:
                    workflows.append(parsed_workflow)
            except Exception as e:
                logger.warning(
                    f"Could not parse workflow {workflow_raw.get('name', '<unknown>')}: {e}"
                )

        return workflows

    async def create_workflow(
        self, workflow: WorkflowDefinition, type_name_to_id: dict | None = None
    ) -> str:
        """Create a workflow. Returns remote ID.

        Args:
            workflow: WorkflowDefinition with name, description, and state list
            type_name_to_id: Optional mapping of work item type names to IDs for converting YAML to API format

        Returns:
            str: Remote workflow ID
        """
        import httpx

        client = self._require_client
        config = self._require_config

        ws = config.workspace
        proj_id = self._project_id

        # Build API URL
        create_url = f"{config.api_url}/api/v1/workspaces/{ws}/projects/{proj_id}/workflows/"

        # Prepare payload
        payload = {
            "name": workflow.name,
            "description": workflow.description or "",
            "is_active": getattr(workflow, "is_active", False),
        }

        # Convert work_item_types from names to IDs if mapping is provided
        type_name_to_id = type_name_to_id or {}
        work_item_types = getattr(workflow, "work_item_types", None)
        if work_item_types and isinstance(work_item_types, list):
            converted_wit_ids = []
            for wit in work_item_types:
                if isinstance(wit, str):
                    # Try to map name to ID
                    if wit in type_name_to_id:
                        converted_wit_ids.append(type_name_to_id[wit])
                    else:
                        # Assume it's already an ID
                        converted_wit_ids.append(wit)
                else:
                    # Try to get UUID from WorkItemTypeDefinition object
                    wit_id = None
                    if hasattr(wit, "ws_workitemtype_id"):
                        wit_id = wit.ws_workitemtype_id
                    elif hasattr(wit, "id"):
                        wit_id = wit.id
                    if wit_id:
                        converted_wit_ids.append(str(wit_id))
                    else:
                        converted_wit_ids.append(str(wit))

            if converted_wit_ids:
                payload["work_item_type_ids"] = converted_wit_ids

        try:
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http_client:
                response = await http_client.post(create_url, json=payload)
                response.raise_for_status()
                data = response.json()
                workflow_id = data.get("id")

                if not workflow_id:
                    raise APIError(f"No workflow ID in response: {data}", status_code=400)

                logger.info(f"Created workflow '{workflow.name}' with ID {workflow_id}")
                return str(workflow_id)

        except httpx.HTTPStatusError as e:
            error_detail = ""
            try:
                error_data = e.response.json()
                error_detail = error_data.get("detail", str(error_data))
            except Exception:
                error_detail = e.response.text

            raise APIError(
                f"Failed to create workflow '{workflow.name}': {error_detail}",
                status_code=e.response.status_code,
            )
        except Exception as e:
            raise APIError(f"Failed to create workflow '{workflow.name}': {e}", status_code=0)

    async def update_workflow(
        self, workflow_id: str, workflow: WorkflowDefinition, type_name_to_id: dict | None = None
    ) -> None:
        """Update a workflow.

        Args:
            workflow_id: Remote workflow UUID
            workflow: Updated WorkflowDefinition
            type_name_to_id: Optional mapping of work item type names to IDs for converting YAML to API format
        """
        import httpx

        client = self._require_client
        config = self._require_config

        ws = config.workspace
        proj_id = self._project_id

        # Build API URL
        update_url = (
            f"{config.api_url}/api/v1/workspaces/{ws}/projects/{proj_id}/workflows/{workflow_id}/"
        )

        # Prepare payload - only update fields that changed
        payload = {
            "name": workflow.name,
            "description": workflow.description or "",
            "is_active": getattr(workflow, "is_active", False),
        }

        # Convert work_item_types from names to IDs if mapping is provided
        type_name_to_id = type_name_to_id or {}
        work_item_types = getattr(workflow, "work_item_types", None)
        if work_item_types and isinstance(work_item_types, list):
            converted_wit_ids = []
            for wit in work_item_types:
                if isinstance(wit, str):
                    # Try to map name to ID
                    if wit in type_name_to_id:
                        converted_wit_ids.append(type_name_to_id[wit])
                    else:
                        # Assume it's already an ID
                        converted_wit_ids.append(wit)
                else:
                    # Try to get UUID from WorkItemTypeDefinition object
                    wit_id = None
                    if hasattr(wit, "ws_workitemtype_id"):
                        wit_id = wit.ws_workitemtype_id
                    elif hasattr(wit, "id"):
                        wit_id = wit.id
                    if wit_id:
                        converted_wit_ids.append(str(wit_id))
                    else:
                        converted_wit_ids.append(str(wit))

            if converted_wit_ids:
                payload["work_item_type_ids"] = converted_wit_ids

        try:
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http_client:
                response = await http_client.patch(update_url, json=payload)
                response.raise_for_status()
                logger.info(f"Updated workflow '{workflow.name}'")

        except httpx.HTTPStatusError as e:
            error_detail = ""
            try:
                error_data = e.response.json()
                error_detail = error_data.get("detail", str(error_data))
            except Exception:
                error_detail = e.response.text

            raise APIError(
                f"Failed to update workflow '{workflow.name}': {error_detail}",
                status_code=e.response.status_code,
            )
        except Exception as e:
            raise APIError(f"Failed to update workflow '{workflow.name}': {e}", status_code=0)

    async def attach_workflow_states(self, workflow_id: str, state_ids: list[str]) -> None:
        """Attach states to a workflow.

        Plane exposes workflow states as a separate resource; the main
        `/workflows/` POST/PATCH payload does not accept states. This posts
        `{state_ids: [...]}` to the dedicated sub-endpoint. The backend uses
        bulk_create(ignore_conflicts=True), so re-posting already-attached
        states is a safe no-op — callers can pass the full desired set.

        Args:
            workflow_id: Remote workflow UUID.
            state_ids:   Project-level state UUIDs to associate with the workflow.
        """
        if not state_ids:
            return

        import httpx

        client = self._require_client
        config = self._require_config

        url = (
            f"{config.api_url}/api/v1/workspaces/{config.workspace}/"
            f"projects/{self._project_id}/workflows/{workflow_id}/states/"
        )
        payload = {"state_ids": list(state_ids)}

        try:
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http_client:
                response = await http_client.post(url, json=payload)
                response.raise_for_status()
                logger.info(f"Attached {len(state_ids)} state(s) to workflow {workflow_id}")
        except httpx.HTTPStatusError as e:
            error_detail = e.response.text
            try:
                error_data = e.response.json()
                error_detail = error_data.get("detail", str(error_data))
            except Exception:
                pass
            raise APIError(
                f"Failed to attach states to workflow {workflow_id}: {error_detail}",
                status_code=e.response.status_code,
            )
        except Exception as e:
            raise APIError(f"Failed to attach states to workflow {workflow_id}: {e}", status_code=0)

    async def create_workflow_transition(
        self,
        workflow_id: str,
        from_state_id: str,
        to_state_id: str,
        transition_type: str = "transition",
        approver_user_ids: list[str] | None = None,
        pre_rules: list[dict] | None = None,
        post_rules: list[dict] | None = None,
    ) -> str | None:
        """Create a workflow transition.

        POSTs to `/workflows/{workflow_id}/state-transitions/` with:
            {
              "state_id": <source state UUID>,        # FROM state
              "transition_state_id": <target UUID>,   # TO state
              "type": "transition" | "approval",
              "member_ids": [<approver user UUIDs>],
              "pre_rules": [{"handler_name": "run_script", "rule_type": "validation",
                             "config": {"script_id": "<uuid>"}}],
              "post_rules": [{"handler_name": "run_script", "rule_type": "action",
                              "config": {"script_id": "<uuid>"}}]
            }

        Returns the new transition's UUID on success, or None if the backend
        reports the transition already exists (treated as idempotent no-op).

        Raises APIError for any other failure.
        """
        import httpx

        client = self._require_client
        config = self._require_config

        url = (
            f"{config.api_url}/api/v1/workspaces/{config.workspace}/"
            f"projects/{self._project_id}/workflows/{workflow_id}/state-transitions/"
        )
        payload: dict = {
            "state_id": from_state_id,
            "transition_state_id": to_state_id,
            "type": transition_type,
        }
        if approver_user_ids:
            payload["member_ids"] = list(approver_user_ids)
        if pre_rules:
            payload["pre_rules"] = pre_rules
        if post_rules:
            payload["post_rules"] = post_rules

        try:
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http_client:
                response = await http_client.post(url, json=payload)
                if response.status_code in (200, 201):
                    data = response.json() or {}
                    tid = data.get("id")
                    logger.info(
                        f"Created transition on workflow {workflow_id}: "
                        f"{from_state_id} → {to_state_id} ({transition_type})"
                    )
                    return str(tid) if tid else None
                # Treat duplicate as a no-op — backend returns 400 with a
                # specific error string (see WorkflowStateTransitionsAPIEndpoint.post).
                if response.status_code == 400:
                    try:
                        body = response.json() or {}
                    except Exception:
                        body = {"error": response.text}
                    err = str(body.get("error", body)).lower()
                    if "already exists" in err:
                        logger.debug(
                            f"Transition already exists on workflow {workflow_id}: "
                            f"{from_state_id} → {to_state_id}"
                        )
                        return None
                response.raise_for_status()
        except httpx.HTTPStatusError as e:
            error_detail = e.response.text
            try:
                error_data = e.response.json()
                error_detail = error_data.get("detail", error_data.get("error", str(error_data)))
            except Exception:
                pass
            raise APIError(
                f"Failed to create transition {from_state_id}→{to_state_id} "
                f"on workflow {workflow_id}: {error_detail}",
                status_code=e.response.status_code,
            )
        except Exception as e:
            raise APIError(
                f"Failed to create transition {from_state_id}→{to_state_id} "
                f"on workflow {workflow_id}: {e}",
                status_code=0,
            )
        return None

    async def update_workflow_transition(
        self,
        workflow_id: str,
        transition_id: str,
        pre_rules: list[dict] | None = None,
        post_rules: list[dict] | None = None,
    ) -> None:
        """PATCH an existing workflow transition to update its conditions.

        Uses `PATCH /workflows/{workflow_id}/state-transitions/{transition_id}/`
        with the conditions payload:
            {
              "pre_rules": [{"handler_name": "run_script", "rule_type": "validation",
                             "config": {"script_id": "<uuid>"}}],
              "post_rules": [{"handler_name": "run_script", "rule_type": "action",
                              "config": {"script_id": "<uuid>"}}]
            }

        Pass empty lists to clear existing conditions.  Omitting a key leaves
        the existing conditions unchanged (pass [] to clear them explicitly).

        Raises APIError on failure.
        """
        import httpx

        client = self._require_client
        config = self._require_config

        url = (
            f"{config.api_url}/api/v1/workspaces/{config.workspace}/"
            f"projects/{self._project_id}/workflows/{workflow_id}/"
            f"state-transitions/{transition_id}/"
        )
        payload: dict = {}
        if pre_rules is not None:
            payload["pre_rules"] = pre_rules
        if post_rules is not None:
            payload["post_rules"] = post_rules

        if not payload:
            return  # Nothing to update

        try:
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http_client:
                response = await http_client.patch(url, json=payload)
                if response.status_code in (200, 204):
                    logger.info(
                        f"Updated conditions on transition {transition_id} "
                        f"of workflow {workflow_id}"
                    )
                    return
                response.raise_for_status()
        except httpx.HTTPStatusError as e:
            error_detail = e.response.text
            try:
                error_data = e.response.json()
                error_detail = error_data.get("detail", error_data.get("error", str(error_data)))
            except Exception:
                pass
            raise APIError(
                f"Failed to update conditions on transition {transition_id} "
                f"of workflow {workflow_id}: {error_detail}",
                status_code=e.response.status_code,
            )
        except Exception as e:
            raise APIError(
                f"Failed to update conditions on transition {transition_id} "
                f"of workflow {workflow_id}: {e}",
                status_code=0,
            )

    async def fetch_workflow_transitions(
        self, workflow_id: str
    ) -> list[dict[str, Any]]:
        """Fetch all transitions for a workflow using the GET endpoint.

        Endpoint:
        GET /api/v1/workspaces/{slug}/projects/{project_id}/workflows/{workflow_id}/state-transitions/

        Added by Plane backend team on 2026-04-29.

        Returns:
            List of transition dicts with keys: id, workflow_state_id, transition_state_id,
            type, member_ids, pre_hooks, post_hooks, etc.
            Returns empty list if the endpoint is unreachable or returns no results.
        """
        import httpx

        client = self._require_client
        config = self._require_config

        url = (
            f"{config.api_url}/api/v1/workspaces/{config.workspace}/"
            f"projects/{self._project_id}/workflows/{workflow_id}/"
            f"state-transitions/"
        )

        try:
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http_client:
                response = await http_client.get(url)
                if response.status_code == 200:
                    data = response.json() or {}
                    results = data.get("results", data) if isinstance(data, dict) else data
                    if isinstance(results, list):
                        logger.debug(f"Fetched {len(results)} transitions for workflow {workflow_id}")
                        return results
                    return []
                else:
                    logger.info(
                        f"Transitions endpoint returned {response.status_code} for workflow {workflow_id}"
                    )
                    return []
        except Exception as e:
            logger.debug(f"Could not fetch transitions for workflow {workflow_id}: {e}")
            return []

    async def delete_workflow_transition(self, workflow_id: str, transition_id: str) -> None:
        """Delete a workflow transition by its UUID."""
        import httpx

        client = self._require_client
        config = self._require_config

        url = (
            f"{config.api_url}/api/v1/workspaces/{config.workspace}/"
            f"projects/{self._project_id}/workflows/{workflow_id}/"
            f"state-transitions/{transition_id}/"
        )

        try:
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http_client:
                response = await http_client.delete(url)
                response.raise_for_status()
                logger.info(f"Deleted transition {transition_id} from workflow {workflow_id}")
        except httpx.HTTPStatusError as e:
            error_detail = e.response.text
            try:
                error_data = e.response.json()
                error_detail = error_data.get("detail", error_data.get("error", str(error_data)))
            except Exception:
                pass
            raise APIError(
                f"Failed to delete transition {transition_id} on workflow {workflow_id}: {error_detail}",
                status_code=e.response.status_code,
            )
        except Exception as e:
            raise APIError(
                f"Failed to delete transition {transition_id} on workflow {workflow_id}: {e}",
                status_code=0,
            )

    async def detach_workflow_state(self, workflow_id: str, state_id: str) -> None:
        """Remove a single state from a workflow.

        Args:
            workflow_id: Remote workflow UUID.
            state_id:    Project-level state UUID to remove from the workflow.
        """
        import httpx

        client = self._require_client
        config = self._require_config

        url = (
            f"{config.api_url}/api/v1/workspaces/{config.workspace}/"
            f"projects/{self._project_id}/workflows/{workflow_id}/states/{state_id}/"
        )

        try:
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http_client:
                response = await http_client.delete(url)
                response.raise_for_status()
                logger.info(f"Detached state {state_id} from workflow {workflow_id}")
        except httpx.HTTPStatusError as e:
            error_detail = e.response.text
            try:
                error_data = e.response.json()
                error_detail = error_data.get("detail", str(error_data))
            except Exception:
                pass
            raise APIError(
                f"Failed to detach state {state_id} from workflow {workflow_id}: {error_detail}",
                status_code=e.response.status_code,
            )
        except Exception as e:
            raise APIError(f"Failed to detach state {state_id} from workflow {workflow_id}: {e}", status_code=0)

    def _extract_logo_props(self, raw_logo_props) -> LogoProps | None:
        """Convert SDK logo props payload to our model."""
        if not raw_logo_props:
            return None

        icon_name = None
        background_color = None
        emoji_value = None

        if isinstance(raw_logo_props, dict):
            icon = raw_logo_props.get("icon")
            emoji = raw_logo_props.get("emoji")
            icon_name = icon.get("name") if isinstance(icon, dict) else None
            background_color = (
                icon.get("background_color") if isinstance(icon, dict) else None
            ) or raw_logo_props.get("background_color")
            emoji_value = (
                emoji.get("value") if isinstance(emoji, dict) else raw_logo_props.get("emoji")
            )
        else:
            icon = getattr(raw_logo_props, "icon", None)
            emoji = getattr(raw_logo_props, "emoji", None)
            icon_name = getattr(icon, "name", None) if icon else None
            background_color = getattr(icon, "background_color", None) if icon else None
            emoji_value = (
                getattr(emoji, "value", None) if emoji else getattr(raw_logo_props, "emoji", None)
            )

        if not any((icon_name, background_color, emoji_value)):
            return None

        return LogoProps(
            icon=icon_name,
            background_color=background_color,
            emoji=emoji_value,
        )

    async def _build_field_definitions(self, type_id: str) -> list[FieldDefinition]:
        """Fetch and convert work item properties for a type."""
        fields: list[FieldDefinition] = []

        for prop in await self.list_type_properties(type_id, strict=True):
            raw_type = _normalize_property_type(
                _get_enum_value(getattr(prop, "property_type", None)) or "text"
            )

            try:
                field_type = FieldType(raw_type)
            except ValueError:
                field_type = FieldType.TEXT

            options: list[str] | None = None
            prop_options = getattr(prop, "options", None)
            if prop_options:
                options = [
                    str(getattr(option, "value", None) or getattr(option, "name", None))
                    for option in prop_options
                    if getattr(option, "value", None) or getattr(option, "name", None)
                ] or None

            relation_type = getattr(prop, "relation_type", None)
            # Normalize relation_type: extract from enum strings like "relationtype.user" -> "user"
            normalized_relation_type = None
            if relation_type:
                rt_str = str(relation_type).lower()
                # Handle enum format like "relationtype.user"
                if "." in rt_str:
                    rt_str = rt_str.split(".")[-1]
                # Only keep valid values
                if rt_str in ("user", "issue"):
                    normalized_relation_type = rt_str

            try:
                fields.append(
                    FieldDefinition(
                        name=str(getattr(prop, "name", None) or getattr(prop, "display_name", "") or ""),
                        display_name=getattr(prop, "display_name", None)
                        or getattr(prop, "name", None),
                        type=field_type,
                        required=getattr(prop, "is_required", False),
                        options=options,
                        is_multi=getattr(prop, "is_multi", False),
                        is_active=getattr(prop, "is_active", True),
                        relation_type=normalized_relation_type,
                        remote_id=str(prop.id),
                    )
                )
            except ValueError as e:
                # Skip malformed fields with warning instead of failing entire schema load
                prop_name = getattr(prop, "name", None) or getattr(prop, "display_name", "unknown")
                logger.warning(f"Skipping malformed field '{prop_name}' in type {type_id}: {e}")
                continue

        return fields

    # -------------------------------------------------------------------------
    # Public API: Schema (Types, States, Labels)
    # -------------------------------------------------------------------------

    async def list_types(self) -> list[WorkItemTypeDefinition]:
        """List all work item types (cached)."""
        await self._ensure_caches_loaded()
        return self._cache.types

    async def list_states(self) -> list[StateDefinition]:
        """List all states (cached)."""
        await self._ensure_caches_loaded()
        return self._cache.states

    async def list_labels(self) -> list[LabelDefinition]:
        """List all labels (cached)."""
        await self._ensure_caches_loaded()
        return self._cache.labels

    async def list_modules(self) -> list[ModuleDefinition]:
        """List all modules from remote API."""
        if not self._project_id or not self._config:
            return []
        modules_raw = await self.list_modules_raw(self._config.workspace, self._project_id)
        modules = []
        for m in modules_raw:
            try:
                module_def = ModuleDefinition(
                    name=getattr(m, "name", ""),
                    description=getattr(m, "description", None),
                    status=getattr(m, "status", "backlog"),
                    start_date=getattr(m, "start_date", None),
                    end_date=getattr(m, "end_date", None),
                    remote_id=getattr(m, "id", None),
                )
                modules.append(module_def)
            except Exception as e:
                logger.warning(f"Failed to parse module {getattr(m, 'name', 'unknown')}: {e}")
        return modules

    async def list_cycles(self) -> list[CycleDefinition]:
        """List all cycles from remote API."""
        if not self._project_id or not self._config:
            return []
        cycles_raw = await self.list_cycles_raw(self._config.workspace, self._project_id)
        cycles = []
        for c in cycles_raw:
            try:
                cycle_def = CycleDefinition(
                    name=getattr(c, "name", ""),
                    description=getattr(c, "description", None),
                    status=getattr(c, "status", "backlog"),
                    start_date=getattr(c, "start_date", None),
                    end_date=getattr(c, "end_date", None),
                    remote_id=getattr(c, "id", None),
                )
                cycles.append(cycle_def)
            except Exception as e:
                logger.warning(f"Failed to parse cycle {getattr(c, 'name', 'unknown')}: {e}")
        return cycles

    async def list_types_raw(
        self, workspace: str | None = None, project_id: str | None = None
    ) -> list:
        """Fetch work item types with full metadata (raw SDK response)."""
        client = self._require_client
        try:
            ws = workspace or (self._config.workspace if self._config else None)
            pid = project_id or self._project_id
            return list(
                await client.call(
                    client.sdk.work_item_types.list,
                    workspace_slug=ws,
                    project_id=pid,
                )
            )
        except (APIError, NetworkError) as e:
            logger.warning(f"Failed to fetch raw types: {e}")
            return []
        except (TypeError, AttributeError, ValueError) as e:
            logger.error(f"Unexpected error fetching raw types: {e}")
            return []

    async def create_type(self, type_def: WorkItemTypeDefinition) -> str:
        """Create a work item type. Returns remote ID."""
        from plane.models.work_item_types import CreateWorkItemType

        client = self._require_client
        config = self._require_config
        logger.info(f"Creating work item type: {type_def.name}")

        data = CreateWorkItemType(
            name=type_def.name,
            description=type_def.description or "",
            is_epic=getattr(type_def, "is_epic", None),
            is_active=True,
        )

        response = await client.call(
            client.sdk.work_item_types.create,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            data=data,
        )

        type_id = str(response.id)
        self._cache.invalidate_types()

        # Update logo_props if provided
        logo_props = getattr(type_def, "logo_props", None)
        if logo_props:
            await self._update_type_logo_props(type_id, logo_props)

        # Create custom properties
        fields = getattr(type_def, "fields", None)
        if fields:
            await self._create_type_properties(type_id, fields)

        return type_id

    async def update_type(self, type_id: str, type_def: WorkItemTypeDefinition) -> None:
        """Update a work item type."""
        from plane.models.work_item_types import UpdateWorkItemType

        client = self._require_client
        config = self._require_config
        await client.call(
            client.sdk.work_item_types.update,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            work_item_type_id=type_id,
            data=UpdateWorkItemType(
                name=type_def.name,
                description=type_def.description or "",
                is_epic=getattr(type_def, "is_epic", False),
            ),
        )
        if type_def.logo_props:
            await self._update_type_logo_props(type_id, type_def.logo_props)
        await self._sync_type_properties(type_id, type_def.fields or [])
        self._cache.invalidate_types()

    async def delete_type(self, type_id: str) -> None:
        """Delete a work item type.

        Default types (is_default=true) cannot be deleted — backend returns 400.
        Raises ValueError for default-type 400 responses so the caller can skip gracefully.
        """
        client = self._require_client
        config = self._require_config
        logger.info(f"Deleting work item type: {type_id}")
        try:
            await client.call(
                client.sdk.work_item_types.delete,
                workspace_slug=config.workspace,
                project_id=self._project_id,
                work_item_type_id=type_id,
            )
        except Exception as e:
            if "default" in str(e).lower() or "cannot delete" in str(e).lower():
                raise ValueError(f"Cannot delete default work item type {type_id}") from e
            raise
        self._cache.invalidate_types()

    async def import_workspace_types(
        self, workspace_slug: str, project_id: str, work_item_type_ids: list[str]
    ) -> None:
        """Import workspace-level work item types into a project.

        This links the project to workspace-level work item types instead of
        creating project-specific types. Used when enterprise mode is enabled.

        Args:
            workspace_slug: Workspace slug
            project_id: Project UUID
            work_item_type_ids: List of workspace work item type UUIDs to import
        """
        client = self._require_client

        try:
            # TODO(sdk-refactor): no SDK method for bulk-linking workspace types to a
            # project. Replace once SDK exposes work_item_types.import_to_project().
            base_url = client.sdk.config.base_path  # e.g., https://phoenix.plane.town/api/v1
            url = f"{base_url}/workspaces/{workspace_slug}/projects/{project_id}/import-work-item-types/"
            logger.debug(f"Importing workspace types to project: {url}")

            response = client.sdk.work_item_types.session.post(
                url,
                json={"work_item_types": work_item_type_ids},
                headers={
                    "X-Api-Key": client.sdk.config.api_key,
                    "Content-Type": "application/json",
                },
                timeout=client.sdk.config.timeout,
            )

            logger.debug(f"API response status: {response.status_code}")

            if response.status_code == 200:
                logger.info(f"✓ Imported {len(work_item_type_ids)} workspace work item types")
            else:
                raise APIError(
                    f"Failed to import workspace work item types: HTTP {response.status_code}",
                    status_code=response.status_code,
                )

            self._cache.invalidate_types()

        except Exception as e:
            logger.error(f"Failed to import workspace work item types: {e}")
            raise APIError(f"Failed to import workspace work item types: {e}", status_code=0) from e

    async def _update_type_logo_props(self, type_id: str, logo_props) -> None:
        """Update work item type with logo props.

        Uses the SDK's internal ``_patch`` method because the public
        ``work_item_types.update()`` requires all fields and would
        overwrite unrelated properties.  There is no public partial-update
        endpoint in the Plane SDK for work item types.
        """
        client = self._require_client
        config = self._require_config
        logo_props_dict = {
            key: getattr(logo_props, key, None)
            for key in ["icon", "background_color", "emoji"]
            if getattr(logo_props, key, None)
        }
        if logo_props_dict:
            try:
                await client.call(
                    client.sdk.work_item_types._patch,
                    f"{config.workspace}/projects/{self._project_id}/work-item-types/{type_id}",
                    {"logo_props": logo_props_dict},
                )
            except AttributeError:
                logger.warning(
                    "SDK does not support _patch for work item types. "
                    "Logo props update skipped. Consider upgrading the Plane SDK."
                )
            except Exception as e:
                logger.warning(f"Failed to update logo props for type {type_id}: {e}")

    async def _create_type_properties(self, type_id: str, fields: list) -> None:
        """Create custom properties for a work item type."""
        from plane.models.enums import PropertyType, RelationType
        from plane.models.work_item_properties import (
            CreateWorkItemProperty,
            CreateWorkItemPropertyOption,
        )
        from plane.models.work_item_property_configurations import (
            DateAttributeSettings,
            TextAttributeSettings,
        )

        client = self._require_client
        config = self._require_config
        for field in fields:
            property_type = self._map_field_type(field.type)
            kwargs = {
                "display_name": field.display_name or field.name,
                "description": "",
                "property_type": property_type.value,
                "is_required": field.required,
                "is_active": field.is_active,
            }

            if property_type == PropertyType.TEXT:
                kwargs["settings"] = TextAttributeSettings(display_format="multi-line")
            elif property_type == PropertyType.DATETIME:
                kwargs["settings"] = DateAttributeSettings(display_format="MM/dd/yyyy")

            if property_type == PropertyType.RELATION:
                relation_type = field.relation_type or "user"
                if relation_type.lower() == "issue":
                    kwargs["relation_type"] = RelationType.ISSUE.value
                else:
                    kwargs["relation_type"] = RelationType.USER.value

            if field.is_multi:
                kwargs["is_multi"] = field.is_multi

            if property_type == PropertyType.OPTION and getattr(field, "options", None):
                kwargs["options"] = [
                    CreateWorkItemPropertyOption(name=opt) for opt in field.options
                ]

            await client.call(
                client.sdk.work_item_properties.create,
                workspace_slug=config.workspace,
                project_id=self._project_id,
                type_id=type_id,
                data=CreateWorkItemProperty(**kwargs),
            )
        self._property_cache.pop(type_id, None)

    async def _sync_type_properties(self, type_id: str, fields: list[FieldDefinition]) -> None:
        """Create or update type properties to match local definitions."""
        existing_fields = {
            field.name.lower(): field for field in await self._build_field_definitions(type_id)
        }
        desired_keys = {field.name.lower() for field in fields}

        for existing_name, existing in existing_fields.items():
            if existing_name in desired_keys or not existing.remote_id:
                continue
            await self._delete_type_property(type_id, existing.remote_id)

        for field in fields:
            existing_field: FieldDefinition | None = existing_fields.get(field.name.lower())
            if existing_field is None:
                await self._create_type_properties(type_id, [field])
                continue

            if self._field_signature(existing_field) == self._field_signature(field):
                continue

            await self._update_type_property(type_id, existing_field.remote_id, field)

        self._property_cache.pop(type_id, None)

    async def _update_type_property(
        self,
        type_id: str,
        property_id: str | None,
        field: FieldDefinition,
    ) -> None:
        """Update an existing work item property definition."""
        from plane.models.enums import PropertyType, RelationType
        from plane.models.work_item_properties import UpdateWorkItemProperty
        from plane.models.work_item_property_configurations import (
            DateAttributeSettings,
            TextAttributeSettings,
        )

        if not property_id:
            raise ValidationError(
                f"Cannot update property '{field.name}': missing remote_id",
                field="properties",
            )

        client = self._require_client
        config = self._require_config
        property_type = self._map_field_type(field.type)

        kwargs: dict[str, Any] = {
            "display_name": field.display_name or field.name,
            "property_type": property_type.value,
            "is_required": field.required,
            "is_active": field.is_active,
            "is_multi": field.is_multi,
        }
        if property_type == PropertyType.TEXT:
            kwargs["settings"] = TextAttributeSettings(display_format="multi-line")
        elif property_type == PropertyType.DATETIME:
            kwargs["settings"] = DateAttributeSettings(display_format="MM/dd/yyyy")
        if property_type == PropertyType.RELATION:
            relation_type = field.relation_type or "user"
            kwargs["relation_type"] = (
                RelationType.ISSUE.value
                if relation_type and relation_type.lower() == "issue"
                else RelationType.USER.value
            )

        await client.call(
            client.sdk.work_item_properties.update,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            type_id=type_id,
            work_item_property_id=property_id,
            data=UpdateWorkItemProperty(**kwargs),
        )
        if property_type == PropertyType.OPTION:
            await self._sync_property_options(property_id, field.options or [])

    async def _delete_type_property(self, type_id: str, property_id: str) -> None:
        """Delete a remote type property."""
        client = self._require_client
        config = self._require_config
        await client.call(
            client.sdk.work_item_properties.delete,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            type_id=type_id,
            work_item_property_id=property_id,
        )

    async def _sync_property_options(self, property_id: str, options: list[str]) -> None:
        """Make remote OPTION values match the local option names."""
        from plane.models.work_item_properties import CreateWorkItemPropertyOption

        client = self._require_client
        config = self._require_config
        existing_options = {
            (getattr(option, "name", None) or "").lower(): option
            for option in await self.list_property_options(property_id, strict=True)
            if getattr(option, "name", None)
        }
        desired_options = _unique_strings(options)
        desired_lookup = {option.lower() for option in desired_options}

        for existing_name, existing in existing_options.items():
            if existing_name in desired_lookup:
                continue
            await client.call(
                client.sdk.work_item_properties.options.delete,
                workspace_slug=config.workspace,
                project_id=self._project_id,
                property_id=property_id,
                option_id=str(existing.id),
            )

        for option_name in desired_options:
            if option_name.lower() in existing_options:
                continue
            await client.call(
                client.sdk.work_item_properties.options.create,
                workspace_slug=config.workspace,
                project_id=self._project_id,
                property_id=property_id,
                data=CreateWorkItemPropertyOption(name=option_name),
            )

    def _field_signature(self, field: FieldDefinition) -> tuple:
        """Build a comparison signature for property definitions."""
        field_type = getattr(field.type, "value", field.type)
        return (
            field.name.lower(),
            field.display_name,
            str(field_type).lower() if field_type else "",
            field.required,
            tuple(field.options or []),
            field.is_multi,
            field.is_active,
            field.relation_type,
        )

    def _map_field_type(self, field_type):
        """Map field type to Plane PropertyType."""
        from plane.models.enums import PropertyType

        field_type_str = _get_enum_value(field_type)

        # Normalize aliases
        aliases = {"string": "text", "enum": "option", "user": "relation", "number": "decimal"}
        field_type_str = aliases.get(field_type_str, field_type_str)

        mapping = {
            "text": PropertyType.TEXT,
            "decimal": PropertyType.DECIMAL,
            "date": PropertyType.DATETIME,
            "datetime": PropertyType.DATETIME,
            "option": PropertyType.OPTION,
            "relation": PropertyType.RELATION,
            "boolean": PropertyType.BOOLEAN,
            "url": PropertyType.URL,
            "email": PropertyType.EMAIL,
            "file": PropertyType.FILE,
        }
        return mapping.get(field_type_str, PropertyType.TEXT)

    async def create_state(self, state: StateDefinition) -> str:
        """Create a state. Returns remote ID."""
        from plane.models.states import CreateState

        client = self._require_client
        config = self._require_config
        data = CreateState(
            name=state.name,
            group=state.group,
            color=state.color or DEFAULT_COLOR,
            description=state.description or "",
        )
        response = await client.call(
            client.sdk.states.create,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            data=data,
        )
        self._cache.invalidate_states()
        return str(response.id)

    async def update_state(self, state_id: str, state: StateDefinition) -> None:
        """Update a state."""
        from plane.models.states import UpdateState

        client = self._require_client
        config = self._require_config
        data = UpdateState(
            name=state.name,
            group=state.group,
            color=state.color or DEFAULT_COLOR,
            description=state.description or "",
        )
        await client.call(
            client.sdk.states.update,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            state_id=state_id,
            data=data,
        )
        self._cache.invalidate_states()

    async def delete_state(self, state_id: str) -> None:
        """Delete a state by ID.

        Raises APIError if the state cannot be deleted (e.g. it is the default
        state for its group, or work items are still assigned to it).
        """
        client = self._require_client
        config = self._require_config
        await client.call(
            client.sdk.states.delete,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            state_id=state_id,
        )
        self._cache.invalidate_states()

    async def create_label(self, label: LabelDefinition) -> str:
        """Create a label. Returns remote ID."""
        from plane.models.labels import CreateLabel

        client = self._require_client
        config = self._require_config
        data = CreateLabel(name=label.name, color=label.color or DEFAULT_COLOR)
        response = await client.call(
            client.sdk.labels.create,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            data=data,
        )
        self._cache.invalidate_labels()
        return str(response.id)

    async def update_label(self, label_id: str, label: LabelDefinition) -> None:
        """Update a label."""
        from plane.models.labels import UpdateLabel

        client = self._require_client
        config = self._require_config
        data = UpdateLabel(name=label.name, color=label.color or DEFAULT_COLOR)
        await client.call(
            client.sdk.labels.update,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            label_id=label_id,
            data=data,
        )
        self._cache.invalidate_labels()

    async def delete_label(self, label_id: str) -> None:
        """Delete a label by ID."""
        client = self._require_client
        config = self._require_config
        await client.call(
            client.sdk.labels.delete,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            label_id=label_id,
        )
        self._cache.invalidate_labels()

    async def create_module(self, module: ModuleDefinition) -> str:
        """Create a module. Returns remote ID."""
        from plane.models.modules import CreateModule

        client = self._require_client
        config = self._require_config
        data = CreateModule(
            name=module.name,
            description=module.description or "",
            status=module.status or "backlog",
            start_date=module.start_date,
            end_date=module.end_date,
        )
        response = await client.call(
            client.sdk.modules.create,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            data=data,
        )
        return str(response.id)

    async def update_module(self, module_id: str, module: ModuleDefinition) -> None:
        """Update a module."""
        from plane.models.modules import UpdateModule

        client = self._require_client
        config = self._require_config
        data = UpdateModule(
            name=module.name,
            description=module.description or "",
            status=module.status or "backlog",
            start_date=module.start_date,
            end_date=module.end_date,
        )
        await client.call(
            client.sdk.modules.update,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            module_id=module_id,
            data=data,
        )

    async def create_cycle(self, cycle: CycleDefinition) -> str:
        """Create a cycle. Returns remote ID."""
        from plane.models.cycles import CreateCycle

        client = self._require_client
        config = self._require_config

        # Get current user ID for owned_by field
        me = await client.call(client.sdk.users.get_me)
        owned_by = str(me.id)

        data = CreateCycle(
            name=cycle.name,
            description=cycle.description or "",
            start_date=cycle.start_date,
            end_date=cycle.end_date,
            owned_by=owned_by,
            project_id=self._project_id,
        )
        response = await client.call(
            client.sdk.cycles.create,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            data=data,
        )
        return str(response.id)

    async def update_cycle(self, cycle_id: str, cycle: CycleDefinition) -> None:
        """Update a cycle."""
        from plane.models.cycles import UpdateCycle

        client = self._require_client
        config = self._require_config
        data = UpdateCycle(
            name=cycle.name,
            description=cycle.description or "",
            start_date=cycle.start_date,
            end_date=cycle.end_date,
        )
        await client.call(
            client.sdk.cycles.update,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            cycle_id=cycle_id,
            data=data,
        )

    # -------------------------------------------------------------------------
    # Project Features
    # -------------------------------------------------------------------------

    def _features_url(self) -> str:
        """Return the raw /features/ endpoint URL for this project."""
        config = self._require_config
        base = config.api_url.rstrip("/")
        return f"{base}/api/v1/workspaces/{config.workspace}/projects/{self._project_id}/features/"

    async def enable_features(
        self,
        modules_enabled: bool = False,
        cycles_enabled: bool = False,
        pages_enabled: bool = False,
        views_enabled: bool = False,
        intakes_enabled: bool = False,
        epics_enabled: bool = False,
        work_item_types_enabled: bool = False,
        workflows_enabled: bool = False,
        parallel_cycles_enabled: bool = False,
        project_updates_enabled: bool = False,
    ) -> None:
        """Enable features on the project.

        Only sends flags that are explicitly set to True — False means
        "don't touch this flag", not "disable it". Use set_features() to
        apply exact values (including disabling features).

        Args:
            modules_enabled: Enable modules feature
            cycles_enabled: Enable cycles feature
            pages_enabled: Enable pages feature
            views_enabled: Enable views feature
            intakes_enabled: Enable intakes feature
            epics_enabled: Enable epics feature
            work_item_types_enabled: Enable work item types feature
            workflows_enabled: Enable workflows feature (required before
                creating/updating workflows via the workflows API)
            parallel_cycles_enabled: Enable parallel cycles feature
            project_updates_enabled: Enable project updates feature
        """
        import httpx

        client = self._require_client

        feature_data: dict[str, bool] = {}
        if modules_enabled:
            feature_data["modules"] = True
        if cycles_enabled:
            feature_data["cycles"] = True
        if pages_enabled:
            feature_data["pages"] = True
        if views_enabled:
            feature_data["views"] = True
        if intakes_enabled:
            feature_data["intakes"] = True
        if epics_enabled:
            feature_data["epics"] = True
        if work_item_types_enabled:
            feature_data["work_item_types"] = True
        if workflows_enabled:
            feature_data["workflows"] = True
        if parallel_cycles_enabled:
            feature_data["parallel_cycles"] = True
        if project_updates_enabled:
            feature_data["project_updates"] = True

        if not feature_data:
            return

        try:
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http:
                resp = await http.patch(self._features_url(), json=feature_data)
                resp.raise_for_status()
            logger.info(f"Enabled features: {', '.join(feature_data)}")
        except Exception as e:
            logger.warning(f"Failed to enable features: {e}")
            # Don't fail the entire push if feature enablement fails

    async def get_project_features(self) -> dict[str, bool]:
        """Get current project feature toggles.

        Returns a plain dict with ALL keys the API returns — currently:
        cycles, modules, pages, views, intakes, epics, work_item_types,
        workflows, parallel_cycles, project_updates.

        Using raw httpx instead of the SDK so that fields not yet modelled
        in ProjectFeature (parallel_cycles, project_updates, future additions)
        are captured automatically — no model_extra workarounds needed.
        """
        import httpx

        client = self._require_client

        try:
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http:
                resp = await http.get(self._features_url())
                resp.raise_for_status()
                data = resp.json()
            return {k: bool(v) for k, v in data.items() if isinstance(v, bool)}
        except Exception as e:
            logger.warning(f"Failed to fetch project features: {e}")
            return {}

    async def set_features(self, features: dict[str, bool]) -> None:
        """Set project features to exact values declared in features.yaml.

        Unlike enable_features() which only switches things ON, this method
        applies the caller's exact intent — false values disable the feature.

        Args:
            features: Dict mapping feature name → bool. Only keys present in
                      the dict are sent; absent keys are left unchanged by the API.
        """
        import httpx

        client = self._require_client

        if not features:
            return

        try:
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http:
                resp = await http.patch(self._features_url(), json=features)
                resp.raise_for_status()
            logger.info(f"Set project features: {features}")
        except Exception as e:
            logger.warning(f"Failed to set project features: {e}")
            # Don't fail the entire schema push if feature update fails

    # -------------------------------------------------------------------------
    # Public API: Work Items
    # -------------------------------------------------------------------------

    async def create_work_item(self, work_item: WorkItem) -> str:
        """Create a work item. Returns remote ID."""
        from plane.models.work_items import CreateWorkItem

        client = self._require_client
        config = self._require_config
        await self._ensure_caches_loaded()

        # O(1) lookups using cache
        type_id = self._cache.get_type_id(work_item.type) if work_item.type else None
        state_id = self._cache.get_state_id(work_item.state) if work_item.state else None
        label_ids = self._cache.get_label_ids(work_item.labels) if work_item.labels else []
        self._validate_work_item_references(work_item, type_id, state_id, label_ids)

        kwargs = self._build_work_item_kwargs(
            work_item,
            type_id,
            state_id,
            label_ids,
        )
        data = CreateWorkItem(**kwargs)

        response = await client.call(
            client.sdk.work_items.create,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            data=data,
        )
        work_item_id = str(response.id)

        # Capture sequence_id for auto-ID writeback
        sequence_id = getattr(response, "sequence_id", None)
        if sequence_id is not None:
            self._sequence_ids[work_item_id] = int(sequence_id)

        try:
            if type_id:
                await self._set_work_item_properties(
                    work_item_id,
                    type_id,
                    work_item.properties,
                    replace_existing=False,
                )
            await self._sync_work_item_relations(work_item_id, work_item, replace_existing=False)
        except (APIError, NetworkError, ValidationError):
            try:
                await self.delete_work_item(work_item_id)
            except (APIError, NetworkError) as cleanup_error:
                logger.warning(
                    f"Failed to roll back partially created work item {work_item_id}: {cleanup_error}"
                )
            raise

        return work_item_id

    async def update_work_item(self, remote_id: str, work_item: WorkItem) -> None:
        """Update an existing work item."""
        from plane.models.work_items import UpdateWorkItem

        client = self._require_client
        config = self._require_config
        await self._ensure_caches_loaded()

        type_id = self._cache.get_type_id(work_item.type) if work_item.type else None
        state_id = self._cache.get_state_id(work_item.state) if work_item.state else None
        label_ids = self._cache.get_label_ids(work_item.labels) if work_item.labels else []
        self._validate_work_item_references(work_item, type_id, state_id, label_ids)

        kwargs = self._build_work_item_kwargs(
            work_item,
            type_id,
            state_id,
            label_ids,
            include_empty_collections=True,
        )
        data = UpdateWorkItem(**kwargs)

        await client.call(
            client.sdk.work_items.update,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            work_item_id=remote_id,
            data=data,
        )

        if type_id:
            await self._set_work_item_properties(
                remote_id,
                type_id,
                work_item.properties,
                replace_existing=True,
            )
        await self._sync_work_item_relations(remote_id, work_item, replace_existing=True)

    def _validate_work_item_references(
        self,
        work_item: WorkItem,
        type_id: str | None,
        state_id: str | None,
        label_ids: list[str],
    ) -> None:
        """Raise a validation error for unsupported or unresolved work item fields."""
        # Skip type validation when types cache is empty (e.g. 402 on free tier)
        types_available = bool(self._cache._type_name_to_id)
        if work_item.type and not type_id and types_available:
            raise ValidationError(
                f"Unknown type '{work_item.type}'",
                field="type",
            )
        if work_item.state and not state_id:
            raise ValidationError(
                f"Unknown state '{work_item.state}'",
                field="state",
            )
        if work_item.labels and len(label_ids) != len(work_item.labels):
            resolved_labels = {
                label_name.lower() for label_name in self._cache.get_label_names(label_ids)
            }
            unknown_labels = [
                label for label in work_item.labels if label.lower() not in resolved_labels
            ]
            raise ValidationError(
                f"Unknown label(s): {', '.join(unknown_labels)}",
                field="labels",
            )
        if work_item.watchers:
            raise ValidationError(
                "The current Plane API integration does not support syncing 'watchers'.",
                field="watchers",
            )
        if work_item.children:
            raise ValidationError(
                "Nested 'children' are not supported by the current push/apply pipeline.",
                field="children",
            )
        self._validate_work_item_properties(work_item)

    def _build_work_item_kwargs(
        self,
        work_item: WorkItem,
        type_id: str | None,
        state_id: str | None,
        label_ids: list[str],
        include_empty_collections: bool = False,
    ) -> dict[str, Any]:
        """Build kwargs dict for work item create/update."""
        kwargs: dict[str, Any] = {"name": work_item.title}

        if work_item.description:
            kwargs["description_html"] = work_item.description
        if type_id:
            kwargs["type_id"] = type_id
        if state_id:
            kwargs["state"] = state_id
        if work_item.priority:
            kwargs["priority"] = work_item.priority
        if label_ids or include_empty_collections:
            kwargs["labels"] = label_ids
        if work_item.start_date:
            kwargs["start_date"] = work_item.start_date
        if work_item.due_date:
            kwargs["target_date"] = work_item.due_date
        if work_item.parent:
            kwargs["parent"] = work_item.parent
        if work_item.assignees or include_empty_collections:
            kwargs["assignees"] = work_item.assignees

        return kwargs

    def _validate_work_item_properties(self, work_item: WorkItem) -> None:
        """Validate custom property names and option values against the cached type schema."""
        if not work_item.properties or not work_item.type:
            return

        type_def = next(
            (
                type_def
                for type_def in self._cache.types
                if type_def.name.lower() == work_item.type.lower()
            ),
            None,
        )
        if type_def is None:
            return

        fields = {field.name.lower(): field for field in type_def.fields or []}
        for prop_name, prop_value in work_item.properties.items():
            field = fields.get(prop_name.lower())
            if field is None:
                raise ValidationError(
                    f"Unknown property '{prop_name}' for type '{type_def.name}'",
                    field="properties",
                )

            field_type = getattr(field.type, "value", field.type)
            if str(field_type).lower() != FieldType.OPTION.value:
                continue

            valid_options = {option.lower() for option in field.options or []}
            values = prop_value if isinstance(prop_value, list) else [prop_value]
            unknown = [str(value) for value in values if str(value).lower() not in valid_options]
            if unknown:
                raise ValidationError(
                    f"Unknown option(s) for property '{prop_name}': {', '.join(unknown)}",
                    field="properties",
                )

    async def delete_work_item(self, remote_id: str) -> None:
        """Delete a work item from Plane."""
        client = self._require_client
        config = self._require_config
        await client.call(
            client.sdk.work_items.delete,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            work_item_id=remote_id,
        )

    async def get_work_item(self, remote_id: str) -> WorkItem:
        """Retrieve a single work item by remote ID.

        More efficient than list_work_items() when checking a small number
        of items (e.g., during conflict detection for updates).

        Args:
            remote_id: The UUID of the work item to retrieve

        Returns:
            WorkItem converted from the SDK response

        Raises:
            NotFoundError: If the work item does not exist
            APIError: If the API call fails
        """
        client = self._require_client
        config = self._require_config
        await self._ensure_caches_loaded()

        response = await client.call(
            client.sdk.work_items.retrieve,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            work_item_id=remote_id,
        )
        relations = await self._get_work_item_relations(remote_id)
        self._apply_relation_fields(response, relations)
        type_id = _extract_id(getattr(response, "type_id", None)) or _extract_id(
            getattr(response, "type", None)
        )
        properties = await self._fetch_work_item_properties_for_item(remote_id, type_id)
        work_item = self._convert_sdk_work_item(response, relations=relations)
        work_item.properties = properties
        return work_item

    async def list_work_items(self) -> list[WorkItem]:
        """List all work items from Plane with pagination."""
        await self._ensure_caches_loaded()
        raw_items = await self.list_work_items_raw(include_relations=True)
        return [self._convert_sdk_work_item(item) for item in raw_items]

    def _convert_sdk_work_item(
        self, item, relations: dict[str, list[str]] | None = None
    ) -> WorkItem:
        """Convert SDK work item to our model."""
        # Resolve state: always try cache first (item.state may be a UUID string,
        # which _extract_name would return as-is — not a human-readable name).
        state_val = getattr(item, "state", None)
        state_id = _extract_id(state_val)
        state_name = (self._cache.get_state_name(state_id) if state_id else None) or _extract_name(
            state_val
        )

        raw_labels = getattr(item, "labels", None) or []
        if raw_labels and all(_extract_name(label) for label in raw_labels):
            label_names: list[str] = [n for label in raw_labels for n in [_extract_name(label)] if n is not None]
        else:
            label_ids: list[str] = [i for label in raw_labels for i in [_extract_id(label)] if i is not None]
            label_names = self._cache.get_label_names(label_ids)

        # Build item ID from project key + sequence
        sequence_id = getattr(item, "sequence_id", None)
        item_id = f"{self._require_config.project_key}-{sequence_id}" if sequence_id else None

        # Resolve type name from cache
        type_name = _extract_name(getattr(item, "type", None))
        type_id = _extract_id(getattr(item, "type_id", None)) or _extract_id(
            getattr(item, "type", None)
        )
        item_type = type_name or (self._cache.get_type_name(type_id) if type_id else None) or "task"

        # Build WorkItem with all optional fields
        parent_id = getattr(item, "parent", None) or getattr(item, "parent_id", None)
        assignees = getattr(item, "assignees", None) or []
        normalized_relations = relations or self._extract_relation_fields(item)
        duplicate_relations = normalized_relations.get("duplicate", [])

        return WorkItem(
            id=item_id,
            title=item.name,
            description=getattr(item, "description_html", None)
            or getattr(item, "description", None),
            type=item_type,
            state=state_name,
            priority=getattr(item, "priority", None),
            labels=label_names,
            start_date=getattr(item, "start_date", None),
            due_date=getattr(item, "target_date", None),
            parent=str(parent_id) if parent_id else None,
            assignees=[
                getattr(assignee, "email", None) or _extract_id(assignee) or str(assignee)
                for assignee in assignees
            ],
            blocked_by=normalized_relations.get("blocked_by", []),
            blocking=normalized_relations.get("blocking", []),
            duplicate_of=duplicate_relations[0] if duplicate_relations else None,
            relates_to=normalized_relations.get("relates_to", []),
        )

    async def list_work_items_raw(
        self,
        workspace: str | None = None,
        project_id: str | None = None,
        include_relations: bool = False,
    ) -> list:
        """List work items returning raw SDK response objects (with pagination)."""
        from plane.models.query_params import WorkItemQueryParams

        client = self._require_client
        ws = workspace or (self._config.workspace if self._config else None)
        pid = project_id or self._project_id

        all_items: list = []
        cursor: str | None = None
        per_page = 100

        try:
            while True:
                response = await client.call(
                    client.sdk.work_items.list,
                    workspace_slug=ws,
                    project_id=pid,
                    params=WorkItemQueryParams(cursor=cursor, per_page=per_page),
                )

                results = list(getattr(response, "results", []) or [])
                all_items.extend(results)

                if not getattr(response, "next_page_results", False):
                    break
                cursor = getattr(response, "next_cursor", None)
                if not cursor:
                    break

            if include_relations:
                await self._hydrate_work_item_relations(all_items)

        except (APIError, NetworkError) as e:
            logger.warning(f"Failed to fetch work items: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error fetching work items: {e}")
            return []

        return all_items

    def _extract_relation_fields(self, item) -> dict[str, list[str]]:
        """Extract relation lists from hydrated SDK items."""
        blocked_by = getattr(item, "blocked_issues", None)
        if blocked_by is None:
            blocked_by = getattr(item, "blocked_by", None)

        blocking = getattr(item, "blocker_issues", None)
        if blocking is None:
            blocking = getattr(item, "blocking", None)

        duplicate = getattr(item, "duplicate", None)
        if duplicate is None:
            duplicate_to = getattr(item, "duplicate_to", None)
            duplicate = [duplicate_to] if duplicate_to else []

        relates_to = getattr(item, "related_issues", None)
        if relates_to is None:
            relates_to = getattr(item, "relates_to", None)

        return {
            "blocked_by": [_extract_id(value) or str(value) for value in blocked_by or []],
            "blocking": [_extract_id(value) or str(value) for value in blocking or []],
            "duplicate": [_extract_id(value) or str(value) for value in duplicate or []],
            "relates_to": [_extract_id(value) or str(value) for value in relates_to or []],
        }

    def _apply_relation_fields(self, item, relations: dict[str, list[str]]) -> None:
        """Attach relation fields in the legacy shape expected elsewhere in the repo."""
        duplicate_values = relations.get("duplicate", [])
        setattr(
            item, "parent_id", getattr(item, "parent", None) or getattr(item, "parent_id", None)
        )
        setattr(item, "blocked_issues", relations.get("blocked_by", []))
        setattr(item, "blocker_issues", relations.get("blocking", []))
        setattr(item, "duplicate_to", duplicate_values[0] if duplicate_values else None)
        setattr(item, "related_issues", relations.get("relates_to", []))

    async def _get_work_item_relations(self, work_item_id: str) -> dict[str, list[str]]:
        """Fetch normalized work item relations from Plane."""
        client = self._require_client
        config = self._require_config
        response = await client.call(
            client.sdk.work_items.relations.list,
            workspace_slug=config.workspace,
            project_id=self._project_id,
            work_item_id=work_item_id,
        )
        return {
            "blocking": [str(value) for value in getattr(response, "blocking", []) or []],
            "blocked_by": [str(value) for value in getattr(response, "blocked_by", []) or []],
            "duplicate": [str(value) for value in getattr(response, "duplicate", []) or []],
            "relates_to": [str(value) for value in getattr(response, "relates_to", []) or []],
        }

    async def _hydrate_work_item_relations(self, items: list) -> None:
        """Fetch relation data for a batch of raw SDK items."""
        relation_tasks = []
        hydrated_items = []

        for item in items:
            item_id = _extract_id(getattr(item, "id", None))
            if not item_id:
                continue
            hydrated_items.append(item)
            relation_tasks.append(self._get_work_item_relations(item_id))

        if not relation_tasks:
            return

        relation_results = await asyncio.gather(*relation_tasks, return_exceptions=True)
        for item, relation_result in zip(hydrated_items, relation_results):
            if isinstance(relation_result, BaseException):
                logger.warning(
                    f"Failed to fetch relations for work item {_extract_id(getattr(item, 'id', None))}: {relation_result}"
                )
                continue
            self._apply_relation_fields(item, relation_result)

    async def _sync_work_item_relations(
        self,
        work_item_id: str,
        work_item: WorkItem,
        replace_existing: bool,
    ) -> None:
        """Create or replace work item relations."""
        from plane.models.work_items import CreateWorkItemRelation, RemoveWorkItemRelation

        client = self._require_client
        config = self._require_config
        desired_relations = {
            "blocked_by": _unique_strings(work_item.blocked_by),
            "blocking": _unique_strings(work_item.blocking),
            "duplicate": _unique_strings(
                [work_item.duplicate_of] if work_item.duplicate_of else []
            ),
            "relates_to": _unique_strings(work_item.relates_to),
        }
        if not any(desired_relations.values()) and not replace_existing:
            return

        current_relations = (
            await self._get_work_item_relations(work_item_id)
            if replace_existing
            else {"blocked_by": [], "blocking": [], "duplicate": [], "relates_to": []}
        )

        for relation_type, desired_values in desired_relations.items():
            current_values = _unique_strings(current_relations.get(relation_type, []))
            to_remove = [value for value in current_values if value not in desired_values]
            to_add = [value for value in desired_values if value not in current_values]

            for related_issue in to_remove:
                await client.call(
                    client.sdk.work_items.relations.delete,
                    workspace_slug=config.workspace,
                    project_id=self._project_id,
                    work_item_id=work_item_id,
                    data=RemoveWorkItemRelation(related_issue=related_issue),
                )

            if to_add:
                await client.call(
                    client.sdk.work_items.relations.create,
                    workspace_slug=config.workspace,
                    project_id=self._project_id,
                    work_item_id=work_item_id,
                    data=CreateWorkItemRelation(
                        relation_type=relation_type,
                        issues=to_add,
                    ),
                )

    # -------------------------------------------------------------------------
    # Property Operations
    # -------------------------------------------------------------------------

    async def list_type_properties(self, type_id: str, strict: bool = False) -> list:
        """Fetch all properties for a work item type."""
        client = self._require_client
        config = self._require_config
        try:
            return list(
                await client.call(
                    client.sdk.work_item_properties.list,
                    workspace_slug=config.workspace,
                    project_id=self._project_id,
                    type_id=type_id,
                )
            )
        except (APIError, NetworkError) as e:
            if strict:
                raise
            logger.debug(f"Failed to fetch properties for type {type_id}: {e}")
            return []
        except (TypeError, AttributeError, ValueError) as e:
            if strict:
                raise
            logger.error(f"Unexpected error fetching properties for type {type_id}: {e}")
            return []

    async def list_property_options(self, property_id: str, strict: bool = False) -> list:
        """Fetch all options for an OPTION type property."""
        client = self._require_client
        config = self._require_config
        try:
            return list(
                await client.call(
                    client.sdk.work_item_properties.options.list,
                    workspace_slug=config.workspace,
                    project_id=self._project_id,
                    property_id=property_id,
                )
            )
        except (APIError, NetworkError) as e:
            if strict:
                raise
            logger.debug(f"Failed to fetch options for property {property_id}: {e}")
            return []
        except (TypeError, AttributeError, ValueError) as e:
            if strict:
                raise
            logger.error(f"Unexpected error fetching property options for {property_id}: {e}")
            return []

    async def _get_property_map(self, type_id: str) -> dict[str, dict[str, Any]]:
        """Get (and cache) the property map for a work item type.

        Avoids redundant API calls when setting properties on many items of
        the same type.
        """
        if type_id in self._property_cache:
            return self._property_cache[type_id]

        props_response = await self.list_type_properties(type_id)
        property_map: dict[str, dict[str, Any]] = {}
        for prop in props_response:
            prop_name = getattr(prop, "display_name", None) or getattr(prop, "name", None)
            internal_name = getattr(prop, "name", None)
            if prop_name:
                prop_type = _get_enum_value(getattr(prop, "property_type", None)) or "text"
                prop_info = {
                    "property_id": str(prop.id),
                    "is_multi": getattr(prop, "is_multi", False),
                    "property_type": prop_type,
                    "display_name": prop_name,
                }
                property_map[prop_name.lower()] = prop_info
                if internal_name:
                    property_map[internal_name.lower()] = prop_info

        # Evict oldest entries if cache exceeds max size
        if len(self._property_cache) >= self._PROPERTY_CACHE_MAX_SIZE:
            oldest_key = next(iter(self._property_cache))
            del self._property_cache[oldest_key]

        self._property_cache[type_id] = property_map
        return property_map

    async def _set_work_item_properties(
        self,
        work_item_id: str,
        type_id: str,
        properties: dict[str, Any],
        replace_existing: bool = False,
    ) -> None:
        """Set custom property values for a work item."""
        from plane.models.work_item_properties import CreateWorkItemPropertyValue

        properties = properties or {}
        if not properties and not replace_existing:
            return
        property_map = await self._get_property_map(type_id)
        desired_property_ids: set[str] = set()

        for prop_name, prop_value in properties.items():
            prop_info = property_map.get(prop_name.lower())
            if prop_info is None:
                raise ValidationError(
                    f"Property '{prop_name}' does not exist on the remote type",
                    field="properties",
                )

            property_id = prop_info["property_id"]
            desired_property_ids.add(property_id)

            if self._property_value_is_empty(prop_value):
                await self._delete_property_value(work_item_id, property_id)
                continue

            if "option" in prop_info["property_type"]:
                await self._set_option_property(
                    work_item_id,
                    property_id,
                    prop_value,
                    prop_info["is_multi"],
                    prop_name,
                )
            else:
                await self._upsert_property_value(
                    work_item_id,
                    property_id,
                    CreateWorkItemPropertyValue(value=prop_value),
                )

        if replace_existing:
            for property_id in {prop_info["property_id"] for prop_info in property_map.values()}:
                if property_id in desired_property_ids:
                    continue
                await self._delete_property_value(work_item_id, property_id)

    async def _set_option_property(
        self, work_item_id: str, property_id: str, value, is_multi: bool, prop_name: str
    ) -> None:
        """Set an OPTION type property value."""
        from plane.models.work_item_properties import CreateWorkItemPropertyValue

        self._require_client  # guard: raises if not connected
        self._require_config  # guard: raises if not configured
        options = await self.list_property_options(property_id, strict=True)
        option_map = {}
        for opt in options:
            opt_name = (
                getattr(opt, "value", None)
                or getattr(opt, "name", None)
                or getattr(opt, "label", None)
            )
            if opt_name:
                option_map[str(opt_name).lower()] = str(opt.id)

        if is_multi:
            values = value if isinstance(value, list) else [value]
            unknown_values = [
                str(option) for option in values if str(option).lower() not in option_map
            ]
            if unknown_values:
                raise ValidationError(
                    f"Unknown option(s) for property '{prop_name}': {', '.join(unknown_values)}",
                    field="properties",
                )
            option_ids = [option_map[str(option).lower()] for option in values]
            await self._upsert_property_value(
                work_item_id,
                property_id,
                CreateWorkItemPropertyValue(value=option_ids),
            )
            return

        val = value[0] if isinstance(value, list) else value
        if val is None:
            return
        option_id = option_map.get(str(val).lower())
        if option_id is None:
            raise ValidationError(
                f"Unknown option '{val}' for property '{prop_name}'",
                field="properties",
            )
        await self._upsert_property_value(
            work_item_id,
            property_id,
            CreateWorkItemPropertyValue(value=option_id),
        )

    async def _upsert_property_value(self, work_item_id: str, property_id: str, data) -> None:
        """Create or update a property value depending on whether it already exists."""
        from planecompose.exceptions import NotFoundError

        client = self._require_client
        config = self._require_config
        try:
            await client.call(
                client.sdk.work_item_properties.values.update,
                workspace_slug=config.workspace,
                project_id=self._project_id,
                work_item_id=work_item_id,
                property_id=property_id,
                data=data,
            )
        except NotFoundError:
            await client.call(
                client.sdk.work_item_properties.values.create,
                workspace_slug=config.workspace,
                project_id=self._project_id,
                work_item_id=work_item_id,
                property_id=property_id,
                data=data,
            )

    async def _delete_property_value(self, work_item_id: str, property_id: str) -> None:
        """Delete a property value, ignoring missing values."""
        from planecompose.exceptions import NotFoundError

        client = self._require_client
        config = self._require_config
        try:
            await client.call(
                client.sdk.work_item_properties.values.delete,
                workspace_slug=config.workspace,
                project_id=self._project_id,
                work_item_id=work_item_id,
                property_id=property_id,
            )
        except NotFoundError:
            return

    def _property_value_is_empty(self, value: Any) -> bool:
        """Treat explicit nulls and empty lists as clearing a property."""
        return value is None or (isinstance(value, list) and len(value) == 0)

    async def get_property_value(self, work_item_id: str, property_id: str) -> Any:
        """Get a property value for a work item."""
        from planecompose.exceptions import NotFoundError

        client = self._require_client
        config = self._require_config
        try:
            return await client.call(
                client.sdk.work_item_properties.values.retrieve,
                workspace_slug=config.workspace,
                project_id=self._project_id,
                work_item_id=work_item_id,
                property_id=property_id,
            )
        except NotFoundError:
            return None
        except (APIError, NetworkError) as e:
            logger.debug(f"Failed to get property value: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting property value: {e}")
            return None

    async def build_property_maps(
        self, types_data: list[dict[str, Any]]
    ) -> dict[str, dict[str, Any]]:
        """Build maps of properties and options for all work item types."""
        property_maps: dict[str, dict[str, Any]] = {}

        for type_info in types_data:
            type_id = type_info.get("id")
            if not type_id:
                continue

            property_maps[type_id] = {}

            try:
                properties = await self.list_type_properties(type_id)
                for prop in properties:
                    prop_id = str(prop.id)
                    prop_name = getattr(prop, "display_name", None) or getattr(prop, "name", None)
                    prop_type = _get_enum_value(getattr(prop, "property_type", None)) or "text"

                    if not prop_name:
                        continue

                    # Build options map for OPTION type properties
                    options_map = {}
                    options = getattr(prop, "options", None)
                    if "option" in prop_type and options:
                        for opt in options:
                            opt_id = str(getattr(opt, "id", "")) or None
                            opt_value = getattr(opt, "value", None) or getattr(opt, "name", None)
                            if opt_id and opt_value:
                                options_map[opt_id] = opt_value

                    relation_type = getattr(prop, "relation_type", None)
                    property_maps[type_id][prop_id] = {
                        "name": prop_name,
                        "type": prop_type,
                        "is_multi": getattr(prop, "is_multi", False),
                        "relation_type": str(relation_type).lower() if relation_type else None,
                        "options": options_map,
                    }
            except Exception as e:
                logger.warning(f"Failed to fetch properties for type {type_id}: {e}")

        return property_maps

    async def _fetch_work_item_properties_for_item(
        self,
        work_item_id: str,
        type_id: str | None,
    ) -> dict[str, Any]:
        """Fetch custom property values for a single work item."""
        if not type_id:
            return {}

        property_maps = await self.build_property_maps([{"id": type_id}])
        if not property_maps.get(type_id):
            return {}

        item_stub = SimpleNamespace(id=work_item_id, type_id=type_id)
        properties = await self.fetch_work_item_properties_batch([item_stub], property_maps)
        return properties.get(work_item_id, {})

    async def fetch_work_item_properties_batch(
        self, work_items: list, property_maps: dict[str, Any]
    ) -> dict[str, dict[str, Any]]:
        """Fetch custom property values for multiple work items efficiently.

        Uses asyncio.gather to fetch all properties for each item in parallel
        rather than making sequential API calls per item per property.
        """
        import asyncio

        results: dict[str, dict[str, Any]] = {}

        # Group items by type for efficient property fetching
        items_by_type: dict[str, list] = {}
        for item in work_items:
            type_id = getattr(item, "type_id", None)
            if type_id:
                type_id_str = str(type_id)
                if type_id_str not in items_by_type:
                    items_by_type[type_id_str] = []
                items_by_type[type_id_str].append(item)

        for type_id, items in items_by_type.items():
            if type_id not in property_maps or not property_maps[type_id]:
                continue

            props = list(property_maps[type_id].items())

            for item in items:
                item_id = str(item.id)
                results[item_id] = {}

                # Fetch all properties for this item in parallel
                fetch_tasks = [self.get_property_value(item_id, prop_id) for prop_id, _ in props]
                responses = await asyncio.gather(*fetch_tasks, return_exceptions=True)

                for (prop_id, prop_info), value_response in zip(props, responses):
                    if isinstance(value_response, BaseException) or value_response is None:
                        continue

                    prop_type = str(prop_info["type"]).lower()

                    if isinstance(value_response, list):
                        values = []
                        for val_item in value_response:
                            val = getattr(val_item, "value", None)
                            if val is not None:
                                val_str = str(val)
                                if "option" in prop_type and val_str in prop_info.get(
                                    "options", {}
                                ):
                                    values.append(prop_info["options"][val_str])
                                else:
                                    values.append(val)
                        if values:
                            results[item_id][prop_info["name"]] = values
                    else:
                        val = getattr(value_response, "value", None)
                        if val is not None:
                            val_str = str(val)
                            if "option" in prop_type and val_str in prop_info.get("options", {}):
                                results[item_id][prop_info["name"]] = [
                                    prop_info["options"][val_str]
                                ]
                            else:
                                results[item_id][prop_info["name"]] = val

        return results

    # -------------------------------------------------------------------------
    # Project Operations
    # -------------------------------------------------------------------------

    async def retrieve_project(self, workspace: str, project_id: str):
        """Retrieve a project by UUID."""
        client = self._require_client
        return await client.call(
            client.sdk.projects.retrieve,
            workspace_slug=workspace,
            project_id=project_id,
        )

    async def list_projects(self, workspace: str) -> list:
        """List all projects in a workspace."""
        client = self._require_client
        response = await client.call(
            client.sdk.projects.list,
            workspace_slug=workspace,
        )
        return _get_results(response)

    async def create_project(
        self,
        workspace: str,
        name: str,
        identifier: str,
        description: str = "",
        network: str | None = None,
        timezone: str | None = None,
    ) -> Any:
        """Create a new project."""
        from plane.models.projects import CreateProject

        client = self._require_client
        data = CreateProject(
            name=name,
            identifier=identifier.upper(),
            description=description or "Created via plane-compose",
        )
        project = await client.call(
            client.sdk.projects.create,
            workspace_slug=workspace,
            data=data,
        )
        # Apply metadata fields not supported by CreateProject (network, timezone)
        if network is not None or timezone is not None:
            await self.update_project_metadata(
                workspace=workspace,
                project_id=str(project.id),
                network=network,
                timezone=timezone,
            )
        return project

    async def update_project_metadata(
        self,
        workspace: str,
        project_id: str,
        name: str | None = None,
        description: str | None = None,
        network: str | None = None,
        timezone: str | None = None,
    ) -> None:
        """PATCH project metadata fields (name, description, network, timezone).

        Uses raw httpx since the SDK UpdateProject model does not support the
        network field (integer mapping). Maps human-readable network values:
          "public"  -> 2
          "private" -> 0
        """
        import httpx

        client = self._require_client
        # Intentionally NOT using _require_config — workspace and project_id are passed
        # as explicit parameters so this method works with both create_client() backends
        # (no config set) and fully connected backends (config set).
        api_url = self._config.api_url if self._config else client._api_url

        payload: dict = {}
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if network is not None:
            from planecompose.core.models import network_to_int
            network_val = network_to_int(network)
            if network_val is not None:
                payload["network"] = network_val
            else:
                logger.warning(f"Unknown network value '{network}', must be 'public' or 'private' — skipping")
        if timezone is not None:
            payload["timezone"] = timezone

        if not payload:
            return

        url = f"{api_url}/api/v1/workspaces/{workspace}/projects/{project_id}/"
        try:
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http:
                resp = await http.patch(url, json=payload)
                resp.raise_for_status()
            logger.info(f"Updated project metadata: {list(payload.keys())}")
        except Exception as e:
            logger.warning(f"Failed to update project metadata: {e}")

    async def list_states_raw(self, workspace: str, project_id: str) -> list:
        """List states returning raw SDK response objects."""
        client = self._require_client
        try:
            response = await client.call(
                client.sdk.states.list,
                workspace_slug=workspace,
                project_id=project_id,
            )
            return _get_results(response)
        except (APIError, NetworkError) as e:
            logger.warning(f"Failed to fetch states: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error fetching states: {e}")
            return []

    async def list_labels_raw(self, workspace: str, project_id: str) -> list:
        """List labels returning raw SDK response objects."""
        client = self._require_client
        try:
            response = await client.call(
                client.sdk.labels.list,
                workspace_slug=workspace,
                project_id=project_id,
            )
            return _get_results(response)
        except (APIError, NetworkError) as e:
            logger.warning(f"Failed to fetch raw labels: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error fetching raw labels: {e}")
            return []

    # ------------------------------------------------------------------
    # Cycles
    # ------------------------------------------------------------------

    async def list_cycles_raw(self, workspace: str, project_id: str) -> list:
        """List all cycles (active + archived) returning raw SDK objects."""
        client = self._require_client
        try:
            response = await client.call(
                client.sdk.cycles.list,
                workspace_slug=workspace,
                project_id=project_id,
            )
            active = _get_results(response)
        except (APIError, NetworkError) as e:
            logger.warning(f"Failed to fetch cycles: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error fetching cycles: {e}")
            return []

        try:
            archived_response = await client.call(
                client.sdk.cycles.list_archived,
                workspace_slug=workspace,
                project_id=project_id,
            )
            archived = _get_results(archived_response)
        except Exception as e:
            logger.warning(f"Failed to fetch archived cycles: {e}")
            archived = []

        return active + archived

    async def list_cycle_work_items_raw(
        self, workspace: str, project_id: str, cycle_id: str
    ) -> list:
        """List work items belonging to a cycle."""
        client = self._require_client
        try:
            response = await client.call(
                client.sdk.cycles.list_work_items,
                workspace_slug=workspace,
                project_id=project_id,
                cycle_id=cycle_id,
            )
            return _get_results(response)
        except (APIError, NetworkError) as e:
            logger.warning(f"Failed to fetch work items for cycle {cycle_id}: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error fetching cycle work items: {e}")
            return []

    # ------------------------------------------------------------------
    # Modules
    # ------------------------------------------------------------------

    async def list_modules_raw(self, workspace: str, project_id: str) -> list:
        """List all modules (active + archived) returning raw SDK objects."""
        client = self._require_client
        try:
            response = await client.call(
                client.sdk.modules.list,
                workspace_slug=workspace,
                project_id=project_id,
            )
            active = _get_results(response)
        except (APIError, NetworkError) as e:
            logger.warning(f"Failed to fetch modules: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error fetching modules: {e}")
            return []

        try:
            archived_response = await client.call(
                client.sdk.modules.list_archived,
                workspace_slug=workspace,
                project_id=project_id,
            )
            archived = _get_results(archived_response)
        except Exception as e:
            logger.warning(f"Failed to fetch archived modules: {e}")
            archived = []

        return active + archived

    async def list_estimates_raw(self, workspace: str, project_id: str) -> list:
        """List all project estimates with their points (raw SDK objects).

        Note: plane-sdk doesn't have estimates support yet, so we use direct HTTP.
        """
        from types import SimpleNamespace

        import requests  # type: ignore[import-untyped]

        client = self._require_client
        base_path = client.sdk.config.base_path.rstrip("/")
        api_key = client.sdk.config.api_key

        try:
            # Make direct HTTP request to estimates endpoint
            # The API endpoint is /workspaces/{workspace_slug}/projects/{project_id}/estimates/
            url = f"{base_path}/workspaces/{workspace}/projects/{project_id}/estimates/"
            headers = {
                "X-Api-Key": api_key,
                "Content-Type": "application/json",
            }

            logger.debug(f"Fetching estimates from: {url}")
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()
            data = response.json()

            logger.debug(f"Estimates API response: {type(data)}")

            # Convert dict results to SimpleNamespace objects to match SDK behavior
            estimates = []
            if isinstance(data, dict):
                # Check if it's wrapped in 'results' (paginated response)
                if "results" in data:
                    for item in data.get("results", []):
                        estimates.append(SimpleNamespace(**item))
                # Check if it has an 'id' field (single estimate object)
                elif "id" in data:
                    estimates.append(SimpleNamespace(**data))
                # Otherwise treat as a list of estimates
                elif not any(key in data for key in ["detail", "error"]):
                    # It might be a dict of estimates with IDs as keys
                    for key, item in data.items():
                        if isinstance(item, dict):
                            estimates.append(SimpleNamespace(**item))
            elif isinstance(data, list):
                for item in data:
                    if isinstance(item, dict):
                        estimates.append(SimpleNamespace(**item))

            logger.debug(f"Parsed {len(estimates)} estimates")
            return estimates

        except requests.exceptions.Timeout as e:
            logger.warning(f"Timeout fetching estimates: {e}")
            return []
        except requests.exceptions.RequestException as e:
            logger.warning(f"Failed to fetch estimates: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error fetching estimates: {e}")
            return []

    async def fetch_project_members(self, workspace: str, project_id: str) -> list[dict]:
        """Fetch all members of a project.

        Returns a list of dicts with ``id``, ``email``, ``display_name``, and
        optionally ``role`` (integer: 5=Guest, 15=Member, 20=Admin).

        Bot users (email starts with ``bot_user``) are excluded.

        Tries a direct HTTP GET against
        ``/api/v1/workspaces/{slug}/projects/{id}/members/`` first —
        this endpoint returns ``role`` (int) and ``role_slug`` (string).
        Falls back to the SDK call (no role field) when the endpoint responds
        with a non-200 status or is otherwise unavailable.

        Args:
            workspace:  Workspace slug.
            project_id: Project UUID.

        Returns:
            List of member dicts, empty list on failure.
        """
        import httpx

        client = self._require_client
        config = self._require_config

        # ── Primary path: direct HTTP GET (returns role + role_slug) ──
        try:
            url = (
                f"{config.api_url}/api/v1/workspaces/{workspace}"
                f"/projects/{project_id}/members/"
            )
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http:
                response = await http.get(url)

            if response.status_code == 200:
                result = []
                for m in response.json() or []:
                    email = m.get("email") or ""
                    if email.startswith("bot_user"):
                        continue
                    entry: dict = {}
                    mid = m.get("id")
                    if mid:
                        entry["id"] = str(mid)
                    if email:
                        entry["email"] = email
                    display_name = m.get("display_name")
                    if display_name:
                        entry["display_name"] = display_name
                    # Prefer role_slug (string); fall back to integer for older servers
                    role_slug = m.get("role_slug")
                    if role_slug:
                        entry["role"] = role_slug
                    elif m.get("role") is not None:
                        entry["role"] = m["role"]  # integer; write_members_yaml converts to str
                    if entry:
                        result.append(entry)
                has_roles = any("role" in m for m in result)
                logger.debug(
                    f"Fetched {len(result)} project members for {project_id}"
                    f"{' (with role)' if has_roles else ''}"
                )
                return result

            # Non-200 (e.g. 404 on older Plane) → fall through to SDK fallback
            logger.debug(
                f"Direct member fetch returned HTTP {response.status_code} for {project_id}"
                ", falling back to SDK (no role)"
            )
        except Exception as e:
            logger.debug(f"Direct member fetch failed for {project_id} ({e}), falling back to SDK")

        # ── Fallback: SDK call — pre-PR #6865, no role field ──
        try:
            members = await client.call(
                client.sdk.projects.get_members,
                workspace_slug=workspace,
                project_id=project_id,
            )
            result = []
            for m in members or []:
                email = getattr(m, "email", None) or ""
                if email.startswith("bot_user"):
                    continue
                entry = {}
                mid = getattr(m, "id", None)
                if mid:
                    entry["id"] = str(mid)
                if email:
                    entry["email"] = email
                display_name = getattr(m, "display_name", None)
                if display_name:
                    entry["display_name"] = display_name
                if entry:
                    result.append(entry)
            logger.debug(f"Fetched {len(result)} project members for {project_id} (SDK, no role)")
            return result
        except Exception as e:
            logger.warning(f"Could not fetch project members for {project_id}: {e}")
            return []

    async def add_project_member(
        self, workspace: str, project_id: str, member_id: str, role: int = 15
    ) -> bool:
        """Add a member to the project.

        Uses a direct HTTP POST since the SDK does not expose this operation.
        Endpoint: POST /api/v1/workspaces/{slug}/projects/{project_id}/project-members/
        Body: ``{"member": "<uuid>", "role": 15}``

        Role values: 5 = Guest, 15 = Member, 20 = Admin.

        Args:
            workspace:  Workspace slug.
            project_id: Project UUID.
            member_id:  Workspace member UUID to add.
            role:       Role to assign (default 15 = Member).

        Returns:
            True if added (201), False on error.
        """
        import httpx

        client = self._require_client
        config = self._require_config
        url = (
            f"{config.api_url}/api/v1/workspaces/{workspace}/projects/{project_id}/project-members/"
        )
        payload = {"member": member_id, "role": role}

        try:
            async with httpx.AsyncClient(headers={"X-Api-Key": client._api_key}) as http:
                response = await http.post(url, json=payload)
            if response.status_code in (200, 201):
                logger.info(f"Added member {member_id} to project {project_id}")
                return True
            # Parse the error body to give a useful log message
            try:
                err_body = response.json()
            except Exception:
                err_body = {"error": response.text}
            err_str = str(err_body).lower()
            # Treat "already a member" responses as a no-op success
            if "already" in err_str:
                logger.debug(f"Member {member_id} already in project {project_id}")
                return True
            logger.warning(
                f"Failed to add member {member_id} to project {project_id}: "
                f"HTTP {response.status_code} — {err_body}"
            )
            return False
        except Exception as e:
            logger.warning(f"Error adding member {member_id} to project {project_id}: {e}")
            return False

    async def list_module_work_items_raw(
        self, workspace: str, project_id: str, module_id: str
    ) -> list:
        """List work items belonging to a module."""
        client = self._require_client
        try:
            response = await client.call(
                client.sdk.modules.list_work_items,
                workspace_slug=workspace,
                project_id=project_id,
                module_id=module_id,
            )
            return _get_results(response)
        except (APIError, NetworkError) as e:
            logger.warning(f"Failed to fetch work items for module {module_id}: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error fetching module work items: {e}")
            return []
