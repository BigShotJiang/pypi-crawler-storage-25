"""Plane CLI - Scaffold and sync projects with Plane."""
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("plane-compose")
except PackageNotFoundError:
    __version__ = "0.0.0"
