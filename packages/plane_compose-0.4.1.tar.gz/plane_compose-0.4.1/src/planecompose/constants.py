"""Shared constants for planecompose.

This module centralizes commonly used string constants to:
- Prevent typos in directory/file names
- Make refactoring easier
- Provide a single source of truth for project structure
"""

# Project structure directories
DIR_SCHEMA = "schema"
DIR_WORK = "work"
DIR_PLANE = ".plane"
DIR_REMOTE = "remote"

# Configuration files
FILE_PLANE_YAML = "plane.yaml"
FILE_STATE_JSON = "state.json"
FILE_TYPES_YAML = "types.yaml"
FILE_WORKFLOWS_YAML = "workflows.yaml"
FILE_STATES_YAML = "states.yaml"
FILE_LABELS_YAML = "labels.yaml"

# Default values
DEFAULT_COLOR = "#858585"
DEFAULT_WORKFLOW = "default"
DEFAULT_TYPE = "Story"
DEFAULT_API_URL = "https://api.plane.so"

# Valid relation types for FieldDefinition
VALID_RELATION_TYPES = ("user", "issue")

# Valid state groups (from Plane API)
VALID_STATE_GROUPS = (
    "backlog", "unstarted", "started", "completed", "cancelled", "triage",
)

# State groups (from Plane API)
# Note: triage is a fixed system state managed by Plane
STATE_GROUP_BACKLOG = "backlog"
STATE_GROUP_UNSTARTED = "unstarted"
STATE_GROUP_STARTED = "started"
STATE_GROUP_COMPLETED = "completed"
STATE_GROUP_CANCELLED = "cancelled"
STATE_GROUP_TRIAGE = "triage"  # Fixed system state - cannot be created/modified

# Display limits
MAX_ERROR_DISPLAY_COUNT = 5
ERROR_MESSAGE_MAX_CHARS = 80
