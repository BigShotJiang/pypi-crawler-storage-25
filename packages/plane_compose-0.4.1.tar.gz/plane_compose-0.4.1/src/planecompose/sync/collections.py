"""Collection membership helpers — fetch cycle/module work item maps.

Centralises the async loops that were copy-pasted across clone.py and
pull.py (4 near-identical copies).  Each helper accepts a pre-built
id_to_sequence map (UUID → "PROJ-42") so callers own that computation
and we stay free of any project-key or context coupling.
"""

from planecompose.utils.logger import get_logger

logger = get_logger()


async def fetch_cycle_items_map(
    backend,
    workspace: str,
    project_uuid: str,
    cycles_list: list,
    id_to_sequence: dict[str, str],
) -> dict[str, list[str]]:
    """Build a cycle_id → [sequence_id, ...] map by fetching each cycle's items.

    Args:
        backend:        PlaneBackend instance (provides list_cycle_work_items_raw).
        workspace:      Workspace slug.
        project_uuid:   Project UUID.
        cycles_list:    List of cycle objects (must have an ``id`` attribute).
        id_to_sequence: Pre-built {work_item_uuid: "PROJ-42"} map.

    Returns:
        Dict of ``{cycle_uuid: ["PROJ-1", "PROJ-2", ...]}``.
        Cycles with no matching work items get an empty list.
    """
    cycle_items_map: dict[str, list[str]] = {}

    for cycle in cycles_list:
        cycle_id = str(getattr(cycle, "id", "") or "")
        if not cycle_id:
            continue
        try:
            raw_items = await backend.list_cycle_work_items_raw(workspace, project_uuid, cycle_id)
            cycle_items_map[cycle_id] = [
                id_to_sequence[str(getattr(ci, "id", "") or "")]
                for ci in raw_items
                if str(getattr(ci, "id", "") or "") in id_to_sequence
            ]
        except Exception as e:
            logger.warning(f"Could not fetch items for cycle {cycle_id}: {e}")
            cycle_items_map[cycle_id] = []

    return cycle_items_map


async def fetch_module_items_map(
    backend,
    workspace: str,
    project_uuid: str,
    modules_list: list,
    id_to_sequence: dict[str, str],
) -> dict[str, list[str]]:
    """Build a module_id → [sequence_id, ...] map by fetching each module's items.

    Args:
        backend:        PlaneBackend instance (provides list_module_work_items_raw).
        workspace:      Workspace slug.
        project_uuid:   Project UUID.
        modules_list:   List of module objects (must have an ``id`` attribute).
        id_to_sequence: Pre-built {work_item_uuid: "PROJ-42"} map.

    Returns:
        Dict of ``{module_uuid: ["PROJ-1", "PROJ-2", ...]}``.
        Modules with no matching work items get an empty list.
    """
    module_items_map: dict[str, list[str]] = {}

    for module in modules_list:
        module_id = str(getattr(module, "id", "") or "")
        if not module_id:
            continue
        try:
            raw_items = await backend.list_module_work_items_raw(workspace, project_uuid, module_id)
            module_items_map[module_id] = [
                id_to_sequence[str(getattr(mi, "id", "") or "")]
                for mi in raw_items
                if str(getattr(mi, "id", "") or "") in id_to_sequence
            ]
        except Exception as e:
            logger.warning(f"Could not fetch items for module {module_id}: {e}")
            module_items_map[module_id] = []

    return module_items_map
