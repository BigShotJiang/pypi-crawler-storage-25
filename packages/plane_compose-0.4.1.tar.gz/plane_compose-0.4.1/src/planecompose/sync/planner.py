"""Sync planner for calculating what needs to be synced.

This module extracts change detection logic from CLI commands,
enabling reuse and proper testing.

Usage:
    planner = SyncPlanner()
    plan = planner.plan_push(local_items, current_state)

    # Inspect the plan
    print(f"{len(plan.creates)} items to create")
    print(f"{len(plan.updates)} items to update")

    # Execute with SyncExecutor
    executor = SyncExecutor(backend)
    result = await executor.execute(plan)
"""
from dataclasses import dataclass, field
from enum import Enum
from typing import Iterator

from planecompose.core.models import WorkItem, SyncState
from planecompose.parser.work_yaml import WorkItemWithMeta
from planecompose.utils.work_items import (
    get_tracking_key,
    calculate_content_hash,
    is_remote_snapshot_source,
    parse_source,
    CONTENT_HASH_VERSION,
)
from planecompose.utils.logger import get_logger

logger = get_logger()


@dataclass
class ConflictItem:
    """A detected conflict where remote has diverged from last known state.

    This means someone changed the work item in the Plane UI (or via API)
    since the last sync, and the local push would overwrite those changes.
    """
    tracking_key: str
    item_title: str
    local_hash: str
    state_hash: str
    remote_hash: str


class SyncAction(Enum):
    """Type of sync action to perform."""
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"
    SKIP = "skip"


@dataclass
class SyncItem:
    """A single item to sync."""
    action: SyncAction
    item: WorkItem
    tracking_key: str
    source_file: str
    index: int
    remote_id: str | None = None  # Set for UPDATE/DELETE actions
    reason: str = ""  # Why this action was chosen


@dataclass
class SyncPlan:
    """
    Plan for a sync operation.

    Contains lists of items to create, update, and optionally delete.
    Does NOT execute anything - that's SyncExecutor's job.
    """
    creates: list[SyncItem] = field(default_factory=list)
    updates: list[SyncItem] = field(default_factory=list)
    deletes: list[SyncItem] = field(default_factory=list)
    skipped: list[SyncItem] = field(default_factory=list)

    @property
    def total_changes(self) -> int:
        """Total number of changes (creates + updates + deletes)."""
        return len(self.creates) + len(self.updates) + len(self.deletes)

    @property
    def is_empty(self) -> bool:
        """Check if plan has no changes."""
        return self.total_changes == 0

    def all_items(self) -> Iterator[SyncItem]:
        """Iterate over all items in order: creates, updates, deletes."""
        yield from self.creates
        yield from self.updates
        yield from self.deletes

    def summary(self) -> dict:
        """Get a summary of the plan."""
        return {
            'creates': len(self.creates),
            'updates': len(self.updates),
            'deletes': len(self.deletes),
            'skipped': len(self.skipped),
            'total_changes': self.total_changes,
        }


class SyncPlanner:
    """
    Plans sync operations by comparing local items with remote state.

    This class is stateless - it just compares and generates plans.
    It does not execute any operations or modify state.
    """

    def plan_push(
        self,
        local_items: list[WorkItemWithMeta],
        state: SyncState,
    ) -> SyncPlan:
        """
        Plan a push operation (additive mode).

        In push mode:
        - New items are created
        - Changed items are updated
        - Items not in local are NOT deleted (additive/collaborative)

        Args:
            local_items: Work items from YAML files
            state: Current sync state

        Returns:
            SyncPlan with creates and updates (no deletes in push mode)
        """
        plan = SyncPlan()
        seen_keys: set[str] = set()

        for item_meta in local_items:
            item = item_meta.item
            tracking_key = get_tracking_key(item, item_meta.source_file, item_meta.index)
            source_file = str(item_meta.source_file)

            if tracking_key in seen_keys:
                logger.warning(
                    "Duplicate tracking key '%s' in %s (index %d) - skipping",
                    tracking_key, source_file, item_meta.index,
                )
                plan.skipped.append(SyncItem(
                    action=SyncAction.SKIP,
                    item=item,
                    tracking_key=tracking_key,
                    source_file=source_file,
                    index=item_meta.index,
                    reason="duplicate tracking key",
                ))
                continue
            seen_keys.add(tracking_key)

            if tracking_key in state.work_items:
                # Item exists in state - check if changed
                item_state = state.work_items[tracking_key]
                current_hash = calculate_content_hash(item)

                # Detect stale hash version: if the state was saved with an
                # older hash algorithm, the hashes will always differ. Treat
                # as "changed" so the item gets re-pushed and the state is
                # updated with the current hash version.
                hash_stale = getattr(item_state, 'hash_version', 1) != CONTENT_HASH_VERSION

                if hash_stale or current_hash != item_state.content_hash:
                    reason = "hash version upgraded" if hash_stale else "content changed"
                    plan.updates.append(SyncItem(
                        action=SyncAction.UPDATE,
                        item=item,
                        tracking_key=tracking_key,
                        source_file=source_file,
                        index=item_meta.index,
                        remote_id=item_state.remote_id,
                        reason=reason,
                    ))
                else:
                    # No change - skip
                    plan.skipped.append(SyncItem(
                        action=SyncAction.SKIP,
                        item=item,
                        tracking_key=tracking_key,
                        source_file=source_file,
                        index=item_meta.index,
                        remote_id=item_state.remote_id,
                        reason="already synced, no changes",
                    ))
            else:
                # New item
                plan.creates.append(SyncItem(
                    action=SyncAction.CREATE,
                    item=item,
                    tracking_key=tracking_key,
                    source_file=source_file,
                    index=item_meta.index,
                    reason="new item",
                ))

        logger.debug(
            f"Planned push: {len(plan.creates)} creates, "
            f"{len(plan.updates)} updates, {len(plan.skipped)} skipped"
        )
        return plan

    def detect_conflicts(
        self,
        plan: SyncPlan,
        state: SyncState,
        remote_items: dict[str, WorkItem],
    ) -> list[ConflictItem]:
        """
        Detect conflicts between local updates and remote changes.

        For each item in the plan's update list, checks whether the remote
        version has changed since the last sync by comparing content hashes.
        If the remote hash differs from the state hash, someone modified the
        item externally (e.g., in the Plane UI) and pushing would overwrite
        those changes.

        Args:
            plan: The sync plan containing updates to check
            state: Current sync state with last-known content hashes
            remote_items: Dict mapping remote_id -> WorkItem fetched from Plane

        Returns:
            List of ConflictItem for each detected conflict
        """
        conflicts: list[ConflictItem] = []

        for sync_item in plan.updates:
            if not sync_item.remote_id:
                continue

            # Look up the remote item by its remote_id
            remote_item = remote_items.get(sync_item.remote_id)
            if remote_item is None:
                # Remote item not found (maybe deleted remotely); not a conflict
                continue

            # Get the state hash (what we last synced)
            item_state = state.work_items.get(sync_item.tracking_key)
            if item_state is None:
                continue
            if getattr(item_state, "hash_version", 1) != CONTENT_HASH_VERSION:
                logger.warning(
                    "Conflict detection skipped for '%s': state hash uses version %s "
                    "(current: %s). Remote changes may be overwritten. "
                    "Re-import to update hash versions.",
                    sync_item.tracking_key,
                    getattr(item_state, "hash_version", 1),
                    CONTENT_HASH_VERSION,
                )
                continue

            state_hash = item_state.content_hash
            remote_hash = calculate_content_hash(remote_item)
            local_hash = calculate_content_hash(sync_item.item)

            # Conflict: remote has changed since last sync
            if remote_hash != state_hash:
                conflicts.append(ConflictItem(
                    tracking_key=sync_item.tracking_key,
                    item_title=sync_item.item.title,
                    local_hash=local_hash,
                    state_hash=state_hash,
                    remote_hash=remote_hash,
                ))

        if conflicts:
            logger.warning(
                f"Detected {len(conflicts)} conflict(s): remote items "
                f"changed since last sync"
            )

        return conflicts

    def plan_apply(
        self,
        local_items: list[WorkItemWithMeta],
        state: SyncState,
        scope: str | None = None,
    ) -> SyncPlan:
        """
        Plan an apply operation (declarative mode).

        In apply mode:
        - New items are created
        - Changed items are updated
        - Items not in local ARE deleted (declarative)
        - Scope limits which items can be deleted

        Args:
            local_items: Work items from YAML files
            state: Current sync state
            scope: Optional scope pattern to limit deletions (e.g., "work/inbox.yaml")

        Returns:
            SyncPlan with creates, updates, and deletes
        """
        plan = self.plan_push(local_items, state)

        # Find items to delete (in state but not in local)
        local_keys = {
            get_tracking_key(item.item, item.source_file, item.index)
            for item in local_items
        }

        for tracking_key, item_state in state.work_items.items():
            if is_remote_snapshot_source(item_state.source):
                continue

            if tracking_key not in local_keys:
                # Check scope
                if scope and not item_state.source.startswith(scope):
                    continue  # Out of scope, don't delete

                # Item should be deleted
                source_file, source_index = parse_source(item_state.source)
                plan.deletes.append(SyncItem(
                    action=SyncAction.DELETE,
                    item=WorkItem(title=f"[tracked: {tracking_key}]", type="unknown"),
                    tracking_key=tracking_key,
                    source_file=source_file,
                    index=source_index,
                    remote_id=item_state.remote_id,
                    reason="not in local YAML files",
                ))

        logger.debug(
            f"Planned apply: {len(plan.creates)} creates, "
            f"{len(plan.updates)} updates, {len(plan.deletes)} deletes"
        )
        return plan

    def plan_pull(
        self,
        remote_items: list[WorkItem],
        state: SyncState,
    ) -> SyncPlan:
        """
        Plan a pull operation.

        Determines which remote items are new or changed compared to local state.

        Args:
            remote_items: Work items from remote (Plane)
            state: Current sync state

        Returns:
            SyncPlan indicating what would be pulled
        """
        plan = SyncPlan()

        for item in remote_items:
            # Use namespaced tracking key for remote items
            tracking_key = f"id:{item.id}" if item.id else f"hash:{calculate_content_hash(item)}"

            if tracking_key in state.work_items:
                item_state = state.work_items[tracking_key]
                current_hash = calculate_content_hash(item)

                if current_hash != item_state.content_hash:
                    plan.updates.append(SyncItem(
                        action=SyncAction.UPDATE,
                        item=item,
                        tracking_key=tracking_key,
                        source_file="remote",
                        index=0,
                        remote_id=item_state.remote_id,
                        reason="remote changed",
                    ))
                else:
                    plan.skipped.append(SyncItem(
                        action=SyncAction.SKIP,
                        item=item,
                        tracking_key=tracking_key,
                        source_file="remote",
                        index=0,
                        reason="no changes",
                    ))
            else:
                plan.creates.append(SyncItem(
                    action=SyncAction.CREATE,
                    item=item,
                    tracking_key=tracking_key,
                    source_file="remote",
                    index=0,
                    reason="new remote item",
                ))

        return plan
