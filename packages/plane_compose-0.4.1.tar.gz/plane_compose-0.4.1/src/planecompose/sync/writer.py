"""Writers for converting remote data to local YAML files.

This module handles the conversion of remote data (from Plane API)
to clean YAML format for local storage.

Usage:
    writer = PullWriter(project_root)
    writer.write_schema(types, states, labels)
    writer.write_work_items(items, output_path, properties)
"""
from typing import Any

import yaml
from pathlib import Path
from dataclasses import dataclass

from planecompose.core.models import (
    WorkItem,
    WorkItemTypeDefinition,
    StateDefinition,
    LabelDefinition,
    WorkflowDefinition,
)
from planecompose.utils.logger import get_logger

logger = get_logger()


@dataclass
class PullResult:
    """Result of a pull operation."""
    schema_written: bool = False
    types_count: int = 0
    states_count: int = 0
    labels_count: int = 0
    work_items_count: int = 0
    properties_fetched: bool = False
    output_file: str = ""


class PullWriter:
    """
    Writes pulled data to local YAML files.

    Handles:
    - Schema files (types.yaml, workflows.yaml, labels.yaml)
    - Work items file (configurable output path)
    - Clean YAML formatting
    """

    def __init__(self, root_path: Path):
        """
        Initialize writer.

        Args:
            root_path: Project root directory
        """
        self.root_path = root_path
        self.schema_dir = root_path / "schema"

    def write_schema(
        self,
        types: list[WorkItemTypeDefinition],
        states: list[StateDefinition],
        labels: list[LabelDefinition],
        workflows: list[WorkflowDefinition] | None = None,
    ) -> None:
        """
        Write schema files to schema/ directory.

        Args:
            types: Work item types from remote
            states: States from remote
            labels: Labels from remote
            workflows: Workflows from remote (optional)
        """
        self.schema_dir.mkdir(exist_ok=True)

        self._write_types(types)
        self._write_states(states)
        if workflows:
            self._write_workflows(workflows)
        self._write_labels(labels)

        logger.debug(
            f"Wrote schema: {len(types)} types, "
            f"{len(states)} states, {len(labels)} labels, "
            f"{len(workflows) if workflows else 0} workflows"
        )

    def _write_types(self, types: list[WorkItemTypeDefinition]) -> None:
        """Write types.yaml — delegates to the canonical common writer."""
        from planecompose.parser.schema_writer import write_types_yaml
        write_types_yaml(self.schema_dir / "types.yaml", types)

    def _write_states(self, states: list[StateDefinition]) -> None:
        """Write states.yaml — delegates to the canonical common writer."""
        from planecompose.parser.schema_writer import write_states_yaml
        write_states_yaml(self.schema_dir / "states.yaml", states)

    def _write_workflows(self, workflows: list[WorkflowDefinition]) -> None:
        """Write workflows.yaml — delegates to the canonical common writer."""
        from planecompose.parser.schema_writer import write_workflows_yaml
        write_workflows_yaml(self.schema_dir / "workflows.yaml", workflows)

    def _write_labels(self, labels: list[LabelDefinition]) -> None:
        """Write labels.yaml — delegates to the canonical common writer."""
        from planecompose.parser.schema_writer import write_labels_yaml
        write_labels_yaml(self.schema_dir / "labels.yaml", labels)

    def write_work_items(
        self,
        items: list[WorkItem],
        output_path: str | Path,
        properties: dict[str, dict] | None = None,
        raw_items: list | None = None,
        merge_existing: bool = False,
    ) -> int:
        """
        Write work items to YAML file.

        Args:
            items: Work items to write
            output_path: Output file path (relative to root or absolute)
            properties: Optional dict of item_uuid -> properties dict
            raw_items: Raw SDK items (for UUID lookup when properties provided)
            merge_existing: If True, merge with existing items in file

        Returns:
            Number of items written
        """
        output_file = self.root_path / output_path if not Path(output_path).is_absolute() else Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)

        items_to_write = []

        # Load existing if merging
        if merge_existing and output_file.exists():
            existing = self._load_yaml(output_file)
            if existing and isinstance(existing, list):
                items_to_write.extend(existing)

        # Convert items to dicts
        for idx, item in enumerate(items):
            item_dict = self._work_item_to_dict(item)

            # Add properties if available
            if properties and raw_items and idx < len(raw_items):
                raw_item = raw_items[idx]
                if hasattr(raw_item, 'id'):
                    item_uuid = str(raw_item.id)
                    if item_uuid in properties and properties[item_uuid]:
                        item_dict['properties'] = properties[item_uuid]

            items_to_write.append(item_dict)

        self._write_yaml(output_file, items_to_write)
        logger.debug(f"Wrote {len(items)} work items to {output_path}")

        return len(items)

    def _work_item_to_dict(self, item: WorkItem) -> dict:
        """Convert WorkItem to clean dict for YAML output."""
        # Start with required fields, id first if present
        item_dict: dict[str, Any] = {}

        if item.id:
            item_dict['id'] = item.id

        item_dict['title'] = item.title
        item_dict['type'] = item.type

        # Add optional fields only if present
        if item.description:
            item_dict['description'] = item.description
        if item.state:
            item_dict['state'] = item.state
        if item.priority:
            item_dict['priority'] = item.priority
        if item.labels:
            item_dict['labels'] = item.labels

        # Dates
        if item.start_date:
            item_dict['start_date'] = item.start_date
        if item.due_date:
            item_dict['due_date'] = item.due_date

        # Assignments
        if item.assignees:
            item_dict['assignees'] = item.assignees
        if hasattr(item, 'watchers') and item.watchers:
            item_dict['watchers'] = item.watchers

        # Relationships
        if item.parent:
            item_dict['parent'] = item.parent
        if item.blocked_by:
            item_dict['blocked_by'] = item.blocked_by
        if item.blocking:
            item_dict['blocking'] = item.blocking
        if item.duplicate_of:
            item_dict['duplicate_of'] = item.duplicate_of
        if item.relates_to:
            item_dict['relates_to'] = item.relates_to

        return item_dict

    def write_work_items_canonical(
        self,
        items: list[WorkItem],
        properties: dict[str, dict] | None = None,
        raw_items: list | None = None,
    ) -> int:
        """Write work items to work/workitems.yaml in the canonical format.

        Uses the `workitems:` root key format with a user-facing header comment.
        Items pulled from remote always have an `id:` (sequence ID like P103-1).

        Returns:
            Number of items written
        """
        output_file = self.root_path / "work" / "workitems.yaml"
        output_file.parent.mkdir(parents=True, exist_ok=True)

        items_list = []
        for idx, item in enumerate(items):
            item_dict = self._work_item_to_dict(item)
            if properties and raw_items and idx < len(raw_items):
                raw_item = raw_items[idx]
                if hasattr(raw_item, "id"):
                    item_uuid = str(raw_item.id)
                    if item_uuid in properties and properties[item_uuid]:
                        item_dict["properties"] = properties[item_uuid]
            items_list.append(item_dict)

        header = (
            "# Work items — edit and run 'plane push' to sync changes to Plane.\n"
            "# Items with 'id:' are tracked (PATCH on next push if changed).\n"
            "# New items without 'id:' will be created (POST) and id written back.\n"
        )
        self._write_yaml(output_file, {"workitems": items_list}, header=header)
        logger.debug(f"Wrote {len(items)} work items to work/workitems.yaml")
        return len(items)

    def _write_yaml(self, path: Path, data, header: str = "") -> None:
        """Write data to YAML file with clean formatting and optional header comments."""
        with open(path, 'w') as f:
            if header:
                f.write(header)
                f.write("\n")
            yaml.dump(
                data,
                f,
                default_flow_style=False,
                sort_keys=False,
                allow_unicode=True,
            )

    def _load_yaml(self, path: Path):
        """Load YAML file."""
        with open(path, 'r') as f:
            return yaml.safe_load(f)
