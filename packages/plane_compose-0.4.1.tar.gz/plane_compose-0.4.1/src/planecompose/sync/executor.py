"""Sync executor for executing sync plans with parallel batch processing.

This module handles the actual execution of sync operations:
- Creates work items in Plane
- Updates existing work items
- Tracks state changes
- Provides progress callbacks

Key improvement: Uses asyncio.gather for parallel batch processing,
making syncs significantly faster than sequential processing.

Usage:
    executor = SyncExecutor(backend, state_manager)
    result = await executor.execute(plan, progress_callback=on_progress)
"""
import asyncio
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable, Awaitable

from planecompose.backend.base import Backend
from planecompose.core.models import WorkItemState
from planecompose.state.manager import StateManager
from planecompose.sync.planner import SyncPlan, SyncItem
from planecompose.utils.work_items import calculate_content_hash, CONTENT_HASH_VERSION
from planecompose.utils.logger import get_logger

logger = get_logger()

# Default batch size for parallel processing
DEFAULT_BATCH_SIZE = 5


@dataclass
class SyncItemResult:
    """Result of syncing a single item."""
    item: SyncItem
    success: bool
    remote_id: str | None = None
    error: str | None = None
    error_type: str | None = None  # e.g., "ValidationError", "APIError"
    sequence_id: int | None = None  # Plane sequence number (e.g., 123 for PROJ-123)


@dataclass
class SyncResult:
    """Result of a sync operation."""
    created: list[SyncItemResult] = field(default_factory=list)
    updated: list[SyncItemResult] = field(default_factory=list)
    deleted: list[SyncItemResult] = field(default_factory=list)
    failed: list[SyncItemResult] = field(default_factory=list)
    elapsed_time: float = 0.0

    @property
    def created_count(self) -> int:
        return len([r for r in self.created if r.success])

    @property
    def updated_count(self) -> int:
        return len([r for r in self.updated if r.success])

    @property
    def deleted_count(self) -> int:
        return len([r for r in self.deleted if r.success])

    @property
    def failed_count(self) -> int:
        return len(self.failed)

    @property
    def total_processed(self) -> int:
        # Include failed items - they were processed (attempted), just didn't succeed
        return len(self.created) + len(self.updated) + len(self.deleted) + len(self.failed)

    def summary(self) -> dict:
        """Get a summary of the sync result."""
        return {
            'created': self.created_count,
            'updated': self.updated_count,
            'deleted': self.deleted_count,
            'failed': self.failed_count,
            'total_processed': self.total_processed,
            'elapsed_time': f"{self.elapsed_time:.1f}s",
        }


# Type alias for progress callback
ProgressCallback = Callable[[int, int, str], Awaitable[None] | None]


class SyncExecutor:
    """
    Executes sync plans with parallel batch processing.

    Key features:
    - Parallel processing within batches (5x faster than sequential)
    - Automatic state updates with locking
    - Progress callbacks for UI feedback
    - Error handling per-item (doesn't fail entire batch)
    """

    def __init__(
        self,
        backend: Backend,
        state_manager: StateManager | None = None,
        batch_size: int = DEFAULT_BATCH_SIZE,
        max_concurrency: int = DEFAULT_BATCH_SIZE,
    ):
        """
        Initialize executor.

        Args:
            backend: Backend for API calls
            state_manager: Optional state manager (if None, state not updated)
            batch_size: Number of items to process in parallel
            max_concurrency: Maximum concurrent API calls (prevents rate limiter overload)
        """
        self.backend = backend
        self.state_manager = state_manager
        self.batch_size = batch_size
        self._semaphore = asyncio.Semaphore(max_concurrency)

    async def execute(
        self,
        plan: SyncPlan,
        progress_callback: ProgressCallback | None = None,
        dry_run: bool = False,
    ) -> SyncResult:
        """
        Execute a sync plan.

        Args:
            plan: The sync plan to execute
            progress_callback: Optional callback for progress updates
            dry_run: If True, don't actually execute (just return empty result)

        Returns:
            SyncResult with details of what was synced
        """
        import time
        start_time = time.time()

        if dry_run:
            return SyncResult(elapsed_time=0.0)

        result = SyncResult()
        total_items = plan.total_changes
        processed = 0

        # Process creates in parallel batches
        for batch_result in await self._process_batches(
            plan.creates,
            self._create_item,
            progress_callback,
            processed,
            total_items,
        ):
            if batch_result.success:
                result.created.append(batch_result)
            else:
                result.failed.append(batch_result)
            processed += 1

        # Process updates in parallel batches
        for batch_result in await self._process_batches(
            plan.updates,
            self._update_item,
            progress_callback,
            processed,
            total_items,
        ):
            if batch_result.success:
                result.updated.append(batch_result)
            else:
                result.failed.append(batch_result)
            processed += 1

        # Process deletes in parallel batches (if any)
        for batch_result in await self._process_batches(
            plan.deletes,
            self._delete_item,
            progress_callback,
            processed,
            total_items,
        ):
            if batch_result.success:
                result.deleted.append(batch_result)
            else:
                result.failed.append(batch_result)
            processed += 1

        result.elapsed_time = time.time() - start_time

        logger.info(
            f"Sync completed: {result.created_count} created, "
            f"{result.updated_count} updated, {result.deleted_count} deleted, "
            f"{result.failed_count} failed in {result.elapsed_time:.1f}s"
        )

        return result

    async def _process_batches(
        self,
        items: list[SyncItem],
        processor: Callable[[SyncItem], Awaitable[SyncItemResult]],
        progress_callback: ProgressCallback | None,
        start_index: int,
        total: int,
    ) -> list[SyncItemResult]:
        """
        Process items in parallel batches.

        This is the KEY performance optimization - items within a batch
        are processed concurrently using asyncio.gather().
        A semaphore prevents overwhelming the API with too many concurrent calls.
        """
        results = []

        async def _guarded(item: SyncItem) -> SyncItemResult:
            async with self._semaphore:
                return await processor(item)

        for i in range(0, len(items), self.batch_size):
            batch = items[i:i + self.batch_size]

            # Process batch items in parallel (semaphore-guarded)
            batch_results = await asyncio.gather(
                *[_guarded(item) for item in batch],
                return_exceptions=True,
            )

            # Handle results
            for j, batch_result in enumerate(batch_results):
                if isinstance(batch_result, BaseException):
                    # Convert exception to failed result, preserving error type
                    results.append(SyncItemResult(
                        item=batch[j],
                        success=False,
                        error=str(batch_result),
                        error_type=type(batch_result).__name__,
                    ))
                else:
                    # batch_result is SyncItemResult
                    results.append(batch_result)

                # Update progress
                if progress_callback:
                    current = start_index + len(results)
                    item_title = batch[j].item.title[:30] if batch[j].item.title else "item"
                    callback_result = progress_callback(current, total, item_title)
                    if asyncio.iscoroutine(callback_result):
                        await callback_result

        return results

    async def _create_item(self, sync_item: SyncItem) -> SyncItemResult:
        """Create a single work item."""
        try:
            remote_id = await self.backend.create_work_item(sync_item.item)

            # Store remote_id for later batch state update
            if self.state_manager:
                sync_item.remote_id = remote_id

            # Extract sequence_id if backend tracks it (e.g., PlaneBackend)
            sequence_id = None
            get_seq = getattr(self.backend, 'get_sequence_id', None)
            if get_seq and remote_id:
                sequence_id = get_seq(remote_id)

            logger.debug(f"Created work item: {sync_item.item.title[:50]}")
            return SyncItemResult(
                item=sync_item,
                success=True,
                remote_id=remote_id,
                sequence_id=sequence_id,
            )

        except Exception as e:
            logger.error(f"Failed to create '{sync_item.item.title}': {e}")
            return SyncItemResult(
                item=sync_item,
                success=False,
                error=str(e),
                error_type=type(e).__name__,
            )

    async def _update_item(self, sync_item: SyncItem) -> SyncItemResult:
        """Update a single work item."""
        try:
            if sync_item.remote_id is None:
                raise RuntimeError(
                    f"Cannot update '{sync_item.item.title}': remote_id is missing"
                )
            await self.backend.update_work_item(sync_item.remote_id, sync_item.item)

            logger.debug(f"Updated work item: {sync_item.item.title[:50]}")
            return SyncItemResult(
                item=sync_item,
                success=True,
                remote_id=sync_item.remote_id,
            )

        except Exception as e:
            logger.error(f"Failed to update '{sync_item.item.title}': {e}")
            return SyncItemResult(
                item=sync_item,
                success=False,
                error=str(e),
                error_type=type(e).__name__,
            )

    async def _delete_item(self, sync_item: SyncItem) -> SyncItemResult:
        """Delete a single work item from Plane.

        Note: State removal is batched in update_state_batch() rather than
        per-item to minimize lock acquisitions.
        """
        try:
            if sync_item.remote_id is None:
                raise RuntimeError(
                    f"Cannot delete '{sync_item.tracking_key}': remote_id is missing"
                )
            await self.backend.delete_work_item(sync_item.remote_id)

            logger.debug(f"Deleted work item: {sync_item.tracking_key}")
            return SyncItemResult(
                item=sync_item,
                success=True,
                remote_id=sync_item.remote_id,
            )

        except Exception as e:
            logger.error(f"Failed to delete '{sync_item.tracking_key}': {e}")
            return SyncItemResult(
                item=sync_item,
                success=False,
                error=str(e),
                error_type=type(e).__name__,
            )

    async def update_state_batch(self, result: SyncResult) -> None:
        """
        Update state for all successful operations in a single lock.

        Call this after execute() to batch state updates efficiently.
        Handles creates, updates, AND deletes in one transaction.
        """
        if not self.state_manager:
            return

        updates = []

        # Collect all successful creates and updates
        for item_result in result.created + result.updated:
            if item_result.success and item_result.remote_id:
                sync_item = item_result.item
                updates.append((
                    sync_item.tracking_key,
                    WorkItemState(
                        remote_id=item_result.remote_id,
                        content_hash=calculate_content_hash(sync_item.item),
                        source=f"{sync_item.source_file}:{sync_item.index}",
                        last_synced=datetime.now(timezone.utc).isoformat(),
                        hash_version=CONTENT_HASH_VERSION,
                    ),
                ))

        # Collect successful deletes for batch removal
        delete_keys = [
            item_result.item.tracking_key
            for item_result in result.deleted
            if item_result.success
        ]

        if updates:
            self.state_manager.update_work_items_batch(updates)
            logger.debug(f"Updated state for {len(updates)} items")

        if delete_keys:
            removed = self.state_manager.remove_work_items_batch(delete_keys)
            logger.debug(f"Removed {removed} deleted items from state")
