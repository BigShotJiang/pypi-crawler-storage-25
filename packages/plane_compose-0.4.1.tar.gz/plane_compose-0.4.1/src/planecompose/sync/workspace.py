"""Bootstrap workspace configuration for new projects.

Encapsulates the fetch-and-write pattern shared by ``init`` and ``clone``:
fetch workspace features + work item types from the API, then write
workspace.yaml into the target directory.

This module is intentionally free of CLI or ProjectContext coupling — it
works purely with raw credentials, a workspace slug, and a filesystem path.
"""

from pathlib import Path

from planecompose.backend.client import PlaneApiClient
from planecompose.backend.workspace_sync import (
    fetch_workspace_features,
    fetch_workspace_members,
    fetch_workspace_work_item_types,
)
from planecompose.utils.project import update_workspace_yaml
from planecompose.utils.logger import get_logger

logger = get_logger()


def bootstrap_workspace_yaml(
    server_url: str,
    api_key: str,
    connection_id: str,
    workspace_slug: str,
    target_dir: Path,
) -> tuple[dict, dict]:
    """Fetch workspace features, WITs, and members and write workspace.yaml.

    Used during project bootstrap (``init``, ``clone``) before a
    ``ProjectContext`` exists.  Errors are swallowed — commands proceed
    without workspace config if the API call fails (e.g. non-Enterprise
    plans, network issues).

    Args:
        server_url:     Base API URL (e.g. ``https://app.plane.so``).
        api_key:        API key for authentication.
        connection_id:  Connection identifier.
        workspace_slug: Workspace slug.
        target_dir:     Directory to write ``workspace.yaml`` into.
                        **Must already exist** before calling this function.

    Returns:
        ``(workspace_features, workspace_wit_dict)`` where
        ``workspace_wit_dict`` is an ``{id: wit_data}`` mapping of
        workspace-level work item types (empty dict if the feature is
        disabled or the fetch failed).
    """
    workspace_features: dict = {}
    workspace_wit_dict: dict = {}

    try:
        client = PlaneApiClient(
            api_url=server_url,
            api_key=api_key,
            connection_id=connection_id,
        )
        workspace_features = fetch_workspace_features(client, workspace_slug)

        if workspace_features and workspace_features.get("work_item_types", False):
            workspace_wit_dict = fetch_workspace_work_item_types(client, workspace_slug)

        # Members are always fetched — not behind a feature flag
        members = fetch_workspace_members(client, workspace_slug)

        if workspace_features:
            update_workspace_yaml(
                target_dir,
                workspace=workspace_slug,
                workspace_features=workspace_features,
                work_item_types=list(workspace_wit_dict.values()) if workspace_wit_dict else None,
                members=members if members else None,
            )
    except Exception as e:
        logger.warning(f"Could not fetch workspace config for {workspace_slug}: {e}")

    return workspace_features, workspace_wit_dict
