"""Schema inheritance resolver.

Resolves `extends` chains for schema inheritance, merging parent and
child type/workflow/label definitions with child-wins semantics.
"""
from pathlib import Path

from planecompose.core.models import (
    WorkItemTypeDefinition,
    WorkflowDefinition,
    LabelDefinition,
)
from planecompose.exceptions import ConfigError
from planecompose.parser.types_yaml import parse_types_yaml
from planecompose.parser.workflows_yaml import parse_workflows_yaml
from planecompose.parser.labels_yaml import parse_labels_yaml
from planecompose.constants import FILE_TYPES_YAML, FILE_WORKFLOWS_YAML, FILE_LABELS_YAML


def resolve_schema_inheritance(
    schema_dir: Path,
    extends_path: str | None,
    _visited: set[Path] | None = None,
) -> tuple[list[WorkItemTypeDefinition], list[WorkflowDefinition], list[LabelDefinition]]:
    """Resolve schema inheritance by merging parent and child definitions.

    Loads parent schema if ``extends_path`` is set, recursively resolves
    the parent's own inheritance, then merges child definitions on top
    with child-wins semantics.

    Args:
        schema_dir: Absolute path to the child schema directory.
        extends_path: Relative path (from schema_dir's parent, i.e. the
            project root) to the parent schema directory, or None.
        _visited: Internal set used to detect circular inheritance.

    Returns:
        Merged (types, workflows, labels) tuple.

    Raises:
        ConfigError: On circular inheritance or missing parent path.
    """
    if _visited is None:
        _visited = set()

    resolved_dir = schema_dir.resolve()

    # Circular dependency check
    if resolved_dir in _visited:
        raise ConfigError(
            f"Circular schema inheritance detected: {resolved_dir} "
            f"already in chain {_visited}"
        )
    _visited.add(resolved_dir)

    # Load parent schema (recursively) if extends is specified
    parent_types: list[WorkItemTypeDefinition] = []
    parent_workflows: list[WorkflowDefinition] = []
    parent_labels: list[LabelDefinition] = []

    if extends_path is not None:
        # Resolve relative to the project root (parent of schema_dir)
        project_root = schema_dir.parent
        project_root_resolved = project_root.resolve()
        parent_schema_dir = (project_root / extends_path).resolve()

        # Prevent path traversal too far outside the project root.
        # Allow paths within the project itself or within the workspace
        # (sibling projects one level up — a common inheritance pattern).
        # Block anything that escapes the workspace parent.
        workspace_root_resolved = project_root_resolved.parent
        within_project = parent_schema_dir.is_relative_to(project_root_resolved)
        within_workspace = parent_schema_dir.is_relative_to(workspace_root_resolved)
        if not (within_project or within_workspace):
            raise ConfigError(
                f"schema.extends path '{extends_path}' escapes the workspace root. "
                "Only paths within the project or its parent workspace directory are allowed."
            )

        if not parent_schema_dir.exists():
            raise ConfigError(
                f"Parent schema directory not found: {parent_schema_dir} "
                f"(extends: {extends_path})"
            )

        # Check if the parent has its own plane.yaml with extends
        parent_project_root = parent_schema_dir.parent
        parent_plane_yaml = parent_project_root / "plane.yaml"
        parent_extends: str | None = None

        if parent_plane_yaml.exists():
            import yaml

            with open(parent_plane_yaml, "r") as f:
                parent_data = yaml.safe_load(f)
            if parent_data:
                parent_schema_data = parent_data.get("schema", {})
                if parent_schema_data:
                    parent_extends = parent_schema_data.get("extends")

        parent_types, parent_workflows, parent_labels = resolve_schema_inheritance(
            parent_schema_dir,
            parent_extends,
            _visited,
        )

    # Load child schema files
    child_types = _load_types_safe(schema_dir / FILE_TYPES_YAML)
    child_workflows = _load_workflows_safe(schema_dir / FILE_WORKFLOWS_YAML)
    child_labels = _load_labels_safe(schema_dir / FILE_LABELS_YAML)

    # Merge: child wins
    merged_types = _merge_types(parent_types, child_types)
    merged_workflows = _merge_workflows(parent_workflows, child_workflows)
    merged_labels = _merge_labels(parent_labels, child_labels)

    return merged_types, merged_workflows, merged_labels


def _load_types_safe(path: Path) -> list[WorkItemTypeDefinition]:
    """Load types from file, returning empty list if file missing."""
    if not path.exists():
        return []
    return parse_types_yaml(path)


def _load_workflows_safe(path: Path) -> list[WorkflowDefinition]:
    """Load workflows from file, returning empty list if file missing."""
    if not path.exists():
        return []
    return parse_workflows_yaml(path)


def _load_labels_safe(path: Path) -> list[LabelDefinition]:
    """Load labels from file, returning empty list if file missing."""
    if not path.exists():
        return []
    return parse_labels_yaml(path)


def _merge_types(
    parent: list[WorkItemTypeDefinition],
    child: list[WorkItemTypeDefinition],
) -> list[WorkItemTypeDefinition]:
    """Merge parent and child type definitions.

    For each parent type: if a child type has the same name
    (case-insensitive), the child version wins with field-level
    deep merge. New child types are appended.
    """
    # Build index of parent types by lowercase name
    merged: dict[str, WorkItemTypeDefinition] = {
        t.name.lower(): t for t in parent
    }

    for child_type in child:
        key = child_type.name.lower()
        if key in merged:
            # Deep merge fields: child fields override parent by field name
            merged[key] = _deep_merge_type(merged[key], child_type)
        else:
            merged[key] = child_type

    return list(merged.values())


def _deep_merge_type(
    parent_type: WorkItemTypeDefinition,
    child_type: WorkItemTypeDefinition,
) -> WorkItemTypeDefinition:
    """Deep merge a child type onto a parent type.

    The child's scalar fields (description, workflow, etc.) replace
    the parent's. Fields (custom properties) are merged by field
    name: child field overrides parent field with the same name.
    """
    # Start with parent fields indexed by name
    merged_fields = {f.name.lower(): f for f in parent_type.fields}

    # Child fields override
    for field in child_type.fields:
        merged_fields[field.name.lower()] = field

    child_fields_set: set[str] = getattr(child_type, "model_fields_set", set())

    return WorkItemTypeDefinition(
        name=child_type.name,
        description=(
            child_type.description
            if "description" in child_fields_set
            else parent_type.description
        ),
        workflow=(
            child_type.workflow
            if "workflow" in child_fields_set
            else parent_type.workflow
        ),
        parent_types=(
            child_type.parent_types
            if "parent_types" in child_fields_set
            else parent_type.parent_types
        ),
        fields=list(merged_fields.values()),
        remote_id=(
            child_type.remote_id
            if "remote_id" in child_fields_set
            else parent_type.remote_id
        ),
        ws_workitemtype_id=(
            child_type.ws_workitemtype_id
            if "ws_workitemtype_id" in child_fields_set
            else parent_type.ws_workitemtype_id
        ),
        logo_props=(
            child_type.logo_props
            if "logo_props" in child_fields_set
            else parent_type.logo_props
        ),
        is_epic=(
            child_type.is_epic
            if "is_epic" in child_fields_set
            else parent_type.is_epic
        ),
        is_default=(
            child_type.is_default
            if "is_default" in child_fields_set
            else parent_type.is_default
        ),
        level=(
            child_type.level
            if "level" in child_fields_set
            else parent_type.level
        ),
    )


def _merge_workflows(
    parent: list[WorkflowDefinition],
    child: list[WorkflowDefinition],
) -> list[WorkflowDefinition]:
    """Merge parent and child workflow definitions.

    Child workflow replaces parent workflow entirely by name
    (case-insensitive). New child workflows are appended.
    """
    merged: dict[str, WorkflowDefinition] = {
        w.name.lower(): w for w in parent
    }

    for child_wf in child:
        merged[child_wf.name.lower()] = child_wf

    return list(merged.values())


def _merge_labels(
    parent: list[LabelDefinition],
    child: list[LabelDefinition],
) -> list[LabelDefinition]:
    """Merge parent and child label definitions.

    Child label replaces parent label by name (case-insensitive).
    New child labels are appended.
    """
    merged: dict[str, LabelDefinition] = {
        lbl.name.lower(): lbl for lbl in parent
    }

    for child_label in child:
        merged[child_label.name.lower()] = child_label

    return list(merged.values())
