"""Schema file writer — rebuilds schema YAMLs with remote IDs baked in.

Called after every schema push so that:
  - labels.yaml  → each label has an `id:` field
  - workflows.yaml → each state has an `id:` field
  - types.yaml   → each type has an `id:` field

With IDs present, subsequent pushes can PATCH (update) instead of
blindly creating duplicates, and renames are detected correctly.

Public API (importable by other modules):
  - write_workflows_yaml(path, workflows) — canonical workflow YAML writer
  - workflow_to_dict(wf)                 — convert WorkflowDefinition → dict
  - WORKFLOWS_YAML_HEADER                — shared header comment string
"""
from pathlib import Path

import yaml

from planecompose.core.models import (
    LabelDefinition,
    StateDefinition,
    WorkItemTypeDefinition,
    WorkflowDefinition,
    ModuleDefinition,
    CycleDefinition,
)

# ---------------------------------------------------------------------------
# Shared workflow constants & helpers (imported by clone_helpers, sync/writer)
# ---------------------------------------------------------------------------

WORKFLOWS_YAML_HEADER = """# Workflow Definitions
# Defines state machines for work items with transitions and validation rules
#
# Each state entry is either:
#   {}                          — no outgoing transitions (terminal state)
#   flow_type + to              — one flow config; each target has its own config
#
# flow_type: transition  — free move to any listed target state
# flow_type: approval    — requires approver sign-off before moving
#
# The `to` list contains dicts of {target_state: per_transition_config}.
# Use {} as the value when a transition has no special config.
#
# Per-transition config keys (all optional):
#   approvers: [email, ...]      — who must approve (approval flow only)
#   required_approvals: N        — minimum approvals needed
#   rejection_state: StateName   — where to send if rejected
#   conditions:
#     pre: [rule, ...]           — rules checked before transition
#     post: [rule, ...]          — rules applied after transition
#
# Example:
# workflows:
#   Default Workflow:
#     description: Default workflow for the project
#     is_active: true
#     is_default: true
#     states:
#       Backlog:
#         flow_type: transition
#         to:
#         - In Progress: {}
#         - In Review: {}
#       In Progress:
#         flow_type: approval
#         to:
#         - Done:
#             approvers: [user@example.com]
#             required_approvals: 1
#             rejection_state: Backlog
#             conditions:
#               pre:
#               - handler: run_script
#                 script_id: <uuid>
#                 config: {}
#               post: []
#       Done: {}"""


def rule_to_dict(rule) -> dict:
    """Serialise a RuleDefinition to a YAML-safe dict.

    Keeps ``script_id`` as a top-level key and strips it from ``config``
    to avoid duplication.  The ``script`` field is reserved for a future
    local-file-path feature.
    """
    entry: dict = {"handler": rule.handler}
    if rule.script_id:
        entry["script_id"] = rule.script_id
    if rule.script:                      # local file path (future)
        entry["script"] = rule.script
    cfg = dict(rule.config) if rule.config else {}
    cfg.pop("script_id", None)           # already in top-level script_id
    entry["config"] = cfg
    return entry


def workflow_to_dict(wf: WorkflowDefinition) -> dict:
    """Convert a WorkflowDefinition to a YAML-serialisable dict.

    This is the single canonical implementation used by all three write
    paths (clone, pull, schema push).  The dict produced here is the value
    for a single workflow entry inside ``workflows: {}``.

    The caller is responsible for the ``name`` key (used as the dict key)
    and for any extra overrides (e.g. clone_helpers adds preserved states
    when the API returns an empty list).
    """
    entry: dict = {}

    # Metadata
    if wf.description:
        entry["description"] = wf.description
    entry["is_active"] = wf.is_active
    entry["is_default"] = wf.is_default
    if wf.work_item_types:
        entry["work_item_types"] = list(wf.work_item_types)

    # States dict: state_name → flow config or {} (terminal / no outgoing).
    #
    # flow_type is STATE-level — all outgoing transitions from a state share
    # the same type (transition | approval), approvers, and conditions.
    # Individual target states are collected into a ``to`` list.
    states_dict: dict = {}
    for state in wf.states:
        if not state.transitions:
            states_dict[state.name] = {}
            continue

        flow_type = state.type or "transition"

        # Build per-transition `to` list: [{target_name: per_trans_config}]
        # Each transition carries its own approvers, conditions, rejection_state.
        to_list = []
        for t in state.transitions:
            per_trans: dict = {}
            if t.approvers:
                per_trans["approvers"] = list(t.approvers)
            if t.required_approvals is not None:
                per_trans["required_approvals"] = t.required_approvals
            if t.rejection_state:
                per_trans["rejection_state"] = t.rejection_state
            pre = [rule_to_dict(r) for r in t.pre_rules]
            post = [rule_to_dict(r) for r in t.post_rules]
            if pre or post:
                per_trans["conditions"] = {"pre": pre, "post": post}
            to_list.append({t.to: per_trans})

        state_entry: dict = {
            "flow_type": flow_type,
            "to": to_list,
        }
        states_dict[state.name] = state_entry

    entry["states"] = states_dict

    # Embed remote workflow id for idempotent updates on subsequent pushes.
    if wf.remote_id:
        entry["id"] = wf.remote_id

    return entry


def write_workflows_yaml(path: Path, workflows: list[WorkflowDefinition]) -> None:
    """Write workflows.yaml from a list of WorkflowDefinition objects.

    This is the single canonical writer used by all paths:
      - ``plane clone``         (via clone_helpers)
      - ``plane pull``          (via sync/writer.PullWriter)
      - ``plane schema push``   (via rebuild_schema_files)
      - ``plane schema import`` (via clone_helpers)

    Args:
        path:      Destination file path (e.g. schema_dir / "workflows.yaml").
        workflows: Resolved WorkflowDefinition objects (with states + transitions).
    """
    workflows_dict = {wf.name: workflow_to_dict(wf) for wf in workflows}
    _dump(path, {"workflows": workflows_dict}, header=WORKFLOWS_YAML_HEADER)


# ---------------------------------------------------------------------------
# Shared header constants (importable by other modules that do load→merge→write)
# ---------------------------------------------------------------------------

LABELS_YAML_HEADER = """# Label Definitions
# Labels help organize and categorize work items in your project
#
# Example:
# labels:
#   - name: Frontend
#     color: "#3b82f6"
#     id: <uuid>
#   - name: Backend
#     color: "#10b981"
#     id: <uuid>"""

STATES_YAML_HEADER = """# State Definitions
# States represent different stages of work items
#
# State groups: backlog, unstarted, started, completed, cancelled
#
# Example:
# states:
#   Backlog:
#     group: backlog
#     color: '#60646C'
#     id: <uuid>
#   In Progress:
#     group: started
#     color: '#F59E0B'
#     id: <uuid>
#   Done:
#     group: completed
#     color: '#46A758'
#     id: <uuid>"""

TYPES_YAML_HEADER = """# Work Item Type Definitions
#
# NOTE: Base work item types (Bug, Feature, Task, etc) are automatically created.
# This file can be used to add custom properties to existing types or create custom types.
#
# Example:
# work_item_types:
#   Bug:
#     description: A defect or issue requiring fix
#     id: <uuid>
#   Feature:
#     description: Net-new functionality or capability
#     id: <uuid>"""

FEATURES_YAML_HEADER = """# Project Feature Toggles
# Enable or disable features for this project.
# Changes here are applied when you run `plane schema push`.
#
# Data gating: cycles/modules data is only pushed when the flag is true.
# Set a flag to false to disable the feature AND skip pushing its data.
#
# Available features:
#   cycles          — time-boxed sprints / iterations
#   modules         — group work items by feature area
#   pages           — collaborative wiki pages
#   views           — saved filtered views
#   intakes         — public intake / triage form
#   epics           — hierarchical parent work items
#   work_item_types — custom work item type definitions
#   workflows       — state-machine workflow rules
#   parallel_cycles — allow multiple active cycles simultaneously
#   project_updates — project progress update posts
#
# Example:
# features:
#   cycles: true
#   modules: true
#   pages: false
#   views: false
#   intakes: false
#   epics: false
#   work_item_types: false
#   workflows: false
#   parallel_cycles: false
#   project_updates: false"""


def dump_yaml(path: Path, data: object, header: str = "") -> None:
    """Public alias for ``_dump`` — write YAML with header, importable by cli/schema.py."""
    _dump(path, data, header=header)


def _get_remote_id(obj) -> str | None:
    """Return the remote ID from either a model object (``remote_id``) or a
    raw SDK object (``id``).  Casts to str and returns None for falsy values.
    """
    raw = getattr(obj, "remote_id", None) or getattr(obj, "id", None)
    return str(raw) if raw else None


def rebuild_schema_files(
    schema_dir: Path,
    types: list[WorkItemTypeDefinition],
    workflows: list[WorkflowDefinition],
    labels: list[LabelDefinition],
    modules: list[ModuleDefinition] | None = None,
    cycles: list[CycleDefinition] | None = None,
    enterprise_mode: bool = False,
    states: list[StateDefinition] | None = None,
    work_dir: Path | None = None,
    features: dict | None = None,
) -> None:
    """Rewrite all schema YAML files with IDs included.

    Args:
        schema_dir:  Path to the project's schema/ directory.
        types:       Resolved type definitions (with remote_id set).
        workflows:   Resolved workflow definitions (states have remote_id set).
        labels:      Resolved label definitions (with remote_id set).
        modules:     Resolved module definitions (with remote_id set).
        cycles:      Resolved cycle definitions (with remote_id set).
        enterprise_mode: If True, write minimal types.yaml for workspace-linked types.
        states:      Resolved state definitions (with remote_id set). If None,
                     falls back to the union of states across workflows.
        work_dir:    Path to the project's work/ directory. Cycles and modules are
                     written here. Defaults to schema_dir.parent / 'work'.
        features:    Project feature toggles dict to write to schema/features.yaml.
                     If None, features.yaml is not touched.
    """
    schema_dir.mkdir(parents=True, exist_ok=True)

    # Cycles and modules are operational data → work/ folder.
    _work_dir = work_dir if work_dir is not None else schema_dir.parent / "work"
    _work_dir.mkdir(parents=True, exist_ok=True)

    # If caller didn't supply the canonical state list (e.g., legacy callers),
    # derive it from workflows so states.yaml still gets refreshed.
    if states is None:
        by_name: dict[str, StateDefinition] = {}
        for wf in workflows:
            for s in wf.states:
                by_name.setdefault(s.name.lower(), s)
        states = list(by_name.values())

    write_labels_yaml(schema_dir / "labels.yaml", labels)
    write_states_yaml(schema_dir / "states.yaml", states)
    write_workflows_yaml(schema_dir / "workflows.yaml", workflows)
    write_types_yaml(schema_dir / "types.yaml", types, enterprise_mode=enterprise_mode)
    if features is not None:
        write_features_yaml(schema_dir / "features.yaml", features)
    if modules:
        write_modules_yaml(_work_dir / "modules.yaml", modules)
    if cycles:
        write_cycles_yaml(_work_dir / "cycles.yaml", cycles)


# ---------------------------------------------------------------------------
# labels.yaml
# ---------------------------------------------------------------------------

def write_labels_yaml(path: Path, labels) -> None:
    """Write labels.yaml (array under root key).

    Accepts both ``LabelDefinition`` model objects (``remote_id`` attr) and
    raw SDK objects (``id`` attr) — ``_get_remote_id`` handles both.

    Format:
        labels:
          - name: Frontend
            color: '#3b82f6'
            id: <uuid>
    """
    data = []
    for lbl in labels:
        entry: dict = {"name": lbl.name}
        rid = _get_remote_id(lbl)
        if rid:
            entry["id"] = rid
        if lbl.color:
            entry["color"] = lbl.color
        data.append(entry)
    _dump(path, {"labels": data}, header=LABELS_YAML_HEADER)


# ---------------------------------------------------------------------------
# states.yaml
# ---------------------------------------------------------------------------

def write_states_yaml(path: Path, states) -> None:
    """Write states.yaml (name → attrs dict under root key).

    Accepts both ``StateDefinition`` model objects and raw SDK objects.
    ``allow_issue_creation`` is written only when ``False`` (compact format —
    omitting it implies the default ``True``).  ``is_default`` is written
    only when ``True``.

    Format:
        states:
          Backlog:
            group: backlog
            color: '#60646C'
            id: <uuid>
    """
    states_dict: dict = {}
    for state in states:
        name = getattr(state, "name", None)
        if not name:
            continue
        entry: dict = {"group": getattr(state, "group", "unstarted")}
        color = getattr(state, "color", None)
        if color:
            entry["color"] = color
        description = getattr(state, "description", None)
        if description:
            entry["description"] = description
        # Write only when non-default to keep files compact.
        if getattr(state, "is_default", False):
            entry["is_default"] = True
        if getattr(state, "allow_issue_creation", True) is False:
            entry["allow_issue_creation"] = False
        rid = _get_remote_id(state)
        if rid:
            entry["id"] = rid
        states_dict[name] = entry
    _dump(path, {"states": states_dict}, header=STATES_YAML_HEADER)


# ---------------------------------------------------------------------------
# types.yaml
# ---------------------------------------------------------------------------

def write_types_yaml(path: Path, types: list[WorkItemTypeDefinition], enterprise_mode: bool = False) -> None:
    """Write types.yaml (type name → attrs dict under root key).

    Format:
        work_item_types:
          Bug:
            id: <uuid>
            description: ...
    """
    if not types:
        _dump(path, {"work_item_types": {}}, header=TYPES_YAML_HEADER)
        return

    types_dict: dict = {}
    for t in types:
        entry: dict = {}

        # Always include id (project-level WIT id)
        if t.remote_id:
            entry["id"] = t.remote_id

        # Enterprise mode: include workspace-level type reference.
        # We do NOT skip the rest of the fields — user-defined description,
        # workflow, and properties must be preserved on every schema rebuild.
        if enterprise_mode or t.ws_workitemtype_id:
            if t.ws_workitemtype_id:
                entry["ws_workitemtype_id"] = t.ws_workitemtype_id

        # Full format: write all user-defined fields regardless of mode
        if t.description:
            entry["description"] = t.description
        entry["workflow"] = t.workflow or "default"
        if t.parent_types:
            entry["parent_types"] = t.parent_types
        if t.is_epic:
            entry["is_epic"] = t.is_epic
        if t.is_default:
            entry["is_default"] = t.is_default
        if t.level:
            entry["level"] = t.level
        if t.logo_props:
            logo: dict = {}
            if t.logo_props.icon:
                logo["icon"] = t.logo_props.icon
            if t.logo_props.background_color:
                logo["background_color"] = t.logo_props.background_color
            if t.logo_props.emoji:
                logo["emoji"] = t.logo_props.emoji
            if logo:
                entry["logo_props"] = logo
        if t.fields:
            props = []
            for f in t.fields:
                field_entry: dict = {
                    "name": f.name,
                    "type": f.type.value if hasattr(f.type, "value") else str(f.type),
                }
                if f.display_name and f.display_name != f.name:
                    field_entry["display_name"] = f.display_name
                if f.required:
                    field_entry["required"] = f.required
                if f.options:
                    field_entry["options"] = f.options
                if f.is_multi:
                    field_entry["is_multi"] = f.is_multi
                if not f.is_active:
                    field_entry["is_active"] = f.is_active
                props.append(field_entry)
            entry["properties"] = props
        types_dict[t.name] = entry

    _dump(path, {"work_item_types": types_dict}, header=TYPES_YAML_HEADER)


# ---------------------------------------------------------------------------
# features.yaml
# ---------------------------------------------------------------------------

# Canonical order for features.yaml output (mirrors ProjectFeature field order)
_FEATURES_KEY_ORDER = [
    "cycles",
    "modules",
    "pages",
    "views",
    "intakes",
    "epics",
    "work_item_types",
    "workflows",
    "parallel_cycles",
    "project_updates",
]


def write_features_yaml(path: Path, features: dict) -> None:
    """Write features.yaml with project feature toggles.

    All keys in ``_FEATURES_KEY_ORDER`` are always written — using the
    API-returned value when present, defaulting to ``false`` otherwise.
    This keeps the file complete and predictable regardless of what the
    API returns (e.g. newer features not yet exposed by this instance).
    Any extra keys returned by the API are appended after the known list.

    Args:
        path:     Destination file path (e.g. schema_dir / "features.yaml").
        features: Dict mapping feature name → bool.
    """
    ordered: dict = {}
    for key in _FEATURES_KEY_ORDER:
        ordered[key] = features.get(key, False)  # default false if API omits it
    # Preserve any extra keys the API might return in future
    for key, val in features.items():
        if key not in ordered:
            ordered[key] = val
    _dump(path, {"features": ordered}, header=FEATURES_YAML_HEADER)


# ---------------------------------------------------------------------------
# modules.yaml
# ---------------------------------------------------------------------------

def write_modules_yaml(path: Path, modules: list[ModuleDefinition]) -> None:
    """Write modules.yaml (array under root key).

    Format:
        modules:
          - name: Authentication
            description: ...
            id: <uuid>
    """
    header = """# Module Definitions
# Modules group related work items by feature area or milestone.
#
# Example:
# modules:
#   - name: Authentication
#     description: User login, OAuth, and session management
#     start_date: '2024-01-01'
#     end_date: '2024-03-31'
#     id: <uuid>
#   - name: API Integration
#     description: Third-party API integrations
#     id: <uuid>"""
    data = []
    for mod in modules:
        entry: dict = {"name": mod.name}
        rid = _get_remote_id(mod)
        if rid:
            entry["id"] = rid
        if mod.description:
            entry["description"] = mod.description
        if mod.status:
            entry["status"] = mod.status
        if mod.start_date:
            entry["start_date"] = mod.start_date
        if mod.end_date:
            entry["end_date"] = mod.end_date
        data.append(entry)
    _dump(path, {"modules": data}, header=header)


# ---------------------------------------------------------------------------
# cycles.yaml
# ---------------------------------------------------------------------------

def write_cycles_yaml(path: Path, cycles: list[CycleDefinition]) -> None:
    """Write cycles.yaml (array under root key).

    Format:
        cycles:
          - name: Sprint 1
            description: ...
            id: <uuid>
    """
    header = """# Cycle Definitions
# Cycles represent time-boxed sprints or iterations.
#
# Example:
# cycles:
#   - name: Sprint 1
#     description: First sprint — core setup and scaffolding
#     start_date: '2024-01-01'
#     end_date: '2024-01-14'
#     status: backlog
#     id: <uuid>
#   - name: Sprint 2
#     description: Second sprint — feature development
#     start_date: '2024-01-15'
#     end_date: '2024-01-28'
#     id: <uuid>"""
    data = []
    for cyc in cycles:
        entry: dict = {"name": cyc.name}
        rid = _get_remote_id(cyc)
        if rid:
            entry["id"] = rid
        if cyc.description:
            entry["description"] = cyc.description
        if cyc.status:
            entry["status"] = cyc.status
        if cyc.start_date:
            entry["start_date"] = cyc.start_date
        if cyc.end_date:
            entry["end_date"] = cyc.end_date
        data.append(entry)
    _dump(path, {"cycles": data}, header=header)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _dump(path: Path, data: object, header: str = "") -> None:
    """Write YAML with consistent formatting and optional header comments."""
    with open(path, "w") as f:
        if header:
            f.write(header)
            f.write("\n")
        yaml.dump(
            data,
            f,
            default_flow_style=False,
            allow_unicode=True,
            sort_keys=False,
        )
