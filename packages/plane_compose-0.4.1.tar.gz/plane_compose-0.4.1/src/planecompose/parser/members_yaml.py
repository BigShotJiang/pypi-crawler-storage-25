"""Parser for members.yaml — project member list."""

from pathlib import Path

import yaml

from planecompose.utils.logger import get_logger

logger = get_logger()

# Role mappings — Plane API uses integer role values
ROLE_STR_TO_INT: dict[str, int] = {
    "guest": 5,
    "member": 15,
    "admin": 20,
}
ROLE_INT_TO_STR: dict[int, str] = {v: k for k, v in ROLE_STR_TO_INT.items()}
DEFAULT_ROLE = "member"


def read_members_yaml(project_path: Path) -> list[dict]:
    """Read members.yaml and return a list of member dicts.

    Each entry may contain any combination of: ``id``, ``email``, ``display_name``, ``role``.
    For push, only ``email`` is required. ``role`` defaults to ``member`` if omitted.

    Args:
        project_path: Root path of the project (where plane.yaml lives).
                      File is read from ``schema/members.yaml``.

    Returns:
        List of member dicts, or empty list if the file does not exist or is empty.
    """
    members_path = project_path / "schema" / "members.yaml"
    if not members_path.exists():
        return []
    try:
        with open(members_path) as f:
            data = yaml.safe_load(f)
        if not data:
            return []

        # Extract from root key if present (new format: members: [...])
        if isinstance(data, dict) and 'members' in data and len(data) == 1:
            data = data['members']

        if not isinstance(data, list):
            return []
        return [m for m in data if isinstance(m, dict) and m.get("email")]
    except Exception as e:
        logger.warning(f"Could not read members.yaml: {e}")
        return []


def write_members_yaml(project_path: Path, members: list[dict]) -> None:
    """Write members.yaml with id, email, display_name, and optionally role for each member.

    ``role`` is written **only when explicitly present** in the member dict.  The Plane
    API does not return project-level role in GET responses, so pull/clone/import will
    not populate this field.  Users set ``role`` manually (``guest`` | ``member`` |
    ``admin``); ``plane push`` then applies it to the project.

    Args:
        project_path: Root path of the project (where plane.yaml lives).
                      File is written to ``schema/members.yaml``.
        members: List of member dicts (id, email, display_name, and optionally role).
    """
    members_path = project_path / "schema" / "members.yaml"
    # Keep only the fields we care about, in a consistent order
    clean = []
    for m in members:
        entry: dict = {}
        if m.get("id"):
            entry["id"] = m["id"]
        if m.get("email"):
            entry["email"] = m["email"]
        if m.get("display_name"):
            entry["display_name"] = m["display_name"]
        # Write role when present — accepts any slug string (incl. custom roles)
        # or a legacy integer (converted to canonical slug).
        role_raw = m.get("role")
        if role_raw is not None:
            role_str = str(role_raw).lower() if not isinstance(role_raw, str) else role_raw
            if role_str.isdigit():
                role_str = ROLE_INT_TO_STR.get(int(role_str), role_str)
            if role_str:
                entry["role"] = role_str
        if entry:
            clean.append(entry)

    with open(members_path, "w") as f:
        yaml.dump({"members": clean}, f, default_flow_style=False, sort_keys=False, allow_unicode=True)

    logger.debug(f"Wrote members.yaml with {len(clean)} members")


def merge_member_roles(fetched_members: list[dict], project_path: Path) -> list[dict]:
    """Apply previously-saved role values to a freshly-fetched member list.

    The Plane API does not return role in GET responses.  Call this before
    :func:`write_members_yaml` during pull/clone/import so that roles the user
    has already set in ``schema/members.yaml`` are not silently reset to the
    default on every sync.

    For members not present in the existing file the default role (``member``)
    is used; :func:`write_members_yaml` handles that case automatically.

    Args:
        fetched_members: Fresh member dicts from the API (no role field).
        project_path:    Root path of the project (where ``plane.yaml`` lives).

    Returns:
        New list of member dicts with ``role`` populated from the existing file
        where available.
    """
    existing = read_members_yaml(project_path)
    existing_role_by_email: dict[str, str] = {
        m["email"]: m["role"]
        for m in existing
        if m.get("email") and m.get("role") and isinstance(m["role"], str) and m["role"].strip()
    }

    merged = []
    for m in fetched_members:
        member = dict(m)
        email = member.get("email", "")
        if email in existing_role_by_email:
            member["role"] = existing_role_by_email[email]
        merged.append(member)
    return merged
