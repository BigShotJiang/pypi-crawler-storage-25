"""Parser for work/*.yaml files - Terraform-style clean parsing."""
import yaml
from pathlib import Path
from typing import Iterator, NamedTuple
from planecompose.core.models import WorkItem
from planecompose.exceptions import ParserError


class WorkItemWithMeta(NamedTuple):
    """Work item with metadata about its source (for tracking)."""
    item: WorkItem
    source_file: str  # Relative path
    index: int  # type: ignore[assignment]  # Shadows tuple.index(); rename would touch many call sites


def parse_work_items(path: Path, root_path: Path | None = None) -> Iterator[WorkItemWithMeta]:
    """Parse work items from YAML files without modifying them.

    Any ``*.yaml`` file under ``work/`` is treated as a work items file, except
    for the two reserved files: ``cycles.yaml`` and ``modules.yaml``.  Files are
    sorted alphabetically so the merge order is deterministic.  ``workitems.yaml``
    sorts before most custom names, keeping backward compatibility.

    Falls back to ``.plane/remote/items.yaml`` (pre-Phase 3 layout) when no
    work-item YAML files are found in the directory.
    """
    if root_path is None:
        root_path = path.parent if path.is_file() else path

    # Files in work/ that are NOT work items — never parse these as work items
    _NON_WORKITEM_FILES = {"cycles.yaml", "modules.yaml"}

    if path.is_file():
        yield from _parse_work_file(path, root_path)
    elif path.is_dir():
        # Collect all *.yaml files that are not reserved operational files
        work_item_files = sorted(
            f for f in path.glob("*.yaml")
            if f.name not in _NON_WORKITEM_FILES
        )
        if work_item_files:
            for file_path in work_item_files:
                yield from _parse_work_file(file_path, root_path)
        else:
            # Backward compat: pre-Phase 3 projects — try .plane/remote/items.yaml
            legacy = root_path / ".plane" / "remote" / "items.yaml"
            if legacy.exists():
                yield from _parse_work_file(legacy, root_path)


def _parse_work_file(path: Path, root_path: Path) -> Iterator[WorkItemWithMeta]:
    """Parse a single work YAML file."""
    try:
        # Use as_posix() so paths are always forward-slash separated on all platforms
        relative_path = path.relative_to(root_path).as_posix()
    except ValueError:
        relative_path = path.as_posix()

    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as e:
        line = None
        if hasattr(e, 'problem_mark') and e.problem_mark is not None:
            line = e.problem_mark.line + 1
        raise ParserError(
            message=f"Invalid YAML in {relative_path}: {e}",
            file_path=relative_path,
            line=line,
        )
    except UnicodeDecodeError as e:
        raise ParserError(
            message=f"Encoding error in {relative_path}: {e}. Ensure file is UTF-8.",
            file_path=relative_path,
        )

    if not data:
        return

    # Support root-key format: workitems: [...]
    # This is the canonical format for work/workitems.yaml
    if isinstance(data, dict) and "workitems" in data:
        items_list = data["workitems"] or []
        if not isinstance(items_list, list):
            raise ParserError(
                message=f"Expected 'workitems' to be a list in {relative_path}",
                file_path=relative_path,
            )
        for index, item_data in enumerate(items_list):
            if item_data:
                try:
                    item = _parse_work_item(item_data)
                except (KeyError, TypeError) as e:
                    raise ParserError(
                        message=f"Invalid work item at index {index} in {relative_path}: {e}",
                        file_path=relative_path,
                    )
                yield WorkItemWithMeta(item, relative_path, index)
        return

    if isinstance(data, list):
        for index, item_data in enumerate(data):
            if item_data:  # Skip empty items
                try:
                    item = _parse_work_item(item_data)
                except (KeyError, TypeError) as e:
                    raise ParserError(
                        message=f"Invalid work item at index {index} in {relative_path}: {e}",
                        file_path=relative_path,
                    )
                yield WorkItemWithMeta(item, relative_path, index)
    elif isinstance(data, dict):
        try:
            item = _parse_work_item(data)
        except (KeyError, TypeError) as e:
            raise ParserError(
                message=f"Invalid work item in {relative_path}: {e}",
                file_path=relative_path,
            )
        yield WorkItemWithMeta(item, relative_path, 0)
    else:
        raise ParserError(
            message=f"Expected list or dict in {relative_path}, got {type(data).__name__}",
            file_path=relative_path,
        )


def _parse_work_item(data: dict, parent_id: str | None = None) -> WorkItem:
    """
    Parse a single work item dictionary.
    
    CLEAN approach: Only read what's in the file, don't add metadata.
    """
    children = []
    for child_data in data.get('children', []):
        child = _parse_work_item(child_data, data.get('id'))
        children.append(child)
    
    return WorkItem(
        id=data.get('id'),  # Optional user-provided ID
        title=data['title'],
        description=data.get('description'),
        type=data.get('type', 'task'),
        state=data.get('state'),
        priority=data.get('priority'),
        labels=data.get('labels', []),
        start_date=data.get('start_date'),
        due_date=data.get('due_date'),
        parent=parent_id or data.get('parent'),  # Use parent_id from hierarchy or explicit parent
        children=children,
        assignees=data.get('assignees', []),
        watchers=data.get('watchers', []),
        blocked_by=data.get('blocked_by', []),
        blocking=data.get('blocking', []),
        duplicate_of=data.get('duplicate_of'),
        relates_to=data.get('relates_to', []),
        properties=data.get('properties', {}),  # Custom properties
    )



