"""Parser for plane.yaml configuration file."""
import yaml
from pathlib import Path
from planecompose.core.models import ProjectConfig, WorkspaceConfig
from planecompose.constants import DEFAULT_API_URL, DEFAULT_TYPE


def parse_plane_yaml(path: Path) -> ProjectConfig:
    """Parse plane.yaml into ProjectConfig model (project-specific config only).

    Validates that the file has type=project (optional for backwards compatibility).
    """
    with open(path, 'r') as f:
        data = yaml.safe_load(f)

    # Validate file type (optional for backwards compatibility with older plane.yaml files)
    file_type = data.get('type', 'project')  # Default to 'project' for backwards compatibility
    if file_type != 'project':
        # Log warning but don't fail - could be a workspace.yaml loaded as plane.yaml
        from planecompose.utils.logger import get_logger
        logger = get_logger()
        logger.warning(f"plane.yaml has type={file_type}, expected type=project")

    project_data = data.get('project', {})
    schema_data = data.get('schema', {})

    return ProjectConfig(
        workspace=data['workspace'],
        project_key=project_data.get('key', data.get('project_key', '')),
        project_uuid=project_data.get('uuid'),  # Optional UUID field
        project_name=project_data.get('name'),
        project_description=project_data.get('description') or None,
        project_network=project_data.get('network') or None,
        project_timezone=project_data.get('timezone') or None,
        api_url=data.get('api_url') or DEFAULT_API_URL,
        default_type=data.get('defaults', {}).get('type', DEFAULT_TYPE),
        schema_extends=schema_data.get('extends') if schema_data else None,
        connection_id=data.get('connection'),  # Optional explicit connection reference
        template=data.get('template'),  # Template source (persisted for future upgrades)
    )


def parse_workspace_yaml(path: Path) -> WorkspaceConfig:
    """Parse workspace.yaml into WorkspaceConfig model (workspace-level config only)."""
    with open(path, 'r') as f:
        data = yaml.safe_load(f)

    if data is None:
        data = {}

    return WorkspaceConfig(
        workspace=data.get('workspace', ''),
        workspace_features=data.get('workspace_features'),
        work_item_types=data.get('work_item_types'),  # List of workspace-level WIT definitions
    )



