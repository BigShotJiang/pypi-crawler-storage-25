"""Parser for schema/workflows.yaml."""
import yaml
from pathlib import Path
from planecompose.core.models import (
    WorkflowDefinition,
    StateDefinition,
    TransitionDefinition,
    RuleDefinition,
)


def _parse_rules(rules_raw: list) -> list[RuleDefinition]:
    """Parse a list of rule dicts into RuleDefinition objects."""
    result = []
    for rule_data in rules_raw:
        if isinstance(rule_data, dict):
            result.append(RuleDefinition(
                handler=rule_data.get('handler', 'run_script'),
                script_id=rule_data.get('script_id', ''),
                script=rule_data.get('script', ''),   # local file path (future)
                config=rule_data.get('config') or {},
            ))
    return result


def parse_states_yaml(path: Path) -> dict[str, dict]:
    """Parse states.yaml into a dict of state definitions by name.

    Returns:
        Dict mapping state_name -> {id, group, color, ...}
    """
    with open(path, 'r') as f:
        data = yaml.safe_load(f)

    if not data:
        return {}

    # Extract from root key if present (new format: states: {...})
    if isinstance(data, dict) and 'states' in data and len(data) == 1:
        data = data['states']

    # Handle both list format and dict format
    if isinstance(data, list):
        # Legacy list format
        states_dict = {}
        for state in data:
            name = state.get('name')
            if name:
                states_dict[name] = state
        return states_dict
    else:
        # Dict format (new): state_name -> properties
        return dict(data)


def parse_workflows_yaml(
    path: Path,
    states_definitions: dict[str, dict] | None = None,
) -> list[WorkflowDefinition]:
    """Parse workflows.yaml into WorkflowDefinition models.

    Args:
        path: Path to workflows.yaml
        states_definitions: Dict of state definitions from states.yaml
                           If None, will try to load from sibling states.yaml

    Returns:
        List of WorkflowDefinition objects
    """
    with open(path, 'r') as f:
        data = yaml.safe_load(f)

    if not data:
        return []

    # Load state definitions if not provided
    if states_definitions is None:
        states_yaml_path = path.parent / "states.yaml"
        if states_yaml_path.exists():
            states_definitions = parse_states_yaml(states_yaml_path)
        else:
            states_definitions = {}

    # Handle both old nested format (workflows: {...}) and new format (top-level keys)
    workflows_data = data.get('workflows', data)

    workflows = []
    for workflow_key, config in workflows_data.items():
        if not isinstance(config, dict):
            continue

        states_data = config.get('states', {})
        states = []

        if isinstance(states_data, dict):
            # ── New format ────────────────────────────────────────────────────
            # states:
            #   StateName:                  ← state name is the key
            #     flow_type: transition      ← state-level flow type
            #     to: [Target, ...]          ← one or more target states
            #     approvers: []
            #     conditions:
            #       pre: [...]
            #       post: [...]
            #   TerminalState: {}            ← no outgoing transitions
            for state_name, state_config in states_data.items():
                state_def = states_definitions.get(state_name, {})

                if not state_config:
                    # Terminal / no outgoing transitions
                    states.append(StateDefinition(
                        name=state_name,
                        description=state_def.get('description'),
                        color=state_def.get('color'),
                        group=state_def.get('group', 'unstarted'),
                        remote_id=state_def.get('id'),
                        allow_issue_creation=state_def.get('allow_issue_creation', True),
                        is_default=state_def.get('is_default', False),
                        type='transition',
                        transitions=[],
                    ))
                    continue

                flow_type = state_config.get('flow_type', 'transition')

                # `to` can be:
                #   New format: list of dicts  [{TargetName: per_trans_config}, ...]
                #   Old format: list of strings [TargetName, ...]  (backward compat)
                #   Single string: "TargetName"                    (backward compat)
                to_raw = state_config.get('to') or []
                if isinstance(to_raw, str):
                    to_raw = [to_raw]

                # State-level fallback fields (old format only — new format encodes
                # these per-transition, but we fall back for old files).
                state_approvers = list(state_config.get('approvers') or [])
                state_rejection = state_config.get('rejection_state')
                state_req_approvals = state_config.get('required_approvals')
                state_conditions = state_config.get('conditions') or {}
                state_pre_rules = _parse_rules(state_conditions.get('pre') or [])
                state_post_rules = _parse_rules(state_conditions.get('post') or [])

                transitions = []
                for item in to_raw:
                    if isinstance(item, str):
                        # ── Old format: plain string target, use state-level fields ──
                        target = item
                        per_trans: dict = {}
                    elif isinstance(item, dict) and item:
                        # ── New format: {target_name: per_trans_config_or_None} ──
                        target = next(iter(item))
                        per_trans = item[target] or {}
                    else:
                        continue

                    if not target:
                        continue

                    # Resolve per-transition fields, falling back to state-level.
                    approvers = list(per_trans.get('approvers') or state_approvers)
                    rejection_state = per_trans.get('rejection_state') or state_rejection
                    required_approvals = per_trans.get('required_approvals')
                    if required_approvals is None:
                        required_approvals = state_req_approvals

                    cond = per_trans.get('conditions') or {}
                    # Only fall back to state-level conditions when per-trans has none.
                    if cond:
                        pre_rules = _parse_rules(cond.get('pre') or [])
                        post_rules = _parse_rules(cond.get('post') or [])
                    else:
                        pre_rules = state_pre_rules
                        post_rules = state_post_rules

                    transitions.append(TransitionDefinition(
                        to=target,
                        type=flow_type,
                        approvers=approvers,
                        rejection_state=rejection_state,
                        required_approvals=required_approvals,
                        pre_rules=pre_rules,
                        post_rules=post_rules,
                    ))

                states.append(StateDefinition(
                    name=state_name,
                    description=state_def.get('description'),
                    color=state_def.get('color'),
                    group=state_def.get('group', 'unstarted'),
                    remote_id=state_def.get('id'),
                    allow_issue_creation=state_def.get('allow_issue_creation', True),
                    is_default=state_def.get('is_default', False),
                    type=flow_type,
                    transitions=transitions,
                ))

        elif isinstance(states_data, list):
            # ── Legacy format (backward compat) ───────────────────────────────
            # Two sub-variants:
            #   A) List of strings + separate transitions dict:
            #        states: [Backlog, In Progress]
            #        transitions:
            #          Backlog:
            #          - to: In Progress
            #
            #   B) List of dicts (oldest format):
            #        states:
            #          - name: backlog
            #            group: unstarted
            #            color: '#858585'
            transitions_dict = config.get('transitions', {})

            for state_entry in states_data:
                # Normalise: accept both str ("Backlog") and dict ({name: ...})
                if isinstance(state_entry, dict):
                    state_name = state_entry.get('name', '')
                    # Use inline dict values as the state definition
                    state_def = {
                        'group': state_entry.get('group', 'unstarted'),
                        'color': state_entry.get('color'),
                        'description': state_entry.get('description'),
                        'id': state_entry.get('id') or state_entry.get('remote_id'),
                        'is_default': state_entry.get('is_default', False),
                        'allow_issue_creation': state_entry.get('allow_issue_creation', True),
                    }
                else:
                    state_name = state_entry
                    state_def = states_definitions.get(state_name, {})

                if not state_name:
                    continue

                transitions_for_state = transitions_dict.get(state_name, {})

                if isinstance(transitions_for_state, dict):
                    trans_list = [] if not transitions_for_state else [transitions_for_state]
                elif isinstance(transitions_for_state, list):
                    trans_list = transitions_for_state
                else:
                    trans_list = []

                transitions = []
                for trans_data in trans_list:
                    if not isinstance(trans_data, dict) or not trans_data:
                        continue
                    pre_rules = _parse_rules(trans_data.get('pre_rules') or [])
                    post_rules = _parse_rules(trans_data.get('post_rules') or [])
                    transitions.append(TransitionDefinition(
                        to=trans_data.get('to', ''),
                        type=trans_data.get('type', 'transition'),
                        required_approvals=trans_data.get('required_approvals'),
                        approvers=list(trans_data.get('approvers') or []),
                        rejection_state=trans_data.get('rejection_state'),
                        pre_rules=pre_rules,
                        post_rules=post_rules,
                    ))

                states.append(StateDefinition(
                    name=state_name,
                    description=state_def.get('description'),
                    color=state_def.get('color'),
                    group=state_def.get('group', 'unstarted'),
                    remote_id=state_def.get('id'),
                    allow_issue_creation=state_def.get('allow_issue_creation', True),
                    is_default=state_def.get('is_default', False),
                    type=state_def.get('type', 'transition'),
                    transitions=transitions,
                ))

        # Create workflow
        workflows.append(WorkflowDefinition(
            name=config.get('name', workflow_key),
            description=config.get('description'),
            states=states,
            is_active=config.get('is_active', False),
            is_default=config.get('is_default', False),
            work_item_types=config.get('work_item_types', []),
            remote_id=config.get('id'),
            created_by=config.get('created_by'),
            updated_by=config.get('updated_by'),
            initial=config.get('initial'),  # Legacy field
            terminal=config.get('terminal'),  # Legacy field
        ))

    return workflows
