"""Template loader - handles default, local, and remote Git templates."""
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Optional
from rich.console import Console

console = Console()


class TemplateLoader:
    """Load templates from default, local paths, or remote Git repositories."""

    @staticmethod
    def _get_default_template_path() -> Path:
        """Get path to built-in default template."""
        return Path(__file__).parent / "default"

    @staticmethod
    def _is_git_url(template: str) -> bool:
        """Check if template argument is a Git URL."""
        return (
            template.startswith("https://")
            or template.startswith("http://")
            or template.startswith("git@")
            or template.startswith("git://")
        )

    @staticmethod
    def _parse_git_url(url: str) -> tuple[str, str, str | None]:
        """Parse Git URL to extract repo URL, template path, and optional branch.

        Supports multiple formats:
            https://github.com/org/repo/templates/template1
            → ("https://github.com/org/repo.git", "templates/template1", None)

            https://github.com/org/repo/tree/main/templates/template1
            → ("https://github.com/org/repo.git", "templates/template1", "main")

            git@github.com:org/repo/templates/template1
            → ("git@github.com:org/repo.git", "templates/template1", None)

        Returns:
            (repo_url, template_path, branch)
        """
        # For HTTPS URLs
        if url.startswith("https://") or url.startswith("http://"):
            # Remove protocol
            protocol = url.split("://")[0]
            rest = url.split("://", 1)[1]

            # Split into domain and path
            parts = rest.split("/", 1)
            if len(parts) < 2:
                raise ValueError(f"Invalid Git URL format: {url}")

            domain = parts[0]  # github.com
            path = parts[1]    # org/repo/... or org/repo/tree/branch/...

            path_components = path.split("/")
            if len(path_components) < 2:
                raise ValueError(f"Invalid Git URL format: {url}")

            org = path_components[0]
            repo = path_components[1]

            # Check if URL includes /tree/branch/path format (GitHub web URL)
            branch = None
            template_path = ""

            if len(path_components) > 2 and path_components[2] == "tree":
                # GitHub web URL format: org/repo/tree/branch/path
                if len(path_components) < 4:
                    raise ValueError(f"Invalid GitHub URL format (missing branch): {url}")
                branch = path_components[3]
                template_path = "/".join(path_components[4:]) if len(path_components) > 4 else ""
            else:
                # Direct path format: org/repo/path/to/template
                template_path = "/".join(path_components[2:]) if len(path_components) > 2 else ""

            repo_url = f"{protocol}://{domain}/{org}/{repo}.git"
            return repo_url, template_path, branch

        # For SSH URLs (git@github.com:org/repo/templates/template1)
        if url.startswith("git@"):
            # Format: git@github.com:org/repo/path/to/template
            parts = url.split(":")
            if len(parts) < 2:
                raise ValueError(f"Invalid Git SSH URL format: {url}")

            host_part = parts[0]  # git@github.com
            path_part = parts[1]  # org/repo/templates/template1

            path_components = path_part.split("/")
            if len(path_components) < 2:
                raise ValueError(f"Invalid Git SSH URL format: {url}")

            org = path_components[0]
            repo = path_components[1]
            template_path = "/".join(path_components[2:]) if len(path_components) > 2 else ""

            repo_url = f"{host_part}:{org}/{repo}.git"
            return repo_url, template_path, None

        raise ValueError(f"Unsupported Git URL format: {url}")

    @staticmethod
    def _validate_template_structure(template_path: Path) -> None:
        """Validate that template has required directory structure.

        Raises:
            ValueError: If template structure is invalid
        """
        required_dirs = ["schema", "work"]
        for dir_name in required_dirs:
            dir_path = template_path / dir_name
            if not dir_path.exists() or not dir_path.is_dir():
                raise ValueError(
                    f"Template missing required directory: {dir_name}/ "
                    f"(expected at {dir_path})"
                )

    @staticmethod
    def _split_tag(template_arg: str) -> tuple[str, "str | None"]:
        """Split a template spec into (url_or_path, ref).

        Supports GitHub-Actions-style pinning with ``@tag`` or ``@release``:
            https://github.com/org/repo/templates/t1@v1.2.0  →  (url, "v1.2.0")
            git@github.com:org/repo/templates/t1@v2          →  (url, "v2")
            https://github.com/org/repo/templates/t1          →  (url, None)

        For SSH URLs (git@...) the host '@' is skipped — only the portion
        after the first '/' is searched for a pinning '@'.
        """
        if template_arg.startswith("git@"):
            slash_pos = template_arg.find("/")
            if slash_pos == -1:
                return template_arg, None
            idx = template_arg.rfind("@", slash_pos)
            if idx == -1:
                return template_arg, None
            return template_arg[:idx], template_arg[idx + 1:]
        else:
            idx = template_arg.rfind("@")
            if idx == -1:
                return template_arg, None
            return template_arg[:idx], template_arg[idx + 1:]

    def load(self, template_arg: Optional[str] = None) -> Path:
        """Load template and return its path.

        Args:
            template_arg: Template specification (path or URL), or None for default.
                Supports ``@tag`` pinning, e.g. ``https://github.com/…/t@v1.2.0``.

        Returns:
            Path to template directory (validated)

        Raises:
            ValueError: If template is invalid or inaccessible
            RuntimeError: If Git clone fails
        """
        # Use default if not specified
        if template_arg is None:
            template_path = self._get_default_template_path()
            if not template_path.exists():
                raise ValueError(
                    f"Default template not found at {template_path}. "
                    f"Ensure planecompose package is properly installed."
                )
            console.print("[dim]Using default template[/dim]")
            return template_path

        # Strip @tag/release suffix before further processing
        base_arg, pinned_ref = self._split_tag(template_arg)

        # Detect and handle Git URLs
        if self._is_git_url(base_arg):
            console.print("[dim]Cloning template from remote repository...[/dim]")
            return self._load_from_git(base_arg, pinned_ref=pinned_ref)

        # Handle local paths (tag suffix ignored for local paths)
        return self._load_from_local(base_arg)

    def _load_from_local(self, template_path_str: str) -> Path:
        """Load template from local filesystem.

        Args:
            template_path_str: Local path (relative or absolute)

        Returns:
            Path to template directory (validated)

        Raises:
            ValueError: If path doesn't exist or has invalid structure
        """
        template_path = Path(template_path_str).resolve()

        if not template_path.exists():
            raise ValueError(f"Template path not found: {template_path_str}")

        if not template_path.is_dir():
            raise ValueError(f"Template path is not a directory: {template_path_str}")

        self._validate_template_structure(template_path)
        console.print(f"[dim]Using template from {template_path}[/dim]")
        return template_path

    @staticmethod
    def _normalize_git_url(git_url: str) -> str:
        """Normalize well-known non-clone URL variants to their clonable form.

        Handles:
          - github.dev  → github.com  (VS Code web editor URL)
          - gitlab.dev  → gitlab.com  (future-proofing)
        """
        replacements = [
            ("https://github.dev/", "https://github.com/"),
            ("http://github.dev/", "https://github.com/"),
        ]
        for old, new in replacements:
            if git_url.startswith(old):
                normalized = new + git_url[len(old):]
                console.print(
                    "[yellow]⚠[/yellow]  [dim]github.dev URL detected — "
                    "auto-corrected to github.com[/dim]"
                )
                return normalized
        return git_url

    def _load_from_git(self, git_url: str, pinned_ref: "str | None" = None) -> Path:
        """Clone template from Git repository.

        Args:
            git_url: Git URL with embedded template path (and optional branch via /tree/branch/)
            pinned_ref: Explicit tag/release/branch from ``@ref`` suffix — takes priority
                        over any branch embedded in the URL path.

        Returns:
            Path to template directory in temp location

        Raises:
            ValueError: If URL is invalid
            RuntimeError: If git clone fails
        """
        git_url = self._normalize_git_url(git_url)
        try:
            repo_url, template_path_in_repo, url_branch = self._parse_git_url(git_url)
        except ValueError as e:
            raise ValueError(f"Invalid Git URL: {git_url}\n{str(e)}")

        if not template_path_in_repo:
            raise ValueError(
                f"Git URL must include template path. "
                f"Expected format: {git_url}/templates/my-template"
            )

        # @tag suffix takes priority; fall back to branch embedded in URL (/tree/branch/)
        ref = pinned_ref or url_branch

        # Warn on http:// template URLs (MITM risk — template content served over plaintext)
        if repo_url.startswith("http://"):
            from urllib.parse import urlparse
            host = urlparse(repo_url).hostname or ""
            if host not in ("localhost", "127.0.0.1", "::1"):
                console.print(
                    "[yellow]Warning:[/yellow] Template URL uses insecure http://. "
                    "Template content could be intercepted in transit. Use https:// instead."
                )

        # Validate ref format to prevent unexpected git flag injection
        import re as _re
        if ref and not _re.match(r'^[a-zA-Z0-9._/\-]+$', ref):
            raise ValueError(
                f"Invalid ref '{ref}': only alphanumeric characters, '.', '_', '/', and '-' are allowed."
            )

        # Create temp directory for clone
        temp_dir = tempfile.mkdtemp(prefix="plane_template_")
        try:
            # Build git clone command with optional ref (tag, release, or branch)
            clone_cmd = ["git", "clone"]
            if ref:
                clone_cmd.extend(["-b", ref])
            clone_cmd.extend([repo_url, temp_dir])

            ref_str = f" (ref: {ref})" if ref else ""
            console.print(f"[dim]Cloning {repo_url}{ref_str}...[/dim]")

            result = subprocess.run(
                clone_cmd,
                capture_output=True,
                text=True,
                timeout=60,
            )

            if result.returncode != 0:
                raise RuntimeError(
                    f"Git clone failed: {result.stderr}\n"
                    f"Repository: {repo_url}\n"
                    f"Ref: {ref or 'default'}\n"
                    f"Check that:\n"
                    f"  - Repository URL is correct\n"
                    f"  - Tag/release/branch exists (if specified)\n"
                    f"  - You have access to the repository\n"
                    f"  - Git is installed and configured"
                )

            template_path = Path(temp_dir) / template_path_in_repo
            # Containment check — prevent path traversal via crafted template paths
            if not str(template_path.resolve()).startswith(str(Path(temp_dir).resolve())):
                raise ValueError(
                    f"Template path '{template_path_in_repo}' escapes the clone directory. "
                    "Refusing to load template."
                )
            if not template_path.exists():
                raise ValueError(
                    f"Template path not found in repository: {template_path_in_repo}\n"
                    f"Repository URL: {repo_url}\n"
                    f"Ref: {ref or 'default'}"
                )

            self._validate_template_structure(template_path)
            console.print(f"[dim]Loaded template: {template_path_in_repo}[/dim]")

            # Return the cloned path (caller is responsible for cleanup if needed)
            # For now, we'll copy to a persistent temp location
            return template_path

        except subprocess.TimeoutExpired:
            shutil.rmtree(temp_dir, ignore_errors=True)
            raise RuntimeError(f"Git clone timed out after 60 seconds for {repo_url}")
        except Exception:
            shutil.rmtree(temp_dir, ignore_errors=True)
            raise

    @staticmethod
    def copy_template_files(
        template_path: Path, target_schema_dir: Path, target_work_dir: Path
    ) -> None:
        """Copy template files to project directories.

        Args:
            template_path: Path to template root
            target_schema_dir: Destination for schema/ files
            target_work_dir: Destination for work/ files
        """
        # Copy schema files
        schema_src = template_path / "schema"
        if schema_src.exists():
            for yaml_file in schema_src.glob("*.yaml"):
                shutil.copy2(yaml_file, target_schema_dir / yaml_file.name)

        # Copy work files
        work_src = template_path / "work"
        if work_src.exists():
            for yaml_file in work_src.glob("*.yaml"):
                shutil.copy2(yaml_file, target_work_dir / yaml_file.name)
