"""Core domain models."""

import re
from pydantic import BaseModel, Field, field_validator, model_validator, ConfigDict
from typing import Any
from enum import Enum

from planecompose.constants import (
    DEFAULT_TYPE,
    DEFAULT_API_URL,
    VALID_RELATION_TYPES,
    VALID_STATE_GROUPS,
)


class FieldType(str, Enum):
    """Field types matching Plane API's property types."""

    # Primary types (match Plane SDK PropertyType)
    TEXT = "text"
    NUMBER = "number"
    DECIMAL = "decimal"
    DATE = "date"
    DATETIME = "datetime"
    OPTION = "option"  # Dropdown/select
    RELATION = "relation"  # User/member picker
    BOOLEAN = "boolean"
    URL = "url"  # URL field
    EMAIL = "email"  # Email field
    FILE = "file"  # File attachment

    # Aliases for backward compatibility
    STRING = "string"  # Maps to TEXT in backend
    ENUM = "enum"  # Maps to OPTION in backend
    USER = "user"  # Maps to RELATION in backend


class FieldDefinition(BaseModel):
    name: str
    display_name: str | None = None  # Human-readable name
    type: FieldType
    required: bool = False
    default: Any = None
    options: list[str] | None = None  # For enum/dropdown types
    is_multi: bool = False  # Multi-select for options
    is_active: bool = True  # Whether field is active
    relation_type: str | None = None  # For RELATION: "user" or "issue"
    remote_id: str | None = None  # Property ID from Plane

    @field_validator("relation_type")
    @classmethod
    def validate_relation_type(cls, v: str | None) -> str | None:
        if v is not None and v not in VALID_RELATION_TYPES:
            raise ValueError(f"relation_type must be one of {VALID_RELATION_TYPES}, got '{v}'")
        return v

    @model_validator(mode="after")
    def validate_options_for_type(self) -> "FieldDefinition":
        """Ensure OPTION/ENUM fields have options defined."""
        if self.type in (FieldType.OPTION, FieldType.ENUM) and not self.options:
            raise ValueError(
                f"Field '{self.name}' of type {self.type.value} must have options defined"
            )
        return self

    def __repr__(self) -> str:
        return f"FieldDefinition({self.name}: {self.type.value})"


class LogoProps(BaseModel):
    """Logo/icon configuration for work item types."""

    icon: str | None = None  # Icon name (e.g., "Activity", "Bug")
    background_color: str | None = None  # Hex color
    emoji: str | None = None  # Alternative emoji


class RuleDefinition(BaseModel):
    """Pre-validation or post-action rule for workflow transitions."""

    handler: str = "run_script"  # Handler type (e.g., "run_script")
    script_id: str = ""  # Remote script UUID (from API); push resolves it to a hook
    script: str = ""    # Local script file path (future: e.g. ./scripts/validate.js)
    config: dict[str, Any] = Field(default_factory=dict)  # Execution variables and extra config

    def __repr__(self) -> str:
        return f"RuleDefinition(handler={self.handler}, script_id={self.script_id})"


class TransitionDefinition(BaseModel):
    """Transition from one state to another in a workflow."""

    to: str  # Target state name
    type: str = "transition"  # "transition" or "approval"
    required_approvals: int | None = None  # Number of approvals required (null = all)
    approvers: list[str] = Field(default_factory=list)  # Approver emails
    rejection_state: str | None = None  # State to move to on approval rejection
    pre_rules: list[RuleDefinition] = Field(default_factory=list)  # Pre-validation rules
    post_rules: list[RuleDefinition] = Field(default_factory=list)  # Post-action rules
    remote_id: str | None = None  # Remote transition UUID (from API); used for PATCH on conditions push

    @field_validator("type")
    @classmethod
    def validate_type(cls, v: str) -> str:
        if v not in ("transition", "approval"):
            raise ValueError(f"type must be 'transition' or 'approval', got '{v}'")
        return v

    def __repr__(self) -> str:
        return f"TransitionDefinition({self.to}: {self.type})"


class WorkItemTypeDefinition(BaseModel):
    name: str
    description: str | None = None
    workflow: str = "default"
    parent_types: list[str] = Field(default_factory=list)
    fields: list[FieldDefinition] = Field(default_factory=list)
    remote_id: str | None = None
    # Enterprise: Reference to workspace-level work item type (instead of defining locally)
    ws_workitemtype_id: str | None = None
    # Rich metadata from Plane
    logo_props: LogoProps | None = None
    is_epic: bool = False
    is_default: bool = False
    level: float = 0.0  # Hierarchy level


class StateDefinition(BaseModel):
    name: str
    description: str | None = None
    color: str | None = None
    group: str = "unstarted"
    remote_id: str | None = None

    # Workflow-specific fields (optional, used when state is part of a workflow)
    allow_issue_creation: bool = True
    is_default: bool = False
    type: str = "transition"  # "transition" or "approval"
    transitions: list["TransitionDefinition"] = Field(default_factory=list)

    @field_validator("group")
    @classmethod
    def validate_group(cls, v: str) -> str:
        if v not in VALID_STATE_GROUPS:
            raise ValueError(f"group must be one of {VALID_STATE_GROUPS}, got '{v}'")
        return v

    @field_validator("type")
    @classmethod
    def validate_type(cls, v: str) -> str:
        if v not in ("transition", "approval"):
            raise ValueError(f"type must be 'transition' or 'approval', got '{v}'")
        return v

    def __repr__(self) -> str:
        return f"StateDefinition({self.name}: {self.group})"


class WorkflowDefinition(BaseModel):
    """Workflow definition with states, transitions, and rules."""

    name: str
    description: str | None = None
    states: list[StateDefinition]

    # Workflow metadata
    is_active: bool = False
    is_default: bool = False  # Read-only from Plane, indicates default workflow
    work_item_types: list[str] = Field(
        default_factory=list
    )  # Work item types this workflow applies to

    # Plane tracking
    remote_id: str | None = None  # Workflow ID from Plane
    created_by: str | None = None  # User ID who created this workflow
    updated_by: str | None = None  # User ID who last updated

    # Legacy fields (kept for backward compatibility)
    initial: str | None = None  # Optional - Plane uses state groups instead
    terminal: list[str] | None = None  # Optional - Plane uses state groups instead

    def __repr__(self) -> str:
        return f"WorkflowDefinition({self.name}: {len(self.states)} states)"


class LabelDefinition(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str
    color: str | None = None
    remote_id: str | None = None


class ModuleDefinition(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str
    description: str | None = None
    status: str = "backlog"  # backlog, planned, in-progress, paused, completed, cancelled
    start_date: str | None = None  # ISO format: YYYY-MM-DD
    end_date: str | None = None  # ISO format: YYYY-MM-DD
    remote_id: str | None = None


class CycleDefinition(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str
    description: str | None = None
    # status is computed by Plane from start/end dates — not user-managed.
    # Kept as optional so existing YAML files with status: still load cleanly.
    status: str | None = None
    start_date: str | None = None  # ISO format: YYYY-MM-DD
    end_date: str | None = None  # ISO format: YYYY-MM-DD
    remote_id: str | None = None


_ISO_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class WorkItem(BaseModel):
    """Work item - kept clean, no metadata pollution."""

    id: str | None = None  # Optional stable ID for tracking (user-provided)
    title: str
    description: str | None = None
    type: str = DEFAULT_TYPE
    state: str | None = None
    priority: str | None = None
    labels: list[str] = Field(default_factory=list)

    # Dates
    start_date: str | None = None  # ISO format: YYYY-MM-DD
    due_date: str | None = None  # ISO format: YYYY-MM-DD

    # Hierarchy
    parent: str | None = None  # Parent work item ID (e.g., "PROJ-123")
    children: list["WorkItem"] = Field(default_factory=list)

    # Assignments
    assignees: list[str] = Field(default_factory=list)  # List of emails or user IDs
    watchers: list[str] = Field(default_factory=list)  # Collaborators to notify

    # Dependencies & Relationships (for dependency charts)
    blocked_by: list[str] = Field(default_factory=list)  # Work items blocking this one
    blocking: list[str] = Field(default_factory=list)  # Work items this one blocks
    duplicate_of: str | None = None  # Original work item if this is a duplicate
    relates_to: list[str] = Field(default_factory=list)  # Related work items

    # Custom properties
    properties: dict[str, Any] = Field(
        default_factory=dict
    )  # Custom properties (e.g., {"platform": "iOS", "severity": "critical"})

    @field_validator("start_date", "due_date")
    @classmethod
    def validate_date_format(cls, v: str | None) -> str | None:
        if v is not None and not _ISO_DATE_RE.match(v):
            raise ValueError(f"Date must be in YYYY-MM-DD format, got '{v}'")
        return v


class WorkspaceConfig(BaseModel):
    """Workspace-level configuration (stored in workspace.yaml)."""

    workspace: str  # Workspace slug
    workspace_features: dict[str, bool] | None = None  # Cached workspace feature flags
    work_item_types: list[dict[str, Any]] | None = (
        None  # Master list of workspace-level WITs (Enterprise)
    )
    members: list[dict[str, Any]] | None = None  # Workspace members (id + email + display_name)

    @field_validator("workspace")
    @classmethod
    def validate_workspace(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("workspace must not be empty")
        return v


class ProjectConfig(BaseModel):
    """Project-level configuration (stored in plane.yaml)."""

    workspace: str
    project_key: str  # Short identifier like "MYPROJ"
    project_uuid: str | None = None  # Actual UUID from Plane
    project_name: str | None = None
    project_description: str | None = None  # Project description
    project_network: str | None = None  # "public" or "private" (API: 2=public, 0=private)
    project_timezone: str | None = None  # IANA timezone string e.g. "Asia/Kolkata"
    api_url: str = DEFAULT_API_URL
    default_type: str = DEFAULT_TYPE
    schema_extends: str | None = None  # Relative path to parent schema dir
    connection_id: str | None = None  # Explicit connection reference (optional)
    template: str | None = None  # Template source used during init/upgrade (persisted in plane.yaml)

    @field_validator("workspace")
    @classmethod
    def validate_workspace(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("workspace must not be empty")
        return v

    @field_validator("project_key")
    @classmethod
    def validate_project_key(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("project_key must not be empty")
        return v

    @field_validator("api_url")
    @classmethod
    def validate_api_url(cls, v: str) -> str:
        if not v.startswith(("http://", "https://")):
            raise ValueError(f"api_url must start with http:// or https://, got '{v}'")
        return v


# Project network visibility helpers — single source of truth for the
# human-readable ↔ API integer mapping used across backend, CLI, and utils.
_NETWORK_STR_TO_INT: dict[str, int] = {"public": 2, "private": 0}
_NETWORK_INT_TO_STR: dict[int, str] = {2: "public", 0: "private"}


def network_to_int(network: str) -> int | None:
    """Convert "public"/"private" to the API integer value (2/0). Returns None if unknown."""
    return _NETWORK_STR_TO_INT.get(network.lower())


def network_to_str(network: int, default: str = "public") -> str:
    """Convert API integer (2/0) to "public"/"private". Returns default if unknown."""
    return _NETWORK_INT_TO_STR.get(network, default)


class WorkItemState(BaseModel):
    """State tracking for a single work item."""

    remote_id: str
    content_hash: str
    source: str  # e.g., "work/workitems.yaml:0" (file path + index)
    last_synced: str
    hash_version: int = 1  # tracks which CONTENT_HASH_VERSION produced the hash

    def __repr__(self) -> str:
        return f"WorkItemState(remote_id={self.remote_id[:8]}..., source={self.source})"


class SyncState(BaseModel):
    last_sync: str | None = None
    types: dict[str, str] = Field(default_factory=dict)  # name -> remote_id
    states: dict[str, str] = Field(default_factory=dict)  # name -> remote_id
    labels: dict[str, str] = Field(default_factory=dict)  # name -> remote_id
    cycles: dict[str, str] = Field(default_factory=dict)  # name -> remote_id
    modules: dict[str, str] = Field(default_factory=dict)  # name -> remote_id
    estimates: dict[str, str] = Field(default_factory=dict)  # name -> remote_id
    properties: dict[str, dict[str, str]] = Field(
        default_factory=dict
    )  # type_id -> {prop_name -> prop_id}
    workflows: dict[str, str] = Field(default_factory=dict)  # workflow_name -> remote_id
    work_items: dict[str, WorkItemState] = Field(default_factory=dict)  # id/hash -> state


class WorkspaceSyncState(BaseModel):
    """Workspace-level sync state tracking workspace entities (not projects)."""

    last_sync: str | None = None

    # Work item types and their properties
    workitemtypes: dict[str, Any] = Field(
        default_factory=lambda: {
            "types": {},  # type_name -> type_id
            "properties": {},  # prop_name -> prop_id
            "hierarchy": {},  # parent_type_id -> [child_type_ids]
        }
    )

    # Workspace members
    members: dict[str, str] = Field(default_factory=dict)  # email -> member_id

    # Project-level labels and states
    projects: dict[str, Any] = Field(
        default_factory=lambda: {
            "labels": {},  # project_label_name -> label_id
            "states": {},  # project_state_name -> state_id
        }
    )

    # Initiative labels
    initiatives: dict[str, Any] = Field(
        default_factory=lambda: {"labels": {}}  # initiative_label_name -> label_id
    )

    # Release schema config (tags + labels only — no actual releases here)
    releases: dict[str, Any] = Field(
        default_factory=lambda: {
            "tags": {},  # tag_version -> tag_id
            "labels": {},  # label_name -> label_id
        }
    )

    # Workspace-level relation type definitions
    relations: dict[str, str] = Field(default_factory=dict)  # relation_name -> relation_id

    # Customer property definitions (schema/customers.yaml)
    customers: dict[str, Any] = Field(
        default_factory=lambda: {
            "properties": {},  # property_name -> {id, type}
        }
    )

    # Enabled workspace features
    features: dict[str, bool] = Field(default_factory=dict)  # feature_name -> enabled

    # Work-level operational data (mirrors work/ folder on disk)
    work: dict[str, Any] = Field(
        default_factory=lambda: {
            "releases": {},  # release_name -> release_id
        }
    )

    _version: int = 1


# Rebuild models to resolve forward references
WorkItem.model_rebuild()  # Resolves children field reference
StateDefinition.model_rebuild()  # Resolves TransitionDefinition reference
TransitionDefinition.model_rebuild()  # Resolves RuleDefinition reference
WorkflowDefinition.model_rebuild()  # Resolves StateDefinition reference
