"""Push command - push work items to Plane.

This command uses the sync module for change detection and execution:
- SyncPlanner: Determines what needs to be created/updated
- SyncExecutor: Executes with parallel batch processing
- StateManager: Tracks sync state with file locking
"""

import asyncio
from pathlib import Path
from typing import Any, cast
import typer
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn

from planecompose.parser.work_yaml import parse_work_items
from planecompose.sync.planner import SyncPlanner
from planecompose.sync.executor import SyncExecutor
from planecompose.state.manager import StateManager
from planecompose.utils.errors import handle_api_error
from planecompose.validation.work_items import validate_work_items
from planecompose.cli.helpers import (
    console,
    require_project_context,
    create_progress,
    connect_backend,
)
from planecompose.cli.display import display_push_plan, display_push_summary
from planecompose.cli.sync_helpers import sync_workspace_context


def push(
    project: str | None = typer.Argument(
        None, help="Project folder name (e.g. testcompose1). Combined with --path if provided."
    ),
    path: Path | None = typer.Option(
        None, "--path", help="Parent directory containing the project (default: current directory)"
    ),
    connection: str | None = typer.Option(
        None, "--connection", "-c", help="Connection ID to use (overrides plane.yaml setting)"
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", "-n", help="Show what would be pushed without making changes"
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Push without confirmation"),
    schema_only: bool = typer.Option(
        False, "--schema-only", help="Alias for --skip workitems --skip cycles --skip modules"
    ),
    skip: list[str] = typer.Option(
        [],
        "--skip",
        help="Skip a section: workitems, cycles, modules. Repeatable.",
    ),
    work_only: bool = typer.Option(False, "--work-only", help="Only push work items (not schema)"),
    all_projects: bool = typer.Option(False, "--all", help="Push all projects found recursively", hidden=True),
    filter_workspace: str | None = typer.Option(
        None, "--workspace", "-w", help="Filter projects by workspace (with --all)"
    ),
    filter_pattern: str | None = typer.Option(
        None, "--filter", help="Filter projects by glob pattern (with --all)", hidden=True
    ),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON", hidden=True),
    no_conflict_check: bool = typer.Option(
        False, "--no-conflict-check", help="Skip remote conflict detection (for CI)"
    ),
    exit_code: bool = typer.Option(
        False,
        "--exit-code",
        help="Use differentiated exit codes for CI/CD: 0=no changes, 1=error, 2=changes applied/detected",
    ),
    resume: bool = typer.Option(
        False, "--resume", help="Retry only the items that failed in the last push", hidden=True
    ),
):
    """
    Push schema and work items to Plane.

    By default, pushes both schema and work items.
    Use --work-only to skip schema (faster if schema unchanged).
    Use --schema-only to push only schema (alias for --skip workitems --skip cycles --skip modules).
    Use --skip to skip individual sections: workitems, cycles, modules.

    Reads work items from work/workitems.yaml and creates them in Plane.

    Exit codes (with --exit-code):
        0: No changes needed (everything already in sync)
        1: Error occurred
        2: Changes were successfully applied (or detected in --dry-run)

    Examples:
        plane push                                    # Push project in current directory
        plane push testcompose1                       # Push cwd/testcompose1
        plane push testcompose1 --path ./projects    # Push ./projects/testcompose1
        plane push --path ./projects/api             # Push specific full path
        plane push --all                             # Push all projects
        plane push --all --workspace=myteam          # Push all projects in workspace
        plane push --json                            # Machine-readable output
        plane push --exit-code                       # CI-friendly exit codes
        plane push --resume                          # Retry failed items from last push
        plane push --skip workitems                  # Push only schema
        plane push --schema-only                     # Alias: push only schema
    """
    # Resolve the project directory:
    #   project + path  → path / project
    #   project only    → cwd / project
    #   path only       → path (treated as full project dir)
    #   neither         → cwd
    resolved_path: Path | None
    if project:
        resolved_path = (path or Path.cwd()).resolve() / project
    else:
        resolved_path = path.resolve() if path else None

    # Compute effective skip set
    from planecompose.cli.helpers import validate_project_skip
    skip_set = set(skip)
    if schema_only:
        skip_set |= {"workitems", "cycles", "modules"}
    validate_project_skip(skip_set)

    try:
        # JSON mode implies force (skip interactive prompts)
        if json_output:
            force = True
        if all_projects:
            asyncio.run(
                _push_all(
                    dry_run,
                    force,
                    schema_only,
                    work_only,
                    filter_workspace,
                    filter_pattern,
                    connection,
                )
            )
        else:
            asyncio.run(
                _push(
                    resolved_path,
                    dry_run,
                    force,
                    skip_set,
                    work_only,
                    json_output,
                    no_conflict_check,
                    exit_code,
                    resume,
                    connection,
                )
            )
    except KeyboardInterrupt:
        if not json_output:
            console.print("\n[yellow]Operation cancelled.[/yellow]")
        raise typer.Exit(130)


async def _push(
    path: Path | None,
    dry_run: bool,
    force: bool,
    skip_set: set[str],
    work_only: bool,
    json_output: bool = False,
    no_conflict_check: bool = False,
    exit_code_mode: bool = False,
    resume: bool = False,
    connection: str | None = None,
):
    """Async implementation of push."""
    import time
    import json

    schema_time: float = 0
    backend = None
    changes_applied = False  # Track whether changes were made (for --exit-code)

    # Suppress Rich output in JSON mode
    if json_output:
        console.quiet = True

    try:
        # Load project context
        ctx = require_project_context(path)

        # Filesystem-as-state: if a work/ file doesn't exist, auto-add to skip_set
        work_dir = ctx.root_path / "work"
        if not (work_dir / "cycles.yaml").exists():
            skip_set = skip_set | {"cycles"}
        if not (work_dir / "modules.yaml").exists():
            skip_set = skip_set | {"modules"}
        # Filesystem-as-state for workitems: skip if no work item files present.
        # Any *.yaml in work/ except cycles.yaml and modules.yaml counts.
        _NON_WORKITEM_FILES = {"cycles.yaml", "modules.yaml"}
        if not any(
            f.name not in _NON_WORKITEM_FILES
            for f in work_dir.glob("*.yaml")
        ):
            skip_set = skip_set | {"workitems"}

        # features.yaml gate: if a feature is explicitly disabled, skip its data.
        # This takes precedence over the filesystem-as-state check above so that
        # a user can have cycles.yaml with content but keep cycles: false to
        # prevent it from being pushed.
        import yaml as _fyaml
        _features_yaml_path = ctx.root_path / "schema" / "features.yaml"
        if _features_yaml_path.exists():
            _fdata = _fyaml.safe_load(open(_features_yaml_path)) or {}
            _feats = _fdata.get("features", {})
            if _feats.get("cycles") is False:
                skip_set = skip_set | {"cycles"}
            if _feats.get("modules") is False:
                skip_set = skip_set | {"modules"}

        # Sync workspace features before running push
        sync_workspace_context(ctx)

        # Override connection_id if provided via CLI
        if connection:
            ctx.config.connection_id = connection

        # --resume is incompatible with workitems-skipped mode
        if resume and "workitems" in skip_set:
            console.print("[red]--resume cannot be used with --schema-only or --skip workitems[/red]")
            raise typer.Exit(1)

        # Push schema first (unless --work-only or --resume)
        push_start = time.time()
        if not work_only and not resume:
            console.print("\n[bold cyan]Step 1: Pushing schema...[/bold cyan]")
            from planecompose.cli.schema import _push_schema

            await _push_schema(dry_run, force, path)
            schema_time = time.time() - push_start

            # Return early only when all work sections are skipped (== --schema-only)
            all_work_skipped = skip_set >= {"workitems", "cycles", "modules"}
            if all_work_skipped:
                if json_output:
                    console.quiet = False
                    print(
                        json.dumps(
                            {
                                "command": "push",
                                "success": True,
                                "skipped": sorted(skip_set),
                                "elapsed_seconds": round(schema_time, 2),
                            },
                            indent=2,
                        )
                    )
                return

            # Step 2: work — always shown, covers cycles + modules + work items
            console.print("\n[bold cyan]Step 2: Pushing work...[/bold cyan]")

            # Show upfront which sections are being skipped and why
            for section in ("cycles", "modules"):
                if section in skip_set:
                    console.print(f"  [dim]↷ {section.capitalize()}: skipped[/dim]")

            # Push cycles and/or modules (active sections only)
            if any(s not in skip_set for s in ("cycles", "modules")):
                await _push_cycles_and_modules(path, skip_set, dry_run)

            # If workitems are skipped, we're done after schema + cycles/modules
            if "workitems" in skip_set:
                console.print("  [dim]↷ Work items: skipped[/dim]")
                elapsed = time.time() - push_start
                skipped_str = f" (Skipped: {', '.join(sorted(skip_set))})" if skip_set else ""
                console.print(f"\n[green]✓[/green] Push completed in {elapsed:.1f}s{skipped_str}")
                return

        # Load project context again for the work items step (fail fast if plane.yaml not found)
        ctx = require_project_context(path)
        # Re-apply connection override if provided
        if connection:
            ctx.config.connection_id = connection
        had_uuid = ctx.config.project_uuid is not None

        with create_progress() as (progress, task):
            # Connect to backend
            ctx, backend = await connect_backend(ctx, progress=progress, task=task)

            # Persist resolved UUID to plane.yaml if it wasn't there before
            if not had_uuid and ctx.config.project_uuid:
                from planecompose.utils.project import update_plane_yaml_with_uuid

                update_plane_yaml_with_uuid(
                    ctx.root_path, ctx.config.project_key, ctx.config.project_uuid
                )

            state_manager = StateManager(ctx.root_path)
            planner = SyncPlanner()

            progress.update(task, description="Loading work items...")
            all_items = list(parse_work_items(ctx.work_path, ctx.root_path))

            progress.update(task, description="Loading schema cache...")
            await backend.ensure_schema_loaded()

            progress.update(task, description="Validating work items...")
            validation_result = validate_work_items(
                [item_meta.item for item_meta in all_items],
                backend.get_cache(),
            )
            if validation_result.warning_count and not json_output:
                _display_validation_warnings(validation_result)
            if not validation_result.is_valid:
                if json_output:
                    console.quiet = False
                    print(
                        json.dumps(
                            {
                                "command": "push",
                                "success": False,
                                "error": "validation failed",
                                "issues": [
                                    {
                                        "item": issue.item_title,
                                        "field": issue.field,
                                        "message": issue.message,
                                        "severity": issue.severity,
                                    }
                                    for issue in validation_result.issues
                                ],
                            },
                            indent=2,
                        )
                    )
                else:
                    from planecompose.cli.validate import _display_rich

                    _display_rich(validation_result, len(all_items))
                raise typer.Exit(1)

            progress.update(task, description="Planning sync...")
            plan = planner.plan_push(all_items, ctx.state)

        # If --resume, filter the plan to only include items from the resume file
        if resume:
            resume_data = _load_resume_state(ctx.root_path)
            if resume_data is None:
                console.print("[yellow]No resume file found. Nothing to retry.[/yellow]")
                console.print(
                    "[dim]Resume files are created automatically when a push has partial failures.[/dim]"
                )
                return
            plan = _filter_plan_for_resume(plan, resume_data)
            if plan.is_empty:
                console.print(
                    "[green]All previously failed items are now resolved (no matching items in plan).[/green]"
                )
                _cleanup_resume_state(ctx.root_path)
                return
            console.print(
                f"\n[bold cyan]Resuming push: retrying {plan.total_changes} previously failed item(s)...[/bold cyan]"
            )

        # Check if anything to do
        if plan.is_empty:
            if json_output:
                console.quiet = False
                print(
                    json.dumps(
                        {
                            "command": "push",
                            "success": True,
                            "created": 0,
                            "updated": 0,
                            "deleted": 0,
                            "failed": 0,
                            "elapsed_seconds": 0,
                            "failed_items": [],
                        },
                        indent=2,
                    )
                )
            else:
                console.print("\n[green]All work items are already synced![/green]")

                if not all_items:
                    console.print(
                        f"\nAdd work items to any [cyan]{ctx.work_path}/*.yaml[/cyan] file"
                    )
                    console.print("\nExample:")
                    console.print("  - title: Implement user authentication")
                    console.print("    type: task")
                    console.print("    priority: high")
                    console.print("    labels: [backend, feature]\n")
                else:
                    console.print(f"\n[dim]{len(plan.skipped)} items already in Plane[/dim]")

            return  # exit 0: no changes needed

        if dry_run:
            if json_output:
                console.quiet = False
                plan_data = {
                    "command": "push",
                    "dry_run": True,
                    "creates": len(plan.creates),
                    "updates": len(plan.updates),
                    "deletes": len(plan.deletes),
                    "skipped": len(plan.skipped),
                    "total_changes": plan.total_changes,
                    "items": [
                        {
                            "action": si.action.value,
                            "title": si.item.title,
                            "type": si.item.type,
                            "reason": si.reason,
                        }
                        for si in list(plan.creates) + list(plan.updates) + list(plan.deletes)
                    ],
                }
                print(json.dumps(plan_data, indent=2))
            else:
                # Display push plan
                display_push_plan(plan)
                console.print("[yellow]Dry run mode - no changes applied[/yellow]")
            # --exit-code: exit 2 if changes were detected
            if exit_code_mode:
                raise typer.Exit(2)
            return

        # Display push plan (non-JSON mode)
        if not json_output:
            display_push_plan(plan)

        # Conflict detection: check if remote items changed since last sync
        conflicts = []
        if plan.updates and not no_conflict_check and not dry_run:
            conflicts = await _check_conflicts(backend, planner, plan, ctx.state, json_output)
            if conflicts and not force:
                from rich.prompt import Confirm

                if not Confirm.ask(
                    f"[yellow]{len(conflicts)} conflict(s) detected.[/yellow] "
                    f"Push anyway and overwrite remote changes?"
                ):
                    console.print(
                        "[yellow]Cancelled. Use --force to override or resolve conflicts first.[/yellow]"
                    )
                    raise typer.Exit(0)

        # Confirm before pushing
        if not force:
            from rich.prompt import Confirm

            action_parts = []
            if plan.creates:
                action_parts.append(f"Create {len(plan.creates)}")
            if plan.updates:
                action_parts.append(f"Update {len(plan.updates)}")
            action = ", ".join(action_parts)

            if not Confirm.ask(f"{action} work items in Plane?"):
                console.print("[yellow]Cancelled[/yellow]")
                raise typer.Exit(0)

        # Execute sync with progress
        start_time = time.time()

        executor = SyncExecutor(backend, state_manager)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
        ) as progress:
            progress_task = progress.add_task(
                f"Syncing {plan.total_changes} work items...", total=plan.total_changes
            )

            async def on_progress(current: int, total: int, item_title: str):
                progress.update(progress_task, completed=current)

            result = await executor.execute(plan, progress_callback=on_progress)

            # Update state in batch
            progress.update(progress_task, description="Saving state...")
            await executor.update_state_batch(result)

        # Save or clean up resume state based on results
        if result.failed_count > 0:
            _save_resume_state(ctx.root_path, result)
        else:
            # Successful push with no failures - clean up any resume file
            _cleanup_resume_state(ctx.root_path)

        # Track that changes were applied
        changes_applied = (result.created_count + result.updated_count + result.deleted_count) > 0

        # Auto-write IDs back to YAML for newly created items without user-provided IDs
        if result.created:
            ids_written = _write_generated_ids_and_remap_state(
                state_manager,
                result.created,
                ctx.config.project_key,
                ctx.root_path,
            )
            if ids_written and not json_output:
                console.print(
                    f"\n[dim]Auto-assigned IDs to {ids_written} work item(s) in YAML[/dim]"
                )

        if result.failed_count == 0 and changes_applied:
            state_manager.mark_last_sync()

        # Display summary
        elapsed = time.time() - start_time

        if json_output:
            console.quiet = False
            print(
                json.dumps(
                    {
                        "command": "push",
                        "success": result.failed_count == 0,
                        "created": result.created_count,
                        "updated": result.updated_count,
                        "deleted": result.deleted_count,
                        "failed": result.failed_count,
                        "elapsed_seconds": round(elapsed, 2),
                        "failed_items": [
                            {"title": r.item.item.title, "error": r.error or ""}
                            for r in result.failed
                        ],
                    },
                    indent=2,
                )
            )
        else:
            display_push_summary(result, schema_time, elapsed, work_only)

        # Handle exit codes
        if result.failed_count > 0:
            raise typer.Exit(1)
        if exit_code_mode and changes_applied:
            raise typer.Exit(2)

    except asyncio.CancelledError:
        pass  # KeyboardInterrupt caught in sync wrapper; CancelledError is cleanup only
    except typer.Exit:
        raise  # Re-raise typer.Exit so it propagates correctly
    except Exception as e:
        if json_output:
            console.quiet = False
            print(
                json.dumps(
                    {
                        "command": "push",
                        "success": False,
                        "error": str(e),
                    },
                    indent=2,
                )
            )
            raise typer.Exit(1)
        handle_api_error(e, "push work items")
        raise typer.Exit(1)
    finally:
        if json_output:
            console.quiet = False
        if backend:
            await backend.disconnect()


async def _check_conflicts(backend, planner, plan, state, json_output: bool = False):
    """Fetch remote items for updates and detect conflicts.

    Returns a list of ConflictItem. Displays warnings to the console
    (or includes them in JSON output).
    """
    from rich.table import Table
    from planecompose.exceptions import NotFoundError

    remote_items: dict[str, object] = {}
    fetch_errors: list[str] = []

    with create_progress() as (progress, task):
        progress.update(task, description="Checking for remote conflicts...")

        # Fetch remote items in parallel with bounded concurrency
        semaphore = asyncio.Semaphore(5)

        async def _fetch_one(sync_item):
            async with semaphore:
                try:
                    remote_item = await backend.get_work_item(sync_item.remote_id)
                    return (sync_item.remote_id, remote_item, None)
                except NotFoundError:
                    return (sync_item.remote_id, None, None)
                except Exception as exc:
                    return (sync_item.remote_id, None, f"{sync_item.item.title[:50]}: {exc}")

        items_to_fetch = [si for si in plan.updates if si.remote_id]
        results = await asyncio.gather(*[_fetch_one(si) for si in items_to_fetch])

        for remote_id, remote_item, error in results:
            if error:
                fetch_errors.append(error)
            elif remote_item is not None:
                remote_items[remote_id] = remote_item

    if fetch_errors:
        raise RuntimeError(
            "Conflict detection could not verify remote state for: "
            + "; ".join(fetch_errors)
            + ". Retry, or use --no-conflict-check if you intentionally want to skip this safeguard."
        )

    conflicts = planner.detect_conflicts(plan, state, remote_items)

    if conflicts:
        if json_output:
            # JSON mode: conflicts will be handled by caller
            pass
        else:
            console.print(
                f"\n[bold yellow]Warning: {len(conflicts)} conflict(s) detected[/bold yellow]"
            )
            console.print("[dim]These items were modified remotely since your last sync.[/dim]\n")

            table = Table(title="Conflicting Items")
            table.add_column("Item", style="bold")
            table.add_column("Local Hash", style="cyan", max_width=10)
            table.add_column("State Hash", style="dim", max_width=10)
            table.add_column("Remote Hash", style="yellow", max_width=10)

            for conflict in conflicts:
                table.add_row(
                    conflict.item_title[:50],
                    conflict.local_hash[:10],
                    conflict.state_hash[:10],
                    conflict.remote_hash[:10],
                )

            console.print(table)
            console.print()

    return conflicts


def _display_validation_warnings(result) -> None:
    """Show non-blocking validation warnings before push."""
    warnings = [issue for issue in result.issues if issue.severity == "warning"]
    if not warnings:
        return

    console.print(
        f"\n[yellow]Validation warnings:[/yellow] {len(warnings)} non-blocking issue(s) found."
    )
    for issue in warnings[:5]:
        console.print(f"  [dim]- {issue.item_title}: {issue.field} - {issue.message}[/dim]")
    if len(warnings) > 5:
        console.print(f"  [dim]...and {len(warnings) - 5} more[/dim]")


def _write_generated_ids_and_remap_state(
    state_manager: StateManager,
    created_results,
    project_key: str,
    root_path: Path,
) -> int:
    """Persist generated IDs to YAML and move state entries to their stable keys."""
    from planecompose.utils.id_writer import write_ids_to_yaml_with_remaps

    written, remaps = write_ids_to_yaml_with_remaps(
        created_results,
        project_key,
        root_path,
    )
    if remaps:
        state_manager.remap_work_item_tracking_keys(remaps)

    return written


async def _push_all(
    dry_run: bool,
    force: bool,
    schema_only: bool,
    work_only: bool,
    filter_workspace: str | None,
    filter_pattern: str | None,
    connection: str | None = None,
):
    """Push all discovered projects."""
    from planecompose.utils.multiproject import (
        discover_projects,
        run_batch,
        display_batch_results,
        display_discovered_projects,
    )

    # Convert schema_only to skip_set for _push
    push_skip_set: set[str] = set()
    if schema_only:
        push_skip_set = {"workitems", "cycles", "modules"}

    # Discover projects
    console.print("\n[bold]Discovering projects...[/bold]")
    projects = discover_projects(
        filter_workspace=filter_workspace,
        filter_pattern=filter_pattern,
    )

    if not projects:
        console.print("[yellow]No projects found[/yellow]")
        console.print("\n[dim]Make sure you're in a directory containing plane.yaml files[/dim]")
        raise typer.Exit(1)

    # Display discovered projects
    display_discovered_projects(projects)

    if dry_run:
        console.print("[yellow]Dry run mode - showing what would be pushed[/yellow]\n")

    # Confirm before pushing all
    if not force and not dry_run:
        from rich.prompt import Confirm

        if not Confirm.ask(f"Push {len(projects)} projects?"):
            console.print("[yellow]Cancelled[/yellow]")
            raise typer.Exit(0)

    # Define the operation for each project
    async def push_one(project_path: Path):
        await _push(
            project_path,
            dry_run,
            force=True,
            skip_set=push_skip_set,
            work_only=work_only,
            connection=connection,
        )

    # Run batch operation
    console.print(f"\n[bold]Pushing {len(projects)} projects...[/bold]\n")

    results = await run_batch(
        projects=projects,
        operation=push_one,
        operation_name="push",
        concurrency=1,  # Sequential for clearer output
    )

    # Display results
    success_count, failure_count = display_batch_results(results, "push")

    if failure_count > 0:
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Resume state helpers
# ---------------------------------------------------------------------------

RESUME_FILE = ".plane/resume.json"


def _save_resume_state(root_path: Path, result) -> None:
    """Save resume state after a push with partial failures.

    Writes a `.plane/resume.json` file listing the tracking keys of
    items that failed so they can be retried with ``plane push --resume``.
    """
    import json
    from datetime import datetime, timezone

    resume_path = root_path / RESUME_FILE
    resume_path.parent.mkdir(parents=True, exist_ok=True)

    failed_keys = [r.item.tracking_key for r in result.failed]
    data = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "failed_keys": failed_keys,
        "total_attempted": result.total_processed,
        "total_failed": result.failed_count,
    }

    with open(resume_path, "w") as f:
        json.dump(data, f, indent=2)

    console.print(
        f"\n[yellow]Resume file saved to {RESUME_FILE} "
        f"({len(failed_keys)} failed item(s)).[/yellow]"
    )
    console.print("[dim]Run 'plane push --resume' to retry only the failed items.[/dim]")


def _load_resume_state(root_path: Path) -> dict | None:
    """Load resume state from `.plane/resume.json`.

    Returns the parsed JSON dict, or ``None`` if the file does not exist.
    """
    import json

    resume_path = root_path / RESUME_FILE
    if not resume_path.exists():
        return None

    try:
        with open(resume_path) as f:
            return cast(dict[Any, Any], json.load(f))
    except (json.JSONDecodeError, OSError) as exc:
        console.print(f"[yellow]Warning: could not read resume file: {exc}[/yellow]")
        return None


def _filter_plan_for_resume(plan, resume_data: dict):
    """Filter a SyncPlan to include only items whose tracking keys appear
    in the resume file's ``failed_keys`` list.

    Returns a new :class:`SyncPlan` (the original is not mutated).
    """
    from planecompose.sync.planner import SyncPlan

    failed_keys = set(resume_data.get("failed_keys", []))

    filtered = SyncPlan()
    filtered.creates = [si for si in plan.creates if si.tracking_key in failed_keys]
    filtered.updates = [si for si in plan.updates if si.tracking_key in failed_keys]
    filtered.deletes = [si for si in plan.deletes if si.tracking_key in failed_keys]
    filtered.skipped = plan.skipped  # preserve skipped for context
    return filtered


def _cleanup_resume_state(root_path: Path) -> None:
    """Delete the resume file if it exists."""
    resume_path = root_path / RESUME_FILE
    if resume_path.exists():
        resume_path.unlink()
        console.print("[dim]Cleaned up resume file (all items succeeded).[/dim]")


async def _push_cycles_and_modules(
    path: Path | None,
    skip_set: set[str],
    dry_run: bool = False,
) -> None:
    """Push cycles and/or modules from work/ YAML files to Plane.

    - If remote_id is set on a cycle/module → PATCH (update).
    - If remote_id is absent → POST (create) and backfill the id into the YAML.
    - Skips whichever sections are in skip_set.
    """
    import yaml as _yaml

    ctx = require_project_context(path)
    ctx, backend = await connect_backend(ctx)
    state_manager = StateManager(ctx.root_path)

    def _backfill_id(yaml_path: Path, name: str, remote_id: str, key: str) -> None:
        """Write remote_id back into the YAML entry that matches `name`."""
        raw = _yaml.safe_load(yaml_path.read_text()) or {}
        entries = raw.get(key, []) or []
        for entry in entries:
            if isinstance(entry, dict) and entry.get("name") == name and "id" not in entry:
                entry["id"] = remote_id
                break
        yaml_path.write_text(_yaml.dump({key: entries}, default_flow_style=False, allow_unicode=True, sort_keys=False))

    # ── Cycles ────────────────────────────────────────────────────────────────
    if "cycles" not in skip_set and ctx.cycles:
        cycles_yaml = ctx.root_path / "work" / "cycles.yaml"
        created = updated = 0
        cycles_state: dict[str, str] = {}  # name → remote_id (for state update)
        for cycle in ctx.cycles:
            if cycle.remote_id:
                if not dry_run:
                    await backend.update_cycle(cycle.remote_id, cycle)
                cycles_state[cycle.name] = cycle.remote_id
                updated += 1
            else:
                if not dry_run:
                    new_id = await backend.create_cycle(cycle)
                    _backfill_id(cycles_yaml, cycle.name, new_id, "cycles")
                    cycles_state[cycle.name] = new_id
                created += 1

        if not dry_run and cycles_state:
            state_manager.update_schema_state(cycles=cycles_state)

        parts = []
        if created:
            parts.append(f"{created} created")
        if updated:
            parts.append(f"{updated} updated")
        if not parts:
            parts.append("nothing to do")
        prefix = "[dim](dry run) " if dry_run else ""
        console.print(f"  {prefix}🔁 Cycles: {', '.join(parts)}[/dim]" if dry_run
                      else f"  [green]✓[/green] Cycles: {', '.join(parts)}")
    elif "cycles" not in skip_set:
        console.print("  [dim]🔁 Cycles: nothing in work/cycles.yaml[/dim]")

    # ── Modules ───────────────────────────────────────────────────────────────
    if "modules" not in skip_set and ctx.modules:
        modules_yaml = ctx.root_path / "work" / "modules.yaml"
        created = updated = 0
        modules_state: dict[str, str] = {}  # name → remote_id (for state update)
        for module in ctx.modules:
            if module.remote_id:
                if not dry_run:
                    await backend.update_module(module.remote_id, module)
                modules_state[module.name] = module.remote_id
                updated += 1
            else:
                if not dry_run:
                    new_id = await backend.create_module(module)
                    _backfill_id(modules_yaml, module.name, new_id, "modules")
                    modules_state[module.name] = new_id
                created += 1

        if not dry_run and modules_state:
            state_manager.update_schema_state(modules=modules_state)

        parts = []
        if created:
            parts.append(f"{created} created")
        if updated:
            parts.append(f"{updated} updated")
        if not parts:
            parts.append("nothing to do")
        prefix = "[dim](dry run) " if dry_run else ""
        console.print(f"  {prefix}📦 Modules: {', '.join(parts)}[/dim]" if dry_run
                      else f"  [green]✓[/green] Modules: {', '.join(parts)}")
    elif "modules" not in skip_set:
        console.print("  [dim]📦 Modules: nothing in work/modules.yaml[/dim]")
