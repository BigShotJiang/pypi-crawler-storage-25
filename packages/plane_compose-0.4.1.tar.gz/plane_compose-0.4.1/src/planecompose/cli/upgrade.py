"""Upgrade command - standardize project schema to a template.

This module implements the 'plane upgrade' command which:
1. Pulls the latest schema from Plane to local YAML files
2. Compares local schema with a template
3. Displays the impact to the user
4. Applies changes to local YAML files
5. Optionally pushes changes to Plane

The upgrade operation is non-destructive:
- Local-only items are preserved (never deleted)
- Template-defined items are created or updated
- For items in both, template values win on specific fields
- Property-level merging: local-only properties preserved, template wins on field-level changes
"""

import asyncio
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional, cast

import typer
import yaml
from rich.prompt import Confirm

from planecompose.cli.helpers import (
    console,
    connect_backend,
    create_progress,
    require_project_context,
)
from planecompose.config.context import load_project_context, ProjectContext, DIR_SCHEMA
from planecompose.core.models import (
    WorkItemTypeDefinition,
    StateDefinition,
    LabelDefinition,
    FieldDefinition,
    CycleDefinition,
    ModuleDefinition,
)
from planecompose.parser.types_yaml import parse_types_yaml
from planecompose.parser.labels_yaml import parse_labels_yaml
from planecompose.parser.workflows_yaml import parse_workflows_yaml, parse_states_yaml
from planecompose.state.manager import StateManager
from planecompose.templates.loader import TemplateLoader
from planecompose.utils.logger import get_logger

logger = get_logger()


# ============================================================================
# Data Structures
# ============================================================================


@dataclass
class FieldChange:
    """A single field-level change in a schema item."""
    field: str  # Field name (e.g., "description", "color", "group")
    old_value: Any  # Previous value
    new_value: Any  # New value (from template)


@dataclass
class TypeChangeset:
    """Changes for a single work item type."""
    name: str
    changes: list[FieldChange] = field(default_factory=list)  # Top-level field changes
    properties_to_add: list[FieldDefinition] = field(default_factory=list)  # From template
    properties_to_update: list[FieldChange] = field(default_factory=list)  # field=prop_name
    properties_only_in_local: list[str] = field(default_factory=list)  # Preserved local props

    def has_changes(self) -> bool:
        """Check if there are any changes for this type."""
        return bool(
            self.changes
            or self.properties_to_add
            or self.properties_to_update
        )


@dataclass
class ItemChangeset:
    """Changes for a state or label."""
    name: str
    changes: list[FieldChange] = field(default_factory=list)


@dataclass
class UpgradeDiff:
    """Complete diff between local schema and template."""
    types_to_add: list[WorkItemTypeDefinition] = field(default_factory=list)
    types_to_update: list[TypeChangeset] = field(default_factory=list)
    types_only_in_local: list[str] = field(default_factory=list)

    states_to_add: list[StateDefinition] = field(default_factory=list)
    states_to_update: list[ItemChangeset] = field(default_factory=list)
    states_only_in_local: list[str] = field(default_factory=list)

    labels_to_add: list[LabelDefinition] = field(default_factory=list)
    labels_to_update: list[ItemChangeset] = field(default_factory=list)
    labels_only_in_local: list[str] = field(default_factory=list)

    cycles_to_add: list[CycleDefinition] = field(default_factory=list)
    cycles_to_update: list[ItemChangeset] = field(default_factory=list)
    cycles_only_in_local: list[str] = field(default_factory=list)

    modules_to_add: list[ModuleDefinition] = field(default_factory=list)
    modules_to_update: list[ItemChangeset] = field(default_factory=list)
    modules_only_in_local: list[str] = field(default_factory=list)

    # Feature flag changes (template wins over local features.yaml)
    features_to_update: list[FieldChange] = field(default_factory=list)

    # Work items from template (only populated when --include-data)
    workitems_to_add: list[dict] = field(default_factory=list)

    def is_empty(self) -> bool:
        """Check if there are any changes."""
        return (
            not self.types_to_add
            and not self.types_to_update
            and not self.states_to_add
            and not self.states_to_update
            and not self.labels_to_add
            and not self.labels_to_update
            and not self.cycles_to_add
            and not self.cycles_to_update
            and not self.modules_to_add
            and not self.modules_to_update
            and not self.features_to_update
            and not self.workitems_to_add
        )

    @property
    def total_additions(self) -> int:
        """Count new items being added."""
        return (
            len(self.types_to_add)
            + len(self.states_to_add)
            + len(self.labels_to_add)
            + len(self.cycles_to_add)
            + len(self.modules_to_add)
            + len(self.workitems_to_add)
        )

    @property
    def total_updates(self) -> int:
        """Count items being updated."""
        return (
            len(self.types_to_update)
            + len(self.states_to_update)
            + len(self.labels_to_update)
            + len(self.cycles_to_update)
            + len(self.modules_to_update)
            + len(self.features_to_update)
        )

    @property
    def total_preserved(self) -> int:
        """Count local-only items being preserved."""
        return (
            len(self.types_only_in_local)
            + len(self.states_only_in_local)
            + len(self.labels_only_in_local)
            + len(self.cycles_only_in_local)
            + len(self.modules_only_in_local)
        )


# ============================================================================
# CLI Command
# ============================================================================


def upgrade(
    project: Optional[str] = typer.Argument(
        None, help="Project folder name (e.g. testcompose1). Combined with --path if provided."
    ),
    path: Path | None = typer.Option(
        None, "--path", help="Parent directory containing the project (default: current directory)"
    ),
    template: Optional[str] = typer.Option(
        None, "--template", "-t",
        help="Template path, Git URL, or Git URL with @tag pin. "
             "If omitted, uses the template stored in plane.yaml."
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", "-n", help="Show diff only, make no changes"
    ),
    force: bool = typer.Option(
        False, "--force", "-f", help="Skip confirmation prompts"
    ),
    skip_pull: bool = typer.Option(
        False, "--skip-pull", help="Skip pulling latest schema from Plane"
    ),
    schema_only: bool = typer.Option(
        False, "--schema-only", help="Update local YAML only, don't push to Plane"
    ),
    include_data: bool = typer.Option(
        False, "--include-data", help="Also copy cycles, modules, and work items from template"
    ),
):
    """
    Upgrade project schema to match a template.

    This command helps standardize project schemas across multiple projects:

    1. Pulls latest schema from Plane (optionally, --skip-pull to use current local)
    2. Compares template with local schema
    3. Shows impact (additions, updates, preserved local items)
    4. Asks for confirmation before applying
    5. Updates local YAML files
    6. Optionally pushes changes to Plane

    The upgrade is non-destructive:
    - Local-only items are always preserved
    - Template-defined items create or update
    - For overlapping items, template fields win

    Examples:
        plane upgrade -t ./my-template                                          # Current directory
        plane upgrade testcompose1 -t ./template                               # Specific project
        plane upgrade testcompose1 --path ./projects -t ./template             # Project in parent dir
        plane upgrade -t https://github.com/org/repo/templates/standard       # Remote template
        plane upgrade -t https://github.com/org/repo/templates/std@v1.2.0     # Pinned to tag/release
        plane upgrade testcompose1                                              # Use template from plane.yaml
        plane upgrade testcompose1 -t ./template --skip-pull                   # Use current local schema
        plane upgrade testcompose1 -t ./template --dry-run                     # Preview without changes
        plane upgrade testcompose1 -t ./template --force --schema-only         # Apply locally, no push
        plane upgrade testcompose1 -t ./template --include-data                # Schema + cycles/modules/workitems
    """
    # Resolve the project directory (same pattern as push/pull/clone)
    resolved_path = (
        (path or Path.cwd()).resolve() / project if project
        else (path.resolve() if path else None)
    )

    try:
        asyncio.run(_upgrade(
            resolved_path,
            template,
            dry_run,
            force,
            skip_pull,
            schema_only,
            include_data,
        ))
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled.[/yellow]")
        raise typer.Exit(130)
    except typer.Exit:
        raise  # pass through clean exits (e.g. --no-template, dry-run)
    except typer.Abort:
        # User cancelled via confirmation prompt - exit cleanly
        raise typer.Exit(0)
    except Exception as e:
        logger.exception("Upgrade failed")
        console.print(f"\n[red]✗ Upgrade failed:[/red] {e}")
        raise typer.Exit(1)


# ============================================================================
# Main Orchestrator
# ============================================================================


async def _upgrade(
    path: Path | None,
    template: Optional[str],
    dry_run: bool,
    force: bool,
    skip_pull: bool,
    schema_only: bool,
    include_data: bool = False,
):
    """
    Execute the upgrade flow:
    1. Load project context
    2. Pull latest schema from Plane (unless --skip-pull)
    3. Load template
    4. Compute diff
    5. Display impact
    6. Confirm with user (unless --force)
    7. Apply to local YAML
    8. Offer to push to Plane
    """

    # Step 0: Load project context
    ctx = require_project_context(path)

    # Resolve template: CLI flag > plane.yaml stored value > error
    if not template:
        stored = ctx.config.template
        if not stored or stored == "default":
            console.print(
                "[red]✗[/red] No template specified.\n\n"
                "  The built-in [bold]default[/bold] template is not upgradable.\n"
                "  Pass [cyan]-t <template>[/cyan] to upgrade from a custom template, "
                "or set [cyan]template:[/cyan] in plane.yaml.\n\n"
                "  Example:\n"
                "    plane upgrade -t https://github.com/org/repo/templates/standard\n"
                "    plane upgrade -t https://github.com/org/repo/templates/std@v1.2.0"
            )
            raise typer.Exit(1)
        template = stored
        console.print(f"[dim]Using template from plane.yaml:[/dim] {template}")

    console.print(f"\n[bold]Upgrading:[/bold] {ctx.config.project_key} " +
                  f"({ctx.config.workspace})")
    console.print(f"[dim]Template:[/dim] {template}\n")

    # Step 1: Pull latest from Plane (optional)
    if not skip_pull:
        # Pull latest schema from Plane so the upgrade diff is always computed
        # against the current remote state — not potentially stale local files.
        with create_progress() as (progress, task):
            progress.update(task, description="Syncing schema from Plane...")
            await _pull_latest_schema_impl(ctx, progress, task)

        # Reload context with updated YAML
        ctx = load_project_context(path)
        console.print("[green]✓[/green] Schema synced from Plane\n")

    # Step 2: Load template
    loader = TemplateLoader()
    try:
        template_path = loader.load(template)
    except Exception as e:
        console.print(f"[red]✗[/red] Could not load template: {e}")
        raise typer.Exit(1)

    console.print(f"[green]✓[/green] Template loaded from {template_path}\n")

    tmpl_types = _parse_template_types(template_path)
    tmpl_states = _parse_template_states(template_path)
    tmpl_labels = _parse_template_labels(template_path)
    tmpl_cycles = _parse_template_cycles(template_path)
    tmpl_modules = _parse_template_modules(template_path)
    tmpl_features = _parse_template_features(template_path)
    tmpl_workitems = _parse_template_workitems(template_path) if include_data else []

    # Load local features.yaml to gate cycles/modules and compute features diff
    local_features: dict = {}
    _features_file = ctx.root_path / "schema" / "features.yaml"
    if _features_file.exists():
        try:
            _fdata = yaml.safe_load(_features_file.read_text()) or {}
            local_features = _fdata.get("features", {}) if isinstance(_fdata, dict) else {}
        except Exception as e:
            logger.debug(f"Could not load local features.yaml: {e}")

    # Gate: when --include-data, use template features to decide whether to
    # include cycles/modules (template may enable them even if local has them off).
    # Without --include-data, cycles/modules are schema-only concern so skip data.
    if include_data:
        _gate_features = tmpl_features or local_features
        cycles_disabled = _gate_features.get("cycles") is False
        modules_disabled = _gate_features.get("modules") is False
    else:
        cycles_disabled = True   # data skipped unless --include-data
        modules_disabled = True

    if not include_data:
        if tmpl_cycles:
            console.print("[dim]ℹ  cycles/modules/workitems skipped — use [cyan]--include-data[/cyan] to copy data from template[/dim]")
    else:
        if cycles_disabled:
            console.print("[dim]ℹ  cycles: false in template features.yaml — cycles section skipped[/dim]")
        if modules_disabled:
            console.print("[dim]ℹ  modules: false in template features.yaml — modules section skipped[/dim]")

    # Debug: show what was parsed from template and local
    logger.debug(f"Template types    ({len(tmpl_types)}): {[t.name for t in tmpl_types]}")
    logger.debug(f"Local types       ({len(ctx.types)}): {[t.name for t in ctx.types]}")
    logger.debug(f"Template states   ({len(tmpl_states)}): {[s.name for s in tmpl_states]}")
    logger.debug(f"Local states      ({len(ctx.states)}): {[s.name for s in ctx.states]}")
    logger.debug(f"Template labels   ({len(tmpl_labels)}): {[lbl.name for lbl in tmpl_labels]}")
    logger.debug(f"Local labels      ({len(ctx.labels)}): {[lbl.name for lbl in ctx.labels]}")
    logger.debug(f"Template cycles   ({len(tmpl_cycles)}): {[c.name for c in tmpl_cycles]} (skipped={cycles_disabled})")
    logger.debug(f"Local cycles      ({len(ctx.cycles)}): {[c.name for c in ctx.cycles]}")
    logger.debug(f"Template modules  ({len(tmpl_modules)}): {[m.name for m in tmpl_modules]} (skipped={modules_disabled})")
    logger.debug(f"Local modules     ({len(ctx.modules)}): {[m.name for m in ctx.modules]}")
    logger.debug(f"Template features : {tmpl_features}")
    logger.debug(f"Local features    : {local_features}")

    # Step 3: Compute diff
    diff = _compute_upgrade_diff(
        ctx.types, ctx.states, ctx.labels, ctx.cycles, ctx.modules,
        tmpl_types, tmpl_states, tmpl_labels, tmpl_cycles, tmpl_modules,
        skip_cycles=cycles_disabled,
        skip_modules=modules_disabled,
        local_features=local_features,
        tmpl_features=tmpl_features,
        tmpl_workitems=tmpl_workitems,
        local_work_dir=ctx.root_path / "work",
    )

    # Step 4: Display impact
    _display_upgrade_diff(diff, ctx.config.project_key, template, include_data=include_data)

    # Step 5: Check if there's anything to do
    if diff.is_empty():
        console.print("\n[green]✓[/green] Already up to date with template.")
        return

    # Step 6: Dry-run or confirm
    if dry_run:
        console.print("\n[dim](No changes made - dry-run mode)[/dim]")
        return

    if not force:
        if not Confirm.ask("\nApply these changes to local schema?"):
            raise typer.Abort()

    # Step 7: Apply to local YAML files
    console.print("\n[cyan]Applying changes to local schema files...[/cyan]")
    _apply_upgrade(ctx.root_path, diff)
    console.print("[green]✓[/green] Local schema files updated.")

    # Update plane.yaml with the template source (so future upgrades need no -t)
    _update_plane_yaml_template(ctx.root_path, template)

    # Step 8: Offer to push (unless --schema-only)
    if not schema_only:
        if force or Confirm.ask("\nPush changes to Plane now?"):
            if include_data:
                console.print("\n[cyan]Pushing changes to Plane...[/cyan]")
                from planecompose.cli.push import _push
                await _push(
                    path=ctx.root_path,
                    dry_run=False,
                    force=True,
                    skip_set=set(),
                    work_only=False,
                    no_conflict_check=True,
                )
            else:
                console.print("\n[cyan]Pushing schema changes to Plane...[/cyan]")
                from planecompose.cli.schema import _push_schema
                await _push_schema(dry_run=False, force=True, path=ctx.root_path)
    else:
        console.print("\n[dim]Run 'plane schema push' to apply changes to Plane.[/dim]")


def _update_plane_yaml_template(project_root: Path, template: str) -> None:
    """Persist the template source in plane.yaml.

    Uses line-level text replacement so comments and formatting are preserved.
    - If a ``template:`` line already exists → replace it.
    - If it doesn't exist → append it after the ``defaults:`` block (or at end of file).
    """
    plane_yaml = project_root / "plane.yaml"
    if not plane_yaml.exists():
        return

    content = plane_yaml.read_text()
    new_line = f"template: {template}"

    lines = content.splitlines(keepends=True)

    # Case 1: existing template: line → replace in-place
    for i, line in enumerate(lines):
        stripped = line.lstrip()
        if stripped.startswith("template:"):
            lines[i] = new_line + "\n"
            plane_yaml.write_text("".join(lines))
            return

    # Case 2: no template: line yet → insert after the defaults: block
    # Find last non-blank line in the defaults: section, then insert after it
    in_defaults = False
    insert_after = -1
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("defaults:"):
            in_defaults = True
            insert_after = i
        elif in_defaults:
            if stripped and not stripped.startswith("#") and not line.startswith(" "):
                # New top-level key started — insert before this line
                break
            if stripped:
                insert_after = i

    if insert_after >= 0:
        lines.insert(insert_after + 1, new_line + "\n")
    else:
        # Fallback: append at end of file
        lines.append("\n" + new_line + "\n")

    plane_yaml.write_text("".join(lines))


# ============================================================================
# Step 1: Pull Latest Schema
# ============================================================================



async def _pull_latest_schema_impl(ctx: ProjectContext, progress, task):
    """
    Pull latest schema from Plane and update local YAML files.

    Uses the same write functions as clone so the output format is identical
    (headers, IDs, field completeness).
    """
    from planecompose.cli.clone_helpers import (
        write_types_yaml,
        write_states_yaml,
        write_workflows_yaml,
        write_labels_yaml,
        write_features_yaml,
    )
    from planecompose.utils.mapping import build_type_map

    progress.update(task, description="Connecting to Plane...")
    ctx, backend = await connect_backend(ctx, auto_create=False,
                                         progress=progress, task=task)

    workspace = ctx.config.workspace
    project_id = ctx.config.project_uuid

    # Fetch all remote schema (raw SDK objects, same as clone)
    progress.update(task, description="Fetching types from Plane...")
    types_sdk = await backend.list_types_raw()
    types_data = [_convert_sdk_type_to_dict(t) for t in types_sdk]

    progress.update(task, description="Building property maps...")
    property_maps = await backend.build_property_maps(types_data)

    progress.update(task, description="Fetching states...")
    states_list = await backend.list_states_raw(cast(str, workspace), cast(str, project_id))

    progress.update(task, description="Fetching labels...")
    labels_list = await backend.list_labels_raw(cast(str, workspace), cast(str, project_id))

    progress.update(task, description="Fetching workflows...")
    try:
        workflows_list = await backend.fetch_workflows(workspace, project_id)
    except Exception:
        workflows_list = []

    # Write YAML files using the same helpers as clone (correct format + headers + IDs)
    target_dir = ctx.root_path
    write_types_yaml(target_dir, types_data, property_maps)
    write_states_yaml(target_dir, states_list)
    if workflows_list:
        type_id_to_name = build_type_map(types_data)
        write_workflows_yaml(target_dir, workflows_list, type_id_to_name)
    else:
        # No remote workflows — write the default template (header + workflows: {})
        import shutil as _shutil
        _default = Path(__file__).parent.parent / "templates" / "default" / "schema" / "workflows.yaml"
        _shutil.copy(_default, target_dir / "schema" / "workflows.yaml")
    write_labels_yaml(target_dir, labels_list)

    # Fetch + write features.yaml (non-blocking — missing on older API versions)
    progress.update(task, description="Fetching features...")
    try:
        features = await backend.get_project_features()
        if features:
            write_features_yaml(target_dir, features)
    except Exception as e:
        logger.debug(f"Could not fetch project features: {e}")

    # Keep state/label lists as StateDefinition/LabelDefinition for state.json update
    remote_states = await backend.list_states()
    remote_labels = await backend.list_labels()

    # Update state.json ID mappings
    state_manager = StateManager(ctx.root_path)

    # Clean up stale lock files before trying to acquire
    _cleanup_stale_lock(ctx.root_path)

    try:
        with state_manager.lock():
            type_map = {t["name"]: t["id"] for t in types_data if t.get("id")}
            state_map = {s.name: s.remote_id for s in remote_states if s.remote_id}
            label_map = {lbl.name: lbl.remote_id for lbl in remote_labels if lbl.remote_id}
            state_manager.update_schema_state(
                types=type_map,
                states=state_map,
                labels=label_map,
            )
    except TimeoutError as e:
        console.print("\n[red]✗[/red] Could not acquire state lock.")
        console.print("  Another process may be syncing. Possible causes:")
        console.print("    1. Run a sync in parallel (wait for it to finish)")
        console.print("    2. A stale lock file from a previous run")
        console.print("  To manually clean up the lock file:")
        console.print(f"    rm {ctx.root_path / '.plane' / '.state.lock'}")
        logger.debug(f"Lock timeout: {e}")
        raise typer.Exit(1)
    except Exception as e:
        logger.debug(f"Error updating state after pull: {e}")
        # If we can't update state, the YAML files are still updated, which is the important part
        # Just log and continue
        pass


# ============================================================================
# Lock Management
# ============================================================================


def _cleanup_stale_lock(project_root: Path):
    """
    Remove stale lock file if it exists and is older than 5 seconds.

    This handles the case where a previous process was interrupted and left
    a lock file behind.
    """
    import time

    lock_file = project_root / ".plane" / ".state.lock"
    if not lock_file.exists():
        return

    try:
        # Check if lock file is older than 5 seconds
        mtime = lock_file.stat().st_mtime
        age_seconds = time.time() - mtime
        if age_seconds > 5:
            logger.debug(f"Removing stale lock file (age: {age_seconds:.1f}s)")
            lock_file.unlink()
    except Exception as e:
        logger.debug(f"Could not clean up stale lock file: {e}")
        # Continue anyway - the lock manager will handle it


# ============================================================================
# Step 2-3: Load Template & Compute Diff
# ============================================================================


def _parse_template_types(template_path: Path) -> list[WorkItemTypeDefinition]:
    """Parse work item types from template."""
    f = template_path / "schema" / "types.yaml"
    return parse_types_yaml(f) if f.exists() else []


def _parse_template_states(template_path: Path) -> list[StateDefinition]:
    """
    Parse states from template.

    Handles both states.yaml (separate) and workflows.yaml (inline) formats.
    parse_states_yaml returns dict[str, dict] (name -> props), so we convert
    it to list[StateDefinition] here.
    """
    states_file = template_path / "schema" / "states.yaml"
    workflows_file = template_path / "schema" / "workflows.yaml"

    if states_file.exists():
        # parse_states_yaml returns dict[str, dict], not list[StateDefinition]
        # Convert it: {name: {group, color, ...}} -> [StateDefinition, ...]
        raw = parse_states_yaml(states_file)
        states = []
        for name, props in raw.items():
            if isinstance(props, dict):
                states.append(StateDefinition(
                    name=name,
                    group=props.get("group", "unstarted"),
                    color=props.get("color"),
                    remote_id=props.get("id"),
                ))
            else:
                # Fallback: just the name with defaults
                states.append(StateDefinition(name=name, group="unstarted"))
        return states

    elif workflows_file.exists():
        # Extract unique states from all workflows
        # parse_workflows_yaml already returns WorkflowDefinition objects
        # whose .states are list[StateDefinition]
        workflows = parse_workflows_yaml(workflows_file, {})
        seen, states = set(), []
        for wf in workflows:
            for s in (wf.states or []):
                # Defensive: handle both StateDefinition objects and strings
                if isinstance(s, str):
                    if s.lower() not in seen:
                        states.append(StateDefinition(name=s, group="unstarted"))
                        seen.add(s.lower())
                elif hasattr(s, "name"):
                    if s.name.lower() not in seen:
                        states.append(s)
                        seen.add(s.name.lower())
        return states

    return []


def _parse_template_labels(template_path: Path) -> list[LabelDefinition]:
    """Parse labels from template."""
    f = template_path / "schema" / "labels.yaml"
    return parse_labels_yaml(f) if f.exists() else []


def _parse_template_features(template_path: Path) -> dict | None:
    """Parse feature toggles from template's schema/features.yaml.

    Returns a dict of {feature_name: bool} if the file exists, or None if the
    template doesn't define feature flags (so no features diff is computed).
    """
    f = template_path / "schema" / "features.yaml"
    if not f.exists():
        return None
    try:
        raw = yaml.safe_load(f.read_text())
        if isinstance(raw, dict):
            features = raw.get("features", {})
            return features if isinstance(features, dict) else {}
    except Exception as e:
        logger.debug(f"Could not parse template features.yaml: {e}")
    return None


def _load_yaml_list_with_key(path: Path, root_key: str) -> list[dict]:
    """
    Load a YAML list that may be either a bare list or wrapped under a root key.

    Handles both formats:
      - Bare list:          [- name: foo, ...]
      - Dict with root key: cycles: [- name: foo, ...]
    """
    if not path.exists():
        return []
    try:
        raw = yaml.safe_load(path.read_text())
        if raw is None:
            return []
        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            items = raw.get(root_key) or []
            return items if isinstance(items, list) else []
    except Exception:
        pass
    return []


def _parse_template_cycles(template_path: Path) -> list[CycleDefinition]:
    """Parse cycles from template's work/cycles.yaml (operational data).

    Falls back to schema/cycles.yaml for older templates.
    """
    f = template_path / "work" / "cycles.yaml"
    if not f.exists():
        f = template_path / "schema" / "cycles.yaml"
    items = _load_yaml_list_with_key(f, "cycles")
    cycles = []
    for c in items:
        if not isinstance(c, dict) or not c.get("name"):
            continue
        try:
            entry = dict(c)
            if "id" in entry and "remote_id" not in entry:
                entry["remote_id"] = entry.pop("id")
            cycles.append(CycleDefinition(**{k: v for k, v in entry.items()
                                             if k in CycleDefinition.model_fields}))
        except Exception:
            continue
    return cycles


def _parse_template_modules(template_path: Path) -> list[ModuleDefinition]:
    """Parse modules from template's work/modules.yaml (operational data).

    Falls back to schema/modules.yaml for older templates.
    """
    f = template_path / "work" / "modules.yaml"
    if not f.exists():
        f = template_path / "schema" / "modules.yaml"
    items = _load_yaml_list_with_key(f, "modules")
    modules = []
    for m in items:
        if not isinstance(m, dict) or not m.get("name"):
            continue
        try:
            entry = dict(m)
            if "id" in entry and "remote_id" not in entry:
                entry["remote_id"] = entry.pop("id")
            modules.append(ModuleDefinition(**{k: v for k, v in entry.items()
                                               if k in ModuleDefinition.model_fields}))
        except Exception:
            continue
    return modules


def _parse_template_workitems(template_path: Path) -> list[dict]:
    """Parse work items from template's work/ directory (all *.yaml except reserved).

    Returns raw dicts (not WorkItem models) so IDs are stripped and items are
    written back as new (id-less) entries ready for a fresh push.
    """
    _NON_WORKITEM_FILES = {"cycles.yaml", "modules.yaml"}
    work_dir = template_path / "work"
    if not work_dir.is_dir():
        return []

    result = []
    for f in sorted(work_dir.glob("*.yaml")):
        if f.name in _NON_WORKITEM_FILES:
            continue
        # Parse the file: support bare list, {workitems: [...]}, or {<stem>: [...]}
        try:
            raw = yaml.safe_load(f.read_text())
        except Exception:
            continue
        if raw is None:
            continue
        if isinstance(raw, list):
            items = raw
        elif isinstance(raw, dict):
            # Try stem key first (tasks.yaml → tasks:), then "workitems" as fallback,
            # then grab the first list value in the dict
            stem_key = f.stem
            if stem_key in raw and isinstance(raw[stem_key], list):
                items = raw[stem_key]
            elif "workitems" in raw and isinstance(raw["workitems"], list):
                items = raw["workitems"]
            else:
                # Last resort: first list value
                items = next((v for v in raw.values() if isinstance(v, list)), [])
        else:
            continue
        for item in items:
            if not isinstance(item, dict) or not item.get("title"):
                continue
            # Strip id/remote_id — these are new items for the target project
            entry = {k: v for k, v in item.items() if k not in ("id", "remote_id")}
            result.append(entry)
    return result


def _compute_upgrade_diff(
    local_types: list[WorkItemTypeDefinition],
    local_states: list[StateDefinition],
    local_labels: list[LabelDefinition],
    local_cycles: list[CycleDefinition],
    local_modules: list[ModuleDefinition],
    tmpl_types: list[WorkItemTypeDefinition],
    tmpl_states: list[StateDefinition],
    tmpl_labels: list[LabelDefinition],
    tmpl_cycles: list[CycleDefinition],
    tmpl_modules: list[ModuleDefinition],
    skip_cycles: bool = False,
    skip_modules: bool = False,
    local_features: dict | None = None,
    tmpl_features: dict | None = None,
    tmpl_workitems: list[dict] | None = None,
    local_work_dir: Path | None = None,
) -> UpgradeDiff:
    """
    Compute the difference between local schema and template.

    Merge strategy (template wins, local-only items preserved):
    - Items only in template → ADD
    - Items only in local → PRESERVE
    - Items in both → for work item types, compute property-level diff

    skip_cycles / skip_modules: when True (features.yaml gate), those sections
    are skipped entirely — no additions, updates, or preserved-only output.

    local_features / tmpl_features: when both provided, computes feature flag
    changes where template wins (same strategy as schema items).
    """
    diff = UpgradeDiff()

    # --- Work Item Types ---
    local_type_map = {t.name.lower(): t for t in local_types}
    tmpl_type_map = {t.name.lower(): t for t in tmpl_types}

    diff.types_to_add = [t for t in tmpl_types if t.name.lower() not in local_type_map]
    diff.types_only_in_local = [t.name for t in local_types
                                if t.name.lower() not in tmpl_type_map]

    for tmpl_type in tmpl_types:
        key = tmpl_type.name.lower()
        if key in local_type_map:
            local_type = local_type_map[key]
            changeset = _compute_type_changeset(local_type, tmpl_type)
            if changeset.has_changes():
                diff.types_to_update.append(changeset)

    # --- States ---
    local_state_map = {s.name.lower(): s for s in local_states}
    tmpl_state_map = {s.name.lower(): s for s in tmpl_states}

    diff.states_to_add = [s for s in tmpl_states if s.name.lower() not in local_state_map]
    diff.states_only_in_local = [s.name for s in local_states
                                 if s.name.lower() not in tmpl_state_map]

    for tmpl_state in tmpl_states:
        key = tmpl_state.name.lower()
        if key in local_state_map:
            local_state = local_state_map[key]
            changes = _compute_state_changes(local_state, tmpl_state)
            if changes:
                diff.states_to_update.append(
                    ItemChangeset(name=tmpl_state.name, changes=changes)
                )

    # --- Labels ---
    local_label_map = {lbl.name.lower(): lbl for lbl in local_labels}
    tmpl_label_map = {lbl.name.lower(): lbl for lbl in tmpl_labels}

    diff.labels_to_add = [lbl for lbl in tmpl_labels if lbl.name.lower() not in local_label_map]
    diff.labels_only_in_local = [lbl.name for lbl in local_labels
                                 if lbl.name.lower() not in tmpl_label_map]

    for tmpl_label in tmpl_labels:
        key = tmpl_label.name.lower()
        if key in local_label_map:
            local_label = local_label_map[key]
            changes = _compute_label_changes(local_label, tmpl_label)
            if changes:
                diff.labels_to_update.append(
                    ItemChangeset(name=tmpl_label.name, changes=changes)
                )

    # --- Cycles (skipped when cycles feature is disabled) ---
    if not skip_cycles:
        local_cycle_map = {c.name.lower(): c for c in local_cycles}
        tmpl_cycle_map = {c.name.lower(): c for c in tmpl_cycles}

        diff.cycles_to_add = [c for c in tmpl_cycles if c.name.lower() not in local_cycle_map]
        diff.cycles_only_in_local = [c.name for c in local_cycles
                                      if c.name.lower() not in tmpl_cycle_map]

        for tmpl_cycle in tmpl_cycles:
            key = tmpl_cycle.name.lower()
            if key in local_cycle_map:
                local_cycle = local_cycle_map[key]
                changes = _compute_cycle_changes(local_cycle, tmpl_cycle)
                if changes:
                    diff.cycles_to_update.append(
                        ItemChangeset(name=tmpl_cycle.name, changes=changes)
                    )

    # --- Modules (skipped when modules feature is disabled) ---
    if not skip_modules:
        local_module_map = {m.name.lower(): m for m in local_modules}
        tmpl_module_map = {m.name.lower(): m for m in tmpl_modules}

        diff.modules_to_add = [m for m in tmpl_modules if m.name.lower() not in local_module_map]
        diff.modules_only_in_local = [m.name for m in local_modules
                                       if m.name.lower() not in tmpl_module_map]

        for tmpl_module in tmpl_modules:
            key = tmpl_module.name.lower()
            if key in local_module_map:
                local_module = local_module_map[key]
                changes = _compute_module_changes(local_module, tmpl_module)
                if changes:
                    diff.modules_to_update.append(
                        ItemChangeset(name=tmpl_module.name, changes=changes)
                    )

    # --- Features (template wins; only computed when template has features.yaml) ---
    if tmpl_features is not None and local_features is not None:
        for key, tmpl_val in tmpl_features.items():
            local_val = local_features.get(key)
            if local_val != tmpl_val:
                diff.features_to_update.append(
                    FieldChange(key, local_val, tmpl_val)
                )

    # --- Work Items (only when --include-data; new items from template not in local) ---
    if tmpl_workitems:
        # Collect titles from all work/*.yaml files (except reserved) to avoid duplicates
        _NON_WORKITEM_FILES = {"cycles.yaml", "modules.yaml"}
        local_titles: set[str] = set()
        if local_work_dir and local_work_dir.is_dir():
            for _wf in sorted(local_work_dir.glob("*.yaml")):
                if _wf.name in _NON_WORKITEM_FILES:
                    continue
                try:
                    _raw = yaml.safe_load(_wf.read_text()) or {}
                    # support both {workitems: [...]} and bare list
                    if isinstance(_raw, dict):
                        _items = _raw.get("workitems", []) or []
                    elif isinstance(_raw, list):
                        _items = _raw
                    else:
                        _items = []
                    for i in _items:
                        if isinstance(i, dict) and i.get("title"):
                            local_titles.add(str(i["title"]).lower())
                except Exception:
                    pass
        diff.workitems_to_add = [
            item for item in tmpl_workitems
            if str(item.get("title", "")).lower() not in local_titles
        ]

    return diff


def _compute_type_changeset(
    local: WorkItemTypeDefinition,
    tmpl: WorkItemTypeDefinition,
) -> TypeChangeset:
    """
    Compute changes for a work item type.

    Template fields that may change:
    - description
    - workflow
    - is_epic
    - logo_props (icon, color)

    Properties: compare by name (case-insensitive), template wins on fields
    but local-only properties are preserved.
    """
    changes = []
    local_desc = (local.description or "").strip()
    tmpl_desc = (tmpl.description or "").strip()
    if local_desc != tmpl_desc:
        changes.append(FieldChange("description", local.description, tmpl.description))

    if getattr(local, "workflow", None) != getattr(tmpl, "workflow", None):
        changes.append(FieldChange(
            "workflow",
            getattr(local, "workflow", None),
            getattr(tmpl, "workflow", None),
        ))

    if getattr(local, "is_epic", False) != getattr(tmpl, "is_epic", False):
        changes.append(FieldChange("is_epic", local.is_epic, tmpl.is_epic))

    # Compare logo_props
    local_logo = getattr(local, "logo_props", None)
    tmpl_logo = getattr(tmpl, "logo_props", None)
    if local_logo != tmpl_logo:
        if tmpl_logo is not None:
            changes.append(FieldChange("logo", local_logo, tmpl_logo))

    # Property-level comparison
    local_prop_map = {f.name.lower(): f for f in (local.fields or [])}
    tmpl_prop_map = {f.name.lower(): f for f in (tmpl.fields or [])}

    properties_to_add = [
        f for f in (tmpl.fields or [])
        if f.name.lower() not in local_prop_map
    ]

    properties_only_in_local = [
        f.name for f in (local.fields or [])
        if f.name.lower() not in tmpl_prop_map
    ]

    properties_to_update = []
    for tmpl_field in (tmpl.fields or []):
        key = tmpl_field.name.lower()
        if key in local_prop_map:
            local_field = local_prop_map[key]
            if _field_signature(local_field) != _field_signature(tmpl_field):
                properties_to_update.append(
                    FieldChange(tmpl_field.name, local_field, tmpl_field)
                )

    return TypeChangeset(
        name=tmpl.name,
        changes=changes,
        properties_to_add=properties_to_add,
        properties_to_update=properties_to_update,
        properties_only_in_local=properties_only_in_local,
    )


def _field_signature(f: FieldDefinition) -> tuple:
    """Build signature for field comparison (excluding IDs and names)."""
    field_type = getattr(getattr(f, "type", None), "value", getattr(f, "type", None))
    return (
        str(field_type).lower() if field_type else "",
        getattr(f, "required", False),
        tuple(getattr(f, "options", None) or []),
        getattr(f, "is_multi", False),
        getattr(f, "is_active", True),
        getattr(f, "relation_type", None),
    )


def _compute_state_changes(
    local: StateDefinition,
    tmpl: StateDefinition,
) -> list[FieldChange]:
    """Compute changes for a state (color, group, etc.)."""
    changes = []

    if getattr(local, "color", None) != getattr(tmpl, "color", None):
        changes.append(FieldChange(
            "color",
            getattr(local, "color", None),
            getattr(tmpl, "color", None),
        ))

    if getattr(local, "group", None) != getattr(tmpl, "group", None):
        changes.append(FieldChange(
            "group",
            getattr(local, "group", None),
            getattr(tmpl, "group", None),
        ))

    return changes


def _compute_label_changes(
    local: LabelDefinition,
    tmpl: LabelDefinition,
) -> list[FieldChange]:
    """Compute changes for a label."""
    changes = []

    if getattr(local, "color", None) != getattr(tmpl, "color", None):
        changes.append(FieldChange(
            "color",
            getattr(local, "color", None),
            getattr(tmpl, "color", None),
        ))

    if getattr(local, "description", None) != getattr(tmpl, "description", None):
        changes.append(FieldChange(
            "description",
            getattr(local, "description", None),
            getattr(tmpl, "description", None),
        ))

    return changes


def _compute_cycle_changes(
    local: CycleDefinition,
    tmpl: CycleDefinition,
) -> list[FieldChange]:
    """Compute changes for a cycle (description, status)."""
    changes = []
    if (local.description or "").strip() != (tmpl.description or "").strip():
        changes.append(FieldChange("description", local.description, tmpl.description))
    if local.status != tmpl.status:
        changes.append(FieldChange("status", local.status, tmpl.status))
    return changes


def _compute_module_changes(
    local: ModuleDefinition,
    tmpl: ModuleDefinition,
) -> list[FieldChange]:
    """Compute changes for a module (description, status)."""
    changes = []
    if (local.description or "").strip() != (tmpl.description or "").strip():
        changes.append(FieldChange("description", local.description, tmpl.description))
    if local.status != tmpl.status:
        changes.append(FieldChange("status", local.status, tmpl.status))
    return changes


# ============================================================================
# Step 4: Display Impact
# ============================================================================


def _display_upgrade_diff(diff: UpgradeDiff, project_key: str, template_src: str, include_data: bool = False):
    """Display the upgrade diff in a human-friendly format."""
    plan_title = "Upgrade Plan" if include_data else "Schema Upgrade Plan"
    console.print(f"[cyan]{'='*70}[/cyan]")
    console.print(f"[bold]{plan_title}[/bold]")
    console.print(f"[cyan]{'='*70}[/cyan]\n")

    # Work Item Types
    if diff.types_to_add or diff.types_to_update or diff.types_only_in_local:
        console.print("[bold cyan]Work Item Types[/bold cyan]")
        for t in diff.types_to_add:
            console.print(f"  [green]+[/green] {t.name:<20} [dim]NEW — will be added[/dim]")
        for changeset in diff.types_to_update:
            console.print(f"  [yellow]~[/yellow] {changeset.name:<20} [dim]UPDATED[/dim]")
            for change in changeset.changes:
                old_val = _truncate_display(str(change.old_value), 30) if change.old_value else "[dim]none[/dim]"
                new_val = _truncate_display(str(change.new_value), 30) if change.new_value else "[dim]none[/dim]"
                console.print(f"      {change.field}: {old_val} → {new_val}")
            if changeset.properties_to_add:
                for prop in changeset.properties_to_add:
                    console.print(f"      [green]+[/green] property: {prop.name}")
            if changeset.properties_to_update:
                for prop_change in changeset.properties_to_update:
                    console.print(f"      [yellow]~[/yellow] property: {prop_change.field}")
            if changeset.properties_only_in_local:
                for local_prop_name in changeset.properties_only_in_local:
                    console.print(f"      [dim]≡[/dim] {local_prop_name} [dim][local property — preserved][/dim]")
        for name in diff.types_only_in_local:
            console.print(f"  [dim]○[/dim] {name:<20} [dim]LOCAL ONLY — will be preserved[/dim]")
        console.print()

    # States
    if diff.states_to_add or diff.states_to_update or diff.states_only_in_local:
        console.print("[bold cyan]States[/bold cyan]")
        for s in diff.states_to_add:
            group_info = f" ({s.group})" if s.group else ""
            console.print(f"  [green]+[/green] {s.name:<20} [dim]NEW{group_info} — will be added[/dim]")
        for state_changeset in diff.states_to_update:
            console.print(f"  [yellow]~[/yellow] {state_changeset.name:<20} [dim]UPDATED[/dim]")
            for change in state_changeset.changes:
                console.print(f"      {change.field}: {change.old_value} → {change.new_value}")
        for name in diff.states_only_in_local:
            console.print(f"  [dim]○[/dim] {name:<20} [dim]LOCAL ONLY — will be preserved[/dim]")
        console.print()

    # Labels
    if diff.labels_to_add or diff.labels_to_update or diff.labels_only_in_local:
        console.print("[bold cyan]Labels[/bold cyan]")
        for lbl in diff.labels_to_add:
            color_info = f" ({lbl.color})" if lbl.color else ""
            console.print(f"  [green]+[/green] {lbl.name:<20} [dim]NEW{color_info} — will be added[/dim]")
        for label_changeset in diff.labels_to_update:
            console.print(f"  [yellow]~[/yellow] {label_changeset.name:<20} [dim]UPDATED[/dim]")
            for change in label_changeset.changes:
                console.print(f"      {change.field}: {change.old_value} → {change.new_value}")
        for name in diff.labels_only_in_local:
            console.print(f"  [dim]○[/dim] {name:<20} [dim]LOCAL ONLY — will be preserved[/dim]")
        console.print()

    # Cycles
    if diff.cycles_to_add or diff.cycles_to_update or diff.cycles_only_in_local:
        console.print("[bold cyan]Cycles[/bold cyan]")
        for c in diff.cycles_to_add:
            console.print(f"  [green]+[/green] {c.name:<20} [dim]NEW — will be added[/dim]")
        for cycle_changeset in diff.cycles_to_update:
            console.print(f"  [yellow]~[/yellow] {cycle_changeset.name:<20} [dim]UPDATED[/dim]")
            for change in cycle_changeset.changes:
                console.print(f"      {change.field}: {change.old_value} → {change.new_value}")
        for name in diff.cycles_only_in_local:
            console.print(f"  [dim]○[/dim] {name:<20} [dim]LOCAL ONLY — will be preserved[/dim]")
        console.print()

    # Modules
    if diff.modules_to_add or diff.modules_to_update or diff.modules_only_in_local:
        console.print("[bold cyan]Modules[/bold cyan]")
        for m in diff.modules_to_add:
            console.print(f"  [green]+[/green] {m.name:<20} [dim]NEW — will be added[/dim]")
        for module_changeset in diff.modules_to_update:
            console.print(f"  [yellow]~[/yellow] {module_changeset.name:<20} [dim]UPDATED[/dim]")
            for change in module_changeset.changes:
                console.print(f"      {change.field}: {change.old_value} → {change.new_value}")
        for name in diff.modules_only_in_local:
            console.print(f"  [dim]○[/dim] {name:<20} [dim]LOCAL ONLY — will be preserved[/dim]")
        console.print()

    # Features
    if diff.features_to_update:
        console.print("[bold cyan]Features[/bold cyan]")
        for change in diff.features_to_update:
            old_str = str(change.old_value) if change.old_value is not None else "[dim]not set[/dim]"
            new_str = "[green]true[/green]" if change.new_value is True else "[red]false[/red]"
            console.print(f"  [yellow]~[/yellow] {change.field:<20} {old_str} → {new_str}")
        console.print()

    # Work Items (only shown when --include-data)
    if diff.workitems_to_add:
        console.print("[bold cyan]Work Items[/bold cyan]")
        for item in diff.workitems_to_add[:10]:
            title = str(item.get("title", ""))[:50]
            console.print(f"  [green]+[/green] {title}")
        if len(diff.workitems_to_add) > 10:
            console.print(f"  [dim]... and {len(diff.workitems_to_add) - 10} more[/dim]")
        console.print()

    # Summary
    console.print("[cyan]─" * 70 + "[/cyan]")
    summary = f"Additions: {diff.total_additions} · Updates: {diff.total_updates} · Preserved: {diff.total_preserved}"
    console.print(f"[bold]{summary}[/bold]")
    console.print()


def _truncate_display(s: str, max_len: int = 40) -> str:
    """Truncate string for display."""
    if len(s) > max_len:
        return s[:max_len-3] + "..."
    return s


# ============================================================================
# Step 7: Apply Changes to Local YAML
# ============================================================================


def _apply_upgrade(project_root: Path, diff: UpgradeDiff):
    """Apply upgrade changes to local schema YAML files."""
    schema_dir = project_root / DIR_SCHEMA
    schema_dir.mkdir(parents=True, exist_ok=True)
    work_dir = project_root / "work"

    _apply_types_upgrade(schema_dir, diff)
    _apply_states_upgrade(schema_dir, diff)
    _apply_labels_upgrade(schema_dir, diff)
    _apply_cycles_upgrade(work_dir, diff)
    _apply_modules_upgrade(work_dir, diff)
    _apply_features_upgrade(schema_dir, diff)
    _apply_workitems_upgrade(work_dir, diff)


def _apply_types_upgrade(schema_dir: Path, diff: UpgradeDiff):
    """Apply type changes to types.yaml."""
    from planecompose.constants import FILE_TYPES_YAML

    types_file = schema_dir / FILE_TYPES_YAML
    raw = yaml.safe_load(types_file.read_text()) if types_file.exists() else {}

    # Normalize to work_item_types root key
    if "work_item_types" in raw:
        wit_dict = raw["work_item_types"]
    else:
        wit_dict = raw or {}

    # Add new types
    for t in diff.types_to_add:
        wit_dict[t.name] = _type_to_yaml_dict(t)

    # Update existing types
    for changeset in diff.types_to_update:
        # Find entry (case-insensitive)
        entry = None
        for k in wit_dict:
            if k.lower() == changeset.name.lower():
                entry = wit_dict[k]
                break

        if entry is None:
            continue

        # Apply top-level field changes
        for change in changeset.changes:
            if change.field == "description":
                entry["description"] = change.new_value
            elif change.field == "workflow":
                entry["workflow"] = change.new_value
            elif change.field == "is_epic":
                entry["is_epic"] = change.new_value
            elif change.field == "logo":
                if change.new_value:
                    entry["logo_props"] = {
                        "icon": getattr(change.new_value, "icon", None),
                        "background_color": getattr(change.new_value, "background_color", None),
                    }

        # Apply property changes
        props_list = entry.get("properties") or []
        prop_map = {p["name"].lower(): i for i, p in enumerate(props_list)
                    if isinstance(p, dict) and "name" in p}

        # Update existing properties
        for prop_change in changeset.properties_to_update:
            idx = prop_map.get(prop_change.field.lower())
            if idx is not None:
                props_list[idx] = _field_to_yaml_dict(prop_change.new_value)

        # Add new properties
        for new_prop in changeset.properties_to_add:
            props_list.append(_field_to_yaml_dict(new_prop))

        # Update entry
        if props_list:
            entry["properties"] = props_list

    # Write back
    _write_yaml_file(types_file, {"work_item_types": wit_dict})


def _apply_states_upgrade(schema_dir: Path, diff: UpgradeDiff):
    """Apply state changes to states.yaml and workflows.yaml."""
    from planecompose.constants import FILE_STATES_YAML, FILE_WORKFLOWS_YAML

    states_file = schema_dir / FILE_STATES_YAML
    raw = yaml.safe_load(states_file.read_text()) if states_file.exists() else {}
    states_dict = raw.get("states", raw) if isinstance(raw, dict) else {}

    # Add new states
    for s in diff.states_to_add:
        entry = {"group": s.group}
        if s.color:
            entry["color"] = s.color
        states_dict[s.name] = entry

    # Update existing states
    for changeset in diff.states_to_update:
        entry = states_dict.get(changeset.name, {})
        for change in changeset.changes:
            if change.field == "color":
                entry["color"] = change.new_value
            elif change.field == "group":
                entry["group"] = change.new_value
        states_dict[changeset.name] = entry

    _write_yaml_file(states_file, {"states": states_dict})

    # Update workflows.yaml if there are new states
    if diff.states_to_add:
        workflows_file = schema_dir / FILE_WORKFLOWS_YAML
        if workflows_file.exists():
            raw_wf = yaml.safe_load(workflows_file.read_text()) or {}
            wf_dict = raw_wf.get("workflows", raw_wf)
            if wf_dict:
                # Find default workflow
                default_wf = None
                for wf_name, wf_data in wf_dict.items():
                    if isinstance(wf_data, dict) and (
                        wf_data.get("is_default")
                        or wf_name.lower() == "default workflow"
                    ):
                        default_wf = wf_data
                        break

                if default_wf is not None:
                    existing_states = set(default_wf.get("states") or [])
                    for s in diff.states_to_add:
                        existing_states.add(s.name)
                    default_wf["states"] = list(existing_states)

                _write_yaml_file(workflows_file, {"workflows": wf_dict})


def _apply_labels_upgrade(schema_dir: Path, diff: UpgradeDiff):
    """Apply label changes to labels.yaml."""
    from planecompose.constants import FILE_LABELS_YAML

    labels_file = schema_dir / FILE_LABELS_YAML
    raw = yaml.safe_load(labels_file.read_text()) if labels_file.exists() else {}
    labels_list = (
        raw.get("labels")
        if isinstance(raw, dict)
        else raw
    ) or []

    # Build lookup for updates
    label_map = {
        lbl["name"].lower(): lbl
        for lbl in labels_list
        if isinstance(lbl, dict) and "name" in lbl
    }

    # Add new labels
    for label in diff.labels_to_add:
        labels_list.append({
            "name": label.name,
            "color": label.color,
        })

    # Update existing labels
    for changeset in diff.labels_to_update:
        entry = label_map.get(changeset.name.lower())
        if entry:
            for change in changeset.changes:
                if change.field == "color":
                    entry["color"] = change.new_value
                elif change.field == "description":
                    entry["description"] = change.new_value

    _write_yaml_file(labels_file, {"labels": labels_list})


def _apply_cycles_upgrade(work_dir: Path, diff: UpgradeDiff):
    """Apply cycle changes to work/cycles.yaml (list format)."""
    if not diff.cycles_to_add and not diff.cycles_to_update:
        return
    work_dir.mkdir(parents=True, exist_ok=True)
    cycles_file = work_dir / "cycles.yaml"
    cycles_list = _load_yaml_list_with_key(cycles_file, "cycles")

    cycle_map = {
        c["name"].lower(): c
        for c in cycles_list
        if isinstance(c, dict) and "name" in c
    }

    # Add new cycles from template
    for cycle in diff.cycles_to_add:
        entry = {"name": cycle.name}
        if cycle.description:
            entry["description"] = cycle.description
        if cycle.status and cycle.status != "backlog":
            entry["status"] = cycle.status
        if cycle.start_date:
            entry["start_date"] = cycle.start_date
        if cycle.end_date:
            entry["end_date"] = cycle.end_date
        cycles_list.append(entry)

    # Update existing cycles
    for changeset in diff.cycles_to_update:
        existing_cycle = cycle_map.get(changeset.name.lower())
        if existing_cycle:
            for change in changeset.changes:
                if change.field in ("description", "status"):
                    existing_cycle[change.field] = change.new_value

    _write_yaml_file_with_key(cycles_file, "cycles", cycles_list)


def _apply_modules_upgrade(work_dir: Path, diff: UpgradeDiff):
    """Apply module changes to work/modules.yaml (list format)."""
    if not diff.modules_to_add and not diff.modules_to_update:
        return
    work_dir.mkdir(parents=True, exist_ok=True)
    modules_file = work_dir / "modules.yaml"
    modules_list = _load_yaml_list_with_key(modules_file, "modules")

    module_map = {
        m["name"].lower(): m
        for m in modules_list
        if isinstance(m, dict) and "name" in m
    }

    # Add new modules from template
    for module in diff.modules_to_add:
        entry = {"name": module.name}
        if module.description:
            entry["description"] = module.description
        if module.status and module.status != "backlog":
            entry["status"] = module.status
        if module.start_date:
            entry["start_date"] = module.start_date
        if module.end_date:
            entry["end_date"] = module.end_date
        modules_list.append(entry)

    # Update existing modules
    for changeset in diff.modules_to_update:
        existing_module = module_map.get(changeset.name.lower())
        if existing_module:
            for change in changeset.changes:
                if change.field in ("description", "status"):
                    existing_module[change.field] = change.new_value

    _write_yaml_file_with_key(modules_file, "modules", modules_list)


def _apply_workitems_upgrade(work_dir: Path, diff: UpgradeDiff):
    """Append work items from template to work/workitems.yaml."""
    if not diff.workitems_to_add:
        return
    work_dir.mkdir(parents=True, exist_ok=True)
    workitems_file = work_dir / "workitems.yaml"
    # Load existing items to avoid duplicates by title
    existing_list = _load_yaml_list_with_key(workitems_file, "workitems")
    existing_titles = {
        item["title"].lower()
        for item in existing_list
        if isinstance(item, dict) and item.get("title")
    }
    added = 0
    for item in diff.workitems_to_add:
        title = item.get("title", "")
        if not title or title.lower() in existing_titles:
            continue
        existing_list.append(item)
        existing_titles.add(title.lower())
        added += 1
    if added:
        _write_yaml_file_with_key(workitems_file, "workitems", existing_list)


def _apply_features_upgrade(schema_dir: Path, diff: UpgradeDiff):
    """Apply feature flag changes to schema/features.yaml.

    Merges template-driven changes into the existing features.yaml. Any feature
    key not in the diff is left untouched (local-only keys are preserved).
    Creates features.yaml if it doesn't exist yet.
    """
    if not diff.features_to_update:
        return

    from planecompose.parser.schema_writer import write_features_yaml as _write_features_yaml

    features_file = schema_dir / "features.yaml"

    # Load existing local features (preserve keys not in template diff)
    existing_features: dict = {}
    if features_file.exists():
        try:
            raw = yaml.safe_load(features_file.read_text())
            if isinstance(raw, dict):
                existing_features = raw.get("features", {}) or {}
        except Exception as e:
            logger.debug(f"Could not read existing features.yaml: {e}")

    # Apply template-driven changes (template wins)
    for change in diff.features_to_update:
        existing_features[change.field] = change.new_value

    _write_features_yaml(features_file, existing_features)


def _write_yaml_file_with_key(path: Path, root_key: str, items: list):
    """
    Write a YAML list file using the same format as clone_helpers:
      <root_key>:
        - name: ...

    Preserves any leading comment block that was already in the file.
    """
    # Collect leading comment lines from existing file
    header_lines = []
    if path.exists():
        for line in path.read_text().splitlines():
            if line.startswith("#") or line.strip() == "":
                header_lines.append(line)
            else:
                break  # stop at first non-comment, non-blank line

    data_yaml = yaml.dump(
        {root_key: items},
        default_flow_style=False,
        sort_keys=False,
        allow_unicode=True,
    )

    path.parent.mkdir(parents=True, exist_ok=True)
    if header_lines:
        header_block = "\n".join(header_lines).rstrip()
        path.write_text(header_block + "\n" + data_yaml)
    else:
        path.write_text(data_yaml)


def _write_yaml_file(path: Path, data: dict):
    """Write YAML file with consistent formatting."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        yaml.dump(
            data,
            f,
            default_flow_style=False,
            sort_keys=False,
            allow_unicode=True,
        )


# ============================================================================
# Helper Functions for YAML Conversion
# ============================================================================


def _type_to_yaml_dict(t: WorkItemTypeDefinition) -> dict:
    """Convert WorkItemTypeDefinition to YAML dict."""
    result = {
        "description": t.description or f"{t.name} work item",
        "workflow": getattr(t, "workflow", "default"),
    }

    if getattr(t, "is_epic", False):
        result["is_epic"] = True

    if getattr(t, "logo_props", None):
        logo = t.logo_props
        if logo:
            result["logo_props"] = {
                "icon": getattr(logo, "icon", None),
                "background_color": getattr(logo, "background_color", None),
            }

    if getattr(t, "fields", None):
        result["properties"] = [_field_to_yaml_dict(f) for f in t.fields]

    return result


def _field_to_yaml_dict(f: FieldDefinition) -> dict:
    """Convert FieldDefinition to YAML dict."""
    field_type = getattr(getattr(f, "type", None), "value", getattr(f, "type", None))
    field_type_str = str(field_type).lower() if field_type else "text"

    result = {
        "name": f.name,
        "type": field_type_str,
        "required": getattr(f, "required", False),
    }

    if getattr(f, "options", None):
        result["options"] = getattr(f, "options")

    if getattr(f, "is_multi", False):
        result["is_multi"] = True

    if getattr(f, "is_active", True) is False:
        result["is_active"] = False

    if getattr(f, "relation_type", None):
        result["relation_type"] = f.relation_type

    return result


def _convert_sdk_type_to_dict(t) -> dict:
    """Convert SDK type object to dictionary (from clone_helpers)."""
    t_id = getattr(t, "id", None)
    type_dict = {
        "id": str(t_id) if t_id else None,
        "name": getattr(t, "name", None),
        "description": getattr(t, "description", None),
        "is_epic": getattr(t, "is_epic", False),
        "is_default": getattr(t, "is_default", False),
        "level": getattr(t, "level", 0),
    }

    # Extract workspace-level type ID if present
    ws_type_id = getattr(t, "workspace_item_type_id", None)
    if ws_type_id:
        type_dict["workspace_item_type_id"] = str(ws_type_id)

    # Handle logo_props
    lp = getattr(t, "logo_props", None)
    if lp:
        model_dump = getattr(lp, "model_dump", None)
        if model_dump:
            type_dict["logo_props"] = model_dump()
        elif isinstance(lp, dict):
            type_dict["logo_props"] = lp
        else:
            type_dict["logo_props"] = {
                "icon": getattr(lp, "icon", None),
                "emoji": getattr(lp, "emoji", None),
                "in_use": getattr(lp, "in_use", None),
            }

    return type_dict


def _build_type_config(wit: dict, property_maps: dict) -> dict:
    """Build type configuration for types.yaml (from clone_helpers)."""
    # Check if workspace-linked type
    if wit.get("workspace_item_type_id"):
        return {"ws_workitemtype_id": wit["workspace_item_type_id"]}

    # Full format for standalone types
    type_config: dict[str, Any] = {
        "description": wit.get("description") or f"{wit.get('name')} work item",
        "workflow": "default",
    }

    if wit.get("id"):
        type_config["id"] = wit["id"]

    if wit.get("logo_props"):
        logo = wit["logo_props"]
        if logo.get("icon"):
            type_config["icon"] = {
                "name": logo["icon"].get("name"),
                "color": logo["icon"].get("background_color"),
            }

    if wit.get("is_epic"):
        type_config["is_epic"] = True

    if wit.get("level", 0) > 0:
        type_config["level"] = wit["level"]

    if wit.get("is_default"):
        type_config["is_default"] = True

    # Add properties
    wit_id = wit.get("id")
    if wit_id and wit_id in property_maps and property_maps[wit_id]:
        type_config["properties"] = []
        for prop_id, prop_info in property_maps[wit_id].items():
            prop_name = prop_info.get("name", "").strip()
            if not prop_name:
                continue

            prop_type = prop_info["type"]
            prop_type_value = getattr(prop_type, "value", None)
            prop_type_str = str(prop_type_value if prop_type_value else prop_type).lower()

            prop_config = {
                "name": prop_name,
                "type": prop_type_str,
                "required": False,
            }

            if prop_id:
                prop_config["id"] = prop_id

            if "option" in prop_type_str and prop_info.get("options"):
                prop_config["options"] = list(prop_info["options"].values())

            type_config["properties"].append(prop_config)

    return type_config


# _write_*_from_remote functions removed — upgrade now uses the same
# write_types_yaml / write_states_yaml / write_workflows_yaml / write_labels_yaml
# functions from clone_helpers so the output format, headers, and IDs are identical.
