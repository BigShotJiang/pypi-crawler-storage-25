"""Display rate limit statistics."""
from typing import Optional
import typer
from rich.console import Console
from rich.table import Table
from datetime import datetime

from planecompose.backend.client import PlaneApiClient
from planecompose.cli.auth import _load_config
from planecompose.config.settings import get_settings

console = Console()

app = typer.Typer(help="Rate limit statistics and monitoring")


def _validate_connection_exists(connection_id: str) -> None:
    """Validate connection exists, exit if not."""
    config = _load_config()
    connections = {c["id"]: c for c in config.get("connections", [])}
    if connection_id not in connections:
        console.print(f"\n[red]✗[/red] Connection [bold]{connection_id}[/bold] not found.")
        console.print("Run [cyan]plane auth list-connections[/cyan] to see available connections.")
        raise typer.Exit(1)


@app.command(name="stats")
def stats(
    connection: Optional[str] = typer.Option(None, "--connection", "-c", help="Connection ID"),
):
    """Display current rate limit statistics."""
    connection_id = connection or "default"
    if connection:
        _validate_connection_exists(connection_id)

    # Get persistent stats with per-minute calculation
    settings = get_settings()
    persistent_state = PlaneApiClient._get_persistent_state()
    persistent_stats = persistent_state.get_stats(connection_id)

    # Create stats table
    table = Table(title=f"Rate Limit Statistics ({connection_id})", show_header=True, header_style="bold cyan")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("Total Requests", str(persistent_stats['total_requests']))
    table.add_row("Requests Per Minute", f"{persistent_stats['requests_per_minute']:.2f}/min")
    table.add_row("Total Wait Time", f"{persistent_stats['total_wait_time']:.2f}s")

    # Time information
    if persistent_stats['started_at']:
        start_time = datetime.fromtimestamp(persistent_stats['started_at']).strftime("%H:%M:%S")
        elapsed_min = persistent_stats['elapsed_seconds'] / 60.0
        table.add_row("Tracking Period", f"{elapsed_min:.1f} minutes (since {start_time})")

    # Client throttle config
    table.add_row("Client Throttle", f"{settings.rate_limit_per_minute}/min ({settings.rate_limit_per_minute/60.0:.2f}/sec)")

    console.print()
    console.print(table)
    console.print()

    # Show message if no requests yet
    if persistent_stats['total_requests'] == 0:
        console.print("[dim]No requests recorded yet for this connection[/dim]")


@app.command(name="reset")
def reset(
    connection: Optional[str] = typer.Option(None, "--connection", "-c", help="Connection ID"),
):
    """Reset rate limit statistics."""
    connection_id = connection or "default"
    if connection:
        _validate_connection_exists(connection_id)

    persistent_state = PlaneApiClient._get_persistent_state()
    persistent_state.reset(connection_id)

    rate_limiter = PlaneApiClient.get_rate_limiter(connection_id)
    rate_limiter.reset()

    console.print(f"[green]✓[/green] Rate limit statistics reset for {connection_id}")
