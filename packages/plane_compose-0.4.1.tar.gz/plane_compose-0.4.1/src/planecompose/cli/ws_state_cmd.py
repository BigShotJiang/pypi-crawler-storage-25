"""Workspace state commands - inspect and manage workspace sync state.

Provides visibility into the .plane/state.json file that tracks
workspace-level sync status for members, work item types, releases, etc.

The `show` output uses dotted-path notation that matches exactly what the
`remove` command accepts — copy any line's path and paste it into remove.
"""
import typer
import json
from pathlib import Path
from rich.console import Console
from rich.panel import Panel

console = Console()

app = typer.Typer(help="Inspect and manage workspace sync state")

# ── Path schema ──────────────────────────────────────────────────────────────
# Defines how to navigate the nested state dict for remove/show.
#
# Two-level: state[top][sub][key]   e.g. workitemtypes.types.Task
# One-level: state[top][key]        e.g. members.user@domain.com
#                                        features.project_grouping
#
# Keys may contain dots (release names like "R1.0.6", emails, tag versions).
# The schema is authoritative — unknown paths are rejected cleanly.

_TWO_LEVEL: dict[str, set[str]] = {
    "workitemtypes": {"types", "properties", "hierarchy"},
    "projects":      {"labels", "states"},
    "initiatives":   {"labels"},
    "releases":      {"tags", "labels"},
    "work":          {"releases"},
    "customers":     {"properties"},
}
_ONE_LEVEL: set[str] = {"members", "features", "relations"}


def _resolve_ws_dir(workspace: str | None) -> Path:
    """Resolve the workspace directory from an optional name/path argument.

    Resolution order:
    1. No argument → current directory
    2. Argument is an existing path → use as-is
    3. Argument is a name → look for it as a sub-folder of the current directory
    """
    if not workspace:
        return Path.cwd()
    candidate = Path(workspace)
    if candidate.is_absolute():
        return candidate.resolve()
    # Try as sub-folder of cwd first (most common: `plane ws state show compose-cli`
    # run from the parent directory that contains the cloned workspace folder)
    sub = Path.cwd() / workspace
    if sub.exists():
        return sub.resolve()
    # Fall back to treating it as a relative/absolute path
    return candidate.resolve()


def _resolve_path(state: dict, path_str: str) -> tuple[dict, str] | None:
    """Resolve a dotted path to (parent_dict, key).

    Returns (parent, key) if found so the caller can do del parent[key].
    Returns None if the path is invalid or the key is not present.
    """
    first_dot = path_str.find(".")
    if first_dot == -1:
        return None

    top = path_str[:first_dot]
    rest = path_str[first_dot + 1:]

    if top in _ONE_LEVEL:
        # One-level: rest is the key (may contain dots, e.g. email or bool feature)
        parent = state.get(top)
        if isinstance(parent, dict) and rest in parent:
            return parent, rest
        return None

    if top in _TWO_LEVEL:
        # Two-level: split rest into sub + key
        second_dot = rest.find(".")
        if second_dot == -1:
            return None
        sub = rest[:second_dot]
        key = rest[second_dot + 1:]
        if sub not in _TWO_LEVEL[top]:
            return None
        parent = state.get(top, {}).get(sub)
        if isinstance(parent, dict) and key in parent:
            return parent, key
        return None

    return None


def _load_workspace_state(ws_dir: Path) -> dict | None:
    """Load workspace state file, return None if not found."""
    state_file = ws_dir / ".plane" / "state.json"
    if not state_file.exists():
        return None
    try:
        return dict(json.loads(state_file.read_text()))
    except Exception as e:
        console.print(f"[red]Error loading state:[/red] {e}")
        return None


def _save_workspace_state(ws_dir: Path, state: dict) -> None:
    """Save workspace state file."""
    state_file = ws_dir / ".plane" / "state.json"
    state_file.parent.mkdir(parents=True, exist_ok=True)
    state_file.write_text(json.dumps(state, indent=2))


def _emit_group(entries: list[tuple[str, str]]) -> None:
    """Print a blank-line-separated group of 'dotted.path = value' lines."""
    if not entries:
        return
    console.print()
    for path, value in entries:
        console.print(f"  [cyan]{path}[/cyan] = [dim]{value}[/dim]")


@app.command("show")
def show(
    workspace: str | None = typer.Argument(
        None, help="Workspace folder name or path (default: current directory)"
    ),
    json_output: bool = typer.Option(False, "--json", help="Output raw state.json"),
):
    """
    Show workspace sync state as copyable dotted paths.

    Each line is   dotted.path = value
    Copy any path and pass it directly to 'plane ws state remove'.

    Examples:
        plane ws state show                     # current directory
        plane ws state show compose-cli         # workspace by name (from parent dir)
        plane ws state show --json              # raw JSON
    """
    try:
        ws_dir = _resolve_ws_dir(workspace)

        state = _load_workspace_state(ws_dir)
        if state is None:
            console.print("[yellow]No workspace state file found.[/yellow]")
            console.print("Run [cyan]plane ws clone[/cyan] to initialize workspace state.")
            return

        if json_output:
            console.print(json.dumps(state, indent=2))
            return

        console.print()
        console.print(
            Panel(
                f"[bold]File:[/bold] {ws_dir / '.plane/state.json'}\n"
                f"[bold]Last Sync:[/bold] {state.get('last_sync', 'never')}",
                title="[bold]Workspace Sync State[/bold]",
                border_style="blue",
            )
        )

        # workitemtypes.types.*
        _emit_group([
            (f"workitemtypes.types.{name}", str(tid))
            for name, tid in state.get("workitemtypes", {}).get("types", {}).items()
        ])

        # workitemtypes.properties.*
        _emit_group([
            (f"workitemtypes.properties.{name}", str(pid))
            for name, pid in state.get("workitemtypes", {}).get("properties", {}).items()
        ])

        # members.*
        _emit_group([
            (f"members.{email}", str(mid))
            for email, mid in state.get("members", {}).items()
        ])

        # projects.labels.*
        _emit_group([
            (f"projects.labels.{name}", str(lid))
            for name, lid in state.get("projects", {}).get("labels", {}).items()
        ])

        # initiatives.labels.*
        _emit_group([
            (f"initiatives.labels.{name}", str(lid))
            for name, lid in state.get("initiatives", {}).get("labels", {}).items()
        ])

        # releases.tags.*
        _emit_group([
            (f"releases.tags.{version}", str(tid))
            for version, tid in state.get("releases", {}).get("tags", {}).items()
        ])

        # releases.labels.*
        _emit_group([
            (f"releases.labels.{name}", str(lid))
            for name, lid in state.get("releases", {}).get("labels", {}).items()
        ])

        # projects.states.*
        _emit_group([
            (f"projects.states.{name}", str(sid))
            for name, sid in state.get("projects", {}).get("states", {}).items()
        ])

        # relations.*
        _emit_group([
            (f"relations.{name}", str(rid))
            for name, rid in state.get("relations", {}).items()
        ])

        # customers.properties.*
        # Value may be a plain id string (old format) or a {id, type} dict (new format).
        cust_rows = []
        for prop_name, prop_val in state.get("customers", {}).get("properties", {}).items():
            if isinstance(prop_val, dict):
                prop_id = prop_val.get("id", "?")
                prop_type = prop_val.get("type", "")
                display = f"{prop_id}  [{prop_type}]" if prop_type else prop_id
            else:
                display = str(prop_val)
            cust_rows.append((f"customers.properties.{prop_name}", display))
        _emit_group(cust_rows)

        # features.*
        _emit_group([
            (f"features.{key}", str(val).lower())
            for key, val in state.get("features", {}).items()
        ])

        # work.releases.*
        _emit_group([
            (f"work.releases.{name}", str(rid))
            for name, rid in state.get("work", {}).get("releases", {}).items()
        ])

        console.print()

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command("reset")
def reset(
    workspace: str | None = typer.Argument(
        None, help="Workspace folder name or path (default: current directory)"
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Reset without confirmation"),
):
    """
    Reset workspace sync state (delete state file).

    This will cause the next workspace operation to treat all items as new.
    Use with caution — may cause duplicate items if remote already has data.

    Examples:
        plane ws state reset                    # Reset current directory
        plane ws state reset compose-cli        # Reset workspace by name (from parent dir)
        plane ws state reset --force            # Reset without confirmation
    """
    try:
        ws_dir = _resolve_ws_dir(workspace)

        state = _load_workspace_state(ws_dir)
        if state is None:
            console.print("[yellow]No workspace state file to reset.[/yellow]")
            return

        if not force:
            from rich.prompt import Confirm

            wit_types = len(state.get("workitemtypes", {}).get("types", {}))
            members = len(state.get("members", {}))
            releases = len(state.get("work", {}).get("releases", {}))
            cust_props = len(state.get("customers", {}).get("properties", {}))
            relations = len(state.get("relations", {}))

            console.print("\n[yellow]Warning:[/yellow] This will delete tracking for:")
            console.print(f"  - {wit_types} work item types")
            console.print(f"  - {members} members")
            console.print(f"  - {releases} releases")
            if cust_props:
                console.print(f"  - {cust_props} customer properties")
            if relations:
                console.print(f"  - {relations} relation definitions")
            console.print()
            console.print("[yellow]The next operation may create duplicates if items already exist in Plane.[/yellow]")
            console.print()

            if not Confirm.ask("Are you sure you want to reset workspace state?"):
                console.print("[yellow]Cancelled[/yellow]")
                raise typer.Exit(0)

        state_file = ws_dir / ".plane" / "state.json"
        state_file.unlink(missing_ok=True)
        console.print("[green]Workspace state reset successfully.[/green]")
        console.print("Next operation will treat all workspace items as new.")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command("remove")
def remove(
    path_str: str = typer.Argument(
        ...,
        help="Dotted path as shown by 'plane ws state show', e.g. 'work.releases.R1.0.6' or 'releases.tags.v1.0.4'",
    ),
    workspace: str | None = typer.Option(
        None, "--workspace", "-w",
        help="Workspace folder name or path (default: current directory)",
    ),
):
    """
    Remove a specific entry from workspace state tracking.

    Use the exact dotted path shown by 'plane ws state show' — copy and paste.

    Examples:
        plane ws state remove "workitemtypes.types.Task"
        plane ws state remove "workitemtypes.properties.severity"
        plane ws state remove "members.user@domain.com"
        plane ws state remove "releases.tags.v1.0.4"
        plane ws state remove "releases.labels.Blue"
        plane ws state remove "work.releases.R1.0.6"
        plane ws state remove "features.work_item_types"
        plane ws state remove "initiatives.labels.MyLabel"
        plane ws state remove "projects.labels.Engineering"
        plane ws state remove "projects.states.Backlog"
        plane ws state remove "relations.Duplicate"
        plane ws state remove "customers.properties.zone"
        plane ws state remove "work.releases.R1.0.6" --workspace compose-cli
    """
    try:
        ws_dir = _resolve_ws_dir(workspace)

        state = _load_workspace_state(ws_dir)
        if state is None:
            console.print("[yellow]No workspace state file found.[/yellow]")
            raise typer.Exit(1)

        result = _resolve_path(state, path_str)
        if result is None:
            console.print(f"[yellow]Not found:[/yellow] {path_str}")
            console.print(
                "Run [cyan]plane ws state show[/cyan] to see valid paths."
            )
            raise typer.Exit(1)

        parent, key = result
        del parent[key]
        _save_workspace_state(ws_dir, state)
        console.print(f"[green]Removed:[/green] {path_str}")

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command("clear-items")
def clear_items(
    workspace: str | None = typer.Argument(
        None, help="Workspace folder name or path (default: current directory)"
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Clear without confirmation"),
):
    """
    Clear workspace state for a specific section (non-destructive).

    Use dot notation to clear specific subsections.
    """
    try:
        ws_dir = _resolve_ws_dir(workspace)  # noqa: F841 — resolved but not used below

        console.print("[yellow]Note:[/yellow] Use 'plane ws state remove' to remove individual items")
        console.print("Or use 'plane ws state reset --force' to clear entire state file")
        raise typer.Exit(0)

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
