"""Helper functions for clone command.

This module provides utilities for:
- Converting SDK objects to dicts
- Writing schema YAML files
- Converting work items to YAML format
"""
from typing import Any

import yaml
from pathlib import Path


def _write_yaml_with_header(path: Path, data: object, header: str = "") -> None:
    """Write YAML with consistent formatting and optional header comments."""
    with open(path, "w") as f:
        if header:
            f.write(header)
            f.write("\n")
        yaml.dump(
            data,
            f,
            default_flow_style=False,
            sort_keys=False,
            allow_unicode=True,
        )


def convert_sdk_type_to_dict(t) -> dict:
    """Convert an SDK type object to a dictionary.

    Args:
        t: SDK type object with attributes like id, name, description, etc.

    Returns:
        Dictionary representation of the type
    """
    t_id = getattr(t, 'id', None)
    type_dict = {
        'id': str(t_id) if t_id else None,
        'name': getattr(t, 'name', None),
        'description': getattr(t, 'description', None),
        'is_epic': getattr(t, 'is_epic', False),
        'is_default': getattr(t, 'is_default', False),
        'level': getattr(t, 'level', 0),
    }

    # Extract workspace-level type ID if type is linked to a workspace-level type
    ws_type_id = getattr(t, 'workspace_item_type_id', None)
    if ws_type_id:
        type_dict['workspace_item_type_id'] = str(ws_type_id)

    # Handle logo_props (SDK may return object or dict)
    lp = getattr(t, 'logo_props', None)
    if lp:
        model_dump = getattr(lp, 'model_dump', None)
        if model_dump:
            type_dict['logo_props'] = model_dump()
        elif isinstance(lp, dict):
            type_dict['logo_props'] = lp
        else:
            type_dict['logo_props'] = {
                'icon': getattr(lp, 'icon', None),
                'emoji': getattr(lp, 'emoji', None),
                'in_use': getattr(lp, 'in_use', None),
            }

    return type_dict


def build_type_config(wit: dict, property_maps: dict) -> dict:
    """Build type configuration for types.yaml with nested properties.

    For workspace-linked types (those with workspace_item_type_id), returns minimal format:
        {
          'ws_workitemtype_id': workspace_type_id
        }

    For standalone types, returns full format with description, workflow, and properties.

    Args:
        wit: Work item type dict (from convert_sdk_type_to_dict)
        property_maps: Property maps from backend.build_property_maps()

    Returns:
        Type configuration dict for YAML output
    """
    # Check if this is a workspace-linked type
    if wit.get('workspace_item_type_id'):
        # Minimal format for workspace-linked types (using schema field name)
        type_config: dict[str, Any] = {
            'ws_workitemtype_id': wit['workspace_item_type_id']
        }
        return type_config

    # Full format for standalone types
    type_config = {  # type already annotated above
        'description': wit.get('description') or f"{wit.get('name')} work item",
        'workflow': 'default',
    }

    # Embed remote ID for idempotent PATCH operations
    if wit.get('id'):
        type_config['id'] = wit['id']

    # Add rich metadata
    if wit.get('logo_props'):
        logo = wit['logo_props']
        if logo.get('icon'):
            type_config['icon'] = {
                'name': logo['icon'].get('name'),
                'color': logo['icon'].get('background_color'),
            }
        if logo.get('in_use') == 'emoji' and logo.get('emoji'):
            type_config['emoji'] = logo['emoji'].get('value')

    if wit.get('is_epic'):
        type_config['is_epic'] = True
    if wit.get('level', 0) > 0:
        type_config['level'] = wit['level']
    if wit.get('is_default'):
        type_config['is_default'] = True

    # Add properties from property_maps (nested under type, matching init structure)
    wit_id = wit.get('id')
    if wit_id and wit_id in property_maps and property_maps[wit_id]:
        type_config['properties'] = []
        for prop_id, prop_info in property_maps[wit_id].items():
            # Skip properties with empty names (defensive handling)
            prop_name = prop_info.get('name', '').strip()
            if not prop_name:
                continue

            prop_type = prop_info['type']
            prop_type_value = getattr(prop_type, 'value', None)
            prop_type = str(prop_type_value if prop_type_value else prop_type).lower()

            prop_config = {
                'name': prop_name,
                'type': prop_type,
                'required': False,
            }

            # Embed property ID for idempotent PATCH
            if prop_id:
                prop_config['id'] = prop_id

            # Add options list for OPTION type properties
            if 'option' in prop_type and prop_info.get('options'):
                options_list = list(prop_info['options'].values())
                if options_list:
                    prop_config['options'] = options_list

            if prop_info.get('is_multi'):
                prop_config['is_multi'] = True

            if 'relation' in prop_type and prop_info.get('relation_type'):
                prop_config['relation_type'] = prop_info['relation_type']

            type_config['properties'].append(prop_config)

    return type_config


def build_clone_state(
    types_data: list[dict[str, Any]],
    states_list: list[Any],
    labels_list: list[Any],
    cycles_list: list[Any] | None = None,
    modules_list: list[Any] | None = None,
    workflows_list: list[Any] | None = None,
    property_maps: dict[str, dict[str, Any]] | None = None,
    last_sync: str = "",
    work_items_raw: list[Any] | None = None,
    work_items_dicts: list[dict] | None = None,
) -> dict[str, Any]:
    """Build initial clone state with schema mappings and work item tracking.

    work_items_raw: raw SDK objects (have .id = UUID, .sequence_id = int)
    work_items_dicts: converted dicts (have 'id' = sequence ID like 'P103-1')
    Both must be provided and in the same order to populate work item tracking.

    Args:
        types_data: List of type dicts with 'name' and 'id'
        states_list: List of state SDK objects
        labels_list: List of label SDK objects
        cycles_list: Optional list of cycle SDK objects
        modules_list: Optional list of module SDK objects
        workflows_list: Optional list of workflow SDK objects
        property_maps: Optional property maps from backend.build_property_maps()
        last_sync: ISO timestamp of last sync
    """
    schema_types: dict[str, str] = {}
    for wit in types_data:
        if wit.get("name") and wit.get("id"):
            schema_types[wit["name"]] = wit["id"]

    schema_states: dict[str, str] = {}
    for state in states_list:
        state_id = str(getattr(state, "id", None)) if getattr(state, "id", None) else None
        state_name = getattr(state, "name", None)
        if state_id and state_name:
            schema_states[state_name] = state_id

    schema_labels: dict[str, str] = {}
    for label in labels_list:
        label_id = str(getattr(label, "id", None)) if getattr(label, "id", None) else None
        label_name = getattr(label, "name", None)
        if label_id and label_name:
            schema_labels[label_name] = label_id

    schema_workflows: dict[str, str] = {}
    if workflows_list:
        for workflow in workflows_list:
            workflow_id = str(getattr(workflow, "id", None) or getattr(workflow, "remote_id", None)) if getattr(workflow, "id", None) or getattr(workflow, "remote_id", None) else None
            workflow_name = getattr(workflow, "name", None)
            if workflow_id and workflow_name:
                schema_workflows[workflow_name] = workflow_id

    schema_cycles: dict[str, str] = {}
    if cycles_list:
        for cycle in cycles_list:
            cycle_id = str(getattr(cycle, "id", None)) if getattr(cycle, "id", None) else None
            cycle_name = getattr(cycle, "name", None)
            if cycle_id and cycle_name:
                schema_cycles[cycle_name] = cycle_id

    schema_modules: dict[str, str] = {}
    if modules_list:
        for module in modules_list:
            module_id = str(getattr(module, "id", None)) if getattr(module, "id", None) else None
            module_name = getattr(module, "name", None)
            if module_id and module_name:
                schema_modules[module_name] = module_id

    # Build properties mapping: type_id -> {property_name -> property_id}
    # This enables idempotent property push/sync in the future
    schema_properties: dict[str, dict[str, str]] = {}
    if property_maps:
        for type_id, props in property_maps.items():
            schema_properties[type_id] = {}
            for prop_id, prop_info in props.items():
                prop_name = prop_info.get('name')
                if prop_name and prop_id:
                    schema_properties[type_id][prop_name] = prop_id

    # Build work item tracking entries so push knows UUIDs and does PATCH not POST.
    # Content hash is "" at clone time — planner will PATCH on first push (not create duplicates).
    work_items_state: dict[str, Any] = {}
    if work_items_raw and work_items_dicts:
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        for idx, (raw_item, item_dict) in enumerate(zip(work_items_raw, work_items_dicts)):
            seq_id = item_dict.get("id")          # e.g. "P103-1"
            uuid = str(raw_item.id) if hasattr(raw_item, "id") else None
            if seq_id and uuid:
                work_items_state[f"id:{seq_id}"] = {
                    "remote_id": uuid,
                    "content_hash": "",
                    "source": f"work/workitems.yaml:{idx}",
                    "last_synced": now,
                }

    return {
        "last_sync": last_sync,
        "types": schema_types,
        "states": schema_states,
        "labels": schema_labels,
        "workflows": schema_workflows if schema_workflows else {},
        "cycles": schema_cycles,
        "modules": schema_modules,
        "properties": schema_properties if schema_properties else {},
        "work_items": work_items_state,
    }


def write_types_yaml(target_dir: Path, types_data: list[dict], property_maps: dict) -> None:
    """Write types.yaml schema file with nested properties (matching init structure).

    Args:
        target_dir: Project directory
        types_data: List of type dicts from SDK
        property_maps: Property maps from backend
    """
    header = """# Work Item Type Definitions
#
# NOTE: Base work item types (Bug, Feature, Task, etc) are automatically created.
# This file can be used to add custom properties to existing types or create custom types.
#
# Example:
# work_item_types:
#   Bug:
#     description: A defect or issue requiring fix
#     id: <uuid>
#   Feature:
#     description: Net-new functionality or capability
#     id: <uuid>"""
    types_yaml = {}
    for wit in types_data:
        if not wit.get('name'):
            continue
        type_config = build_type_config(wit, property_maps)
        # Only embed remote ID for non-workspace-linked types
        # Workspace-linked types use ws_workitemtype_id instead
        if wit.get('id') and not wit.get('workspace_item_type_id'):
            type_config['id'] = wit['id']
        types_yaml[wit['name']] = type_config

    _write_yaml_with_header(target_dir / "schema" / "types.yaml", {"work_item_types": types_yaml}, header=header)


def write_states_yaml(target_dir: Path, states_list: list) -> None:
    """Write states.yaml — delegates to the canonical common writer."""
    from planecompose.parser.schema_writer import write_states_yaml as _write
    _write(target_dir / "schema" / "states.yaml", states_list)


def write_workflows_yaml(target_dir: Path, workflows_list: list, type_id_to_name: dict | None = None) -> None:
    """Write workflows.yaml — clone-aware wrapper around the canonical writer.

    Handles two concerns that are specific to ``plane clone`` / ``plane pull``:

    1. **work_item_types ID→name conversion** — the API may return UUIDs in
       ``work_item_types`` even after ``parse_workflow_from_api`` has run
       (e.g. when the type_id_to_name map was incomplete at fetch time).
       We resolve them here as a safety net.

    2. **State preservation** — the Plane public API does not always return a
       workflow's state list.  On re-clones we read the existing local
       ``workflows.yaml`` and fall back to the local state dict (matched by
       remote_id first, then by name) so user edits are not wiped.

    The actual YAML serialisation is delegated to
    ``schema_writer.write_workflows_yaml`` / ``workflow_to_dict`` so the
    format is identical across all write paths.

    Args:
        target_dir: Project directory (schema/ is a subdirectory).
        workflows_list: WorkflowDefinition objects (from ``backend.fetch_workflows``).
        type_id_to_name: Optional UUID → name map for work_item_types resolution.
    """
    from planecompose.parser.schema_writer import (
        workflow_to_dict,
        WORKFLOWS_YAML_HEADER,
    )

    type_id_to_name = type_id_to_name or {}

    # ── Read existing local workflows.yaml for state preservation ──────────
    existing_yaml: dict = {}
    workflows_path = target_dir / "schema" / "workflows.yaml"
    if workflows_path.exists():
        try:
            loaded = yaml.safe_load(workflows_path.read_text()) or {}
            if isinstance(loaded, dict):
                existing_yaml = loaded.get('workflows', loaded)
        except Exception:
            existing_yaml = {}
    existing_by_id: dict = {
        entry.get('id'): entry
        for entry in existing_yaml.values()
        if isinstance(entry, dict) and entry.get('id')
    }

    # ── Build per-workflow dicts ────────────────────────────────────────────
    workflows_dict: dict = {}
    for workflow in workflows_list:
        # Core serialisation (metadata + states + rules).
        entry = workflow_to_dict(workflow)

        # ── work_item_types: resolve any remaining UUIDs → names ───────────
        raw_types = entry.get('work_item_types') or []
        if raw_types and type_id_to_name:
            resolved = []
            for wit in raw_types:
                if isinstance(wit, str) and wit in type_id_to_name:
                    resolved.append(type_id_to_name[wit])
                else:
                    resolved.append(wit)
            entry['work_item_types'] = resolved

        # ── State preservation: fall back to local when API returned none ──
        if not entry.get('states'):
            wf_id = getattr(workflow, 'remote_id', None) or getattr(workflow, 'id', None)
            wf_name = getattr(workflow, 'name', None)
            existing_entry = (
                existing_by_id.get(str(wf_id)) if wf_id else None
            ) or (
                existing_yaml.get(wf_name) if wf_name else None
            )
            if isinstance(existing_entry, dict):
                preserved = existing_entry.get('states')
                if isinstance(preserved, dict) and preserved:
                    # New format — use as-is.
                    entry['states'] = preserved
                elif isinstance(preserved, list) and preserved:
                    # Old format (list of names) — migrate to new dict format.
                    preserved_trans = existing_entry.get('transitions') or {}
                    migrated: dict = {}
                    for sname in preserved:
                        sname = str(sname)
                        old_trans = preserved_trans.get(sname)
                        if not old_trans:
                            migrated[sname] = {}
                        elif isinstance(old_trans, list) and old_trans:
                            t0_raw = old_trans[0]
                            migrated[sname] = {
                                'flow_type': t0_raw.get('type', 'transition'),
                                'to': [t.get('to', '') for t in old_trans if t.get('to')],
                                'approvers': list(t0_raw.get('approvers') or []),
                                'conditions': {'pre': [], 'post': []},
                            }
                        else:
                            migrated[sname] = {}
                    entry['states'] = migrated

        wf_name = getattr(workflow, 'name', f'workflow_{len(workflows_dict)}')
        workflows_dict[wf_name] = entry

    _write_yaml_with_header(
        target_dir / "schema" / "workflows.yaml",
        {"workflows": workflows_dict},
        header=WORKFLOWS_YAML_HEADER,
    )


def write_labels_yaml(target_dir: Path, labels_list: list) -> None:
    """Write labels.yaml — delegates to the canonical common writer."""
    from planecompose.parser.schema_writer import write_labels_yaml as _write
    _write(target_dir / "schema" / "labels.yaml", labels_list)


def write_features_yaml(target_dir: Path, features: dict) -> None:
    """Write schema/features.yaml with project feature toggles.

    Args:
        target_dir: Project root directory (schema/ is a subdirectory).
        features:   Dict mapping feature name → bool from the API.
    """
    from planecompose.parser.schema_writer import write_features_yaml as _write
    _write(target_dir / "schema" / "features.yaml", features)


# ---------------------------------------------------------------------------
# Cycles
# ---------------------------------------------------------------------------

def write_cycles_yaml(
    target_dir: Path,
    cycles: list,
    cycle_items_map: dict[str, list[str]],  # cycle_id -> [sequence_ids]
) -> None:
    """Write cycles.yaml with cycle metadata and item membership.

    Args:
        target_dir: Project directory
        cycles: List of raw cycle SDK objects
        cycle_items_map: Map of cycle_id to list of work item sequence IDs (e.g. IW-1)
    """
    cycles_data = []
    for cycle in cycles:
        cycle_id = str(getattr(cycle, 'id', '') or '')
        entry: dict = {'name': getattr(cycle, 'name', '')}

        # Embed the remote ID so subsequent pushes PATCH instead of creating duplicates
        if cycle_id:
            entry['id'] = cycle_id

        description = getattr(cycle, 'description', None)
        if description:
            entry['description'] = description
        start_date = getattr(cycle, 'start_date', None)
        if start_date:
            entry['start_date'] = start_date
        end_date = getattr(cycle, 'end_date', None)
        if end_date:
            entry['end_date'] = end_date
        # status is computed by Plane from dates — don't write it to YAML
        items = cycle_items_map.get(cycle_id, [])
        if items:
            entry['work_items'] = items
        cycles_data.append(entry)

    work_dir = target_dir / 'work'
    work_dir.mkdir(parents=True, exist_ok=True)

    header = """# Cycle Definitions
# Cycles represent time-boxed sprints or iterations.
# Operational data — lives in work/ (not schema/).
#
# Example:
# cycles:
#   - name: Sprint 1
#     description: First sprint — core setup and scaffolding
#     start_date: '2024-01-01'
#     end_date: '2024-01-14'
#     status: backlog
#     id: <uuid>
#   - name: Sprint 2
#     description: Second sprint — feature development
#     start_date: '2024-01-15'
#     end_date: '2024-01-28'
#     id: <uuid>"""
    _write_yaml_with_header(work_dir / 'cycles.yaml', {"cycles": cycles_data}, header=header)


# ---------------------------------------------------------------------------
# Modules
# ---------------------------------------------------------------------------

def write_modules_yaml(
    target_dir: Path,
    modules: list,
    module_items_map: dict[str, list[str]],  # module_id -> [sequence_ids]
) -> None:
    """Write modules.yaml with module metadata and item membership.

    Args:
        target_dir: Project directory
        modules: List of raw module SDK objects
        module_items_map: Map of module_id to list of work item sequence IDs (e.g. IW-1)
    """
    modules_data = []
    for module in modules:
        module_id = str(getattr(module, 'id', '') or '')
        entry: dict = {'name': getattr(module, 'name', '')}

        # Embed the remote ID so subsequent pushes PATCH instead of creating duplicates
        if module_id:
            entry['id'] = module_id

        description = getattr(module, 'description_text', None) or getattr(module, 'description', None)
        if description:
            entry['description'] = description
        start_date = getattr(module, 'start_date', None)
        if start_date:
            entry['start_date'] = start_date
        target_date = getattr(module, 'target_date', None)
        if target_date:
            entry['end_date'] = target_date
        status = getattr(module, 'status', None)
        if status:
            entry['status'] = str(status)
        items = module_items_map.get(module_id, [])
        if items:
            entry['work_items'] = items
        modules_data.append(entry)

    work_dir = target_dir / 'work'
    work_dir.mkdir(parents=True, exist_ok=True)

    header = """# Module Definitions
# Modules group related work items by feature area or milestone.
# Operational data — lives in work/ (not schema/).
#
# Example:
# modules:
#   - name: Authentication
#     description: User login, OAuth, and session management
#     start_date: '2024-01-01'
#     end_date: '2024-03-31'
#     status: backlog
#     id: <uuid>
#   - name: API Integration
#     description: Third-party API integrations and webhooks
#     start_date: '2024-02-01'
#     end_date: '2024-03-15'
#     id: <uuid>"""
    _write_yaml_with_header(work_dir / 'modules.yaml', {"modules": modules_data}, header=header)


def convert_work_item_to_dict(
    item,
    project_identifier: str,
    type_map: dict,
    state_map: dict,
    label_map: dict,
    work_item_properties: dict,
) -> dict:
    """Convert SDK work item to YAML dict format.

    Args:
        item: SDK work item object
        project_identifier: Project identifier for building item IDs
        type_map: Map of type UUID to type name
        state_map: Map of state UUID to state name
        label_map: Map of label UUID to label name
        work_item_properties: Pre-fetched property values by item ID

    Returns:
        Work item dict for YAML output
    """
    # Get type name from type_id
    type_id = getattr(item, 'type_id', None)
    type_name = type_map.get(str(type_id), 'task') if type_id else 'task'

    item_dict = {
        'title': item.name,
        'type': type_name,
    }

    # Add sequence ID for stable tracking
    sequence_id = getattr(item, 'sequence_id', None)
    if sequence_id:
        item_dict = {'id': f"{project_identifier}-{sequence_id}", **item_dict}

    # Core fields
    description_html = getattr(item, 'description_html', None)
    if description_html:
        item_dict['description'] = description_html

    state = getattr(item, 'state', None)
    if state:
        state_name = state_map.get(str(state))
        if state_name:
            item_dict['state'] = state_name

    priority = getattr(item, 'priority', None)
    if priority:
        item_dict['priority'] = priority

    labels = getattr(item, 'labels', None)
    if labels:
        label_names = [label_map[str(lid)] for lid in labels if str(lid) in label_map]
        if label_names:
            item_dict['labels'] = label_names

    # Dates
    start_date = getattr(item, 'start_date', None)
    if start_date:
        item_dict['start_date'] = start_date

    target_date = getattr(item, 'target_date', None)
    if target_date:
        item_dict['due_date'] = target_date

    # Parent relationship
    parent_id = getattr(item, 'parent_id', None) or getattr(item, 'parent', None)
    if parent_id:
        item_dict['parent'] = str(parent_id)

    # Assignees
    assignees = getattr(item, 'assignees', None)
    if assignees:
        assignee_list = [str(a) for a in assignees]
        if assignee_list:
            item_dict['assignees'] = assignee_list

    # Dependencies & Relationships
    blocked_issues = getattr(item, 'blocked_issues', None)
    if blocked_issues is None:
        blocked_issues = getattr(item, 'blocked_by', None)
    if blocked_issues:
        blocked_by = [str(b) for b in blocked_issues]
        if blocked_by:
            item_dict['blocked_by'] = blocked_by

    blocker_issues = getattr(item, 'blocker_issues', None)
    if blocker_issues is None:
        blocker_issues = getattr(item, 'blocking', None)
    if blocker_issues:
        blocking = [str(b) for b in blocker_issues]
        if blocking:
            item_dict['blocking'] = blocking

    duplicate_to = getattr(item, 'duplicate_to', None)
    if duplicate_to is None:
        duplicate_values = getattr(item, 'duplicate', None)
        duplicate_to = duplicate_values[0] if duplicate_values else None
    if duplicate_to:
        item_dict['duplicate_of'] = str(duplicate_to)

    related_issues = getattr(item, 'related_issues', None)
    if related_issues is None:
        related_issues = getattr(item, 'relates_to', None)
    if related_issues:
        relates_to = [str(r) for r in related_issues]
        if relates_to:
            item_dict['relates_to'] = relates_to

    # Add pre-fetched properties
    item_id = getattr(item, 'id', None)
    if item_id:
        item_id_str = str(item_id)
        if item_id_str in work_item_properties and work_item_properties[item_id_str]:
            item_dict['properties'] = work_item_properties[item_id_str]

    return item_dict


def format_timing_breakdown(phase_times: dict) -> str:
    """Format timing breakdown for success message.

    Args:
        phase_times: Dictionary of phase names to elapsed times

    Returns:
        Formatted string for display
    """
    timing_lines = []
    if 'types' in phase_times:
        timing_lines.append(f"  Types: {phase_times['types']:.1f}s")
    if 'states' in phase_times:
        timing_lines.append(f"  States: {phase_times['states']:.1f}s")
    if 'labels' in phase_times:
        timing_lines.append(f"  Labels: {phase_times['labels']:.1f}s")
    if 'work_items' in phase_times:
        timing_lines.append(f"  Work Items: {phase_times['work_items']:.1f}s")
    if 'properties' in phase_times:
        timing_lines.append(f"  Properties: {phase_times['properties']:.1f}s")
    return "\n".join(timing_lines)


