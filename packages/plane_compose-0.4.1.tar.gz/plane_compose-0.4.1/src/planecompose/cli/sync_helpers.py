"""Helper functions for syncing workspace data before commands."""

from planecompose.config.context import ProjectContext
from planecompose.backend.client import PlaneApiClient
from planecompose.backend.workspace_sync import (
    sync_workspace_features,
    sync_workspace_members,
    sync_workspace_work_item_types,
)
from planecompose.utils.logger import get_logger
from planecompose.utils.project import update_workspace_yaml
from rich.console import Console

logger = get_logger()
console = Console()


def sync_workspace_context(
    context: ProjectContext, verbose: bool = False, save_to_yaml: bool = True
) -> None:
    """
    Sync workspace data (features and work item types) at the start of a command.

    This ensures workspace feature flags and workspace-level work item types are
    up-to-date before running any schema or sync operations.

    Args:
        context: ProjectContext to sync
        verbose: If True, log when features are updated
        save_to_yaml: If True, persist workspace config to workspace.yaml
    """
    client = PlaneApiClient(
        api_url=context.config.api_url,
        api_key=context.api_key,
        token_type=context.token_type,
        connection_id=context.config.connection_id or "default",
    )

    # Sync workspace features
    features_updated = sync_workspace_features(context, client)
    if features_updated:
        if verbose:
            logger.info("✓ Workspace features synced")

    # Sync workspace work item types (if enabled)
    types_updated = sync_workspace_work_item_types(context, client)
    if types_updated:
        if verbose:
            logger.info("✓ Workspace work item types synced")
    else:
        logger.debug("No workspace work item types to sync (feature may not be enabled)")

    # Sync workspace members (always — not behind a feature flag)
    members_updated = sync_workspace_members(context, client)
    if members_updated:
        if verbose:
            logger.info("✓ Workspace members synced")
    else:
        logger.debug("No workspace members returned from API")

    # Persist workspace configuration to workspace.yaml
    # NOTE: workspace_config is always initialized by the sync functions above
    if save_to_yaml and context.workspace_config:
        logger.debug("Saving workspace configuration to workspace.yaml")
        update_workspace_yaml(
            context.root_path,
            workspace=context.config.workspace,
            workspace_features=context.workspace_config.workspace_features,
            work_item_types=context.workspace_config.work_item_types,
            members=context.workspace_config.members,
        )
