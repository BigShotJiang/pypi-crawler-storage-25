"""Shared workspace resolution utilities for CLI commands."""
from typing import Any
import typer
from rich.console import Console
from rich.prompt import Prompt
from rich.table import Table
from rich import box as rich_box

console = Console()


def pick_workspace(workspaces: list[dict[str, Any]], connections: dict[str, Any], default_slug: str | None) -> dict[str, Any]:
    """Show an interactive workspace picker. Returns selected workspace entry."""
    console.print()
    console.print("[bold]Connected workspaces:[/bold]")

    table = Table(box=rich_box.SIMPLE, padding=(0, 1), show_header=False)
    table.add_column("Num", style="dim")
    table.add_column("Slug", style="cyan")
    table.add_column("Connection", style="dim")
    table.add_column("Type", style="dim")

    for i, ws in enumerate(workspaces, 1):
        conn = connections.get(ws["connection_id"], {})
        token_type = "PAT" if conn.get("token_type") == "pat" else "workspace"
        star = " [yellow]★[/yellow]" if ws["slug"] == default_slug else ""
        table.add_row(f"({i})", f"{ws['slug']}{star}", ws["connection_id"], token_type)

    console.print(table)

    # Default selection: default workspace index, or 1
    default_idx = 1
    if default_slug:
        for i, ws in enumerate(workspaces, 1):
            if ws["slug"] == default_slug:
                default_idx = i
                break

    while True:
        raw = Prompt.ask("  Select workspace", default=str(default_idx))
        try:
            idx = int(raw.strip())
            if 1 <= idx <= len(workspaces):
                return workspaces[idx - 1]
        except ValueError:
            pass
        console.print(f"[yellow]Please enter a number between 1 and {len(workspaces)}[/yellow]")


def resolve_workspace(
    workspace_slug: str | None,
    connection_id: str | None,
    command_hint: str = "plane init",
) -> tuple[str, str, str, str]:
    """
    Resolve workspace to (slug, connection_id, server_url, token).

    Args:
        workspace_slug: From --workspace flag, or None for interactive picker.
        connection_id:  From --connection flag for disambiguation.
        command_hint:   Used in error messages (e.g. "plane clone", "plane init").

    Returns:
        (slug, connection_id, server_url, token)

    Raises:
        typer.Exit on any error.
    """
    from planecompose.cli.auth import _load_config

    config = _load_config()
    connections = {c["id"]: c for c in config.get("connections", [])}
    workspaces = config.get("workspaces", [])

    if not workspaces:
        console.print("\n[red]✗[/red] No workspaces connected.")
        console.print("Run [cyan]plane auth login[/cyan] to connect a workspace first.")
        raise typer.Exit(1)

    if workspace_slug:
        matches = [ws for ws in workspaces if ws["slug"] == workspace_slug]

        if not matches:
            console.print(f"\n[red]✗[/red] Workspace [bold]{workspace_slug}[/bold] is not connected.")
            console.print(
                "Run [cyan]plane auth login[/cyan] or "
                "[cyan]plane auth connect-workspace[/cyan] to add it."
            )
            raise typer.Exit(1)

        if connection_id:
            target = next((ws for ws in matches if ws["connection_id"] == connection_id), None)
            if not target:
                console.print(
                    f"\n[red]✗[/red] Workspace [bold]{workspace_slug}[/bold] is not linked to "
                    f"connection [bold]{connection_id}[/bold]."
                )
                console.print("Run [cyan]plane auth list-connections[/cyan] to see what's configured.")
                raise typer.Exit(1)
            ws_entry = target
        elif len(matches) > 1:
            conn_ids = [ws["connection_id"] for ws in matches]
            console.print(
                f"\n[yellow]⚠[/yellow] Workspace [bold]{workspace_slug}[/bold] exists in "
                f"multiple connections: {', '.join(conn_ids)}"
            )
            console.print(
                f"Use [cyan]--connection <id>[/cyan] to disambiguate. "
                f"Example: [cyan]{command_hint} --workspace {workspace_slug} "
                f"--connection {conn_ids[0]}[/cyan]"
            )
            raise typer.Exit(1)
        else:
            ws_entry = matches[0]
    else:
        if connection_id:
            conn = connections.get(connection_id)
            if not conn:
                console.print(
                    f"\n[red]✗[/red] Connection [bold]{connection_id}[/bold] not found in config."
                )
                console.print("Run [cyan]plane auth list-connections[/cyan] to see what's configured.")
                raise typer.Exit(1)

            is_pat = conn.get("token_type") == "pat"

            if is_pat:
                # PAT: workspace slug is required — can't discover workspaces without it
                console.print(
                    f"\n[red]✗[/red] Connection [bold]{connection_id}[/bold] is a PAT — "
                    "workspace slug is required."
                )
                console.print(
                    f"Example: [cyan]plane ws clone <workspace-slug> -c {connection_id}[/cyan]"
                )
                raise typer.Exit(1)
            else:
                # Workspace token: scoped to one workspace — skip the picker
                conn_workspaces = [ws for ws in workspaces if ws["connection_id"] == connection_id]
                if not conn_workspaces:
                    console.print(
                        f"\n[red]✗[/red] No workspaces connected to [bold]{connection_id}[/bold]."
                    )
                    console.print("Run [cyan]plane auth list-connections[/cyan] to see what's configured.")
                    raise typer.Exit(1)
                ws_entry = conn_workspaces[0]
        else:
            ws_entry = pick_workspace(workspaces, connections, config.get("default_workspace"))

    resolved_conn_id = ws_entry["connection_id"]
    conn = connections.get(resolved_conn_id)
    if not conn:
        console.print(
            f"\n[red]✗[/red] Connection [bold]{resolved_conn_id}[/bold] not found in config. "
            "Run [cyan]plane auth list-connections[/cyan]."
        )
        raise typer.Exit(1)

    return ws_entry["slug"], resolved_conn_id, conn["server_url"], conn["token"]


def resolve_connection_by_id(conn_id: str) -> tuple[str, str]:
    """Resolve a known connection ID to (server_url, token).

    Used by commands that read their workspace context from plane.yaml (e.g.
    ``plane ws pull``) rather than accepting a slug argument.

    Raises typer.Exit on failure.
    """
    from planecompose.cli.auth import _load_config

    config = _load_config()
    connections = {c["id"]: c for c in config.get("connections", [])}

    conn = connections.get(conn_id)
    if not conn:
        console.print(
            f"\n[red]✗[/red] Connection [bold]{conn_id}[/bold] not found in local config."
        )
        console.print(
            "Run [cyan]plane auth list-connections[/cyan] to see configured connections, "
            "or re-authenticate with [cyan]plane auth login[/cyan]."
        )
        raise typer.Exit(1)

    return conn["server_url"], conn["token"]
