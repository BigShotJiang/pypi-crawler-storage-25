"""Clone command - clone a Plane project.

Supports three identifier formats:
  1. UUID: plane clone <uuid> --workspace=<slug>
  2. Project key: plane clone <KEY> --workspace=<slug>
  3. Shorthand: plane clone <workspace>/<KEY>

All API calls go through PlaneBackend - no direct SDK usage in CLI code.
"""

import asyncio
import typer
import yaml
from pathlib import Path
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.panel import Panel

from planecompose.cli.helpers import validate_project_skip
from planecompose.cli.clone_helpers import (
    build_clone_state,
    convert_sdk_type_to_dict,
    write_types_yaml,
    write_states_yaml,
    write_workflows_yaml,
    write_labels_yaml,
    write_features_yaml,
    write_cycles_yaml,
    write_modules_yaml,
    convert_work_item_to_dict,
)
from planecompose.sync.workspace import bootstrap_workspace_yaml
from planecompose.utils.logger import get_logger
from planecompose.utils.mapping import build_id_sequence_map, build_type_map
from planecompose.sync.collections import fetch_cycle_items_map, fetch_module_items_map
from planecompose.constants import DEFAULT_TYPE, DEFAULT_WORKFLOW
from planecompose.parser.members_yaml import write_members_yaml, merge_member_roles
from planecompose.utils.identifiers import (
    parse_project_identifier,
    validate_identifier,
    format_identifier_help,
    IdentifierFormat,
    ProjectIdentifier,
)

logger = get_logger()

console = Console()


def clone(
    project: str = typer.Argument(
        ...,
        help="Project identifier: UUID, project key (KEY), or workspace/KEY",
        metavar="PROJECT",
    ),
    directory: str | None = typer.Option(
        None, "--directory", "-d", help="Directory name to clone into (default: project identifier)"
    ),
    path: Path | None = typer.Option(
        None, "--path", help="Parent directory to clone into (default: current directory)"
    ),
    workspace: str | None = typer.Option(None, "--workspace", "-w", help="Workspace slug"),
    connection: str | None = typer.Option(
        None,
        "--connection",
        "-c",
        help="Connection ID (disambiguates if same slug exists in multiple connections)",
    ),
    schema_only: bool = typer.Option(
        False,
        "--schema-only",
        help="Alias for --skip workitems --skip cycles --skip modules",
    ),
    skip: list[str] = typer.Option(
        [],
        "--skip",
        help="Skip a section: workitems, cycles, modules. Repeatable.",
    ),
    with_properties: bool = typer.Option(
        False,
        "--with-properties",
        help="Clone work item property values (slower, requires many API calls)",
    ),
):
    """
    Clone a Plane project (fast by default).

    Creates a new local workspace with:
    - plane.yaml (project configuration)
    - schema/ (types, workflows, labels with property definitions)
    - work/workitems.yaml (all work items)

    By default, work item property VALUES are NOT cloned (schema definitions are).
    Use --with-properties to clone property values (can be very slow for large projects).
    Use --schema-only to skip work items, cycles, and modules entirely (much faster for large projects).
    Use --skip to skip individual sections: workitems, cycles, modules.

    This is like 'git clone' - use it to get someone else's project.
    For your own project, use 'plane pull' instead.

    \b
    Supported formats:
      UUID:      plane clone <uuid> --workspace=<slug>
      Key:       plane clone <KEY> --workspace=<slug>
      Shorthand: plane clone <workspace>/<KEY>

    \b
    Examples:
      plane clone 8cee0da2-1b5b-4699-b11a-e3c8b26dd55d --workspace=myteam
      plane clone MYPROJ --workspace=myteam
      plane clone myteam/MYPROJ
      plane clone myteam/MYPROJ --schema-only             # Skip all work data
      plane clone myteam/MYPROJ --skip workitems          # Skip only work items
      plane clone myteam/MYPROJ --skip cycles --skip modules  # Skip cycles and modules
    """
    # If workspace/KEY shorthand used, extract workspace from identifier
    # before running the picker so we don't ask twice
    embedded_workspace = workspace
    if "/" in project:
        embedded_workspace = project.split("/")[0]

    # Resolve workspace credentials
    from planecompose.cli.workspace_utils import resolve_workspace

    ws_slug, conn_id, server_url, token = resolve_workspace(
        embedded_workspace, connection, command_hint="plane clone"
    )

    # Re-parse identifier now that we have a confirmed workspace slug
    identifier = parse_project_identifier(project, ws_slug)

    # Validate the parsed identifier
    errors = validate_identifier(identifier)
    if errors:
        console.print("\n[red]✗ Error:[/red] Invalid project identifier")
        for error in errors:
            console.print(f"  {error}")
        console.print(f"\n{format_identifier_help()}")
        raise typer.Exit(1)

    # Compute effective skip set
    skip_set = set(skip)
    if schema_only:
        skip_set |= {"workitems", "cycles", "modules"}
    validate_project_skip(skip_set)

    try:
        asyncio.run(
            _clone(
                identifier,
                directory,
                path,
                skip_set,
                with_properties,
                server_url,
                token,
                conn_id,
            )
        )
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled.[/yellow]")
        raise typer.Exit(130)


def _write_workitems_yaml(path: Path, items_list: list) -> None:
    """Write work/workitems.yaml in the canonical format.

    When items_list is empty (schema-only clone), writes an empty template.
    When items_list has items, writes them under the `workitems:` root key.
    """
    header = (
        "# Work items — edit and run 'plane push' to sync changes to Plane.\n"
        "# Items with 'id:' are tracked (PATCH on next push if changed).\n"
        "# New items without 'id:' will be created (POST) and id written back.\n"
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(header)
        f.write("\n")
        yaml.dump(
            {"workitems": items_list},
            f,
            default_flow_style=False,
            sort_keys=False,
            allow_unicode=True,
        )


async def _clone(
    identifier: ProjectIdentifier,
    directory: str | None,
    parent_path: Path | None = None,
    skip_set: set[str] | None = None,
    with_properties: bool = False,
    server_url: str = "https://api.plane.so",
    api_key: str = "",
    connection_id: str = "",
):
    """Async implementation of clone.

    Args:
        identifier: Parsed project identifier (from parse_project_identifier)
        directory: Target directory (default: project name)
        skip_set: Set of sections to skip: workitems, cycles, modules
        with_properties: Whether to fetch work item property values

    All API calls go through PlaneBackend (rate limiting is automatic).
    """
    if skip_set is None:
        skip_set = set()
    import time
    from planecompose.backend.plane import PlaneBackend

    start_time = time.time()
    phase_times = {}

    assert identifier.workspace is not None, "workspace validated by validate_identifier"
    workspace: str = identifier.workspace
    backend = None

    try:
        console.print(f"\n[bold cyan]Cloning {identifier.display_name}...[/bold cyan]")
        if skip_set:
            console.print(f"[dim]  (Skipping: {', '.join(sorted(skip_set))})[/dim]\n")
        elif not with_properties:
            console.print(
                "[dim]  (Use --with-properties to clone work item property values)[/dim]\n"
            )
        else:
            console.print("[dim]  (Cloning with property values - this may take longer)[/dim]\n")

        # Create backend using resolved credentials
        backend = PlaneBackend.create_client(server_url, api_key)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            phase_start = time.time()
            task = progress.add_task("Connecting to Plane...", total=None)

            # Resolve project identifier to UUID if needed
            project_uuid = identifier.project_uuid

            if identifier.format in (IdentifierFormat.PROJECT_KEY, IdentifierFormat.WORKSPACE_KEY):
                # Need to look up project by key
                assert identifier.project_key is not None
                progress.update(
                    task, description=f"🔍 Looking up project {identifier.project_key}..."
                )
                try:
                    project_uuid = await _resolve_project_key(
                        backend, workspace, identifier.project_key
                    )
                    if not project_uuid:
                        console.print(
                            f"\n[red]✗ Error:[/red] Project '{identifier.project_key}' not found in workspace '{workspace}'"
                        )
                        console.print("\n[yellow]Make sure:[/yellow]")
                        console.print("  • The project key is correct (case-sensitive)")
                        console.print("  • You have access to this project")
                        console.print("  • The workspace slug is correct")
                        raise typer.Exit(1)
                except typer.Exit:
                    raise
                except Exception as e:
                    console.print(f"\n[red]✗ Error:[/red] Could not look up project: {e}")
                    raise typer.Exit(1)

            # Fetch project details
            progress.update(task, description="📡 Fetching project details...")
            assert project_uuid is not None, "resolved above or set from identifier"

            try:
                project = await backend.retrieve_project(workspace, project_uuid)
                phase_times["connect"] = time.time() - phase_start
            except Exception as e:
                console.print("\n[red]✗ Error:[/red] Could not fetch project")
                console.print(f"[dim]{e}[/dim]")
                console.print("\n[yellow]Make sure:[/yellow]")
                if identifier.format == IdentifierFormat.UUID:
                    console.print("  • The project UUID is correct")
                else:
                    console.print(f"  • The project key '{identifier.project_key}' exists")
                console.print("  • You have access to this project")
                console.print("  • The workspace slug is correct")
                raise typer.Exit(1)

            # Determine directory name
            if not directory:
                # Use project identifier or name
                directory = (
                    project.identifier.lower()
                    if project.identifier
                    else project.name.lower().replace(" ", "-")
                )

            base = (parent_path or Path.cwd()).resolve()
            target_dir = base / directory

            if target_dir.exists():
                from rich.prompt import Confirm

                if not Confirm.ask(f"[yellow]Directory '{directory}' exists. Overwrite?[/yellow]"):
                    console.print("[yellow]Cancelled[/yellow]")
                    raise typer.Exit(0)

            # Create directory structure
            progress.update(task, description="Creating directory structure...")
            target_dir.mkdir(parents=True, exist_ok=True)
            (target_dir / "schema").mkdir(exist_ok=True)
            (target_dir / "work").mkdir(exist_ok=True)
            (target_dir / ".plane").mkdir(parents=True, exist_ok=True)

            # Create plane.yaml
            progress.update(task, description="Writing configuration...")
            # Map API network integer to human-readable string
            from planecompose.core.models import network_to_str
            _network_str = network_to_str(project.network) if project.network is not None else "public"
            plane_yaml = {
                "type": "project",
                "workspace": workspace,
                "connection": connection_id,
                "project": {
                    "key": project.identifier,
                    "uuid": project_uuid,
                    "name": project.name,
                    "description": project.description or "",
                    "network": _network_str,
                    "timezone": project.timezone or "UTC",
                },
                "defaults": {
                    "type": DEFAULT_TYPE,
                    "workflow": DEFAULT_WORKFLOW,
                },
                "template": "default",
            }

            with open(target_dir / "plane.yaml", "w") as f:
                f.write("# Plane Project Configuration\n")
                f.write("# This file contains project-specific settings.\n")
                f.write("# Edit plane.yaml to change project key, name, or defaults.\n")
                f.write("# Use 'plane push' to sync changes to Plane.\n")
                f.write("\n")
                yaml.dump(plane_yaml, f, default_flow_style=False, sort_keys=False)

            # Fetch and write workspace.yaml (workspace-level configuration)
            progress.update(task, description="Fetching workspace configuration...")
            workspace_features, workspace_wit_dict = bootstrap_workspace_yaml(
                server_url=server_url,
                api_key=api_key,
                connection_id=connection_id,
                workspace_slug=workspace,
                target_dir=target_dir,
            )

            # Fetch and write schema (with rich metadata)
            phase_start = time.time()
            progress.update(task, description="📋 Fetching work item types...")

            # Use backend to fetch types (rate limiting is automatic)
            # Handle validation errors from malformed field definitions
            try:
                types_sdk = await backend.list_types_raw(workspace, project_uuid)
            except ValueError as e:
                console.print(f"\n[yellow]⚠ Warning:[/yellow] Could not fetch all types: {e}")
                console.print("[dim]Continuing with available schema...[/dim]\n")
                types_sdk = []

            # Convert SDK objects to dicts for consistent processing
            types_data = [convert_sdk_type_to_dict(t) for t in types_sdk]

            # If workspace-level WIT is enabled, map project types to workspace types
            if (
                workspace_features
                and workspace_features.get("work_item_types", False)
                and workspace_wit_dict
            ):
                # Build mapping from workspace type name -> id for fast lookup
                ws_type_name_to_id = {
                    wit["name"]: wit["id"] for wit in workspace_wit_dict.values() if "name" in wit
                }

                # Inject workspace_item_type_id into each project type that matches a workspace type
                for wit in types_data:
                    wit_name = wit.get("name")
                    if wit_name and wit_name in ws_type_name_to_id:
                        wit["workspace_item_type_id"] = ws_type_name_to_id[wit_name]
                        logger.debug(
                            f"Mapped project type '{wit_name}' to workspace type {ws_type_name_to_id[wit_name]}"
                        )

            # Build property maps for writing schema (needed in both schema-only and full modes)
            property_maps = {}
            try:
                # Set config temporarily so backend methods work
                from planecompose.core.models import ProjectConfig

                backend._config = ProjectConfig(
                    workspace=workspace,
                    project_key=project.identifier,
                    project_uuid=project_uuid,
                    project_name=project.name,
                    api_url=server_url,
                    connection_id=connection_id,
                )
                backend._project_id = project_uuid

                progress.update(
                    task, description=f"📋 Building property maps for {len(types_data)} types..."
                )
                property_maps = await backend.build_property_maps(types_data)
            except ValueError as e:
                # Handle malformed field definitions (e.g., option fields without options)
                console.print(
                    f"\n[yellow]⚠ Warning:[/yellow] Could not fully parse property definitions: {e}"
                )
                console.print("[dim]Continuing with available schema...[/dim]\n")
                property_maps = {}

            phase_times["types"] = time.time() - phase_start

            # Write types.yaml using helper
            write_types_yaml(target_dir, types_data, property_maps)

            # Fetch states (via backend - rate limiting automatic)
            phase_start = time.time()
            progress.update(task, description="🔄 Fetching workflow states...")
            states_list = await backend.list_states_raw(workspace, project_uuid)

            if not states_list:
                # SDK validation may fail, use defaults
                console.print("[yellow]⚠ Warning:[/yellow] Could not fetch states, using defaults")
                from types import SimpleNamespace

                states_list = [
                    SimpleNamespace(
                        id="default-1", name="backlog", group="backlog", color="#94a3b8"
                    ),
                    SimpleNamespace(
                        id="default-2", name="todo", group="unstarted", color="#3b82f6"
                    ),
                    SimpleNamespace(
                        id="default-3", name="in_progress", group="started", color="#f59e0b"
                    ),
                    SimpleNamespace(
                        id="default-4", name="done", group="completed", color="#22c55e"
                    ),
                ]

            # Write states.yaml using helper (Phase 3 refactored format)
            write_states_yaml(target_dir, states_list)

            phase_times["states"] = time.time() - phase_start

            # Fetch workflows
            phase_start = time.time()
            progress.update(task, description="🔄 Fetching workflows...")
            workflows_list = None
            try:
                workflows_list = await backend.fetch_workflows(workspace, project_uuid)
            except Exception as e:
                logger.debug(f"Could not fetch workflows: {e}")
                # Non-blocking: workflows are optional

            # Create type_id_to_name mapping for workflow work_item_types conversion
            type_id_to_name = build_type_map(types_data)

            # Write workflows.yaml using helper (Phase 3 refactored format with transitions)
            if workflows_list:
                write_workflows_yaml(target_dir, workflows_list, type_id_to_name)
            else:
                # No remote workflows — write the default template (header + workflows: {})
                import shutil as _shutil
                _default = Path(__file__).parent.parent / "templates" / "default" / "schema" / "workflows.yaml"
                _shutil.copy(_default, target_dir / "schema" / "workflows.yaml")

            phase_times["workflows"] = time.time() - phase_start

            # Fetch labels (via backend - rate limiting automatic)
            phase_start = time.time()
            progress.update(task, description="🏷️  Fetching labels...")
            labels_list = await backend.list_labels_raw(workspace, project_uuid)

            # Write labels.yaml using helper
            write_labels_yaml(target_dir, labels_list)
            phase_times["labels"] = time.time() - phase_start

            # Fetch and write project features (schema/features.yaml)
            try:
                progress.update(task, description="⚙️  Fetching project features...")
                project_features = await backend.get_project_features()
                if project_features:
                    write_features_yaml(target_dir, project_features)
            except Exception as e:
                logger.debug(f"Could not fetch project features: {e}")
                # Non-blocking: features.yaml is optional

            # Fetch and write project members
            try:
                progress.update(task, description="👥 Fetching project members...")
                project_members = await backend.fetch_project_members(workspace, project_uuid)
                if project_members:
                    write_members_yaml(
                        target_dir,
                        merge_member_roles(project_members, target_dir),
                    )
            except Exception as e:
                logger.debug(f"Could not fetch project members: {e}")
                # Non-blocking: members.yaml is optional

            # Fetch work items (skip if "workitems" in skip_set)
            items_list = []
            id_to_sequence: dict[str, str] = {}

            if "workitems" not in skip_set:
                # Fetch work items (via backend - rate limiting automatic)
                phase_start = time.time()
                progress.update(task, description="📝 Fetching work items...")
                work_items_list = await backend.list_work_items_raw(include_relations=True)

                # Build state, label, and type maps for reverse lookup
                state_map = {str(s.id): s.name for s in states_list}
                label_map = {str(lbl.id): lbl.name for lbl in labels_list}
                # Build type map: UUID -> type name
                type_map = build_type_map(types_data)

                # property_maps already built earlier, reuse it

                phase_times["work_items"] = time.time() - phase_start

                # Fetch properties in batch (OPTIONAL - can be very slow!)
                work_item_properties = {}
                if with_properties and property_maps:
                    phase_start = time.time()
                    total_calls = sum(
                        len(property_maps.get(str(getattr(item, "type_id", "")), {}))
                        for item in work_items_list
                        if getattr(item, "type_id", None)
                    )

                    progress.update(
                        task,
                        description=f"⚙️  Fetching property values ({total_calls} API calls, ~{total_calls / 50:.0f}min)...",
                    )
                    work_item_properties = await backend.fetch_work_item_properties_batch(
                        work_items_list, property_maps
                    )
                    phase_times["properties"] = time.time() - phase_start

                # Convert to clean YAML format (FAST - no API calls here!)
                total_items = len(work_items_list)
                progress.update(task, description=f"Processing {total_items} work items...")

                items_list = [
                    convert_work_item_to_dict(
                        item,
                        project.identifier,
                        type_map,
                        state_map,
                        label_map,
                        work_item_properties,
                    )
                    for item in work_items_list
                ]

                # Build sequence_id map: remote UUID -> "IW-123" for use in cycles/modules
                id_to_sequence = build_id_sequence_map(work_items_list, project.identifier)
            else:
                # workitems skipped
                progress.update(task, description="Skipping work items...")

            # Write work items to work/workitems.yaml (canonical source of truth).
            # items_list is [] when workitems were skipped — writes an empty template.
            _write_workitems_yaml(target_dir / "work" / "workitems.yaml", items_list)

            # ------------------------------------------------------------------
            # Cycles (skip fetch if "cycles" in skip_set; always write template)
            # ------------------------------------------------------------------
            cycles_list = []
            if "cycles" not in skip_set:
                phase_start = time.time()
                progress.update(task, description="🔁 Fetching cycles...")
                cycles_list = await backend.list_cycles_raw(workspace, project_uuid)

                cycle_items_map: dict[str, list[str]] = {}
                if "workitems" not in skip_set:
                    cycle_items_map = await fetch_cycle_items_map(
                        backend, workspace, project_uuid, cycles_list, id_to_sequence
                    )
                else:
                    cycle_items_map = {}

                write_cycles_yaml(target_dir, cycles_list, cycle_items_map)
                phase_times["cycles"] = time.time() - phase_start
            else:
                progress.update(task, description="Skipping cycles...")
                # Always create an empty template so filesystem-as-state works
                write_cycles_yaml(target_dir, [], {})

            # ------------------------------------------------------------------
            # Modules (skip fetch if "modules" in skip_set; always write template)
            # ------------------------------------------------------------------
            modules_list = []
            if "modules" not in skip_set:
                phase_start = time.time()
                progress.update(task, description="📦 Fetching modules...")
                modules_list = await backend.list_modules_raw(workspace, project_uuid)

                module_items_map: dict[str, list[str]] = {}
                if "workitems" not in skip_set:
                    module_items_map = await fetch_module_items_map(
                        backend, workspace, project_uuid, modules_list, id_to_sequence
                    )
                else:
                    module_items_map = {}

                write_modules_yaml(target_dir, modules_list, module_items_map)
                phase_times["modules"] = time.time() - phase_start
            else:
                progress.update(task, description="Skipping modules...")
                # Always create an empty template so filesystem-as-state works
                write_modules_yaml(target_dir, [], {})

            # Create state.json with schema mappings only.
            import json
            from datetime import datetime, timezone

            # Enterprise instances: properties belong to workspace-level WIT,
            # not project types — don't store project-level property UUIDs in state.json.
            is_enterprise = bool(
                workspace_features and workspace_features.get("work_item_types", False)
            )

            now_iso = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
            state_json = build_clone_state(
                types_data,
                states_list,
                labels_list,
                cycles_list=cycles_list,
                modules_list=modules_list,
                workflows_list=workflows_list if workflows_list else None,
                property_maps=property_maps if (property_maps and not is_enterprise) else None,
                last_sync=now_iso,
                work_items_raw=work_items_list if "work_items_list" in dir() else None,
                work_items_dicts=items_list if items_list else None,
            )

            with open(target_dir / ".plane" / "state.json", "w") as f:
                json.dump(state_json, f, indent=2)

            # Create .gitignore
            (target_dir / ".gitignore").write_text(".plane/\n")

        # Success message with timing breakdown
        total_time = time.time() - start_time
        total_str = (
            f"{total_time:.1f}s"
            if total_time < 60
            else f"{int(total_time // 60)}m {int(total_time % 60)}s"
        )

        # Build timing breakdown
        timing_lines = []
        if "types" in phase_times:
            timing_lines.append(f"  📋 Types: {phase_times['types']:.1f}s")
        if "states" in phase_times:
            timing_lines.append(f"  🔄 States: {phase_times['states']:.1f}s")
        if "workflows" in phase_times:
            timing_lines.append(f"  🔄 Workflows: {phase_times['workflows']:.1f}s")
        if "labels" in phase_times:
            timing_lines.append(f"  🏷️  Labels: {phase_times['labels']:.1f}s")
        if "work_items" in phase_times:
            timing_lines.append(f"  📝 Work Items: {phase_times['work_items']:.1f}s")
        if "properties" in phase_times:
            timing_lines.append(f"  ⚙️  Properties: {phase_times['properties']:.1f}s")
        if "cycles" in phase_times:
            timing_lines.append(f"  🔁 Cycles: {phase_times['cycles']:.1f}s")
        if "modules" in phase_times:
            timing_lines.append(f"  📦 Modules: {phase_times['modules']:.1f}s")
        timing_breakdown = "\n".join(timing_lines) if timing_lines else ""

        property_note = ""
        if not with_properties:
            property_note = (
                "\n[dim]💡 Tip: Use --with-properties to clone work item property values[/dim]"
            )

        items_count = len(items_list) if "items_list" in dir() else 0
        cycles_count = len(cycles_list) if "cycles_list" in dir() else 0
        modules_count = len(modules_list) if "modules_list" in dir() else 0
        members_count = len(project_members) if "project_members" in dir() and project_members else 0
        workflows_count = len(workflows_list) if "workflows_list" in dir() and workflows_list else 0

        console.print()
        console.print(
            Panel(
                f"[green]✓[/green] Successfully cloned project: [bold]{project.name}[/bold]\n\n"
                f"Directory: [cyan]{directory}/[/cyan]\n"
                f"Project: [dim]{project.identifier} ({project_uuid[:8] if project_uuid else '?'}...)[/dim]\n"
                f"Members: [dim]{members_count} in schema/members.yaml[/dim]\n"
                f"Workflows: [dim]{workflows_count} in schema/workflows.yaml[/dim]\n"
                f"Features: [dim]schema/features.yaml[/dim]\n"
                f"Work items: [dim]{items_count} items in work/workitems.yaml[/dim]\n"
                f"Cycles: [dim]{cycles_count} in work/cycles.yaml[/dim]\n"
                f"Modules: [dim]{modules_count} in work/modules.yaml[/dim]\n"
                f"Time: [dim]{total_str}[/dim]\n\n"
                f"[bold]Timing Breakdown:[/bold]\n{timing_breakdown}"
                f"{property_note}\n\n"
                f"[bold]Next steps:[/bold]\n"
                f"  1. [cyan]cd {directory}[/cyan]\n"
                f"  2. Review items in [cyan]work/workitems.yaml, work/cycles.yaml, work/modules.yaml[/cyan]\n"
                f"  4. Add your own items to [cyan]work/*.yaml[/cyan]\n"
                f"  5. [cyan]plane push[/cyan] to sync your changes",
                title="Clone Complete",
                title_align="left",
                border_style="green",
            )
        )
        console.print()

    except asyncio.CancelledError:
        pass  # KeyboardInterrupt caught in sync wrapper; CancelledError is cleanup only
    except typer.Exit:
        raise
    except Exception as e:
        from planecompose.utils.errors import handle_api_error

        handle_api_error(e, "clone project")
        raise typer.Exit(1)
    finally:
        if backend:
            await backend.disconnect()


async def _resolve_project_key(backend, workspace: str, project_key: str) -> str | None:
    """Resolve a project key to its UUID.

    Args:
        backend: PlaneBackend instance
        workspace: Workspace slug
        project_key: Project identifier/key (e.g., "MYPROJ")

    Returns:
        Project UUID if found, None otherwise

    This is used when the user provides a project key instead of UUID.
    """
    try:
        # List all projects in the workspace
        projects = await backend.list_projects(workspace)

        # Find project by key (case-insensitive comparison for user convenience)
        for proj in projects:
            if proj.identifier and proj.identifier.upper() == project_key.upper():
                return str(proj.id)

        return None
    except Exception:
        # Re-raise to let caller handle
        raise
