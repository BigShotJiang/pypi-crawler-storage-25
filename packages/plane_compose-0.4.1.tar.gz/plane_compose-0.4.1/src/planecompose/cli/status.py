"""Status command - show project sync status."""
import json
from pathlib import Path
import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from planecompose.config.context import load_project_context
from planecompose.parser.work_yaml import parse_work_items
from planecompose.sync.planner import SyncPlanner
from planecompose.utils.work_items import is_remote_snapshot_source

console = Console()


def status(
    path: Path | None = typer.Argument(None, help="Path to project directory (default: current directory)"),
    all_projects: bool = typer.Option(False, "--all", help="Show status for all projects found recursively"),
    filter_workspace: str | None = typer.Option(None, "--workspace", "-w", help="Filter projects by workspace (with --all)"),
    filter_pattern: str | None = typer.Option(None, "--filter", help="Filter projects by glob pattern (with --all)"),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON"),
):
    """
    Show project sync status.

    Displays information about the current project, schema sync status,
    and pending work items.

    Examples:
        plane status                    # Status of current directory
        plane status ./projects/api     # Status of specific project
        plane status --all              # Status of all projects
        plane status --json             # Machine-readable output
    """
    if all_projects:
        _status_all(filter_workspace, filter_pattern)
        return

    _status_single(path, json_output)


def _status_single(path: Path | None = None, json_output: bool = False):
    """Show status for a single project."""
    try:
        ctx = load_project_context(path, require_auth=False)

        types_synced = len(ctx.state.types)
        states_synced = len(ctx.state.states)
        labels_synced = len(ctx.state.labels)

        types_total = len(ctx.types)
        states_total = len(ctx.states)
        labels_total = len(ctx.labels)

        work_items = list(parse_work_items(ctx.work_path, ctx.root_path))
        work_plan = SyncPlanner().plan_push(work_items, ctx.state)
        pending_local_changes = len(work_plan.creates) + len(work_plan.updates)

        synced_local_items = sum(
            1 for item_state in ctx.state.work_items.values()
            if not is_remote_snapshot_source(item_state.source)
        )

        if json_output:
            data = {
                "command": "status",
                "project": ctx.config.project_key,
                "workspace": ctx.config.workspace,
                "project_name": ctx.config.project_name or None,
                "project_uuid": ctx.config.project_uuid or None,
                "tracked_items": synced_local_items,
                "pending_items": pending_local_changes,
                "unchanged_items": len(work_plan.skipped),
                "last_sync": ctx.state.last_sync,
                "state_file": ".plane/state.json",
                "schema": {
                    "types": {"local": types_total, "synced": types_synced},
                    "states": {"local": states_total, "synced": states_synced},
                    "labels": {"local": labels_total, "synced": labels_synced},
                },
            }
            print(json.dumps(data, indent=2))
            return

        # Project info
        console.print()
        uuid_info = f" ({ctx.config.project_uuid[:8]}...)" if ctx.config.project_uuid else " [dim](not synced yet)[/dim]"
        project_info = f"""[bold]Workspace:[/bold] {ctx.config.workspace}
[bold]Project:[/bold] {ctx.config.project_name or 'N/A'}
[bold]Project Key:[/bold] {ctx.config.project_key}{uuid_info}
[bold]Root:[/bold] {ctx.root_path}"""

        console.print(Panel(project_info, title="[cyan]Project Info[/cyan]", border_style="cyan"))
        console.print()

        # Schema status
        schema_table = Table(title="Schema Status", show_header=True)
        schema_table.add_column("Type", style="cyan")
        schema_table.add_column("Local", justify="right")
        schema_table.add_column("Synced", justify="right")
        schema_table.add_column("Status", justify="center")

        schema_table.add_row(
            "Types",
            str(types_total),
            str(types_synced),
            "[green]✓[/green]" if types_synced == types_total else "[yellow]pending[/yellow]"
        )
        schema_table.add_row(
            "States",
            str(states_total),
            str(states_synced),
            "[green]✓[/green]" if states_synced == states_total else "[yellow]pending[/yellow]"
        )
        schema_table.add_row(
            "Labels",
            str(labels_total),
            str(labels_synced),
            "[green]✓[/green]" if labels_synced == labels_total else "[yellow]pending[/yellow]"
        )

        console.print(schema_table)
        console.print()

        # Work items status
        work_table = Table(title="Work Items Status")
        work_table.add_column("Status", style="cyan")
        work_table.add_column("Count", justify="right")

        work_table.add_row("Pending local changes", str(pending_local_changes))
        work_table.add_row("Unchanged local items", str(len(work_plan.skipped)))
        work_table.add_row("Synced local items", str(synced_local_items))

        console.print(work_table)
        console.print()

        # Last sync info
        if ctx.state.last_sync:
            console.print(f"[dim]Last sync: {ctx.state.last_sync}[/dim]")
        else:
            console.print("[dim]Never synced[/dim]")
        console.print()

        # Suggestions
        has_pending_schema = (
            types_synced < types_total or
            states_synced < states_total or
            labels_synced < labels_total
        )

        if has_pending_schema or types_synced == 0:
            console.print("[bold]Next steps:[/bold]")
            if has_pending_schema or types_synced == 0:
                console.print("  • Run [cyan]plane schema push[/cyan] to sync schema")
            if pending_local_changes:
                console.print(f"  • Run [cyan]plane push[/cyan] to sync {pending_local_changes} work item changes")
            console.print()
        elif pending_local_changes:
            console.print("[bold]Next step:[/bold]")
            console.print(f"  • Run [cyan]plane push[/cyan] to sync {pending_local_changes} work item changes")
            console.print()
        else:
            console.print("[green]✓ Everything is up to date![/green]")
            console.print("\nAdd work items to any [cyan]work/*.yaml[/cyan] file to get started")
            console.print()

    except FileNotFoundError as e:
        if json_output:
            print(json.dumps({"command": "status", "success": False, "error": str(e)}, indent=2))
        else:
            console.print(f"\n[red]✗ Error:[/red] {e}")
            console.print("\nRun [cyan]plane init[/cyan] to initialize a project")
            console.print()
        raise typer.Exit(1)
    except Exception as e:
        if json_output:
            print(json.dumps({"command": "status", "success": False, "error": str(e)}, indent=2))
        else:
            console.print(f"\n[red]✗ Error:[/red] {e}")
            console.print()
        raise typer.Exit(1)


def _status_all(filter_workspace: str | None, filter_pattern: str | None):
    """Show status for all discovered projects."""
    from planecompose.utils.multiproject import discover_projects

    # Discover projects
    console.print("\n[bold]Discovering projects...[/bold]")
    projects = discover_projects(
        filter_workspace=filter_workspace,
        filter_pattern=filter_pattern,
    )

    if not projects:
        console.print("[yellow]No projects found[/yellow]")
        console.print("\n[dim]Make sure you're in a directory containing plane.yaml files[/dim]")
        raise typer.Exit(1)

    # Create summary table
    table = Table(title=f"Status of {len(projects)} Projects")
    table.add_column("Project", style="cyan")
    table.add_column("Workspace", style="dim")
    table.add_column("Schema", justify="center")
    table.add_column("Work Items", justify="right")
    table.add_column("Synced", justify="right")
    table.add_column("Status")

    total_pending = 0
    total_synced = 0

    for project_info in projects:
        try:
            ctx = load_project_context(project_info.path, require_auth=False)

            # Schema status
            types_synced = len(ctx.state.types)
            states_synced = len(ctx.state.states)
            labels_synced = len(ctx.state.labels)
            types_total = len(ctx.types)
            states_total = len(ctx.states)
            labels_total = len(ctx.labels)

            schema_ok = (
                types_synced >= types_total and
                states_synced >= states_total and
                labels_synced >= labels_total
            )
            schema_status = "[green]OK[/green]" if schema_ok else "[yellow]Pending[/yellow]"

            # Work items
            work_items = list(parse_work_items(ctx.work_path, ctx.root_path))
            work_plan = SyncPlanner().plan_push(work_items, ctx.state)
            pending = len(work_plan.creates) + len(work_plan.updates)
            synced = sum(
                1 for item_state in ctx.state.work_items.values()
                if not is_remote_snapshot_source(item_state.source)
            )
            total_pending += pending
            total_synced += synced

            # Overall status
            if pending == 0 and schema_ok:
                overall = "[green]Up to date[/green]"
            elif pending > 0:
                overall = f"[yellow]{pending} to push[/yellow]"
            else:
                overall = "[yellow]Schema pending[/yellow]"

            table.add_row(
                project_info.project_key,
                project_info.workspace,
                schema_status,
                str(pending),
                str(synced),
                overall,
            )
        except Exception as e:
            table.add_row(
                project_info.project_key,
                project_info.workspace,
                "[red]Error[/red]",
                "-",
                "-",
                f"[red]{str(e)[:30]}[/red]",
            )

    console.print()
    console.print(table)
    console.print()

    # Summary
    console.print(f"[bold]Summary:[/bold] {len(projects)} projects, {total_pending} pending, {total_synced} synced")
    if total_pending > 0:
        console.print("\n[yellow]Run [cyan]plane push --all[/cyan] to push all pending items[/yellow]")
    console.print()
