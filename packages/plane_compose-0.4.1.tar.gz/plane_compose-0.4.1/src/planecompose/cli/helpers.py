"""Shared helpers for CLI commands.

This module provides common utilities used across CLI commands:
- Project root and config loading
- Project context loading with consistent error handling
- Progress spinner creation
- Backend connection with project validation
"""

import typer
from pathlib import Path
from contextlib import contextmanager
from typing import Any
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, TaskID

from planecompose.config.context import load_project_context, ProjectContext
from planecompose.backend.plane import PlaneBackend
from planecompose.utils.project import ensure_project_exists

console = Console()


def get_project_root() -> Path:
    """
    Get project root directory (containing plane.yaml).

    Searches current directory and parent directories for plane.yaml.
    Returns current directory if no plane.yaml is found.

    Returns:
        Path: Directory containing plane.yaml, or cwd if not found
    """
    cwd = Path.cwd()

    for parent in [cwd] + list(cwd.parents):
        if (parent / "plane.yaml").exists():
            return parent

    return cwd


def get_config() -> dict:
    """
    Load configuration from plane.yaml.

    Returns:
        dict: Parsed plane.yaml contents, or empty dict if not found
    """
    import yaml

    project_root = get_project_root()
    config_file = project_root / "plane.yaml"

    if config_file.exists():
        return yaml.safe_load(config_file.read_text()) or {}

    return {}


def require_project_context(path: Path | None = None, require_auth: bool = True) -> ProjectContext:
    """
    Load project context, exiting with helpful error if not found.

    This provides consistent error handling for all CLI commands that
    require a plane.yaml file.

    Args:
        path: Optional path to the project directory (defaults to current directory)

    Returns:
        ProjectContext: The loaded project context

    Raises:
        typer.Exit(1): If plane.yaml is not found
    """
    try:
        return load_project_context(path, require_auth=require_auth)
    except FileNotFoundError as e:
        target_path = path or Path.cwd()
        message = str(e)
        console.print(f"\n[red]Error:[/red] {message}")

        if message.startswith("Not authenticated"):
            console.print("\n[yellow]To fix this:[/yellow]")
            console.print("  - Run [cyan]plane auth login[/cyan] to authenticate")
            console.print(
                "  - Use [cyan]--offline[/cyan] when the command supports local-only validation\n"
            )
        else:
            console.print(f"\n[dim]plane.yaml must exist in: {target_path}[/dim]")
            console.print("\n[yellow]To fix this:[/yellow]")
            console.print("  - [cyan]cd[/cyan] to a directory with plane.yaml")
            console.print("  - Run [cyan]plane init[/cyan] to initialize a new project")
            console.print(
                "  - Run [cyan]plane clone <project-uuid>[/cyan] to clone an existing project"
            )
        console.print()
        raise typer.Exit(1)


@contextmanager
def create_progress(console_instance: Console | None = None):
    """
    Create a progress spinner context manager.

    This provides a consistent progress spinner UI across all CLI commands.

    Args:
        console_instance: Optional console to use (defaults to module console)

    Yields:
        tuple[Progress, task_id]: Progress instance and initial task ID

    Example:
        with create_progress() as (progress, task):
            progress.update(task, description="Loading...")
            # do work
            progress.update(task, description="Done!")
    """
    target_console = console_instance or console
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=target_console,
    ) as progress:
        task = progress.add_task("Working...", total=None)
        yield progress, task


async def connect_backend(
    ctx: ProjectContext,
    auto_create: bool = False,
    progress: Progress | None = None,
    task: TaskID | None = None,
) -> tuple[ProjectContext, PlaneBackend]:
    """
    Connect to Plane backend with project validation.

    This is the standard way to establish a backend connection for CLI commands.
    It validates the project exists (optionally creating it) and returns a
    connected backend instance.

    Args:
        ctx: Project context (from require_project_context())
        auto_create: Whether to auto-create the project if it doesn't exist
        progress: Optional progress instance for status updates
        task: Optional task ID for progress updates

    Returns:
        tuple[ProjectContext, PlaneBackend]: Updated context and connected backend

    Raises:
        typer.Exit(1): If project validation fails
    """

    def update_progress(description: str):
        if progress and task is not None:
            progress.update(task, description=description)

    update_progress("Checking project...")

    try:
        project_uuid = await ensure_project_exists(
            workspace=ctx.config.workspace,
            project_key=ctx.config.project_key,
            project_uuid=ctx.config.project_uuid,
            project_name=ctx.config.project_name,
            api_key=ctx.api_key,
            api_url=ctx.config.api_url,
            auto_create=auto_create,
            project_description=ctx.config.project_description,
            project_network=ctx.config.project_network,
            project_timezone=ctx.config.project_timezone,
        )
        ctx.config.project_uuid = project_uuid
    except Exception as e:
        # Error message already displayed by ensure_project_exists
        console.print()
        raise typer.Exit(1) from e

    update_progress("Connecting to Plane...")

    backend = PlaneBackend()
    await backend.connect(
        ctx.config, ctx.api_key, token_type=getattr(ctx, "token_type", "workspace")
    )

    return ctx, backend


async def fetch_remote_schema(
    backend: PlaneBackend,
    progress: Progress | None = None,
    task: TaskID | None = None,
    include_work: bool = True,
):
    """
    Fetch types, states, labels, workflows, and optionally modules and cycles.

    Args:
        backend: Connected PlaneBackend instance
        progress: Optional progress instance for status updates
        task: Optional task ID for progress updates
        include_work: If True (default), also fetch modules and cycles (operational
            data that lives in work/).  Pass False for schema-only operations like
            'plane schema push' so we don't touch work/ data at all.

    Returns:
        tuple: (remote_types, remote_states, remote_labels, remote_workflows, remote_modules, remote_cycles)
        When include_work=False, remote_modules and remote_cycles are always empty lists.
    """

    def update(description: str):
        if progress and task is not None:
            progress.update(task, description=description)

    update("Fetching types...")
    remote_types = await backend.list_types()

    update("Fetching states...")
    remote_states = await backend.list_states()

    update("Fetching labels...")
    remote_labels = await backend.list_labels()

    update("Fetching workflows...")
    remote_workflows = await backend.fetch_workflows()

    if include_work:
        update("Fetching modules...")
        remote_modules = await backend.list_modules()

        update("Fetching cycles...")
        remote_cycles = await backend.list_cycles()
    else:
        remote_modules = []
        remote_cycles = []

    return (
        remote_types,
        remote_states,
        remote_labels,
        remote_workflows,
        remote_modules,
        remote_cycles,
    )


async def load_project_and_backend(
    auto_create: bool = False,
    initial_status: str = "Loading project...",
) -> tuple[ProjectContext, PlaneBackend]:
    """
    Load project context and connect to backend in one step.

    This combines require_project_context() and connect_backend() with
    a progress spinner for the common case where both are needed.

    Args:
        auto_create: Whether to auto-create the project if it doesn't exist
        initial_status: Initial progress message

    Returns:
        tuple: (ctx, backend, progress, task) - Note: progress context is still active

    Note:
        The returned progress context is still active. The caller is responsible
        for using it within the same `with` block or closing it properly.

    Example:
        with create_progress() as (progress, task):
            progress.update(task, description="Loading project...")
            ctx = require_project_context()
            ctx, backend = await connect_backend(ctx, progress=progress, task=task)
            # continue with progress...
    """
    # This is a convenience function that shows the pattern
    # but callers should typically use the individual functions
    # for more control over the progress lifecycle
    ctx = require_project_context()

    with create_progress() as (progress, task):
        progress.update(task, description=initial_status)
        ctx, backend = await connect_backend(
            ctx,
            auto_create=auto_create,
            progress=progress,
            task=task,
        )

    return ctx, backend


# ============================================================================
# Schema Comparison Utilities
# ============================================================================


def find_items_to_create(local_items: list, remote_items: list) -> list:
    """
    Find local items that don't exist in remote (case-insensitive).

    Args:
        local_items: List of local schema items (must have .name attribute)
        remote_items: List of remote schema items (must have .name attribute)

    Returns:
        list: Items from local_items that don't exist in remote_items
    """
    remote_names = {item.name.lower() for item in remote_items}
    return [item for item in local_items if item.name.lower() not in remote_names]


def build_schema_maps(local_items: list, remote_items: list) -> tuple[dict, dict]:
    """
    Build case-insensitive lookup maps for schema items.

    Args:
        local_items: List of local schema items
        remote_items: List of remote schema items

    Returns:
        tuple: (local_map, remote_map) with lowercase keys
    """
    local_map = {item.name.lower(): item for item in local_items}
    remote_map = {item.name.lower(): item for item in remote_items}
    return local_map, remote_map


def find_schema_changes(local_items: list, remote_items: list) -> tuple[list, list, list]:
    """
    Find items to create, update, and delete between local and remote.

    Uses case-insensitive name comparison.

    Args:
        local_items: List of local schema items
        remote_items: List of remote schema items

    Returns:
        tuple: (to_create, to_update, to_delete)
    """
    local_map, remote_map = build_schema_maps(local_items, remote_items)

    to_create = [item for item in local_items if item.name.lower() not in remote_map]
    to_update = [
        item
        for item in local_items
        if item.name.lower() in remote_map
        and _schema_item_signature(item) != _schema_item_signature(remote_map[item.name.lower()])
    ]
    to_delete = [item for item in remote_items if item.name.lower() not in local_map]

    return to_create, to_update, to_delete


def _schema_item_signature(item) -> tuple:
    """Build a comparison signature for schema items, excluding remote IDs."""
    if hasattr(item, "fields"):
        fields = []
        for field in getattr(item, "fields", []) or []:
            field_type = getattr(
                getattr(field, "type", None), "value", getattr(field, "type", None)
            )
            fields.append(
                (
                    field.name.lower(),
                    getattr(field, "display_name", None),
                    str(field_type).lower() if field_type else "",
                    getattr(field, "required", False),
                    tuple(getattr(field, "options", []) or []),
                    getattr(field, "is_multi", False),
                    getattr(field, "is_active", True),
                    getattr(field, "relation_type", None),
                )
            )

        logo = getattr(item, "logo_props", None)
        logo_signature = None
        if logo is not None:
            logo_signature = (
                getattr(logo, "icon", None),
                getattr(logo, "background_color", None),
                getattr(logo, "emoji", None),
            )

        return (
            item.name.lower(),
            getattr(item, "description", None),
            tuple(sorted(fields)),
            logo_signature,
            getattr(item, "is_epic", False),
            getattr(item, "is_default", False),
            getattr(item, "level", 0.0),
        )

    if hasattr(item, "group"):
        return (
            item.name.lower(),
            getattr(item, "description", None),
            getattr(item, "color", None),
            getattr(item, "group", None),
        )

    return (
        item.name.lower(),
        getattr(item, "color", None),
        getattr(item, "description", None),
    )


def display_failed_items(
    failed_items: list[tuple[str, str]],
    item_type: str,
) -> None:
    """
    Display a summary of failed items with truncated error messages.

    Args:
        failed_items: List of (name, error_message) tuples
        item_type: Type name for display (e.g., "states", "labels", "types")
    """
    from planecompose.constants import MAX_ERROR_DISPLAY_COUNT, ERROR_MESSAGE_MAX_CHARS

    if not failed_items:
        return

    console.print(f"\n[red]✗[/red] Failed to create {len(failed_items)} {item_type}:")
    for name, error in failed_items[:MAX_ERROR_DISPLAY_COUNT]:
        console.print(f"  • {name}: {error[:ERROR_MESSAGE_MAX_CHARS]}")
    if len(failed_items) > MAX_ERROR_DISPLAY_COUNT:
        console.print(f"  ... and {len(failed_items) - MAX_ERROR_DISPLAY_COUNT} more")


def print_schema_section(
    label: str,
    only_local: list[str],
    only_remote: list[str],
    in_both: int,
    renamed: list[tuple[str, str]],
) -> None:
    """Print a single schema-diff section (types, states, labels, modules, cycles …).

    Prints nothing if there is nothing to report.

    Args:
        label:      Display heading, e.g. ``"Types"`` or ``"States"``.
        only_local: Names present locally but missing on the remote.
        only_remote: Names present on the remote but missing locally.
        in_both:    Count of items that match on both sides unchanged.
        renamed:    Pairs of ``(local_name, remote_name)`` for items whose
                    name differs between sides.
    """
    if not (only_local or only_remote or in_both or renamed):
        return
    console.print(f"[bold cyan]{label}:[/bold cyan]")
    for local_name, remote_name in renamed:
        console.print(
            f'  [yellow]~[/yellow] {local_name} → remote: "{remote_name}" (modified remotely)'
        )
    if only_local:
        console.print(f"  [green]+[/green] Only in local: {', '.join(only_local)}")
    if only_remote:
        console.print(f"  [red]-[/red] Only in remote: {', '.join(only_remote)}")
    if in_both:
        console.print(f"  [dim]=[/dim] In both: {in_both} {label.lower()}")
    console.print()


def compare_schema_items(
    local_items: list,
    remote_items: list,
) -> tuple[list[str], list[str], int, list[tuple[str, str]]]:
    """Compare schema items using remote IDs when available, falling back to name matching.

    Local items carry ``remote_id`` (populated from the ``id:`` field in schema
    YAML files after a push/clone).  Remote items are SDK objects with an ``id``
    attribute.

    Matching priority:
      1. ID match  — local.remote_id == remote.id  → same logical item
      2. Name match — case-insensitive name equality  → same logical item (no ID yet)
      3. No match  → orphan on one side

    Args:
        local_items:  List of local schema model objects (LabelDefinition, etc.)
        remote_items: List of remote SDK objects

    Returns:
        tuple of:
          only_local  — names present locally but missing remotely
          only_remote — names present remotely but missing locally
          in_both     — count of items that match on both sides with the same name
          renamed     — list of (local_name, remote_name) for items matched by ID
                        whose names differ (i.e. renamed on the remote)
    """
    # Build remote lookup by id and by lower-case name
    remote_by_id: dict[str, Any] = {}
    remote_by_name_lower: dict[str, Any] = {}
    for r in remote_items:
        # Handle both SDK objects (with .id) and LabelDefinition (with .remote_id)
        r_id = str(getattr(r, "id", None) or getattr(r, "remote_id", None) or "")
        if r_id:
            remote_by_id[r_id] = r
        remote_by_name_lower[r.name.lower()] = r

    matched_remote_name_lower: set[str] = set()
    only_local: list[str] = []
    in_both_count: int = 0
    renamed_pairs: list[tuple[str, str]] = []

    for local in local_items:
        remote = None

        # 1. Try ID-based match
        if local.remote_id and local.remote_id in remote_by_id:
            remote = remote_by_id[local.remote_id]

        # 2. Fall back to name-based match
        if remote is None and local.name.lower() in remote_by_name_lower:
            remote = remote_by_name_lower[local.name.lower()]

        if remote is not None:
            matched_remote_name_lower.add(remote.name.lower())
            if remote.name.lower() != local.name.lower():
                # Same ID, different name → renamed on remote
                renamed_pairs.append((local.name, remote.name))
            else:
                in_both_count += 1
        else:
            only_local.append(local.name)

    # Anything on the remote side not matched
    only_remote = [r.name for r in remote_items if r.name.lower() not in matched_remote_name_lower]

    return (
        sorted(only_local),
        sorted(only_remote),
        in_both_count,
        sorted(renamed_pairs, key=lambda x: x[0]),
    )


VALID_PROJECT_SKIP = {"workitems", "cycles", "modules"}


def validate_project_skip(skip: set[str]) -> None:
    """Validate --skip values for project commands (clone, pull, push, diff).

    Args:
        skip: Set of section names to skip.

    Raises:
        typer.Exit(1): If any invalid skip values are provided.
    """
    invalid = skip - VALID_PROJECT_SKIP
    if invalid:
        console.print(f"[red]✗ Invalid --skip value(s): {', '.join(sorted(invalid))}[/red]")
        console.print(f"  Valid values: {', '.join(sorted(VALID_PROJECT_SKIP))}")
        raise typer.Exit(1)


def detect_workflow_changes(local_workflows, remote_workflows):
    """Detect content changes in workflows that exist on both local and remote.

    Returns a dict with:
      wit_changes:   list of (wf_name, local_wits, remote_wits)
      state_changes: list of (wf_name, local_states, remote_states)
      rule_changes:  list of (wf_name, [edge_desc, ...])

    Used by both `schema diff` and `schema import` default mode to surface
    content changes in items that are name-matched but differ in content.
    """

    def _transition_rule_sig(wf) -> set[tuple]:
        """Build a signature set for all transitions including their rule script IDs."""
        sigs: set[tuple] = set()
        try:
            for st in getattr(wf, "states", None) or []:
                for t in getattr(st, "transitions", None) or []:
                    pre_ids = frozenset(
                        getattr(r, "script_id", "") or ""
                        for r in (getattr(t, "pre_rules", None) or [])
                        if getattr(r, "script_id", "")
                    )
                    post_ids = frozenset(
                        getattr(r, "script_id", "") or ""
                        for r in (getattr(t, "post_rules", None) or [])
                        if getattr(r, "script_id", "")
                    )
                    sigs.add((
                        getattr(st, "name", ""),
                        getattr(t, "to", ""),
                        pre_ids,
                        post_ids,
                    ))
        except (TypeError, AttributeError):
            pass
        return sigs

    wit_changes = []
    state_changes = []
    rule_changes = []

    for local_wf in local_workflows:
        # Find matching remote workflow by ID or name
        remote_wf = None
        for r in remote_workflows:
            if (
                local_wf.remote_id and str(getattr(r, "remote_id", None) or getattr(r, "id", None)) == local_wf.remote_id
            ) or r.name.lower() == local_wf.name.lower():
                remote_wf = r
                break

        if not remote_wf:
            continue

        local_wits = set(getattr(local_wf, "work_item_types", []) or [])
        remote_wits = set(getattr(remote_wf, "work_item_types", []) or [])
        if local_wits != remote_wits:
            wit_changes.append((local_wf.name, local_wits, remote_wits))

        local_state_names = {s.name for s in (getattr(local_wf, "states", None) or [])}
        remote_state_names = {s.name for s in (getattr(remote_wf, "states", None) or [])}
        if local_state_names != remote_state_names:
            state_changes.append((local_wf.name, local_state_names, remote_state_names))

        local_rule_sigs = _transition_rule_sig(local_wf)
        remote_rule_sigs = _transition_rule_sig(remote_wf)
        if local_rule_sigs != remote_rule_sigs:
            local_by_edge = {(f, t): (pre, post) for f, t, pre, post in local_rule_sigs}
            remote_by_edge = {(f, t): (pre, post) for f, t, pre, post in remote_rule_sigs}
            all_edges = set(local_by_edge) | set(remote_by_edge)
            rule_descs = [
                f"{e[0]} → {e[1]}"
                for e in sorted(all_edges)
                if local_by_edge.get(e) != remote_by_edge.get(e)
            ]
            if rule_descs:
                rule_changes.append((local_wf.name, rule_descs))

    return {
        "wit_changes": wit_changes,
        "state_changes": state_changes,
        "rule_changes": rule_changes,
    }
