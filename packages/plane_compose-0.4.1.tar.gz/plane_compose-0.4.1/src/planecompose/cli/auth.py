"""Authentication commands."""

import os
import stat
import json
from typing import Any, cast
import typer
from pathlib import Path
from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.table import Table
from rich import box as rich_box

app = typer.Typer(help="Authentication commands")
console = Console()

LEGACY_CONFIG_DIR = Path.home() / ".config" / "plane-cli"


def _get_config_dir() -> Path:
    """
    Return config directory, respecting PLANE_CONFIG_DIR env var.

    Priority:
    1. PLANE_CONFIG_DIR environment variable
    2. Settings.config_dir (defaults to ~/.config/plane-compose)
    """
    env_override = os.environ.get("PLANE_CONFIG_DIR")
    if env_override:
        return Path(env_override).expanduser().resolve()
    from planecompose.config.settings import get_settings

    return get_settings().config_dir


def _get_config_file() -> Path:
    return _get_config_dir() / "config.json"


def _get_token_file() -> Path:
    return _get_config_dir() / "credentials"


def _migrate_legacy_config():
    """Migrate config from plane-cli to plane-compose if needed.

    Only runs when using the default config dir — if PLANE_CONFIG_DIR is
    explicitly set, the user wants a clean slate, not a copy of old files.
    """
    if os.environ.get("PLANE_CONFIG_DIR"):
        return  # Custom dir — skip legacy migration

    if _get_config_file().exists():
        return  # Already migrated or new install

    # Check for legacy config
    legacy_config = LEGACY_CONFIG_DIR / "config.json"
    legacy_token = LEGACY_CONFIG_DIR / "credentials"

    if legacy_config.exists() or legacy_token.exists():
        _get_config_dir().mkdir(parents=True, exist_ok=True)

        if legacy_config.exists():
            import shutil

            shutil.copy2(legacy_config, _get_config_file())
            _get_config_file().chmod(0o600)

        if legacy_token.exists():
            import shutil

            shutil.copy2(legacy_token, _get_token_file())
            _get_token_file().chmod(0o600)


def _check_file_permissions(path: Path) -> None:
    """Warn if credential file permissions are too open."""
    if not path.exists() or os.name == "nt":
        return
    mode = path.stat().st_mode
    if mode & (stat.S_IRGRP | stat.S_IWGRP | stat.S_IROTH | stat.S_IWOTH):
        console.print(
            f"[yellow]Warning:[/yellow] {path} has insecure permissions. "
            "Fixing to owner-only (600)."
        )
        path.chmod(0o600)


def _migrate_to_v2(old_config: dict) -> dict:
    """
    Migrate old format {api_key, server_url} to v2 format.
    Creates connection-1 with token_type="workspace".
    Leaves workspaces[] empty (can't infer slug).
    """
    api_key = old_config.get("api_key", "")
    server_url = old_config.get("server_url", "https://api.plane.so")
    return {
        "version": 2,
        "connections": [
            {
                "id": "connection-1",
                "token_type": "workspace",
                "token": api_key,
                "server_url": server_url,
            }
        ],
        "workspaces": [],
        "default_workspace": None,
    }


def _load_config() -> dict:
    """Load config.json, running migration if needed. Returns dict."""
    _migrate_legacy_config()
    config_file = _get_config_file()
    token_file = _get_token_file()
    _check_file_permissions(config_file)

    if config_file.exists():
        try:
            config_data = json.loads(config_file.read_text())

            # Migrate old format (no version or version < 2)
            if config_data.get("version", 1) < 2:
                config_data = _migrate_to_v2(config_data)
                _save_config(config_data)

            return cast(dict[str, Any], config_data)
        except (json.JSONDecodeError, KeyError):
            pass

    # Check for legacy plain token file (plain text api key)
    _check_file_permissions(token_file)
    if token_file.exists():
        api_key = token_file.read_text().strip()
        if api_key:
            config_data = {
                "version": 2,
                "connections": [
                    {
                        "id": "connection-1",
                        "token_type": "workspace",
                        "token": api_key,
                        "server_url": "https://api.plane.so",
                    }
                ],
                "workspaces": [],
                "default_workspace": None,
            }
            _save_config(config_data)
            # Remove legacy plaintext file after successful migration
            try:
                token_file.unlink()
            except OSError:
                pass
            return config_data

    # Return an empty v2 config
    return {
        "version": 2,
        "connections": [],
        "workspaces": [],
        "default_workspace": None,
    }


def _save_config(config: dict) -> None:
    """Save config dict to config.json with 0o600 permissions (owner-read-only).

    Uses os.open with O_CREAT so the file is created with correct permissions
    atomically — avoids the TOCTOU window where write_text() + chmod() would
    briefly leave the file world-readable under permissive umasks.
    """
    import os as _os
    config_file = _get_config_file()
    config_file.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(config, indent=2)
    fd = _os.open(config_file, _os.O_WRONLY | _os.O_CREAT | _os.O_TRUNC, 0o600)
    try:
        with _os.fdopen(fd, 'w') as f:
            f.write(content)
    except Exception:
        _os.close(fd)
        raise


def _next_connection_id(config: dict) -> str:
    """Return next available connection-N id."""
    existing = {c["id"] for c in config.get("connections", [])}
    i = 1
    while f"connection-{i}" in existing:
        i += 1
    return f"connection-{i}"


def _normalize_server_url(url: str) -> str:
    """Ensure *url* has an ``https://`` scheme; fall back to api.plane.so if blank."""
    url = url.strip() if url else ""
    if not url:
        return "https://api.plane.so"
    if not url.startswith("http://") and not url.startswith("https://"):
        return f"https://{url}"
    # Warn when http:// is used with a non-local host — API key sent in plaintext
    if url.startswith("http://"):
        from urllib.parse import urlparse
        host = urlparse(url).hostname or ""
        if host not in ("localhost", "127.0.0.1", "::1"):
            from rich.console import Console as _Console
            _Console().print(
                f"[yellow]Warning:[/yellow] Using insecure http:// connection to '{host}'. "
                "Your API key will be sent in plaintext. Use https:// for production instances."
            )
    return url


def _prompt_auth_type() -> str:
    """Interactively prompt for auth type; returns ``'pat'`` or ``'workspace'``."""
    console.print("  Auth type:")
    console.print("    (1) Personal Access Token")
    console.print("    (2) Workspace Token")
    choice = Prompt.ask("  Choice", default="1")
    return "workspace" if choice.strip() == "2" else "pat"


def _validate_workspace(
    server_url: str,
    token: str,
    token_type: str,
    workspace_slug: str,
) -> bool:
    """
    Validate token against workspace by calling projects list API.
    Returns True if valid, raises with user-friendly message if not.
    """
    url = f"{server_url.rstrip('/')}/api/v1/workspaces/{workspace_slug}/projects/"

    # Both PAT and workspace tokens use X-Api-Key — Bearer is not supported
    # by the Plane API for plane_api_xxx tokens. token_type is scope metadata only.
    headers = {"X-Api-Key": token}

    try:
        import httpx

        response = httpx.get(url, headers=headers, timeout=15)
        if response.status_code == 200:
            return True
        elif response.status_code == 401:
            raise typer.BadParameter("Authentication failed: invalid or expired token.")
        elif response.status_code == 403:
            raise typer.BadParameter(f"Permission denied for workspace '{workspace_slug}'.")
        elif response.status_code == 404:
            raise typer.BadParameter(f"Workspace '{workspace_slug}' not found at {server_url}.")
        else:
            raise typer.BadParameter(f"Unexpected response {response.status_code} from {url}.")
    except ImportError:
        # Fall back to urllib.request
        import urllib.request
        import urllib.error

        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=15):
                return True
        except urllib.error.HTTPError as e:
            if e.code == 401:
                raise typer.BadParameter("Authentication failed: invalid or expired token.") from e
            elif e.code == 403:
                raise typer.BadParameter(
                    f"Permission denied for workspace '{workspace_slug}'."
                ) from e
            elif e.code == 404:
                raise typer.BadParameter(
                    f"Workspace '{workspace_slug}' not found at {server_url}."
                ) from e
            else:
                raise typer.BadParameter(f"Unexpected response {e.code} from {url}.") from e
        except urllib.error.URLError as e:
            raise typer.BadParameter(f"Could not reach server {server_url}: {e.reason}") from e


# ---------------------------------------------------------------------------
# Backward-compat helper used by context.py
# ---------------------------------------------------------------------------


def load_config() -> tuple[str, str]:
    """
    Load server URL and API key from configuration.

    Returns:
        tuple: (server_url, api_key)

    Raises:
        typer.Exit: If not authenticated
    """
    config = _load_config()

    # Try default workspace first
    default_slug = config.get("default_workspace")
    if default_slug:
        workspaces = config.get("workspaces", [])
        connections = {c["id"]: c for c in config.get("connections", [])}
        for ws in workspaces:
            if ws["slug"] == default_slug:
                conn = connections.get(ws["connection_id"])
                if conn:
                    return conn["server_url"], conn["token"]

    # Fall back to first available connection
    connections = config.get("connections", [])
    if connections:
        conn = connections[0]
        return conn["server_url"], conn["token"]

    console.print("[red]✗ Not authenticated[/red]")
    console.print("\nRun [cyan]plane auth login[/cyan] to authenticate")
    raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


def _login_impl(
    server_url_opt: str | None = None,
    auth_type_opt: str | None = None,
    token_opt: str | None = None,
    workspace_opt: str | None = None,
    connection_opt: str | None = None,
    is_interactive: bool = True,  # Internal flag for output formatting
):
    """
    Add a new connection and link a workspace.

    - If workspace provided: semi-interactive (prompt for missing values)
    - If no flags provided: fully interactive prompts
    - Environment variables used as fallback: PLANE_SERVER_URL, PLANE_AUTH_TYPE, PLANE_AUTH_TOKEN, PLANE_WORKSPACE, PLANE_CONNECTION

    Args:
        server_url_opt: Optional server URL (flag > env var > prompt)
        auth_type_opt: Optional auth type: 'pat', 'workspace', '1', or '2' (flag > env var > prompt)
        token_opt: Optional API token (flag > env var > prompt)
        workspace_opt: Optional workspace slug (flag > env var > prompt)
        connection_opt: Optional connection name (flag > env var > auto-generated)
        is_interactive: If False, uses minimal output (for CI/CD)

    Returns:
        connection_id on success, raises typer.Exit on error
    """
    config = _load_config()

    # Check environment variables as fallback (lower priority than flags)
    server_url_opt = server_url_opt or os.environ.get("PLANE_SERVER_URL")
    auth_type_opt = auth_type_opt or os.environ.get("PLANE_AUTH_TYPE")
    token_opt = token_opt or os.environ.get("PLANE_AUTH_TOKEN")
    workspace_opt = workspace_opt or os.environ.get("PLANE_WORKSPACE")
    connection_opt = connection_opt or os.environ.get("PLANE_CONNECTION")

    # Determine mode: flag-based or interactive
    # If workspace is provided, use semi-interactive mode (prompt for missing flags)
    # Otherwise, fully interactive mode

    if workspace_opt:
        # Semi-interactive mode: workspace provided, prompt for missing required fields
        if is_interactive:
            console.print()
            console.print("[bold cyan]Plane CLI — New Connection[/bold cyan]")
            console.print()

        # Server URL (optional flag, has default)
        _server_url_arg: str = server_url_opt if server_url_opt is not None else Prompt.ask("  Server URL", default="https://api.plane.so")
        server_url = _normalize_server_url(_server_url_arg)

        workspace_slug = workspace_opt

        # Auth type (required for flag mode, optional for interactive)
        if auth_type_opt:
            if auth_type_opt.strip() in ("2", "workspace"):
                token_type = "workspace"
            elif auth_type_opt.strip() in ("1", "pat"):
                token_type = "pat"
            else:
                console.print(
                    "[red]Error:[/red] Invalid auth-type. Use 'pat', 'workspace', '1', or '2'."
                )
                raise typer.Exit(1)
        else:
            token_type = _prompt_auth_type()

        # Token (required, prompt if not provided)
        token = token_opt or Prompt.ask("  Token", password=True)
        if not token or len(token) < 10:
            console.print("[red]Error:[/red] Token is too short.")
            raise typer.Exit(1)

        # Connection name (prompt in semi-interactive if not provided via flag)
        if connection_opt and connection_opt.strip():
            connection_id = connection_opt
        else:
            suggested_id = _next_connection_id(config)
            connection_id = Prompt.ask("  Connection name", default=suggested_id)
            if not connection_id.strip():
                connection_id = suggested_id
    else:
        # Interactive authentication
        console.print()
        console.print("[bold cyan]Plane CLI — New Connection[/bold cyan]")
        console.print()

        # Server URL
        server_url = _normalize_server_url(
            Prompt.ask("  Server URL", default="https://api.plane.so")
        )

        # Auth type
        token_type = _prompt_auth_type()

        # Token
        token = Prompt.ask("  Token", password=True)
        if not token or len(token) < 10:
            console.print("[red]Error:[/red] Token is too short.")
            raise typer.Exit(1)

        # Workspace slug
        workspace_slug = Prompt.ask("  Workspace slug")
        if not workspace_slug or not workspace_slug.strip():
            console.print("[red]Error:[/red] Workspace slug is required.")
            raise typer.Exit(1)
        workspace_slug = workspace_slug.strip()

        # Connection name (only in fully interactive mode)
        suggested_id = _next_connection_id(config)
        connection_id = Prompt.ask("  Connection name", default=suggested_id)
        if not connection_id.strip():
            connection_id = suggested_id

    # Check for duplicate connection
    existing_ids = {c["id"] for c in config.get("connections", [])}
    if connection_id in existing_ids:
        console.print(
            f"[red]Error:[/red] Connection '{connection_id}' already exists. "
            "Choose a different name."
        )
        raise typer.Exit(1)

    # Validate workspace
    if is_interactive:
        console.print()
        console.print(
            f"  [dim]→ Validating... "
            f"(GET {server_url}/api/v1/workspaces/{workspace_slug}/projects/)[/dim]"
        )
    try:
        _validate_workspace(server_url, token, token_type, workspace_slug)
    except typer.BadParameter as e:
        error_msg = str(e)
        console.print(f"[red]Error:[/red] {error_msg}")
        if is_interactive:
            console.print("[yellow]Nothing was saved.[/yellow]")
        raise typer.Exit(1)

    # Check if workspace already linked
    existing_slugs = {ws["slug"] for ws in config.get("workspaces", [])}
    if workspace_slug in existing_slugs:
        console.print(
            f"[red]Error:[/red] Workspace '{workspace_slug}' is already linked. "
            "Use `plane auth connect-workspace` if you want to add it under a different connection."
        )
        raise typer.Exit(1)

    # All good — persist
    config.setdefault("connections", []).append(
        {
            "id": connection_id,
            "token_type": token_type,
            "token": token,
            "server_url": server_url,
        }
    )
    config.setdefault("workspaces", []).append(
        {"slug": workspace_slug, "connection_id": connection_id}
    )

    is_first_workspace = config.get("default_workspace") is None
    if is_first_workspace:
        config["default_workspace"] = workspace_slug

    _save_config(config)

    # Output based on mode
    if is_interactive:
        console.print(f"[green]✓[/green] Connection [bold]{connection_id}[/bold] created.")
        console.print(f"[green]✓[/green] Workspace [bold]{workspace_slug}[/bold] linked.")
        if is_first_workspace:
            console.print("[green]✓[/green] Set as default workspace.")
        console.print()
    else:
        # CI/CD mode: output only the connection name
        console.print(connection_id)

    return connection_id


def _list_connections_impl():
    """
    Display all connections and their linked workspaces.

    Alias: plane auth whoami
    """
    config = _load_config()
    connections = config.get("connections", [])

    if not connections:
        console.print()
        console.print("[yellow]No connections configured.[/yellow]")
        console.print("\nRun [cyan]plane auth login[/cyan] to add your first connection.")
        console.print()
        return

    default_slug = config.get("default_workspace")
    workspaces = config.get("workspaces", [])

    # Build mapping: connection_id -> list of slugs
    conn_workspaces: dict[str, list[str]] = {}
    for ws in workspaces:
        conn_id = ws["connection_id"]
        conn_workspaces.setdefault(conn_id, []).append(ws["slug"])

    table = Table(
        show_header=True,
        header_style="bold cyan",
        box=rich_box.ROUNDED,
        padding=(0, 1),
        border_style="dim",
    )
    table.add_column("ID", style="cyan")
    table.add_column("Type")
    table.add_column("Server")
    table.add_column("Workspaces")

    for conn in connections:
        conn_id = conn["id"]
        token_type_display = "PAT" if conn.get("token_type") == "pat" else "workspace"
        slugs = conn_workspaces.get(conn_id, [])

        # Annotate default workspace with a star
        slug_display_parts = []
        for slug in slugs:
            if slug == default_slug:
                slug_display_parts.append(f"{slug} [yellow]★[/yellow]")
            else:
                slug_display_parts.append(slug)
        workspaces_display = (
            ", ".join(slug_display_parts) if slug_display_parts else "[dim]none[/dim]"
        )

        table.add_row(
            conn_id,
            token_type_display,
            conn.get("server_url", ""),
            workspaces_display,
        )

    console.print()
    console.print("  [bold]CONNECTIONS[/bold]")
    console.print(table)
    console.print("  [yellow]★[/yellow] = default workspace")
    console.print()


@app.command(name="connect-workspace")
def connect_workspace(
    workspace_slug: str = typer.Argument(..., help="Workspace slug to link"),
    connection_id: str = typer.Option(..., "--connection", "-c", help="Connection ID to link the workspace to (required)"),
):
    """Link an existing workspace slug to an existing connection."""
    config = _load_config()

    # Find connection
    connections = {c["id"]: c for c in config.get("connections", [])}
    if connection_id not in connections:
        console.print(f"[red]Error:[/red] Connection '{connection_id}' does not exist.")
        console.print("Run [cyan]plane auth list-connections[/cyan] to see available connections.")
        raise typer.Exit(1)

    # Check for duplicate workspace
    existing_slugs = {ws["slug"] for ws in config.get("workspaces", [])}
    if workspace_slug in existing_slugs:
        console.print(f"[red]Error:[/red] Workspace '{workspace_slug}' is already linked.")
        raise typer.Exit(1)

    # Validate
    conn = connections[connection_id]
    console.print(
        f"\n  [dim]→ Validating... "
        f"(GET {conn['server_url']}/api/v1/workspaces/{workspace_slug}/projects/)[/dim]"
    )
    try:
        _validate_workspace(conn["server_url"], conn["token"], conn["token_type"], workspace_slug)
    except typer.BadParameter as e:
        console.print(f"\n[red]✗ Validation failed:[/red] {e}")
        raise typer.Exit(1)

    config.setdefault("workspaces", []).append(
        {"slug": workspace_slug, "connection_id": connection_id}
    )
    _save_config(config)

    console.print(
        f"[green]✓[/green] Workspace [bold]{workspace_slug}[/bold] linked to [bold]{connection_id}[/bold]."
    )


@app.command(name="disconnect-workspace")
def disconnect_workspace(
    workspace_slug: str = typer.Argument(..., help="Workspace slug to unlink"),
    connection_id: str = typer.Option(
        None, "--connection", "-c", help="Verify connection before removing"
    ),
):
    """Unlink a workspace slug."""
    config = _load_config()

    workspaces = config.get("workspaces", [])
    target = None
    for ws in workspaces:
        if ws["slug"] == workspace_slug:
            target = ws
            break

    if target is None:
        console.print(f"[red]Error:[/red] Workspace '{workspace_slug}' is not linked.")
        raise typer.Exit(1)

    if connection_id and target["connection_id"] != connection_id:
        console.print(
            f"[red]Error:[/red] Workspace '{workspace_slug}' is linked to "
            f"'{target['connection_id']}', not '{connection_id}'."
        )
        raise typer.Exit(1)

    actual_conn_id = target["connection_id"]
    config["workspaces"] = [ws for ws in workspaces if ws["slug"] != workspace_slug]

    # Update default if needed
    if config.get("default_workspace") == workspace_slug:
        remaining = config.get("workspaces", [])
        config["default_workspace"] = remaining[0]["slug"] if remaining else None
        if config["default_workspace"]:
            console.print(
                f"[yellow]Default workspace updated to '{config['default_workspace']}'.[/yellow]"
            )
        else:
            console.print("[yellow]No default workspace set.[/yellow]")

    _save_config(config)
    console.print(f"[green]✓[/green] Workspace [bold]{workspace_slug}[/bold] unlinked.")

    # Warn if connection now has no workspaces
    remaining_for_conn = [
        ws for ws in config.get("workspaces", []) if ws["connection_id"] == actual_conn_id
    ]
    if not remaining_for_conn:
        console.print(
            f"[yellow]⚠[/yellow] {actual_conn_id} now has no workspaces. "
            f"Run `plane auth logout {actual_conn_id}` to remove it."
        )


@app.command(name="logout")
def logout(
    connection_id: str = typer.Argument(..., help="Connection ID to remove"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt"),
):
    """Remove a connection and all its linked workspaces."""
    config = _load_config()

    connections = config.get("connections", [])
    target_conn = next((c for c in connections if c["id"] == connection_id), None)
    if target_conn is None:
        console.print(f"[red]Error:[/red] Connection '{connection_id}' does not exist.")
        raise typer.Exit(1)

    affected_workspaces = [
        ws for ws in config.get("workspaces", []) if ws["connection_id"] == connection_id
    ]
    n = len(affected_workspaces)

    if not force:
        confirmed = Confirm.ask(
            f"This will remove {connection_id} and {n} workspace(s). Continue?",
            default=False,
        )
        if not confirmed:
            console.print("Aborted.")
            raise typer.Exit(0)

    # Remove connection
    config["connections"] = [c for c in connections if c["id"] != connection_id]

    # Remove affected workspaces
    removed_slugs = {ws["slug"] for ws in affected_workspaces}
    config["workspaces"] = [
        ws for ws in config.get("workspaces", []) if ws["slug"] not in removed_slugs
    ]

    # Update default if needed
    if config.get("default_workspace") in removed_slugs:
        remaining = config.get("workspaces", [])
        config["default_workspace"] = remaining[0]["slug"] if remaining else None

    _save_config(config)

    console.print(f"[green]✓[/green] Removed connection [bold]{connection_id}[/bold].")
    for slug in sorted(removed_slugs):
        console.print(f"[green]✓[/green] Removed workspace [bold]{slug}[/bold].")
    if config.get("default_workspace"):
        console.print(f"[dim]Default workspace is now '{config['default_workspace']}'.[/dim]")
    else:
        console.print("[yellow]No default workspace set.[/yellow]")


# ---------------------------------------------------------------------------
# Command wrappers with typer decorators
# ---------------------------------------------------------------------------


@app.command(name="login")
def login(
    server_url: str = typer.Option(
        None, "--server-url", help="Plane server URL (e.g., https://api.plane.so)"
    ),
    auth_type: str = typer.Option(
        None, "--auth-type", help="Auth type: 'pat', 'workspace', '1', or '2'"
    ),
    token: str = typer.Option(None, "--token", help="API token or API key"),
    workspace: str = typer.Option(None, "--workspace", "-w", help="Workspace slug"),
    connection: str = typer.Option(
        None, "--connection", "-c", help="Connection name (auto-generated if not provided)"
    ),
):
    """
    Authenticate with Plane.

    Non-interactive mode (for CI/CD):
        plane auth login --server-url https://api.plane.so --auth-type pat --token YOUR_TOKEN --workspace myteam
        → Returns: connection-1

    Interactive mode:
        plane auth login
        → Prompts for all values
    """
    # Determine if flag-based or interactive
    flags_provided = any([server_url, auth_type, token, workspace])
    is_interactive = not flags_provided

    _login_impl(
        server_url_opt=server_url,
        auth_type_opt=auth_type,
        token_opt=token,
        workspace_opt=workspace,
        connection_opt=connection,
        is_interactive=is_interactive,
    )


@app.command(name="connect", hidden=True)
def connect(
    server_url: str = typer.Option(None, "--server-url", help="Plane server URL"),
    auth_type: str = typer.Option(
        None, "--auth-type", help="Auth type: 'pat', 'workspace', '1', or '2'"
    ),
    token: str = typer.Option(None, "--token", help="API token or API key"),
    workspace: str = typer.Option(None, "--workspace", "-w", help="Workspace slug"),
    connection: str = typer.Option(
        None, "--connection", "-c", help="Connection name (auto-generated if not provided)"
    ),
):
    """Alias for 'plane auth login' (hidden)."""
    flags_provided = any([server_url, auth_type, token, workspace])
    is_interactive = not flags_provided

    _login_impl(
        server_url_opt=server_url,
        auth_type_opt=auth_type,
        token_opt=token,
        workspace_opt=workspace,
        connection_opt=connection,
        is_interactive=is_interactive,
    )


@app.command(name="list-connections")
def list_connections():
    """List all saved connections and their linked workspaces."""
    _list_connections_impl()


@app.command(name="whoami", hidden=True)
def whoami():
    """Alias for 'plane auth list-connections' (hidden)."""
    _list_connections_impl()


@app.command(name="connections", hidden=True)
def connections():
    """Alias for 'plane auth list-connections' (hidden)."""
    _list_connections_impl()
