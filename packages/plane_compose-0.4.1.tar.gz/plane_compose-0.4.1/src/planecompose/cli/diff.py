"""Diff command - show bidirectional differences between local and remote work items.

Shows what would change if you pushed local changes or pulled remote changes.
Connects to Plane to fetch remote work items and compares them with local state.
"""
import asyncio
import json
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

import typer

from planecompose.parser.work_yaml import parse_work_items
from planecompose.utils.work_items import (
    calculate_content_hash,
    get_tracking_key,
    is_remote_snapshot_source,
    CONTENT_HASH_VERSION,
)
from planecompose.cli.helpers import (
    console,
    require_project_context,
    create_progress,
    connect_backend,
    fetch_remote_schema,
    compare_schema_items,
    print_schema_section,
    detect_workflow_changes,
)
from planecompose.utils.errors import handle_api_error
from planecompose.utils.logger import get_logger

logger = get_logger()


# ============================================================================
# Data Structures for Diff Results
# ============================================================================


class DiffCategory(str, Enum):
    """Categories for work item diff results."""

    NEW_LOCAL = "new_local"  # In local, not in state (never pushed)
    MODIFIED_LOCAL = "modified_local"  # Local hash changed, remote unchanged
    MODIFIED_REMOTE = "modified_remote"  # Remote hash changed, local unchanged
    CONFLICT = "conflict"  # Both sides changed
    IN_SYNC = "in_sync"  # All hashes match
    DELETED_REMOTE = "deleted_remote"  # In state but not in remote


@dataclass
class DiffEntry:
    """A single diff result entry."""

    category: DiffCategory
    title: str
    tracking_key: str | None
    remote_id: str | None
    source: str | None
    local_hash: str | None
    state_hash: str | None
    remote_hash: str | None
    field_diffs: dict[str, tuple] | None = None  # {"field_name": (local_val, remote_val), ...}


@dataclass
class WorkItemDiffResult:
    """Aggregated diff result across all categories."""

    new_local: list[DiffEntry]
    modified_local: list[DiffEntry]
    modified_remote: list[DiffEntry]
    conflicts: list[DiffEntry]
    in_sync: list[DiffEntry]
    deleted_remote: list[DiffEntry]

    @property
    def has_differences(self) -> bool:
        """True if there are any differences between local and remote."""
        return bool(
            self.new_local
            or self.modified_local
            or self.modified_remote
            or self.conflicts
            or self.deleted_remote
        )

    @property
    def conflict_count(self) -> int:
        """Count of conflicting items."""
        return len(self.conflicts)


# ============================================================================
# CLI Command
# ============================================================================


def diff(
    project: str | None = typer.Argument(None, help="Project folder name (e.g. testcompose1). Combined with --path if provided."),
    path: Path | None = typer.Option(None, "--path", help="Parent directory containing the project (default: current directory)"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    exit_code: bool = typer.Option(False, "--exit-code", help="Use differentiated exit codes for CI/CD: 0=in sync, 1=error, 2=differences found"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show content hashes for debugging"),
    schema_only: bool = typer.Option(
        False,
        "--schema-only",
        help="Alias for --skip workitems --skip cycles --skip modules",
    ),
    skip: list[str] = typer.Option(
        [],
        "--skip",
        help="Skip a section: workitems, cycles, modules. Repeatable.",
    ),
):
    """
    Show bidirectional differences between local and remote work items.

    Shows what would change if you:
    - Pushed local changes to remote
    - Pulled remote changes to local

    Connects to Plane to fetch remote work items and compares them with
    local state, giving you a complete picture of divergence.

    Exit codes (with --exit-code):
        0: Local and remote are in sync
        1: Error occurred
        2: Differences found (changes needed on either side)

    Examples:
        plane diff                                      # Diff current project
        plane diff testcompose1                         # Diff cwd/testcompose1
        plane diff testcompose1 --path ./projects      # Diff ./projects/testcompose1
        plane diff --path ./projects/testcompose1      # Diff specific full path
        plane diff --json                               # Machine-readable output
        plane diff --exit-code                          # CI-friendly exit codes
        plane diff --verbose                            # Show hash details for debugging
        plane diff --skip workitems                     # Skip work items diff
        plane diff --schema-only                        # Skip all work data diff
    """
    # Resolve the project directory (same pattern as push command)
    resolved_path: Path | None
    if project:
        resolved_path = (path or Path.cwd()).resolve() / project
    else:
        resolved_path = path.resolve() if path else None

    # Compute effective skip set
    from planecompose.cli.helpers import validate_project_skip
    skip_set = set(skip)
    if schema_only:
        skip_set |= {"workitems", "cycles", "modules"}
    validate_project_skip(skip_set)

    try:
        asyncio.run(_diff(resolved_path, json_output, exit_code_mode=exit_code, verbose=verbose, skip_set=skip_set))
    except KeyboardInterrupt:
        if not json_output:
            console.print("\n[yellow]Cancelled.[/yellow]")
        raise typer.Exit(130)


# ============================================================================
# Field-Level Comparison
# ============================================================================


def _compute_field_diffs(local_item, remote_item) -> dict[str, tuple]:
    """
    Compare local and remote work items field by field.

    Returns dict of differing fields: {field_name: (local_value, remote_value)}
    """
    diffs = {}

    # Fields to compare
    fields_to_check = [
        "title",
        "description",
        "state",
        "priority",
        "labels",
        "assignees",
        "start_date",
        "target_date",
        "estimate_point",
        "is_draft",
    ]

    for field in fields_to_check:
        local_val = getattr(local_item, field, None)
        remote_val = getattr(remote_item, field, None)

        if local_val != remote_val:
            diffs[field] = (local_val, remote_val)

    return diffs


def _format_field_value(value) -> str:
    """Format a field value for display."""
    if value is None:
        return "—"
    if isinstance(value, list):
        return ", ".join(str(v) for v in value) if value else "—"
    if isinstance(value, bool):
        return "Yes" if value else "No"
    return str(value)


# ============================================================================
# Core Logic: Bidirectional Comparison
# ============================================================================


def _classify_work_items(
    local_items: list, state_items: dict, remote_by_id: dict
) -> WorkItemDiffResult:
    """
    Classify work items into diff categories by comparing local, state, and remote hashes.

    Args:
        local_items: list[WorkItemWithMeta] from parse_work_items()
        state_items: dict[tracking_key, WorkItemState] from ctx.state.work_items
        remote_by_id: dict[remote_id, WorkItem] — only remote items we care about

    Returns:
        WorkItemDiffResult with items classified into 6 categories
    """
    # Build lookup map for local items
    local_by_key = {
        get_tracking_key(m.item, m.source_file, m.index): m for m in local_items
    }

    result = WorkItemDiffResult(
        new_local=[],
        modified_local=[],
        modified_remote=[],
        conflicts=[],
        in_sync=[],
        deleted_remote=[],
    )

    # Walk state items and classify
    for tracking_key, item_state in state_items.items():
        # Skip remote snapshot sources (items pulled from remote)
        if is_remote_snapshot_source(item_state.source):
            continue

        # Look up remote item by its UUID
        remote_item = remote_by_id.get(item_state.remote_id)
        local_meta = local_by_key.get(tracking_key)

        # If remote item is gone, it was deleted remotely
        if remote_item is None:
            result.deleted_remote.append(
                DiffEntry(
                    category=DiffCategory.DELETED_REMOTE,
                    title=f"[tracked: {tracking_key}]",
                    tracking_key=tracking_key,
                    remote_id=item_state.remote_id,
                    source=item_state.source,
                    local_hash=None,
                    state_hash=item_state.content_hash,
                    remote_hash=None,
                )
            )
            continue

        # Compute hashes
        state_hash = item_state.content_hash
        remote_hash = calculate_content_hash(remote_item)
        local_hash = (
            calculate_content_hash(local_meta.item) if local_meta else state_hash
        )

        # Handle stale hash version: treat as modified if hash algorithm changed
        if item_state.hash_version != CONTENT_HASH_VERSION:
            local_hash = "stale_version"  # Force != state_hash

        title = local_meta.item.title if local_meta else f"[tracked: {tracking_key}]"

        # Compute field diffs for modified items
        field_diffs = None
        if local_hash != state_hash and local_meta:
            # Local changed: compute field diffs between local and remote
            field_diffs = _compute_field_diffs(local_meta.item, remote_item)
        elif remote_hash != state_hash:
            # Remote changed: compute field diffs between local and remote
            if local_meta:
                field_diffs = _compute_field_diffs(local_meta.item, remote_item)

        # Classify by hash comparison
        if local_hash == state_hash and remote_hash == state_hash:
            result.in_sync.append(
                DiffEntry(
                    category=DiffCategory.IN_SYNC,
                    title=title,
                    tracking_key=tracking_key,
                    remote_id=item_state.remote_id,
                    source=item_state.source,
                    local_hash=local_hash,
                    state_hash=state_hash,
                    remote_hash=remote_hash,
                )
            )
        elif local_hash != state_hash and remote_hash == state_hash:
            result.modified_local.append(
                DiffEntry(
                    category=DiffCategory.MODIFIED_LOCAL,
                    title=title,
                    tracking_key=tracking_key,
                    remote_id=item_state.remote_id,
                    source=item_state.source,
                    local_hash=local_hash,
                    state_hash=state_hash,
                    remote_hash=remote_hash,
                    field_diffs=field_diffs,
                )
            )
        elif local_hash == state_hash and remote_hash != state_hash:
            result.modified_remote.append(
                DiffEntry(
                    category=DiffCategory.MODIFIED_REMOTE,
                    title=title,
                    tracking_key=tracking_key,
                    remote_id=item_state.remote_id,
                    source=item_state.source,
                    local_hash=local_hash,
                    state_hash=state_hash,
                    remote_hash=remote_hash,
                    field_diffs=field_diffs,
                )
            )
        else:  # local_hash != state_hash and remote_hash != state_hash
            result.modified_local.append(
                DiffEntry(
                    category=DiffCategory.MODIFIED_LOCAL,
                    title=title,
                    tracking_key=tracking_key,
                    remote_id=item_state.remote_id,
                    source=item_state.source,
                    local_hash=local_hash,
                    state_hash=state_hash,
                    remote_hash=remote_hash,
                    field_diffs=field_diffs,
                )
            )

    # Local items not in state → new, never pushed
    for tracking_key, local_meta in local_by_key.items():
        if tracking_key not in state_items:
            result.new_local.append(
                DiffEntry(
                    category=DiffCategory.NEW_LOCAL,
                    title=local_meta.item.title,
                    tracking_key=tracking_key,
                    remote_id=None,
                    source=f"{local_meta.source_file}:{local_meta.index}",
                    local_hash=calculate_content_hash(local_meta.item),
                    state_hash=None,
                    remote_hash=None,
                )
            )

    return result


# ============================================================================
# Async Implementation
# ============================================================================


async def _diff(path: Path | None, json_output: bool, exit_code_mode: bool = False, verbose: bool = False, skip_set: set[str] | None = None):
    """Async implementation of diff.

    Mirrors plane push: shows schema diff first, then work items diff.
    Backend is connected once and shared across both sections.
    """
    if skip_set is None:
        skip_set = set()
    backend = None
    if json_output:
        console.quiet = True

    try:
        ctx = require_project_context(path)

        # Filesystem-as-state: if a work/ file doesn't exist, auto-add to skip_set
        work_dir = ctx.root_path / "work"
        if not (work_dir / "cycles.yaml").exists():
            skip_set = skip_set | {"cycles"}
        if not (work_dir / "modules.yaml").exists():
            skip_set = skip_set | {"modules"}
        # Filesystem-as-state for workitems: skip if no work item files present.
        # Any *.yaml in work/ except cycles.yaml and modules.yaml counts.
        _NON_WORKITEM_FILES_DIFF = {"cycles.yaml", "modules.yaml"}
        if not any(
            f.name not in _NON_WORKITEM_FILES_DIFF
            for f in work_dir.glob("*.yaml")
        ):
            skip_set = skip_set | {"workitems"}

        # Parse local work items before connecting (fail fast if YAML is invalid)
        local_items = [] if "workitems" in skip_set else list(parse_work_items(ctx.work_path, ctx.root_path))

        # Always connect — we need it for both schema diff and work items diff
        with create_progress() as (progress, task):
            progress.update(task, description="Connecting to Plane...")
            ctx, backend = await connect_backend(ctx, progress=progress, task=task)

            # ── Schema diff ──────────────────────────────────────────────────
            (
                remote_types,
                remote_states,
                remote_labels,
                remote_workflows,
                remote_modules,
                remote_cycles,
            ) = await fetch_remote_schema(backend, progress=progress, task=task)

            remote_features: dict[str, bool] = {}
            try:
                remote_features = await backend.get_project_features()
            except Exception as e:
                logger.debug(f"Could not fetch remote features for diff: {e}")

            # ── Work items diff ──────────────────────────────────────────────
            remote_by_id: dict = {}
            if "workitems" not in skip_set:
                progress.update(task, description="Fetching tracked work items...")
                remote_ids_to_fetch = {
                    ws.remote_id
                    for ws in ctx.state.work_items.values()
                    if ws.remote_id and not is_remote_snapshot_source(ws.source)
                }

                semaphore = asyncio.Semaphore(3)

                async def _fetch_one(remote_id: str):
                    async with semaphore:
                        try:
                            item = await backend.get_work_item(remote_id)
                            return (remote_id, item)
                        except Exception:
                            return (remote_id, None)

                results = await asyncio.gather(
                    *[_fetch_one(rid) for rid in remote_ids_to_fetch]
                )
                for remote_id, item in results:
                    if item:
                        remote_by_id[remote_id] = item

        if json_output:
            # JSON mode: work items only (schema diff is rich-only for now)
            result = _classify_work_items(local_items, ctx.state.work_items, remote_by_id)
            _display_json(result)
            if exit_code_mode and result.has_differences:
                raise typer.Exit(2)
            return

        # ── Rich output ──────────────────────────────────────────────────────

        # Section 1: Schema diff (same logic as `plane schema diff`)
        console.print("\n[bold]Schema Comparison: Local ↔ Remote[/bold]\n")

        only_local_types, only_remote_types, types_in_both, renamed_types = compare_schema_items(ctx.types, remote_types)
        print_schema_section("Types", only_local_types, only_remote_types, types_in_both, renamed_types)

        only_local_states, only_remote_states, states_in_both, renamed_states = compare_schema_items(ctx.states, remote_states)
        print_schema_section("States", only_local_states, only_remote_states, states_in_both, renamed_states)

        only_local_labels, only_remote_labels, labels_in_both, renamed_labels = compare_schema_items(ctx.labels, remote_labels)
        print_schema_section("Labels", only_local_labels, only_remote_labels, labels_in_both, renamed_labels)

        only_local_modules, only_remote_modules, modules_in_both, renamed_modules = compare_schema_items(ctx.modules, remote_modules)
        print_schema_section("Modules", only_local_modules, only_remote_modules, modules_in_both, renamed_modules)

        # Workflows
        only_local_wf, only_remote_wf, wf_in_both, renamed_wf = compare_schema_items(ctx.workflows, remote_workflows)
        wf_changes = detect_workflow_changes(ctx.workflows, remote_workflows)
        wf_wit_changes = wf_changes["wit_changes"]
        wf_state_changes = wf_changes["state_changes"]
        wf_rule_changes = wf_changes["rule_changes"]
        wf_has_changes = bool(only_local_wf or only_remote_wf or renamed_wf or wf_wit_changes or wf_state_changes or wf_rule_changes)
        if wf_has_changes or wf_in_both:
            console.print("[bold cyan]Workflows:[/bold cyan]")
            for local_name, remote_name in renamed_wf:
                console.print(f'  [yellow]~[/yellow] {local_name} → remote: "{remote_name}" (modified remotely)')
            for wf_name, local_wits, remote_wits in wf_wit_changes:
                console.print(f"  [yellow]~[/yellow] {wf_name}: work_item_types changed")
                added = local_wits - remote_wits
                removed = remote_wits - local_wits
                if added:
                    console.print(f"    [green]  + Added: {', '.join(sorted(added))}")
                if removed:
                    console.print(f"    [red]  - Removed: {', '.join(sorted(removed))}")
            for wf_name, local_st, remote_st_set in wf_state_changes:
                console.print(f"  [yellow]~[/yellow] {wf_name}: states changed")
                added = local_st - remote_st_set
                removed = remote_st_set - local_st
                if added:
                    console.print(f"    [green]  + Added: {', '.join(sorted(added))}")
                if removed:
                    console.print(f"    [red]  - Removed: {', '.join(sorted(removed))}")
            for wf_name, rule_descs in wf_rule_changes:
                console.print(f"  [yellow]~[/yellow] {wf_name}: transition conditions changed")
                for desc in rule_descs:
                    console.print(f"    [yellow]  ~ {desc}[/yellow]")
            if only_local_wf:
                console.print(f"  [green]+[/green] Only in local: {', '.join(only_local_wf)}")
            if only_remote_wf:
                console.print(f"  [red]-[/red] Only in remote: {', '.join(only_remote_wf)}")
            if wf_in_both and not wf_has_changes:
                console.print(f"  [dim]= {wf_in_both} workflow(s) in sync[/dim]")
            console.print()

        # Cycles
        only_local_cycles, only_remote_cycles, cycles_in_both, renamed_cycles = compare_schema_items(ctx.cycles, remote_cycles)
        print_schema_section("Cycles", only_local_cycles, only_remote_cycles, cycles_in_both, renamed_cycles)

        # Features
        feature_diffs: list[tuple[str, bool, bool]] = []
        features_in_sync = 0
        local_features: dict[str, bool] = {}
        _local_features_path = ctx.schema_path / "features.yaml"
        if _local_features_path.exists():
            import yaml as _fyaml
            _fdata = _fyaml.safe_load(open(_local_features_path)) or {}
            local_features = _fdata.get("features", {})

        if local_features and remote_features:
            all_keys = sorted(set(local_features) | set(remote_features))
            for key in all_keys:
                local_val = local_features.get(key)
                remote_val = remote_features.get(key)
                if local_val is None or remote_val is None:
                    continue
                if local_val != remote_val:
                    feature_diffs.append((key, local_val, remote_val))
                else:
                    features_in_sync += 1
            console.print("[bold cyan]Features:[/bold cyan]")
            for feat_name, local_val, remote_val in feature_diffs:
                local_str = "[green]true[/green]" if local_val else "[red]false[/red]"
                remote_str = "[green]true[/green]" if remote_val else "[red]false[/red]"
                console.print(f"  [yellow]~[/yellow] {feat_name}: local={local_str}, remote={remote_str}")
            sync_count = features_in_sync if feature_diffs else features_in_sync
            console.print(f"  [dim]= {sync_count} feature(s) in sync[/dim]")
            console.print()

        schema_has_diff = bool(
            only_local_types or only_remote_types or renamed_types
            or only_local_states or only_remote_states or renamed_states
            or only_local_labels or only_remote_labels or renamed_labels
            or only_local_modules or only_remote_modules or renamed_modules
            or only_local_wf or only_remote_wf or renamed_wf
            or wf_wit_changes or wf_state_changes or wf_rule_changes
            or only_local_cycles or only_remote_cycles or renamed_cycles
            or feature_diffs
        )
        if not schema_has_diff:
            console.print("[green]✓ Schema in sync![/green]\n")

        # Section 2: Work items diff
        result = _classify_work_items(local_items, ctx.state.work_items, remote_by_id)
        _display_rich(result, verbose=verbose)

        has_diff = schema_has_diff or result.has_differences
        if not has_diff:
            pass  # both sections already printed their own "in sync" messages
        else:
            console.print("[yellow]Actions:[/yellow]")
            if schema_has_diff:
                console.print("  [cyan]plane schema push[/cyan]  - Push schema changes")
                console.print("  [cyan]plane schema import --merge[/cyan]  - Add remote-only schema locally")
            if result.has_differences:
                console.print("  [cyan]plane push[/cyan]  - Push work item changes")
                console.print("  [cyan]plane pull[/cyan]  - Pull remote changes")
            console.print()

        if exit_code_mode and has_diff:
            raise typer.Exit(2)

    except asyncio.CancelledError:
        pass
    except typer.Exit:
        raise
    except Exception as e:
        if json_output:
            console.quiet = False
            print(
                json.dumps(
                    {
                        "command": "diff",
                        "success": False,
                        "error": str(e),
                    },
                    indent=2,
                )
            )
            raise typer.Exit(1)
        handle_api_error(e, "diff work items")
        raise typer.Exit(1)
    finally:
        console.quiet = False
        if backend:
            await backend.disconnect()


# ============================================================================
# Display Functions
# ============================================================================


def _display_json(result: WorkItemDiffResult) -> None:
    """Output diff result as JSON."""

    def entry_to_dict(e: DiffEntry) -> dict[str, Any]:
        data: dict[str, Any] = {
            "category": e.category.value,
            "title": e.title,
            "tracking_key": e.tracking_key,
            "remote_id": e.remote_id,
            "source": e.source,
        }
        if e.field_diffs:
            data["field_diffs"] = {
                field: {"local": _format_field_value(local), "remote": _format_field_value(remote)}
                for field, (local, remote) in e.field_diffs.items()
            }
        return data

    # Collect all items
    all_items = (
        result.new_local
        + result.modified_local
        + result.modified_remote
        + result.in_sync
        + result.deleted_remote
    )

    data = {
        "command": "diff",
        "success": True,
        "has_differences": result.has_differences,
        "summary": {
            "new_local": len(result.new_local),
            "modified_local": len(result.modified_local),
            "modified_remote": len(result.modified_remote),
            "in_sync": len(result.in_sync),
            "deleted_remote": len(result.deleted_remote),
        },
        "items": [entry_to_dict(e) for e in all_items],
    }
    print(json.dumps(data, indent=2))


def _display_rich(result: WorkItemDiffResult, verbose: bool = False) -> None:
    """Display diff result using Rich formatting with field-level details."""
    console.print("\n[bold]Work Items: Local ↔ Remote[/bold]\n")

    has_anything = False

    # Show new local items
    if result.new_local:
        has_anything = True
        console.print("[bold cyan]New Locally (+):[/bold cyan]")
        for entry in result.new_local:
            console.print(f"  {entry.title}")
        console.print()

    # Show modified local items with field diffs
    if result.modified_local:
        has_anything = True
        console.print("[bold yellow]Modified Locally (~):[/bold yellow]")
        for entry in result.modified_local:
            console.print(f"  {entry.title}")
            if entry.field_diffs:
                for field_name, (local_val, remote_val) in entry.field_diffs.items():
                    local_str = _format_field_value(local_val)
                    remote_str = _format_field_value(remote_val)
                    console.print(
                        f"    [dim]{field_name}:[/dim] (local) [green]\"{local_str}\"[/green]  (remote) [dim]\"{remote_str}\"[/dim]"
                    )
        console.print()

    # Show modified remote items with field diffs
    if result.modified_remote:
        has_anything = True
        console.print("[bold cyan]Modified Remotely (!):[/bold cyan]")
        for entry in result.modified_remote:
            console.print(f"  {entry.title}")
            if entry.field_diffs:
                for field_name, (local_val, remote_val) in entry.field_diffs.items():
                    local_str = _format_field_value(local_val)
                    remote_str = _format_field_value(remote_val)
                    console.print(
                        f"    [dim]{field_name}:[/dim] (local) [dim]\"{local_str}\"[/dim]  (remote) [cyan]\"{remote_str}\"[/cyan]"
                    )
        console.print()

    # Show deleted remote items
    if result.deleted_remote:
        has_anything = True
        console.print("[bold dim]Deleted Remotely (d):[/bold dim]")
        for entry in result.deleted_remote:
            console.print(f"  [dim]{entry.title}[/dim]")
        console.print()

    # Always show in_sync count
    if result.in_sync:
        console.print(f"[dim]= {len(result.in_sync)} in sync[/dim]")
        console.print()

    # Summary
    if not has_anything and not result.in_sync:
        console.print("[green]✓ All items are in sync![/green]\n")
    elif not has_anything:
        console.print("[green]✓ All tracked items are in sync![/green]\n")
    else:
        console.print("[green]✓ No true conflicts detected[/green]\n")

    # Show action hints
    if result.new_local or result.modified_local:
        console.print("[yellow]Push local changes:[/yellow]")
        console.print("  [cyan]plane push[/cyan]\n")
    if result.modified_remote:
        console.print("[yellow]Pull remote changes:[/yellow]")
        console.print("  [cyan]plane pull[/cyan]\n")
