"""Pull command - fetch work items from Plane.

This command uses:
- PlaneBackend for all API calls
- PullWriter for converting remote data to YAML
- StateManager for tracking pulled items
"""

import asyncio
from pathlib import Path
from typing import cast
import typer

from planecompose.sync.writer import PullWriter
from planecompose.state.manager import StateManager
from planecompose.utils.errors import handle_api_error
from planecompose.cli.helpers import (
    console,
    require_project_context,
    create_progress,
    connect_backend,
    validate_project_skip,
)
from planecompose.cli.clone_helpers import (
    write_cycles_yaml,
    write_modules_yaml,
)
from planecompose.cli.sync_helpers import sync_workspace_context
from planecompose.utils.mapping import build_id_sequence_map
from planecompose.sync.collections import fetch_cycle_items_map, fetch_module_items_map
from planecompose.parser.members_yaml import write_members_yaml, merge_member_roles
from planecompose.utils.logger import get_logger

logger = get_logger()


def pull(
    project: str | None = typer.Argument(
        None, help="Project folder name (e.g. tcomp1). Combined with --path if provided."
    ),
    path: Path | None = typer.Option(
        None, "--path", help="Parent directory containing the project (default: current directory)"
    ),
    connection: str | None = typer.Option(
        None, "--connection", "-c", help="Connection ID to use (overrides plane.yaml setting)"
    ),
    merge: bool = typer.Option(False, "--merge", help="Merge with existing items in output file"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite without confirmation"),
    schema_only: bool = typer.Option(
        False,
        "--schema-only",
        help="Alias for --skip workitems --skip cycles --skip modules",
    ),
    skip: list[str] = typer.Option(
        [],
        "--skip",
        help="Skip a section: workitems, cycles, modules. Repeatable.",
    ),
    with_properties: bool = typer.Option(
        True,
        "--with-properties/--no-properties",
        help="Fetch custom property values (default: yes)",
    ),
    work_only: bool = typer.Option(False, "--work-only", help="Pull only work items (skip schema)"),
    all_projects: bool = typer.Option(False, "--all", help="Pull all projects found recursively", hidden=True),
    filter_workspace: str | None = typer.Option(
        None, "--workspace", "-w", help="Filter projects by workspace (with --all)"
    ),
    filter_pattern: str | None = typer.Option(
        None, "--filter", help="Filter projects by glob pattern (with --all)", hidden=True
    ),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON", hidden=True),
):
    """
    Pull schema and work items from YOUR project (uses plane.yaml context).

    By default, pulls both schema and work items.
    Use --work-only to skip schema (faster).
    Use --schema-only to skip work items (much faster for large projects).

    Fetches work items from your project and writes to work/workitems.yaml.
    By default, fetches custom property values (use --no-properties to skip).

    For cloning someone else's project, use 'plane clone <uuid>' instead.

    Examples:
        plane pull                                   # Pull project in current directory
        plane pull tcomp1                            # Pull cwd/tcomp1
        plane pull tcomp1 --path ./projects         # Pull ./projects/tcomp1
        plane pull --path ./projects/tcomp1         # Pull specific full path
        plane pull --schema-only                    # Fast schema-only pull
        plane pull --skip workitems                 # Skip only work items
        plane pull --skip cycles --skip modules     # Skip cycles and modules
        plane pull --all                            # Pull all projects
        plane pull --all --workspace=myteam         # Pull all projects in workspace
        plane pull --json                           # Machine-readable output
    """
    # Resolve project directory (same pattern as push)
    resolved_path: Path | None
    if project:
        resolved_path = (path or Path.cwd()).resolve() / project
    else:
        resolved_path = path.resolve() if path else None

    # Compute effective skip set
    skip_set = set(skip)
    if schema_only:
        skip_set |= {"workitems", "cycles", "modules"}
    validate_project_skip(skip_set)

    try:
        # JSON mode implies force (skip interactive prompts)
        if json_output:
            force = True
        if all_projects:
            asyncio.run(
                _pull_all(
                    merge,
                    force,
                    schema_only,
                    with_properties,
                    work_only,
                    filter_workspace,
                    filter_pattern,
                    connection,
                )
            )
        else:
            asyncio.run(
                _pull(
                    resolved_path,
                    merge,
                    force,
                    skip_set,
                    with_properties,
                    work_only,
                    json_output,
                    connection,
                )
            )
    except KeyboardInterrupt:
        if not json_output:
            console.print("\n[yellow]Operation cancelled.[/yellow]")
        raise typer.Exit(130)


async def _pull(
    path: Path | None,
    merge: bool,
    force: bool,
    skip_set: set[str],
    with_properties: bool,
    work_only: bool,
    json_output: bool = False,
    connection: str | None = None,
):
    """Async implementation of pull."""
    import time
    import json

    start_time = time.time()
    schema_time: float = 0
    backend = None

    # Suppress Rich output in JSON mode
    if json_output:
        console.quiet = True

    try:
        # Load project context (fail fast if plane.yaml not found)
        ctx = require_project_context(path)

        # NOTE: No filesystem-as-state auto-skip here.
        # Pull always fetches all sections from remote (unless explicitly --skip'd).
        # Filesystem-as-state applies to push/diff only — don't push what you haven't got locally.
        # Pull is the inverse: bring remote → local, always refreshing whatever exists remotely.

        # Sync workspace features before running pull
        sync_workspace_context(ctx)

        # Override connection_id if provided via CLI
        if connection:
            ctx.config.connection_id = connection

        with create_progress() as (progress, task):
            # Connect to backend
            ctx, backend = await connect_backend(ctx, progress=progress, task=task)

            writer = PullWriter(ctx.root_path)
            state_manager = StateManager(ctx.root_path)

            # Pull schema first (unless --work-only)
            if not work_only:
                schema_start = time.time()
                progress.update(task, description="Pulling schema...")

                try:
                    remote_types = await backend.list_types()
                    remote_states = await backend.list_states()
                    remote_labels = await backend.list_labels()

                    # Fetch workflows (new in Phase 4)
                    remote_workflows = None
                    try:
                        remote_workflows = await backend.fetch_workflows()
                    except Exception as e:
                        logger.debug(f"Could not fetch workflows: {e}")
                        # Non-blocking: workflows are optional

                    # Backfill type→workflow: the API returns workflow assignment
                    # on the workflow side (work_item_types list), not on the type
                    # itself. Build a reverse map so types.yaml shows the correct
                    # workflow name instead of always defaulting to "default".
                    if remote_workflows and remote_types:
                        type_name_to_workflow: dict[str, str] = {}
                        for wf in remote_workflows:
                            for type_name in (wf.work_item_types or []):
                                type_name_to_workflow[type_name] = wf.name
                        for t in remote_types:
                            if t.name in type_name_to_workflow:
                                t.workflow = type_name_to_workflow[t.name]

                    writer.write_schema(
                        remote_types, remote_states, remote_labels, remote_workflows
                    )

                    # Fetch and write project features (schema/features.yaml)
                    try:
                        project_features = await backend.get_project_features()
                        if project_features:
                            from planecompose.parser.schema_writer import write_features_yaml
                            write_features_yaml(
                                ctx.root_path / "schema" / "features.yaml", project_features
                            )
                    except Exception as e:
                        logger.debug(f"Could not fetch project features: {e}")
                        # Non-blocking: features.yaml is optional

                    # Fetch and write project members
                    try:
                        project_members = await backend.fetch_project_members(
                            ctx.config.workspace, cast(str, ctx.config.project_uuid)
                        )
                        if project_members:
                            write_members_yaml(
                                ctx.root_path,
                                merge_member_roles(project_members, ctx.root_path),
                            )
                    except Exception as e:
                        logger.debug(f"Could not fetch project members: {e}")
                        # Non-blocking: members.yaml is optional

                    # Note: All schema state will be updated together at the end
                except ValueError as e:
                    console.print(f"\n[yellow]⚠ Warning:[/yellow] Could not fetch schema: {e}")
                    console.print("[dim]Continuing without schema...[/dim]\n")
                    remote_types, remote_states, remote_labels = [], [], []

                schema_time = time.time() - schema_start

            # Fetch work items (skip if "workitems" in skip_set)
            remote_items = []
            work_item_properties = {}
            raw_items_for_props = []

            if "workitems" not in skip_set:
                progress.update(task, description="📝 Fetching work items...")
                remote_items = await backend.list_work_items()

                # Large-project safety net
                if len(remote_items) > 10000 and not force and not json_output:
                    from rich.prompt import Confirm
                    console.print(
                        f"\n[yellow]⚠[/yellow]  Remote has {len(remote_items):,} work items. "
                        f"Pull all into work/workitems.yaml?"
                    )
                    if not Confirm.ask("Continue", default=False):
                        console.print("[yellow]Cancelled[/yellow]")
                        raise typer.Exit(0)

                # Fetch properties if requested
                if with_properties and remote_items:
                    progress.update(task, description="Fetching property definitions...")

                    types_sdk = await backend.list_types_raw()
                    types_data = [
                        {
                            "id": str(t.id) if hasattr(t, "id") else None,
                            "name": getattr(t, "name", None),
                        }
                        for t in types_sdk
                    ]

                    property_maps = await backend.build_property_maps(types_data)

                    if property_maps:
                        raw_items_for_props = await backend.list_work_items_raw()

                        total_calls = sum(
                            len(property_maps.get(str(getattr(item, "type_id", None)), {}))
                            for item in raw_items_for_props
                            if hasattr(item, "type_id")
                        )

                        if total_calls > 0:
                            est_time = (
                                f"~{total_calls // 50}min"
                                if total_calls > 50
                                else f"~{total_calls}s"
                            )
                            progress.update(
                                task,
                                description=f"Fetching {total_calls} property values ({est_time})...",
                            )

                        work_item_properties = await backend.fetch_work_item_properties_batch(
                            raw_items_for_props, property_maps
                        )

                # Write work items inside the progress block
                if remote_items:
                    progress.update(task, description="Writing work/workitems.yaml...")
                    writer.write_work_items_canonical(
                        items=remote_items,
                        properties=work_item_properties if with_properties else None,
                        raw_items=raw_items_for_props if with_properties else None,
                    )

            # Fetch and write cycles (skip if --work-only or "cycles" in skip_set)
            cycles_list = []
            if not work_only and "cycles" not in skip_set:
                try:
                    progress.update(task, description="🔁 Fetching cycles...")
                    cycles_list = await backend.list_cycles_raw(
                        ctx.config.workspace, cast(str, ctx.config.project_uuid)
                    )

                    # Build cycle items map if we have work items
                    cycle_items_map: dict[str, list[str]] = {}
                    if remote_items:
                        id_to_sequence = build_id_sequence_map(remote_items, ctx.config.project_key)
                        cycle_items_map = await fetch_cycle_items_map(
                            backend,
                            ctx.config.workspace,
                            cast(str, ctx.config.project_uuid),
                            cycles_list,
                            id_to_sequence,
                        )

                    write_cycles_yaml(ctx.root_path, cycles_list, cycle_items_map)
                except Exception as e:
                    console.print(f"[yellow]⚠ Warning:[/yellow] Could not fetch cycles: {e}")

            # Fetch and write modules (skip if --work-only or "modules" in skip_set)
            modules_list = []
            if not work_only and "modules" not in skip_set:
                try:
                    progress.update(task, description="📦 Fetching modules...")
                    modules_list = await backend.list_modules_raw(
                        ctx.config.workspace, cast(str, ctx.config.project_uuid)
                    )

                    # Build module items map if we have work items
                    module_items_map: dict[str, list[str]] = {}
                    if remote_items:
                        id_to_sequence = build_id_sequence_map(remote_items, ctx.config.project_key)
                        module_items_map = await fetch_module_items_map(
                            backend,
                            ctx.config.workspace,
                            cast(str, ctx.config.project_uuid),
                            modules_list,
                            id_to_sequence,
                        )

                    write_modules_yaml(ctx.root_path, modules_list, module_items_map)
                except Exception as e:
                    console.print(f"[yellow]⚠ Warning:[/yellow] Could not fetch modules: {e}")

        # Update state with all schema mappings (types, states, labels, cycles, modules, properties)
        try:
            # Build types, states, and labels mappings (from cached schema)
            # Skip items with empty names (should not happen, but defensively handle it)
            types_mapping = {t.name: t.remote_id for t in remote_types if t.remote_id and t.name}
            states_mapping = {s.name: s.remote_id for s in remote_states if s.remote_id and s.name}
            labels_mapping = {
                lbl.name: lbl.remote_id for lbl in remote_labels if lbl.remote_id and lbl.name
            }

            # Build workflows mapping (new in Phase 4)
            workflows_mapping = {}
            if remote_workflows:
                workflows_mapping = {
                    w.name: w.remote_id for w in remote_workflows if w.remote_id and w.name
                }

            # Build properties mapping: type_id -> {property_name -> property_id}
            # Skip for enterprise instances: properties belong to workspace-level WIT,
            # not project types — storing project-level property UUIDs would be wrong.
            is_enterprise = bool(
                ctx.workspace_config
                and ctx.workspace_config.workspace_features
                and ctx.workspace_config.workspace_features.get("work_item_types", False)
            )
            properties_mapping = {}
            if not is_enterprise:
                for t in remote_types:
                    if t.remote_id and hasattr(t, "fields") and t.fields:
                        properties_mapping[t.remote_id] = {
                            prop.name: prop.remote_id
                            for prop in t.fields
                            if prop.remote_id and prop.name
                        }

            # Build cycles and modules mappings
            cycles_mapping = {}
            modules_mapping = {}

            if not work_only and "cycles" not in skip_set:
                cycles_mapping = {
                    getattr(c, "name", ""): str(getattr(c, "id", ""))
                    for c in cycles_list
                    if getattr(c, "name", "") and getattr(c, "id", "")
                }
            if not work_only and "modules" not in skip_set:
                modules_mapping = {
                    getattr(m, "name", ""): str(getattr(m, "id", ""))
                    for m in modules_list
                    if getattr(m, "name", "") and getattr(m, "id", "")
                }

            # Update state with all mappings
            state_manager.update_schema_state(
                types=types_mapping if types_mapping else None,
                states=states_mapping if states_mapping else None,
                workflows=workflows_mapping if workflows_mapping else None,
                labels=labels_mapping if labels_mapping else None,
                cycles=cycles_mapping if cycles_mapping else None,
                modules=modules_mapping if modules_mapping else None,
                properties=properties_mapping if properties_mapping else None,
            )
        except Exception as e:
            console.print(f"[yellow]⚠ Warning:[/yellow] Could not update state: {e}")

        state_manager.mark_last_sync()

        # Display unified summary
        elapsed = time.time() - start_time

        if json_output:
            console.quiet = False
            print(
                json.dumps(
                    {
                        "command": "pull",
                        "success": True,
                        "items_pulled": len(remote_items),
                        "cycles_pulled": len(cycles_list),
                        "modules_pulled": len(modules_list),
                        "skipped": sorted(skip_set),
                    },
                    indent=2,
                )
            )
        else:
            console.print()
            # Schema line (unless --work-only)
            if not work_only and schema_time:
                console.print(
                    f"  [green]✓[/green] Schema → [cyan]schema/[/cyan] [dim]({schema_time:.1f}s)[/dim]"
                )
            # Per-section counts — always show all three
            work_sections = [
                ("workitems", "📝 Work items",  len(remote_items),  "work/workitems.yaml"),
                ("cycles",    "🔁 Cycles",      len(cycles_list),   "work/cycles.yaml"),
                ("modules",   "📦 Modules",     len(modules_list),  "work/modules.yaml"),
            ]
            for key, label, count, dest in work_sections:
                # A section is "skipped" if explicitly in skip_set OR if work_only skips cycles/modules
                effectively_skipped = key in skip_set or (work_only and key in {"cycles", "modules"})
                if effectively_skipped:
                    console.print(f"  [dim]⊘ {label}: skipped[/dim]")
                else:
                    console.print(
                        f"  [green]✓[/green] {label}: [bold]{count}[/bold] → [cyan]{dest}[/cyan]"
                    )
            console.print(f"\n[green]✓[/green] Pull completed in {elapsed:.1f}s\n")

    except asyncio.CancelledError:
        pass  # KeyboardInterrupt caught in sync wrapper; CancelledError is cleanup only
    except Exception as e:
        if json_output:
            console.quiet = False
            print(
                json.dumps(
                    {
                        "command": "pull",
                        "success": False,
                        "error": str(e),
                    },
                    indent=2,
                )
            )
            raise typer.Exit(1)
        handle_api_error(e, "pull work items")
        raise typer.Exit(1)
    finally:
        if json_output:
            console.quiet = False
        if backend:
            await backend.disconnect()


async def _pull_all(
    merge: bool,
    force: bool,
    schema_only: bool,
    with_properties: bool,
    work_only: bool,
    filter_workspace: str | None,
    filter_pattern: str | None,
    connection: str | None = None,
):
    """Pull all discovered projects."""
    from planecompose.utils.multiproject import (
        discover_projects,
        run_batch,
        display_batch_results,
        display_discovered_projects,
    )

    # Convert schema_only to skip_set for _pull
    skip_set: set[str] = set()
    if schema_only:
        skip_set = {"workitems", "cycles", "modules"}

    # Discover projects
    console.print("\n[bold]Discovering projects...[/bold]")
    projects = discover_projects(
        filter_workspace=filter_workspace,
        filter_pattern=filter_pattern,
    )

    if not projects:
        console.print("[yellow]No projects found[/yellow]")
        console.print("\n[dim]Make sure you're in a directory containing plane.yaml files[/dim]")
        raise typer.Exit(1)

    # Display discovered projects
    display_discovered_projects(projects)

    # Confirm before pulling all
    if not force:
        from rich.prompt import Confirm

        if not Confirm.ask(f"Pull {len(projects)} projects?"):
            console.print("[yellow]Cancelled[/yellow]")
            raise typer.Exit(0)

    # Define the operation for each project
    async def pull_one(project_path: Path):
        await _pull(
            project_path,
            merge,
            force=True,
            skip_set=skip_set,
            with_properties=with_properties,
            work_only=work_only,
            connection=connection,
        )

    # Run batch operation
    console.print(f"\n[bold]Pulling {len(projects)} projects...[/bold]\n")

    results = await run_batch(
        projects=projects,
        operation=pull_one,
        operation_name="pull",
        concurrency=1,  # Sequential for clearer output
    )

    # Display results
    success_count, failure_count = display_batch_results(results, "pull")

    if failure_count > 0:
        raise typer.Exit(1)
