"""Workspace commands — plane ws

Implements workspace-level schema operations:
  plane ws clone   — clone workspace config into a local folder
  plane ws pull    — pull latest workspace config into an existing folder
  plane ws diff    — show what differs between local and remote
  plane ws push    — push local schema changes to the workspace
  plane ws state   — inspect and manage workspace sync state
"""

import asyncio
import shutil
import tempfile
import time
from pathlib import Path
from typing import Any

import typer
import yaml
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from planecompose.backend.workspace_sync import workspace_http_get
from planecompose.utils.logger import get_logger

logger = get_logger()
console = Console()

# Plane member role values → human-readable labels
_ROLE_LABELS: dict[int, str] = {20: "admin", 15: "member", 10: "viewer", 5: "guest"}

# Valid --skip values for plane ws commands
_VALID_WS_SKIP: frozenset[str] = frozenset({"releases"})


def _validate_skip(skip: list[str]) -> None:
    """Raise typer.Exit(1) if any --skip value is not recognised."""
    invalid = [s for s in skip if s not in _VALID_WS_SKIP]
    if invalid:
        console.print(
            f"[red]✗ Error:[/red] Unknown --skip value(s): {', '.join(invalid)}\n"
            f"  Valid values for [bold]plane ws[/bold]: "
            + ", ".join(sorted(_VALID_WS_SKIP))
        )
        raise typer.Exit(1)


app = typer.Typer(
    help="Workspace management commands.",
    no_args_is_help=True,
)


# Register state subcommand
def _register_state_subcommand():
    """Register workspace state management subcommand."""
    from planecompose.cli import ws_state_cmd

    app.add_typer(ws_state_cmd.app, name="state")


_register_state_subcommand()


# ---------------------------------------------------------------------------
# Workspace state management
# ---------------------------------------------------------------------------

def _init_workspace_state(ws_dir: Path, data: dict[str, Any]) -> None:
    """Initialize workspace state file from cloned data.

    Creates .plane/state.json tracking workspace-level entities synced:
    - Work item types with their IDs and properties
    - Workspace members with their IDs
    - Release tags, labels, and releases
    - Initiative and project labels
    - Enabled workspace features

    Called after ws clone to track what was fetched from the remote.
    Uses nested structure for easier hierarchical cleanup.
    """
    from planecompose.state.manager import StateManager
    from planecompose.core.models import WorkspaceSyncState
    from datetime import datetime, timezone
    import json

    try:
        manager = StateManager(ws_dir)

        # Build workspace state from cloned data
        state = WorkspaceSyncState()
        state.last_sync = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

        # Track work item types by name
        # wit_dict is keyed by ID (from API), so extract name from the type data
        wit_dict = data.get("wit_dict", {})
        for wit_id, wit_data in wit_dict.items():
            if isinstance(wit_data, dict):
                wit_name = wit_data.get("name")
                if wit_name:
                    state.workitemtypes["types"][wit_name] = str(wit_data.get("id", wit_id))

        # Track custom properties by name
        properties = data.get("properties", [])
        for prop in properties:
            if isinstance(prop, dict):
                prop_name = prop.get("display_name") or prop.get("name")
                if prop_name and prop.get("id"):
                    state.workitemtypes["properties"][prop_name] = str(prop["id"])

        # Track members by email
        members = data.get("members", [])
        for member in members:
            if isinstance(member, dict):
                member_email = member.get("email")
                if member_email and member.get("id"):
                    state.members[member_email] = str(member["id"])

        # Track project labels (may be None when fetch failed — skip gracefully)
        project_labels = data.get("project_labels") or []
        for label in project_labels:
            if isinstance(label, dict):
                label_name = label.get("name")
                if label_name and label.get("id"):
                    state.projects["labels"][label_name] = str(label["id"])

        # Track project states (may be None when fetch failed — skip gracefully)
        project_states = data.get("project_states") or []
        state.projects.setdefault("states", {})
        for ps in project_states:
            if isinstance(ps, dict):
                state_name = ps.get("name")
                if state_name and ps.get("id"):
                    state.projects["states"][state_name] = str(ps["id"])

        # Track initiative labels
        initiative_labels = data.get("initiative_labels", [])
        for label in initiative_labels:
            if isinstance(label, dict):
                label_name = label.get("name")
                if label_name and label.get("id"):
                    state.initiatives["labels"][label_name] = str(label["id"])

        # Track release tags (keyed by version, not name)
        release_tags = data.get("release_tags", [])
        for tag in release_tags:
            if isinstance(tag, dict):
                tag_version = tag.get("version")
                if tag_version and tag.get("id"):
                    state.releases["tags"][tag_version] = str(tag["id"])

        # Track release labels
        release_labels = data.get("release_labels", [])
        for label in release_labels:
            if isinstance(label, dict):
                label_name = label.get("name")
                if label_name and label.get("id"):
                    state.releases["labels"][label_name] = str(label["id"])

        # Track releases (work-level operational data → work.releases)
        releases = data.get("releases", [])
        for release in releases:
            if isinstance(release, dict):
                release_name = release.get("name")
                if release_name and release.get("id"):
                    state.work["releases"][release_name] = str(release["id"])

        # Track relation definitions (name → id)
        relation_definitions = data.get("relation_definitions", [])
        for rd in relation_definitions:
            if isinstance(rd, dict):
                rd_name = rd.get("name")
                if rd_name and rd.get("id"):
                    state.relations[rd_name] = str(rd["id"])

        # Track customer property definitions (name → {id, type})
        # Storing type allows push to detect and reject immutable type changes.
        customer_properties = data.get("customer_properties") or []
        for cp in customer_properties:
            if isinstance(cp, dict):
                cp_name = cp.get("name")
                if cp_name and cp.get("id"):
                    state.customers["properties"][cp_name] = {
                        "id": str(cp["id"]),
                        "type": cp.get("property_type", ""),
                    }

        # Track enabled workspace features
        features = data.get("features", {})
        if isinstance(features, dict):
            state.features = features

        # Save workspace state directly as JSON (not using SyncState)
        with manager.lock():
            state_file = manager.state_file
            state_file.parent.mkdir(parents=True, exist_ok=True)
            state_file.write_text(json.dumps(state.model_dump(), indent=2, default=str))

        logger.debug(
            f"Initialized workspace state: {len(state.workitemtypes['types'])} types, "
            f"{len(state.members)} members, {len(state.work['releases'])} releases"
        )
    except Exception as e:
        logger.warning(f"Could not initialize workspace state: {e}")
        # Don't fail the clone if state initialization fails


def _update_workspace_state_after_push(ws_dir: Path) -> None:
    """Update workspace state file after a successful push.

    Re-reads local YAML files to pick up IDs written back during push
    (e.g. a new release POSTed to the API gets its server-assigned id
    written back into work/releases.yaml — state must reflect that).
    """
    from planecompose.state.manager import StateManager
    from planecompose.core.models import WorkspaceSyncState
    from datetime import datetime, timezone
    import json

    try:
        manager = StateManager(ws_dir)
        state_file = ws_dir / ".plane" / "state.json"

        # Load existing state dict (or start fresh)
        if state_file.exists():
            try:
                state_data = json.loads(state_file.read_text())
            except json.JSONDecodeError:
                state_data = WorkspaceSyncState().model_dump()
        else:
            state_data = WorkspaceSyncState().model_dump()

        # Always refresh last_sync
        state_data["last_sync"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

        # Re-read work/releases.yaml — picks up IDs written back for new releases
        # Stored under work.releases (separate from schema config in releases.tags/labels)
        work_releases_path = ws_dir / "work" / "releases.yaml"
        if work_releases_path.exists():
            try:
                work_yaml = yaml.safe_load(work_releases_path.read_text()) or {}
                releases_dict: dict[str, str] = {}
                for r in (work_yaml.get("releases") or []):
                    if isinstance(r, dict) and r.get("name") and r.get("id"):
                        releases_dict[r["name"]] = str(r["id"])
                state_data.setdefault("work", {})["releases"] = releases_dict
            except Exception as exc:
                logger.warning(f"Could not re-read work/releases.yaml for state update: {exc}")

        # Re-read schema/releases.yaml — picks up IDs for new tags + labels
        schema_releases_path = ws_dir / "schema" / "releases.yaml"
        if schema_releases_path.exists():
            try:
                schema_yaml = yaml.safe_load(schema_releases_path.read_text()) or {}
                state_data.setdefault("releases", {})

                tags_dict: dict[str, str] = {}
                for t in (schema_yaml.get("release_tags") or []):
                    if isinstance(t, dict) and t.get("version") and t.get("id"):
                        tags_dict[t["version"]] = str(t["id"])
                state_data["releases"]["tags"] = tags_dict

                labels_dict: dict[str, str] = {}
                for lbl in (schema_yaml.get("labels") or []):
                    if isinstance(lbl, dict) and lbl.get("name") and lbl.get("id"):
                        labels_dict[lbl["name"]] = str(lbl["id"])
                state_data["releases"]["labels"] = labels_dict
            except Exception as exc:
                logger.warning(f"Could not re-read schema/releases.yaml for state update: {exc}")

        # Re-read schema/project.yaml — picks up IDs for new project labels and states
        schema_project_path = ws_dir / "schema" / "project.yaml"
        if schema_project_path.exists():
            try:
                project_yaml = yaml.safe_load(schema_project_path.read_text()) or {}
                state_data.setdefault("projects", {})

                labels_dict2: dict[str, str] = {}
                for lbl in (project_yaml.get("labels") or []):
                    if isinstance(lbl, dict) and lbl.get("name") and lbl.get("id"):
                        labels_dict2[lbl["name"]] = str(lbl["id"])
                state_data["projects"]["labels"] = labels_dict2

                states_dict: dict[str, str] = {}
                for st in (project_yaml.get("states") or []):
                    if isinstance(st, dict) and st.get("name") and st.get("id"):
                        states_dict[st["name"]] = str(st["id"])
                state_data["projects"]["states"] = states_dict
            except Exception as exc:
                logger.warning(f"Could not re-read schema/project.yaml for state update: {exc}")

        # Re-read schema/relations.yaml — picks up IDs for newly created custom relations
        schema_relations_path = ws_dir / "schema" / "relations.yaml"
        if schema_relations_path.exists():
            try:
                relations_yaml = yaml.safe_load(schema_relations_path.read_text()) or {}
                relations_dict: dict[str, str] = {}
                for rd in (relations_yaml.get("relations") or []):
                    if isinstance(rd, dict) and rd.get("name") and rd.get("id"):
                        relations_dict[rd["name"]] = str(rd["id"])
                state_data["relations"] = relations_dict
            except Exception as exc:
                logger.warning(f"Could not re-read schema/relations.yaml for state update: {exc}")

        # Re-read schema/initiatives.yaml — picks up IDs for new initiative labels
        schema_initiatives_path = ws_dir / "schema" / "initiatives.yaml"
        if schema_initiatives_path.exists():
            try:
                init_yaml = yaml.safe_load(schema_initiatives_path.read_text()) or {}
                init_dict: dict[str, str] = {}
                for lbl in (init_yaml.get("labels") or []):
                    if isinstance(lbl, dict) and lbl.get("name") and lbl.get("id"):
                        init_dict[lbl["name"]] = str(lbl["id"])
                state_data.setdefault("initiatives", {})["labels"] = init_dict
            except Exception as exc:
                logger.warning(f"Could not re-read schema/initiatives.yaml for state update: {exc}")

        # Re-read schema/customers.yaml — picks up IDs and types for customer properties
        schema_customers_path = ws_dir / "schema" / "customers.yaml"
        if schema_customers_path.exists():
            try:
                customers_yaml = yaml.safe_load(schema_customers_path.read_text()) or {}
                customers_props_dict: dict[str, dict] = {}
                for cp in (customers_yaml.get("properties") or []):
                    if isinstance(cp, dict) and cp.get("name") and cp.get("id"):
                        customers_props_dict[cp["name"]] = {
                            "id": str(cp["id"]),
                            "type": cp.get("type", ""),  # YAML uses "type", not "property_type"
                        }
                state_data.setdefault("customers", {})["properties"] = customers_props_dict
            except Exception as exc:
                logger.warning(f"Could not re-read schema/customers.yaml for state update: {exc}")

        with manager.lock():
            state_file.parent.mkdir(parents=True, exist_ok=True)
            state_file.write_text(json.dumps(state_data, indent=2, default=str))

        logger.debug("Updated workspace state after push")
    except Exception as e:
        logger.warning(f"Could not update workspace state after push: {e}")
        # Don't fail the push if state update fails


def _update_workspace_state_after_pull(ws_dir: Path, data: dict[str, Any] | None = None) -> None:
    """Update workspace state file after a successful pull.

    When fresh remote data is available (always the case during pull), fully
    re-initializes state so releases, tags, labels, members etc. are current.
    Falls back to timestamp-only update if no data is provided.
    """
    from planecompose.state.manager import StateManager
    from planecompose.core.models import WorkspaceSyncState
    from datetime import datetime, timezone
    import json

    try:
        if data:
            # Full re-init from fresh remote data — this is the normal pull path.
            # _init_workspace_state handles its own locking and file creation.
            _init_workspace_state(ws_dir, data)
        else:
            # No remote data (shouldn't happen in practice) — just bump last_sync.
            manager = StateManager(ws_dir)
            state_file = ws_dir / ".plane" / "state.json"
            with manager.lock():
                if state_file.exists():
                    try:
                        state_data = json.loads(state_file.read_text())
                    except json.JSONDecodeError:
                        state_data = WorkspaceSyncState().model_dump()
                else:
                    state_data = WorkspaceSyncState().model_dump()
                state_data["last_sync"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
                state_file.parent.mkdir(parents=True, exist_ok=True)
                state_file.write_text(json.dumps(state_data, indent=2, default=str))

        logger.debug("Updated workspace state after pull")
    except Exception as e:
        logger.warning(f"Could not update workspace state after pull: {e}")
        # Don't fail the pull if state update fails


# ---------------------------------------------------------------------------
# plane ws clone
# ---------------------------------------------------------------------------

@app.command()
def clone(
    workspace: str | None = typer.Argument(
        None, help="Workspace slug (interactive picker if omitted)"
    ),
    path: Path | None = typer.Option(
        None, "--path", help="Parent directory to clone into (default: current directory)"
    ),
    connection: str = typer.Option(
        ..., "--connection", "-c", help="Connection ID (required; disambiguates if slug exists in multiple connections)"
    ),
    skip: list[str] = typer.Option(
        [], "--skip", help="Skip a work section (valid: releases). Repeatable.",
    ),
):
    """
    Clone a workspace configuration locally.

    Creates a folder named after the workspace slug containing:

    \b
      plane.yaml                 workspace context (type: workspace)
      schema/
        features.yaml            workspace feature flags
        members.yaml             members with roles
        workitemtypes.yaml       work item types, properties, hierarchy
        project.yaml             project labels (states stub — no v1 route yet)
        initiatives.yaml         initiative labels
        releases.yaml            release tags and labels (config only)
        relations.yaml           relation type definitions
        webhooks.yaml            webhook configurations (stub — no v1 route yet)
      work/
        releases.yaml            actual releases (empty template if --skip releases)

    \b
    Use --skip to omit remote data for a work section (file is still created):
        plane ws clone compose-cli --skip releases   # work/releases.yaml written as empty template

    \b
    Examples:
        plane ws clone                               # interactive workspace picker
        plane ws clone compose-cli                   # clone specific workspace
        plane ws clone compose-cli --path ./ws       # clone into ./ws/compose-cli/
        plane ws clone compose-cli --skip releases   # schema config only
    """
    from planecompose.cli.workspace_utils import resolve_workspace

    _validate_skip(skip)
    ws_slug, conn_id, server_url, token = resolve_workspace(
        workspace, connection, command_hint="plane ws clone"
    )

    try:
        asyncio.run(_clone(ws_slug, conn_id, server_url, token, path, skip=skip))
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled.[/yellow]")
        raise typer.Exit(130)


async def _fetch_ws_data(client: Any, ws_slug: str, progress: Any, task: Any) -> dict[str, Any]:
    """Fetch all workspace schema data from remote.

    Shared by both ``_clone`` and ``_pull`` — returns a dict with every
    section so callers can decide what to write and where.
    """
    from planecompose.backend.workspace_sync import (
        fetch_workspace_features,
        fetch_workspace_work_item_types,
        fetch_customer_properties,
    )

    progress.update(task, description="Fetching workspace features...")
    features = fetch_workspace_features(client, ws_slug)

    progress.update(task, description="Fetching workspace members...")
    members = _fetch_members_with_roles(client, ws_slug)

    progress.update(task, description="Fetching workspace work item types...")
    wit_dict: dict[str, Any] = {}
    if features.get("work_item_types", False):
        wit_dict = fetch_workspace_work_item_types(client, ws_slug)

    progress.update(task, description="Fetching workspace work item properties...")
    properties = _fetch_work_item_properties(client, ws_slug)

    progress.update(task, description="Fetching type→property mappings...")
    type_property_map = _fetch_type_property_map(client, ws_slug, wit_dict)

    progress.update(task, description="Fetching initiative labels...")
    initiative_labels = _fetch_initiative_labels(client, ws_slug)

    progress.update(task, description="Fetching project labels...")
    project_labels = _fetch_project_labels(client, ws_slug)

    progress.update(task, description="Fetching project states...")
    project_states = _fetch_project_states(client, ws_slug)

    progress.update(task, description="Fetching relation definitions...")
    relation_definitions = _fetch_relation_definitions(client, ws_slug)

    # Fetch release_tags first — needed to resolve tag IDs → version strings in releases
    progress.update(task, description="Fetching releases...")
    release_tags = _fetch_release_tags(client, ws_slug)
    release_labels = _fetch_release_labels(client, ws_slug)
    releases = _fetch_releases(client, ws_slug, release_tags=release_tags)

    # Fetch customer properties — only when the customers feature is enabled.
    # Returns None on fetch failure; empty list when feature is enabled but no properties exist.
    progress.update(task, description="Fetching customer properties...")
    customer_properties: list[dict] | None = None
    if features.get("customers", False):
        customer_properties = fetch_customer_properties(client, ws_slug)

    return {
        "features": features,
        "members": members,
        "wit_dict": wit_dict,
        "properties": properties,
        "type_property_map": type_property_map,
        "initiative_labels": initiative_labels,
        "project_labels": project_labels,
        "project_states": project_states,
        "relation_definitions": relation_definitions,
        "releases": releases,
        "release_tags": release_tags,
        "release_labels": release_labels,
        "customer_properties": customer_properties,
    }


async def _clone(
    ws_slug: str,
    conn_id: str,
    server_url: str,
    api_key: str,
    parent_path: Path | None = None,
    skip: list[str] | None = None,
) -> None:
    """Async implementation of ws clone."""
    from planecompose.backend.plane import PlaneBackend

    start_time = time.time()
    parent = parent_path.resolve() if parent_path else Path.cwd()
    target_dir = parent / ws_slug

    console.print(f"\n[bold cyan]Cloning workspace '{ws_slug}'...[/bold cyan]\n")

    if target_dir.exists():
        console.print(f"[red]✗ Error:[/red] Directory '{target_dir}' already exists.")
        console.print(
            "  Remove it first or choose a different parent with [cyan]--path[/cyan]."
        )
        raise typer.Exit(1)

    backend = PlaneBackend.create_client(server_url, api_key, connection_id=conn_id)
    created = False

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Connecting to Plane...", total=None)

            _skip = set(skip or [])

            # Create directory + plane.yaml
            progress.update(task, description="Creating workspace directory...")
            target_dir.mkdir(parents=True, exist_ok=True)
            schema_dir = target_dir / "schema"
            schema_dir.mkdir(exist_ok=True)
            created = True
            _write_plane_yaml(target_dir, ws_slug, conn_id)

            # Fetch all data
            client = backend._require_client
            data = await _fetch_ws_data(client, ws_slug, progress, task)

            # Write schema files (configuration — Settings-level data)
            progress.update(task, description="Writing schema files...")
            _write_features_yaml(schema_dir / "features.yaml", data["features"])
            _write_members_yaml(schema_dir / "members.yaml", data["members"])
            _write_workitemtypes_yaml(
                schema_dir / "workitemtypes.yaml",
                data["wit_dict"],
                data["properties"],
                data["type_property_map"],
            )
            _write_initiatives_yaml(schema_dir / "initiatives.yaml", data["initiative_labels"])
            _write_releases_config_yaml(
                schema_dir / "releases.yaml",
                data["release_tags"],
                data["release_labels"],
            )
            _write_project_yaml(
                schema_dir / "project.yaml",
                data["project_labels"] or [],
                data["project_states"] or [],
            )
            _write_relations_yaml(schema_dir / "relations.yaml", data["relation_definitions"])
            if data["features"].get("customers", False):
                _write_customers_yaml(
                    schema_dir / "customers.yaml",
                    data.get("customer_properties"),
                )
            _write_webhooks_yaml(schema_dir / "webhooks.yaml")

            # Write work files (operational data — UI-level data)
            # work/ folder is always created; --skip releases omits remote data but
            # still writes an empty template so the file exists for future `plane ws pull`.
            work_dir = target_dir / "work"
            work_dir.mkdir(exist_ok=True)
            progress.update(task, description="Writing work files...")
            releases_data = [] if "releases" in _skip else data["releases"]
            _write_work_releases_yaml(work_dir / "releases.yaml", releases_data)

            # Initialize workspace state tracking
            progress.update(task, description="Initializing state tracking...")
            _init_workspace_state(target_dir, data)

            progress.update(task, description="Done!")

        elapsed = time.time() - start_time
        _print_summary(
            ws_slug,
            target_dir,
            data["features"],
            data["members"],
            data["wit_dict"],
            data["properties"],
            data["initiative_labels"],
            data["releases"],
            data["release_tags"],
            data["release_labels"],
            data["project_labels"],
            data["project_states"],
            data["relation_definitions"],
            elapsed,
        )

    except typer.Exit:
        raise
    except Exception as e:
        if created and target_dir.exists():
            shutil.rmtree(target_dir, ignore_errors=True)
            console.print(f"[dim]Cleaned up partial clone at {target_dir}[/dim]")
        console.print(f"\n[red]✗ Error:[/red] {e}")
        logger.exception("ws clone failed")
        raise typer.Exit(1)
    finally:
        await backend.disconnect()


# ---------------------------------------------------------------------------
# plane ws pull
# ---------------------------------------------------------------------------

@app.command()
def pull(
    workspace: str | None = typer.Argument(
        None, help="Workspace folder name or path (default: current directory)",
    ),
    force: bool = typer.Option(
        False, "--force", "-f",
        help="Overwrite local changes without confirmation (remote wins entirely)",
    ),
    merge: bool = typer.Option(
        False, "--merge", "-m",
        help="Preserve local-only additions while applying remote changes",
    ),
    skip: list[str] = typer.Option(
        [], "--skip", help="Skip a work section (valid: releases). Repeatable.",
    ),
):
    """
    Pull latest workspace configuration from Plane.

    Refreshes schema/ and work/ files in an existing workspace directory.

    \b
    Default (no flags):
      Shows which files differ and prompts before overwriting local changes.

    \b
    --merge: preserve local additions, apply remote changes
      Remote wins for existing entries. Local-only items (e.g. release tags
      you added locally) are kept. No confirmation prompt.

    \b
    --force: remote always wins, no prompt
      Discards all local changes. Use for CI or clean reset.

    \b
    --skip: omit a work section from this pull
      plane ws pull --skip releases   # refresh schema/ only, leave work/releases.yaml alone

    \b
    Examples:
        cd compose-cli && plane ws pull
        plane ws pull compose-cli --merge
        plane ws pull compose-cli --force
        plane ws pull compose-cli --skip releases
    """
    from planecompose.cli.workspace_utils import resolve_connection_by_id

    if force and merge:
        console.print("[red]✗ Error:[/red] --force and --merge are mutually exclusive.")
        raise typer.Exit(1)

    _validate_skip(skip)
    ws_dir = _resolve_ws_dir(workspace)
    ws_slug, conn_id = _read_plane_yaml(ws_dir)
    server_url, token = resolve_connection_by_id(conn_id)

    try:
        asyncio.run(_pull(ws_dir, ws_slug, conn_id, server_url, token, force=force, merge=merge, skip=skip))
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled.[/yellow]")
        raise typer.Exit(130)


def _resolve_ws_dir(workspace: str | None) -> Path:
    """Resolve the workspace directory from an optional name/path argument.

    Resolution order:
    1. No argument → current directory
    2. Argument is an existing path → use as-is
    3. Argument is a name → look for it as a sub-folder of the current directory
    """
    if not workspace:
        return Path.cwd()
    candidate = Path(workspace)
    if candidate.is_absolute():
        return candidate.resolve()
    # Try as sub-folder of cwd first (most common: `plane ws pull compose-cli`
    # run from the parent directory that contains the cloned workspace folder)
    sub = Path.cwd() / workspace
    if sub.exists():
        return sub.resolve()
    # Fall back to treating it as a relative/absolute path
    return candidate.resolve()


def _read_plane_yaml(ws_dir: Path) -> tuple[str, str]:
    """Read plane.yaml from a workspace directory and return (ws_slug, conn_id).

    Validates the file exists and has type: workspace.
    """
    plane_yaml = ws_dir / "plane.yaml"
    if not plane_yaml.exists():
        console.print(f"[red]✗ Error:[/red] No [bold]plane.yaml[/bold] found in '{ws_dir}'.")
        console.print(
            "  Run [cyan]plane ws clone <workspace>[/cyan] first to create the workspace directory."
        )
        raise typer.Exit(1)

    with open(plane_yaml) as f:
        ctx = yaml.safe_load(f) or {}

    if ctx.get("type") != "workspace":
        console.print(
            f"[red]✗ Error:[/red] '{plane_yaml}' has type [bold]{ctx.get('type')!r}[/bold], "
            "expected [bold]'workspace'[/bold]."
        )
        console.print("  Make sure you're inside a workspace directory, not a project directory.")
        raise typer.Exit(1)

    ws_slug = ctx.get("workspace")
    conn_id = ctx.get("connection")
    if not ws_slug or not conn_id:
        console.print(
            "[red]✗ Error:[/red] plane.yaml is missing [bold]workspace[/bold] or "
            "[bold]connection[/bold] field."
        )
        raise typer.Exit(1)

    return ws_slug, conn_id


async def _pull(
    ws_dir: Path,
    ws_slug: str,
    conn_id: str,
    server_url: str,
    api_key: str,
    force: bool = False,
    merge: bool = False,
    skip: list[str] | None = None,
) -> None:
    """Async implementation of ws pull."""
    from planecompose.backend.plane import PlaneBackend

    start_time = time.time()
    schema_dir = ws_dir / "schema"

    console.print(f"\n[bold cyan]Pulling workspace '{ws_slug}'...[/bold cyan]\n")

    if not schema_dir.exists():
        console.print(
            f"[red]✗ Error:[/red] No [bold]schema/[/bold] directory found in '{ws_dir}'."
        )
        console.print(
            "  This directory looks incomplete — try [cyan]plane ws clone[/cyan] again."
        )
        raise typer.Exit(1)

    backend = PlaneBackend.create_client(server_url, api_key, connection_id=conn_id)

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Connecting to Plane...", total=None)
            client = backend._require_client
            data = await _fetch_ws_data(client, ws_slug, progress, task)
            progress.update(task, description="Comparing local files...")

        # ── Compute which files would change ──────────────────────────────────
        # Schema sections: (filename, section_name) — all live in schema_dir
        SCHEMA_SECTIONS: list[tuple[str, str]] = [
            ("features.yaml",      "features"),
            ("members.yaml",       "members"),
            ("workitemtypes.yaml", "workitemtypes"),
            ("initiatives.yaml",   "initiatives"),
            ("project.yaml",       "project"),
            ("releases.yaml",      "releases_schema"),  # config only: tags + labels
            ("relations.yaml",     "relations"),
        ]
        # customers.yaml — only when workspace has customers feature enabled
        if data["features"].get("customers", False):
            SCHEMA_SECTIONS.append(("customers.yaml", "customers"))
        # Work sections: (filename, section_name) — all live in work_dir
        # Filtered by --skip: "releases" → skip work/releases.yaml
        _skip = set(skip or [])
        work_dir = ws_dir / "work"
        WORK_SECTIONS: list[tuple[str, str]] = [
            ("releases.yaml", "releases_work"),  # operational: actual releases
        ]
        WORK_SECTIONS = [(f, s) for f, s in WORK_SECTIONS if f.replace(".yaml", "") not in _skip]

        # changed: plan_key → (local_text, remote_text, base_dir)
        #   plan_key for schema files: filename (e.g. "releases.yaml")
        #   plan_key for work files:   "work/<filename>" (e.g. "work/releases.yaml")
        changed: dict[str, tuple[str, str, Path]] = {}
        unchanged: list[str] = []

        for filename, section in SCHEMA_SECTIONS:
            # When a section's data fetch failed (e.g. HTTP 429 rate-limit),
            # treat the file as unchanged so we don't wipe local content.
            if section == "project" and data.get("project_labels") is None:
                unchanged.append(filename)
                continue
            if section == "customers" and data.get("customer_properties") is None:
                unchanged.append(filename)
                continue
            local_path = schema_dir / filename
            local_text = _normalize_yaml(local_path.read_text() if local_path.exists() else "")
            remote_text = _render_remote_section(section, data)
            if local_text != remote_text:
                changed[filename] = (local_text, remote_text, schema_dir)
            else:
                unchanged.append(filename)

        for filename, section in WORK_SECTIONS:
            local_path = work_dir / filename
            local_text = _normalize_yaml(local_path.read_text() if local_path.exists() else "")
            remote_text = _render_remote_section(section, data)
            plan_key = f"work/{filename}"
            if local_text != remote_text:
                changed[plan_key] = (local_text, remote_text, work_dir)
            else:
                unchanged.append(plan_key)

        if not changed:
            elapsed = time.time() - start_time
            # Update workspace state even when no changes
            _update_workspace_state_after_pull(ws_dir, data)
            _print_pull_summary(ws_slug, ws_dir, [], list(unchanged), elapsed)
            return

        # ── Confirm before overwriting ─────────────────────────────────────────
        if not force and not merge:
            console.print(
                f"\n[yellow]  {len(changed)} file(s) differ from remote:[/yellow]  "
                + ", ".join(f"[cyan]{k}[/cyan]" for k in changed)
            )
            console.print()
            console.print("  [dim]Options:[/dim]")
            pad = max(
                len(f"plane ws diff {ws_slug}"),
                len(f"plane ws pull {ws_slug} --merge"),
                len(f"plane ws pull {ws_slug} --force"),
            )
            console.print(
                f"    [cyan]{'plane ws diff ' + ws_slug:<{pad}}[/cyan]"
                "  — review changes before applying"
            )
            console.print(
                f"    [cyan]{'plane ws pull ' + ws_slug + ' --merge':<{pad}}[/cyan]"
                "  — preserve local additions, apply remote changes"
            )
            console.print(
                f"    [cyan]{'plane ws pull ' + ws_slug + ' --force':<{pad}}[/cyan]"
                "  — overwrite local changes without prompt"
            )
            console.print()
            if not typer.confirm("  Apply remote changes?", default=False):
                console.print("[yellow]  Aborted — no files changed.[/yellow]")
                raise typer.Exit(0)
            console.print()

        # ── Build a unified section map for merge mode ─────────────────────────
        # Maps plan_key → (section_name, base_dir, filename)
        _ALL_SECTIONS: dict[str, tuple[str, Path, str]] = {}
        for fname, sec in SCHEMA_SECTIONS:
            _ALL_SECTIONS[fname] = (sec, schema_dir, fname)
        for fname, sec in WORK_SECTIONS:
            _ALL_SECTIONS[f"work/{fname}"] = (sec, work_dir, fname)

        # ── Apply ──────────────────────────────────────────────────────────────
        if merge:
            # Merge mode: preserve local-only additions, apply remote changes.
            # No confirmation needed — merge is non-destructive by design.
            merged_files: list[str] = []
            for plan_key, (sec, base_dir, fname) in _ALL_SECTIONS.items():
                # If the underlying fetch failed (e.g. 429 rate-limit), skip
                # this section entirely so local content is preserved.
                if sec == "project" and data.get("project_labels") is None:
                    unchanged.append(plan_key)
                    continue
                if sec == "customers" and data.get("customer_properties") is None:
                    unchanged.append(plan_key)
                    continue
                local_path = base_dir / fname
                local_text = _normalize_yaml(local_path.read_text() if local_path.exists() else "")
                remote_text = _render_remote_section(sec, data)

                if local_text == remote_text:
                    unchanged.append(plan_key)
                    continue

                local_yaml = yaml.safe_load(local_text) or {}
                remote_yaml = yaml.safe_load(remote_text) or {}
                merged = _merge_ws_section(sec, local_yaml, remote_yaml)

                if merged is None:
                    # Section where remote always wins (features, workitemtypes)
                    final_text = remote_text
                else:
                    final_text = yaml.dump(
                        merged,
                        Dumper=_IndentedDumper,
                        default_flow_style=False,
                        sort_keys=False,
                        allow_unicode=True,
                    )

                if final_text != local_text:
                    base_dir.mkdir(exist_ok=True)
                    local_path.write_text(final_text)
                    merged_files.append(plan_key)
                else:
                    unchanged.append(plan_key)

            elapsed = time.time() - start_time
            # Update workspace state after successful merge pull
            _update_workspace_state_after_pull(ws_dir, data)
            _print_pull_summary(ws_slug, ws_dir, merged_files, unchanged, elapsed, mode="merge")
        else:
            for plan_key, (_local, remote_text, base_dir) in changed.items():
                # Extract the actual filename from the plan key
                fname = plan_key[5:] if plan_key.startswith("work/") else plan_key
                base_dir.mkdir(exist_ok=True)
                (base_dir / fname).write_text(remote_text)

            elapsed = time.time() - start_time
            # Update workspace state after successful pull
            _update_workspace_state_after_pull(ws_dir, data)
            _print_pull_summary(ws_slug, ws_dir, list(changed.keys()), unchanged, elapsed)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"\n[red]✗ Error:[/red] {e}")
        logger.exception("ws pull failed")
        raise typer.Exit(1)
    finally:
        await backend.disconnect()


def _merge_by_key(local_items: list, remote_items: list, key: str) -> list:
    """Merge two lists: remote wins for existing keys, local-only items appended.

    Items in local whose key value appears in remote are dropped (remote
    version is used).  Items in local with a key not in remote — or with no
    key field at all — are treated as local additions and appended after the
    remote list.
    """
    remote_keys = {item[key] for item in remote_items if item.get(key)}
    local_only = [
        item for item in local_items
        if not item.get(key) or item[key] not in remote_keys
    ]
    return list(remote_items) + local_only


def _merge_ws_section(
    section: str,
    local_data: dict,
    remote_data: dict,
) -> dict | None:
    """Compute a merged dict for a workspace schema section.

    Returns the merged dict to write, or ``None`` if remote always wins
    (caller should use the raw remote text unchanged).

    Merge strategy per section:
    - features, workitemtypes  → remote always wins (None)
    - members                  → union by id
    - initiatives              → labels union by name
    - releases                 → releases union by id,
                                 release_tags union by version,
                                 labels union by name
    """
    if section in ("features", "workitemtypes"):
        return None

    if section == "members":
        return {
            "members": _merge_by_key(
                local_data.get("members", []),
                remote_data.get("members", []),
                key="id",
            )
        }

    if section == "initiatives":
        return {
            "labels": _merge_by_key(
                local_data.get("labels", []),
                remote_data.get("labels", []),
                key="name",
            )
        }

    if section == "releases_schema":
        # schema/releases.yaml: config only — release_tags + release labels
        return {
            "release_tags": _merge_by_key(
                local_data.get("release_tags", []),
                remote_data.get("release_tags", []),
                key="version",
            ),
            "labels": _merge_by_key(
                local_data.get("labels", []),
                remote_data.get("labels", []),
                key="name",
            ),
        }

    if section == "releases_work":
        # work/releases.yaml: operational data — actual releases
        return {
            "releases": _merge_by_key(
                local_data.get("releases", []),
                remote_data.get("releases", []),
                key="id",
            ),
        }

    if section == "project":
        # Labels: merge by name — local-only labels (no remote counterpart) are
        # preserved as local additions.  Remote version wins for labels that
        # exist on both sides (remote has the authoritative id).
        # States: server-managed; remote always wins.
        return {
            "labels": _merge_by_key(
                local_data.get("labels", []),
                remote_data.get("labels", []),
                key="name",
            ),
            "states": remote_data.get("states", []),
        }

    if section == "relations":
        return {
            "relations": _merge_by_key(
                local_data.get("relations", []),
                remote_data.get("relations", []),
                key="id",
            ),
        }

    if section == "customers":
        return {
            "properties": _merge_by_key(
                local_data.get("properties", []),
                remote_data.get("properties", []),
                key="id",
            ),
        }

    return None  # unknown section — remote wins


# ── Semantic diff ──────────────────────────────────────────────────────────────

# section → [(yaml_key, merge_key, display_fields)]
# display_fields: ordered list of item keys to show in the one-line label.
_DIFF_LISTS: dict[str, list[tuple[str, str, list[str]]]] = {
    "members": [
        ("members", "id", ["email", "display_name", "role"]),
    ],
    "initiatives": [
        # id-based merge so renames show as ~ modified rather than add/remove pair
        ("labels", "id", ["name", "color", "sort_order"]),
    ],
    # schema/releases.yaml — config only: release_tags + release labels
    "releases_schema": [
        ("release_tags", "version", ["version"]),
        # id-based merge so renames show as ~ modified rather than add/remove pair
        ("labels", "id", ["name", "color", "sort_order"]),
    ],
    # work/releases.yaml — operational data: actual releases
    "releases_work": [
        ("releases", "id", ["name", "status"]),
    ],
    "project": [
        # id-based merge so renames show as ~ modified rather than add/remove pair
        ("labels", "id", ["name", "color", "sort_order"]),
        ("states", "id", ["name", "color", "group"]),
    ],
    "relations": [
        ("relations", "id", ["name", "outward", "inward", "is_default"]),
    ],
    "customers": [
        # id-based merge so renames show as ~ modified rather than add/remove pair
        ("properties", "id", ["name", "display_name", "type", "required", "active", "options"]),
    ],
}


def _format_diff_item(item: dict, display_fields: list[str]) -> str:
    """One-line label for a single YAML item in the semantic diff."""
    parts = [str(item[f]) for f in display_fields if item.get(f) is not None]
    return "  ".join(parts) if parts else repr(item)


def _compute_semantic_diff(
    section: str,
    local_yaml: dict,
    remote_yaml: dict,
) -> list[dict]:
    """
    Compute semantic diff blocks for a single workspace schema section.

    Returns a list of blocks:
      {"type": "features", "changes": [{key, local, remote}]}
      {"type": "map",  "yaml_key": ..., "remote_only": [names], "local_only": [names], "changed": [names]}
      {"type": "list", "yaml_key": ..., "display_fields": [...], "remote_only": [...], "local_only": [...]}

    Returns [] when there are no differences.
    """
    if section == "features":
        all_keys = sorted(set(local_yaml) | set(remote_yaml))
        changes = [
            {"key": k, "local": local_yaml.get(k), "remote": remote_yaml.get(k)}
            for k in all_keys
            if local_yaml.get(k) != remote_yaml.get(k)
        ]
        return [{"type": "features", "changes": changes}] if changes else []

    if section == "members":
        # Members cannot be pushed — warn if local changes detected
        if local_yaml != remote_yaml:
            return [{"type": "members_unsupported", "has_changes": True}]
        return []

    if section == "workitemtypes":
        wit_local = local_yaml.get("work_item_types", {}) or {}
        wit_remote = remote_yaml.get("work_item_types", {}) or {}
        local_names = set(wit_local)
        remote_names = set(wit_remote)
        remote_only = sorted(remote_names - local_names)
        local_only = sorted(local_names - remote_names)
        changed = sorted(
            n for n in local_names & remote_names if wit_local[n] != wit_remote[n]
        )

        blocks: list[dict[str, Any]] = []
        if remote_only or local_only or changed:
            blocks.append({"type": "map", "yaml_key": "work_item_types",
                           "remote_only": remote_only, "local_only": local_only,
                           "changed": changed})

        # Also detect property option changes
        # Pass full YAML (not just work_item_types) since _compute_property_push_plan
        # looks for "properties" key at top level
        prop_changes = _compute_property_push_plan(local_yaml, remote_yaml)
        if prop_changes:
            blocks.append({"type": "property_options", "changes": prop_changes})

        # Detect hierarchy changes (not supported for push)
        hierarchy_local = local_yaml.get("hierarchy") or []
        hierarchy_remote = remote_yaml.get("hierarchy") or []
        if hierarchy_local != hierarchy_remote:
            blocks.append({"type": "hierarchy_changes", "has_changes": True})

        return blocks

    # Standard list sections
    list_configs = _DIFF_LISTS.get(section, [])
    if not list_configs:
        return []

    blocks = []
    for yaml_key, merge_key, display_fields in list_configs:
        items_local = local_yaml.get(yaml_key) or []
        items_remote = remote_yaml.get(yaml_key) or []
        local_keys = {item.get(merge_key) for item in items_local if item.get(merge_key)}
        remote_keys = {item.get(merge_key) for item in items_remote if item.get(merge_key)}
        remote_only = [item for item in items_remote if item.get(merge_key) not in local_keys]
        local_only = [item for item in items_local if item.get(merge_key) not in remote_keys]

        # Detect changed items — same key in both but fields differ
        changed_items: list[dict] = []
        remote_by_key = {r.get(merge_key): r for r in items_remote if r.get(merge_key)}
        if yaml_key == "releases":
            for item in items_local:
                key_val = item.get(merge_key)
                if not key_val or key_val not in remote_by_key:
                    continue
                remote_item = remote_by_key[key_val]
                # Compare mutable fields
                diff_fields: dict[str, tuple] = {}
                for field in ("name", "status", "is_latest", "is_prerelease",
                              "target_date", "release_date", "tag"):
                    lv, rv = item.get(field), remote_item.get(field)
                    if lv != rv:
                        diff_fields[field] = (rv, lv)
                # Compare linked labels (list of names)
                lv_labels = sorted(item.get("labels") or [])
                rv_labels = sorted(remote_item.get("labels") or [])
                if lv_labels != rv_labels:
                    diff_fields["labels"] = (rv_labels, lv_labels)
                if diff_fields:
                    changed_items.append({
                        "item": item,
                        "remote_item": remote_item,
                        "diff_fields": diff_fields,
                    })
        else:
            # Generic: compare all display_fields for items matched by merge_key
            for item in items_local:
                key_val = item.get(merge_key)
                if not key_val or key_val not in remote_by_key:
                    continue
                remote_item = remote_by_key[key_val]
                diff_fields = {}
                for field in display_fields:
                    lv, rv = item.get(field), remote_item.get(field)
                    if lv != rv:
                        diff_fields[field] = (rv, lv)
                if diff_fields:
                    changed_items.append({
                        "item": item,
                        "remote_item": remote_item,
                        "diff_fields": diff_fields,
                    })

        if remote_only or local_only or changed_items:
            blocks.append({
                "type": "list",
                "yaml_key": yaml_key,
                "display_fields": display_fields,
                "remote_only": remote_only,
                "local_only": local_only,
                "changed": changed_items,
            })

    return blocks


def _compute_wit_push_plan(
    wit_local_yaml: dict,
    wit_remote_yaml: dict,
    data: dict,
) -> dict[str, dict]:
    """Compute what needs to be pushed to remote for workitemtypes.yaml.

    Compares local vs remote work_item_types dicts (keyed by type name) and
    returns per-type change entries for types that differ.

    Returns::

        {
          type_name: {
            "type_id":  str,                   # UUID from local (or remote) entry
            "meta":     {field: (remote, local)},  # metadata fields that changed
            "link":     [prop_name, ...],      # properties to add to this type
            "unlink":   [prop_name, ...],      # properties to remove from this type
          },
          ...
        }
    """
    local_types: dict[str, dict] = wit_local_yaml.get("work_item_types") or {}
    remote_types: dict[str, dict] = wit_remote_yaml.get("work_item_types") or {}

    # Build prop_name_by_id for resolving property IDs in type_property_map
    # (not needed here — remote YAML already has resolved names)
    # But keep for reference: data["properties"] = [{id, name, ...}, ...]

    result: dict[str, dict] = {}

    for type_name, local_entry in local_types.items():
        remote_entry = remote_types.get(type_name)

        # ── New type — create remotely ────────────────────────────────────────
        if remote_entry is None:
            local_props: list[str] = list(local_entry.get("properties") or [])
            result[type_name] = {
                "type_id": None,          # unknown until created
                "is_new": True,
                "local_entry": local_entry,
                "meta": {},
                "link": local_props,      # all properties need linking after create
                "unlink": [],
            }
            continue

        type_id = local_entry.get("id") or remote_entry.get("id")
        if not type_id:
            continue

        # ── Metadata diff ────────────────────────────────────────────────────
        meta: dict[str, tuple] = {}
        for field in ("description", "is_active", "level"):
            lv = local_entry.get(field)
            rv = remote_entry.get(field)
            if lv != rv:
                meta[field] = (rv, lv)

        # Icon is a nested dict — compare field-by-field
        local_icon = local_entry.get("icon") or {}
        remote_icon = remote_entry.get("icon") or {}
        for icon_field in ("name", "color"):
            lv = local_icon.get(icon_field)
            rv = remote_icon.get(icon_field)
            if lv != rv:
                meta[f"icon.{icon_field}"] = (rv, lv)

        # ── Property diff ────────────────────────────────────────────────────
        local_props = list(local_entry.get("properties") or [])
        remote_props: list[str] = list(remote_entry.get("properties") or [])
        local_prop_set = set(local_props)
        remote_prop_set = set(remote_props)

        link = [p for p in local_props if p not in remote_prop_set]
        unlink = [p for p in remote_props if p not in local_prop_set]

        if meta or link or unlink:
            result[type_name] = {
                "type_id": type_id,
                "is_new": False,
                "meta": meta,
                "link": link,
                "unlink": unlink,
            }

    return result


def _compute_property_push_plan(
    wit_local_yaml: dict,
    wit_remote_yaml: dict,
) -> dict[str, dict]:
    """Compute what property and option changes need to be pushed.

    Detects:
      - New properties (local property has no ``id``)
      - New options within OPTION-type properties (local option has no ``id``)
      - Changed options (same ``id``, different ``name`` or ``color``)

    Returns::

        {
          prop_name: {
            "is_new": bool,                    # True if property needs to be created
            "property": dict,                  # Full property dict for new properties
            "property_id": str,                # ID of existing property (for option changes)
            "new_options":     [{"name": ..., "color": ...}],
            "changed_options": [{"id": ..., "diff": {field: (remote, local)}}],
          },
          ...
        }
    """
    local_props_list: list[dict] = wit_local_yaml.get("properties") or []
    remote_props_list: list[dict] = wit_remote_yaml.get("properties") or []

    remote_by_id: dict[str, dict] = {p["id"]: p for p in remote_props_list if p.get("id")}
    remote_names: set[str] = {p["name"] for p in remote_props_list if p.get("name")}

    result: dict[str, dict] = {}

    for local_prop in local_props_list:
        prop_id = local_prop.get("id")
        prop_name = local_prop.get("name")

        if not prop_name:
            continue  # Skip properties without names

        # New property (no id)
        if not prop_id:
            if prop_name not in remote_names:
                result[prop_name] = {
                    "is_new": True,
                    "property": local_prop,
                }
            continue

        # Existing property (has id) — check for option changes
        remote_prop = remote_by_id.get(prop_id)
        if not remote_prop:
            continue

        # Only OPTION-type properties have options to diff
        if local_prop.get("property_type") != "OPTION":
            continue

        prop_name = local_prop.get("name") or remote_prop.get("name") or prop_id
        local_options: list[dict] = local_prop.get("options") or []
        remote_options: list[dict] = remote_prop.get("options") or []
        remote_opts_by_id: dict[str, dict] = {o["id"]: o for o in remote_options if o.get("id")}

        new_options: list[dict] = []
        changed_options: list[dict] = []

        for opt in local_options:
            opt_id = opt.get("id")
            if not opt_id:
                # No id → needs to be created
                new_options.append(opt)
            elif opt_id in remote_opts_by_id:
                remote_opt = remote_opts_by_id[opt_id]
                diff: dict[str, tuple] = {}
                for field in ("name", "color"):
                    lv, rv = opt.get(field), remote_opt.get(field)
                    if lv != rv:
                        diff[field] = (rv, lv)
                if diff:
                    changed_options.append({"id": opt_id, "name": opt.get("name", opt_id), "diff": diff})

        if new_options or changed_options:
            result[prop_name] = {
                "is_new": False,
                "property_id": prop_id,
                "new_options": new_options,
                "changed_options": changed_options,
            }

    return result


def _print_semantic_diff(filename: str, blocks: list[dict]) -> None:
    """Print semantic diff for a single schema file."""
    console.print(f"\n[bold]{'─' * 60}[/bold]")
    console.print(f"[bold yellow]  {filename}[/bold yellow]")
    console.print(f"[bold]{'─' * 60}[/bold]")

    for block in blocks:
        btype = block["type"]

        if btype == "features":
            for ch in block["changes"]:
                key, lv, rv = ch["key"], ch["local"], ch["remote"]
                if rv is None:
                    console.print(f"  [dim]→ local adds:[/dim]  {key}")
                elif lv is None:
                    console.print(f"  [dim]← remote adds:[/dim]  {key}")
                else:
                    console.print(f"  [yellow]~[/yellow] {key}: [dim]{rv}[/dim] → [bold]{lv}[/bold]")

        elif btype == "map":
            if block.get("remote_only"):
                console.print("\n  [dim]← remote adds[/dim]  [dim](plane ws pull --merge to apply)[/dim]")
                for name in block["remote_only"]:
                    console.print(f"      [green]+[/green] {name}")
            if block.get("local_only"):
                console.print("\n  [dim]→ local adds[/dim]   [dim](plane ws push to apply)[/dim]")
                for name in block["local_only"]:
                    console.print(f"      [green]+[/green] {name}")
            if block.get("changed"):
                console.print("\n  [dim]~ changed[/dim]")
                for name in block["changed"]:
                    console.print(f"      [yellow]~[/yellow] {name}")

        elif btype == "property_options":
            for prop_name, pc in block["changes"].items():
                # New property (needs to be created)
                if pc.get("is_new"):
                    prop_obj = pc.get("property", {})
                    console.print(f"\n  [green]+[/green] [dim]properties:[/dim]  {prop_name} [dim](new {prop_obj.get('property_type', '?')} property)[/dim]")
                    if prop_obj.get("description"):
                        console.print(f"      [dim]description:[/dim] {prop_obj['description']}")
                    # Show options if it's an OPTION type property
                    for opt in prop_obj.get("options", []):
                        console.print(f"      [green]+[/green] option: {opt.get('name', '?')}")
                # Existing property with option changes
                else:
                    console.print(f"\n  [dim]properties → {prop_name}:[/dim]")
                    for opt in pc.get("new_options", []):
                        console.print(f"      [green]+[/green] option: {opt.get('name', '?')}")
                    for ch in pc.get("changed_options", []):
                        console.print(f"      [yellow]~[/yellow] option: {ch['name']}")
                        for field, (old_val, new_val) in ch["diff"].items():
                            console.print(f"        [dim]{field}:[/dim] {old_val} → [bold]{new_val}[/bold]")

        elif btype == "hierarchy_changes":
            console.print("\n  [red]✗ Hierarchy changes detected[/red]")
            console.print("    [yellow]⚠  These changes [bold]cannot be pushed[/bold] — they will be [bold]reset to remote[/bold][/yellow]")

        elif btype == "members_unsupported":
            console.print("\n  [red]✗ Member changes detected[/red]")
            console.print("    [yellow]⚠  These changes [bold]cannot be pushed[/bold] — they will be [bold]reset to remote[/bold][/yellow]")

        elif btype == "list":
            yaml_key = block["yaml_key"]
            display_fields = block["display_fields"]
            if block["remote_only"]:
                console.print(
                    "\n  [dim]← remote adds[/dim]  "
                    "[dim](plane ws pull --merge to apply)[/dim]"
                )
                console.print(f"    [dim]{yaml_key}:[/dim]")
                for item in block["remote_only"]:
                    console.print(
                        f"      [green]+[/green] {_format_diff_item(item, display_fields)}"
                    )
            if block["local_only"]:
                console.print(
                    "\n  [dim]→ local adds[/dim]   "
                    "[dim](plane ws push to apply)[/dim]"
                )
                console.print(f"    [dim]{yaml_key}:[/dim]")
                for item in block["local_only"]:
                    console.print(
                        f"      [green]+[/green] {_format_diff_item(item, display_fields)}"
                    )
            for ch in block.get("changed", []):
                item = ch["item"]
                name = item.get("name") or item.get("version") or "?"
                console.print(
                    "\n  [dim]~ modified[/dim]     "
                    "[dim](plane ws push to apply)[/dim]"
                )
                console.print(f"    [dim]{yaml_key}:[/dim]  [yellow]~[/yellow] {name}")
                for field, (old_val, new_val) in ch["diff_fields"].items():
                    console.print(
                        f"      [dim]{field}:[/dim]  [dim]{old_val}[/dim]"
                        f" → [bold]{new_val}[/bold]"
                    )


def _print_pull_summary(
    ws_slug: str,
    ws_dir: Path,
    updated: list[str],
    unchanged: list[str],
    elapsed: float,
    mode: str = "overwrite",
) -> None:
    verb = "Merged" if mode == "merge" else "Updated"
    # Files that exist on disk as stubs but are not synced (no API key route yet)
    skipped = ["webhooks.yaml"]

    lines = ["[bold green]✓ Pull complete![/bold green]\n"]
    lines.append(f"  [dim]Location:[/dim]  {ws_dir}\n")

    if updated:
        lines.append(
            f"  [bold green]{verb}[/bold green]   ({len(updated)}): "
            + ", ".join(f"[cyan]{f}[/cyan]" for f in updated)
        )
    if unchanged:
        lines.append(
            f"  [dim]Unchanged  ({len(unchanged)}):[/dim] "
            + ", ".join(unchanged)
        )
    lines.append(
        f"  [dim]Skipped    ({len(skipped)}):[/dim] "
        + ", ".join(skipped)
        + "  [dim](no API key route yet)[/dim]"
    )

    console.print(
        Panel(
            "\n".join(lines),
            title=f"[bold]plane ws pull[/bold]  [dim]{elapsed:.1f}s[/dim]",
            border_style="green" if updated else "dim",
            padding=(1, 2),
        )
    )


# ---------------------------------------------------------------------------
# plane ws push
# ---------------------------------------------------------------------------

@app.command()
def push(
    workspace: str | None = typer.Argument(
        None, help="Workspace folder name or path (default: current directory)",
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", "-n",
        help="Preview what would be pushed without making any changes",
    ),
    force: bool = typer.Option(
        False, "--force", "-f",
        help="Push without confirmation prompt",
    ),
    prune: bool = typer.Option(
        False, "--prune",
        help="Also delete remote entries that are absent from local YAML (project states, project labels, relation definitions)",
    ),
    skip: list[str] = typer.Option(
        [], "--skip", help="Skip a work section (valid: releases). Repeatable.",
    ),
):
    """
    Push local workspace schema additions to Plane.

    By default pushes local additions and updates only — never deletes.
    Use --prune to also remove remote entries absent from local YAML.

    \b
    Sections pushed:
      schema/releases.yaml  — new release tags, release labels
      work/releases.yaml    — new releases (skipped if --skip releases)
      initiatives           — new initiative labels
      project.yaml          — new/updated project states and labels
      relations.yaml        — new/updated relation definitions

    \b
    Sections skipped (managed elsewhere):
      features, members    — admin/billing settings, use Plane UI
      workitemtypes        — use plane schema push

    \b
    After push, local YAML files are updated with the IDs assigned by the server.

    \b
    Examples:
        cd compose-cli && plane ws push
        plane ws push compose-cli --dry-run
        plane ws push compose-cli --force
        plane ws push compose-cli --prune        # also deletes remote-only entries
        plane ws push compose-cli --skip releases
    """
    from planecompose.cli.workspace_utils import resolve_connection_by_id

    _validate_skip(skip)
    ws_dir = _resolve_ws_dir(workspace)
    ws_slug, conn_id = _read_plane_yaml(ws_dir)
    server_url, token = resolve_connection_by_id(conn_id)

    try:
        asyncio.run(_push(ws_dir, ws_slug, conn_id, server_url, token,
                          dry_run=dry_run, force=force, prune=prune, skip=skip))
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled.[/yellow]")
        raise typer.Exit(130)


async def _push(
    ws_dir: Path,
    ws_slug: str,
    conn_id: str,
    server_url: str,
    api_key: str,
    dry_run: bool = False,
    force: bool = False,
    prune: bool = False,
    skip: list[str] | None = None,
) -> None:
    """Async implementation of ws push."""
    from planecompose.backend.plane import PlaneBackend

    start_time = time.time()
    schema_dir = ws_dir / "schema"

    console.print(f"\n[bold cyan]Pushing workspace '{ws_slug}'...[/bold cyan]\n")

    if not schema_dir.exists():
        console.print(
            f"[red]✗ Error:[/red] No [bold]schema/[/bold] directory found in '{ws_dir}'."
        )
        raise typer.Exit(1)

    backend = PlaneBackend.create_client(server_url, api_key, connection_id=conn_id)

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Fetching remote state...", total=None)
            client = backend._require_client
            data = await _fetch_ws_data(client, ws_slug, progress, task)
            progress.update(task, description="Computing diff...")

        # ── Compute what needs to be pushed ───────────────────────────────────
        # push_plan: filename → {"local_only": {yaml_key: [items]},
        #                        "changed":    {yaml_key: [{item, diff_fields}]},
        #                        "features":   {key: new_val}}
        push_plan: dict[str, dict] = {}

        # Features — full dict comparison, push any locally-changed flag
        feat_local = yaml.safe_load(
            _normalize_yaml((schema_dir / "features.yaml").read_text()
                            if (schema_dir / "features.yaml").exists() else "")
        ) or {}
        feat_remote = yaml.safe_load(_render_remote_section("features", data)) or {}
        feat_changes = {
            k: v
            for k, v in (feat_local.get("features") or {}).items()
            if v != (feat_remote.get("features") or {}).get(k)
        }
        if feat_changes:
            push_plan["features.yaml"] = {"features": feat_changes}

        # Work item types — metadata patches + property link/unlink + property options
        wit_path = schema_dir / "workitemtypes.yaml"
        hierarchy_unsupported = False
        if wit_path.exists():
            wit_local_text = _normalize_yaml(wit_path.read_text())
            wit_remote_text = _render_remote_section("workitemtypes", data)
            if wit_local_text != wit_remote_text:
                wit_local_yaml = yaml.safe_load(wit_local_text) or {}
                wit_remote_yaml = yaml.safe_load(wit_remote_text) or {}
                wit_changes = _compute_wit_push_plan(
                    wit_local_yaml, wit_remote_yaml, data
                )
                prop_changes = _compute_property_push_plan(wit_local_yaml, wit_remote_yaml)

                # Detect hierarchy changes (not supported for push)
                hierarchy_local = wit_local_yaml.get("hierarchy") or []
                hierarchy_remote = wit_remote_yaml.get("hierarchy") or []
                if hierarchy_local != hierarchy_remote:
                    hierarchy_unsupported = True

                if wit_changes or prop_changes:
                    push_plan["workitemtypes.yaml"] = {
                        "wit_changes": wit_changes,
                        "prop_changes": prop_changes,
                        "hierarchy_unsupported": hierarchy_unsupported,
                    }

        # Members — cannot be pushed (API role restrictions)
        members_unsupported = False
        members_path = schema_dir / "members.yaml"
        members_local_text = _normalize_yaml(members_path.read_text() if members_path.exists() else "")
        members_remote_text = _render_remote_section("members", data)
        if members_local_text != members_remote_text:
            members_unsupported = True

        # List sections (initiatives, project, schema releases config)
        # plan_key → (section_name, local_path) for list-type sections
        _skip = set(skip or [])
        work_dir = ws_dir / "work"
        _LIST_SECTIONS: list[tuple[str, str, Path]] = [
            ("initiatives.yaml", "initiatives",     schema_dir / "initiatives.yaml"),
            ("project.yaml",     "project",         schema_dir / "project.yaml"),
            ("relations.yaml",   "relations",       schema_dir / "relations.yaml"),
            # schema/releases.yaml — config only (tags + labels); always included
            ("releases.yaml",    "releases_schema", schema_dir / "releases.yaml"),
        ]
        # customers.yaml — customer property definitions; only when feature is enabled
        if data["features"].get("customers", False) and data.get("customer_properties") is not None:
            _LIST_SECTIONS.append(
                ("customers.yaml", "customers", schema_dir / "customers.yaml")
            )
        # work/releases.yaml — operational (actual releases); omit if --skip releases
        if "releases" not in _skip:
            _LIST_SECTIONS.append(
                ("work/releases.yaml", "releases_work", work_dir / "releases.yaml")
            )
        # Sections where --prune can DELETE remote-only entries (endpoint confirmed available)
        _PRUNABLE: dict[tuple[str, str], str] = {
            # (section, yaml_key) → url_template using {ws_slug} and {id}
            ("project", "states"):      "workspaces/{ws_slug}/project-states/{id}/",
            ("project", "labels"):      "workspaces/{ws_slug}/project-labels/{id}/",
            ("relations", "relations"): "workspaces/{ws_slug}/work-item-relation-definitions/{id}/",
            ("customers", "properties"): "workspaces/{ws_slug}/customer-properties/{id}/",
        }

        for plan_key, section, local_path in _LIST_SECTIONS:
            local_text = _normalize_yaml(local_path.read_text() if local_path.exists() else "")
            remote_text = _render_remote_section(section, data)

            if local_text == remote_text:
                continue

            local_yaml_data = yaml.safe_load(local_text) or {}
            remote_yaml_data = yaml.safe_load(remote_text) or {}
            blocks = _compute_semantic_diff(section, local_yaml_data, remote_yaml_data)

            local_only: dict[str, list] = {}
            changed_items: dict[str, list] = {}
            remote_only_prunable: dict[str, list] = {}
            for block in blocks:
                if block["type"] == "list":
                    if block["local_only"]:
                        local_only[block["yaml_key"]] = block["local_only"]
                    if block.get("changed"):
                        changed_items[block["yaml_key"]] = block["changed"]
                    # Collect remote-only items for pruneable yaml_keys
                    if block.get("remote_only") and (section, block["yaml_key"]) in _PRUNABLE:
                        deletable = [i for i in block["remote_only"] if i.get("id")]
                        if deletable:
                            remote_only_prunable[block["yaml_key"]] = deletable

            if local_only or changed_items or remote_only_prunable:
                push_plan[plan_key] = {
                    "_section": section,
                    "_path": local_path,
                    "local_only": local_only,
                    "changed": changed_items,
                    "remote_only_prunable": remote_only_prunable,
                }

        # ── Nothing to push ───────────────────────────────────────────────────
        # A plan entry with only remote_only_prunable but no local_only/changed is
        # only actionable when --prune is set.
        has_pushable = any(
            fp.get("local_only") or fp.get("changed") or fp.get("features") or fp.get("wit_changes")
            for fp in push_plan.values()
        )
        has_prunable = any(fp.get("remote_only_prunable") for fp in push_plan.values())

        if not push_plan or (not has_pushable and not (prune and has_prunable)):
            # Check if there are only unsupported changes
            unsupported_only = (hierarchy_unsupported or members_unsupported)
            if unsupported_only:
                elapsed = time.time() - start_time
                msg_lines = ["[bold yellow]⚠ No pushable changes detected[/bold yellow]\n"]
                msg_lines.append("[yellow]Local changes in unsupported sections:[/yellow]")
                if hierarchy_unsupported:
                    msg_lines.append("[dim]  • Hierarchy — will be reset to remote version[/dim]")
                if members_unsupported:
                    msg_lines.append("[dim]  • Members — will be reset to remote version[/dim]")
                msg_lines.append("\n[dim]Use 'plane ws pull' to sync these from remote.[/dim]")
                console.print(
                    Panel(
                        "\n".join(msg_lines),
                        title=f"[bold]plane ws push[/bold]  [dim]{elapsed:.1f}s[/dim]",
                        border_style="yellow",
                        padding=(1, 2),
                    )
                )
            else:
                elapsed = time.time() - start_time
                console.print(
                    Panel(
                        "[bold green]✓ Nothing to push — remote is already up to date.[/bold green]",
                        title=f"[bold]plane ws push[/bold]  [dim]{elapsed:.1f}s[/dim]",
                        border_style="green",
                        padding=(1, 2),
                    )
                )
            return

        # ── Show push preview ─────────────────────────────────────────────────
        console.print("[yellow]  Changes to push:[/yellow]\n")

        # Show unsupported changes first
        if hierarchy_unsupported or members_unsupported:
            console.print("  [red]✗ Unsupported changes (will NOT be pushed):[/red]")
            if hierarchy_unsupported:
                console.print("    [yellow]⚠  Hierarchy[/yellow] — will be reset to remote version")
            if members_unsupported:
                console.print("    [yellow]⚠  Members[/yellow] — will be reset to remote version")
            console.print()

        for filename, file_plan in push_plan.items():
            console.print(f"  [bold]{filename}[/bold]")
            if filename == "features.yaml":
                for key, val in file_plan.get("features", {}).items():
                    console.print(f"    [yellow]~[/yellow] {key}: → [bold]{val}[/bold]")
                continue
            if filename == "workitemtypes.yaml":
                for type_name, tc in file_plan.get("wit_changes", {}).items():
                    if tc.get("is_new"):
                        console.print(f"    [green]+[/green] {type_name} [dim](new type)[/dim]")
                        local_e = tc.get("local_entry") or {}
                        for field in ("description", "is_active", "level"):
                            if field in local_e:
                                console.print(f"      [dim]{field}:[/dim] [bold]{local_e[field]}[/bold]")
                        for p in tc.get("link", []):
                            console.print(f"      [green]+[/green] link property: {p}")
                    else:
                        console.print(f"    [yellow]~[/yellow] {type_name}")
                        for field, (old_val, new_val) in tc.get("meta", {}).items():
                            console.print(f"      [dim]{field}:[/dim] {old_val} → [bold]{new_val}[/bold]")
                        for p in tc.get("link", []):
                            console.print(f"      [green]+[/green] link property: {p}")
                        for p in tc.get("unlink", []):
                            console.print(f"      [red]-[/red] unlink property: {p}")
                # Property option changes
                for prop_name, pc in file_plan.get("prop_changes", {}).items():
                    console.print(f"    [dim]properties → {prop_name}:[/dim]")
                    for opt in pc.get("new_options", []):
                        console.print(f"      [green]+[/green] option: {opt.get('name', '?')}")
                    for ch in pc.get("changed_options", []):
                        console.print(f"      [yellow]~[/yellow] option: {ch['name']}")
                        for field, (old_val, new_val) in ch["diff"].items():
                            console.print(f"        [dim]{field}:[/dim] {old_val} → [bold]{new_val}[/bold]")
                continue
            for yaml_key, items in file_plan.get("local_only", {}).items():
                console.print(f"    [dim]{yaml_key}:[/dim]")
                for item in items:
                    console.print(f"      [green]+[/green] {_format_push_item(yaml_key, item)}")
            for yaml_key, changes in file_plan.get("changed", {}).items():
                console.print(f"    [dim]{yaml_key}:[/dim]")
                for ch in changes:
                    name = ch["item"].get("name") or ch["item"].get("version") or "?"
                    console.print(f"      [yellow]~[/yellow] {name}")
                    for field, (old_val, new_val) in ch["diff_fields"].items():
                        console.print(f"        [dim]{field}:[/dim] {old_val} → [bold]{new_val}[/bold]")
            for yaml_key, items in file_plan.get("remote_only_prunable", {}).items():
                if items:
                    console.print(f"    [dim]{yaml_key}:[/dim]")
                    for item in items:
                        name = item.get("name") or item.get("id", "?")
                        if prune:
                            console.print(f"      [red]-[/red] {name} [dim](will delete)[/dim]")
                        else:
                            console.print(f"      [red]-[/red] {name} [dim](remote-only — use --prune to delete)[/dim]")
        console.print()

        if dry_run:
            console.print("[dim]  Dry run — no changes made.[/dim]")
            return

        # ── Confirm ───────────────────────────────────────────────────────────
        if not force:
            if not typer.confirm("  Push these changes to remote?", default=False):
                console.print("[yellow]  Aborted — no changes pushed.[/yellow]")
                raise typer.Exit(0)
            console.print()

        # ── Apply ─────────────────────────────────────────────────────────────
        base_url = client.sdk.config.base_path
        headers = {
            "X-Api-Key": api_key,
            "Content-Type": "application/json",
        }
        timeout = client.sdk.config.timeout
        session = client.sdk.workspaces.session

        pushed: dict[str, list[str]] = {}   # filename → [description lines]
        errors: list[str] = []

        for plan_key, file_plan in push_plan.items():
            # section and local_path are stored explicitly for list-section entries;
            # for special entries (features, workitemtypes) derive from plan_key.
            section = file_plan.get("_section") or plan_key.replace(".yaml", "")
            local_path = file_plan.get("_path") or schema_dir / plan_key
            filename = plan_key  # used for display and plan key comparisons
            file_pushed: list[str] = []

            # ── Work item types (CREATE / PATCH metadata + link/unlink properties) ──
            if filename == "workitemtypes.yaml":
                prop_name_to_id = {
                    p["name"]: p["id"]
                    for p in (data.get("properties") or [])
                    if p.get("name") and p.get("id")
                }
                # Track newly created type IDs so we can write them back to YAML
                new_type_ids: dict[str, tuple[Any, dict]] = {}

                for type_name, tc in file_plan.get("wit_changes", {}).items():
                    type_id = tc.get("type_id")

                    # ── CREATE new type via POST ───────────────────────────────
                    if tc.get("is_new"):
                        local_e = tc.get("local_entry") or {}
                        create_payload: dict = {"name": type_name}
                        if local_e.get("description"):
                            create_payload["description"] = local_e["description"]
                        if "is_active" in local_e:
                            create_payload["is_active"] = local_e["is_active"]
                        if "level" in local_e:
                            create_payload["level"] = local_e["level"]
                        icon = local_e.get("icon") or {}
                        if icon:
                            create_payload["logo_props"] = {
                                "icon": {
                                    "name": icon.get("name"),
                                    "background_color": icon.get("color"),
                                }
                            }
                        try:
                            url = f"{base_url}/workspaces/{ws_slug}/work-item-types/"
                            resp = session.post(url, headers=headers, json=create_payload, timeout=timeout)
                            if resp.status_code in (200, 201):
                                created = resp.json()
                                type_id = created.get("id")
                                logger.info(f"✓ Created WIT {type_name}: {type_id}")
                                file_pushed.append(f"+ {type_name} (created)")
                                if type_id:
                                    # Store full normalised entry so diff is clean after push
                                    level = created.get("level", 0)
                                    try:
                                        level = int(float(level)) if float(level) == int(float(level)) else float(level)
                                    except (TypeError, ValueError):
                                        level = 0
                                    normalised: dict = {"id": type_id}
                                    if created.get("description"):
                                        normalised["description"] = created["description"]
                                    if created.get("is_default"):
                                        normalised["is_default"] = True
                                    normalised["is_active"] = created.get("is_active", True)
                                    normalised["level"] = level
                                    logo_props = created.get("logo_props") or {}
                                    icon_data = (logo_props.get("icon") or {})
                                    if icon_data:
                                        normalised["icon"] = {
                                            "name": icon_data.get("name"),
                                            "color": icon_data.get("background_color"),
                                        }
                                    new_type_ids[type_name] = (type_id, normalised)
                            else:
                                errors.append(f"WIT '{type_name}' CREATE: HTTP {resp.status_code} — {resp.text[:120]}")
                                continue  # skip property linking if create failed
                        except Exception as e:
                            errors.append(f"WIT '{type_name}' CREATE: {e}")
                            continue

                    else:
                        # ── PATCH metadata fields ─────────────────────────────
                        meta = tc.get("meta", {})
                        if meta:
                            # icon.name / icon.color come back as "icon.name" keys —
                            # rebuild nested logo_props for the PATCH payload
                            patch_payload: dict = {}
                            icon_patch: dict = {}
                            for f, (_, new_val) in meta.items():
                                if f.startswith("icon."):
                                    icon_patch[f[5:]] = new_val  # "name" or "color"
                                else:
                                    patch_payload[f] = new_val
                            if icon_patch:
                                # YAML uses "color"; API expects "background_color"
                                icon_api: dict = {}
                                if "name" in icon_patch:
                                    icon_api["name"] = icon_patch["name"]
                                if "color" in icon_patch:
                                    icon_api["background_color"] = icon_patch["color"]
                                patch_payload["logo_props"] = {"icon": icon_api}
                            try:
                                url = f"{base_url}/workspaces/{ws_slug}/work-item-types/{type_id}/"
                                resp = session.patch(url, headers=headers, json=patch_payload, timeout=timeout)
                                if resp.status_code in (200, 201):
                                    logger.info(f"✓ Updated WIT {type_name}: {list(patch_payload)}")
                                    file_pushed.append(f"~ {type_name} (updated {', '.join(meta)})")
                                else:
                                    errors.append(f"WIT '{type_name}' PATCH: HTTP {resp.status_code} — {resp.text[:120]}")
                            except Exception as e:
                                errors.append(f"WIT '{type_name}' PATCH: {e}")

                    # ── Link new properties ────────────────────────────────────
                    for prop_name in tc.get("link", []):
                        prop_id = prop_name_to_id.get(prop_name)
                        if not prop_id:
                            errors.append(f"WIT '{type_name}': property '{prop_name}' not found in workspace properties")
                            continue
                        try:
                            url = f"{base_url}/workspaces/{ws_slug}/work-item-types/{type_id}/properties/"
                            resp = session.post(url, headers=headers, json={"properties": [prop_id]}, timeout=timeout)
                            if resp.status_code in (200, 201):
                                logger.info(f"✓ Linked property {prop_name} to {type_name}")
                                file_pushed.append(f"~ {type_name}: linked property '{prop_name}'")
                            else:
                                errors.append(f"WIT '{type_name}' link '{prop_name}': HTTP {resp.status_code} — {resp.text[:120]}")
                        except Exception as e:
                            errors.append(f"WIT '{type_name}' link '{prop_name}': {e}")

                    # ── Unlink removed properties ──────────────────────────────
                    for prop_name in tc.get("unlink", []):
                        prop_id = prop_name_to_id.get(prop_name)
                        if not prop_id:
                            errors.append(f"WIT '{type_name}': property '{prop_name}' not found — cannot unlink")
                            continue
                        try:
                            url = f"{base_url}/workspaces/{ws_slug}/work-item-types/{type_id}/properties/{prop_id}/"
                            resp = session.delete(url, headers=headers, timeout=timeout)
                            if resp.status_code in (200, 204):
                                logger.info(f"✓ Unlinked property {prop_name} from {type_name}")
                                file_pushed.append(f"~ {type_name}: unlinked property '{prop_name}'")
                            else:
                                errors.append(f"WIT '{type_name}' unlink '{prop_name}': HTTP {resp.status_code} — {resp.text[:120]}")
                        except Exception as e:
                            errors.append(f"WIT '{type_name}' unlink '{prop_name}': {e}")

                # ── Create new properties ─────────────────────────────────────
                new_property_ids: dict[str, tuple[str, dict]] = {}  # prop_name -> (prop_id, normalized)
                for prop_name, pc in file_plan.get("prop_changes", {}).items():
                    if not pc.get("is_new"):
                        continue

                    prop_obj = pc.get("property", {})
                    create_prop_payload: dict = {
                        "display_name": prop_name,  # API requires display_name
                        "property_type": prop_obj.get("property_type", "TEXT"),
                    }
                    if prop_obj.get("description"):
                        create_prop_payload["description"] = prop_obj["description"]
                    if "is_required" in prop_obj:
                        create_prop_payload["is_required"] = prop_obj["is_required"]
                    if "is_multi" in prop_obj:
                        create_prop_payload["is_multi"] = prop_obj["is_multi"]
                    if "is_active" in prop_obj:
                        create_prop_payload["is_active"] = prop_obj["is_active"]

                    try:
                        url = f"{base_url}/workspaces/{ws_slug}/work-item-properties/"
                        resp = session.post(url, headers=headers, json=create_prop_payload, timeout=timeout)
                        if resp.status_code in (200, 201):
                            created_prop = resp.json()
                            prop_id = created_prop.get("id")
                            logger.info(f"✓ Created property '{prop_name}': {prop_id}")
                            file_pushed.append(f"+ created property '{prop_name}' ({create_prop_payload.get('property_type')})")
                            # Store normalized entry for writeback
                            normalised = {"id": prop_id}
                            if created_prop.get("description"):
                                normalised["description"] = created_prop["description"]
                            normalised["property_type"] = created_prop.get("property_type", "TEXT")
                            normalised["is_required"] = created_prop.get("is_required", False)
                            normalised["is_multi"] = created_prop.get("is_multi", False)
                            normalised["is_active"] = created_prop.get("is_active", True)
                            if prop_id:
                                new_property_ids[prop_name] = (prop_id, normalised)
                                # Update mapping for property linking
                                prop_name_to_id[prop_name] = prop_id
                        else:
                            errors.append(f"Property '{prop_name}' CREATE: HTTP {resp.status_code} — {resp.text[:120]}")
                    except Exception as e:
                        errors.append(f"Property '{prop_name}' CREATE: {e}")

                # ── Property option CREATE / PATCH ─────────────────────────────
                # new_option_ids: {prop_name: [(opt_name, opt_id), ...]}
                new_option_ids: dict[str, list[tuple[str, str]]] = {}
                for prop_name, pc in file_plan.get("prop_changes", {}).items():
                    # Skip newly created properties (options are handled during property creation)
                    if pc.get("is_new"):
                        # Handle options for newly created properties
                        prop_id = new_property_ids.get(prop_name, (None, None))[0]
                        if not prop_id:
                            continue
                        prop_obj = pc.get("property", {})
                        prop_new_ids: list[tuple[str, str]] = []
                        for opt in prop_obj.get("options", []):
                            if opt.get("id"):
                                continue  # Skip options that already have IDs
                            opt_name = opt.get("name", "")
                            create_opt_payload: dict = {"name": opt_name}
                            if opt.get("color"):
                                create_opt_payload["color"] = opt["color"]
                            try:
                                url = f"{base_url}/workspaces/{ws_slug}/work-item-properties/{prop_id}/options/"
                                resp = session.post(url, headers=headers, json=create_opt_payload, timeout=timeout)
                                if resp.status_code in (200, 201):
                                    created_opt = resp.json()
                                    opt_id = created_opt.get("id")
                                    logger.info(f"✓ Created option '{opt_name}' on property '{prop_name}': {opt_id}")
                                    file_pushed.append(f"+ property '{prop_name}': option '{opt_name}' created")
                                    if opt_id:
                                        prop_new_ids.append((opt_name, opt_id))
                                else:
                                    errors.append(f"Property '{prop_name}' option '{opt_name}' CREATE: HTTP {resp.status_code} — {resp.text[:120]}")
                            except Exception as e:
                                errors.append(f"Property '{prop_name}' option '{opt_name}' CREATE: {e}")
                        if prop_new_ids:
                            new_option_ids[prop_name] = prop_new_ids
                        continue

                    property_id = pc.get("property_id")
                    prop_new_ids = []

                    for opt in pc.get("new_options", []):
                        opt_name = opt.get("name", "")
                        create_opt_payload = {"name": opt_name}
                        if opt.get("color"):
                            create_opt_payload["color"] = opt["color"]
                        try:
                            url = f"{base_url}/workspaces/{ws_slug}/work-item-properties/{property_id}/options/"
                            resp = session.post(url, headers=headers, json=create_opt_payload, timeout=timeout)
                            if resp.status_code in (200, 201):
                                created_opt = resp.json()
                                opt_id = created_opt.get("id")
                                logger.info(f"✓ Created option '{opt_name}' on property '{prop_name}': {opt_id}")
                                file_pushed.append(f"+ property '{prop_name}': option '{opt_name}' created")
                                if opt_id:
                                    prop_new_ids.append((opt_name, opt_id))
                            else:
                                errors.append(f"Property '{prop_name}' option '{opt_name}' CREATE: HTTP {resp.status_code} — {resp.text[:120]}")
                        except Exception as e:
                            errors.append(f"Property '{prop_name}' option '{opt_name}' CREATE: {e}")

                    for ch in pc.get("changed_options", []):
                        opt_id = ch["id"]
                        opt_name = ch["name"]
                        patch_opt = {f: new_val for f, (_, new_val) in ch["diff"].items()}
                        try:
                            url = f"{base_url}/workspaces/{ws_slug}/work-item-properties/{property_id}/options/{opt_id}/"
                            resp = session.patch(url, headers=headers, json=patch_opt, timeout=timeout)
                            if resp.status_code in (200, 201):
                                logger.info(f"✓ Updated option '{opt_name}' on property '{prop_name}'")
                                file_pushed.append(f"~ property '{prop_name}': option '{opt_name}' updated")
                            else:
                                errors.append(f"Property '{prop_name}' option '{opt_name}' PATCH: HTTP {resp.status_code} — {resp.text[:120]}")
                        except Exception as e:
                            errors.append(f"Property '{prop_name}' option '{opt_name}' PATCH: {e}")

                    if prop_new_ids:
                        new_option_ids[prop_name] = prop_new_ids

                # Write newly created property/type/option IDs back into the local YAML
                needs_writeback = bool(new_property_ids or new_type_ids or new_option_ids)
                if needs_writeback:
                    try:
                        wit_yaml_local = yaml.safe_load(local_path.read_text()) or {}

                        # Patch new property IDs + full normalised entry into properties list
                        if new_property_ids:
                            props_local: list[dict] = wit_yaml_local.get("properties") or []
                            if not props_local:
                                props_local = []
                                wit_yaml_local["properties"] = props_local
                            # Build lookup: prop_name → property entry
                            prop_entry_by_name = {p.get("name"): p for p in props_local if p.get("name")}
                            for pname, (pid, normalised) in new_property_ids.items():
                                prop_entry = prop_entry_by_name.get(pname)
                                if prop_entry is not None:
                                    # Update with full normalised entry to prevent diff noise
                                    prop_entry.update(normalised)
                                    console.print(f"  [dim]↳ wrote id for property '{pname}' → {pid}[/dim]")

                        # Patch new type IDs + full normalised entry into work_item_types
                        if new_type_ids:
                            wit_types_local = wit_yaml_local.get("work_item_types")
                            if wit_types_local is None:
                                wit_types_local = {}
                                wit_yaml_local["work_item_types"] = wit_types_local
                            for tname, (tid, normalised) in new_type_ids.items():
                                if tname in wit_types_local:
                                    # Update with full normalised entry to prevent diff noise
                                    wit_types_local[tname].update(normalised)
                                    console.print(f"  [dim]↳ wrote id for type '{tname}' → {tid}[/dim]")

                        # Patch new option IDs into properties list
                        if new_option_ids:
                            props_local = wit_yaml_local.get("properties") or []
                            # Build lookup: prop_name → property entry
                            prop_entry_by_name = {p.get("name"): p for p in props_local if p.get("name")}
                            for pname, opt_id_pairs in new_option_ids.items():
                                prop_entry = prop_entry_by_name.get(pname)
                                if prop_entry is None:
                                    continue
                                opts_local: list[dict] = prop_entry.get("options") or []
                                # Build lookup: option name → option entry (for ones without id)
                                opts_without_id = {o.get("name"): o for o in opts_local if not o.get("id") and o.get("name")}
                                for opt_name, opt_id in opt_id_pairs:
                                    opt_entry = opts_without_id.get(opt_name)
                                    if opt_entry is not None:
                                        opt_entry["id"] = opt_id
                                        console.print(f"  [dim]↳ wrote id for option '{opt_name}' → {opt_id}[/dim]")

                        _dump(local_path, wit_yaml_local)
                        console.print("  [dim]✓ Updated workitemtypes.yaml with new IDs[/dim]")
                    except Exception as e:
                        console.print(f"  [red]⚠ Could not write new IDs back to YAML: {e}[/red]")

                if file_pushed:
                    pushed[filename] = file_pushed
                continue

            # ── Features (PATCH via SDK) ───────────────────────────────────────
            if filename == "features.yaml":
                feat_changes = file_plan.get("features", {})
                try:
                    from plane.models.workspaces import WorkspaceFeature

                    # Build full feature model: remote values as base, local changes on top
                    remote_feats = data.get("features") or {}
                    merged = {**remote_feats, **feat_changes}
                    # WorkspaceFeature only knows these known fields — filter to what it accepts
                    known = set(WorkspaceFeature.model_fields.keys())
                    model_data = {k: v for k, v in merged.items() if k in known}
                    feature_model = WorkspaceFeature(**model_data)

                    client.sdk.workspaces.update_features(
                        workspace_slug=ws_slug,
                        data=feature_model,
                    )
                    for key, val in feat_changes.items():
                        file_pushed.append(f"features: {key} → {val}")
                        logger.info(f"✓ Updated feature {key} = {val}")
                except Exception as e:
                    errors.append(f"features: {e}")
                    logger.warning(f"Feature update failed: {e}")
                if file_pushed:
                    pushed[filename] = file_pushed
                continue

            # ── List sections (initiatives, releases) ──────────────────────────
            local_yaml = yaml.safe_load(local_path.read_text()) if local_path.exists() else {}

            # Resolve label name → id for releases (needed for tag/label linking)
            release_label_id_map = {
                lbl["name"]: lbl["id"]
                for lbl in (data.get("release_labels") or [])
                if lbl.get("name") and lbl.get("id")
            }
            release_tag_id_map = {
                t["version"]: t["id"]
                for t in (data.get("release_tags") or [])
                if t.get("version") and t.get("id")
            }

            # Create new (local-only) items
            for yaml_key, items in file_plan.get("local_only", {}).items():
                for item in items:
                    payload = _build_push_payload(section, yaml_key, item)
                    url = _push_endpoint(section, yaml_key, ws_slug, base_url)
                    try:
                        resp = session.post(url, headers=headers, json=payload, timeout=timeout)
                        if resp.status_code in (200, 201):
                            created = resp.json()
                            label = _format_push_item(yaml_key, item)
                            logger.info(f"✓ Created {yaml_key}: {label} (id={created.get('id')})")
                            if created.get("id"):
                                _patch_local_id(local_yaml, yaml_key, item, created["id"])
                                new_id = created["id"]
                                # For new releases: link tag and labels if specified
                                if yaml_key == "releases":
                                    _push_release_links(
                                        session, headers, timeout, ws_slug, base_url,
                                        new_id, item, release_tag_id_map, release_label_id_map,
                                        errors,
                                    )
                            file_pushed.append(f"+ {yaml_key}: {label}")
                        else:
                            msg = f"{yaml_key} '{_format_push_item(yaml_key, item)}': HTTP {resp.status_code} — {resp.text[:120]}"
                            errors.append(msg)
                            logger.warning(f"Push failed: {msg}")
                    except Exception as e:
                        msg = f"{yaml_key} '{_format_push_item(yaml_key, item)}': {e}"
                        errors.append(msg)
                        logger.warning(f"Push error: {msg}")

            # Update changed (existing) items
            for yaml_key, changes in file_plan.get("changed", {}).items():
                for ch in changes:
                    item = ch["item"]
                    diff_fields = ch["diff_fields"]
                    release_id = item.get("id")
                    name = item.get("name") or item.get("version") or "?"

                    if yaml_key == "releases" and release_id:
                        # Separate field updates vs label updates
                        field_patch = {
                            k: v
                            for k, v in {
                                "name": item.get("name"),
                                "status": item.get("status"),
                                "is_latest": item.get("is_latest"),
                                "is_prerelease": item.get("is_prerelease"),
                                "target_date": item.get("target_date"),
                                "release_date": item.get("release_date"),
                            }.items()
                            if k in diff_fields
                        }
                        # Resolve tag version → id for PATCH
                        if "tag" in diff_fields:
                            tag_version = item.get("tag")
                            field_patch["tag"] = (
                                release_tag_id_map.get(tag_version) if tag_version else None
                            )

                        try:
                            if field_patch:
                                url = f"{base_url}/workspaces/{ws_slug}/releases/{release_id}/"
                                resp = session.patch(url, headers=headers, json=field_patch, timeout=timeout)
                                if resp.status_code in (200, 201):
                                    logger.info(f"✓ Updated release {name}: {list(field_patch)}")
                                    file_pushed.append(f"~ releases: {name} (updated {', '.join(field_patch)})")
                                else:
                                    errors.append(f"releases PATCH '{name}': HTTP {resp.status_code} — {resp.text[:120]}")

                            # Update labels if changed
                            if "labels" in diff_fields:
                                _push_release_label_update(
                                    session, headers, timeout, ws_slug, base_url,
                                    release_id, name,
                                    old_labels=diff_fields["labels"][0],   # remote labels
                                    new_labels=item.get("labels") or [],   # local labels
                                    label_id_map=release_label_id_map,
                                    file_pushed=file_pushed,
                                    errors=errors,
                                )
                        except Exception as e:
                            errors.append(f"releases update '{name}': {e}")
                            logger.warning(f"Release update error: {e}")

                    elif yaml_key == "states" and section == "project":
                        # PATCH project state (name/color/group changes)
                        # Endpoint: PATCH /workspaces/{slug}/project-states/{id}/
                        state_id = item.get("id")
                        if not state_id:
                            errors.append(f"project states: '{name}' has no id — cannot PATCH")
                            continue
                        patch_payload = {f: item[f] for f in diff_fields if f in ("name", "color", "group", "description")}
                        if patch_payload:
                            try:
                                url = f"{base_url}/workspaces/{ws_slug}/project-states/{state_id}/"
                                resp = session.patch(url, headers=headers, json=patch_payload, timeout=timeout)
                                if resp.status_code in (200, 201):
                                    logger.info(f"✓ Updated project state {name}: {list(patch_payload)}")
                                    file_pushed.append(
                                        f"~ states: {name} (updated {', '.join(patch_payload)})"
                                    )
                                else:
                                    errors.append(
                                        f"project states PATCH '{name}': "
                                        f"HTTP {resp.status_code} — {resp.text[:120]}"
                                    )
                            except Exception as e:
                                errors.append(f"project states update '{name}': {e}")

                    elif yaml_key == "relations" and section == "relations":
                        # PATCH relation definition (name/outward/inward/is_active/color changes)
                        rel_id = item.get("id")
                        if not rel_id:
                            errors.append(f"relations: '{name}' has no id — cannot PATCH")
                            continue
                        patchable = ("name", "outward", "inward", "is_active", "color", "sort_order")
                        patch_payload = {f: item[f] for f in diff_fields if f in patchable and f in item}
                        if patch_payload:
                            try:
                                url = f"{base_url}/workspaces/{ws_slug}/work-item-relation-definitions/{rel_id}/"
                                resp = session.patch(url, headers=headers, json=patch_payload, timeout=timeout)
                                if resp.status_code in (200, 201):
                                    logger.info(f"✓ Updated relation '{name}': {list(patch_payload)}")
                                    file_pushed.append(
                                        f"~ relations: {name} (updated {', '.join(patch_payload)})"
                                    )
                                else:
                                    errors.append(
                                        f"relations PATCH '{name}': "
                                        f"HTTP {resp.status_code} — {resp.text[:120]}"
                                    )
                            except Exception as e:
                                errors.append(f"relations update '{name}': {e}")

                    elif yaml_key == "labels" and section == "project":
                        # PATCH project label (name/color/sort_order changes)
                        label_id = item.get("id")
                        if not label_id:
                            errors.append(f"project labels: '{name}' has no id — cannot PATCH")
                            continue
                        patch_payload = {f: item[f] for f in diff_fields if f in ("name", "color", "sort_order")}
                        if patch_payload:
                            try:
                                url = f"{base_url}/workspaces/{ws_slug}/project-labels/{label_id}/"
                                resp = session.patch(url, headers=headers, json=patch_payload, timeout=timeout)
                                if resp.status_code in (200, 201):
                                    logger.info(f"✓ Updated project label {name}: {list(patch_payload)}")
                                    file_pushed.append(
                                        f"~ labels: {name} (updated {', '.join(patch_payload)})"
                                    )
                                else:
                                    errors.append(
                                        f"project labels PATCH '{name}': "
                                        f"HTTP {resp.status_code} — {resp.text[:120]}"
                                    )
                            except Exception as e:
                                errors.append(f"project labels update '{name}': {e}")

                    elif yaml_key == "labels" and section in (
                        "initiatives", "releases_schema",
                    ):
                        # PATCH for initiative/release labels returns 403 via API key (session-auth only).
                        # Log as warning — user must rename in Plane UI.
                        logger.warning(
                            f"Cannot PATCH {section} label '{name}' via API key — "
                            "rename in Plane UI instead (403 limitation, see plane-compose-issues.md)"
                        )
                        errors.append(
                            f"{section} label '{name}': rename not supported via API key "
                            "(use Plane UI to rename)"
                        )

                    elif yaml_key == "properties" and section == "customers":
                        # PATCH customer property (display_name / required / active / settings / options).
                        # 'name' (slug) and 'type' are immutable after creation — warn and skip.
                        prop_id = item.get("id")
                        if not prop_id:
                            errors.append(f"customers properties: '{name}' has no id — cannot PATCH")
                            continue
                        patch_payload = {}
                        options_ops: list[dict] = []  # tracks new/delete/rename ops for logging
                        for f in diff_fields:
                            if f == "name":
                                _, new_name_val = diff_fields["name"]
                                logger.warning(
                                    f"customers property '{name}': 'name' (slug) is immutable after "
                                    f"creation — local change to '{new_name_val}' ignored. "
                                    "Restore the original name in customers.yaml."
                                )
                                errors.append(
                                    f"customers property '{name}': name is immutable — "
                                    f"revert the name change in customers.yaml"
                                )
                                continue
                            elif f == "type":
                                _, new_type_val = diff_fields["type"]
                                logger.warning(
                                    f"customers property '{name}': 'type' cannot be changed after "
                                    f"creation — local change to '{new_type_val}' ignored. "
                                    "Delete and recreate the property to change its type."
                                )
                                errors.append(
                                    f"customers property '{name}': type is immutable — "
                                    f"delete and recreate to change type (was: {item.get('type', '?')})"
                                )
                                continue
                            elif f == "display_name" and "display_name" in item:
                                patch_payload["display_name"] = item["display_name"]
                            elif f == "required":
                                patch_payload["is_required"] = item.get("required", False)
                            elif f == "active":
                                patch_payload["is_active"] = bool(item.get("active", True))
                            elif f == "settings" and "settings" in item:
                                patch_payload["settings"] = item["settings"]
                            elif f == "options":
                                # diff_fields["options"] = (remote_options, local_options)
                                remote_opts, local_opts = diff_fields["options"]
                                remote_opts = remote_opts or []
                                local_opts = local_opts or []
                                # Build id-keyed lookups
                                remote_by_id = {
                                    o["id"]: o for o in remote_opts
                                    if isinstance(o, dict) and o.get("id")
                                }
                                local_by_id = {
                                    o["id"]: o for o in local_opts
                                    if isinstance(o, dict) and o.get("id")
                                }
                                # New: local entry without id
                                new_opts = [
                                    o for o in local_opts
                                    if isinstance(o, dict) and not o.get("id")
                                ]
                                # Deleted: in remote but not in local (by id)
                                deleted_ids = set(remote_by_id) - set(local_by_id)
                                # Renamed: id in both, name changed
                                renamed_opts = [
                                    {"id": oid, "name": local_by_id[oid]["name"]}
                                    for oid in set(remote_by_id) & set(local_by_id)
                                    if remote_by_id[oid].get("name") != local_by_id[oid].get("name")
                                ]
                                options_ops = (
                                    [{"name": o["name"]} for o in new_opts]
                                    + [{"id": oid, "is_active": False} for oid in deleted_ids]
                                    + renamed_opts
                                )
                                if options_ops:
                                    patch_payload["options"] = options_ops
                        if patch_payload:
                            try:
                                url = f"{base_url}/workspaces/{ws_slug}/customer-properties/{prop_id}/"
                                resp = session.patch(url, headers=headers, json=patch_payload, timeout=timeout)
                                if resp.status_code in (200, 201):
                                    # Build human-readable summary of what changed
                                    changed_fields: list[str] = [
                                        k for k in patch_payload if k != "options"
                                    ]
                                    if "options" in patch_payload:
                                        n_new = sum(1 for o in options_ops if not o.get("id"))
                                        n_del = sum(1 for o in options_ops if o.get("is_active") is False)
                                        n_ren = sum(
                                            1 for o in options_ops
                                            if o.get("id") and o.get("is_active") is not False
                                        )
                                        if n_new:
                                            changed_fields.append(f"+{n_new} option(s)")
                                        if n_del:
                                            changed_fields.append(f"-{n_del} option(s)")
                                        if n_ren:
                                            changed_fields.append(f"~{n_ren} option(s) renamed")
                                    logger.info(
                                        f"✓ Updated customer property '{name}': {changed_fields}"
                                    )
                                    file_pushed.append(
                                        f"~ properties: {name} (updated {', '.join(changed_fields)})"
                                    )
                                    # If new options were created, fetch detail to get assigned IDs
                                    # and write them back into local_yaml so we don't push again.
                                    has_new_opts = any(not o.get("id") for o in options_ops)
                                    if has_new_opts:
                                        try:
                                            detail_resp = session.get(
                                                url, headers=headers, timeout=timeout
                                            )
                                            if detail_resp.status_code == 200:
                                                server_opts = detail_resp.json().get("options", [])
                                                for prop_entry in local_yaml.get("properties", []):
                                                    if (
                                                        isinstance(prop_entry, dict)
                                                        and prop_entry.get("id") == prop_id
                                                    ):
                                                        prop_entry["options"] = [
                                                            {"id": so["id"], "name": so["name"]}
                                                            for so in server_opts
                                                            if so.get("id") and so.get("name")
                                                            and so.get("is_active", True)
                                                        ]
                                                        break
                                        except Exception as detail_err:
                                            logger.warning(
                                                f"Could not fetch updated options for '{name}': {detail_err}"
                                            )
                                else:
                                    errors.append(
                                        f"customer properties PATCH '{name}': "
                                        f"HTTP {resp.status_code} — {resp.text[:120]}"
                                    )
                            except Exception as e:
                                errors.append(f"customer properties update '{name}': {e}")

            # ── Prune: delete remote-only entries (only when --prune is set) ───
            if prune:
                for del_yaml_key, del_items in file_plan.get("remote_only_prunable", {}).items():
                    url_template = _PRUNABLE.get((section, del_yaml_key))
                    if not url_template:
                        continue
                    for del_item in del_items:
                        del_id = del_item.get("id")
                        del_name = del_item.get("name") or del_id or "?"
                        if not del_id:
                            continue
                        # Skip system-level / default entries that cannot be deleted
                        if del_item.get("is_default"):
                            logger.info(f"Skipping default {del_yaml_key} '{del_name}' (cannot delete system default)")
                            continue
                        try:
                            del_url = f"{base_url}/{url_template.format(ws_slug=ws_slug, id=del_id)}"
                            resp = session.delete(del_url, headers=headers, timeout=timeout)
                            if resp.status_code in (200, 204):
                                logger.info(f"✓ Pruned {del_yaml_key} '{del_name}' (id={del_id})")
                                file_pushed.append(f"- {del_yaml_key}: {del_name} (deleted)")
                            else:
                                errors.append(
                                    f"{del_yaml_key} DELETE '{del_name}': "
                                    f"HTTP {resp.status_code} — {resp.text[:120]}"
                                )
                        except Exception as e:
                            errors.append(f"{del_yaml_key} delete '{del_name}': {e}")

            # Write local YAML back with patched IDs / updated content
            if file_pushed or file_plan.get("changed"):
                local_path.write_text(
                    yaml.dump(
                        local_yaml,
                        Dumper=_IndentedDumper,
                        default_flow_style=False,
                        sort_keys=False,
                        allow_unicode=True,
                    )
                )
            if file_pushed:
                pushed[filename] = file_pushed

        elapsed = time.time() - start_time

        # Update workspace state after successful push
        _update_workspace_state_after_push(ws_dir)

        _print_push_summary(ws_slug, ws_dir, pushed, errors, elapsed)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"\n[red]✗ Error:[/red] {e}")
        logger.exception("ws push failed")
        raise typer.Exit(1)
    finally:
        await backend.disconnect()


def _push_release_links(
    session: Any,
    headers: dict,
    timeout: Any,
    ws_slug: str,
    base_url: str,
    release_id: str,
    item: dict,
    tag_id_map: dict[str, str],
    label_id_map: dict[str, str],
    errors: list[str],
) -> None:
    """After creating a new release, attach its tag and labels if specified."""
    name = item.get("name", "?")

    # Attach tag if specified
    tag_version = item.get("tag")
    if tag_version:
        tag_id = tag_id_map.get(tag_version)
        if tag_id:
            url = f"{base_url}/workspaces/{ws_slug}/releases/{release_id}/"
            resp = session.patch(url, headers=headers, json={"tag": tag_id}, timeout=timeout)
            if resp.status_code in (200, 201):
                logger.info(f"✓ Linked tag '{tag_version}' to release '{name}'")
            else:
                errors.append(f"releases tag link '{name}': HTTP {resp.status_code}")
        else:
            errors.append(f"releases tag link '{name}': tag '{tag_version}' not found in remote — push the tag first")

    # Attach labels if specified
    label_names = item.get("labels") or []
    if label_names:
        label_ids = [label_id_map[n] for n in label_names if n in label_id_map]
        missing = [n for n in label_names if n not in label_id_map]
        if missing:
            errors.append(f"releases labels '{name}': labels {missing} not found — push them first")
        if label_ids:
            url = f"{base_url}/workspaces/{ws_slug}/releases/{release_id}/labels/"
            resp = session.post(url, headers=headers, json={"label_ids": label_ids}, timeout=timeout)
            if resp.status_code in (200, 201):
                logger.info(f"✓ Linked labels {label_names} to release '{name}'")
            else:
                errors.append(f"releases label link '{name}': HTTP {resp.status_code}")


def _push_release_label_update(
    session: Any,
    headers: dict,
    timeout: Any,
    ws_slug: str,
    base_url: str,
    release_id: str,
    name: str,
    old_labels: list[str],
    new_labels: list[str],
    label_id_map: dict[str, str],
    file_pushed: list[str],
    errors: list[str],
) -> None:
    """Sync labels on an existing release: add new, remove removed."""
    to_add = [lbl for lbl in new_labels if lbl not in old_labels]
    to_remove = [lbl for lbl in old_labels if lbl not in new_labels]
    url = f"{base_url}/workspaces/{ws_slug}/releases/{release_id}/labels/"

    if to_add:
        add_ids = [label_id_map[n] for n in to_add if n in label_id_map]
        missing = [n for n in to_add if n not in label_id_map]
        if missing:
            errors.append(f"releases labels '{name}': {missing} not found — push them first")
        if add_ids:
            resp = session.post(url, headers=headers, json={"label_ids": add_ids}, timeout=timeout)
            if resp.status_code in (200, 201):
                logger.info(f"✓ Added labels {to_add} to release '{name}'")
                file_pushed.append(f"~ releases: {name} (added labels: {', '.join(to_add)})")
            else:
                errors.append(f"releases add labels '{name}': HTTP {resp.status_code}")

    if to_remove:
        rem_ids = [label_id_map[n] for n in to_remove if n in label_id_map]
        if rem_ids:
            resp = session.delete(url, headers=headers, json={"label_ids": rem_ids}, timeout=timeout)
            if resp.status_code in (200, 204):
                logger.info(f"✓ Removed labels {to_remove} from release '{name}'")
                file_pushed.append(f"~ releases: {name} (removed labels: {', '.join(to_remove)})")
            else:
                errors.append(f"releases remove labels '{name}': HTTP {resp.status_code}")


def _push_endpoint(section: str, yaml_key: str, ws_slug: str, base_url: str) -> str:
    """Return the POST URL for a given section/yaml_key."""
    if section == "initiatives":
        return f"{base_url}/workspaces/{ws_slug}/initiatives/labels/"
    if section == "releases_work":
        # work/releases.yaml — actual release objects
        if yaml_key == "releases":
            return f"{base_url}/workspaces/{ws_slug}/releases/"
    if section == "releases_schema":
        # schema/releases.yaml — config: tags + labels
        if yaml_key == "release_tags":
            return f"{base_url}/workspaces/{ws_slug}/releases/tags/"
        if yaml_key == "labels":
            return f"{base_url}/workspaces/{ws_slug}/releases/labels/"
    if section == "project" and yaml_key == "labels":
        # TODO(sdk-refactor): replace with SDK call once project-labels are exposed
        return f"{base_url}/workspaces/{ws_slug}/project-labels/"
    if section == "project" and yaml_key == "states":
        return f"{base_url}/workspaces/{ws_slug}/project-states/"
    if section == "relations" and yaml_key == "relations":
        return f"{base_url}/workspaces/{ws_slug}/work-item-relation-definitions/"
    if section == "customers" and yaml_key == "properties":
        return f"{base_url}/workspaces/{ws_slug}/customer-properties/"
    raise ValueError(f"No push endpoint for section={section} yaml_key={yaml_key}")


def _build_push_payload(section: str, yaml_key: str, item: dict) -> dict:
    """Build the POST payload for a given item."""
    if section == "initiatives" and yaml_key == "labels":
        payload: dict = {"name": item["name"], "color": item.get("color", "#6695FF")}
        if item.get("sort_order") is not None:
            payload["sort_order"] = item["sort_order"]
        return payload

    if section == "releases_work" and yaml_key == "releases":
        # work/releases.yaml — actual release objects
        payload = {"name": item["name"], "status": item.get("status", "unreleased")}
        if item.get("is_latest") is not None:
            payload["is_latest"] = item["is_latest"]
        if item.get("is_prerelease") is not None:
            payload["is_prerelease"] = item["is_prerelease"]
        if item.get("target_date"):
            payload["target_date"] = item["target_date"]
        if item.get("release_date"):
            payload["release_date"] = item["release_date"]
        return payload

    if section == "releases_schema":
        # schema/releases.yaml — config: tags + labels
        if yaml_key == "release_tags":
            return {"version": item["version"]}
        if yaml_key == "labels":
            payload = {"name": item["name"], "color": item.get("color", "#6695FF")}
            if item.get("sort_order") is not None:
                payload["sort_order"] = item["sort_order"]
            return payload

    if section == "project" and yaml_key == "labels":
        payload = {"name": item["name"], "color": item.get("color", "#6695FF")}
        if item.get("sort_order") is not None:
            payload["sort_order"] = item["sort_order"]
        return payload

    if section == "project" and yaml_key == "states":
        payload = {"name": item["name"], "color": item.get("color", "#6695FF")}
        if item.get("group"):
            payload["group"] = item["group"]
        if item.get("description"):
            payload["description"] = item["description"]
        return payload

    if section == "relations" and yaml_key == "relations":
        payload = {
            "name": item["name"],
            "outward": item.get("outward", ""),
            "inward": item.get("inward", ""),
        }
        if item.get("is_active") is not None:
            payload["is_active"] = item["is_active"]
        if item.get("color"):
            payload["color"] = item["color"]
        if item.get("sort_order") is not None:
            payload["sort_order"] = item["sort_order"]
        return payload

    if section == "customers" and yaml_key == "properties":
        payload = {
            "name": item["name"],
            "display_name": item.get("display_name") or item["name"],
            "property_type": item.get("type", "TEXT"),
            "is_required": item.get("required", False),
            # is_active must be sent explicitly — without it the API defaults to
            # false and the property is created but hidden in the Plane UI.
            # Honour the 'active' field from YAML; default to True for new properties.
            "is_active": bool(item.get("active", True)),
        }
        if item.get("settings"):
            payload["settings"] = item["settings"]
        return payload

    raise ValueError(f"No payload builder for section={section} yaml_key={yaml_key}")


def _format_push_item(yaml_key: str, item: dict) -> str:
    """One-line display for a push item."""
    if yaml_key == "releases":
        return f"{item.get('name', '?')}  [{item.get('status', 'unreleased')}]"
    if yaml_key == "release_tags":
        return str(item.get("version", "?"))
    if yaml_key == "labels":
        color = item.get("color", "")
        return f"{item.get('name', '?')}  {color}".strip()
    if yaml_key == "members":
        return item.get("email") or item.get("display_name") or "?"
    if yaml_key == "properties":
        return item.get("display_name") or item.get("name") or "?"
    return str(item)


def _patch_local_id(local_yaml: dict, yaml_key: str, item: dict, new_id: str) -> None:
    """Inject the server-assigned ID into the matching local YAML item in-place.

    Matches by the natural key for each list type:
      releases      → name
      release_tags  → version
      labels        → name
      (initiatives) → name
    """
    match_key_map = {
        "releases": "name",
        "release_tags": "version",
        "labels": "name",
        "properties": "name",  # customer property definitions
    }
    match_key = match_key_map.get(yaml_key, "name")
    match_val = item.get(match_key)

    target_list = local_yaml.get(yaml_key, [])
    for i, entry in enumerate(target_list):
        if entry.get(match_key) == match_val and not entry.get("id"):
            # Rebuild dict with id first for consistent field ordering
            updated = {"id": new_id}
            updated.update(entry)
            target_list[i] = updated
            return


def _print_push_summary(
    ws_slug: str,
    ws_dir: Path,
    pushed: dict[str, list[str]],
    errors: list[str],
    elapsed: float,
) -> None:
    total = sum(len(v) for v in pushed.values())
    lines = ["[bold green]✓ Push complete![/bold green]\n"]
    lines.append(f"  [dim]Location:[/dim]  {ws_dir}\n")

    if pushed:
        lines.append(f"  [bold green]Applied[/bold green]  ({total}):")
        for filename, items in pushed.items():
            lines.append(f"    [cyan]{filename}[/cyan]")
            for desc in items:
                if desc.startswith("~ "):
                    lines.append(f"      [yellow]~[/yellow] {desc[2:]}")
                elif desc.startswith("+ "):
                    lines.append(f"      [green]+[/green] {desc[2:]}")
                else:
                    lines.append(f"      [green]+[/green] {desc}")

    if errors:
        lines.append(f"\n  [bold red]Errors[/bold red]  ({len(errors)}):")
        for err in errors:
            lines.append(f"    [red]✗[/red] {err}")

    lines.append(
        "\n  [dim]Local YAML files updated with server-assigned IDs.[/dim]"
        if pushed else ""
    )

    border = "red" if errors and not pushed else "green"
    console.print(
        Panel(
            "\n".join(lines),
            title=f"[bold]plane ws push[/bold]  [dim]{elapsed:.1f}s[/dim]",
            border_style=border,
            padding=(1, 2),
        )
    )


# ---------------------------------------------------------------------------
# plane ws diff
# ---------------------------------------------------------------------------

@app.command()
def diff(
    workspace: str | None = typer.Argument(
        None, help="Workspace folder name or path (default: current directory)",
    ),
    skip: list[str] = typer.Option(
        [], "--skip", help="Skip a work section (valid: releases). Repeatable.",
    ),
):
    """
    Show differences between local workspace files and remote.

    Compares each schema/ and work/ file on disk against the current state in Plane.
    Output is grouped by direction:
      [green]→ local adds[/green]   — items in local not yet in remote (what push would send)
      [green]← remote adds[/green]  — items in remote not yet in local (what pull would apply)

    \b
    --skip: omit a work section from the diff
        plane ws diff --skip releases   # compare schema/ only

    \b
    Examples:
        cd compose-cli && plane ws diff
        plane ws diff compose-cli
        plane ws diff compose-cli --skip releases
    """
    from planecompose.cli.workspace_utils import resolve_connection_by_id

    _validate_skip(skip)
    ws_dir = _resolve_ws_dir(workspace)
    ws_slug, conn_id = _read_plane_yaml(ws_dir)
    server_url, token = resolve_connection_by_id(conn_id)

    try:
        asyncio.run(_diff(ws_dir, ws_slug, conn_id, server_url, token, skip=skip))
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled.[/yellow]")
        raise typer.Exit(130)


async def _diff(
    ws_dir: Path,
    ws_slug: str,
    conn_id: str,
    server_url: str,
    api_key: str,
    skip: list[str] | None = None,
) -> None:
    """Async implementation of ws diff."""
    from planecompose.backend.plane import PlaneBackend

    start_time = time.time()
    schema_dir = ws_dir / "schema"

    console.print(f"\n[bold cyan]Diffing workspace '{ws_slug}'...[/bold cyan]\n")

    if not schema_dir.exists():
        console.print(
            f"[red]✗ Error:[/red] No [bold]schema/[/bold] directory found in '{ws_dir}'."
        )
        raise typer.Exit(1)

    backend = PlaneBackend.create_client(server_url, api_key, connection_id=conn_id)

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Fetching remote state...", total=None)
            client = backend._require_client
            data = await _fetch_ws_data(client, ws_slug, progress, task)
            progress.update(task, description="Comparing...")

        # Files we can compare — schema/ and work/ (same set that pull updates)
        # (plan_key, section_name, local_path) for all files we diff
        _skip = set(skip or [])
        work_dir = ws_dir / "work"
        all_sections: list[tuple[str, str, Path]] = [
            ("features.yaml",      "features",         schema_dir / "features.yaml"),
            ("members.yaml",       "members",           schema_dir / "members.yaml"),
            ("workitemtypes.yaml", "workitemtypes",     schema_dir / "workitemtypes.yaml"),
            ("initiatives.yaml",   "initiatives",       schema_dir / "initiatives.yaml"),
            ("project.yaml",       "project",           schema_dir / "project.yaml"),
            # schema/releases.yaml — config only (tags + labels); always diffed
            ("releases.yaml",      "releases_schema",  schema_dir / "releases.yaml"),
            ("relations.yaml",     "relations",         schema_dir / "relations.yaml"),
        ]
        # customers.yaml — only when workspace has customers feature enabled
        if data["features"].get("customers", False):
            all_sections.append(
                ("customers.yaml", "customers", schema_dir / "customers.yaml")
            )
        # work/releases.yaml — operational (actual releases); omit if --skip releases
        if "releases" not in _skip:
            all_sections.append(
                ("work/releases.yaml", "releases_work", work_dir / "releases.yaml")
            )

        diffed: list[str] = []
        identical: list[str] = []

        for plan_key, section, local_path in all_sections:
            # When a section's data fetch failed (e.g. HTTP 429 rate-limit),
            # skip it in the diff rather than showing spurious deletes.
            if section == "project" and data.get("project_labels") is None:
                identical.append(plan_key)
                continue
            if section == "customers" and data.get("customer_properties") is None:
                identical.append(plan_key)
                continue
            local_text = _normalize_yaml(local_path.read_text() if local_path.exists() else "")
            remote_text = _render_remote_section(section, data)

            if local_text == remote_text:
                identical.append(plan_key)
                continue

            local_yaml = yaml.safe_load(local_text) or {}
            remote_yaml = yaml.safe_load(remote_text) or {}
            blocks = _compute_semantic_diff(section, local_yaml, remote_yaml)

            if not blocks:
                # Texts differ but no semantic blocks — treat as identical
                # (e.g. pure formatting difference already normalised away)
                identical.append(plan_key)
                continue

            diffed.append(plan_key)
            _print_semantic_diff(plan_key, blocks)

        elapsed = time.time() - start_time
        _print_diff_summary(diffed, identical, elapsed)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"\n[red]✗ Error:[/red] {e}")
        logger.exception("ws diff failed")
        raise typer.Exit(1)
    finally:
        await backend.disconnect()


def _render_remote_section(section: str, data: dict[str, Any]) -> str:
    """Render what a schema file would contain for the given section.

    Writes to a temp file using the same writer functions as pull/clone so the
    comparison is byte-for-byte identical to what pull would produce.
    """
    with tempfile.NamedTemporaryFile(suffix=".yaml", delete=False) as f:
        tmp = Path(f.name)
    try:
        if section == "features":
            _write_features_yaml(tmp, data["features"])
        elif section == "members":
            _write_members_yaml(tmp, data["members"])
        elif section == "workitemtypes":
            _write_workitemtypes_yaml(
                tmp,
                data["wit_dict"],
                data["properties"],
                data["type_property_map"],
            )
        elif section == "initiatives":
            _write_initiatives_yaml(tmp, data["initiative_labels"])
        elif section == "releases_schema":
            _write_releases_config_yaml(
                tmp,
                data["release_tags"],
                data["release_labels"],
            )
        elif section == "releases_work":
            _write_work_releases_yaml(tmp, data["releases"])
        elif section == "project":
            # project_labels / project_states can be None when the fetch failed
            # (e.g. 429).  Clone callers should have already skipped this path
            # via the guard in _fetch_ws_data, but fall back to [] for safety.
            labels = data["project_labels"] if data["project_labels"] is not None else []
            states = data.get("project_states") or []
            _write_project_yaml(tmp, labels, states)
        elif section == "relations":
            _write_relations_yaml(tmp, data.get("relation_definitions", []))
        elif section == "customers":
            _write_customers_yaml(tmp, data.get("customer_properties") or [])
        return tmp.read_text()
    finally:
        tmp.unlink(missing_ok=True)


def _print_diff_summary(
    diffed: list[str],
    identical: list[str],
    elapsed: float,
) -> None:
    if not diffed:
        console.print(
            Panel(
                "[bold green]✓ Local schema is up to date — no differences found.[/bold green]\n\n"
                f"  [dim]Compared: {', '.join(identical)}[/dim]",
                title=f"[bold]plane ws diff[/bold]  [dim]{elapsed:.1f}s[/dim]",
                border_style="green",
                padding=(1, 2),
            )
        )
    else:
        console.print(
            Panel(
                f"[bold yellow]  {len(diffed)} file(s) differ from remote:[/bold yellow]  "
                + ", ".join(f"[cyan]{f}[/cyan]" for f in diffed)
                + (
                    f"\n  [dim]Unchanged: {', '.join(identical)}[/dim]"
                    if identical else ""
                )
                + "\n\n"
                "[dim]  Run [/dim][cyan]plane ws pull --merge[/cyan][dim] to apply remote changes while keeping local additions.[/dim]",
                title=f"[bold]plane ws diff[/bold]  [dim]{elapsed:.1f}s[/dim]",
                border_style="yellow",
                padding=(1, 2),
            )
        )


# ---------------------------------------------------------------------------
# Summary (clone)
# ---------------------------------------------------------------------------

def _print_summary(
    ws_slug: str,
    target_dir: Path,
    features: dict,
    members: list,
    wit_dict: dict,
    properties: list,
    initiative_labels: list,
    releases: list,
    release_tags: list,
    release_labels: list,
    project_labels: list | None,
    project_states: list | None,
    relation_definitions: list,
    elapsed: float,
) -> None:
    enabled = [k for k, v in features.items() if v]
    labels_line = (
        f"  [dim]Project labels: [/dim] {len(project_labels)} fetched\n"
        if project_labels is not None
        else "  [dim]Project labels: [/dim] [dim]unavailable (rate limited)[/dim]\n"
    )
    states_line = (
        f"  [dim]Project states:  [/dim] {len(project_states)} fetched\n"
        if project_states
        else "  [dim]Project states:  [/dim] [dim]endpoint not available yet[/dim]\n"
    )
    relations_line = (
        f"  [dim]Relations:       [/dim] {len(relation_definitions)} fetched\n"
        if relation_definitions
        else "  [dim]Relations:       [/dim] [dim]endpoint not available yet[/dim]\n"
    )
    console.print(
        Panel(
            f"[bold green]✓ Workspace cloned successfully![/bold green]\n\n"
            f"  [dim]Location:       [/dim] {target_dir}\n"
            f"  [dim]Members:        [/dim] {len(members)} fetched\n"
            f"  [dim]WI Types:       [/dim] {len(wit_dict)} fetched\n"
            f"  [dim]WI Properties:  [/dim] {len(properties)} fetched\n"
            f"  [dim]Initiative lbls:[/dim] {len(initiative_labels)} fetched\n"
            f"  [dim]Releases:       [/dim] {len(releases)} fetched\n"
            f"  [dim]Release tags:   [/dim] {len(release_tags)} fetched\n"
            f"  [dim]Release labels: [/dim] {len(release_labels)} fetched\n"
            + labels_line
            + states_line
            + relations_line
            + f"  [dim]Features:       [/dim] {', '.join(enabled) if enabled else 'none'}\n\n"
            f"  [cyan]cd {ws_slug}[/cyan]\n\n"
            f"[dim]Next: plane ws pull · plane ws schema push · plane ws schema diff[/dim]",
            title=f"[bold]plane ws clone[/bold]  [dim]{elapsed:.1f}s[/dim]",
            border_style="green",
            padding=(1, 2),
        )
    )


# ---------------------------------------------------------------------------
# Data fetchers
# ---------------------------------------------------------------------------

def _fetch_members_with_roles(client: Any, ws_slug: str) -> list[dict]:
    """Fetch workspace members with role via direct HTTP.

    The SDK's workspaces.get_members() drops the `role` field. We call the
    endpoint directly so members.yaml captures each member's actual role.

    Role values: 20=Admin/Owner, 15=Member, 10=Viewer, 5=Guest

    # TODO(sdk-refactor): replace with client.sdk.workspaces.get_members() once
    # the SDK exposes the `role` field on returned member objects.
    """
    base_url = client.sdk.config.base_path
    data = workspace_http_get(client, f"{base_url}/workspaces/{ws_slug}/members/")
    if data is None:
        return []

    result: list[dict] = []
    for m in data or []:
        email = m.get("email", "")
        # Skip system bot accounts (bot users, intake bots, automation bots)
        if (
            email.startswith("bot_user")
            or email.startswith("automation-bot-")
            or email.endswith("-intake@plane.so")
        ):
            continue
        entry: dict = {}
        if m.get("id"):
            entry["id"] = m["id"]
        if email:
            entry["email"] = email
        if m.get("display_name"):
            entry["display_name"] = m["display_name"]
        role_slug = m.get("role_slug")
        if role_slug:
            entry["role"] = role_slug
        elif m.get("role") is not None:
            # Fallback for older servers that don't return role_slug
            entry["role"] = _ROLE_LABELS.get(m["role"], str(m["role"]))
        if entry:
            result.append(entry)

    logger.info(f"✓ Fetched {len(result)} workspace members for {ws_slug}")
    return result


def _fetch_work_item_properties(client: Any, ws_slug: str) -> list[dict]:
    """Fetch workspace-level custom work item property definitions.

    Returns a list of property objects with name, property_type, is_required,
    is_multi, is_active, and options (for OPTION type properties).

    # TODO(sdk-refactor): SDK has work_item_properties.list() but it is
    # project-scoped. Replace once SDK adds workspace-level list support.
    """
    base_url = client.sdk.config.base_path
    data = workspace_http_get(client, f"{base_url}/workspaces/{ws_slug}/work-item-properties/")
    if not data:
        return []

    result: list[dict] = []
    for prop in data or []:
        entry: dict = {}
        if prop.get("id"):
            entry["id"] = prop["id"]
        if prop.get("name"):
            entry["name"] = prop["name"]
        if prop.get("property_type"):
            entry["property_type"] = prop["property_type"]
        entry["is_required"] = prop.get("is_required", False)
        entry["is_multi"] = prop.get("is_multi", False)
        entry["is_active"] = prop.get("is_active", True)
        # Include options list for OPTION-type properties
        options = prop.get("options") or []
        if options:
            entry["options"] = [
                {k: v for k, v in opt.items() if k in ("id", "name", "color", "sort_order")}
                for opt in options
            ]
        result.append(entry)

    logger.info(f"✓ Fetched {len(result)} work item properties for {ws_slug}")
    return result


def _fetch_type_property_map(
    client: Any, ws_slug: str, wit_dict: dict[str, Any]
) -> dict[str, list[Any]]:
    """Fetch the property IDs assigned to each unique work item type.

    Calls ``GET /api/v1/workspaces/{slug}/work-item-types/{type_id}/properties/``
    which returns a flat list of property UUIDs.

    To avoid redundant calls for duplicate-named types (e.g. 15 "Task" entries
    created from defaults), only the "winning" type ID per name is fetched —
    using the same preference as the YAML writer (is_default wins).

    Returns a dict mapping type_id → [property_id, ...].
    """
    if not wit_dict:
        return {}

    # Determine the winning type ID per unique name (mirrors writer dedup logic)
    winning: dict[str, str] = {}  # name → type_id
    for type_id, wit in wit_dict.items():
        name = wit.get("name", "")
        if name and (name not in winning or wit.get("is_default")):
            winning[name] = type_id

    base_url = client.sdk.config.base_path
    result: dict[str, list[Any]] = {}
    for name, type_id in winning.items():
        ids = workspace_http_get(
            client,
            f"{base_url}/workspaces/{ws_slug}/work-item-types/{type_id}/properties/",
        )
        if isinstance(ids, list):
            result[type_id] = ids

    logger.info(
        f"✓ Fetched property mappings for {len(result)}/{len(winning)} types in {ws_slug}"
    )
    return result


def _fetch_initiative_labels(client: Any, ws_slug: str) -> list[dict]:
    """Fetch workspace-level initiative labels, preserving sort order.

    Includes sort_order so labels are written in the same order as the UI
    and new labels can be positioned correctly on push.

    # TODO(sdk-refactor): no SDK method exists. Add once SDK exposes
    # workspaces.list_initiative_labels() or similar.
    """
    base_url = client.sdk.config.base_path
    data = workspace_http_get(client, f"{base_url}/workspaces/{ws_slug}/initiatives/labels/")
    if not data:
        return []

    result: list[dict] = []
    for lbl in data or []:
        entry: dict = {}
        if lbl.get("id"):
            entry["id"] = lbl["id"]
        if lbl.get("name"):
            entry["name"] = lbl["name"]
        if lbl.get("color"):
            entry["color"] = lbl["color"]
        if lbl.get("sort_order") is not None:
            entry["sort_order"] = lbl["sort_order"]
        if entry:
            result.append(entry)

    # Sort by sort_order so YAML reflects the UI display order
    result.sort(key=lambda x: x.get("sort_order") or 0)
    logger.info(f"✓ Fetched {len(result)} initiative labels for {ws_slug}")
    return result


def _fetch_project_labels(client: Any, ws_slug: str) -> list[dict] | None:
    """Fetch workspace-level project labels.

    Endpoint: GET /api/v1/workspaces/{slug}/project-labels/
    Returns labels used to tag projects in the workspace project-tracking view.
    Includes sort_order so labels are written in UI display order.

    Returns ``None`` when the API call fails (e.g. HTTP 429 rate-limit) so
    callers can distinguish "fetch failed → preserve local" from "server
    returned an empty list → write empty".  Returns ``[]`` when the server
    responds 200 with no labels.

    Note: project-states uses /api/ (session auth only) — no v1 route yet.
    See plane-compose-issues.md for the backend request.

    # TODO(sdk-refactor): replace with SDK call once workspace project-labels
    # are exposed in the Python SDK.
    """
    base_url = client.sdk.config.base_path
    data = workspace_http_get(client, f"{base_url}/workspaces/{ws_slug}/project-labels/")
    if data is None:
        # API call failed (e.g. 429 rate-limit) — signal to caller so local
        # data is preserved rather than being wiped.
        return None
    # ``data`` is now a list (possibly empty if the server has no labels).
    result: list[dict] = []
    for lbl in data:
        entry: dict = {}
        if lbl.get("id"):
            entry["id"] = lbl["id"]
        if lbl.get("name"):
            entry["name"] = lbl["name"]
        if lbl.get("color"):
            entry["color"] = lbl["color"]
        if lbl.get("sort_order") is not None:
            entry["sort_order"] = lbl["sort_order"]
        if entry:
            result.append(entry)

    result.sort(key=lambda x: x.get("sort_order") or 0)
    logger.info(f"✓ Fetched {len(result)} project labels for {ws_slug}")
    return result


def _fetch_project_states(client: Any, ws_slug: str) -> list[dict] | None:
    """Fetch workspace-level project states.

    Endpoint: GET /api/v1/workspaces/{slug}/project-states/
    Available once plane-ee PR #7010 is merged.

    Returns ``None`` when the API call fails (e.g. HTTP 429 rate-limit) so
    callers can distinguish "fetch failed → preserve local" from "server
    returned an empty list → write empty".  Returns ``[]`` when the server
    responds 200 with no states.

    Fields captured: id, name, color, group, default, sequence, description.
    """
    base_url = client.sdk.config.base_path
    data = workspace_http_get(client, f"{base_url}/workspaces/{ws_slug}/project-states/")
    if data is None:
        # API call failed (e.g. 429 rate-limit) — signal to caller so local
        # data is preserved rather than being wiped.
        return None

    result: list[dict] = []
    for s in data:
        entry: dict = {}
        if s.get("id"):
            entry["id"] = s["id"]
        if s.get("name"):
            entry["name"] = s["name"]
        if s.get("color"):
            entry["color"] = s["color"]
        if s.get("group"):
            entry["group"] = s["group"]
        if s.get("default") is not None:
            entry["default"] = s["default"]
        if s.get("sequence") is not None:
            entry["sequence"] = s["sequence"]
        if s.get("description"):
            entry["description"] = s["description"]
        if entry:
            result.append(entry)

    result.sort(key=lambda x: x.get("sequence") or 0)
    logger.info(f"✓ Fetched {len(result)} project states for {ws_slug}")
    return result


def _fetch_relation_definitions(client: Any, ws_slug: str) -> list[dict]:
    """Fetch workspace-level work item relation definitions.

    Endpoint: GET /api/v1/workspaces/{slug}/work-item-relation-definitions/
    Available once plane-ee PR #7048 is merged.
    Returns [] on 404/failure — caller writes stub in that case.

    Fields captured: id, name, outward, inward, is_default, is_active, color, sort_order.
    """
    base_url = client.sdk.config.base_path
    # Pass ?is_default=false&is_active=false to disable both server-side filters so the
    # response includes ALL relation definitions (custom + system, active + inactive).
    # Without these params the endpoint defaults to is_default=true, returning only
    # system-seeded relations and silently omitting any custom ones.
    data = workspace_http_get(
        client,
        f"{base_url}/workspaces/{ws_slug}/work-item-relation-definitions/?is_default=false&is_active=false",
    )
    if not data:
        return []

    result: list[dict] = []
    for r in data or []:
        entry: dict = {}
        if r.get("id"):
            entry["id"] = r["id"]
        if r.get("name"):
            entry["name"] = r["name"]
        if r.get("outward"):
            entry["outward"] = r["outward"]
        if r.get("inward"):
            entry["inward"] = r["inward"]
        # Only write is_default when True — marks system relations the user cannot delete.
        # Custom relations (is_default=false) omit this field to keep the YAML clean.
        if r.get("is_default"):
            entry["is_default"] = True
        # is_active: no UI toggle exists; always true in practice — omit to reduce noise.
        # color: not exposed in Plane UI for relations — omit.
        # sort_order kept for stable ordering.
        if r.get("sort_order") is not None:
            entry["sort_order"] = r["sort_order"]
        if entry:
            result.append(entry)

    result.sort(key=lambda x: x.get("sort_order") or 0)
    logger.info(f"✓ Fetched {len(result)} relation definitions for {ws_slug}")
    return result


def _fetch_releases(
    client: Any,
    ws_slug: str,
    release_tags: list[dict] | None = None,
) -> list[dict]:
    """Fetch workspace-level releases, resolving tag IDs and per-release labels.

    Each release entry includes:
      - tag: version string (e.g. "v1.0.0") resolved from release_tags, not a UUID
      - labels: list of label names attached to this specific release

    # TODO(sdk-refactor): no SDK method exists. Add once SDK exposes
    # workspaces.list_releases() or similar.
    """
    base_url = client.sdk.config.base_path
    data = workspace_http_get(client, f"{base_url}/workspaces/{ws_slug}/releases/")
    if not data:
        return []

    # Build tag ID → version lookup for human-readable output
    tag_version_map: dict[str, str] = {
        t["id"]: t["version"]
        for t in (release_tags or [])
        if t.get("id") and t.get("version")
    }

    result: list[dict] = []
    for rel in data or []:
        entry: dict = {}
        if rel.get("id"):
            entry["id"] = rel["id"]
        if rel.get("name"):
            entry["name"] = rel["name"]
        if rel.get("status"):
            entry["status"] = rel["status"]
        if rel.get("target_date"):
            entry["target_date"] = rel["target_date"]
        if rel.get("release_date"):
            entry["release_date"] = rel["release_date"]
        entry["is_latest"] = rel.get("is_latest", False)
        entry["is_prerelease"] = rel.get("is_prerelease", False)

        # Resolve tag UUID → version string
        if rel.get("tag"):
            entry["tag"] = tag_version_map.get(rel["tag"], rel["tag"])

        # Fetch labels attached to this specific release
        if rel.get("id"):
            linked = workspace_http_get(
                client,
                f"{base_url}/workspaces/{ws_slug}/releases/{rel['id']}/labels/",
            )
            if linked:
                names = [lbl["name"] for lbl in linked if lbl.get("name")]
                if names:
                    entry["labels"] = names

        result.append(entry)

    logger.info(f"✓ Fetched {len(result)} releases for {ws_slug}")
    return result


def _fetch_release_tags(client: Any, ws_slug: str) -> list[dict]:
    """Fetch workspace-level release tags (git tag references).

    # TODO(sdk-refactor): no SDK method exists. Add once SDK exposes
    # workspaces.list_release_tags() or similar.
    """
    base_url = client.sdk.config.base_path
    data = workspace_http_get(client, f"{base_url}/workspaces/{ws_slug}/releases/tags/")
    if not data:
        return []

    result: list[dict] = []
    for tag in data or []:
        entry: dict = {}
        if tag.get("id"):
            entry["id"] = tag["id"]
        if tag.get("version"):
            entry["version"] = tag["version"]
        if tag.get("commit_hash"):
            entry["commit_hash"] = tag["commit_hash"]
        if tag.get("git_tag"):
            entry["git_tag"] = tag["git_tag"]
        if entry:
            result.append(entry)

    logger.info(f"✓ Fetched {len(result)} release tags for {ws_slug}")
    return result


def _fetch_release_labels(client: Any, ws_slug: str) -> list[dict]:
    """Fetch workspace-level release labels, preserving sort order.

    Includes sort_order so labels are written in the same order as the UI
    and new labels can be positioned correctly on push.

    # TODO(sdk-refactor): no SDK method exists. Add once SDK exposes
    # workspaces.list_release_labels() or similar.
    """
    base_url = client.sdk.config.base_path
    data = workspace_http_get(client, f"{base_url}/workspaces/{ws_slug}/releases/labels/")
    if not data:
        return []

    result: list[dict] = []
    for lbl in data or []:
        entry: dict = {}
        if lbl.get("id"):
            entry["id"] = lbl["id"]
        if lbl.get("name"):
            entry["name"] = lbl["name"]
        if lbl.get("color"):
            entry["color"] = lbl["color"]
        if lbl.get("sort_order") is not None:
            entry["sort_order"] = lbl["sort_order"]
        if entry:
            result.append(entry)

    # Sort by sort_order so YAML reflects the UI display order
    result.sort(key=lambda x: x.get("sort_order") or 0)
    logger.info(f"✓ Fetched {len(result)} release labels for {ws_slug}")
    return result


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------

class _IndentedDumper(yaml.Dumper):
    """PyYAML Dumper that indents list items under their parent key.

    Default PyYAML writes:
        releases:
        - id: abc

    This produces the more readable form:
        releases:
          - id: abc

    Ensures consistent formatting across clone, pull, and diff so file
    comparisons never show false diffs due to indentation style.
    """

    def increase_indent(self, flow: bool = False, indentless: bool = False) -> None:
        return super().increase_indent(flow=flow, indentless=False)


def _dump(path: Path, data: Any, header: str = "") -> None:
    """Write data to a YAML file with consistently indented list items and optional header comments."""
    with open(path, "w") as f:
        if header:
            f.write(header)
            f.write("\n")
        yaml.dump(
            data, f,
            Dumper=_IndentedDumper,
            default_flow_style=False,
            sort_keys=False,
            allow_unicode=True,
        )


def _normalize_yaml(text: str) -> str:
    """Re-parse and re-dump YAML text through _IndentedDumper.

    Eliminates false diff noise from files written by older versions of this
    tool that used PyYAML's default non-indented list style.  Both sides of a
    diff/pull comparison are normalized before the string comparison so only
    real content differences are reported.

    Returns the original text unchanged on parse failure.
    """
    if not text.strip():
        return text
    try:
        data = yaml.safe_load(text)
        return yaml.dump(
            data,
            Dumper=_IndentedDumper,
            default_flow_style=False,
            sort_keys=False,
            allow_unicode=True,
        )
    except Exception:
        return text


def _write_plane_yaml(target_dir: Path, ws_slug: str, conn_id: str) -> None:
    """Write plane.yaml marking this as a workspace context."""
    header = """# Plane Workspace Configuration
# This is a workspace-level configuration file.
# Use 'plane workspace' commands to manage this file."""
    _dump(
        target_dir / "plane.yaml",
        {
            "type": "workspace",
            "workspace": ws_slug,
            "connection": conn_id,
        },
        header=header,
    )


def _write_features_yaml(path: Path, features: dict) -> None:
    """Write workspace feature flags under a 'features:' root key."""
    header = """# Workspace Feature Flags
# Controls which features are enabled in the workspace.
# These flags are set via Plane's workspace settings and are read-only here."""
    _dump(path, {"features": features}, header=header)


def _write_members_yaml(path: Path, members: list[dict]) -> None:
    """Write workspace members list under a 'members:' root key."""
    header = """# Workspace Members
# Lists all members in the workspace with their roles.
# This information is synced from Plane and is read-only here.
#
# Example:
# members:
#   - email: user1@example.com
#     id: <uuid>
#     display_name: User One
#   - email: user2@example.com
#     id: <uuid>
#     display_name: User Two"""
    _dump(path, {"members": members}, header=header)


def _write_workitemtypes_yaml(
    path: Path,
    wit_dict: dict[str, Any],
    properties: list[dict] | None = None,
    type_property_map: dict[str, list[Any]] | None = None,
) -> None:
    """Write workitemtypes.yaml with three sections matching the UI tabs:
      - work_item_types  (types with icon, level, description)
      - properties       (workspace-level custom property definitions — stub)
      - hierarchy        (derived from level field on each type)

    Workspace can have duplicate-named types (e.g. many "Task" entries created
    from defaults). We deduplicate by name, preferring the is_default entry.
    """
    work_item_types: dict = {}

    for type_id, wit in wit_dict.items():
        name = wit.get("name", "")
        if not name:
            continue

        level = float(wit.get("level", 0.0) or 0.0)
        level_int = int(level) if level == int(level) else level

        entry: dict = {"id": type_id}
        if wit.get("description"):
            entry["description"] = wit["description"]
        if wit.get("is_default"):
            entry["is_default"] = True
        entry["is_active"] = wit.get("is_active", True)
        entry["level"] = level_int

        # Flatten logo_props → icon for readability
        logo_props = wit.get("logo_props") or {}
        icon_data = logo_props.get("icon") or {}
        if icon_data:
            entry["icon"] = {
                "name": icon_data.get("name"),
                "color": icon_data.get("background_color"),
            }

        # Deduplicate by name: prefer is_default, otherwise keep first seen
        if name not in work_item_types or wit.get("is_default"):
            work_item_types[name] = entry

    # Attach property names to each deduped type entry.
    # Build an id→name lookup from the already-fetched properties list so we
    # show human-readable names instead of raw UUIDs.
    if type_property_map:
        prop_name_by_id = {
            p["id"]: p["name"]
            for p in (properties or [])
            if p.get("id") and p.get("name")
        }
        for entry in work_item_types.values():
            prop_ids = type_property_map.get(entry["id"], [])
            if prop_ids:
                entry["properties"] = [prop_name_by_id.get(pid, pid) for pid in prop_ids]

    # Build levels from ACTIVE type names only — inactive types are excluded
    # from hierarchy (matches UI behaviour: disabled types don't appear in
    # the hierarchy view even though the API returns them).
    levels: dict[float, list[str]] = {}
    for name, entry in work_item_types.items():
        if not entry.get("is_active", True):
            continue
        lvl = float(entry["level"])
        levels.setdefault(lvl, []).append(name)

    # Build hierarchy as level-grouped nodes (descending — highest level first,
    # matching the UI which shows the most abstract types at the top).
    # Level 0 = default leaf types. Level N = parent of Level N-1 types.
    # parent_types are omitted — they are implicit: all types at level N-1
    # are parents of all types at level N.
    hierarchy: list[dict] = []
    for lvl in sorted(levels.keys(), reverse=True):
        lvl_int = int(lvl) if lvl == int(lvl) else lvl
        hierarchy.append({
            "level": lvl_int,
            "types": sorted(levels[lvl]),
        })

    header = """# Workspace Work Item Types
# Defines work item types available across all projects in the workspace.
# This information is synced from Plane and is read-only here.
#
# Sections:
# - work_item_types: Type definitions with icons, levels, and descriptions
# - properties: Workspace-level custom property definitions
# - hierarchy: Types grouped by level (highest level first, matching the UI)
#              Level 0 = default leaf types. Each level's types can be
#              children of the level above them. Read-only — edit via Plane UI."""
    _dump(
        path,
        {
            "work_item_types": work_item_types,
            "properties": properties or [],
            "hierarchy": hierarchy,
        },
        header=header,
    )


def _write_project_yaml(
    path: Path,
    labels: list[dict] | None = None,
    states: list[dict] | None = None,
) -> None:
    """Workspace project-tracking labels and states.

    Labels fetched from /api/v1/workspaces/{slug}/project-labels/.
    States fetched from /api/v1/workspaces/{slug}/project-states/ (plane-ee PR #7010).
    Falls back to empty states list on older Plane instances without the endpoint.
    """
    header = """# Workspace Project Configuration
# Shared labels and states for workspace-level projects.
# This information is synced from Plane and is read-only here.
#
# Sections:
# - labels: Shared labels available across projects
# - states: Workspace project states"""
    _dump(path, {
        "labels": labels or [],
        "states": states or [],
    }, header=header)


def _write_initiatives_yaml(path: Path, labels: list[dict] | None = None) -> None:
    """Write initiative labels used for categorizing strategic initiatives."""
    header = """# Workspace Initiatives Configuration
# Labels for organizing and tracking workspace-level strategic initiatives.
# This information is synced from Plane and is read-only here.
#
# Sections:
# - labels: Labels available for initiatives"""
    _dump(path, {"labels": labels or []}, header=header)


def _write_releases_config_yaml(
    path: Path,
    release_tags: list[dict] | None = None,
    labels: list[dict] | None = None,
) -> None:
    """Write schema/releases.yaml — configuration only: release tags and labels.

    Actual release objects (operational data) live in work/releases.yaml.
    """
    header = """# Workspace Releases Configuration (schema)
# Defines release tags and labels used to categorise releases.
# This is configuration (Settings-level) data — rarely changes.
#
# Sections:
# - release_tags: Git tag references for releases (version strings)
# - labels: Labels for release organisation
#
# Actual release objects live in work/releases.yaml."""
    _dump(
        path,
        {
            "release_tags": release_tags or [],
            "labels": labels or [],
        },
        header=header,
    )


def _write_work_releases_yaml(
    path: Path,
    releases: list[dict] | None = None,
) -> None:
    """Write work/releases.yaml — operational data: actual release objects.

    Release tags and labels (configuration) live in schema/releases.yaml.
    """
    header = """# Workspace Releases (work)
# Contains the actual release objects — name, status, dates, linked tags and labels.
# This is operational data (UI-level) — changes frequently.
#
# How it works:
#   - Items WITHOUT an id  → created on `plane ws push` (id written back in-place)
#   - Items WITH an id     → updated on `plane ws push` if fields changed
#   - Items absent locally → NOT deleted remotely (pull to refresh)
#
# Release tags and label definitions live in schema/releases.yaml.
#
# Field reference:
#   name          (required) display name shown in Plane UI
#   status        unreleased | released | cancelled  (default: unreleased)
#   tag           version string — must match a release_tag in schema/releases.yaml
#   target_date   YYYY-MM-DD
#   release_date  YYYY-MM-DD  (set when status → released)
#   is_latest     true | false
#   is_prerelease true | false
#   labels        list of label names from schema/releases.yaml
#
# Example:
#
# releases:
#   - name: v1.0.0
#     status: released
#     tag: v1.0.0
#     release_date: 2025-06-01
#     is_latest: true
#     is_prerelease: false
#     labels:
#       - Stable
#   - name: v1.1.0-beta
#     status: unreleased
#     tag: v1.1.0
#     target_date: 2025-08-01
#     is_prerelease: true"""
    _dump(
        path,
        {"releases": releases or []},
        header=header,
    )


def _write_relations_yaml(path: Path, relations: list[dict] | None = None) -> None:
    """Write relations.yaml.

    Field mapping (matches /api/v1/workspaces/{slug}/work-item-relation-definitions/ response):
      name       — display name shown in the UI
      outward    — label shown on the source side  (e.g. "implements")
      inward     — label shown on the target side  (e.g. "implemented by")
      is_default — only written when true; marks system-seeded relations (cannot be deleted)
      sort_order — display order

    System default relations are always present in every workspace (created_by=null).
    Custom relations are created by workspace admins (is_default omitted in YAML).

    Fetched from /api/v1/workspaces/{slug}/work-item-relation-definitions/ (plane-ee PR #7048).
    Falls back to empty list on older Plane instances without the endpoint.
    """
    header = """# Workspace Work Item Relations
# Defines relationships between work items (e.g., "implements", "depends on").
# System-default relations (marked is_default: true) cannot be deleted.
# Custom relations can be created, updated, or removed via plane ws push [--prune].
#
# IMPORTANT: name, outward, and inward must each be unique across all relations in
# the workspace. Duplicate values will be rejected by the API with a validation error.
#
# Fields:
# - name: Display name of the relation type
# - outward: Label shown on the source side (e.g., "implements")
# - inward: Label shown on the target side (e.g., "implemented by")
# - is_default: true only for system-seeded relations (cannot be deleted or modified)"""
    if relations is not None:
        _dump(path, {"relations": relations}, header=header)
        return

    # Fallback stub — written when endpoint returns 404 (older Plane without PR #7048).
    _dump(path, {"relations": []}, header=header)


def _write_customers_yaml(
    path: Path,
    properties: list[dict] | None = None,
) -> None:
    """Write schema/customers.yaml — customer property definitions.

    Only custom properties are listed here.  Standard fields (name, email,
    website_url, domain, employees, stage, contract_status, revenue) are
    always present in Plane and are not included.

    Only written when the workspace has the ``customers`` feature enabled.

    Fetched from /api/v1/workspaces/{slug}/customer-properties/.

    Fields (for each property):
      id            — UUID assigned by the server
      name          — internal identifier slug (immutable after creation)
      display_name  — label shown in the Plane UI
      type          — TEXT | NUMBER | DATE | DATETIME | BOOLEAN | OPTION | MULTI_OPTION | FILE | URL
      required      — true | false
      settings      — type-specific settings (e.g. {display_format: single-line} for TEXT)
    """
    header = """# Customer Property Definitions
# Custom fields added to the customer form.
# Standard fields (name, email, website_url, domain, employees,
# stage, contract_status, revenue) are always present in Plane.
#
# Only custom properties are listed here.
#
# To add/update/remove a custom property:
#   1. Edit this file (add/modify/remove entries under 'properties:')
#   2. Run plane ws push to apply changes
#   3. Use plane ws push --prune to also delete remote-only properties
#
# Fields:
#   id            server-assigned UUID (written back after creation; omit for new entries)
#   name          internal identifier slug (immutable — cannot be changed after creation)
#   display_name  label shown in the Plane UI
#   type          TEXT | NUMBER | DATE | DATETIME | BOOLEAN | OPTION | MULTI_OPTION | FILE | URL
#   required      true | false  (default: false)
#   active        true | false  — mirrors is_active; set false to disable without deleting
#   settings      type-specific settings (e.g. {display_format: single-line} for TEXT)"""

    props: list[dict] = []
    for p in (properties or []):
        if not isinstance(p, dict):
            continue
        entry: dict = {}
        if p.get("id"):
            entry["id"] = p["id"]
        if p.get("name"):
            entry["name"] = p["name"]
        if p.get("display_name"):
            entry["display_name"] = p["display_name"]
        prop_type = p.get("property_type")
        if prop_type:
            entry["type"] = prop_type
        entry["required"] = bool(p.get("is_required", False))
        # active mirrors is_active on the server — set to false to disable the
        # property in the Plane UI without deleting it.
        entry["active"] = bool(p.get("is_active", True))
        if p.get("settings"):
            entry["settings"] = p["settings"]
        # For OPTION / MULTI_OPTION properties, write the option values.
        # options come from the detail endpoint (list endpoint omits them).
        # Only include active options — is_active: false are soft-deleted entries
        # that the detail endpoint still returns.
        if prop_type in ("OPTION", "MULTI_OPTION") and p.get("options"):
            entry["options"] = [
                {"id": opt["id"], "name": opt["name"]}
                for opt in p["options"]
                if opt.get("id") and opt.get("name") and opt.get("is_active", True)
            ]
        if entry.get("name"):
            props.append(entry)

    _dump(path, {"properties": props}, header=header)


def _write_webhooks_yaml(path: Path, webhooks: list[dict] | None = None) -> None:
    """Write webhooks.yaml.

    Field schema (from plane-ee WebhookSerializer / Webhook model):
      url           — payload URL
      name          — display name
      is_active     — bool (default true)
      content_type  — "JSON" or "FORM_DATA"
      project       — bool, trigger on project events  (deprecated v1 scope)
      issue         — bool, trigger on work item events (deprecated v1 scope)
      module        — bool, trigger on module events   (deprecated v1 scope)
      cycle         — bool, trigger on cycle events    (deprecated v1 scope)
      issue_comment — bool, trigger on comment events  (deprecated v1 scope)
      rich_filters  — JSON object (new-style event filter, replaces individual flags)
      pql_filters   — JSON object (PQL-based filter)
      secret_key    — auto-generated by server, NOT stored in YAML (sensitive)

    API note: GET/POST/PATCH/DELETE /api/workspaces/{slug}/webhooks/ → 401 (session auth only)
    GET /api/v1/workspaces/{slug}/webhooks/ → 404 (no v1 route yet)
    Stub written empty until backend adds API key support.
    """
    header = """# Workspace Webhooks
# Configure webhooks to receive notifications about workspace events.
# This information is synced from Plane and is read-only here.
# Secrets are never stored locally; manage them via the Plane web interface.
#
# Fields:
# - url: Webhook endpoint URL
# - name: Display name for the webhook
# - is_active: Whether the webhook is enabled
# - content_type: "JSON" or "FORM_DATA"
# - rich_filters: Event filter object (new-style filtering)
#
# Example:
# webhooks:
#   - name: CI/CD Integration
#     url: https://ci.example.com/webhooks/plane
#     is_active: true
#     content_type: JSON"""
    _dump(path, {"webhooks": webhooks or []}, header=header)
