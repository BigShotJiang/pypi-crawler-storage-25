"""Display utilities for CLI commands.

This module provides consistent formatting and display functions
used across CLI commands for tables, summaries, and progress output.
"""
from typing import Callable
from rich.table import Table

from planecompose.cli.helpers import console


def format_duration(seconds: float) -> str:
    """Format a duration in seconds to a human-readable string."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    return f"{int(seconds // 60)}m {int(seconds % 60)}s"


def display_create_table(title: str, items: list, row_func: Callable) -> None:
    """
    Display a table of items to be created.

    Args:
        title: Table title (e.g., "Work Item Types")
        items: List of items to display
        row_func: Function that takes an item and returns a tuple of (name, details)
    """
    if not items:
        return

    table = Table(title=f"{title} to Create")
    table.add_column("Name")
    table.add_column("Details", style="dim")

    for item in items:
        row_data = row_func(item)
        table.add_row(*row_data)

    console.print(table)
    console.print()


def display_items_preview(items: list, title: str = "Work Items to Pull") -> None:
    """
    Display a preview table of work items.

    Args:
        items: List of WorkItem objects
        title: Table title
    """
    console.print(f"\n[bold]Found {len(items)} work items in Plane[/bold]\n")

    table = Table(title=title)
    table.add_column("ID", style="cyan")
    table.add_column("Title", style="bold")
    table.add_column("Type", style="yellow")
    table.add_column("State", style="green")

    for item in items[:10]:
        table.add_row(
            item.id or "—",
            item.title[:40] + ("..." if len(item.title) > 40 else ""),
            item.type,
            item.state or "—"
        )

    console.print(table)

    if len(items) > 10:
        console.print(f"[dim]...and {len(items) - 10} more[/dim]")

    console.print()


def display_pull_summary(
    work_only: bool,
    schema_time: float,
    items_count: int,
    output_path: str,
    with_properties: bool,
    elapsed: float,
) -> None:
    """Display summary after pull command."""
    console.print()

    if not work_only:
        console.print(f"[green][/green] Pulled schema to [cyan]schema/[/cyan] [dim]({format_duration(schema_time)})[/dim]")

    console.print(f"[green][/green] Pulled {items_count} work items to [cyan]{output_path}[/cyan]")

    if with_properties:
        console.print("[green][/green] Fetched custom properties for all items")

    console.print(f"[dim]  Total time: {format_duration(elapsed)}[/dim]")
    console.print()

    if work_only:
        console.print("[dim]Tip: Use without --work-only to pull schema too[/dim]")
    console.print()


def display_push_plan(plan) -> None:
    """
    Display the sync plan before pushing.

    Args:
        plan: SyncPlan object with creates and updates lists
    """
    console.print("\n[bold]Work Items Push Plan[/bold]\n")

    if plan.creates:
        table = Table(title=f"{len(plan.creates)} Work Items to Create")
        table.add_column("Title", style="bold")
        table.add_column("Type", style="cyan")
        table.add_column("Priority", style="yellow")
        table.add_column("Labels", style="dim")

        for sync_item in plan.creates:
            item = sync_item.item
            labels_str = ", ".join(item.labels) if item.labels else ""
            table.add_row(
                item.title[:50] + ("..." if len(item.title) > 50 else ""),
                item.type,
                item.priority or "none",
                labels_str
            )

        console.print(table)
        console.print()

    if plan.updates:
        table = Table(title=f"{len(plan.updates)} Work Items to Update")
        table.add_column("Title", style="bold")
        table.add_column("Type", style="cyan")
        table.add_column("Reason", style="yellow")

        for sync_item in plan.updates:
            item = sync_item.item
            table.add_row(
                item.title[:50] + ("..." if len(item.title) > 50 else ""),
                item.type,
                sync_item.reason
            )

        console.print(table)
        console.print()


def display_push_summary(
    result,
    schema_time: float,
    work_time: float,
    work_only: bool,
) -> None:
    """
    Display summary after push command.

    Args:
        result: SyncResult object with created_count, updated_count, failed
        schema_time: Time spent pushing schema
        work_time: Time spent pushing work items
        work_only: Whether schema was skipped
    """
    console.print()

    if schema_time > 0 and not work_only:
        console.print(f"[green][/green] Pushed schema [dim]({format_duration(schema_time)})[/dim]")

    if result.created_count > 0:
        console.print(f"[green][/green] Created {result.created_count} work items")

    if result.updated_count > 0:
        console.print(f"[green][/green] Updated {result.updated_count} work items")

    if result.failed_count > 0:
        console.print(f"[red][/red] {result.failed_count} items failed")
        for item_result in result.failed:
            console.print(f"  [dim]- {item_result.item.item.title[:40]}: {item_result.error}[/dim]")

    total_time = schema_time + work_time
    console.print(f"[dim]  Total time: {format_duration(total_time)}[/dim]")
    console.print()
