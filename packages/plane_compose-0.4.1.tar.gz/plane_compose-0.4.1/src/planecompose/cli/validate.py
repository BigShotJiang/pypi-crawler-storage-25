"""Validate command - validate work items without pushing.

Runs all validation checks (types, states, labels, priority, duplicates,
date formats) and reports issues. Can run with or without a remote
connection (offline mode skips schema validation).
"""
import asyncio
from pathlib import Path

import typer
from rich.table import Table

from planecompose.cli.helpers import (
    console,
    require_project_context,
    create_progress,
    connect_backend,
)
from planecompose.parser.work_yaml import parse_work_items
from planecompose.validation.work_items import validate_work_items, ValidationResult


def validate(
    path: Path | None = typer.Argument(None, help="Path to project directory (default: current directory)"),
    offline: bool = typer.Option(False, "--offline", help="Skip schema validation (no API connection needed)"),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON"),
):
    """
    Validate work items against the schema without pushing.

    Checks types, states, labels, priority values, date formats,
    and duplicate IDs.

    Use --offline to validate without connecting to Plane (skips
    type/state/label checks).

    Examples:
        plane validate                 # Validate current project
        plane validate ./projects/api  # Validate specific project
        plane validate --offline       # Validate without API connection
        plane validate --json          # Machine-readable output
    """
    try:
        asyncio.run(_validate(path, offline, json_output))
    except KeyboardInterrupt:
        console.print("\n[yellow]Cancelled.[/yellow]")
        raise typer.Exit(130)


async def _validate(path: Path | None, offline: bool, json_output: bool):
    """Async implementation of validate."""
    ctx = require_project_context(path, require_auth=not offline)
    backend = None

    try:
        # Parse work items
        all_items = list(parse_work_items(ctx.work_path, ctx.root_path))

        if not all_items:
            if json_output:
                import json
                console.print(json.dumps({"valid": True, "items": 0, "errors": 0, "warnings": 0, "issues": []}))
            else:
                console.print("[yellow]No work items found to validate.[/yellow]")
            return

        cache = None
        if not offline:
            with create_progress() as (progress, task):
                progress.update(task, description="Connecting to Plane...")
                ctx, backend = await connect_backend(ctx, progress=progress, task=task)
                progress.update(task, description="Loading schema...")
                await backend.ensure_schema_loaded()
                cache = backend.get_cache()

        # Run validation
        items = [item_meta.item for item_meta in all_items]
        result = validate_work_items(items, cache)

        if json_output:
            _display_json(result, len(items))
        else:
            _display_rich(result, len(items))

        if not result.is_valid:
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        from planecompose.utils.errors import handle_api_error
        handle_api_error(e, "validate")
        raise typer.Exit(1)
    finally:
        if backend:
            await backend.disconnect()


def _display_json(result: ValidationResult, item_count: int):
    """Output validation result as JSON."""
    import json
    data = {
        "valid": result.is_valid,
        "items": item_count,
        "errors": result.error_count,
        "warnings": result.warning_count,
        "issues": [
            {
                "item": issue.item_title,
                "field": issue.field,
                "message": issue.message,
                "severity": issue.severity,
            }
            for issue in result.issues
        ],
    }
    console.print(json.dumps(data, indent=2))


def _display_rich(result: ValidationResult, item_count: int):
    """Display validation result using Rich tables."""
    console.print(f"\n[bold]Validated {item_count} work items[/bold]\n")

    errors = [i for i in result.issues if i.severity == "error"]
    warnings = [i for i in result.issues if i.severity == "warning"]

    if errors:
        table = Table(title="Errors", show_lines=False)
        table.add_column("Item", style="cyan", max_width=40)
        table.add_column("Field", style="yellow")
        table.add_column("Message", style="red")

        for issue in errors:
            table.add_row(issue.item_title, issue.field, issue.message)

        console.print(table)
        console.print()

    if warnings:
        table = Table(title="Warnings", show_lines=False)
        table.add_column("Item", style="cyan", max_width=40)
        table.add_column("Field", style="yellow")
        table.add_column("Message", style="dim")

        for issue in warnings:
            table.add_row(issue.item_title, issue.field, issue.message)

        console.print(table)
        console.print()

    if result.is_valid:
        if result.warning_count > 0:
            console.print(f"[green]Valid[/green] ({result.warning_count} warnings)")
        else:
            console.print("[green]All checks passed![/green]")
    else:
        console.print(
            f"[red]{result.error_count} error(s)[/red], "
            f"{result.warning_count} warning(s)"
        )
