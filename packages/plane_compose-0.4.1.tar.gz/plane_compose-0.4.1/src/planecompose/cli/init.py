"""Initialize command - creates a new Plane project structure."""

import re
import typer
from pathlib import Path
from rich.console import Console
from rich.prompt import Prompt, Confirm
from planecompose.utils.project import create_gitignore
from planecompose.cli.workspace_utils import resolve_workspace
from planecompose.templates.loader import TemplateLoader
from planecompose.sync.workspace import bootstrap_workspace_yaml
from planecompose.backend.client import PlaneApiClient
from planecompose.parser.members_yaml import write_members_yaml
from planecompose.utils.logger import get_logger

logger = get_logger()

console = Console()


def init(
    project: str | None = typer.Argument(None, help="Project identifier/key (e.g., MYPROJ, API)"),
    workspace: str | None = typer.Option(
        None, "--workspace", "-w", help="Workspace slug (required)"
    ),
    connection: str | None = typer.Option(
        None,
        "--connection",
        "-c",
        help="Connection ID (optional, disambiguates if same slug exists in multiple connections)",
    ),
    path: Path | None = typer.Option(
        None, "--path", help="Parent path for project directory (default: current directory)"
    ),
    template: str | None = typer.Option(
        None, "--template", "-t", help="Template to use (default, local path, or Git URL)"
    ),
):
    """
    Initialize a new Plane project structure.

    Creates a new directory with plane.yaml, schema files, and work directory.
    Project will be created in Plane when you run 'plane schema push'.

    Templates:
        Use --template to specify a template source:
        - Default: plane init (built-in template)
        - Local path: plane init MYPROJ -w myteam --template ./my-templates/template1
        - Git HTTPS: plane init MYPROJ -w myteam --template https://github.com/org/repo/templates/template1
        - Git SSH: plane init MYPROJ -w myteam --template git@github.com:org/repo.git/templates/template1

    Examples:
        plane init MYPROJ -w myteam                               # create project with specific workspace
        plane init MYPROJ -w myteam -c connection-1              # use specific connection
        plane init MYPROJ -w myteam --template ./templates/custom # use custom template
        plane init                                                 # interactive mode (choose workspace + project)
    """
    # If no project provided, go interactive
    if not project and not workspace:
        console.print("\n[bold]Interactive mode:[/bold] Let's set up your project.\n")
        # Fall back to interactive workspace selection
        workspace_slug, resolved_connection_id, server_url, _token = resolve_workspace(
            None, connection, command_hint="plane init"
        )
        project = None  # Will be prompted below
    else:
        # Workspace is required if project is provided
        if not workspace:
            console.print(
                "[red]Error:[/red] Workspace is required. Use: [cyan]plane init <project> -w <workspace>[/cyan]"
            )
            raise typer.Exit(1)

        # Resolve workspace with provided workspace and optional connection
        workspace_slug, resolved_connection_id, server_url, _token = resolve_workspace(
            workspace, connection, command_hint="plane init"
        )

    # Strip protocol for display hints
    server_display = server_url.replace("https://", "").replace("http://", "")

    # Plane API enforces a max identifier length of 10 characters
    MAX_KEY_LENGTH = 10

    def _normalize_key(raw: str) -> str:
        """Strip special chars, uppercase. Returns empty string if nothing left."""
        return re.sub(r"[^A-Z0-9]", "", raw.upper())

    # Project identifier — interactive loop if not supplied as positional argument
    raw_project_input = project  # preserve original for project_name derivation
    project_key = project
    if not project_key:
        console.print()
        console.print("[cyan]Enter a project identifier[/cyan]")
        console.print(
            f"[dim]Uppercase letters and numbers only, max {MAX_KEY_LENGTH} chars (e.g. 'MYPROJ', 'API')[/dim]"
        )
        while True:
            raw = Prompt.ask("  Project identifier").strip()
            normalized = _normalize_key(raw)
            if not normalized:
                console.print(
                    "[yellow]Identifier must contain at least one letter or number.[/yellow]"
                )
                continue
            if len(normalized) > MAX_KEY_LENGTH:
                console.print(
                    f"[yellow]'{normalized}' is {len(normalized)} characters — "
                    f"max is {MAX_KEY_LENGTH}. Please use a shorter key.[/yellow]"
                )
                continue
            raw_project_input = raw
            project_key = normalized
            break
    else:
        # Supplied via --project flag — normalize and validate, fail fast if too long
        normalized = _normalize_key(project_key)
        if not normalized:
            console.print(
                "[red]Project identifier must contain at least one letter or number.[/red]"
            )
            raise typer.Exit(1)
        if len(normalized) > MAX_KEY_LENGTH:
            console.print(
                f"[red]✗[/red] Identifier [bold]{normalized}[/bold] is {len(normalized)} characters "
                f"— Plane allows a maximum of {MAX_KEY_LENGTH}.\n"
                f"  Please use a shorter key, e.g. [cyan]--project TCOMP3[/cyan]"
            )
            raise typer.Exit(1)
        project_key = normalized

    # Derive human-readable project name from the raw input BEFORE stripping.
    # Just title-case it — preserve the user's structure (hyphens, spaces, etc.)
    # e.g. "test-compose-1" → "Test-Compose-1", "test compose 2" → "Test Compose 2"
    project_name = (raw_project_input or project_key).strip().title()
    dir_name = project_key.lower()

    # Determine project directory
    parent_path = (path or Path.cwd()).resolve()
    project_path = parent_path / dir_name

    # Check if directory exists
    if project_path.exists():
        if (project_path / "plane.yaml").exists():
            console.print(f"\n[yellow]Project already exists at {project_path}[/yellow]")
            if not Confirm.ask("Overwrite existing project?"):
                raise typer.Exit(1)
        else:
            console.print(f"\n[yellow]Directory {dir_name}/ already exists[/yellow]")
            if not Confirm.ask("Use this directory?"):
                raise typer.Exit(1)

    console.print(f"\n[bold]Initializing Plane project in {project_path}[/bold]\n")

    # Create directory structure
    project_path.mkdir(parents=True, exist_ok=True)
    schema_dir = project_path / "schema"
    work_dir = project_path / "work"
    schema_dir.mkdir(exist_ok=True)
    work_dir.mkdir(exist_ok=True)
    (project_path / ".plane").mkdir(exist_ok=True)

    # Create plane.yaml (project-specific only, no workspace features)
    template_line = f"template: {template}" if template else "template: default"
    plane_yaml_content = f"""# Plane Project Configuration
# This file contains project-specific settings.
# Edit plane.yaml to change project key, name, or defaults.
# Use 'plane schema push' to sync schema changes to Plane.
# Use 'plane push' to sync schema + work items to Plane.

type: project
workspace: {workspace_slug}
connection: {resolved_connection_id}
project:
  key: {project_key}
  name: {project_name}
  description: ""
  network: public        # public or private
  timezone: UTC          # IANA timezone e.g. Asia/Kolkata, America/New_York

defaults:
  type: Story
  workflow: default

{template_line}
"""
    (project_path / "plane.yaml").write_text(plane_yaml_content)
    console.print("  [green]✓[/green] Created plane.yaml")

    # Fetch workspace features + WITs and write workspace.yaml
    bootstrap_workspace_yaml(
        server_url=server_url,
        api_key=_token,
        connection_id=resolved_connection_id,
        workspace_slug=workspace_slug,
        target_dir=project_path,
    )

    # Load and copy template files
    try:
        template_loader = TemplateLoader()
        template_path = template_loader.load(template)
        template_loader.copy_template_files(template_path, schema_dir, work_dir)
        console.print("  [green]✓[/green] Created schema/types.yaml")
        console.print("  [green]✓[/green] Created schema/states.yaml")
        console.print("  [green]✓[/green] Created schema/workflows.yaml")
        console.print("  [green]✓[/green] Created schema/labels.yaml")
        console.print("  [green]✓[/green] Created work/cycles.yaml")
        console.print("  [green]✓[/green] Created work/modules.yaml")
        console.print("  [green]✓[/green] Created work/workitems.yaml")
    except (ValueError, RuntimeError) as e:
        console.print(f"\n[red]Error loading template:[/red] {str(e)}")
        raise typer.Exit(1)

    # Seed members.yaml with the token owner's identity
    try:
        _client = PlaneApiClient(
            api_url=server_url,
            api_key=_token,
            connection_id=resolved_connection_id,
        )
        me = _client.sdk.users.get_me()
        entry: dict = {}
        if me.id:
            entry["id"] = str(me.id)
        if me.email:
            entry["email"] = me.email
        if me.display_name:
            entry["display_name"] = me.display_name
        # Token owner is the project creator — seed as admin
        entry["role"] = "admin"
        if entry:
            write_members_yaml(project_path, [entry])
        console.print("  [green]✓[/green] Created schema/members.yaml")
    except Exception as e:
        logger.debug(f"Could not fetch token owner identity: {e}")
        # schema/members.yaml already exists from template as [] — that's fine
        console.print("  [green]✓[/green] Created schema/members.yaml")

    # Create .plane/state.json
    state_json = """{
  "last_sync": null,
  "types": {},
  "states": {},
  "workflows": {},
  "labels": {},
  "cycles": {},
  "modules": {},
  "properties": {},
  "work_items": {}
}"""
    (project_path / ".plane" / "state.json").write_text(state_json)
    console.print("  [green]✓[/green] Created .plane/state.json")

    # Create .gitignore
    create_gitignore(project_path)

    # Show next steps
    console.print("\n[bold green]✓ Project initialized successfully![/bold green]\n")
    console.print(f"[bold]Project directory:[/bold] [cyan]{dir_name}/[/cyan]")
    console.print(
        f"[bold]Workspace:[/bold]         [cyan]{workspace_slug}[/cyan] ({server_display})\n"
    )
    console.print("[bold]Next steps:[/bold]")
    console.print(f"  1. [cyan]cd {dir_name}[/cyan]")
    console.print("  2. [cyan]plane schema push[/cyan] - Create project and push schema to Plane")
    console.print("  3. Edit [cyan]work/workitems.yaml[/cyan] - Add work items")
    console.print("  4. Edit [cyan]work/modules.yaml[/cyan] - Add modules")
    console.print("  5. Edit [cyan]work/cycles.yaml[/cyan] - Add cycles")
    console.print("  6. [cyan]plane push[/cyan] - Push work items to Plane")
    console.print("\n[dim]Tip: Customize schema files before pushing![/dim]")
