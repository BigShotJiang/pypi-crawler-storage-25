"""State commands - inspect and manage project sync state.

Provides visibility into the .plane/state.json file that tracks
sync status for types, states, labels, cycles, modules, and work items.

The `show` output uses dotted-path notation that matches exactly what the
`remove` command accepts — copy any line's path and paste it into remove.
"""
import json
import typer
from pathlib import Path
from rich.console import Console
from rich.panel import Panel

from planecompose.state.manager import StateManager

console = Console()

app = typer.Typer(help="Inspect and manage sync state")


# ── Path schema ───────────────────────────────────────────────────────────────
# All project sections are flat one-level: state[section][key]
#
# section:   types | states | labels | cycles | modules | work_items
# key:       name or tracking key (may contain dots, e.g. "In Progress", "id:P103-1")
#
# Path format:   section.key   e.g. "types.Task", "work_items.id:P103-1"
# The schema is authoritative — unknown sections are rejected cleanly.

_SCHEMA_SECTIONS: set[str] = {
    "types", "states", "labels", "cycles", "modules", "work_items",
}


def _resolve_project_path(project: str | None, path: Path | None) -> Path:
    """Resolve the project directory from optional project name + path."""
    if project:
        return (path or Path.cwd()).resolve() / project
    return path.resolve() if path else Path.cwd().resolve()


def _resolve_path(state_dict: dict, path_str: str) -> tuple[dict, str] | None:
    """Resolve a dotted path to (parent_dict, key).

    Returns (parent, key) if found so the caller can do del parent[key].
    Returns None if the path is invalid or the key is not present.

    Path format: section.key  (first dot separates section from key;
    remaining dots are part of the key itself).
    """
    first_dot = path_str.find(".")
    if first_dot == -1:
        return None

    section = path_str[:first_dot]
    key = path_str[first_dot + 1:]

    if section not in _SCHEMA_SECTIONS:
        return None

    # work_items are stored as WorkItemState objects — access raw dict for removal
    parent = state_dict.get(section)
    if not isinstance(parent, dict):
        return None

    if key in parent:
        return parent, key

    return None


def _emit_group(entries: list[tuple[str, str]]) -> None:
    """Print a blank-line-separated group of 'dotted.path = value' lines."""
    if not entries:
        return
    console.print()
    for path, value in entries:
        console.print(f"  [cyan]{path}[/cyan] = [dim]{value}[/dim]")


# ─────────────────────────────────────────────────────────────────────────────


@app.command("show")
def show(
    project: str | None = typer.Argument(
        None,
        help="Project folder name (e.g. testcompose1). Optional when run from inside the project directory.",
    ),
    path: Path | None = typer.Option(
        None, "--path", help="Parent directory containing the project (default: current directory)"
    ),
    json_output: bool = typer.Option(False, "--json", help="Output raw state.json"),
):
    """
    Show sync state as copyable dotted paths.

    Each line is   dotted.path = value
    Copy any path and pass it directly to 'plane state remove'.

    Examples:
        plane state show                              # Run from inside project directory
        plane state show test1                        # Show test1 in current directory
        plane state show test1 --path ./projects      # Show ./projects/test1
        plane state show --path ./projects/test1      # Explicit full path
        plane state show --json                       # Raw JSON
    """
    try:
        project_path = _resolve_project_path(project, path)
        manager = StateManager(project_path)

        if not manager.exists():
            console.print("[yellow]No state file found.[/yellow]")
            console.print("Run [cyan]plane clone[/cyan] or [cyan]plane push[/cyan] to initialize state.")
            return

        state = manager.load()

        if json_output:
            console.print(json.dumps(state.model_dump(), indent=2, default=str))
            return

        state_file = project_path / ".plane" / "state.json"
        console.print()
        console.print(
            Panel(
                f"[bold]File:[/bold] {state_file}\n"
                f"[bold]Last Sync:[/bold] {state.last_sync or 'never'}",
                title="[bold]Project Sync State[/bold]",
                border_style="blue",
            )
        )

        # types.*
        _emit_group([
            (f"types.{name}", str(rid))
            for name, rid in state.types.items()
        ])

        # states.*
        _emit_group([
            (f"states.{name}", str(rid))
            for name, rid in state.states.items()
        ])

        # labels.*
        _emit_group([
            (f"labels.{name}", str(rid))
            for name, rid in state.labels.items()
        ])

        # cycles.*
        _emit_group([
            (f"cycles.{name}", str(rid))
            for name, rid in state.cycles.items()
        ])

        # modules.*
        _emit_group([
            (f"modules.{name}", str(rid))
            for name, rid in state.modules.items()
        ])

        # work_items.* — show tracking key → remote_id
        _emit_group([
            (f"work_items.{key}", str(item.remote_id))
            for key, item in state.work_items.items()
        ])

        console.print()

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command("remove")
def remove(
    path_str: str = typer.Argument(
        ...,
        help="Dotted path as shown by 'plane state show', e.g. 'types.Task', 'states.In Progress', 'work_items.id:P103-1'",
    ),
    project: str | None = typer.Option(
        None, "--project", "-p",
        help="Project folder name. Optional when run from inside the project directory.",
    ),
    path: Path | None = typer.Option(
        None, "--path",
        help="Parent directory containing the project (default: current directory)",
    ),
):
    """
    Remove a specific entry from state tracking.

    Use the exact dotted path shown by 'plane state show' — copy and paste.

    Supports removing:
      types.Task
      states.In Progress
      labels.Frontend
      cycles.Sprint 1
      modules.Auth
      work_items.id:P103-1

    Examples:
        plane state remove "types.Task"
        plane state remove "states.In Progress"
        plane state remove "labels.Frontend"
        plane state remove "cycles.Sprint 1"
        plane state remove "modules.Auth"
        plane state remove "work_items.id:P103-1"
        plane state remove "types.Task" --project test1
        plane state remove "labels.Bug" --path ./projects/test1
    """
    try:
        project_path = _resolve_project_path(project, path)
        manager = StateManager(project_path)

        if not manager.exists():
            console.print("[yellow]No state file found.[/yellow]")
            raise typer.Exit(1)

        # Load raw dict for path resolver (model_dump gives us plain dicts)
        state = manager.load()
        state_dict = state.model_dump()

        # Normalize work_items: model_dump returns WorkItemState dicts, not str values.
        # We need the resolver to find them, then we'll delete from the live state.
        result = _resolve_path(state_dict, path_str)
        if result is None:
            console.print(f"[yellow]Not found:[/yellow] {path_str}")
            console.print(
                "Run [cyan]plane state show[/cyan] to see valid paths."
            )
            raise typer.Exit(1)

        # Perform the deletion on the live state object (not the dumped dict)
        section = path_str[:path_str.find(".")]
        key = path_str[path_str.find(".") + 1:]

        with manager.lock():
            state = manager.load()
            section_obj = getattr(state, section, None)
            if section_obj is None or key not in section_obj:
                console.print(f"[yellow]Not found:[/yellow] {path_str}")
                raise typer.Exit(1)
            del section_obj[key]
            manager.save(state)

        console.print(f"[green]Removed:[/green] {path_str}")

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command("reset")
def reset(
    project: str | None = typer.Argument(
        None,
        help="Project folder name (e.g. testcompose1). Optional when run from inside the project directory.",
    ),
    path: Path | None = typer.Option(
        None, "--path", help="Parent directory containing the project (default: current directory)"
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Reset without confirmation"),
):
    """
    Reset sync state (delete state file).

    This will cause the next push to treat all items as new.
    Use with caution — may cause duplicate items if remote already has data.

    Examples:
        plane state reset                              # Run from inside project directory
        plane state reset test1                        # Reset test1 in current directory
        plane state reset test1 --path ./projects      # Reset ./projects/test1
        plane state reset --path ./projects/test1      # Explicit full path
    """
    project_path = _resolve_project_path(project, path)
    manager = StateManager(project_path)

    if not manager.exists():
        console.print("[yellow]No state file to reset.[/yellow]")
        return

    if not force:
        from rich.prompt import Confirm

        state = manager.load()
        console.print("\n[yellow]Warning:[/yellow] This will delete tracking for:")
        console.print(f"  - {len(state.types)} types")
        console.print(f"  - {len(state.states)} states")
        console.print(f"  - {len(state.labels)} labels")
        console.print(f"  - {len(state.cycles)} cycles")
        console.print(f"  - {len(state.modules)} modules")
        console.print(f"  - {len(state.work_items)} work items")
        console.print()
        console.print("[yellow]The next push may create duplicates if items already exist in Plane.[/yellow]")
        console.print()

        if not Confirm.ask("Are you sure you want to reset state?"):
            console.print("[yellow]Cancelled[/yellow]")
            raise typer.Exit(0)

    manager.reset()
    console.print("[green]State reset successfully.[/green]")
    console.print("Next push will treat all items as new.")


@app.command("clear-items")
def clear_items(
    project: str | None = typer.Argument(
        None,
        help="Project folder name (e.g. testcompose1). Optional when run from inside the project directory.",
    ),
    path: Path | None = typer.Option(
        None, "--path", help="Parent directory containing the project (default: current directory)"
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Clear without confirmation"),
):
    """
    Clear only work item tracking (keep schema mappings).

    Preserves type/state/label/cycle/module mappings but resets work item tracking.
    Useful when you want to re-sync work items without recreating schema.

    Examples:
        plane state clear-items                              # Run from inside project directory
        plane state clear-items test1                        # Clear test1 in current directory
        plane state clear-items test1 --path ./projects      # Clear ./projects/test1
        plane state clear-items --path ./projects/test1      # Explicit full path
    """
    project_path = _resolve_project_path(project, path)
    manager = StateManager(project_path)

    if not manager.exists():
        console.print("[yellow]No state file found.[/yellow]")
        return

    state = manager.load()

    if not state.work_items:
        console.print("[yellow]No work items to clear.[/yellow]")
        return

    if not force:
        from rich.prompt import Confirm
        if not Confirm.ask(f"Clear tracking for {len(state.work_items)} work items?"):
            console.print("[yellow]Cancelled[/yellow]")
            raise typer.Exit(0)

    with manager.lock():
        state = manager.load()
        state.work_items.clear()
        manager.save(state)

    console.print("[green]Work item tracking cleared.[/green]")
    console.print("Schema mappings preserved. Next push will re-sync work items.")
