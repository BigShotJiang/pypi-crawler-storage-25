"""Schema management commands."""

import asyncio
from pathlib import Path
from typing import Any, cast

import typer
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from planecompose.cli.display import display_create_table
from planecompose.cli.helpers import (
    build_schema_maps,
    compare_schema_items,
    connect_backend,
    console,
    create_progress,
    detect_workflow_changes,
    display_failed_items,
    fetch_remote_schema,
    find_schema_changes,
    print_schema_section,
    require_project_context,
)
from planecompose.cli.sync_helpers import sync_workspace_context
from planecompose.utils.logger import get_logger

logger = get_logger()

app = typer.Typer(help="Schema management commands")


# ============================================================================
# CLI Commands - User-facing Interface
# ============================================================================


@app.command()
def validate(
    project: str | None = typer.Argument(
        None, help="Project folder name. Combined with --path if provided."
    ),
    path: Path | None = typer.Option(
        None, "--path", help="Parent directory containing the project (default: current directory)"
    ),
):
    """
    Validate local schema files without connecting to Plane.

    Examples:
        plane schema validate                 # Validate current directory
        plane schema validate ./projects/api  # Validate specific project
    """
    resolved_path = (
        (path or Path.cwd()).resolve() / project if project else (path.resolve() if path else None)
    )
    try:
        result = _validate_schema(resolved_path)
        _display_validation_result(result)

        if not result["valid"]:
            raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"\n[red]✗ Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def push(
    project: str | None = typer.Argument(
        None, help="Project folder name. Combined with --path if provided."
    ),
    path: Path | None = typer.Option(
        None, "--path", help="Parent directory containing the project (default: current directory)"
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", "-n", help="Show what would be pushed without making changes"
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Push without confirmation"),
):
    """
    Push schema to Plane.

    Creates the project if it doesn't exist, then pushes types, states, and labels.

    Examples:
        plane schema push                              # Push current directory
        plane schema push tcomp1                      # Push cwd/tcomp1
        plane schema push tcomp1 --path ./projects    # Push ./projects/tcomp1
    """
    resolved_path = (
        (path or Path.cwd()).resolve() / project if project else (path.resolve() if path else None)
    )
    try:
        asyncio.run(_push_schema(dry_run, force, resolved_path))
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled.[/yellow]")
        raise typer.Exit(130)


# ============================================================================
# Validation Helpers
# ============================================================================


def _validate_schema(path: Path | None = None) -> dict:
    """
    Validate schema by attempting to load all schema files.

    Returns dict with structure:
    {
        'valid': bool,
        'types': {'count': int, 'error': str | None},
        'states': {'count': int, 'error': str | None},
        'labels': {'count': int, 'error': str | None},
        'modules': {'count': int, 'error': str | None},
        'cycles': {'count': int, 'error': str | None},
    }
    """
    from planecompose.config.context import load_project_context

    result: dict[str, Any] = {
        "valid": True,
        "types": {"count": 0, "error": None},
        "states": {"count": 0, "error": None},
        "labels": {"count": 0, "error": None},
        "modules": {"count": 0, "error": None},
        "cycles": {"count": 0, "error": None},
    }

    try:
        ctx = load_project_context(path, require_auth=False)

        # All loaded successfully
        result["types"]["count"] = len(ctx.types)
        result["states"]["count"] = len(ctx.states)
        result["labels"]["count"] = len(ctx.labels)
        result["modules"]["count"] = len(ctx.modules)
        result["cycles"]["count"] = len(ctx.cycles)
        result["valid"] = True

    except Exception as e:
        # Context loading failed - try to load individual schemas to pinpoint errors
        result["valid"] = False

        schema_dir = None
        try:
            from planecompose.config.context import load_project_context

            ctx = load_project_context(path, require_auth=False)
        except Exception:
            # Try to get schema_dir from plane.yaml
            from planecompose.config.context import DIR_SCHEMA, load_project_context

            try:
                root_path = path or Path.cwd()
                schema_dir = (
                    root_path / DIR_SCHEMA
                    if not path or not (path / DIR_SCHEMA).exists()
                    else path / DIR_SCHEMA
                )
            except Exception:
                schema_dir = None

        # Try to load each schema individually to see which ones fail
        if schema_dir and schema_dir.exists():
            _validate_individual_schemas(result, schema_dir)
        else:
            # Fall back to letting the error propagate
            result["types"]["error"] = str(e)

    return result


def _validate_individual_schemas(result: dict, schema_dir: Path) -> None:
    """Try to load each schema file individually to find errors."""
    from pydantic import ValidationError

    from planecompose.constants import FILE_LABELS_YAML, FILE_TYPES_YAML, FILE_WORKFLOWS_YAML
    from planecompose.parser.labels_yaml import parse_labels_yaml
    from planecompose.parser.types_yaml import parse_types_yaml
    from planecompose.parser.workflows_yaml import parse_workflows_yaml

    # Try types
    try:
        types = parse_types_yaml(schema_dir / FILE_TYPES_YAML)
        result["types"]["count"] = len(types)
    except Exception as e:
        result["types"]["error"] = str(e)

    # Try workflows (which include states)
    try:
        workflows = parse_workflows_yaml(schema_dir / FILE_WORKFLOWS_YAML)
        states_count = sum(len(w.states) for w in workflows)
        result["states"]["count"] = states_count
    except Exception as e:
        result["states"]["error"] = str(e)

    # Try labels
    try:
        labels = parse_labels_yaml(schema_dir / FILE_LABELS_YAML)
        result["labels"]["count"] = len(labels)
    except Exception as e:
        result["labels"]["error"] = str(e)

    # Try modules
    try:
        import yaml

        work_dir = schema_dir.parent / "work"
        modules_file = (work_dir / "modules.yaml") if (work_dir / "modules.yaml").exists() else (schema_dir / "modules.yaml")
        if modules_file.exists():
            from planecompose.core.models import ModuleDefinition

            content = yaml.safe_load(modules_file.read_text())
            # Extract from root key if present (new format: modules: [...])
            if isinstance(content, dict) and 'modules' in content and len(content) == 1:
                content = content['modules']
            modules = []
            if isinstance(content, list):
                for idx, m in enumerate(content):
                    if isinstance(m, dict):
                        try:
                            # 'id' in YAML is the remote UUID (written by schema_writer/clone_helpers)
                            # map it to the model field name before Pydantic sees it
                            if "id" in m and "remote_id" not in m:
                                m = dict(m)
                                m["remote_id"] = m.pop("id")
                            modules.append(ModuleDefinition(**m))
                        except ValidationError as e:
                            if not result["modules"]["error"]:  # Only set first error
                                errors_by_msg: dict[str, list[str]] = {}
                                for error in e.errors():
                                    field = str(error["loc"][0])
                                    msg = error["msg"]
                                    if msg not in errors_by_msg:
                                        errors_by_msg[msg] = []
                                    errors_by_msg[msg].append(field)
                                error_strs = [
                                    f"[{msg}] {', '.join(fields)}"
                                    for msg, fields in errors_by_msg.items()
                                ]
                                result["modules"]["error"] = f"Index {idx}: " + " | ".join(
                                    error_strs
                                )
            result["modules"]["count"] = len(modules) if not result["modules"]["error"] else 0
    except Exception as e:
        result["modules"]["error"] = str(e)

    # Try cycles
    try:
        import yaml

        work_dir_c = schema_dir.parent / "work"
        cycles_file = (work_dir_c / "cycles.yaml") if (work_dir_c / "cycles.yaml").exists() else (schema_dir / "cycles.yaml")
        if cycles_file.exists():
            from planecompose.core.models import CycleDefinition

            content = yaml.safe_load(cycles_file.read_text())
            # Extract from root key if present (new format: cycles: [...])
            if isinstance(content, dict) and 'cycles' in content and len(content) == 1:
                content = content['cycles']
            cycles = []
            if isinstance(content, list):
                for idx, c in enumerate(content):
                    if isinstance(c, dict):
                        try:
                            # 'id' in YAML is the remote UUID — map to model field name
                            if "id" in c and "remote_id" not in c:
                                c = dict(c)
                                c["remote_id"] = c.pop("id")
                            cycles.append(CycleDefinition(**c))
                        except ValidationError as e:
                            if not result["cycles"]["error"]:  # Only set first error
                                errors_by_msg_c: dict[str, list[str]] = {}
                                for error in e.errors():
                                    field = str(error["loc"][0])
                                    msg = error["msg"]
                                    if msg not in errors_by_msg_c:
                                        errors_by_msg_c[msg] = []
                                    errors_by_msg_c[msg].append(field)
                                error_strs = [
                                    f"[{msg}] {', '.join(fields)}"
                                    for msg, fields in errors_by_msg_c.items()
                                ]
                                result["cycles"]["error"] = f"Index {idx}: " + " | ".join(
                                    error_strs
                                )
            result["cycles"]["count"] = len(cycles) if not result["cycles"]["error"] else 0
    except Exception as e:
        result["cycles"]["error"] = str(e)


def _display_validation_result(result: dict) -> None:
    """Display validation result with Rich formatting."""
    console.print()

    if result["valid"]:
        # Success case
        console.print("[green]✓ Schema is valid![/green]\n")
        console.print(f"  [cyan]Types:[/cyan] {result['types']['count']}")
        console.print(f"  [cyan]States:[/cyan] {result['states']['count']}")
        console.print(f"  [cyan]Labels:[/cyan] {result['labels']['count']}")
        console.print(f"  [cyan]Modules:[/cyan] {result['modules']['count']}")
        console.print(f"  [cyan]Cycles:[/cyan] {result['cycles']['count']}")
        console.print()
    else:
        # Error case - show what's valid and what's invalid
        console.print("[red]✗ Schema validation failed[/red]\n")

        # Create table for overview
        table = Table(title="Schema Status", show_header=True, header_style="bold cyan")
        table.add_column("Component", style="cyan")
        table.add_column("Status", justify="center")
        table.add_column("Count", style="green")

        for component in ["types", "states", "labels", "modules", "cycles"]:
            data = result[component]
            if data["error"]:
                status = "[red]✗[/red]"
                # Count number of errors (rough estimate from semicolon count + 1, or just "Error")
                details = "[yellow]Error[/yellow]"
            else:
                status = "[green]✓[/green]"
                details = str(data["count"])

            table.add_row(component.capitalize(), status, details)

        console.print(table)
        console.print()

        # Show detailed errors below the table
        has_errors = False
        for component in ["types", "states", "labels", "modules", "cycles"]:
            data = result[component]
            if data["error"]:
                has_errors = True
                console.print(f"[bold]{component.capitalize()}:[/bold]")
                console.print(f"  [red]{data['error']}[/red]")
                console.print()

        if not has_errors:
            console.print("[green]✓ No errors found[/green]\n")


# ============================================================================
# Schema helpers
# ============================================================================


def _normalize_value(val):
    """Normalize values for comparison (treat None and empty string as equivalent)."""
    if val is None or val == "":
        return None
    return val


def _item_changed(local_item, remote_item) -> bool:
    """Check if a local schema item differs from its remote counterpart.

    Returns True if any significant attribute has changed (color, group, description).
    Returns False if all attributes match (no update needed).

    Handles None vs empty string normalization for safe comparison.
    """
    # Compare color (normalize empty/None and case)
    local_color = _normalize_value(getattr(local_item, "color", None))
    remote_color = _normalize_value(getattr(remote_item, "color", None))
    # Normalize hex colors to lowercase for case-insensitive comparison
    if local_color and isinstance(local_color, str):
        local_color = local_color.lower()
    if remote_color and isinstance(remote_color, str):
        remote_color = remote_color.lower()
    if local_color != remote_color:
        return True

    # Compare group (for states)
    local_group = _normalize_value(getattr(local_item, "group", None))
    remote_group = _normalize_value(getattr(remote_item, "group", None))
    if local_group != remote_group:
        return True

    # Compare description (normalize empty/None)
    local_desc = _normalize_value(getattr(local_item, "description", None))
    remote_desc = _normalize_value(getattr(remote_item, "description", None))
    if local_desc != remote_desc:
        return True

    # Compare properties (for types)
    local_props = getattr(local_item, "properties", None)
    remote_props = getattr(remote_item, "properties", None)
    if local_props != remote_props:
        return True

    # Compare workflow (for types)
    local_wf = getattr(local_item, "workflow", None)
    remote_wf = getattr(remote_item, "workflow", None)
    if local_wf != remote_wf:
        return True

    # Compare work_item_types (for workflows) — order-insensitive set comparison.
    # Only meaningful when the attribute exists on both sides; absent on non-workflow types.
    if hasattr(local_item, "work_item_types") or hasattr(remote_item, "work_item_types"):
        local_wits = set(getattr(local_item, "work_item_types", None) or [])
        remote_wits = set(getattr(remote_item, "work_item_types", None) or [])
        if local_wits != remote_wits:
            return True

    # Compare is_active (for workflows)
    if hasattr(local_item, "is_active") or hasattr(remote_item, "is_active"):
        local_active = getattr(local_item, "is_active", None)
        remote_active = getattr(remote_item, "is_active", None)
        if local_active != remote_active:
            return True

    # Compare is_default (for workflows and states)
    if hasattr(local_item, "is_default") or hasattr(remote_item, "is_default"):
        local_default = getattr(local_item, "is_default", None)
        remote_default = getattr(remote_item, "is_default", None)
        if local_default != remote_default:
            return True

    # Compare workflow states set (only applicable to WorkflowDefinition).
    # States are a list of StateDefinition — compare by name (order-insensitive).
    # This ensures workflows with only state-list changes still land in
    # workflows_to_update so attach/detach logic can run.
    if hasattr(local_item, "states") and hasattr(remote_item, "states"):
        try:
            local_state_names = {s.name for s in (getattr(local_item, "states", None) or [])}
            remote_state_names = {s.name for s in (getattr(remote_item, "states", None) or [])}
            if local_state_names != remote_state_names:
                return True
        except (TypeError, AttributeError):
            pass

    # Compare workflow transitions (only applicable to WorkflowDefinition).
    # Each StateDefinition carries its outgoing transitions; signature a
    # transition by (from_state_name, to_state_name, type) — order-insensitive.
    # Also include pre/post rule conditions so condition-only changes land in
    # workflows_to_update and get pushed via _sync_workflow_transitions().
    if hasattr(local_item, "states") and hasattr(remote_item, "states"):
        try:

            def _transition_sig(item):
                sigs: set[tuple] = set()
                for st in getattr(item, "states", None) or []:
                    for t in getattr(st, "transitions", None) or []:
                        pre = frozenset(
                            (getattr(r, "handler", ""), getattr(r, "script_id", ""))
                            for r in (getattr(t, "pre_rules", None) or [])
                        )
                        post = frozenset(
                            (getattr(r, "handler", ""), getattr(r, "script_id", ""))
                            for r in (getattr(t, "post_rules", None) or [])
                        )
                        sigs.add((st.name, getattr(t, "to", ""), getattr(t, "type", "transition"), pre, post))
                return sigs

            if _transition_sig(local_item) != _transition_sig(remote_item):
                return True
        except (TypeError, AttributeError):
            pass

    return False


def _split_create_update(local_items, remote_items, remote_by_id: dict):
    """Split local schema items into (to_create, to_update).

    - If local item has remote_id and it exists in remote:
      - If attributes match remote → skip (no update needed)
      - If attributes differ → UPDATE bucket
    - If local item name already exists in remote (no id) → skip (already exists).
    - Otherwise → CREATE bucket.
    """
    remote_names_lower = {r.name.lower() for r in remote_items}
    to_create = []
    to_update = []
    for item in local_items:
        if item.remote_id and item.remote_id in remote_by_id:
            # Item exists on remote - check if it actually changed
            remote_item = remote_by_id[item.remote_id]
            if _item_changed(item, remote_item):
                to_update.append(item)
            # else: no changes, skip
        elif item.name.lower() not in remote_names_lower:
            to_create.append(item)
        # else: name exists remotely but no id — already in sync, skip
    return to_create, to_update


async def _import_workspace_types(
    backend, workspace_slug: str, project_id: str, types_to_import: list, workspace_config
) -> tuple[int, list]:
    """Import workspace-level work item types into a project.

    Args:
        backend: PlaneBackend instance
        workspace_slug: Workspace slug
        project_id: Project UUID
        types_to_import: List of WorkItemTypeDefinition to import
        workspace_config: WorkspaceConfig with workspace types

    Returns:
        Tuple of (successfully_imported_count, failed_imports_list)
    """
    if not types_to_import or not workspace_config or not workspace_config.work_item_types:
        return 0, []

    # Build map of workspace type names to IDs
    workspace_types_by_name = {
        wit.get("name"): wit.get("id")
        for wit in workspace_config.work_item_types
        if wit.get("name") and wit.get("id")
    }

    # Match project types with workspace types by name
    workspace_type_ids = []
    failed = []
    for type_def in types_to_import:
        workspace_type_id = workspace_types_by_name.get(type_def.name)
        if workspace_type_id:
            workspace_type_ids.append(workspace_type_id)
            # Populate ws_workitemtype_id for future reference
            type_def.ws_workitemtype_id = workspace_type_id
        else:
            failed.append((type_def.name, "No matching workspace work item type found"))

    if not workspace_type_ids:
        return 0, failed

    # Call the import API endpoint
    try:
        await backend.import_workspace_types(workspace_slug, project_id, workspace_type_ids)
        logger.info(f"✓ Imported {len(workspace_type_ids)} workspace work item types")
        return len(workspace_type_ids), failed
    except Exception as e:
        logger.error(f"Failed to import workspace work item types: {e}")
        # Mark all matched types as failed
        for workspace_type_id in workspace_type_ids:
            # Find the type name for error reporting
            for wit in workspace_config.work_item_types:
                if wit.get("id") == workspace_type_id:
                    failed.append((wit.get("name", "Unknown"), str(e)))
                    break
        return 0, failed


def _rules_to_api(rules, rule_type: str) -> list[dict]:
    """Convert a list of RuleDefinition objects to the API write format.

    The API expects:
        {"handler_name": "run_script", "rule_type": "validation|action",
         "config": {"script_id": "<uuid>", "execution_variables": {}}}

    Rules without a script_id are skipped (the API will reject them).

    Args:
        rules: List of RuleDefinition objects.
        rule_type: "validation" for pre_rules, "action" for post_rules.
    """
    result: list[dict] = []
    for rule in rules:
        script_id = getattr(rule, "script_id", "") or ""
        if not script_id:
            logger.debug(
                f"Skipping rule with handler '{rule.handler}' — no script_id "
                f"(scripts must be created in Plane UI first)"
            )
            continue
        config = dict(getattr(rule, "config", {}) or {})
        config["script_id"] = script_id
        # Ensure execution_variables is a dict (API rejects None or missing)
        config["execution_variables"] = config.get("execution_variables") or {}
        result.append({
            "handler_name": getattr(rule, "handler", "run_script") or "run_script",
            "rule_type": rule_type,
            "config": config,
        })
    return result


async def _sync_workflow_transitions(
    backend,
    local_wf,
    remote_wf,
    state_name_to_id: dict,
    email_to_user_id: dict | None = None,
) -> None:
    """Push transitions defined on a local workflow to remote.

    For each (from_state → to_state, type) tuple that's present locally but
    not on remote, POST a new transition (with conditions if any).
    Duplicates are handled server-side (`create_workflow_transition` treats
    "already exists" as a no-op).

    For transitions that already exist on remote but have different conditions,
    PATCH them via `update_workflow_transition`.

    Approver emails stored in the local TransitionDefinition are converted to
    user UUIDs via ``email_to_user_id`` before being sent as ``member_ids``.

    Args:
        backend: Active plane backend instance (must have remote_id for wf).
        local_wf: Local WorkflowDefinition with states[].transitions populated.
        remote_wf: Matching remote WorkflowDefinition (or None if just created).
        state_name_to_id: Project-state name → UUID mapping.
        email_to_user_id: Optional email → user UUID mapping for resolving approvers.
    """
    if not local_wf or not local_wf.remote_id:
        return

    def _sigs(wf) -> set[tuple[str, str, str]]:
        sigs: set[tuple[str, str, str]] = set()
        if not wf:
            return sigs
        for st in getattr(wf, "states", None) or []:
            for t in getattr(st, "transitions", None) or []:
                sigs.add((st.name, getattr(t, "to", ""), getattr(t, "type", "transition")))
        return sigs

    def _rule_sig(rules) -> frozenset:
        return frozenset(
            (getattr(r, "handler", ""), getattr(r, "script_id", ""))
            for r in (rules or [])
        )

    # Build local lookups: (from_state, to_state) → TransitionDefinition
    local_trans_by_edge: dict[tuple[str, str], object] = {}
    for st in getattr(local_wf, "states", None) or []:
        for t in getattr(st, "transitions", None) or []:
            local_trans_by_edge[(st.name, getattr(t, "to", ""))] = t

    # Build remote lookups: (from_state, to_state) → TransitionDefinition
    # (includes remote_id for PATCH calls)
    remote_trans_by_edge: dict[tuple[str, str], object] = {}
    for st in getattr(remote_wf, "states", None) or []:
        for t in getattr(st, "transitions", None) or []:
            remote_trans_by_edge[(st.name, getattr(t, "to", ""))] = t

    local_sigs = _sigs(local_wf)
    remote_sigs = _sigs(remote_wf)
    to_add = local_sigs - remote_sigs

    # --- Step 1: Create new transitions (local-only) ---
    for from_name, to_name, ttype in to_add:
        from_id = state_name_to_id.get(from_name)
        to_id = state_name_to_id.get(to_name)
        if not from_id or not to_id:
            logger.warning(
                f"Skipping transition {from_name}→{to_name} on workflow "
                f"'{local_wf.name}': could not resolve state UUIDs"
            )
            continue

        # Resolve approver emails → UUIDs for this specific transition.
        approver_ids: list[str] | None = None
        local_trans = local_trans_by_edge.get((from_name, to_name))
        if local_trans and email_to_user_id:
            raw_approvers = getattr(local_trans, "approvers", None) or []
            resolved: list[str] = []
            for approver in raw_approvers:
                uid = email_to_user_id.get(approver)
                if uid:
                    resolved.append(uid)
                else:
                    logger.warning(
                        f"Approver '{approver}' on transition {from_name}→{to_name} "
                        f"in workflow '{local_wf.name}' not found in project members — skipped"
                    )
            if resolved:
                approver_ids = resolved

        # Include conditions (pre/post rules) on new transitions.
        pre_api: list[dict] | None = None
        post_api: list[dict] | None = None
        if local_trans:
            pre_api = _rules_to_api(getattr(local_trans, "pre_rules", []) or [], "validation") or None
            post_api = _rules_to_api(getattr(local_trans, "post_rules", []) or [], "action") or None

        try:
            await backend.create_workflow_transition(
                workflow_id=local_wf.remote_id,
                from_state_id=str(from_id),
                to_state_id=str(to_id),
                transition_type=ttype or "transition",
                approver_user_ids=approver_ids,
                pre_rules=pre_api,
                post_rules=post_api,
            )
        except Exception as e:
            logger.error(
                f"Failed to create transition {from_name}→{to_name} on workflow "
                f"'{local_wf.name}': {e}"
            )

    # --- Step 2: PATCH conditions on existing transitions that changed ---
    # Only runs when remote_wf is available (i.e. not a freshly-created workflow).
    if remote_wf:
        common_edges = {(f, t) for f, t, _ in local_sigs} & {(f, t) for f, t, _ in remote_sigs}
        for edge in common_edges:
            local_t = local_trans_by_edge.get(edge)
            remote_t = remote_trans_by_edge.get(edge)
            if not local_t or not remote_t:
                continue

            trans_id = getattr(remote_t, "remote_id", None)
            if not trans_id:
                logger.debug(
                    f"No remote_id for transition {edge[0]}→{edge[1]} on workflow "
                    f"'{local_wf.name}' — cannot push condition changes"
                )
                continue

            local_pre_sig = _rule_sig(getattr(local_t, "pre_rules", []))
            remote_pre_sig = _rule_sig(getattr(remote_t, "pre_rules", []))
            local_post_sig = _rule_sig(getattr(local_t, "post_rules", []))
            remote_post_sig = _rule_sig(getattr(remote_t, "post_rules", []))

            if local_pre_sig == remote_pre_sig and local_post_sig == remote_post_sig:
                continue  # Conditions unchanged

            pre_api = _rules_to_api(getattr(local_t, "pre_rules", []) or [], "validation")
            post_api = _rules_to_api(getattr(local_t, "post_rules", []) or [], "action")

            try:
                await backend.update_workflow_transition(
                    workflow_id=local_wf.remote_id,
                    transition_id=trans_id,
                    pre_rules=pre_api,
                    post_rules=post_api,
                )
                logger.info(
                    f"Updated conditions on transition {edge[0]}→{edge[1]} "
                    f"of workflow '{local_wf.name}'"
                )
            except Exception as e:
                logger.error(
                    f"Failed to update conditions on transition {edge[0]}→{edge[1]} "
                    f"of workflow '{local_wf.name}': {e}"
                )


async def _merge_remote_additions(ctx, backend) -> None:
    """Pull any server-side additions back into ctx so push is self-contained.

    Run at the end of `_push_schema`, just before `_rebuild_schema` writes the
    yaml files. Additive only — does NOT remove anything from local or
    overwrite local attributes on items already present by name. The common
    case this handles is the Default Workflow (and its states) that Plane
    auto-creates when the workflows feature is first enabled on a project.

    Currently refreshes states and workflows. Types/labels already cover
    their needs during the push loop itself (remote_id backfill).
    """
    # --- States ---
    try:
        remote_states = await backend.list_states()
    except Exception as e:
        logger.debug(f"Could not list remote states for post-push refresh: {e}")
        remote_states = []

    if remote_states:
        local_state_names = {s.name.lower() for s in ctx.states}
        for rs in remote_states:
            if not rs or not rs.name:
                continue
            if rs.name.lower() not in local_state_names:
                # New remote state — add a local entry so it lands in
                # states.yaml on the subsequent rebuild.
                ctx.states.append(rs)
                local_state_names.add(rs.name.lower())
            else:
                # Backfill remote_id on existing local entry if it was
                # missing (e.g., state matched by name during the push
                # split but remote_id wasn't propagated).
                for ls in ctx.states:
                    if ls.name.lower() == rs.name.lower() and not ls.remote_id and rs.remote_id:
                        ls.remote_id = rs.remote_id
                        break

    # --- Workflows ---
    try:
        remote_workflows = await backend.fetch_workflows()
    except Exception as e:
        logger.debug(f"Could not fetch remote workflows for post-push refresh: {e}")
        remote_workflows = []

    if remote_workflows:
        local_workflow_names = {w.name.lower() for w in ctx.workflows}
        for rw in remote_workflows:
            if not rw or not rw.name:
                continue
            if rw.name.lower() not in local_workflow_names:
                ctx.workflows.append(rw)
                local_workflow_names.add(rw.name.lower())
            else:
                # Backfill remote_id + any missing states on the local entry.
                for lw in ctx.workflows:
                    if lw.name.lower() != rw.name.lower():
                        continue
                    if not lw.remote_id and rw.remote_id:
                        lw.remote_id = rw.remote_id
                    # Union workflow.states (by name) — preserves any inline
                    # transition info on the local side while adding states
                    # the remote says belong to this workflow.
                    if rw.states:
                        local_state_set = {s.name.lower() for s in (lw.states or [])}
                        for rs in rw.states:
                            if rs.name and rs.name.lower() not in local_state_set:
                                lw.states.append(rs)
                                local_state_set.add(rs.name.lower())
                    break


def _rebuild_schema(ctx) -> None:
    """Rewrite schema YAML files with remote IDs baked in.

    Detects enterprise mode based on workspace configuration:
    - If workspace has work_item_types feature enabled, writes minimal types.yaml format
    - Otherwise, writes full types.yaml format with all fields
    """
    from planecompose.parser.schema_writer import rebuild_schema_files

    # Detect enterprise mode: workspace has work_item_types feature enabled AND has workspace work item types
    enterprise_mode = (
        ctx.workspace_config
        and ctx.workspace_config.workspace_features
        and ctx.workspace_config.workspace_features.get("work_item_types", False)
        and ctx.workspace_config.work_item_types is not None
        and len(ctx.workspace_config.work_item_types) > 0
    )

    rebuild_schema_files(
        schema_dir=ctx.schema_path,
        types=ctx.types,
        workflows=ctx.workflows,
        labels=ctx.labels,
        modules=ctx.modules,
        cycles=ctx.cycles,
        enterprise_mode=enterprise_mode,
        states=ctx.states,
    )
    console.print("[dim]  Schema files rebuilt with remote IDs.[/dim]")


# ============================================================================
# Async Implementations - Business Logic
# ============================================================================


async def _push_schema(dry_run: bool, force: bool, path: Path | None = None):
    """Async implementation of schema push."""
    from rich.prompt import Confirm

    from planecompose.utils.project import ensure_project_exists

    backend = None
    try:
        ctx = require_project_context(path)

        # Sync workspace features before pushing schema
        sync_workspace_context(ctx)

        # Check if project exists (without auto-creating yet)
        with create_progress() as (progress, task):
            progress.update(task, description="Checking project...")
            try:
                # Check if project already exists
                _ = await ensure_project_exists(
                    workspace=ctx.config.workspace,
                    project_key=ctx.config.project_key,
                    project_uuid=ctx.config.project_uuid,
                    project_name=ctx.config.project_name,
                    api_key=ctx.api_key,
                    api_url=ctx.config.api_url,
                    auto_create=False,  # Just check, don't create yet
                    silent_on_not_found=True,  # Suppress error output for existence check
                )
                project_exists = True
            except Exception:
                # Project doesn't exist
                project_exists = False

        # If project doesn't exist, ask for confirmation before creating
        if not project_exists and not dry_run:
            console.print("\n[bold]New Project[/bold]")
            console.print(f"  [cyan]{ctx.config.project_name}[/cyan] ({ctx.config.project_key})")
            console.print(f"  Workspace: [cyan]{ctx.config.workspace}[/cyan]\n")

            if not force:
                if not Confirm.ask("Create this project in Plane?"):
                    console.print("[yellow]Cancelled[/yellow]")
                    raise typer.Exit(0)

        # Now connect to backend with auto_create (will create if needed)
        with create_progress() as (progress, task):
            ctx, backend = await connect_backend(
                ctx, auto_create=True, progress=progress, task=task
            )

            # Push project metadata (name, description, network, timezone) from plane.yaml
            progress.update(task, description="Updating project metadata...")
            _has_metadata = any([
                ctx.config.project_name is not None,
                ctx.config.project_description is not None,
                ctx.config.project_network is not None,
                ctx.config.project_timezone is not None,
            ])
            if _has_metadata and ctx.config.project_uuid:
                await backend.update_project_metadata(
                    workspace=ctx.config.workspace,
                    project_id=ctx.config.project_uuid,
                    name=ctx.config.project_name,
                    description=ctx.config.project_description,
                    network=ctx.config.project_network,
                    timezone=ctx.config.project_timezone,
                )

            # Push feature flags — features.yaml is authoritative when present.
            # Falls back to inferring from local schema data for backwards compat
            # (projects cloned before features.yaml was introduced).
            progress.update(task, description="Pushing features...")
            _features_yaml_path = ctx.schema_path / "features.yaml"
            if _features_yaml_path.exists():
                # features.yaml present → it is the complete, explicit declaration.
                # One API call; no inference needed.
                import yaml as _yaml
                with open(_features_yaml_path) as _ff:
                    _features_data = _yaml.safe_load(_ff)
                _features_dict = (_features_data or {}).get("features", {})
                if _features_dict:
                    await backend.set_features(_features_dict)
            else:
                # No features.yaml → infer enables from local schema data.
                # (legacy behaviour — projects that pre-date features.yaml)
                has_modules = bool(ctx.modules)
                has_cycles = bool(ctx.cycles)
                has_custom_types = bool(ctx.types)
                has_workflows = bool(ctx.workflows) and (
                    any(not getattr(w, "is_default", False) for w in ctx.workflows)
                    or len(ctx.workflows) > 1
                )
                await backend.enable_features(
                    modules_enabled=has_modules,
                    cycles_enabled=has_cycles,
                    work_item_types_enabled=has_custom_types,
                    workflows_enabled=has_workflows,
                )

            (
                remote_types,
                remote_states,
                remote_labels,
                remote_workflows,
                _remote_modules,  # unused — schema push never touches work/ data
                _remote_cycles,   # unused — schema push never touches work/ data
            ) = await fetch_remote_schema(
                backend, progress=progress, task=task, include_work=False
            )

        # Build remote lookup maps: name → remote_id, id → object
        remote_label_by_id = {lbl.remote_id: lbl for lbl in remote_labels if lbl.remote_id}
        remote_state_by_id = {s.remote_id: s for s in remote_states if s.remote_id}
        remote_type_by_id = {t.remote_id: t for t in remote_types if t.remote_id}
        remote_workflow_by_id = {w.remote_id: w for w in remote_workflows if w.remote_id}

        # Split local items into CREATE (no id / unknown id) vs UPDATE (has id)
        labels_to_create, labels_to_update = _split_create_update(
            ctx.labels, remote_labels, remote_label_by_id
        )
        states_to_create, states_to_update = _split_create_update(
            ctx.states, remote_states, remote_state_by_id
        )
        types_to_create, types_to_update = _split_create_update(
            ctx.types, remote_types, remote_type_by_id
        )
        workflows_to_create, workflows_to_update = _split_create_update(
            ctx.workflows, remote_workflows, remote_workflow_by_id
        )
        # NOTE: modules and cycles are operational data (work/), not schema.
        # They are managed by 'plane push', not 'plane schema push'.

        # In enterprise mode (workspace-level work_item_types enabled), project-level
        # type updates are not possible — these types are managed at the workspace.
        # Filter workspace-linked types out of types_to_update so they don't appear
        # in the push plan or produce spurious "failed" entries in the summary.
        # (Creates still flow through _import_workspace_types, which is correct.)
        workspace_wit_enabled = (
            ctx.workspace_config
            and ctx.workspace_config.workspace_features
            and ctx.workspace_config.workspace_features.get("work_item_types", False)
        )
        if workspace_wit_enabled:
            types_to_update = [t for t in types_to_update if not t.ws_workitemtype_id]

        # Display push plan
        console.print("\n[bold]Schema Push Plan[/bold]\n")

        display_create_table(
            "Work Item Types (create)", types_to_create, lambda t: [t.name, t.description or ""]
        )
        display_create_table("States (create)", states_to_create, lambda s: [s.name, s.group])
        display_create_table(
            "Labels (create)", labels_to_create, lambda lbl: [lbl.name, lbl.color or ""]
        )
        display_create_table(
            "Workflows (create)", workflows_to_create, lambda w: [w.name, w.description or ""]
        )
        if types_to_update:
            console.print(
                f"  [yellow]~[/yellow] Types to update: {', '.join(t.name for t in types_to_update)}"
            )
        if states_to_update:
            console.print(
                f"  [yellow]~[/yellow] States to update: {', '.join(s.name for s in states_to_update)}"
            )
        if labels_to_update:
            console.print(
                f"  [yellow]~[/yellow] Labels to update: {', '.join(lbl.name for lbl in labels_to_update)}"
            )
        if workflows_to_update:
            console.print(
                f"  [yellow]~[/yellow] Workflows to update: {', '.join(w.name for w in workflows_to_update)}"
            )

        total = (
            len(types_to_create)
            + len(states_to_create)
            + len(labels_to_create)
            + len(workflows_to_create)
            + len(types_to_update)
            + len(states_to_update)
            + len(labels_to_update)
            + len(workflows_to_update)
        )

        if total == 0:
            console.print("[green]✓ Everything up to date![/green]")
            console.print("All schema items already exist in Plane.\n")
            # Still rebuild schema files to ensure IDs are baked in
            _rebuild_schema(ctx)
            return

        console.print(
            f"\n[bold]Summary:[/bold] {len(types_to_create) + len(states_to_create) + len(labels_to_create) + len(workflows_to_create)} to create, "
            f"{len(types_to_update) + len(states_to_update) + len(labels_to_update) + len(workflows_to_update)} to update\n"
        )

        if dry_run:
            console.print("[yellow]Dry run mode - no changes applied[/yellow]")
            return

        # Confirm before applying schema modifications
        if not force:
            if not Confirm.ask("Apply these schema changes?"):
                console.print("[yellow]Cancelled[/yellow]")
                raise typer.Exit(0)

        # Push changes with tracking
        created_states = 0
        created_labels = 0
        created_types = 0
        created_workflows = 0
        updated_states = 0
        updated_labels = 0
        updated_types = 0
        updated_workflows = 0
        failed_states = []
        failed_labels = []
        failed_types = []
        failed_workflows = []

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            # Create states first (required by work items)
            if states_to_create:
                task = progress.add_task(
                    f"Creating {len(states_to_create)} states...", total=len(states_to_create)
                )
                for state in states_to_create:
                    try:
                        remote_id = await backend.create_state(state)
                        state.remote_id = remote_id
                        ctx.state.states[state.name] = remote_id
                        created_states += 1
                    except Exception as e:
                        failed_states.append((state.name, str(e)))
                        logger.error(f"Failed to create state '{state.name}': {e}")
                    progress.update(task, advance=1)
                progress.remove_task(task)

            # Update states
            if states_to_update:
                task = progress.add_task(
                    f"Updating {len(states_to_update)} states...", total=len(states_to_update)
                )
                for state in states_to_update:
                    try:
                        await backend.update_state(state.remote_id, state)
                        ctx.state.states[state.name] = state.remote_id
                        updated_states += 1
                    except Exception as e:
                        failed_states.append((state.name, str(e)))
                        logger.error(f"Failed to update state '{state.name}': {e}")
                    progress.update(task, advance=1)
                progress.remove_task(task)

            # Create labels
            if labels_to_create:
                task = progress.add_task(
                    f"Creating {len(labels_to_create)} labels...", total=len(labels_to_create)
                )
                for label in labels_to_create:
                    try:
                        remote_id = await backend.create_label(label)
                        label.remote_id = remote_id
                        ctx.state.labels[label.name] = remote_id
                        created_labels += 1
                    except Exception as e:
                        failed_labels.append((label.name, str(e)))
                        logger.error(f"Failed to create label '{label.name}': {e}")
                    progress.update(task, advance=1)
                progress.remove_task(task)

            # Update labels
            if labels_to_update:
                task = progress.add_task(
                    f"Updating {len(labels_to_update)} labels...", total=len(labels_to_update)
                )
                for label in labels_to_update:
                    try:
                        await backend.update_label(label.remote_id, label)
                        ctx.state.labels[label.name] = label.remote_id
                        updated_labels += 1
                    except Exception as e:
                        failed_labels.append((label.name, str(e)))
                        logger.error(f"Failed to update label '{label.name}': {e}")
                    progress.update(task, advance=1)
                progress.remove_task(task)

            # Types must be created BEFORE workflows, because a workflow's
            # work_item_type_ids payload needs project-level type UUIDs — and
            # those only exist after import_workspace_types (or create_type)
            # has run. Previously workflows were created first and got a
            # stale type_name_to_id, causing "Must be a valid UUID" errors
            # for any workflow that referenced a not-yet-imported type.
            workspace_wit_enabled = (
                ctx.workspace_config
                and ctx.workspace_config.workspace_features
                and ctx.workspace_config.workspace_features.get("work_item_types", False)
            )

            if types_to_create:
                if workspace_wit_enabled:
                    task = progress.add_task(
                        f"Importing {len(types_to_create)} workspace types...",
                        total=len(types_to_create),
                    )
                    imported_count, import_failed = await _import_workspace_types(
                        backend,
                        cast(str, ctx.config.workspace),
                        cast(str, ctx.config.project_uuid),
                        types_to_create,
                        ctx.workspace_config,
                    )
                    for type_def in types_to_create:
                        if type_def.ws_workitemtype_id:
                            created_types += 1
                            ctx.state.types[type_def.name] = type_def.ws_workitemtype_id
                        else:
                            failed_types.append(
                                (type_def.name, "No matching workspace work item type found")
                            )
                    failed_types.extend(import_failed)
                    progress.update(task, advance=len(types_to_create))
                    progress.remove_task(task)
                else:
                    task = progress.add_task(
                        f"Creating {len(types_to_create)} types...", total=len(types_to_create)
                    )
                    for type_def in types_to_create:
                        try:
                            remote_id = await backend.create_type(type_def)
                            type_def.remote_id = remote_id
                            ctx.state.types[type_def.name] = remote_id
                            created_types += 1
                        except Exception as e:
                            failed_types.append((type_def.name, str(e)))
                            logger.error(f"Failed to create type '{type_def.name}': {e}")
                        progress.update(task, advance=1)
                    progress.remove_task(task)

            if types_to_update:
                if workspace_wit_enabled:
                    logger.debug(
                        f"Skipping {len(types_to_update)} type updates — workspace-level work_item_types enabled."
                    )
                else:
                    task = progress.add_task(
                        f"Updating {len(types_to_update)} types...", total=len(types_to_update)
                    )
                    for type_def in types_to_update:
                        try:
                            await backend.update_type(type_def.remote_id, type_def)
                            ctx.state.types[type_def.name] = type_def.remote_id
                            updated_types += 1
                        except Exception as e:
                            failed_types.append((type_def.name, str(e)))
                            logger.error(f"Failed to update type '{type_def.name}': {e}")
                        progress.update(task, advance=1)
                    progress.remove_task(task)

            # Build type_name_to_id mapping for workflow work_item_types conversion.
            # The workflow API expects PROJECT-level type IDs in work_item_type_ids,
            # not workspace-level ws_workitemtype_id. Re-fetch remote_types AFTER
            # the types step above so newly-imported workspace types (which only
            # just got project-level UUIDs) are included.
            try:
                remote_types = await backend.list_types()
            except Exception as e:
                logger.warning(f"Failed to refresh type list after types step: {e}")
            type_name_to_id = {}
            for type_def in remote_types:
                if type_def.remote_id and type_def.name:
                    type_name_to_id[type_def.name] = type_def.remote_id
            for type_def in ctx.types:
                if type_def.remote_id and type_def.name and type_def.name not in type_name_to_id:
                    type_name_to_id[type_def.name] = type_def.remote_id

            # Build state_name_to_id mapping for attaching states to workflows.
            # Plane's workflow create/update payload does not accept states —
            # they are managed via a separate /workflows/{id}/states/ endpoint.
            #
            # remote_states only contains states that existed BEFORE this push.
            # States created in this same push have their remote_id set on the
            # local objects in states_to_create, so we merge both sources to
            # ensure newly-created states are resolvable by workflows.
            state_name_to_id = {s.name: s.remote_id for s in remote_states if s.remote_id}
            for s in states_to_create:
                if s.remote_id and s.name not in state_name_to_id:
                    state_name_to_id[s.name] = s.remote_id

            # Build email → user UUID mapping for resolving transition approvers.
            # Approvers are stored as emails in workflows.yaml (set during pull/clone
            # via user_id_to_email), so we need the reverse mapping on push.
            email_to_user_id: dict[str, str] = {}
            try:
                members = await backend.fetch_project_members(
                    cast(str, ctx.config.workspace), cast(str, backend._project_id)
                )
                for m in members:
                    uid = m.get("id")
                    email = m.get("email")
                    if uid and email:
                        email_to_user_id[email] = uid
                logger.debug(f"Built email_to_user_id with {len(email_to_user_id)} members")
            except Exception as e:
                logger.debug(f"Could not build email_to_user_id: {e}")

            def _resolve_workflow_state_ids(workflow) -> list[str]:
                """Map a workflow's local states to project-level state UUIDs."""
                ids: list[str] = []
                for st in workflow.states or []:
                    sid = getattr(st, "remote_id", None) or state_name_to_id.get(st.name)
                    if sid:
                        ids.append(sid)
                    else:
                        logger.warning(
                            f"Could not resolve state '{st.name}' for workflow "
                            f"'{workflow.name}' — skipping"
                        )
                return ids

            # Create workflows (then attach their states)
            if workflows_to_create:
                task = progress.add_task(
                    f"Creating {len(workflows_to_create)} workflows...",
                    total=len(workflows_to_create),
                )
                for workflow in workflows_to_create:
                    try:
                        remote_id = await backend.create_workflow(
                            workflow, type_name_to_id=type_name_to_id
                        )
                        workflow.remote_id = remote_id
                        # Attach all local states to the freshly-created workflow
                        state_ids = _resolve_workflow_state_ids(workflow)
                        if state_ids:
                            await backend.attach_workflow_states(remote_id, state_ids)
                        # Push transitions defined in the local workflow
                        await _sync_workflow_transitions(
                            backend, workflow, None, state_name_to_id, email_to_user_id
                        )
                        ctx.state.workflows[workflow.name] = remote_id
                        created_workflows += 1
                    except Exception as e:
                        failed_workflows.append((workflow.name, str(e)))
                        logger.error(f"Failed to create workflow '{workflow.name}': {e}")
                    progress.update(task, advance=1)
                progress.remove_task(task)

            # Update workflows (then sync their states + transitions)
            if workflows_to_update:
                task = progress.add_task(
                    f"Updating {len(workflows_to_update)} workflows...",
                    total=len(workflows_to_update),
                )
                for workflow in workflows_to_update:
                    try:
                        await backend.update_workflow(
                            workflow.remote_id, workflow, type_name_to_id=type_name_to_id
                        )

                        # Sync states against remote
                        remote_wf = remote_workflow_by_id.get(workflow.remote_id)
                        remote_state_ids = {
                            s.remote_id
                            for s in (remote_wf.states if remote_wf else [])
                            if s.remote_id
                        }
                        local_state_ids = set(_resolve_workflow_state_ids(workflow))

                        to_add = local_state_ids - remote_state_ids
                        to_remove = remote_state_ids - local_state_ids

                        if to_add:
                            await backend.attach_workflow_states(workflow.remote_id, list(to_add))
                        for sid in to_remove:
                            await backend.detach_workflow_state(workflow.remote_id, sid)

                        # Sync transitions (create new local-only ones; existing
                        # duplicates are treated as no-ops by the backend).
                        # Delete-path TBD — requires a GET endpoint for
                        # transitions to enumerate what's on remote.
                        await _sync_workflow_transitions(
                            backend, workflow, remote_wf, state_name_to_id, email_to_user_id
                        )

                        ctx.state.workflows[workflow.name] = workflow.remote_id
                        updated_workflows += 1
                    except Exception as e:
                        failed_workflows.append((workflow.name, str(e)))
                        logger.error(f"Failed to update workflow '{workflow.name}': {e}")
                    progress.update(task, advance=1)
                progress.remove_task(task)

            # (types create/update moved to before workflows — see above)

            # NOTE: modules and cycles are NOT pushed here.
            # They are operational data (work/) managed by 'plane push'.

            # Sync state with remote items that exist by name match
            # (ensures items skipped in _split_create_update are still tracked)
            task = progress.add_task("Syncing state with remote...", total=None)

            # Build reverse lookup: name -> remote item
            remote_states_by_name = {s.name: s for s in remote_states}
            remote_types_by_name = {t.name: t for t in remote_types}
            remote_labels_by_name = {lbl.name: lbl for lbl in remote_labels}

            # Add any local items that exist on remote (by name) but don't have IDs locally
            # IMPORTANT: Update both ctx.state AND the definition objects' remote_id
            # so that _rebuild_schema() can write IDs back to YAML files
            for local_state in ctx.states:
                if local_state.name in remote_states_by_name and not local_state.remote_id:
                    remote_state = remote_states_by_name[local_state.name]
                    if remote_state.remote_id:
                        ctx.state.states[local_state.name] = remote_state.remote_id
                        # Also update the definition object so IDs get written to YAML
                        local_state.remote_id = remote_state.remote_id

            for local_type in ctx.types:
                if local_type.name in remote_types_by_name and not local_type.remote_id:
                    remote_type = remote_types_by_name[local_type.name]
                    if remote_type.remote_id:
                        ctx.state.types[local_type.name] = remote_type.remote_id
                        # Also update the definition object so IDs get written to YAML
                        local_type.remote_id = remote_type.remote_id

            for local_label in ctx.labels:
                if local_label.name in remote_labels_by_name and not local_label.remote_id:
                    remote_label = remote_labels_by_name[local_label.name]
                    if remote_label.remote_id:
                        ctx.state.labels[local_label.name] = remote_label.remote_id
                        # Also update the definition object so IDs get written to YAML
                        local_label.remote_id = remote_label.remote_id
            # NOTE: modules/cycles state sync happens in 'plane push', not here.

            progress.remove_task(task)

            # Save state
            task = progress.add_task("Saving state...", total=None)
            ctx.save_state()
            progress.remove_task(task)

            # Post-push refresh: additively pick up anything the backend
            # created as a side effect of our push that we don't yet know
            # about locally (most commonly the Default Workflow that Plane
            # auto-creates when the workflows feature flips on). This keeps
            # `push` self-contained — callers shouldn't need a follow-up pull
            # just to capture server-side additions.
            task = progress.add_task("Refreshing from remote...", total=None)
            try:
                await _merge_remote_additions(ctx, backend)
            except Exception as e:
                logger.warning(f"Post-push remote refresh failed: {e}")
            progress.remove_task(task)

        # Rebuild schema files with IDs baked in
        _rebuild_schema(ctx)

        # Update plane.yaml with project UUID (if newly created)
        if ctx.config.project_uuid:
            from planecompose.utils.project import update_plane_yaml_with_uuid

            try:
                update_plane_yaml_with_uuid(
                    ctx.root_path, ctx.config.project_key, ctx.config.project_uuid
                )
            except Exception as e:
                logger.warning(f"Failed to update plane.yaml with project UUID: {e}")

        # Display summary
        console.print()
        console.print("[bold]Schema Push Summary[/bold]\n")

        if created_states > 0:
            console.print(f"[green]✓[/green] Created {created_states} states")
        if updated_states > 0:
            console.print(f"[yellow]~[/yellow] Updated {updated_states} states")
        if created_labels > 0:
            console.print(f"[green]✓[/green] Created {created_labels} labels")
        if updated_labels > 0:
            console.print(f"[yellow]~[/yellow] Updated {updated_labels} labels")
        if created_workflows > 0:
            console.print(f"[green]✓[/green] Created {created_workflows} workflows")
        if updated_workflows > 0:
            console.print(f"[yellow]~[/yellow] Updated {updated_workflows} workflows")
        if created_types > 0:
            console.print(f"[green]✓[/green] Created {created_types} types")
        if updated_types > 0:
            console.print(f"[yellow]~[/yellow] Updated {updated_types} types")

        display_failed_items(failed_states, "states")
        display_failed_items(failed_labels, "labels")
        display_failed_items(failed_workflows, "workflows")
        display_failed_items(failed_types, "types")

        total_created = (
            created_states
            + created_labels
            + created_workflows
            + created_types
        )
        total_updated = (
            updated_states
            + updated_labels
            + updated_workflows
            + updated_types
        )
        total_failed = (
            len(failed_states) + len(failed_labels) + len(failed_workflows) + len(failed_types)
        )

        if total_failed == 0:
            from planecompose.state.manager import StateManager

            StateManager(ctx.root_path).mark_last_sync()
            console.print("\n[bold green]✓ Schema push complete![/bold green]")
            console.print(f"Created: {total_created}  Updated: {total_updated}\n")
        else:
            console.print("\n[yellow]⚠ Schema push completed with errors[/yellow]")
            console.print(
                f"Created: {total_created}  Updated: {total_updated}  Failed: {total_failed}\n"
            )

    except asyncio.CancelledError:
        pass  # KeyboardInterrupt caught in sync wrapper; CancelledError is cleanup only
    except typer.Exit:
        raise
    except Exception as e:
        from planecompose.utils.errors import handle_api_error

        handle_api_error(e, "push schema")
        raise typer.Exit(1)
    finally:
        if backend:
            await backend.disconnect()


@app.command("import")
def import_schema(
    project: str | None = typer.Argument(
        None, help="Project folder name. Combined with --path if provided."
    ),
    path: Path | None = typer.Option(
        None, "--path", help="Parent directory containing the project (default: current directory)"
    ),
    merge: bool = typer.Option(
        False, "--merge", "-m", help="Add missing items from remote (additive, no overwrites)"
    ),
    force: bool = typer.Option(
        False, "--force", "-f", help="Overwrite local schema files with remote (DESTRUCTIVE)"
    ),
):
    """
    Import schema from Plane (Terraform-style).

    By default, only updates .plane/state.json with remote IDs (connects local to remote).
    Your local schema files are NOT modified.

    Modes:
      (default)  State-only import - map local schema names to remote UUIDs
      --merge    Add missing items from remote to local (additive, safe)
      --force    Overwrite local schema with remote (DESTRUCTIVE)

    Examples:
        plane schema import                 # Connect local schema to remote IDs
        plane schema import ./projects/api  # Import specific project
        plane schema import --merge         # Add missing types/states/labels from remote
        plane schema import --force         # Replace local with remote (use with caution)
    """
    resolved_path = (
        (path or Path.cwd()).resolve() / project if project else (path.resolve() if path else None)
    )
    try:
        asyncio.run(_import_schema(resolved_path, merge, force))
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled.[/yellow]")
        raise typer.Exit(130)


async def _import_schema(path: Path | None, merge: bool, force: bool):
    """Async implementation of schema import."""
    import time

    from planecompose.cli.clone_helpers import (
        convert_sdk_type_to_dict,
    )
    from planecompose.state.manager import StateManager

    backend = None
    try:
        ctx = require_project_context(path)

        # Sync workspace features before importing schema
        sync_workspace_context(ctx)

        start_time = time.time()

        with create_progress() as (progress, task):
            ctx, backend = await connect_backend(ctx, progress=progress, task=task)

            # Fetch remote schema with full property data
            progress.update(task, description="Fetching types...")
            types_sdk = await backend.list_types_raw()
            types_data = [convert_sdk_type_to_dict(t) for t in types_sdk]

            progress.update(task, description="Building property maps...")
            property_maps = await backend.build_property_maps(types_data)

            progress.update(task, description="Fetching states...")
            remote_states = await backend.list_states()

            progress.update(task, description="Fetching labels...")
            remote_labels = await backend.list_labels()

            # Fetch workflows too — previously skipped, which is why
            # schema import never pulled the Default Workflow (or any other).
            progress.update(task, description="Fetching workflows...")
            try:
                remote_workflows = await backend.fetch_workflows()
            except Exception as e:
                logger.debug(f"Could not fetch workflows during import: {e}")
                remote_workflows = []

            progress.update(task, description="Fetching members...")
            try:
                project_members = await backend.fetch_project_members(
                    cast(str, ctx.config.workspace), cast(str, ctx.config.project_uuid)
                )
            except Exception as e:
                logger.debug(f"Could not fetch project members during import: {e}")
                project_members = []

            # Fetch cycles and modules (raw SDK objects so write_cycles/modules_yaml works)
            progress.update(task, description="Fetching cycles...")
            try:
                cycles_raw = await backend.list_cycles_raw(
                    cast(str, ctx.config.workspace), cast(str, ctx.config.project_uuid)
                )
            except Exception as e:
                logger.debug(f"Could not fetch cycles during import: {e}")
                cycles_raw = []

            progress.update(task, description="Fetching modules...")
            try:
                modules_raw = await backend.list_modules_raw(
                    cast(str, ctx.config.workspace), cast(str, ctx.config.project_uuid)
                )
            except Exception as e:
                logger.debug(f"Could not fetch modules during import: {e}")
                modules_raw = []

            # Fetch project features for features.yaml
            progress.update(task, description="Fetching project features...")
            try:
                project_features_import = await backend.get_project_features()
            except Exception as e:
                logger.debug(f"Could not fetch project features during import: {e}")
                project_features_import = {}

        # Build remote lookup maps (case-insensitive)
        remote_type_map = {t["name"].lower(): t for t in types_data if t.get("name")}
        remote_state_map = {s.name.lower(): s for s in remote_states}
        remote_label_map = {lbl.name.lower(): lbl for lbl in remote_labels}

        state_manager = StateManager(ctx.root_path)

        if force:
            # FORCE MODE: Overwrite local files with remote. No prompt —
            # --force is meant to be non-interactive (scripting/CI).
            console.print(
                "\n[yellow]⚠  FORCE MODE: overwriting local schema files with remote.[/yellow]"
            )

            await _write_full_schema(
                ctx, types_data, remote_states, remote_labels, property_maps, remote_workflows,
                cycles_raw=cycles_raw, modules_raw=modules_raw,
            )

            # Update state with all remote IDs
            state_manager.update_schema_state(
                types={t["name"]: t["id"] for t in types_data if t.get("name") and t.get("id")},
                states={s.name: s.remote_id for s in remote_states if s.remote_id},
                labels={lbl.name: lbl.remote_id for lbl in remote_labels if lbl.remote_id},
                update_last_sync=True,
            )

            # Write features.yaml
            if project_features_import:
                from planecompose.parser.schema_writer import write_features_yaml as _wfy
                _wfy(ctx.root_path / "schema" / "features.yaml", project_features_import)

            # Write members
            if project_members:
                from planecompose.parser.members_yaml import write_members_yaml, merge_member_roles

                write_members_yaml(
                    ctx.root_path,
                    merge_member_roles(project_members, ctx.root_path),
                )

            elapsed = time.time() - start_time
            console.print("\n[green]✓[/green] Imported schema from remote (force mode)")
            console.print(f"  [cyan]Types:[/cyan] {len(types_data)} → schema/types.yaml")
            console.print(f"  [cyan]States:[/cyan] {len(remote_states)} → schema/states.yaml")
            console.print(
                f"  [cyan]Workflows:[/cyan] {len(remote_workflows) if remote_workflows else 0} → schema/workflows.yaml"
            )
            console.print(f"  [cyan]Labels:[/cyan] {len(remote_labels)} → schema/labels.yaml")
            console.print(f"  [cyan]Features:[/cyan] {len(project_features_import)} toggle(s) → schema/features.yaml")
            console.print(f"  [cyan]Cycles:[/cyan] {len(cycles_raw)} → work/cycles.yaml")
            console.print(f"  [cyan]Modules:[/cyan] {len(modules_raw)} → work/modules.yaml")
            console.print(f"  [cyan]Members:[/cyan] {len(project_members)} → schema/members.yaml")
            console.print(f"[dim]  Completed in {elapsed:.1f}s[/dim]\n")

            # Note: we deliberately do NOT call _rebuild_schema(ctx) here.
            # ctx holds the pre-import state (loaded at the start of this
            # command), so rebuilding from ctx would overwrite the fresh
            # workflows.yaml/states.yaml we just wrote. _write_full_schema
            # already produces the correct enterprise-aware formatting.

        elif merge:
            # MERGE MODE: Add missing items from remote (additive)
            added_types, added_states, added_labels, added_workflows = await _merge_schema(
                ctx,
                types_data,
                remote_states,
                remote_labels,
                property_maps,
                remote_type_map,
                remote_state_map,
                remote_label_map,
                remote_workflows=remote_workflows,
            )

            # Update state with all remote IDs (including existing)
            state_manager.update_schema_state(
                types={t["name"]: t["id"] for t in types_data if t.get("name") and t.get("id")},
                states={s.name: s.remote_id for s in remote_states if s.remote_id},
                labels={lbl.name: lbl.remote_id for lbl in remote_labels if lbl.remote_id},
                update_last_sync=True,
            )

            # Write features.yaml (always refresh in merge mode)
            if project_features_import:
                from planecompose.parser.schema_writer import write_features_yaml as _wfy
                _wfy(ctx.root_path / "schema" / "features.yaml", project_features_import)

            # Write members — preserve existing roles (API doesn't return them)
            if project_members:
                from planecompose.parser.members_yaml import write_members_yaml, merge_member_roles

                write_members_yaml(
                    ctx.root_path,
                    merge_member_roles(project_members, ctx.root_path),
                )

            elapsed = time.time() - start_time
            total_added = len(added_types) + len(added_states) + len(added_labels) + len(added_workflows)

            if total_added == 0:
                console.print("\n[green]✓[/green] Schema already complete - nothing to add")
            else:
                console.print(f"\n[green]✓[/green] Merged {total_added} items from remote")
                if added_types:
                    console.print(f"  [green]+[/green] Types: {', '.join(added_types)}")
                if added_states:
                    console.print(f"  [green]+[/green] States: {', '.join(added_states)}")
                if added_labels:
                    console.print(f"  [green]+[/green] Labels: {', '.join(added_labels)}")
                if added_workflows:
                    console.print(f"  [green]+[/green] Workflows: {', '.join(added_workflows)}")

            console.print(
                f"\n[dim]State updated with {len(types_data)} types, {len(remote_states)} states, "
                f"{len(remote_labels)} labels, {len(remote_workflows)} workflows[/dim]"
            )
            console.print(f"[dim]Completed in {elapsed:.1f}s[/dim]\n")

        else:
            # DEFAULT MODE: State-only import (no file changes)
            # Map local schema names to remote UUIDs

            # Match local types to remote
            matched_types = 0
            unmatched_types = []
            for local_type in ctx.types:
                remote = remote_type_map.get(local_type.name.lower())
                if remote and remote.get("id"):
                    ctx.state.types[local_type.name] = remote["id"]
                    matched_types += 1
                else:
                    unmatched_types.append(local_type.name)

            # Match local states to remote
            matched_states = 0
            unmatched_states = []
            for local_state in ctx.states:
                remote_state = remote_state_map.get(local_state.name.lower())
                if remote_state and remote_state.remote_id:
                    ctx.state.states[local_state.name] = remote_state.remote_id
                    matched_states += 1
                else:
                    unmatched_states.append(local_state.name)

            # Match local labels to remote
            matched_labels = 0
            unmatched_labels = []
            for local_label in ctx.labels:
                remote_label = remote_label_map.get(local_label.name.lower())
                if remote_label and remote_label.remote_id:
                    ctx.state.labels[local_label.name] = remote_label.remote_id
                    matched_labels += 1
                else:
                    unmatched_labels.append(local_label.name)

            # Match local workflows to remote
            remote_workflow_map = {w.name.lower(): w for w in remote_workflows}
            matched_workflows = 0
            unmatched_workflows = []
            for local_wf in ctx.workflows:
                remote_wf = remote_workflow_map.get(local_wf.name.lower())
                if remote_wf and remote_wf.remote_id:
                    ctx.state.workflows[local_wf.name] = remote_wf.remote_id
                    matched_workflows += 1
                else:
                    unmatched_workflows.append(local_wf.name)

            # Detect content changes in matched workflows (same name, different transitions etc.)
            wf_changes = detect_workflow_changes(ctx.workflows, remote_workflows)

            # Save state
            ctx.save_state()
            state_manager.mark_last_sync()

            elapsed = time.time() - start_time
            console.print("\n[green]✓[/green] State updated (local files unchanged)")
            console.print(f"  [cyan]Types:[/cyan] {matched_types}/{len(ctx.types)} matched")
            console.print(f"  [cyan]States:[/cyan] {matched_states}/{len(ctx.states)} matched")
            console.print(f"  [cyan]Labels:[/cyan] {matched_labels}/{len(ctx.labels)} matched")
            console.print(f"  [cyan]Workflows:[/cyan] {matched_workflows}/{len(ctx.workflows)} matched")

            if unmatched_types or unmatched_states or unmatched_labels or unmatched_workflows:
                console.print("\n[yellow]Unmatched (exist locally but not in remote):[/yellow]")
                if unmatched_types:
                    console.print(f"  Types: {', '.join(unmatched_types)}")
                if unmatched_states:
                    console.print(f"  States: {', '.join(unmatched_states)}")
                if unmatched_labels:
                    console.print(f"  Labels: {', '.join(unmatched_labels)}")
                if unmatched_workflows:
                    console.print(f"  Workflows: {', '.join(unmatched_workflows)}")
                console.print("\n[dim]Run 'plane schema push' to create these in remote[/dim]")

            # Show items only in remote
            local_type_names = {t.name.lower() for t in ctx.types}
            local_state_names = {s.name.lower() for s in ctx.states}
            local_label_names = {lbl.name.lower() for lbl in ctx.labels}
            local_workflow_names = {w.name.lower() for w in ctx.workflows}

            remote_only_types = [
                t["name"]
                for t in types_data
                if t.get("name") and t["name"].lower() not in local_type_names
            ]
            remote_only_states = [
                s.name for s in remote_states if s.name.lower() not in local_state_names
            ]
            remote_only_labels = [
                lbl.name for lbl in remote_labels if lbl.name.lower() not in local_label_names
            ]
            remote_only_workflows = [
                w.name for w in remote_workflows if w.name.lower() not in local_workflow_names
            ]

            if remote_only_types or remote_only_states or remote_only_labels or remote_only_workflows:
                console.print("\n[cyan]Only in remote (not in local schema):[/cyan]")
                if remote_only_types:
                    console.print(f"  Types: {', '.join(remote_only_types)}")
                if remote_only_states:
                    console.print(f"  States: {', '.join(remote_only_states)}")
                if remote_only_labels:
                    console.print(f"  Labels: {', '.join(remote_only_labels)}")
                if remote_only_workflows:
                    console.print(f"  Workflows: {', '.join(remote_only_workflows)}")
                console.print("\n[dim]Run 'plane schema import --merge' to add these locally[/dim]")

            # Show content changes in matched items (e.g., workflow transitions)
            has_wf_content_changes = any(wf_changes[k] for k in wf_changes)
            if has_wf_content_changes:
                console.print("\n[yellow]Content changes in matched items:[/yellow]")
                for wf_name, local_wits, remote_wits in wf_changes["wit_changes"]:
                    console.print(f"  [yellow]~[/yellow] Workflow '{wf_name}': work_item_types changed")
                    added = local_wits - remote_wits
                    removed = remote_wits - local_wits
                    if added:
                        console.print(f"    [green]+ Added: {', '.join(sorted(added))}")
                    if removed:
                        console.print(f"    [red]- Removed: {', '.join(sorted(removed))}")
                for wf_name, local_sts, remote_sts in wf_changes["state_changes"]:
                    console.print(f"  [yellow]~[/yellow] Workflow '{wf_name}': states changed")
                    added = local_sts - remote_sts
                    removed = remote_sts - local_sts
                    if added:
                        console.print(f"    [green]+ Added: {', '.join(sorted(added))}")
                    if removed:
                        console.print(f"    [red]- Removed: {', '.join(sorted(removed))}")
                for wf_name, rule_descs in wf_changes["rule_changes"]:
                    console.print(f"  [yellow]~[/yellow] Workflow '{wf_name}': transition conditions changed")
                    for desc in rule_descs:
                        console.print(f"    [yellow]~ {desc}[/yellow]")
                console.print(
                    "\n[dim]Transition conditions are managed in Plane UI (cannot be pushed via CLI)[/dim]"
                )
                console.print("[dim]Run 'plane schema diff' for full comparison[/dim]")
                console.print("[dim]Run 'plane schema import --merge' to pull remote-only items locally[/dim]")

            # Show feature conflicts (local features.yaml vs remote).
            # Read the original local file — do NOT write it (default mode is read-only).
            local_features_import: dict[str, bool] = {}
            _lf_path = ctx.root_path / "schema" / "features.yaml"
            if _lf_path.exists():
                import yaml as _fyaml
                _fd = _fyaml.safe_load(open(_lf_path)) or {}
                local_features_import = _fd.get("features", {})

            if local_features_import and project_features_import:
                feature_conflicts = [
                    (k, local_features_import[k], project_features_import[k])
                    for k in sorted(set(local_features_import) & set(project_features_import))
                    if local_features_import.get(k) != project_features_import.get(k)
                ]
                if feature_conflicts:
                    console.print("\n[yellow]Feature conflicts (local ≠ remote):[/yellow]")
                    for feat, local_val, remote_val in feature_conflicts:
                        local_str = "[green]true[/green]" if local_val else "[red]false[/red]"
                        remote_str = "[green]true[/green]" if remote_val else "[red]false[/red]"
                        console.print(f"  [yellow]~[/yellow] {feat}: local={local_str}, remote={remote_str}")
                    console.print(
                        "\n[dim]To resolve: [cyan]plane schema push[/cyan] applies local → remote[/dim]"
                    )
                    console.print(
                        "[dim]            [cyan]plane schema import --force[/cyan] overwrites local with remote[/dim]"
                    )

            console.print(f"\n[dim]Completed in {elapsed:.1f}s[/dim]\n")

    except asyncio.CancelledError:
        pass  # KeyboardInterrupt caught in sync wrapper; CancelledError is cleanup only
    except typer.Exit:
        raise
    except Exception as e:
        from planecompose.utils.errors import handle_api_error

        handle_api_error(e, "import schema")
        raise typer.Exit(1)
    finally:
        if backend:
            await backend.disconnect()


async def _write_full_schema(
    ctx, types_data, remote_states, remote_labels, property_maps, remote_workflows=None,
    cycles_raw=None, modules_raw=None,
):
    """Write full schema files from remote data.

    Writes schema/types.yaml, schema/states.yaml, schema/workflows.yaml,
    schema/labels.yaml with remote IDs embedded. Cycles and modules go to
    work/cycles.yaml and work/modules.yaml (operational data, not schema/).

    Uses remote_workflows (from backend.fetch_workflows) when provided so the
    Default Workflow (and any project-defined workflows) actually land in
    workflows.yaml — previously this function hardcoded a single synthetic
    'default' workflow and never queried the API.

    cycles_raw / modules_raw: raw SDK objects from list_cycles_raw /
    list_modules_raw. When provided, work/cycles.yaml and work/modules.yaml
    are written with definition metadata but no work_items membership (schema
    import does not import work item assignments).
    """
    from planecompose.cli.clone_helpers import (
        write_types_yaml,
        write_workflows_yaml,
        write_cycles_yaml,
        write_modules_yaml,
    )
    from planecompose.parser.schema_writer import write_states_yaml, write_labels_yaml, WORKFLOWS_YAML_HEADER
    from planecompose.parser.schema_writer import dump_yaml

    schema_dir = ctx.root_path / "schema"
    schema_dir.mkdir(exist_ok=True)

    # --- types.yaml ---
    write_types_yaml(ctx.root_path, types_data, property_maps)

    # --- states.yaml ---
    write_states_yaml(schema_dir / "states.yaml", remote_states)

    # --- workflows.yaml ---
    type_id_to_name = {
        wit["id"]: wit["name"] for wit in types_data if wit.get("id") and wit.get("name")
    }
    if remote_workflows:
        write_workflows_yaml(ctx.root_path, list(remote_workflows), type_id_to_name)
    else:
        # No workflows on remote — write a clean empty doc with header.
        dump_yaml(schema_dir / "workflows.yaml", {"workflows": {}}, header=WORKFLOWS_YAML_HEADER)

    # --- labels.yaml ---
    write_labels_yaml(schema_dir / "labels.yaml", remote_labels)

    # --- cycles.yaml ---
    # Write with empty work_items map: schema import captures definitions only,
    # not work item membership. A subsequent `plane pull` can populate items.
    if cycles_raw is not None:
        write_cycles_yaml(ctx.root_path, cycles_raw, {})

    # --- modules.yaml ---
    if modules_raw is not None:
        write_modules_yaml(ctx.root_path, modules_raw, {})


async def _merge_schema(
    ctx,
    types_data,
    remote_states,
    remote_labels,
    property_maps,
    remote_type_map,
    remote_state_map,
    remote_label_map,
    remote_workflows=None,
):
    """Merge remote schema into local (additive only)."""
    import yaml

    from planecompose.cli.clone_helpers import build_type_config
    from planecompose.parser.schema_writer import dump_yaml, TYPES_YAML_HEADER, LABELS_YAML_HEADER

    schema_dir = ctx.root_path / "schema"
    added_types = []
    added_states = []
    added_labels = []
    added_workflows = []

    # Get existing local names (case-insensitive)
    local_type_names = {t.name.lower() for t in ctx.types}
    local_state_names = {s.name.lower() for s in ctx.states}
    local_label_names = {lbl.name.lower() for lbl in ctx.labels}

    # Find types only in remote
    new_types = [
        t for t in types_data if t.get("name") and t["name"].lower() not in local_type_names
    ]
    if new_types:
        # Load existing types.yaml
        types_file = schema_dir / "types.yaml"
        existing_types: dict[str, Any] = {}
        if types_file.exists():
            loaded = yaml.safe_load(types_file.read_text()) or {}
            # Extract from root key if present (new format: work_item_types: {...})
            if isinstance(loaded, dict) and 'work_item_types' in loaded and len(loaded) == 1:
                loaded = loaded['work_item_types']
            # Handle both dict and list formats
            if isinstance(loaded, dict):
                existing_types = loaded
            elif isinstance(loaded, list):
                existing_types = {
                    t.get("name", f"type_{i}"): t
                    for i, t in enumerate(loaded)
                    if isinstance(t, dict)
                }

        # If workspace-level WIT is enabled, map new types to workspace WIT IDs
        workspace_features = ctx.workspace_config.workspace_features if ctx.workspace_config else {}
        if workspace_features.get("work_item_types", False):
            # Build workspace WIT name -> id mapping
            workspace_wit_dict = (
                ctx.workspace_config.work_item_types if ctx.workspace_config else []
            )
            ws_type_name_to_id = {
                wit.get("name"): wit.get("id")
                for wit in workspace_wit_dict
                if wit.get("name") and wit.get("id")
            }

            # Inject workspace_item_type_id into new types
            for wit in new_types:
                wit_name = wit.get("name")
                if wit_name and wit_name in ws_type_name_to_id:
                    wit["workspace_item_type_id"] = ws_type_name_to_id[wit_name]

        # Add new types
        for wit in new_types:
            existing_types[wit["name"]] = build_type_config(wit, property_maps)
            added_types.append(wit["name"])

        dump_yaml(types_file, {"work_item_types": existing_types}, header=TYPES_YAML_HEADER)

    # Find states only in remote
    new_states = [s for s in remote_states if s.name.lower() not in local_state_names]
    if new_states:
        # Load existing workflows.yaml
        workflows_file = schema_dir / "workflows.yaml"
        existing_workflows: dict[str, Any] = {"default": {"states": []}}
        if workflows_file.exists():
            loaded = yaml.safe_load(workflows_file.read_text()) or {}
            # Extract from root key if present (new format: workflows: {...})
            if isinstance(loaded, dict) and 'workflows' in loaded and len(loaded) == 1:
                existing_workflows = loaded['workflows']
            elif isinstance(loaded, dict):
                existing_workflows = loaded
            else:
                existing_workflows = {"default": {"states": []}}

        # Ensure "default" workflow exists
        if "default" not in existing_workflows:
            existing_workflows["default"] = {"states": []}

        # Add new states
        for state in new_states:
            existing_workflows["default"]["states"].append(
                {
                    "name": state.name,
                    "group": state.group,
                    "color": state.color or "#808080",
                }
            )
            added_states.append(state.name)

        with open(workflows_file, "w") as f:
            yaml.dump(
                {"workflows": existing_workflows}, f, default_flow_style=False, sort_keys=False, allow_unicode=True
            )

    # Find labels only in remote
    new_labels = [lbl for lbl in remote_labels if lbl.name.lower() not in local_label_names]
    if new_labels:
        # Load existing labels.yaml
        labels_file = schema_dir / "labels.yaml"
        existing_labels = []
        if labels_file.exists():
            loaded = yaml.safe_load(labels_file.read_text()) or {}
            # Extract from root key if present (new format: labels: [...])
            if isinstance(loaded, dict) and 'labels' in loaded and len(loaded) == 1:
                loaded = loaded['labels']
            if isinstance(loaded, list):
                existing_labels = loaded
            elif isinstance(loaded, dict):
                if "groups" in loaded:
                    # Convert grouped format to flat
                    for group_data in loaded.get("groups", {}).values():
                        for lbl in group_data.get("labels", []):
                            existing_labels.append(lbl)
                # If loaded is just a dict of labels, keep it as a list (labels should be a list, not a dict)
                # Note: this shouldn't normally happen, but handle it gracefully

        # Add new labels
        for label in new_labels:
            label_data = {"name": label.name}
            if label.color:
                label_data["color"] = label.color
            existing_labels.append(label_data)
            added_labels.append(label.name)

        dump_yaml(labels_file, {"labels": existing_labels}, header=LABELS_YAML_HEADER)

    # Find workflows only in remote (by name, case-insensitive)
    if remote_workflows:
        local_workflow_names = {w.name.lower() for w in ctx.workflows}
        new_workflows = [
            w for w in remote_workflows if w.name.lower() not in local_workflow_names
        ]
        if new_workflows:
            # Load existing workflows.yaml (already loaded above for states, but re-load cleanly)
            workflows_file = schema_dir / "workflows.yaml"
            existing_wf_data: dict[str, Any] = {}
            if workflows_file.exists():
                loaded = yaml.safe_load(workflows_file.read_text()) or {}
                if isinstance(loaded, dict) and 'workflows' in loaded and len(loaded) == 1:
                    existing_wf_data = loaded['workflows']
                elif isinstance(loaded, dict):
                    existing_wf_data = loaded

            for wf in new_workflows:
                # Build a minimal workflow entry: name → states list
                wf_entry: dict[str, Any] = {}
                if wf.remote_id:
                    wf_entry["id"] = wf.remote_id
                if wf.description:
                    wf_entry["description"] = wf.description
                # Include states if available
                if wf.states:
                    wf_entry["states"] = [
                        {k: v for k, v in {
                            "name": s.name,
                            "group": s.group,
                            "color": s.color,
                        }.items() if v}
                        for s in wf.states
                    ]
                # Include work_item_types if available
                if getattr(wf, "work_item_types", None):
                    wf_entry["work_item_types"] = list(wf.work_item_types)

                existing_wf_data[wf.name] = wf_entry
                added_workflows.append(wf.name)

            with open(workflows_file, "w") as f:
                yaml.dump(
                    {"workflows": existing_wf_data},
                    f,
                    default_flow_style=False,
                    sort_keys=False,
                    allow_unicode=True,
                )

    return added_types, added_states, added_labels, added_workflows


@app.command()
def sync(
    project: str | None = typer.Argument(
        None, help="Project folder name. Combined with --path if provided."
    ),
    path: Path | None = typer.Option(
        None, "--path", help="Parent directory containing the project (default: current directory)"
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", "-n", help="Show what would be synced without making changes"
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Sync without confirmation"),
):
    """
    Declarative schema sync - make remote match local EXACTLY.

    This command:
    - Creates types/states/labels that exist in local but not remote
    - Updates types/states/labels that differ between local and remote
    - DELETES types/states/labels that exist in remote but not local

    WARNING: This is a DECLARATIVE operation. Use with caution!

    Examples:
        plane schema sync                 # Sync current directory
        plane schema sync ./projects/api  # Sync specific project
    For additive-only sync (no deletions), use 'plane schema push' instead.

    NOTE: Delete operations are not yet supported by the Plane API.
    This command will show what WOULD be deleted but won't actually delete.
    """
    resolved_path = (
        (path or Path.cwd()).resolve() / project if project else (path.resolve() if path else None)
    )
    try:
        asyncio.run(_sync_schema(resolved_path, dry_run, force))
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled.[/yellow]")
        raise typer.Exit(130)


async def _sync_schema(path: Path | None, dry_run: bool, force: bool):
    """Async implementation of declarative schema sync."""
    backend = None
    try:
        ctx = require_project_context(path)
        from planecompose.state.manager import StateManager

        with create_progress() as (progress, task):
            ctx, backend = await connect_backend(ctx, progress=progress, task=task)
            (
                remote_types,
                remote_states,
                remote_labels,
                _remote_workflows,  # not used in declarative sync path
                remote_modules,
                remote_cycles,
            ) = await fetch_remote_schema(backend, progress=progress, task=task)

        # Build maps for comparison (case-insensitive)
        _, remote_type_map = build_schema_maps(ctx.types, remote_types)
        _, remote_state_map = build_schema_maps(ctx.states, remote_states)
        _, remote_label_map = build_schema_maps(ctx.labels, remote_labels)

        # Calculate changes
        types_to_create, types_to_update, types_to_delete = find_schema_changes(
            ctx.types, remote_types
        )
        states_to_create, states_to_update, states_to_delete = find_schema_changes(
            ctx.states, remote_states
        )
        labels_to_create, labels_to_update, labels_to_delete = find_schema_changes(
            ctx.labels, remote_labels
        )

        # Resolve workspace-level WIT flag once — used in both display and apply sections.
        workspace_wit_enabled = (
            ctx.workspace_config
            and ctx.workspace_config.workspace_features
            and ctx.workspace_config.workspace_features.get("work_item_types", False)
        )

        # Display sync plan
        console.print("\n[bold]Declarative Schema Sync Plan[/bold]\n")

        has_changes = False

        if types_to_create or types_to_update:
            console.print("[bold cyan]Types:[/bold cyan]")
            if types_to_create:
                console.print(
                    f"  [green]+[/green] Create: {', '.join(t.name for t in types_to_create)}"
                )
                has_changes = True
            if types_to_update:
                console.print(
                    f"  [yellow]~[/yellow] Update: {', '.join(t.name for t in types_to_update)}"
                )
                has_changes = True
            console.print()

        if types_to_delete:
            console.print("[bold red]Types to DELETE:[/bold red]")
            for t in types_to_delete:
                console.print(f"  [red]-[/red] Delete: {t.name}")
            if workspace_wit_enabled:
                console.print(
                    "  [yellow]⚠️  Workspace-level WIT enabled — type deletion skipped (use Plane UI)[/yellow]"
                )
            console.print()
            has_changes = True

        if states_to_create or states_to_update:
            console.print("[bold cyan]States:[/bold cyan]")
            if states_to_create:
                console.print(
                    f"  [green]+[/green] Create: {', '.join(s.name for s in states_to_create)}"
                )
                has_changes = True
            if states_to_update:
                console.print(
                    f"  [yellow]~[/yellow] Update: {', '.join(s.name for s in states_to_update)}"
                )
                has_changes = True
            console.print()

        if states_to_delete:
            console.print("[bold red]States to DELETE:[/bold red]")
            for s in states_to_delete:
                if s.remote_id:
                    console.print(f"  [red]-[/red] Delete: {s.name}")
                else:
                    console.print(f"  [red]-[/red] Delete: {s.name} [dim](no remote ID — will skip)[/dim]")
            console.print()
            has_changes = True

        if labels_to_create or labels_to_update:
            console.print("[bold cyan]Labels:[/bold cyan]")
            if labels_to_create:
                console.print(
                    f"  [green]+[/green] Create: {', '.join(lbl.name for lbl in labels_to_create)}"
                )
                has_changes = True
            if labels_to_update:
                console.print(
                    f"  [yellow]~[/yellow] Update: {', '.join(lbl.name for lbl in labels_to_update)}"
                )
                has_changes = True
            console.print()

        if labels_to_delete:
            console.print("[bold red]Labels to DELETE:[/bold red]")
            for lbl in labels_to_delete:
                if lbl.remote_id:
                    console.print(f"  [red]-[/red] Delete: {lbl.name}")
                else:
                    console.print(f"  [red]-[/red] Delete: {lbl.name} [dim](no remote ID — will skip)[/dim]")
            console.print()
            has_changes = True

        if not has_changes:
            console.print("[green]✓ Schema already in sync![/green]\n")
            return

        if dry_run:
            console.print("[yellow]Dry run mode - no changes applied[/yellow]\n")
            return

        # Confirm before syncing
        if not force and has_changes:
            from rich.prompt import Confirm

            # Only count ops we can actually execute (items with remote IDs for deletes)
            deletable_types = (
                [t for t in types_to_delete if t.remote_id]
                if not workspace_wit_enabled else []
            )
            deletable_states = [s for s in states_to_delete if s.remote_id]
            deletable_labels = [lbl for lbl in labels_to_delete if lbl.remote_id]
            total_changes = (
                len(types_to_create)
                + len(types_to_update)
                + len(deletable_types)
                + len(states_to_create)
                + len(states_to_update)
                + len(deletable_states)
                + len(labels_to_create)
                + len(labels_to_update)
                + len(deletable_labels)
            )

            if not Confirm.ask(f"Apply {total_changes} changes to remote schema?"):
                console.print("[yellow]Cancelled[/yellow]")
                raise typer.Exit(0)

        # Apply changes
        if has_changes:
            console.print("\n[bold]Applying schema changes...[/bold]\n")
            state_manager = StateManager(ctx.root_path)
            synced_types: dict[str, str] = {}
            synced_states: dict[str, str] = {}
            synced_labels: dict[str, str] = {}

            # Push types (skip if workspace-level work_item_types are enabled)
            if workspace_wit_enabled:
                logger.warning(
                    "Skipping work item type creation: workspace-level work_item_types are enabled"
                )
                for type_def in types_to_create:
                    console.print(
                        f"  [yellow]⊘[/yellow] Skipping type {type_def.name}: workspace-level work_item_types enabled"
                    )
            else:
                for type_def in types_to_create:
                    try:
                        remote_id = await backend.create_type(type_def)
                        synced_types[type_def.name] = remote_id
                        console.print(f"  [green]✓[/green] Created type: {type_def.name}")
                    except Exception as e:
                        console.print(f"  [red]✗[/red] Failed type {type_def.name}: {e}")

            # Update types (skip if workspace-level work_item_types are enabled)
            if workspace_wit_enabled:
                for type_def in types_to_update:
                    console.print(
                        f"  [yellow]⊘[/yellow] Skipping type update {type_def.name}: workspace-level work_item_types enabled"
                    )
            else:
                for type_def in types_to_update:
                    try:
                        # Get remote ID (case-insensitive lookup)
                        remote_type = remote_type_map.get(type_def.name.lower())
                        remote_id = (getattr(remote_type, "remote_id", None) if remote_type else None) or ""
                        if remote_id:
                            await backend.update_type(remote_id, type_def)
                            synced_types[type_def.name] = remote_id
                            console.print(f"  [green]✓[/green] Updated type: {type_def.name}")
                        else:
                            console.print(
                                f"  [yellow]~[/yellow] Skipped type {type_def.name} (no remote ID)"
                            )
                    except Exception as e:
                        console.print(f"  [red]✗[/red] Failed type {type_def.name}: {e}")

            # Push states
            for state_def in states_to_create:
                try:
                    remote_id = await backend.create_state(state_def)
                    synced_states[state_def.name] = remote_id
                    console.print(f"  [green]✓[/green] Created state: {state_def.name}")
                except Exception as e:
                    console.print(f"  [red]✗[/red] Failed state {state_def.name}: {e}")

            # Update states
            for state_def in states_to_update:
                try:
                    remote_state = remote_state_map.get(state_def.name.lower())
                    remote_id = (getattr(remote_state, "remote_id", None) if remote_state else None) or ""
                    if remote_id:
                        await backend.update_state(remote_id, state_def)
                        synced_states[state_def.name] = remote_id
                        console.print(f"  [green]✓[/green] Updated state: {state_def.name}")
                    else:
                        console.print(
                            f"  [yellow]~[/yellow] Skipped state {state_def.name} (no remote ID)"
                        )
                except Exception as e:
                    console.print(f"  [red]✗[/red] Failed state {state_def.name}: {e}")

            # Push labels
            for label_def in labels_to_create:
                try:
                    remote_id = await backend.create_label(label_def)
                    synced_labels[label_def.name] = remote_id
                    console.print(f"  [green]✓[/green] Created label: {label_def.name}")
                except Exception as e:
                    console.print(f"  [red]✗[/red] Failed label {label_def.name}: {e}")

            # Update labels
            for label_def in labels_to_update:
                try:
                    remote_label = remote_label_map.get(label_def.name.lower())
                    remote_id = (getattr(remote_label, "remote_id", None) if remote_label else None) or ""
                    if remote_id:
                        await backend.update_label(remote_id, label_def)
                        synced_labels[label_def.name] = remote_id
                        console.print(f"  [green]✓[/green] Updated label: {label_def.name}")
                    else:
                        console.print(
                            f"  [yellow]~[/yellow] Skipped label {label_def.name} (no remote ID)"
                        )
                except Exception as e:
                    console.print(f"  [red]✗[/red] Failed label {label_def.name}: {e}")

            # Delete types (only when workspace-level WIT is not enabled)
            deleted_types: list[str] = []
            if not workspace_wit_enabled:
                for type_def in types_to_delete:
                    remote_id = getattr(type_def, "remote_id", None) or ""
                    if not remote_id:
                        console.print(
                            f"  [yellow]⊘[/yellow] Skipped delete {type_def.name} (no remote ID)"
                        )
                        continue
                    try:
                        await backend.delete_type(remote_id)
                        deleted_types.append(type_def.name)
                        console.print(f"  [green]✓[/green] Deleted type: {type_def.name}")
                    except ValueError:
                        console.print(
                            f"  [yellow]⊘[/yellow] Skipped delete {type_def.name} (default type)"
                        )
                    except Exception as e:
                        console.print(f"  [red]✗[/red] Failed delete {type_def.name}: {e}")
            elif types_to_delete:
                console.print(
                    "[yellow]⚠️  Type deletions skipped (workspace-level WIT — use Plane UI)[/yellow]"
                )

            # Delete states
            deleted_states: list[str] = []
            for state_def in states_to_delete:
                remote_id = getattr(state_def, "remote_id", None) or ""
                if not remote_id:
                    console.print(
                        f"  [yellow]⊘[/yellow] Skipped delete {state_def.name} (no remote ID)"
                    )
                    continue
                try:
                    await backend.delete_state(remote_id)
                    deleted_states.append(state_def.name)
                    console.print(f"  [green]✓[/green] Deleted state: {state_def.name}")
                except Exception as e:
                    console.print(f"  [red]✗[/red] Failed delete state {state_def.name}: {e}")

            # Delete labels
            deleted_labels: list[str] = []
            for label_def in labels_to_delete:
                remote_id = getattr(label_def, "remote_id", None) or ""
                if not remote_id:
                    console.print(
                        f"  [yellow]⊘[/yellow] Skipped delete {label_def.name} (no remote ID)"
                    )
                    continue
                try:
                    await backend.delete_label(remote_id)
                    deleted_labels.append(label_def.name)
                    console.print(f"  [green]✓[/green] Deleted label: {label_def.name}")
                except Exception as e:
                    console.print(f"  [red]✗[/red] Failed delete label {label_def.name}: {e}")

            console.print()
            console.print("[green]✓ Schema sync complete[/green]")
            applied_changes = bool(
                synced_types or synced_states or synced_labels
                or deleted_types or deleted_states or deleted_labels
            )
            state_manager.update_schema_state(
                types=synced_types or None,
                states=synced_states or None,
                labels=synced_labels or None,
                update_last_sync=applied_changes,
            )
            console.print()

    except asyncio.CancelledError:
        pass  # KeyboardInterrupt caught in sync wrapper; CancelledError is cleanup only
    except typer.Exit:
        raise
    except Exception as e:
        from planecompose.utils.errors import handle_api_error

        handle_api_error(e, "sync schema")
        raise typer.Exit(1)
    finally:
        if backend:
            await backend.disconnect()


@app.command()
def diff(
    project: str | None = typer.Argument(
        None, help="Project folder name. Combined with --path if provided."
    ),
    path: Path | None = typer.Option(
        None, "--path", help="Parent directory containing the project (default: current directory)"
    ),
    exit_code: bool = typer.Option(
        False,
        "--exit-code",
        help="Use differentiated exit codes for CI/CD: 0=no diff, 1=error, 2=differences found",
    ),
):
    """
    Compare local schema with remote schema.

    Shows what would change if you pushed local schema or pulled remote schema.

    Exit codes (with --exit-code):
        0: Schemas are in sync (no differences)
        1: Error occurred
        2: Differences found

    Examples:
        plane schema diff                              # Diff current directory
        plane schema diff tcomp1                      # Diff cwd/tcomp1
        plane schema diff tcomp1 --path ./projects    # Diff ./projects/tcomp1
        plane schema diff --exit-code                 # CI-friendly exit codes
    """
    resolved_path = (
        (path or Path.cwd()).resolve() / project if project else (path.resolve() if path else None)
    )
    try:
        asyncio.run(_diff_schema(resolved_path, exit_code))
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled.[/yellow]")
        raise typer.Exit(130)


async def _diff_schema(path: Path | None = None, exit_code_mode: bool = False):
    """Async implementation of schema diff."""
    backend = None
    try:
        ctx = require_project_context(path)

        with create_progress() as (progress, task):
            ctx, backend = await connect_backend(ctx, progress=progress, task=task)
            (
                remote_types,
                remote_states,
                remote_labels,
                remote_workflows,
                remote_modules,
                remote_cycles,
            ) = await fetch_remote_schema(backend, progress=progress, task=task)

            # Fetch remote features for comparison (non-blocking)
            remote_features: dict[str, bool] = {}
            try:
                remote_features = await backend.get_project_features()
            except Exception as e:
                logger.debug(f"Could not fetch remote features for diff: {e}")

        # Compare schemas using ID-aware matching
        console.print("\n[bold]Schema Comparison: Local ↔ Remote[/bold]\n")

        # Compare types, states, labels, modules
        only_local_types, only_remote_types, types_in_both, renamed_types = compare_schema_items(
            ctx.types, remote_types
        )
        print_schema_section(
            "Types", only_local_types, only_remote_types, types_in_both, renamed_types
        )

        only_local_states, only_remote_states, states_in_both, renamed_states = (
            compare_schema_items(ctx.states, remote_states)
        )
        print_schema_section(
            "States", only_local_states, only_remote_states, states_in_both, renamed_states
        )

        only_local_labels, only_remote_labels, labels_in_both, renamed_labels = (
            compare_schema_items(ctx.labels, remote_labels)
        )
        print_schema_section(
            "Labels", only_local_labels, only_remote_labels, labels_in_both, renamed_labels
        )

        only_local_modules, only_remote_modules, modules_in_both, renamed_modules = (
            compare_schema_items(ctx.modules, remote_modules)
        )
        print_schema_section(
            "Modules", only_local_modules, only_remote_modules, modules_in_both, renamed_modules
        )

        # Compare workflows - check existence, work_item_types, states, and transition-rule changes
        only_local_workflows, only_remote_workflows, workflows_in_both, renamed_workflows = (
            compare_schema_items(ctx.workflows, remote_workflows)
        )

        # Detect content changes in matched workflows using shared helper.
        # NOTE: Transition rule changes are NOT pushable via CLI (no PATCH endpoint;
        # scripts are internal-only). We surface them for visibility only.
        wf_changes = detect_workflow_changes(ctx.workflows, remote_workflows)
        workflows_with_wit_changes = wf_changes["wit_changes"]
        workflows_with_state_changes = wf_changes["state_changes"]
        workflows_with_rule_changes = wf_changes["rule_changes"]

        # workflows_in_both is a COUNT of matched workflows — not a list of changed items.
        # It must NOT be used as a change indicator (it's always > 0 after clone/push).
        workflows_have_changes = bool(
            only_local_workflows
            or only_remote_workflows
            or renamed_workflows
            or workflows_with_wit_changes
            or workflows_with_state_changes
            or workflows_with_rule_changes
        )
        if workflows_have_changes or workflows_in_both:
            console.print("[bold cyan]Workflows:[/bold cyan]")
            for local_name, remote_name in renamed_workflows:
                console.print(
                    f'  [yellow]~[/yellow] {local_name} → remote: "{remote_name}" (modified remotely)'
                )
            for wf_name, local_wits, remote_wits in workflows_with_wit_changes:
                console.print(f"  [yellow]~[/yellow] {wf_name}: work_item_types changed")
                # Convention: green "+" = in local only (will be added on push)
                #             red   "-" = in remote only (will be removed on push)
                if local_wits and not remote_wits:
                    console.print(f"    [green]  + Added: {', '.join(sorted(local_wits))}")
                elif not local_wits and remote_wits:
                    console.print(f"    [red]  - Removed: {', '.join(sorted(remote_wits))}")
                else:
                    added = local_wits - remote_wits
                    removed = remote_wits - local_wits
                    if added:
                        console.print(f"    [green]  + Added: {', '.join(sorted(added))}")
                    if removed:
                        console.print(f"    [red]  - Removed: {', '.join(sorted(removed))}")
            for wf_name, local_states, remote_states_set in workflows_with_state_changes:
                console.print(f"  [yellow]~[/yellow] {wf_name}: states changed")
                added = local_states - remote_states_set
                removed = remote_states_set - local_states
                if added:
                    console.print(f"    [green]  + Added: {', '.join(sorted(added))}")
                if removed:
                    console.print(f"    [red]  - Removed: {', '.join(sorted(removed))}")
            for wf_name, rule_descs in workflows_with_rule_changes:
                console.print(
                    f"  [yellow]~[/yellow] {wf_name}: transition conditions changed"
                )
                for desc in rule_descs:
                    console.print(f"    [yellow]  ~ {desc}[/yellow]")
            if only_local_workflows:
                console.print(
                    f"  [green]+[/green] Only in local: {', '.join(only_local_workflows)}"
                )
            if only_remote_workflows:
                console.print(f"  [red]-[/red] Only in remote: {', '.join(only_remote_workflows)}")
            if workflows_in_both and not workflows_have_changes:
                console.print(f"  [dim]= {workflows_in_both} workflow(s) in sync[/dim]")
            console.print()

        # Compare cycles
        only_local_cycles, only_remote_cycles, cycles_in_both, renamed_cycles = (
            compare_schema_items(ctx.cycles, remote_cycles)
        )
        print_schema_section(
            "Cycles", only_local_cycles, only_remote_cycles, cycles_in_both, renamed_cycles
        )

        # Compare project metadata (name, description, network, timezone) from plane.yaml
        metadata_diffs: list[tuple[str, str, str]] = []  # (field, local_val, remote_val)
        if ctx.config.project_uuid:
            try:
                remote_project = await backend.retrieve_project(
                    ctx.config.workspace, ctx.config.project_uuid
                )
                from planecompose.core.models import network_to_str
                _remote_network = network_to_str(remote_project.network) if remote_project.network is not None else "public"
                _meta_checks = [
                    ("name", ctx.config.project_name, remote_project.name),
                    ("description", ctx.config.project_description or "", remote_project.description or ""),
                    ("network", ctx.config.project_network or "public", _remote_network),
                    ("timezone", ctx.config.project_timezone or "UTC", remote_project.timezone or "UTC"),
                ]
                for field, local_val, remote_val in _meta_checks:
                    if local_val != remote_val:
                        metadata_diffs.append((field, str(local_val), str(remote_val)))
            except Exception as e:
                logger.debug(f"Could not fetch remote project for metadata diff: {e}")

        if metadata_diffs:
            console.print("[bold cyan]Project Metadata (plane.yaml):[/bold cyan]")
            for field, local_val, remote_val in metadata_diffs:
                console.print(
                    f"  [yellow]~[/yellow] {field}: "
                    f"local=[green]{local_val}[/green], remote=[red]{remote_val}[/red]"
                )
            console.print()

        # Compare features (only when local features.yaml is present)
        feature_diffs: list[tuple[str, bool, bool]] = []  # (name, local_val, remote_val)
        features_in_sync = 0
        local_features: dict[str, bool] = {}
        _local_features_path = ctx.schema_path / "features.yaml"
        if _local_features_path.exists():
            import yaml as _fyaml
            _fdata = _fyaml.safe_load(open(_local_features_path)) or {}
            local_features = _fdata.get("features", {})

        if local_features and remote_features:
            # Compare every key that appears in local (which is always the full set
            # after write_features_yaml). Keys absent from the API response are treated
            # as False — the server's implicit default for a disabled/unknown feature.
            all_keys = sorted(set(local_features) | set(remote_features))
            for key in all_keys:
                local_feat_val = local_features.get(key)
                if local_feat_val is None:
                    continue  # key only in remote — no local opinion, skip
                remote_feat_val = remote_features.get(key, False)  # absent = false
                if local_feat_val != remote_feat_val:
                    feature_diffs.append((key, local_feat_val, remote_feat_val))
                else:
                    features_in_sync += 1

            console.print("[bold cyan]Features:[/bold cyan]")
            for feat_name, local_feat_val, remote_feat_val in feature_diffs:
                local_str = "[green]true[/green]" if local_feat_val else "[red]false[/red]"
                remote_str = "[green]true[/green]" if remote_feat_val else "[red]false[/red]"
                # Arrow shows local → remote (what push will change remote to)
                console.print(
                    f"  [yellow]~[/yellow] {feat_name}: "
                    f"local={local_str}, remote={remote_str}"
                )
            if features_in_sync:
                console.print(f"  [dim]= {features_in_sync} feature(s) in sync[/dim]")
            elif not feature_diffs:
                console.print("  [dim]= 0 feature(s) in sync[/dim]")
            console.print()

        # Summary
        has_diff = bool(
            metadata_diffs
            or only_local_types
            or only_remote_types
            or renamed_types
            or only_local_states
            or only_remote_states
            or renamed_states
            or only_local_labels
            or only_remote_labels
            or renamed_labels
            or only_local_modules
            or only_remote_modules
            or renamed_modules
            or only_local_workflows
            or only_remote_workflows
            or renamed_workflows
            or workflows_with_wit_changes
            or workflows_with_state_changes
            or workflows_with_rule_changes
            or only_local_cycles
            or only_remote_cycles
            or renamed_cycles
            or feature_diffs
        )

        if not has_diff:
            console.print("[green]✓ Schemas are in sync![/green]\n")
        else:
            console.print("[yellow]Actions:[/yellow]")
            console.print("  [cyan]plane schema push[/cyan] - Push local changes to remote")
            console.print(
                "  [cyan]plane schema import --merge[/cyan] - Add remote-only schema locally"
            )
            console.print(
                "  [cyan]plane schema import --force[/cyan] - Replace local schema with remote"
            )
            console.print()
            # --exit-code: exit 2 if differences found
            if exit_code_mode:
                raise typer.Exit(2)

    except asyncio.CancelledError:
        pass  # KeyboardInterrupt caught in sync wrapper; CancelledError is cleanup only
    except typer.Exit:
        raise
    except Exception as e:
        from planecompose.utils.errors import handle_api_error

        handle_api_error(e, "diff schema")
        raise typer.Exit(1)
    finally:
        if backend:
            await backend.disconnect()
