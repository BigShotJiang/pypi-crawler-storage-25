"""Pre-push validation for work items against schema.

Validates that work items reference valid types, states, and labels
before sending to the API, providing clear error messages.
"""
import re
from dataclasses import dataclass, field

from planecompose.backend.cache import SchemaCache
from planecompose.core.models import FieldType, WorkItem

# Valid priority values accepted by the Plane API
VALID_PRIORITIES = {"urgent", "high", "medium", "low", "none"}

# Pre-compiled date pattern
_DATE_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")


@dataclass
class ValidationIssue:
    """A single validation issue."""
    item_title: str
    field: str
    message: str
    severity: str = "error"  # "error" or "warning"


@dataclass
class ValidationResult:
    """Result of validating work items."""
    issues: list[ValidationIssue] = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        return not any(i.severity == "error" for i in self.issues)

    @property
    def error_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "error")

    @property
    def warning_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "warning")


def validate_work_items(
    items: list[WorkItem],
    cache: SchemaCache | None = None,
) -> ValidationResult:
    """
    Validate work items against the schema cache.

    Checks:
    - Type exists in schema
    - State exists in schema
    - Labels exist in schema
    - Priority is a valid value
    - Date formats are YYYY-MM-DD
    - No duplicate IDs across items

    Args:
        items: Work items to validate
        cache: Loaded schema cache with types/states/labels (optional for
               standalone validation without a remote connection)

    Returns:
        ValidationResult with any issues found
    """
    result = ValidationResult()

    has_cache = cache is not None and cache.is_loaded
    if cache is not None and not cache.is_loaded:
        result.issues.append(ValidationIssue(
            item_title="(all)",
            field="schema",
            message="Schema cache not loaded, skipping schema validation",
            severity="warning",
        ))

    # Collect all items (including nested children) for duplicate ID check
    all_items = _collect_items(items)

    # Check for duplicate IDs
    _check_duplicate_ids(all_items, result)

    # Check for circular parent references
    _check_circular_parents(all_items, result)

    for item in all_items:
        _validate_item(item, cache if has_cache else None, result)

    return result


def _check_duplicate_ids(items: list[WorkItem], result: ValidationResult) -> None:
    """Check for duplicate user-provided IDs across all items."""
    seen_ids: dict[str, str] = {}  # id -> first item title
    for item in items:
        if item.id:
            if item.id in seen_ids:
                result.issues.append(ValidationIssue(
                    item_title=item.title[:50],
                    field="id",
                    message=f"Duplicate ID '{item.id}' (also used by '{seen_ids[item.id]}')",
                ))
            else:
                seen_ids[item.id] = item.title[:50]


def _check_circular_parents(items: list[WorkItem], result: ValidationResult) -> None:
    """Check for circular parent references (A parent of B, B parent of A)."""
    # Build parent graph: child_id -> parent_id
    parent_map: dict[str, str] = {}
    title_map: dict[str, str] = {}  # id -> title for error messages

    for item in items:
        if item.id:
            title_map[item.id] = item.title[:50]
        if item.id and item.parent:
            # Self-parenthood check
            if item.id == item.parent:
                result.issues.append(ValidationIssue(
                    item_title=item.title[:50],
                    field="parent",
                    message=f"Item '{item.id}' references itself as parent",
                ))
                continue
            parent_map[item.id] = item.parent

    # Detect cycles using visited-set traversal
    visited: set[str] = set()
    for start_id in parent_map:
        if start_id in visited:
            continue
        path: list[str] = []
        current = start_id
        path_set: set[str] = set()
        while current in parent_map and current not in path_set:
            path.append(current)
            path_set.add(current)
            current = parent_map[current]

        if current in path_set:
            # Found a cycle - report it
            cycle_start = path.index(current) if current in path else -1
            if cycle_start >= 0:
                cycle = path[cycle_start:] + [current]
                cycle_display = " -> ".join(cycle)
                result.issues.append(ValidationIssue(
                    item_title=title_map.get(current, current),
                    field="parent",
                    message=f"Circular parent reference detected: {cycle_display}",
                ))

        visited.update(path_set)


def _collect_items(items: list[WorkItem]) -> list[WorkItem]:
    """Collect work items and all descendants recursively."""
    collected: list[WorkItem] = []
    for item in items:
        collected.append(item)
        if item.children:
            collected.extend(_collect_items(item.children))
    return collected


def _validate_item(
    item: WorkItem,
    cache: SchemaCache | None,
    result: ValidationResult,
) -> None:
    """Validate a single work item."""
    title = item.title[:50]

    # Validate type (only if cache available)
    if cache and item.type and not cache.has_type(item.type):
        result.issues.append(ValidationIssue(
            item_title=title,
            field="type",
            message=f"Unknown type '{item.type}'",
        ))

    # Validate state (only if cache available)
    if cache and item.state and not cache.has_state(item.state):
        result.issues.append(ValidationIssue(
            item_title=title,
            field="state",
            message=f"Unknown state '{item.state}'",
        ))

    # Validate labels (only if cache available)
    if cache:
        for label in item.labels:
            if not cache.has_label(label):
                result.issues.append(ValidationIssue(
                    item_title=title,
                    field="labels",
                    message=f"Unknown label '{label}'",
                ))

        _validate_properties(item, cache, result, title)

    # Validate priority
    if item.priority and item.priority.lower() not in VALID_PRIORITIES:
        result.issues.append(ValidationIssue(
            item_title=title,
            field="priority",
            message=(
                f"Invalid priority '{item.priority}'. "
                f"Valid values: {', '.join(sorted(VALID_PRIORITIES))}"
            ),
        ))

    # Validate date format
    if item.start_date and not _DATE_PATTERN.match(item.start_date):
        result.issues.append(ValidationIssue(
            item_title=title,
            field="start_date",
            message=f"Invalid date format '{item.start_date}', expected YYYY-MM-DD",
        ))
    if item.due_date and not _DATE_PATTERN.match(item.due_date):
        result.issues.append(ValidationIssue(
            item_title=title,
            field="due_date",
            message=f"Invalid date format '{item.due_date}', expected YYYY-MM-DD",
        ))

    # Validate date range (start must be before due)
    if item.start_date and item.due_date:
        if (_DATE_PATTERN.match(item.start_date) and _DATE_PATTERN.match(item.due_date)
                and item.start_date > item.due_date):
            result.issues.append(ValidationIssue(
                item_title=title,
                field="due_date",
                message=f"Due date '{item.due_date}' is before start date '{item.start_date}'",
            ))

    # Validate assignees format (should be UUIDs or emails)
    _email_or_uuid = re.compile(
        r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$|^[^@\s]+@[^@\s]+\.[^@\s]+$',
        re.IGNORECASE,
    )
    for assignee in item.assignees:
        if not _email_or_uuid.match(assignee):
            result.issues.append(ValidationIssue(
                item_title=title,
                field="assignees",
                message=f"Invalid assignee '{assignee}': expected UUID or email address",
                severity="warning",
            ))

    if item.watchers:
        result.issues.append(ValidationIssue(
            item_title=title,
            field="watchers",
            message=(
                "The current Plane API integration does not support syncing "
                "'watchers'. Remove this field before pushing."
            ),
        ))

    if item.children:
        result.issues.append(ValidationIssue(
            item_title=title,
            field="children",
            message=(
                "Nested 'children' are not supported by the current push/apply "
                "pipeline. Flatten them into top-level work items first."
            ),
        ))

    # Warn about items without stable IDs
    if not item.id:
        result.issues.append(ValidationIssue(
            item_title=title,
            field="id",
            message=(
                "No 'id' field set. Editing this item's title will create "
                "a duplicate on next push. Consider adding a stable id."
            ),
            severity="warning",
        ))


def _validate_properties(
    item: WorkItem,
    cache: SchemaCache,
    result: ValidationResult,
    title: str,
) -> None:
    """Validate custom property names and option values for the selected type."""
    if not item.properties or not item.type:
        return

    type_def = next(
        (type_def for type_def in cache.types if type_def.name.lower() == item.type.lower()),
        None,
    )
    if type_def is None:
        return

    field_map = {
        field.name.lower(): field
        for field in type_def.fields or []
    }

    for prop_name, prop_value in item.properties.items():
        field = field_map.get(prop_name.lower())
        if field is None:
            result.issues.append(ValidationIssue(
                item_title=title,
                field="properties",
                message=f"Unknown property '{prop_name}' for type '{type_def.name}'",
            ))
            continue

        field_type = getattr(field.type, "value", field.type)
        if str(field_type).lower() != FieldType.OPTION.value:
            continue

        valid_options = {option.lower() for option in field.options or []}
        values = prop_value if isinstance(prop_value, list) else [prop_value]
        unknown_values = [
            str(value)
            for value in values
            if str(value).lower() not in valid_options
        ]
        if unknown_values:
            result.issues.append(ValidationIssue(
                item_title=title,
                field="properties",
                message=(
                    f"Unknown option(s) for property '{prop_name}': "
                    f"{', '.join(unknown_values)}"
                ),
            ))
