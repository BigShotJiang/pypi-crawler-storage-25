"""State management for Plane Compose.

This module provides centralized state management with:
- File locking for concurrent safety
- State versioning for future migrations
- Helper methods for state operations
"""
from planecompose.state.manager import StateManager, StateLock

__all__ = ['StateManager', 'StateLock']
