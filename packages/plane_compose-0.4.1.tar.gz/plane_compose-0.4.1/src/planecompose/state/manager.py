"""State manager with file locking for concurrent safety.

This module provides centralized state management for Plane Compose.
All state operations (load, save, update) should go through this manager.

Features:
- File locking to prevent concurrent corruption
- State versioning for future migrations
- Atomic writes to prevent partial state corruption
- Human-readable JSON format

IMPORTANT: This module assumes single-process access per project directory.
File locking protects against concurrent threads/coroutines within a single
process, but does NOT guarantee safety across multiple processes on NFS/Docker
volumes. CI/CD pipelines should serialize `plane push` per project.
"""
import json
import os
import sys
import threading
import time
from pathlib import Path
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterator

try:
    import fcntl
    HAS_FCNTL = True
except ImportError:
    HAS_FCNTL = False

from planecompose.core.models import SyncState, WorkItemState, WorkItem
from planecompose.exceptions import StateError
from planecompose.utils.logger import get_logger

logger = get_logger()

# Current state format version
STATE_VERSION = 1


def _utc_now_iso() -> str:
    """Return a normalized UTC ISO-8601 timestamp."""
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass
class StateLock:
    """Handle for a held state lock."""
    lock_file: Path
    file_handle: object
    acquired_at: float


class StateManager:
    """
    Manages sync state with file locking for concurrent safety.

    Usage:
        manager = StateManager(project_root)

        # Read state (no lock needed for read-only)
        state = manager.load()

        # Update state with locking
        with manager.lock():
            state = manager.load()
            state.work_items["key"] = new_item_state
            manager.save(state)

        # Or use convenience methods
        manager.update_work_item("key", work_item, remote_id, source, index)
    """

    # Per-path in-process thread locks — ensures same-process threads serialize
    # before competing for the file lock (Windows O_CREAT|O_EXCL uses PID, so
    # threads in the same process can't detect each other via stale-PID check).
    _thread_locks: dict[str, threading.Lock] = {}
    _thread_locks_mutex: threading.Lock = threading.Lock()

    @classmethod
    def _get_thread_lock(cls, root_path: Path) -> threading.Lock:
        key = str(root_path.resolve())
        with cls._thread_locks_mutex:
            if key not in cls._thread_locks:
                cls._thread_locks[key] = threading.Lock()
            return cls._thread_locks[key]

    def __init__(self, root_path: Path):
        """
        Initialize state manager.

        Args:
            root_path: Project root directory (contains .plane/)
        """
        self.root_path = root_path
        self.state_dir = root_path / ".plane"
        self.state_file = self.state_dir / "state.json"
        self.backup_file = self.state_dir / "state.json.bak"
        self.lock_file = self.state_dir / "state.lock"

    def exists(self) -> bool:
        """Check if state file exists."""
        return self.state_file.exists()

    def load(self) -> SyncState:
        """
        Load state from disk.

        Falls back to backup file if primary state file is corrupted.

        Returns:
            SyncState: The loaded state, or empty state if file doesn't exist

        Raises:
            StateError: If both state file and backup are corrupted
        """
        if not self.state_file.exists():
            return SyncState()

        try:
            return self._load_from(self.state_file)
        except StateError:
            # Primary file corrupted -- try backup
            if self.backup_file.exists():
                logger.warning(
                    "State file corrupted, restoring from backup"
                )
                try:
                    state = self._load_from(self.backup_file)
                    # Restore backup as primary
                    import shutil
                    shutil.copy2(self.backup_file, self.state_file)
                    return state
                except StateError:
                    pass
            raise StateError(
                "State file is corrupted and no valid backup exists. "
                "Run 'plane state reset' to start fresh."
            )

    def _load_from(self, path: Path) -> SyncState:
        """Load state from a specific file path."""
        try:
            with open(path, 'r') as f:
                data = json.load(f)

            # Check version and migrate if needed
            version = data.pop('_version', 1)
            if version > STATE_VERSION:
                raise StateError(
                    f"State file version {version} is newer than supported version {STATE_VERSION}. "
                    "Please update plane-compose."
                )

            # Convert work_items dict values to WorkItemState objects
            if 'work_items' in data:
                data['work_items'] = {
                    k: WorkItemState(**v) if isinstance(v, dict) else v
                    for k, v in data['work_items'].items()
                }

            return SyncState(**data)

        except json.JSONDecodeError as e:
            raise StateError(f"State file is corrupted ({path.name}): {e}")
        except StateError:
            raise
        except Exception as e:
            raise StateError(f"Failed to load state ({path.name}): {e}")

    def save(self, state: SyncState) -> None:
        """
        Save state to disk atomically.

        Creates a backup of the existing state before writing, then uses
        write-to-temp-then-rename pattern to prevent partial writes.

        Args:
            state: The state to save

        Raises:
            StateError: If save fails
        """
        self.state_dir.mkdir(parents=True, exist_ok=True)

        try:
            # Backup existing state before overwriting
            if self.state_file.exists():
                import shutil
                shutil.copy2(self.state_file, self.backup_file)

            # Prepare data with version
            data = state.model_dump()
            data['_version'] = STATE_VERSION

            # Write to temp file first (atomic write pattern)
            # Use NamedTemporaryFile for an unpredictable filename — avoids symlink attacks
            import tempfile as _tempfile
            with _tempfile.NamedTemporaryFile(
                mode='w',
                dir=self.state_dir,
                delete=False,
                suffix='.tmp',
                prefix='.state_',
            ) as tf:
                json.dump(data, tf, indent=2, default=str)
                tf.flush()
                os.fsync(tf.fileno())
                temp_file = Path(tf.name)

            # Atomic replace (os.replace works on Windows even if target exists;
            # Path.rename raises FileExistsError on Windows when target is present)
            os.replace(temp_file, self.state_file)

            logger.debug(f"Saved state with {len(state.work_items)} work items")

        except Exception as e:
            raise StateError(f"Failed to save state: {e}")

    @contextmanager
    def lock(self, timeout: float = 30.0) -> Iterator[StateLock]:
        """
        Acquire exclusive lock on state file.

        Usage:
            with manager.lock():
                state = manager.load()
                # ... modify state ...
                manager.save(state)

        Args:
            timeout: Maximum time to wait for lock (seconds)

        Yields:
            StateLock: Lock handle

        Raises:
            StateError: If lock cannot be acquired
        """
        self.state_dir.mkdir(parents=True, exist_ok=True)

        # Acquire in-process thread lock first so same-process threads
        # serialize cleanly without polling the file lock against themselves.
        thread_lock = self._get_thread_lock(self.root_path)
        if not thread_lock.acquire(timeout=timeout):
            raise StateError(
                f"Could not acquire state lock within {timeout}s. "
                "Another process may be syncing. "
                "If this persists, delete .plane/state.lock"
            )
        try:
            if HAS_FCNTL:
                yield from self._lock_fcntl(timeout)
            else:
                yield from self._lock_fallback(timeout)
        finally:
            thread_lock.release()

    def _lock_fcntl(self, timeout: float) -> Iterator[StateLock]:
        """Unix file locking using fcntl."""
        start_time = time.time()
        lock_handle = None

        try:
            lock_handle = open(self.lock_file, 'w')

            # Try to acquire lock with timeout
            while True:
                try:
                    fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)  # type: ignore[attr-defined]
                    break  # Lock acquired
                except (IOError, OSError):
                    if time.time() - start_time > timeout:
                        raise StateError(
                            f"Could not acquire state lock within {timeout}s. "
                            "Another process may be syncing. "
                            "If this persists, delete .plane/state.lock"
                        )
                    time.sleep(0.1)

            lock_info = StateLock(
                lock_file=self.lock_file,
                file_handle=lock_handle,
                acquired_at=time.time(),
            )

            logger.debug("Acquired state lock")
            yield lock_info

        finally:
            if lock_handle:
                try:
                    fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)  # type: ignore[attr-defined]
                    lock_handle.close()
                    logger.debug("Released state lock")
                except Exception as e:
                    logger.debug(f"Lock cleanup: {e}")

    _fallback_warning_shown = False

    def _lock_fallback(self, timeout: float) -> Iterator[StateLock]:
        """Fallback file locking for platforms without fcntl (e.g., Windows).

        Uses O_CREAT|O_EXCL for atomic lock file creation to avoid TOCTOU races.
        Also detects stale locks left behind by crashed processes.
        """
        if not StateManager._fallback_warning_shown:
            logger.warning(
                "fcntl not available on this platform. "
                "Using simple lock file fallback (not safe for concurrent access)."
            )
            StateManager._fallback_warning_shown = True

        start_time = time.time()
        lock_fd = None
        created_lock = False
        acquired = False

        try:
            while True:
                try:
                    # Atomic create-or-fail: avoids TOCTOU race
                    lock_fd = os.open(
                        str(self.lock_file),
                        os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                    )
                    created_lock = True
                    os.write(lock_fd, str(os.getpid()).encode())
                    os.close(lock_fd)
                    lock_fd = None  # Closed successfully; mark so finally doesn't re-close
                    acquired = True
                    break  # Lock acquired
                except FileExistsError:
                    # Lock file exists — check if holder is still alive
                    try:
                        holder_pid = int(self.lock_file.read_text().strip())
                        if not self._pid_exists(holder_pid):
                            logger.warning(
                                f"Removing stale lock (PID {holder_pid} no longer running)"
                            )
                            self.lock_file.unlink(missing_ok=True)
                            continue  # Retry immediately
                    except (ValueError, OSError):
                        pass  # Can't read PID; fall through to timeout check

                    if time.time() - start_time > timeout:
                        raise StateError(
                            f"Could not acquire state lock within {timeout}s. "
                            "Another process may be syncing. "
                            "If this persists, delete .plane/state.lock"
                        )
                    time.sleep(0.1)

            lock_info = StateLock(
                lock_file=self.lock_file,
                file_handle=None,
                acquired_at=time.time(),
            )

            logger.debug("Acquired state lock (fallback)")
            yield lock_info

        finally:
            # Close fd if open() succeeded but we didn't get to os.close()
            if lock_fd is not None:
                try:
                    os.close(lock_fd)
                except OSError:
                    pass
            if acquired or created_lock:
                try:
                    self.lock_file.unlink(missing_ok=True)
                    logger.debug("Released state lock (fallback)")
                except Exception as e:
                    logger.debug(f"Lock cleanup: {e}")

    @staticmethod
    def _pid_exists(pid: int) -> bool:
        """Check whether a process with the given PID is running."""
        if sys.platform == "win32":
            # On Windows, os.kill(pid, 0) sends CTRL_C_EVENT (signal value 0)
            # to the console process group, which raises KeyboardInterrupt in
            # the calling process.  Use OpenProcess + GetExitCodeProcess instead.
            import ctypes  # noqa: PLC0415
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            handle = ctypes.windll.kernel32.OpenProcess(  # type: ignore[attr-defined]
                PROCESS_QUERY_LIMITED_INFORMATION, False, pid
            )
            if not handle:
                return False
            exit_code = ctypes.c_ulong(0)
            ctypes.windll.kernel32.GetExitCodeProcess(  # type: ignore[attr-defined]
                handle, ctypes.byref(exit_code)
            )
            ctypes.windll.kernel32.CloseHandle(handle)  # type: ignore[attr-defined]
            STILL_ACTIVE = 259
            return exit_code.value == STILL_ACTIVE
        # Unix: signal 0 only checks process existence without sending a signal
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return True  # Process exists but we can't signal it

    # -------------------------------------------------------------------------
    # Convenience Methods
    # -------------------------------------------------------------------------

    def update_work_item(
        self,
        tracking_key: str,
        work_item: WorkItem,
        remote_id: str,
        source_file: str | Path,
        index: int,
        update_last_sync: bool = False,
    ) -> None:
        """
        Update a work item in state (with locking).

        Args:
            tracking_key: Key for tracking (user-provided id or content hash)
            work_item: The work item
            remote_id: Remote ID from Plane
            source_file: Source YAML file
            index: Index within file
        """
        from planecompose.utils.work_items import calculate_content_hash, CONTENT_HASH_VERSION

        with self.lock():
            state = self.load()
            state.work_items[tracking_key] = WorkItemState(
                remote_id=remote_id,
                content_hash=calculate_content_hash(work_item),
                source=f"{source_file}:{index}",
                last_synced=_utc_now_iso(),
                hash_version=CONTENT_HASH_VERSION,
            )
            if update_last_sync:
                state.last_sync = _utc_now_iso()
            self.save(state)

    def update_work_items_batch(
        self,
        updates: list[tuple[str, WorkItemState]],
        update_last_sync: bool = False,
    ) -> None:
        """
        Update multiple work items in state (single lock).

        Args:
            updates: List of (tracking_key, WorkItemState) tuples
        """
        with self.lock():
            state = self.load()
            for key, item_state in updates:
                state.work_items[key] = item_state
            if update_last_sync and updates:
                state.last_sync = _utc_now_iso()
            self.save(state)

    def remap_work_item_tracking_keys(
        self,
        remaps: list[tuple[str, str]],
        update_last_sync: bool = False,
    ) -> int:
        """Move tracked work items from old keys to new keys in a single lock."""
        if not remaps:
            return 0

        moved = 0
        with self.lock():
            state = self.load()
            for old_key, new_key in remaps:
                if old_key == new_key or old_key not in state.work_items:
                    continue
                state.work_items[new_key] = state.work_items.pop(old_key)
                moved += 1

            if update_last_sync and moved:
                state.last_sync = _utc_now_iso()

            if moved:
                self.save(state)

        return moved

    def get_work_item(self, tracking_key: str) -> WorkItemState | None:
        """Get work item state by tracking key."""
        state = self.load()
        return state.work_items.get(tracking_key)

    def remove_work_item(self, tracking_key: str) -> bool:
        """
        Remove a work item from state (with locking).

        Returns:
            True if item was removed, False if not found
        """
        with self.lock():
            state = self.load()
            if tracking_key in state.work_items:
                del state.work_items[tracking_key]
                self.save(state)
                return True
            return False

    def remove_work_items_batch(self, tracking_keys: list[str]) -> int:
        """
        Remove multiple work items from state in a single lock.

        Args:
            tracking_keys: List of tracking keys to remove

        Returns:
            Number of items actually removed
        """
        if not tracking_keys:
            return 0

        removed = 0
        with self.lock():
            state = self.load()
            for key in tracking_keys:
                if key in state.work_items:
                    del state.work_items[key]
                    removed += 1
            if removed:
                self.save(state)
        return removed

    def clear(self) -> None:
        """Clear all state (with locking)."""
        with self.lock():
            self.save(SyncState())
            logger.info("Cleared all state")

    def reset(self) -> None:
        """Reset state by deleting state file."""
        if self.state_file.exists():
            self.state_file.unlink()
            logger.info("Reset state (deleted state file)")

    # -------------------------------------------------------------------------
    # Schema State Methods
    # -------------------------------------------------------------------------

    def update_schema_state(
        self,
        types: dict[str, str] | None = None,
        states: dict[str, str] | None = None,
        workflows: dict[str, str] | None = None,
        labels: dict[str, str] | None = None,
        cycles: dict[str, str] | None = None,
        modules: dict[str, str] | None = None,
        estimates: dict[str, str] | None = None,
        properties: dict[str, dict[str, str]] | None = None,
        update_last_sync: bool = False,
    ) -> None:
        """
        Update schema state mappings (with locking).

        Args:
            types: Type name -> remote_id mapping
            states: State name -> remote_id mapping
            workflows: Workflow name -> remote_id mapping
            labels: Label name -> remote_id mapping
            cycles: Cycle name -> remote_id mapping
            modules: Module name -> remote_id mapping
            estimates: Estimate name -> remote_id mapping
            properties: Type ID -> {property name -> property_id} mapping
        """
        with self.lock():
            state = self.load()
            if types is not None:
                state.types.update(types)
            if states is not None:
                state.states.update(states)
            if workflows is not None:
                state.workflows.update(workflows)
            if labels is not None:
                state.labels.update(labels)
            if cycles is not None:
                state.cycles.update(cycles)
            if modules is not None:
                state.modules.update(modules)
            if estimates is not None:
                state.estimates.update(estimates)
            if properties is not None:
                # Merge properties (type_id -> {prop_name -> prop_id})
                for type_id, props in properties.items():
                    if type_id not in state.properties:
                        state.properties[type_id] = {}
                    state.properties[type_id].update(props)
            if update_last_sync:
                state.last_sync = _utc_now_iso()
            self.save(state)

    def mark_last_sync(self, timestamp: str | None = None) -> None:
        """Update the top-level last_sync timestamp without mutating mappings."""
        with self.lock():
            state = self.load()
            state.last_sync = timestamp or _utc_now_iso()
            self.save(state)

    # -------------------------------------------------------------------------
    # Display/Debug Methods
    # -------------------------------------------------------------------------

    def get_summary(self) -> dict:
        """Get a summary of current state for display."""
        state = self.load()
        return {
            'last_sync': state.last_sync,
            'types_count': len(state.types),
            'states_count': len(state.states),
            'labels_count': len(state.labels),
            'work_items_count': len(state.work_items),
            'state_file': str(self.state_file),
        }

    def get_work_items_summary(self) -> list[dict]:
        """Get summary of all tracked work items."""
        state = self.load()
        return [
            {
                'tracking_key': key,
                'remote_id': item.remote_id,
                'source': item.source,
                'last_synced': item.last_synced,
            }
            for key, item in state.work_items.items()
        ]
