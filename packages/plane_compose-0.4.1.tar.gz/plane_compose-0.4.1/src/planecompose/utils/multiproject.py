"""Multi-project discovery and batch operations.

This module provides utilities for managing multiple Plane projects:
- discover_projects(): Find all plane.yaml files in a directory tree
- run_batch(): Execute operations across multiple projects
"""
import asyncio
from pathlib import Path
from dataclasses import dataclass
from typing import Callable, Awaitable
from rich.console import Console
from rich.table import Table

from planecompose.constants import FILE_PLANE_YAML
from planecompose.utils.logger import get_logger

logger = get_logger()
console = Console()


@dataclass
class ProjectInfo:
    """Information about a discovered project."""
    path: Path
    workspace: str
    project_key: str
    project_name: str | None = None


@dataclass
class BatchResult:
    """Result of a batch operation."""
    project: ProjectInfo
    success: bool
    message: str
    error: Exception | None = None


def discover_projects(
    root: Path | None = None,
    filter_pattern: str | None = None,
    filter_workspace: str | None = None,
) -> list[ProjectInfo]:
    """
    Discover all Plane projects under a directory.

    Recursively searches for plane.yaml files and extracts project info.
    Respects .planeignore files for exclusions.

    Args:
        root: Root directory to search (defaults to current directory)
        filter_pattern: Glob pattern to filter paths (e.g., "projects/*")
        filter_workspace: Only include projects from this workspace

    Returns:
        List of ProjectInfo objects sorted by path
    """
    import yaml

    if root is None:
        root = Path.cwd()
    root = root.resolve()

    # Load ignore patterns
    ignore_patterns = _load_ignore_patterns(root)

    projects = []

    # Find all plane.yaml files
    for plane_yaml in root.rglob(FILE_PLANE_YAML):
        project_path = plane_yaml.parent

        # Check ignore patterns
        rel_path = project_path.relative_to(root)
        if _should_ignore(rel_path, ignore_patterns):
            continue

        # Check filter pattern
        if filter_pattern:
            from fnmatch import fnmatch
            if not fnmatch(str(rel_path), filter_pattern):
                continue

        # Parse plane.yaml for basic info
        try:
            with open(plane_yaml) as f:
                data = yaml.safe_load(f) or {}

            workspace = data.get('workspace', '')
            project_data = data.get('project', {})
            project_key = project_data.get('key', data.get('project_key', ''))
            project_name = project_data.get('name')

            # Check workspace filter
            if filter_workspace and workspace != filter_workspace:
                continue

            projects.append(ProjectInfo(
                path=project_path,
                workspace=workspace,
                project_key=project_key,
                project_name=project_name,
            ))
        except Exception as e:
            logger.debug(f"Skipping {plane_yaml}: {e}")
            continue

    # Sort by path for consistent ordering
    return sorted(projects, key=lambda p: p.path)


def _load_ignore_patterns(root: Path) -> list[str]:
    """Load patterns from .planeignore file."""
    ignore_file = root / '.planeignore'
    if not ignore_file.exists():
        return []

    patterns = []
    for line in ignore_file.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith('#'):
            patterns.append(line)
    return patterns


def _should_ignore(path: Path, patterns: list[str]) -> bool:
    """Check if a path matches any ignore pattern."""
    from fnmatch import fnmatch

    path_str = str(path)
    for pattern in patterns:
        if fnmatch(path_str, pattern) or fnmatch(path_str + '/', pattern):
            return True
    return False


async def run_batch(
    projects: list[ProjectInfo],
    operation: Callable[[Path], Awaitable[None]],
    operation_name: str,
    concurrency: int = 4,
    stop_on_error: bool = False,
) -> list[BatchResult]:
    """
    Run an operation across multiple projects.

    Args:
        projects: List of projects to operate on
        operation: Async function that takes a project path
        operation_name: Name for display (e.g., "push", "pull")
        concurrency: Max concurrent operations
        stop_on_error: Whether to stop on first error

    Returns:
        List of BatchResult objects
    """
    results: list[BatchResult] = []
    semaphore = asyncio.Semaphore(concurrency)

    async def run_one(project: ProjectInfo) -> BatchResult:
        async with semaphore:
            try:
                await operation(project.path)
                return BatchResult(
                    project=project,
                    success=True,
                    message="Success",
                )
            except Exception as e:
                return BatchResult(
                    project=project,
                    success=False,
                    message=str(e),
                    error=e,
                )

    # Run operations
    if stop_on_error:
        # Sequential with early exit
        for project in projects:
            result = await run_one(project)
            results.append(result)
            if not result.success:
                break
    else:
        # Parallel execution
        tasks = [run_one(project) for project in projects]
        results = await asyncio.gather(*tasks)

    return list(results)


def display_batch_results(
    results: list[BatchResult],
    operation_name: str,
) -> tuple[int, int]:
    """
    Display batch operation results in a table.

    Args:
        results: List of BatchResult objects
        operation_name: Name of the operation for display

    Returns:
        Tuple of (success_count, failure_count)
    """
    table = Table(title=f"Batch {operation_name.title()} Results")
    table.add_column("Project", style="cyan")
    table.add_column("Workspace", style="dim")
    table.add_column("Status", justify="center")
    table.add_column("Message")

    success_count = 0
    failure_count = 0

    for result in results:
        if result.success:
            status = "[green]Success[/green]"
            success_count += 1
        else:
            status = "[red]Failed[/red]"
            failure_count += 1

        table.add_row(
            result.project.project_key,
            result.project.workspace,
            status,
            result.message[:50] + "..." if len(result.message) > 50 else result.message,
        )

    console.print()
    console.print(table)
    console.print()

    # Summary
    total = len(results)
    if failure_count == 0:
        console.print(f"[green]All {total} projects {operation_name}ed successfully![/green]")
    else:
        console.print(f"[yellow]{success_count}/{total} succeeded, {failure_count} failed[/yellow]")
    console.print()

    return success_count, failure_count


def display_discovered_projects(projects: list[ProjectInfo], root: Path | None = None) -> None:
    """Display discovered projects in a table."""
    if not projects:
        console.print("[yellow]No projects found[/yellow]")
        return

    table = Table(title=f"Found {len(projects)} Projects")
    table.add_column("Project", style="cyan")
    table.add_column("Workspace", style="dim")
    table.add_column("Path")

    for project in projects:
        path_str = str(project.path)
        if root:
            try:
                path_str = str(project.path.relative_to(root))
            except ValueError:
                pass

        table.add_row(
            project.project_key,
            project.workspace,
            path_str,
        )

    console.print()
    console.print(table)
    console.print()
