"""Project identifier parsing utilities.

Supports three formats for identifying projects:

1. UUID format:
   plane clone 8cee0da2-1b5b-4699-b11a-e3c8b26dd55d --workspace=myteam

2. Project key with --workspace flag:
   plane clone MYPROJ --workspace=myteam

3. Workspace/key shorthand:
   plane clone myteam/MYPROJ

This module provides clean parsing and validation for all three formats,
with helpful error messages for users.
"""

import re
from dataclasses import dataclass
from enum import Enum


class IdentifierFormat(Enum):
    """The detected format of a project identifier."""
    UUID = "uuid"
    PROJECT_KEY = "project_key"
    WORKSPACE_KEY = "workspace_key"


@dataclass
class ProjectIdentifier:
    """Parsed project identifier with resolved values.

    Attributes:
        format: The detected format of the identifier
        project_uuid: UUID if provided directly, None otherwise
        project_key: Project key (e.g., "MYPROJ") if not UUID format
        workspace: Workspace slug (required for all operations)
    """
    format: IdentifierFormat
    project_uuid: str | None
    project_key: str | None
    workspace: str | None

    @property
    def display_name(self) -> str:
        """Human-readable name for error messages."""
        if self.project_uuid:
            return f"project {self.project_uuid[:8]}..."
        elif self.project_key and self.workspace:
            return f"project {self.workspace}/{self.project_key}"
        elif self.project_key:
            return f"project {self.project_key}"
        return "project"


# UUID pattern: 8-4-4-4-12 hex digits
UUID_PATTERN = re.compile(
    r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
)

# Project key pattern: uppercase letters, numbers, underscores (typically 2-10 chars)
PROJECT_KEY_PATTERN = re.compile(r'^[A-Z][A-Z0-9_]{0,19}$')

# Workspace/key shorthand pattern: workspace-slug/PROJECT_KEY
WORKSPACE_KEY_PATTERN = re.compile(r'^([a-z][a-z0-9_-]{0,49})/([A-Z][A-Z0-9_]{0,19})$')


def is_uuid(value: str) -> bool:
    """Check if a string is a valid UUID format."""
    return bool(UUID_PATTERN.match(value))


def is_project_key(value: str) -> bool:
    """Check if a string looks like a project key (uppercase, no slashes)."""
    return bool(PROJECT_KEY_PATTERN.match(value))


def is_workspace_key_format(value: str) -> bool:
    """Check if a string matches workspace/key format."""
    return bool(WORKSPACE_KEY_PATTERN.match(value))


def parse_project_identifier(
    identifier: str,
    workspace_flag: str | None = None,
) -> ProjectIdentifier:
    """Parse a project identifier and return structured result.

    Args:
        identifier: The identifier string (UUID, key, or workspace/key)
        workspace_flag: The --workspace flag value, if provided

    Returns:
        ProjectIdentifier with parsed values

    Examples:
        >>> parse_project_identifier("8cee0da2-1b5b-4699-b11a-e3c8b26dd55d", "myteam")
        ProjectIdentifier(format=UUID, project_uuid="8cee...", workspace="myteam")

        >>> parse_project_identifier("MYPROJ", "myteam")
        ProjectIdentifier(format=PROJECT_KEY, project_key="MYPROJ", workspace="myteam")

        >>> parse_project_identifier("myteam/MYPROJ")
        ProjectIdentifier(format=WORKSPACE_KEY, project_key="MYPROJ", workspace="myteam")
    """
    identifier = identifier.strip()

    # Format 1: UUID (e.g., "8cee0da2-1b5b-4699-b11a-e3c8b26dd55d")
    if is_uuid(identifier):
        return ProjectIdentifier(
            format=IdentifierFormat.UUID,
            project_uuid=identifier,
            project_key=None,
            workspace=workspace_flag,
        )

    # Format 3: workspace/key shorthand (e.g., "myteam/MYPROJ")
    match = WORKSPACE_KEY_PATTERN.match(identifier)
    if match:
        parsed_workspace, parsed_key = match.groups()
        # If workspace flag also provided, it must match
        if workspace_flag and workspace_flag != parsed_workspace:
            # User provided both - use flag and warn
            effective_workspace = workspace_flag
        else:
            effective_workspace = parsed_workspace
        return ProjectIdentifier(
            format=IdentifierFormat.WORKSPACE_KEY,
            project_uuid=None,
            project_key=parsed_key,
            workspace=effective_workspace,
        )

    # Format 2: Project key only (e.g., "MYPROJ")
    if is_project_key(identifier):
        return ProjectIdentifier(
            format=IdentifierFormat.PROJECT_KEY,
            project_uuid=None,
            project_key=identifier,
            workspace=workspace_flag,
        )

    # Try case-insensitive key check (user might have typed "myproj" instead of "MYPROJ")
    upper_identifier = identifier.upper()
    if is_project_key(upper_identifier) and '/' not in identifier:
        return ProjectIdentifier(
            format=IdentifierFormat.PROJECT_KEY,
            project_uuid=None,
            project_key=upper_identifier,
            workspace=workspace_flag,
        )

    # Unknown format - return as-is with PROJECT_KEY format for error handling downstream
    return ProjectIdentifier(
        format=IdentifierFormat.PROJECT_KEY,
        project_uuid=None,
        project_key=identifier,
        workspace=workspace_flag,
    )


def validate_identifier(identifier: ProjectIdentifier) -> list[str]:
    """Validate a parsed identifier and return list of error messages.

    Returns:
        Empty list if valid, list of error messages otherwise
    """
    errors = []

    # All formats require workspace
    if not identifier.workspace:
        if identifier.format == IdentifierFormat.UUID:
            errors.append("--workspace is required when using UUID format")
        elif identifier.format == IdentifierFormat.PROJECT_KEY:
            errors.append("--workspace is required when using project key")
            errors.append("  Hint: Use 'plane clone MYPROJ --workspace=myteam'")
            errors.append("  Or use shorthand: 'plane clone myteam/MYPROJ'")

    # UUID format validation
    if identifier.format == IdentifierFormat.UUID:
        if identifier.project_uuid and not is_uuid(identifier.project_uuid):
            errors.append(f"Invalid UUID format: {identifier.project_uuid}")

    # Project key validation
    if identifier.project_key and not is_project_key(identifier.project_key):
        if '/' in identifier.project_key:
            errors.append(f"Invalid workspace/key format: {identifier.project_key}")
            errors.append("  Expected format: workspace-slug/PROJECT_KEY")
            errors.append("  Example: myteam/MYPROJ")
        else:
            errors.append(f"Invalid project key: {identifier.project_key}")
            errors.append("  Project keys should be uppercase (e.g., MYPROJ)")

    return errors


def format_identifier_help() -> str:
    """Return help text showing supported identifier formats."""
    return """
Supported formats:
  1. UUID with workspace:      plane clone <uuid> --workspace=<slug>
  2. Project key with workspace: plane clone <KEY> --workspace=<slug>
  3. Shorthand:                plane clone <workspace>/<KEY>

Examples:
  plane clone 8cee0da2-1b5b-4699-b11a-e3c8b26dd55d --workspace=myteam
  plane clone MYPROJ --workspace=myteam
  plane clone myteam/MYPROJ
""".strip()
