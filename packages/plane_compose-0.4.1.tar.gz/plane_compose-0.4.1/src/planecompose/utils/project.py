"""Project management utilities.

All API calls go through PlaneBackend - no direct SDK usage here.
"""

from pathlib import Path
from rich.console import Console
from rich.panel import Panel
import yaml

from planecompose.exceptions import APIError, NotFoundError, PermissionError as PlanePermissionError

console = Console()


def update_plane_yaml_with_uuid(project_path: Path, project_key: str, project_uuid: str) -> None:
    """Add UUID to plane.yaml preserving all comments and formatting.

    Uses targeted line insertion instead of yaml.dump to avoid stripping
    inline comments (e.g. # public or private) added by init/clone.

    Inserts `  uuid: <value>` immediately after the `  name:` line under
    the project: block. If uuid already exists, replaces it in-place.
    """
    plane_yaml_path = project_path / "plane.yaml"

    with open(plane_yaml_path, "r") as f:
        lines = f.readlines()

    # Check if uuid line already exists — replace it in-place
    for i, line in enumerate(lines):
        if line.lstrip().startswith("uuid:"):
            lines[i] = f"  uuid: {project_uuid}\n"
            with open(plane_yaml_path, "w") as f:
                f.writelines(lines)
            console.print("\n[dim]Updated plane.yaml with project UUID[/dim]")
            return

    # uuid not present — insert after the `  name:` line inside project: block
    in_project_block = False
    for i, line in enumerate(lines):
        stripped = line.lstrip()
        if stripped.startswith("project:"):
            in_project_block = True
            continue
        if in_project_block:
            if stripped.startswith("name:"):
                lines.insert(i + 1, f"  uuid: {project_uuid}\n")
                with open(plane_yaml_path, "w") as f:
                    f.writelines(lines)
                console.print("\n[dim]Updated plane.yaml with project UUID[/dim]")
                return
            # Left the project block (hit a top-level key) without finding name:
            if line and not line[0].isspace() and stripped and not stripped.startswith("#"):
                break

    # Fallback: yaml.dump (should not normally be reached)
    with open(plane_yaml_path, "r") as f:
        config_data = yaml.safe_load(f)
    config_data["project"]["uuid"] = project_uuid
    with open(plane_yaml_path, "w") as f:
        yaml.dump(config_data, f, default_flow_style=False, sort_keys=False)
    console.print("\n[dim]Updated plane.yaml with project UUID[/dim]")


def update_plane_yaml_with_metadata(
    project_path: Path,
    description: str | None = None,
    network: int | None = None,
    timezone: str | None = None,
) -> None:
    """Update plane.yaml with project metadata fields fetched from the API.

    Maps the API's integer network value back to human-readable strings:
      2 -> "public"
      0 -> "private"

    Only writes fields that are provided (non-None).
    """
    plane_yaml_path = project_path / "plane.yaml"
    if not plane_yaml_path.exists():
        return

    with open(plane_yaml_path, "r") as f:
        config_data = yaml.safe_load(f)

    if "project" not in config_data:
        config_data["project"] = {}

    if description is not None:
        config_data["project"]["description"] = description
    if network is not None:
        from planecompose.core.models import network_to_str
        config_data["project"]["network"] = network_to_str(network)
    if timezone is not None:
        config_data["project"]["timezone"] = timezone

    with open(plane_yaml_path, "w") as f:
        yaml.dump(config_data, f, default_flow_style=False, sort_keys=False)


def extract_essential_wit_fields(work_item_type: dict) -> dict:
    """
    Extract only essential fields from a work item type API response.

    Keeps only: id, name, description
    Filters out: timestamps, logos, internal flags, sync metadata, etc.

    Args:
        work_item_type: Full WIT object from API

    Returns:
        Dictionary with only essential fields
    """
    essential = {
        "id": work_item_type.get("id"),
        "name": work_item_type.get("name"),
    }

    # Only include description if it's not empty
    if work_item_type.get("description"):
        essential["description"] = work_item_type.get("description")

    return essential


def extract_essential_member_fields(member: dict) -> dict:
    """
    Extract only essential fields from a workspace member API response.

    Keeps only: id, email, display_name
    Filters out: avatar, avatar_url, first_name, last_name, etc.

    Args:
        member: Full member object from API (UserLite)

    Returns:
        Dictionary with only essential fields
    """
    essential: dict = {}

    if member.get("id"):
        essential["id"] = member["id"]
    if member.get("email"):
        essential["email"] = member["email"]
    if member.get("display_name"):
        essential["display_name"] = member["display_name"]

    return essential


def update_workspace_yaml(
    project_path: Path,
    workspace: str,
    workspace_features: dict[str, bool] | None = None,
    work_item_types: list | None = None,
    members: list | None = None,
) -> None:
    """
    Update or create workspace.yaml with workspace-level configuration.

    Args:
        project_path: Root path of the project
        workspace: Workspace slug
        workspace_features: Workspace feature flags from API
        work_item_types: List of workspace-level work item types from API (will be filtered to essential fields)
        members: List of workspace members from API (will be filtered to id, email, display_name)
    """
    workspace_yaml_path = project_path / "workspace.yaml"

    # Load existing workspace.yaml if it exists
    if workspace_yaml_path.exists():
        with open(workspace_yaml_path, "r") as f:
            config_data = yaml.safe_load(f) or {}
    else:
        config_data = {}

    # Ensure workspace slug is set
    config_data["workspace"] = workspace

    # Update workspace features if provided
    if workspace_features is not None:
        config_data["workspace_features"] = workspace_features

    # Update work item types if provided (filter to essential fields only)
    if work_item_types is not None:
        config_data["work_item_types"] = [
            extract_essential_wit_fields(wit) for wit in work_item_types
        ]

    # Update members if provided (filter to essential fields only)
    if members is not None:
        config_data["members"] = [extract_essential_member_fields(m) for m in members]

    # Write back to workspace.yaml with header
    header = """# Workspace Configuration
# Synced from Plane. Contains workspace features and member information.
#
# Sections:
# - workspace: Workspace slug
# - workspace_features: Feature flags (read-only)
# - work_item_types: Workspace-level type definitions (read-only)
# - members: Workspace members (read-only)"""
    with open(workspace_yaml_path, "w") as f:
        if header:
            f.write(header)
            f.write("\n")
        yaml.dump(config_data, f, default_flow_style=False, sort_keys=False)

    console.print("[dim]✓ Updated workspace.yaml with workspace configuration[/dim]")


def update_plane_yaml_with_workspace_features(
    project_path: Path, workspace_features: dict[str, bool]
) -> None:
    """
    DEPRECATED: Use update_workspace_yaml() instead.

    This function is kept for backward compatibility but delegates to update_workspace_yaml().
    Workspace features should now be stored in workspace.yaml, not plane.yaml.
    """
    # Minimal backward compat - just log and do nothing
    console.print("[dim]Note: Workspace features are now stored in workspace.yaml[/dim]")


async def ensure_project_exists(
    workspace: str,
    project_key: str,
    project_uuid: str | None,
    project_name: str | None,
    api_key: str,
    api_url: str,
    auto_create: bool = True,
    silent_on_not_found: bool = False,
    project_description: str | None = None,
    project_network: str | None = None,
    project_timezone: str | None = None,
) -> str:
    """
    Ensure project exists in Plane.

    All API calls go through PlaneBackend (no direct SDK usage).

    Args:
        workspace: Workspace slug
        project_key: Short identifier (e.g., "MYPROJ")
        project_uuid: Optional UUID if already known
        project_name: Project display name
        api_key: Plane API key
        api_url: Plane API URL
        auto_create: Whether to create project if it doesn't exist
        silent_on_not_found: When True, suppress error output if project not found (used for existence checks)
        project_description: Optional description to set on new projects
        project_network: Optional network setting ("public" or "private") for new projects
        project_timezone: Optional IANA timezone string for new projects

    Returns: project UUID

    Raises:
        Exception: If project doesn't exist and can't be created
    """
    from planecompose.backend.plane import PlaneBackend

    # Use backend for all API calls (rate limiting is automatic)
    backend = PlaneBackend.create_client(api_url, api_key)

    # If we already have the UUID, try to verify it exists
    if project_uuid:
        try:
            project = await backend.retrieve_project(workspace, project_uuid)
            console.print(f"[green]✓[/green] Found project: {project.name}")
            return project_uuid
        except (APIError, NotFoundError):
            # UUID is stale/invalid - fall back to key lookup
            console.print("[dim]UUID in plane.yaml is stale, looking up by key instead...[/dim]")

    # Look up project by key
    try:
        projects = await backend.list_projects(workspace)
        existing = next((p for p in projects if p.identifier == project_key.upper()), None)

        if existing:
            console.print(
                f"[green]✓[/green] Found project: {existing.name} ({project_key.upper()})"
            )
            return str(existing.id)

        # Project doesn't exist
        if not auto_create:
            if not silent_on_not_found:
                _show_project_not_found_error(workspace, project_key, projects)
            raise Exception(f"Project '{project_key}' not found in workspace '{workspace}'")

        # Create new project
        console.print(f"\n[cyan]Project '{project_key.upper()}' not found. Creating...[/cyan]")

        new_project = await backend.create_project(
            workspace=workspace,
            name=project_name or project_key.upper(),
            identifier=project_key.upper(),
            description=project_description or "",
            network=project_network,
            timezone=project_timezone,
        )

        console.print(f"[green]✓[/green] Created project: {new_project.name}")
        console.print(f"[dim]  Identifier: {project_key.upper()}[/dim]")
        console.print(f"[dim]  UUID: {new_project.id}[/dim]")
        return str(new_project.id)

    except (PlanePermissionError, APIError) as e:
        # Handle permission errors (403)
        is_permission_error = isinstance(e, PlanePermissionError) or (
            isinstance(e, APIError) and e.status_code == 403
        )
        if is_permission_error:
            console.print("\n[red]✗ Permission Denied[/red]")
            console.print(
                f"You don't have permission to create projects in workspace '{workspace}'"
            )
            console.print("\n[yellow]Solutions:[/yellow]")
            console.print("  • Use a workspace where you have admin/member access")
            console.print("  • Ask workspace admin to create the project first")
            console.print("  • Use a different API key with proper permissions")
        raise


def _show_project_not_found_error(workspace: str, project_key: str, available_projects: list):
    """Show helpful error when project key doesn't exist."""
    console.print("\n[red]✗ Project Not Found[/red]\n")

    error_msg = f"""Project with identifier '[cyan]{project_key.upper()}[/cyan]' doesn't exist in workspace '[cyan]{workspace}[/cyan]'.

[yellow]Available projects in this workspace:[/yellow]"""

    if available_projects:
        for p in available_projects:
            error_msg += f"\n  • {p.name} ([cyan]{p.identifier}[/cyan])"
    else:
        error_msg += "\n  [dim](no projects found)[/dim]"

    error_msg += """

[yellow]Solutions:[/yellow]
  1. Fix the 'key' in plane.yaml to match an existing project
  2. Or run [cyan]plane schema push[/cyan] to create the project automatically"""

    console.print(Panel(error_msg, title="[red]Error[/red]", border_style="red"))


def update_plane_yaml_with_workspace_work_item_types(
    project_path: Path, workspace_types: dict[str, dict]
) -> None:
    """
    DEPRECATED: Use update_workspace_yaml() instead.

    This function is kept for backward compatibility but delegates to update_workspace_yaml().
    Workspace work item types should now be stored in workspace.yaml, not plane.yaml.
    """
    # Minimal backward compat - just log and do nothing
    console.print("[dim]Note: Workspace work item types are now stored in workspace.yaml[/dim]")


def create_gitignore(project_path: Path) -> None:
    """Create .gitignore file if it doesn't exist."""
    gitignore_path = project_path / ".gitignore"

    if gitignore_path.exists():
        # Just append .plane/ if not already there
        content = gitignore_path.read_text()
        if ".plane/" not in content:
            with open(gitignore_path, "a") as f:
                f.write("\n# Plane CLI sync state\n.plane/\n")
    else:
        # Only ignore sync state - project contains YAML files, not code
        gitignore_content = """# Plane CLI sync state
.plane/
"""
        gitignore_path.write_text(gitignore_content)
        console.print("  [green]✓[/green] Created .gitignore")
