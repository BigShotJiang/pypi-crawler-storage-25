"""Persist rate limit statistics to disk with timestamps."""
import json
import time
from pathlib import Path


class RateLimitState:
    """Manage persistent rate limit stats per connection with timestamps."""

    def __init__(self, state_file: Path):
        """
        Initialize rate limit state manager.

        Args:
            state_file: Path to store rate limit stats (e.g., ~/.config/plane-compose/rate-limits.json)
        """
        self.state_file = state_file
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        self._load()

    def _load(self) -> None:
        """Load state from disk."""
        if self.state_file.exists():
            try:
                with open(self.state_file) as f:
                    self.data = json.load(f)
            except Exception:
                self.data = {}
        else:
            self.data = {}

    def _save(self) -> None:
        """Save state to disk."""
        try:
            with open(self.state_file, 'w') as f:
                json.dump(self.data, f, indent=2)
        except Exception:
            # Silently fail - don't break API calls due to persistence issues
            pass

    def record_request(self, connection_id: str, wait_time: float = 0.0) -> None:
        """
        Record an API request for a connection.

        Args:
            connection_id: Connection identifier
            wait_time: Time waited due to rate limiting (seconds)
        """
        if connection_id not in self.data:
            self.data[connection_id] = {
                "total_requests": 0,
                "total_wait_time": 0.0,
                "started_at": time.time(),
                "last_request_at": time.time(),
                "last_reset_at": None,
            }

        conn_data = self.data[connection_id]
        conn_data["total_requests"] += 1
        conn_data["total_wait_time"] += wait_time
        conn_data["last_request_at"] = time.time()

        self._save()

    def get_stats(self, connection_id: str) -> dict:
        """
        Get stats for a connection including per-minute calculation.

        Args:
            connection_id: Connection identifier

        Returns:
            Stats dict with calculated rates
        """
        if connection_id not in self.data:
            return {
                "total_requests": 0,
                "total_wait_time": 0.0,
                "requests_per_minute": 0.0,
                "started_at": None,
                "last_request_at": None,
            }

        conn_data = self.data[connection_id]
        total_requests = conn_data["total_requests"]

        # Calculate time elapsed since start (or reset)
        reset_time = conn_data.get("last_reset_at") or conn_data.get("started_at")
        elapsed_seconds = time.time() - reset_time if reset_time else 0

        # Calculate requests per minute
        requests_per_minute = (total_requests / elapsed_seconds * 60) if elapsed_seconds > 0 else 0

        return {
            "total_requests": total_requests,
            "total_wait_time": conn_data.get("total_wait_time", 0.0),
            "requests_per_minute": requests_per_minute,
            "started_at": conn_data.get("started_at"),
            "last_request_at": conn_data.get("last_request_at"),
            "elapsed_seconds": elapsed_seconds,
        }

    def reset(self, connection_id: str) -> None:
        """
        Reset stats for a connection.

        Args:
            connection_id: Connection identifier
        """
        if connection_id in self.data:
            self.data[connection_id]["total_requests"] = 0
            self.data[connection_id]["total_wait_time"] = 0.0
            self.data[connection_id]["last_reset_at"] = time.time()
            self.data[connection_id]["started_at"] = time.time()
            self._save()

    def reset_all(self) -> None:
        """Reset all stats."""
        self.data = {}
        self._save()
