"""Work item utilities - Terraform-style clean state management."""
import hashlib
import re
from datetime import datetime, timezone

from planecompose.core.models import WorkItem, WorkItemState

REMOTE_SNAPSHOT_PREFIX = ".plane/remote/"

# Bump this when hash serialization changes so that existing state.json
# hashes are recognised as stale rather than silently mismatching.
CONTENT_HASH_VERSION = 2


def generate_id_from_title(title: str) -> str:
    """Generate a stable ID from title (if user doesn't provide one)."""
    # Convert to lowercase and replace spaces/special chars with hyphens
    slug = re.sub(r'[^\w\s-]', '', title.lower())
    slug = re.sub(r'[-\s]+', '-', slug)
    slug = slug.strip('-')

    # Limit length
    if len(slug) > 50:
        slug = slug[:50].rstrip('-')

    return slug or "item"


def calculate_content_hash(item: WorkItem) -> str:
    """
    Calculate content hash for change detection (like Git).

    This is used to detect if an item was modified locally.
    Includes ALL mutable fields to ensure no changes are silently ignored.

    The hash is versioned: changing the field list or serialization order
    requires bumping CONTENT_HASH_VERSION so that existing hashes in
    state.json are treated as stale (triggering an update) rather than
    causing silent mismatches.
    """
    parts = [
        f"v{CONTENT_HASH_VERSION}",  # version prefix for future-proofing
        item.title,
        item.description or '',
        item.type,
        item.state or '',
        item.priority or '',
        ','.join(sorted(item.labels)),
        ','.join(sorted(item.assignees)),
        item.start_date or '',
        item.due_date or '',
        item.parent or '',
        ','.join(sorted(item.watchers)),
        ','.join(sorted(item.blocked_by)),
        ','.join(sorted(item.blocking)),
        item.duplicate_of or '',
        ','.join(sorted(item.relates_to)),
        # Properties: sorted key=value pairs for stability
        ','.join(f"{k}={v}" for k, v in sorted(item.properties.items())),
    ]
    content = '|'.join(parts)
    return hashlib.sha256(content.encode()).hexdigest()[:16]


def get_tracking_key(item: WorkItem, source: str, index: int) -> str:
    """
    Get the tracking key for a work item.

    Strategy:
    1. If item has user-provided `id`, use with `id:` prefix (stable across changes)
    2. Otherwise, use content hash with `hash:` prefix (like Git)

    The namespace prefixes prevent collisions between user-provided IDs
    and auto-generated hash keys.

    Returns: tracking key for state.json
    """
    if item.id:
        return f"id:{item.id}"

    # Use content hash as fallback
    content_hash = calculate_content_hash(item)
    return f"hash:{content_hash}"


def is_remote_snapshot_source(source: str) -> bool:
    """Check whether a tracked item came from the read-only remote snapshot."""
    return source.startswith(REMOTE_SNAPSHOT_PREFIX)


def parse_source(source: str) -> tuple[str, int]:
    """Parse a source string like 'work/workitems.yaml:3' into (file_path, index).

    Uses the *last* colon as the delimiter so that file paths containing
    colons (e.g. Windows ``C:\\path``) are handled correctly.

    Returns:
        (file_path, index) tuple.  If the format is unexpected, returns
        (source, 0) as a safe fallback.
    """
    # Find the last colon that is followed only by digits (the index)
    match = re.search(r':(\d+)$', source)
    if match:
        return source[:match.start()], int(match.group(1))
    return source, 0


def make_work_item_state(remote_id: str, item: WorkItem, source: str, index: int) -> WorkItemState:
    """Create a WorkItemState for tracking."""
    return WorkItemState(
        remote_id=remote_id,
        content_hash=calculate_content_hash(item),
        source=f"{source}:{index}",
        last_synced=datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
        hash_version=CONTENT_HASH_VERSION,
    )
