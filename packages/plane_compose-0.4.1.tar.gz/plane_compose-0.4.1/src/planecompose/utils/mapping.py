"""Shared mapping utilities — pure functions, no I/O.

Centralises the handful of "build a dict from a raw API list" patterns that
were copy-pasted across clone.py, pull.py, and workflows.py.
"""
from typing import Any


def build_id_sequence_map(items: list, project_key: str) -> dict[str, str]:
    """Build a UUID → readable-ID map from a list of work item objects.

    Maps each item's remote UUID to its human-readable sequence ID
    (e.g. ``"PROJ-42"``).  Used when writing cycle/module membership so
    YAML files reference ``PROJ-42`` rather than raw UUIDs.

    Args:
        items:       List of work item objects (must have ``id`` and
                     ``sequence_id`` attributes).
        project_key: Project identifier prefix (e.g. ``"PROJ"``).

    Returns:
        Dict of ``{uuid_str: "PROJ-<seq>"}`` for every item that has both
        ``id`` and ``sequence_id`` set.
    """
    result: dict[str, str] = {}
    for item in items:
        item_id = str(getattr(item, 'id', '') or '')
        seq = getattr(item, 'sequence_id', None)
        if item_id and seq:
            result[item_id] = f"{project_key}-{seq}"
    return result


def build_name_id_map(
    raw_items: list[dict[str, Any]],
    *,
    id_key: str = 'id',
    name_key: str = 'name',
) -> dict[str, str]:
    """Build a name → ID mapping from a raw API list.

    Generic replacement for the near-identical ``build_script_mapping``,
    ``build_user_mapping`` (email→id), and the name→id half of
    ``build_state_mapping`` in ``workflows.py``.

    Args:
        raw_items: List of dicts from the Plane API.
        id_key:    Key to use as the value (default ``"id"``).
        name_key:  Key to use as the lookup key (default ``"name"``).
                   Pass ``"email"`` for member/user mappings.

    Returns:
        Dict of ``{name_key_value: id_key_value}``.
    """
    result: dict[str, str] = {}
    for item in raw_items:
        item_id = str(item.get(id_key, '') or '')
        item_name = item.get(name_key, '') or ''
        if item_id and item_name:
            result[str(item_name)] = item_id
    return result


def build_type_map(types_data: list[dict[str, Any]]) -> dict[str, str]:
    """Build a type UUID → type name map from raw workspace type data.

    Replaces the one-liner dict comprehension that appeared twice in the
    same function in clone.py (once for workflows, once for work items).

    Args:
        types_data: List of workspace work item type dicts (must have
                    ``"id"`` and ``"name"`` keys).

    Returns:
        Dict of ``{type_uuid: type_name}``.
    """
    return {
        wit['id']: wit['name']
        for wit in types_data
        if 'id' in wit and 'name' in wit
    }
