"""Auto-write remote IDs back to YAML files after first push.

After creating work items in Plane, items that lack a user-provided `id`
get tracked by content hash (e.g., `hash:<sha>`). If the user later edits
the title, the hash changes and the next push creates a duplicate.

This module solves that by writing the Plane sequence ID (e.g., "PROJ-123")
back into the YAML source files after creation, giving each item a stable
tracking key going forward.

Usage:
    from planecompose.utils.id_writer import write_ids_to_yaml
    written = write_ids_to_yaml(created_results, "PROJ", root_path)
"""
import yaml
from pathlib import Path

try:
    import fcntl
    HAS_FCNTL = True
except ImportError:
    HAS_FCNTL = False

from planecompose.sync.executor import SyncItemResult
from planecompose.utils.logger import get_logger

logger = get_logger()


def _locked_write(file_path: Path, content: str) -> None:
    """Write content to a file with exclusive locking.

    On Unix, acquires an exclusive lock (fcntl.LOCK_EX) on the file itself
    for the duration of the write. On platforms without fcntl (e.g., Windows),
    falls back to a plain write with a debug log.
    """
    if HAS_FCNTL:
        with open(file_path, 'w', encoding='utf-8') as f:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)  # type: ignore[attr-defined]
            try:
                f.write(content)
                f.flush()
            finally:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)  # type: ignore[attr-defined]
    else:
        logger.debug("fcntl not available; writing without file lock")
        file_path.write_text(content, encoding='utf-8')


def write_ids_to_yaml(
    created_results: list[SyncItemResult],
    project_key: str,
    root_path: Path,
) -> int:
    """Write auto-assigned IDs back to YAML files."""
    written_count, _ = write_ids_to_yaml_with_remaps(
        created_results,
        project_key,
        root_path,
    )
    return written_count


def write_ids_to_yaml_with_remaps(
    created_results: list[SyncItemResult],
    project_key: str,
    root_path: Path,
) -> tuple[int, list[tuple[str, str]]]:
    """Write auto-assigned IDs back to YAML source files.

    For each successfully created work item that had no user-provided ``id``,
    this inserts ``id: PROJ-<sequence>`` into the YAML file so future pushes
    use a stable tracking key instead of a content hash.

    Args:
        created_results: Results from SyncExecutor for CREATE operations.
        project_key: Project identifier prefix (e.g., "PROJ").
        root_path: Project root directory (YAML paths are relative to this).

    Returns:
        Tuple of:
        - Number of items that had IDs written back
        - List of ``(old_tracking_key, new_tracking_key)`` remaps for items
          that were successfully written
    """
    items_by_file: dict[str, list[tuple[int, str, str]]] = {}

    for result in created_results:
        if not result.success or result.sequence_id is None:
            continue

        sync_item = result.item
        # Only write back if the item had no user-provided id
        if sync_item.item.id:
            continue

        source_file = sync_item.source_file
        index = sync_item.index
        readable_id = f"{project_key}-{result.sequence_id}"
        new_tracking_key = f"id:{readable_id}"

        if source_file not in items_by_file:
            items_by_file[source_file] = []
        items_by_file[source_file].append((index, readable_id, new_tracking_key))

    if not items_by_file:
        return 0, []

    written_count = 0
    # Track which (source_file, index) pairs were successfully written
    written_pairs: set[tuple[str, int]] = set()

    for source_file, planned_entries in items_by_file.items():
        try:
            file_path = root_path / source_file
            if not file_path.exists():
                logger.warning(f"Source file not found for ID writeback: {file_path}")
                continue

            writable_pairs = _collect_writable_pairs(
                file_path,
                [(index, readable_id) for index, readable_id, _ in planned_entries],
            )
            if not writable_pairs:
                continue

            written = _write_ids_to_file(file_path, writable_pairs)
            written_count += written
            written_indices = {index for index, _ in writable_pairs}
            for index, _, _ in planned_entries:
                if index in written_indices:
                    written_pairs.add((source_file, index))

        except Exception as e:
            logger.error(f"Failed to write IDs to {source_file}: {e}")

    # Build remaps from original tracking keys for items we wrote
    actual_remaps: list[tuple[str, str]] = []
    for result in created_results:
        if not result.success or result.sequence_id is None:
            continue
        sync_item = result.item
        if sync_item.item.id:
            continue
        if (sync_item.source_file, sync_item.index) in written_pairs:
            new_tracking_key = f"id:{project_key}-{result.sequence_id}"
            actual_remaps.append((sync_item.tracking_key, new_tracking_key))

    return written_count, actual_remaps


def _collect_writable_pairs(
    file_path: Path,
    index_id_pairs: list[tuple[int, str]],
) -> list[tuple[int, str]]:
    """Return the pairs that can actually be written to a given YAML file."""
    content = file_path.read_text(encoding="utf-8")
    data = yaml.safe_load(content)
    if data is None:
        return []

    if isinstance(data, dict):
        # workitems: root key format (work/workitems.yaml)
        items_list = data.get("workitems")
        if isinstance(items_list, list):
            valid_pairs: list[tuple[int, str]] = []
            for index, readable_id in index_id_pairs:
                if 0 <= index < len(items_list) and isinstance(items_list[index], dict) and not items_list[index].get("id"):
                    valid_pairs.append((index, readable_id))
            return valid_pairs
        # Single-item dict format (legacy)
        for index, readable_id in index_id_pairs:
            if index == 0 and not data.get("id"):
                return [(index, readable_id)]
        return []

    if isinstance(data, list):
        valid_pairs = []
        for index, readable_id in index_id_pairs:
            if 0 <= index < len(data) and isinstance(data[index], dict) and not data[index].get("id"):
                valid_pairs.append((index, readable_id))
        return valid_pairs

    return []


def _write_ids_to_file(
    file_path: Path,
    index_id_pairs: list[tuple[int, str]],
) -> int:
    """Write IDs into a single YAML file, preserving formatting where possible.

    The function reads the file, parses the YAML structure, adds ``id`` fields
    to the appropriate items, and writes it back. It uses a line-based insertion
    approach to preserve comments and formatting as much as possible.

    Args:
        file_path: Absolute path to the YAML file.
        index_id_pairs: List of (item_index, readable_id) tuples.

    Returns:
        Number of IDs written.
    """
    content = file_path.read_text(encoding='utf-8')

    # Parse to understand structure
    data = yaml.safe_load(content)
    if data is None:
        return 0

    is_list = isinstance(data, list)
    is_dict = isinstance(data, dict)

    if is_dict:
        # workitems: root key format (work/workitems.yaml) — delegate to list logic
        items_list = data.get("workitems")
        if isinstance(items_list, list):
            sorted_pairs = sorted(index_id_pairs, key=lambda p: p[0], reverse=True)
            valid_pairs = [
                (idx, rid) for idx, rid in sorted_pairs
                if 0 <= idx < len(items_list) and not items_list[idx].get("id")
            ]
            if not valid_pairs:
                return 0
            updated_content = _insert_ids_list(content, valid_pairs)
            _locked_write(file_path, updated_content)
            return len(valid_pairs)

        # Single item dict format (legacy) - index must be 0
        pairs_for_this = [(idx, rid) for idx, rid in index_id_pairs if idx == 0]
        if not pairs_for_this:
            return 0
        _, readable_id = pairs_for_this[0]

        # Already has an id? skip
        if data.get('id'):
            return 0

        updated_content = _insert_id_single_item(content, readable_id)
        _locked_write(file_path, updated_content)
        return 1

    elif is_list:
        # Sort pairs by index (descending) so insertions don't shift indices
        sorted_pairs = sorted(index_id_pairs, key=lambda p: p[0], reverse=True)

        # Validate indices and filter items that already have IDs
        valid_pairs = []
        for idx, readable_id in sorted_pairs:
            if 0 <= idx < len(data) and not data[idx].get('id'):
                valid_pairs.append((idx, readable_id))

        if not valid_pairs:
            return 0

        updated_content = _insert_ids_list(content, valid_pairs)
        _locked_write(file_path, updated_content)
        return len(valid_pairs)

    return 0


def _insert_id_single_item(content: str, readable_id: str) -> str:
    """Insert ``id`` field into a single-item (dict) YAML file.

    Inserts ``id: <value>`` as the first key in the document, before ``title``.
    """
    lines = content.splitlines(keepends=True)
    insert_pos = 0

    # Find first non-comment, non-empty line (the start of the mapping)
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped and not stripped.startswith('#') and not stripped.startswith('---'):
            insert_pos = i
            break

    # Detect indentation from the first key line
    indent = _detect_indent(lines[insert_pos]) if insert_pos < len(lines) else ''

    id_line = f"{indent}id: {_format_yaml_value(readable_id)}\n"
    lines.insert(insert_pos, id_line)
    return ''.join(lines)


def _insert_ids_list(content: str, index_id_pairs: list[tuple[int, str]]) -> str:
    """Insert ``id`` fields into a list-style YAML file.

    Each list item starts with ``- ``. We find the Nth item and insert
    ``id: <value>`` right after the ``- `` line (before ``title``).

    Args:
        index_id_pairs: Must be sorted by index DESCENDING to avoid shifting.
    """
    lines = content.splitlines(keepends=True)

    # Find the line positions of each top-level list item start.
    # Strategy: collect all "- " lines with their indentation level, then keep
    # only those at the minimum indent (i.e., the top-level items). This avoids
    # mistaking nested list items (e.g., "  - Infrastructure" inside a labels
    # block) for top-level work item entries, which would shift all indices and
    # inject IDs at the wrong position.
    candidates: list[tuple[int, int]] = []  # (line_number, indent_level)
    for i, line in enumerate(lines):
        stripped = line.lstrip()
        if stripped.startswith('- ') and not stripped.startswith('- -'):
            indent = len(line) - len(stripped)
            candidates.append((i, indent))

    item_starts: list[int] = []
    if candidates:
        min_indent = min(indent for _, indent in candidates)
        item_starts = [ln for ln, indent in candidates if indent == min_indent]

    for idx, readable_id in index_id_pairs:
        if idx >= len(item_starts):
            logger.warning(f"Item index {idx} out of range (found {len(item_starts)} items)")
            continue

        item_line_num = item_starts[idx]
        item_line = lines[item_line_num]

        # Detect the indentation pattern
        # For "- title: ...", the continuation indent is "  " (2 spaces after "- ")
        dash_indent = len(item_line) - len(item_line.lstrip())
        content_indent = ' ' * (dash_indent + 2)

        # Check if item is inline (- title: ...) or block (- \n  title: ...)
        stripped = item_line.lstrip()
        after_dash = stripped[2:]  # Content after "- "

        if after_dash.strip().startswith('title:') or after_dash.strip().startswith('id:'):
            # Inline format: "- title: Foo" -> insert "  id: X" before this line
            # and convert to: "- id: X\n  title: Foo"
            # Actually, insert id line right after the dash, pushing title down
            # We need to change "- title: ..." to "- id: X\n  title: ..."

            # Replace the "- <first_key>: ..." with "- id: <value>\n  <first_key>: ..."
            id_line = f"{' ' * dash_indent}- id: {_format_yaml_value(readable_id)}\n"
            rest_line = f"{content_indent}{after_dash.lstrip()}"
            # Preserve original line ending
            if not rest_line.endswith('\n') and item_line.endswith('\n'):
                rest_line += '\n'
            lines[item_line_num] = id_line + rest_line
        else:
            # The first key is on a subsequent line
            # Insert id line right after the "- " line
            id_line = f"{content_indent}id: {_format_yaml_value(readable_id)}\n"
            lines.insert(item_line_num + 1, id_line)
            # Adjust subsequent item_starts since we inserted a line
            # (Not needed since we process in descending order)

    return ''.join(lines)


def _detect_indent(line: str) -> str:
    """Detect the leading whitespace of a line."""
    return line[:len(line) - len(line.lstrip())]


def _format_yaml_value(value: str) -> str:
    """Format a value for safe YAML output.

    Quotes the value if it contains special YAML characters.
    For simple identifiers like "PROJ-123", no quoting is needed.
    """
    # PROJ-123 style IDs are safe without quoting
    if value and all(c.isalnum() or c in '-_.' for c in value):
        return value
    return f'"{value}"'
