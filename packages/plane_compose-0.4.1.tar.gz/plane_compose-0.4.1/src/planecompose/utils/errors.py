"""Shared error handling utilities for CLI commands.

Provides consistent, user-friendly error messages across all CLI commands.

NOTE: Error type detection is centralized in backend/client.py.
This module focuses on USER-FRIENDLY error display, not detection.
"""
from rich.console import Console
from rich.panel import Panel

from planecompose.exceptions import (
    AuthenticationError,
    PermissionError,
    NotFoundError,
    RateLimitError,
    ConfigError,
    ValidationError,
    NetworkError,
    StateError,
    SyncConflictError,
    TimeoutError as PlaneTimeoutError,
)
from planecompose.backend.client import detect_error_type

console = Console()


def handle_api_error(error: Exception, context: str = "") -> None:
    """
    Handle API errors with helpful, user-friendly messages.

    Uses centralized error detection from backend/client.py to determine
    error type, then displays appropriate help message.

    Args:
        error: The exception that was raised
        context: Optional context about what operation was being performed
    """
    # Use centralized error detection
    error_class = detect_error_type(error)

    if error_class == AuthenticationError:
        _show_auth_error()
    elif error_class == PermissionError:
        _show_permission_error(context)
    elif error_class == NotFoundError:
        _show_not_found_error(context)
    elif error_class == RateLimitError:
        _show_rate_limit_error(error)
    elif error_class == NetworkError:
        if isinstance(error, PlaneTimeoutError):
            _show_timeout_error(error)
        else:
            _show_network_error(error)
    elif isinstance(error, SyncConflictError):
        _show_sync_conflict_error(error)
    elif isinstance(error, ConfigError):
        _show_config_error(error)
    elif isinstance(error, ValidationError):
        _show_validation_error(error)
    elif isinstance(error, StateError):
        _show_state_error(error)
    else:
        _show_generic_error(error)


def _show_auth_error() -> None:
    """Show authentication error message."""
    console.print("\n[red]Authentication Failed (401)[/red]")
    console.print("\nYour API key is invalid or expired.")
    console.print("\n[yellow]Solution:[/yellow]")
    console.print("  Run [cyan]plane auth login[/cyan] to re-authenticate")
    console.print("\n[dim]Get your API key from: https://app.plane.so/<workspace-slug>/settings/account/api-tokens/[/dim]")


def _show_permission_error(context: str) -> None:
    """Show permission denied error message."""
    console.print("\n[red]Permission Denied (403)[/red]")

    if context:
        console.print(f"\nYou don't have permission to {context}.")
    else:
        console.print("\nYou don't have permission for this operation.")

    console.print("\n[yellow]Solutions:[/yellow]")
    console.print("  - Verify you're a member/admin of the workspace")
    console.print("  - Use a workspace where you have proper permissions")
    console.print("  - Check with your workspace administrator")
    console.print("\nRun [cyan]plane auth whoami[/cyan] to verify your access")


def _show_not_found_error(context: str) -> None:
    """Show not found error message."""
    console.print("\n[red]Not Found (404)[/red]")

    console.print("\nThe resource doesn't exist or you don't have access to it.")

    console.print("\n[yellow]Check:[/yellow]")
    console.print("  - Workspace name in plane.yaml is correct")
    console.print("  - Project key/UUID in plane.yaml is valid")
    console.print("  - You have access to this workspace/project")

    if "project" in context.lower() or not context:
        console.print("\n[dim]Tip: Run [cyan]plane schema push[/cyan] to create a new project[/dim]")


def _show_rate_limit_error(error: Exception) -> None:
    """Show rate limit error message."""
    console.print("\n[red]Rate Limit Exceeded (429)[/red]")
    console.print("\nToo many API requests. Please wait and try again.")

    retry_after = getattr(error, 'retry_after', None)
    if retry_after:
        console.print(f"\n[yellow]Retry after:[/yellow] {retry_after} seconds")

    console.print("\n[yellow]Solutions:[/yellow]")
    console.print("  - Wait a minute before retrying")
    console.print("  - Run [cyan]plane rate stats[/cyan] to check usage")
    console.print("  - Reduce batch size or use --dry-run first")
    console.print("\n[dim]Rate limit: 50 requests/minute (configurable via PLANE_RATE_LIMIT_PER_MINUTE)[/dim]")


def _show_network_error(error: Exception) -> None:
    """Show network error message."""
    console.print("\n[red]Network Error[/red]")
    console.print(f"\nCould not connect to Plane API: {error}")

    console.print("\n[yellow]Check:[/yellow]")
    console.print("  - Your internet connection")
    console.print("  - The API URL in plane.yaml (default: https://api.plane.so)")
    console.print("  - Any firewall or proxy settings")


def _show_config_error(error: Exception) -> None:
    """Show configuration error message."""
    console.print("\n[red]Configuration Error[/red]")
    console.print(f"\n{error}")

    console.print("\n[yellow]Check:[/yellow]")
    console.print("  - plane.yaml exists and is valid YAML")
    console.print("  - Required fields (workspace, project.key) are set")
    console.print("  - Schema files in schema/ are valid")


def _show_validation_error(error: ValidationError) -> None:
    """Show validation error message."""
    console.print("\n[red]Validation Error[/red]")

    if error.field:
        console.print(f"\nInvalid value for field: [cyan]{error.field}[/cyan]")

    console.print(f"\n{error.message}")

    if error.details:
        console.print("\n[dim]Details:[/dim]")
        for key, value in error.details.items():
            console.print(f"  {key}: {value}")


def _show_state_error(error: StateError) -> None:
    """Show state error message."""
    console.print("\n[red]State Error[/red]")
    console.print(f"\n{error}")

    console.print("\n[yellow]Solutions:[/yellow]")
    console.print("  - Run [cyan]plane state show[/cyan] to inspect state")
    console.print("  - Run [cyan]plane state reset[/cyan] to reset state (caution: may cause duplicates)")
    console.print("  - Delete .plane/state.json manually if corrupted")


def _show_timeout_error(error: Exception) -> None:
    """Show timeout error message."""
    console.print("\n[red]Request Timed Out[/red]")
    console.print(f"\n{error}")

    console.print("\n[yellow]Solutions:[/yellow]")
    console.print("  - Check your network connection")
    console.print("  - Increase timeout: set PLANE_API_TIMEOUT to a higher value (default: 30s)")
    console.print("  - The Plane server may be under heavy load; try again later")


def _show_sync_conflict_error(error: Exception) -> None:
    """Show sync conflict error message."""
    console.print("\n[red]Sync Conflict Detected[/red]")
    console.print(f"\n{error}")

    conflicts = getattr(error, 'conflicts', [])
    if conflicts:
        console.print("\n[yellow]Conflicting items:[/yellow]")
        for item in conflicts[:10]:
            if isinstance(item, tuple):
                console.print(f"  - {item[0]}: {item[1]}")
            else:
                console.print(f"  - {item}")

    console.print("\n[yellow]Solutions:[/yellow]")
    console.print("  - Run [cyan]plane push --force[/cyan] to overwrite remote changes")
    console.print("  - Run [cyan]plane pull[/cyan] to fetch remote changes first")
    console.print("  - Run [cyan]plane schema import[/cyan] to re-sync state")


def _show_generic_error(error: Exception) -> None:
    """Show generic error message."""
    from rich.markup import escape
    console.print(f"\n[red]Error:[/red] {escape(str(error))}")
    console.print("\n[dim]If this error persists, please report it at:[/dim]")
    console.print("[dim]https://github.com/makeplane/compose/issues[/dim]")


def show_project_not_found(workspace: str, project_key: str, available_projects: list | None = None) -> None:
    """
    Show a helpful error when project key doesn't exist.

    Args:
        workspace: Workspace slug
        project_key: Project key that wasn't found
        available_projects: List of available projects (optional)
    """
    error_lines = [
        f"Project '[cyan]{project_key.upper()}[/cyan]' not found in workspace '[cyan]{workspace}[/cyan]'.",
        "",
        "[yellow]Available projects:[/yellow]",
    ]

    if available_projects:
        for p in available_projects[:10]:
            name = getattr(p, 'name', str(p))
            identifier = getattr(p, 'identifier', '')
            if identifier:
                error_lines.append(f"  - {name} ([cyan]{identifier}[/cyan])")
            else:
                error_lines.append(f"  - {name}")

        if len(available_projects) > 10:
            error_lines.append(f"  ... and {len(available_projects) - 10} more")
    else:
        error_lines.append("  [dim](no projects found)[/dim]")

    error_lines.extend([
        "",
        "[yellow]Solutions:[/yellow]",
        "  1. Fix the 'key' in plane.yaml to match an existing project",
        "  2. Or run [cyan]plane schema push[/cyan] to create the project",
    ])

    console.print()
    console.print(Panel(
        "\n".join(error_lines),
        title="[red]Project Not Found[/red]",
        border_style="red",
    ))


def show_success(message: str, details: list[str] | None = None) -> None:
    """Show a success message with optional details."""
    console.print(f"\n[bold green]{message}[/bold green]")

    if details:
        for detail in details:
            console.print(f"  {detail}")


def show_warning(message: str, suggestions: list[str] | None = None) -> None:
    """Show a warning message with optional suggestions."""
    console.print(f"\n[yellow]Warning:[/yellow] {message}")

    if suggestions:
        console.print("\n[dim]Suggestions:[/dim]")
        for suggestion in suggestions:
            console.print(f"  - {suggestion}")
