from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="TenantWorkflowDefinitionResponse")


@_attrs_define
class TenantWorkflowDefinitionResponse:
    """
    Attributes:
        app_id (str):
        workflow_name (str):
        system_prompt (str):
        multi_turn (bool):
        media_input (bool):
        created_at (datetime.datetime):
    """

    app_id: str
    workflow_name: str
    system_prompt: str
    multi_turn: bool
    media_input: bool
    created_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        app_id = self.app_id

        workflow_name = self.workflow_name

        system_prompt = self.system_prompt

        multi_turn = self.multi_turn

        media_input = self.media_input

        created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "app_id": app_id,
                "workflow_name": workflow_name,
                "system_prompt": system_prompt,
                "multi_turn": multi_turn,
                "media_input": media_input,
                "created_at": created_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        app_id = d.pop("app_id")

        workflow_name = d.pop("workflow_name")

        system_prompt = d.pop("system_prompt")

        multi_turn = d.pop("multi_turn")

        media_input = d.pop("media_input")

        created_at = isoparse(d.pop("created_at"))

        tenant_workflow_definition_response = cls(
            app_id=app_id,
            workflow_name=workflow_name,
            system_prompt=system_prompt,
            multi_turn=multi_turn,
            media_input=media_input,
            created_at=created_at,
        )

        tenant_workflow_definition_response.additional_properties = d
        return tenant_workflow_definition_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
