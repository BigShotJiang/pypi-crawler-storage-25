from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="TenantWorkflowDefinitionRequest")


@_attrs_define
class TenantWorkflowDefinitionRequest:
    """
    Attributes:
        system_prompt (str):
        multi_turn (bool | Unset):  Default: False.
        media_input (bool | Unset):  Default: False.
    """

    system_prompt: str
    multi_turn: bool | Unset = False
    media_input: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        system_prompt = self.system_prompt

        multi_turn = self.multi_turn

        media_input = self.media_input

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "system_prompt": system_prompt,
            }
        )
        if multi_turn is not UNSET:
            field_dict["multi_turn"] = multi_turn
        if media_input is not UNSET:
            field_dict["media_input"] = media_input

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        system_prompt = d.pop("system_prompt")

        multi_turn = d.pop("multi_turn", UNSET)

        media_input = d.pop("media_input", UNSET)

        tenant_workflow_definition_request = cls(
            system_prompt=system_prompt,
            multi_turn=multi_turn,
            media_input=media_input,
        )

        tenant_workflow_definition_request.additional_properties = d
        return tenant_workflow_definition_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
