from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.apple_exchange_request import AppleExchangeRequest
from ...models.apple_exchange_response import AppleExchangeResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    *,
    body: AppleExchangeRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/apple/exchange",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AppleExchangeResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = AppleExchangeResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AppleExchangeResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AppleExchangeRequest,
) -> Response[AppleExchangeResponse | HTTPValidationError]:
    """Apple Exchange

     Native iOS Sign in with Apple — identity token only.

    Accepts the identity token from ASAuthorizationAppleIDCredential (no auth code
    exchange or nonce required for native app flows). Returns a minimal response
    with the access JWT, user_id, and app_id for use as Bearer credentials.

    The app_id is determined from the bundle ID (aud claim) in the identity token.

    Args:
        body (AppleExchangeRequest): Request body for native iOS Apple identity token exchange.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppleExchangeResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: AppleExchangeRequest,
) -> AppleExchangeResponse | HTTPValidationError | None:
    """Apple Exchange

     Native iOS Sign in with Apple — identity token only.

    Accepts the identity token from ASAuthorizationAppleIDCredential (no auth code
    exchange or nonce required for native app flows). Returns a minimal response
    with the access JWT, user_id, and app_id for use as Bearer credentials.

    The app_id is determined from the bundle ID (aud claim) in the identity token.

    Args:
        body (AppleExchangeRequest): Request body for native iOS Apple identity token exchange.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppleExchangeResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AppleExchangeRequest,
) -> Response[AppleExchangeResponse | HTTPValidationError]:
    """Apple Exchange

     Native iOS Sign in with Apple — identity token only.

    Accepts the identity token from ASAuthorizationAppleIDCredential (no auth code
    exchange or nonce required for native app flows). Returns a minimal response
    with the access JWT, user_id, and app_id for use as Bearer credentials.

    The app_id is determined from the bundle ID (aud claim) in the identity token.

    Args:
        body (AppleExchangeRequest): Request body for native iOS Apple identity token exchange.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppleExchangeResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: AppleExchangeRequest,
) -> AppleExchangeResponse | HTTPValidationError | None:
    """Apple Exchange

     Native iOS Sign in with Apple — identity token only.

    Accepts the identity token from ASAuthorizationAppleIDCredential (no auth code
    exchange or nonce required for native app flows). Returns a minimal response
    with the access JWT, user_id, and app_id for use as Bearer credentials.

    The app_id is determined from the bundle ID (aud claim) in the identity token.

    Args:
        body (AppleExchangeRequest): Request body for native iOS Apple identity token exchange.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppleExchangeResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
