from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="AppleExchangeResponse")


@_attrs_define
class AppleExchangeResponse:
    """Minimal token response for native iOS clients.

    Attributes:
        jwt (str): Access JWT for Bearer auth
        user_id (str): Stable user identifier
        app_id (str): App identifier (tenant)
    """

    jwt: str
    user_id: str
    app_id: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        jwt = self.jwt

        user_id = self.user_id

        app_id = self.app_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "jwt": jwt,
                "user_id": user_id,
                "app_id": app_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        jwt = d.pop("jwt")

        user_id = d.pop("user_id")

        app_id = d.pop("app_id")

        apple_exchange_response = cls(
            jwt=jwt,
            user_id=user_id,
            app_id=app_id,
        )

        apple_exchange_response.additional_properties = d
        return apple_exchange_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
