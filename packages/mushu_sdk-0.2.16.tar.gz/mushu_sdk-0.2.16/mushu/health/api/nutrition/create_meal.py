from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.meal import Meal
from ...models.meal_create_request import MealCreateRequest
from ...types import Response


def _get_kwargs(
    app_id: str,
    user_id: str,
    *,
    body: MealCreateRequest,
    authorization: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["authorization"] = authorization

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/apps/{app_id}/nutrition/{user_id}/meals".format(
            app_id=quote(str(app_id), safe=""),
            user_id=quote(str(user_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | Meal | None:
    if response.status_code == 201:
        response_201 = Meal.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | Meal]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: MealCreateRequest,
    authorization: str,
) -> Response[HTTPValidationError | Meal]:
    """Create Meal

     Create a saved meal definition (collection of items + quantities).

    Args:
        app_id (str):
        user_id (str):
        authorization (str):
        body (MealCreateRequest): Create a saved meal (collection of items).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | Meal]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        user_id=user_id,
        body=body,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: MealCreateRequest,
    authorization: str,
) -> HTTPValidationError | Meal | None:
    """Create Meal

     Create a saved meal definition (collection of items + quantities).

    Args:
        app_id (str):
        user_id (str):
        authorization (str):
        body (MealCreateRequest): Create a saved meal (collection of items).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | Meal
    """

    return sync_detailed(
        app_id=app_id,
        user_id=user_id,
        client=client,
        body=body,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: MealCreateRequest,
    authorization: str,
) -> Response[HTTPValidationError | Meal]:
    """Create Meal

     Create a saved meal definition (collection of items + quantities).

    Args:
        app_id (str):
        user_id (str):
        authorization (str):
        body (MealCreateRequest): Create a saved meal (collection of items).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | Meal]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        user_id=user_id,
        body=body,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: MealCreateRequest,
    authorization: str,
) -> HTTPValidationError | Meal | None:
    """Create Meal

     Create a saved meal definition (collection of items + quantities).

    Args:
        app_id (str):
        user_id (str):
        authorization (str):
        body (MealCreateRequest): Create a saved meal (collection of items).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | Meal
    """

    return (
        await asyncio_detailed(
            app_id=app_id,
            user_id=user_id,
            client=client,
            body=body,
            authorization=authorization,
        )
    ).parsed
