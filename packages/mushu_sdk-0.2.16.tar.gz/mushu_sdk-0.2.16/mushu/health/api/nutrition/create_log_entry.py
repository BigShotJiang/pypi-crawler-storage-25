from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.log_entry_create_request import LogEntryCreateRequest
from ...models.log_entry_response import LogEntryResponse
from ...types import Response


def _get_kwargs(
    app_id: str,
    user_id: str,
    *,
    body: LogEntryCreateRequest,
    authorization: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["authorization"] = authorization

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/apps/{app_id}/nutrition/{user_id}/log".format(
            app_id=quote(str(app_id), safe=""),
            user_id=quote(str(user_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | LogEntryResponse | None:
    if response.status_code == 201:
        response_201 = LogEntryResponse.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | LogEntryResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: LogEntryCreateRequest,
    authorization: str,
) -> Response[HTTPValidationError | LogEntryResponse]:
    """Create Log Entry

     Log a meal. Provide meal_uuid to reference a saved meal, or nutrients for a one-off.

    Args:
        app_id (str):
        user_id (str):
        authorization (str):
        body (LogEntryCreateRequest): Log a meal at a point in time.

            Two paths:
              1. meal_uuid provided — server joins items, computes snapshot nutrients
              2. nutrients provided directly — for AI estimates / quick log without saving a meal

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | LogEntryResponse]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        user_id=user_id,
        body=body,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: LogEntryCreateRequest,
    authorization: str,
) -> HTTPValidationError | LogEntryResponse | None:
    """Create Log Entry

     Log a meal. Provide meal_uuid to reference a saved meal, or nutrients for a one-off.

    Args:
        app_id (str):
        user_id (str):
        authorization (str):
        body (LogEntryCreateRequest): Log a meal at a point in time.

            Two paths:
              1. meal_uuid provided — server joins items, computes snapshot nutrients
              2. nutrients provided directly — for AI estimates / quick log without saving a meal

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | LogEntryResponse
    """

    return sync_detailed(
        app_id=app_id,
        user_id=user_id,
        client=client,
        body=body,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: LogEntryCreateRequest,
    authorization: str,
) -> Response[HTTPValidationError | LogEntryResponse]:
    """Create Log Entry

     Log a meal. Provide meal_uuid to reference a saved meal, or nutrients for a one-off.

    Args:
        app_id (str):
        user_id (str):
        authorization (str):
        body (LogEntryCreateRequest): Log a meal at a point in time.

            Two paths:
              1. meal_uuid provided — server joins items, computes snapshot nutrients
              2. nutrients provided directly — for AI estimates / quick log without saving a meal

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | LogEntryResponse]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        user_id=user_id,
        body=body,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: LogEntryCreateRequest,
    authorization: str,
) -> HTTPValidationError | LogEntryResponse | None:
    """Create Log Entry

     Log a meal. Provide meal_uuid to reference a saved meal, or nutrients for a one-off.

    Args:
        app_id (str):
        user_id (str):
        authorization (str):
        body (LogEntryCreateRequest): Log a meal at a point in time.

            Two paths:
              1. meal_uuid provided — server joins items, computes snapshot nutrients
              2. nutrients provided directly — for AI estimates / quick log without saving a meal

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | LogEntryResponse
    """

    return (
        await asyncio_detailed(
            app_id=app_id,
            user_id=user_id,
            client=client,
            body=body,
            authorization=authorization,
        )
    ).parsed
