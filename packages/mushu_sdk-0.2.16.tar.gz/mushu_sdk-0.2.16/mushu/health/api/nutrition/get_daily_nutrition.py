from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.daily_nutrition_totals import DailyNutritionTotals
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response


def _get_kwargs(
    app_id: str,
    user_id: str,
    *,
    local_date: str,
    authorization: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["authorization"] = authorization

    params: dict[str, Any] = {}

    params["local_date"] = local_date

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/apps/{app_id}/nutrition/{user_id}/daily".format(
            app_id=quote(str(app_id), safe=""),
            user_id=quote(str(user_id), safe=""),
        ),
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DailyNutritionTotals | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = DailyNutritionTotals.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DailyNutritionTotals | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    local_date: str,
    authorization: str,
) -> Response[DailyNutritionTotals | HTTPValidationError]:
    """Get Daily Nutrition

    Args:
        app_id (str):
        user_id (str):
        local_date (str): YYYY-MM-DD in user's local timezone
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DailyNutritionTotals | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        user_id=user_id,
        local_date=local_date,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    local_date: str,
    authorization: str,
) -> DailyNutritionTotals | HTTPValidationError | None:
    """Get Daily Nutrition

    Args:
        app_id (str):
        user_id (str):
        local_date (str): YYYY-MM-DD in user's local timezone
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DailyNutritionTotals | HTTPValidationError
    """

    return sync_detailed(
        app_id=app_id,
        user_id=user_id,
        client=client,
        local_date=local_date,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    local_date: str,
    authorization: str,
) -> Response[DailyNutritionTotals | HTTPValidationError]:
    """Get Daily Nutrition

    Args:
        app_id (str):
        user_id (str):
        local_date (str): YYYY-MM-DD in user's local timezone
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DailyNutritionTotals | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        user_id=user_id,
        local_date=local_date,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    local_date: str,
    authorization: str,
) -> DailyNutritionTotals | HTTPValidationError | None:
    """Get Daily Nutrition

    Args:
        app_id (str):
        user_id (str):
        local_date (str): YYYY-MM-DD in user's local timezone
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DailyNutritionTotals | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            app_id=app_id,
            user_id=user_id,
            client=client,
            local_date=local_date,
            authorization=authorization,
        )
    ).parsed
