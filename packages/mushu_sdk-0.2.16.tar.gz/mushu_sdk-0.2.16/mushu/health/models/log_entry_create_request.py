from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.nutrients_mixin import NutrientsMixin


T = TypeVar("T", bound="LogEntryCreateRequest")


@_attrs_define
class LogEntryCreateRequest:
    """Log a meal at a point in time.

    Two paths:
      1. meal_uuid provided — server joins items, computes snapshot nutrients
      2. nutrients provided directly — for AI estimates / quick log without saving a meal

        Attributes:
            local_date (str):
            logged_at (str):
            meal_name (str):
            meal_uuid (None | str | Unset):
            source (str | Unset):  Default: 'womoji_food'.
            nutrients (None | NutrientsMixin | Unset):
    """

    local_date: str
    logged_at: str
    meal_name: str
    meal_uuid: None | str | Unset = UNSET
    source: str | Unset = "womoji_food"
    nutrients: None | NutrientsMixin | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.nutrients_mixin import NutrientsMixin

        local_date = self.local_date

        logged_at = self.logged_at

        meal_name = self.meal_name

        meal_uuid: None | str | Unset
        if isinstance(self.meal_uuid, Unset):
            meal_uuid = UNSET
        else:
            meal_uuid = self.meal_uuid

        source = self.source

        nutrients: dict[str, Any] | None | Unset
        if isinstance(self.nutrients, Unset):
            nutrients = UNSET
        elif isinstance(self.nutrients, NutrientsMixin):
            nutrients = self.nutrients.to_dict()
        else:
            nutrients = self.nutrients

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "local_date": local_date,
                "logged_at": logged_at,
                "meal_name": meal_name,
            }
        )
        if meal_uuid is not UNSET:
            field_dict["meal_uuid"] = meal_uuid
        if source is not UNSET:
            field_dict["source"] = source
        if nutrients is not UNSET:
            field_dict["nutrients"] = nutrients

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.nutrients_mixin import NutrientsMixin

        d = dict(src_dict)
        local_date = d.pop("local_date")

        logged_at = d.pop("logged_at")

        meal_name = d.pop("meal_name")

        def _parse_meal_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        meal_uuid = _parse_meal_uuid(d.pop("meal_uuid", UNSET))

        source = d.pop("source", UNSET)

        def _parse_nutrients(data: object) -> None | NutrientsMixin | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                nutrients_type_0 = NutrientsMixin.from_dict(data)

                return nutrients_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | NutrientsMixin | Unset, data)

        nutrients = _parse_nutrients(d.pop("nutrients", UNSET))

        log_entry_create_request = cls(
            local_date=local_date,
            logged_at=logged_at,
            meal_name=meal_name,
            meal_uuid=meal_uuid,
            source=source,
            nutrients=nutrients,
        )

        log_entry_create_request.additional_properties = d
        return log_entry_create_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
