from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.daily_nutrition_totals_totals import DailyNutritionTotalsTotals


T = TypeVar("T", bound="DailyNutritionTotals")


@_attrs_define
class DailyNutritionTotals:
    """Summed nutrition for a given date.

    Attributes:
        local_date (str):
        log_count (int):
        totals (DailyNutritionTotalsTotals):
    """

    local_date: str
    log_count: int
    totals: DailyNutritionTotalsTotals
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        local_date = self.local_date

        log_count = self.log_count

        totals = self.totals.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "local_date": local_date,
                "log_count": log_count,
                "totals": totals,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.daily_nutrition_totals_totals import DailyNutritionTotalsTotals

        d = dict(src_dict)
        local_date = d.pop("local_date")

        log_count = d.pop("log_count")

        totals = DailyNutritionTotalsTotals.from_dict(d.pop("totals"))

        daily_nutrition_totals = cls(
            local_date=local_date,
            log_count=log_count,
            totals=totals,
        )

        daily_nutrition_totals.additional_properties = d
        return daily_nutrition_totals

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
