from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.meal_item import MealItem


T = TypeVar("T", bound="Meal")


@_attrs_define
class Meal:
    """A saved meal definition.

    Attributes:
        meal_uuid (str):
        name (str):
        items (list[MealItem]):
        created_at (str):
        updated_at (str):
    """

    meal_uuid: str
    name: str
    items: list[MealItem]
    created_at: str
    updated_at: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        meal_uuid = self.meal_uuid

        name = self.name

        items = []
        for items_item_data in self.items:
            items_item = items_item_data.to_dict()
            items.append(items_item)

        created_at = self.created_at

        updated_at = self.updated_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "meal_uuid": meal_uuid,
                "name": name,
                "items": items,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.meal_item import MealItem

        d = dict(src_dict)
        meal_uuid = d.pop("meal_uuid")

        name = d.pop("name")

        items = []
        _items = d.pop("items")
        for items_item_data in _items:
            items_item = MealItem.from_dict(items_item_data)

            items.append(items_item)

        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        meal = cls(
            meal_uuid=meal_uuid,
            name=name,
            items=items,
            created_at=created_at,
            updated_at=updated_at,
        )

        meal.additional_properties = d
        return meal

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
