from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="Item")


@_attrs_define
class Item:
    """A food item in the library.

    Attributes:
        item_uuid (str):
        name (str):
        created_at (str):
        calories (float | Unset):  Default: 0.0.
        protein_g (float | Unset):  Default: 0.0.
        carbs_g (float | Unset):  Default: 0.0.
        fat_g (float | Unset):  Default: 0.0.
        fiber_g (float | Unset):  Default: 0.0.
        sugar_g (float | Unset):  Default: 0.0.
        saturated_fat_g (float | Unset):  Default: 0.0.
        monounsaturated_fat_g (float | Unset):  Default: 0.0.
        polyunsaturated_fat_g (float | Unset):  Default: 0.0.
        cholesterol_mg (float | Unset):  Default: 0.0.
        sodium_mg (float | Unset):  Default: 0.0.
        caffeine_mg (float | Unset):  Default: 0.0.
        water_ml (float | Unset):  Default: 0.0.
        vitamin_a_mcg (float | Unset):  Default: 0.0.
        vitamin_b6_mg (float | Unset):  Default: 0.0.
        vitamin_b12_mcg (float | Unset):  Default: 0.0.
        vitamin_c_mg (float | Unset):  Default: 0.0.
        vitamin_d_mcg (float | Unset):  Default: 0.0.
        vitamin_e_mg (float | Unset):  Default: 0.0.
        vitamin_k_mcg (float | Unset):  Default: 0.0.
        folate_mcg (float | Unset):  Default: 0.0.
        biotin_mcg (float | Unset):  Default: 0.0.
        niacin_mg (float | Unset):  Default: 0.0.
        pantothenic_acid_mg (float | Unset):  Default: 0.0.
        riboflavin_mg (float | Unset):  Default: 0.0.
        thiamin_mg (float | Unset):  Default: 0.0.
        calcium_mg (float | Unset):  Default: 0.0.
        chloride_mg (float | Unset):  Default: 0.0.
        chromium_mcg (float | Unset):  Default: 0.0.
        copper_mg (float | Unset):  Default: 0.0.
        iodine_mcg (float | Unset):  Default: 0.0.
        iron_mg (float | Unset):  Default: 0.0.
        magnesium_mg (float | Unset):  Default: 0.0.
        manganese_mg (float | Unset):  Default: 0.0.
        molybdenum_mcg (float | Unset):  Default: 0.0.
        phosphorus_mg (float | Unset):  Default: 0.0.
        potassium_mg (float | Unset):  Default: 0.0.
        selenium_mcg (float | Unset):  Default: 0.0.
        zinc_mg (float | Unset):  Default: 0.0.
        brand (None | str | Unset):
        serving_size (float | Unset):  Default: 1.0.
        serving_unit (str | Unset):  Default: 'serving'.
        source (str | Unset):  Default: 'ai_estimate'.
    """

    item_uuid: str
    name: str
    created_at: str
    calories: float | Unset = 0.0
    protein_g: float | Unset = 0.0
    carbs_g: float | Unset = 0.0
    fat_g: float | Unset = 0.0
    fiber_g: float | Unset = 0.0
    sugar_g: float | Unset = 0.0
    saturated_fat_g: float | Unset = 0.0
    monounsaturated_fat_g: float | Unset = 0.0
    polyunsaturated_fat_g: float | Unset = 0.0
    cholesterol_mg: float | Unset = 0.0
    sodium_mg: float | Unset = 0.0
    caffeine_mg: float | Unset = 0.0
    water_ml: float | Unset = 0.0
    vitamin_a_mcg: float | Unset = 0.0
    vitamin_b6_mg: float | Unset = 0.0
    vitamin_b12_mcg: float | Unset = 0.0
    vitamin_c_mg: float | Unset = 0.0
    vitamin_d_mcg: float | Unset = 0.0
    vitamin_e_mg: float | Unset = 0.0
    vitamin_k_mcg: float | Unset = 0.0
    folate_mcg: float | Unset = 0.0
    biotin_mcg: float | Unset = 0.0
    niacin_mg: float | Unset = 0.0
    pantothenic_acid_mg: float | Unset = 0.0
    riboflavin_mg: float | Unset = 0.0
    thiamin_mg: float | Unset = 0.0
    calcium_mg: float | Unset = 0.0
    chloride_mg: float | Unset = 0.0
    chromium_mcg: float | Unset = 0.0
    copper_mg: float | Unset = 0.0
    iodine_mcg: float | Unset = 0.0
    iron_mg: float | Unset = 0.0
    magnesium_mg: float | Unset = 0.0
    manganese_mg: float | Unset = 0.0
    molybdenum_mcg: float | Unset = 0.0
    phosphorus_mg: float | Unset = 0.0
    potassium_mg: float | Unset = 0.0
    selenium_mcg: float | Unset = 0.0
    zinc_mg: float | Unset = 0.0
    brand: None | str | Unset = UNSET
    serving_size: float | Unset = 1.0
    serving_unit: str | Unset = "serving"
    source: str | Unset = "ai_estimate"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        item_uuid = self.item_uuid

        name = self.name

        created_at = self.created_at

        calories = self.calories

        protein_g = self.protein_g

        carbs_g = self.carbs_g

        fat_g = self.fat_g

        fiber_g = self.fiber_g

        sugar_g = self.sugar_g

        saturated_fat_g = self.saturated_fat_g

        monounsaturated_fat_g = self.monounsaturated_fat_g

        polyunsaturated_fat_g = self.polyunsaturated_fat_g

        cholesterol_mg = self.cholesterol_mg

        sodium_mg = self.sodium_mg

        caffeine_mg = self.caffeine_mg

        water_ml = self.water_ml

        vitamin_a_mcg = self.vitamin_a_mcg

        vitamin_b6_mg = self.vitamin_b6_mg

        vitamin_b12_mcg = self.vitamin_b12_mcg

        vitamin_c_mg = self.vitamin_c_mg

        vitamin_d_mcg = self.vitamin_d_mcg

        vitamin_e_mg = self.vitamin_e_mg

        vitamin_k_mcg = self.vitamin_k_mcg

        folate_mcg = self.folate_mcg

        biotin_mcg = self.biotin_mcg

        niacin_mg = self.niacin_mg

        pantothenic_acid_mg = self.pantothenic_acid_mg

        riboflavin_mg = self.riboflavin_mg

        thiamin_mg = self.thiamin_mg

        calcium_mg = self.calcium_mg

        chloride_mg = self.chloride_mg

        chromium_mcg = self.chromium_mcg

        copper_mg = self.copper_mg

        iodine_mcg = self.iodine_mcg

        iron_mg = self.iron_mg

        magnesium_mg = self.magnesium_mg

        manganese_mg = self.manganese_mg

        molybdenum_mcg = self.molybdenum_mcg

        phosphorus_mg = self.phosphorus_mg

        potassium_mg = self.potassium_mg

        selenium_mcg = self.selenium_mcg

        zinc_mg = self.zinc_mg

        brand: None | str | Unset
        if isinstance(self.brand, Unset):
            brand = UNSET
        else:
            brand = self.brand

        serving_size = self.serving_size

        serving_unit = self.serving_unit

        source = self.source

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "item_uuid": item_uuid,
                "name": name,
                "created_at": created_at,
            }
        )
        if calories is not UNSET:
            field_dict["calories"] = calories
        if protein_g is not UNSET:
            field_dict["protein_g"] = protein_g
        if carbs_g is not UNSET:
            field_dict["carbs_g"] = carbs_g
        if fat_g is not UNSET:
            field_dict["fat_g"] = fat_g
        if fiber_g is not UNSET:
            field_dict["fiber_g"] = fiber_g
        if sugar_g is not UNSET:
            field_dict["sugar_g"] = sugar_g
        if saturated_fat_g is not UNSET:
            field_dict["saturated_fat_g"] = saturated_fat_g
        if monounsaturated_fat_g is not UNSET:
            field_dict["monounsaturated_fat_g"] = monounsaturated_fat_g
        if polyunsaturated_fat_g is not UNSET:
            field_dict["polyunsaturated_fat_g"] = polyunsaturated_fat_g
        if cholesterol_mg is not UNSET:
            field_dict["cholesterol_mg"] = cholesterol_mg
        if sodium_mg is not UNSET:
            field_dict["sodium_mg"] = sodium_mg
        if caffeine_mg is not UNSET:
            field_dict["caffeine_mg"] = caffeine_mg
        if water_ml is not UNSET:
            field_dict["water_ml"] = water_ml
        if vitamin_a_mcg is not UNSET:
            field_dict["vitamin_a_mcg"] = vitamin_a_mcg
        if vitamin_b6_mg is not UNSET:
            field_dict["vitamin_b6_mg"] = vitamin_b6_mg
        if vitamin_b12_mcg is not UNSET:
            field_dict["vitamin_b12_mcg"] = vitamin_b12_mcg
        if vitamin_c_mg is not UNSET:
            field_dict["vitamin_c_mg"] = vitamin_c_mg
        if vitamin_d_mcg is not UNSET:
            field_dict["vitamin_d_mcg"] = vitamin_d_mcg
        if vitamin_e_mg is not UNSET:
            field_dict["vitamin_e_mg"] = vitamin_e_mg
        if vitamin_k_mcg is not UNSET:
            field_dict["vitamin_k_mcg"] = vitamin_k_mcg
        if folate_mcg is not UNSET:
            field_dict["folate_mcg"] = folate_mcg
        if biotin_mcg is not UNSET:
            field_dict["biotin_mcg"] = biotin_mcg
        if niacin_mg is not UNSET:
            field_dict["niacin_mg"] = niacin_mg
        if pantothenic_acid_mg is not UNSET:
            field_dict["pantothenic_acid_mg"] = pantothenic_acid_mg
        if riboflavin_mg is not UNSET:
            field_dict["riboflavin_mg"] = riboflavin_mg
        if thiamin_mg is not UNSET:
            field_dict["thiamin_mg"] = thiamin_mg
        if calcium_mg is not UNSET:
            field_dict["calcium_mg"] = calcium_mg
        if chloride_mg is not UNSET:
            field_dict["chloride_mg"] = chloride_mg
        if chromium_mcg is not UNSET:
            field_dict["chromium_mcg"] = chromium_mcg
        if copper_mg is not UNSET:
            field_dict["copper_mg"] = copper_mg
        if iodine_mcg is not UNSET:
            field_dict["iodine_mcg"] = iodine_mcg
        if iron_mg is not UNSET:
            field_dict["iron_mg"] = iron_mg
        if magnesium_mg is not UNSET:
            field_dict["magnesium_mg"] = magnesium_mg
        if manganese_mg is not UNSET:
            field_dict["manganese_mg"] = manganese_mg
        if molybdenum_mcg is not UNSET:
            field_dict["molybdenum_mcg"] = molybdenum_mcg
        if phosphorus_mg is not UNSET:
            field_dict["phosphorus_mg"] = phosphorus_mg
        if potassium_mg is not UNSET:
            field_dict["potassium_mg"] = potassium_mg
        if selenium_mcg is not UNSET:
            field_dict["selenium_mcg"] = selenium_mcg
        if zinc_mg is not UNSET:
            field_dict["zinc_mg"] = zinc_mg
        if brand is not UNSET:
            field_dict["brand"] = brand
        if serving_size is not UNSET:
            field_dict["serving_size"] = serving_size
        if serving_unit is not UNSET:
            field_dict["serving_unit"] = serving_unit
        if source is not UNSET:
            field_dict["source"] = source

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        item_uuid = d.pop("item_uuid")

        name = d.pop("name")

        created_at = d.pop("created_at")

        calories = d.pop("calories", UNSET)

        protein_g = d.pop("protein_g", UNSET)

        carbs_g = d.pop("carbs_g", UNSET)

        fat_g = d.pop("fat_g", UNSET)

        fiber_g = d.pop("fiber_g", UNSET)

        sugar_g = d.pop("sugar_g", UNSET)

        saturated_fat_g = d.pop("saturated_fat_g", UNSET)

        monounsaturated_fat_g = d.pop("monounsaturated_fat_g", UNSET)

        polyunsaturated_fat_g = d.pop("polyunsaturated_fat_g", UNSET)

        cholesterol_mg = d.pop("cholesterol_mg", UNSET)

        sodium_mg = d.pop("sodium_mg", UNSET)

        caffeine_mg = d.pop("caffeine_mg", UNSET)

        water_ml = d.pop("water_ml", UNSET)

        vitamin_a_mcg = d.pop("vitamin_a_mcg", UNSET)

        vitamin_b6_mg = d.pop("vitamin_b6_mg", UNSET)

        vitamin_b12_mcg = d.pop("vitamin_b12_mcg", UNSET)

        vitamin_c_mg = d.pop("vitamin_c_mg", UNSET)

        vitamin_d_mcg = d.pop("vitamin_d_mcg", UNSET)

        vitamin_e_mg = d.pop("vitamin_e_mg", UNSET)

        vitamin_k_mcg = d.pop("vitamin_k_mcg", UNSET)

        folate_mcg = d.pop("folate_mcg", UNSET)

        biotin_mcg = d.pop("biotin_mcg", UNSET)

        niacin_mg = d.pop("niacin_mg", UNSET)

        pantothenic_acid_mg = d.pop("pantothenic_acid_mg", UNSET)

        riboflavin_mg = d.pop("riboflavin_mg", UNSET)

        thiamin_mg = d.pop("thiamin_mg", UNSET)

        calcium_mg = d.pop("calcium_mg", UNSET)

        chloride_mg = d.pop("chloride_mg", UNSET)

        chromium_mcg = d.pop("chromium_mcg", UNSET)

        copper_mg = d.pop("copper_mg", UNSET)

        iodine_mcg = d.pop("iodine_mcg", UNSET)

        iron_mg = d.pop("iron_mg", UNSET)

        magnesium_mg = d.pop("magnesium_mg", UNSET)

        manganese_mg = d.pop("manganese_mg", UNSET)

        molybdenum_mcg = d.pop("molybdenum_mcg", UNSET)

        phosphorus_mg = d.pop("phosphorus_mg", UNSET)

        potassium_mg = d.pop("potassium_mg", UNSET)

        selenium_mcg = d.pop("selenium_mcg", UNSET)

        zinc_mg = d.pop("zinc_mg", UNSET)

        def _parse_brand(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        brand = _parse_brand(d.pop("brand", UNSET))

        serving_size = d.pop("serving_size", UNSET)

        serving_unit = d.pop("serving_unit", UNSET)

        source = d.pop("source", UNSET)

        item = cls(
            item_uuid=item_uuid,
            name=name,
            created_at=created_at,
            calories=calories,
            protein_g=protein_g,
            carbs_g=carbs_g,
            fat_g=fat_g,
            fiber_g=fiber_g,
            sugar_g=sugar_g,
            saturated_fat_g=saturated_fat_g,
            monounsaturated_fat_g=monounsaturated_fat_g,
            polyunsaturated_fat_g=polyunsaturated_fat_g,
            cholesterol_mg=cholesterol_mg,
            sodium_mg=sodium_mg,
            caffeine_mg=caffeine_mg,
            water_ml=water_ml,
            vitamin_a_mcg=vitamin_a_mcg,
            vitamin_b6_mg=vitamin_b6_mg,
            vitamin_b12_mcg=vitamin_b12_mcg,
            vitamin_c_mg=vitamin_c_mg,
            vitamin_d_mcg=vitamin_d_mcg,
            vitamin_e_mg=vitamin_e_mg,
            vitamin_k_mcg=vitamin_k_mcg,
            folate_mcg=folate_mcg,
            biotin_mcg=biotin_mcg,
            niacin_mg=niacin_mg,
            pantothenic_acid_mg=pantothenic_acid_mg,
            riboflavin_mg=riboflavin_mg,
            thiamin_mg=thiamin_mg,
            calcium_mg=calcium_mg,
            chloride_mg=chloride_mg,
            chromium_mcg=chromium_mcg,
            copper_mg=copper_mg,
            iodine_mcg=iodine_mcg,
            iron_mg=iron_mg,
            magnesium_mg=magnesium_mg,
            manganese_mg=manganese_mg,
            molybdenum_mcg=molybdenum_mcg,
            phosphorus_mg=phosphorus_mg,
            potassium_mg=potassium_mg,
            selenium_mcg=selenium_mcg,
            zinc_mg=zinc_mg,
            brand=brand,
            serving_size=serving_size,
            serving_unit=serving_unit,
            source=source,
        )

        item.additional_properties = d
        return item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
