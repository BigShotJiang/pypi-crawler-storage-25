from enum import Enum


class ItemCreateRequestSource(str, Enum):
    AI_ESTIMATE = "ai_estimate"
    BARCODE = "barcode"
    MANUAL = "manual"

    def __str__(self) -> str:
        return str(self.value)
