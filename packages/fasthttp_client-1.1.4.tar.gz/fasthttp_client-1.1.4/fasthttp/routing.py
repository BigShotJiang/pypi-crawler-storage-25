from collections.abc import Callable
from typing import Annotated, Literal

from annotated_doc import Doc
from pydantic import BaseModel


class Route:
    """
    Definition of an HTTP request route.

    A Route binds together an HTTP method, a target URL,
    optional request data, and a response handler function.

    It is used by FastHTTP to send requests and process
    responses in a structured and predictable way.
    """

    def __init__(
        self,
        *,
        method: Annotated[
            Literal["GET", "POST", "PUT", "PATCH", "DELETE"],
            Doc(
                """
                HTTP method for the request.

                Determines how the request will be sent to the server.

                Suppoeted methods are:
                GET, POST, PUT, PATCH, DELETE.
                """
            ),
        ],
        url: Annotated[
            str,
            Doc(
                """
                Target URL for the HTTP request.

                Must be a full URL including scheme, host and path
                Example:
                https://api.google.com/
                """
            ),
        ],
        handler: Annotated[
            Callable,
            Doc(
                """
                Response handler function.

                This asyncfunction will be called with a Response object
                and can return:
                - str
                - Response
                - None
                """
            ),
        ],
        params: Annotated[
            dict | None,
            Doc(
                """
                Query parameters to be sent with the request.

                The dictionary will be encoded into the URL query string
                and appended to the request URL.
                """
            ),
        ] = None,
        json: Annotated[
            dict | None,
            Doc(
                """
                JSON body to be sent with the request.

                The data will be serialized to JSON and sent with the

                application/json Content-Type header.
                """
            ),
        ] = None,
        data: Annotated[
            object | None,
            Doc(
                """

                Raw request body or form data.

                Can be used to send form-encoded data, plain text,

                binary payloads or any custom request body.
                """
            ),
        ] = None,
        response_model: Annotated[
            type[BaseModel] | None,
            Doc(
                """
                Optional Pydantic model for validating handler results.

                If provided, the handler return value will be
                validated before returning.

                If None, the result is returned unchanged.
                """
            ),
        ] = None,
        request_model: Annotated[
            type[BaseModel] | None,
            Doc(
                """
                Optional Pydantic model for validating request data.

                If provided, the request json/data will be validated
                before sending the request.

                If None, the request data is sent without validation.
                """
            ),
        ] = None,
        tags: Annotated[
            list[str] | None,
            Doc(
                """
                Tags for grouping and filtering requests.

                Tags allow you to organize routes and run only
                specific groups of requests. Useful for running
                subsets of requests in large applications.

                Example:
                    tags=["users"] - route belongs to "users" group
                """
            ),
        ] = None,
        dependencies: Annotated[
            list | None,
            Doc(
                """
                List of dependencies to execute before the request.

                Dependencies are functions that modify the request
                config (headers, params, etc.) before the request
                is sent. Useful for adding auth tokens, logging,
                or other request modifications.

                Example:
                    dependencies=[Depends(add_auth), Depends(add_trace_id)]
                """
            ),
        ] = None,
        skip_request: Annotated[
            bool,
            Doc(
                """
                Skip HTTP request execution.

                When True, the HTTP client will not send a real request.
                The handler is responsible for executing the request
                and returning the result. Used for GraphQL and custom
                protocols.
                """
            ),
        ] = False,
        responses: Annotated[
            dict[int, dict[Literal["model"], type[BaseModel]]] | None,
            Doc(
                """
                Response models for different status codes.

                A dictionary mapping HTTP status codes to Pydantic models
                that will be used to validate error responses.

                Example:
                    responses={
                        404: {"model": Error404},
                        500: {"model": Error500}
                    }

                When the server returns an error status code (4xx, 5xx),
                the response body will be validated against the
                corresponding model.
                """
            ),
        ] = None,
    ) -> None:
        self.method = method
        self.url = url
        self.handler = handler
        self.params = params
        self.json = json
        self.data = data
        self.response_model = response_model
        self.request_model = request_model
        self.tags = tags or []
        self.dependencies = dependencies or []
        self.skip_request = skip_request
        self.responses = responses or {}
