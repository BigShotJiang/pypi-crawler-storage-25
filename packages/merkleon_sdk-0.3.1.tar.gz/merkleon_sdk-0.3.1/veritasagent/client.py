"""
Core VeritasAgent SDK client.
Sends audit events to the VeritasAgent platform.

Features:
- Automatic PII scrubbing (emails, SSNs, credit cards, API keys, phone numbers)
- Retry with exponential backoff on transient failures
- Backpressure (bounded queue, no silent drops)
- Client-side SHA-256 hashing for prompts/responses (never sends raw content)
"""
import hashlib
import json
import logging
import os
import re
import threading
import time
from collections import deque
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Optional, Any
from uuid import uuid4

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False

logger = logging.getLogger("veritasagent")


# ─────────────────────────────────────────────────────────────
# PII Scrubber — redact common PII patterns before sending
# ─────────────────────────────────────────────────────────────
_PII_PATTERNS = [
    # Email addresses
    (re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"), "[EMAIL_REDACTED]"),
    # US SSN (xxx-xx-xxxx)
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "[SSN_REDACTED]"),
    # Credit card (13-19 digits, with optional spaces/dashes)
    (re.compile(r"\b(?:\d[ -]*?){13,19}\b"), "[CC_REDACTED]"),
    # API keys (generic: 20+ alphanumeric with underscores/hyphens preceded by key/token/secret)
    (re.compile(r"\b(?:sk|pk|api[_-]?key|token|secret|bearer)[_\-=: ]+[\w\-]{20,}\b", re.IGNORECASE), "[KEY_REDACTED]"),
    # AWS access keys
    (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "[AWS_KEY_REDACTED]"),
    # OpenAI API keys
    (re.compile(r"\bsk-[A-Za-z0-9]{20,}\b"), "[OPENAI_KEY_REDACTED]"),
    # Phone numbers (US format: +1-xxx-xxx-xxxx or 10 digits)
    (re.compile(r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"), "[PHONE_REDACTED]"),
    # IPv4 addresses (keep first octet for diagnostics)
    (re.compile(r"\b(\d{1,3})\.\d{1,3}\.\d{1,3}\.\d{1,3}\b"), r"\1.x.x.x"),
    # JWT tokens
    (re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"), "[JWT_REDACTED]"),
]


def scrub_pii(text: str) -> str:
    """Redact common PII patterns from text before sending to the server."""
    if not text:
        return text
    result = text
    for pattern, replacement in _PII_PATTERNS:
        result = pattern.sub(replacement, result)
    return result


# ─────────────────────────────────────────────────────────────
# VeritasClient
# ─────────────────────────────────────────────────────────────

MAX_QUEUE_SIZE = 10000          # Max events buffered before we drop
MAX_RETRIES = 3                  # Retry attempts on transient failures
RETRY_BACKOFF_BASE = 0.5         # Initial backoff (seconds)


class VeritasClient:
    """
    Client for sending audit telemetry to VeritasAgent.

    Usage:
        client = VeritasClient(
            endpoint="http://localhost:8000",
            agent_id="my-research-bot",
            api_key="va_abc123",
            scrub_pii=True,    # default True
        )

        client.track_llm(model="gpt-4o", prompt="What is X?", token_count=100)
    """

    def __init__(
        self,
        endpoint: str = None,
        agent_id: str = None,
        api_key: str = None,
        session_id: str = None,
        parent_agent_id: str = None,
        container_image_hash: str = None,
        async_mode: bool = False,
        batch_size: int = 10,
        flush_interval: float = 5.0,
        scrub_pii: bool = True,
        max_retries: int = MAX_RETRIES,
    ):
        self.endpoint = (endpoint or os.environ.get("VERITAS_ENDPOINT", "http://localhost:8000")).rstrip("/")
        self.agent_id = agent_id or os.environ.get("VERITAS_AGENT_ID", f"agent-{uuid4().hex[:8]}")
        self.api_key = api_key or os.environ.get("VERITAS_API_KEY", "")
        self.session_id = session_id or uuid4().hex[:16]
        self.parent_agent_id = parent_agent_id or os.environ.get("VERITAS_PARENT_AGENT_ID")
        self.container_image_hash = container_image_hash or os.environ.get("VERITAS_IMAGE_HASH")
        self.async_mode = async_mode
        self._batch: deque = deque(maxlen=MAX_QUEUE_SIZE)
        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._last_flush = time.time()
        self._invocation_depth = 0
        self.scrub_pii = scrub_pii
        self.max_retries = max_retries
        self._queue_lock = threading.Lock()
        self._dropped_events = 0  # track drops for visibility

        if not HAS_HTTPX:
            logger.warning("httpx not installed. Install with: pip install httpx")

    @property
    def _headers(self) -> dict:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def emit_event(
        self,
        event_type: str,
        destination_host: str = None,
        destination_port: int = 0,
        destination_service: str = None,
        file_path: str = None,
        process_name: str = None,
        process_cmdline: str = None,
        model_name: str = "",
        token_count: int = 0,
        prompt_hash: str = None,
        response_hash: str = None,
        details: dict = None,
        cost_usd: float = 0.0,
    ) -> Optional[dict]:
        """Emit a single audit event to VeritasAgent."""
        # Scrub PII from process cmdline and file paths (common leak points)
        if self.scrub_pii:
            process_cmdline = scrub_pii(process_cmdline) if process_cmdline else process_cmdline
            # Scrub string values in details dict
            if details:
                details = {k: (scrub_pii(v) if isinstance(v, str) else v) for k, v in details.items()}

        event = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "rule": f"SDK:{event_type}",
            "output": f"Agent {self.agent_id} performed {event_type}",
            "priority": "NOTICE",
            "source": "veritasagent-sdk",
            "fields": {
                "agent_id": self.agent_id,
                "session_id": self.session_id,
                "proc_name": process_name or "python",
                "proc_cmdline": process_cmdline or "",
                "fd_name": "",
                "fd_dip": destination_host or "",
                "fd_dport": str(destination_port),
                "fd_dhost": destination_host or "",
                "fd_service": destination_service or "",
                "file_path": file_path or "",
                "model_name": model_name,
                "token_count": str(token_count),
                "cost_usd": str(cost_usd),
                "prompt_hash": prompt_hash or "",
                "response_hash": response_hash or "",
                "parent_agent_id": self.parent_agent_id or "",
                "session_graph_id": self.session_id,
                "invocation_depth": str(self._invocation_depth),
                "container_image_hash": self.container_image_hash or "",
                **(details or {}),
            },
        }

        if self.async_mode:
            with self._queue_lock:
                if len(self._batch) >= MAX_QUEUE_SIZE:
                    self._dropped_events += 1
                    logger.warning(
                        f"VeritasAgent queue full (max {MAX_QUEUE_SIZE}), dropping oldest event. "
                        f"Total dropped: {self._dropped_events}"
                    )
                self._batch.append(event)
                should_flush = (
                    len(self._batch) >= self._batch_size
                    or (time.time() - self._last_flush) > self._flush_interval
                )
            if should_flush:
                return self.flush()
            return None
        else:
            return self._send_event_with_retry(event)

    def _send_event_with_retry(self, event: dict) -> Optional[dict]:
        """Send single event with exponential backoff on transient failures."""
        if not HAS_HTTPX:
            logger.error("httpx required. pip install httpx")
            return None

        for attempt in range(self.max_retries + 1):
            try:
                with httpx.Client(timeout=10.0) as client:
                    resp = client.post(
                        f"{self.endpoint}/api/v1/events/ingest",
                        headers=self._headers,
                        json=event,
                    )
                    if resp.status_code == 200:
                        return resp.json()
                    if resp.status_code in (400, 401, 403, 422):
                        # Permanent failure — don't retry
                        logger.warning(f"VeritasAgent ingest rejected ({resp.status_code}): {resp.text[:200]}")
                        return None
                    # 5xx, 429 — retry
                    logger.warning(f"VeritasAgent transient error {resp.status_code} (attempt {attempt + 1}/{self.max_retries + 1})")
            except (httpx.ConnectError, httpx.TimeoutException, httpx.ReadError) as e:
                logger.warning(f"VeritasAgent connection error: {e} (attempt {attempt + 1}/{self.max_retries + 1})")
            except Exception as e:
                logger.error(f"VeritasAgent send error: {e}")
                return None

            if attempt < self.max_retries:
                time.sleep(RETRY_BACKOFF_BASE * (2 ** attempt))

        logger.error(f"VeritasAgent: failed to send event after {self.max_retries + 1} attempts")
        return None

    def flush(self) -> Optional[dict]:
        """Flush batched events with retry."""
        with self._queue_lock:
            if not self._batch:
                return None
            batch_to_send = list(self._batch)
            self._batch.clear()
            self._last_flush = time.time()

        if not HAS_HTTPX:
            return None

        for attempt in range(self.max_retries + 1):
            try:
                with httpx.Client(timeout=30.0) as client:
                    resp = client.post(
                        f"{self.endpoint}/api/v1/events/ingest/bulk",
                        headers=self._headers,
                        json={"events": batch_to_send},
                    )
                    if resp.status_code == 200:
                        return resp.json()
                    if resp.status_code in (400, 401, 403, 422):
                        logger.warning(f"VeritasAgent bulk ingest rejected: {resp.status_code}")
                        return None
            except Exception as e:
                logger.warning(f"VeritasAgent flush error: {e} (attempt {attempt + 1})")

            if attempt < self.max_retries:
                time.sleep(RETRY_BACKOFF_BASE * (2 ** attempt))

        # Requeue events that failed to send (up to MAX_QUEUE_SIZE)
        with self._queue_lock:
            for event in batch_to_send:
                if len(self._batch) >= MAX_QUEUE_SIZE:
                    self._dropped_events += 1
                    break
                self._batch.append(event)
        logger.error(f"VeritasAgent: bulk flush failed, {len(batch_to_send)} events requeued (or dropped)")
        return None

    @contextmanager
    def track(self, event_type: str, **kwargs):
        """Context manager for tracking an operation with duration."""
        start = time.time()
        self._invocation_depth += 1
        try:
            yield
        finally:
            duration_ms = (time.time() - start) * 1000
            self._invocation_depth -= 1
            kwargs.setdefault("details", {})
            kwargs["details"]["duration_ms"] = round(duration_ms, 2)
            self.emit_event(event_type=event_type, **kwargs)

    def track_llm(
        self,
        model: str,
        prompt: str = None,
        response: str = None,
        token_count: int = 0,
        cost_usd: float = 0.0,
        provider: str = None,
    ) -> Optional[dict]:
        """Track an LLM inference call. Prompts/responses are hashed client-side."""
        prompt_hash = self.hash_content(prompt) if prompt else None
        response_hash = self.hash_content(response) if response else None

        provider_hosts = {
            "openai": "api.openai.com",
            "anthropic": "api.anthropic.com",
            "google": "generativelanguage.googleapis.com",
            "cohere": "api.cohere.ai",
            "mistral": "api.mistral.ai",
        }
        host = provider_hosts.get((provider or "").lower(), provider or "api.openai.com")

        return self.emit_event(
            event_type="LLM_INFERENCE_CALL",
            destination_host=host,
            destination_port=443,
            destination_service=f"{provider or 'LLM'} API",
            model_name=model,
            token_count=token_count,
            cost_usd=cost_usd,
            prompt_hash=prompt_hash,
            response_hash=response_hash,
        )

    def track_tool(
        self,
        tool_name: str,
        tool_input: dict = None,
        result: Any = None,
        host: str = None,
    ) -> Optional[dict]:
        """Track a tool invocation. Input/result are hashed client-side."""
        return self.emit_event(
            event_type="TOOL_INVOCATION",
            destination_host=host or "localhost",
            destination_service=tool_name,
            details={
                "tool_name": tool_name,
                "input_hash": self.hash_content(json.dumps(tool_input)) if tool_input else "",
                "result_hash": self.hash_content(str(result)) if result else "",
            },
        )

    def track_mcp(
        self,
        server_name: str,
        tool_name: str,
        arguments: dict = None,
    ) -> Optional[dict]:
        """Track an MCP (Model Context Protocol) tool call."""
        return self.emit_event(
            event_type="MCP_TOOL_CALL",
            destination_service=f"MCP:{server_name}",
            destination_host="localhost",
            details={
                "mcp_server": server_name,
                "mcp_tool": tool_name,
                "args_hash": self.hash_content(json.dumps(arguments)) if arguments else "",
            },
        )

    def prove(
        self,
        action: str,
        *,
        agent: str | None = None,
        model: str | None = None,
        tokens: int = 0,
        metadata: dict | None = None,
    ) -> dict:
        """One-liner proof of any AI agent action.

        Usage:
            m = Merkleon(api_key="mk_...")
            m.prove("gpt-4o called: summarize Q4 report", agent="research-bot")
        """
        if agent:
            self.agent_id = agent

        fields = {"action": action}
        if model:
            fields["model_name"] = model
        if tokens:
            fields["token_count"] = tokens
        if metadata:
            fields.update(metadata)

        return self.emit_event(
            event_type="ai.action",
            process_name=model or "ai-agent",
            process_cmdline=action[:200],
            details=fields,
            cost_usd=0.0,
            token_count=tokens,
            model_name=model or "",
        )

    def child_client(self, child_agent_id: str) -> "VeritasClient":
        """Create a child client for multi-agent tracing."""
        return VeritasClient(
            endpoint=self.endpoint,
            agent_id=child_agent_id,
            api_key=self.api_key,
            session_id=self.session_id,
            parent_agent_id=self.agent_id,
            container_image_hash=self.container_image_hash,
            scrub_pii=self.scrub_pii,
            max_retries=self.max_retries,
        )

    @staticmethod
    def hash_content(content: str) -> str:
        """SHA-256 hash of content. Used for prompt/response privacy."""
        if not content:
            return ""
        return hashlib.sha256(content.encode()).hexdigest()

    def stats(self) -> dict:
        """Return SDK runtime stats."""
        with self._queue_lock:
            queue_size = len(self._batch)
        return {
            "queue_size": queue_size,
            "queue_max": MAX_QUEUE_SIZE,
            "dropped_events": self._dropped_events,
            "agent_id": self.agent_id,
        }

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.flush()

    def __repr__(self):
        return f"VeritasClient(endpoint={self.endpoint!r}, agent_id={self.agent_id!r})"
