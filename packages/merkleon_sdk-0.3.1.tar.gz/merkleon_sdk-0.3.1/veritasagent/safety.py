"""SafetyClient — active interception SDK for Python agents.

Usage:

    from veritasagent.safety import SafetyClient, ActionKind

    safety = SafetyClient(endpoint="http://localhost:8000",
                         agent_id="my-agent",
                         api_key="...")

    # Guard a shell command
    with safety.guard_shell("rm -rf build/", cwd=".") as decision:
        if decision.allowed:
            subprocess.run(["rm", "-rf", "build/"], check=True)
        # Snapshot (if any) is stored — undo via safety.undo(decision.snapshot_id)

    # Guard a SQL statement
    with safety.guard_sql("DELETE FROM users WHERE inactive=true",
                         db_url="postgresql://...") as decision:
        if decision.allowed:
            engine.execute(text(decision.action.sql))

    # Approve from another process / human:
    safety.approve(decision.approval_token)

The context manager is the primary API — it calls /safety/check, optionally
blocks on /safety/wait/{token} for a human approval, raises SafetyDenied on
deny, and posts /safety/commit on successful exit.
"""
from __future__ import annotations

import os
import time
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Iterator, Optional

import requests


class SafetyDenied(Exception):
    """Raised inside `guard_*` when the verdict is deny."""
    def __init__(self, decision: "SafetyDecision"):
        super().__init__(f"action denied: {', '.join(decision.reasons)}")
        self.decision = decision


@dataclass
class SafetyDecision:
    action_id: str
    verdict: str  # allow / deny / require_approval
    blast_radius: str  # none / low / medium / high / catastrophic
    score: int
    reasons: list[str]
    matched_rules: list[str]
    snapshot_id: Optional[str]
    snapshot_kind: str
    requires_approval: bool
    approval_token: Optional[str]
    raw: dict[str, Any]
    action: dict[str, Any]

    @property
    def allowed(self) -> bool:
        return self.verdict == "allow"


class SafetyClient:
    def __init__(self,
                 endpoint: Optional[str] = None,
                 agent_id: Optional[str] = None,
                 api_key: Optional[str] = None,
                 tenant_id: str = "default",
                 approval_timeout: float = 300.0,
                 session_id: Optional[str] = None,
                 request_timeout: float = 30.0):
        self.endpoint = (endpoint or os.environ.get("VERITAS_ENDPOINT") or
                         "http://localhost:8000").rstrip("/")
        self.agent_id = agent_id or os.environ.get("VERITAS_AGENT_ID") or "unnamed-agent"
        self.api_key = api_key or os.environ.get("VERITAS_API_KEY") or ""
        self.tenant_id = tenant_id
        self.approval_timeout = approval_timeout
        self.session_id = session_id or f"session-{int(time.time())}"
        self.request_timeout = request_timeout

    # ---- HTTP helpers ----

    def _headers(self) -> dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    def _post(self, path: str, body: dict | None = None, params: dict | None = None) -> dict:
        r = requests.post(self.endpoint + path, json=body, params=params,
                          headers=self._headers(), timeout=self.request_timeout)
        r.raise_for_status()
        return r.json()

    def _get(self, path: str, params: dict | None = None) -> dict:
        r = requests.get(self.endpoint + path, params=params, headers=self._headers(),
                         timeout=self.request_timeout)
        r.raise_for_status()
        return r.json()

    # ---- Core check / commit / undo ----

    def check(self, action: dict[str, Any]) -> SafetyDecision:
        action.setdefault("agent_id", self.agent_id)
        action.setdefault("session_id", self.session_id)
        raw = self._post("/api/v1/safety/check", body=action,
                         params={"tenant_id": self.tenant_id})
        return SafetyDecision(
            action_id=raw["action_id"],
            verdict=raw["verdict"],
            blast_radius=raw["blast_radius"],
            score=raw["score"],
            reasons=raw.get("reasons", []),
            matched_rules=raw.get("matched_rules", []),
            snapshot_id=raw.get("snapshot_id"),
            snapshot_kind=raw.get("snapshot_kind", "none"),
            requires_approval=raw.get("requires_approval", False),
            approval_token=raw.get("approval_token"),
            raw=raw,
            action=action,
        )

    def wait_for_approval(self, token: str, timeout: Optional[float] = None) -> str:
        timeout = timeout if timeout is not None else self.approval_timeout
        # Server long-polls up to its own timeout; loop in case of network blips.
        deadline = time.time() + timeout
        while True:
            remaining = max(1.0, min(60.0, deadline - time.time()))
            if remaining <= 0:
                return "deny"
            r = self._get(f"/api/v1/safety/wait/{token}", params={"timeout": remaining})
            if r.get("resolved"):
                return r["verdict"]
            if time.time() >= deadline:
                return "deny"

    def approve(self, approval_token: str, approve: bool = True,
                approver: str = "", reason: str = "") -> dict:
        return self._post("/api/v1/safety/approve", body={
            "approval_token": approval_token,
            "approve": approve,
            "approver": approver,
            "reason": reason,
        })

    def commit(self, action_id: str) -> dict:
        return self._post(f"/api/v1/safety/commit/{action_id}")

    def undo(self, snapshot_id: str, restore_db_url: Optional[str] = None) -> dict:
        body = {"restore_db_url": restore_db_url} if restore_db_url else None
        return self._post(f"/api/v1/safety/undo/{snapshot_id}", body=body)

    # ---- Context-manager guards ----

    @contextmanager
    def _guard(self, action: dict[str, Any]) -> Iterator[SafetyDecision]:
        decision = self.check(action)

        if decision.requires_approval and decision.approval_token:
            verdict = self.wait_for_approval(decision.approval_token)
            decision.verdict = verdict
            decision.requires_approval = False

        if decision.verdict == "deny":
            raise SafetyDenied(decision)

        executed = False
        try:
            yield decision
            executed = True
        finally:
            if executed and decision.allowed:
                try:
                    self.commit(decision.action_id)
                except Exception:
                    pass  # commit is bookkeeping, not safety-critical

    def guard_shell(self, command: str, cwd: Optional[str] = None,
                    intent: str = "") -> "_GuardCM":
        return _GuardCM(self, {
            "kind": "shell", "command": command, "cwd": cwd, "intent": intent,
        })

    def guard_git(self, command: str, cwd: Optional[str] = None,
                  intent: str = "") -> "_GuardCM":
        return _GuardCM(self, {
            "kind": "git", "command": command, "cwd": cwd, "intent": intent,
        })

    def guard_fs_write(self, path: str | None = None, paths: list[str] | None = None,
                       intent: str = "") -> "_GuardCM":
        return _GuardCM(self, {
            "kind": "fs_write", "path": path, "paths": paths or [], "intent": intent,
        })

    def guard_fs_delete(self, path: str | None = None, paths: list[str] | None = None,
                        intent: str = "") -> "_GuardCM":
        return _GuardCM(self, {
            "kind": "fs_delete", "path": path, "paths": paths or [], "intent": intent,
        })

    def guard_sql(self, sql: str, db_url: str, db_kind: Optional[str] = None,
                  intent: str = "") -> "_GuardCM":
        return _GuardCM(self, {
            "kind": "sql", "sql": sql, "db_url": db_url, "db_kind": db_kind, "intent": intent,
        })

    def guard_http(self, method: str, url: str, intent: str = "") -> "_GuardCM":
        return _GuardCM(self, {
            "kind": "http", "method": method.upper(), "url": url, "intent": intent,
        })


class _GuardCM:
    """Returned by guard_*; supports `with` semantics."""
    def __init__(self, client: SafetyClient, action: dict[str, Any]):
        self._client = client
        self._action = action
        self._cm = None
        self.decision: Optional[SafetyDecision] = None

    def __enter__(self) -> SafetyDecision:
        self._cm = self._client._guard(self._action)
        self.decision = self._cm.__enter__()
        return self.decision

    def __exit__(self, exc_type, exc, tb):
        return self._cm.__exit__(exc_type, exc, tb)
