"""Replay capture SDK — wraps a model call to record its full execution context.

Two integration patterns:

1. Decorator (cleanest when wrapping an existing chat function):

    from veritasagent.replay import ReplayRecorder

    rec = ReplayRecorder(endpoint="...", agent_id="my-agent")

    @rec.record(model="gpt-4o", provider="openai")
    def chat(messages, tools=None, **kw):
        return openai.chat.completions.create(messages=messages, tools=tools, **kw)

2. Manual:

    cap = rec.start(model="gpt-4o", messages=[...], tool_schemas=[...])
    response = openai.chat.completions.create(...)
    cap.finish_from_openai(response)        # or .finish(text=..., tool_calls=[...])
    rec.flush(cap)

Captures are content-addressed: writing the same canonical input+output twice
is a no-op on the server.
"""
from __future__ import annotations

import functools
import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional
from uuid import uuid4

import requests


def _canonical_sha256(obj: Any) -> str:
    return hashlib.sha256(
        json.dumps(obj, sort_keys=True, separators=(",", ":"),
                   ensure_ascii=False, default=str).encode("utf-8")
    ).hexdigest()


@dataclass
class _PendingCapture:
    capture_id: str
    agent_id: str
    session_id: str
    intent: str
    parent_event_id: Optional[str]
    input: dict
    output: dict = field(default_factory=lambda: {"text": "", "tool_calls": [],
                                                  "finish_reason": None, "usage": {}})

    def finish(self, text: str = "",
               tool_calls: Optional[list[dict]] = None,
               finish_reason: Optional[str] = None,
               usage: Optional[dict] = None) -> None:
        self.output = {
            "text": text or "",
            "tool_calls": tool_calls or [],
            "finish_reason": finish_reason,
            "usage": usage or {},
        }

    def finish_from_openai(self, response: Any) -> None:
        """Convenience: extract text + tool calls from an OpenAI ChatCompletion."""
        choice = response.choices[0]
        msg = choice.message
        tool_calls: list[dict] = []
        for tc in (getattr(msg, "tool_calls", None) or []):
            try:
                args = json.loads(tc.function.arguments)
            except Exception:
                args = {"_raw": tc.function.arguments}
            tool_calls.append({"name": tc.function.name, "arguments": args})
        usage = {}
        u = getattr(response, "usage", None)
        if u is not None:
            usage = {
                "prompt_tokens": getattr(u, "prompt_tokens", 0),
                "completion_tokens": getattr(u, "completion_tokens", 0),
                "total_tokens": getattr(u, "total_tokens", 0),
            }
        self.finish(text=getattr(msg, "content", "") or "",
                    tool_calls=tool_calls,
                    finish_reason=getattr(choice, "finish_reason", None),
                    usage=usage)

    def finish_from_anthropic(self, response: Any) -> None:
        text_parts: list[str] = []
        tool_calls: list[dict] = []
        for block in getattr(response, "content", []) or []:
            t = getattr(block, "type", None)
            if t == "text":
                text_parts.append(getattr(block, "text", ""))
            elif t == "tool_use":
                tool_calls.append({
                    "name": getattr(block, "name", ""),
                    "arguments": getattr(block, "input", {}) or {},
                })
        usage = getattr(response, "usage", None)
        usage_dict: dict[str, int] = {}
        if usage is not None:
            usage_dict = {
                "prompt_tokens": getattr(usage, "input_tokens", 0),
                "completion_tokens": getattr(usage, "output_tokens", 0),
                "total_tokens": (getattr(usage, "input_tokens", 0)
                                 + getattr(usage, "output_tokens", 0)),
            }
        self.finish(text="".join(text_parts),
                    tool_calls=tool_calls,
                    finish_reason=getattr(response, "stop_reason", None),
                    usage=usage_dict)


class ReplayRecorder:
    def __init__(self,
                 endpoint: Optional[str] = None,
                 agent_id: Optional[str] = None,
                 api_key: Optional[str] = None,
                 tenant_id: str = "default",
                 session_id: Optional[str] = None,
                 request_timeout: float = 30.0):
        self.endpoint = (endpoint or os.environ.get("VERITAS_ENDPOINT")
                         or "http://localhost:8000").rstrip("/")
        self.agent_id = agent_id or os.environ.get("VERITAS_AGENT_ID") or "unnamed-agent"
        self.api_key = api_key or os.environ.get("VERITAS_API_KEY") or ""
        self.tenant_id = tenant_id
        self.session_id = session_id or f"session-{int(time.time())}"
        self.request_timeout = request_timeout

    def _headers(self) -> dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    # ---- Manual API ----

    def start(self, *,
              model: str,
              messages: list[dict[str, Any]],
              provider: str = "openai",
              system_prompt: str = "",
              temperature: float = 0.0,
              top_p: float = 1.0,
              seed: Optional[int] = None,
              max_tokens: int = 1024,
              stop: Optional[list[str]] = None,
              tool_schemas: Optional[list[dict]] = None,
              tool_choice: Any = None,
              model_version: Optional[str] = None,
              intent: str = "",
              parent_event_id: Optional[str] = None,
              extra: Optional[dict] = None) -> _PendingCapture:
        return _PendingCapture(
            capture_id=f"cap_{uuid4().hex[:16]}",
            agent_id=self.agent_id,
            session_id=self.session_id,
            intent=intent,
            parent_event_id=parent_event_id,
            input={
                "model": model,
                "model_version": model_version,
                "provider": provider,
                "temperature": temperature,
                "top_p": top_p,
                "seed": seed,
                "max_tokens": max_tokens,
                "stop": stop or [],
                "system_prompt": system_prompt,
                "messages": messages,
                "tool_schemas": tool_schemas or [],
                "tool_choice": tool_choice,
                "extra": extra or {},
            },
        )

    def flush(self, capture: _PendingCapture) -> dict:
        body = {
            "capture_id": capture.capture_id,
            "agent_id": capture.agent_id,
            "session_id": capture.session_id,
            "parent_event_id": capture.parent_event_id,
            "intent": capture.intent,
            "input": capture.input,
            "output": capture.output,
        }
        r = requests.post(
            self.endpoint + "/api/v1/replay/capture",
            json=body, params={"tenant_id": self.tenant_id},
            headers=self._headers(), timeout=self.request_timeout,
        )
        r.raise_for_status()
        return r.json()

    # ---- Decorator ----

    def record(self, *, model: str, provider: str = "openai",
               extract: str = "openai") -> Callable:
        """Decorate a chat function. The wrapped fn must accept `messages=` and
        return either an OpenAI/Anthropic response object, or a dict with keys
        `text`, `tool_calls`, `finish_reason`, `usage`.

        `extract` selects the response parser: "openai" | "anthropic" | "dict".
        """
        def decorator(fn: Callable) -> Callable:
            @functools.wraps(fn)
            def wrapped(*args, **kwargs):
                messages = kwargs.get("messages") or (args[0] if args else [])
                tool_schemas = kwargs.get("tools") or []
                cap = self.start(
                    model=kwargs.get("model", model),
                    provider=provider,
                    messages=messages,
                    tool_schemas=tool_schemas,
                    temperature=kwargs.get("temperature", 0.0),
                    top_p=kwargs.get("top_p", 1.0),
                    seed=kwargs.get("seed"),
                    max_tokens=kwargs.get("max_tokens", 1024),
                    system_prompt=kwargs.get("system", ""),
                )
                resp = fn(*args, **kwargs)
                if extract == "openai":
                    cap.finish_from_openai(resp)
                elif extract == "anthropic":
                    cap.finish_from_anthropic(resp)
                elif extract == "dict" and isinstance(resp, dict):
                    cap.finish(**{k: resp[k] for k in
                                   ("text", "tool_calls", "finish_reason", "usage")
                                   if k in resp})
                self.flush(cap)
                return resp
            return wrapped
        return decorator

    # ---- Replay ----

    def replay(self, capture_id: str,
               override_provider: Optional[str] = None,
               override_model: Optional[str] = None) -> dict:
        body = {"override_provider": override_provider,
                "override_model": override_model}
        r = requests.post(
            self.endpoint + f"/api/v1/replay/run/{capture_id}",
            json=body, params={"tenant_id": self.tenant_id},
            headers=self._headers(), timeout=self.request_timeout,
        )
        r.raise_for_status()
        return r.json()

    def list_captures(self, agent_id: Optional[str] = None,
                      session_id: Optional[str] = None, limit: int = 100) -> list[dict]:
        params: dict = {"tenant_id": self.tenant_id, "limit": limit}
        if agent_id:
            params["agent_id"] = agent_id
        if session_id:
            params["session_id"] = session_id
        r = requests.get(self.endpoint + "/api/v1/replay/captures",
                         params=params, headers=self._headers(),
                         timeout=self.request_timeout)
        r.raise_for_status()
        return r.json()
