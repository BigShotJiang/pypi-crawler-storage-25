"""
VeritasAgent SDK — Tamper-proof audit telemetry for AI agents.

Usage:
    from veritasagent import VeritasClient, track_llm_call, track_tool_use

    client = VeritasClient(endpoint="http://localhost:8000", agent_id="my-agent")

    # Decorator-based tracking
    @track_llm_call(client)
    def call_openai(prompt):
        return openai.chat(prompt)

    # Context manager tracking
    with client.track("tool_invocation", tool="web_search"):
        results = search(query)

    # Manual tracking
    client.emit_event(event_type="FILE_WRITE", file_path="/tmp/output.json")
"""

from veritasagent.client import VeritasClient
from veritasagent.decorators import track_llm_call, track_tool_use, track_file_access
from veritasagent.middleware import VeritasLangChainCallback, VeritasOpenAIWrapper
from veritasagent.safety import SafetyClient, SafetyDecision, SafetyDenied

# Alias for the clean API
Merkleon = VeritasClient

__version__ = "0.3.1"
__all__ = [
    "VeritasClient",
    "Merkleon",
    "track_llm_call",
    "track_tool_use",
    "track_file_access",
    "VeritasLangChainCallback",
    "VeritasOpenAIWrapper",
    "SafetyClient",
    "SafetyDecision",
    "SafetyDenied",
]
