"""
Merkleon — Cryptographic proof of every AI agent action.

Usage:
    from merkleon import Merkleon

    m = Merkleon(api_key="mk_...")
    m.prove("gpt-4o called: summarize Q4 report", agent="research-bot")

The underlying implementation lives in the `veritasagent` package.
This is a clean top-level alias so the SDK matches the product name.
"""
from veritasagent.client import VeritasClient as Merkleon
from veritasagent.client import VeritasClient

__version__ = "0.3.1"
__all__ = ["Merkleon", "VeritasClient"]
