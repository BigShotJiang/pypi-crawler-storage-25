"""
FairCareAI Performance Visualization Module

Publication-quality visualizations for model performance per TRIPOD+AI.
Designed for governance committee presentations to lay stakeholders.

Methodology: Van Calster et al. (2025), TRIPOD+AI (Collins et al. 2024).

Van Calster et al. (2025) Metric Classification:
- RECOMMENDED: AUROC, calibration_plot, net_benefit, decision_curve
- OPTIONAL: Brier score, calibration slope/intercept, ICI, sensitivity, specificity, PPV, NPV
- CAUTION: AUPRC, accuracy, F1, MCC (shown only with explicit request)

Two-Persona Behavior:
- Governance: RECOMMENDED metrics only (default)
- Data Scientist: RECOMMENDED + OPTIONAL when include_optional=True
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import plotly.graph_objects as go
from plotly.subplots import make_subplots

from faircareai.core.config import (
    OutputPersona,
    get_axis_labels,
    get_label,
)
from faircareai.visualization.themes import (
    FAIRCAREAI_COLORS,
    LEGEND_POSITIONS,
    TYPOGRAPHY,
    apply_faircareai_theme,
)

if TYPE_CHECKING:
    from faircareai.core.results import AuditResults


def plot_discrimination_curves(
    results: AuditResults,
    include_optional: bool = False,
    persona: OutputPersona = OutputPersona.DATA_SCIENTIST,
) -> go.Figure:
    """Plot ROC curve (AUROC - RECOMMENDED) and optionally Precision-Recall curve.

    Van Calster et al. (2025) Classification:
    - AUROC: RECOMMENDED - always shown
    - AUPRC: CAUTION - only shown when include_optional=True (mixes statistical/decision-analytical)

    TRIPOD+AI 2.1: Discrimination metrics visualization.

    Args:
        results: AuditResults from FairCareAudit.run().
        include_optional: If True, shows PR curve with AUPRC (CAUTION metric).
            If False, shows only ROC curve with AUROC (RECOMMENDED metric).
            Default False for Governance persona.
        persona: OutputPersona for label terminology (default DATA_SCIENTIST).

    Returns:
        Plotly Figure with discrimination curves.

    Note:
        AUPRC is classified as CAUTION by Van Calster et al. (2025) because it
        "mixes statistical with decision-analytical" assessment. Use with caution.
    """
    # Get persona-appropriate labels for AUROC
    auroc_label = get_label("auroc", persona, "name")
    x_label, y_label = get_axis_labels("auroc", persona)
    perf = results.overall_performance
    disc = perf.get("discrimination", {})

    # Create subplots based on include_optional
    if include_optional:
        # Show both ROC (RECOMMENDED) and PR (CAUTION) curves
        fig = make_subplots(
            rows=1,
            cols=2,
            subplot_titles=(
                f"ROC Curve - {auroc_label} (RECOMMENDED)",
                "Precision-Recall Curve (CAUTION)",
            ),
            horizontal_spacing=0.12,
        )
    else:
        # Show only ROC (RECOMMENDED) curve - single column
        fig = make_subplots(
            rows=1,
            cols=1,
            subplot_titles=(f"ROC Curve - {auroc_label}",),
        )

    # === ROC Curve ===
    roc_data = disc.get("roc_curve", {})
    fpr = roc_data.get("fpr", [])
    tpr = roc_data.get("tpr", [])
    auroc = disc.get("auroc", 0)
    auroc_ci = disc.get("auroc_ci_fmt", "")

    if fpr and tpr:
        # ROC curve
        fig.add_trace(
            go.Scatter(
                x=fpr,
                y=tpr,
                mode="lines",
                name=f"Model (AUROC={auroc:.3f})",
                line=dict(color=FAIRCAREAI_COLORS["primary"], width=2.5),
                hovertemplate="FPR: %{x:.3f}<br>TPR: %{y:.3f}<extra></extra>",
            ),
            row=1,
            col=1,
        )

        # Diagonal reference
        fig.add_trace(
            go.Scatter(
                x=[0, 1],
                y=[0, 1],
                mode="lines",
                name="Random Classifier",
                line=dict(color=FAIRCAREAI_COLORS["gray"], width=1.5, dash="dash"),
                showlegend=False,
            ),
            row=1,
            col=1,
        )

    # Update ROC axes with persona-appropriate labels
    if persona == OutputPersona.GOVERNANCE:
        x_axis_text = "False Alarm Rate"
        y_axis_text = "Detection Rate"
    else:
        x_axis_text = x_label or "1 - Specificity (False Positive Rate)"
        y_axis_text = y_label or "Sensitivity (True Positive Rate)"

    fig.update_xaxes(
        title_text=x_axis_text,
        range=[0, 1],
        tickformat=".0%",
        row=1,
        col=1,
    )
    fig.update_yaxes(
        title_text=y_axis_text,
        range=[0, 1],
        tickformat=".0%",
        row=1,
        col=1,
    )

    # === Precision-Recall Curve (CAUTION metric - only if include_optional) ===
    auprc = disc.get("auprc", 0)
    if include_optional:
        pr_data = disc.get("pr_curve", {})
        recall = pr_data.get("recall", [])
        precision = pr_data.get("precision", [])
        prevalence = disc.get("prevalence", 0)

        if recall and precision:
            # PR curve
            fig.add_trace(
                go.Scatter(
                    x=recall,
                    y=precision,
                    mode="lines",
                    name=f"Model (AUPRC={auprc:.3f})",
                    line=dict(color=FAIRCAREAI_COLORS["secondary"], width=2.5),
                    hovertemplate="Recall: %{x:.3f}<br>Precision: %{y:.3f}<extra></extra>",
                ),
                row=1,
                col=2,
            )

            # Baseline (prevalence)
            fig.add_trace(
                go.Scatter(
                    x=[0, 1],
                    y=[prevalence, prevalence],
                    mode="lines",
                    name=f"Baseline (Prevalence={prevalence:.3f})",
                    line=dict(color=FAIRCAREAI_COLORS["gray"], width=1.5, dash="dash"),
                    showlegend=False,
                ),
                row=1,
                col=2,
            )

        # Update PR axes with clear, descriptive labels
        fig.update_xaxes(
            title_text="Recall (% of actual positives detected)",
            range=[0, 1],
            tickformat=".0%",
            row=1,
            col=2,
        )
        fig.update_yaxes(
            title_text="Precision (% of flagged cases that are true positives)",
            range=[0, 1],
            tickformat=".0%",
            row=1,
            col=2,
        )

    # Generate alt text for WCAG 2.1 AA compliance
    if include_optional:
        alt_text = (
            f"Model discrimination curves. Left: ROC curve with AUROC = {auroc:.3f} {auroc_ci}. "
            f"Right: Precision-Recall curve with AUPRC = {auprc:.3f} (CAUTION metric). "
            "Higher values indicate better model discrimination."
        )
    else:
        alt_text = (
            f"Model discrimination: ROC curve with AUROC = {auroc:.3f} {auroc_ci}. "
            "Higher AUROC indicates better discrimination between outcomes."
        )

    # Apply theme and layout
    fig = apply_faircareai_theme(fig)
    fig.update_layout(
        title=dict(
            text=f"Model Discrimination: AUROC = {auroc:.3f} {auroc_ci}",
            x=0,
            xanchor="left",
        ),
        height=500,
        showlegend=True,
        legend=LEGEND_POSITIONS["top_horizontal"],
        margin=dict(b=80),
        meta={"description": alt_text},  # WCAG 2.1 screen reader support
    )
    return fig


def plot_calibration_curve(
    results: AuditResults,
    include_optional: bool = False,
    persona: OutputPersona = OutputPersona.DATA_SCIENTIST,
) -> go.Figure:
    """Plot calibration curve for overall model.

    Van Calster et al. (2025) Classification:
    - calibration_plot: RECOMMENDED - always shown
    - Brier score, ICI, calibration slope: OPTIONAL - shown when include_optional=True

    TRIPOD+AI 2.2: Calibration visualization.

    Args:
        results: AuditResults from FairCareAudit.run().
        include_optional: If True, shows OPTIONAL metrics (Brier, ICI, slope) in annotation.
            If False, shows only the calibration curve (RECOMMENDED).
            Default False for Governance persona.
        persona: OutputPersona for label terminology (default DATA_SCIENTIST).

    Returns:
        Plotly Figure with calibration curve.

    Note:
        The calibration curve itself is RECOMMENDED per Van Calster et al. (2025).
        Summary statistics (Brier, ICI, slope) are OPTIONAL as they can "conceal
        the direction of miscalibration."
    """
    # Get persona-appropriate labels
    x_label, y_label = get_axis_labels("calibration", persona)
    perf = results.overall_performance
    cal = perf.get("calibration", {})
    cal_curve = cal.get("calibration_curve", {})
    cal_curve_smoothed = cal.get("calibration_curve_smoothed", {})

    smoothed_true = cal_curve_smoothed.get("prob_true", [])
    smoothed_pred = cal_curve_smoothed.get("prob_pred", [])
    prob_true = cal_curve.get("prob_true", [])
    prob_pred = cal_curve.get("prob_pred", [])

    fig = go.Figure()

    # Perfect calibration line
    fig.add_trace(
        go.Scatter(
            x=[0, 1],
            y=[0, 1],
            mode="lines",
            name="Perfect Calibration",
            line=dict(color=FAIRCAREAI_COLORS["gray"], width=1.5, dash="dash"),
        )
    )

    # Calibration curve (smoothed line preferred)
    if smoothed_true and smoothed_pred:
        fig.add_trace(
            go.Scatter(
                x=smoothed_pred,
                y=smoothed_true,
                mode="lines",
                name="Smoothed Calibration",
                line=dict(color=FAIRCAREAI_COLORS["primary"], width=2.5),
                hovertemplate=(
                    "Predicted: %{x:.3f}<br>Observed (smoothed): %{y:.3f}<extra></extra>"
                ),
            )
        )
        if prob_true and prob_pred:
            fig.add_trace(
                go.Scatter(
                    x=prob_pred,
                    y=prob_true,
                    mode="markers",
                    name="Binned Observations",
                    marker=dict(size=6, color=FAIRCAREAI_COLORS["primary"], opacity=0.6),
                    hovertemplate=(
                        "Mean Predicted: %{x:.3f}<br>Observed Rate: %{y:.3f}<extra></extra>"
                    ),
                    showlegend=False,
                )
            )
    elif prob_true and prob_pred:
        fig.add_trace(
            go.Scatter(
                x=prob_pred,
                y=prob_true,
                mode="lines+markers",
                name="Model Calibration",
                line=dict(color=FAIRCAREAI_COLORS["primary"], width=2.5),
                marker=dict(size=8),
                hovertemplate=(
                    "Mean Predicted: %{x:.3f}<br>Observed Rate: %{y:.3f}<extra></extra>"
                ),
            )
        )

    # Metrics annotation - OPTIONAL metrics shown only when include_optional=True
    slope = cal.get("calibration_slope", 1.0)
    brier = cal.get("brier_score", 0)
    ici = cal.get("ici", 0)

    if include_optional:
        metrics_text = (
            f"<b>Calibration Metrics (OPTIONAL)</b><br>"
            f"Slope: {slope:.2f} (ideal: 1.00)<br>"
            f"Brier Score: {brier:.4f}<br>"
            f"ICI: {ici:.4f}"
        )

        fig.add_annotation(
            text=metrics_text,
            xref="paper",
            yref="paper",
            x=0.02,
            y=0.98,
            showarrow=False,
            font=dict(size=TYPOGRAPHY["annotation_size"]),
            align="left",
            bgcolor="rgba(255,255,255,0.8)",
            bordercolor=FAIRCAREAI_COLORS["gray"],
            borderwidth=1,
        )

    # Generate alt text for WCAG 2.1 AA compliance
    alt_text = (
        f"Model calibration curve. Brier score: {brier:.4f} (lower is better). "
        f"Calibration slope: {slope:.3f} (ideal: 1.0). "
        "Points close to the diagonal indicate well-calibrated predictions."
    )

    # Persona-appropriate title and axis labels
    if persona == OutputPersona.GOVERNANCE:
        title_text = "Prediction Accuracy: Do Predicted Risks Match Reality?"
        x_axis_title = "Predicted Risk Level (what the model says)"
        y_axis_title = "Actual Outcome Rate (what really happened)"
    else:
        title_text = "Model Calibration: Do Predicted Risks Match Reality?"
        x_axis_title = x_label or "Mean Predicted Risk (what the model says)"
        y_axis_title = y_label or "Observed Outcome Rate (what actually happened)"

    # Apply theme
    fig = apply_faircareai_theme(fig)
    fig.update_layout(
        title=dict(text=title_text, x=0, xanchor="left"),
        xaxis_title=x_axis_title,
        yaxis_title=y_axis_title,
        height=500,
        width=600,
        xaxis=dict(range=[0, 1], tickformat=".0%"),
        yaxis=dict(range=[0, 1], tickformat=".0%"),
        meta={"description": alt_text},  # WCAG 2.1 screen reader support
    )
    return fig


def plot_threshold_analysis(
    results: AuditResults,
    selected_threshold: float | None = None,
    include_optional: bool = False,
) -> go.Figure:
    """Interactive threshold sensitivity analysis.

    Van Calster et al. (2025) Classification:
    - sensitivity, specificity, PPV, NPV: OPTIONAL - shown when include_optional=True
    - This entire chart displays OPTIONAL classification metrics

    TRIPOD+AI 2.4: Threshold selection transparency.

    Args:
        results: AuditResults from FairCareAudit.run().
        selected_threshold: Threshold to highlight.
        include_optional: If True, shows the threshold analysis chart.
            If False, returns placeholder (chart contains only OPTIONAL metrics).
            Default False for Governance persona.

    Returns:
        Plotly Figure with threshold analysis.

    Note:
        This chart displays OPTIONAL classification metrics per Van Calster et al. (2025).
        For Governance reports, consider using the decision curve instead.
    """
    if not include_optional:
        # Governance mode: return placeholder
        fig = go.Figure()
        fig.add_annotation(
            text="Threshold analysis requires include_optional=True<br>"
            "(Van Calster: sensitivity/specificity/PPV/NPV are OPTIONAL metrics)",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=TYPOGRAPHY["annotation_size"], color=FAIRCAREAI_COLORS["gray"]),
        )
        fig = apply_faircareai_theme(fig)
        fig.update_layout(
            title=dict(text="Threshold Selection Impact", x=0, xanchor="left"),
            height=300,
        )
        return fig
    perf = results.overall_performance
    thresh_data = perf.get("threshold_analysis", {})
    plot_data = thresh_data.get("plot_data", {})

    thresholds = plot_data.get("thresholds", [])
    sensitivity = plot_data.get("sensitivity", [])
    specificity = plot_data.get("specificity", [])
    ppv = plot_data.get("ppv", [])
    npv = plot_data.get("npv", [])
    pct_flagged = plot_data.get("pct_flagged", [])

    if not thresholds:
        fig = go.Figure()
        fig.add_annotation(
            text="No threshold analysis data available",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=TYPOGRAPHY["annotation_size"], color=FAIRCAREAI_COLORS["gray"]),
        )
        fig = apply_faircareai_theme(fig)
        fig.update_layout(
            title=dict(text="Threshold Selection Impact", x=0, xanchor="left"),
            height=300,
        )
        return fig

    fig = make_subplots(
        rows=2,
        cols=1,
        subplot_titles=(
            "Classification Metrics by Threshold",
            "Percentage of Patients Flagged",
        ),
        vertical_spacing=0.22,
        row_heights=[0.65, 0.35],
    )

    # Classification metrics
    metrics = [
        ("Sensitivity (TPR)", sensitivity, FAIRCAREAI_COLORS["primary"]),
        ("Specificity (1-FPR)", specificity, FAIRCAREAI_COLORS["secondary"]),
        ("PPV (Precision)", ppv, FAIRCAREAI_COLORS["accent"]),
        ("NPV", npv, FAIRCAREAI_COLORS["success"]),
    ]

    for name, values, color in metrics:
        fig.add_trace(
            go.Scatter(
                x=thresholds,
                y=values,
                mode="lines",
                name=name,
                line=dict(color=color, width=2),
                hovertemplate=f"{name}: %{{y:.1%}}<br>Threshold: %{{x:.2f}}<extra></extra>",
            ),
            row=1,
            col=1,
        )

    # Percentage flagged
    fig.add_trace(
        go.Scatter(
            x=thresholds,
            y=pct_flagged,
            mode="lines+markers",
            name="% Flagged",
            line=dict(color=FAIRCAREAI_COLORS["warning"], width=2),
            marker=dict(size=6),
            hovertemplate="Flagged: %{y:.1f}%<br>Threshold: %{x:.2f}<extra></extra>",
        ),
        row=2,
        col=1,
    )

    # Highlight selected threshold
    if selected_threshold is not None:
        for row in [1, 2]:
            fig.add_vline(
                x=selected_threshold,
                line=dict(color=FAIRCAREAI_COLORS["error"], width=2, dash="dash"),
                annotation_text=f"Selected: {selected_threshold:.2f}",
                annotation_position="top",
                row=row,
                col=1,
            )

    # Update axes with descriptive labels
    fig.update_xaxes(
        title_text="Decision Threshold (risk cutoff for flagging patients)", row=2, col=1
    )
    fig.update_yaxes(title_text="Performance Metric Value", tickformat=".0%", row=1, col=1)
    fig.update_yaxes(title_text="% of Patients Flagged as High-Risk", row=2, col=1)

    # Generate alt text for WCAG 2.1 AA compliance
    threshold_text = f" Selected threshold: {selected_threshold:.2f}." if selected_threshold else ""
    alt_text = (
        "Threshold selection impact analysis. "
        "Top: Performance metrics (Sensitivity, Specificity, PPV, NPV) across thresholds. "
        "Bottom: Percentage of patients flagged at each threshold."
        f"{threshold_text}"
    )

    # Apply theme
    fig = apply_faircareai_theme(fig)
    fig.update_layout(
        title=dict(text="Threshold Selection Impact", x=0, xanchor="left"),
        height=650,
        showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
        ),
        margin=dict(t=100),
        meta={"description": alt_text},  # WCAG 2.1 screen reader support
    )

    return fig


def plot_decision_curve(
    results: AuditResults,
    persona: OutputPersona = OutputPersona.DATA_SCIENTIST,
) -> go.Figure:
    """Plot Decision Curve Analysis for clinical utility.

    Van Calster et al. (2025) Classification: RECOMMENDED
    - net_benefit, decision_curve: Essential for clinical decision support
    - Always shown regardless of include_optional setting

    TRIPOD+AI 2.5: Clinical utility assessment.

    Args:
        results: AuditResults from FairCareAudit.run().
        persona: OutputPersona for label terminology (default DATA_SCIENTIST).

    Returns:
        Plotly Figure with DCA curves.

    Note:
        This is a RECOMMENDED metric per Van Calster et al. (2025).
        Decision curves show clinical utility across threshold probabilities.
    """
    # Get persona-appropriate labels
    x_label, y_label = get_axis_labels("decision_curve", persona)
    perf = results.overall_performance
    dca = perf.get("decision_curve", {})

    thresholds = dca.get("thresholds", [])
    nb_model = dca.get("net_benefit_model", [])
    nb_all = dca.get("net_benefit_all", [])
    nb_none = dca.get("net_benefit_none", [])
    useful_range = dca.get("useful_range_summary", {})

    fig = go.Figure()

    if not thresholds:
        fig.add_annotation(
            text="No decision curve data available",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=TYPOGRAPHY["annotation_size"], color=FAIRCAREAI_COLORS["gray"]),
        )
        fig = apply_faircareai_theme(fig)
        fig.update_layout(
            title=dict(text="Decision Curve Analysis", x=0, xanchor="left"),
            height=500,
        )
        return fig

    # Net benefit curves
    # Model
    fig.add_trace(
        go.Scatter(
            x=thresholds,
            y=nb_model,
            mode="lines",
            name="Model",
            line=dict(color=FAIRCAREAI_COLORS["primary"], width=2.5),
            hovertemplate="Net Benefit: %{y:.3f}<br>Threshold: %{x:.2f}<extra></extra>",
        )
    )

    # Treat All
    fig.add_trace(
        go.Scatter(
            x=thresholds,
            y=nb_all,
            mode="lines",
            name="Treat All",
            line=dict(color=FAIRCAREAI_COLORS["warning"], width=2, dash="dash"),
        )
    )

    # Treat None
    fig.add_trace(
        go.Scatter(
            x=thresholds,
            y=nb_none,
            mode="lines",
            name="Treat None",
            line=dict(color=FAIRCAREAI_COLORS["gray"], width=2, dash="dot"),
        )
    )

    # Shade useful range
    if useful_range.get("min") is not None and useful_range.get("max") is not None:
        fig.add_vrect(
            x0=useful_range["min"],
            x1=useful_range["max"],
            fillcolor=FAIRCAREAI_COLORS["success"],
            opacity=0.1,
            line_width=0,
            annotation_text="Useful Range",
            annotation_position="top",
        )

    # Generate alt text for WCAG 2.1 AA compliance
    alt_text = (
        "Decision Curve Analysis showing clinical utility of the model. "
        "Compares net benefit of using the model versus treating all or no patients. "
        "Model is useful when its curve is above both 'Treat All' and 'Treat None' strategies."
    )

    # Persona-appropriate title and axis labels
    if persona == OutputPersona.GOVERNANCE:
        title_text = "Clinical Utility Analysis: When is the Model Useful?"
        x_axis_title = x_label or "Risk Cutoff Level (risk level for taking action)"
        y_axis_title = y_label or "Clinical Value (benefit per 100 patients)"
    else:
        title_text = "Decision Curve Analysis: When is the Model Clinically Useful?"
        x_axis_title = x_label or "Threshold Probability (risk level for action)"
        y_axis_title = y_label or "Net Benefit (clinical value per 100 patients)"

    # Apply theme
    fig = apply_faircareai_theme(fig)
    fig.update_layout(
        title=dict(
            text=title_text,
            x=0,
            xanchor="left",
        ),
        xaxis_title=x_axis_title,
        yaxis_title=y_axis_title,
        height=500,
        xaxis=dict(range=[0, 1], tickformat=".0%"),
        yaxis=dict(
            range=[
                min(-0.1, min(nb_model) * 1.1 if nb_model else -0.5),
                max(nb_model) * 1.3 if nb_model else 0.5,
            ]
        ),
        margin=dict(r=80),
        meta={"description": alt_text},  # WCAG 2.1 screen reader support
    )

    # Interpretation annotation
    interpretation = (
        "<b>Interpretation:</b><br>"
        "Model is useful when its curve is above both<br>"
        "'Treat All' and 'Treat None' strategies."
    )

    fig.add_annotation(
        text=interpretation,
        xref="paper",
        yref="paper",
        x=0.98,
        y=0.02,
        xanchor="right",
        yanchor="bottom",
        showarrow=False,
        font=dict(size=TYPOGRAPHY["annotation_size"]),
        align="left",
        bgcolor="rgba(255,255,255,0.9)",
        bordercolor=FAIRCAREAI_COLORS["gray"],
        borderwidth=1,
    )
    return fig


def plot_confusion_matrix(results: AuditResults) -> go.Figure:
    """Plot confusion matrix heatmap.

    Args:
        results: AuditResults from FairCareAudit.run().

    Returns:
        Plotly Figure with confusion matrix.
    """
    perf = results.overall_performance
    cm = perf.get("confusion_matrix", {})

    matrix = cm.get("matrix", [[0, 0], [0, 0]])
    threshold = cm.get("threshold", 0.5)

    # Extract values
    tn, fp = matrix[0]
    fn, tp = matrix[1]
    total = tn + fp + fn + tp

    if total == 0:
        fig = go.Figure()
        fig.add_annotation(
            text="No confusion matrix data available (empty dataset)",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=TYPOGRAPHY["annotation_size"], color=FAIRCAREAI_COLORS["gray"]),
        )
        fig = apply_faircareai_theme(fig)
        fig.update_layout(
            title=dict(text="Confusion Matrix", x=0, xanchor="left"),
            height=400,
        )
        return fig

    # Create text annotations
    text = [
        [
            f"TN<br>{tn:,}<br>({tn / total * 100:.1f}%)",
            f"FP<br>{fp:,}<br>({fp / total * 100:.1f}%)",
        ],
        [
            f"FN<br>{fn:,}<br>({fn / total * 100:.1f}%)",
            f"TP<br>{tp:,}<br>({tp / total * 100:.1f}%)",
        ],
    ]

    # Color scale (darker for higher values)
    z = [[tn, fp], [fn, tp]]

    fig = go.Figure(
        data=go.Heatmap(
            z=z,
            x=["Predicted Negative", "Predicted Positive"],
            y=["Actual Negative", "Actual Positive"],
            text=text,
            texttemplate="%{text}",
            textfont=dict(size=14),
            colorscale=[
                [0, "white"],
                [0.5, FAIRCAREAI_COLORS["secondary"]],
                [1, FAIRCAREAI_COLORS["primary"]],
            ],
            showscale=False,
            hoverongaps=False,
        )
    )

    # Generate alt text for WCAG 2.1 AA compliance
    alt_text = (
        f"Confusion matrix at threshold {threshold:.2f}. "
        f"True Negatives: {tn}, False Positives: {fp}, "
        f"False Negatives: {fn}, True Positives: {tp}."
    )

    # Apply theme
    fig = apply_faircareai_theme(fig)
    fig.update_layout(
        title=dict(text=f"Confusion Matrix at Threshold = {threshold:.2f}", x=0, xanchor="left"),
        xaxis_title="Predicted",
        yaxis_title="Actual",
        height=400,
        width=500,
        meta={"description": alt_text},  # WCAG 2.1 screen reader support
    )

    return fig


def plot_performance_summary(
    results: AuditResults,
    include_optional: bool = False,
) -> go.Figure:
    """Create a single-page performance summary for governance.

    Van Calster et al. (2025) Classification:
    - AUROC: RECOMMENDED - always shown
    - Brier Score: OPTIONAL - shown when include_optional=True
    - Sensitivity, Specificity, PPV, NPV: OPTIONAL - shown when include_optional=True

    Args:
        results: AuditResults from FairCareAudit.run().
        include_optional: If True, shows full 2x2 summary with OPTIONAL metrics.
            If False, shows RECOMMENDED metrics only (AUROC).
            Default False for Governance persona.

    Returns:
        Plotly Figure with key performance metrics.

    Note:
        By default, shows only RECOMMENDED metrics per Van Calster et al. (2025).
        Enable include_optional=True for full Data Scientist view.
    """
    perf = results.overall_performance
    disc = perf.get("discrimination", {})
    cal = perf.get("calibration", {})
    cls = perf.get("classification_at_threshold", {})

    if include_optional:
        # Data Scientist view: full 2x2 subplot with OPTIONAL metrics
        fig = make_subplots(
            rows=2,
            cols=2,
            subplot_titles=(
                "Discrimination (AUROC) - RECOMMENDED",
                "Calibration (Brier) - OPTIONAL",
                "Classification Metrics - OPTIONAL",
                "% Flagged High Risk",
            ),
            specs=[
                [{"type": "indicator"}, {"type": "indicator"}],
                [{"type": "bar"}, {"type": "indicator"}],
            ],
            vertical_spacing=0.2,
            horizontal_spacing=0.15,
        )
    else:
        # Governance view: RECOMMENDED metrics only
        fig = make_subplots(
            rows=1,
            cols=1,
            subplot_titles=("Discrimination (AUROC) - RECOMMENDED",),
            specs=[[{"type": "indicator"}]],
        )

    # AUROC gauge
    auroc = disc.get("auroc", 0)
    fig.add_trace(
        go.Indicator(
            mode="gauge+number",
            value=auroc,
            number={"suffix": "", "valueformat": ".3f"},
            gauge=dict(
                axis=dict(range=[0.5, 1]),
                bar=dict(color=FAIRCAREAI_COLORS["primary"]),
                steps=[
                    {"range": [0.5, 0.7], "color": FAIRCAREAI_COLORS["error"]},
                    {"range": [0.7, 0.8], "color": FAIRCAREAI_COLORS["warning"]},
                    {"range": [0.8, 1], "color": FAIRCAREAI_COLORS["success"]},
                ],
                threshold=dict(
                    line=dict(color="black", width=2),
                    thickness=0.75,
                    value=0.8,
                ),
            ),
        ),
        row=1,
        col=1,
    )

    # OPTIONAL metrics - only shown when include_optional=True
    if include_optional:
        # Calibration gauge (Brier score - lower is better) - OPTIONAL
        brier = cal.get("brier_score", 0.25)
        fig.add_trace(
            go.Indicator(
                mode="gauge+number",
                value=brier,
                number={"suffix": "", "valueformat": ".3f"},
                title={"text": "Brier Score"},
                gauge=dict(
                    axis=dict(range=[0, 0.5]),
                    bar=dict(color=FAIRCAREAI_COLORS["secondary"]),
                    steps=[
                        {"range": [0, 0.1], "color": FAIRCAREAI_COLORS["success"]},
                        {"range": [0.1, 0.2], "color": FAIRCAREAI_COLORS["warning"]},
                        {"range": [0.2, 0.5], "color": FAIRCAREAI_COLORS["error"]},
                    ],
                ),
            ),
            row=1,
            col=2,
        )

        # Classification metrics bar chart - OPTIONAL
        metrics = {
            "Sensitivity": cls.get("sensitivity", 0),
            "Specificity": cls.get("specificity", 0),
            "PPV": cls.get("ppv", 0),
            "NPV": cls.get("npv", 0),
        }

        fig.add_trace(
            go.Bar(
                x=list(metrics.keys()),
                y=list(metrics.values()),
                marker_color=[
                    FAIRCAREAI_COLORS["primary"],
                    FAIRCAREAI_COLORS["secondary"],
                    FAIRCAREAI_COLORS["accent"],
                    FAIRCAREAI_COLORS["success"],
                ],
                text=[f"{v:.1%}" for v in metrics.values()],
                textposition="inside",
                textfont=dict(color="white", size=TYPOGRAPHY["annotation_size"]),
            ),
            row=2,
            col=1,
        )

        # % Flagged indicator
        pct_flagged = cls.get("pct_flagged", 0)
        fig.add_trace(
            go.Indicator(
                mode="number+delta",
                value=pct_flagged,
                number={"suffix": "%", "valueformat": ".1f"},
                title={"text": "% Flagged High Risk"},
            ),
            row=2,
            col=2,
        )

    # Generate alt text for WCAG 2.1 AA compliance
    auroc = disc.get("auroc", 0)
    brier = cal.get("brier_score", 0)
    sensitivity = cls.get("sensitivity", 0)
    specificity = cls.get("specificity", 0)
    ppv = cls.get("ppv", 0)
    npv = cls.get("npv", 0)
    pct_flagged = cls.get("pct_flagged", 0)

    if include_optional:
        alt_text = (
            f"Model performance summary for {results.config.model_name}. "
            f"AUROC: {auroc:.3f} (RECOMMENDED). Brier Score: {brier:.4f} (OPTIONAL). "
            f"Sensitivity: {sensitivity:.1%}, Specificity: {specificity:.1%}, "
            f"PPV: {ppv:.1%}, NPV: {npv:.1%} (all OPTIONAL). "
            f"{pct_flagged:.1f}% of patients flagged as high risk."
        )
        # Update layout for 2x2 grid
        fig.update_layout(
            title=dict(
                text=f"Model Performance Summary - {results.config.model_name}",
                x=0,
                xanchor="left",
            ),
            height=600,
            showlegend=False,
            meta={"description": alt_text},
        )
        fig.update_yaxes(title_text="Value", range=[0, 1.1], tickformat=".0%", row=2, col=1)
        fig.update_xaxes(title_text="Metric", row=2, col=1)
    else:
        alt_text = (
            f"Model discrimination summary for {results.config.model_name}. "
            f"AUROC: {auroc:.3f} (RECOMMENDED metric per Van Calster et al. 2025)."
        )
        # Update layout for single gauge
        fig.update_layout(
            title=dict(
                text=f"Model Discrimination (AUROC) - {results.config.model_name}",
                x=0,
                xanchor="left",
            ),
            height=350,
            showlegend=False,
            meta={"description": alt_text},
        )

    # Apply theme
    fig = apply_faircareai_theme(fig)

    return fig
