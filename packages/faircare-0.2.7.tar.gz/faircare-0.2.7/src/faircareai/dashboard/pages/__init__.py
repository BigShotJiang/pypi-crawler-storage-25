"""FairCareAI Dashboard Pages."""
