"""
FairCareAI - Analysis Page

Main analysis dashboard with dual-audience support.
Displays performance metrics, fairness analysis, and visualizations.
"""

from typing import Any

import polars as pl
import streamlit as st

from faircareai.dashboard.components.accessibility import (
    accessible_plotly_chart,
    announce_status_change,
    generate_chart_alt_text,
    render_semantic_heading,
    render_skip_link,
)
from faircareai.dashboard.components.audience_toggle import (
    get_metric_display,
    get_section_content,
    render_audience_toggle,
)
from faircareai.dashboard.components.glossary import (
    render_glossary_sidebar,
    render_inline_definition,
)
from faircareai.visualization.themes import (
    GOVERNANCE_DISCLAIMER_SHORT,
    render_scorecard_html,
    render_status_badge,
)


@st.cache_data
def run_audit(_df: pl.DataFrame, threshold: float, group_cols: list[str]) -> tuple[Any, Any]:
    """Run and cache audit results."""
    from datetime import date

    from faircareai.core.audit import AuditResult
    from faircareai.core.disparity import compute_disparities
    from faircareai.core.metrics import compute_group_metrics

    df = _df

    if "y_pred" not in df.columns:
        if "y_prob" not in df.columns:
            raise ValueError("Missing required column: `y_pred` or `y_prob`")
        df = df.with_columns((pl.col("y_prob") >= threshold).cast(pl.Int64).alias("y_pred"))

    metrics: list[str] = ["tpr", "fpr", "ppv", "npv"]

    metrics_frames: list[pl.DataFrame] = []
    disparities_frames: list[pl.DataFrame] = []
    warnings: list[str] = []

    # Build a single overall row (independent of attribute)
    overall_base = compute_group_metrics(
        df,
        group_col=group_cols[0],
        y_true_col="y_true",
        y_pred_col="y_pred",
        metrics=metrics,
    ).filter(pl.col("group") == "_overall")
    overall_metrics = overall_base.with_columns(pl.lit("_overall").alias("attribute"))

    for attr in group_cols:
        group_metrics = compute_group_metrics(
            df,
            group_col=attr,
            y_true_col="y_true",
            y_pred_col="y_pred",
            metrics=metrics,
        )

        # Collect sample size warnings (non-empty strings)
        warning_rows = (
            group_metrics.filter(pl.col("warning") != "")
            .select(pl.col("warning"))
            .to_series()
            .to_list()
        )
        warnings.extend([w for w in warning_rows if isinstance(w, str) and w])

        metrics_frames.append(
            group_metrics.filter(pl.col("group") != "_overall").with_columns(
                pl.lit(attr).alias("attribute")
            )
        )

        for metric in metrics:
            disparities = compute_disparities(group_metrics, metric=metric)
            if len(disparities) == 0:
                continue
            disparities_frames.append(
                disparities.with_columns(
                    [
                        pl.lit(attr).alias("attribute"),
                        pl.col("status").str.to_uppercase(),
                    ]
                )
            )

    metrics_df = pl.concat([overall_metrics, *metrics_frames], how="vertical")
    disparities_df = (
        pl.concat(disparities_frames, how="vertical") if disparities_frames else pl.DataFrame()
    )

    pass_count = (
        len(disparities_df.filter(pl.col("status") == "PASS")) if len(disparities_df) else 0
    )
    warn_count = (
        len(disparities_df.filter(pl.col("status") == "WARN")) if len(disparities_df) else 0
    )
    fail_count = (
        len(disparities_df.filter(pl.col("status") == "FAIL")) if len(disparities_df) else 0
    )

    worst_disparity: tuple[str, str, float] | None = None
    if len(disparities_df) > 0:
        worst_row = (
            disparities_df.with_columns(pl.col("difference").abs().alias("_abs_diff"))
            .sort("_abs_diff", descending=True)
            .head(1)
            .to_dicts()
        )
        if worst_row:
            row = worst_row[0]
            worst_disparity = (
                str(row.get("comparison_group", "")),
                str(row.get("metric", "")),
                float(row.get("difference", 0.0)),
            )

    result = AuditResult(
        model_name="Uploaded Model",
        audit_date=date.today().isoformat(),
        n_samples=len(df),
        threshold=threshold,
        group_col=group_cols[0] if len(group_cols) == 1 else "multiple",
        metrics_df=metrics_df,
        disparities_df=disparities_df,
        pass_count=pass_count,
        warn_count=warn_count,
        fail_count=fail_count,
        worst_disparity=worst_disparity,
        warnings=sorted(set(warnings)),
    )

    return result, None


def render_executive_summary(result: Any, audience: str) -> None:
    """Render executive summary section."""
    render_semantic_heading("Results Summary", level=2, id="summary")

    # Present counts objectively
    if audience == "governance":
        status_desc = (
            f"{result.pass_count} metrics within threshold, "
            f"{result.warn_count} near threshold, "
            f"{result.fail_count} outside threshold."
        )
    else:
        status_desc = (
            f"{result.pass_count} pass, {result.warn_count} warn, "
            f"{result.fail_count} outside configured thresholds."
        )

    # Visual status based on counts
    if result.fail_count > 0:
        status_type = "fail"
    elif result.warn_count > 0:
        status_type = "warn"
    else:
        status_type = "pass"

    st.markdown(
        render_status_badge(
            status_type,
            f"<b>Analysis Complete</b><br><span style='font-size:14px'>{status_desc}</span>",
        ),
        unsafe_allow_html=True,
    )

    st.write("")

    # Scorecard
    st.markdown(
        render_scorecard_html(result.pass_count, result.warn_count, result.fail_count),
        unsafe_allow_html=True,
    )

    # Key metrics row
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Samples", f"{result.n_samples:,}")
    with col2:
        st.metric("Decision Threshold", f"{result.threshold:.0%}")
    with col3:
        st.metric(
            "Groups Analyzed",
            result.group_col.replace("_", " ").title() if result.group_col else "N/A",
        )

    # Largest disparity callout
    if result.worst_disparity:
        group, metric, value = result.worst_disparity

        if audience == "governance":
            metric_name = {
                "tpr": "Detection Rate",
                "fpr": "False Alarm Rate",
                "ppv": "Positive Flag Accuracy",
                "npv": "Negative Flag Accuracy",
            }.get(metric, metric.upper())

            direction = "lower" if value < 0 else "higher"
            st.markdown(
                f"""<div class="fc-callout-disparity">
                <b>Largest Disparity</b><br>
                The model's {metric_name} for <b>{group}</b> patients is <b>{abs(value):.1%}</b> {direction}
                than the reference group.
                </div>""",
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                f"""<div class="fc-callout-disparity">
                <b>Largest Disparity</b><br>
                {metric.upper()} for <b>{group}</b>: Δ = {value:+.3f} vs reference
                </div>""",
                unsafe_allow_html=True,
            )


def render_performance_section(result: Any, df: pl.DataFrame, audience: str) -> None:
    """Render overall performance section."""
    section_content = get_section_content("overall_performance", audience, {})

    render_semantic_heading(section_content["title"], level=2, id="performance")
    st.markdown(section_content["description"])

    # Performance metrics in columns
    col1, col2, col3, col4 = st.columns(4)

    # Get metrics from result
    metrics_row = result.metrics_df.filter(pl.col("group") == "_overall").head(1)

    if len(metrics_row) > 0:
        row = metrics_row.to_dicts()[0]

        with col1:
            auroc_display = get_metric_display("auroc", row.get("auroc"), audience)
            st.metric(auroc_display["name"], auroc_display["value"])
            if audience == "governance":
                st.caption("Higher is better (max 1.0)")

        with col2:
            tpr_display = get_metric_display("tpr", row.get("tpr"), audience)
            st.metric(tpr_display["name"], tpr_display["value"])
            if audience == "governance":
                st.caption("% of cases correctly caught")

        with col3:
            fpr_display = get_metric_display("fpr", row.get("fpr"), audience)
            st.metric(fpr_display["name"], fpr_display["value"])
            if audience == "governance":
                st.caption("% of false alarms")

        with col4:
            ppv_display = get_metric_display("ppv", row.get("ppv"), audience)
            st.metric(ppv_display["name"], ppv_display["value"])
            if audience == "governance":
                st.caption("% of flags that are correct")


def render_fairness_section(
    result: Any, df: pl.DataFrame, group_cols: list[str], audience: str
) -> None:
    """Render fairness analysis section."""
    section_content = get_section_content("fairness_summary", audience, {})

    render_semantic_heading(section_content["title"], level=2, id="fairness")
    st.markdown(section_content["description"])

    from faircareai.visualization.plots import create_forest_plot

    # Metric selector
    if audience == "data_scientist":
        metric_options: list[str] = ["tpr", "fpr", "ppv", "npv"]
        selected_metric_value = st.selectbox(
            "Select metric to analyze",
            options=metric_options,
            format_func=lambda x: x.upper(),
        )
        selected_metric = selected_metric_value or "tpr"
    else:
        metric_labels: dict[str, str] = {
            "tpr": "Detection Rate",
            "fpr": "False Alarm Rate",
            "ppv": "Positive Flag Accuracy",
            "npv": "Negative Flag Accuracy",
        }
        selected_metric_value = st.selectbox(
            "What would you like to examine?",
            options=list(metric_labels.keys()),
            format_func=lambda x: metric_labels[x],
        )
        selected_metric = selected_metric_value or "tpr"

    # Show inline definition for governance
    if audience == "governance":
        render_inline_definition(selected_metric, audience)

    st.markdown("---")

    # Forest plots for each demographic attribute
    for attr in group_cols:
        render_semantic_heading(
            f"By {attr.replace('_', ' ').title()}",
            level=3,
        )

        attr_metrics = result.metrics_df.filter(
            (pl.col("attribute") == attr) & (pl.col("group") != "_overall")
        )

        if len(attr_metrics) > 0:
            # Add CI columns for forest plot
            ci_lower_col = f"{selected_metric}_ci_lower"
            ci_upper_col = f"{selected_metric}_ci_upper"

            if ci_lower_col in attr_metrics.columns and ci_upper_col in attr_metrics.columns:
                metrics_with_ci = attr_metrics.with_columns(
                    [
                        pl.col(ci_lower_col).alias("ci_lower"),
                        pl.col(ci_upper_col).alias("ci_upper"),
                    ]
                )
            else:
                # Fallback: create dummy CI columns
                metrics_with_ci = attr_metrics.with_columns(
                    [
                        pl.col(selected_metric).alias("ci_lower"),
                        pl.col(selected_metric).alias("ci_upper"),
                    ]
                )

            # Create forest plot
            if audience == "governance":
                subtitle = "Comparison of groups to the reference line"
            else:
                subtitle = "95% CI shown. Ghosted bars indicate small sample sizes."

            fig = create_forest_plot(
                metrics_with_ci,
                metric=selected_metric,
                title=f"{selected_metric.upper()} by {attr.replace('_', ' ').title()}",
                subtitle=subtitle,
                show_safe_zone=selected_metric in ["tpr", "ppv", "npv"],
            )

            # Generate alt text
            alt_text = generate_chart_alt_text(
                "forest_plot",
                {
                    "n_groups": len(attr_metrics),
                    "metric": selected_metric,
                    "attribute": attr,
                    "reference_group": "overall",
                    "range_min": attr_metrics[selected_metric].min(),
                    "range_max": attr_metrics[selected_metric].max(),
                    "flagged_count": len(
                        result.disparities_df.filter(
                            (pl.col("attribute") == attr)
                            & (pl.col("metric") == selected_metric)
                            & (pl.col("status") == "FAIL")
                        )
                    ),
                },
            )

            accessible_plotly_chart(fig, f"forest_{attr}", alt_text)

            # Disparity summary
            attr_disparities = result.disparities_df.filter(
                (pl.col("attribute") == attr) & (pl.col("metric") == selected_metric)
            )

            if len(attr_disparities) > 0:
                flagged = attr_disparities.filter(pl.col("status") == "FAIL")
                review = attr_disparities.filter(pl.col("status") == "WARN")

                if len(flagged) > 0:
                    if audience == "governance":
                        st.info(f"{len(flagged)} group(s) outside configured threshold")
                    else:
                        st.info(f"{len(flagged)} group comparison(s) outside threshold")
                if len(review) > 0:
                    if audience == "governance":
                        st.info(f"{len(review)} group(s) near configured threshold")
                    else:
                        st.info(f"{len(review)} group comparison(s) near threshold")

        st.markdown("---")


def render_impossibility_callout(result: Any, audience: str) -> None:
    """Render the Impossibility Theorem callout when disparities exist.

    Per Chouldechova (2017) and Kleinberg et al. (2017), it is mathematically
    impossible to satisfy all fairness metrics simultaneously when base rates
    differ between groups. This callout surfaces that insight contextually.
    """
    if len(result.disparities_df) == 0:
        return

    has_flags = result.fail_count > 0 or result.warn_count > 0
    if not has_flags:
        return

    render_semantic_heading("Understanding Fairness Trade-offs", level=2, id="impossibility")

    if audience == "governance":
        st.markdown(
            """<div class="fc-callout-info">"""
            """<b>Why can't we make all metrics equal?</b><br><br>"""
            """Mathematics shows that when different patient groups have different """
            """underlying rates of a condition, it is <b>impossible</b> to make all """
            """fairness metrics equal at the same time """
            """(Chouldechova 2017; Kleinberg et al. 2017).<br><br>"""
            """This means <b>choosing which fairness metric to prioritize is a """
            """values decision</b> that your governance team must make based on """
            """clinical context. For example:<br>"""
            """<ul>"""
            """<li>Prioritizing <b>equal Detection Rates</b> means accepting """
            """different False Alarm Rates between groups</li>"""
            """<li>Prioritizing <b>equal False Alarm Rates</b> means accepting """
            """different Detection Rates between groups</li>"""
            """</ul>"""
            """Neither choice is wrong — the right choice depends on the clinical """
            """consequences of each type of error for your patient population."""
            """</div>""",
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            """<div class="fc-callout-info">"""
            """<b>Impossibility Theorem</b><br><br>"""
            """Per Chouldechova (2017) and Kleinberg et al. (2017), when base rates """
            """differ across groups, simultaneously satisfying calibration, """
            """equalized odds, and predictive parity is mathematically impossible """
            """(except in degenerate cases).<br><br>"""
            """<b>Implication:</b> The choice of primary fairness metric is a """
            """normative decision, not a technical one. Document your metric """
            """selection rationale in the Fairness Configuration settings."""
            """</div>""",
            unsafe_allow_html=True,
        )


def render_analysis_page() -> None:
    """Render the main analysis page."""
    render_skip_link()

    # Check for data
    if "uploaded_data" not in st.session_state:
        st.warning("No data loaded. Please upload data first.")
        if st.button("Go to Upload Page"):
            st.switch_page("pages/1_upload.py")
        return

    df = st.session_state["uploaded_data"]
    group_cols = st.session_state.get("selected_demographic_cols", [])

    if not group_cols:
        st.warning("No demographic columns selected. Please select columns first.")
        if st.button("Go to Upload Page"):
            st.switch_page("pages/1_upload.py")
        return

    # Header
    render_semantic_heading("Fairness Analysis", level=1, id="page-title")
    st.caption(f"Step 2 of 4 | {GOVERNANCE_DISCLAIMER_SHORT}")

    # Sidebar: Glossary and configuration
    with st.sidebar:
        st.markdown("### Configuration")

        # Read defaults from Settings page (session state), fall back to sensible defaults
        default_threshold = st.session_state.get("default_threshold", 0.5)

        threshold = st.slider(
            "Decision Threshold",
            0.0,
            1.0,
            default_threshold,
            0.01,
            help="Classification threshold for binary predictions",
            key="analysis_threshold",
        )

        st.divider()

        render_glossary_sidebar()

    # Audience toggle
    st.markdown("---")
    audience = render_audience_toggle()
    st.markdown("---")

    # Run audit
    result, audit = run_audit(df, threshold, group_cols)
    announce_status_change("Analysis complete")

    # Render sections
    render_executive_summary(result, audience)
    st.markdown("---")
    render_performance_section(result, df, audience)
    st.markdown("---")
    render_fairness_section(result, df, group_cols, audience)
    render_impossibility_callout(result, audience)

    # Navigation
    st.markdown("---")
    col1, col2 = st.columns(2)

    with col1:
        if st.button("Back to Upload", use_container_width=True):
            st.switch_page("pages/1_upload.py")

    with col2:
        if st.button("Continue to Governance Report", type="primary", use_container_width=True):
            st.session_state["audit_result"] = result
            st.session_state["audit_threshold"] = threshold
            st.switch_page("pages/3_governance.py")


# Run the page
render_analysis_page()
