"""
KHY-Quant: Open-source quantitative trading system.

This package provides a Python CLI launcher that bootstraps and manages
a Node.js-based quantitative trading backend. The architecture is:

    Python CLI (entry point)
        -> Node.js backend (Express server + CLI REPL)
            -> Data sources (AKShare, TuShare, etc.)
            -> AI providers (Gemini, Groq, OpenRouter, etc.)
            -> SQLite/PostgreSQL database
            -> Vue.js frontend (optional)

Key features:
    - Multi-source market data aggregation (A-shares, crypto, forex)
    - AI-powered trading signal generation and strategy recommendations
    - Backtesting engine with historical data replay
    - Real-time portfolio tracking and risk management
    - Plugin system for custom strategies and data adapters
    - Web UI dashboard with professional TradingView-style charts

Install modes:
    pip install khy-quant          # Core CLI + backend
    pip install khy-quant[data]    # + Python data analysis (pandas, numpy)
    pip install khy-quant[ml]      # + Machine learning strategies (sklearn, xgboost)
    pip install khy-quant[full]    # Everything

Quick start:
    $ khy            # Launch interactive REPL
    $ khy server     # Start web server on port 8080
    $ khy data list  # Browse available data sources

Version history:
    1.0.4 - Open-source release with full documentation
"""
__version__ = "1.6.6.2"
