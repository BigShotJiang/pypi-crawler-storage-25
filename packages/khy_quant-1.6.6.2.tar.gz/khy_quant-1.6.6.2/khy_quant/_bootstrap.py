"""
First-run bootstrap for KHY-Quant.

When a user installs KHY-Quant via `pip install khy-quant` and runs `khy`
for the first time, several setup steps are needed before the Node.js
backend can start:

1. **npm install** — Install Node.js dependencies (Express, Sequelize, etc.)
   The pip wheel includes source code but NOT node_modules/ (too large).
   This step downloads ~200MB of npm packages on first run.

2. **.env generation** — Create environment configuration with secure random
   secrets (JWT_SECRET, etc.). Uses Python's `secrets` module for
   cryptographically strong random values.

3. **Database initialization** — Run the seed script to create SQLite tables
   and insert default data (admin user, default strategies, etc.).

4. **Getting-started guide** — Generate a welcome document with quickstart
   instructions tailored to the user's environment.

The bootstrap is idempotent: a marker file (.khy_quant_bootstrapped) prevents
re-running on subsequent launches. If something fails, the user can delete
the marker and re-run `khy` to retry.

Network considerations:
    - In China, npm is slow/unreliable from the default registry
    - We auto-detect Chinese locale and configure npmmirror.com
    - This is written to a project-level .npmrc (not global config)
"""
import os
import secrets
import subprocess
import sys
from pathlib import Path

# Marker file name — when this exists in backend_dir, bootstrap is skipped
MARKER_FILE = ".khy_quant_bootstrapped"


def _is_china_network() -> bool:
    """Heuristic: detect if user is likely in China (for npm mirror selection).

    Checks:
    - LANG/LC_ALL environment variables for "zh" prefix
    - TZ environment variable for Chinese cities
    - Windows system locale via locale.getdefaultlocale()

    Returns True by default as a safety measure — the npmmirror.com registry
    works globally (it's a CDN), so using it outside China only adds minimal
    latency, while NOT using it in China would cause npm install to fail or
    take 30+ minutes.
    """
    lang = os.environ.get("LANG", "") + os.environ.get("LC_ALL", "")
    tz = os.environ.get("TZ", "")
    if lang.startswith("zh") or "Shanghai" in tz or "Chongqing" in tz:
        return True
    # Windows: check system locale
    if os.name == "nt":
        try:
            import locale
            loc = locale.getdefaultlocale()[0] or ""
            if loc.startswith("zh"):
                return True
        except Exception:
            pass
    return True  # Default to True for safety — mirror works globally


def _configure_npm_registry(npm_cmd: str, cwd: Path):
    """Ensure project-level .npmrc exists with China mirror.

    Creates a .npmrc file in the backend directory (project-level) rather
    than modifying the user's global npm configuration. This is important
    because:
    - Users may have other projects that need the default registry
    - Global config changes persist after uninstall (unclean)
    - Project-level .npmrc is self-contained and portable

    If file write fails (read-only filesystem), falls back to `npm config set`
    as a last resort.
    """
    npmrc = cwd / ".npmrc"
    if npmrc.exists():
        content = npmrc.read_text(encoding="utf-8", errors="replace")
        # Don't overwrite if user already has a mirror configured
        if "npmmirror" in content or "taobao" in content or "aliyun" in content:
            return  # Already configured

    # Write project-level .npmrc — does not touch user's global npm config
    try:
        npmrc.write_text("registry=https://registry.npmmirror.com\n")
        print("  [OK] .npmrc created (npmmirror.com)")
    except OSError:
        # Fallback: set via npm config (global) if we can't write file
        try:
            subprocess.run(
                [npm_cmd, "config", "set", "registry", "https://registry.npmmirror.com"],
                capture_output=True, timeout=10, cwd=str(cwd), **_subprocess_kwargs(),
            )
            print("  [OK] npm registry set to npmmirror.com")
        except Exception:
            pass


def _subprocess_kwargs():
    """Get platform-specific subprocess kwargs to suppress console window on Windows.

    On Windows, every subprocess.run() or Popen() call creates a visible
    console window by default. For background operations during bootstrap,
    we suppress this to avoid distracting the user.
    """
    kwargs = {}
    if os.name == "nt":
        # Prevent console window flash on Windows
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0  # SW_HIDE
        kwargs["startupinfo"] = si
        kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
    return kwargs


def ensure_bootstrapped(backend_dir: Path, node_cmd: str):
    """Run bootstrap steps if not already done.

    This is the main entry point called from cli.py. It checks for the
    marker file and runs all setup steps if missing.

    Steps (in order):
    1. npm install    — Install Node.js dependencies
    2. .env file      — Generate environment configuration
    3. DB init        — Seed database with default data
    4. Marker file    — Write .khy_quant_bootstrapped
    5. Guide          — Generate getting-started document (best effort)

    Args:
        backend_dir: Path to the backend directory (contains package.json)
        node_cmd: Path to the Node.js binary ("node" or "node.exe")
    """
    marker = backend_dir / MARKER_FILE
    if marker.exists():
        return  # Already bootstrapped — skip everything

    print()
    print("  KHY-Quant first-run setup...")
    print()

    ok = True
    ok = _ensure_npm_install(backend_dir) and ok  # Step 1: npm install
    _ensure_env_file(backend_dir)                  # Step 2: .env generation
    _ensure_db_init(backend_dir, node_cmd)          # Step 3: database seed

    if ok:
        try:
            marker.write_text("bootstrapped\n")
        except OSError:
            pass  # read-only filesystem edge case (Docker, snap, etc.)

    # Step 4: Generate getting-started guide (non-critical)
    _generate_getting_started(backend_dir, node_cmd)

    print()
    print("  Setup complete!")
    print()


def _ensure_npm_install(backend_dir: Path) -> bool:
    """Run npm install if node_modules is missing or critical packages are absent.

    We don't just check if node_modules/ exists — it might be partially
    installed (interrupted download, corrupted cache, etc.). Instead, we
    verify that specific critical packages are present:

    - @aws/codewhisperer-streaming-client: AI provider SDK
    - express: Web server framework

    If any are missing, we run a full `npm install`.

    Args:
        backend_dir: Path to backend/ directory containing package.json

    Returns:
        True if dependencies are ready, False if npm install failed
    """
    node_modules = backend_dir / "node_modules"

    # Check if critical SDK packages exist (not just node_modules directory)
    critical_packages = [
        node_modules / "@aws" / "codewhisperer-streaming-client",
        node_modules / "express",
    ]
    all_critical_present = (
        node_modules.exists()
        and any(node_modules.iterdir())
        and all(p.exists() for p in critical_packages)
    )

    if all_critical_present:
        print("  [OK] Node.js dependencies already installed")
        return True

    if node_modules.exists() and any(node_modules.iterdir()):
        print("  [INFO] Some packages missing, reinstalling...")

    print("  Installing Node.js dependencies...")
    npm_cmd = "npm.cmd" if os.name == "nt" else "npm"

    # Configure npm to use China mirror for reliable downloads
    _configure_npm_registry(npm_cmd, backend_dir)

    try:
        result = subprocess.run(
            [npm_cmd, "install", "--no-audit", "--no-fund"],
            # --no-audit: Skip vulnerability audit (faster, we audit separately)
            # --no-fund: Skip funding messages (cleaner output)
            cwd=str(backend_dir),
            capture_output=True,
            timeout=300,  # 5 minutes — generous for slow networks
            **_subprocess_kwargs(),
        )
        if result.returncode == 0:
            print("  [OK] Node.js dependencies installed")
            return True
        else:
            print(
                "  [WARN] npm install exited with errors. "
                "You may need to run it manually:",
                file=sys.stderr,
            )
            print(f"    cd {backend_dir} && npm install", file=sys.stderr)
            return False
    except FileNotFoundError:
        print(
            f"  [WARN] '{npm_cmd}' not found. Install npm and run:",
            file=sys.stderr,
        )
        print(f"    cd {backend_dir} && npm install", file=sys.stderr)
        return False
    except subprocess.TimeoutExpired:
        print("  [WARN] npm install timed out (5 min)", file=sys.stderr)
        return False


def _ensure_env_file(backend_dir: Path):
    """Generate .env with secure random secrets if it doesn't exist.

    The .env file configures the Node.js backend with:
    - Database type (SQLite default — zero config, or PostgreSQL for production)
    - Server port and environment (development/production)
    - JWT secret for authentication (64-char hex, cryptographically random)
    - Data source toggles (AKShare enabled by default)
    - AI provider API keys (commented out — user fills in what they have)

    Security:
    - JWT_SECRET is generated using Python's `secrets` module (CSPRNG)
    - File permissions are set to 0600 on Unix (owner read/write only)
    - The .env file is excluded from pip wheel and git (via .gitignore)
    """
    env_file = backend_dir / ".env"
    if env_file.exists():
        print("  [OK] .env configuration exists")
        return

    print("  Generating .env configuration...")
    # Generate a 64-character hex string for JWT signing
    # This is cryptographically secure (uses os.urandom internally)
    jwt_secret = secrets.token_hex(32)

    content = (
        "# KHY-Quant Environment Configuration\n"
        f"# Generated by khy-quant bootstrap\n"
        "\n"
        "# Database (sqlite = zero config, postgres = production)\n"
        "DB_TYPE=sqlite\n"
        "\n"
        "# Server\n"
        "PORT=8080\n"
        "NODE_ENV=development\n"
        "LOG_LEVEL=info\n"
        "\n"
        "# Authentication\n"
        f"JWT_SECRET={jwt_secret}\n"
        "JWT_EXPIRES_IN=7d\n"
        "\n"
        "# Data Sources\n"
        "ENABLE_AKSHARE=true\n"
        "ENABLE_TUSHARE=false\n"
        "DEFAULT_DATA_SOURCE=reliable\n"
        "\n"
        "# AI Providers (fill in the ones you have)\n"
        "# GEMINI_API_KEY=\n"
        "# GROQ_API_KEY=\n"
        "# OPENROUTER_API_KEY=\n"
        "# ZHIPU_API_KEY=\n"
    )

    env_file.write_text(content)

    # Restrict permissions on Unix — prevent other users from reading secrets
    if os.name != "nt":
        try:
            os.chmod(str(env_file), 0o600)
        except OSError:
            pass

    print("  [OK] .env generated (secrets auto-generated)")


def _ensure_db_init(backend_dir: Path, node_cmd: str):
    """Run database seed script to create tables and insert default data.

    The seed script (scripts/seed.js) uses Sequelize ORM to:
    - Create all tables if they don't exist (sync)
    - Insert default admin user (admin/admin123)
    - Insert default trading strategies
    - Insert system settings

    The script is idempotent — running it multiple times is safe.
    If the database already exists, it skips creation.
    """
    seed_script = backend_dir / "scripts" / "seed.js"
    if not seed_script.exists():
        return

    print("  Initializing database...")
    try:
        result = subprocess.run(
            [node_cmd, str(seed_script)],
            cwd=str(backend_dir),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=60,
            **_subprocess_kwargs(),
        )
        if result.returncode == 0:
            print("  [OK] Database initialized")
        else:
            print("  [OK] Database ready (may already be initialized)")
    except subprocess.TimeoutExpired:
        print("  [WARN] Database initialization timed out", file=sys.stderr)
    except Exception as e:
        print(f"  [WARN] Database initialization error: {e}", file=sys.stderr)


def _generate_getting_started(backend_dir: Path, node_cmd: str):
    """Generate getting-started guide via Node.js service.

    This creates a GETTING_STARTED.md file in the backend directory with
    environment-specific instructions (detected OS, Node version, available
    AI providers, etc.).

    Best effort — failure here doesn't affect functionality. The guide
    is also regenerated on first REPL start.
    """
    try:
        subprocess.run(
            [node_cmd, "-e",
             "require('./src/services/gettingStartedService').generateGettingStarted()"],
            cwd=str(backend_dir),
            capture_output=True, timeout=15,
            **_subprocess_kwargs(),
        )
    except Exception:
        pass  # Best effort — guide generated on first REPL start anyway
