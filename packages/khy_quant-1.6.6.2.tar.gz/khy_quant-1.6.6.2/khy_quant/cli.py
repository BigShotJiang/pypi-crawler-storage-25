"""
KHY-Quant CLI entry point.

This module serves as the bridge between Python's packaging ecosystem (pip)
and the Node.js backend that powers the actual trading system. It is a thin
"shim" that:

1. Verifies Node.js >= 18 is installed (required by the backend)
2. Locates the bundled backend/ directory (pip-installed or dev mode)
3. Runs first-time bootstrap if needed (npm install, .env, DB init)
4. Transfers control to the Node.js CLI (bin/khyquant.js)

Architecture diagram:

    pip install khy-quant
        |
        v
    khy_quant/cli.py  (this file — Python entry point)
        |
        +-- check_node()        # Ensure Node.js >= 18 available
        +-- get_bundle_dir()    # Find backend/ in package or dev tree
        +-- _bootstrap.py       # First-run: npm install, .env, DB seed
        |
        v
    os.execvpe(node, [khyquant.js, ...args])   # Replace process with Node
        |
        v
    Node.js REPL / Express server / CLI commands

Why Python wraps Node.js:
    - pip install is the most accessible distribution channel
    - Python handles cross-platform Node.js detection and setup
    - The actual trading logic benefits from Node.js's async I/O model
    - Users get a single `pip install khy-quant && khy` experience
"""
import os
import subprocess
import sys
from pathlib import Path

try:
    # Python 3.8+ has importlib.metadata in the standard library
    from importlib import metadata as importlib_metadata
except ImportError:  # pragma: no cover - Python < 3.8 fallback
    import importlib_metadata  # type: ignore


def get_bundle_dir() -> Path:
    """Return the path to the bundled backend/ directory.

    Search order:
    1. Split package: khy-quant-backend (if installed separately)
    2. Pip-installed mode: khy_quant/bundled/backend/ (inside the wheel)
    3. Development mode: ../backend/ (editable install or git clone)

    The backend directory contains:
        - bin/khyquant.js    (CLI entry point)
        - server.js          (Express web server)
        - src/               (application source code)
        - package.json       (Node.js dependencies)
    """
    # Strategy 1: Try the split backend package (for modular installs)
    try:
        from khy_quant_backend.cli import get_bundle_dir as _backend_get
        return _backend_get()
    except ImportError:
        pass

    # Strategy 2: Pip-installed mode — bundled inside the wheel
    # After `pip install khy-quant`, the backend lives at:
    #   site-packages/khy_quant/bundled/backend/
    bundled = Path(__file__).parent / "bundled" / "backend"
    if bundled.exists():
        return bundled

    # Strategy 3: Development / editable mode — sibling directory
    # When running from a git clone with `pip install -e .`:
    #   project_root/khy_quant/cli.py  <- this file
    #   project_root/backend/          <- the backend
    dev = Path(__file__).parent.parent / "backend"
    if dev.exists():
        return dev

    # None found — provide actionable error message
    print("Error: Cannot locate KHY-Quant backend directory.", file=sys.stderr)
    print("  If you installed via pip, the package may be corrupted.", file=sys.stderr)
    print("  Try: pip install --force-reinstall khy-quant", file=sys.stderr)
    sys.exit(1)


def _subprocess_kwargs():
    """Get platform-specific subprocess kwargs to suppress console window on Windows.

    On Windows, spawning a subprocess normally creates a visible console window.
    For background operations (version checks, npm install, etc.) we suppress
    this to avoid visual flicker.
    """
    kwargs = {}
    if os.name == "nt":
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0  # SW_HIDE — invisible window
        kwargs["startupinfo"] = si
        kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
    return kwargs


def check_node() -> str:
    """Check Node.js is installed and >= 18. Return the node binary path.

    Why Node.js 18+:
        - Native fetch() API (used by AI providers)
        - Stable AbortController (used by streaming)
        - ESM improvements for module loading
        - Required by several npm dependencies

    Tries both 'node' and 'node.exe' to handle various PATH configurations.
    On failure, prints platform-specific installation instructions.
    """
    for cmd in ("node", "node.exe"):
        try:
            result = subprocess.run(
                [cmd, "--version"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=10,
                **_subprocess_kwargs(),
            )
            if result.returncode == 0:
                # Parse version: "v22.12.0" -> 22
                version = result.stdout.strip().lstrip("v")
                major = int(version.split(".")[0])
                if major >= 18:
                    return cmd
                print(
                    f"Error: Node.js v{version} found but >= 18 required.",
                    file=sys.stderr,
                )
                _print_node_install_hint()
                sys.exit(1)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue

    print("Error: Node.js not found.", file=sys.stderr)
    print("  KHY-Quant requires Node.js >= 18.", file=sys.stderr)
    _print_node_install_hint()
    sys.exit(1)


def get_installed_version() -> str:
    """Return installed khy-quant package version, or empty string if unknown.

    Used to pass the Python package version to the Node.js backend via
    the KHYQUANT_PKG_VERSION environment variable, so the CLI can display
    it in the REPL prompt and version commands.
    """
    try:
        return importlib_metadata.version("khy-quant")
    except Exception:
        return ""


def _print_node_install_hint():
    """Print platform-specific Node.js install instructions.

    Detects Chinese locale via LANG/LC_ALL/TZ environment variables to
    suggest the npmmirror.com mirror (faster downloads in China).
    """
    # Detect Chinese locale for mirror suggestion
    lang = os.environ.get("LANG", "") + os.environ.get("LC_ALL", "")
    tz = os.environ.get("TZ", "")
    is_china = lang.startswith("zh") or "Shanghai" in tz or "Chongqing" in tz

    if is_china:
        print("  Install from: https://npmmirror.com/mirrors/node/", file=sys.stderr)
    else:
        print("  Install from: https://nodejs.org/", file=sys.stderr)

    # Platform-specific package manager suggestions
    plat = sys.platform
    if plat == "darwin":
        print("  Or: brew install node", file=sys.stderr)
    elif plat.startswith("linux"):
        print("  Or: curl -fsSL https://deb.nodesource.com/setup_22.x | sudo bash -", file=sys.stderr)
    elif plat == "win32":
        print("  Or: winget install OpenJS.NodeJS.LTS", file=sys.stderr)


def main():
    """Entry point registered as console_scripts in pyproject.toml.

    Registered under three names for convenience:
        khy       — shortest, for daily use
        khy-quant — full package name
        khyquant  — no-hyphen variant

    Flow:
        1. check_node()            — verify Node.js >= 18
        2. get_bundle_dir()        — find backend/
        3. ensure_bootstrapped()   — first-run setup (npm, .env, DB)
        4. os.execvpe(node, ...)   — hand off to Node.js CLI

    On Unix, os.execvpe() replaces this Python process entirely with Node.js.
    This is important for:
        - Signal handling (Ctrl+C goes directly to Node's REPL)
        - TTY/stdin passthrough (Node's readline gets the real terminal)
        - Process tree cleanliness (no zombie Python parent)

    On Windows, os.execvpe() is not available, so we use subprocess.run()
    and forward the exit code.
    """
    node = check_node()
    backend_dir = get_bundle_dir()

    # First-run bootstrap (no-op if already done)
    from khy_quant._bootstrap import ensure_bootstrapped
    ensure_bootstrapped(backend_dir, node)

    # Locate the Node.js CLI entry point
    cli_script = backend_dir / "bin" / "khyquant.js"
    if not cli_script.exists():
        print(f"Error: CLI script not found at {cli_script}", file=sys.stderr)
        sys.exit(1)

    # Build the command: node bin/khyquant.js [user args...]
    args = [node, str(cli_script)] + sys.argv[1:]

    # Pass environment variables to the Node.js process
    env = os.environ.copy()
    env["KHYQUANT_ROOT"] = str(backend_dir)  # Backend knows where it lives
    pkg_version = get_installed_version()
    if pkg_version:
        env["KHYQUANT_PKG_VERSION"] = pkg_version  # For version display

    if os.name == "nt":
        # Windows: can't use os.execvpe, use subprocess instead
        # Important: stay in user's CWD (not backend_dir)
        result = subprocess.run(args, env=env)
        sys.exit(result.returncode)
    else:
        # Unix: replace this process entirely with Node.js
        # This gives Node.js direct terminal access for the REPL
        os.execvpe(node, args, env)
