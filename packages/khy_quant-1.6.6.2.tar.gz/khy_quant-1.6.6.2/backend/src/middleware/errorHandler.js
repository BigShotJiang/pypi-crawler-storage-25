module.exports = require('../../../packages/shared/src/middleware/errorHandler');
