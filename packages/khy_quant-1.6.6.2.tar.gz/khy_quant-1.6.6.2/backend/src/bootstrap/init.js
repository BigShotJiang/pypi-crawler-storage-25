/**
 * init() — memoized, once-only process-level initialization.
 *
 * Runs exactly once per process regardless of how many times it is called.
 * Replaces the inline environment setup scattered across khyquant.js and
 * bootstrap.js.
 *
 * Each step is individually try/caught so a single failure does not block
 * the entire initialization pipeline.
 *
 * Usage:
 *   const { init } = require('./init');
 *   await init(); // safe to call multiple times — returns same promise
 */

const path = require('path');
const state = require('./state');
const { checkpoint } = require('./startupProfiler');

let _promise = null;

/**
 * Run all one-time initialization steps.
 * Memoized: first call creates the promise, subsequent calls return it.
 * @returns {Promise<void>}
 */
function init() {
  if (_promise) return _promise;
  _promise = _doInit();
  return _promise;
}

async function _doInit() {
  checkpoint('init:start');

  // 1. Load .env from backend root
  try {
    const envPath = path.resolve(
      process.env.KHYQUANT_ROOT || path.resolve(__dirname, '../..'),
      '.env'
    );
    require('dotenv').config({ path: envPath });
  } catch {
    // dotenv not available or .env missing — proceed with process.env as-is
  }

  // 2. Apply environment defaults (DB_TYPE, PORT, etc.)
  try {
    const { applyEnvDefaults } = require('../config/env');
    applyEnvDefaults();
  } catch {
    // config/env not available — non-critical
  }

  // 3. Ensure KHYQUANT_ROOT is set
  if (!process.env.KHYQUANT_ROOT) {
    process.env.KHYQUANT_ROOT = path.resolve(__dirname, '../..');
  }

  // 4. Register graceful shutdown handlers
  try {
    const { registerShutdownHandlers } = require('./shutdown');
    registerShutdownHandlers();
  } catch {
    // shutdown module not available — non-critical
  }

  // 5. Apply custom CA certificates (must happen before first TLS handshake)
  try {
    if (process.env.NODE_EXTRA_CA_CERTS) {
      const fs = require('fs');
      const certPath = process.env.NODE_EXTRA_CA_CERTS;
      if (fs.existsSync(certPath)) {
        // Node.js respects NODE_EXTRA_CA_CERTS natively; just verify the file
        // exists so we can warn early if it's missing.
      }
    }
  } catch {
    // CA cert check is non-critical
  }

  // 6. Mark as initialized
  state.set('initialized', true);

  checkpoint('init:done');
}

/**
 * Check if init has completed without triggering it.
 */
function isComplete() {
  return state.get('initialized');
}

module.exports = { init, isComplete };
