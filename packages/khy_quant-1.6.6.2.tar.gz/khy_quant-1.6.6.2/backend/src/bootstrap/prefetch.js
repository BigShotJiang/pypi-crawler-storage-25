/**
 * Prefetch Orchestration — parallel startup tasks and deferred background work.
 *
 * parallelPrefetch()  — runs during init/setup phase (before REPL prompt).
 * deferredPrefetch()  — runs after REPL prompt is displayed (user can type).
 *
 * Consolidates the scattered setTimeout chains from repl.js into a single
 * managed module.  Returns timer IDs so they can be cancelled on shutdown.
 *
 * Usage:
 *   const { parallelPrefetch, deferredPrefetch } = require('./prefetch');
 *   await parallelPrefetch({ mode: 'khyquant' });
 *   const timers = deferredPrefetch({ mode: 'khyquant', onOutput, isBusy });
 */

const { checkpoint } = require('./startupProfiler');

/**
 * Run critical prefetch tasks in parallel during startup.
 * Each task is individually error-isolated.
 *
 * @param {{ mode?: string }} options
 */
async function parallelPrefetch(options = {}) {
  const { mode = 'khyquant' } = options;
  checkpoint('prefetch:parallel:start');

  const tasks = [];

  // Hardware profile detection (both modes)
  tasks.push(
    (async () => {
      try {
        const hw = require('../services/hardwareProfileService');
        hw.detectProfile();
      } catch { /* non-critical */ }
    })()
  );

  if (mode === 'khyquant') {
    // Network detector (full mode only)
    tasks.push(
      (async () => {
        try {
          const networkDetector = require('../services/networkDetector');
          await networkDetector.init();
        } catch { /* non-critical */ }
      })()
    );

    // Cache service warmup (full mode only)
    tasks.push(
      (async () => {
        try {
          const cache = require('../services/cacheService');
          await cache.getStats();
        } catch { /* non-critical */ }
      })()
    );
  }

  await Promise.allSettled(tasks);
  checkpoint('prefetch:parallel:done');
}

/**
 * Schedule deferred background tasks after REPL is ready.
 *
 * Returns an array of timer IDs that can be cleared on shutdown:
 *   const timers = deferredPrefetch({ ... });
 *   // on exit: timers.forEach(clearTimeout);
 *
 * @param {{ mode?: string, onOutput?: (msg: string) => void, isBusy?: () => boolean }} options
 * @returns {Array<NodeJS.Timeout>}
 */
function deferredPrefetch(options = {}) {
  const { mode = 'khyquant', onOutput, isBusy } = options;
  const timers = [];
  const busy = () => (typeof isBusy === 'function' ? isBusy() : false);
  const emit = (msg) => {
    if (typeof onOutput === 'function' && !busy()) onOutput(msg);
  };

  if (mode === 'khy') {
    // Lightweight mode: minimal deferred tasks
    timers.push(
      setTimeout(() => {
        try {
          const hw = require('../services/hardwareProfileService');
          hw.applyLimits();
        } catch { /* non-critical */ }
      }, 2000)
    );
    return timers;
  }

  // ── Full mode (khyquant): all deferred tasks ──────────────────────────

  // 2s: Apply hardware-based limits
  timers.push(
    setTimeout(() => {
      try {
        const hw = require('../services/hardwareProfileService');
        const profile = hw.detectProfile();
        hw.applyLimits();
        if (profile.isLightweight) {
          try {
            const chalk = require('chalk');
            emit(chalk.dim(`  ℹ 轻量模式: ${profile.profile} (${profile.memory.totalGB}GB RAM, ${profile.cpu.cores} cores)`));
          } catch { /* chalk not available */ }
        }
      } catch { /* non-critical */ }
    }, 2000)
  );

  // 3s: Data cleanup + periodic cleanup
  timers.push(
    setTimeout(() => {
      try {
        const cleanup = require('../services/cleanupService');
        const result = cleanup.runCleanup();
        cleanup.startPeriodicCleanup();
        if (result.summary && result.summary.actions && result.summary.actions.length > 0) {
          try {
            const chalk = require('chalk');
            emit(chalk.dim(`  ℹ 自动清理: ${result.summary.actions.join(', ')} (释放 ${result.summary.freedHuman})`));
          } catch { /* chalk not available */ }
        }
      } catch { /* non-critical */ }
    }, 3000)
  );

  // 4s: Resource guard memory monitor + project memory prune
  timers.push(
    setTimeout(() => {
      try {
        const { startMemoryMonitor } = require('../services/resourceGuard');
        startMemoryMonitor();
      } catch { /* non-critical */ }
    }, 4000)
  );

  timers.push(
    setTimeout(() => {
      try {
        const { pruneProjects } = require('../services/projectMemoryService');
        pruneProjects();
      } catch { /* non-critical */ }
    }, 4000)
  );

  // 5s: File integrity check + version update notice
  timers.push(
    setTimeout(() => {
      try {
        const integrity = require('../services/fileIntegrityService');
        const ok = integrity.verifyOnStartup();
        if (!ok) {
          try {
            const chalk = require('chalk');
            emit(chalk.red('  ⚠ 文件完整性校验异常 — 部分核心文件已被修改'));
            emit(chalk.dim('    运行 security 命令查看详情'));
          } catch { /* chalk not available */ }
        }
      } catch { /* non-critical */ }
    }, 5000)
  );

  timers.push(
    setTimeout(() => {
      try {
        const { getUpdateNotice } = require('../services/versionService');
        const notice = getUpdateNotice();
        if (notice && !busy()) {
          try {
            const chalk = require('chalk');
            emit(chalk.yellow(`  🔄 ${notice}`));
          } catch { /* chalk not available */ }
        }
      } catch { /* non-critical */ }
    }, 5000)
  );

  // 6s: IDE adapter recovery
  timers.push(
    setTimeout(async () => {
      try {
        const { recoverIdeAdapters, formatRecoveryMessage } = require('../services/versionService');
        const result = await recoverIdeAdapters();
        const msg = formatRecoveryMessage(result);
        if (msg && !busy()) {
          try {
            const chalk = require('chalk');
            emit(chalk.dim(`  ℹ IDE 适配器: ${msg}`));
          } catch { /* chalk not available */ }
        }
      } catch { /* non-critical */ }
    }, 6000)
  );

  // 8s: Skill learning suggestions
  timers.push(
    setTimeout(() => {
      try {
        const { getSuggestedLearning } = require('../services/skillLearningService');
        const suggestions = getSuggestedLearning();
        if (suggestions.length > 0 && !busy()) {
          const s = suggestions[0];
          try {
            const chalk = require('chalk');
            emit('');
            emit(chalk.yellow(`  💡 学习建议: `) + chalk.white(s.name));
            emit(chalk.dim(`     ${s.reason}`));
            emit(chalk.dim(`     → ${s.action}`));
            emit('');
          } catch { /* chalk not available */ }
        }
      } catch { /* non-critical */ }
    }, 8000)
  );

  // Immediate: cloud sync + admin telemetry + security monitor
  setImmediate(() => {
    try {
      const cloudSync = require('../services/cloudSync');
      if (cloudSync.isEnabled()) {
        cloudSync.fetchRemoteConfig().catch(() => {});
        cloudSync.flushTelemetry().catch(() => {});
      }
    } catch { /* non-critical */ }

    try {
      const adminSvc = require('../services/adminService');
      adminSvc.syncTelemetry().catch(() => {});
    } catch { /* non-critical */ }

    try {
      const { startSecurityMonitor } = require('../services/securityGuardService');
      startSecurityMonitor();
    } catch { /* non-critical */ }
  });

  checkpoint('prefetch:deferred:scheduled');
  return timers;
}

module.exports = { parallelPrefetch, deferredPrefetch };
