/**
 * Protocol Format Detection & Constants
 *
 * Supported protocols:
 *   - openai: OpenAI Chat Completions (/v1/chat/completions)
 *   - anthropic: Claude Messages API (/v1/messages)
 *   - gemini: Google Gemini GenerateContent
 *   - grok: Grok (OpenAI-compatible with extensions)
 *   - codex: OpenAI Responses API (/v1/responses)
 */

const PROTOCOLS = {
  OPENAI: 'openai',
  ANTHROPIC: 'anthropic',
  GEMINI: 'gemini',
  GROK: 'grok',
  CODEX: 'codex',
};

/**
 * Auto-detect protocol format from a request body.
 * @param {object} body - Parsed request body
 * @param {string} [path] - Request URL path (optional hint)
 * @returns {string} Detected protocol name
 */
function detectProtocol(body, path = '') {
  // Path-based detection (most reliable)
  if (path.includes('/v1/messages')) return PROTOCOLS.ANTHROPIC;
  if (path.includes(':generateContent') || path.includes(':streamGenerateContent')) return PROTOCOLS.GEMINI;
  if (path.includes('/v1/responses')) return PROTOCOLS.CODEX;

  // Body-based heuristics
  if (body.contents && Array.isArray(body.contents)) return PROTOCOLS.GEMINI;
  if (body.system !== undefined && body.messages && !body.model?.startsWith('grok')) return PROTOCOLS.ANTHROPIC;
  if (body.input && Array.isArray(body.input) && body.instructions !== undefined) return PROTOCOLS.CODEX;
  if (body.model?.startsWith('grok')) return PROTOCOLS.GROK;

  // Default: OpenAI format (most common)
  return PROTOCOLS.OPENAI;
}

/**
 * Get list of all supported protocols.
 * @returns {string[]}
 */
function getSupportedProtocols() {
  return Object.values(PROTOCOLS);
}

module.exports = { PROTOCOLS, detectProtocol, getSupportedProtocols };
