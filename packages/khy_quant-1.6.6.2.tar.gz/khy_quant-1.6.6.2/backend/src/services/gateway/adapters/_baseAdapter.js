/**
 * Base Adapter — optional base class for AI gateway adapters.
 *
 * Provides standardized response formatting and common utilities.
 * Existing adapters continue to work via duck typing — this base class
 * is opt-in for new adapters and can be incrementally adopted.
 *
 * Duck-typing contract (what aiGateway.js expects):
 *   - detect([forceRefresh]) → boolean
 *   - generate(prompt, options) → { success, content, provider, model?, tokenUsage? }
 *   - name (string property)
 */

class BaseAdapter {
  /**
   * @param {object} config
   * @param {string} config.name - Adapter display name
   * @param {string} config.type - Adapter type (e.g., 'ide', 'api', 'local', 'relay')
   * @param {number} [config.priority=99] - Lower = higher priority in cascade
   */
  constructor({ name, type, priority } = {}) {
    if (!name) throw new Error('BaseAdapter: name is required');
    this.name = name;
    this.type = type || 'unknown';
    this.priority = priority || 99;
    this._available = false;
    this._lastCheck = 0;
    this._cacheTTL = 30000; // 30s detection cache
    this.activeModel = null;
  }

  /**
   * Detect whether this adapter is available.
   * Subclasses MUST override this method.
   *
   * @param {boolean} [forceRefresh=false] - Bypass cache
   * @returns {boolean}
   */
  detect(forceRefresh = false) {
    // Use cached value if fresh enough
    if (!forceRefresh && Date.now() - this._lastCheck < this._cacheTTL) {
      return this._available;
    }

    this._available = this._doDetect();
    this._lastCheck = Date.now();
    return this._available;
  }

  /**
   * Internal detection logic. Override in subclasses.
   * @returns {boolean}
   */
  _doDetect() {
    return false;
  }

  /**
   * Generate a response from the AI model.
   * Subclasses MUST override this method.
   *
   * @param {string} prompt - The prompt/conversation text
   * @param {object} [options] - Generation options
   * @param {number} [options.temperature]
   * @param {number} [options.maxTokens]
   * @param {function} [options.onChunk] - Streaming callback
   * @param {string} [options.system] - System prompt
   * @param {Array} [options.messages] - Structured messages
   * @returns {Promise<{ success: boolean, content?: string, error?: string, provider?: string, model?: string, tokenUsage?: object }>}
   */
  async generate(prompt, options = {}) {
    throw new Error(`${this.name}: generate() not implemented`);
  }

  /**
   * List available models (optional, not all adapters support this).
   * @returns {Promise<Array<{id: string, name: string}>>}
   */
  async listModels() {
    return [];
  }

  /**
   * Format a successful response.
   *
   * @param {string} content - Response text
   * @param {object} [meta] - Additional metadata
   * @returns {{ success: true, content, provider, model?, tokenUsage?, adapter? }}
   */
  _successResponse(content, meta = {}) {
    return {
      success: true,
      content,
      provider: this.name,
      adapter: this.name,
      model: meta.model || this.activeModel || undefined,
      tokenUsage: meta.tokenUsage || undefined,
      ...meta,
    };
  }

  /**
   * Format a failure response.
   *
   * @param {string|Error} error - Error message or Error object
   * @param {object} [meta] - Additional metadata
   * @returns {{ success: false, error, provider, statusCode? }}
   */
  _failureResponse(error, meta = {}) {
    return {
      success: false,
      error: error instanceof Error ? error.message : String(error),
      provider: this.name,
      adapter: this.name,
      statusCode: meta.statusCode || undefined,
      ...meta,
    };
  }

  /**
   * Get adapter status for display.
   * @returns {{ name, type, available, activeModel }}
   */
  getStatus() {
    return {
      name: this.name,
      type: this.type,
      available: this._available,
      activeModel: this.activeModel,
    };
  }
}

module.exports = BaseAdapter;
