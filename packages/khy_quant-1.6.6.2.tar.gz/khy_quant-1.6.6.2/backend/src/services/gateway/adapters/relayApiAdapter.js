/**
 * Relay API Adapter — connect to third-party OpenAI-compatible Claude API relays.
 *
 * Supports:
 * - AWS Bedrock relay (Lambda/API Gateway)
 * - Third-party relay stations (OpenAI-SB, API2D, OhMyGPT, etc.)
 * - Self-hosted VPS reverse proxy (Nginx, Caddy)
 * - Cloudflare Workers proxy
 *
 * Config via environment variables:
 *   RELAY_API_ENDPOINT=https://your-relay.com/v1
 *   RELAY_API_KEY=sk-xxx
 *   RELAY_API_MODEL=claude-sonnet-4-20250514
 */
const https = require('https');
const http = require('http');
const { URL } = require('url');

const DEFAULT_MODEL = 'claude-sonnet-4-20250514';
const TIMEOUT_MS = 120_000;

let _available = null;

// ── Config helpers ──

function getConfig() {
  return {
    endpoint: process.env.RELAY_API_ENDPOINT || '',
    key: process.env.RELAY_API_KEY || '',
    model: process.env.RELAY_API_MODEL || DEFAULT_MODEL,
  };
}

// ── HTTP request with optional proxy support ──

function makeRequest(url, { method = 'POST', headers = {}, body, timeout = TIMEOUT_MS } = {}) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const mod = parsed.protocol === 'https:' ? https : http;

    // Check for proxy environment variables
    const proxyUrl = process.env.https_proxy || process.env.HTTPS_PROXY ||
                     process.env.http_proxy || process.env.HTTP_PROXY;

    // TLS Sidecar: route through sidecar for configured target domains
    let effectiveProxy = proxyUrl;
    try {
      const sidecar = require('../tlsSidecar');
      if (sidecar.shouldProxy(parsed.hostname)) {
        effectiveProxy = sidecar.getProxyUrl();
      }
    } catch { /* sidecar not available */ }

    let options = {
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method,
      headers,
      timeout,
    };

    // If proxy is configured, route through it
    if (effectiveProxy && parsed.protocol === 'https:') {
      try {
        const proxy = new URL(effectiveProxy);
        // CONNECT tunnel via proxy
        const connectReq = http.request({
          hostname: proxy.hostname,
          port: proxy.port || 80,
          method: 'CONNECT',
          path: `${parsed.hostname}:${parsed.port || 443}`,
          timeout,
        });
        connectReq.on('connect', (res, socket) => {
          if (res.statusCode !== 200) {
            reject(new Error(`Proxy CONNECT failed: ${res.statusCode}`));
            return;
          }
          const tunnelOptions = {
            ...options,
            socket,
            agent: false,
          };
          const req = https.request(tunnelOptions, handleResponse(resolve, reject));
          req.on('error', reject);
          req.on('timeout', () => { req.destroy(); reject(new Error('request timeout')); });
          if (body) req.write(typeof body === 'string' ? body : JSON.stringify(body));
          req.end();
        });
        connectReq.on('error', reject);
        connectReq.on('timeout', () => { connectReq.destroy(); reject(new Error('proxy timeout')); });
        connectReq.end();
        return;
      } catch { /* fall through to direct request */ }
    }

    const req = mod.request(options, handleResponse(resolve, reject));
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('request timeout')); });
    if (body) req.write(typeof body === 'string' ? body : JSON.stringify(body));
    req.end();
  });
}

function handleResponse(resolve, reject) {
  return (res) => {
    // For streaming: return the response object directly
    if (res.headers['content-type']?.includes('text/event-stream')) {
      resolve({ status: res.statusCode, stream: res, headers: res.headers });
      return;
    }
    let data = '';
    res.on('data', chunk => { data += chunk; });
    res.on('end', () => {
      try { resolve({ status: res.statusCode, data: JSON.parse(data), headers: res.headers }); }
      catch { resolve({ status: res.statusCode, data, headers: res.headers }); }
    });
    res.on('error', reject);
  };
}

// ── SSE stream parser ──

function parseSSEStream(stream, onChunk) {
  return new Promise((resolve, reject) => {
    let content = '';
    let model = null;
    let buffer = '';

    stream.on('data', (chunk) => {
      buffer += chunk.toString();
      const lines = buffer.split('\n');
      buffer = lines.pop() || ''; // keep incomplete line in buffer

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const payload = line.slice(6).trim();
          if (payload === '[DONE]') continue;
          try {
            const obj = JSON.parse(payload);
            // OpenAI format
            const delta = obj.choices?.[0]?.delta;
            if (delta?.content) {
              content += delta.content;
              if (onChunk) onChunk({ type: 'text', text: delta.content });
            }
            // Anthropic format (some relays use this)
            if (obj.type === 'content_block_delta' && obj.delta?.text) {
              content += obj.delta.text;
              if (onChunk) onChunk({ type: 'text', text: obj.delta.text });
            }
            // Thinking content
            if (delta?.reasoning_content || delta?.thinking) {
              const text = delta.reasoning_content || delta.thinking;
              if (onChunk) onChunk({ type: 'thinking', text });
            }
            if (obj.model) model = obj.model;
          } catch { /* skip malformed SSE */ }
        }
      }
    });

    stream.on('end', () => resolve({ content, model }));
    stream.on('error', reject);
  });
}

// ── Adapter interface ──

function detect(forceRefresh = false) {
  if (_available !== null && !forceRefresh) return _available;
  const cfg = getConfig();
  _available = !!(cfg.endpoint && cfg.key);
  return _available;
}

async function generate(prompt, options = {}) {
  const cfg = getConfig();
  // Support external key/endpoint override (from apiKeyPool)
  const activeKey = options.apiKey || cfg.key;
  const activeEndpoint = options.apiEndpoint || cfg.endpoint;

  if (!activeEndpoint || !activeKey) {
    return {
      success: false, content: '', provider: 'Relay API', adapter: 'relay_api',
      error: 'RELAY_API_ENDPOINT and RELAY_API_KEY not configured',
      attempts: [{ provider: 'Relay API', success: false, error: 'not_configured' }],
    };
  }

  const model = options.model || cfg.model;
  const endpoint = activeEndpoint.replace(/\/+$/, '');
  const url = `${endpoint}/chat/completions`;
  const useStream = !!(options.onChunk);

  // Build messages: use structured messages if provided, else wrap prompt
  let messages;
  if (options.messages && options.messages.length > 0) {
    messages = options.messages.map(m => ({ role: m.role, content: m.content }));
    // Prepend system message if provided
    if (options.system) {
      messages = [{ role: 'system', content: options.system }, ...messages];
    }
  } else {
    messages = [{ role: 'user', content: prompt }];
    if (options.system) {
      messages = [{ role: 'system', content: options.system }, ...messages];
    }
  }

  const body = {
    model,
    messages,
    stream: useStream,
    temperature: options.temperature ?? 0.3,
    max_tokens: options.maxTokens ?? 2048,
  };

  try {
    const res = await makeRequest(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${activeKey}`,
        'Accept': useStream ? 'text/event-stream' : 'application/json',
      },
      body,
    });

    if (res.status !== 200 && !res.stream) {
      const errMsg = res.data?.error?.message || res.data?.message || `HTTP ${res.status}`;
      return {
        success: false, content: '', provider: 'Relay API', adapter: 'relay_api',
        error: errMsg, statusCode: res.status, headers: res.headers || null,
        attempts: [{ provider: `Relay API (${model})`, success: false, error: errMsg, statusCode: res.status }],
      };
    }

    // Streaming response
    if (res.stream) {
      const { content, model: usedModel } = await parseSSEStream(res.stream, options.onChunk);
      const displayModel = usedModel || model;
      return {
        success: true,
        content: content.trim(),
        provider: `Relay (${displayModel})`,
        adapter: 'relay_api',
        model: displayModel,
        attempts: [{ provider: `Relay API (${displayModel})`, success: true }],
      };
    }

    // Non-streaming response
    const data = res.data;
    const content = data.choices?.[0]?.message?.content ||
                    data.content?.[0]?.text || // Anthropic format
                    '';
    const usedModel = data.model || model;

    if (!content) {
      return {
        success: false, content: '', provider: 'Relay API', adapter: 'relay_api',
        error: 'Empty response',
        attempts: [{ provider: `Relay API (${usedModel})`, success: false, error: 'empty_response' }],
      };
    }

    return {
      success: true,
      content: content.trim(),
      provider: `Relay (${usedModel})`,
      adapter: 'relay_api',
      model: usedModel,
      tokenUsage: data.usage ? {
        inputTokens: data.usage.prompt_tokens,
        outputTokens: data.usage.completion_tokens,
        totalTokens: data.usage.total_tokens,
      } : null,
      attempts: [{ provider: `Relay API (${usedModel})`, success: true }],
    };
  } catch (err) {
    return {
      success: false, content: '', provider: 'Relay API', adapter: 'relay_api',
      error: err.message,
      attempts: [{ provider: `Relay API (${model})`, success: false, error: err.message }],
    };
  }
}

function getStatus() {
  detect();
  const cfg = getConfig();
  let detail;
  if (_available) {
    const endpoint = cfg.endpoint.replace(/\/+$/, '');
    const host = (() => { try { return new URL(endpoint).hostname; } catch { return endpoint; } })();
    detail = `已配置 → ${host} (${cfg.model})`;
  } else {
    detail = '未配置 — 运行 gateway config 设置中转地址和密钥';
  }
  return { name: 'API 中转', type: 'relay_api', available: _available, detail };
}

function destroy() {
  _available = null;
}

module.exports = { detect, generate, getStatus, destroy };
