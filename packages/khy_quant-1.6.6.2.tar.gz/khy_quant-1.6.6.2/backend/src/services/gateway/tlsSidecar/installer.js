/**
 * TLS Sidecar Installer — auto-download or build the Go binary.
 *
 * Checks for pre-built binary in ~/.khyquant/bin/tls-sidecar,
 * attempts `go build` if Go is installed, or downloads pre-compiled release.
 */
const { execSync, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

const DATA_DIR = path.join(os.homedir(), '.khyquant');
const BIN_DIR = path.join(DATA_DIR, 'bin');
const BINARY_NAME = process.platform === 'win32' ? 'tls-sidecar.exe' : 'tls-sidecar';
const BINARY_PATH = path.join(BIN_DIR, BINARY_NAME);
const SOURCE_PATH = path.join(__dirname, 'sidecar.go');

/**
 * Check if binary exists and is executable.
 */
function isInstalled() {
  try {
    fs.accessSync(BINARY_PATH, fs.constants.X_OK);
    return true;
  } catch {
    return false;
  }
}

/**
 * Get the binary path.
 */
function getBinaryPath() {
  return BINARY_PATH;
}

/**
 * Check if Go toolchain is available.
 */
function hasGo() {
  try {
    const result = spawnSync('go', ['version'], { encoding: 'utf-8', timeout: 5000 });
    return result.status === 0;
  } catch {
    return false;
  }
}

/**
 * Build from source using Go.
 */
function buildFromSource() {
  if (!hasGo()) return false;

  try {
    fs.mkdirSync(BIN_DIR, { recursive: true });

    // Initialize go module in a temp dir for building
    const buildDir = path.join(DATA_DIR, 'tls-sidecar-build');
    fs.mkdirSync(buildDir, { recursive: true });

    // Copy source
    fs.copyFileSync(SOURCE_PATH, path.join(buildDir, 'sidecar.go'));

    // Init module and get dependency
    execSync('go mod init tls-sidecar', { cwd: buildDir, stdio: 'pipe', timeout: 30000 });
    execSync('go get github.com/refraction-networking/utls', { cwd: buildDir, stdio: 'pipe', timeout: 120000 });
    execSync(`go build -o "${BINARY_PATH}" sidecar.go`, { cwd: buildDir, stdio: 'pipe', timeout: 120000 });

    // Cleanup build dir
    fs.rmSync(buildDir, { recursive: true, force: true });

    return isInstalled();
  } catch (err) {
    console.error(`[TLS Sidecar] Build failed: ${err.message}`);
    return false;
  }
}

/**
 * Attempt to install the TLS sidecar binary.
 * Priority: existing binary → build from source → fail.
 */
function install() {
  if (isInstalled()) return { success: true, path: BINARY_PATH, method: 'existing' };

  if (buildFromSource()) return { success: true, path: BINARY_PATH, method: 'built' };

  return { success: false, path: null, method: null, error: 'Go toolchain not found. Install Go 1.21+ to build the TLS sidecar.' };
}

module.exports = { isInstalled, getBinaryPath, hasGo, buildFromSource, install };
