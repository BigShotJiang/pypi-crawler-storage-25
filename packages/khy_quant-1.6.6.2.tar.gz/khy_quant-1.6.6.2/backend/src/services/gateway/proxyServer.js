/**
 * Reverse Proxy Server — unified OpenAI-compatible API endpoint
 * that routes requests to IDE adapters (Kiro, Cursor, Claude, Codex).
 *
 * Endpoints:
 *   POST /v1/chat/completions  — OpenAI-compatible chat (stream/non-stream)
 *   POST /v1/messages          — Anthropic-compatible messages
 *   GET  /v1/models            — Aggregated model list from all IDEs
 *   GET  /health               — Health check
 *   GET  /pool/stats           — Account pool statistics
 */
const http = require('http');
const crypto = require('crypto');
const protocolConverter = require('./protocolConverter');
const { PROTOCOLS } = protocolConverter;

let _server = null;
let _gateway = null;

function getGateway() {
  if (!_gateway) _gateway = require('./aiGateway');
  return _gateway;
}

const IDE_ADAPTERS = ['kiro', 'cursor', 'claude', 'codex', 'trae', 'warp', 'windsurf', 'vscode'];

/**
 * Strip real IP headers from outgoing requests to prevent IP leaking.
 * Called before forwarding to IDE adapters.
 */
function sanitizeIpHeaders() {
  // Set fake forwarded headers to mask real IP
  const fakeIp = `10.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
  return {
    'X-Forwarded-For': fakeIp,
    'X-Real-IP': fakeIp,
    'CF-Connecting-IP': fakeIp,
    'True-Client-IP': fakeIp,
  };
}

/**
 * Parse request body as JSON.
 */
function parseBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => { data += chunk; });
    req.on('end', () => {
      try { resolve(JSON.parse(data)); }
      catch { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

/**
 * Send JSON response.
 */
function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': process.env.PROXY_CORS_ORIGINS || '*',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

/**
 * Route model ID to adapter key.
 * Format: "kiro/claude-sonnet-4" → { adapterKey: 'kiro', modelId: 'claude-sonnet-4' }
 * Fallback: "gpt-4o" → { adapterKey: null, modelId: 'gpt-4o' }
 */
function parseModel(model) {
  if (!model) return { adapterKey: null, modelId: null };
  const slash = model.indexOf('/');
  if (slash > 0) {
    const prefix = model.slice(0, slash).toLowerCase();
    if (IDE_ADAPTERS.includes(prefix)) {
      return { adapterKey: prefix, modelId: model.slice(slash + 1) };
    }
  }
  return { adapterKey: null, modelId: model };
}

/**
 * Handle POST /v1/chat/completions
 */
async function handleChatCompletions(req, res) {
  const body = await parseBody(req);
  const { messages: rawMsgs, model, stream } = body;

  if (!rawMsgs?.length) return sendJson(res, 400, { error: { message: 'messages required' } });

  // Extract system prompt and convert to flat prompt
  let system;
  const messages = [];
  for (const m of rawMsgs) {
    if (m.role === 'system') { system = m.content; continue; }
    messages.push(m);
  }

  const prompt = [
    system ? `System: ${system}` : '',
    ...messages.map(m => `${m.role}: ${m.content}`),
  ].filter(Boolean).join('\n');

  const { adapterKey, modelId } = parseModel(model);
  const gw = getGateway();
  if (!gw._initialized) await gw.init();

  if (stream) {
    // SSE streaming response
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': process.env.PROXY_CORS_ORIGINS || '*',
    });

    const responseId = `chatcmpl-${crypto.randomUUID()}`;
    const created = Math.floor(Date.now() / 1000);

    const sendSSE = (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);

    try {
      const result = adapterKey
        ? await gw.generateWithAdapter(adapterKey, prompt, {
          model: modelId,
          onChunk: (chunk) => {
            if (chunk.type === 'text') {
              sendSSE({
                id: responseId, object: 'chat.completion.chunk', created,
                model: model || 'default',
                choices: [{ index: 0, delta: { content: chunk.text }, finish_reason: null }],
              });
            }
          },
        })
        : await gw.generate(prompt, {
          onChunk: (chunk) => {
            if (chunk.type === 'text') {
              sendSSE({
                id: responseId, object: 'chat.completion.chunk', created,
                model: model || 'default',
                choices: [{ index: 0, delta: { content: chunk.text }, finish_reason: null }],
              });
            }
          },
        });

      sendSSE({
        id: responseId, object: 'chat.completion.chunk', created,
        model: model || 'default',
        choices: [{ index: 0, delta: {}, finish_reason: 'stop' }],
      });
      res.write('data: [DONE]\n\n');
      res.end();
    } catch (err) {
      res.write(`data: ${JSON.stringify({ error: { message: err.message } })}\n\n`);
      res.end();
    }
  } else {
    // Non-streaming
    try {
      const result = adapterKey
        ? await gw.generateWithAdapter(adapterKey, prompt, { model: modelId })
        : await gw.generate(prompt);

      if (!result.success) {
        return sendJson(res, 500, { error: { message: 'Generation failed' } });
      }

      sendJson(res, 200, {
        id: `chatcmpl-${crypto.randomUUID()}`,
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        model: model || 'default',
        choices: [{ index: 0, message: { role: 'assistant', content: result.content }, finish_reason: 'stop' }],
        usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 },
      });
    } catch (err) {
      sendJson(res, 500, { error: { message: err.message } });
    }
  }
}

/**
 * Handle multi-protocol requests — converts input protocol to canonical,
 * generates via gateway, then converts response back to source protocol.
 */
async function handleMultiProtocol(req, res, sourceProtocol) {
  const body = await parseBody(req);
  const { canonical, detectedProtocol } = protocolConverter.convertRequest(body, sourceProtocol);

  // Build flat prompt from canonical messages
  const prompt = [
    canonical.system ? `System: ${canonical.system}` : '',
    ...canonical.messages.map(m => {
      const text = typeof m.content === 'string' ? m.content : (Array.isArray(m.content) ? m.content.map(b => b.text || '').join('') : '');
      return `${m.role}: ${text}`;
    }),
  ].filter(Boolean).join('\n');

  const gw = getGateway();
  if (!gw._initialized) await gw.init();

  const outputProtocol = detectedProtocol;

  if (canonical.metadata.stream) {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': process.env.PROXY_CORS_ORIGINS || '*',
    });

    let fullContent = '';
    try {
      await gw.generate(prompt, {
        onChunk: (chunk) => {
          if (chunk.type === 'text') {
            fullContent += chunk.text;
            res.write(`data: ${JSON.stringify({ type: 'content_block_delta', delta: { text: chunk.text } })}\n\n`);
          }
        },
      });

      // Build canonical response and convert to output protocol
      const canonicalResp = { id: `msg_${crypto.randomUUID()}`, model: canonical.model || 'default', content: fullContent, thinking: null, toolCalls: null, stopReason: 'end_turn', usage: { inputTokens: 0, outputTokens: 0, totalTokens: 0 } };
      const formatted = protocolConverter.convertResponse(canonicalResp, outputProtocol);
      res.write(`data: ${JSON.stringify(formatted)}\n\n`);
      res.write('data: [DONE]\n\n');
      res.end();
    } catch (err) {
      res.write(`data: ${JSON.stringify({ error: { message: err.message } })}\n\n`);
      res.end();
    }
  } else {
    try {
      const result = await gw.generate(prompt);
      if (!result.success) {
        return sendJson(res, 500, { error: { message: 'Generation failed' } });
      }

      const canonicalResp = { id: `msg_${crypto.randomUUID()}`, model: canonical.model || 'default', content: result.content, thinking: null, toolCalls: null, stopReason: 'end_turn', usage: { inputTokens: 0, outputTokens: 0, totalTokens: 0 } };
      const formatted = protocolConverter.convertResponse(canonicalResp, outputProtocol);
      sendJson(res, 200, formatted);
    } catch (err) {
      sendJson(res, 500, { error: { message: err.message } });
    }
  }
}

/**
 * Handle GET /v1/models — aggregate from all IDE adapters
 */
async function handleListModels(req, res) {
  const gw = getGateway();
  if (!gw._initialized) await gw.init();

  const allModels = [];

  for (const key of IDE_ADAPTERS) {
    try {
      const models = await gw.listModels(key);
      for (const m of models) {
        allModels.push({
          id: `${key}/${m.id}`,
          object: 'model',
          created: Math.floor(Date.now() / 1000),
          owned_by: key,
          name: m.name || m.id,
          description: m.description || '',
          is_default: m.isDefault || false,
        });
      }
    } catch { /* adapter not available */ }
  }

  sendJson(res, 200, { object: 'list', data: allModels });
}

/**
 * Start the proxy server.
 */
function start(port) {
  return new Promise((resolve, reject) => {
    if (_server) {
      reject(new Error('Proxy server already running'));
      return;
    }

    const listenPort = port || parseInt(process.env.PROXY_PORT, 10) || 9100;
    const authToken = process.env.PROXY_AUTH_TOKEN;

    _server = http.createServer(async (req, res) => {
      // CORS preflight
      if (req.method === 'OPTIONS') {
        res.writeHead(204, {
          'Access-Control-Allow-Origin': process.env.PROXY_CORS_ORIGINS || '*',
          'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization',
          'Access-Control-Max-Age': '86400',
        });
        return res.end();
      }

      // Auth check (optional)
      if (authToken) {
        const auth = req.headers.authorization;
        if (!auth || auth !== `Bearer ${authToken}`) {
          return sendJson(res, 401, { error: { message: 'Unauthorized' } });
        }
      }

      // Strip real client IP from incoming request before processing
      delete req.headers['x-forwarded-for'];
      delete req.headers['x-real-ip'];
      delete req.headers['cf-connecting-ip'];
      delete req.headers['true-client-ip'];

      const url = new URL(req.url, `http://localhost:${listenPort}`);
      const pathname = url.pathname;

      try {
        if (req.method === 'POST' && pathname === '/v1/chat/completions') {
          await handleChatCompletions(req, res);
        } else if (req.method === 'POST' && pathname === '/v1/messages') {
          await handleMultiProtocol(req, res, PROTOCOLS.ANTHROPIC);
        } else if (req.method === 'POST' && pathname.match(/^\/v1beta\/models\/[^/]+:generateContent$/)) {
          await handleMultiProtocol(req, res, PROTOCOLS.GEMINI);
        } else if (req.method === 'POST' && pathname === '/v1/responses') {
          await handleMultiProtocol(req, res, PROTOCOLS.CODEX);
        } else if (req.method === 'GET' && pathname === '/v1/models') {
          await handleListModels(req, res);
        } else if (req.method === 'GET' && pathname === '/health') {
          sendJson(res, 200, { status: 'ok', adapters: IDE_ADAPTERS, protocols: protocolConverter.getSupportedProtocols() });
        } else {
          sendJson(res, 404, { error: { message: 'Not found' } });
        }
      } catch (err) {
        sendJson(res, 500, { error: { message: err.message } });
      }
    });

    _server.listen(listenPort, () => resolve(listenPort));
    _server.on('error', reject);
  });
}

/**
 * Stop the proxy server.
 */
function stop() {
  return new Promise((resolve) => {
    if (!_server) { resolve(); return; }
    _server.close(() => { _server = null; resolve(); });
  });
}

function isRunning() { return !!_server; }

function getPort() {
  return parseInt(process.env.PROXY_PORT, 10) || 9100;
}

module.exports = { start, stop, isRunning, getPort };
