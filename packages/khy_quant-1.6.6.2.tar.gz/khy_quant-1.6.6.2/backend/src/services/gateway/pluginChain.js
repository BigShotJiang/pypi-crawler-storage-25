/**
 * Plugin Chain — responsibility chain for AI gateway lifecycle hooks.
 *
 * Plugins are loaded from ~/.khyquant/gateway_plugins/ directory.
 * Each plugin exports hooks: onBeforeRequest, onAfterResponse, onError, onStream.
 *
 * Example plugin:
 *   module.exports = {
 *     name: 'example',
 *     priority: 100,
 *     hooks: {
 *       onBeforeRequest: async (ctx, next) => next(ctx),
 *       onAfterResponse: async (ctx, next) => next(ctx),
 *       onError: async (ctx, next) => next(ctx),
 *       onStream: (chunk, ctx) => chunk,
 *     },
 *   };
 */
const fs = require('fs');
const path = require('path');
const os = require('os');

const PLUGINS_DIR = process.env.GATEWAY_PLUGINS_DIR
  ? path.resolve(process.env.GATEWAY_PLUGINS_DIR.replace(/^~/, os.homedir()))
  : path.join(os.homedir(), '.khyquant', 'gateway_plugins');

const ENABLED = process.env.GATEWAY_PLUGINS_ENABLED !== 'false';

let _plugins = [];
let _loaded = false;

/**
 * Load all plugins from disk, sorted by priority (descending).
 */
function loadPlugins() {
  _plugins = [];
  _loaded = true;

  if (!ENABLED) return;

  try {
    if (!fs.existsSync(PLUGINS_DIR)) {
      fs.mkdirSync(PLUGINS_DIR, { recursive: true });
      return;
    }

    const files = fs.readdirSync(PLUGINS_DIR).filter(f => {
      // Security: only allow simple .js filenames (no path traversal)
      if (!f.endsWith('.js')) return false;
      if (f.includes('/') || f.includes('\\') || f.includes('..')) return false;
      if (f.startsWith('.')) return false;
      return /^[a-zA-Z0-9_\-]+\.js$/.test(f);
    });

    for (const file of files) {
      try {
        const pluginPath = path.join(PLUGINS_DIR, file);
        // Clear require cache for hot-reload
        delete require.cache[require.resolve(pluginPath)];
        const plugin = require(pluginPath);

        if (!plugin.name) plugin.name = path.basename(file, '.js');
        if (!plugin.priority) plugin.priority = 0;
        if (!plugin.hooks) plugin.hooks = {};
        plugin._enabled = plugin.enabled !== false;
        plugin._file = file;

        _plugins.push(plugin);
      } catch (err) {
        console.error(`[PluginChain] Failed to load ${file}: ${err.message}`);
      }
    }

    // Sort by priority descending (higher priority runs first)
    _plugins.sort((a, b) => (b.priority || 0) - (a.priority || 0));
  } catch (err) {
    console.error(`[PluginChain] Error reading plugins dir: ${err.message}`);
  }
}

/**
 * Reload all plugins from disk.
 */
function reload() {
  _loaded = false;
  loadPlugins();
  return _plugins.length;
}

/**
 * Get list of loaded plugins.
 */
function list() {
  if (!_loaded) loadPlugins();
  return _plugins.map(p => ({
    name: p.name,
    priority: p.priority,
    enabled: p._enabled,
    file: p._file,
    hooks: Object.keys(p.hooks || {}),
  }));
}

/**
 * Enable or disable a plugin by name.
 */
function toggle(name, enabled) {
  if (!_loaded) loadPlugins();
  const plugin = _plugins.find(p => p.name === name);
  if (!plugin) return false;
  plugin._enabled = enabled;
  return true;
}

/**
 * Execute onBeforeRequest chain.
 * @param {object} ctx - { prompt, options, adapter, cancelled }
 * @returns {Promise<object>} Modified ctx (or ctx.cancelled = true to abort)
 */
async function executeBeforeRequest(ctx) {
  if (!_loaded) loadPlugins();
  if (!ENABLED) return ctx;

  const chain = _plugins.filter(p => p._enabled && p.hooks?.onBeforeRequest);

  for (const plugin of chain) {
    try {
      ctx = await plugin.hooks.onBeforeRequest(ctx, async (c) => c);
      if (ctx.cancelled) break;
    } catch (err) {
      console.error(`[PluginChain] ${plugin.name}.onBeforeRequest error: ${err.message}`);
    }
  }

  return ctx;
}

/**
 * Execute onAfterResponse chain.
 * @param {object} ctx - { prompt, options, response, adapter }
 * @returns {Promise<object>} Modified ctx
 */
async function executeAfterResponse(ctx) {
  if (!_loaded) loadPlugins();
  if (!ENABLED) return ctx;

  const chain = _plugins.filter(p => p._enabled && p.hooks?.onAfterResponse);

  for (const plugin of chain) {
    try {
      ctx = await plugin.hooks.onAfterResponse(ctx, async (c) => c);
    } catch (err) {
      console.error(`[PluginChain] ${plugin.name}.onAfterResponse error: ${err.message}`);
    }
  }

  return ctx;
}

/**
 * Execute onError chain.
 * @param {object} ctx - { prompt, options, error, adapter, retry }
 * @returns {Promise<object>} Modified ctx (ctx.retry = true to retry)
 */
async function executeOnError(ctx) {
  if (!_loaded) loadPlugins();
  if (!ENABLED) return ctx;

  const chain = _plugins.filter(p => p._enabled && p.hooks?.onError);

  for (const plugin of chain) {
    try {
      ctx = await plugin.hooks.onError(ctx, async (c) => c);
    } catch (err) {
      console.error(`[PluginChain] ${plugin.name}.onError error: ${err.message}`);
    }
  }

  return ctx;
}

/**
 * Execute onStream filter — synchronous, returns modified chunk or null to suppress.
 * @param {object} chunk - Stream chunk
 * @param {object} ctx - { adapter, options }
 * @returns {object|null} Modified chunk or null
 */
function executeOnStream(chunk, ctx) {
  if (!_loaded) loadPlugins();
  if (!ENABLED) return chunk;

  const chain = _plugins.filter(p => p._enabled && p.hooks?.onStream);

  let result = chunk;
  for (const plugin of chain) {
    try {
      result = plugin.hooks.onStream(result, ctx);
      if (result === null) return null; // suppress chunk
    } catch (err) {
      console.error(`[PluginChain] ${plugin.name}.onStream error: ${err.message}`);
    }
  }

  return result;
}

/**
 * Get the plugins directory path.
 */
function getPluginsDir() {
  return PLUGINS_DIR;
}

module.exports = {
  loadPlugins,
  reload,
  list,
  toggle,
  executeBeforeRequest,
  executeAfterResponse,
  executeOnError,
  executeOnStream,
  getPluginsDir,
  ENABLED,
};
