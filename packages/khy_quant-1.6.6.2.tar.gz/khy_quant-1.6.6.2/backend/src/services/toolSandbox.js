/**
 * Tool Sandbox — enhanced sandboxed execution with per-tool resource limits.
 *
 * Wraps Node.js vm module and child_process with:
 * - Configurable timeout per risk level
 * - Output size caps
 * - Command whitelist/blacklist for shell execution
 * - Memory measurement
 *
 * Extends (does not replace) resourceGuard.js's safeExec.
 */
const vm = require('vm');
const { execSync } = require('child_process');
const path = require('path');

// ── Default limits per risk level ───────────────────────────────────

const DEFAULT_LIMITS = {
  safe:     { timeoutMs: 10000,  maxOutputBytes: 1048576,  maxMemoryMB: 100 },
  low:      { timeoutMs: 30000,  maxOutputBytes: 5242880,  maxMemoryMB: 200 },
  medium:   { timeoutMs: 60000,  maxOutputBytes: 10485760, maxMemoryMB: 300 },
  high:     { timeoutMs: 120000, maxOutputBytes: 10485760, maxMemoryMB: 500 },
  critical: { timeoutMs: 120000, maxOutputBytes: 10485760, maxMemoryMB: 500 },
};

// Commands that are always blocked (destructive / dangerous)
const BLOCKED_COMMANDS = [
  'rm -rf /',
  'rm -rf ~',
  'rm -rf /*',
  'mkfs',
  'dd if=',
  ':(){:|:&};:',   // fork bomb
  'chmod -R 777 /',
  'wget|sh',
  'curl|sh',
  'curl|bash',
  'wget|bash',
];

// Paths that should never be written to
const BLOCKED_PATHS = [
  '/etc/',
  '/usr/',
  '/bin/',
  '/sbin/',
  '/boot/',
  '/proc/',
  '/sys/',
];

// ── Sandboxed Code Execution ────────────────────────────────────────

/**
 * Execute JavaScript code in a sandboxed VM context.
 *
 * @param {string} code - JavaScript code to execute
 * @param {object} [limits]
 * @param {number} [limits.timeoutMs=5000] - Execution timeout
 * @param {number} [limits.maxOutputBytes=1048576] - Max output size
 * @returns {{ success: boolean, result?: any, output?: string, error?: string, elapsed: number }}
 */
function sandboxedExec(code, limits = {}) {
  const timeout = Math.min(limits.timeoutMs || 5000, 120000);
  const maxOutput = limits.maxOutputBytes || 1048576; // 1MB default

  const start = Date.now();
  const output = [];
  let totalOutputBytes = 0;

  // Create sandbox with limited globals
  const sandbox = {
    console: {
      log: (...args) => {
        const line = args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ');
        totalOutputBytes += Buffer.byteLength(line, 'utf-8');
        if (totalOutputBytes <= maxOutput) {
          output.push(line);
        }
      },
      error: (...args) => {
        const line = args.map(a => String(a)).join(' ');
        totalOutputBytes += Buffer.byteLength(line, 'utf-8');
        if (totalOutputBytes <= maxOutput) {
          output.push(`[ERROR] ${line}`);
        }
      },
      warn: (...args) => {
        const line = args.map(a => String(a)).join(' ');
        totalOutputBytes += Buffer.byteLength(line, 'utf-8');
        if (totalOutputBytes <= maxOutput) {
          output.push(`[WARN] ${line}`);
        }
      },
    },
    Math,
    Date,
    JSON,
    parseInt,
    parseFloat,
    isNaN,
    isFinite,
    Array,
    Object,
    String,
    Number,
    Boolean,
    Map,
    Set,
    RegExp,
    Error,
    Promise,
    setTimeout: undefined,  // Blocked
    setInterval: undefined, // Blocked
    require: undefined,     // Blocked
    process: undefined,     // Blocked
    global: undefined,      // Blocked
  };

  try {
    const context = vm.createContext(sandbox);
    const script = new vm.Script(code, { filename: 'sandbox.js' });
    const result = script.runInContext(context, { timeout });

    const elapsed = Date.now() - start;
    const outputText = output.join('\n');
    const truncated = totalOutputBytes > maxOutput;

    return {
      success: true,
      result: _serializeResult(result),
      output: truncated ? outputText + `\n... (output truncated at ${maxOutput} bytes)` : outputText,
      elapsed,
      truncated,
    };
  } catch (err) {
    return {
      success: false,
      error: err.message,
      output: output.join('\n'),
      elapsed: Date.now() - start,
    };
  }
}

// ── Sandboxed Shell Execution ───────────────────────────────────────

/**
 * Execute a shell command with safety checks and output limits.
 *
 * @param {string} command - Shell command
 * @param {object} [limits]
 * @param {number} [limits.timeoutMs=30000] - Execution timeout
 * @param {number} [limits.maxOutputBytes=5242880] - Max output size (5MB)
 * @param {string[]} [limits.allowedCommands] - If set, only these command prefixes are allowed
 * @param {string} [limits.cwd] - Working directory
 * @returns {{ success: boolean, output?: string, error?: string, elapsed: number }}
 */
function sandboxedShell(command, limits = {}) {
  const timeout = Math.min(limits.timeoutMs || 30000, 120000);
  const maxOutput = limits.maxOutputBytes || 5242880;
  const cwd = limits.cwd || process.env.KHYQUANT_CWD || process.cwd();

  // Security: check blocked patterns
  const cmdLower = command.toLowerCase().trim();
  for (const blocked of BLOCKED_COMMANDS) {
    if (cmdLower.includes(blocked.toLowerCase())) {
      return {
        success: false,
        error: `Blocked: command contains dangerous pattern "${blocked}"`,
        elapsed: 0,
      };
    }
  }

  // Security: check blocked paths in write commands
  const writePatterns = /\b(rm|rmdir|mv|cp|chmod|chown|ln)\b/i;
  if (writePatterns.test(command)) {
    for (const blockedPath of BLOCKED_PATHS) {
      if (command.includes(blockedPath)) {
        return {
          success: false,
          error: `Blocked: cannot modify system path "${blockedPath}"`,
          elapsed: 0,
        };
      }
    }
  }

  // Allowed commands whitelist (if configured)
  if (limits.allowedCommands && Array.isArray(limits.allowedCommands)) {
    const cmdPrefix = command.split(/\s+/)[0];
    if (!limits.allowedCommands.includes(cmdPrefix)) {
      return {
        success: false,
        error: `Blocked: "${cmdPrefix}" is not in allowed commands list`,
        elapsed: 0,
      };
    }
  }

  const start = Date.now();

  try {
    const output = execSync(command, {
      cwd,
      timeout,
      encoding: 'utf-8',
      maxBuffer: maxOutput,
      stdio: ['pipe', 'pipe', 'pipe'],
    });

    const elapsed = Date.now() - start;
    const truncated = Buffer.byteLength(output, 'utf-8') >= maxOutput;

    return {
      success: true,
      output: truncated ? output.slice(0, maxOutput) + '\n... (output truncated)' : output,
      elapsed,
      truncated,
    };
  } catch (err) {
    return {
      success: false,
      error: err.message,
      output: err.stdout ? String(err.stdout).slice(0, maxOutput) : '',
      stderr: err.stderr ? String(err.stderr).slice(0, 2000) : '',
      elapsed: Date.now() - start,
    };
  }
}

// ── Limit Configuration ─────────────────────────────────────────────

/**
 * Get default resource limits for a tool based on its risk level.
 *
 * @param {string} toolName - Tool name (for potential overrides)
 * @param {string} risk - Risk level
 * @returns {object} Resource limits
 */
function getToolLimits(toolName, risk) {
  const base = DEFAULT_LIMITS[risk] || DEFAULT_LIMITS.medium;
  return { ...base };
}

// ── Internal helpers ────────────────────────────────────────────────

function _serializeResult(result) {
  if (result === undefined) return undefined;
  if (result === null) return null;
  if (typeof result === 'string' || typeof result === 'number' || typeof result === 'boolean') {
    return result;
  }
  try {
    const json = JSON.stringify(result);
    if (json.length > 10000) {
      return json.slice(0, 10000) + '... (truncated)';
    }
    return JSON.parse(json); // Round-trip to strip non-serializable values
  } catch {
    return String(result);
  }
}

module.exports = {
  sandboxedExec,
  sandboxedShell,
  getToolLimits,
  DEFAULT_LIMITS,
  BLOCKED_COMMANDS,
};
