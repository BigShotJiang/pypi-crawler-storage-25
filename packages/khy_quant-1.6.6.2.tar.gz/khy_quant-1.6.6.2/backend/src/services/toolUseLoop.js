/**
 * Tool-Use Loop — iterative AI ↔ tool execution cycle.
 *
 * Inspired by Claude Code's agentic loop:
 *   1. Send user message + tool definitions → AI
 *   2. Parse AI response for tool calls
 *   3. Execute tools (with permission checks)
 *   4. Append results to conversation, loop back to step 1
 *   5. When AI responds without tool calls → return final answer
 *
 * Safety: hard max-iterations limit, per-tool timeout, audit logging.
 * Feature flag: KHY_TOOL_LOOP=false disables this, falling back to legacy.
 */
const chalk = require('chalk');

// ── Constants ──────────────────────────────────────────────────────

const MAX_ITERATIONS = 10;
const TOOL_CALL_REGEX = /<tool_call>\s*(\w+)\s*\(([^)]*)\)\s*<\/tool_call>/g;
const JSON_TOOL_CALL_REGEX = /<tool_call>\s*(\{[\s\S]*?\})\s*<\/tool_call>/g;

// ── Main Loop ──────────────────────────────────────────────────────

/**
 * Run an iterative tool-use loop: AI generates tool calls, system executes
 * them, feeds results back, and AI continues until it has a final answer.
 *
 * @param {string} userMessage - The user's original message
 * @param {object} options
 * @param {function} options.chat - AI chat function (message, opts) => { reply, ... }
 * @param {object} [options.chatOpts] - Options passed through to chat()
 * @param {number} [options.maxIterations=10] - Safety limit on loop iterations
 * @param {function} [options.onToolCall] - Callback before tool execution: (toolName, params, iteration)
 * @param {function} [options.onToolResult] - Callback after tool execution: (toolName, result, iteration)
 * @param {function} [options.onIteration] - Callback at each iteration start: (iteration, totalCalls)
 * @returns {Promise<{ finalResponse: string, toolCallLog: Array, iterations: number, provider?: string }>}
 */
async function runToolUseLoop(userMessage, options = {}) {
  const {
    chat,
    chatOpts = {},
    maxIterations = MAX_ITERATIONS,
    onToolCall,
    onToolResult,
    onIteration,
  } = options;

  if (!chat || typeof chat !== 'function') {
    throw new Error('toolUseLoop: chat function is required');
  }

  const toolCallLog = [];
  let currentMessage = userMessage;
  let lastResult = null;
  let totalToolCalls = 0;

  for (let iteration = 1; iteration <= maxIterations; iteration++) {
    if (onIteration) onIteration(iteration, totalToolCalls);

    // 1. Send to AI
    const aiResult = await chat(currentMessage, {
      ...chatOpts,
      _isFollowUp: iteration > 1,
    });

    if (!aiResult || !aiResult.reply) {
      return {
        finalResponse: aiResult?.reply || 'AI returned no response',
        toolCallLog,
        iterations: iteration,
        provider: aiResult?.provider,
        tokenUsage: aiResult?.tokenUsage,
      };
    }

    lastResult = aiResult;

    // 2. Parse tool calls from AI response
    const toolCalls = _parseToolCalls(aiResult.reply);

    // Also include legacy [CMD:...] commands as pseudo-tool-calls
    if (aiResult.commands && aiResult.commands.length > 0) {
      for (const cmd of aiResult.commands) {
        toolCalls.push({ name: '_legacy_cmd', params: { command: cmd }, legacy: true });
      }
    }

    // 3. No tool calls → final response
    if (toolCalls.length === 0) {
      return {
        finalResponse: aiResult.reply,
        toolCallLog,
        iterations: iteration,
        provider: aiResult.provider,
        tokenUsage: aiResult.tokenUsage,
        effort: aiResult.effort,
      };
    }

    // 4. Execute tool calls — parallel for concurrency-safe, sequential for rest
    const toolResults = [];
    const parallelCalls = [];
    const sequentialCalls = [];

    // Classify calls by concurrency safety
    let toolRegistry;
    try { toolRegistry = require('../tools'); } catch { toolRegistry = null; }

    for (const call of toolCalls) {
      if (call.legacy) {
        sequentialCalls.push(call);
        continue;
      }
      let isSafe = false;
      if (toolRegistry) {
        const regTool = toolRegistry.get(call.name);
        if (regTool && typeof regTool.isConcurrencySafe === 'function') {
          isSafe = regTool.isConcurrencySafe(call.params);
        }
      }
      if (isSafe) {
        parallelCalls.push(call);
      } else {
        sequentialCalls.push(call);
      }
    }

    // Execute parallel calls (only if >= 2, otherwise treat as sequential)
    if (parallelCalls.length >= 2) {
      const parallelPromises = parallelCalls.map(async (call) => {
        totalToolCalls++;
        if (onToolCall) onToolCall(call.name, call.params, iteration);
        const start = Date.now();
        let result;
        try {
          result = await toolRegistry.execute(call.name, call.params);
        } catch (err) {
          result = { success: false, error: err.message };
        }
        const elapsed = Date.now() - start;
        try {
          const { logToolExecution } = require('./auditLog');
          logToolExecution({ tool: call.name, params: call.params, result, elapsed });
        } catch { /* audit non-critical */ }
        if (onToolResult) onToolResult(call.name, result, iteration);
        return { tool: call.name, params: call.params, result, elapsed };
      });

      const settled = await Promise.allSettled(parallelPromises);
      for (const s of settled) {
        if (s.status === 'fulfilled') {
          toolResults.push(s.value);
          toolCallLog.push({ iteration, ...s.value });
          if (s.value.result && s.value.result.denied) {
            return {
              finalResponse: _stripToolCalls(aiResult.reply) + `\n\n${chalk.yellow('⚠ Tool execution denied by user, stopping.')}`,
              toolCallLog, iterations: iteration, provider: aiResult.provider, stopped: true,
            };
          }
        } else {
          const entry = { tool: 'unknown', params: {}, result: { success: false, error: s.reason?.message || 'Promise rejected' }, elapsed: 0 };
          toolResults.push(entry);
          toolCallLog.push({ iteration, ...entry });
        }
      }
    } else {
      // Move single parallel call back to sequential
      sequentialCalls.unshift(...parallelCalls);
    }

    // Execute sequential calls
    for (const call of sequentialCalls) {
      totalToolCalls++;

      // Skip legacy commands — they are handled by the existing REPL pipeline
      if (call.legacy) {
        toolResults.push({
          tool: '_legacy_cmd',
          params: call.params,
          result: { success: true, note: 'Executed via legacy command pipeline' },
        });
        toolCallLog.push({
          iteration,
          tool: '_legacy_cmd',
          params: call.params,
          result: { success: true },
          elapsed: 0,
        });
        continue;
      }

      if (onToolCall) onToolCall(call.name, call.params, iteration);

      const start = Date.now();
      let result;

      try {
        // Use tool registry for execution (includes permission checks)
        const toolRegistry = require('../tools');
        result = await toolRegistry.execute(call.name, call.params);
      } catch (err) {
        result = { success: false, error: err.message };
      }

      const elapsed = Date.now() - start;

      // Audit logging (non-critical)
      try {
        const { logToolExecution } = require('./auditLog');
        logToolExecution({
          tool: call.name,
          params: call.params,
          result,
          elapsed,
        });
      } catch { /* audit failure is non-critical */ }

      if (onToolResult) onToolResult(call.name, result, iteration);

      toolResults.push({ tool: call.name, params: call.params, result });
      toolCallLog.push({ iteration, tool: call.name, params: call.params, result, elapsed });

      // If user denied the tool, stop the loop
      if (result && result.denied) {
        return {
          finalResponse: _stripToolCalls(aiResult.reply) + `\n\n${chalk.yellow('⚠ Tool execution denied by user, stopping.')}`,
          toolCallLog,
          iterations: iteration,
          provider: aiResult.provider,
          stopped: true,
        };
      }
    }

    // 5. Build follow-up message with tool results
    currentMessage = _buildToolResultMessage(toolResults);
  }

  // Exceeded max iterations
  const warning = `\n\n${chalk.yellow(`⚠ Reached maximum tool-use iterations (${maxIterations}). Returning last response.`)}`;
  return {
    finalResponse: (lastResult?.reply || '') + warning,
    toolCallLog,
    iterations: maxIterations,
    provider: lastResult?.provider,
    maxIterationsReached: true,
  };
}

// ── Parsing ────────────────────────────────────────────────────────

/**
 * Parse tool calls from AI response text.
 * Supports two formats:
 *   1. <tool_call>tool_name(param1, param2)</tool_call>
 *   2. <tool_call>{"name": "tool", "params": {...}}</tool_call>
 *
 * @param {string} text - AI response text
 * @returns {Array<{name: string, params: object}>}
 */
function _parseToolCalls(text) {
  if (!text) return [];

  const calls = [];

  // Format 1: JSON-style tool calls
  const jsonMatches = [...text.matchAll(/<tool_call>\s*(\{[\s\S]*?\})\s*<\/tool_call>/g)];
  for (const match of jsonMatches) {
    try {
      const parsed = JSON.parse(match[1]);
      if (parsed.name) {
        calls.push({
          name: parsed.name,
          params: parsed.params || parsed.arguments || {},
        });
      }
    } catch { /* skip malformed JSON */ }
  }

  // Format 2: function-call-style tool calls
  // e.g. <tool_call>git_status()</tool_call> or <tool_call>quote(sh600519)</tool_call>
  const funcMatches = [...text.matchAll(/<tool_call>\s*(\w+)\s*\(([^)]*)\)\s*<\/tool_call>/g)];
  for (const match of funcMatches) {
    const name = match[1];
    const argsStr = match[2].trim();

    // Avoid duplicates (if already matched as JSON)
    if (calls.some(c => c.name === name)) continue;

    const params = _parseFunctionArgs(name, argsStr);
    calls.push({ name, params });
  }

  return calls;
}

/**
 * Parse function-call-style arguments into an object.
 * Maps positional args to parameter names based on tool schema.
 *
 * @param {string} toolName
 * @param {string} argsStr - Raw argument string
 * @returns {object}
 */
function _parseFunctionArgs(toolName, argsStr) {
  if (!argsStr) return {};

  // Try JSON parse first (e.g. {"symbol": "sh600519"})
  try {
    if (argsStr.startsWith('{')) {
      return JSON.parse(argsStr);
    }
  } catch { /* fall through */ }

  // Try key=value pairs (e.g. symbol=sh600519, staged=true)
  if (argsStr.includes('=')) {
    const params = {};
    const pairs = argsStr.split(',').map(s => s.trim());
    for (const pair of pairs) {
      const [key, ...rest] = pair.split('=');
      const value = rest.join('=').trim().replace(/^["']|["']$/g, '');
      params[key.trim()] = _coerceValue(value);
    }
    return params;
  }

  // Positional argument: map to the first required parameter
  try {
    const toolRegistry = require('../tools');
    const tool = toolRegistry.get(toolName);
    if (tool && tool.inputSchema) {
      const firstRequired = Object.entries(tool.inputSchema)
        .find(([, rule]) => rule.required);
      if (firstRequired) {
        return { [firstRequired[0]]: argsStr.replace(/^["']|["']$/g, '') };
      }
    }
  } catch { /* registry not available */ }

  // Fallback: treat as single unnamed parameter
  return { value: argsStr };
}

/**
 * Coerce string values to appropriate JS types.
 */
function _coerceValue(str) {
  if (str === 'true') return true;
  if (str === 'false') return false;
  if (str === 'null') return null;
  const num = Number(str);
  if (!isNaN(num) && str !== '') return num;
  return str;
}

// ── Formatting ─────────────────────────────────────────────────────

/**
 * Build a follow-up message containing tool execution results.
 * Formatted so the AI can understand what happened and continue.
 */
function _buildToolResultMessage(toolResults) {
  const parts = ['[Tool execution results]\n'];

  for (const tr of toolResults) {
    if (tr.tool === '_legacy_cmd') continue;

    parts.push(`Tool: ${tr.tool}`);
    if (tr.result.success) {
      // Include relevant output fields
      const output = tr.result.output || tr.result.content || tr.result.result;
      if (output) {
        const text = typeof output === 'string' ? output : JSON.stringify(output);
        // Truncate very long outputs
        parts.push(`Result: ${text.length > 3000 ? text.slice(0, 3000) + '... (truncated)' : text}`);
      } else {
        parts.push('Result: Success');
      }
    } else {
      parts.push(`Error: ${tr.result.error || 'Unknown error'}`);
    }
    parts.push('');
  }

  return parts.join('\n');
}

/**
 * Remove <tool_call> tags from text for display purposes.
 */
function _stripToolCalls(text) {
  if (!text) return '';
  return text
    .replace(/<tool_call>[\s\S]*?<\/tool_call>/g, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/**
 * Check if the tool-use loop is enabled via feature flag.
 * @returns {boolean}
 */
function isEnabled() {
  return process.env.KHY_TOOL_LOOP !== 'false';
}

// ── Exports ────────────────────────────────────────────────────────

module.exports = {
  runToolUseLoop,
  isEnabled,
  MAX_ITERATIONS,
  // Exposed for testing
  _parseToolCalls,
  _stripToolCalls,
  _buildToolResultMessage,
};
