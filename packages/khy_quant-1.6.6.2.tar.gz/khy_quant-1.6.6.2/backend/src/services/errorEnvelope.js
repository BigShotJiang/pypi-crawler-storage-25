/**
 * Error Envelope — standardized response format for all service operations.
 *
 * Provides a consistent shape for success and failure results across
 * the entire codebase. Gradually adopt in new code — existing code
 * that returns { success, error } continues to work.
 *
 * Format:
 *   Success: { ok: true, data: ..., meta?: ... }
 *   Failure: { ok: false, error: { message, code, detail? } }
 */

// ── Standard Error Codes ───────────────────────────────────────────

const ERROR_CODES = {
  NOT_FOUND: 'NOT_FOUND',
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  PERMISSION_DENIED: 'PERMISSION_DENIED',
  TIMEOUT: 'TIMEOUT',
  RATE_LIMITED: 'RATE_LIMITED',
  NETWORK_ERROR: 'NETWORK_ERROR',
  AUTH_ERROR: 'AUTH_ERROR',
  INTERNAL_ERROR: 'INTERNAL_ERROR',
  NOT_AVAILABLE: 'NOT_AVAILABLE',
  BLOCKED: 'BLOCKED',
};

// ── Envelope Constructors ──────────────────────────────────────────

/**
 * Create a success envelope.
 *
 * @param {*} data - The result data
 * @param {object} [meta] - Optional metadata (elapsed, provider, etc.)
 * @returns {{ ok: true, data: *, meta?: object }}
 */
function success(data, meta) {
  const envelope = { ok: true, data };
  if (meta && typeof meta === 'object' && Object.keys(meta).length > 0) {
    envelope.meta = meta;
  }
  return envelope;
}

/**
 * Create a failure envelope.
 *
 * @param {string} message - Human-readable error message
 * @param {string} [code='INTERNAL_ERROR'] - Error code from ERROR_CODES
 * @param {object} [detail] - Additional error context
 * @returns {{ ok: false, error: { message: string, code: string, detail?: object } }}
 */
function failure(message, code, detail) {
  const error = {
    message: String(message),
    code: code || ERROR_CODES.INTERNAL_ERROR,
  };
  if (detail && typeof detail === 'object') {
    error.detail = detail;
  }
  return { ok: false, error };
}

/**
 * Convert a caught error into a standardized failure envelope.
 * Classifies common error patterns into appropriate codes.
 *
 * @param {Error|*} err - The caught error
 * @param {string} [context] - Where the error occurred (e.g., 'toolCalling.execute')
 * @returns {{ ok: false, error: { message, code, detail? } }}
 */
function fromCatch(err, context) {
  if (!err) {
    return failure('Unknown error', ERROR_CODES.INTERNAL_ERROR);
  }

  const message = err.message || String(err);
  const code = _classifyError(message, err);
  const detail = {};

  if (context) detail.context = context;
  if (err.code) detail.originalCode = err.code;
  if (err.statusCode) detail.statusCode = err.statusCode;

  return failure(message, code, Object.keys(detail).length > 0 ? detail : undefined);
}

/**
 * Check if an object is a valid envelope (success or failure).
 *
 * @param {*} obj
 * @returns {boolean}
 */
function isEnvelope(obj) {
  if (!obj || typeof obj !== 'object') return false;
  if (obj.ok === true && 'data' in obj) return true;
  if (obj.ok === false && obj.error && typeof obj.error.message === 'string') return true;
  return false;
}

/**
 * Convert legacy { success, error, ... } format to envelope format.
 * Useful for bridging old code to new code.
 *
 * @param {object} legacyResult - { success: boolean, error?: string, ... }
 * @returns {{ ok: boolean, data?: *, error?: object }}
 */
function fromLegacy(legacyResult) {
  if (!legacyResult || typeof legacyResult !== 'object') {
    return failure('Invalid result', ERROR_CODES.INTERNAL_ERROR);
  }

  if (legacyResult.success) {
    // Extract data (everything except 'success' and 'error')
    const { success: _, error: __, ...data } = legacyResult;
    return success(Object.keys(data).length > 0 ? data : undefined);
  }

  return failure(
    legacyResult.error || 'Operation failed',
    legacyResult.denied ? ERROR_CODES.PERMISSION_DENIED : ERROR_CODES.INTERNAL_ERROR
  );
}

// ── ServiceError ───────────────────────────────────────────────────

/**
 * Custom error class that carries an error code and converts to envelope.
 */
class ServiceError extends Error {
  /**
   * @param {string} message
   * @param {string} [code='INTERNAL_ERROR']
   * @param {object} [meta]
   */
  constructor(message, code, meta) {
    super(message);
    this.name = 'ServiceError';
    this.code = code || ERROR_CODES.INTERNAL_ERROR;
    this.meta = meta || {};
  }

  /**
   * Convert to failure envelope.
   * @returns {{ ok: false, error: { message, code, detail? } }}
   */
  toEnvelope() {
    return failure(
      this.message,
      this.code,
      Object.keys(this.meta).length > 0 ? this.meta : undefined
    );
  }
}

// ── Internal ───────────────────────────────────────────────────────

/**
 * Classify an error message into an error code.
 */
function _classifyError(message, err) {
  const msg = message.toLowerCase();

  if (msg.includes('timeout') || msg.includes('etimedout') || msg.includes('aborted')) {
    return ERROR_CODES.TIMEOUT;
  }
  if (msg.includes('rate limit') || msg.includes('too many requests') || (err && err.statusCode === 429)) {
    return ERROR_CODES.RATE_LIMITED;
  }
  if (msg.includes('econnrefused') || msg.includes('enotfound') || msg.includes('network')) {
    return ERROR_CODES.NETWORK_ERROR;
  }
  if (msg.includes('unauthorized') || msg.includes('invalid key') || msg.includes('api key') || (err && (err.statusCode === 401 || err.statusCode === 403))) {
    return ERROR_CODES.AUTH_ERROR;
  }
  if (msg.includes('not found') || (err && err.statusCode === 404)) {
    return ERROR_CODES.NOT_FOUND;
  }
  if (msg.includes('permission') || msg.includes('denied') || msg.includes('blocked')) {
    return ERROR_CODES.PERMISSION_DENIED;
  }
  if (msg.includes('validation') || msg.includes('invalid') || msg.includes('required')) {
    return ERROR_CODES.VALIDATION_ERROR;
  }

  return ERROR_CODES.INTERNAL_ERROR;
}

// ── Exports ────────────────────────────────────────────────────────

module.exports = {
  success,
  failure,
  fromCatch,
  fromLegacy,
  isEnvelope,
  ServiceError,
  ERROR_CODES,
};
