/**
 * Query State Machine — explicit state transitions for the query loop.
 *
 * The state is a plain value object replaced entirely each iteration
 * (state = nextState(...)). The transition field records WHY the loop
 * continued, making debugging and testing straightforward.
 */

const TRANSITIONS = Object.freeze({
  NEXT_TURN: 'next_turn',
  STOP_HOOK_BLOCKING: 'stop_hook_blocking',
  MAX_OUTPUT_RECOVERY: 'max_output_recovery',
  TOKEN_BUDGET_CONTINUATION: 'token_budget_continuation',
  COMPACT_RETRY: 'compact_retry',
  USER_ABORT: 'user_abort',
  MAX_TURNS_REACHED: 'max_turns_reached',
  DONE: 'done',
});

/**
 * Create the initial state for a new query loop.
 * @param {object} config - QueryConfig snapshot
 * @returns {object} Initial state
 */
function createInitialState(config) {
  return {
    messages: [],
    turnCount: 0,
    transition: TRANSITIONS.NEXT_TURN,
    maxOutputRecoveryCount: 0,
    hasAttemptedCompact: false,
    withheldMessages: [],
    continuationDeltas: [],
    lastOutputTokens: 0,
  };
}

/**
 * Produce a new state by applying a transition and optional updates.
 * @param {object} currentState
 * @param {string} transition - One of TRANSITIONS values
 * @param {object} [updates] - Partial state overrides
 * @returns {object} New state (shallow clone)
 */
function nextState(currentState, transition, updates = {}) {
  return {
    ...currentState,
    transition,
    ...updates,
  };
}

/**
 * Determine whether the loop should continue based on current state.
 * @param {object} state
 * @returns {boolean}
 */
function shouldContinue(state) {
  switch (state.transition) {
    case TRANSITIONS.NEXT_TURN:
    case TRANSITIONS.STOP_HOOK_BLOCKING:
    case TRANSITIONS.MAX_OUTPUT_RECOVERY:
    case TRANSITIONS.TOKEN_BUDGET_CONTINUATION:
    case TRANSITIONS.COMPACT_RETRY:
      return true;

    case TRANSITIONS.USER_ABORT:
    case TRANSITIONS.MAX_TURNS_REACHED:
    case TRANSITIONS.DONE:
    default:
      return false;
  }
}

module.exports = { TRANSITIONS, createInitialState, nextState, shouldContinue };
