/**
 * Stop Hooks — user-configurable validation after each query turn.
 *
 * Hooks are shell commands defined in ~/.khyquant/stop_hooks.json.
 * After each turn, matching hooks are executed and their exit codes
 * determine whether the query loop continues, stops, or injects an
 * error for the model to address.
 *
 * Config format:
 *   [{ "name": "lint", "command": "npm run lint", "on": "after_turn", "timeout": 10000 }]
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const DEFAULT_TIMEOUT = 10000; // 10s

/**
 * Load hooks from the user config file.
 * Returns empty array if file is missing or invalid.
 * @returns {Array<{ name: string, command: string, on: string, timeout?: number }>}
 */
function loadHooks() {
  try {
    const { getDataHome } = require('../../utils/dataHome');
    const configPath = path.join(getDataHome(), 'stop_hooks.json');
    if (!fs.existsSync(configPath)) return [];
    const raw = fs.readFileSync(configPath, 'utf-8');
    const hooks = JSON.parse(raw);
    if (!Array.isArray(hooks)) return [];
    return hooks.filter((h) => h && h.name && h.command);
  } catch {
    return [];
  }
}

/**
 * Evaluate hooks matching the given trigger.
 *
 * @param {Array} hooks - Loaded hooks array
 * @param {object} context - { turnCount, lastToolResults, lastReply, transition, trigger }
 * @returns {{ results: Array, preventContinuation: boolean, blockingErrors: Array<{ role: string, content: string }> }}
 */
function evaluateHooks(hooks, context = {}) {
  const trigger = context.trigger || 'after_turn';
  const matching = hooks.filter((h) => (h.on || 'after_turn') === trigger);

  if (matching.length === 0) {
    return { results: [], preventContinuation: false, blockingErrors: [] };
  }

  const results = [];
  const blockingErrors = [];
  let preventContinuation = false;

  for (const hook of matching) {
    const timeout = hook.timeout || DEFAULT_TIMEOUT;
    try {
      execSync(hook.command, {
        timeout,
        stdio: 'pipe',
        cwd: process.env.KHYQUANT_CWD || process.cwd(),
        env: {
          ...process.env,
          KHY_TURN_COUNT: String(context.turnCount || 0),
          KHY_TRANSITION: context.transition || '',
        },
      });
      results.push({ name: hook.name, action: 'pass' });
    } catch (err) {
      const stderr = err.stderr ? err.stderr.toString().trim() : '';
      const stdout = err.stdout ? err.stdout.toString().trim() : '';
      const output = stderr || stdout || err.message;

      if (err.status === 2) {
        // Exit code 2: prevent continuation entirely
        preventContinuation = true;
        results.push({ name: hook.name, action: 'preventContinuation', output });
      } else {
        // Any other non-zero exit: blocking error (inject as user message)
        blockingErrors.push({
          role: 'user',
          content: `[Stop Hook "${hook.name}" failed]\n${output}\n\nPlease fix the issue above before continuing.`,
        });
        results.push({ name: hook.name, action: 'blockingError', output });
      }
    }
  }

  return { results, preventContinuation, blockingErrors };
}

module.exports = { loadHooks, evaluateHooks };
