/**
 * Token Budget — per-turn budget tracking and continuation decisions.
 *
 * Tracks token consumption across turns and decides whether the query
 * loop should continue or stop. Implements diminishing returns detection
 * to prevent wasteful continuation when the model has little to add.
 */

const COMPLETION_THRESHOLD = 0.9;    // Stop at 90% of budget
const DIMINISHING_THRESHOLD = 500;   // Tokens
const MAX_CONTINUATIONS = 3;

/**
 * Create a new budget tracker for one query lifecycle.
 * @param {object} config - QueryConfig snapshot
 * @returns {object} Budget tracker state
 */
function createBudget(config) {
  return {
    limit: config.maxTokens || 4096,
    used: 0,
    turns: [],
    continuationCount: 0,
    lastDelta: 0,
  };
}

/**
 * Record a turn's token usage.
 * @param {object} budget - Budget tracker
 * @param {object} tokenUsage - { inputTokens, outputTokens, totalTokens }
 */
function recordTurn(budget, tokenUsage) {
  if (!tokenUsage) return;

  const total = tokenUsage.totalTokens || tokenUsage.outputTokens || 0;
  const prevUsed = budget.used;

  budget.used += total;
  budget.lastDelta = total;
  budget.turns.push({
    inputTokens: tokenUsage.inputTokens || 0,
    outputTokens: tokenUsage.outputTokens || 0,
    total,
    timestamp: Date.now(),
  });
}

/**
 * Decide whether the query loop should request another continuation.
 *
 * @param {object} budget - Budget tracker
 * @param {object} config - QueryConfig snapshot
 * @returns {{ action: 'continue'|'stop', reason: string }}
 */
function shouldContinue(budget, config) {
  // Sub-agents never auto-continue
  if (config.isSubAgent) {
    return { action: 'stop', reason: 'sub_agent' };
  }

  // Budget not set or unlimited
  if (!budget.limit || budget.limit <= 0) {
    return { action: 'stop', reason: 'no_budget' };
  }

  // Check if we've exceeded the completion threshold
  const pct = budget.used / budget.limit;
  if (pct >= COMPLETION_THRESHOLD) {
    return { action: 'stop', reason: 'budget_threshold' };
  }

  // Diminishing returns detection:
  // If 3+ continuations and each recent delta < 500 tokens, stop
  if (budget.continuationCount >= MAX_CONTINUATIONS) {
    const recentTurns = budget.turns.slice(-MAX_CONTINUATIONS);
    const allDiminishing = recentTurns.every(
      (t) => t.total < DIMINISHING_THRESHOLD
    );
    if (allDiminishing) {
      return { action: 'stop', reason: 'diminishing_returns' };
    }
  }

  // Budget available — continue
  budget.continuationCount++;
  return {
    action: 'continue',
    reason: 'budget_available',
    remaining: budget.limit - budget.used,
    pct: Math.round(pct * 100),
  };
}

/**
 * Get a summary of the budget state for diagnostics.
 * @param {object} budget
 * @returns {object}
 */
function getSummary(budget) {
  return {
    used: budget.used,
    limit: budget.limit,
    pct: budget.limit > 0 ? Math.round((budget.used / budget.limit) * 100) : 0,
    turns: budget.turns.length,
    continuations: budget.continuationCount,
  };
}

module.exports = { createBudget, recordTurn, shouldContinue, getSummary };
