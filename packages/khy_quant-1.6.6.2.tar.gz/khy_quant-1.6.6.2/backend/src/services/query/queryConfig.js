/**
 * Query Config — immutable configuration snapshot.
 *
 * Created once at the start of submitMessage(), frozen for the entire
 * query loop. Prevents mid-query settings changes from causing
 * inconsistent behavior.
 */

const DEFAULT_MAX_TURNS = 10;
const DEFAULT_MAX_TOKENS = 4096;

const DEFAULT_EFFORT_PRESETS = {
  max:    { temperature: 0.2, maxTokens: 4096 },
  high:   { temperature: 0.3, maxTokens: 2048 },
  medium: { temperature: 0.5, maxTokens: 1024 },
  low:    { temperature: 0.7, maxTokens: 512 },
};

/**
 * Create a frozen config snapshot for one query lifecycle.
 *
 * @param {object} [options]
 * @param {string} [options.effort] - Effort level override
 * @param {number} [options.maxTurns] - Max tool-use turns
 * @param {Array}  [options.images] - Image attachments
 * @param {boolean} [options.isSubAgent] - Sub-agent flag (disables continuation)
 * @returns {Readonly<object>}
 */
function createConfig(options = {}) {
  // Read effort presets from ai.js if available, else use defaults
  let effortPresets = DEFAULT_EFFORT_PRESETS;
  let currentEffort = 'high';
  try {
    const ai = require('../../cli/ai');
    if (ai.EFFORT_PRESETS) effortPresets = ai.EFFORT_PRESETS;
    if (ai.getEffort) currentEffort = ai.getEffort();
  } catch { /* ai module not available */ }

  const effort = options.effort || currentEffort;
  const preset = effortPresets[effort] || effortPresets.high;

  // Read available tools from registry
  let tools = [];
  try {
    const toolRegistry = require('../../tools');
    tools = toolRegistry.getEnabled
      ? [...toolRegistry.getEnabled().keys()]
      : [];
  } catch { /* tool registry not available */ }

  const config = {
    effort,
    temperature: preset.temperature,
    maxTokens: preset.maxTokens || DEFAULT_MAX_TOKENS,
    maxTurns: options.maxTurns || DEFAULT_MAX_TURNS,
    tools,
    images: options.images || null,
    isSubAgent: options.isSubAgent || false,
    createdAt: Date.now(),
  };

  return Object.freeze(config);
}

module.exports = { createConfig, DEFAULT_EFFORT_PRESETS };
