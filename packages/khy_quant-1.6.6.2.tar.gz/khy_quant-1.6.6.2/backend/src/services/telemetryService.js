/**
 * Telemetry Service — unified metrics aggregation across tools, agents, and services.
 *
 * Collects and aggregates metrics from:
 *   - Tool executions (via auditLog)
 *   - Agent runs (tradingAgentsService)
 *   - AI model usage (tokenUsageService / aiMonitor)
 *   - Service health (serviceRegistry)
 *
 * Does NOT replace individual monitoring modules — imports and composes them.
 * Provides a single getUnifiedStats() for dashboards and HUD.
 */
const os = require('os');

// ── In-memory counters (reset on process restart) ──────────────────

const _counters = {
  toolCalls: 0,
  toolErrors: 0,
  agentRuns: 0,
  serviceCalls: 0,
  totalLatencyMs: 0,
  startTime: Date.now(),
};

const _recentEvents = [];  // ring buffer of last N events
const MAX_RECENT = 100;

// ── Event Recording ────────────────────────────────────────────────

/**
 * Record a tool call event.
 *
 * @param {object} entry
 * @param {string} entry.tool - Tool name
 * @param {boolean} entry.success - Whether it succeeded
 * @param {number} [entry.elapsed] - Execution time in ms
 * @param {string} [entry.error] - Error message if failed
 */
function trackToolCall(entry) {
  if (!entry) return;

  _counters.toolCalls++;
  if (!entry.success) _counters.toolErrors++;
  if (entry.elapsed) _counters.totalLatencyMs += entry.elapsed;

  _pushEvent({
    type: 'tool',
    tool: entry.tool,
    success: !!entry.success,
    elapsed: entry.elapsed || 0,
    error: entry.error,
    timestamp: Date.now(),
  });
}

/**
 * Record an agent run event.
 *
 * @param {object} entry
 * @param {string} entry.agentId - Agent identifier
 * @param {string} entry.action - Action taken
 * @param {boolean} entry.success
 * @param {number} [entry.elapsed]
 */
function trackAgentRun(entry) {
  if (!entry) return;

  _counters.agentRuns++;
  if (entry.elapsed) _counters.totalLatencyMs += entry.elapsed;

  _pushEvent({
    type: 'agent',
    agentId: entry.agentId,
    action: entry.action,
    success: !!entry.success,
    elapsed: entry.elapsed || 0,
    timestamp: Date.now(),
  });
}

/**
 * Record a service call event.
 *
 * @param {object} entry
 * @param {string} entry.service - Service name
 * @param {string} entry.method - Method called
 * @param {boolean} entry.success
 * @param {number} [entry.elapsed]
 */
function trackServiceCall(entry) {
  if (!entry) return;

  _counters.serviceCalls++;
  if (entry.elapsed) _counters.totalLatencyMs += entry.elapsed;

  _pushEvent({
    type: 'service',
    service: entry.service,
    method: entry.method,
    success: !!entry.success,
    elapsed: entry.elapsed || 0,
    timestamp: Date.now(),
  });
}

// ── Aggregated Statistics ──────────────────────────────────────────

/**
 * Get unified statistics across all telemetry sources.
 * Merges in-memory counters with data from auditLog and tokenUsageService.
 *
 * @returns {object} Unified stats
 */
function getUnifiedStats() {
  const uptime = Date.now() - _counters.startTime;

  // Base in-memory stats
  const stats = {
    uptime,
    uptimeFormatted: _formatDuration(uptime),
    toolCalls: _counters.toolCalls,
    toolErrors: _counters.toolErrors,
    toolSuccessRate: _counters.toolCalls > 0
      ? Math.round((_counters.toolCalls - _counters.toolErrors) / _counters.toolCalls * 100)
      : 100,
    agentRuns: _counters.agentRuns,
    serviceCalls: _counters.serviceCalls,
    avgLatency: _counters.toolCalls > 0
      ? Math.round(_counters.totalLatencyMs / _counters.toolCalls)
      : 0,
    system: {
      memoryUsed: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
      memoryTotal: Math.round(os.totalmem() / 1024 / 1024),
      cpuLoad: os.loadavg()[0],
    },
  };

  // Merge audit log stats (non-critical)
  try {
    const { getAuditStats } = require('./auditLog');
    const auditStats = getAuditStats();
    stats.audit = {
      totalCalls: auditStats.totalCalls,
      deniedCount: auditStats.deniedCount,
      topTools: Object.entries(auditStats.byTool || {})
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5)
        .map(([name, count]) => ({ name, count })),
    };
  } catch { /* audit service not available */ }

  // Merge token usage stats (non-critical)
  try {
    const tokenUsage = require('./tokenUsageService');
    if (typeof tokenUsage.getSessionStats === 'function') {
      stats.tokens = tokenUsage.getSessionStats();
    } else if (typeof tokenUsage.getUsageSummary === 'function') {
      stats.tokens = tokenUsage.getUsageSummary();
    }
  } catch { /* token usage service not available */ }

  // Service registry stats (non-critical)
  try {
    const registry = require('./serviceRegistry');
    stats.services = registry.stats();
  } catch { /* registry not available */ }

  return stats;
}

/**
 * Get recent events for real-time monitoring.
 *
 * @param {number} [limit=20]
 * @returns {Array}
 */
function getRecentEvents(limit = 20) {
  return _recentEvents.slice(-limit);
}

/**
 * Create dashboard data suitable for HUD or web display.
 *
 * @returns {object} Dashboard-formatted data
 */
function createDashboardData() {
  const stats = getUnifiedStats();

  // Compute per-minute rates
  const minutesUp = Math.max(1, stats.uptime / 60000);

  return {
    summary: {
      uptime: stats.uptimeFormatted,
      toolCallsPerMinute: (stats.toolCalls / minutesUp).toFixed(1),
      successRate: `${stats.toolSuccessRate}%`,
      avgLatency: `${stats.avgLatency}ms`,
      memoryUsed: `${stats.system.memoryUsed}MB`,
    },
    counters: {
      tools: stats.toolCalls,
      agents: stats.agentRuns,
      services: stats.serviceCalls,
      errors: stats.toolErrors,
    },
    topTools: stats.audit?.topTools || [],
    tokens: stats.tokens || {},
    recentEvents: getRecentEvents(10),
  };
}

/**
 * Reset all in-memory counters (for testing).
 */
function reset() {
  _counters.toolCalls = 0;
  _counters.toolErrors = 0;
  _counters.agentRuns = 0;
  _counters.serviceCalls = 0;
  _counters.totalLatencyMs = 0;
  _counters.startTime = Date.now();
  _recentEvents.length = 0;
}

// ── Internal ───────────────────────────────────────────────────────

function _pushEvent(event) {
  _recentEvents.push(event);
  if (_recentEvents.length > MAX_RECENT) {
    _recentEvents.shift();
  }
}

function _formatDuration(ms) {
  const seconds = Math.floor(ms / 1000);
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ${seconds % 60}s`;
  const hours = Math.floor(minutes / 60);
  return `${hours}h ${minutes % 60}m`;
}

// ── Exports ────────────────────────────────────────────────────────

module.exports = {
  trackToolCall,
  trackAgentRun,
  trackServiceCall,
  getUnifiedStats,
  getRecentEvents,
  createDashboardData,
  reset,
};
