module.exports = require('../../../packages/shared/src/services/cacheService');
