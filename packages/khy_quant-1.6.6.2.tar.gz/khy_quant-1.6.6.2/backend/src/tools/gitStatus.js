const { defineTool, isGitRepo } = require('./_baseTool');
const { execSync } = require('child_process');

module.exports = defineTool({
  name: 'gitStatus',
  description: 'Show the working tree status (git status --porcelain)',
  category: 'git',
  risk: 'safe',
  isReadOnly: true,
  isConcurrencySafe: true,
  isEnabled: isGitRepo,
  inputSchema: {},
  async execute(params, context) {
    try {
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      const output = execSync('git status --porcelain', {
        cwd,
        encoding: 'utf-8',
        timeout: 10000,
      });
      return { success: true, output: output || '' };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },
});
