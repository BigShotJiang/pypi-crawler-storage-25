const { defineTool } = require('./_baseTool');
const vm = require('vm');

module.exports = defineTool({
  name: 'executeCode',
  description: 'Execute JavaScript code in a sandboxed VM context',
  category: 'execution',
  risk: 'high',
  isReadOnly: false,
  isConcurrencySafe: false,
  inputSchema: {
    code: { type: 'string', required: true, description: 'JavaScript code to execute' },
    language: { type: 'string', required: false, enum: ['javascript'], description: 'Code language (only javascript supported)' },
  },
  async execute(params, context) {
    try {
      const sandbox = {
        console: { log: (...a) => a.join(' '), error: (...a) => a.join(' ') },
        Math,
        Date,
        JSON,
        parseInt,
        parseFloat,
        isNaN,
        isFinite,
      };

      const result = vm.runInNewContext(params.code, sandbox, { timeout: 5000 });
      return { success: true, result: result !== undefined ? String(result) : undefined };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },
});
