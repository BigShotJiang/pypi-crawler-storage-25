/**
 * ToolSearch — discover and load deferred tools by keyword.
 *
 * When the tool count grows (with MCP tools), not all tool schemas
 * fit in the initial prompt. Deferred tools (shouldDefer: true) only
 * show their name; the model uses ToolSearch to get full descriptions.
 *
 * Supports two query modes:
 *   "select:readFile,writeFile"  — exact name selection
 *   "file editing"               — keyword search with scoring
 *
 * Feature gate: KHY_TOOL_SEARCH=true to enable.
 */
const { defineTool } = require('./_baseTool');

// ── Name Parsing ───────────────────────────────────────────────────

/**
 * Parse a tool name into searchable parts.
 * Handles camelCase, snake_case, and MCP-style mcp__server__tool names.
 *
 * @param {string} name
 * @returns {{ parts: string[], full: string }}
 */
function parseToolName(name) {
  if (!name) return { parts: [], full: '' };

  // MCP tools: mcp__server__tool → [server, tool]
  if (name.startsWith('mcp__')) {
    const withoutPrefix = name.replace(/^mcp__/, '').toLowerCase();
    const parts = withoutPrefix.split('__').flatMap(p => p.split('_'));
    return { parts, full: withoutPrefix.replace(/__/g, ' ').replace(/_/g, ' ') };
  }

  // CamelCase → parts: readFile → [read, file]
  const parts = name
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/_/g, ' ')
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean);

  return { parts, full: parts.join(' ') };
}

// ── Scoring ────────────────────────────────────────────────────────

/**
 * Score how well a tool matches a search query.
 * @param {object} tool
 * @param {string[]} queryTerms - Lowercased query tokens
 * @returns {number} Score (higher = better match)
 */
function scoreTool(tool, queryTerms) {
  let score = 0;

  const { parts: nameParts, full: nameFull } = parseToolName(tool.name);
  const desc = (tool.description || '').toLowerCase();
  const hint = (tool.searchHint || '').toLowerCase();
  const aliases = (tool.aliases || []).map(a => a.toLowerCase());

  for (const term of queryTerms) {
    // Exact name match (highest value)
    if (tool.name.toLowerCase() === term) { score += 10; continue; }

    // Alias match
    if (aliases.includes(term)) { score += 8; continue; }

    // Name part match
    if (nameParts.includes(term)) { score += 5; continue; }

    // Name substring
    if (nameFull.includes(term)) { score += 3; continue; }

    // Search hint match
    if (hint.includes(term)) { score += 4; continue; }

    // Description match
    if (desc.includes(term)) { score += 2; continue; }
  }

  return score;
}

// ── Tool Definition ────────────────────────────────────────────────

module.exports = defineTool({
  name: 'toolSearch',
  description: 'Search and discover available tools by keyword or select by name',
  category: 'system',
  risk: 'safe',
  isReadOnly: true,
  isConcurrencySafe: true,
  alwaysLoad: true,  // ToolSearch itself is never deferred

  isEnabled() {
    return process.env.KHY_TOOL_SEARCH === 'true';
  },

  inputSchema: {
    query: {
      type: 'string',
      required: true,
      description: 'Search query (keywords) or "select:tool1,tool2" for exact selection',
    },
  },

  async execute(params) {
    const query = (params.query || '').trim();
    if (!query) {
      return { success: false, error: 'Query is required' };
    }

    let toolRegistry;
    try { toolRegistry = require('./index'); } catch {
      return { success: false, error: 'Tool registry not available' };
    }

    // Mode 1: Direct selection — "select:readFile,writeFile"
    if (query.startsWith('select:')) {
      const names = query.slice(7).split(',').map(n => n.trim()).filter(Boolean);
      return await handleSelect(names, toolRegistry);
    }

    // Mode 2: Keyword search
    return await handleSearch(query, toolRegistry);
  },
});

// ── Handlers ───────────────────────────────────────────────────────

async function handleSelect(names, registry) {
  const results = [];
  const allTools = registry.getAll();

  for (const name of names) {
    // Try exact match first
    let tool = allTools.get(name);

    // Try alias match
    if (!tool) {
      for (const [, t] of allTools) {
        if (t.aliases && t.aliases.includes(name)) {
          tool = t;
          break;
        }
      }
    }

    if (tool) {
      const prompt = await tool.prompt();
      results.push({
        name: tool.name,
        description: prompt,
        schema: tool.toFunctionDef(),
        category: tool.category,
        risk: tool.risk,
      });
    } else {
      results.push({ name, error: `Tool not found: ${name}` });
    }
  }

  return {
    success: true,
    mode: 'select',
    tools: results,
    count: results.filter(r => !r.error).length,
  };
}

async function handleSearch(query, registry) {
  const queryTerms = query.toLowerCase().split(/\s+/).filter(Boolean);
  const allTools = registry.getAll();
  const scored = [];

  for (const [name, tool] of allTools) {
    if (name === 'toolSearch') continue; // Don't return self
    const score = scoreTool(tool, queryTerms);
    if (score > 0) {
      scored.push({ tool, score });
    }
  }

  // Sort by score descending, take top 10
  scored.sort((a, b) => b.score - a.score);
  const top = scored.slice(0, 10);

  const results = [];
  for (const { tool, score } of top) {
    const prompt = await tool.prompt();
    results.push({
      name: tool.name,
      score,
      description: prompt,
      schema: tool.toFunctionDef(),
      category: tool.category,
      risk: tool.risk,
      deferred: tool.shouldDefer || false,
    });
  }

  return {
    success: true,
    mode: 'search',
    query,
    tools: results,
    count: results.length,
    totalAvailable: allTools.size,
  };
}
