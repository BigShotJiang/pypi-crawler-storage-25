const { defineTool, isGitRepo } = require('./_baseTool');
const { execSync } = require('child_process');

module.exports = defineTool({
  name: 'gitDiff',
  description: 'Show changes in the working directory (git diff)',
  category: 'git',
  risk: 'safe',
  isReadOnly: true,
  isConcurrencySafe: true,
  isEnabled: isGitRepo,
  inputSchema: {
    file: { type: 'string', required: false, description: 'Specific file to diff' },
  },
  async execute(params, context) {
    try {
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      const cmd = params.file ? `git diff -- ${params.file}` : 'git diff';
      const output = execSync(cmd, {
        cwd,
        encoding: 'utf-8',
        timeout: 10000,
      });
      return { success: true, output: output || '' };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },
});
