const { defineTool, isGitRepo } = require('./_baseTool');
const { execSync } = require('child_process');

module.exports = defineTool({
  name: 'gitCommit',
  description: 'Stage files and create a git commit',
  category: 'git',
  risk: 'medium',
  isReadOnly: false,
  isConcurrencySafe: false,
  isEnabled: isGitRepo,
  inputSchema: {
    message: { type: 'string', required: true, description: 'Commit message' },
    files: { type: 'array', required: false, description: 'Files to stage (git add). If empty, commits already staged files.' },
  },
  async execute(params, context) {
    try {
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      const opts = { cwd, encoding: 'utf-8', timeout: 15000 };

      if (params.files && params.files.length > 0) {
        const fileList = params.files.map(f => `"${f}"`).join(' ');
        execSync(`git add ${fileList}`, opts);
      }

      const output = execSync(`git commit -m "${params.message.replace(/"/g, '\\"')}"`, opts);
      return { success: true, output: output || '' };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },
});
