const { defineTool } = require('./_baseTool');
const fs = require('fs');
const path = require('path');

module.exports = defineTool({
  name: 'writeFile',
  description: 'Write content to a file on the filesystem',
  category: 'filesystem',
  risk: 'high',
  isReadOnly: false,
  isDestructive: (input) => {
    // Overwriting an existing file is destructive
    if (!input?.path) return false;
    try {
      const resolved = require('path').resolve(
        process.env.KHYQUANT_CWD || process.cwd(), input.path
      );
      return require('fs').existsSync(resolved);
    } catch { return false; }
  },
  isConcurrencySafe: false,

  // Chapter 5 additions
  maxResultSizeChars: 1000, // write results are tiny

  inputSchema: {
    path: { type: 'string', required: true, description: 'File path (relative to CWD or absolute)' },
    content: { type: 'string', required: true, description: 'Content to write' },
  },

  async validateInput(input) {
    const { validateNotUNCPath, validateNoPathTraversal, composeValidations } = require('./inputValidators');
    return composeValidations(
      validateNotUNCPath(input.path),
      validateNoPathTraversal(input.path),
    );
  },

  getActivityDescription(input) {
    return `Writing to ${input.path || 'file'}`;
  },

  async execute(params, context) {
    try {
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      const filePath = path.resolve(cwd, params.path);
      const dir = path.dirname(filePath);

      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      fs.writeFileSync(filePath, params.content, 'utf-8');
      const bytes = Buffer.byteLength(params.content, 'utf-8');
      return { success: true, path: filePath, bytes };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },
});
