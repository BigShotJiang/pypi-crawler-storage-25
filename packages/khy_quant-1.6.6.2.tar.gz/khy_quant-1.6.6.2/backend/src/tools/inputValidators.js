/**
 * Input Validators — reusable semantic validation functions.
 *
 * These go beyond schema type checks. Any tool can use them in its
 * validateInput() method for security and safety checks.
 */
const fs = require('fs');
const path = require('path');

const { isBlockedDevicePath } = require('./shellClassifier');

// ── Default limits ─────────────────────────────────────────────────

const MAX_READ_FILE_SIZE = 500 * 1024;   // 500 KB
const MAX_EDIT_FILE_SIZE = 2 * 1024 * 1024; // 2 MB

// ── Validators ─────────────────────────────────────────────────────

/**
 * Block device paths that would hang or exhaust memory.
 * @param {string} filePath
 * @returns {{ valid: boolean, message?: string }}
 */
function validateNotDevicePath(filePath) {
  if (isBlockedDevicePath(filePath)) {
    return {
      valid: false,
      message: `Blocked: "${filePath}" is a device path that could cause the process to hang or exhaust memory.`,
    };
  }
  return { valid: true };
}

/**
 * Check file size before reading/editing.
 * @param {string} filePath - Resolved absolute path
 * @param {number} [maxBytes] - Maximum allowed file size
 * @returns {{ valid: boolean, message?: string }}
 */
function validateFileSize(filePath, maxBytes = MAX_READ_FILE_SIZE) {
  try {
    const stat = fs.statSync(filePath);
    if (stat.size > maxBytes) {
      const sizeMB = (stat.size / 1024 / 1024).toFixed(1);
      const maxMB = (maxBytes / 1024 / 1024).toFixed(1);
      return {
        valid: false,
        message: `File too large: ${sizeMB} MB (max ${maxMB} MB). Use a shell command to read specific portions.`,
      };
    }
  } catch {
    // File doesn't exist or can't be stat'd — let the tool handle that
  }
  return { valid: true };
}

/**
 * Detect no-op edits (old_string === new_string).
 * @param {string} oldStr
 * @param {string} newStr
 * @returns {{ valid: boolean, message?: string }}
 */
function validateNotNoop(oldStr, newStr) {
  if (oldStr === newStr) {
    return {
      valid: false,
      message: 'No-op edit: old_string and new_string are identical.',
    };
  }
  return { valid: true };
}

/**
 * Block UNC paths to prevent NTLM credential leakage.
 * On Windows, fs operations on UNC paths (\\server\share) trigger SMB
 * authentication, potentially leaking NTLM hashes to malicious servers.
 *
 * @param {string} filePath
 * @returns {{ valid: boolean, message?: string }}
 */
function validateNotUNCPath(filePath) {
  if (!filePath || typeof filePath !== 'string') return { valid: true };
  if (filePath.startsWith('\\\\') || filePath.startsWith('//')) {
    return {
      valid: false,
      message: 'Blocked: UNC network paths are not allowed (security: prevents NTLM credential leakage).',
    };
  }
  return { valid: true };
}

/**
 * Detect path traversal attempts that escape the working directory.
 * @param {string} filePath
 * @param {string} [baseCwd] - Base directory to enforce
 * @returns {{ valid: boolean, message?: string }}
 */
function validateNoPathTraversal(filePath, baseCwd) {
  if (!baseCwd) baseCwd = process.env.KHYQUANT_CWD || process.cwd();
  try {
    const resolved = path.resolve(baseCwd, filePath);
    const normalizedBase = path.resolve(baseCwd);
    if (!resolved.startsWith(normalizedBase)) {
      return {
        valid: false,
        message: `Path traversal detected: "${filePath}" resolves outside the working directory.`,
      };
    }
  } catch {
    // Path resolution failed — likely invalid path
  }
  return { valid: true };
}

/**
 * Run multiple validators in sequence. Stops at the first failure.
 * @param {...{ valid: boolean, message?: string }} results
 * @returns {{ valid: boolean, message?: string }}
 */
function composeValidations(...results) {
  for (const r of results) {
    if (!r.valid) return r;
  }
  return { valid: true };
}

module.exports = {
  validateNotDevicePath,
  validateFileSize,
  validateNotNoop,
  validateNotUNCPath,
  validateNoPathTraversal,
  composeValidations,
  MAX_READ_FILE_SIZE,
  MAX_EDIT_FILE_SIZE,
};
