const { defineTool } = require('./_baseTool');

module.exports = defineTool({
  name: 'strategyList',
  description: 'List all available trading strategies',
  category: 'data',
  risk: 'safe',
  isReadOnly: true,
  isConcurrencySafe: true,
  inputSchema: {},
  async execute(params, context) {
    try {
      const { handleStrategyList } = require('../cli/handlers/backtest');
      const result = await handleStrategyList();
      return { success: true, data: result };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },
});
