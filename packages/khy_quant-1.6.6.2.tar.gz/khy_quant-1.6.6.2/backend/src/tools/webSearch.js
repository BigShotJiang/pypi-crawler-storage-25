const { defineTool } = require('./_baseTool');

module.exports = defineTool({
  name: 'webSearch',
  description: 'Search the web for information using a query string',
  category: 'data',
  risk: 'low',
  isReadOnly: true,
  isConcurrencySafe: true,

  // Chapter 5 additions
  aliases: ['web_search', 'search_web'],
  shouldDefer: true,
  searchHint: 'search the web for information, news, documentation',

  async prompt() {
    return `Search the web for information using a query string.
Returns search results with titles, snippets, and URLs.
Use this when you need up-to-date information not in your training data.`;
  },

  inputSchema: {
    query: { type: 'string', required: true, description: 'Search query' },
  },
  async execute(params, context) {
    try {
      const webSearchService = require('../services/webSearchService');
      const result = await webSearchService.search(params.query);
      return { success: true, data: result };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },
});
