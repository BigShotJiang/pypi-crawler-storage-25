module.exports = require('../../../packages/shared/src/utils/logger');
