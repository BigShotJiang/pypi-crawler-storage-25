/**
 * Interactive REPL — the heart of the CLI.
 * Combines command mode, menu mode, and AI conversation mode.
 *
 * All heavy modules are lazy-loaded for fast cold start.
 */
const readline = require('readline');
const fs = require('fs');
const path = require('path');

// ── Lazy module loaders (Claude-style: zero top-level heavy requires) ──
let _chalk, _inquirer, _formatters, _router, _ai, _menu, _userProfile;
const chalk = () => (_chalk ??= require('chalk'));
const inquirer = () => (_inquirer ??= require('inquirer'));
const fmt = () => (_formatters ??= require('./formatters'));
const router = () => (_router ??= require('./router'));
const ai = () => (_ai ??= require('./ai'));
const menu = () => (_menu ??= require('./menu'));
const userProfile = () => (_userProfile ??= require('../services/userProfile'));

const os = require('os');
const HISTORY_FILE = path.join(os.homedir(), '.khyquant_history');
const MAX_HISTORY = 500;
const VERSION = process.env.KHYQUANT_PKG_VERSION || require('../../package.json').version;

// ── Terminal title (ANSI escape) ────────────────────────────────────────

function setTerminalTitle(title) {
  if (process.stdout.isTTY) {
    process.stdout.write(`\x1b]0;${title}\x07`);
  }
}

function updateTitleFromConversation(userMessage) {
  const topic = (userMessage || '').replace(/\n/g, ' ').slice(0, 30).trim();
  setTerminalTitle(topic ? `KHY-Quant · ${topic}` : 'KHY-Quant');
}

/**
 * Load command history from file.
 */
function loadHistory() {
  try {
    if (fs.existsSync(HISTORY_FILE)) {
      return fs.readFileSync(HISTORY_FILE, 'utf-8').split('\n').filter(Boolean);
    }
  } catch { /* ignore */ }
  return [];
}

/**
 * Save command history to file.
 */
function saveHistory(history) {
  try {
    const lines = history.slice(-MAX_HISTORY);
    fs.writeFileSync(HISTORY_FILE, lines.join('\n') + '\n');
  } catch { /* ignore */ }
}

/**
 * Offer interactive model selection at startup.
 * Shows a dropdown if multiple adapters/models are available.
 */
async function offerModelSelection() {
  try {
    const aiGateway = require('../services/gateway/aiGateway');

    // Quick sync detection of available adapters
    const allStatus = aiGateway.getStatus();
    const availableAdapters = allStatus.filter(s => s.enabled && s.available);

    if (availableAdapters.length === 0) return;

    // Gather models from all available adapters that support listModels
    const modelChoices = [];
    for (const adapter of availableAdapters) {
      if (adapter.refreshModels) {
        try {
          const models = await adapter.refreshModels();
          for (const model of models) {
            modelChoices.push({
              name: `${adapter.name} → ${model.name || model.id}${model.isDefault ? ' (默认)' : ''}`,
              value: { adapter: adapter.type, model: model.id },
            });
          }
        } catch { /* skip */ }
      } else {
        // Adapter without model list — add as single entry
        modelChoices.push({
          name: `${adapter.name}`,
          value: { adapter: adapter.type, model: null },
        });
      }
    }

    if (modelChoices.length <= 1) return; // No choice needed

    // Check if user has a saved preference — skip selection if so
    const currentAdapter = process.env.GATEWAY_PREFERRED_ADAPTER;
    const currentModel = process.env.GATEWAY_PREFERRED_MODEL;
    if (currentAdapter && currentModel) {
      // Already configured, show current and offer quick switch
      fmt().printInfo(`当前模型: ${currentAdapter}/${currentModel} — 输入 gateway model 切换`);
      return;
    }

    // Show interactive selection
    const inq = inquirer();
    console.log('');
    const { selected } = await inq.prompt([{
      type: 'list',
      name: 'selected',
      message: '选择 AI 模型 (上下箭头选择，回车确认，Esc跳过):',
      choices: [
        ...modelChoices,
        new inq.Separator(),
        { name: '跳过 (稍后用 gateway model 设置)', value: null },
      ],
      pageSize: 10,
    }]);

    if (selected) {
      process.env.GATEWAY_PREFERRED_ADAPTER = selected.adapter;
      if (selected.model) process.env.GATEWAY_PREFERRED_MODEL = selected.model;
      fmt().printSuccess(`已选择: ${selected.adapter}${selected.model ? '/' + selected.model : ''}`);
    }
  } catch {
    // Non-critical — silently skip if anything fails
  }
}

/**
 * Execute a menu result by mapping it back to command handlers.
 */
async function executeMenuResult(result) {
  if (!result) return;

  switch (result.action) {
    case 'quote': {
      const { handleQuote } = require('./handlers/data');
      await handleQuote(result.symbol);
      break;
    }
    case 'backtest-run': {
      const { handleBacktestRun } = require('./handlers/backtest');
      await handleBacktestRun(result.symbol, {
        strategy: result.strategy,
        start: result.start,
        end: result.end,
        capital: result.capital,
      });
      break;
    }
    case 'data-fetch': {
      const { handleDataFetch } = require('./handlers/data');
      await handleDataFetch(result.symbol);
      break;
    }
    case 'data-list': {
      const { handleDataList } = require('./handlers/data');
      await handleDataList();
      break;
    }
    case 'cache-clear': {
      const { handleCacheClear } = require('./handlers/data');
      await handleCacheClear();
      break;
    }
    case 'server-start': {
      const { handleServerStart } = require('./handlers/service');
      await handleServerStart();
      break;
    }
    case 'server-status': {
      const { handleServerStatus } = require('./handlers/service');
      await handleServerStatus();
      break;
    }
    case 'db-init': {
      const { handleDbInit } = require('./handlers/service');
      await handleDbInit();
      break;
    }
    case 'db-seed': {
      const { handleDbSeed } = require('./handlers/service');
      await handleDbSeed();
      break;
    }
    case 'db-status': {
      const { handleDbStatus } = require('./handlers/service');
      await handleDbStatus();
      break;
    }
    case 'ai-status':
      await ai().handleAiStatus();
      break;
    case 'ai-config':
      await ai().handleAiConfig();
      break;
    case 'doctor': {
      const { handleDoctor } = require('./handlers/init');
      await handleDoctor();
      break;
    }
    case 'gateway-status': {
      const { handleGatewayStatus } = require('./handlers/gateway');
      await handleGatewayStatus();
      break;
    }
    case 'gateway-config': {
      const { handleGatewayConfig } = require('./handlers/gateway');
      await handleGatewayConfig();
      break;
    }
    case 'gateway-relay': {
      const { handleGatewayRelay } = require('./handlers/gateway');
      await handleGatewayRelay();
      break;
    }
    case 'gateway-select-model': {
      const { handleGatewaySelectModel } = require('./handlers/gateway');
      await handleGatewaySelectModel();
      break;
    }
    case 'docs-quickstart': {
      const { handleDocsQuickstart } = require('./handlers/docs');
      await handleDocsQuickstart();
      break;
    }
    case 'docs-claude': {
      const { handleDocsClaude } = require('./handlers/docs');
      await handleDocsClaude();
      break;
    }
    case 'docs-gateway': {
      const { handleDocsGateway } = require('./handlers/docs');
      await handleDocsGateway();
      break;
    }
    case 'docs-strategy': {
      const { handleDocsStrategy } = require('./handlers/docs');
      await handleDocsStrategy();
      break;
    }
    case 'docs-faq': {
      const { handleDocsFaq } = require('./handlers/docs');
      await handleDocsFaq();
      break;
    }
  }
}

/**
 * Start the interactive REPL loop.
 */
async function startRepl() {
  // Load formatters + chalk now (needed for REPL UI)
  const { printBanner, printError, printSuccess, printInfo, printWarn, ICON_PROMPT, ICON_BOT, MASCOT_MINI, getRandomFarewell } = fmt();
  const c = chalk();
  const { parseInput, route, getCompletions } = router();

  // Load renderer constants for inline use
  const { DOT_PENDING, DOT_ACTIVE, DOT_SUCCESS, DOT_ERROR } = require('./aiRenderer');
  const TREE_LAST = '└';

  // Set terminal window title
  setTerminalTitle('KHY-Quant');

  // Show banner
  const aiProvider = ai().getActiveProvider();
  printBanner(VERSION, aiProvider);

  // Display first-run getting-started guide (only on first ever launch)
  try {
    const gettingStarted = require('../services/gettingStartedService');
    gettingStarted.displayGettingStarted();
  } catch { /* non-critical */ }

  // Initialize proxy configuration from saved settings
  try {
    const proxyConfig = require('../services/proxyConfigService');
    proxyConfig.initFromConfig();
  } catch { /* proxy init is non-critical */ }

  // Auto-resume last session if recent (within 24h)
  try {
    const resumeResult = ai().autoResumeLastSession();
    if (resumeResult && resumeResult.resumed) {
      const timeAgo = new Date(resumeResult.timestamp).toLocaleString('zh-CN');
      printInfo(`已自动恢复上次对话 (${resumeResult.messageCount} 条消息, ${timeAgo})`);
    }
  } catch { /* auto-resume is non-critical */ }

  // ── State variables (must be before setTimeout calls and renderStatusBar) ──
  let _busy = false;
  let _planMode = false;
  let _ctrlCCount = 0;
  let _ctrlCTimer = null;
  let _recentCommands = [];
  const PATTERN_WINDOW = 5;
  let _startupTimers = [];

  // ── Deferred prefetch: all non-blocking startup tasks in one place ─────
  // Replaces 8+ individual setTimeout calls with a single managed module.
  // Falls back to empty array if the bootstrap module is not available.
  try {
    const { deferredPrefetch } = require('../bootstrap/prefetch');
    _startupTimers = deferredPrefetch({
      mode: 'khyquant',
      isBusy: () => _busy,
      onOutput: (msg) => {
        if (!_busy) {
          console.log(msg);
          try { rl.prompt(); } catch { /* ignore */ }
        }
      },
    });
  } catch {
    // Fallback: if bootstrap module unavailable, no deferred tasks.
    // This should never happen in normal operation but ensures safety.
  }

  // Offer interactive model selection if multiple models are available
  await offerModelSelection();

  // Setup readline
  const history = loadHistory();

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: c.cyan(MASCOT_MINI + ' khyquant') + c.dim(` ${ICON_PROMPT} `),
    historySize: MAX_HISTORY,
    completer: (line) => {
      const completions = getCompletions(line);
      return [completions.length > 0 ? completions : [], line];
    },
  });

  // Prepopulate history
  history.forEach(line => rl.history.push(line));

  // ── Exit handling ──
  // IMPORTANT: Do NOT add any keypress listener on rl.input / process.stdin.
  // readline internally calls emitKeypressEvents on its input stream.
  // Adding another 'keypress' listener causes every character to echo twice
  // because the keypress event fires for both readline's internal handler
  // and our external handler, each triggering a write to stdout.
  // The SIGINT handler (Ctrl+C double-press to exit) is registered later
  // in this function, after all state variables are initialized.

  // ── Prompt Frame (Claude Code style: upper line + branch badge + lower line) ──
  let _statusBarEnabled = process.stdout.isTTY && process.stdout.columns > 60;
  let _currentOp = '';        // Active operation name (shown during AI work)
  let _requestStart = 0;      // Timestamp when current operation started
  let _sessionTokens = 0;     // Running token count for display
  let _queryEngine = null;    // QueryEngine singleton (KHY_QUERY_ENGINE mode)

  // ANSI cursor helpers
  const SAVE_CURSOR    = '\x1b[s';
  const RESTORE_CURSOR = '\x1b[u';
  const CLEAR_LINE     = '\x1b[K';
  const moveTo = (row, col) => `\x1b[${row};${col}H`;

  // Rotating tips
  const TIPS = [
    '/btw 在 AI 工作时插入不打断的提示',
    '/review 自动多轮代码审查',
    '/cost 查看 AI 费用统计',
    '/model 快速切换 AI 模型',
    '/plan 生成执行计划再动手',
    '/hud 展开完整仪表盘',
    'pool list 管理 AI 账号池',
    'image <路径> 图片分析',
  ];
  let _tipIdx = 0;
  const _tipTimer = setInterval(() => { _tipIdx = (_tipIdx + 1) % TIPS.length; }, 30000);

  /**
   * Render the upper status line (2 rows above prompt).
   * Busy: operation name + elapsed + tokens.
   * Idle: provider status + tip.
   */
  function renderUpperLine() {
    if (!_statusBarEnabled) return;
    const cols = process.stdout.columns || 80;

    let statusText, tipText;
    if (_busy && _currentOp) {
      const elapsed = ((Date.now() - _requestStart) / 1000).toFixed(0);
      const tokStr = _sessionTokens > 0 ? ` · ↓ ${_sessionTokens.toLocaleString()} tokens` : '';
      statusText = `· ${_currentOp}… (${elapsed}s${tokStr})`;
    } else {
      const provider = ai().getActiveProvider() || 'AI';
      statusText = `· 就绪 · ${provider}`;
    }
    tipText = `└ ${TIPS[_tipIdx]}`;

    // Write two lines above current cursor position, then move back
    process.stdout.write(
      SAVE_CURSOR +
      `\x1b[2A\r${CLEAR_LINE}${c.dim(statusText)}` +
      `\n${CLEAR_LINE}${c.dim(tipText)}` +
      RESTORE_CURSOR
    );
  }

  /**
   * Render git branch badge in top-right corner of terminal.
   * Uses Unicode box drawing: ┌─┐ │ │ └─┘
   */
  function renderBranchBadge() {
    if (!_statusBarEnabled) return;
    const cols = process.stdout.columns || 80;

    // Refresh git info (cached, 30s TTL)
    const hud = require('./hudRenderer');
    hud.refreshGit();
    const { git } = hud.getState();
    if (!git.branch) return;

    const dirty = git.dirty ? '*' : '';
    const text = `${git.branch}${dirty}`;
    const boxWidth = text.length + 2; // +2 for padding spaces

    const top    = `┌${'─'.repeat(boxWidth)}┐`;
    const middle = `│ ${text} │`;
    const bottom = `└${'─'.repeat(boxWidth)}┘`;

    const startCol = Math.max(1, cols - top.length + 1);

    process.stdout.write(
      SAVE_CURSOR +
      moveTo(1, startCol) + c.cyan(top) +
      moveTo(2, startCol) + c.cyan(middle) +
      moveTo(3, startCol) + c.cyan(bottom) +
      RESTORE_CURSOR
    );
  }

  /**
   * Render the lower mode/shortcut line (below prompt).
   * Shows mode tags + keyboard hints.
   */
  function renderLowerLine() {
    if (!_statusBarEnabled) return;

    const parts = [];
    if (_planMode) parts.push(c.yellow('⏸ plan mode'));
    if (_busy) {
      parts.push(c.dim('esc 中断'));
    } else {
      parts.push(c.dim('/help 帮助'));
      parts.push(c.dim('/review 审查'));
      parts.push(c.dim('2×Ctrl+C 退出'));
    }

    const line = parts.join(c.dim(' · '));
    // Write one line below prompt, then move cursor back up to prompt line end
    process.stdout.write('\n' + CLEAR_LINE + line + '\x1b[1A\x1b[999C');
  }

  /**
   * Render the full prompt frame: upper line → branch badge → (prompt) → lower line.
   * Called after rl.prompt() to paint the surrounding chrome.
   */
  function renderPromptFrame() {
    if (!_statusBarEnabled) return;
    renderUpperLine();
    renderBranchBadge();
    renderLowerLine();
  }

  // Wrap rl.prompt to inject the frame
  const _origPrompt = rl.prompt.bind(rl);
  rl.prompt = (...args) => {
    // Reserve 2 blank lines above for the upper status line
    if (_statusBarEnabled) {
      process.stdout.write('\n\n');
    }
    _origPrompt(...args);
    renderPromptFrame();
  };

  // Handle terminal resize
  if (process.stdout.on) {
    process.stdout.on('resize', () => {
      _statusBarEnabled = process.stdout.isTTY && process.stdout.columns > 60;
      renderPromptFrame();
    });
  }

  rl.prompt();

  // Track session start
  userProfile().trackSessionStart();

  // Non-blocking startup tasks (cloudSync, adminService, skillLearning,
  // securityGuard) are now handled by deferredPrefetch() above.

  // /btw hint queue — non-interrupting hints queued while AI is working
  let _btwQueue = [];

  rl.on('line', async (line) => {
    const trimmed = line.trim();
    if (!trimmed) {
      rl.prompt();
      return;
    }

    // Slash command menu — when user types exactly "/"
    if (trimmed === '/') {
      try {
        const inq = inquirer();
        console.log('');

        // Try category-grouped menu via commandRegistry
        let choices;
        try {
          const cmdReg = require('./commandRegistry');
          const byCat = cmdReg.getByCategory();
          const catNames = cmdReg.CATEGORIES || {};
          choices = [];
          for (const [cat, cmds] of Object.entries(byCat)) {
            if (cmds.length === 0) continue;
            choices.push(new inq.Separator(c.bold.white(`── ${catNames[cat] || cat} ──`)));
            for (const sc of cmds) {
              choices.push({
                name: `${c.cyan(sc.cmd.padEnd(14))} ${sc.label.padEnd(10)} ${c.dim(sc.desc)}`,
                value: sc,
              });
            }
          }
        } catch {
          // Fallback to flat list from router
          const { SLASH_COMMANDS } = router();
          choices = SLASH_COMMANDS.map(sc => ({
            name: `${c.cyan(sc.cmd.padEnd(14))} ${sc.label.padEnd(10)} ${c.dim(sc.desc)}`,
            value: sc,
          }));
        }

        const { selected } = await inq.prompt([{
          type: 'list',
          name: 'selected',
          message: '选择命令:',
          choices,
          pageSize: 18,
          loop: false,
        }]);

        if (selected) {
          if (selected.flag) {
            // Handle special flags
            if (selected.flag.startsWith('effort-')) {
              const level = selected.flag.replace('effort-', '');
              if (ai().setEffort(level)) {
                const presets = ai().getEffortPresets();
                const p = presets[level];
                printSuccess(`模型精度已切换: ${level} (${p.label}) — temp=${p.temperature}, maxTokens=${p.maxTokens}`);
              }
            } else if (selected.flag === 'plan') {
              // Enter plan mode — next AI call will generate a structured plan
              _planMode = true;
              printInfo('计划模式已开启 — 下次 AI 回复将先制定执行计划');
            } else if (selected.flag === 'image') {
              // Prompt for image file path
              printInfo('用法: image <文件路径> <分析提示>  或  paste <分析提示>');
            } else if (selected.flag === 'paste') {
              // Trigger clipboard paste
              _btwQueue.push('paste');
              printInfo('已排队剪贴板粘贴 — 下次输入时自动执行');
            } else if (selected.flag === 'clipboard') {
              // Clipboard relay status and instructions
              try {
                const clipAdapter = require('../services/gateway/adapters/clipboardRelayAdapter');
                const status = clipAdapter.getStatus();
                if (status.available) {
                  printSuccess(status.detail);
                } else {
                  printError(status.detail);
                }
                printInfo('用法: clipboard relay <提示>  或  webai <提示>');
                printInfo('管理: clipboard relay list / set <服务> / open');
              } catch (e) {
                printError(`剪贴板中继不可用: ${e.message}`);
              }
            } else if (selected.flag === 'websearch') {
              // Web search via Kiro InvokeMCP
              try {
                const webSearch = require('../services/webSearchService');
                if (!webSearch.isAvailable()) {
                  printError('联网搜索不可用 — 需要 Kiro IDE 认证 (请先登录 Kiro)');
                } else {
                  const { query } = await inquirer().prompt([{
                    type: 'input', name: 'query', message: '搜索关键词:',
                    validate: v => v.trim() ? true : '请输入搜索关键词',
                  }]);
                  printInfo(`正在搜索: ${query}`);
                  const result = await webSearch.search(query);
                  if (result.success) {
                    console.log('');
                    console.log(c.bold.cyan('  🔍 搜索结果'));
                    console.log(c.dim('  ─'.repeat(30)));
                    for (const r of (result.results || []).slice(0, 10)) {
                      console.log('');
                      console.log(c.bold.white(`  ${r.title}`));
                      if (r.url) console.log(c.blue(`  ${r.url}`));
                      if (r.snippet) console.log(c.gray(`  ${r.snippet}`));
                      if (r.publishedDate) console.log(c.dim(`  ${r.publishedDate}`));
                    }
                    console.log('');
                  } else {
                    printError(result.error || '搜索失败');
                  }
                }
              } catch (e) {
                printError(`搜索失败: ${e.message}`);
              }
            } else if (selected.flag === 'proxy') {
              // Proxy configuration (Clash / HTTP / SOCKS5)
              try {
                const proxyConfig = require('../services/proxyConfigService');
                const status = proxyConfig.getStatus();
                if (status.active) {
                  printSuccess(`代理已启用: ${status.url}`);
                  const { action } = await inquirer().prompt([{
                    type: 'list', name: 'action', message: '代理操作:',
                    choices: [
                      { name: '关闭代理', value: 'off' },
                      { name: '重新检测 Clash', value: 'detect' },
                      { name: '取消', value: 'cancel' },
                    ],
                  }]);
                  if (action === 'off') { proxyConfig.disableProxy(); printSuccess('代理已关闭'); }
                  else if (action === 'detect') {
                    const r = await proxyConfig.autoDetectAndEnable();
                    r.success ? printSuccess(`已检测并启用: ${r.proxy.url}`) : printError(r.error);
                  }
                } else {
                  const { action } = await inquirer().prompt([{
                    type: 'list', name: 'action', message: '代理设置:',
                    choices: [
                      { name: '自动检测 Clash', value: 'detect' },
                      { name: '手动配置 HTTP 代理', value: 'http' },
                      { name: '手动配置 SOCKS5 代理', value: 'socks5' },
                      { name: '取消', value: 'cancel' },
                    ],
                  }]);
                  if (action === 'detect') {
                    printInfo('正在检测 Clash...');
                    const r = await proxyConfig.autoDetectAndEnable();
                    r.success ? printSuccess(`已检测并启用: ${r.proxy.url}`) : printError(r.error);
                  } else if (action === 'http' || action === 'socks5') {
                    const { port } = await inquirer().prompt([{
                      type: 'input', name: 'port', message: `端口 (默认 ${action === 'http' ? '7890' : '1080'}):`,
                      default: action === 'http' ? '7890' : '1080',
                    }]);
                    const r = await proxyConfig.enableProxy({ type: action, host: '127.0.0.1', port });
                    r.success ? printSuccess(`代理已启用: ${r.proxy.url}`) : printError(r.error);
                  }
                }
              } catch (e) { printError(`代理配置失败: ${e.message}`); }
            } else if (selected.flag === 'models') {
              // Ollama / NVIDIA model management
              try {
                const ollamaMgr = require('../services/ollamaModelManager');
                const running = await ollamaMgr.isOllamaRunning();
                const hw = ollamaMgr.detectHardware();

                console.log('');
                printInfo(`硬件: ${hw.totalRamGB} GB RAM · ${hw.cpuCount} CPUs` + (hw.gpu ? ` · GPU: ${hw.gpu.name} (${(hw.gpu.vramMB / 1024).toFixed(1)} GB)` : ''));
                printInfo(`硬件等级: ${hw.tier.toUpperCase()} — Ollama ${running ? c.green('运行中') : c.yellow('未运行')}`);
                console.log('');

                if (running) {
                  const models = await ollamaMgr.listModels();
                  if (models.length > 0) {
                    printSuccess(`已安装 ${models.length} 个模型:`);
                    for (const m of models) {
                      console.log(c.dim(`    ${m.name}  (${m.size}, ${m.paramSize})`));
                    }
                  } else {
                    printInfo('暂无已安装模型');
                  }
                }

                const { recommended } = ollamaMgr.getRecommendations();
                console.log('');
                printInfo(`推荐模型 (${hw.tier} 级别):`);
                const choices = recommended.map((m, i) => ({
                  name: `${m.name} (${m.size}) — ${m.reason}`,
                  value: m.id,
                }));
                choices.push({ name: '取消', value: 'cancel' });

                const { modelId } = await inquirer().prompt([{
                  type: 'list', name: 'modelId', message: '选择要下载的模型:',
                  choices,
                }]);

                if (modelId !== 'cancel' && running) {
                  printInfo(`正在下载 ${modelId}...`);
                  await ollamaMgr.pullModel(modelId, (progress) => {
                    if (progress.total > 0 && process.stdout.isTTY) {
                      process.stdout.write(`\r  ⟳ ${progress.status} ${progress.percent}%`);
                    }
                  });
                  console.log('');
                  printSuccess(`模型 ${modelId} 下载完成!`);
                } else if (modelId !== 'cancel') {
                  printError('Ollama 未运行。请先安装并启动: https://ollama.ai');
                  printInfo(`或手动执行: ollama pull ${modelId}`);
                }
              } catch (e) { printError(`模型管理失败: ${e.message}`); }
            } else if (selected.flag === 'scan') {
              // Antivirus scan
              try {
                const av = require('../services/antivirusService');
                const tools = av.detectTools();
                if (!tools.hasClamAV) {
                  printError('ClamAV 未安装');
                  const inst = av.getInstallInstructions();
                  printInfo(`安装命令: ${inst.install}`);
                } else {
                  printInfo('正在扫描项目文件...');
                  const result = av.scanProject();
                  if (result.clean) {
                    printSuccess(`扫描完成: 未发现威胁 (${(result.elapsed / 1000).toFixed(1)}s)`);
                  } else {
                    printError(`发现 ${result.infected} 个威胁!`);
                    for (const t of result.threats) {
                      console.log(c.red(`    ${t.virus} → ${t.file}`));
                    }
                    printInfo('已隔离到 ~/.khyquant/quarantine/');
                  }
                }
              } catch (e) { printError(`扫描失败: ${e.message}`); }
            } else if (selected.flag === 'security-full') {
              // Full security status
              try {
                const secGuard = require('../services/securityGuardService');
                const integrity = require('../services/fileIntegrityService');
                const resGuard = require('../services/resourceGuard');

                // 1. File integrity
                console.log('');
                printInfo('文件完整性校验...');
                const intResult = integrity.verify();
                if (intResult.verified) {
                  printSuccess(`完整性: ${intResult.unchanged} 文件无改动`);
                } else {
                  printError(`完整性异常: ${intResult.modified.length} 修改, ${intResult.removed.length} 删除`);
                  for (const f of intResult.modified.slice(0, 5)) console.log(c.yellow(`    修改: ${f}`));
                  for (const f of intResult.removed.slice(0, 5)) console.log(c.red(`    删除: ${f}`));
                }
                if (intResult.added.length > 0) {
                  printInfo(`新增文件: ${intResult.added.length} (正常更新)`);
                }

                // 2. Threat scan
                printInfo('威胁扫描...');
                const threats = secGuard.scanForThreats();
                if (threats.clean) {
                  printSuccess('威胁扫描: 未发现异常');
                } else {
                  printError(`发现 ${threats.threats.length} 个威胁:`);
                  for (const t of threats.threats) {
                    console.log(c.red(`    [${t.severity}] ${t.type}: ${t.detail}`));
                  }
                }

                // 3. System health
                const health = resGuard.systemHealthCheck();
                if (health.healthy) {
                  printSuccess('系统资源: 正常');
                } else {
                  for (const w of health.warnings) printWarn(w);
                }

                // 4. Security stats
                const stats = secGuard.getSecurityStats();
                if (stats.totalEvents > 0) {
                  printInfo(`安全事件: ${stats.totalEvents} 总计, ${stats.last24h} 近24小时`);
                }
                console.log('');
              } catch (e) { printError(`安全检查失败: ${e.message}`); }
            } else if (selected.flag === 'hardware') {
              // Hardware info and local model recommendations
              try {
                const hw = require('../services/hardwareProfileService');
                const { lines, profile } = hw.getHardwareSummary();

                console.log('');
                printInfo('硬件配置:');
                for (const line of lines) console.log(c.dim(`    ${line}`));
                console.log('');

                if (profile.localModels.length > 0) {
                  printInfo('推荐本地模型:');
                  for (const m of profile.localModels) {
                    const rec = m.recommended ? c.green(' ★ 推荐') : '';
                    if (m.recommendation === 'api-only') {
                      console.log(c.yellow(`    ${m.reason}`));
                    } else {
                      console.log(c.dim(`    ${m.name} (${m.sizeGB}GB)`) + rec);
                      console.log(c.dim(`      ${m.reason}`));
                    }
                  }
                }

                console.log('');
                printInfo('资源限制:');
                const lim = profile.limits;
                console.log(c.dim(`    Node.js 堆: ${lim.nodeHeapMB}MB`));
                console.log(c.dim(`    并发数: ${lim.maxConcurrency}`));
                console.log(c.dim(`    多智能体: ${lim.enableMultiAgent ? '启用' : '禁用'}`));
                console.log(c.dim(`    本地模型: ${lim.enableLocalModel ? '启用' : '禁用'}`));
                console.log('');
              } catch (e) { printError(`硬件检测失败: ${e.message}`); }
            } else if (selected.flag === 'review') {
              // Multi-round AI code review
              try {
                const { handleReview } = require('./handlers/review');
                _busy = true;
                await handleReview();
                _busy = false;
              } catch (e) { printError(`代码审查失败: ${e.message}`); _busy = false; }
            } else if (selected.flag === 'subscribe') {
              // Show AI subscription guide
              try {
                const { handleDocsSubscription } = require('./handlers/docs');
                await handleDocsSubscription();
              } catch (e) { printError(`显示订阅指引失败: ${e.message}`); }
            }
          } else if (selected.route) {
            // Parse and execute the route command
            const cmdParsed = parseInput(selected.route);
            if (cmdParsed) {
              const result = await route(cmdParsed);
              if (result === 'exit') {
                ai().saveConversation();
                saveHistory(history);
                setTerminalTitle('');
                console.log('');
                console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
                console.log(c.dim('  对话已保存'));
                console.log('');
                process.exit(0);
              }
            }
          }
        }
      } catch { /* menu cancelled or error */ }
      rl.prompt();
      return;
    }

    // /btw — queue hint without interrupting current AI work
    if (trimmed.startsWith('/btw ')) {
      const hint = trimmed.slice(5).trim();
      if (hint) {
        _btwQueue.push(hint);
        console.log(c.dim(`  📌 提示已排队 (当前队列: ${_btwQueue.length})`));
      }
      rl.prompt();
      return;
    }

    // /max, /high, /medium, /low — effort level switching
    const effortMatch = trimmed.match(/^\/(max|high|medium|low)$/);
    if (effortMatch) {
      const level = effortMatch[1];
      if (ai().setEffort(level)) {
        const presets = ai().getEffortPresets();
        const p = presets[level];
        printSuccess(`模型精度已切换: ${level} (${p.label}) — temp=${p.temperature}, maxTokens=${p.maxTokens}`);
      } else {
        printError('无效的精度级别');
      }
      rl.prompt();
      return;
    }

    // ── Clipboard relay commands ──────────────────────────────────
    const clipRelayMatch = /^(?:clipboard\s+relay|剪贴板中继|webai)(?:\s+(.+))?$/i.exec(trimmed);
    if (clipRelayMatch) {
      const subCmd = (clipRelayMatch[1] || '').trim().toLowerCase();

      try {
        const clipAdapter = require('../services/gateway/adapters/clipboardRelayAdapter');

        // Sub-commands: service list, service set, open, or direct prompt
        if (subCmd === 'list' || subCmd === '列表') {
          const services = clipAdapter.getServices();
          const current = clipAdapter.getPreferredService();
          printInfo('可用的 Web AI 服务:');
          for (const [key, svc] of Object.entries(services)) {
            const marker = key === current ? c.green(' ← 当前') : '';
            console.log(`  ${c.cyan(key.padEnd(10))} ${svc.name.padEnd(20)} ${c.dim(svc.url)}${marker}`);
          }
        } else if (subCmd.startsWith('set ') || subCmd.startsWith('切换 ')) {
          const serviceKey = subCmd.replace(/^(set|切换)\s+/i, '').trim();
          if (clipAdapter.setService(serviceKey)) {
            const services = clipAdapter.getServices();
            printSuccess(`已切换到 ${services[serviceKey].name}`);
          } else {
            printError(`未知服务: ${serviceKey} — 运行 clipboard relay list 查看可用服务`);
          }
        } else if (subCmd === 'open' || subCmd === '打开') {
          const services = clipAdapter.getServices();
          const current = clipAdapter.getPreferredService();
          const svc = services[current];
          clipAdapter.openBrowser(svc.url);
          printInfo(`已打开 ${svc.name}: ${svc.url}`);
        } else if (subCmd === 'status' || subCmd === '状态' || !subCmd) {
          const status = clipAdapter.getStatus();
          if (status.available) {
            printSuccess(status.detail);
          } else {
            printError(status.detail);
          }
        } else {
          // Treat as a prompt to relay via clipboard
          _busy = true;
          try {
            const result = await clipAdapter.generate(subCmd);
            if (result.success) {
              const renderer = require('./aiRenderer');
              renderer.printStepLine('success', '剪贴板 AI 回复', result.provider);
              console.log(c.dim('  ┌──'));
              const rendered = renderer.renderAiResponse(result.content);
              rendered.split('\n').forEach(l => console.log(c.dim('  │ ') + l));
              console.log(c.dim('  └──'));
            } else {
              printError(result.content);
            }
          } finally {
            _busy = false;
          }
        }
      } catch (err) {
        printError(`剪贴板中继失败: ${err.message}`);
      }
      rl.prompt();
      return;
    }

    // Image analysis — file path or clipboard paste
    const imageMatch = trimmed.match(/^(?:image|图片|img)\s+(.+?\.(png|jpg|jpeg|gif|webp))\s*(.*)/i);
    const pasteMatch = /^(?:paste|粘贴|clipboard|剪贴板)(?:\s+(.*))?$/i.exec(trimmed);

    if (imageMatch || pasteMatch) {
      try {
        const imageService = require('../services/imageService');
        const renderer = require('./aiRenderer');
        let image, prompt;

        if (imageMatch) {
          // File path mode
          const filePath = imageMatch[1];
          prompt = imageMatch[3] || '请分析这张图片';
          renderer.printToolCallStart('Read', { path: filePath });
          const readStart = Date.now();
          image = imageService.readImageFromFile(filePath);
          renderer.printToolCallResult('Read', { path: filePath }, 'success',
            `${image.format.toUpperCase()}, ${(image.sizeBytes / 1024).toFixed(0)}KB`,
            Date.now() - readStart
          );
        } else {
          // Clipboard paste mode
          prompt = pasteMatch[1] || '请分析这张图片';
          renderer.printToolCallStart('Clipboard', '读取剪贴板图片');
          const readStart = Date.now();
          image = imageService.readImageFromClipboard();
          renderer.printToolCallResult('Clipboard', '剪贴板', 'success',
            `${image.format.toUpperCase()}, ${(image.sizeBytes / 1024).toFixed(0)}KB`,
            Date.now() - readStart
          );
        }

        // Show preview
        imageService.printImagePreview(image);

        // Send to AI with vision
        _busy = true;
        const tracker = new renderer.ProcessTracker();
        tracker.start('请求 AI', ai().getActiveProvider() || 'Vision AI');

        const aiResult = await ai().chat(prompt, {
          images: [{ base64: image.base64, mimeType: image.mimeType }],
        });

        if (tracker.isActive) tracker.complete();

        if (aiResult.reply) {
          renderer.printStepLine('success', 'AI 图片分析', aiResult.provider || 'vision');
          console.log(c.dim('  ┌──'));
          const rendered = renderer.renderAiResponse(aiResult.reply);
          rendered.split('\n').forEach(l => console.log(c.dim('  │ ') + l));
          console.log(c.dim('  └──'));
        } else {
          printInfo('AI 未返回分析结果 — 当前 AI 服务可能不支持图片分析');
        }
        console.log('');
      } catch (imgErr) {
        printError(`图片处理失败: ${imgErr.message}`);
      } finally {
        _busy = false;
      }
      rl.prompt();
      return;
    }

    // Prevent concurrent command execution
    if (_busy) {
      // Queue input without interrupting current work (like Claude Code's /btw)
      _btwQueue.push(trimmed);
      console.log(c.dim(`  ${DOT_PENDING} 已排队: "${trimmed.slice(0, 40)}${trimmed.length > 40 ? '...' : ''}" (队列: ${_btwQueue.length})`));
      console.log(c.dim(`    ${TREE_LAST} AI 完成当前工作后自动处理，Ctrl+C 可中断`));
      return;
    }
    _busy = true;

    // Save to history
    history.push(trimmed);

    // Parse and route the command
    const parsed = parseInput(trimmed);
    if (!parsed) {
      _busy = false;
      rl.prompt();
      return;
    }

    try {
      const result = await route(parsed);

      // Clear QueryEngine history when user clears screen
      if (parsed.command === 'clear' && _queryEngine) {
        try { _queryEngine.clearHistory(); } catch {}
      }

      if (result === 'exit') {
        ai().saveConversation();
        saveHistory(history);
        setTerminalTitle(''); // restore terminal title
        console.log('');
        console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
        console.log(c.dim('  对话已保存，下次输入 resume 恢复上下文'));
        console.log('');
        process.exit(0);
      }

      if (result === 'menu') {
        let menuResult;
        do {
          menuResult = await menu().runMenuLoop();
          await executeMenuResult(menuResult);
        } while (menuResult !== null);
        rl.prompt();
        return;
      }

      if (result === 'ai-status') {
        await ai().handleAiStatus();
        rl.prompt();
        return;
      }

      if (result === 'ai-config') {
        await ai().handleAiConfig();
        rl.prompt();
        return;
      }

      if (result === 'ai-on' || result === 'ai-off') {
        // AI is always on — no manual toggle needed
        printInfo('AI 对话已默认开启，无需手动切换');
        rl.prompt();
        return;
      }

      if (result === true) {
        // Command was handled — track it
        if (parsed && parsed.command) userProfile().trackCommand(parsed.command);

        // Record command sequence for pattern learning
        if (parsed && parsed.command) {
          _recentCommands.push(trimmed);
          if (_recentCommands.length > PATTERN_WINDOW) _recentCommands.shift();

          // Record workflow step for habit optimization
          try {
            const { recordWorkflowStep, recordInteraction: recordHabit } = require('../services/usageHabitService');
            recordHabit(trimmed);
            if (_recentCommands.length >= 2) {
              recordWorkflowStep(_recentCommands.slice(-2));
            }
          } catch { /* best effort */ }

          // Check for patterns when we have enough commands
          if (_recentCommands.length >= 2) {
            try {
              const { recordCommandSequence } = require('../services/skillLearningService');
              const suggestion = recordCommandSequence(_recentCommands.slice(-3));
              if (suggestion && suggestion.suggest) {
                console.log('');
                console.log(c.yellow(`  ⚡ 检测到重复操作模式 (${suggestion.count} 次):`));
                console.log(c.dim(`     ${suggestion.sequence.join(' → ')}`));
                console.log(c.dim(`     输入 skill learn workflow "${suggestion.sequence.join(' → ')}" 自动化`));
                console.log('');
              }
            } catch { /* pattern learning is best-effort */ }
          }
        }

        rl.prompt();
        return;
      }

      // result.aiForward → a command generated a prompt for AI
      const aiInput = (result && result.aiForward) ? result.aiForward : trimmed;

      // Unrecognized command → auto-route to AI (always on)

      // result === false or aiForward → send to AI
      let streamState = { phase: 'idle', thinkingStarted: false, textStarted: false };

      // Merge any queued /btw hints into the input
      let finalAiInput = aiInput;
      if (_btwQueue.length > 0) {
        const hints = _btwQueue.splice(0).join('\n');
        finalAiInput = `${aiInput}\n\n[附加提示]\n${hints}`;
      }

      // Detect file paths in input (drag-and-drop support)
      // Strips quotes, resolves relative to user's launch directory
      try {
        const fileExts = /\.(txt|js|ts|py|json|csv|md|log|yaml|yml|toml|html|css|vue|sql|sh|bat|xml|ini|cfg|conf|java|go|rs|c|cpp|h|rb|php)$/i;
        const pathCandidate = finalAiInput.replace(/^['"`]+|['"`]+$/g, '').replace(/\\ /g, ' ').split(/\s+/)[0];
        if (fileExts.test(pathCandidate)) {
          const userCwd = process.env.KHYQUANT_CWD || process.cwd();
          const resolvedPath = path.isAbsolute(pathCandidate) ? pathCandidate : path.resolve(userCwd, pathCandidate);
          if (fs.existsSync(resolvedPath) && fs.statSync(resolvedPath).isFile()) {
            const stat = fs.statSync(resolvedPath);
            const maxSize = 100 * 1024;
            const content = fs.readFileSync(resolvedPath, 'utf-8').slice(0, maxSize);
            const sizeInfo = stat.size > maxSize ? `截取前 100KB / 总 ${(stat.size / 1024).toFixed(0)}KB` : `${(stat.size / 1024).toFixed(1)} KB`;
            printInfo(`已读取文件: ${path.basename(resolvedPath)} (${sizeInfo})`);
            const followUp = finalAiInput.slice(pathCandidate.length).trim();
            const prompt = followUp || '请分析这个文件的内容';
            finalAiInput = `[文件内容: ${path.basename(resolvedPath)}]\n\`\`\`\n${content}\n\`\`\`\n\n${prompt}`;
          }
        }
      } catch { /* file detection is best-effort, ignore errors */ }

      // Check for multi-agent trigger
      const agentRunner = require('../services/cliAgentRunner');
      if (agentRunner.shouldUseMultiAgent(finalAiInput)) {
        _currentOp = '多智能体协作';
        _requestStart = Date.now();
        const agentDisplay = require('./agentRenderer');
        const renderer = require('./aiRenderer');

        // Decompose task into sub-tasks
        const subtasks = agentRunner.decomposeTask(finalAiInput);
        let renderedLines = 0;

        // Show initial agent display
        renderedLines = agentDisplay.renderAgentDisplay(subtasks.map(st => ({
          name: st.name, status: 'pending', toolCalls: 0, tokens: 0, elapsed: 0, detail: '',
        })));

        // Run agents with progress updates
        const agentResults = await agentRunner.runAgents(subtasks, {
          ai: ai(),
          onProgress: (states) => {
            renderedLines = agentDisplay.rerenderAgentDisplay(states, renderedLines);
          },
        });

        // Show final state
        agentDisplay.rerenderAgentDisplay(agentResults, renderedLines, true);
        agentDisplay.renderAgentSummary(agentResults);

        // Synthesize results
        renderer.printToolCallStart('Synthesize', '综合分析');
        const synthStart = Date.now();
        const synthesized = await agentRunner.synthesizeResults(agentResults, finalAiInput, ai());
        renderer.printToolCallResult('Synthesize', '综合分析', 'success', '合成完成', Date.now() - synthStart);

        // Display synthesized result
        agentDisplay.renderSynthesisResult(synthesized, agentResults);
        console.log('');
        _busy = false;
        rl.prompt();
        return;
      }

      // Check for plan mode trigger
      const planService = require('../services/planModeService');
      let needsPlan = false;
      try {
        const { preprocess } = require('../services/inputPreprocessor');
        const pp = preprocess(aiInput);
        needsPlan = pp.needsPlan || _planMode;
      } catch { /* best effort */ }

      if (needsPlan || _planMode) {
        const renderer = require('./aiRenderer');
        _planMode = false; // Reset after use
        _currentOp = '计划模式';
        _requestStart = Date.now();

        // Step 1: Generate plan
        renderer.printStepLine('active', '计划模式', '生成执行计划...');
        const { plan, rawResponse, provider, elapsed } = await planService.enterPlanMode(finalAiInput, ai());

        if (plan && plan.steps.length > 0) {
          if (process.stdout.isTTY) {
            process.stdout.write('\x1b[1A\r\x1b[K');
          }
          renderer.printStepLine('success', '计划模式', `生成 ${plan.steps.length} 步执行计划`);

          // Step 2: Present for approval
          const approval = await planService.presentForApproval(plan, renderer, rl);

          if (approval.approved) {
            // Step 3: Execute step by step
            console.log('');
            renderer.printStepLine('active', '执行计划', `${plan.steps.filter(s => s.status !== 'skipped').length} 步骤`);

            const results = await planService.executePlanSteps(plan, {
              ai: ai(),
              renderer,
              rl,
              route,
              parseInput,
            });

            if (process.stdout.isTTY) {
              process.stdout.write('\x1b[1A\r\x1b[K');
            }
            renderer.printStepLine('success', '计划执行完成', `${results.filter(r => r.step.status === 'completed').length}/${results.length} 成功`);

            // Show final results
            for (const { step, result } of results) {
              if (result.reply) {
                console.log(c.dim(`  ┌── 步骤 ${step.id}: ${step.description}`));
                const rendered = renderer.renderAiResponse(result.reply);
                rendered.split('\n').forEach(l => console.log(c.dim('  │ ') + l));
                console.log(c.dim('  └──'));
              }
            }
            renderer.renderAgentDone({
              toolCalls: results.length,
              elapsedMs: elapsed,
            });
          } else {
            printInfo('计划已取消');
          }
        } else {
          // Plan generation failed — fall through to normal AI
          if (rawResponse) {
            const renderer2 = require('./aiRenderer');
            console.log(c.dim('  ┌──'));
            const rendered = renderer2.renderAiResponse(rawResponse);
            rendered.split('\n').forEach(l => console.log(c.dim('  │ ') + l));
            console.log(c.dim('  └──'));
          }
        }
        planService.reset();
        console.log('');
        _busy = false;
        rl.prompt();
        return;
      }

      // Load AI renderer for rich output
      const renderer = require('./aiRenderer');
      const spinner = new renderer.DynamicSpinner();
      const tracker = new renderer.ProcessTracker();

      // Step 0: Show intent understanding (brief local analysis)
      try {
        const intents = [];
        const lower = aiInput.toLowerCase();
        if (/回测|backtest/.test(lower))       intents.push('回测分析');
        if (/行情|quote|价格|涨跌/.test(lower))   intents.push('行情查询');
        if (/数据|data|下载|fetch/.test(lower))   intents.push('数据获取');
        if (/策略|strategy|信号/.test(lower))     intents.push('策略分析');
        if (/分析|analyze|评估|诊断/.test(lower))  intents.push('深度分析');
        if (/对比|比较|vs/.test(lower))           intents.push('对比分析');
        if (/推荐|建议|suggest/.test(lower))      intents.push('推荐建议');
        if (/解释|什么是|如何|怎么/.test(lower))   intents.push('知识问答');

        if (intents.length > 0) {
          renderer.printStepLine('active', '理解', aiInput.slice(0, 30).replace(/\n/g, ' '));
          renderer.printStepDetail(`意图: ${intents.join(' + ')}`);
          // Overwrite the active line with success
          if (process.stdout.isTTY) {
            process.stdout.write('\x1b[2A\r\x1b[K');
          }
          renderer.printStepLine('success', '理解', aiInput.slice(0, 30).replace(/\n/g, ' '));
          renderer.printStepDetail(`意图: ${intents.join(' + ')}`);
        }
      } catch { /* best effort */ }

      // Step 1: Preprocessing — detect complexity for display
      let complexTask = false;
      try {
        const { preprocess } = require('../services/inputPreprocessor');
        const pp = preprocess(aiInput);
        complexTask = pp.needsPlan;
      } catch { /* best effort */ }

      if (complexTask) {
        tracker.start('分析', aiInput.slice(0, 40), '复杂任务检测');
        tracker.complete('AI 将先制定执行计划');
      }

      // Step 2: AI request
      _currentOp = '请求 AI';
      _requestStart = Date.now();
      tracker.start('请求 AI', ai().getActiveProvider() || 'AI 服务');

      const onChunk = (chunk) => {
        if (chunk.type === 'thinking') {
          // Complete the request step, start thinking step
          if (tracker.isActive) tracker.complete();
          spinner.stop();
          _currentOp = '思考中';
          if (!streamState.thinkingStarted) {
            streamState.thinkingStarted = true;
            streamState.phase = 'thinking';
            tracker.start('思考', '', '深度分析中...');
            console.log('');
            console.log(c.yellow(`  ${ICON_BOT} 思考过程:`));
            console.log(c.dim('  ┌──'));
          }
          const thinkLines = chunk.text.split('\n');
          thinkLines.forEach(l => process.stdout.write(c.dim('  │ ') + c.yellow(l) + '\n'));
        } else if (chunk.type === 'text') {
          if (streamState.phase === 'thinking') {
            console.log(c.dim('  └──'));
            console.log('');
            if (tracker.isActive) tracker.complete('思考完成');
            streamState.phase = 'text';
            spinner.setPhase('generating', '生成回复');
          }
          if (!streamState.textStarted) {
            streamState.textStarted = true;
            _currentOp = '生成回复';
            if (tracker.isActive) tracker.complete();
            spinner.stop();
            tracker.start('生成', '', '输出回复...');
          }
        } else if (chunk.type === 'cost') {
          streamState.cost = chunk.cost;
          if (chunk.cost?.totalTokens) _sessionTokens = chunk.cost.totalTokens;
        }
      };

      // Start dynamic spinner
      spinner.start('request');

      let aiResult;

      // ── QueryEngine path (KHY_QUERY_ENGINE=true) ────────────────
      let _useQueryEngine = false;
      try { _useQueryEngine = require('../services/queryEngine').isEnabled(); } catch {}

      if (_useQueryEngine) {
        try {
          const { QueryEngine } = require('../services/queryEngine');
          if (!_queryEngine) _queryEngine = new QueryEngine();
          for await (const event of _queryEngine.submitMessage(finalAiInput, {
            effort: ai().getEffort(),
          })) {
            switch (event.type) {
              case 'thinking':
                onChunk({ type: 'thinking', text: event.data });
                break;
              case 'text':
                onChunk({ type: 'text', text: event.data });
                break;
              case 'tool_call':
                spinner.stop();
                console.log(c.cyan(`  🔧 ${event.data.name}(${Object.values(event.data.params || {}).join(', ')})`));
                spinner.start('tool');
                break;
              case 'tool_result': {
                spinner.stop();
                const ok = event.data.result?.success;
                console.log(ok ? c.green(`  ✓ ${event.data.name} (${event.data.elapsed}ms)`) : c.red(`  ✗ ${event.data.name}: ${event.data.result?.error}`));
                break;
              }
              case 'cost':
                if (event.data?.totalTokens) _sessionTokens += event.data.totalTokens;
                break;
              case 'done':
                aiResult = event.data;
                break;
            }
          }
          spinner.stop();
          if (tracker.isActive) tracker.complete();
        } catch (qeErr) {
          spinner.stop();
          if (tracker.isActive) tracker.complete();
          // Fall through to legacy path on QueryEngine error
          _useQueryEngine = false;
          console.log(c.yellow(`  ⚠ QueryEngine error: ${qeErr.message} — falling back to legacy`));
        }
      }

      if (!_useQueryEngine) {
      // ── Legacy path (original code) ────────────────────────────
      try {
        const { startWatchdog, WATCHDOG_TIMEOUT_MS } = require('../services/resourceGuard');
        const wd = startWatchdog('ai-chat', WATCHDOG_TIMEOUT_MS, () => {
          spinner.stop();
          console.log(c.red('\n  ⚠ AI 请求超时，已自动取消'));
        });
        aiResult = await ai().chat(finalAiInput, {
          onChunk,
          onFallback: (info) => {
            // Display adapter switch warning (don't silently switch)
            spinner.stop();
            const statusCode = info.failedStatusCode ? ` (${info.failedStatusCode})` : '';
            console.log(c.yellow(`\n  ⚠ ${info.failedAdapter} 请求失败: ${info.failedError}${statusCode}`));
            if (info.nextAdapter) {
              console.log(c.yellow(`  → 切换到 ${info.nextAdapter}`));
            }
            console.log('');
            spinner.start('request');
          },
        });
        wd.done();
      } catch (wdErr) {
        spinner.stop();
        if (tracker.isActive) tracker.complete();
        throw wdErr;
      }

      spinner.stop();
      if (tracker.isActive) tracker.complete();
      } // end if (!_useQueryEngine)

      // Close thinking block if it was still open
      if (streamState.phase === 'thinking') {
        console.log(c.dim('  └──'));
        console.log('');
      }

      if (aiResult.reply) {
        // Update terminal title with conversation topic
        updateTitleFromConversation(aiInput);

        // Update session tokens for prompt frame display
        if (aiResult.tokenUsage?.totalTokens) {
          _sessionTokens += aiResult.tokenUsage.totalTokens;
        }

        // Build meta info line (Claude Code style)
        const elapsedSec = aiResult.elapsed ? `${(aiResult.elapsed / 1000).toFixed(1)}s` : '';
        const tokenCount = aiResult.tokenUsage
          ? `↑ ${aiResult.tokenUsage.totalTokens?.toLocaleString() || '?'} tokens` : '';
        const thinkTime = streamState.thinkingStarted ? 'thought' : '';
        const metaParts = [elapsedSec, tokenCount, thinkTime].filter(Boolean);
        const metaTag = metaParts.length > 0 ? c.dim(` (${metaParts.join(' · ')})`) : '';

        // Show response header with green dot (completed)
        renderer.printStepLine('success', 'AI 回复', aiResult.provider || 'local', metaParts.join(' · '));

        // Render with diff highlighting and markdown-lite
        console.log(c.dim('  ┌──'));
        const rendered = renderer.renderAiResponse(aiResult.reply);
        const lines = rendered.split('\n');
        lines.forEach(l => console.log(c.dim('  │ ') + l));
        console.log(c.dim('  └──'));

        // Compacting notice when conversation history is long
        try {
          const historyLen = aiResult.tokenUsage?.totalTokens || 0;
          if (historyLen > 3000) {
            renderer.printCompactingNotice({
              elapsed: elapsedSec,
              tokens: aiResult.tokenUsage?.totalTokens?.toLocaleString() || '?',
              thought: streamState.thinkingStarted ? `${((aiResult.elapsed || 0) * 0.3 / 1000).toFixed(0)}s` : undefined,
              tip: '使用 /btw 在 AI 工作时插入不打断的提示',
            });
          }
        } catch { /* best effort */ }

        // Extract and display task plan if AI response contains numbered steps
        try {
          const planPattern = /执行计划|分析步骤|操作步骤|回测计划|分步/;
          if (planPattern.test(aiResult.reply) || needsPlan) {
            const planTracker = new renderer.TaskPlanTracker();
            if (planTracker.extractFromResponse(aiResult.reply)) {
              planTracker.render();
            }
          }
        } catch { /* best effort */ }

        // Show knowledge tip (contextual, throttled)
        try {
          const { getContextualTip } = require('../services/knowledgeTeachingService');
          const tip = getContextualTip(aiInput, aiResult.reply);
          if (tip) {
            console.log(c.yellow(`  💡 量化小知识: `) + c.white(tip.content.slice(0, 120) + (tip.content.length > 120 ? '...' : '')));
            console.log(c.dim(`     (${tip.category} · ${tip.level})`));
          }
        } catch { /* knowledge tips are best-effort */ }

        // Detect inline options in AI response (numbered lists ending with ?)
        // Pattern: AI asks a question with numbered options like "1. xxx\n2. xxx\n请选择"
        try {
          const optionPattern = /(?:^|\n)\s*(\d)\.\s+(.+)/g;
          const questionPattern = /请选择|你想|哪个|选哪|怎么做|如何选/;
          const hasQuestion = questionPattern.test(aiResult.reply);

          if (hasQuestion) {
            const matches = [...aiResult.reply.matchAll(optionPattern)];
            if (matches.length >= 2 && matches.length <= 6) {
              const options = matches.map(m => ({ label: m[2].trim() }));
              const selection = await renderer.askInlineQuestion(
                'AI 需要你的选择:',
                options,
                { rl }
              );
              if (selection) {
                // Send selection back to AI as follow-up
                _btwQueue.push(`我选择: ${Array.isArray(selection) ? selection.join(', ') : selection}`);
                console.log(c.green(`  ✓ 已选择: ${Array.isArray(selection) ? selection.join(', ') : selection}`));
                console.log(c.dim('  下次输入将自动附带你的选择'));
              }
            }
          }
        } catch { /* interactive selection is best-effort */ }

        console.log('');
      } else {
        // Empty reply — inform user
        printInfo('AI 未返回有效回复 — 请重试或检查连接');
        console.log('');
      }

      // Execute any embedded commands with Claude Code-style tool call display
      // Also handle <tool_call> tags via the new tool-use loop
      if (aiResult.commands && aiResult.commands.length > 0) {
        console.log('');
        const toolCallStats = { toolCalls: 0, startTime: Date.now() };
        for (const cmd of aiResult.commands) {
          const cmdParts = cmd.split(/\s+/);
          const cmdLabel = cmdParts[0] || cmd;
          const cmdTarget = cmdParts.slice(1).join(' ') || '';
          toolCallStats.toolCalls++;

          // Show Claude Code-style tool call start
          renderer.printToolCallStart(cmdLabel, cmdTarget || cmd);
          const cmdStart = Date.now();

          try {
            const cmdParsed = parseInput(cmd);
            if (cmdParsed) {
              // Capture output by temporarily redirecting console.log
              const origLog = console.log;
              const output = [];
              console.log = (...args) => {
                const line = args.map(a => typeof a === 'string' ? a : String(a)).join(' ');
                output.push(line);
              };
              try {
                await route(cmdParsed);
              } finally {
                console.log = origLog;
              }

              const cmdElapsed = Date.now() - cmdStart;

              // Show condensed result via tool call result display
              const condensed = output.filter(l => l.trim()).slice(0, 5);
              const cleanLines = condensed.map(l => l.replace(/\x1b\[[0-9;]*m/g, '').trim().slice(0, 80));
              const detail = cleanLines.length > 0 ? cleanLines[0] : `${cmdLabel} completed`;
              const moreLines = output.filter(l => l.trim()).length;

              renderer.printToolCallResult(
                cmdLabel,
                cmdTarget || cmd,
                'success',
                moreLines > 1 ? `${detail} (+${moreLines - 1} more lines)` : detail,
                cmdElapsed
              );
            } else {
              renderer.printToolCallResult(cmdLabel, cmd, 'error', 'Cannot parse command', 0);
            }
          } catch (cmdErr) {
            renderer.printToolCallResult(
              cmdLabel, cmd, 'error',
              cmdErr.message || 'Execution failed',
              Date.now() - cmdStart
            );
          }
        }
        // Show completion summary
        renderer.renderAgentDone({
          toolCalls: toolCallStats.toolCalls,
          elapsedMs: Date.now() - toolCallStats.startTime,
        });
      }

      // Handle <tool_call> based tool executions via new tool-use loop
      try {
        const toolUseLoop = require('../services/toolUseLoop');
        if (toolUseLoop.isEnabled()) {
          const { _parseToolCalls } = toolUseLoop;
          const parsedCalls = _parseToolCalls(aiResult.reply);
          if (parsedCalls.length > 0) {
            console.log('');
            _currentOp = '工具调用';
            for (const call of parsedCalls) {
              renderer.printToolCallStart(call.name, JSON.stringify(call.params).slice(0, 60));
              const callStart = Date.now();
              try {
                const toolRegistry = require('../tools');
                const result = await toolRegistry.execute(call.name, call.params);
                const elapsed = Date.now() - callStart;
                renderer.printToolCallResult(
                  call.name, '',
                  result.success ? 'success' : 'error',
                  result.output || result.error || (result.success ? 'OK' : 'Failed'),
                  elapsed
                );
              } catch (err) {
                renderer.printToolCallResult(call.name, '', 'error', err.message, Date.now() - callStart);
              }
            }
          }
        }
      } catch { /* tool-use loop is optional */ }

    } catch (err) {
      try { printError(err?.message || String(err) || '执行出错'); } catch { /* ignore */ }
    } finally {
      _busy = false;
      _currentOp = '';
      // Ensure terminal is in a clean state after AI streaming
      if (process.stdout.isTTY) {
        process.stdout.write('\x1b[?25h'); // show cursor (in case hidden during streaming)
      }
      try { rl.prompt(); } catch { /* readline may be destroyed */ }
    }
  });

  // Handle Ctrl+C — require double-press within 2s to exit (prevent accidental exit)
  rl.on('SIGINT', () => {
    if (_busy) {
      // If a command is running, just cancel it
      _busy = false;
      console.log(c.yellow('\n  ⚠ 操作已中断'));
      rl.prompt();
      return;
    }

    _ctrlCCount++;
    if (_ctrlCCount >= 2) {
      // Double Ctrl+C confirmed — exit
      ai().saveConversation();
      saveHistory(history);
      setTerminalTitle(''); // restore terminal title
      console.log('');
      console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
      console.log(c.dim('  对话已保存'));
      console.log('');
      process.exit(0);
    } else {
      console.log(c.yellow('\n  ⚠ 再按一次 Ctrl+C 退出 (对话会自动保存)，或输入 resume 恢复'));
      if (_ctrlCTimer) clearTimeout(_ctrlCTimer);
      _ctrlCTimer = setTimeout(() => { _ctrlCCount = 0; }, 2000);
      rl.prompt();
    }
  });

  // Handle Ctrl+D (EOF) — save and exit gracefully
  rl.on('close', () => {
    // Cancel all startup timers
    for (const t of _startupTimers) clearTimeout(t);
    clearInterval(_tipTimer);
    if (_ctrlCTimer) clearTimeout(_ctrlCTimer);
    // Cancel all resource guard timers before exit
    try { require('../services/resourceGuard').cancelAll(); } catch { /* ignore */ }
    ai().saveConversation();
    saveHistory(history);
    setTerminalTitle(''); // restore terminal title
    if (!rl._exiting) {
      console.log('');
      console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
      console.log(c.dim('  对话已保存，下次输入 resume 恢复'));
      console.log('');
    }
    process.exit(0);
  });
}

module.exports = { startRepl };
