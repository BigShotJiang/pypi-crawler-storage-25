/**
 * Lightweight AI REPL — zero-start mode.
 *
 * Launched via `khy ai` — skips auth, server, and all heavy startup services.
 * Reuses ai.js chat engine, aiGateway adapters, router commands, and all
 * rendering components (aiRenderer, agentRenderer, planModeService).
 *
 * Target: <200ms to first prompt.
 */
const readline = require('readline');
const fs = require('fs');
const path = require('path');
const os = require('os');

// ── Lazy module loaders ──
let _chalk, _fmt, _router, _ai, _inquirer;
const c = () => (_chalk ??= require('chalk'));
const fmt = () => (_fmt ??= require('./formatters'));
const router = () => (_router ??= require('./router'));
const ai = () => (_ai ??= require('./ai'));
const inquirer = () => (_inquirer ??= require('inquirer'));

const HISTORY_FILE = path.join(os.homedir(), '.khyquant_history');
const MAX_HISTORY = 500;
const VERSION = process.env.KHYQUANT_PKG_VERSION || require('../../package.json').version;

// Commands that require full mode (server, DB, auth)
const BLOCKED_COMMANDS = new Set([
  'db', 'account', 'position', 'order',
  'login', 'register', 'logout', 'whoami', 'passwd', 'forgot',
  'cloud', 'admin', 'train', 'compute', 'update', 'doctor', 'plugin',
]);

// ── History helpers ──
function loadHistory() {
  try {
    if (fs.existsSync(HISTORY_FILE)) {
      return fs.readFileSync(HISTORY_FILE, 'utf-8').split('\n').filter(Boolean);
    }
  } catch { /* ignore */ }
  return [];
}

function saveHistory(history) {
  try {
    fs.writeFileSync(HISTORY_FILE, history.slice(-MAX_HISTORY).join('\n') + '\n');
  } catch { /* ignore */ }
}

function setTerminalTitle(title) {
  if (process.stdout.isTTY) process.stdout.write(`\x1b]0;${title}\x07`);
}

/**
 * Start the lightweight AI REPL.
 * @param {object} [options]
 * @param {boolean} [options.oneShot] - run single query and return
 * @param {boolean} [options.printMode] - raw text output for piping
 * @param {string}  [options.prompt] - prompt for oneShot/printMode
 */
async function startLiteRepl(options = {}) {
  const { printLiteBanner, printError, printInfo, printSuccess, ICON_PROMPT, ICON_BOT, MASCOT_MINI, getRandomFarewell } = fmt();
  const chalk = c();
  const { parseInput, route, getCompletions, SLASH_COMMANDS } = router();

  // ── Print mode: raw output, no formatting ──
  if (options.printMode && options.prompt) {
    const result = await ai().chat(options.prompt);
    if (result && result.reply) process.stdout.write(result.reply + '\n');
    return;
  }

  // ── One-shot mode: formatted single query ──
  if (options.oneShot && options.prompt) {
    const renderer = require('./aiRenderer');
    const aiProvider = ai().getActiveProvider() || 'AI';
    console.log('');
    renderer.printStepLine('active', '请求 AI', aiProvider);

    let thinkingStarted = false;
    const result = await ai().chat(options.prompt, {
      onChunk: (chunk) => {
        if (chunk.type === 'thinking' && !thinkingStarted) {
          thinkingStarted = true;
          if (process.stdout.isTTY) process.stdout.write('\x1b[1A\r\x1b[K');
          renderer.printStepLine('success', '请求 AI', aiProvider);
          console.log('');
          console.log(chalk.yellow(`  ${ICON_BOT} 思考过程:`));
          console.log(chalk.dim('  ┌──'));
        }
        if (chunk.type === 'thinking') {
          chunk.text.split('\n').forEach(l => process.stdout.write(chalk.dim('  │ ') + chalk.yellow(l) + '\n'));
        }
      },
    });

    if (thinkingStarted) {
      console.log(chalk.dim('  └──'));
      console.log('');
    } else {
      if (process.stdout.isTTY) process.stdout.write('\x1b[1A\r\x1b[K');
    }

    if (result.reply) {
      const meta = [
        result.elapsed ? `${(result.elapsed / 1000).toFixed(1)}s` : '',
        result.tokenUsage ? `${result.tokenUsage.totalTokens} tokens` : '',
      ].filter(Boolean).join(' · ');
      renderer.printStepLine('success', 'AI 回复', result.provider || 'local', meta);
      console.log(chalk.dim('  ┌──'));
      renderer.renderAiResponse(result.reply).split('\n').forEach(l => console.log(chalk.dim('  │ ') + l));
      console.log(chalk.dim('  └──'));
    } else {
      printError('AI 未返回有效回复');
    }
    console.log('');
    return;
  }

  // ── Interactive REPL mode ──
  setTerminalTitle('KHY-Quant AI');
  const aiProvider = ai().getActiveProvider();
  printLiteBanner(VERSION, aiProvider);

  // Auto-resume last session (synchronous, no setTimeout)
  try {
    const resumeResult = ai().autoResumeLastSession();
    if (resumeResult && resumeResult.resumed) {
      const timeAgo = new Date(resumeResult.timestamp).toLocaleString('zh-CN');
      printInfo(`已恢复上次对话 (${resumeResult.messageCount} 条消息, ${timeAgo})`);
    }
  } catch { /* non-critical */ }

  // State variables
  let _busy = false;
  let _planMode = false;
  let _ctrlCCount = 0;
  let _ctrlCTimer = null;
  let _btwQueue = [];

  // ── Complete Roles export/import ──
  const ROLES_DIR = path.join(os.homedir(), '.khyquant');

  function _exportCompleteRoles() {
    const roles = {
      version: VERSION,
      exportDate: new Date().toISOString(),
      // System prompt (user override)
      systemPrompt: null,
      // Agent roles (custom overrides)
      agentRoles: null,
      // Tool permissions
      toolPermissions: null,
      // Provider config (keys masked)
      providerConfig: {},
      // Prompt library (if exists)
      promptLibrary: null,
      // Skill registry (if exists)
      skillRegistry: null,
      // Project memory (if exists)
      projectMemory: null,
    };

    // System prompt
    const spFile = path.join(ROLES_DIR, 'system_prompt.txt');
    try { if (fs.existsSync(spFile)) roles.systemPrompt = fs.readFileSync(spFile, 'utf-8'); } catch {}

    // Agent roles
    const arFile = path.join(ROLES_DIR, 'agent_roles.json');
    try { if (fs.existsSync(arFile)) roles.agentRoles = JSON.parse(fs.readFileSync(arFile, 'utf-8')); } catch {}

    // Tool permissions
    const tpFile = path.join(ROLES_DIR, 'tool_permissions.json');
    try { if (fs.existsSync(tpFile)) roles.toolPermissions = JSON.parse(fs.readFileSync(tpFile, 'utf-8')); } catch {}

    // Provider configs (mask sensitive keys)
    const envKeys = ['DEEPSEEK_API_KEY', 'QWEN_API_KEY', 'GLM_API_KEY', 'DOUBAO_API_KEY',
      'WENXIN_API_KEY', 'OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'RELAY_API_KEY',
      'DEEPSEEK_API_ENDPOINT', 'QWEN_API_ENDPOINT', 'GLM_API_ENDPOINT', 'DOUBAO_API_ENDPOINT',
      'WENXIN_API_ENDPOINT', 'OPENAI_API_ENDPOINT', 'ANTHROPIC_API_ENDPOINT',
      'RELAY_API_ENDPOINT', 'RELAY_API_MODEL', 'OLLAMA_HOST', 'OLLAMA_MODEL'];
    for (const k of envKeys) {
      if (process.env[k]) {
        // Mask API keys (show first 6 + last 4 chars)
        if (k.endsWith('_KEY') && process.env[k].length > 12) {
          const v = process.env[k];
          roles.providerConfig[k] = v.slice(0, 6) + '***' + v.slice(-4);
        } else {
          roles.providerConfig[k] = process.env[k];
        }
      }
    }

    // Prompt library
    const plFile = path.join(ROLES_DIR, 'prompt_library.json');
    try { if (fs.existsSync(plFile)) roles.promptLibrary = JSON.parse(fs.readFileSync(plFile, 'utf-8')); } catch {}

    // Skill registry
    const srFile = path.join(ROLES_DIR, 'skill_registry.json');
    try { if (fs.existsSync(srFile)) roles.skillRegistry = JSON.parse(fs.readFileSync(srFile, 'utf-8')); } catch {}

    // Project memory
    const pmFile = path.join(ROLES_DIR, 'project_memory.json');
    try { if (fs.existsSync(pmFile)) roles.projectMemory = JSON.parse(fs.readFileSync(pmFile, 'utf-8')); } catch {}

    const outPath = path.join(os.homedir(), 'khy_complete_roles.json');
    fs.writeFileSync(outPath, JSON.stringify(roles, null, 2), 'utf-8');
    return outPath;
  }

  function _importCompleteRoles(filePath) {
    if (!fs.existsSync(filePath)) throw new Error(`文件不存在: ${filePath}`);
    const roles = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    let count = 0;

    if (!fs.existsSync(ROLES_DIR)) fs.mkdirSync(ROLES_DIR, { recursive: true });

    if (roles.systemPrompt) {
      fs.writeFileSync(path.join(ROLES_DIR, 'system_prompt.txt'), roles.systemPrompt, 'utf-8');
      count++;
    }
    if (roles.agentRoles) {
      fs.writeFileSync(path.join(ROLES_DIR, 'agent_roles.json'), JSON.stringify(roles.agentRoles, null, 2), 'utf-8');
      count++;
    }
    if (roles.toolPermissions) {
      fs.writeFileSync(path.join(ROLES_DIR, 'tool_permissions.json'), JSON.stringify(roles.toolPermissions, null, 2), 'utf-8');
      count++;
    }
    if (roles.promptLibrary) {
      fs.writeFileSync(path.join(ROLES_DIR, 'prompt_library.json'), JSON.stringify(roles.promptLibrary, null, 2), 'utf-8');
      count++;
    }
    if (roles.skillRegistry) {
      fs.writeFileSync(path.join(ROLES_DIR, 'skill_registry.json'), JSON.stringify(roles.skillRegistry, null, 2), 'utf-8');
      count++;
    }
    if (roles.projectMemory) {
      fs.writeFileSync(path.join(ROLES_DIR, 'project_memory.json'), JSON.stringify(roles.projectMemory, null, 2), 'utf-8');
      count++;
    }
    // Provider config: write to .env (note: keys are masked in export, so only endpoints/models are useful)
    if (roles.providerConfig) {
      const envPath = path.resolve(__dirname, '../../.env');
      let envContent = '';
      try { envContent = fs.readFileSync(envPath, 'utf-8'); } catch {}
      for (const [k, v] of Object.entries(roles.providerConfig)) {
        if (k.endsWith('_KEY') && v.includes('***')) continue; // Skip masked keys
        const regex = new RegExp(`^${k}=.*$`, 'm');
        const line = `${k}=${v}`;
        if (regex.test(envContent)) {
          envContent = envContent.replace(regex, line);
        } else {
          envContent = envContent.trimEnd() + '\n' + line + '\n';
        }
        count++;
      }
      fs.writeFileSync(envPath, envContent, 'utf-8');
    }

    return count;
  }

  // Setup readline
  const history = loadHistory();
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: chalk.bold.cyan('❯ '),
    historySize: MAX_HISTORY,
    completer: (line) => {
      const completions = getCompletions(line);
      return [completions.length > 0 ? completions : [], line];
    },
  });
  history.forEach(line => rl.history.push(line));

  // ── Prompt frame (Claude Code style) ──
  let _statusBarEnabled = process.stdout.isTTY && process.stdout.columns > 60;

  // ANSI helpers
  const SAVE_CURSOR    = '\x1b[s';
  const RESTORE_CURSOR = '\x1b[u';
  const CLEAR_LINE     = '\x1b[K';

  // Rotating tips
  const TIPS = [
    '/btw 在 AI 工作时插入不打断的提示',
    '/review 多轮代码审查',
    '/model 快速切换 AI 模型',
    '/plan 生成执行计划再动手',
    '/server 启动 Web UI',
    '/cost 查看 AI 费用统计',
  ];
  let _tipIdx = 0;
  const _tipTimer = setInterval(() => { _tipIdx = (_tipIdx + 1) % TIPS.length; }, 30000);

  /**
   * Render upper status line (above the prompt).
   * Shows provider + model when idle, operation status when busy.
   */
  function renderUpperLine() {
    if (!_statusBarEnabled) return;
    const provider = ai().getActiveProvider() || 'AI';
    let statusText, tipText;
    if (_busy) {
      statusText = chalk.dim(`· 处理中 · ${provider}`);
    } else {
      statusText = chalk.dim(`· 就绪 · ${provider}`);
    }
    tipText = chalk.dim(`└ ${TIPS[_tipIdx]}`);
    process.stdout.write(
      SAVE_CURSOR +
      `\x1b[2A\r${CLEAR_LINE}${statusText}` +
      `\n${CLEAR_LINE}${tipText}` +
      RESTORE_CURSOR
    );
  }

  /**
   * Render lower mode line (below the prompt).
   * Shows keyboard shortcuts and mode indicators.
   */
  function renderLowerLine() {
    if (!_statusBarEnabled) return;
    const parts = [];
    if (_planMode) parts.push(chalk.yellow('plan mode'));
    parts.push(chalk.dim('/help 帮助'));
    parts.push(chalk.dim('/review 审查'));
    parts.push(chalk.dim('2×Ctrl+C 退出'));
    const line = parts.join(chalk.dim(' · '));
    process.stdout.write('\n' + CLEAR_LINE + line + '\x1b[1A\x1b[999C');
  }

  /**
   * Render git branch badge in top-right corner.
   */
  function renderBranchBadge() {
    if (!_statusBarEnabled) return;
    const cols = process.stdout.columns || 80;
    try {
      const hud = require('./hudRenderer');
      hud.refreshGit();
      const { git } = hud.getState();
      if (!git.branch) return;
      const dirty = git.dirty ? '*' : '';
      const text = `${git.branch}${dirty}`;
      const boxWidth = text.length + 2;
      const top    = `┌${'─'.repeat(boxWidth)}┐`;
      const middle = `│ ${text} │`;
      const bottom = `└${'─'.repeat(boxWidth)}┘`;
      const startCol = Math.max(1, cols - top.length + 1);
      const moveTo = (row, col) => `\x1b[${row};${col}H`;
      process.stdout.write(
        SAVE_CURSOR +
        moveTo(1, startCol) + chalk.cyan(top) +
        moveTo(2, startCol) + chalk.cyan(middle) +
        moveTo(3, startCol) + chalk.cyan(bottom) +
        RESTORE_CURSOR
      );
    } catch { /* best effort */ }
  }

  /**
   * Full prompt frame: upper line + branch badge + prompt + lower line.
   */
  function renderPromptFrame() {
    if (!_statusBarEnabled) return;
    renderUpperLine();
    renderBranchBadge();
    renderLowerLine();
  }

  // Wrap prompt to inject the frame
  const _origPrompt = rl.prompt.bind(rl);
  rl.prompt = (...args) => {
    if (_statusBarEnabled) {
      process.stdout.write('\n\n');
    }
    _origPrompt(...args);
    renderPromptFrame();
  };

  if (process.stdout.on) {
    process.stdout.on('resize', () => {
      _statusBarEnabled = process.stdout.isTTY && process.stdout.columns > 60;
      renderPromptFrame();
    });
  }

  rl.prompt();

  // Initialize HUD git info (non-blocking)
  try { require('./hudRenderer').refreshGit(); } catch {}

  // Lightweight deferred prefetch for khy mode (hardware limits only)
  try {
    const { deferredPrefetch } = require('../bootstrap/prefetch');
    deferredPrefetch({ mode: 'khy' });
  } catch { /* bootstrap not available, fine */ }

  // ── Lite slash commands (filtered subset) ──
  const LITE_SLASH = SLASH_COMMANDS.filter(sc =>
    !['/security', '/scan', '/hardware', '/doctor'].includes(sc.cmd)
  );
  LITE_SLASH.push({ cmd: '/hud', desc: '显示 HUD 仪表盘', label: 'HUD 面板' });
  LITE_SLASH.push({ cmd: '/export-roles', desc: '导出 Complete Roles 配置文件', label: '导出角色' });
  LITE_SLASH.push({ cmd: '/import-roles', desc: '导入 Complete Roles 配置文件', label: '导入角色' });
  LITE_SLASH.push({ cmd: '/learn', desc: '导入 Claude 轨迹文件进行自我学习', label: '学习轨迹' });
  LITE_SLASH.push({ cmd: '/optimize', desc: 'AI 自我优化（分析经验并改进）', label: '自优化' });
  LITE_SLASH.push({ cmd: '/optimize-log', desc: '查看优化历史记录', label: '优化日志' });
  LITE_SLASH.push({ cmd: '/push', desc: '推送项目到 GitHub/Gitee 私人仓库备份', label: '推送备份' });
  LITE_SLASH.push({ cmd: '/pool', desc: '查看 API Key 池状态（多账号轮询）', label: 'Key 池' });
  LITE_SLASH.push({ cmd: '/model', desc: '切换 AI 模型 / 适配器', label: '切换模型', route: 'gateway model' });
  LITE_SLASH.push({ cmd: '/config', desc: '配置 API Key / 中转站 / Ollama', label: 'AI 配置', route: 'gateway config' });
  LITE_SLASH.push({ cmd: '/gateway', desc: '查看 AI 网关状态', label: '网关状态', route: 'gateway status' });
  LITE_SLASH.push({ cmd: '/server', desc: '启动 Web 服务器', label: '启动服务', route: 'server start' });
  LITE_SLASH.push({ cmd: '/init', desc: '创建 khy.md 项目指令文件', label: '初始化', route: 'init' });
  LITE_SLASH.push({ cmd: '/review', desc: '多轮代码审查', label: '代码审查', route: 'review' });

  // ── Main line handler ──
  rl.on('line', async (line) => {
    const trimmed = line.trim();
    if (!trimmed) { rl.prompt(); return; }

    // Slash menu — inline display (Claude Code style)
    if (trimmed === '/' || (trimmed.startsWith('/') && trimmed.length <= 12 && !/^\/\w+\s/.test(trimmed))) {
      const filter = trimmed.length > 1 ? trimmed.toLowerCase() : '';
      const matches = filter
        ? LITE_SLASH.filter(sc => sc.cmd.startsWith(filter) || sc.label.includes(filter.slice(1)))
        : LITE_SLASH;

      if (matches.length === 0) {
        printInfo(`无匹配的命令: ${trimmed}`);
        rl.prompt();
        return;
      }

      // If exact match on a single command, execute it directly
      const exactMatch = matches.length === 1 && matches[0].cmd === trimmed;
      if (exactMatch) {
        const selected = matches[0];
        if (selected.flag === 'plan') {
          _planMode = true;
          printInfo('计划模式已开启 — 下次 AI 回复将先制定执行计划');
          renderPromptFrame();
        } else if (selected.flag) {
          if (selected.flag.startsWith('effort-')) {
            const level = selected.flag.replace('effort-', '');
            if (ai().setEffort(level)) {
              const p = ai().getEffortPresets()[level];
              printSuccess(`精度已切换: ${level} (${p.label})`);
            }
          } else if (selected.flag === 'subscribe') {
            const { handleDocsSubscription } = require('./handlers/docs');
            await handleDocsSubscription();
          }
        } else if (selected.route) {
          const parsed = parseInput(selected.route);
          if (parsed) await route(parsed);
        }
        rl.prompt();
        return;
      }

      // Print inline command list (Claude Code style)
      console.log('');
      const cmdWidth = Math.max(...matches.map(sc => sc.cmd.length)) + 2;
      for (const sc of matches) {
        const cmdCol = chalk.cyan(sc.cmd.padEnd(cmdWidth));
        const descCol = chalk.dim(sc.desc);
        console.log(`  ${cmdCol} ${descCol}`);
      }
      console.log('');
      rl.prompt();
      return;
    }

    // Quick slash shortcuts (without menu)
    if (/^\/plan$/i.test(trimmed)) {
      _planMode = true;
      printInfo('计划模式已开启');
      renderPromptFrame();
      rl.prompt();
      return;
    }
    if (/^\/cost$/i.test(trimmed)) {
      try {
        const tokenSvc = require('../services/tokenUsageService');
        const s = tokenSvc.getSessionUsage();
        console.log(chalk.cyan(`  本次会话: ${s.totalTokens.toLocaleString()} tokens, ${s.requests} 次请求`));
      } catch { printInfo('token 统计暂不可用'); }
      rl.prompt();
      return;
    }
    if (/^\/hud$/i.test(trimmed)) {
      const hud = require('./hudRenderer');
      hud.refreshGit();
      console.log(hud.renderHudPanel(process.stdout.columns || 80));
      rl.prompt();
      return;
    }
    if (/^\/export-roles$/i.test(trimmed)) {
      try {
        const rolesFile = _exportCompleteRoles();
        printSuccess(`Complete Roles 已导出: ${rolesFile}`);
        printInfo('将此文件发送给他人或保存，在新机器上使用 /import-roles 恢复');
      } catch (e) { printError(`导出失败: ${e.message}`); }
      rl.prompt();
      return;
    }
    if (/^\/import-roles$/i.test(trimmed)) {
      const inq = inquirer();
      const { filePath } = await inq.prompt([{
        type: 'input',
        name: 'filePath',
        message: 'Complete Roles 文件路径:',
        default: path.join(os.homedir(), 'khy_complete_roles.json'),
      }]);
      try {
        const count = _importCompleteRoles(filePath);
        printSuccess(`Complete Roles 已导入! 恢复了 ${count} 项配置`);
        printInfo('重启终端后完全生效');
      } catch (e) { printError(`导入失败: ${e.message}`); }
      rl.prompt();
      return;
    }

    // ── /learn — import Claude transcript for self-learning ──
    if (/^\/learn$/i.test(trimmed)) {
      const inq = inquirer();
      const { filePath: transcriptPath } = await inq.prompt([{
        type: 'input',
        name: 'filePath',
        message: 'Claude 轨迹文件路径 (.jsonl):',
        validate: v => v.endsWith('.jsonl') || v.endsWith('.json') ? true : '请输入 .jsonl 或 .json 文件路径',
      }]);
      try {
        const optimizer = require('../services/selfOptimizer');
        const result = optimizer.learnFromTranscript(transcriptPath);
        if (result.success) {
          console.log('');
          printSuccess(`轨迹学习完成!`);
          console.log(chalk.dim(`  总消息: ${result.stats.totalMessages}`));
          console.log(chalk.dim(`  用户消息: ${result.stats.userMessages} · AI 消息: ${result.stats.assistantMessages}`));
          console.log(chalk.dim(`  工具调用: ${result.stats.toolCalls} · 错误: ${result.stats.errors}`));
          console.log(chalk.dim(`  用户纠正: ${result.stats.corrections} · 用户确认: ${result.stats.confirmations}`));
          console.log(chalk.cyan(`  新增模式: ${result.patternsAdded} 条`));
          console.log('');
          printInfo('学到的经验将在后续对话中自动应用');
        } else {
          printError(`学习失败: ${result.error}`);
        }
      } catch (e) { printError(`轨迹解析失败: ${e.message}`); }
      rl.prompt();
      return;
    }

    // ── /optimize — AI self-optimization ──
    if (/^\/optimize$/i.test(trimmed)) {
      const optimizer = require('../services/selfOptimizer');
      const summary = optimizer.getLearningSummary();

      console.log('');
      console.log(chalk.cyan.bold('  AI 自我优化面板'));
      console.log('');
      console.log(chalk.white('  学习状态:'));
      console.log(chalk.dim(`    已学习模式: ${summary.patterns} 条`));
      console.log(chalk.dim(`    纠正经验: ${summary.corrections} · 确认经验: ${summary.confirmations}`));
      console.log(chalk.dim(`    工作流模式: ${summary.workflows} · 错误恢复: ${summary.errors}`));
      console.log(chalk.dim(`    自定义提示词: ${summary.hasCustomPrompt ? chalk.green('●') : chalk.dim('○')}`));
      console.log(chalk.dim(`    自定义角色: ${summary.hasCustomRoles ? chalk.green('●') : chalk.dim('○')}`));
      console.log(chalk.dim(`    提示词库: ${summary.hasPromptLibrary ? chalk.green('●') : chalk.dim('○')}`));
      if (summary.lastOptimized) {
        console.log(chalk.dim(`    上次优化: ${new Date(summary.lastOptimized).toLocaleString('zh-CN')}`));
      }
      console.log('');

      if (summary.patterns > 0) {
        const inq = inquirer();
        const { action } = await inq.prompt([{
          type: 'list',
          name: 'action',
          message: '优化操作:',
          choices: [
            { name: '让 AI 基于学到的经验自动优化提示词', value: 'auto' },
            { name: '查看已学习的模式', value: 'view' },
            { name: '清除学习数据', value: 'clear' },
            { name: '↩️  返回', value: 'back' },
          ],
        }]);

        if (action === 'auto') {
          printInfo('正在基于学习数据生成优化建议...');
          const learned = optimizer.getLearnedContext();
          if (learned) {
            const optimizePrompt = `你是一个 AI 系统优化器。以下是从历史对话中提取的学习经验：

${learned}

当前系统提示词：
${optimizer.readConfig('system_prompt.txt') || '(默认)'}

请基于这些经验，生成一段优化后的补充指令（不超过 500 字），将其追加到系统提示词中以改进未来的对话质量。
只输出优化的补充内容，不要重复原有内容。格式为纯文本。`;

            try {
              const result = await ai().chat(optimizePrompt, { _isFollowUp: true, effort: 'high' });
              if (result.reply) {
                console.log('');
                console.log(chalk.cyan('  AI 生成的优化建议:'));
                console.log(chalk.dim('  ┌──'));
                result.reply.split('\n').forEach(l => console.log(chalk.dim('  │ ') + l));
                console.log(chalk.dim('  └──'));
                console.log('');

                const { apply } = await inq.prompt([{
                  type: 'confirm',
                  name: 'apply',
                  message: '是否应用此优化?',
                  default: true,
                }]);

                if (apply) {
                  // Append to prompt library as learned instruction
                  let lib = {};
                  try { const raw = optimizer.readConfig('prompt_library.json'); if (raw) lib = JSON.parse(raw); } catch {}
                  if (!lib.instructions) lib.instructions = [];
                  lib.instructions.push(result.reply.trim());
                  const writeResult = optimizer.applyOptimization('prompt_library', lib, 'AI self-optimization based on learned patterns');
                  if (writeResult.success) {
                    printSuccess('优化已应用! 配置文件已安全更新');
                    printInfo('无需重启 — 下次对话即生效');
                  } else {
                    printError(`应用失败: ${writeResult.error}`);
                  }
                }
              }
            } catch (e) { printError(`优化请求失败: ${e.message}`); }
          } else {
            printInfo('暂无学习数据，请先使用 /learn 导入轨迹文件');
          }
        }

        if (action === 'view') {
          const patterns = optimizer.readConfig('learned_patterns.json');
          if (patterns) {
            const parsed = JSON.parse(patterns);
            console.log('');
            for (const p of parsed.slice(-10)) {
              const icon = p.type === 'correction' ? chalk.red('✗')
                : p.type === 'confirmation' ? chalk.green('✓')
                : p.type === 'tool_sequence' ? chalk.cyan('→')
                : chalk.yellow('!');
              console.log(`  ${icon} ${chalk.dim(`[${p.type}]`)} ${p.lesson}`);
            }
            console.log('');
          } else {
            printInfo('暂无学习数据');
          }
        }

        if (action === 'clear') {
          const { confirm } = await inq.prompt([{
            type: 'confirm', name: 'confirm', message: '确认清除所有学习数据?', default: false,
          }]);
          if (confirm) {
            optimizer.safeWriteConfig('learned_patterns.json', []);
            printSuccess('学习数据已清除');
          }
        }
      } else {
        printInfo('暂无学习数据。使用 /learn 导入 Claude 轨迹文件开始学习');
      }
      console.log('');
      rl.prompt();
      return;
    }

    // ── /optimize-log ──
    if (/^\/optimize-log$/i.test(trimmed)) {
      const optimizer = require('../services/selfOptimizer');
      const history = optimizer.getOptimizationHistory(15);
      if (history.length === 0) {
        printInfo('暂无优化记录');
      } else {
        console.log('');
        console.log(chalk.cyan.bold('  优化历史'));
        console.log('');
        for (const h of history) {
          const time = new Date(h.timestamp).toLocaleString('zh-CN');
          const icon = h.action === 'ai_optimize' ? chalk.green('●')
            : h.action === 'transcript_learn' ? chalk.cyan('●')
            : h.action === 'config_rollback' ? chalk.yellow('●')
            : chalk.dim('●');
          console.log(`  ${icon} ${chalk.dim(time)} ${chalk.white(h.action)} → ${h.target}`);
        }
        console.log('');
      }
      rl.prompt();
      return;
    }

    // ── /pool — API Key pool status ──
    if (/^\/pool$/i.test(trimmed)) {
      try {
        const pool = require('../services/apiKeyPool');
        pool.init();
        const allStatus = pool.getAllStatus();
        const providers = Object.keys(allStatus);

        console.log('');
        console.log(chalk.cyan.bold('  API Key 池状态'));
        console.log('');

        if (providers.length === 0) {
          console.log(chalk.dim('  暂无已配置的 Key'));
          console.log(chalk.dim('  运行 gateway → provider-keys 添加 API Key'));
        } else {
          for (const provider of providers) {
            const keys = allStatus[provider];
            const activeCount = keys.filter(k => k.status === 'active').length;
            console.log(chalk.white(`  ${provider.charAt(0).toUpperCase() + provider.slice(1)}`) +
              chalk.dim(` (${keys.length} key${keys.length > 1 ? 's' : ''}, ${activeCount} active)`));

            for (const k of keys) {
              const icon = k.status === 'active' ? chalk.green('●')
                : k.status === 'cooldown' ? chalk.yellow('○')
                : chalk.red('○');
              const label = k.label ? chalk.dim(` ${k.label}`) : '';
              const priority = chalk.dim(` P:${k.priority}`);
              let statusInfo = '';
              if (k.status === 'cooldown') {
                statusInfo = chalk.yellow(` ⏳ ${k.cooldownRemaining}s`);
              }
              const stats = chalk.dim(` ${k.totalRequests} req · ${k.totalFailures} fail`);
              const errInfo = k.lastError ? chalk.dim(chalk.red(` · ${k.lastError.slice(0, 30)}`)) : '';
              console.log(`    ${icon} ${chalk.dim(k.keyPreview)}${label}${priority}${statusInfo}${stats}${errInfo}`);
            }
            console.log('');
          }
        }
      } catch (e) {
        printError(`Key 池加载失败: ${e.message}`);
      }
      console.log('');
      rl.prompt();
      return;
    }

    // ── /push — push project to GitHub/Gitee private repo ──
    if (/^\/push$/i.test(trimmed)) {
      const { execSync } = require('child_process');
      const projectCwd = process.env.KHYQUANT_CWD || process.cwd();

      console.log('');
      console.log(chalk.cyan.bold('  项目推送到私人仓库'));
      console.log('');

      // Check git status
      try {
        const branch = execSync('git rev-parse --abbrev-ref HEAD', { cwd: projectCwd, encoding: 'utf-8', stdio: 'pipe' }).trim();
        const status = execSync('git status --porcelain', { cwd: projectCwd, encoding: 'utf-8', stdio: 'pipe' }).trim();
        const remotes = execSync('git remote -v', { cwd: projectCwd, encoding: 'utf-8', stdio: 'pipe' }).trim();

        console.log(chalk.dim(`  分支: ${branch}`));
        console.log(chalk.dim(`  工作区: ${status ? `${status.split('\n').length} 个文件改动` : '干净'}`));
        console.log('');

        // Parse existing remotes
        const remoteMap = {};
        for (const line of remotes.split('\n').filter(Boolean)) {
          const match = line.match(/^(\S+)\s+(\S+)\s+\(push\)/);
          if (match) remoteMap[match[1]] = match[2];
        }

        if (Object.keys(remoteMap).length > 0) {
          console.log(chalk.dim('  已配置的远程仓库:'));
          for (const [name, url] of Object.entries(remoteMap)) {
            // Mask tokens in URL
            const safeUrl = url.replace(/(:\/\/)([^@]+)@/, '$1***@');
            console.log(chalk.dim(`    ${name}: ${safeUrl}`));
          }
          console.log('');
        }

        const inq = inquirer();
        const { action } = await inq.prompt([{
          type: 'list',
          name: 'action',
          message: '操作:',
          choices: [
            ...(Object.keys(remoteMap).length > 0
              ? Object.keys(remoteMap).map(name => ({
                  name: `推送到 ${name} (${remoteMap[name].includes('gitee') ? 'Gitee' : remoteMap[name].includes('github') ? 'GitHub' : 'remote'})`,
                  value: `push-${name}`,
                }))
              : []),
            { name: '添加 GitHub 私人仓库', value: 'add-github' },
            { name: '添加 Gitee 私人仓库', value: 'add-gitee' },
            { name: '↩️  返回', value: 'back' },
          ],
        }]);

        if (action === 'back') {
          rl.prompt();
          return;
        }

        if (action.startsWith('push-')) {
          const remoteName = action.replace('push-', '');
          // Commit first if dirty
          if (status) {
            const { doCommit } = await inq.prompt([{
              type: 'confirm',
              name: 'doCommit',
              message: `工作区有改动，是否先提交?`,
              default: true,
            }]);
            if (doCommit) {
              const { commitMsg } = await inq.prompt([{
                type: 'input',
                name: 'commitMsg',
                message: '提交信息:',
                default: `Update ${new Date().toISOString().slice(0, 10)}`,
              }]);
              try {
                execSync('git add -A', { cwd: projectCwd, stdio: 'pipe' });
                execSync(`git commit -m "${commitMsg.replace(/"/g, '\\"')}"`, { cwd: projectCwd, stdio: 'pipe' });
                printSuccess('已提交');
              } catch { printInfo('无新改动需要提交'); }
            }
          }

          // Push
          const renderer = require('./aiRenderer');
          const pushTracker = new renderer.ToolUseTracker('Push', `${remoteName}`);
          pushTracker.printHeader();
          pushTracker.toolStart('git push', `${remoteName} ${branch}`);
          try {
            execSync(`git push ${remoteName} ${branch}`, { cwd: projectCwd, encoding: 'utf-8', stdio: 'pipe', timeout: 120000 });
            pushTracker.toolEnd('git push', 'success', '', 0);
            pushTracker.finish();
            printSuccess(`已推送到 ${remoteName} (${branch})`);
          } catch (e) {
            pushTracker.toolEnd('git push', 'error', e.message, 0);
            pushTracker.finish();
            printError(`推送失败: ${e.message}`);
          }
        }

        if (action === 'add-github' || action === 'add-gitee') {
          const platform = action === 'add-github' ? 'github' : 'gitee';
          const domain = platform === 'github' ? 'github.com' : 'gitee.com';

          const { remoteName } = await inq.prompt([{
            type: 'input',
            name: 'remoteName',
            message: '远程名称:',
            default: platform,
            validate: v => v.trim().length > 0 || '不能为空',
          }]);

          const { repoUrl } = await inq.prompt([{
            type: 'input',
            name: 'repoUrl',
            message: `仓库地址 (SSH 或 HTTPS):`,
            default: `git@${domain}:username/khy-quant.git`,
            validate: v => v.includes(domain) || v.includes('@') ? true : `请输入 ${platform} 仓库地址`,
          }]);

          try {
            try {
              execSync(`git remote remove ${remoteName}`, { cwd: projectCwd, stdio: 'pipe' });
            } catch { /* no existing remote */ }
            execSync(`git remote add ${remoteName} ${repoUrl}`, { cwd: projectCwd, stdio: 'pipe' });
            printSuccess(`已添加远程仓库: ${remoteName} → ${repoUrl}`);
            printInfo(`使用 /push 再次执行即可推送`);
          } catch (e) {
            printError(`添加失败: ${e.message}`);
          }
        }
      } catch (e) {
        printError(`非 git 仓库或 git 不可用: ${e.message}`);
      }
      console.log('');
      rl.prompt();
      return;
    }

    // ── Support dropping .jsonl files directly ──
    if (trimmed.endsWith('.jsonl') || trimmed.endsWith('.json')) {
      const candidatePath = trimmed.replace(/^['"`]+|['"`]+$/g, '').replace(/\\ /g, ' ');
      const resolvedPath = path.isAbsolute(candidatePath) ? candidatePath : path.resolve(process.env.KHYQUANT_CWD || process.cwd(), candidatePath);
      if (fs.existsSync(resolvedPath) && fs.statSync(resolvedPath).isFile()) {
        // Check if it looks like a Claude transcript
        try {
          const firstLine = fs.readFileSync(resolvedPath, 'utf-8').split('\n')[0];
          const parsed = JSON.parse(firstLine);
          if (parsed.role || parsed.type || parsed.content) {
            printInfo(`检测到 Claude 轨迹文件，正在学习...`);
            const optimizer = require('../services/selfOptimizer');
            const result = optimizer.learnFromTranscript(resolvedPath);
            if (result.success) {
              printSuccess(`学习完成! 新增 ${result.patternsAdded} 条模式 (共 ${result.stats.totalMessages} 条消息)`);
            } else {
              printError(`学习失败: ${result.error || '未知错误'}`);
            }
            rl.prompt();
            return;
          }
        } catch { /* not a transcript, fall through to normal processing */ }
      }
    }

    // ── Secret study mode password ──
    if (trimmed === 'allowstudybykhy') {
      const aiMod = ai();
      if (aiMod.isStudyMode()) {
        printInfo('学习模式已处于激活状态');
      } else {
        aiMod.enableStudyMode();
        console.log('');
        printSuccess('🎓 学习模式已解锁！');
        console.log(chalk.dim('  现在你可以向 AI 提问关于本项目的一切:'));
        console.log(chalk.dim('    • 项目架构与模块关系'));
        console.log(chalk.dim('    • 任意源码文件的实现逻辑'));
        console.log(chalk.dim('    • 设计模式与技术决策'));
        console.log(chalk.dim('    • 前后端交互与数据流'));
        console.log(chalk.dim('    • AI 网关适配器系统'));
        console.log(chalk.dim('    • 策略引擎与回测引擎'));
        console.log('');
        console.log(chalk.dim('  试试: "解释一下 AI 网关的适配器模式"'));
        console.log(chalk.dim('  试试: "分析 liteRepl.js 的设计思路"'));
        console.log('');
      }
      rl.prompt();
      return;
    }

    // Concurrency guard
    if (_busy) {
      _btwQueue.push(trimmed);
      console.log(chalk.dim(`  └ 已排队: "${trimmed.slice(0, 40)}" — AI 完成后自动处理`));
      return;
    }
    _busy = true;
    history.push(trimmed);

    try {
      // Parse input
      const parsed = parseInput(trimmed);

      // Check for blocked commands
      if (parsed && BLOCKED_COMMANDS.has(parsed.command)) {
        printInfo(`"${parsed.command}" 需要完整模式。请运行 khyquant 启动。`);
        _busy = false;
        rl.prompt();
        return;
      }

      // Route recognized commands
      if (parsed) {
        const result = await route(parsed);

        if (result === 'exit') {
          ai().saveConversation();
          saveHistory(history);
          setTerminalTitle('');
          console.log('');
          console.log(chalk.cyan(`  ${MASCOT_MINI} `) + chalk.dim(getRandomFarewell()));
          console.log('');
          process.exit(0);
        }

        if (result === true) {
          _busy = false;
          rl.prompt();
          return;
        }

        // 'menu' and special returns
        if (result === 'menu') {
          const { runMenuLoop } = require('./menu');
          await runMenuLoop();
          _busy = false;
          rl.prompt();
          return;
        }
      }

      // ── AI path (unrecognized command or AI forward) ──
      const aiInput = (parsed && parsed.aiForward) ? parsed.aiForward : trimmed;

      // Merge queued hints
      let finalAiInput = aiInput;
      if (_btwQueue.length > 0) {
        const hints = _btwQueue.splice(0).join('\n');
        finalAiInput = `${aiInput}\n\n[附加提示]\n${hints}`;
      }

      // File drag-and-drop detection
      try {
        const fileExts = /\.(txt|js|ts|py|json|csv|md|log|yaml|yml|toml|html|css|vue|sql|sh|bat|xml|ini|cfg|conf|java|go|rs|c|cpp|h|rb|php)$/i;
        const pathCandidate = finalAiInput.replace(/^['"`]+|['"`]+$/g, '').replace(/\\ /g, ' ').split(/\s+/)[0];
        if (fileExts.test(pathCandidate)) {
          const userCwd = process.env.KHYQUANT_CWD || process.cwd();
          const resolvedPath = path.isAbsolute(pathCandidate) ? pathCandidate : path.resolve(userCwd, pathCandidate);
          if (fs.existsSync(resolvedPath) && fs.statSync(resolvedPath).isFile()) {
            const stat = fs.statSync(resolvedPath);
            const maxSize = 100 * 1024;
            const content = fs.readFileSync(resolvedPath, 'utf-8').slice(0, maxSize);
            const sizeInfo = stat.size > maxSize ? `截取前 100KB` : `${(stat.size / 1024).toFixed(1)} KB`;
            printInfo(`已读取文件: ${path.basename(resolvedPath)} (${sizeInfo})`);
            const followUp = finalAiInput.slice(pathCandidate.length).trim();
            finalAiInput = `[文件内容: ${path.basename(resolvedPath)}]\n\`\`\`\n${content}\n\`\`\`\n\n${followUp || '请分析这个文件的内容'}`;
          }
        }
      } catch { /* best-effort */ }

      // ── Multi-agent trigger ──
      const agentRunner = require('../services/cliAgentRunner');
      if (agentRunner.shouldUseMultiAgent(finalAiInput)) {
        const agentDisplay = require('./agentRenderer');
        const renderer = require('./aiRenderer');

        // Claude Code-style tool use tracker for multi-agent
        const toolTracker = new renderer.ToolUseTracker('Agents', finalAiInput.slice(0, 50).replace(/\n/g, ' '));
        toolTracker.printHeader();

        renderer.printActionHint(`分解任务并启动多智能体并行分析...`);
        const subtasks = agentRunner.decomposeTask(finalAiInput);

        // Track each agent as a tool use
        for (const st of subtasks) {
          toolTracker.toolStart(st.name, st.task ? st.task.slice(0, 60) : '');
        }

        const agentResults = await agentRunner.runAgents(subtasks, {
          ai: ai(),
          onProgress: (states) => {
            // Update tool tracker with agent status changes
            for (const state of states) {
              if (state.status === 'completed' || state.status === 'error') {
                toolTracker.toolEnd(state.name, state.status === 'completed' ? 'success' : 'error',
                  '', state.elapsed || 0);
                if (state.tokens) toolTracker.addTokens(state.tokens);
              }
            }
            try { require('./hudRenderer').agentUpdate(states); } catch {}
          },
        });

        // Collapse to "Done" summary
        const totalTokens = agentResults.reduce((sum, a) => sum + (a.tokens || 0), 0);
        toolTracker.addTokens(totalTokens);
        toolTracker.finish();

        renderer.printToolCallStart('Synthesize', '综合分析');
        const synthStart = Date.now();
        const synthesized = await agentRunner.synthesizeResults(agentResults, finalAiInput, ai());
        renderer.printToolCallResult('Synthesize', '综合分析', 'success', '合成完成', Date.now() - synthStart);

        agentDisplay.renderSynthesisResult(synthesized, agentResults);
        console.log('');
        _busy = false;
        rl.prompt();
        return;
      }

      // ── Plan mode ──
      const planService = require('../services/planModeService');
      let needsPlan = false;
      try {
        const { preprocess } = require('../services/inputPreprocessor');
        const pp = preprocess(aiInput);
        needsPlan = pp.needsPlan || _planMode;
      } catch { /* best effort */ }

      if (needsPlan || _planMode) {
        const renderer = require('./aiRenderer');
        _planMode = false;
        renderPromptFrame();

        renderer.printActionHint(`进入计划模式，分析任务并生成执行计划...`);
        renderer.printStepLine('active', '计划模式', '生成执行计划...');
        const { plan, rawResponse, provider, elapsed } = await planService.enterPlanMode(finalAiInput, ai());

        if (plan && plan.steps.length > 0) {
          if (process.stdout.isTTY) process.stdout.write('\x1b[1A\r\x1b[K');
          renderer.printStepLine('success', '计划模式', `生成 ${plan.steps.length} 步执行计划`);

          const approval = await planService.presentForApproval(plan, renderer, rl);

          if (approval.approved) {
            console.log('');
            renderer.printStepLine('active', '执行计划', `${plan.steps.filter(s => s.status !== 'skipped').length} 步骤`);

            const results = await planService.executePlanSteps(plan, {
              ai: ai(), renderer, rl, route, parseInput,
            });

            if (process.stdout.isTTY) process.stdout.write('\x1b[1A\r\x1b[K');
            renderer.printStepLine('success', '计划执行完成', `${results.filter(r => r.step.status === 'completed').length}/${results.length} 成功`);

            for (const { step, result } of results) {
              if (result.reply) {
                console.log(chalk.dim(`  ┌── 步骤 ${step.id}: ${step.description}`));
                renderer.renderAiResponse(result.reply).split('\n').forEach(l => console.log(chalk.dim('  │ ') + l));
                console.log(chalk.dim('  └──'));
              }
            }
            renderer.renderAgentDone({ toolCalls: results.length, elapsedMs: elapsed });
          } else {
            printInfo('计划已取消');
          }
        } else if (rawResponse) {
          const renderer2 = require('./aiRenderer');
          console.log(chalk.dim('  ┌──'));
          renderer2.renderAiResponse(rawResponse).split('\n').forEach(l => console.log(chalk.dim('  │ ') + l));
          console.log(chalk.dim('  └──'));
        }
        planService.reset();
        console.log('');
        _busy = false;
        rl.prompt();
        return;
      }

      // ── Standard AI chat with Claude Code-style rendering ──
      const renderer = require('./aiRenderer');

      // Model capability check — warn if current model may be insufficient
      try {
        const aiMod = ai();
        if (aiMod.checkModelCapability) {
          const capCheck = aiMod.checkModelCapability(finalAiInput);
          if (capCheck) {
            console.log(chalk.yellow(`  ⚠ 当前模型可能不太适合此任务:`));
            capCheck.issues.forEach(i => console.log(chalk.dim(`    • ${i}`)));
            if (capCheck.recommendations.length > 0) {
              console.log(chalk.cyan(`  推荐模型:`));
              capCheck.recommendations.forEach((r, i) =>
                console.log(chalk.cyan(`    ${i + 1}. ${r.label}`)));
              console.log(chalk.dim(`  继续使用当前模型处理...\n`));
            }
          }
        }
      } catch { /* non-critical */ }


      // Brief description of what's about to happen
      const truncatedInput = aiInput.replace(/\n/g, ' ').slice(0, 50);
      renderer.printActionHint(`向 AI 发送请求: "${truncatedInput}${aiInput.length > 50 ? '...' : ''}"`);
      const spinner = new renderer.DynamicSpinner();
      const tracker = new renderer.ProcessTracker();
      let streamState = { phase: 'idle', thinkingStarted: false, textStarted: false };

      // Intent detection display
      try {
        const intents = [];
        const lower = aiInput.toLowerCase();
        if (/回测|backtest/.test(lower))         intents.push('回测分析');
        if (/行情|quote|价格|涨跌/.test(lower))     intents.push('行情查询');
        if (/数据|data|下载|fetch/.test(lower))     intents.push('数据获取');
        if (/策略|strategy|信号/.test(lower))       intents.push('策略分析');
        if (/分析|analyze|评估|诊断/.test(lower))    intents.push('深度分析');
        if (/解释|什么是|如何|怎么/.test(lower))     intents.push('知识问答');

        if (intents.length > 0) {
          renderer.printStepLine('active', '理解', aiInput.slice(0, 30).replace(/\n/g, ' '));
          renderer.printStepDetail(`意图: ${intents.join(' + ')}`);
          if (process.stdout.isTTY) process.stdout.write('\x1b[2A\r\x1b[K');
          renderer.printStepLine('success', '理解', aiInput.slice(0, 30).replace(/\n/g, ' '));
          renderer.printStepDetail(`意图: ${intents.join(' + ')}`);
        }
      } catch { /* best effort */ }

      // AI request with streaming
      tracker.start('请求 AI', ai().getActiveProvider() || 'AI 服务');
      try { require('./hudRenderer').toolStart('Request', ai().getActiveProvider() || 'AI'); } catch {}

      const onChunk = (chunk) => {
        if (chunk.type === 'thinking') {
          if (tracker.isActive) tracker.complete();
          spinner.stop();
          if (!streamState.thinkingStarted) {
            streamState.thinkingStarted = true;
            streamState.phase = 'thinking';
            tracker.start('思考', '', '深度分析中...');
            console.log('');
            console.log(chalk.yellow(`  ${ICON_BOT} 思考过程:`));
            console.log(chalk.dim('  ┌──'));
          }
          chunk.text.split('\n').forEach(l => process.stdout.write(chalk.dim('  │ ') + chalk.yellow(l) + '\n'));
        } else if (chunk.type === 'text') {
          if (streamState.phase === 'thinking') {
            console.log(chalk.dim('  └──'));
            console.log('');
            if (tracker.isActive) tracker.complete('思考完成');
            streamState.phase = 'text';
            spinner.setPhase('generating', '生成回复');
          }
          if (!streamState.textStarted) {
            streamState.textStarted = true;
            if (tracker.isActive) tracker.complete();
            spinner.stop();
            tracker.start('生成', '', '输出回复...');
          }
        }
      };

      spinner.start('request');

      let aiResult;
      try {
        aiResult = await ai().chat(finalAiInput, {
          onChunk,
          onFallback: (info) => {
            spinner.stop();
            console.log(chalk.yellow(`\n  ⚠ ${info.failedAdapter} 失败: ${info.failedError}`));
            if (info.nextAdapter) console.log(chalk.yellow(`  → 切换到 ${info.nextAdapter}`));
            console.log('');
            spinner.start('request');
          },
        });
      } catch (err) {
        spinner.stop();
        if (tracker.isActive) tracker.complete();
        throw err;
      }

      spinner.stop();
      if (tracker.isActive) tracker.complete();

      // Update HUD state after AI response
      try {
        const hud = require('./hudRenderer');
        hud.updateTokens(aiResult.tokenUsage);
        hud.toolEnd('AI Response', 'success', aiResult.elapsed || 0);
      } catch { /* hudRenderer not critical */ }

      if (streamState.phase === 'thinking') {
        console.log(chalk.dim('  └──'));
        console.log('');
      }

      if (aiResult.reply) {
        setTerminalTitle(`KHY-Quant AI · ${aiInput.slice(0, 20)}`);

        const metaParts = [
          aiResult.elapsed ? `${(aiResult.elapsed / 1000).toFixed(1)}s` : '',
          aiResult.tokenUsage ? `↑ ${aiResult.tokenUsage.totalTokens?.toLocaleString() || '?'} tokens` : '',
        ].filter(Boolean);

        renderer.printStepLine('success', 'AI 回复', aiResult.provider || 'local', metaParts.join(' · '));
        console.log(chalk.dim('  ┌──'));
        renderer.renderAiResponse(aiResult.reply).split('\n').forEach(l => console.log(chalk.dim('  │ ') + l));
        console.log(chalk.dim('  └──'));

        // Extract task plan from response
        try {
          const planPattern = /执行计划|分析步骤|操作步骤|分步/;
          if (planPattern.test(aiResult.reply)) {
            const planTracker = new renderer.TaskPlanTracker();
            if (planTracker.extractFromResponse(aiResult.reply)) planTracker.render();
          }
        } catch { /* best effort */ }

        console.log('');
      } else {
        printInfo('AI 未返回有效回复 — 请重试或检查连接');
        console.log('');
      }

      // Execute embedded commands with tool call display
      if (aiResult.commands && aiResult.commands.length > 0) {
        console.log('');
        const toolTracker2 = new renderer.ToolUseTracker('Execute', `${aiResult.commands.length} commands`);
        toolTracker2.printHeader();

        for (const cmd of aiResult.commands) {
          const cmdParts = cmd.split(/\s+/);
          const cmdLabel = cmdParts[0] || cmd;
          const cmdTarget = cmdParts.slice(1).join(' ') || '';

          toolTracker2.toolStart(cmdLabel, cmdTarget || cmd);
          const cmdStart = Date.now();

          try {
            const cmdParsed = parseInput(cmd);
            if (cmdParsed && !BLOCKED_COMMANDS.has(cmdParsed.command)) {
              const origLog = console.log;
              const output = [];
              console.log = (...args) => output.push(args.map(String).join(' '));
              try { await route(cmdParsed); } finally { console.log = origLog; }

              toolTracker2.toolEnd(cmdLabel, 'success', '', Date.now() - cmdStart);
            } else {
              toolTracker2.toolEnd(cmdLabel, 'error', 'not available', 0);
            }
          } catch (e) {
            toolTracker2.toolEnd(cmdLabel, 'error', e.message || 'failed', Date.now() - cmdStart);
          }
        }
        toolTracker2.finish();
      }

      // Parse <tool_call> tags from AI response (git, web search, etc.)
      if (aiResult.reply) {
        const toolCallRe = /<tool_call>([\w]+)\((.*?)\)<\/tool_call>/gs;
        let tcMatch;
        const toolCalls = [];
        while ((tcMatch = toolCallRe.exec(aiResult.reply)) !== null) {
          toolCalls.push({ name: tcMatch[1], args: tcMatch[2].replace(/^["']|["']$/g, '') });
        }
        if (toolCalls.length > 0) {
          const toolCalling = require('../services/toolCalling');
          const tcTracker = new renderer.ToolUseTracker('Tools', `${toolCalls.length} tool calls`);
          tcTracker.printHeader();

          for (const tc of toolCalls) {
            try { require('./hudRenderer').toolStart(tc.name, tc.args.slice(0, 30)); } catch {}
            const tcStart = Date.now();
            tcTracker.toolStart(tc.name, tc.args.slice(0, 50));
            try {
              const tcResult = await toolCalling.executeTool(tc.name, { command: tc.args, query: tc.args, symbol: tc.args, path: tc.args, code: tc.args, keyword: tc.args });
              const elapsed = Date.now() - tcStart;
              if (tcResult.denied) {
                tcTracker.toolEnd(tc.name, 'error', '用户拒绝', elapsed);
              } else if (tcResult.success) {
                tcTracker.toolEnd(tc.name, 'success', 'done', elapsed);
                // Feed result back to AI as follow-up
                const resultSummary = tcResult.output || tcResult.content || JSON.stringify(tcResult).slice(0, 2000);
                if (resultSummary) {
                  printInfo(`工具结果已获取，正在反馈给 AI...`);
                  const followUp = await ai().chat(`工具 ${tc.name} 执行结果:\n${resultSummary}\n\n请基于此结果继续回答。`, { _isFollowUp: true });
                  if (followUp.reply) {
                    renderer.printStepLine('success', 'AI 补充', '', '');
                    console.log(chalk.dim('  ┌──'));
                    renderer.renderAiResponse(followUp.reply).split('\n').forEach(l => console.log(chalk.dim('  │ ') + l));
                    console.log(chalk.dim('  └──'));
                  }
                }
              } else {
                tcTracker.toolEnd(tc.name, 'error', tcResult.error || 'failed', elapsed);
              }
            } catch (e) {
              tcTracker.toolEnd(tc.name, 'error', e.message, Date.now() - tcStart);
            }
            try { require('./hudRenderer').toolEnd(tc.name, 'done', Date.now() - tcStart); } catch {}
          }
          tcTracker.finish();
        }
      }

    } catch (err) {
      try { printError(err?.message || String(err) || '执行出错'); } catch { /* ignore */ }
    } finally {
      _busy = false;
      if (process.stdout.isTTY) process.stdout.write('\x1b[?25h');
      try { rl.prompt(); } catch { /* ignore */ }
    }
  });

  // ── Ctrl+C exit ──
  rl.on('SIGINT', () => {
    if (_busy) {
      _busy = false;
      console.log(chalk.yellow('\n  ⚠ 操作已中断'));
      rl.prompt();
      return;
    }
    _ctrlCCount++;
    if (_ctrlCCount >= 2) {
      clearInterval(_tipTimer);
      ai().saveConversation();
      saveHistory(history);
      setTerminalTitle('');
      console.log('');
      console.log(chalk.cyan(`  ${MASCOT_MINI} `) + chalk.dim(getRandomFarewell()));
      console.log(chalk.dim('  对话已保存'));
      console.log('');
      process.exit(0);
    }
    console.log(chalk.yellow('\n  ⚠ 再按一次 Ctrl+C 退出 (对话自动保存)'));
    if (_ctrlCTimer) clearTimeout(_ctrlCTimer);
    _ctrlCTimer = setTimeout(() => { _ctrlCCount = 0; }, 2000);
    rl.prompt();
  });

  // ── Ctrl+D exit ──
  rl.on('close', () => {
    clearInterval(_tipTimer);
    ai().saveConversation();
    saveHistory(history);
    setTerminalTitle('');
    console.log('');
    console.log(chalk.cyan(`  ${MASCOT_MINI} `) + chalk.dim(getRandomFarewell()));
    console.log(chalk.dim('  对话已保存'));
    process.exit(0);
  });
}

module.exports = { startLiteRepl };
