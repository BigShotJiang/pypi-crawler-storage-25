/**
 * CLI output formatting utilities.
 * All user-facing prose is in Chinese.
 */
const chalk = require('chalk');
const Table = require('cli-table3');

// ── Mascot & themed icons ────────────────────────────────────────────────────

const MASCOT = [
  '  ╭─────╮    ',
  '  │ ◉ ◉ │    ',
  '╭─┤ ▽▽▽ ├─╮  ',
  '│ ╰─┬─┬─╯ │  ',
  '╰───┤ ├───╯  ',
  '  ╭─┴─┴─╮    ',
  '  │ KHY │    ',
  '  ╰─────╯    ',
];

const MASCOT_MINI = '◉';       // for status lines
const ICON_PROMPT = '❯';       // prompt arrow
const ICON_AI = '⚡';           // AI indicator
const ICON_BULL = '📈';        // market up
const ICON_BEAR = '📉';        // market down
const ICON_BOT = '🤖';         // AI bot head
const ICON_CHART = '📊';       // chart / backtest
const ICON_GEAR = '⚙';         // system
const ICON_PLUG = '🔌';        // plugin
const ICON_HEART = '💚';       // health / doctor
const ICON_ROCKET = '🚀';      // launch / start
const ICON_KEY = '🔑';         // API key
const ICON_DB = '🗄';           // database
const ICON_SEARCH = '🔍';      // search
const ICON_GATEWAY = '🌐';     // gateway / relay

// Random startup tips shown below banner
const TIPS = [
  '输入股票名称或拼音即可查询，如: hq 茅台',
  '支持拼音命令: huice = 回测, hangqing = 行情',
  '输入 menu 打开交互式菜单，鼠标点击操作',
  '直接输入自然语言问题，AI 会理解并执行',
  '运行 doctor 随时检查系统环境健康状态',
  '自定义命令放到 ~/.khyquant/commands/ 即可加载',
  '输入 bt 茅台 --strategy 1 快速回测',
];

function printBanner(version, aiProvider) {
  const b = chalk.cyan;
  const g = chalk.green;
  const y = chalk.yellow;
  const w = chalk.bold.white;
  const d = chalk.dim;

  // Adaptive greeting
  let tip;
  try {
    const userProfile = require('../services/userProfile');
    tip = userProfile.getGreeting();
  } catch {
    tip = TIPS[Math.floor(Math.random() * TIPS.length)];
  }

  // Recent activity summary
  let recentActivity = '暂无最近活动';
  try {
    const os = require('os');
    const fs = require('fs');
    const path = require('path');
    const convoDir = path.join(os.homedir(), '.khyquant', 'conversations');
    if (fs.existsSync(convoDir)) {
      const files = fs.readdirSync(convoDir).filter(f => f.endsWith('.json')).sort().reverse();
      if (files.length > 0) {
        const latest = JSON.parse(fs.readFileSync(path.join(convoDir, files[0]), 'utf-8'));
        const date = new Date(latest.timestamp);
        const now = new Date();
        const diffH = Math.round((now - date) / 3600000);
        const timeAgo = diffH < 1 ? '刚刚' : diffH < 24 ? `${diffH}小时前` : `${Math.round(diffH / 24)}天前`;
        recentActivity = `${latest.messageCount} 条对话 (${timeAgo})`;
      }
    }
  } catch { /* best effort */ }

  // Build Claude Code-style boxed banner
  const cols = Math.min(process.stdout.columns || 80, 90);
  const midCol = Math.floor(cols * 0.45);
  const rightCol = cols - midCol - 5;   // borders + padding

  const aiTag = aiProvider
    ? `AI: ${aiProvider}`
    : 'AI 未配置';
  const aiColor = aiProvider ? g : y;

  // Get active model info from gateway
  let modelDetail = '';
  try {
    const gateway = require('../services/gateway/aiGateway');
    const active = gateway.getActiveAdapter();
    if (active) {
      const parts = [active.name || active.type];
      if (active.activeModel) parts.push(active.activeModel);
      modelDetail = parts.join(' · ');
    }
  } catch { /* best effort */ }

  // Detect frontend URL from actual server port
  let frontendUrl = '';
  try {
    const bPort = parseInt(process.env.PORT || '3000', 10);
    frontendUrl = `http://localhost:${bPort}/trading`;
  } catch { /* best effort */ }

  const cwd = process.cwd();
  const cwdShort = cwd.replace(require('os').homedir(), '~');

  // Left column lines
  const leftLines = [
    '',
    w('   欢迎回来!'),
    '',
    ...MASCOT.map(l => b(l)),
    '',
    aiColor(`  ${modelDetail || aiTag}`),
    frontendUrl ? g(`  🌐 ${frontendUrl}`) : '',
    d(`  ${cwdShort}`),
    '',
  ].filter(l => l !== '');

  // Right column lines
  const rightLines = [
    y('快速入门'),
    d('运行 ') + w('/init') + d(' 创建 khy.md 项目指令文件'),
    '',
    g('常用命令'),
    d('help     ') + d('查看所有命令'),
    d('menu     ') + d('打开交互菜单'),
    d('ai on    ') + d('开启 AI 对话'),
    d('cleanup  ') + d('清理存储空间'),
    '',
    b('最近活动'),
    d(recentActivity),
    '',
  ];

  // Render header
  const headerText = `KHY-Quant v${version}`;
  console.log('');
  console.log(d('╭─ ') + b(headerText) + d(' ' + '─'.repeat(Math.max(1, cols - headerText.length - 6)) + '╮'));

  // Render body — left | right
  const maxRows = Math.max(leftLines.length, rightLines.length);

  for (let i = 0; i < maxRows; i++) {
    const rawLeft = leftLines[i] || '';
    const rawRight = rightLines[i] || '';
    const leftVisible = displayWidth(rawLeft);
    const rightVisible = displayWidth(rawRight);

    const leftPad = Math.max(0, midCol - leftVisible);
    const rightPad = Math.max(0, rightCol - rightVisible);

    const separator = (i === 0) ? d('│') : d('│');

    console.log(
      d('│') + rawLeft + ' '.repeat(leftPad) +
      separator + ' ' + rawRight + ' '.repeat(rightPad) + d('│')
    );
  }

  console.log(d('╰' + '─'.repeat(cols - 2) + '╯'));

  // Disclaimer + contact (compact)
  console.log(d('  ⚠ 本系统仅供学习研究，不构成投资建议 · 风险自担'));
  console.log(d('  💬 QQ群: ') + w('1083973296') + d(' · 官网 khyquant.top'));
  console.log(d(`  💡 ${tip}`));
  console.log('');
}

function stripAnsi(str) {
  // eslint-disable-next-line no-control-regex
  return str.replace(/\u001b\[[0-9;]*m/g, '');
}

/**
 * Calculate the visual display width of a string, accounting for:
 * - CJK characters (2 columns each)
 * - Emoji (2 columns each)
 * - ANSI escape codes (0 columns)
 * - Combining characters (0 columns)
 */
function displayWidth(str) {
  const stripped = stripAnsi(str);
  let width = 0;
  for (const ch of stripped) {
    const cp = ch.codePointAt(0);
    // CJK Unified Ideographs, CJK Symbols, Fullwidth Forms, Hangul
    if (
      (cp >= 0x1100 && cp <= 0x115F) ||   // Hangul Jamo
      (cp >= 0x2E80 && cp <= 0x303E) ||   // CJK Radicals Supplement, Kangxi Radicals
      (cp >= 0x3040 && cp <= 0x33BF) ||   // Hiragana, Katakana, CJK Compatibility
      (cp >= 0x3400 && cp <= 0x4DBF) ||   // CJK Unified Extension A
      (cp >= 0x4E00 && cp <= 0x9FFF) ||   // CJK Unified Ideographs
      (cp >= 0xA000 && cp <= 0xA4CF) ||   // Yi Syllables
      (cp >= 0xAC00 && cp <= 0xD7AF) ||   // Hangul Syllables
      (cp >= 0xF900 && cp <= 0xFAFF) ||   // CJK Compatibility Ideographs
      (cp >= 0xFE30 && cp <= 0xFE6F) ||   // CJK Compatibility Forms
      (cp >= 0xFF01 && cp <= 0xFF60) ||   // Fullwidth Forms
      (cp >= 0xFFE0 && cp <= 0xFFE6) ||   // Fullwidth Signs
      (cp >= 0x20000 && cp <= 0x2FA1F) || // CJK Ext B-F, Supplement
      (cp >= 0x1F300 && cp <= 0x1F9FF)    // Miscellaneous Symbols/Emoji
    ) {
      width += 2;
    } else if (cp >= 0x0300 && cp <= 0x036F) {
      // Combining diacritical marks — zero width
      width += 0;
    } else {
      width += 1;
    }
  }
  return width;
}

/**
 * Pad a string to a target display width, accounting for CJK characters.
 * @param {string} str - raw or ANSI-colored string
 * @param {number} targetWidth
 * @param {string} [fill=' ']
 * @returns {string}
 */
function padToWidth(str, targetWidth, fill = ' ') {
  const currentWidth = displayWidth(str);
  const needed = Math.max(0, targetWidth - currentWidth);
  return str + fill.repeat(needed);
}

/**
 * Truncate a string to a maximum display width, adding '...' if truncated.
 * @param {string} str
 * @param {number} maxWidth
 * @returns {string}
 */
function truncateToWidth(str, maxWidth) {
  if (displayWidth(str) <= maxWidth) return str;
  let result = '';
  let w = 0;
  for (const ch of str) {
    const cp = ch.codePointAt(0);
    const charWidth = (
      (cp >= 0x1100 && cp <= 0x115F) ||
      (cp >= 0x2E80 && cp <= 0x9FFF) ||
      (cp >= 0x3040 && cp <= 0x33BF) ||
      (cp >= 0x3400 && cp <= 0x4DBF) ||
      (cp >= 0x4E00 && cp <= 0x9FFF) ||
      (cp >= 0xAC00 && cp <= 0xD7AF) ||
      (cp >= 0xF900 && cp <= 0xFAFF) ||
      (cp >= 0xFE30 && cp <= 0xFE6F) ||
      (cp >= 0xFF01 && cp <= 0xFF60) ||
      (cp >= 0xFFE0 && cp <= 0xFFE6) ||
      (cp >= 0x20000 && cp <= 0x2FA1F) ||
      (cp >= 0x1F300 && cp <= 0x1F9FF)
    ) ? 2 : 1;
    if (w + charWidth + 3 > maxWidth) { // reserve 3 for '...'
      result += '...';
      break;
    }
    result += ch;
    w += charWidth;
  }
  return result;
}

/**
 * Safe string for terminal output — replace any characters that might
 * cause rendering issues in terminals that don't support full Unicode.
 */
function safeTerminalString(str) {
  if (!str || typeof str !== 'string') return '';
  // Replace null bytes and other control characters (except newline/tab)
  // eslint-disable-next-line no-control-regex
  return str.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
}

function printSuccess(msg) {
  console.log(chalk.green('  ✓ ') + msg);
}

function printError(msg) {
  console.log(chalk.red('  ✗ ') + msg);
}

function printWarn(msg) {
  console.log(chalk.yellow('  ⚠ ') + msg);
}

function printInfo(msg) {
  console.log(chalk.blue('  ℹ ') + msg);
}

function printTable(headers, rows) {
  const table = new Table({
    head: headers.map(h => chalk.cyan(h)),
    style: { 'padding-left': 1, 'padding-right': 1 },
  });
  rows.forEach(row => table.push(row));
  console.log(table.toString());
}

function printQuote(quote) {
  const change = quote.current - quote.preClose;
  const changePct = quote.preClose > 0 ? (change / quote.preClose) * 100 : 0;
  const color = change >= 0 ? chalk.red : chalk.green; // Chinese market: red = up
  const icon = change >= 0 ? ICON_BULL : ICON_BEAR;
  const arrow = change >= 0 ? '▲' : '▼';

  console.log('');
  console.log(`  ${icon} ${chalk.bold(quote.name)} ${chalk.dim('(' + quote.symbol + ')')}`);
  console.log(chalk.dim('  ┌──────────────────────────────────────'));
  console.log(`  │ 现价  ${color(chalk.bold('¥' + quote.current.toFixed(2)))}  ${color(arrow + ' ' + (change >= 0 ? '+' : '') + changePct.toFixed(2) + '%')}`);
  console.log(`  │ 开盘  ¥${quote.open.toFixed(2)}  最高  ${chalk.red('¥' + quote.high.toFixed(2))}  最低  ${chalk.green('¥' + quote.low.toFixed(2))}`);
  console.log(`  │ 昨收  ¥${quote.preClose.toFixed(2)}  成交量  ${chalk.bold(formatVolume(quote.volume))}`);
  if (quote.date) console.log(`  │ 时间  ${chalk.dim(quote.date + ' ' + (quote.time || ''))}`);
  console.log(chalk.dim('  └──────────────────────────────────────'));
  console.log('');
}

function printBacktestResult(result) {
  const returnColor = result.totalReturn >= 0 ? chalk.red : chalk.green;
  const icon = result.totalReturn >= 0 ? ICON_BULL : ICON_BEAR;

  console.log('');
  console.log(`  ${ICON_CHART} ${chalk.bold('回测结果')} ${icon}`);
  console.log(chalk.dim('  ┌──────────────────────────────────────'));

  const rows = [
    ['品种', result.symbol],
    ['区间', `${result.startDate} → ${result.endDate}`],
    ['', ''],
    ['初始资金', formatCurrency(result.initialCapital)],
    ['最终资金', chalk.bold(formatCurrency(result.finalCapital))],
    ['总收益率', returnColor(chalk.bold(safePercent(result.totalReturn)))],
    ['年化收益', returnColor(safePercent(result.annualizedReturn))],
    ['', ''],
    ['最大回撤', chalk.yellow(safePercent(result.maxDrawdown, false))],
    ['夏普比率', safeNum(result.sharpeRatio, 4)],
    ['胜率', safePercent(result.winRate, false)],
    ['', ''],
    ['交易次数', String(result.totalTrades || 0)],
    ['盈利次数', chalk.red(String(result.winningTrades || 0))],
    ['亏损次数', chalk.green(String(result.losingTrades || 0))],
    ['交易天数', String(result.tradingDays || 0)],
  ];

  rows.forEach(([label, value]) => {
    if (!label && !value) {
      console.log(chalk.dim('  ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌'));
      return;
    }
    console.log(`  │ ${chalk.dim(label.padEnd(10))} ${value}`);
  });

  console.log(chalk.dim('  └──────────────────────────────────────'));
  console.log('');
}

function safePercent(value, showSign = true) {
  if (value === undefined || value === null || isNaN(value)) return '-';
  const prefix = showSign && value >= 0 ? '+' : '';
  return prefix + Number(value).toFixed(2) + '%';
}

function safeNum(value, decimals = 2) {
  if (value === undefined || value === null || isNaN(value)) return '-';
  return Number(value).toFixed(decimals);
}

function formatCurrency(value) {
  return '¥' + Number(value).toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatVolume(vol) {
  if (!vol) return '0';
  if (vol >= 1e8) return (vol / 1e8).toFixed(2) + '亿';
  if (vol >= 1e4) return (vol / 1e4).toFixed(2) + '万';
  return String(vol);
}

function printHelp() {
  const pkg = require('../../package.json');
  const displayVersion = process.env.KHYQUANT_PKG_VERSION || pkg.version;
  console.log('');
  console.log(`  ${MASCOT_MINI} ${chalk.bold('KHY-Quant')} ${chalk.dim('量化交易终端')} ${chalk.cyan('v' + displayVersion)}`);
  console.log(chalk.dim('     https://github.com/khyquant · 作者: khy-qqb'));
  console.log('');
  console.log(chalk.dim('  用法: khy [命令] [参数] [--选项]'));
  console.log(chalk.dim('  支持中文/拼音/英文命令，标的支持代码或名称'));
  console.log(chalk.dim('  ─────────────────────────────────────────'));
  console.log('');

  const groups = [
    {
      name: `${ICON_BULL} 行情数据`,
      cmds: [
        ['quote <代码|名称>', '实时行情', 'hq, hangqing, 行情, p'],
        ['search <关键词>', '搜索品种', 'ss, sousuo, find, 搜索'],
        ['data fetch <代码>', '下载K线数据', 'xz, xiazai, dl, 下载'],
        ['data list', '查看品种列表', 'sj, shuju, 数据'],
        ['watch <代码>', '实时监控 (开发中)', 'jk, jiankong, 监控'],
        ['rank', '涨跌排行 (开发中)', 'ph, paihang, top, 排行'],
        ['cache clear', '清理缓存', 'hc, huancun, 清缓存'],
      ]
    },
    {
      name: `${ICON_CHART} 策略回测`,
      cmds: [
        ['backtest <代码>', '运行策略回测', 'bt, huice, 回测'],
        ['  --strategy <id|文件>', '指定策略 (ID 或 .js 文件路径)', ''],
        ['  --start / --end', '起止日期 (默认近一年)', ''],
        ['  --capital <金额>', '初始资金 (默认 100000)', ''],
        ['  --verbose', '显示详细交易记录', ''],
        ['backtest list', '历史回测记录', ''],
        ['strategy list', '查看可用策略', 'cl, celue, 策略'],
      ]
    },
    {
      name: `${ICON_ROCKET} 交易 (实盘预留)`,
      cmds: [
        ['account', '查看账户资金', 'zh, zhanghu, acc, 账户'],
        ['position', '查看当前持仓', 'cc, chicang, pos, 持仓'],
        ['order <代码> --side buy|sell', '委托下单', 'xd, xiadan, 下单'],
        ['buy <代码> --qty 100', '快捷买入', '买入, mairu'],
        ['sell <代码> --qty 100', '快捷卖出', '卖出, maichu'],
      ]
    },
    {
      name: `${ICON_BOT} AI 助手`,
      cmds: [
        ['analyze <代码>', 'AI分析走势', 'fx, fenxi, 分析'],
        ['ai status', 'AI 服务状态', ''],
        ['ai config', '配置 API 密钥', ''],
        ['<任意自然语言>', 'AI 理解并执行', ''],
      ]
    },
    {
      name: `${ICON_BOT} IDE 模型调用`,
      cmds: [
        ['kiro --list', '列出 Kiro 可用模型', ''],
        ['kiro --model <模型ID>', '指定模型并进入对话', ''],
        ['kiro', '交互选择模型后对话', ''],
        ['cursor --list', '列出 Cursor 可用模型', ''],
        ['claude --list', '列出 Claude 可用模型', ''],
        ['codex --list', '列出 Codex 可用模型', ''],
        ['trae --list', '列出 Trae 可用模型', ''],
        ['trae --model <模型ID>', '指定 Trae 模型并对话', ''],
      ]
    },
    {
      name: `${ICON_GATEWAY} AI 网关`,
      cmds: [
        ['gateway status', 'AI网关状态 (CLI/API/中转)', 'wg, 网关'],
        ['gateway config', '配置网关参数', ''],
        ['gateway relay', '启动Web中转服务', 'relay, 中转, zhongzhuan'],
      ]
    },
    {
      name: `${ICON_GEAR} 系统管理`,
      cmds: [
        ['server start [--port N]', '启动后端服务', 'fw, fuwu, 服务'],
        ['server status', '查看服务状态', ''],
        ['db init', '初始化数据库', 'sjk, shujuku, 数据库'],
        ['db seed', '填充示例数据', ''],
        ['db status', '数据库状态', ''],
      ]
    },
    {
      name: `${ICON_HEART} 环境管理`,
      cmds: [
        ['init', '初始化向导 (配置、数据库、种子)', 'setup, 初始化, chushihua, 安装'],
        ['init --force', '强制重新初始化', ''],
        ['doctor', '环境诊断检查', 'check, 诊断, zhenduan, 健康'],
      ]
    },
    {
      name: `${ICON_PLUG} 扩展与其他`,
      cmds: [
        ['skill list', '查看可用 Skill (内置+远程)', 'skills'],
        ['skill install <id>', '从注册表安装 Skill', ''],
        ['skill uninstall <id>', '卸载 Skill', ''],
        ['/analyze <代码>', 'Skill: AI 智能分析', '/fx, /分析'],
        ['/recommend', 'Skill: 策略推荐', '/tj, /推荐'],
        ['/news', 'Skill: 市场资讯', '/zx, /资讯'],
        ['/compare <品种>', 'Skill: 对比分析', '/db, /对比'],
        ['/explain <概念>', 'Skill: 概念解释', '/js, /解释'],
        ['plugin list', '查看自定义命令', ''],
        ['plugin reload', '重新加载插件', ''],
        ['menu', '打开交互菜单', 'cd, caidan, 菜单'],
        ['help', '显示此帮助', 'bz, bangzhu, h, 帮助'],
        ['clear', '清屏', 'cls, qp, 清屏'],
        ['exit', '退出', 'q, tuichu, quit, 退出'],
      ]
    },
  ];

  groups.forEach(group => {
    console.log(`  ${chalk.cyan.bold(group.name)}`);
    group.cmds.forEach(([cmd, desc, aliases]) => {
      const aliasStr = aliases ? chalk.dim(` (${aliases})`) : '';
      console.log(`    ${chalk.white(cmd.padEnd(28))} ${chalk.dim(desc)}${aliasStr}`);
    });
    console.log('');
  });

  console.log(chalk.dim('  示例:'));
  console.log(chalk.dim('    khy hq 茅台                  查询茅台行情'));
  console.log(chalk.dim('    khy huice sh600519            回测沪深300'));
  console.log(chalk.dim('    khy ss 银行                   搜索含"银行"的品种'));
  console.log(chalk.dim('    khy bt 茅台 --strategy 1      用策略1回测茅台'));
  console.log(chalk.dim('    khy kiro --list               查看 Kiro 模型列表'));
  console.log(chalk.dim('    khy kiro --model <模型ID>     指定 Kiro 模型并进入对话'));
  console.log(chalk.dim('    khy trae --list               查看 Trae 模型列表'));
  console.log(chalk.dim('    khy claude --list             查看 Claude 模型列表'));
  console.log('');
  console.log(chalk.yellow('  ⚠ 免责声明'));
  console.log(chalk.dim('    本系统仅供学习研究使用，不构成任何投资建议。'));
  console.log(chalk.dim('    量化策略存在固有风险，历史回测不代表未来收益。'));
  console.log(chalk.dim('    据此操作产生的一切风险及损失由使用者自行承担。'));
  console.log(chalk.dim('    因使用本系统产生的任何侵权责任亦由使用者自行承担。'));
  console.log('');
  console.log(chalk.dim('  💬 交流 QQ 群: ') + chalk.bold.white('1083973296'));
  console.log(chalk.dim('  🌐 官网: https://khyquant.top'));
  console.log(chalk.dim('  📦 安装: pip install khy-quant'));
  console.log('');

  // Show user plugins
  try {
    const { getPluginList, PLUGINS_DIR } = require('./plugins');
    const plugins = getPluginList();
    if (plugins.length > 0) {
      console.log(`  ${chalk.cyan.bold('自定义命令')} (${PLUGINS_DIR}/)`);
      plugins.forEach(p => {
        console.log(`    ${chalk.white((p.name).padEnd(28))} ${chalk.dim(p.description || '')}`);
      });
      console.log('');
    }
  } catch { /* plugins not loaded */ }
}

async function withSpinner(text, fn, { muteOutput = false } = {}) {
  // On Windows, ora's ANSI cursor control conflicts with readline in REPL mode,
  // causing all output to be swallowed. Use a simple text fallback instead.
  const useSimpleSpinner = process.platform === 'win32' && process.stdin.isTTY;

  let spinner;
  if (useSimpleSpinner) {
    // Simple fallback: just print the text, no animated spinner
    process.stdout.write(chalk.cyan(`  ◌ ${text}...`));
    spinner = {
      succeed: (msg) => { process.stdout.write('\r' + chalk.green(`  ✓ ${msg || text}`) + '\n'); },
      fail: (msg) => { process.stdout.write('\r' + chalk.red(`  ✗ ${msg || text}`) + '\n'); },
    };
  } else {
    const ora = (await import('ora')).default;
    // discardStdin: false prevents ora from pausing/closing stdin,
    // which would destroy any active readline interface and crash the REPL.
    spinner = ora({ text, indent: 2, discardStdin: false }).start();
  }

  // Suppress noisy service logs (console + winston) while spinner runs
  let origLog, origWarn, origError, origLogLevel;
  if (muteOutput) {
    origLog = console.log;
    origWarn = console.warn;
    origError = console.error;
    console.log = () => {};
    console.warn = () => {};
    console.error = () => {};
    // Also silence winston console transport
    try {
      const logger = require('../utils/logger');
      origLogLevel = logger.level;
      logger.level = 'silent';
    } catch { /* logger not available */ }
  }

  const restore = () => {
    if (!muteOutput) return;
    console.log = origLog;
    console.warn = origWarn;
    console.error = origError;
    try {
      const logger = require('../utils/logger');
      logger.level = origLogLevel || 'info';
    } catch { /* ignore */ }
  };

  try {
    const result = await fn();
    restore();
    spinner.succeed();
    return result;
  } catch (err) {
    restore();
    spinner.fail(err.message);
    throw err;
  }
}

function printDivider(label) {
  if (label) {
    const line = '─'.repeat(Math.max(0, 22 - stripAnsi(label).length));
    console.log(chalk.dim(`  ── ${label} ${line}`));
  } else {
    console.log(chalk.dim('  ' + '─'.repeat(40)));
  }
}

// Farewell messages (randomly chosen on exit)
const FAREWELLS = [
  '祝你投资顺利，下次见！',
  '量化之路，一步一个脚印。再见！',
  '市场永远在，机会随时来。再见！',
  '稳健投资，长期致胜。下次见！',
  '数据驱动决策，理性战胜情绪。再见！',
];

function getRandomFarewell() {
  return FAREWELLS[Math.floor(Math.random() * FAREWELLS.length)];
}

/**
 * Print a lightweight banner for AI-only mode (no ASCII art).
 */
function printLiteBanner(version, aiProvider) {
  const provider = aiProvider ? chalk.green(aiProvider) : chalk.yellow('未配置');
  console.log('');
  console.log(chalk.cyan.bold('  KHY AI Terminal') + chalk.dim(` v${version}`) + chalk.dim(' · ') + provider);
  console.log(chalk.dim('  输入问题开始对话，/ 查看命令菜单'));
  console.log(chalk.dim('  /model 切换模型 · /config 配置 API Key/中转站/Ollama · /server 启动 Web UI'));
  console.log('');
}

module.exports = {
  // Output functions
  printBanner,
  printLiteBanner,
  printSuccess,
  printError,
  printWarn,
  printInfo,
  printTable,
  printQuote,
  printBacktestResult,
  printHelp,
  printDivider,
  // Formatting helpers
  formatCurrency,
  formatVolume,
  stripAnsi,
  displayWidth,
  padToWidth,
  truncateToWidth,
  safeTerminalString,
  // Spinner
  withSpinner,
  // Theme icons (for use in other modules)
  MASCOT_MINI,
  ICON_PROMPT,
  ICON_AI,
  ICON_BOT,
  ICON_CHART,
  ICON_GEAR,
  ICON_ROCKET,
  ICON_KEY,
  ICON_DB,
  ICON_SEARCH,
  ICON_HEART,
  ICON_PLUG,
  ICON_BULL,
  ICON_BEAR,
  ICON_GATEWAY,
  // Farewell
  getRandomFarewell,
};
