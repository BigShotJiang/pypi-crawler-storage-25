/**
 * AI Output Renderer — rich terminal output for AI responses.
 *
 * Features:
 *   - Dynamic spinner with phase-aware status text
 *   - Red/green diff display for code changes
 *   - Inline interactive prompts (numbered options)
 *   - Markdown-lite rendering (headers, code blocks, lists)
 *
 * Lazy-loads chalk for fast cold start.
 */
let _chalk;
const c = () => (_chalk ??= require('chalk'));

// ── Dynamic Spinner ─────────────────────────────────────────────────────

const SPINNER_FRAMES = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
const SPINNER_COLORS = ['cyan', 'cyan', 'blue', 'blue', 'magenta', 'magenta', 'yellow', 'yellow', 'green', 'green'];
const PHASE_LABELS = {
  init:      '初始化',
  security:  '安全检查',
  preprocess:'预处理输入',
  request:   '请求 AI 服务',
  thinking:  '深度思考',
  analyzing: '分析数据',
  generating:'生成回复',
  tools:     '调用工具',
  done:      '完成',
};

class DynamicSpinner {
  constructor() {
    this._frame = 0;
    this._timer = null;
    this._phase = 'init';
    this._detail = '';
    this._startTime = Date.now();
    this._tokens = 0;
  }

  start(phase = 'init') {
    if (this._timer) this.stop(); // prevent interval leak
    this._phase = phase;
    this._startTime = Date.now();
    this._timer = setInterval(() => this._render(), 100);
  }

  setPhase(phase, detail = '') {
    this._phase = phase;
    this._detail = detail;
  }

  setTokens(count) {
    this._tokens = count;
  }

  _render() {
    if (!process.stdout.isTTY) return;
    const frame = SPINNER_FRAMES[this._frame % SPINNER_FRAMES.length];
    const colorName = SPINNER_COLORS[this._frame % SPINNER_COLORS.length];
    this._frame++;

    const elapsed = ((Date.now() - this._startTime) / 1000).toFixed(0);
    const label = PHASE_LABELS[this._phase] || this._phase;
    const detail = this._detail ? ` — ${this._detail}` : '';
    const tokenStr = this._tokens > 0 ? ` · ${this._tokens.toLocaleString()} tokens` : '';

    // Animated ✳ cycles warm colors; label uses phase-based color
    const iconColor = c()[colorName];
    let labelColor;
    switch (this._phase) {
      case 'thinking':  labelColor = c().yellow; break;
      case 'analyzing': labelColor = c().cyan; break;
      case 'generating':labelColor = c().green; break;
      case 'tools':     labelColor = c().magenta; break;
      default:          labelColor = c().white; break;
    }

    const line = `  ${iconColor(frame)} ${labelColor(label)}${c().dim(detail)} ${c().dim(`(${elapsed}s${tokenStr})`)}`;
    process.stdout.write(`\r\x1b[K${line}`);
  }

  stop() {
    if (this._timer) {
      clearInterval(this._timer);
      this._timer = null;
    }
    process.stdout.write('\r\x1b[K'); // clear line
  }
}

// ── Diff Renderer ───────────────────────────────────────────────────────

/**
 * Render a unified diff with red/green coloring.
 * Lines starting with + are green, - are red, @@ are cyan.
 */
function renderDiff(diffText) {
  const lines = diffText.split('\n');
  const rendered = [];

  for (const line of lines) {
    if (line.startsWith('+++') || line.startsWith('---')) {
      rendered.push(c().bold(line));
    } else if (line.startsWith('+')) {
      rendered.push(c().bgGreen.black(line));
    } else if (line.startsWith('-')) {
      rendered.push(c().bgRed.white(line));
    } else if (line.startsWith('@@')) {
      rendered.push(c().cyan(line));
    } else {
      rendered.push(c().dim(line));
    }
  }

  return rendered.join('\n');
}

/**
 * Detect and render inline diffs within AI response text.
 * Looks for fenced diff blocks: ```diff ... ```
 */
function renderResponseWithDiffs(text) {
  // Split on diff code blocks
  const parts = text.split(/(```diff\n[\s\S]*?```)/g);
  const rendered = [];

  for (const part of parts) {
    if (part.startsWith('```diff\n') && part.endsWith('```')) {
      const diffContent = part.slice(8, -3); // strip fences
      rendered.push(c().dim('  ┌── diff ──'));
      const diffLines = renderDiff(diffContent).split('\n');
      for (const dl of diffLines) {
        rendered.push(`  │ ${dl}`);
      }
      rendered.push(c().dim('  └──'));
    } else {
      rendered.push(part);
    }
  }

  return rendered.join('\n');
}

// ── Inline Code Highlighting ────────────────────────────────────────────

/**
 * Light markdown rendering for AI responses.
 * Handles: headers, inline code, code blocks, bold.
 */
function renderMarkdownLite(text) {
  return text
    // Code blocks (```...```) — cyan
    .replace(/```(\w*)\n([\s\S]*?)```/g, (_m, lang, code) => {
      const langTag = lang ? c().dim(` ${lang}`) : '';
      const codeLines = code.split('\n').map(l => `  ${c().dim('│')} ${c().white(l)}`).join('\n');
      return `${c().dim('  ┌──')}${langTag}\n${codeLines}\n${c().dim('  └──')}`;
    })
    // Headers
    .replace(/^(#{1,3})\s+(.+)$/gm, (_m, hashes, title) => {
      return c().bold.cyan(`  ${title}`);
    })
    // Bold
    .replace(/\*\*(.+?)\*\*/g, (_m, text) => c().bold(text))
    // Inline code
    .replace(/`([^`]+)`/g, (_m, code) => c().cyan(code))
    // Bullet lists
    .replace(/^(\s*)[-*]\s+/gm, '$1• ');
}

// ── Interactive Prompt ──────────────────────────────────────────────────

/**
 * Present numbered options to the user and wait for selection.
 * Returns the selected option(s) or null if cancelled.
 *
 * @param {string} question - The question to ask
 * @param {Array<{label: string, description?: string}>} options
 * @param {object} [opts]
 * @param {boolean} [opts.multiSelect=false]
 * @param {readline.Interface} [opts.rl] - existing readline to reuse
 * @returns {Promise<string|string[]|null>}
 */
async function askInlineQuestion(question, options, opts = {}) {
  const readline = require('readline');

  console.log('');
  console.log(c().yellow(`  ❓ ${question}`));
  console.log('');

  options.forEach((opt, i) => {
    const num = c().cyan(`  [${i + 1}]`);
    const label = c().white(opt.label);
    const desc = opt.description ? c().dim(` — ${opt.description}`) : '';
    console.log(`${num} ${label}${desc}`);
  });

  // Add "Other" option
  console.log(c().dim(`  [${options.length + 1}] 其他 (自由输入)`));
  console.log(c().dim(`  [0] 跳过`));
  console.log('');

  // Read selection
  const rl = opts.rl || readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  return new Promise((resolve) => {
    const prompt = opts.multiSelect
      ? c().dim('  选择 (多选用逗号分隔, 如 1,3): ')
      : c().dim('  选择: ');

    rl.question(prompt, (answer) => {
      if (!opts.rl) rl.close();

      const trimmed = answer.trim();
      if (!trimmed || trimmed === '0') {
        resolve(null);
        return;
      }

      // Free input mode
      const lastIdx = options.length + 1;
      if (trimmed === String(lastIdx)) {
        // Ask for free text
        const rl2 = readline.createInterface({ input: process.stdin, output: process.stdout });
        rl2.question(c().dim('  请输入: '), (text) => {
          rl2.close();
          resolve(text.trim() || null);
        });
        return;
      }

      if (opts.multiSelect) {
        const indices = trimmed.split(/[,，\s]+/).map(s => parseInt(s, 10) - 1);
        const selected = indices
          .filter(i => i >= 0 && i < options.length)
          .map(i => options[i].label);
        resolve(selected.length > 0 ? selected : null);
      } else {
        const idx = parseInt(trimmed, 10) - 1;
        if (idx >= 0 && idx < options.length) {
          resolve(options[idx].label);
        } else {
          resolve(trimmed); // treat as free input
        }
      }
    });
  });
}

// ── AI Response Renderer ────────────────────────────────────────────────

/**
 * Wrap a line at terminal width, preserving ANSI escape codes.
 * Skips lines inside code blocks (prefixed with │).
 * @param {string} line
 * @param {number} maxWidth
 * @returns {string}
 */
function wrapLine(line, maxWidth) {
  if (maxWidth <= 0) return line;
  // Strip ANSI for length measurement
  const stripped = line.replace(/\x1b\[[0-9;]*m/g, '');
  if (stripped.length <= maxWidth) return line;

  // Don't wrap code block lines (contain │ indicator)
  if (stripped.includes('│')) return line;

  // Simple word-boundary wrapping on the visible text
  const words = stripped.split(/(\s+)/);
  const lines = [];
  let current = '';
  let currentLen = 0;
  const indent = '    '; // continuation indent

  for (const word of words) {
    if (currentLen + word.length > maxWidth && current.length > 0) {
      lines.push(current);
      current = indent + word.trimStart();
      currentLen = indent.length + word.trimStart().length;
    } else {
      current += word;
      currentLen += word.length;
    }
  }
  if (current) lines.push(current);

  return lines.join('\n');
}

/**
 * Render a complete AI response with all formatting.
 * @param {string} text - raw AI response text
 * @param {object} [opts]
 * @param {object} [opts.chalk] - chalk instance
 * @returns {string} rendered text for console output
 */
function renderAiResponse(text) {
  if (!text) return '';

  // First handle diff blocks
  let rendered = renderResponseWithDiffs(text);

  // Then apply markdown-lite
  rendered = renderMarkdownLite(rendered);

  // Word-wrap long lines to terminal width
  const cols = (process.stdout.columns || 80) - 6; // leave margin for │ prefix
  if (cols > 20) {
    rendered = rendered.split('\n').map(l => wrapLine(l, cols)).join('\n');
  }

  return rendered;
}

// ── Process Step Indicators (Claude Code style) ────────────────────────

const DOT_PENDING  = '○';   // not started
const DOT_ACTIVE   = '✳';   // in-progress (animated color)
const DOT_SUCCESS  = '●';   // completed (green)
const DOT_ERROR    = '●';   // failed (red)
const DOT_DONE     = '✳';   // finished (gray, same glyph as active but dimmed)
const TREE_LAST    = '└';
const TREE_MID     = '├';

// Animated sparkle: ✳ cycles through warm colors while active
const SPARKLE_COLORS = ['red', 'redBright', 'yellow', 'magenta', 'red', 'redBright'];
let _sparkleTimers = new Set();

/**
 * Start an animated ✳ sparkle on the current active step line.
 * Returns a handle to stop the animation.
 * @param {string} label
 * @param {string} target
 * @param {string} detail
 * @returns {{ stop: Function }}
 */
function startSparkle(label, target = '', detail = '') {
  if (!process.stdout.isTTY) return { stop() {} };

  let frame = 0;
  const timer = setInterval(() => {
    const colorName = SPARKLE_COLORS[frame % SPARKLE_COLORS.length];
    frame++;
    const icon = c()[colorName](DOT_ACTIVE);
    const targetStr = target ? c().dim(`(${target})`) : '';
    const detailStr = detail ? c().dim(` ${detail}`) : '';
    const line = `  ${icon} ${c().white(label)} ${targetStr}${detailStr}`;
    process.stdout.write(`\r\x1b[K${line}`);
  }, 200);

  _sparkleTimers.add(timer);

  return {
    stop() {
      clearInterval(timer);
      _sparkleTimers.delete(timer);
      process.stdout.write('\r\x1b[K'); // clear the animated line
    },
  };
}

/**
 * Print a single process step line.
 * @param {'pending'|'active'|'success'|'error'|'done'} status
 * @param {string} label - e.g. "Reading", "Write", "Bash"
 * @param {string} [target] - e.g. "src/cli/repl.js", "node -c ..."
 * @param {string} [detail] - e.g. "(ctrl+o to expand)", "→ OK"
 */
function printStepLine(status, label, target = '', detail = '') {
  let dot;
  switch (status) {
    case 'active':  dot = c().redBright(DOT_ACTIVE); break;
    case 'success': dot = c().green(DOT_SUCCESS); break;
    case 'error':   dot = c().red(DOT_ERROR); break;
    case 'done':    dot = c().dim(DOT_DONE); break;
    default:        dot = c().dim(DOT_PENDING); break;
  }

  const targetStr = target ? c().dim(`(${target})`) : '';
  const detailStr = detail ? c().dim(` ${detail}`) : '';
  const labelColor = status === 'success' ? c().green(label)
                   : status === 'error'   ? c().red(label)
                   : status === 'active'  ? c().white(label)
                   : c().dim(label);

  console.log(`  ${dot} ${labelColor} ${targetStr}${detailStr}`);
}

/**
 * Print an indented detail line with tree branch character.
 * @param {string} text - detail text
 * @param {boolean} [isLast=true] - whether this is the last detail line
 */
function printStepDetail(text, isLast = true) {
  const branch = isLast ? TREE_LAST : TREE_MID;
  console.log(`    ${c().dim(branch)} ${c().dim(text)}`);
}

/**
 * ProcessTracker — manages a sequence of process steps with live updates.
 *
 * Usage:
 *   const tracker = new ProcessTracker();
 *   tracker.start('Reading', 'src/cli/repl.js', '1 file...');
 *   // ... do work ...
 *   tracker.complete('Read 245 lines');
 *   tracker.start('Write', 'src/cli/ai.js');
 *   // ... do work ...
 *   tracker.complete('Added 3 lines');
 */
class ProcessTracker {
  constructor() {
    this._current = null;
    this._startTime = null;
    this._sparkle = null;
  }

  /**
   * Start a new step. Completes any previous in-progress step first.
   * @param {string} label - e.g. "Reading", "Write", "Bash", "AI 思考"
   * @param {string} [target] - e.g. file path, command, etc.
   * @param {string} [hint] - e.g. "1 file...", "ctrl+o to expand"
   */
  start(label, target = '', hint = '') {
    // Auto-complete previous step if still active
    if (this._current) {
      this._finishCurrent('done');
    }
    this._current = { label, target, hint };
    this._startTime = Date.now();

    // Print the initial static line, then overlay sparkle animation
    printStepLine('active', label, target, hint);
    this._sparkle = startSparkle(label, target, hint);

    // Sync to HUD
    try { require('./hudRenderer').toolStart(label, target); } catch {}
  }

  /**
   * Complete the current step — shows gray ✳ (finished, no longer active).
   * @param {string} [detail] - completion detail shown on tree line
   */
  complete(detail = '') {
    this._finishCurrent('done', detail);
  }

  /**
   * Mark the current step as failed.
   * @param {string} [detail] - error detail shown on tree line
   */
  fail(detail = '') {
    this._finishCurrent('error', detail);
  }

  /**
   * Internal: overwrite current active line with final status + detail.
   */
  _finishCurrent(status, detail = '') {
    if (!this._current) return;

    // Stop sparkle animation
    if (this._sparkle) {
      this._sparkle.stop();
      this._sparkle = null;
    }

    const elapsed = Date.now() - this._startTime;
    const elapsedStr = elapsed > 1000 ? ` (${(elapsed / 1000).toFixed(1)}s)` : '';

    // Sync to HUD
    try { require('./hudRenderer').toolEnd(this._current.label, status, elapsed); } catch {}

    if (process.stdout.isTTY) {
      // Move cursor up to overwrite the active line
      process.stdout.write('\x1b[1A\r\x1b[K'); // up 1 line, clear
      const { label, target } = this._current;
      printStepLine(status, label, target, elapsedStr);
    }
    // On non-TTY, skip rewrite — the active line stays as-is (no double output)

    if (detail) {
      printStepDetail(detail);
    }

    this._current = null;
    this._startTime = null;
  }

  /**
   * Whether a step is currently in progress.
   */
  get isActive() {
    return this._current !== null;
  }
}

// ── Task Plan Tracker (Claude Code style task list) ────────────────────

const TASK_PENDING     = '☐';
const TASK_IN_PROGRESS = '■';
const TASK_COMPLETED   = '✔';

/**
 * TaskPlanTracker — displays and updates a task checklist.
 *
 * Usage:
 *   const plan = new TaskPlanTracker();
 *   plan.addTask('Fetch market data');
 *   plan.addTask('Run backtest');
 *   plan.addTask('Generate report');
 *   plan.render();          // show all tasks
 *   plan.start(0);          // mark first as in-progress → re-render
 *   plan.complete(0);       // mark as done → re-render
 */
class TaskPlanTracker {
  constructor() {
    this._tasks = [];
    this._renderedLines = 0; // how many lines the last render() produced
  }

  /**
   * Add a task to the plan.
   * @param {string} description
   * @returns {number} task index
   */
  addTask(description) {
    this._tasks.push({ description, status: 'pending' });
    return this._tasks.length - 1;
  }

  /**
   * Mark a task as in-progress.
   */
  start(index) {
    if (this._tasks[index]) {
      this._tasks[index].status = 'in_progress';
      this._rerender();
    }
  }

  /**
   * Mark a task as completed.
   */
  complete(index) {
    if (this._tasks[index]) {
      this._tasks[index].status = 'completed';
      this._rerender();
    }
  }

  /**
   * Mark a task as failed.
   */
  fail(index) {
    if (this._tasks[index]) {
      this._tasks[index].status = 'error';
      this._rerender();
    }
  }

  /**
   * Get summary line: "4 tasks (2 done, 1 in progress, 1 open)"
   */
  getSummary() {
    const done = this._tasks.filter(t => t.status === 'completed').length;
    const inProgress = this._tasks.filter(t => t.status === 'in_progress').length;
    const open = this._tasks.filter(t => t.status === 'pending').length;
    const errored = this._tasks.filter(t => t.status === 'error').length;

    const parts = [];
    if (done > 0)       parts.push(`${done} done`);
    if (inProgress > 0) parts.push(`${inProgress} in progress`);
    if (open > 0)       parts.push(`${open} open`);
    if (errored > 0)    parts.push(`${errored} failed`);

    return `${this._tasks.length} tasks (${parts.join(', ')})`;
  }

  /**
   * Render the full task list to stdout.
   */
  render() {
    console.log('');
    console.log(c().dim(`  ${this.getSummary()}`));
    for (const task of this._tasks) {
      let icon, color;
      switch (task.status) {
        case 'completed':
          icon = c().green(TASK_COMPLETED);
          color = c().strikethrough.dim;
          break;
        case 'in_progress':
          icon = c().yellow(TASK_IN_PROGRESS);
          color = c().bold.white;
          break;
        case 'error':
          icon = c().red('✗');
          color = c().red;
          break;
        default:
          icon = c().dim(TASK_PENDING);
          color = c().white;
          break;
      }
      console.log(`    ${icon} ${color(task.description)}`);
    }
    this._renderedLines = this._tasks.length + 2; // summary + blank + tasks
  }

  /**
   * Re-render by clearing previous output and printing again.
   */
  _rerender() {
    if (this._renderedLines > 0 && process.stdout.isTTY) {
      // Move up and clear previous render
      for (let i = 0; i < this._renderedLines; i++) {
        process.stdout.write('\x1b[1A\r\x1b[K');
      }
    }
    this.render();
  }

  /**
   * Extract tasks from an AI response containing a numbered plan.
   * Looks for patterns like "1. xxx\n2. xxx\n3. xxx" under a "计划"/"步骤" heading.
   * @param {string} text - AI response text
   * @returns {boolean} true if tasks were extracted
   */
  extractFromResponse(text) {
    // Look for numbered items (Chinese or English)
    const planPattern = /(?:^|\n)\s*(\d+)[.、）)]\s*(.+)/g;
    const matches = [...text.matchAll(planPattern)];

    if (matches.length >= 2) {
      for (const m of matches) {
        this.addTask(m[2].trim().slice(0, 60));
      }
      return true;
    }
    return false;
  }

  get length() { return this._tasks.length; }
  get allDone() { return this._tasks.every(t => t.status === 'completed' || t.status === 'error'); }
}

// ── Context Compaction Notice ──────────────────────────────────────────

/**
 * Print a "Compacting conversation..." notice (Claude Code style).
 * @param {object} opts - { elapsed, tokens, thought }
 */
function printCompactingNotice(opts = {}) {
  const parts = [];
  if (opts.elapsed) parts.push(opts.elapsed);
  if (opts.tokens)  parts.push(`↑ ${opts.tokens} tokens`);
  if (opts.thought) parts.push(`thought for ${opts.thought}`);

  const meta = parts.length > 0 ? c().dim(` (${parts.join(' · ')})`) : '';
  console.log(`  ${c().yellow('*')} ${c().yellow.bold('压缩上下文...')}${meta}`);

  if (opts.tip) {
    printStepDetail(`Tip: ${opts.tip}`);
  }
}

// ── Legacy helpers (preserved for backward compatibility) ──────────────

function printProcessStep(icon, message, detail = '') {
  const detailStr = detail ? c().dim(` (${detail})`) : '';
  console.log(`  ${icon} ${c().white(message)}${detailStr}`);
}

function printToolCall(toolName, args = '') {
  printStepLine('active', `调用 ${toolName}`, args);
}

/**
 * Print a brief description line before an action (Claude Code style).
 * Shows a dim one-liner explaining what will be done next.
 * @param {string} description - e.g. "Updating the spinner icon to use ✳"
 */
function printActionHint(description) {
  console.log(c().dim(`  ${description}`));
}

function printThinkingStep(thought) {
  const truncated = thought.length > 80 ? thought.slice(0, 80) + '...' : thought;
  console.log(`  ${c().yellow('💭')} ${c().dim(truncated)}`);
}

// ── Claude Code-style Tool Call Display ──────────────────────────────

/**
 * Print a tool call start line (Claude Code style).
 * Shows: ● ToolName(param: "value", path: "file.js")
 *
 * @param {string} toolName - e.g. "Search", "Read", "Bash", "Write"
 * @param {object|string} params - tool parameters to display
 * @returns {number} line count printed (for cursor-up later)
 */
function printToolCallStart(toolName, params = {}) {
  let paramStr = '';
  if (typeof params === 'string') {
    paramStr = params;
  } else if (params && typeof params === 'object') {
    const entries = Object.entries(params).slice(0, 3); // max 3 params shown
    paramStr = entries.map(([k, v]) => {
      const val = typeof v === 'string'
        ? (v.length > 40 ? `"${v.slice(0, 40)}..."` : `"${v}"`)
        : String(v);
      return `${k}: ${val}`;
    }).join(', ');
  }

  console.log(`  ${c().redBright(DOT_ACTIVE)} ${c().bold(toolName)}${c().dim(`(${paramStr})`)}`);
  return 1;
}

/**
 * Print a tool call result, overwriting the active line.
 * Shows: ● ToolName(params) with green/red dot + tree detail line.
 *
 * @param {string} toolName
 * @param {object|string} params - same params as start (for redraw)
 * @param {'success'|'error'} status
 * @param {string} detail - result summary, e.g. "Found 3 matches", "245 lines"
 * @param {number} elapsed - ms elapsed
 */
function printToolCallResult(toolName, params, status, detail = '', elapsed = 0) {
  let paramStr = '';
  if (typeof params === 'string') {
    paramStr = params;
  } else if (params && typeof params === 'object') {
    const entries = Object.entries(params).slice(0, 3);
    paramStr = entries.map(([k, v]) => {
      const val = typeof v === 'string'
        ? (v.length > 40 ? `"${v.slice(0, 40)}..."` : `"${v}"`)
        : String(v);
      return `${k}: ${val}`;
    }).join(', ');
  }

  // Move cursor up to overwrite active line
  if (process.stdout.isTTY) {
    process.stdout.write('\x1b[1A\r\x1b[K');
  }

  const dot = status === 'success' ? c().dim(DOT_DONE) : c().red(DOT_ERROR);
  const nameColor = status === 'success' ? c().dim(toolName) : c().red(toolName);
  const elapsedStr = elapsed > 500 ? c().dim(` (${(elapsed / 1000).toFixed(1)}s)`) : '';
  console.log(`  ${dot} ${c().bold(nameColor)}${c().dim(`(${paramStr})`)}${elapsedStr}`);

  if (detail) {
    printStepDetail(detail);
  }
}

/**
 * Print a file operation result with line count statistics.
 * Shows Claude Code style: "Added N lines, removed M lines"
 *
 * @param {'update'|'create'|'delete'} operation
 * @param {string} filePath - file path relative to cwd
 * @param {object} [stats] - { added: number, removed: number, total: number }
 * @param {number} [elapsed] - ms elapsed
 */
function printFileOperation(operation, filePath, stats = {}, elapsed = 0) {
  const opColors = {
    update: { dot: c().green(DOT_SUCCESS), label: c().green('Update'), verb: 'Updated' },
    create: { dot: c().green(DOT_SUCCESS), label: c().green('Create'), verb: 'Created' },
    delete: { dot: c().red(DOT_ERROR), label: c().red('Delete'), verb: 'Deleted' },
  };
  const op = opColors[operation] || opColors.update;
  const elapsedStr = elapsed > 500 ? c().dim(` (${(elapsed / 1000).toFixed(1)}s)`) : '';

  console.log(`  ${op.dot} ${c().bold(op.label)}${c().dim(`(${filePath})`)}${elapsedStr}`);

  // Show line change stats
  const statParts = [];
  if (stats.added > 0) statParts.push(`Added ${stats.added} line${stats.added !== 1 ? 's' : ''}`);
  if (stats.removed > 0) statParts.push(`removed ${stats.removed} line${stats.removed !== 1 ? 's' : ''}`);
  if (statParts.length > 0) {
    printStepDetail(statParts.join(', '));
  }
}

/**
 * Print a diff view with line numbers and red/green coloring.
 * Includes context lines around changes.
 *
 * @param {string} filePath
 * @param {Array<{lineNum: number, type: 'add'|'remove'|'context', content: string}>} lines
 * @param {object} [stats] - { added, removed }
 */
function printInlineDiff(filePath, lines, stats = {}) {
  const maxLineNum = Math.max(...lines.map(l => l.lineNum || 0));
  const lineNumWidth = String(maxLineNum).length;

  for (const line of lines) {
    const num = String(line.lineNum || '').padStart(lineNumWidth);
    switch (line.type) {
      case 'add':
        // Green background highlight for added lines
        console.log(c().bgGreen.black(`  ${num} + ${line.content}`));
        break;
      case 'remove':
        // Red background highlight for removed lines
        console.log(c().bgRed.white(`  ${num} - ${line.content}`));
        break;
      default:
        console.log(`  ${c().dim(num)}   ${c().dim(line.content)}`);
        break;
    }
  }
}

/**
 * Render "Running N agents..." header.
 * @param {number} count
 * @param {string} [hint] - e.g. "(ctrl+o to expand)"
 */
function renderAgentHeader(count, hint = '') {
  const hintStr = hint ? c().dim(`  ${hint}`) : '';
  console.log(`  ${c().redBright(DOT_ACTIVE)} ${c().bold(`Running ${count} agents...`)}${hintStr}`);
}

/**
 * Render tree-style agent progress.
 * @param {Array<{name: string, status: 'pending'|'running'|'completed'|'error', toolCalls?: number, tokens?: number, elapsed?: string, detail?: string}>} agents
 * @returns {number} lines rendered
 */
function renderAgentProgress(agents) {
  let lines = 0;
  for (let i = 0; i < agents.length; i++) {
    const agent = agents[i];
    const isLast = i === agents.length - 1;
    const branch = isLast ? '└' : '├';

    let statusIcon, nameColor;
    switch (agent.status) {
      case 'completed':
        statusIcon = c().dim(DOT_DONE);
        nameColor = c().dim;
        break;
      case 'error':
        statusIcon = c().red(DOT_ERROR);
        nameColor = c().red;
        break;
      case 'running':
        statusIcon = c().redBright(DOT_ACTIVE);
        nameColor = c().bold.white;
        break;
      default:
        statusIcon = c().dim(DOT_PENDING);
        nameColor = c().dim;
        break;
    }

    // Stats string: tool calls · tokens · elapsed
    const stats = [];
    if (agent.toolCalls > 0) stats.push(`${agent.toolCalls} tool uses`);
    if (agent.tokens > 0) {
      const tokenStr = agent.tokens >= 1000
        ? `${(agent.tokens / 1000).toFixed(1)}k tokens`
        : `${agent.tokens} tokens`;
      stats.push(tokenStr);
    }
    if (agent.elapsed) stats.push(agent.elapsed);
    const statsStr = stats.length > 0 ? c().dim(` · ${stats.join(' · ')}`) : '';

    console.log(`  ${branch} ${nameColor(agent.name)}${statsStr}`);
    lines++;

    // Detail line (sub-tree)
    if (agent.detail) {
      const subBranch = isLast ? ' ' : '│';
      console.log(`  ${subBranch} ${c().dim(`└ ${agent.detail}`)}`);
      lines++;
    }
  }
  return lines;
}

/**
 * Render agent/task completion summary line.
 * Shows: Done (N tool uses · X.Xk tokens · Nm NNs)
 *
 * @param {object} stats - { toolCalls, tokens, elapsedMs }
 */
function renderAgentDone(stats = {}) {
  const parts = [];
  if (stats.toolCalls > 0) parts.push(`${stats.toolCalls} tool uses`);
  if (stats.tokens > 0) {
    parts.push(`${(stats.tokens / 1000).toFixed(1)}k tokens`);
  }
  if (stats.elapsedMs > 0) {
    const sec = Math.floor(stats.elapsedMs / 1000);
    const min = Math.floor(sec / 60);
    const remSec = sec % 60;
    parts.push(min > 0 ? `${min}m ${remSec}s` : `${sec}s`);
  }

  const detail = parts.length > 0 ? ` (${parts.join(' · ')})` : '';
  console.log(`  ${c().dim('└')} ${c().green('Done')}${c().dim(detail)}`);
}

/**
 * Render "(ctrl+o to expand)" hint.
 */
function renderExpandHint() {
  console.log(c().dim('  (ctrl+o to expand)'));
}

/**
 * ExpandableSection — manages collapsible output sections.
 * Stores full output but displays only a summary until expanded.
 */
class ExpandableSection {
  constructor() {
    this._sections = [];
    this._expandedIndex = -1;
  }

  /**
   * Add a collapsible section.
   * @param {string} summary - one-line summary shown when collapsed
   * @param {string[]} fullOutput - full output lines shown when expanded
   */
  add(summary, fullOutput) {
    this._sections.push({ summary, fullOutput, expanded: false });
    return this._sections.length - 1;
  }

  /**
   * Toggle expand/collapse of a section.
   */
  toggle(index) {
    if (index >= 0 && index < this._sections.length) {
      this._sections[index].expanded = !this._sections[index].expanded;
    }
  }

  /**
   * Get all sections for display.
   */
  getSections() {
    return this._sections;
  }
}

/**
 * ToolUseTracker — Claude Code-style collapsible tool-use display.
 *
 * While running, shows:
 *   ● Explore(Explore training infrastructure)
 *     ├ Bash(grep -r "train.*start" /path/to/dir)
 *     │ Running...
 *     ├ Read(backend/src/cli/router.js)
 *     │ Running...
 *     └ +12 more tool uses (ctrl+o to expand)
 *     (ctrl+b to run in background)
 *
 * When done, collapses to:
 *   ● Explore(Explore training infrastructure)
 *     └ Done (24 tool uses · 60.9k tokens · 2m 15s)
 *     (ctrl+o to expand)
 */
class ToolUseTracker {
  /**
   * @param {string} label - Top-level label (e.g. "Explore", "Agent")
   * @param {string} description - Short description (e.g. "Explore training infrastructure")
   * @param {object} [opts]
   * @param {number} [opts.maxVisible=3] - Max tool calls visible before "+N more"
   */
  constructor(label, description, opts = {}) {
    this._label = label;
    this._description = description;
    this._maxVisible = opts.maxVisible || 3;
    this._tools = [];          // [{ name, params, status, elapsed, detail }]
    this._renderedLines = 0;
    this._startTime = Date.now();
    this._totalTokens = 0;
    this._finished = false;
    this._headerPrinted = false;
  }

  /**
   * Print the header line (call once before adding tools).
   */
  printHeader() {
    if (this._headerPrinted) return;
    this._headerPrinted = true;
    console.log(`  ${c().dim(DOT_ACTIVE)} ${c().bold(this._label)}${c().dim(`(${this._description})`)}`);
    this._renderedLines = 1;
  }

  /**
   * Record a tool call starting.
   * @param {string} name - Tool name (e.g. "Read", "Bash", "Grep")
   * @param {string} params - Brief param string
   */
  toolStart(name, params = '') {
    this._tools.push({ name, params, status: 'running', elapsed: 0, detail: '', startTime: Date.now() });
    this._rerender();
  }

  /**
   * Record a tool call completing.
   * @param {string} name - Tool name
   * @param {'success'|'error'} status
   * @param {string} [detail]
   * @param {number} [elapsed] - ms
   */
  toolEnd(name, status = 'success', detail = '', elapsed = 0) {
    // Find the most recent matching running tool
    for (let i = this._tools.length - 1; i >= 0; i--) {
      if (this._tools[i].name === name && this._tools[i].status === 'running') {
        this._tools[i].status = status;
        this._tools[i].detail = detail;
        this._tools[i].elapsed = elapsed || (Date.now() - this._tools[i].startTime);
        break;
      }
    }
    this._rerender();
  }

  /**
   * Add token count.
   * @param {number} tokens
   */
  addTokens(tokens) {
    this._totalTokens += tokens;
  }

  /**
   * Mark as finished and collapse to summary.
   */
  finish() {
    this._finished = true;
    this._rerender();
  }

  /**
   * Clear previously rendered lines and re-render.
   */
  _rerender() {
    if (!this._headerPrinted) this.printHeader();

    // Clear previous tool lines (not the header)
    if (process.stdout.isTTY && this._renderedLines > 1) {
      for (let i = 0; i < this._renderedLines - 1; i++) {
        process.stdout.write('\x1b[1A\r\x1b[K');
      }
    }

    let lines = 0;

    if (this._finished) {
      // Replace header with green dot
      if (process.stdout.isTTY) {
        process.stdout.write('\x1b[1A\r\x1b[K');
      }
      console.log(`  ${c().green(DOT_SUCCESS)} ${c().bold(this._label)}${c().dim(`(${this._description})`)}`);
      lines++;

      // Summary line
      const elapsed = Date.now() - this._startTime;
      const parts = [];
      parts.push(`${this._tools.length} tool uses`);
      if (this._totalTokens > 0) {
        parts.push(this._totalTokens >= 1000
          ? `${(this._totalTokens / 1000).toFixed(1)}k tokens`
          : `${this._totalTokens} tokens`);
      }
      const sec = Math.floor(elapsed / 1000);
      const min = Math.floor(sec / 60);
      const remSec = sec % 60;
      parts.push(min > 0 ? `${min}m ${remSec}s` : `${sec}s`);

      console.log(`    ${c().dim('└')} ${c().green('Done')} ${c().dim(`(${parts.join(' · ')})`)}`);
      lines++;
      console.log(c().dim('    (ctrl+o to expand)'));
      lines++;

      this._renderedLines = 1 + lines;
      return;
    }

    // Running state: show recent tools with tree branches
    const visible = this._tools.slice(-this._maxVisible);
    const hiddenCount = Math.max(0, this._tools.length - this._maxVisible);

    for (let i = 0; i < visible.length; i++) {
      const tool = visible[i];
      const isLast = i === visible.length - 1 && hiddenCount === 0;
      const branch = isLast ? '└' : '├';

      let statusIcon;
      if (tool.status === 'running') {
        statusIcon = '';
      } else if (tool.status === 'success') {
        statusIcon = '';
      } else {
        statusIcon = '';
      }

      const paramStr = tool.params ? tool.params.slice(0, 80) : '';
      console.log(`    ${c().dim(branch)} ${c().bold(tool.name)}${c().dim(`(${paramStr})`)}`);
      lines++;

      // Sub-status line
      if (tool.status === 'running') {
        const subBranch = isLast ? ' ' : '│';
        console.log(`    ${c().dim(subBranch)} ${c().dim('Running…')}`);
        lines++;
      }
    }

    if (hiddenCount > 0) {
      console.log(`    ${c().dim(`+${hiddenCount} more tool uses (ctrl+o to expand)`)}`);
      lines++;
    }

    console.log(c().dim('    (ctrl+b to run in background)'));
    lines++;

    this._renderedLines = 1 + lines;
  }

  /**
   * Get total tool count.
   */
  get toolCount() { return this._tools.length; }
  get totalTokens() { return this._totalTokens; }
  get elapsedMs() { return Date.now() - this._startTime; }
}

module.exports = {
  DynamicSpinner,
  ProcessTracker,
  TaskPlanTracker,
  ToolUseTracker,
  ExpandableSection,
  renderDiff,
  renderResponseWithDiffs,
  renderMarkdownLite,
  renderAiResponse,
  askInlineQuestion,
  printStepLine,
  printStepDetail,
  printCompactingNotice,
  printProcessStep,
  printToolCall,
  printActionHint,
  printToolCallStart,
  printToolCallResult,
  printFileOperation,
  printInlineDiff,
  renderAgentHeader,
  renderAgentProgress,
  renderAgentDone,
  renderExpandHint,
  printThinkingStep,
  startSparkle,
  PHASE_LABELS,
  DOT_PENDING,
  DOT_ACTIVE,
  DOT_SUCCESS,
  DOT_ERROR,
  DOT_DONE,
  TASK_PENDING,
  TASK_IN_PROGRESS,
  TASK_COMPLETED,
};
