/**
 * Permission Dialog — Claude Code-style box-drawn approval prompt.
 *
 * Renders a Unicode-bordered box with tool details, risk coloring,
 * and an interactive approval menu.
 *
 * Usage:
 *   const { formatPermissionDialog } = require('./permissionDialog');
 *   const decision = await formatPermissionDialog('shell_command', params, riskInfo, reasoning);
 *   // → 'allow' | 'allow-session' | 'allow-always' | 'deny'
 */
const chalk = require('chalk');

// ── Risk colors ─────────────────────────────────────────────────────

const RISK_STYLES = {
  safe:     { color: chalk.green,      badge: chalk.bgGreen.black(' SAFE ') },
  low:      { color: chalk.cyan,       badge: chalk.bgCyan.black(' LOW ') },
  medium:   { color: chalk.yellow,     badge: chalk.bgYellow.black(' MEDIUM ') },
  high:     { color: chalk.red,        badge: chalk.bgRed.white(' HIGH ') },
  critical: { color: chalk.redBright,  badge: chalk.bgRedBright.white(' CRITICAL ') },
};

// ── ANSI-safe width measurement ─────────────────────────────────────

function stripAnsi(str) {
  return str.replace(/\x1b\[[0-9;]*m/g, '');
}

function displayWidth(str) {
  const clean = stripAnsi(str);
  let width = 0;
  for (const ch of clean) {
    const code = ch.codePointAt(0);
    // CJK and fullwidth characters take 2 columns
    if ((code >= 0x1100 && code <= 0x115F) ||
        (code >= 0x2E80 && code <= 0xA4CF) ||
        (code >= 0xAC00 && code <= 0xD7AF) ||
        (code >= 0xF900 && code <= 0xFAFF) ||
        (code >= 0xFE10 && code <= 0xFE6F) ||
        (code >= 0xFF01 && code <= 0xFF60) ||
        (code >= 0xFFE0 && code <= 0xFFE6) ||
        (code >= 0x20000 && code <= 0x2FA1F)) {
      width += 2;
    } else {
      width += 1;
    }
  }
  return width;
}

function padRight(str, targetWidth) {
  const current = displayWidth(str);
  const needed = Math.max(0, targetWidth - current);
  return str + ' '.repeat(needed);
}

// ── Box rendering ───────────────────────────────────────────────────

/**
 * Render a Unicode box around tool call details.
 *
 * @param {string} toolName - Tool name
 * @param {object} params - Tool parameters
 * @param {object} riskInfo - { level, label, color }
 * @param {string} [reasoning] - AI reasoning text
 * @returns {string} Rendered box text (multi-line)
 */
function renderToolBox(toolName, params, riskInfo, reasoning) {
  const cols = process.stdout.columns || 80;
  const boxWidth = Math.min(cols - 4, 72);
  const innerWidth = boxWidth - 4; // 2 border chars + 2 padding

  const risk = riskInfo || { level: 'medium', label: 'Unknown' };
  const style = RISK_STYLES[risk.level] || RISK_STYLES.medium;
  const borderColor = style.color;

  const lines = [];

  // Top border
  lines.push(borderColor(`  ┌${'─'.repeat(boxWidth - 2)}┐`));

  // Tool name + risk badge
  const header = `  🔧 ${toolName}`;
  const badge = style.badge;
  const headerLine = `${header}  ${badge}`;
  lines.push(borderColor('  │ ') + padRight(headerLine, innerWidth) + borderColor(' │'));

  // Separator
  lines.push(borderColor(`  ├${'─'.repeat(boxWidth - 2)}┤`));

  // Parameters
  const cleanParams = { ...params };
  delete cleanParams._reasoning; // Don't show internal fields

  if (Object.keys(cleanParams).length > 0) {
    lines.push(borderColor('  │ ') + padRight(chalk.dim('Parameters:'), innerWidth) + borderColor(' │'));
    for (const [key, value] of Object.entries(cleanParams)) {
      let displayVal;
      if (typeof value === 'string') {
        displayVal = value.length > 50 ? value.slice(0, 47) + '...' : value;
      } else {
        displayVal = JSON.stringify(value);
        if (displayVal.length > 50) displayVal = displayVal.slice(0, 47) + '...';
      }
      const paramLine = `  ${chalk.white(key)}: ${chalk.dim(displayVal)}`;
      lines.push(borderColor('  │ ') + padRight(paramLine, innerWidth) + borderColor(' │'));
    }
  } else {
    lines.push(borderColor('  │ ') + padRight(chalk.dim('  (no parameters)'), innerWidth) + borderColor(' │'));
  }

  // AI reasoning
  if (reasoning) {
    lines.push(borderColor(`  ├${'─'.repeat(boxWidth - 2)}┤`));
    lines.push(borderColor('  │ ') + padRight(chalk.dim('💭 AI reasoning:'), innerWidth) + borderColor(' │'));

    // Word-wrap reasoning text
    const words = reasoning.split(/\s+/);
    let currentLine = '  ';
    for (const word of words) {
      if (displayWidth(currentLine + word) > innerWidth - 2) {
        lines.push(borderColor('  │ ') + padRight(chalk.dim(currentLine), innerWidth) + borderColor(' │'));
        currentLine = '  ' + word + ' ';
      } else {
        currentLine += word + ' ';
      }
    }
    if (currentLine.trim()) {
      lines.push(borderColor('  │ ') + padRight(chalk.dim(currentLine), innerWidth) + borderColor(' │'));
    }
  }

  // Bottom border
  lines.push(borderColor(`  └${'─'.repeat(boxWidth - 2)}┘`));

  return lines.join('\n');
}

// ── Interactive approval ────────────────────────────────────────────

/**
 * Prompt user for tool execution approval.
 * Uses inquirer list for arrow-key selection if available,
 * falls back to text input for non-TTY.
 *
 * @param {string} toolName - Tool name
 * @param {object} [options]
 * @param {string} [options.risk] - Risk level for display
 * @returns {Promise<'allow'|'allow-session'|'allow-always'|'deny'>}
 */
async function promptApproval(toolName, options = {}) {
  const isTTY = process.stdin.isTTY && process.stdout.isTTY;

  if (isTTY) {
    try {
      const inquirer = require('inquirer');
      const risk = options.risk || 'medium';
      const style = RISK_STYLES[risk] || RISK_STYLES.medium;

      const { choice } = await inquirer.prompt([{
        type: 'list',
        name: 'choice',
        message: `Execute ${style.color(toolName)}?`,
        choices: [
          { name: `${chalk.green('Yes')} — execute this time`, value: 'allow' },
          { name: `${chalk.cyan('Yes, trust for session')} — allow all calls this session`, value: 'allow-session' },
          { name: `${chalk.blue('Yes, always trust')} — permanently approve this tool`, value: 'allow-always' },
          { name: `${chalk.red('No')} — deny execution`, value: 'deny' },
        ],
        default: 0,
      }]);

      return choice;
    } catch {
      // inquirer failed (e.g., piped input), fall through to text
    }
  }

  // Text fallback for non-TTY
  return new Promise((resolve) => {
    const rl = require('readline').createInterface({
      input: process.stdin,
      output: process.stdout,
    });

    console.log(`  ${chalk.green('1.')} Yes`);
    console.log(`  ${chalk.cyan('2.')} Yes, trust for session`);
    console.log(`  ${chalk.blue('3.')} Yes, always trust`);
    console.log(`  ${chalk.red('4.')} No`);

    rl.question(chalk.dim('  > '), (answer) => {
      rl.close();
      const n = answer.trim().toLowerCase();
      if (n === '1' || n === 'y' || n === 'yes' || n === '') resolve('allow');
      else if (n === '2' || n === 's') resolve('allow-session');
      else if (n === '3' || n === 'a') resolve('allow-always');
      else resolve('deny');
    });
  });
}

// ── Combined entry point ────────────────────────────────────────────

/**
 * Show the full permission dialog: box + approval prompt.
 *
 * @param {string} toolName - Tool name
 * @param {object} params - Tool call parameters
 * @param {object} riskInfo - { level, label }
 * @param {string} [reasoning] - AI reasoning
 * @returns {Promise<'allow'|'allow-session'|'allow-always'|'deny'>}
 */
async function formatPermissionDialog(toolName, params, riskInfo, reasoning) {
  console.log('');
  console.log(renderToolBox(toolName, params, riskInfo, reasoning));
  console.log('');

  return promptApproval(toolName, { risk: riskInfo?.level });
}

module.exports = {
  renderToolBox,
  promptApproval,
  formatPermissionDialog,
  RISK_STYLES,
};
