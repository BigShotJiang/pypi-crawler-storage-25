/**
 * Multi-Step Progress Display — terminal progress bars with step tracking.
 *
 * Features:
 *   - Multi-step progress with weighted steps
 *   - ANSI cursor manipulation for in-place line updates
 *   - TTY-aware: plain output when not a terminal
 *   - Colored progress bar (green/yellow/dim by completion)
 *
 * Uses chalk (project dependency) for colors.
 */
const chalk = require('chalk');

// ── Progress Bar Renderer ───────────────────────────────────────────────

const BLOCK_FILLED = '\u2588'; // █
const BLOCK_EMPTY  = '\u2591'; // ░

/**
 * Render a text-based progress bar string.
 *
 * @param {number} percent - Completion percentage (0–100)
 * @param {number} [width=30] - Character width of the bar
 * @returns {string} Styled progress bar, e.g. "████░░░░░"
 */
function renderProgressBar(percent, width = 30) {
  const clamped = Math.max(0, Math.min(100, percent));
  const filled = Math.round((clamped / 100) * width);
  const empty = width - filled;

  const barStr = BLOCK_FILLED.repeat(filled) + BLOCK_EMPTY.repeat(empty);

  // Color based on completion level
  if (clamped >= 100) {
    return chalk.green(barStr);
  } else if (clamped >= 50) {
    return chalk.yellow(barStr);
  }
  return chalk.dim(barStr);
}

// ── Multi-Step Progress ─────────────────────────────────────────────────

/**
 * Multi-step progress display with in-place terminal updates.
 *
 * Usage:
 *   const progress = new MultiStepProgress([
 *     { label: 'Fetching data', weight: 2 },
 *     { label: 'Running backtest', weight: 5 },
 *     { label: 'Generating report', weight: 1 },
 *   ]);
 *   progress.start(0);
 *   progress.advance(1, 'processing 500 bars...');
 *   progress.advance(2);
 *   progress.complete();
 *
 * @param {Array<{label: string, weight?: number}>} steps - Step definitions
 */
class MultiStepProgress {
  /**
   * @param {Array<{label: string, weight?: number}>} steps
   */
  constructor(steps) {
    if (!Array.isArray(steps) || steps.length === 0) {
      throw new Error('MultiStepProgress requires a non-empty steps array');
    }

    this._steps = steps.map((s, i) => ({
      label: s.label,
      weight: s.weight ?? 1,
      index: i,
    }));

    this._totalWeight = this._steps.reduce((sum, s) => sum + s.weight, 0);
    this._currentStep = -1;
    this._hasRendered = false;
    this._isTTY = !!process.stdout.isTTY;
  }

  /**
   * Calculate the overall percentage through step `stepIndex`.
   * @param {number} stepIndex
   * @returns {number}
   */
  _percentAtStep(stepIndex) {
    if (stepIndex < 0) return 0;
    let weightDone = 0;
    for (let i = 0; i <= stepIndex && i < this._steps.length; i++) {
      weightDone += this._steps[i].weight;
    }
    return Math.round((weightDone / this._totalWeight) * 100);
  }

  /**
   * Render a progress line to stdout.
   * @param {number} stepIndex
   * @param {string} [detail]
   */
  _render(stepIndex, detail) {
    const step = this._steps[stepIndex];
    if (!step) return;

    const stepNum = stepIndex + 1;
    const total = this._steps.length;
    const percent = this._percentAtStep(stepIndex);
    const bar = renderProgressBar(percent);
    const detailStr = detail ? ` ${chalk.dim(detail)}` : '';

    const line = `  Step ${stepNum}/${total}: ${step.label}${detailStr} [${bar}] ${percent}%`;

    if (this._isTTY) {
      // Overwrite the previous line if we already rendered one
      if (this._hasRendered) {
        process.stdout.write('\x1b[1A\r\x1b[K');
      }
      process.stdout.write(line + '\n');
    } else {
      // Non-TTY: simple line output, no cursor manipulation
      console.log(line);
    }

    this._hasRendered = true;
  }

  /**
   * Start rendering from a specific step.
   *
   * @param {number} stepIndex - Zero-based step index to begin
   */
  start(stepIndex) {
    this._currentStep = stepIndex;
    this._render(stepIndex);
  }

  /**
   * Advance to a new step, optionally with extra detail text.
   *
   * @param {number} stepIndex - Zero-based step index to advance to
   * @param {string} [detail] - Optional detail text shown after the label
   */
  advance(stepIndex, detail) {
    this._currentStep = stepIndex;
    this._render(stepIndex, detail);
  }

  /**
   * Mark all steps as complete with a green checkmark.
   */
  complete() {
    if (this._isTTY && this._hasRendered) {
      process.stdout.write('\x1b[1A\r\x1b[K');
    }

    const bar = renderProgressBar(100);
    const line = `  ${chalk.green('\u2714')} All steps complete [${bar}] 100%`;

    if (this._isTTY) {
      process.stdout.write(line + '\n');
    } else {
      console.log(line);
    }
  }

  /**
   * Abort the progress with a red error message.
   *
   * @param {string} reason - Reason for aborting
   */
  abort(reason) {
    if (this._isTTY && this._hasRendered) {
      process.stdout.write('\x1b[1A\r\x1b[K');
    }

    const currentLabel = this._currentStep >= 0
      ? this._steps[this._currentStep].label
      : 'unknown step';
    const line = chalk.red(`  \u2718 Aborted at "${currentLabel}": ${reason}`);

    if (this._isTTY) {
      process.stdout.write(line + '\n');
    } else {
      console.log(line);
    }
  }
}

module.exports = {
  MultiStepProgress,
  renderProgressBar,
};
