/**
 * AI conversational mode for the CLI.
 * When user input doesn't match a known command, it's sent to the LLM
 * with a quant-trading system prompt. The AI can also invoke tools
 * (quote, backtest, data fetch) by returning structured commands.
 *
 * Heavy modules (chalk, formatters) are lazy-loaded for fast cold start.
 */
const path = require('path');
const fs = require('fs');
const os = require('os');

// ── Lazy module loaders ──
let _chalk, _fmt;
const chalk = () => (_chalk ??= require('chalk'));
const fmt = () => (_fmt ??= require('./formatters'));

let _service = null;
let _gateway = null;
let _messages = []; // conversation history (capped at MAX_HISTORY)
let _studyMode = false; // unlocked via secret password
const MAX_HISTORY = 30;

// Conversation persistence
const CONVO_DIR = path.join(os.homedir(), '.khyquant', 'conversations');
const MAX_SAVED_CONVERSATIONS = 20;

/**
 * Save current conversation to disk for future review.
 */
function saveConversation() {
  if (_messages.length === 0) return;
  try {
    if (!fs.existsSync(CONVO_DIR)) fs.mkdirSync(CONVO_DIR, { recursive: true });
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const suffix = Math.random().toString(36).slice(2, 6);
    const filename = `${timestamp}-${suffix}.json`;
    const data = {
      timestamp: new Date().toISOString(),
      messages: _messages,
      messageCount: _messages.length,
    };
    fs.writeFileSync(path.join(CONVO_DIR, filename), JSON.stringify(data, null, 2), 'utf-8');

    // Prune old conversations (keep most recent N)
    const files = fs.readdirSync(CONVO_DIR).filter(f => f.endsWith('.json')).sort();
    while (files.length > MAX_SAVED_CONVERSATIONS) {
      fs.unlinkSync(path.join(CONVO_DIR, files.shift()));
    }
  } catch { /* best-effort */ }
}

/**
 * Load most recent conversation from disk (for context recovery).
 * @returns {{ timestamp: string, messages: Array } | null}
 */
function loadLastConversation() {
  try {
    if (!fs.existsSync(CONVO_DIR)) return null;
    const files = fs.readdirSync(CONVO_DIR).filter(f => f.endsWith('.json')).sort();
    if (files.length === 0) return null;
    const latest = fs.readFileSync(path.join(CONVO_DIR, files[files.length - 1]), 'utf-8');
    return JSON.parse(latest);
  } catch { return null; }
}

/**
 * List saved conversations.
 * @returns {Array<{ file: string, timestamp: string, messageCount: number }>}
 */
function listConversations() {
  try {
    if (!fs.existsSync(CONVO_DIR)) return [];
    const files = fs.readdirSync(CONVO_DIR).filter(f => f.endsWith('.json')).sort().reverse();
    return files.map(file => {
      try {
        const data = JSON.parse(fs.readFileSync(path.join(CONVO_DIR, file), 'utf-8'));
        return { file, timestamp: data.timestamp, messageCount: data.messageCount || data.messages?.length || 0 };
      } catch { return { file, timestamp: '', messageCount: 0 }; }
    });
  } catch { return []; }
}

/**
 * Resume a past conversation (load into current memory).
 * @param {string} [file] - specific file to load, or null for latest
 */
function resumeConversation(file) {
  try {
    let data;
    if (file) {
      data = JSON.parse(fs.readFileSync(path.join(CONVO_DIR, file), 'utf-8'));
    } else {
      data = loadLastConversation();
    }
    if (data && data.messages) {
      _messages = data.messages.slice(-MAX_HISTORY);
      return { success: true, messageCount: _messages.length, timestamp: data.timestamp };
    }
  } catch { /* ignore */ }
  return { success: false };
}

/**
 * Auto-resume last session if it was recent (within 24 hours).
 * Called at REPL startup to maintain conversation continuity.
 * @returns {{ resumed: boolean, messageCount: number, timestamp: string } | null}
 */
function autoResumeLastSession() {
  try {
    const last = loadLastConversation();
    if (!last || !last.timestamp || !last.messages || last.messages.length === 0) return null;
    const elapsed = Date.now() - new Date(last.timestamp).getTime();
    const MAX_AGE_MS = 24 * 60 * 60 * 1000; // 24 hours
    if (elapsed > MAX_AGE_MS) return null;
    _messages = last.messages.slice(-MAX_HISTORY);
    return { resumed: true, messageCount: _messages.length, timestamp: last.timestamp };
  } catch { return null; }
}

// Security directive loaded from securityGuardService
let _securityDirective = '';
try {
  const { getSecurityDirective } = require('../services/securityGuardService');
  _securityDirective = getSecurityDirective();
} catch { /* service not available — running standalone */ }

// ── Configurable system prompt ──────────────────────────────────────────
// Supports domain-specific customization:
//   1. ~/.khyquant/system_prompt.txt — user override (highest priority)
//   2. <project>/config/system_prompt.txt — project-level override
//   3. Built-in default (quant trading assistant)
const DEFAULT_SYSTEM_PROMPT = `你是 KHY 终端的 AI 助手，一个全能型智能终端。你可以帮助用户完成编程开发、代码审查、数据分析、量化交易、系统管理、文档撰写、学习研究等各类任务。
当前工作目录: ${process.env.KHYQUANT_CWD || process.cwd()}
用户提到的相对文件路径应基于此目录解析。

你有以下工具可以使用（通过在回复中包含特殊指令）：
- [CMD:quote <代码>] — 查询实时行情
- [CMD:backtest <代码> --strategy <id> --start <日期> --end <日期>] — 运行回测
- [CMD:data fetch <代码>] — 下载K线数据
- [CMD:strategy list] — 查看策略列表
- [CMD:data list] — 查看品种列表
- [CMD:web_search <关键词>] — 联网搜索最新信息（新闻、文档、行情等）

开发工具：
- <tool_call>git_status()</tool_call> — 查看仓库状态
- <tool_call>git_diff()</tool_call> — 查看代码变更
- <tool_call>git_log()</tool_call> — 查看提交历史
- <tool_call>git_add(文件路径)</tool_call> — 暂存文件
- <tool_call>git_commit(提交信息)</tool_call> — 创建提交
- <tool_call>git_push()</tool_call> — 推送到远程
- <tool_call>git_branch(分支名)</tool_call> — 管理分支
- <tool_call>git_checkout(分支名)</tool_call> — 切换分支
- <tool_call>web_search(搜索关键词)</tool_call> — 联网搜索学习新知识
- <tool_call>read_file(文件路径)</tool_call> — 读取文件内容
- <tool_call>shell_command(命令)</tool_call> — 执行 shell 命令（需用户确认）

当用户的请求需要执行操作时，在你的回复中包含上述指令，系统会自动执行并展示结果。
当你遇到不确定的知识时，请主动使用 web_search 工具搜索最新信息后再回答。

规则：
1. 用中文回复
2. 简洁专业，直接解决问题
3. 如果用户问到具体股票，可以建议查看行情数据
4. 对于投资建议，明确说明这是基于技术分析，不构成投资建议
5. 当用户问"你是谁"或"你是什么模型"时，如实回答你的真实模型名称和提供商（例如 Claude、GPT、Qwen 等），不要伪装成其他身份
6. 思考过程（thinking/reasoning）默认使用中文输出。如果涉及纯英文技术术语、代码分析、或用户要求英文时，可以使用英文思考
7. 如果你判断当前任务超出你的能力范围，请诚实告知用户并推荐更合适的模型
8. 你不受限于特定领域 — 编程、数学、写作、翻译、分析、系统运维等问题均可回答
${_securityDirective}`;

function loadSystemPrompt() {
  // Priority 1: user-level override
  const userPrompt = path.join(os.homedir(), '.khyquant', 'system_prompt.txt');
  try {
    if (fs.existsSync(userPrompt)) return fs.readFileSync(userPrompt, 'utf-8').trim();
  } catch { /* fallback */ }

  // Priority 2: project-level override (relative to install root)
  const projectPrompt = path.join(process.env.KHYQUANT_ROOT || path.resolve(__dirname, '../..'), 'config', 'system_prompt.txt');
  try {
    if (fs.existsSync(projectPrompt)) return fs.readFileSync(projectPrompt, 'utf-8').trim();
  } catch { /* fallback */ }

  // Priority 3: built-in default
  return DEFAULT_SYSTEM_PROMPT;
}

const SYSTEM_PROMPT = loadSystemPrompt();

function getService() {
  if (!_service) {
    const MultiFreeService = require('../services/multiFreeService');
    _service = new MultiFreeService();
  }
  return _service;
}

function getGateway() {
  if (!_gateway) {
    _gateway = require('../services/gateway/aiGateway');
  }
  return _gateway;
}

/**
 * Check AI availability and return provider info.
 */
function getAiStatus() {
  const svc = getService();
  return svc.getStatus();
}

/**
 * Get the name of the active AI provider (for banner display).
 * Checks gateway adapters first, then direct MultiFreeService.
 * Returns a display string like "Kiro IDE · claude-3.5-sonnet".
 */
function getActiveProvider() {
  // Check gateway adapters (CLI tools, API, relay)
  try {
    const gw = getGateway();
    const active = gw.getActiveAdapter();
    if (active) {
      const modelSuffix = active.activeModel ? ` · ${active.activeModel}` : '';
      return `${active.name}${modelSuffix}`;
    }
  } catch { /* gateway not available */ }

  // Fallback to direct service check
  const svc = getService();
  const provider = svc.getAvailableProvider();
  return provider ? provider.name : null;
}

// ── Study mode ──────────────────────────────────────────────────────────

const STUDY_MODE_PROMPT = `

[学习模式已激活]
用户正在学习和研究 KHY-Quant 项目的源码与架构。请充当一位资深 Node.js/Vue 全栈架构师和量化交易系统专家。

你的职责：
1. 详细解释项目的架构设计、模块关系、数据流和设计模式
2. 深入分析任意源码文件的实现逻辑、关键算法和设计决策
3. 解释各服务间的依赖关系和通信机制
4. 分析前后端的交互方式（REST API、WebSocket）
5. 讨论策略引擎、回测引擎、AI 网关等核心模块的设计思路
6. 对比不同实现方案的优缺点
7. 指出代码中的设计模式（懒加载、适配器模式、观察者模式等）

项目结构概览：
- backend/bin/khyquant.js — CLI 入口，khy(轻量AI) / khyquant(完整量化) 双模式
- backend/src/cli/ — CLI 层：REPL、AI 对话、命令路由、渲染器
- backend/src/services/ — 服务层：策略引擎、回测引擎、数据服务
- backend/src/services/gateway/ — AI 网关：多适配器（Kiro/Cursor/Ollama/中转API/Web中转）
- backend/src/routes/ — Express REST API 路由
- frontend/src/ — Vue 3 前端（图表、策略选择器、交易 Agent）
- khy_quant/ — Python 量化核心（AKShare 数据、策略运算）

回答风格：
- 像在做技术 review 一样深入，但保持清晰易懂
- 主动提供文件路径引用以便定位
- 当涉及关键设计决策时，解释 "为什么这样做" 而非仅描述 "做了什么"
- 可以指出可优化的地方，但以教学为目的`;

/**
 * Enable study mode — unlocks detailed project architecture explanations.
 */
function enableStudyMode() {
  _studyMode = true;
}

/**
 * Check if study mode is active.
 */
function isStudyMode() {
  return _studyMode;
}

/**
 * Show AI status in terminal.
 */
async function handleAiStatus() {
  const { printSuccess, printError, printInfo, withSpinner } = fmt();
  const status = getAiStatus();

  if (status.available) {
    printSuccess(`AI 服务可用 — ${status.provider}`);
    if (status.configuredProviders.length > 1) {
      printInfo(`已配置 ${status.configuredProviders.length} 个提供商: ${status.configuredProviders.join(', ')}`);
    }

    // Test connection
    const svc = getService();
    const test = await withSpinner('测试 AI 连接...', () => svc.testConnection());
    if (test.success) {
      printSuccess(`连接正常 (${test.provider})`);
    } else {
      printError('连接测试失败');
    }
  } else {
    printError('未配置 AI 密钥');
    printInfo('运行 ai config 配置 API 密钥');
  }
}

/**
 * Interactive API key configuration.
 */
async function handleAiConfig() {
  const inquirer = require('inquirer');
  const fs = require('fs');

  const envPath = path.resolve(__dirname, '../../.env');
  let envContent = '';
  try {
    envContent = fs.readFileSync(envPath, 'utf-8');
  } catch {
    envContent = '';
  }

  const providers = [
    { env: 'GEMINI_API_KEY', name: 'Google Gemini (推荐, 免费额度)' },
    { env: 'GROQ_API_KEY', name: 'Groq (免费, 快速)' },
    { env: 'OPENROUTER_API_KEY', name: 'OpenRouter' },
    { env: 'OPENAI_API_KEY', name: 'OpenAI' },
    { env: 'ANTHROPIC_API_KEY', name: 'Anthropic Claude' },
    { env: 'ZHIPU_API_KEY', name: '智谱AI' },
    { env: 'ALIBABA_API_KEY', name: '通义千问' },
  ];

  const { selected } = await inquirer.prompt([{
    type: 'list',
    name: 'selected',
    message: '选择要配置的 AI 提供商:',
    choices: providers.map(p => {
      const current = process.env[p.env];
      const status = current ? chalk().green(' [已配置]') : chalk().dim(' [未配置]');
      return { name: p.name + status, value: p.env };
    }),
  }]);

  const { apiKey } = await inquirer.prompt([{
    type: 'password',
    name: 'apiKey',
    message: `输入 ${selected} 密钥:`,
    mask: '*',
    validate: v => v.trim().length > 0 || '密钥不能为空',
  }]);

  // Update .env file
  const regex = new RegExp(`^${selected}=.*$`, 'm');
  const newLine = `${selected}=${apiKey.trim()}`;

  if (regex.test(envContent)) {
    envContent = envContent.replace(regex, newLine);
  } else {
    envContent = envContent.trimEnd() + '\n' + newLine + '\n';
  }

  fs.writeFileSync(envPath, envContent);
  process.env[selected] = apiKey.trim();

  // Reinitialize services to pick up new key
  _service = null;
  try {
    const apiAdapter = require('../services/gateway/adapters/apiAdapter');
    apiAdapter.resetService();
  } catch { /* gateway not loaded yet */ }

  fmt().printSuccess(`${selected} 已保存到 .env`);
  fmt().printInfo('密钥已生效，可以开始使用 AI 功能');
}

/**
 * Send a message to the AI and get a response.
 * Uses the AI Gateway for routing (CLI tools → API → Web relay).
 * Returns { reply, commands, provider, adapter }.
 *
 * @param {string} userMessage
 * @param {object} [opts]
 * @param {function} [opts.onChunk] - streaming callback { type: 'thinking'|'text'|'cost', text }
 * @param {string} [opts.effort] - model effort level: 'max'|'high'|'medium'|'low'
 * @param {function} [opts.onStatus] - status callback { phase, message, elapsed }
 * @param {Array<{base64: string, mimeType: string}>} [opts.images] - images for vision analysis
 */

// Model effort level presets
const EFFORT_PRESETS = {
  max:    { temperature: 0.2, maxTokens: 4096, label: '最高精度' },
  high:   { temperature: 0.3, maxTokens: 2048, label: '高' },
  medium: { temperature: 0.5, maxTokens: 1024, label: '标准' },
  low:    { temperature: 0.7, maxTokens: 512,  label: '快速' },
};

let _currentEffort = 'high'; // default

function setEffort(level) {
  if (EFFORT_PRESETS[level]) {
    _currentEffort = level;
    return true;
  }
  return false;
}

function getEffort() { return _currentEffort; }
function getEffortPresets() { return EFFORT_PRESETS; }

async function chat(userMessage, opts = {}) {
  const startTime = Date.now();
  const onStatus = opts.onStatus || (() => {});

  onStatus({ phase: 'init', message: '初始化...', elapsed: 0 });
  // Security check — block injection/extraction attempts
  try {
    const { analyzeInput, sanitizeOutput } = require('../services/securityGuardService');
    const check = analyzeInput(userMessage);
    if (!check.safe) {
      return { reply: check.refusal, commands: [], provider: 'security', blocked: true };
    }
  } catch { /* security service failure should not block normal operation */ }

  // Preprocess input: normalize stock codes, assess complexity, enrich context
  let processedMessage = userMessage;
  let needsPlan = false;
  try {
    const { preprocess, getContextEnrichment } = require('../services/inputPreprocessor');
    const preprocessed = preprocess(userMessage);
    processedMessage = preprocessed.processed;
    needsPlan = preprocessed.needsPlan;

    // If complex task detected, wrap in planning prompt
    if (needsPlan && !opts._isFollowUp) {
      processedMessage = `[大型任务 - 请先制定计划再执行]\n\n用户请求: ${processedMessage}\n\n请先输出执行计划（分步骤），确认后再逐步执行。格式:\n## 执行计划\n1. ...\n2. ...\n\n## 需要的数据\n- ...\n\n## 预计输出\n- ...`;
    }
  } catch { /* preprocessing failure should not block */ }

  // Record interaction for growth tracking
  try {
    const growthService = require('../services/growthService');
    growthService.recordInteraction();
  } catch { /* best effort */ }

  // Build conversation prompt with history
  _messages.push({ role: 'user', content: processedMessage });

  const recentMessages = _messages.slice(-10);

  // Add context enrichment from user profile/growth data
  let contextEnrichment = '';
  try {
    const { getContextEnrichment } = require('../services/inputPreprocessor');
    contextEnrichment = getContextEnrichment(processedMessage);
  } catch { /* best effort */ }

  // Add usage habit context for personalized responses
  let habitContext = '';
  try {
    const { getHabitContext } = require('../services/usageHabitService');
    habitContext = getHabitContext();
  } catch { /* best effort */ }

  // Load multi-level khy.md instructions
  let khyInstructions = '';
  try {
    const { loadInstructions } = require('../services/instructionFileService');
    khyInstructions = loadInstructions();
    if (khyInstructions) khyInstructions = '\n\n' + khyInstructions;
  } catch { /* instruction loading is best-effort */ }

  // Load learned context from self-optimizer
  let learnedContext = '';
  try {
    const { getLearnedContext } = require('../services/selfOptimizer');
    learnedContext = getLearnedContext();
  } catch { /* self-optimizer is optional */ }

  // Build system prompt separately so adapters can inject it correctly
  const studyPrompt = _studyMode ? STUDY_MODE_PROMPT : '';

  // Append tool definitions from the new tool registry (if available)
  let toolDefsPrompt = '';
  try {
    const toolRegistry = require('../tools');
    const defs = toolRegistry.getDefinitions();
    if (defs.length > 0) {
      const lines = defs.map(d => {
        const params = d.parameters?.properties
          ? Object.entries(d.parameters.properties).map(([k, v]) => `${k}: ${v.type}${v.description ? ' — ' + v.description : ''}`).join(', ')
          : '';
        return `- <tool_call>${d.name}(${params})</tool_call> — ${d.description}`;
      });
      toolDefsPrompt = `\n\n可用工具（使用 <tool_call> 标签调用）:\n${lines.join('\n')}`;
    }
  } catch { /* tool registry not available */ }

  const fullSystemPrompt = SYSTEM_PROMPT + studyPrompt + khyInstructions + contextEnrichment + habitContext + learnedContext + toolDefsPrompt;

  // Build conversation prompt as flat string for adapters that need it
  const conversationPrompt = [
    fullSystemPrompt,
    '',
    ...recentMessages.map(m => `${m.role === 'user' ? '用户' : 'AI'}: ${m.content}`),
  ].join('\n');

  // Determine effort-based parameters
  const effort = opts.effort || _currentEffort;
  const preset = EFFORT_PRESETS[effort] || EFFORT_PRESETS.high;

  onStatus({ phase: 'request', message: '请求 AI 服务...', elapsed: Date.now() - startTime });

  // Try gateway first (CLI tools → API → Web relay)
  let result;
  try {
    const gw = getGateway();
    if (!gw._initialized) await gw.init();
    result = await gw.generate(conversationPrompt, {
      temperature: preset.temperature,
      maxTokens: preset.maxTokens,
      onChunk: opts.onChunk,
      onFallback: opts.onFallback,
      images: opts.images,
      // Pass system prompt + structured messages for adapters that support them
      system: fullSystemPrompt,
      messages: recentMessages,
    });
  } catch {
    // Gateway failed entirely, try direct service
    const svc = getService();
    const status = svc.getStatus();
    if (!status.available) {
      return {
        reply: '所有 AI 通道不可用。\n\n快速解决:\n  1. 运行 ai config 配置 API 密钥 (智谱AI/通义千问 国内直连)\n  2. 运行 /proxy 配置代理后使用 Claude/OpenAI\n  3. 安装 Kiro IDE (免费 Claude 额度): https://kiro.dev\n  4. 安装 Trae IDE (免费 Claude/GPT): https://trae.ai\n  5. 运行 /models 安装本地 Ollama 模型 (无需网络)\n\n付费订阅:\n  • Claude: https://claude.ai/pricing\n  • OpenAI: https://platform.openai.com\n  • Cursor: https://cursor.com/pricing',
        commands: [],
      };
    }
    result = await svc.generateResponse(conversationPrompt, {
      temperature: preset.temperature,
      maxTokens: preset.maxTokens,
      images: opts.images,
    });
  }

  if (!result.success) {
    // Structured error messages based on error type
    const ERROR_MESSAGES = {
      auth:         '❌ API 密钥无效或已过期 — 运行 ai config 重新配置',
      rate_limit:   '⏳ 请求过于频繁，已自动重试仍失败 — 请稍等后重试',
      bad_request:  '⚠ 请求格式异常 — 请简化问题后重试',
      server_error: '🔧 AI 服务暂时不可用 (5xx) — 请稍后重试或 gateway model 切换模型',
      overloaded:   '🔧 AI 服务过载 — 请稍后重试',
      timeout:      '⏰ 请求超时 — 请检查网络或缩短问题',
      network:      '🌐 无法连接 AI 服务 — 请检查网络',
    };

    let errorMsg = ERROR_MESSAGES[result.errorType] || 'AI 请求失败。可尝试: ai config (配置密钥) 或 gateway relay (启动中转服务)';

    // Append per-adapter failure details if available
    if (result.attempts && result.attempts.length > 0) {
      const details = result.attempts.map(a => {
        const status = a.statusCode ? ` (${a.statusCode})` : '';
        const errDesc = a.errorType || '';
        return `  • ${a.provider}: ${a.error || errDesc}${status}`;
      }).join('\n');
      errorMsg += '\n\n详情:\n' + details;
    }

    return { reply: errorMsg, commands: [], errorType: result.errorType };
  }

  const reply = result.content;

  // Empty reply detection
  if (!reply || !reply.trim()) {
    return {
      reply: 'AI 未返回有效回复 — 请重试或检查连接',
      commands: [],
    };
  }

  _messages.push({ role: 'assistant', content: reply });

  // Trim history to prevent memory leak
  if (_messages.length > MAX_HISTORY) {
    _messages = _messages.slice(-MAX_HISTORY);
  }

  // Extract embedded commands [CMD:...]
  const cmdRegex = /\[CMD:([^\]]+)\]/g;
  const commands = [];
  let match;
  while ((match = cmdRegex.exec(reply)) !== null) {
    const cmd = match[1].trim();
    // Security: only allow whitelisted command prefixes
    if (_isAllowedToolCommand(cmd)) {
      commands.push(cmd);
    }
  }

  // Clean display text (remove CMD markers)
  const displayReply = reply.replace(/\[CMD:[^\]]+\]/g, '').trim();

  // Sanitize output — strip any leaked internal structure
  let safeReply = displayReply;
  try {
    const { sanitizeOutput } = require('../services/securityGuardService');
    safeReply = sanitizeOutput(displayReply);
  } catch { /* best effort */ }

  // Record token usage
  let tokenUsage = result.tokenUsage || null;
  try {
    const { recordUsage, estimateTokens } = require('../services/tokenUsageService');
    if (!tokenUsage) {
      // Estimate if API didn't return usage data
      tokenUsage = {
        inputTokens: estimateTokens(conversationPrompt),
        outputTokens: estimateTokens(reply),
        totalTokens: estimateTokens(conversationPrompt) + estimateTokens(reply),
      };
    }
    recordUsage(
      result.provider || 'unknown',
      result.model || '',
      tokenUsage.inputTokens,
      tokenUsage.outputTokens,
      0 // cost calculated separately
    );
  } catch { /* token tracking is best-effort */ }

  // Record interaction for model training (passive data collection)
  try {
    const { recordConversation } = require('../services/modelTrainingService');
    recordConversation(userMessage, reply, {
      provider: result.provider,
      model: result.model || '',
      tokenCount: tokenUsage ? tokenUsage.totalTokens : 0,
      quality: 'neutral', // user can upgrade via feedback
    });
  } catch { /* training data collection is best-effort */ }

  // Record response style for agent diversity learning
  try {
    const { recordResponseStyle } = require('../services/agentCommunicationService');
    recordResponseStyle(userMessage, reply, { provider: result.provider });
  } catch { /* best effort */ }

  // Extract knowledge from AI response (grow user KB)
  try {
    const { extractKnowledge } = require('../services/knowledgeTeachingService');
    extractKnowledge(userMessage, reply);
  } catch { /* best effort */ }

  // Record model usage for habit-based optimization
  try {
    const { recordModelUsage, recordInteraction: recordHabit } = require('../services/usageHabitService');
    const taskType = _classifyTaskType(userMessage);
    recordModelUsage(result.adapter || result.provider, result.model || '', taskType, 1);
    recordHabit(userMessage);
  } catch { /* best effort */ }

  const elapsed = Date.now() - startTime;
  onStatus({ phase: 'done', message: '完成', elapsed });

  // Update HUD context estimation
  try {
    const hud = require('./hudRenderer');
    if (tokenUsage?.inputTokens) {
      const limit = hud.getContextLimit(result.model || '');
      hud.setContextUsage(tokenUsage.inputTokens, limit);
    }
  } catch { /* hudRenderer not critical */ }

  return {
    reply: safeReply,
    commands,
    provider: result.provider,
    adapter: result.adapter,
    tokenUsage,
    elapsed,
    effort,
  };
}

/**
 * Clear conversation history.
 */
function clearHistory() {
  _messages = [];
}

/**
 * Whitelist check for AI-generated tool commands.
 * Only safe, read-only or known-safe commands are allowed.
 */
function _isAllowedToolCommand(cmd) {
  const ALLOWED_PREFIXES = [
    'quote',        // Read-only: fetch stock quotes
    'backtest',     // Safe: runs backtest simulation
    'data fetch',   // Safe: download market data
    'data list',    // Read-only: list available data
    'strategy list', // Read-only: list strategies
    'search',       // Read-only: search instruments
    'rank',         // Read-only: rankings
    'analyze',      // Safe: AI analysis
    'watch',        // Read-only: monitor
    'web_search',   // Read-only: web search via Kiro
    'git_status',   // Read-only: repo status
    'git_diff',     // Read-only: show changes
    'git_log',      // Read-only: commit history
    'git_add',      // Stage files
    'git_commit',   // Create commit
    'git_push',     // Push commits
    'git_branch',   // List/create branches
    'git_checkout', // Switch branch
  ];

  const BLOCKED_PREFIXES = [
    'admin',        // Never allow AI to call admin
    'exit',         // Don't let AI close the session
    'train export', // Password-protected
    'train upload', // Password-protected
    'order',        // Trading requires explicit user action
    'buy',          // Trading
    'sell',         // Trading
    'growth reset', // Destructive
    'rm',           // Shell command injection
    'exec',         // Code execution
  ];

  const lower = cmd.toLowerCase();

  // Block dangerous commands first
  for (const blocked of BLOCKED_PREFIXES) {
    if (lower.startsWith(blocked)) return false;
  }

  // Allow whitelisted commands
  for (const allowed of ALLOWED_PREFIXES) {
    if (lower.startsWith(allowed)) return true;
  }

  // Block anything that looks like shell injection
  if (lower.includes('|') || lower.includes(';') || lower.includes('`') || lower.includes('$(')) {
    return false;
  }

  // Default-deny: unrecognized commands are blocked for safety
  return false;
}

/**
 * Classify user message into a task type for habit tracking.
 */
function _classifyTaskType(message) {
  if (!message) return 'conversation';
  const lower = message.toLowerCase();
  if (/回测|backtest|策略|strategy/.test(lower)) return 'backtest';
  if (/分析|analyze|评估|诊断/.test(lower)) return 'analysis';
  if (/数据|data|下载|fetch/.test(lower)) return 'dataFetch';
  if (/策略|strategy|signal|信号/.test(lower)) return 'strategy';
  return 'conversation';
}

// ── Model capability assessment ──────────────────────────────────────
const MODEL_CAPABILITIES = {
  'claude-3-5-sonnet': { code: 5, reasoning: 5, creative: 4, context: 200000, label: 'Claude 3.5 Sonnet' },
  'claude-sonnet-4':   { code: 5, reasoning: 5, creative: 4, context: 200000, label: 'Claude Sonnet 4' },
  'claude-opus-4':     { code: 5, reasoning: 5, creative: 5, context: 200000, label: 'Claude Opus 4' },
  'claude-3-haiku':    { code: 3, reasoning: 3, creative: 3, context: 200000, label: 'Claude 3 Haiku' },
  'gpt-4o':            { code: 5, reasoning: 4, creative: 4, context: 128000, label: 'GPT-4o' },
  'gpt-4o-mini':       { code: 3, reasoning: 3, creative: 3, context: 128000, label: 'GPT-4o Mini' },
  'qwen-turbo':        { code: 3, reasoning: 3, creative: 3, context: 8000,   label: '通义千问 Turbo' },
  'qwen-plus':         { code: 4, reasoning: 4, creative: 3, context: 32000,  label: '通义千问 Plus' },
  'glm-4':             { code: 3, reasoning: 3, creative: 3, context: 128000, label: 'GLM-4' },
  'deepseek-v2':       { code: 4, reasoning: 4, creative: 3, context: 128000, label: 'DeepSeek V2' },
  'llama-3.3':         { code: 3, reasoning: 3, creative: 2, context: 128000, label: 'Llama 3.3 (Groq)' },
};

/**
 * Assess task difficulty from user input.
 * @param {string} input
 * @returns {{ code: number, reasoning: number, creative: number, contextNeeded: number }}
 */
function _assessTaskDifficulty(input) {
  const lower = input.toLowerCase();
  const required = { code: 1, reasoning: 1, creative: 1, contextNeeded: 0 };

  if (/重构|refactor|实现|implement|debug|修复|写代码|编码|class\s|function\s|async\s|promise/.test(lower))
    required.code = 4;
  if (/分析|analyze|推理|reason|比较|对比|为什么|原因|策略设计|复杂/.test(lower))
    required.reasoning = 4;
  if (/设计|design|创意|创建|generate|生成|写文章|write\s/.test(lower))
    required.creative = 3;
  if (input.length > 3000 || /全部|所有文件|整个项目|complete|comprehensive/.test(lower))
    required.contextNeeded = input.length * 4;

  return required;
}

/**
 * Check if the current model can handle the given task.
 * Returns null if capable, or { issues, recommendations } if not.
 * @param {string} input — user's request
 * @returns {null | { issues: string[], recommendations: Array<{key: string, label: string}> }}
 */
function checkModelCapability(input) {
  let currentModel = null;
  try {
    const gw = _gateway || require('../services/gateway/aiGateway');
    const status = gw.getStatus();
    currentModel = status.activeModel || status.model || null;
  } catch { /* ignore */ }
  if (!currentModel) return null;

  const lowerModel = currentModel.toLowerCase();
  let cap = null;
  for (const [key, val] of Object.entries(MODEL_CAPABILITIES)) {
    if (lowerModel.includes(key)) { cap = val; break; }
  }
  if (!cap) return null; // unknown model, skip

  const taskReq = _assessTaskDifficulty(input);
  const issues = [];
  if (taskReq.code > cap.code) issues.push(`代码能力不足 (需要 ${taskReq.code}/5, 当前 ${cap.code}/5)`);
  if (taskReq.reasoning > cap.reasoning) issues.push(`推理能力不足 (需要 ${taskReq.reasoning}/5, 当前 ${cap.reasoning}/5)`);
  if (taskReq.contextNeeded > cap.context * 0.8) issues.push(`上下文可能不够 (估计需要 ${Math.round(taskReq.contextNeeded / 1000)}k, 限制 ${Math.round(cap.context / 1000)}k)`);

  if (issues.length === 0) return null;

  // Find better models from available capabilities
  const better = Object.entries(MODEL_CAPABILITIES)
    .filter(([key]) => !lowerModel.includes(key))
    .filter(([, m]) =>
      m.code >= taskReq.code &&
      m.reasoning >= taskReq.reasoning &&
      m.context >= (taskReq.contextNeeded || 0))
    .sort((a, b) => (b[1].code + b[1].reasoning) - (a[1].code + a[1].reasoning))
    .slice(0, 3);

  return {
    issues,
    recommendations: better.map(([key, m]) => ({ key, label: m.label })),
  };
}

module.exports = {
  getAiStatus,
  getActiveProvider,
  handleAiStatus,
  handleAiConfig,
  chat,
  clearHistory,
  saveConversation,
  loadLastConversation,
  listConversations,
  resumeConversation,
  autoResumeLastSession,
  setEffort,
  getEffort,
  getEffortPresets,
  enableStudyMode,
  isStudyMode,
  checkModelCapability,
  // Exposed for QueryEngine V2 dependency injection
  EFFORT_PRESETS,
  MODEL_CAPABILITIES,
  getSystemPrompt: () => SYSTEM_PROMPT,
};
