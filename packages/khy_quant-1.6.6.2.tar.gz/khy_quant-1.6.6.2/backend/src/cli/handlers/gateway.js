/**
 * CLI Handlers for the AI Gateway system.
 * Commands: gateway status, gateway config, gateway relay
 */
const chalk = require('chalk');
const { printSuccess, printError, printInfo, printTable, ICON_GATEWAY } = require('../formatters');

/**
 * Display status of all gateway adapters with live connectivity test.
 */
async function handleGatewayStatus() {
  const gateway = require('../../services/gateway/aiGateway');
  if (!gateway._initialized) await gateway.init();

  const statuses = gateway.getStatus();

  console.log('');
  console.log(`  ${ICON_GATEWAY} ${chalk.cyan.bold('AI 网关状态')}`);
  console.log(chalk.dim('  正在检测各通道连通性...'));
  console.log('');

  // Run connectivity tests in parallel for enabled+available adapters
  const testPromises = {};
  for (const s of statuses) {
    if (s.enabled && s.available) {
      testPromises[s.type] = gateway.testAdapter(s.type).catch(() => null);
    }
  }
  const testResults = {};
  for (const [key, promise] of Object.entries(testPromises)) {
    testResults[key] = await promise;
  }

  printTable(
    ['优先级', '适配器', '类型', '状态', '连通', '详情'],
    statuses.map(s => {
      const test = testResults[s.type];
      let connCol = chalk.dim('—');
      if (!s.enabled) {
        connCol = chalk.dim('已禁用');
      } else if (!s.available) {
        connCol = chalk.dim('—');
      } else if (test) {
        if (test.connectivity?.success) {
          const ms = test.connectivity.latencyMs;
          const modelOk = test.models?.success;
          if (modelOk) {
            connCol = chalk.green(`● ${ms}ms (${test.models.count} models)`);
          } else if (test.models) {
            connCol = chalk.yellow(`● ${ms}ms (models: ${test.models.error})`);
          } else {
            connCol = chalk.green(`● ${ms}ms`);
          }
        } else {
          connCol = chalk.red(`● ${test.connectivity?.error || 'failed'}`);
        }
      }
      return [
        String(s.priority),
        s.name,
        s.type,
        s.enabled
          ? (s.available ? chalk.green('✓ 可用') : chalk.yellow('⚠ 不可用'))
          : chalk.dim('已禁用'),
        connCol,
        s.detail,
      ];
    })
  );

  const active = gateway.getActiveAdapter();
  if (active) {
    console.log('');
    printSuccess(`当前活跃通道: ${active.name} (${active.type})`);
  } else {
    console.log('');
    printInfo('无活跃通道 — 可用 gateway relay 启动 Web 中转');
  }
  console.log('');
}

/**
 * Interactive gateway configuration.
 */
async function handleGatewayConfig() {
  const inquirer = require('inquirer');
  const fs = require('fs');
  const path = require('path');
  const envPath = path.resolve(__dirname, '../../../.env');

  let envContent = '';
  try { envContent = fs.readFileSync(envPath, 'utf-8'); } catch { /* no .env */ }

  const { action } = await inquirer.prompt([{
    type: 'list',
    name: 'action',
    message: '网关配置:',
    choices: [
      { name: '设置 CLI 工具桥接 (开/关)', value: 'cli-toggle' },
      { name: '配置 Ollama 本地模型', value: 'ollama-config' },
      { name: '配置 API 中转 (Claude/GPT 中转站)', value: 'relay-api' },
      { name: '配置模型厂商 API Key (DeepSeek/Qwen/GLM/豆包等)', value: 'provider-keys' },
      { name: '设置 Web 中转端口', value: 'relay-port' },
      { name: '设置中转超时时间', value: 'relay-timeout' },
      { name: '↩️  返回', value: 'back' },
    ],
  }]);

  if (action === 'back') return;

  function setEnvVar(key, value) {
    const regex = new RegExp(`^${key}=.*$`, 'm');
    const line = `${key}=${value}`;
    if (regex.test(envContent)) {
      envContent = envContent.replace(regex, line);
    } else {
      envContent = envContent.trimEnd() + '\n' + line + '\n';
    }
    fs.writeFileSync(envPath, envContent);
    process.env[key] = String(value);
  }

  if (action === 'cli-toggle') {
    const current = process.env.GATEWAY_CLI_ENABLED !== 'false';
    const { enabled } = await inquirer.prompt([{
      type: 'confirm',
      name: 'enabled',
      message: `CLI 工具桥接当前${current ? '已开启' : '已关闭'}，是否开启?`,
      default: true,
    }]);
    setEnvVar('GATEWAY_CLI_ENABLED', enabled);
    printSuccess(`CLI 工具桥接已${enabled ? '开启' : '关闭'}`);
  }

  if (action === 'ollama-config') {
    const ollamaAdapter = require('../../services/gateway/adapters/ollamaAdapter');
    const available = ollamaAdapter.detect(true); // force refresh
    const models = ollamaAdapter.getModels();

    if (!available) {
      printError('Ollama 服务未运行');
      printInfo('安装: https://ollama.com');
      printInfo('启动: ollama serve');
      printInfo('拉取模型: ollama pull qwen2.5:7b');
      return;
    }

    printSuccess(`Ollama 运行中，${models.length} 个模型可用`);

    if (models.length > 0) {
      const { model } = await inquirer.prompt([{
        type: 'list',
        name: 'model',
        message: '选择默认模型:',
        choices: models.map(m => ({ name: m, value: m })),
        default: process.env.OLLAMA_MODEL || 'qwen2.5:7b',
      }]);
      setEnvVar('OLLAMA_MODEL', model);
      printSuccess(`默认模型已设为 ${model}`);
    }

    const { host } = await inquirer.prompt([{
      type: 'input',
      name: 'host',
      message: 'Ollama 地址:',
      default: process.env.OLLAMA_HOST || 'http://localhost:11434',
    }]);
    if (host !== 'http://localhost:11434') {
      setEnvVar('OLLAMA_HOST', host);
      printSuccess(`Ollama 地址已设为 ${host}`);
    }
    return;
  }

  if (action === 'relay-api') {
    const chalk = require('chalk');
    const currentEndpoint = process.env.RELAY_API_ENDPOINT || '';
    const currentKey = process.env.RELAY_API_KEY || '';
    const currentModel = process.env.RELAY_API_MODEL || 'claude-sonnet-4-20250514';

    if (currentEndpoint) {
      console.log(chalk.dim(`  当前: ${currentEndpoint} / ${currentModel}`));
    }

    const { endpoint } = await inquirer.prompt([{
      type: 'input',
      name: 'endpoint',
      message: '中转 API 地址 (OpenAI 兼容格式):',
      default: currentEndpoint || 'https://api.example.com/v1',
      validate: v => v.startsWith('http') ? true : '请输入完整 URL (https://...)',
    }]);

    const { key } = await inquirer.prompt([{
      type: 'password',
      name: 'key',
      message: 'API Key:',
      mask: '*',
      default: currentKey,
      validate: v => v.length > 0 ? true : '请输入 API Key',
    }]);

    const { model } = await inquirer.prompt([{
      type: 'input',
      name: 'model',
      message: '模型名称:',
      default: currentModel,
    }]);

    setEnvVar('RELAY_API_ENDPOINT', endpoint);
    setEnvVar('RELAY_API_KEY', key);
    setEnvVar('RELAY_API_MODEL', model);

    printSuccess(`API 中转已配置: ${endpoint}`);
    printInfo(`模型: ${model}`);

    // Test connection
    const { test } = await inquirer.prompt([{
      type: 'confirm',
      name: 'test',
      message: '是否测试连接?',
      default: true,
    }]);

    if (test) {
      printInfo('测试中...');
      try {
        const relayAdapter = require('../../services/gateway/adapters/relayApiAdapter');
        relayAdapter.detect(true);
        const result = await relayAdapter.generate('Say "hello" in one word.', { maxTokens: 10 });
        if (result.success) {
          printSuccess(`连接成功! 响应: "${result.content.slice(0, 50)}" (${result.provider})`);
        } else {
          printError(`连接失败: ${result.error}`);
        }
      } catch (e) {
        printError(`测试错误: ${e.message}`);
      }
    }
    return;
  }

  if (action === 'provider-keys') {
    const pool = require('../../services/apiKeyPool');
    pool.init();

    const PROVIDERS = [
      { name: 'DeepSeek', poolKey: 'deepseek', envKey: 'DEEPSEEK_API_KEY', envEndpoint: 'DEEPSEEK_API_ENDPOINT', defaultEndpoint: 'https://api.deepseek.com/v1', models: ['deepseek-chat', 'deepseek-coder', 'deepseek-reasoner'] },
      { name: '通义千问 (Qwen)', poolKey: 'qwen', envKey: 'QWEN_API_KEY', envEndpoint: 'QWEN_API_ENDPOINT', defaultEndpoint: 'https://dashscope.aliyuncs.com/compatible-mode/v1', models: ['qwen-turbo', 'qwen-plus', 'qwen-max'] },
      { name: '智谱 GLM', poolKey: 'glm', envKey: 'GLM_API_KEY', envEndpoint: 'GLM_API_ENDPOINT', defaultEndpoint: 'https://open.bigmodel.cn/api/paas/v4', models: ['glm-4', 'glm-4-flash', 'glm-4-air'] },
      { name: '豆包 (Doubao)', poolKey: 'doubao', envKey: 'DOUBAO_API_KEY', envEndpoint: 'DOUBAO_API_ENDPOINT', defaultEndpoint: 'https://ark.cn-beijing.volces.com/api/v3', models: ['doubao-pro-32k', 'doubao-lite-32k'] },
      { name: '百度文心', poolKey: 'wenxin', envKey: 'WENXIN_API_KEY', envEndpoint: 'WENXIN_API_ENDPOINT', defaultEndpoint: 'https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop', models: ['ernie-4.0', 'ernie-speed'] },
      { name: 'OpenAI', poolKey: 'openai', envKey: 'OPENAI_API_KEY', envEndpoint: 'OPENAI_API_ENDPOINT', defaultEndpoint: 'https://api.openai.com/v1', models: ['gpt-4o', 'gpt-4o-mini', 'o1-mini'] },
      { name: 'Anthropic (Claude)', poolKey: 'anthropic', envKey: 'ANTHROPIC_API_KEY', envEndpoint: 'ANTHROPIC_API_ENDPOINT', defaultEndpoint: 'https://api.anthropic.com/v1', models: ['claude-sonnet-4-20250514', 'claude-3-5-haiku-20241022'] },
      { name: 'HuggingFace', poolKey: null, envKey: 'HF_TOKEN', envEndpoint: null, defaultEndpoint: null, models: [], isToken: true },
      { name: 'Relay (中转站)', poolKey: 'relay', envKey: 'RELAY_API_KEY', envEndpoint: 'RELAY_API_ENDPOINT', defaultEndpoint: '', models: [] },
    ];

    // Show current pool status
    console.log('');
    console.log(chalk.cyan.bold('  API Key 池管理'));
    console.log('');
    for (const p of PROVIDERS) {
      if (p.poolKey) {
        const status = pool.getPoolStatus(p.poolKey);
        if (status.length > 0) {
          console.log(`  ${chalk.white(p.name)} ${chalk.dim(`(${status.length} keys)`)}`);
          for (const s of status) {
            const icon = s.status === 'active' ? chalk.green('●')
              : s.status === 'cooldown' ? chalk.yellow('○')
              : chalk.red('○');
            const cooldown = s.cooldownRemaining > 0 ? chalk.yellow(` ⏳${s.cooldownRemaining}s`) : '';
            console.log(`    ${icon} ${chalk.dim(s.keyPreview)}  ${s.label || ''}  P:${s.priority}  ${chalk.dim(`${s.totalRequests} req`)}${cooldown}`);
          }
        } else {
          const hasEnv = !!process.env[p.envKey];
          const icon = hasEnv ? chalk.green('●') : chalk.dim('○');
          console.log(`  ${icon} ${chalk.white(p.name)}${hasEnv ? chalk.dim(` (env)`) : ''}`);
        }
      } else {
        const hasKey = !!process.env[p.envKey];
        const icon = hasKey ? chalk.green('●') : chalk.dim('○');
        console.log(`  ${icon} ${chalk.white(p.name)}${hasKey ? chalk.dim(` (${process.env[p.envKey].slice(0, 6)}...)`) : ''}`);
      }
    }
    console.log('');

    const { providerAction } = await inquirer.prompt([{
      type: 'list',
      name: 'providerAction',
      message: '操作:',
      choices: [
        { name: '添加 API Key', value: 'add' },
        { name: '移除 API Key', value: 'remove' },
        { name: '查看 Key 池详情', value: 'status' },
        { name: '↩️  返回', value: 'back' },
      ],
    }]);

    if (providerAction === 'back') return;

    if (providerAction === 'add') {
      const { provider } = await inquirer.prompt([{
        type: 'list',
        name: 'provider',
        message: '选择厂商:',
        choices: [
          ...PROVIDERS.map(p => ({ name: p.name, value: p })),
          { name: '↩️  返回', value: null },
        ],
      }]);

      if (!provider) return;

      const { key } = await inquirer.prompt([{
        type: 'password',
        name: 'key',
        message: `${provider.name} API Key:`,
        mask: '*',
        validate: v => v.length > 0 ? true : '请输入 API Key',
      }]);

      // HuggingFace: token only, save to env
      if (provider.isToken) {
        setEnvVar(provider.envKey, key);
        printSuccess(`${provider.name} Token 已保存`);
        return;
      }

      // Endpoint
      let keyEndpoint = provider.defaultEndpoint;
      const { useDefault } = await inquirer.prompt([{
        type: 'confirm',
        name: 'useDefault',
        message: `使用默认地址 (${provider.defaultEndpoint || '无'})？`,
        default: true,
      }]);
      if (!useDefault) {
        const { ep } = await inquirer.prompt([{
          type: 'input',
          name: 'ep',
          message: 'API 地址:',
          default: provider.defaultEndpoint,
        }]);
        keyEndpoint = ep;
      }

      // Priority
      const { priority } = await inquirer.prompt([{
        type: 'input',
        name: 'priority',
        message: '优先级 (数字越大越优先, 0=默认):',
        default: '10',
        validate: v => /^\d+$/.test(v) ? true : '请输入数字',
      }]);

      // Label
      const { label } = await inquirer.prompt([{
        type: 'input',
        name: 'label',
        message: '标签 (可选, 如 "付费号"):',
        default: '',
      }]);

      if (provider.poolKey) {
        try {
          pool.addKey(provider.poolKey, {
            key,
            endpoint: keyEndpoint,
            priority: parseInt(priority, 10),
            label,
          });
          printSuccess(`已添加到 ${provider.name} Key 池`);
        } catch (e) {
          printError(e.message);
        }
      }

      // Also set as RELAY_API for gateway compatibility (first key)
      setEnvVar(provider.envKey, key);
      if (provider.envEndpoint && keyEndpoint) {
        setEnvVar(provider.envEndpoint, keyEndpoint);
      }

      // Model selection for non-relay providers
      if (provider.models.length > 0) {
        const { model } = await inquirer.prompt([{
          type: 'list',
          name: 'model',
          message: '选择默认模型:',
          choices: provider.models,
        }]);
        setEnvVar('RELAY_API_ENDPOINT', keyEndpoint);
        setEnvVar('RELAY_API_KEY', key);
        setEnvVar('RELAY_API_MODEL', model);
        printSuccess(`${provider.name} 已配置: ${model}`);
      }
    }

    if (providerAction === 'remove') {
      const allStatus = pool.getAllStatus();
      const removeChoices = [];
      for (const [prov, keys] of Object.entries(allStatus)) {
        for (const k of keys) {
          removeChoices.push({
            name: `${prov} · ${k.keyPreview} · ${k.label || '无标签'} · P:${k.priority}`,
            value: { provider: prov, keyId: k.keyId },
          });
        }
      }
      if (removeChoices.length === 0) {
        printInfo('Key 池为空');
        return;
      }
      const { toRemove } = await inquirer.prompt([{
        type: 'list',
        name: 'toRemove',
        message: '选择要移除的 Key:',
        choices: [...removeChoices, { name: '↩️  返回', value: null }],
      }]);
      if (toRemove) {
        pool.removeKey(toRemove.provider, toRemove.keyId);
        printSuccess('已移除');
      }
    }

    if (providerAction === 'status') {
      const allStatus = pool.getAllStatus();
      if (Object.keys(allStatus).length === 0) {
        printInfo('Key 池为空。使用「添加 API Key」开始配置');
        return;
      }
      console.log('');
      for (const [prov, keys] of Object.entries(allStatus)) {
        console.log(chalk.cyan(`  ${prov} (${keys.length} keys)`));
        for (const k of keys) {
          const icon = k.status === 'active' ? chalk.green('●')
            : k.status === 'cooldown' ? chalk.yellow('○')
            : chalk.red('○');
          const cooldown = k.cooldownRemaining > 0 ? chalk.yellow(` ⏳ ${k.cooldownRemaining}s`) : '';
          const error = k.lastError ? chalk.red(` · ${k.lastError.slice(0, 40)}`) : '';
          console.log(`    ${icon} ${chalk.dim(k.keyPreview)}  ${k.label || ''}  P:${k.priority}  ${chalk.dim(`✓ ${k.totalRequests} req · ✗ ${k.totalFailures} fail`)}${cooldown}${error}`);
        }
        console.log('');
      }
    }
    return;
  }

  if (action === 'relay-port') {
    const { port } = await inquirer.prompt([{
      type: 'input',
      name: 'port',
      message: '中转服务端口:',
      default: process.env.GATEWAY_RELAY_PORT || '9099',
      validate: v => /^\d+$/.test(v) ? true : '请输入数字',
    }]);
    setEnvVar('GATEWAY_RELAY_PORT', port);
    printSuccess(`中转端口已设为 ${port}`);
    printInfo('重启中转服务后生效');
  }

  if (action === 'relay-timeout') {
    const { minutes } = await inquirer.prompt([{
      type: 'input',
      name: 'minutes',
      message: '中转超时 (分钟):',
      default: String(Math.round((parseInt(process.env.GATEWAY_RELAY_TIMEOUT, 10) || 600000) / 60000)),
      validate: v => /^\d+$/.test(v) ? true : '请输入数字',
    }]);
    setEnvVar('GATEWAY_RELAY_TIMEOUT', parseInt(minutes, 10) * 60000);
    printSuccess(`中转超时已设为 ${minutes} 分钟`);
  }
}

/**
 * Select AI model from available adapters (with connectivity indicators).
 */
async function handleGatewaySelectModel() {
  const inquirer = require('inquirer');
  const gateway = require('../../services/gateway/aiGateway');
  if (!gateway._initialized) await gateway.init();

  const statuses = gateway.getStatus();
  const availableAdapters = statuses.filter(s => s.available && s.enabled);

  if (availableAdapters.length === 0) {
    printError('无可用 AI 通道');
    return;
  }

  // Run connectivity tests in parallel for all available adapters
  printInfo('检测各通道连通性...');
  const testResults = {};
  const testPromises = availableAdapters.map(async (s) => {
    try {
      testResults[s.type] = await gateway.testAdapter(s.type);
    } catch { testResults[s.type] = null; }
  });
  await Promise.all(testPromises);

  // Collect models from all available adapters with indicators
  const modelChoices = [];
  for (const s of availableAdapters) {
    const test = testResults[s.type];
    const adapterOk = test?.connectivity?.success;
    const indicator = adapterOk
      ? chalk.green(`● ${test.connectivity.latencyMs}ms`)
      : chalk.red(`● ${test?.connectivity?.error || 'failed'}`);

    try {
      const models = await gateway.listModels(s.type);
      if (models && models.length > 0) {
        for (const m of models) {
          modelChoices.push({
            name: `${m.name || m.id} ${chalk.dim('(' + s.name + ')')} ${indicator}${m.isDefault ? chalk.green(' ✓ 当前') : ''}`,
            value: { adapter: s.type, model: m.id },
            disabled: !adapterOk ? chalk.red('连接失败') : false,
          });
        }
      } else {
        // Adapter available but no model list (e.g. relay)
        modelChoices.push({
          name: `${s.name} ${chalk.dim('(默认模型)')} ${indicator}`,
          value: { adapter: s.type, model: null },
          disabled: !adapterOk ? chalk.red('连接失败') : false,
        });
      }
    } catch {
      // Skip adapters that fail to list models
      modelChoices.push({
        name: `${s.name} ${chalk.dim('(模型列表获取失败)')} ${chalk.red('●')}`,
        value: { adapter: s.type, model: null },
        disabled: chalk.red('不可用'),
      });
    }
  }

  if (modelChoices.length === 0) {
    printInfo('当前可用通道未提供模型列表');
    return;
  }

  const { selected } = await inquirer.prompt([{
    type: 'list',
    name: 'selected',
    message: '选择 AI 模型:',
    choices: [
      ...modelChoices,
      new inquirer.Separator(),
      { name: '↩️  返回', value: null },
    ],
  }]);

  if (!selected) return;

  // Save selection to .env
  const fs = require('fs');
  const path = require('path');
  const envPath = path.resolve(__dirname, '../../../.env');
  let envContent = '';
  try { envContent = fs.readFileSync(envPath, 'utf-8'); } catch { /* no .env */ }

  function setEnvVar(key, value) {
    const regex = new RegExp(`^${key}=.*$`, 'm');
    const line = `${key}=${value}`;
    if (regex.test(envContent)) {
      envContent = envContent.replace(regex, line);
    } else {
      envContent = envContent.trimEnd() + '\n' + line + '\n';
    }
    process.env[key] = String(value);
  }

  setEnvVar('GATEWAY_PREFERRED_ADAPTER', selected.adapter);
  if (selected.model) setEnvVar('GATEWAY_PREFERRED_MODEL', selected.model);
  fs.writeFileSync(envPath, envContent);

  printSuccess(`已选择: ${selected.model || '默认模型'} (${selected.adapter})`);
  console.log('');
}

/**
 * Explicitly start the web relay server.
 */
async function handleGatewayRelay() {
  const gateway = require('../../services/gateway/aiGateway');
  const relay = gateway.getRelayAdapter();

  if (relay.isRunning()) {
    printInfo(`中转服务已在运行: http://localhost:${relay.getPort()}`);
    return;
  }

  const port = await relay.start();
  console.log('');
  printSuccess(`AI 中转服务已启动`);
  console.log('');
  console.log(chalk.bold(`  🌐 打开浏览器访问: ${chalk.cyan(`http://localhost:${port}`)}`));
  console.log('');
  console.log(chalk.dim('  使用方式:'));
  console.log(chalk.dim('    1. 终端发送 AI 请求后，提示会出现在网页上'));
  console.log(chalk.dim('    2. 点击「一键复制」将提示复制到剪贴板'));
  console.log(chalk.dim('    3. 粘贴到任意 AI 网页（ChatGPT、Claude、Gemini 等）'));
  console.log(chalk.dim('    4. 复制 AI 回复，粘贴到网页文本框，点击「提交」'));
  console.log(chalk.dim('    5. 回复将自动返回到终端'));
  console.log('');
}

/**
 * Detect IDE installations and allow manual path configuration.
 */
async function handleGatewayDetect() {
  const { detectAll, setCustomPath, findInstallation, findDataPath } = require('../../services/gateway/adapters/ideDetector');

  const results = detectAll();

  console.log('');
  console.log(`  ${chalk.cyan.bold('IDE 安装检测')}`);
  console.log('');

  printTable(
    ['IDE', '安装路径', '数据路径', '状态'],
    results.map(r => [
      r.name.charAt(0).toUpperCase() + r.name.slice(1),
      r.installPath || chalk.dim('未找到'),
      r.dataPath ? chalk.dim('✓') : chalk.dim('—'),
      r.available ? chalk.green('✓ 已检测') : chalk.yellow('⚠ 未检测到'),
    ])
  );
  console.log('');

  // Offer to set custom paths for missing IDEs
  const missing = results.filter(r => !r.available);
  if (missing.length > 0) {
    printInfo('未检测到的 IDE 可手动设置安装路径');
    const inquirer = require('inquirer');

    const { action } = await inquirer.prompt([{
      type: 'list',
      name: 'action',
      message: '操作:',
      choices: [
        ...missing.map(r => ({
          name: `设置 ${r.name} 安装路径`,
          value: r.name,
        })),
        { name: '↩️  返回', value: 'back' },
      ],
    }]);

    if (action !== 'back') {
      const { customPath } = await inquirer.prompt([{
        type: 'input',
        name: 'customPath',
        message: `输入 ${action} 安装路径:`,
        validate: (v) => {
          if (!v.trim()) return '路径不能为空';
          return true;
        },
      }]);

      const fs = require('fs');
      const pathModule = require('path');
      const envPath = pathModule.resolve(__dirname, '../../../.env');
      let envContent = '';
      try { envContent = fs.readFileSync(envPath, 'utf-8'); } catch { /* no .env */ }

      const envKey = `${action.toUpperCase()}_INSTALL_PATH`;
      const regex = new RegExp(`^${envKey}=.*$`, 'm');
      const line = `${envKey}=${customPath.trim()}`;

      if (regex.test(envContent)) {
        envContent = envContent.replace(regex, line);
      } else {
        envContent = envContent.trimEnd() + '\n' + line + '\n';
      }

      fs.writeFileSync(envPath, envContent);
      process.env[envKey] = customPath.trim();
      setCustomPath(action, customPath.trim());

      printSuccess(`${action} 安装路径已设为: ${customPath.trim()}`);
    }
  }
}

/**
 * Two-step connectivity test for all or specific adapters.
 * Pattern inspired by cc-haha ProviderTestResult (connectivity + models).
 */
async function handleGatewayTest(targetAdapter) {
  const gateway = require('../../services/gateway/aiGateway');
  if (!gateway._initialized) await gateway.init();

  const statuses = gateway.getStatus();
  const toTest = targetAdapter
    ? statuses.filter(s => s.type === targetAdapter || s.name.toLowerCase().includes(targetAdapter.toLowerCase()))
    : statuses.filter(s => s.enabled);

  if (toTest.length === 0) {
    printError(targetAdapter ? `未找到适配器: ${targetAdapter}` : '无已启用的适配器');
    return;
  }

  console.log('');
  console.log(`  ${chalk.cyan.bold('AI 通道连通测试')}`);
  console.log('');

  for (const s of toTest) {
    console.log(`  ${chalk.bold(s.name)} ${chalk.dim(`(${s.type})`)}`);

    if (!s.available) {
      console.log(`    ${chalk.dim('① 检测')}  ${chalk.red('● 不可用')} ${chalk.dim(s.detail || '')}`);
      console.log('');
      continue;
    }

    const result = await gateway.testAdapter(s.type);

    // Step 1: Connectivity
    if (result.connectivity?.success) {
      console.log(`    ${chalk.dim('① 连接')}  ${chalk.green('● 已连接')} ${chalk.dim(`(${result.connectivity.latencyMs}ms)`)}`);
    } else {
      console.log(`    ${chalk.dim('① 连接')}  ${chalk.red('● 失败:')} ${chalk.red(result.connectivity?.error || 'unknown')}`);
      console.log('');
      continue;
    }

    // Step 2: Models (if tested)
    if (result.models) {
      if (result.models.success) {
        const modelNames = result.models.list?.slice(0, 3).map(m => m.name || m.id).join(', ') || '';
        const more = result.models.count > 3 ? ` +${result.models.count - 3}` : '';
        console.log(`    ${chalk.dim('② 模型')}  ${chalk.green('● 可用')} ${chalk.dim(`(${result.models.latencyMs}ms · ${result.models.count} models)`)}${modelNames ? chalk.dim(` ${modelNames}${more}`) : ''}`);
      } else {
        console.log(`    ${chalk.dim('② 模型')}  ${chalk.red('● 失败:')} ${chalk.red(result.models.error || 'unknown')} ${chalk.dim(`(${result.models.latencyMs}ms)`)}`);
      }
    }

    console.log('');
  }
}

/**
 * Start/stop/status the AI management backend server.
 * @param {string} action - 'start' | 'stop' | 'status'
 */
async function handleAiServer(action) {
  const server = require('../../services/aiManagementServer');

  if (action === 'stop') {
    if (!server.isRunning()) {
      printInfo('AI 管理服务未运行');
      return;
    }
    await server.stop();
    printSuccess('AI 管理服务已停止');
    return;
  }

  if (action === 'status') {
    if (server.isRunning()) {
      printSuccess(`AI 管理服务运行中: http://localhost:${server.getPort()}`);
    } else {
      printInfo('AI 管理服务未运行');
    }
    return;
  }

  // Default: start
  if (server.isRunning()) {
    printInfo(`AI 管理服务已在运行: http://localhost:${server.getPort()}`);
    return;
  }

  const port = await server.start();
  console.log('');
  printSuccess('AI 管理服务已启动');
  console.log('');
  console.log(chalk.bold(`  🌐 API:       ${chalk.cyan(`http://localhost:${port}/api/health`)}`));
  console.log(chalk.bold(`  🔌 WebSocket: ${chalk.cyan(`ws://localhost:${port}/ws`)}`));
  console.log('');
  console.log(chalk.dim('  REST 端点:'));
  console.log(chalk.dim('    GET  /api/status          — 适配器状态'));
  console.log(chalk.dim('    GET  /api/models          — 模型列表 (含健康指标)'));
  console.log(chalk.dim('    POST /api/test/:adapter   — 两步连通测试'));
  console.log(chalk.dim('    GET  /api/config          — 网关配置'));
  console.log(chalk.dim('    PUT  /api/config          — 更新配置'));
  console.log(chalk.dim('    GET  /api/conversations   — 会话列表'));
  console.log(chalk.dim('    GET  /api/usage           — Token 用量'));
  console.log(chalk.dim('    GET  /api/tools           — 工具列表'));
  console.log(chalk.dim('    POST /api/tools/:name     — 执行工具'));
  console.log('');
}

/**
 * Display supported protocol conversion formats.
 */
function handleGatewayProtocols() {
  const { getSupportedProtocols, PROTOCOLS } = require('../../services/gateway/protocolConverter');

  console.log('');
  console.log(`  ${ICON_GATEWAY} ${chalk.cyan.bold('协议转换支持')}`);
  console.log('');

  const protocols = getSupportedProtocols();
  const rows = protocols.map(p => {
    const endpoints = {
      [PROTOCOLS.OPENAI]: '/v1/chat/completions',
      [PROTOCOLS.ANTHROPIC]: '/v1/messages',
      [PROTOCOLS.GEMINI]: '/v1beta/models/:model:generateContent',
      [PROTOCOLS.GROK]: '/v1/chat/completions (Grok)',
      [PROTOCOLS.CODEX]: '/v1/responses',
    };
    return [p, endpoints[p] || '—', chalk.green('✓ 双向')];
  });

  printTable(['协议', '端点', '转换方向'], rows);

  console.log('');
  printInfo('任意协议间可互转（通过 Canonical 中间格式）');
  printInfo('代理服务自动检测输入协议，以原协议格式返回');
  console.log('');
}

/**
 * OAuth token management.
 */
async function handleGatewayOAuth(action, provider) {
  const oauth = require('../../services/gateway/oauthManager');
  oauth.init();

  if (action === 'refresh' && provider) {
    printInfo(`正在刷新 ${provider} token...`);
    const token = await oauth.refreshToken(provider);
    if (token) {
      printSuccess(`${provider} token 已刷新`);
    } else {
      printError(`${provider} 刷新失败 — 请检查 refresh_token 配置`);
    }
    return;
  }

  // Default: status
  const allStatus = oauth.getAllStatus();
  console.log('');
  console.log(`  ${ICON_GATEWAY} ${chalk.cyan.bold('OAuth Token 状态')}`);
  console.log('');

  for (const [key, status] of Object.entries(allStatus)) {
    const icon = status.valid ? chalk.green('●') : (status.registered ? chalk.yellow('●') : chalk.dim('○'));
    const expiry = status.expiresIn > 0 ? chalk.dim(`(${Math.round(status.expiresIn / 60)}min)`) : '';
    const error = status.error ? chalk.red(` · ${status.error.slice(0, 40)}`) : '';
    const refresh = status.hasRefreshToken ? chalk.dim(' [refresh]') : '';
    console.log(`  ${icon} ${chalk.white(status.provider || key)} ${status.valid ? chalk.green('有效') : (status.registered ? chalk.yellow('已过期') : chalk.dim('未配置'))} ${expiry}${refresh}${error}`);
  }

  console.log('');
  printInfo('使用 gateway oauth refresh <provider> 强制刷新');
  console.log('');
}

module.exports = { handleGatewayStatus, handleGatewayConfig, handleGatewayRelay, handleGatewayDetect, handleGatewaySelectModel, handleGatewayTest, handleAiServer, handleGatewayProtocols, handleGatewayOAuth };
