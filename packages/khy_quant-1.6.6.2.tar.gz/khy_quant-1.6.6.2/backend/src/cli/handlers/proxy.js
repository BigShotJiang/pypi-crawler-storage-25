/**
 * CLI Handlers for the Reverse Proxy server.
 * Commands: proxy start, proxy stop, proxy status
 */
const chalk = require('chalk');
const { printSuccess, printError, printInfo } = require('../formatters');

function getProxy() {
  return require('../../services/gateway/proxyServer');
}

async function handleProxyStart(options = {}) {
  const proxy = getProxy();

  if (proxy.isRunning()) {
    printInfo(`代理服务已在运行: http://localhost:${proxy.getPort()}`);
    return;
  }

  try {
    const port = await proxy.start(options.port ? parseInt(options.port, 10) : undefined);
    console.log('');
    printSuccess('反向代理已启动');
    console.log('');
    console.log(`  ${chalk.gray('Chat:')}    ${chalk.cyan(`http://localhost:${port}/v1/chat/completions`)}`);
    console.log(`  ${chalk.gray('Models:')}  ${chalk.cyan(`http://localhost:${port}/v1/models`)}`);
    console.log(`  ${chalk.gray('Health:')} ${chalk.cyan(`http://localhost:${port}/health`)}`);
    console.log('');
    console.log(chalk.dim('  模型格式: kiro/claude-sonnet-4, cursor/gpt-4o, claude/claude-opus-4-6'));
    console.log(chalk.dim('  无前缀时按网关优先级级联'));
    console.log('');
  } catch (err) {
    printError(`启动失败: ${err.message}`);
  }
}

async function handleProxyStop() {
  const proxy = getProxy();
  if (!proxy.isRunning()) {
    printInfo('代理服务未运行');
    return;
  }
  await proxy.stop();
  printSuccess('反向代理已停止');
}

async function handleProxyStatus() {
  const proxy = getProxy();
  if (proxy.isRunning()) {
    printSuccess(`反向代理运行中: http://localhost:${proxy.getPort()}`);
  } else {
    printInfo('反向代理未运行 — 使用 proxy start 启动');
  }
}

/**
 * TLS Sidecar commands: proxy tls start/stop/status/fingerprint
 */
async function handleProxyTls(action, arg) {
  const sidecar = require('../../services/gateway/tlsSidecar');

  if (action === 'start') {
    if (sidecar.isRunning()) {
      printInfo(`TLS Sidecar 已在运行: ${sidecar.getProxyUrl()}`);
      return;
    }
    try {
      const result = await sidecar.start();
      printSuccess(`TLS Sidecar 已启动 (PID: ${result.pid})`);
      console.log(`  ${chalk.gray('代理地址:')} ${chalk.cyan(sidecar.getProxyUrl())}`);
      console.log(`  ${chalk.gray('指纹:')}     ${chalk.cyan(result.fingerprint)}`);
      console.log('');
      const config = sidecar.loadConfig();
      console.log(chalk.dim(`  目标域名: ${config.targets.join(', ')}`));
      console.log('');
    } catch (err) {
      printError(`TLS Sidecar 启动失败: ${err.message}`);
      if (err.message.includes('binary not available')) {
        printInfo('需要 Go 1.21+ 工具链来编译 sidecar');
        printInfo('安装 Go: https://go.dev/dl/');
      }
    }
  } else if (action === 'stop') {
    if (!sidecar.isRunning()) {
      printInfo('TLS Sidecar 未运行');
      return;
    }
    await sidecar.stop();
    printSuccess('TLS Sidecar 已停止');
  } else if (action === 'fingerprint' && arg) {
    await sidecar.setFingerprint(arg);
    printSuccess(`TLS 指纹已切换为: ${arg}`);
    printInfo('支持: chrome_auto, chrome_120, firefox_auto, firefox_120, safari, random');
  } else {
    // status
    const status = sidecar.getStatus();
    console.log('');
    console.log(`  ${chalk.cyan.bold('TLS Sidecar 状态')}`);
    console.log('');
    console.log(`  ${chalk.gray('运行:')}       ${status.running ? chalk.green('● 是') : chalk.red('● 否')}`);
    console.log(`  ${chalk.gray('已启用:')}     ${status.enabled ? '是' : '否'}`);
    console.log(`  ${chalk.gray('端口:')}       ${status.port}`);
    console.log(`  ${chalk.gray('指纹:')}       ${status.fingerprint}`);
    console.log(`  ${chalk.gray('二进制:')}     ${status.binaryInstalled ? chalk.green('已安装') : chalk.yellow('未安装')}`);
    console.log(`  ${chalk.gray('Go 工具链:')} ${status.goAvailable ? chalk.green('可用') : chalk.yellow('不可用')}`);
    console.log(`  ${chalk.gray('目标域名:')}   ${status.targets.join(', ')}`);
    if (status.pid) console.log(`  ${chalk.gray('PID:')}        ${status.pid}`);
    console.log('');
  }
}

module.exports = { handleProxyStart, handleProxyStop, handleProxyStatus, handleProxyTls };
