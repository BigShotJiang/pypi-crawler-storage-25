/**
 * CLI Handlers for Antigravity-style Account Pool management.
 * Commands: pool list, pool add, pool delete, pool enable, pool disable,
 *           pool status, pool scheduling, pool import
 */
const chalk = require('chalk');
const { printSuccess, printError, printInfo, printTable } = require('../formatters');

function getPool() {
  return require('../../services/accountPool');
}

const PROVIDERS = [
  'deepseek', 'openai', 'anthropic', 'qwen', 'glm', 'doubao', 'wenxin', 'relay',
];

const TIER_COLORS = {
  ULTRA: chalk.hex('#FFD700'),
  PRO: chalk.hex('#409EFF'),
  FREE: chalk.dim,
};

const STATUS_COLORS = {
  active: chalk.green,
  cooldown: chalk.yellow,
  disabled: chalk.dim,
  circuit_open: chalk.red,
};

/**
 * Display all accounts in a table.
 */
async function handlePoolList() {
  const pool = getPool();
  await pool.init();

  const accounts = pool.getAllAccounts();

  if (accounts.length === 0) {
    printInfo('账号池为空 — 使用 pool add <provider> 添加账号');
    return;
  }

  console.log('');
  console.log(`  ${chalk.cyan.bold('AI 账号池')}`);
  console.log('');

  printTable(
    ['ID', '提供商', '标签', '层级', '状态', '健康', '配额', '请求', '失败'],
    accounts.map(a => [
      String(a.id || '-'),
      a.provider,
      a.label || a.email || chalk.dim('-'),
      (TIER_COLORS[a.tier] || chalk.dim)(a.tier),
      (STATUS_COLORS[a.status] || chalk.dim)(a.status),
      _healthBar(a.healthScore),
      _quotaBar(a.quotaRemaining),
      String(a.totalRequests || 0),
      a.totalFailures > 0 ? chalk.red(String(a.totalFailures)) : '0',
    ])
  );
  console.log('');
}

/**
 * Interactive add account.
 */
async function handlePoolAdd(provider) {
  const inquirer = require('inquirer');
  const pool = getPool();
  await pool.init();

  if (!provider) {
    const ans = await inquirer.prompt([{
      type: 'list',
      name: 'provider',
      message: '选择 AI 提供商:',
      choices: [...PROVIDERS, new inquirer.Separator(), { name: '↩️  返回', value: null }],
    }]);
    if (!ans.provider) return;
    provider = ans.provider;
  }

  if (!PROVIDERS.includes(provider)) {
    printError(`不支持的提供商: ${provider}。可选: ${PROVIDERS.join(', ')}`);
    return;
  }

  const answers = await inquirer.prompt([
    {
      type: 'password',
      name: 'apiKey',
      message: 'API Key:',
      mask: '*',
      validate: v => v.length > 0 ? true : '请输入 API Key',
    },
    {
      type: 'input',
      name: 'endpoint',
      message: 'API 端点 (可选, 回车跳过):',
      default: '',
    },
    {
      type: 'list',
      name: 'tier',
      message: '账号层级:',
      choices: [
        { name: 'FREE  — 免费额度', value: 'FREE' },
        { name: 'PRO   — 付费标准', value: 'PRO' },
        { name: 'ULTRA — 高级/无限', value: 'ULTRA' },
      ],
      default: 'FREE',
    },
    {
      type: 'input',
      name: 'label',
      message: '标签 (可选):',
      default: '',
    },
    {
      type: 'input',
      name: 'priority',
      message: '优先级 (数字, 0=默认):',
      default: '0',
      validate: v => /^\d+$/.test(v) ? true : '请输入数字',
    },
  ]);

  try {
    const account = await pool.addAccount({
      provider,
      apiKey: answers.apiKey,
      endpoint: answers.endpoint,
      tier: answers.tier,
      label: answers.label,
      priority: parseInt(answers.priority, 10),
    });
    printSuccess(`账号已添加: ${provider} [${answers.tier}]${answers.label ? ' — ' + answers.label : ''}`);
  } catch (err) {
    printError(`添加失败: ${err.message}`);
  }
}

/**
 * Delete an account.
 */
async function handlePoolDelete(idOrLabel) {
  const pool = getPool();
  await pool.init();

  if (!idOrLabel) {
    printError('用法: pool delete <id|label>');
    return;
  }

  const accounts = pool.getAllAccounts();
  const target = accounts.find(a =>
    String(a.id) === String(idOrLabel) ||
    (a.label && a.label.toLowerCase() === String(idOrLabel).toLowerCase())
  );

  if (!target) {
    printError(`未找到账号: ${idOrLabel}`);
    return;
  }

  const inquirer = require('inquirer');
  const { confirm } = await inquirer.prompt([{
    type: 'confirm',
    name: 'confirm',
    message: `确认删除 ${target.provider} 账号 "${target.label || target.id}"?`,
    default: false,
  }]);

  if (confirm) {
    await pool.removeAccount(target.id);
    printSuccess('账号已删除');
  }
}

/**
 * Enable an account.
 */
async function handlePoolEnable(idOrLabel) {
  const pool = getPool();
  await pool.init();
  const account = _findAccount(pool, idOrLabel);
  if (!account) return;
  await pool.enableAccount(account.id);
  printSuccess(`账号 "${account.label || account.id}" 已启用`);
}

/**
 * Disable an account.
 */
async function handlePoolDisable(idOrLabel) {
  const pool = getPool();
  await pool.init();
  const account = _findAccount(pool, idOrLabel);
  if (!account) return;
  await pool.disableAccount(account.id);
  printSuccess(`账号 "${account.label || account.id}" 已禁用`);
}

/**
 * Show pool status overview.
 */
async function handlePoolStatus() {
  const pool = getPool();
  await pool.init();
  const status = pool.getStatus();

  console.log('');
  console.log(`  ${chalk.cyan.bold('账号池概览')}`);
  console.log('');
  console.log(`  总账号: ${chalk.white.bold(status.totalAccounts)}`);
  console.log(`  调度模式: ${chalk.cyan(status.schedulingMode)}`);
  console.log(`  熔断器: ${status.circuitBreaker.enabled ? chalk.green('启用') : chalk.dim('禁用')}`);
  console.log('');

  if (Object.keys(status.byProvider).length > 0) {
    printTable(
      ['提供商', '总计', '活跃', '冷却', '熔断', '禁用'],
      Object.entries(status.byProvider).map(([prov, s]) => [
        prov,
        String(s.total),
        chalk.green(String(s.active)),
        s.cooldown > 0 ? chalk.yellow(String(s.cooldown)) : '0',
        s.circuitOpen > 0 ? chalk.red(String(s.circuitOpen)) : '0',
        s.disabled > 0 ? chalk.dim(String(s.disabled)) : '0',
      ])
    );
  } else {
    printInfo('无账号');
  }
  console.log('');
}

/**
 * View or change scheduling mode.
 */
async function handlePoolScheduling(mode) {
  const pool = getPool();
  await pool.init();

  const validModes = ['PerformanceFirst', 'Balance', 'CacheFirst'];

  if (!mode) {
    const config = pool.getSchedulingConfig();
    console.log('');
    console.log(`  当前调度模式: ${chalk.cyan.bold(config.schedulingMode)}`);
    console.log(`  最大等待秒数: ${config.maxWaitSeconds}s (CacheFirst 模式)`);
    console.log('');
    console.log(chalk.dim('  可用模式:'));
    console.log(chalk.dim('    PerformanceFirst — 纯轮询，最大吞吐'));
    console.log(chalk.dim('    Balance          — 粘性 + 快速故障转移 (推荐)'));
    console.log(chalk.dim('    CacheFirst       — 最大复用，减少提示缓存失效'));
    console.log('');
    printInfo('使用 pool scheduling <mode> 切换');
    return;
  }

  if (!validModes.includes(mode)) {
    printError(`无效模式: ${mode}。可选: ${validModes.join(', ')}`);
    return;
  }

  pool.setSchedulingConfig({ schedulingMode: mode });
  printSuccess(`调度模式已切换为: ${mode}`);
}

// ── Helpers ──

function _findAccount(pool, idOrLabel) {
  if (!idOrLabel) {
    printError('请指定账号 ID 或标签');
    return null;
  }
  const accounts = pool.getAllAccounts();
  const target = accounts.find(a =>
    String(a.id) === String(idOrLabel) ||
    (a.label && a.label.toLowerCase() === String(idOrLabel).toLowerCase())
  );
  if (!target) {
    printError(`未找到账号: ${idOrLabel}`);
    return null;
  }
  return target;
}

function _healthBar(score) {
  const pct = Math.round((score || 0) * 100);
  if (pct >= 80) return chalk.green(`${pct}%`);
  if (pct >= 50) return chalk.yellow(`${pct}%`);
  return chalk.red(`${pct}%`);
}

function _quotaBar(remaining) {
  const pct = Math.round(remaining || 0);
  if (pct >= 50) return chalk.green(`${pct}%`);
  if (pct >= 20) return chalk.yellow(`${pct}%`);
  return chalk.red(`${pct}%`);
}

module.exports = {
  handlePoolList,
  handlePoolAdd,
  handlePoolDelete,
  handlePoolEnable,
  handlePoolDisable,
  handlePoolStatus,
  handlePoolScheduling,
};
