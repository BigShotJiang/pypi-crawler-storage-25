module.exports = require('../../../packages/shared/src/models/UserFavorite.js');
