module.exports = require('../../../packages/shared/src/models/Instrument.js');
