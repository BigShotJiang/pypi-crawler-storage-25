module.exports = require('../../../packages/shared/src/models/KlineCache.js');
