module.exports = require('../../../packages/shared/src/models/User.js');
