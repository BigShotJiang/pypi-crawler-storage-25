module.exports = require('../../../packages/shared/src/models/MarketData.js');
