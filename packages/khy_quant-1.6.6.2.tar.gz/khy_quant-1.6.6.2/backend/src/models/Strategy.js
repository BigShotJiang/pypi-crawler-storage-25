module.exports = require('../../../packages/shared/src/models/Strategy.js');
