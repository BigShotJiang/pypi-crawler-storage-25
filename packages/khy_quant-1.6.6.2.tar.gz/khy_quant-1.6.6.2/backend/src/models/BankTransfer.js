module.exports = require('../../../packages/shared/src/models/BankTransfer.js');
