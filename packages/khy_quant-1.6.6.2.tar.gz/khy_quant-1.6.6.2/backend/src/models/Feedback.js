module.exports = require('../../../packages/shared/src/models/Feedback.js');
