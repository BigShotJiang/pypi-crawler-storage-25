/**
 * Compatibility shim — re-exports models from @khy/shared.
 * Existing backend code using require('../models') continues to work.
 */
module.exports = require('../../../packages/shared/src/models');
