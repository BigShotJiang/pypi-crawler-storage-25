module.exports = require('../../../packages/shared/src/models/KlineData.js');
