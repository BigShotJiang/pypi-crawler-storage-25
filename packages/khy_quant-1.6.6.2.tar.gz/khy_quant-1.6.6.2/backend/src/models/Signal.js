module.exports = require('../../../packages/shared/src/models/Signal.js');
