module.exports = require('../../../packages/shared/src/models/AISuggestion.js');
