module.exports = require('../../../packages/shared/src/models/AnnouncementRead.js');
