module.exports = require('../../../packages/shared/src/models/Backtest.js');
