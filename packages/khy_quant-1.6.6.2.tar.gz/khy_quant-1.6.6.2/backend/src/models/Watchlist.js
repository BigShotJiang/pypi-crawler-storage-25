module.exports = require('../../../packages/shared/src/models/Watchlist.js');
