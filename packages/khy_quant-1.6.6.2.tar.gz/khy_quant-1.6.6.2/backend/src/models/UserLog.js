module.exports = require('../../../packages/shared/src/models/UserLog.js');
