module.exports = require('../../../packages/shared/src/models/Announcement.js');
