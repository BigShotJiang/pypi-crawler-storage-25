module.exports = require('../../../packages/shared/src/models/Trade.js');
