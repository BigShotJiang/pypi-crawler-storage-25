module.exports = require('../../../packages/shared/src/models/SystemSetting.js');
