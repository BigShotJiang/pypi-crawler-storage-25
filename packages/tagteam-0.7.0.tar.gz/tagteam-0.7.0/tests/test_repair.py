"""Tests for the Phase 28 Step A repair state machine
(`tagteam.repair`).

Covers:
  - `should_attempt_repair` gating on sentinel + backoff window
  - `attempt_repair` happy path (sentinel cleared, success returned)
  - `attempt_repair` failure path (sentinel preserved, backoff
    advanced, exponential schedule)
  - `attempt_repair` reentrancy under existing writer lock
  - `needs_louder_signal` 24-hour threshold
  - Sentinel `since` preserved across failures (louder-signal anchor)
"""

import json
from datetime import datetime, timezone, timedelta
from pathlib import Path
from unittest.mock import patch

import pytest

from tagteam import cycle, db, dualwrite, repair


@pytest.fixture
def project(tmp_path):
    (tmp_path / "docs" / "handoffs").mkdir(parents=True)
    return tmp_path


def _seed_clean_cycle(project):
    """Set up a project with one valid cycle so import_from_files
    has something to import."""
    cycle.init_cycle("p", "plan", "L", "R", "v1", str(project))


# ---------- should_attempt_repair ----------

class TestShouldAttemptRepair:
    def test_false_when_sentinel_clear(self, project):
        assert repair.should_attempt_repair(project) is False

    def test_true_when_sentinel_set_and_no_prior_attempt(self, project):
        dualwrite.mark_db_invalid(project, reason="test")
        assert repair.should_attempt_repair(project) is True

    def test_false_when_within_backoff_window(self, project):
        dualwrite.mark_db_invalid(project, reason="test")
        # Manually set next_attempt_at to the future.
        flag = project / ".tagteam" / "DB_INVALID"
        info = json.loads(flag.read_text())
        future = datetime.now(timezone.utc) + timedelta(minutes=10)
        info["next_attempt_at"] = future.isoformat()
        flag.write_text(json.dumps(info))
        assert repair.should_attempt_repair(project) is False

    def test_true_when_backoff_window_elapsed(self, project):
        dualwrite.mark_db_invalid(project, reason="test")
        flag = project / ".tagteam" / "DB_INVALID"
        info = json.loads(flag.read_text())
        past = datetime.now(timezone.utc) - timedelta(minutes=1)
        info["next_attempt_at"] = past.isoformat()
        flag.write_text(json.dumps(info))
        assert repair.should_attempt_repair(project) is True

    def test_true_on_unparseable_backoff(self, project):
        """Permissive on corruption — let the next attempt either
        succeed or rewrite the field."""
        dualwrite.mark_db_invalid(project, reason="test")
        flag = project / ".tagteam" / "DB_INVALID"
        info = json.loads(flag.read_text())
        info["next_attempt_at"] = "not a timestamp"
        flag.write_text(json.dumps(info))
        assert repair.should_attempt_repair(project) is True


# ---------- attempt_repair: happy path ----------

class TestAttemptRepairHappyPath:
    def test_clears_sentinel_after_successful_rebuild(self, project):
        _seed_clean_cycle(project)
        dualwrite.mark_db_invalid(project, reason="simulated failure")
        assert dualwrite.is_db_invalid(project)

        result = repair.attempt_repair(project)
        assert result["success"] is True
        assert dualwrite.is_db_invalid(project) is False

    def test_db_rebuilt_from_files(self, project):
        _seed_clean_cycle(project)
        # Tamper with the DB — mutate a round so it diverges from files.
        conn = db.connect(project_dir=str(project))
        try:
            conn.execute("UPDATE rounds SET content='tampered' WHERE 1=1")
            conn.commit()
        finally:
            conn.close()
        dualwrite.mark_db_invalid(project, reason="simulated")

        result = repair.attempt_repair(project)
        assert result["success"] is True

        conn = db.connect(project_dir=str(project))
        try:
            rows = conn.execute("SELECT content FROM rounds").fetchall()
        finally:
            conn.close()
        # The tampered content was overwritten by the rebuild from files.
        assert all("tampered" not in r[0] for r in rows)

    def test_idempotent_when_sentinel_already_clear(self, project):
        _seed_clean_cycle(project)
        # No sentinel set — should be a no-op success.
        result = repair.attempt_repair(project)
        assert result["success"] is True
        assert "sentinel not set" in result.get("reason", "")

    def test_rebuild_helper_runs_when_sentinel_clear(self, project):
        _seed_clean_cycle(project)
        conn = db.connect(project_dir=str(project))
        try:
            conn.execute("UPDATE rounds SET content='tampered' WHERE 1=1")
            conn.commit()
        finally:
            conn.close()

        result = repair.rebuild_db_from_files_and_verify(project)
        assert result["success"] is True
        conn = result["conn"]
        try:
            rows = conn.execute("SELECT content FROM rounds").fetchall()
        finally:
            conn.close()
        assert all("tampered" not in r[0] for r in rows)

    def test_repair_exports_markdown_when_step_b_active(self, project, monkeypatch):
        monkeypatch.setenv("TAGTEAM_STEP_B", "1")
        _seed_clean_cycle(project)
        (project / "docs" / "handoffs" / "p_plan.md").unlink()
        dualwrite.mark_db_invalid(project, reason="simulated")

        result = repair.attempt_repair(project)
        assert result["success"] is True
        md = project / "docs" / "handoffs" / "p_plan.md"
        assert md.exists()
        conn = db.connect(project_dir=str(project))
        try:
            assert md.read_text() == db.render_cycle(conn, "p", "plan")
        finally:
            conn.close()


# ---------- attempt_repair: failure path ----------

class TestAttemptRepairFailurePath:
    def test_failure_keeps_sentinel_set(self, project):
        _seed_clean_cycle(project)
        dualwrite.mark_db_invalid(project, reason="simulated")

        with patch(
            "tagteam.db.import_from_files",
            side_effect=RuntimeError("import failed"),
        ):
            result = repair.attempt_repair(project)

        assert result["success"] is False
        assert dualwrite.is_db_invalid(project) is True
        assert "import failed" in result["reason"]

    def test_failure_records_backoff(self, project):
        _seed_clean_cycle(project)
        dualwrite.mark_db_invalid(project, reason="simulated")
        now = datetime.now(timezone.utc)

        with patch(
            "tagteam.db.import_from_files",
            side_effect=RuntimeError("import failed"),
        ):
            result = repair.attempt_repair(project, now=now)

        next_at = datetime.fromisoformat(result["next_attempt_at"])
        # First failure: 1 minute backoff
        assert (next_at - now).total_seconds() == 60

    def test_exponential_backoff_schedule(self, project):
        """Each failure doubles the backoff up to 1-hour cap."""
        _seed_clean_cycle(project)
        dualwrite.mark_db_invalid(project, reason="simulated")
        now = datetime.now(timezone.utc)

        expected_delays = [60, 120, 240, 480, 960, 1920, 3600, 3600, 3600]

        with patch(
            "tagteam.db.import_from_files",
            side_effect=RuntimeError("nope"),
        ):
            for i, expected_delay in enumerate(expected_delays):
                result = repair.attempt_repair(project, now=now)
                next_at = datetime.fromisoformat(result["next_attempt_at"])
                actual_delay = (next_at - now).total_seconds()
                assert actual_delay == expected_delay, (
                    f"failure #{i+1}: expected {expected_delay}s, "
                    f"got {actual_delay}s"
                )

    def test_since_preserved_across_failures(self, project):
        """The `since` timestamp must NOT advance on each failure
        — it anchors the 24-hour louder-signal threshold."""
        _seed_clean_cycle(project)
        dualwrite.mark_db_invalid(project, reason="simulated")
        original_since = dualwrite.get_db_invalid_info(project)["since"]

        with patch(
            "tagteam.db.import_from_files",
            side_effect=RuntimeError("nope"),
        ):
            for _ in range(3):
                repair.attempt_repair(project)

        info = dualwrite.get_db_invalid_info(project)
        assert info["since"] == original_since
        assert info["consecutive_failures"] == 3

    def test_inconsistent_file_blocks_repair(self, project):
        """If the file side has malformed input, repair refuses to
        rebuild — the operator needs to fix the files first. Sentinel
        stays set, with a `file_inconsistent` reason."""
        _seed_clean_cycle(project)
        # Corrupt the file side: rounds.jsonl with a non-object line
        # trips file_side_sanity's `rounds_jsonl_object_shape` check.
        rp = project / "docs" / "handoffs" / "p_plan_rounds.jsonl"
        rp.write_text("1\n")
        dualwrite.mark_db_invalid(project, reason="simulated")

        result = repair.attempt_repair(project)
        assert result["success"] is False
        assert dualwrite.is_db_invalid(project) is True
        assert "file_inconsistent" in result["reason"]
        assert "object_shape" in result["reason"]

    @pytest.mark.parametrize("malformed_file,bad_content", [
        ("p_plan_status.json", "[]"),
        ("p_plan_status.json", '"not an object"'),
        ("p_plan_status.json", "42"),
    ])
    def test_repair_handles_non_object_status_without_crashing(
        self, project, malformed_file, bad_content
    ):
        """Regression for Codex round-2 review blocker: a status.json
        that's valid JSON but not an object used to crash
        file_side_sanity's `.keys()` call, which would escape repair's
        backoff handling entirely. Repair must classify it as
        file_inconsistent and record a bounded-backoff failure."""
        _seed_clean_cycle(project)
        (project / "docs" / "handoffs" / malformed_file).write_text(
            bad_content
        )
        dualwrite.mark_db_invalid(project, reason="simulated")

        # Must not raise.
        result = repair.attempt_repair(project)
        assert result["success"] is False
        assert "file_inconsistent" in result["reason"]
        assert "status_json_object_shape" in result["reason"]
        # Sentinel remains set — backoff state advanced.
        assert dualwrite.is_db_invalid(project)
        info = dualwrite.get_db_invalid_info(project)
        assert info["consecutive_failures"] >= 1

    def test_repair_handles_non_object_state_without_crashing(self, project):
        """Same regression but for handoff-state.json. Without the
        fix, check_state_file_integrity would AttributeError on
        `.get(...)` and escape repair."""
        _seed_clean_cycle(project)
        (project / "handoff-state.json").write_text("[]")
        dualwrite.mark_db_invalid(project, reason="simulated")

        result = repair.attempt_repair(project)
        assert result["success"] is False
        assert "file_inconsistent" in result["reason"]
        assert "state_json_object_shape" in result["reason"]
        assert dualwrite.is_db_invalid(project)


# ---------- needs_louder_signal ----------

class TestNeedsLouderSignal:
    def test_false_when_sentinel_clear(self, project):
        assert repair.needs_louder_signal(project) is False

    def test_false_when_recent(self, project):
        dualwrite.mark_db_invalid(project, reason="test")
        # Default `since` is now — recent, no louder signal.
        assert repair.needs_louder_signal(project) is False

    def test_true_when_24h_old(self, project):
        dualwrite.mark_db_invalid(project, reason="test")
        # Force `since` to 25 hours ago.
        flag = project / ".tagteam" / "DB_INVALID"
        info = json.loads(flag.read_text())
        old = datetime.now(timezone.utc) - timedelta(hours=25)
        info["since"] = old.isoformat()
        flag.write_text(json.dumps(info))
        assert repair.needs_louder_signal(project) is True

    def test_threshold_boundary(self, project):
        """Just under 24h: False. At/over 24h: True."""
        dualwrite.mark_db_invalid(project, reason="test")
        flag = project / ".tagteam" / "DB_INVALID"
        info = json.loads(flag.read_text())

        # 23h59m: False
        info["since"] = (
            datetime.now(timezone.utc) - timedelta(hours=23, minutes=59)
        ).isoformat()
        flag.write_text(json.dumps(info))
        assert repair.needs_louder_signal(project) is False

        # 24h01m: True
        info["since"] = (
            datetime.now(timezone.utc) - timedelta(hours=24, minutes=1)
        ).isoformat()
        flag.write_text(json.dumps(info))
        assert repair.needs_louder_signal(project) is True


# ---------- Reentrancy with existing writer lock ----------

class TestRepairReentrancy:
    def test_repair_works_when_caller_holds_lock(self, project):
        """Retry-on-next-write callers run inside the dual-write
        writer lock. attempt_repair must re-acquire harmlessly."""
        _seed_clean_cycle(project)
        dualwrite.mark_db_invalid(project, reason="simulated")

        with dualwrite.writer_lock(project):
            result = repair.attempt_repair(project)

        assert result["success"] is True
        assert dualwrite.is_db_invalid(project) is False


# ---------- CLI: tagteam state repair-db ----------

class TestStateRepairDbCli:
    @pytest.fixture
    def cli_project(self, tmp_path, monkeypatch):
        from tagteam import state
        (tmp_path / "tagteam.yaml").write_text(
            "agents:\n  lead: {name: L}\n  reviewer: {name: R}\n"
        )
        monkeypatch.setattr(state, "_cached_project_root", None,
                            raising=False)
        monkeypatch.chdir(tmp_path)
        cycle.init_cycle("p", "plan", "L", "R", "v1", str(tmp_path))
        return tmp_path

    def test_no_op_when_sentinel_clear(self, cli_project, capsys):
        from tagteam.state import _state_repair_db
        rc = _state_repair_db([])
        assert rc == 0
        out = capsys.readouterr().out
        assert "DB is healthy" in out

    def test_repair_succeeds(self, cli_project, capsys):
        from tagteam.state import _state_repair_db
        dualwrite.mark_db_invalid(cli_project, reason="test")
        rc = _state_repair_db([])
        assert rc == 0
        out = capsys.readouterr().out
        assert "Repair succeeded" in out
        assert dualwrite.is_db_invalid(cli_project) is False

    def test_force_clear_skips_repair(self, cli_project, capsys):
        from tagteam.state import _state_repair_db
        dualwrite.mark_db_invalid(cli_project, reason="test")
        rc = _state_repair_db(["--force-clear"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "force-clear" in out
        assert "WARNING" in out
        assert dualwrite.is_db_invalid(cli_project) is False

    def test_force_clear_when_clear_is_no_op(self, cli_project, capsys):
        from tagteam.state import _state_repair_db
        rc = _state_repair_db(["--force-clear"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "nothing to clear" in out

    def test_returns_nonzero_in_backoff(self, cli_project, capsys):
        from tagteam.state import _state_repair_db
        dualwrite.mark_db_invalid(cli_project, reason="test")
        # Set next_attempt_at to the future
        flag = cli_project / ".tagteam" / "DB_INVALID"
        info = json.loads(flag.read_text())
        future = (datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat()
        info["next_attempt_at"] = future
        flag.write_text(json.dumps(info))

        rc = _state_repair_db([])
        assert rc == 1
        out = capsys.readouterr().out
        assert "Backoff in effect" in out


# ---------- Retry-on-next-write hook ----------

class TestRetryOnNextWrite:
    def test_cycle_write_triggers_repair(self, project):
        """When a cycle write happens with sentinel set + backoff
        elapsed, the shadow-write helper attempts repair before
        proceeding."""
        _seed_clean_cycle(project)
        dualwrite.mark_db_invalid(project, reason="simulated")
        assert dualwrite.is_db_invalid(project)

        # Trigger another cycle write — should opportunistically repair.
        cycle.add_round("p", "plan", "reviewer", "REQUEST_CHANGES",
                        1, "fix", str(project))

        # Sentinel cleared by the retry-on-next-write hook.
        assert dualwrite.is_db_invalid(project) is False

        # DB also has the new round (from the repair's rebuild).
        conn = db.connect(project_dir=str(project))
        try:
            n_rounds = conn.execute(
                "SELECT COUNT(*) FROM rounds"
            ).fetchone()[0]
        finally:
            conn.close()
        assert n_rounds == 2

    def test_retry_skipped_when_in_backoff(self, project):
        """If backoff hasn't elapsed, the shadow-write helper does
        NOT attempt repair — sentinel stays set and the regular
        shadow-write path runs (and likely re-marks invalid)."""
        _seed_clean_cycle(project)
        dualwrite.mark_db_invalid(project, reason="test")
        # Manually advance backoff to the future
        flag = project / ".tagteam" / "DB_INVALID"
        info = json.loads(flag.read_text())
        info["next_attempt_at"] = (
            datetime.now(timezone.utc) + timedelta(minutes=10)
        ).isoformat()
        flag.write_text(json.dumps(info))

        # Should not crash; sentinel stays set since repair is gated.
        cycle.add_round("p", "plan", "reviewer", "REQUEST_CHANGES",
                        1, "fix", str(project))
        assert dualwrite.is_db_invalid(project) is True

    def test_retry_amend_path(self, project):
        """The AMEND shadow-write helper has its own retry hook."""
        _seed_clean_cycle(project)
        dualwrite.mark_db_invalid(project, reason="simulated")

        cycle.add_round("p", "plan", "lead", "AMEND",
                        1, "amendment", str(project))

        assert dualwrite.is_db_invalid(project) is False
        conn = db.connect(project_dir=str(project))
        try:
            actions = [
                r["action"]
                for r in db.get_rounds(conn, "p", "plan")
            ]
        finally:
            conn.close()
        assert "AMEND" in actions
