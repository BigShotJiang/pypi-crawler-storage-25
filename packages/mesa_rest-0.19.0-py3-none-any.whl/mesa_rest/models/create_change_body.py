from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.create_change_body_author import CreateChangeBodyAuthor
  from ..models.create_change_body_committer import CreateChangeBodyCommitter
  from ..models.create_change_body_files_item_type_0 import CreateChangeBodyFilesItemType0
  from ..models.create_change_body_files_item_type_1 import CreateChangeBodyFilesItemType1





T = TypeVar("T", bound="CreateChangeBody")



@_attrs_define
class CreateChangeBody:
    """ 
        Attributes:
            base_change_id (str): Change to create the new change on top of. Use the virtual root change id
                (zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz) to create the first change in an empty repository.
            message (str | Unset):
            author (CreateChangeBodyAuthor | Unset):
            committer (CreateChangeBodyCommitter | Unset):
            files (list[CreateChangeBodyFilesItemType0 | CreateChangeBodyFilesItemType1] | Unset):
     """

    base_change_id: str
    message: str | Unset = UNSET
    author: CreateChangeBodyAuthor | Unset = UNSET
    committer: CreateChangeBodyCommitter | Unset = UNSET
    files: list[CreateChangeBodyFilesItemType0 | CreateChangeBodyFilesItemType1] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.create_change_body_committer import CreateChangeBodyCommitter
        from ..models.create_change_body_author import CreateChangeBodyAuthor
        from ..models.create_change_body_files_item_type_1 import CreateChangeBodyFilesItemType1
        from ..models.create_change_body_files_item_type_0 import CreateChangeBodyFilesItemType0
        base_change_id = self.base_change_id

        message = self.message

        author: dict[str, Any] | Unset = UNSET
        if not isinstance(self.author, Unset):
            author = self.author.to_dict()

        committer: dict[str, Any] | Unset = UNSET
        if not isinstance(self.committer, Unset):
            committer = self.committer.to_dict()

        files: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.files, Unset):
            files = []
            for files_item_data in self.files:
                files_item: dict[str, Any]
                if isinstance(files_item_data, CreateChangeBodyFilesItemType0):
                    files_item = files_item_data.to_dict()
                else:
                    files_item = files_item_data.to_dict()

                files.append(files_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "base_change_id": base_change_id,
        })
        if message is not UNSET:
            field_dict["message"] = message
        if author is not UNSET:
            field_dict["author"] = author
        if committer is not UNSET:
            field_dict["committer"] = committer
        if files is not UNSET:
            field_dict["files"] = files

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_change_body_author import CreateChangeBodyAuthor
        from ..models.create_change_body_committer import CreateChangeBodyCommitter
        from ..models.create_change_body_files_item_type_0 import CreateChangeBodyFilesItemType0
        from ..models.create_change_body_files_item_type_1 import CreateChangeBodyFilesItemType1
        d = dict(src_dict)
        base_change_id = d.pop("base_change_id")

        message = d.pop("message", UNSET)

        _author = d.pop("author", UNSET)
        author: CreateChangeBodyAuthor | Unset
        if isinstance(_author,  Unset):
            author = UNSET
        else:
            author = CreateChangeBodyAuthor.from_dict(_author)




        _committer = d.pop("committer", UNSET)
        committer: CreateChangeBodyCommitter | Unset
        if isinstance(_committer,  Unset):
            committer = UNSET
        else:
            committer = CreateChangeBodyCommitter.from_dict(_committer)




        _files = d.pop("files", UNSET)
        files: list[CreateChangeBodyFilesItemType0 | CreateChangeBodyFilesItemType1] | Unset = UNSET
        if _files is not UNSET:
            files = []
            for files_item_data in _files:
                def _parse_files_item(data: object) -> CreateChangeBodyFilesItemType0 | CreateChangeBodyFilesItemType1:
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        files_item_type_0 = CreateChangeBodyFilesItemType0.from_dict(data)



                        return files_item_type_0
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    if not isinstance(data, dict):
                        raise TypeError()
                    files_item_type_1 = CreateChangeBodyFilesItemType1.from_dict(data)



                    return files_item_type_1

                files_item = _parse_files_item(files_item_data)

                files.append(files_item)


        create_change_body = cls(
            base_change_id=base_change_id,
            message=message,
            author=author,
            committer=committer,
            files=files,
        )


        create_change_body.additional_properties = d
        return create_change_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
