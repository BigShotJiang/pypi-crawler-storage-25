from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import HTMLResponse, JSONResponse
from starlette.routing import Route

HTML = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>i4z-terminal-mcp</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@xterm/xterm@5/css/xterm.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{background:#0d1117;color:#c9d1d9;font-family:monospace;display:flex;height:100vh}
#sidebar{width:240px;background:#161b22;border-right:1px solid #30363d;display:flex;flex-direction:column;flex-shrink:0}
#sidebar h2{padding:16px;font-size:14px;border-bottom:1px solid #30363d;color:#58a6ff}
#terminal-list{flex:1;overflow-y:auto;padding:8px}
.term-item{padding:10px 12px;cursor:pointer;border-radius:6px;font-size:12px;margin:2px 0;display:flex;align-items:center;gap:8px}
.term-item:hover{background:#1f2937}
.term-item.active{background:#1f6feb}
.status-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}
.status-dot.on{background:#3fb950}
.status-dot.off{background:#f85149}
#db-info{font-size:11px;color:#484f58;padding:4px 12px;border-top:1px solid #161b22}
#main{flex:1;display:flex;flex-direction:column;min-width:0}
#toolbar{padding:6px 16px;border-bottom:1px solid #30363d;font-size:12px;display:flex;gap:20px;flex-shrink:0;align-items:center}
#toolbar span{color:#8b949e}
#toolbar strong{color:#c9d1d9}
#content{flex:1;display:flex;flex-direction:column;overflow:hidden}
#xterm-panel{flex:1;min-height:0;position:relative}
#xterm-container{position:absolute;inset:0;padding:4px}
#grip{cursor:row-resize;height:4px;background:#21262d;border-top:1px solid #30363d;border-bottom:1px solid #30363d;flex-shrink:0}
#grip:hover{background:#30363d}
#history-panel{overflow-y:auto;flex-shrink:0;border-top:1px solid #30363d;height:180px}
#history-panel h3{position:sticky;top:0;background:#0d1117;padding:6px 12px;font-size:11px;color:#8b949e;border-bottom:1px solid #21262d;margin:0}
.h-entry{padding:3px 12px;font-size:11px;border-bottom:1px solid #161b22;white-space:pre-wrap;word-break:break-all;display:flex;gap:8px}
.h-entry .hts{color:#484f58;flex-shrink:0;font-size:10px;min-width:65px}
.h-entry.in .htxt{color:#58a6ff}
.h-entry.out .htxt{color:#8b949e}
#empty{display:flex;align-items:center;justify-content:center;height:100%;color:#484f58;font-size:14px}
</style>
</head>
<body>
<div id="sidebar">
<h2>Terminals</h2>
<div id="terminal-list"><div style="color:#484f58;padding:12px;font-size:12px">No terminals</div></div>
<div id="db-info"></div>
</div>
<div id="main">
<div id="toolbar">
<span>ID: <strong id="t-id">-</strong></span>
<span>PID: <strong id="t-pid">-</strong></span>
<span>Alive: <strong id="t-alive">-</strong></span>
<span>CWD: <strong id="t-cwd">-</strong></span>
</div>
<div id="content">
<div id="xterm-panel">
<div id="xterm-container"><div id="empty">Select a terminal from the sidebar</div></div>
</div>
<div id="grip"></div>
<div id="history-panel">
<h3>History</h3>
<div id="history-list"></div>
</div>
</div>
</div>
<script type="importmap">
{"imports":{"@xterm/xterm":"https://cdn.jsdelivr.net/npm/@xterm/xterm@5/lib/xterm.js"}}
</script>
<script type="module">
import {Terminal} from '@xterm/xterm';

const $=id=>document.getElementById(id);
let activeId=null,term=null,termTimer=null,histTimer=null,histCursor=0,termCursor=0;

async function refreshList(){
  const r=await fetch('/api/terminals'),data=await r.json();
  $('db-info').textContent=data.length?data.length+' terminal(s)':'';
  if(!data.length){$('terminal-list').innerHTML='<div style="color:#484f58;padding:12px;font-size:12px">No terminals</div>';return}
  $('terminal-list').innerHTML=data.map(t=>`<div class="term-item${t.id===activeId?' active':''}" data-id="${t.id}" data-alive="${t.alive}">
    <span class="status-dot ${t.alive?'on':'off'}"></span>${t.id}
  </div>`).join('');
  $('terminal-list').querySelectorAll('.term-item').forEach(e=>e.onclick=()=>select(e.dataset.id));
}

async function select(id){
  if(termTimer)clearInterval(termTimer);
  if(histTimer)clearInterval(histTimer);
  if(term){term.dispose();term=null}
  activeId=id; histCursor=0; termCursor=0;
  $('empty').style.display='none';
  $('xterm-container').innerHTML='';
  $('history-list').innerHTML='';
  refreshList();
  loadStatus();

  term=new Terminal({cursorBlink:true,fontSize:13,rows:24,theme:{background:'#0d1117',foreground:'#c9d1d9',cursor:'#c9d1d9'}});
  term.open($('xterm-container'));
  const ro=new ResizeObserver(()=>{
    const h=$('xterm-container').clientHeight;
    const w=$('xterm-container').clientWidth;
    const cellH=Math.max(1,(term._core._renderService?.dimensions?.css?.cellHeight)||16);
    const cellW=Math.max(1,(term._core._renderService?.dimensions?.css?.cellWidth)||8.5);
    term.resize(Math.max(3,Math.floor(w/cellW)),Math.max(3,Math.floor(h/cellH)));
  });
  ro.observe($('xterm-container'));

  term.onData(data=>{
    fetch('/api/send/'+activeId,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:data})});
  });

  termTimer=setInterval(pollOutput,150);
  pollOutput();
  histTimer=setInterval(pollHistory,1000);
  pollHistory();
  loadStatus();
}

async function pollOutput(){
  if(!activeId||!term)return;
  try{
    const r=await fetch('/api/output/'+activeId+'?since='+termCursor),d=await r.json();
    if(d.output){term.write(d.output);termCursor=d.cursor}
  }catch(e){}
}
async function pollHistory(){
  if(!activeId)return;
  try{
    const r=await fetch('/api/history/'+activeId+'?since='+histCursor),d=await r.json();
    for(const e of d.events){
      const div=document.createElement('div');
      div.className='h-entry '+e.type;
      div.innerHTML='<span class="hts">'+e.timestamp.slice(11,19)+'</span><span class="htxt">'+esc(e.text)+'</span>';
      $('history-list').appendChild(div);
    }
    if(d.events.length){histCursor=d.cursor;$('history-panel').scrollTop=$('history-panel').scrollHeight}
  }catch(e){}
}
async function loadStatus(){
  if(!activeId)return;
  try{
    const r=await fetch('/api/status/'+activeId),d=await r.json();
    $('t-id').textContent=d.id||'-';
    $('t-pid').textContent=d.pid||'-';
    $('t-alive').textContent=d.alive?'yes':'no';
    $('t-cwd').textContent=d.cwd||'-';
  }catch(e){}
}
function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}

let dragging=false;
$('grip').onmousedown=e=>{dragging=true;e.preventDefault()};
document.onmousemove=e=>{
  if(!dragging)return;
  const main=$('main'),rect=main.getBoundingClientRect();
  const total=rect.height-32;
  const pct=Math.max(0.15,Math.min(0.85,(total-(e.clientY-rect.top))/total));
  $('xterm-panel').style.flex=pct;
  $('history-panel').style.flex=(1-pct);
};
document.onmouseup=()=>{dragging=false};

setInterval(refreshList,2000);
refreshList();
</script>
</body>
</html>"""


def create_app(manager):
    from terminal.log import log

    async def index(request):
        log("GET /", "WEB")
        return HTMLResponse(HTML)

    async def api_terminals(request):
        log("GET /api/terminals", "WEB")
        return JSONResponse(manager.list_all())

    async def api_status(request):
        terminal_id = request.path_params["terminal_id"]
        try:
            return JSONResponse(manager.status(terminal_id))
        except KeyError:
            return JSONResponse({"error": "not found"}, status_code=404)

    async def api_output(request):
        terminal_id = request.path_params["terminal_id"]
        since = int(request.query_params.get("since", 0))
        try:
            return JSONResponse(manager.read(terminal_id, since))
        except KeyError:
            return JSONResponse({"output": "", "cursor": since}, status_code=404)

    async def api_history(request):
        terminal_id = request.path_params["terminal_id"]
        since = int(request.query_params.get("since", 0))
        try:
            data = manager.get_history(terminal_id, since)
            log(f"GET /api/history/{terminal_id}?since={since} -> {len(data['events'])} events", "WEB")
            return JSONResponse(data)
        except KeyError:
            log(f"GET /api/history/{terminal_id} -> 404", "WEB")
            return JSONResponse({"events": [], "cursor": since}, status_code=404)

    async def api_send(request: Request):
        terminal_id = request.path_params["terminal_id"]
        body = await request.json()
        text = body.get("text", "")
        if not text:
            return JSONResponse({"error": "missing text"}, status_code=400)
        try:
            manager.send(terminal_id, text)
            log(f"POST /api/send/{terminal_id} '{text.strip()[:60]}'", "WEB")
            return JSONResponse({"status": "sent"})
        except KeyError:
            return JSONResponse({"error": "terminal not found"}, status_code=404)
        except RuntimeError as e:
            return JSONResponse({"error": str(e)}, status_code=400)

    return Starlette(routes=[
        Route("/", index),
        Route("/api/terminals", api_terminals),
        Route("/api/status/{terminal_id}", api_status),
        Route("/api/output/{terminal_id}", api_output),
        Route("/api/history/{terminal_id}", api_history),
        Route("/api/send/{terminal_id}", api_send, methods=["POST"]),
    ])
