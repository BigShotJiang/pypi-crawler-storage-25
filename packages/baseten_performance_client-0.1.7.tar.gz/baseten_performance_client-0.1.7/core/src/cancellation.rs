use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use tokio::task::JoinSet;

/// A cancellation token that can be used to cancel async operations.
///
/// Clone this token and pass it to functions that should be cancellable.
/// When `cancel()` is called, all operations checking this token will be cancelled.
#[derive(Debug, Clone, Default)]
pub struct CancellationToken {
    cancelled: Arc<AtomicBool>,
    cancel_on_drop: bool,
}

impl CancellationToken {
    pub fn new(cancel_on_drop: bool) -> Self {
        Self {
            cancelled: Arc::new(AtomicBool::new(false)),
            cancel_on_drop,
        }
    }

    /// Cancel all operations using this token
    pub fn cancel(&self) {
        self.cancelled.store(true, Ordering::SeqCst);
    }

    /// Check if cancellation has been requested
    pub fn is_cancelled(&self) -> bool {
        self.cancelled.load(Ordering::SeqCst)
    }
}

impl Drop for CancellationToken {
    fn drop(&mut self) {
        if self.cancel_on_drop {
            // Automatically cancel when dropped for RAII behavior
            // This ensures that when the axum handle is revoked, the proxy stops proxying
            self.cancel();
        }
    }
}

/// RAII guard that wraps a JoinSet and aborts all tasks when dropped.
///
/// This ensures that when a future is cancelled (e.g., via tokio::select! or Drop),
/// all spawned tasks are automatically aborted, preventing resource leaks.
pub(crate) struct JoinSetGuard<T: 'static> {
    join_set: JoinSet<T>,
    cancel_token: Option<CancellationToken>,
}

impl<T: 'static> JoinSetGuard<T> {
    pub(crate) fn new() -> Self {
        Self {
            join_set: JoinSet::new(),
            cancel_token: None,
        }
    }

    pub(crate) fn with_cancel_token(cancel_token: CancellationToken) -> Self {
        Self {
            join_set: JoinSet::new(),
            cancel_token: Some(cancel_token),
        }
    }

    pub(crate) fn spawn<F>(&mut self, task: F)
    where
        F: std::future::Future<Output = T> + Send + 'static,
        T: Send,
    {
        self.join_set.spawn(task);
    }

    pub async fn join_next(&mut self) -> Option<Result<T, tokio::task::JoinError>> {
        self.join_set.join_next().await
    }

    pub(crate) fn abort_all(&mut self) {
        if let Some(ref token) = self.cancel_token {
            token.cancel();
        }
        self.join_set.abort_all();
    }
}

impl<T: 'static> Default for JoinSetGuard<T> {
    fn default() -> Self {
        Self::new()
    }
}

impl<T: 'static> Drop for JoinSetGuard<T> {
    fn drop(&mut self) {
        self.abort_all();
    }
}
