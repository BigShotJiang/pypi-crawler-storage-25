"""Tests for SBOM output formatters."""

from __future__ import annotations

import json

import pytest
from ai_finder_scanner.models import (
    Finding,
    FindingType,
    ManifestDep,
    ScanResult,
    SDKUsage,
)
from ai_finder_scanner.output.cyclonedx import CycloneDXFormatter
from ai_finder_scanner.output.json_output import JSONFormatter
from ai_finder_scanner.output.spdx import SPDX23Formatter


@pytest.fixture
def sample_result() -> ScanResult:
    """Create a sample scan result for testing."""
    findings = [
        Finding(
            type=FindingType.SDK_USAGE,
            file_path="main.py",
            line=1,
            confidence=1.0,
            sdk_usage=SDKUsage(
                sdk="openai",
                import_statement="import openai",
                version="1.0.0",
            ),
        ),
        Finding(
            type=FindingType.MANIFEST_DEP,
            file_path="requirements.txt",
            line=1,
            confidence=1.0,
            manifest_dep=ManifestDep(
                name="langchain",
                version=">=0.1.0",
                manifest_file="requirements.txt",
            ),
        ),
    ]
    return ScanResult(
        root_path="/test/project",
        findings=findings,
        files_scanned=10,
        duration_ms=100,
    )


class TestJSONFormatter:
    def test_format_returns_valid_json(self, sample_result: ScanResult) -> None:
        formatter = JSONFormatter()
        output = formatter.format(sample_result)

        # Should be valid JSON
        data = json.loads(output)
        assert isinstance(data, dict)

    def test_format_includes_metadata(self, sample_result: ScanResult) -> None:
        formatter = JSONFormatter()
        output = formatter.format(sample_result)
        data = json.loads(output)

        assert data["root_path"] == "/test/project"
        assert data["files_scanned"] == 10
        assert data["duration_ms"] == 100

    def test_format_includes_findings(self, sample_result: ScanResult) -> None:
        formatter = JSONFormatter()
        output = formatter.format(sample_result)
        data = json.loads(output)

        assert len(data["findings"]) == 2
        assert data["findings"][0]["type"] == "sdk_usage"
        assert data["findings"][0]["file_path"] == "main.py"

    def test_format_empty_result(self) -> None:
        result = ScanResult(
            root_path="/empty",
            findings=[],
            files_scanned=0,
            duration_ms=0,
        )
        formatter = JSONFormatter()
        output = formatter.format(result)
        data = json.loads(output)

        assert data["findings"] == []

    def test_format_indented(self, sample_result: ScanResult) -> None:
        formatter = JSONFormatter(indent=2)
        output = formatter.format(sample_result)

        # Should have newlines for indentation
        assert "\n" in output


@pytest.fixture
def model_file_result() -> ScanResult:
    """Create a scan result with a model file finding."""
    from ai_finder_scanner.models import ModelInfo

    findings = [
        Finding(
            type=FindingType.MODEL_FILE,
            file_path="models/llama-3-8b.gguf",
            confidence=1.0,
            model_info=ModelInfo(
                format="gguf",
                architecture="llama",
                parameter_count=8000000000,
                quantization="Q4_K_M",
            ),
        ),
    ]
    return ScanResult(
        root_path="/test/project",
        findings=findings,
        files_scanned=5,
        duration_ms=50,
    )


class TestCycloneDXFormatter:
    def test_format_returns_valid_json(self, sample_result: ScanResult) -> None:
        formatter = CycloneDXFormatter()
        output = formatter.format(sample_result)

        data = json.loads(output)
        assert isinstance(data, dict)

    def test_format_has_cyclonedx_structure(self, sample_result: ScanResult) -> None:
        formatter = CycloneDXFormatter()
        output = formatter.format(sample_result)
        data = json.loads(output)

        # CycloneDX required fields
        assert "bomFormat" in data
        assert data["bomFormat"] == "CycloneDX"
        assert "specVersion" in data
        assert "components" in data

    def test_format_includes_components(self, sample_result: ScanResult) -> None:
        formatter = CycloneDXFormatter()
        output = formatter.format(sample_result)
        data = json.loads(output)

        # Should have components from findings
        assert len(data["components"]) >= 1

        # Check component structure
        component = data["components"][0]
        assert "type" in component
        assert "name" in component

    def test_format_sdk_as_library(self, sample_result: ScanResult) -> None:
        formatter = CycloneDXFormatter()
        output = formatter.format(sample_result)
        data = json.loads(output)

        # Find openai component
        openai_comp = next((c for c in data["components"] if c["name"] == "openai"), None)
        assert openai_comp is not None
        assert openai_comp["type"] == "library"

    def test_format_includes_purl(self, sample_result: ScanResult) -> None:
        formatter = CycloneDXFormatter()
        output = formatter.format(sample_result)
        data = json.loads(output)

        # Check that at least one component has a purl
        components_with_purl = [c for c in data["components"] if "purl" in c]
        assert len(components_with_purl) >= 1

    def test_format_purl_scoped_npm_package(self) -> None:
        """Test that scoped npm packages get properly encoded PURLs."""
        findings = [
            Finding(
                type=FindingType.MANIFEST_DEP,
                file_path="package.json",
                line=5,
                confidence=1.0,
                manifest_dep=ManifestDep(
                    name="@anthropic-ai/sdk",
                    version="^1.0.0",
                    manifest_file="package.json",
                ),
            ),
        ]
        result = ScanResult(
            root_path="/test",
            findings=findings,
            files_scanned=1,
            duration_ms=10,
        )
        formatter = CycloneDXFormatter()
        output = formatter.format(result)
        data = json.loads(output)

        # Find the scoped package
        pkg = next((c for c in data["components"] if "anthropic" in c["name"]), None)
        assert pkg is not None
        # PURL should have namespace/name format: pkg:npm/namespace/name@version
        # The leading @ from @anthropic-ai/sdk is removed and split into namespace/name
        assert pkg["purl"] == "pkg:npm/anthropic-ai/sdk@1.0.0"
        # Verify the PURL starts correctly (no @scope/ pattern)
        assert pkg["purl"].startswith("pkg:npm/anthropic-ai/")

    def test_format_spec_version_1_6(self, sample_result: ScanResult) -> None:
        formatter = CycloneDXFormatter()
        output = formatter.format(sample_result)
        data = json.loads(output)

        assert data["specVersion"] == "1.6"

    def test_format_empty_result(self) -> None:
        result = ScanResult(
            root_path="/empty",
            findings=[],
            files_scanned=0,
            duration_ms=0,
        )
        formatter = CycloneDXFormatter()
        output = formatter.format(result)
        data = json.loads(output)

        assert data["components"] == []

    def test_format_model_has_learning_type(self, model_file_result: ScanResult) -> None:
        formatter = CycloneDXFormatter()
        output = formatter.format(model_file_result)
        data = json.loads(output)

        model_comp = next(
            (c for c in data["components"] if c["type"] == "machine-learning-model"),
            None,
        )
        assert model_comp is not None
        assert "modelCard" in model_comp
        assert "modelParameters" in model_comp["modelCard"]
        assert model_comp["modelCard"]["modelParameters"].get("learningType") == "supervised"

    def test_format_model_has_inputs_outputs(self, model_file_result: ScanResult) -> None:
        formatter = CycloneDXFormatter()
        output = formatter.format(model_file_result)
        data = json.loads(output)

        model_comp = next(
            (c for c in data["components"] if c["type"] == "machine-learning-model"),
            None,
        )
        assert model_comp is not None
        model_params = model_comp["modelCard"]["modelParameters"]

        # LLMs should have string inputs/outputs
        assert "inputs" in model_params
        assert "outputs" in model_params
        assert model_params["inputs"] == [{"format": "string"}]
        assert model_params["outputs"] == [{"format": "string"}]


class TestSPDX23Formatter:
    def test_format_returns_valid_json(self, sample_result: ScanResult) -> None:
        formatter = SPDX23Formatter()
        output = formatter.format(sample_result)

        data = json.loads(output)
        assert isinstance(data, dict)

    def test_format_has_spdx_structure(self, sample_result: ScanResult) -> None:
        formatter = SPDX23Formatter()
        output = formatter.format(sample_result)
        data = json.loads(output)

        # SPDX required fields
        assert "spdxVersion" in data
        assert data["spdxVersion"] == "SPDX-2.3"
        assert "SPDXID" in data
        assert "packages" in data
        assert "relationships" in data

    def test_format_includes_packages(self, sample_result: ScanResult) -> None:
        formatter = SPDX23Formatter()
        output = formatter.format(sample_result)
        data = json.loads(output)

        # Should have packages from findings
        assert len(data["packages"]) >= 1

        # Check package structure
        package = data["packages"][0]
        assert "SPDXID" in package
        assert "name" in package

    def test_format_includes_purl_in_external_refs(self, sample_result: ScanResult) -> None:
        formatter = SPDX23Formatter()
        output = formatter.format(sample_result)
        data = json.loads(output)

        # Check that packages have external refs with PURLs
        packages_with_purl = [
            p
            for p in data["packages"]
            if "externalRefs" in p
            and any(r.get("referenceType") == "purl" for r in p["externalRefs"])
        ]
        assert len(packages_with_purl) >= 1

    def test_format_empty_result(self) -> None:
        result = ScanResult(
            root_path="/empty",
            findings=[],
            files_scanned=0,
            duration_ms=0,
        )
        formatter = SPDX23Formatter()
        output = formatter.format(result)
        data = json.loads(output)

        assert data["packages"] == []
        assert data["relationships"] == []


class TestGetFormatter:
    def test_get_formatter_cyclonedx(self) -> None:
        from ai_finder_scanner.output import get_formatter

        formatter = get_formatter("cyclonedx")
        assert isinstance(formatter, CycloneDXFormatter)

    def test_get_formatter_json(self) -> None:
        from ai_finder_scanner.output import get_formatter

        formatter = get_formatter("json")
        assert isinstance(formatter, JSONFormatter)

    def test_get_formatter_spdx_23(self) -> None:
        from ai_finder_scanner.output import get_formatter

        formatter = get_formatter("spdx", spdx_version="2.3")
        assert isinstance(formatter, SPDX23Formatter)

    def test_get_formatter_spdx_30(self) -> None:
        from ai_finder_scanner.output import get_formatter
        from ai_finder_scanner.output.spdx3 import SPDX3Formatter

        formatter = get_formatter("spdx", spdx_version="3.0")
        assert isinstance(formatter, SPDX3Formatter)

    def test_get_formatter_spdx_requires_version(self) -> None:
        from ai_finder_scanner.output import get_formatter

        with pytest.raises(ValueError, match="requires --spdx-version"):
            get_formatter("spdx")

    def test_get_formatter_unknown_format(self) -> None:
        from ai_finder_scanner.output import get_formatter

        with pytest.raises(ValueError, match="Unknown format"):
            get_formatter("unknown")
