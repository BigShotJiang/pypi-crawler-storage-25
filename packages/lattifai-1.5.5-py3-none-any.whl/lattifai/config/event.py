"""Audio Event Detection configuration for LattifAI."""

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Dict, List, Literal, Optional

from ..utils import _select_device

if TYPE_CHECKING:
    from ..client import SyncAPIClient


@dataclass
class EventConfig:
    """
    Audio Event Detection configuration.

    Settings for detecting audio events (Speech, Music, Male, Female...) in audio files using the AED model.

    Event Matching:
        When event_matching is enabled, the AED system will:
        1. Parse [Event] markers from input captions (e.g., [Music], [Applause])
        2. Match caption events to AED labels using semantic matching
        3. Force detection of matched labels even if not in top_k
        4. Update caption timestamps based on AED detection results

        Event matching logic is implemented in lattifai_core.event.EventMatcher.
    """

    _toml_section = "event"

    enabled: bool = False
    """Enable audio event detection."""

    device: Literal["cpu", "cuda", "mps", "auto"] = "auto"
    """Computation device for Event Detection models."""

    vad_chunk_size: float = 30.0
    """VAD chunk size in seconds for speech segmentation."""

    vad_max_gap: float = 2.0
    """Maximum gap in seconds between VAD segments to merge."""

    fast_mode: bool = True
    """Enable fast mode (only detect top_k classes, skip others)."""

    model_path: str = ""
    """Path to pretrained model. If empty, uses default bundled model."""

    event_matching: bool = True
    """Whether update events in the alignment"""

    extra_events: List[str] = field(default_factory=list)
    """Additional event types to always detect, even if not in top_k.
    Example: ["Applause", "Laughter", "Music"]
    """

    event_aliases: Dict[str, List[str]] = field(default_factory=dict)
    """Custom aliases mapping [Event] markers to AED labels.

    Core AED labels (14 types):
        [Applause], [Baby cry], [Battle cry], [Bellow], [Children shouting],
        [Laughter], [Music], [Shout], [Singing], [Sound effect],
        [Speech], [Whoop], [Yell]

    Custom aliases extend built-ins (not replace):
        {"[Audience reaction]": ["[Applause]", "[Cheering]"]}
    """

    time_tolerance: float = 20.0
    """Max time (seconds) non-Speech events can extend beyond supervision boundaries."""

    update_timestamps: bool = True
    """Whether to update caption event timestamps based on AED detections."""

    duplicate_strategy: Literal["keep_all", "merge_first", "split"] = "merge_first"
    """Strategy for handling multiple [Event] markers mapped to same AED interval.
    - keep_all: Update all events to same time range (may cause overlapping)
    - merge_first: Keep only first event per interval, skip duplicates
    - split: Split interval at speech boundaries (not yet implemented)
    """

    client_wrapper: Optional["SyncAPIClient"] = field(default=None, repr=False)
    """Reference to the SyncAPIClient instance. Auto-set during client initialization."""

    def __post_init__(self):
        """Validate and auto-populate configuration after initialization."""
        # Validate device
        if self.device not in ("cpu", "cuda", "mps", "auto") and not self.device.startswith("cuda:"):
            raise ValueError(f"device must be one of ('cpu', 'cuda', 'mps', 'auto'), got '{self.device}'")

        if self.device == "auto":
            self.device = _select_device(self.device)

        # Validate vad_chunk_size
        if self.vad_chunk_size < 0:
            raise ValueError("vad_chunk_size must be non-negative")

        # Validate vad_max_gap
        if self.vad_max_gap < 0:
            raise ValueError("vad_max_gap must be non-negative")

        # Validate time_tolerance
        if self.time_tolerance < 0:
            raise ValueError("time_tolerance must be non-negative")
