"""Caption CLI entry point with nemo_run."""

import re
from typing import Annotated, List, Optional

import nemo_run as run

from lattifai.caption.config import ASSConfig, LRCConfig, RenderConfig, StandardizationConfig
from lattifai.caption.formats.nle.fcpxml import FCPXMLConfig
from lattifai.caption.formats.nle.premiere import PremiereXMLConfig
from lattifai.caption.formats.ttml import TTMLConfig
from lattifai.cli.entrypoint import LattifAIEntrypoint
from lattifai.types import Pathlike
from lattifai.utils import safe_print


def align_timestamps_from_ref(
    supervisions: List,
    ref_supervisions: List,
) -> List:
    """Align timestamps of supervisions using a reference caption as timing source.

    Matches each input supervision to reference supervisions by text similarity,
    using both word-level keys (Latin scripts) and character-level keys (CJK).
    Searches sequentially through the reference stream to handle repeated text.
    Preserves original text and speaker labels from input; only timestamps change.

    Args:
        supervisions: Input supervisions (good text/speaker, coarse timestamps).
        ref_supervisions: Reference supervisions (accurate timestamps).

    Returns:
        Updated supervisions with reference-aligned timestamps.
    """
    if not supervisions or not ref_supervisions:
        return supervisions

    def _normalize(text: str) -> str:
        text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)  # strip md links
        text = re.sub(r"[^\w\s]", "", text.lower())
        return " ".join(text.split())

    # Build normalized text stream from reference, skipping empty entries
    ref_entries = []
    for s in ref_supervisions:
        norm = _normalize(s.text)
        if norm:
            ref_entries.append((s.start, s.start + s.duration, norm))

    if not ref_entries:
        return supervisions

    ref_stream = " ".join(norm for _, _, norm in ref_entries)
    ref_end_time = max(end for _, end, _ in ref_entries if end > 0) if ref_entries else 0.0

    # Build character-offset to timestamp mapping
    char_offsets = []
    pos = 0
    for start, _end, norm in ref_entries:
        char_offsets.append((pos, start))
        pos += len(norm) + 1  # +1 for space separator

    def _lookup_timestamp(char_idx: int) -> float:
        """Binary search for the timestamp at a character position."""
        lo, hi = 0, len(char_offsets) - 1
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if char_offsets[mid][0] <= char_idx:
                lo = mid
            else:
                hi = mid - 1
        return char_offsets[lo][1]

    def _make_keys(norm_text: str) -> List[str]:
        """Generate match keys of decreasing specificity.

        Word-based keys work well for Latin scripts (space-separated words).
        Character-based keys handle CJK and serve as fallback for Latin.
        """
        keys = []
        words = norm_text.split()

        # Word-based keys (Latin scripts)
        for n in [8, 5, 3]:
            if len(words) >= n:
                keys.append(" ".join(words[:n]))

        # Character-based keys (CJK + universal fallback)
        for n in [20, 12, 6]:
            if len(norm_text) >= n:
                key = norm_text[:n]
                if key not in keys:
                    keys.append(key)

        return keys

    def _find_time(text: str, search_from: int) -> tuple:
        """Find timestamp for text, searching forward from given position.

        Returns (timestamp, matched_char_position) or (None, search_from).
        """
        norm = _normalize(text)
        if not norm:
            return None, search_from

        keys = _make_keys(norm)
        for key in keys:
            idx = ref_stream.find(key, search_from)
            if idx >= 0:
                return _lookup_timestamp(idx), idx

        return None, search_from

    # Align each supervision with sequential search
    matched = 0
    prev_start = 0.0
    search_pos = 0
    results = []
    for sup in supervisions:
        found, match_pos = _find_time(sup.text, search_pos)
        if found is not None:
            sup.start = found
            search_pos = match_pos + 1  # advance past this match
            matched += 1
        else:
            # Fallback: keep original timestamp but ensure monotonicity
            sup.start = max(sup.start, prev_start)
        prev_start = sup.start
        results.append(sup)

    # Recalculate durations from next segment's start
    for i in range(len(results) - 1):
        results[i].duration = max(results[i + 1].start - results[i].start, 0.0)
    if results:
        last_dur = ref_end_time - results[-1].start
        results[-1].duration = max(last_dur, 0.1) if last_dur > 0 else max(results[-1].duration, 0.1)

    safe_print(f"   Aligned {matched}/{len(results)} segments from reference")
    return results


@run.cli.entrypoint(name="convert", namespace="caption", entrypoint_cls=LattifAIEntrypoint)
def convert(
    input_path: Pathlike,
    output_path: Pathlike,
    reference: Optional[Pathlike] = None,
    input_format: Optional[str] = None,
    normalize_text: bool = False,
    render: Annotated[Optional[RenderConfig], run.Config[RenderConfig]] = None,
    standardization: Annotated[Optional[StandardizationConfig], run.Config[StandardizationConfig]] = None,
    ass: Annotated[Optional[ASSConfig], run.Config[ASSConfig]] = None,
    lrc: Annotated[Optional[LRCConfig], run.Config[LRCConfig]] = None,
    ttml: Annotated[Optional[TTMLConfig], run.Config[TTMLConfig]] = None,
    fcpxml: Annotated[Optional[FCPXMLConfig], run.Config[FCPXMLConfig]] = None,
    premiere: Annotated[Optional[PremiereXMLConfig], run.Config[PremiereXMLConfig]] = None,
) -> Pathlike:
    """
    Convert caption file to another format.

    Shortcut: invoking ``laicap-convert`` is equivalent to running ``lai caption convert``.

    Args:
        input_path: Path to input caption file (supports SRT, VTT, JSON, TextGrid formats)
        output_path: Path to output caption file (format determined by file extension)
        reference: Optional reference caption for timestamp alignment
        input_format: Explicitly specify input format (e.g., 'markdown', 'srt')
        normalize_text: Clean HTML entities and normalize whitespace
        render: Render configuration (nemo_run Config).
            render.include_speaker_in_text, render.word_level,
            render.translation_first
        ass: ASS format configuration (nemo_run Config).
            ass.font_name, ass.font_size, ass.background_color,
            ass.speaker_color, ass.primary_color, ass.outline_color,
            ass.karaoke_effect (sweep/instant/outline),
            ass.karaoke_color_scheme (overrides ASS colors),
            ass.kinetic_style (word-level motion preset: bounce/pop/shake/
            pulse/swing/fade/zoom/rise/typewriter/blur_in/glow/neon/wave/
            flicker/stagger — composes with karaoke_effect)
        lrc: LRC lyric format configuration: timestamp precision, metadata.
        ttml: TTML/IMSC1/EBU-TT-D format configuration: style, region, profile.
        fcpxml: Final Cut Pro XML format configuration: fps, roles, styles.
        premiere: Premiere Pro XML format configuration: fps, resolution, tracks.

    Examples:
        # Basic format conversion
        lai caption convert input.srt output.vtt

        # Custom font, background box, speaker coloring, word-level cues
        lai caption convert input.json output.ass \\
            ass.font_name="PingFang SC" ass.font_size=24 \\
            ass.background_color="#00000080" ass.speaker_color=auto \\
            render.word_level=true

        # Karaoke with color scheme — karaoke_effect alone is enough,
        # no need to also pass render.word_level=true
        lai caption convert input.json output.ass \\
            ass.speaker_color=auto \\
            ass.karaoke_effect=sweep ass.karaoke_color_scheme=azure-gold

        # Line-level kinetic entrance (default — whole line fades in)
        lai caption convert input.json output.ass \\
            ass.kinetic_style=fade

        # Word-level kinetic (per-word activation) — requires word_level=true,
        # CLI auto-defaults karaoke_effect=sweep so \\k tags are emitted as
        # the kinetic time carrier
        lai caption convert input.json output.ass \\
            render.word_level=true \\
            ass.kinetic_style=bounce ass.karaoke_color_scheme=neon
    """
    from pathlib import Path

    # ASS karaoke is triggered by ASSConfig.karaoke_effect alone — there is
    # no longer any coupling with RenderConfig.word_level (lattifai-captions
    # decoupled the two when word_level became tri-state).
    #
    # The only CLI helper still pulling its weight is the word-scope kinetic
    # convenience. word-scope kinetic presets (bounce, shake, glow, stagger,
    # etc.) need \k karaoke tags as per-word time carriers; without them the
    # writer either silently degrades to line-scope (dual-scope styles) or
    # crashes outright (word-only styles). When the user asks for
    # word_level=True with a word-natural kinetic preset but forgets
    # karaoke_effect, default it to "sweep". Line-natural presets
    # (fade/zoom/rise/blur_in/pop) are NOT touched — injecting karaoke would
    # add an unrequested color sweep.
    from lattifai.caption.kinetic import is_word_scope_kinetic_style
    from lattifai.data import Caption

    if (
        ass is not None
        and is_word_scope_kinetic_style(ass.kinetic_style)
        and ass.karaoke_effect is None
        and render is not None
        and render.word_level is True
    ):
        ass.karaoke_effect = "sweep"

    caption = Caption.read(input_path, normalize_text=normalize_text, format=input_format)
    # Align timestamps from reference if provided
    if reference:
        ref_caption = Caption.read(reference)
        caption.supervisions = align_timestamps_from_ref(caption.supervisions, ref_caption.supervisions)

    # Select format-specific config based on output extension
    ext = Path(output_path).suffix.lstrip(".").lower()
    format_config = {
        "ass": ass,
        "ssa": ass,
        "ttml": ttml,
        "imsc1": ttml,
        "ebu_tt_d": ttml,
        "fcpxml": fcpxml,
        "premiere_xml": premiere,
        "lrc": lrc,
    }.get(
        ext, ass
    )  # fallback to ass for backward compatibility

    caption.write(
        output_path,
        format_config=format_config,
        render=render,
        standardization=standardization,
    )

    safe_print(f"Converted {input_path} -> {output_path}")
    return output_path


@run.cli.entrypoint(name="normalize", namespace="caption", entrypoint_cls=LattifAIEntrypoint)
def normalize(
    input_path: Pathlike,
    output_path: Pathlike,
) -> Pathlike:
    """
    Normalize caption text by cleaning HTML entities and whitespace.

    This command reads a caption file and normalizes all text content by applying
    the following transformations:
    - Decode common HTML entities (&amp;, &lt;, &gt;, &quot;, &#39;, &nbsp;)
    - Remove HTML tags (e.g., <i>, <font>, <b>, <br>)
    - Collapse multiple whitespace characters into single spaces
    - Convert curly apostrophes to straight ones in contractions
    - Strip leading and trailing whitespace from each segment

    Shortcut: invoking ``laisub-normalize`` is equivalent to running ``lai caption normalize``.

    Args:
        input_path: Path to input caption file to normalize
        output_path: Path to output caption file (defaults to overwriting input file)

    Examples:
        # Normalize and save to new file (positional arguments)
        lai caption normalize input.srt output.srt

        # Normalize with format conversion
        lai caption normalize input.vtt output.srt

        # Using keyword arguments (traditional syntax)
        lai caption normalize \
            input_path=input.srt \
            output_path=output.srt
    """
    from pathlib import Path

    from lattifai.data import Caption

    input_path = Path(input_path).expanduser()
    output_path = Path(output_path).expanduser()

    caption_obj = Caption.read(input_path, normalize_text=True)
    caption_obj.write(output_path)

    if output_path == input_path:
        safe_print(f"✅ Normalized {input_path} (in-place)")
    else:
        safe_print(f"✅ Normalized {input_path} -> {output_path}")

    return output_path


@run.cli.entrypoint(name="shift", namespace="caption", entrypoint_cls=LattifAIEntrypoint)
def shift(
    input_path: Pathlike,
    output_path: Pathlike,
    seconds: float,
) -> Pathlike:
    """
    Shift caption timestamps by a specified number of seconds.

    This command reads a caption file and adjusts all timestamps by adding or
    subtracting a specified offset. Use positive values to delay captions and
    negative values to make them appear earlier.

    Shortcut: invoking ``laisub-shift`` is equivalent to running ``lai caption shift``.

    Args:
        input_path: Path to input caption file
        output_path: Path to output caption file (can be same as input for in-place modification)
        seconds: Number of seconds to shift timestamps. Positive values delay captions,
                 negative values advance them earlier.

    Examples:
        # Delay captions by 2 seconds (positional arguments)
        lai caption shift input.srt output.srt 2.0

        # Make captions appear 1.5 seconds earlier
        lai caption shift input.srt output.srt -1.5

        # Shift and convert format
        lai caption shift input.vtt output.srt seconds=0.5

        # Using keyword arguments (traditional syntax)
        lai caption shift \\
            input_path=input.srt \\
            output_path=output.srt \\
            seconds=3.0
    """
    from pathlib import Path

    from lattifai.data import Caption

    input_path = Path(input_path).expanduser()
    output_path = Path(output_path).expanduser()

    # Read captions
    caption_obj = Caption.read(input_path)

    # Shift timestamps
    shifted_caption = caption_obj.shift_time(seconds)

    # Write shifted captions
    shifted_caption.write(output_path)

    if seconds >= 0:
        direction = f"delayed by {seconds}s"
    else:
        direction = f"advanced by {abs(seconds)}s"

    if output_path == input_path:
        safe_print(f"✅ Shifted timestamps {direction} in {input_path} (in-place)")
    else:
        safe_print(f"✅ Shifted timestamps {direction}: {input_path} -> {output_path}")

    return output_path


@run.cli.entrypoint(name="diff", namespace="caption", entrypoint_cls=LattifAIEntrypoint)
def diff(
    reference: Pathlike,
    hyp_path: Pathlike,
    split_sentence: bool = True,
    verbose: bool = True,
) -> list:
    """
    Compare and align caption supervisions with transcription segments.

    This command reads a reference caption file and a hypothesis file, then performs
    text alignment to show how they match up. It's useful for comparing
    original subtitles against ASR (Automatic Speech Recognition) results.

    Args:
        reference: Path to reference caption file (ground truth)
        hyp_path: Path to hypothesis file (e.g., ASR results)
        split_sentence: Enable sentence splitting before alignment (default: True)
        verbose: Enable verbose output to show detailed alignment info (default: True)

    Examples:
        # Compare reference with hypothesis (positional arguments)
        lai caption diff subtitles.srt transcription.json

        # Disable sentence splitting
        lai caption diff subtitles.srt transcription.json split_sentence=false

        # Disable verbose output
        lai caption diff subtitles.srt transcription.json verbose=false
    """
    from pathlib import Path

    from lattifai.alignment.text_align import align_supervisions_and_transcription
    from lattifai.caption import SentenceSplitter
    from lattifai.data import Caption

    reference = Path(reference).expanduser()
    hyp_path = Path(hyp_path).expanduser()

    # Read reference caption (supervisions)
    caption_obj = Caption.read(reference)

    # Read hypothesis
    hyp_obj = Caption.read(hyp_path)

    # Apply sentence splitting if enabled
    if split_sentence:
        splitter = SentenceSplitter(device="cpu", lazy_init=True)
        caption_obj.supervisions = splitter.split_sentences(caption_obj.supervisions)
        hyp_obj.supervisions = splitter.split_sentences(hyp_obj.supervisions)

    # Set transcription on caption object
    caption_obj.transcription = hyp_obj.supervisions

    safe_print(f"📖  Reference: {len(caption_obj.supervisions)} segments from {reference}")
    safe_print(f"🎤 Hypothesis: {len(caption_obj.transcription)} segments from {hyp_path}")
    if split_sentence:
        safe_print("✂️  Sentence splitting: enabled")
    safe_print("")

    # Perform alignment
    results = align_supervisions_and_transcription(
        caption=caption_obj,
        verbose=verbose,
    )

    # # Print summary
    # safe_print("")
    # safe_print("=" * 72)
    # safe_print(f"📊 Alignment Summary: {len(results)} groups")
    # for idx, (sub_align, asr_align, quality, timestamp, typing) in enumerate(results):
    #     sub_count = len(sub_align) if sub_align else 0
    #     asr_count = len(asr_align) if asr_align else 0
    #     safe_print(f"  Group {idx + 1}: ref={sub_count}, hyp={asr_count}, {quality.info}, typing={typing}")

    return results


def main_diff():
    run.cli.main(diff)


def main_convert():
    run.cli.main(convert)


def main_normalize():
    run.cli.main(normalize)


def main_shift():
    run.cli.main(shift)


if __name__ == "__main__":
    main_convert()
