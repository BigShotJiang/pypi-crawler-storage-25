import json
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import numpy as np
import onnxruntime as ort
from tqdm import tqdm

from lattifai.audio2 import AudioData
from lattifai.errors import AlignmentError, DependencyError, ModelLoadError
from lattifai.theme import theme
from lattifai.types import Pathlike
from lattifai.utils import safe_print


class Lattice1Worker:
    """Worker for processing audio with LatticeGraph."""

    def __init__(
        self, model_path: Pathlike, device: str = "cpu", num_threads: int = 8, config: Optional[Any] = None
    ) -> None:
        try:
            self.model_config = json.load(open(f"{model_path}/config.json"))
        except Exception as e:
            raise ModelLoadError(f"config from {model_path}", original_error=e)

        # Store alignment config with beam search parameters
        self.alignment_config = config

        # SessionOptions
        sess_options = ort.SessionOptions()
        # sess_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        sess_options.intra_op_num_threads = num_threads  # CPU cores
        sess_options.execution_mode = ort.ExecutionMode.ORT_PARALLEL
        sess_options.add_session_config_entry("session.intra_op.allow_spinning", "0")
        # Suppress CoreMLExecutionProvider warnings about partial graph support
        sess_options.log_severity_level = 3  # ERROR level only

        acoustic_model_path = f"{model_path}/acoustic_opt.onnx"

        providers = []
        all_providers = ort.get_all_providers()
        if device.startswith("cuda") and all_providers.count("CUDAExecutionProvider") > 0:
            providers.append("CUDAExecutionProvider")
        if "MPSExecutionProvider" in all_providers:
            providers.append("MPSExecutionProvider")
        if "CoreMLExecutionProvider" in all_providers:
            if "quant" in acoustic_model_path:
                # NOTE: CPUExecutionProvider is faster for quantized models
                pass
            else:
                providers.append("CoreMLExecutionProvider")

        try:
            self.acoustic_ort = ort.InferenceSession(
                acoustic_model_path,
                sess_options,
                providers=providers + ["CPUExecutionProvider"],
            )
        except Exception as e:
            raise ModelLoadError(f"acoustic model from {model_path}", original_error=e)

        # Get vocab_size from model output
        self.vocab_size = self.acoustic_ort.get_outputs()[0].shape[-1]

        # get input_names
        input_names = [inp.name for inp in self.acoustic_ort.get_inputs()]
        assert "audios" in input_names, f"Input name audios not found in {input_names}"

        # Initialize separator if available
        separator_model_path = Path(model_path) / "separator.onnx"
        if separator_model_path.exists():
            self.separator_ort = ort.InferenceSession(
                str(separator_model_path),
                providers=providers + ["CPUExecutionProvider"],
            )
        else:
            self.separator_ort = None

        self.timings = defaultdict(lambda: 0.0)

    @property
    def frame_shift(self) -> float:
        return 0.02  # 20 ms

    def emission(self, ndarray: np.ndarray, acoustic_scale: float = 1.0) -> np.ndarray:
        """Generate emission probabilities from audio ndarray.

        Args:
            ndarray: Audio data as numpy array of shape (1, T) or (C, T)

        Returns:
            Emission numpy array of shape (1, T, vocab_size)
        """
        if self.alignment_config and self.alignment_config.normalize_volume:
            from lattifai.audio2 import normalize_volume

            ndarray = normalize_volume(ndarray)

        _start = time.time()

        if ndarray.shape[1] < 160:
            ndarray = np.pad(ndarray, ((0, 0), (0, 320 - ndarray.shape[1])), mode="constant")

        CHUNK_SIZE = 60 * 16000  # 60 seconds
        total_samples = ndarray.shape[1]

        if total_samples > CHUNK_SIZE:
            frame_samples = int(16000 * self.frame_shift)
            emissions = np.empty((1, total_samples // frame_samples + 1, self.vocab_size), dtype=np.float32)
            for start in range(0, total_samples, CHUNK_SIZE):
                chunk = ndarray[:, start : start + CHUNK_SIZE]
                if chunk.shape[1] < 160:
                    chunk = np.pad(chunk, ((0, 0), (0, 320 - chunk.shape[1])), mode="constant")

                emission_out = self.acoustic_ort.run(None, {"audios": chunk})[0]
                if acoustic_scale != 1.0:
                    emission_out *= acoustic_scale
                sf = start // frame_samples  # start frame
                lf = sf + emission_out.shape[1]  # last frame
                emissions[0, sf:lf, :] = emission_out
            emissions[:, lf:, :] = 0.0
        else:
            emission_out = self.acoustic_ort.run(
                None,
                {
                    "audios": ndarray,
                },
            )  # (1, T, vocab_size) numpy
            emissions = emission_out[0]

            if acoustic_scale != 1.0:
                emissions *= acoustic_scale

        self.timings["emission"] += time.time() - _start
        return emissions  # (1, T, vocab_size) numpy

    def alignment(
        self,
        audio: AudioData,
        lattice_graph: Tuple[str, int, float],
        emission: Optional[np.ndarray] = None,
        offset: float = 0.0,
    ) -> Dict[str, Any]:
        """Process audio with LatticeGraph.

        Args:
            audio: AudioData object
            lattice_graph: LatticeGraph data
            emission: Pre-computed emission numpy array (ignored if streaming=True)
            offset: Time offset for the audio
            streaming: If True, use streaming mode for memory-efficient processing

        Returns:
            Processed LatticeGraph

        Raises:
            AudioLoadError: If audio cannot be loaded
            DependencyError: If required dependencies are missing
            AlignmentError: If alignment process fails
        """
        import k2py as k2

        lattice_graph_str, final_state, acoustic_scale = lattice_graph

        _start = time.time()
        try:
            # Create decoding graph using k2py
            graph_dict = k2.CreateFsaVecFromStr(lattice_graph_str, int(final_state), False)
            decoding_graph = graph_dict["fsa"]
            aux_labels = graph_dict["aux_labels"]
        except Exception as e:
            raise AlignmentError(
                "Failed to create decoding graph from lattice",
                context={"original_error": str(e), "lattice_graph_length": len(lattice_graph_str)},
            )
        self.timings["decoding_graph"] += time.time() - _start

        _start = time.time()

        # Get beam search parameters from config or use defaults
        search_beam = self.alignment_config.search_beam or 200
        output_beam = self.alignment_config.output_beam or 80
        min_active_states = self.alignment_config.min_active_states or 400
        max_active_states = self.alignment_config.max_active_states or 10000

        if emission is None and audio.streaming_mode:
            # Initialize OnlineDenseIntersecter for streaming
            intersecter = k2.OnlineDenseIntersecter(
                decoding_graph,
                aux_labels,
                float(search_beam),
                float(output_beam),
                int(min_active_states),
                int(max_active_states),
                allow_partial=True,
            )

            # Streaming mode — flush every N chunks for memory/quality tradeoff.
            # flush_interval=0: never flush (O(total) memory, globally optimal)
            # flush_interval=N: flush every N chunks (higher N = better quality, more memory)
            # flush_interval="auto": auto-decide based on duration and chunk size
            flush_cfg = getattr(self.alignment_config, "flush_interval", "auto") if self.alignment_config else "auto"
            has_flush = hasattr(intersecter, "decode_and_flush")
            if isinstance(flush_cfg, int):
                flush_interval = flush_cfg if has_flush else 0
            elif flush_cfg == "auto":
                _MIN_DURATION = 2400  # 40 minutes
                _MIN_CHUNK_SECS = 300  # chunk must be large enough for ShortestPath
                if has_flush and audio.duration > _MIN_DURATION and audio.streaming_chunk_secs >= _MIN_CHUNK_SECS:
                    # Auto: ~10 min worth of chunks per flush cycle
                    flush_interval = max(1, int(1200 / audio.streaming_chunk_secs))
                else:
                    flush_interval = 0
            else:
                flush_interval = 0
            total_duration = audio.duration
            total_minutes = int(total_duration / 60.0)

            max_probs = []
            aligned_probs = []

            with tqdm(
                total=total_minutes,
                desc=f"Processing audio ({total_minutes} min)",
                unit="min",
                unit_scale=False,
                unit_divisor=1,
            ) as pbar:
                chunk_counter = 0
                cycle_probs = []
                for chunk in audio.iter_chunks():
                    chunk_emission = self.emission(chunk.ndarray, acoustic_scale=acoustic_scale)

                    __start = time.time()
                    chunk_counter += 1
                    do_flush = flush_interval > 0 and chunk_counter % flush_interval == 0

                    if do_flush:
                        intersecter.decode_and_flush(chunk_emission[0])
                    else:
                        intersecter.decode(chunk_emission[0])

                    probs = np.exp(chunk_emission[0])
                    max_probs.append(np.max(probs, axis=-1))
                    cycle_probs.append(probs)

                    if do_flush or flush_interval == 0:
                        labels = intersecter.get_partial_labels()
                        emission = np.concatenate(cycle_probs, axis=0)
                        if len(labels) == len(emission):
                            aligned_probs.append(emission[np.arange(len(labels)), labels])
                        else:
                            aligned_probs.append(np.max(emission, axis=-1))
                        cycle_probs = []

                    del chunk_emission
                    self.timings["align_>labels"] += time.time() - __start
                    pbar.update(int(chunk.duration / 60.0))

                # Tail chunks that didn't complete a flush cycle
                if cycle_probs:
                    aligned_probs.append(np.max(np.concatenate(cycle_probs, axis=0), axis=-1))

            # Build emission_stats for confidence calculation
            emission_stats = {
                "max_probs": np.concatenate(max_probs),
                "aligned_probs": np.concatenate(aligned_probs),
            }

            __start = time.time()
            results, labels = intersecter.finish()
            self.timings["align_>finish"] += time.time() - __start
        else:
            # Batch mode
            if emission is None:
                emission = self.emission(audio.ndarray, acoustic_scale=acoustic_scale)  # (1, T, vocab_size)
            else:
                if acoustic_scale != 1.0:
                    emission *= acoustic_scale
            # Use AlignSegments directly
            results, labels = k2.AlignSegments(
                graph_dict,
                emission[0],  # Pass the prepared scores
                float(search_beam),
                float(output_beam),
                int(min_active_states),
                int(max_active_states),
                allow_partial=True,
            )
            # Compute emission_stats from full emission (same format as streaming)
            probs = np.exp(emission[0])  # [T, V]
            emission_stats = {
                "max_probs": np.max(probs, axis=-1),  # [T]
                "aligned_probs": probs[np.arange(probs.shape[0]), labels[0]],  # [T]
            }

        self.timings["align_segments"] += time.time() - _start

        channel = 0
        return emission_stats, results, labels, self.frame_shift, offset, channel  # frame_shift=20ms

    def profile(self) -> None:
        """Print formatted profiling statistics."""
        if not self.timings:
            return

        safe_print(theme.step("\n⏱️  Alignment Profiling"))
        safe_print(theme.dim("─" * 44))
        safe_print(
            f"{theme.label('Phase'.ljust(21))} "
            f"{theme.label('Time'.ljust(12))} "
            f"{theme.label('Percent'.rjust(8))}"
        )
        safe_print(theme.dim("─" * 44))

        total_time = sum(self.timings.values())

        # Sort by duration descending
        sorted_stats = sorted(self.timings.items(), key=lambda x: x[1], reverse=True)

        for name, duration in sorted_stats:
            percentage = (duration / total_time * 100) if total_time > 0 else 0.0
            # Name: Cyan, Time: Yellow, Percent: Gray
            safe_print(
                f"{name:<20} "
                f"{theme.warn(f'{duration:7.4f}s'.ljust(12))} "
                f"{theme.dim(f'{percentage:.2f}%'.rjust(8))}"
            )

        safe_print(theme.dim("─" * 44))
        # Pad "Total Time" before coloring to ensure correct alignment (ANSI codes don't count for width)
        safe_print(f"{theme.label('Total Time'.ljust(20))} " f"{theme.value(f'{total_time:7.4f}s'.ljust(12))}\n")


def _load_worker(model_path: str, device: str, config: Optional[Any] = None) -> Lattice1Worker:
    """Instantiate lattice worker with consistent error handling."""
    try:
        return Lattice1Worker(model_path, device=device, num_threads=8, config=config)
    except Exception as e:
        raise ModelLoadError(f"worker from {model_path}", original_error=e)
