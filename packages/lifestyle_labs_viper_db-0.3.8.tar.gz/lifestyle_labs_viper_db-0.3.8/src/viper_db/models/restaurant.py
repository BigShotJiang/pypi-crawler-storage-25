from typing import TYPE_CHECKING

import sqlalchemy as sa
from sqlmodel import Field, Relationship, SQLModel

if TYPE_CHECKING:
    from .experience import Experience


class Restaurant(SQLModel, table=True):
    __tablename__ = "restaurants"

    experience_id: int = Field(
        sa_column=sa.Column(
            sa.Integer,
            sa.ForeignKey("experiences.id", ondelete="CASCADE"),
            primary_key=True,
        ),
    )
    cuisine: list[str] | None = Field(
        default_factory=list,
        sa_column=sa.Column(sa.ARRAY(sa.Text), server_default="{}"),
    )
    resy_name: str | None = Field(default=None, sa_column=sa.Column(sa.Text))
    resy_venue_id: int | None = Field(default=None)
    url_slug: str | None = Field(default=None, sa_column=sa.Column(sa.Text))

    experience: "Experience" = Relationship(back_populates="restaurant")
