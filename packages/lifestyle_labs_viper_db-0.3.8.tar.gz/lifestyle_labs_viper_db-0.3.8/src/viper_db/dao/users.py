"""CRUD operations for the users table."""

import logging
from typing import Optional
from uuid import UUID

from sqlmodel import select

from viper_db.models import User
from viper_db.utils.db import get_session

logger = logging.getLogger(__name__)


class UsersDAO:
    @property
    def session(self):
        return get_session()

    async def get_by_id(self, user_id: UUID) -> Optional[User]:
        return await self.session.get(User, user_id)

    async def get_by_phone(self, phone: str) -> Optional[User]:
        result = await self.session.execute(select(User).where(User.phone == phone))
        return result.scalar_one_or_none()

    async def get_all(self) -> list[User]:
        result = await self.session.execute(select(User))
        return list(result.scalars().all())

    async def update(self, user_id: UUID, data) -> Optional[User]:
        user = await self.session.get(User, user_id)
        if not user:
            return None
        for key, value in data.model_dump(exclude_unset=True).items():
            setattr(user, key, value)
        self.session.add(user)
        await self.session.commit()
        await self.session.refresh(user)
        return user

    async def delete(self, user_id: UUID) -> bool:
        user = await self.session.get(User, user_id)
        if not user:
            return False
        await self.session.delete(user)
        await self.session.commit()
        return True


users_dao = UsersDAO()
