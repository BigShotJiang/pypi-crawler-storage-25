"""CRUD operations for the conversations table."""

from typing import Optional
from uuid import UUID

from sqlmodel import select

from viper_db.models import Conversation
from viper_db.utils.db import get_session


class ConversationsDAO:
    @property
    def session(self):
        return get_session()

    async def get_by_id(self, conversation_id: int) -> Optional[Conversation]:
        return await self.session.get(Conversation, conversation_id)

    async def get_all_by_user(self, user_id: UUID) -> list[Conversation]:
        statement = select(Conversation).where(Conversation.user_id == user_id)
        result = await self.session.execute(statement)
        return list(result.scalars().all())

    async def create(self, data) -> Conversation:
        conversation = Conversation.model_validate(data)
        self.session.add(conversation)
        await self.session.commit()
        await self.session.refresh(conversation)
        return conversation

    async def update(self, conversation_id: int, data) -> Optional[Conversation]:
        conversation = await self.get_by_id(conversation_id)
        if not conversation:
            return None

        update_data = data.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(conversation, key, value)

        self.session.add(conversation)
        await self.session.commit()
        await self.session.refresh(conversation)
        return conversation

    async def delete(self, conversation_id: int) -> bool:
        conversation = await self.session.get(Conversation, conversation_id)
        if not conversation:
            return False
        await self.session.delete(conversation)
        await self.session.commit()
        return True


conversations_dao = ConversationsDAO()
