# pyexcel2mustache

Convert Excel (`xlsx`) sheets into Mustache templates based on a defined schema. This is now a distributable Python package.

## Features

- Convert multiple sheets at once using customizable schemas.
- Skip sheets starting with an underscore (`_`).
- Robust and modular architecture following SOLID principles.
- Easy installation via `pip`.

## Installation

Install the package from the local directory:

```bash
pip install .
```

Once published to PyPI, you can install it using:

```bash
pip install pyexcel2mustache
```

## Requirements

- Python 3.8+
- Dependencies (automatically installed): `openpyxl`, `pystache`

## Excel Schema Rules

Each sheet must follow a strict schema for the first 5 rows:

1.  **Row 1**: Column Description
2.  **Row 2**: Usage / PrimaryKey indicator (`'PrimaryKey'` string marks it as primary)
3.  **Row 3**: Attribute name
4.  **Row 4**: Data Type
5.  **Row 5**: Variable Name (the actual identifier used in the template)

*Note: Sheets starting with an underscore (`_`) will be skipped.*

## Usage

Once installed, use the `pyexcel2mustache` command in your terminal:

```bash
pyexcel2mustache -i <input_excel> -t <template_mustache> -o <output_path> [-c]
```

### Arguments

- `-i`, `--input`: Path to the input Excel file. (**Required**)
- `-t`, `--template`: Path to the Mustache template file. (**Required**)
- `-o`, `--output`: Path for the generated output file. (**Required**)
- `-c`, `--clean`: Clean up/remove existing output file before writing.

## Project Structure (Refactored)

The project follows a modular structure:
- `src/pyexcel2mustache/domain`: Data models.
- `src/pyexcel2mustache/parsers`: Excel parsing logic.
- `src/pyexcel2mustache/renderers`: Mustache rendering engine.
- `src/pyexcel2mustache/cli`: Command line argument handling.
