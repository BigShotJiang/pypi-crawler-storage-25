import os
import logging
from pyexcel2mustache.cli.args_parser import parse_arguments
from pyexcel2mustache.parsers.excel_parser import ExcelParser
from pyexcel2mustache.renderers.mustache_renderer import MustacheRenderer

# Configure logger for the package
logger = logging.getLogger("pyexcel2mustache")


def run():
    """
    The main entry point for the excel2mustache CLI tool.
    This function is called by the entry point defined in pyproject.toml.
    """
    args = parse_arguments()

    if args.clean and os.path.exists(args.output):
        os.remove(args.output)

    try:
        with open(args.template, "r") as f:
            template_content = f.read()
        if not template_content:
            logger.error("Template file is empty.")
            return
    except Exception as e:
        logger.error(f"Error reading template: {e}")
        return

    parser = ExcelParser()
    try:
        class_list = parser.parse(args.input)
    except Exception as e:
        logger.error(f"Error parsing Excel file: {e}")
        return

    renderer = MustacheRenderer()
    try:
        result = renderer.render(template_content, class_list)
    except Exception as e:
        logger.error(f"Error rendering template: {e}")
        return

    try:
        with open(args.output, "w") as f:
            f.write(result)
        logger.info(f"Successfully generated: {args.output}")
    except Exception as e:
        logger.error(f"Error writing output file: {e}")
        return


if __name__ == "__main__":
    # Default logging configuration for CLI usage
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    run()
