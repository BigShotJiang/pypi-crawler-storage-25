import argparse


def parse_arguments() -> argparse.Namespace:
    """
    Parses command-line arguments for the application.

    Returns:
        argparse.Namespace: An object containing the parsed arguments.
    """
    parser = argparse.ArgumentParser(
        description="Convert Excel files to Mustache templates."
    )
    parser.add_argument(
        "-i", "--input", help="Path of the input Excel file", required=True
    )
    parser.add_argument(
        "-t", "--template", help="Path of the Mustache template file", required=True
    )
    parser.add_argument("-o", "--output", help="Path of the output file", required=True)
    parser.add_argument(
        "-c",
        "--clean",
        help="Clean up the output if it already exists",
        action="store_true",
    )

    return parser.parse_args()
