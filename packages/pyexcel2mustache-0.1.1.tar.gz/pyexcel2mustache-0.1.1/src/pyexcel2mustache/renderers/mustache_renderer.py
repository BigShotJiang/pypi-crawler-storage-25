import pystache
from pyexcel2mustache.domain.models import ClassList


class MustacheRenderer:
    """
    A renderer that uses Mustache templates to render domain models as strings.
    """

    def render(self, template_content: str, data: ClassList) -> str:
        """
        Renders the provided template content with the given data.

        Args:
            template_content (str): The mustache template string.
            data (ClassList): The domain models to be rendered.

        Returns:
            str: The rendered output string.
        """
        return pystache.render(template_content, data)
