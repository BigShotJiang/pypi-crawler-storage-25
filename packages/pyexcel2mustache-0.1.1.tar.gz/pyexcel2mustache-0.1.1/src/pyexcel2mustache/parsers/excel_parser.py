import datetime
from openpyxl import load_workbook
from pyexcel2mustache.domain.models import (
    ClassList,
    ClassDeclare,
    ClassMember,
    Attribute,
)
from pyexcel2mustache.parsers.base_parser import BaseParser


class ExcelParser(BaseParser):
    """
    A parser that reads Excel (.xlsx) files and converts them into domain models.
    """

    def parse(self, file_path: str) -> ClassList:
        wb = load_workbook(filename=file_path, data_only=True)
        class_list = ClassList(datetime.datetime.now())

        for sheet in wb:
            if sheet.title.startswith("_"):
                continue

            class_declare = self._parse_sheet(sheet)
            if class_declare:
                class_list.add(class_declare)

        return class_list

    def _parse_sheet(self, sheet) -> ClassDeclare:
        # According to AGENTS.md requirements and original logic:
        # Row 1 (idx 0): Column Description
        # Row 2 (idx 1): Usage / PrimaryKey check ('PrimaryKey' string here)
        # Row 3 (idx 2): Attribute (Not used for data, but part of schema)
        # Row 4 (idx 3): Data Type
        # Row 5 (idx 4): Variable Name

        primary_index = -1
        data_types = []
        variable_names = []
        attributes_list = []  # To hold the 'PrimaryKey' attribute if needed

        # We need to iterate through rows or access them by index.
        # Since it's a strict schema, we can use sheet.iter_rows()
        # and check row indices (1-based). Or convert to list of rows.
        rows = list(sheet.iter_rows())

        if len(rows) < 5:
            return None  # Sheet too small for the required schema

        # Row 2 (idx 1): Find PrimaryKey index
        row_2 = rows[1]
        for idx, cell in enumerate(row_2):
            if cell.value == "PrimaryKey":
                primary_index = idx
                break

        # Row 4 (idx 3): Data Types
        row_4 = rows[3]
        for cell in row_4:
            data_types.append(str(cell.value) if cell.value is not None else "")

        # Row 5 (idx 4): Variable Names
        row_5 = rows[4]
        for cell in row_5:
            variable_names.append(str(cell.value) if cell.value is not None else "")

        class_members = []
        # Iterate through the columns collected from data type and name rows
        for i in range(len(data_types)):
            if i >= len(variable_names):
                break

            name = variable_names[i]
            dtype = data_types[i]

            # Skip if no name is provided (treating it as end of columns)
            if not name:
                continue

            is_primary = i == primary_index
            attrs = []
            if is_primary:
                attrs.append(Attribute("PrimaryKey"))

            member = ClassMember(
                attributes=attrs, data_type=dtype, name=name, is_primary_key=is_primary
            )
            class_members.append(member)

        return ClassDeclare(sheet.title, datetime.datetime.now(), class_members)
