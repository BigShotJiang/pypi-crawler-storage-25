from abc import ABC, abstractmethod
from pyexcel2mustache.domain.models import ClassList


class BaseParser(ABC):
    """
    Abstract base class for all parsers.
    """

    @abstractmethod
    def parse(self, file_path: str) -> ClassList:
        """
        Parses a file and returns a ClassList object.

        Args:
            file_path (str): Path to the input file.

        Returns:
            ClassList: The parsed domain models.
        """
        pass
