import datetime
from typing import List


class Attribute:
    """Represents a single attribute within a class member."""

    def __init__(self, name: str):
        self._name = name

    @property
    def property(self) -> str:
        return self._name


class ClassMember:
    """Represents a field or variable defined in the Excel schema."""

    def __init__(
        self,
        attributes: List[Attribute],
        data_type: str,
        name: str,
        is_primary_key: bool,
    ):
        self._attributes = attributes
        self._type = data_type
        self._name = name
        self._is_primary_key = is_primary_key

    @property
    def type_name(self) -> str:
        return self._type

    @property
    def var_name(self) -> str:
        return self._name

    @property
    def attributes(self) -> List[Attribute]:
        return self._attributes

    @property
    def IsPrimaryKey(self) -> bool:
        return self._is_primary_key


class ClassDeclare:
    """Represents a fully defined class structure."""

    def __init__(
        self, name: str, date: datetime.datetime, class_members: List[ClassMember]
    ):
        self._name = name
        self._date = date
        self._classMembers = class_members

    @property
    def name(self) -> str:
        return self._name

    @property
    def class_members(self) -> List[ClassMember]:
        return self._classMembers

    @property
    def date(self) -> datetime.datetime:
        return self._date


class ClassList:
    """A collection of defined classes, used for template rendering."""

    def __init__(self, date: datetime.datetime):
        self._class_list = []
        self._date = date

    def add(self, class_declare: ClassDeclare) -> None:
        self._class_list.append(class_declare)

    @property
    def class_list(self) -> List[ClassDeclare]:
        return self._class_list

    @property
    def date(self) -> datetime.datetime:
        return self._date
