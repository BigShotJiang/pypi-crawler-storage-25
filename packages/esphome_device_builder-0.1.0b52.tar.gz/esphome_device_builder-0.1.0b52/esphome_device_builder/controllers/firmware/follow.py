"""Firmware-job WS streaming endpoints: follow_job + follow_jobs."""

from __future__ import annotations

from operator import attrgetter
from typing import TYPE_CHECKING, Any

from ...helpers.event_bus import StreamControls, stream_events
from ...models import (
    TERMINAL_JOB_EVENTS,
    TERMINAL_JOB_STATUSES,
    EventType,
    StreamEvent,
)

if TYPE_CHECKING:
    from ...helpers.event_bus import Event
    from .controller import FirmwareController


async def follow_job(
    controller: FirmwareController,
    *,
    job_id: str,
    client: Any = None,
    message_id: str = "",
) -> None:
    """Follow a job: replay history, stream new output (``tail -f``-style).

    Already-terminal jobs get one history send + a final result
    event, then end. Live jobs keep streaming until completion.

    Snapshot-then-subscribe ordering matters: the listener is
    attached *before* the history replay so lines fired during
    replay queue through the listener and land strictly after
    history. The earlier iterate-then-subscribe shape dropped
    every line appended during replay, and the gap widened
    forever after the first in-flight ``_trim_job_output`` reassign.
    """
    job = controller.state.jobs.get(job_id)
    if not job:
        msg = f"Job not found: {job_id}"
        raise ValueError(msg)

    # Capture snapshot before ``stream_events`` attaches listeners.
    # Both happen in synchronous-adjacent statements so nothing
    # fires between freeze and subscribe.
    snapshot = list(job.output)
    is_terminal = job.status in TERMINAL_JOB_STATUSES
    terminal_status = job.status.value if is_terminal else ""
    terminal_exit_code = job.exit_code
    terminal_error = job.error if is_terminal else None

    async def _send_initial(controls: StreamControls) -> None:
        for line in snapshot:
            await client.send_event(message_id, StreamEvent.OUTPUT, line)
        if is_terminal:
            await client.send_event(
                message_id,
                StreamEvent.RESULT,
                {
                    "status": terminal_status,
                    "exit_code": terminal_exit_code,
                    # ``error`` carries the human-readable failure
                    # reason the frontend install dialog renders in
                    # its red banner. Without it the banner falls
                    # back to a generic "Install failed." that
                    # misattributes a receiver-restart to a broken
                    # build env. ``None`` for successful jobs.
                    "error": terminal_error,
                },
            )
            # End the stream so the helper returns instead of
            # parking on ``queue.get`` — already-terminal job has
            # nothing more to deliver.
            controls.end()

    def _handle_event(event: Event, controls: StreamControls) -> None:
        if event.event_type == EventType.JOB_OUTPUT:
            if event.data.get("job_id") == job_id:
                controls.push(StreamEvent.OUTPUT, event.data["line"])
        elif event.event_type in TERMINAL_JOB_EVENTS:
            ev_job = event.data.get("job")
            if ev_job and getattr(ev_job, "job_id", None) == job_id:
                status = getattr(ev_job, "status", "unknown")
                status_val = status.value if hasattr(status, "value") else str(status)
                controls.push_priority(
                    StreamEvent.RESULT,
                    {
                        "status": status_val,
                        "exit_code": getattr(ev_job, "exit_code", None),
                        "error": getattr(ev_job, "error", None),
                    },
                )
                controls.end()

    await stream_events(
        client=client,
        message_id=message_id,
        bus=controller._db.bus,
        event_types=(EventType.JOB_OUTPUT, *TERMINAL_JOB_EVENTS),
        handle_event=_handle_event,
        send_initial=_send_initial,
    )


async def follow_jobs(
    controller: FirmwareController,
    *,
    client: Any = None,
    message_id: str = "",
    snapshot: bool = True,
) -> None:
    """Stream every job's lifecycle events + live output to one client.

    With ``snapshot=True`` (default), the full retained job set
    (active + trimmed terminal history) is replayed first so a
    refresh paints immediately with no follow-up
    ``firmware/get_jobs``. Each event payload is bus-shape
    (``job_id``-keyed) so the frontend updates its in-memory map
    without extra queries.

    Runs until the client disconnects (surfaces as
    ``CancelledError`` from ``send_event``). Same
    snapshot-then-subscribe ordering as :func:`follow_job` — a
    ``JOB_*`` event firing during snapshot replay queues through
    the listener rather than being lost.
    """
    if client is None:
        return

    # Freeze the snapshot to dicts synchronously *before*
    # ``stream_events`` attaches listeners. Deferring ``to_dict()``
    # into ``send_initial`` would let the runner mutate a running
    # job between freeze and serialise — that mutation lands in
    # both the snapshot AND the listener, so the client sees the
    # same line twice.
    snapshot_payloads = (
        [
            job.to_dict()
            for job in sorted(controller.state.jobs.values(), key=attrgetter("created_at"))
        ]
        if snapshot
        else []
    )

    async def _send_initial(_controls: StreamControls) -> None:
        for payload in snapshot_payloads:
            await client.send_event(message_id, StreamEvent.SNAPSHOT, payload)

    def _handle_event(event: Event, controls: StreamControls) -> None:
        if event.event_type == EventType.JOB_OUTPUT:
            controls.push(EventType.JOB_OUTPUT, event.data)
        elif event.event_type == EventType.JOB_PROGRESS:
            controls.push(EventType.JOB_PROGRESS, event.data)
        else:
            # Lifecycle event — use ``push_priority`` so a backlog
            # of high-rate output/progress can't drop a status
            # transition. A missed JOB_COMPLETED leaves the panel
            # stuck on the old status forever (no resync after
            # the initial snapshot).
            job = event.data.get("job")
            if job is None:
                return
            payload = job.to_dict() if hasattr(job, "to_dict") else job
            controls.push_priority(event.event_type.value, payload)

    await stream_events(
        client=client,
        message_id=message_id,
        bus=controller._db.bus,
        event_types=(
            EventType.JOB_QUEUED,
            EventType.JOB_STARTED,
            *TERMINAL_JOB_EVENTS,
            EventType.JOB_OUTPUT,
            EventType.JOB_PROGRESS,
        ),
        handle_event=_handle_event,
        send_initial=_send_initial,
    )
