"""plato-auth-middleware — Simple shared-secret auth for fleet services.

Lightweight auth layer that validates Bearer tokens before allowing access.
Designed to drop in front of plato-shell.py and plato-tiles.py.

Usage:
    from plato_auth_middleware import AuthMiddleware, require_auth
    
    # Wrap your HTTP handler
    auth = AuthMiddleware.from_env()  # reads PLATO_API_KEY env var
    # or
    auth = AuthMiddleware(api_key="your-secret-key")
    
    # In your request handler:
    if not auth.validate(request.headers.get('Authorization', '')):
        return 401, {"error": "Unauthorized"}
"""
import os
import hashlib
import hmac
import time
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class RateLimitEntry:
    last_seen: float = 0.0
    request_count: int = 0
    window_start: float = 0.0


class AuthMiddleware:
    """Simple bearer-token auth with per-agent rate limiting.
    
    Auth modes:
    - 'token': require Bearer token match
    - 'open': no auth (development mode)
    - 'permissive': log auth failures but allow through
    """
    
    def __init__(self, api_key: str = "", mode: str = "token"):
        self.api_key = api_key
        self.mode = mode
        self._rate_limits: dict[str, RateLimitEntry] = {}
        self._default_rpm = 60  # requests per minute per agent
        self._default_submit_rpm = 10  # stricter for writes
    
    @classmethod
    def from_env(cls) -> "AuthMiddleware":
        """Create from environment variables."""
        key = os.environ.get("PLATO_API_KEY", "")
        mode = os.environ.get("PLATO_AUTH_MODE", "token" if key else "open")
        return cls(api_key=key, mode=mode)
    
    def validate(self, auth_header: str) -> bool:
        """Validate Authorization header. Returns True if access should be granted."""
        if self.mode == "open":
            return True
        
        if not auth_header:
            return self.mode == "permissive"
        
        if not auth_header.startswith("Bearer "):
            return self.mode == "permissive"
        
        token = auth_header[7:]
        
        if self.mode == "permissive":
            return True
        
        # Constant-time comparison to prevent timing attacks
        if not self.api_key:
            return False
        
        return hmac.compare_digest(token, self.api_key)
    
    def check_rate_limit(self, agent: str, is_write: bool = False) -> bool:
        """Check rate limit for agent. Returns True if allowed."""
        now = time.time()
        rpm = self._default_submit_rpm if is_write else self._default_rpm
        
        if agent not in self._rate_limits:
            self._rate_limits[agent] = RateLimitEntry(
                last_seen=now, request_count=1, window_start=now
            )
            return True
        
        entry = self._rate_limits[agent]
        
        # Reset window if expired
        if now - entry.window_start > 60.0:
            entry.window_start = now
            entry.request_count = 1
            return True
        
        entry.request_count += 1
        entry.last_seen = now
        
        return entry.request_count <= rpm
    
    def rate_limit_remaining(self, agent: str) -> int:
        """Return remaining requests in current window."""
        entry = self._rate_limits.get(agent)
        if not entry:
            return self._default_rpm
        
        elapsed = time.time() - entry.window_start
        if elapsed > 60.0:
            return self._default_rpm
        
        return max(0, self._default_rpm - entry.request_count)


# ── Tests ──

import unittest

class TestAuthMiddleware(unittest.TestCase):
    def test_valid_token(self):
        auth = AuthMiddleware(api_key="secret123", mode="token")
        self.assertTrue(auth.validate("Bearer secret123"))
    
    def test_invalid_token(self):
        auth = AuthMiddleware(api_key="secret123", mode="token")
        self.assertFalse(auth.validate("Bearer wrong"))
    
    def test_missing_header(self):
        auth = AuthMiddleware(api_key="secret123", mode="token")
        self.assertFalse(auth.validate(""))
    
    def test_open_mode(self):
        auth = AuthMiddleware(api_key="", mode="open")
        self.assertTrue(auth.validate(""))
    
    def test_permissive_mode(self):
        auth = AuthMiddleware(api_key="secret123", mode="permissive")
        self.assertTrue(auth.validate(""))
        self.assertTrue(auth.validate("Bearer wrong"))
    
    def test_rate_limit_allows(self):
        auth = AuthMiddleware(api_key="", mode="open")
        for _ in range(50):
            self.assertTrue(auth.check_rate_limit("agent-1"))
    
    def test_rate_limit_blocks(self):
        auth = AuthMiddleware(api_key="", mode="open")
        auth._default_rpm = 5
        for i in range(5):
            self.assertTrue(auth.check_rate_limit("agent-1"))
        self.assertFalse(auth.check_rate_limit("agent-1"))
    
    def test_rate_limit_independent_agents(self):
        auth = AuthMiddleware(api_key="", mode="open")
        auth._default_rpm = 3
        for _ in range(3):
            auth.check_rate_limit("agent-a")
        self.assertFalse(auth.check_rate_limit("agent-a"))
        self.assertTrue(auth.check_rate_limit("agent-b"))
    
    def test_write_stricter(self):
        auth = AuthMiddleware(api_key="", mode="open")
        auth._default_submit_rpm = 2
        self.assertTrue(auth.check_rate_limit("x", is_write=True))
        self.assertTrue(auth.check_rate_limit("x", is_write=True))
        self.assertFalse(auth.check_rate_limit("x", is_write=True))
        # Read still works
        self.assertTrue(auth.check_rate_limit("x", is_write=False))
    
    def test_timing_safe_comparison(self):
        """Token comparison should be constant-time."""
        auth = AuthMiddleware(api_key="a" * 64, mode="token")
        # Both should take similar time regardless of match position
        self.assertTrue(auth.validate("Bearer " + "a" * 64))
        self.assertFalse(auth.validate("Bearer " + "b" * 64))

if __name__ == "__main__":
    unittest.main()
