# plato-input-sanitizer

Input validation and authentication middleware for PLATO fleet services.

## Components

### `input_sanitizer` — Defense-in-depth input validation
- Agent name sanitization (XSS, SQL injection, path traversal blocking)
- Room name validation (whitelist characters)
- Content sanitization (null bytes, length limits)
- Tile submission validation (required fields, answer min-length)

### `auth` — Bearer token authentication with rate limiting
- Simple shared-secret Bearer token auth
- Per-agent rate limiting (configurable RPM for reads vs writes)
- Timing-safe token comparison
- Modes: `token` (enforce), `open` (dev), `permissive` (log-only)

## Install

```bash
pip install plato-input-sanitizer
```

## Usage

```python
from plato_input_sanitizer import sanitize_agent_name, sanitize_tile_submission
from plato_input_sanitizer.auth import AuthMiddleware

# Validate inputs
name = sanitize_agent_name("agent-42")  # raises ValueError if bad

# Auth middleware
auth = AuthMiddleware.from_env()  # reads PLATO_API_KEY
if not auth.validate(request.headers.get("Authorization", "")):
    return 401, {"error": "Unauthorized"}

if not auth.check_rate_limit(agent_name, is_write=True):
    return 429, {"error": "Rate limited"}
```

## Security Audit Response

Created in response to external security audit findings:
- CRITICAL-5: Stored XSS via agent names → `sanitize_agent_name()` with HTML escaping
- HIGH-4: Path traversal in multiple services → injection pattern blocking
- HIGH-3: Rate limit bypass via agent rotation → per-agent rate limiting with timing enforcement
