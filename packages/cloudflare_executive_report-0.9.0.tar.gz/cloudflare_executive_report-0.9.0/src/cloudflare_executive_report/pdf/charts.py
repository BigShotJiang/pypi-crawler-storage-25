"""Matplotlib time-series figures (non-interactive backend)."""

from __future__ import annotations

import calendar
import io
import math
from collections.abc import Sequence
from datetime import date
from typing import Any, Literal, cast

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import ticker
from matplotlib.lines import Line2D

from cloudflare_executive_report.common.formatting import format_bytes_human, trim_decimal
from cloudflare_executive_report.pdf.theme import Theme

ChartTimeGranularity = Literal["day", "week", "month"]

# Bottom + top series for stacked charts (e.g. cached + uncached). ``None`` = missing day.
StackedPoint = tuple[float | None, float | None]
StackedTriplePoint = tuple[float | None, float | None, float | None]
CHART_MARKER_SIZE: float = 4.0
CHART_MARKER_EDGE_WIDTH: float = 0.55
CHART_LINE_WIDTH: float = 1.55
# Policy-driven line colors:
# - single: accent
# - dual: accent (CF-associated) then primary (counterpart)
# - triple: accent (primary series), primary (secondary series), tertiary (other series)


def _marker_style(color: str) -> dict[str, Any]:
    return {
        "marker": "o",
        "markersize": CHART_MARKER_SIZE,
        "markerfacecolor": color,
        "markeredgewidth": CHART_MARKER_EDGE_WIDTH,
        "markeredgecolor": "white",
    }


def _save_figure_bytes(fig: Any, *, theme: Theme) -> bytes:
    """Save a matplotlib figure to bytes honoring configured chart format."""
    buf = io.BytesIO()
    save_kwargs: dict[str, Any] = {
        "format": theme.chart_format,
        "bbox_inches": "tight",
        "facecolor": "white",
        "pad_inches": 0,
    }
    if theme.chart_format == "png":
        save_kwargs["dpi"] = theme.chart_dpi
    fig.savefig(buf, **save_kwargs)
    plt.close(fig)
    buf.seek(0)
    return buf.read()


def _sum_aligned_stack_rows(
    rows: Sequence[Sequence[float | None]],
    width: int,
) -> tuple[float | None, ...]:
    """Per-series sums when every row has ``width`` finite values; else all ``None``."""
    acc: list[list[float]] = [[] for _ in range(width)]
    for tup in rows:
        if len(tup) != width:
            continue
        if not all(x is not None for x in tup):
            continue
        for i in range(width):
            acc[i].append(float(tup[i]))  # type: ignore[arg-type]
    if not acc[0]:
        return tuple(None for _ in range(width))
    return tuple(sum(acc[i]) for i in range(width))


def _bucket_weekly_stacked_n(
    points: Sequence[tuple[date, Sequence[float | None]]],
    width: int,
    subtitle: str,
) -> tuple[list[date], list[tuple[float | None, ...]], str]:
    chunks: list[list[tuple[date, Sequence[float | None]]]] = []
    cur: list[tuple[date, Sequence[float | None]]] = []
    for p in points:
        cur.append(p)
        if len(cur) >= 7:
            chunks.append(cur)
            cur = []
    if cur:
        chunks.append(cur)
    out_dates: list[date] = []
    out_vals: list[tuple[float | None, ...]] = []
    for ch in chunks:
        out_dates.append(ch[0][0])
        out_vals.append(_sum_aligned_stack_rows([t for _, t in ch], width))
    return out_dates, out_vals, subtitle


def _bucket_monthly_stacked_n(
    points: Sequence[tuple[date, Sequence[float | None]]],
    width: int,
) -> tuple[list[date], list[tuple[float | None, ...]], str]:
    buckets: dict[tuple[int, int], list[Sequence[float | None]]] = {}
    order: list[tuple[int, int]] = []
    for d, tup in points:
        key = (d.year, d.month)
        if key not in buckets:
            buckets[key] = []
            order.append(key)
        buckets[key].append(tup)
    out_dates: list[date] = []
    out_vals: list[tuple[float | None, ...]] = []
    for key in order:
        y, m = key
        out_dates.append(date(y, m, 1))
        out_vals.append(_sum_aligned_stack_rows(buckets[key], width))
    return out_dates, out_vals, ""


def _aggregate_multi_series_for_chart(
    points: Sequence[tuple[date, Sequence[float | None]]],
    width: int,
) -> tuple[list[date], list[tuple[float | None, ...]], str, ChartTimeGranularity]:
    raw_dates = [d for d, _ in points]
    raw_vals = [tuple(t) for _, t in points]
    n = len(points)
    if n == 0:
        return [], [], "", "day"

    def daily() -> tuple[list[date], list[tuple[float | None, ...]], str, ChartTimeGranularity]:
        return raw_dates, raw_vals, "", "day"

    if n <= 7:
        return daily()
    if n <= 60:
        return daily()
    if n <= 365:
        d, v, s = _bucket_weekly_stacked_n(points, width, "Weekly totals (sum per 7-day bucket)")
        return d, v, s, "week"

    dates, vals, _ = _bucket_monthly_stacked_n(points, width)
    if len(dates) > 24:
        dates = dates[-24:]
        vals = vals[-24:]
        return dates, vals, "Monthly totals - last 24 months shown", "month"
    return dates, vals, "Monthly totals (sum per calendar month)", "month"


def aggregate_single_series_for_chart(
    points: Sequence[tuple[date, int | None]],
) -> tuple[list[date], list[float | None], str, ChartTimeGranularity]:
    """
    Reduce point count for long ranges.

    Returns (dates, values with None gaps, subtitle, time granularity for x-axis labels).
    """
    raw_dates = [d for d, _ in points]
    raw_vals = [v for _, v in points]
    n = len(points)
    if n == 0:
        return [], [], "", "day"

    def daily() -> tuple[list[date], list[float | None], str, ChartTimeGranularity]:
        return raw_dates, [float(v) if v is not None else None for v in raw_vals], "", "day"

    if n <= 7:
        return daily()
    if n <= 60:
        return daily()
    if n <= 365:
        d, v, s = _bucket_weekly(points, "Weekly totals (sum per 7-day bucket)")
        return d, v, s, "week"

    dates, vals, _ = _bucket_monthly(points, "")
    if len(dates) > 24:
        dates = dates[-24:]
        vals = vals[-24:]
        return dates, vals, "Monthly totals - last 24 months shown", "month"
    return dates, vals, "Monthly totals (sum per calendar month)", "month"


def _bucket_weekly(
    points: Sequence[tuple[date, int | None]],
    subtitle: str,
) -> tuple[list[date], list[float | None], str]:
    chunks: list[list[tuple[date, int | None]]] = []
    cur: list[tuple[date, int | None]] = []
    for p in points:
        cur.append(p)
        if len(cur) >= 7:
            chunks.append(cur)
            cur = []
    if cur:
        chunks.append(cur)
    out_dates: list[date] = []
    out_vals: list[float | None] = []
    for ch in chunks:
        d0 = ch[0][0]
        vs = [x[1] for x in ch]
        if all(x is None for x in vs):
            out_vals.append(None)
        else:
            out_vals.append(float(sum(x for x in vs if x is not None)))
        out_dates.append(d0)
    return out_dates, out_vals, subtitle


def _bucket_monthly(
    points: Sequence[tuple[date, int | None]],
    subtitle: str,
) -> tuple[list[date], list[float | None], str]:
    buckets: dict[tuple[int, int], list[int | None]] = {}
    order: list[tuple[int, int]] = []
    for d, v in points:
        key = (d.year, d.month)
        if key not in buckets:
            buckets[key] = []
            order.append(key)
        buckets[key].append(v)
    out_dates: list[date] = []
    out_vals: list[float | None] = []
    for key in order:
        vs = buckets[key]
        if all(x is None for x in vs):
            out_vals.append(None)
        else:
            out_vals.append(float(sum(x for x in vs if x is not None)))
        y, m = key
        out_dates.append(date(y, m, 1))
    return out_dates, out_vals, subtitle


def aggregate_dual_series_for_chart(
    points: Sequence[tuple[date, StackedPoint]],
) -> tuple[list[date], list[StackedPoint], str, ChartTimeGranularity]:
    """Same bucketing rules as ``aggregate_single_series_for_chart``, for two aligned series."""
    d, v, s, g = _aggregate_multi_series_for_chart([(d, p) for d, p in points], 2)
    return d, [cast(StackedPoint, t) for t in v], s, g


def aggregate_triple_series_for_chart(
    points: Sequence[tuple[date, StackedTriplePoint]],
) -> tuple[list[date], list[StackedTriplePoint], str, ChartTimeGranularity]:
    """Same bucketing rules as ``aggregate_dual_series_for_chart``, for three aligned series."""
    d, v, s, g = _aggregate_multi_series_for_chart([(d, p) for d, p in points], 3)
    return d, [cast(StackedTriplePoint, t) for t in v], s, g


def _format_y_tick_cf(value: float, _pos: int | None = None) -> str:
    """Compact Y ticks like Cloudflare analytics (0, 5k, 10k, 25.74k)."""
    if value == 0:
        return "0"
    x = float(value)
    axv = abs(x)
    if axv >= 1_000_000_000:
        v = x / 1_000_000_000.0
        s = trim_decimal(v, 2)
        return f"{s}B"
    if axv >= 1_000_000:
        v = x / 1_000_000.0
        s = trim_decimal(v, 2)
        return f"{s}M"
    if axv >= 1000:
        v = x / 1000.0
        s = trim_decimal(v, 2)
        return f"{s}k"
    if x == int(x):
        return str(int(x))
    return trim_decimal(x, 1)


def _format_y_tick_bytes(value: float, _pos: int | None = None) -> str:
    """Y-axis labels for byte totals (KB / MB / GB), not SI millions/billions."""
    if value <= 0:
        return "0B" if value == 0 else ""
    return format_bytes_human(int(max(0, round(value))))


def _x_axis_labels_cf(
    dates: Sequence[date],
    granularity: ChartTimeGranularity,
) -> list[str]:
    """
    X tick text: one style per granularity (no mixing).

    - ``month``: month labels only: ``Apr`` or ``Apr '25`` if the range spans years.
    - ``day`` / ``week``: weekday + day of month for every point: ``Tue 31``, ``Wed 01``, …
    """
    if not dates:
        return []
    if granularity == "month":
        y0, y1 = dates[0].year, dates[-1].year
        multi_year = y0 != y1
        return [d.strftime("%b '%y") if multi_year else d.strftime("%b") for d in dates]

    # Daily or weekly buckets: always DoW + day (including across month boundaries).
    return [f"{calendar.day_abbr[d.weekday()]} {d.day:02d}" for d in dates]


def _xtick_indices(n: int, max_labels: int = 11) -> list[int]:
    """Sparse tick indices so labels do not crowd the axis."""
    if n <= 0:
        return []
    if n <= max_labels:
        return list(range(n))
    step = max(1, (n - 1) // (max_labels - 1))
    idx = list(range(0, n, step))
    if idx[-1] != n - 1:
        idx.append(n - 1)
    return sorted(set(idx))


def render_single_line_chart_bytes(
    dates: Sequence[date],
    values: Sequence[float | None],
    *,
    title: str,
    subtitle: str,
    y_label: str,
    theme: Theme,
    time_granularity: ChartTimeGranularity = "day",
) -> bytes:
    """Single-series line chart with markers and compact axis ticks."""
    series = [(y_label, theme.accent, list(values))]
    return _line_chart_n_series(
        dates,
        series,
        title=title,
        subtitle=subtitle,
        theme=theme,
        time_granularity=time_granularity,
    )


def _line_chart_n_series(
    dates: Sequence[date],
    series: Sequence[tuple[str, str, Sequence[float | None]]],
    *,
    title: str,
    subtitle: str,
    theme: Theme,
    time_granularity: ChartTimeGranularity,
) -> bytes:
    """Render one chart from N line series using shared styling logic."""
    fig_w = min(theme.content_width_in(), 7.1)
    fig_h = fig_w * 0.35
    fig, ax = plt.subplots(figsize=(fig_w, fig_h), facecolor="white")
    if not dates:
        ax.text(0.5, 0.5, "No data", ha="center", va="center", color=theme.muted)
    else:
        x = list(range(len(dates)))
        plot_kw: dict[str, Any] = {
            "linewidth": CHART_LINE_WIDTH,
            "solid_capstyle": "round",
            "zorder": 3,
        }
        plotted_series: list[tuple[str, str]] = []
        ymax = 0.0
        for label, color, raw_values in series:
            y_values: list[float] = []
            for value in raw_values:
                if value is None:
                    y_values.append(float("nan"))
                    continue
                fv = float(value)
                y_values.append(fv)
                ymax = max(ymax, fv)
            if len(y_values) < len(dates):
                y_values.extend([float("nan")] * (len(dates) - len(y_values)))
            elif len(y_values) > len(dates):
                y_values = y_values[: len(dates)]
            ax.plot(x, y_values, color=color, label=label, **plot_kw, **_marker_style(color))
            if any(math.isfinite(v) for v in y_values):
                plotted_series.append((label, color))

        if ymax > 0:
            ax.set_ylim(0, ymax * 1.08)

        tick_idx = _xtick_indices(len(dates))
        full_labels = _x_axis_labels_cf(dates, time_granularity)
        ax.set_xticks(tick_idx)
        ax.set_xticklabels(
            [full_labels[i] for i in tick_idx],
            rotation=0,
            ha="center",
            fontsize=7,
            color=theme.muted,
        )
        ax.yaxis.set_major_formatter(ticker.FuncFormatter(_format_y_tick_cf))
        ax.tick_params(axis="y", labelsize=7, colors=theme.muted)
        ax.grid(axis="both", linestyle="-", alpha=0.2, color=theme.border)
        ax.set_axisbelow(True)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

        if plotted_series:
            handles = [
                Line2D(
                    [0],
                    [0],
                    color=color,
                    lw=CHART_LINE_WIDTH,
                    **_marker_style(color),
                    label=label,
                )
                for label, color in plotted_series
            ]
            ax.legend(
                handles=handles,
                loc="upper right",
                frameon=False,
                fontsize=7,
                handlelength=1.1,
                handletextpad=0.45,
                borderaxespad=0.5,
            )
            leg = ax.get_legend()
            if leg is not None:
                for text in leg.get_texts():
                    text.set_color(theme.slate)
    ax.set_title(title, fontsize=10, color=theme.slate, pad=8)
    if subtitle:
        fig.text(0.5, 0.02, subtitle, ha="center", fontsize=7, color=theme.muted)
    return _save_figure_bytes(fig, theme=theme)


def render_triple_line_chart_bytes(
    dates: Sequence[date],
    triples: Sequence[StackedTriplePoint],
    *,
    title: str,
    subtitle: str,
    legend_a: str,
    legend_b: str,
    legend_c: str,
    theme: Theme,
    time_granularity: ChartTimeGranularity = "day",
) -> bytes:
    """Three generic lines from aligned ``(a, b, c)`` per time bucket."""
    series: list[tuple[str, str, list[float | None]]] = [
        (legend_a, theme.accent, [a for a, _, _ in triples]),
        (legend_b, theme.primary, [b for _, b, _ in triples]),
        (legend_c, theme.tertiary, [c for _, _, c in triples]),
    ]
    return _line_chart_n_series(
        dates,
        series,
        title=title,
        subtitle=subtitle,
        theme=theme,
        time_granularity=time_granularity,
    )


def render_dual_line_chart_bytes(
    dates: Sequence[date],
    pairs: Sequence[StackedPoint],
    *,
    title: str,
    subtitle: str,
    legend_a: str,
    legend_b: str,
    theme: Theme,
    time_granularity: ChartTimeGranularity = "day",
) -> bytes:
    """Two lines: ``legend_a`` (first series) then ``legend_b`` (second)."""
    series: list[tuple[str, str, list[float | None]]] = [
        (legend_a, theme.accent, [a for a, _ in pairs]),
        (legend_b, theme.primary, [b for _, b in pairs]),
    ]
    return _line_chart_n_series(
        dates,
        series,
        title=title,
        subtitle=subtitle,
        theme=theme,
        time_granularity=time_granularity,
    )


def prepare_dual_line_daily_series(
    points: Sequence[tuple[date, tuple[int | None, int | None]]],
    theme: Theme,
    *,
    chart_title: str,
    legend_a: str,
    legend_b: str,
) -> tuple[bytes, str]:
    """Two absolute-count lines with the same date bucketing as triple-line charts."""
    as_floats: list[tuple[date, StackedPoint]] = [
        (
            d,
            (
                float(a) if a is not None else None,
                float(b) if b is not None else None,
            ),
        )
        for d, (a, b) in points
    ]
    d, pairs, sub, gran = aggregate_dual_series_for_chart(as_floats)
    if len(d) < 2:
        return b"", sub
    png = render_dual_line_chart_bytes(
        d,
        pairs,
        title=chart_title,
        subtitle=sub,
        legend_a=legend_a,
        legend_b=legend_b,
        theme=theme,
        time_granularity=gran,
    )
    return png, sub


def prepare_triple_line_daily_series(
    points: Sequence[tuple[date, tuple[int | None, int | None, int | None]]],
    theme: Theme,
    *,
    chart_title: str,
    legend_a: str,
    legend_b: str,
    legend_c: str,
) -> tuple[bytes, str]:
    """Same bucketing as dual series; renders three absolute-count lines."""
    as_floats: list[tuple[date, StackedTriplePoint]] = [
        (
            d,
            (
                float(a) if a is not None else None,
                float(b) if b is not None else None,
                float(c) if c is not None else None,
            ),
        )
        for d, (a, b, c) in points
    ]
    d, trips, sub, gran = aggregate_triple_series_for_chart(as_floats)
    if len(d) < 2:
        return b"", sub
    png = render_triple_line_chart_bytes(
        d,
        trips,
        title=chart_title,
        subtitle=sub,
        legend_a=legend_a,
        legend_b=legend_b,
        legend_c=legend_c,
        theme=theme,
        time_granularity=gran,
    )
    return png, sub


def prepare_single_line_daily_series(
    points: Sequence[tuple[date, int | None]],
    theme: Theme,
    *,
    chart_title: str,
    y_axis_label: str,
) -> tuple[bytes, str]:
    """
    Build a time-series PNG from per-day values (None = gap).

    Any stream can call this with its own ``chart_title`` and ``y_axis_label``.
    """
    d, v, sub, gran = aggregate_single_series_for_chart(points)
    if len(d) < 2:
        return b"", sub
    png = render_single_line_chart_bytes(
        d,
        v,
        title=chart_title,
        subtitle=sub,
        y_label=y_axis_label,
        theme=theme,
        time_granularity=gran,
    )
    return png, sub
