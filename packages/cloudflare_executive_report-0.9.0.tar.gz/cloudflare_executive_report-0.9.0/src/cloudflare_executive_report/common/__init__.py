"""Shared cross-command helpers."""
