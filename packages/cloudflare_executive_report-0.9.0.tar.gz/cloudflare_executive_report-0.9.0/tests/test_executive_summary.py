from cloudflare_executive_report.executive.summary import build_executive_summary


def test_build_executive_summary_healthy_zone():
    out = build_executive_summary(
        zone_name="example.com",
        zone_health={
            "zone_status": "active",
            "ssl_mode": "strict",
            "always_https": "on",
            "security_level": "medium",
            "dnssec_status": "active",
            "ddos_protection": "on",
            "security_rules_active": 3,
        },
        dns={"total_queries": 1000, "average_qps": 1.2},
        http={
            "total_requests": 50000,
            "total_requests_human": "50K",
            "cache_hit_ratio": 55.0,
            "encrypted_requests": 49000,
            "encrypted_requests_human": "49K",
        },
        security={
            "total_events": 200,
            "mitigated_count": 200,
            "http_requests_sampled": 50000,
            "http_requests_sampled_human": "50K",
            "not_mitigated_sampled": 49800,
            "not_mitigated_sampled_human": "49.8K",
            "mitigation_rate_pct": 0.4,
            "top_actions": [
                {"action": "managed_challenge", "count": 160},
                {"action": "block", "count": 40},
            ],
        },
        cache={"cache_hit_ratio": 55.0, "served_cf_count": 20000, "served_origin_count": 30000},
        dns_records={
            "total_records": 10,
            "proxied_records": 8,
            "dns_only_records": 2,
            "apex_unproxied_a_aaaa": 0,
        },
        audit={"total_events": 3},
        certificates={
            "total_certificate_packs": 1,
            "expiring_in_30_days": 0,
            "soonest_expiry": "2026-12-01T00:00:00Z",
        },
        warnings=[],
    )
    assert out["verdict"] == "healthy"
    assert out["kpis"]["security"]["threats_mitigated"] == 200
    assert out["kpis"]["security"]["mitigated_events_human"] == "200"
    assert out["kpis"]["security"]["mitigation_rate_pct"] == 0.4
    assert "security_level" not in out["kpis"]["platform"]
    assert out["kpis"]["traffic"]["encrypted_gap_pct"] >= 0.0
    assert out["kpis"]["dns"]["average_qps"] == 1.2
    assert "takeaways_categorized" in out


def test_build_executive_summary_warning_with_warnings_and_inactive_zone():
    out = build_executive_summary(
        zone_name="example.com",
        zone_health={
            "zone_status": "pending",
            "ssl_mode": "full",
            "always_https": "off",
            "security_level": "medium",
            "dnssec_status": "disabled",
            "ddos_protection": "on",
            "security_rules_active": 0,
        },
        dns={"total_queries": 10, "average_qps": 0.1},
        http={"total_requests": 10, "total_requests_human": "10", "cache_hit_ratio": 0.0},
        security={"top_actions": [{"action": "block", "count": 1}]},
        cache=None,
        dns_records={
            "total_records": 0,
            "proxied_records": 0,
            "dns_only_records": 0,
            "apex_unproxied_a_aaaa": 0,
        },
        audit={"total_events": 0},
        certificates={
            "total_certificate_packs": 0,
            "expiring_in_30_days": 0,
            "soonest_expiry": None,
        },
        warnings=["No DNS cache entry for zone example.com on 2026-04-01"],
    )
    assert out["verdict"] == "critical"
    assert "zone_status=pending" in out["verdict_reasons"]
    assert "warnings_present" not in out["verdict_reasons"]
    assert out["warnings_count"] >= 1
    assert len(out["actions"]) >= 1
    assert set(out["takeaways_categorized"].keys()) == {
        "wins",
        "risks",
        "signals",
        "deltas",
    }
    assert all(a not in out["takeaways"] for a in out["actions"])


def test_build_executive_summary_no_actions_when_no_action_rules_match():
    out = build_executive_summary(
        zone_name="example.com",
        zone_health={
            "zone_status": "active",
            "ssl_mode": "strict",
            "always_https": "on",
            "security_level": "high",
            "dnssec_status": "active",
            "ddos_protection": "on",
            "security_rules_active": 3,
        },
        dns={"total_queries": 1000, "average_qps": 1.2},
        http={
            "total_requests": 50000,
            "total_requests_human": "50K",
            "cache_hit_ratio": 55.0,
            "encrypted_requests": 49000,
            "encrypted_requests_human": "49K",
        },
        security={
            "total_events": 200,
            "mitigated_count": 200,
            "http_requests_sampled": 50000,
            "http_requests_sampled_human": "50K",
            "not_mitigated_sampled": 49800,
            "not_mitigated_sampled_human": "49.8K",
            "mitigation_rate_pct": 0.4,
        },
        cache={"cache_hit_ratio": 55.0, "served_cf_count": 20000, "served_origin_count": 30000},
        dns_records={
            "total_records": 10,
            "proxied_records": 8,
            "dns_only_records": 2,
            "apex_unproxied_a_aaaa": 0,
        },
        audit={"total_events": 10},
        certificates={
            "total_certificate_packs": 1,
            "expiring_in_30_days": 0,
            "soonest_expiry": "2026-12-01T00:00:00Z",
        },
        warnings=[],
    )
    assert out["actions"] == []


def test_build_executive_summary_fallback_threats_from_top_actions():
    out = build_executive_summary(
        zone_name="example.com",
        zone_health={"zone_status": "active"},
        dns={},
        http={"total_requests": 1, "total_requests_human": "1"},
        security={
            "top_actions": [
                {"action": "block", "count": 3},
                {"action": "managed_challenge", "count": 4},
                {"action": "log", "count": 9},
            ]
        },
        cache={},
        dns_records={
            "total_records": 1,
            "proxied_records": 1,
            "dns_only_records": 0,
            "apex_unproxied_a_aaaa": 0,
        },
        audit={"total_events": 0},
        certificates={
            "total_certificate_packs": 1,
            "expiring_in_30_days": 0,
            "soonest_expiry": None,
        },
        warnings=[],
    )
    assert out["kpis"]["security"]["threats_mitigated"] == 7


def test_build_executive_summary_uses_adaptive_http_takeaway_when_available():
    out = build_executive_summary(
        zone_name="example.com",
        zone_health={"zone_status": "active"},
        dns={"total_queries": 100, "average_qps": 0.2},
        http={"total_requests": 860007},
        security={"mitigated_count": 10, "mitigation_rate_pct": 1.0},
        cache={},
        http_adaptive={
            "status_4xx_rate_pct": 0.99,
            "status_5xx_rate_pct": 0.02,
            "origin_response_duration_avg_ms": 264.2,
            "latency_p50_ms": 10.0,
            "latency_p95_ms": 50.0,
        },
        dns_records={
            "total_records": 1,
            "proxied_records": 1,
            "dns_only_records": 0,
            "apex_unproxied_a_aaaa": 0,
        },
        audit={"total_events": 1},
        certificates={
            "total_certificate_packs": 1,
            "expiring_in_30_days": 0,
            "soonest_expiry": "2026-08-01T00:00:00Z",
        },
        warnings=[],
    )
    assert any(
        t.startswith("[i]") or t.startswith("[!]") or t.startswith("[OK]") for t in out["takeaways"]
    )


def test_build_executive_summary_apex_and_cert_kpi_fields():
    out = build_executive_summary(
        zone_name="vhsantos.net",
        zone_health={"zone_status": "active", "always_https": "on", "ssl_mode": "strict"},
        dns={"total_queries": 100, "average_qps": 3.97},
        http={
            "total_requests": 1_000_000,
            "total_requests_human": "1.0M",
            "encrypted_requests": 940_000,
            "encrypted_requests_human": "940K",
        },
        security={"mitigated_count": 1000, "mitigation_rate_pct": 0.1},
        cache={},
        dns_records={
            "total_records": 54,
            "proxied_records": 13,
            "dns_only_records": 41,
            "apex_unproxied_a_aaaa": 1,
        },
        audit={"total_events": 46},
        certificates={
            "total_certificate_packs": 2,
            "expiring_in_30_days": 0,
            "soonest_expiry": "2026-05-16T10:27:03Z",
        },
        warnings=[],
    )
    assert out["kpis"]["dns_records"]["apex_protection_status"].startswith("exposed")
    assert out["kpis"]["certificates"]["cert_expires_human"].startswith("2026-05-16")
    assert out["kpis"]["traffic"]["encrypted_gap_pct"] > 5.0
    assert any("Apex record not proxied" in t for t in out["takeaways"])
    assert any("Enable proxy on apex A/AAAA record - hides origin IP." in a for a in out["actions"])


def test_build_executive_summary_includes_baseline_reference_takeaway_when_comparing():
    previous_report = {
        "report_period": {"start": "2026-03-25", "end": "2026-03-31"},
        "zones": [
            {
                "zone_id": "z1",
                "http": {
                    "total_requests": 1000,
                    "cache_hit_ratio": 10.0,
                    "encrypted_requests": 900,
                },
                "security": {"mitigated_count": 10, "mitigation_rate_pct": 1.0},
                "dns": {"total_queries": 500, "average_qps": 0.5},
                "http_adaptive": {
                    "status_4xx_rate_pct": 1.0,
                    "status_5xx_rate_pct": 0.1,
                    "origin_response_duration_avg_ms": 200.0,
                    "latency_p95_ms": 100.0,
                },
                "dns_records": {
                    "proxied_records": 1,
                    "dns_only_records": 1,
                    "apex_unproxied_a_aaaa": 0,
                },
                "zone_health": {"ssl_mode": "strict", "dnssec_status": "active"},
            }
        ],
    }
    previous_zone = previous_report["zones"][0]
    out = build_executive_summary(
        zone_id="z1",
        zone_name="example.com",
        zone_health={"zone_status": "active", "ssl_mode": "strict", "dnssec_status": "active"},
        dns={"total_queries": 600, "average_qps": 0.6},
        http={"total_requests": 1100, "cache_hit_ratio": 11.0, "encrypted_requests": 950},
        security={"mitigated_count": 15, "mitigation_rate_pct": 1.2},
        cache={},
        http_adaptive={
            "status_4xx_rate_pct": 0.9,
            "status_5xx_rate_pct": 0.1,
            "origin_response_duration_avg_ms": 190.0,
            "latency_p95_ms": 95.0,
        },
        dns_records={"proxied_records": 2, "dns_only_records": 1, "apex_unproxied_a_aaaa": 0},
        audit={"total_events": 1},
        certificates={"total_certificate_packs": 1, "expiring_in_30_days": 0},
        warnings=[],
        current_period={"start": "2026-04-01", "end": "2026-04-07"},
        previous_report=previous_report,
        previous_zone=previous_zone,
    )
    assert any("Comparing to: 2026-03-25 to 2026-03-31" in t for t in out["takeaways"])


def test_verdict_dns_only_no_proxied_zero_http_stays_healthy_despite_one_pipeline_warning() -> None:
    out = build_executive_summary(
        zone_name="dns.example",
        zone_health={"zone_status": "active"},
        dns={"total_queries": 10000, "average_qps": 1.0},
        http={"total_requests": 0, "total_requests_human": "0", "cache_hit_ratio": 0.0},
        security={},
        cache={},
        dns_records={
            "total_records": 5,
            "proxied_records": 0,
            "dns_only_records": 5,
            "apex_unproxied_a_aaaa": 0,
        },
        audit={"total_events": 0},
        certificates={"total_certificate_packs": 0},
        warnings=["DNS for zone dns.example on 2026-04-01 unavailable (cache miss)"],
    )
    assert out["verdict"] == "healthy"
    assert "no_http_traffic" not in out["verdict_reasons"]
    assert "warnings_present" not in out["verdict_reasons"]


def test_verdict_proxied_but_zero_http_is_warning() -> None:
    out = build_executive_summary(
        zone_name="www.example.com",
        zone_health={"zone_status": "active"},
        dns={"total_queries": 100, "average_qps": 0.1},
        http={"total_requests": 0, "total_requests_human": "0", "cache_hit_ratio": 0.0},
        security={"mitigated_count": 0, "mitigation_rate_pct": 0.0},
        cache={},
        dns_records={
            "total_records": 3,
            "proxied_records": 2,
            "dns_only_records": 1,
            "apex_unproxied_a_aaaa": 0,
        },
        audit={"total_events": 0},
        certificates={"total_certificate_packs": 1, "expiring_in_30_days": 0},
        warnings=[],
    )
    assert out["verdict"] == "warning"
    assert "no_http_traffic" in out["verdict_reasons"]
    assert "warnings_present" not in out["verdict_reasons"]


def test_verdict_four_pipeline_warnings_add_warnings_present() -> None:
    warns = [
        "DNS for zone example.com on 2026-04-01 unavailable (cache miss)",
        "HTTP for zone example.com on 2026-04-02 unavailable (cache miss)",
        "Security for zone example.com on 2026-04-03 unavailable (cache miss)",
        "Cache for zone example.com on 2026-04-04 unavailable (cache miss)",
    ]
    out = build_executive_summary(
        zone_name="example.com",
        zone_health={"zone_status": "active"},
        dns={"total_queries": 100, "average_qps": 0.1},
        http={"total_requests": 1000, "total_requests_human": "1K", "cache_hit_ratio": 0.0},
        security={"mitigated_count": 0, "mitigation_rate_pct": 0.0},
        cache={},
        dns_records={
            "total_records": 2,
            "proxied_records": 1,
            "dns_only_records": 1,
            "apex_unproxied_a_aaaa": 0,
        },
        audit={"total_events": 0},
        certificates={"total_certificate_packs": 1, "expiring_in_30_days": 0},
        warnings=warns,
    )
    assert out["verdict"] == "warning"
    assert "warnings_present" in out["verdict_reasons"]
    assert any(
        "Missing data for 4 metrics - verdict may be affected." in t for t in out["takeaways"]
    )


def test_verdict_three_pipeline_warnings_no_warnings_present() -> None:
    warns = [
        "DNS for zone example.com on 2026-04-01 unavailable (cache miss)",
        "HTTP for zone example.com on 2026-04-02 unavailable (cache miss)",
        "Security for zone example.com on 2026-04-03 unavailable (cache miss)",
    ]
    out = build_executive_summary(
        zone_name="example.com",
        zone_health={"zone_status": "active"},
        dns={"total_queries": 100, "average_qps": 0.1},
        http={"total_requests": 1000, "total_requests_human": "1K", "cache_hit_ratio": 0.0},
        security={"mitigated_count": 0, "mitigation_rate_pct": 0.0},
        cache={},
        dns_records={
            "total_records": 2,
            "proxied_records": 1,
            "dns_only_records": 1,
            "apex_unproxied_a_aaaa": 0,
        },
        audit={"total_events": 0},
        certificates={"total_certificate_packs": 1, "expiring_in_30_days": 0},
        warnings=warns,
    )
    assert out["verdict"] == "healthy"
    assert "warnings_present" not in out["verdict_reasons"]
    assert not any("Missing data for" in t for t in out["takeaways"])


def test_build_executive_summary_disabled_rules_drops_matching_actions() -> None:
    out = build_executive_summary(
        zone_name="example.com",
        zone_health={
            "zone_status": "active",
            "ssl_mode": "strict",
            "always_https": "on",
            "security_level": "medium",
            "dnssec_status": "disabled",
            "ddos_protection": "on",
            "security_rules_active": 1,
        },
        dns={"total_queries": 10, "average_qps": 0.1},
        http={"total_requests": 100, "encrypted_requests": 100, "cache_hit_ratio": 50.0},
        security={"mitigated_count": 0, "mitigation_rate_pct": 0.0},
        cache={},
        http_adaptive={},
        dns_records={"apex_unproxied_a_aaaa": 0},
        audit={"total_events": 0},
        certificates={"total_certificate_packs": 1, "expiring_in_30_days": 0},
        warnings=[],
        disabled_rules=["dnssec"],
    )
    assert not any("Enable DNSSEC" in a for a in out["actions"])
