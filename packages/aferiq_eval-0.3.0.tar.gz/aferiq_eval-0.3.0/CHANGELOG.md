# Changelog

All notable changes to `aferiq-eval` (internal namespace: `rageval`).

This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.0] — 2026-05-16

### Added
- **`aferiq.integrations.*`** — every framework integration is now reachable
  under the canonical aferiq namespace. `from aferiq.integrations.langchain
  import RAGEvalCallbackHandler` works (previously: ModuleNotFoundError;
  users had to fall back to `rageval.integrations.langchain`). 9 thin
  shim modules: `langchain`, `llamaindex`, `agent_callback`, `langgraph`,
  `openai_patch`, `anthropic_patch`, `openai_assistants`, `tracing`,
  `_context`. Each re-exports its `rageval.integrations.*` counterpart
  via `from … import *` so class identity is preserved across namespaces.
- **`end_trajectory(goal=...)`** — agent integrations driving trajectories
  manually can now override the goal at finalisation time, useful when the
  goal wasn't known at `start_trajectory()` (e.g. a callback handler that
  only learns user intent partway through).
- **`AferiqAgentCallbackHandler.on_tool_start`** — handler now hooks
  on_tool_start in addition to on_tool_end. Reads tool name from
  `serialized["name"]` (LangChain), `kwargs["name"]` (explicit override),
  or maps from run_id captured at start time. Previously, agents using
  LangGraph-style tool dispatch produced steps with `tool_name=None`,
  silently degrading the `tool_use_correctness` metric.

### Changed
- **`pip install aferiq-eval` no longer pulls litellm.** Moved to the
  optional `[evaluate]` extras. Users running the local LLM judge install
  `pip install "aferiq-eval[evaluate]"`. Tracing-only users (the cloud
  ingest path) drop ~200MB of transitive deps (tiktoken, hf-xet, etc).
  When the local judge runs without litellm installed, the error message
  points at the right install command.
- **`aferiq.start()` is now verbose by default** (was silent). Prints the
  same 5-line boot summary as `aferiq.init()` plus the auto-patch
  status. Pass `verbose=False` in CI/production loggers to opt out.
  Rationale: the recommended onboarding path was less observable than
  the explicit one — silent failures on first run cost trust.
- README + `docs/{pt,en}/integrations.md` rewritten to use the
  `aferiq-eval` package name and the `aferiq` import namespace
  throughout. `rageval` continues to work as an alias.

## [0.2.5] — 2026-05-10

### Changed
- `aferiq.start()` now passes `emit_standalone=True` when auto-patching OpenAI / Anthropic SDKs. Standalone LLM calls (no enclosing `@trace` / agent context) now emit a trace each instead of being dropped. Matches user expectation for the 1-line `start()` integration.

## [0.2.4] — 2026-05-09

### Added
- **`AFERIQ_DSN`** — single env var that bundles API key + ingest URL, Sentry-style. `aferiq.init()` parses it transparently; explicit `AFERIQ_API_KEY` + `AFERIQ_INGEST_URL` continue to work. Reduces the env surface from two vars to one for the typical case.

## [0.2.3] — 2026-05-09

### Fixed
- `import aferiq` no longer requires `langchain-core` to be installed. The langchain integration was imported eagerly at package import time, which broke any user who installed `aferiq-eval` without the `[langchain]` extra. Now imported lazily on first use.
- Bumped `pyproject.toml#version` to 0.2.3 (had drifted to 0.2.1, mismatched the actual API shape).

## [0.2.2] — 2026-05-09

### Added
- **`aferiq.start()`** — 1-line integration. Wraps `aferiq.init()` + auto-patching of OpenAI and Anthropic SDKs in a single call so that `import aferiq; aferiq.start()` is the entire boilerplate. Standalone LLM calls and `@trace`-decorated functions are captured without further wiring.
- Agent eval support — `AgentTrace`, `AgentStep`, `evaluate_agent()` (alongside the existing single-turn `EvalSample` / `evaluate()` paths).
- `aferiq-trace-run` wrapper command. Auto-instruments OpenAI + Anthropic SDKs to capture tokens + latency per LLM call without touching application code.
- `AferiqAgentCallbackHandler` — single callback that captures full trajectories from LangChain `AgentExecutor` and LangGraph state machines.
- `AferiqAssistantHandler` — streaming event handler for OpenAI Assistants API.
- 4 agent metrics: `trajectory_quality`, `tool_use_correctness`, `goal_completion`, `cost_efficiency` (3 LLM-judged + 1 computational).
- New `prompts/` files (PT-BR + EN) for the agent metrics.
- `examples/` runnable demos for each integration path.

### Changed
- `TraceHandler` type widened to accept either `EvalSample` or `AgentTrace` (`Trace = Union[EvalSample, AgentTrace]`). Existing handlers keep working — the new shape only surfaces when an agent integration is active.
- `CloudClient.send` / `AsyncCloudClient.send` now dispatch by trace shape — RAG and agent traces serialise to different ingestion payloads.
- Hallucination judge prompt extended to emit per-claim `verdict` (grounded/partial/invented/contradicted) and `chunk_idx` (which retrieved chunk would have supported the claim, or null).

## [0.2.1] — 2026-05-08

### Added
- **`aferiq init` CLI command** — interactive setup that drops the user from `pip install aferiq-eval` to first trace in seconds. Detects framework by scanning project imports (LangChain, LangGraph, CrewAI, LlamaIndex, Haystack, AutoGen, Pydantic AI, OpenAI/Anthropic SDKs), prompts for the API key via stdin (hidden, never as a CLI arg, never stored), writes/edits `.env` preserving existing variables, ensures `.env` is in `.gitignore`, and adds `import aferiq; aferiq.init()` to the detected entry point (`main.py` / `app.py` / `server.py` / etc) right after any module docstring or shebang. Idempotent — re-running is a safe no-op. Both `aferiq init` and `rageval init` resolve to the same command.
- **`aferiq.init(verbose=True, probe=True)`** — boot-time diagnostic. `verbose=True` (default) prints a 4-line summary on first init: state ✓/✗, endpoint, redact_pii flag, and probe status. `probe=True` (default) sends a HEAD request to the ingest URL and surfaces the result inline:
    ```
    [aferiq] ✓ tracing initialized
    [aferiq]   endpoint: https://aferiq.com.br/api/v1/traces
    [aferiq]   redact_pii: True (BR patterns)
    [aferiq]   workspace probe: 200 OK (key valid)
    ```
  Bad config surfaces immediately (`401 (key invalid or revoked)`, `404 (endpoint not found)`, `connection refused`, `timeout`) instead of silently dropping traces. Probe failures DO NOT prevent handler registration — the app keeps running normally with the standard per-trace warnings.
- New `aferiq` CLI entry point alongside `rageval` (both registered in `[project.scripts]`).
- 26 new tests across `test_cli_init.py` (env-file upsert, gitignore, prepend init, full CLI flow with `CliRunner`) and `TestVerboseAndProbe` in `test_cloud.py` (stdout assertions, probe status codes, network-error swallowing).

### Changed
- Existing init tests in `test_cloud.py` now pass `verbose=False, probe=False` so they stay silent and don't make network calls.

## [0.2.0] — 2026-05-08

### Added
- **Plug-and-play cloud setup** via `aferiq.init()` — collapses the 30+ lines of boilerplate (regex redactor + handler + httpx.post + register_trace_handler) that customers used to copy-paste into a single function call. Reads `AFERIQ_API_KEY` and `AFERIQ_INGEST_URL` from env, registers a default handler that POSTs traces with PII redaction by default, and is idempotent + no-op when env is missing. Full integration is now:
    ```python
    import aferiq
    aferiq.init()
    chain.invoke(input, config={"callbacks": [aferiq.handler()]})
    ```
- New top-level module `aferiq` (re-exports everything from `rageval`). Both `import aferiq` and `import rageval` work — `aferiq` is preferred going forward, matching the PyPI package name.
- `aferiq.handler()` factory — returns a fresh `RAGEvalCallbackHandler` per call (concurrent-safe).
- `aferiq.redact_pii_br(text)` — public BR-PII regex redactor (CPF/CNPJ/RG/CEP/email/phone). Idempotent, handles empty input.
- 20 new tests in `test_cloud.py` covering redactor, init lifecycle (env, kwargs, placeholder, idempotency), handler registration (EvalSample + AgentTrace serialization, network error swallowing, 4xx/5xx logging without raising), and handler factory.

### Changed
- Bump from 0.1.x to 0.2.0 because the new `init()` + `handler()` API is the recommended path going forward and changes the integration surface meaningfully (though `register_trace_handler` and `RAGEvalCallbackHandler` continue to work for users who want manual control).

## [0.1.1] — 2026-05-08

### Fixed
- `RAGEvalCallbackHandler` now emits traces reliably with **LCEL chains**. Previously, chains composed with `RunnableParallel` (e.g. `{"context": retriever | format_docs, "question": ...} | prompt | llm`) skipped emission because the handler required `on_retriever_end` to fire — which doesn't propagate consistently from inside a parallel map. The handler now tracks the outermost chain by `run_id` and emits on `on_chain_end`, with answer captured from `on_llm_end`/`on_chat_model_end` OR fallback-extracted from chain outputs.
- `RAGEvalCallbackHandler` now listens to `on_chat_model_end` (not just `on_llm_end`) so modern `ChatOpenAI` / `ChatAnthropic` integrations capture answers correctly.
- Empty/missing context no longer blocks emission. If `on_retriever_end` doesn't fire (LCEL nested case), the trace still goes through with `context=[]` — better than dropping the trace silently.

### Added
- `RAGEvalCallbackHandler.on_chain_error` resets internal state so a failed run doesn't poison the next one.
- Query extraction now also looks at `inputs["messages"]` (last message's `.content`) and accepts a raw string input for chat-style chains.

## [0.0.1] — 2026-05-06

### Added
- Single-turn RAG evaluation library (Brazilian Portuguese vertical).
- 3 metrics: `faithfulness`, `citation_accuracy`, `hallucination`.
- LangChain + LlamaIndex callback integrations.
- `@trace` decorator with auto-detection of common parameter names.
- `CloudClient` for shipping traces to the aferiq cloud API.
- CLI: `rageval evaluate --dataset traces.jsonl --metrics faithfulness`.
- Disk + memory caching backends.
