"""Quickstart: @trace decorator + batch evaluation.

Demonstrates the decorator-based integration pattern:
    1. Decorate your RAG function with @trace
    2. Register a handler that collects samples
    3. Run the RAG normally (multiple invocations)
    4. Evaluate the collected samples in batch

Pré-requisitos:
    pip install -e packages/lib
    export OPENAI_API_KEY=sk-...

Rodar:
    python packages/lib/examples/integration_decorator.py
"""

from __future__ import annotations

from rageval import (
    EvalSample,
    evaluate_samples,
    register_trace_handler,
    trace,
)
from rageval.cache import DiskCache
from rageval.judge import Judge

# 1) handler que coleta os traces na memória
collected: list[EvalSample] = []
register_trace_handler(collected.append)


# 2) decora a função RAG (substitua pelo seu retriever + LLM real)
@trace
def my_rag(query: str, context: list[str]) -> str:
    # Em produção, algo como:
    #   chunks = retriever.search(query)
    #   answer = llm.generate(query, chunks)
    # Aqui: stub para o exemplo
    return f"Resposta stub para: '{query}' usando {len(context)} chunks"


def main() -> None:
    # 3) rode o RAG normalmente — cada chamada vira um trace coletado
    samples = [
        (
            "Qual o prazo do CDC para arrependimento?",
            ["Art. 49 do CDC: 7 dias contados do recebimento."],
        ),
        (
            "Qual o faturamento limite do MEI em 2024?",
            ["MEI tem limite de R$ 81.000,00 anuais conforme LC 123/2006."],
        ),
        (
            "Quem pode usar o Simples Nacional?",
            [
                "Microempresas (até R$ 360 mil/ano) e empresas de pequeno porte "
                "(até R$ 4,8 milhões/ano)."
            ],
        ),
    ]
    for query, context in samples:
        my_rag(query, context)

    print(f"Capturadas {len(collected)} amostras\n")

    # 4) avalie em batch
    result = evaluate_samples(
        collected,
        metrics=["faithfulness"],
        judge=Judge(model="gpt-4o-mini", cache=DiskCache()),
        language="pt",
    )

    print(result)
    print()
    print("Agregado:")
    for metric, mean in result.aggregate.items():
        print(f"  {metric}: {mean:.3f}")


if __name__ == "__main__":
    main()
