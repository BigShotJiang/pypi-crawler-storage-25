# Examples

Runnable scripts demonstrating aferiq's RAG and agent capture paths.

## Quickstart

All examples assume:

```bash
pip install rageval
export OPENAI_API_KEY=sk-...
export RAGEVAL_API_KEY=rg_pk_live_...   # optional — without it, traces print to stdout
```

Plus framework-specific extras:

| Example | Extras |
|---|---|
| `langchain_agent_executor.py` | `pip install 'rageval[langchain]' langchain langchain-openai` |
| `langgraph_agent.py` | `pip install 'rageval[langgraph]' langchain-openai` |

## Running

Always wrap your command in `aferiq-trace-run` so OpenAI/Anthropic SDK calls
get token + latency capture:

```bash
aferiq-trace-run python langchain_agent_executor.py
```

Without `aferiq-trace-run`, the trajectory still captures agent decisions and
tool calls, but LLM steps will have no token counts or latency — those come
from the SDK monkey patches.

## What gets shipped

When `RAGEVAL_API_KEY` is set, every captured trace POSTs to
`https://api.rageval.dev/v1/traces` (override with `RAGEVAL_BASE_URL` env
var). Each agent run becomes:

- **1 root row**: goal, final answer, scores (when judges run)
- **N step rows**: each tool call, agent decision, LLM step — same
  `parent_trace_id` linking back to the root

The dashboard auto-detects the trace shape: agent runs render as a
step-by-step tree; RAG traces stay claim-by-claim.

## Don't have agents yet?

The single-turn RAG path still works the same way:

```python
from rageval import trace, register_trace_handler
from rageval.client import CloudClient

register_trace_handler(CloudClient.from_env().send)

@trace
def my_rag(query: str, context: list[str]) -> str:
    return llm.generate(query, context)
```

No need for `aferiq-trace-run` in the RAG path — the `@trace` decorator
captures input/output directly.
