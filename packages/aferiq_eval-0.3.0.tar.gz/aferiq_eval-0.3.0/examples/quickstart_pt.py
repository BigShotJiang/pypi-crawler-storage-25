"""Quickstart em PT-BR — exemplo end-to-end.

Inclui 3 amostras desenhadas pra estressar a métrica:
  1. Resposta fiel ao contexto
  2. Resposta inventou um número (alucinação genérica)
  3. Resposta inventou conteúdo de Lei BR (alucinação BR-específica)

Pré-requisitos:
    pip install -e packages/lib
    export OPENAI_API_KEY=sk-...

Rodar:
    python packages/lib/examples/quickstart_pt.py
"""

from __future__ import annotations

from rageval import evaluate
from rageval.cache import DiskCache
from rageval.judge import Judge

queries = [
    "Qual o prazo do CDC pra arrependimento em compras à distância?",
    "Quantos funcionários a Receita Federal tem?",
    "O que diz a Lei nº 14.815/2024?",
]

contexts = [
    [
        "Art. 49 do CDC: o consumidor pode desistir do contrato em 7 dias contados "
        "do recebimento do produto, sempre que a contratação ocorrer fora do "
        "estabelecimento comercial."
    ],
    [
        "A Receita Federal é o órgão responsável pela administração tributária federal."
    ],
    [
        "A Lei nº 14.815/2024 trata de licitações públicas e contratos administrativos."
    ],
]

answers = [
    # 1. fiel
    "Pelo CDC, o consumidor tem 7 dias pra desistir, contados do recebimento.",
    # 2. inventou número
    "A Receita Federal tem aproximadamente 30.000 funcionários.",
    # 3. inventou conteúdo de lei BR
    "A Lei nº 14.815/2024 estabelece o piso salarial para servidores públicos.",
]


def main() -> None:
    print("Rodando avaliação com 3 amostras…\n")

    judge = Judge(model="gpt-4o-mini", cache=DiskCache())

    result = evaluate(
        queries=queries,
        contexts=contexts,
        answers=answers,
        metrics=["faithfulness"],
        judge=judge,
        language="pt",
    )

    print(result)
    print()
    print("Agregado:")
    for metric, mean in result.aggregate.items():
        print(f"  {metric}: {mean:.3f}")

    print("\nDetalhe por amostra:")
    for i, sr in enumerate(result.samples, start=1):
        score = sr.scores[0]
        print(f"\n[{i}] {sr.sample.query}")
        print(f"    score: {score.score:.2f}")
        print(f"    razão: {score.reasoning}")


if __name__ == "__main__":
    main()
