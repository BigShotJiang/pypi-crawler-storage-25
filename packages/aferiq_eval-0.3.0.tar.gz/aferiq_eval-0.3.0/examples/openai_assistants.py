"""Example: instrument an OpenAI Assistants run with aferiq.

Run with::

    pip install 'aferiq-eval[openai]'
    export OPENAI_API_KEY=sk-...
    export RAGEVAL_API_KEY=rg_pk_live_...   # optional — without it, traces print to stdout
    aferiq-trace-run python openai_assistants.py

The Assistants API exposes a streaming pattern with an event handler.
``AferiqAssistantHandler`` is a drop-in subclass that captures every Run step
(LLM completions + tool calls) into an ``AgentTrace`` and emits it via the
trace handler registry on completion.
"""

from __future__ import annotations

import json
import os
import time

from openai import OpenAI

from rageval import register_trace_handler
from rageval.client import CloudClient
from rageval.integrations.openai_assistants import AferiqAssistantHandler


# A tiny "calculator" tool the Assistant can call. Real tools live behind
# whatever business logic you have.
def calculate(expression: str) -> str:
    if any(c.isalpha() for c in expression):
        return "Erro: somente expressões aritméticas."
    try:
        return str(eval(expression, {"__builtins__": {}}, {}))  # noqa: S307
    except Exception as e:
        return f"Erro: {e}"


def main() -> None:
    if "OPENAI_API_KEY" not in os.environ:
        raise SystemExit("OPENAI_API_KEY not set; example aborts.")

    if os.getenv("RAGEVAL_API_KEY"):
        register_trace_handler(CloudClient.from_env().send)
    register_trace_handler(_print_trace)

    client = OpenAI()

    # Tool spec — aferiq records this into AgentTrace.tool_specs so the
    # tool_use_correctness judge knows what was available to call.
    tools = [
        {
            "type": "function",
            "function": {
                "name": "calculate",
                "description": "Evaluate a simple arithmetic expression.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "expression": {"type": "string"},
                    },
                    "required": ["expression"],
                },
            },
        }
    ]

    assistant = client.beta.assistants.create(
        name="aferiq-demo-calculator",
        instructions=(
            "Você é um assistente que usa a calculadora pra responder "
            "perguntas matemáticas em PT-BR."
        ),
        model="gpt-4o-mini",
        tools=tools,
    )

    thread = client.beta.threads.create()
    client.beta.threads.messages.create(
        thread_id=thread.id,
        role="user",
        content="Quanto é 47 vezes 138, mais 9?",
    )

    handler = AferiqAssistantHandler(
        goal="Quanto é 47 vezes 138, mais 9?",
        tool_specs=tools,
    )

    # Stream the run. The Assistants API may emit `requires_action` events
    # if the model decides to call a tool — for brevity this example only
    # captures the trajectory; real tool call execution is left as an
    # exercise (see Assistants API docs for the full required-action loop).
    with client.beta.threads.runs.stream(
        thread_id=thread.id,
        assistant_id=assistant.id,
        event_handler=handler,
    ) as stream:
        for event in stream:
            if event.event == "thread.run.requires_action":
                # Submit tool outputs (sync execution for the demo).
                tool_outputs = []
                for call in event.data.required_action.submit_tool_outputs.tool_calls:
                    if call.function.name == "calculate":
                        args = json.loads(call.function.arguments)
                        result = calculate(args.get("expression", ""))
                        tool_outputs.append({"tool_call_id": call.id, "output": result})

                with client.beta.threads.runs.submit_tool_outputs_stream(
                    thread_id=thread.id,
                    run_id=event.data.id,
                    tool_outputs=tool_outputs,
                    event_handler=handler,  # same handler, continues capture
                ) as continued:
                    continued.until_done()
                break

        stream.until_done()

    # Cleanup — Assistants persist on OpenAI's side; delete after demo.
    time.sleep(0.5)
    client.beta.assistants.delete(assistant.id)


def _print_trace(trace: object) -> None:
    from rageval.agent import AgentTrace

    if not isinstance(trace, AgentTrace):
        return
    print(f"\n=== AgentTrace · {trace.trace_id[:8]}… ===")
    print(f"Goal: {trace.goal}")
    print(f"Steps ({len(trace.steps)}):")
    for s in trace.steps:
        bits = [f"  [{s.step_index:02d}] {s.step_type}"]
        if s.tool_name:
            bits.append(f"tool={s.tool_name}")
        if s.tokens_in is not None or s.tokens_out is not None:
            bits.append(f"tokens={s.tokens_in or 0}+{s.tokens_out or 0}")
        if s.latency_ms is not None:
            bits.append(f"{s.latency_ms}ms")
        print(" · ".join(bits))
    print(f"Final: {trace.final_answer}")
    print(f"Total tokens: {trace.total_tokens()} · Total latency: {trace.total_latency_ms()}ms")


if __name__ == "__main__":
    main()
