"""Example: instrument a LangGraph state-machine agent with aferiq.

Run with::

    pip install rageval[langgraph] langchain-openai
    export OPENAI_API_KEY=sk-...
    export RAGEVAL_API_KEY=rg_pk_live_...
    aferiq-trace-run python langgraph_agent.py

LangGraph uses LangChain Core's callback API, so the same handler that
captures AgentExecutor runs captures graph.invoke runs too. State
transitions show up as nested ``on_chain_start``/``on_chain_end`` events;
tool calls show up via the standard ``on_tool_*`` hooks.
"""

from __future__ import annotations

import os
from typing import TypedDict

from langchain_core.messages import AIMessage, HumanMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import END, StateGraph

from rageval import register_trace_handler
from rageval.client import CloudClient
from rageval.integrations.langgraph import AferiqAgentCallbackHandler


class State(TypedDict):
    messages: list
    iteration: int


def think(state: State) -> State:
    """One LLM step — picks the next action."""
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    response = llm.invoke(state["messages"])
    return {
        "messages": state["messages"] + [response],
        "iteration": state["iteration"] + 1,
    }


def should_continue(state: State) -> str:
    """Stop after 3 iterations or when LLM signals done."""
    last = state["messages"][-1] if state["messages"] else None
    if state["iteration"] >= 3:
        return END
    if isinstance(last, AIMessage) and "DONE" in (last.content or ""):
        return END
    return "think"


def main() -> None:
    if "OPENAI_API_KEY" not in os.environ:
        raise SystemExit("OPENAI_API_KEY not set; example aborts.")

    if os.getenv("RAGEVAL_API_KEY"):
        register_trace_handler(CloudClient.from_env().send)
    register_trace_handler(_print_trace)

    graph_builder = StateGraph(State)
    graph_builder.add_node("think", think)
    graph_builder.set_entry_point("think")
    graph_builder.add_conditional_edges("think", should_continue)
    graph = graph_builder.compile()

    handler = AferiqAgentCallbackHandler(goal="Explique o que é jurisprudência em 2 frases, depois diga DONE.")

    graph.invoke(
        {
            "messages": [
                HumanMessage(content="Explique o que é jurisprudência em 2 frases. Quando terminar, diga DONE."),
            ],
            "iteration": 0,
        },
        config={"callbacks": [handler]},
    )


def _print_trace(trace: object) -> None:
    from rageval.agent import AgentTrace

    if not isinstance(trace, AgentTrace):
        return
    print(f"\n=== AgentTrace · {trace.trace_id[:8]}… ===")
    print(f"Goal: {trace.goal}")
    print(f"Steps ({len(trace.steps)}):")
    for s in trace.steps:
        bits = [f"  [{s.step_index:02d}] {s.step_type}"]
        if s.tool_name:
            bits.append(f"tool={s.tool_name}")
        if s.tokens_in is not None or s.tokens_out is not None:
            bits.append(f"tokens={s.tokens_in or 0}+{s.tokens_out or 0}")
        if s.latency_ms is not None:
            bits.append(f"{s.latency_ms}ms")
        print(" · ".join(bits))
    print(f"Final: {trace.final_answer}")


if __name__ == "__main__":
    main()
