"""Quickstart: integração com LlamaIndex.

Adiciona o ``RAGEvalCallbackHandler`` ao callback manager global e cada
``query_engine.query(...)`` produz um trace capturado em ``handler.traces``.

Pré-requisitos:
    pip install -e "packages/lib[llamaindex]"
    pip install llama-index llama-index-llms-openai llama-index-embeddings-openai
    export OPENAI_API_KEY=sk-...

Este arquivo mostra a forma idiomática mas requer documentos reais para rodar.
"""

from __future__ import annotations

from rageval import evaluate_samples
from rageval.cache import DiskCache
from rageval.integrations.llamaindex import RAGEvalCallbackHandler
from rageval.judge import Judge


def main() -> None:
    handler = RAGEvalCallbackHandler()

    # from llama_index.core import (
    #     Settings,
    #     SimpleDirectoryReader,
    #     VectorStoreIndex,
    # )
    # from llama_index.core.callbacks import CallbackManager
    #
    # # registra o handler globalmente
    # Settings.callback_manager = CallbackManager([handler])
    #
    # docs = SimpleDirectoryReader("./meus_docs").load_data()
    # index = VectorStoreIndex.from_documents(docs)
    # query_engine = index.as_query_engine(similarity_top_k=4)
    #
    # for question in ["pergunta 1", "pergunta 2", "pergunta 3"]:
    #     query_engine.query(question)

    print(f"Capturadas {len(handler.traces)} amostras\n")

    if not handler.traces:
        print("Nenhuma amostra capturada — descomente o bloco acima e rode com seu índice real.")
        return

    result = evaluate_samples(
        handler.traces,
        metrics=["faithfulness", "citation_accuracy"],
        judge=Judge(model="gpt-4o-mini", cache=DiskCache()),
        language="pt",
    )

    print(result)
    print()
    for metric, mean in result.aggregate.items():
        print(f"  {metric}: {mean:.3f}")


if __name__ == "__main__":
    main()
