"""Quickstart in English — end-to-end example.

Includes 3 samples that exercise the metric:
  1. Faithful answer
  2. Answer with an invented number (generic hallucination)
  3. Answer that fabricates a legal citation

Prerequisites:
    pip install -e packages/lib
    export OPENAI_API_KEY=sk-...

Run:
    python packages/lib/examples/quickstart_en.py
"""

from __future__ import annotations

from rageval import evaluate
from rageval.cache import DiskCache
from rageval.judge import Judge

queries = [
    "What is Brazil's consumer-protection cooling-off period for distance contracts?",
    "How many employees does the Brazilian IRS have?",
    "What does Law 14.815/2024 say?",
]

contexts = [
    [
        "Art. 49 of the CDC: the consumer may withdraw from the contract within 7 days "
        "of receiving the product, whenever the contracting occurs outside the "
        "commercial establishment."
    ],
    ["The Receita Federal is Brazil's federal tax administration agency."],
    ["Law 14.815/2024 governs public procurement and administrative contracts."],
]

answers = [
    "Under the CDC, the consumer has 7 days to withdraw, counted from receipt.",
    "The Receita Federal has approximately 30,000 employees.",
    "Law 14.815/2024 establishes the minimum wage for civil servants.",
]


def main() -> None:
    print("Running evaluation on 3 samples…\n")

    judge = Judge(model="gpt-4o-mini", cache=DiskCache())

    result = evaluate(
        queries=queries,
        contexts=contexts,
        answers=answers,
        metrics=["faithfulness"],
        judge=judge,
        language="en",
    )

    print(result)
    print()
    print("Aggregate:")
    for metric, mean in result.aggregate.items():
        print(f"  {metric}: {mean:.3f}")

    print("\nPer-sample detail:")
    for i, sr in enumerate(result.samples, start=1):
        score = sr.scores[0]
        print(f"\n[{i}] {sr.sample.query}")
        print(f"    score: {score.score:.2f}")
        print(f"    reasoning: {score.reasoning}")


if __name__ == "__main__":
    main()
