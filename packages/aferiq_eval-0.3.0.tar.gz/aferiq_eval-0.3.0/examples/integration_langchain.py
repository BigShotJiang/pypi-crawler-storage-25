"""Quickstart: integração com LangChain.

Plug-and-play: adiciona o ``RAGEvalCallbackHandler`` na lista de callbacks da
sua chain. Cada invocação produz um trace capturado em ``handler.traces``.

Pré-requisitos:
    pip install -e "packages/lib[langchain]"
    pip install langchain langchain-openai langchain-community
    export OPENAI_API_KEY=sk-...

Este arquivo mostra a forma idiomática de integração mas não roda sozinho —
você precisa de um vector store real (Chroma, Qdrant, FAISS, pgvector, etc).
"""

from __future__ import annotations

from rageval import evaluate_samples
from rageval.cache import DiskCache
from rageval.integrations.langchain import RAGEvalCallbackHandler
from rageval.judge import Judge


def main() -> None:
    handler = RAGEvalCallbackHandler()

    # Monte a sua chain como de costume, registrando o handler:
    #
    # from langchain_openai import ChatOpenAI
    # from langchain_chroma import Chroma
    # from langchain_openai import OpenAIEmbeddings
    # from langchain.chains import RetrievalQA
    #
    # llm = ChatOpenAI(model="gpt-4o-mini")
    # vectorstore = Chroma(
    #     collection_name="meus_docs",
    #     embedding_function=OpenAIEmbeddings(),
    # )
    # chain = RetrievalQA.from_chain_type(
    #     llm=llm,
    #     retriever=vectorstore.as_retriever(),
    #     callbacks=[handler],
    # )
    #
    # for question in ["pergunta 1", "pergunta 2", "pergunta 3"]:
    #     chain.invoke({"query": question})

    print(f"Capturadas {len(handler.traces)} amostras\n")

    if not handler.traces:
        print("Nenhuma amostra capturada — descomente o bloco acima e rode com sua chain real.")
        return

    result = evaluate_samples(
        handler.traces,
        metrics=["faithfulness", "hallucination"],
        judge=Judge(model="gpt-4o-mini", cache=DiskCache()),
        language="pt",
    )

    print(result)
    print()
    for metric, mean in result.aggregate.items():
        print(f"  {metric}: {mean:.3f}")


if __name__ == "__main__":
    main()
