"""Example: instrument a LangChain AgentExecutor with aferiq.

Run with::

    pip install rageval[langchain] langchain langchain-community openai
    export OPENAI_API_KEY=sk-...
    export RAGEVAL_API_KEY=rg_pk_live_...   # for shipping; optional for local-only
    aferiq-trace-run python langchain_agent_executor.py

The agent is intentionally small: one calculator tool + one search stub.
The trace captures every LLM call (tokens + latency, via the OpenAI SDK
monkey patch installed by ``aferiq-trace-run``) plus every agent decision
and tool call.
"""

from __future__ import annotations

import os

from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain.tools import Tool
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI

from rageval import register_trace_handler
from rageval.client import CloudClient
from rageval.integrations.agent_callback import AferiqAgentCallbackHandler


def _calculator(expression: str) -> str:
    """Evaluate a simple arithmetic expression. Real agents should sandbox this."""
    try:
        # restrict to ascii digits + arithmetic chars to be a bit safer than raw eval
        if any(c.isalpha() for c in expression):
            return "Erro: somente expressões aritméticas."
        return str(eval(expression, {"__builtins__": {}}, {}))  # noqa: S307
    except Exception as e:
        return f"Erro: {e}"


def _search(query: str) -> str:
    """Stub — returns a fake document. Replace with your retriever."""
    return f"Resultado de busca pra '{query}': [placeholder]"


def main() -> None:
    if "OPENAI_API_KEY" not in os.environ:
        raise SystemExit("OPENAI_API_KEY not set; example aborts.")

    # Optional: ship traces to aferiq cloud. Without RAGEVAL_API_KEY, traces
    # are still printed via the print handler below.
    if os.getenv("RAGEVAL_API_KEY"):
        register_trace_handler(CloudClient.from_env().send)
    register_trace_handler(_print_trace)

    tools = [
        Tool(
            name="calculator",
            func=_calculator,
            description="Avalia uma expressão aritmética. Input: expressão (ex: '3 + 4 * 2').",
        ),
        Tool(
            name="search",
            func=_search,
            description="Busca documentos relevantes pra uma pergunta.",
        ),
    ]

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", "Você é um assistente útil que usa ferramentas quando precisa."),
            ("human", "{input}"),
            MessagesPlaceholder("agent_scratchpad"),
        ]
    )
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    agent = create_openai_tools_agent(llm, tools, prompt)
    executor = AgentExecutor(agent=agent, tools=tools, verbose=False)

    handler = AferiqAgentCallbackHandler(
        goal=None,  # let the handler auto-detect from inputs.input
        tool_specs=[{"name": t.name, "description": t.description} for t in tools],
    )

    result = executor.invoke(
        {"input": "Quanto é 47 vezes 138, e qual o significado da palavra 'usucapião'?"},
        config={"callbacks": [handler]},
    )
    print("\nFinal answer:", result.get("output"))


def _print_trace(trace: object) -> None:
    """Pretty-print every captured trace to stdout."""
    from rageval.agent import AgentTrace

    if not isinstance(trace, AgentTrace):
        return
    print(f"\n=== AgentTrace · {trace.trace_id[:8]}… ===")
    print(f"Goal: {trace.goal}")
    print(f"Steps ({len(trace.steps)}):")
    for s in trace.steps:
        bits = [f"  [{s.step_index:02d}] {s.step_type}"]
        if s.tool_name:
            bits.append(f"tool={s.tool_name}")
        if s.tokens_in is not None or s.tokens_out is not None:
            bits.append(f"tokens={s.tokens_in or 0}+{s.tokens_out or 0}")
        if s.latency_ms is not None:
            bits.append(f"{s.latency_ms}ms")
        print(" · ".join(bits))
    print(f"Final: {trace.final_answer}")
    print(f"Total tokens: {trace.total_tokens()} · Total latency: {trace.total_latency_ms()}ms")


if __name__ == "__main__":
    main()
