"""Validate prompt quality against the BR-labeled dataset.

For each example × metric, calls the real LLM judge and compares the score
to the human-labeled ``expected_<metric>`` field within ``tolerance``.
Reports per-metric agreement %.

Usage:
    export OPENAI_API_KEY=sk-...
    python packages/lib/scripts/validate_prompts.py
    python packages/lib/scripts/validate_prompts.py --judge-model claude-3-5-sonnet-20241022
    python packages/lib/scripts/validate_prompts.py --metrics faithfulness --language pt

Cost note (rough estimate at gpt-4o-mini list price):
    ~20 examples × 3 metrics × 1 language ≈ 60 calls ≈ USD 0.05–0.10 per run.

Bar: ≥85% agreement vs human label per metric (Phase 2/3 Technical DoD).
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from rich.console import Console
from rich.table import Table

from rageval import evaluate
from rageval.cache import DiskCache
from rageval.judge import Judge
from rageval.metrics import available_metrics

DEFAULT_DATASET = Path(__file__).resolve().parent.parent / "datasets" / "br_eval_v1.jsonl"
AGREEMENT_BAR = 0.85

console = Console()


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate prompts against labeled dataset.")
    parser.add_argument("--dataset", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--judge-model", default="gpt-4o-mini")
    parser.add_argument("--language", default="pt", choices=["pt", "en"])
    parser.add_argument(
        "--metrics",
        default=",".join(available_metrics()),
        help=f"Comma-separated metric names (default: {','.join(available_metrics())}).",
    )
    args = parser.parse_args()

    metrics_to_run = [m.strip() for m in args.metrics.split(",") if m.strip()]
    if not metrics_to_run:
        console.print("[red]Provide at least one metric via --metrics.[/]")
        return 2

    if not args.dataset.exists():
        console.print(f"[red]Dataset not found: {args.dataset}[/]")
        return 2

    examples: list[dict[str, object]] = []
    with args.dataset.open(encoding="utf-8") as f:
        for line_no, line in enumerate(f, start=1):
            stripped = line.strip()
            if not stripped:
                continue
            try:
                examples.append(json.loads(stripped))
            except json.JSONDecodeError as e:
                console.print(f"[red]Line {line_no}: invalid JSON ({e}).[/]")
                return 2

    console.print(f"[dim]Dataset: {args.dataset.name} ({len(examples)} examples)[/]")
    console.print(f"[dim]Judge: {args.judge_model} | Language: {args.language}[/]")
    console.print(f"[dim]Metrics: {metrics_to_run}[/]")
    console.print(f"[dim]Agreement bar: {AGREEMENT_BAR:.0%}[/]\n")

    queries = [str(e["query"]) for e in examples]
    contexts = [list(e["context"]) for e in examples]  # type: ignore[arg-type]
    answers = [str(e["answer"]) for e in examples]

    judge = Judge(model=args.judge_model, cache=DiskCache())

    console.print("[dim]Running evaluation (cache: ~/.cache/rageval)…[/]")
    result = evaluate(
        queries=queries,
        contexts=contexts,
        answers=answers,
        metrics=metrics_to_run,
        judge=judge,
        language=args.language,  # type: ignore[arg-type]
    )

    summary_table = Table(title="Agreement vs human label", header_style="bold cyan")
    summary_table.add_column("metric")
    summary_table.add_column("agreement", justify="right")
    summary_table.add_column("verdict", justify="center")

    overall_pass = True
    disagreements_by_metric: dict[str, list[tuple[str, str, float, float]]] = {}

    for metric_name in metrics_to_run:
        expected_field = f"expected_{metric_name}"
        agreements = 0
        comparisons = 0
        disagreements: list[tuple[str, str, float, float]] = []

        for example, sample_result in zip(examples, result.samples, strict=True):
            actual = sample_result.score_for(metric_name)
            if actual is None:
                continue
            expected = example.get(expected_field)
            if expected is None:
                continue
            tolerance = float(example.get("tolerance", 0.15))  # type: ignore[arg-type]
            comparisons += 1
            if abs(actual.score - float(expected)) <= tolerance:  # type: ignore[arg-type]
                agreements += 1
            else:
                disagreements.append(
                    (
                        str(example["id"]),
                        str(example.get("type", "")),
                        float(expected),  # type: ignore[arg-type]
                        actual.score,
                    )
                )

        if comparisons == 0:
            summary_table.add_row(metric_name, "—", "[yellow]N/A[/]")
            continue

        pct = agreements / comparisons
        verdict = "[green]PASS[/]" if pct >= AGREEMENT_BAR else "[red]FAIL[/]"
        summary_table.add_row(
            metric_name,
            f"{pct:.0%} ({agreements}/{comparisons})",
            verdict,
        )
        disagreements_by_metric[metric_name] = disagreements
        if pct < AGREEMENT_BAR:
            overall_pass = False

    console.print(summary_table)

    for metric_name, disagreements in disagreements_by_metric.items():
        if not disagreements:
            continue
        console.print(f"\n[bold]{metric_name} disagreements ({len(disagreements)}):[/]")
        for example_id, type_, expected, actual in disagreements:
            console.print(
                f"  • {example_id} ({type_}): expected {expected:.2f}, got {actual:.2f}"
            )

    console.print()
    if overall_pass:
        console.print("[bold green]✓ All metrics meet the 85% agreement bar.[/]")
        return 0
    console.print("[bold red]✗ One or more metrics below the 85% agreement bar.[/]")
    console.print("[dim]Hand-tune the failing metric's prompt and re-run.[/]")
    return 1


if __name__ == "__main__":
    sys.exit(main())
