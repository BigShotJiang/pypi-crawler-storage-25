"""Verify CHANGELOG.md is in sync with pyproject.toml version.

The release process bumps `pyproject.toml#project.version` and tags
`vX.Y.Z`. Without a separate check, it's easy to forget to add the matching
`## [X.Y.Z] — YYYY-MM-DD` heading to CHANGELOG.md (this happened in the
0.2.2/0.2.3/0.2.4 jumps that drifted the file from 0.2.1 to 0.2.5 with
nothing logged between).

What we enforce:
    The first dated heading (regex `## \\[\\d+\\.\\d+\\.\\d+\\]`) must equal
    the pyproject version.

What we allow:
    A `## [Unreleased]` section above the first dated heading. It's fine to
    accumulate notes there during development — we just don't let a release
    sail past with it untouched.

Usage:
    python scripts/check_changelog.py           # from packages/lib/
    python scripts/check_changelog.py --pyproject path --changelog path
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

HEADING_RE = re.compile(r"^##\s*\[(\d+\.\d+\.\d+)\]", re.MULTILINE)

# Match `version = "x.y.z"` at the start of a line. Restricted to inside the
# [project] table by `pyproject_version()` so we don't pick up a build-system
# pin or a dependency version.
PROJECT_VERSION_RE = re.compile(
    r"^\s*version\s*=\s*[\"'](\d+\.\d+\.\d+[^\"']*)[\"']\s*$",
    re.MULTILINE,
)


def first_dated_version(changelog_text: str) -> str | None:
    match = HEADING_RE.search(changelog_text)
    return match.group(1) if match else None


def pyproject_version(pyproject_text: str) -> str:
    """Extract `project.version` without tomllib (stdlib only since 3.11).

    Scoped to the `[project]` table so we don't pick up `[build-system]` or a
    dependency-pin `version =` line elsewhere in the file.
    """
    project_idx = pyproject_text.find("[project]")
    if project_idx < 0:
        raise ValueError("pyproject.toml has no [project] table")
    next_table = re.search(r"^\[(?!project\b)", pyproject_text[project_idx + 1 :], re.MULTILINE)
    end = project_idx + 1 + next_table.start() if next_table else len(pyproject_text)
    section = pyproject_text[project_idx:end]
    match = PROJECT_VERSION_RE.search(section)
    if not match:
        raise ValueError("Could not find `version = \"...\"` inside [project]")
    return match.group(1)


def main() -> int:
    here = Path(__file__).resolve().parent.parent  # packages/lib/

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pyproject", type=Path, default=here / "pyproject.toml")
    parser.add_argument("--changelog", type=Path, default=here / "CHANGELOG.md")
    args = parser.parse_args()

    pyproject_v = pyproject_version(args.pyproject.read_text(encoding="utf-8"))
    changelog_v = first_dated_version(args.changelog.read_text(encoding="utf-8"))

    if changelog_v is None:
        print(
            f"::error::CHANGELOG.md has no dated ## [X.Y.Z] entry. "
            f"pyproject.toml version is {pyproject_v}.",
            file=sys.stderr,
        )
        return 1

    if changelog_v != pyproject_v:
        print(
            f"::error::CHANGELOG.md top dated entry is [{changelog_v}] but "
            f"pyproject.toml version is {pyproject_v}. Add a "
            f"`## [{pyproject_v}] — YYYY-MM-DD` heading above the existing "
            f"entries (or below `## [Unreleased]` if present).",
            file=sys.stderr,
        )
        return 1

    print(f"CHANGELOG.md in sync with pyproject.toml at version {pyproject_v}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
