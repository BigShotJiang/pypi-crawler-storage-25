"""Re-export of `rageval.integrations.langgraph` under the canonical aferiq.* namespace."""

from rageval.integrations import langgraph as _src
from rageval.integrations.langgraph import *  # noqa: F401, F403

# Mirror the source module's public names so static analysis + dir() work.
__all__ = getattr(_src, "__all__", [n for n in dir(_src) if not n.startswith("_")])
