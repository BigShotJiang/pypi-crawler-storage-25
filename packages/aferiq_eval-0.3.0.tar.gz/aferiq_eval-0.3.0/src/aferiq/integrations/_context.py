"""Re-export of `rageval.integrations._context` under the canonical aferiq.* namespace."""

from rageval.integrations import _context as _src
from rageval.integrations._context import *  # noqa: F401, F403

# Mirror the source module's public names so static analysis + dir() work.
__all__ = getattr(_src, "__all__", [n for n in dir(_src) if not n.startswith("_")])
