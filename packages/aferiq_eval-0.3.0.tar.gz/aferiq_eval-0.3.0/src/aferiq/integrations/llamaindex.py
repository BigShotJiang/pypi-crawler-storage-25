"""Re-export of `rageval.integrations.llamaindex` under the canonical aferiq.* namespace."""

from rageval.integrations import llamaindex as _src
from rageval.integrations.llamaindex import *  # noqa: F401, F403

# Mirror the source module's public names so static analysis + dir() work.
__all__ = getattr(_src, "__all__", [n for n in dir(_src) if not n.startswith("_")])
