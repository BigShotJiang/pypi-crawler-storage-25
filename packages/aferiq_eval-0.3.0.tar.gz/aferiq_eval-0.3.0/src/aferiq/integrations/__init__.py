"""aferiq.integrations — namespace mirror of rageval.integrations.

Each submodule under ``aferiq.integrations.*`` is a thin shim that
re-exports the corresponding ``rageval.integrations.*`` module. Existing
code keeps working; the rebrand is purely additive.

Example::

    # New, preferred:
    from aferiq.integrations.langchain import RAGEvalCallbackHandler
    from aferiq.integrations.llamaindex import RAGEvalCallbackHandler
    from aferiq.integrations.agent_callback import AferiqAgentCallbackHandler

    # Still works:
    from rageval.integrations.langchain import RAGEvalCallbackHandler
"""
