"""Re-export of `rageval.integrations.anthropic_patch` under the canonical aferiq.* namespace."""

from rageval.integrations import anthropic_patch as _src
from rageval.integrations.anthropic_patch import *  # noqa: F401, F403

# Mirror the source module's public names so static analysis + dir() work.
__all__ = getattr(_src, "__all__", [n for n in dir(_src) if not n.startswith("_")])
