"""aferiq — public name for the rageval SDK.

This module re-exports everything from ``rageval`` so users can write the
canonical plug-and-play setup::

    import aferiq
    aferiq.init()
    chain.invoke(input, config={"callbacks": [aferiq.handler()]})

Both ``import aferiq`` and ``import rageval`` work — they refer to the
same code. ``aferiq`` is the preferred name going forward, matching the
PyPI package (``pip install aferiq-eval``) and the dashboard URL.

Backwards compatibility: existing code that imports ``rageval`` (or any
of its submodules) keeps working — the rename is purely additive.

Auto-instrumentation patches::

    aferiq.patch_openai()      # captures openai.chat.completions.create
    aferiq.patch_anthropic()   # captures anthropic.messages.create

Callbacks (LangChain / LangGraph)::

    aferiq.handler()                   # RAGEvalCallbackHandler factory
    aferiq.agent_handler(goal=...)     # AferiqAgentCallbackHandler factory
"""

from __future__ import annotations

# Re-export the entire public surface of rageval. Anything in `__all__`
# from `rageval.__init__` becomes available as `aferiq.<name>`.
from rageval import (
    AgentEvalResult,
    AgentStep,
    AgentTrace,
    AgentTraceResult,
    AsyncCloudClient,
    CloudClient,
    EvalResult,
    EvalSample,
    MetricScore,
    SampleResult,
    StepType,
    Trace,
    __version__,
    aevaluate,
    aevaluate_agent,
    aevaluate_samples,
    clear_trace_handlers,
    evaluate,
    evaluate_agent,
    evaluate_samples,
    handler,
    init,
    redact_pii_br,
    register_trace_handler,
    start,
    trace,
)

# Auto-instrumentation patches — safe to import at module top-level. Each
# function does its actual SDK import lazily inside the function body, so
# importing them here doesn't pull in openai/anthropic — those remain
# fully optional dependencies.
from rageval.integrations.anthropic_patch import patch_anthropic
from rageval.integrations.openai_patch import patch_openai


def agent_handler(**kwargs):  # type: ignore[no-untyped-def]
    """Factory for the LangGraph / AgentExecutor callback handler.

    Captures multi-step agent trajectories (goal, tool calls, intermediate
    reasoning, final answer). Pass ``goal=user_message`` so the trace knows
    what the agent was asked to do.

    Lazy-imports langchain-core. If you don't have langchain-core installed,
    this raises ImportError with a helpful message — install with
    ``pip install langchain-core``.

    Equivalent to::

        from rageval.integrations.langchain import AferiqAgentCallbackHandler
        AferiqAgentCallbackHandler(**kwargs)

    but exposed under the ``aferiq.*`` namespace for consistency with
    ``aferiq.handler()`` and ``aferiq.patch_openai()``.
    """
    from rageval.integrations.agent_callback import AferiqAgentCallbackHandler

    return AferiqAgentCallbackHandler(**kwargs)


__all__ = [
    "AgentEvalResult",
    "AgentStep",
    "AgentTrace",
    "AgentTraceResult",
    "AsyncCloudClient",
    "CloudClient",
    "EvalResult",
    "EvalSample",
    "MetricScore",
    "SampleResult",
    "StepType",
    "Trace",
    "__version__",
    "aevaluate",
    "aevaluate_agent",
    "aevaluate_samples",
    "agent_handler",
    "clear_trace_handlers",
    "evaluate",
    "evaluate_agent",
    "evaluate_samples",
    "handler",
    "init",
    "patch_anthropic",
    "patch_openai",
    "redact_pii_br",
    "register_trace_handler",
    "start",
    "trace",
]
