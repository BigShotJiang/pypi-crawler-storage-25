"""Trajectory quality metric — judges whether the agent's path was reasonable.

Reads `prompts/trajectory_quality_{pt,en}.txt`. Output: score, reasoning,
issues[] with per-step problems.
"""

from __future__ import annotations

from typing import Any

from rageval.metrics.agent_base import _AgentPromptBasedMetric


class TrajectoryQuality(_AgentPromptBasedMetric):
    name: str = "trajectory_quality"

    def _name(self) -> str:
        return self.name

    def _extract_details(self, parsed: dict[str, Any]) -> dict[str, Any]:
        return {"issues": parsed.get("issues", [])}
