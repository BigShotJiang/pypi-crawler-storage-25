"""Metric base classes + judge-response parsing helpers.

Hierarchy:
    Metric                   -- public ABC (defines score/ascore contract)
    └── _PromptBasedMetric   -- shared concrete base for all metrics that
                                load a prompt template and parse JSON output

Concrete metric classes (Faithfulness, CitationAccuracy, Hallucination) inherit
from ``_PromptBasedMetric`` and only need to set ``name`` and (optionally)
override ``_extract_details``.
"""

from __future__ import annotations

import json
import re
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

from rageval.prompts import load_prompt
from rageval.types import EvalSample, Language, MetricScore

if TYPE_CHECKING:
    from rageval.judge import AsyncJudge, Judge


class Metric(ABC):
    """Public metric contract.

    Subclasses must define ``name`` and implement ``score`` and ``ascore``.
    Most concrete metrics should inherit from ``_PromptBasedMetric`` instead
    of implementing this directly.
    """

    name: str

    @abstractmethod
    def score(
        self, sample: EvalSample, judge: Judge, language: Language = "pt"
    ) -> MetricScore:
        """Score a single sample synchronously."""

    @abstractmethod
    async def ascore(
        self, sample: EvalSample, judge: AsyncJudge, language: Language = "pt"
    ) -> MetricScore:
        """Score a single sample asynchronously."""


class _PromptBasedMetric(Metric):
    """Shared concrete base for metrics that follow the prompt → JSON pattern.

    The flow:
        1. Load ``{name}_{language}.txt`` from rageval.prompts
        2. Format it with ``{query, context, answer}``
        3. Call the judge once
        4. Parse JSON and extract ``score`` (clamped to [0, 1]) + ``reasoning``
        5. Optionally extract metric-specific details via ``_extract_details``

    Subclasses set ``name`` and override ``_extract_details`` if they want
    to surface per-claim breakdowns or other structured data.
    """

    def _format_context(self, context: list[str]) -> str:
        return "\n\n".join(f"[{i + 1}] {chunk}" for i, chunk in enumerate(context))

    def _build_prompt(self, sample: EvalSample, language: Language) -> str:
        template = load_prompt(self.name, language)
        return template.format(
            query=sample.query,
            context=self._format_context(sample.context),
            answer=sample.answer,
        )

    def _extract_details(self, parsed: dict[str, Any]) -> dict[str, Any]:
        """Override to surface metric-specific structured info from parsed JSON."""
        return {}

    def _interpret(self, raw: str, language: Language) -> MetricScore:
        try:
            parsed = parse_judge_json(raw)
            score = clamp_score(parsed.get("score", 0.0))
            reasoning = str(parsed.get("reasoning", "")).strip()
            if not reasoning:
                reasoning = "(sem motivo)" if language == "pt" else "(no reasoning)"
            details = self._extract_details(parsed)
        except ValueError as e:
            score = 0.0
            reasoning = (
                f"(falha ao parsear resposta do juiz: {e})"
                if language == "pt"
                else f"(failed to parse judge response: {e})"
            )
            details = {}

        return MetricScore(
            metric=self.name,
            score=score,
            reasoning=reasoning,
            language=language,
            raw_judge_response=raw,
            details=details,
        )

    def score(
        self, sample: EvalSample, judge: Judge, language: Language = "pt"
    ) -> MetricScore:
        return self._interpret(judge(self._build_prompt(sample, language)), language)

    async def ascore(
        self, sample: EvalSample, judge: AsyncJudge, language: Language = "pt"
    ) -> MetricScore:
        return self._interpret(await judge(self._build_prompt(sample, language)), language)


_FENCE_RE = re.compile(r"```(?:json)?\s*(.+?)\s*```", re.DOTALL)
_BRACE_RE = re.compile(r"\{.+\}", re.DOTALL)


def parse_judge_json(raw: str) -> dict[str, Any]:
    """Parse a judge's response JSON, tolerant to common LLM output quirks.

    Handles:
        - plain JSON
        - JSON wrapped in markdown code fences (``` or ```json)
        - JSON with leading/trailing prose

    Raises:
        ValueError if no JSON object can be extracted.
    """
    cleaned = raw.strip()

    fence_match = _FENCE_RE.search(cleaned)
    if fence_match:
        cleaned = fence_match.group(1).strip()

    try:
        return _ensure_dict(json.loads(cleaned))
    except json.JSONDecodeError:
        pass

    brace_match = _BRACE_RE.search(cleaned)
    if brace_match:
        try:
            return _ensure_dict(json.loads(brace_match.group(0)))
        except json.JSONDecodeError:
            pass

    raise ValueError(f"Could not parse JSON from judge response: {raw[:200]!r}")


def _ensure_dict(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object, got {type(value).__name__}")
    return value


def clamp_score(value: Any) -> float:
    """Coerce a value into a float in [0.0, 1.0]. Falls back to 0.0 on bad input."""
    try:
        f = float(value)
    except (TypeError, ValueError):
        return 0.0
    return max(0.0, min(1.0, f))
