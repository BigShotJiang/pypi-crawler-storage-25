"""Faithfulness metric.

Score 1.0 = answer fully supported by context; 0.0 = fully invented or contradicting.

The PT-BR prompt is hand-tuned for Brazilian failure patterns:
fabricated legal citations (Lei nº inventada), fake CNPJ/CPF, fictional
references to Receita Federal / INSS / SUS, etc. This is the moat.
"""

from __future__ import annotations

from typing import Any

from rageval.metrics.base import _PromptBasedMetric


class Faithfulness(_PromptBasedMetric):
    """Does the answer follow from the retrieved context?"""

    name: str = "faithfulness"

    def _extract_details(self, parsed: dict[str, Any]) -> dict[str, Any]:
        return {"unsupported_claims": parsed.get("unsupported_claims", [])}
