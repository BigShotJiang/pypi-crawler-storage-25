"""Tool use correctness metric — judges whether tools were called with valid
args, in plausible order. Reads `prompts/tool_use_correctness_{pt,en}.txt`.
"""

from __future__ import annotations

from typing import Any

from rageval.metrics.agent_base import _AgentPromptBasedMetric


class ToolUseCorrectness(_AgentPromptBasedMetric):
    name: str = "tool_use_correctness"

    def _name(self) -> str:
        return self.name

    def _extract_details(self, parsed: dict[str, Any]) -> dict[str, Any]:
        return {"errors": parsed.get("errors", [])}
