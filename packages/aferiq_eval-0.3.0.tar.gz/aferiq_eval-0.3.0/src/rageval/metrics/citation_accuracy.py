"""Citation accuracy metric.

For each atomic claim in the answer, identifies which retrieved chunks support it.
Score = (# claims with at least one supporting chunk) / (# total claims).

PT-BR prompt enforces strict matching for Brazilian patterns: a claim citing
"Lei nº X" or "Art. Y" is only attributed to a chunk that contains exactly
the same reference; CNPJ/CPF numbers must match exactly.
"""

from __future__ import annotations

from typing import Any

from rageval.metrics.base import _PromptBasedMetric


class CitationAccuracy(_PromptBasedMetric):
    """Per-claim mapping to retrieved chunks."""

    name: str = "citation_accuracy"

    def _extract_details(self, parsed: dict[str, Any]) -> dict[str, Any]:
        return {"claims": parsed.get("claims", [])}
