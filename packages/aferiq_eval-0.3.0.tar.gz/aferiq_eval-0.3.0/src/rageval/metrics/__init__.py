"""Metrics registry — RAG (single-turn) and agent (multi-step trajectory)."""

from __future__ import annotations

from rageval.metrics.base import Metric
from rageval.metrics.citation_accuracy import CitationAccuracy
from rageval.metrics.cost_efficiency import CostEfficiency
from rageval.metrics.faithfulness import Faithfulness
from rageval.metrics.goal_completion import GoalCompletion
from rageval.metrics.hallucination import Hallucination
from rageval.metrics.tool_use_correctness import ToolUseCorrectness
from rageval.metrics.trajectory_quality import TrajectoryQuality

_REGISTRY: dict[str, type[Metric]] = {
    "faithfulness": Faithfulness,
    "citation_accuracy": CitationAccuracy,
    "hallucination": Hallucination,
}

_AGENT_REGISTRY: dict[str, type[Metric]] = {
    "trajectory_quality": TrajectoryQuality,
    "tool_use_correctness": ToolUseCorrectness,
    "goal_completion": GoalCompletion,
    "cost_efficiency": CostEfficiency,
}


def get_metric(name: str) -> Metric:
    """Look up a RAG metric by name and instantiate it."""
    if name not in _REGISTRY:
        available = ", ".join(sorted(_REGISTRY.keys()))
        raise ValueError(f"Unknown RAG metric {name!r}. Available: {available}")
    return _REGISTRY[name]()


def get_agent_metric(name: str) -> Metric:
    """Look up an agent metric by name and instantiate it."""
    if name not in _AGENT_REGISTRY:
        available = ", ".join(sorted(_AGENT_REGISTRY.keys()))
        raise ValueError(f"Unknown agent metric {name!r}. Available: {available}")
    return _AGENT_REGISTRY[name]()


def available_metrics() -> list[str]:
    """All RAG metric names registered for this version."""
    return sorted(_REGISTRY.keys())


def available_agent_metrics() -> list[str]:
    """All agent metric names registered for this version."""
    return sorted(_AGENT_REGISTRY.keys())


__all__ = [
    "CitationAccuracy",
    "CostEfficiency",
    "Faithfulness",
    "GoalCompletion",
    "Hallucination",
    "Metric",
    "ToolUseCorrectness",
    "TrajectoryQuality",
    "available_agent_metrics",
    "available_metrics",
    "get_agent_metric",
    "get_metric",
]
