"""Agent-shape metric base — shared by trajectory_quality, tool_use_correctness,
and goal_completion.

Mirrors `_PromptBasedMetric` (RAG-shape) but takes an `AgentTrace` and
formats prompts with `{goal}`, `{trajectory}`, `{tool_specs}`, `{tool_calls}`,
`{final_answer}`, `{trajectory_summary}`.
"""

from __future__ import annotations

import json
from abc import abstractmethod
from typing import TYPE_CHECKING, Any

from rageval.agent import AgentTrace
from rageval.metrics.base import Metric, clamp_score, parse_judge_json
from rageval.prompts import load_prompt
from rageval.types import Language, MetricScore

if TYPE_CHECKING:
    from rageval.judge import AsyncJudge, Judge


def _format_trajectory(trace: AgentTrace) -> str:
    if not trace.steps:
        return "(empty trajectory)"
    lines = []
    for i, s in enumerate(trace.steps):
        tool = f" {s.tool_name}" if s.tool_name else ""
        summary = ""
        if s.step_type == "tool" and s.step_output is not None:
            out = (
                s.step_output
                if isinstance(s.step_output, str)
                else json.dumps(s.step_output)
            )
            summary = f": {_truncate(out, 120)}"
        elif s.step_type == "agent_action" and s.step_input is not None:
            inp = (
                s.step_input
                if isinstance(s.step_input, str)
                else json.dumps(s.step_input)
            )
            summary = f": {_truncate(inp, 120)}"
        elif s.step_type == "llm" and s.tokens_in is not None:
            summary = (
                f": {s.tokens_in or 0}+{s.tokens_out or 0} tokens · "
                f"{s.latency_ms or 0}ms"
            )
        lines.append(f"{i + 1}. [{s.step_type}]{tool}{summary}")
    return "\n".join(lines)


def _format_tool_calls(trace: AgentTrace) -> str:
    calls = [s for s in trace.steps if s.step_type in {"tool", "agent_action"}]
    if not calls:
        return "(none)"
    lines = []
    for i, s in enumerate(calls):
        inp = (
            s.step_input
            if isinstance(s.step_input, str)
            else json.dumps(s.step_input or {})
        )
        lines.append(f"{i + 1}. {s.tool_name or '(unknown)'}: input={_truncate(inp, 200)}")
    return "\n".join(lines)


def _format_trajectory_summary(trace: AgentTrace) -> str:
    counts: dict[str, int] = {}
    for s in trace.steps:
        counts[s.step_type] = counts.get(s.step_type, 0) + 1
    parts = ", ".join(f"{n}× {t}" for t, n in counts.items())
    tools = sorted({s.tool_name for s in trace.steps if s.tool_name})
    tool_str = f" · tools: {', '.join(tools)}" if tools else ""
    return f"{len(trace.steps)} steps ({parts}){tool_str}"


def _truncate(s: str, n: int) -> str:
    return s if len(s) <= n else f"{s[:n]}…"


class _AgentPromptBasedMetric(Metric):
    """Shared base for agent metrics. Concrete subclasses set ``name`` and
    optionally override ``_extract_details``."""

    def _build_prompt(self, trace: AgentTrace, language: Language) -> str:
        template = load_prompt(self.name, language)
        return template.format(
            goal=trace.goal,
            trajectory=_format_trajectory(trace),
            tool_calls=_format_tool_calls(trace),
            tool_specs=json.dumps(trace.tool_specs or [], indent=2)
            if trace.tool_specs
            else "(none)",
            final_answer=trace.final_answer or "(no answer)",
            trajectory_summary=_format_trajectory_summary(trace),
        )

    def _extract_details(self, parsed: dict[str, Any]) -> dict[str, Any]:
        return {}

    def _interpret(self, raw: str, language: Language) -> MetricScore:
        try:
            parsed = parse_judge_json(raw)
            score = clamp_score(parsed.get("score", 0.0))
            reasoning = str(parsed.get("reasoning", "")).strip() or (
                "(sem motivo)" if language == "pt" else "(no reasoning)"
            )
            details = self._extract_details(parsed)
        except ValueError as e:
            score = 0.0
            reasoning = (
                f"(falha ao parsear resposta do juiz: {e})"
                if language == "pt"
                else f"(failed to parse judge response: {e})"
            )
            details = {}

        return MetricScore(
            metric=self.name,
            score=score,
            reasoning=reasoning,
            language=language,
            raw_judge_response=raw,
            details=details,
        )

    def score(  # type: ignore[override]
        self, trace: AgentTrace, judge: Judge, language: Language = "pt"
    ) -> MetricScore:
        return self._interpret(judge(self._build_prompt(trace, language)), language)

    async def ascore(  # type: ignore[override]
        self, trace: AgentTrace, judge: AsyncJudge, language: Language = "pt"
    ) -> MetricScore:
        return self._interpret(
            await judge(self._build_prompt(trace, language)), language
        )

    @abstractmethod
    def _name(self) -> str: ...
