"""Goal completion metric — judges whether the agent's final answer satisfies
the user's original goal. Reads `prompts/goal_completion_{pt,en}.txt`.
"""

from __future__ import annotations

from typing import Any

from rageval.metrics.agent_base import _AgentPromptBasedMetric


class GoalCompletion(_AgentPromptBasedMetric):
    name: str = "goal_completion"

    def _name(self) -> str:
        return self.name

    def _extract_details(self, parsed: dict[str, Any]) -> dict[str, Any]:
        return {
            "completed": parsed.get("completed", False),
            "gap": parsed.get("gap", ""),
        }
