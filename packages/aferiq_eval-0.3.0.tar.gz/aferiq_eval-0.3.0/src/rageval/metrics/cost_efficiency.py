"""Cost efficiency metric — purely computational, no LLM judge.

Score = clamp(optimal / actual, 0..1), where:
  - actual = total step count
  - optimal = a baseline (default 3 steps; override per-call)

A trajectory that took 1-3 steps is considered fully efficient (1.0); each
extra step proportionally lowers the score.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from rageval.agent import AgentTrace
from rageval.metrics.base import Metric
from rageval.types import Language, MetricScore

if TYPE_CHECKING:
    from rageval.judge import AsyncJudge, Judge


class CostEfficiency(Metric):
    name: str = "cost_efficiency"

    def __init__(self, optimal_step_baseline: int = 3) -> None:
        self.optimal = optimal_step_baseline

    def score(  # type: ignore[override]
        self, trace: AgentTrace, judge: Judge, language: Language = "pt"
    ) -> MetricScore:
        return self._compute(trace, language)

    async def ascore(  # type: ignore[override]
        self, trace: AgentTrace, judge: AsyncJudge, language: Language = "pt"
    ) -> MetricScore:
        return self._compute(trace, language)

    def _compute(self, trace: AgentTrace, language: Language) -> MetricScore:
        n_steps = len(trace.steps)
        tokens_total = trace.total_tokens()
        ratio = 1.0 if n_steps <= 1 else min(1.0, self.optimal / n_steps)
        reasoning_pt = (
            f"{n_steps} passos usados, baseline {self.optimal} (ratio {ratio:.2f}). "
            f"Tokens total: {tokens_total}."
        )
        reasoning_en = (
            f"{n_steps} steps used, {self.optimal}-step baseline (ratio {ratio:.2f}). "
            f"Tokens total: {tokens_total}."
        )
        return MetricScore(
            metric=self.name,
            score=ratio,
            reasoning=reasoning_pt if language == "pt" else reasoning_en,
            language=language,
            details={
                "n_steps": n_steps,
                "tokens_total": tokens_total,
                "optimal_baseline": self.optimal,
            },
        )
