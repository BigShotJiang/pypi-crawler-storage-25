"""Claim-level hallucination detection.

Decomposes the answer into atomic claims and classifies each as supported or
hallucinated. The PT-BR prompt categorizes Brazilian-specific hallucination
patterns: fake Lei nº, fabricated CNPJ/CPF, fictional Receita Federal/INSS/SUS
references, invented public-policy programs, wrong legal deadlines, etc.

The ``details`` field on the returned MetricScore exposes the per-claim list
with categories — useful for dashboards and debugging.

Score = (# supported claims) / (# total claims).
"""

from __future__ import annotations

from typing import Any

from rageval.metrics.base import _PromptBasedMetric


class Hallucination(_PromptBasedMetric):
    """Claim-level hallucination detection with BR-pattern categorization."""

    name: str = "hallucination"

    def _extract_details(self, parsed: dict[str, Any]) -> dict[str, Any]:
        return {"claims": parsed.get("claims", [])}
