"""Plug-and-play setup for sending traces to the aferiq cloud.

This module collapses the boilerplate that customers used to copy-paste
(regex redactor + httpx.post handler + register_trace_handler call) into
a single ``init()`` call. The full integration becomes::

    # .env
    AFERIQ_API_KEY=rg_pk_live_...
    AFERIQ_INGEST_URL=https://...

    # In your app's entry point
    import aferiq
    aferiq.init()

    # On each chain invocation
    chain.invoke(input, config={"callbacks": [aferiq.handler()]})

Public API:
    init(api_key=None, ingest_url=None, redact=True, timeout=5.0) -> None
    handler() -> RAGEvalCallbackHandler
    redact_pii_br(text: str) -> str

``init()`` is idempotent and a no-op when env vars are missing or when the
API key is a placeholder — safe to leave in code without breaking dev/test
environments.
"""

from __future__ import annotations

import logging
import os
import re
from typing import TYPE_CHECKING, Any

import httpx

from rageval.agent import AgentTrace
from rageval.integrations.tracing import register_trace_handler
from rageval.types import EvalSample

if TYPE_CHECKING:
    # Type-only import — actual import happens lazily inside handler().
    # Keeping this out of runtime imports lets users `import aferiq` and
    # call aferiq.start() WITHOUT installing langchain-core (which the
    # LangChain handler needs). Users only pay the cost when they call
    # aferiq.handler().
    from rageval.integrations.langchain import RAGEvalCallbackHandler

_logger = logging.getLogger("rageval.cloud")
_initialized = False

# Brazilian PII patterns. Order matters: longer/more-specific patterns first
# so partial matches don't get consumed by a more permissive regex.
_DEFAULT_REDACTORS: list[tuple[re.Pattern[str], str]] = [
    # CNPJ: 12.345.678/0001-90 (more specific than CPF — match first)
    (re.compile(r"\b\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2}\b"), "[CNPJ]"),
    # CPF: 123.456.789-09
    (re.compile(r"\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b"), "[CPF]"),
    # RG: 12.345.678-9 or 12.345.678-X (X is checksum digit, can be alpha)
    (re.compile(r"\b\d{1,2}\.?\d{3}\.?\d{3}-?[\dxX]\b"), "[RG]"),
    # CEP: 01310-100 or 01310100
    (re.compile(r"\b\d{5}-?\d{3}\b"), "[CEP]"),
    # Email
    (re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b"), "[EMAIL]"),
    # Brazilian phone: (11) 91234-5678, 11912345678, +55 11 91234-5678
    (re.compile(r"\(?\b\d{2}\)?\s?9?\d{4}-?\d{4}\b"), "[PHONE]"),
]


def redact_pii_br(text: str) -> str:
    """Redact common Brazilian PII patterns from a string.

    Replaces CPF, CNPJ, RG, CEP, email, and phone numbers with bracketed
    labels. Idempotent (calling twice does not double-redact).

    Args:
        text: Input string to redact. Empty/None passes through unchanged.

    Returns:
        Redacted string with each PII pattern replaced by ``[CPF]``,
        ``[CNPJ]``, ``[RG]``, ``[CEP]``, ``[EMAIL]``, or ``[PHONE]``.
    """
    if not text:
        return text
    for pattern, repl in _DEFAULT_REDACTORS:
        text = pattern.sub(repl, text)
    return text


def _parse_dsn(dsn: str) -> tuple[str, str]:
    """Parse a Sentry-style DSN URL into (api_key, ingest_url).

    Format: ``https://<api_key>@<host>[:port]/<path>``

    Example::

        >>> _parse_dsn("https://rg_pk_live_xxx@aferiq.com.br/api/v1/traces")
        ("rg_pk_live_xxx", "https://aferiq.com.br/api/v1/traces")
        >>> _parse_dsn("http://rg_pk_live_xxx@localhost:3030/api/v1/traces")
        ("rg_pk_live_xxx", "http://localhost:3030/api/v1/traces")

    Raises:
        ValueError: if the DSN is malformed (missing scheme, host, or
            embedded API key).
    """
    from urllib.parse import urlparse, urlunparse

    parsed = urlparse(dsn)
    if not parsed.scheme or not parsed.hostname:
        raise ValueError(
            "AFERIQ_DSN malformado — esperado formato "
            "https://<api_key>@<host>/api/v1/traces, "
            f"recebido: {dsn!r}"
        )
    if not parsed.username:
        raise ValueError(
            "AFERIQ_DSN não contém API key como username — esperado "
            "https://rg_pk_live_xxx@host/api/v1/traces (note o '@' "
            "separando key + host)"
        )

    api_key = parsed.username
    netloc = parsed.hostname
    if parsed.port:
        netloc = f"{netloc}:{parsed.port}"
    ingest_url = urlunparse((parsed.scheme, netloc, parsed.path, "", "", ""))
    return api_key, ingest_url


def init(
    *,
    dsn: str | None = None,
    api_key: str | None = None,
    ingest_url: str | None = None,
    redact: bool = True,
    timeout: float = 5.0,
    verbose: bool = True,
    probe: bool = True,
    auto_patch: bool = True,
) -> bool:
    """Configure aferiq cloud tracing in one line.

    **Recommended setup — DSN-style (1 env var)**::

        # Set in .env:
        AFERIQ_DSN=https://rg_pk_live_xxx@aferiq.com.br/api/v1/traces

        # In code:
        aferiq.start()  # reads AFERIQ_DSN automatically

    The DSN combines API key + endpoint in a single URL (Sentry-style).
    Less surface for typos than 2 separate env vars.

    **Legacy setup — 2 env vars** (still supported for backwards compat)::

        AFERIQ_API_KEY=rg_pk_live_xxx
        AFERIQ_INGEST_URL=https://aferiq.com.br/api/v1/traces

    Precedence: explicit ``dsn=`` kwarg → ``AFERIQ_DSN`` env var →
    ``api_key`` / ``ingest_url`` kwargs → ``AFERIQ_API_KEY`` /
    ``AFERIQ_INGEST_URL`` env vars. First match wins.

    No-op (returns ``False``) if no config is found. This makes
    ``init()`` safe to call unconditionally in dev / test where env vars
    may be absent — your app keeps running with zero traces sent.

    Idempotent: only one handler is registered no matter how many times
    you call this.

    Args:
        dsn: Sentry-style DSN URL combining API key + endpoint. Overrides
            both ``AFERIQ_DSN`` env var and individual ``api_key`` /
            ``ingest_url`` kwargs.
        api_key: Override AFERIQ_API_KEY env var. Format: ``rg_pk_live_…``.
            Ignored if ``dsn`` is provided.
        ingest_url: Override AFERIQ_INGEST_URL env var. Full URL ending in
            ``/api/v1/traces``. Ignored if ``dsn`` is provided.
        redact: Apply Brazilian PII regex (CPF/CNPJ/RG/CEP/email/phone)
            before posting. Default ``True``. Set ``False`` only if you
            already redact upstream OR are testing in a clean env.
        timeout: Per-POST HTTP timeout in seconds. Default 5.0 — kept short
            so tracing doesn't slow down user-facing requests.
        verbose: Print a 4-line setup summary to stdout on first call.
            Useful for sanity-checking env wiring during boot. Default
            ``True``. Set ``False`` for headless services where stdout
            should stay empty.
        probe: Send a no-op OPTIONS / HEAD request to ``ingest_url`` to
            validate the key + endpoint at boot time. Default ``True``.
            Bad config (revoked key, wrong URL, network down) surfaces
            immediately instead of silently dropping traces. Probe failures
            do NOT prevent the handler from being registered — your app
            keeps trying to post real traces, with their normal warnings.

    Returns:
        ``True`` if a handler was registered (config valid),
        ``False`` if init was skipped (missing config or placeholder key).
    """
    global _initialized
    if _initialized:
        return True  # already done — keep silent

    # Resolve config — DSN takes precedence over individual key/url pair.
    effective_dsn = dsn or os.getenv("AFERIQ_DSN", "")
    if effective_dsn:
        try:
            api_key, ingest_url = _parse_dsn(effective_dsn)
        except ValueError as exc:
            _logger.warning("[aferiq] invalid AFERIQ_DSN: %s", exc)
            if verbose:
                _print_status(
                    ok=False,
                    ingest_url="(invalid DSN)",
                    redact=redact,
                    probe_status=f"DSN parse failed: {exc}",
                )
            return False
    else:
        api_key = api_key or os.getenv("AFERIQ_API_KEY", "")
        ingest_url = ingest_url or os.getenv("AFERIQ_INGEST_URL", "")

    if not api_key or not ingest_url:
        _logger.info(
            "[aferiq] tracing disabled — set AFERIQ_DSN "
            "(or AFERIQ_API_KEY + AFERIQ_INGEST_URL) in env to enable "
            "cloud traces."
        )
        if verbose:
            _print_status(
                ok=False,
                ingest_url=ingest_url or "(unset)",
                redact=redact,
                probe_status="skipped (config missing)",
            )
        return False

    if api_key.startswith("rg_pk_live_<") or "<COLE" in api_key.upper():
        _logger.warning(
            "[aferiq] tracing disabled — AFERIQ_API_KEY looks like a "
            "placeholder. Update .env with the real value from your "
            "dashboard's /dashboard/api-keys page."
        )
        if verbose:
            _print_status(
                ok=False,
                ingest_url=ingest_url,
                redact=redact,
                probe_status="skipped (placeholder key)",
            )
        return False

    handler_fn = _build_handler(api_key, ingest_url, redact, timeout)
    register_trace_handler(handler_fn)
    _initialized = True

    probe_status = "skipped"
    if probe:
        probe_status = _probe_ingest(api_key, ingest_url, timeout)

    patched: list[str] = []
    if auto_patch:
        patched = _auto_patch_loaded_sdks()

    _logger.info(
        "[aferiq] tracing initialized → %s (redact_pii=%s, patched=%s)",
        ingest_url, redact, patched or "(none)",
    )
    if verbose:
        _print_status(
            ok=True,
            ingest_url=ingest_url,
            redact=redact,
            probe_status=probe_status,
            patched=patched,
        )
    return True


def _auto_patch_loaded_sdks() -> list[str]:
    """Detect which LLM SDKs are already imported in the running process
    and monkey-patch the ones we support so their calls are auto-captured.

    Only patches SDKs whose module is already in ``sys.modules`` — we
    never trigger their import as a side-effect of init(). User who only
    has openai imported gets only OpenAI patched; same for anthropic.

    LangChain users still need to add ``callbacks=[aferiq.handler()]`` to
    their chain.invoke explicitly — globally hooking LangChain's callback
    system varies too much across versions to do reliably here. Verbose
    output prints a hint when langchain-core is imported.

    Returns the list of human-readable names of what was patched.
    """
    import sys
    patched: list[str] = []

    if "openai" in sys.modules:
        try:
            from rageval.integrations.openai_patch import patch_openai
            # emit_standalone=True: bare chat.completions.create outside
            # any @aferiq.trace function emits a standalone EvalSample.
            # This is what makes "import aferiq + start()" actually capture
            # every LLM call without any decorator.
            if patch_openai(emit_standalone=True):
                patched.append("openai")
        except Exception as exc:  # noqa: BLE001
            _logger.debug("[aferiq] openai auto-patch skipped: %s", exc)

    if "anthropic" in sys.modules:
        try:
            from rageval.integrations.anthropic_patch import patch_anthropic
            if patch_anthropic(emit_standalone=True):
                patched.append("anthropic")
        except Exception as exc:  # noqa: BLE001
            _logger.debug("[aferiq] anthropic auto-patch skipped: %s", exc)

    return patched


def start(
    dsn: str | None = None,
    *,
    api_key: str | None = None,
    ingest_url: str | None = None,
    verbose: bool = True,
) -> bool:
    """One-line setup. Aliases ``init(auto_patch=True, verbose=True)``.

    Use this as the canonical entry point for new code::

        import aferiq
        aferiq.start()  # reads AFERIQ_DSN from env

    Or explicit::

        aferiq.start("https://rg_pk_live_xxx@aferiq.com.br/api/v1/traces")

    Lê AFERIQ_DSN (or AFERIQ_API_KEY + AFERIQ_INGEST_URL legacy) do env,
    registra trace handler com redação PII BR, e auto-patcheia
    openai/anthropic se estiverem importados — captura toda chamada
    LLM sem decorator nem callback.

    ``verbose=True`` prints the 5-line boot summary by default — silent
    failures on the recommended onboarding path are too costly. Pass
    ``verbose=False`` in CI/production loggers.

    Pra LangChain, adicione ``callbacks=[aferiq.handler()]`` em cada
    ``chain.invoke()`` (a auto-instrumentação global de LangChain é
    instável entre versões, então mantemos explícito por enquanto).
    """
    return init(
        dsn=dsn,
        api_key=api_key,
        ingest_url=ingest_url,
        verbose=verbose,
    )


def _probe_ingest(api_key: str, ingest_url: str, timeout: float) -> str:
    """Send a HEAD request to the ingest endpoint and return a one-word
    status describing what we got back. Used by the boot summary.

    Failure modes are friendly text, not exceptions — probe is purely
    informational and must never crash the user's app.
    """
    try:
        response = httpx.head(
            ingest_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )
        if response.status_code == 200:
            return "200 OK (key valid)"
        if response.status_code == 401:
            return "401 (key invalid or revoked — generate a new one)"
        if response.status_code == 405:
            # Endpoint exists but doesn't accept HEAD — that's fine, the
            # POST handler is what actually runs in prod. Treat as healthy.
            return "405 (endpoint reachable; POST handler will accept)"
        if response.status_code == 404:
            return "404 (endpoint not found — check AFERIQ_INGEST_URL)"
        return f"{response.status_code} (unexpected — check dashboard)"
    except httpx.ConnectError:
        return "connection refused (DNS or network down)"
    except httpx.TimeoutException:
        return f"timeout after {timeout}s (network or server slow)"
    except Exception as exc:  # noqa: BLE001 — probe must never raise
        return f"error: {type(exc).__name__}"


def _print_status(
    *,
    ok: bool,
    ingest_url: str,
    redact: bool,
    probe_status: str,
    patched: list[str] | None = None,
) -> None:
    """Render the setup summary to stdout. Plain text, no rich/colors —
    works in CI logs, Docker, and IDE consoles uniformly.
    """
    marker = "✓" if ok else "✗"
    state = "tracing initialized" if ok else "tracing DISABLED"
    print(f"[aferiq] {marker} {state}")
    print(f"[aferiq]   endpoint: {ingest_url}")
    print(f"[aferiq]   redact_pii: {redact} (BR patterns)")
    print(f"[aferiq]   workspace probe: {probe_status}")
    if ok and patched is not None:
        if patched:
            print(f"[aferiq]   auto-patched: {', '.join(patched)}")
        else:
            print("[aferiq]   auto-patched: (nothing loaded; import openai/anthropic before start())")


def handler() -> RAGEvalCallbackHandler:
    """Return a fresh LangChain callback handler.

    Each call returns a NEW instance. Pass per chain invocation so concurrent
    requests don't share state::

        chain.invoke(input, config={"callbacks": [aferiq.handler()]})

    The handler captures (query, context, answer) from the chain run and
    emits via the trace handler registry — so :func:`init` must be called
    first for the trace to actually reach the cloud.

    Lazy import: requires ``langchain-core`` only when this function is
    called. Users who don't use LangChain can ``import aferiq`` and call
    ``aferiq.start()`` without installing langchain-core.
    """
    from rageval.integrations.langchain import RAGEvalCallbackHandler

    return RAGEvalCallbackHandler()


def _is_initialized() -> bool:
    """Test helper — exposed for tests to assert state, not for users."""
    return _initialized


def _reset_for_testing() -> None:
    """Test helper only — resets the init flag so tests can re-init."""
    global _initialized
    _initialized = False


def _build_handler(
    api_key: str,
    ingest_url: str,
    redact: bool,
    timeout: float,
) -> Any:
    """Closure over (api_key, ingest_url, redact, timeout) → trace handler.

    Returns a callable suitable for ``register_trace_handler``. The closure
    pattern keeps the API key out of any module-level mutable state.
    """

    def _do_redact(text: str) -> str:
        return redact_pii_br(text) if redact else text

    def _post(trace: Any) -> None:
        try:
            payload = _trace_to_payload(trace, _do_redact)
            if payload is None:
                return
            response = httpx.post(
                ingest_url,
                headers={"Authorization": f"Bearer {api_key}"},
                json=payload,
                timeout=timeout,
            )
            if response.status_code >= 400:
                _logger.warning(
                    "[aferiq] ingest returned %s: %s",
                    response.status_code,
                    response.text[:200],
                )
            else:
                _logger.info("[aferiq] trace posted")
        except Exception as exc:  # noqa: BLE001 — never break user's request flow
            _logger.warning("[aferiq] failed to post trace: %s", exc)

    return _post


def _trace_to_payload(trace: Any, redact_fn: Any) -> dict[str, Any] | None:
    """Serialize a trace shape into the ingest endpoint's JSON payload.

    Supports both single-turn ``EvalSample`` (RAG) and multi-step
    ``AgentTrace`` (agentic). Returns None for unknown shapes (logged as a
    warning by the caller's exception path).
    """
    if isinstance(trace, EvalSample):
        return {
            "query": redact_fn(trace.query),
            "context": [redact_fn(c) for c in trace.context],
            "answer": redact_fn(trace.answer),
        }
    if isinstance(trace, AgentTrace):
        return {
            "trace_id": trace.trace_id,
            "goal": redact_fn(trace.goal or ""),
            "final_answer": redact_fn(trace.final_answer or ""),
            "steps": [
                {
                    **step.model_dump(),
                    "step_input": redact_fn(str(step.step_input or "")),
                    "step_output": redact_fn(str(step.step_output or "")),
                }
                for step in trace.steps
            ],
            "tool_specs": trace.tool_specs,
        }
    _logger.warning(
        "[aferiq] unknown trace shape, skipping post: %s", type(trace).__name__
    )
    return None
