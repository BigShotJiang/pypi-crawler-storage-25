"""Public ``evaluate()`` / ``aevaluate()`` entry points (RAG + agent)."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from rageval.agent import AgentTrace
from rageval.metrics import get_agent_metric, get_metric
from rageval.types import EvalResult, EvalSample, Language, MetricScore, SampleResult

if TYPE_CHECKING:
    from rageval.judge import AsyncJudge, Judge


def evaluate(
    queries: list[str],
    contexts: list[list[str]],
    answers: list[str],
    *,
    metrics: list[str] | None = None,
    ground_truth: list[str] | None = None,
    judge: Judge | None = None,
    language: Language = "pt",
) -> EvalResult:
    """Evaluate a batch of (query, context, answer) tuples synchronously.

    Args:
        queries: One query per sample.
        contexts: One list of retrieved chunks per sample. Same length as ``queries``.
        answers: One answer per sample.
        metrics: Metric names to run. Defaults to ``["faithfulness"]``.
        ground_truth: Optional reference answers, one per sample.
        judge: Custom Judge. Defaults to a fresh ``Judge()`` (gpt-4o-mini, no cache).
        language: ``"pt"`` (default) or ``"en"``.

    Returns:
        ``EvalResult`` with per-sample scores and aggregate means.
    """
    if metrics is None:
        metrics = ["faithfulness"]
    if judge is None:
        from rageval.judge import Judge as _Judge

        judge = _Judge()

    samples = _build_samples(queries, contexts, answers, ground_truth)
    metric_objs = [get_metric(name) for name in metrics]

    sample_results: list[SampleResult] = []
    for sample in samples:
        scores: list[MetricScore] = [m.score(sample, judge, language) for m in metric_objs]
        sample_results.append(SampleResult(sample=sample, scores=scores))

    return EvalResult(
        samples=sample_results,
        aggregate=_aggregate(sample_results, metrics),
        language=language,
    )


async def aevaluate(
    queries: list[str],
    contexts: list[list[str]],
    answers: list[str],
    *,
    metrics: list[str] | None = None,
    ground_truth: list[str] | None = None,
    judge: AsyncJudge | None = None,
    language: Language = "pt",
    concurrency: int = 8,
) -> EvalResult:
    """Async version of :func:`evaluate`.

    Runs metric evaluations concurrently with bounded fan-out (``concurrency``).
    """
    if metrics is None:
        metrics = ["faithfulness"]
    if judge is None:
        from rageval.judge import AsyncJudge as _AsyncJudge

        judge = _AsyncJudge()

    samples = _build_samples(queries, contexts, answers, ground_truth)
    metric_objs = [get_metric(name) for name in metrics]

    semaphore = asyncio.Semaphore(concurrency)

    async def _score_one(sample: EvalSample) -> SampleResult:
        async with semaphore:
            scores = await asyncio.gather(
                *(m.ascore(sample, judge, language) for m in metric_objs)
            )
        return SampleResult(sample=sample, scores=list(scores))

    sample_results = list(await asyncio.gather(*(_score_one(s) for s in samples)))

    return EvalResult(
        samples=sample_results,
        aggregate=_aggregate(sample_results, metrics),
        language=language,
    )


def evaluate_samples(
    samples: list[EvalSample],
    *,
    metrics: list[str] | None = None,
    judge: Judge | None = None,
    language: Language = "pt",
) -> EvalResult:
    """Evaluate a list of pre-built ``EvalSample`` objects.

    Convenience wrapper around :func:`evaluate` for callers that already have
    samples (e.g. collected via the ``@trace`` decorator or a callback handler).
    """
    if not samples:
        return EvalResult(samples=[], aggregate={}, language=language)

    has_gt = any(s.ground_truth is not None for s in samples)
    return evaluate(
        queries=[s.query for s in samples],
        contexts=[s.context for s in samples],
        answers=[s.answer for s in samples],
        ground_truth=[s.ground_truth or "" for s in samples] if has_gt else None,
        metrics=metrics,
        judge=judge,
        language=language,
    )


async def aevaluate_samples(
    samples: list[EvalSample],
    *,
    metrics: list[str] | None = None,
    judge: AsyncJudge | None = None,
    language: Language = "pt",
    concurrency: int = 8,
) -> EvalResult:
    """Async version of :func:`evaluate_samples`."""
    if not samples:
        return EvalResult(samples=[], aggregate={}, language=language)

    has_gt = any(s.ground_truth is not None for s in samples)
    return await aevaluate(
        queries=[s.query for s in samples],
        contexts=[s.context for s in samples],
        answers=[s.answer for s in samples],
        ground_truth=[s.ground_truth or "" for s in samples] if has_gt else None,
        metrics=metrics,
        judge=judge,
        language=language,
        concurrency=concurrency,
    )


def _build_samples(
    queries: list[str],
    contexts: list[list[str]],
    answers: list[str],
    ground_truth: list[str] | None,
) -> list[EvalSample]:
    if not (len(queries) == len(contexts) == len(answers)):
        raise ValueError(
            f"queries ({len(queries)}), contexts ({len(contexts)}), and answers "
            f"({len(answers)}) must have equal length"
        )
    if ground_truth is not None and len(ground_truth) != len(queries):
        raise ValueError(
            f"ground_truth length ({len(ground_truth)}) must match queries ({len(queries)})"
        )

    return [
        EvalSample(
            query=q,
            context=c,
            answer=a,
            ground_truth=ground_truth[i] if ground_truth else None,
        )
        for i, (q, c, a) in enumerate(zip(queries, contexts, answers, strict=True))
    ]


def _aggregate(results: list[SampleResult], metrics: list[str]) -> dict[str, float]:
    """Compute mean score per metric across all samples."""
    out: dict[str, float] = {}
    for m in metrics:
        scores = [s.score for r in results for s in r.scores if s.metric == m]
        out[m] = sum(scores) / len(scores) if scores else 0.0
    return out


# ============================================================================
# Agent eval — multi-step trajectories
# ============================================================================


@dataclass(frozen=True)
class AgentTraceResult:
    """Per-trace scoring output. Mirrors :class:`SampleResult` for RAG."""

    trace: AgentTrace
    scores: list[MetricScore]

    def score_for(self, metric: str) -> MetricScore | None:
        for s in self.scores:
            if s.metric == metric:
                return s
        return None


@dataclass(frozen=True)
class AgentEvalResult:
    """Full evaluation result for a batch of agent trajectories."""

    traces: list[AgentTraceResult]
    aggregate: dict[str, float] = field(default_factory=dict)
    language: Language = "pt"

    def to_dict(self) -> dict[str, object]:
        return {
            "traces": [
                {
                    "trace_id": tr.trace.trace_id,
                    "goal": tr.trace.goal,
                    "scores": [s.model_dump() for s in tr.scores],
                }
                for tr in self.traces
            ],
            "aggregate": self.aggregate,
            "language": self.language,
        }


def evaluate_agent(
    traces: list[AgentTrace],
    *,
    metrics: list[str] | None = None,
    judge: Judge | None = None,
    language: Language = "pt",
) -> AgentEvalResult:
    """Evaluate a batch of agent trajectories synchronously.

    Args:
        traces: List of ``AgentTrace`` (each with goal + steps + final_answer).
        metrics: Agent metric names. Defaults to
            ``["trajectory_quality", "goal_completion", "cost_efficiency"]``.
        judge: Custom Judge. Defaults to a fresh ``Judge()``. ``cost_efficiency``
            is computational and ignores the judge.
        language: ``"pt"`` (default) or ``"en"``.
    """
    if metrics is None:
        metrics = ["trajectory_quality", "goal_completion", "cost_efficiency"]
    if judge is None:
        from rageval.judge import Judge as _Judge

        judge = _Judge()

    metric_objs = [get_agent_metric(name) for name in metrics]

    trace_results: list[AgentTraceResult] = []
    for trace in traces:
        scores: list[MetricScore] = [
            m.score(trace, judge, language) for m in metric_objs  # type: ignore[arg-type]
        ]
        trace_results.append(AgentTraceResult(trace=trace, scores=scores))

    return AgentEvalResult(
        traces=trace_results,
        aggregate=_aggregate_agent(trace_results, metrics),
        language=language,
    )


async def aevaluate_agent(
    traces: list[AgentTrace],
    *,
    metrics: list[str] | None = None,
    judge: AsyncJudge | None = None,
    language: Language = "pt",
    concurrency: int = 8,
) -> AgentEvalResult:
    """Async version of :func:`evaluate_agent` with bounded fan-out."""
    if metrics is None:
        metrics = ["trajectory_quality", "goal_completion", "cost_efficiency"]
    if judge is None:
        from rageval.judge import AsyncJudge as _AsyncJudge

        judge = _AsyncJudge()

    metric_objs = [get_agent_metric(name) for name in metrics]
    semaphore = asyncio.Semaphore(concurrency)

    async def _score_one(trace: AgentTrace) -> AgentTraceResult:
        async with semaphore:
            scores = await asyncio.gather(
                *(m.ascore(trace, judge, language) for m in metric_objs)  # type: ignore[arg-type]
            )
        return AgentTraceResult(trace=trace, scores=list(scores))

    trace_results = list(await asyncio.gather(*(_score_one(t) for t in traces)))

    return AgentEvalResult(
        traces=trace_results,
        aggregate=_aggregate_agent(trace_results, metrics),
        language=language,
    )


def _aggregate_agent(
    results: list[AgentTraceResult], metrics: list[str]
) -> dict[str, float]:
    out: dict[str, float] = {}
    for m in metrics:
        scores = [s.score for r in results for s in r.scores if s.metric == m]
        out[m] = sum(scores) / len(scores) if scores else 0.0
    return out
