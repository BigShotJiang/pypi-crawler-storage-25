"""Agent trace types — multi-step trajectories with tool calls, tokens, latency.

Lives next to ``EvalSample`` (single-turn RAG). Both shapes coexist; the
trace handler registry accepts either via the ``Trace`` union.

Design notes:
- ``AgentStep.step_input`` / ``step_output`` are loosely typed (dict | str | None)
  because tool call args, LLM messages, and retrieval results don't share a
  schema. The backend serialises them as JSON strings.
- ``trace_id`` on ``AgentTrace`` is the *root* UUID. When shipped to the
  ingestion API, each step becomes its own row with ``parent_trace_id =
  trace_id`` and ``step_index = 0..N``.
- ``tool_specs`` is the catalogue of tools the agent could call. Used by
  ``tool_use_correctness`` judge to know what was *available* vs what was
  *invoked*. Optional — only set when the framework exposes it (LangGraph
  does, AgentExecutor does via tool list).
"""

from __future__ import annotations

from typing import Any, Literal, Union

from pydantic import BaseModel, ConfigDict, Field

StepType = Literal["llm", "tool", "retrieval", "agent_action"]


class AgentStep(BaseModel):
    """One observation/action inside an agent trajectory."""

    model_config = ConfigDict(frozen=True)

    step_index: int = Field(ge=0)
    step_type: StepType
    tool_name: str | None = None
    step_input: dict[str, Any] | str | None = None
    step_output: dict[str, Any] | str | None = None
    tokens_in: int | None = None
    tokens_out: int | None = None
    latency_ms: int | None = None


class AgentTrace(BaseModel):
    """A multi-step agent run.

    The ``goal`` is the high-level user request that initiated the trajectory.
    The ``steps`` list is in execution order (step_index increases). The
    ``final_answer`` is whatever the agent returned at the end — None if the
    agent halted without a final response (loop, error, hard timeout).
    """

    model_config = ConfigDict(frozen=True)

    trace_id: str
    goal: str
    steps: list[AgentStep] = Field(default_factory=list)
    final_answer: str | None = None
    tool_specs: list[dict[str, Any]] | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    def total_tokens(self) -> int:
        """Sum of tokens_in + tokens_out across all steps that recorded them."""
        return sum(
            (s.tokens_in or 0) + (s.tokens_out or 0) for s in self.steps
        )

    def total_latency_ms(self) -> int:
        """Sum of latency_ms across all steps that recorded it."""
        return sum(s.latency_ms or 0 for s in self.steps)

    def n_tool_calls(self) -> int:
        return sum(1 for s in self.steps if s.step_type == "tool")

    def n_llm_calls(self) -> int:
        return sum(1 for s in self.steps if s.step_type == "llm")


# Union type used by the trace handler registry — handlers receive either.
Trace = Union["AgentTrace", "EvalSample"]  # noqa: UP007 — explicit Union for runtime check

# Re-export from types so callers don't need two imports
from rageval.types import EvalSample  # noqa: E402,F401
