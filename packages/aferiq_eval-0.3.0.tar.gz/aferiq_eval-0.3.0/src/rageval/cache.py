"""Caching layer for judge responses.

Default behavior: file-per-key under ``~/.cache/rageval`` keyed by
``sha256(prompt + model + temperature)``.

Three implementations:
    DiskCache  -- persistent, default
    MemoryCache -- in-process, useful for tests
    NullCache   -- no-op, disable caching entirely
"""

from __future__ import annotations

import hashlib
import json
from abc import ABC, abstractmethod
from pathlib import Path


class Cache(ABC):
    """Cache interface."""

    @abstractmethod
    def get(self, prompt: str, model: str, temperature: float) -> str | None:
        """Return the cached response or None on miss."""

    @abstractmethod
    def set(self, prompt: str, model: str, temperature: float, response: str) -> None:
        """Store the response for the given key."""


def _key(prompt: str, model: str, temperature: float) -> str:
    raw = json.dumps(
        {"p": prompt, "m": model, "t": temperature}, sort_keys=True, ensure_ascii=False
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


class NullCache(Cache):
    """Disable caching — always miss, never store."""

    def get(self, prompt: str, model: str, temperature: float) -> str | None:
        return None

    def set(self, prompt: str, model: str, temperature: float, response: str) -> None:
        return None


class MemoryCache(Cache):
    """In-process dict-backed cache. Lifetime = process. Useful for tests."""

    def __init__(self) -> None:
        self._store: dict[str, str] = {}

    def get(self, prompt: str, model: str, temperature: float) -> str | None:
        return self._store.get(_key(prompt, model, temperature))

    def set(self, prompt: str, model: str, temperature: float, response: str) -> None:
        self._store[_key(prompt, model, temperature)] = response


class DiskCache(Cache):
    """File-per-key disk cache.

    Default location: ``~/.cache/rageval``. Pass a directory to override.
    Cache failures (read or write) never raise — they degrade to misses.
    """

    def __init__(self, directory: str | Path | None = None) -> None:
        if directory is None:
            directory = Path.home() / ".cache" / "rageval"
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        return self.directory / f"{key}.json"

    def get(self, prompt: str, model: str, temperature: float) -> str | None:
        path = self._path(_key(prompt, model, temperature))
        if not path.exists():
            return None
        try:
            with path.open("r", encoding="utf-8") as f:
                data = json.load(f)
            return str(data["response"])
        except (json.JSONDecodeError, KeyError, OSError):
            return None

    def set(self, prompt: str, model: str, temperature: float, response: str) -> None:
        path = self._path(_key(prompt, model, temperature))
        try:
            with path.open("w", encoding="utf-8") as f:
                json.dump(
                    {"response": response, "model": model, "temperature": temperature},
                    f,
                    ensure_ascii=False,
                )
        except OSError:
            return None
