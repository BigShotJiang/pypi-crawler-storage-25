"""Cloud client for sending traces to RAG Eval BR cloud.

Plug into the @trace decorator's handler registry::

    from rageval import register_trace_handler
    from rageval.client import CloudClient

    register_trace_handler(CloudClient.from_env().send)

The client never raises on send failures — it logs and drops, so cloud
outages cannot break the user's RAG fn.
"""

from __future__ import annotations

import logging
import os
from typing import Any
from uuid import uuid4

import httpx

from rageval.agent import AgentTrace, Trace
from rageval.types import EvalSample

_logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = "https://api.rageval.dev"


class CloudClient:
    """Synchronous cloud client.

    Args:
        api_key: ``rg_pk_live_<32 chars>`` from the dashboard's API keys page.
        base_url: override for self-hosted or staging deployments. Falls back
            to ``RAGEVAL_BASE_URL`` env var, then the production default.
        timeout: per-request timeout in seconds (default 10).
    """

    def __init__(
        self,
        api_key: str,
        base_url: str | None = None,
        timeout: float = 10.0,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        self.api_key = api_key
        self.base_url = (
            base_url or os.getenv("RAGEVAL_BASE_URL") or DEFAULT_BASE_URL
        ).rstrip("/")
        self.timeout = timeout
        self._client: httpx.Client | None = None

    @classmethod
    def from_env(cls) -> CloudClient:
        """Construct from ``RAGEVAL_API_KEY`` (and optional ``RAGEVAL_BASE_URL``)."""
        api_key = os.getenv("RAGEVAL_API_KEY")
        if not api_key:
            raise RuntimeError(
                "RAGEVAL_API_KEY environment variable not set. "
                "Generate a key in your project's API keys page."
            )
        return cls(api_key)

    def send(self, trace: Trace) -> None:
        """Send one trace (RAG ``EvalSample`` or ``AgentTrace``).

        Use as a handler with ``register_trace_handler``. Errors are logged
        but never raised — production safety.
        """
        try:
            self._post_json("/v1/traces", _build_payload(trace))
        except Exception as exc:  # noqa: BLE001
            _logger.warning("rageval CloudClient.send failed: %s", exc)

    def send_batch(self, traces: list[Trace]) -> int:
        """Send a batch in one HTTP request. Returns the number reported as accepted.

        Mixed batches (RAG + agent traces in the same call) are supported —
        each trace is serialised independently.

        Returns 0 on transport failure (logged, not raised).
        """
        if not traces:
            return 0
        try:
            response = self._post_json(
                "/v1/traces",
                {"traces": [_build_payload(t) for t in traces]},
            )
            return int(response.get("accepted", 0))
        except Exception as exc:  # noqa: BLE001
            _logger.warning("rageval CloudClient.send_batch failed: %s", exc)
            return 0

    def _post_json(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        client = self._ensure_client()
        url = f"{self.base_url}{path}"
        response = client.post(
            url,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            json=body,
        )
        response.raise_for_status()
        try:
            data = response.json()
            return data if isinstance(data, dict) else {}
        except ValueError:
            return {}

    def _ensure_client(self) -> httpx.Client:
        if self._client is None:
            self._client = httpx.Client(timeout=self.timeout)
        return self._client

    def close(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> CloudClient:
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()


class AsyncCloudClient:
    """Async equivalent of :class:`CloudClient`."""

    def __init__(
        self,
        api_key: str,
        base_url: str | None = None,
        timeout: float = 10.0,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        self.api_key = api_key
        self.base_url = (
            base_url or os.getenv("RAGEVAL_BASE_URL") or DEFAULT_BASE_URL
        ).rstrip("/")
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None

    @classmethod
    def from_env(cls) -> AsyncCloudClient:
        api_key = os.getenv("RAGEVAL_API_KEY")
        if not api_key:
            raise RuntimeError(
                "RAGEVAL_API_KEY environment variable not set. "
                "Generate a key in your project's API keys page."
            )
        return cls(api_key)

    async def send(self, trace: Trace) -> None:
        try:
            await self._post_json("/v1/traces", _build_payload(trace))
        except Exception as exc:  # noqa: BLE001
            _logger.warning("rageval AsyncCloudClient.send failed: %s", exc)

    async def send_batch(self, traces: list[Trace]) -> int:
        if not traces:
            return 0
        try:
            response = await self._post_json(
                "/v1/traces",
                {"traces": [_build_payload(t) for t in traces]},
            )
            return int(response.get("accepted", 0))
        except Exception as exc:  # noqa: BLE001
            _logger.warning("rageval AsyncCloudClient.send_batch failed: %s", exc)
            return 0

    async def _post_json(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        client = self._ensure_client()
        url = f"{self.base_url}{path}"
        response = await client.post(
            url,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            json=body,
        )
        response.raise_for_status()
        try:
            data = response.json()
            return data if isinstance(data, dict) else {}
        except ValueError:
            return {}

    def _ensure_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> AsyncCloudClient:
        return self

    async def __aexit__(self, *_args: object) -> None:
        await self.close()


# --------------------------------------------------------------------------
# Payload builders — module-level so both sync and async clients share them.
# --------------------------------------------------------------------------
def _build_payload(trace: Trace) -> dict[str, Any]:
    """Dispatch by trace shape — EvalSample (RAG) or AgentTrace (multi-step)."""
    if isinstance(trace, AgentTrace):
        return _build_agent_payload(trace)
    return _build_sample_payload(trace)


def _build_sample_payload(sample: EvalSample) -> dict[str, Any]:
    return {
        "trace_id": str(uuid4()),
        "query": sample.query,
        "context": list(sample.context),
        "answer": sample.answer,
        "ground_truth": sample.ground_truth,
    }


def _build_agent_payload(trace: AgentTrace) -> dict[str, Any]:
    """Serialise an AgentTrace into the API ingestion shape.

    The root row carries the goal + final_answer (as `answer`). Steps are
    listed in `steps[]`; the API expands them into individual rows that
    share the trace_id as parent_trace_id.
    """
    # Use trace_id as the root's trace_id so the parent linkage is stable.
    return {
        "trace_id": trace.trace_id,
        "query": trace.goal,
        "context": [],
        "answer": trace.final_answer or "",
        "ground_truth": None,
        "metadata": trace.metadata or None,
        "goal": trace.goal,
        "tool_specs": trace.tool_specs,
        "steps": [
            {
                "step_index": s.step_index,
                "step_type": s.step_type,
                "tool_name": s.tool_name,
                "step_input": s.step_input,
                "step_output": s.step_output,
                "tokens_in": s.tokens_in,
                "tokens_out": s.tokens_out,
                "latency_ms": s.latency_ms,
            }
            for s in trace.steps
        ],
    }
