"""Allow ``python -m rageval ...`` as an alternative to the ``rageval`` script."""

from __future__ import annotations

from rageval.cli import main

if __name__ == "__main__":
    main()
