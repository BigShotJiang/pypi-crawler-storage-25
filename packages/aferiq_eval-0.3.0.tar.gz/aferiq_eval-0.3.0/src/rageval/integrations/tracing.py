"""``@trace`` decorator: capture (query, context, answer) from a RAG function.

Auto-detection: matches function parameter names against known patterns
(``query``/``question``/``prompt``/``input`` for query;
``context``/``chunks``/``documents``/``docs``/``sources``/``passages`` for context).
Answer is always the function's return value.

Override with ``capture={"query": "user_q", "context": "retrieved"}``.

Captured traces are dispatched to handlers registered via
``register_trace_handler``. With no handler, the decorator is effectively a no-op
(zero overhead beyond a function-call wrapping).

This module is intentionally minimal — it does NOT introspect local variables
of the decorated function. If your RAG fn computes the context internally and
the parameter is e.g. ``retriever``, refactor or use a wrapper.
"""

from __future__ import annotations

import asyncio
import functools
import inspect
import logging
from collections.abc import Callable
from typing import Any

from rageval.agent import AgentTrace, Trace
from rageval.types import EvalSample

_logger = logging.getLogger(__name__)

TraceHandler = Callable[[Trace], None]
"""A trace handler is any callable that receives a Trace (EvalSample for RAG
or AgentTrace for agent runs) and returns None.

Existing handlers that only know about EvalSample still work — they just
receive AgentTrace objects too once agent integrations are active. Such
handlers should isinstance-check before treating the value as a sample
(e.g. CloudClient.send dispatches by shape).
"""

_QUERY_NAMES: frozenset[str] = frozenset(
    {
        "query",
        "question",
        "prompt",
        "input",
        "user_query",
        "user_input",
        "user_message",
        "message",
        "msg",
        "text",
        "user_text",
        "q",
    }
)
_CONTEXT_NAMES: frozenset[str] = frozenset(
    {
        "context",
        "contexts",
        "chunks",
        "documents",
        "docs",
        "sources",
        "passages",
        "retrieved",
        "retrieved_docs",
        "ctx",
    }
)

_handlers: list[TraceHandler] = []


def register_trace_handler(handler: TraceHandler) -> None:
    """Register a handler invoked for every captured trace.

    Handlers are called in registration order. Handler exceptions are logged
    but never raised — a buggy handler does not break the user's RAG fn.

    Common handlers:
        - ``list.append`` — collect locally for batch eval
        - ``CloudClient(api_key=...).send`` — forward to cloud (Phase 6)
        - file/log writer
    """
    _handlers.append(handler)


def clear_trace_handlers() -> None:
    """Remove all registered handlers. Idempotent. Mainly used in tests."""
    _handlers.clear()


def _emit(sample: EvalSample) -> None:
    """Broadcast a single-turn RAG sample to all handlers."""
    for handler in _handlers:
        try:
            handler(sample)
        except Exception as exc:  # noqa: BLE001
            _logger.warning("rageval trace handler raised: %s", exc)


def _emit_trace(trace: AgentTrace) -> None:
    """Broadcast an agent trajectory to all handlers.

    Same registry as RAG samples — handlers receive both shapes mixed and
    should isinstance-check (or accept Trace) accordingly.
    """
    for handler in _handlers:
        try:
            handler(trace)
        except Exception as exc:  # noqa: BLE001
            _logger.warning("rageval trace handler raised: %s", exc)


def _detect_named_param(
    bound_args: dict[str, Any], names: frozenset[str]
) -> tuple[str, Any] | None:
    for name, value in bound_args.items():
        if name.lower() in names:
            return name, value
    return None


def _coerce_context(value: Any) -> list[str] | None:
    if value is None:
        return None
    if isinstance(value, str):
        return [value]
    if isinstance(value, list | tuple):
        return [str(item) for item in value]
    return None


def _build_sample(
    fn_name: str,
    bound_args: dict[str, Any],
    result: Any,
    capture: dict[str, str] | None,
) -> EvalSample | None:
    """Try to assemble an EvalSample. Logs warnings on detection failures."""
    if capture and "query" in capture:
        query_value = bound_args.get(capture["query"])
    else:
        detected = _detect_named_param(bound_args, _QUERY_NAMES)
        query_value = detected[1] if detected else None

    if not isinstance(query_value, str):
        _logger.warning(
            "rageval @trace: could not detect 'query' parameter for %s. "
            "Use capture={'query': 'arg_name'} to override. "
            "See docs/pt/integrations.md.",
            fn_name,
        )
        return None

    if capture and "context" in capture:
        context_value = bound_args.get(capture["context"])
    else:
        detected = _detect_named_param(bound_args, _CONTEXT_NAMES)
        context_value = detected[1] if detected else None

    context_list = _coerce_context(context_value)
    if context_list is None:
        # Tool-calling agents and pure conversational bots often have no
        # explicit context arg — context is built internally from tool
        # results. Emit the trace with an empty context list so the user
        # still gets observability. Pair with patch_openai() to capture
        # per-LLM-call detail as steps.
        _logger.debug(
            "rageval @trace: no 'context' parameter for %s — emitting with "
            "empty context list. If you need explicit context, add a param "
            "matching one of %s or pass capture={'context': 'arg_name'}.",
            fn_name,
            sorted(_CONTEXT_NAMES),
        )
        context_list = []

    answer = result if isinstance(result, str) else str(result)

    return EvalSample(query=query_value, context=context_list, answer=answer)


def trace(
    fn: Callable[..., Any] | None = None,
    *,
    capture: dict[str, str] | None = None,
) -> Callable[..., Any]:
    """Decorator that captures (query, context, answer) from a RAG function.

    Usage::

        from rageval.integrations import trace

        @trace
        def my_rag(query: str, context: list[str]) -> str:
            return llm.generate(query, context)

    Override auto-detection::

        @trace(capture={"query": "user_q", "context": "retrieved_docs"})
        def my_rag(user_q: str, retrieved_docs: list[str]) -> str:
            ...

    Async functions are supported — the decorator detects coroutine functions
    automatically and emits the trace after the awaitable resolves.

    Captured traces go to handlers registered via ``register_trace_handler``.
    With no registered handlers, the decorator is essentially a pass-through.
    """

    def decorator(target_fn: Callable[..., Any]) -> Callable[..., Any]:
        sig = inspect.signature(target_fn)

        if asyncio.iscoroutinefunction(target_fn):

            @functools.wraps(target_fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                result = await target_fn(*args, **kwargs)
                _try_emit(target_fn.__name__, sig, args, kwargs, result, capture)
                return result

            return async_wrapper

        @functools.wraps(target_fn)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            result = target_fn(*args, **kwargs)
            _try_emit(target_fn.__name__, sig, args, kwargs, result, capture)
            return result

        return sync_wrapper

    if fn is not None:
        return decorator(fn)
    return decorator


def _try_emit(
    fn_name: str,
    sig: inspect.Signature,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    result: Any,
    capture: dict[str, str] | None,
) -> None:
    """Bind args, build EvalSample, dispatch — swallowing any errors."""
    if not _handlers:
        return  # short-circuit: zero overhead when no handlers registered
    try:
        bound = sig.bind_partial(*args, **kwargs)
        bound.apply_defaults()
        sample = _build_sample(fn_name, dict(bound.arguments), result, capture)
        if sample is not None:
            _emit(sample)
    except Exception as exc:  # noqa: BLE001
        _logger.warning("rageval @trace failed for %s: %s", fn_name, exc)
