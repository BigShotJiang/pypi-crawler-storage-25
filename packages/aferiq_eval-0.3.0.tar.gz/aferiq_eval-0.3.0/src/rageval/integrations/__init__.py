"""Framework integrations.

Submodules:

- ``rageval.integrations.tracing`` — ``@trace`` decorator + handler registry
- ``rageval.integrations.langchain`` — LangChain callback (RAG: RetrievalQA)
- ``rageval.integrations.llamaindex`` — LlamaIndex callback (RAG)
- ``rageval.integrations.agent_callback`` — agent callback for LangChain
  AgentExecutor and LangGraph (uses ``langchain-core``'s BaseCallbackHandler)
- ``rageval.integrations.langgraph`` — convenience re-exports for LangGraph
- ``rageval.integrations.openai_patch`` / ``anthropic_patch`` — SDK monkey
  patches activated by ``aferiq-trace-run`` for token + latency capture

The decorator and handler registry are always available. The framework-specific
handlers and monkey patches are imported lazily — they raise a clear
ImportError pointing at the missing dep only when actually imported by user
code.
"""

from __future__ import annotations

from rageval.integrations.tracing import (
    clear_trace_handlers,
    register_trace_handler,
    trace,
)

__all__ = [
    "clear_trace_handlers",
    "register_trace_handler",
    "trace",
]
