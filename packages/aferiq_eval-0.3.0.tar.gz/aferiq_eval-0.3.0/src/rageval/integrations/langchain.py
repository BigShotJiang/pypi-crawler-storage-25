"""LangChain callback handler.

Captures (query, context, answer) from a LangChain chain and emits an
``EvalSample`` to all registered trace handlers.

Requires ``langchain-core>=0.3.0`` — install with ``pip install langchain-core``.

Usage::

    from rageval.integrations.langchain import RAGEvalCallbackHandler

    handler = RAGEvalCallbackHandler()
    chain.invoke({"query": "..."}, config={"callbacks": [handler]})

    # later:
    samples = handler.traces
    result = evaluate_samples(samples, metrics=["faithfulness"])

The handler supports three chain shapes:

1. **Classic** — ``RetrievalQA.from_chain_type`` and similar pre-LCEL chains.
   Events fire as ``on_chain_start`` → ``on_retriever_end`` → ``on_llm_end``.

2. **LCEL with explicit retriever** — composed chains where the retriever is
   a top-level step::

       chain = retriever | format_docs | prompt | llm | parser

   ``on_retriever_end`` fires reliably; standard flow.

3. **LCEL with retriever nested in a RunnableParallel** — modern pattern::

       chain = (
           {"context": retriever | format_docs, "question": ...}
           | prompt | llm | parser
       )

   In some langchain-core versions, ``on_retriever_end`` does not propagate
   from inside the parallel map. The handler falls back to extracting docs
   captured by ``on_retriever_end`` if it fired, or emits with empty context
   otherwise. Either way, a trace is emitted at the outermost ``on_chain_end``
   so the user gets observability without code patches.

The handler also listens to ``on_chat_model_end`` (modern chat models) in
addition to ``on_llm_end`` (text LLMs), since LangChain core dispatches to
different methods depending on the model class.

Concurrent chains in the same handler instance are not isolated — instantiate
one handler per request, OR use the ``rageval.integrations.tracing.trace``
decorator on your top-level RAG function instead.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

try:
    from langchain_core.callbacks import BaseCallbackHandler
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "rageval.integrations.langchain requires langchain-core. "
        "Install with: pip install langchain-core"
    ) from e

# Re-export the agent handler for convenience — same module surface.
# Users can do `from rageval.integrations.langchain import AferiqAgentCallbackHandler`
# regardless of whether they're on AgentExecutor (langchain) or LangGraph.
from rageval.integrations.agent_callback import AferiqAgentCallbackHandler  # noqa: F401,E402
from rageval.integrations.tracing import _emit
from rageval.types import EvalSample

# Common keys LangChain users assign to "the user's question". The handler
# checks them in order on the outermost chain's inputs.
_QUERY_KEYS = ("query", "question", "input", "user_input", "prompt")

# Common keys for the chain's final answer when extracting from outputs.
_ANSWER_KEYS = ("answer", "output", "result", "text", "response")


class RAGEvalCallbackHandler(BaseCallbackHandler):
    """LangChain callback that captures one RAG trace per outer chain run.

    Emission strategy:
        - Track the outermost chain by ``run_id`` (the first chain start
          where ``parent_run_id`` is None).
        - Capture query from that start's inputs.
        - Capture context from ``on_retriever_end`` if it fires.
        - Capture answer from ``on_llm_end`` / ``on_chat_model_end`` if they
          fire — fall back to the chain's output dict on ``on_chain_end``.
        - Emit one ``EvalSample`` when the outermost chain ends.

    Each emitted sample is also broadcast to handlers registered via
    ``rageval.integrations.tracing.register_trace_handler``.
    """

    raise_error: bool = False

    def __init__(self) -> None:
        super().__init__()
        self.traces: list[EvalSample] = []
        self._root_run_id: UUID | None = None
        self._current_query: str | None = None
        self._current_context: list[str] | None = None
        self._current_answer: str | None = None

    @property
    def last_trace(self) -> EvalSample | None:
        """Most recently emitted trace, or None if none yet."""
        return self.traces[-1] if self.traces else None

    def clear(self) -> None:
        """Reset traces and any in-progress capture state."""
        self.traces.clear()
        self._reset_run()

    def _reset_run(self) -> None:
        self._root_run_id = None
        self._current_query = None
        self._current_context = None
        self._current_answer = None

    # ------------------------------------------------------------------
    # Chain lifecycle — track the outermost run and capture query/answer.
    # ------------------------------------------------------------------

    def on_chain_start(
        self,
        serialized: dict[str, Any] | None,
        inputs: dict[str, Any] | Any,
        *,
        run_id: UUID | None = None,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        # Only treat the FIRST start with no parent as the outermost. Nested
        # chain_starts inside the same run share the same handler instance.
        if self._root_run_id is not None:
            return
        if parent_run_id is not None:
            return
        self._root_run_id = run_id
        self._current_query = _extract_query(inputs)

    def on_chain_end(
        self,
        outputs: dict[str, Any] | Any,
        *,
        run_id: UUID | None = None,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        # Emit only when the outermost chain ends.
        if run_id is None or run_id != self._root_run_id:
            return

        # Fallback: if no LLM event fired, try to extract answer from outputs.
        answer = self._current_answer
        if answer is None:
            answer = _extract_answer_from_output(outputs)

        # Need at least query + answer to be useful. Context can be empty
        # (LCEL with nested retriever may not fire on_retriever_end).
        if self._current_query is not None and answer is not None:
            sample = EvalSample(
                query=self._current_query,
                context=self._current_context or [],
                answer=answer,
            )
            self.traces.append(sample)
            _emit(sample)

        self._reset_run()

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID | None = None,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        # Reset on outermost error so the next run starts clean.
        if run_id is not None and run_id == self._root_run_id:
            self._reset_run()

    # ------------------------------------------------------------------
    # Retriever — best-effort capture of context.
    # ------------------------------------------------------------------

    def on_retriever_end(
        self,
        documents: Any,
        *,
        run_id: UUID | None = None,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        try:
            self._current_context = [
                getattr(doc, "page_content", str(doc)) for doc in documents
            ]
        except TypeError:
            self._current_context = []

    # ------------------------------------------------------------------
    # LLM / Chat model — capture answer.
    # ------------------------------------------------------------------

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: UUID | None = None,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        if self._current_answer is not None:
            return  # already captured (e.g. from on_chat_model_end)
        answer = _extract_llm_answer(response)
        if answer is not None:
            self._current_answer = answer

    def on_chat_model_end(
        self,
        response: Any,
        *,
        run_id: UUID | None = None,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        # Modern ChatModel implementations call on_chat_model_end at the end
        # of streaming. Some LangChain versions also fire on_llm_end after,
        # so first-write-wins to avoid double overwrite.
        if self._current_answer is not None:
            return
        answer = _extract_llm_answer(response)
        if answer is not None:
            self._current_answer = answer


def _extract_query(inputs: Any) -> str | None:
    """Pull the user's question from the chain's input.

    Tries common dict keys, then falls back to the raw input if it's a string.
    """
    if isinstance(inputs, dict):
        for key in _QUERY_KEYS:
            value = inputs.get(key)
            if isinstance(value, str) and value:
                return value
        # Some LCEL chains nest the message inside ``messages`` or similar.
        messages = inputs.get("messages")
        if isinstance(messages, list) and messages:
            last = messages[-1]
            content = getattr(last, "content", None)
            if isinstance(content, str) and content:
                return content
    elif isinstance(inputs, str) and inputs:
        return inputs
    return None


def _extract_answer_from_output(outputs: Any) -> str | None:
    """Pull the answer from the outermost chain's outputs.

    Used as a fallback when neither on_llm_end nor on_chat_model_end fired
    (rare, but happens with custom LCEL chains that bypass standard hooks).
    """
    if isinstance(outputs, str) and outputs:
        return outputs
    if isinstance(outputs, dict):
        for key in _ANSWER_KEYS:
            value = outputs.get(key)
            if isinstance(value, str) and value:
                return value
        # Some chains return the parsed message under a model-specific key —
        # walk one level looking for any string value as last resort.
        for value in outputs.values():
            if isinstance(value, str) and value:
                return value
    # ChatMessage / AIMessage with .content
    content = getattr(outputs, "content", None)
    if isinstance(content, str) and content:
        return content
    return None


def _extract_llm_answer(response: Any) -> str | None:
    """Pull the answer text from a LangChain LLMResult-shaped object."""
    generations = getattr(response, "generations", None)
    if not generations:
        return None
    try:
        first = generations[0]
        if not first:
            return None
        gen = first[0]
        text = getattr(gen, "text", None)
        if isinstance(text, str) and text:
            return text
        message = getattr(gen, "message", None)
        if message is not None:
            content = getattr(message, "content", None)
            if isinstance(content, str) and content:
                return content
    except (IndexError, AttributeError):
        return None
    return None
