"""Monkey-patch OpenAI's ``chat.completions.create`` to capture tokens + latency.

Activated by ``aferiq-trace-run`` (or the env-var-only mode). When an OpenAI
chat completion fires inside an active trajectory (see ``_context``), we
record an ``AgentStep`` of type ``llm`` with the response's prompt/completion
tokens and the wall-clock latency.

Outside a trajectory the call is untouched — no overhead beyond a single
ContextVar read.

Supports both:
  - openai >= 1.0 (current): ``client.chat.completions.create(...)``
  - openai >= 1.0 async:     ``await client.chat.completions.create(...)``

Legacy ``openai.ChatCompletion.create`` (openai < 1.0) is NOT supported —
that SDK is deprecated and barely used in 2026.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from rageval.integrations._context import has_active_trajectory, record_step

_log = logging.getLogger(__name__)
_patched = False


def patch_openai(*, emit_standalone: bool = False) -> bool:
    """Install the patch. Idempotent — calling twice is a no-op.

    Two modes:

    - **Trajectory mode** (default): when ``chat.completions.create`` fires
      inside an active ``@aferiq.trace`` function, the call is recorded as
      an ``AgentStep`` of the parent trajectory. Outside a trajectory the
      call is untouched — zero overhead, zero traces.

    - **Standalone mode** (``emit_standalone=True``, used by
      ``aferiq.start()``): same as trajectory mode AND additionally
      emits a standalone ``EvalSample`` (query=last user message,
      context=[], answer=response content) for every bare LLM call
      outside a trajectory. This makes the "1-line auto-capture every
      call" promise actually work.

    Args:
        emit_standalone: emit traces for bare LLM calls outside any
            ``@aferiq.trace`` function. Default ``False`` for backwards
            compat. ``aferiq.start()`` sets this to ``True`` automatically.

    Returns True if patched, False if openai is not importable (silent skip).
    """
    global _patched
    if _patched:
        return True
    try:
        from openai.resources.chat import (
            AsyncCompletions,
            Completions,
        )
        from openai.resources.chat import completions as _completions  # noqa: F401
    except ImportError:
        _log.debug("openai SDK not installed; patch skipped")
        return False

    _patch_sync(Completions, emit_standalone)
    _patch_async(AsyncCompletions, emit_standalone)

    _patched = True
    return True


def _patch_sync(Completions: Any, emit_standalone: bool) -> None:  # noqa: N803  -- mirrors openai SDK class name
    if getattr(Completions.create, "_aferiq_patched", False):
        return
    original = Completions.create

    def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        if has_active_trajectory():
            # Trajectory mode — record as step of parent trace
            t0 = time.perf_counter()
            try:
                response = original(self, *args, **kwargs)
            except Exception:
                latency = int((time.perf_counter() - t0) * 1000)
                _safe_record(latency_ms=latency, step_input=_summarize_messages(kwargs))
                raise
            latency = int((time.perf_counter() - t0) * 1000)
            tokens_in, tokens_out = _extract_usage(response)
            _safe_record(
                latency_ms=latency,
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                step_input=_summarize_messages(kwargs),
                step_output=_summarize_response(response),
            )
            return response

        # No trajectory — call passes through. If emit_standalone is set,
        # emit a standalone EvalSample after the response lands.
        response = original(self, *args, **kwargs)
        if emit_standalone:
            _emit_standalone_chat_trace(kwargs, response)
        return response

    wrapped._aferiq_patched = True  # type: ignore[attr-defined]
    Completions.create = wrapped


def _patch_async(AsyncCompletions: Any, emit_standalone: bool) -> None:  # noqa: N803  -- mirrors openai SDK class name
    if getattr(AsyncCompletions.create, "_aferiq_patched", False):
        return
    original = AsyncCompletions.create

    async def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        if has_active_trajectory():
            t0 = time.perf_counter()
            try:
                response = await original(self, *args, **kwargs)
            except Exception:
                latency = int((time.perf_counter() - t0) * 1000)
                _safe_record(latency_ms=latency, step_input=_summarize_messages(kwargs))
                raise
            latency = int((time.perf_counter() - t0) * 1000)
            tokens_in, tokens_out = _extract_usage(response)
            _safe_record(
                latency_ms=latency,
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                step_input=_summarize_messages(kwargs),
                step_output=_summarize_response(response),
            )
            return response

        response = await original(self, *args, **kwargs)
        if emit_standalone:
            _emit_standalone_chat_trace(kwargs, response)
        return response

    wrapped._aferiq_patched = True  # type: ignore[attr-defined]
    AsyncCompletions.create = wrapped


def _emit_standalone_chat_trace(kwargs: dict[str, Any], response: Any) -> None:
    """Emit a standalone EvalSample for a bare chat.completions.create call.

    Extracts:
      - query   = content of the last `user` message in kwargs.messages
      - context = [] (no retrieval visible at the patch layer)
      - answer  = response.choices[0].message.content

    Silently skips (no trace emitted) when:
      - No user message found
      - Response has no text content (e.g., tool_calls only — those happen
        in agent loops where @aferiq.trace on the entry function captures
        the turn instead)
      - Anything raises (handler must NEVER break user code)
    """
    try:
        from rageval.integrations.tracing import _emit
        from rageval.types import EvalSample

        messages = kwargs.get("messages") or []
        user_msgs = [
            m.get("content", "")
            for m in messages
            if isinstance(m, dict) and m.get("role") == "user"
        ]
        query = user_msgs[-1] if user_msgs else ""
        if not isinstance(query, str) or not query.strip():
            return

        # Pull answer from response (Pydantic or dict shape)
        answer: str = ""
        try:
            choices = getattr(response, "choices", None) or response.get("choices")
            if not choices:
                return
            first = choices[0]
            msg = getattr(first, "message", None) or first.get("message")
            content = getattr(msg, "content", None) or (
                msg.get("content") if isinstance(msg, dict) else None
            )
            if isinstance(content, str):
                answer = content
        except Exception:  # noqa: BLE001
            return

        if not answer.strip():
            return  # tool_calls or empty — skip

        sample = EvalSample(query=query, context=[], answer=answer)
        _emit(sample)
    except Exception as exc:  # noqa: BLE001
        _log.debug("standalone chat trace emit failed: %s", exc)


def _extract_usage(response: Any) -> tuple[int | None, int | None]:
    """Pull (prompt_tokens, completion_tokens) from a ChatCompletion response.

    Tolerates dict-shape (legacy) and Pydantic-shape (current). Returns
    ``(None, None)`` if the shape is unrecognised — never raises.

    Handles the case where one field is present and the other is None on a
    class-instance shape (the SDK sometimes sets only prompt_tokens early).
    """
    usage: Any = None
    try:
        if isinstance(response, dict):
            usage = response.get("usage")
        else:
            usage = getattr(response, "usage", None)
    except Exception:
        return None, None
    if usage is None:
        return None, None

    if isinstance(usage, dict):
        pt = usage.get("prompt_tokens")
        ct = usage.get("completion_tokens")
    else:
        pt = getattr(usage, "prompt_tokens", None)
        ct = getattr(usage, "completion_tokens", None)

    return (
        int(pt) if pt is not None else None,
        int(ct) if ct is not None else None,
    )


def _summarize_messages(kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Compact representation of the request — model + last-user-message preview."""
    messages = kwargs.get("messages")
    model = kwargs.get("model")
    if not messages:
        return {"model": model} if model else None
    try:
        # Last user message preview, ≤200 chars.
        last_user = next(
            (m.get("content") for m in reversed(messages) if m.get("role") == "user"),
            None,
        )
        preview = (last_user or "")[:200] if isinstance(last_user, str) else None
        return {
            "model": model,
            "n_messages": len(messages),
            "last_user_preview": preview,
        }
    except Exception:
        return {"model": model}


def _summarize_response(response: Any) -> dict[str, Any] | None:
    """Compact representation of the response — first choice content preview + finish_reason."""
    try:
        choices = getattr(response, "choices", None) or response.get("choices")
        if not choices:
            return None
        first = choices[0]
        msg = getattr(first, "message", None) or first.get("message")
        content = getattr(msg, "content", None) or (msg.get("content") if msg else None)
        finish = getattr(first, "finish_reason", None) or first.get("finish_reason")
        preview = (content or "")[:200] if isinstance(content, str) else None
        return {"finish_reason": finish, "preview": preview}
    except Exception:
        return None


def _safe_record(**kwargs: Any) -> None:
    """Record an LLM step, swallowing any exception — never break user code."""
    try:
        record_step(step_type="llm", **kwargs)
    except Exception as e:
        _log.debug("record_step failed: %s", e)
