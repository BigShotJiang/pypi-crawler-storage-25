"""LangGraph integration — convenience re-exports.

LangGraph extends ``langchain_core``'s callback API, so the same handler
that captures AgentExecutor traces also captures LangGraph runs::

    from rageval.integrations.langgraph import AferiqAgentCallbackHandler

    handler = AferiqAgentCallbackHandler(goal="...")
    graph.invoke(state, config={"callbacks": [handler]})

If you have ``langgraph`` installed but the import below fails, you're
likely on an old version (<0.2) — upgrade with ``pip install -U langgraph``.
"""

from __future__ import annotations

# We don't strictly require ``langgraph`` to be installed for the callback
# to work — it only needs ``langchain-core``. But we do a soft import to
# fail loudly if someone tries to use this module without LangGraph at all.
try:
    import langgraph  # noqa: F401
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "rageval.integrations.langgraph requires langgraph. "
        "Install with: pip install langgraph"
    ) from e

from rageval.integrations.agent_callback import AferiqAgentCallbackHandler

__all__ = ["AferiqAgentCallbackHandler"]
