"""OpenAI Assistants API integration — streaming event handler.

Captures every Run step (LLM call, tool call) into an ``AgentTrace`` and
emits it via the trace handler registry on completion.

Usage::

    from openai import OpenAI
    from rageval.integrations.openai_assistants import AferiqAssistantHandler

    client = OpenAI()
    with client.beta.threads.runs.stream(
        thread_id=thread.id,
        assistant_id=assistant.id,
        event_handler=AferiqAssistantHandler(goal="Qual o prazo do CDC?"),
    ) as stream:
        stream.until_done()

The handler builds an ``AgentTrace`` as the run streams. When the run ends
(``on_end``), it broadcasts the trace via the registered handler registry.

Tools called by the assistant become step_type="tool"; LLM completions
become step_type="llm". Token counts come from the run's `usage` field
when available.
"""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any, Literal

try:
    from openai.lib.streaming import AssistantEventHandler
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "rageval.integrations.openai_assistants requires openai>=1.40. "
        "Install with: pip install 'openai>=1.40'"
    ) from e

from rageval.integrations._context import (
    end_trajectory,
    record_step,
    start_trajectory,
)
from rageval.integrations.tracing import _emit_trace

_log = logging.getLogger(__name__)


class AferiqAssistantHandler(AssistantEventHandler):
    """Drop-in event handler for ``client.beta.threads.runs.stream``.

    Notes:
        - Best-effort capture: the Assistants SDK shape changes occasionally.
          Each event handler swallows exceptions and logs at debug level so a
          shape mismatch never breaks the user's run.
        - Token counts: the API exposes `run.usage` in the final ``thread.run.completed``
          event, so per-step token capture is not always available. We record
          per-step latency via wall-clock timing.
    """

    def __init__(
        self,
        goal: str,
        tool_specs: list[dict[str, Any]] | None = None,
    ) -> None:
        super().__init__()
        self._goal = goal
        self._tool_specs = tool_specs
        self._step_start: dict[str, float] = {}
        # Lazy-start trajectory on first event so we can use the run_id as
        # the trace_id when available.
        self._trajectory_id: str | None = None

    # ------------------------------------------------------------------
    # Run + Step lifecycle
    # ------------------------------------------------------------------
    def on_run_step_created(self, run_step: Any) -> None:
        try:
            self._ensure_trajectory(run_step)
            self._step_start[run_step.id] = time.perf_counter()
        except Exception as e:  # noqa: BLE001
            _log.debug("on_run_step_created failed: %s", e)

    def on_run_step_done(self, run_step: Any) -> None:
        try:
            latency = self._compute_latency(run_step.id)
            step_type = self._derive_step_type(run_step)
            tokens_in, tokens_out = self._extract_step_tokens(run_step)
            tool_name = self._derive_tool_name(run_step)
            record_step(
                step_type=step_type,
                tool_name=tool_name,
                step_input=self._extract_step_input(run_step),
                step_output=self._extract_step_output(run_step),
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                latency_ms=latency,
            )
        except Exception as e:  # noqa: BLE001
            _log.debug("on_run_step_done failed: %s", e)

    def on_message_done(self, message: Any) -> None:
        # Final assistant message — usually after the last LLM step. We
        # snapshot it so on_end can use it as final_answer.
        try:
            self._final_answer = _extract_message_text(message)
        except Exception as e:  # noqa: BLE001
            _log.debug("on_message_done failed: %s", e)

    def on_end(self) -> None:
        try:
            trace = end_trajectory(final_answer=getattr(self, "_final_answer", None))
            if trace is not None:
                _emit_trace(trace)
        except Exception as e:  # noqa: BLE001
            _log.debug("on_end failed: %s", e)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _ensure_trajectory(self, run_step: Any) -> None:
        if self._trajectory_id is not None:
            return
        run_id = getattr(run_step, "run_id", None) or str(uuid.uuid4())
        self._trajectory_id = start_trajectory(
            goal=self._goal,
            trace_id=run_id,
            tool_specs=self._tool_specs,
        )

    def _compute_latency(self, step_id: str) -> int | None:
        t0 = self._step_start.pop(step_id, None)
        if t0 is None:
            return None
        return int((time.perf_counter() - t0) * 1000)

    def _derive_step_type(
        self, run_step: Any
    ) -> Literal["llm", "tool", "retrieval", "agent_action"]:
        # OpenAI run_step.type ∈ {"message_creation", "tool_calls"}
        rs_type = getattr(run_step, "type", None)
        if rs_type == "tool_calls":
            return "tool"
        if rs_type == "message_creation":
            return "llm"
        return "agent_action"

    def _derive_tool_name(self, run_step: Any) -> str | None:
        details = getattr(run_step, "step_details", None)
        if not details:
            return None
        tool_calls = getattr(details, "tool_calls", None)
        if not tool_calls:
            return None
        try:
            first = tool_calls[0]
            t = getattr(first, "type", None)
            if t == "function":
                fn = getattr(first, "function", None)
                return getattr(fn, "name", None) if fn else None
            return t
        except Exception:
            return None

    def _extract_step_input(self, run_step: Any) -> dict[str, Any] | str | None:
        details = getattr(run_step, "step_details", None)
        if not details:
            return None
        tool_calls = getattr(details, "tool_calls", None)
        if tool_calls:
            try:
                first = tool_calls[0]
                fn = getattr(first, "function", None)
                if fn:
                    return {"arguments": getattr(fn, "arguments", "")}
            except Exception:
                return None
        return None

    def _extract_step_output(self, run_step: Any) -> dict[str, Any] | str | None:
        details = getattr(run_step, "step_details", None)
        if not details:
            return None
        tool_calls = getattr(details, "tool_calls", None)
        if tool_calls:
            try:
                first = tool_calls[0]
                fn = getattr(first, "function", None)
                if fn and getattr(fn, "output", None):
                    return {"output": fn.output}
            except Exception:
                return None
        return None

    def _extract_step_tokens(
        self, run_step: Any
    ) -> tuple[int | None, int | None]:
        usage = getattr(run_step, "usage", None)
        if not usage:
            return None, None
        try:
            ti = getattr(usage, "prompt_tokens", None)
            to = getattr(usage, "completion_tokens", None)
            return (
                int(ti) if ti is not None else None,
                int(to) if to is not None else None,
            )
        except Exception:
            return None, None


def _extract_message_text(message: Any) -> str | None:
    try:
        content = getattr(message, "content", None)
        if not content:
            return None
        for block in content:
            text = getattr(block, "text", None)
            value = getattr(text, "value", None) if text else None
            if isinstance(value, str) and value:
                return value
    except Exception:
        return None
    return None
