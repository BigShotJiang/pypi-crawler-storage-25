"""LlamaIndex callback handler.

Captures (query, context, answer) from a LlamaIndex query engine by hooking
into ``CBEventType.QUERY`` (query), ``CBEventType.RETRIEVE`` (context), and
``CBEventType.LLM`` or synthesizer events (answer).

Requires ``llama-index-core>=0.11.0`` — install with ``pip install llama-index-core``.

Usage::

    from llama_index.core import Settings
    from rageval.integrations.llamaindex import RAGEvalCallbackHandler

    handler = RAGEvalCallbackHandler()
    Settings.callback_manager.add_handler(handler)

    response = query_engine.query("...")

    samples = handler.traces

The handler captures the simplest case: one query → one retrieve → one synthesize.
For more complex flows, use the decorator-based approach in
``rageval.integrations.tracing``.
"""

from __future__ import annotations

from typing import Any

try:
    from llama_index.core.callbacks.base_handler import BaseCallbackHandler
    from llama_index.core.callbacks.schema import CBEventType, EventPayload
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "rageval.integrations.llamaindex requires llama-index-core. "
        "Install with: pip install llama-index-core"
    ) from e

from rageval.integrations.tracing import _emit
from rageval.types import EvalSample


class RAGEvalCallbackHandler(BaseCallbackHandler):
    """LlamaIndex callback that captures RAG traces."""

    def __init__(self) -> None:
        super().__init__(event_starts_to_ignore=[], event_ends_to_ignore=[])
        self.traces: list[EvalSample] = []
        self._current_query: str | None = None
        self._current_context: list[str] | None = None

    @property
    def last_trace(self) -> EvalSample | None:
        return self.traces[-1] if self.traces else None

    def clear(self) -> None:
        self.traces.clear()
        self._current_query = None
        self._current_context = None

    def start_trace(self, trace_id: str | None = None) -> None:
        self._current_query = None
        self._current_context = None

    def end_trace(
        self,
        trace_id: str | None = None,
        trace_map: dict[str, list[str]] | None = None,
    ) -> None:
        return None

    def on_event_start(
        self,
        event_type: CBEventType,
        payload: dict[Any, Any] | None = None,
        event_id: str = "",
        parent_id: str = "",
        **kwargs: Any,
    ) -> str:
        if (
            event_type == CBEventType.QUERY
            and payload is not None
            and EventPayload.QUERY_STR in payload
        ):
            value = payload[EventPayload.QUERY_STR]
            if isinstance(value, str):
                self._current_query = value
        return event_id

    def on_event_end(
        self,
        event_type: CBEventType,
        payload: dict[Any, Any] | None = None,
        event_id: str = "",
        **kwargs: Any,
    ) -> None:
        if payload is None:
            return

        if event_type == CBEventType.RETRIEVE and EventPayload.NODES in payload:
            nodes = payload[EventPayload.NODES]
            self._current_context = [_node_text(n) for n in nodes]
            return

        if event_type in (CBEventType.LLM, CBEventType.SYNTHESIZE):
            answer = _extract_response(payload)
            if answer is None:
                return
            if self._current_query is not None and self._current_context is not None:
                sample = EvalSample(
                    query=self._current_query,
                    context=self._current_context,
                    answer=answer,
                )
                self.traces.append(sample)
                _emit(sample)
                self._current_query = None
                self._current_context = None


def _node_text(node: Any) -> str:
    inner = getattr(node, "node", node)
    text = getattr(inner, "text", None)
    if isinstance(text, str):
        return text
    return str(node)


def _extract_response(payload: dict[Any, Any]) -> str | None:
    response = payload.get(EventPayload.RESPONSE)
    if response is None:
        return None
    if isinstance(response, str):
        return response
    message = getattr(response, "message", None)
    if message is not None:
        content = getattr(message, "content", None)
        if isinstance(content, str) and content:
            return content
    text_attr = getattr(response, "response", None)
    if isinstance(text_attr, str) and text_attr:
        return text_attr
    return str(response)
