"""Prompt template loader.

Templates live as ``{metric}_{language}.txt`` next to this file.
Use ``load_prompt(metric, language)`` to fetch one.
"""

from __future__ import annotations

from pathlib import Path

from rageval.types import Language

_PROMPTS_DIR = Path(__file__).parent


def load_prompt(metric: str, language: Language) -> str:
    """Load ``{metric}_{language}.txt`` from the prompts directory.

    Raises:
        FileNotFoundError: if the template file does not exist.
    """
    path = _PROMPTS_DIR / f"{metric}_{language}.txt"
    if not path.exists():
        raise FileNotFoundError(
            f"Prompt template not found for metric={metric!r}, language={language!r}. "
            f"Expected at {path}."
        )
    return path.read_text(encoding="utf-8")


__all__ = ["load_prompt"]
