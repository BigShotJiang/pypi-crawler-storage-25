"""rageval CLI built with typer + rich.

Subcommands:
    rageval evaluate --dataset path.jsonl --metrics faithfulness
    rageval evaluate-agent --dataset agent_traces.jsonl --metrics trajectory_quality,goal_completion
    rageval version
    rageval metrics                 # list available metrics
    rageval agent-metrics           # list agent metrics
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from rageval import AgentStep, AgentTrace, __version__, evaluate, evaluate_agent
from rageval.cli_init import aferiq_init
from rageval.metrics import available_agent_metrics, available_metrics

app = typer.Typer(
    name="rageval",
    help="RAG evaluation for Brazilian Portuguese.",
    add_completion=False,
    no_args_is_help=True,
)

# `aferiq init` / `rageval init` — interactive setup for new projects.
app.command(name="init", help="Setup interativo do aferiq num projeto Python.")(aferiq_init)

console = Console()
err_console = Console(stderr=True, style="red")


@app.command()
def version() -> None:
    """Print the installed rageval version."""
    console.print(f"rageval [bold cyan]{__version__}[/]")


@app.command()
def metrics() -> None:
    """List RAG metrics available in this version."""
    console.print("[bold]Métricas RAG disponíveis:[/]")
    for name in available_metrics():
        console.print(f"  • {name}")


@app.command(name="agent-metrics")
def agent_metrics_cmd() -> None:
    """List agent metrics available in this version."""
    console.print("[bold]Métricas de agente disponíveis:[/]")
    for name in available_agent_metrics():
        console.print(f"  • {name}")


@app.command(name="evaluate")
def evaluate_cmd(
    dataset: Annotated[
        Path,
        typer.Option(
            "--dataset",
            "-d",
            help="JSONL file: one record per line with {query, context, answer, ground_truth?}.",
            exists=True,
            file_okay=True,
            dir_okay=False,
        ),
    ],
    metrics: Annotated[
        str,
        typer.Option(
            "--metrics",
            "-m",
            help="Comma-separated metric names. Default: faithfulness.",
        ),
    ] = "faithfulness",
    language: Annotated[
        str,
        typer.Option(
            "--language",
            "-l",
            help="Prompt language: 'pt' (default) or 'en'.",
        ),
    ] = "pt",
    judge_model: Annotated[
        str,
        typer.Option(
            "--judge-model",
            help="litellm model id for the judge (default: gpt-4o-mini).",
        ),
    ] = "gpt-4o-mini",
    output: Annotated[
        Path | None,
        typer.Option(
            "--output",
            "-o",
            help="Optional path to write the result as JSON.",
        ),
    ] = None,
) -> None:
    """Run evaluation against a JSONL dataset."""
    if language not in ("pt", "en"):
        err_console.print(f"Invalid --language: {language!r}. Use 'pt' or 'en'.")
        raise typer.Exit(2)

    metric_list = [m.strip() for m in metrics.split(",") if m.strip()]
    if not metric_list:
        err_console.print("Provide at least one metric via --metrics.")
        raise typer.Exit(2)

    queries: list[str] = []
    contexts: list[list[str]] = []
    answers: list[str] = []
    ground_truth: list[str] = []
    has_gt = True

    with dataset.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, start=1):
            stripped = line.strip()
            if not stripped:
                continue
            try:
                rec = json.loads(stripped)
            except json.JSONDecodeError as e:
                err_console.print(f"Line {line_no}: invalid JSON ({e}).")
                raise typer.Exit(2) from e

            for required in ("query", "context", "answer"):
                if required not in rec:
                    err_console.print(f"Line {line_no} missing required field {required!r}.")
                    raise typer.Exit(2)

            queries.append(str(rec["query"]))
            ctx = rec["context"]
            contexts.append(list(ctx) if isinstance(ctx, list) else [str(ctx)])
            answers.append(str(rec["answer"]))

            if "ground_truth" in rec:
                ground_truth.append(str(rec["ground_truth"]))
            else:
                has_gt = False

    if not queries:
        err_console.print(f"No samples found in {dataset}.")
        raise typer.Exit(2)

    from rageval.judge import Judge

    judge = Judge(model=judge_model)

    msg = (
        f"Avaliando {len(queries)} amostra(s) com {metric_list} (juiz: {judge_model})…"
        if language == "pt"
        else f"Evaluating {len(queries)} sample(s) with {metric_list} (judge: {judge_model})…"
    )
    console.print(f"[dim]{msg}[/]")

    result = evaluate(
        queries=queries,
        contexts=contexts,
        answers=answers,
        ground_truth=ground_truth if has_gt else None,
        metrics=metric_list,
        judge=judge,
        language=language,  # type: ignore[arg-type]
    )

    console.print(result)
    console.print()
    label = "Agregado" if language == "pt" else "Aggregate"
    console.print(f"[bold]{label}:[/]")
    for m, mean in result.aggregate.items():
        console.print(f"  {m}: [bold cyan]{mean:.3f}[/]")

    if output is not None:
        with output.open("w", encoding="utf-8") as f:
            json.dump(result.to_dict(), f, ensure_ascii=False, indent=2, default=str)
        saved_msg = f"\n[dim]Resultado salvo em {output}[/]" if language == "pt" else f"\n[dim]Saved to {output}[/]"
        console.print(saved_msg)


@app.command(name="evaluate-agent")
def evaluate_agent_cmd(
    dataset: Annotated[
        Path,
        typer.Option(
            "--dataset",
            "-d",
            help=(
                "JSONL of agent traces. One record per line with "
                "{trace_id, goal, steps: [...], final_answer?, tool_specs?}."
            ),
            exists=True,
            file_okay=True,
            dir_okay=False,
        ),
    ],
    metrics: Annotated[
        str,
        typer.Option(
            "--metrics",
            "-m",
            help="Comma-separated agent metric names. Default: trajectory_quality,goal_completion,cost_efficiency.",
        ),
    ] = "trajectory_quality,goal_completion,cost_efficiency",
    language: Annotated[
        str,
        typer.Option("--language", "-l", help="'pt' (default) or 'en'."),
    ] = "pt",
    judge_model: Annotated[
        str,
        typer.Option(
            "--judge-model",
            help="litellm model id for the judge (default: gpt-4o-mini).",
        ),
    ] = "gpt-4o-mini",
    output: Annotated[
        Path | None,
        typer.Option(
            "--output",
            "-o",
            help="Optional path to write the result as JSON.",
        ),
    ] = None,
) -> None:
    """Evaluate agent trajectories from a JSONL dataset.

    Each record needs at least ``goal`` and ``steps``. Example::

        {"trace_id": "uuid-1", "goal": "Qual o prazo do CDC?",
         "steps": [
            {"step_index": 0, "step_type": "llm", "tokens_in": 142, "tokens_out": 38, "latency_ms": 420},
            {"step_index": 1, "step_type": "tool", "tool_name": "search",
             "step_input": {"q": "CDC arrependimento"},
             "step_output": "Art. 49 do CDC: 7 dias…"}
         ],
         "final_answer": "7 dias do recebimento.",
         "tool_specs": [{"name": "search", "description": "..."}]}
    """
    if language not in ("pt", "en"):
        err_console.print(f"Invalid --language: {language!r}. Use 'pt' or 'en'.")
        raise typer.Exit(2)

    metric_list = [m.strip() for m in metrics.split(",") if m.strip()]
    if not metric_list:
        err_console.print("Provide at least one metric via --metrics.")
        raise typer.Exit(2)

    traces: list[AgentTrace] = []
    with dataset.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, start=1):
            stripped = line.strip()
            if not stripped:
                continue
            try:
                rec = json.loads(stripped)
            except json.JSONDecodeError as e:
                err_console.print(f"Line {line_no}: invalid JSON ({e}).")
                raise typer.Exit(2) from e

            for required in ("trace_id", "goal", "steps"):
                if required not in rec:
                    err_console.print(
                        f"Line {line_no} missing required field {required!r}."
                    )
                    raise typer.Exit(2)

            steps = [AgentStep(**s) for s in rec.get("steps", [])]
            traces.append(
                AgentTrace(
                    trace_id=str(rec["trace_id"]),
                    goal=str(rec["goal"]),
                    steps=steps,
                    final_answer=rec.get("final_answer"),
                    tool_specs=rec.get("tool_specs"),
                    metadata=rec.get("metadata", {}),
                )
            )

    if not traces:
        err_console.print(f"No traces found in {dataset}.")
        raise typer.Exit(2)

    from rageval.judge import Judge

    judge = Judge(model=judge_model)

    msg = (
        f"Avaliando {len(traces)} trajetória(s) com {metric_list} (juiz: {judge_model})…"
        if language == "pt"
        else f"Evaluating {len(traces)} trajectory(ies) with {metric_list} (judge: {judge_model})…"
    )
    console.print(f"[dim]{msg}[/]")

    result = evaluate_agent(
        traces=traces,
        metrics=metric_list,
        judge=judge,
        language=language,  # type: ignore[arg-type]
    )

    label = "Agregado" if language == "pt" else "Aggregate"
    console.print(f"[bold]{label}:[/]")
    for m, mean in result.aggregate.items():
        console.print(f"  {m}: [bold cyan]{mean:.3f}[/]")

    if output is not None:
        with output.open("w", encoding="utf-8") as f:
            json.dump(result.to_dict(), f, ensure_ascii=False, indent=2, default=str)
        saved_msg = (
            f"\n[dim]Resultado salvo em {output}[/]"
            if language == "pt"
            else f"\n[dim]Saved to {output}[/]"
        )
        console.print(saved_msg)


def main() -> None:
    app()


if __name__ == "__main__":
    sys.exit(main())  # type: ignore[func-returns-value]
