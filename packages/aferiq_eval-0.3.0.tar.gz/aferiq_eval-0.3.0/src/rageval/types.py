"""Public Pydantic types for rageval."""

from __future__ import annotations

from io import StringIO
from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel, ConfigDict, Field

if TYPE_CHECKING:
    from rich.console import RenderableType

Language = Literal["pt", "en"]


class EvalSample(BaseModel):
    """A single (query, context, answer) tuple to evaluate."""

    model_config = ConfigDict(frozen=True)

    query: str
    context: list[str]
    answer: str
    ground_truth: str | None = None


class MetricScore(BaseModel):
    """Score for a single metric on a single sample."""

    model_config = ConfigDict(frozen=True)

    metric: str
    score: float = Field(ge=0.0, le=1.0)
    reasoning: str
    language: Language = "pt"
    raw_judge_response: str | None = None
    details: dict[str, Any] = Field(default_factory=dict)
    """Metric-specific structured info (e.g. per-claim breakdown)."""


class SampleResult(BaseModel):
    """All metric scores produced for one sample."""

    sample: EvalSample
    scores: list[MetricScore]

    def score_for(self, metric: str) -> MetricScore | None:
        for s in self.scores:
            if s.metric == metric:
                return s
        return None


class EvalResult(BaseModel):
    """Full evaluation result for a batch of samples."""

    samples: list[SampleResult]
    aggregate: dict[str, float]
    language: Language = "pt"

    def to_dict(self) -> dict[str, Any]:
        """JSON-friendly representation."""
        return self.model_dump()

    def __rich__(self) -> RenderableType:
        from rich.table import Table

        title = "rageval — resultados" if self.language == "pt" else "rageval — results"
        table = Table(title=title, header_style="bold cyan")
        table.add_column("query", overflow="fold", max_width=60)
        for metric in self.aggregate:
            table.add_column(metric, justify="right")
        for sr in self.samples:
            row = [sr.sample.query]
            for metric in self.aggregate:
                ms = sr.score_for(metric)
                row.append(f"{ms.score:.2f}" if ms else "—")
            table.add_row(*row)
        return table

    def __str__(self) -> str:
        from rich.console import Console

        buf = StringIO()
        Console(file=buf, force_terminal=False, no_color=True, width=100).print(self.__rich__())
        return buf.getvalue()
