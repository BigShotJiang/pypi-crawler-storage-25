"""Tests for CitationAccuracy metric."""

from __future__ import annotations

from collections.abc import Callable

from rageval.judge import AsyncJudge, Judge
from rageval.metrics import available_metrics, get_metric
from rageval.metrics.citation_accuracy import CitationAccuracy
from rageval.prompts import load_prompt
from rageval.types import EvalSample


class TestCitationAccuracy:
    def test_registered(self) -> None:
        assert "citation_accuracy" in available_metrics()
        assert isinstance(get_metric("citation_accuracy"), CitationAccuracy)

    def test_well_formed_response_extracts_claims(
        self, fake_judge_factory: Callable[[list[str]], Judge]
    ) -> None:
        judge = fake_judge_factory(
            [
                '{"score": 0.75, "reasoning": "3 of 4 claims have chunks", '
                '"claims": [{"text": "x", "supporting_chunks": [1]}]}'
            ]
        )
        metric = CitationAccuracy()
        sample = EvalSample(query="q", context=["c1", "c2"], answer="a")

        result = metric.score(sample, judge, language="pt")

        assert result.metric == "citation_accuracy"
        assert result.score == 0.75
        assert result.details == {"claims": [{"text": "x", "supporting_chunks": [1]}]}

    def test_pt_prompt_includes_inputs(
        self, fake_judge_factory: Callable[[list[str]], Judge]
    ) -> None:
        judge = fake_judge_factory(['{"score": 1.0, "reasoning": "x"}'])
        metric = CitationAccuracy()
        sample = EvalSample(
            query="my-query-marker-uniq",
            context=["my-ctx-marker-uniq"],
            answer="my-ans-marker-uniq",
        )

        metric.score(sample, judge, language="pt")

        prompt = judge._call_log[0]["prompt"]  # type: ignore[attr-defined]
        assert "my-query-marker-uniq" in prompt
        assert "my-ctx-marker-uniq" in prompt
        assert "my-ans-marker-uniq" in prompt

    def test_pt_prompt_targets_br_exact_match_patterns(self) -> None:
        """PT prompt must call out exact-match BR patterns (Lei nº, CNPJ)."""
        pt = load_prompt("citation_accuracy", "pt")
        assert "Lei nº" in pt
        assert "CNPJ" in pt
        assert "MATCH EXATO" in pt or "match exato" in pt.lower()

    def test_en_prompt_exists(self) -> None:
        en = load_prompt("citation_accuracy", "en")
        assert "QUESTION" in en
        assert "ANSWER" in en
        assert "CONTEXT" in en

    def test_chunks_numbered_starting_at_one(
        self, fake_judge_factory: Callable[[list[str]], Judge]
    ) -> None:
        judge = fake_judge_factory(['{"score": 1.0, "reasoning": "x"}'])
        metric = CitationAccuracy()
        sample = EvalSample(
            query="q",
            context=["chunk-zero-content", "chunk-one-content"],
            answer="a",
        )

        metric.score(sample, judge, language="pt")

        prompt = judge._call_log[0]["prompt"]  # type: ignore[attr-defined]
        assert "[1]" in prompt
        assert "[2]" in prompt
        assert "chunk-zero-content" in prompt
        assert "chunk-one-content" in prompt

    async def test_ascore(self) -> None:
        async def fake_async_fn(prompt: str, model: str, temp: float) -> str:
            return '{"score": 0.5, "reasoning": "x"}'

        judge = AsyncJudge(model="fake", judge_fn=fake_async_fn)
        metric = CitationAccuracy()
        sample = EvalSample(query="q", context=["c"], answer="a")
        result = await metric.ascore(sample, judge, language="pt")
        assert result.score == 0.5
