"""Tests for the LangChain callback handler."""

from __future__ import annotations

from uuid import uuid4

import pytest

# Skip the entire module if langchain-core isn't installed (it's a soft dep).
pytest.importorskip("langchain_core")

from langchain_core.documents import Document
from langchain_core.messages import AIMessage
from langchain_core.outputs import ChatGeneration, Generation, LLMResult

from rageval.integrations.langchain import RAGEvalCallbackHandler
from rageval.integrations.tracing import clear_trace_handlers, register_trace_handler


@pytest.fixture(autouse=True)
def _isolate() -> None:
    clear_trace_handlers()
    yield
    clear_trace_handlers()


def _llm_result(text: str) -> LLMResult:
    return LLMResult(generations=[[Generation(text=text)]])


def _chat_result(text: str) -> LLMResult:
    return LLMResult(
        generations=[[ChatGeneration(message=AIMessage(content=text))]]
    )


def _run_full_flow(
    handler: RAGEvalCallbackHandler,
    *,
    inputs: dict | str,
    docs: list[Document] | None,
    answer_text: str | None,
    output: dict | str | None = None,
    use_chat_model: bool = False,
) -> None:
    """Drive a complete chain lifecycle: start → retrieve → llm → end."""
    run_id = uuid4()
    handler.on_chain_start({}, inputs, run_id=run_id)
    if docs is not None:
        handler.on_retriever_end(docs, run_id=uuid4(), parent_run_id=run_id)
    if answer_text is not None:
        if use_chat_model:
            handler.on_chat_model_end(
                _chat_result(answer_text), run_id=uuid4(), parent_run_id=run_id
            )
        else:
            handler.on_llm_end(
                _llm_result(answer_text), run_id=uuid4(), parent_run_id=run_id
            )
    handler.on_chain_end(output if output is not None else {"output": answer_text or ""}, run_id=run_id)


class TestLangChainHandler:
    def test_full_flow_emits_one_trace(self) -> None:
        handler = RAGEvalCallbackHandler()

        _run_full_flow(
            handler,
            inputs={"query": "qual o prazo do CDC?"},
            docs=[
                Document(page_content="Art. 49: 7 dias."),
                Document(page_content="Art. 50: complemento."),
            ],
            answer_text="7 dias do recebimento.",
        )

        assert len(handler.traces) == 1
        sample = handler.traces[0]
        assert sample.query == "qual o prazo do CDC?"
        assert sample.context == ["Art. 49: 7 dias.", "Art. 50: complemento."]
        assert sample.answer == "7 dias do recebimento."

    def test_question_input_key(self) -> None:
        handler = RAGEvalCallbackHandler()
        _run_full_flow(
            handler,
            inputs={"question": "outro nome de input"},
            docs=[Document(page_content="x")],
            answer_text="a",
        )
        assert handler.traces[0].query == "outro nome de input"

    def test_input_key(self) -> None:
        handler = RAGEvalCallbackHandler()
        _run_full_flow(
            handler,
            inputs={"input": "yet another"},
            docs=[Document(page_content="x")],
            answer_text="a",
        )
        assert handler.traces[0].query == "yet another"

    def test_no_recognized_query_key_no_trace(self) -> None:
        handler = RAGEvalCallbackHandler()
        _run_full_flow(
            handler,
            inputs={"unknown_key": "value"},
            docs=[Document(page_content="x")],
            answer_text="a",
        )
        assert handler.traces == []

    def test_multiple_chain_invocations(self) -> None:
        handler = RAGEvalCallbackHandler()

        _run_full_flow(
            handler,
            inputs={"query": "q1"},
            docs=[Document(page_content="c1")],
            answer_text="a1",
        )
        _run_full_flow(
            handler,
            inputs={"query": "q2"},
            docs=[Document(page_content="c2")],
            answer_text="a2",
        )

        assert len(handler.traces) == 2
        assert handler.traces[0].query == "q1"
        assert handler.traces[1].query == "q2"

    def test_last_trace(self) -> None:
        handler = RAGEvalCallbackHandler()
        assert handler.last_trace is None

        _run_full_flow(
            handler,
            inputs={"query": "q1"},
            docs=[Document(page_content="c1")],
            answer_text="a1",
        )

        assert handler.last_trace is not None
        assert handler.last_trace.query == "q1"

    def test_clear_resets_state(self) -> None:
        handler = RAGEvalCallbackHandler()
        _run_full_flow(
            handler,
            inputs={"query": "q"},
            docs=[Document(page_content="c")],
            answer_text="a",
        )

        handler.clear()

        assert handler.traces == []
        assert handler.last_trace is None

    def test_emits_to_global_handlers(self) -> None:
        captured: list = []
        register_trace_handler(captured.append)

        handler = RAGEvalCallbackHandler()
        _run_full_flow(
            handler,
            inputs={"query": "q"},
            docs=[Document(page_content="c")],
            answer_text="a",
        )

        assert len(captured) == 1
        assert captured[0].query == "q"


class TestLCELRobustness:
    """Cover modern LCEL patterns that the original handler missed."""

    def test_chat_model_end_captures_answer(self) -> None:
        """ChatOpenAI / ChatAnthropic fire on_chat_model_end (not on_llm_end)."""
        handler = RAGEvalCallbackHandler()
        _run_full_flow(
            handler,
            inputs={"question": "q"},
            docs=[Document(page_content="ctx")],
            answer_text="a chat",
            use_chat_model=True,
        )
        assert len(handler.traces) == 1
        assert handler.traces[0].answer == "a chat"

    def test_lcel_nested_retriever_no_retriever_end(self) -> None:
        """RunnableParallel may not propagate on_retriever_end. Emit anyway,
        with empty context, using answer captured from on_llm_end."""
        handler = RAGEvalCallbackHandler()
        _run_full_flow(
            handler,
            inputs={"question": "lcel q"},
            docs=None,  # <-- retriever event never fires
            answer_text="lcel answer",
        )
        assert len(handler.traces) == 1
        sample = handler.traces[0]
        assert sample.query == "lcel q"
        assert sample.context == []
        assert sample.answer == "lcel answer"

    def test_fallback_extracts_answer_from_output_string(self) -> None:
        """If no LLM event fires (custom LCEL with bypassed LLM hooks), fall
        back to extracting the answer from the chain's outputs."""
        handler = RAGEvalCallbackHandler()
        run_id = uuid4()
        handler.on_chain_start({}, {"query": "q"}, run_id=run_id)
        handler.on_retriever_end([Document(page_content="ctx")], run_id=uuid4(), parent_run_id=run_id)
        # No on_llm_end / on_chat_model_end fires.
        handler.on_chain_end("plain string output", run_id=run_id)

        assert len(handler.traces) == 1
        assert handler.traces[0].answer == "plain string output"

    def test_fallback_extracts_answer_from_output_dict(self) -> None:
        handler = RAGEvalCallbackHandler()
        run_id = uuid4()
        handler.on_chain_start({}, {"query": "q"}, run_id=run_id)
        handler.on_retriever_end([Document(page_content="ctx")], run_id=uuid4(), parent_run_id=run_id)
        handler.on_chain_end({"answer": "from dict"}, run_id=run_id)

        assert handler.traces[0].answer == "from dict"

    def test_no_emit_without_query(self) -> None:
        """If the outermost chain inputs have no recognized query key, skip."""
        handler = RAGEvalCallbackHandler()
        run_id = uuid4()
        handler.on_chain_start({}, {"random": "x"}, run_id=run_id)
        handler.on_chain_end({"output": "a"}, run_id=run_id)
        assert handler.traces == []

    def test_nested_chain_starts_ignored(self) -> None:
        """Inner chain_start events (with parent_run_id set) must not reset
        the captured query. Only the outermost run is tracked."""
        handler = RAGEvalCallbackHandler()
        outer_id = uuid4()
        inner_id = uuid4()
        handler.on_chain_start({}, {"question": "outer"}, run_id=outer_id)
        # Inner runnable inside RunnableParallel — has parent_run_id
        handler.on_chain_start(
            {}, {"question": "should_be_ignored"},
            run_id=inner_id, parent_run_id=outer_id,
        )
        handler.on_retriever_end([Document(page_content="ctx")], run_id=uuid4(), parent_run_id=outer_id)
        handler.on_llm_end(_llm_result("a"), run_id=uuid4(), parent_run_id=outer_id)
        handler.on_chain_end({"output": "a"}, run_id=outer_id)

        assert handler.traces[0].query == "outer"

    def test_chain_error_resets_state_for_next_run(self) -> None:
        """An error mid-run must not poison the next run's capture state."""
        handler = RAGEvalCallbackHandler()
        run_id_1 = uuid4()
        handler.on_chain_start({}, {"query": "q1"}, run_id=run_id_1)
        handler.on_chain_error(RuntimeError("boom"), run_id=run_id_1)
        # Now do a clean run — should capture normally.
        _run_full_flow(
            handler,
            inputs={"query": "q2"},
            docs=[Document(page_content="ctx")],
            answer_text="a2",
        )
        assert len(handler.traces) == 1
        assert handler.traces[0].query == "q2"

    def test_extracts_query_from_messages_list(self) -> None:
        """LCEL chains that take a ``messages`` list (chat-style) — pull from
        the last message's content."""
        handler = RAGEvalCallbackHandler()
        run_id = uuid4()
        handler.on_chain_start(
            {},
            {"messages": [AIMessage(content="ignored"), AIMessage(content="last user msg")]},
            run_id=run_id,
        )
        handler.on_retriever_end([Document(page_content="ctx")], run_id=uuid4(), parent_run_id=run_id)
        handler.on_llm_end(_llm_result("a"), run_id=uuid4(), parent_run_id=run_id)
        handler.on_chain_end({"output": "a"}, run_id=run_id)

        assert handler.traces[0].query == "last user msg"
