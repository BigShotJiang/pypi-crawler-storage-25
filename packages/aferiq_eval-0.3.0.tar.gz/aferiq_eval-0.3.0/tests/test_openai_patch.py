"""Tests for the OpenAI SDK monkey patch.

We can't reach OpenAI's actual API in unit tests, so we mock the create
function and verify the patch wraps + restores it correctly, captures
``response.usage`` and latency, and stays a no-op when no trajectory is active.
"""

from __future__ import annotations

import pytest

from rageval.integrations._context import (
    end_trajectory,
    record_step,
    start_trajectory,
)
from rageval.integrations.tracing import clear_trace_handlers


@pytest.fixture(autouse=True)
def _clean_state() -> None:
    end_trajectory()
    clear_trace_handlers()
    yield
    end_trajectory()
    clear_trace_handlers()


class TestPatchExtractUsage:
    """Test the usage-extraction helper directly without monkey-patching the
    actual OpenAI SDK (which may or may not be installed)."""

    def test_extract_from_pydantic_shape(self) -> None:
        from rageval.integrations.openai_patch import _extract_usage

        class _Usage:
            prompt_tokens = 142
            completion_tokens = 38

        class _Resp:
            usage = _Usage()

        ti, to = _extract_usage(_Resp())
        assert ti == 142
        assert to == 38

    def test_extract_from_dict_shape(self) -> None:
        from rageval.integrations.openai_patch import _extract_usage

        resp = {"usage": {"prompt_tokens": 50, "completion_tokens": 10}}
        ti, to = _extract_usage(resp)
        assert ti == 50
        assert to == 10

    def test_extract_handles_missing_usage(self) -> None:
        from rageval.integrations.openai_patch import _extract_usage

        class _NoUsage:
            pass

        ti, to = _extract_usage(_NoUsage())
        assert ti is None
        assert to is None

    def test_extract_handles_partial_usage(self) -> None:
        from rageval.integrations.openai_patch import _extract_usage

        class _Usage:
            prompt_tokens = 100
            # completion_tokens missing
            completion_tokens = None

        class _Resp:
            usage = _Usage()

        ti, to = _extract_usage(_Resp())
        assert ti == 100
        assert to is None


class TestPatchSummarizers:
    def test_summarize_messages_picks_last_user(self) -> None:
        from rageval.integrations.openai_patch import _summarize_messages

        kwargs = {
            "model": "gpt-4o-mini",
            "messages": [
                {"role": "system", "content": "you are an assistant"},
                {"role": "user", "content": "first"},
                {"role": "assistant", "content": "ok"},
                {"role": "user", "content": "last user message here"},
            ],
        }
        summary = _summarize_messages(kwargs)
        assert summary is not None
        assert summary["model"] == "gpt-4o-mini"
        assert summary["n_messages"] == 4
        assert summary["last_user_preview"] == "last user message here"

    def test_summarize_messages_truncates_long_content(self) -> None:
        from rageval.integrations.openai_patch import _summarize_messages

        long_msg = "x" * 500
        summary = _summarize_messages({"model": "m", "messages": [{"role": "user", "content": long_msg}]})
        assert summary is not None
        assert len(summary["last_user_preview"]) == 200

    def test_summarize_response_extracts_finish_reason(self) -> None:
        from rageval.integrations.openai_patch import _summarize_response

        class _Msg:
            content = "the answer"

        class _Choice:
            message = _Msg()
            finish_reason = "stop"

        class _Resp:
            choices = [_Choice()]

        summary = _summarize_response(_Resp())
        assert summary is not None
        assert summary["finish_reason"] == "stop"
        assert summary["preview"] == "the answer"


class TestNoActiveTrajectoryNoOp:
    """Patch should be a no-op when no trajectory is in flight — record_step
    returns None and nothing is captured anywhere."""

    def test_record_step_returns_none(self) -> None:
        # No trajectory active
        result = record_step(step_type="llm", tokens_in=100, tokens_out=20, latency_ms=300)
        assert result is None


class TestRecordStepInsideTrajectory:
    def test_step_recorded(self) -> None:
        start_trajectory(goal="test")
        s = record_step(step_type="llm", tokens_in=42, tokens_out=8, latency_ms=120)
        assert s is not None
        assert s.tokens_in == 42
        assert s.step_type == "llm"

        trace = end_trajectory()
        assert trace is not None
        assert len(trace.steps) == 1
        assert trace.total_tokens() == 50


class TestEmitStandalone:
    """`patch_openai(emit_standalone=True)` makes bare chat.completions.create
    calls outside @aferiq.trace produce standalone EvalSamples — used by
    aferiq.start() to deliver the "1-line auto-capture" promise.
    """

    def test_emits_sample_from_chat_kwargs_and_response(self) -> None:
        from rageval.integrations.openai_patch import _emit_standalone_chat_trace
        from rageval.integrations.tracing import register_trace_handler
        from rageval.types import EvalSample

        captured: list[EvalSample] = []
        register_trace_handler(captured.append)

        # Fake OpenAI response — Pydantic-ish shape
        class FakeMsg:
            content = "Brasília."
        class FakeChoice:
            message = FakeMsg()
        class FakeResponse:
            choices = [FakeChoice()]

        _emit_standalone_chat_trace(
            kwargs={
                "model": "gpt-4o-mini",
                "messages": [
                    {"role": "system", "content": "Você é assistente"},
                    {"role": "user", "content": "Qual a capital do Brasil?"},
                ],
            },
            response=FakeResponse(),
        )

        assert len(captured) == 1
        assert captured[0].query == "Qual a capital do Brasil?"
        assert captured[0].context == []
        assert captured[0].answer == "Brasília."

    def test_skips_when_no_user_message(self) -> None:
        from rageval.integrations.openai_patch import _emit_standalone_chat_trace
        from rageval.integrations.tracing import register_trace_handler
        from rageval.types import EvalSample

        captured: list[EvalSample] = []
        register_trace_handler(captured.append)

        class FakeMsg:
            content = "..."
        class FakeChoice:
            message = FakeMsg()
        class FakeResponse:
            choices = [FakeChoice()]

        _emit_standalone_chat_trace(
            kwargs={"messages": [{"role": "system", "content": "sys only"}]},
            response=FakeResponse(),
        )
        assert len(captured) == 0

    def test_skips_when_tool_calls_only(self) -> None:
        """When response has no text content (only tool_calls), skip — those
        happen in agent loops where @aferiq.trace on the entry captures the
        turn properly."""
        from rageval.integrations.openai_patch import _emit_standalone_chat_trace
        from rageval.integrations.tracing import register_trace_handler
        from rageval.types import EvalSample

        captured: list[EvalSample] = []
        register_trace_handler(captured.append)

        class FakeMsg:
            content = None  # tool_calls only, no text
        class FakeChoice:
            message = FakeMsg()
        class FakeResponse:
            choices = [FakeChoice()]

        _emit_standalone_chat_trace(
            kwargs={
                "messages": [{"role": "user", "content": "search"}],
            },
            response=FakeResponse(),
        )
        assert len(captured) == 0

    def test_never_raises_on_malformed_input(self) -> None:
        """Handler must never break user code, even with garbage input."""
        from rageval.integrations.openai_patch import _emit_standalone_chat_trace

        # Should not raise
        _emit_standalone_chat_trace(kwargs={}, response=None)
        _emit_standalone_chat_trace(kwargs={"messages": None}, response=None)
        _emit_standalone_chat_trace(
            kwargs={"messages": [{"role": "user", "content": "x"}]},
            response="not a real response",
        )
