"""Tests for AgentTrace types + ContextVar trajectory state."""

from __future__ import annotations

import pytest

from rageval import AgentStep, AgentTrace
from rageval.integrations._context import (
    current_trace_id,
    end_trajectory,
    has_active_trajectory,
    record_step,
    start_trajectory,
)
from rageval.integrations.tracing import (
    _emit_trace,
    clear_trace_handlers,
    register_trace_handler,
)


@pytest.fixture(autouse=True)
def _clean_state() -> None:
    """Reset trajectory state and handler registry around each test."""
    end_trajectory()  # idempotent — clears any leftover ContextVar
    clear_trace_handlers()
    yield
    end_trajectory()
    clear_trace_handlers()


class TestAgentStep:
    def test_minimal_step(self) -> None:
        s = AgentStep(step_index=0, step_type="llm")
        assert s.step_index == 0
        assert s.step_type == "llm"
        assert s.tool_name is None
        assert s.tokens_in is None

    def test_full_step(self) -> None:
        s = AgentStep(
            step_index=1,
            step_type="tool",
            tool_name="search",
            step_input={"q": "x"},
            step_output="result",
            tokens_in=120,
            tokens_out=30,
            latency_ms=420,
        )
        assert s.tool_name == "search"
        assert s.step_input == {"q": "x"}
        assert s.tokens_in == 120

    def test_frozen(self) -> None:
        from pydantic import ValidationError

        s = AgentStep(step_index=0, step_type="llm")
        with pytest.raises((ValidationError, AttributeError)):
            s.tool_name = "x"  # type: ignore[misc]


class TestAgentTrace:
    def test_aggregates(self) -> None:
        t = AgentTrace(
            trace_id="t1",
            goal="g",
            steps=[
                AgentStep(step_index=0, step_type="llm", tokens_in=100, tokens_out=20, latency_ms=300),
                AgentStep(step_index=1, step_type="tool", tool_name="search", latency_ms=80),
                AgentStep(step_index=2, step_type="llm", tokens_in=200, tokens_out=40, latency_ms=350),
            ],
        )
        assert t.total_tokens() == 100 + 20 + 200 + 40
        assert t.total_latency_ms() == 300 + 80 + 350
        assert t.n_tool_calls() == 1
        assert t.n_llm_calls() == 2

    def test_empty_steps(self) -> None:
        t = AgentTrace(trace_id="t1", goal="g", steps=[])
        assert t.total_tokens() == 0
        assert t.total_latency_ms() == 0
        assert t.n_tool_calls() == 0


class TestTrajectoryContext:
    def test_no_active_by_default(self) -> None:
        assert not has_active_trajectory()
        assert current_trace_id() is None

    def test_record_without_start_is_noop(self) -> None:
        result = record_step(step_type="llm")
        assert result is None

    def test_full_lifecycle(self) -> None:
        tid = start_trajectory(goal="my goal")
        assert has_active_trajectory()
        assert current_trace_id() == tid

        s1 = record_step(step_type="llm", tokens_in=10, tokens_out=2)
        s2 = record_step(step_type="tool", tool_name="search")

        assert s1 is not None and s1.step_index == 0
        assert s2 is not None and s2.step_index == 1

        trace = end_trajectory(final_answer="done")
        assert trace is not None
        assert trace.trace_id == tid
        assert trace.goal == "my goal"
        assert trace.final_answer == "done"
        assert len(trace.steps) == 2
        assert not has_active_trajectory()

    def test_end_without_start_is_noop(self) -> None:
        assert end_trajectory() is None

    def test_replacing_trajectory(self) -> None:
        tid1 = start_trajectory(goal="first")
        record_step(step_type="llm")
        # Starting a new trajectory replaces the active one
        tid2 = start_trajectory(goal="second")
        assert tid2 != tid1
        record_step(step_type="tool", tool_name="t")
        trace = end_trajectory()
        assert trace is not None
        assert trace.goal == "second"
        assert len(trace.steps) == 1

    def test_tool_specs_preserved(self) -> None:
        tools = [{"name": "x"}]
        start_trajectory(goal="g", tool_specs=tools)
        trace = end_trajectory()
        assert trace is not None
        assert trace.tool_specs == tools


class TestEmitTrace:
    def test_handler_receives_agent_trace(self) -> None:
        received: list[AgentTrace] = []
        register_trace_handler(received.append)

        start_trajectory(goal="g")
        record_step(step_type="llm")
        trace = end_trajectory(final_answer="a")
        assert trace is not None
        _emit_trace(trace)

        assert len(received) == 1
        assert received[0].goal == "g"
        assert received[0].final_answer == "a"

    def test_handler_exception_is_swallowed(self) -> None:
        def bad_handler(_: object) -> None:
            raise RuntimeError("bad")

        register_trace_handler(bad_handler)
        # Must not raise:
        _emit_trace(AgentTrace(trace_id="t", goal="g", steps=[]))
