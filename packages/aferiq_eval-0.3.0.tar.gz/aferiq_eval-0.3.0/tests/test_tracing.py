"""Tests for the @trace decorator and handler registry."""

from __future__ import annotations

import logging

import pytest

from rageval import EvalSample
from rageval.integrations.tracing import (
    clear_trace_handlers,
    register_trace_handler,
    trace,
)


@pytest.fixture(autouse=True)
def _isolate_handlers() -> None:
    clear_trace_handlers()
    yield
    clear_trace_handlers()


class TestTraceSync:
    def test_no_handlers_means_pass_through(self) -> None:
        @trace
        def my_rag(query: str, context: list[str]) -> str:
            return "answer"

        assert my_rag("q", ["c"]) == "answer"

    def test_handler_receives_sample(self) -> None:
        captured: list[EvalSample] = []
        register_trace_handler(captured.append)

        @trace
        def my_rag(query: str, context: list[str]) -> str:
            return "answer-text"

        my_rag("hello?", ["chunk-a", "chunk-b"])

        assert len(captured) == 1
        assert captured[0].query == "hello?"
        assert captured[0].context == ["chunk-a", "chunk-b"]
        assert captured[0].answer == "answer-text"

    def test_multiple_handlers_all_called(self) -> None:
        h1: list[EvalSample] = []
        h2: list[EvalSample] = []
        register_trace_handler(h1.append)
        register_trace_handler(h2.append)

        @trace
        def my_rag(query: str, context: list[str]) -> str:
            return "x"

        my_rag("q", ["c"])

        assert len(h1) == 1
        assert len(h2) == 1

    def test_handler_exception_does_not_break_function(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        def bad_handler(s: EvalSample) -> None:
            raise RuntimeError("boom")

        captured: list[EvalSample] = []
        register_trace_handler(bad_handler)
        register_trace_handler(captured.append)

        @trace
        def my_rag(query: str, context: list[str]) -> str:
            return "x"

        with caplog.at_level(logging.WARNING):
            assert my_rag("q", ["c"]) == "x"

        assert len(captured) == 1
        assert "boom" in caplog.text or "raised" in caplog.text

    def test_capture_override(self) -> None:
        captured: list[EvalSample] = []
        register_trace_handler(captured.append)

        @trace(capture={"query": "user_q", "context": "retrieved"})
        def my_rag(user_q: str, retrieved: list[str]) -> str:
            return "a"

        my_rag(user_q="hello", retrieved=["c1", "c2"])

        assert captured[0].query == "hello"
        assert captured[0].context == ["c1", "c2"]

    def test_alias_question_for_query(self) -> None:
        captured: list[EvalSample] = []
        register_trace_handler(captured.append)

        @trace
        def my_rag(question: str, chunks: list[str]) -> str:
            return "a"

        my_rag(question="q", chunks=["c"])

        assert captured[0].query == "q"
        assert captured[0].context == ["c"]

    def test_alias_prompt_and_documents(self) -> None:
        captured: list[EvalSample] = []
        register_trace_handler(captured.append)

        @trace
        def my_rag(prompt: str, documents: list[str]) -> str:
            return "a"

        my_rag("p", ["d"])

        assert captured[0].query == "p"
        assert captured[0].context == ["d"]

    def test_unrecognized_context_param_emits_with_empty_context(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Tool-calling agents often have no explicit `context` param —
        context is built internally from tool results. The decorator now
        emits the trace with an empty context list (instead of bailing)
        so the user still gets observability on the outer turn."""
        captured: list[EvalSample] = []
        register_trace_handler(captured.append)

        @trace
        def my_rag(input: str, retriever: object) -> str:
            return "a"

        with caplog.at_level(logging.DEBUG, logger="rageval.integrations.tracing"):
            my_rag("q", retriever=object())

        assert len(captured) == 1
        assert captured[0].query == "q"
        assert captured[0].context == []
        assert captured[0].answer == "a"

    def test_string_context_coerced_to_list(self) -> None:
        captured: list[EvalSample] = []
        register_trace_handler(captured.append)

        @trace
        def my_rag(query: str, context: str) -> str:
            return "a"

        my_rag("q", "single chunk")

        assert captured[0].context == ["single chunk"]

    def test_non_string_answer_coerced(self) -> None:
        captured: list[EvalSample] = []
        register_trace_handler(captured.append)

        @trace
        def my_rag(query: str, context: list[str]) -> dict[str, str]:
            return {"text": "weird"}

        my_rag("q", ["c"])

        assert isinstance(captured[0].answer, str)
        assert "weird" in captured[0].answer


class TestTraceAsync:
    async def test_async_function_emits_after_await(self) -> None:
        captured: list[EvalSample] = []
        register_trace_handler(captured.append)

        @trace
        async def my_async_rag(query: str, context: list[str]) -> str:
            return "async-answer"

        result = await my_async_rag("q", ["c"])

        assert result == "async-answer"
        assert len(captured) == 1
        assert captured[0].answer == "async-answer"

    async def test_async_with_capture_override(self) -> None:
        captured: list[EvalSample] = []
        register_trace_handler(captured.append)

        @trace(capture={"query": "user_q", "context": "ctx"})
        async def my_rag(user_q: str, ctx: list[str]) -> str:
            return "a"

        await my_rag(user_q="x", ctx=["y"])

        assert captured[0].query == "x"
        assert captured[0].context == ["y"]


class TestRegistry:
    def test_clear_handlers_removes_all(self) -> None:
        captured: list[EvalSample] = []
        register_trace_handler(captured.append)
        clear_trace_handlers()

        @trace
        def f(query: str, context: list[str]) -> str:
            return "x"

        f("q", ["c"])

        assert captured == []

    def test_handlers_called_in_registration_order(self) -> None:
        order: list[str] = []
        register_trace_handler(lambda s: order.append("first"))
        register_trace_handler(lambda s: order.append("second"))

        @trace
        def f(query: str, context: list[str]) -> str:
            return "x"

        f("q", ["c"])

        assert order == ["first", "second"]
