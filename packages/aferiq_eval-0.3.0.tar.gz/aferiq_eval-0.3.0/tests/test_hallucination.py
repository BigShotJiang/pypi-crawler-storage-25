"""Tests for Hallucination metric."""

from __future__ import annotations

from collections.abc import Callable

from rageval.judge import AsyncJudge, Judge
from rageval.metrics import available_metrics, get_metric
from rageval.metrics.hallucination import Hallucination
from rageval.prompts import load_prompt
from rageval.types import EvalSample


class TestHallucination:
    def test_registered(self) -> None:
        assert "hallucination" in available_metrics()
        assert isinstance(get_metric("hallucination"), Hallucination)

    def test_well_formed_response_extracts_claims(
        self, fake_judge_factory: Callable[[list[str]], Judge]
    ) -> None:
        response = (
            '{"score": 0.5, "reasoning": "1/2 supported", '
            '"claims": ['
            '{"text": "claim-1", "supported": true, "category": null}, '
            '{"text": "claim-2", "supported": false, "category": "LEI"}'
            "]}"
        )
        judge = fake_judge_factory([response])
        metric = Hallucination()
        sample = EvalSample(query="q", context=["c"], answer="a")

        result = metric.score(sample, judge, language="pt")

        assert result.metric == "hallucination"
        assert result.score == 0.5
        assert len(result.details["claims"]) == 2
        assert result.details["claims"][1]["category"] == "LEI"

    def test_pt_prompt_includes_all_br_categories(self) -> None:
        """PT prompt must enumerate all Brazilian hallucination categories."""
        pt = load_prompt("hallucination", "pt")
        required_categories = [
            "LEI",
            "CNPJ_CPF_RG",
            "ENTIDADE_BR",
            "PRAZO_VALOR",
            "POLITICA",
            "GEOGRAFIA_BR",
        ]
        for cat in required_categories:
            assert cat in pt, f"Missing category {cat!r} in PT hallucination prompt"

    def test_pt_prompt_mentions_specific_br_entities(self) -> None:
        """PT prompt should namedrop the specific BR entities/programs the moat targets."""
        pt = load_prompt("hallucination", "pt")
        for entity in ["Receita Federal", "INSS", "SUS", "BACEN", "Pix"]:
            assert entity in pt, f"PT prompt should mention {entity!r}"
        assert "Bolsa Família" in pt or "Auxílio Brasil" in pt or "MEI" in pt

    def test_en_prompt_categories(self) -> None:
        en = load_prompt("hallucination", "en")
        # Categories standardised on PT codes for consistency across EN/PT
        # judges (the codes are stable identifiers, not user-facing strings).
        for keyword in [
            "LEI",
            "CNPJ_CPF_RG",
            "ENTIDADE_BR",
            "PRAZO_VALOR",
            "POLITICA",
            "GEOGRAFIA_BR",
        ]:
            assert keyword in en

    def test_malformed_response_scores_zero_with_empty_details(
        self, fake_judge_factory: Callable[[list[str]], Judge]
    ) -> None:
        judge = fake_judge_factory(["not json at all"])
        metric = Hallucination()
        sample = EvalSample(query="q", context=["c"], answer="a")

        result = metric.score(sample, judge, language="pt")

        assert result.score == 0.0
        assert result.details == {}

    def test_missing_claims_field_returns_empty_list(
        self, fake_judge_factory: Callable[[list[str]], Judge]
    ) -> None:
        judge = fake_judge_factory(['{"score": 0.8, "reasoning": "ok"}'])
        metric = Hallucination()
        sample = EvalSample(query="q", context=["c"], answer="a")

        result = metric.score(sample, judge, language="pt")

        assert result.score == 0.8
        assert result.details == {"claims": []}

    async def test_ascore(self) -> None:
        async def fake_async_fn(prompt: str, model: str, temp: float) -> str:
            return '{"score": 0.9, "reasoning": "x", "claims": []}'

        judge = AsyncJudge(model="fake", judge_fn=fake_async_fn)
        metric = Hallucination()
        sample = EvalSample(query="q", context=["c"], answer="a")
        result = await metric.ascore(sample, judge, language="pt")
        assert result.score == 0.9
