"""Tests for AferiqAgentCallbackHandler — works for LangChain AgentExecutor and
LangGraph callback events.

We don't actually run an Agent — we drive the handler with synthetic events
that simulate what LangChain core would emit.
"""

from __future__ import annotations

import pytest

# Skip the entire module if langchain-core isn't installed (it's a soft dep).
pytest.importorskip("langchain_core")

from rageval import AgentTrace
from rageval.integrations._context import end_trajectory
from rageval.integrations.agent_callback import AferiqAgentCallbackHandler
from rageval.integrations.tracing import clear_trace_handlers, register_trace_handler


class _FakeAction:
    def __init__(self, tool: str, tool_input: dict) -> None:
        self.tool = tool
        self.tool_input = tool_input


@pytest.fixture(autouse=True)
def _clean_state() -> None:
    end_trajectory()
    clear_trace_handlers()
    yield
    end_trajectory()
    clear_trace_handlers()


def test_handler_captures_chain_lifecycle() -> None:
    received: list[AgentTrace] = []
    register_trace_handler(received.append)

    handler = AferiqAgentCallbackHandler(goal="Quanto é 2+2?")

    handler.on_chain_start(
        serialized={"name": "AgentExecutor"},
        inputs={"input": "Quanto é 2+2?"},
    )
    handler.on_agent_action(_FakeAction("calculator", {"expression": "2+2"}))
    handler.on_tool_end("4")
    handler.on_chain_end(outputs={"output": "4"})

    assert len(received) == 1
    trace = received[0]
    assert trace.goal == "Quanto é 2+2?"
    assert trace.final_answer == "4"
    assert len(trace.steps) == 2
    assert trace.steps[0].step_type == "agent_action"
    assert trace.steps[0].tool_name == "calculator"
    assert trace.steps[1].step_type == "tool"
    assert trace.steps[1].step_output == "4"


def test_handler_extracts_goal_from_inputs() -> None:
    received: list[AgentTrace] = []
    register_trace_handler(received.append)

    handler = AferiqAgentCallbackHandler()  # no explicit goal

    handler.on_chain_start(
        serialized={"name": "AgentExecutor"},
        inputs={"question": "Whats up?"},
    )
    handler.on_chain_end(outputs={"answer": "all good"})

    assert len(received) == 1
    assert received[0].goal == "Whats up?"
    assert received[0].final_answer == "all good"


def test_handler_ignores_nested_chain_events() -> None:
    received: list[AgentTrace] = []
    register_trace_handler(received.append)

    handler = AferiqAgentCallbackHandler(goal="g")

    handler.on_chain_start({"name": "outer"}, {"input": "g"})
    # Nested chain start — should NOT begin a new trajectory
    handler.on_chain_start({"name": "inner"}, {"input": "ignored"})
    handler.on_agent_action(_FakeAction("t", {}))
    handler.on_chain_end({"output": "inner-out"})  # nested end — keep trajectory
    handler.on_chain_end({"output": "final"})

    assert len(received) == 1
    assert received[0].goal == "g"
    assert received[0].final_answer == "final"


def test_handler_on_chain_error_still_emits() -> None:
    received: list[AgentTrace] = []
    register_trace_handler(received.append)

    handler = AferiqAgentCallbackHandler(goal="g")
    handler.on_chain_start({"name": "outer"}, {"input": "g"})
    handler.on_agent_action(_FakeAction("tool_x", {}))
    handler.on_chain_error(RuntimeError("boom"))

    assert len(received) == 1
    assert received[0].final_answer is None  # no successful answer
    assert len(received[0].steps) == 1


def test_on_tool_start_captures_name_for_on_tool_end() -> None:
    """F7 regression: tool_name should make it onto AgentStep when the user
    drives on_tool_start/end manually (LangGraph-style) instead of going
    through on_agent_action (LangChain AgentExecutor-style)."""
    from uuid import uuid4

    received: list[AgentTrace] = []
    register_trace_handler(received.append)

    handler = AferiqAgentCallbackHandler(goal="g")
    handler.on_chain_start({"name": "outer"}, {"input": "g"})

    run_id_1 = uuid4()
    handler.on_tool_start(
        serialized={"name": "calculator"},
        input_str="2+2",
        run_id=run_id_1,
    )
    handler.on_tool_end(output="4", run_id=run_id_1)

    # Also accept explicit name= kwarg (when caller knows it directly).
    run_id_2 = uuid4()
    handler.on_tool_start(
        serialized={},
        input_str="hello",
        run_id=run_id_2,
        name="formatter",
    )
    handler.on_tool_end(output="Hello!", run_id=run_id_2)

    handler.on_chain_end({"output": "done"})

    assert len(received) == 1
    steps = received[0].steps
    assert len(steps) == 2
    assert steps[0].step_type == "tool"
    assert steps[0].tool_name == "calculator"
    assert steps[0].step_output == "4"
    assert steps[1].tool_name == "formatter"


def test_end_trajectory_accepts_goal_override() -> None:
    """F6 regression: callers driving the trajectory manually can override the
    goal at end_trajectory time (e.g. when the goal was unknown at start)."""
    from rageval.integrations._context import (
        end_trajectory,
        record_step,
        start_trajectory,
    )

    start_trajectory(goal="initial placeholder")
    record_step(step_type="llm")
    trace = end_trajectory(final_answer="ok", goal="real goal learned later")
    assert trace is not None
    assert trace.goal == "real goal learned later"
    assert trace.final_answer == "ok"

    # Without override, the start_trajectory goal stands.
    start_trajectory(goal="my-goal")
    t2 = end_trajectory(final_answer="x")
    assert t2 is not None
    assert t2.goal == "my-goal"


def test_pydantic_input_serialised() -> None:
    received: list[AgentTrace] = []
    register_trace_handler(received.append)

    class _PydInput:
        def model_dump(self) -> dict:
            return {"field": "value"}

    handler = AferiqAgentCallbackHandler(goal="g")
    handler.on_chain_start({"name": "outer"}, {"input": "g"})
    handler.on_agent_action(_FakeAction("t", _PydInput()))  # type: ignore[arg-type]
    handler.on_chain_end({"output": "done"})

    step_in = received[0].steps[0].step_input
    assert step_in == {"field": "value"}
