"""Tests for the cloud client (sync + async)."""

from __future__ import annotations

import json

import httpx
import pytest

from rageval.client import AsyncCloudClient, CloudClient
from rageval.types import EvalSample


def _mock_transport(
    expected_path: str,
    response_status: int = 200,
    response_body: dict[str, object] | None = None,
    capture: list[httpx.Request] | None = None,
) -> httpx.MockTransport:
    def handler(request: httpx.Request) -> httpx.Response:
        if capture is not None:
            capture.append(request)
        assert request.url.path == expected_path
        body = response_body if response_body is not None else {"accepted": 1}
        return httpx.Response(response_status, json=body)

    return httpx.MockTransport(handler)


class TestCloudClient:
    def test_requires_api_key(self) -> None:
        with pytest.raises(ValueError, match="api_key"):
            CloudClient(api_key="")

    def test_send_posts_to_traces_endpoint(self) -> None:
        captured: list[httpx.Request] = []
        transport = _mock_transport("/v1/traces", capture=captured)

        client = CloudClient(api_key="rg_pk_live_test", base_url="https://api.test")
        client._client = httpx.Client(transport=transport)

        client.send(
            EvalSample(query="qual o prazo?", context=["Art. 49: 7 dias."], answer="7 dias.")
        )

        assert len(captured) == 1
        request = captured[0]
        assert request.headers["authorization"] == "Bearer rg_pk_live_test"
        body = json.loads(request.content)
        assert body["query"] == "qual o prazo?"
        assert body["context"] == ["Art. 49: 7 dias."]
        assert body["answer"] == "7 dias."
        assert "trace_id" in body

    def test_send_swallows_errors(self, caplog: pytest.LogCaptureFixture) -> None:
        """A 500 from cloud must NOT raise — silent log only."""
        transport = _mock_transport("/v1/traces", response_status=500, response_body={})

        client = CloudClient(api_key="key", base_url="https://api.test")
        client._client = httpx.Client(transport=transport)

        # should not raise
        client.send(EvalSample(query="q", context=["c"], answer="a"))

        assert "send failed" in caplog.text or "500" in caplog.text

    def test_send_batch_returns_accepted_count(self) -> None:
        transport = _mock_transport(
            "/v1/traces", response_body={"accepted": 3}
        )
        client = CloudClient(api_key="key", base_url="https://api.test")
        client._client = httpx.Client(transport=transport)

        n = client.send_batch(
            [
                EvalSample(query=f"q{i}", context=["c"], answer="a")
                for i in range(3)
            ]
        )

        assert n == 3

    def test_send_batch_empty_returns_zero(self) -> None:
        client = CloudClient(api_key="key", base_url="https://api.test")
        # no transport needed — empty input short-circuits
        assert client.send_batch([]) == 0

    def test_send_batch_swallows_errors(self) -> None:
        transport = _mock_transport("/v1/traces", response_status=503, response_body={})
        client = CloudClient(api_key="key", base_url="https://api.test")
        client._client = httpx.Client(transport=transport)

        n = client.send_batch(
            [EvalSample(query="q", context=["c"], answer="a")]
        )

        assert n == 0

    def test_from_env_requires_api_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("RAGEVAL_API_KEY", raising=False)
        with pytest.raises(RuntimeError, match="RAGEVAL_API_KEY"):
            CloudClient.from_env()

    def test_from_env_uses_env_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("RAGEVAL_API_KEY", "rg_pk_live_test")
        client = CloudClient.from_env()
        assert client.api_key == "rg_pk_live_test"

    def test_from_env_uses_base_url_override(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("RAGEVAL_API_KEY", "k")
        monkeypatch.setenv("RAGEVAL_BASE_URL", "https://staging.rageval.dev/")
        client = CloudClient.from_env()
        assert client.base_url == "https://staging.rageval.dev"  # trailing slash stripped

    def test_context_manager_closes(self) -> None:
        transport = _mock_transport("/v1/traces")
        with CloudClient(api_key="k", base_url="https://api.test") as client:
            client._client = httpx.Client(transport=transport)
            client.send(EvalSample(query="q", context=["c"], answer="a"))
        assert client._client is None


class TestAsyncCloudClient:
    async def test_send_posts(self) -> None:
        captured: list[httpx.Request] = []
        transport = httpx.MockTransport(
            lambda req: (captured.append(req) or httpx.Response(200, json={"accepted": 1}))
        )

        client = AsyncCloudClient(api_key="k", base_url="https://api.test")
        client._client = httpx.AsyncClient(transport=transport)

        await client.send(EvalSample(query="q", context=["c"], answer="a"))
        await client.close()

        assert len(captured) == 1
        body = json.loads(captured[0].content)
        assert body["query"] == "q"

    async def test_send_batch(self) -> None:
        transport = httpx.MockTransport(
            lambda req: httpx.Response(200, json={"accepted": 2})
        )
        client = AsyncCloudClient(api_key="k", base_url="https://api.test")
        client._client = httpx.AsyncClient(transport=transport)

        n = await client.send_batch(
            [
                EvalSample(query="q1", context=["c"], answer="a"),
                EvalSample(query="q2", context=["c"], answer="a"),
            ]
        )
        await client.close()

        assert n == 2

    async def test_swallows_errors(self) -> None:
        transport = httpx.MockTransport(lambda req: httpx.Response(500))
        client = AsyncCloudClient(api_key="k", base_url="https://api.test")
        client._client = httpx.AsyncClient(transport=transport)

        # must not raise
        await client.send(EvalSample(query="q", context=["c"], answer="a"))
        await client.close()
