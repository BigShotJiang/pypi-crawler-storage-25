"""Tests for the LlamaIndex callback handler."""

from __future__ import annotations

import pytest

# Skip the entire module if llama-index-core isn't installed (it's a soft dep).
pytest.importorskip("llama_index.core")

from llama_index.core.callbacks.schema import CBEventType, EventPayload
from llama_index.core.schema import NodeWithScore, TextNode

from rageval.integrations.llamaindex import RAGEvalCallbackHandler
from rageval.integrations.tracing import clear_trace_handlers, register_trace_handler


@pytest.fixture(autouse=True)
def _isolate() -> None:
    clear_trace_handlers()
    yield
    clear_trace_handlers()


def _node(text: str) -> NodeWithScore:
    return NodeWithScore(node=TextNode(text=text), score=1.0)


class TestLlamaIndexHandler:
    def test_full_flow_emits_one_trace(self) -> None:
        handler = RAGEvalCallbackHandler()

        handler.on_event_start(
            CBEventType.QUERY,
            payload={EventPayload.QUERY_STR: "qual o prazo?"},
            event_id="e1",
        )
        handler.on_event_end(
            CBEventType.RETRIEVE,
            payload={EventPayload.NODES: [_node("Art. 49: 7 dias."), _node("complemento.")]},
            event_id="e2",
        )
        handler.on_event_end(
            CBEventType.LLM,
            payload={EventPayload.RESPONSE: "7 dias do recebimento."},
            event_id="e3",
        )

        assert len(handler.traces) == 1
        sample = handler.traces[0]
        assert sample.query == "qual o prazo?"
        assert sample.context == ["Art. 49: 7 dias.", "complemento."]
        assert sample.answer == "7 dias do recebimento."

    def test_synthesize_event_also_emits(self) -> None:
        handler = RAGEvalCallbackHandler()
        handler.on_event_start(
            CBEventType.QUERY, payload={EventPayload.QUERY_STR: "q"}
        )
        handler.on_event_end(
            CBEventType.RETRIEVE, payload={EventPayload.NODES: [_node("c")]}
        )
        handler.on_event_end(
            CBEventType.SYNTHESIZE, payload={EventPayload.RESPONSE: "a"}
        )

        assert len(handler.traces) == 1
        assert handler.traces[0].answer == "a"

    def test_clear_resets_state(self) -> None:
        handler = RAGEvalCallbackHandler()
        handler.on_event_start(
            CBEventType.QUERY, payload={EventPayload.QUERY_STR: "q"}
        )
        handler.on_event_end(
            CBEventType.RETRIEVE, payload={EventPayload.NODES: [_node("c")]}
        )
        handler.on_event_end(CBEventType.LLM, payload={EventPayload.RESPONSE: "a"})

        handler.clear()

        assert handler.traces == []
        assert handler.last_trace is None

    def test_emits_to_global_handlers(self) -> None:
        captured: list = []
        register_trace_handler(captured.append)

        handler = RAGEvalCallbackHandler()
        handler.on_event_start(
            CBEventType.QUERY, payload={EventPayload.QUERY_STR: "q"}
        )
        handler.on_event_end(
            CBEventType.RETRIEVE, payload={EventPayload.NODES: [_node("c")]}
        )
        handler.on_event_end(CBEventType.LLM, payload={EventPayload.RESPONSE: "a"})

        assert len(captured) == 1
        assert captured[0].query == "q"

    def test_multiple_traces_accumulate(self) -> None:
        handler = RAGEvalCallbackHandler()

        for i in range(3):
            handler.start_trace()
            handler.on_event_start(
                CBEventType.QUERY,
                payload={EventPayload.QUERY_STR: f"q{i}"},
            )
            handler.on_event_end(
                CBEventType.RETRIEVE,
                payload={EventPayload.NODES: [_node(f"c{i}")]},
            )
            handler.on_event_end(
                CBEventType.LLM,
                payload={EventPayload.RESPONSE: f"a{i}"},
            )

        assert len(handler.traces) == 3
        assert [t.query for t in handler.traces] == ["q0", "q1", "q2"]
