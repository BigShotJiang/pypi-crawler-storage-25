"""Tests for rageval.cache."""

from __future__ import annotations

from pathlib import Path

import pytest

from rageval.cache import DiskCache, MemoryCache, NullCache, _key


class TestKey:
    def test_same_inputs_same_key(self) -> None:
        assert _key("p", "m", 0.0) == _key("p", "m", 0.0)

    def test_different_prompt_different_key(self) -> None:
        assert _key("p1", "m", 0.0) != _key("p2", "m", 0.0)

    def test_different_model_different_key(self) -> None:
        assert _key("p", "m1", 0.0) != _key("p", "m2", 0.0)

    def test_different_temp_different_key(self) -> None:
        assert _key("p", "m", 0.0) != _key("p", "m", 0.5)

    def test_unicode_in_prompt(self) -> None:
        # ensure non-ASCII is handled deterministically
        assert _key("perguntá", "m", 0.0) == _key("perguntá", "m", 0.0)


class TestNullCache:
    def test_always_misses(self) -> None:
        c = NullCache()
        assert c.get("p", "m", 0.0) is None
        c.set("p", "m", 0.0, "response")
        assert c.get("p", "m", 0.0) is None


class TestMemoryCache:
    def test_set_then_get(self, memory_cache: MemoryCache) -> None:
        memory_cache.set("p", "m", 0.0, "hello")
        assert memory_cache.get("p", "m", 0.0) == "hello"

    def test_miss_returns_none(self, memory_cache: MemoryCache) -> None:
        assert memory_cache.get("p", "m", 0.0) is None

    def test_independent_keys(self, memory_cache: MemoryCache) -> None:
        memory_cache.set("p", "m", 0.0, "a")
        memory_cache.set("q", "m", 0.0, "b")
        assert memory_cache.get("p", "m", 0.0) == "a"
        assert memory_cache.get("q", "m", 0.0) == "b"

    def test_overwrite(self, memory_cache: MemoryCache) -> None:
        memory_cache.set("p", "m", 0.0, "first")
        memory_cache.set("p", "m", 0.0, "second")
        assert memory_cache.get("p", "m", 0.0) == "second"


class TestDiskCache:
    def test_set_then_get(self, tmp_disk_cache_dir: Path) -> None:
        c = DiskCache(tmp_disk_cache_dir)
        c.set("p", "m", 0.0, "hello")
        assert c.get("p", "m", 0.0) == "hello"

    def test_persists_across_instances(self, tmp_disk_cache_dir: Path) -> None:
        c1 = DiskCache(tmp_disk_cache_dir)
        c1.set("p", "m", 0.0, "hello")
        c2 = DiskCache(tmp_disk_cache_dir)
        assert c2.get("p", "m", 0.0) == "hello"

    def test_corrupt_file_returns_none(self, tmp_disk_cache_dir: Path) -> None:
        c = DiskCache(tmp_disk_cache_dir)
        c.set("p", "m", 0.0, "hello")
        files = list(tmp_disk_cache_dir.iterdir())
        assert len(files) == 1
        files[0].write_text("not json")
        assert c.get("p", "m", 0.0) is None

    def test_unicode_response(self, tmp_disk_cache_dir: Path) -> None:
        c = DiskCache(tmp_disk_cache_dir)
        c.set("p", "m", 0.0, "olá, com acento e ção!")
        assert c.get("p", "m", 0.0) == "olá, com acento e ção!"

    def test_miss_returns_none(self, tmp_disk_cache_dir: Path) -> None:
        c = DiskCache(tmp_disk_cache_dir)
        assert c.get("never-set", "m", 0.0) is None

    def test_default_directory_is_under_home(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        # redirect HOME to tmp so we don't pollute the real cache
        monkeypatch.setenv("HOME", str(tmp_path))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        c = DiskCache()
        assert c.directory == tmp_path / ".cache" / "rageval"
        assert c.directory.exists()
