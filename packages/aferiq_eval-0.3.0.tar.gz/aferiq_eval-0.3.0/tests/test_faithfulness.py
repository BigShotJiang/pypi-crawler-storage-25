"""Tests for rageval.metrics.faithfulness."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

from rageval.judge import Judge
from rageval.metrics.base import clamp_score, parse_judge_json
from rageval.metrics.faithfulness import Faithfulness
from rageval.types import EvalSample


class TestParseJudgeJson:
    def test_plain_json(self) -> None:
        assert parse_judge_json('{"score": 0.8}') == {"score": 0.8}

    def test_markdown_fenced_json(self) -> None:
        raw = '```json\n{"score": 0.5, "reasoning": "ok"}\n```'
        assert parse_judge_json(raw) == {"score": 0.5, "reasoning": "ok"}

    def test_markdown_fenced_no_lang(self) -> None:
        raw = '```\n{"score": 0.6}\n```'
        assert parse_judge_json(raw) == {"score": 0.6}

    def test_unfenced_with_prose(self) -> None:
        raw = 'Sure! Here is my evaluation:\n{"score": 0.7}\nHope that helps.'
        assert parse_judge_json(raw) == {"score": 0.7}

    def test_invalid_raises(self) -> None:
        with pytest.raises(ValueError, match="Could not parse JSON"):
            parse_judge_json("no json here")

    def test_array_top_level_raises(self) -> None:
        with pytest.raises(ValueError, match="Expected JSON object"):
            parse_judge_json("[1, 2, 3]")


class TestClampScore:
    def test_in_range(self) -> None:
        assert clamp_score(0.5) == 0.5

    def test_above_one(self) -> None:
        assert clamp_score(1.5) == 1.0

    def test_below_zero(self) -> None:
        assert clamp_score(-0.5) == 0.0

    def test_string_number(self) -> None:
        assert clamp_score("0.7") == 0.7

    def test_invalid_returns_zero(self) -> None:
        assert clamp_score("nope") == 0.0
        assert clamp_score(None) == 0.0


class TestFaithfulness:
    def test_well_formed_response(
        self, fake_judge_factory: Callable[[list[str]], Judge]
    ) -> None:
        judge = fake_judge_factory(['{"score": 0.9, "reasoning": "tudo ok"}'])
        metric = Faithfulness()
        sample = EvalSample(
            query="Qual o prazo do CDC?",
            context=["Art. 49: 7 dias contados do recebimento."],
            answer="7 dias.",
        )

        result = metric.score(sample, judge, language="pt")

        assert result.metric == "faithfulness"
        assert result.score == 0.9
        assert result.reasoning == "tudo ok"
        assert result.language == "pt"
        assert result.raw_judge_response is not None

    def test_malformed_response_score_zero(
        self, fake_judge_factory: Callable[[list[str]], Judge]
    ) -> None:
        judge = fake_judge_factory(["completely bogus output, no JSON"])
        metric = Faithfulness()
        sample = EvalSample(query="q", context=["c"], answer="a")

        result = metric.score(sample, judge, language="pt")

        assert result.score == 0.0
        # PT-language fallback contains "falha"
        assert "falha" in result.reasoning.lower()

    def test_score_clamped_above(
        self, fake_judge_factory: Callable[[list[str]], Judge]
    ) -> None:
        judge = fake_judge_factory(['{"score": 1.7, "reasoning": "x"}'])
        metric = Faithfulness()
        sample = EvalSample(query="q", context=["c"], answer="a")

        result = metric.score(sample, judge, language="pt")

        assert result.score == 1.0

    def test_score_clamped_below(
        self, fake_judge_factory: Callable[[list[str]], Judge]
    ) -> None:
        judge = fake_judge_factory(['{"score": -0.3, "reasoning": "x"}'])
        metric = Faithfulness()
        sample = EvalSample(query="q", context=["c"], answer="a")

        result = metric.score(sample, judge, language="pt")

        assert result.score == 0.0

    def test_prompt_includes_inputs(
        self, fake_judge_factory: Callable[[list[str]], Judge]
    ) -> None:
        judge = fake_judge_factory(['{"score": 1.0, "reasoning": "x"}'])
        metric = Faithfulness()
        sample = EvalSample(
            query="my-unique-query-marker-xyz",
            context=["my-unique-context-marker-xyz"],
            answer="my-unique-answer-marker-xyz",
        )

        metric.score(sample, judge, language="pt")

        log: list[dict[str, Any]] = judge._call_log  # type: ignore[attr-defined]
        prompt = log[0]["prompt"]
        assert "my-unique-query-marker-xyz" in prompt
        assert "my-unique-context-marker-xyz" in prompt
        assert "my-unique-answer-marker-xyz" in prompt

    def test_pt_and_en_prompts_differ(
        self, fake_judge_factory: Callable[[list[str]], Judge]
    ) -> None:
        judge_pt = fake_judge_factory(['{"score": 1.0, "reasoning": "x"}'])
        judge_en = fake_judge_factory(['{"score": 1.0, "reasoning": "x"}'])
        metric = Faithfulness()
        sample = EvalSample(query="q", context=["c"], answer="a")

        metric.score(sample, judge_pt, language="pt")
        metric.score(sample, judge_en, language="en")

        pt_prompt = judge_pt._call_log[0]["prompt"]  # type: ignore[attr-defined]
        en_prompt = judge_en._call_log[0]["prompt"]  # type: ignore[attr-defined]

        assert pt_prompt != en_prompt
        # PT prompt mentions Brazilian failure patterns
        assert "Receita Federal" in pt_prompt or "CNPJ" in pt_prompt
        # EN prompt is in English (no PT-specific keywords)
        assert "Receita Federal" not in en_prompt

    def test_pt_prompt_mentions_brazilian_failure_patterns(self) -> None:
        """The PT-BR prompt is the moat — verify it actually targets BR patterns."""
        from rageval.prompts import load_prompt

        prompt = load_prompt("faithfulness", "pt")
        assert "CNPJ" in prompt
        assert "CPF" in prompt
        assert "Receita Federal" in prompt or "INSS" in prompt
        assert "Lei nº" in prompt

    async def test_ascore_works(
        self, fake_judge_factory: Callable[[list[str]], Judge]
    ) -> None:
        # for async, we wrap a sync fake into an async fn
        from rageval.judge import AsyncJudge

        async def fake_async_fn(prompt: str, model: str, temp: float) -> str:
            return '{"score": 0.85, "reasoning": "async ok"}'

        judge = AsyncJudge(model="fake", judge_fn=fake_async_fn)
        metric = Faithfulness()
        sample = EvalSample(query="q", context=["c"], answer="a")

        result = await metric.ascore(sample, judge, language="pt")

        assert result.score == 0.85
        assert result.reasoning == "async ok"
