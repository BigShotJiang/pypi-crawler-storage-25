"""Tests for the 4 agent metrics — judges are mocked except cost_efficiency
which is purely computational.
"""

from __future__ import annotations

from typing import Any

from rageval import AgentStep, AgentTrace
from rageval.metrics.cost_efficiency import CostEfficiency
from rageval.metrics.goal_completion import GoalCompletion
from rageval.metrics.tool_use_correctness import ToolUseCorrectness
from rageval.metrics.trajectory_quality import TrajectoryQuality


class _FakeJudge:
    """Records prompts and returns canned JSON responses."""

    def __init__(self, response: str) -> None:
        self.response = response
        self.prompts: list[str] = []

    def __call__(self, prompt: str) -> str:
        self.prompts.append(prompt)
        return self.response


def _trace(steps: list[AgentStep], goal: str = "g") -> AgentTrace:
    return AgentTrace(trace_id="t1", goal=goal, steps=steps, final_answer="ok")


class TestTrajectoryQuality:
    def test_score_extracted(self) -> None:
        judge = _FakeJudge('{"score": 0.85, "reasoning": "ok", "issues": []}')
        metric = TrajectoryQuality()
        result = metric.score(_trace([]), judge, "pt")
        assert result.metric == "trajectory_quality"
        assert result.score == 0.85
        assert result.details == {"issues": []}

    def test_issues_surfaced(self) -> None:
        judge = _FakeJudge(
            '{"score": 0.5, "reasoning": "had issues", '
            '"issues": [{"step_idx": 1, "problem": "wrong tool"}]}'
        )
        result = TrajectoryQuality().score(_trace([]), judge, "pt")
        assert result.details["issues"] == [
            {"step_idx": 1, "problem": "wrong tool"}
        ]

    def test_prompt_includes_goal_and_trajectory(self) -> None:
        judge = _FakeJudge('{"score": 1.0, "reasoning": "x"}')
        trace = _trace(
            [
                AgentStep(step_index=0, step_type="llm", tokens_in=50, tokens_out=10),
                AgentStep(step_index=1, step_type="tool", tool_name="search"),
            ],
            goal="my goal",
        )
        TrajectoryQuality().score(trace, judge, "pt")
        prompt = judge.prompts[0]
        assert "my goal" in prompt
        assert "[llm]" in prompt
        assert "search" in prompt


class TestToolUseCorrectness:
    def test_errors_surfaced(self) -> None:
        judge = _FakeJudge(
            '{"score": 0.4, "reasoning": "wrong args", '
            '"errors": [{"call_idx": 0, "type": "wrong_args", "detail": "missing q"}]}'
        )
        result = ToolUseCorrectness().score(_trace([]), judge, "en")
        assert result.metric == "tool_use_correctness"
        assert result.score == 0.4
        assert result.details["errors"][0]["type"] == "wrong_args"


class TestGoalCompletion:
    def test_completed_field_extracted(self) -> None:
        judge = _FakeJudge(
            '{"score": 0.9, "reasoning": "all good", "completed": true, "gap": ""}'
        )
        result = GoalCompletion().score(_trace([]), judge, "pt")
        assert result.score == 0.9
        assert result.details["completed"] is True
        assert result.details["gap"] == ""

    def test_not_completed_with_gap(self) -> None:
        judge = _FakeJudge(
            '{"score": 0.3, "reasoning": "partial", "completed": false, "gap": "missed part B"}'
        )
        result = GoalCompletion().score(_trace([]), judge, "en")
        assert result.details["completed"] is False
        assert "part B" in result.details["gap"]


class TestCostEfficiency:
    def test_one_step_is_perfect(self) -> None:
        trace = _trace([AgentStep(step_index=0, step_type="llm", tokens_in=10, tokens_out=5)])
        result = CostEfficiency().score(trace, _FakeJudge(""), "pt")
        assert result.score == 1.0
        assert result.details["n_steps"] == 1

    def test_three_steps_is_perfect_with_default_baseline(self) -> None:
        steps = [AgentStep(step_index=i, step_type="llm") for i in range(3)]
        result = CostEfficiency().score(_trace(steps), _FakeJudge(""), "pt")
        assert result.score == 1.0  # 3/3
        assert result.details["n_steps"] == 3

    def test_six_steps_is_half_efficient(self) -> None:
        steps = [AgentStep(step_index=i, step_type="llm") for i in range(6)]
        result = CostEfficiency().score(_trace(steps), _FakeJudge(""), "pt")
        assert result.score == 0.5  # 3/6 with default baseline=3

    def test_custom_baseline(self) -> None:
        steps = [AgentStep(step_index=i, step_type="llm") for i in range(10)]
        result = CostEfficiency(optimal_step_baseline=5).score(_trace(steps), _FakeJudge(""), "pt")
        assert result.score == 0.5  # 5/10

    def test_tokens_aggregated(self) -> None:
        steps = [
            AgentStep(step_index=0, step_type="llm", tokens_in=100, tokens_out=20),
            AgentStep(step_index=1, step_type="llm", tokens_in=200, tokens_out=40),
        ]
        result = CostEfficiency().score(_trace(steps), _FakeJudge(""), "pt")
        assert result.details["tokens_total"] == 360


class TestMalformedJudgeResponse:
    """All LLM-based metrics tolerate broken JSON."""

    def test_trajectory_quality_falls_back(self) -> None:
        judge = _FakeJudge("not json at all")
        result = TrajectoryQuality().score(_trace([]), judge, "pt")
        assert result.score == 0.0  # parser fallback

    def test_score_clamped(self) -> None:
        judge = _FakeJudge('{"score": 5.0, "reasoning": "out of range"}')
        result = TrajectoryQuality().score(_trace([]), judge, "pt")
        assert result.score == 1.0  # clamped


def _unused() -> Any:
    """Keep ``Any`` import non-trivial for the future."""
    return None
