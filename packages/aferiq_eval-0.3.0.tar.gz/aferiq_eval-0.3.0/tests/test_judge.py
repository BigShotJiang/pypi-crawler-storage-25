"""Tests for rageval.judge."""

from __future__ import annotations

from rageval.cache import MemoryCache
from rageval.judge import AsyncJudge, Judge


def test_judge_calls_judge_fn() -> None:
    calls: list[tuple[str, str, float]] = []

    def fn(prompt: str, model: str, temp: float) -> str:
        calls.append((prompt, model, temp))
        return "ok"

    j = Judge(model="x", temperature=0.5, judge_fn=fn)
    result = j("hello")

    assert result == "ok"
    assert calls == [("hello", "x", 0.5)]


def test_judge_caches_response_with_memory_cache() -> None:
    call_count = 0

    def fn(prompt: str, model: str, temp: float) -> str:
        nonlocal call_count
        call_count += 1
        return f"r{call_count}"

    j = Judge(model="x", judge_fn=fn, cache=MemoryCache())
    r1 = j("hello")
    r2 = j("hello")

    assert r1 == "r1"
    assert r2 == "r1"  # cached
    assert call_count == 1


def test_judge_cache_keys_by_temperature() -> None:
    call_count = 0

    def fn(prompt: str, model: str, temp: float) -> str:
        nonlocal call_count
        call_count += 1
        return f"r{call_count}"

    cache = MemoryCache()
    j_cold = Judge(model="x", temperature=0.0, judge_fn=fn, cache=cache)
    j_warm = Judge(model="x", temperature=0.5, judge_fn=fn, cache=cache)

    j_cold("hello")
    j_warm("hello")

    assert call_count == 2  # different temps = different cache keys


def test_judge_no_cache_always_calls() -> None:
    call_count = 0

    def fn(prompt: str, model: str, temp: float) -> str:
        nonlocal call_count
        call_count += 1
        return "x"

    j = Judge(judge_fn=fn)  # default NullCache
    j("hello")
    j("hello")

    assert call_count == 2


async def test_async_judge_calls_judge_fn() -> None:
    calls: list[tuple[str, str, float]] = []

    async def fn(prompt: str, model: str, temp: float) -> str:
        calls.append((prompt, model, temp))
        return "ok"

    j = AsyncJudge(model="x", temperature=0.0, judge_fn=fn)
    result = await j("hello")

    assert result == "ok"
    assert calls == [("hello", "x", 0.0)]


async def test_async_judge_caches() -> None:
    call_count = 0

    async def fn(prompt: str, model: str, temp: float) -> str:
        nonlocal call_count
        call_count += 1
        return f"r{call_count}"

    j = AsyncJudge(model="x", judge_fn=fn, cache=MemoryCache())
    r1 = await j("hello")
    r2 = await j("hello")

    assert r1 == "r1"
    assert r2 == "r1"
    assert call_count == 1
