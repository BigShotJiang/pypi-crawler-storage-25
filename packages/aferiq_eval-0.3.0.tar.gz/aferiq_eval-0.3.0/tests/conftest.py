"""Shared pytest fixtures for rageval."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any

import pytest

from rageval.cache import MemoryCache
from rageval.judge import Judge


@pytest.fixture
def memory_cache() -> MemoryCache:
    """Fresh in-memory cache per test."""
    return MemoryCache()


@pytest.fixture
def tmp_disk_cache_dir(tmp_path: Path) -> Path:
    """Isolated disk-cache directory per test."""
    cache_dir = tmp_path / "rageval_cache"
    cache_dir.mkdir()
    return cache_dir


@pytest.fixture
def fake_judge_factory() -> Callable[[list[str]], Judge]:
    """Build a Judge that returns canned responses in order, recording calls.

    Use:
        def test_x(fake_judge_factory):
            judge = fake_judge_factory(['{"score": 0.9, "reasoning": "ok"}'])
            ...
    """
    def make(responses: list[str]) -> Judge:
        queue = list(responses)
        call_log: list[dict[str, Any]] = []

        def fake_fn(prompt: str, model: str, temperature: float) -> str:
            call_log.append({"prompt": prompt, "model": model, "temperature": temperature})
            if not queue:
                raise AssertionError("fake judge ran out of canned responses")
            return queue.pop(0)

        judge = Judge(model="fake-model", temperature=0.0, judge_fn=fake_fn)
        # attach for inspection
        judge._call_log = call_log  # type: ignore[attr-defined]
        return judge

    return make


@pytest.fixture
def sample_pt_data() -> dict[str, list[Any]]:
    """Sample PT-BR data — covers a faithful and a hallucinated answer."""
    return {
        "queries": [
            "Qual o prazo do CDC pra arrependimento?",
            "Qual a idade do CNPJ 11.222.333/0001-44?",
        ],
        "contexts": [
            ["Art. 49 do CDC: 7 dias contados do recebimento do produto."],
            ["O CNPJ é um identificador fiscal de 14 dígitos. Não tem 'idade' como pessoa."],
        ],
        "answers": [
            "Pelo CDC, o consumidor tem 7 dias pra desistir.",
            "O CNPJ tem 30 anos.",  # hallucinated
        ],
    }
