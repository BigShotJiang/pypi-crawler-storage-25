"""Tests for scripts/check_changelog.py.

The script is imported via importlib because `scripts/` isn't a Python
package — adding an __init__.py would change how hatchling treats it.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest

_SCRIPT = Path(__file__).resolve().parent.parent / "scripts" / "check_changelog.py"


def _load():
    spec = importlib.util.spec_from_file_location("check_changelog", _SCRIPT)
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_first_dated_version_skips_unreleased() -> None:
    cc = _load()
    text = """# Changelog

## [Unreleased]

### Added
- something

## [1.2.3] — 2026-05-01

### Added
- thing
"""
    assert cc.first_dated_version(text) == "1.2.3"


def test_first_dated_version_returns_none_when_only_unreleased() -> None:
    cc = _load()
    text = "# Changelog\n\n## [Unreleased]\n\n### Added\n- thing\n"
    assert cc.first_dated_version(text) is None


def test_pyproject_version_parsing() -> None:
    cc = _load()
    text = '[project]\nname = "x"\nversion = "9.8.7"\n'
    assert cc.pyproject_version(text) == "9.8.7"


def test_main_passes_when_changelog_matches(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    cc = _load()
    py = tmp_path / "pyproject.toml"
    py.write_text('[project]\nname = "x"\nversion = "2.0.0"\n')
    cl = tmp_path / "CHANGELOG.md"
    cl.write_text("# Changelog\n\n## [2.0.0] — 2026-05-14\n\n### Added\n- thing\n")

    sys.argv = ["check_changelog.py", "--pyproject", str(py), "--changelog", str(cl)]
    assert cc.main() == 0
    out = capsys.readouterr().out
    assert "2.0.0" in out


def test_main_fails_on_version_mismatch(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    cc = _load()
    py = tmp_path / "pyproject.toml"
    py.write_text('[project]\nname = "x"\nversion = "2.0.0"\n')
    cl = tmp_path / "CHANGELOG.md"
    cl.write_text("# Changelog\n\n## [1.9.9] — 2026-05-14\n\n### Added\n- thing\n")

    sys.argv = ["check_changelog.py", "--pyproject", str(py), "--changelog", str(cl)]
    assert cc.main() == 1
    err = capsys.readouterr().err
    assert "[1.9.9]" in err
    assert "2.0.0" in err


def test_main_fails_when_no_dated_entry(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    cc = _load()
    py = tmp_path / "pyproject.toml"
    py.write_text('[project]\nname = "x"\nversion = "2.0.0"\n')
    cl = tmp_path / "CHANGELOG.md"
    cl.write_text("# Changelog\n\n## [Unreleased]\n\n### Added\n- thing\n")

    sys.argv = ["check_changelog.py", "--pyproject", str(py), "--changelog", str(cl)]
    assert cc.main() == 1
    err = capsys.readouterr().err
    assert "no dated" in err.lower()
