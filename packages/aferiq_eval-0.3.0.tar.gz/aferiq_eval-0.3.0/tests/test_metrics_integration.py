"""Integration tests: run multiple metrics together via evaluate()."""

from __future__ import annotations

from collections.abc import Callable

import pytest

from rageval import evaluate
from rageval.judge import Judge
from rageval.metrics import available_metrics


def test_all_three_metrics_registered() -> None:
    assert sorted(available_metrics()) == ["citation_accuracy", "faithfulness", "hallucination"]


def test_run_all_three_metrics_together(
    fake_judge_factory: Callable[[list[str]], Judge],
) -> None:
    """One sample × 3 metrics → 3 judge calls → 3 scores aggregated."""
    judge = fake_judge_factory(
        [
            '{"score": 0.95, "reasoning": "fiel", "unsupported_claims": []}',
            '{"score": 0.80, "reasoning": "claims mapeados", "claims": []}',
            '{"score": 0.90, "reasoning": "sem alucinação", "claims": []}',
        ]
    )

    result = evaluate(
        queries=["q"],
        contexts=[["c"]],
        answers=["a"],
        metrics=["faithfulness", "citation_accuracy", "hallucination"],
        judge=judge,
    )

    assert len(result.samples) == 1
    assert len(result.samples[0].scores) == 3
    assert result.aggregate["faithfulness"] == pytest.approx(0.95)
    assert result.aggregate["citation_accuracy"] == pytest.approx(0.80)
    assert result.aggregate["hallucination"] == pytest.approx(0.90)


def test_metrics_isolate_failures(fake_judge_factory: Callable[[list[str]], Judge]) -> None:
    """If one metric's judge call returns garbage, others still produce real scores."""
    judge = fake_judge_factory(
        [
            '{"score": 0.95, "reasoning": "ok", "unsupported_claims": []}',
            "completely bogus",
            '{"score": 0.85, "reasoning": "ok", "claims": []}',
        ]
    )

    result = evaluate(
        queries=["q"],
        contexts=[["c"]],
        answers=["a"],
        metrics=["faithfulness", "citation_accuracy", "hallucination"],
        judge=judge,
    )

    scores = result.samples[0].scores
    by_metric = {s.metric: s for s in scores}

    assert by_metric["faithfulness"].score == pytest.approx(0.95)
    assert by_metric["citation_accuracy"].score == 0.0  # parsing failed → 0
    assert by_metric["hallucination"].score == pytest.approx(0.85)


def test_aggregate_means_per_metric_across_samples(
    fake_judge_factory: Callable[[list[str]], Judge],
) -> None:
    """Means are computed independently per metric across samples."""
    judge = fake_judge_factory(
        [
            # sample 1
            '{"score": 1.0, "reasoning": "x", "unsupported_claims": []}',
            '{"score": 0.5, "reasoning": "x", "claims": []}',
            # sample 2
            '{"score": 0.0, "reasoning": "x", "unsupported_claims": []}',
            '{"score": 0.5, "reasoning": "x", "claims": []}',
        ]
    )

    result = evaluate(
        queries=["q1", "q2"],
        contexts=[["c1"], ["c2"]],
        answers=["a1", "a2"],
        metrics=["faithfulness", "citation_accuracy"],
        judge=judge,
    )

    assert result.aggregate["faithfulness"] == pytest.approx(0.5)  # (1.0 + 0.0) / 2
    assert result.aggregate["citation_accuracy"] == pytest.approx(0.5)  # (0.5 + 0.5) / 2
