"""Tests for rageval.core (evaluate / aevaluate)."""

from __future__ import annotations

from collections.abc import Callable

import pytest

from rageval import aevaluate, evaluate
from rageval.judge import AsyncJudge, Judge


def test_evaluate_basic_shape(fake_judge_factory: Callable[[list[str]], Judge]) -> None:
    judge = fake_judge_factory(
        [
            '{"score": 0.9, "reasoning": "ok"}',
            '{"score": 0.4, "reasoning": "not ok"}',
        ]
    )

    result = evaluate(
        queries=["q1", "q2"],
        contexts=[["c1"], ["c2"]],
        answers=["a1", "a2"],
        metrics=["faithfulness"],
        judge=judge,
    )

    assert len(result.samples) == 2
    assert result.samples[0].sample.query == "q1"
    assert result.samples[0].scores[0].score == 0.9
    assert result.samples[1].scores[0].score == 0.4
    assert result.aggregate == {"faithfulness": pytest.approx(0.65)}


def test_evaluate_default_metric_is_faithfulness(
    fake_judge_factory: Callable[[list[str]], Judge],
) -> None:
    judge = fake_judge_factory(['{"score": 0.5, "reasoning": "ok"}'])

    result = evaluate(
        queries=["q1"],
        contexts=[["c1"]],
        answers=["a1"],
        judge=judge,
    )

    assert "faithfulness" in result.aggregate


def test_evaluate_length_mismatch_raises() -> None:
    with pytest.raises(ValueError, match="must have equal length"):
        evaluate(
            queries=["a", "b"],
            contexts=[["c1"]],
            answers=["a1"],
        )


def test_evaluate_ground_truth_length_validated() -> None:
    with pytest.raises(ValueError, match="ground_truth"):
        evaluate(
            queries=["q1"],
            contexts=[["c1"]],
            answers=["a1"],
            ground_truth=["g1", "g2"],
        )


def test_evaluate_unknown_metric_raises(
    fake_judge_factory: Callable[[list[str]], Judge],
) -> None:
    judge = fake_judge_factory([])
    with pytest.raises(ValueError, match="Unknown RAG metric"):
        evaluate(
            queries=["q"],
            contexts=[["c"]],
            answers=["a"],
            metrics=["nonexistent"],
            judge=judge,
        )


def test_evaluate_serializes_to_dict(
    fake_judge_factory: Callable[[list[str]], Judge],
) -> None:
    judge = fake_judge_factory(['{"score": 0.9, "reasoning": "ok"}'])
    result = evaluate(
        queries=["q1"],
        contexts=[["c1"]],
        answers=["a1"],
        judge=judge,
    )
    d = result.to_dict()
    assert "samples" in d
    assert "aggregate" in d
    assert d["aggregate"] == {"faithfulness": 0.9}


def test_evaluate_str_renders(fake_judge_factory: Callable[[list[str]], Judge]) -> None:
    """Smoke test: str(result) renders without crashing and contains the query."""
    judge = fake_judge_factory(['{"score": 0.9, "reasoning": "ok"}'])
    result = evaluate(
        queries=["unique-query-token"],
        contexts=[["c1"]],
        answers=["a1"],
        judge=judge,
    )
    s = str(result)
    assert "unique-query-token" in s
    assert "0.90" in s


def test_evaluate_passes_ground_truth_to_samples(
    fake_judge_factory: Callable[[list[str]], Judge],
) -> None:
    judge = fake_judge_factory(['{"score": 0.9, "reasoning": "ok"}'])
    result = evaluate(
        queries=["q1"],
        contexts=[["c1"]],
        answers=["a1"],
        ground_truth=["the-truth"],
        judge=judge,
    )
    assert result.samples[0].sample.ground_truth == "the-truth"


async def test_aevaluate_basic() -> None:
    async def fake_async_fn(prompt: str, model: str, temp: float) -> str:
        return '{"score": 0.8, "reasoning": "ok"}'

    judge = AsyncJudge(judge_fn=fake_async_fn)

    result = await aevaluate(
        queries=["q1", "q2"],
        contexts=[["c1"], ["c2"]],
        answers=["a1", "a2"],
        judge=judge,
    )

    assert len(result.samples) == 2
    assert all(s.scores[0].score == 0.8 for s in result.samples)
    assert result.aggregate["faithfulness"] == pytest.approx(0.8)


async def test_aevaluate_concurrency_param_accepted() -> None:
    async def fake_async_fn(prompt: str, model: str, temp: float) -> str:
        return '{"score": 1.0, "reasoning": "x"}'

    judge = AsyncJudge(judge_fn=fake_async_fn)
    result = await aevaluate(
        queries=["q1", "q2", "q3"],
        contexts=[["c1"], ["c2"], ["c3"]],
        answers=["a1", "a2", "a3"],
        judge=judge,
        concurrency=2,
    )

    assert len(result.samples) == 3
