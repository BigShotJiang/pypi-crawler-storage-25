"""TinyEHR — A tiny EHR dataset for learning, prototyping, and building."""

from tinyehr.api import (
    build_sqlite,
    describe_table,
    get_patient,
    help,
    info,
    list_tables,
    load_table,
    search_tables,
)

__version__ = "0.1.0"
__all__ = [
    "help", "info", "list_tables", "describe_table", "search_tables",
    "load_table", "get_patient", "build_sqlite", "__version__",
]
