"""TinyEHR — load clinical tables from HuggingFace as DataFrames."""

import sqlite3
import warnings
from pathlib import Path

import pandas as pd

try:
    import pyarrow  # noqa: F401
    _HAS_PYARROW = True
except ImportError:
    _HAS_PYARROW = False

__all__ = [
    "help", "info", "list_tables", "describe_table", "search_tables",
    "load_table", "get_patient", "build_sqlite",
]

# ── HuggingFace base URL ───────────────────────────────────────────────────

_HF_BASE = (
    "https://huggingface.co/datasets/vidulpanickan/TinyEHR/resolve/main"
)
_GH_BASE = (
    "https://raw.githubusercontent.com/vidulpanickan/TinyEHR/main"
)

# MIMIC CSV subfolder mapping (GitHub repo structure)
_MIMIC_CSV_SUBDIR = {}
for _t in ["admissions", "d_hcpcs", "d_icd_diagnoses", "d_icd_procedures",
           "d_labitems", "diagnoses_icd", "drgcodes", "emar", "emar_detail",
           "hcpcsevents", "labevents", "microbiologyevents", "omr", "patients",
           "pharmacy", "poe", "poe_detail", "prescriptions", "procedures_icd",
           "provider", "services", "transfers"]:
    _MIMIC_CSV_SUBDIR[_t] = "hosp"
for _t in ["caregiver", "chartevents", "d_items", "datetimeevents", "icustays",
           "ingredientevents", "inputevents", "outputevents", "procedureevents"]:
    _MIMIC_CSV_SUBDIR[_t] = "icu"
_MIMIC_CSV_SUBDIR["noteevents"] = "notes"
_MIMIC_CSV_SUBDIR["date_offsets"] = "../metadata"

# ── Table registries ──────────────────────────────────────────────────────

_MIMIC_TABLES = [
    "admissions", "caregiver", "chartevents", "d_hcpcs", "d_icd_diagnoses",
    "d_icd_procedures", "d_items", "d_labitems", "date_offsets",
    "datetimeevents", "diagnoses_icd", "drgcodes", "emar", "emar_detail",
    "hcpcsevents", "icustays", "ingredientevents", "inputevents",
    "labevents", "microbiologyevents", "noteevents", "omr", "outputevents",
    "patients", "pharmacy", "poe", "poe_detail", "prescriptions",
    "procedureevents", "procedures_icd", "provider", "services", "transfers",
]

_OMOP_TABLES = [
    "2b_concept", "2b_concept_relationship", "2b_vocabulary",
    "attribute_definition", "care_site", "cdm_source", "cohort",
    "cohort_attribute", "cohort_definition", "condition_era",
    "condition_occurrence", "cost", "death", "device_exposure", "dose_era",
    "drug_era", "drug_exposure", "fact_relationship", "location",
    "measurement", "metadata", "note", "note_nlp", "observation",
    "observation_period", "payer_plan_period", "person",
    "procedure_occurrence", "provider", "specimen", "visit_detail",
    "visit_occurrence",
]

_TABLES = {
    "tinyehr_mimic_format": _MIMIC_TABLES,
    "tinyehr_omop_format": _OMOP_TABLES,
}

_DEFAULT_FORMAT = "tinyehr_mimic_format"

# Patient ID column per format (for get_patient)
_PATIENT_ID_COL = {
    "tinyehr_mimic_format": "subject_id",
    "tinyehr_omop_format": "person_id",
}

_TABLE_ROW_COUNTS = {
    "tinyehr_mimic_format": {
        "admissions": 275, "caregiver": 15468, "chartevents": 668862,
        "d_hcpcs": 89200, "d_icd_diagnoses": 109775, "d_icd_procedures": 85257,
        "d_items": 4014, "d_labitems": 1622, "date_offsets": 100,
        "datetimeevents": 15280, "diagnoses_icd": 4506, "drgcodes": 454,
        "emar": 35835, "emar_detail": 72018, "hcpcsevents": 61,
        "icustays": 140, "ingredientevents": 25728, "inputevents": 20404,
        "labevents": 107727, "microbiologyevents": 2899, "noteevents": 4580,
        "omr": 2964, "outputevents": 9362, "patients": 100,
        "pharmacy": 15306, "poe": 45154, "poe_detail": 3795,
        "prescriptions": 18087, "procedureevents": 1468, "procedures_icd": 722,
        "provider": 40508, "services": 319, "transfers": 1190,
    },
    "tinyehr_omop_format": {
        "2b_concept": 3904, "2b_concept_relationship": 7716, "2b_vocabulary": 27,
        "attribute_definition": 0, "care_site": 31, "cdm_source": 1,
        "cohort": 0, "cohort_attribute": 0, "cohort_definition": 0,
        "condition_era": 3771, "condition_occurrence": 16441, "cost": 0,
        "death": 15, "device_exposure": 3855, "dose_era": 117,
        "drug_era": 7931, "drug_exposure": 18229, "fact_relationship": 1752,
        "location": 1, "measurement": 338550, "metadata": 0,
        "note": 4580, "note_nlp": 0, "observation": 31390,
        "observation_period": 100, "payer_plan_period": 0, "person": 100,
        "procedure_occurrence": 18447, "provider": 0, "specimen": 150,
        "visit_detail": 14479, "visit_occurrence": 852,
    },
}

# ── Cache directory ───────────────────────────────────────────────────────

_CACHE_DIR = Path.home() / ".cache" / "tinyehr"


def _validate_format(fmt: str) -> None:
    if fmt not in _TABLES:
        raise ValueError(
            f"Unknown format '{fmt}'. "
            f"Choose from: {', '.join(sorted(_TABLES))}"
        )


def _validate_table(name: str, fmt: str) -> None:
    if name not in _TABLES[fmt]:
        raise ValueError(
            f"Table '{name}' not found in {fmt}. "
            f"Use list_tables(format='{fmt}') to see available tables."
        )


def _parquet_url(table: str, fmt: str) -> str:
    return f"{_HF_BASE}/{fmt}/{table}.parquet"


def _csv_url(table: str, fmt: str) -> str:
    if fmt == "tinyehr_mimic_format":
        subdir = _MIMIC_CSV_SUBDIR.get(table, "hosp")
        return f"{_GH_BASE}/{fmt}/{subdir}/{table}.csv"
    else:
        return f"{_GH_BASE}/{fmt}/{table}.csv"


def _cache_path(table: str, fmt: str) -> Path:
    return _CACHE_DIR / fmt / f"{table}.parquet"


_PYARROW_WARNING_SHOWN = False


# ── Public API ────────────────────────────────────────────────────────────


def list_tables(format: str = _DEFAULT_FORMAT) -> list[str]:
    """Return sorted list of table names for the given format.

    Args:
        format: 'tinyehr_mimic_format' (default) or 'tinyehr_omop_format'
    """
    _validate_format(format)
    return sorted(_TABLES[format])


def help() -> None:
    """Print a quick reference of all available functions."""
    print("""TinyEHR — A tiny EHR dataset (100 patients, MIMIC + OMOP formats)

Functions:
  tinyehr.help()                            This help text
  tinyehr.info()                            Overview of all tables with row counts
  tinyehr.list_tables()                     List table names
  tinyehr.describe_table("patients")        Column names, types, and sample rows
  tinyehr.search_tables("lab")              Find tables by keyword
  tinyehr.load_table("patients")            Load a table as a DataFrame
  tinyehr.get_patient(10000032)             All data for one patient
  tinyehr.build_sqlite()                    Build a local SQLite database

Formats:
  'tinyehr_mimic_format' (default) — 33 tables, MIMIC-IV native schema
  'tinyehr_omop_format'            — 32 tables, OMOP CDM v5.3.1

Pass format= to any function, e.g.:
  tinyehr.load_table("person", format="tinyehr_omop_format")

Docs: https://tinyehr.org
Data: https://huggingface.co/datasets/vidulpanickan/TinyEHR""")


def info(format: str = _DEFAULT_FORMAT) -> None:
    """Print an overview of all tables and their row counts.

    Args:
        format: 'tinyehr_mimic_format' (default) or 'tinyehr_omop_format'
    """
    _validate_format(format)
    rows = _TABLE_ROW_COUNTS[format]
    total_rows = sum(rows.values())
    total_tables = len(rows)

    print(f"TinyEHR — {format} ({total_tables} tables, {total_rows:,} rows)")
    print()
    print(f"  {'Table':<30s} {'Rows':>10s}")
    print(f"  {'─' * 30} {'─' * 10}")
    for table in sorted(rows):
        print(f"  {table:<30s} {rows[table]:>10,}")
    print(f"\nSchema docs: https://tinyehr.org")


def describe_table(
    name: str,
    format: str = _DEFAULT_FORMAT,
    *,
    sample_rows: int = 3,
) -> None:
    """Print a summary of a table: row count, columns, and sample data.

    Args:
        name: Table name (e.g. 'patients', 'admissions')
        format: 'tinyehr_mimic_format' (default) or 'tinyehr_omop_format'
        sample_rows: Number of sample rows to display (default 3)
    """
    _validate_format(format)
    _validate_table(name, format)

    df = load_table(name, format=format)
    print(f"{name} ({len(df):,} rows, {len(df.columns)} columns)")
    print()
    print("Columns:")
    for col in df.columns:
        print(f"  {col:<35s} {df[col].dtype}")

    if sample_rows > 0 and len(df) > 0:
        print(f"\nSample ({sample_rows} rows):")
        print(df.head(sample_rows).to_string(index=False))
    print(f"\nFull schema: https://tinyehr.org")


def search_tables(
    keyword: str,
    format: str = _DEFAULT_FORMAT,
) -> None:
    """Search for tables by keyword in table names and column names.

    Args:
        keyword: Search term (case-insensitive)
        format: 'tinyehr_mimic_format' (default) or 'tinyehr_omop_format'
    """
    _validate_format(format)
    keyword_lower = keyword.lower()
    results = []

    for table in _TABLES[format]:
        table_match = keyword_lower in table.lower()
        rows = _TABLE_ROW_COUNTS[format].get(table, 0)

        # Check column names by loading the table
        if not table_match and rows > 0:
            df = load_table(table, format=format)
            matching_cols = [c for c in df.columns if keyword_lower in c.lower()]
        elif rows > 0:
            df = load_table(table, format=format)
            matching_cols = [c for c in df.columns if keyword_lower in c.lower()]
        else:
            matching_cols = []

        if table_match or matching_cols:
            results.append((table, rows, matching_cols, table_match))

    if not results:
        print(f"No tables matching '{keyword}' in {format}.")
        return

    print(f"Tables matching '{keyword}' in {format}:\n")
    for table, rows, matching_cols, table_match in sorted(results):
        markers = []
        if table_match:
            markers.append("table name matches")
        if matching_cols:
            markers.append(f"columns: {', '.join(matching_cols)}")
        print(f"  {table:<30s} ({rows:,} rows) — {'; '.join(markers)}")


def get_patient(
    patient_id: int,
    format: str = _DEFAULT_FORMAT,
) -> dict[str, pd.DataFrame]:
    """Load all data for a single patient across all tables.

    Args:
        patient_id: The subject_id (MIMIC) or person_id (OMOP)
        format: 'tinyehr_mimic_format' (default) or 'tinyehr_omop_format'

    Returns:
        Dict mapping table name → DataFrame (only tables with data for this patient).
    """
    _validate_format(format)
    id_col = _PATIENT_ID_COL[format]
    result = {}

    for table in sorted(_TABLES[format]):
        if _TABLE_ROW_COUNTS[format].get(table, 0) == 0:
            continue

        df = load_table(table, format=format)
        if id_col not in df.columns:
            continue

        filtered = df[df[id_col] == patient_id]
        if not filtered.empty:
            result[table] = filtered

    return result


def load_table(
    name: str,
    format: str = _DEFAULT_FORMAT,
    *,
    use_cache: bool = True,
) -> pd.DataFrame:
    """Load a table as a pandas DataFrame.

    Downloads from HuggingFace on first call, then uses a local cache.

    Args:
        name: Table name (e.g. 'patients', 'admissions')
        format: 'tinyehr_mimic_format' (default) or 'tinyehr_omop_format'
        use_cache: If True (default), cache Parquet files locally.
    """
    _validate_format(format)
    _validate_table(name, format)

    cached = _cache_path(name, format)

    if use_cache and cached.exists() and _HAS_PYARROW:
        return pd.read_parquet(cached)

    if _HAS_PYARROW:
        url = _parquet_url(name, format)
        df = pd.read_parquet(url)

        if use_cache:
            cached.parent.mkdir(parents=True, exist_ok=True)
            df.to_parquet(cached, engine="pyarrow", index=False)
    else:
        global _PYARROW_WARNING_SHOWN
        if not _PYARROW_WARNING_SHOWN:
            warnings.warn(
                "pyarrow not found — loading CSV from GitHub (slower, all columns as text). "
                "Install pyarrow for faster Parquet loading: pip install pyarrow",
                stacklevel=2,
            )
            _PYARROW_WARNING_SHOWN = True

        url = _csv_url(name, format)
        df = pd.read_csv(url, low_memory=False)

    return df


def build_sqlite(
    format: str = _DEFAULT_FORMAT,
    output: str | Path | None = None,
) -> Path:
    """Download all tables and build a local SQLite database.

    Args:
        format: 'tinyehr_mimic_format' (default) or 'tinyehr_omop_format'
        output: Output path. Defaults to ~/.cache/tinyehr/{format}.db

    Returns:
        Path to the SQLite database file.
    """
    _validate_format(format)

    if output is None:
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        output = _CACHE_DIR / f"{format}.db"
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)

    if output.exists():
        output.unlink()

    conn = sqlite3.connect(str(output))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=OFF")

    tables = _TABLES[format]
    total = len(tables)

    for i, table in enumerate(tables, 1):
        print(f"  [{i}/{total}] {table}...", end=" ", flush=True)
        df = load_table(table, format=format)
        df.to_sql(table, conn, if_exists="replace", index=False)
        print(f"{len(df):,} rows")

    conn.execute("PRAGMA journal_mode=DELETE")
    conn.close()

    print(f"\nSQLite database: {output}")
    return output
