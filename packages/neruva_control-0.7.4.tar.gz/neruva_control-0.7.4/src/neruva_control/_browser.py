"""Browser sub-agent for both Code and Computer agents.

Backed by Playwright (Python). The action surface mirrors the
Playwright CLI / Browser-Use pattern: instead of returning a raw DOM
or screenshot, the agent gets a compact accessibility snapshot (YAML-
like) and works with element refs. This is the same path Microsoft
took with Playwright CLI -- ~4x fewer tokens than Playwright MCP.

Lazy-initialized: the first ``browser_open`` boots Chromium; closes
on session end or explicit ``browser_close``. Single shared instance
per daemon (keeps state across multiple browser_* calls).
"""
from __future__ import annotations

import asyncio
import threading
from typing import Any, Optional


_LOCK = threading.Lock()
_STATE: dict[str, Any] = {"loop": None, "browser": None, "context": None,
                          "page": None, "started": False}


def _ensure_loop() -> asyncio.AbstractEventLoop:
    """Run Playwright's async API on a dedicated background loop. The
    agent calls execute synchronously from any thread."""
    if _STATE.get("loop") and not _STATE["loop"].is_closed():
        return _STATE["loop"]
    loop = asyncio.new_event_loop()
    _STATE["loop"] = loop

    def _runner():
        asyncio.set_event_loop(loop)
        loop.run_forever()

    t = threading.Thread(target=_runner, daemon=True)
    t.start()
    return loop


def _run(coro):
    loop = _ensure_loop()
    fut = asyncio.run_coroutine_threadsafe(coro, loop)
    return fut.result(timeout=120)


async def _start_browser(headless: bool = False):
    if _STATE.get("browser") is not None:
        return
    try:
        from playwright.async_api import async_playwright
    except ImportError as e:
        raise RuntimeError(
            "playwright not installed. Run: pip install playwright "
            "&& playwright install chromium"
        ) from e
    pw = await async_playwright().start()
    _STATE["_pw"] = pw
    browser = await pw.chromium.launch(headless=headless)
    ctx = await browser.new_context(
        viewport={"width": 1280, "height": 800},
        user_agent="Mozilla/5.0 neruva-control browser sub-agent",
    )
    page = await ctx.new_page()
    _STATE["browser"] = browser
    _STATE["context"] = ctx
    _STATE["page"] = page
    _STATE["started"] = True


async def _close_browser():
    page = _STATE.get("page")
    ctx = _STATE.get("context")
    browser = _STATE.get("browser")
    pw = _STATE.get("_pw")
    try:
        if page:
            await page.close()
        if ctx:
            await ctx.close()
        if browser:
            await browser.close()
        if pw:
            await pw.stop()
    except Exception:
        pass
    _STATE["page"] = None
    _STATE["context"] = None
    _STATE["browser"] = None
    _STATE["_pw"] = None
    _STATE["started"] = False


def browser_available() -> tuple[bool, str]:
    try:
        import playwright  # noqa: F401
        return True, "playwright"
    except ImportError:
        return False, ("playwright not installed (pip install playwright "
                       "&& playwright install chromium)")


def browser_action(verb: str, args: dict) -> dict:
    """Single entry point dispatched on ``verb``:
      open ({url, headless?})
      navigate ({url})
      snapshot ({})                 -- accessibility tree summary
      click ({selector | text})
      fill ({selector, text})
      type ({selector, text})       -- alias for fill
      press ({key})                 -- e.g. Enter, Escape
      screenshot ({path?})          -- saves to path or returns base64
      wait_for ({selector | text, timeout_ms?})
      content ({selector?})         -- innerText (or whole body)
      close ({})
    """
    avail, reason = browser_available()
    if not avail:
        return {"ok": False, "error": reason}
    verb = (verb or "").lower()
    try:
        if verb == "open":
            url = str(args.get("url", "")).strip()
            headless = bool(args.get("headless", False))
            with _LOCK:
                _run(_start_browser(headless=headless))
                if url:
                    _run(_STATE["page"].goto(url, wait_until="domcontentloaded"))
            return {"ok": True, "url": url or "(no url)", "ready": True}
        if not _STATE.get("started"):
            return {"ok": False, "error": "browser not open. Call browser_open first."}
        page = _STATE["page"]
        if verb == "navigate":
            url = str(args.get("url", "")).strip()
            if not url:
                return {"ok": False, "error": (
                    "navigate requires args.url. If the page is already "
                    "open from a prior browser({verb:'open',...}), use "
                    "browser({verb:'content',args:{}}) or "
                    "browser({verb:'snapshot',args:{}}) to inspect it."
                )}
            _run(page.goto(url, wait_until="domcontentloaded"))
            return {"ok": True, "url": url, "title": _run(page.title())}
        if verb == "snapshot":
            # Accessibility tree -- compact representation
            tree = _run(page.accessibility.snapshot()) or {}

            def _walk(node: dict, depth: int = 0, out: Optional[list] = None,
                      max_n: int = 120) -> list:
                if out is None:
                    out = []
                if len(out) >= max_n:
                    return out
                name = (node.get("name") or "").strip()
                role = node.get("role", "")
                if role and (name or role in ("link", "button", "textbox",
                                              "combobox", "checkbox",
                                              "menuitem", "tab")):
                    out.append({
                        "role": role,
                        "name": name[:80],
                        "depth": depth,
                    })
                for child in (node.get("children") or []):
                    _walk(child, depth + 1, out, max_n)
                return out
            elements = _walk(tree)
            title = _run(page.title())
            url = page.url
            return {"ok": True, "url": url, "title": title,
                    "n_elements": len(elements), "elements": elements}
        if verb == "click":
            selector = args.get("selector")
            text = args.get("text")
            if selector:
                _run(page.click(selector, timeout=8000))
                return {"ok": True, "clicked": str(selector)}
            if text:
                _run(page.get_by_text(str(text), exact=False).first.click(timeout=8000))
                return {"ok": True, "clicked_text": str(text)}
            return {"ok": False, "error": "selector or text required"}
        if verb in ("fill", "type"):
            selector = str(args.get("selector", ""))
            text = str(args.get("text", ""))
            if not selector:
                return {"ok": False, "error": "selector required"}
            _run(page.fill(selector, text, timeout=8000))
            return {"ok": True, "filled": selector}
        if verb == "press":
            key = str(args.get("key", "")).strip()
            if not key:
                return {"ok": False, "error": "key required"}
            _run(page.keyboard.press(key))
            return {"ok": True, "pressed": key}
        if verb == "screenshot":
            path = args.get("path")
            if path:
                _run(page.screenshot(path=str(path), full_page=False))
                return {"ok": True, "path": str(path)}
            import base64
            png = _run(page.screenshot(full_page=False))
            return {"ok": True, "png_b64": base64.b64encode(png).decode()[:200_000]}
        if verb == "wait_for":
            sel = args.get("selector")
            txt = args.get("text")
            timeout = int(args.get("timeout_ms", 8000))
            if sel:
                _run(page.wait_for_selector(str(sel), timeout=timeout))
                return {"ok": True, "waited_for": str(sel)}
            if txt:
                _run(page.get_by_text(str(txt), exact=False).first.wait_for(timeout=timeout))
                return {"ok": True, "waited_for_text": str(txt)}
            return {"ok": False, "error": "selector or text required"}
        if verb == "content":
            sel = args.get("selector")
            if sel:
                text = _run(page.locator(str(sel)).inner_text(timeout=4000))
            else:
                text = _run(page.evaluate("() => document.body.innerText"))
            text = str(text or "")
            return {"ok": True, "n_chars": len(text), "text": text[:6000]}
        if verb == "close":
            with _LOCK:
                _run(_close_browser())
            return {"ok": True}
        return {"ok": False, "error": f"unknown browser verb: {verb!r}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
