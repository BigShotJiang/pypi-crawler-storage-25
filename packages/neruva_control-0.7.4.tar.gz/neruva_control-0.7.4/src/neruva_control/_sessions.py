"""Session manager -- spawns and tails Claude Code subprocesses.

Each Session = one ``claude --headless --output-format stream-json``
subprocess. Stdout is read line-by-line, each line parsed as JSON,
pushed to per-session asyncio queues for fan-out to WebSocket clients.

Generic enough to swap the binary out for ``cursor``, ``codex``,
``gemini``, etc. in v2 -- the only assumption is "binary outputs
newline-delimited JSON to stdout."

Single-process. One SessionManager per daemon. Sessions live until
explicitly stopped or the daemon dies (in which case OS reaps the
subprocess). Event ring per session bounded at 1000 events to cap
memory if no client is reading.
"""
from __future__ import annotations

import asyncio
import json
import os
import secrets
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, AsyncIterator, Optional


def _which_claude() -> Optional[str]:
    """Locate the Claude Code CLI binary. Honors NERUVA_CLAUDE_BIN env
    so tests can point at /bin/cat etc. Returns None if not found --
    the daemon surfaces this as a clear error to the browser instead
    of crashing on session spawn."""
    override = os.environ.get("NERUVA_CLAUDE_BIN")
    if override:
        return override
    return shutil.which("claude")


@dataclass
class SessionMeta:
    id: str
    project: str        # project namespace (records substrate scope)
    pid: int            # 0 for non-subprocess sessions (e.g. computer agent)
    started_at_ms: int
    status: str  # "running" | "stopped" | "crashed"
    project_id: Optional[str] = None  # link to Project metadata
    model: Optional[str] = None
    last_event_at_ms: Optional[int] = None
    event_count: int = 0
    claude_session_id: Optional[str] = None  # captured from system/init event; used by --resume
    resumed_from: Optional[str] = None  # set if this session was spawned via /resume
    duration_ms: Optional[int] = None    # set on stop()
    # agent_type: "code" (Neruva Code) | "computer" (Neruva Computer GUI loop)
    # | "claude_code_legacy" (back-compat subprocess path, not for new sessions).
    # Defaulted to "code" -- existing callers pass nothing.
    agent_type: str = "code"
    initial_task: Optional[str] = None   # for computer-agent sessions


@dataclass
class _SessionHandle:
    meta: SessionMeta
    queue: asyncio.Queue  # bounded ring of recent events
    listeners: set = field(default_factory=set)  # asyncio.Queue per WS client
    reader_task: Optional[asyncio.Task] = None
    recorder: Optional[Any] = None  # SessionRecorder; circular import avoided
    # Code-agent: subprocess.Popen of `claude`. None for computer-agent.
    proc: Optional[subprocess.Popen] = None
    # Computer-agent: queue of user messages to inject mid-flight, and
    # the asyncio task running the agent loop.
    user_messages: Optional[asyncio.Queue] = None
    agent_task: Optional[asyncio.Task] = None
    abort_flag: bool = False


class SessionManager:
    """Owns the live set of Claude Code sessions on this machine.

    Thread-safety: single asyncio loop. Do not call from sync code.
    """

    EVENT_RING = 1000

    def __init__(self) -> None:
        self._sessions: dict[str, _SessionHandle] = {}

    def list(self) -> list[SessionMeta]:
        return [h.meta for h in self._sessions.values()]

    def get(self, session_id: str) -> Optional[SessionMeta]:
        h = self._sessions.get(session_id)
        return h.meta if h else None

    async def spawn(
        self,
        project: str,
        prompt: Optional[str] = None,
        model: Optional[str] = None,
        project_id: Optional[str] = None,
        cwd: Optional[str] = None,
        resume_claude_session_id: Optional[str] = None,
    ) -> SessionMeta:
        bin_path = _which_claude()
        if not bin_path:
            raise RuntimeError(
                "claude binary not found on PATH. Install Claude Code from "
                "https://claude.com/claude-code or set NERUVA_CLAUDE_BIN."
            )
        # Claude Code: -p/--print is non-interactive mode; --output-format
        # stream-json gives newline-delimited JSON; --input-format stream-json
        # lets us send subsequent user messages as JSON envelopes via stdin
        # without re-spawning. Initial prompt (if any) is sent through stdin
        # below as a JSON envelope, NOT on the command line, so we can
        # support interactive multi-turn from the browser.
        args: list[str] = [
            bin_path, "-p",
            "--output-format", "stream-json",
            "--input-format", "stream-json",
            "--include-partial-messages",
            "--verbose",  # required by claude when --print + stream-json
        ]
        if resume_claude_session_id:
            # --fork-session creates a new session id while resuming the
            # context of the original (so two resumes don't collide on the
            # same id). Drop --fork-session if you want strict same-id
            # continuation; --resume alone reuses the original id.
            args += ["--resume", resume_claude_session_id, "--fork-session"]
        if model:
            args += ["--model", model]
        # On Windows, CREATE_NO_WINDOW so spawned subprocess doesn't pop a
        # console flash. Linux/Mac: 0 (no flag).
        creationflags = 0
        if sys.platform == "win32":
            creationflags = 0x08000000  # CREATE_NO_WINDOW
        # Inherit parent env so claude inherits PATH etc., then explicitly
        # inject NERUVA_API_KEY (and similar known agent env keys) so MCP
        # child processes spawned by claude (e.g. @neruva/mcp via npx) can
        # find their credentials. Without this, the user's neruva MCP server
        # silently fails to register tools and the agent thinks Neruva isn't
        # connected.
        from ._config import neruva_api_key
        spawn_env = os.environ.copy()
        nk = neruva_api_key()
        if nk:
            spawn_env["NERUVA_API_KEY"] = nk
        proc = subprocess.Popen(
            args,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",     # avoid cp1252 mojibake on Windows ("â€"" issue)
            errors="replace",     # don't crash on malformed bytes
            bufsize=1,            # line-buffered
            cwd=cwd or os.path.expanduser("~"),
            env=spawn_env,
            creationflags=creationflags,
        )
        sid = "s_" + secrets.token_hex(6)
        meta = SessionMeta(
            id=sid,
            project=project,
            project_id=project_id,
            pid=proc.pid,
            started_at_ms=int(time.time() * 1000),
            status="running",
            model=model,
            resumed_from=resume_claude_session_id,
        )
        handle = _SessionHandle(meta=meta, proc=proc, queue=asyncio.Queue(maxsize=self.EVENT_RING))
        # Auto-recorder -- silent no-op if NERUVA_API_KEY unset.
        from ._recorder import SessionRecorder
        handle.recorder = SessionRecorder(project=project, session_id=sid)
        await handle.recorder.start()
        # Background reader: parses stdout lines, fans out to listeners
        handle.reader_task = asyncio.create_task(self._reader(handle))
        self._sessions[sid] = handle
        # If an initial prompt was provided, send it as a stream-json
        # envelope on stdin (Claude Code expects that exact shape when
        # --input-format stream-json is set).
        if prompt:
            await self._write_user_message(handle, prompt)
        return meta

    async def spawn_computer_agent(
        self,
        project: str,
        initial_task: str,
        project_id: Optional[str] = None,
        max_steps: int = 12,
    ) -> SessionMeta:
        """Spawn a Neruva Computer (screen-control) agent as a Session.

        Same Session contract as Claude Code: the daemon hands back a
        SessionMeta, the browser subscribes over WS and gets streamed
        events, send_input() pushes mid-flight user messages into the
        agent's directive queue (D2 milestone).
        """
        from ._agent import _PYAUTOGUI_OK
        from ._config import neruva_api_key
        if not _PYAUTOGUI_OK:
            raise RuntimeError(
                "pyautogui not installed -- pip install neruva-control[agent]"
            )
        sid = "ca_" + secrets.token_hex(6)
        meta = SessionMeta(
            id=sid,
            project=project,
            project_id=project_id,
            pid=0,
            started_at_ms=int(time.time() * 1000),
            status="running",
            agent_type="computer",
            initial_task=initial_task,
        )
        handle = _SessionHandle(
            meta=meta,
            queue=asyncio.Queue(maxsize=self.EVENT_RING),
            user_messages=asyncio.Queue(),
        )
        from ._recorder import SessionRecorder
        handle.recorder = SessionRecorder(project=project, session_id=sid)
        await handle.recorder.start()
        self._sessions[sid] = handle
        # Kick off the agent loop as an asyncio task.
        handle.agent_task = asyncio.create_task(
            self._run_computer_agent(
                handle, initial_task, project, neruva_api_key(), max_steps,
            )
        )
        return meta

    async def spawn_code_agent(
        self,
        project: str,
        initial_task: str,
        project_id: Optional[str] = None,
        cwd: Optional[str] = None,
        max_steps: int = 20,
    ) -> SessionMeta:
        """Spawn a Neruva Code session.

        Same Session contract as Neruva Computer: the browser sees a
        SessionMeta, subscribes over WS, sends mid-flight directives
        via send_input which lands in the directive queue."""
        from ._config import neruva_api_key
        sid = "co_" + secrets.token_hex(6)
        meta = SessionMeta(
            id=sid,
            project=project,
            project_id=project_id,
            pid=0,
            started_at_ms=int(time.time() * 1000),
            status="running",
            agent_type="code",
            initial_task=initial_task,
        )
        handle = _SessionHandle(
            meta=meta,
            queue=asyncio.Queue(maxsize=self.EVENT_RING),
            user_messages=asyncio.Queue(),
        )
        from ._recorder import SessionRecorder
        handle.recorder = SessionRecorder(project=project, session_id=sid)
        await handle.recorder.start()
        self._sessions[sid] = handle
        handle.agent_task = asyncio.create_task(
            self._run_code_agent(
                handle, initial_task, project, neruva_api_key(),
                cwd, max_steps,
            )
        )
        return meta

    async def _run_code_agent(
        self,
        handle: _SessionHandle,
        initial_task: str,
        namespace: str,
        nv_key: Optional[str],
        cwd: Optional[str],
        max_steps: int,
    ) -> None:
        """Drive _code_agent.run_task with mid-flight chat-steering."""
        from ._code_agent import run_task as run_code_task

        # Tell every subscribed listener the session is alive *now* so
        # the UI doesn't sit blank during cold-start memory enrichment +
        # plan-cache lookup + first vendor call.
        starting_ev = {"type": "agent.event", "event": "session_starting",
                       "session_id": handle.meta.id}
        for q in list(handle.listeners):
            try: q.put_nowait(starting_ev)
            except Exception: pass

        directives_buf: list[str] = []
        # Conversation log spanning ALL chat turns in this session. Each
        # entry is either {"role": "user", "text": ...} or
        # {"role": "assistant", "kind": "say"|"action", ...}. We prepend
        # a compacted form to the next task so the model can answer
        # "we talked about it earlier" without losing context.
        convo_log: list[dict] = [{"role": "user", "text": initial_task}]
        last_say_text: Optional[str] = None  # captured from action events

        async def on_step(ev: dict) -> None:
            ev2 = {"type": "agent.event", "session_id": handle.meta.id, **ev}
            try: handle.queue.put_nowait(ev2)
            except Exception: pass
            for q in list(handle.listeners):
                try: q.put_nowait(ev2)
                except Exception: pass
            handle.meta.event_count += 1
            handle.meta.last_event_at_ms = int(time.time() * 1000)
            if handle.recorder:
                try: handle.recorder.offer(ev2)
                except Exception: pass
            # Capture each assistant action so the convo log is
            # complete across `say` exits.
            if ev.get("event") == "action":
                act = ev.get("action") or {}
                a = str(act.get("action", "")).lower()
                if a == "say":
                    text = act.get("text") or (act.get("args") or {}).get("text") or ""
                    if text:
                        convo_log.append({"role": "assistant",
                                          "kind": "say", "text": text})
                elif a not in ("done", ""):
                    args_str = json.dumps(act.get("args", {}))[:160]
                    convo_log.append({"role": "assistant", "kind": "action",
                                      "summary": f"{a}({args_str})"})
            # Capture meaningful results so follow-up turns ("what were
            # the results?") have actual data to reference instead of
            # hallucinating task ids. Truncated; kind-aware.
            elif ev.get("event") == "step_done":
                res = ev.get("result") or {}
                if not isinstance(res, dict):
                    pass
                else:
                    snippet = ""
                    if "stdout" in res and res.get("stdout"):
                        snippet = f"stdout:\n{str(res['stdout'])[:1200]}"
                        if res.get("stderr"):
                            snippet += f"\nstderr:\n{str(res['stderr'])[:300]}"
                    elif "content" in res and res.get("content"):
                        snippet = f"file content (truncated):\n{str(res['content'])[:1200]}"
                    elif "matches" in res and res.get("matches"):
                        snippet = f"matches:\n{str(res['matches'])[:800]}"
                    elif "paths" in res and res.get("paths"):
                        snippet = f"paths: {str(res['paths'])[:600]}"
                    elif "text" in res and res.get("text"):
                        snippet = f"web text:\n{str(res['text'])[:800]}"
                    elif res.get("error"):
                        snippet = f"error: {str(res['error'])[:400]}"
                    if snippet:
                        convo_log.append({"role": "assistant",
                                          "kind": "result",
                                          "text": snippet})
            while handle.user_messages and not handle.user_messages.empty():
                msg = await handle.user_messages.get()
                directives_buf.append(msg)
                drect_ev = {"type": "user.directive", "text": msg,
                            "session_id": handle.meta.id}
                for q in list(handle.listeners):
                    try: q.put_nowait(drect_ev)
                    except Exception: pass

        def _format_convo() -> str:
            if len(convo_log) <= 1:
                return ""
            lines = []
            for e in convo_log[:-1]:  # exclude current task -- it's appended below
                if e["role"] == "user":
                    lines.append(f"USER: {e['text']}")
                elif e.get("kind") == "say":
                    lines.append(f"ASSISTANT (said): {e['text']}")
                elif e.get("kind") == "result":
                    lines.append(f"RESULT: {e['text']}")
                else:
                    lines.append(f"ASSISTANT (did): {e['summary']}")
            return "\n".join(lines)

        def build_task() -> str:
            convo = _format_convo()
            current = directives_buf[-1] if directives_buf else initial_task
            parts = []
            if convo:
                parts.append("PRIOR CONVERSATION (this session, oldest first):")
                parts.append(convo)
                parts.append("")
            parts.append(f"CURRENT USER MESSAGE: {current}")
            if len(directives_buf) > 1:
                joined = "\n".join(f"- {d}" for d in directives_buf[:-1])
                parts.append(f"\nADDITIONAL MID-FLIGHT DIRECTIVES:\n{joined}")
            return "\n".join(parts)

        # ---- approval_async: gated actions await user 'y'/'n'/'a' ----
        async def approval_async(action: dict) -> str:
            """Block on user_messages for an approval verdict. Returns
            'y'/'n'/'a'. Times out to 'n' after 5 minutes."""
            try:
                msg = await asyncio.wait_for(
                    handle.user_messages.get(), timeout=300.0)
            except asyncio.TimeoutError:
                return "n"
            verdict = (msg or "").strip().lower()
            # Map common forms
            if verdict in ("y", "yes", "ok", "approve", "accept", "1"):
                return "y"
            if verdict in ("a", "all", "yes-all", "accept-all", "yolo"):
                return "a"
            if verdict in ("n", "no", "deny", "reject", "cancel", "0"):
                return "n"
            # Anything else: treat as denial AND requeue the message so
            # the chat-steering directive isn't lost.
            try:
                handle.user_messages.put_nowait(msg)
            except Exception:
                pass
            return "n"

        # ---- NERUVA.md per-project auto-load + Agent Skills index ----
        # NERUVA.md: full content prepended (per-project conventions).
        # Skills: just the {name: summary} index; full body loaded
        # on demand via load_skill({name}) action.
        project_md_preamble = ""
        try:
            if cwd:
                md = Path(cwd) / "NERUVA.md"
                if md.exists() and md.stat().st_size < 32_000:
                    project_md_preamble = md.read_text(encoding="utf-8",
                                                       errors="replace")[:32_000]
        except Exception:
            project_md_preamble = ""

        try:
            from ._skills import skills_preamble
            skills_idx = skills_preamble(cwd)
        except Exception:
            skills_idx = ""

        original_build = build_task

        def build_task_with_md() -> str:
            base = original_build()
            preamble_parts = []
            if project_md_preamble:
                preamble_parts.append(
                    f"PROJECT CONVENTIONS (NERUVA.md):\n"
                    f"{project_md_preamble}\n--- END CONVENTIONS ---")
            if skills_idx:
                preamble_parts.append(skills_idx)
            if not preamble_parts:
                return base
            return "\n\n".join(preamble_parts) + "\n\n" + base

        # Continuous session: keep alive between tasks. Each new chat
        # message becomes the next task; convo_log + substrate memory +
        # plan cache span all tasks in the session.
        try:
            while not handle.abort_flag:
                result = await run_code_task(
                    build_task_with_md, namespace=namespace,
                    cwd=cwd, neruva_api_key=nv_key, max_steps=max_steps,
                    on_step=on_step, approval_async=approval_async,
                )
                for q in list(handle.listeners):
                    try: q.put_nowait({"type": "session.result", **result,
                                       "session_id": handle.meta.id})
                    except Exception: pass
                next_msg = await handle.user_messages.get()
                if handle.abort_flag or not next_msg:
                    break
                directives_buf.clear()
                initial_task = next_msg
                convo_log.append({"role": "user", "text": next_msg})
                # NOTE: send_input() already broadcasts user.input. Don't
                # re-emit here or the Cockpit shows the message twice.
        except asyncio.CancelledError:
            for q in list(handle.listeners):
                try: q.put_nowait({"type": "session.aborted",
                                   "session_id": handle.meta.id})
                except Exception: pass
            raise
        except Exception as e:
            for q in list(handle.listeners):
                try: q.put_nowait({"type": "session.error",
                                   "session_id": handle.meta.id,
                                   "error": f"{type(e).__name__}: {e}"})
                except Exception: pass
        finally:
            handle.meta.status = "stopped"
            handle.meta.duration_ms = (int(time.time() * 1000)
                                       - handle.meta.started_at_ms)

    async def _run_computer_agent(
        self,
        handle: _SessionHandle,
        initial_task: str,
        namespace: str,
        nv_key: Optional[str],
        max_steps: int,
    ) -> None:
        """Drive _agent.run_task with mid-flight user-message injection.

        Between each agent turn we drain handle.user_messages and append
        any pending directives to the task context so the model sees
        them in the very next prompt."""
        from ._agent import run_task

        # Immediate signal so the UI shows "starting..." while we wait
        # for the first screenshot + vendor call.
        starting_ev = {"type": "agent.event", "event": "session_starting",
                       "session_id": handle.meta.id}
        for q in list(handle.listeners):
            try: q.put_nowait(starting_ev)
            except Exception: pass

        directives_buf: list[str] = []
        # Conversation log spanning all chat turns in this session, so
        # "run that simulation we just discussed" has context. Same
        # pattern as the Code agent loop.
        convo_log: list[dict] = [{"role": "user", "text": initial_task}]

        async def on_step(ev: dict) -> None:
            """Fan agent events to listeners + the ring buffer + recorder."""
            ev2 = {"type": "agent.event", "session_id": handle.meta.id, **ev}
            try: handle.queue.put_nowait(ev2)
            except Exception: pass
            for q in list(handle.listeners):
                try: q.put_nowait(ev2)
                except Exception: pass
            handle.meta.event_count += 1
            handle.meta.last_event_at_ms = int(time.time() * 1000)
            if handle.recorder:
                try: handle.recorder.offer(ev2)
                except Exception: pass
            # Capture assistant actions for the convo log so cross-turn
            # context persists through `say` exits.
            if ev.get("event") == "action":
                act = ev.get("action") or {}
                a = str(act.get("action", "")).lower()
                if a == "say":
                    text = act.get("text") or (act.get("args") or {}).get("text") or ""
                    if text:
                        convo_log.append({"role": "assistant",
                                          "kind": "say", "text": text})
                elif a not in ("done", ""):
                    args_str = json.dumps(act.get("args", {}))[:160]
                    convo_log.append({"role": "assistant", "kind": "action",
                                      "summary": f"{a}({args_str})"})
            elif ev.get("event") == "step_done":
                # Result snippet so "what happened?" follow-ups have data.
                res = ev.get("result") or {}
                if isinstance(res, dict):
                    snippet = ""
                    if res.get("error"):
                        snippet = f"error: {str(res['error'])[:300]}"
                    elif res.get("waited_ms"):
                        snippet = f"waited {res['waited_ms']}ms"
                    elif res.get("scrolled"):
                        snippet = f"scrolled {res['scrolled']}"
                    if snippet:
                        convo_log.append({"role": "assistant",
                                          "kind": "result", "text": snippet})
            # Pull pending user directives between agent turns.
            while handle.user_messages and not handle.user_messages.empty():
                msg = await handle.user_messages.get()
                directives_buf.append(msg)
                drect_ev = {"type": "user.directive", "text": msg,
                            "session_id": handle.meta.id}
                for q in list(handle.listeners):
                    try: q.put_nowait(drect_ev)
                    except Exception: pass

        def _format_convo() -> str:
            if len(convo_log) <= 1:
                return ""
            lines = []
            for e in convo_log[:-1]:
                if e["role"] == "user":
                    lines.append(f"USER: {e['text']}")
                elif e.get("kind") == "say":
                    lines.append(f"ASSISTANT (said): {e['text']}")
                else:
                    lines.append(f"ASSISTANT (did): {e['summary']}")
            return "\n".join(lines)

        def build_task() -> str:
            convo = _format_convo()
            current = directives_buf[-1] if directives_buf else initial_task
            parts = []
            if convo:
                parts.append("PRIOR CONVERSATION (this session, oldest first):")
                parts.append(convo)
                parts.append("")
            parts.append(f"CURRENT USER MESSAGE: {current}")
            if len(directives_buf) > 1:
                joined = "\n".join(f"- {d}" for d in directives_buf[:-1])
                parts.append(f"\nADDITIONAL MID-FLIGHT DIRECTIVES:\n{joined}")
            return "\n".join(parts)

        # Continuous session: after each task completes, wait for the
        # next chat message and treat it as the next task. Session stays
        # "running" until explicitly stopped or aborted.
        try:
            while not handle.abort_flag:
                result = await run_task(
                    build_task, namespace=namespace,
                    neruva_api_key=nv_key, max_steps=max_steps,
                    on_step=on_step,
                )
                for q in list(handle.listeners):
                    try: q.put_nowait({"type": "session.result", **result,
                                       "session_id": handle.meta.id})
                    except Exception: pass
                next_msg = await handle.user_messages.get()
                if handle.abort_flag or not next_msg:
                    break
                directives_buf.clear()
                initial_task = next_msg
                convo_log.append({"role": "user", "text": next_msg})
                # NOTE: send_input() already broadcasts user.input. Don't
                # re-emit here or the Cockpit shows the message twice.
        except asyncio.CancelledError:
            for q in list(handle.listeners):
                try: q.put_nowait({"type": "session.aborted",
                                   "session_id": handle.meta.id})
                except Exception: pass
            raise
        except Exception as e:
            for q in list(handle.listeners):
                try: q.put_nowait({"type": "session.error",
                                   "session_id": handle.meta.id,
                                   "error": f"{type(e).__name__}: {e}"})
                except Exception: pass
        finally:
            handle.meta.status = "stopped"
            handle.meta.duration_ms = (int(time.time() * 1000)
                                       - handle.meta.started_at_ms)

    async def _write_user_message(self, handle: _SessionHandle, text: str) -> None:
        """Send a user-turn message in Claude Code's stream-json input shape."""
        envelope = json.dumps({
            "type": "user",
            "message": {"role": "user", "content": text},
        })
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(
            None,
            lambda: (handle.proc.stdin.write(envelope + "\n"), handle.proc.stdin.flush()),
        )

    async def send_input(self, session_id: str, text: str) -> None:
        h = self._sessions.get(session_id)
        if not h:
            raise KeyError(session_id)
        # Neruva Code + Neruva Computer: push to mid-flight chat-steering
        # queue. The agent loop drains this between turns and appends to
        # the next prompt.
        if h.meta.agent_type in ("computer", "code"):
            if h.meta.status != "running" or h.user_messages is None:
                raise RuntimeError(f"{h.meta.agent_type} session {session_id} not running")
            await h.user_messages.put(text)
        # Claude Code legacy: write to subprocess stdin.
        else:
            if h.proc is None or h.proc.poll() is not None:
                raise RuntimeError(f"session {session_id} is not running")
            if not h.proc.stdin:
                raise RuntimeError("session has no stdin")
            await self._write_user_message(h, text)
        # Broadcast a synthetic "user.input" event so every device viewing
        # this session sees the prompt land -- not just the device that
        # typed it. Push into the history ring AND fan-out to live listeners.
        ev = {
            "type": "user.input",
            "session_id": session_id,
            "text": text,
            "ts_ms": int(time.time() * 1000),
        }
        try: h.queue.put_nowait(ev)
        except Exception: pass
        for q in list(h.listeners):
            try: q.put_nowait(ev)
            except Exception: pass

    async def stop(self, session_id: str) -> None:
        h = self._sessions.pop(session_id, None)
        if not h:
            return
        h.meta.duration_ms = int(time.time() * 1000) - h.meta.started_at_ms
        # Auto-archive: post one final session_summary record so the
        # substrate has a single queryable entry capturing this session.
        if h.recorder:
            try:
                h.recorder.offer({
                    "type": "session_summary_synth",  # synthetic; consumed by recorder._classify
                    "session_id": h.meta.id,
                    "claude_session_id": h.meta.claude_session_id,
                    "project": h.meta.project,
                    "project_id": h.meta.project_id,
                    "duration_ms": h.meta.duration_ms,
                    "event_count": h.meta.event_count,
                    "ended_via": "user_stop",
                })
            except Exception: pass
        if h.reader_task:
            h.reader_task.cancel()
        # Computer-agent: set abort flag + cancel task.
        if h.meta.agent_type == "computer":
            h.abort_flag = True
            if h.agent_task:
                h.agent_task.cancel()
        # Code-agent: terminate subprocess.
        elif h.proc is not None:
            try:
                h.proc.terminate()
                await asyncio.get_running_loop().run_in_executor(None, lambda: h.proc.wait(timeout=5))
            except Exception:
                try:
                    h.proc.kill()
                except Exception:
                    pass
        if h.recorder:
            try: await h.recorder.stop()
            except Exception: pass
        h.meta.status = "stopped"
        # Flush a final marker to listeners
        for q in list(h.listeners):
            try:
                q.put_nowait({"type": "session.stopped", "session_id": session_id})
            except Exception:
                pass

    def subscribe(self, session_id: str) -> Optional[asyncio.Queue]:
        """Return a fresh queue receiving future events for this session.
        Each WS client gets its own queue. None if session unknown."""
        h = self._sessions.get(session_id)
        if not h:
            return None
        q: asyncio.Queue = asyncio.Queue(maxsize=self.EVENT_RING)
        h.listeners.add(q)
        return q

    def unsubscribe(self, session_id: str, queue: asyncio.Queue) -> None:
        h = self._sessions.get(session_id)
        if h:
            h.listeners.discard(queue)

    async def _reader(self, handle: _SessionHandle) -> None:
        """Background task. Reads subprocess stdout line-by-line, parses
        each as JSON, fans out to listeners + saves to history queue."""
        loop = asyncio.get_running_loop()
        try:
            while True:
                line = await loop.run_in_executor(None, handle.proc.stdout.readline)
                if not line:
                    # EOF -- subprocess exited
                    break
                line = line.rstrip("\n")
                if not line:
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    # Not JSON -- wrap as raw text so browser still sees something
                    event = {"type": "raw", "text": line}
                handle.meta.event_count += 1
                handle.meta.last_event_at_ms = int(time.time() * 1000)
                # Capture claude's internal session_id from system/init so
                # we can later resume via --resume <id>
                if (
                    not handle.meta.claude_session_id
                    and isinstance(event, dict)
                    and event.get("type") == "system"
                    and event.get("subtype") == "init"
                    and isinstance(event.get("session_id"), str)
                ):
                    handle.meta.claude_session_id = event["session_id"]
                # Auto-record into Neruva substrate (no-op if no API key)
                if handle.recorder:
                    try: handle.recorder.offer(event)
                    except Exception: pass
                # History buffer (drop oldest if full)
                if handle.queue.full():
                    try: handle.queue.get_nowait()
                    except Exception: pass
                try: handle.queue.put_nowait(event)
                except Exception: pass
                # Fan-out to live listeners
                for q in list(handle.listeners):
                    try: q.put_nowait(event)
                    except asyncio.QueueFull: pass
        except asyncio.CancelledError:
            return
        except Exception as e:
            for q in list(handle.listeners):
                try: q.put_nowait({"type": "reader.error", "detail": str(e)})
                except Exception: pass
        finally:
            rc = handle.proc.poll()
            handle.meta.status = "stopped" if rc == 0 else "crashed"
            for q in list(handle.listeners):
                try: q.put_nowait({"type": "session.exit", "returncode": rc})
                except Exception: pass

    async def history(self, session_id: str) -> list[dict[str, Any]]:
        """Snapshot of recent events for the session (for new WS clients
        that connect mid-stream and want to see context)."""
        h = self._sessions.get(session_id)
        if not h:
            return []
        # Drain without consuming -- just snapshot internal deque
        snapshot: list[dict[str, Any]] = []
        # asyncio.Queue doesn't expose its deque safely; we approximate
        # by getting + re-putting until empty.
        while not h.queue.empty():
            try:
                snapshot.append(h.queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        for e in snapshot:
            try: h.queue.put_nowait(e)
            except Exception: pass
        return snapshot
