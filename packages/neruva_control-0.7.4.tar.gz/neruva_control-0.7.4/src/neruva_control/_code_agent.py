"""Neruva Code agent loop: file/bash/edit executor + substrate plan
caching + memory enrichment + chat-steering.

The action model itself runs server-side at api.neruva.io. The daemon
sends task + history to /v1/agent/code/step and gets back the next
action JSON. Vendor identity is fully server-side (trade-secret IP);
the daemon only knows "Neruva Code."

Flow:
  0. Pre-task: substrate /v1/agent/context for past relevant records
     (memory enrichment, prepended to first prompt).
  1. Look up cached plan via substrate plan_cache_lookup.
  2. If hit (score >= 0.85, success_rate >= 0.8) -> replay cached plan.
  3. Else: substrate /code/step -> execute action -> repeat until
     'done' or max_steps. Per-action safety check against past
     mistake_learn records.
  4. Save plan to substrate plan_cache_save for next time.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any, Awaitable, Callable, Optional

import httpx

from ._memory_enrichment import (
    enrich_task_with_memory,
    check_action_safety,
    compose_enriched_task,
)


NERUVA_BASE_URL = os.environ.get("NERUVA_URL", "https://api.neruva.io")

# Defaults
_DEFAULT_MAX_STEPS = 20
_DEFAULT_INTER_STEP_SLEEP_S = 0.2
_DEFAULT_STEP_TIMEOUT_S = 90.0
_DEFAULT_SUBSTRATE_TIMEOUT_S = 10.0
_DEFAULT_BASH_TIMEOUT_S = 30.0
_CACHE_SCORE_THRESHOLD = 0.85
_CACHE_SUCCESS_RATE_THRESHOLD = 0.8

# Background bash output buffers, keyed by task_id. Survives across
# steps inside one daemon process so the model can read_background
# later. Capped to ~2000 lines per task.
_BG_OUTPUTS: dict[str, dict] = {}

# Actions that REQUIRE user approval before execution. Daemon emits
# `pending_approval` and waits on user_messages for 'y'/'n'/'a'.
_GATED_ACTIONS = {"write_file", "edit_file"}

# Bash patterns that are gated (force approval) on top of the
# always-blocked _BLOCKED_BASH_PATTERNS below.
_GATED_BASH_PATTERNS = [
    re.compile(r"\bgit\s+push\b"),
    re.compile(r"\bgit\s+reset\s+--hard\b"),
    re.compile(r"\bgit\s+clean\s+-[a-z]*f"),
    re.compile(r"\bnpm\s+publish\b"),
    re.compile(r"\btwine\s+upload\b"),
    re.compile(r"\bgcloud\s+(?:run|builds)\s+deploy\b"),
    re.compile(r"\brm\s+-[a-z]*r"),
    re.compile(r"\bsudo\b"),
    re.compile(r"\bcurl\b.*\|\s*(?:bash|sh)"),
]

# Bash safety: block obvious destructive patterns. Not exhaustive; MVP
# guard only. A determined model could still cause damage.
_BLOCKED_BASH_PATTERNS = [
    re.compile(r"\brm\s+-rf?\s+/(?!tmp|var/tmp)", re.IGNORECASE),
    re.compile(r"\bsudo\b", re.IGNORECASE),
    re.compile(r"\bmkfs\b", re.IGNORECASE),
    re.compile(r"\bdd\s+if=", re.IGNORECASE),
    re.compile(r"\bshutdown\b", re.IGNORECASE),
    re.compile(r"\breboot\b", re.IGNORECASE),
    re.compile(r":\(\)\s*\{[^}]*:\|:[^;]*;\s*\}\s*;\s*:", re.IGNORECASE),
    re.compile(r">\s*/dev/sd[a-z]", re.IGNORECASE),
]


# ---------------------------------------------------------------------------
# Model call (substrate proxy)
# ---------------------------------------------------------------------------

def pick_action(
    task_text: str,
    history: list[dict],
    *,
    cwd: Optional[str] = None,
    timeout: float = _DEFAULT_STEP_TIMEOUT_S,
    neruva_api_key: Optional[str] = None,
) -> dict:
    """Ask the Neruva Code action model for ONE next action via the
    substrate proxy. Daemon needs only NERUVA_API_KEY; vendor identity
    stays server-side.

    Returns the parsed JSON action dict. Raises on transport failure
    -- caller decides whether to abort the task."""
    api_key = neruva_api_key or os.environ.get("NERUVA_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError(
            "NERUVA_API_KEY not configured. Get one at "
            "https://app.neruva.io and put it in ~/.config/neruva/.env."
        )
    # Use the shared retry helper so transient Cloud Run edge 429s
    # (cold start / autoscale burst) don't kill the very first step.
    r = _substrate_post_retry(
        f"{NERUVA_BASE_URL}/v1/agent/code/step",
        {
            "task_text": task_text,
            "history": history[-6:] if history else [],
            "cwd": cwd or os.getcwd(),
        },
        api_key,
        timeout=timeout,
    )
    if r is None:
        raise RuntimeError("substrate unreachable after retries")
    r.raise_for_status()
    return r.json().get("action") or {}


# Back-compat alias.
devstral_pick_action = pick_action


# ---------------------------------------------------------------------------
# Action executor (unchanged - all file/bash ops happen locally)
# ---------------------------------------------------------------------------

def _pick(action: dict, key: str, default=None):
    if key in action:
        return action[key]
    args = action.get("args") or {}
    return args.get(key, default)


def _resolve_path(p: str, cwd: Optional[str]) -> Path:
    path = Path(p).expanduser()
    if not path.is_absolute() and cwd:
        path = (Path(cwd) / path).resolve()
    else:
        path = path.resolve()
    return path


def execute_code_action(action: dict, cwd: Optional[str] = None) -> dict:
    """Run one Neruva Code action. Returns {ok, ...} or {ok: False, error}."""
    a = str(action.get("action", "")).lower()
    try:
        if a == "read_file":
            p = _resolve_path(_pick(action, "path", ""), cwd)
            if not p.exists():
                return {"ok": False, "error": f"file not found: {p}"}
            try:
                text = p.read_text(encoding="utf-8", errors="replace")
            except Exception as e:
                return {"ok": False, "error": f"read failed: {e}"}
            return {"ok": True, "content": text[:5000],
                    "n_bytes": len(text), "path": str(p)}

        if a == "write_file":
            p = _resolve_path(_pick(action, "path", ""), cwd)
            content = str(_pick(action, "content", ""))
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding="utf-8")
            return {"ok": True, "wrote_bytes": len(content), "path": str(p)}

        if a == "edit_file":
            p = _resolve_path(_pick(action, "path", ""), cwd)
            if not p.exists():
                return {"ok": False, "error": f"file not found: {p}"}
            old = str(_pick(action, "old", ""))
            new = str(_pick(action, "new", ""))
            text = p.read_text(encoding="utf-8", errors="replace")
            n_occurrences = text.count(old)
            if n_occurrences == 0:
                return {"ok": False,
                        "error": f"old string not found in {p}"}
            if n_occurrences > 1:
                return {"ok": False,
                        "error": (f"old string matches {n_occurrences} "
                                  f"places in {p}; needs more context")}
            text2 = text.replace(old, new)
            p.write_text(text2, encoding="utf-8")
            return {"ok": True, "edited": str(p), "delta_bytes": len(text2) - len(text)}

        if a in ("search_files", "grep"):
            pattern = str(_pick(action, "pattern", ""))
            output_mode = str(_pick(action, "output_mode", "files")).lower()
            glob_filter = str(_pick(action, "glob", "")).strip()
            search_dir = _resolve_path(_pick(action, "dir", "."), cwd)
            if not search_dir.exists():
                return {"ok": False, "error": f"dir not found: {search_dir}"}
            rg = shutil.which("rg")
            mode_args = []
            if output_mode == "files":
                mode_args = ["-l"]
            elif output_mode == "count":
                mode_args = ["-c"]
            else:  # content
                mode_args = ["-n", "--max-count", "20"]
            if rg:
                cmd = [rg, *mode_args, "--max-filesize", "1M", "--no-heading"]
                if glob_filter:
                    cmd += ["--glob", glob_filter]
                cmd += [pattern, str(search_dir)]
            else:
                grep_flags = "-rn" if output_mode == "content" else (
                    "-rl" if output_mode == "files" else "-rc")
                cmd = ["grep", grep_flags, "--max-count", "20", pattern,
                       str(search_dir)]
            try:
                proc = subprocess.run(
                    cmd, capture_output=True, text=True,
                    timeout=15, check=False,
                )
                out = (proc.stdout or "")[:3000]
                return {"ok": True, "matches": out,
                        "output_mode": output_mode,
                        "n_lines": out.count("\n")}
            except subprocess.TimeoutExpired:
                return {"ok": False, "error": "search timeout"}

        if a == "glob":
            pattern = str(_pick(action, "pattern", "")).strip()
            if not pattern:
                return {"ok": False, "error": "glob pattern required"}
            base = _resolve_path(_pick(action, "dir", "."), cwd)
            if not base.exists():
                return {"ok": False, "error": f"dir not found: {base}"}
            try:
                paths = sorted(str(p) for p in base.glob(pattern))[:200]
            except Exception as e:
                return {"ok": False, "error": f"glob failed: {e}"}
            return {"ok": True, "n_matches": len(paths),
                    "paths": paths, "truncated": len(paths) >= 200}

        if a == "web_fetch":
            url = str(_pick(action, "url", "")).strip()
            if not url:
                return {"ok": False, "error": "url required"}
            if not (url.startswith("http://") or url.startswith("https://")):
                return {"ok": False, "error": "url must be http(s)"}
            try:
                with httpx.Client(timeout=15.0, follow_redirects=True) as cli:
                    r = cli.get(url, headers={"User-Agent":
                                              "neruva-control/0.4 (+https://neruva.io)"})
                ct = r.headers.get("content-type", "")
                text = r.text
                # Crude HTML strip: keep text content only
                if "html" in ct.lower():
                    text = re.sub(r"(?is)<script.*?</script>", "", text)
                    text = re.sub(r"(?is)<style.*?</style>", "", text)
                    text = re.sub(r"(?s)<[^>]+>", " ", text)
                    text = re.sub(r"\s+", " ", text).strip()
                return {"ok": True, "url": url, "status": r.status_code,
                        "content_type": ct, "text": text[:5000],
                        "truncated": len(text) > 5000}
            except Exception as e:
                return {"ok": False, "error": f"fetch failed: {e}"}

        if a == "todo_write":
            items = _pick(action, "items", []) or []
            if not isinstance(items, list):
                return {"ok": False, "error": "items must be a list"}
            # Daemon caches via the on_step event; the executor just
            # confirms shape and echoes back the normalized list.
            norm = []
            for i, it in enumerate(items):
                if not isinstance(it, dict): continue
                norm.append({
                    "id": str(it.get("id") or f"t{i}"),
                    "content": str(it.get("content") or "").strip(),
                    "status": str(it.get("status") or "pending").lower(),
                })
            return {"ok": True, "items": norm, "n": len(norm)}

        if a == "read_background":
            task_id = str(_pick(action, "task_id", "")).strip()
            tail = int(_pick(action, "tail_lines", 50))
            buf = _BG_OUTPUTS.get(task_id)
            if buf is None:
                return {"ok": False, "error": f"unknown background task_id: {task_id}"}
            lines = buf.get("lines", [])
            return {"ok": True, "task_id": task_id,
                    "running": buf.get("running", False),
                    "returncode": buf.get("returncode"),
                    "tail": "\n".join(lines[-tail:])}

        if a == "load_skill":
            from ._skills import load_skill
            name = str(_pick(action, "name", "")).strip()
            if not name:
                return {"ok": False, "error": "skill name required"}
            body = load_skill(name, cwd=cwd)
            if body is None:
                return {"ok": False,
                        "error": f"skill not found: {name!r}. Check ~/.config/neruva/skills/ or <project>/.neruva/skills/"}
            return {"ok": True, "name": name, "body": body[:8000],
                    "n_chars": len(body)}

        if a == "repo_map":
            from ._repo_map import build_repo_map
            base = _resolve_path(_pick(action, "dir", "."), cwd)
            max_files = int(_pick(action, "max_files", 60))
            if not base.exists():
                return {"ok": False, "error": f"dir not found: {base}"}
            try:
                summary, stats = build_repo_map(str(base), max_files=max_files)
            except Exception as e:
                return {"ok": False, "error": f"repo_map failed: {e}"}
            return {"ok": True, "summary": summary[:8000],
                    "n_files": stats.get("n_files", 0),
                    "n_symbols": stats.get("n_symbols", 0),
                    "truncated": stats.get("truncated", False)}

        if a == "lsp_diagnostics":
            from ._lsp import lsp_diagnostics
            path = _pick(action, "path", "") or _pick(action, "file", "")
            p = _resolve_path(str(path), cwd)
            return lsp_diagnostics(str(p), project_root=str(cwd) if cwd else None)

        if a == "lsp_hover":
            from ._lsp import lsp_hover
            path = _pick(action, "path", "") or _pick(action, "file", "")
            p = _resolve_path(str(path), cwd)
            return lsp_hover(str(p),
                             int(_pick(action, "line", 1)),
                             int(_pick(action, "col", 1)),
                             project_root=str(cwd) if cwd else None)

        if a in ("lsp_goto_definition", "lsp_definition"):
            from ._lsp import lsp_goto_definition
            path = _pick(action, "path", "") or _pick(action, "file", "")
            p = _resolve_path(str(path), cwd)
            return lsp_goto_definition(str(p),
                                       int(_pick(action, "line", 1)),
                                       int(_pick(action, "col", 1)),
                                       project_root=str(cwd) if cwd else None)

        if a in ("lsp_find_references", "lsp_references"):
            from ._lsp import lsp_find_references
            path = _pick(action, "path", "") or _pick(action, "file", "")
            p = _resolve_path(str(path), cwd)
            return lsp_find_references(str(p),
                                       int(_pick(action, "line", 1)),
                                       int(_pick(action, "col", 1)),
                                       project_root=str(cwd) if cwd else None)

        if a == "lsp_workspace_symbol":
            from ._lsp import lsp_workspace_symbol
            return lsp_workspace_symbol(
                str(_pick(action, "query", "")),
                project_root=str(cwd or os.getcwd()),
                lang=str(_pick(action, "lang", "python")),
            )

        if a == "lsp_status":
            from ._lsp import lsp_status
            return lsp_status()

        if a == "tool_describe":
            from ._tool_catalog import describe
            name = str(_pick(action, "name", "")).strip()
            if not name:
                return {"ok": False, "error": "name required"}
            meta = describe("code", name)
            if not meta:
                return {"ok": False, "error": f"unknown tool: {name!r}"}
            return {"ok": True, "name": name,
                    "summary": meta["summary"], "schema": meta["schema"]}

        if a == "browser":
            from ._browser import browser_action
            verb = str(_pick(action, "verb", "")).strip() or \
                   str(_pick(action, "command", "")).strip()
            args = _pick(action, "args", {}) or {}
            # Tolerate flat shape: {action: 'browser', open: {...}}
            if not verb:
                for k in ("open", "navigate", "snapshot", "click", "fill",
                          "type", "press", "screenshot", "wait_for",
                          "content", "close"):
                    if k in action:
                        verb = k
                        if isinstance(action.get(k), dict):
                            args = action[k]
                        break
            return browser_action(verb, args if isinstance(args, dict) else {})

        if a == "index_project":
            from ._indexer import index_project
            base = _resolve_path(_pick(action, "path", "."), cwd)
            if not base.exists():
                return {"ok": False, "error": f"dir not found: {base}"}
            namespace = str(_pick(action, "namespace", "code_index"))
            max_files = int(_pick(action, "max_files", 500))
            try:
                stats = index_project(
                    str(base), namespace=namespace,
                    max_files=max_files, verbose=False,
                )
            except Exception as e:
                return {"ok": False, "error": f"index failed: {e}"}
            return {"ok": True, **stats,
                    "hint": ("Now call code_search({query, namespace}) to "
                             "find symbols semantically.")}

        if a == "code_search":
            from ._memory_enrichment import _post_quiet
            api_key = os.environ.get("NERUVA_API_KEY", "").strip()
            if not api_key:
                return {"ok": False, "error": "NERUVA_API_KEY required for code_search"}
            query = str(_pick(action, "query", "")).strip()
            if not query:
                return {"ok": False, "error": "query required"}
            ns = str(_pick(action, "namespace", "code_index"))
            top_k = int(_pick(action, "top_k", 8))
            data = _post_quiet(
                "/v1/records/" + ns + "/query",
                {"text": query, "topK": top_k,
                 "kind": ["code_chunk"], "includeText": True,
                 "includeMeta": True},
                api_key,
            )
            if data is None:
                return {"ok": False, "error": "substrate unreachable or namespace empty"}
            records = (data or {}).get("records") or []
            hits = []
            for r in records:
                meta = r.get("meta") or {}
                hits.append({
                    "path": meta.get("path", "?"),
                    "lang": meta.get("lang", "?"),
                    "lines": meta.get("lines", ""),
                    "score": r.get("score", 0.0),
                    "snippet": str(r.get("text", ""))[:600],
                })
            return {"ok": True, "n_hits": len(hits), "hits": hits,
                    "hint": ("If 0 hits, the project may not be indexed. "
                             "Run `neruva-control index <project_path>` first.")}

        if a == "run_bash":
            cmd = str(_pick(action, "command", ""))
            background = bool(_pick(action, "background", False))
            for pat in _BLOCKED_BASH_PATTERNS:
                if pat.search(cmd):
                    return {"ok": False,
                            "error": f"blocked: matches destructive pattern {pat.pattern!r}"}
            if background:
                # Long-running command. Spawn detached, capture output
                # into _BG_OUTPUTS keyed by task_id. Model retrieves via
                # read_background.
                import secrets as _secrets, threading as _threading
                task_id = "bg_" + _secrets.token_hex(4)
                _BG_OUTPUTS[task_id] = {"running": True, "returncode": None,
                                        "lines": [], "started_ms": int(time.time()*1000)}
                def _runner(c=cmd, t=task_id, w=cwd):
                    try:
                        p = subprocess.Popen(
                            c, shell=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, cwd=w,
                            bufsize=1,
                        )
                        if p.stdout:
                            for line in p.stdout:
                                buf = _BG_OUTPUTS.get(t)
                                if buf is None: break
                                buf["lines"].append(line.rstrip("\n"))
                                # cap memory
                                if len(buf["lines"]) > 2000:
                                    buf["lines"] = buf["lines"][-1500:]
                        p.wait()
                        if t in _BG_OUTPUTS:
                            _BG_OUTPUTS[t]["running"] = False
                            _BG_OUTPUTS[t]["returncode"] = p.returncode
                    except Exception as e:
                        if t in _BG_OUTPUTS:
                            _BG_OUTPUTS[t]["lines"].append(f"[runner error] {e}")
                            _BG_OUTPUTS[t]["running"] = False
                            _BG_OUTPUTS[t]["returncode"] = -1
                _threading.Thread(target=_runner, daemon=True).start()
                return {"ok": True, "task_id": task_id, "background": True,
                        "command": cmd[:120]}
            try:
                proc = subprocess.run(
                    cmd, shell=True, capture_output=True, text=True,
                    timeout=_DEFAULT_BASH_TIMEOUT_S, check=False,
                    cwd=cwd,
                )
                out = (proc.stdout or "")[:2000]
                err = (proc.stderr or "")[:1000]
                return {
                    "ok": proc.returncode == 0,
                    "returncode": proc.returncode,
                    "stdout": out,
                    "stderr": err,
                }
            except subprocess.TimeoutExpired:
                return {"ok": False, "error": f"bash timeout {_DEFAULT_BASH_TIMEOUT_S}s"}

        if a == "done":
            return {"ok": True, "done": True}

        if a == "say":
            text = str(_pick(action, "text", ""))
            return {"ok": True, "said": text}

        return {"ok": False, "error": f"unknown action: {a!r}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


# ---------------------------------------------------------------------------
# Substrate plan-cache helpers
# ---------------------------------------------------------------------------

def _substrate_post_retry(
    url: str, body: dict, api_key: str,
    *, max_attempts: int = 5, base_delay_s: float = 0.5,
    timeout: float = _DEFAULT_SUBSTRATE_TIMEOUT_S,
) -> Optional[httpx.Response]:
    """POST with exponential backoff on 429."""
    delay = base_delay_s
    last_r: Optional[httpx.Response] = None
    for attempt in range(max_attempts):
        try:
            with httpx.Client(timeout=timeout) as cli:
                r = cli.post(
                    url,
                    headers={"Api-Key": api_key,
                             "Content-Type": "application/json"},
                    json=body,
                )
            last_r = r
            if r.status_code != 429:
                return r
        except Exception:
            pass
        time.sleep(delay)
        delay = min(delay * 2, 8.0)
    return last_r


async def _emit(on_step: Optional[Callable[[dict], Awaitable[None]]],
                event: dict) -> None:
    if on_step is None:
        return
    try:
        await on_step(event)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Main task loop
# ---------------------------------------------------------------------------

async def run_task(
    task_text,
    namespace: str = "cockpit_code",
    *,
    cwd: Optional[str] = None,
    neruva_api_key: Optional[str] = None,
    max_steps: int = _DEFAULT_MAX_STEPS,
    on_step: Optional[Callable[[dict], Awaitable[None]]] = None,
    approval_async: Optional[Callable[[dict], Awaitable[str]]] = None,
    use_cache: bool = True,
    use_memory: bool = True,
    depth: int = 0,
) -> dict:
    """Run a Neruva Code task end-to-end via substrate proxy.

    `task_text` accepts a string OR a zero-arg callable returning a
    string (callable form enables chat-steering: re-read on each turn).

    `approval_async(action_dict) -> 'y'|'n'|'a'` -- if provided, gated
    actions (write_file, edit_file, risky bash) await this callback
    before executing. 'a' = accept-all for the rest of the task.

    Returns {ok, n_steps, duration_ms, used_cache, model_calls,
    plan_saved_to_substrate, memory_enriched, history, plan}.
    """
    nv_key = neruva_api_key or os.environ.get("NERUVA_API_KEY", "").strip()
    if not nv_key:
        return {"ok": False, "error": "NERUVA_API_KEY not configured",
                "n_steps": 0}

    if callable(task_text):
        get_task = task_text
        initial_task_str = task_text()
    else:
        initial_task_str = str(task_text)
        get_task = lambda: initial_task_str   # noqa: E731

    t0 = time.perf_counter()

    # ---- 0+1. Memory enrichment + plan-cache lookup IN PARALLEL ----
    # Both are substrate queries (~200ms warm, 2-4s cold). Running them
    # in threads with a tight wall-clock deadline cuts perceived spawn
    # time from 5-10s to <3s. If either misses the deadline, we proceed
    # without it -- enrichment is opportunistic, cache miss = live path.
    plan: list[dict] = []
    history: list[dict] = []
    plan_used_from_cache = False
    success = False
    model_calls = 0
    enrichment_preamble = ""
    accept_all_session = False   # flipped to True if user picks 'a' once

    import concurrent.futures
    _SPAWN_DEADLINE_S = 2.0
    enrich_fut = None
    cache_fut = None
    pool: Optional[concurrent.futures.ThreadPoolExecutor] = None
    if use_memory or use_cache:
        pool = concurrent.futures.ThreadPoolExecutor(max_workers=2)
        if use_memory:
            enrich_fut = pool.submit(
                enrich_task_with_memory,
                initial_task_str, namespace, nv_key,
            )
        if use_cache:
            cache_fut = pool.submit(
                _substrate_post_retry,
                f"{NERUVA_BASE_URL}/v1/agent/plan_cache_lookup",
                {"namespace": namespace, "task_text": initial_task_str,
                 "top_k": 1, "min_score": _CACHE_SCORE_THRESHOLD},
                nv_key,
            )
        # Wait at most _SPAWN_DEADLINE_S total for both.
        deadline = time.perf_counter() + _SPAWN_DEADLINE_S
        if enrich_fut:
            try:
                remaining = max(0.0, deadline - time.perf_counter())
                enrichment_preamble = enrich_fut.result(timeout=remaining) or ""
            except Exception:
                enrichment_preamble = ""
            if enrichment_preamble:
                await _emit(on_step, {
                    "event": "memory_enriched",
                    "preview": enrichment_preamble[:200],
                    "n_chars": len(enrichment_preamble),
                })
        if cache_fut:
            try:
                remaining = max(0.0, deadline - time.perf_counter())
                r = cache_fut.result(timeout=remaining)
            except Exception:
                r = None
            if r is not None and r.status_code == 200:
                hits = r.json().get("hits", [])
                if hits and hits[0]["success_rate"] >= _CACHE_SUCCESS_RATE_THRESHOLD:
                    plan = hits[0]["plan"]
                    plan_used_from_cache = True
                    await _emit(on_step, {
                        "event": "plan_cache_hit",
                        "n_steps": len(plan),
                        "score": hits[0]["score"],
                        "record_id": hits[0]["record_id"],
                    })
        # Don't wait for stragglers -- shutdown non-blocking.
        if pool:
            pool.shutdown(wait=False, cancel_futures=True)

    # ---- 2. Execute (cached or live) ----
    if plan_used_from_cache:
        for i, step in enumerate(plan):
            await _emit(on_step, {
                "event": "step_start", "i": i, "step": step,
                "source": "cache",
            })
            res = execute_code_action(step, cwd=cwd)
            history.append({"step": step, "result": res})
            await _emit(on_step, {
                "event": "step_done", "i": i, "result": res,
            })
            if not res.get("ok"):
                break
            await asyncio.sleep(_DEFAULT_INTER_STEP_SLEEP_S)
        success = all(h["result"].get("ok") for h in history)
    else:
        for i in range(max_steps):
            current_task = get_task()
            full_task = compose_enriched_task(current_task,
                                              enrichment_preamble)
            try:
                action = pick_action(full_task, history, cwd=cwd,
                                     neruva_api_key=nv_key)
                model_calls += 1
            except Exception as e:
                await _emit(on_step, {
                    "event": "model_error", "i": i,
                    "error": f"{type(e).__name__}: {e}",
                })
                break
            await _emit(on_step, {
                "event": "action", "i": i, "action": action,
                "source": "neruva-code",
            })
            action_type = str(action.get("action", "")).lower()
            if action_type == "done":
                # Refuse "done" at step 0 with no prior actions -- the
                # model is giving up before trying. Force one more turn
                # by adding a nudge to history; if it does it again, we
                # fail the task honestly rather than reporting ok=true.
                if i == 0 and not history:
                    history.append({
                        "step": {"action": "done", "reasoning": "premature"},
                        "result": {"ok": False, "error":
                            "you emitted 'done' at step 0 with no work "
                            "done. Pick a concrete first action."},
                    })
                    await _emit(on_step, {
                        "event": "premature_done",
                        "i": i,
                        "note": "model gave up at step 0; nudging it to act",
                    })
                    continue
                # Force a final `say` summary if the model is trying to
                # `done` without ever speaking to the user. The user
                # wants a chat-style recap of what was done, not a
                # silent 'task complete' event. We only nudge ONCE; if
                # the model insists on `done` again, accept it.
                already_summarized = any(
                    str((h.get("step") or {}).get("action", "")).lower() == "say"
                    for h in history
                )
                already_nudged = any(
                    "nudge:summary" == (h.get("step") or {}).get("reasoning", "")
                    for h in history
                )
                if history and not already_summarized and not already_nudged:
                    history.append({
                        "step": {"action": "done", "reasoning": "nudge:summary"},
                        "result": {"ok": False, "error":
                            "Before 'done', emit say({text}) with a 1-3 "
                            "sentence summary of WHAT YOU DID and key "
                            "results. The user is on a chat surface and "
                            "wants the recap."},
                    })
                    await _emit(on_step, {
                        "event": "summary_nudge",
                        "i": i,
                        "note": "model tried to done without summary; "
                                "nudging for a final say",
                    })
                    continue
                success = True
                break
            # ---- Subagent (recursive run_task with isolated context) ----
            # ---- Cross-agent delegation: Code -> Computer ----
            # Hand off a screen-control task to Neruva Computer. Depth-
            # limited; shares cwd + memory; child returns a compact
            # summary the Code agent can reason on.
            if action_type == "delegate":
                args = action.get("args") or {}
                to = str(args.get("to") or action.get("to") or "").lower()
                d_task = str(args.get("task") or action.get("task") or "").strip()
                d_max = int(args.get("max_steps") or action.get("max_steps") or 10)
                d_max = max(2, min(20, d_max))
                if depth >= 2:
                    d_res = {"ok": False, "error": "delegate depth limit (max 2)"}
                elif not d_task:
                    d_res = {"ok": False, "error": "delegate: task required"}
                elif to != "computer":
                    d_res = {"ok": False, "error":
                             f"delegate: 'to' must be 'computer' (got {to!r})"}
                else:
                    # Lazy-import to avoid top-level import of pyautogui on
                    # daemons that don't have the [agent] extra installed.
                    try:
                        from ._agent import run_task as run_computer_task
                    except Exception as e:
                        d_res = {"ok": False,
                                 "error": f"computer agent not available: {e}"}
                    else:
                        await _emit(on_step, {"event": "delegate_start",
                                              "i": i, "to": "computer",
                                              "task": d_task[:200],
                                              "max_steps": d_max,
                                              "depth": depth + 1})
                        try:
                            d_result = await run_computer_task(
                                d_task, namespace=namespace,
                                neruva_api_key=nv_key, max_steps=d_max,
                                on_step=on_step,
                            )
                        except Exception as e:
                            d_result = {"ok": False,
                                        "error": f"{type(e).__name__}: {e}",
                                        "n_steps": 0, "history": []}
                        # Compose summary from last `say` text or fallback.
                        d_history = d_result.get("history") or []
                        last_say = ""
                        for h in reversed(d_history):
                            step = h.get("step") or {}
                            if str(step.get("action", "")).lower() == "say":
                                last_say = str((step.get("text") or
                                                (step.get("args") or {}).get("text")
                                                or ""))[:400]
                                break
                        summary = (last_say or
                                   f"computer agent ran {d_result.get('n_steps', 0)} "
                                   f"step(s); ok={d_result.get('ok')}")
                        d_res = {"ok": bool(d_result.get("ok")),
                                 "delegated_to": "computer",
                                 "n_steps": d_result.get("n_steps", 0),
                                 "duration_ms": d_result.get("duration_ms", 0),
                                 "summary": summary}
                        await _emit(on_step, {"event": "delegate_done",
                                              "i": i, "to": "computer",
                                              "result": d_res})
                plan.append(action)
                history.append({"step": action, "result": d_res})
                await _emit(on_step, {"event": "step_done", "i": i,
                                      "result": d_res})
                await asyncio.sleep(_DEFAULT_INTER_STEP_SLEEP_S)
                continue

            # Depth-limited so the model can't infinite-spawn. The subagent
            # shares cwd + key but gets its own history + plan + memory
            # enrichment. We surface its summary back into the main loop's
            # history so the parent can reason about the result.
            if action_type == "subagent":
                if depth >= 2:
                    sub_res = {"ok": False, "error":
                        "subagent depth limit reached (max 2)"}
                    plan.append(action)
                    history.append({"step": action, "result": sub_res})
                    await _emit(on_step, {"event": "step_done",
                                          "i": i, "result": sub_res})
                    continue
                sub_task = str((action.get("args") or {}).get("task")
                               or action.get("task") or "").strip()
                if not sub_task:
                    sub_res = {"ok": False,
                               "error": "subagent: task required"}
                    plan.append(action)
                    history.append({"step": action, "result": sub_res})
                    await _emit(on_step, {"event": "step_done",
                                          "i": i, "result": sub_res})
                    continue
                sub_max = int((action.get("args") or {}).get("max_steps")
                              or action.get("max_steps") or 10)
                sub_max = max(2, min(20, sub_max))
                await _emit(on_step, {"event": "subagent_start",
                                      "i": i, "task": sub_task[:200],
                                      "max_steps": sub_max, "depth": depth + 1})
                sub_result = await run_task(
                    sub_task, namespace=namespace, cwd=cwd,
                    neruva_api_key=nv_key, max_steps=sub_max,
                    on_step=on_step, approval_async=approval_async,
                    use_cache=False, use_memory=False, depth=depth + 1,
                )
                # Compose a compact summary the parent can reason on.
                sub_history = sub_result.get("history") or []
                last_say = ""
                for h in reversed(sub_history):
                    step = h.get("step") or {}
                    if str(step.get("action", "")).lower() == "say":
                        last_say = str((step.get("text") or
                                        (step.get("args") or {}).get("text")
                                        or ""))[:400]
                        break
                summary = (last_say or
                           f"subagent ran {sub_result.get('n_steps', 0)} step(s); "
                           f"ok={sub_result.get('ok')}")
                sub_res = {"ok": bool(sub_result.get("ok")),
                           "n_steps": sub_result.get("n_steps", 0),
                           "duration_ms": sub_result.get("duration_ms", 0),
                           "summary": summary}
                plan.append(action)
                history.append({"step": action, "result": sub_res})
                await _emit(on_step, {"event": "subagent_done",
                                      "i": i, "result": sub_res,
                                      "depth": depth + 1})
                await _emit(on_step, {"event": "step_done",
                                      "i": i, "result": sub_res})
                await asyncio.sleep(_DEFAULT_INTER_STEP_SLEEP_S)
                continue

            # `say` is terminal for this turn: emit the message, complete the
            # task, hand control back to the session loop which waits for the
            # user's next input. Without this break, the model can spin in a
            # say-loop generating greeting after greeting.
            if action_type == "say":
                res = execute_code_action(action, cwd=cwd)
                plan.append(action)
                history.append({"step": action, "result": res})
                await _emit(on_step, {
                    "event": "step_done", "i": i, "result": res,
                })
                success = True
                break
            action_summary = (f"{action.get('action')}: "
                              f"{json.dumps(action.get('args', {}))[:200]}")
            if use_memory:
                hit = check_action_safety(action_summary, namespace, nv_key)
                if hit:
                    await _emit(on_step, {
                        "event": "safety_warning", "i": i,
                        "action": action,
                        "past_failure": {
                            "kind": hit.get("kind"),
                            "score": hit.get("score"),
                            "text": str(hit.get("text", ""))[:200],
                        },
                    })
            # ---- Accept-edits gating ----
            # Risky actions await user approval before execution. Once
            # the user picks 'a' (accept all), every subsequent gated
            # action in this task auto-approves.
            needs_approval = False
            why = ""
            if not accept_all_session and approval_async is not None:
                if action_type in _GATED_ACTIONS:
                    needs_approval = True
                    why = f"{action_type} (file)"
                elif action_type == "run_bash":
                    cmd_str = str((action.get("args") or {}).get("command")
                                  or action.get("command") or "")
                    for pat in _GATED_BASH_PATTERNS:
                        if pat.search(cmd_str):
                            needs_approval = True
                            why = f"bash matched gated pattern {pat.pattern!r}"
                            break
            if needs_approval:
                # Resolve relative paths server-side so the approval card
                # shows the FULL path -- users were asking "where is the
                # file being built?" Empty for run_bash; cwd echoed too.
                approval_meta: dict = {"cwd": str(cwd or os.getcwd())}
                if action_type in ("write_file", "edit_file"):
                    raw_path = (action.get("path")
                                or (action.get("args") or {}).get("path"))
                    if raw_path:
                        try:
                            approval_meta["resolved_path"] = str(
                                _resolve_path(str(raw_path), cwd))
                        except Exception:
                            approval_meta["resolved_path"] = str(raw_path)
                await _emit(on_step, {
                    "event": "pending_approval", "i": i,
                    "action": action, "why": why,
                    **approval_meta,
                })
                try:
                    answer = (await approval_async(action) or "").strip().lower()
                except Exception:
                    answer = "n"
                if answer in ("a", "all", "yes-all", "accept-all"):
                    accept_all_session = True
                    answer = "y"
                if answer not in ("y", "yes"):
                    res = {"ok": False, "error": "user denied approval",
                           "denied": True}
                    plan.append(action)
                    history.append({"step": action, "result": res})
                    await _emit(on_step, {
                        "event": "step_done", "i": i, "result": res,
                    })
                    # On denial, keep going so the model can pick a
                    # different action; don't fail the whole task.
                    await asyncio.sleep(_DEFAULT_INTER_STEP_SLEEP_S)
                    continue
            res = execute_code_action(action, cwd=cwd)
            plan.append(action)
            history.append({"step": action, "result": res})
            await _emit(on_step, {
                "event": "step_done", "i": i, "result": res,
            })
            if not res.get("ok"):
                break
            await asyncio.sleep(_DEFAULT_INTER_STEP_SLEEP_S)

    duration_ms = int((time.perf_counter() - t0) * 1000)

    # ---- 3. Save plan to substrate ----
    saved = False
    if not plan_used_from_cache and plan:
        r = _substrate_post_retry(
            f"{NERUVA_BASE_URL}/v1/agent/plan_cache_save",
            {"namespace": namespace, "task_text": initial_task_str,
             "plan": plan, "success": success, "duration_ms": duration_ms,
             "tags": ["neruva-code"]},
            nv_key,
        )
        saved = (r is not None and r.status_code == 200)

    final = {
        "ok": success,
        "n_steps": len(plan),
        "duration_ms": duration_ms,
        "used_cache": plan_used_from_cache,
        "model_calls": model_calls,
        "plan_saved_to_substrate": saved if not plan_used_from_cache else False,
        "memory_enriched": bool(enrichment_preamble),
        "history": history,
        "plan": plan,
    }
    await _emit(on_step, {"event": "task_complete", **final})
    return final
