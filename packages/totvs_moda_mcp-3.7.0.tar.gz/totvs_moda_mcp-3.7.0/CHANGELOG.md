# Changelog

## [3.7.0] - 2026-05-24

### Added
- Optional Analytics gateway with `totvs_analytics_call`, enabled only with `TOTVS_ENABLE_ANALYTICS=true`.
- Full Swagger path coverage in the endpoint harness: `251/251` endpoints mapped.
- Remaining non-Analytics endpoints mapped for General, Image, Seller, Product, Product Engineering, Purchase Order, Sales Order and Person.
- Contract tests for the new endpoints and the optional Analytics gateway.

### Changed
- `customer_360` now injects branch defaults in its internal sales-order search.
- `customer_360` now calculates first/last purchase dates by actual order date instead of trusting API order.
- Pending material consumption now validates required material/classification filters before calling the API.
- Documentation refreshed for endpoint coverage, testing status and optional Analytics behavior.

### Tests
- Test suite expanded to 202 tests.

## [3.6.0] - 2026-05-24

### Added
- Endpoint harness generated from local Swagger files with coverage matrix in `docs/API_ENDPOINT_MATRIX.md`.
- Agent endpoint harness guide in `docs/AGENT_ENDPOINT_HARNESS.md`.
- n8n/agent architecture proposal in `docs/N8N_AUTOMATION_ARCHITECTURE.md`.
- Product auxiliary read endpoints:
  - `totvs_get_product_additional_field_types`
  - `totvs_get_product_classification_types`
  - `totvs_get_product_composition_group_product`
  - `totvs_get_product_composition_product`
  - `totvs_get_product_instruction_items`
  - `totvs_get_product_price_table_scales`
  - `totvs_get_product_grouper_configurations`
- Product Engineering, Material Request, Product Prototype, Logistics and Person coverage expanded.

### Changed
- Endpoint coverage increased to `169/251`.
- Product coverage increased to `38/42`.
- Upsert behavior documented/tested for TOTVS create/update split flows.

### Tests
- Test suite expanded to 176 tests.

## [3.5.0] - 2026-05-22

### Added
- Fast 360 aggregators: `totvs_product_360`, `totvs_raw_material_360`, `totvs_order_360`, `totvs_invoice_360`.
- Operational shortcuts: `totvs_sales_today_summary`, `totvs_new_customers_today`.
- Fast open-order aggregators: `totvs_open_purchase_orders` and `totvs_open_production_orders`.
- `docs/PERFORMANCE.md` with benchmark notes and guidance for fast composed tools.
- Operational defaults in startup context: price, cost and stock code lists are now exposed via `operationalDefaults`.

### Changed
- `daily_dashboard` now uses the receivable documents endpoint and returns partial section errors instead of failing the whole dashboard.
- Product and stock aggregators now read price/cost/stock defaults from startup context, with `.env` fallback.
- Purchase order open statuses `[1,3,5]` documented as the standard TOTVS default.

### Tests
- Test suite expanded to 128 tests.

## [3.1.2] — 2026-04-27

### Adicionado
- `totvs_get_instructions` — guia completo do servidor para LLMs: tools por categoria, fluxo de status, dicas de uso. Resolve o problema de LLMs tentando criar scripts Python em vez de usar as tools MCP.
- Variável de ambiente `TOTVS_OPERATION_CONTEXT`: permite injetar contexto operacional da empresa (ex: significado real dos status de pedido) no guia retornado pela tool.

## [3.1.1] — 2026-04-26

### Corrigido
- `context_cache`: branches agora usa default `1` quando `TOTVS_BRANCH_CODES` não está configurado.
- `context_cache._load_operations`: adicionados params de data obrigatórios; corrigido mapeamento de campos (`operationCode`/`description`).
- `context_cache._discover_price_types`: corrigido formato do body — API exige `option.prices[{branchCode, priceCodeList}]`.
- `context_cache._discover_cost_types`: corrigido formato do body — API exige `option.costs[{branchCode, costCodeList}]` + `filter.hasCost`/`branchCostCodeList`.
- `search_costs`: corrigido body — agora usa `option.costs` e `filter.hasCost`/`branchCostCodeList` conforme exigido pela API.

### Documentação
- README reescrito com documentação técnica completa: tabela de tools por módulo, estrutura do projeto, variáveis de ambiente, exemplos de uso.

## [3.1.0] — 2026-04-25

### Corrigido
- `update_product_data` estava com bug crítico: usava POST quando devia ser PUT, e endpoint errado. Tool nunca funcionou. Refatorada com auto-roteamento (simples vs batch).
- `update_product_price` exigia `valueType` mas não documentava no schema. Adicionado fallback pra Price quando omitido. Aliases P/C aceitos.

### Adicionado
- `tools/_value_types.py` — normalização de Price/Cost com aliases P/C.
- `update_product_price_only` — atualiza preço com valueType='Price' injetado.
- `update_product_cost` — atualiza custo com valueType='Cost' injetado.
- `update_product_simple` — alias claro pro PUT /products/{code}/{branchCode}.
- `update_product_branch_info_batch` — update em lote por filial.
- Schema enriquecido de `update_product_data` (weight, ncmCode, CST, flags).
- Schema enriquecido de `search_prices` (filter.change, option.prices, digitalPromotionPrices).

### Mudado
- `context_cache.py` agora descobre `priceTypes` e `costTypes` reais via top 20 produtos vendidos. Antes vinha vazio.
- `get_context` ganhou parâmetro `verbose` (default false). Slim mode retorna ~5KB; verbose retorna cache completo.
- Carregamento do cache agora é resiliente: falha em um endpoint não impede os outros.

### Testes
- 26 testes novos. Total do projeto: 117.

## [3.0.0] — 2026-04-24

### Removido
- Módulo Analytics completo (24 tools)
- Variável de ambiente `TOTVS_ENABLE_ANALYTICS` (não tem mais função)

### Razão da remoção
Analytics é módulo opcional do TOTVS Moda — a maioria dos usuários não contrata. Manter no projeto adicionava 24 tools que aparecem no LLM mas retornam 401/403, polui a interface, e gera consumo desnecessário de tokens no system prompt.

Quem precisar de analytics pode contribuir via PR ou manter um fork.

### Migração
Se você tem `TOTVS_ENABLE_ANALYTICS` no seu `.env` ou `mcp.json`, pode remover. Não tem mais efeito.

Nenhuma outra mudança. Tools dos demais 15 módulos continuam idênticas.

### Documentação adicionada
- `docs/PROJECT_STATE.md` — estado consolidado do projeto
- `docs/ROADMAP.md` — plano de evolução
- `docs/PATTERNS.md` — padrões obrigatórios

---

## [2.1.6] - 2026-04-20

### Fixed

#### Critical Bug Fix: ProductTools.search_products

- **`tools/product.py`**: Fixed `search_products` request body structure
  - Was sending all parameters directly in `filter` object
  - API requires `option.BranchInfoCode` (mandatory field)
  - When using `priceCodeList`, must also set `filter.hasPrice = true`
  - When using `priceCodeList`, must populate `filter.priceCodeList` and `filter.branchPriceCodeList`
  - Previous implementation returned HTTP 400 errors
  - Now correctly structures request with both `option` and `filter` objects
  - Validated with manual testing: successfully retrieves products from production API

**Impact**: `totvs_search_products` tool is now fully functional

### Changed

- Updated `.gitignore` to exclude test files (test_manual.py, test_phase2.py, TEST_RESULTS.md, TESTING_ROADMAP.md)

## [2.1.5] - 2026-04-18

### Added - 15 New Endpoints

#### Sales Order - Complete Item Management (10 endpoints)

- **`totvs_add_order_items`**: Add items to existing order (POST `/sales-order/v2/items`)
- **`totvs_remove_order_item`**: Remove item from order (DELETE `/sales-order/v2/items`)
- **`totvs_cancel_order_items`**: Cancel item quantities (POST `/sales-order/v2/cancel-items`)
- **`totvs_change_order_item_quantity`**: Change item quantities (POST `/sales-order/v2/quantity-items`)
- **`totvs_update_order_items_additional`**: Update item additional data (POST `/sales-order/v2/additional-items`)
- **`totvs_add_order_observation`**: Add observation to order (POST `/sales-order/v2/observations-order`)
- **`totvs_update_order_shipping`**: Update shipping/freight data (POST `/sales-order/v2/shipping-order`)
- **`totvs_update_order_additional`**: Update tracking, ecommerce, omni data (POST `/sales-order/v2/additional-order`)
- **`totvs_search_batch_items`**: Search order batches by status and change date (GET `/sales-order/v2/batch-items`)
- **`totvs_create_order_relationship_counts`**: Link counts to order (POST `/sales-order/v2/relationship-counts`)

Sales Order module upgraded from "consultation only" to **full operational management** - add/remove items, adjust quantities, update observations, freight, and tracking via natural language.

#### Product - Missing Write Operations (3 endpoints)

- **`totvs_create_reference`**: Create new product reference (POST `/product/v2/references`)
- **`totvs_update_barcode`**: Update existing barcode (POST `/product/v2/barcodes/update`)
- **`totvs_create_classification_type`**: Create classification type (POST `/product/v2/classifications`)

#### Accounts Receivable - Module Completed (2 endpoints)

- **`totvs_move_gift_check`**: Move gift check (POST `/accounts-receivable/v2/gift-check-movements`)
- **`totvs_upsert_invoice_commission`**: Create/update invoice commission (POST `/accounts-receivable/v2/comission`)

**Accounts Receivable module now covers 100% of official swagger endpoints.**

### Testing

- Added 21 new contract tests covering all 15 new endpoints
- Validates HTTP method, URL, required fields, and body shape
- Total test suite: **57 tests passing** (16 client + 20 regression + 21 new)
- Test execution time: ~0.5s

### Project Stats

- **75+ tools** across 18 modules
- **Accounts Receivable**: 100% swagger coverage
- **Account Payable**: 100% swagger coverage
- **Sales Order**: Full operational management capabilities

## [2.2.0] - 2026-04-18

### Added

#### Testing Infrastructure

- **Automated Testing Suite**: Added 36 comprehensive tests
  - `tests/test_totvs_client.py`: 16 tests covering HTTP client, OAuth2, retry logic, and error handling
  - `tests/test_tools_regressions.py`: 20 regression tests ensuring all 5 critical bug fixes remain fixed
  - `tests/conftest.py`: Shared pytest fixtures with respx mocking
  - `pytest.ini`: pytest configuration with async support

- **Continuous Integration**: GitHub Actions workflow
  - `.github/workflows/tests.yml`: Automated tests on Python 3.11 and 3.12
  - Runs on every push and pull request
  - Completes in under 1 minute

- **Contributing Guide**: `CONTRIBUTING.md`
  - Guidelines for opening pull requests
  - Instructions for running tests locally
  - Code style and quality requirements

### Testing Coverage

- ✅ OAuth2 token acquisition and auto-refresh
- ✅ HTTP retry logic with exponential backoff
- ✅ Error handling and parsing
- ✅ All 5 critical bug fixes from v2.0.1:
  - `update_product_data` uses PUT (not POST)
  - IMAGE endpoints use correct swagger paths
  - `search_voucher` uses GET (not POST)
  - `change_order_status` uses correct payload
  - `change_charge_type` validation works

## [2.0.1] - 2026-04-18

### Fixed

#### Critical Bug Fixes

- **`tools/product.py`**: Fixed `update_product_data` HTTP method from POST to PUT
  - Was returning HTTP 405 (Method Not Allowed) in production
  - Swagger specifies PUT `/api/totvsmoda/product/v2/data`

- **`tools/image.py`**: Complete rewrite with correct swagger endpoints
  - Previous code used `/product-images` which doesn't exist
  - All 3 image tools were returning HTTP 404
  - Now implements 6 correct methods:
    - `search_product_images` - POST `/product/search`
    - `upload_product_image` - POST `/product`
    - `import_image_no_link` - POST `/V2/imports`
    - `upload_person_image` - POST `/persons`
    - `list_person_images` - GET `/persons`
    - `get_person_image_base64` - GET `/person-images`

- **`tools/voucher.py`**: Fixed `search_voucher` HTTP method
  - Changed from POST with body to GET with query params
  - Was returning HTTP 404
  - Removed orphan `get_voucher` method (endpoint doesn't exist in swagger)

- **`tools/sales_order.py`**: Fixed `change_order_status` payload schema
  - Changed field from `newStatus` to `statusOrder`
  - Now enforces valid enum values:
    - `InProgress`, `BillingReleased`, `Blocked`, `InComposition`, `InAnalysis`
  - Was being rejected with HTTP 400 Bad Request
  - Added backward compatibility for `newStatus`
  - Added optional fields: `reasonBlockingCode`, `reasonBlockingDescription`

- **`tools/sales_order.py`**: Enhanced `cancel_order`
  - Added optional `ReasonCancellationDescription` field (max 80 chars)

- **`tools/accounts_receivable.py`**: Fixed `change_charge_type` validation
  - Added validation to ensure `customerCode` OR `customerCpfCnpj` is provided
  - Both fields marked as required in swagger but are mutually exclusive

#### Server Improvements

- **`server.py`**: Fixed ROUTING type hints
  - Removed `"totvs_get_context": None` breaking `dict[str, tuple[str, str]]`
  - Removed orphan `"totvs_get_price_tables_headers"` entry
  - Updated all 6 IMAGE tool mappings to new method names

### Added

- **`server.py`**: Added missing `totvs_search_seller_pending_conditionals` tool
  - Method existed in `tools/analytics.py` but was orphan
  - Now properly registered in TOOLS and ROUTING

## [2.0.0] - 2026-04-16

- Initial release with 16 modules and 135+ tools
