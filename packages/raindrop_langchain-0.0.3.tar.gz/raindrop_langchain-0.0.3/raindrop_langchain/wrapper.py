"""
LangChain callback handler for Raindrop observability.

Captures LLM calls, tool usage, chains, and retrievers via LangChain's
callback system and ships them to the Raindrop API.

Usage::

    from raindrop_langchain import RaindropLangchain

    raindrop = RaindropLangchain(api_key="rk_...")
    model = ChatOpenAI()
    result = model.invoke("Hello", config={"callbacks": [raindrop.handler]})
    raindrop.flush()
"""

from __future__ import annotations

import json
import logging
import time
import uuid
import warnings
from typing import Any, Dict, List, Literal, Optional, Sequence, Union

from langchain_core.callbacks import AsyncCallbackHandler
from langchain_core.outputs import LLMResult

import raindrop.analytics as _raindrop_analytics

logger = logging.getLogger("raindrop_langchain")

_LANGGRAPH_INTERNAL_NAMES = frozenset({
    "LangGraph",
    "__start__",
    "__end__",
    "ChannelWrite",
    "ChannelRead",
})


def _is_langgraph_internal(name: str) -> bool:
    """Check whether *name* belongs to a LangGraph-internal chain node."""
    if name in _LANGGRAPH_INTERNAL_NAMES:
        return True
    if name.startswith("Branch:"):
        return True
    if name.startswith("__") and name.endswith("__"):
        return True
    return False


def _get_name_from_serialized(serialized: Dict[str, Any]) -> str:
    """Extract a human-readable name from a LangChain serialized object."""
    if serialized.get("name"):
        return serialized["name"]
    ids = serialized.get("id")
    if ids and isinstance(ids, list) and len(ids) > 0:
        return ids[-1]
    return "unknown"


class _LLMMetadata:
    """Extracted metadata from an LLM response."""

    __slots__ = (
        "model", "output_text", "prompt_tokens", "completion_tokens",
        "finish_reason", "cached_tokens", "reasoning_tokens",
    )

    def __init__(
        self,
        model: Optional[str] = None,
        output_text: Optional[str] = None,
        prompt_tokens: Optional[int] = None,
        completion_tokens: Optional[int] = None,
        finish_reason: Optional[str] = None,
        cached_tokens: Optional[int] = None,
        reasoning_tokens: Optional[int] = None,
    ) -> None:
        self.model = model
        self.output_text = output_text
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens
        self.finish_reason = finish_reason
        self.cached_tokens = cached_tokens
        self.reasoning_tokens = reasoning_tokens


def _extract_llm_metadata(
    response: LLMResult,
) -> _LLMMetadata:
    """Extract model name, output text, token counts, finish_reason, and
    extended token categories from an *LLMResult*.

    Returns:
        An :class:`_LLMMetadata` instance.
    """
    model: Optional[str] = None
    output_text: Optional[str] = None
    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    finish_reason: Optional[str] = None
    cached_tokens: Optional[int] = None
    reasoning_tokens: Optional[int] = None

    if response.generations and response.generations[0]:
        gen = response.generations[0][0]
        output_text = gen.text

        # -- finish_reason from generation_info ---------------------------------
        gen_info: Dict[str, Any] = getattr(gen, "generation_info", None) or {}
        finish_reason = gen_info.get("finish_reason")

        msg = getattr(gen, "message", None)
        if msg:
            resp_meta: Dict[str, Any] = getattr(msg, "response_metadata", {}) or {}
            model = resp_meta.get("model_name") or resp_meta.get("model")

            # Fall back to response_metadata for finish_reason
            if not finish_reason:
                finish_reason = resp_meta.get("finish_reason")

            usage_meta = getattr(msg, "usage_metadata", None)
            if usage_meta:
                if isinstance(usage_meta, dict):
                    prompt_tokens = usage_meta.get("input_tokens")
                    completion_tokens = usage_meta.get("output_tokens")
                    # Extended token categories (LangChain OpenAI format)
                    input_details = usage_meta.get("input_token_details") or {}
                    output_details = usage_meta.get("output_token_details") or {}
                    if isinstance(input_details, dict):
                        cached_tokens = input_details.get("cache_read")
                    if isinstance(output_details, dict):
                        reasoning_tokens = output_details.get("reasoning")
                else:
                    prompt_tokens = getattr(usage_meta, "input_tokens", None)
                    completion_tokens = getattr(usage_meta, "output_tokens", None)
                    input_details = getattr(usage_meta, "input_token_details", None) or {}
                    output_details = getattr(usage_meta, "output_token_details", None) or {}
                    if isinstance(input_details, dict):
                        cached_tokens = input_details.get("cache_read")
                    else:
                        cached_tokens = getattr(input_details, "cache_read", None)
                    if isinstance(output_details, dict):
                        reasoning_tokens = output_details.get("reasoning")
                    else:
                        reasoning_tokens = getattr(output_details, "reasoning", None)

    llm_output: Dict[str, Any] = response.llm_output or {}
    if not model:
        model = llm_output.get("model_name") or llm_output.get("model")

    token_usage: Dict[str, Any] = (
        llm_output.get("token_usage") or llm_output.get("tokenUsage") or {}
    )
    if prompt_tokens is None:
        pt = token_usage.get("prompt_tokens")
        prompt_tokens = pt if pt is not None else token_usage.get("promptTokens")
    if completion_tokens is None:
        ct = token_usage.get("completion_tokens")
        completion_tokens = ct if ct is not None else token_usage.get("completionTokens")

    # Extended token categories from llm_output (OpenAI raw format)
    if cached_tokens is None:
        prompt_details = token_usage.get("prompt_tokens_details") or {}
        if isinstance(prompt_details, dict):
            cached_tokens = prompt_details.get("cached_tokens")
    if reasoning_tokens is None:
        completion_details = token_usage.get("completion_tokens_details") or {}
        if isinstance(completion_details, dict):
            reasoning_tokens = completion_details.get("reasoning_tokens")

    return _LLMMetadata(
        model=model,
        output_text=output_text,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        finish_reason=finish_reason,
        cached_tokens=cached_tokens,
        reasoning_tokens=reasoning_tokens,
    )


def _build_error_properties(error: BaseException) -> Dict[str, str]:
    """Build a properties dict capturing the error type and message."""
    return {
        "error.type": type(error).__name__,
        "error.message": str(error),
    }


# ---------------------------------------------------------------------------
# Callback handler (internal implementation detail)
# ---------------------------------------------------------------------------


class RaindropCallbackHandler(AsyncCallbackHandler):
    """LangChain callback handler that ships events to Raindrop.

    Supports both synchronous and asynchronous LangChain callbacks by
    inheriting from :class:`AsyncCallbackHandler`.
    """

    def __init__(
        self,
        user_id: str = "unknown",
        convo_id: Optional[str] = None,
        trace_chains: bool = True,
        trace_retrievers: bool = True,
        filter_langgraph_internals: bool = True,
        *,
        debug: bool = False,
    ) -> None:
        super().__init__()
        self._user_id = user_id or "unknown"
        self._convo_id = convo_id
        self._trace_chains = trace_chains
        self._trace_retrievers = trace_retrievers
        self._filter_langgraph = filter_langgraph_internals
        self._debug = debug

        self._spans: Dict[str, Dict[str, Any]] = {}
        self._root_run_ids: Dict[str, str] = {}
        self._event_ids: Dict[str, str] = {}
        self._interaction: Optional[Any] = None

    # -- internal helpers ----------------------------------------------------

    def _get_event_id(
        self, run_id: uuid.UUID, parent_run_id: Optional[uuid.UUID] = None
    ) -> str:
        """Return a stable event ID for the root run that *run_id* belongs to."""
        rid = str(run_id)
        pid = str(parent_run_id) if parent_run_id else None
        root_id = self._root_run_ids.get(pid, pid) if pid else rid
        self._root_run_ids[rid] = root_id
        if root_id not in self._event_ids:
            self._event_ids[root_id] = str(uuid.uuid4())
        return self._event_ids[root_id]

    def _cleanup(self, run_id: uuid.UUID) -> None:
        """Remove all internal tracking state for the given *run_id*."""
        rid = str(run_id)
        self._spans.pop(rid, None)
        self._spans.pop(f"{run_id}:agent_action", None)
        # Check whether this run was registered via _get_event_id before
        # popping it.  Filtered runs (e.g. LangGraph internals) skip
        # _get_event_id, so they are never in _root_run_ids.
        was_registered = rid in self._root_run_ids
        root_id = self._root_run_ids.pop(rid, rid)
        if root_id == rid:
            # Always clean up _event_ids to prevent memory leaks — even for
            # unregistered (filtered) runs whose ID may have been used as
            # root_id by child runs via _get_event_id.
            self._event_ids.pop(root_id, None)
            # Only finish the interaction when the run was actually registered.
            # Filtered LangGraph internal chains must not prematurely destroy
            # the interaction that a legitimate root run created.
            if was_registered and self._interaction is not None:
                try:
                    self._interaction.finish()
                except Exception:
                    logger.debug("Error finishing interaction", exc_info=True)
                self._interaction = None

    def _finalize_if_root(
        self,
        run_id: uuid.UUID,
        output: Optional[str] = None,
        model: Optional[str] = None,
        properties: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Ship a ``track_ai`` event when *run_id* is the root of its tree."""
        rid = str(run_id)
        root_id = self._root_run_ids.get(rid, rid)
        event_id = self._event_ids.get(root_id)
        if not event_id:
            return

        if root_id == rid:
            _raindrop_analytics.track_ai(
                user_id=self._user_id,
                event="ai_generation",
                event_id=event_id,
                output=output,
                model=model,
                properties=properties,
                convo_id=self._convo_id,
            )

    @staticmethod
    def _build_properties(
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Merge LangChain *tags* and *metadata* into a Raindrop properties dict."""
        if not tags and not metadata:
            return None
        props: Dict[str, Any] = {}
        if tags:
            props["langchain.tags"] = tags
        if metadata:
            props.update(metadata)
        return props

    # -------------------------------------------------------------------------
    # LLM events
    # -------------------------------------------------------------------------

    def _ensure_interaction(self, run_id: uuid.UUID) -> None:
        """Create an interaction for the root run if one does not already exist."""
        rid = str(run_id)
        root_id = self._root_run_ids.get(rid, rid)
        # Only create an interaction when this is a root-level run
        if root_id == rid and self._interaction is None:
            event_id = self._event_ids.get(root_id)
            try:
                self._interaction = _raindrop_analytics.begin(
                    user_id=self._user_id,
                    event="ai_generation",
                    event_id=event_id,
                    convo_id=self._convo_id,
                )
            except Exception:
                logger.debug("Error creating interaction", exc_info=True)

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        try:
            if self._filter_langgraph and str(run_id) in self._spans:
                return
            event_id = self._get_event_id(run_id, parent_run_id)
            self._ensure_interaction(run_id)
            self._spans[str(run_id)] = {
                "event_id": event_id,
                "type": "llm",
                "input": "\n".join(prompts),
                "properties": self._build_properties(tags, metadata),
            }
        except Exception:
            logger.debug("Error in on_llm_start", exc_info=True)

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[Any]],
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        try:
            if self._filter_langgraph and str(run_id) in self._spans:
                return
            event_id = self._get_event_id(run_id, parent_run_id)
            self._ensure_interaction(run_id)
            self._spans[str(run_id)] = {
                "event_id": event_id,
                "type": "chat",
                "properties": self._build_properties(tags, metadata),
            }

            input_text = _extract_chat_input(messages)
            self._spans[str(run_id)]["input"] = input_text
        except Exception:
            logger.debug("Error in on_chat_model_start", exc_info=True)

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            meta = _extract_llm_metadata(response)

            span_data = self._spans.get(str(run_id), {})
            input_text = span_data.get("input")
            span_props: Dict[str, Any] = span_data.get("properties") or {}

            properties: Dict[str, Any] = {**span_props}
            if meta.prompt_tokens is not None:
                properties["ai.usage.prompt_tokens"] = meta.prompt_tokens
            if meta.completion_tokens is not None:
                properties["ai.usage.completion_tokens"] = meta.completion_tokens
            if meta.finish_reason is not None:
                properties["ai.finish_reason"] = meta.finish_reason
            if meta.cached_tokens is not None:
                properties["ai.usage.cached_tokens"] = meta.cached_tokens
            if meta.reasoning_tokens is not None:
                properties["ai.usage.thoughts_tokens"] = meta.reasoning_tokens

            rid = str(run_id)
            root_id = self._root_run_ids.get(rid, rid)
            event_id = self._event_ids.get(root_id)

            if event_id:
                _raindrop_analytics.track_ai(
                    user_id=self._user_id,
                    event="ai_generation",
                    event_id=event_id if root_id == rid else str(uuid.uuid4()),
                    input=input_text,
                    output=meta.output_text,
                    model=meta.model,
                    properties=properties if properties else None,
                    convo_id=self._convo_id,
                )
        except Exception:
            logger.debug("Error in on_llm_end", exc_info=True)
        finally:
            self._cleanup(run_id)

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            error_props = _build_error_properties(error)
            span_data = self._spans.get(str(run_id), {})
            span_props: Dict[str, Any] = span_data.get("properties") or {}
            merged = {**span_props, **error_props}
            self._finalize_if_root(run_id, properties=merged)
        except Exception:
            logger.debug("Error in on_llm_error", exc_info=True)
        finally:
            self._cleanup(run_id)

    # -------------------------------------------------------------------------
    # Chain events
    # -------------------------------------------------------------------------

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        name: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        try:
            if self._filter_langgraph:
                chain_name = name or _get_name_from_serialized(serialized)
                if _is_langgraph_internal(chain_name):
                    return
            self._get_event_id(run_id, parent_run_id)
            self._ensure_interaction(run_id)
            if not self._trace_chains:
                return
            self._spans[str(run_id)] = {"type": "chain"}
        except Exception:
            logger.debug("Error in on_chain_start", exc_info=True)

    def on_chain_end(
        self,
        outputs: Dict[str, Any],
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            self._finalize_if_root(run_id)
        except Exception:
            logger.debug("Error in on_chain_end", exc_info=True)
        finally:
            self._cleanup(run_id)

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            error_props = _build_error_properties(error)
            self._finalize_if_root(run_id, properties=error_props)
        except Exception:
            logger.debug("Error in on_chain_error", exc_info=True)
        finally:
            self._cleanup(run_id)

    # -------------------------------------------------------------------------
    # Tool events
    # -------------------------------------------------------------------------

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        try:
            event_id = self._get_event_id(run_id, parent_run_id)
            tool_name = serialized.get("name") or (
                serialized.get("id", [None])[-1] if serialized.get("id") else None
            )
            self._spans[str(run_id)] = {
                "event_id": event_id,
                "type": "tool",
                "name": tool_name,
                "input": input_str,
                "start_time_ns": time.monotonic_ns(),
            }
        except Exception:
            logger.debug("Error in on_tool_start", exc_info=True)

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            span_data = self._spans.get(str(run_id), {})
            tool_name = span_data.get("name") or "unknown"
            tool_input = span_data.get("input")
            start_ns = span_data.get("start_time_ns")
            duration_ms: Optional[float] = None
            if start_ns is not None:
                duration_ms = (time.monotonic_ns() - start_ns) / 1_000_000

            if self._interaction is not None:
                try:
                    self._interaction.track_tool(
                        name=tool_name,
                        input=tool_input,
                        output=str(output) if output is not None else None,
                        duration_ms=duration_ms,
                    )
                except Exception:
                    logger.debug("Error tracking tool span", exc_info=True)

            self._finalize_if_root(run_id)
        except Exception:
            logger.debug("Error in on_tool_end", exc_info=True)
        finally:
            self._cleanup(run_id)

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            span_data = self._spans.get(str(run_id), {})
            tool_name = span_data.get("name") or "unknown"
            tool_input = span_data.get("input")
            start_ns = span_data.get("start_time_ns")
            duration_ms: Optional[float] = None
            if start_ns is not None:
                duration_ms = (time.monotonic_ns() - start_ns) / 1_000_000

            if self._interaction is not None:
                try:
                    self._interaction.track_tool(
                        name=tool_name,
                        input=tool_input,
                        error=error,
                        duration_ms=duration_ms,
                    )
                except Exception:
                    logger.debug("Error tracking tool error span", exc_info=True)

            error_props = _build_error_properties(error)
            self._finalize_if_root(run_id, properties=error_props)
        except Exception:
            logger.debug("Error in on_tool_error", exc_info=True)
        finally:
            self._cleanup(run_id)

    # -------------------------------------------------------------------------
    # Retriever events
    # -------------------------------------------------------------------------

    def on_retriever_start(
        self,
        serialized: Dict[str, Any],
        query: str,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        try:
            self._get_event_id(run_id, parent_run_id)
            if not self._trace_retrievers:
                return
            self._spans[str(run_id)] = {"type": "retriever"}
        except Exception:
            logger.debug("Error in on_retriever_start", exc_info=True)

    def on_retriever_end(
        self,
        documents: Sequence[Any],
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            self._finalize_if_root(run_id)
        except Exception:
            logger.debug("Error in on_retriever_end", exc_info=True)
        finally:
            self._cleanup(run_id)

    def on_retriever_error(
        self,
        error: BaseException,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            error_props = _build_error_properties(error)
            self._finalize_if_root(run_id, properties=error_props)
        except Exception:
            logger.debug("Error in on_retriever_error", exc_info=True)
        finally:
            self._cleanup(run_id)

    # -------------------------------------------------------------------------
    # Agent events
    # -------------------------------------------------------------------------

    def on_agent_action(
        self,
        action: Any,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            self._get_event_id(run_id, parent_run_id)
            tool = getattr(action, "tool", None) or "unknown"
            tool_input = getattr(action, "tool_input", "")
            if not isinstance(tool_input, str):
                try:
                    tool_input = json.dumps(tool_input)
                except Exception:
                    tool_input = str(tool_input)
            span_key = f"{run_id}:agent_action"
            self._spans[span_key] = {
                "type": "agent_action",
                "tool": tool,
                "tool_input": tool_input,
            }
        except Exception:
            logger.debug("Error in on_agent_action", exc_info=True)

    def on_agent_finish(
        self,
        finish: Any,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            span_key = f"{run_id}:agent_action"
            self._spans.pop(span_key, None)
        except Exception:
            logger.debug("Error in on_agent_finish", exc_info=True)


# ---------------------------------------------------------------------------
# Chat input extraction helper
# ---------------------------------------------------------------------------


def _extract_chat_input(messages: List[List[Any]]) -> Optional[str]:
    """Extract the last user message from nested chat message lists."""
    all_msgs = [msg for msg_list in messages for msg in msg_list]
    user_msgs = [m for m in all_msgs if getattr(m, "type", "unknown") in ("human", "user")]
    last_msg = user_msgs[-1] if user_msgs else (all_msgs[-1] if all_msgs else None)
    if last_msg is None:
        return None
    content = last_msg.content if hasattr(last_msg, "content") else str(last_msg)
    if isinstance(content, list):
        try:
            content = json.dumps(content)
        except Exception:
            content = str(content)
    return content


# ---------------------------------------------------------------------------
# Top-level wrapper class
# ---------------------------------------------------------------------------


class RaindropLangchain:
    """High-level entry-point for Raindrop + LangChain integration.

    Provides the callback :attr:`handler` to pass into LangChain, plus
    convenience methods for flushing, shutting down, identifying users,
    and tracking signals.

    Usage::

        raindrop = RaindropLangchain(api_key="rk_...")
        model = ChatOpenAI()
        result = model.invoke("Hello", config={"callbacks": [raindrop.handler]})
        raindrop.flush()
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        user_id: Optional[str] = None,
        convo_id: Optional[str] = None,
        trace_chains: bool = True,
        trace_retrievers: bool = True,
        filter_langgraph_internals: bool = True,
        tracing_enabled: bool = True,
        bypass_otel_for_tools: bool = True,
        *,
        debug: bool = False,
    ) -> None:
        if not api_key:
            warnings.warn(
                "[raindrop-langchain] api_key not provided; telemetry shipping is disabled",
                stacklevel=2,
            )

        if debug:
            logger.setLevel(logging.DEBUG)
        else:
            logger.setLevel(logging.WARNING)

        _raindrop_analytics.init(
            api_key=api_key or "",
            tracing_enabled=tracing_enabled,
            bypass_otel_for_tools=bypass_otel_for_tools,
            auto_instrument=False,
        )

        self._user_id = user_id or "unknown"
        self._convo_id = convo_id
        self._debug = debug

        self._handler = RaindropCallbackHandler(
            user_id=self._user_id,
            convo_id=convo_id,
            trace_chains=trace_chains,
            trace_retrievers=trace_retrievers,
            filter_langgraph_internals=filter_langgraph_internals,
            debug=debug,
        )

    @property
    def handler(self) -> RaindropCallbackHandler:
        """The LangChain callback handler instance.

        Pass this to LangChain via ``config={"callbacks": [raindrop.handler]}``.
        """
        return self._handler

    def flush(self) -> None:
        """Flush all pending events to the Raindrop API."""
        try:
            _raindrop_analytics.flush()
        except Exception:
            logger.debug("Failed to flush events", exc_info=True)

    def shutdown(self) -> None:
        """Flush remaining events and release resources."""
        try:
            _raindrop_analytics.shutdown()
        except Exception:
            logger.debug("Failed to shutdown", exc_info=True)

    def identify(
        self,
        user_id: str,
        traits: Optional[Dict[str, Union[str, int, bool, float]]] = None,
    ) -> None:
        """Identify a user with optional traits.

        Args:
            user_id: The user identifier.
            traits: Optional dictionary of user traits.
        """
        try:
            _raindrop_analytics.identify(user_id=user_id, traits=traits or {})
        except Exception:
            logger.debug("Failed to identify user", exc_info=True)

    def track_signal(
        self,
        event_id: str,
        name: str,
        signal_type: Literal["default", "feedback", "edit"] = "default",
        *,
        timestamp: Optional[str] = None,
        properties: Optional[Dict[str, object]] = None,
        attachment_id: Optional[str] = None,
        comment: Optional[str] = None,
        after: Optional[str] = None,
        sentiment: Optional[Literal["POSITIVE", "NEGATIVE"]] = None,
    ) -> None:
        """Track a signal event.

        Args:
            event_id: The event ID to associate the signal with.
            name: Signal name.
            signal_type: One of "default", "feedback", or "edit".
            timestamp: Optional ISO-8601 timestamp string.
            properties: Optional extra properties dict.
            attachment_id: Optional attachment identifier.
            comment: Optional comment text.
            after: Optional "after" value for edit signals.
            sentiment: Optional sentiment ("POSITIVE" or "NEGATIVE").
        """
        try:
            _raindrop_analytics.track_signal(
                event_id=event_id,
                name=name,
                signal_type=signal_type,
                timestamp=timestamp,
                properties=properties,
                attachment_id=attachment_id,
                comment=comment,
                after=after,
                sentiment=sentiment,
            )
        except Exception:
            logger.debug("Failed to track signal", exc_info=True)

    # -- backwards-compat dict access ----------------------------------------

    def __getitem__(self, key: str) -> Any:
        """Support dict-style access for backwards compatibility.

        .. deprecated::
            Use attribute access instead.
        """
        _COMPAT_MAP = {"handler": "handler", "flush": "flush", "shutdown": "shutdown"}
        if key in _COMPAT_MAP:
            warnings.warn(
                f'raindrop["{key}"] is deprecated — use raindrop.{key} instead',
                DeprecationWarning,
                stacklevel=2,
            )
            return getattr(self, key)
        raise KeyError(key)


# ---------------------------------------------------------------------------
# Factory function
# ---------------------------------------------------------------------------


def create_raindrop_langchain(
    api_key: Optional[str] = None,
    user_id: Optional[str] = None,
    convo_id: Optional[str] = None,
    trace_chains: bool = True,
    trace_retrievers: bool = True,
    filter_langgraph_internals: bool = True,
    tracing_enabled: bool = True,
    bypass_otel_for_tools: bool = True,
    *,
    debug: bool = False,
) -> RaindropLangchain:
    """Create a Raindrop-instrumented LangChain integration.

    This is the recommended entry-point. Returns a :class:`RaindropLangchain`
    instance.

    Args:
        api_key: Raindrop API key (``rk_...``). If None, telemetry is disabled.
        user_id: Associate all events with this user.
        convo_id: Conversation ID to group related events.
        trace_chains: Track chain execution (default ``True``).
        trace_retrievers: Track retriever calls (default ``True``).
        filter_langgraph_internals: Filter LangGraph-internal chain events
            and deduplicate LLM callbacks (default ``True``).
        tracing_enabled: Enable distributed tracing (default ``True``).
        bypass_otel_for_tools: Bypass OTEL for tool spans (default ``True``).
        debug: Enable debug logging (default ``False``).

    Returns:
        A :class:`RaindropLangchain` instance.

    Usage::

        raindrop = create_raindrop_langchain(api_key="rk_...")
        model = ChatOpenAI()
        result = model.invoke("Hello", config={"callbacks": [raindrop.handler]})
        raindrop.flush()
    """
    try:
        return RaindropLangchain(
            api_key=api_key,
            user_id=user_id,
            convo_id=convo_id,
            trace_chains=trace_chains,
            trace_retrievers=trace_retrievers,
            filter_langgraph_internals=filter_langgraph_internals,
            tracing_enabled=tracing_enabled,
            bypass_otel_for_tools=bypass_otel_for_tools,
            debug=debug,
        )
    except Exception:
        logger.debug("Failed to create RaindropLangchain", exc_info=True)
        try:
            return RaindropLangchain(
                api_key="",
                user_id=user_id,
                convo_id=convo_id,
                trace_chains=trace_chains,
                trace_retrievers=trace_retrievers,
                filter_langgraph_internals=filter_langgraph_internals,
                debug=debug,
            )
        except Exception:
            logger.debug("Fallback RaindropLangchain also failed", exc_info=True)
            raise
