"""Tests for LangChain Raindrop integration."""

import time
import uuid
from unittest.mock import MagicMock, patch

from raindrop_langchain.wrapper import (
    RaindropCallbackHandler,
    RaindropLangchain,
    _LLMMetadata,
    _extract_llm_metadata,
    create_raindrop_langchain,
)


class FakeLLMResult:
    """Minimal LLMResult-like object for testing."""

    def __init__(
        self,
        text="Hello!",
        model=None,
        prompt_tokens=None,
        completion_tokens=None,
        finish_reason=None,
        cached_tokens=None,
        reasoning_tokens=None,
    ):
        msg = MagicMock()
        msg.content = text
        msg.response_metadata = {"model_name": model} if model else {}

        if finish_reason:
            msg.response_metadata["finish_reason"] = finish_reason

        if prompt_tokens is not None:
            usage = {
                "input_tokens": prompt_tokens,
                "output_tokens": completion_tokens,
                "total_tokens": (prompt_tokens or 0) + (completion_tokens or 0),
            }
            if cached_tokens is not None:
                usage["input_token_details"] = {"cache_read": cached_tokens}
            if reasoning_tokens is not None:
                usage["output_token_details"] = {"reasoning": reasoning_tokens}
            msg.usage_metadata = usage
        else:
            msg.usage_metadata = None

        gen = MagicMock()
        gen.text = text
        gen.message = msg
        gen.generation_info = {}
        if finish_reason:
            gen.generation_info["finish_reason"] = finish_reason

        self.generations = [[gen]]
        self.llm_output = {}
        if model:
            self.llm_output["model_name"] = model
        if prompt_tokens is not None:
            self.llm_output["token_usage"] = {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": (prompt_tokens or 0) + (completion_tokens or 0),
            }


FAKE_LLM_SERIALIZED = {"id": ["langchain", "chat_models", "ChatOpenAI"], "name": "ChatOpenAI"}
FAKE_TOOL_SERIALIZED = {"id": ["langchain", "tools", "Calculator"], "name": "Calculator"}
FAKE_CHAIN_SERIALIZED = {"id": ["langchain", "chains", "RunnableSequence"], "name": "RunnableSequence"}


def _make_handler() -> RaindropCallbackHandler:
    """Create a handler with raindrop analytics mocked out."""
    handler = RaindropCallbackHandler(
        user_id="test-user",
    )
    return handler


class TestExtractLLMMetadata:
    """Test the metadata extraction helper."""

    def test_extracts_from_usage_metadata(self):
        result = FakeLLMResult(text="Hi", model="gpt-4o", prompt_tokens=10, completion_tokens=5)
        meta = _extract_llm_metadata(result)
        assert isinstance(meta, _LLMMetadata)
        assert meta.model == "gpt-4o"
        assert meta.output_text == "Hi"
        assert meta.prompt_tokens == 10
        assert meta.completion_tokens == 5

    def test_extracts_from_llm_output_fallback(self):
        result = FakeLLMResult(text="Hello", model="gpt-3.5-turbo")
        result.generations[0][0].message.usage_metadata = None
        result.llm_output["token_usage"] = {"prompt_tokens": 20, "completion_tokens": 15}
        meta = _extract_llm_metadata(result)
        assert meta.model == "gpt-3.5-turbo"
        assert meta.output_text == "Hello"
        assert meta.prompt_tokens == 20
        assert meta.completion_tokens == 15

    def test_handles_empty_result(self):
        result = MagicMock()
        result.generations = [[]]
        result.llm_output = {}
        meta = _extract_llm_metadata(result)
        assert meta.model is None
        assert meta.output_text is None
        assert meta.prompt_tokens is None
        assert meta.completion_tokens is None

    def test_extracts_finish_reason_from_generation_info(self):
        result = FakeLLMResult(text="Done", model="gpt-4o", finish_reason="stop")
        meta = _extract_llm_metadata(result)
        assert meta.finish_reason == "stop"

    def test_extracts_finish_reason_from_response_metadata(self):
        """finish_reason falls back to response_metadata when generation_info is empty."""
        result = FakeLLMResult(text="Done", model="gpt-4o", finish_reason="length")
        # Clear generation_info so it falls back to response_metadata
        result.generations[0][0].generation_info = {}
        meta = _extract_llm_metadata(result)
        assert meta.finish_reason == "length"

    def test_extracts_extended_tokens_from_usage_metadata(self):
        result = FakeLLMResult(
            text="Hi", model="gpt-4o",
            prompt_tokens=100, completion_tokens=50,
            cached_tokens=30, reasoning_tokens=10,
        )
        meta = _extract_llm_metadata(result)
        assert meta.cached_tokens == 30
        assert meta.reasoning_tokens == 10

    def test_extracts_extended_tokens_from_llm_output(self):
        """Extended tokens from OpenAI raw format in llm_output."""
        result = FakeLLMResult(text="Hi", model="gpt-4o")
        result.generations[0][0].message.usage_metadata = None
        result.llm_output["token_usage"] = {
            "prompt_tokens": 100,
            "completion_tokens": 50,
            "prompt_tokens_details": {"cached_tokens": 25},
            "completion_tokens_details": {"reasoning_tokens": 15},
        }
        meta = _extract_llm_metadata(result)
        assert meta.cached_tokens == 25
        assert meta.reasoning_tokens == 15

    def test_no_extended_tokens_returns_none(self):
        result = FakeLLMResult(text="Hi", model="gpt-4o", prompt_tokens=10, completion_tokens=5)
        meta = _extract_llm_metadata(result)
        assert meta.cached_tokens is None
        assert meta.reasoning_tokens is None


class TestCallbackHandler:
    """Test the RaindropCallbackHandler."""


    def test_llm_start_and_end(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["What is 2+2?"], run_id=run_id)
        assert str(run_id) in handler._spans

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            result = FakeLLMResult(text="4", model="gpt-4o", prompt_tokens=5, completion_tokens=3)
            handler.on_llm_end(result, run_id=run_id)
            mock_raindrop.track_ai.assert_called_once()
            call_kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert call_kwargs["user_id"] == "test-user"
            assert call_kwargs["event"] == "ai_generation"
            assert call_kwargs["model"] == "gpt-4o"

    def test_chat_model_start_captures_input(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        msg = MagicMock()
        msg.type = "human"
        msg.content = "Tell me a joke"

        handler.on_chat_model_start(FAKE_LLM_SERIALIZED, [[msg]], run_id=run_id)
        span_data = handler._spans[str(run_id)]
        assert "joke" in span_data.get("input", "")

    def test_chain_flow_ships_on_llm_end(self):
        """In chain->LLM flows, track_ai is called immediately on LLM end."""
        handler = _make_handler()
        chain_id = uuid.uuid4()
        llm_id = uuid.uuid4()

        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=chain_id)
        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Hello"], run_id=llm_id, parent_run_id=chain_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            result = FakeLLMResult(text="World", model="gpt-4o")
            handler.on_llm_end(result, run_id=llm_id, parent_run_id=chain_id)
            mock_raindrop.track_ai.assert_called_once()
            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["input"] == "Hello"
            assert kwargs["output"] == "World"
            assert kwargs["model"] == "gpt-4o"

    def test_tool_events_cleanup(self):
        handler = _make_handler()
        run_id = uuid.uuid4()
        parent_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["calc"], run_id=parent_id)
        handler.on_tool_start(FAKE_TOOL_SERIALIZED, '{"a": 5}', run_id=run_id, parent_run_id=parent_id)
        assert str(run_id) in handler._spans

        handler.on_tool_end("15", run_id=run_id)
        assert str(run_id) not in handler._spans

    def test_cleanup_removes_state(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Test"], run_id=run_id)
        assert str(run_id) in handler._spans

        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            result = FakeLLMResult(text="Done")
            handler.on_llm_end(result, run_id=run_id)
        assert str(run_id) not in handler._spans

    def test_error_cleans_up(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Bad"], run_id=run_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            handler.on_llm_error(RuntimeError("fail"), run_id=run_id)
        assert str(run_id) not in handler._spans

    def test_llm_error_finalizes_root_event(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Bad input"], run_id=run_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            handler.on_llm_error(RuntimeError("API error"), run_id=run_id)
            mock_raindrop.track_ai.assert_called_once()

    def test_llm_error_captures_error_properties(self):
        """Error events should capture error type and message in properties."""
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Bad input"], run_id=run_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            handler.on_llm_error(ValueError("Invalid input"), run_id=run_id)
            mock_raindrop.track_ai.assert_called_once()
            call_kwargs = mock_raindrop.track_ai.call_args.kwargs
            props = call_kwargs.get("properties", {})
            assert props["error.type"] == "ValueError"
            assert props["error.message"] == "Invalid input"

    def test_token_counts_forwarded(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Test"], run_id=run_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            result = FakeLLMResult(text="Hi", model="gpt-4o", prompt_tokens=10, completion_tokens=5)
            handler.on_llm_end(result, run_id=run_id)
            call_kwargs = mock_raindrop.track_ai.call_args.kwargs
            props = call_kwargs.get("properties", {})
            assert props.get("ai.usage.prompt_tokens") == 10
            assert props.get("ai.usage.completion_tokens") == 5

    def test_trace_chains_false_still_ships_on_llm_end(self):
        """With traceChains=false, LLM events still ship immediately."""
        handler = RaindropCallbackHandler(
            user_id="test-user",
            trace_chains=False,
        )

        chain_id = uuid.uuid4()
        llm_id = uuid.uuid4()

        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=chain_id)
        assert str(chain_id) not in handler._spans

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Hello"], run_id=llm_id, parent_run_id=chain_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            result = FakeLLMResult(text="World")
            handler.on_llm_end(result, run_id=llm_id, parent_run_id=chain_id)
            mock_raindrop.track_ai.assert_called_once()

    def test_chat_model_end_to_end(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        msg = MagicMock()
        msg.type = "human"
        msg.content = "Tell me a joke"

        handler.on_chat_model_start(FAKE_LLM_SERIALIZED, [[msg]], run_id=run_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            result = FakeLLMResult(text="Why did the chicken cross the road?", model="gpt-4o")
            handler.on_llm_end(result, run_id=run_id)
            mock_raindrop.track_ai.assert_called_once()
            call_kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert "joke" in call_kwargs.get("input", "")
            assert "chicken" in call_kwargs.get("output", "")

    def test_chain_flow_preserves_llm_data(self):
        """In chain->LLM flow, track_ai on LLM end has the LLM's data."""
        handler = _make_handler()
        chain_id = uuid.uuid4()
        llm_id = uuid.uuid4()

        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=chain_id)
        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Hello"], run_id=llm_id, parent_run_id=chain_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            result = FakeLLMResult(text="World", model="gpt-4o", prompt_tokens=10, completion_tokens=5)
            handler.on_llm_end(result, run_id=llm_id, parent_run_id=chain_id)
            mock_raindrop.track_ai.assert_called_once()
            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs.get("input") == "Hello"
            assert kwargs.get("output") == "World"
            assert kwargs.get("model") == "gpt-4o"
            props = kwargs.get("properties", {})
            assert props.get("ai.usage.prompt_tokens") == 10
            assert props.get("ai.usage.completion_tokens") == 5

    def test_chain_flow_preserves_convo_id(self):
        handler = RaindropCallbackHandler(
            user_id="test-user",
            convo_id="convo-chain-test",
        )

        chain_id = uuid.uuid4()
        llm_id = uuid.uuid4()

        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=chain_id)
        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Hello"], run_id=llm_id, parent_run_id=chain_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            handler.on_llm_end(FakeLLMResult(text="World"), run_id=llm_id, parent_run_id=chain_id)
            mock_raindrop.track_ai.assert_called_once()
            assert mock_raindrop.track_ai.call_args.kwargs["convo_id"] == "convo-chain-test"

    def test_chain_flow_preserves_tags_metadata(self):
        handler = _make_handler()
        chain_id = uuid.uuid4()
        llm_id = uuid.uuid4()

        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=chain_id)
        handler.on_llm_start(
            FAKE_LLM_SERIALIZED, ["Hello"],
            run_id=llm_id, parent_run_id=chain_id,
            tags=["important"], metadata={"env": "staging"},
        )

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            handler.on_llm_end(FakeLLMResult(text="World"), run_id=llm_id, parent_run_id=chain_id)
            mock_raindrop.track_ai.assert_called_once()
            props = mock_raindrop.track_ai.call_args.kwargs.get("properties", {})
            assert props["langchain.tags"] == ["important"]
            assert props["env"] == "staging"

    def test_chain_error_finalizes(self):
        handler = _make_handler()
        chain_id = uuid.uuid4()

        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=chain_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            handler.on_chain_error(RuntimeError("Chain broke"), run_id=chain_id)
            mock_raindrop.track_ai.assert_called_once()

    def test_chain_error_captures_error_properties(self):
        handler = _make_handler()
        chain_id = uuid.uuid4()

        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=chain_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            handler.on_chain_error(RuntimeError("Chain broke"), run_id=chain_id)
            mock_raindrop.track_ai.assert_called_once()
            call_kwargs = mock_raindrop.track_ai.call_args.kwargs
            props = call_kwargs.get("properties", {})
            assert props["error.type"] == "RuntimeError"
            assert props["error.message"] == "Chain broke"

    def test_tool_error_finalizes(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_tool_start(FAKE_TOOL_SERIALIZED, '{"a": 1}', run_id=run_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            handler.on_tool_error(RuntimeError("Tool broke"), run_id=run_id)
            mock_raindrop.track_ai.assert_called_once()
        assert str(run_id) not in handler._spans

    def test_retriever_error_finalizes(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_retriever_start({"id": ["retriever"]}, "query", run_id=run_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            handler.on_retriever_error(RuntimeError("Retriever broke"), run_id=run_id)
            mock_raindrop.track_ai.assert_called_once()
        assert str(run_id) not in handler._spans

    def test_retriever_cleanup_with_tracing_disabled(self):
        handler = RaindropCallbackHandler(
            user_id="test-user",
            trace_retrievers=False,
        )

        run_id = uuid.uuid4()
        handler.on_retriever_start({"id": ["retriever"]}, "query", run_id=run_id)
        assert str(run_id) in handler._root_run_ids

        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            handler.on_retriever_end([], run_id=run_id)
        assert str(run_id) not in handler._root_run_ids

    def test_convo_id_forwarded(self):
        handler = RaindropCallbackHandler(
            user_id="test-user",
            convo_id="convo-abc",
        )

        run_id = uuid.uuid4()
        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Hello"], run_id=run_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            result = FakeLLMResult(text="Hi", model="gpt-4o")
            handler.on_llm_end(result, run_id=run_id)
            mock_raindrop.track_ai.assert_called_once()
            call_kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert call_kwargs["convo_id"] == "convo-abc"

    def test_tags_and_metadata_forwarded(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(
            FAKE_LLM_SERIALIZED,
            ["Hello"],
            run_id=run_id,
            tags=["production", "test"],
            metadata={"customField": "value123"},
        )

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            result = FakeLLMResult(text="Hi", model="gpt-4o")
            handler.on_llm_end(result, run_id=run_id)
            mock_raindrop.track_ai.assert_called_once()
            call_kwargs = mock_raindrop.track_ai.call_args.kwargs
            props = call_kwargs.get("properties", {})
            assert props["langchain.tags"] == ["production", "test"]
            assert props["customField"] == "value123"

    def test_agent_action_and_finish(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Agent task"], run_id=run_id)

        action = MagicMock()
        action.tool = "search"
        action.tool_input = "LangChain docs"

        handler.on_agent_action(action, run_id=run_id)
        span_key = f"{run_id}:agent_action"
        assert span_key in handler._spans
        assert handler._spans[span_key]["tool"] == "search"

        finish = MagicMock()
        finish.return_values = {"output": "Found docs"}

        handler.on_agent_finish(finish, run_id=run_id)
        assert span_key not in handler._spans

    def test_retriever_happy_path(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_retriever_start({"id": ["retriever", "VectorStore"]}, "search query", run_id=run_id)
        assert str(run_id) in handler._spans

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            handler.on_retriever_end(
                [MagicMock(page_content="doc1"), MagicMock(page_content="doc2")],
                run_id=run_id,
            )
            mock_raindrop.track_ai.assert_called_once()
        assert str(run_id) not in handler._spans

    def test_multiple_requests_no_leak(self):
        handler = _make_handler()

        for i in range(10):
            run_id = uuid.uuid4()
            handler.on_llm_start(FAKE_LLM_SERIALIZED, [f"Request {i}"], run_id=run_id)

            with patch("raindrop_langchain.wrapper._raindrop_analytics"):
                result = FakeLLMResult(text=f"Response {i}")
                handler.on_llm_end(result, run_id=run_id)

        assert len(handler._spans) == 0
        assert len(handler._root_run_ids) == 0
        assert len(handler._event_ids) == 0

    def test_user_id_defaults_to_unknown(self):
        """Handler user_id should default to 'unknown' when not provided."""
        handler = RaindropCallbackHandler()
        assert handler._user_id == "unknown"

    def test_user_id_none_becomes_unknown(self):
        """Handler user_id should become 'unknown' when None is passed."""
        handler = RaindropCallbackHandler(user_id=None)
        assert handler._user_id == "unknown"


class TestToolSpanTracking:
    """Test interaction.track_tool() for tool spans."""

    def test_on_tool_end_calls_track_tool(self):
        """on_tool_end should call interaction.track_tool with name, input, output, duration."""
        handler = _make_handler()
        mock_interaction = MagicMock()
        handler._interaction = mock_interaction

        run_id = uuid.uuid4()
        handler.on_tool_start(FAKE_TOOL_SERIALIZED, '{"a": 5}', run_id=run_id)

        handler.on_tool_end("15", run_id=run_id)

        mock_interaction.track_tool.assert_called_once()
        call_kwargs = mock_interaction.track_tool.call_args.kwargs
        assert call_kwargs["name"] == "Calculator"
        assert call_kwargs["input"] == '{"a": 5}'
        assert call_kwargs["output"] == "15"
        assert call_kwargs["duration_ms"] is not None
        assert call_kwargs["duration_ms"] >= 0

    def test_on_tool_error_calls_track_tool_with_error(self):
        """on_tool_error should call interaction.track_tool with error and duration."""
        handler = _make_handler()
        mock_interaction = MagicMock()
        handler._interaction = mock_interaction

        run_id = uuid.uuid4()
        handler.on_tool_start(FAKE_TOOL_SERIALIZED, '{"a": 1}', run_id=run_id)

        error = RuntimeError("Tool broke")
        handler.on_tool_error(error, run_id=run_id)

        mock_interaction.track_tool.assert_called_once()
        call_kwargs = mock_interaction.track_tool.call_args.kwargs
        assert call_kwargs["name"] == "Calculator"
        assert call_kwargs["input"] == '{"a": 1}'
        assert call_kwargs["error"] is error
        assert call_kwargs["duration_ms"] is not None
        assert call_kwargs["duration_ms"] >= 0

    def test_tool_span_duration_calculation(self):
        """Duration should be calculated from start_time_ns stored in span."""
        handler = _make_handler()
        mock_interaction = MagicMock()
        handler._interaction = mock_interaction

        run_id = uuid.uuid4()
        handler.on_tool_start(FAKE_TOOL_SERIALIZED, "input", run_id=run_id)

        # Verify start_time_ns was recorded
        span = handler._spans[str(run_id)]
        assert "start_time_ns" in span
        assert isinstance(span["start_time_ns"], int)

        handler.on_tool_end("output", run_id=run_id)
        duration = mock_interaction.track_tool.call_args.kwargs["duration_ms"]
        assert isinstance(duration, float)
        assert duration >= 0

    def test_tool_span_no_interaction_does_not_crash(self):
        """When no interaction exists, tool end/error should not crash."""
        handler = _make_handler()
        assert handler._interaction is None

        run_id = uuid.uuid4()
        handler.on_tool_start(FAKE_TOOL_SERIALIZED, "input", run_id=run_id)
        # Should not raise
        handler.on_tool_end("output", run_id=run_id)
        assert str(run_id) not in handler._spans

    def test_tool_error_span_no_interaction_does_not_crash(self):
        """When no interaction exists, tool error should not crash."""
        handler = _make_handler()
        assert handler._interaction is None

        run_id = uuid.uuid4()
        handler.on_tool_start(FAKE_TOOL_SERIALIZED, "input", run_id=run_id)
        handler.on_tool_error(RuntimeError("fail"), run_id=run_id)
        assert str(run_id) not in handler._spans

    def test_tool_end_track_tool_exception_is_swallowed(self):
        """If track_tool raises, it should be caught and not propagate."""
        handler = _make_handler()
        mock_interaction = MagicMock()
        mock_interaction.track_tool.side_effect = RuntimeError("SDK error")
        handler._interaction = mock_interaction

        run_id = uuid.uuid4()
        handler.on_tool_start(FAKE_TOOL_SERIALIZED, "input", run_id=run_id)
        # Should not raise despite track_tool error
        handler.on_tool_end("output", run_id=run_id)
        assert str(run_id) not in handler._spans

    def test_tool_end_with_none_output(self):
        """on_tool_end should handle None output."""
        handler = _make_handler()
        mock_interaction = MagicMock()
        handler._interaction = mock_interaction

        run_id = uuid.uuid4()
        handler.on_tool_start(FAKE_TOOL_SERIALIZED, "input", run_id=run_id)
        handler.on_tool_end(None, run_id=run_id)

        call_kwargs = mock_interaction.track_tool.call_args.kwargs
        assert call_kwargs["output"] is None

    def test_on_tool_start_stores_input_and_start_time(self):
        """on_tool_start should store input and start_time_ns in span data."""
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_tool_start(FAKE_TOOL_SERIALIZED, '{"query": "test"}', run_id=run_id)

        span = handler._spans[str(run_id)]
        assert span["input"] == '{"query": "test"}'
        assert span["start_time_ns"] > 0
        assert span["name"] == "Calculator"


class TestInteractionLifecycle:
    """Test interaction begin/track lifecycle."""

    def test_interaction_created_on_root_llm_start(self):
        """begin() should be called when a root LLM run starts."""
        handler = _make_handler()
        run_id = uuid.uuid4()

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            mock_raindrop.begin.return_value = MagicMock()
            handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Hello"], run_id=run_id)
            mock_raindrop.begin.assert_called_once()
            call_kwargs = mock_raindrop.begin.call_args.kwargs
            assert call_kwargs["user_id"] == "test-user"
            assert call_kwargs["event"] == "ai_generation"
            assert call_kwargs["convo_id"] is None
            assert call_kwargs["event_id"] is not None
            assert handler._interaction is not None

    def test_interaction_created_on_root_chain_start(self):
        """begin() should be called when a root chain starts."""
        handler = _make_handler()
        chain_id = uuid.uuid4()

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            mock_raindrop.begin.return_value = MagicMock()
            handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=chain_id)
            mock_raindrop.begin.assert_called_once()
            assert handler._interaction is not None

    def test_interaction_not_recreated_for_child_runs(self):
        """begin() should not be called again for child runs."""
        handler = _make_handler()
        chain_id = uuid.uuid4()
        llm_id = uuid.uuid4()

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            mock_interaction = MagicMock()
            mock_raindrop.begin.return_value = mock_interaction

            handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=chain_id)
            handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Hello"], run_id=llm_id, parent_run_id=chain_id)

            # begin() should only be called once for the root chain
            assert mock_raindrop.begin.call_count == 1

    def test_interaction_begin_error_is_swallowed(self):
        """If begin() raises, it should be caught and handler still works."""
        handler = _make_handler()
        run_id = uuid.uuid4()

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            mock_raindrop.begin.side_effect = RuntimeError("SDK error")
            # Should not raise
            handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Hello"], run_id=run_id)
            assert handler._interaction is None

    def test_interaction_finished_on_root_cleanup(self):
        """finish() should be called on the interaction when the root run completes."""
        handler = _make_handler()
        mock_interaction = MagicMock()
        handler._interaction = mock_interaction
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Test"], run_id=run_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            handler.on_llm_end(FakeLLMResult(text="Done"), run_id=run_id)

        mock_interaction.finish.assert_called_once()
        assert handler._interaction is None

    def test_interaction_not_finished_on_child_cleanup(self):
        """finish() should NOT be called when a child run is cleaned up."""
        handler = _make_handler()
        mock_interaction = MagicMock()
        handler._interaction = mock_interaction

        chain_id = uuid.uuid4()
        llm_id = uuid.uuid4()

        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=chain_id)
        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Hello"], run_id=llm_id, parent_run_id=chain_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            handler.on_llm_end(FakeLLMResult(text="World"), run_id=llm_id, parent_run_id=chain_id)

        # Interaction should NOT be finished yet — only the child LLM run was cleaned up
        mock_interaction.finish.assert_not_called()
        assert handler._interaction is not None

    def test_filtered_langgraph_chain_does_not_finish_interaction(self):
        """Filtered LangGraph internal chains must NOT finish the interaction.

        When on_chain_start filters out a LangGraph internal chain (returning
        early without calling _get_event_id), the subsequent on_chain_end still
        fires _cleanup.  Since the run was never registered in _root_run_ids,
        _cleanup must NOT treat it as a root run and must NOT call
        interaction.finish().
        """
        handler = _make_handler()  # filter_langgraph_internals=True by default
        mock_interaction = MagicMock()
        handler._interaction = mock_interaction

        # Simulate a real root chain that created the interaction
        real_root_id = uuid.uuid4()
        handler.on_chain_start({"name": "AgentExecutor", "id": ["AgentExecutor"]}, {}, run_id=real_root_id)

        # Now a LangGraph internal chain fires — it is filtered in on_chain_start
        internal_id = uuid.uuid4()
        handler.on_chain_start(
            {"name": "ChannelWrite", "id": ["ChannelWrite"]},
            {},
            run_id=internal_id,
            parent_run_id=real_root_id,
        )

        # on_chain_end for the filtered internal chain
        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            handler.on_chain_end({}, run_id=internal_id, parent_run_id=real_root_id)

        # The interaction must still be alive — the filtered chain must not have finished it
        mock_interaction.finish.assert_not_called()
        assert handler._interaction is not None

    def test_interaction_finish_error_is_swallowed(self):
        """If finish() raises, it should be caught and interaction reset to None."""
        handler = _make_handler()
        mock_interaction = MagicMock()
        mock_interaction.finish.side_effect = RuntimeError("SDK error")
        handler._interaction = mock_interaction
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Test"], run_id=run_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            # Should not raise despite finish() error
            handler.on_llm_end(FakeLLMResult(text="Done"), run_id=run_id)

        assert handler._interaction is None

    def test_interaction_reset_allows_new_invocation(self):
        """After a root run completes, a new invocation should create a new interaction."""
        handler = _make_handler()
        run_id1 = uuid.uuid4()
        run_id2 = uuid.uuid4()

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            interaction1 = MagicMock()
            interaction2 = MagicMock()
            mock_raindrop.begin.side_effect = [interaction1, interaction2]

            # First invocation
            handler.on_llm_start(FAKE_LLM_SERIALIZED, ["First"], run_id=run_id1)
            assert handler._interaction is interaction1

            handler.on_llm_end(FakeLLMResult(text="Done1"), run_id=run_id1)
            interaction1.finish.assert_called_once()
            assert handler._interaction is None

            # Second invocation — should create a new interaction
            handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Second"], run_id=run_id2)
            assert handler._interaction is interaction2
            assert mock_raindrop.begin.call_count == 2


class TestFinishReason:
    """Test finish_reason extraction and forwarding."""

    def test_finish_reason_forwarded_in_properties(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Test"], run_id=run_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            result = FakeLLMResult(text="Done", model="gpt-4o", finish_reason="stop")
            handler.on_llm_end(result, run_id=run_id)
            call_kwargs = mock_raindrop.track_ai.call_args.kwargs
            props = call_kwargs.get("properties", {})
            assert props["ai.finish_reason"] == "stop"

    def test_finish_reason_length(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Test"], run_id=run_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            result = FakeLLMResult(text="...", model="gpt-4o", finish_reason="length")
            handler.on_llm_end(result, run_id=run_id)
            props = mock_raindrop.track_ai.call_args.kwargs.get("properties", {})
            assert props["ai.finish_reason"] == "length"

    def test_no_finish_reason_omitted(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Test"], run_id=run_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            result = FakeLLMResult(text="Done", model="gpt-4o", prompt_tokens=10, completion_tokens=5)
            handler.on_llm_end(result, run_id=run_id)
            props = mock_raindrop.track_ai.call_args.kwargs.get("properties", {})
            assert props is not None
            assert "ai.finish_reason" not in props


class TestExtendedTokens:
    """Test extended token categories (cached_tokens, reasoning_tokens)."""

    def test_cached_and_reasoning_tokens_forwarded(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Test"], run_id=run_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            result = FakeLLMResult(
                text="Done", model="gpt-4o",
                prompt_tokens=100, completion_tokens=50,
                cached_tokens=30, reasoning_tokens=10,
            )
            handler.on_llm_end(result, run_id=run_id)
            props = mock_raindrop.track_ai.call_args.kwargs.get("properties", {})
            assert props["ai.usage.cached_tokens"] == 30
            assert props["ai.usage.thoughts_tokens"] == 10

    def test_no_extended_tokens_omitted(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Test"], run_id=run_id)

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            result = FakeLLMResult(text="Done", model="gpt-4o", prompt_tokens=10, completion_tokens=5)
            handler.on_llm_end(result, run_id=run_id)
            props = mock_raindrop.track_ai.call_args.kwargs.get("properties", {})
            assert "ai.usage.cached_tokens" not in props
            assert "ai.usage.thoughts_tokens" not in props


class TestTracingFlags:
    """Test that tracing_enabled and bypass_otel_for_tools are passed to init."""

    def test_init_passes_tracing_flags(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            RaindropLangchain(api_key="rk_test")
            mock_raindrop.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
                auto_instrument=False,
            )

    def test_init_passes_custom_tracing_flags(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            RaindropLangchain(
                api_key="rk_test",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )
            mock_raindrop.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
                auto_instrument=False,
            )

    def test_factory_passes_tracing_flags(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            create_raindrop_langchain(api_key="rk_test")
            mock_raindrop.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
                auto_instrument=False,
            )

    def test_factory_passes_custom_tracing_flags(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            create_raindrop_langchain(
                api_key="rk_test",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )
            mock_raindrop.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
                auto_instrument=False,
            )


class TestDebugFlag:
    """Test the debug=True constructor flag."""

    def test_debug_flag_stored_on_handler(self):
        handler = RaindropCallbackHandler(debug=True)
        assert handler._debug is True

    def test_debug_flag_default_false(self):
        handler = RaindropCallbackHandler()
        assert handler._debug is False

    def test_debug_flag_passed_through_wrapper(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            rl = RaindropLangchain(api_key="rk_test", debug=True)
            assert rl._debug is True
            assert rl.handler._debug is True

    def test_debug_flag_passed_through_factory(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            rl = create_raindrop_langchain(api_key="rk_test", debug=True)
            assert rl.handler._debug is True


class TestRaindropLangchain:
    """Test the top-level RaindropLangchain class."""

    def test_create_instance(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            rl = RaindropLangchain(api_key="rk_test", user_id="user-1")
            mock_raindrop.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
                auto_instrument=False,
            )
            assert isinstance(rl.handler, RaindropCallbackHandler)

    def test_handler_property_returns_callback_handler(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            rl = RaindropLangchain(api_key="rk_test", user_id="user-1")
            assert isinstance(rl.handler, RaindropCallbackHandler)
            assert rl.handler._user_id == "user-1"

    def test_flush_delegates(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            rl = RaindropLangchain(api_key="rk_test")
            rl.flush()
            mock_raindrop.flush.assert_called_once()

    def test_shutdown_delegates(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            rl = RaindropLangchain(api_key="rk_test")
            rl.shutdown()
            mock_raindrop.shutdown.assert_called_once()

    def test_identify_delegates(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            rl = RaindropLangchain(api_key="rk_test")
            rl.identify("user-1", {"name": "Alice", "plan": "pro"})
            mock_raindrop.identify.assert_called_once_with(
                user_id="user-1",
                traits={"name": "Alice", "plan": "pro"},
            )

    def test_track_signal_delegates(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            rl = RaindropLangchain(api_key="rk_test")
            rl.track_signal("evt-1", "thumbs_up", "feedback", sentiment="POSITIVE")
            mock_raindrop.track_signal.assert_called_once_with(
                event_id="evt-1",
                name="thumbs_up",
                signal_type="feedback",
                timestamp=None,
                properties=None,
                attachment_id=None,
                comment=None,
                after=None,
                sentiment="POSITIVE",
            )

    def test_convo_id_forwarded(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            rl = RaindropLangchain(api_key="rk_test", convo_id="convo-xyz")
            assert rl.handler._convo_id == "convo-xyz"

    def test_user_id_defaults_to_unknown(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            rl = RaindropLangchain(api_key="rk_test")
            assert rl._user_id == "unknown"
            assert rl.handler._user_id == "unknown"

    def test_empty_api_key_warns(self):
        """Empty api_key should produce a warnings.warn, not crash."""
        import warnings as _warnings

        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            with _warnings.catch_warnings(record=True) as w:
                _warnings.simplefilter("always")
                RaindropLangchain(api_key="")
                user_warnings = [x for x in w if not issubclass(x.category, DeprecationWarning)]
                assert len(user_warnings) == 1
                assert "api_key not provided" in str(user_warnings[0].message)

    def test_none_api_key_warns(self):
        """None api_key should produce a warnings.warn."""
        import warnings as _warnings

        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            with _warnings.catch_warnings(record=True) as w:
                _warnings.simplefilter("always")
                RaindropLangchain(api_key=None)
                user_warnings = [x for x in w if not issubclass(x.category, DeprecationWarning)]
                assert len(user_warnings) == 1
                assert "api_key not provided" in str(user_warnings[0].message)

    def test_identify_with_none_traits(self):
        """identify() with traits=None should default to empty dict."""
        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            rl = RaindropLangchain(api_key="rk_test")
            rl.identify("user-1")
            mock_raindrop.identify.assert_called_once_with(
                user_id="user-1",
                traits={},
            )

    def test_track_signal_all_params(self):
        """track_signal() should forward all params to raindrop.track_signal."""
        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            rl = RaindropLangchain(api_key="rk_test")
            rl.track_signal(
                event_id="evt-2",
                name="edited",
                signal_type="edit",
                timestamp="2026-01-01T00:00:00Z",
                properties={"key": "value"},
                attachment_id="att-1",
                comment="looks good",
                after="new text",
                sentiment="NEGATIVE",
            )
            mock_raindrop.track_signal.assert_called_once_with(
                event_id="evt-2",
                name="edited",
                signal_type="edit",
                timestamp="2026-01-01T00:00:00Z",
                properties={"key": "value"},
                attachment_id="att-1",
                comment="looks good",
                after="new text",
                sentiment="NEGATIVE",
            )

    def test_debug_sets_logger_level(self):
        """debug=True should set the logger level to DEBUG."""
        import logging

        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            RaindropLangchain(api_key="rk_test", debug=True)
            from raindrop_langchain.wrapper import logger
            assert logger.level == logging.DEBUG

    def test_getitem_backwards_compat_handler(self):
        """Dict-style raindrop["handler"] should still work with deprecation warning."""
        import warnings

        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            rl = RaindropLangchain(api_key="rk_test", user_id="user-1")
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                handler = rl["handler"]
                assert isinstance(handler, RaindropCallbackHandler)
                assert len(w) == 1
                assert issubclass(w[0].category, DeprecationWarning)
                assert "deprecated" in str(w[0].message).lower()

    def test_getitem_backwards_compat_flush(self):
        """Dict-style raindrop["flush"] should return the flush method."""
        import warnings

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            rl = RaindropLangchain(api_key="rk_test")
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                flush_fn = rl["flush"]
                flush_fn()
                mock_raindrop.flush.assert_called_once()

    def test_getitem_backwards_compat_shutdown(self):
        """Dict-style raindrop["shutdown"] should return the shutdown method."""
        import warnings

        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            rl = RaindropLangchain(api_key="rk_test")
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                shutdown_fn = rl["shutdown"]
                shutdown_fn()
                mock_raindrop.shutdown.assert_called_once()

    def test_getitem_invalid_key_raises(self):
        """Dict-style access with invalid key should raise KeyError."""
        import pytest

        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            rl = RaindropLangchain(api_key="rk_test")
            with pytest.raises(KeyError):
                rl["nonexistent"]


class TestCreateFactory:
    """Test the create_raindrop_langchain factory function."""

    def test_returns_raindrop_langchain_instance(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics") as mock_raindrop:
            result = create_raindrop_langchain(api_key="rk_test", user_id="user-1")

            assert isinstance(result, RaindropLangchain)
            assert isinstance(result.handler, RaindropCallbackHandler)

    def test_factory_with_convo_id(self):
        with patch("raindrop_langchain.wrapper._raindrop_analytics"):
            result = create_raindrop_langchain(
                api_key="test-write-key",
                user_id="user-1",
                convo_id="convo-xyz",
            )
            assert result.handler._convo_id == "convo-xyz"


class TestVersion:
    """Test that __version__ is exposed."""

    def test_version_exists(self):
        from raindrop_langchain import __version__
        assert isinstance(__version__, str)
        assert __version__ == "0.0.3"


class TestPyTyped:
    """Test that py.typed marker exists."""

    def test_py_typed_exists(self):
        import importlib.resources as resources
        # Just verify the package is importable with typed marker
        import raindrop_langchain
        assert hasattr(raindrop_langchain, "__version__")
