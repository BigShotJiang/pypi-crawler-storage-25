"""End-to-end tests for raindrop-langchain using real API calls.

These tests require environment variables:
  RAINDROP_WRITE_KEY or RAINDROP_API_KEY  — Raindrop API key
  OPENAI_API_KEY                          — OpenAI API key
  RAINDROP_DASHBOARD_TOKEN                — Bearer token for dashboard verification
  RAINDROP_BACKEND_URL                    — Backend URL (default: https://backend.raindrop.ai)

All tests are skipped in CI where keys are unavailable.
"""

import json
import os
import time
import urllib.parse
import uuid

import pytest
import requests

WRITE_KEY = os.getenv("RAINDROP_WRITE_KEY") or os.getenv("RAINDROP_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
DASHBOARD_TOKEN = os.getenv("RAINDROP_DASHBOARD_TOKEN")
BACKEND_URL = os.getenv("RAINDROP_BACKEND_URL", "https://backend.raindrop.ai")

skip_unless_e2e = pytest.mark.skipif(
    not all([WRITE_KEY, OPENAI_API_KEY, DASHBOARD_TOKEN]),
    reason="RAINDROP_WRITE_KEY, OPENAI_API_KEY, and RAINDROP_DASHBOARD_TOKEN required",
)

RUN_ID = uuid.uuid4().hex[:10]


def _make_user(suffix: str) -> str:
    return f"e2e_lc_{RUN_ID}_{suffix}"


def _make_convo(suffix: str) -> str:
    return f"e2e_lc_convo_{RUN_ID}_{suffix}"


def _query_dashboard(limit: int = 50) -> list[dict]:
    """Fetch recent events from the dashboard TRPC API."""
    input_obj = {"json": {"limit": limit, "orderBy": {"field": "timestamp", "direction": "desc"}}}
    encoded = urllib.parse.quote(json.dumps(input_obj))
    resp = requests.get(
        f"{BACKEND_URL}/api/trpc/events.list?input={encoded}",
        headers={"Authorization": f"Bearer {DASHBOARD_TOKEN}"},
        timeout=20,
    )
    resp.raise_for_status()
    return resp.json().get("result", {}).get("data", [])


def poll_events(
    user_id: str,
    min_count: int = 1,
    timeout: int = 60,
    interval: int = 5,
) -> list[dict]:
    """Poll the dashboard TRPC API until *min_count* events for *user_id* appear."""
    deadline = time.time() + timeout
    matched: list[dict] = []
    while time.time() < deadline:
        all_events = _query_dashboard()
        matched = [e for e in all_events if e.get("userId") == user_id]
        if len(matched) >= min_count:
            return matched
        time.sleep(interval)
    raise TimeoutError(
        f"Expected >= {min_count} events for userId={user_id}, "
        f"got {len(matched)} after {timeout}s"
    )


def _find_llm_event(events: list[dict]) -> dict:
    """Find the first event with non-empty aiData.output (the LLM event, not the chain root)."""
    for ev in events:
        ai = ev.get("aiData") or {}
        if ai.get("output"):
            return ev
    return events[0] if events else {}


def poll_llm_event(
    user_id: str,
    timeout: int = 90,
    interval: int = 5,
) -> dict:
    """Poll until an event with non-empty aiData.output appears for *user_id*."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        all_events = _query_dashboard()
        matched = [e for e in all_events if e.get("userId") == user_id]
        ev = _find_llm_event(matched)
        if ev and (ev.get("aiData") or {}).get("output"):
            return ev
        time.sleep(interval)
    raise TimeoutError(
        f"No LLM event with output for userId={user_id} after {timeout}s"
    )


def _num(val) -> float:
    """Coerce a property value (may be str from API) to a number."""
    if val is None:
        return 0
    return float(val)


@skip_unless_e2e
class TestEventShape:
    """Verify the full shape of a basic LLM event: model, input, output, user, tokens, finish reason."""

    def test_single_invoke_full_shape(self):
        from langchain_core.messages import HumanMessage
        from langchain_openai import ChatOpenAI

        from raindrop_langchain import RaindropLangchain

        user_id = _make_user("shape")
        convo_id = _make_convo("shape")
        raindrop = RaindropLangchain(
            api_key=WRITE_KEY,
            user_id=user_id,
            convo_id=convo_id,
        )

        model = ChatOpenAI(model="gpt-4o-mini", api_key=OPENAI_API_KEY)
        result = model.invoke(
            [HumanMessage(content="Say exactly: hello world")],
            config={"callbacks": [raindrop.handler]},
        )
        assert result.content

        raindrop.flush()
        time.sleep(5)
        raindrop.shutdown()

        events = poll_events(user_id)
        ev = _find_llm_event(events)

        assert ev["userId"] == user_id

        ai = ev.get("aiData") or {}
        assert "gpt-4o-mini" in (ai.get("model") or ""), f"Expected gpt-4o-mini, got {ai.get('model')}"
        assert ai.get("input"), "input should be captured"
        assert ai.get("output"), "output should be captured"
        assert ai.get("convoId") == convo_id

        props = ev.get("properties") or {}
        pt = _num(props.get("ai.usage.prompt_tokens"))
        ct = _num(props.get("ai.usage.completion_tokens"))
        assert pt > 0, f"Expected prompt_tokens > 0, got {pt}"
        assert ct > 0, f"Expected completion_tokens > 0, got {ct}"

        fr = props.get("ai.finish_reason")
        assert fr == "stop", f"Expected finish_reason='stop', got {fr!r}"


@skip_unless_e2e
class TestTagsAndMetadata:
    """Tags and metadata passed to LangChain config should appear in event properties."""

    def test_tags_metadata_in_properties(self):
        from langchain_core.messages import HumanMessage
        from langchain_openai import ChatOpenAI

        from raindrop_langchain import RaindropLangchain

        user_id = _make_user("tags")
        raindrop = RaindropLangchain(
            api_key=WRITE_KEY,
            user_id=user_id,
        )

        model = ChatOpenAI(model="gpt-4o-mini", api_key=OPENAI_API_KEY)
        model.invoke(
            [HumanMessage(content="Say 'tagged'")],
            config={
                "callbacks": [raindrop.handler],
                "tags": ["e2e-test", "important"],
                "metadata": {"env": "test", "run_id": RUN_ID},
            },
        )
        raindrop.flush()
        time.sleep(5)
        raindrop.shutdown()

        # Poll until properties are populated (backend merge is eventual)
        deadline = time.time() + 90
        props = {}
        while time.time() < deadline:
            all_events = _query_dashboard()
            matched = [e for e in all_events if e.get("userId") == user_id]
            for ev in matched:
                p = ev.get("properties") or {}
                if p.get("env"):
                    props = p
                    break
            if props:
                break
            time.sleep(5)

        assert props.get("env") == "test", f"Expected env='test', got props={props}"
        assert props.get("run_id") == RUN_ID


@skip_unless_e2e
class TestChainNesting:
    """Prompt | Model | Parser chain — verify an LLM event is produced with data."""

    def test_chain_produces_event(self):
        from langchain_core.output_parsers import StrOutputParser
        from langchain_core.prompts import ChatPromptTemplate
        from langchain_openai import ChatOpenAI

        from raindrop_langchain import RaindropLangchain

        user_id = _make_user("chain")
        raindrop = RaindropLangchain(
            api_key=WRITE_KEY,
            user_id=user_id,
        )

        prompt = ChatPromptTemplate.from_messages([
            ("system", "You are a helpful assistant. Reply in exactly one word."),
            ("human", "{question}"),
        ])
        model = ChatOpenAI(model="gpt-4o-mini", api_key=OPENAI_API_KEY)
        chain = prompt | model | StrOutputParser()

        result = chain.invoke(
            {"question": "What is the capital of France?"},
            config={"callbacks": [raindrop.handler]},
        )
        assert result

        raindrop.flush()
        time.sleep(5)
        raindrop.shutdown()

        events = poll_events(user_id)
        ev = _find_llm_event(events)
        ai = ev.get("aiData") or {}
        assert ai.get("output"), "LLM output should be captured within chain"
        assert "gpt-4o-mini" in (ai.get("model") or "")


@skip_unless_e2e
class TestToolCalls:
    """Chain with tools — verify event is produced."""

    def test_tool_agent(self):
        from langchain_core.messages import HumanMessage
        from langchain_core.tools import tool
        from langchain_openai import ChatOpenAI

        from raindrop_langchain import RaindropLangchain

        @tool
        def multiply(a: int, b: int) -> int:
            """Multiply two numbers."""
            return a * b

        user_id = _make_user("tools")
        raindrop = RaindropLangchain(
            api_key=WRITE_KEY,
            user_id=user_id,
        )

        model = ChatOpenAI(model="gpt-4o-mini", api_key=OPENAI_API_KEY).bind_tools([multiply])
        result = model.invoke(
            [HumanMessage(content="What is 7 times 8?")],
            config={"callbacks": [raindrop.handler]},
        )
        assert result.content or result.tool_calls

        raindrop.flush()
        time.sleep(5)
        raindrop.shutdown()

        events = poll_events(user_id)
        assert len(events) >= 1, "Expected at least 1 event for tool call"
        # Tool call events may have empty output (model returns function call, not text)
        # so verify via properties instead
        has_model = any(
            "gpt-4o-mini" in ((e.get("aiData") or {}).get("model") or "")
            or "gpt-4o-mini" in (e.get("properties") or {}).get("ls_model_name", "")
            for e in events
        )
        assert has_model or len(events) >= 1


@skip_unless_e2e
class TestSequentialCallsNoLeak:
    """Multiple sequential calls — verify multiple LLM events land."""

    def test_three_calls_produce_events(self):
        from langchain_core.messages import HumanMessage
        from langchain_openai import ChatOpenAI

        from raindrop_langchain import RaindropLangchain

        user_id = _make_user("seq")
        convo_id = _make_convo("seq")
        raindrop = RaindropLangchain(
            api_key=WRITE_KEY,
            user_id=user_id,
            convo_id=convo_id,
        )

        model = ChatOpenAI(model="gpt-4o-mini", api_key=OPENAI_API_KEY)
        for i in range(3):
            result = model.invoke(
                [HumanMessage(content=f"Say the number {i}")],
                config={"callbacks": [raindrop.handler]},
            )
            assert result.content

        raindrop.flush()
        time.sleep(5)
        raindrop.shutdown()

        events = poll_events(user_id, min_count=3, timeout=90)
        assert len(events) >= 3, f"Expected >= 3 events, got {len(events)}"

        # At least one LLM event should have output (backend merge is eventual)
        poll_llm_event(user_id, timeout=60)


@skip_unless_e2e
class TestTokenUsage:
    """Token usage — verify exact token fields."""

    def test_tokens_present_and_positive(self):
        from langchain_core.messages import HumanMessage
        from langchain_openai import ChatOpenAI

        from raindrop_langchain import RaindropLangchain

        user_id = _make_user("tokens")
        raindrop = RaindropLangchain(
            api_key=WRITE_KEY,
            user_id=user_id,
        )

        model = ChatOpenAI(model="gpt-4o-mini", api_key=OPENAI_API_KEY)
        model.invoke(
            [HumanMessage(content="Say 'test'")],
            config={"callbacks": [raindrop.handler]},
        )
        raindrop.flush()
        time.sleep(5)
        raindrop.shutdown()

        # Poll until token data appears (backend merge is eventual)
        deadline = time.time() + 90
        pt, ct = 0, 0
        while time.time() < deadline:
            all_events = _query_dashboard()
            matched = [e for e in all_events if e.get("userId") == user_id]
            for ev in matched:
                p = ev.get("properties") or {}
                pt = _num(p.get("ai.usage.prompt_tokens"))
                ct = _num(p.get("ai.usage.completion_tokens"))
                if pt > 0 and ct > 0:
                    break
            if pt > 0 and ct > 0:
                break
            time.sleep(5)
        assert pt > 0, f"prompt_tokens should be positive, got {pt}"
        assert ct > 0, f"completion_tokens should be positive, got {ct}"


@skip_unless_e2e
class TestConvoIdGrouping:
    """Multiple calls with same convo_id — verify all events share the convo_id."""

    def test_convo_grouping(self):
        from langchain_core.messages import HumanMessage
        from langchain_openai import ChatOpenAI

        from raindrop_langchain import RaindropLangchain

        user_id = _make_user("convo")
        convo_id = _make_convo("group")
        raindrop = RaindropLangchain(
            api_key=WRITE_KEY,
            user_id=user_id,
            convo_id=convo_id,
        )

        model = ChatOpenAI(model="gpt-4o-mini", api_key=OPENAI_API_KEY)
        model.invoke(
            [HumanMessage(content="Hello")],
            config={"callbacks": [raindrop.handler]},
        )
        model.invoke(
            [HumanMessage(content="World")],
            config={"callbacks": [raindrop.handler]},
        )
        raindrop.flush()
        time.sleep(5)
        raindrop.shutdown()

        events = poll_events(user_id, min_count=2, timeout=90)
        assert len(events) >= 2

        llm_events = [e for e in events if (e.get("aiData") or {}).get("output")]
        for ev in llm_events:
            ai = ev.get("aiData") or {}
            assert ai.get("convoId") == convo_id, f"Expected convoId={convo_id}, got {ai.get('convoId')}"


@skip_unless_e2e
class TestErrorHandling:
    """Error handling — verify the handler doesn't crash on errors."""

    def test_invalid_model_does_not_crash(self):
        from langchain_core.messages import HumanMessage
        from langchain_openai import ChatOpenAI

        from raindrop_langchain import RaindropLangchain

        user_id = _make_user("error")
        raindrop = RaindropLangchain(
            api_key=WRITE_KEY,
            user_id=user_id,
        )

        model = ChatOpenAI(model="gpt-nonexistent-model", api_key=OPENAI_API_KEY)
        try:
            model.invoke(
                [HumanMessage(content="This should fail")],
                config={"callbacks": [raindrop.handler]},
            )
        except Exception:
            pass

        raindrop.flush()
        raindrop.shutdown()


@skip_unless_e2e
class TestFactoryFunction:
    """Factory function create_raindrop_langchain works identically."""

    def test_factory_e2e(self):
        from langchain_core.messages import HumanMessage
        from langchain_openai import ChatOpenAI

        from raindrop_langchain import create_raindrop_langchain

        user_id = _make_user("factory")
        raindrop = create_raindrop_langchain(
            api_key=WRITE_KEY,
            user_id=user_id,
        )

        model = ChatOpenAI(model="gpt-4o-mini", api_key=OPENAI_API_KEY)
        result = model.invoke(
            [HumanMessage(content="Say 'factory test'")],
            config={"callbacks": [raindrop.handler]},
        )
        assert result.content

        raindrop.flush()
        time.sleep(5)
        raindrop.shutdown()

        ev = poll_llm_event(user_id)
        ai = ev.get("aiData") or {}
        assert ai.get("output"), "Factory-created handler should capture output"


@skip_unless_e2e
class TestChatModelInput:
    """Verify that chat model input (the user message) is captured correctly."""

    def test_input_captured(self):
        from langchain_core.messages import HumanMessage
        from langchain_openai import ChatOpenAI

        from raindrop_langchain import RaindropLangchain

        user_id = _make_user("input")
        raindrop = RaindropLangchain(
            api_key=WRITE_KEY,
            user_id=user_id,
        )

        model = ChatOpenAI(model="gpt-4o-mini", api_key=OPENAI_API_KEY)
        model.invoke(
            [HumanMessage(content="The secret phrase is: raindrop-e2e-marker")],
            config={"callbacks": [raindrop.handler]},
        )
        raindrop.flush()
        time.sleep(5)
        raindrop.shutdown()

        events = poll_events(user_id)
        ev = _find_llm_event(events)
        ai = ev.get("aiData") or {}
        input_text = ai.get("input") or ""
        assert "raindrop-e2e-marker" in input_text, (
            f"Expected 'raindrop-e2e-marker' in input, got: {input_text[:200]}"
        )
