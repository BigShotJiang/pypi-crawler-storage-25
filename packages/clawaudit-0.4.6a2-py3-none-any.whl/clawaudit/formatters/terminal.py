"""Rich terminal formatter."""

from typing import List

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text

from clawaudit import __version__
from clawaudit.formatters.base import BaseFormatter
from clawaudit.models.finding import Finding


SEVERITY_COLORS = {
    "CRITICAL": "red bold",
    "HIGH": "red",
    "MEDIUM": "yellow",
    "WARNING": "yellow",
    "INFO": "blue",
}

STATUS_ICONS = {
    "FAIL": "[red]FAIL[/red]",
    "PASS": "[green]PASS[/green]",
    "SKIP": "[dim]SKIP[/dim]",
    "ERROR": "[red]ERR [/red]",
}


class TerminalFormatter(BaseFormatter):
    def format(self, findings: List[Finding]) -> str:
        console = Console()

        # Summary counts
        total = len(findings)
        all_fails = [f for f in findings if f.status == "FAIL"]
        infos = [f for f in all_fails if f.severity.value == "INFO"]
        fails = [f for f in all_fails if f.severity.value != "INFO"]
        passes = [f for f in findings if f.status == "PASS"]
        skips = [f for f in findings if f.status == "SKIP"]

        criticals = [f for f in fails if f.severity.value == "CRITICAL"]
        highs = [f for f in fails if f.severity.value == "HIGH"]

        # Header
        console.print()
        console.print(Panel.fit(
            f"[bold]Foresight ClawAudit v{__version__} - OpenClaw Security Report[/bold]",
            border_style="cyan",
        ))
        console.print()

        # Score
        score = self._compute_score(findings)
        grade = self._grade(score)
        console.print(f"  Score: [bold]{score}/100[/bold] ({grade})")
        summary = (f"  Checks: {total} total, [green]{len(passes)} passed[/green], "
                   f"[red]{len(fails)} failed[/red]")
        if infos:
            summary += f", [blue]{len(infos)} info[/blue]"
        summary += f", [dim]{len(skips)} skipped[/dim]"
        console.print(summary)
        console.print()

        # Failed checks by severity
        if criticals:
            console.print("[red bold]CRITICAL[/red bold]")
            for f in criticals:
                console.print(f"  [red]>[/red] {f.check_id} {f.title}")
                if f.detail:
                    console.print(f"    [dim]{f.detail}[/dim]")
            console.print()

        if highs:
            console.print("[red]HIGH[/red]")
            for f in highs:
                console.print(f"  [red]>[/red] {f.check_id} {f.title}")
                if f.detail:
                    console.print(f"    [dim]{f.detail}[/dim]")
            console.print()

        warnings = [f for f in fails if f.severity.value in ("WARNING", "MEDIUM")]
        if warnings:
            console.print("[yellow]WARNING[/yellow]")
            for f in warnings:
                console.print(f"  [yellow]>[/yellow] {f.check_id} {f.title}")
                if f.detail:
                    console.print(f"    [dim]{f.detail}[/dim]")
            console.print()

        if infos:
            console.print("[blue]INFO[/blue]")
            for f in infos:
                console.print(f"  [blue]>[/blue] {f.check_id} {f.title}")
                if f.detail:
                    console.print(f"    [dim]{f.detail}[/dim]")
            console.print()

        # Passed checks
        if passes:
            console.print("[green]PASSED[/green]")
            for f in passes:
                console.print(f"  [green]>[/green] {f.check_id} {f.title}")
            console.print()

        return ""

    def _compute_score(self, findings: List[Finding]) -> int:
        score = 100
        for f in findings:
            if f.status != "FAIL":
                continue
            if f.severity.value == "CRITICAL":
                score -= 12
            elif f.severity.value == "HIGH":
                score -= 8
            elif f.severity.value in ("MEDIUM", "WARNING"):
                score -= 5
        return max(0, score)

    def _grade(self, score: int) -> str:
        if score >= 90:
            return "A"
        elif score >= 80:
            return "B"
        elif score >= 70:
            return "C"
        elif score >= 60:
            return "D"
        return "F"
