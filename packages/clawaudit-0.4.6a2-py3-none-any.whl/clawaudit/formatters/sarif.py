"""SARIF 2.1.0 formatter."""

import json
from typing import List, Dict, Any

from clawaudit import __version__
from clawaudit.formatters.base import BaseFormatter
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity

SARIF_SCHEMA = "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json"
SARIF_VERSION = "2.1.0"


class SarifFormatter(BaseFormatter):
    def format(self, findings: List[Finding]) -> str:
        rules = self._extract_rules(findings)
        results = [self._finding_to_result(f) for f in findings]

        sarif = {
            "$schema": SARIF_SCHEMA,
            "version": SARIF_VERSION,
            "runs": [
                {
                    "tool": {
                        "driver": {
                            "name": "clawaudit",
                            "version": __version__,
                            "rules": rules,
                        }
                    },
                    "results": results,
                }
            ],
        }
        return json.dumps(sarif, indent=2, ensure_ascii=False)

    def _extract_rules(self, findings: List[Finding]) -> List[Dict[str, Any]]:
        seen = set()
        rules = []
        for f in findings:
            if f.check_id in seen:
                continue
            seen.add(f.check_id)
            rules.append({
                "id": f.check_id,
                "shortDescription": {"text": f.title},
                "defaultConfiguration": {
                    "level": self._severity_to_level(f.severity),
                },
                "properties": {
                    "severity": f.severity.value,
                },
            })
        return rules

    def _finding_to_result(self, finding: Finding) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "ruleId": finding.check_id,
            "level": self._severity_to_level(finding.severity),
            "message": {"text": finding.detail or finding.title},
            "locations": [
                {
                    "physicalLocation": {
                        "artifactLocation": {
                            "uri": finding.check_id,
                        }
                    }
                }
            ],
            "properties": {
                "check_id": finding.check_id,
                "category": finding.category.value,
                "status": finding.status,
                "detail": finding.detail,
            },
        }
        return result

    def _severity_to_level(self, severity: Severity) -> str:
        if severity in (Severity.CRITICAL, Severity.HIGH):
            return "error"
        if severity in (Severity.MEDIUM, Severity.WARNING):
            return "warning"
        return "note"
