"""Output formatters."""

from clawaudit.formatters.base import BaseFormatter
from clawaudit.formatters.terminal import TerminalFormatter
from clawaudit.formatters.json_fmt import JsonFormatter
from clawaudit.formatters.sarif import SarifFormatter
from clawaudit.formatters.markdown import MarkdownFormatter


def get_formatter(name: str) -> BaseFormatter:
    formatters = {
        "terminal": TerminalFormatter,
        "json": JsonFormatter,
        "sarif": SarifFormatter,
        "markdown": MarkdownFormatter,
    }
    cls = formatters.get(name)
    if cls is None:
        raise ValueError(f"Unknown format: {name}")
    return cls()
