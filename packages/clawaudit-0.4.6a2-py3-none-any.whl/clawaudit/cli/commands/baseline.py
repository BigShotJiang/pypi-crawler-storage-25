"""clawaudit baseline command."""

import hashlib
import json
from pathlib import Path
from typing import Optional

import click

from clawaudit.config.discovery import OpenClawDiscovery

BASELINE_DIR = Path.home() / ".clawaudit" / "baselines"


@click.group()
def baseline():
    """Manage security baselines."""
    pass


@baseline.command()
@click.option("--path", default=None, help="OpenClaw install directory")
def init(path: Optional[str]):
    """Generate config + skill/MCP file SHA256 baseline."""
    discovery = OpenClawDiscovery(explicit_path=path)

    if not discovery.state_dir:
        click.echo("Error: No OpenClaw installation found.", err=True)
        raise SystemExit(1)

    state_dir = discovery.state_dir
    BASELINE_DIR.mkdir(parents=True, exist_ok=True)

    # Config file baseline
    config_lines = []
    for cf in discovery.config_files:
        sha = hashlib.sha256(cf.read_bytes()).hexdigest()
        config_lines.append(f"{sha}  {cf}")

    config_baseline = BASELINE_DIR / "config-baseline.sha256"
    config_baseline.write_text("\n".join(config_lines) + "\n")
    click.echo(f"Config baseline: {len(config_lines)} file(s) -> {config_baseline}")

    # Skill/MCP file baseline
    skill_mcp_lines = []
    for subdir_name in ("skills", "mcp"):
        subdir = state_dir / "workspace" / subdir_name
        if not subdir.is_dir():
            continue
        for f in sorted(subdir.rglob("*")):
            if f.is_file():
                sha = hashlib.sha256(f.read_bytes()).hexdigest()
                skill_mcp_lines.append(f"{sha}  {f}")

    skill_baseline = BASELINE_DIR / "skill-mcp-baseline.sha256"
    skill_baseline.write_text("\n".join(skill_mcp_lines) + "\n")
    click.echo(f"Skill/MCP baseline: {len(skill_mcp_lines)} file(s) -> {skill_baseline}")


@baseline.command()
@click.option("--path", default=None, help="OpenClaw install directory")
def mcp(path: Optional[str]):
    """Snapshot current MCP server tool list for rug pull detection."""
    discovery = OpenClawDiscovery(explicit_path=path)

    if not discovery.state_dir:
        click.echo("Error: No OpenClaw installation found.", err=True)
        raise SystemExit(1)

    BASELINE_DIR.mkdir(parents=True, exist_ok=True)

    tool_map: dict = {}
    for cf in discovery.config_files:
        if cf.suffix != ".json":
            continue
        try:
            data = json.loads(cf.read_text())
        except Exception:
            continue
        servers = data.get("mcpServers", {})
        if not isinstance(servers, dict):
            continue
        for server_name, server_cfg in servers.items():
            tools = server_cfg.get("tools", [])
            names = []
            if isinstance(tools, list):
                for tool in tools:
                    if isinstance(tool, dict):
                        names.append(tool.get("name", ""))
                    else:
                        names.append(str(tool))
            tool_map[server_name] = sorted(names)

    out_file = BASELINE_DIR / "mcp-tools-baseline.json"
    out_file.write_text(json.dumps(tool_map, indent=2) + "\n")
    click.echo(f"MCP tool baseline: {len(tool_map)} server(s) -> {out_file}")


@baseline.command()
def show():
    """Show current baseline status."""
    baselines = [
        ("Config baseline", BASELINE_DIR / "config-baseline.sha256"),
        ("Skill/MCP baseline", BASELINE_DIR / "skill-mcp-baseline.sha256"),
        ("MCP tool baseline", BASELINE_DIR / "mcp-tools-baseline.json"),
    ]

    for name, p in baselines:
        if p.is_file():
            import datetime
            mtime = p.stat().st_mtime
            ts = datetime.datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
            click.echo(f"  {name}: EXISTS (generated {ts})")
        else:
            click.echo(f"  {name}: NOT FOUND")
