"""clawaudit cvedb command."""

import click


@click.group()
def cvedb():
    """Manage CVE database."""
    pass


@cvedb.command()
def update():
    """Update local CVE database from GitHub Advisory."""
    from clawaudit.cvedb.fetcher import update_cvedb
    update_cvedb()


@cvedb.command(name="list")
@click.option("--severity", default=None, help="Filter by severity (e.g. critical, high)")
def list_cves(severity):
    """List advisories in local database."""
    from rich.console import Console
    from rich.table import Table
    from clawaudit.cvedb.matcher import load_cvedb

    cves = load_cvedb()
    if severity:
        cves = [c for c in cves if c.get("severity", "").upper() == severity.upper()]

    if not cves:
        click.echo("No advisories found.")
        return

    severity_colors = {
        "CRITICAL": "red bold",
        "HIGH": "red",
        "MEDIUM": "yellow",
        "LOW": "blue",
    }

    console = Console()
    console.print(f"\n[bold]OpenClaw CVE Database[/bold] ({len(cves)} advisories)\n")

    for entry in cves:
        sev = entry.get("severity", "?")
        style = severity_colors.get(sev, "")
        ghsa = entry.get("id", "")
        date = entry.get("published", "")
        affected = entry.get("affected", "")
        title = entry.get("title", "")
        sev_str = f"[{style}]{sev:8s}[/{style}]" if style else f"{sev:8s}"
        console.print(f"  [cyan]{ghsa}[/cyan]  {sev_str}  {date}  ({affected})")
        console.print(f"    {title}")
