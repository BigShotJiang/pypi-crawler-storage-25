"""CVE database updater — fetches from GitHub Advisory API."""

import os
from pathlib import Path
from typing import List, Dict, Any

import click
import requests
import yaml

from clawaudit.cvedb.matcher import load_cvedb

GITHUB_API = "https://api.github.com/advisories"
USER_CVE_DB = Path.home() / ".clawaudit" / "cvedb" / "openclaw_cves.yaml"


def update_cvedb():
    """Update local CVE database from GitHub Advisory."""
    click.echo("Updating CVE database from GitHub Advisory...")

    existing = load_cvedb()
    existing_ids = {c.get("id", "") for c in existing}

    try:
        fetched = _fetch_github()
    except Exception as e:
        click.echo(f"  GitHub Advisory fetch failed: {e}", err=True)
        return

    added = 0
    for entry in fetched:
        if entry["id"] not in existing_ids:
            existing.append(entry)
            existing_ids.add(entry["id"])
            added += 1

    # Sort by published date descending (newest first)
    existing.sort(key=lambda e: e.get("published", ""), reverse=True)

    _save_cvedb(existing)
    click.echo(f"Updated: {added} new advisories added, {len(existing)} total")


def _fetch_github() -> List[Dict[str, Any]]:
    """Fetch all OpenClaw advisories from GitHub Advisory Database API."""
    results = []
    headers = {"Accept": "application/vnd.github+json"}

    token = os.environ.get("GITHUB_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"

    url = f"{GITHUB_API}?affects=openclaw&per_page=100&ecosystem=npm"

    while url:
        resp = requests.get(url, headers=headers, timeout=30)
        resp.raise_for_status()
        advisories = resp.json()

        for adv in advisories:
            ghsa_id = adv.get("ghsa_id", "")
            if not ghsa_id:
                continue

            cve_id = adv.get("cve_id", "")
            title = adv.get("summary", "")
            severity = _normalize_severity(adv.get("severity", "MEDIUM"))
            cvss = adv.get("cvss", {}).get("score") if adv.get("cvss") else None
            published = (adv.get("published_at") or "")[:10]

            # Merge all vulnerability ranges with || (OR)
            vulns = adv.get("vulnerabilities", [])
            ranges = []
            for v in vulns:
                vr = v.get("vulnerable_version_range", "")
                if vr:
                    ranges.append(vr)
            affected = " || ".join(ranges) if ranges else ""

            entry: Dict[str, Any] = {
                "id": ghsa_id,
                "affected": affected,
                "severity": severity,
                "title": title,
                "url": f"https://github.com/advisories/{ghsa_id}",
                "published": published,
            }
            if cve_id:
                entry["cve"] = cve_id
            if cvss is not None:
                entry["cvss"] = cvss
            results.append(entry)

        # Follow pagination via Link header
        url = _parse_next_link(resp.headers.get("Link", ""))

    return results


def _parse_next_link(link_header: str):
    """Extract next page URL from Link header."""
    if not link_header:
        return None
    for part in link_header.split(","):
        if 'rel="next"' in part:
            try:
                return part.split("<")[1].split(">")[0]
            except (IndexError, ValueError):
                return None
    return None


def _normalize_severity(sev: str) -> str:
    return sev.strip().upper()


def _save_cvedb(cves: List[Dict[str, Any]]):
    """Write CVE database to user directory (~/.clawaudit/cvedb/)."""
    USER_CVE_DB.parent.mkdir(parents=True, exist_ok=True)
    try:
        with open(USER_CVE_DB, "w", encoding="utf-8") as f:
            yaml.dump(cves, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
    except OSError as e:
        click.echo(f"  Warning: could not save CVE database: {e}", err=True)
