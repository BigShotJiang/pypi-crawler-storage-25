"""Finding model for scan results."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, TYPE_CHECKING

if TYPE_CHECKING:
    from clawaudit.fixers.actions import FixAction

from clawaudit.models.severity import Severity, Category


@dataclass
class Finding:
    """A single security finding."""
    check_id: str           # e.g. "PA-NET01"
    title: str
    severity: Severity
    category: Category
    status: str             # "FAIL", "PASS", "SKIP", "ERROR"
    description: str = ""
    detail: str = ""        # additional context / evidence
    remediation: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    fix_actions: List[FixAction] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "check_id": self.check_id,
            "title": self.title,
            "severity": self.severity.value,
            "category": self.category.value,
            "status": self.status,
            "description": self.description,
            "detail": self.detail,
            "remediation": self.remediation,
            "metadata": self.metadata,
        }
