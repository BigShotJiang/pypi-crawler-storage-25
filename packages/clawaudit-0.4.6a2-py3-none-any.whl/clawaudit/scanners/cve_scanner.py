"""PA-CVE* — Known vulnerability scanner."""

from typing import List, Optional

from clawaudit.scanners.base import BaseScanner
from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity, Category


class CveScanner(BaseScanner):
    category = Category.CVE
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []

        # Skip if user specified checks and none are CVE-related
        if checks and not any(c.startswith("PA-CVE") for c in checks):
            return self.findings

        version = self.discovery.version

        if not version:
            self.skip("PA-CVE00", "CVE version matching", Severity.HIGH,
                      "Cannot determine OpenClaw version")
            return self.findings

        from clawaudit.cvedb.matcher import match_version

        matched = match_version(version)
        if not matched:
            self.add_finding("PA-CVE00", "CVE version matching", Severity.HIGH, "PASS",
                             detail=f"Version {version}: no known CVEs")
            return self.findings

        sev_map = {
            "CRITICAL": Severity.CRITICAL,
            "HIGH": Severity.HIGH,
            "MEDIUM": Severity.MEDIUM,
            "LOW": Severity.WARNING,
        }

        cve_labels = []
        for cve in matched:
            severity = sev_map.get(cve.get("severity", "").upper(), Severity.HIGH)
            check_id = cve.get("cve") or cve.get("id", "PA-CVE00")
            label = cve.get("cve", cve.get("id", "unknown"))
            cve_labels.append(label)
            self.add_finding(
                check_id=check_id,
                title=cve.get("title", ""),
                severity=severity,
                status="FAIL",
                detail=f"Affected: {cve.get('affected', '')} | CVSS: {cve.get('cvss', '?')} | Ref: {cve.get('url', 'N/A')}",
                remediation=f"Upgrade OpenClaw to fix {label}",
            )

        # Single consolidated FixAction for all CVEs
        if cve_labels:
            self.findings[-1].fix_actions = [
                FixAction(
                    description="Upgrade OpenClaw to fix known CVEs",
                    fix_type="manual",
                    manual_steps=(
                        f"OpenClaw {version} is affected by {len(cve_labels)} known CVE(s). "
                        f"Upgrade to the latest version to fix all of them."
                    ),
                ),
            ]

        return self.findings
