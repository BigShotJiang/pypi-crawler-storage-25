"""PA-SC* — Supply chain security scanner."""

import hashlib
import json
import platform
import re
from pathlib import Path
from typing import List, Optional, Set

from clawaudit.scanners.base import BaseScanner
from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity, Category


class ScScanner(BaseScanner):
    category = Category.SC
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        all_checks = {
            "PA-SC01": self._sc01_skill_source,
            "PA-SC02": self._sc02_file_integrity,
            "PA-SC03": self._sc03_tool_description_poison,
            "PA-SC04": self._sc04_axios_compromise,
        }
        return self._dispatch(all_checks, checks)

    def _load_clawhub_skills(self, lock_files: List[Path]) -> Set[str]:
        """Load skill names from .clawhub/lock.json files."""
        clawhub_skills: Set[str] = set()
        for lock_file in lock_files:
            try:
                lock_data = json.loads(lock_file.read_text(errors="ignore"))
                if isinstance(lock_data, dict):
                    clawhub_skills.update(lock_data.keys())
            except Exception:
                pass
        return clawhub_skills

    # ------------------------------------------------------------------
    # PA-SC01: Skill source not verified
    # ------------------------------------------------------------------
    def _sc01_skill_source(self, needs):
        check_id = "PA-SC01"
        title = "Third-party skill from unverified source"
        remediation = needs.get("remediation", "")

        skills_match = self._get_match(needs, "skills_dirs")
        lock_match = self._get_match(needs, "clawhub_lock_files")
        skills_dirs = skills_match.get("paths", [])
        if not skills_dirs:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail="No skills directory found")
            return

        clawhub_skills = self._load_clawhub_skills(lock_match.get("paths", []))

        unverified = []
        seen = set()
        for skills_dir in skills_dirs:
            if not skills_dir.is_dir():
                continue
            for skill in skills_dir.iterdir():
                if not skill.is_dir() or skill.name in seen:
                    continue
                seen.add(skill.name)
                has_git = (skill / ".git").exists()
                in_clawhub = skill.name in clawhub_skills
                if not has_git and not in_clawhub:
                    unverified.append((skill.name, str(skill)))

        if unverified:
            names = ", ".join(u[0] for u in unverified)
            fix_steps = (
                f"Unverified skill(s): {names}\n"
                "Step 1: Review each skill to determine if it is trustworthy.\n"
                "Step 2: Remove untrusted skills:\n"
                + "".join(f"  rm -rf {u[1]}\n" for u in unverified)
                + "Step 3: Reinstall needed skills from ClawHub or verified Git repos:\n"
                "  clawhub install <skill-name>"
            )
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Skills without verified source: {names}",
                             remediation=remediation or "Only install skills from ClawHub or verified Git repositories",
                             fix_actions=[
                                 FixAction(
                                     description="Remove unverified skills",
                                     fix_type="manual",
                                     manual_steps=fix_steps,
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-SC02: Skill file integrity
    # ------------------------------------------------------------------
    def _sc02_file_integrity(self, needs):
        check_id = "PA-SC02"
        title = "Skill file integrity deviation"
        remediation = needs.get("remediation", "")

        match = self._get_match(needs)
        match_paths = match.get("paths", [])
        if not match_paths:
            self.skip(check_id, title, Severity.HIGH,
                      "No baseline directory configured")
            return
        baseline_file = match_paths[0] / "skill-mcp-baseline.sha256"

        if not baseline_file.is_file():
            self.skip(check_id, title, Severity.HIGH,
                      "No baseline file found. Run: clawaudit baseline init")
            return

        try:
            raw = baseline_file.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            self.skip(check_id, title, Severity.HIGH,
                      "Cannot read baseline file")
            return

        baseline_data = {}
        for line in raw.splitlines():
            parts = line.split(maxsplit=1)
            if len(parts) == 2 and len(parts[0]) == 64:
                baseline_data[parts[1]] = parts[0]

        if not baseline_data:
            self.skip(check_id, title, Severity.HIGH,
                      "Baseline file is empty or corrupted. Run: clawaudit baseline init")
            return

        changed = []
        for path_str, expected in baseline_data.items():
            p = Path(path_str)
            if not p.is_file():
                changed.append(f"missing: {path_str}")
                continue
            actual = hashlib.sha256(p.read_bytes()).hexdigest()
            if actual != expected:
                changed.append(f"modified: {path_str}")

        if changed:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail="; ".join(changed),
                             remediation=remediation or "Investigate file changes, update baseline if legitimate",
                             fix_actions=[
                                 FixAction(
                                     description="Review skill file integrity changes",
                                     fix_type="manual",
                                     manual_steps=(
                                         f"Detected {len(changed)} skill file(s) changed from baseline:\n"
                                         + "\n".join(f"  - {c}" for c in changed) + "\n"
                                         "Step 1: Review each changed/missing file to confirm changes are intentional.\n"
                                         "Step 2: If a skill has been tampered with, remove it:\n"
                                         "  rm -rf <skill-directory>\n"
                                         "Step 3: Reinstall from ClawHub: clawhub install <skill-name>\n"
                                         "Step 4: If changes are legitimate, update baseline: clawaudit baseline init"
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-SC03: Skill description poisoning
    # ------------------------------------------------------------------
    def _sc03_tool_description_poison(self, needs):
        check_id = "PA-SC03"
        title = "Skill description contains hidden instructions"
        remediation = needs.get("remediation", "")

        # Collect patterns from all match entries
        suspicious_patterns = []
        skills_dirs = []
        for m in needs.get("match", []):
            suspicious_patterns.extend(m.get("patterns", []))
            if m.get("name") == "skills":
                skills_dirs.extend(m.get("paths", []))

        hits = []
        skill_paths = {}

        # Scan SKILL.md and scripts/ in all skill directories
        for skills_dir in skills_dirs:
            if not skills_dir.is_dir():
                continue
            for skill_dir in skills_dir.iterdir():
                if not skill_dir.is_dir():
                    continue
                # Collect files to scan: SKILL.md + scripts/*
                files_to_scan = []
                skill_md = skill_dir / "SKILL.md"
                if skill_md.is_file():
                    files_to_scan.append(skill_md)
                scripts_dir = skill_dir / "scripts"
                if scripts_dir.is_dir():
                    files_to_scan.extend(
                        f for f in scripts_dir.rglob("*") if f.is_file()
                    )
                if not files_to_scan:
                    continue
                found = False
                for f in files_to_scan:
                    if found:
                        break
                    try:
                        text = f.read_text(encoding="utf-8", errors="ignore")
                    except OSError:
                        continue
                    for pat in suspicious_patterns:
                        if re.search(pat, text, re.IGNORECASE):
                            if skill_dir.name not in skill_paths:
                                hits.append(skill_dir.name)
                                skill_paths[skill_dir.name] = str(skill_dir)
                            found = True
                            break

        if hits:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Suspicious instructions in skill(s): {', '.join(hits)}",
                             remediation=remediation or "Remove skills with hidden prompt injection instructions",
                             fix_actions=[
                                 FixAction(
                                     description="Remove skills with hidden instructions",
                                     fix_type="manual",
                                     manual_steps=(
                                         f"Suspicious prompt injection patterns found in skill(s): {', '.join(hits)}\n"
                                         "Step 1: Review each skill's SKILL.md for hidden instructions:\n"
                                         + "".join(f"  cat {skill_paths[h]}/SKILL.md\n" for h in hits)
                                         + "Step 2: Remove malicious skills:\n"
                                         + "".join(f"  rm -rf {skill_paths[h]}\n" for h in hits)
                                         + "Step 3: Report malicious skills to ClawHub."
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-SC04: Axios supply-chain compromise
    # ------------------------------------------------------------------
    def _sc04_axios_compromise(self, needs):
        check_id = "PA-SC04"
        title = "Axios supply-chain compromise (axios 1.14.1 / 0.30.4)"
        remediation = needs.get("remediation", "")

        compromised = needs.get("compromised_versions", ["1.14.1", "0.30.4"])
        malicious_pkgs = needs.get("malicious_packages", ["plain-crypto-js"])

        issues = []

        # --- Check 1: Lockfiles contain compromised axios versions ---
        lock_match = self._get_match(needs, "lockfiles")
        for lock_path in lock_match.get("paths", []):
            if not lock_path.is_file():
                continue
            try:
                content = lock_path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for ver in compromised:
                pattern = rf'"axios":\s*"[^"]*{re.escape(ver)}'
                if re.search(pattern, content):
                    issues.append(f"axios@{ver} in {lock_path.name}")
                    break
            for pkg in malicious_pkgs:
                if pkg in content:
                    issues.append(f"malicious dependency '{pkg}' in {lock_path.name}")

        # --- Check 2: node_modules contains malicious packages ---
        nm_match = self._get_match(needs, "node_modules")
        for nm_dir in nm_match.get("paths", []):
            if not nm_dir.is_dir():
                continue
            for pkg in malicious_pkgs:
                if (nm_dir / pkg).is_dir():
                    issues.append(f"malicious package '{pkg}' installed in {nm_dir}")
            # Check installed axios version via package.json
            axios_pkg = nm_dir / "axios" / "package.json"
            if axios_pkg.is_file():
                try:
                    pkg_data = json.loads(axios_pkg.read_text(errors="ignore"))
                    ver = pkg_data.get("version", "")
                    if ver in compromised:
                        issues.append(f"axios@{ver} installed in {nm_dir}")
                except Exception:
                    pass

        # --- Check 3: RAT artifacts on disk ---
        os_key = platform.system().lower()
        rat_paths = needs.get("rat_artifacts", {}).get(os_key, [])
        for rat_path in rat_paths:
            p = Path(rat_path)
            if p.is_file():
                issues.append(f"RAT artifact found: {rat_path}")

        if issues:
            detail = "; ".join(issues)
            self.add_finding(
                check_id, title, Severity.CRITICAL, "FAIL",
                detail=detail,
                remediation=remediation,
                fix_actions=[
                    FixAction(
                        description="Remediate axios supply-chain compromise",
                        fix_type="manual",
                        manual_steps=(
                            f"Detected: {detail}\n"
                            "Step 1: Pin axios to a safe version: npm install axios@1.14.0 --save-exact\n"
                            "Step 2: rm -rf node_modules && npm ci\n"
                            "Step 3: Rotate ALL credentials (npm tokens, AWS keys, SSH keys, API keys, .env)\n"
                            "Step 4: Block C2 IP 142.11.206.73 and domain sfrclak.com at firewall\n"
                            "Step 5: If RAT artifacts found, perform a full system rebuild\n"
                            "Ref: https://cloud.google.com/blog/topics/threat-intelligence/"
                            "north-korea-threat-actor-targets-axios-npm-package/"
                        ),
                    ),
                ],
            )
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS",
                             detail="No compromised axios versions or artifacts detected")
