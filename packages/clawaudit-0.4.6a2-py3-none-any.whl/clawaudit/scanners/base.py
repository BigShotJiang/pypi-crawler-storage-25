"""Base scanner class."""

from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Optional, Tuple

from clawaudit.config.discovery import OpenClawDiscovery
from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity, Category


class BaseScanner(ABC):
    """Base class for all scanners."""

    category: Category
    mode: str = "local"  # "local", "remote", "both"

    def __init__(self, discovery: OpenClawDiscovery, target: str = "", port: int = 18789):
        self.discovery = discovery
        self.target = target
        self.port = port
        self.findings: List[Finding] = []

    def add_finding(
        self,
        check_id: str,
        title: str,
        severity: Severity,
        status: str,
        description: str = "",
        detail: str = "",
        remediation: str = "",
        fix_actions: Optional[List[FixAction]] = None,
        **metadata,
    ) -> Finding:
        finding = Finding(
            check_id=check_id,
            title=title,
            severity=severity,
            category=self.category,
            status=status,
            description=description,
            detail=detail,
            remediation=remediation,
            metadata=metadata,
            fix_actions=fix_actions or [],
        )
        self.findings.append(finding)
        return finding

    def skip(self, check_id: str, title: str, severity: Severity, reason: str) -> Finding:
        return self.add_finding(
            check_id=check_id,
            title=title,
            severity=severity,
            status="SKIP",
            detail=reason,
        )

    def _dispatch(
        self,
        all_checks: Dict[str, Callable],
        checks: Optional[List[str]] = None,
    ) -> List[Finding]:
        """Standard dispatch: resolve files_for() per check, call fn(needs).

        Each check function receives a *needs* dict from
        ``self.discovery.files_for(check_id)``.
        """
        self.findings = []
        for check_id, fn in all_checks.items():
            if checks and check_id not in checks:
                continue
            needs = self.discovery.files_for(check_id)
            fn(needs)
        return self.findings

    # ------------------------------------------------------------------
    # Match helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _get_match(needs: Dict[str, Any], name: str = "") -> Dict[str, Any]:
        """Get a match entry by name, or the first entry if name is empty."""
        for m in needs.get("match", []):
            if not name or m.get("name") == name:
                return m
        return {"type": "text", "paths": []}

    @staticmethod
    def _resolve_keypaths(
        data: dict, keypath: str,
    ) -> List[Tuple[str, Any]]:
        """Resolve a dot-delimited keypath with ``*`` wildcards against a dict.

        Returns a list of ``(display_path, value)`` tuples.  A ``*`` segment
        iterates all keys at that level.

        Example::

            _resolve_keypaths(config, "channels.*.accounts.*.botToken")
            # → [("channels.telegram.accounts.main.botToken", "tok_abc"), ...]
        """
        parts = keypath.split(".")
        # Stack: (current_data, remaining_parts, display_parts_so_far)
        stack: List[Tuple[Any, List[str], List[str]]] = [(data, parts, [])]
        results: List[Tuple[str, Any]] = []

        while stack:
            current, remaining, display = stack.pop()
            if not remaining:
                results.append((".".join(display), current))
                continue
            key, *rest = remaining
            if not isinstance(current, dict):
                continue
            if key == "*":
                for k, v in current.items():
                    stack.append((v, rest, display + [k]))
            else:
                val = current.get(key)
                if val is not None:
                    stack.append((val, rest, display + [key]))

        return results

    @abstractmethod
    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        """Run scans. If checks is given, only run those check IDs."""
        ...
