"""PA-AUTH* — Authentication & authorization scanner."""

import re
import secrets
from typing import List, Optional

from clawaudit.scanners.base import BaseScanner
from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity, Category


class AuthScanner(BaseScanner):
    category = Category.AUTH
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        all_checks = {
            "PA-AUTH01": self._auth01_default_creds,
            "PA-AUTH02": self._auth02_ui_bypass,
        }
        return self._dispatch(all_checks, checks)

    # ------------------------------------------------------------------
    # PA-AUTH01: Default/weak credentials
    # ------------------------------------------------------------------
    def _auth01_default_creds(self, needs):
        check_id = "PA-AUTH01"
        title = "Default/weak credentials"
        found = False

        weak_values = {v.lower() for v in needs.get("weak_values", [])}
        min_len = needs.get("thresholds", {}).get("min_credential_length", 8)

        for m in needs.get("match", []):
            if m.get("type") != "json":
                continue
            keypaths = m.get("keypaths", [])
            for f in m.get("paths", []):
                if f.suffix != ".json":
                    continue
                try:
                    config = self.discovery.read_config(f)
                except Exception:
                    continue
                if not isinstance(config, dict):
                    continue

                for kp in keypaths:
                    for display, value in self._resolve_keypaths(config, kp):
                        if value is None or not isinstance(value, str):
                            continue
                        # Skip env var references
                        if value.startswith("${") or value.startswith("$"):
                            continue

                        keys = tuple(display.split("."))
                        is_agent_profile = "auth-profiles" in f.name

                        if is_agent_profile:
                            # Agent auth profiles: check sibling keyRef/tokenRef
                            provider_name = keys[-2] if len(keys) >= 2 else "provider"
                            # Navigate to parent dict to check for Ref sibling
                            parent = config
                            for k in keys[:-1]:
                                parent = parent.get(k, {}) if isinstance(parent, dict) else {}
                            field_name = keys[-1] if keys else ""
                            ref_key = field_name.replace("apiKey", "keyRef").replace("token", "tokenRef")
                            has_ref = bool(parent.get(ref_key)) if isinstance(parent, dict) else False
                            finding = self._check_agent_cred(
                                check_id, title, f, display, value,
                                provider_name, has_ref=has_ref,
                                weak_values=weak_values, min_len=min_len,
                            )
                        else:
                            finding = self._check_cred_value(
                                check_id, title, f, display, value, keys,
                                weak_values=weak_values, min_len=min_len,
                            )
                        if finding:
                            found = True

        if not found:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    def _check_agent_cred(self, check_id, title, filepath, display, value,
                          provider_name, has_ref=False, weak_values=None, min_len=8):
        """Check an agent auth-profiles.json credential. Returns True if FAIL.

        Unlike gateway credentials, these are third-party provider keys
        that cannot be auto-replaced — only manual remediation is offered.
        """
        if weak_values is None:
            weak_values = set()

        is_weak = value.lower() in weak_values
        is_short = len(value) <= min_len - 1

        if not is_weak and not is_short and not has_ref:
            # Plaintext but not weak/short — suggest SecretRef migration
            self.add_finding(check_id, title, Severity.MEDIUM, "FAIL",
                             detail=f"Plaintext credential ({display}) in {filepath.name}",
                             remediation=f"Replace plaintext apiKey with a SecretRef to avoid storing secrets in config files",
                             fix_actions=[
                                 FixAction(
                                     description=f"Migrate {display} to SecretRef",
                                     fix_type="manual",
                                     manual_steps=(
                                         f"Replace the plaintext key in {filepath} with a SecretRef:\n"
                                         f'  "keyRef": {{"source": "env", "id": "{provider_name.upper()}_API_KEY"}}\n'
                                         f"Then set the environment variable {provider_name.upper()}_API_KEY "
                                         f"to the actual key value."
                                     ),
                                 ),
                             ])
            return True

        if has_ref:
            return False

        if not is_weak and not is_short:
            return False

        if is_weak:
            detail = f"Weak credential ({display}={value}) in {filepath.name}"
        else:
            detail = f"{display} too short ({len(value)} chars) in {filepath.name}"

        self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                         detail=detail,
                         remediation=f"Generate a new API key from {provider_name}'s dashboard and update {filepath.name}",
                         fix_actions=[
                             FixAction(
                                 description=f"Replace weak {display}",
                                 fix_type="manual",
                                 manual_steps=(
                                     f"1. Go to {provider_name}'s API dashboard and generate a new key\n"
                                     f"2. Update {filepath} with the new key, or better yet, use a SecretRef:\n"
                                     f'   "keyRef": {{"source": "env", "id": "{provider_name.upper()}_API_KEY"}}\n'
                                     f"3. Revoke the old key from {provider_name}'s dashboard"
                                 ),
                             ),
                         ])
        return True

    def _check_cred_value(self, check_id, title, f, display, value, keys,
                          weak_values=None, min_len=8):
        """Check if a credential value is weak or too short. Returns True if FAIL."""
        import json as _json

        if weak_values is None:
            weak_values = set()

        is_weak = value.lower() in weak_values
        is_short = len(value) <= min_len - 1

        if not is_weak and not is_short:
            return False

        new_token = secrets.token_urlsafe(32)
        if is_weak:
            detail = f"Weak credential ({display}={value}) in {f.name}"
            remediation = "Set a strong, unique token (>= 16 chars)"
        else:
            detail = f"{display} too short ({len(value)} chars) in {f.name}"
            remediation = "Use a credential with at least 16 characters"

        # Build fix: read JSON, set new value at known path, write back
        fix_actions = [
            FixAction(
                description=f"Replace {display} in {f.name}",
                fix_type="json_path_edit",
                target_file=str(f),
                old_value=_json.dumps(list(keys)),  # store path as JSON array
                new_value=new_token,
            ),
            FixAction(
                description=f"Sync {display} to other services",
                fix_type="manual",
                manual_steps=f"{display} in {f.name} was auto-replaced. Check the new value in {f.name} and update any clients that use this credential.",
            ),
        ]

        self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                         detail=detail, remediation=remediation,
                         fix_actions=fix_actions)
        return True

    # ------------------------------------------------------------------
    # PA-AUTH02: Control UI auth bypass
    # ------------------------------------------------------------------
    def _auth02_ui_bypass(self, needs):
        check_id = "PA-AUTH02"
        title = "Control UI auth bypass enabled"
        found = False

        bypass_flags = needs.get("bypass_flags", [])
        remediation = needs.get("remediation", "")
        match = self._get_match(needs)

        for bf in bypass_flags:
            flag = bf["flag"]
            desc = bf["description"]
            pattern = re.compile(
                rf'(["\']?{flag}["\']?\s*[:=]\s*)(true|yes|1)',
                re.IGNORECASE,
            )
            for f in match.get("paths", []):
                try:
                    text = f.read_text(encoding="utf-8", errors="ignore")
                except OSError:
                    continue
                m = pattern.search(text)
                if m:
                    self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                                     detail=f"{flag} is enabled in {f.name} — {desc}",
                                     remediation=remediation or f"Set {flag} to false",
                                     fix_actions=[
                                         FixAction(
                                             description=f"Set {flag} to false in {f.name}",
                                             fix_type="file_edit",
                                             target_file=str(f),
                                             old_value=m.group(0),
                                             new_value=m.group(1) + "false",
                                         ),
                                     ])
                    found = True

        if not found:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")
