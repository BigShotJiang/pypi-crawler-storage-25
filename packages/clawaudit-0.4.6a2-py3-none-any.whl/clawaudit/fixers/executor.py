"""FixExecutor — previews, executes, and logs auto-fix actions."""

import hashlib
import json
import subprocess
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any

from rich.console import Console
from rich.table import Table

from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding

HISTORY_DIR = Path.home() / ".clawaudit" / "fix-history"


class FixResult:
    """Result of a single fix action execution."""

    def __init__(self, action: FixAction, check_id: str, success: bool, message: str = ""):
        self.action = action
        self.check_id = check_id
        self.success = success
        self.message = message


class FixExecutor:
    """Preview, execute, and log fix actions from scan findings."""

    def __init__(self):
        self.console = Console(stderr=True)

    def collect_fixable(self, findings: List[Finding]) -> List[Finding]:
        """Return FAIL findings that have at least one fix_action."""
        return [f for f in findings if f.status == "FAIL" and f.fix_actions]

    def has_auto_actions(self, findings: List[Finding]) -> bool:
        """Check if there are any auto-fixable (non-manual) actions."""
        for f in self.collect_fixable(findings):
            for a in f.fix_actions:
                if a.fix_type != "manual":
                    return True
        return False

    def preview(self, findings: List[Finding]) -> None:
        """Print auto-fix plan table (manual actions shown separately after execution)."""
        auto_actions = []
        for f in self.collect_fixable(findings):
            for a in f.fix_actions:
                if a.fix_type != "manual":
                    auto_actions.append((f, a))

        if auto_actions:
            table = Table(title="Auto-fix plan", show_lines=True)
            table.add_column("Check", style="cyan", width=12)
            table.add_column("Type", width=10)
            table.add_column("Description")
            for f, a in auto_actions:
                table.add_row(f.check_id, a.fix_type, a.description)
            self.console.print(table)
            self.console.print()

    def execute(self, findings: List[Finding]) -> List[FixResult]:
        """Execute all auto-fixable actions. Returns list of results."""
        results: List[FixResult] = []
        fixable = self.collect_fixable(findings)

        for f in fixable:
            for action in f.fix_actions:
                if action.fix_type == "file_edit":
                    result = self._apply_file_edit(action, f.check_id)
                elif action.fix_type == "json_path_edit":
                    result = self._apply_json_path_edit(action, f.check_id)
                elif action.fix_type == "command":
                    result = self._apply_command(action, f.check_id)
                else:
                    # manual — skip execution, will be shown in todo list
                    continue
                results.append(result)

        self._save_history(results)
        return results

    def print_results(self, results: List[FixResult]) -> None:
        """Print execution results to the terminal."""
        if not results:
            return

        self.console.print()
        self.console.print("[bold]Fix results:[/bold]")
        for r in results:
            icon = "[green]OK[/green]" if r.success else "[red]FAIL[/red]"
            self.console.print(f"  {icon} [{r.check_id}] {r.action.description}")
            if not r.success and r.message:
                self.console.print(f"       [dim]{r.message}[/dim]")
        self.console.print()

    def print_manual_todo(self, findings: List[Finding]) -> None:
        """Print manual-only fix actions as a separate todo list."""
        manual = []
        for f in self.collect_fixable(findings):
            for a in f.fix_actions:
                if a.fix_type == "manual":
                    manual.append((f, a))

        if not manual:
            return

        self.console.print()
        self.console.print("[yellow bold]Manual remediation TODO:[/yellow bold]")
        for i, (f, a) in enumerate(manual, 1):
            self.console.print(f"  {i}. [{f.check_id}] {a.manual_steps}")
        self.console.print()

    def _apply_json_path_edit(self, action: FixAction, check_id: str) -> FixResult:
        """Set a value at a known JSON path in a config file."""
        path = Path(action.target_file)
        try:
            text = path.read_text(encoding="utf-8")
            data = json.loads(text)

            keys = json.loads(action.old_value)  # old_value stores the JSON path
            # Navigate to parent, set the leaf key
            obj = data
            for k in keys[:-1]:
                obj = obj[k]
            obj[keys[-1]] = action.new_value

            path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n",
                            encoding="utf-8")
            return FixResult(action, check_id, True)
        except (json.JSONDecodeError, KeyError, TypeError) as e:
            return FixResult(action, check_id, False, f"JSON path edit failed: {e}")
        except OSError as e:
            return FixResult(action, check_id, False, str(e))

    def _apply_file_edit(self, action: FixAction, check_id: str) -> FixResult:
        """Replace old_value with new_value in target_file."""
        path = Path(action.target_file)
        try:
            text = path.read_text(encoding="utf-8")
            if action.old_value not in text:
                return FixResult(action, check_id, False,
                                 f"old_value not found in {path.name}")
            text = text.replace(action.old_value, action.new_value, 1)
            path.write_text(text, encoding="utf-8")
            return FixResult(action, check_id, True)
        except OSError as e:
            return FixResult(action, check_id, False, str(e))

    def _apply_command(self, action: FixAction, check_id: str) -> FixResult:
        """Run a shell command."""
        try:
            result = subprocess.run(
                action.command, shell=True,
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode == 0:
                return FixResult(action, check_id, True)
            return FixResult(action, check_id, False,
                             result.stderr.strip() or f"exit code {result.returncode}")
        except subprocess.TimeoutExpired:
            return FixResult(action, check_id, False, "command timed out")
        except OSError as e:
            return FixResult(action, check_id, False, str(e))

    def _save_history(self, results: List[FixResult]) -> None:
        """Save fix history as audit log (no sensitive values, only hashes)."""
        if not results:
            return

        try:
            HISTORY_DIR.mkdir(parents=True, exist_ok=True)
            ts = datetime.now().strftime("%Y-%m-%dT%H%M%S")
            log_file = HISTORY_DIR / f"{ts}.json"

            actions_log: List[Dict[str, Any]] = []
            for r in results:
                entry: Dict[str, Any] = {
                    "check_id": r.check_id,
                    "fix_type": r.action.fix_type,
                    "description": r.action.description,
                    "success": r.success,
                }
                if r.action.fix_type in ("file_edit", "json_path_edit"):
                    entry["target_file"] = r.action.target_file
                    entry["old_hash"] = hashlib.sha256(
                        r.action.old_value.encode()
                    ).hexdigest()[:16]
                elif r.action.fix_type == "command":
                    entry["command"] = r.action.command
                if not r.success:
                    entry["error"] = r.message
                actions_log.append(entry)

            log_data = {
                "timestamp": datetime.now().isoformat(),
                "actions": actions_log,
            }
            log_file.write_text(json.dumps(log_data, indent=2, ensure_ascii=False),
                                encoding="utf-8")
        except OSError:
            self.console.print("[dim]Warning: could not save fix history[/dim]")
