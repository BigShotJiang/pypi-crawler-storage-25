"""Play Asteroids using OmniLink with a multi-tool strategic AI.

The agent registers three action tools (engage, evade, analyze) plus
query tools for the UI to fetch game state.

Usage
-----
    python -m omnilink.examples.asteroids.play_asteroids
"""

from __future__ import annotations

from typing import Any

from omnilink.tool_runner import ToolRunner

from .asteroids_api import get_state, send_action, SERVER_URL
from .asteroids_engine import decide_action, state_summary


class AsteroidsRunner(ToolRunner):
    agent_name = "asteroids-agent"
    display_name = "Asteroids"
    game_server_url = SERVER_URL

    # Multi-tool descriptions
    tool_name = "engage"
    tool_description = "Engage targets: aim and shoot asteroids from safe distance."
    commands = "stop_game, pause_game, resume_game"
    query_tools = [
        {"name": "get_score", "description": "Returns current score, lives, and wave."},
        {"name": "get_ship", "description": "Returns ship position, angle, and velocity."},
        {"name": "get_asteroids", "description": "Returns count and positions of nearby asteroids."},
        {"name": "get_status", "description": "Returns whether the game is over."},
    ]

    def __init__(self) -> None:
        self._last_score = 0
        self._last_lives = -1
        self._last_wave = -1
        self._last_mode = ""
        self._mode_counts: dict[str, int] = {}

    def execute_query_tool(self, tool_name: str, **kwargs: Any) -> dict[str, Any]:
        state = get_state()
        if tool_name == "get_score":
            return {"score": state.get("score", 0), "lives": state.get("lives", 0), "wave": state.get("wave", 1)}
        if tool_name == "get_ship":
            return {
                "x": state.get("shipX", 0), "y": state.get("shipY", 0),
                "angle": state.get("shipAngle", 0),
                "vx": state.get("shipVX", 0), "vy": state.get("shipVY", 0),
                "alive": state.get("shipAlive", True),
            }
        if tool_name == "get_asteroids":
            asteroids = state.get("asteroids", [])
            return {"count": len(asteroids), "asteroids": asteroids[:10]}
        if tool_name == "get_status":
            return {"game_over": state.get("gameOver", False), "game_state": state.get("game_state", "")}
        return {"error": f"Unknown tool: {tool_name}"}

    def get_profile_settings(self) -> dict[str, Any]:
        """Register multiple tools with OmniLink."""
        base = super().get_profile_settings()
        base["mainTask"] = (
            "Asteroids strategic AI coordinator. Uses multiple tools: "
            "engage (offensive targeting), evade (threat evasion), "
            "analyze (field assessment). For info queries, use query tools.\n\n"
            "RULES:\n"
            "- Action requests → output Command: line\n"
            "- Info requests → output Tool: line\n"
        )
        base["availableTools"] = "engage, evade, analyze, " + ", ".join(
            t["name"] for t in self.query_tools
        )
        base["availableToolDetails"] = [
            {"name": "engage", "description": "Engage targets: aim, shoot, and clear asteroids."},
            {"name": "evade", "description": "Evade threats: trajectory-simulated flee."},
            {"name": "analyze", "description": "Analyze the threat map and select strategy."},
        ] + self.query_tools
        return base

    def get_system_instruction(self) -> dict[str, Any]:
        return {
            "mainTask": (
                "Asteroids strategic AI. You have three tools: "
                "engage (shoot), evade (flee), analyze (assess). "
                "Call engage now to start playing."
            ),
            "availableTools": "engage, evade, analyze",
            "availableToolDetails": [
                {"name": "engage", "description": "Engage targets and shoot asteroids."},
                {"name": "evade", "description": "Evade threats using trajectory simulation."},
                {"name": "analyze", "description": "Analyze threat map for strategy selection."},
            ],
            "availableCommands": self.commands,
            "allowToolUse": True,
        }

    def get_state(self) -> dict[str, Any]:
        return get_state()

    def execute_action(self, state: dict[str, Any]) -> None:
        action, mode = decide_action(state)
        send_action(action)
        if mode != self._last_mode:
            self._last_mode = mode
        self._mode_counts[mode] = self._mode_counts.get(mode, 0) + 1

    def state_summary(self, state: dict[str, Any]) -> str:
        base = state_summary(state)
        total = sum(self._mode_counts.values()) or 1
        mode_pcts = ", ".join(
            f"{m}: {c * 100 // total}%"
            for m, c in sorted(self._mode_counts.items(), key=lambda x: -x[1])
        )
        return f"{base}\nTool usage: {mode_pcts}" if mode_pcts else base

    def is_game_over(self, state: dict[str, Any]) -> bool:
        return state.get("gameOver", False)

    def game_over_message(self, state: dict[str, Any]) -> str:
        score = state.get("score", 0)
        wave = state.get("wave", 1)
        total = sum(self._mode_counts.values()) or 1
        mode_pcts = ", ".join(
            f"{m}: {c * 100 // total}%"
            for m, c in sorted(self._mode_counts.items(), key=lambda x: -x[1])
        )
        return f"GAME OVER — Final score: {score}, Wave: {wave}\n  Tool usage: {mode_pcts}"

    def on_start(self) -> None:
        try:
            send_action("RESUME")
            print("  Game resumed.")
        except Exception:
            pass

    def log_events(self, state: dict[str, Any]) -> None:
        score = state.get("score", 0)
        lives = state.get("lives", 0)
        wave = state.get("wave", 1)

        if score != self._last_score:
            print(f"  Score: {score}  (+{score - self._last_score})")
            self._last_score = score
        if lives != self._last_lives:
            if self._last_lives > 0 and lives < self._last_lives:
                print(f"  ** Life lost! Lives: {lives}")
            self._last_lives = lives
        if wave != self._last_wave:
            print(f"  Wave: {wave}")
            self._last_wave = wave


if __name__ == "__main__":
    AsteroidsRunner().run()
