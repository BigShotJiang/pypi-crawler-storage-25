"""Play Husky fleet navigation using OmniLink tool calling.

The AI agent calls the ``make_move`` tool, which coordinates all 5
Husky robots toward their individual waypoint circuits.

Usage
-----
    python -m omnilink.examples.husky_fleet.play_fleet
"""

from __future__ import annotations

from typing import Any

from omnilink.tool_runner import ToolRunner

from .fleet_api import get_fleet_state, drive, ROBOT_IDS
from .fleet_engine import FleetNavigator, fleet_state_summary


class FleetRunner(ToolRunner):
    agent_name = "husky-fleet-agent"
    display_name = "Husky Fleet"
    tool_description = "Navigate all 5 Husky robots toward their waypoints."
    commands = "stop_game, pause_game, resume_game"
    poll_interval = 0.05
    memory_every = 10
    ask_every = 30
    query_tools = [
        {"name": "get_fleet_status", "description": "Returns overall fleet progress (waypoints, laps, finished)."},
        {"name": "get_robot", "description": "Returns position and waypoint info for a specific robot. Args: robot_id."},
        {"name": "get_all_positions", "description": "Returns positions of all 5 robots."},
    ]

    def __init__(self) -> None:
        self._navigator = FleetNavigator(loop=True)
        self._last_wps: dict[str, int] = {rid: -1 for rid in ROBOT_IDS}
        self._last_laps: dict[str, int] = {rid: 0 for rid in ROBOT_IDS}

    def execute_query_tool(self, tool_name: str, **kwargs: Any) -> dict[str, Any]:
        fleet_state = get_fleet_state()
        nav = self._navigator
        if tool_name == "get_fleet_status":
            return {
                "total_waypoints_reached": nav.total_waypoints_reached,
                "total_laps": nav.total_laps,
                "all_finished": nav.all_finished,
                "robots": len(ROBOT_IDS),
            }
        if tool_name == "get_robot":
            rid = kwargs.get("robot_id", "husky_0")
            if rid not in nav.robots:
                return {"error": f"Unknown robot: {rid}"}
            rnav = nav.robots[rid]
            st = fleet_state.get(rid, {"x": 0, "y": 0, "yaw": 0})
            target = rnav.target
            return {
                "robot_id": rid,
                "x": st["x"], "y": st["y"], "yaw": st["yaw"],
                "waypoint_index": rnav.current_wp + 1,
                "waypoint_target": {"x": target[0], "y": target[1]} if target else None,
                "waypoints_reached": rnav.total_waypoints_reached,
                "laps": rnav.laps,
            }
        if tool_name == "get_all_positions":
            return {
                rid: {"x": round(st["x"], 2), "y": round(st["y"], 2), "yaw": round(st["yaw"], 2)}
                for rid, st in fleet_state.items()
            }
        return {"error": f"Unknown tool: {tool_name}"}

    def get_state(self) -> dict[str, Any]:
        return get_fleet_state()

    def execute_action(self, state: dict[str, Any]) -> None:
        commands = self._navigator.decide_actions(state)
        for rid, cmd in commands.items():
            try:
                drive(rid, cmd["vx"], cmd["wz"])
            except Exception:
                pass

    def state_summary(self, state: dict[str, Any]) -> str:
        return fleet_state_summary(state, self._navigator)

    def is_game_over(self, state: dict[str, Any]) -> bool:
        return self._navigator.all_finished

    def game_over_message(self, state: dict[str, Any]) -> str:
        return f"MISSION COMPLETE -- Total waypoints: {self._navigator.total_waypoints_reached}"

    def log_events(self, state: dict[str, Any]) -> None:
        for rid in ROBOT_IDS:
            nav = self._navigator.robots[rid]
            if nav.current_wp != self._last_wps[rid]:
                target = nav.target
                target_str = f"({target[0]:.1f}, {target[1]:.1f})" if target else "done"
                print(f"  {rid}: wp {nav.current_wp + 1}/{len(nav.waypoints)} -> {target_str}  [reached: {nav.total_waypoints_reached}]")
                self._last_wps[rid] = nav.current_wp
            if nav.laps != self._last_laps[rid]:
                print(f"  {rid}: ** Lap {nav.laps} completed!")
                self._last_laps[rid] = nav.laps

    def get_review_instruction(self) -> dict[str, Any]:
        return {
            "mainTask": (
                "Monitor Husky Fleet. If all robots finished waypoints: stop_game. "
                "Otherwise: make_move."
            ),
            "availableTools": self._all_tool_names(),
            "availableToolDetails": self._all_tool_details(),
            "availableCommands": self.commands,
            "allowToolUse": True,
        }


if __name__ == "__main__":
    FleetRunner().run()
