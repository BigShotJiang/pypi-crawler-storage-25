"""Play Pac-Man using OmniLink tool calling.

The AI agent calls the ``make_move`` tool, which acts as a local
Pac-Man AI controller.  The model never sees the game — it simply
triggers the tool.  The tool reads the game state, runs BFS pathfinding,
and moves Pac-Man accordingly.

This keeps API credit usage to a minimum (one call to kick off).

Usage
-----
    python -m omnilink.examples.pacman.play_pacman
"""

from __future__ import annotations

import time
from typing import Any

from omnilink.tool_runner import ToolRunner

from .pacman_api import get_state, send_action, SERVER_URL
from .pacman_engine import decide_action, state_summary, reset_commitment


class PacmanRunner(ToolRunner):
    agent_name = "pacman-agent"
    display_name = "Pac-Man"
    tool_description = "Run Pac-Man AI."
    game_server_url = SERVER_URL
    query_tools = [
        {"name": "get_score", "description": "Returns current score, lives, and level."},
        {"name": "get_position", "description": "Returns Pac-Man's position on the grid."},
        {"name": "get_ghosts", "description": "Returns ghost positions and states."},
        {"name": "get_pellets", "description": "Returns number of pellets remaining."},
    ]

    def __init__(self) -> None:
        self._last_score = 0
        self._last_lives = -1
        self._last_level = -1

    def execute_query_tool(self, tool_name: str, **kwargs: Any) -> dict[str, Any]:
        state = get_state()
        if tool_name == "get_score":
            return {"score": state.get("score", 0), "lives": state.get("lives", 0), "level": state.get("level", 1)}
        if tool_name == "get_position":
            return {"pacman": state.get("pacman", {})}
        if tool_name == "get_ghosts":
            return {"ghosts": state.get("ghosts", [])}
        if tool_name == "get_pellets":
            pellets = state.get("pellets", [])
            power = state.get("power_pellets", [])
            return {"pellets": len(pellets) if isinstance(pellets, list) else 0, "power_pellets": len(power) if isinstance(power, list) else 0}
        return {"error": f"Unknown tool: {tool_name}"}

    def get_state(self) -> dict[str, Any]:
        return get_state()

    def execute_action(self, state: dict[str, Any]) -> None:
        if state.get("game_state") == "PLAY":
            walkable = state.get("walkable", [])
            if not walkable:
                return
            action = decide_action(state)
            send_action(action)

    def state_summary(self, state: dict[str, Any]) -> str:
        return state_summary(state)

    def is_game_over(self, state: dict[str, Any]) -> bool:
        return state.get("game_state") == "GAMEOVER"

    def game_over_message(self, state: dict[str, Any]) -> str:
        return f"GAME OVER — Final score: {state.get('score', 0)}, Level: {state.get('level', 1)}"

    def on_start(self) -> None:
        try:
            send_action("START")
            time.sleep(0.5)
            print("  Game started.")
        except Exception:
            pass

    def log_events(self, state: dict[str, Any]) -> None:
        score = state.get("score", 0)
        lives = state.get("lives", 0)
        level = state.get("level", 1)

        if score != self._last_score:
            print(f"  Score: {score}  (+{score - self._last_score})")
            self._last_score = score
        if lives != self._last_lives:
            if self._last_lives > 0 and lives < self._last_lives:
                print(f"  ** Life lost! Lives: {lives}")
                reset_commitment()
            self._last_lives = lives
        if level != self._last_level:
            print(f"  Level: {level}")
            reset_commitment()
            self._last_level = level


if __name__ == "__main__":
    PacmanRunner().run()
