"""Play Space Invaders using OmniLink tool calling.

The AI agent calls the ``make_move`` tool, which acts as a local
Space Invaders AI controller.  The model never sees the game — it
simply triggers the tool.  The tool reads the game state, picks a
target alien, and moves / shoots accordingly.

This keeps API credit usage to a minimum (one call to kick off).

Usage
-----
    python -m omnilink.examples.space_invaders.play_space_invaders
"""

from __future__ import annotations

from typing import Any

from omnilink.tool_runner import ToolRunner

from .space_invaders_api import get_state, send_action, SERVER_URL
from .space_invaders_engine import decide_action, state_summary


class SpaceInvadersRunner(ToolRunner):
    agent_name = "space-invaders-agent"
    display_name = "Space Invaders"
    tool_description = "Move ship and shoot."
    game_server_url = SERVER_URL
    query_tools = [
        {"name": "get_score", "description": "Returns current score, lives, and level."},
        {"name": "get_ship", "description": "Returns ship position."},
        {"name": "get_aliens", "description": "Returns number and positions of remaining aliens."},
        {"name": "get_status", "description": "Returns whether the game is over."},
    ]

    def __init__(self) -> None:
        self._last_score = 0
        self._last_lives = -1
        self._last_level = -1

    def execute_query_tool(self, tool_name: str, **kwargs: Any) -> dict[str, Any]:
        state = get_state()
        if tool_name == "get_score":
            return {"score": state.get("score", 0), "lives": state.get("lives", 0), "level": state.get("level", 1)}
        if tool_name == "get_ship":
            return {"ship": state.get("ship", state.get("player", {}))}
        if tool_name == "get_aliens":
            aliens = state.get("aliens", [])
            return {"count": len(aliens) if isinstance(aliens, list) else 0, "aliens": aliens[:10] if isinstance(aliens, list) else []}
        if tool_name == "get_status":
            return {"game_over": state.get("gameOver", False)}
        return {"error": f"Unknown tool: {tool_name}"}

    def get_state(self) -> dict[str, Any]:
        return get_state()

    def execute_action(self, state: dict[str, Any]) -> None:
        send_action(decide_action(state))

    def state_summary(self, state: dict[str, Any]) -> str:
        return state_summary(state)

    def is_game_over(self, state: dict[str, Any]) -> bool:
        return state.get("gameOver", False)

    def game_over_message(self, state: dict[str, Any]) -> str:
        return f"GAME OVER — Final score: {state.get('score', 0)}, Level: {state.get('level', 1)}"

    def on_start(self) -> None:
        try:
            send_action("RESUME")
            print("  Game resumed.")
        except Exception:
            pass

    def log_events(self, state: dict[str, Any]) -> None:
        score = state.get("score", 0)
        lives = state.get("lives", 0)
        level = state.get("level", 1)

        if score != self._last_score:
            print(f"  Score: {score}  (+{score - self._last_score})")
            self._last_score = score
        if lives != self._last_lives:
            if self._last_lives > 0 and lives < self._last_lives:
                print(f"  ** Life lost! Lives: {lives}")
            self._last_lives = lives
        if level != self._last_level:
            print(f"  Level: {level}")
            self._last_level = level


if __name__ == "__main__":
    SpaceInvadersRunner().run()
