"""Play Husky navigation using OmniLink tool calling.

The AI agent calls the ``make_move`` tool, which steers the robot
toward waypoints using a pure-pursuit controller.

Usage
-----
    python -m omnilink.examples.husky.play_husky
"""

from __future__ import annotations

import math
from typing import Any

from omnilink.tool_runner import ToolRunner

from .husky_api import get_state, drive
from .husky_engine import HuskyNavigator, state_summary


class HuskyRunner(ToolRunner):
    agent_name = "husky-agent"
    display_name = "Husky"
    tool_description = "Steer toward the next waypoint."
    poll_interval = 0.05
    memory_every = 10
    ask_every = 30
    commands = "stop_game, pause_game, resume_game"
    query_tools = [
        {"name": "get_pose", "description": "Returns robot position (x, y) and heading (yaw)."},
        {"name": "get_waypoint", "description": "Returns current target waypoint and distance."},
        {"name": "get_progress", "description": "Returns waypoints reached and laps completed."},
    ]

    def __init__(self) -> None:
        self._navigator = HuskyNavigator(loop=True)
        self._last_wp = -1
        self._last_laps = 0

    def execute_query_tool(self, tool_name: str, **kwargs: Any) -> dict[str, Any]:
        state = get_state()
        nav = self._navigator
        if tool_name == "get_pose":
            return {"x": state.get("x", 0), "y": state.get("y", 0), "yaw": state.get("yaw", 0)}
        if tool_name == "get_waypoint":
            target = nav.target
            if target:
                dist = math.hypot(target[0] - state.get("x", 0), target[1] - state.get("y", 0))
                return {"waypoint": {"x": target[0], "y": target[1]}, "distance": round(dist, 2), "index": nav.current_wp + 1, "total": len(nav.waypoints)}
            return {"waypoint": None, "finished": True}
        if tool_name == "get_progress":
            return {"waypoints_reached": nav.total_waypoints_reached, "laps": nav.laps, "finished": nav.finished}
        return {"error": f"Unknown tool: {tool_name}"}

    def get_state(self) -> dict[str, Any]:
        return get_state()

    def execute_action(self, state: dict[str, Any]) -> None:
        cmd = self._navigator.decide_action(state)
        try:
            drive(cmd["vx"], cmd["wz"])
        except Exception:
            pass

    def state_summary(self, state: dict[str, Any]) -> str:
        return state_summary(state, self._navigator)

    def is_game_over(self, state: dict[str, Any]) -> bool:
        return self._navigator.finished

    def game_over_message(self, state: dict[str, Any]) -> str:
        return f"MISSION COMPLETE — Waypoints reached: {self._navigator.total_waypoints_reached}"

    def log_events(self, state: dict[str, Any]) -> None:
        nav = self._navigator
        if nav.current_wp != self._last_wp:
            target = nav.target
            target_str = f"({target[0]:.1f}, {target[1]:.1f})" if target else "done"
            print(f"  Waypoint {nav.current_wp + 1}/{len(nav.waypoints)} -> {target_str}  [reached: {nav.total_waypoints_reached}]")
            self._last_wp = nav.current_wp
        if nav.laps != self._last_laps:
            print(f"  ** Lap {nav.laps} completed!")
            self._last_laps = nav.laps


if __name__ == "__main__":
    HuskyRunner().run()
