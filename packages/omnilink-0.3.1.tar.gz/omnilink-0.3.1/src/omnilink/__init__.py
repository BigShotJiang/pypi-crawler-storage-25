#!/usr/bin/env python3
# omnilink.py — OmniLink engine with HTTP bridge helpers
# Dependencies: requests  (pip install requests)

from __future__ import annotations

from omnilink.client import OmniLinkAPIError, OmniLinkClient  # noqa: F401
from omnilink.tool_runner import ToolRunner  # noqa: F401

import http.server as _http_server
import json
import logging
import os
import queue
import re
import threading
import time
import uuid
from collections import Counter, deque
from dataclasses import dataclass
from pathlib import Path
from typing import (
    Any,
    Callable,
    Deque,
    Dict,
    Iterable,
    List,
    Optional,
    Pattern,
    Protocol,
    Sequence,
    Set,
    Tuple,
    Union,
)
import textwrap

try:  # pragma: no cover - optional dependency
    import requests  # type: ignore[import-not-found]
    from requests.adapters import HTTPAdapter  # type: ignore[import-not-found]
except Exception:  # pragma: no cover - optional dependency
    requests = None  # type: ignore[assignment]
    HTTPAdapter = None  # type: ignore[assignment]

try:  # pragma: no cover - optional dependency
    from urllib3.util.retry import Retry  # type: ignore[import-not-found]
except Exception:  # pragma: no cover - optional dependency
    Retry = None  # type: ignore[assignment]

RequestException = requests.RequestException if requests else Exception

# =========================================================
# Utilities / Types
# =========================================================

def _json_safe_copy(data: Any) -> Any:
    """Return a JSON-serializable deep copy of ``data`` using ``str`` fallbacks."""

    try:
        return json.loads(json.dumps(data, default=str))
    except Exception:
        # As a last resort, stringify the object itself.
        return json.loads(json.dumps(str(data)))


TypeConverter = Callable[[str], Any]
InlineCodeHandler = Callable[["InlineCodeMessage"], None]


@dataclass
class AgentFeedback:
    """Structured feedback emitted by command handlers."""

    message: str
    kind: str = "info"
    ok: Optional[bool] = None
    progress: Optional[float] = None
    data: Optional[Dict[str, Any]] = None

    def to_payload(self, *, command: Optional[str] = None) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"message": self.message}
        if command:
            payload["command"] = command
        if self.kind != "info":
            payload["kind"] = self.kind
        if self.ok is not None:
            payload["ok"] = self.ok
        if self.progress is not None:
            payload["progress"] = self.progress
        if self.data:
            payload["data"] = self.data
        return payload

    def to_legacy_payload(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "feedback": True,
            "ok": self.ok if self.ok is not None else True,
            "message": self.message,
        }
        if self.kind != "info":
            payload["kind"] = self.kind
        if self.progress is not None:
            payload["progress"] = self.progress
        if self.data:
            payload["data"] = self.data
        return payload


@dataclass
class AgentQuestion:
    """Question payload that can optionally include inline code suggestions."""

    prompt: str
    choices: Optional[Sequence[str]] = None
    allow_multiple: bool = False
    inline_code: Optional["InlineCodeMessage"] = None
    data: Optional[Dict[str, Any]] = None

    def to_payload(self, *, command: Optional[str] = None) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"prompt": self.prompt}
        if command:
            payload["command"] = command
        if self.choices:
            payload["choices"] = [str(choice) for choice in self.choices]
        if self.allow_multiple:
            payload["allowMultiple"] = True
        if self.inline_code:
            payload["inlineCodeMessage"] = self.inline_code.to_payload()
        if self.data:
            payload["data"] = self.data
        return payload


class PendingQuestion:
    """Represents a question awaiting an external reply."""

    def __init__(self, engine: "OmniLinkEngine", correlation_id: str) -> None:
        self._engine = engine
        self.correlation_id = correlation_id
        self._event = threading.Event()
        self._response: Optional[Dict[str, Any]] = None
        self._error: Optional[BaseException] = None

    def wait(
        self,
        timeout: Optional[float] = None,
        *,
        cancel_on_timeout: bool = False,
        cancel_message: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Block until an answer is received or timeout expires.

        When ``cancel_on_timeout`` is true, timing out will also cancel the
        pending question so late replies are ignored.
        """

        if not self._event.wait(timeout):
            if cancel_on_timeout:
                self.cancel(cancel_message or "Timed out waiting for agent reply")
            raise TimeoutError(
                f"Timed out waiting for agent reply (correlation_id={self.correlation_id})"
            )
        if self._error is not None:
            raise self._error
        return dict(self._response or {})

    def cancel(self, message: Optional[str] = None) -> None:
        """Cancel this question so future replies are ignored."""

        self._engine._cancel_pending_question(self.correlation_id, message)

    def done(self) -> bool:
        """Return ``True`` if a reply (or cancellation) has been recorded."""

        return self._event.is_set()

    def result(self) -> Optional[Dict[str, Any]]:
        """Return the reply payload if one has been received."""

        return dict(self._response) if self._response is not None else None

    # Internal helpers -------------------------------------------------
    def _resolve(self, payload: Dict[str, Any]) -> None:
        self._response = dict(payload)
        self._event.set()

    def _reject(self, message: Optional[str]) -> None:
        self._error = RuntimeError(message or "Question cancelled")
        self._event.set()


class AgentMessenger(Protocol):
    """Interface for emitting structured agent updates while handling commands."""

    def send_feedback(self, feedback: AgentFeedback) -> None:
        ...

    def ask_question(self, question: AgentQuestion) -> PendingQuestion:
        ...

    def acknowledge(
        self,
        status: str,
        *,
        message: Optional[str] = None,
        data: Optional[Dict[str, Any]] = None,
    ) -> None:
        ...


LOGGER = logging.getLogger(__name__)

def _num_conv(s: str) -> Union[int, float]:
    if re.fullmatch(r"-?\d+", s):
        return int(s)
    f = float(s)
    return int(f) if f.is_integer() else f

def _normalize_separators(text: str) -> str:
    """
    Normalize separators for matching:
      - strip
      - collapse whitespace to single space
      - convert spaces to underscores
    NOTE: we DO NOT lowercase to preserve captured values like 'C2'.
    """
    t = re.sub(r"\s+", " ", text.strip())
    return t.replace(" ", "_")


def _env_flag(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() not in ("0", "false", "no", "off")


# =========================================================
# Type registry
# =========================================================

class TypeRegistry:
    """
    Holds named types mapping to (regex, converter).
    Converters receive str and return a typed value (or raise ValueError).
    """
    def __init__(self) -> None:
        self._types: Dict[str, Tuple[str, Optional[TypeConverter]]] = {}
        self._install_defaults()

    def _install_defaults(self) -> None:
        # Common text
        self.register("alpha", r"[A-Za-z]+")
        self.register("letters", r"[A-Za-z]+")
        self.register("word", r"[A-Za-z]+")
        self.register("lower", r"[a-z]+")
        self.register("upper", r"[A-Z]+")
        self.register("slug", r"[A-Za-z0-9_-]+")
        self.register("alnum", r"[A-Za-z0-9]+")
        self.register("alphanumeric", r"[A-Za-z0-9]+")

        # Numbers / bools
        self.register("int", r"-?\d+", lambda s: int(s))
        self.register("float", r"-?\d+(?:\.\d+)?", lambda s: float(s))
        self.register("num", r"-?\d+(?:\.\d+)?", _num_conv)
        self.register("digit", r"\d", lambda s: int(s))
        self.register("digits", r"\d+", lambda s: int(s))
        self.register("bool", r"(?:true|false|0|1)", lambda s: s.lower() in ("true", "1"))

        # IDs / time-ish (kept as strings)
        self.register("uuid", r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}")
        self.register("date", r"\d{4}-\d{2}-\d{2}")
        self.register("time", r"\d{2}:\d{2}(?::\d{2})?")
        self.register("datetime", r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2})?Z?")

        # Anything (greedy)
        self.register("any", r".+")

    def register(self, name: str, regex: str, converter: Optional[TypeConverter] = None) -> None:
        self._types[name.lower()] = (regex, converter)

    def get(self, name: str) -> Optional[Tuple[str, Optional[TypeConverter]]]:
        return self._types.get(name.lower())

    def available(self) -> Dict[str, str]:
        return {k: v[0] for k, v in self._types.items()}

# =========================================================
# Pattern compilation and matching
# =========================================================

# Token format inside []:
#   [name:type]      named + typed
#   [name]           named, default token regex
#   [:type]          unnamed, typed
#   [/regex/]        unnamed, custom regex
#   [name:/regex/]   named, custom regex
_TOKEN_PAT = re.compile(r"\[([^\]]+)\]")   # inner contents only
_DEFAULT_TOKEN_RX = r"[^_]+"               # stops at underscore

@dataclass
class CompiledPattern:
    template: str
    regex: Pattern[str]
    var_names: List[str]
    var_types: List[Optional[str]]
    text: str  # normalized template text

def _parse_token(token: str) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """
    Returns (name, type_name, regex_override)
    """
    token = token.strip()
    if token.startswith("/") and token.endswith("/") and len(token) > 2:
        return None, None, token[1:-1]
    if ":" in token:
        left, right = token.split(":", 1)
        left, right = left.strip(), right.strip()
        if right.startswith("/") and right.endswith("/") and len(right) > 2:
            name = left or None
            return name, None, right[1:-1]
        name = left or None
        typ = right or None
        return name, typ, None
    if token:
        return token, None, None
    return None, None, None

def _compile_template(template: str, types: TypeRegistry) -> CompiledPattern:
    """
    Compile a human-readable template into a strict regex with capturing groups.
    Both template and inputs are normalized with _normalize_separators (NOT lowercased).
    Regex is compiled with IGNORECASE; captures preserve original case.
    """
    norm = _normalize_separators(template)
    var_names: List[str] = []
    var_types: List[Optional[str]] = []
    pieces: List[str] = []
    last = 0

    for m in _TOKEN_PAT.finditer(norm):
        pieces.append(re.escape(norm[last:m.start()]))

        name, typ, rx_override = _parse_token(m.group(1))

        if rx_override:
            cap_rx = f"({rx_override})"
        elif typ:
            spec = types.get(typ)
            if not spec:
                raise ValueError(f"Unknown type '{typ}' in template: {template}")
            rx, _ = spec
            cap_rx = f"({rx})"
        else:
            cap_rx = f"({_DEFAULT_TOKEN_RX})"

        if not name:
            name = f"var{len(var_names) + 1}"

        var_names.append(name)
        var_types.append(typ)
        pieces.append(cap_rx)
        last = m.end()

    pieces.append(re.escape(norm[last:]))

    full_rx = "^" + "".join(pieces) + "$"
    return CompiledPattern(
        template=template,
        regex=re.compile(full_rx, flags=re.IGNORECASE),
        var_names=var_names,
        var_types=var_types,
        text=norm,
    )

# =========================================================
# Engine
# =========================================================

@dataclass
class Event:
    command: str
    text: str
    template: Optional[str]
    normalized_template: Optional[str]
    vars: Dict[str, Any]
    errors: List[Dict[str, Any]]
    meta: Dict[str, Any]
    timestamp: float
    messenger: Optional[AgentMessenger] = None

Handler = Callable[[Dict[str, Any]], Any]
Predicate = Callable[[Dict[str, Any]], bool]

class OmniLinkEngine:
    """
    Pattern-driven command engine with routing, middleware, metrics, and history.
    """
    def __init__(self, patterns: Iterable[str], types: Optional[TypeRegistry] = None, keep_history: int = 200) -> None:
        self.types = types or TypeRegistry()
        self._compiled: List[CompiledPattern] = []
        self._templates: List[str] = []
        self._handlers: List[Tuple[Predicate, Handler]] = []
        self._before: List[Handler] = []
        self._after: List[Handler] = []
        self._messenger: Optional[AgentMessenger] = None

        self.metrics = Counter()
        self.history: Deque[Event] = deque(maxlen=keep_history)

        self._pending_questions: Dict[str, PendingQuestion] = {}
        self._pending_lock = threading.Lock()

        for t in patterns:
            self.add_template(t)

    # Templates
    def add_template(self, template: str) -> None:
        cp = _compile_template(template, self.types)
        self._compiled.append(cp)
        self._templates.append(template)

    @property
    def templates(self) -> List[str]:
        return list(self._templates)

    # Routing
    def on(self, predicate: Predicate, handler: Handler) -> None:
        self._handlers.append((predicate, handler))

    def on_template(self, template: str, handler: Handler) -> None:
        norm = _normalize_separators(template)
        self._handlers.append((lambda e: e.get("normalized_template") == norm, handler))

    def before(self, handler: Handler) -> None:
        self._before.append(handler)

    def after(self, handler: Handler) -> None:
        self._after.append(handler)

    # Parsing and handling
    def parse(self, text: str) -> Dict[str, Any]:
        tnorm = _normalize_separators(text)
        conversion_errors: List[Dict[str, Any]] = []
        for cp in self._compiled:
            m = cp.regex.match(tnorm)
            if not m:
                continue
            values = m.groups()
            out: Dict[str, Any] = {}
            for name, typ, val in zip(cp.var_names, cp.var_types, values):
                if typ:
                    spec = self.types.get(typ)
                    if spec and spec[1]:
                        try:
                            out[name] = spec[1](val)
                        except Exception as exc:
                            LOGGER.warning(
                                "Type conversion failed",
                                extra={
                                    "template": cp.template,
                                    "variable": name,
                                    "type": typ,
                                    "value": val,
                                    "error": str(exc),
                                },
                                exc_info=True,
                            )
                            out[name] = val
                            conversion_errors.append(
                                {
                                    "variable": name,
                                    "type": typ,
                                    "value": val,
                                    "error": str(exc),
                                }
                            )
                    else:
                        out[name] = val
                else:
                    out[name] = val
            return {
                "ok": True,
                "template": cp.template,
                "normalized_template": cp.text,
                "vars": out,
                "errors": conversion_errors,
            }
        return {
            "ok": False,
            "template": None,
            "normalized_template": None,
            "vars": {},
            "errors": [],
        }

    # State snapshots ---------------------------------------------------
    def _serialize_event(self, event: Event, *, include_messenger: bool = False) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "command": event.command,
            "text": event.text,
            "template": event.template,
            "normalized_template": event.normalized_template,
            "vars": event.vars,
            "errors": event.errors,
            "meta": event.meta,
            "timestamp": event.timestamp,
        }
        if include_messenger:
            payload["messenger"] = str(event.messenger) if event.messenger is not None else None
        return _json_safe_copy(payload)

    def get_recent_events(
        self,
        limit: Optional[int] = None,
        *,
        newest_first: bool = True,
        include_messenger: bool = False,
    ) -> List[Dict[str, Any]]:
        """Return a JSON-serializable snapshot of recent history events."""

        events: Sequence[Event] = list(self.history)
        if limit is not None and limit >= 0:
            events = events[-limit:]
        if newest_first:
            events = list(reversed(events))
        return [self._serialize_event(evt, include_messenger=include_messenger) for evt in events]

    def get_metrics_snapshot(self) -> Dict[str, int]:
        """Return a JSON-serializable copy of current metrics counters."""

        return _json_safe_copy(dict(self.metrics))

    def get_context(
        self,
        *,
        history_limit: Optional[int] = 10,
        include_metrics: bool = True,
        include_history: bool = True,
        newest_first: bool = True,
        include_messenger: bool = False,
    ) -> Dict[str, Any]:
        """Return a combined snapshot of metrics and recent history."""

        context: Dict[str, Any] = {"generated_at": time.time()}
        if include_metrics:
            context["metrics"] = self.get_metrics_snapshot()
        if include_history and history_limit != 0:
            limit = history_limit if history_limit is None else max(history_limit, 0)
            context["recent_events"] = self.get_recent_events(
                limit=limit,
                newest_first=newest_first,
                include_messenger=include_messenger,
            )
        return _json_safe_copy(context)

    def set_messenger(self, messenger: Optional[AgentMessenger]) -> None:
        """Register a default messenger used when ``handle`` is called without one."""

        self._messenger = messenger

    # Questions ---------------------------------------------------------
    def create_question_waiter(self) -> PendingQuestion:
        """Create and track a ``PendingQuestion`` for external replies."""

        correlation_id = uuid.uuid4().hex
        pending = PendingQuestion(self, correlation_id)
        with self._pending_lock:
            self._pending_questions[correlation_id] = pending
        return pending

    def receive_agent_reply(self, reply: Dict[str, Any]) -> bool:
        """Resolve a pending question from an agent reply payload."""

        correlation_id = self._extract_correlation_id(reply)
        if not correlation_id:
            return False
        with self._pending_lock:
            pending = self._pending_questions.pop(correlation_id, None)
        if not pending:
            return False
        pending._resolve(reply)
        return True

    def _extract_correlation_id(self, reply: Dict[str, Any]) -> Optional[str]:
        value: Optional[str] = None
        for key in ("correlationId", "correlation_id", "id"):
            raw = reply.get(key)
            if isinstance(raw, str) and raw.strip():
                value = raw.strip()
                break
        if value:
            return value
        data = reply.get("data")
        if isinstance(data, dict):
            for key in ("correlationId", "correlation_id"):
                raw = data.get(key)
                if isinstance(raw, str) and raw.strip():
                    return raw.strip()
        return None

    def _cancel_pending_question(self, correlation_id: str, message: Optional[str] = None) -> None:
        with self._pending_lock:
            pending = self._pending_questions.pop(correlation_id, None)
        if pending:
            pending._reject(message)

    def handle(
        self,
        text: str,
        meta: Optional[Dict[str, Any]] = None,
        messenger: Optional[AgentMessenger] = None,
    ) -> Dict[str, Any]:
        meta = meta or {}
        ts = time.time()
        parsed = self.parse(text)
        active_messenger = messenger if messenger is not None else self._messenger
        evt: Dict[str, Any] = {
            "command": text,
            "text": _normalize_separators(text),
            "template": parsed.get("template"),
            "normalized_template": parsed.get("normalized_template"),
            "vars": parsed.get("vars", {}),
            "errors": parsed.get("errors", []),
            "meta": meta,
            "timestamp": ts,
            "messenger": active_messenger,
        }

        # history + metrics
        self.history.append(Event(**evt))
        self.metrics["handle.calls"] += 1
        self.metrics[f"handle.ok.{bool(parsed.get('ok'))}"] += 1
        template_key = evt["normalized_template"] or "<none>"
        self.metrics[f"handle.template.{template_key}"] += 1
        if evt["errors"]:
            self.metrics["handle.parse_errors"] += len(evt["errors"])

        # before middleware
        for h in self._before:
            try:
                h(evt)
            except Exception as e:
                logging.exception("Error in before-handler: %s", e)

        # routing
        result: Any = None
        matched_handler = False
        for pred, handler in self._handlers:
            try:
                if pred(evt):
                    matched_handler = True
                    self.metrics["handle.matched"] += 1
                    self.metrics[f"handle.matched.{template_key}"] += 1
                    result = handler(evt)
                    break
            except Exception as e:
                LOGGER.exception("Handler error", extra={"template": evt["template"]})
                result = {"error": str(e)}
                break

        if not matched_handler:
            self.metrics["handle.unmatched"] += 1
            LOGGER.info(
                "No handler matched event",
                extra={
                    "command": evt["command"],
                    "template": evt["template"],
                    "normalized_template": evt["normalized_template"],
                },
            )

        # after middleware
        for h in self._after:
            try:
                h(evt)
            except Exception as e:
                LOGGER.exception("Error in after-handler", extra={"template": evt["template"]})

        return {
            "ok": bool(parsed.get("ok")),
            "template": evt["template"],
            "normalized_template": evt["normalized_template"],
            "vars": evt["vars"],
            "errors": evt["errors"],
            "result": result,
            "meta": meta,
            "timestamp": ts,
        }

# =========================================================
# Pattern file loader (exported)
# =========================================================

from inspect import getsourcefile, signature, stack

def load_patterns_from_file(path: Union[str, Path], types: Optional[TypeRegistry] = None) -> List[str]:
    """
    Lines are templates; '#' starts a comment. Blank lines ignored.
    Robustness features:
      - Resolves relative paths against the caller's directory if needed.
      - Reads with utf-8-sig to ignore BOMs.
      - Auto-unquotes lines wrapped in "..." or '...'.
    """
    p = Path(path)
    tried: List[Path] = []

    def _read_file(pp: Path) -> List[str]:
        text = pp.read_text(encoding="utf-8-sig")
        out: List[str] = []
        for line in text.splitlines():
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
                s = s[1:-1].strip()
            if s:
                out.append(s)
        return out

    # 1) as-is
    tried.append(p)
    if p.exists():
        return _read_file(p)

    # 2) relative to caller
    try:
        caller_file = getsourcefile(stack()[1].frame) or ""
        base = Path(caller_file).resolve().parent if caller_file else Path.cwd()
    except Exception:
        base = Path.cwd()
    p2 = (base / p).resolve()
    if p2.exists():
        tried.append(p2)
        return _read_file(p2)

    # 3) relative to CWD
    p3 = Path.cwd() / p
    if p3.exists():
        tried.append(p3)
        return _read_file(p3)

    raise FileNotFoundError(f"Patterns file not found. Tried: {', '.join(str(x) for x in tried)}")


# =========================================================
# =========================================================
# Inline code helpers (shared by HTTP bridge)
# =========================================================

_FENCED_CODE_RX = re.compile(r"^```(?:[A-Za-z0-9#+\-_.]*)?\s*([\s\S]*?)\s*```$", re.DOTALL)


def _clean_inline_label(label: str) -> str:
    label = label.strip()
    if label.endswith(":"):
        label = label[:-1]
    return label or "Code"


def _prepare_inline_code(code: str) -> str:
    trimmed = code.strip()
    fenced = _FENCED_CODE_RX.match(trimmed)
    if fenced:
        trimmed = fenced.group(1).strip()
    elif trimmed.startswith("`") and trimmed.endswith("`") and len(trimmed) > 1:
        trimmed = trimmed[1:-1].strip()
    normalized = textwrap.dedent(trimmed.replace("\r\n", "\n")).strip("\n")
    return normalized


@dataclass
class InlineCodeSnippet:
    """Inline code snippet published alongside a command."""

    label: str
    content: str

    @classmethod
    def from_payload(cls, payload: Any) -> Optional["InlineCodeSnippet"]:
        if isinstance(payload, dict):
            raw_content = payload.get("content")
            raw_label = payload.get("label", "")
        else:
            raw_content = payload
            raw_label = ""

        if not isinstance(raw_content, str):
            return None

        content = _prepare_inline_code(raw_content)
        if not content:
            return None

        label = _clean_inline_label(str(raw_label))
        return cls(label=label, content=content)


@dataclass
class InlineCodeMessage:
    """Structured inline code payload ready to execute."""

    command: str
    snippets: List[InlineCodeSnippet]
    response: Optional[str] = None
    timestamp: Optional[str] = None

    @classmethod
    def from_payload(cls, payload: Any) -> Optional["InlineCodeMessage"]:
        if not isinstance(payload, dict):
            return None

        raw_snippets = payload.get("inlineCode")
        if not isinstance(raw_snippets, list):
            return None

        snippets: List[InlineCodeSnippet] = []
        for item in raw_snippets:
            snippet = InlineCodeSnippet.from_payload(item)
            if snippet:
                snippets.append(snippet)

        if not snippets:
            return None

        command = str(payload.get("command") or "").strip()
        response = payload.get("response")
        timestamp = payload.get("timestamp")

        return cls(
            command=command,
            snippets=snippets,
            response=str(response) if isinstance(response, str) and response else None,
            timestamp=str(timestamp) if isinstance(timestamp, str) and timestamp else None,
        )

    def to_script(self, *, comment_prefix: Optional[str] = "# ") -> str:
        """Combine all snippets into a single script ready for ``exec``.

        ``comment_prefix`` controls whether snippet labels are included as
        comments. Set it to ``None`` to omit labels entirely.
        """

        blocks: List[str] = []
        for snippet in self.snippets:
            code = snippet.content.strip("\n")
            if not code:
                continue
            label = snippet.label.strip()
            if comment_prefix is not None and label:
                blocks.append(f"{comment_prefix}{label}\n{code}")
            else:
                blocks.append(code)

        script = "\n\n".join(blocks).strip("\n")
        if script and not script.endswith("\n"):
            script += "\n"
        return script

    def to_payload(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "command": self.command,
            "inlineCode": [
                {
                    "label": snippet.label,
                    "content": snippet.content,
                }
                for snippet in self.snippets
            ],
        }
        if self.response is not None:
            payload["response"] = self.response
        if self.timestamp is not None:
            payload["timestamp"] = self.timestamp
        return payload

# Global bridge singleton so give_context() can publish
_BRIDGE_SINGLETON: Optional["OmniLinkHTTPBridge"] = None

# =========================================================
# HTTP Bridge (no external broker needed)
# =========================================================

class _HTTPAgentMessenger(AgentMessenger):
    """Publish structured agent updates via the HTTP bridge's in-memory store."""

    def __init__(self, *, bridge: "OmniLinkHTTPBridge", command: str) -> None:
        self._bridge = bridge
        self._command = command

    def send_feedback(self, feedback: AgentFeedback) -> None:
        payload = feedback.to_legacy_payload()
        payload = json.loads(json.dumps(payload, default=str))
        self._bridge._store_feedback(payload)

    def ask_question(self, question: AgentQuestion) -> PendingQuestion:
        pending = self._bridge.engine.create_question_waiter()
        fallback: Dict[str, Any] = {
            "feedback": True, "ok": True,
            "question": question.prompt,
            "correlationId": pending.correlation_id,
        }
        if question.choices:
            fallback["choices"] = [str(c) for c in question.choices]
        self._bridge._store_feedback(json.loads(json.dumps(fallback, default=str)))
        return pending

    def acknowledge(self, status: str, *, message: Optional[str] = None, data: Optional[Dict[str, Any]] = None) -> None:
        payload: Dict[str, Any] = {"feedback": True, "ok": True, "status": status}
        if message is not None:
            payload["message"] = message
        if data:
            payload["data"] = data
        self._bridge._store_feedback(json.loads(json.dumps(payload, default=str)))


class OmniLinkHTTPBridge:
    """HTTP REST bridge for OmniLinkEngine — no external broker required.

    Runs a lightweight HTTP server that exposes:
      GET  /context   — latest context JSON
      GET  /feedback  — latest feedback JSON
      POST /command   — receive commands from the web UI
      POST /inline-code — receive inline code snippets
    """

    def __init__(
        self,
        engine: OmniLinkEngine,
        host: str = "0.0.0.0",
        port: int = 5000,
        log: bool = True,
        *,
        inline_code_handler: Optional[InlineCodeHandler] = None,
    ) -> None:
        self.engine = engine
        self.host = host
        self.port = port
        self.log = log
        self.inline_code_handler = inline_code_handler

        self._latest_context: Optional[str] = None
        self._latest_feedback: Optional[str] = None
        self._command_queue: "queue.Queue[Optional[_HTTPQueuedCommand]]" = queue.Queue()
        self._server: Optional[Any] = None

        self._command_thread = threading.Thread(
            target=self._command_worker, name="OmniLinkHTTPBridgeWorker", daemon=True,
        )
        self._command_thread.start()

        try:
            self._engine_accepts_messenger = "messenger" in signature(self.engine.handle).parameters
        except (ValueError, TypeError, AttributeError):
            self._engine_accepts_messenger = False

        global _BRIDGE_SINGLETON
        _BRIDGE_SINGLETON = self  # type: ignore[assignment]

    # ---- context / feedback storage ----
    def publish_context(self, context_str: str) -> None:
        payload = json.dumps({"context": str(context_str)})
        self._latest_context = payload
        if self.log:
            LOGGER.info("HTTP context updated", extra={"length": len(context_str)})

    def publish_state_snapshot(
        self,
        *,
        history_limit: Optional[int] = None,
        include_metrics: bool = True,
        include_history: bool = True,
        include_messenger: bool = False,
    ) -> Dict[str, Any]:
        snapshot = self.engine.get_context(
            history_limit=history_limit,
            include_metrics=include_metrics,
            include_history=include_history,
            include_messenger=include_messenger,
        )
        safe_snapshot = _json_safe_copy(snapshot)
        self._latest_context = json.dumps(safe_snapshot)
        if self.log:
            LOGGER.info("HTTP state snapshot updated", extra={"history_limit": history_limit})
        return safe_snapshot

    def _store_feedback(self, payload: Dict[str, Any]) -> None:
        self._latest_feedback = json.dumps(payload)
        if self.log:
            LOGGER.info("HTTP feedback stored", extra={k: v for k, v in payload.items() if k != "details"})

    # ---- command processing ----
    def _command_worker(self) -> None:
        while True:
            queued = self._command_queue.get()
            try:
                if queued is None:
                    return
                self._process_command(queued)
            except Exception:
                LOGGER.exception("HTTP command worker error")
            finally:
                self._command_queue.task_done()

    def _process_command(self, queued: "_HTTPQueuedCommand") -> None:
        try:
            kwargs: Dict[str, Any] = {"meta": queued.meta}
            if queued.messenger is not None:
                kwargs["messenger"] = queued.messenger
            res = self.engine.handle(queued.command, **kwargs)
            result = res.get("result")
            handler_failed = isinstance(result, dict) and bool(result.get("error"))
            feedback_payload = {
                "feedback": bool(res.get("ok")) and not handler_failed,
                "ok": bool(res.get("ok")),
                "template": res.get("template"),
                "normalized_template": res.get("normalized_template"),
                "errors": res.get("errors", []),
            }
            if handler_failed:
                feedback_payload["handler_error"] = result.get("error")
        except Exception as exc:
            LOGGER.exception("HTTP handler exception", extra={"command": queued.command})
            feedback_payload = {
                "feedback": False, "ok": False,
                "error": "handler_exception", "details": str(exc),
            }
        self._store_feedback(feedback_payload)

    def _handle_command(self, payload_text: str) -> Dict[str, Any]:
        data = None
        try:
            data = json.loads(payload_text)
        except json.JSONDecodeError:
            pass

        if isinstance(data, dict):
            command = data.get("command")
            raw_meta = data.get("meta")
            meta = dict(raw_meta) if isinstance(raw_meta, dict) else {}
        else:
            command = payload_text.strip()
            meta = {}

        if not isinstance(command, str) or not command.strip():
            return {"feedback": False, "ok": False, "error": "empty_command"}

        messenger = None
        if self._engine_accepts_messenger:
            messenger = _HTTPAgentMessenger(bridge=self, command=command)

        queued = _HTTPQueuedCommand(command=command, meta=meta, messenger=messenger)
        self._command_queue.put(queued)

        if self.log:
            LOGGER.info("HTTP command queued", extra={"command": command})
        return {"status": "ok", "command": command}

    def _handle_inline_code(self, payload_text: str) -> None:
        try:
            data = json.loads(payload_text)
        except json.JSONDecodeError:
            return
        message = InlineCodeMessage.from_payload(data)
        if not message:
            return
        if self.log:
            LOGGER.info("HTTP inline code received", extra={"command": message.command, "snippet_count": len(message.snippets)})
        if self.inline_code_handler:
            try:
                self.inline_code_handler(message)
            except Exception:
                LOGGER.exception("Inline code handler error")

    # ---- HTTP server ----
    def _create_handler(self):
        bridge = self

        class Handler(_http_server.BaseHTTPRequestHandler):
            def log_message(self, fmt, *args):
                pass

            def _cors(self):
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")

            def do_OPTIONS(self):
                self.send_response(200); self._cors(); self.end_headers()

            def do_GET(self):
                if self.path == "/context":
                    body = (bridge._latest_context or "{}").encode()
                elif self.path == "/feedback":
                    body = (bridge._latest_feedback or "{}").encode()
                else:
                    self.send_error(404); return
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self._cors(); self.end_headers()
                self.wfile.write(body)

            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length).decode("utf-8", errors="replace")

                if self.path == "/command":
                    result = bridge._handle_command(body)
                    resp = json.dumps(result).encode()
                elif self.path == "/inline-code":
                    bridge._handle_inline_code(body)
                    resp = b'{"status":"ok"}'
                else:
                    self.send_error(404); return

                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self._cors(); self.end_headers()
                self.wfile.write(resp)

        return Handler

    def start(self) -> "OmniLinkHTTPBridge":
        """Start HTTP server in a background thread (non-blocking)."""
        handler = self._create_handler()
        self._server = _http_server.ThreadingHTTPServer((self.host, self.port), handler)
        t = threading.Thread(target=self._server.serve_forever, daemon=True, name="OmniLinkHTTPServer")
        t.start()
        if self.log:
            LOGGER.info("HTTP bridge listening", extra={"host": self.host, "port": self.port})
        return self

    def loop_forever(self) -> None:
        """Start HTTP server and block until KeyboardInterrupt."""
        handler = self._create_handler()
        self._server = _http_server.ThreadingHTTPServer((self.host, self.port), handler)
        if self.log:
            LOGGER.info("HTTP bridge listening (blocking)", extra={"host": self.host, "port": self.port})
        try:
            self._server.serve_forever()
        except KeyboardInterrupt:
            pass

    def stop(self) -> None:
        if self._server:
            self._server.shutdown()
            self._server = None


@dataclass
class _HTTPQueuedCommand:
    command: str
    meta: Dict[str, Any]
    messenger: Optional[AgentMessenger]


# =========================================================
# Public API: give_context
# =========================================================

def give_context(context_str: str) -> None:
    """
    Publish a context string via the active HTTP bridge.
    Requires that an OmniLinkHTTPBridge has been instantiated.
    """
    global _BRIDGE_SINGLETON
    if _BRIDGE_SINGLETON is None:
        raise RuntimeError("No bridge initialized; create an OmniLinkHTTPBridge before calling give_context().")
    _BRIDGE_SINGLETON.publish_context(context_str)

# =========================================================
# Periodic context publishing (integrated)
# =========================================================
_CONTEXT_THREAD: Optional[threading.Thread] = None
_CONTEXT_STOP: Optional[threading.Event] = None

def start_periodic_context(interval_seconds: float, message: Union[str, Callable[[], str]]) -> None:
    """
    Start a background thread that calls give_context(...) every `interval_seconds`.
    `message` can be either a string or a zero-arg callable returning a string.
    If called again, it will restart with the new settings.
    """
    global _CONTEXT_THREAD, _CONTEXT_STOP, _BRIDGE_SINGLETON
    if _BRIDGE_SINGLETON is None:
        raise RuntimeError("No bridge initialized; create an OmniLinkHTTPBridge before start_periodic_context().")

    # If already running, stop the old one first
    stop_periodic_context()

    stop_evt = threading.Event()
    _CONTEXT_STOP = stop_evt

    def _producer() -> str:
        return message() if callable(message) else str(message)

    def _loop():
        # first immediate push
        try:
            give_context(_producer())
        except Exception:
            LOGGER.exception("Periodic context initial publish error")

        # then periodic
        while not stop_evt.wait(interval_seconds):
            try:
                give_context(_producer())
            except Exception:
                LOGGER.exception("Periodic context publish error")

    t = threading.Thread(target=_loop, daemon=True)
    _CONTEXT_THREAD = t
    t.start()
    if _BRIDGE_SINGLETON and _BRIDGE_SINGLETON.log:
        LOGGER.info(
            "Periodic context started",
            extra={"interval_seconds": interval_seconds},
        )

def stop_periodic_context() -> None:
    """Stop the periodic context thread if running."""
    global _CONTEXT_THREAD, _CONTEXT_STOP
    if _CONTEXT_STOP is not None:
        _CONTEXT_STOP.set()
        _CONTEXT_STOP = None
    _CONTEXT_THREAD = None



# =========================================================
# Chat API client
# =========================================================

class OmniLinkChatClient:
    """HTTP client for the OmniLink ``/api/chat`` endpoint.

    Parameters
    ----------
    base_url:
        Root URL of your OmniLink deployment, e.g. ``"https://your-app.vercel.app"``.
        No trailing slash needed.
    omni_key:
        Bearer token (Omni Key) used to authenticate requests.
    timeout:
        HTTP request timeout in seconds (default: 30).

    Example
    -------
    ::

        from omnilink import OmniLinkChatClient

        client = OmniLinkChatClient(
            base_url="https://www.omnilink-agents.com",
            omni_key="omk_...",
        )

        response = client.chat(
            prompt="What is the status of mission Alpha?",
            agent_name="mission-control",
        )
        print(response["text"])
    """

    def __init__(
        self,
        base_url: str,
        omni_key: str,
        *,
        timeout: int = 30,
    ) -> None:
        if requests is None:
            raise ImportError(
                "The 'requests' package is required for OmniLinkChatClient. "
                "Install it with: pip install requests"
            )
        self._base_url = base_url.rstrip("/")
        self._omni_key = omni_key
        self._timeout = timeout

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def chat(
        self,
        prompt: Optional[str] = None,
        *,
        agent_name: str,
        messages: Optional[List[Dict[str, Any]]] = None,
        engine: str = "g2-engine",
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        system_instruction_request: Optional[Dict[str, Any]] = None,
        system_instruction_suffix: Optional[str] = None,
        use_prompt_pipeline: bool = False,
        **extra: Any,
    ) -> Dict[str, Any]:
        """Send a chat request to ``/api/chat`` and return the parsed response.

        Either ``prompt`` (a plain string) or ``messages`` (a list of
        ``{"role": ..., "content": ...}`` dicts) must be provided.

        Parameters
        ----------
        prompt:
            Shorthand for a single user message. Mutually exclusive with
            ``messages``.
        agent_name:
            Name of the target agent. Required by the server.
        messages:
            Full conversation array in OpenAI format.  Takes precedence
            over ``prompt`` when both are given.
        engine:
            Which AI engine to use: ``"g1-engine"`` (Gemini),
            ``"g2-engine"`` (GPT-5, default), ``"g3-engine"`` (Grok),
            or ``"g4-engine"`` (Claude).
        temperature:
            Optional sampling temperature forwarded to the engine.
        max_tokens:
            Optional token limit forwarded to the engine.
        system_instruction_request:
            Structured system-instruction object forwarded to the engine.
        system_instruction_suffix:
            Additional text appended to the system instruction.
        use_prompt_pipeline:
            When ``True`` the server composes system instructions
            automatically from agent context.
        **extra:
            Any additional fields to merge into the request body (e.g.
            ``agentPersona``, ``customInstructions``, ``knowledgeMode``).

        Returns
        -------
        dict
            Parsed JSON response. On success contains at minimum
            ``{"ok": True, "text": "...", "requestId": "..."}``.

        Raises
        ------
        requests.RequestException
            On network or HTTP-level failures.
        RuntimeError
            When the server returns a non-2xx status code.
        """
        body: Dict[str, Any] = {
            "agentName": agent_name,
            "engine": engine,
            "usePromptPipeline": use_prompt_pipeline,
        }

        if messages is not None:
            body["messages"] = messages
        elif prompt is not None:
            body["prompt"] = prompt
        else:
            raise ValueError("Either 'prompt' or 'messages' must be provided.")

        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        if system_instruction_request is not None:
            body["systemInstructionRequest"] = system_instruction_request
        if system_instruction_suffix is not None:
            body["systemInstructionSuffix"] = system_instruction_suffix

        body.update(extra)

        url = f"{self._base_url}/api/chat"
        headers = {
            "Authorization": f"Bearer {self._omni_key}",
            "Content-Type": "application/json",
        }

        response = requests.post(url, json=body, headers=headers, timeout=self._timeout)

        if not response.ok:
            try:
                error_body = response.json()
            except Exception:
                error_body = {"raw": response.text}
            raise RuntimeError(
                f"OmniLink chat request failed [{response.status_code}]: {error_body}"
            )

        return response.json()

