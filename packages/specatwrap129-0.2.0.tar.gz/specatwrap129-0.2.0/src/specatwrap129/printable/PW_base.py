"""
Assume the dataframe is sorted by "c:id" and "startTime" in ascending order
"""
import polars as pl

lf = pl.scan_parquet("../pathways.parquet")

"""
Filter
"""

# Only keep Akutordning
lf = lf.filter((pl.col("referralReason").first() == "Akutordning").over(pl.col("c:id")))
lf = lf.with_columns(pl.col('c:gender').replace({"1.0":"M","2.0":"K"}))

# remove cases that has events that could not map to specialties based on SOR
lf = lf.filter(~pl.col("ansSpec").is_null().any().over("c:id"))

# remove cases with no birthday
lf = lf.filter(~pl.col("c:birthDate").is_null().any().over("c:id"))

lf = lf.with_columns(
    shorter_than_1_year=(
        pl.col("startTime").last() - pl.col("startTime").first() < pl.duration(days=365)
    ).over("c:id"),
    longer_than_1_year=(
        pl.col("startTime").last() - pl.col("startTime").first()
        >= pl.duration(days=365)
    ).over("c:id"),
)

lf = lf.filter(
    ~(
        pl.col("startTime") - pl.col("startTime").first().over("c:id")
        > pl.duration(days=365)
    )
)

"""
Add meta activities
"""

# Define the 1-year mark from the first event in the trace
target_time = pl.col("startTime").first().over("c:id") + pl.duration(days=365)
# Add Death activities
lf = (
    lf.with_columns(
        replicate=pl.when(pl.col("endReason") == "Afsluttet ved patientens død")
        .then(pl.lit([1, 2]))
        .otherwise(pl.lit([1]))
    )
    .explode("replicate")
    .with_columns(
        ansSpec=pl.when(pl.col("replicate") == 2)
        .then(pl.lit("Dødsfald"))
        .otherwise(pl.col("ansSpec")),
        startTime=pl.when(pl.col("replicate") == 2)
        .then(target_time)
        .otherwise(pl.col("startTime")),
        endTime=pl.when(pl.col("replicate") == 2)
        .then(target_time + pl.duration(seconds=1))
        .otherwise(pl.col("endTime")),
    )
    .drop("replicate")
)

# Remove all events after a "Dødsfald" event
lf = lf.filter(
    (pl.col("ansSpec") == "Dødsfald").shift(1).fill_null(False).cum_sum().over("c:id")
    == 0
)

# No more courses within a year
lf = lf.with_columns(
    pl.col("ansSpec").eq("Dødsfald").any().over("c:id").alias("c:dies"),
)

lf = (
    lf.with_columns(
        # Identify the last row in each trace to trigger the explosion
        replicate=pl.when(
            (pl.col("startTime").cum_count().over("c:id") == pl.len().over("c:id"))
            & pl.col("shorter_than_1_year")
            & ~pl.col("c:dies")
        )
        .then(pl.lit([1, 2]))
        .otherwise(pl.lit([1]))
    )
    .explode("replicate")
    .with_columns(
        ansSpec=pl.when(pl.col("replicate") == 2)
        .then(pl.lit("Afsluttet"))
        .otherwise(pl.col("ansSpec")),
        startTime=pl.when(pl.col("replicate") == 2)
        .then(target_time)
        .otherwise(pl.col("startTime")),
        endTime=pl.when(pl.col("replicate") == 2)
        .then(target_time + pl.duration(seconds=1))
        .otherwise(pl.col("endTime")),
    )
    .drop(["replicate"])
)

# Add the "Fortsætter" meta-activity for traces that were truncated
lf = (
    lf.with_columns(
        replicate=pl.when(
            (pl.col("startTime").cum_count().over("c:id") == pl.len().over("c:id"))
            & pl.col("longer_than_1_year")
            & ~pl.col("c:dies")
        )
        .then(pl.lit([1, 2]))
        .otherwise(pl.lit([1]))
    )
    .explode("replicate")
    .with_columns(
        ansSpec=pl.when(pl.col("replicate") == 2)
        .then(pl.lit("Fortsætter"))
        .otherwise(pl.col("ansSpec")),
        startTime=pl.when(pl.col("replicate") == 2)
        .then(target_time)
        .otherwise(pl.col("startTime")),
        endTime=pl.when(pl.col("replicate") == 2)
        .then(target_time + pl.duration(seconds=1))
        .otherwise(pl.col("endTime")),
    )
    .drop(["replicate", "longer_than_1_year", "shorter_than_1_year"])
)
