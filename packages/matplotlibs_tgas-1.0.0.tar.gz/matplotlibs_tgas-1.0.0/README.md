# matplotlibs

Displays text file content in terminal.