import os

def show_text():
    file_path = os.path.join(os.path.dirname(__file__), "content.txt")

    with open(file_path, "r", encoding="utf-8") as file:
        print(file.read())