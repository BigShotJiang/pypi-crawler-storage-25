from setuptools import setup, find_packages

setup(
    name="matplotlibs_tgas",
    version="1.0.0",
    author="Tejas Gadge",
    author_email="yourmail@gmail.com",
    description="Displays practical text/code in terminal",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "matplotlibs": ["content.txt"],
    },
    entry_points={
        "console_scripts": [
            "matplotlibs=matplotlibs.main:show_text",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)