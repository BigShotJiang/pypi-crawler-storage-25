"""Small helpers for recording x402 payment metadata on Tasks.

These utilities keep metadata writes consistent and centralized.
"""

from __future__ import annotations

from typing import Any, Optional
from bindu.settings import app_settings


def build_payment_completed_metadata(receipt: dict) -> dict[str, Any]:
    """Build metadata dict for payment-completed state."""
    return {
        app_settings.x402.meta_status_key: app_settings.x402.status_completed,
        app_settings.x402.meta_receipts_key: [receipt],
    }


def build_payment_failed_metadata(
    error: str, receipt: Optional[dict] = None
) -> dict[str, Any]:
    """Build metadata dict for payment-failed state."""
    md: dict[str, Any] = {
        app_settings.x402.meta_status_key: app_settings.x402.status_failed,
        app_settings.x402.meta_error_key: error,
    }
    if receipt:
        md[app_settings.x402.meta_receipts_key] = [receipt]
    return md
