"""Token management utilities for Hydra authentication.

This module provides helper functions for managing OAuth tokens,
including getting tokens for agents and validating tokens.
"""

from __future__ import annotations as _annotations

from typing import Optional

from bindu.settings import app_settings
from .client import http_client
from bindu.utils.logging import get_logger

logger = get_logger("bindu.utils.token_utils")


async def get_client_credentials_token(
    client_id: str,
    client_secret: str,
    scope: Optional[str] = None,
    audience: Optional[str] = None,
) -> Optional[dict]:
    """Get access token using client credentials grant.

    Args:
        client_id: OAuth client ID
        client_secret: OAuth client secret
        scope: Optional space-separated scopes
        audience: Optional audience to request. When provided, Hydra
            includes the value in the issued token's ``aud`` claim — needed
            by step-ca's OIDC provisioner, which rejects tokens without
            ``aud: step-ca``.

    Returns:
        Token response dict with access_token, token_type, expires_in
    """
    try:
        # Use client_secret_post (credentials in body) instead of client_secret_basic
        # because DIDs contain colons which break HTTP Basic auth
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
        }

        data = {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
        }

        if scope:
            data["scope"] = scope
        if audience:
            data["audience"] = audience

        async with http_client(
            base_url=app_settings.hydra.public_url,
            verify_ssl=app_settings.hydra.verify_ssl,
            timeout=app_settings.hydra.timeout,
        ) as client:
            response = await client.post("/oauth2/token", headers=headers, data=data)

            if response.status == 200:
                result = await response.json()
                logger.debug(f"Token obtained for client: {client_id}")
                return result
            else:
                error_text = await response.text()
                logger.error(
                    f"Failed to get token for {client_id}: {response.status} - {error_text}"
                )
                return None

    except Exception as e:
        logger.error(f"Failed to get client credentials token: {e}")
        return None


async def introspect_token(token: str) -> Optional[dict]:
    """Introspect a token to check if it's valid.

    Args:
        token: Access token to introspect

    Returns:
        Introspection result dict or None
    """
    from bindu.auth.hydra.client import HydraClient

    try:
        async with HydraClient(
            admin_url=app_settings.hydra.admin_url,
            public_url=app_settings.hydra.public_url,
            timeout=app_settings.hydra.timeout,
            verify_ssl=app_settings.hydra.verify_ssl,
        ) as hydra:
            result = await hydra.introspect_token(token)
            return result

    except Exception as e:
        logger.error(f"Failed to introspect token: {e}")
        return None


async def revoke_token(token: str) -> bool:
    """Revoke an access or refresh token.

    Args:
        token: Token to revoke

    Returns:
        True if revoked successfully, False otherwise
    """
    from bindu.auth.hydra.client import HydraClient

    try:
        async with HydraClient(
            admin_url=app_settings.hydra.admin_url,
            public_url=app_settings.hydra.public_url,
            timeout=app_settings.hydra.timeout,
            verify_ssl=app_settings.hydra.verify_ssl,
        ) as hydra:
            return await hydra.revoke_token(token)

    except Exception as e:
        logger.error(f"Failed to revoke token: {e}")
        return False
