from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

install_requires = [
    "requests",
    "beautifulsoup4",
    "click",
    "rich",
    "selenium",
    "webdriver-manager",
]

dev_requires = [
    "pytest",
    "pytest-requests-mock",
]

setup(
    name="slave-cp",
    version="0.1.0",
    author="block-plant",
    description="A CLI tool to automate competitive programming workflow",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/block-plant/slave-cp",
    packages=find_packages(),
    install_requires=install_requires,
    extras_require={
        "dev": dev_requires,
    },
    python_requires=">=3.7",
    entry_points={
        "console_scripts": [
            "slave-cp=slave_cp.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)