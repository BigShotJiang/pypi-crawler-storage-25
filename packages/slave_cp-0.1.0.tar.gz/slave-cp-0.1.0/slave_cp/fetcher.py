import os
import requests
from pathlib import Path
from bs4 import BeautifulSoup
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from slave_cp.runner import LANGUAGES
from slave_cp import config

console = Console()

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
}


# ─── MAIN ENTRY POINT ───────────────────────────────────────────────────────

def fetch_contest(contest_id: str, platform: str, workspace: Path):
    """Main function called by cli.py to fetch a contest."""
    if platform == "codeforces":
        fetch_codeforces(contest_id, workspace)
    elif platform == "codechef":
        fetch_codechef(contest_id, workspace)
    else:
        raise ValueError(f"Unsupported platform: {platform}")


# ─── CODEFORCES ─────────────────────────────────────────────────────────────

def fetch_codeforces(contest_id: str, workspace: Path):
    """Fetch all problems and test cases from a Codeforces contest."""

    # Extract numeric contest ID from e.g. CF1234 → 1234
    numeric_id = contest_id.upper().replace("CF", "").strip()

    contest_url = f"https://codeforces.com/contest/{numeric_id}/problems"
    console.print(f"[dim]Fetching problem list from:[/] {contest_url}")

    response = requests.get(contest_url, headers=HEADERS)
    if response.status_code != 200:
        raise ConnectionError(f"Failed to fetch contest page (HTTP {response.status_code}). Check the contest ID.")

    soup = BeautifulSoup(response.text, "html.parser")

    # Find all problem letters from the problem table
    problem_tags = soup.select("table.problems tr td:first-child a")
    if not problem_tags:
        raise ValueError("No problems found. The contest may not have started yet or the ID is wrong.")

    problem_letters = [tag.text.strip() for tag in problem_tags]
    console.print(f"[bold green]✔ Found {len(problem_letters)} problems:[/] {', '.join(problem_letters)}\n")

    # Create contest folder inside workspace
    contest_folder = workspace / contest_id.upper()
    contest_folder.mkdir(parents=True, exist_ok=True)

    # Load preferred extension from config
    cfg = config.load_config()
    ext = cfg.get("extension", ".cpp")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        for letter in problem_letters:
            task = progress.add_task(f"Fetching problem {letter}...", total=None)

            problem_url = f"https://codeforces.com/contest/{numeric_id}/problem/{letter}"
            test_cases = scrape_codeforces_testcases(problem_url)

            # Create problem folder and solution template
            problem_folder = contest_folder / letter
            problem_folder.mkdir(exist_ok=True)
            create_solution_template(contest_folder, letter, ext)

            # Write test cases
            write_testcases(problem_folder, test_cases)

            progress.update(task, description=f"[green]✔ Problem {letter} — {len(test_cases)} test case(s)[/]", completed=True)

    console.print(f"\n[bold green]✔ Contest {contest_id} ready at:[/] {contest_folder}\n")


def scrape_codeforces_testcases(problem_url: str) -> list[dict]:
    """Scrape input/output test cases from a Codeforces problem page."""
    response = requests.get(problem_url, headers=HEADERS)
    if response.status_code != 200:
        raise ConnectionError(f"Failed to fetch problem page: {problem_url}")

    soup = BeautifulSoup(response.text, "html.parser")

    test_cases = []
    sample_tests = soup.find("div", class_="sample-test")
    if not sample_tests:
        return test_cases

    inputs  = sample_tests.find_all("div", class_="input")
    outputs = sample_tests.find_all("div", class_="output")

    for i, (inp, out) in enumerate(zip(inputs, outputs), start=1):
        input_text  = inp.find("pre").get_text(separator="\n").strip()
        output_text = out.find("pre").get_text(separator="\n").strip()
        test_cases.append({
            "index":  i,
            "input":  input_text,
            "output": output_text
        })

    return test_cases


# ─── CODECHEF ───────────────────────────────────────────────────────────────

def fetch_codechef(contest_id: str, workspace: Path):
    """Fetch all problems and test cases from a CodeChef contest."""

    # Extract ID from e.g. CC-START001 → START001
    numeric_id = contest_id.upper().replace("CC-", "").replace("CC", "").strip()

    console.print(f"[dim]Fetching CodeChef contest:[/] {numeric_id}")
    console.print("[yellow]⚠ CodeChef requires browser automation (Selenium). Launching browser...[/]\n")

    try:
        from selenium import webdriver
        from selenium.webdriver.chrome.service import Service
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        from webdriver_manager.chrome import ChromeDriverManager
    except ImportError:
        raise ImportError("Selenium not installed. Run: pip install selenium webdriver-manager")

    options = webdriver.ChromeOptions()
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")

    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=options
    )

    # Load preferred extension from config
    cfg = config.load_config()
    ext = cfg.get("extension", ".cpp")

    try:
        # Get problem list
        contest_url = f"https://www.codechef.com/contests/{numeric_id}/problems"
        driver.get(contest_url)
        WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "a[href*='/problems/']"))
        )

        soup = BeautifulSoup(driver.page_source, "html.parser")
        problem_links = soup.select("a[href*='/problems/']")

        problem_codes = []
        for link in problem_links:
            href = link.get("href", "")
            if f"/{numeric_id}/" in href:
                code = href.split("/")[-1].strip().upper()
                if code and code not in problem_codes:
                    problem_codes.append(code)

        if not problem_codes:
            raise ValueError("No problems found. Check the contest ID.")

        console.print(f"[bold green]✔ Found {len(problem_codes)} problems:[/] {', '.join(problem_codes)}\n")

        contest_folder = workspace / contest_id.upper()
        contest_folder.mkdir(parents=True, exist_ok=True)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            for code in problem_codes:
                task = progress.add_task(f"Fetching problem {code}...", total=None)

                problem_url = f"https://www.codechef.com/{numeric_id}/problems/{code}"
                driver.get(problem_url)
                WebDriverWait(driver, 15).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, "section"))
                )

                test_cases = scrape_codechef_testcases(driver.page_source)

                problem_folder = contest_folder / code
                problem_folder.mkdir(exist_ok=True)
                create_solution_template(contest_folder, code, ext)
                write_testcases(problem_folder, test_cases)

                progress.update(task, description=f"[green]✔ Problem {code} — {len(test_cases)} test case(s)[/]", completed=True)

        console.print(f"\n[bold green]✔ Contest {contest_id} ready at:[/] {contest_folder}\n")

    finally:
        driver.quit()


def scrape_codechef_testcases(page_source: str) -> list[dict]:
    """Scrape input/output test cases from a CodeChef problem page source."""
    soup = BeautifulSoup(page_source, "html.parser")
    test_cases = []

    sections = soup.find_all("section")
    for section in sections:
        heading = section.find(["h2", "h3", "h4"])
        if heading and "example" in heading.get_text().lower():
            pres = section.find_all("pre")
            for i in range(0, len(pres) - 1, 2):
                input_text  = pres[i].get_text(separator="\n").strip()
                output_text = pres[i + 1].get_text(separator="\n").strip()
                test_cases.append({
                    "index":  len(test_cases) + 1,
                    "input":  input_text,
                    "output": output_text
                })

    return test_cases


# ─── HELPERS ────────────────────────────────────────────────────────────────

def write_testcases(problem_folder: Path, test_cases: list[dict]):
    """Write input/output test case files into the problem folder."""
    for tc in test_cases:
        input_file  = problem_folder / f"input{tc['index']}.txt"
        output_file = problem_folder / f"output{tc['index']}.txt"
        input_file.write_text(tc["input"],  encoding="utf-8")
        output_file.write_text(tc["output"], encoding="utf-8")


def create_solution_template(contest_folder: Path, problem_letter: str, extension: str = ".cpp"):
    """Create a blank solution file with the correct template for the language."""
    if extension not in LANGUAGES:
        console.print(f"[yellow]⚠ Unknown extension {extension}, defaulting to .cpp[/]")
        extension = ".cpp"

    lang = LANGUAGES[extension]
    solution_file = contest_folder / f"{problem_letter}{extension}"

    if solution_file.exists():
        return  # Don't overwrite if already exists

    template = lang["template"]

    # Java needs class name to match filename
    if extension == ".java":
        template = template.format(classname=problem_letter.upper())

    solution_file.write_text(template, encoding="utf-8")