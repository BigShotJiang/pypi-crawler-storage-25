import json
import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".slave-cp"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_CONFIG = {
    "workspace": None,
    "language": "cpp",
    "codeforces": {
        "handle": None,
        "password": None
    },
    "codechef": {
        "handle": None,
        "password": None
    }
}


def init_config():
    """Create config directory and file if they don't exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_FILE.exists():
        save_config(DEFAULT_CONFIG)


def load_config() -> dict:
    """Load config from file. Returns default if file doesn't exist."""
    init_config()
    with open(CONFIG_FILE, "r") as f:
        return json.load(f)


def save_config(config: dict):
    """Save config dictionary to file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=4)


def set_workspace(path: str):
    """Set and save the workspace path."""
    workspace = Path(path).expanduser().resolve()
    if not workspace.exists():
        workspace.mkdir(parents=True, exist_ok=True)
    config = load_config()
    config["workspace"] = str(workspace)
    save_config(config)
    return workspace


def get_workspace() -> Path:
    """Get workspace path. Raises error if not set."""
    config = load_config()
    if not config["workspace"]:
        raise ValueError(
            "Workspace not set. Run 'slave-cp init <path>' first."
        )
    return Path(config["workspace"])


def set_credentials(platform: str, handle: str, password: str):
    """Save credentials for a platform (codeforces or codechef)."""
    config = load_config()
    config[platform]["handle"] = handle
    config[platform]["password"] = password
    save_config(config)


def get_credentials(platform: str) -> dict:
    """Get saved credentials for a platform."""
    config = load_config()
    return config.get(platform, {})