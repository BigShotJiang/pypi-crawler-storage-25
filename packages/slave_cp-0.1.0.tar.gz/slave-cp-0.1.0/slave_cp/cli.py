import click
from rich.console import Console
from slave_cp import config, fetcher, runner, submitter

console = Console()


# ─── MAIN GROUP ─────────────────────────────────────────────────────────────

@click.group(invoke_without_command=True)
@click.pass_context
def main(ctx):
    """slave-cp: Automate your competitive programming workflow."""
    if ctx.invoked_subcommand is None:
        from slave_cp.utils import print_banner
        print_banner()
        click.echo(ctx.get_help())


# ─── INIT ───────────────────────────────────────────────────────────────────

@main.command()
@click.argument("path")
def init(path):
    """Set your workspace folder and save credentials.

    Example: slave-cp init ~/competitive
    """
    workspace = config.set_workspace(path)
    console.print(f"\n[bold green]✔ Workspace set to:[/] {workspace}")

    console.print("\n[bold cyan]Codeforces credentials (for auto-submit):[/]")
    cf_handle   = click.prompt("  Handle", default="", show_default=False)
    cf_password = click.prompt("  Password", hide_input=True, default="", show_default=False)
    if cf_handle:
        config.set_credentials("codeforces", cf_handle, cf_password)
        console.print("[bold green]✔ Codeforces credentials saved.[/]")

    console.print("\n[bold cyan]CodeChef credentials (for auto-submit):[/]")
    cc_handle   = click.prompt("  Handle", default="", show_default=False)
    cc_password = click.prompt("  Password", hide_input=True, default="", show_default=False)
    if cc_handle:
        config.set_credentials("codechef", cc_handle, cc_password)
        console.print("[bold green]✔ CodeChef credentials saved.[/]")

    console.print("\n[bold cyan]Preferred language extension (e.g. .cpp, .py, .java):[/]")
    ext = click.prompt("  Extension", default=".cpp", show_default=True)
    cfg = config.load_config()
    cfg["extension"] = ext
    config.save_config(cfg)
    console.print(f"[bold green]✔ Default extension set to {ext}[/]")

    console.print("\n[bold green]✔ slave-cp is ready! Happy coding.[/]\n")


# ─── FETCH ──────────────────────────────────────────────────────────────────

@main.command()
@click.argument("contest_id")
def fetch(contest_id):
    """Fetch all problems and test cases for a contest.

    Example: slave-cp fetch CF1234
             slave-cp fetch CC-START001
    """
    console.print(f"\n[bold cyan]Fetching contest:[/] {contest_id}\n")

    try:
        workspace = config.get_workspace()
    except ValueError as e:
        console.print(f"[bold red]✘ {e}[/]")
        return

    platform = detect_platform(contest_id)
    if not platform:
        console.print("[bold red]✘ Could not detect platform. Use CF<id> for Codeforces or CC-<id> for CodeChef.[/]")
        return

    try:
        fetcher.fetch_contest(contest_id, platform, workspace)
    except Exception as e:
        console.print(f"[bold red]✘ Error fetching contest: {e}[/]")


# ─── RUN ────────────────────────────────────────────────────────────────────

@main.command()
@click.argument("problem")
@click.option("--contest", "-c", default=None, help="Contest ID (e.g. CF1234). Auto-detected if inside contest folder.")
def run(problem, contest):
    """Compile and test your solution against all test cases.

    Example: slave-cp run A
             slave-cp run A --contest CF1234
    """
    try:
        workspace = config.get_workspace()
    except ValueError as e:
        console.print(f"[bold red]✘ {e}[/]")
        return

    contest_id = contest or detect_contest_from_cwd(workspace)
    if not contest_id:
        console.print("[bold red]✘ Could not detect contest. Use --contest CF1234 or run from inside the contest folder.[/]")
        return

    console.print(f"\n[bold cyan]Running:[/] {contest_id}/{problem.upper()}\n")

    try:
        all_passed = runner.run_problem(problem, contest_id, workspace)
    except FileNotFoundError as e:
        console.print(f"[bold red]✘ {e}[/]")
        return

    if all_passed:
        console.print("\n[bold green]✔ All test cases passed![/]")
        submit = click.confirm("\nDo you want to submit to the judge?", default=False)
        if submit:
            platform = detect_platform(contest_id)
            try:
                submitter.submit(problem, contest_id, platform, workspace)
            except Exception as e:
                console.print(f"[bold red]✘ Submission failed: {e}[/]")
    else:
        console.print("\n[bold red]✘ Some test cases failed. Fix your solution and try again.[/]\n")


# ─── CONFIG ─────────────────────────────────────────────────────────────────

@main.command("config")
def show_config():
    """Show current slave-cp configuration."""
    cfg = config.load_config()
    console.print("\n[bold cyan]Current Configuration:[/]")
    console.print(f"  Workspace : [green]{cfg['workspace']}[/]")
    console.print(f"  Extension : [green]{cfg['extension']}[/]")
    console.print(f"  CF Handle : [green]{cfg['codeforces']['handle']}[/]")
    console.print(f"  CC Handle : [green]{cfg['codechef']['handle']}[/]")
    console.print()


# ─── LIST ───────────────────────────────────────────────────────────────────

@main.command("list")
def list_contests_cmd():
    """List all contests in your workspace."""
    try:
        workspace = config.get_workspace()
    except ValueError as e:
        console.print(f"[bold red]✘ {e}[/]")
        return
    from slave_cp.utils import list_contests
    list_contests(workspace)


# ─── CHECK ──────────────────────────────────────────────────────────────────

@main.command("check")
def check_deps():
    """Check which compilers and interpreters are installed."""
    from slave_cp.utils import check_dependencies
    check_dependencies()


# ─── HELPERS ────────────────────────────────────────────────────────────────

def detect_platform(contest_id: str) -> str | None:
    """Detect platform from contest ID prefix."""
    contest_id = contest_id.upper()
    if contest_id.startswith("CF"):
        return "codeforces"
    elif contest_id.startswith("CC"):
        return "codechef"
    return None


def detect_contest_from_cwd(workspace) -> str | None:
    """If user is inside a contest folder, detect the contest ID."""
    import os
    from pathlib import Path
    cwd = Path(os.getcwd())
    if cwd.parent == workspace:
        return cwd.name
    return None