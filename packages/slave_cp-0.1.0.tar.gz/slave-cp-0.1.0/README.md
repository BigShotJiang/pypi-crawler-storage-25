# ⚡ slave-cp

> Your competitive programming workflow, automated.

[![CI](https://github.com/block-plant/slave-cp/actions/workflows/ci.yml/badge.svg)](https://github.com/block-plant/slave-cp/actions)
[![PyPI version](https://img.shields.io/pypi/v/slave-cp.svg)](https://pypi.org/project/slave-cp/)
[![Python](https://img.shields.io/pypi/pyversions/slave-cp.svg)](https://pypi.org/project/slave-cp/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

**slave-cp** is a command-line tool that automates the repetitive parts of competitive programming — fetching problems, running test cases with rich diffs, and submitting — so you can focus entirely on solving.

---

## ✨ Features

- 📥 **Fetch** problems and sample test cases from Codeforces in one command
- 🗂️ **Auto-generates** a clean folder structure and solution templates
- ▶️ **Run** your solution against all test cases with colored pass/fail output
- 🔍 **Diff view** — see exactly where your output differs from expected
- 🚀 **Auto-submit** — triggered automatically when all test cases pass
- 🌐 **23 languages** supported — C++, Python, Java, Rust, Go, Kotlin, and more
- 🔒 **Credentials stored locally** — no third-party servers, ever

---

## 📦 Installation

```bash
pip install slave-cp
```

Requires Python 3.7+.

---

## 🚀 Quick Start

```bash
# 1. Set your workspace and save credentials (one-time setup)
slave-cp init ~/competitive

# 2. Fetch a contest
slave-cp fetch CF1234

# 3. Solve problem A (edit A.cpp, A.py, A.java — whatever language you like)
vim ~/competitive/CF1234/A.cpp

# 4. Run against sample test cases
slave-cp run A

# 5. If all pass, you'll be asked to submit automatically
```

---

## 📁 Folder Structure

After `slave-cp fetch CF1234`:

```
~/competitive/
└── CF1234/
    ├── A.cpp              ← pre-created solution template
    ├── A/
    │   ├── input1.txt
    │   ├── output1.txt
    │   ├── input2.txt
    │   └── output2.txt
    ├── B.cpp
    ├── B/
    │   └── ...
    └── ...
```

---

## 🖥️ Commands

### `slave-cp init <path>`
Set your workspace folder and save credentials for Codeforces and CodeChef. Run this once before anything else.

```bash
slave-cp init ~/competitive
# ✔ Workspace set to: ~/competitive
# Codeforces handle: tourist
# Codeforces password: ••••••••
# ✔ Codeforces credentials saved.
# Default extension: .cpp
# ✔ slave-cp is ready! Happy coding.
```

---

### `slave-cp fetch <contest-id>`
Scrapes all problems and sample test cases for a contest. Supports Codeforces (`CF<id>`) and CodeChef (`CC-<id>`).

```bash
slave-cp fetch CF1234        # Codeforces contest 1234
slave-cp fetch CC-START001   # CodeChef contest
```

---

### `slave-cp run <problem>`
Compiles and runs your solution against all sample test cases. If all pass, you'll be prompted to submit.

```bash
slave-cp run A
slave-cp run A --contest CF1234   # specify contest explicitly
```

**Output:**
```
Language detected: C++
Compiling: A.cpp ... OK
Running 3 test case(s)...

  ✔ Test 1  →  ACCEPTED
  ✘ Test 2  →  WRONG ANSWER

  ╭───┬─────────┬─────────────────┬──────────────╮
  │   │ Input   │ Expected Output │ Your Output  │
  ├───┼─────────┼─────────────────┼──────────────┤
  │ 1 │ 3 5     │ 4               │ 3            │
  ╰───┴─────────┴─────────────────┴──────────────╯

  ✔ Test 3  →  ACCEPTED

─────────────────────────────────────────────
  ✘ 2/3 passed — 1 failed
─────────────────────────────────────────────
```

If all test cases pass:
```
─────────────────────────────────────────────
  ✔ All 3/3 test cases passed!
─────────────────────────────────────────────
Do you want to submit to the judge? [y/N]:
```

If multiple language files exist for the same problem (e.g. `A.cpp` and `A.py`), slave-cp will ask which one to run.

When all tests pass and you confirm submit, slave-cp logs in and polls for the verdict:

```
✔ Logged in successfully.
Submitting problem A (.cpp) ...
✔ Solution submitted successfully!

Waiting for verdict.........

  ✔ ACCEPTED 🎉
```

Possible verdicts: `ACCEPTED`, `WRONG ANSWER`, `TIME LIMIT EXCEEDED`, `MEMORY LIMIT EXCEEDED`, `RUNTIME ERROR`, `COMPILATION ERROR`.

> **Note:** CodeChef submission uses Selenium with headless Chrome, same as `slave-cp fetch`.

---

### `slave-cp config`
Show your current configuration.

```bash
slave-cp config
# Workspace : ~/competitive
# Extension : .cpp
# CF Handle : tourist
# CC Handle : chef
```

---

### `slave-cp list`
List all contests in your workspace.

```bash
slave-cp list
```

---

### `slave-cp check`
Check which compilers and interpreters are installed on your system.

```bash
slave-cp check
```

---

## 🌐 Supported Languages

| Language | Extension | Compiled |
|---|---|---|
| C++ | `.cpp` | ✅ `g++ -O2 -std=c++17` |
| C | `.c` | ✅ `gcc -O2` |
| Python 3 | `.py` | ❌ |
| PyPy 3 | `.pypy` | ❌ |
| Java | `.java` | ✅ `javac` |
| Kotlin | `.kt` | ✅ `kotlinc` |
| Go | `.go` | ✅ `go build` |
| Rust | `.rs` | ✅ `rustc -O` |
| C# | `.cs` | ❌ `dotnet-script` |
| Ruby | `.rb` | ❌ |
| JavaScript | `.js` | ❌ |
| TypeScript | `.ts` | ✅ `tsc` |
| Haskell | `.hs` | ✅ `ghc -O2` |
| Scala | `.scala` | ✅ `scalac` |
| D | `.d` | ✅ `dmd -O` |
| Pascal | `.pas` | ✅ `fpc` |
| Perl | `.pl` | ❌ |
| PHP | `.php` | ❌ |
| Swift | `.swift` | ✅ `swiftc` |
| Lua | `.lua` | ❌ |
| R | `.r` | ❌ |
| Dart | `.dart` | ❌ |
| F# | `.fs` | ❌ `dotnet-fsi` |

---

## ⚙️ Configuration

Config is stored at `~/.slave-cp/config.json`:

```json
{
  "workspace": "~/competitive",
  "extension": ".cpp",
  "codeforces": { "handle": "tourist" },
  "codechef":   { "handle": "chef" }
}
```

To update, just re-run `slave-cp init` or edit the file directly.

---

## 🧪 Running Tests

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run all tests
pytest tests/ -v
```

Tests cover:
- `test_config.py` — init, save/load, workspace, credentials
- `test_fetcher.py` — write test cases, templates, CF scraping (mocked HTTP)
- `test_runner.py` — load test cases, detect solution, run (AC / WA / TLE / RE), summary

---

## 🗺️ Roadmap

- [x] Phase 1 — Fetch + folder setup (Codeforces)
- [x] Phase 2 — Run & test locally with diff output
- [x] Phase 3 — Auto-submit to Codeforces
- [x] Phase 4 — CodeChef support
- [x] Phase 5 — Published on PyPI

---

## 🤝 Contributing

Pull requests are welcome! For major changes, open an issue first.

```bash
git clone https://github.com/block-plant/slave-cp
cd slave-cp
pip install -e ".[dev]"
pytest tests/
```

Please make sure tests pass and code is formatted with `black` before submitting a PR.

---

## 📄 License

[MIT](LICENSE) © block-plant