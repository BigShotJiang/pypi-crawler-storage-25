from dataclasses import dataclass, field
from typing import Callable, Sequence
import click

from chattool.setup.chrome import setup_chrome_driver
from chattool.setup.claude import setup_claude
from chattool.setup.codex import setup_codex
from chattool.setup.cc_connect import setup_cc_connect
from chattool.setup.frp import setup_frp
from chattool.setup.lark_cli import setup_lark_cli
from chattool.setup.opencode import setup_opencode
from chattool.setup.alias import setup_alias
from chattool.setup.nodejs import setup_nodejs
from chattool.setup.playground import setup_playground


@dataclass(frozen=True)
class SetupOptionElement:
    param_decls: Sequence[str]
    kwargs: dict = field(default_factory=dict)


@dataclass(frozen=True)
class SetupCommandElement:
    name: str
    help: str
    callback: Callable
    options: Sequence[SetupOptionElement] = field(default_factory=tuple)


def chrome_setup(interactive):
    setup_chrome_driver(interactive=interactive)


def frp_setup(interactive):
    setup_frp(interactive=interactive)


def nodejs_setup(interactive):
    setup_nodejs(interactive=interactive)


def alias_setup(shell, dry_run):
    setup_alias(shell=shell, dry_run=dry_run)


def codex_setup(preferred_auth_method, base_url, model, env, interactive):
    setup_codex(
        preferred_auth_method=preferred_auth_method,
        base_url=base_url,
        model=model,
        env_ref=env,
        interactive=interactive,
    )


def cc_connect_setup(interactive):
    setup_cc_connect(interactive=interactive)


def claude_setup(auth_token, base_url, small_fast_model, interactive):
    setup_claude(
        auth_token=auth_token,
        base_url=base_url,
        small_fast_model=small_fast_model,
        interactive=interactive,
    )


def opencode_setup(base_url, api_key, model, interactive):
    setup_opencode(
        base_url=base_url,
        api_key=api_key,
        model=model,
        interactive=interactive,
    )


def lark_cli_setup(app_id, app_secret, brand, env, interactive):
    setup_lark_cli(
        app_id=app_id,
        app_secret=app_secret,
        brand=brand,
        env_ref=env,
        interactive=interactive,
    )


def playground_setup(workspace_dir, chattool_source, interactive, force):
    setup_playground(
        workspace_dir=workspace_dir,
        chattool_source=chattool_source,
        interactive=interactive,
        force=force,
    )


SETUP_COMMAND_ELEMENTS = (
    SetupCommandElement(
        name="alias",
        help="Setup shell aliases for ChatTool commands.",
        callback=alias_setup,
        options=(
            SetupOptionElement(
                param_decls=("-s", "--shell"),
                kwargs={"default": None, "type": click.Choice(["zsh", "bash"]), "help": "Target shell: zsh or bash. Defaults to $SHELL."},
            ),
            SetupOptionElement(
                param_decls=("--dry-run",),
                kwargs={"is_flag": True, "help": "Preview alias changes without writing to shell rc file."},
            ),
        ),
    ),
    SetupCommandElement(
        name="cc-connect",
        help="Setup cc-connect CLI and runtime dependencies.",
        callback=cc_connect_setup,
        options=(
            SetupOptionElement(
                param_decls=("--interactive/--no-interactive", "-i/-I"),
                kwargs={"default": None, "help": "Auto prompt on missing args, -i forces interactive, -I disables it."},
            ),
        ),
    ),
    SetupCommandElement(
        name="claude",
        help="Setup Claude Code CLI and config files.",
        callback=claude_setup,
        options=(
            SetupOptionElement(
                param_decls=("--interactive/--no-interactive", "-i/-I"),
                kwargs={"default": None, "help": "Auto prompt on missing args, -i forces interactive, -I disables it."},
            ),
            SetupOptionElement(
                param_decls=("--auth-token", "--token"),
                kwargs={"default": None, "help": "Value for ANTHROPIC_AUTH_TOKEN."},
            ),
            SetupOptionElement(
                param_decls=("--base-url", "--url"),
                kwargs={"default": None, "help": "Optional ANTHROPIC_BASE_URL value."},
            ),
            SetupOptionElement(
                param_decls=("--small-fast-model", "--sfm"),
                kwargs={"default": None, "help": "Optional ANTHROPIC_SMALL_FAST_MODEL value."},
            ),
        ),
    ),
    SetupCommandElement(
        name="chrome",
        help="Setup Chrome and Chromedriver.",
        callback=chrome_setup,
        options=(
            SetupOptionElement(
                param_decls=("--interactive/--no-interactive", "-i/-I"),
                kwargs={"default": None, "help": "Auto prompt on missing args, -i forces interactive, -I disables it."},
            ),
        ),
    ),
    SetupCommandElement(
        name="frp",
        help="Setup FRP Client/Server.",
        callback=frp_setup,
        options=(
            SetupOptionElement(
                param_decls=("--interactive/--no-interactive", "-i/-I"),
                kwargs={"default": None, "help": "Auto prompt on missing args, -i forces interactive, -I disables it."},
            ),
        ),
    ),
    SetupCommandElement(
        name="nodejs",
        help="Setup nvm and Node.js (default LTS).",
        callback=nodejs_setup,
        options=(
            SetupOptionElement(
                param_decls=("--interactive/--no-interactive", "-i/-I"),
                kwargs={"default": None, "help": "Auto prompt on missing args, -i forces interactive, -I disables it."},
            ),
        ),
    ),
    SetupCommandElement(
        name="codex",
        help="Setup Codex CLI and config files.",
        callback=codex_setup,
        options=(
            SetupOptionElement(
                param_decls=("--interactive/--no-interactive", "-i/-I"),
                kwargs={"default": None, "help": "Auto prompt on missing args, -i forces interactive, -I disables it."},
            ),
            SetupOptionElement(
                param_decls=("--preferred-auth-method", "--pam"),
                kwargs={"default": None, "help": "Value for preferred_auth_method and OPENAI_API_KEY."},
            ),
            SetupOptionElement(
                param_decls=("--base-url", "--url"),
                kwargs={"default": None, "help": "Optional base_url for model provider."},
            ),
            SetupOptionElement(
                param_decls=("--model",),
                kwargs={"default": None, "help": "Optional default model name."},
            ),
            SetupOptionElement(
                param_decls=("-e", "--env"),
                kwargs={"default": None, "help": "Load OpenAI config from a .env file path or saved OpenAI profile name."},
            ),
        ),
    ),
    SetupCommandElement(
        name="opencode",
        help="Setup OpenCode CLI and config files.",
        callback=opencode_setup,
        options=(
            SetupOptionElement(
                param_decls=("--interactive/--no-interactive", "-i/-I"),
                kwargs={"default": None, "help": "Auto prompt on missing args, -i forces interactive, -I disables it."},
            ),
            SetupOptionElement(
                param_decls=("--base-url", "--url"),
                kwargs={"default": None, "help": "Required base URL for the provider."},
            ),
            SetupOptionElement(
                param_decls=("--api-key", "--key"),
                kwargs={"default": None, "help": "Required API key for the provider."},
            ),
            SetupOptionElement(
                param_decls=("--model",),
                kwargs={"default": None, "help": "Required default model name."},
            ),
        ),
    ),
    SetupCommandElement(
        name="lark-cli",
        help="Setup official lark-cli and reuse ChatTool Feishu config.",
        callback=lark_cli_setup,
        options=(
            SetupOptionElement(
                param_decls=("--interactive/--no-interactive", "-i/-I"),
                kwargs={"default": None, "help": "Auto prompt on missing args, -i forces interactive, -I disables it."},
            ),
            SetupOptionElement(
                param_decls=("--app-id",),
                kwargs={"default": None, "help": "Lark/Feishu app id."},
            ),
            SetupOptionElement(
                param_decls=("--app-secret",),
                kwargs={"default": None, "help": "Lark/Feishu app secret."},
            ),
            SetupOptionElement(
                param_decls=("--brand",),
                kwargs={"default": None, "type": click.Choice(["feishu", "lark"]), "help": "Official brand value written to lark-cli config."},
            ),
            SetupOptionElement(
                param_decls=("-e", "--env"),
                kwargs={"default": None, "help": "Load Feishu config from a .env file path or saved Feishu profile name."},
            ),
        ),
    ),
    SetupCommandElement(
        name="playground",
        help="Bootstrap or update a workspace with a ChatTool clone, memory files, and workspace skills.",
        callback=playground_setup,
        options=(
            SetupOptionElement(
                param_decls=("--interactive/--no-interactive", "-i/-I"),
                kwargs={"default": None, "help": "Auto prompt on missing args, -i forces interactive, -I disables it."},
            ),
            SetupOptionElement(
                param_decls=("--workspace-dir", "--dir"),
                kwargs={"default": None, "help": "Workspace root directory. Defaults to current directory."},
            ),
            SetupOptionElement(
                param_decls=("--chattool-source", "--source"),
                kwargs={"default": None, "help": "Git URL or local ChatTool repo path used for cloning/updating workspace/ChatTool."},
            ),
            SetupOptionElement(
                param_decls=("--force",),
                kwargs={"is_flag": True, "help": "Allow overwriting generated files and replace a broken non-git ChatTool directory when rerunning."},
            ),
        ),
    ),
)
