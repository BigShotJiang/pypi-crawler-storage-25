"""YADE MCP Server - YADE open-source DEM simulation tools via MCP."""

__version__ = "0.3.0"
