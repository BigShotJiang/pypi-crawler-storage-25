import ctboost
import numpy as np


def test_build_info_matches_package_version():
    info = ctboost.build_info()
    assert info["version"] == ctboost.__version__
    assert info["cxx_standard"] == 17
    assert isinstance(info["cuda_enabled"], bool)
    assert isinstance(info["cuda_runtime"], str)
    assert isinstance(info["compiler"], str)


def test_pool_shell_preserves_constructor_shape():
    pool = ctboost.Pool(
        data=[[0.0, 1.0], [1.0, 0.0]],
        label=[0, 1],
        cat_features=[1],
        feature_names=["a", "b"],
    )
    assert pool.num_rows == 2
    assert pool.num_cols == 2
    assert pool.cat_features == [1]
    assert pool.feature_names == ["a", "b"]
    np.testing.assert_array_equal(pool.label, np.array([0.0, 1.0], dtype=np.float32))


def test_estimators_expose_sklearn_params():
    clf = ctboost.CTBoostClassifier(
        iterations=32,
        learning_rate=0.05,
        task_type="GPU",
        verbose=True,
        colsample_bytree=0.5,
        max_leaves=8,
        min_data_in_leaf=3,
        min_child_weight=0.2,
        gamma=0.1,
        random_seed=13,
    )
    reg = ctboost.CTBoostRegressor(iterations=12)

    clf_params = clf.get_params()
    reg_params = reg.get_params()

    assert clf_params["iterations"] == 32
    assert clf_params["learning_rate"] == 0.05
    assert clf_params["task_type"] == "GPU"
    assert clf_params["verbose"] is True
    assert clf_params["colsample_bytree"] == 0.5
    assert clf_params["max_leaves"] == 8
    assert clf_params["min_data_in_leaf"] == 3
    assert clf_params["min_child_weight"] == 0.2
    assert clf_params["gamma"] == 0.1
    assert clf_params["random_seed"] == 13
    assert clf_params["loss_function"] == "Logloss"
    assert reg_params["iterations"] == 12
    assert reg_params["loss_function"] == "RMSE"


def test_native_booster_exports_verbose_flag():
    handle = ctboost._core.GradientBooster(verbose=True)
    state = handle.export_state()
    assert state["verbose"] is True


def test_native_booster_exports_tree_control_state():
    handle = ctboost._core.GradientBooster(
        colsample_bytree=0.6,
        max_leaves=7,
        min_data_in_leaf=4,
        min_child_weight=0.5,
        gamma=0.2,
        random_seed=17,
    )
    state = handle.export_state()

    assert state["colsample_bytree"] == 0.6
    assert state["max_leaves"] == 7
    assert state["min_data_in_leaf"] == 4
    assert state["min_child_weight"] == 0.5
    assert state["gamma"] == 0.2
    assert state["random_seed"] == 17


def test_debug_build_histogram_reports_matrix_shape():
    pool = ctboost.Pool(
        data=[[0.0, 1.0], [1.0, 0.0], [0.5, np.nan]],
        label=[0, 1, 0],
    )
    summary = ctboost._core._debug_build_histogram(pool._handle, max_bins=16, nan_mode="Min")

    assert summary["num_rows"] == 3
    assert summary["num_cols"] == 2
    assert len(summary["num_bins_per_feature"]) == 2
    assert len(summary["cut_offsets"]) == 3
    assert summary["elapsed_ms"] >= 0.0


def test_exact_quantile_builder_matches_sorted_cut_positions(monkeypatch):
    monkeypatch.setenv("CTBOOST_HIST_APPROX_THRESHOLD_ROWS", "0")

    values = np.array([7.0, 1.0, 3.0, 9.0, 5.0, 2.0, 8.0, 4.0, 6.0], dtype=np.float32)
    pool = ctboost.Pool(values.reshape(-1, 1), np.zeros(values.shape[0], dtype=np.float32))
    summary = ctboost._core._debug_build_histogram(pool._handle, max_bins=4, nan_mode="Min")

    expected = np.sort(values)[[2, 4, 6]].astype(np.float32)
    np.testing.assert_allclose(np.asarray(summary["cut_values"], dtype=np.float32), expected)


def test_selection_quantile_builder_matches_sorted_cut_positions(monkeypatch):
    monkeypatch.setenv("CTBOOST_HIST_APPROX_THRESHOLD_ROWS", "0")
    monkeypatch.setenv("CTBOOST_HIST_EXACT_SELECT_THRESHOLD_ROWS", "1")

    values = np.linspace(1.0, 4096.0, 4096, dtype=np.float32)
    rng = np.random.default_rng(7)
    rng.shuffle(values)
    pool = ctboost.Pool(values.reshape(-1, 1), np.zeros(values.shape[0], dtype=np.float32))
    summary = ctboost._core._debug_build_histogram(pool._handle, max_bins=8, nan_mode="Min")

    expected = np.sort(values)[[512, 1024, 1536, 2048, 2560, 3072, 3584]].astype(np.float32)
    np.testing.assert_allclose(np.asarray(summary["cut_values"], dtype=np.float32), expected)


def test_large_histogram_build_paths_are_deterministic(monkeypatch):
    rng = np.random.default_rng(42)
    X = rng.normal(size=(4096, 4)).astype(np.float32)
    y = (0.7 * X[:, 0] - 0.3 * X[:, 1] + 0.1 * X[:, 2]).astype(np.float32)

    monkeypatch.setenv("CTBOOST_HIST_THREADS", "2")
    monkeypatch.setenv("CTBOOST_HIST_APPROX_THRESHOLD_ROWS", "256")
    monkeypatch.setenv("CTBOOST_HIST_APPROX_SAMPLE_SIZE", "128")

    model_a = ctboost.CTBoostRegressor(iterations=6, max_depth=3)
    model_b = ctboost.CTBoostRegressor(iterations=6, max_depth=3)
    model_a.fit(X, y)
    model_b.fit(X, y)

    preds_a = model_a.predict(X[:128])
    preds_b = model_b.predict(X[:128])
    assert preds_a.shape == (128,)
    np.testing.assert_allclose(preds_a, preds_b, rtol=1e-6, atol=1e-6)
