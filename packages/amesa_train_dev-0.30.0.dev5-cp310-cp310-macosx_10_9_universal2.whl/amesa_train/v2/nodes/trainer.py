# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

"""
Trainer node entry point. Runs EpisodeManager and optional local orchestration.

Usage: python -m amesa_train.v2.nodes.trainer

Environment variables:
- REDIS_URL: Redis connection URL (default: redis://localhost:6379)
- AGENT_JSON: Serialized full agent JSON (preferred for cluster deployments)
- AGENT_PATH: Path to agent JSON file (local orchestration fallback)
- TRAIN_CYCLES: Number of training cycles (default: 100)
- AMESA_SKILL_TO_TRAIN: Optional explicit skill name for V2 config
- AMESA_CLUSTER_CONTAINER_MODE: If "1" or "true", distributed container mode (locality flags)
- ENVIRONMENT_NAME, NAMESPACE: Training environment discovery (cluster mode)
- AMESA_CONNECTION_URLS_JSON: JSON object of service endpoints (e.g. {"sim": "host:port"})
- AMESA_SIM_OBSERVATIONS_TOPIC: Sim observations topic (default: amesa.sim.observations)
- AMESA_SKILL_ACTIONS_TOPIC: Skill actions topic (default: amesa.skill.actions)
- AMESA_SIM_INPUT_TOPIC: Sim command topic (default: amesa.sim.input)
- AMESA_EPISODE_TOPIC: Episode output topic (default: amesa.episodes)
- AMESA_PAUSE_TOPIC, AMESA_RESUME_TOPIC: Pause/resume topics
- AMESA_CONSUMER_GROUP: Consumer group (default: amesa-training-group)
- AMESA_BATCH_SIZE, AMESA_MAX_EPISODES_IN_MEMORY, AMESA_EPISODE_TIMEOUT
- AMESA_PPO_TRAINING_SAMPLES, AMESA_ENABLE_PPO_TRAINING
- AMESA_ENABLE_AUTO_SCALE: If "1" or "true", auto-scale between cycles based on steps/second
- STANDALONE_EPISODE_MANAGER: If "1" or "true", run only EpisodeManager (no run_v2)
- AMESA_SIM_ENV_INIT_JSON: Optional JSON object forwarded as TrainerTargetV2Config.sim_env_init
"""

import asyncio
import json
import os
from typing import Any, Dict, Optional


def _to_bool(value: object) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def _resolve_input_topic() -> str:
    return os.environ.get("AMESA_SKILL_ACTIONS_TOPIC", "amesa.skill.actions")


def _resolve_output_topic() -> str:
    return os.environ.get("AMESA_SIM_INPUT_TOPIC", "amesa.sim.input")


def _parse_connection_urls() -> Dict[str, Any]:
    raw = os.environ.get("AMESA_CONNECTION_URLS_JSON", "").strip()
    if not raw:
        return {}
    parsed = json.loads(raw)
    if not isinstance(parsed, dict):
        raise ValueError("AMESA_CONNECTION_URLS_JSON must be a JSON object")
    return parsed


def _parse_sim_env_init_json() -> Optional[Dict[str, Any]]:
    raw = os.environ.get("AMESA_SIM_ENV_INIT_JSON", "").strip()
    if not raw:
        return None
    parsed = json.loads(raw)
    if not isinstance(parsed, dict):
        raise ValueError("AMESA_SIM_ENV_INIT_JSON must be a JSON object")
    return parsed


def _load_agent_from_env():
    """Load agent from AGENT_JSON or AGENT_PATH."""
    from amesa_core.agent.agent import Agent

    agent_json = os.environ.get("AGENT_JSON", "").strip()
    if agent_json:
        parsed = json.loads(agent_json)
        if not isinstance(parsed, dict):
            raise ValueError("AGENT_JSON must be a JSON object")
        return Agent.from_json(parsed)

    agent_path = os.environ.get("AGENT_PATH", "").strip()
    if agent_path and os.path.exists(agent_path):
        return Agent.load(agent_path)

    raise ValueError("AGENT_JSON or AGENT_PATH must be set to load the agent for full orchestration")


def main() -> None:
    """Run the trainer node."""
    standalone = os.environ.get("STANDALONE_EPISODE_MANAGER", "").lower() in ("1", "true")
    if standalone:
        _run_standalone_episode_manager()
    else:
        _run_full_orchestration()


def _run_standalone_episode_manager() -> None:
    """Run only EpisodeManager (for distributed deployment)."""

    async def _run() -> None:
        from amesa_core.settings import settings

        from amesa_train.networking.episode_manager import EpisodeManagerEventBase

        redis_url = os.environ.get("REDIS_URL", "redis://localhost:6379")
        sim_obs = os.environ.get("AMESA_SIM_OBSERVATIONS_TOPIC", "amesa.sim.observations")
        skill_actions = _resolve_input_topic()
        sim_input = _resolve_output_topic()
        episode_topic = os.environ.get("AMESA_EPISODE_TOPIC", "amesa.episodes")
        consumer_group = os.environ.get("AMESA_CONSUMER_GROUP", "amesa-training-group")
        batch_size = int(os.environ.get("AMESA_BATCH_SIZE", "4000"))
        max_episodes = int(os.environ.get("AMESA_MAX_EPISODES_IN_MEMORY", "50"))
        episode_timeout = float(os.environ.get("AMESA_EPISODE_TIMEOUT", "300.0"))
        ppo_samples = int(os.environ.get("AMESA_PPO_TRAINING_SAMPLES", "4000"))
        enable_ppo = os.environ.get("AMESA_ENABLE_PPO_TRAINING", "true").lower() in ("1", "true")

        manager = EpisodeManagerEventBase(
            episode_manager_id=f"episode-manager-{settings.RUN_ID}",
            redis_url=redis_url,
            sim_obs_topics=sim_obs,
            skill_action_topic=skill_actions,
            output_topic=episode_topic,
            sim_input_topic=sim_input,
            consumer_group=consumer_group,
            batch_size=batch_size,
            max_episodes_in_memory=max_episodes,
            episode_timeout=episode_timeout,
            ppo_training_samples=ppo_samples,
            enable_ppo_training=enable_ppo,
        )
        await manager.init()
        await manager.connect()
        await manager.start()

    asyncio.run(_run())


def _run_full_orchestration() -> None:
    """Run full run_v2 with agent (local orchestration)."""
    from amesa_core.config.trainer_target_v2 import TrainerTargetV2Config

    from amesa_train.v2.run import run_v2

    agent = _load_agent_from_env()
    redis_url = os.environ.get("REDIS_URL", "redis://localhost:6379")
    train_cycles = int(os.environ.get("TRAIN_CYCLES", "100"))

    cluster_container_mode = _to_bool(os.environ.get("AMESA_CLUSTER_CONTAINER_MODE", ""))
    connection_urls = _parse_connection_urls()
    skill_to_train = (os.environ.get("AMESA_SKILL_TO_TRAIN") or "").strip() or None
    env_name = os.environ.get("ENVIRONMENT_NAME")
    env_namespace = os.environ.get("NAMESPACE")

    sim_address = os.environ.get("SIM_ADDRESS")
    enable_sim_group = bool(sim_address) and not cluster_container_mode

    config = TrainerTargetV2Config(
        redis_url=redis_url,
        sim_observation_topic=os.environ.get("AMESA_SIM_OBSERVATIONS_TOPIC", "amesa.sim.observations"),
        skill_action_topic=_resolve_input_topic(),
        sim_input_topic=_resolve_output_topic(),
        perceptor_input_topic=os.environ.get("AMESA_PERCEPTOR_INPUT_TOPIC", "amesa.perceptor.input"),
        perceptor_output_topic=os.environ.get("AMESA_PERCEPTOR_OUTPUT_TOPIC", "amesa.perceptor.output"),
        episode_topic=os.environ.get("AMESA_EPISODE_TOPIC", "amesa.episodes"),
        pause_topic=os.environ.get("AMESA_PAUSE_TOPIC", "amesa.pause"),
        resume_topic=os.environ.get("AMESA_RESUME_TOPIC", "amesa.resume"),
        consumer_group=os.environ.get("AMESA_CONSUMER_GROUP", "amesa-training-group"),
        sim_address=sim_address,
        enable_sim_group=enable_sim_group,
        enable_perceptors=bool(agent.perceptors),
        enable_auto_scale=os.environ.get("AMESA_ENABLE_AUTO_SCALE", "").lower() in ("1", "true"),
        auto_scale_target_steps_per_second=float(os.environ.get("AMESA_AUTO_SCALE_TARGET_SPS", "100.0")),
        auto_scale_max_replicas=int(os.environ.get("AMESA_AUTO_SCALE_MAX_REPLICAS", "8")),
        cluster_container_mode=cluster_container_mode,
        environment_name=env_name,
        environment_namespace=env_namespace,
        connection_urls=connection_urls or None,
        skill_to_train=skill_to_train,
        sim_env_init=_parse_sim_env_init_json(),
        sim_node_local=not cluster_container_mode,
        perceptor_node_local=not cluster_container_mode,
        skill_node_local=False if cluster_container_mode else None,
        episode_manager_local=True,
    )

    run_v2(agent, redis_url=redis_url, config=config, train_cycles=train_cycles)


if __name__ == "__main__":
    main()
