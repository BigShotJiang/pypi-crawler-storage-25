# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

"""
V2 node entry points for standalone Docker deployment.

Each node can be run as: python -m amesa_train.v2.nodes.<node>

Environment variables (Docker compatibility):
- REDIS_URL: Redis connection URL
- SIM_ADDRESS: gRPC address for sim (sim node)
- AMESA_SIM_INPUT_TOPIC, AMESA_SIM_OBSERVATIONS_TOPIC: Topic overrides
- AMESA_PERCEPTOR_INPUT_TOPIC, AMESA_PERCEPTOR_OUTPUT_TOPIC: Topic overrides
- AMESA_SKILL_INPUT_TOPIC, AMESA_SKILL_ACTIONS_TOPIC: Topic overrides
- AGENT_PATH or SKILL_CONTEXT_JSON: Agent/skill context (skill node)
- PERCEPTOR_CONFIG_PATH: Perceptor config (perceptor node)
"""
