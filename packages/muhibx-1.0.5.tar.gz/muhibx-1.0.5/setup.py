from setuptools import find_packages, setup


README_TEXT = (
    "muhibx is a personal project module of MUHIB-143, designed to provide MUHIB-143's tools officially."
)


setup(
    name="muhibx",
    version="1.0.5",
    description="High-performance networking module powered by MUHIB-143",
    long_description=README_TEXT,
    long_description_content_type="text/markdown",
    author="MUHIB-143",
    license="MIT",
    python_requires=">=3.10",
    packages=find_packages(where="."),
    zip_safe=False,
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: Implementation :: CPython",
        "Operating System :: POSIX :: Linux",
        "Operating System :: Android",
        "Topic :: Internet :: WWW/HTTP",
    ],
)
