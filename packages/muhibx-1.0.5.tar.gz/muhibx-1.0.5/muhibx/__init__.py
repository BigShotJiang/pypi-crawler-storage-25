from __future__ import annotations

import importlib.util
import os
import platform
import subprocess
import sys
from pathlib import Path
from types import ModuleType


# ===== CONFIG =====
_NATIVE_MODULE_NAME = "comx"
_PACKAGE_DIR = Path(__file__).resolve().parent
_CACHE_DIR = Path.home() / ".cache" / "muhibx"

# 🔥 Your GitHub RAW base URL
_BASE_URL = "https://raw.githubusercontent.com/MUHIB-143/comx/main/binaries"


# ===== ARCH MAP =====
_ARCH_MAP = {
    ("linux", "x86_64"): "comx-linux-x86_64.so",
    ("linux", "aarch64"): "comx-linux-aarch64.so",
    ("linux", "armv8l"): "comx-linux-armv8l.so",
    ("android", "aarch64"): "comx-android-aarch64.so",
}


# ===== HELPERS =====
def _normalize_machine(machine: str) -> str:
    return {
        "amd64": "x86_64",
        "arm64": "aarch64",
        "armv7l": "armv8l",
    }.get(machine.lower(), machine.lower())


def _detect_os() -> str:
    return "android" if sys.platform == "android" else "linux"


def _get_so_name(os_name: str, arch: str) -> str:
    try:
        return _ARCH_MAP[(os_name, arch)]
    except KeyError:
        raise ImportError(f"Unsupported platform: {os_name}/{arch}")


def _curl_download(url: str, out_path: Path):
    cmd = [
        "curl",
        "-L",  # follow redirects
        "--fail",
        "--silent",
        "--show-error",
        "-o",
        str(out_path),
        url,
    ]

    subprocess.run(cmd, check=True)


# ===== DOWNLOAD =====
def _download_binary(os_name: str, arch: str) -> Path:
    so_name = _get_so_name(os_name, arch)

    cache_dir = _CACHE_DIR / os_name
    cache_dir.mkdir(parents=True, exist_ok=True)

    target = cache_dir / so_name

    # already downloaded
    if target.exists() and target.stat().st_size > 0:
        return target

    url = f"{_BASE_URL}/{so_name}"
    tmp = target.with_suffix(".tmp")

    if tmp.exists():
        tmp.unlink()

    try:
        _curl_download(url, tmp)
    except Exception as e:
        raise ImportError(f"Download failed: {url}\n{e}")

    if not tmp.exists() or tmp.stat().st_size == 0:
        raise ImportError(f"Downloaded file is empty: {url}")

    os.replace(tmp, target)
    return target


# ===== LOAD NATIVE =====
def _load_native() -> ModuleType:
    os_name = _detect_os()
    arch = _normalize_machine(platform.machine())

    so_name = _get_so_name(os_name, arch)

    # check local package first
    local_path = _PACKAGE_DIR / so_name

    if not local_path.exists():
        local_path = _download_binary(os_name, arch)

    spec = importlib.util.spec_from_file_location(_NATIVE_MODULE_NAME, local_path)
    if not spec or not spec.loader:
        raise ImportError(f"Cannot load module from {local_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[_NATIVE_MODULE_NAME] = module
    spec.loader.exec_module(module)

    return module


# ===== EXPORT =====
_NATIVE = _load_native()

__version__ = getattr(_NATIVE, "__version__", "1.0.0")
__developer__ = getattr(_NATIVE, "__developer__", "MUHIB-143")

__all__ = [name for name in dir(_NATIVE) if not name.startswith("_")]


def __getattr__(name: str):
    return getattr(_NATIVE, name)


def __dir__():
    return sorted(set(globals()) | set(dir(_NATIVE)))
