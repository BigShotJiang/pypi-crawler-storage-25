# astrahttp

**astrahttp** — async HTTP client for Python with clean API, automatic error handling, Pydantic validation, and middleware support.

---

## :flag_gb: English documentation

Tutorial, reference, and middleware guide in English.

[Go to English docs](en/index.md){ .md-button .md-button--primary }

---

## :flag_ru: Документация на русском

Туториал, справочник и руководство по middleware на русском языке.

[Перейти к русской документации](ru/index.md){ .md-button .md-button--primary }

---

```python
import asyncio
import astra

async def main():
    async with astra.ClientSession() as session:
        async with session.get("httpbin.org/get") as resp:
            print(resp.status)   # 200
            print(resp.json())

asyncio.run(main())
```

**Install:**

```bash
pip install astra-client
```
