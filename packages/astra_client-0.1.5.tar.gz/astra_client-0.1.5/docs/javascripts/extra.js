/* ═══════════════════════════════════════════════════════════
   ASTRAHTTP DOCS — extra.js
═══════════════════════════════════════════════════════════ */

/* ── Scroll progress bar ─────────────────────────────────── */
function initProgress() {
  if (document.getElementById('astra-progress')) return;
  const bar = document.createElement('div');
  bar.id = 'astra-progress';
  document.body.appendChild(bar);

  function update() {
    const scrolled = window.scrollY;
    const total = document.documentElement.scrollHeight - window.innerHeight;
    bar.style.width = total > 0 ? `${(scrolled / total) * 100}%` : '0%';
  }

  window.addEventListener('scroll', update, { passive: true });
  update();
}

/* ── Particle canvas ─────────────────────────────────────── */
let particleRAF = null;

function initParticles() {
  let canvas = document.getElementById('astra-canvas');
  if (!canvas) {
    canvas = document.createElement('canvas');
    canvas.id = 'astra-canvas';
    document.body.prepend(canvas);
  }

  const ctx = canvas.getContext('2d');
  const isDark = () => document.body.getAttribute('data-md-color-scheme') === 'slate';

  const PARTICLE_COUNT = 55;
  let W, H, particles;

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }

  function mkParticle() {
    return {
      x: Math.random() * W,
      y: Math.random() * H,
      r: Math.random() * 1.6 + 0.4,
      vx: (Math.random() - 0.5) * 0.25,
      vy: (Math.random() - 0.5) * 0.25,
      alpha: Math.random() * 0.5 + 0.15,
    };
  }

  function init() {
    resize();
    particles = Array.from({ length: PARTICLE_COUNT }, mkParticle);
  }

  function drawConnections() {
    const maxDist = 130;
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const d  = Math.sqrt(dx * dx + dy * dy);
        if (d < maxDist) {
          const alpha = (1 - d / maxDist) * 0.18;
          ctx.beginPath();
          ctx.strokeStyle = isDark()
            ? `rgba(255,87,34,${alpha})`
            : `rgba(255,87,34,${alpha * 0.5})`;
          ctx.lineWidth = 0.8;
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.stroke();
        }
      }
    }
  }

  function tick() {
    ctx.clearRect(0, 0, W, H);

    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0) p.x = W;
      if (p.x > W) p.x = 0;
      if (p.y < 0) p.y = H;
      if (p.y > H) p.y = 0;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = isDark()
        ? `rgba(255,87,34,${p.alpha})`
        : `rgba(200,60,20,${p.alpha * 0.6})`;
      ctx.fill();
    });

    drawConnections();
    particleRAF = requestAnimationFrame(tick);
  }

  if (particleRAF) cancelAnimationFrame(particleRAF);
  init();
  tick();

  window.removeEventListener('resize', resize);
  window.addEventListener('resize', resize, { passive: true });
}

/* ── Code lang labels ────────────────────────────────────── */
function addCodeLabels() {
  document.querySelectorAll('.highlight').forEach(block => {
    if (block.querySelector('.astra-lang-label')) return;
    const cls = [...block.classList].find(c => c.startsWith('language-'));
    if (!cls) return;
    const lang = cls.replace('language-', '').toUpperCase();
    if (!lang || lang === 'TEXT' || lang === 'PLAIN') return;
    const label = document.createElement('span');
    label.className = 'astra-lang-label';
    label.textContent = lang;
    block.style.position = 'relative';
    block.appendChild(label);
  });
}

/* ── Table row hover ─────────────────────────────────────── */
function enhanceTables() {
  document.querySelectorAll('.md-typeset table:not([class]) tr').forEach(row => {
    if (row._astraEnhanced) return;
    row._astraEnhanced = true;
    row.addEventListener('mouseenter', () => {
      row.style.transition = 'background 0.15s ease';
      row.style.background = 'rgba(255,87,34,0.05)';
    });
    row.addEventListener('mouseleave', () => {
      row.style.background = '';
    });
  });
}

/* ── External links ──────────────────────────────────────── */
function externalLinks() {
  document.querySelectorAll('a[href^="http"]').forEach(link => {
    if (link.hostname !== location.hostname) {
      link.setAttribute('target', '_blank');
      link.setAttribute('rel', 'noopener noreferrer');
    }
  });
}

/* ── Smooth active section highlight in TOC ──────────────── */
let tocObserver = null;
function initTOC() {
  if (tocObserver) tocObserver.disconnect();

  const headings = document.querySelectorAll('.md-content h2[id], .md-content h3[id]');
  const navLinks  = document.querySelectorAll('.md-nav--secondary a.md-nav__link');
  if (!headings.length || !navLinks.length) return;

  tocObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const id = entry.target.id;
      navLinks.forEach(link => {
        const active = link.getAttribute('href') === `#${id}`;
        link.classList.toggle('md-nav__link--active', active);
      });
    });
  }, { rootMargin: '-10% 0px -80% 0px', threshold: 0 });

  headings.forEach(h => tocObserver.observe(h));
}

/* ── Keyboard shortcut: / to focus search ────────────────── */
function initKeyboard() {
  document.addEventListener('keydown', e => {
    if (e.key === '/' && !['INPUT','TEXTAREA'].includes(document.activeElement.tagName)) {
      e.preventDefault();
      document.querySelector('.md-search__input')?.focus();
    }
    if (e.key === 'Escape') {
      document.querySelector('.md-search__input')?.blur();
    }
  });
}

/* ── Copy button feedback ────────────────────────────────── */
function initCopyFeedback() {
  document.querySelectorAll('.md-clipboard').forEach(btn => {
    if (btn._astraCopy) return;
    btn._astraCopy = true;
    btn.addEventListener('click', () => {
      const orig = btn.innerHTML;
      btn.style.color = '#00e676';
      btn.title = 'Copied!';
      setTimeout(() => {
        btn.style.color = '';
        btn.title = 'Copy';
      }, 1500);
    });
  });
}

/* ── Main init ───────────────────────────────────────────── */
function init() {
  initProgress();
  initParticles();
  addCodeLabels();
  enhanceTables();
  externalLinks();
  initTOC();
  initKeyboard();
  initCopyFeedback();
}

/* ── MkDocs instant navigation re-run ───────────────────── */
function onNavigate() {
  addCodeLabels();
  enhanceTables();
  externalLinks();
  initTOC();
  initCopyFeedback();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

document.addEventListener('DOMContentSwitch', onNavigate);
