# Примеры Middleware

## Auth middleware

Добавляет Bearer-токен в каждый запрос:

```python
from astra.middleware import BaseMiddleware

class BearerAuthMiddleware(BaseMiddleware):
    __return_type__ = bool
    __priority__ = 0
    __methods__ = None
    __enabled__ = True

    def __init__(self, token: str) -> None:
        self.token = token

    async def request(self, method, url, kwargs):
        kwargs["headers"] = kwargs.get("headers") or {}
        kwargs["headers"]["Authorization"] = f"Bearer {self.token}"
        return kwargs

async with astra.ClientSession(
    middleware=[BearerAuthMiddleware("my-secret-token")],
) as session:
    async with session.get("httpbin.org/headers") as resp:
        print(resp.json())
```

## Logging middleware

Выводит каждый запрос и ответ:

```python
class LoggingMiddleware(BaseMiddleware):
    __return_type__ = None
    __priority__ = 99
    __methods__ = None
    __enabled__ = True

    async def request(self, method, url, kwargs):
        print(f"→ {method} {url}")
        return kwargs

    async def response(self, response):
        print(f"← {response.status}")
        return response
```

!!! tip
    Высокий `__priority__` — logging запускается **последним на входе** (видит финальные kwargs)
    и **первым на выходе** (видит сырой ответ).

## Timing middleware

Измеряет продолжительность запроса:

```python
import time
from astra.middleware import BaseMiddleware

class TimingMiddleware(BaseMiddleware):
    __return_type__ = float
    __priority__ = 0
    __methods__ = None
    __enabled__ = True

    async def request(self, method, url, kwargs):
        kwargs["headers"] = kwargs.get("headers") or {}
        kwargs["headers"]["X-Request-Start"] = str(time.monotonic())
        return kwargs

    async def response(self, response):
        start = float(response.headers.get("x-request-start", 0))
        elapsed = time.monotonic() - start
        print(f"Запрос занял {elapsed:.3f}s")
        return response
```

## Фильтр по методам

Запускает middleware только для определённых HTTP-методов:

```python
class WriteOpMiddleware(BaseMiddleware):
    __return_type__ = bool
    __priority__ = 1
    __methods__ = ["POST", "PUT", "PATCH", "DELETE"]
    __enabled__ = True

    async def request(self, method, url, kwargs):
        kwargs["headers"] = kwargs.get("headers") or {}
        kwargs["headers"]["X-Write-Op"] = "true"
        return kwargs
```

Для `GET`, `HEAD` и `OPTIONS` этот middleware молча пропускается.

## Toggle без удаления

Отключайте middleware в рантайме без редактирования сессии:

```python
debug = LoggingMiddleware()

async with astra.ClientSession(middleware=[debug]) as session:
    async with session.get("httpbin.org/get") as resp:   # логируется
        pass

    debug.__enabled__ = False

    async with session.get("httpbin.org/get") as resp:   # не логируется
        pass
```

## Цепочка через pipe

Объединяйте несколько middleware в одну строку:

```python
chain = (
    BearerAuthMiddleware("token")
    | TimingMiddleware()
    | LoggingMiddleware()
)

async with astra.ClientSession(middleware=chain) as session:
    ...
```

Порядок выполнения на запросе: `BearerAuth → Timing → Logging → [HTTP]`
Порядок выполнения на ответе: `[HTTP] → Logging → Timing → BearerAuth`
