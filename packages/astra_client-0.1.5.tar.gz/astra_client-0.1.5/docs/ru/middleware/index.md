# Middleware

Middleware позволяет перехватывать и модифицировать **каждый запрос и ответ** через `ClientSession` — без изменения кода запросов.

## Что может делать middleware

- Автоматически добавлять заголовки авторизации
- Логировать все запросы и ответы
- Добавлять заголовки таймингов и трейсинга
- Повторять запрос при определённых кодах ответа
- Трансформировать данные ответа

## Как работает

```
запрос →  mw1.request → mw2.request → mw3.request → [HTTP]
ответ  ←  mw1.response ← mw2.response ← mw3.response ← [HTTP]
```

Middleware выполняется в порядке `__priority__` на входе и в **обратном порядке** на выходе.

## Быстрый пример

```python
import asyncio
import astra
from astra.middleware import BaseMiddleware

class LoggingMiddleware(BaseMiddleware):
    __return_type__ = None
    __priority__ = 0
    __methods__ = None
    __enabled__ = True

    async def request(self, method, url, kwargs):
        print(f"→ {method} {url}")
        return kwargs

    async def response(self, response):
        print(f"← {response.status}")
        return response

async def main():
    async with astra.ClientSession(
        middleware=[LoggingMiddleware()],
    ) as session:
        async with session.get("httpbin.org/get") as resp:
            print(resp.json())

asyncio.run(main())
```

Вывод:

```
→ GET https://httpbin.org/get
← 200
```

## Далее

- [Создание Middleware](creating.md) — API BaseMiddleware, атрибуты класса, pipe-чейнинг
- [Примеры](examples.md) — auth, логирование, тайминги, фильтр по методам, toggle
