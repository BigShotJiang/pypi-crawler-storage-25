# Справочник по Middleware

```python
from astra.middleware import BaseMiddleware, MiddlewareChain
```

## BaseMiddleware

Базовый класс для всех middleware.

### Атрибуты класса

| Атрибут | Тип | Описание |
|---------|-----|---------|
| `__return_type__` | `type \| None` | Тип, с которым работает middleware |
| `__priority__` | `int` | Порядок выполнения — меньше = раньше |
| `__methods__` | `list[str] \| None` | HTTP-методы для перехвата; `None` = все |
| `__enabled__` | `bool` | `False` — пропускать без удаления |

### Методы

#### `request(method, url, kwargs)`

```python
async def request(
    self,
    method: str,
    url: str,
    kwargs: dict[str, Any],
) -> dict[str, Any]
```

Вызывается до HTTP-запроса. Должен вернуть `kwargs`.

#### `response(response)`

```python
async def response(self, response: Response) -> Response
```

Вызывается после HTTP-ответа. Должен вернуть `Response`.

### Dunder-методы

#### `__repr__`

```python
repr(mw)   # <MyMiddleware return_type=<class 'bool'>>
```

#### `__or__`

```python
mw1 | mw2   # → MiddlewareChain([mw1, mw2])
```

#### `__init_subclass__`

Срабатывает при наследовании от `BaseMiddleware`. Переопределите для кастомной валидации.

---

## MiddlewareChain

Упорядоченный список экземпляров `BaseMiddleware`.

### Конструктор

```python
MiddlewareChain(middlewares: list[BaseMiddleware])
```

### Методы / операторы

| Метод | Описание |
|-------|---------|
| `chain \| mw` | Добавить middleware, вернуть новую цепочку |
| `len(chain)` | Количество middleware в цепочке |
| `iter(chain)` | Итерация по middleware |
| `repr(chain)` | `<MiddlewareChain [Mw1, Mw2]>` |

### Пример

```python
from astra.middleware import BaseMiddleware, MiddlewareChain

chain = AuthMiddleware() | LoggingMiddleware() | TimingMiddleware()

async with astra.ClientSession(middleware=chain) as session:
    ...
```
