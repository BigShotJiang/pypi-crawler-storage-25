# Response

```python
from astra.response import Response
```

Возвращается каждым контекстным менеджером запроса при входе в `__aenter__`.

## Атрибуты

| Атрибут | Тип | Описание |
|---------|-----|---------|
| `status` | `int` | HTTP-код статуса |
| `headers` | `httpx.Headers` | Заголовки ответа (без учёта регистра) |

## Методы

### `json()`

```python
resp.json() -> dict | BaseModel
```

Парсит тело ответа как JSON. Если задан `response_model` (на уровне сессии или запроса) —
возвращает валидированный экземпляр Pydantic-модели. Иначе возвращает `dict`.

---

### `text()`

```python
resp.text() -> str
```

Возвращает тело ответа как декодированную строку.

---

### `read()`

```python
resp.read() -> bytes
```

Возвращает сырое тело ответа как байты.

---

### `close()` *(async)*

```python
await resp.close()
```

Закрывает ответ и освобождает соединение. Вызывается автоматически при выходе из `async with` — вручную нужен редко.

## Пример

```python
async with session.get("httpbin.org/get") as resp:
    print(resp.status)                       # 200
    print(resp.headers["content-type"])      # application/json
    data = resp.json()                       # dict
    text = resp.text()                       # str
    raw = resp.read()                        # bytes
```
