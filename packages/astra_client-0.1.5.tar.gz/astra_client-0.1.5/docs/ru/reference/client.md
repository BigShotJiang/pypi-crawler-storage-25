# ClientSession

```python
from astra import ClientSession
```

## Конструктор

```python
ClientSession(
    base_url: str | None = None,
    headers: dict[str, str] | None = None,
    timeout: float | None = None,
    response_model: type[BaseModel] | None = None,
    http2: bool = False,
    middleware: list[BaseMiddleware] | MiddlewareChain | None = None,
)
```

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|---------|
| `base_url` | `str \| None` | `None` | Добавляется перед всеми относительными URL |
| `headers` | `dict \| None` | `None` | Заголовки по умолчанию для всех запросов |
| `timeout` | `float \| None` | `None` | Таймаут по умолчанию в секундах |
| `response_model` | `type[BaseModel] \| None` | `None` | Pydantic-модель по умолчанию для `resp.json()` |
| `http2` | `bool` | `False` | Включить HTTP/2 (требует `h2`) |
| `middleware` | `list \| MiddlewareChain \| None` | `None` | Цепочка middleware |

## Контекстный менеджер

```python
async with astra.ClientSession(...) as session:
    ...
# пул соединений закрывается при выходе
```

## Методы

Все методы возвращают `_RequestContext` (async контекстный менеджер, возвращающий `Response`).

---

### `get(url, *, params, headers, timeout, response_model)`

```python
session.get(
    url: str,
    *,
    params: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
    timeout: float | None = None,
    response_model: type[BaseModel] | None = None,
) -> _RequestContext
```

---

### `post(url, *, json, data, headers, timeout, response_model)`

```python
session.post(
    url: str,
    *,
    json: Any | None = None,
    data: dict | str | bytes | None = None,
    headers: dict[str, str] | None = None,
    timeout: float | None = None,
    response_model: type[BaseModel] | None = None,
) -> _RequestContext
```

---

### `put(url, *, json, data, headers, timeout, response_model)`

Та же сигнатура, что у `post`.

---

### `patch(url, *, json, data, headers, timeout, response_model)`

Та же сигнатура, что у `post`.

---

### `delete(url, *, headers, timeout, response_model)`

```python
session.delete(
    url: str,
    *,
    headers: dict[str, str] | None = None,
    timeout: float | None = None,
    response_model: type[BaseModel] | None = None,
) -> _RequestContext
```

---

### `head(url, *, headers, timeout, response_model)`

Та же сигнатура, что у `delete`.

---

### `options(url, *, headers, timeout, response_model)`

Та же сигнатура, что у `delete`.

---

### `request(method, url, *, params, headers, json, data, timeout, response_model)`

Универсальный метод — все verb-методы делегируют сюда.

```python
session.request(
    method: str,
    url: str,
    *,
    params: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
    json: Any | None = None,
    data: dict | str | bytes | None = None,
    timeout: float | None = None,
    response_model: type[BaseModel] | None = None,
) -> _RequestContext
```
