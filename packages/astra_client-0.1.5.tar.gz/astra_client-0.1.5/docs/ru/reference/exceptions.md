# Исключения

```python
import astra
```

Все исключения наследуются от `astra.AstraHttpError`.

## Иерархия

```
AstraHttpError
├── MissingDependencyError
├── NetworkError
│   ├── ConnectionError
│   ├── TimeoutError
│   └── TooManyRedirectsError
├── InvalidURLError
└── HTTPStatusError
    ├── ClientError  (4xx)
    │   ├── BadRequestError          # 400
    │   ├── UnauthorizedError        # 401
    │   ├── ForbiddenError           # 403
    │   ├── NotFoundError            # 404
    │   ├── MethodNotAllowedError    # 405
    │   ├── UnprocessableEntityError # 422
    │   └── TooManyRequestsError     # 429
    └── ServerError  (5xx)
        ├── InternalServerError      # 500
        ├── BadGatewayError          # 502
        ├── ServiceUnavailableError  # 503
        └── GatewayTimeoutError      # 504
```

## Справочник

### `AstraHttpError`

Корневое исключение. Перехватывайте, чтобы обработать любую ошибку astrahttp.

---

### `MissingDependencyError`

Бросается при отсутствии опциональной зависимости (например, `h2`).

```python
except astra.MissingDependencyError as e:
    print(e)
```

---

### `NetworkError`

База для ошибок, возникающих до получения ответа.

| Подкласс | Когда бросается |
|----------|----------------|
| `ConnectionError` | Невозможно достучаться до сервера |
| `TimeoutError` | Запрос превысил таймаут |
| `TooManyRedirectsError` | Слишком много редиректов |

---

### `InvalidURLError`

Бросается для некорректных URL.

---

### `HTTPStatusError`

База для ответов 4xx и 5xx. Предоставляет `status_code: int`.

```python
except astra.HTTPStatusError as e:
    print(e.status_code)   # например 404
    print(str(e))          # например [404] Not Found
```

#### `ClientError` (4xx)

| Класс | Код |
|-------|-----|
| `BadRequestError` | 400 |
| `UnauthorizedError` | 401 |
| `ForbiddenError` | 403 |
| `NotFoundError` | 404 |
| `MethodNotAllowedError` | 405 |
| `UnprocessableEntityError` | 422 |
| `TooManyRequestsError` | 429 |

#### `ServerError` (5xx)

| Класс | Код |
|-------|-----|
| `InternalServerError` | 500 |
| `BadGatewayError` | 502 |
| `ServiceUnavailableError` | 503 |
| `GatewayTimeoutError` | 504 |
