# astrahttp

**astrahttp** — асинхронный HTTP-клиент для Python на основе [httpx](https://www.python-httpx.org/). Чистый API с контекстными менеджерами, автоматическая обработка ошибок, валидация через Pydantic, поддержка HTTP/2 и гибкая система middleware.

---

## Возможности

- **Async-first** — создан для `asyncio`, каждый запрос через `async with`
- **Автоматическая обработка ошибок** — HTTP 4xx/5xx и сетевые ошибки бросают типизированные исключения
- **Интеграция с Pydantic** — валидация JSON-ответов прямо в модели
- **Система middleware** — перехват и трансформация запросов/ответов через `BaseMiddleware`
- **Поддержка HTTP/2** — включается одним флагом
- **Авто-схема URL** — можно писать `"example.com"` вместо `"https://example.com"`
- **Настройки сессии** — base URL, заголовки, таймаут задаются один раз для всех запросов

---

## Установка

```bash
pip install astra-client
```

С поддержкой HTTP/2:

```bash
pip install astra-client[http2]
```

---

## Быстрый старт

```python
import asyncio
import astra

async def main():
    async with astra.ClientSession(base_url="https://httpbin.org") as session:
        async with session.get("/get") as resp:
            print(resp.status)   # 200
            data = resp.json()
            print(data["url"])

asyncio.run(main())
```

---

## Требования

- Python 3.10+
- httpx ≥ 0.28.1
- pydantic ≥ 2.0 (опционально, для валидации моделей)

---

## Исходный код

GitHub: [https://github.com/ndugram/astrahttp](https://github.com/ndugram/astrahttp)
