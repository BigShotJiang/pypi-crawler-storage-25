# HTTP/2

astrahttp поддерживает HTTP/2 через библиотеку `h2`.

## Установка

```bash
pip install astra-client[http2]
```

Или отдельно:

```bash
pip install h2
```

## Включение

Передайте `http2=True` в `ClientSession`:

```python
import asyncio
import astra

async def main():
    async with astra.ClientSession(http2=True) as session:
        async with session.get("https://http2.github.io/") as resp:
            print(resp.status)

asyncio.run(main())
```

!!! warning "Отсутствующая зависимость"
    Без установленного `h2` параметр `http2=True` бросает:

    ```
    MissingDependencyError: HTTP/2 support requires the 'h2' package.
    Install it with: pip install astra-client[http2]
    ```

## HTTP/2 с настройками сессии

Все настройки сессии работают так же с HTTP/2:

```python
async with astra.ClientSession(
    base_url="https://api.example.com",
    headers={"Authorization": "Bearer token"},
    timeout=10.0,
    http2=True,
) as session:
    async with session.get("/data") as resp:
        print(resp.json())
```

## Параллельные запросы через HTTP/2

HTTP/2 мультиплексирует несколько запросов через одно соединение — параллельные запросы особенно эффективны:

```python
import asyncio
import astra

async def fetch(session, path):
    async with session.get(path) as resp:
        return resp.status

async def main():
    async with astra.ClientSession(
        base_url="https://http2.github.io",
        http2=True,
    ) as session:
        results = await asyncio.gather(
            fetch(session, "/"),
            fetch(session, "/"),
            fetch(session, "/"),
        )
        print(results)

asyncio.run(main())
```

!!! note
    Сервер тоже должен поддерживать HTTP/2. Если сервер поддерживает только HTTP/1.1 —
    соединение автоматически откатится на него.
