# Обработка ответа

Каждый успешный запрос возвращает объект `Response` внутри блока `async with`.

## Код статуса

```python
async with session.get("httpbin.org/get") as resp:
    print(resp.status)   # 200
```

`resp.status` — это `int`, HTTP-код ответа.

## Заголовки

```python
async with session.get("httpbin.org/get") as resp:
    print(resp.headers["content-type"])
    print(resp.headers.get("x-custom-header"))
```

`resp.headers` — объект `httpx.Headers` с доступом без учёта регистра.

## JSON

```python
async with session.get("httpbin.org/get") as resp:
    data = resp.json()   # dict
    print(data["url"])
```

С Pydantic-моделью:

```python
from pydantic import BaseModel

class Origin(BaseModel):
    origin: str

async with session.get("httpbin.org/get", response_model=Origin) as resp:
    result = resp.json()   # экземпляр Origin
    print(result.origin)
```

## Текст

```python
async with session.get("httpbin.org/html") as resp:
    html = resp.text()   # str
    print(html[:200])
```

## Сырые байты

```python
async with session.get("httpbin.org/image/png") as resp:
    data = resp.read()   # bytes
    with open("image.png", "wb") as f:
        f.write(data)
```

## Жизненный цикл ответа

Ответ закрывается автоматически при выходе из блока `async with`:

```python
async with session.get("example.com") as resp:
    data = resp.json()
# соединение освобождается здесь
```

!!! warning "Не используйте resp вне блока"
    После выхода из `async with` ответ закрыт. Чтение из него завершится ошибкой.
