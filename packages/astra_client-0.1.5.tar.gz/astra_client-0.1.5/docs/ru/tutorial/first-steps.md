# Первые шаги

## Установка

```bash
pip install astra-client
```

## Первый запрос

Каждый запрос в astrahttp использует асинхронный контекстный менеджер:

```python
import asyncio
import astra

async def main():
    async with astra.ClientSession() as session:
        async with session.get("httpbin.org/get") as resp:
            print(resp.status)
            print(resp.json())

asyncio.run(main())
```

!!! tip "Схема URL"
    Можно не писать `https://` — astrahttp добавит её автоматически.
    `"httpbin.org/get"` становится `"https://httpbin.org/get"`.

## Два контекстных менеджера

astrahttp использует **два вложенных** блока `async with`:

```python
async with astra.ClientSession() as session:       # (1)
    async with session.get("example.com") as resp: # (2)
        data = resp.json()
```

1. `ClientSession` — открывает и закрывает пул HTTP-соединений.
2. `session.get(...)` — отправляет запрос и возвращает `Response`.

Запрос не отправляется, пока вы не войдёте во внутренний блок `async with`.

## Чтение ответа

```python
async with session.get("example.com/data") as resp:
    print(resp.status)          # HTTP-код ответа (int)
    print(resp.headers)         # Заголовки ответа
    text = resp.text()          # Тело как строка
    data = resp.json()          # Тело как dict
    raw  = resp.read()          # Тело как bytes
```

!!! note
    `text()`, `json()` и `read()` — обычные (не async) методы.

## Следующие шаги

- [HTTP методы](http-methods.md) — GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS
- [Конфигурация сессии](session-configuration.md) — base URL, заголовки, таймаут
- [Обработка ошибок](error-handling.md) — типизированные исключения для каждой ситуации
