# Параллельные запросы

astrahttp работает с `asyncio.gather` для конкурентных запросов.

## Базовые параллельные запросы

```python
import asyncio
import astra

async def fetch(session, url):
    async with session.get(url) as resp:
        return resp.json()

async def main():
    async with astra.ClientSession() as session:
        results = await asyncio.gather(
            fetch(session, "httpbin.org/get?id=1"),
            fetch(session, "httpbin.org/get?id=2"),
            fetch(session, "httpbin.org/get?id=3"),
        )
        for r in results:
            print(r["args"])

asyncio.run(main())
```

Все три запроса отправляются одновременно — общее время ≈ времени самого медленного.

## Динамический список URL

```python
async def main():
    urls = [f"jsonplaceholder.typicode.com/posts/{i}" for i in range(1, 11)]

    async with astra.ClientSession() as session:
        tasks = [fetch(session, url) for url in urls]
        posts = await asyncio.gather(*tasks)

    for post in posts:
        print(post["title"])
```

## С обработкой ошибок

```python
async def safe_fetch(session, url):
    try:
        async with session.get(url) as resp:
            return resp.json()
    except astra.AstraHttpError as e:
        return {"error": str(e), "url": url}

async def main():
    async with astra.ClientSession() as session:
        results = await asyncio.gather(
            safe_fetch(session, "httpbin.org/get"),
            safe_fetch(session, "httpbin.org/status/500"),
            safe_fetch(session, "httpbin.org/status/404"),
        )
        for r in results:
            print(r)
```

## С Pydantic-моделями

```python
from pydantic import BaseModel

class Post(BaseModel):
    id: int
    title: str

async def fetch_post(session, post_id):
    async with session.get(f"/posts/{post_id}", response_model=Post) as resp:
        return resp.json()

async def main():
    async with astra.ClientSession(
        base_url="https://jsonplaceholder.typicode.com",
    ) as session:
        posts = await asyncio.gather(*[fetch_post(session, i) for i in range(1, 6)])
        for post in posts:
            print(post.title)
```

!!! tip "Используйте одну сессию"
    Всегда делитесь одной `ClientSession` между конкурентными запросами — она
    управляет пулом соединений внутри. Не создавайте новую сессию на каждый запрос.
