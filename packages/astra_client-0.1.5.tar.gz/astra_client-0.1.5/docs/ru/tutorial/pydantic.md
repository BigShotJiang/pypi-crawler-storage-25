# Pydantic модели

astrahttp интегрируется с [Pydantic v2](https://docs.pydantic.dev/) для автоматической валидации и парсинга JSON-ответов.

## Базовое использование

Определите Pydantic-модель и передайте её в `response_model`:

```python
import asyncio
import astra
from pydantic import BaseModel

class Post(BaseModel):
    id: int
    userId: int
    title: str
    body: str

async def main():
    async with astra.ClientSession() as session:
        async with session.get(
            "jsonplaceholder.typicode.com/posts/1",
            response_model=Post,
        ) as resp:
            post = resp.json()   # экземпляр Post, не dict
            print(post.title)
            print(post.id)

asyncio.run(main())
```

## Модель на уровне сессии

Задайте `response_model` один раз для всех запросов:

```python
async with astra.ClientSession(
    base_url="https://jsonplaceholder.typicode.com",
    response_model=Post,
) as session:
    async with session.get("/posts/1") as resp:
        post = resp.json()   # Post
```

## Вложенные модели

```python
from pydantic import BaseModel

class Address(BaseModel):
    street: str
    city: str

class User(BaseModel):
    id: int
    name: str
    address: Address

async with session.get("/users/1", response_model=User) as resp:
    user = resp.json()
    print(user.address.city)
```

## Опциональные поля

```python
from pydantic import BaseModel
from typing import Optional

class Article(BaseModel):
    id: int
    title: str
    subtitle: Optional[str] = None   # может отсутствовать в ответе
```

## Алиасы

Маппинг JSON-ключей в Python-атрибуты:

```python
from pydantic import BaseModel, Field

class Item(BaseModel):
    item_id: int = Field(alias="itemId")
    item_name: str = Field(alias="itemName")

async with session.get("/items/1", response_model=Item) as resp:
    item = resp.json()
    print(item.item_id)   # маппинг из "itemId"
```

!!! tip "Ошибки валидации"
    Если JSON-ответ не совпадает с моделью, Pydantic бросает `pydantic.ValidationError`.
    Перехватывайте его, если API может вернуть неожиданную структуру.
