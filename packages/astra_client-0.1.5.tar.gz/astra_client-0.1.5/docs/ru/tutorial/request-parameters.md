# Параметры запроса

## Query-параметры

Передайте dict в `params` — он будет добавлен в строку запроса URL:

```python
async with session.get("httpbin.org/get", params={"page": 2, "limit": 50}) as resp:
    print(resp.json())
# → GET https://httpbin.org/get?page=2&limit=50
```

## Заголовки

Объединяются с заголовками сессии:

```python
async with session.get(
    "httpbin.org/headers",
    headers={"X-Custom": "value"},
) as resp:
    print(resp.json())
```

!!! tip
    Заголовки сессии и заголовки запроса **объединяются**. При конфликте — приоритет у заголовков запроса.

## JSON-тело

```python
async with session.post(
    "httpbin.org/post",
    json={"username": "alice", "score": 42},
) as resp:
    print(resp.json())
```

`Content-Type: application/json` устанавливается автоматически.

## Сырое тело

Передайте `dict`, `str` или `bytes` в `data`:

=== "dict (form data)"

    ```python
    async with session.post("httpbin.org/post", data={"key": "value"}) as resp:
        print(resp.status)
    ```

=== "string"

    ```python
    async with session.post("httpbin.org/post", data="raw string body") as resp:
        print(resp.status)
    ```

=== "bytes"

    ```python
    async with session.post("httpbin.org/post", data=b"\x00\x01\x02") as resp:
        print(resp.status)
    ```

## Таймаут для одного запроса

Переопределяет таймаут сессии для конкретного запроса:

```python
async with session.get("httpbin.org/delay/5", timeout=10.0) as resp:
    print(resp.status)
```

Если запрос занимает дольше `timeout` секунд — бросается `astra.TimeoutError`.

## Модель ответа для одного запроса

Переопределяет Pydantic-модель сессии для конкретного запроса:

```python
from pydantic import BaseModel

class User(BaseModel):
    id: int
    name: str

async with session.get("/user/1", response_model=User) as resp:
    user = resp.json()   # возвращает экземпляр User
    print(user.name)
```
