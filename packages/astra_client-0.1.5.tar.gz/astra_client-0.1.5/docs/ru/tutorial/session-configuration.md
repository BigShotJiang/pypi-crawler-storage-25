# Конфигурация сессии

`ClientSession` принимает настройки, которые применяются ко всем запросам в этой сессии.

## Base URL

Добавляет базовый URL перед всеми относительными путями:

```python
async with astra.ClientSession(base_url="https://api.example.com") as session:
    async with session.get("/users") as resp:      # → https://api.example.com/users
        print(resp.json())
    async with session.get("/posts/1") as resp:    # → https://api.example.com/posts/1
        print(resp.json())
```

## Заголовки по умолчанию

Отправляются с каждым запросом:

```python
async with astra.ClientSession(
    base_url="https://api.example.com",
    headers={
        "Authorization": "Bearer my-token",
        "Accept": "application/json",
    },
) as session:
    async with session.get("/profile") as resp:
        print(resp.json())
```

Заголовки запроса **объединяются** с заголовками сессии.

## Таймаут по умолчанию

Глобальный таймаут в секундах для всех запросов:

```python
async with astra.ClientSession(timeout=5.0) as session:
    async with session.get("httpbin.org/delay/3") as resp:
        print(resp.status)   # 3с < 5с — успех
```

Переопределение для конкретного запроса:

```python
async with session.get("httpbin.org/delay/10", timeout=15.0) as resp:
    print(resp.status)
```

## Модель ответа по умолчанию

Валидация всех ответов через Pydantic:

```python
from pydantic import BaseModel

class User(BaseModel):
    id: int
    name: str
    email: str

async with astra.ClientSession(
    base_url="https://api.example.com",
    response_model=User,
) as session:
    async with session.get("/user/1") as resp:
        user = resp.json()   # экземпляр User, не dict
        print(user.name)
```

## HTTP/2

Включить HTTP/2 для всей сессии:

```python
async with astra.ClientSession(http2=True) as session:
    async with session.get("https://http2.github.io/") as resp:
        print(resp.status)
```

!!! warning "Требует доп. зависимость"
    ```bash
    pip install astra-client[http2]
    ```
    Без установленного `h2` параметр `http2=True` бросает `MissingDependencyError`.

## Полный пример

```python
import asyncio
import astra
from pydantic import BaseModel

class Post(BaseModel):
    id: int
    title: str
    body: str

async def main():
    async with astra.ClientSession(
        base_url="https://jsonplaceholder.typicode.com",
        headers={"Accept": "application/json"},
        timeout=10.0,
        response_model=Post,
    ) as session:
        async with session.get("/posts/1") as resp:
            post = resp.json()
            print(post.title)

asyncio.run(main())
```
