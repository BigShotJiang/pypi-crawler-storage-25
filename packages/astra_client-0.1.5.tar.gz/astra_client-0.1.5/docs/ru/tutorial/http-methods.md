# HTTP методы

astrahttp поддерживает все стандартные HTTP-методы через удобные методы `ClientSession`.

## GET

```python
async with session.get("httpbin.org/get", params={"page": 1}) as resp:
    print(resp.json())
```

## POST

```python
async with session.post("httpbin.org/post", json={"name": "Алиса"}) as resp:
    print(resp.json())
```

POST с form data:

```python
async with session.post("httpbin.org/post", data={"field": "value"}) as resp:
    print(resp.json())
```

## PUT

```python
async with session.put("httpbin.org/put", json={"id": 1, "name": "Боб"}) as resp:
    print(resp.status)
```

## PATCH

```python
async with session.patch("httpbin.org/patch", json={"name": "Карол"}) as resp:
    print(resp.status)
```

## DELETE

```python
async with session.delete("httpbin.org/delete") as resp:
    print(resp.status)   # 200 или 204
```

## HEAD

Возвращает только заголовки, без тела:

```python
async with session.head("httpbin.org/get") as resp:
    print(resp.headers["content-type"])
```

## OPTIONS

```python
async with session.options("httpbin.org/get") as resp:
    print(resp.status)
```

## Универсальный `request()`

Все методы выше делегируют в `request()`. Можно вызывать напрямую:

```python
async with session.request("GET", "httpbin.org/get") as resp:
    print(resp.status)
```

## Общие параметры

Каждый метод принимает следующие keyword-аргументы:

| Параметр | Тип | Описание |
|----------|-----|----------|
| `params` | `dict` | Параметры строки запроса |
| `headers` | `dict` | Заголовки запроса (объединяются с заголовками сессии) |
| `json` | `Any` | JSON-тело — автоматически ставит `Content-Type: application/json` |
| `data` | `dict \| str \| bytes` | Сырое тело запроса |
| `timeout` | `float` | Таймаут в секундах для этого запроса |
| `response_model` | `type[BaseModel]` | Pydantic-модель для валидации JSON |

!!! note
    `json` и `data` доступны только в POST, PUT и PATCH.
    GET, DELETE, HEAD, OPTIONS принимают только `params`, `headers` и `timeout`.
