# Обработка ошибок

astrahttp бросает типизированные исключения для каждой ситуации — сетевые сбои и HTTP-ошибки.

## Иерархия исключений

```
AstraHttpError
├── MissingDependencyError        # опциональная зависимость не установлена
├── NetworkError                  # сбой соединения до получения ответа
│   ├── ConnectionError           # невозможно достучаться до сервера
│   ├── TimeoutError              # запрос превысил таймаут
│   └── TooManyRedirectsError     # слишком много редиректов
├── InvalidURLError               # неверный URL
└── HTTPStatusError               # получен ответ 4xx или 5xx
    ├── ClientError               # 4xx база
    │   ├── BadRequestError       # 400
    │   ├── UnauthorizedError     # 401
    │   ├── ForbiddenError        # 403
    │   ├── NotFoundError         # 404
    │   ├── MethodNotAllowedError # 405
    │   ├── UnprocessableEntityError  # 422
    │   └── TooManyRequestsError  # 429
    └── ServerError               # 5xx база
        ├── InternalServerError   # 500
        ├── BadGatewayError       # 502
        ├── ServiceUnavailableError   # 503
        └── GatewayTimeoutError   # 504
```

## Перехват конкретных ошибок

```python
import astra

async with astra.ClientSession() as session:
    try:
        async with session.get("example.com/api/resource") as resp:
            data = resp.json()
    except astra.NotFoundError:
        print("Ресурс не найден")
    except astra.UnauthorizedError:
        print("Неверные учётные данные")
    except astra.TooManyRequestsError:
        print("Rate limit — замедлите запросы")
    except astra.ServerError:
        print("Ошибка сервера — попробуйте позже")
    except astra.TimeoutError:
        print("Таймаут запроса")
    except astra.ConnectionError:
        print("Не удаётся подключиться к серверу")
    except astra.AstraHttpError as e:
        print(f"Неожиданная ошибка: {e}")
```

## Перехват по категории

```python
except astra.ClientError:   # все 4xx
    ...

except astra.ServerError:   # все 5xx
    ...

except astra.NetworkError:  # connection/timeout/redirect ошибки
    ...

except astra.AstraHttpError:  # всё
    ...
```

## Код статуса у HTTP-ошибок

Все подклассы `HTTPStatusError` предоставляют `status_code`:

```python
try:
    async with session.get("example.com/secret") as resp:
        ...
except astra.HTTPStatusError as e:
    print(e.status_code)   # 403
    print(str(e))          # [403] Forbidden
```

## Пример с повторными попытками

```python
import asyncio
import astra

async def get_with_retry(session, url, retries=3, delay=1.0):
    for attempt in range(1, retries + 1):
        try:
            async with session.get(url) as resp:
                return resp.json()
        except (astra.ServerError, astra.TimeoutError) as e:
            if attempt == retries:
                raise
            await asyncio.sleep(delay * attempt)
```

## MissingDependencyError

Бросается при отсутствии опциональной зависимости:

```python
try:
    async with astra.ClientSession(http2=True) as session:
        ...
except astra.MissingDependencyError as e:
    print(e)
    # HTTP/2 support requires the 'h2' package.
    # Install it with: pip install astra-client[http2]
```
