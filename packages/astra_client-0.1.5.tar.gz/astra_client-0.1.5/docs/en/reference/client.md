# ClientSession

```python
from astra import ClientSession
```

## Constructor

```python
ClientSession(
    base_url: str | None = None,
    headers: dict[str, str] | None = None,
    timeout: float | None = None,
    response_model: type[BaseModel] | None = None,
    http2: bool = False,
    middleware: list[BaseMiddleware] | MiddlewareChain | None = None,
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `base_url` | `str \| None` | `None` | Prepended to all relative URLs |
| `headers` | `dict \| None` | `None` | Default headers for every request |
| `timeout` | `float \| None` | `None` | Default timeout in seconds |
| `response_model` | `type[BaseModel] \| None` | `None` | Default Pydantic model for `resp.json()` |
| `http2` | `bool` | `False` | Enable HTTP/2 (requires `h2`) |
| `middleware` | `list \| MiddlewareChain \| None` | `None` | Middleware chain |

## Context manager

```python
async with astra.ClientSession(...) as session:
    ...
# connection pool closed on exit
```

## Methods

All methods return a `_RequestContext` (async context manager that yields `Response`).

---

### `get(url, *, params, headers, timeout, response_model)`

```python
session.get(
    url: str,
    *,
    params: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
    timeout: float | None = None,
    response_model: type[BaseModel] | None = None,
) -> _RequestContext
```

---

### `post(url, *, json, data, headers, timeout, response_model)`

```python
session.post(
    url: str,
    *,
    json: Any | None = None,
    data: dict | str | bytes | None = None,
    headers: dict[str, str] | None = None,
    timeout: float | None = None,
    response_model: type[BaseModel] | None = None,
) -> _RequestContext
```

---

### `put(url, *, json, data, headers, timeout, response_model)`

Same signature as `post`.

---

### `patch(url, *, json, data, headers, timeout, response_model)`

Same signature as `post`.

---

### `delete(url, *, headers, timeout, response_model)`

```python
session.delete(
    url: str,
    *,
    headers: dict[str, str] | None = None,
    timeout: float | None = None,
    response_model: type[BaseModel] | None = None,
) -> _RequestContext
```

---

### `head(url, *, headers, timeout, response_model)`

Same signature as `delete`.

---

### `options(url, *, headers, timeout, response_model)`

Same signature as `delete`.

---

### `request(method, url, *, params, headers, json, data, timeout, response_model)`

Generic method — all verb shortcuts delegate here.

```python
session.request(
    method: str,
    url: str,
    *,
    params: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
    json: Any | None = None,
    data: dict | str | bytes | None = None,
    timeout: float | None = None,
    response_model: type[BaseModel] | None = None,
) -> _RequestContext
```
