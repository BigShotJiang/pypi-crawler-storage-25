# Exceptions

```python
import astra
```

All exceptions inherit from `astra.AstraHttpError`.

## Hierarchy

```
AstraHttpError
├── MissingDependencyError
├── NetworkError
│   ├── ConnectionError
│   ├── TimeoutError
│   └── TooManyRedirectsError
├── InvalidURLError
└── HTTPStatusError
    ├── ClientError  (4xx)
    │   ├── BadRequestError          # 400
    │   ├── UnauthorizedError        # 401
    │   ├── ForbiddenError           # 403
    │   ├── NotFoundError            # 404
    │   ├── MethodNotAllowedError    # 405
    │   ├── UnprocessableEntityError # 422
    │   └── TooManyRequestsError     # 429
    └── ServerError  (5xx)
        ├── InternalServerError      # 500
        ├── BadGatewayError          # 502
        ├── ServiceUnavailableError  # 503
        └── GatewayTimeoutError      # 504
```

## Reference

### `AstraHttpError`

Root exception. Catch this to handle any astrahttp error.

---

### `MissingDependencyError`

Raised when an optional dependency (e.g. `h2`) is not installed.

```python
except astra.MissingDependencyError as e:
    print(e)
```

---

### `NetworkError`

Base for errors that occur before a response is received.

| Subclass | When raised |
|----------|-------------|
| `ConnectionError` | Cannot reach the server |
| `TimeoutError` | Request exceeded timeout |
| `TooManyRedirectsError` | Too many redirects |

---

### `InvalidURLError`

Raised for malformed URLs.

---

### `HTTPStatusError`

Base for 4xx and 5xx responses. Exposes `status_code: int`.

```python
except astra.HTTPStatusError as e:
    print(e.status_code)   # e.g. 404
    print(str(e))          # e.g. [404] Not Found
```

#### `ClientError` (4xx)

| Class | Code |
|-------|------|
| `BadRequestError` | 400 |
| `UnauthorizedError` | 401 |
| `ForbiddenError` | 403 |
| `NotFoundError` | 404 |
| `MethodNotAllowedError` | 405 |
| `UnprocessableEntityError` | 422 |
| `TooManyRequestsError` | 429 |

#### `ServerError` (5xx)

| Class | Code |
|-------|------|
| `InternalServerError` | 500 |
| `BadGatewayError` | 502 |
| `ServiceUnavailableError` | 503 |
| `GatewayTimeoutError` | 504 |
