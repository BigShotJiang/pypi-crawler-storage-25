# Middleware Reference

```python
from astra.middleware import BaseMiddleware, MiddlewareChain
```

## BaseMiddleware

Base class for all middleware.

### Class attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `__return_type__` | `type \| None` | Type this middleware operates on |
| `__priority__` | `int` | Execution order — lower runs first |
| `__methods__` | `list[str] \| None` | HTTP methods to apply to; `None` = all |
| `__enabled__` | `bool` | Set `False` to skip without removing |

### Methods

#### `request(method, url, kwargs)`

```python
async def request(
    self,
    method: str,
    url: str,
    kwargs: dict[str, Any],
) -> dict[str, Any]
```

Called before the HTTP request. Must return `kwargs` (modified or as-is).

#### `response(response)`

```python
async def response(self, response: Response) -> Response
```

Called after the HTTP response. Must return a `Response`.

### Dunder methods

#### `__repr__`

```python
repr(mw)   # <MyMiddleware return_type=<class 'bool'>>
```

#### `__or__`

```python
mw1 | mw2   # → MiddlewareChain([mw1, mw2])
```

#### `__init_subclass__`

Fires when a class inherits from `BaseMiddleware`. Override for custom subclass validation.

---

## MiddlewareChain

An ordered list of `BaseMiddleware` instances.

### Constructor

```python
MiddlewareChain(middlewares: list[BaseMiddleware])
```

### Methods / operators

| Method | Description |
|--------|-------------|
| `chain \| mw` | Append middleware, return new chain |
| `len(chain)` | Number of middleware in chain |
| `iter(chain)` | Iterate over middleware |
| `repr(chain)` | `<MiddlewareChain [Mw1, Mw2]>` |

### Example

```python
from astra.middleware import BaseMiddleware, MiddlewareChain

chain = AuthMiddleware() | LoggingMiddleware() | TimingMiddleware()
# MiddlewareChain([AuthMiddleware, LoggingMiddleware, TimingMiddleware])

async with astra.ClientSession(middleware=chain) as session:
    ...
```
