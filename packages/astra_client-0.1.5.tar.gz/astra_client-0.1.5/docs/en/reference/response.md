# Response

```python
from astra.response import Response
```

Returned by every request context manager on `__aenter__`.

## Attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `status` | `int` | HTTP status code |
| `headers` | `httpx.Headers` | Response headers (case-insensitive) |

## Methods

### `json()`

```python
resp.json() -> dict | BaseModel
```

Parse the response body as JSON. If a `response_model` was set (session-level or per-request),
returns a validated Pydantic model instance. Otherwise returns a raw `dict`.

---

### `text()`

```python
resp.text() -> str
```

Return the response body as a decoded string.

---

### `read()`

```python
resp.read() -> bytes
```

Return the raw response body as bytes.

---

### `close()` *(async)*

```python
await resp.close()
```

Close the response and release the connection. Called automatically on `async with` exit — you rarely need this manually.

## Example

```python
async with session.get("httpbin.org/get") as resp:
    print(resp.status)                       # 200
    print(resp.headers["content-type"])      # application/json
    data = resp.json()                       # dict
    text = resp.text()                       # str
    raw = resp.read()                        # bytes
```
