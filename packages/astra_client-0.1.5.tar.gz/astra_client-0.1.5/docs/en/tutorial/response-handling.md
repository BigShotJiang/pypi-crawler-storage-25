# Response Handling

Every successful request yields a `Response` object inside the `async with` block.

## Status code

```python
async with session.get("httpbin.org/get") as resp:
    print(resp.status)   # 200
```

`resp.status` is an `int` — the raw HTTP status code.

## Headers

```python
async with session.get("httpbin.org/get") as resp:
    print(resp.headers["content-type"])
    print(resp.headers.get("x-custom-header"))
```

`resp.headers` is an `httpx.Headers` object — case-insensitive dict-like access.

## JSON

```python
async with session.get("httpbin.org/get") as resp:
    data = resp.json()   # dict
    print(data["url"])
```

With a Pydantic model:

```python
from pydantic import BaseModel

class Origin(BaseModel):
    origin: str

async with session.get("httpbin.org/get", response_model=Origin) as resp:
    result = resp.json()   # Origin instance
    print(result.origin)
```

## Text

```python
async with session.get("httpbin.org/html") as resp:
    html = resp.text()   # str
    print(html[:200])
```

## Raw bytes

```python
async with session.get("httpbin.org/image/png") as resp:
    data = resp.read()   # bytes
    with open("image.png", "wb") as f:
        f.write(data)
```

## Response lifecycle

The response is automatically closed when the `async with` block exits:

```python
async with session.get("example.com") as resp:
    data = resp.json()
# connection released here
```

!!! warning "Don't use resp outside the block"
    After the `async with` block exits, the response is closed. Reading from it
    outside will fail.
