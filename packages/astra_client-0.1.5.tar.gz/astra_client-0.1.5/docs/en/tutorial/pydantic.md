# Pydantic Models

astrahttp integrates with [Pydantic v2](https://docs.pydantic.dev/) to validate and parse JSON responses automatically.

## Basic usage

Define a Pydantic model and pass it as `response_model`:

```python
import asyncio
import astra
from pydantic import BaseModel

class Post(BaseModel):
    id: int
    userId: int
    title: str
    body: str

async def main():
    async with astra.ClientSession() as session:
        async with session.get(
            "jsonplaceholder.typicode.com/posts/1",
            response_model=Post,
        ) as resp:
            post = resp.json()   # Post instance, not dict
            print(post.title)
            print(post.id)

asyncio.run(main())
```

## Session-level model

Set `response_model` once for all requests:

```python
async with astra.ClientSession(
    base_url="https://jsonplaceholder.typicode.com",
    response_model=Post,
) as session:
    async with session.get("/posts/1") as resp:
        post = resp.json()   # Post
```

## List responses

Wrap the model in a list:

```python
from pydantic import BaseModel
from typing import List

class Post(BaseModel):
    id: int
    title: str

# Use TypeAdapter for lists
from pydantic import TypeAdapter

async with session.get("/posts") as resp:
    raw = resp.json()   # list[dict] — no model applied to lists directly
    posts = TypeAdapter(List[Post]).validate_python(raw)
```

## Nested models

```python
from pydantic import BaseModel

class Address(BaseModel):
    street: str
    city: str

class User(BaseModel):
    id: int
    name: str
    address: Address

async with session.get("/users/1", response_model=User) as resp:
    user = resp.json()
    print(user.address.city)
```

## Optional fields

```python
from pydantic import BaseModel
from typing import Optional

class Article(BaseModel):
    id: int
    title: str
    subtitle: Optional[str] = None   # may be missing in response
```

## Aliases

Map JSON keys to Python attribute names:

```python
from pydantic import BaseModel, Field

class Item(BaseModel):
    item_id: int = Field(alias="itemId")
    item_name: str = Field(alias="itemName")

async with session.get("/items/1", response_model=Item) as resp:
    item = resp.json()
    print(item.item_id)   # mapped from "itemId"
```

!!! tip "Validation errors"
    If the response JSON doesn't match the model, Pydantic raises
    `pydantic.ValidationError`. Catch it if the API may return unexpected shapes.
