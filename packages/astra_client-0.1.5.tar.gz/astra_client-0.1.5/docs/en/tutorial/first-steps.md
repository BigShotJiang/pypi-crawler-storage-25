# First Steps

## Installation

```bash
pip install astra-client
```

## Your first request

Every request in astrahttp uses an async context manager. Here is the minimal example:

```python
import asyncio
import astra

async def main():
    async with astra.ClientSession() as session:
        async with session.get("httpbin.org/get") as resp:
            print(resp.status)
            print(resp.json())

asyncio.run(main())
```

!!! tip "URL scheme"
    You can omit `https://` — astrahttp adds it automatically.
    `"httpbin.org/get"` becomes `"https://httpbin.org/get"`.

## Two context managers

astrahttp uses **two nested** `async with` blocks:

```python
async with astra.ClientSession() as session:   # (1)
    async with session.get("example.com") as resp:  # (2)
        data = resp.json()
```

1. `ClientSession` — opens and closes the underlying HTTP connection pool.
2. `session.get(...)` — sends the request and gives you a `Response`.

The request is not sent until you enter the inner `async with` block.

## Reading the response

```python
async with session.get("example.com/data") as resp:
    print(resp.status)          # HTTP status code (int)
    print(resp.headers)         # Response headers
    text = resp.text()          # Body as string
    data = resp.json()          # Body parsed as dict
    raw  = resp.read()          # Body as bytes
```

!!! note
    `text()`, `json()`, and `read()` are regular (not async) methods.

## Next steps

- [HTTP Methods](http-methods.md) — GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS
- [Session Configuration](session-configuration.md) — base URL, headers, timeout
- [Error Handling](error-handling.md) — typed exceptions for every error case
