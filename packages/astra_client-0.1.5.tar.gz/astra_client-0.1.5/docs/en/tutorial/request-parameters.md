# Request Parameters

## Query parameters

Pass a dict to `params` — it is appended to the URL as a query string:

```python
async with session.get("httpbin.org/get", params={"page": 2, "limit": 50}) as resp:
    print(resp.json())
# → GET https://httpbin.org/get?page=2&limit=50
```

## Headers

Merge per-request headers with session defaults:

```python
async with session.get(
    "httpbin.org/headers",
    headers={"X-Custom": "value"},
) as resp:
    print(resp.json())
```

!!! tip
    Session-level headers and per-request headers are **merged**. Per-request values take priority on conflict.

## JSON body

```python
async with session.post(
    "httpbin.org/post",
    json={"username": "alice", "score": 42},
) as resp:
    print(resp.json())
```

Sets `Content-Type: application/json` automatically.

## Raw body

Pass a `dict`, `str`, or `bytes` to `data`:

=== "dict (form data)"

    ```python
    async with session.post("httpbin.org/post", data={"key": "value"}) as resp:
        print(resp.status)
    ```

=== "string"

    ```python
    async with session.post("httpbin.org/post", data="raw string body") as resp:
        print(resp.status)
    ```

=== "bytes"

    ```python
    async with session.post("httpbin.org/post", data=b"\x00\x01\x02") as resp:
        print(resp.status)
    ```

## Per-request timeout

Override the session default timeout for a single request:

```python
async with session.get("httpbin.org/delay/5", timeout=10.0) as resp:
    print(resp.status)
```

If the request takes longer than `timeout` seconds, `astra.TimeoutError` is raised.

## Per-request response model

Override the session-level Pydantic model for a single request:

```python
from pydantic import BaseModel

class User(BaseModel):
    id: int
    name: str

async with session.get("/user/1", response_model=User) as resp:
    user = resp.json()   # returns User instance
    print(user.name)
```
