# HTTP/2

astrahttp supports HTTP/2 via the `h2` library.

## Install

```bash
pip install astra-client[http2]
```

Or separately:

```bash
pip install h2
```

## Enable

Pass `http2=True` to `ClientSession`:

```python
import asyncio
import astra

async def main():
    async with astra.ClientSession(http2=True) as session:
        async with session.get("https://http2.github.io/") as resp:
            print(resp.status)

asyncio.run(main())
```

!!! warning "Missing dependency"
    Without `h2` installed, `http2=True` raises:

    ```
    MissingDependencyError: HTTP/2 support requires the 'h2' package.
    Install it with: pip install astra-client[http2]
    ```

## HTTP/2 with base URL and session config

All session configuration works the same with HTTP/2:

```python
async with astra.ClientSession(
    base_url="https://api.example.com",
    headers={"Authorization": "Bearer token"},
    timeout=10.0,
    http2=True,
) as session:
    async with session.get("/data") as resp:
        print(resp.json())
```

## Concurrent requests over HTTP/2

HTTP/2 multiplexes multiple requests over a single connection — parallel requests
are especially efficient:

```python
import asyncio
import astra

async def fetch(session, path):
    async with session.get(path) as resp:
        return resp.status

async def main():
    async with astra.ClientSession(
        base_url="https://http2.github.io",
        http2=True,
    ) as session:
        results = await asyncio.gather(
            fetch(session, "/"),
            fetch(session, "/"),
            fetch(session, "/"),
        )
        print(results)

asyncio.run(main())
```

!!! note
    The server must also support HTTP/2. If the server only supports HTTP/1.1,
    the connection will fall back automatically.
