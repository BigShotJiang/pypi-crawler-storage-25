# HTTP Methods

astrahttp supports all standard HTTP methods as shorthand helpers on `ClientSession`.

## GET

```python
async with session.get("httpbin.org/get", params={"page": 1}) as resp:
    print(resp.json())
```

## POST

```python
async with session.post("httpbin.org/post", json={"name": "Alice"}) as resp:
    print(resp.json())
```

POST with form data:

```python
async with session.post("httpbin.org/post", data={"field": "value"}) as resp:
    print(resp.json())
```

## PUT

```python
async with session.put("httpbin.org/put", json={"id": 1, "name": "Bob"}) as resp:
    print(resp.status)
```

## PATCH

```python
async with session.patch("httpbin.org/patch", json={"name": "Carol"}) as resp:
    print(resp.status)
```

## DELETE

```python
async with session.delete("httpbin.org/delete") as resp:
    print(resp.status)   # 200 or 204
```

## HEAD

Returns only headers, no body:

```python
async with session.head("httpbin.org/get") as resp:
    print(resp.headers["content-type"])
```

## OPTIONS

```python
async with session.options("httpbin.org/get") as resp:
    print(resp.status)
```

## Generic `request()`

All methods above delegate to `request()`. You can call it directly for non-standard verbs:

```python
async with session.request("GET", "httpbin.org/get") as resp:
    print(resp.status)
```

## Common parameters

Every method accepts these keyword arguments:

| Parameter | Type | Description |
|-----------|------|-------------|
| `params` | `dict` | Query string parameters |
| `headers` | `dict` | Per-request headers (merged with session headers) |
| `json` | `Any` | JSON body — sets `Content-Type: application/json` |
| `data` | `dict \| str \| bytes` | Raw body |
| `timeout` | `float` | Timeout override in seconds |
| `response_model` | `type[BaseModel]` | Pydantic model for JSON validation |

!!! note
    `json` and `data` are only available on POST, PUT, and PATCH.
    GET, DELETE, HEAD, OPTIONS only accept `params`, `headers`, and `timeout`.
