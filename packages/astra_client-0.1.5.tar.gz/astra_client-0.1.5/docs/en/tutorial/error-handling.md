# Error Handling

astrahttp raises typed exceptions for every error case — network failures and HTTP error responses.

## Exception hierarchy

```
AstraHttpError
├── MissingDependencyError        # optional dep not installed (e.g. h2)
├── NetworkError                  # connection failed before response
│   ├── ConnectionError           # cannot reach server
│   ├── TimeoutError              # request exceeded timeout
│   └── TooManyRedirectsError     # too many redirects
├── InvalidURLError               # malformed URL
└── HTTPStatusError               # 4xx or 5xx response received
    ├── ClientError               # 4xx base
    │   ├── BadRequestError       # 400
    │   ├── UnauthorizedError     # 401
    │   ├── ForbiddenError        # 403
    │   ├── NotFoundError         # 404
    │   ├── MethodNotAllowedError # 405
    │   ├── UnprocessableEntityError  # 422
    │   └── TooManyRequestsError  # 429
    └── ServerError               # 5xx base
        ├── InternalServerError   # 500
        ├── BadGatewayError       # 502
        ├── ServiceUnavailableError   # 503
        └── GatewayTimeoutError   # 504
```

## Catching specific errors

```python
import astra

async with astra.ClientSession() as session:
    try:
        async with session.get("example.com/api/resource") as resp:
            data = resp.json()
    except astra.NotFoundError:
        print("Resource not found")
    except astra.UnauthorizedError:
        print("Invalid credentials")
    except astra.TooManyRequestsError:
        print("Rate limited — slow down")
    except astra.ServerError:
        print("Server error — try again later")
    except astra.TimeoutError:
        print("Request timed out")
    except astra.ConnectionError:
        print("Cannot reach server")
    except astra.AstraHttpError as e:
        print(f"Unexpected error: {e}")
```

## Catching by category

```python
except astra.ClientError:   # catches all 4xx
    ...

except astra.ServerError:   # catches all 5xx
    ...

except astra.NetworkError:  # catches connection/timeout/redirect errors
    ...

except astra.AstraHttpError:  # catches everything
    ...
```

## Status code on HTTP errors

All `HTTPStatusError` subclasses expose `status_code`:

```python
try:
    async with session.get("example.com/secret") as resp:
        ...
except astra.HTTPStatusError as e:
    print(e.status_code)   # 403
    print(str(e))          # [403] Forbidden
```

## Retry example

```python
import asyncio
import astra

async def get_with_retry(session, url, retries=3, delay=1.0):
    for attempt in range(1, retries + 1):
        try:
            async with session.get(url) as resp:
                return resp.json()
        except (astra.ServerError, astra.TimeoutError) as e:
            if attempt == retries:
                raise
            await asyncio.sleep(delay * attempt)
```

## MissingDependencyError

Raised when an optional dependency is missing:

```python
try:
    async with astra.ClientSession(http2=True) as session:
        ...
except astra.MissingDependencyError as e:
    print(e)
    # HTTP/2 support requires the 'h2' package.
    # Install it with: pip install astra-client[http2]
```
