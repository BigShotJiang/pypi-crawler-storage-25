# Session Configuration

`ClientSession` accepts configuration that applies to every request made through that session.

## Base URL

Prepend a base URL to all relative paths:

```python
async with astra.ClientSession(base_url="https://api.example.com") as session:
    async with session.get("/users") as resp:      # → https://api.example.com/users
        print(resp.json())
    async with session.get("/posts/1") as resp:    # → https://api.example.com/posts/1
        print(resp.json())
```

## Default headers

Send the same headers with every request:

```python
async with astra.ClientSession(
    base_url="https://api.example.com",
    headers={
        "Authorization": "Bearer my-token",
        "Accept": "application/json",
    },
) as session:
    async with session.get("/profile") as resp:
        print(resp.json())
```

Per-request headers are **merged** on top of session headers.

## Default timeout

Set a global timeout in seconds for all requests:

```python
async with astra.ClientSession(timeout=5.0) as session:
    async with session.get("httpbin.org/delay/3") as resp:
        print(resp.status)   # completes in 3s < 5s limit
```

Override per request:

```python
async with session.get("httpbin.org/delay/10", timeout=15.0) as resp:
    print(resp.status)
```

## Default response model

Validate every response against a Pydantic model by default:

```python
from pydantic import BaseModel

class User(BaseModel):
    id: int
    name: str
    email: str

async with astra.ClientSession(
    base_url="https://api.example.com",
    response_model=User,
) as session:
    async with session.get("/user/1") as resp:
        user = resp.json()   # User instance, not dict
        print(user.name)
```

Override per request with a different model or `None`.

## HTTP/2

Enable HTTP/2 for all requests in the session:

```python
async with astra.ClientSession(http2=True) as session:
    async with session.get("https://http2.github.io/") as resp:
        print(resp.status)
```

!!! warning "Requires extra dependency"
    ```bash
    pip install astra-client[http2]
    ```
    Without `h2` installed, passing `http2=True` raises `MissingDependencyError`.

## Full example

```python
import asyncio
import astra
from pydantic import BaseModel

class Post(BaseModel):
    id: int
    title: str
    body: str

async def main():
    async with astra.ClientSession(
        base_url="https://jsonplaceholder.typicode.com",
        headers={"Accept": "application/json"},
        timeout=10.0,
        response_model=Post,
    ) as session:
        async with session.get("/posts/1") as resp:
            post = resp.json()
            print(post.title)

asyncio.run(main())
```
