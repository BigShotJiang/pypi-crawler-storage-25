# Middleware

Middleware lets you intercept and modify **every request and response** that passes through a `ClientSession` — without changing your request code.

## What middleware can do

- Inject authentication headers automatically
- Log all requests and responses
- Add timing / tracing headers
- Retry on specific response codes
- Transform response data

## How it works

```
request →  mw1.request → mw2.request → mw3.request → [HTTP]
response ←  mw1.response ← mw2.response ← mw3.response ← [HTTP]
```

Middleware runs in `__priority__` order on the way **in**, and in **reverse** on the way out.

## Quick example

```python
import asyncio
import astra
from astra.middleware import BaseMiddleware

class LoggingMiddleware(BaseMiddleware):
    __return_type__ = None
    __priority__ = 0
    __methods__ = None
    __enabled__ = True

    async def request(self, method, url, kwargs):
        print(f"→ {method} {url}")
        return kwargs

    async def response(self, response):
        print(f"← {response.status}")
        return response

async def main():
    async with astra.ClientSession(
        middleware=[LoggingMiddleware()],
    ) as session:
        async with session.get("httpbin.org/get") as resp:
            print(resp.json())

asyncio.run(main())
```

Output:

```
→ GET https://httpbin.org/get
← 200
```

## Next

- [Creating Middleware](creating.md) — BaseMiddleware API, class attributes, pipe chaining
- [Examples](examples.md) — auth, logging, timing, method filters, toggle
