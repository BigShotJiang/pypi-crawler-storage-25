# Middleware Examples

## Auth middleware

Inject a Bearer token into every request:

```python
from astra.middleware import BaseMiddleware

class BearerAuthMiddleware(BaseMiddleware):
    __return_type__ = bool
    __priority__ = 0
    __methods__ = None
    __enabled__ = True

    def __init__(self, token: str) -> None:
        self.token = token

    async def request(self, method, url, kwargs):
        kwargs["headers"] = kwargs.get("headers") or {}
        kwargs["headers"]["Authorization"] = f"Bearer {self.token}"
        return kwargs

async with astra.ClientSession(
    middleware=[BearerAuthMiddleware("my-secret-token")],
) as session:
    async with session.get("httpbin.org/headers") as resp:
        print(resp.json())
```

## Logging middleware

Print every request and response:

```python
class LoggingMiddleware(BaseMiddleware):
    __return_type__ = None
    __priority__ = 99
    __methods__ = None
    __enabled__ = True

    async def request(self, method, url, kwargs):
        print(f"→ {method} {url}")
        return kwargs

    async def response(self, response):
        print(f"← {response.status}")
        return response
```

!!! tip
    Set a high `__priority__` so logging runs **last on request** (sees the
    fully-built kwargs) and **first on response** (sees the raw response).

## Timing middleware

Measure request duration:

```python
import time
from astra.middleware import BaseMiddleware

class TimingMiddleware(BaseMiddleware):
    __return_type__ = float
    __priority__ = 0
    __methods__ = None
    __enabled__ = True

    async def request(self, method, url, kwargs):
        kwargs["headers"] = kwargs.get("headers") or {}
        kwargs["headers"]["X-Request-Start"] = str(time.monotonic())
        return kwargs

    async def response(self, response):
        start = float(response.headers.get("x-request-start", 0))
        elapsed = time.monotonic() - start
        print(f"Request took {elapsed:.3f}s")
        return response
```

## Method filter

Run middleware only for specific HTTP methods:

```python
class WriteOpMiddleware(BaseMiddleware):
    __return_type__ = bool
    __priority__ = 1
    __methods__ = ["POST", "PUT", "PATCH", "DELETE"]
    __enabled__ = True

    async def request(self, method, url, kwargs):
        kwargs["headers"] = kwargs.get("headers") or {}
        kwargs["headers"]["X-Write-Op"] = "true"
        return kwargs
```

This middleware is silently skipped for `GET`, `HEAD`, and `OPTIONS`.

## Toggle without removing

Disable a middleware at runtime without editing the session:

```python
debug = LoggingMiddleware()

async with astra.ClientSession(middleware=[debug]) as session:
    async with session.get("httpbin.org/get") as resp:   # logged
        pass

    debug.__enabled__ = False

    async with session.get("httpbin.org/get") as resp:   # not logged
        pass
```

## Chain with pipe

Combine multiple middleware in one line:

```python
chain = (
    BearerAuthMiddleware("token")
    | TimingMiddleware()
    | LoggingMiddleware()
)

async with astra.ClientSession(middleware=chain) as session:
    ...
```

Execution order on request: `BearerAuth → Timing → Logging → [HTTP]`
Execution order on response: `[HTTP] → Logging → Timing → BearerAuth`
