# Creating Middleware

## BaseMiddleware

All middleware inherit from `BaseMiddleware`:

```python
from astra.middleware import BaseMiddleware

class MyMiddleware(BaseMiddleware):
    __return_type__ = bool
    __priority__ = 0
    __methods__ = None
    __enabled__ = True

    async def request(self, method, url, kwargs):
        # modify kwargs before the request is sent
        return kwargs

    async def response(self, response):
        # inspect or modify the response
        return response
```

## Class attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `__return_type__` | `type \| None` | Type this middleware operates on. Informational. |
| `__priority__` | `int` | Execution order — **lower runs first**. |
| `__methods__` | `list[str] \| None` | HTTP methods to intercept. `None` = all methods. |
| `__enabled__` | `bool` | `False` skips this middleware without removing it. |

!!! note "No defaults"
    None of these attributes have defaults in `BaseMiddleware`. Define only the ones
    you need. Attributes you don't define are simply not checked.

## `request(method, url, kwargs)`

Called **before** the HTTP request is sent. Receives:

- `method` — HTTP verb string (`"GET"`, `"POST"`, etc.)
- `url` — resolved URL string (scheme already added)
- `kwargs` — dict with keys: `params`, `headers`, `json`, `data`, `timeout`

Must return the (possibly modified) `kwargs` dict:

```python
async def request(self, method, url, kwargs):
    kwargs["headers"] = kwargs.get("headers") or {}
    kwargs["headers"]["X-Request-ID"] = generate_id()
    return kwargs
```

!!! warning "headers may be None"
    `kwargs["headers"]` is `None` when no headers were passed.
    Always use `kwargs.get("headers") or {}` before adding keys.

## `response(response)`

Called **after** the HTTP response is received. Receives a `Response` object.
Must return a `Response` (can be the same or a wrapper):

```python
async def response(self, response):
    if response.status >= 400:
        print(f"Error {response.status}")
    return response
```

## Dunder methods

### `__repr__`

```python
mw = MyMiddleware()
print(mw)   # <MyMiddleware return_type=<class 'bool'>>
```

### `__or__` — pipe chaining

Combine middleware with `|`:

```python
from astra.middleware import BaseMiddleware

chain = AuthMiddleware() | LoggingMiddleware() | TimingMiddleware()
```

The result is a `MiddlewareChain` — pass it directly to `ClientSession`:

```python
async with astra.ClientSession(middleware=chain) as session:
    ...
```

### `__init_subclass__`

Fires when you subclass `BaseMiddleware`. Override it to add custom validation:

```python
class StrictMiddleware(BaseMiddleware):
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if not hasattr(cls, "__priority__"):
            raise TypeError(f"{cls.__name__} must define __priority__")
```

## Attaching to a session

=== "List"

    ```python
    astra.ClientSession(
        middleware=[AuthMiddleware(), LoggingMiddleware()],
    )
    ```

=== "Pipe"

    ```python
    astra.ClientSession(
        middleware=AuthMiddleware() | LoggingMiddleware(),
    )
    ```

Both are equivalent. Order in the list respects `__priority__` — it is sorted automatically.

## Toggle at runtime

```python
debug = DebugMiddleware()
debug.__enabled__ = False   # temporarily disable
```

The middleware stays in the chain but is skipped on every request until re-enabled.
