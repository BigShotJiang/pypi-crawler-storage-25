# astrahttp

**astrahttp** is an async HTTP client for Python built on top of [httpx](https://www.python-httpx.org/). It provides a clean context-manager API, automatic error handling, Pydantic response validation, HTTP/2 support, and a flexible middleware system.

---

## Features

- **Async-first** — built for `asyncio`, every request uses `async with`
- **Automatic error handling** — HTTP 4xx/5xx and network errors raise typed exceptions
- **Pydantic integration** — validate JSON responses directly into model instances
- **Middleware system** — intercept and transform requests/responses with `BaseMiddleware`
- **HTTP/2 support** — enable with a single flag
- **URL auto-scheme** — pass `"example.com"` instead of `"https://example.com"`
- **Session-level defaults** — set base URL, headers, timeout once for all requests

---

## Install

```bash
pip install astra-client
```

With HTTP/2 support:

```bash
pip install astra-client[http2]
```

---

## Quick Start

```python
import asyncio
import astra

async def main():
    async with astra.ClientSession(base_url="https://httpbin.org") as session:
        async with session.get("/get") as resp:
            print(resp.status)   # 200
            data = resp.json()
            print(data["url"])

asyncio.run(main())
```

---

## Requirements

- Python 3.10+
- httpx ≥ 0.28.1
- pydantic ≥ 2.0 (optional, for model validation)

---

## Source

GitHub: [https://github.com/ndugram/astrahttp](https://github.com/ndugram/astrahttp)
