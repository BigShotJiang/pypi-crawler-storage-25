# Code of Conduct

## Our Pledge

We are committed to making participation in this project a harassment-free experience for everyone, regardless of age, body size, disability, ethnicity, gender identity, level of experience, nationality, personal appearance, race, religion, or sexual identity.

## Our Standards

Acceptable behavior:
- Using welcoming and inclusive language
- Respecting differing viewpoints and experiences
- Accepting constructive criticism gracefully
- Focusing on what is best for the community

Unacceptable behavior:
- Harassment, insults, or derogatory comments
- Publishing others' private information without permission
- Trolling or deliberately disruptive behavior
- Any conduct that would be inappropriate in a professional setting

## Enforcement

Instances of unacceptable behavior may be reported to n7for8572@gmail.com. All complaints will be reviewed and investigated promptly and fairly.

Maintainers have the right to remove, edit, or reject comments, commits, issues, and other contributions that violate this Code of Conduct.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org), version 2.1.
