import pytest
import httpx
import astra


async def test_base_url_prepended_to_requests(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession(base_url="https://api.example.com") as session:
        async with session.get("/users") as resp:
            assert resp.status == 200
    assert "api.example.com" in str(httpx_mock.get_requests()[0].url)


async def test_base_url_none_uses_absolute_url(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession() as session:
        async with session.get("example.com/api") as resp:
            assert resp.status == 200
    assert str(httpx_mock.get_requests()[0].url).startswith("https://example.com")


async def test_timeout_passed_to_request(httpx_mock):
    httpx_mock.add_exception(httpx.TimeoutException(""))
    with pytest.raises(astra.TimeoutError):
        async with astra.ClientSession(timeout=0.001) as session:
            async with session.get("example.com") as resp:
                pass


async def test_per_request_timeout_overrides_session(httpx_mock):
    httpx_mock.add_exception(httpx.TimeoutException(""))
    with pytest.raises(astra.TimeoutError):
        async with astra.ClientSession(timeout=30.0) as session:
            async with session.get("example.com", timeout=0.001) as resp:
                pass


async def test_session_headers_merged_with_request_headers(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession(headers={"X-Session": "sess"}) as session:
        async with session.get("example.com", headers={"X-Request": "req"}) as resp:
            assert resp.status == 200
    req = httpx_mock.get_requests()[0]
    assert req.headers["x-session"] == "sess"
    assert req.headers["x-request"] == "req"


async def test_post_with_form_data_sent(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession() as session:
        async with session.post("example.com", data={"field": "value"}) as resp:
            assert resp.status == 200
    assert httpx_mock.get_requests()[0].method == "POST"


async def test_post_with_raw_bytes_sent(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession() as session:
        async with session.post("example.com", data=b"\x00\x01\x02") as resp:
            assert resp.status == 200


async def test_post_with_json_sets_content_type(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession() as session:
        async with session.post("example.com", json={"key": "val"}) as resp:
            assert resp.status == 200
    req = httpx_mock.get_requests()[0]
    assert "application/json" in req.headers.get("content-type", "")


async def test_delete_with_headers(httpx_mock):
    httpx_mock.add_response(status_code=204)
    async with astra.ClientSession() as session:
        async with session.delete("example.com/item/1", headers={"X-Confirm": "true"}) as resp:
            assert resp.status == 204
    assert httpx_mock.get_requests()[0].headers["x-confirm"] == "true"


async def test_patch_with_json_body(httpx_mock):
    httpx_mock.add_response(json={"id": 1, "status": "active"})
    async with astra.ClientSession() as session:
        async with session.patch("example.com/item/1", json={"status": "active"}) as resp:
            data = resp.json()
    assert data["status"] == "active"


async def test_put_overwrites_resource(httpx_mock):
    httpx_mock.add_response(json={"id": 1, "name": "updated"})
    async with astra.ClientSession() as session:
        async with session.put("example.com/item/1", json={"name": "updated"}) as resp:
            data = resp.json()
    assert data["name"] == "updated"
    assert httpx_mock.get_requests()[0].method == "PUT"


async def test_head_returns_no_body(httpx_mock):
    httpx_mock.add_response(status_code=200, headers={"x-count": "42"})
    async with astra.ClientSession() as session:
        async with session.head("example.com") as resp:
            assert resp.status == 200
            assert resp.headers["x-count"] == "42"


async def test_options_response_status(httpx_mock):
    httpx_mock.add_response(status_code=200, headers={"Allow": "GET, POST, OPTIONS"})
    async with astra.ClientSession() as session:
        async with session.options("example.com") as resp:
            assert resp.status == 200


async def test_multiple_query_params(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession() as session:
        async with session.get("example.com", params={"a": "1", "b": "2", "c": "3"}) as resp:
            assert resp.status == 200
    url = str(httpx_mock.get_requests()[0].url)
    assert "a=1" in url
    assert "b=2" in url
    assert "c=3" in url


async def test_session_used_as_context_manager(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    session = astra.ClientSession()
    async with session:
        async with session.get("example.com") as resp:
            assert resp.status == 200


async def test_empty_headers_dict_accepted(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession(headers={}) as session:
        async with session.get("example.com") as resp:
            assert resp.status == 200


async def test_none_timeout_means_no_timeout(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession(timeout=None) as session:
        async with session.get("example.com") as resp:
            assert resp.status == 200
