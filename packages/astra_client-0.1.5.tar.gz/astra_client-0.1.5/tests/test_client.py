import pytest
import httpx
import astra


async def test_get_request(httpx_mock):
    httpx_mock.add_response(json={"method": "GET"})
    async with astra.ClientSession() as session:
        async with session.get("example.com/get") as resp:
            assert resp.status == 200
            data = resp.json()
            assert data["method"] == "GET"


async def test_post_request_with_json(httpx_mock):
    httpx_mock.add_response(json={"method": "POST"})
    async with astra.ClientSession() as session:
        async with session.post("example.com/post", json={"key": "val"}) as resp:
            assert resp.status == 200


async def test_put_request(httpx_mock):
    httpx_mock.add_response(json={"method": "PUT"})
    async with astra.ClientSession() as session:
        async with session.put("example.com/put", json={"key": "val"}) as resp:
            assert resp.status == 200


async def test_patch_request(httpx_mock):
    httpx_mock.add_response(json={"method": "PATCH"})
    async with astra.ClientSession() as session:
        async with session.patch("example.com/patch", json={"key": "val"}) as resp:
            assert resp.status == 200


async def test_delete_request(httpx_mock):
    httpx_mock.add_response(status_code=204)
    async with astra.ClientSession() as session:
        async with session.delete("example.com/delete") as resp:
            assert resp.status == 204


async def test_head_request(httpx_mock):
    httpx_mock.add_response(status_code=200)
    async with astra.ClientSession() as session:
        async with session.head("example.com") as resp:
            assert resp.status == 200


async def test_options_request(httpx_mock):
    httpx_mock.add_response(status_code=200)
    async with astra.ClientSession() as session:
        async with session.options("example.com") as resp:
            assert resp.status == 200


async def test_request_method_directly(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession() as session:
        async with session.request("GET", "example.com") as resp:
            assert resp.status == 200


async def test_correct_http_method_used_for_post(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession() as session:
        async with session.post("example.com", json={}) as resp:
            pass
    assert httpx_mock.get_requests()[0].method == "POST"


async def test_correct_http_method_used_for_put(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession() as session:
        async with session.put("example.com", json={}) as resp:
            pass
    assert httpx_mock.get_requests()[0].method == "PUT"


async def test_params_sent_in_request(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession() as session:
        async with session.get("example.com", params={"q": "search", "page": "1"}) as resp:
            assert resp.status == 200
    assert "q=search" in str(httpx_mock.get_requests()[0].url)


async def test_session_headers_sent(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession(headers={"X-Token": "secret"}) as session:
        async with session.get("example.com") as resp:
            assert resp.status == 200
    assert httpx_mock.get_requests()[0].headers["x-token"] == "secret"


async def test_per_request_headers_sent(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession() as session:
        async with session.get("example.com", headers={"X-Custom": "value"}) as resp:
            assert resp.status == 200
    assert httpx_mock.get_requests()[0].headers["x-custom"] == "value"


async def test_timeout_error_raised(httpx_mock):
    httpx_mock.add_exception(httpx.TimeoutException(""))
    with pytest.raises(astra.TimeoutError):
        async with astra.ClientSession() as session:
            async with session.get("example.com") as resp:
                pass


async def test_connection_error_raised(httpx_mock):
    httpx_mock.add_exception(httpx.ConnectError(""))
    with pytest.raises(astra.ConnectionError):
        async with astra.ClientSession() as session:
            async with session.get("example.com") as resp:
                pass


async def test_too_many_redirects_raised(httpx_mock):
    httpx_mock.add_exception(httpx.TooManyRedirects(""))
    with pytest.raises(astra.TooManyRedirectsError):
        async with astra.ClientSession() as session:
            async with session.get("example.com") as resp:
                pass


async def test_network_error_raised(httpx_mock):
    httpx_mock.add_exception(httpx.NetworkError(""))
    with pytest.raises(astra.NetworkError):
        async with astra.ClientSession() as session:
            async with session.get("example.com") as resp:
                pass


async def test_invalid_url_raised(httpx_mock):
    httpx_mock.add_exception(httpx.InvalidURL(""))
    with pytest.raises(astra.InvalidURLError):
        async with astra.ClientSession() as session:
            async with session.get("example.com") as resp:
                pass


async def test_404_raises_not_found(httpx_mock):
    httpx_mock.add_response(status_code=404)
    with pytest.raises(astra.NotFoundError):
        async with astra.ClientSession() as session:
            async with session.get("example.com") as resp:
                pass


async def test_401_raises_unauthorized(httpx_mock):
    httpx_mock.add_response(status_code=401)
    with pytest.raises(astra.UnauthorizedError):
        async with astra.ClientSession() as session:
            async with session.get("example.com") as resp:
                pass


async def test_500_raises_internal_server_error(httpx_mock):
    httpx_mock.add_response(status_code=500)
    with pytest.raises(astra.InternalServerError):
        async with astra.ClientSession() as session:
            async with session.get("example.com") as resp:
                pass


async def test_503_raises_service_unavailable(httpx_mock):
    httpx_mock.add_response(status_code=503)
    with pytest.raises(astra.ServiceUnavailableError):
        async with astra.ClientSession() as session:
            async with session.get("example.com") as resp:
                pass


async def test_bare_url_https_scheme_added(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession() as session:
        async with session.get("example.com") as resp:
            pass
    assert str(httpx_mock.get_requests()[0].url).startswith("https://")


async def test_multiple_requests_in_session(httpx_mock):
    httpx_mock.add_response(json={"n": 1})
    httpx_mock.add_response(json={"n": 2})
    async with astra.ClientSession() as session:
        async with session.get("example.com/1") as resp:
            d1 = resp.json()
        async with session.get("example.com/2") as resp:
            d2 = resp.json()
    assert d1["n"] == 1
    assert d2["n"] == 2
