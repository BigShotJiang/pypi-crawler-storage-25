import sys
import importlib
import pytest
import astra
from astra.exceptions import MissingDependencyError


def test_missing_dependency_error_is_astra_error():
    assert issubclass(MissingDependencyError, astra.AstraHttpError)


def test_missing_dependency_error_message():
    err = MissingDependencyError("test message")
    assert "test message" in str(err)


def test_missing_dependency_exported_from_astra():
    assert hasattr(astra, "MissingDependencyError")


async def test_http2_false_does_not_raise(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession(http2=False) as session:
        async with session.get("example.com") as resp:
            assert resp.status == 200


async def test_http2_raises_missing_dependency_when_h2_absent(monkeypatch):
    import builtins
    real_import = builtins.__import__

    def mock_import(name, *args, **kwargs):
        if name == "h2":
            raise ImportError("No module named 'h2'")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", mock_import)

    with pytest.raises(MissingDependencyError) as exc_info:
        astra.ClientSession(http2=True)

    assert "pip install astra-client[http2]" in str(exc_info.value)


async def test_http2_error_message_contains_h2(monkeypatch):
    import builtins
    real_import = builtins.__import__

    def mock_import(name, *args, **kwargs):
        if name == "h2":
            raise ImportError
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", mock_import)

    with pytest.raises(MissingDependencyError) as exc_info:
        astra.ClientSession(http2=True)

    assert "h2" in str(exc_info.value).lower()


@pytest.mark.skipif(
    importlib.util.find_spec("h2") is None,
    reason="h2 not installed",
)
async def test_http2_works_when_h2_installed(httpx_mock):
    httpx_mock.add_response(json={"protocol": "h2"})
    async with astra.ClientSession(http2=True) as session:
        async with session.get("example.com") as resp:
            assert resp.status == 200


@pytest.mark.skipif(
    importlib.util.find_spec("h2") is not None,
    reason="h2 is installed",
)
async def test_http2_raises_when_h2_not_installed():
    with pytest.raises(MissingDependencyError):
        astra.ClientSession(http2=True)
