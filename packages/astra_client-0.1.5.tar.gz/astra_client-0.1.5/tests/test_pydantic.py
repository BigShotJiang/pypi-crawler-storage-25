import pytest
from pydantic import BaseModel, ValidationError
import astra


class UserResponse(BaseModel):
    id: int
    name: str


class PostResponse(BaseModel):
    title: str
    body: str


async def test_session_model_validates_response(httpx_mock):
    httpx_mock.add_response(json={"id": 1, "name": "Alice"})
    async with astra.ClientSession(response_model=UserResponse) as session:
        async with session.get("example.com/user") as resp:
            data = resp.json()
    assert isinstance(data, UserResponse)
    assert data.id == 1
    assert data.name == "Alice"


async def test_per_request_model_overrides_session_model(httpx_mock):
    httpx_mock.add_response(json={"title": "Post", "body": "Content"})
    async with astra.ClientSession(response_model=UserResponse) as session:
        async with session.get("example.com/post", response_model=PostResponse) as resp:
            data = resp.json()
    assert isinstance(data, PostResponse)
    assert data.title == "Post"


async def test_no_model_returns_raw_dict(httpx_mock):
    httpx_mock.add_response(json={"id": 1, "name": "Alice"})
    async with astra.ClientSession() as session:
        async with session.get("example.com/user") as resp:
            data = resp.json()
    assert isinstance(data, dict)
    assert data["id"] == 1


async def test_validation_error_propagates_on_schema_mismatch(httpx_mock):
    httpx_mock.add_response(json={"unexpected": "data"})
    with pytest.raises(ValidationError):
        async with astra.ClientSession(response_model=UserResponse) as session:
            async with session.get("example.com/user") as resp:
                resp.json()


async def test_nested_model_validation(httpx_mock):
    class Address(BaseModel):
        city: str
        country: str

    class PersonResponse(BaseModel):
        name: str
        address: Address

    httpx_mock.add_response(json={"name": "Bob", "address": {"city": "Moscow", "country": "Russia"}})
    async with astra.ClientSession(response_model=PersonResponse) as session:
        async with session.get("example.com/person") as resp:
            data = resp.json()
    assert isinstance(data, PersonResponse)
    assert isinstance(data.address, Address)
    assert data.address.city == "Moscow"


async def test_post_with_per_request_model(httpx_mock):
    httpx_mock.add_response(json={"id": 42, "name": "New User"})
    async with astra.ClientSession() as session:
        async with session.post(
            "example.com/users",
            json={"name": "New User"},
            response_model=UserResponse,
        ) as resp:
            data = resp.json()
    assert isinstance(data, UserResponse)
    assert data.id == 42


async def test_session_model_applies_to_all_requests(httpx_mock):
    httpx_mock.add_response(json={"id": 1, "name": "Alice"})
    httpx_mock.add_response(json={"id": 2, "name": "Bob"})
    async with astra.ClientSession(response_model=UserResponse) as session:
        async with session.get("example.com/user/1") as resp:
            u1 = resp.json()
        async with session.get("example.com/user/2") as resp:
            u2 = resp.json()
    assert isinstance(u1, UserResponse)
    assert isinstance(u2, UserResponse)
    assert u1.id == 1
    assert u2.id == 2


async def test_model_with_optional_fields(httpx_mock):
    class FlexResponse(BaseModel):
        id: int
        name: str
        email: str | None = None

    httpx_mock.add_response(json={"id": 5, "name": "Charlie"})
    async with astra.ClientSession(response_model=FlexResponse) as session:
        async with session.get("example.com/user") as resp:
            data = resp.json()
    assert isinstance(data, FlexResponse)
    assert data.email is None
