import json
import httpx


def make_httpx_response(
    status_code: int = 200,
    body: dict | None = None,
    text: str | None = None,
    headers: dict | None = None,
) -> httpx.Response:
    if body is not None:
        content = json.dumps(body).encode()
        content_type = "application/json"
    else:
        content = (text or "").encode()
        content_type = "text/plain; charset=utf-8"
    resp_headers = {"content-type": content_type, **(headers or {})}
    return httpx.Response(status_code=status_code, content=content, headers=resp_headers)
