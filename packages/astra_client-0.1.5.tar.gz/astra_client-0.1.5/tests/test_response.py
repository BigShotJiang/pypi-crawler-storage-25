import pytest
from pydantic import BaseModel, ValidationError
from astra.response import Response
from conftest import make_httpx_response


async def test_status_attribute():
    resp = Response(make_httpx_response(201))
    assert resp.status == 201


async def test_headers_attribute():
    resp = Response(make_httpx_response(200, headers={"x-custom": "value"}))
    assert resp.headers["x-custom"] == "value"


async def test_text_returns_decoded_string():
    resp = Response(make_httpx_response(text="hello world"))
    assert resp.text() == "hello world"


async def test_json_returns_parsed_dict():
    resp = Response(make_httpx_response(body={"key": "value", "count": 42}))
    data = resp.json()
    assert data["key"] == "value"
    assert data["count"] == 42


async def test_read_returns_bytes():
    resp = Response(make_httpx_response(text="hello"))
    data = resp.read()
    assert isinstance(data, bytes)
    assert data == b"hello"


async def test_close_does_not_raise():
    resp = Response(make_httpx_response(200))
    await resp.close()


async def test_json_with_model_returns_validated_instance():
    class User(BaseModel):
        id: int
        name: str

    resp = Response(
        make_httpx_response(body={"id": 1, "name": "Alice"}),
        response_model=User,
    )
    data = resp.json()
    assert isinstance(data, User)
    assert data.id == 1
    assert data.name == "Alice"


async def test_json_without_model_returns_raw_dict():
    resp = Response(make_httpx_response(body={"id": 1}))
    data = resp.json()
    assert isinstance(data, dict)


async def test_response_model_none_by_default():
    resp = Response(make_httpx_response(body={}))
    assert resp._response_model is None


async def test_model_validation_error_propagates():
    class Strict(BaseModel):
        id: int
        name: str

    resp = Response(
        make_httpx_response(body={"wrong": "fields"}),
        response_model=Strict,
    )
    with pytest.raises(ValidationError):
        resp.json()


async def test_status_codes_stored_correctly():
    for code in [200, 201, 400, 404, 500]:
        resp = Response(make_httpx_response(code))
        assert resp.status == code
