import pytest
import astra
from astra.middleware import BaseMiddleware, MiddlewareChain


class SimpleMiddleware(BaseMiddleware):
    __return_type__ = bool
    __priority__ = 10
    __methods__ = ["GET"]
    __enabled__ = True


class AnotherMiddleware(BaseMiddleware):
    __return_type__ = str
    __priority__ = 1
    __enabled__ = True


# ── BaseMiddleware ────────────────────────────────────────────────────────────

def test_repr_contains_class_name_and_return_type():
    mw = SimpleMiddleware()
    assert "SimpleMiddleware" in repr(mw)
    assert "bool" in repr(mw)


def test_repr_no_return_type():
    class Bare(BaseMiddleware):
        pass

    assert "None" in repr(Bare())


def test_or_returns_middleware_chain():
    chain = SimpleMiddleware() | AnotherMiddleware()
    assert isinstance(chain, MiddlewareChain)


def test_subclass_without_dunders_has_no_attrs():
    class Bare(BaseMiddleware):
        pass

    mw = Bare()
    assert not hasattr(mw, "__return_type__")
    assert not hasattr(mw, "__priority__")
    assert not hasattr(mw, "__methods__")
    assert not hasattr(mw, "__enabled__")


async def test_request_returns_kwargs_unchanged():
    mw = SimpleMiddleware()
    kwargs = {"headers": {}, "params": None}
    result = await mw.request("GET", "https://example.com", kwargs)
    assert result is kwargs


async def test_response_returns_response_unchanged(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession() as session:
        async with session.get("example.com") as resp:
            mw = SimpleMiddleware()
            result = await mw.response(resp)
            assert result is resp


# ── MiddlewareChain ───────────────────────────────────────────────────────────

def test_chain_len():
    chain = SimpleMiddleware() | AnotherMiddleware()
    assert len(chain) == 2


def test_chain_or_appends():
    chain = SimpleMiddleware() | AnotherMiddleware() | SimpleMiddleware()
    assert len(chain) == 3


def test_chain_iter_order():
    a = SimpleMiddleware()
    b = AnotherMiddleware()
    items = list(a | b)
    assert items[0] is a
    assert items[1] is b


def test_chain_repr():
    chain = SimpleMiddleware() | AnotherMiddleware()
    r = repr(chain)
    assert "SimpleMiddleware" in r
    assert "AnotherMiddleware" in r


# ── Integration: request modification ────────────────────────────────────────

async def test_middleware_modifies_request_headers(httpx_mock):
    httpx_mock.add_response(json={"ok": True})

    class AddHeaderMiddleware(BaseMiddleware):
        __return_type__ = bool
        __priority__ = 0
        __methods__ = None
        __enabled__ = True

        async def request(self, method, url, kwargs):
            kwargs["headers"] = kwargs.get("headers") or {}
            kwargs["headers"]["X-Test"] = "middleware"
            return kwargs

    async with astra.ClientSession(middleware=[AddHeaderMiddleware()]) as session:
        async with session.get("example.com") as resp:
            assert resp.status == 200

    request = httpx_mock.get_request()
    assert request.headers.get("x-test") == "middleware"


async def test_middleware_modifies_response(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    call_log = []

    class TrackMiddleware(BaseMiddleware):
        __return_type__ = bool
        __priority__ = 0
        __methods__ = None
        __enabled__ = True

        async def response(self, response):
            call_log.append(response.status)
            return response

    async with astra.ClientSession(middleware=[TrackMiddleware()]) as session:
        async with session.get("example.com") as resp:
            assert resp.status == 200

    assert call_log == [200]


# ── Integration: __enabled__ ──────────────────────────────────────────────────

async def test_disabled_middleware_skipped(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    call_log = []

    class DisabledMiddleware(BaseMiddleware):
        __return_type__ = bool
        __priority__ = 0
        __methods__ = None
        __enabled__ = False

        async def request(self, method, url, kwargs):
            call_log.append("called")
            return kwargs

    async with astra.ClientSession(middleware=[DisabledMiddleware()]) as session:
        async with session.get("example.com") as _:
            pass

    assert call_log == []


# ── Integration: __methods__ ──────────────────────────────────────────────────

async def test_methods_filter_skips_non_matching(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    call_log = []

    class GetOnlyMiddleware(BaseMiddleware):
        __return_type__ = bool
        __priority__ = 0
        __methods__ = ["GET"]
        __enabled__ = True

        async def request(self, method, url, kwargs):
            call_log.append(method)
            return kwargs

    async with astra.ClientSession(middleware=[GetOnlyMiddleware()]) as session:
        async with session.post("example.com", json={}) as _:
            pass

    assert call_log == []


async def test_methods_filter_runs_on_match(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    call_log = []

    class GetOnlyMiddleware(BaseMiddleware):
        __return_type__ = bool
        __priority__ = 0
        __methods__ = ["GET"]
        __enabled__ = True

        async def request(self, method, url, kwargs):
            call_log.append(method)
            return kwargs

    async with astra.ClientSession(middleware=[GetOnlyMiddleware()]) as session:
        async with session.get("example.com") as _:
            pass

    assert call_log == ["GET"]


# ── Integration: __priority__ ─────────────────────────────────────────────────

async def test_priority_determines_execution_order(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    order = []

    class HighPriority(BaseMiddleware):
        __return_type__ = bool
        __priority__ = 1
        __methods__ = None
        __enabled__ = True

        async def request(self, method, url, kwargs):
            order.append("high")
            return kwargs

    class LowPriority(BaseMiddleware):
        __return_type__ = bool
        __priority__ = 99
        __methods__ = None
        __enabled__ = True

        async def request(self, method, url, kwargs):
            order.append("low")
            return kwargs

    # pass in reverse order — priority should fix it
    async with astra.ClientSession(middleware=[LowPriority(), HighPriority()]) as session:
        async with session.get("example.com") as _:
            pass

    assert order == ["high", "low"]


# ── Integration: pipe syntax in ClientSession ─────────────────────────────────

async def test_pipe_middleware_in_client_session(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    call_log = []

    class MW(BaseMiddleware):
        __return_type__ = bool
        __priority__ = 0
        __methods__ = None
        __enabled__ = True

        async def request(self, method, url, kwargs):
            call_log.append("mw")
            return kwargs

    async with astra.ClientSession(middleware=MW() | MW()) as session:
        async with session.get("example.com") as _:
            pass

    assert call_log == ["mw", "mw"]
