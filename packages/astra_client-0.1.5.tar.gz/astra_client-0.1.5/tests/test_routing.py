import pytest
from astra.helpers.routing import check_https_url


async def test_bare_url_gets_https():
    assert await check_https_url(url="example.com") == "https://example.com"


async def test_https_url_unchanged():
    assert await check_https_url(url="https://example.com") == "https://example.com"


async def test_http_url_unchanged():
    assert await check_https_url(url="http://example.com") == "http://example.com"


async def test_whitespace_stripped():
    assert await check_https_url(url="  example.com  ") == "https://example.com"


async def test_url_with_path():
    assert await check_https_url(url="example.com/api/v1") == "https://example.com/api/v1"


async def test_url_with_query_string():
    assert await check_https_url(url="example.com?key=value") == "https://example.com?key=value"


async def test_url_with_port():
    assert await check_https_url(url="example.com:8080") == "https://example.com:8080"


async def test_http_scheme_not_upgraded():
    assert await check_https_url(url="http://insecure.example.com") == "http://insecure.example.com"
