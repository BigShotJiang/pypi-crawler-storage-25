import asyncio
import pytest
import astra


async def test_concurrent_get_requests(httpx_mock):
    for i in range(5):
        httpx_mock.add_response(json={"id": i})

    async def fetch(session: astra.ClientSession, path: str) -> dict:
        async with session.get(path) as resp:
            return resp.json()

    async with astra.ClientSession() as session:
        tasks = [fetch(session, f"example.com/{i}") for i in range(5)]
        results = await asyncio.gather(*tasks)

    assert len(results) == 5


async def test_concurrent_mixed_methods(httpx_mock):
    httpx_mock.add_response(json={"method": "GET"})
    httpx_mock.add_response(json={"method": "POST"})
    httpx_mock.add_response(json={"method": "PUT"})

    async def do_get(session):
        async with session.get("example.com/get") as r:
            return r.json()

    async def do_post(session):
        async with session.post("example.com/post", json={}) as r:
            return r.json()

    async def do_put(session):
        async with session.put("example.com/put", json={}) as r:
            return r.json()

    async with astra.ClientSession() as session:
        get_r, post_r, put_r = await asyncio.gather(
            do_get(session),
            do_post(session),
            do_put(session),
        )

    assert get_r["method"] == "GET"
    assert post_r["method"] == "POST"
    assert put_r["method"] == "PUT"


async def test_gather_propagates_exception(httpx_mock):
    import httpx as _httpx

    httpx_mock.add_response(json={"ok": True})
    httpx_mock.add_exception(_httpx.ConnectError(""))

    async def fetch(session, path):
        async with session.get(path) as r:
            return r.json()

    async with astra.ClientSession() as session:
        with pytest.raises(astra.ConnectionError):
            await asyncio.gather(
                fetch(session, "example.com/a"),
                fetch(session, "example.com/b"),
            )


async def test_sequential_requests_same_session(httpx_mock):
    for i in range(3):
        httpx_mock.add_response(json={"n": i})

    results = []
    async with astra.ClientSession() as session:
        for i in range(3):
            async with session.get(f"example.com/{i}") as resp:
                results.append(resp.json()["n"])

    assert results == [0, 1, 2]


async def test_concurrent_requests_preserve_response_data(httpx_mock):
    payloads = [{"id": i, "name": f"item-{i}"} for i in range(10)]
    for payload in payloads:
        httpx_mock.add_response(json=payload)

    async def fetch(session, i):
        async with session.get(f"example.com/item/{i}") as r:
            return r.json()

    async with astra.ClientSession() as session:
        tasks = [fetch(session, i) for i in range(10)]
        results = await asyncio.gather(*tasks)

    assert len(results) == 10
    ids = {r["id"] for r in results}
    assert len(ids) == 10


async def test_gather_return_exceptions_collects_errors(httpx_mock):
    import httpx as _httpx

    httpx_mock.add_exception(_httpx.TimeoutException(""))
    httpx_mock.add_exception(_httpx.TimeoutException(""))

    async def fetch(session):
        async with session.get("example.com") as r:
            return r.json()

    async with astra.ClientSession() as session:
        results = await asyncio.gather(
            fetch(session),
            fetch(session),
            return_exceptions=True,
        )

    assert all(isinstance(r, astra.TimeoutError) for r in results)
