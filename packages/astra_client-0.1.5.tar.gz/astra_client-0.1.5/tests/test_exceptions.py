import pytest
import astra
from astra.exceptions.http import raise_for_status


@pytest.mark.parametrize("status_code", [200, 201, 204, 301, 302, 304])
def test_non_error_codes_do_not_raise(status_code):
    raise_for_status(status_code, "OK")


def test_400_raises_bad_request():
    with pytest.raises(astra.BadRequestError):
        raise_for_status(400, "Bad Request")


def test_401_raises_unauthorized():
    with pytest.raises(astra.UnauthorizedError):
        raise_for_status(401, "Unauthorized")


def test_403_raises_forbidden():
    with pytest.raises(astra.ForbiddenError):
        raise_for_status(403, "Forbidden")


def test_404_raises_not_found():
    with pytest.raises(astra.NotFoundError):
        raise_for_status(404, "Not Found")


def test_405_raises_method_not_allowed():
    with pytest.raises(astra.MethodNotAllowedError):
        raise_for_status(405, "Method Not Allowed")


def test_422_raises_unprocessable_entity():
    with pytest.raises(astra.UnprocessableEntityError):
        raise_for_status(422, "Unprocessable Entity")


def test_429_raises_too_many_requests():
    with pytest.raises(astra.TooManyRequestsError):
        raise_for_status(429, "Too Many Requests")


def test_500_raises_internal_server_error():
    with pytest.raises(astra.InternalServerError):
        raise_for_status(500, "Internal Server Error")


def test_502_raises_bad_gateway():
    with pytest.raises(astra.BadGatewayError):
        raise_for_status(502, "Bad Gateway")


def test_503_raises_service_unavailable():
    with pytest.raises(astra.ServiceUnavailableError):
        raise_for_status(503, "Service Unavailable")


def test_504_raises_gateway_timeout():
    with pytest.raises(astra.GatewayTimeoutError):
        raise_for_status(504, "Gateway Timeout")


def test_unknown_4xx_raises_client_error():
    with pytest.raises(astra.ClientError):
        raise_for_status(418, "I'm a Teapot")


def test_unknown_5xx_raises_server_error():
    with pytest.raises(astra.ServerError):
        raise_for_status(511, "Network Authentication Required")


def test_exception_str_includes_status_code():
    with pytest.raises(astra.NotFoundError) as exc_info:
        raise_for_status(404, "Not Found")
    assert "404" in str(exc_info.value)


def test_http_status_error_stores_status_code():
    with pytest.raises(astra.NotFoundError) as exc_info:
        raise_for_status(404, "Not Found")
    assert exc_info.value.status_code == 404


def test_4xx_is_subclass_of_http_status_error():
    with pytest.raises(astra.HTTPStatusError):
        raise_for_status(404, "Not Found")


def test_5xx_is_subclass_of_http_status_error():
    with pytest.raises(astra.HTTPStatusError):
        raise_for_status(500, "Internal Server Error")


def test_http_status_error_is_subclass_of_astra_error():
    with pytest.raises(astra.AstraHttpError):
        raise_for_status(400, "Bad Request")


def test_network_error_hierarchy():
    assert issubclass(astra.ConnectionError, astra.NetworkError)
    assert issubclass(astra.TimeoutError, astra.NetworkError)
    assert issubclass(astra.TooManyRedirectsError, astra.NetworkError)
    assert issubclass(astra.NetworkError, astra.AstraHttpError)


def test_client_error_is_http_status_error():
    err = astra.ClientError("error", status_code=400)
    assert isinstance(err, astra.HTTPStatusError)
    assert isinstance(err, astra.AstraHttpError)


def test_server_error_is_http_status_error():
    err = astra.ServerError("error", status_code=500)
    assert isinstance(err, astra.HTTPStatusError)
    assert err.status_code == 500


def test_specific_errors_are_subclass_of_client_error():
    assert issubclass(astra.BadRequestError, astra.ClientError)
    assert issubclass(astra.UnauthorizedError, astra.ClientError)
    assert issubclass(astra.ForbiddenError, astra.ClientError)
    assert issubclass(astra.NotFoundError, astra.ClientError)
    assert issubclass(astra.TooManyRequestsError, astra.ClientError)


def test_specific_errors_are_subclass_of_server_error():
    assert issubclass(astra.InternalServerError, astra.ServerError)
    assert issubclass(astra.BadGatewayError, astra.ServerError)
    assert issubclass(astra.ServiceUnavailableError, astra.ServerError)
    assert issubclass(astra.GatewayTimeoutError, astra.ServerError)
