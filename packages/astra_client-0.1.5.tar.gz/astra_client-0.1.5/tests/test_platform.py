"""
Platform-specific behavior tests.
Each test is tagged with the platform(s) it targets via pytest.mark.skipif.
The full suite still runs everywhere — platform marks only gate tests
that verify OS-specific behavior.
"""
import sys
import asyncio
import pytest
import astra


IS_WINDOWS = sys.platform == "win32"
IS_MACOS = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")


# ---------------------------------------------------------------------------
# Cross-platform — must pass on all OSes
# ---------------------------------------------------------------------------


async def test_session_creates_and_closes_cleanly(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession() as session:
        async with session.get("example.com") as resp:
            assert resp.status == 200


async def test_https_url_added_on_all_platforms(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession() as session:
        async with session.get("example.com") as resp:
            pass
    assert str(httpx_mock.get_requests()[0].url).startswith("https://")


async def test_headers_sent_on_all_platforms(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession(headers={"X-Platform": sys.platform}) as session:
        async with session.get("example.com") as resp:
            assert resp.status == 200
    assert httpx_mock.get_requests()[0].headers["x-platform"] == sys.platform


async def test_json_round_trip_on_all_platforms(httpx_mock):
    payload = {"unicode": "кириллица", "emoji": "🚀", "crlf": "line\r\nbreak"}
    httpx_mock.add_response(json=payload)
    async with astra.ClientSession() as session:
        async with session.get("example.com") as resp:
            data = resp.json()
    assert data["unicode"] == "кириллица"
    assert data["emoji"] == "🚀"


async def test_error_hierarchy_consistent_on_all_platforms():
    assert issubclass(astra.ConnectionError, astra.NetworkError)
    assert issubclass(astra.TimeoutError, astra.NetworkError)
    assert issubclass(astra.NetworkError, astra.AstraHttpError)
    assert issubclass(astra.HTTPStatusError, astra.AstraHttpError)
    assert issubclass(astra.MissingDependencyError, astra.AstraHttpError)


async def test_asyncio_event_loop_works(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    loop = asyncio.get_event_loop()
    assert loop is not None
    async with astra.ClientSession() as session:
        async with session.get("example.com") as resp:
            assert resp.status == 200


async def test_concurrent_requests_on_all_platforms(httpx_mock):
    for _ in range(4):
        httpx_mock.add_response(json={"ok": True})

    async def fetch(session, path):
        async with session.get(path) as r:
            return r.status

    async with astra.ClientSession() as session:
        results = await asyncio.gather(*[fetch(session, f"example.com/{i}") for i in range(4)])

    assert all(s == 200 for s in results)


# ---------------------------------------------------------------------------
# Windows-specific
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not IS_WINDOWS, reason="Windows only")
async def test_windows_proactor_event_loop_compatible(httpx_mock):
    """httpx must work with ProactorEventLoop (default on Windows)."""
    httpx_mock.add_response(json={"os": "windows"})
    loop = asyncio.get_event_loop()
    assert loop is not None
    async with astra.ClientSession() as session:
        async with session.get("example.com") as resp:
            assert resp.status == 200


@pytest.mark.skipif(not IS_WINDOWS, reason="Windows only")
async def test_windows_url_with_backslash_not_used(httpx_mock):
    """URLs must use forward slashes even on Windows."""
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession(base_url="https://example.com") as session:
        async with session.get("/api/v1/resource") as resp:
            assert resp.status == 200
    url = str(httpx_mock.get_requests()[0].url)
    assert "\\" not in url


@pytest.mark.skipif(not IS_WINDOWS, reason="Windows only")
def test_windows_missing_dep_error_message_readable():
    """Error messages must be ASCII-safe for Windows console."""
    err = astra.MissingDependencyError("pip install astra-client[http2]")
    msg = str(err)
    msg.encode("ascii")  # must not raise


@pytest.mark.skipif(not IS_WINDOWS, reason="Windows only")
async def test_windows_multiple_sessions(httpx_mock):
    httpx_mock.add_response(json={"n": 1})
    httpx_mock.add_response(json={"n": 2})
    async with astra.ClientSession() as s1, astra.ClientSession() as s2:
        async with s1.get("example.com/1") as r1:
            async with s2.get("example.com/2") as r2:
                assert r1.json()["n"] == 1
                assert r2.json()["n"] == 2


# ---------------------------------------------------------------------------
# macOS-specific
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not IS_MACOS, reason="macOS only")
async def test_macos_ssl_default_context_works(httpx_mock):
    """Default SSL context on macOS (uses system keychain) must not break the client."""
    httpx_mock.add_response(json={"os": "macos"})
    async with astra.ClientSession() as session:
        async with session.get("example.com") as resp:
            assert resp.status == 200


@pytest.mark.skipif(not IS_MACOS, reason="macOS only")
async def test_macos_unicode_headers(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    async with astra.ClientSession(headers={"X-App": "astra-client"}) as session:
        async with session.get("example.com") as resp:
            assert resp.status == 200


@pytest.mark.skipif(not IS_MACOS, reason="macOS only")
async def test_macos_concurrent_requests_no_deadlock(httpx_mock):
    for _ in range(8):
        httpx_mock.add_response(json={"ok": True})

    async def fetch(session, i):
        async with session.get(f"example.com/{i}") as r:
            return r.status

    async with astra.ClientSession() as session:
        results = await asyncio.gather(*[fetch(session, i) for i in range(8)])

    assert all(s == 200 for s in results)


@pytest.mark.skipif(not IS_MACOS, reason="macOS only")
def test_macos_platform_detected():
    assert sys.platform == "darwin"


# ---------------------------------------------------------------------------
# Linux-specific
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not IS_LINUX, reason="Linux only")
async def test_linux_selector_event_loop_compatible(httpx_mock):
    """SelectorEventLoop (default on Linux) must work with httpx async client."""
    httpx_mock.add_response(json={"os": "linux"})
    loop = asyncio.get_event_loop()
    assert isinstance(loop, asyncio.SelectorEventLoop)
    async with astra.ClientSession() as session:
        async with session.get("example.com") as resp:
            assert resp.status == 200


@pytest.mark.skipif(not IS_LINUX, reason="Linux only")
async def test_linux_high_concurrency(httpx_mock):
    for _ in range(32):
        httpx_mock.add_response(json={"ok": True})

    async def fetch(session, i):
        async with session.get(f"example.com/{i}") as r:
            return r.status

    async with astra.ClientSession() as session:
        results = await asyncio.gather(*[fetch(session, i) for i in range(32)])

    assert all(s == 200 for s in results)


@pytest.mark.skipif(not IS_LINUX, reason="Linux only")
async def test_linux_all_http_methods(httpx_mock):
    for _ in range(6):
        httpx_mock.add_response(json={"ok": True})

    async with astra.ClientSession() as session:
        async with session.get("example.com") as r:
            assert r.status == 200
        async with session.post("example.com", json={}) as r:
            assert r.status == 200
        async with session.put("example.com", json={}) as r:
            assert r.status == 200
        async with session.patch("example.com", json={}) as r:
            assert r.status == 200
        async with session.delete("example.com") as r:
            assert r.status == 200
        async with session.head("example.com") as r:
            assert r.status == 200


@pytest.mark.skipif(not IS_LINUX, reason="Linux only")
def test_linux_platform_detected():
    assert sys.platform.startswith("linux")
