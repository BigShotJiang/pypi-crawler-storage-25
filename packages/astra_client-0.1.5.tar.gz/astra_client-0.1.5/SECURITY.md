# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| 0.1.x   | ✓         |

## Reporting a Vulnerability

**Do not open a public GitHub issue for security vulnerabilities.**

Email: n7for8572@gmail.com

Include:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (optional)

You will receive a response within 48 hours. If the issue is confirmed, a patch will be released as soon as possible.

## Scope

- Dependency vulnerabilities (e.g. httpx, pydantic) — report upstream first, then here if the issue requires a version bump in astra-client
- Unsafe defaults in `ClientSession` configuration
- Issues allowing SSRF, header injection, or credential leakage through the library API
