# Contributing to astra-client

## Setup

```bash
git clone https://github.com/ndugram/astrahttp
cd astrahttp
pip install -e ".[dev]"
```

## Running Tests

```bash
pytest
```

## Running Linter

```bash
ruff check astra tests
ruff format astra tests
```

## Making Changes

1. Fork the repository
2. Create a branch: `git checkout -b feat/your-feature`
3. Make your changes
4. Add tests for new behavior
5. Run tests and linter — both must pass
6. Open a pull request against `master`

## Pull Request Guidelines

- Keep PRs focused — one feature or fix per PR
- Update examples if you add or change public API
- Do not bump the version — maintainer handles releases

## Code Style

- Python 3.10+ syntax
- Type annotations required on all public functions
- No comments explaining *what* the code does — only *why* when non-obvious
- Line length: 100 characters (enforced by ruff)

## Adding Examples

Put new examples under `examples/<category>/`. Use `httpbin.org` or `jsonplaceholder.typicode.com` as test endpoints — no external accounts required.

## Reporting Issues

Open a GitHub issue with:
- Python version
- astra-client version
- Minimal reproducible example
- Expected vs actual behavior
