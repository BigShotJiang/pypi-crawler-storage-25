from __future__ import annotations

from collections.abc import Iterator
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from astra.response import Response


class BaseMiddleware:
    """Base class for all astra middleware.

    Subclass this and override :meth:`request` and/or :meth:`response`
    to intercept or modify requests and responses.

    Class attributes:

    - ``__return_type__``: expected type this middleware operates on.
    - ``__priority__``: execution order — lower value runs first.
    - ``__methods__``: list of HTTP methods to apply to (``None`` = all).
    - ``__enabled__``: set to ``False`` to skip without removing from chain.
    """

    __return_type__: type | None
    __priority__: int
    __methods__: list[str] | None
    __enabled__: bool

    def __repr__(self) -> str:
        return_type = getattr(self, "__return_type__", None)
        return f"<{self.__class__.__name__} return_type={return_type}>"

    def __or__(self, other: BaseMiddleware) -> MiddlewareChain:
        """Combine two middleware into a :class:`MiddlewareChain` via ``|``."""
        return MiddlewareChain([self, other])

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)

    async def request(
        self,
        method: str,
        url: str,
        kwargs: dict[str, Any],
    ) -> dict[str, Any]:
        """Called before the HTTP request is sent.

        :param method: HTTP method (``GET``, ``POST``, etc.).
        :param url: Resolved request URL.
        :param kwargs: Request keyword arguments (headers, params, json, etc.).
        :return: Modified ``kwargs`` dict passed to the next middleware or httpx.
        """
        return kwargs

    async def response(self, response: Response) -> Response:
        """Called after the HTTP response is received.

        :param response: Wrapped :class:`~astra.response.Response` object.
        :return: Modified or replaced response passed back up the chain.
        """
        return response


class MiddlewareChain:
    """Ordered chain of :class:`BaseMiddleware` instances.

    Created via the ``|`` operator on middleware objects.
    Passed directly to :class:`~astra.client.ClientSession` as ``middleware=``.
    """

    def __init__(self, middlewares: list[BaseMiddleware]) -> None:
        self._middlewares = middlewares

    def __or__(self, other: BaseMiddleware) -> MiddlewareChain:
        """Append another middleware to the chain via ``|``."""
        return MiddlewareChain([*self._middlewares, other])

    def __repr__(self) -> str:
        names = ", ".join(m.__class__.__name__ for m in self._middlewares)
        return f"<MiddlewareChain [{names}]>"

    def __iter__(self) -> Iterator[BaseMiddleware]:
        return iter(self._middlewares)

    def __len__(self) -> int:
        return len(self._middlewares)
