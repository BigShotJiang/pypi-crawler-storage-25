async def check_https_url(*, url: str) -> str:
    """Ensure URL has an HTTP scheme, defaulting to HTTPS.

    Allows users to pass bare URLs like ``"google.com"`` instead of
    ``"https://google.com"``. If the URL already has a scheme
    (``http://`` or ``https://``), it is returned unchanged.

    Args:
        url: Raw URL string, with or without scheme.

    Returns:
        URL guaranteed to start with ``http://`` or ``https://``.

    Examples:
        >>> await check_https_url(url="google.com")
        'https://google.com'
        >>> await check_https_url(url="https://google.com")
        'https://google.com'
        >>> await check_https_url(url="http://example.com")
        'http://example.com'
    """
    url = url.strip()
    if url.startswith(("https://", "http://")):
        return url
    return f"https://{url}"
