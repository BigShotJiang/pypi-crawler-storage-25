import httpx
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from pydantic import BaseModel


class Response:
    """Wraps an httpx response with a simplified async interface.

    Args:
        raw_response: The underlying :class:`httpx.Response` object.
        response_model: Optional Pydantic model class to validate JSON against.

    Attributes:
        status: HTTP status code.
        headers: Response headers.
    """

    def __init__(
        self,
        raw_response: httpx.Response,
        response_model: "type[BaseModel] | None" = None,
    ) -> None:
        self._raw = raw_response
        self._response_model = response_model
        self.status: int = raw_response.status_code
        self.headers: httpx.Headers = raw_response.headers

    def text(self) -> str:
        """Return response body decoded as text."""
        return self._raw.text

    def json(self) -> Any:
        """Return response body parsed as JSON, validated against response_model if set."""
        data = self._raw.json()
        if self._response_model is not None:
            return self._response_model.model_validate(data)
        return data

    def read(self) -> bytes:
        """Return raw response body as bytes."""
        return self._raw.content

    async def close(self) -> None:
        """Close the underlying response and release the connection."""
        await self._raw.aclose()
