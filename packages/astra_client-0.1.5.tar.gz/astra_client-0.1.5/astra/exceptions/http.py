from .base import AstraHttpError


class HTTPStatusError(AstraHttpError):
    """Raised when server returns a non-2xx response.

    Args:
        message: Human-readable description.
        status_code: HTTP status code from the response.
    """

    def __init__(self, message: str, *, status_code: int) -> None:
        super().__init__(message)
        self.status_code = status_code

    def __str__(self) -> str:
        return f"[{self.status_code}] {super().__str__()}"


# ── 4xx Client Errors ────────────────────────────────────────────────────────

class ClientError(HTTPStatusError):
    """Raised for 4xx responses — request was invalid or unauthorized."""


class BadRequestError(ClientError):
    """400 Bad Request — server could not parse the request."""


class UnauthorizedError(ClientError):
    """401 Unauthorized — valid credentials required."""


class ForbiddenError(ClientError):
    """403 Forbidden — server understood the request but refuses to fulfill it."""


class NotFoundError(ClientError):
    """404 Not Found — requested resource does not exist."""


class MethodNotAllowedError(ClientError):
    """405 Method Not Allowed — HTTP method not supported for this endpoint."""


class UnprocessableEntityError(ClientError):
    """422 Unprocessable Entity — request was well-formed but semantically invalid."""


class TooManyRequestsError(ClientError):
    """429 Too Many Requests — rate limit exceeded."""


# ── 5xx Server Errors ────────────────────────────────────────────────────────

class ServerError(HTTPStatusError):
    """Raised for 5xx responses — server failed to fulfill a valid request."""


class InternalServerError(ServerError):
    """500 Internal Server Error — unexpected server-side failure."""


class BadGatewayError(ServerError):
    """502 Bad Gateway — upstream server returned an invalid response."""


class ServiceUnavailableError(ServerError):
    """503 Service Unavailable — server is temporarily overloaded or down."""


class GatewayTimeoutError(ServerError):
    """504 Gateway Timeout — upstream server did not respond in time."""


# ── Status code → exception mapping ─────────────────────────────────────────

_STATUS_MAP: dict[int, type[HTTPStatusError]] = {
    400: BadRequestError,
    401: UnauthorizedError,
    403: ForbiddenError,
    404: NotFoundError,
    405: MethodNotAllowedError,
    422: UnprocessableEntityError,
    429: TooManyRequestsError,
    500: InternalServerError,
    502: BadGatewayError,
    503: ServiceUnavailableError,
    504: GatewayTimeoutError,
}


def raise_for_status(status_code: int, reason: str) -> None:
    """Raise the appropriate :class:`HTTPStatusError` subclass for a given status code.

    Falls back to :class:`ClientError` for unknown 4xx and :class:`ServerError`
    for unknown 5xx. Does nothing for 1xx–3xx codes.

    Args:
        status_code: HTTP status code from the response.
        reason: Short description from the response (e.g. ``"Not Found"``).

    Raises:
        HTTPStatusError: Subclass matching the status code.
    """
    if status_code < 400:
        return

    exc_class = _STATUS_MAP.get(status_code)

    if exc_class is None:
        exc_class = ClientError if status_code < 500 else ServerError

    raise exc_class(reason, status_code=status_code)
