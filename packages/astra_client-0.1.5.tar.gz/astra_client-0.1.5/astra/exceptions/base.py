class AstraHttpError(Exception):
    """Root exception for all astrahttp errors.

    Catch this to handle any error raised by the library.
    """


class MissingDependencyError(AstraHttpError):
    """Raised when an optional dependency required for a feature is not installed."""
