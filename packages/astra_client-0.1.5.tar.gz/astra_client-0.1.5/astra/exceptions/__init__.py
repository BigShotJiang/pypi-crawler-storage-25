from .base import AstraHttpError, MissingDependencyError
from .network import (
    NetworkError,
    ConnectionError,
    TimeoutError,
    TooManyRedirectsError,
    InvalidURLError,
)
from .http import (
    HTTPStatusError,
    ClientError,
    BadRequestError,
    UnauthorizedError,
    ForbiddenError,
    NotFoundError,
    MethodNotAllowedError,
    UnprocessableEntityError,
    TooManyRequestsError,
    ServerError,
    InternalServerError,
    BadGatewayError,
    ServiceUnavailableError,
    GatewayTimeoutError,
    raise_for_status,
)

__all__ = [
    "AstraHttpError",
    "MissingDependencyError",
    # network
    "NetworkError",
    "ConnectionError",
    "TimeoutError",
    "TooManyRedirectsError",
    "InvalidURLError",
    # http status
    "HTTPStatusError",
    "ClientError",
    "BadRequestError",
    "UnauthorizedError",
    "ForbiddenError",
    "NotFoundError",
    "MethodNotAllowedError",
    "UnprocessableEntityError",
    "TooManyRequestsError",
    "ServerError",
    "InternalServerError",
    "BadGatewayError",
    "ServiceUnavailableError",
    "GatewayTimeoutError",
    "raise_for_status",
]
