from .base import AstraHttpError


class NetworkError(AstraHttpError):
    """Raised when a network-level failure occurs before a response is received."""


class ConnectionError(NetworkError):
    """Raised when a connection to the server cannot be established."""


class TimeoutError(NetworkError):
    """Raised when a request exceeds the configured timeout."""


class TooManyRedirectsError(NetworkError):
    """Raised when the server returns more redirects than the client allows."""


class InvalidURLError(AstraHttpError):
    """Raised when the provided URL is malformed or cannot be resolved."""
