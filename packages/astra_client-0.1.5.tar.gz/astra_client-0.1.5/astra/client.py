import httpx
from typing import Any, TYPE_CHECKING
from .response import Response
from .helpers.routing import check_https_url
from .exceptions import (
    ConnectionError,
    TimeoutError,
    TooManyRedirectsError,
    InvalidURLError,
    NetworkError,
    MissingDependencyError,
    raise_for_status,
)
from .middleware.base import BaseMiddleware, MiddlewareChain

if TYPE_CHECKING:
    from pydantic import BaseModel


RequestData = dict[str, Any] | str | bytes


class ClientSession:
    """Async HTTP client session wrapping httpx.AsyncClient.

    Supports context manager usage and provides shorthand methods
    for common HTTP verbs. Each method returns a context manager
    that yields a :class:`Response`.

    Args:
        base_url: Optional base URL prepended to all requests.
        headers: Default headers sent with every request.
        timeout: Default timeout in seconds for all requests.
        response_model: Optional Pydantic model class. When set, ``response.json()``
            returns a validated model instance instead of raw data.
    """

    def __init__(
        self,
        base_url: str | None = None,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
        response_model: "type[BaseModel] | None" = None,
        http2: bool = False,
        middleware: list[BaseMiddleware] | MiddlewareChain | None = None,
    ) -> None:
        if http2:
            try:
                import h2  # noqa: F401
            except ImportError:
                raise MissingDependencyError(
                    "HTTP/2 support requires the 'h2' package. "
                    "Install it with: pip install astra-client[http2]"
                ) from None
        self._client = httpx.AsyncClient(
            base_url=base_url or "",
            headers=headers or {},
            timeout=timeout,
            http2=http2,
        )
        self._response_model = response_model
        self._middleware: list[BaseMiddleware] = list(middleware) if middleware is not None else []

    async def __aenter__(self) -> "ClientSession":
        await self._client.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:  # noqa: ANN001
        await self._client.__aexit__(exc_type, exc, tb)

    def request(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        json: Any | None = None,
        data: RequestData | None = None,
        timeout: float | None = None,
        response_model: "type[BaseModel] | None" = None,
    ) -> "_RequestContext":
        """Build a request context manager for the given method and URL.

        Args:
            method: HTTP method (GET, POST, etc.).
            url: Target URL, absolute or relative to ``base_url``.
            params: Query string parameters.
            headers: Request-specific headers, merged with session defaults.
            json: JSON-serializable body. Sets Content-Type to application/json.
            data: Raw body as dict, str, or bytes.
            timeout: Per-request timeout override in seconds.
            response_model: Pydantic model override for this request only.

        Returns:
            Async context manager that yields a :class:`Response`.
        """
        return _RequestContext(
            self._client,
            method,
            url,
            params=params,
            headers=headers,
            json=json,
            data=data,
            timeout=timeout,
            response_model=response_model or self._response_model,
            middleware=self._middleware,
        )

    def get(
        self,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
        response_model: "type[BaseModel] | None" = None,
    ) -> "_RequestContext":
        """Send a GET request.

        Args:
            url: Target URL.
            params: Query string parameters.
            headers: Request-specific headers.
            timeout: Timeout override in seconds.
            response_model: Pydantic model override for this request only.
        """
        return self.request("GET", url, params=params, headers=headers, timeout=timeout, response_model=response_model)

    def post(
        self,
        url: str,
        *,
        json: Any | None = None,
        data: RequestData | None = None,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
        response_model: "type[BaseModel] | None" = None,
    ) -> "_RequestContext":
        """Send a POST request.

        Args:
            url: Target URL.
            json: JSON body.
            data: Raw body.
            headers: Request-specific headers.
            timeout: Timeout override in seconds.
            response_model: Pydantic model override for this request only.
        """
        return self.request("POST", url, json=json, data=data, headers=headers, timeout=timeout, response_model=response_model)

    def put(
        self,
        url: str,
        *,
        json: Any | None = None,
        data: RequestData | None = None,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
        response_model: "type[BaseModel] | None" = None,
    ) -> "_RequestContext":
        """Send a PUT request.

        Args:
            url: Target URL.
            json: JSON body.
            data: Raw body.
            headers: Request-specific headers.
            timeout: Timeout override in seconds.
            response_model: Pydantic model override for this request only.
        """
        return self.request("PUT", url, json=json, data=data, headers=headers, timeout=timeout, response_model=response_model)

    def patch(
        self,
        url: str,
        *,
        json: Any | None = None,
        data: RequestData | None = None,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
        response_model: "type[BaseModel] | None" = None,
    ) -> "_RequestContext":
        """Send a PATCH request.

        Args:
            url: Target URL.
            json: JSON body.
            data: Raw body.
            headers: Request-specific headers.
            timeout: Timeout override in seconds.
            response_model: Pydantic model override for this request only.
        """
        return self.request("PATCH", url, json=json, data=data, headers=headers, timeout=timeout, response_model=response_model)

    def delete(
        self,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
        response_model: "type[BaseModel] | None" = None,
    ) -> "_RequestContext":
        """Send a DELETE request.

        Args:
            url: Target URL.
            headers: Request-specific headers.
            timeout: Timeout override in seconds.
            response_model: Pydantic model override for this request only.
        """
        return self.request("DELETE", url, headers=headers, timeout=timeout, response_model=response_model)

    def head(
        self,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
        response_model: "type[BaseModel] | None" = None,
    ) -> "_RequestContext":
        """Send a HEAD request.

        Args:
            url: Target URL.
            headers: Request-specific headers.
            timeout: Timeout override in seconds.
            response_model: Pydantic model override for this request only.
        """
        return self.request("HEAD", url, headers=headers, timeout=timeout, response_model=response_model)

    def options(
        self,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
        response_model: "type[BaseModel] | None" = None,
    ) -> "_RequestContext":
        """Send an OPTIONS request.

        Args:
            url: Target URL.
            headers: Request-specific headers.
            timeout: Timeout override in seconds.
            response_model: Pydantic model override for this request only.
        """
        return self.request("OPTIONS", url, headers=headers, timeout=timeout, response_model=response_model)


class _RequestContext:
    """Async context manager that executes an HTTP request on enter.

    Returned by :meth:`ClientSession.request` and its shorthand methods.
    Yields a :class:`Response` on ``__aenter__`` and closes it on ``__aexit__``.
    """

    def __init__(
        self,
        client: httpx.AsyncClient,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        json: Any | None = None,
        data: RequestData | None = None,
        timeout: float | None = None,
        response_model: "type[BaseModel] | None" = None,
        middleware: list[BaseMiddleware] | None = None,
    ) -> None:
        self._client = client
        self._method = method
        self._url = url
        self._params = params
        self._headers = headers
        self._json = json
        self._data: Any = data
        self._timeout = timeout
        self._response_model = response_model
        self._response: Response | None = None
        self._middleware = middleware or []

    def _active_middleware(self) -> list[BaseMiddleware]:
        active = []
        for mw in self._middleware:
            if hasattr(mw, "__enabled__") and not mw.__enabled__:
                continue
            if hasattr(mw, "__methods__") and mw.__methods__ is not None:
                if self._method.upper() not in [m.upper() for m in mw.__methods__]:
                    continue
            active.append(mw)
        active.sort(key=lambda m: getattr(m, "__priority__", 0))
        return active

    async def __aenter__(self) -> Response:
        url = await check_https_url(url=self._url)
        active = self._active_middleware()

        kwargs: dict[str, Any] = {
            "params": self._params,
            "headers": self._headers,
            "json": self._json,
            "data": self._data,
            "timeout": self._timeout,
        }
        for mw in active:
            kwargs = await mw.request(self._method, url, kwargs)

        try:
            resp = await self._client.request(self._method, url, **kwargs)
        except httpx.TimeoutException as e:
            raise TimeoutError(str(e)) from e
        except httpx.TooManyRedirects as e:
            raise TooManyRedirectsError(str(e)) from e
        except httpx.InvalidURL as e:
            raise InvalidURLError(str(e)) from e
        except httpx.ConnectError as e:
            raise ConnectionError(str(e)) from e
        except httpx.NetworkError as e:
            raise NetworkError(str(e)) from e

        raise_for_status(resp.status_code, resp.reason_phrase)
        self._response = Response(resp, response_model=self._response_model)

        for mw in reversed(active):
            self._response = await mw.response(self._response)

        return self._response

    async def __aexit__(self, exc_type, exc, tb) -> None:  # noqa: ANN001
        assert self._response is not None
        await self._response.close()
