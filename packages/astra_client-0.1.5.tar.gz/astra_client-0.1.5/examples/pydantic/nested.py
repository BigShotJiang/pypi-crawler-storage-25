import asyncio

import astra
from pydantic import BaseModel


class Headers(BaseModel):
    host: str
    user_agent: str = ""

    class Config:
        populate_by_name = True
        extra = "allow"


class GetResponse(BaseModel):
    args: dict[str, str]
    headers: Headers
    origin: str
    url: str


async def main() -> None:
    async with astra.ClientSession(response_model=GetResponse) as session:
        async with session.get("httpbin.org/get", params={"foo": "bar"}) as response:
            data: GetResponse = response.json()
            print(data.url)
            print(data.args)
            print(data.headers.host)


asyncio.run(main())
