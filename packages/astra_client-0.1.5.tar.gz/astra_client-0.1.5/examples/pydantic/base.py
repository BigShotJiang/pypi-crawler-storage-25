import asyncio

import astra
from pydantic import BaseModel


class GetResponse(BaseModel):
    origin: str
    url: str


async def main() -> None:
    async with astra.ClientSession(response_model=GetResponse) as session:
        async with session.get("httpbin.org/get") as response:
            data: GetResponse = response.json()
            print(data.origin)
            print(data.url)


asyncio.run(main())
