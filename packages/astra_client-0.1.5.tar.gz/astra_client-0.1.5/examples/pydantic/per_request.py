import asyncio

import astra
from pydantic import BaseModel


class GetResponse(BaseModel):
    origin: str
    url: str


class PostResponse(BaseModel):
    url: str
    json: dict


async def main() -> None:
    async with astra.ClientSession() as session:
        async with session.get("httpbin.org/get", response_model=GetResponse) as response:
            get_data: GetResponse = response.json()
            print("GET origin:", get_data.origin)

        async with session.post(
            "httpbin.org/post",
            json={"key": "value"},
            response_model=PostResponse,
        ) as response:
            post_data: PostResponse = response.json()
            print("POST json:", post_data.json)


asyncio.run(main())
