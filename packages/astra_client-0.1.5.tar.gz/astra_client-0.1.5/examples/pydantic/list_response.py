import asyncio

import astra
from pydantic import BaseModel


class Todo(BaseModel):
    userId: int
    id: int
    title: str
    completed: bool


async def main() -> None:
    async with astra.ClientSession() as session:
        async with session.get("jsonplaceholder.typicode.com/todos") as response:
            raw: list[dict] = response.json()
            todos = [Todo.model_validate(item) for item in raw]
            for todo in todos[:5]:
                print(f"[{'x' if todo.completed else ' '}] {todo.title}")


asyncio.run(main())
