import asyncio

import astra
from pydantic import BaseModel, Field


class Args(BaseModel):
    page: str = Field(alias="page", default="1")
    limit: str = Field(alias="limit", default="10")


class Response(BaseModel):
    args: Args
    url: str


async def main() -> None:
    async with astra.ClientSession(response_model=Response) as session:
        async with session.get(
            "httpbin.org/get",
            params={"page": "2", "limit": "5"},
        ) as response:
            data: Response = response.json()
            print(f"page={data.args.page} limit={data.args.limit}")
            print(data.url)


asyncio.run(main())
