import asyncio
from typing import Optional

import astra
from pydantic import BaseModel, Field


class Post(BaseModel):
    id: int
    title: str
    body: str
    userId: int
    tags: Optional[list[str]] = Field(default_factory=list)
    views: Optional[int] = None


async def main() -> None:
    async with astra.ClientSession(response_model=Post) as session:
        async with session.get("jsonplaceholder.typicode.com/posts/1") as response:
            post: Post = response.json()
            print(post.title)
            print(f"tags: {post.tags}")
            print(f"views: {post.views}")


asyncio.run(main())
