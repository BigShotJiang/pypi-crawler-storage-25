import asyncio

import astra
from pydantic import BaseModel


class CreatePostRequest(BaseModel):
    title: str
    body: str
    userId: int


class CreatePostResponse(BaseModel):
    id: int
    title: str
    body: str
    userId: int


async def main() -> None:
    payload = CreatePostRequest(title="Hello", body="World", userId=1)

    async with astra.ClientSession(response_model=CreatePostResponse) as session:
        async with session.post(
            "jsonplaceholder.typicode.com/posts",
            json=payload.model_dump(),
        ) as response:
            post: CreatePostResponse = response.json()
            print(f"created post id={post.id}: {post.title}")


asyncio.run(main())
