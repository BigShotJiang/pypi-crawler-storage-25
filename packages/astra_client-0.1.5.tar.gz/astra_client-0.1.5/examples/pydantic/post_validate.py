import asyncio

import astra
from pydantic import BaseModel


class PostBody(BaseModel):
    username: str
    score: int


class PostResponse(BaseModel):
    json: PostBody
    url: str


async def main() -> None:
    payload = {"username": "astra", "score": 42}

    async with astra.ClientSession() as session:
        async with session.post(
            "httpbin.org/post",
            json=payload,
            response_model=PostResponse,
        ) as response:
            data: PostResponse = response.json()
            print(data.json.username)
            print(data.json.score)
            print(data.url)


asyncio.run(main())
