import asyncio

import astra
from pydantic import BaseModel, ValidationError


class StrictResponse(BaseModel):
    id: int
    name: str
    email: str


async def main() -> None:
    async with astra.ClientSession() as session:
        try:
            async with session.get(
                "httpbin.org/get",
                response_model=StrictResponse,
            ) as response:
                data = response.json()
                print(data)
        except ValidationError as e:
            print("Validation failed:")
            for err in e.errors():
                print(f"  {err['loc']} — {err['msg']}")
        except astra.NetworkError as e:
            print("Network error:", e)


asyncio.run(main())
