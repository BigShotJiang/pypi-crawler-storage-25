import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession() as session:
        try:
            async with session.get("https://this-host-does-not-exist.invalid/path") as response:
                print(response.status)
        except astra.ConnectionError as e:
            print(f"connection failed: {e}")
        except astra.NetworkError as e:
            print(f"network error: {e}")

        try:
            async with session.get("httpbin.org/delay/10", timeout=1.0) as response:
                print(response.status)
        except astra.TimeoutError as e:
            print(f"timed out: {e}")

        try:
            async with session.get("https://httpbin.org/absolute-redirect/10") as response:
                print(response.status)
        except astra.TooManyRedirectsError as e:
            print(f"too many redirects: {e}")


asyncio.run(main())
