import asyncio

import astra


STATUS_CODES = [400, 401, 403, 404, 405, 422, 429, 500, 502, 503, 504]


async def main() -> None:
    async with astra.ClientSession(base_url="https://httpbin.org") as session:
        for code in STATUS_CODES:
            try:
                async with session.get(f"/status/{code}") as response:
                    print(f"{code}: ok ({response.status})")
            except astra.BadRequestError:
                print(f"{code}: bad request")
            except astra.UnauthorizedError:
                print(f"{code}: unauthorized")
            except astra.ForbiddenError:
                print(f"{code}: forbidden")
            except astra.NotFoundError:
                print(f"{code}: not found")
            except astra.MethodNotAllowedError:
                print(f"{code}: method not allowed")
            except astra.UnprocessableEntityError:
                print(f"{code}: unprocessable entity")
            except astra.TooManyRequestsError:
                print(f"{code}: rate limited")
            except astra.InternalServerError:
                print(f"{code}: internal server error")
            except astra.BadGatewayError:
                print(f"{code}: bad gateway")
            except astra.ServiceUnavailableError:
                print(f"{code}: service unavailable")
            except astra.GatewayTimeoutError:
                print(f"{code}: gateway timeout")
            except astra.HTTPStatusError as e:
                print(f"{code}: http error — {e}")


asyncio.run(main())
