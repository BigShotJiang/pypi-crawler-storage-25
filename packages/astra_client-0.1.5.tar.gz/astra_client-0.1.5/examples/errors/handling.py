import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession() as session:
        try:
            async with session.get("httpbin.org/status/404") as response:
                print(response.status)
        except astra.NotFoundError:
            print("404 — resource not found")
        except astra.UnauthorizedError:
            print("401 — invalid credentials")
        except astra.TooManyRequestsError:
            print("429 — rate limit exceeded")
        except astra.TimeoutError:
            print("request timed out")
        except astra.ConnectionError:
            print("could not reach the server")
        except astra.AstraHttpError as e:
            print(f"error: {e}")


asyncio.run(main())
