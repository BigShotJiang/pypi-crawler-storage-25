import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession(base_url="https://httpbin.org") as session:
        try:
            async with session.get("/status/500") as response:
                print(response.status)
        except astra.InternalServerError:
            print("server crashed, retry later")

        try:
            async with session.get("/status/503") as response:
                print(response.status)
        except astra.ServiceUnavailableError:
            print("service down, retry later")

        try:
            async with session.get("/status/504") as response:
                print(response.status)
        except astra.GatewayTimeoutError:
            print("upstream timed out")

        try:
            async with session.get("/status/502") as response:
                print(response.status)
        except astra.BadGatewayError:
            print("bad gateway")


asyncio.run(main())
