import asyncio

import astra


async def main() -> None:
    try:
        async with astra.ClientSession(http2=True) as session:
            async with session.get("https://httpbin.org/get") as response:
                print(response.status)
    except astra.MissingDependencyError as e:
        print(f"install error: {e}")


asyncio.run(main())
