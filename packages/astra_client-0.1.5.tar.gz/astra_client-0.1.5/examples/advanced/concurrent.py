import asyncio

import astra


async def fetch(session: astra.ClientSession, post_id: int) -> dict:
    async with session.get(f"/posts/{post_id}") as response:
        return response.json()


async def main() -> None:
    async with astra.ClientSession(base_url="https://jsonplaceholder.typicode.com") as session:
        tasks = [fetch(session, i) for i in range(1, 11)]
        results = await asyncio.gather(*tasks)
        for post in results:
            print(f"[{post['id']}] {post['title']}")


asyncio.run(main())
