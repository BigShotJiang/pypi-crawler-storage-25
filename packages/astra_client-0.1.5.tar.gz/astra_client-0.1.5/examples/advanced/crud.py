import asyncio

import astra


BASE = "https://jsonplaceholder.typicode.com"


async def create_post(session: astra.ClientSession, title: str, body: str) -> dict:
    async with session.post("/posts", json={"title": title, "body": body, "userId": 1}) as r:
        return r.json()


async def read_post(session: astra.ClientSession, post_id: int) -> dict:
    async with session.get(f"/posts/{post_id}") as r:
        return r.json()


async def update_post(session: astra.ClientSession, post_id: int, title: str) -> dict:
    async with session.put(f"/posts/{post_id}", json={"title": title, "body": "updated", "userId": 1}) as r:
        return r.json()


async def patch_post(session: astra.ClientSession, post_id: int, title: str) -> dict:
    async with session.patch(f"/posts/{post_id}", json={"title": title}) as r:
        return r.json()


async def delete_post(session: astra.ClientSession, post_id: int) -> None:
    async with session.delete(f"/posts/{post_id}"):
        pass


async def main() -> None:
    async with astra.ClientSession(base_url=BASE) as session:
        post = await create_post(session, "Test Title", "Test Body")
        print(f"created: id={post['id']}")

        fetched = await read_post(session, 1)
        print(f"read: {fetched['title']}")

        updated = await update_post(session, 1, "Updated Title")
        print(f"put: {updated['title']}")

        patched = await patch_post(session, 1, "Patched Title")
        print(f"patch: {patched['title']}")

        await delete_post(session, 1)
        print("deleted post 1")


asyncio.run(main())
