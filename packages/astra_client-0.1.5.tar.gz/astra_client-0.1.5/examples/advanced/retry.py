import asyncio

import astra


async def get_with_retry(
    session: astra.ClientSession,
    url: str,
    retries: int = 3,
    delay: float = 1.0,
) -> dict:
    for attempt in range(1, retries + 1):
        try:
            async with session.get(url) as response:
                return response.json()
        except (astra.ServerError, astra.TimeoutError, astra.NetworkError) as e:
            if attempt == retries:
                raise
            print(f"attempt {attempt} failed: {e}, retrying in {delay}s...")
            await asyncio.sleep(delay)
    raise RuntimeError("unreachable")


async def main() -> None:
    async with astra.ClientSession(base_url="https://httpbin.org") as session:
        try:
            data = await get_with_retry(session, "/get", retries=3)
            print(data["url"])
        except astra.AstraHttpError as e:
            print(f"all retries exhausted: {e}")


asyncio.run(main())
