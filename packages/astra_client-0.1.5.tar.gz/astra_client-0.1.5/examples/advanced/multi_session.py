import asyncio

import astra


async def fetch_posts(session: astra.ClientSession) -> list[dict]:
    async with session.get("/posts/1") as response:
        return [response.json()]


async def fetch_users(session: astra.ClientSession) -> list[dict]:
    async with session.get("/users/1") as response:
        return [response.json()]


async def main() -> None:
    async with (
        astra.ClientSession(base_url="https://jsonplaceholder.typicode.com") as posts_session,
        astra.ClientSession(base_url="https://jsonplaceholder.typicode.com") as users_session,
    ):
        posts, users = await asyncio.gather(
            fetch_posts(posts_session),
            fetch_users(users_session),
        )
        print("posts:", [p["title"] for p in posts])
        print("users:", [u["name"] for u in users])


asyncio.run(main())
