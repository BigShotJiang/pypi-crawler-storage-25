import asyncio

import astra


async def fetch_all_pages(
    session: astra.ClientSession,
    path: str,
    page_size: int = 10,
    max_pages: int = 3,
) -> list[dict]:
    items: list[dict] = []
    for page in range(1, max_pages + 1):
        async with session.get(path, params={"_page": str(page), "_limit": str(page_size)}) as response:
            page_data: list[dict] = response.json()
            if not page_data:
                break
            items.extend(page_data)
            print(f"fetched page {page}: {len(page_data)} items")
    return items


async def main() -> None:
    async with astra.ClientSession(base_url="https://jsonplaceholder.typicode.com") as session:
        posts = await fetch_all_pages(session, "/posts", page_size=5, max_pages=3)
        print(f"total fetched: {len(posts)}")
        for post in posts[:3]:
            print(f"  [{post['id']}] {post['title']}")


asyncio.run(main())
