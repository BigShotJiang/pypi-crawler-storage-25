import asyncio

import astra


async def fetch(session: astra.ClientSession, path: str) -> dict:
    async with session.get(path) as response:
        return response.json()


async def main() -> None:
    async with astra.ClientSession(
        base_url="https://httpbin.org",
        http2=True,
    ) as session:
        paths = ["/get", "/uuid", "/ip", "/user-agent", "/headers"]
        tasks = [fetch(session, path) for path in paths]
        results = await asyncio.gather(*tasks)
        for path, result in zip(paths, results):
            print(f"{path}: {list(result.keys())}")


asyncio.run(main())
