import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession(base_url="https://httpbin.org", timeout=30.0) as session:
        async with session.get("/get", timeout=5.0) as response:
            print(f"fast endpoint: {response.status}")

        try:
            async with session.get("/delay/3", timeout=1.0) as response:
                print(response.status)
        except astra.TimeoutError:
            print("slow endpoint timed out after 1s (session default is 30s)")

        async with session.get("/delay/1") as response:
            print(f"used session timeout: {response.status}")


asyncio.run(main())
