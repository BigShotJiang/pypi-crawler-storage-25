import asyncio

import astra


async def fetch_user(session: astra.ClientSession, user_id: int) -> dict:
    async with session.get(f"/users/{user_id}") as response:
        return response.json()


async def main() -> None:
    async with astra.ClientSession(base_url="https://jsonplaceholder.typicode.com") as session:
        for user_id in range(1, 4):
            data = await fetch_user(session, user_id)
            print(data)


asyncio.run(main())
