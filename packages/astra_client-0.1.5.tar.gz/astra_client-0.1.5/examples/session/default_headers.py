import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession(
        base_url="https://httpbin.org",
        headers={
            "User-Agent": "astra-client/1.0",
            "Accept": "application/json",
            "X-Request-ID": "abc-123",
        },
    ) as session:
        async with session.get("/headers") as response:
            print(response.status)
            data = response.json()
            print(data["headers"])


asyncio.run(main())
