import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession(timeout=3.0) as session:
        try:
            async with session.get("httpbin.org/delay/10") as response:
                print(response.status)
        except astra.TimeoutError:
            print("timed out after 3 seconds")


asyncio.run(main())
