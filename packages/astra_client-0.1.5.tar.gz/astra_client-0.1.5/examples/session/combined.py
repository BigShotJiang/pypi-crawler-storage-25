import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession(
        base_url="https://httpbin.org",
        headers={"Authorization": "Bearer my-token", "X-App": "demo"},
        timeout=10.0,
    ) as session:
        async with session.get("/get", params={"q": "hello"}) as response:
            print(response.status)
            print(response.json())

        async with session.post("/post", json={"x": 1}) as response:
            print(response.status)
            print(response.json())

        async with session.delete("/delete") as response:
            print(response.status)


asyncio.run(main())
