import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession(base_url="https://httpbin.org") as session:
        async with session.get("/get") as response:
            print(response.status)
            print(response.json())

        async with session.post("/post", json={"key": "value"}) as response:
            print(response.status)
            print(response.json())


asyncio.run(main())
