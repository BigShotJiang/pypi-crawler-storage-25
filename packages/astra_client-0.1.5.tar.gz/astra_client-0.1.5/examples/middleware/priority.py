import asyncio
import astra
from astra.middleware import BaseMiddleware


class FirstMiddleware(BaseMiddleware):
    __return_type__ = bool
    __priority__ = 1
    __methods__ = None
    __enabled__ = True

    async def request(self, method, url, kwargs):
        print("[1] request")
        return kwargs

    async def response(self, response):
        print("[1] response")
        return response


class SecondMiddleware(BaseMiddleware):
    __return_type__ = bool
    __priority__ = 2
    __methods__ = None
    __enabled__ = True

    async def request(self, method, url, kwargs):
        print("[2] request")
        return kwargs

    async def response(self, response):
        print("[2] response")
        return response


class ThirdMiddleware(BaseMiddleware):
    __return_type__ = bool
    __priority__ = 3
    __methods__ = None
    __enabled__ = True

    async def request(self, method, url, kwargs):
        print("[3] request")
        return kwargs

    async def response(self, response):
        print("[3] response")
        return response


async def main():
    # order in list doesn't matter — sorted by __priority__
    async with astra.ClientSession(
        middleware=[ThirdMiddleware(), FirstMiddleware(), SecondMiddleware()],
    ) as session:
        async with session.get("httpbin.org/get") as resp:
            print("status:", resp.status)

    # expected output:
    # [1] request
    # [2] request
    # [3] request
    # ← HTTP response
    # [3] response
    # [2] response
    # [1] response


asyncio.run(main())
