import asyncio
import astra
from astra.middleware import BaseMiddleware


class LoggingMiddleware(BaseMiddleware):
    __return_type__ = None
    __priority__ = 0
    __methods__ = None
    __enabled__ = True

    async def request(self, method, url, kwargs):
        print(f"[LOG] → {method} {url}")
        return kwargs

    async def response(self, response):
        print(f"[LOG] ← {response.status}")
        return response


async def main():
    async with astra.ClientSession(
        middleware=[LoggingMiddleware()],
    ) as session:
        async with session.get("httpbin.org/get") as resp:
            print(resp.json())


asyncio.run(main())
