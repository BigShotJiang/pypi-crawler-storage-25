import asyncio
import astra
from astra.middleware import BaseMiddleware


class DebugMiddleware(BaseMiddleware):
    __return_type__ = None
    __priority__ = 0
    __methods__ = None
    __enabled__ = True

    async def request(self, method, url, kwargs):
        print(f"[DEBUG] {method} {url} kwargs={kwargs}")
        return kwargs

    async def response(self, response):
        print(f"[DEBUG] status={response.status} headers={dict(response.headers)}")
        return response


async def main():
    debug = DebugMiddleware()

    async with astra.ClientSession(middleware=[debug]) as session:
        print("--- debug ON ---")
        async with session.get("httpbin.org/get") as resp:
            print("status:", resp.status)

        debug.__enabled__ = False

        print("\n--- debug OFF ---")
        async with session.get("httpbin.org/get") as resp:
            print("status:", resp.status)


asyncio.run(main())
