import asyncio
import astra
from astra.middleware import BaseMiddleware


class BearerAuthMiddleware(BaseMiddleware):
    __return_type__ = bool
    __priority__ = 0
    __methods__ = None
    __enabled__ = True

    def __init__(self, token: str) -> None:
        self.token = token

    async def request(self, method, url, kwargs):
        kwargs.setdefault("headers", {})
        kwargs["headers"]["Authorization"] = f"Bearer {self.token}"
        return kwargs


async def main():
    async with astra.ClientSession(
        middleware=[BearerAuthMiddleware(token="my-secret-token")],
    ) as session:
        async with session.get("httpbin.org/headers") as resp:
            data = resp.json()
            print(data["headers"].get("Authorization"))


asyncio.run(main())
