import asyncio
import astra
from astra.middleware import BaseMiddleware


class TimingMiddleware(BaseMiddleware):
    __return_type__ = float
    __priority__ = 0
    __methods__ = None
    __enabled__ = True

    async def request(self, method, url, kwargs):
        import time
        kwargs.setdefault("headers", {})
        kwargs["headers"]["X-Request-Time"] = str(time.time())
        return kwargs


class UserAgentMiddleware(BaseMiddleware):
    __return_type__ = str
    __priority__ = 1
    __methods__ = None
    __enabled__ = True

    async def request(self, method, url, kwargs):
        kwargs.setdefault("headers", {})
        kwargs["headers"]["User-Agent"] = "astra/1.0"
        return kwargs


class LoggingMiddleware(BaseMiddleware):
    __return_type__ = None
    __priority__ = 2
    __methods__ = None
    __enabled__ = True

    async def request(self, method, url, kwargs):
        print(f"[LOG] → {method} {url} headers={list(kwargs.get('headers', {}).keys())}")
        return kwargs

    async def response(self, response):
        print(f"[LOG] ← {response.status}")
        return response


async def main():
    # pipe syntax
    chain = TimingMiddleware() | UserAgentMiddleware() | LoggingMiddleware()

    async with astra.ClientSession(middleware=chain) as session:
        async with session.get("httpbin.org/headers") as resp:
            print(resp.json())


asyncio.run(main())
