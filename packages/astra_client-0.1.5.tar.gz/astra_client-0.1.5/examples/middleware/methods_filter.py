import asyncio
import astra
from astra.middleware import BaseMiddleware


class PostOnlyMiddleware(BaseMiddleware):
    __return_type__ = bool
    __priority__ = 0
    __methods__ = ["POST", "PUT", "PATCH"]
    __enabled__ = True

    async def request(self, method, url, kwargs):
        print(f"[POST-ONLY] intercepted {method} {url}")
        kwargs.setdefault("headers", {})
        kwargs["headers"]["X-Write-Op"] = "true"
        return kwargs


class GetOnlyMiddleware(BaseMiddleware):
    __return_type__ = bool
    __priority__ = 0
    __methods__ = ["GET"]
    __enabled__ = True

    async def request(self, method, url, kwargs):
        print(f"[GET-ONLY] intercepted {method} {url}")
        return kwargs


async def main():
    async with astra.ClientSession(
        middleware=[PostOnlyMiddleware(), GetOnlyMiddleware()],
    ) as session:
        # PostOnlyMiddleware skipped, GetOnlyMiddleware runs
        async with session.get("httpbin.org/get") as resp:
            print("GET status:", resp.status)

        # GetOnlyMiddleware skipped, PostOnlyMiddleware runs
        async with session.post("httpbin.org/post", json={"x": 1}) as resp:
            print("POST status:", resp.status)


asyncio.run(main())
