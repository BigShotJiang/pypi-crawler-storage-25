import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession() as session:
        async with session.post(
            "httpbin.org/post",
            json={"username": "astra", "version": "0.1.0"},
        ) as response:
            print(response.status)
            print(response.json())


asyncio.run(main())
