import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession() as session:
        async with session.put(
            "httpbin.org/put",
            json={"status": "updated"},
        ) as response:
            print(response.status)
            print(response.json())


asyncio.run(main())
