import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession() as session:
        async with session.get("httpbin.org/get") as response:
            print(response.status)
            print(response.json())


asyncio.run(main())
