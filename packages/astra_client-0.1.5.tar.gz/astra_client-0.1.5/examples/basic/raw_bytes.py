import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession() as session:
        payload = b"\x00\x01\x02\x03"
        async with session.post("httpbin.org/post", data=payload) as response:
            print(response.status)
            data = response.json()
            print(data["data"])


asyncio.run(main())
