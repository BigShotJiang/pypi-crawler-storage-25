import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession() as session:
        form = {"username": "alice", "password": "secret"}
        async with session.post("httpbin.org/post", data=form) as response:
            print(response.status)
            data = response.json()
            print(data["form"])


asyncio.run(main())
