import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession(base_url="https://httpbin.org") as session:
        params = {"page": "1", "limit": "10", "sort": "desc"}
        async with session.get("/get", params=params) as response:
            print(response.status)
            data = response.json()
            print(data["args"])


asyncio.run(main())
