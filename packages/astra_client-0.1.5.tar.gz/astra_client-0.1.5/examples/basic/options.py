import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession() as session:
        async with session.options("httpbin.org/get") as response:
            print(response.status)
            print(response.headers.get("Allow"))


asyncio.run(main())
