import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession(
        base_url="https://httpbin.org",
        headers={"X-App": "astra"},
    ) as session:
        async with session.get(
            "/headers",
            headers={"X-Request-ID": "req-001", "X-Trace": "trace-abc"},
        ) as response:
            print(response.status)
            data = response.json()
            print(data["headers"])


asyncio.run(main())
