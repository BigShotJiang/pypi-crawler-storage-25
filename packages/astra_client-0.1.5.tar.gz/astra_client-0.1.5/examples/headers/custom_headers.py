import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession(
        headers={"X-App-Name": "astrahttp", "Accept-Language": "en-US"},
    ) as session:
        async with session.get("httpbin.org/headers") as response:
            print(response.status)
            print(response.json())


asyncio.run(main())
