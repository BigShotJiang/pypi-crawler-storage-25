import asyncio

import astra

API_KEY = "my-secret-api-key"


async def main() -> None:
    async with astra.ClientSession(
        base_url="https://httpbin.org",
        headers={"X-API-Key": API_KEY},
    ) as session:
        async with session.get("/headers") as response:
            print(response.status)
            data = response.json()
            print(data["headers"].get("X-Api-Key"))


asyncio.run(main())
