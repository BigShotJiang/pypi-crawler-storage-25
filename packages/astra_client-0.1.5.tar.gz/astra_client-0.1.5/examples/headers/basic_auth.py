import asyncio
import base64

import astra


def basic_auth(username: str, password: str) -> str:
    token = base64.b64encode(f"{username}:{password}".encode()).decode()
    return f"Basic {token}"


async def main() -> None:
    async with astra.ClientSession(
        headers={"Authorization": basic_auth("user", "pass")},
    ) as session:
        async with session.get("httpbin.org/basic-auth/user/pass") as response:
            print(response.status)
            print(response.json())


asyncio.run(main())
