import asyncio

import astra


async def main() -> None:
    async with astra.ClientSession(
        headers={"Authorization": "Bearer YOUR_TOKEN_HERE"},
    ) as session:
        async with session.get("httpbin.org/bearer") as response:
            print(response.status)
            print(response.json())


asyncio.run(main())
