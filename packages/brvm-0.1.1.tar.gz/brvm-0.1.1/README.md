# BRVM Python Package 📈��
[![PyPI version](https://badge.fury.io/py/brvm.svg)](https://pypi.org/project/brvm/)[![Python Versions](https://img.shields.io/badge/python-3.9%20%7C%203.10%20%7C%203.11-blue)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)

Une bibliothèque Python open-source robuste pour scraper et analyser les données de la **Bourse Régionale des Valeurs Mobilières (BRVM)**.  
Conçue pour les analystes financiers, les développeurs et les data scientists, elle s'inspire du format `yfinance` en renvoyant directement des objets `pandas.DataFrame` propres et standardisés.

Les données sont extraites et croisées à partir de multiples sources fiables (Site officiel BRVM, Sika Finance, RichBourse, UMOA-Titres) avec un système de fallback automatique en cas d'indisponibilité d'une source.

## 🔥 Fonctionnalités & Univers Couvert

- **Actions (Equities) & Indices** : Cotations en temps réel (EOD), historiques complets OHLCV, liste des tickers validés.
- **Obligations (Bonds)** : Prise en charge des obligations cotées à la BRVM.
- **Profils & Fondamentaux** : Informations d'entreprises, ratios financiers annuels (PER, ROE, Rendement de Dividende, Capitalisation).
- **Corporate Actions** : Historiques des dividendes, actualités des entreprises (Sika Finance), extraction du Bulletin Officiel de la Cote (BOC).
- **Marché Primaire (UMOA-Titres)** : Courbe des taux souverains, historique et calendrier des adjudications (Bons et Obligations du Trésor).
- **⚡ Cache SQLite Local** : Accélération des requêtes redondantes via une base de données locale respectueuse des API distantes.

## 📦 Installation

L'installation recommandée se fait simplement via `pip` :

```bash
pip install brvm
```

**Pour la version de développement depuis les sources :**

```bash
git clone https://github.com/Naofal03/brvm.git
cd brvm
pip install -e "."
```

## 🚀 Utilisation Courante (API Complète)

Toutes les méthodes exposées renvoient soit des dictionnaires Python, soit des `pandas.DataFrame` prêts à l'analyse.

### 1. Actions, Indices et Obligations
```python
import brvm

# a. Lister tous les instruments (Actions, Indices, Obligations)
df_tickers = brvm.get_tickers()
print(df_tickers.head())

# b. Obtenir la dernière cotation officielle détaillée EOD d'une action
cours = brvm.get_quote("SNTS")
print(f"Sonatel - Clôture : {cours['close']} XOF, Volume : {cours['volume']}")

# c. Récupérer l'historique complet OHLCV (Open, High, Low, Close, Volume)
df_historique = brvm.get_history("SNTS", start="2023-01-01", end="2024-01-01")
print(df_historique)

# d. Récupérer l'historique d'un indice (ex: BRVM Composite)
df_index = brvm.get_index_history("BRVM-COMP")
```

### 2. Fondamentaux & Corporate Actions
```python
# a. Profil de l'entreprise (Secteur, activité, capitalisation...)
profil = brvm.get_company_info("SNTS")

# b. Historique des ratios financiers (PER, ROE, Rendements)
df_fondamentaux = brvm.get_fundamentals_history("SNTS")

# c. Historique complet des dividendes
df_div = brvm.get_dividends("SNTS")

# d. Actualités et articles de presse (via Sika Finance)
news = brvm.get_news("SNTS")
print(news[0]['title'], "-", news[0]['url'])

# e. Récupérer le Bulletin Officiel de la Cote (BOC) du jour
df_boc = brvm.get_latest_boc()
```

### 3. Marché Primaire (UMOA-Titres)
```python
# a. Récupérer la dernière Courbe des Taux (matrice des taux Zéro-Coupon)
courbe_taux = brvm.get_yield_curve()

# b. Consulter les résultats récents d'adjudications du marché primaire
historique_emissions = brvm.get_adjudications_history(limit=10)

# c. Consulter le calendrier des prochaines émissions de l'UEMOA
calendrier = brvm.get_adjudications_calendar(limit=5)
```

## 🛠️ Format des Données Temporelles (Standard OHLCV)
La méthode `get_history` obéit à la standardisation suivante :
- **Absence de Nulls intempestifs** : Les NaN pour Open/High/Low n'existent que pour les jours où le `trading_status` est "NC" (Non Coté).  
- **Forward Fill** : Les jours sans transaction voient leur cours précédent reporté sur la valeur de clôture (`close`), le volume tombant à `0`.
- Colonnes fixes : `[date, open, high, low, close, adj_close, volume, value, trading_status]`.

## ⚙️ Gestion du Cache Local
Par défaut, le package utilise une base de données cache `~/.brvm_cache.db` pour éviter d'inonder les serveurs de la BRVM. 
- Les séries temporelles (EOD) expirent après **12 heures**.
- Les données structurelles (Tickers, Fondamentaux) expirent après **7 jours**.

Si vous souhaitez forcer un appel réseau frais :
```python
brvm.disable_cache()
brvm.get_history("SNTS")  # Requête réseau obligée
brvm.enable_cache()       # Réactivation du système
```

## 🧪 Tests et Contribution
Le package demande une stricte couverture de tests (>80%). Pour lancer les tests en environnement de dev :

```bash
pip install -e ".[dev]"
pytest --cov=brvm
```

## 📄 Licence
Ce projet est mis à disposition sous licence Open-Source MIT.
