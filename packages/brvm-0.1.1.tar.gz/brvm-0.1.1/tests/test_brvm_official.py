from pathlib import Path

from brvm.scrapers import brvm_official


FIXTURES_DIR = Path(__file__).parent / "fixtures"


class DummyResponse:
    def __init__(self, text: str) -> None:
        self.text = text


class DummySession:
    def __init__(self, html: str) -> None:
        self.html = html

    def get(self, url: str, params: dict | None = None) -> DummyResponse:
        _ = (url, params)
        return DummyResponse(self.html)


def test_fetch_tickers_parses_equities_and_indices(monkeypatch) -> None:
    html = (FIXTURES_DIR / "brvm_portefeuille.html").read_text(encoding="utf-8")
    monkeypatch.setattr(brvm_official, "get_brvm_session", lambda: DummySession(html))

    result = brvm_official.fetch_tickers()

    assert "ABJC" in set(result["id"])
    assert "BRVM-COMP" in set(result["id"])
    assert result.loc[result["id"] == "ABJC", "instrument_type"].iloc[0] == "EQUITY"
    assert result.loc[result["id"] == "BRVM-COMP", "instrument_type"].iloc[0] == "INDEX"


def test_fetch_latest_quotes_normalizes_numeric_columns(monkeypatch) -> None:
    html = (FIXTURES_DIR / "brvm_portefeuille.html").read_text(encoding="utf-8")
    monkeypatch.setattr(brvm_official, "get_brvm_session", lambda: DummySession(html))

    result = brvm_official.fetch_latest_quotes()
    abjc = result.loc[result["symbol"] == "ABJC"].iloc[0]

    assert int(abjc["open"]) == 3425
    assert int(abjc["close"]) == 3420
    assert int(abjc["volume"]) == 1677
