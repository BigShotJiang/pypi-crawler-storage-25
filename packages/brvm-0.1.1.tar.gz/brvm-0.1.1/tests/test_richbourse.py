from pathlib import Path

from brvm.scrapers import richbourse


FIXTURES_DIR = Path(__file__).parent / "fixtures"


class DummyResponse:
    def __init__(self, text: str) -> None:
        self.text = text


class DummySession:
    def __init__(self, html: str) -> None:
        self.html = html

    def get(self, url: str, params: dict | None = None) -> DummyResponse:
        _ = (url, params)
        return DummyResponse(self.html)


def test_fetch_equity_history_normalizes_adjusted_values(monkeypatch) -> None:
    html = (FIXTURES_DIR / "richbourse_equity_history.html").read_text(encoding="utf-8")
    monkeypatch.setattr(richbourse, "get_brvm_session", lambda: DummySession(html))

    result = richbourse.fetch_history("ABJC", is_index=False, max_pages=1)

    assert list(result.columns) == [
        "date",
        "open",
        "high",
        "low",
        "close",
        "adj_close",
        "volume",
        "value",
        "trading_status",
    ]
    assert int(result.iloc[-1]["close"]) == 3420
    assert int(result.iloc[-1]["adj_close"]) == 3420
    assert int(result.iloc[-1]["volume"]) == 1677
    assert result.iloc[0]["trading_status"] == "NC"


def test_fetch_index_history_fills_missing_volume_and_value(monkeypatch) -> None:
    html = (FIXTURES_DIR / "richbourse_index_history.html").read_text(encoding="utf-8")
    monkeypatch.setattr(richbourse, "get_brvm_session", lambda: DummySession(html))

    result = richbourse.fetch_history("BRVM-COMPOSITE", is_index=True, max_pages=1)

    assert float(result.iloc[-1]["close"]) == 406.95
    assert int(result.iloc[-1]["volume"]) == 0
    assert int(result.iloc[-1]["value"]) == 0
    assert result.iloc[-1]["trading_status"] == "NC"
