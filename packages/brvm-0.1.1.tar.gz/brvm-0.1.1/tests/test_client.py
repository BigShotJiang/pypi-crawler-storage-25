import pytest
import brvm.client as client

def test_get_brvm_session():
    session = client.get_brvm_session()
    assert isinstance(session, client.BRVMClient)
    
    # Singleton check
    session2 = client.get_brvm_session()
    assert session is session2

def test_client_get_post(monkeypatch):
    class MockResponse:
        def raise_for_status(self): pass
    class MockHttpxClient:
        def __init__(self, *args, **kwargs): pass
        def request(self, method, url, **kwargs):
            return MockResponse()
        def close(self): pass
    
    # Create valid client then override sessions
    c = client.BRVMClient()
    c._session = MockHttpxClient()
    c._insecure_session = MockHttpxClient()
    
    res_get = c.get("http://example.com")
    assert isinstance(res_get, MockResponse)
    
    res_post = c.post("http://example.com", data={"key": "val"})
    assert isinstance(res_post, MockResponse)

def test_client_fallback(monkeypatch):
    class MockResponse:
        def raise_for_status(self): pass
    
    class FailingClient:
        def request(self, method, url, **kwargs):
            raise Exception("CERTIFICATE_VERIFY_FAILED")
        def close(self): pass
        
    class WorkingClient:
        def request(self, method, url, **kwargs):
            return MockResponse()
        def close(self): pass
            
    c = client.BRVMClient()
    c._session = FailingClient()
    c._insecure_session = WorkingClient()
    
    res = c.get("http://example.com")
    assert isinstance(res, MockResponse)

def test_client_context():
    c = client.BRVMClient()
    with c as ctx:
        assert isinstance(ctx, client.BRVMClient)
