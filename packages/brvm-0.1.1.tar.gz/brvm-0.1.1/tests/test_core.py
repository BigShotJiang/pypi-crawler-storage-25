from datetime import date
import pandas as pd
import pytest
from brvm import core
from brvm.exceptions import InvalidSymbolError, SourceUnavailableError

def mock_get_tickers():
    return pd.DataFrame([
        {"id": "SNTS", "name": "SONATEL", "instrument_type": "EQUITY", "sector": "SERVICES PUBLICS"},
        {"id": "BRVM-COMP", "name": "BRVM COMPOSITE", "instrument_type": "INDEX", "sector": None}
    ])

def test_get_history_filters_on_requested_window(monkeypatch) -> None:
    history = pd.DataFrame([
        {"date": date(2026, 4, 1), "close": 3630, "volume": 906},
        {"date": date(2026, 4, 9), "close": 3420, "volume": 1677},
    ])
    monkeypatch.setattr(core, "get_tickers", mock_get_tickers)
    monkeypatch.setattr(core, "fetch_richbourse_history", lambda *args, **kwargs: history)
    
    result = core.get_history("SNTS", start="2026-04-05", end="2026-04-09")
    assert len(result) == 1
    assert result.iloc[0]["date"] == date(2026, 4, 9)

def test_get_history_rejects_unknown_symbol(monkeypatch) -> None:
    monkeypatch.setattr(core, "get_tickers", mock_get_tickers)
    with pytest.raises(InvalidSymbolError):
        core.get_history("XXXX")

def test_get_history_empty_source(monkeypatch) -> None:
    monkeypatch.setattr(core, "get_tickers", mock_get_tickers)
    monkeypatch.setattr(core, "fetch_richbourse_history", lambda *args, **kwargs: pd.DataFrame([]))
    with pytest.raises(SourceUnavailableError):
        core.get_history("SNTS")

def test_get_quote_returns_dict(monkeypatch) -> None:
    import pandas as pd
    monkeypatch.setattr(core, "fetch_latest_quotes", lambda: pd.DataFrame([
        {"symbol": "SNTS", "name": "SONATEL", "open": 100, "close": 102, "previous_close": 100, "volume": 10, "variation": 2.0}
    ]))
    def mock_fetch_boc():
        return pd.DataFrame([
            {"symbol": "SNTS", "open": 101, "close": 103, "previous_close": 100, "variation_percent": 3.0}
        ])

    import brvm.scrapers.boc
    monkeypatch.setattr(brvm.scrapers.boc, "fetch_latest_boc_cached", mock_fetch_boc)

    res = core.get_quote("SNTS")
    assert res["symbol"] == "SNTS"
    assert res["open"] == 101  # Updated by BOC
    assert res["close"] == 103 # Updated by BOC

def test_get_quote_rejects_unknown_symbol(monkeypatch) -> None:
    monkeypatch.setattr(core, "fetch_latest_quotes", lambda: pd.DataFrame(columns=["symbol", "open", "close"]))
    with pytest.raises(InvalidSymbolError):
        core.get_quote("XXXX")

def test_get_company_info(monkeypatch) -> None:
    monkeypatch.setattr(core, "get_tickers", mock_get_tickers)
    monkeypatch.setattr(core, "fetch_sika_company_info", lambda x: {"symbol": "SNTS", "name": "SikaInfo"})
    res = core.get_company_info("SNTS")
    assert res["name"] == "SikaInfo"

    # Test fallback to tickers
    monkeypatch.setattr(core, "fetch_sika_company_info", lambda x: None)
    res_fb = core.get_company_info("SNTS")
    assert res_fb["name"] == "SONATEL"
    
    with pytest.raises(InvalidSymbolError):
        core.get_company_info("XXXX")

def test_get_fundamentals_history(monkeypatch) -> None:
    monkeypatch.setattr(core, "get_tickers", mock_get_tickers)
    monkeypatch.setattr(core, "fetch_sika_fundamentals_history", lambda x: pd.DataFrame([{"year": 2025}]))
    res = core.get_fundamentals_history("SNTS")
    assert len(res) == 1
    
    with pytest.raises(InvalidSymbolError):
        core.get_fundamentals_history("XXXX")

def test_get_dividends(monkeypatch) -> None:
    monkeypatch.setattr(core, "get_tickers", mock_get_tickers)
    monkeypatch.setattr(core, "fetch_dividends", lambda x: pd.DataFrame([{"amount": 100}]))
    res = core.get_dividends("SNTS")
    assert len(res) == 1
    
    with pytest.raises(InvalidSymbolError):
         core.get_dividends("XXXX")

def test_get_index_history(monkeypatch) -> None:
    monkeypatch.setattr(core, "get_tickers", mock_get_tickers)
    monkeypatch.setattr(core, "fetch_richbourse_history", lambda *args, **kwargs: pd.DataFrame([{"date": date(2026, 4, 1)}]))
    res = core.get_index_history("BRVM COMPOSITE")
    assert len(res) == 1

def test_get_latest_boc(monkeypatch) -> None:
    monkeypatch.setattr(core, "fetch_latest_boc", lambda: pd.DataFrame([{"symbol": "SNTS"}]))
    res = core.get_latest_boc()
    assert len(res) == 1

def test_get_news(monkeypatch) -> None:
    monkeypatch.setattr(core, "get_tickers", mock_get_tickers)
    monkeypatch.setattr(core, "fetch_company_news", lambda x: [{"title": "News 1"}])
    res = core.get_news("SNTS")
    assert len(res) == 1
    
    with pytest.raises(InvalidSymbolError):
        core.get_news("XXXX")
