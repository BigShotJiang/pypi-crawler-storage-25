import pytest
import pandas as pd
from brvm.scrapers.boc import fetch_latest_boc, fetch_latest_boc_url, _clean_number
import brvm.scrapers.boc as boc_module
import io

def test_clean_number():
    assert _clean_number("1 000") == 1000.0
    assert _clean_number("1,5") == 1.5
    assert _clean_number("-2,5") == -2.5
    assert _clean_number("error") is None

def test_fetch_latest_boc_url(monkeypatch):
    class MockResponse:
        def __init__(self, text):
            self.text = text

    class MockSession:
        def get(self, url, **kwargs):
            html = """
            <html><body><a href="/test.pdf">PDF</a></body></html>
            """
            return MockResponse(html)

    monkeypatch.setattr(boc_module, "get_brvm_session", lambda: MockSession())
    assert fetch_latest_boc_url() == "https://www.brvm.org/test.pdf"

def test_fetch_latest_boc_url_failure(monkeypatch):
    class MockResponse:
        def __init__(self, text):
            self.text = text

    class MockSession:
        def get(self, url, **kwargs):
            return MockResponse("<html><body>No link</body></html>")

    monkeypatch.setattr(boc_module, "get_brvm_session", lambda: MockSession())
    with pytest.raises(RuntimeError):
        fetch_latest_boc_url()
