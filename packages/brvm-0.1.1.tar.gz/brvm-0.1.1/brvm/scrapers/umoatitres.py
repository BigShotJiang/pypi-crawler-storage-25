import io
import re
import numpy as np
import pandas as pd
import httpx
from bs4 import BeautifulSoup

UMOA_TITRES_YIELD_CURVE_URL = "https://www.umoatitres.org/fr/ressources-2/courbe-des-taux/"

def fetch_yield_curve() -> list[dict]:
    """
    Fetches the latest yield curve (Courbe des Taux) from the UMOA-Titres website.
    Downloads the Excel file and extracts data for each country.
    """
    with httpx.Client(verify=False, timeout=15) as client:
        # 1. Fetch the main page to find the latest yield curve excel file
        response = client.get(UMOA_TITRES_YIELD_CURVE_URL)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'lxml')
        
        # Regex to find links that look like excel files for 'courbes-de-taux'
        links = soup.find_all('a', href=re.compile(r'courbes?-des?-taux.*\.xlsx?', re.I))
        if not links:
            # Fallback
            links = soup.find_all('a', href=re.compile(r'\.xlsx$', re.I))
            
        if not links:
            raise ValueError("No yield curve Excel file links found on UMOA-Titres.")
            
        # Get the most recent link (top one)
        latest_file_url = links[0].get('href')
        if latest_file_url.startswith('//'):
            latest_file_url = 'https:' + latest_file_url
            
        # 2. Download the Excel file
        file_response = client.get(latest_file_url)
        file_response.raise_for_status()
        
    # 3. Parse the Excel file
    xl = pd.ExcelFile(io.BytesIO(file_response.content))
    
    yield_curves = []
    
    for sheet in xl.sheet_names:
        # Ignore empty or default sheet names
        if 'feuil' in sheet.lower() or 'sheet' in sheet.lower():
            continue
            
        df = xl.parse(sheet, header=None)
        
        # Find the starting row of the data ('Maturité')
        mask = df.isin(['Maturité', 'Maturite'])
        idx = np.where(mask)
        
        if len(idx[0]) > 0:
            row, col = idx[0][0], idx[1][0]
            
            # Extract the 3 columns (Maturité, Zero Coupon, Taux Après Lissage)
            # and ignore rows where all 3 values are NaN
            sub = df.iloc[row:, col:col+3].dropna(how='all')
            
            # Use the first row as columns and drop it
            sub.columns = ['maturite', 'zero_coupon', 'taux_lissage']
            sub = sub.iloc[1:].reset_index(drop=True)
            
            # Keep only rows where 'maturite' is a string (e.g. '1 an', '3 mois')
            # Some excel files might have junk at the bottom
            sub = sub[sub['maturite'].astype(str).str.contains('mois|an')]
            
            # Clean up the output to primitive types
            curve_data = []
            for _, r in sub.iterrows():
                curve_data.append({
                    "maturite": str(r["maturite"]).strip(),
                    "zero_coupon": float(r["zero_coupon"]) if pd.notna(r["zero_coupon"]) else None,
                    "taux_lissage": float(r["taux_lissage"]) if pd.notna(r["taux_lissage"]) else None
                })
                
            yield_curves.append({
                "country": sheet.strip(),
                "yield_curve": curve_data
            })
            
    return yield_curves

UMOA_TITRES_EMISSIONS_URL = "https://www.umoatitres.org/fr/emissions/"

def _extract_link(td) -> str | None:
    a = td.find('a')
    if a and 'href' in a.attrs:
        href = a['href']
        if href.startswith('//'):
            href = 'https:' + href
        elif href.startswith('/'):
            href = 'https://www.umoatitres.org' + href
        return href
    return None

def fetch_adjudications_history(limit: int = 50) -> list[dict]:
    """
    Fetches the history of latest primary market emissions/adjudications.
    """
    with httpx.Client(verify=False, timeout=15) as client:
        response = client.get(UMOA_TITRES_EMISSIONS_URL)
        response.raise_for_status()
        
    soup = BeautifulSoup(response.text, 'lxml')
    tables = soup.find_all('table')
    history_table = None
    
    for t in tables:
        headers = [th.get_text(strip=True) for th in set(t.find_all('th'))]
        if 'Émetteur' in headers and 'Maturité(mois)' in headers:
            history_table = t
            break
            
    if not history_table:
        return []
        
    results = []
    rows = history_table.find_all('tr')[1:]
    
    for r in rows:
        if len(results) >= limit:
            break
        tds = r.find_all('td')
        if len(tds) >= 10:
            results.append({
                "issuer": tds[0].get_text(strip=True),
                "instrument": tds[1].get_text(strip=True),
                "details": tds[2].get_text(strip=True),
                "operation_date": tds[3].get_text(strip=True),
                "value_date": tds[4].get_text(strip=True),
                "maturity_date": tds[5].get_text(strip=True),
                "maturity_months": tds[6].get_text(strip=True),
                "grace_period_years": tds[7].get_text(strip=True),
                "status": tds[9].get_text(strip=True),
                "url": _extract_link(tds[8])
            })
            
    return results

def fetch_adjudications_calendar(limit: int = 50) -> list[dict]:
    """
    Fetches the upcoming primary market emissions/adjudications.
    """
    with httpx.Client(verify=False, timeout=15) as client:
        response = client.get(UMOA_TITRES_EMISSIONS_URL)
        response.raise_for_status()
        
    soup = BeautifulSoup(response.text, 'lxml')
    tables = soup.find_all('table')
    calendar_table = None
    
    for t in tables:
        headers = [th.get_text(strip=True) for th in set(t.find_all('th'))]
        if 'Émetteur' in headers and 'Montant(millions de FCFA)' in headers:
            calendar_table = t
            break
            
    if not calendar_table:
        return []
        
    results = []
    rows = calendar_table.find_all('tr')[1:]
    
    for r in rows:
        if len(results) >= limit:
            break
        tds = r.find_all('td')
        if len(tds) >= 9:
            results.append({
                "issuer": tds[0].get_text(strip=True),
                "instrument": tds[1].get_text(strip=True),
                "details": tds[2].get_text(strip=True),
                "operation_date": tds[3].get_text(strip=True),
                "value_date": tds[4].get_text(strip=True),
                "maturity_date": tds[5].get_text(strip=True),
                "amount_millions_cfa": tds[6].get_text(strip=True),
                "status": tds[8].get_text(strip=True),
                "url": _extract_link(tds[7])
            })
            
    return results
