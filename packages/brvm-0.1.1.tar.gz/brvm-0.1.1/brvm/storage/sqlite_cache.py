import sqlite3
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional
import pandas as pd

logger = logging.getLogger(__name__)

# TTL (Time To Live) constants
TTL_EOD = timedelta(hours=12)
TTL_STATIC = timedelta(days=7)

class SQLiteCache:
    """Gestionnaire de cache local via SQLite."""
    
    def __init__(self, db_path: str | Path = "~/.brvm_cache.db", enabled: bool = True):
        self.enabled = enabled
        self.db_path = Path(db_path).expanduser()
        if self.enabled:
            self._init_db()

    def _init_db(self) -> None:
        """Initialise la table de stockage brute clé/valeur pour le cache."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS api_cache (
                    key TEXT PRIMARY KEY,
                    updated_at TIMESTAMP,
                    data JSON
                )
            ''')

    def get(self, key: str, max_age: timedelta) -> Optional[Any]:
        """Récupère une valeur en cache si elle n'a pas expiré."""
        if not self.enabled:
            return None
            
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT updated_at, data FROM api_cache WHERE key = ?", (key,))
            row = cursor.fetchone()
            
            if row:
                updated_at = datetime.fromisoformat(row[0])
                if datetime.now() - updated_at <= max_age:
                    logger.debug(f"Cache HIT for {key}")
                    return json.loads(row[1])
                else:
                    logger.debug(f"Cache EXPIRED for {key}")
                    self.delete(key)
        return None

    def set(self, key: str, data: Any) -> None:
        """Enregistre une valeur dans le cache."""
        if not self.enabled:
            return
            
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                INSERT OR REPLACE INTO api_cache (key, updated_at, data)
                VALUES (?, ?, ?)
            ''', (key, datetime.now().isoformat(), json.dumps(data)))
            logger.debug(f"Cache SET for {key}")

    def delete(self, key: str) -> None:
        """Supprime une valeur du cache."""
        if not self.enabled:
            return
            
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM api_cache WHERE key = ?", (key,))

    def clear(self) -> None:
        """Vide l'intégralité du cache."""
        if not self.enabled:
            return
            
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM api_cache")

# Instance unique du cache
brvm_cache = SQLiteCache()
