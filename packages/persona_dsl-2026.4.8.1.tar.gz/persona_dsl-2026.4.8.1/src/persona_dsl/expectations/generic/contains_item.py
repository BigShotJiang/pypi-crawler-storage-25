from collections.abc import Container

from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona


class ContainsItem(Expectation):
    """Проверяет, что список содержит указанный элемент."""

    def __init__(self, expected_item: object):
        self.expected_item = expected_item

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        """Проверяет, что список содержит указанный элемент."""
        if kwargs:
            raise TypeError(
                "ContainsItem не принимает именованные аргументы выполнения."
            )
        if len(args) != 1:
            raise TypeError(
                "ContainsItem требует ровно один позиционный аргумент со списком."
            )
        actual_list = args[0]
        if not isinstance(actual_list, Container):
            raise TypeError(
                "ContainsItem требует контейнер в качестве фактического значения."
            )
        contains_item = self.expected_item in actual_list
        if not contains_item:
            raise AssertionError(
                f"Ожидался элемент {self.expected_item!r}, но он отсутствует в {actual_list!r}."
            )

    def _get_step_description(self, persona: Persona) -> str:
        return f"содержит элемент '{self.expected_item}'"
