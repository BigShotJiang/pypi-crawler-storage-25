from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona


class IsEqualTo(Expectation):
    """Проверяет, что фактическое значение равно ожидаемому."""

    def __init__(self, expected: object):
        """Инициализирует ожидание.

        Args:
            expected: Ожидаемое значение.
        """
        self.expected = expected

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        """Проверяет, что фактическое значение равно ожидаемому."""
        if kwargs:
            raise TypeError("IsEqualTo не принимает именованные аргументы выполнения.")
        if len(args) != 1:
            raise TypeError(
                "IsEqualTo требует ровно один позиционный аргумент для сравнения."
            )
        actual = args[0]
        if actual != self.expected:
            raise AssertionError(
                f"Ожидалось значение {self.expected!r}, получено {actual!r}."
            )

    def _get_step_description(self, persona: Persona) -> str:
        return f"равно '{self.expected}'"
