from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona


class IsTruthy(Expectation):
    """Проверяет, что значение приводится к True."""

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if kwargs:
            raise TypeError("IsTruthy не принимает именованные аргументы выполнения.")
        if len(args) != 1:
            raise TypeError(
                "IsTruthy требует ровно один позиционный аргумент для проверки."
            )
        actual = args[0]
        if not actual:
            raise AssertionError(f"Ожидалось truthy-значение, получено {actual!r}.")

    def _get_step_description(self, persona: Persona) -> str:
        return "приводится к True"
