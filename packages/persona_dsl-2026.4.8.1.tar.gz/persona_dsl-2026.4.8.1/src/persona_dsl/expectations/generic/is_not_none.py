from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona


class IsNotNone(Expectation):
    """Проверяет, что фактическое значение не равно None."""

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if kwargs:
            raise TypeError("IsNotNone не принимает именованные аргументы выполнения.")
        if len(args) != 1:
            raise TypeError(
                "IsNotNone требует ровно один позиционный аргумент для проверки."
            )
        actual = args[0]
        if actual is None:
            raise AssertionError("Ожидалось значение, отличное от None.")

    def _get_step_description(self, persona: Persona) -> str:
        return "не равно None"
