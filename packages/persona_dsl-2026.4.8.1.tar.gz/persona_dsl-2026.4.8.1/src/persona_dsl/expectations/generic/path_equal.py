from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona
from persona_dsl.utils.path import extract_by_path


class PathEqual(Expectation):
    """
    Проверяет, что значение по указанному пути (dot/bracket нотация) внутри объекта равно ожидаемому.

    Пример:
        PathEqual("a.b[0].c", 42).check({"a": {"b": [{"c": 42}]}})  # проходит
    """

    def __init__(self, path: str, expected: object):
        self.path = path
        self.expected = expected

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if kwargs:
            raise TypeError("PathEqual не принимает именованные аргументы выполнения.")
        if len(args) != 1:
            raise TypeError(
                "PathEqual требует ровно один позиционный аргумент с фактическим объектом."
            )
        actual = args[0]
        value = extract_by_path(actual, self.path)
        if value != self.expected:
            raise AssertionError(
                f"Ожидалось значение {self.expected!r} по пути {self.path!r}, получено {value!r}."
            )

    def _get_step_description(self, persona: Persona) -> str:
        return f"значение по пути '{self.path}' равно '{self.expected}'"
