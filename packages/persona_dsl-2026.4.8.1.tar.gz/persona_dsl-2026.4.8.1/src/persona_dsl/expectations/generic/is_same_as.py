from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona


class IsSameAs(Expectation):
    """Проверяет идентичность объектов через оператор is."""

    def __init__(self, expected_reference: object):
        self.expected_reference = expected_reference

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if kwargs:
            raise TypeError("IsSameAs не принимает именованные аргументы выполнения.")
        if len(args) != 1:
            raise TypeError(
                "IsSameAs требует ровно один позиционный аргумент для проверки."
            )
        actual = args[0]
        if actual is not self.expected_reference:
            raise AssertionError("Ожидалось, что фактическое значение — тот же объект.")

    def _get_step_description(self, persona: Persona) -> str:
        return "является тем же объектом"
