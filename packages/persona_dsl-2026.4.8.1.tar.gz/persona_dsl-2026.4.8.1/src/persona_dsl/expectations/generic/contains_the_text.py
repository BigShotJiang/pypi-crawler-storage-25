from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona


class ContainsTheText(Expectation):
    def __init__(self, expected_text: str):
        self.expected_text = expected_text

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if kwargs:
            raise TypeError(
                "ContainsTheText не принимает именованные аргументы выполнения."
            )
        if len(args) != 1:
            raise TypeError(
                "ContainsTheText требует ровно один позиционный аргумент с текстом."
            )
        actual_text = args[0]
        if not isinstance(actual_text, str):
            raise TypeError("ContainsTheText требует строковый фактический аргумент.")
        if self.expected_text not in actual_text:
            raise AssertionError(
                f"Ожидался текст {self.expected_text!r} в {actual_text!r}."
            )

    def _get_step_description(self, persona: Persona) -> str:
        return f"содержит текст '{self.expected_text}'"
