from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona


class IsInstanceOf(Expectation):
    """Проверяет тип фактического значения через isinstance(...)."""

    def __init__(self, expected_type: type[object] | tuple[type[object], ...]):
        self.expected_type = expected_type

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if kwargs:
            raise TypeError(
                "IsInstanceOf не принимает именованные аргументы выполнения."
            )
        if len(args) != 1:
            raise TypeError(
                "IsInstanceOf требует ровно один позиционный аргумент для проверки."
            )
        actual = args[0]
        if not isinstance(actual, self.expected_type):
            raise AssertionError(
                f"Ожидался объект типа {self.expected_type!r}, получен {type(actual)!r}."
            )

    def _get_step_description(self, persona: Persona) -> str:
        if isinstance(self.expected_type, tuple):
            type_name = ", ".join(tp.__name__ for tp in self.expected_type)
        else:
            type_name = self.expected_type.__name__
        return f"имеет тип '{type_name}'"
