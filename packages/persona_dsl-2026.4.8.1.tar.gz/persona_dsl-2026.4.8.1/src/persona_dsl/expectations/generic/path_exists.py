from os import PathLike
from pathlib import Path

from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona


class PathExists(Expectation):
    """Проверяет, что путь существует на диске."""

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if kwargs:
            raise TypeError("PathExists не принимает именованные аргументы выполнения.")
        if len(args) != 1:
            raise TypeError(
                "PathExists требует ровно один позиционный аргумент с путём."
            )
        actual = args[0]
        if not isinstance(actual, (str, PathLike, Path)):
            raise TypeError("PathExists требует строку или pathlib.Path.")
        if not Path(actual).exists():
            raise AssertionError(f"Ожидалось, что путь {Path(actual)!s} существует.")

    def _get_step_description(self, persona: Persona) -> str:
        return "существует как путь на диске"
