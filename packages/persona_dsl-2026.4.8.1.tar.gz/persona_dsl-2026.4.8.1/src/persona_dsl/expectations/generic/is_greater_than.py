from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona


class IsGreaterThan(Expectation):
    """Проверяет, что одно число больше другого."""

    def __init__(self, value: int | float):
        self.value = value

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        """Проверяет, что одно число больше другого."""
        if kwargs:
            raise TypeError(
                "IsGreaterThan не принимает именованные аргументы выполнения."
            )
        if len(args) != 1:
            raise TypeError(
                "IsGreaterThan требует ровно один позиционный аргумент для сравнения."
            )
        actual_value = args[0]
        if not isinstance(actual_value, int | float):
            raise TypeError("IsGreaterThan требует числовой фактический аргумент.")
        if actual_value <= self.value:
            raise AssertionError(
                f"Ожидалось значение больше {self.value!r}, получено {actual_value!r}."
            )

    def _get_step_description(self, persona: Persona) -> str:
        return f"больше чем {self.value}"
