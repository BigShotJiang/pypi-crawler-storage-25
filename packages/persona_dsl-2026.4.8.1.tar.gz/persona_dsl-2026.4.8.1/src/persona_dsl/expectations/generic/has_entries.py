from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona


class HasEntries(Expectation):
    """
    Проверяет, что фактический словарь содержит все ключи и значения
    из ожидаемого словаря.
    """

    def __init__(self, expected_data: dict[str, object]):
        self.expected_data = expected_data

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        """Проверяет, что actual_data содержит все записи из expected_data."""
        if kwargs:
            raise TypeError("HasEntries не принимает именованные аргументы выполнения.")
        if len(args) != 1:
            raise TypeError(
                "HasEntries требует ровно один позиционный аргумент со словарём."
            )
        actual_data = args[0]
        if not isinstance(actual_data, dict):
            raise TypeError(
                "HasEntries требует словарь в качестве фактического значения."
            )
        for key, expected_value in self.expected_data.items():
            if key not in actual_data:
                raise AssertionError(f"Ключ {key!r} отсутствует в фактических данных.")
            actual_value = actual_data[key]
            if actual_value != expected_value:
                raise AssertionError(
                    f"Для ключа {key!r} ожидалось {expected_value!r}, получено {actual_value!r}."
                )

    def _get_step_description(self, persona: Persona) -> str:
        return f"содержит записи {self.expected_data}"
