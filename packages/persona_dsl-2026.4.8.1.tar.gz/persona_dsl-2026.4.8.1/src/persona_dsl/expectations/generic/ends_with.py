from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona


class EndsWith(Expectation):
    """Проверяет, что строка оканчивается ожидаемым суффиксом."""

    def __init__(self, expected_suffix: str):
        self.expected_suffix = expected_suffix

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if kwargs:
            raise TypeError("EndsWith не принимает именованные аргументы выполнения.")
        if len(args) != 1:
            raise TypeError(
                "EndsWith требует ровно один позиционный аргумент со строкой."
            )
        actual = args[0]
        if not isinstance(actual, str):
            raise TypeError("EndsWith требует строковое фактическое значение.")
        if not actual.endswith(self.expected_suffix):
            raise AssertionError(
                f"Ожидалось, что {actual!r} оканчивается на {self.expected_suffix!r}."
            )

    def _get_step_description(self, persona: Persona) -> str:
        return f"оканчивается на '{self.expected_suffix}'"
