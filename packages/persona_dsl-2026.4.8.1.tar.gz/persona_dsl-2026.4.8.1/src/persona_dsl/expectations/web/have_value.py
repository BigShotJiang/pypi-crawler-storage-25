from playwright.sync_api import expect

from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_target_locator


class HaveValue(Expectation):
    """
    Проверка: Input имеет ожидаемое значение.
    Wrapper for: expect(locator).to_have_value(value)
    """

    def __init__(self, value: str, timeout: float = 5000):
        self.value = value
        self.timeout = timeout

    def _get_step_description(self, persona: Persona) -> str:
        return f"имеет значение '{self.value}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        locator = require_target_locator(
            persona, args, kwargs, component_name=self.__class__.__name__
        )
        expect(locator).to_have_value(self.value, timeout=self.timeout)
