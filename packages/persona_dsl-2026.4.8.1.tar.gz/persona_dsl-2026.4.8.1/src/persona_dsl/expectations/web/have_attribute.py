from playwright.sync_api import expect

from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_target_locator


class HaveAttribute(Expectation):
    """
    Проверка: Элемент имеет атрибут с ожидаемым значением (или любым, если value=None).
    """

    def __init__(self, name: str, value: str | None = None, timeout: float = 5000):
        self.name = name
        self.value = value
        self.timeout = timeout

    def _get_step_description(self, persona: Persona) -> str:
        val_desc = f"='{self.value}'" if self.value is not None else ""
        return f"имеет атрибут '{self.name}'{val_desc}"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        locator = require_target_locator(
            persona, args, kwargs, component_name=self.__class__.__name__
        )
        if self.value is not None:
            expect(locator).to_have_attribute(
                self.name, self.value, timeout=self.timeout
            )
            return

        actual_value = locator.get_attribute(self.name)
        if actual_value is None:
            raise AssertionError(
                f"Ожидалось наличие атрибута '{self.name}', но он отсутствует."
            )
