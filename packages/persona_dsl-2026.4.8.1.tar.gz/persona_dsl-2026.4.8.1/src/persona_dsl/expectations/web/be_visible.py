from playwright.sync_api import expect

from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_target_locator


class BeVisible(Expectation):
    """
    Проверка: Элемент видим на странице.
    Wrapper for: expect(locator).to_be_visible()
    """

    def __init__(self, timeout: float = 5000):
        self.timeout = timeout

    def _get_step_description(self, persona: Persona) -> str:
        return "видим на странице"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        locator = require_target_locator(
            persona, args, kwargs, component_name=self.__class__.__name__
        )
        expect(locator).to_be_visible(timeout=self.timeout)
