from playwright.sync_api import expect

from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_target_locator


class ContainText(Expectation):
    """
    Проверка: Элемент содержит указанный текст.
    Wrapper for: expect(locator).to_contain_text(expected)
    """

    def __init__(self, expected: str, timeout: float = 5000):
        self.expected = expected
        self.timeout = timeout

    def _get_step_description(self, persona: Persona) -> str:
        return f"содержит текст '{self.expected}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        locator = require_target_locator(
            persona, args, kwargs, component_name=self.__class__.__name__
        )
        expect(locator).to_contain_text(self.expected, timeout=self.timeout)
