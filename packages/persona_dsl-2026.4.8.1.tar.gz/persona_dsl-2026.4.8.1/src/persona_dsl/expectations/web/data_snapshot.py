from __future__ import annotations

import difflib
import json
import textwrap
from pathlib import Path
from typing import TypeAlias

from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona
from persona_dsl.utils.snapshots import is_snapshot_update_enabled

SnapshotScalar: TypeAlias = str | int | float | bool | None
SnapshotValue: TypeAlias = (
    SnapshotScalar | dict[str, "SnapshotValue"] | list["SnapshotValue"]
)
SnapshotRecord: TypeAlias = dict[str, SnapshotValue]
SnapshotPayload: TypeAlias = SnapshotRecord | list[SnapshotRecord]


def _coerce_snapshot_value(raw_value: object, *, path: str) -> SnapshotValue:
    if raw_value is None or isinstance(raw_value, (str, int, float, bool)):
        return raw_value

    if isinstance(raw_value, list):
        return [
            _coerce_snapshot_value(item, path=f"{path}[{index}]")
            for index, item in enumerate(raw_value)
        ]

    if isinstance(raw_value, dict):
        result: dict[str, SnapshotValue] = {}
        for key, value in raw_value.items():
            if not isinstance(key, str):
                raise TypeError(f"{path}: ключ словаря должен быть строкой.")
            result[key] = _coerce_snapshot_value(value, path=f"{path}.{key}")
        return result

    raise TypeError(
        f"{path} содержит неподдерживаемый тип снапшота: {type(raw_value).__name__}."
    )


def _coerce_snapshot_record(raw_value: object, *, path: str) -> SnapshotRecord:
    if not isinstance(raw_value, dict):
        raise TypeError(
            f"{path} должен быть словарём со строковыми ключами, получено: {type(raw_value).__name__}."
        )
    result: SnapshotRecord = {}
    for key, value in raw_value.items():
        if not isinstance(key, str):
            raise TypeError(f"{path}: ключ словаря должен быть строкой.")
        result[key] = _coerce_snapshot_value(value, path=f"{path}.{key}")
    return result


def _coerce_snapshot_payload(raw_value: object) -> SnapshotPayload:
    if isinstance(raw_value, list):
        return [
            _coerce_snapshot_record(item, path=f"payload[{index}]")
            for index, item in enumerate(raw_value)
        ]
    return _coerce_snapshot_record(raw_value, path="payload")


class MatchesDataSnapshot(Expectation):
    """
    Сравнивает извлеченные данные (Dict или List[Dict]) с сохраненным JSON-эталоном.
    Работает по принципу визуальных скриншотов, но для структурированных данных.
    """

    def __init__(
        self,
        name: str,
        exclude_keys: list[str] | None = None,
        update: bool = False,
        ignore_order: bool = False,
    ) -> None:
        self.name = name
        self.exclude_keys = exclude_keys or []
        self.update = update
        self.ignore_order = ignore_order

    def _get_step_description(self, persona: Persona) -> str:
        return f"Сверка данных со снимком '{self.name}'"

    def _clean_value(self, data: SnapshotValue) -> SnapshotValue:
        if isinstance(data, dict):
            return {
                key: self._clean_value(value)
                for key, value in data.items()
                if key not in self.exclude_keys
            }
        if isinstance(data, list):
            return [self._clean_value(item) for item in data]
        return data

    def _clean_record(self, data: SnapshotRecord) -> SnapshotRecord:
        return {
            key: self._clean_value(value)
            for key, value in data.items()
            if key not in self.exclude_keys
        }

    def _clean_data(self, data: SnapshotPayload) -> SnapshotPayload:
        if isinstance(data, list):
            return [self._clean_record(item) for item in data]
        return self._clean_record(data)

    def _sort_data(self, data: SnapshotPayload) -> SnapshotPayload:
        if isinstance(data, list) and self.ignore_order:
            return sorted(data, key=lambda item: json.dumps(item, sort_keys=True))
        return data

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if kwargs:
            raise TypeError(
                "MatchesDataSnapshot не принимает именованные аргументы выполнения."
            )
        if len(args) != 1:
            raise TypeError(
                "MatchesDataSnapshot требует ровно один позиционный аргумент с фактическими данными."
            )

        target = _coerce_snapshot_payload(args[0])
        cleaned_actual = self._clean_data(target)
        sorted_actual = self._sort_data(cleaned_actual)

        snapshots_dir = Path.cwd() / "tests" / "snapshots" / "data_snapshots"
        snapshots_dir.mkdir(parents=True, exist_ok=True)
        snapshot_path = snapshots_dir / f"{self.name}.json"

        if not snapshot_path.exists() or is_snapshot_update_enabled(
            persona, explicit_update=self.update
        ):
            with open(snapshot_path, "w", encoding="utf-8") as file:
                json.dump(
                    sorted_actual, file, ensure_ascii=False, indent=4, sort_keys=True
                )
            return None

        with open(snapshot_path, "r", encoding="utf-8") as file:
            expected_data = _coerce_snapshot_payload(json.load(file))

        sorted_expected = self._sort_data(expected_data)

        if sorted_actual == sorted_expected:
            return None

        actual_str = json.dumps(
            sorted_actual, ensure_ascii=False, indent=2, sort_keys=True
        )
        expected_str = json.dumps(
            sorted_expected, ensure_ascii=False, indent=2, sort_keys=True
        )

        diff_text = "".join(
            difflib.unified_diff(
                expected_str.splitlines(keepends=True),
                actual_str.splitlines(keepends=True),
                fromfile=f"Expected ({self.name}.json)",
                tofile="Actual Data",
            )
        )

        raise AssertionError(
            f"Данные не совпадают с эталоном '{self.name}'.\n\nРазличия:\n{textwrap.indent(diff_text, '  ')}"
        )
