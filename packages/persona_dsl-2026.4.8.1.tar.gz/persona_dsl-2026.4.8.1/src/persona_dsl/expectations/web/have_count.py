from playwright.sync_api import expect

from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_target_locator


class HaveCount(Expectation):
    """
    Проверка: Список элементов имеет ожидаемое количество.
    Wrapper for: expect(locator).to_have_count(count)
    """

    def __init__(self, count: int, timeout: float = 5000):
        self.count = count
        self.timeout = timeout

    def _get_step_description(self, persona: Persona) -> str:
        return f"имеет количество элементов: {self.count}"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        locator = require_target_locator(
            persona, args, kwargs, component_name=self.__class__.__name__
        )
        expect(locator).to_have_count(self.count, timeout=self.timeout)
