from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona


class IsDisplayed(Expectation):
    """Проверяет, что значение (результат факта) равно True."""

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if kwargs:
            raise TypeError(
                "IsDisplayed не принимает именованные аргументы выполнения."
            )
        if len(args) != 1:
            raise TypeError(
                "IsDisplayed требует ровно один позиционный аргумент с фактическим значением."
            )
        actual_value = args[0]
        assert actual_value is True, "Элемент не отображается, хотя ожидалось обратное."

    def _get_step_description(self, persona: Persona) -> str:
        return "отображается на странице"
