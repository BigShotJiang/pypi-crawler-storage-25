from __future__ import annotations

import shutil
import time
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path

import allure

from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona
from persona_dsl.utils.artifacts import artifacts_dir, sanitize_filename
from persona_dsl.utils.snapshots import is_snapshot_update_enabled


@dataclass(frozen=True, slots=True)
class IgnoreRegion:
    x: int
    y: int
    width: int
    height: int


def _require_int(raw_value: object, *, path: str) -> int:
    if not isinstance(raw_value, int) or isinstance(raw_value, bool):
        raise TypeError(f"{path} должен быть целым числом.")
    return raw_value


def _coerce_ignore_regions(
    raw_regions: Sequence[Mapping[str, object]] | None,
) -> list[IgnoreRegion]:
    if raw_regions is None:
        return []

    regions: list[IgnoreRegion] = []
    for index, raw_region in enumerate(raw_regions):
        regions.append(
            IgnoreRegion(
                x=_require_int(raw_region.get("x"), path=f"ignore_regions[{index}].x"),
                y=_require_int(raw_region.get("y"), path=f"ignore_regions[{index}].y"),
                width=_require_int(
                    raw_region.get("w"), path=f"ignore_regions[{index}].w"
                ),
                height=_require_int(
                    raw_region.get("h"), path=f"ignore_regions[{index}].h"
                ),
            )
        )
    return regions


class MatchesScreenshot(Expectation):
    """
    Ожидание: файл-скриншот совпадает с baseline-снимком (PNG) с допуском threshold.
    - baseline хранится по умолчанию в tests/snapshots/<snapshot_name>.
    - при отсутствии baseline:
        * если update=True или UPDATE_SNAPSHOTS=1 — baseline создаётся из actual;
        * иначе — ошибка.
    - при расхождении > threshold — сохраняется diff и прикрепляется в Allure.
    """

    def __init__(
        self,
        snapshot_name: str,
        threshold: float = 0.0,
        update: bool = False,
        ignore_regions: Sequence[Mapping[str, object]] | None = None,
        baseline_dir: str | None = None,
    ) -> None:
        self.snapshot_name = snapshot_name
        self.threshold = float(threshold)
        self.update = bool(update)
        self.ignore_regions = _coerce_ignore_regions(ignore_regions)
        self.baseline_dir = baseline_dir

    def _get_step_description(self, persona: Persona) -> str:
        return f"совпадает со скриншотом '{self.snapshot_name}' (threshold={self.threshold})"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if kwargs:
            raise TypeError(
                "MatchesScreenshot не принимает именованные аргументы выполнения."
            )
        if len(args) != 1:
            raise TypeError(
                "MatchesScreenshot требует ровно один позиционный аргумент с путём к PNG."
            )

        actual_path = args[0]
        if not isinstance(actual_path, str):
            raise TypeError(
                f"MatchesScreenshot ожидает строковый путь к PNG, получено: {type(actual_path)}"
            )

        try:
            from PIL import Image, ImageChops, ImageDraw
        except ModuleNotFoundError as error:
            raise RuntimeError(
                "Для сравнения скриншотов требуется пакет 'pillow'. Установите его."
            ) from error

        snap_name = sanitize_filename(self.snapshot_name)
        if not snap_name.lower().endswith(".png"):
            snap_name += ".png"
        base_dir = (
            Path(self.baseline_dir)
            if self.baseline_dir is not None
            else (Path.cwd() / "tests" / "snapshots")
        )
        baseline_path = base_dir / snap_name
        actual_path_p = Path(actual_path)

        is_update_mode = is_snapshot_update_enabled(
            persona, explicit_update=self.update
        )
        if not baseline_path.exists():
            if not is_update_mode:
                raise AssertionError(
                    f"Baseline не найден: {baseline_path}. "
                    f"Запустите с UPDATE_SNAPSHOTS=1 или установите update=True для обновления baseline."
                )
            baseline_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(actual_path_p, baseline_path)
            allure.attach.file(
                str(actual_path_p),
                name=f"baseline-created:{snap_name}",
                attachment_type=allure.attachment_type.PNG,
            )
            return

        with Image.open(baseline_path).convert("RGBA") as img_base, Image.open(
            actual_path_p
        ).convert("RGBA") as img_act:
            if img_base.size != img_act.size:
                if not is_update_mode:
                    raise AssertionError(
                        f"Размеры изображений различаются: baseline={img_base.size}, actual={img_act.size}. "
                        f"Обновите baseline (UPDATE_SNAPSHOTS=1 или update=True)."
                    )
                shutil.copyfile(actual_path_p, baseline_path)
                allure.attach.file(
                    str(actual_path_p),
                    name=f"baseline-updated:{snap_name}",
                    attachment_type=allure.attachment_type.PNG,
                )
                return

            if self.ignore_regions:
                draw_b = ImageDraw.Draw(img_base)
                draw_a = ImageDraw.Draw(img_act)
                for region in self.ignore_regions:
                    if region.width <= 0 or region.height <= 0:
                        continue
                    draw_b.rectangle(
                        [
                            region.x,
                            region.y,
                            region.x + region.width,
                            region.y + region.height,
                        ],
                        fill=(0, 0, 0, 255),
                    )
                    draw_a.rectangle(
                        [
                            region.x,
                            region.y,
                            region.x + region.width,
                            region.y + region.height,
                        ],
                        fill=(0, 0, 0, 255),
                    )

            diff = ImageChops.difference(img_base, img_act).convert("L")
            histogram = diff.histogram()
            if histogram is None:
                raise RuntimeError("Pillow не смог построить histogram() для diff.")
            nonzero = sum(histogram[1:])
            total = diff.size[0] * diff.size[1]
            frac = nonzero / total if total > 0 else 0.0

            if frac <= self.threshold:
                return

            ts = int(time.time() * 1000)
            art_dir = artifacts_dir("screenshots")
            diff_path = art_dir / f"{ts}-diff-{snap_name}"
            diff.save(diff_path)

            allure.attach.file(
                str(baseline_path),
                name=f"baseline:{snap_name}",
                attachment_type=allure.attachment_type.PNG,
            )
            allure.attach.file(
                str(actual_path_p),
                name=f"actual:{snap_name}",
                attachment_type=allure.attachment_type.PNG,
            )
            allure.attach.file(
                str(diff_path),
                name=f"diff:{snap_name}",
                attachment_type=allure.attachment_type.PNG,
            )

            raise AssertionError(
                f"Скриншот не совпадает с baseline: {baseline_path}. "
                f"Доля отличий={frac:.6f}, допустимо <= {self.threshold}. Diff сохранён: {diff_path}"
            )
