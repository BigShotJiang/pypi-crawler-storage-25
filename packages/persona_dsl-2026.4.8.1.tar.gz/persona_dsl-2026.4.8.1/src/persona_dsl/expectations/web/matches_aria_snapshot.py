from __future__ import annotations

import difflib
import shutil
import time
from copy import deepcopy
from pathlib import Path
from typing import TypeAlias

import allure
import yaml

from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona
from persona_dsl.utils.artifacts import artifacts_dir, sanitize_filename
from persona_dsl.utils.path import remove_by_path
from persona_dsl.utils.snapshots import is_snapshot_update_enabled

YamlScalar: TypeAlias = str | int | float | bool | None
YamlValue: TypeAlias = YamlScalar | dict[str, "YamlValue"] | list["YamlValue"]


def _coerce_yaml_value(raw_value: object, *, path: str) -> YamlValue:
    if raw_value is None or isinstance(raw_value, (str, int, float, bool)):
        return raw_value

    if isinstance(raw_value, list):
        return [
            _coerce_yaml_value(item, path=f"{path}[{index}]")
            for index, item in enumerate(raw_value)
        ]

    if isinstance(raw_value, dict):
        result: dict[str, YamlValue] = {}
        for key, value in raw_value.items():
            if not isinstance(key, str):
                raise TypeError(f"{path}: ключ YAML-объекта должен быть строкой.")
            result[key] = _coerce_yaml_value(value, path=f"{path}.{key}")
        return result

    raise TypeError(
        f"{path} содержит неподдерживаемый YAML-тип: {type(raw_value).__name__}."
    )


def _normalize_yaml(value: YamlValue, *, sort_keys: bool) -> YamlValue:
    if isinstance(value, dict):
        normalized_items = (
            sorted(value.items(), key=lambda item: item[0])
            if sort_keys
            else list(value.items())
        )
        return {
            key: _normalize_yaml(inner_value, sort_keys=sort_keys)
            for key, inner_value in normalized_items
        }
    if isinstance(value, list):
        return [_normalize_yaml(item, sort_keys=sort_keys) for item in value]
    return value


def _dump_yaml(value: YamlValue) -> str:
    return yaml.safe_dump(
        value,
        default_flow_style=False,
        allow_unicode=True,
        indent=2,
        sort_keys=False,
    )


class MatchesAriaSnapshot(Expectation):
    """
    Ожидание: ARIA-снепшот (YAML строка) совпадает с baseline (.yaml).
    - baseline ищется по умолчанию в tests/snapshots/<name>.yaml.
    - при отсутствии baseline:
        * если update=True или UPDATE_SNAPSHOTS=1 — baseline создаётся из actual;
        * иначе — ошибка.
    - перед сравнением можно исключить пути (ignore_paths) и нормализовать порядок ключей (sort_keys=True).
    """

    def __init__(
        self,
        snapshot_name: str,
        update: bool = False,
        baseline_dir: str | None = None,
        ignore_paths: list[str] | None = None,
        sort_keys: bool = True,
    ) -> None:
        self.snapshot_name = snapshot_name
        self.update = bool(update)
        self.baseline_dir = baseline_dir
        self.ignore_paths = ignore_paths or []
        self.sort_keys = bool(sort_keys)

    def _get_step_description(self, persona: Persona) -> str:
        return f"совпадает с ARIA-снепшотом '{self.snapshot_name}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if kwargs:
            raise TypeError(
                "MatchesAriaSnapshot не принимает именованные аргументы выполнения."
            )
        if len(args) != 1:
            raise TypeError(
                "MatchesAriaSnapshot требует ровно один позиционный аргумент с YAML-снепшотом."
            )

        actual_value = args[0]
        if not isinstance(actual_value, str):
            raise TypeError(
                f"MatchesAriaSnapshot ожидает YAML строку, получено: {type(actual_value)}"
            )

        try:
            loaded_actual = yaml.safe_load(actual_value)
        except yaml.YAMLError as error:
            raise ValueError(f"Не удалось распарсить YAML снепшот: {error}") from error

        actual_dict = _coerce_yaml_value(loaded_actual, path="actual")

        snap_name = sanitize_filename(self.snapshot_name)
        if not snap_name.lower().endswith((".yaml", ".yml")):
            snap_name += ".yaml"
        base_dir = (
            Path(self.baseline_dir)
            if self.baseline_dir is not None
            else (Path.cwd() / "tests" / "snapshots")
        )
        baseline_path = base_dir / snap_name

        def prepare(value: YamlValue) -> YamlValue:
            prepared = deepcopy(value)
            for path in self.ignore_paths:
                remove_by_path(prepared, path, strict=True)
            return _normalize_yaml(prepared, sort_keys=self.sort_keys)

        actual_norm = prepare(actual_dict)
        actual_yaml = _dump_yaml(actual_norm)
        is_update_mode = is_snapshot_update_enabled(
            persona, explicit_update=self.update
        )

        if not baseline_path.exists():
            if not is_update_mode:
                raise AssertionError(
                    f"ARIA baseline не найден: {baseline_path}. "
                    f"Запустите с UPDATE_SNAPSHOTS=1 или установите update=True для создания baseline."
                )

            baseline_path.parent.mkdir(parents=True, exist_ok=True)
            baseline_path.write_text(actual_yaml, encoding="utf-8")
            allure.attach(
                actual_yaml,
                name=f"baseline-created:{snap_name}",
                attachment_type=allure.attachment_type.TEXT,
            )
            return

        try:
            loaded_baseline = yaml.safe_load(baseline_path.read_text(encoding="utf-8"))
        except yaml.YAMLError as error:
            raise AssertionError(
                f"Не удалось прочитать baseline YAML {baseline_path}: {error}"
            ) from error

        base_norm = prepare(_coerce_yaml_value(loaded_baseline, path="baseline"))
        base_yaml = _dump_yaml(base_norm)

        if base_norm == actual_norm:
            return

        if is_update_mode:
            backup_path = baseline_path.with_suffix(".bak.yaml")
            shutil.copyfile(baseline_path, backup_path)
            baseline_path.write_text(actual_yaml, encoding="utf-8")
            allure.attach(
                actual_yaml,
                name=f"baseline-updated:{snap_name}",
                attachment_type=allure.attachment_type.TEXT,
            )
            return

        ts = int(time.time() * 1000)
        art_dir = artifacts_dir("snapshots")
        actual_path = art_dir / f"{ts}-actual-{snap_name}"
        diff_path = art_dir / f"{ts}-diff-{snap_name}.diff"

        actual_path.write_text(actual_yaml, encoding="utf-8")
        udiff = "".join(
            difflib.unified_diff(
                base_yaml.splitlines(keepends=True),
                actual_yaml.splitlines(keepends=True),
                fromfile="baseline",
                tofile="actual",
            )
        )
        diff_path.write_text(udiff, encoding="utf-8")

        allure.attach.file(
            str(baseline_path),
            name=f"baseline:{snap_name}",
            attachment_type=allure.attachment_type.TEXT,
        )
        allure.attach.file(
            str(actual_path),
            name=f"actual:{snap_name}",
            attachment_type=allure.attachment_type.TEXT,
        )
        allure.attach(
            udiff,
            name=f"diff:{snap_name}",
            attachment_type=allure.attachment_type.TEXT,
        )

        raise AssertionError(
            f"ARIA YAML не совпадает с baseline: {baseline_path}. Diff: {diff_path}"
        )
