from __future__ import annotations

from typing import TYPE_CHECKING

from .builder import SchemaBuilder
from .registry import (
    SchemaMessageCodec,
    deserialize_registered_payload,
    register_message_codec,
    registered_message_codecs,
    serialize_registered_model,
)

if TYPE_CHECKING:
    from .xml import XmlModelBinding, XmlModelCodec, register_xml_binding


def __getattr__(name: str) -> object:
    if name in {"XmlModelBinding", "XmlModelCodec", "register_xml_binding"}:
        from .xml import XmlModelBinding, XmlModelCodec, register_xml_binding

        return {
            "XmlModelBinding": XmlModelBinding,
            "XmlModelCodec": XmlModelCodec,
            "register_xml_binding": register_xml_binding,
        }[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "SchemaBuilder",
    "SchemaMessageCodec",
    "XmlModelBinding",
    "XmlModelCodec",
    "register_message_codec",
    "registered_message_codecs",
    "serialize_registered_model",
    "deserialize_registered_payload",
    "register_xml_binding",
]
