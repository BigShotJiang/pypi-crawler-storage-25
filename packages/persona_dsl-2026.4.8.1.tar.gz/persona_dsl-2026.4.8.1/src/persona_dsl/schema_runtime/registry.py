from __future__ import annotations

from collections.abc import Mapping
from types import MappingProxyType
from typing import Protocol, TypeVar

ModelT = TypeVar("ModelT")


class SchemaMessageCodec(Protocol):
    """Контракт codec для сериализации/десериализации schema-first моделей."""

    def serialize(self, value: object) -> bytes: ...

    def deserialize(self, payload: bytes, model_type: type[object]) -> object: ...


_CODECS_BY_TYPE: dict[type[object], SchemaMessageCodec] = {}


def register_message_codec(model_type: type[object], codec: SchemaMessageCodec) -> None:
    if not isinstance(model_type, type):
        raise TypeError("model_type должен быть типом Python.")
    _CODECS_BY_TYPE[model_type] = codec


def registered_message_codecs() -> Mapping[type[object], SchemaMessageCodec]:
    return MappingProxyType(_CODECS_BY_TYPE)


def _find_registered_codec(model_type: type[object]) -> SchemaMessageCodec:
    codec = _CODECS_BY_TYPE.get(model_type)
    if codec is not None:
        return codec

    for registered_type, registered_codec in _CODECS_BY_TYPE.items():
        if issubclass(model_type, registered_type):
            return registered_codec

    raise LookupError(
        f"Для типа '{model_type.__name__}' не зарегистрирован schema codec."
    )


def serialize_registered_model(value: object) -> bytes:
    model_type = type(value)
    codec = _find_registered_codec(model_type)
    return codec.serialize(value)


def deserialize_registered_payload(payload: bytes, model_type: type[ModelT]) -> ModelT:
    codec = _find_registered_codec(model_type)
    result = codec.deserialize(payload, model_type)
    if not isinstance(result, model_type):
        raise TypeError(
            f"Codec для '{model_type.__name__}' вернул несовместимый тип "
            f"'{type(result).__name__}'."
        )
    return result
