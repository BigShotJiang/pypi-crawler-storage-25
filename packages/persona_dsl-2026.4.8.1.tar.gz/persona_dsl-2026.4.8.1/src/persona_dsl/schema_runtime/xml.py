from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import xmlschema
from xsdata.formats.dataclass.parsers import XmlParser
from xsdata.formats.dataclass.serializers import XmlSerializer
from xsdata.formats.dataclass.serializers.config import SerializerConfig
from xsdata.formats.dataclass.serializers.writers import XmlEventWriter

from .registry import register_message_codec


@dataclass(frozen=True)
class XmlModelBinding:
    model_type: type[object]
    schema_path: Path
    root_name: str


@lru_cache(maxsize=None)
def _load_schema(schema_path: str) -> xmlschema.XMLSchema:
    return xmlschema.XMLSchema(schema_path)


class XmlModelCodec:
    """Codec XML-сообщений для schema-first dataclass моделей."""

    def __init__(self, binding: XmlModelBinding) -> None:
        self.binding = binding
        self._serializer = XmlSerializer(
            config=SerializerConfig(
                encoding="UTF-8",
                xml_declaration=True,
                pretty_print=False,
            ),
            writer=XmlEventWriter,
        )
        self._parser = XmlParser()

    def serialize(self, value: object) -> bytes:
        if not isinstance(value, self.binding.model_type):
            raise TypeError(
                f"XmlModelCodec ожидает '{self.binding.model_type.__name__}', "
                f"получено '{type(value).__name__}'."
            )

        xml_text = self._serializer.render(value)
        payload = xml_text.encode("utf-8")
        self.validate(payload)
        return payload

    def deserialize(self, payload: bytes, model_type: type[object]) -> object:
        if not issubclass(model_type, self.binding.model_type):
            raise TypeError(
                f"XmlModelCodec для '{self.binding.model_type.__name__}' не может "
                f"десериализовать '{model_type.__name__}'."
            )

        self.validate(payload)
        return self._parser.from_bytes(payload, model_type)

    def validate(self, payload: bytes) -> None:
        schema = _load_schema(str(self.binding.schema_path))
        try:
            schema.validate(payload)
        except xmlschema.XMLSchemaValidationError as error:
            raise ValueError(
                f"XML payload не соответствует XSD '{self.binding.schema_path}': {error}"
            ) from error


def register_xml_binding(
    model_type: type[object],
    schema_path: str | Path,
    root_name: str,
) -> XmlModelBinding:
    schema_file = Path(schema_path).resolve()
    if not schema_file.exists():
        raise FileNotFoundError(f"XSD схема не найдена: {schema_file}")

    binding = XmlModelBinding(
        model_type=model_type,
        schema_path=schema_file,
        root_name=root_name,
    )
    register_message_codec(model_type, XmlModelCodec(binding))
    return binding
