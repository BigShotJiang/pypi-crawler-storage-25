from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import Field, MISSING, is_dataclass
from decimal import Decimal, InvalidOperation
from enum import Enum
import types
from typing import Generic, TypeVar, Union, get_args, get_origin, get_type_hints

ModelT = TypeVar("ModelT")


def _path(base: str, field_name: str) -> str:
    return f"{base}.{field_name}" if base else field_name


def _list_path(base: str, index: int) -> str:
    return f"{base}[{index}]"


def _model_hints(model_type: type[object]) -> dict[str, object]:
    return get_type_hints(model_type)


def _unwrap_optional(annotation: object) -> tuple[object, bool]:
    origin = get_origin(annotation)
    if origin not in (Union, types.UnionType):
        return annotation, False

    args = [item for item in get_args(annotation) if item is not type(None)]
    if len(args) != 1:
        raise TypeError(f"Неподдерживаемый union-аннотация: {annotation!r}")
    return args[0], True


def _list_item_type(annotation: object) -> object | None:
    origin = get_origin(annotation)
    if origin is not list:
        return None

    args = get_args(annotation)
    if len(args) != 1:
        raise TypeError(f"Список должен содержать ровно один тип: {annotation!r}")
    item_type: object = args[0]
    return item_type


def _dataclass_fields(model_type: type[object]) -> tuple[Field[object], ...]:
    raw_fields = getattr(model_type, "__dataclass_fields__", None)
    if not isinstance(raw_fields, dict):
        raise TypeError(
            f"SchemaBuilder ожидает dataclass тип, получено '{model_type!r}'."
        )

    result: list[Field[object]] = []
    for field_info in raw_fields.values():
        if not isinstance(field_info, Field):
            raise TypeError(
                f"Dataclass '{model_type.__name__}' содержит некорректное поле '{field_info!r}'."
            )
        result.append(field_info)
    return tuple(result)


def _coerce_primitive(expected_type: type[object], value: object, path: str) -> object:
    if expected_type is object:
        return value
    if expected_type is bool:
        if type(value) is not bool:
            raise TypeError(
                f"Поле '{path}' ожидает bool, получено '{type(value).__name__}'."
            )
        return value
    if expected_type is int:
        if not isinstance(value, int) or isinstance(value, bool):
            raise TypeError(
                f"Поле '{path}' ожидает int, получено '{type(value).__name__}'."
            )
        return value
    if expected_type is float:
        if not isinstance(value, float):
            raise TypeError(
                f"Поле '{path}' ожидает float, получено '{type(value).__name__}'."
            )
        return value
    if expected_type is str:
        if not isinstance(value, str):
            raise TypeError(
                f"Поле '{path}' ожидает str, получено '{type(value).__name__}'."
            )
        return value
    raise TypeError(
        f"Неподдерживаемый примитивный тип поля '{path}': {expected_type!r}"
    )


def _coerce_runtime_scalar(
    expected_type: type[object], value: object, path: str
) -> object:
    if expected_type is Decimal:
        if isinstance(value, Decimal):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return Decimal(value)
        if isinstance(value, str):
            try:
                return Decimal(value)
            except (InvalidOperation, ValueError, TypeError) as error:
                raise TypeError(
                    f"Поле '{path}' ожидает Decimal, получено {value!r}."
                ) from error
        raise TypeError(
            f"Поле '{path}' ожидает Decimal, получено '{type(value).__name__}'."
        )

    if isinstance(value, expected_type):
        return value

    from_string = getattr(expected_type, "from_string", None)
    if callable(from_string) and isinstance(value, str):
        try:
            return from_string(value)
        except (ValueError, TypeError) as error:
            raise TypeError(
                f"Поле '{path}' ожидает значение типа '{expected_type.__qualname__}', "
                f"получено {value!r}."
            ) from error

    raise TypeError(
        f"Поле '{path}' ожидает '{expected_type.__qualname__}', "
        f"получено '{type(value).__name__}'."
    )


class SchemaBuilder(Generic[ModelT]):
    """Базовый builder для schema-first dataclass моделей."""

    def __init__(
        self,
        model_type: type[ModelT],
        project_defaults_factory: Callable[[], Mapping[str, object]] | None = None,
    ) -> None:
        if not is_dataclass(model_type):
            raise TypeError(
                f"SchemaBuilder ожидает dataclass тип, получено '{model_type!r}'."
            )
        self._model_type = model_type
        self._project_defaults_factory = project_defaults_factory
        self._assigned_values: dict[str, object] = {}
        self._appended_values: dict[str, list[object]] = {}

    def _set(self, field_name: str, value: object) -> None:
        self._assigned_values[field_name] = value

    def _append(self, field_name: str, value: object) -> None:
        self._appended_values.setdefault(field_name, []).append(value)

    def build(self) -> ModelT:
        return self._build_at_path(self._model_type.__name__)

    def _build_at_path(self, path: str) -> ModelT:
        project_defaults = (
            self._project_defaults_factory() if self._project_defaults_factory else {}
        )
        if not isinstance(project_defaults, Mapping):
            raise TypeError(
                f"Project defaults для '{self._model_type.__name__}' должны быть Mapping."
            )

        field_names = {
            field_info.name for field_info in _dataclass_fields(self._model_type)
        }
        unknown_defaults = set(project_defaults) - field_names
        if unknown_defaults:
            unknown = ", ".join(sorted(unknown_defaults))
            raise KeyError(
                f"Project defaults для '{self._model_type.__name__}' содержат неизвестные поля: {unknown}"
            )

        unknown_assigned = set(self._assigned_values) - field_names
        if unknown_assigned:
            unknown = ", ".join(sorted(unknown_assigned))
            raise KeyError(
                f"Builder '{self._model_type.__name__}' содержит неизвестные поля: {unknown}"
            )

        unknown_appended = set(self._appended_values) - field_names
        if unknown_appended:
            unknown = ", ".join(sorted(unknown_appended))
            raise KeyError(
                f"Builder '{self._model_type.__name__}' содержит неизвестные list-поля: {unknown}"
            )

        type_hints = _model_hints(self._model_type)
        kwargs: dict[str, object] = {}

        for field_info in _dataclass_fields(self._model_type):
            field_path = _path(path, field_info.name)
            annotation = type_hints[field_info.name]
            item_type = _list_item_type(annotation)

            if item_type is not None:
                base_items: list[object]
                if field_info.name in self._assigned_values:
                    assigned_value = self._assigned_values[field_info.name]
                    if not isinstance(assigned_value, list):
                        raise TypeError(
                            f"Поле '{field_path}' ожидает list, получено '{type(assigned_value).__name__}'."
                        )
                    base_items = list(assigned_value)
                elif field_info.name in project_defaults:
                    project_value = project_defaults[field_info.name]
                    if not isinstance(project_value, list):
                        raise TypeError(
                            f"Project default '{field_path}' должен быть list, получено '{type(project_value).__name__}'."
                        )
                    base_items = [item for item in project_value]
                elif field_info.default_factory is not MISSING:
                    default_items = field_info.default_factory()
                    if not isinstance(default_items, list):
                        raise TypeError(
                            f"Поле '{field_path}' ожидает list default_factory, "
                            f"получено '{type(default_items).__name__}'."
                        )
                    base_items = [item for item in default_items]
                else:
                    base_items = []

                items = base_items + self._appended_values.get(field_info.name, [])
                kwargs[field_info.name] = [
                    self._coerce_value(item_type, item, _list_path(field_path, index))
                    for index, item in enumerate(items)
                ]
                continue

            if field_info.name in self._assigned_values:
                raw_value = self._assigned_values[field_info.name]
            elif field_info.name in project_defaults:
                raw_value = project_defaults[field_info.name]
            elif field_info.default is not MISSING:
                raw_value = field_info.default
            elif field_info.default_factory is not MISSING:
                raw_value = field_info.default_factory()
            else:
                raise ValueError(
                    f"Не задано обязательное поле '{field_path}' для '{self._model_type.__name__}'."
                )

            kwargs[field_info.name] = self._coerce_value(
                annotation,
                raw_value,
                field_path,
            )

        return self._model_type(**kwargs)

    def _coerce_value(self, annotation: object, value: object, path: str) -> object:
        target_type, optional = _unwrap_optional(annotation)
        if value is None:
            if optional:
                return None
            raise TypeError(f"Поле '{path}' обязательно и не может быть None.")

        if isinstance(value, SchemaBuilder):
            return value._build_at_path(path)

        list_item_type = _list_item_type(target_type)
        if list_item_type is not None:
            if not isinstance(value, list):
                raise TypeError(
                    f"Поле '{path}' ожидает list, получено '{type(value).__name__}'."
                )
            return [
                self._coerce_value(list_item_type, item, _list_path(path, index))
                for index, item in enumerate(value)
            ]

        if isinstance(target_type, type) and is_dataclass(target_type):
            if isinstance(value, target_type):
                return value
            raise TypeError(
                f"Поле '{path}' ожидает '{target_type.__name__}', получено '{type(value).__name__}'."
            )

        if isinstance(target_type, type) and issubclass(target_type, Enum):
            if isinstance(value, target_type):
                return value
            try:
                return target_type(value)
            except ValueError as error:
                raise TypeError(
                    f"Поле '{path}' ожидает одно из значений enum '{target_type.__name__}', "
                    f"получено {value!r}."
                ) from error

        if isinstance(target_type, type):
            if target_type in {str, int, float, bool, object}:
                return _coerce_primitive(target_type, value, path)
            return _coerce_runtime_scalar(target_type, value, path)

        raise TypeError(f"Неподдерживаемый тип поля '{path}': {target_type!r}")
