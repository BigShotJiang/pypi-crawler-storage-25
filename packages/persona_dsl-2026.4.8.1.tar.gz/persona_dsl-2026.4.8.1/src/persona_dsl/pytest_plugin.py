from __future__ import annotations
import functools
import json
import logging
import os
import time
import sys
from collections.abc import Callable, Generator, Iterable, Mapping, Sequence
from enum import Enum
from contextlib import contextmanager
from functools import lru_cache
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Literal,
    NoReturn,
    Protocol,
    TypeAlias,
    TypedDict,
    runtime_checkable,
)
from urllib.parse import urlparse

import allure
import requests
import pytest
import yaml
from pluggy import Result as HookResult

from .contracts import RetryPolicyConfig, capture_outcome

if TYPE_CHECKING:
    from playwright.sync_api import (
        Browser,
        BrowserContext,
        BrowserType,
        Playwright,
    )

    from persona_dsl.persona import Persona
    from persona_dsl.skills.use_api import UseAPI
    from persona_dsl.skills.use_browser import UseBrowser
    from persona_dsl.skills.use_database import UseDatabase
    from persona_dsl.skills.use_kafka import UseKafka
    from persona_dsl.skills.use_soap import UseSOAP
    from persona_dsl.utils.config import Config

logger = logging.getLogger(__name__)

ConfigMapping: TypeAlias = dict[str, object]
ScenarioData: TypeAlias = dict[str, object]
RetryConfigMap: TypeAlias = dict[str, RetryPolicyConfig]
PluginSkillInstance: TypeAlias = (
    "UseBrowser | UseAPI | UseDatabase | UseKafka | UseSOAP"
)


class SelenoidSessionInfo(TypedDict):
    url: str
    id: str


class ResourceRegistry(TypedDict, total=False):
    playwright: Playwright
    browser: Browser
    browser_contexts: dict[str, BrowserContext]
    selenoid_sessions: list[SelenoidSessionInfo]


@runtime_checkable
class SupportsStop(Protocol):
    def stop(self) -> None: ...


@runtime_checkable
class TestCallable(Protocol):
    def __call__(self, *args: object, **kwargs: object) -> object: ...


class AddOptionParserContext(Protocol):
    def addoption(self, *args: object, **kwargs: object) -> None: ...


class ConfigureContext(Protocol):
    def addinivalue_line(self, key: str, value: str) -> None: ...

    def getoption(self, name: str) -> object: ...


class RequestNodeContext(Protocol):
    @property
    def name(self) -> str: ...


class FixtureRequestContext(Protocol):
    @property
    def node(self) -> RequestNodeContext | None: ...


def _fail(message: str) -> NoReturn:
    pytest.fail(message, pytrace=False)


def _normalize_identifier(raw_value: object, *, label: str) -> str:
    if isinstance(raw_value, str):
        return raw_value

    if isinstance(raw_value, Enum):
        enum_value = raw_value.value
        if not isinstance(enum_value, str):
            raise TypeError(f"{label} должен содержать строковое значение.")
        return enum_value

    value_attr = getattr(raw_value, "value", None)
    if isinstance(value_attr, str):
        return value_attr

    _fail(f"{label} должен быть строкой или Enum со строковым value.")


def _require_mapping(raw_value: object, *, path: str) -> ConfigMapping:
    if not isinstance(raw_value, dict):
        _fail(
            f"Значение '{path}' должно быть словарём, получено: {type(raw_value).__name__}"
        )
    return dict(raw_value)


def _get_mapping(
    mapping: Mapping[str, object], key: str, *, path: str
) -> ConfigMapping | None:
    raw_value = mapping.get(key)
    if raw_value is None:
        return None
    return _require_mapping(raw_value, path=f"{path}.{key}")


def _get_optional_str(
    mapping: Mapping[str, object], key: str, *, path: str
) -> str | None:
    raw_value = mapping.get(key)
    if raw_value is None:
        return None
    if not isinstance(raw_value, str):
        _fail(
            f"Значение '{path}.{key}' должно быть строкой, получено: {type(raw_value).__name__}"
        )
    return raw_value


def _get_required_str(mapping: Mapping[str, object], key: str, *, path: str) -> str:
    value = _get_optional_str(mapping, key, path=path)
    if not value:
        _fail(f"Значение '{path}.{key}' должно быть непустой строкой.")
    return value


def _get_bool(
    mapping: Mapping[str, object], key: str, *, path: str, default: bool
) -> bool:
    raw_value = mapping.get(key)
    if raw_value is None:
        return default
    if not isinstance(raw_value, bool):
        _fail(
            f"Значение '{path}.{key}' должно быть bool, получено: {type(raw_value).__name__}"
        )
    return raw_value


def _get_int(
    mapping: Mapping[str, object], key: str, *, path: str, default: int
) -> int:
    raw_value = mapping.get(key)
    if raw_value is None:
        return default
    if not isinstance(raw_value, int) or isinstance(raw_value, bool):
        _fail(
            f"Значение '{path}.{key}' должно быть int, получено: {type(raw_value).__name__}"
        )
    return raw_value


def _get_float(
    mapping: Mapping[str, object], key: str, *, path: str, default: float
) -> float:
    raw_value = mapping.get(key)
    if raw_value is None:
        return default
    if isinstance(raw_value, bool) or not isinstance(raw_value, (int, float)):
        _fail(
            f"Значение '{path}.{key}' должно быть числом, получено: {type(raw_value).__name__}"
        )
    return float(raw_value)


def _get_optional_float(
    mapping: Mapping[str, object], key: str, *, path: str
) -> float | None:
    raw_value = mapping.get(key)
    if raw_value is None:
        return None
    if isinstance(raw_value, bool) or not isinstance(raw_value, (int, float)):
        _fail(
            f"Значение '{path}.{key}' должно быть числом, получено: {type(raw_value).__name__}"
        )
    return float(raw_value)


def _get_string_list(
    mapping: Mapping[str, object], key: str, *, path: str
) -> list[str]:
    raw_value = mapping.get(key)
    if raw_value is None:
        return []
    if not isinstance(raw_value, list):
        _fail(
            f"Значение '{path}.{key}' должно быть списком строк, получено: {type(raw_value).__name__}"
        )
    values: list[str] = []
    for index, item in enumerate(raw_value):
        if not isinstance(item, str):
            _fail(
                f"Значение '{path}.{key}[{index}]' должно быть строкой, получено: {type(item).__name__}"
            )
        values.append(item)
    return values


def _get_optional_string_mapping(
    mapping: Mapping[str, object], key: str, *, path: str
) -> dict[str, str] | None:
    raw_value = mapping.get(key)
    if raw_value is None:
        return None
    if not isinstance(raw_value, dict):
        _fail(
            f"Значение '{path}.{key}' должно быть словарём строк, получено: {type(raw_value).__name__}"
        )
    result: dict[str, str] = {}
    for inner_key, inner_value in raw_value.items():
        if not isinstance(inner_key, str):
            _fail(
                f"Ключ '{path}.{key}' должен быть строкой, получено: {type(inner_key).__name__}"
            )
        if not isinstance(inner_value, str):
            _fail(
                f"Значение '{path}.{key}.{inner_key}' должно быть строкой, получено: {type(inner_value).__name__}"
            )
        result[inner_key] = inner_value
    return result


def _get_retry_backoff_mode(
    mapping: Mapping[str, object],
    key: str,
    *,
    path: str,
    default: Literal["linear", "exp"],
) -> Literal["linear", "exp"]:
    raw_value = mapping.get(key)
    if raw_value is None:
        return default
    if raw_value == "linear":
        return "linear"
    if raw_value == "exp":
        return "exp"
    _fail(
        f"Значение '{path}.{key}' должно быть 'linear' или 'exp', получено: {raw_value!r}"
    )


def _coerce_retry_policy_config(raw_value: object, *, path: str) -> RetryPolicyConfig:
    mapping = _require_mapping(raw_value, path=path)
    unsupported_keys = {
        key
        for key in mapping
        if key
        not in {"max_attempts", "delay", "backoff_mode", "backoff_factor", "jitter"}
    }
    if unsupported_keys:
        unsupported = ", ".join(sorted(unsupported_keys))
        _fail(
            f"Конфигурация '{path}' содержит неподдерживаемые ключи: {unsupported}. "
            "В YAML допускаются только max_attempts, delay, backoff_mode, backoff_factor, jitter."
        )

    config: RetryPolicyConfig = {}
    if "max_attempts" in mapping:
        config["max_attempts"] = _get_int(mapping, "max_attempts", path=path, default=1)
    if "delay" in mapping:
        config["delay"] = _get_float(mapping, "delay", path=path, default=0.0)
    if "backoff_mode" in mapping:
        config["backoff_mode"] = _get_retry_backoff_mode(
            mapping, "backoff_mode", path=path, default="exp"
        )
    if "backoff_factor" in mapping:
        config["backoff_factor"] = _get_float(
            mapping, "backoff_factor", path=path, default=1.0
        )
    if "jitter" in mapping:
        config["jitter"] = _get_float(mapping, "jitter", path=path, default=0.0)
    return config


def _get_retry_configs(raw_retries: Mapping[str, object]) -> RetryConfigMap:
    retry_configs: RetryConfigMap = {}
    for retry_name, retry_value in raw_retries.items():
        retry_configs[retry_name] = _coerce_retry_policy_config(
            retry_value, path=f"retries.{retry_name}"
        )
    return retry_configs


def _require_plugin_skill_instance(
    value: object, *, skill_name: str
) -> PluginSkillInstance:
    from persona_dsl.skills.use_api import UseAPI
    from persona_dsl.skills.use_browser import UseBrowser
    from persona_dsl.skills.use_database import UseDatabase
    from persona_dsl.skills.use_kafka import UseKafka
    from persona_dsl.skills.use_soap import UseSOAP

    if isinstance(value, (UseBrowser, UseAPI, UseDatabase, UseKafka, UseSOAP)):
        return value
    raise TypeError(
        f"Навык '{skill_name}' должен быть экземпляром поддерживаемого Skill-класса, "
        f"получено: {type(value).__name__}."
    )


def _launch_browser_instance(
    browser_type: BrowserType,
    *,
    headless: bool,
    slow_mo: float,
    timeout: float,
    executable_path: str | None,
    args: list[str],
    channel: str | None,
) -> Browser:
    return browser_type.launch(
        headless=headless,
        slow_mo=slow_mo,
        timeout=timeout,
        executable_path=executable_path,
        args=args or None,
        channel=channel,
    )


def _create_browser_context(
    browser: Browser,
    *,
    ignore_https_errors: bool,
    base_url: str | None,
    is_maximized: bool,
    is_headless: bool,
    viewport: Mapping[str, object] | None,
    cfg_path: str,
) -> BrowserContext:
    if is_maximized and not is_headless:
        return browser.new_context(
            ignore_https_errors=ignore_https_errors,
            base_url=base_url,
            no_viewport=True,
        )

    if viewport is not None:
        width = _get_int(
            viewport,
            "width",
            path=f"{cfg_path}.viewport",
            default=-1,
        )
        height = _get_int(
            viewport,
            "height",
            path=f"{cfg_path}.viewport",
            default=-1,
        )
        if width <= 0 or height <= 0:
            pytest.fail(
                f"Значения '{cfg_path}.viewport.width' и '{cfg_path}.viewport.height' должны быть положительными целыми числами.",
                pytrace=False,
            )
        return browser.new_context(
            ignore_https_errors=ignore_https_errors,
            base_url=base_url,
            viewport={"width": width, "height": height},
        )

    return browser.new_context(
        ignore_https_errors=ignore_https_errors,
        base_url=base_url,
    )


def _require_kafka_offset(
    mapping: Mapping[str, object], *, path: str
) -> Literal["earliest", "latest"]:
    raw_value = _get_optional_str(mapping, "from_offset", path=path)
    if raw_value is None or raw_value == "latest":
        return "latest"
    if raw_value == "earliest":
        return "earliest"
    pytest.fail(
        f"Конфигурация '{path}.from_offset' должна быть 'earliest' или 'latest'.",
        pytrace=False,
    )


def _require_test_callable(item: pytest.Item) -> TestCallable:
    raw_obj: object = getattr(item, "obj", None)
    if raw_obj is None or not isinstance(raw_obj, TestCallable):
        raise TypeError("pytest item должен предоставлять вызываемый атрибут obj.")
    return raw_obj


def _extract_session_id(payload: object) -> str:
    if not isinstance(payload, dict):
        raise RuntimeError(
            "Selenoid вернул некорректный ответ: верхний уровень должен быть словарём."
        )

    value_block = payload.get("value")
    if value_block is not None and not isinstance(value_block, dict):
        raise RuntimeError("Поле 'value' в ответе Selenoid должно быть словарём.")

    if isinstance(value_block, dict):
        value_session_id = value_block.get("sessionId")
        if isinstance(value_session_id, str) and value_session_id:
            return value_session_id

    root_session_id = payload.get("sessionId")
    if isinstance(root_session_id, str) and root_session_id:
        return root_session_id

    raise RuntimeError(f"Selenoid не вернул sessionId: {payload}")


def _require_browser_type(playwright: Playwright, browser_name: str) -> BrowserType:
    if browser_name == "chromium":
        return playwright.chromium
    if browser_name == "firefox":
        return playwright.firefox
    if browser_name == "webkit":
        return playwright.webkit
    if browser_name == "sberbrowser":
        return playwright.chromium
    raise ValueError(
        "Поддерживаемые значения 'skills.browser.<name>.type': chromium, firefox, webkit, sberbrowser."
    )


class DataDrivenError(Exception):
    """Кастомное исключение для ошибок в @data_driven."""

    pass


def _taas_ready() -> bool:
    """
    Проверяет, корректно ли сконфигурирован контекст TaaS:
    - установлен TAAS_RUN_ID
    - TAAS_STREAM_MAXLEN является положительным целым
    """
    if not os.environ.get("TAAS_RUN_ID"):
        return False
    raw = os.getenv("TAAS_STREAM_MAXLEN", "10000")
    try:
        return int(raw) > 0
    except ValueError:
        return False


# --- Allure Step Instrumentation ---
_original_allure_step = allure.step


@contextmanager
def _instrumented_allure_step(description: str) -> Generator[object, None, None]:
    """Обертка над allure.step, которая отправляет события в TaaS."""
    from .utils.taas_integration import publish_taas_event

    start_time = time.time()
    publish_taas_event(
        {
            "event": "step_start",
            "type": "allure_step",
            "data": {"description": description, "timestamp": start_time},
        }
    )

    status = "passed"
    try:
        with _original_allure_step(description) as s:
            yield s
    finally:
        exc_type, _, _ = sys.exc_info()
        if exc_type is not None:
            status = "failed"
        end_time = time.time()
        duration = end_time - start_time
        publish_taas_event(
            {
                "event": "step_end",
                "type": "allure_step",
                "data": {
                    "description": description,
                    "timestamp": end_time,
                    "duration": duration,
                    "status": status,
                },
            }
        )


# --- End Allure Step Instrumentation ---


def _get_skill_config(
    config: Config, skill_type: str, name: str
) -> ConfigMapping | None:
    stype_config = config.skills.get(skill_type)
    if stype_config is None:
        return None
    if not isinstance(stype_config, dict):
        raise TypeError(
            f"Конфигурация 'skills.{skill_type}' должна быть словарём, получено: {type(stype_config).__name__}"
        )

    if name == "default":
        return _get_mapping(stype_config, "default", path=f"skills.{skill_type}")

    return _get_mapping(stype_config, name, path=f"skills.{skill_type}")


def _create_selenoid_session(
    hub_url: str,
    capabilities: ConfigMapping,
    retries: int = 3,
    timeout: float = 10.0,
) -> tuple[str, str]:
    """
    Создает сессию в Selenoid через WebDriver API с повторными попытками.
    Возвращает кортеж (ws_endpoint, session_id).
    """
    session_url = f"{hub_url.rstrip('/')}/wd/hub/session"
    last_error: Exception | None = None

    for attempt in range(retries + 1):
        try:
            logger.info(
                f"Попытка создания сессии Selenoid ({attempt + 1}/{retries + 1})..."
            )
            # requests imported at module level
            resp = requests.post(
                session_url, json={"capabilities": capabilities}, timeout=timeout
            )
            if resp.status_code == 200:
                session_id = _extract_session_id(resp.json())

                # Формируем WS URL для CDP
                parsed = urlparse(hub_url)
                ws_scheme = "wss" if parsed.scheme == "https" else "ws"
                ws_endpoint = f"{ws_scheme}://{parsed.netloc}/devtools/{session_id}"

                logger.info(f"Сессия Selenoid создана: {session_id}")
                return ws_endpoint, session_id
            else:
                logger.warning(
                    f"Ошибка создания сессии Selenoid (Code {resp.status_code}): {resp.text}"
                )
        except (requests.RequestException, RuntimeError, ValueError) as error:
            last_error = error
            logger.warning("Ошибка подключения к Selenoid: %s", error)

        if attempt < retries:
            time.sleep(2.0)

    raise RuntimeError(
        f"Не удалось создать сессию Selenoid после {retries + 1} попыток. Последняя ошибка: {last_error}"
    )


def _get_persona_config(config: Config, role: str) -> ConfigMapping | None:
    personas_config = config.personas
    return _get_mapping(
        personas_config, "default" if role == "default" else role, path="personas"
    )


def _build_chromium_args(cfg: Mapping[str, object], *, path: str) -> list[str]:
    """Строит список аргументов командной строки для Chromium-based браузеров."""
    args = _get_string_list(cfg, "args", path=path)

    if _get_bool(cfg, "no_sandbox", path=path, default=False):
        args.append("--no-sandbox")

    disable_features = _get_string_list(cfg, "disable_features", path=path)

    if _get_bool(cfg, "ignore_https_errors", path=path, default=False):
        args.append("--ignore-certificate-errors")
        # Отключаем принудительное обновление до HTTPS и связанные с ним предупреждения
        if "HttpsUpgrades" not in disable_features:
            disable_features.append("HttpsUpgrades")
        if "EnforceHttps" not in disable_features:
            disable_features.append("EnforceHttps")

        # Для HTTP сайтов отключаем предупреждения о небезопасности
        base_url = _get_optional_str(cfg, "base_url", path=path)
        if base_url:
            parsed_url = urlparse(base_url)
            if parsed_url.scheme == "http":
                origin = f"{parsed_url.scheme}://{parsed_url.netloc}"
                args.append(f"--unsafely-treat-insecure-origin-as-secure={origin}")

    if _get_bool(cfg, "start_maximized", path=path, default=False):
        args.append("--start-maximized")

    if disable_features:
        features_str = ",".join(disable_features)
        args.append(f"--disable-features={features_str}")

    return args


def _require_test_id(scenario: Mapping[str, object], *, index: int) -> str:
    raw_test_id = scenario.get("test_id")
    if not isinstance(raw_test_id, str) or not raw_test_id:
        _fail(
            "@data_driven: каждая вариация должна содержать непустое строковое поле "
            f"'test_id'. Ошибка в индексе: {index}"
        )
    return raw_test_id


class PersonaSession:
    def __init__(
        self,
        config: Config,
        persona_class: type[Persona],
        request: FixtureRequestContext,
    ) -> None:
        self.config = config
        self.persona_class = persona_class
        self.request = request
        self._personas: dict[str, Persona] = {}
        self._resources: ResourceRegistry = {}

    def get(self, role_id: str | Enum = "default") -> Persona:
        role_id_str = _normalize_identifier(role_id, label="Идентификатор роли")
        if role_id_str not in self._personas:
            persona_cfg = _get_persona_config(self.config, role_id_str)
            if persona_cfg is None:
                pytest.fail(
                    f"Конфигурация для роли '{role_id_str}' не найдена в 'config/{self.config.env}.yaml'",
                    pytrace=False,
                )

            persona_name_raw = persona_cfg.get("name")
            if persona_name_raw is None:
                persona_name = "Персона"
            elif isinstance(persona_name_raw, str) and persona_name_raw:
                persona_name = persona_name_raw
            else:
                pytest.fail(
                    f"Поле 'personas.{role_id_str}.name' должно быть непустой строкой.",
                    pytrace=False,
                )

            new_persona = self.persona_class(name=persona_name)
            new_persona.role_id = role_id_str
            new_persona.params = dict(persona_cfg)
            new_persona.params["update_snapshots"] = self.config.update_snapshots

            auth_key = persona_cfg.get("auth_key")
            if auth_key is None:
                new_persona.secrets = {}
            else:
                if not isinstance(auth_key, str) or not auth_key:
                    pytest.fail(
                        f"Поле 'auth_key' для роли '{role_id_str}' должно быть непустой строкой.",
                        pytrace=False,
                    )
                secrets_data = self.config.auth.get(auth_key)
                if secrets_data is None:
                    pytest.fail(
                        f"Ключ авторизации '{auth_key}' для роли '{role_id_str}' не найден в config/auth.yaml",
                        pytrace=False,
                    )
                if not isinstance(secrets_data, dict):
                    pytest.fail(
                        f"Данные для ключа авторизации '{auth_key}' в config/auth.yaml должны быть словарём.",
                        pytrace=False,
                    )
                new_persona.secrets = dict(secrets_data)

            new_persona.retries_config = _get_retry_configs(self.config.retries)

            def provider(p: Persona, st: object, sn: str) -> PluginSkillInstance:
                return self._get_skill_for_persona(p, st, sn, role_id_str)

            new_persona.set_skill_provider(provider)
            setattr(new_persona, "_pytest_request", self.request)
            setattr(new_persona, "_persona_session", self)
            self._personas[role_id_str] = new_persona
        return self._personas[role_id_str]

    def persona(self, role_id: str | Enum = "default") -> Persona:
        return self.get(role_id)

    def __call__(self, role_id: str | Enum = "default") -> Persona:
        return self.get(role_id)

    def _get_skill_for_persona(
        self, persona: Persona, skill_id: object, name: str, role_id: str
    ) -> PluginSkillInstance:
        skill_val = _normalize_identifier(skill_id, label="Идентификатор навыка")
        known_skills = persona.skills.get(skill_val)
        if known_skills is None or name not in known_skills:
            skill_instance = self._create_skill_instance(skill_id, name, role_id)
            persona.learn((skill_val, name, skill_instance))
        learned_skill = persona.skills[skill_val][name]
        return _require_plugin_skill_instance(
            learned_skill, skill_name=f"{skill_val}.{name}"
        )

    def _create_skill_instance(
        self, skill_id: object, name: str, role_id: str
    ) -> PluginSkillInstance:
        skill_val = _normalize_identifier(skill_id, label="Идентификатор навыка")
        cfg = _get_skill_config(self.config, skill_val, name)
        if cfg is None:
            pytest.fail(
                f"Конфигурация для навыка '{skill_val}.{name}' не найдена.",
                pytrace=False,
            )

        if skill_val == "browser":
            from persona_dsl.skills.use_browser import UseBrowser
            from playwright.sync_api import sync_playwright

            cfg_path = f"skills.browser.{name}"
            if "playwright" not in self._resources:
                self._resources["playwright"] = sync_playwright().start()
                playwright = self._resources["playwright"]
                requested_type = (
                    _get_optional_str(cfg, "type", path=cfg_path) or "chromium"
                )
                browser_type = _require_browser_type(playwright, requested_type)
                selenoid_url = _get_optional_str(cfg, "selenoid_url", path=cfg_path)
                ws_endpoint = _get_optional_str(cfg, "ws_endpoint", path=cfg_path)

                if selenoid_url and ws_endpoint:
                    pytest.fail(
                        f"Конфигурация '{cfg_path}' не может одновременно содержать 'selenoid_url' и 'ws_endpoint'.",
                        pytrace=False,
                    )

                if selenoid_url:
                    selenoid_opts = (
                        _get_mapping(cfg, "selenoid_options", path=cfg_path) or {}
                    )
                    if requested_type == "sberbrowser":
                        browser_name = "sberbrowser"
                    elif requested_type == "chromium":
                        browser_name = "chrome"
                    else:
                        browser_name = requested_type

                    caps: ConfigMapping = {
                        "browserName": browser_name,
                        "enableVNC": _get_bool(
                            selenoid_opts,
                            "enableVNC",
                            path=f"{cfg_path}.selenoid_options",
                            default=True,
                        ),
                        "enableVideo": _get_bool(
                            selenoid_opts,
                            "enableVideo",
                            path=f"{cfg_path}.selenoid_options",
                            default=False,
                        ),
                    }
                    version = _get_optional_str(cfg, "version", path=cfg_path)
                    if version is not None:
                        caps["version"] = version

                    chrome_options = _get_mapping(
                        selenoid_opts,
                        "goog:chromeOptions",
                        path=f"{cfg_path}.selenoid_options",
                    )
                    if chrome_options is not None:
                        caps["goog:chromeOptions"] = chrome_options

                    for key, value in selenoid_opts.items():
                        if key not in caps:
                            caps[key] = value

                    common_args = _build_chromium_args(cfg, path=cfg_path)
                    opts_key = (
                        "moz:firefoxOptions"
                        if browser_name == "firefox"
                        else "goog:chromeOptions"
                    )
                    raw_options = caps.get(opts_key)
                    options = (
                        {}
                        if raw_options is None
                        else _require_mapping(
                            raw_options,
                            path=f"{cfg_path}.selenoid_options.{opts_key}",
                        )
                    )
                    option_args = _get_string_list(
                        options,
                        "args",
                        path=f"{cfg_path}.selenoid_options.{opts_key}",
                    )

                    if _get_bool(cfg, "headless", path=cfg_path, default=False):
                        if "--headless" not in option_args:
                            option_args.append("--headless")

                    existing_args = set(option_args)
                    for arg in common_args:
                        if arg not in existing_args:
                            option_args.append(arg)
                    options["args"] = option_args
                    caps[opts_key] = options

                    if self.request.node is not None:
                        caps["name"] = self.request.node.name
                        if bool(caps["enableVideo"]):
                            caps["videoName"] = f"{self.request.node.name}.mp4"

                    always_match_caps: ConfigMapping = dict(caps)
                    w3c_caps: ConfigMapping = {"alwaysMatch": always_match_caps}
                    retries = _get_int(cfg, "session_retries", path=cfg_path, default=3)
                    session_timeout = _get_float(
                        cfg,
                        "session_timeout",
                        path=cfg_path,
                        default=30.0,
                    )
                    ws_url, session_id = _create_selenoid_session(
                        selenoid_url,
                        w3c_caps,
                        retries=retries,
                        timeout=session_timeout,
                    )

                    if "selenoid_sessions" not in self._resources:
                        self._resources["selenoid_sessions"] = []
                    self._resources["selenoid_sessions"].append(
                        {"url": selenoid_url, "id": session_id}
                    )

                    self._resources["browser"] = browser_type.connect_over_cdp(
                        ws_url,
                        slow_mo=_get_float(cfg, "slow_mo", path=cfg_path, default=0.0),
                        timeout=_get_float(
                            cfg, "timeout", path=cfg_path, default=30000.0
                        ),
                    )

                elif ws_endpoint:
                    self._resources["browser"] = browser_type.connect_over_cdp(
                        ws_endpoint,
                        slow_mo=_get_float(cfg, "slow_mo", path=cfg_path, default=0.0),
                        timeout=_get_float(
                            cfg, "timeout", path=cfg_path, default=30000.0
                        ),
                    )
                else:
                    args = _build_chromium_args(cfg, path=cfg_path)
                    executable_path = _get_optional_str(
                        cfg, "executable_path", path=cfg_path
                    )
                    channel = _get_optional_str(cfg, "channel", path=cfg_path)
                    self._resources["browser"] = _launch_browser_instance(
                        browser_type,
                        headless=_get_bool(
                            cfg, "headless", path=cfg_path, default=True
                        ),
                        slow_mo=_get_float(cfg, "slow_mo", path=cfg_path, default=0.0),
                        timeout=_get_float(
                            cfg, "timeout", path=cfg_path, default=30000.0
                        ),
                        executable_path=executable_path,
                        args=args,
                        channel=channel,
                    )
                self._resources["browser_contexts"] = {}

            browser = self._resources["browser"]
            contexts = self._resources["browser_contexts"]
            if role_id not in contexts:
                base_url_override = os.getenv("BASE_URL") or _get_optional_str(
                    cfg, "base_url", path=cfg_path
                )
                viewport = _get_mapping(cfg, "viewport", path=cfg_path)
                raw_args = _get_string_list(cfg, "args", path=cfg_path)
                is_maximized = (
                    _get_bool(cfg, "start_maximized", path=cfg_path, default=False)
                    or "--start-maximized" in raw_args
                )
                is_headless = _get_bool(cfg, "headless", path=cfg_path, default=True)
                contexts[role_id] = _create_browser_context(
                    browser,
                    ignore_https_errors=_get_bool(
                        cfg, "ignore_https_errors", path=cfg_path, default=False
                    ),
                    base_url=base_url_override,
                    is_maximized=is_maximized,
                    is_headless=is_headless,
                    viewport=viewport,
                    cfg_path=cfg_path,
                )

            context = contexts[role_id]
            if not context.pages:
                page = context.new_page()
            else:
                page = context.pages[0]

            return UseBrowser.from_page(
                page,
                base_url=os.getenv("BASE_URL")
                or _get_optional_str(cfg, "base_url", path=cfg_path),
                default_timeout=_get_optional_float(
                    cfg, "default_timeout", path=cfg_path
                ),
                default_navigation_timeout=_get_optional_float(
                    cfg, "default_navigation_timeout", path=cfg_path
                ),
            )

        if skill_val == "api":
            from persona_dsl.skills.use_api import UseAPI

            cfg_path = f"skills.api.{name}"
            base_url = os.getenv("BASE_URL") or _get_required_str(
                cfg, "base_url", path=cfg_path
            )
            return UseAPI.at(
                base_url=base_url,
                verify_ssl=_get_bool(cfg, "verify_ssl", path=cfg_path, default=True),
                timeout=_get_float(cfg, "timeout", path=cfg_path, default=10.0),
                retries=_get_int(cfg, "retries", path=cfg_path, default=0),
                backoff=_get_float(cfg, "backoff", path=cfg_path, default=0.5),
                log_bodies=_get_bool(cfg, "log_bodies", path=cfg_path, default=False),
                default_headers=_get_optional_string_mapping(
                    cfg, "headers", path=cfg_path
                ),
            )

        if skill_val == "db":
            from persona_dsl.skills.use_database import UseDatabase

            cfg_path = f"skills.db.{name}"
            driver_name = _get_required_str(cfg, "driver", path=cfg_path)
            dsn = _get_required_str(cfg, "dsn", path=cfg_path)
            user = _get_optional_str(cfg, "user", path=cfg_path)
            password = _get_optional_str(cfg, "password", path=cfg_path)
            if ("{user}" in dsn or "{password}" in dsn) and (
                user is None or password is None
            ):
                pytest.fail(
                    f"Конфигурация '{cfg_path}' должна содержать 'user' и 'password' для подстановки в dsn.",
                    pytrace=False,
                )
            if "{user}" in dsn or "{password}" in dsn:
                dsn_final = dsn.format(user=user, password=password)
            else:
                dsn_final = dsn
            try:
                driver_module = __import__(driver_name)
            except (ImportError, ModuleNotFoundError) as error:
                pytest.fail(
                    f"Не удалось импортировать драйвер БД '{driver_name}': {error}",
                    pytrace=False,
                )
            return UseDatabase.with_dsn(dsn=dsn_final, driver=driver_module)

        if skill_val == "kafka":
            from persona_dsl.skills.use_kafka import UseKafka

            cfg_path = f"skills.kafka.{name}"
            bootstrap = _get_required_str(cfg, "bootstrap_servers", path=cfg_path)
            group_id = _get_optional_str(cfg, "group_id", path=cfg_path)
            from_offset = _require_kafka_offset(cfg, path=cfg_path)
            return UseKafka.with_servers(
                bootstrap_servers=bootstrap,
                group_id=group_id,
                from_offset=from_offset,
                timeout=_get_float(cfg, "timeout", path=cfg_path, default=10.0),
            )
        if skill_val == "soap":
            from persona_dsl.skills.use_soap import UseSOAP

            cfg_path = f"skills.soap.{name}"
            return UseSOAP.at(_get_required_str(cfg, "wsdl_url", path=cfg_path))

        raise NotImplementedError(
            f"Ленивое создание для навыка '{skill_val}' не реализовано."
        )

    def _parse_args_with_role(
        self, args: tuple[object, ...]
    ) -> tuple[str, tuple[object, ...]]:
        """Разбирает аргументы, отделяя опциональную роль в начале.

        Поддерживаются:
        - Enum (BaseRole)
        - str (идентификатор роли)
        """
        role_id = "default"
        if args:
            first = args[0]
            if isinstance(first, Enum):
                role_id = _normalize_identifier(first, label="Идентификатор роли")
                args = args[1:]
            elif isinstance(first, str):
                role_id = first
                args = args[1:]
        return role_id, args

    def make(self, *args: object) -> None:
        """Выполняет действия, изменяющие состояние системы."""
        from persona_dsl.components.base_step import BaseStep

        role_id, actions = self._parse_args_with_role(args)
        typed_actions = [action for action in actions if isinstance(action, BaseStep)]
        if len(typed_actions) != len(actions):
            raise TypeError("Метод 'make' принимает только шаги (BaseStep).")
        persona_instance = self.get(role_id)
        for item in typed_actions:
            item.execute(persona_instance)

    # Синонимы для make
    perform = make
    does = make

    def verify(self, assertion: object, actual_value: object) -> None:
        """Alias for checking a single assertion against a value."""
        self.check(actual_value, assertion)

    def check(self, actual_value: object, *expectations: object) -> None:
        """Проверяет фактическое значение на соответствие ожиданиям."""
        from persona_dsl.components.expectation import Expectation

        typed_expectations = [
            expectation
            for expectation in expectations
            if isinstance(expectation, Expectation)
        ]
        if len(typed_expectations) != len(expectations):
            raise TypeError(
                "Метод 'check' может принимать только Expectation в качестве второго и последующих аргументов."
            )
        if not typed_expectations:
            raise ValueError("Метод 'check' требует хотя бы один Expectation.")

        persona_instance = self.get("default")
        for expectation in typed_expectations:
            expectation.execute(persona_instance, actual_value)

    def _cleanup_resources(self) -> None:
        for persona in self._personas.values():
            for skill_type in persona.skills.values():
                for skill_instance in skill_type.values():
                    forget_method = getattr(skill_instance, "forget", None)
                    if callable(forget_method):
                        forget_method()
        if "browser_contexts" in self._resources:
            for context in self._resources["browser_contexts"].values():
                context.close()
        if "browser" in self._resources:
            browser = self._resources["browser"]
            close = getattr(browser, "close", None)
            if callable(close):
                close()

        if "selenoid_sessions" in self._resources:
            for session in self._resources["selenoid_sessions"]:
                s_url = session["url"]
                s_id = session["id"]
                try:
                    del_url = f"{s_url.rstrip('/')}/wd/hub/session/{s_id}"
                    logger.info("Удаление сессии Selenoid: %s", s_id)
                    requests.delete(del_url, timeout=5.0)
                except requests.RequestException as error:
                    logger.warning(
                        "Ошибка удаления сессии Selenoid %s: %s", s_id, error
                    )
        if "playwright" in self._resources:
            pw = self._resources["playwright"]
            if not isinstance(pw, SupportsStop):
                raise RuntimeError(
                    "Playwright-ресурс не имеет метода stop(); нарушен контракт sync_playwright().start()"
                )
            pw.stop()


PersonaDispatcher = PersonaSession


def pytest_addoption(parser: AddOptionParserContext) -> None:
    parser.addoption(
        "--env", action="store", default="dev", help="Окружение: dev/staging/prod"
    )
    parser.addoption(
        "--generate-pages",
        action="store_true",
        default=False,
        help="Генерация PageObject во время тестов (используется с Op GeneratePageObject).",
    )
    parser.addoption(
        "--update-snapshots",
        action="store_true",
        default=False,
        help="Обновление эталонов для всех видов снепшотов (Data, Aria, Screenshot).",
    )


def pytest_configure(config: ConfigureContext) -> None:
    """Регистрирует кастомные маркеры и настраивает предупреждения."""
    # 1. Подавляем предупреждения о неизвестных маркерах,
    #    чтобы можно было использовать @tag("any_tag") без редактирования pytest.ini
    config.addinivalue_line("filterwarnings", "ignore::pytest.PytestUnknownMarkWarning")

    # 2. Регистрируем маркер @data_driven из ядра, чтобы не делать это в проекте
    config.addinivalue_line(
        "markers",
        "data_driven: кастомная параметризация теста, управляемая фреймворком",
    )

    # 3. Регистрируем маркер @persona_retry (LCL-37)
    config.addinivalue_line(
        "markers",
        "persona_retry(max_attempts=1, delay=0.0, ...): автоматический перезапуск теста при падении",
    )

    env_opt = config.getoption("--env")
    if env_opt is None:
        return
    if not isinstance(env_opt, str):
        raise TypeError(
            f"Опция '--env' должна быть строкой, получено: {type(env_opt).__name__}"
        )
    if env_opt:
        os.environ["TAAS_ENV"] = env_opt


@pytest.fixture(scope="session")
def config(pytestconfig: pytest.Config) -> Config:
    """Загружает конфигурацию из файлов в зависимости от окружения."""
    from persona_dsl.utils.config import Config

    env = pytestconfig.getoption("--env")
    cfg = Config.load(env, project_root=pytestconfig.rootpath)
    cfg.update_snapshots = pytestconfig.getoption("--update-snapshots")
    return cfg


@pytest.fixture(scope="session")
def persona_class() -> type[Persona]:
    """Возвращает базовый класс Persona для использования в диспетчере."""
    from persona_dsl.persona import Persona

    return Persona


@pytest.fixture(scope="session", autouse=True)
def _validate_config(pytestconfig: pytest.Config) -> None:
    """
    Автоматически используемая фикстура для строгой валидации конфигурации проекта
    на основе деклараций в tests/conftest.py (PERSONA_SKILLS, PERSONA_ROLES).
    - Если деклараций нет — конфигурация не требуется и валидация пропускается.
    - Если декларации есть — файл config/{env}.yaml обязателен; при отсутствии/несоответствии — жёсткая ошибка.
    """
    env = pytestconfig.getoption("--env")
    cfg_path = Path(pytestconfig.rootpath) / "config" / f"{env}.yaml"
    plugins = list(pytestconfig.pluginmanager.get_plugins())
    project_skills: list[object] = []
    project_roles_enum: type[Enum] | None = None
    for mod in plugins:
        ps = getattr(mod, "PERSONA_SKILLS", None)
        pr = getattr(mod, "PERSONA_ROLES", None)
        if ps and not project_skills:
            project_skills = ps
        if pr and project_roles_enum is None:
            project_roles_enum = pr

    # Нет деклараций — ничего не валидируем и не загружаем конфиг
    if not project_skills and not project_roles_enum:
        return

    # Декларации есть — файл обязателен
    if not cfg_path.exists():
        pytest.fail(
            f"Отсутствует файл конфигурации 'config/{env}.yaml', тогда как в conftest.py объявлены "
            f"PERSONA_SKILLS/ROLES. Создайте config/{env}.yaml или уберите декларации.",
            pytrace=False,
        )

    # Загружаем конфиг и валидируем перечисленные навыки/роли
    # Загружаем конфиг и валидируем перечисленные навыки/роли
    from persona_dsl.utils.config import Config

    cfg = Config.load(env, project_root=pytestconfig.rootpath)
    errors: list[str] = []

    for skill_item in project_skills:
        if isinstance(skill_item, tuple):
            if len(skill_item) != 2:
                pytest.fail(
                    "Элементы PERSONA_SKILLS в формате tuple должны содержать ровно два значения: (skill_id, profile_name).",
                    pytrace=False,
                )
            skill_id, raw_skill_name = skill_item
            if not isinstance(raw_skill_name, str) or not raw_skill_name:
                pytest.fail(
                    "Имя профиля в PERSONA_SKILLS должно быть непустой строкой.",
                    pytrace=False,
                )
            skill_name = raw_skill_name
        else:
            skill_id = skill_item
            skill_name = "default"

        skill_key = _normalize_identifier(skill_id, label="Идентификатор навыка")
        if _get_skill_config(cfg, skill_key, skill_name) is None:
            error_msg = f"  - Именованный навык '{skill_key}.{skill_name}'"
            if skill_name == "default":
                error_msg = f"  - Базовый навык '{skill_key}'"
            errors.append(error_msg)

    if project_roles_enum is not None:
        for role_member in project_roles_enum:
            accessible_name = _normalize_identifier(
                role_member, label="Идентификатор роли"
            )
            if _get_persona_config(cfg, accessible_name) is None:
                errors.append(
                    f"  - Проектная роль '{accessible_name}' (из {project_roles_enum.__name__})"
                )

    if errors:
        pytest.fail(
            f"Отсутствует конфигурация в 'config/{env}.yaml' для следующих сущностей, объявленных в conftest.py:\n"
            + ", ".join(errors),
            pytrace=False,
        )


@pytest.fixture(scope="function")
def personas(
    request: pytest.FixtureRequest, config: Config, persona_class: type[Persona]
) -> Generator[PersonaSession, None, None]:
    session = PersonaSession(config, persona_class, request)
    yield session
    session._cleanup_resources()


@pytest.fixture(scope="function")
def persona(personas: PersonaSession) -> Persona:
    return personas.get("default")


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(
    item: pytest.Item, call: object
) -> Generator[None, HookResult[pytest.TestReport], None]:
    outcome = yield
    rep = outcome.get_result()
    if rep.when == "call":
        from persona_dsl.utils.metrics import metrics

        status = "passed" if rep.passed else "failed"
        tags = {"test_name": item.name, "status": status}
        metrics.gauge("test.duration", rep.duration, tags)
        metrics.counter("test.runs", tags).inc()
        fixture_names = getattr(item, "fixturenames", ())
        funcargs = getattr(item, "funcargs", {})
        if (
            status == "failed"
            and isinstance(fixture_names, Sequence)
            and ("persona" in fixture_names or "personas" in fixture_names)
            and isinstance(funcargs, dict)
        ):
            session = funcargs.get("personas")
            if not isinstance(session, PersonaSession):
                persona_or_session = funcargs.get("persona")
                if isinstance(persona_or_session, PersonaSession):
                    session = persona_or_session
                else:
                    session_candidate = getattr(
                        persona_or_session, "_persona_session", None
                    )
                    if isinstance(session_candidate, PersonaSession):
                        session = session_candidate

            if isinstance(session, PersonaSession) and "browser" in session._resources:
                screenshot_on_fail = _get_bool(
                    session.config.reporting,
                    "screenshot_on_fail",
                    path="reporting",
                    default=True,
                )
                pagesource_on_fail = _get_bool(
                    session.config.reporting,
                    "pagesource_on_fail",
                    path="reporting",
                    default=True,
                )
                if screenshot_on_fail or pagesource_on_fail:
                    browser = session._resources["browser"]
                    if browser.contexts:
                        from persona_dsl.utils.artifacts import (
                            artifacts_dir,
                            sanitize_filename,
                        )

                        screenshot_dir = artifacts_dir("screenshots")
                        for index, context in enumerate(browser.contexts):
                            if not context.pages:
                                continue
                            page = context.pages[-1]
                            context_name = f"context-{index}"
                            if screenshot_on_fail:
                                screenshot_path = (
                                    screenshot_dir
                                    / f"{sanitize_filename(item.name)}-{context_name}.png"
                                )
                                page.screenshot(path=str(screenshot_path))
                                allure.attach.file(
                                    str(screenshot_path),
                                    name=f"screenshot-on-fail-{context_name}",
                                    attachment_type=allure.attachment_type.PNG,
                                )
                            if pagesource_on_fail:
                                page_source = page.content()
                                allure.attach(
                                    page_source,
                                    name=f"page-source-on-fail-{context_name}",
                                    attachment_type=allure.attachment_type.HTML,
                                )
    setattr(item, "rep_" + rep.when, rep)


@lru_cache(maxsize=None)
def _load_test_data_file(filename: str) -> list[ScenarioData]:
    """Загружает и кеширует тестовые данные из YAML/JSON файла в tests/data."""
    base_dir = Path.cwd() / "tests" / "data"
    name = filename

    # Список кандидатов: если расширение задано — используем его; иначе пробуем .yaml, .yml, затем .json
    if any(name.endswith(ext) for ext in (".yaml", ".yml", ".json")):
        candidates = [base_dir / name]
    else:
        candidates = [
            base_dir / f"{name}.yaml",
            base_dir / f"{name}.yml",
            base_dir / f"{name}.json",
        ]

    for path in candidates:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                if path.suffix.lower() == ".json":
                    data = json.load(f)
                else:
                    data = yaml.safe_load(f)
            if not isinstance(data, list):
                raise DataDrivenError(
                    f"Данные в файле {path} должны быть списком (list)."
                )
            scenarios: list[ScenarioData] = []
            for index, item in enumerate(data):
                if not isinstance(item, dict):
                    raise DataDrivenError(
                        f"Данные в файле {path} должны содержать только словари. Ошибка в индексе: {index}"
                    )
                scenarios.append(dict(item))
            return scenarios

    raise DataDrivenError(
        "Файл с тестовыми данными не найден. Ожидались: "
        + ", ".join(str(p) for p in candidates)
    )


def pytest_sessionstart(session: pytest.Session) -> None:
    """Вызывается в начале тестовой сессии для monkey-patching allure.step."""
    if _taas_ready():
        setattr(allure, "step", _instrumented_allure_step)


def pytest_sessionfinish(session: pytest.Session) -> None:
    """Вызывается в конце тестовой сессии для восстановления allure.step и отправки финального события."""
    if _taas_ready():
        final_status = "COMPLETED" if session.exitstatus == 0 else "FAILED"
        finish_event = {
            "event": "finish",
            "data": {"status": final_status, "return_code": int(session.exitstatus)},
        }
        try:
            from .utils.taas_integration import publish_taas_event

            publish_taas_event(finish_event)
        except (RuntimeError, ValueError, TypeError) as error:
            logger.warning("TaaS: не удалось отправить finish событие: %s", error)

        setattr(allure, "step", _original_allure_step)


def _resolve_data_driven_expressions(val: object) -> object:
    """Рекурсивно вычисляет SystemVar-выражения в данных."""
    if isinstance(val, dict):
        if val.get("kind") == "system" and "name" in val:
            name = val.get("name")
            if not isinstance(name, str) or not name:
                raise ValueError(
                    "@data_driven expr: поле 'name' в SystemVar должно быть непустой строкой."
                )
            args_value = val.get("args")
            if args_value is None:
                args: dict[str, object] = {}
            elif isinstance(args_value, dict):
                args = dict(args_value)
            else:
                raise ValueError(
                    f"@data_driven expr: поле 'args' у SystemVar '{name}' должно быть словарём."
                )
            resolved_args = {
                k: _resolve_data_driven_expressions(v) for k, v in args.items()
            }
            from persona_dsl.utils import data_providers as _dp

            func = getattr(_dp, name, None)
            if callable(func):
                try:
                    return func(**resolved_args)
                except (TypeError, ValueError) as error:
                    raise ValueError(
                        f"@data_driven expr: ошибка вычисления SystemVar '{name}' "
                        f"с аргументами {resolved_args}: {error}"
                    ) from error
            raise ValueError(
                f"@data_driven expr: неизвестный провайдер SystemVar '{name}'"
            )
        return {k: _resolve_data_driven_expressions(v) for k, v in val.items()}
    if isinstance(val, list):
        return [_resolve_data_driven_expressions(x) for x in val]
    return val


def pytest_generate_tests(metafunc: pytest.Metafunc) -> None:
    """Генерирует параметризованные тесты для маркера @data_driven."""
    for marker in metafunc.definition.iter_markers(name="data_driven"):
        source = marker.args[0] if marker.args else marker.kwargs.get("source")
        is_file_raw = marker.kwargs.get("file", False)
        if not isinstance(is_file_raw, bool):
            pytest.fail(
                "Параметр 'file' в @data_driven должен быть bool.",
                pytrace=False,
            )
        is_file = is_file_raw

        if source is None:
            pytest.fail(
                "Источник данных 'source' для @data_driven не был предоставлен.",
                pytrace=False,
            )

        try:
            scenarios_source = _load_test_data_file(source) if is_file else source
        except DataDrivenError as e:
            pytest.fail(str(e), pytrace=False)

        if not isinstance(scenarios_source, list):
            pytest.fail(
                f"Данные для @data_driven должны быть списком словарей. Получено: {type(scenarios_source)}",
                pytrace=False,
            )

        scenarios: list[ScenarioData] = []
        for index, raw_scenario in enumerate(scenarios_source):
            if not isinstance(raw_scenario, dict):
                pytest.fail(
                    "Данные для @data_driven должны быть списком словарей. "
                    f"Ошибка в индексе: {index}, получено: {type(raw_scenario).__name__}",
                    pytrace=False,
                )
            scenarios.append(dict(raw_scenario))

        name_template = marker.kwargs.get("name_template")
        scenario_ids = [
            _require_test_id(scenario, index=index)
            for index, scenario in enumerate(scenarios)
        ]
        if isinstance(name_template, str) and name_template:
            ids: list[str] = []
            for index, scenario in enumerate(scenarios):
                try:
                    ids.append(name_template.format(**scenario))
                except (KeyError, IndexError, ValueError) as error:
                    pytest.fail(
                        "@data_driven: шаблон имени вариации "
                        f"'{name_template}' не может быть применён к сценарию с test_id='{scenario_ids[index]}': {error}",
                        pytrace=False,
                    )
        else:
            ids = scenario_ids

        resolved_scenarios: list[ScenarioData] = []
        original_variant_id = os.environ.get("TAAS_VARIANT_ID")
        try:
            for index, scenario in enumerate(scenarios):
                test_id = _require_test_id(scenario, index=index)
                os.environ["TAAS_VARIANT_ID"] = test_id
                resolved_scenario = _resolve_data_driven_expressions(scenario)
                if not isinstance(resolved_scenario, dict):
                    pytest.fail(
                        f"@data_driven: после вычисления выражений сценарий '{test_id}' перестал быть словарём.",
                        pytrace=False,
                    )
                resolved_scenarios.append(dict(resolved_scenario))
        except ValueError as error:
            pytest.fail(f"ValueError: {error}", pytrace=False)
        finally:
            if original_variant_id is None:
                os.environ.pop("TAAS_VARIANT_ID", None)
            else:
                os.environ["TAAS_VARIANT_ID"] = original_variant_id

        only_marker = marker.kwargs.get("only")
        only_env = os.environ.get("TAAS_VARIANT_IDS")

        is_filtered = False
        active_filter_set: set[str] | None = None

        if only_marker is not None:
            is_filtered = True
            if isinstance(only_marker, (str, bytes)) or not isinstance(
                only_marker, Iterable
            ):
                pytest.fail(
                    "@data_driven: параметр 'only' должен быть итерируемым набором строковых test_id.",
                    pytrace=False,
                )
            filter_values: set[str] = set()
            for raw_value in only_marker:
                if not isinstance(raw_value, str) or not raw_value:
                    pytest.fail(
                        "@data_driven: параметр 'only' должен содержать только непустые строки.",
                        pytrace=False,
                    )
                filter_values.add(raw_value)
            active_filter_set = filter_values

        if only_env:
            is_filtered = True
            env_set = {s.strip() for s in only_env.split(",") if s.strip()}
            if active_filter_set is None:
                active_filter_set = env_set
            else:
                active_filter_set.intersection_update(env_set)

        if is_filtered:
            final_scenarios: list[ScenarioData] = []
            final_ids: list[str] = []
            if active_filter_set:
                for index, (scenario, scenario_id) in enumerate(
                    zip(resolved_scenarios, ids, strict=False)
                ):
                    if _require_test_id(scenario, index=index) in active_filter_set:
                        final_scenarios.append(scenario)
                        final_ids.append(scenario_id)

            if not final_scenarios:
                pytest.fail(
                    "@data_driven: ни одна вариация не осталась после фильтрации (only/TAAS_VARIANT_IDS).",
                    pytrace=False,
                )
            resolved_scenarios = final_scenarios
            ids = final_ids

        if "scenario" in metafunc.fixturenames and resolved_scenarios:
            metafunc.parametrize("scenario", resolved_scenarios, ids=ids)


def pytest_runtest_setup(item: pytest.Item) -> None:
    """
    Перед каждым тестом:
    1. Устанавливаем TAAS_VARIANT_ID для детерминированного seed'а.
    2. (LCL-37) Оборачиваем тестовую функцию в ретрай-декоратор, если задан маркер @persona_retry.
    """
    from persona_dsl.utils.retry import RetryPolicy  # Lazy import for coverage

    prev = os.environ.get("TAAS_VARIANT_ID")
    variant_id: str | None = None
    callspec = getattr(item, "callspec", None)
    if callspec and "scenario" in callspec.params:
        scenario = callspec.params["scenario"]

        if isinstance(scenario, dict):
            test_id = scenario.get("test_id")
            if isinstance(test_id, str) and test_id:
                variant_id = test_id

    if variant_id:
        os.environ["TAAS_VARIANT_ID"] = variant_id
    setattr(item, "_prev_taas_variant_id", prev)

    retry_marker = item.get_closest_marker("persona_retry")
    policy: RetryPolicy | None = None

    if retry_marker:
        kwargs = dict(retry_marker.kwargs)
        policy = RetryPolicy(**kwargs)
    else:
        env = item.config.getoption("--env")
        cfg_path = Path(item.config.rootpath) / "config" / f"{env}.yaml"
        if cfg_path.exists():
            from persona_dsl.utils.config import Config

            cfg = Config.load(env, project_root=item.config.rootpath)
            default_policy = cfg.retries.get("default")
            if default_policy is not None:
                policy = RetryPolicy(
                    **_coerce_retry_policy_config(
                        default_policy, path="retries.default"
                    )
                )

    if policy is not None:
        original_func = _require_test_callable(item)

        @functools.wraps(original_func)
        def retrying_test_func(*args: object, **kwargs: object) -> object:
            attempt = 0
            while True:
                attempt += 1
                outcome = capture_outcome(lambda: original_func(*args, **kwargs))
                if outcome.succeeded:
                    return outcome.require_value()

                error = outcome.require_error()
                if not policy.should_retry(attempt, error):
                    raise error

                logger.warning(
                    "Тест '%s' упал (попытка %s/%s): %s. Ретрай через %sс.",
                    item.name,
                    attempt,
                    policy.max_attempts,
                    error,
                    policy.delay,
                )
                policy.wait(attempt)
                if policy.on_retry_action:
                    policy.execute_action()

        setattr(item, "obj", retrying_test_func)


def pytest_runtest_teardown(item: pytest.Item, nextitem: object) -> None:
    """
    Восстанавливаем предыдущее значение TAAS_VARIANT_ID после теста.
    """
    prev = getattr(item, "_prev_taas_variant_id", None)
    if prev is None:
        os.environ.pop("TAAS_VARIANT_ID", None)
    else:
        os.environ["TAAS_VARIANT_ID"] = prev


@pytest.fixture(scope="session")
def testdata() -> Callable[[str], list[ScenarioData]]:
    """Фабричная фикстура для загрузки тестовых данных из `tests/data/*.{yaml,yml,json}`."""
    return _load_test_data_file


def pytest_runtest_logstart(nodeid: str, location: object) -> None:
    """
    Отправляет JSON-событие в TaaS при старте каждого теста.
    Работает только в контексте TaaS (когда задан TAAS_RUN_ID), чтобы не влиять на обычный вывод pytest.
    """
    if not _taas_ready():
        return
    # Используем имя теста (без пути) как description для корневого узла
    test_name = nodeid.split("::")[-1]
    event_data = {
        "event": "test_start",
        "data": {
            "node_id": nodeid,
            "description": test_name,
            "timestamp": time.time(),
        },
    }
    try:
        from .utils.taas_integration import publish_taas_event

        publish_taas_event(event_data)
    except (RuntimeError, ValueError, TypeError) as error:
        logger.warning("TaaS: не удалось отправить событие test_start: %s", error)


def pytest_runtest_logreport(report: pytest.TestReport) -> None:
    """
    Отправляет JSON-событие в stdout по завершении каждой фазы теста (setup, call, teardown).
    Нас интересует только 'call' для отображения итогового статуса.
    Работает только в контексте TaaS (когда задан TAAS_RUN_ID), чтобы не влиять на обычный вывод pytest.
    """
    if not _taas_ready():
        return
    if report.when == "call":
        test_name = report.nodeid.split("::")[-1]
        event_data = {
            "event": "test_end",
            "data": {
                "node_id": report.nodeid,
                "description": test_name,
                "status": report.outcome,
                "duration": report.duration,
                "timestamp": time.time(),
            },
        }
        try:
            from .utils.taas_integration import publish_taas_event

            publish_taas_event(event_data)
        except (RuntimeError, ValueError, TypeError) as error:
            logger.warning("TaaS: не удалось отправить событие test_end: %s", error)
