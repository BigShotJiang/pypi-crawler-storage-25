from __future__ import annotations

from dataclasses import fields, is_dataclass
from enum import Enum, EnumType
from typing import TypeAlias, TypeGuard

JsonScalar: TypeAlias = str | int | float | bool | None
JsonValue: TypeAlias = JsonScalar | list["JsonValue"] | dict[str, "JsonValue"]
JsonObject: TypeAlias = dict[str, JsonValue]
JsonArray: TypeAlias = list[JsonValue]


def is_json_value(value: object) -> TypeGuard[JsonValue]:
    if value is None or isinstance(value, (str, int, float, bool)):
        return True
    if isinstance(value, list):
        return all(is_json_value(item) for item in value)
    if isinstance(value, dict):
        return all(
            isinstance(key, str) and is_json_value(item) for key, item in value.items()
        )
    return False


def is_json_object(value: object) -> TypeGuard[JsonObject]:
    return isinstance(value, dict) and all(
        isinstance(key, str) and is_json_value(item) for key, item in value.items()
    )


def is_json_array(value: object) -> TypeGuard[JsonArray]:
    return isinstance(value, list) and all(is_json_value(item) for item in value)


def to_json_value(value: object) -> JsonValue:
    if is_json_value(value):
        return value
    if isinstance(value, bytes):
        return value.hex()
    if isinstance(value, Enum):
        return to_json_value(value.value)
    if isinstance(value, EnumType):
        members: list[JsonValue] = []
        raw_member: object
        for raw_member in value:
            if not isinstance(raw_member, Enum):
                raise TypeError(
                    f"Enum класс '{value.__qualname__}' должен содержать только Enum members."
                )
            members.append(to_json_value(raw_member.value))
        return members
    if isinstance(value, type):
        return f"{value.__module__}.{value.__qualname__}"
    if isinstance(value, tuple):
        return [to_json_value(item) for item in value]
    if isinstance(value, list):
        return [to_json_value(item) for item in value]
    if isinstance(value, dict):
        result: dict[str, JsonValue] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError(
                    f"JSON object ожидает строковый ключ, получено '{type(key).__name__}'."
                )
            result[key] = to_json_value(item)
        return result
    if is_dataclass(value) and not isinstance(value, type):
        return {
            field_info.name: to_json_value(getattr(value, field_info.name))
            for field_info in fields(value)
        }
    raise TypeError(
        f"Невозможно привести значение типа '{type(value).__name__}' к JsonValue."
    )
