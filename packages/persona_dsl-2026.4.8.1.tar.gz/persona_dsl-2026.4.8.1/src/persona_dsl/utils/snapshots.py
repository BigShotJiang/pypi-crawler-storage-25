from __future__ import annotations

import os
from collections.abc import Mapping


def is_snapshot_update_enabled(persona: object, *, explicit_update: bool) -> bool:
    """Определяет, разрешено ли создание или обновление baseline-снимков."""
    if explicit_update:
        return True

    if os.getenv("UPDATE_SNAPSHOTS") == "1":
        return True

    if persona is None:
        return False

    raw_params = getattr(persona, "params", None)
    if raw_params is None:
        return False
    if not isinstance(raw_params, Mapping):
        raise TypeError("Persona.params должен быть словарём конфигурации.")

    raw_flag = raw_params.get("update_snapshots", False)
    if not isinstance(raw_flag, bool):
        raise TypeError(
            "Флаг Persona.params['update_snapshots'] должен быть булевым значением."
        )
    return raw_flag
