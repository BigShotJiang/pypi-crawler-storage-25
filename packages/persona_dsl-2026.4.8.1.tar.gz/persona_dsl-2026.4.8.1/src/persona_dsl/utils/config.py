from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml
from dotenv import load_dotenv

from .config_models import (
    AuthConfig,
    ConfigDocument,
    GeneratorConfig,
    PersonasConfig,
    ReportingConfig,
    RetriesConfig,
    SkillsConfig,
)


def _load_yaml_mapping(path: Path, description: str) -> dict[str, object]:
    with open(path, "r", encoding="utf-8") as file:
        raw_data = yaml.safe_load(file)

    if raw_data is None:
        return {}

    if not isinstance(raw_data, dict):
        raise TypeError(
            f"{description} должен содержать YAML-объект верхнего уровня, получено: {type(raw_data).__name__}"
        )

    result: dict[str, object] = {}
    for key, value in raw_data.items():
        if not isinstance(key, str):
            raise TypeError(
                f"{description} должен содержать только строковые ключи, получено: {type(key).__name__}"
            )
        result[key] = value
    return result


@dataclass(slots=True, init=False)
class Config:
    """Хранит типизированную конфигурацию тестового проекта."""

    skills: SkillsConfig = field(default_factory=SkillsConfig)
    personas: PersonasConfig = field(default_factory=PersonasConfig)
    auth: AuthConfig = field(default_factory=AuthConfig)
    reporting: ReportingConfig = field(default_factory=ReportingConfig)
    retries: RetriesConfig = field(default_factory=RetriesConfig)
    generator: GeneratorConfig = field(default_factory=GeneratorConfig)
    update_snapshots: bool = False
    env: str = "dev"

    def __init__(
        self,
        *,
        skills: object = None,
        personas: object = None,
        auth: object = None,
        reporting: object = None,
        retries: object = None,
        generator: object = None,
        update_snapshots: bool = False,
        env: str = "dev",
    ) -> None:
        self.skills = SkillsConfig.model_validate({} if skills is None else skills)
        self.personas = PersonasConfig.model_validate(
            {} if personas is None else personas
        )
        self.auth = AuthConfig.model_validate({} if auth is None else auth)
        self.reporting = ReportingConfig.model_validate(
            {} if reporting is None else reporting
        )
        self.retries = RetriesConfig.model_validate({} if retries is None else retries)
        self.generator = GeneratorConfig.model_validate(
            {} if generator is None else generator
        )
        self.update_snapshots = update_snapshots
        self.env = env

    @classmethod
    def model_validate(cls, raw: object) -> "Config":
        if isinstance(raw, cls):
            return raw
        document = ConfigDocument.model_validate(raw)
        return cls(
            skills=document.skills,
            personas=document.personas,
            reporting=document.reporting,
            retries=document.retries,
            generator=document.generator,
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        if mode != "python":
            raise ValueError("Поддерживается только режим сериализации 'python'.")
        return {
            "skills": self.skills.model_dump(mode=mode),
            "personas": self.personas.model_dump(mode=mode),
            "auth": self.auth.model_dump(mode=mode),
            "reporting": self.reporting.model_dump(mode=mode),
            "retries": self.retries.model_dump(mode=mode),
            "generator": self.generator.model_dump(mode=mode),
            "update_snapshots": self.update_snapshots,
            "env": self.env,
        }

    @staticmethod
    def load(env: str, project_root: Path | None = None) -> "Config":
        """
        Загружает конфигурацию для указанного окружения.
        1. Читает `config/{env}.yaml`.
        2. Читает `config/auth.yaml` (если существует).
        3. Загружает переменные из `.env.{env}`.
        """
        root = project_root or Path.cwd()
        config_path = root / "config" / f"{env}.yaml"
        if not config_path.exists():
            raise FileNotFoundError(
                f"Конфигурация для окружения '{env}' не найдена: {config_path}"
            )

        data = _load_yaml_mapping(config_path, f"Файл конфигурации '{config_path}'")
        document = ConfigDocument.model_validate(data)

        auth_data: dict[str, object] = {}
        auth_path = root / "config" / "auth.yaml"
        if auth_path.exists():
            auth_data = _load_yaml_mapping(auth_path, f"Файл авторизации '{auth_path}'")

        dotenv_path = root / f".env.{env}"
        if dotenv_path.exists():
            load_dotenv(dotenv_path)

        return Config(
            skills=document.skills,
            personas=document.personas,
            auth=AuthConfig.model_validate(auth_data),
            reporting=document.reporting,
            retries=document.retries,
            generator=document.generator,
            env=env,
        )
