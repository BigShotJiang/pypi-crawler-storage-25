from __future__ import annotations

import random
import time
from dataclasses import dataclass
from typing import Callable, Literal, Optional, Tuple, Type, TypeVar

from ..contracts import capture_outcome

BackoffMode = Literal["linear", "exp"]
ResultT = TypeVar("ResultT")


@dataclass
class RetryPolicy:
    """
    Политика повторных попыток (ретраев).

    Attributes:
        max_attempts: Максимальное количество попыток (включая первую). По умолчанию 1 (без ретраев).
        delay: Задержка между попытками в секундах.
        backoff_mode: Режим расчёта задержки. `linear` держит постоянный интервал,
            `exp` увеличивает задержку экспоненциально.
        backoff_factor: Множитель увеличения задержки для `exp`.
        jitter: Случайный шум, добавляемый к задержке.
        retry_on: Кортеж типов исключений, при которых нужно повторять попытку.
        retry_if: Предикат для проверки экземпляра исключения (вернуть True, если нужно повторить).
        on_retry_action: Коллбек, вызываемый перед каждой повторной попыткой.
    """

    max_attempts: int = 1
    delay: float = 0.0
    backoff_mode: BackoffMode = "exp"
    backoff_factor: float = 1.0
    jitter: float = 0.0
    retry_on: Tuple[Type[Exception], ...] = (Exception,)
    retry_if: Optional[Callable[[Exception], bool]] = None
    on_retry_action: Optional[Callable[[], None]] = None

    def should_retry(self, attempt: int, exception: Exception) -> bool:
        """Определяет, нужно ли делать ретрай."""
        if attempt >= self.max_attempts:
            return False

        if not isinstance(exception, self.retry_on):
            return False

        if self.retry_if is not None and not self.retry_if(exception):
            return False

        return True

    def wait(self, attempt: int) -> None:
        """Выполняет ожидание перед следующей попыткой."""
        if self.backoff_mode == "linear":
            wait_time = self.delay
        elif self.backoff_mode == "exp":
            wait_time = self.delay * (self.backoff_factor ** (attempt - 1))
        else:
            raise ValueError("RetryPolicy.backoff_mode должен быть 'linear' или 'exp'.")
        if self.jitter > 0:
            wait_time += random.uniform(0, self.jitter)
        if wait_time > 0:
            time.sleep(wait_time)

    def execute_action(self) -> None:
        """Выполняет действие перед ретраем (если задано)."""
        if self.on_retry_action:
            self.on_retry_action()


def retry_call(
    action: Callable[[], ResultT],
    *,
    retries: int,
    interval: float,
    backoff: BackoffMode,
    jitter: float,
) -> ResultT:
    """Выполняет действие с явной политикой повторов для сгенерированного сценарного кода."""
    policy = RetryPolicy(
        max_attempts=retries + 1,
        delay=interval,
        backoff_mode=backoff,
        backoff_factor=2.0,
        jitter=jitter,
    )
    attempt = 1
    while True:
        outcome = capture_outcome(action)
        if outcome.succeeded:
            return outcome.require_value()
        error = outcome.require_error()
        if not policy.should_retry(attempt, error):
            raise error
        policy.wait(attempt)
        attempt += 1
