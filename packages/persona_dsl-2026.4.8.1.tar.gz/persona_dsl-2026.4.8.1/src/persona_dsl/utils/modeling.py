from __future__ import annotations

from collections.abc import ItemsView, Iterator, KeysView, Mapping, ValuesView
from dataclasses import fields, is_dataclass
from enum import Enum
from pathlib import Path
from typing import TypeVar

_LiteralStrT = TypeVar("_LiteralStrT", bound=str)


class StrictModel(Mapping[str, object]):
    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        if mode != "python":
            raise ValueError("Поддерживается только режим сериализации 'python'.")
        if not is_dataclass(self):
            raise TypeError(
                f"{self.__class__.__name__} должен быть dataclass для model_dump()."
            )
        dumped: dict[str, object] = {}
        for field_info in fields(self):
            dumped[field_info.name] = _dump_value(getattr(self, field_info.name))
        return dumped

    def _base_model_dump(self, *, mode: str = "python") -> dict[str, object]:
        """Базовая сериализация без zero-arg super() для slots-dataclass на Python 3.12."""
        return StrictModel.model_dump(self, mode=mode)

    def __getitem__(self, key: str) -> object:
        return self.model_dump(mode="python")[key]

    def get(self, key: str, default: object | None = None) -> object | None:
        return self.model_dump(mode="python").get(key, default)

    def keys(self) -> KeysView[str]:
        return self.model_dump(mode="python").keys()

    def items(self) -> ItemsView[str, object]:
        return self.model_dump(mode="python").items()

    def values(self) -> ValuesView[object]:
        return self.model_dump(mode="python").values()

    def __iter__(self) -> Iterator[str]:
        return iter(self.model_dump(mode="python"))

    def __len__(self) -> int:
        return len(self.model_dump(mode="python"))

    def __contains__(self, key: object) -> bool:
        return key in self.model_dump(mode="python")


def _dump_value(value: object) -> object:
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        return model_dump(mode="python")
    if isinstance(value, list):
        return [_dump_value(item) for item in value]
    if isinstance(value, tuple):
        return [_dump_value(item) for item in value]
    if isinstance(value, dict):
        dumped: dict[str, object] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError(
                    "Сериализуемый словарь должен содержать строковые ключи."
                )
            dumped[key] = _dump_value(item)
        return dumped
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, Path):
        return str(value)
    return value


def require_mapping(raw: object, model_name: str) -> Mapping[str, object]:
    if not isinstance(raw, Mapping):
        model_dump = getattr(raw, "model_dump", None)
        if callable(model_dump):
            raw = model_dump(mode="python")
    if not isinstance(raw, Mapping):
        raise TypeError(f"{model_name} должен быть объектом.")
    for key in raw:
        if not isinstance(key, str):
            raise TypeError(f"{model_name} должен содержать только строковые ключи.")
    return raw


def require_str(data: Mapping[str, object], field_name: str, model_name: str) -> str:
    value = data.get(field_name)
    if not isinstance(value, str) or not value:
        raise TypeError(f"{model_name}.{field_name} должен быть непустой строкой.")
    return value


def require_optional_str(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
) -> str | None:
    value = data.get(field_name)
    if value is None:
        return None
    if not isinstance(value, str):
        raise TypeError(f"{model_name}.{field_name} должен быть строкой или null.")
    return value


def require_optional_int(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
) -> int | None:
    value = data.get(field_name)
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{model_name}.{field_name} должен быть целым числом или null.")
    return value


def require_int(data: Mapping[str, object], field_name: str, model_name: str) -> int:
    value = data.get(field_name)
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{model_name}.{field_name} должен быть целым числом.")
    return value


def require_bool(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
    *,
    default: bool,
) -> bool:
    value = data.get(field_name, default)
    if not isinstance(value, bool):
        raise TypeError(f"{model_name}.{field_name} должен быть булевым значением.")
    return value


def require_string_list(raw: object, context: str) -> list[str]:
    if not isinstance(raw, list):
        raise TypeError(f"{context} должен быть списком строк.")
    result: list[str] = []
    for item in raw:
        if not isinstance(item, str):
            raise TypeError(f"{context} должен содержать только строки.")
        result.append(item)
    return result


def require_mapping_list(raw: object, context: str) -> list[Mapping[str, object]]:
    if not isinstance(raw, list):
        raise TypeError(f"{context} должен быть списком объектов.")
    result: list[Mapping[str, object]] = []
    for index, item in enumerate(raw):
        result.append(require_mapping(item, f"{context}[{index}]"))
    return result


def require_string_keyed_dict(
    raw: object,
    context: str,
) -> dict[str, object]:
    data = require_mapping(raw, context)
    return {key: value for key, value in data.items()}


def require_literal(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
    *,
    allowed: tuple[_LiteralStrT, ...],
    default: _LiteralStrT | None = None,
) -> _LiteralStrT:
    value = data.get(field_name, default)
    if value not in allowed:
        raise TypeError(
            f"{model_name}.{field_name} должен быть одним из: {', '.join(allowed)}."
        )
    if not isinstance(value, str):
        raise TypeError(f"{model_name}.{field_name} должен быть строковым литералом.")
    for literal_value in allowed:
        if literal_value == value:
            return literal_value
    raise TypeError(
        f"{model_name}.{field_name} должен совпадать с одним из разрешённых литералов."
    )


def require_optional_literal(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
    *,
    allowed: tuple[_LiteralStrT, ...],
) -> _LiteralStrT | None:
    value = data.get(field_name)
    if value is None:
        return None
    if value not in allowed:
        raise TypeError(
            f"{model_name}.{field_name} должен быть одним из: {', '.join(allowed)} или null."
        )
    if not isinstance(value, str):
        raise TypeError(f"{model_name}.{field_name} должен быть строковым литералом.")
    for literal_value in allowed:
        if literal_value == value:
            return literal_value
    raise TypeError(
        f"{model_name}.{field_name} должен совпадать с одним из разрешённых литералов."
    )


def coerce_string_list(values: list[str], context: str) -> list[str]:
    result: list[str] = []
    for item in values:
        if not isinstance(item, str):
            raise TypeError(f"{context} должен содержать только строки.")
        result.append(item)
    return result


def coerce_int(value: object, context: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{context} должен быть целым числом.")
    return value


def coerce_float(value: object, context: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{context} должен быть числом.")
    return float(value)


def normalize_optional_text(value: object, context: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise TypeError(f"{context} должен быть строкой или null.")
    normalized = value.strip()
    return normalized or None


def ensure_string_keyed_mapping(
    raw: Mapping[str, object], context: str
) -> dict[str, object]:
    for key in raw:
        if not isinstance(key, str):
            raise TypeError(f"{context} должен содержать только строковые ключи.")
    return dict(raw)
