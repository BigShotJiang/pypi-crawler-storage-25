import random
import time
from collections.abc import Callable
from typing import Literal

from allure import step

from ..components.expectation import Expectation
from .metrics import metrics
from .taas_integration import publish_taas_event

BackoffMode = Literal["linear", "exp"]


def wait_until(
    fact: Callable[[], object],
    expectation: Expectation,
    timeout: float = 10.0,
    interval: float = 0.5,
    backoff: BackoffMode = "linear",
    jitter: float = 0.0,
    domain: str | None = None,
    on_timeout: Literal["fail", "warn", "continue"] = "fail",
) -> object:
    """
    Универсальный helper ожиданий.
    Периодически вызывает fact(), проверяя expectation._perform(None, value) до тех пор, пока не истечет timeout.

    Args:
        fact: вызываемая без аргументов функция, возвращающая значение для проверки.
        expectation: экземпляр класса Expectation с методом check(actual).
        timeout: общий таймаут в секундах.
        interval: базовый интервал между попытками.
        backoff: стратегия увеличения интервала: 'linear' или 'exp'.
        jitter: добавочный случайный шум в секундах, 0 — без шума.
        domain: логический домен ожидания ('ui' | 'api' | 'kafka'), используется в метриках и событиях.
        on_timeout: поведение при истечении таймаута: 'fail' | 'warn' | 'continue'.
    """
    start = time.time()
    attempts = 0
    status = "running"
    description = f"Ожидание: {expectation.__class__.__name__}"

    publish_taas_event(
        {
            "event": "step_start",
            "type": "wait",
            "data": {
                "description": description,
                "timestamp": start,
                "component_name": expectation.__class__.__name__,
                "component_params": {
                    "timeout": timeout,
                    "interval": interval,
                    "backoff": backoff,
                    "jitter": jitter,
                    "domain": domain,
                },
            },
        }
    )

    try:
        with step(description):
            while True:
                attempts += 1
                value = fact()
                check_result = expectation.check_result(value)
                if check_result.succeeded:
                    status = "passed"
                    return value

                if time.time() - start >= timeout:
                    status = "failed" if on_timeout == "fail" else "passed"
                    if on_timeout == "fail":
                        error = check_result.require_error()
                        raise TimeoutError(
                            f"Ожидание не выполнено за {timeout}с: {description}. "
                            f"Последняя ошибка: {error}"
                        ) from error
                    return value

                delay = (
                    interval
                    if backoff == "linear"
                    else interval * (2 ** (attempts - 1))
                )
                if jitter > 0:
                    delay += random.uniform(0, jitter)
                time.sleep(min(delay, max(0.0, timeout - (time.time() - start))))
    finally:
        duration = time.time() - start
        metrics.gauge(
            "wait.duration",
            duration,
            {"status": status, "domain": domain or "unspecified"},
        )
        metrics.counter("wait.attempts", {"domain": domain or "unspecified"}).inc(
            attempts
        )
        publish_taas_event(
            {
                "event": "step_end",
                "type": "wait",
                "data": {
                    "description": description,
                    "timestamp": time.time(),
                    "duration": duration,
                    "status": status,
                    "attempts": attempts,
                    "domain": domain,
                },
            }
        )
