from __future__ import annotations

import time
import os
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Mapping, TypeAlias

MetricTags: TypeAlias = Mapping[str, object]


class Reporter(ABC):
    @abstractmethod
    def report(
        self, metric_name: str, value: float, tags: Mapping[str, object]
    ) -> None: ...


class FileReporter(Reporter):
    def __init__(self, output_file: Path) -> None:
        self._output_file = output_file

    def report(
        self, metric_name: str, value: float, tags: Mapping[str, object]
    ) -> None:
        tag_str = ",".join([f"{k}={v}" for k, v in tags.items()])
        with open(self._output_file, "a", encoding="utf-8") as f:
            f.write(f"{metric_name}{{{tag_str}}} {value} {int(time.time())}\n")


logger = logging.getLogger(__name__)


class StdoutReporter(Reporter):
    def report(
        self, metric_name: str, value: float, tags: Mapping[str, object]
    ) -> None:
        tag_str = ",".join([f"{k}={v}" for k, v in tags.items()])
        logger.info(f"{metric_name}{{{tag_str}}} {value} {int(time.time())}")


class Counter:
    def __init__(self, metrics_system: Metrics, name: str, tags: MetricTags) -> None:
        self._metrics = metrics_system
        self._name = name
        self._tags = _normalize_tags(tags)

    def inc(self, value: int = 1) -> None:
        self._metrics.report(f"{self._name}.count", value, self._tags)


class Metrics:
    def __init__(self) -> None:
        self._reporters: list[Reporter] = []

    def add_reporter(self, reporter: Reporter) -> None:
        self._reporters.append(reporter)

    def report(
        self, metric_name: str, value: float, tags: Mapping[str, object]
    ) -> None:
        for reporter in self._reporters:
            reporter.report(metric_name, value, tags)

    def gauge(self, name: str, value: float, tags: MetricTags | None = None) -> None:
        self.report(name, value, _normalize_tags(tags))

    def counter(self, name: str, tags: MetricTags | None = None) -> Counter:
        return Counter(self, name, _normalize_tags(tags))


def _normalize_tags(tags: MetricTags | None) -> dict[str, object]:
    if tags is None:
        return {}
    return dict(tags)


# Глобальный экземпляр для использования в рамках сессии
metrics = Metrics()
log_path = os.getenv("TEST_METRICS_FILE", "test_metrics.log")
metrics.add_reporter(FileReporter(Path(log_path)))
if os.getenv("TEST_METRICS_STDOUT", "0") == "1":
    metrics.add_reporter(StdoutReporter())
