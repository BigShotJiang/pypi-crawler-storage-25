from dataclasses import dataclass
import os
import re
from pathlib import Path


def sanitize_filename(name: str) -> str:
    """Безопасное имя файла для снапшотов/скриншотов."""
    return re.sub(r"[^A-Za-z0-9._-]+", "-", str(name)).strip("-") or "snapshot"


@dataclass(frozen=True)
class RuntimeArtifacts:
    screenshot_path: str | None = None
    screenshot_url: str | None = None
    snapshot_path: str | None = None
    snapshot_url: str | None = None


def runtime_artifacts_root() -> Path:
    """Корень runtime-артефактов: <ARTIFACTS>/<run_id> или локальный cwd."""
    base_dir = Path(os.getenv("TAAS_ARTIFACTS_DIR", str(Path.cwd())))
    run_id = os.getenv("TAAS_RUN_ID")
    return (base_dir / run_id) if run_id else base_dir


def runtime_artifact_url(subdir: str, filename: str) -> str | None:
    """Публичный URL runtime-артефакта внутри текущего запуска."""
    run_id = os.getenv("TAAS_RUN_ID")
    return f"/artifacts/{run_id}/{subdir}/{filename}" if run_id else None


def artifacts_dir(subdir: str) -> Path:
    """Каталог для артефактов запуска: <ARTIFACTS>/<run_id>/<subdir> или локальный ./<subdir>."""
    out = runtime_artifacts_root() / subdir
    out.mkdir(parents=True, exist_ok=True)
    return out


def screenshots_dir() -> Path:
    """Каталог для скриншотов."""
    return artifacts_dir("screenshots")


def runtime_file_artifact(
    path_value: str | Path,
    *,
    subdir: str,
) -> tuple[str | None, str | None]:
    """Возвращает путь и URL для уже созданного runtime-файла известного типа."""
    candidate = Path(path_value).expanduser()
    if not candidate.is_file():
        return None, None

    resolved_path = candidate.resolve()
    expected_dir = (runtime_artifacts_root() / subdir).resolve()
    if not resolved_path.is_relative_to(expected_dir):
        return None, None

    filename = resolved_path.name
    return str(resolved_path), runtime_artifact_url(subdir, filename)


def persist_text_artifact(
    *,
    subdir: str,
    component_name: str,
    extension: str,
    content: str,
    timestamp: float,
) -> tuple[str, str | None]:
    """Сохраняет текстовый runtime-артефакт и возвращает путь и URL."""
    target_dir = artifacts_dir(subdir)
    filename = f"{int(timestamp * 1000)}-{sanitize_filename(component_name)}{extension}"
    target_path = target_dir / filename
    target_path.write_text(content, encoding="utf-8")
    return str(target_path), runtime_artifact_url(subdir, filename)
