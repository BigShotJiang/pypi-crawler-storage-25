from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, Self, TypeVar

from persona_dsl.json_types import JsonObject, is_json_object, is_json_value
from persona_dsl.utils.modeling import (
    StrictModel,
    coerce_float,
    coerce_int,
    require_mapping,
    require_optional_str,
    require_string_list,
)

ConfigModelT = TypeVar("ConfigModelT", bound=StrictModel)
_ConfigModelCovT = TypeVar("_ConfigModelCovT", bound=StrictModel, covariant=True)


class _StrictModelFactory(Protocol[_ConfigModelCovT]):
    @classmethod
    def model_validate(cls, raw: object) -> _ConfigModelCovT: ...


def _extract_unknown_fields(
    data: dict[str, object],
    *,
    allowed: set[str],
    context: str,
) -> JsonObject:
    extras: JsonObject = {}
    for key, value in data.items():
        if key in allowed:
            continue
        if not is_json_value(value):
            raise TypeError(
                f"{context}.{key} должен быть JSON-совместимым значением для дополнительного поля."
            )
        extras[key] = value
    return extras


def _optional_bool(
    data: dict[str, object], field_name: str, context: str
) -> bool | None:
    value = data.get(field_name)
    if value is None:
        return None
    if not isinstance(value, bool):
        raise TypeError(f"{context}.{field_name} должен быть bool или null.")
    return value


def _optional_int(data: dict[str, object], field_name: str, context: str) -> int | None:
    value = data.get(field_name)
    if value is None:
        return None
    return coerce_int(value, f"{context}.{field_name}")


def _optional_float(
    data: dict[str, object], field_name: str, context: str
) -> float | None:
    value = data.get(field_name)
    if value is None:
        return None
    return coerce_float(value, f"{context}.{field_name}")


def _optional_string_dict(
    data: dict[str, object],
    field_name: str,
    context: str,
) -> dict[str, str] | None:
    value = data.get(field_name)
    if value is None:
        return None
    if not isinstance(value, dict):
        raise TypeError(f"{context}.{field_name} должно быть словарём строк.")
    mapping = require_mapping(value, f"{context}.{field_name}")
    result: dict[str, str] = {}
    for key, item in mapping.items():
        if not isinstance(item, str):
            raise TypeError(
                f"{context}.{field_name}.{key} должен быть строкой, получено: {type(item).__name__}."
            )
        result[key] = item
    return result


def _optional_json_object(
    data: dict[str, object],
    field_name: str,
    context: str,
) -> JsonObject | None:
    value = data.get(field_name)
    if value is None:
        return None
    if not is_json_object(value):
        raise TypeError(f"{context}.{field_name} должен быть JSON-объектом или null.")
    return value


@dataclass(slots=True)
class ViewportConfig(StrictModel):
    width: int
    height: int

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = dict(require_mapping(raw, cls.__name__))
        return cls(
            width=coerce_int(data.get("width"), f"{cls.__name__}.width"),
            height=coerce_int(data.get("height"), f"{cls.__name__}.height"),
        )


@dataclass(slots=True)
class BrowserSkillConfig(StrictModel):
    base_url: str | None = None
    ws_url: str | None = None
    path: str | None = None
    type: str | None = None
    headless: bool | None = None
    no_sandbox: bool | None = None
    ignore_https_errors: bool | None = None
    start_maximized: bool | None = None
    args: list[str] = field(default_factory=list)
    disable_features: list[str] = field(default_factory=list)
    selenoid_url: str | None = None
    selenoid_options: JsonObject | None = None
    version: str | None = None
    session_retries: int | None = None
    session_timeout: float | None = None
    slow_mo: float | None = None
    timeout: float | None = None
    executable_path: str | None = None
    channel: str | None = None
    default_timeout: float | None = None
    default_navigation_timeout: float | None = None
    viewport: ViewportConfig | None = None
    extra_fields: JsonObject = field(default_factory=dict)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = dict(require_mapping(raw, cls.__name__))
        allowed = {
            "base_url",
            "ws_url",
            "path",
            "type",
            "headless",
            "no_sandbox",
            "ignore_https_errors",
            "start_maximized",
            "args",
            "disable_features",
            "selenoid_url",
            "selenoid_options",
            "version",
            "session_retries",
            "session_timeout",
            "slow_mo",
            "timeout",
            "executable_path",
            "channel",
            "default_timeout",
            "default_navigation_timeout",
            "viewport",
        }
        viewport = data.get("viewport")
        return cls(
            base_url=require_optional_str(data, "base_url", cls.__name__),
            ws_url=require_optional_str(data, "ws_url", cls.__name__),
            path=require_optional_str(data, "path", cls.__name__),
            type=require_optional_str(data, "type", cls.__name__),
            headless=_optional_bool(data, "headless", cls.__name__),
            no_sandbox=_optional_bool(data, "no_sandbox", cls.__name__),
            ignore_https_errors=_optional_bool(
                data, "ignore_https_errors", cls.__name__
            ),
            start_maximized=_optional_bool(data, "start_maximized", cls.__name__),
            args=require_string_list(data.get("args", []), f"{cls.__name__}.args"),
            disable_features=require_string_list(
                data.get("disable_features", []),
                f"{cls.__name__}.disable_features",
            ),
            selenoid_url=require_optional_str(data, "selenoid_url", cls.__name__),
            selenoid_options=_optional_json_object(
                data, "selenoid_options", cls.__name__
            ),
            version=require_optional_str(data, "version", cls.__name__),
            session_retries=_optional_int(data, "session_retries", cls.__name__),
            session_timeout=_optional_float(data, "session_timeout", cls.__name__),
            slow_mo=_optional_float(data, "slow_mo", cls.__name__),
            timeout=_optional_float(data, "timeout", cls.__name__),
            executable_path=require_optional_str(data, "executable_path", cls.__name__),
            channel=require_optional_str(data, "channel", cls.__name__),
            default_timeout=_optional_float(data, "default_timeout", cls.__name__),
            default_navigation_timeout=_optional_float(
                data, "default_navigation_timeout", cls.__name__
            ),
            viewport=(
                ViewportConfig.model_validate(viewport)
                if viewport is not None
                else None
            ),
            extra_fields=_extract_unknown_fields(
                data, allowed=allowed, context=cls.__name__
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        payload = self._base_model_dump(mode=mode)
        extra_fields = payload.pop("extra_fields")
        assert isinstance(extra_fields, dict)
        payload.update(extra_fields)
        return payload


@dataclass(slots=True)
class ApiSkillConfig(StrictModel):
    base_url: str | None = None
    verify_ssl: bool | None = None
    timeout: float | None = None
    retries: int | None = None
    backoff: float | None = None
    log_bodies: bool | None = None
    headers: dict[str, str] | None = None
    extra_fields: JsonObject = field(default_factory=dict)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = dict(require_mapping(raw, cls.__name__))
        allowed = {
            "base_url",
            "verify_ssl",
            "timeout",
            "retries",
            "backoff",
            "log_bodies",
            "headers",
        }
        return cls(
            base_url=require_optional_str(data, "base_url", cls.__name__),
            verify_ssl=_optional_bool(data, "verify_ssl", cls.__name__),
            timeout=_optional_float(data, "timeout", cls.__name__),
            retries=_optional_int(data, "retries", cls.__name__),
            backoff=_optional_float(data, "backoff", cls.__name__),
            log_bodies=_optional_bool(data, "log_bodies", cls.__name__),
            headers=_optional_string_dict(data, "headers", cls.__name__),
            extra_fields=_extract_unknown_fields(
                data, allowed=allowed, context=cls.__name__
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        payload = self._base_model_dump(mode=mode)
        extra_fields = payload.pop("extra_fields")
        assert isinstance(extra_fields, dict)
        payload.update(extra_fields)
        return payload


@dataclass(slots=True)
class DbConnectionConfig(StrictModel):
    driver: str | None = None
    dsn: str | None = None
    user: str | None = None
    password: str | None = None
    extra_fields: JsonObject = field(default_factory=dict)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = dict(require_mapping(raw, cls.__name__))
        allowed = {"driver", "dsn", "user", "password"}
        return cls(
            driver=require_optional_str(data, "driver", cls.__name__),
            dsn=require_optional_str(data, "dsn", cls.__name__),
            user=require_optional_str(data, "user", cls.__name__),
            password=require_optional_str(data, "password", cls.__name__),
            extra_fields=_extract_unknown_fields(
                data, allowed=allowed, context=cls.__name__
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        payload = self._base_model_dump(mode=mode)
        extra_fields = payload.pop("extra_fields")
        assert isinstance(extra_fields, dict)
        payload.update(extra_fields)
        return payload


@dataclass(slots=True)
class KafkaSkillConfig(StrictModel):
    bootstrap_servers: str | None = None
    group_id: str | None = None
    from_offset: str | None = None
    timeout: float | None = None
    extra_fields: JsonObject = field(default_factory=dict)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = dict(require_mapping(raw, cls.__name__))
        allowed = {"bootstrap_servers", "group_id", "from_offset", "timeout"}
        return cls(
            bootstrap_servers=require_optional_str(
                data, "bootstrap_servers", cls.__name__
            ),
            group_id=require_optional_str(data, "group_id", cls.__name__),
            from_offset=require_optional_str(data, "from_offset", cls.__name__),
            timeout=_optional_float(data, "timeout", cls.__name__),
            extra_fields=_extract_unknown_fields(
                data, allowed=allowed, context=cls.__name__
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        payload = self._base_model_dump(mode=mode)
        extra_fields = payload.pop("extra_fields")
        assert isinstance(extra_fields, dict)
        payload.update(extra_fields)
        return payload


@dataclass(slots=True)
class SoapSkillConfig(StrictModel):
    wsdl_url: str | None = None
    extra_fields: JsonObject = field(default_factory=dict)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = dict(require_mapping(raw, cls.__name__))
        allowed = {"wsdl_url", "wsdl"}
        wsdl_url = require_optional_str(data, "wsdl_url", cls.__name__)
        legacy_wsdl = require_optional_str(data, "wsdl", cls.__name__)
        if wsdl_url is not None and legacy_wsdl is not None and wsdl_url != legacy_wsdl:
            raise TypeError(
                f"{cls.__name__}.wsdl_url и {cls.__name__}.wsdl не должны конфликтовать."
            )
        return cls(
            wsdl_url=wsdl_url or legacy_wsdl,
            extra_fields=_extract_unknown_fields(
                data, allowed=allowed, context=cls.__name__
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        payload = self._base_model_dump(mode=mode)
        extra_fields = payload.pop("extra_fields")
        assert isinstance(extra_fields, dict)
        payload.update(extra_fields)
        return payload


@dataclass(slots=True)
class SkillsConfig(StrictModel):
    browser: dict[str, BrowserSkillConfig] = field(default_factory=dict)
    api: dict[str, ApiSkillConfig] = field(default_factory=dict)
    db: dict[str, DbConnectionConfig] = field(default_factory=dict)
    kafka: dict[str, KafkaSkillConfig] = field(default_factory=dict)
    soap: dict[str, SoapSkillConfig] = field(default_factory=dict)
    extra_fields: dict[str, JsonObject] = field(default_factory=dict)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = dict(require_mapping(raw, cls.__name__))
        allowed = {"browser", "api", "db", "kafka", "soap"}
        extra_fields: dict[str, JsonObject] = {}
        for key, value in data.items():
            if key in allowed:
                continue
            if not is_json_object(value):
                raise TypeError(
                    f"{cls.__name__}.{key} должен быть JSON-объектом для дополнительной skill-группы."
                )
            extra_fields[key] = value

        return cls(
            browser=_validate_named_section(
                data.get("browser"),
                BrowserSkillConfig,
                f"{cls.__name__}.browser",
            ),
            api=_validate_named_section(
                data.get("api"),
                ApiSkillConfig,
                f"{cls.__name__}.api",
            ),
            db=_validate_named_section(
                data.get("db"),
                DbConnectionConfig,
                f"{cls.__name__}.db",
            ),
            kafka=_validate_named_section(
                data.get("kafka"),
                KafkaSkillConfig,
                f"{cls.__name__}.kafka",
            ),
            soap=_validate_named_section(
                data.get("soap"),
                SoapSkillConfig,
                f"{cls.__name__}.soap",
            ),
            extra_fields=extra_fields,
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        payload = self._base_model_dump(mode=mode)
        extra_fields = payload.pop("extra_fields")
        assert isinstance(extra_fields, dict)
        payload.update(extra_fields)
        return payload


@dataclass(slots=True)
class PersonaRoleConfig(StrictModel):
    name: str | None = None
    auth_key: str | None = None
    extra_fields: JsonObject = field(default_factory=dict)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = dict(require_mapping(raw, cls.__name__))
        allowed = {"name", "auth_key"}
        return cls(
            name=require_optional_str(data, "name", cls.__name__),
            auth_key=require_optional_str(data, "auth_key", cls.__name__),
            extra_fields=_extract_unknown_fields(
                data, allowed=allowed, context=cls.__name__
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        payload = self._base_model_dump(mode=mode)
        extra_fields = payload.pop("extra_fields")
        assert isinstance(extra_fields, dict)
        payload.update(extra_fields)
        return payload


@dataclass(slots=True)
class PersonasConfig(StrictModel):
    roles: dict[str, PersonaRoleConfig] = field(default_factory=dict)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        roles: dict[str, PersonaRoleConfig] = {}
        for key, value in data.items():
            roles[key] = PersonaRoleConfig.model_validate(value)
        return cls(roles=roles)

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        if mode != "python":
            raise ValueError("Поддерживается только режим сериализации 'python'.")
        return {
            role_name: role_config.model_dump(mode=mode)
            for role_name, role_config in self.roles.items()
        }

    def role_items(self) -> dict[str, PersonaRoleConfig]:
        return dict(self.roles)


@dataclass(slots=True)
class ReportingConfig(StrictModel):
    enabled: bool | None = None
    screenshot_on_fail: bool | None = None
    pagesource_on_fail: bool | None = None
    extra_fields: JsonObject = field(default_factory=dict)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = dict(require_mapping(raw, cls.__name__))
        allowed = {"enabled", "screenshot_on_fail", "pagesource_on_fail"}
        return cls(
            enabled=_optional_bool(data, "enabled", cls.__name__),
            screenshot_on_fail=_optional_bool(data, "screenshot_on_fail", cls.__name__),
            pagesource_on_fail=_optional_bool(data, "pagesource_on_fail", cls.__name__),
            extra_fields=_extract_unknown_fields(
                data, allowed=allowed, context=cls.__name__
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        payload = self._base_model_dump(mode=mode)
        extra_fields = payload.pop("extra_fields")
        assert isinstance(extra_fields, dict)
        payload.update(extra_fields)
        return payload


@dataclass(slots=True)
class RetryPolicyModel(StrictModel):
    max_attempts: int | None = None
    delay: float | None = None
    backoff_mode: str | None = None
    backoff_factor: float | None = None
    jitter: float | None = None
    extra_fields: JsonObject = field(default_factory=dict)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = dict(require_mapping(raw, cls.__name__))
        allowed = {
            "max_attempts",
            "delay",
            "backoff_mode",
            "backoff_factor",
            "jitter",
        }
        return cls(
            max_attempts=_optional_int(data, "max_attempts", cls.__name__),
            delay=_optional_float(data, "delay", cls.__name__),
            backoff_mode=require_optional_str(data, "backoff_mode", cls.__name__),
            backoff_factor=_optional_float(data, "backoff_factor", cls.__name__),
            jitter=_optional_float(data, "jitter", cls.__name__),
            extra_fields=_extract_unknown_fields(
                data, allowed=allowed, context=cls.__name__
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        payload = self._base_model_dump(mode=mode)
        extra_fields = payload.pop("extra_fields")
        assert isinstance(extra_fields, dict)
        payload.update(extra_fields)
        return payload


@dataclass(slots=True)
class RetriesConfig(StrictModel):
    policies: dict[str, RetryPolicyModel] = field(default_factory=dict)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        return cls(
            policies={
                key: RetryPolicyModel.model_validate(value)
                for key, value in data.items()
            }
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        if mode != "python":
            raise ValueError("Поддерживается только режим сериализации 'python'.")
        return {
            policy_name: policy.model_dump(mode=mode)
            for policy_name, policy in self.policies.items()
        }


@dataclass(slots=True)
class GeneratorConfig(StrictModel):
    portal_classes: list[str] = field(default_factory=list)
    portal_patterns: list[str] = field(default_factory=list)
    extra_fields: JsonObject = field(default_factory=dict)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = dict(require_mapping(raw, cls.__name__))
        allowed = {"portal_classes", "portal_patterns"}
        return cls(
            portal_classes=require_string_list(
                data.get("portal_classes", []),
                f"{cls.__name__}.portal_classes",
            ),
            portal_patterns=require_string_list(
                data.get("portal_patterns", []),
                f"{cls.__name__}.portal_patterns",
            ),
            extra_fields=_extract_unknown_fields(
                data, allowed=allowed, context=cls.__name__
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        payload = self._base_model_dump(mode=mode)
        extra_fields = payload.pop("extra_fields")
        assert isinstance(extra_fields, dict)
        payload.update(extra_fields)
        return payload


@dataclass(slots=True)
class ConfigDocument(StrictModel):
    skills: SkillsConfig = field(default_factory=SkillsConfig)
    personas: PersonasConfig = field(default_factory=PersonasConfig)
    reporting: ReportingConfig = field(default_factory=ReportingConfig)
    retries: RetriesConfig = field(default_factory=RetriesConfig)
    generator: GeneratorConfig = field(default_factory=GeneratorConfig)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = dict(require_mapping(raw, cls.__name__))
        allowed = {"skills", "personas", "reporting", "retries", "generator"}
        unexpected = [key for key in data if key not in allowed]
        if unexpected:
            raise TypeError(
                f"{cls.__name__} содержит неподдерживаемые секции: {', '.join(sorted(unexpected))}."
            )
        return cls(
            skills=SkillsConfig.model_validate(data.get("skills", {})),
            personas=PersonasConfig.model_validate(data.get("personas", {})),
            reporting=ReportingConfig.model_validate(data.get("reporting", {})),
            retries=RetriesConfig.model_validate(data.get("retries", {})),
            generator=GeneratorConfig.model_validate(data.get("generator", {})),
        )


@dataclass(slots=True)
class AuthConfig(StrictModel):
    entries: dict[str, JsonObject] = field(default_factory=dict)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        entries: dict[str, JsonObject] = {}
        for key, value in data.items():
            if not is_json_object(value):
                raise TypeError(f"{cls.__name__}.{key} должен быть JSON-объектом.")
            entries[key] = value
        return cls(entries=entries)

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        if mode != "python":
            raise ValueError("Поддерживается только режим сериализации 'python'.")
        return dict(self.entries)


def _validate_named_section(
    raw: object,
    model_type: _StrictModelFactory[ConfigModelT],
    context: str,
) -> dict[str, ConfigModelT]:
    if raw is None:
        return {}
    mapping = require_mapping(raw, context)
    return {key: model_type.model_validate(value) for key, value in mapping.items()}
