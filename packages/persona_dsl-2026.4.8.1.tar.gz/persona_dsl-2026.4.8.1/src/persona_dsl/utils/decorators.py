from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from types import ModuleType
from typing import (
    TYPE_CHECKING,
    ContextManager,
    Literal,
    ParamSpec,
    Protocol,
    TypeVar,
    overload,
)

import pytest

if TYPE_CHECKING:
    from allure_commons.types import (
        AttachmentType,
        LabelType,
        LinkType,
        ParameterMode,
        Severity,
    )
else:
    AttachmentType = None
    LabelType = None
    LinkType = None
    ParameterMode = None
    Severity = None

try:
    import allure as _allure
except ModuleNotFoundError:
    _allure_module: ModuleType | None = None
else:
    _allure_module = _allure
    if not TYPE_CHECKING:
        from allure_commons.types import (
            AttachmentType as _RuntimeAttachmentType,
            LabelType as _RuntimeLabelType,
            LinkType as _RuntimeLinkType,
            ParameterMode as _RuntimeParameterMode,
            Severity as _RuntimeSeverity,
        )

        AttachmentType = _RuntimeAttachmentType
        LabelType = _RuntimeLabelType
        LinkType = _RuntimeLinkType
        ParameterMode = _RuntimeParameterMode
        Severity = _RuntimeSeverity

P = ParamSpec("P")
R = TypeVar("R")


class _AllureAttachmentTypeNamespace(Protocol):
    TEXT: object
    HTML: object
    JSON: object


class _AllureParameterModeNamespace(Protocol):
    HIDDEN: object
    MASKED: object


class _AllureAttachNamespace(Protocol):
    def __call__(
        self,
        body: object,
        name: str | None = None,
        attachment_type: object | None = None,
        extension: str | None = None,
    ) -> object: ...

    def file(
        self,
        source: str,
        name: str | None = None,
        attachment_type: object | None = None,
        extension: str | None = None,
    ) -> object: ...


class _AllureDynamicNamespace(Protocol):
    def title(self, value: str) -> None: ...

    def description(self, value: str) -> None: ...

    def description_html(self, value: str) -> None: ...

    def tag(self, *values: str) -> None: ...

    def epic(self, *values: str) -> None: ...

    def feature(self, *values: str) -> None: ...

    def story(self, *values: str) -> None: ...

    def severity(self, value: str | object) -> None: ...

    def label(self, label_type: str, *values: object) -> None: ...

    def id(self, value: str) -> None: ...

    def link(
        self,
        url: str,
        *,
        link_type: str | None = None,
        name: str | None = None,
    ) -> None: ...

    def issue(self, url: str, *, name: str | None = None) -> None: ...

    def testcase(self, url: str, *, name: str | None = None) -> None: ...

    def parent_suite(self, value: str) -> None: ...

    def suite(self, value: str) -> None: ...

    def sub_suite(self, value: str) -> None: ...

    def manual(self) -> None: ...

    def parameter(
        self,
        name: str,
        value: object,
        excluded: bool | None = None,
        mode: object | None = None,
    ) -> None: ...


class _AllureStepNamespace(Protocol):
    def __call__(self, title: str) -> ContextManager[object]: ...


def _pytest_marker(name: str) -> pytest.MarkDecorator:
    marker_candidate: object = getattr(pytest.mark, name, None)
    if not isinstance(marker_candidate, pytest.MarkDecorator):
        raise TypeError(f"pytest.mark.{name} должен быть pytest MarkDecorator.")
    return marker_candidate


def _apply_pytest_marker(
    func: Callable[P, R],
    marker_name: str,
    *marker_args: object,
    **marker_kwargs: object,
) -> Callable[P, R]:
    _pytest_marker(marker_name)(*marker_args, **marker_kwargs)(func)
    return func


def _allure_factory(name: str) -> object | None:
    if _allure_module is None:
        return None
    candidate: object = getattr(_allure_module, name, None)
    if candidate is None:
        raise AttributeError(f"Модуль allure не содержит декоратор {name}.")
    if not callable(candidate):
        raise TypeError(f"allure.{name} должен быть вызываемым декоратором.")
    return candidate


def _allure_attribute(name: str) -> object | None:
    if _allure_module is None:
        return None
    candidate: object = getattr(_allure_module, name, None)
    if candidate is None:
        raise AttributeError(f"Модуль allure не содержит атрибут {name}.")
    return candidate


@overload
def _allure_runtime_attribute(name: Literal["attach"]) -> _AllureAttachNamespace: ...


@overload
def _allure_runtime_attribute(
    name: Literal["attachment_type"],
) -> _AllureAttachmentTypeNamespace: ...


@overload
def _allure_runtime_attribute(name: Literal["dynamic"]) -> _AllureDynamicNamespace: ...


@overload
def _allure_runtime_attribute(
    name: Literal["parameter_mode"],
) -> _AllureParameterModeNamespace: ...


@overload
def _allure_runtime_attribute(name: Literal["step"]) -> _AllureStepNamespace: ...


def _allure_runtime_attribute(name: str) -> object | None:
    return _allure_attribute(name)


def _ensure_identity_decorator_result(
    decorated: object,
    target: Callable[P, R],
    error_message: str,
) -> Callable[P, R]:
    if decorated is not target:
        raise TypeError(error_message)
    return target


def _apply_allure_decorator(
    func: Callable[P, R],
    decorator_name: str,
    *decorator_args: object,
    **decorator_kwargs: object,
) -> Callable[P, R]:
    factory = _allure_factory(decorator_name)
    if factory is None:
        return func
    if not callable(factory):
        raise TypeError(f"allure.{decorator_name} должен быть вызываемым декоратором.")
    decorator = factory(*decorator_args, **decorator_kwargs)
    if not callable(decorator):
        raise TypeError(f"allure.{decorator_name}(...) должен возвращать декоратор.")
    return _ensure_identity_decorator_result(
        decorator(func),
        func,
        f"allure.{decorator_name}(...) должен возвращать исходную функцию без дополнительной обёртки.",
    )


def tag(*tags: str) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор для добавления тегов к тестам."""

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        marked_func = func
        for tag_name in tags:
            marked_func = _apply_pytest_marker(marked_func, tag_name)
            marked_func = _apply_allure_decorator(marked_func, "tag", tag_name)
        return marked_func

    return wrapper


def _metadata_marker(
    name: str,
    *values: str,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    if not values:
        raise ValueError(f"Декоратор @{name} требует минимум одно значение.")

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        marked_func = func
        for value in values:
            marked_func = _apply_pytest_marker(marked_func, name, value)
        return _apply_allure_decorator(marked_func, name, *values)

    return wrapper


def epic(*values: str) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор для эпика теста."""

    return _metadata_marker("epic", *values)


def feature(*values: str) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор для функционального блока теста."""

    return _metadata_marker("feature", *values)


def story(*values: str) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор для пользовательского сценария теста."""

    return _metadata_marker("story", *values)


def title(value: str) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор заголовка теста в Allure и каталоге TaaS."""

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        marked_func = _apply_pytest_marker(func, "title", value)
        marked_func = _apply_allure_decorator(marked_func, "title", value)
        setattr(marked_func, "__allure_display_name__", value)
        return marked_func

    return wrapper


def description(value: str) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор текстового описания теста в Allure."""

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        return _apply_allure_decorator(func, "description", value)

    return wrapper


def description_html(value: str) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор HTML-описания теста в Allure."""

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        return _apply_allure_decorator(func, "description_html", value)

    return wrapper


def label(
    label_type: str,
    *values: object,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор произвольных Allure labels."""

    if not values:
        raise ValueError("Декоратор @label требует минимум одно значение.")

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        return _apply_allure_decorator(func, "label", label_type, *values)

    return wrapper


def severity(
    value: str | object,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор severity для Allure."""

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        return _apply_allure_decorator(func, "severity", value)

    return wrapper


def allure_id(value: str) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор Allure ID."""

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        return _apply_allure_decorator(func, "id", value)

    return wrapper


id = allure_id


def suite(value: str) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор suite для Allure."""

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        return _apply_allure_decorator(func, "suite", value)

    return wrapper


def parent_suite(value: str) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор parent_suite для Allure."""

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        return _apply_allure_decorator(func, "parent_suite", value)

    return wrapper


def sub_suite(value: str) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор sub_suite для Allure."""

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        return _apply_allure_decorator(func, "sub_suite", value)

    return wrapper


@overload
def manual(func: Callable[P, R]) -> Callable[P, R]: ...


@overload
def manual() -> Callable[[Callable[P, R]], Callable[P, R]]: ...


def manual(
    func: Callable[P, R] | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]] | Callable[P, R]:
    """Декоратор пометки manual для Allure."""

    def wrapper(target: Callable[P, R]) -> Callable[P, R]:
        manual_attr = _allure_attribute("manual")
        if manual_attr is None:
            return target
        if not callable(manual_attr):
            raise TypeError("allure.manual должен быть вызываемым декоратором.")
        return _ensure_identity_decorator_result(
            manual_attr(target),
            target,
            "allure.manual должен возвращать исходную функцию без дополнительной обёртки.",
        )

    if func is None:
        return wrapper
    return wrapper(func)


def link(
    url: str,
    *,
    link_type: str | None = None,
    name: str | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор ссылки Allure."""

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        kwargs: dict[str, object] = {}
        if link_type is not None:
            kwargs["link_type"] = link_type
        if name is not None:
            kwargs["name"] = name
        return _apply_allure_decorator(func, "link", url, **kwargs)

    return wrapper


def issue(
    url: str,
    *,
    name: str | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор issue-ссылки Allure."""

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        kwargs: dict[str, object] = {}
        if name is not None:
            kwargs["name"] = name
        return _apply_allure_decorator(func, "issue", url, **kwargs)

    return wrapper


def testcase(
    url: str,
    *,
    name: str | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Декоратор testcase-ссылки Allure."""

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        kwargs: dict[str, object] = {}
        if name is not None:
            kwargs["name"] = name
        return _apply_allure_decorator(func, "testcase", url, **kwargs)

    return wrapper


class _AllureRuntimeNamespace:
    attach: _AllureAttachNamespace
    attachment_type: _AllureAttachmentTypeNamespace
    dynamic: _AllureDynamicNamespace
    parameter_mode: _AllureParameterModeNamespace
    step: _AllureStepNamespace

    def __init__(self) -> None:
        self.attach = _allure_runtime_attribute("attach")
        self.attachment_type = _allure_runtime_attribute("attachment_type")
        self.dynamic = _allure_runtime_attribute("dynamic")
        self.parameter_mode = _allure_runtime_attribute("parameter_mode")
        self.severity_level = _allure_attribute("severity_level")
        self.step = _allure_runtime_attribute("step")
        self.AttachmentType = AttachmentType
        self.LabelType = LabelType
        self.LinkType = LinkType
        self.ParameterMode = ParameterMode
        self.Severity = Severity


class _ReportRuntimeNamespace:
    attach: _AllureAttachNamespace
    attachment_type: _AllureAttachmentTypeNamespace
    metadata: _AllureDynamicNamespace
    parameter_mode: _AllureParameterModeNamespace

    def __init__(self) -> None:
        self.attach = _allure_runtime_attribute("attach")
        self.attachment_type = _allure_runtime_attribute("attachment_type")
        self.metadata = _allure_runtime_attribute("dynamic")
        self.parameter_mode = _allure_runtime_attribute("parameter_mode")
        self.severity_level = _allure_attribute("severity_level")
        self.AttachmentType = AttachmentType
        self.LabelType = LabelType
        self.LinkType = LinkType
        self.ParameterMode = ParameterMode
        self.Severity = Severity


allure_runtime = _AllureRuntimeNamespace()
attachment_type = allure_runtime.attachment_type
parameter_mode = allure_runtime.parameter_mode
severity_level = allure_runtime.severity_level
report_runtime = _ReportRuntimeNamespace()
report_attachment_type = report_runtime.attachment_type
report_parameter_mode = report_runtime.parameter_mode


def data_driven(
    source: object | None = None,
    file: bool = False,
    name_template: str | None = None,
    only: Sequence[str] | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """
    Декоратор параметризации, управляемый фреймворком.

    Args:
        source: Источник данных. При `file=True` это имя файла без расширения,
            иначе ожидается сериализуемый источник вариаций.
        file: Режим интерпретации `source`.
        name_template: Шаблон имени вариации.
        only: Список допустимых test_id.
    """

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        return _apply_pytest_marker(
            func,
            "data_driven",
            source=source,
            file=file,
            name_template=name_template,
            only=only,
        )

    return wrapper


def _mapping_for_template(value: object, *, index: int) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise TypeError(
            f"Вариант #{index} не является отображением и не может использоваться как словарный шаблон."
        )
    for key in value:
        if not isinstance(key, str):
            raise TypeError(
                f"Вариант #{index} содержит нестроковый ключ {key!r}, который нельзя использовать в name_template."
            )
    return dict(value)


def _format_name_template(*, name_template: str, value: object, index: int) -> str:
    try:
        if isinstance(value, Mapping):
            return name_template.format(**_mapping_for_template(value, index=index))
        return name_template.format(value=value)
    except KeyError as error:
        missing_key = error.args[0]
        raise ValueError(
            f"name_template ссылается на отсутствующий ключ {missing_key!r} в варианте #{index}."
        ) from error
    except IndexError as error:
        raise ValueError(
            f"name_template содержит недопустимую позиционную ссылку для варианта #{index}."
        ) from error
    except ValueError as error:
        raise ValueError(f"Некорректный name_template: {error}.") from error


def parametrize_simple(
    arg_name: str,
    values: Sequence[object],
    ids: Sequence[str] | None = None,
    name_template: str | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """
    Упрощённая обёртка над `pytest.mark.parametrize`.

    Args:
        arg_name: Имя параметра тестовой функции.
        values: Последовательность значений.
        ids: Явный список идентификаторов параметров.
        name_template: Шаблон генерации `ids`.
    """
    computed_ids: list[str] | None = None
    if ids is not None:
        computed_ids = list(ids)
    elif isinstance(name_template, str) and name_template:
        computed_ids = [
            _format_name_template(
                name_template=name_template,
                value=value,
                index=index,
            )
            for index, value in enumerate(values)
        ]

    def wrapper(func: Callable[P, R]) -> Callable[P, R]:
        return _apply_pytest_marker(
            func,
            "parametrize",
            arg_name,
            list(values),
            ids=computed_ids,
        )

    return wrapper
