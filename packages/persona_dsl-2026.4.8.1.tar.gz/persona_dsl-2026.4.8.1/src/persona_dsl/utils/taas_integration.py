from __future__ import annotations

import json
import os
import logging
from os import PathLike
from typing import Protocol, TypeAlias, runtime_checkable

import redis

TaasEventPayload: TypeAlias = dict[str, object]
REDIS_ERROR = redis.RedisError


@runtime_checkable
class SupportsToDict(Protocol):
    def to_dict(self) -> object: ...


@runtime_checkable
class SupportsToJson(Protocol):
    def to_json(self) -> object: ...


_taas_redis_client: redis.Redis | None = None
_taas_redis_mod: object | None = None
_taas_connection_failed: bool = False


def reset_taas_redis_client() -> None:
    """Сбрасывает кеш клиента Redis (для переинициализации соединения)."""
    global _taas_redis_client, _taas_redis_mod, _taas_connection_failed
    _taas_redis_client = None
    _taas_redis_mod = None
    _taas_connection_failed = False


logger = logging.getLogger(__name__)


def _connect_or_raise() -> redis.Redis | None:
    redis_url = os.environ.get("REDIS_URL", "redis://localhost:6379")
    try:
        client = redis.from_url(redis_url, decode_responses=True)
        client.ping()
        return client
    except REDIS_ERROR as error:
        is_strict = os.environ.get("TAAS_STRICT_CONNECT", "false").lower() not in (
            "false",
            "0",
        )
        if is_strict:
            raise RuntimeError(
                f"[TAAS_INTEGRATION] Не удалось подключиться к Redis по REDIS_URL={redis_url}: {error}"
            ) from error
        logger.warning(
            "[TAAS_INTEGRATION] Non-strict mode: Не удалось подключиться к Redis. "
            "События TaaS будут отключены. Ошибка: %s",
            error,
        )
        return None


def get_taas_redis_client() -> redis.Redis | None:
    """Инициализирует и возвращает клиент Redis, если запуск в контексте TaaS."""
    global _taas_redis_client, _taas_redis_mod, _taas_connection_failed
    if not os.environ.get("TAAS_RUN_ID") or _taas_connection_failed:
        return None

    if _taas_redis_mod is not None and _taas_redis_mod is not redis:
        reset_taas_redis_client()

    if _taas_redis_client is None:
        _taas_redis_client = _connect_or_raise()
        if _taas_redis_client is None:
            _taas_connection_failed = True
            return None
        _taas_redis_mod = redis
        return _taas_redis_client

    try:
        _taas_redis_client.ping()
        return _taas_redis_client
    except REDIS_ERROR:
        _taas_redis_client = _connect_or_raise()
        if _taas_redis_client is None:
            _taas_connection_failed = True
            return None
        _taas_redis_mod = redis
        return _taas_redis_client


class TaasJSONEncoder(json.JSONEncoder):
    def default(self, obj: object) -> object:
        # Handle Path objects
        if isinstance(obj, PathLike):
            return os.fspath(obj)
        # Handle Sets
        if isinstance(obj, set):
            return list(obj)
        # Handle Byte strings
        if isinstance(obj, bytes):
            return obj.decode("utf-8", errors="replace")
        # Handle objects with to_dict method (common in Pydantic/DataClasses)
        if isinstance(obj, SupportsToDict):
            return obj.to_dict()
        # Handle objects with to_json method
        if isinstance(obj, SupportsToJson):
            return obj.to_json()

        return str(obj)


def publish_taas_event(event_payload: object) -> None:
    """Публикует событие только в Redis Stream (без Pub/Sub и списков)."""
    run_id = os.environ.get("TAAS_RUN_ID")
    client = get_taas_redis_client()
    if client and run_id:
        # Строгая валидация структуры события
        if not isinstance(event_payload, dict):
            raise TypeError("[TAAS_INTEGRATION] event_payload должен быть dict")
        ev = event_payload.get("event")
        if not isinstance(ev, str) or not ev:
            raise ValueError(
                "[TAAS_INTEGRATION] Событие должно содержать непустое строковое поле 'event'"
            )
        data = event_payload.get("data")
        if not isinstance(data, dict):
            raise ValueError(
                "[TAAS_INTEGRATION] Событие должно содержать объект 'data'"
            )
        if str(ev).startswith("step_"):
            t = event_payload.get("type")
            if not isinstance(t, str) or not t:
                raise ValueError(
                    "[TAAS_INTEGRATION] Для step_* событий обязательно строковое поле 'type'"
                )

        json_payload = json.dumps(event_payload, cls=TaasJSONEncoder)

        event_type = ev
        component_type = event_payload.get("type")
        description = data.get("description")
        status = data.get("status")
        logger.info(
            "[TAAS_INTEGRATION] Event: %s, type=%s, status=%s, desc=%s",
            event_type,
            component_type,
            status,
            description,
        )

        # Только Redis Streams
        stream_key = f"run:{run_id}:events"
        raw_maxlen = os.getenv("TAAS_STREAM_MAXLEN", "10000")
        try:
            maxlen = int(raw_maxlen)
            if maxlen <= 0:
                raise ValueError("TAAS_STREAM_MAXLEN должен быть положительным целым")
        except ValueError as error:
            raise RuntimeError(
                f"[TAAS_INTEGRATION] Некорректное значение TAAS_STREAM_MAXLEN={raw_maxlen}: {error}"
            ) from error
        client.xadd(stream_key, {"json": json_payload}, maxlen=maxlen, approximate=True)
