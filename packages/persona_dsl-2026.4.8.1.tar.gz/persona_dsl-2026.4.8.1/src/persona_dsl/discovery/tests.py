from __future__ import annotations

import ast
import json
import os
import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path

from persona_dsl.discovery.annotations import (
    coerce_annotation_metadata,
    project_annotation_metadata,
)
from persona_dsl.discovery.components import discover_components
from persona_dsl.discovery.models import DiscoveryDiagnostic, TestDefinition, TestKind
from persona_dsl.json_types import JsonObject, is_json_object
from persona_dsl.references import build_reference_index
from persona_dsl.references.models import ReferenceIndexResult, ReferenceOccurrence
from persona_dsl.scenario import IRParseError, graph_to_structure, parse_code_to_graph
from persona_dsl.scenario.models import ParseCodeResponse

_LAST_DISCOVERY_ERROR: dict[str, str] | None = None
_LAST_DISCOVERY_DIAGNOSTICS: list[DiscoveryDiagnostic] = []


def get_last_test_discovery_error() -> dict[str, str]:
    return _LAST_DISCOVERY_ERROR or {}


def get_test_discovery_diagnostics() -> list[DiscoveryDiagnostic]:
    return list(_LAST_DISCOVERY_DIAGNOSTICS)


def _component_catalog(project_root: Path) -> dict[str, JsonObject]:
    catalog: dict[str, JsonObject] = {}
    for component in discover_components(project_root):
        payload = component.model_dump(mode="python")
        payload["type"] = component.runtime_kind
        if not is_json_object(payload):
            raise TypeError(
                f"Каталог компонента {component.name} должен быть JSON-объектом."
            )
        catalog[component.name] = payload
    return catalog


def _coerce_definition(item: object, index: int) -> TestDefinition:
    item_mapping = _require_mapping(item, index)
    annotations = coerce_annotation_metadata(
        item_mapping.get("annotations"),
        f"definitions[{index}].annotations",
    )
    raw = TestDefinition.model_validate(
        {
            "node_id": _require_str(item, "node_id", index),
            "path": _require_str(item, "path", index),
            "name": _require_str(item, "name", index),
            "kind": _require_kind(item, index),
            "docstring": _require_optional_str(item, "docstring", index),
            "annotations": annotations,
            "annotation_projection": project_annotation_metadata(annotations),
        }
    )
    return raw


def _require_mapping(item: object, index: int) -> dict[str, object]:
    if not isinstance(item, dict):
        raise ValueError(
            f"Элемент отчёта дискавери #{index} должен быть объектом, получено {type(item).__name__}."
        )
    result: dict[str, object] = {}
    for key, value in item.items():
        if not isinstance(key, str):
            raise ValueError(
                f"Элемент отчёта дискавери #{index} содержит нестроковый ключ."
            )
        result[key] = value
    return result


def _require_str(item: object, field_name: str, index: int) -> str:
    data = _require_mapping(item, index)
    value = data.get(field_name)
    if not isinstance(value, str) or not value:
        raise ValueError(
            f"Поле {field_name} у элемента #{index} должно быть непустой строкой."
        )
    return value


def _require_optional_str(item: object, field_name: str, index: int) -> str | None:
    data = _require_mapping(item, index)
    value = data.get(field_name)
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(
            f"Поле {field_name} у элемента #{index} должно быть строкой или null."
        )
    return value


def _require_kind(item: object, index: int) -> TestKind:
    kind = _require_mapping(item, index).get("kind")
    if kind == "file":
        return "file"
    if kind == "class":
        return "class"
    if kind == "method":
        return "method"
    raise ValueError(
        f"Поле kind у элемента #{index} должно быть 'file', 'class' или 'method'."
    )


def _definition_span(
    project_root: Path, definition: TestDefinition
) -> tuple[int, int] | None:
    source = _extract_node_source(project_root, definition)
    if source is None:
        return None
    return source.start_line, source.end_line


class _ExtractedNodeSource:
    def __init__(
        self,
        *,
        source_code: str,
        qualified_name: str,
        start_line: int,
        end_line: int,
    ) -> None:
        self.source_code = source_code
        self.qualified_name = qualified_name
        self.start_line = start_line
        self.end_line = end_line


def _extract_node_source(
    project_root: Path, definition: TestDefinition
) -> _ExtractedNodeSource | None:
    file_path = project_root / definition.path
    if not file_path.exists():
        _LAST_DISCOVERY_DIAGNOSTICS.append(
            DiscoveryDiagnostic(
                kind="io",
                path=definition.path,
                message=f"Файл теста не найден для node_id={definition.node_id}.",
                symbol_id=definition.id,
            )
        )
        return None

    try:
        source_code = file_path.read_text(encoding="utf-8")
    except OSError as error:
        _LAST_DISCOVERY_DIAGNOSTICS.append(
            DiscoveryDiagnostic(
                kind="io",
                path=definition.path,
                message=str(error),
                symbol_id=definition.id,
            )
        )
        return None

    try:
        tree = ast.parse(source_code, filename=definition.path)
    except SyntaxError as error:
        _LAST_DISCOVERY_DIAGNOSTICS.append(
            DiscoveryDiagnostic(
                kind="syntax",
                path=definition.path,
                message=error.msg,
                line=error.lineno,
                column=error.offset,
                symbol_id=definition.id,
            )
        )
        return None

    node_parts = definition.node_id.split("::")
    path_part = node_parts[0]
    if path_part != definition.path:
        _LAST_DISCOVERY_DIAGNOSTICS.append(
            DiscoveryDiagnostic(
                kind="metadata",
                path=definition.path,
                message=(
                    f"node_id={definition.node_id} не соответствует path={definition.path}."
                ),
                symbol_id=definition.id,
            )
        )
        return None

    target: ast.AST | None = None
    qualified_name = definition.node_id

    if definition.kind == "method":
        if len(node_parts) == 2:
            function_name = node_parts[1]
            for item in tree.body:
                if isinstance(item, ast.FunctionDef) and item.name == function_name:
                    target = item
                    qualified_name = f"{definition.path.removesuffix('.py').replace('/', '.')}.{function_name}"
                    break
        elif len(node_parts) >= 3:
            class_name = node_parts[1]
            function_name = node_parts[2]
            for item in tree.body:
                if not isinstance(item, ast.ClassDef) or item.name != class_name:
                    continue
                for body_item in item.body:
                    if (
                        isinstance(body_item, ast.FunctionDef)
                        and body_item.name == function_name
                    ):
                        target = body_item
                        qualified_name = (
                            f"{definition.path.removesuffix('.py').replace('/', '.')}"
                            f".{class_name}.{function_name}"
                        )
                        break
        else:
            return None
    else:
        if len(node_parts) != 2:
            return None
        class_name = node_parts[1]
        for item in tree.body:
            if isinstance(item, ast.ClassDef) and item.name == class_name:
                target = item
                qualified_name = f"{definition.path.removesuffix('.py').replace('/', '.')}.{class_name}"
                break

    if target is None:
        _LAST_DISCOVERY_DIAGNOSTICS.append(
            DiscoveryDiagnostic(
                kind="unsupported",
                path=definition.path,
                message=f"Не удалось найти AST-узел для node_id={definition.node_id}.",
                symbol_id=definition.id,
            )
        )
        return None

    start_line = getattr(target, "lineno", None)
    end_line = getattr(target, "end_lineno", None)
    if not isinstance(start_line, int) or not isinstance(end_line, int):
        _LAST_DISCOVERY_DIAGNOSTICS.append(
            DiscoveryDiagnostic(
                kind="unsupported",
                path=definition.path,
                message=(
                    f"AST-узел для node_id={definition.node_id} не содержит диапазон строк."
                ),
                symbol_id=definition.id,
            )
        )
        return None

    snippet = "\n".join(source_code.splitlines()[start_line - 1 : end_line])
    return _ExtractedNodeSource(
        source_code=textwrap.dedent(snippet),
        qualified_name=qualified_name,
        start_line=start_line,
        end_line=end_line,
    )


def _try_build_structure(
    *,
    project_root: Path,
    definition: TestDefinition,
    components_by_name: dict[str, JsonObject],
) -> tuple[JsonObject | None, str]:
    if definition.kind != "method":
        return None, definition.qualified_name

    extracted = _extract_node_source(project_root, definition)
    if extracted is None:
        return None, definition.qualified_name

    try:
        parsed: ParseCodeResponse = parse_code_to_graph(
            extracted.source_code, components_by_name
        )
        structure = graph_to_structure(
            node_id=definition.node_id,
            test_name=parsed.test_name,
            nodes=parsed.steps,
        )
    except (IRParseError, SyntaxError, TypeError, ValueError) as error:
        _LAST_DISCOVERY_DIAGNOSTICS.append(
            DiscoveryDiagnostic(
                kind="unsupported",
                path=definition.path,
                message=f"Не удалось построить структуру сценария: {error}",
                symbol_id=definition.id,
                context=definition.node_id,
            )
        )
        return None, extracted.qualified_name

    if not is_json_object(structure):
        _LAST_DISCOVERY_DIAGNOSTICS.append(
            DiscoveryDiagnostic(
                kind="metadata",
                path=definition.path,
                message=(
                    f"graph_to_structure для {definition.node_id} вернул не JSON-объект."
                ),
                symbol_id=definition.id,
            )
        )
        return None, extracted.qualified_name
    return structure, extracted.qualified_name


def _collect_referenced_symbol_ids(
    *,
    definition: TestDefinition,
    reference_index: ReferenceIndexResult,
    span: tuple[int, int] | None,
) -> list[str]:
    if span is None:
        return []
    start_line, end_line = span
    symbol_ids: list[str] = []
    for symbol in reference_index.symbols:
        if _occurrence_matches(
            symbol.definition, definition.path, start_line, end_line
        ):
            if symbol.id not in symbol_ids:
                symbol_ids.append(symbol.id)
        for usage in symbol.usages:
            if _occurrence_matches(usage, definition.path, start_line, end_line):
                if symbol.id not in symbol_ids:
                    symbol_ids.append(symbol.id)
    return symbol_ids


def _occurrence_matches(
    occurrence: ReferenceOccurrence,
    path: str,
    start_line: int,
    end_line: int,
) -> bool:
    if occurrence.file_path != path:
        return False
    return not (occurrence.end_line < start_line or occurrence.line > end_line)


def discover_tests(
    project_root: str | Path,
    *,
    reference_index: ReferenceIndexResult | None = None,
) -> list[TestDefinition]:
    global _LAST_DISCOVERY_ERROR

    root = Path(project_root).resolve()
    tests_dir = root / "tests"
    _LAST_DISCOVERY_DIAGNOSTICS.clear()

    if not tests_dir.is_dir():
        _LAST_DISCOVERY_ERROR = None
        return []

    report_file: str | None = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".json") as tmp:
            report_file = tmp.name

        package_root = Path(__file__).resolve().parents[2]
        env = os.environ.copy()
        pythonpath_parts = [str(package_root)]
        existing_pythonpath = env.get("PYTHONPATH")
        if existing_pythonpath:
            pythonpath_parts.append(existing_pythonpath)
        env["PYTHONPATH"] = os.pathsep.join(pythonpath_parts)

        command = [
            sys.executable,
            "-m",
            "pytest",
            "--collect-only",
            "-q",
            "--discovery-report-file",
            report_file,
            "-p",
            "persona_dsl.discovery.pytest_reporter",
            ".",
        ]
        subprocess.run(
            command,
            cwd=str(root),
            check=True,
            capture_output=True,
            text=True,
            encoding="utf-8",
            env=env,
        )

        with open(report_file, "r", encoding="utf-8") as file:
            raw_definitions = json.load(file)
        if not isinstance(raw_definitions, list):
            raise ValueError(
                "Отчёт дискавери должен содержать JSON-массив определений тестов."
            )

        components_by_name = _component_catalog(root)
        resolved_reference_index = reference_index or build_reference_index(root)

        definitions: list[TestDefinition] = []
        for index, item in enumerate(raw_definitions):
            definition = _coerce_definition(item, index)
            structure, qualified_name = _try_build_structure(
                project_root=root,
                definition=definition,
                components_by_name=components_by_name,
            )
            span = _definition_span(root, definition)
            definitions.append(
                TestDefinition(
                    id=definition.id,
                    node_id=definition.node_id,
                    name=definition.name,
                    qualified_name=qualified_name,
                    path=definition.path,
                    kind=definition.kind,
                    docstring=definition.docstring,
                    annotations=definition.annotations,
                    annotation_projection=definition.annotation_projection,
                    structure=structure,
                    referenced_symbol_ids=_collect_referenced_symbol_ids(
                        definition=definition,
                        reference_index=resolved_reference_index,
                        span=span,
                    ),
                )
            )

        _LAST_DISCOVERY_ERROR = None
        return definitions
    except subprocess.CalledProcessError as error:
        _LAST_DISCOVERY_ERROR = {
            "error": "pytest discovery failed",
            "stdout": error.stdout or "",
            "stderr": error.stderr or "",
        }
        return []
    except (
        FileNotFoundError,
        json.JSONDecodeError,
        OSError,
        UnicodeError,
        ValueError,
        TypeError,
    ) as error:
        _LAST_DISCOVERY_ERROR = {"error": f"read-report failed: {error}"}
        return []
    finally:
        if report_file is not None:
            Path(report_file).unlink(missing_ok=True)
