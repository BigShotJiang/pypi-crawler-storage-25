from __future__ import annotations

import ast
from pathlib import Path
from typing import TypedDict

from persona_dsl.discovery.models import SkillDefinition


class _BuiltinSkillSpec(TypedDict):
    skill_id: str
    class_name: str
    module_path: str
    source_path: str
    factory_methods: list[str]
    description: str


_BUILTIN_SKILLS: list[_BuiltinSkillSpec] = [
    {
        "skill_id": "browser",
        "class_name": "UseBrowser",
        "module_path": "persona_dsl.skills.use_browser",
        "source_path": "src/persona_dsl/skills/use_browser.py",
        "factory_methods": ["from_page"],
        "description": "Навык работы с браузером и страницей Playwright.",
    },
    {
        "skill_id": "api",
        "class_name": "UseAPI",
        "module_path": "persona_dsl.skills.use_api",
        "source_path": "src/persona_dsl/skills/use_api.py",
        "factory_methods": ["at"],
        "description": "Навык HTTP/API-взаимодействия через requests.Session.",
    },
    {
        "skill_id": "db",
        "class_name": "UseDatabase",
        "module_path": "persona_dsl.skills.use_database",
        "source_path": "src/persona_dsl/skills/use_database.py",
        "factory_methods": ["with_dsn"],
        "description": "Навык работы с базой данных через драйвер проекта.",
    },
    {
        "skill_id": "kafka",
        "class_name": "UseKafka",
        "module_path": "persona_dsl.skills.use_kafka",
        "source_path": "src/persona_dsl/skills/use_kafka.py",
        "factory_methods": ["with_servers"],
        "description": "Навык работы с Kafka.",
    },
    {
        "skill_id": "soap",
        "class_name": "UseSOAP",
        "module_path": "persona_dsl.skills.use_soap",
        "source_path": "src/persona_dsl/skills/use_soap.py",
        "factory_methods": ["at"],
        "description": "Навык работы с SOAP-сервисами.",
    },
]
_SKILL_ID_BY_BASE = {
    "UseBrowser": "browser",
    "UseAPI": "api",
    "UseDatabase": "db",
    "UseKafka": "kafka",
    "UseSOAP": "soap",
}


def discover_skills(project_root: str | Path) -> list[SkillDefinition]:
    root = Path(project_root).resolve()
    persona_root = Path(__file__).resolve().parents[2]

    definitions = [
        SkillDefinition(
            id=f"skill::{item['source_path']}::{item['class_name']}",
            skill_id=item["skill_id"],
            class_name=item["class_name"],
            module_path=item["module_path"],
            source_path=item["source_path"],
            factory_methods=list(item["factory_methods"]),
            description=item["description"],
            declared_in_core=True,
        )
        for item in _BUILTIN_SKILLS
    ]

    search_roots = [
        root / "skills",
        root / "tests",
    ]
    for search_root in search_roots:
        if not search_root.is_dir():
            continue
        for py_file in sorted(search_root.rglob("*.py")):
            if py_file.name == "__init__.py":
                continue
            definitions.extend(
                _parse_skill_file(
                    py_file=py_file, project_root=root, persona_root=persona_root
                )
            )

    unique: dict[str, SkillDefinition] = {}
    for definition in definitions:
        unique[definition.id] = definition
    return list(unique.values())


def _parse_skill_file(
    *,
    py_file: Path,
    project_root: Path,
    persona_root: Path,
) -> list[SkillDefinition]:
    try:
        content = py_file.read_text(encoding="utf-8")
    except OSError:
        return []
    try:
        tree = ast.parse(content, filename=str(py_file))
    except SyntaxError:
        return []

    definitions: list[SkillDefinition] = []
    module_path = _module_path(py_file, project_root, persona_root)
    relative_path = _relative_path(py_file, project_root, persona_root)
    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        base_names = {_base_name(base) for base in node.bases}
        base_names.discard(None)
        if "BaseSkill" in base_names:
            definitions.append(
                SkillDefinition(
                    id=f"skill::{relative_path}::{node.name}",
                    skill_id=node.name.lower(),
                    class_name=node.name,
                    module_path=module_path,
                    source_path=relative_path,
                    factory_methods=_class_factory_methods(node),
                    description=ast.get_docstring(node),
                    declared_in_core=py_file.is_relative_to(persona_root),
                )
            )
            continue
        matched_skill_id = next(
            (
                _SKILL_ID_BY_BASE[base_name]
                for base_name in base_names
                if base_name in _SKILL_ID_BY_BASE
            ),
            None,
        )
        if matched_skill_id is None:
            continue
        definitions.append(
            SkillDefinition(
                id=f"skill::{relative_path}::{node.name}",
                skill_id=matched_skill_id,
                class_name=node.name,
                module_path=module_path,
                source_path=relative_path,
                factory_methods=_class_factory_methods(node),
                description=ast.get_docstring(node),
                declared_in_core=py_file.is_relative_to(persona_root),
            )
        )
    return definitions


def _base_name(base: ast.expr) -> str | None:
    if isinstance(base, ast.Name):
        return base.id
    if isinstance(base, ast.Attribute):
        return base.attr
    return None


def _class_factory_methods(node: ast.ClassDef) -> list[str]:
    methods: list[str] = []
    for body_item in node.body:
        if not isinstance(body_item, ast.FunctionDef):
            continue
        decorator_names = {
            _base_name(decorator) for decorator in body_item.decorator_list
        }
        if "classmethod" in decorator_names or "staticmethod" in decorator_names:
            methods.append(body_item.name)
    return methods


def _module_path(py_file: Path, project_root: Path, persona_root: Path) -> str:
    if py_file.is_relative_to(persona_root):
        return "persona_dsl." + ".".join(
            py_file.relative_to(persona_root).with_suffix("").parts
        )
    return ".".join(py_file.relative_to(project_root).with_suffix("").parts)


def _relative_path(py_file: Path, project_root: Path, persona_root: Path) -> str:
    if py_file.is_relative_to(persona_root):
        return str(Path("src") / "persona_dsl" / py_file.relative_to(persona_root))
    return str(py_file.relative_to(project_root))
