from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Self

from persona_dsl.json_types import JsonObject, is_json_object
from persona_dsl.references.models import ReferenceIndexResult
from persona_dsl.scenario.models import ComponentParameter
from persona_dsl.utils.modeling import (
    StrictModel,
    normalize_optional_text,
    require_bool,
    require_int,
    require_literal,
    require_mapping,
    require_mapping_list,
    require_optional_int,
    require_optional_str,
    require_str,
    require_string_list,
)

RuntimeKind = Literal[
    "Ops",
    "Step",
    "CombinedStep",
    "Action",
    "Fact",
    "Expectation",
    "Goal",
]
SemanticKind = Literal["Action", "Fact", "Expectation", "Goal"]
DiagnosticKind = Literal["io", "syntax", "introspection", "metadata", "unsupported"]
DocKind = Literal["page", "task", "test_case", "project", "objective", "key_result"]
TestKind = Literal["file", "class", "method"]


@dataclass(slots=True)
class DiscoveryDiagnostic(StrictModel):
    kind: DiagnosticKind
    path: str
    message: str
    line: int | None = None
    column: int | None = None
    context: str | None = None
    symbol_id: str | None = None

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        return cls(
            kind=require_literal(
                data,
                "kind",
                cls.__name__,
                allowed=("io", "syntax", "introspection", "metadata", "unsupported"),
            ),
            path=require_str(data, "path", cls.__name__),
            message=require_str(data, "message", cls.__name__),
            line=require_optional_int(data, "line", cls.__name__),
            column=require_optional_int(data, "column", cls.__name__),
            context=normalize_optional_text(
                data.get("context"), f"{cls.__name__}.context"
            ),
            symbol_id=require_optional_str(data, "symbol_id", cls.__name__),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        payload = self._base_model_dump(mode=mode)
        payload["error"] = self.message
        return payload


@dataclass(slots=True)
class ElementDefinition(StrictModel):
    var_name: str
    name: str
    type: str
    locator: str | None = None
    aria_ref: str | None = None
    accessible_name: str | None = None
    is_list: bool = False
    children: list["ElementDefinition"] = field(default_factory=list)
    text: str | None = None
    label: str | None = None
    placeholder: str | None = None
    test_id: str | None = None
    alt_text: str | None = None
    title: str | None = None
    description: str | None = None
    url: str | None = None
    static_screenshot_path: str | None = None
    static_aria_snapshot_path: str | None = None
    index: int | None = None
    exact: bool | None = None
    role: str | None = None

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        raw_children = data.get("children", [])
        if not isinstance(raw_children, list):
            raise TypeError(f"{cls.__name__}.children должен быть списком.")
        exact_value = data.get("exact")
        if exact_value is not None and not isinstance(exact_value, bool):
            raise TypeError(
                f"{cls.__name__}.exact должен быть булевым значением или null."
            )
        return cls(
            var_name=require_str(data, "var_name", cls.__name__),
            name=require_str(data, "name", cls.__name__),
            type=require_str(data, "type", cls.__name__),
            locator=require_optional_str(data, "locator", cls.__name__),
            aria_ref=require_optional_str(data, "aria_ref", cls.__name__),
            accessible_name=require_optional_str(data, "accessible_name", cls.__name__),
            is_list=require_bool(data, "is_list", cls.__name__, default=False),
            children=[cls.model_validate(item) for item in raw_children],
            text=require_optional_str(data, "text", cls.__name__),
            label=require_optional_str(data, "label", cls.__name__),
            placeholder=require_optional_str(data, "placeholder", cls.__name__),
            test_id=require_optional_str(data, "test_id", cls.__name__),
            alt_text=require_optional_str(data, "alt_text", cls.__name__),
            title=require_optional_str(data, "title", cls.__name__),
            description=require_optional_str(data, "description", cls.__name__),
            url=require_optional_str(data, "url", cls.__name__),
            static_screenshot_path=require_optional_str(
                data, "static_screenshot_path", cls.__name__
            ),
            static_aria_snapshot_path=require_optional_str(
                data, "static_aria_snapshot_path", cls.__name__
            ),
            index=require_optional_int(data, "index", cls.__name__),
            exact=exact_value,
            role=require_optional_str(data, "role", cls.__name__),
        )


@dataclass(slots=True)
class PageDefinition(StrictModel):
    id: str
    name: str
    qualified_name: str
    path: str
    base_class: str = "Page"
    url: str | None = None
    snapshot_path: str | None = None
    screenshot_path: str | None = None
    elements: list[ElementDefinition] = field(default_factory=list)
    reference_symbol_id: str | None = None

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        raw_elements = data.get("elements", [])
        if not isinstance(raw_elements, list):
            raise TypeError(f"{cls.__name__}.elements должен быть списком.")
        path = require_str(data, "path", cls.__name__)
        name = require_str(data, "name", cls.__name__)
        return cls(
            id=require_optional_str(data, "id", cls.__name__)
            or f"page::{path}::{name}",
            name=name,
            qualified_name=require_optional_str(data, "qualified_name", cls.__name__)
            or name,
            path=path,
            base_class=require_optional_str(data, "base_class", cls.__name__) or "Page",
            url=require_optional_str(data, "url", cls.__name__),
            snapshot_path=require_optional_str(data, "snapshot_path", cls.__name__),
            screenshot_path=require_optional_str(data, "screenshot_path", cls.__name__),
            elements=[ElementDefinition.model_validate(item) for item in raw_elements],
            reference_symbol_id=require_optional_str(
                data, "reference_symbol_id", cls.__name__
            ),
        )


@dataclass(slots=True)
class AnnotationLabel(StrictModel):
    name: str
    value: str

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        return cls(
            name=require_str(data, "name", cls.__name__),
            value=require_str(data, "value", cls.__name__),
        )


@dataclass(slots=True)
class AnnotationLink(StrictModel):
    url: str
    type: str = "link"
    name: str | None = None

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        return cls(
            url=require_str(data, "url", cls.__name__),
            type=require_optional_str(data, "type", cls.__name__) or "link",
            name=require_optional_str(data, "name", cls.__name__),
        )


@dataclass(slots=True)
class AnnotationMetadata(StrictModel):
    title: str | None = None
    description: str | None = None
    description_html: str | None = None
    manual: bool = False
    labels: list[AnnotationLabel] = field(default_factory=list)
    links: list[AnnotationLink] = field(default_factory=list)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        raw_labels = data.get("labels", [])
        raw_links = data.get("links", [])
        if not isinstance(raw_labels, list):
            raise TypeError(f"{cls.__name__}.labels должен быть списком.")
        if not isinstance(raw_links, list):
            raise TypeError(f"{cls.__name__}.links должен быть списком.")
        return cls(
            title=require_optional_str(data, "title", cls.__name__),
            description=require_optional_str(data, "description", cls.__name__),
            description_html=require_optional_str(
                data, "description_html", cls.__name__
            ),
            manual=require_bool(data, "manual", cls.__name__, default=False),
            labels=[AnnotationLabel.model_validate(item) for item in raw_labels],
            links=[AnnotationLink.model_validate(item) for item in raw_links],
        )


@dataclass(slots=True)
class AnnotationProjection(StrictModel):
    title: str | None = None
    description: str | None = None
    description_html: str | None = None
    manual: bool = False
    tags: list[str] = field(default_factory=list)
    epics: list[str] = field(default_factory=list)
    features: list[str] = field(default_factory=list)
    stories: list[str] = field(default_factory=list)
    severity: str | None = None
    annotation_id: str | None = None
    parent_suite: str | None = None
    suite: str | None = None
    sub_suite: str | None = None

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        return cls(
            title=require_optional_str(data, "title", cls.__name__),
            description=require_optional_str(data, "description", cls.__name__),
            description_html=require_optional_str(
                data, "description_html", cls.__name__
            ),
            manual=require_bool(data, "manual", cls.__name__, default=False),
            tags=require_string_list(data.get("tags", []), f"{cls.__name__}.tags"),
            epics=require_string_list(data.get("epics", []), f"{cls.__name__}.epics"),
            features=require_string_list(
                data.get("features", []), f"{cls.__name__}.features"
            ),
            stories=require_string_list(
                data.get("stories", []), f"{cls.__name__}.stories"
            ),
            severity=require_optional_str(data, "severity", cls.__name__),
            annotation_id=require_optional_str(data, "annotation_id", cls.__name__),
            parent_suite=require_optional_str(data, "parent_suite", cls.__name__),
            suite=require_optional_str(data, "suite", cls.__name__),
            sub_suite=require_optional_str(data, "sub_suite", cls.__name__),
        )


@dataclass(slots=True)
class ComponentSymbol(StrictModel):
    id: str
    name: str
    qualified_name: str
    path: str
    runtime_kind: RuntimeKind
    semantic_kind: SemanticKind
    parameters: list[ComponentParameter] = field(default_factory=list)
    description: str | None = None
    base_classes: list[str] = field(default_factory=list)
    ancestor_ids: list[str] = field(default_factory=list)
    descendant_ids: list[str] = field(default_factory=list)
    declared_in_core: bool = False
    reference_symbol_id: str | None = None

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        path = require_str(data, "path", cls.__name__)
        name = require_str(data, "name", cls.__name__)
        raw_parameters = data.get("parameters", [])
        if not isinstance(raw_parameters, list):
            raise TypeError(f"{cls.__name__}.parameters должен быть списком.")
        return cls(
            id=require_optional_str(data, "id", cls.__name__)
            or f"component::{path}::{name}",
            name=name,
            qualified_name=require_optional_str(data, "qualified_name", cls.__name__)
            or name,
            path=path,
            runtime_kind=require_literal(
                data,
                "runtime_kind",
                cls.__name__,
                allowed=(
                    "Ops",
                    "Step",
                    "CombinedStep",
                    "Action",
                    "Fact",
                    "Expectation",
                    "Goal",
                ),
            ),
            semantic_kind=require_literal(
                data,
                "semantic_kind",
                cls.__name__,
                allowed=("Action", "Fact", "Expectation", "Goal"),
            ),
            parameters=[
                ComponentParameter.model_validate(item) for item in raw_parameters
            ],
            description=require_optional_str(data, "description", cls.__name__),
            base_classes=require_string_list(
                data.get("base_classes", []), f"{cls.__name__}.base_classes"
            ),
            ancestor_ids=require_string_list(
                data.get("ancestor_ids", []), f"{cls.__name__}.ancestor_ids"
            ),
            descendant_ids=require_string_list(
                data.get("descendant_ids", []), f"{cls.__name__}.descendant_ids"
            ),
            declared_in_core=require_bool(
                data, "declared_in_core", cls.__name__, default=False
            ),
            reference_symbol_id=require_optional_str(
                data, "reference_symbol_id", cls.__name__
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        payload = self._base_model_dump(mode=mode)
        payload["type"] = self.runtime_kind
        return payload


@dataclass(slots=True)
class TestDefinition(StrictModel):
    id: str
    node_id: str
    name: str
    qualified_name: str
    path: str
    kind: TestKind
    docstring: str | None = None
    annotations: AnnotationMetadata = field(default_factory=AnnotationMetadata)
    annotation_projection: AnnotationProjection = field(
        default_factory=AnnotationProjection
    )
    structure: JsonObject | None = None
    referenced_symbol_ids: list[str] = field(default_factory=list)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        structure = data.get("structure")
        if structure is not None and not is_json_object(structure):
            raise TypeError(
                f"{cls.__name__}.structure должен быть JSON-объектом или null."
            )
        node_id = require_str(data, "node_id", cls.__name__)
        path = require_str(data, "path", cls.__name__)
        name = require_str(data, "name", cls.__name__)
        return cls(
            id=require_optional_str(data, "id", cls.__name__)
            or f"test::{path}::{node_id}",
            node_id=node_id,
            name=name,
            qualified_name=require_optional_str(data, "qualified_name", cls.__name__)
            or node_id,
            path=path,
            kind=require_literal(
                data,
                "kind",
                cls.__name__,
                allowed=("file", "class", "method"),
            ),
            docstring=require_optional_str(data, "docstring", cls.__name__),
            annotations=AnnotationMetadata.model_validate(
                data.get("annotations", data.get("allure", {}))
            ),
            annotation_projection=AnnotationProjection.model_validate(
                data.get("annotation_projection", data.get("allure_projection", {}))
            ),
            structure=structure,
            referenced_symbol_ids=require_string_list(
                data.get("referenced_symbol_ids", []),
                f"{cls.__name__}.referenced_symbol_ids",
            ),
        )


@dataclass(slots=True)
class SkillDefinition(StrictModel):
    id: str
    skill_id: str
    class_name: str
    module_path: str
    source_path: str
    factory_methods: list[str] = field(default_factory=list)
    description: str | None = None
    declared_in_core: bool = False

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        source_path = require_str(data, "source_path", cls.__name__)
        class_name = require_str(data, "class_name", cls.__name__)
        return cls(
            id=require_optional_str(data, "id", cls.__name__)
            or f"skill::{source_path}::{class_name}",
            skill_id=require_str(data, "skill_id", cls.__name__),
            class_name=class_name,
            module_path=require_str(data, "module_path", cls.__name__),
            source_path=source_path,
            factory_methods=require_string_list(
                data.get("factory_methods", []), f"{cls.__name__}.factory_methods"
            ),
            description=require_optional_str(data, "description", cls.__name__),
            declared_in_core=require_bool(
                data, "declared_in_core", cls.__name__, default=False
            ),
        )


@dataclass(slots=True)
class ConfigEnvSummary(StrictModel):
    env: str
    path: str
    persona_roles: list[str] = field(default_factory=list)
    skill_bindings: list[str] = field(default_factory=list)
    reporting_flags: list[str] = field(default_factory=list)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        return cls(
            env=require_str(data, "env", cls.__name__),
            path=require_str(data, "path", cls.__name__),
            persona_roles=require_string_list(
                data.get("persona_roles", []), f"{cls.__name__}.persona_roles"
            ),
            skill_bindings=require_string_list(
                data.get("skill_bindings", []), f"{cls.__name__}.skill_bindings"
            ),
            reporting_flags=require_string_list(
                data.get("reporting_flags", []), f"{cls.__name__}.reporting_flags"
            ),
        )


@dataclass(slots=True)
class DocumentationNode(StrictModel):
    id: str
    doc_kind: DocKind
    title: str
    path: str
    parent_id: str | None = None
    tags: list[str] = field(default_factory=list)
    created_at: str | None = None
    updated_at: str | None = None
    content_markdown: str = ""
    related_doc_ids: list[str] = field(default_factory=list)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        return cls(
            id=require_str(data, "id", cls.__name__),
            doc_kind=require_literal(
                data,
                "doc_kind",
                cls.__name__,
                allowed=(
                    "page",
                    "task",
                    "test_case",
                    "project",
                    "objective",
                    "key_result",
                ),
            ),
            title=require_str(data, "title", cls.__name__),
            path=require_str(data, "path", cls.__name__),
            parent_id=require_optional_str(data, "parent_id", cls.__name__),
            tags=require_string_list(data.get("tags", []), f"{cls.__name__}.tags"),
            created_at=require_optional_str(data, "created_at", cls.__name__),
            updated_at=require_optional_str(data, "updated_at", cls.__name__),
            content_markdown=require_optional_str(
                data, "content_markdown", cls.__name__
            )
            or "",
            related_doc_ids=require_string_list(
                data.get("related_doc_ids", []), f"{cls.__name__}.related_doc_ids"
            ),
        )


@dataclass(slots=True)
class KnowledgeBundle(StrictModel):
    id: str
    title: str
    summary: str
    prompt_text: str
    source_paths: list[str] = field(default_factory=list)
    source_doc_ids: list[str] = field(default_factory=list)
    related_symbol_ids: list[str] = field(default_factory=list)
    fingerprint: str = ""

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        return cls(
            id=require_str(data, "id", cls.__name__),
            title=require_str(data, "title", cls.__name__),
            summary=require_str(data, "summary", cls.__name__),
            prompt_text=require_str(data, "prompt_text", cls.__name__),
            source_paths=require_string_list(
                data.get("source_paths", []), f"{cls.__name__}.source_paths"
            ),
            source_doc_ids=require_string_list(
                data.get("source_doc_ids", []), f"{cls.__name__}.source_doc_ids"
            ),
            related_symbol_ids=require_string_list(
                data.get("related_symbol_ids", []),
                f"{cls.__name__}.related_symbol_ids",
            ),
            fingerprint=require_optional_str(data, "fingerprint", cls.__name__) or "",
        )


@dataclass(slots=True)
class ProjectSummary(StrictModel):
    project_root: str
    fingerprint: str
    components_total: int = 0
    pages_total: int = 0
    tests_total: int = 0
    skills_total: int = 0
    docs_total: int = 0
    config_envs: list[str] = field(default_factory=list)
    diagnostics_total: int = 0

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        return cls(
            project_root=require_str(data, "project_root", cls.__name__),
            fingerprint=require_str(data, "fingerprint", cls.__name__),
            components_total=require_int(data, "components_total", cls.__name__),
            pages_total=require_int(data, "pages_total", cls.__name__),
            tests_total=require_int(data, "tests_total", cls.__name__),
            skills_total=require_int(data, "skills_total", cls.__name__),
            docs_total=require_int(data, "docs_total", cls.__name__),
            config_envs=require_string_list(
                data.get("config_envs", []), f"{cls.__name__}.config_envs"
            ),
            diagnostics_total=require_int(data, "diagnostics_total", cls.__name__),
        )


@dataclass(slots=True)
class ProjectIndex(StrictModel):
    summary: ProjectSummary
    components: list[ComponentSymbol] = field(default_factory=list)
    pages: list[PageDefinition] = field(default_factory=list)
    tests: list[TestDefinition] = field(default_factory=list)
    skills: list[SkillDefinition] = field(default_factory=list)
    configs: list[ConfigEnvSummary] = field(default_factory=list)
    docs: list[DocumentationNode] = field(default_factory=list)
    references: ReferenceIndexResult = field(default_factory=ReferenceIndexResult)
    diagnostics: list[DiscoveryDiagnostic] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.summary = ProjectSummary.model_validate(self.summary)
        self.components = [
            ComponentSymbol.model_validate(item) for item in self.components
        ]
        self.pages = [PageDefinition.model_validate(item) for item in self.pages]
        self.tests = [TestDefinition.model_validate(item) for item in self.tests]
        self.skills = [SkillDefinition.model_validate(item) for item in self.skills]
        self.configs = [ConfigEnvSummary.model_validate(item) for item in self.configs]
        self.docs = [DocumentationNode.model_validate(item) for item in self.docs]
        self.references = ReferenceIndexResult.model_validate(self.references)
        self.diagnostics = [
            DiscoveryDiagnostic.model_validate(item) for item in self.diagnostics
        ]

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = require_mapping(raw, cls.__name__)
        return cls(
            summary=ProjectSummary.model_validate(data.get("summary")),
            components=[
                ComponentSymbol.model_validate(item)
                for item in require_mapping_list(
                    data.get("components", []), f"{cls.__name__}.components"
                )
            ],
            pages=[
                PageDefinition.model_validate(item)
                for item in require_mapping_list(
                    data.get("pages", []), f"{cls.__name__}.pages"
                )
            ],
            tests=[
                TestDefinition.model_validate(item)
                for item in require_mapping_list(
                    data.get("tests", []), f"{cls.__name__}.tests"
                )
            ],
            skills=[
                SkillDefinition.model_validate(item)
                for item in require_mapping_list(
                    data.get("skills", []), f"{cls.__name__}.skills"
                )
            ],
            configs=[
                ConfigEnvSummary.model_validate(item)
                for item in require_mapping_list(
                    data.get("configs", []), f"{cls.__name__}.configs"
                )
            ],
            docs=[
                DocumentationNode.model_validate(item)
                for item in require_mapping_list(
                    data.get("docs", []), f"{cls.__name__}.docs"
                )
            ],
            references=ReferenceIndexResult.model_validate(data.get("references", {})),
            diagnostics=[
                DiscoveryDiagnostic.model_validate(item)
                for item in require_mapping_list(
                    data.get("diagnostics", []), f"{cls.__name__}.diagnostics"
                )
            ],
        )


ElementDefinition.__annotations__["children"] = list[ElementDefinition]
