from __future__ import annotations

from pathlib import Path

from persona_dsl.discovery.models import ConfigEnvSummary
from persona_dsl.utils.config import Config


def discover_configs(project_root: str | Path) -> list[ConfigEnvSummary]:
    root = Path(project_root).resolve()
    config_dir = root / "config"
    if not config_dir.is_dir():
        return []

    summaries: list[ConfigEnvSummary] = []
    for config_path in sorted(config_dir.glob("*.yaml")):
        if config_path.stem == "auth":
            continue
        env = config_path.stem
        config = Config.load(env, project_root=root)
        summaries.append(
            ConfigEnvSummary(
                env=env,
                path=str(config_path.relative_to(root)),
                persona_roles=sorted(config.personas.roles.keys()),
                skill_bindings=_collect_skill_bindings(config),
                reporting_flags=_collect_reporting_flags(config),
            )
        )
    return summaries


def _collect_skill_bindings(config: Config) -> list[str]:
    bindings: list[str] = []
    skills_dump = config.skills.model_dump(mode="python")
    for skill_type, named_configs in skills_dump.items():
        if not isinstance(named_configs, dict):
            continue
        for skill_name in sorted(named_configs):
            bindings.append(f"{skill_type}.{skill_name}")
    return bindings


def _collect_reporting_flags(config: Config) -> list[str]:
    flags: list[str] = []
    for key, value in config.reporting.model_dump(mode="python").items():
        if value is None:
            continue
        flags.append(f"{key}={value}")
    return sorted(flags)
