from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence

from persona_dsl.discovery.models import (
    AnnotationLabel,
    AnnotationLink,
    AnnotationMetadata,
    AnnotationProjection,
)
from persona_dsl.utils.modeling import normalize_optional_text, require_mapping

ANNOTATION_EPIC_LABEL = "epic"
ANNOTATION_FEATURE_LABEL = "feature"
ANNOTATION_STORY_LABEL = "story"
ANNOTATION_TAG_LABEL = "tag"
ANNOTATION_SEVERITY_LABEL = "severity"
ANNOTATION_ID_LABEL = "as_id"
ANNOTATION_PARENT_SUITE_LABEL = "parentSuite"
ANNOTATION_SUITE_LABEL = "suite"
ANNOTATION_SUB_SUITE_LABEL = "subSuite"
ANNOTATION_MANUAL_LABEL = "ALLURE_MANUAL"

ANNOTATION_ISSUE_LINK_TYPE = "issue"
ANNOTATION_TESTCASE_LINK_TYPE = "tms"
ANNOTATION_DEFAULT_LINK_TYPE = "link"

ANNOTATION_RESERVED_MULTI_LABELS = {
    ANNOTATION_EPIC_LABEL,
    ANNOTATION_FEATURE_LABEL,
    ANNOTATION_STORY_LABEL,
    ANNOTATION_TAG_LABEL,
}
ANNOTATION_RESERVED_SINGLE_LABELS = {
    ANNOTATION_SEVERITY_LABEL,
    ANNOTATION_ID_LABEL,
    ANNOTATION_PARENT_SUITE_LABEL,
    ANNOTATION_SUITE_LABEL,
    ANNOTATION_SUB_SUITE_LABEL,
}
ANNOTATION_RESERVED_LABELS = (
    ANNOTATION_RESERVED_MULTI_LABELS
    | ANNOTATION_RESERVED_SINGLE_LABELS
    | {ANNOTATION_MANUAL_LABEL}
)


def normalize_bool(value: object, field_name: str) -> bool:
    if not isinstance(value, bool):
        raise ValueError(f"Поле {field_name} должно быть булевым значением.")
    return value


def _normalize_label_type(value: object, field_name: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"Поле {field_name} должно быть строкой.")
    normalized = value.strip()
    if not normalized:
        raise ValueError(f"Поле {field_name} не должно быть пустым.")
    return normalized


def _normalize_label_value(value: object, field_name: str) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if not isinstance(value, str):
        raise ValueError(f"Поле {field_name} должно быть строкой.")
    normalized = value.strip()
    if not normalized:
        raise ValueError(f"Поле {field_name} не должно быть пустым.")
    return normalized


def _dedupe_values(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result


def _dedupe_labels(entries: Iterable[AnnotationLabel]) -> list[AnnotationLabel]:
    seen: set[tuple[str, str]] = set()
    result: list[AnnotationLabel] = []
    for entry in entries:
        key = (entry.name, entry.value)
        if key in seen:
            continue
        seen.add(key)
        result.append(entry)
    return result


def _dedupe_links(entries: Iterable[AnnotationLink]) -> list[AnnotationLink]:
    seen: set[tuple[str, str, str | None]] = set()
    result: list[AnnotationLink] = []
    for entry in entries:
        key = (entry.type, entry.url, entry.name)
        if key in seen:
            continue
        seen.add(key)
        result.append(entry)
    return result


def coerce_annotation_labels(
    value: object, field_name: str = "labels"
) -> list[AnnotationLabel]:
    if value is None:
        return []
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise ValueError(f"Поле {field_name} должно быть массивом labels.")

    entries: list[AnnotationLabel] = []
    for index, item in enumerate(value):
        data = require_mapping(item, f"{field_name}[{index}]")
        name = _normalize_label_type(data.get("name"), f"{field_name}[{index}].name")
        if name == ANNOTATION_MANUAL_LABEL:
            continue
        entries.append(
            AnnotationLabel(
                name=name,
                value=_normalize_label_value(
                    data.get("value"), f"{field_name}[{index}].value"
                ),
            )
        )
    return _dedupe_labels(entries)


def coerce_annotation_links(
    value: object, field_name: str = "links"
) -> list[AnnotationLink]:
    if value is None:
        return []
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise ValueError(f"Поле {field_name} должно быть массивом links.")

    entries: list[AnnotationLink] = []
    for index, item in enumerate(value):
        data = require_mapping(item, f"{field_name}[{index}]")
        url = normalize_optional_text(data.get("url"), f"{field_name}[{index}].url")
        link_type = normalize_optional_text(
            data.get("type"), f"{field_name}[{index}].type"
        )
        name = normalize_optional_text(data.get("name"), f"{field_name}[{index}].name")
        if url is None:
            raise ValueError(f"Поле {field_name}[{index}].url не должно быть пустым.")
        entries.append(
            AnnotationLink(
                url=url,
                type=link_type or ANNOTATION_DEFAULT_LINK_TYPE,
                name=name,
            )
        )
    return _dedupe_links(entries)


def build_annotation_metadata(
    *,
    title: str | None = None,
    description: str | None = None,
    description_html: str | None = None,
    manual: bool = False,
    labels: Sequence[AnnotationLabel] | None = None,
    links: Sequence[AnnotationLink] | None = None,
) -> AnnotationMetadata:
    return AnnotationMetadata(
        title=normalize_optional_text(title, "title"),
        description=normalize_optional_text(description, "description"),
        description_html=normalize_optional_text(description_html, "description_html"),
        manual=bool(manual),
        labels=_dedupe_labels(labels or []),
        links=_dedupe_links(links or []),
    )


def coerce_annotation_metadata(
    value: object | None,
    field_name: str = "annotations",
) -> AnnotationMetadata:
    if value is None:
        return build_annotation_metadata()
    data = require_mapping(value, field_name)
    manual_raw = data.get("manual", False)
    manual = (
        False
        if manual_raw is None
        else normalize_bool(manual_raw, f"{field_name}.manual")
    )
    labels = coerce_annotation_labels(data.get("labels"), f"{field_name}.labels")
    links = coerce_annotation_links(data.get("links"), f"{field_name}.links")
    return build_annotation_metadata(
        title=normalize_optional_text(data.get("title"), f"{field_name}.title"),
        description=normalize_optional_text(
            data.get("description"), f"{field_name}.description"
        ),
        description_html=normalize_optional_text(
            data.get("description_html"), f"{field_name}.description_html"
        ),
        manual=manual,
        labels=labels,
        links=links,
    )


def project_annotation_metadata(
    metadata: Mapping[str, object] | AnnotationMetadata | None,
) -> AnnotationProjection:
    parsed = coerce_annotation_metadata(metadata)
    multi_values: dict[str, list[str]] = {
        ANNOTATION_TAG_LABEL: [],
        ANNOTATION_EPIC_LABEL: [],
        ANNOTATION_FEATURE_LABEL: [],
        ANNOTATION_STORY_LABEL: [],
    }
    single_values: dict[str, str | None] = {
        ANNOTATION_SEVERITY_LABEL: None,
        ANNOTATION_ID_LABEL: None,
        ANNOTATION_PARENT_SUITE_LABEL: None,
        ANNOTATION_SUITE_LABEL: None,
        ANNOTATION_SUB_SUITE_LABEL: None,
    }

    for entry in parsed.labels:
        label_name = entry.name
        label_value = entry.value
        if label_name in multi_values:
            multi_values[label_name].append(label_value)
            continue
        if label_name in single_values and single_values[label_name] is None:
            single_values[label_name] = label_value

    return AnnotationProjection(
        title=parsed.title,
        description=parsed.description,
        description_html=parsed.description_html,
        manual=parsed.manual,
        tags=_dedupe_values(multi_values[ANNOTATION_TAG_LABEL]),
        epics=_dedupe_values(multi_values[ANNOTATION_EPIC_LABEL]),
        features=_dedupe_values(multi_values[ANNOTATION_FEATURE_LABEL]),
        stories=_dedupe_values(multi_values[ANNOTATION_STORY_LABEL]),
        severity=single_values[ANNOTATION_SEVERITY_LABEL],
        annotation_id=single_values[ANNOTATION_ID_LABEL],
        parent_suite=single_values[ANNOTATION_PARENT_SUITE_LABEL],
        suite=single_values[ANNOTATION_SUITE_LABEL],
        sub_suite=single_values[ANNOTATION_SUB_SUITE_LABEL],
    )
