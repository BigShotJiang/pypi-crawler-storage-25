from __future__ import annotations

import re
from pathlib import Path

from persona_dsl.discovery.models import DocKind, DocumentationNode

_DOC_KIND_BY_DIR: dict[str, DocKind] = {
    "pages": "page",
    "tasks": "task",
    "test_cases": "test_case",
    "projects": "project",
    "objectives": "objective",
    "key_results": "key_result",
}
_ID_PATTERN = re.compile(r"\bLCL[-A-Za-z0-9_]+\b")


def discover_docs(project_root: str | Path) -> list[DocumentationNode]:
    root = Path(project_root).resolve()
    docs_root = root / "docs"
    if not docs_root.is_dir():
        return []

    documents: list[DocumentationNode] = []
    for file_path in sorted(docs_root.rglob("*.md")):
        if file_path.name.startswith("."):
            continue
        relative_path = str(file_path.relative_to(root))
        content = file_path.read_text(encoding="utf-8")
        node = _parse_doc_file(content=content, relative_path=relative_path)
        if node is not None:
            documents.append(node)
    return documents


def _parse_doc_file(
    *,
    content: str,
    relative_path: str,
) -> DocumentationNode | None:
    relative = Path(relative_path)
    parts = relative.parts
    if len(parts) < 2 or parts[0] != "docs":
        return None

    if relative.name in {"_catalog.md", "_ids.md"}:
        title = _extract_title(content) or relative.stem
        return DocumentationNode(
            id=f"doc::{relative_path}",
            doc_kind="project",
            title=title,
            path=relative_path,
            content_markdown=content.strip(),
            related_doc_ids=sorted(set(_ID_PATTERN.findall(content))),
        )

    section_name = parts[1] if len(parts) > 1 else ""
    doc_kind = _DOC_KIND_BY_DIR.get(section_name, "project")
    title = _extract_title(content) or relative.stem

    if relative.name == "_index.md":
        return DocumentationNode(
            id=f"doc::{relative_path}",
            doc_kind=doc_kind,
            title=title,
            path=relative_path,
            content_markdown=content.strip(),
            related_doc_ids=sorted(set(_ID_PATTERN.findall(content))),
        )

    if relative.suffix != ".md":
        return None

    meta = _extract_meta(content)
    content_section = _extract_content_section(content)
    return DocumentationNode(
        id=meta.get("id") or f"doc::{relative_path}",
        doc_kind=doc_kind,
        title=title,
        path=relative_path,
        parent_id=meta.get("parent_id"),
        tags=_split_tags(meta.get("tags")),
        created_at=meta.get("created_at"),
        updated_at=meta.get("updated_at"),
        content_markdown=content_section,
        related_doc_ids=_extract_related_doc_ids(content),
    )


def _extract_title(content: str) -> str | None:
    for line in content.splitlines():
        stripped = line.strip()
        if stripped.startswith("# "):
            title = stripped[2:].strip()
            title = re.sub(r"^[^\wА-Яа-я]+", "", title).strip()
            if title:
                return title
    return None


def _extract_meta(content: str) -> dict[str, str | None]:
    lines = content.splitlines()
    in_meta = False
    meta: dict[str, str | None] = {}
    for line in lines:
        stripped = line.strip()
        if stripped == "## 📌 Мета":
            in_meta = True
            continue
        if in_meta and stripped.startswith("## "):
            break
        if not in_meta or not stripped.startswith("- "):
            continue
        key_value = stripped[2:].split(":", maxsplit=1)
        if len(key_value) != 2:
            continue
        key = key_value[0].strip()
        value = key_value[1].strip()
        normalized = None if value in {"null", ""} else value
        if key == "ID":
            meta["id"] = normalized
        elif key == "Родитель":
            meta["parent_id"] = normalized
        elif key == "Теги":
            meta["tags"] = normalized
        elif key == "Создано":
            meta["created_at"] = normalized
        elif key == "Обновлено":
            meta["updated_at"] = normalized
    return meta


def _extract_content_section(content: str) -> str:
    lines = content.splitlines()
    in_content = False
    collected: list[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped == "## 📝 Контент":
            in_content = True
            continue
        if in_content and stripped.startswith("## "):
            break
        if in_content:
            collected.append(line.rstrip())
    result = "\n".join(collected).strip()
    return result or content.strip()


def _extract_related_doc_ids(content: str) -> list[str]:
    related: list[str] = []
    lines = content.splitlines()
    in_relations = False
    for line in lines:
        stripped = line.strip()
        if stripped == "## 🔗 Связи":
            in_relations = True
            continue
        if in_relations and stripped.startswith("## "):
            break
        if in_relations:
            for match in _ID_PATTERN.findall(line):
                if match not in related:
                    related.append(match)
    if related:
        return related
    return sorted(set(_ID_PATTERN.findall(content)))


def _split_tags(raw_tags: str | None) -> list[str]:
    if raw_tags is None:
        return []
    return [tag.strip() for tag in raw_tags.split(",") if tag.strip()]
