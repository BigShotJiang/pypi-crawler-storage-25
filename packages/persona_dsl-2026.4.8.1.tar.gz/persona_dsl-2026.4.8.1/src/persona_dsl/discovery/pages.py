from __future__ import annotations

import ast
import logging
import os
from dataclasses import dataclass
from pathlib import Path

from persona_dsl.discovery.models import ElementDefinition, PageDefinition

logger = logging.getLogger(__name__)

_PAGE_CLASS_MARKER = "Page"


@dataclass(slots=True)
class _RawElementNode:
    var_name: str
    name: str
    type: str
    locator: str | None
    aria_ref: str | None
    accessible_name: str | None
    is_list: bool
    parent: str | None
    text: str | None = None
    label: str | None = None
    placeholder: str | None = None
    test_id: str | None = None
    alt_text: str | None = None
    title: str | None = None
    description: str | None = None
    url: str | None = None
    static_screenshot_path: str | None = None
    static_aria_snapshot_path: str | None = None
    index: int | None = None
    exact: bool | None = None
    role: str | None = None


def discover_pages(project_root: str | Path) -> list[PageDefinition]:
    root = Path(project_root).resolve()
    pages_dir = root / "tests" / "pages"
    if not pages_dir.exists():
        return []

    results: list[PageDefinition] = []
    for current_root, _, files in os.walk(pages_dir):
        for file_name in files:
            if not file_name.endswith(".py") or file_name.startswith("__"):
                continue
            full_path = Path(current_root) / file_name
            rel_path = str(full_path.relative_to(root))
            page = get_page_details(project_root=root, rel_path=rel_path)
            if page is not None:
                results.append(page)
    return results


def get_page_details(
    *, project_root: str | Path, rel_path: str
) -> PageDefinition | None:
    full_path = Path(project_root).resolve() / rel_path
    if not full_path.exists():
        return None

    try:
        code = full_path.read_text(encoding="utf-8")
    except OSError as error:
        logger.warning("Не удалось прочитать файл страницы %s: %s", full_path, error)
        return None
    return parse_page_code(code=code, rel_path=rel_path)


def parse_page_code(*, code: str, rel_path: str) -> PageDefinition | None:
    try:
        tree = ast.parse(code, filename=rel_path)
    except SyntaxError as error:
        logger.warning(
            "Не удалось разобрать AST страницы %s: строка=%s столбец=%s %s",
            rel_path,
            error.lineno,
            error.offset,
            error.msg,
        )
        return None
    return _get_page_details_from_ast(tree, rel_path)


def _class_base_name(base: ast.expr) -> str | None:
    if isinstance(base, ast.Name):
        return base.id
    if isinstance(base, ast.Attribute):
        return base.attr
    return None


def _is_page_class(node: ast.ClassDef) -> bool:
    if _PAGE_CLASS_MARKER in node.name:
        return True
    return any(
        base_name is not None and _PAGE_CLASS_MARKER in base_name
        for base_name in (_class_base_name(base) for base in node.bases)
    )


def _string_or_none_constant(value: ast.expr) -> str | None:
    if not isinstance(value, ast.Constant):
        return None
    constant_value = value.value
    if isinstance(constant_value, str) or constant_value is None:
        return constant_value
    return None


def _bool_or_none_constant(value: ast.expr) -> bool | None:
    if not isinstance(value, ast.Constant):
        return None
    constant_value = value.value
    if isinstance(constant_value, bool):
        return constant_value
    return None


def _int_or_none_constant(value: ast.expr) -> int | None:
    if not isinstance(value, ast.Constant):
        return None
    constant_value = value.value
    if isinstance(constant_value, bool):
        return None
    if isinstance(constant_value, int):
        return constant_value
    return None


def _page_attr_value(value: ast.expr) -> str | None:
    return _string_or_none_constant(value)


def _self_attribute_name(target: ast.Attribute) -> str | None:
    current: ast.expr = target
    while isinstance(current, ast.Attribute):
        if isinstance(current.value, ast.Name) and current.value.id == "self":
            return target.attr
        current = current.value
    return None


def _keyword_value(keywords: list[ast.keyword], name: str) -> ast.expr | None:
    for keyword in keywords:
        if keyword.arg == name:
            return keyword.value
    return None


def _keyword_string_arg(keywords: list[ast.keyword], name: str) -> str | None:
    value = _keyword_value(keywords, name)
    if value is None:
        return None
    return _string_or_none_constant(value)


def _keyword_bool_arg(keywords: list[ast.keyword], name: str) -> bool | None:
    value = _keyword_value(keywords, name)
    if value is None:
        return None
    return _bool_or_none_constant(value)


def _keyword_int_arg(keywords: list[ast.keyword], name: str) -> int | None:
    value = _keyword_value(keywords, name)
    if value is None:
        return None
    return _int_or_none_constant(value)


def _constructor_name(call: ast.Call) -> str:
    if isinstance(call.func, ast.Name):
        return call.func.id
    if isinstance(call.func, ast.Attribute):
        return call.func.attr
    return "Element"


def _element_from_constructor(
    *,
    var_name: str,
    call: ast.Call,
    parent_name: str | None,
    is_list: bool,
) -> _RawElementNode:
    locator = _keyword_string_arg(call.keywords, "selector")
    if locator is None:
        locator = _keyword_string_arg(call.keywords, "locator")
    return _RawElementNode(
        var_name=var_name,
        name=_keyword_string_arg(call.keywords, "name") or var_name,
        type=_constructor_name(call),
        locator=locator,
        aria_ref=_keyword_string_arg(call.keywords, "aria_ref"),
        accessible_name=_keyword_string_arg(call.keywords, "accessible_name"),
        is_list=is_list,
        parent=parent_name,
        text=_keyword_string_arg(call.keywords, "text"),
        label=_keyword_string_arg(call.keywords, "label"),
        placeholder=_keyword_string_arg(call.keywords, "placeholder"),
        test_id=_keyword_string_arg(call.keywords, "test_id"),
        alt_text=_keyword_string_arg(call.keywords, "alt_text"),
        title=_keyword_string_arg(call.keywords, "title"),
        description=_keyword_string_arg(call.keywords, "description"),
        url=_keyword_string_arg(call.keywords, "url"),
        static_screenshot_path=_keyword_string_arg(
            call.keywords, "static_screenshot_path"
        ),
        static_aria_snapshot_path=_keyword_string_arg(
            call.keywords, "static_aria_snapshot_path"
        ),
        index=_keyword_int_arg(call.keywords, "index"),
        exact=_keyword_bool_arg(call.keywords, "exact"),
        role=_keyword_string_arg(call.keywords, "role"),
    )


def _get_page_details_from_ast(
    tree: ast.Module, rel_path: str
) -> PageDefinition | None:
    target_class: ast.ClassDef | None = None
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and _is_page_class(node):
            target_class = node

    if target_class is None:
        return None

    base_class = "Page"
    if target_class.bases:
        first_base_name = _class_base_name(target_class.bases[0])
        if first_base_name is not None:
            base_class = first_base_name

    elements = _extract_elements_from_class(target_class)
    url: str | None = None
    snapshot_path: str | None = None
    screenshot_path: str | None = None

    for node in target_class.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            target = node.targets[0]
            if isinstance(target, ast.Name):
                value = _page_attr_value(node.value)
                if target.id in {"url", "expected_path"}:
                    url = value
                elif target.id == "static_aria_snapshot_path":
                    snapshot_path = value
                elif target.id == "static_screenshot_path":
                    screenshot_path = value

    init_method = next(
        (
            node
            for node in target_class.body
            if isinstance(node, ast.FunctionDef) and node.name == "__init__"
        ),
        None,
    )
    if init_method is not None:
        for node in init_method.body:
            if not (isinstance(node, ast.Assign) and len(node.targets) == 1):
                continue
            target = node.targets[0]
            if not isinstance(target, ast.Attribute):
                continue
            attr_name = _self_attribute_name(target)
            if attr_name is None:
                continue
            value = _page_attr_value(node.value)
            if attr_name == "expected_path":
                url = value
            elif attr_name == "static_aria_snapshot_path":
                snapshot_path = value
            elif attr_name == "static_screenshot_path":
                screenshot_path = value

    module_name = rel_path.removesuffix(".py").replace("/", ".")
    return PageDefinition(
        id=f"page::{rel_path}::{target_class.name}",
        name=target_class.name,
        qualified_name=f"{module_name}.{target_class.name}",
        path=rel_path,
        elements=elements,
        base_class=base_class,
        url=url,
        snapshot_path=snapshot_path,
        screenshot_path=screenshot_path,
    )


def _extract_elements_from_class(class_node: ast.ClassDef) -> list[ElementDefinition]:
    raw_nodes: dict[str, _RawElementNode] = {}
    ordered_names: list[str] = []

    for body_item in class_node.body:
        if isinstance(body_item, ast.Assign) and len(body_item.targets) == 1:
            target = body_item.targets[0]
            if isinstance(target, ast.Name) and isinstance(body_item.value, ast.Call):
                var_name = target.id
                if var_name not in raw_nodes:
                    ordered_names.append(var_name)
                raw_nodes[var_name] = _element_from_constructor(
                    var_name=var_name,
                    call=body_item.value,
                    parent_name=None,
                    is_list=False,
                )

    init_method = next(
        (
            node
            for node in class_node.body
            if isinstance(node, ast.FunctionDef) and node.name == "__init__"
        ),
        None,
    )
    if init_method is not None:
        refined_nodes, refined_order = _extract_raw_tree_nodes(init_method)
        for name in refined_order:
            if name not in raw_nodes:
                ordered_names.append(name)
        raw_nodes.update(refined_nodes)

    return _build_tree(raw_nodes, ordered_names)


def _build_tree(
    raw_nodes: dict[str, _RawElementNode],
    ordered_names: list[str],
) -> list[ElementDefinition]:
    parent_lookup = {
        name: info.parent for name, info in raw_nodes.items() if info.parent is not None
    }

    def creates_cycle(child_name: str, parent_name: str) -> bool:
        seen: set[str] = {child_name}
        current_name: str | None = parent_name
        while current_name is not None:
            if current_name in seen:
                return True
            seen.add(current_name)
            current_name = parent_lookup.get(current_name)
        return False

    created_objs: dict[str, ElementDefinition] = {}
    for name, info in raw_nodes.items():
        created_objs[name] = ElementDefinition(
            var_name=info.var_name,
            name=info.name,
            type=info.type,
            locator=info.locator,
            aria_ref=info.aria_ref,
            accessible_name=info.accessible_name,
            is_list=info.is_list,
            text=info.text,
            label=info.label,
            placeholder=info.placeholder,
            test_id=info.test_id,
            alt_text=info.alt_text,
            title=info.title,
            description=info.description,
            url=info.url,
            static_screenshot_path=info.static_screenshot_path,
            static_aria_snapshot_path=info.static_aria_snapshot_path,
            index=info.index,
            exact=info.exact,
            role=info.role,
        )

    roots: list[ElementDefinition] = []
    for name in ordered_names:
        current = created_objs.get(name)
        raw_info = raw_nodes.get(name)
        if current is None or raw_info is None:
            continue
        parent_name = raw_info.parent
        if parent_name is None:
            roots.append(current)
            continue
        parent = created_objs.get(parent_name)
        if parent is None or parent is current or creates_cycle(name, parent_name):
            roots.append(current)
            continue
        if current not in parent.children:
            parent.children.append(current)

    if not roots:
        return list(created_objs.values())
    return roots


def _extract_raw_tree_nodes(
    init_method: ast.FunctionDef,
) -> tuple[dict[str, _RawElementNode], list[str]]:
    raw_nodes: dict[str, _RawElementNode] = {}
    ordered_names: list[str] = []

    for stmt in init_method.body:
        if not (isinstance(stmt, ast.Assign) and len(stmt.targets) == 1):
            continue

        target = stmt.targets[0]
        if not isinstance(target, ast.Attribute):
            continue

        var_name = _self_attribute_name(target)
        if var_name is None or not isinstance(stmt.value, ast.Call):
            continue

        call = stmt.value
        if not isinstance(call.func, ast.Attribute):
            continue
        if call.func.attr not in {"add_element", "add_element_list"}:
            continue

        parent_name: str | None = None
        if isinstance(call.func.value, ast.Attribute):
            parent_name = call.func.value.attr
        elif not (
            isinstance(call.func.value, ast.Name) and call.func.value.id == "self"
        ):
            continue

        if not call.args or not isinstance(call.args[0], ast.Call):
            continue

        if var_name not in raw_nodes:
            ordered_names.append(var_name)

        raw_nodes[var_name] = _element_from_constructor(
            var_name=var_name,
            call=call.args[0],
            parent_name=parent_name,
            is_list=call.func.attr == "add_element_list",
        )

    return raw_nodes, ordered_names


def _refine_tree_extraction(init_method: ast.FunctionDef) -> list[ElementDefinition]:
    raw_nodes, ordered_names = _extract_raw_tree_nodes(init_method)
    return _build_tree(raw_nodes, ordered_names)
