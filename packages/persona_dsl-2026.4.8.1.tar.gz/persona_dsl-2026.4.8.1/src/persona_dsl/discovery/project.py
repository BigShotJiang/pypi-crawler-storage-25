from __future__ import annotations

import hashlib
from functools import lru_cache
from pathlib import Path
from typing import Literal, TypedDict

from persona_dsl.discovery.components import discover_components, get_discovery_errors
from persona_dsl.discovery.configs import discover_configs
from persona_dsl.discovery.docs import discover_docs
from persona_dsl.discovery.models import (
    ComponentSymbol,
    DiscoveryDiagnostic,
    DocumentationNode,
    KnowledgeBundle,
    PageDefinition,
    ProjectIndex,
    ProjectSummary,
    SkillDefinition,
    TestDefinition,
)
from persona_dsl.discovery.pages import discover_pages
from persona_dsl.discovery.skills import discover_skills
from persona_dsl.discovery.tests import (
    discover_tests,
    get_last_test_discovery_error,
    get_test_discovery_diagnostics,
)
from persona_dsl.references import (
    build_reference_index,
    find_symbol_usages as _find_symbol_usages,
)
from persona_dsl.references.models import ReferenceIndexResult, ReferenceSymbol

ProjectSymbol = (
    ComponentSymbol
    | PageDefinition
    | TestDefinition
    | SkillDefinition
    | DocumentationNode
)
SymbolKind = Literal["component", "page", "test", "skill", "doc", "reference"]

_BUNDLE_IDS = {
    "overview",
    "project_principles",
    "test_authoring",
    "ops_catalog",
    "components_and_composition",
    "pages_and_generation",
    "skills_and_config",
    "project_specific_context",
}


class _BundleSources(TypedDict):
    title: str
    summary: str
    chunks: list[str]
    source_paths: set[str]
    source_doc_ids: set[str]
    related_symbol_ids: set[str]


def build_project_index(project_root: str | Path) -> ProjectIndex:
    root = Path(project_root).resolve()
    fingerprint = _project_fingerprint(root)
    return _build_project_index_cached(str(root), fingerprint)


@lru_cache(maxsize=8)
def _build_project_index_cached(project_root: str, fingerprint: str) -> ProjectIndex:
    root = Path(project_root)
    references = build_reference_index(root)
    pages = _attach_page_references(discover_pages(root), references)
    components = _attach_component_references(discover_components(root), references)
    tests = discover_tests(root, reference_index=references)
    docs = discover_docs(root)
    skills = discover_skills(root)
    configs = discover_configs(root)
    diagnostics = [
        *get_discovery_errors(),
        *get_test_discovery_diagnostics(),
        *_test_discovery_error_diagnostics(root),
    ]
    summary = ProjectSummary(
        project_root=str(root),
        fingerprint=fingerprint,
        components_total=len(components),
        pages_total=len(pages),
        tests_total=len(tests),
        skills_total=len(skills),
        docs_total=len(docs),
        config_envs=[item.env for item in configs],
        diagnostics_total=len(diagnostics),
    )
    return ProjectIndex(
        summary=summary,
        components=components,
        pages=pages,
        tests=tests,
        skills=skills,
        configs=configs,
        docs=docs,
        references=references,
        diagnostics=diagnostics,
    )


def get_project_summary(project_root: str | Path) -> ProjectSummary:
    return build_project_index(project_root).summary


def discover_components_model(project_root: str | Path) -> list[ComponentSymbol]:
    return build_project_index(project_root).components


def discover_pages_model(project_root: str | Path) -> list[PageDefinition]:
    return build_project_index(project_root).pages


def list_symbols(
    project_root: str | Path,
    kind: SymbolKind | None = None,
) -> list[ProjectSymbol | ReferenceSymbol]:
    index = build_project_index(project_root)
    if kind == "component":
        return list(index.components)
    if kind == "page":
        return list(index.pages)
    if kind == "test":
        return list(index.tests)
    if kind == "skill":
        return list(index.skills)
    if kind == "doc":
        return list(index.docs)
    if kind == "reference":
        return list(index.references.symbols)
    return [
        *index.components,
        *index.pages,
        *index.tests,
        *index.skills,
        *index.docs,
        *index.references.symbols,
    ]


def get_symbol(
    project_root: str | Path, symbol_id: str
) -> ProjectSymbol | ReferenceSymbol:
    for symbol in list_symbols(project_root):
        if symbol.id == symbol_id:
            return symbol
    raise ValueError(f"Symbol not found: {symbol_id}")


def get_discovery_diagnostics(project_root: str | Path) -> list[DiscoveryDiagnostic]:
    return build_project_index(project_root).diagnostics


def get_knowledge_bundle(project_root: str | Path, bundle_id: str) -> KnowledgeBundle:
    if bundle_id not in _BUNDLE_IDS:
        raise ValueError(
            f"Unsupported bundle id '{bundle_id}'. Поддерживаемые значения: {', '.join(sorted(_BUNDLE_IDS))}."
        )
    index = build_project_index(project_root)
    root = Path(project_root).resolve()
    bundle_sources = _bundle_sources(bundle_id=bundle_id, index=index, root=root)
    if not bundle_sources["chunks"]:
        raise ValueError(f"Для bundle '{bundle_id}' не найдены явные источники.")

    prompt_text = "\n\n".join(bundle_sources["chunks"]).strip()
    summary = bundle_sources["summary"]
    source_paths = sorted(bundle_sources["source_paths"])
    source_doc_ids = sorted(bundle_sources["source_doc_ids"])
    related_symbol_ids = sorted(bundle_sources["related_symbol_ids"])
    fingerprint = hashlib.sha256(
        f"{index.summary.fingerprint}:{bundle_id}:{'|'.join(source_paths)}".encode(
            "utf-8"
        )
    ).hexdigest()
    return KnowledgeBundle(
        id=bundle_id,
        title=bundle_sources["title"],
        summary=summary,
        prompt_text=prompt_text,
        source_paths=source_paths,
        source_doc_ids=source_doc_ids,
        related_symbol_ids=related_symbol_ids,
        fingerprint=fingerprint,
    )


def find_symbol_usages(project_root: str | Path, symbol_id: str) -> ReferenceSymbol:
    return _find_symbol_usages(project_root, symbol_id)


def _attach_page_references(
    pages: list[PageDefinition], references: ReferenceIndexResult
) -> list[PageDefinition]:
    by_key = {
        (symbol.definition.file_path, symbol.name): symbol.id
        for symbol in references.symbols
        if symbol.kind == "page"
    }
    attached: list[PageDefinition] = []
    for page in pages:
        attached.append(
            PageDefinition(
                id=page.id,
                name=page.name,
                qualified_name=page.qualified_name,
                path=page.path,
                base_class=page.base_class,
                url=page.url,
                snapshot_path=page.snapshot_path,
                screenshot_path=page.screenshot_path,
                elements=page.elements,
                reference_symbol_id=by_key.get((page.path, page.name)),
            )
        )
    return attached


def _attach_component_references(
    components: list[ComponentSymbol], references: ReferenceIndexResult
) -> list[ComponentSymbol]:
    by_key = {
        (symbol.definition.file_path, symbol.name): symbol.id
        for symbol in references.symbols
        if symbol.kind == "step"
    }
    attached: list[ComponentSymbol] = []
    for component in components:
        attached.append(
            ComponentSymbol(
                id=component.id,
                name=component.name,
                qualified_name=component.qualified_name,
                path=component.path,
                runtime_kind=component.runtime_kind,
                semantic_kind=component.semantic_kind,
                parameters=component.parameters,
                description=component.description,
                base_classes=component.base_classes,
                ancestor_ids=component.ancestor_ids,
                descendant_ids=component.descendant_ids,
                declared_in_core=component.declared_in_core,
                reference_symbol_id=by_key.get((component.path, component.name)),
            )
        )
    return attached


def _bundle_sources(
    *,
    bundle_id: str,
    index: ProjectIndex,
    root: Path,
) -> _BundleSources:
    doc_by_path = {doc.path: doc for doc in index.docs}

    def add_doc(
        path: str, chunks: list[str], source_paths: set[str], source_doc_ids: set[str]
    ) -> None:
        doc = doc_by_path.get(path)
        if doc is None:
            return
        source_paths.add(doc.path)
        source_doc_ids.add(doc.id)
        chunks.append(f"Источник: {doc.path}\n{doc.content_markdown or doc.title}")

    def add_file(path: Path, chunks: list[str], source_paths: set[str]) -> None:
        if not path.exists():
            return
        source_paths.add(str(path.relative_to(root)))
        chunks.append(
            f"Источник: {path.relative_to(root)}\n{path.read_text(encoding='utf-8').strip()}"
        )

    chunks: list[str] = []
    source_paths: set[str] = set()
    source_doc_ids: set[str] = set()
    related_symbol_ids: set[str] = set()

    if bundle_id == "overview":
        chunks.append(
            "\n".join(
                [
                    f"Корень проекта: {index.summary.project_root}",
                    f"Компонентов: {index.summary.components_total}",
                    f"Страниц: {index.summary.pages_total}",
                    f"Тестов: {index.summary.tests_total}",
                    f"Навыков: {index.summary.skills_total}",
                    f"Документов: {index.summary.docs_total}",
                ]
            )
        )
        add_file(root / "AGENTS.md", chunks, source_paths)
        add_doc("docs/index.md", chunks, source_paths, source_doc_ids)
        add_doc("docs/PROJECT_DOCUMENTATION.md", chunks, source_paths, source_doc_ids)
        related_symbol_ids.update(item.id for item in index.components[:20])
        return {
            "title": "Обзор проекта Persona",
            "summary": "Сводка по структуре проекта, правилам и основным артефактам.",
            "chunks": chunks,
            "source_paths": source_paths,
            "source_doc_ids": source_doc_ids,
            "related_symbol_ids": related_symbol_ids,
        }

    if bundle_id == "project_principles":
        add_file(root / "AGENTS.md", chunks, source_paths)
        add_doc(
            "docs/pages/LCL-P-4263b3ed__приципы-разработки.md",
            chunks,
            source_paths,
            source_doc_ids,
        )
        add_doc("docs/CODESTYLE.md", chunks, source_paths, source_doc_ids)
        return {
            "title": "Принципы проекта",
            "summary": "Правила разработки, инварианты обработки данных и ограничения на качество реализации.",
            "chunks": chunks,
            "source_paths": source_paths,
            "source_doc_ids": source_doc_ids,
            "related_symbol_ids": related_symbol_ids,
        }

    if bundle_id == "test_authoring":
        add_doc(
            "docs/pages/LCL-P6d467780__persona-dsl---основы.md",
            chunks,
            source_paths,
            source_doc_ids,
        )
        add_doc(
            "docs/pages/LCL-P4ef33711__persona-dsl---стили-сценариев.md",
            chunks,
            source_paths,
            source_doc_ids,
        )
        add_doc(
            "docs/pages/LCL-P1a2f8c4d__persona-dsl---allure-аннотации-и-метаданные.md",
            chunks,
            source_paths,
            source_doc_ids,
        )
        related_symbol_ids.update(test.id for test in index.tests[:20])
        return {
            "title": "Написание тестов",
            "summary": "Основы авторинга тестов, стилей сценариев и аннотаций.",
            "chunks": chunks,
            "source_paths": source_paths,
            "source_doc_ids": source_doc_ids,
            "related_symbol_ids": related_symbol_ids,
        }

    if bundle_id == "ops_catalog":
        ops = [item for item in index.components if item.runtime_kind == "Ops"]
        if ops:
            chunks.append(
                "Каталог Ops:\n"
                + "\n".join(
                    f"- {item.name}: {item.description or 'Описание отсутствует.'}"
                    for item in ops
                )
            )
            related_symbol_ids.update(item.id for item in ops)
        add_doc(
            "docs/pages/LCL-P275c03aa__persona-dsl---готовые-компоненты.md",
            chunks,
            source_paths,
            source_doc_ids,
        )
        return {
            "title": "Каталог Ops",
            "summary": "Built-in и проектные операции Persona DSL.",
            "chunks": chunks,
            "source_paths": source_paths,
            "source_doc_ids": source_doc_ids,
            "related_symbol_ids": related_symbol_ids,
        }

    if bundle_id == "components_and_composition":
        components = [item for item in index.components if item.runtime_kind != "Ops"]
        if components:
            chunks.append(
                "Компоненты сценариев:\n"
                + "\n".join(
                    f"- {item.name} [{item.runtime_kind}]" for item in components[:100]
                )
            )
            related_symbol_ids.update(item.id for item in components)
        add_doc(
            "docs/tasks/LCL-4ce06705__steps-и-combined-steps---трёхуровневая-архитектура.md",
            chunks,
            source_paths,
            source_doc_ids,
        )
        add_doc(
            "docs/tasks/LCL-f9849f04__чистое-ядро-dsl---базовые-классы-ops-step-combinedstep.md",
            chunks,
            source_paths,
            source_doc_ids,
        )
        return {
            "title": "Компоненты и композиция",
            "summary": "Классы Steps/CombinedStep/Goal/Action/Fact/Expectation и их взаимосвязи.",
            "chunks": chunks,
            "source_paths": source_paths,
            "source_doc_ids": source_doc_ids,
            "related_symbol_ids": related_symbol_ids,
        }

    if bundle_id == "pages_and_generation":
        if index.pages:
            chunks.append(
                "Страницы проекта:\n"
                + "\n".join(f"- {page.name}: {page.path}" for page in index.pages[:100])
            )
            related_symbol_ids.update(page.id for page in index.pages)
        add_doc(
            "docs/pages/LCL-Pac4dc66f__persona-dsl---генератор-страниц-pageobjects.md",
            chunks,
            source_paths,
            source_doc_ids,
        )
        add_doc(
            "docs/tasks/LCL-d114acc8__ui-специфичные-метаданные-для-element-и-page.md",
            chunks,
            source_paths,
            source_doc_ids,
        )
        return {
            "title": "Страницы и генерация",
            "summary": "Page Object слой, его контракт и связанные генераторы.",
            "chunks": chunks,
            "source_paths": source_paths,
            "source_doc_ids": source_doc_ids,
            "related_symbol_ids": related_symbol_ids,
        }

    if bundle_id == "skills_and_config":
        if index.skills:
            chunks.append(
                "Навыки:\n"
                + "\n".join(
                    f"- {skill.class_name} ({skill.skill_id})"
                    for skill in index.skills[:100]
                )
            )
            related_symbol_ids.update(skill.id for skill in index.skills)
        if index.configs:
            chunks.append(
                "Окружения конфигурации:\n"
                + "\n".join(
                    f"- {cfg.env}: роли={', '.join(cfg.persona_roles) or '-'}, навыки={', '.join(cfg.skill_bindings) or '-'}"
                    for cfg in index.configs
                )
            )
        add_doc(
            "docs/pages/LCL-P2937e168__persona-dsl---навыки-skills.md",
            chunks,
            source_paths,
            source_doc_ids,
        )
        add_doc(
            "docs/pages/LCL-P989d5fe2__persona-dsl---конфигурация.md",
            chunks,
            source_paths,
            source_doc_ids,
        )
        return {
            "title": "Навыки и конфигурация",
            "summary": "Skill layer, доступные навыки и обзор конфигурационных окружений.",
            "chunks": chunks,
            "source_paths": source_paths,
            "source_doc_ids": source_doc_ids,
            "related_symbol_ids": related_symbol_ids,
        }

    if bundle_id == "project_specific_context":
        for doc in index.docs[:25]:
            if doc.doc_kind not in {"task", "project", "objective", "key_result"}:
                continue
            source_paths.add(doc.path)
            source_doc_ids.add(doc.id)
            chunks.append(f"Источник: {doc.path}\n{doc.content_markdown or doc.title}")
        return {
            "title": "Контекст проекта",
            "summary": "Проектовые задачи, решения и локальная документация репозитория.",
            "chunks": chunks,
            "source_paths": source_paths,
            "source_doc_ids": source_doc_ids,
            "related_symbol_ids": related_symbol_ids,
        }

    raise ValueError(f"Unsupported bundle id: {bundle_id}")


def _test_discovery_error_diagnostics(project_root: Path) -> list[DiscoveryDiagnostic]:
    error = get_last_test_discovery_error()
    if not error:
        return []
    message_parts = [error.get("error", "pytest discovery failed")]
    stdout = error.get("stdout")
    stderr = error.get("stderr")
    if stdout:
        message_parts.append(f"stdout:\n{stdout.strip()}")
    if stderr:
        message_parts.append(f"stderr:\n{stderr.strip()}")
    return [
        DiscoveryDiagnostic(
            kind="introspection",
            path=str(project_root / "tests"),
            message="\n\n".join(part for part in message_parts if part),
        )
    ]


def _project_fingerprint(root: Path) -> str:
    hasher = hashlib.sha256()
    for file_path in sorted(_relevant_files(root)):
        relative_path = (
            str(file_path.relative_to(root))
            if file_path.is_relative_to(root)
            else str(file_path)
        )
        hasher.update(relative_path.encode("utf-8"))
        stat = file_path.stat()
        hasher.update(str(stat.st_mtime_ns).encode("utf-8"))
        hasher.update(str(stat.st_size).encode("utf-8"))
    return hasher.hexdigest()


def _relevant_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for pattern in (
        "tests/**/*.py",
        "docs/**/*.md",
        "config/**/*.yaml",
        "AGENTS.md",
    ):
        files.extend(path for path in root.glob(pattern) if path.is_file())

    persona_root = Path(__file__).resolve().parents[2]
    for pattern in (
        "ops/**/*.py",
        "expectations/**/*.py",
        "skills/**/*.py",
        "discovery/**/*.py",
    ):
        files.extend(path for path in persona_root.glob(pattern) if path.is_file())
    unique: dict[str, Path] = {}
    for file_path in files:
        unique[str(file_path)] = file_path
    return list(unique.values())
