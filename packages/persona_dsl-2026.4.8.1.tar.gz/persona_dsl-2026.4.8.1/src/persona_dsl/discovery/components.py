from __future__ import annotations

import ast
import importlib
import importlib.util
import inspect
import logging
import sys
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import ParamSpec, get_type_hints

from pydantic import BaseModel

from persona_dsl.discovery.models import (
    ComponentSymbol,
    DiagnosticKind,
    DiscoveryDiagnostic,
    RuntimeKind,
    SemanticKind,
)
from persona_dsl.json_types import JsonObject, JsonValue, is_json_object, is_json_value
from persona_dsl.scenario.models import ComponentParameter
from persona_dsl.utils.modeling import normalize_optional_text

logger = logging.getLogger(__name__)

P = ParamSpec("P")

_DISCOVERY_ERRORS: list[DiscoveryDiagnostic] = []
_RUNTIME_BASES = {
    "Goal",
    "Action",
    "Fact",
    "Expectation",
    "Ops",
    "Step",
    "CombinedStep",
}


def _persona_dsl_dir() -> Path:
    return Path(__file__).resolve().parent.parent


def _component_dirs(project_root: Path) -> list[Path]:
    persona_dir = _persona_dsl_dir()
    return [
        project_root / "tests" / "goals",
        project_root / "tests" / "actions",
        project_root / "tests" / "facts",
        project_root / "tests" / "expectations",
        persona_dir / "ops",
        persona_dir / "expectations",
        project_root / "tests" / "steps",
        project_root / "tests" / "combined_steps",
    ]


def _record_discovery_error(
    path: Path,
    message: str,
    *,
    kind: DiagnosticKind = "metadata",
    line: int | None = None,
    column: int | None = None,
    context: str | None = None,
    symbol_id: str | None = None,
) -> None:
    diagnostic = DiscoveryDiagnostic(
        kind=kind,
        path=str(path),
        message=message,
        line=line,
        column=column,
        context=context,
        symbol_id=symbol_id,
    )
    _DISCOVERY_ERRORS.append(diagnostic)
    logger.warning("Discovery error in %s: %s", path, message)


def _class_base_name(base: ast.expr) -> str | None:
    if isinstance(base, ast.Name):
        return base.id
    if isinstance(base, ast.Attribute):
        return base.attr
    return None


def _extract_base_names(class_node: ast.ClassDef) -> set[str]:
    names: set[str] = set()
    for base in class_node.bases:
        base_name = _class_base_name(base)
        if base_name is not None:
            names.add(base_name)
    return names


def _resolve_runtime_kind(
    base_names: list[str] | set[str],
    resolved_local: dict[str, RuntimeKind],
) -> RuntimeKind | None:
    if "Fact" in base_names:
        return "Fact"
    if "Expectation" in base_names:
        return "Expectation"
    if "Goal" in base_names:
        return "Goal"
    if "Action" in base_names:
        return "Action"
    if "Ops" in base_names:
        return "Ops"
    if "CombinedStep" in base_names:
        return "CombinedStep"
    if "Step" in base_names:
        return "Step"

    inherited_kinds = [
        resolved_local[base] for base in base_names if base in resolved_local
    ]
    if "Fact" in inherited_kinds:
        return "Fact"
    if "Expectation" in inherited_kinds:
        return "Expectation"
    if "Goal" in inherited_kinds:
        return "Goal"
    if "Action" in inherited_kinds:
        return "Action"
    if "Ops" in inherited_kinds:
        return "Ops"
    if "CombinedStep" in inherited_kinds:
        return "CombinedStep"
    if "Step" in inherited_kinds:
        return "Step"
    return None


def _resolve_component_type(
    base_names: list[str] | set[str],
    resolved_local: dict[str, RuntimeKind],
) -> RuntimeKind | None:
    return _resolve_runtime_kind(list(base_names), resolved_local)


def _semantic_kind_for_runtime(runtime_kind: RuntimeKind) -> SemanticKind:
    if runtime_kind in {"Goal", "CombinedStep"}:
        return "Goal"
    if runtime_kind == "Fact":
        return "Fact"
    if runtime_kind == "Expectation":
        return "Expectation"
    return "Action"


def _module_path_for_component(py_file: Path, project_root: Path) -> tuple[str, str]:
    persona_dir = _persona_dsl_dir()
    if py_file.is_relative_to(persona_dir):
        relative_path = str(py_file.relative_to(persona_dir))
        raw_module_path = relative_path.removesuffix(".py").replace("/", ".")
        return relative_path, f"persona_dsl.{raw_module_path}"
    relative_path = str(py_file.relative_to(project_root))
    raw_module_path = relative_path.removesuffix(".py").replace("/", ".")
    return relative_path, raw_module_path


def _load_module_for_introspection(py_file: Path, module_path: str) -> ModuleType:
    if module_path.startswith("persona_dsl."):
        return importlib.import_module(module_path)
    module_name = f"persona_dsl_discovery_dynamic__{module_path}".replace(
        ".", "_"
    ).replace("-", "_")
    spec = importlib.util.spec_from_file_location(module_name, py_file)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot create module spec for {py_file}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def _annotation_name(annotation: object) -> str:
    if annotation is inspect.Signature.empty:
        return "object"
    if isinstance(annotation, str):
        return annotation
    if isinstance(annotation, type):
        return annotation.__name__
    annotation_name = getattr(annotation, "__name__", None)
    if isinstance(annotation_name, str):
        return annotation_name
    return str(annotation)


def _default_from_runtime(value: object) -> JsonValue:
    if is_json_value(value):
        return value
    raise TypeError(
        f"Значение по умолчанию {value!r} не является JSON-совместимым для discovery."
    )


def _params_from_signature(
    callable_obj: Callable[P, object],
) -> list[ComponentParameter]:
    signature = inspect.signature(callable_obj)
    params: list[ComponentParameter] = []
    for parameter in signature.parameters.values():
        if parameter.name == "self" or parameter.kind in (
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        ):
            continue

        default_value: JsonValue = None
        required = parameter.default is inspect.Signature.empty
        if not required:
            default_value = _default_from_runtime(parameter.default)

        params.append(
            ComponentParameter(
                name=parameter.name,
                type=_annotation_name(parameter.annotation),
                required=required,
                default=default_value,
            )
        )
    return params


def _unparse_node(node: ast.expr) -> str | None:
    try:
        return ast.unparse(node)
    except ValueError:
        return None


def _annotation_name_from_ast(annotation: ast.expr | None) -> str:
    if annotation is None:
        return "object"
    annotation_name = _unparse_node(annotation)
    if annotation_name is None:
        return "object"
    return annotation_name


def _default_from_ast(default_node: ast.expr) -> JsonValue:
    try:
        default_value = ast.literal_eval(default_node)
    except (SyntaxError, ValueError):
        default_expression = _unparse_node(default_node)
        if default_expression is None:
            return None
        return default_expression

    if is_json_value(default_value):
        return default_value

    default_expression = _unparse_node(default_node)
    if default_expression is None:
        raise TypeError("Значение по умолчанию не удалось сериализовать для discovery.")
    return default_expression


def _params_from_init_ast(init_method: ast.FunctionDef) -> list[ComponentParameter]:
    params: list[ComponentParameter] = []
    args = init_method.args.args[1:]
    defaults = init_method.args.defaults
    defaults_start_idx = len(args) - len(defaults)
    for index, arg in enumerate(args):
        required = index < defaults_start_idx
        default_value: JsonValue = None
        if not required and defaults:
            default_node = defaults[index - defaults_start_idx]
            default_value = _default_from_ast(default_node)

        params.append(
            ComponentParameter(
                name=arg.arg,
                type=_annotation_name_from_ast(arg.annotation),
                required=required,
                default=default_value,
            )
        )
    return params


def _qualified_model_name(model_type: type[BaseModel]) -> str:
    return f"{model_type.__module__}.{model_type.__name__}"


def _json_schema_for_annotation(annotation: object) -> JsonObject | None:
    if not isinstance(annotation, type):
        return None
    if not issubclass(annotation, BaseModel):
        return None
    schema = annotation.model_json_schema()
    if not is_json_object(schema):
        raise TypeError(
            f"JSON schema для {annotation.__module__}.{annotation.__name__} должна быть объектом."
        )
    return schema


def _enrich_params_with_json_schema(
    *,
    params: list[ComponentParameter],
    type_hints: dict[str, object],
) -> None:
    for index, param in enumerate(params):
        annotation = type_hints.get(param.name)
        if annotation is None:
            continue
        schema = _json_schema_for_annotation(annotation)
        if schema is None:
            continue
        assert isinstance(annotation, type)
        params[index] = ComponentParameter(
            name=param.name,
            type=_qualified_model_name(annotation),
            required=param.required,
            default=param.default,
            json_schema=schema,
        )


@dataclass(slots=True)
class _CollectedComponent:
    symbol: ComponentSymbol
    direct_bases: list[str]


def _collect_component_files(project_root: Path) -> list[Path]:
    collected: list[Path] = []
    for components_dir in _component_dirs(project_root):
        if not components_dir.is_dir():
            continue
        for py_file in sorted(components_dir.rglob("*.py")):
            if py_file.name == "__init__.py":
                continue
            collected.append(py_file)
    return collected


def _read_tree(py_file: Path) -> ast.Module | None:
    try:
        content = py_file.read_text(encoding="utf-8")
    except OSError as error:
        _record_discovery_error(py_file, str(error), kind="io")
        return None
    try:
        return ast.parse(content, filename=str(py_file))
    except SyntaxError as error:
        _record_discovery_error(
            py_file,
            error.msg,
            kind="syntax",
            line=error.lineno,
            column=error.offset,
        )
        return None


def _resolve_file_symbols(
    *,
    tree: ast.Module,
    py_file: Path,
    project_root: Path,
) -> list[_CollectedComponent]:
    class_nodes = [node for node in tree.body if isinstance(node, ast.ClassDef)]
    resolved_local: dict[str, RuntimeKind] = {}
    pending = class_nodes[:]
    while pending:
        next_pending: list[ast.ClassDef] = []
        progress = False
        for class_node in pending:
            base_names = _extract_base_names(class_node)
            if not (
                set(base_names).intersection(_RUNTIME_BASES)
                or set(base_names).intersection(resolved_local.keys())
            ):
                next_pending.append(class_node)
                continue
            runtime_kind = _resolve_runtime_kind(base_names, resolved_local)
            if runtime_kind is None:
                next_pending.append(class_node)
                continue
            resolved_local[class_node.name] = runtime_kind
            progress = True
        if not progress:
            break
        pending = next_pending

    relative_path, module_path = _module_path_for_component(py_file, project_root)
    module: ModuleType | None = None
    try:
        module = _load_module_for_introspection(py_file, module_path)
    except (
        AttributeError,
        ImportError,
        NameError,
        OSError,
        RuntimeError,
        SyntaxError,
        TypeError,
        ValueError,
    ) as error:
        _record_discovery_error(
            py_file, f"introspection: {error}", kind="introspection"
        )

    collected: list[_CollectedComponent] = []
    for node in class_nodes:
        runtime_kind = resolved_local.get(node.name)
        if runtime_kind is None:
            continue

        params: list[ComponentParameter] = []
        for body_item in node.body:
            if isinstance(body_item, ast.FunctionDef) and body_item.name == "__init__":
                params = _params_from_init_ast(body_item)
                break

        if module is not None:
            cls_obj = getattr(module, node.name, None)
            init_callable = getattr(cls_obj, "__init__", None)
            if isinstance(cls_obj, type) and callable(init_callable):
                if not params:
                    try:
                        params = _params_from_signature(init_callable)
                    except (TypeError, ValueError) as error:
                        _record_discovery_error(
                            py_file, f"introspection: {error}", kind="introspection"
                        )
                try:
                    type_hints = get_type_hints(init_callable, globalns=module.__dict__)
                except (AttributeError, NameError, TypeError) as error:
                    _record_discovery_error(
                        py_file, f"introspection: {error}", kind="introspection"
                    )
                else:
                    try:
                        _enrich_params_with_json_schema(
                            params=params, type_hints=type_hints
                        )
                    except (AttributeError, TypeError, ValueError) as error:
                        _record_discovery_error(
                            py_file, f"introspection: {error}", kind="introspection"
                        )

        direct_bases = sorted(_extract_base_names(node))
        symbol = ComponentSymbol(
            id=f"component::{relative_path}::{node.name}",
            name=node.name,
            qualified_name=f"{module_path}.{node.name}",
            path=relative_path,
            runtime_kind=runtime_kind,
            semantic_kind=_semantic_kind_for_runtime(runtime_kind),
            parameters=params,
            description=normalize_optional_text(
                ast.get_docstring(node), f"{node.name}.description"
            ),
            base_classes=direct_bases,
            declared_in_core=relative_path.startswith("ops/")
            or relative_path.startswith("expectations/"),
        )
        collected.append(_CollectedComponent(symbol=symbol, direct_bases=direct_bases))
    return collected


def _resolve_relationships(
    collected: list[_CollectedComponent],
) -> list[ComponentSymbol]:
    by_name: dict[str, list[_CollectedComponent]] = {}
    for item in collected:
        by_name.setdefault(item.symbol.name, []).append(item)

    ancestor_cache: dict[str, list[str]] = {}

    def ancestor_ids_for(symbol_id: str, seen: set[str]) -> list[str]:
        if symbol_id in ancestor_cache:
            return list(ancestor_cache[symbol_id])
        if symbol_id in seen:
            return []
        seen.add(symbol_id)
        current = next(item for item in collected if item.symbol.id == symbol_id)
        ancestors: list[str] = []
        for base_name in current.direct_bases:
            for parent in by_name.get(base_name, []):
                if parent.symbol.id not in ancestors:
                    ancestors.append(parent.symbol.id)
                for nested in ancestor_ids_for(parent.symbol.id, seen):
                    if nested not in ancestors:
                        ancestors.append(nested)
        ancestor_cache[symbol_id] = list(ancestors)
        return ancestors

    descendants: dict[str, list[str]] = {item.symbol.id: [] for item in collected}
    for item in collected:
        current_ancestors = ancestor_ids_for(item.symbol.id, set())
        for ancestor_id in current_ancestors:
            descendants.setdefault(ancestor_id, [])
            if item.symbol.id not in descendants[ancestor_id]:
                descendants[ancestor_id].append(item.symbol.id)

    enriched: list[ComponentSymbol] = []
    for item in collected:
        ancestor_ids = ancestor_ids_for(item.symbol.id, set())
        enriched.append(
            ComponentSymbol(
                id=item.symbol.id,
                name=item.symbol.name,
                qualified_name=item.symbol.qualified_name,
                path=item.symbol.path,
                runtime_kind=item.symbol.runtime_kind,
                semantic_kind=item.symbol.semantic_kind,
                parameters=item.symbol.parameters,
                description=item.symbol.description,
                base_classes=item.symbol.base_classes,
                ancestor_ids=ancestor_ids,
                descendant_ids=descendants.get(item.symbol.id, []),
                declared_in_core=item.symbol.declared_in_core,
                reference_symbol_id=item.symbol.reference_symbol_id,
            )
        )
    return enriched


def discover_components(project_root: str | Path) -> list[ComponentSymbol]:
    root = Path(project_root).resolve()
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    _DISCOVERY_ERRORS.clear()

    collected: list[_CollectedComponent] = []
    for py_file in _collect_component_files(root):
        tree = _read_tree(py_file)
        if tree is None:
            continue
        collected.extend(
            _resolve_file_symbols(tree=tree, py_file=py_file, project_root=root)
        )
    return _resolve_relationships(collected)


def get_discovery_errors() -> list[DiscoveryDiagnostic]:
    return list(_DISCOVERY_ERRORS)


DiscoveredComponent = ComponentSymbol
DiscoveryError = DiscoveryDiagnostic
