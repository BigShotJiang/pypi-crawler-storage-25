from __future__ import annotations

import json
from collections.abc import Iterator
from pathlib import Path
from typing import Protocol

import pytest

from persona_dsl.discovery.annotations import (
    ANNOTATION_DEFAULT_LINK_TYPE,
    ANNOTATION_MANUAL_LABEL,
    ANNOTATION_TAG_LABEL,
    build_annotation_metadata,
    normalize_optional_text,
)
from persona_dsl.discovery.models import (
    AnnotationLabel,
    AnnotationLink,
    AnnotationMetadata,
)

ANNOTATION_DESCRIPTION_MARK = "allure_description"
ANNOTATION_DESCRIPTION_HTML_MARK = "allure_description_html"
ANNOTATION_LABEL_MARK = "allure_label"
ANNOTATION_LINK_MARK = "allure_link"
MARK_NAMES_TO_IGNORE = {
    "usefixtures",
    "filterwarnings",
    "skip",
    "skipif",
    "xfail",
    "parametrize",
}

IGNORED_TAG_MARKERS = MARK_NAMES_TO_IGNORE | {
    ANNOTATION_DESCRIPTION_MARK,
    ANNOTATION_DESCRIPTION_HTML_MARK,
    ANNOTATION_LABEL_MARK,
    ANNOTATION_LINK_MARK,
    "data_driven",
    "title",
}


class _MarkerNode(Protocol):
    def iter_markers(self, name: str | None = None) -> Iterator[pytest.Mark]: ...


def _annotation_title(node: object) -> str | None:
    raw_title = getattr(getattr(node, "obj", None), "__allure_display_name__", None)
    return normalize_optional_text(raw_title, "title")


def _read_docstring(obj: object | None) -> str | None:
    docstring = getattr(obj, "__doc__", None)
    if not isinstance(docstring, str):
        return None
    normalized = docstring.strip()
    return normalized or None


def _read_explicit_description(node: _MarkerNode) -> str | None:
    for marker in node.iter_markers(name=ANNOTATION_DESCRIPTION_MARK):
        if not marker.args:
            continue
        return normalize_optional_text(marker.args[0], ANNOTATION_DESCRIPTION_MARK)
    return None


def _read_explicit_description_html(node: _MarkerNode) -> str | None:
    for marker in node.iter_markers(name=ANNOTATION_DESCRIPTION_HTML_MARK):
        if not marker.args:
            continue
        return normalize_optional_text(marker.args[0], ANNOTATION_DESCRIPTION_HTML_MARK)
    return None


def _read_annotation_labels(node: _MarkerNode) -> tuple[list[AnnotationLabel], bool]:
    labels: list[AnnotationLabel] = []
    manual = False
    seen: set[tuple[str, str]] = set()

    for marker in node.iter_markers(name=ANNOTATION_LABEL_MARK):
        raw_label_type = marker.kwargs.get("label_type")
        label_type = normalize_optional_text(raw_label_type, "allure_label.label_type")
        if label_type is None:
            raise ValueError("allure_label.label_type не должен быть пустым.")
        for raw_value in marker.args:
            if label_type == ANNOTATION_MANUAL_LABEL:
                manual = manual or bool(raw_value)
                continue
            value = normalize_optional_text(raw_value, f"allure_label[{label_type}]")
            if value is None:
                raise ValueError(
                    f"allure_label[{label_type}] не должен содержать пустое значение."
                )
            key = (label_type, value)
            if key in seen:
                continue
            seen.add(key)
            labels.append(AnnotationLabel(name=label_type, value=value))

    return labels, manual


def _read_annotation_links(node: _MarkerNode) -> list[AnnotationLink]:
    seen: set[tuple[str, str, str | None]] = set()
    links: list[AnnotationLink] = []

    for marker in node.iter_markers(name=ANNOTATION_LINK_MARK):
        if not marker.args:
            raise ValueError("allure_link должен содержать URL в первом аргументе.")
        url = normalize_optional_text(marker.args[0], "allure_link.url")
        if url is None:
            raise ValueError("allure_link.url не должен быть пустым.")
        link_type = normalize_optional_text(
            marker.kwargs.get("link_type"), "allure_link.link_type"
        )
        name = normalize_optional_text(marker.kwargs.get("name"), "allure_link.name")
        entry = AnnotationLink(
            url=url,
            type=link_type if link_type is not None else ANNOTATION_DEFAULT_LINK_TYPE,
            name=name,
        )
        key = (entry.type, entry.url, entry.name)
        if key in seen:
            continue
        seen.add(key)
        links.append(entry)

    return links


def _read_plain_pytest_tags(node: _MarkerNode) -> list[str]:
    tags: list[str] = []
    seen: set[str] = set()

    for marker in node.iter_markers():
        if marker.name in IGNORED_TAG_MARKERS:
            continue
        if marker.args or marker.kwargs:
            continue
        tag_name = marker.name.strip().lower()
        if not tag_name or tag_name in seen:
            continue
        seen.add(tag_name)
        tags.append(tag_name)

    return tags


def _build_annotation_metadata(node: _MarkerNode) -> AnnotationMetadata:
    labels, manual = _read_annotation_labels(node)
    labels.extend(
        AnnotationLabel(name=ANNOTATION_TAG_LABEL, value=tag_name)
        for tag_name in _read_plain_pytest_tags(node)
    )
    return build_annotation_metadata(
        title=_annotation_title(node),
        description=_read_explicit_description(node),
        description_html=_read_explicit_description_html(node),
        manual=manual,
        labels=labels,
        links=_read_annotation_links(node),
    )


def _serialize_definition(
    *,
    node_id: str,
    path: Path,
    project_root: Path,
    name: str,
    node_type: str,
    docstring: str | None,
    annotations: AnnotationMetadata,
) -> dict[str, object]:
    return {
        "node_id": node_id,
        "path": str(path.relative_to(project_root)),
        "name": name,
        "kind": node_type,
        "docstring": docstring,
        "annotations": annotations.model_dump(mode="python"),
    }


def pytest_addoption(parser: pytest.Parser) -> None:
    parser.addoption(
        "--discovery-report-file",
        action="store",
        help="Path to save test discovery JSON report",
    )


def pytest_collection_finish(session: pytest.Session) -> None:
    report_file_path = session.config.getoption("--discovery-report-file")
    if not report_file_path:
        return

    definitions: list[dict[str, object]] = []
    seen_node_ids: set[str] = set()
    project_root = session.config.rootpath

    for item in session.items:
        method_node_id = item.nodeid
        if method_node_id in seen_node_ids:
            continue

        if isinstance(item.parent, pytest.Class):
            class_node = item.parent
            class_node_id = class_node.nodeid
            if class_node_id not in seen_node_ids:
                definitions.append(
                    _serialize_definition(
                        node_id=class_node_id,
                        path=Path(class_node.path),
                        project_root=project_root,
                        name=class_node.name,
                        node_type="class",
                        docstring=_read_docstring(getattr(class_node, "obj", None)),
                        annotations=_build_annotation_metadata(class_node),
                    )
                )
                seen_node_ids.add(class_node_id)

        definitions.append(
            _serialize_definition(
                node_id=method_node_id,
                path=Path(item.path),
                project_root=project_root,
                name=item.name,
                node_type="method",
                docstring=_read_docstring(getattr(item, "obj", None)),
                annotations=_build_annotation_metadata(item),
            )
        )
        seen_node_ids.add(method_node_id)

    with open(report_file_path, "w", encoding="utf-8") as file_handle:
        json.dump(definitions, file_handle)
