from __future__ import annotations

import ast
from collections.abc import Iterable
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Literal, Mapping, TypeGuard

from persona_dsl.scenario.data_driven_index import build_variant_set_reference_index

from .models import (
    GraphReferenceContext,
    PageRegenerationImpactPreview,
    ReferenceIndexResult,
    ReferenceImpactEntry,
    ReferenceOccurrence,
    ReferenceSymbol,
    RenameConflict,
    RenameEdit,
    RenameFileMove,
    RenameImpact,
    SafeRenamePlan,
)

_PAGE_BASES = {"Page"}
_STEP_BASES = {"Step", "Action", "Goal", "CombinedStep"}
_EXCLUDED_DIR_NAMES = {
    ".git",
    ".hg",
    ".idea",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "htmlcov",
    "node_modules",
    "reports",
}


@dataclass
class _OccurrenceData:
    file_path: str
    line: int
    column: int
    end_line: int
    end_column: int
    start_offset: int
    end_offset: int
    usage_kind: str
    context: str
    source_kind: Literal["python_file", "scenario_graph"] = "python_file"
    source_id: str | None = None
    source_label: str | None = None

    def to_model(self) -> ReferenceOccurrence:
        return ReferenceOccurrence(
            file_path=self.file_path,
            line=self.line,
            column=self.column,
            end_line=self.end_line,
            end_column=self.end_column,
            start_offset=self.start_offset,
            end_offset=self.end_offset,
            usage_kind=self.usage_kind,
            context=self.context,
            source_kind=self.source_kind,
            source_id=self.source_id or self.file_path,
            source_label=self.source_label or self.file_path,
        )


@dataclass
class _SymbolData:
    id: str
    kind: Literal["page", "page_element", "step", "test", "variant_set"]
    name: str
    qualified_name: str
    parent_id: str | None
    node_id: str | None
    definition: _OccurrenceData
    usages: list[_OccurrenceData] = field(default_factory=list)

    def to_model(self) -> ReferenceSymbol:
        return ReferenceSymbol(
            id=self.id,
            kind=self.kind,
            name=self.name,
            qualified_name=self.qualified_name,
            parent_id=self.parent_id,
            node_id=self.node_id,
            definition=self.definition.to_model(),
            usages=[item.to_model() for item in self.usages],
        )


@dataclass
class _ParsedFile:
    root: Path
    file_path: Path
    rel_path: str
    module_name: str
    source: str
    tree: ast.Module
    line_offsets: list[int]

    @property
    def lines(self) -> list[str]:
        return self.source.splitlines()


class _ReferenceBuildError(ValueError):
    pass


def _is_ast_int(value: object) -> TypeGuard[int]:
    return isinstance(value, int) and not isinstance(value, bool)


def _iter_graph_parameters(raw_value: object) -> Iterable[Mapping[str, object]]:
    if not isinstance(raw_value, list):
        return ()
    params: list[Mapping[str, object]] = []
    for item in raw_value:
        if isinstance(item, Mapping) and all(isinstance(key, str) for key in item):
            params.append(item)
    return params


class _UsageCollector(ast.NodeVisitor):
    def __init__(
        self,
        *,
        parsed: _ParsedFile,
        module_symbols: Mapping[str, Dict[str, str]],
        local_symbols: Mapping[str, str],
        page_elements_by_page: Mapping[str, Dict[str, str]],
        symbol_index: Dict[str, _SymbolData],
    ) -> None:
        self.parsed = parsed
        self.module_symbols = module_symbols
        self.local_symbols = dict(local_symbols)
        self.page_elements_by_page = page_elements_by_page
        self.symbol_index = symbol_index
        self.imported_symbols: dict[str, str] = {}
        self.imported_modules: dict[str, str] = {}
        self.page_bindings_stack: list[dict[str, str]] = [{}]
        self.current_page_symbol_id: str | None = None
        self.current_class_name: str | None = None

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        module_name = self._absolute_module_name(node.module, node.level)
        if not module_name:
            return
        symbols = self.module_symbols.get(module_name, {})
        for alias in node.names:
            if alias.name == "*":
                raise _ReferenceBuildError(
                    f"Wildcard import is not supported for reference index: {self.parsed.rel_path}:{getattr(node, 'lineno', '?')}"
                )
            symbol_id = symbols.get(alias.name)
            local_name = alias.asname or alias.name
            if symbol_id is not None:
                self.imported_symbols[local_name] = symbol_id
                occurrence = _alias_occurrence(
                    self.parsed,
                    alias,
                    usage_kind="import",
                    fallback_name=alias.asname or alias.name,
                )
                if occurrence is None:
                    raise _ReferenceBuildError(
                        f"Cannot resolve import occurrence for {alias.name} in {self.parsed.rel_path}"
                    )
                self._add_usage(symbol_id, occurrence)
            else:
                self.imported_modules[local_name] = f"{module_name}.{alias.name}"
        self.generic_visit(node)

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            local_name = alias.asname or alias.name.split(".")[-1]
            self.imported_modules[local_name] = alias.name
        self.generic_visit(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        previous_class = self.current_class_name
        previous_page = self.current_page_symbol_id
        self.current_class_name = node.name
        self.current_page_symbol_id = self.local_symbols.get(node.name)
        self.generic_visit(node)
        self.current_page_symbol_id = previous_page
        self.current_class_name = previous_class

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self.page_bindings_stack.append({})
        self.generic_visit(node)
        self.page_bindings_stack.pop()

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self.page_bindings_stack.append({})
        self.generic_visit(node)
        self.page_bindings_stack.pop()

    def visit_Assign(self, node: ast.Assign) -> None:
        symbol_id = self._resolve_page_symbol_from_value(node.value)
        if (
            symbol_id
            and self.symbol_index.get(symbol_id, None)
            and self.symbol_index[symbol_id].kind == "page"
        ):
            for target in node.targets:
                self._bind_target_to_page(target, symbol_id)
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if node.value is not None:
            symbol_id = self._resolve_page_symbol_from_value(node.value)
            if (
                symbol_id
                and self.symbol_index.get(symbol_id, None)
                and self.symbol_index[symbol_id].kind == "page"
            ):
                self._bind_target_to_page(node.target, symbol_id)
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        symbol_id = self._resolve_symbol_id(node.func)
        if symbol_id is not None:
            occurrence = _name_like_occurrence(
                self.parsed, node.func, usage_kind="call"
            )
            if occurrence is None:
                raise _ReferenceBuildError(
                    f"Cannot resolve call occurrence in {self.parsed.rel_path}:{getattr(node, 'lineno', '?')}"
                )
            self._add_usage(symbol_id, occurrence)
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        if isinstance(node.ctx, ast.Load):
            page_symbol_id, direct_instance = self._resolve_page_binding(node.value)
            if page_symbol_id is not None:
                element_symbols = self.page_elements_by_page.get(page_symbol_id, {})
                element_symbol_id = element_symbols.get(node.attr)
                if element_symbol_id is not None:
                    occurrence = _attribute_occurrence(
                        self.parsed,
                        node,
                        usage_kind=(
                            "page_element_direct"
                            if direct_instance
                            else "page_element_bound"
                        ),
                    )
                    if occurrence is None:
                        raise _ReferenceBuildError(
                            f"Cannot resolve attribute occurrence in {self.parsed.rel_path}:{getattr(node, 'lineno', '?')}"
                        )
                    self._add_usage(element_symbol_id, occurrence)

            if (
                isinstance(node.value, ast.Name)
                and node.value.id == "self"
                and self.current_page_symbol_id is not None
            ):
                element_symbols = self.page_elements_by_page.get(
                    self.current_page_symbol_id, {}
                )
                element_symbol_id = element_symbols.get(node.attr)
                if element_symbol_id is not None:
                    occurrence = _attribute_occurrence(
                        self.parsed,
                        node,
                        usage_kind="page_element_self",
                    )
                    if occurrence is None:
                        raise _ReferenceBuildError(
                            f"Cannot resolve self attribute occurrence in {self.parsed.rel_path}:{getattr(node, 'lineno', '?')}"
                        )
                    self._add_usage(element_symbol_id, occurrence)
        self.generic_visit(node)

    def _add_usage(self, symbol_id: str, occurrence: _OccurrenceData) -> None:
        symbol = self.symbol_index.get(symbol_id)
        if symbol is None:
            raise _ReferenceBuildError(f"Unknown symbol id {symbol_id}")
        key = (
            occurrence.file_path,
            occurrence.start_offset,
            occurrence.end_offset,
            occurrence.usage_kind,
        )
        existing = {
            (
                item.file_path,
                item.start_offset,
                item.end_offset,
                item.usage_kind,
            )
            for item in symbol.usages
        }
        if key not in existing:
            symbol.usages.append(occurrence)

    def _resolve_symbol_id(self, expr: ast.AST) -> str | None:
        if isinstance(expr, ast.Name):
            return self.imported_symbols.get(expr.id) or self.local_symbols.get(expr.id)
        if isinstance(expr, ast.Attribute) and isinstance(expr.value, ast.Name):
            module_name = self.imported_modules.get(expr.value.id)
            if module_name:
                return self.module_symbols.get(module_name, {}).get(expr.attr)
        return None

    def _resolve_page_symbol_from_value(self, expr: ast.AST) -> str | None:
        if isinstance(expr, ast.Call):
            return self._resolve_symbol_id(expr.func)
        return self._resolve_symbol_id(expr)

    def _resolve_page_binding(self, expr: ast.AST) -> tuple[str | None, bool]:
        if isinstance(expr, ast.Call):
            symbol_id = self._resolve_symbol_id(expr.func)
            if symbol_id and self.symbol_index[symbol_id].kind == "page":
                return symbol_id, True
            return None, False
        if isinstance(expr, ast.Name):
            for scope in reversed(self.page_bindings_stack):
                symbol_id = scope.get(expr.id)
                if symbol_id is not None:
                    return symbol_id, False
            return None, False
        if (
            isinstance(expr, ast.Attribute)
            and isinstance(expr.value, ast.Name)
            and expr.value.id == "self"
        ):
            key = f"self.{expr.attr}"
            for scope in reversed(self.page_bindings_stack):
                symbol_id = scope.get(key)
                if symbol_id is not None:
                    return symbol_id, False
        return None, False

    def _bind_target_to_page(self, target: ast.AST, symbol_id: str) -> None:
        scope = self.page_bindings_stack[-1]
        if isinstance(target, ast.Name):
            scope[target.id] = symbol_id
        elif (
            isinstance(target, ast.Attribute)
            and isinstance(target.value, ast.Name)
            and target.value.id == "self"
        ):
            scope[f"self.{target.attr}"] = symbol_id

    def _absolute_module_name(self, module: str | None, level: int) -> str | None:
        if level == 0:
            return module
        parts = self.parsed.module_name.split(".")[:-1]
        if level > len(parts) + 1:
            return None
        base = parts[: len(parts) - (level - 1)]
        if module:
            base.extend(module.split("."))
        return ".".join(base)


def build_reference_index(
    project_root: str | Path,
    *,
    graph_contexts: (
        Iterable[GraphReferenceContext | Mapping[str, object]] | None
    ) = None,
) -> ReferenceIndexResult:
    parsed_files = _parse_project_files(project_root)
    symbol_index, module_symbols, local_symbols, page_elements_by_page = (
        _collect_symbols(parsed_files)
    )
    for symbol in _collect_variant_set_symbols(project_root):
        symbol_index[symbol.id] = symbol
    for parsed in parsed_files:
        collector = _UsageCollector(
            parsed=parsed,
            module_symbols=module_symbols,
            local_symbols=local_symbols.get(parsed.rel_path, {}),
            page_elements_by_page=page_elements_by_page,
            symbol_index=symbol_index,
        )
        try:
            collector.visit(parsed.tree)
        except _ReferenceBuildError as exc:
            raise ValueError(str(exc)) from exc
    _append_variant_set_usages(project_root, symbol_index)

    graph_usage_map = _collect_graph_reference_usages_for_symbols(
        symbol_index={symbol.id: symbol.to_model() for symbol in symbol_index.values()},
        graph_contexts=graph_contexts,
    )
    for symbol_id, graph_usages in graph_usage_map.items():
        matched_symbol = symbol_index.get(symbol_id)
        if matched_symbol is None:
            continue
        existing = {
            (
                item.file_path,
                item.start_offset,
                item.end_offset,
                item.usage_kind,
                item.source_kind,
                item.source_id,
            )
            for item in matched_symbol.usages
        }
        for occurrence in graph_usages:
            key = (
                occurrence.file_path,
                occurrence.start_offset,
                occurrence.end_offset,
                occurrence.usage_kind,
                occurrence.source_kind,
                occurrence.source_id,
            )
            if key in existing:
                continue
            matched_symbol.usages.append(
                _OccurrenceData(
                    file_path=occurrence.file_path,
                    line=occurrence.line,
                    column=occurrence.column,
                    end_line=occurrence.end_line,
                    end_column=occurrence.end_column,
                    start_offset=occurrence.start_offset,
                    end_offset=occurrence.end_offset,
                    usage_kind=occurrence.usage_kind,
                    context=occurrence.context,
                    source_kind=occurrence.source_kind or "scenario_graph",
                    source_id=occurrence.source_id,
                    source_label=occurrence.source_label,
                )
            )

    return ReferenceIndexResult(
        symbols=[
            symbol.to_model()
            for symbol in sorted(
                symbol_index.values(),
                key=lambda item: (
                    item.kind,
                    item.definition.file_path,
                    item.definition.line,
                    item.qualified_name,
                ),
            )
        ],
    )


def find_symbol_usages(
    project_root: str | Path,
    symbol_id: str,
    *,
    graph_contexts: (
        Iterable[GraphReferenceContext | Mapping[str, object]] | None
    ) = None,
) -> ReferenceSymbol:
    index = build_reference_index(project_root, graph_contexts=graph_contexts)
    for symbol in index.symbols:
        if symbol.id == symbol_id:
            return symbol
    raise ValueError(f"Symbol not found: {symbol_id}")


def plan_safe_rename(
    project_root: str | Path,
    *,
    symbol_id: str,
    new_name: str,
    graph_contexts: (
        Iterable[GraphReferenceContext | Mapping[str, object]] | None
    ) = None,
) -> SafeRenamePlan:
    index = build_reference_index(project_root)
    symbol = next((item for item in index.symbols if item.id == symbol_id), None)
    if symbol is None:
        raise ValueError(f"Symbol not found: {symbol_id}")

    _validate_new_name(symbol.kind, new_name)
    occurrences = (
        [*symbol.usages]
        if symbol.kind == "variant_set"
        else [symbol.definition, *symbol.usages]
    )
    unique_occurrences = _dedupe_occurrences(occurrences)
    edits = [
        RenameEdit(
            file_path=item.file_path,
            line=item.line,
            column=item.column,
            end_line=item.end_line,
            end_column=item.end_column,
            start_offset=item.start_offset,
            end_offset=item.end_offset,
            old_text=symbol.name,
            new_text=new_name,
            usage_kind=item.usage_kind,
            context=item.context,
        )
        for item in unique_occurrences
    ]
    file_moves = _build_rename_file_moves(symbol=symbol, new_name=new_name)
    conflicts = _find_rename_conflicts(
        project_root=Path(project_root),
        symbol=symbol,
        indexed_occurrences=unique_occurrences,
        file_moves=file_moves,
    )
    graph_usage_map = collect_graph_reference_usages(
        project_root, graph_contexts=graph_contexts
    )
    graph_usages = graph_usage_map.get(symbol.id, [])
    impact = _build_rename_impact(
        unique_occurrences,
        graph_usages=graph_usages,
        file_moves=file_moves,
    )
    return SafeRenamePlan(
        symbol=symbol,
        new_name=new_name,
        edits=edits,
        file_moves=file_moves,
        conflicts=conflicts,
        graph_usages=graph_usages,
        impact=impact,
        blocked=len(conflicts) > 0,
    )


def apply_safe_rename(
    project_root: str | Path,
    *,
    symbol_id: str,
    new_name: str,
    graph_contexts: (
        Iterable[GraphReferenceContext | Mapping[str, object]] | None
    ) = None,
) -> SafeRenamePlan:
    plan = plan_safe_rename(
        project_root,
        symbol_id=symbol_id,
        new_name=new_name,
        graph_contexts=graph_contexts,
    )
    if plan.blocked:
        first = plan.conflicts[0]
        raise ValueError(
            "Safe rename blocked: "
            f"{first.message} at {first.file_path}:{first.line}:{first.column}"
        )

    grouped: dict[str, list[RenameEdit]] = {}
    for edit in plan.edits:
        grouped.setdefault(edit.file_path, []).append(edit)

    applied_files: list[str] = []
    for rel_path, file_edits in grouped.items():
        file_path = Path(project_root) / rel_path
        content = file_path.read_text(encoding="utf-8")
        for edit in sorted(
            file_edits, key=lambda item: item.start_offset, reverse=True
        ):
            old_text = content[edit.start_offset : edit.end_offset]
            before_char = (
                content[edit.start_offset - 1] if edit.start_offset > 0 else ""
            )
            after_char = (
                content[edit.end_offset] if edit.end_offset < len(content) else ""
            )
            if (
                old_text != edit.old_text
                or _is_identifier_char(before_char)
                or _is_identifier_char(after_char)
            ):
                raise ValueError(
                    "Safe rename aborted due to stale source: "
                    f"expected '{edit.old_text}' in {edit.file_path}:{edit.line}:{edit.column}, got '{old_text}'"
                )
            content = (
                content[: edit.start_offset]
                + edit.new_text
                + content[edit.end_offset :]
            )
        file_path.write_text(content, encoding="utf-8")
        applied_files.append(rel_path)

    for file_move in plan.file_moves:
        source_path = Path(project_root) / file_move.source_path
        target_path = Path(project_root) / file_move.target_path
        target_path.parent.mkdir(parents=True, exist_ok=True)
        source_path.rename(target_path)
        applied_files.extend([file_move.source_path, file_move.target_path])

    plan.applied_files = sorted(set(applied_files))
    return plan


def collect_graph_reference_usages(
    project_root: str | Path,
    *,
    graph_contexts: (
        Iterable[GraphReferenceContext | Mapping[str, object]] | None
    ) = None,
) -> dict[str, list[ReferenceOccurrence]]:
    index = build_reference_index(project_root)
    by_id = {symbol.id: symbol for symbol in index.symbols}
    return _collect_graph_reference_usages_for_symbols(
        symbol_index=by_id,
        graph_contexts=graph_contexts,
    )


def preview_graph_dependencies(
    project_root: str | Path,
    *,
    graph_contexts: (
        Iterable[GraphReferenceContext | Mapping[str, object]] | None
    ) = None,
) -> list[ReferenceImpactEntry]:
    index = build_reference_index(project_root)
    by_id = {symbol.id: symbol for symbol in index.symbols}
    graph_usage_map = _collect_graph_reference_usages_for_symbols(
        symbol_index=by_id,
        graph_contexts=graph_contexts,
    )
    return _build_reference_impact_entries(by_id, graph_usage_map)


def preview_page_regeneration_impact(
    project_root: str | Path,
    *,
    page_path: str,
    generated_page_name: str,
    generated_element_names: Iterable[str],
    mode: Literal["create", "merge"],
    graph_contexts: (
        Iterable[GraphReferenceContext | Mapping[str, object]] | None
    ) = None,
) -> PageRegenerationImpactPreview:
    generated_names = {name for name in generated_element_names if name}
    if mode == "create":
        return PageRegenerationImpactPreview(
            page_path=page_path,
            page_name=generated_page_name,
            mode=mode,
            summary="Создаётся новый файл страницы. Существующие символы проекта не затрагиваются.",
            added_elements=sorted(generated_names),
            retained_element_count=0,
        )

    index = build_reference_index(project_root)
    by_id = {symbol.id: symbol for symbol in index.symbols}
    page_symbol = next(
        (
            symbol
            for symbol in index.symbols
            if symbol.kind == "page" and symbol.definition.file_path == page_path
        ),
        None,
    )
    if page_symbol is None:
        raise ValueError(f"Page symbol not found for path: {page_path}")

    page_elements = [
        symbol
        for symbol in index.symbols
        if symbol.kind == "page_element" and symbol.parent_id == page_symbol.id
    ]
    graph_usage_map = _collect_graph_reference_usages_for_symbols(
        symbol_index=by_id,
        graph_contexts=graph_contexts,
    )

    removed: list[ReferenceImpactEntry] = []
    retained_count = 0
    existing_names = {symbol.name for symbol in page_elements}
    for symbol in page_elements:
        if symbol.name in generated_names:
            retained_count += 1
            continue
        removed.append(
            _build_reference_impact_entry(
                symbol=symbol,
                graph_usages=graph_usage_map.get(symbol.id, []),
                message=(
                    f"Элемент {symbol.name} отсутствует в регенерированном дереве "
                    "и может сломать существующие использования."
                ),
            )
        )

    added_names = sorted(generated_names - existing_names)
    if removed:
        summary = (
            f"Регенерация удаляет {len(removed)} существующих элементов страницы "
            f"{page_symbol.name} и добавляет {len(added_names)} новых."
        )
    else:
        summary = (
            f"Регенерация не удаляет существующие элементы страницы {page_symbol.name}. "
            f"Новых элементов: {len(added_names)}."
        )
    return PageRegenerationImpactPreview(
        page_path=page_path,
        page_name=page_symbol.name,
        mode=mode,
        summary=summary,
        removed_symbols=sorted(
            removed,
            key=lambda item: (-item.total_usage_count, item.symbol.qualified_name),
        ),
        added_elements=added_names,
        retained_element_count=retained_count,
    )


def _collect_symbols(
    parsed_files: Iterable[_ParsedFile],
) -> tuple[
    dict[str, _SymbolData],
    dict[str, dict[str, str]],
    dict[str, dict[str, str]],
    dict[str, dict[str, str]],
]:
    symbol_index: dict[str, _SymbolData] = {}
    module_symbols: dict[str, dict[str, str]] = {}
    file_symbols: dict[str, dict[str, str]] = {}
    page_elements_by_page: dict[str, dict[str, str]] = {}

    for parsed in parsed_files:
        per_file: dict[str, str] = {}
        per_module = module_symbols.setdefault(parsed.module_name, {})

        for node in parsed.tree.body:
            if isinstance(node, ast.ClassDef):
                base_names = {
                    _base_name(base) for base in node.bases if _base_name(base)
                }
                if base_names & _PAGE_BASES:
                    symbol = _make_page_symbol(parsed, node)
                    symbol_index[symbol.id] = symbol
                    per_file[node.name] = symbol.id
                    per_module[node.name] = symbol.id
                    page_elements_by_page[symbol.id] = {}
                    for element in _page_element_symbols(parsed, node, symbol.id):
                        symbol_index[element.id] = element
                        page_elements_by_page[symbol.id][element.name] = element.id
                    continue
                if base_names & _STEP_BASES:
                    symbol = _make_step_symbol(parsed, node)
                    symbol_index[symbol.id] = symbol
                    per_file[node.name] = symbol.id
                    per_module[node.name] = symbol.id
                    continue
                for child in node.body:
                    if isinstance(child, ast.FunctionDef) and child.name.startswith(
                        "test_"
                    ):
                        symbol = _make_test_method_symbol(parsed, node, child)
                        symbol_index[symbol.id] = symbol
            elif isinstance(node, ast.FunctionDef) and node.name.startswith("test_"):
                symbol = _make_test_function_symbol(parsed, node)
                symbol_index[symbol.id] = symbol

        file_symbols[parsed.rel_path] = per_file

    return symbol_index, module_symbols, file_symbols, page_elements_by_page


def _page_element_symbols(
    parsed: _ParsedFile,
    class_node: ast.ClassDef,
    page_symbol_id: str,
) -> Iterable[_SymbolData]:
    for node in class_node.body:
        if not isinstance(node, ast.FunctionDef) or node.name != "__init__":
            continue
        for statement in node.body:
            targets: list[ast.AST] = []
            if isinstance(statement, ast.Assign):
                targets = list(statement.targets)
            elif isinstance(statement, ast.AnnAssign):
                targets = [statement.target]
            else:
                continue
            for target in targets:
                if (
                    isinstance(target, ast.Attribute)
                    and isinstance(target.value, ast.Name)
                    and target.value.id == "self"
                ):
                    occurrence = _attribute_occurrence(
                        parsed,
                        target,
                        usage_kind="definition",
                    )
                    if occurrence is None:
                        raise _ReferenceBuildError(
                            f"Cannot resolve page element definition in {parsed.rel_path}:{getattr(target, 'lineno', '?')}"
                        )
                    rel_path = parsed.rel_path
                    yield _SymbolData(
                        id=f"page_element::{rel_path}::{class_node.name}.{target.attr}",
                        kind="page_element",
                        name=target.attr,
                        qualified_name=f"{class_node.name}.{target.attr}",
                        parent_id=page_symbol_id,
                        node_id=f"{rel_path}::{class_node.name}",
                        definition=occurrence,
                    )


def _make_page_symbol(parsed: _ParsedFile, node: ast.ClassDef) -> _SymbolData:
    occurrence = _class_name_occurrence(parsed, node)
    rel_path = parsed.rel_path
    return _SymbolData(
        id=f"page::{rel_path}::{node.name}",
        kind="page",
        name=node.name,
        qualified_name=node.name,
        parent_id=None,
        node_id=f"{rel_path}::{node.name}",
        definition=occurrence,
    )


def _make_step_symbol(parsed: _ParsedFile, node: ast.ClassDef) -> _SymbolData:
    occurrence = _class_name_occurrence(parsed, node)
    rel_path = parsed.rel_path
    return _SymbolData(
        id=f"step::{rel_path}::{node.name}",
        kind="step",
        name=node.name,
        qualified_name=node.name,
        parent_id=None,
        node_id=f"{rel_path}::{node.name}",
        definition=occurrence,
    )


def _make_test_function_symbol(
    parsed: _ParsedFile, node: ast.FunctionDef
) -> _SymbolData:
    occurrence = _function_name_occurrence(parsed, node)
    rel_path = parsed.rel_path
    node_id = f"{rel_path}::{node.name}"
    return _SymbolData(
        id=f"test::{node_id}",
        kind="test",
        name=node.name,
        qualified_name=node_id,
        parent_id=None,
        node_id=node_id,
        definition=occurrence,
    )


def _make_test_method_symbol(
    parsed: _ParsedFile,
    class_node: ast.ClassDef,
    node: ast.FunctionDef,
) -> _SymbolData:
    occurrence = _function_name_occurrence(parsed, node)
    rel_path = parsed.rel_path
    node_id = f"{rel_path}::{class_node.name}::{node.name}"
    return _SymbolData(
        id=f"test::{node_id}",
        kind="test",
        name=node.name,
        qualified_name=node_id,
        parent_id=None,
        node_id=node_id,
        definition=occurrence,
    )


def _collect_variant_set_symbols(project_root: str | Path) -> list[_SymbolData]:
    reference_index = build_variant_set_reference_index(project_root)
    return [
        _SymbolData(
            id=f"variant_set::{definition.set_name}",
            kind="variant_set",
            name=definition.set_name,
            qualified_name=f"variants/{definition.set_name}",
            parent_id=None,
            node_id=f"variants::{definition.set_name}",
            definition=_OccurrenceData(
                file_path=definition.file_path,
                line=definition.line,
                column=definition.column,
                end_line=definition.end_line,
                end_column=definition.end_column,
                start_offset=definition.start_offset,
                end_offset=definition.end_offset,
                usage_kind="definition_file",
                context=definition.context or f"variants/{definition.set_name}",
            ),
        )
        for definition in reference_index.definitions
    ]


def _append_variant_set_usages(
    project_root: str | Path,
    symbol_index: dict[str, _SymbolData],
) -> None:
    reference_index = build_variant_set_reference_index(project_root)
    for usage in reference_index.usages:
        symbol = symbol_index.get(
            f"variant_set::{_normalize_variant_set_name(usage.source)}"
        )
        if symbol is None:
            continue
        occurrence = _OccurrenceData(
            file_path=usage.file_path,
            line=usage.line,
            column=usage.column,
            end_line=usage.end_line,
            end_column=usage.end_column,
            start_offset=usage.start_offset,
            end_offset=usage.end_offset,
            usage_kind="data_driven_source",
            context=usage.context,
        )
        existing = {
            (item.file_path, item.start_offset, item.end_offset, item.usage_kind)
            for item in symbol.usages
        }
        key = (
            occurrence.file_path,
            occurrence.start_offset,
            occurrence.end_offset,
            occurrence.usage_kind,
        )
        if key not in existing:
            symbol.usages.append(occurrence)


def _parse_project_files(project_root: str | Path) -> list[_ParsedFile]:
    root = Path(project_root).resolve()
    parsed_files: list[_ParsedFile] = []
    for file_path in sorted(_iter_python_files(root)):
        source = file_path.read_text(encoding="utf-8")
        try:
            tree = ast.parse(source)
        except SyntaxError as error:
            raise ValueError(
                f"Cannot build reference index: syntax error in {file_path.relative_to(root)}:{error.lineno}:{error.offset}: {error.msg}"
            ) from error
        rel_path = file_path.relative_to(root).as_posix()
        parsed_files.append(
            _ParsedFile(
                root=root,
                file_path=file_path,
                rel_path=rel_path,
                module_name=rel_path.removesuffix(".py").replace("/", "."),
                source=source,
                tree=tree,
                line_offsets=_build_line_offsets(source),
            )
        )
    return parsed_files


def _iter_python_files(root: Path) -> Iterable[Path]:
    for file_path in root.rglob("*.py"):
        if any(part in _EXCLUDED_DIR_NAMES for part in file_path.parts):
            continue
        yield file_path


def _build_line_offsets(source: str) -> list[int]:
    offsets = [0]
    running = 0
    for line in source.splitlines(keepends=True):
        running += len(line)
        offsets.append(running)
    return offsets


def _offset_for(line_offsets: list[int], line: int, column: int) -> int:
    return line_offsets[line - 1] + column


def _context_line(parsed: _ParsedFile, line: int) -> str:
    lines = parsed.lines
    if 1 <= line <= len(lines):
        return lines[line - 1].strip()
    return ""


def _class_name_occurrence(parsed: _ParsedFile, node: ast.ClassDef) -> _OccurrenceData:
    return _keyword_identifier_occurrence(parsed, node, keyword="class", name=node.name)


def _function_name_occurrence(
    parsed: _ParsedFile, node: ast.FunctionDef
) -> _OccurrenceData:
    return _keyword_identifier_occurrence(parsed, node, keyword="def", name=node.name)


def _keyword_identifier_occurrence(
    parsed: _ParsedFile,
    node: ast.AST,
    *,
    keyword: str,
    name: str,
) -> _OccurrenceData:
    line = getattr(node, "lineno", None)
    column = getattr(node, "col_offset", None)
    if line is None or column is None:
        raise _ReferenceBuildError(
            f"Missing position info for {keyword} {name} in {parsed.rel_path}"
        )
    raw_line = parsed.lines[line - 1]
    segment = raw_line[column:]
    match = re.match(rf"\s*{re.escape(keyword)}\s+({re.escape(name)})\b", segment)
    if not match:
        raise _ReferenceBuildError(
            f"Cannot resolve identifier span for {name} in {parsed.rel_path}:{line}:{column}"
        )
    start_column = column + match.start(1)
    end_column = start_column + len(name)
    return _build_occurrence(
        parsed,
        line=line,
        column=start_column,
        end_line=line,
        end_column=end_column,
        usage_kind="definition",
    )


def _name_like_occurrence(
    parsed: _ParsedFile,
    node: ast.AST,
    *,
    usage_kind: str,
) -> _OccurrenceData | None:
    if isinstance(node, ast.Name):
        line = getattr(node, "lineno", None)
        column = getattr(node, "col_offset", None)
        end_line = getattr(node, "end_lineno", None)
        end_column = getattr(node, "end_col_offset", None)
        if (
            not _is_ast_int(line)
            or not _is_ast_int(column)
            or not _is_ast_int(end_line)
            or not _is_ast_int(end_column)
        ):
            return None
        line_no = line
        column_no = column
        end_line_no = end_line
        end_column_no = end_column
        return _build_occurrence(
            parsed,
            line=line_no,
            column=column_no,
            end_line=end_line_no,
            end_column=end_column_no,
            usage_kind=usage_kind,
        )
    if isinstance(node, ast.Attribute):
        return _attribute_occurrence(parsed, node, usage_kind=usage_kind)
    return None


def _attribute_occurrence(
    parsed: _ParsedFile,
    node: ast.Attribute,
    *,
    usage_kind: str,
) -> _OccurrenceData | None:
    line = getattr(node, "end_lineno", None) or getattr(node, "lineno", None)
    end_column = getattr(node, "end_col_offset", None)
    if not _is_ast_int(line) or not _is_ast_int(end_column):
        return None
    line_no = line
    end_column_no = end_column
    start_column = end_column_no - len(node.attr)
    if start_column < 0:
        return None
    return _build_occurrence(
        parsed,
        line=line_no,
        column=start_column,
        end_line=line_no,
        end_column=end_column_no,
        usage_kind=usage_kind,
    )


def _alias_occurrence(
    parsed: _ParsedFile,
    alias: ast.alias,
    *,
    usage_kind: str,
    fallback_name: str,
) -> _OccurrenceData | None:
    line = getattr(alias, "lineno", None)
    column = getattr(alias, "col_offset", None)
    end_line = getattr(alias, "end_lineno", None)
    end_column = getattr(alias, "end_col_offset", None)
    if (
        _is_ast_int(line)
        and _is_ast_int(column)
        and _is_ast_int(end_line)
        and _is_ast_int(end_column)
    ):
        line_no = line
        column_no = column
        end_line_no = end_line
        end_column_no = end_column
        text = parsed.source[
            _offset_for(parsed.line_offsets, line_no, column_no) : _offset_for(
                parsed.line_offsets, end_line_no, end_column_no
            )
        ]
        match = re.search(rf"\b{re.escape(fallback_name)}\b", text)
        if match:
            start_offset = (
                _offset_for(parsed.line_offsets, line_no, column_no) + match.start()
            )
            end_offset = start_offset + len(fallback_name)
            return _occurrence_from_offsets(
                parsed,
                start_offset=start_offset,
                end_offset=end_offset,
                usage_kind=usage_kind,
            )
    if not _is_ast_int(line) or not _is_ast_int(column):
        return None
    line_no = line
    column_no = column
    raw_line = parsed.lines[line_no - 1]
    match = re.search(rf"\b{re.escape(fallback_name)}\b", raw_line[column_no:])
    if not match:
        return None
    start_column = column_no + match.start()
    end_col = start_column + len(fallback_name)
    return _build_occurrence(
        parsed,
        line=line_no,
        column=start_column,
        end_line=line_no,
        end_column=end_col,
        usage_kind=usage_kind,
    )


def _build_occurrence(
    parsed: _ParsedFile,
    *,
    line: int,
    column: int,
    end_line: int,
    end_column: int,
    usage_kind: str,
) -> _OccurrenceData:
    start_offset = _offset_for(parsed.line_offsets, line, column)
    end_offset = _offset_for(parsed.line_offsets, end_line, end_column)
    return _OccurrenceData(
        file_path=parsed.rel_path,
        line=line,
        column=column,
        end_line=end_line,
        end_column=end_column,
        start_offset=start_offset,
        end_offset=end_offset,
        usage_kind=usage_kind,
        context=_context_line(parsed, line),
    )


def _occurrence_from_offsets(
    parsed: _ParsedFile,
    *,
    start_offset: int,
    end_offset: int,
    usage_kind: str,
) -> _OccurrenceData:
    line, column = _line_col_from_offset(parsed.line_offsets, start_offset)
    end_line, end_column = _line_col_from_offset(parsed.line_offsets, end_offset)
    return _OccurrenceData(
        file_path=parsed.rel_path,
        line=line,
        column=column,
        end_line=end_line,
        end_column=end_column,
        start_offset=start_offset,
        end_offset=end_offset,
        usage_kind=usage_kind,
        context=_context_line(parsed, line),
    )


def _line_col_from_offset(line_offsets: list[int], offset: int) -> tuple[int, int]:
    line = 1
    for index, boundary in enumerate(line_offsets[1:], start=1):
        if offset < boundary:
            line = index
            break
    else:
        line = max(len(line_offsets) - 1, 1)
    return line, offset - line_offsets[line - 1]


def _base_name(node: ast.AST) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return None


def _validate_new_name(kind: str, new_name: str) -> None:
    if kind == "variant_set":
        normalized = _normalize_variant_set_name(new_name)
        if not normalized:
            raise ValueError("Имя набора вариаций не может быть пустым")
        for segment in normalized.split("/"):
            if not re.fullmatch(r"[A-Za-z0-9_-]+", segment or ""):
                raise ValueError(
                    "Имя набора вариаций может содержать только латиницу, цифры, -, _ и /"
                )
        return
    if not new_name or not new_name.isidentifier():
        raise ValueError(f"New name must be a valid Python identifier: {new_name!r}")
    if kind == "test" and not new_name.startswith("test_"):
        raise ValueError("Test rename must keep the 'test_' prefix")


def _dedupe_occurrences(
    occurrences: Iterable[ReferenceOccurrence],
) -> list[ReferenceOccurrence]:
    seen: set[tuple[str, int, int, str, str | None, str | None]] = set()
    result: list[ReferenceOccurrence] = []
    for item in occurrences:
        key = (
            item.file_path,
            item.start_offset,
            item.end_offset,
            item.usage_kind,
            item.source_kind,
            item.source_id,
        )
        if key in seen:
            continue
        seen.add(key)
        result.append(item)
    return sorted(
        result,
        key=lambda item: (
            item.file_path,
            item.start_offset,
            item.end_offset,
            item.usage_kind,
            item.source_kind or "",
            item.source_id or "",
        ),
    )


def _find_rename_conflicts(
    *,
    project_root: Path,
    symbol: ReferenceSymbol,
    indexed_occurrences: Iterable[ReferenceOccurrence],
    file_moves: Iterable[RenameFileMove] = (),
) -> list[RenameConflict]:
    if symbol.kind == "variant_set":
        return _find_variant_set_rename_conflicts(
            project_root=project_root,
            symbol=symbol,
            indexed_occurrences=indexed_occurrences,
            file_moves=file_moves,
        )
    allowed = {
        (item.file_path, item.start_offset, item.end_offset)
        for item in indexed_occurrences
    }
    conflicts: list[RenameConflict] = []
    pattern = re.compile(rf"\b{re.escape(symbol.name)}\b")
    for file_path in _iter_python_files(project_root):
        rel_path = file_path.relative_to(project_root).as_posix()
        source = file_path.read_text(encoding="utf-8")
        line_offsets = _build_line_offsets(source)
        for match in pattern.finditer(source):
            key = (rel_path, match.start(), match.end())
            if key in allowed:
                continue
            line, column = _line_col_from_offset(line_offsets, match.start())
            end_line, end_column = _line_col_from_offset(line_offsets, match.end())
            context = source.splitlines()[line - 1].strip()
            conflicts.append(
                RenameConflict(
                    file_path=rel_path,
                    line=line,
                    column=column,
                    end_line=end_line,
                    end_column=end_column,
                    start_offset=match.start(),
                    end_offset=match.end(),
                    context=context,
                    message=(
                        "Unindexed occurrence blocks safe rename; "
                        "rename this occurrence manually or extend the reference index"
                    ),
                )
            )
    return conflicts


def _build_rename_impact(
    occurrences: Iterable[ReferenceOccurrence],
    *,
    graph_usages: Iterable[ReferenceOccurrence] = (),
    file_moves: Iterable[RenameFileMove] = (),
) -> RenameImpact:
    items = list(occurrences)
    graph_items = list(graph_usages)
    file_move_items = list(file_moves)
    files = {item.file_path for item in items}
    files.update(move.source_path for move in file_move_items)
    files.update(move.target_path for move in file_move_items)
    graph_contexts = {
        item.source_id or item.file_path for item in graph_items if item.source_kind
    }
    return RenameImpact(
        occurrence_count=len(items),
        file_count=len(files),
        test_file_count=sum(1 for path in files if _is_test_file(path)),
        page_file_count=sum(1 for path in files if "/pages/" in f"/{path}"),
        step_file_count=sum(1 for path in files if _is_step_like_file(path)),
        variant_file_count=sum(1 for path in files if _is_variant_set_file(path)),
        graph_usage_count=len(graph_items),
        graph_context_count=len(graph_contexts),
    )


def _is_test_file(path: str) -> bool:
    return path.startswith("tests/") and Path(path).name.startswith("test_")


def _is_step_like_file(path: str) -> bool:
    normalized = f"/{path}"
    return any(
        token in normalized
        for token in ("/tests/actions/", "/tests/goals/", "/tests/steps/")
    )


def _is_variant_set_file(path: str) -> bool:
    normalized = f"/{path}"
    return "/tests/data/variants/" in normalized and Path(path).suffix.lower() in {
        ".yaml",
        ".yml",
        ".json",
    }


def _is_identifier_char(value: str) -> bool:
    return bool(value) and (value.isalnum() or value == "_")


def _normalize_variant_set_name(value: str) -> str:
    normalized = str(value or "").strip().replace("\\", "/")
    if normalized.startswith("./"):
        normalized = normalized[2:]
    if normalized.startswith("tests/data/"):
        normalized = normalized[len("tests/data/") :]
    if normalized.startswith("variants/"):
        normalized = normalized[len("variants/") :]
    for suffix in (".yaml", ".yml", ".json"):
        if normalized.endswith(suffix):
            normalized = normalized[: -len(suffix)]
            break
    return normalized.strip("/")


def _build_rename_file_moves(
    *,
    symbol: ReferenceSymbol,
    new_name: str,
) -> list[RenameFileMove]:
    if symbol.kind != "variant_set":
        return []
    source_path = symbol.definition.file_path
    extension = Path(source_path).suffix
    target_path = (
        Path("tests/data/variants") / Path(_normalize_variant_set_name(new_name))
    ).with_suffix(extension)
    if source_path == target_path.as_posix():
        return []
    return [
        RenameFileMove(
            source_path=source_path,
            target_path=target_path.as_posix(),
        )
    ]


def _find_variant_set_rename_conflicts(
    *,
    project_root: Path,
    symbol: ReferenceSymbol,
    indexed_occurrences: Iterable[ReferenceOccurrence],
    file_moves: Iterable[RenameFileMove],
) -> list[RenameConflict]:
    allowed = {
        (item.file_path, item.start_offset, item.end_offset)
        for item in indexed_occurrences
    }
    conflicts: list[RenameConflict] = []
    for file_move in file_moves:
        target_path = project_root / file_move.target_path
        if target_path.exists():
            conflicts.append(
                RenameConflict(
                    file_path=file_move.target_path,
                    line=1,
                    column=0,
                    end_line=1,
                    end_column=0,
                    start_offset=0,
                    end_offset=0,
                    context=file_move.target_path,
                    message="Целевой файл набора вариаций уже существует",
                )
            )

    for file_path in _iter_python_files(project_root):
        rel_path = file_path.relative_to(project_root).as_posix()
        source = file_path.read_text(encoding="utf-8")
        line_offsets = _build_line_offsets(source)
        for start_offset, end_offset in _iter_variant_set_occurrence_candidates(
            source=source,
            set_name=symbol.name,
        ):
            key = (rel_path, start_offset, end_offset)
            if key in allowed:
                continue
            line, column = _line_col_from_offset(line_offsets, start_offset)
            end_line, end_column = _line_col_from_offset(line_offsets, end_offset)
            context = source.splitlines()[line - 1].strip()
            conflicts.append(
                RenameConflict(
                    file_path=rel_path,
                    line=line,
                    column=column,
                    end_line=end_line,
                    end_column=end_column,
                    start_offset=start_offset,
                    end_offset=end_offset,
                    context=context,
                    message=(
                        "Unindexed occurrence blocks safe rename; "
                        "rename this occurrence manually or extend the reference index"
                    ),
                )
            )
    return conflicts


def _iter_variant_set_occurrence_candidates(
    *,
    source: str,
    set_name: str,
) -> Iterable[tuple[int, int]]:
    seen: set[tuple[int, int]] = set()
    needles = [
        set_name,
        f"variants/{set_name}",
        f"tests/data/variants/{set_name}",
        f"./tests/data/variants/{set_name}",
        f"variants/{set_name}.yaml",
        f"variants/{set_name}.yml",
        f"variants/{set_name}.json",
        f"tests/data/variants/{set_name}.yaml",
        f"tests/data/variants/{set_name}.yml",
        f"tests/data/variants/{set_name}.json",
        f"./tests/data/variants/{set_name}.yaml",
        f"./tests/data/variants/{set_name}.yml",
        f"./tests/data/variants/{set_name}.json",
    ]
    for needle in needles:
        for match in re.finditer(re.escape(needle), source):
            start_offset = match.start() + needle.find(set_name)
            end_offset = start_offset + len(set_name)
            key = (start_offset, end_offset)
            if key in seen:
                continue
            seen.add(key)
            yield key


def _normalize_graph_contexts(
    graph_contexts: Iterable[GraphReferenceContext | Mapping[str, object]] | None,
) -> list[GraphReferenceContext]:
    return [GraphReferenceContext.model_validate(item) for item in graph_contexts or []]


def _collect_graph_reference_usages_for_symbols(
    *,
    symbol_index: Mapping[str, ReferenceSymbol],
    graph_contexts: Iterable[GraphReferenceContext | Mapping[str, object]] | None,
) -> dict[str, list[ReferenceOccurrence]]:
    contexts = _normalize_graph_contexts(graph_contexts)
    if not contexts:
        return {}

    page_symbols = {
        symbol.name: symbol for symbol in symbol_index.values() if symbol.kind == "page"
    }
    step_symbols = {
        symbol.name: symbol for symbol in symbol_index.values() if symbol.kind == "step"
    }
    page_name_by_id = {
        symbol.id: symbol.name
        for symbol in symbol_index.values()
        if symbol.kind == "page"
    }
    element_symbols: dict[tuple[str, str], ReferenceSymbol] = {}
    for symbol in symbol_index.values():
        if symbol.kind != "page_element" or not symbol.parent_id:
            continue
        page_name = page_name_by_id.get(symbol.parent_id)
        if page_name is None:
            continue
        element_symbols[(page_name, symbol.name)] = symbol

    usages: dict[str, list[ReferenceOccurrence]] = {}
    seen: set[tuple[str, str, str, str]] = set()
    for context in contexts:
        for index, node in enumerate(context.nodes):
            _collect_graph_node_usages(
                node=node,
                node_path=f"root[{index}]",
                context=context,
                page_symbols=page_symbols,
                step_symbols=step_symbols,
                element_symbols=element_symbols,
                usages=usages,
                seen=seen,
            )
    return usages


def _collect_graph_node_usages(
    *,
    node: Mapping[str, object],
    node_path: str,
    context: GraphReferenceContext,
    page_symbols: Mapping[str, ReferenceSymbol],
    step_symbols: Mapping[str, ReferenceSymbol],
    element_symbols: Mapping[tuple[str, str], ReferenceSymbol],
    usages: dict[str, list[ReferenceOccurrence]],
    seen: set[tuple[str, str, str, str]],
) -> None:
    component = node.get("component")
    if isinstance(component, Mapping):
        component_name = str(component.get("name") or "")
        step_symbol = step_symbols.get(component_name)
        if step_symbol is not None:
            _append_graph_usage(
                usages=usages,
                seen=seen,
                symbol=step_symbol,
                occurrence=_make_graph_occurrence(
                    context=context,
                    node_path=node_path,
                    usage_kind="graph_step_component",
                    detail=f"Шаг использует компонент {component_name}",
                ),
            )
        params = node.get("parameters")
        if isinstance(params, Mapping):
            _collect_graph_param_usages(
                params=params,
                component=component,
                context=context,
                node_path=f"{node_path}.parameters",
                page_symbols=page_symbols,
                element_symbols=element_symbols,
                usages=usages,
                seen=seen,
            )
        return

    kind = str(node.get("kind") or "")
    if kind == "if":
        _collect_graph_component_params(
            component=node.get("condition_fact"),
            params=node.get("condition_params"),
            context=context,
            node_path=f"{node_path}.condition_params",
            page_symbols=page_symbols,
            element_symbols=element_symbols,
            usages=usages,
            seen=seen,
        )
        _collect_graph_component_params(
            component=node.get("expectation"),
            params=node.get("expectation_params"),
            context=context,
            node_path=f"{node_path}.expectation_params",
            page_symbols=page_symbols,
            element_symbols=element_symbols,
            usages=usages,
            seen=seen,
        )
        _collect_graph_child_nodes(
            node.get("then_steps"),
            f"{node_path}.then_steps",
            context,
            page_symbols,
            step_symbols,
            element_symbols,
            usages,
            seen,
        )
        _collect_graph_child_nodes(
            node.get("else_steps"),
            f"{node_path}.else_steps",
            context,
            page_symbols,
            step_symbols,
            element_symbols,
            usages,
            seen,
        )
        return

    if kind == "foreach":
        _collect_graph_component_params(
            component=node.get("items_fact"),
            params=node.get("items_params"),
            context=context,
            node_path=f"{node_path}.items_params",
            page_symbols=page_symbols,
            element_symbols=element_symbols,
            usages=usages,
            seen=seen,
        )
        _collect_graph_value_usages(
            value=node.get("items_var"),
            context=context,
            node_path=f"{node_path}.items_var",
            page_symbols=page_symbols,
            element_symbols=element_symbols,
            usages=usages,
            seen=seen,
            allow_page_string=False,
        )
        _collect_graph_child_nodes(
            node.get("steps"),
            f"{node_path}.steps",
            context,
            page_symbols,
            step_symbols,
            element_symbols,
            usages,
            seen,
        )
        return

    if kind == "while":
        _collect_graph_component_params(
            component=node.get("condition_fact"),
            params=node.get("condition_params"),
            context=context,
            node_path=f"{node_path}.condition_params",
            page_symbols=page_symbols,
            element_symbols=element_symbols,
            usages=usages,
            seen=seen,
        )
        _collect_graph_component_params(
            component=node.get("expectation"),
            params=node.get("expectation_params"),
            context=context,
            node_path=f"{node_path}.expectation_params",
            page_symbols=page_symbols,
            element_symbols=element_symbols,
            usages=usages,
            seen=seen,
        )
        _collect_graph_child_nodes(
            node.get("steps"),
            f"{node_path}.steps",
            context,
            page_symbols,
            step_symbols,
            element_symbols,
            usages,
            seen,
        )
        return

    if kind == "retry":
        _collect_graph_child_nodes(
            node.get("steps"),
            f"{node_path}.steps",
            context,
            page_symbols,
            step_symbols,
            element_symbols,
            usages,
            seen,
        )


def _collect_graph_child_nodes(
    raw_nodes: object,
    node_path: str,
    context: GraphReferenceContext,
    page_symbols: Mapping[str, ReferenceSymbol],
    step_symbols: Mapping[str, ReferenceSymbol],
    element_symbols: Mapping[tuple[str, str], ReferenceSymbol],
    usages: dict[str, list[ReferenceOccurrence]],
    seen: set[tuple[str, str, str, str]],
) -> None:
    if not isinstance(raw_nodes, list):
        return
    for index, node in enumerate(raw_nodes):
        if not isinstance(node, Mapping):
            continue
        _collect_graph_node_usages(
            node=node,
            node_path=f"{node_path}[{index}]",
            context=context,
            page_symbols=page_symbols,
            step_symbols=step_symbols,
            element_symbols=element_symbols,
            usages=usages,
            seen=seen,
        )


def _collect_graph_component_params(
    *,
    component: object,
    params: object,
    context: GraphReferenceContext,
    node_path: str,
    page_symbols: Mapping[str, ReferenceSymbol],
    element_symbols: Mapping[tuple[str, str], ReferenceSymbol],
    usages: dict[str, list[ReferenceOccurrence]],
    seen: set[tuple[str, str, str, str]],
) -> None:
    if not isinstance(component, Mapping) or not isinstance(params, Mapping):
        return
    _collect_graph_param_usages(
        params=params,
        component=component,
        context=context,
        node_path=node_path,
        page_symbols=page_symbols,
        element_symbols=element_symbols,
        usages=usages,
        seen=seen,
    )


def _collect_graph_param_usages(
    *,
    params: Mapping[str, object],
    component: Mapping[str, object],
    context: GraphReferenceContext,
    node_path: str,
    page_symbols: Mapping[str, ReferenceSymbol],
    element_symbols: Mapping[tuple[str, str], ReferenceSymbol],
    usages: dict[str, list[ReferenceOccurrence]],
    seen: set[tuple[str, str, str, str]],
) -> None:
    page_param_names = {
        str(param.get("name") or "")
        for param in _iter_graph_parameters(component.get("parameters"))
        if _is_page_like_param_signature(param)
    }
    for name, value in params.items():
        _collect_graph_value_usages(
            value=value,
            context=context,
            node_path=f"{node_path}.{name}",
            page_symbols=page_symbols,
            element_symbols=element_symbols,
            usages=usages,
            seen=seen,
            allow_page_string=name in page_param_names,
        )


def _collect_graph_value_usages(
    *,
    value: object,
    context: GraphReferenceContext,
    node_path: str,
    page_symbols: Mapping[str, ReferenceSymbol],
    element_symbols: Mapping[tuple[str, str], ReferenceSymbol],
    usages: dict[str, list[ReferenceOccurrence]],
    seen: set[tuple[str, str, str, str]],
    allow_page_string: bool,
) -> None:
    if isinstance(value, Mapping):
        if value.get("kind") == "element":
            page_name = str(value.get("page") or "")
            element_name = str(value.get("element") or "")
            page_symbol = page_symbols.get(page_name)
            if page_symbol is not None:
                _append_graph_usage(
                    usages=usages,
                    seen=seen,
                    symbol=page_symbol,
                    occurrence=_make_graph_occurrence(
                        context=context,
                        node_path=node_path,
                        usage_kind="graph_page_ref",
                        detail=f"Граф использует страницу {page_name}",
                    ),
                )
            element_symbol = element_symbols.get((page_name, element_name))
            if element_symbol is not None:
                _append_graph_usage(
                    usages=usages,
                    seen=seen,
                    symbol=element_symbol,
                    occurrence=_make_graph_occurrence(
                        context=context,
                        node_path=node_path,
                        usage_kind="graph_page_element_ref",
                        detail=f"Граф использует элемент {page_name}.{element_name}",
                    ),
                )
            return
        for key, child in value.items():
            _collect_graph_value_usages(
                value=child,
                context=context,
                node_path=f"{node_path}.{key}",
                page_symbols=page_symbols,
                element_symbols=element_symbols,
                usages=usages,
                seen=seen,
                allow_page_string=False,
            )
        return
    if isinstance(value, list):
        for index, child in enumerate(value):
            _collect_graph_value_usages(
                value=child,
                context=context,
                node_path=f"{node_path}[{index}]",
                page_symbols=page_symbols,
                element_symbols=element_symbols,
                usages=usages,
                seen=seen,
                allow_page_string=False,
            )
        return
    if allow_page_string and isinstance(value, str):
        page_symbol = page_symbols.get(value)
        if page_symbol is not None:
            _append_graph_usage(
                usages=usages,
                seen=seen,
                symbol=page_symbol,
                occurrence=_make_graph_occurrence(
                    context=context,
                    node_path=node_path,
                    usage_kind="graph_page_ref",
                    detail=f"Граф использует страницу {value}",
                ),
            )


def _append_graph_usage(
    *,
    usages: dict[str, list[ReferenceOccurrence]],
    seen: set[tuple[str, str, str, str]],
    symbol: ReferenceSymbol,
    occurrence: ReferenceOccurrence,
) -> None:
    key = (
        symbol.id,
        occurrence.source_id or occurrence.file_path,
        occurrence.usage_kind,
        occurrence.context,
    )
    if key in seen:
        return
    seen.add(key)
    usages.setdefault(symbol.id, []).append(occurrence)


def _make_graph_occurrence(
    *,
    context: GraphReferenceContext,
    node_path: str,
    usage_kind: str,
    detail: str,
) -> ReferenceOccurrence:
    pseudo_path = f"__graph__/{context.context_id}"
    return ReferenceOccurrence(
        file_path=pseudo_path,
        line=0,
        column=0,
        end_line=0,
        end_column=0,
        start_offset=0,
        end_offset=0,
        usage_kind=usage_kind,
        context=f"{context.context_label}: {detail} ({node_path})",
        source_kind="scenario_graph",
        source_id=context.context_id,
        source_label=context.context_label,
    )


def _build_reference_impact_entries(
    symbol_index: Mapping[str, ReferenceSymbol],
    graph_usage_map: Mapping[str, list[ReferenceOccurrence]],
) -> list[ReferenceImpactEntry]:
    items: list[ReferenceImpactEntry] = []
    for symbol_id, graph_usages in graph_usage_map.items():
        symbol = symbol_index.get(symbol_id)
        if symbol is None:
            continue
        items.append(
            _build_reference_impact_entry(symbol=symbol, graph_usages=graph_usages)
        )
    return sorted(
        items, key=lambda item: (-item.total_usage_count, item.symbol.qualified_name)
    )


def _build_reference_impact_entry(
    *,
    symbol: ReferenceSymbol,
    graph_usages: Iterable[ReferenceOccurrence],
    message: str | None = None,
) -> ReferenceImpactEntry:
    graph_items = _dedupe_occurrences(graph_usages)
    python_items = _dedupe_occurrences(symbol.usages)
    return ReferenceImpactEntry(
        symbol=symbol,
        python_usages=python_items,
        graph_usages=graph_items,
        total_usage_count=len(python_items) + len(graph_items),
        message=message,
    )


def _is_page_like_param_signature(param: Mapping[str, object]) -> bool:
    type_name = str(param.get("type") or "").lower()
    name = str(param.get("name") or "").lower()
    return "page" in type_name or "page" in name
