from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Literal, Self

from persona_dsl.json_types import JsonObject, is_json_object


def _require_mapping(raw: object, model_name: str) -> Mapping[str, object]:
    if not isinstance(raw, Mapping):
        model_dump = getattr(raw, "model_dump", None)
        if callable(model_dump):
            raw = model_dump(mode="python")
    if not isinstance(raw, Mapping):
        raise TypeError(f"{model_name} должен быть объектом.")
    for key in raw:
        if not isinstance(key, str):
            raise TypeError(f"{model_name} должен содержать только строковые ключи.")
    return raw


def _require_str(data: Mapping[str, object], field_name: str, model_name: str) -> str:
    value = data.get(field_name)
    if not isinstance(value, str) or not value:
        raise TypeError(f"{model_name}.{field_name} должен быть непустой строкой.")
    return value


def _require_optional_str(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
) -> str | None:
    value = data.get(field_name)
    if value is None:
        return None
    if not isinstance(value, str):
        raise TypeError(f"{model_name}.{field_name} должен быть строкой или null.")
    return value


def _require_int(data: Mapping[str, object], field_name: str, model_name: str) -> int:
    value = data.get(field_name)
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{model_name}.{field_name} должен быть целым числом.")
    return value


def _require_bool_with_default(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
    default: bool,
) -> bool:
    value = data.get(field_name, default)
    if not isinstance(value, bool):
        raise TypeError(f"{model_name}.{field_name} должен быть булевым значением.")
    return value


def _require_string_list(raw: object, context: str) -> list[str]:
    if not isinstance(raw, list):
        raise TypeError(f"{context} должен быть списком строк.")
    result: list[str] = []
    for item in raw:
        if not isinstance(item, str):
            raise TypeError(f"{context} должен содержать только строки.")
        result.append(item)
    return result


def _coerce_string_list(items: list[str], context: str) -> list[str]:
    result: list[str] = []
    for item in items:
        if not isinstance(item, str):
            raise TypeError(f"{context} должен содержать только строки.")
        result.append(item)
    return result


def _require_json_object_list(raw: object, context: str) -> list[JsonObject]:
    if not isinstance(raw, list):
        raise TypeError(f"{context} должен быть списком JSON-объектов.")
    result: list[JsonObject] = []
    for item in raw:
        if not is_json_object(item):
            raise TypeError(f"{context} должен содержать только JSON-объекты.")
        result.append(item)
    return result


def _coerce_json_object_list(items: list[JsonObject], context: str) -> list[JsonObject]:
    result: list[JsonObject] = []
    for item in items:
        if not is_json_object(item):
            raise TypeError(f"{context} должен содержать только JSON-объекты.")
        result.append(item)
    return result


def _require_source_kind(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
) -> Literal["python_file", "scenario_graph"] | None:
    value = data.get(field_name)
    if value is None:
        return None
    if value == "python_file":
        return "python_file"
    if value == "scenario_graph":
        return "scenario_graph"
    raise TypeError(
        f"{model_name}.{field_name} должен быть 'python_file', 'scenario_graph' или null."
    )


def _require_symbol_kind(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
) -> Literal["page", "page_element", "step", "test", "variant_set"]:
    value = data.get(field_name)
    if value == "page":
        return "page"
    if value == "page_element":
        return "page_element"
    if value == "step":
        return "step"
    if value == "test":
        return "test"
    if value == "variant_set":
        return "variant_set"
    raise TypeError(
        f"{model_name}.{field_name} должен быть одним из: page, page_element, step, test, variant_set."
    )


def _require_preview_mode(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
) -> Literal["create", "merge"]:
    value = data.get(field_name)
    if value == "create":
        return "create"
    if value == "merge":
        return "merge"
    raise TypeError(f"{model_name}.{field_name} должен быть 'create' или 'merge'.")


def _require_python_mode(mode: str) -> None:
    if mode != "python":
        raise ValueError("Поддерживается только режим сериализации 'python'.")


@dataclass(slots=True)
class ReferenceOccurrence:
    file_path: str
    line: int
    column: int
    end_line: int
    end_column: int
    start_offset: int
    end_offset: int
    usage_kind: str
    context: str
    source_kind: Literal["python_file", "scenario_graph"] | None = None
    source_id: str | None = None
    source_label: str | None = None

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_mapping(raw, cls.__name__)
        return cls(
            file_path=_require_str(data, "file_path", cls.__name__),
            line=_require_int(data, "line", cls.__name__),
            column=_require_int(data, "column", cls.__name__),
            end_line=_require_int(data, "end_line", cls.__name__),
            end_column=_require_int(data, "end_column", cls.__name__),
            start_offset=_require_int(data, "start_offset", cls.__name__),
            end_offset=_require_int(data, "end_offset", cls.__name__),
            usage_kind=_require_str(data, "usage_kind", cls.__name__),
            context=_require_str(data, "context", cls.__name__),
            source_kind=_require_source_kind(data, "source_kind", cls.__name__),
            source_id=_require_optional_str(data, "source_id", cls.__name__),
            source_label=_require_optional_str(data, "source_label", cls.__name__),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "file_path": self.file_path,
            "line": self.line,
            "column": self.column,
            "end_line": self.end_line,
            "end_column": self.end_column,
            "start_offset": self.start_offset,
            "end_offset": self.end_offset,
            "usage_kind": self.usage_kind,
            "context": self.context,
            "source_kind": self.source_kind,
            "source_id": self.source_id,
            "source_label": self.source_label,
        }


@dataclass(slots=True)
class ReferenceSymbol:
    id: str
    kind: Literal["page", "page_element", "step", "test", "variant_set"]
    name: str
    qualified_name: str
    definition: ReferenceOccurrence
    parent_id: str | None = None
    node_id: str | None = None
    usages: list[ReferenceOccurrence] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.definition = ReferenceOccurrence.model_validate(self.definition)
        self.usages = [ReferenceOccurrence.model_validate(item) for item in self.usages]

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_mapping(raw, cls.__name__)
        raw_usages = data.get("usages", [])
        if not isinstance(raw_usages, list):
            raise TypeError(f"{cls.__name__}.usages должен быть списком.")
        return cls(
            id=_require_str(data, "id", cls.__name__),
            kind=_require_symbol_kind(data, "kind", cls.__name__),
            name=_require_str(data, "name", cls.__name__),
            qualified_name=_require_str(data, "qualified_name", cls.__name__),
            definition=ReferenceOccurrence.model_validate(data.get("definition")),
            parent_id=_require_optional_str(data, "parent_id", cls.__name__),
            node_id=_require_optional_str(data, "node_id", cls.__name__),
            usages=[ReferenceOccurrence.model_validate(item) for item in raw_usages],
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "id": self.id,
            "kind": self.kind,
            "name": self.name,
            "qualified_name": self.qualified_name,
            "parent_id": self.parent_id,
            "node_id": self.node_id,
            "definition": self.definition.model_dump(mode=mode),
            "usages": [item.model_dump(mode=mode) for item in self.usages],
        }


@dataclass(slots=True)
class ReferenceIndexResult:
    symbols: list[ReferenceSymbol] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.symbols = [ReferenceSymbol.model_validate(item) for item in self.symbols]
        self.warnings = _coerce_string_list(
            self.warnings, f"{self.__class__.__name__}.warnings"
        )

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_mapping(raw, cls.__name__)
        return cls(
            symbols=[
                ReferenceSymbol.model_validate(item)
                for item in _require_mapping_list(
                    data.get("symbols", []), f"{cls.__name__}.symbols"
                )
            ],
            warnings=_require_string_list(
                data.get("warnings", []), f"{cls.__name__}.warnings"
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "symbols": [symbol.model_dump(mode=mode) for symbol in self.symbols],
            "warnings": list(self.warnings),
        }


@dataclass(slots=True)
class RenameEdit:
    file_path: str
    line: int
    column: int
    end_line: int
    end_column: int
    start_offset: int
    end_offset: int
    old_text: str
    new_text: str
    usage_kind: str
    context: str

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_mapping(raw, cls.__name__)
        return cls(
            file_path=_require_str(data, "file_path", cls.__name__),
            line=_require_int(data, "line", cls.__name__),
            column=_require_int(data, "column", cls.__name__),
            end_line=_require_int(data, "end_line", cls.__name__),
            end_column=_require_int(data, "end_column", cls.__name__),
            start_offset=_require_int(data, "start_offset", cls.__name__),
            end_offset=_require_int(data, "end_offset", cls.__name__),
            old_text=_require_str(data, "old_text", cls.__name__),
            new_text=_require_str(data, "new_text", cls.__name__),
            usage_kind=_require_str(data, "usage_kind", cls.__name__),
            context=_require_str(data, "context", cls.__name__),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "file_path": self.file_path,
            "line": self.line,
            "column": self.column,
            "end_line": self.end_line,
            "end_column": self.end_column,
            "start_offset": self.start_offset,
            "end_offset": self.end_offset,
            "old_text": self.old_text,
            "new_text": self.new_text,
            "usage_kind": self.usage_kind,
            "context": self.context,
        }


@dataclass(slots=True)
class RenameConflict:
    file_path: str
    line: int
    column: int
    end_line: int
    end_column: int
    start_offset: int
    end_offset: int
    context: str
    message: str

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_mapping(raw, cls.__name__)
        return cls(
            file_path=_require_str(data, "file_path", cls.__name__),
            line=_require_int(data, "line", cls.__name__),
            column=_require_int(data, "column", cls.__name__),
            end_line=_require_int(data, "end_line", cls.__name__),
            end_column=_require_int(data, "end_column", cls.__name__),
            start_offset=_require_int(data, "start_offset", cls.__name__),
            end_offset=_require_int(data, "end_offset", cls.__name__),
            context=_require_str(data, "context", cls.__name__),
            message=_require_str(data, "message", cls.__name__),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "file_path": self.file_path,
            "line": self.line,
            "column": self.column,
            "end_line": self.end_line,
            "end_column": self.end_column,
            "start_offset": self.start_offset,
            "end_offset": self.end_offset,
            "context": self.context,
            "message": self.message,
        }


@dataclass(slots=True)
class RenameFileMove:
    source_path: str
    target_path: str

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_mapping(raw, cls.__name__)
        return cls(
            source_path=_require_str(data, "source_path", cls.__name__),
            target_path=_require_str(data, "target_path", cls.__name__),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "source_path": self.source_path,
            "target_path": self.target_path,
        }


@dataclass(slots=True)
class RenameImpact:
    occurrence_count: int = 0
    file_count: int = 0
    test_file_count: int = 0
    page_file_count: int = 0
    step_file_count: int = 0
    variant_file_count: int = 0
    graph_usage_count: int = 0
    graph_context_count: int = 0

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_mapping(raw, cls.__name__)
        return cls(
            occurrence_count=_require_int(data, "occurrence_count", cls.__name__),
            file_count=_require_int(data, "file_count", cls.__name__),
            test_file_count=_require_int(data, "test_file_count", cls.__name__),
            page_file_count=_require_int(data, "page_file_count", cls.__name__),
            step_file_count=_require_int(data, "step_file_count", cls.__name__),
            variant_file_count=_require_int(data, "variant_file_count", cls.__name__),
            graph_usage_count=_require_int(data, "graph_usage_count", cls.__name__),
            graph_context_count=_require_int(data, "graph_context_count", cls.__name__),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "occurrence_count": self.occurrence_count,
            "file_count": self.file_count,
            "test_file_count": self.test_file_count,
            "page_file_count": self.page_file_count,
            "step_file_count": self.step_file_count,
            "variant_file_count": self.variant_file_count,
            "graph_usage_count": self.graph_usage_count,
            "graph_context_count": self.graph_context_count,
        }


@dataclass(slots=True)
class SafeRenamePlan:
    symbol: ReferenceSymbol
    new_name: str
    edits: list[RenameEdit] = field(default_factory=list)
    file_moves: list[RenameFileMove] = field(default_factory=list)
    conflicts: list[RenameConflict] = field(default_factory=list)
    graph_usages: list[ReferenceOccurrence] = field(default_factory=list)
    impact: RenameImpact = field(default_factory=RenameImpact)
    blocked: bool = False
    applied_files: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.symbol = ReferenceSymbol.model_validate(self.symbol)
        self.edits = [RenameEdit.model_validate(item) for item in self.edits]
        self.file_moves = [
            RenameFileMove.model_validate(item) for item in self.file_moves
        ]
        self.conflicts = [
            RenameConflict.model_validate(item) for item in self.conflicts
        ]
        self.graph_usages = [
            ReferenceOccurrence.model_validate(item) for item in self.graph_usages
        ]
        self.impact = RenameImpact.model_validate(self.impact)
        self.applied_files = _coerce_string_list(
            self.applied_files,
            f"{self.__class__.__name__}.applied_files",
        )
        if not isinstance(self.blocked, bool):
            raise TypeError(
                f"{self.__class__.__name__}.blocked должен быть булевым значением."
            )

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_mapping(raw, cls.__name__)
        return cls(
            symbol=ReferenceSymbol.model_validate(data.get("symbol")),
            new_name=_require_str(data, "new_name", cls.__name__),
            edits=[
                RenameEdit.model_validate(item)
                for item in _require_mapping_list(
                    data.get("edits", []), f"{cls.__name__}.edits"
                )
            ],
            file_moves=[
                RenameFileMove.model_validate(item)
                for item in _require_mapping_list(
                    data.get("file_moves", []), f"{cls.__name__}.file_moves"
                )
            ],
            conflicts=[
                RenameConflict.model_validate(item)
                for item in _require_mapping_list(
                    data.get("conflicts", []), f"{cls.__name__}.conflicts"
                )
            ],
            graph_usages=[
                ReferenceOccurrence.model_validate(item)
                for item in _require_mapping_list(
                    data.get("graph_usages", []), f"{cls.__name__}.graph_usages"
                )
            ],
            impact=RenameImpact.model_validate(data.get("impact", {})),
            blocked=_require_bool_with_default(data, "blocked", cls.__name__, False),
            applied_files=_require_string_list(
                data.get("applied_files", []),
                f"{cls.__name__}.applied_files",
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "symbol": self.symbol.model_dump(mode=mode),
            "new_name": self.new_name,
            "edits": [item.model_dump(mode=mode) for item in self.edits],
            "file_moves": [item.model_dump(mode=mode) for item in self.file_moves],
            "conflicts": [item.model_dump(mode=mode) for item in self.conflicts],
            "graph_usages": [item.model_dump(mode=mode) for item in self.graph_usages],
            "impact": self.impact.model_dump(mode=mode),
            "blocked": self.blocked,
            "applied_files": list(self.applied_files),
        }


@dataclass(slots=True)
class GraphReferenceContext:
    context_id: str
    context_label: str
    nodes: list[JsonObject] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.nodes = _coerce_json_object_list(
            self.nodes, f"{self.__class__.__name__}.nodes"
        )

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_mapping(raw, cls.__name__)
        return cls(
            context_id=_require_str(data, "context_id", cls.__name__),
            context_label=_require_str(data, "context_label", cls.__name__),
            nodes=_require_json_object_list(
                data.get("nodes", []), f"{cls.__name__}.nodes"
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "context_id": self.context_id,
            "context_label": self.context_label,
            "nodes": [dict(node) for node in self.nodes],
        }


@dataclass(slots=True)
class ReferenceImpactEntry:
    symbol: ReferenceSymbol
    python_usages: list[ReferenceOccurrence] = field(default_factory=list)
    graph_usages: list[ReferenceOccurrence] = field(default_factory=list)
    total_usage_count: int = 0
    message: str | None = None

    def __post_init__(self) -> None:
        self.symbol = ReferenceSymbol.model_validate(self.symbol)
        self.python_usages = [
            ReferenceOccurrence.model_validate(item) for item in self.python_usages
        ]
        self.graph_usages = [
            ReferenceOccurrence.model_validate(item) for item in self.graph_usages
        ]
        if isinstance(self.total_usage_count, bool) or not isinstance(
            self.total_usage_count, int
        ):
            raise TypeError(
                f"{self.__class__.__name__}.total_usage_count должен быть целым числом."
            )
        if self.message is not None and not isinstance(self.message, str):
            raise TypeError(
                f"{self.__class__.__name__}.message должен быть строкой или null."
            )

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_mapping(raw, cls.__name__)
        return cls(
            symbol=ReferenceSymbol.model_validate(data.get("symbol")),
            python_usages=[
                ReferenceOccurrence.model_validate(item)
                for item in _require_mapping_list(
                    data.get("python_usages", []), f"{cls.__name__}.python_usages"
                )
            ],
            graph_usages=[
                ReferenceOccurrence.model_validate(item)
                for item in _require_mapping_list(
                    data.get("graph_usages", []), f"{cls.__name__}.graph_usages"
                )
            ],
            total_usage_count=_require_int(data, "total_usage_count", cls.__name__),
            message=_require_optional_str(data, "message", cls.__name__),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "symbol": self.symbol.model_dump(mode=mode),
            "python_usages": [
                item.model_dump(mode=mode) for item in self.python_usages
            ],
            "graph_usages": [item.model_dump(mode=mode) for item in self.graph_usages],
            "total_usage_count": self.total_usage_count,
            "message": self.message,
        }


@dataclass(slots=True)
class PageRegenerationImpactPreview:
    page_path: str
    page_name: str
    mode: Literal["create", "merge"]
    summary: str
    removed_symbols: list[ReferenceImpactEntry] = field(default_factory=list)
    added_elements: list[str] = field(default_factory=list)
    retained_element_count: int = 0

    def __post_init__(self) -> None:
        self.removed_symbols = [
            ReferenceImpactEntry.model_validate(item) for item in self.removed_symbols
        ]
        self.added_elements = _coerce_string_list(
            self.added_elements,
            f"{self.__class__.__name__}.added_elements",
        )
        if isinstance(self.retained_element_count, bool) or not isinstance(
            self.retained_element_count, int
        ):
            raise TypeError(
                f"{self.__class__.__name__}.retained_element_count должен быть целым числом."
            )

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_mapping(raw, cls.__name__)
        return cls(
            page_path=_require_str(data, "page_path", cls.__name__),
            page_name=_require_str(data, "page_name", cls.__name__),
            mode=_require_preview_mode(data, "mode", cls.__name__),
            summary=_require_str(data, "summary", cls.__name__),
            removed_symbols=[
                ReferenceImpactEntry.model_validate(item)
                for item in _require_mapping_list(
                    data.get("removed_symbols", []), f"{cls.__name__}.removed_symbols"
                )
            ],
            added_elements=_require_string_list(
                data.get("added_elements", []),
                f"{cls.__name__}.added_elements",
            ),
            retained_element_count=_require_int(
                data,
                "retained_element_count",
                cls.__name__,
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "page_path": self.page_path,
            "page_name": self.page_name,
            "mode": self.mode,
            "summary": self.summary,
            "removed_symbols": [
                item.model_dump(mode=mode) for item in self.removed_symbols
            ],
            "added_elements": list(self.added_elements),
            "retained_element_count": self.retained_element_count,
        }


def _require_mapping_list(raw: object, context: str) -> list[Mapping[str, object]]:
    if not isinstance(raw, list):
        raise TypeError(f"{context} должен быть списком объектов.")
    result: list[Mapping[str, object]] = []
    for item in raw:
        result.append(_require_mapping(item, context))
    return result
