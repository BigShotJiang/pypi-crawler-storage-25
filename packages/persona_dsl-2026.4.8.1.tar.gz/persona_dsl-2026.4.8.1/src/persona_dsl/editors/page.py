from __future__ import annotations

import importlib
from typing import Protocol, TypeAlias, TypeGuard

from .base import CodeEditor, CodeEditorValue

ElementDefinition: TypeAlias = dict[str, object]
RESERVED_ELEMENT_KEYS = frozenset({"var_name", "type", "children", "is_list"})


class ElementFieldInfo(Protocol):
    name: str
    init: bool


class DataclassElementClass(Protocol):
    __dataclass_fields__: dict[str, ElementFieldInfo]


def _is_dataclass_element_class(
    value: object,
) -> TypeGuard[type[DataclassElementClass]]:
    return isinstance(value, type) and isinstance(
        getattr(value, "__dataclass_fields__", None),
        dict,
    )


def _require_mapping_list(value: object, *, field_name: str) -> list[ElementDefinition]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise TypeError(f"{field_name} должен быть списком объектов.")
    definitions: list[ElementDefinition] = []
    for index, item in enumerate(value):
        if not isinstance(item, dict):
            raise TypeError(f"{field_name}[{index}] должен быть объектом.")
        definitions.append(dict(item))
    return definitions


def _optional_string(value: object, *, field_name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise TypeError(f"{field_name} должен быть строкой.")
    return value


def _required_non_empty_string(value: object, *, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise TypeError(f"{field_name} должен быть непустой строкой.")
    return value


def _to_code_editor_value(value: object, *, field_name: str) -> CodeEditorValue:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    raise TypeError(
        f"{field_name} должен быть примитивом, поддерживаемым генератором кода."
    )


class PageEditor:
    """
    Domain-specific редактор Page Objects поверх общего CodeEditor.
    """

    def __init__(self, code: str):
        self.editor = CodeEditor(code)

    @staticmethod
    def get_element_class(type_name: str) -> type[DataclassElementClass] | None:
        try:
            module = importlib.import_module("persona_dsl.pages.elements")
        except ModuleNotFoundError:
            return None
        element_class_candidate = getattr(module, type_name, None)
        if element_class_candidate is None:
            return None
        if not _is_dataclass_element_class(element_class_candidate):
            raise TypeError(
                f"persona_dsl.pages.elements.{type_name} должен быть dataclass-классом."
            )
        return element_class_candidate

    @staticmethod
    def get_class_name_for_role(role: str) -> str:
        """
        Возвращает имя класса для ARIA-роли.
        """
        from persona_dsl.pages.registry import ROLE_TO_CLASS

        element_class = ROLE_TO_CLASS.get(role)
        if element_class is None:
            return "Element"
        return element_class.__name__

    @staticmethod
    def resolve_element_class(type_name: str) -> type[DataclassElementClass] | None:
        return PageEditor.get_element_class(type_name)

    @staticmethod
    def should_pass_role(type_name: str) -> bool:
        element_class = PageEditor.resolve_element_class(type_name)
        if element_class is None:
            return True
        for field_info in element_class.__dataclass_fields__.values():
            if field_info.name == "role":
                return field_info.init
        return True

    @staticmethod
    def _get_allowed_fields(
        type_name: str,
        el_def: ElementDefinition,
    ) -> list[str]:
        """
        Возвращает имена полей конструктора.

        Для известных dataclass-элементов берётся точный init-контракт.
        Для кастомных типов используется явный непротиворечивый контракт:
        только примитивные kwargs из входного определения, кроме служебных ключей.
        """
        element_class = PageEditor.resolve_element_class(type_name)
        if element_class is not None:
            return [
                field_info.name
                for field_info in element_class.__dataclass_fields__.values()
                if field_info.init
            ]
        return [key for key in el_def if key not in RESERVED_ELEMENT_KEYS]

    @staticmethod
    def _element_type_name(el_def: ElementDefinition) -> str:
        raw_type_name = el_def.get("type", "Element")
        return _required_non_empty_string(raw_type_name, field_name="type")

    @staticmethod
    def normalize_element_args(
        el_def: ElementDefinition,
        type_name: str,
        include_none: bool = False,
    ) -> dict[str, CodeEditorValue]:
        """
        Собирает kwargs для элемента по строгому контракту конструктора.
        """
        allowed_fields = PageEditor._get_allowed_fields(type_name, el_def)
        candidates = dict(el_def)

        if "var_name" in candidates and "name" not in candidates:
            candidates["name"] = candidates["var_name"]

        mapping: dict[str, CodeEditorValue] = {}
        for key in allowed_fields:
            if key in candidates:
                mapping[key] = _to_code_editor_value(
                    candidates[key],
                    field_name=key,
                )

        should_pass = PageEditor.should_pass_role(type_name)
        if "role" in mapping and not should_pass:
            del mapping["role"]
        elif "role" in candidates and should_pass:
            mapping["role"] = _to_code_editor_value(
                candidates["role"],
                field_name="role",
            )

        if include_none:
            return mapping
        return {
            key: value
            for key, value in mapping.items()
            if value is not None and value != ""
        }

    def get_code(self) -> str:
        return self.editor.get_code()

    def update_class_attributes(self, class_name: str, attrs: dict[str, str]) -> None:
        self.editor.update_class_attributes(class_name, attrs)

    def sync_elements(
        self,
        class_name: str,
        elements: list[ElementDefinition],
    ) -> PageEditor:
        """
        Синхронизирует присваивания элементов внутри `__init__`.
        """
        element_map: dict[str, ElementDefinition] = {}
        ordered_lhs: list[str] = []

        def flatten(definitions: list[ElementDefinition], parent_lhs: str) -> None:
            for index, element_definition in enumerate(definitions):
                var_name = _optional_string(
                    element_definition.get("var_name"),
                    field_name=f"{parent_lhs}[{index}].var_name",
                )
                if var_name is None or not var_name.strip():
                    raise TypeError(
                        f"{parent_lhs}[{index}].var_name должен быть непустой строкой."
                    )
                lhs = f"{parent_lhs}.{var_name}"
                element_map[lhs] = element_definition
                ordered_lhs.append(lhs)
                flatten(
                    _require_mapping_list(
                        element_definition.get("children"),
                        field_name=f"{lhs}.children",
                    ),
                    lhs,
                )

        flatten(elements, "self")

        for lhs in ordered_lhs:
            self._upsert_element(class_name, "__init__", lhs, element_map[lhs])

        allowed_lhs = set(element_map)
        self.editor.remove_assignments_not_in(
            class_name,
            "__init__",
            allowed_lhs,
            {"add_element", "add_element_list"},
        )
        return self

    def _upsert_element(
        self,
        class_name: str,
        method_name: str,
        lhs: str,
        el_def: ElementDefinition,
    ) -> None:
        type_name = self._element_type_name(el_def)
        kwargs = self.normalize_element_args(el_def, type_name, include_none=True)

        if not self.should_pass_role(type_name):
            kwargs["role"] = None

        if not kwargs.get("name"):
            kwargs["name"] = _required_non_empty_string(
                el_def.get("var_name"),
                field_name=f"{lhs}.var_name",
            )

        wrapper = "add_element"
        wrapper_kwargs: dict[str, CodeEditorValue] | None = None

        if bool(el_def.get("is_list")):
            wrapper = "add_element_list"
            wrapper_kwargs = {"alias": lhs.split(".")[-1]}

        self.editor.upsert_complex_call(
            class_name=class_name,
            method_name=method_name,
            target_lhs=lhs,
            inner_func=type_name,
            inner_kwargs=kwargs,
            wrapper_attr=wrapper,
            wrapper_kwargs=wrapper_kwargs,
        )
