from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import TypeAlias
import re

import black
import libcst as cst

AssignmentTransformResult: TypeAlias = (
    cst.BaseSmallStatement | cst.RemovalSentinel | None
)
AssignmentTransformerFunc: TypeAlias = Callable[
    [cst.Assign, str], AssignmentTransformResult
]
CodeEditorValue: TypeAlias = str | int | float | bool | None


class CodeEditor:
    """
    A unified utility for performing non-destructive code modifications using LibCST.
    """

    def __init__(self, code: str):
        self.module = cst.parse_module(code)

    def get_code(self, use_black: bool = True) -> str:
        code = self.module.code
        if use_black:
            return black.format_str(code, mode=black.Mode())
        return code

    def update_class_attributes(
        self, class_name: str, attributes: dict[str, str]
    ) -> "CodeEditor":
        """
        Updates or adds class-level string attributes (e.g. url = "...")
        """

        class AttributeUpdater(cst.CSTTransformer):
            def __init__(self, target_class: str, attrs: dict[str, str]):
                self.target_class = target_class
                self.attrs = attrs
                self.found_class = False
                self.handled_attrs: set[str] = set()

            def visit_ClassDef(self, node: cst.ClassDef) -> bool | None:
                if node.name.value == self.target_class:
                    self.found_class = True
                    return True
                return False

            def leave_ClassDef(
                self, original_node: cst.ClassDef, updated_node: cst.ClassDef
            ) -> cst.BaseStatement:
                if not self.found_class:
                    return updated_node

                new_body_stmts: list[cst.BaseStatement] = []
                # 1. Update existing
                current_body = CodeEditor._collect_base_statements(
                    updated_node.body.body
                )
                for stmt in current_body:
                    if isinstance(stmt, cst.SimpleStatementLine):
                        if isinstance(stmt.body[0], cst.Assign):
                            assign: cst.Assign = stmt.body[0]
                            replaced = False
                            for target in assign.targets:
                                if (
                                    isinstance(target.target, cst.Name)
                                    and target.target.value in self.attrs
                                ):
                                    attr_name = target.target.value
                                    new_val = self.attrs[attr_name]
                                    self.handled_attrs.add(attr_name)
                                    new_assign = assign.with_changes(
                                        value=cst.SimpleString(f'"{new_val}"')
                                    )
                                    new_body_stmts.append(
                                        stmt.with_changes(body=[new_assign])
                                    )
                                    replaced = True
                                    break
                            if replaced:
                                continue
                    new_body_stmts.append(stmt)

                # 2. Insert missing
                to_insert: list[cst.SimpleStatementLine] = []
                for attr, val in self.attrs.items():
                    if attr not in self.handled_attrs and val:
                        assign_stmt = cst.SimpleStatementLine(
                            body=[
                                cst.Assign(
                                    targets=[cst.AssignTarget(target=cst.Name(attr))],
                                    value=cst.SimpleString(f'"{val}"'),
                                )
                            ]
                        )
                        to_insert.append(assign_stmt)

                if to_insert:
                    insert_idx = 0
                    if (
                        new_body_stmts
                        and isinstance(new_body_stmts[0], cst.SimpleStatementLine)
                        and isinstance(new_body_stmts[0].body[0], cst.Expr)
                        and isinstance(
                            new_body_stmts[0].body[0].value, cst.SimpleString
                        )
                    ):
                        insert_idx = 1

                    for item in reversed(to_insert):
                        new_body_stmts.insert(insert_idx, item)

                self.found_class = False
                return updated_node.with_changes(
                    body=cst.IndentedBlock(body=new_body_stmts)
                )

        transformer = AttributeUpdater(class_name, attributes)
        self.module = self.module.visit(transformer)
        return self

    def replace_method(
        self, class_name: str, method_node: cst.FunctionDef
    ) -> "CodeEditor":
        """
        Replaces a method in a class with a new CST definition.
        If the method doesn't exist, it appends it (after __init__ or at start).
        """

        class MethodReplacer(cst.CSTTransformer):
            def __init__(self, target_class: str, new_method: cst.FunctionDef):
                self.target_class = target_class
                self.new_method = new_method
                self.found_class = False

            def leave_ClassDef(
                self, original_node: cst.ClassDef, updated_node: cst.ClassDef
            ) -> cst.BaseStatement:
                if original_node.name.value == self.target_class:
                    self.found_class = True
                    target_name = self.new_method.name.value

                    new_body_stmts: list[cst.BaseStatement] = []
                    replaced = False

                    current_body = CodeEditor._collect_base_statements(
                        updated_node.body.body
                    )
                    for stmt in current_body:
                        if (
                            isinstance(stmt, cst.FunctionDef)
                            and stmt.name.value == target_name
                        ):
                            new_body_stmts.append(self.new_method)
                            replaced = True
                        else:
                            new_body_stmts.append(stmt)

                    if not replaced:
                        # Insert strategy:
                        # If __init__ exists, insert after it?
                        # Or just at the top?
                        # Let's insert at the top (after docstring) for simplicity, or strict append?
                        # Generator usually puts __init__ first.
                        # If replacing __init__, we handled it.
                        # If adding new method, maybe append?

                        # Logic: if __init__ is the target, we likely inserted it.
                        # If it's a random method, append to end.
                        if target_name == "__init__":
                            idx = 0
                            if (
                                new_body_stmts
                                and isinstance(
                                    new_body_stmts[0], cst.SimpleStatementLine
                                )
                                and isinstance(new_body_stmts[0].body[0], cst.Expr)
                                and isinstance(
                                    new_body_stmts[0].body[0].value, cst.SimpleString
                                )
                            ):
                                idx = 1
                            new_body_stmts.insert(idx, self.new_method)
                        else:
                            new_body_stmts.append(self.new_method)

                    return updated_node.with_changes(
                        body=cst.IndentedBlock(body=new_body_stmts)
                    )
                return updated_node

        transformer = MethodReplacer(class_name, method_node)
        self.module = self.module.visit(transformer)
        return self

    def update_class_docstring(self, class_name: str, docstring: str) -> "CodeEditor":
        """
        Updates or adds a docstring to the specified class.
        """

        class DocstringUpdater(cst.CSTTransformer):
            def __init__(self, target_class: str, new_doc: str):
                self.target_class = target_class
                self.new_doc = new_doc
                self.found_class = False

            def leave_ClassDef(
                self, original_node: cst.ClassDef, updated_node: cst.ClassDef
            ) -> cst.BaseStatement:
                if original_node.name.value == self.target_class:
                    self.found_class = True
                    # Create docstring statement
                    doc_stmt = cst.SimpleStatementLine(
                        [cst.Expr(value=cst.SimpleString(repr(self.new_doc)))]
                    )

                    new_body = CodeEditor._collect_base_statements(
                        updated_node.body.body
                    )

                    # Check if first statement is a docstring
                    if (
                        new_body
                        and isinstance(new_body[0], cst.SimpleStatementLine)
                        and new_body[0].body
                        and isinstance(new_body[0].body[0], cst.Expr)
                        and isinstance(new_body[0].body[0].value, cst.SimpleString)
                    ):
                        new_body[0] = doc_stmt
                    else:
                        new_body.insert(0, doc_stmt)

                    return updated_node.with_changes(
                        body=cst.IndentedBlock(body=new_body)
                    )
                return updated_node

        transformer = DocstringUpdater(class_name, docstring)
        self.module = self.module.visit(transformer)
        return self

    def merge_init_from_other_code(
        self, source_code: str, class_name: str
    ) -> "CodeEditor":
        """
        Extracts __init__ method and imports from source_code and applies them to the current module.
        """
        other_module = cst.parse_module(source_code)

        # 1. Extract new __init__ and imports
        class NewCodeExtractor(cst.CSTVisitor):
            def __init__(self, target_class: str):
                self.target_class = target_class
                self.found_init: cst.FunctionDef | None = None
                self.collected_imports: list[cst.Import | cst.ImportFrom] = []

            def visit_ClassDef(self, node: cst.ClassDef) -> bool | None:
                if node.name.value == self.target_class:
                    for body_item in node.body.body:
                        if (
                            isinstance(body_item, cst.FunctionDef)
                            and body_item.name.value == "__init__"
                        ):
                            self.found_init = body_item
                    return False
                return False

            def visit_Import(self, node: cst.Import) -> None:
                self.collected_imports.append(node)

            def visit_ImportFrom(self, node: cst.ImportFrom) -> None:
                self.collected_imports.append(node)

        extractor = NewCodeExtractor(class_name)
        other_module.visit(extractor)

        if not extractor.found_init:
            return self

        # 2. Add imports
        # Convert imports back to strings for add_imports which handles deduplication
        import_strings: list[str] = []
        for imp in extractor.collected_imports:
            import_strings.append(
                cst.Module(body=[cst.SimpleStatementLine(body=[imp])]).code.strip()
            )

        self.add_imports(import_strings)

        # 3. Replace __init__
        self.replace_method(class_name, extractor.found_init)

        return self

    def merge_all_classes_from_other_code(self, source_code: str) -> "CodeEditor":
        """
        Merges ALL classes from source_code into the current module.
        - If class exists:
          - procedural classes update `__init__`;
          - declarative classes replace generated attrs/classes and preserve existing
            docstring + custom methods/classes that are absent in the new version.
        - If class is new: appends it to the module.
        - Merges imports.
        """
        other_module = cst.parse_module(source_code)

        def is_docstring_statement(stmt: cst.BaseStatement) -> bool:
            return (
                isinstance(stmt, cst.SimpleStatementLine)
                and len(stmt.body) == 1
                and isinstance(stmt.body[0], cst.Expr)
                and isinstance(stmt.body[0].value, cst.SimpleString)
            )

        def statement_key(
            stmt: cst.BaseStatement,
        ) -> tuple[str, str] | None:
            if isinstance(stmt, cst.FunctionDef):
                return ("function", stmt.name.value)
            if isinstance(stmt, cst.ClassDef):
                return ("class", stmt.name.value)
            if isinstance(stmt, cst.SimpleStatementLine) and len(stmt.body) == 1:
                small_stmt = stmt.body[0]
                if (
                    isinstance(small_stmt, cst.Assign)
                    and len(small_stmt.targets) == 1
                    and isinstance(small_stmt.targets[0].target, cst.Name)
                ):
                    return ("assign", small_stmt.targets[0].target.value)
                if isinstance(small_stmt, cst.AnnAssign) and isinstance(
                    small_stmt.target, cst.Name
                ):
                    return ("assign", small_stmt.target.value)
            return None

        def normalize_generated_wrapper_name(class_name: str) -> str:
            suffixes = (
                "RowElements",
                "Details",
                "Filters",
                "Component",
                "Popup",
                "Field",
                "Table",
                "Row",
            )
            for suffix in suffixes:
                if class_name.endswith(suffix):
                    prefix = class_name[: -len(suffix)]
                    normalized_prefix = re.sub(r"\d+$", "", prefix)
                    return f"{normalized_prefix}{suffix}"
            return re.sub(r"\d+$", "", class_name)

        def is_generated_wrapper_like(stmt: cst.ClassDef) -> bool:
            body = CodeEditor._collect_base_statements(stmt.body.body)
            non_doc_body = [
                body_stmt for body_stmt in body if not is_docstring_statement(body_stmt)
            ]
            if not non_doc_body:
                return False

            for body_stmt in non_doc_body:
                if isinstance(body_stmt, cst.Pass):
                    continue
                if isinstance(body_stmt, cst.ClassDef):
                    continue
                if isinstance(body_stmt, cst.FunctionDef):
                    return False
                if isinstance(body_stmt, cst.SimpleStatementLine):
                    if len(body_stmt.body) != 1:
                        return False
                    small_stmt = body_stmt.body[0]
                    if isinstance(small_stmt, (cst.Assign, cst.AnnAssign, cst.Pass)):
                        continue
                return False
            return True

        # 1. Collect all classes and imports from source
        class MultiClassExtractor(cst.CSTVisitor):
            def __init__(self) -> None:
                self.classes: dict[str, cst.ClassDef] = {}
                self.imports: list[str] = []

            def visit_ClassDef(self, node: cst.ClassDef) -> bool | None:
                self.classes[node.name.value] = node
                return False  # Don't recurse into nested classes

            def visit_Import(self, node: cst.Import) -> bool | None:
                self.imports.append(
                    cst.Module(body=[cst.SimpleStatementLine(body=[node])]).code.strip()
                )
                return False

            def visit_ImportFrom(self, node: cst.ImportFrom) -> bool | None:
                self.imports.append(
                    cst.Module(body=[cst.SimpleStatementLine(body=[node])]).code.strip()
                )
                return False

        extractor = MultiClassExtractor()
        other_module.visit(extractor)
        source_class_order = list(extractor.classes.keys())

        # 2. Add imports
        self.add_imports(extractor.imports)

        # 3. Process Classes
        for cls_name, cls_node in extractor.classes.items():
            # Check existence freshly
            exists = False
            for stmt in self.module.body:
                if isinstance(stmt, cst.ClassDef) and stmt.name.value == cls_name:
                    exists = True
                    break

            if exists:
                new_init: cst.FunctionDef | None = None
                for body_item in cls_node.body.body:
                    if (
                        isinstance(body_item, cst.FunctionDef)
                        and body_item.name.value == "__init__"
                    ):
                        new_init = body_item
                        break
                if new_init is not None:
                    self.replace_method(cls_name, new_init)
                    continue

                class DeclarativeClassMerger(cst.CSTTransformer):
                    def __init__(self, target_class: str, new_class: cst.ClassDef):
                        self.target_class = target_class
                        self.new_class = new_class

                    def leave_ClassDef(
                        self,
                        original_node: cst.ClassDef,
                        updated_node: cst.ClassDef,
                    ) -> cst.BaseStatement:
                        if original_node.name.value != self.target_class:
                            return updated_node

                        existing_body = CodeEditor._collect_base_statements(
                            updated_node.body.body
                        )
                        new_body = CodeEditor._collect_base_statements(
                            self.new_class.body.body
                        )

                        existing_doc = (
                            existing_body[0]
                            if existing_body
                            and is_docstring_statement(existing_body[0])
                            else None
                        )
                        new_doc = (
                            new_body[0]
                            if new_body and is_docstring_statement(new_body[0])
                            else None
                        )

                        merged_body: list[cst.BaseStatement] = []
                        if existing_doc is not None:
                            merged_body.append(existing_doc)
                        elif new_doc is not None:
                            merged_body.append(new_doc)

                        new_non_doc = [
                            stmt
                            for stmt in new_body
                            if not is_docstring_statement(stmt)
                        ]
                        merged_body.extend(new_non_doc)

                        new_keys = {
                            key
                            for stmt in new_non_doc
                            if (key := statement_key(stmt)) is not None
                        }

                        existing_non_doc = [
                            stmt
                            for stmt in existing_body
                            if not is_docstring_statement(stmt)
                        ]
                        for stmt in existing_non_doc:
                            key = statement_key(stmt)
                            if key is None or key in new_keys:
                                continue
                            if (
                                isinstance(stmt, cst.FunctionDef)
                                and stmt.name.value == "__init__"
                            ):
                                continue
                            if isinstance(stmt, (cst.FunctionDef, cst.ClassDef)):
                                merged_body.append(stmt)

                        return self.new_class.with_changes(
                            body=cst.IndentedBlock(body=merged_body)
                        )

                self.module = self.module.visit(
                    DeclarativeClassMerger(cls_name, cls_node)
                )
            else:
                new_body = list(self.module.body)
                insert_index = len(new_body)
                for next_class_name in source_class_order[
                    source_class_order.index(cls_name) + 1 :
                ]:
                    for body_index, stmt in enumerate(new_body):
                        if (
                            isinstance(stmt, cst.ClassDef)
                            and stmt.name.value == next_class_name
                        ):
                            insert_index = body_index
                            break
                    if insert_index != len(new_body):
                        break

                new_body.insert(insert_index, cls_node)
                self.module = self.module.with_changes(body=new_body)

        source_class_names = set(extractor.classes.keys())
        canonical_generated_names = {
            normalize_generated_wrapper_name(class_name)
            for class_name in source_class_names
        }
        pruned_body: list[cst.CSTNode] = []
        for stmt in self.module.body:
            if not isinstance(stmt, cst.ClassDef):
                pruned_body.append(stmt)
                continue

            class_name = stmt.name.value
            if class_name in source_class_names:
                pruned_body.append(stmt)
                continue

            normalized_name = normalize_generated_wrapper_name(class_name)
            if (
                normalized_name in canonical_generated_names
                and normalized_name != class_name
                and is_generated_wrapper_like(stmt)
            ):
                continue

            pruned_body.append(stmt)

        self.module = self.module.with_changes(body=pruned_body)

        return self

    def add_imports(self, imports: list[str]) -> "CodeEditor":
        """
        Adds import statements if they are not already present.
        Input strings should be full statements like "from foo import bar".
        """
        existing_imports: list[str] = []
        non_import_body: list[cst.CSTNode] = []
        for stmt in self.module.body:
            if isinstance(stmt, cst.SimpleStatementLine) and isinstance(
                stmt.body[0], (cst.Import, cst.ImportFrom)
            ):
                existing_imports.append(cst.Module(body=[stmt]).code.strip())
            else:
                non_import_body.append(stmt)

        merged_imports = self._merge_import_strings(existing_imports + imports)
        if not merged_imports:
            return self

        merged_nodes: list[cst.CSTNode] = []
        for imp_str in merged_imports:
            mod = cst.parse_module(imp_str)
            if mod.body:
                merged_nodes.append(mod.body[0])

        if not merged_nodes:
            return self

        new_body = list(non_import_body)
        insert_pos = 0
        if (
            new_body
            and isinstance(new_body[0], cst.SimpleStatementLine)
            and new_body[0].body
            and isinstance(new_body[0].body[0], cst.Expr)
            and isinstance(new_body[0].body[0].value, cst.SimpleString)
        ):
            insert_pos = 1

        for item in reversed(merged_nodes):
            new_body.insert(insert_pos, item)

        self.module = self.module.with_changes(body=new_body)

        return self

    @staticmethod
    def _render_import_alias(alias: cst.ImportAlias, helper_module: cst.Module) -> str:
        name = helper_module.code_for_node(alias.name).strip()
        if not name:
            raise ValueError("Не удалось определить имя import-alias.")
        if alias.asname is None:
            return name
        as_name = helper_module.code_for_node(alias.asname.name).strip()
        if not as_name:
            raise ValueError("Не удалось определить as-имя import-alias.")
        return f"{name} as {as_name}"

    @staticmethod
    def _merge_import_strings(imports: list[str]) -> list[str]:
        helper_module = cst.Module(body=[])
        merged_imports: dict[str, None] = {}
        future_from_imports: dict[str, None] = {}
        merged_from_imports: dict[str, dict[str, None]] = {}
        passthrough_imports: dict[str, None] = {}

        for import_stmt in imports:
            stripped = import_stmt.strip()
            if not stripped:
                continue

            try:
                parsed_module = cst.parse_module(stripped)
            except cst.ParserSyntaxError as exc:
                raise ValueError(
                    f"Некорректный import для CodeEditor.add_imports: {stripped!r}"
                ) from exc

            if len(parsed_module.body) != 1:
                raise ValueError(
                    "CodeEditor.add_imports поддерживает только одиночные import-операторы."
                )

            stmt = parsed_module.body[0]
            if not (isinstance(stmt, cst.SimpleStatementLine) and len(stmt.body) == 1):
                raise ValueError(
                    "CodeEditor.add_imports поддерживает только простые import-операторы."
                )

            small_stmt = stmt.body[0]
            if isinstance(small_stmt, cst.Import):
                for alias in small_stmt.names:
                    alias_code = CodeEditor._render_import_alias(alias, helper_module)
                    merged_imports[alias_code] = None
                continue

            if isinstance(small_stmt, cst.ImportFrom):
                if isinstance(small_stmt.names, cst.ImportStar):
                    passthrough_imports[stripped] = None
                    continue

                module_name = ""
                if small_stmt.relative:
                    module_name += "." * len(small_stmt.relative)
                if small_stmt.module is not None:
                    module_name += helper_module.code_for_node(
                        small_stmt.module
                    ).strip()

                if not module_name:
                    raise ValueError(
                        f"Не удалось определить модуль для import {stripped!r}"
                    )

                target_bucket = (
                    future_from_imports
                    if module_name == "__future__"
                    else merged_from_imports.setdefault(module_name, {})
                )

                for alias in small_stmt.names:
                    alias_code = CodeEditor._render_import_alias(alias, helper_module)
                    target_bucket[alias_code] = None
                continue

            passthrough_imports[stripped] = None

        result: list[str] = []
        if future_from_imports:
            result.append(
                f"from __future__ import {', '.join(future_from_imports.keys())}"
            )
        if merged_imports:
            result.append(f"import {', '.join(merged_imports.keys())}")
        for module_name, names in merged_from_imports.items():
            result.append(f"from {module_name} import {', '.join(names.keys())}")
        result.extend(passthrough_imports.keys())
        return result

    def transform_assignments(
        self,
        class_name: str,
        method_name: str,
        transformer_func: AssignmentTransformerFunc,
    ) -> "CodeEditor":
        """
        Visits assignments in a specified method and applies a transformation function.
        The transformer_func receives (assignment_node, lhs_full_name) and returns:
        - cst.BaseStatement (modified node)
        - cst.RemoveFromParent() (to delete)
        - None (to keep original)
        """

        class AssignmentTransformer(cst.CSTTransformer):
            def __init__(
                self,
                target_class: str,
                target_method: str,
                func: AssignmentTransformerFunc,
            ):
                self.target_class = target_class
                self.target_method = target_method
                self.func = func
                self.found_class = False
                self.in_method = False

            def visit_ClassDef(self, node: cst.ClassDef) -> bool | None:
                if node.name.value == self.target_class:
                    self.found_class = True
                    return True
                return False

            def visit_FunctionDef(self, node: cst.FunctionDef) -> bool | None:
                if self.found_class and node.name.value == self.target_method:
                    self.in_method = True
                    return True
                return False

            def leave_FunctionDef(
                self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
            ) -> cst.BaseStatement:
                if self.in_method:
                    self.in_method = False
                return updated_node

            def leave_Assign(
                self, original_node: cst.Assign, updated_node: cst.Assign
            ) -> cst.BaseSmallStatement | cst.RemovalSentinel:
                if not self.in_method:
                    return updated_node

                # Extract LHS string (e.g. "self.foo.bar")
                # Assume single target
                if not updated_node.targets:
                    return updated_node

                target = updated_node.targets[0].target
                lhs_str = self._get_full_name(target)

                # Apply transformation
                if lhs_str:
                    result = self.func(updated_node, lhs_str)
                    if result is None:
                        return updated_node
                    return result

                return updated_node

            def _get_full_name(self, node: cst.BaseExpression) -> str | None:
                if isinstance(node, cst.Name):
                    return node.value
                if isinstance(node, cst.Attribute):
                    base = self._get_full_name(node.value)
                    if base:
                        return f"{base}.{node.attr.value}"
                return None

        transformer = AssignmentTransformer(class_name, method_name, transformer_func)
        self.module = self.module.visit(transformer)
        return self

    def insert_statements_to_method(
        self, class_name: str, method_name: str, statements: list[cst.BaseStatement]
    ) -> "CodeEditor":
        """
        Appends statements to the end of a method.
        """

        class StatementInserter(cst.CSTTransformer):
            def __init__(
                self,
                target_class: str,
                target_method: str,
                stmts: list[cst.BaseStatement],
            ):
                self.target_class = target_class
                self.target_method = target_method
                self.stmts = stmts
                self.found_class = False

            def visit_ClassDef(self, node: cst.ClassDef) -> bool | None:
                if node.name.value == self.target_class:
                    self.found_class = True
                    return True
                return False

            def leave_FunctionDef(
                self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
            ) -> cst.BaseStatement:
                if self.found_class and original_node.name.value == self.target_method:
                    new_body = CodeEditor._collect_base_statements(
                        updated_node.body.body
                    )
                    new_body.extend(self.stmts)
                    self.found_class = False  # Stop processing
                    return updated_node.with_changes(
                        body=cst.IndentedBlock(body=new_body)
                    )
                return updated_node

        transformer = StatementInserter(class_name, method_name, statements)
        self.module = self.module.visit(transformer)
        return self

    def insert_statements_to_function(
        self, func_name: str, statements: list[cst.BaseStatement]
    ) -> "CodeEditor":
        """
        Appends statements to the end of a top-level function.
        """

        class FunctionInserter(cst.CSTTransformer):
            def __init__(self, target_func: str, stmts: list[cst.BaseStatement]):
                self.target_func = target_func
                self.stmts = stmts

            def leave_FunctionDef(
                self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
            ) -> cst.BaseStatement:
                # Check if it's top-level (no class parent check needed in visit)
                # But we need to ensure we don't accidentally match methods with same name if we only want top-level?
                # For now, let's assume unique names or strictly top-level?
                # LibCST traversal visits everything.
                # To restrict to top-level, we could check if we are inside a ClassDef.
                # But typically test functions are unique in a file.

                if original_node.name.value == self.target_func:
                    new_body = CodeEditor._collect_base_statements(
                        updated_node.body.body
                    )

                    # Remove 'pass' if it's the only statement and we are adding stuff
                    if (
                        len(new_body) == 1
                        and isinstance(new_body[0], cst.SimpleStatementLine)
                        and isinstance(new_body[0].body[0], cst.Pass)
                    ):
                        new_body = []

                    new_body.extend(self.stmts)
                    return updated_node.with_changes(
                        body=cst.IndentedBlock(body=new_body)
                    )
                return updated_node

        transformer = FunctionInserter(func_name, statements)
        self.module = self.module.visit(transformer)
        return self

    @staticmethod
    def update_call_args(
        call_node: cst.Call, updates: dict[str, CodeEditorValue]
    ) -> cst.Call:
        """
        Updates keyword arguments of a Call node.
        - updates: keys are kwarg names.
          Values:
            - string: update/add (wrapped in quotes if not int-like?)
            - int: Integer
            - bool: Name("True"/"False")
            - None/Empty: remove.
        """
        new_args: list[cst.Arg] = []
        processed_args: set[str] = set()

        def to_cst_value(val: CodeEditorValue) -> cst.BaseExpression:
            if isinstance(val, bool):
                return cst.Name("True" if val else "False")
            if isinstance(val, int):
                return cst.Integer(str(val))
            if isinstance(val, float):
                return cst.Float(str(val))
            if isinstance(val, str):
                if val.isdigit():
                    return cst.Integer(val)
                return cst.SimpleString(f'"{val}"')
            if val is None:
                return cst.Name("None")
            raise ValueError(f"Неподдерживаемое значение аргумента вызова: {val!r}")

        # Update existing
        for arg in call_node.args:
            if isinstance(arg.keyword, cst.Name):
                kw = arg.keyword.value
                if kw in updates:
                    val = updates[kw]
                    processed_args.add(kw)
                    # Logic: if val is None -> remove.
                    # if val is "" -> remove? (Previous logic: val != "")
                    if val is not None and val != "":
                        new_args.append(arg.with_changes(value=to_cst_value(val)))
                else:
                    new_args.append(arg)
            else:
                new_args.append(arg)

        # Add new
        for kw, val in updates.items():
            if kw not in processed_args and val is not None and val != "":
                node_val = to_cst_value(val)
                new_args.append(
                    cst.Arg(
                        keyword=cst.Name(kw),
                        value=node_val,
                        equal=cst.AssignEqual(
                            whitespace_before=cst.SimpleWhitespace(""),
                            whitespace_after=cst.SimpleWhitespace(""),
                        ),
                    )
                )

        return call_node.with_changes(args=new_args)

    def upsert_complex_call(
        self,
        class_name: str,
        method_name: str,
        target_lhs: str,
        inner_func: str,
        inner_kwargs: dict[str, CodeEditorValue],
        wrapper_attr: str | None = None,
        wrapper_kwargs: dict[str, CodeEditorValue] | None = None,
    ) -> "CodeEditor":
        """
        Updates or Creates an assignment: target_lhs = wrapper_attr(inner_func(**kwargs))
        Wrapper is optional. If None, target_lhs = inner_func(**kwargs).
        """

        class AssignmentUpserter(cst.CSTTransformer):
            def __init__(self, parent: CodeEditor):
                self.parent = parent
                self.found = False
                self.in_correct_scope = False

            def visit_ClassDef(self, node: cst.ClassDef) -> bool | None:
                return node.name.value == class_name

            def visit_FunctionDef(self, node: cst.FunctionDef) -> bool | None:
                if node.name.value == method_name:
                    self.in_correct_scope = True
                    return True
                return False

            def leave_FunctionDef(
                self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
            ) -> cst.BaseStatement:
                self.in_correct_scope = False
                return updated_node

            def leave_Assign(
                self, original_node: cst.Assign, updated_node: cst.Assign
            ) -> cst.BaseSmallStatement:
                if not self.in_correct_scope:
                    return updated_node

                # Check LHS
                match = False
                for t in original_node.targets:
                    if self.parent._get_full_name(t.target) == target_lhs:
                        match = True
                        break

                if match:
                    self.found = True
                    # Update Value
                    new_val = self.parent._build_updated_value(
                        original_node.value,
                        target_lhs,  # Pass LHS
                        inner_func,
                        inner_kwargs,
                        wrapper_attr,
                        wrapper_kwargs,
                    )
                    return updated_node.with_changes(value=new_val)

                return updated_node

        upserter = AssignmentUpserter(self)
        self.module = self.module.visit(upserter)

        if not upserter.found:
            # Create new
            val_node = self._build_updated_value(
                None, target_lhs, inner_func, inner_kwargs, wrapper_attr, wrapper_kwargs
            )
            stmt = cst.SimpleStatementLine(
                body=[
                    cst.Assign(
                        targets=[
                            cst.AssignTarget(
                                target=self._parse_assign_target(target_lhs)
                            )
                        ],
                        value=val_node,
                    )
                ]
            )
            self.insert_statements_to_method(class_name, method_name, [stmt])

        return self

    def remove_assignments_not_in(
        self,
        class_name: str,
        method_name: str,
        allowed_lhs: set[str],
        wrapper_whitelist: set[str],
    ) -> "CodeEditor":
        """
        Removes assignments in the method where the value is a call to one of `wrapper_whitelist` attributes,
        BUT the LHS is NOT in `allowed_lhs`.
        Used to clean up deleted elements.
        """

        class Cleanup(cst.CSTTransformer):
            def __init__(self, parent: CodeEditor):
                self.parent = parent
                self.in_correct_scope = False

            def visit_ClassDef(self, node: cst.ClassDef) -> bool | None:
                return node.name.value == class_name

            def visit_FunctionDef(self, node: cst.FunctionDef) -> bool | None:
                if node.name.value == method_name:
                    self.in_correct_scope = True
                    return True
                return False

            def leave_FunctionDef(
                self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
            ) -> cst.BaseStatement:
                self.in_correct_scope = False
                return updated_node

            def leave_Assign(
                self, original_node: cst.Assign, updated_node: cst.Assign
            ) -> cst.BaseSmallStatement | cst.RemovalSentinel:
                if not self.in_correct_scope:
                    return updated_node

                # Check value first: is it a wrapper call we manage?
                is_managed = False
                if isinstance(original_node.value, cst.Call):
                    func = original_node.value.func
                    if (
                        isinstance(func, cst.Attribute)
                        and func.attr.value in wrapper_whitelist
                    ):
                        is_managed = True

                if not is_managed:
                    return updated_node

                # Check LHS
                should_keep = False
                for t in original_node.targets:
                    lhs = self.parent._get_full_name(t.target)
                    if lhs in allowed_lhs:
                        should_keep = True
                        break

                if not should_keep:
                    return cst.RemoveFromParent()

                return updated_node

        self.module = self.module.visit(Cleanup(self))
        return self

    def _get_full_name(self, node: cst.BaseExpression) -> str | None:
        if isinstance(node, cst.Name):
            return node.value
        if isinstance(node, cst.Attribute):
            base = self._get_full_name(node.value)
            if base:
                return f"{base}.{node.attr.value}"
        return None

    def _build_updated_value(
        self,
        current_node: cst.BaseExpression | None,
        target_lhs: str,
        inner_func: str,
        inner_kwargs: dict[str, CodeEditorValue],
        wrapper_attr: str | None,
        wrapper_kwargs: dict[str, CodeEditorValue] | None,
    ) -> cst.BaseExpression:

        # Helper to get inner call from wrapper
        inner_call: cst.Call | None = None
        current_wrapper: cst.Call | None = None

        if current_node and isinstance(current_node, cst.Call):
            if wrapper_attr:
                func = current_node.func
                if isinstance(func, cst.Attribute) and func.attr.value == wrapper_attr:
                    current_wrapper = current_node
                    if current_node.args and isinstance(
                        current_node.args[0].value, cst.Call
                    ):
                        inner_call = current_node.args[0].value
            else:
                inner_call = current_node  # No wrapper, direct call

        # Update Inner
        if inner_call is not None:
            # Update Function Name if changed
            updated_inner = inner_call
            if (
                isinstance(inner_call.func, cst.Name)
                and inner_call.func.value != inner_func
            ):
                updated_inner = inner_call.with_changes(func=cst.Name(inner_func))

            # Update Args
            updated_inner = self.update_call_args(updated_inner, inner_kwargs)
        else:
            # Create new Inner
            args = self._dict_to_cst_args(inner_kwargs)
            updated_inner = cst.Call(func=cst.Name(inner_func), args=args)

        # Update or Create Wrapper
        if wrapper_attr:
            if current_wrapper:
                # Update inner arg (index 0)
                new_wrapper_args = list(current_wrapper.args)
                new_wrapper_args[0] = new_wrapper_args[0].with_changes(
                    value=updated_inner
                )

                updated_wrapper = current_wrapper.with_changes(args=new_wrapper_args)
                if wrapper_kwargs:
                    updated_wrapper = self.update_call_args(
                        updated_wrapper, wrapper_kwargs
                    )
                return updated_wrapper

            else:
                # NEW Wrapper creation
                # Determine caller from LHS: self.banner.logo -> self.banner
                parts = target_lhs.split(".")
                if len(parts) > 1:
                    caller_str = ".".join(parts[:-1])
                else:
                    raise ValueError(
                        f"Некорректная цель присваивания для wrapper-вызова: '{target_lhs}'"
                    )

                # Create wrapper call: caller.wrapper_attr(inner)
                wrapper_args = [cst.Arg(value=updated_inner)]
                if wrapper_kwargs:
                    wrapper_args.extend(self._dict_to_cst_args(wrapper_kwargs))

                return cst.Call(
                    func=cst.Attribute(
                        value=self._parse_expression(caller_str),
                        attr=cst.Name(wrapper_attr),
                    ),
                    args=wrapper_args,
                )

        return updated_inner

    def _dict_to_cst_args(self, kwargs: dict[str, CodeEditorValue]) -> list[cst.Arg]:
        new_args: list[cst.Arg] = []
        for k, v in kwargs.items():
            if v is not None and v != "":
                new_args.append(
                    cst.Arg(
                        keyword=cst.Name(k),
                        value=self._value_to_cst(v),
                        equal=cst.AssignEqual(
                            whitespace_before=cst.SimpleWhitespace(""),
                            whitespace_after=cst.SimpleWhitespace(""),
                        ),
                    )
                )
        return new_args

    @staticmethod
    def _parse_expression(expr: str) -> cst.BaseExpression:
        parsed = cst.parse_expression(expr)
        return parsed

    @staticmethod
    def _parse_assign_target(expr: str) -> cst.BaseAssignTargetExpression:
        parsed = cst.parse_expression(expr)
        if isinstance(
            parsed,
            (
                cst.Name,
                cst.Attribute,
                cst.Subscript,
            ),
        ):
            return parsed
        raise ValueError(f"Некорректная цель присваивания: '{expr}'")

    @staticmethod
    def _value_to_cst(value: CodeEditorValue) -> cst.BaseExpression:
        if isinstance(value, bool):
            return cst.Name("True" if value else "False")
        if isinstance(value, int):
            return cst.Integer(str(value))
        if isinstance(value, float):
            return cst.Float(str(value))
        if isinstance(value, str):
            if value.isdigit():
                return cst.Integer(value)
            return cst.SimpleString(f'"{value}"')
        if value is None:
            return cst.Name("None")
        raise ValueError(f"Неподдерживаемое значение аргумента: {value!r}")

    @staticmethod
    def _collect_base_statements(
        statements: Sequence[cst.BaseStatement | cst.BaseSmallStatement],
    ) -> list[cst.BaseStatement]:
        collected: list[cst.BaseStatement] = []
        for statement in statements:
            if isinstance(statement, cst.BaseStatement):
                collected.append(statement)
                continue
            if isinstance(statement, cst.BaseSmallStatement):
                collected.append(cst.SimpleStatementLine(body=[statement]))
                continue
            raise ValueError(
                f"Ожидался statement-блок LibCST, получен {type(statement).__name__}"
            )
        return collected
