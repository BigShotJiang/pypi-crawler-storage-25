from __future__ import annotations

import libcst as cst

from .base import CodeEditor


class TestEditor:
    """
    Domain Logic for editing Test Files (Pytest + Allure + Persona).
    """

    __test__ = False

    def __init__(self, code: str) -> None:
        self.editor = CodeEditor(code)

    def get_code(self) -> str:
        return self.editor.get_code()

    def add_import(self, module: str, name: str, alias: str | None = None) -> None:
        self.editor.add_imports(
            [f"from {module} import {name}" + (f" as {alias}" if alias else "")]
        )

    def add_test_function(
        self,
        name: str,
        docstring: str = "",
        steps: list[str] | None = None,
        tags: list[str] | None = None,
        links: list[dict[str, str]] | None = None,
    ) -> None:
        """
        Adds a new test function with allure decorators.
        """
        # 0. Auto-import allure
        if tags or links:
            self.editor.add_imports(["import allure"])

        # 1. Build Decorators
        decorators: list[cst.Decorator] = []
        if tags:
            for tag in tags:
                decorators.append(
                    cst.Decorator(
                        decorator=cst.Call(
                            func=cst.Attribute(
                                value=cst.Name("allure"), attr=cst.Name("tag")
                            ),
                            args=[cst.Arg(cst.SimpleString(f'"{tag}"'))],
                        )
                    )
                )

        if links:
            for link in links:
                decorators.append(
                    cst.Decorator(
                        decorator=cst.Call(
                            func=cst.Attribute(
                                value=cst.Name("allure"), attr=cst.Name("link")
                            ),
                            args=[
                                cst.Arg(cst.SimpleString(f'"{link["url"]}"')),
                                cst.Arg(
                                    keyword=cst.Name("name"),
                                    value=cst.SimpleString(f'"{link["name"]}"'),
                                ),
                            ],
                        )
                    )
                )

        # 2. Build Body
        body_stmts: list[cst.BaseStatement] = []
        if docstring:
            body_stmts.append(
                cst.SimpleStatementLine(
                    body=[cst.Expr(cst.SimpleString(f'"""{docstring}"""'))]
                )
            )

        if steps:
            for step in steps:
                body_stmts.append(
                    self._parse_statement_or_raise(
                        step,
                        context=(
                            f"Некорректный шаг '{step}' при создании теста '{name}'"
                        ),
                    )
                )

        if not body_stmts:
            body_stmts.append(cst.SimpleStatementLine(body=[cst.Pass()]))

        # 3. Create FunctionDef
        func_def = cst.FunctionDef(
            name=cst.Name(name),
            params=cst.Parameters(
                params=[cst.Param(name=cst.Name("persona"))]
            ),  # Standard fixture
            body=cst.IndentedBlock(body=body_stmts),
            decorators=decorators,
        )

        # 4. Append to Module
        new_body = list(self.editor.module.body)
        new_body.append(func_def)
        self.editor.module = self.editor.module.with_changes(body=new_body)

    def add_step(self, test_name: str, step_code: str) -> None:
        """
        Adds a step to an existing test function.
        """
        stmt = self._parse_statement_or_raise(
            step_code,
            context=(
                f"Некорректный шаг '{step_code}' для тестовой функции '{test_name}'"
            ),
        )
        self.editor.insert_statements_to_function(test_name, [stmt])

    @staticmethod
    def _parse_statement_or_raise(step_code: str, *, context: str) -> cst.BaseStatement:
        try:
            return cst.parse_statement(step_code)
        except cst.ParserSyntaxError as error:
            raise ValueError(f"{context}: {error}") from error
