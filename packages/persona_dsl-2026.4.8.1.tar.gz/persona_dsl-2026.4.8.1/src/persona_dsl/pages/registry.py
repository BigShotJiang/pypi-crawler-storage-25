import inspect
from dataclasses import fields, MISSING
from typing import Dict, Type

from . import elements as elements_module
from .elements import Element
from .page import Page

PREFERRED_ROLE_CLASS_NAMES: dict[str, str] = {
    "generic": "Generic",
    "combobox": "Select",
}


def _build_registry() -> Dict[str, Type[Element]]:
    """
    Dynamically builds the ROLE_TO_CLASS registry by inspecting the elements module.

    Logic:
    1. Scan all classes in `persona_dsl.pages.elements`.
    2. If class has a 'role' field with a default value, map role -> class.
    3. Register class name (lowercase) as alias if it doesn't conflict.
    """
    registry: Dict[str, Type[Element]] = {}
    role_candidates: Dict[str, list[Type[Element]]] = {}
    discovered_classes: list[Type[Element]] = []
    seen_classes: set[Type[Element]] = set()

    for _, cls in inspect.getmembers(elements_module, inspect.isclass):
        if not issubclass(cls, Element) or cls is Element or cls is Page:
            continue
        if cls in seen_classes:
            continue
        seen_classes.add(cls)
        discovered_classes.append(cls)

        role = None
        for f in fields(cls):
            if f.name == "role":
                if f.default != MISSING:
                    role = f.default
                break

        if role:
            role_str = str(role)
            role_candidates.setdefault(role_str, []).append(cls)

    for role, candidates in role_candidates.items():
        if len(candidates) == 1:
            registry[role] = candidates[0]
            continue

        preferred_class_name = PREFERRED_ROLE_CLASS_NAMES.get(role)
        if preferred_class_name is None:
            candidate_names = ", ".join(cls.__name__ for cls in candidates)
            raise ValueError(
                f"Роль '{role}' зарегистрирована несколькими классами без явного правила выбора: "
                f"{candidate_names}."
            )

        preferred_candidates = [
            cls for cls in candidates if cls.__name__ == preferred_class_name
        ]
        if len(preferred_candidates) != 1:
            candidate_names = ", ".join(cls.__name__ for cls in candidates)
            raise ValueError(
                f"Для роли '{role}' ожидается класс '{preferred_class_name}', "
                f"но найден набор: {candidate_names}."
            )
        registry[role] = preferred_candidates[0]

    for cls in discovered_classes:
        alias = cls.__name__.lower()
        if alias not in registry:
            registry[alias] = cls

    return registry


ROLE_TO_CLASS: Dict[str, Type[Element]] = _build_registry()
