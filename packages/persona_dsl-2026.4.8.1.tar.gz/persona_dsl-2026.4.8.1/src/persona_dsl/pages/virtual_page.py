from __future__ import annotations

from typing import TypedDict

from persona_dsl.pages.elements import Element


class VirtualSnapshotNode(TypedDict, total=False):
    role: str
    name: str
    ref: str
    children: list["VirtualSnapshotNode"]


class VirtualPage:
    """
    Динамическая страница, построенная на основе ARIA-снепшота (dict) в памяти.
    Позволяет обращаться к элементам по структуре (page.banner.button) без генерации файла.
    """

    def __init__(self, snapshot: object):
        self._snapshot = self._validate_node(snapshot, path="root")
        self._root = self._build_tree(self._snapshot, path="root")

    @property
    def root(self) -> Element:
        return self._root

    def _sanitize_name(self, name: str) -> str:
        from persona_dsl.generators.page.utils import sanitize_name

        return sanitize_name(name)

    def _validate_node(self, raw_node: object, *, path: str) -> VirtualSnapshotNode:
        if not isinstance(raw_node, dict):
            raise TypeError(
                f"Узел виртуальной страницы в {path} должен быть словарём, получено {type(raw_node).__name__}."
            )

        role_raw = raw_node.get("role", "generic")
        if not isinstance(role_raw, str) or not role_raw:
            raise TypeError(f"Поле role в {path} должно быть непустой строкой.")

        validated: VirtualSnapshotNode = {"role": role_raw}

        name_raw = raw_node.get("name")
        if name_raw is not None:
            if not isinstance(name_raw, str):
                raise TypeError(f"Поле name в {path} должно быть строкой.")
            validated["name"] = name_raw

        ref_raw = raw_node.get("ref")
        if ref_raw is not None:
            if not isinstance(ref_raw, str):
                raise TypeError(f"Поле ref в {path} должно быть строкой.")
            validated["ref"] = ref_raw

        children_raw = raw_node.get("children")
        if children_raw is None:
            validated["children"] = []
            return validated
        if not isinstance(children_raw, list):
            raise TypeError(f"Поле children в {path} должно быть списком.")

        validated["children"] = [
            self._validate_node(child, path=f"{path}.children[{index}]")
            for index, child in enumerate(children_raw)
        ]
        return validated

    def _build_tree(self, node: VirtualSnapshotNode, *, path: str) -> Element:
        role = node["role"]
        name = node.get("name", "")
        ref = node.get("ref")

        # Определяем класс элемента
        from persona_dsl.pages.registry import ROLE_TO_CLASS

        cls = ROLE_TO_CLASS.get(role)
        if cls is None:
            raise ValueError(
                f"Неизвестная роль '{role}' в {path}. Добавьте явное сопоставление в pages.registry."
            )

        # Создаем инстанс
        # Мы не знаем точное имя переменной здесь, так как оно зависит от контекста родителя.
        # Используем роль/имя как временное имя.
        base_name = self._sanitize_name(name) or role

        # Если это базовый класс Element, ему нужно передать role явно.
        # Если это подкласс (Button, Link и т.д.), у них role обычно init=False и задан дефолтом.
        if cls is Element:
            el = Element(
                name=base_name,
                accessible_name=name,
                aria_ref=ref,
                role=role,
            )
        else:
            el = cls(name=base_name, accessible_name=name, aria_ref=ref)

        # Обрабатываем детей
        children = node.get("children", [])

        # Для именования детей нужно следить за уникальностью в рамках этого родителя
        used_names = set()

        for index, child_node in enumerate(children):
            child_el = self._build_tree(child_node, path=f"{path}.children[{index}]")

            # Придумываем имя для ребенка
            child_role = child_node.get("role", "element")
            child_aria_name = child_node.get("name", "")

            var_name_base = self._sanitize_name(child_aria_name) or child_role

            # Уникализация
            final_name = var_name_base
            i = 1
            while final_name in used_names or hasattr(el, final_name):
                final_name = f"{var_name_base}_{i}"
                i += 1

            used_names.add(final_name)

            # Обновляем имя элемента
            child_el.name = final_name

            # Добавляем в родителя
            # Используем add_element, чтобы прописались parent ссылки и _elements
            el.add_element(child_el, alias=final_name)

        return el

    def __getattr__(self, name: str) -> Element:
        # Делегируем доступ к корневому элементу
        resolved = getattr(self._root, name)
        if not isinstance(resolved, Element):
            raise AttributeError(
                f"Атрибут '{name}' виртуальной страницы не является Element."
            )
        return resolved
