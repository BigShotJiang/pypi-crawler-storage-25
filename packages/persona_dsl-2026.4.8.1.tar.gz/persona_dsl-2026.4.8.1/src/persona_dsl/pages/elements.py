from __future__ import annotations

import copy
from os import PathLike
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import (
    Iterator,
    Literal,
    Mapping,
    Protocol,
    TypeAlias,
    TypeVar,
    runtime_checkable,
)
from playwright.sync_api import Error as PlaywrightError

from persona_dsl.utils.naming import to_snake_case

ElementPrimitiveValue: TypeAlias = str | int | float | bool
ElementOptionValue: TypeAlias = ElementPrimitiveValue
ElementTextInput: TypeAlias = (
    ElementPrimitiveValue | Enum | list[ElementPrimitiveValue | Enum]
)
ElementVariants: TypeAlias = list[ElementPrimitiveValue] | type[Enum]
ElementFilterMap: TypeAlias = dict[str, object]
TableWhereCriteriaValue: TypeAlias = str | Enum
TableWhereCriteria: TypeAlias = Mapping[object, TableWhereCriteriaValue]
ElementT = TypeVar("ElementT", bound="Element")


@dataclass(frozen=True)
class UnresolvedElementDiagnostic:
    path: str
    element_type: str
    field_name: str
    element_name: str
    ui_label: str
    available_hints: dict[str, object]
    reason: str


@dataclass(frozen=True)
class RelativeAnchorSpec:
    path: tuple[str, ...]
    choice_value: str | None = None


class RelativeResolveCycleError(RuntimeError):
    """Жёсткая ошибка циклической relative_to()-цепочки."""


def get_element_ui_label(element: object) -> str:
    accessible_name = getattr(element, "accessible_name", None)
    if isinstance(accessible_name, str) and accessible_name:
        return accessible_name

    text = getattr(element, "text", None)
    if isinstance(text, str) and text:
        return text
    if isinstance(text, Enum):
        return str(text.value)

    variants = getattr(element, "variants", None)
    if isinstance(variants, list) and variants:
        first_variant = variants[0]
        if isinstance(first_variant, Enum):
            return str(first_variant.value)
        if isinstance(first_variant, (str, int, float, bool)):
            return str(first_variant)

    label = getattr(element, "label", None)
    if isinstance(label, str) and label:
        return label

    name = getattr(element, "name", None)
    if isinstance(name, str) and name:
        return name

    return element.__class__.__name__


@runtime_checkable
class QueryContextLike(Protocol):
    def locator(self, selector: str) -> "LocatorLike": ...
    def get_by_test_id(self, test_id: str) -> "LocatorLike": ...
    def get_by_role(
        self, role: str, *, name: str | None = None, exact: bool = False
    ) -> "LocatorLike": ...
    def get_by_label(self, text: str, *, exact: bool = False) -> "LocatorLike": ...
    def get_by_text(self, text: object, *, exact: bool = False) -> "LocatorLike": ...
    def get_by_placeholder(
        self, text: str, *, exact: bool = False
    ) -> "LocatorLike": ...
    def get_by_alt_text(self, text: str, *, exact: bool = False) -> "LocatorLike": ...
    def get_by_title(self, text: str, *, exact: bool = False) -> "LocatorLike": ...
    def evaluate(
        self, expression: str, arg: object | None = None, **kwargs: object
    ) -> object: ...


@runtime_checkable
class BrowserContextLike(Protocol):
    @property
    def pages(self) -> list["BrowserPageLike"]: ...

    def new_page(self) -> "BrowserPageLike": ...
    def close(self) -> None: ...


@runtime_checkable
class BrowserPageLike(QueryContextLike, Protocol):
    @property
    def context(self) -> BrowserContextLike: ...

    def goto(self, url: str) -> None: ...
    def close(self) -> None: ...
    def evaluate(
        self, expression: str, arg: object | None = None, **kwargs: object
    ) -> object: ...
    def screenshot(
        self,
        *,
        path: str,
        full_page: bool = False,
        omit_background: bool = False,
    ) -> None: ...
    def wait_for_load_state(
        self,
        state: str = "load",
        *,
        timeout: float | None = None,
    ) -> None: ...


@runtime_checkable
class LocatorLike(QueryContextLike, Protocol):
    @property
    def page(self) -> BrowserPageLike: ...

    def locator(self, selector: str) -> "LocatorLike": ...

    def get_by_test_id(self, test_id: str) -> "LocatorLike": ...
    def get_by_role(
        self, role: str, *, name: str | None = None, exact: bool = False
    ) -> "LocatorLike": ...
    def get_by_label(self, text: str, *, exact: bool = False) -> "LocatorLike": ...
    def get_by_text(self, text: object, *, exact: bool = False) -> "LocatorLike": ...
    def get_by_placeholder(
        self, text: str, *, exact: bool = False
    ) -> "LocatorLike": ...
    def get_by_alt_text(self, text: str, *, exact: bool = False) -> "LocatorLike": ...
    def get_by_title(self, text: str, *, exact: bool = False) -> "LocatorLike": ...

    @property
    def first(self) -> "LocatorLike": ...

    @property
    def last(self) -> "LocatorLike": ...

    def filter(
        self,
        *,
        has_text: object | None = None,
        has_not_text: object | None = None,
        has: "LocatorLike" | None = None,
        has_not: "LocatorLike" | None = None,
    ) -> "LocatorLike": ...
    def nth(self, index: int) -> "LocatorLike": ...
    def all(self) -> list["LocatorLike"]: ...
    def or_(self, other: "LocatorLike") -> "LocatorLike": ...
    def count(self) -> int: ...
    def text_content(self) -> str | None: ...
    def evaluate(
        self, expression: str, arg: object | None = None, **kwargs: object
    ) -> object: ...
    def scroll_into_view_if_needed(self, *, timeout: float | None = None) -> None: ...
    def screenshot(
        self,
        *,
        path: str,
        full_page: bool = False,
        omit_background: bool = False,
    ) -> None: ...
    def aria_snapshot(self, *, timeout: float | None = None) -> str: ...
    def get_attribute(self, name: str) -> str | None: ...
    def set_input_files(
        self,
        files: str | PathLike[str] | list[str | PathLike[str]],
    ) -> None: ...
    def click(
        self,
        *,
        force: bool = False,
        timeout: float | None = None,
        no_wait_after: bool | None = None,
        trial: bool = False,
    ) -> None: ...
    def dblclick(self, *, force: bool = False) -> None: ...
    def hover(self, *, force: bool = False) -> None: ...
    def drag_to(self, target: "LocatorLike", *, force: bool = False) -> None: ...
    def check(self, *, force: bool = False) -> None: ...
    def uncheck(self, *, force: bool = False) -> None: ...
    def is_checked(self) -> bool: ...
    def is_visible(self) -> bool: ...
    def input_value(self) -> str: ...
    def fill(
        self,
        value: str,
        *,
        force: bool = False,
        timeout: float | None = None,
        no_wait_after: bool | None = None,
    ) -> None: ...
    def press(
        self,
        key: str,
        *,
        delay: float | None = None,
        timeout: float | None = None,
        no_wait_after: bool | None = None,
    ) -> None: ...
    def select_option(self, **kwargs: object) -> None: ...


class Strategy(str, Enum):
    """Стратегии поиска элемента."""

    TEST_ID = "test_id"
    ROLE = "role"
    LABEL = "label"
    TEXT = "text"
    PLACEHOLDER = "placeholder"
    ALT_TEXT = "alt_text"
    TITLE = "title"
    HTML_NAME = "html_name"
    LOCATOR = "locator"  # css/xpath
    REF = "ref"  # data-persona-id / runtime ref
    LINK = "link"  # href
    ALL = "all"  # Использовать все доступные


NON_SEMANTIC_DEFAULT_ROLES = frozenset({"generic", "presentation", "none"})
ROLE_FIRST_CONTAINER_ROLES = frozenset(
    {
        "alert",
        "banner",
        "complementary",
        "contentinfo",
        "list",
        "main",
        "navigation",
        "progressbar",
        "rowgroup",
        "separator",
        "table",
        "tablist",
        "tabpanel",
    }
)


@dataclass(frozen=True)
class Column:
    title: str
    filter: "BaseColumnFilter | None" = None
    cell: "Element | None" = None

    def __post_init__(self) -> None:
        if not isinstance(self.title, str) or not self.title:
            raise TypeError("Column.title должен быть непустой строкой.")
        if self.filter is not None and not isinstance(self.filter, BaseColumnFilter):
            raise TypeError(
                "Column.filter должен быть экземпляром BaseColumnFilter или None."
            )
        if self.cell is not None and not isinstance(self.cell, Element):
            raise TypeError("Column.cell должен быть экземпляром Element или None.")
        if isinstance(self.cell, BaseColumnFilter):
            raise TypeError("Column.cell не может быть экземпляром BaseColumnFilter.")


class TableColumn(str, Enum):
    _spec: Column

    def __new__(cls, value: str | Column) -> "TableColumn":
        spec = value if isinstance(value, Column) else Column(title=value)
        member = str.__new__(cls, spec.title)
        member._value_ = spec.title
        member._spec = spec
        return member

    @property
    def column(self) -> Column:
        return self._spec

    @property
    def filter_prototype(self) -> "BaseColumnFilter | None":
        return self._spec.filter

    @property
    def cell_prototype(self) -> "Element | None":
        return self._spec.cell

    @property
    def popup_type(self) -> type["Generic"] | None:
        filter_prototype = self.filter_prototype
        if isinstance(filter_prototype, MultiSelectColumnFilter):
            return filter_prototype.popup_type
        cell_prototype = self.cell_prototype
        if isinstance(cell_prototype, MultiSelect):
            return cell_prototype.popup_type
        return None

    @property
    def cell_variants(self) -> type[Enum] | None:
        cell_prototype = self.cell_prototype
        if cell_prototype is not None:
            return cell_prototype.Options
        return None

    @property
    def filter_variants(self) -> type[Enum] | None:
        filter_prototype = self.filter_prototype
        if filter_prototype is not None:
            return filter_prototype.Options
        return None


@dataclass
class Element:
    """
    Базовый класс для элементов страницы с поддержкой Multi-Strategy Resolution
    и runtime-aware navigation.
    """

    name: str = ""
    role: str | None = None
    accessible_name: str | None = None
    text: ElementTextInput | None = None
    label: str | None = None
    placeholder: str | None = None
    test_id: str | None = None
    alt_text: str | None = None
    title: str | None = None
    html_name: str | None = None
    locator: str | None = None
    index: int | None = None
    exact: bool = False
    description: str | None = None
    static_screenshot_path: str | None = None
    static_aria_snapshot_path: str | None = None
    aria_ref: str | None = None
    url: str | None = None  # Для Strategy.LINK
    diagnostic_reason: str | None = None
    variants: ElementVariants | None = None  # List of allowed values or Enum Class
    Options: type[Enum] | None = None  # Dynamic Enum storage

    _filters: list[ElementFilterMap] = field(
        default_factory=list, repr=False, init=False
    )
    # Список стратегий поиска (если None — используется стандартный приоритет)
    _strategies: list[Strategy] | None = field(default=None, repr=False, init=False)
    parent: "Element" | None = field(default=None, repr=False, init=False)

    # Навигационные поля
    _nav_source: "Element" | None = field(default=None, repr=False, init=False)
    _nav_type: str | None = field(
        default=None, repr=False, init=False
    )  # 'child', 'next', 'prev', 'parent'
    _nav_arg: object | None = field(default=None, repr=False, init=False)
    _relative_anchor_spec: RelativeAnchorSpec | None = field(
        default=None, repr=False, init=False
    )
    _relative_index: int = field(default=0, repr=False, init=False)
    last_resolve_strategy: str | None = field(default=None, repr=False, init=False)

    # Кэш для Smart Shortcuts
    _shortcut_cache: dict[str, "Element"] = field(
        default_factory=dict, repr=False, init=False
    )

    def __post_init__(self) -> None:
        self._elements: dict[str, Element | ElementList | Repeated] | None = None

        # UNI-ARGUMENT LOGIC:
        # 1. If 'text' is a list, treat it as 'variants'
        if isinstance(self.text, list):
            if self.variants is not None:
                raise TypeError(
                    f"Элемент '{self.name}' не поддерживает одновременную передачу "
                    "списка в 'text' и значения в 'variants'."
                )
            self.variants = [
                _validated_option_value(member, self.name) for member in self.text
            ]
            self.text = None
        elif self.text is not None:
            self.text = _validated_option_value(self.text, self.name)

        if self.variants:
            self.apply_variants(self.variants)

        # validate variants
        if self.text is not None and self.variants is not None:
            # If text is an Enum member, comparison might work directly if variants has Enum members
            # If text is a string, check if it matches
            if self.text not in self.variants:
                # TODO: Add nicer error message with available options
                raise ValueError(
                    f"Invalid text value '{self.text}' for element '{self.name}'. "
                    f"Allowed variants: {self.variants}"
                )

        self._initialize_declarative_children()

    def _initialize_declarative_children(self) -> None:
        declarative_children = _collect_declarative_element_prototypes(type(self))
        if not declarative_children:
            return

        for alias, prototype in declarative_children.items():
            if isinstance(prototype, Repeated):
                repeated = prototype.bind(owner=self, alias=alias)
                if self._elements is None:
                    self._elements = {}
                self._elements[alias] = repeated
                setattr(self, alias, repeated)
                continue
            cloned = _clone_bound_element(prototype)
            if not cloned.name:
                cloned.name = alias
            self.add_element(cloned, alias=alias, overwrite=True)

    def apply_variants(self, variants: ElementVariants) -> None:
        if not isinstance(variants, (list, type)):
            raise TypeError(
                f"Поле 'variants' элемента '{self.name}' должно быть списком "
                "примитивных значений или классом Enum."
            )

        if isinstance(variants, type):
            if not issubclass(variants, Enum):
                raise TypeError(
                    f"Поле 'variants' элемента '{self.name}' должно быть классом Enum."
                )
            self.Options = variants
            self.variants = [
                _validated_option_value(member, self.name) for member in variants
            ]
            return

        normalized_variants: list[ElementPrimitiveValue] = [
            _validated_option_value(member, self.name) for member in variants
        ]
        self.variants = normalized_variants
        if normalized_variants:
            self.Options = _build_dynamic_options_enum(self.name, normalized_variants)
            return
        self.Options = None

    def configure(self: ElementT, **kwargs: object) -> ElementT:
        allowed_fields = {
            "accessible_name",
            "text",
            "label",
            "placeholder",
            "test_id",
            "alt_text",
            "title",
            "html_name",
            "locator",
            "index",
            "exact",
            "description",
            "static_screenshot_path",
            "static_aria_snapshot_path",
            "aria_ref",
            "url",
            "diagnostic_reason",
            "variants",
            "strategies",
        }
        for field_name, raw_value in kwargs.items():
            if field_name not in allowed_fields:
                raise ValueError(
                    f"Элемент '{self.name}' не поддерживает настройку поля '{field_name}'."
                )

            if field_name == "variants":
                if raw_value is None:
                    self.variants = None
                    self.Options = None
                else:
                    if not isinstance(raw_value, (list, type)):
                        raise TypeError(
                            f"Поле 'variants' элемента '{self.name}' должно быть списком или Enum-классом."
                        )
                    self.apply_variants(raw_value)
                continue

            if field_name == "strategies":
                if not isinstance(raw_value, list) or not all(
                    isinstance(item, Strategy) for item in raw_value
                ):
                    raise TypeError(
                        f"Поле 'strategies' элемента '{self.name}' должно быть списком Strategy."
                    )
                self._strategies = list(raw_value)
                continue

            if field_name == "text":
                self.text = _validated_text_input(raw_value, self.name)
                continue

            if field_name == "index":
                self.index = _validated_optional_int(raw_value, field_name, self.name)
                continue

            if field_name == "exact":
                if not isinstance(raw_value, bool):
                    raise TypeError(
                        f"Поле 'exact' элемента '{self.name}' должно быть bool."
                    )
                self.exact = raw_value
                continue

            validated_value = _validated_optional_str(raw_value, field_name, self.name)
            setattr(self, field_name, validated_value)

        return self

    @property
    def ui_label(self) -> str:
        if self.accessible_name:
            return self.accessible_name
        if self.text is not None:
            if isinstance(self.text, Enum):
                return str(self.text.value)
            return str(self.text)
        if isinstance(self.variants, list) and self.variants:
            first_variant = self.variants[0]
            return str(first_variant)
        if self.label:
            return self.label
        return self.name

    @property
    def available_hints(self) -> dict[str, object]:
        hints: dict[str, object] = {}
        scalar_fields = (
            "accessible_name",
            "label",
            "placeholder",
            "text",
            "title",
            "test_id",
            "url",
            "html_name",
            "locator",
            "alt_text",
            "aria_ref",
        )
        for field_name in scalar_fields:
            value = getattr(self, field_name)
            if value not in (None, ""):
                hints[field_name] = value
        if self.variants:
            hints["variants"] = list(self.variants)
        return hints

    def configure_children(self: ElementT, **child_configs: object) -> ElementT:
        if self._elements is None:
            raise ValueError(
                f"Элемент '{self.name}' не является контейнером и не поддерживает configure_children."
            )

        for child_name, child_config in child_configs.items():
            if not isinstance(child_name, str):
                raise TypeError("Имя дочернего элемента должно быть строкой.")
            if not isinstance(child_config, dict):
                raise TypeError(
                    f"Настройка дочернего элемента '{child_name}' должна быть словарём."
                )
            child = self.get_element(child_name)
            child.configure(**child_config)

        return self

    @property
    def is_container(self) -> bool:
        return self._elements is not None

    def using(self, strategies: list[Strategy]) -> "Element":
        """
        Возвращает копию элемента с заданным набором стратегий поиска.
        """
        new_element = copy.copy(self)
        new_element._strategies = strategies
        new_element._filters = list(self._filters)
        return new_element

    def robust(self) -> "Element":
        """Алиас для использования всех доступных стратегий (Strategy.ALL)."""
        return self.using([Strategy.ALL])

    def __call__(self, text: str | None = None, **kwargs: object) -> "Element":
        """
        Возвращает ЭЛЕМЕНТ (не список), найденный по тексту.
        """
        return self.clone(text=text, **kwargs)

    def by_variant(self, value: Enum | str) -> "Element":
        """
        Семантичный способ получения конкретного варианта (Enum или строки) из заданных `variants`.
        Автоматически определяет тип элемента:
        - Для контейнеров опций (напр. combobox, listbox): возвращает вложенную опцию.
        - Для простых текстовых элементов: возвращает клонированный элемент с привязкой к варианту.
        """
        container_roles = ["combobox", "listbox", "radiogroup", "menu"]
        if self.role in container_roles or (
            self.name and "select" in self.name.lower()
        ):
            return self.get_option(value)
        text_value = str(value.value) if isinstance(value, Enum) else str(value)
        return self.clone(text=text_value)

    def get_option(self, value: Enum | str) -> "Element":
        """
        Stragegy to find an option within this element (container).
        Default implementation: Returns a dynamic Search Strategy for an option
        with the given text/value (accessible_name).

        Subclasses (like ListBox) can override this to provide more specific structure
        (e.g. if options are children).
        """
        text_value = str(value.value) if isinstance(value, Enum) else str(value)
        safe_name = to_snake_case(text_value)

        # Avoid circular imports by using string references or local imports if needed?
        # Option is defined in this file (usually).
        # But Element is defined before Option.
        # So we can't return Option(...) easily without forward ref or local import?
        # Option is defined later in file.
        # We can use a factory or local resolve?
        # Actually, python classes are defined sequentially.
        # We can implement it near end of file or just use Element(role="option", ...)

        # Better: Implementation in base class should be simple.
        # But Option class is defined at line 1389.
        # So we can't use Option() here.

        # We can inject it or use Element(role="option")
        el = Element(
            name=f"dynamic_option_{safe_name}",
            role="option",
            accessible_name=text_value,
        )
        el.parent = self
        return el

    def get_option_by_index(self, index: int) -> "Element":
        """
        Stragegy to find an option by index within this element (container).
        Default implementation: Returns a dynamic Search Strategy for an option
        at the specified index.
        """
        # We can inject it or use Element(role="option")
        el = Element(
            name=f"dynamic_option_index_{index}",
            role="option",
            index=index,
        )
        el.parent = self
        return el

    def clone(self, text: str | None = None, **kwargs: object) -> "Element":
        """
        Возвращает копию элемента с модифицированными атрибутами.
        """
        new_element = copy.copy(self)
        new_element._filters = list(self._filters)

        for k, v in kwargs.items():
            if hasattr(new_element, k):
                setattr(new_element, k, v)

        if text is not None:
            # Handle Enum input for 'text'
            text_val = text.value if isinstance(text, Enum) else text

            # If role is 'text', we should set the 'text' attribute, not accessible_name
            # For other roles (like button, link), text argument usually implies accessible_name (label)
            if self.role in {
                "text",
                "generic",
                "listbox",
                "combobox",
                "radiogroup",
                "menu",
            } or (not self.role):
                new_element.text = text_val
            else:
                new_element.accessible_name = text_val

            # Validate against variants if they exist
            if new_element.variants and text_val not in new_element.variants:
                # Check if variants are Enum members and text matches value
                is_enum_match = False
                if isinstance(new_element.variants, list):
                    for v in new_element.variants:
                        v_val = v.value if isinstance(v, Enum) else v
                        if v_val == text_val:
                            is_enum_match = True
                            break

                if not is_enum_match:
                    raise ValueError(
                        f"Invalid text value '{text_val}' for element '{new_element.name}'. "
                        f"Allowed variants: {new_element.variants}"
                    )

        return new_element

    # --- Structural Navigation Methods ---

    def _create_nav_element(
        self, nav_type: str, arg: object | None = None
    ) -> "Element":
        """Создает новый элемент, привязанный к текущему через навигацию."""
        # Создаем generic элемент, так как мы не знаем роль цели заранее
        name_suffix = f"_{nav_type}"
        if arg is not None:
            name_suffix += f"_{arg}"

        new_el = Element(name=f"{self.name}{name_suffix}", role="generic")
        new_el.parent = self  # Важно для цепочки resolve
        new_el._nav_source = self
        new_el._nav_type = nav_type
        new_el._nav_arg = arg
        return new_el

    def child(self, index: int = 0) -> "Element":
        """Возвращает n-го ребенка элемента."""
        return self._create_nav_element("child", index)

    def first_child(self) -> "Element":
        """Возвращает первого ребенка."""
        return self.child(0)

    def last_child(self) -> "Element":
        """Возвращает последнего ребенка."""
        return self._create_nav_element("last_child")

    def next_sibling(self) -> "Element":
        """Возвращает следующий элемент на том же уровне."""
        return self._create_nav_element("next")

    def prev_sibling(self) -> "Element":
        """Возвращает предыдущий элемент на том же уровне."""
        return self._create_nav_element("prev")

    def parent_element(self) -> "Element":
        """Возвращает родительский элемент (DOM parent)."""
        return self._create_nav_element("parent")

    def relative_to(self: ElementT, anchor: "Element", index: int = 0) -> ElementT:
        """Связать weak-элемент с опорным элементом для relative-role resolve."""
        if not isinstance(anchor, Element):
            raise TypeError(
                f"Элемент '{self.name}' ожидает Element в relative_to(), получено {type(anchor).__name__}."
            )
        if not isinstance(index, int) or index < 0:
            raise ValueError(
                f"Элемент '{self.name}' ожидает неотрицательный целочисленный index в relative_to()."
            )
        if not self.role or self.role in NON_SEMANTIC_DEFAULT_ROLES:
            raise ValueError(
                f"Элемент '{self.name}' не поддерживает relative_to() без семантической role."
            )

        new_element = copy.copy(self)
        new_element._filters = list(self._filters)
        new_element._relative_anchor_spec = self._build_relative_anchor_spec(anchor)
        new_element._relative_index = index
        return new_element

    def _build_relative_anchor_spec(self, anchor: "Element") -> RelativeAnchorSpec:
        owner = self.parent
        if isinstance(anchor.parent, RadioGroup) and anchor.role == "radio":
            if not anchor.accessible_name:
                raise ValueError(
                    f"Элемент '{self.name}' не может использовать radio-anchor без accessible_name."
                )
            parent_path = self._anchor_path(anchor.parent, owner=owner)
            return RelativeAnchorSpec(parent_path, choice_value=anchor.accessible_name)

        return RelativeAnchorSpec(self._anchor_path(anchor, owner=owner))

    def _anchor_path(
        self,
        anchor: "Element",
        *,
        owner: "Element | None" = None,
    ) -> tuple[str, ...]:
        path: list[str] = []
        current: Element | None = anchor
        while current is not None and current is not owner:
            if not current.name:
                raise ValueError(
                    f"Элемент '{self.name}' не может построить relative_to() от anchor без name."
                )
            path.append(current.name)
            current = current.parent
        if owner is not None and current is None:
            raise ValueError(
                f"Элемент '{self.name}' не может использовать anchor '{anchor.name}' вне owner '{owner.name}'."
            )
        path.reverse()
        if not path:
            raise ValueError(
                f"Элемент '{self.name}' не может построить пустой relative anchor path."
            )
        return tuple(path)

    # --- Resolution Logic ---

    def _resolve_single_strategy(
        self, base: QueryContextLike, strategy: Strategy
    ) -> LocatorLike | None:
        """Строит локатор для одной конкретной стратегии."""
        if strategy == Strategy.REF and self.aria_ref:
            return base.locator(f'[data-persona-id="{self.aria_ref}"]')

        if strategy == Strategy.LINK and self.url:
            # Ищем ссылку с частичным совпадением href
            return base.locator(f'a[href*="{self.url}"]')

        if strategy == Strategy.TEST_ID and self.test_id:
            return base.get_by_test_id(self.test_id)

        if strategy == Strategy.ROLE and self.role:
            if self.accessible_name:
                return base.get_by_role(
                    self.role, name=self.accessible_name, exact=self.exact
                )
            role_name_candidates = self._role_name_candidates()
            if role_name_candidates:
                locator = base.get_by_role(
                    self.role, name=role_name_candidates[0], exact=self.exact
                )
                for candidate in role_name_candidates[1:]:
                    locator = locator.or_(
                        base.get_by_role(self.role, name=candidate, exact=self.exact)
                    )
                return locator
            return base.get_by_role(self.role, exact=self.exact)

        if strategy == Strategy.LABEL and self.label:
            return base.get_by_label(self.label, exact=self.exact)

        if strategy == Strategy.TEXT and self.text:
            return base.get_by_text(self.text, exact=self.exact)

        if strategy == Strategy.TEXT:
            variant_texts = self._variant_text_candidates()
            if variant_texts:
                locator = base.get_by_text(variant_texts[0], exact=self.exact)
                for candidate in variant_texts[1:]:
                    locator = locator.or_(base.get_by_text(candidate, exact=self.exact))
                return locator

        if strategy == Strategy.PLACEHOLDER and self.placeholder:
            return base.get_by_placeholder(self.placeholder, exact=self.exact)

        if strategy == Strategy.ALT_TEXT and self.alt_text:
            return base.get_by_alt_text(self.alt_text, exact=self.exact)

        if strategy == Strategy.TITLE and self.title:
            return base.get_by_title(self.title, exact=self.exact)

        if strategy == Strategy.HTML_NAME and self.html_name:
            escaped_name = self.html_name.replace("\\", "\\\\").replace('"', '\\"')
            return base.locator(f'css=[name="{escaped_name}"]')

        if strategy == Strategy.LOCATOR and self.locator:
            return base.locator(self.locator)

        return None

    def _has_strategy_value(self, strategy: Strategy) -> bool:
        if strategy == Strategy.REF:
            return bool(self.aria_ref)
        if strategy == Strategy.LINK:
            return bool(self.url)
        if strategy == Strategy.TEST_ID:
            return bool(self.test_id)
        if strategy == Strategy.ROLE:
            if not self.role:
                return False
            if self.role in NON_SEMANTIC_DEFAULT_ROLES:
                return False
            if self.role == "table" and self.aria_ref:
                return False
            if self.role == "link" and self.url:
                return False
            if self.role == "text":
                return False
            if self.role == "radiogroup" and (self.variants or self.Options):
                return False
            if self.role == "img" and self.aria_ref:
                return False
            if (
                self.role in {"combobox", "listbox"}
                and self.aria_ref
                and (self.variants or self.Options)
            ):
                return False
            if self.accessible_name:
                return True
            if self._role_name_candidates():
                return True
            if self.role in ROLE_FIRST_CONTAINER_ROLES:
                return True
            if (
                self.test_id
                or self.aria_ref
                or self.label
                or self.html_name
                or self.placeholder
                or self.text
                or self.alt_text
                or self.title
                or self.url
            ):
                return False
            return True
        if strategy == Strategy.LABEL:
            return bool(self.label)
        if strategy == Strategy.TEXT:
            if self.text:
                return True
            if self.role in {"combobox", "listbox", "radiogroup"}:
                return False
            return bool(self._variant_text_candidates())
        if strategy == Strategy.PLACEHOLDER:
            return bool(self.placeholder)
        if strategy == Strategy.ALT_TEXT:
            return bool(self.alt_text)
        if strategy == Strategy.TITLE:
            return bool(self.title)
        if strategy == Strategy.HTML_NAME:
            return bool(self.html_name)
        if strategy == Strategy.LOCATOR:
            return bool(self.locator)
        return False

    def _variant_text_candidates(self) -> list[str]:
        if not self.variants:
            return []

        candidates: list[str] = []
        for variant in self.variants:
            if isinstance(variant, (str, int, float, bool)):
                normalized = str(variant)
                if normalized and normalized not in candidates:
                    candidates.append(normalized)
        return candidates

    def _role_name_candidates(self) -> list[str]:
        if self.role in {"", "text", "combobox", "listbox", "radiogroup"}:
            return []
        return self._variant_text_candidates()

    def _resolve_navigation_step(self, base: LocatorLike) -> LocatorLike:
        """
        Резолвер навигации.
        Если навигация построена от runtime-ref, требуем Runtime JS.
        Для обычных локаторов используем только структурную CSS/XPath навигацию.
        """
        if self._nav_source is not None and self._nav_source.aria_ref:
            page = base.page
            js_script = """
                ([ref, type, arg]) => {
                    if (!window.__PERSONA__) return null;
                    const el = window.__PERSONA__.navigate(ref, type, arg);
                    return el ? el.getAttribute('data-persona-id') : null;
                }
            """
            try:
                target_id = page.evaluate(
                    js_script,
                    [self._nav_source.aria_ref, self._nav_type, self._nav_arg],
                )
            except PlaywrightError as error:
                raise RuntimeError(
                    f"Не удалось выполнить runtime-навигацию '{self._nav_type}' "
                    f"от ref '{self._nav_source.aria_ref}'."
                ) from error

            if not isinstance(target_id, str) or not target_id:
                raise RuntimeError(
                    f"Runtime-навигация '{self._nav_type}' от ref "
                    f"'{self._nav_source.aria_ref}' не вернула целевой элемент."
                )

            return page.locator(f'[data-persona-id="{target_id}"]')

        if self._nav_type == "child":
            if not isinstance(self._nav_arg, int):
                raise TypeError(
                    f"Навигация child для элемента '{self.name}' требует целочисленный индекс."
                )
            return base.locator(":scope > *").nth(self._nav_arg)

        if self._nav_type == "last_child":
            return base.locator(":scope > *").last

        if self._nav_type == "next":
            return base.locator("xpath=following-sibling::*[1]")

        if self._nav_type == "prev":
            return base.locator("xpath=preceding-sibling::*[1]")

        if self._nav_type == "parent":
            return base.locator("xpath=..")

        raise ValueError(f"Unknown navigation type: {self._nav_type}")

    def _resolve_relative_anchor(self, owner: "Element") -> "Element":
        spec = self._relative_anchor_spec
        if spec is None:
            raise ValueError(f"Элемент '{self.name}' не содержит relative anchor spec.")
        current: object = owner
        for segment in spec.path:
            if not isinstance(current, Element):
                raise TypeError(
                    f"Элемент '{self.name}' потерял relative anchor owner при переходе к '{segment}'."
                )
            current = getattr(current, segment)
        if not isinstance(current, Element):
            raise TypeError(
                f"Элемент '{self.name}' получил не-Element anchor по пути {spec.path!r}."
            )
        if spec.choice_value is not None:
            if not isinstance(current, RadioGroup):
                raise TypeError(
                    f"Элемент '{self.name}' ожидает RadioGroup для relative anchor {spec.path!r}."
                )
            return current.choice(spec.choice_value)
        return current

    def _read_runtime_ref(self, locator: LocatorLike) -> str | None:
        try:
            raw_value = locator.get_attribute("data-persona-id")
        except PlaywrightError:
            return None
        if isinstance(raw_value, str) and raw_value:
            return raw_value
        return None

    def _collect_relative_scope_ids(
        self,
        anchor_locator: LocatorLike,
        *,
        stop_ref: str | None,
    ) -> list[str]:
        script = """
            (element, [boundaryRef]) => {
                const ids = [];
                let current = element.parentElement;
                while (current) {
                    const currentId = current.getAttribute('data-persona-id');
                    if (currentId) {
                        ids.push(currentId);
                        if (boundaryRef && currentId === boundaryRef) {
                            break;
                        }
                    }
                    current = current.parentElement;
                }
                return ids;
            }
        """
        raw_result = anchor_locator.evaluate(script, [stop_ref])
        if not isinstance(raw_result, list):
            raise RuntimeError(
                f"Элемент '{self.name}' не получил список локальных scope ref для relative resolve."
            )
        scope_ids: list[str] = []
        for raw_id in raw_result:
            if isinstance(raw_id, str) and raw_id:
                scope_ids.append(raw_id)
        return scope_ids

    def _pick_relative_candidate(
        self,
        role_candidates: LocatorLike,
        *,
        anchor_ref: str | None,
    ) -> LocatorLike | None:
        filtered_indexes: list[int] = []
        total = role_candidates.count()
        for candidate_index in range(total):
            candidate = role_candidates.nth(candidate_index)
            candidate_ref = self._read_runtime_ref(candidate)
            if anchor_ref and candidate_ref == anchor_ref:
                continue
            filtered_indexes.append(candidate_index)

        if len(filtered_indexes) <= self._relative_index:
            return None

        return role_candidates.nth(filtered_indexes[self._relative_index])

    def _resolve_relative_locator(
        self,
        base: QueryContextLike,
        page: BrowserPageLike,
        resolution_stack: set[int],
    ) -> LocatorLike:
        if self.parent is None:
            raise ValueError(
                f"Элемент '{self.name}' не может использовать relative_to() без parent owner."
            )
        anchor = self._resolve_relative_anchor(self.parent)
        anchor_locator = anchor._resolve_internal(page, resolution_stack)

        anchor_ref = self._read_runtime_ref(anchor_locator)
        owner_ref: str | None = None
        if isinstance(base, LocatorLike):
            owner_ref = self._read_runtime_ref(base)

        scope_ids = self._collect_relative_scope_ids(
            anchor_locator,
            stop_ref=owner_ref,
        )
        if owner_ref and owner_ref not in scope_ids:
            scope_ids.append(owner_ref)

        target_role = self.role
        if target_role is None:
            raise ValueError(
                f"Элемент '{self.name}' не может использовать relative_to() без role."
            )

        for scope_ref in scope_ids:
            scope = page.locator(f'[data-persona-id="{scope_ref}"]')
            role_candidates = scope.get_by_role(target_role, exact=self.exact)
            picked = self._pick_relative_candidate(
                role_candidates,
                anchor_ref=anchor_ref,
            )
            if picked is not None:
                self.last_resolve_strategy = "relative_role"
                return picked

        raise RuntimeError(
            f"Relative resolve не нашёл элемент '{self.name}' от anchor '{anchor.name}' "
            f"по role='{self.role}' и index={self._relative_index}."
        )

    def _get_playwright_locator(
        self,
        base: QueryContextLike,
        *,
        page: BrowserPageLike,
        resolution_stack: set[int],
    ) -> QueryContextLike:
        """Получение локатора с поддержкой Multi-Strategy и Navigation."""

        # 0. Navigation Step
        if self._nav_type:
            if not isinstance(base, LocatorLike):
                raise TypeError(
                    f"Навигация элемента '{self.name}' требует родительский Locator, а не корневую страницу."
                )
            return self._resolve_navigation_step(base)

        # 1. Relative role lookup
        if self._relative_anchor_spec is not None:
            try:
                return self._resolve_relative_locator(base, page, resolution_stack)
            except (
                PlaywrightError,
                RelativeResolveCycleError,
                RuntimeError,
                TypeError,
                ValueError,
            ) as error:
                if isinstance(error, RelativeResolveCycleError):
                    raise
                if self.aria_ref:
                    self.last_resolve_strategy = "aria_ref"
                    return page.locator(f'[data-persona-id="{self.aria_ref}"]')
                raise RuntimeError(
                    f"Relative resolve для элемента '{self.name}' завершился ошибкой."
                ) from error

        # 2. Определение стратегий поиска
        locators = []
        strategies_to_check: list[Strategy] = []
        default_priority = [
            Strategy.ROLE,
            Strategy.LABEL,
            Strategy.HTML_NAME,
            Strategy.PLACEHOLDER,
            Strategy.TEXT,
            Strategy.ALT_TEXT,
            Strategy.TITLE,
            Strategy.REF,
            Strategy.TEST_ID,
            Strategy.LINK,
            Strategy.LOCATOR,
        ]

        if self._strategies:
            if Strategy.ALL in self._strategies:
                strategies_to_check = default_priority
            else:
                strategies_to_check = self._strategies
        else:
            # Стандартный строгий режим:
            # берём только первую доступную стратегию без скрытых fallback-цепочек.
            for strategy in default_priority:
                if self._has_strategy_value(strategy):
                    strategies_to_check = [strategy]
                    break

        if strategies_to_check:
            for strat in strategies_to_check:
                loc = self._resolve_single_strategy(base, strat)
                if loc is not None:
                    locators.append(loc)
        else:
            if not locators:
                if self.parent is None:
                    return base
                if self._is_transparent_resolution_container():
                    return base
                raise ValueError(f"Элемент '{self.name}' не имеет стратегии поиска.")

        ref_only_resolution = (
            len(strategies_to_check) == 1 and strategies_to_check[0] == Strategy.REF
        )

        # 3. Объединение локаторов (OR)
        if not locators:
            raise ValueError(f"Element '{self.name}': не удалось построить локатор.")

        final_locator = locators[0]
        for loc in locators[1:]:
            final_locator = final_locator.or_(loc)

        # 4. Применение фильтров
        if hasattr(self, "_filters") and self._filters:
            for filter_kwargs in self._filters:
                has_locator = _resolve_filter_locator(
                    filter_kwargs.get("has"), final_locator.page
                )
                has_not_locator = _resolve_filter_locator(
                    filter_kwargs.get("has_not"), final_locator.page
                )
                final_locator = final_locator.filter(
                    has_text=filter_kwargs.get("has_text"),
                    has_not_text=filter_kwargs.get("has_not_text"),
                    has=has_locator,
                    has_not=has_not_locator,
                )

        # 5. Индекс
        if self.index is not None and not ref_only_resolution:
            idx = self.index
            if idx < 0:
                total = final_locator.count()
                idx = total + idx
                # Note: Playwright nth() handles negatives? No, it throws if out of bounds usually or wraps?
                # Playwright nth() argument is 0-based index. Negative values like -1 mean last.
                # So we can pass negative directly to nth()!
                # But let's keep explicit logic if we want safety.
                # Actually playwright .nth(-1) works.
            final_locator = final_locator.nth(idx)

        if strategies_to_check:
            chosen_strategy = strategies_to_check[0]
            self.last_resolve_strategy = (
                "aria_ref" if chosen_strategy == Strategy.REF else chosen_strategy.value
            )

        return final_locator

    def _is_transparent_resolution_container(self) -> bool:
        if self.is_container:
            return True
        if isinstance(self, RadioGroup) and (self.variants or self.Options):
            return True
        return False

    def resolve(self, page: BrowserPageLike) -> LocatorLike:
        """Вернуть Playwright Locator."""
        return self._resolve_internal(page, set())

    def _resolve_internal(
        self,
        page: BrowserPageLike,
        resolution_stack: set[int],
    ) -> LocatorLike:
        element_identity = id(self)
        if element_identity in resolution_stack:
            raise RelativeResolveCycleError(
                f"Обнаружен цикл relative_to()/resolve() для элемента '{self.name}'."
            )
        resolution_stack.add(element_identity)
        self.last_resolve_strategy = None

        chain: list[Element] = [self]
        curr = self.parent
        while curr is not None:
            chain.append(curr)
            curr = curr.parent

        try:
            locator: QueryContextLike = page
            for element in reversed(chain):
                locator = element._get_playwright_locator(
                    locator,
                    page=page,
                    resolution_stack=resolution_stack,
                )

            if not isinstance(locator, LocatorLike):
                raise TypeError(
                    f"Элемент '{self.name}' не может быть зарезолвен до Playwright Locator без явной стратегии поиска."
                )
            return locator
        finally:
            resolution_stack.remove(element_identity)

    def resolve_or(
        self, page: BrowserPageLike, *alternatives: "Element"
    ) -> LocatorLike:
        """
        Построить локатор как OR от self и альтернативных элементов.
        """
        loc = self.resolve(page)
        for alt in alternatives:
            loc = loc.or_(alt.resolve(page))
        return loc

    def filter(
        self,
        has_text: str | None = None,
        has_not_text: str | None = None,
        has: "Element" | LocatorLike | None = None,
        has_not: "Element" | LocatorLike | None = None,
    ) -> "Element":
        new_element = copy.copy(self)
        new_element._filters = list(self._filters)

        filter_kwargs: ElementFilterMap = {}
        if has_text is not None:
            filter_kwargs["has_text"] = has_text
        if has_not_text is not None:
            filter_kwargs["has_not_text"] = has_not_text
        if has is not None:
            filter_kwargs["has"] = has
        if has_not is not None:
            filter_kwargs["has_not"] = has_not

        if filter_kwargs:
            new_element._filters.append(filter_kwargs)

        return new_element

    # --- Container methods ---

    def add_element(
        self, element: ElementT, *, alias: str | None = None, overwrite: bool = False
    ) -> ElementT:
        if self._elements is None:
            self._elements = {}

        name = alias or element.name

        # Check for collision in current container ONLY (ignore nested via __getattr__)
        collision = False
        if not overwrite:
            # 1. Already in container map?
            if self._elements is not None and name in self._elements:
                collision = True
            # 2. Instance attribute? (e.g. self.foo = ...)
            elif name in self.__dict__:
                collision = True
            # 3. Class attribute/method? (e.g. def foo(self)...)
            elif hasattr(type(self), name):
                # Если это property, то перезапись разрешена (setattr вызовет сеттер, если он есть)
                if not isinstance(getattr(type(self), name), property):
                    collision = True

        if collision:
            raise ValueError(
                f"Элемент/атрибут '{name}' уже существует в контейнере '{self.name}'. Если это свойство, убедитесь что у него есть setter."
            )

        element.parent = self
        self._elements[name] = element
        setattr(self, name, element)
        return element

    def add_element_list(
        self, prototype: "Element", *, alias: str | None = None, overwrite: bool = False
    ) -> "ElementList":
        if self._elements is None:
            self._elements = {}

        list_name = alias or f"{prototype.name}s"

        # Check for collision in current container ONLY
        collision = False
        if not overwrite:
            if self._elements is not None and list_name in self._elements:
                collision = True
            elif list_name in self.__dict__:
                collision = True
            elif hasattr(type(self), list_name):
                collision = True

        if collision:
            raise ValueError(
                f"Элемент/атрибут '{list_name}' уже существует в контейнере '{self.name}'"
            )

        el_list = ElementList(owner=self, prototype=prototype, name=list_name)
        self._elements[list_name] = el_list
        setattr(self, list_name, el_list)
        return el_list

    def get_element(self, name: str) -> "Element":
        if self._elements is None or name not in self._elements:
            raise AttributeError(
                f"Элемент '{name}' не найден в контейнере '{self.name}'"
            )
        el = self._elements[name]
        if isinstance(el, (ElementList, Repeated)):
            raise AttributeError(
                f"'{name}' является коллекцией. Используйте индекс или вызов."
            )
        return el

    def _find_element_by_name_recursive(self, name: str) -> "Element" | None:
        """Рекурсивный поиск элемента по имени (Smart Shortcut)."""
        if not self._elements:
            return None

        for el in self._elements.values():
            if isinstance(el, Element):
                if el.name == name:
                    return el
                # Recurse
                found = el._find_element_by_name_recursive(name)
                # FIX: Explicit check for None because Element might be Falsy if empty (calls __len__)
                if found is not None:
                    return found
        return None

    def __getattr__(self, name: str) -> "Element":
        if name.startswith("_"):
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")

        # 1. Try direct child
        if self._elements is not None and name in self._elements:
            direct_child = self._elements[name]
            if isinstance(direct_child, (ElementList, Repeated)):
                raise AttributeError(
                    f"'{name}' является коллекцией. Используйте индекс или вызов."
                )
            return direct_child

        # 2. Check cache
        if name in self._shortcut_cache:
            return self._shortcut_cache[name]

        # 3. Recursive search (Smart Shortcut)
        found = self._find_element_by_name_recursive(name)
        if found is not None:
            self._shortcut_cache[name] = found
            return found

        raise AttributeError(
            f"Element '{name}' not found in '{self.name}' or its descendants."
        )

    def _children_in_order(self) -> list["Element"]:
        if not self._elements:
            return []
        items: list[Element] = []
        for v in self._elements.values():
            if isinstance(v, Element):
                items.append(v)
        return items

    def _repeated_children_in_order(self) -> list["Repeated"]:
        if not self._elements:
            return []
        items: list[Repeated] = []
        for value in self._elements.values():
            if isinstance(value, Repeated):
                items.append(value)
        return items

    def __len__(self) -> int:
        children = self._children_in_order()
        if children:
            return len(children)
        return len(self._repeated_children_in_order())

    def __iter__(self) -> Iterator["Element"]:
        yield from self._children_in_order()

    def __getitem__(self, key: int | str) -> "Element":
        if isinstance(key, int):
            children = self._children_in_order()
            if children:
                try:
                    return children[key]
                except IndexError:
                    raise IndexError(f"Index {key} out of range")

            repeated_children = self._repeated_children_in_order()
            if len(repeated_children) == 1:
                return repeated_children[0][key]
            raise IndexError(f"Index {key} out of range")
        if isinstance(key, str):
            # Support dict-like access via shortcuts too?
            # Usually __getitem__ string access is direct.
            # But let's use getattr logic to be consistent with shortcuts.
            return self.__getattr__(key)
        raise TypeError("Index must be int or str")


def _validated_option_value(value: object, element_name: str) -> ElementPrimitiveValue:
    normalized_value = value.value if isinstance(value, Enum) else value
    if isinstance(normalized_value, (str, int, float, bool)):
        return normalized_value
    raise TypeError(
        f"Элемент '{element_name}' получил недопустимое значение варианта: "
        f"{value!r}. Допустимы str, int, float, bool или Enum."
    )


def _build_dynamic_options_enum(
    element_name: str, variants: list[ElementPrimitiveValue]
) -> type[Enum]:
    enum_dict: dict[str, ElementPrimitiveValue] = {}
    for variant in variants:
        raw_name = to_snake_case(str(variant)).upper()
        sanitized_name = re.sub(r"\W", "_", raw_name)
        if not sanitized_name:
            sanitized_name = "VAL"
        if sanitized_name[0].isdigit():
            sanitized_name = f"OPT_{sanitized_name}"
        if sanitized_name in enum_dict and enum_dict[sanitized_name] != variant:
            raise ValueError(
                f"Элемент '{element_name}' содержит конфликт вариантов: "
                f"'{enum_dict[sanitized_name]}' и '{variant}' дают одинаковое имя "
                f"'{sanitized_name}' для Enum."
            )
        enum_dict[sanitized_name] = variant

    enum_cls = _create_runtime_enum("DynamicOptions", enum_dict)
    if not isinstance(enum_cls, type):
        raise TypeError(
            f"Не удалось создать Enum вариантов для элемента '{element_name}'."
        )
    return enum_cls


def _resolve_filter_locator(value: object, page: BrowserPageLike) -> LocatorLike | None:
    if value is None:
        return None
    if isinstance(value, Element):
        return value.resolve(page)
    if isinstance(value, LocatorLike):
        return value
    raise TypeError(
        "Фильтр элемента поддерживает только Element, LocatorLike или None "
        f"для полей 'has'/'has_not', получено: {value!r}."
    )


def _create_runtime_enum(
    enum_name: str, members: dict[str, ElementPrimitiveValue]
) -> object:
    return Enum(enum_name, members)


def _validated_optional_str(
    value: object, field_name: str, element_name: str
) -> str | None:
    if value is None or isinstance(value, str):
        return value
    raise TypeError(
        f"Поле '{field_name}' элемента '{element_name}' должно быть строкой или None."
    )


def _validated_optional_int(
    value: object, field_name: str, element_name: str
) -> int | None:
    if value is None or isinstance(value, int):
        return value
    raise TypeError(
        f"Поле '{field_name}' элемента '{element_name}' должно быть целым числом или None."
    )


def _validated_text_input(value: object, element_name: str) -> ElementTextInput | None:
    if value is None:
        return None
    if isinstance(value, list):
        return [_validated_option_value(item, element_name) for item in value]
    return _validated_option_value(value, element_name)


def collect_unresolved_element_diagnostics(
    root: object,
    *,
    prefix: str,
) -> list[UnresolvedElementDiagnostic]:
    diagnostics: list[UnresolvedElementDiagnostic] = []

    def has_child_elements(element: Element) -> bool:
        element_dict = getattr(element, "__dict__", None)
        if not isinstance(element_dict, dict):
            return False
        for attr_name, attr_value in element_dict.items():
            if not isinstance(attr_name, str):
                continue
            if attr_name.startswith("_") or attr_name == "parent":
                continue
            if isinstance(attr_value, Element):
                return True
        return False

    def walk(obj: object, obj_prefix: str) -> None:
        obj_dict = getattr(obj, "__dict__", None)
        if not isinstance(obj_dict, dict):
            return

        for field_name, value in obj_dict.items():
            if not isinstance(field_name, str):
                continue
            if field_name.startswith("_") or field_name == "parent":
                continue
            if not isinstance(value, Element):
                continue

            full_path = f"{obj_prefix}.{field_name}"
            if value.diagnostic_reason and not has_child_elements(value):
                diagnostics.append(
                    UnresolvedElementDiagnostic(
                        path=full_path,
                        element_type=value.__class__.__name__,
                        field_name=field_name,
                        element_name=value.name,
                        ui_label=value.ui_label,
                        available_hints=value.available_hints,
                        reason=value.diagnostic_reason,
                    )
                )
            walk(value, full_path)

    walk(root, prefix)
    return diagnostics


def _make_repeated_item(
    *,
    owner: Element,
    prototype: Element,
    index: int | None,
) -> Element:
    cls = type(prototype)

    from dataclasses import fields

    cls_fields = {field_def.name: field_def for field_def in fields(cls)}
    kwargs: dict[str, object | None] = {
        "name": f"{prototype.name}_{index}" if index is not None else prototype.name,
        "accessible_name": prototype.accessible_name,
        "locator": prototype.locator,
        "index": index,
        "exact": prototype.exact,
        "description": prototype.description,
        "static_screenshot_path": prototype.static_screenshot_path,
        "static_aria_snapshot_path": prototype.static_aria_snapshot_path,
        "aria_ref": prototype.aria_ref,
        "test_id": prototype.test_id,
        "placeholder": prototype.placeholder,
        "text": prototype.text,
        "role": prototype.role,
        "url": prototype.url,
    }
    filtered_kwargs = {
        key: value
        for key, value in kwargs.items()
        if key not in cls_fields or cls_fields[key].init
    }

    if cls is Element:
        item = Element(
            name=str(filtered_kwargs["name"]),
            accessible_name=_validated_optional_str(
                filtered_kwargs.get("accessible_name"),
                "accessible_name",
                prototype.name,
            ),
            locator=_validated_optional_str(
                filtered_kwargs.get("locator"),
                "locator",
                prototype.name,
            ),
            index=_validated_optional_int(
                filtered_kwargs.get("index"),
                "index",
                prototype.name,
            ),
            exact=bool(filtered_kwargs.get("exact", False)),
            description=_validated_optional_str(
                filtered_kwargs.get("description"),
                "description",
                prototype.name,
            ),
            static_screenshot_path=_validated_optional_str(
                filtered_kwargs.get("static_screenshot_path"),
                "static_screenshot_path",
                prototype.name,
            ),
            static_aria_snapshot_path=_validated_optional_str(
                filtered_kwargs.get("static_aria_snapshot_path"),
                "static_aria_snapshot_path",
                prototype.name,
            ),
            aria_ref=_validated_optional_str(
                filtered_kwargs.get("aria_ref"),
                "aria_ref",
                prototype.name,
            ),
            test_id=_validated_optional_str(
                filtered_kwargs.get("test_id"),
                "test_id",
                prototype.name,
            ),
            placeholder=_validated_optional_str(
                filtered_kwargs.get("placeholder"),
                "placeholder",
                prototype.name,
            ),
            text=_validated_text_input(filtered_kwargs.get("text"), prototype.name),
            role=_validated_optional_str(
                filtered_kwargs.get("role"),
                "role",
                prototype.name,
            ),
            url=_validated_optional_str(
                filtered_kwargs.get("url"),
                "url",
                prototype.name,
            ),
        )
    else:
        candidate = copy.copy(prototype)
        candidate.name = str(filtered_kwargs["name"])
        candidate.index = index
        item = candidate

    item.parent = owner
    item._relative_anchor_spec = prototype._relative_anchor_spec
    item._relative_index = prototype._relative_index
    item.last_resolve_strategy = None
    if prototype._strategies:
        item._strategies = list(prototype._strategies)
    if prototype._filters:
        item._filters = list(prototype._filters)
    return item


class ElementList:
    """Коллекция однотипных элементов."""

    def __init__(self, owner: Element, prototype: Element, name: str) -> None:
        self._owner = owner
        self._prototype = prototype
        self.name = name
        self._prototype.parent = owner

    def __call__(self, text: str | None = None, **kwargs: object) -> Element:
        """
        Возвращает ЭЛЕМЕНТ (не список), найденный по тексту.
        """
        item = self._make_item(None)  # index=None -> ищем среди всех

        if text:
            item = item.filter(has_text=text)

        return item

    def _make_item(self, index: int | None) -> Element:
        return _make_repeated_item(
            owner=self._owner,
            prototype=self._prototype,
            index=index,
        )

    def __getitem__(self, index: int) -> Element:
        if not isinstance(index, int):
            raise IndexError("Index must be int")
        return self._make_item(index)

    def get(self, index: int) -> Element:
        return self.__getitem__(index)

    def first(self) -> Element:
        return self._make_item(0)

    def last(self) -> Element:
        return self._make_item(-1)

    def nth(self, index: int) -> Element:
        return self.__getitem__(index)

    def with_text(self, text: str, *, exact: bool = True) -> Element:
        item = self._make_item(None)
        return item.filter(has_text=text)

    def filter(
        self,
        has_text: str | None = None,
        has_not_text: str | None = None,
        has: "Element" | LocatorLike | None = None,
        has_not: "Element" | LocatorLike | None = None,
    ) -> ElementList:
        new_prototype = self._prototype.filter(
            has_text=has_text, has_not_text=has_not_text, has=has, has_not=has_not
        )
        return ElementList(owner=self._owner, prototype=new_prototype, name=self.name)

    def resolve_all(self, page: BrowserPageLike) -> list[LocatorLike]:
        """
        Resolves the list definition to a list of Playwright Locators.
        """
        # Create a generic item representing the collection strategy
        collection_item = self._make_item(None)
        # Resolve it to get the base locator (e.g. matching all rows)
        base_locator = collection_item.resolve(page)
        # Return all matching locators
        return base_locator.all()


class Repeated:
    """Декларативная repeatable-коллекция однотипных дочерних элементов."""

    def __init__(
        self,
        prototype: Element,
        *,
        name: str | None = None,
        owner: Element | None = None,
        scope: Element | None = None,
        accessible_name: str | None = None,
        text: ElementTextInput | None = None,
        label: str | None = None,
        placeholder: str | None = None,
        test_id: str | None = None,
        alt_text: str | None = None,
        title: str | None = None,
        html_name: str | None = None,
        locator: str | None = None,
        exact: bool = False,
        description: str | None = None,
        static_screenshot_path: str | None = None,
        static_aria_snapshot_path: str | None = None,
        aria_ref: str | None = None,
        url: str | None = None,
        role: str | None = None,
    ) -> None:
        self._prototype = prototype
        self.name = name or f"{prototype.name}s"
        self._owner = owner
        self._scope = _build_repeated_scope_element(
            name=self.name,
            scope=scope,
            accessible_name=accessible_name,
            text=text,
            label=label,
            placeholder=placeholder,
            test_id=test_id,
            alt_text=alt_text,
            title=title,
            html_name=html_name,
            locator=locator,
            exact=exact,
            description=description,
            static_screenshot_path=static_screenshot_path,
            static_aria_snapshot_path=static_aria_snapshot_path,
            aria_ref=aria_ref,
            url=url,
            role=role,
        )
        if self._scope is not None:
            if not self._scope.name:
                self._scope.name = self.name
            self._scope.parent = owner
            self._prototype.parent = self._scope
        elif owner is not None:
            self._prototype.parent = owner

    def bind(self, *, owner: Element, alias: str | None = None) -> "Repeated":
        prototype_clone = _clone_bound_element(self._prototype)
        scope_clone = (
            _clone_bound_element(self._scope)
            if isinstance(self._scope, Element)
            else None
        )
        repeated = Repeated(
            prototype=prototype_clone,
            name=self.name or alias,
            owner=owner,
            scope=scope_clone,
        )
        if alias and not repeated.name:
            repeated.name = alias
        return repeated

    @property
    def scope(self) -> Element | None:
        return self._scope

    @property
    def aria_ref(self) -> str | None:
        if self._scope is None:
            return None
        return self._scope.aria_ref

    def __call__(self, text: str | None = None, **kwargs: object) -> Element:
        item = self._make_item(None)
        if text:
            item = item.filter(has_text=text)
        return item

    def _make_item(self, index: int | None) -> Element:
        if self._owner is None:
            raise ValueError(
                f"Repeatable коллекция '{self.name}' не привязана к контейнеру."
            )
        item_owner = self._scope if self._scope is not None else self._owner
        return _make_repeated_item(
            owner=item_owner,
            prototype=self._prototype,
            index=index,
        )

    def __getitem__(self, index: int) -> Element:
        if not isinstance(index, int):
            raise IndexError("Index must be int")
        return self._make_item(index)

    def get(self, index: int) -> Element:
        return self.__getitem__(index)

    def first(self) -> Element:
        return self._make_item(0)

    def last(self) -> Element:
        return self._make_item(-1)

    def nth(self, index: int) -> Element:
        return self.__getitem__(index)

    def with_text(self, text: str, *, exact: bool = True) -> Element:
        item = self._make_item(None)
        return item.filter(has_text=text)

    def filter(
        self,
        has_text: str | None = None,
        has_not_text: str | None = None,
        has: "Element" | LocatorLike | None = None,
        has_not: "Element" | LocatorLike | None = None,
    ) -> "Repeated":
        new_prototype = self._prototype.filter(
            has_text=has_text, has_not_text=has_not_text, has=has, has_not=has_not
        )
        scope_clone = (
            _clone_bound_element(self._scope)
            if isinstance(self._scope, Element)
            else None
        )
        return Repeated(
            owner=self._owner,
            prototype=new_prototype,
            name=self.name,
            scope=scope_clone,
        )

    def resolve_all(self, page: BrowserPageLike) -> list[LocatorLike]:
        collection_item = self._make_item(None)
        base_locator = collection_item.resolve(page)
        return base_locator.all()


def _build_repeated_scope_element(
    *,
    name: str,
    scope: Element | None,
    accessible_name: str | None,
    text: ElementTextInput | None,
    label: str | None,
    placeholder: str | None,
    test_id: str | None,
    alt_text: str | None,
    title: str | None,
    html_name: str | None,
    locator: str | None,
    exact: bool,
    description: str | None,
    static_screenshot_path: str | None,
    static_aria_snapshot_path: str | None,
    aria_ref: str | None,
    url: str | None,
    role: str | None,
) -> Element | None:
    has_inline_scope = (
        any(
            value not in (None, "", False)
            for value in (
                accessible_name,
                text,
                label,
                placeholder,
                test_id,
                alt_text,
                title,
                html_name,
                locator,
                description,
                static_screenshot_path,
                static_aria_snapshot_path,
                aria_ref,
                url,
                role,
            )
        )
        or exact
    )

    if scope is not None and has_inline_scope:
        raise ValueError(
            f"Repeatable коллекция '{name}' не может одновременно использовать "
            "scope=Element и inline scope-поля."
        )

    if scope is not None:
        return scope
    if not has_inline_scope:
        return None

    return Element(
        name=name,
        accessible_name=accessible_name,
        text=text,
        label=label,
        placeholder=placeholder,
        test_id=test_id,
        alt_text=alt_text,
        title=title,
        html_name=html_name,
        locator=locator,
        exact=exact,
        description=description,
        static_screenshot_path=static_screenshot_path,
        static_aria_snapshot_path=static_aria_snapshot_path,
        aria_ref=aria_ref,
        url=url,
        role=role,
    )


# --- Примитивные элементы ---


@dataclass
class Button(Element):
    role: str = field(default="button", init=False)


@dataclass
class TextField(Element):
    role: str = field(default="textbox", init=False)


@dataclass
class Link(Element):
    role: str = field(default="link", init=False)


@dataclass
class Checkbox(Element):
    role: str = field(default="checkbox", init=False)


@dataclass
class Radio(Element):
    role: str = field(default="radio", init=False)


@dataclass
class Heading(Element):
    role: str = field(default="heading", init=False)


@dataclass
class Paragraph(Element):
    role: str = field(default="paragraph", init=False)


@dataclass
class Strong(Element):
    role: str = field(default="strong", init=False)


@dataclass
class ListElement(Element):
    role: str = field(default="list", init=False)


@dataclass
class ListItem(Element):
    role: str = field(default="listitem", init=False)


def _collect_declarative_element_prototypes(
    owner_cls: type[Element],
) -> dict[str, Element | Repeated]:
    collected: dict[str, Element | Repeated] = {}
    for base_cls in reversed(owner_cls.mro()):
        if not issubclass(base_cls, Element):
            continue
        for attr_name, attr_value in base_cls.__dict__.items():
            if attr_name.startswith("_"):
                continue
            if _is_reserved_namespace_attribute(owner_cls, attr_name, attr_value):
                continue
            if isinstance(attr_value, (Element, Repeated)):
                collected[attr_name] = attr_value
    return collected


def _is_reserved_namespace_attribute(
    owner_cls: type[Element],
    attr_name: str,
    attr_value: object,
) -> bool:
    if not isinstance(attr_value, Element):
        return False
    if attr_name != "elements":
        return False
    return any(base.__name__ == "TableRow" for base in owner_cls.mro())


def _column_title(column: int | str | Enum) -> str:
    if isinstance(column, Enum):
        return str(column.value)
    return str(column)


def _resolve_column_member(
    columns_enum: type[Enum] | None,
    column: str | Enum,
) -> Enum:
    if columns_enum is None:
        raise ValueError("Таблица не содержит объявленного Enum колонок.")

    if isinstance(column, columns_enum):
        return column

    target_value = _column_title(column)
    for member in columns_enum:
        if str(member.value) == target_value:
            return member

    available_columns = ", ".join(str(member.value) for member in columns_enum)
    raise ValueError(
        f"Колонка '{target_value}' не найдена. Доступные колонки: {available_columns}."
    )


def _column_namespace_alias(
    column: Enum, *, namespace: Literal["filters", "elements"]
) -> str:
    alias = to_snake_case(column.name)
    reserved_names = {
        attr_name for attr_name in dir(Element) if not attr_name.startswith("_")
    }
    if alias not in reserved_names:
        return alias
    suffix = "_filter" if namespace == "filters" else "_element"
    return f"{alias}{suffix}"


def _configure_scope_locator(element: Element, locator: str = ":scope") -> None:
    element.locator = locator
    element._strategies = [Strategy.LOCATOR]


def _clone_bound_element(prototype: ElementT) -> ElementT:
    cloned = copy.copy(prototype)
    cloned.parent = None
    cloned._filters = list(prototype._filters)
    cloned._shortcut_cache = {}
    if isinstance(prototype.variants, list):
        cloned.variants = list(prototype.variants)
    if prototype._strategies is not None:
        cloned._strategies = list(prototype._strategies)
    if prototype._elements is None:
        cloned._elements = None
        return cloned

    cloned._elements = {}
    for child_name, child_value in prototype._elements.items():
        if isinstance(child_value, Element):
            child_clone = _clone_bound_element(child_value)
            child_clone.parent = cloned
            cloned._elements[child_name] = child_clone
            setattr(cloned, child_name, child_clone)
            continue

        if isinstance(child_value, Repeated):
            repeated_clone = child_value.bind(owner=cloned, alias=child_name)
            cloned._elements[child_name] = repeated_clone
            setattr(cloned, child_name, repeated_clone)
            continue

        prototype_element_list = child_value
        prototype_clone = _clone_bound_element(prototype_element_list._prototype)
        list_clone = ElementList(
            owner=cloned,
            prototype=prototype_clone,
            name=prototype_element_list.name,
        )
        cloned._elements[child_name] = list_clone
        setattr(cloned, child_name, list_clone)
    return cloned


def _header_locators_from_container(base: LocatorLike) -> list[LocatorLike]:
    return base.locator(
        "xpath=(.//*[self::tr or @role='row'][./*[self::th or @role='columnheader']])[1]/*[self::th or @role='columnheader']"
    ).all()


def _normalize_cell_prototype(prototype: Element | None) -> Element:
    if prototype is None:
        text_element = Text(locator=":scope")
        _configure_scope_locator(text_element)
        text_element.name = "value"
        return text_element

    cloned = _clone_bound_element(prototype)
    if not cloned.name:
        cloned.name = "value"
    if (
        isinstance(cloned, Text)
        and cloned.locator is None
        and cloned.aria_ref is None
        and cloned.test_id is None
    ):
        _configure_scope_locator(cloned)
    return cloned


def _normalize_filter_prototype(
    prototype: BaseColumnFilter | None,
) -> BaseColumnFilter | None:
    if prototype is None:
        return None
    cloned = _clone_bound_element(prototype)
    if not cloned.name:
        cloned.name = "filter"
    return cloned


@dataclass
class TableRow(Element):
    role: str = field(default="row", init=False)
    _where_criteria: TableWhereCriteria | None = field(
        default=None, repr=False, init=False
    )

    def __getattribute__(self, name: str) -> object:
        if name == "elements":
            return object.__getattribute__(self, "_get_bound_elements_namespace")()
        return super().__getattribute__(name)

    @property
    def checkbox(self) -> "Checkbox":
        table = self._require_parent_table()
        if not table.has_selection:
            raise ValueError(
                f"Таблица '{table.name}' не поддерживает checkbox выбора строк."
            )
        if hasattr(self, "_checkbox"):
            return self._checkbox
        cb = Checkbox(name="checkbox", accessible_name="")
        added = self.add_element(cb, alias="_checkbox")
        if not isinstance(added, Checkbox):
            raise TypeError("Ожидался Checkbox при добавлении '_checkbox'.")
        return added

    @checkbox.setter
    def checkbox(self, value: "Checkbox") -> None:
        self._checkbox = value

    @property
    def expander(self) -> "Button":
        table = self._require_parent_table()
        if not table.has_expander:
            raise ValueError(f"Таблица '{table.name}' не поддерживает раскрытие строк.")
        if hasattr(self, "_expander"):
            return self._expander
        btn = Button(name="expander", accessible_name="")
        # Common UI library selectors for row expanders like Ant Design
        btn.locator = 'css=button.ant-table-row-expand-icon, .ant-table-row-expand-icon-cell, button[aria-expanded], [role="button"][aria-expanded]'
        btn._strategies = [Strategy.LOCATOR]
        added = self.add_element(btn, alias="_expander")
        if not isinstance(added, Button):
            raise TypeError("Ожидался Button при добавлении '_expander'.")
        return added

    @expander.setter
    def expander(self, value: "Button") -> None:
        self._expander = value

    def _get_playwright_locator(
        self,
        base: QueryContextLike,
        *,
        page: BrowserPageLike,
        resolution_stack: set[int],
    ) -> QueryContextLike:
        # Если это навигационный элемент, используем базовую логику
        if self._nav_type:
            return super()._get_playwright_locator(
                base,
                page=page,
                resolution_stack=resolution_stack,
            )

        locator = super()._get_playwright_locator(
            base,
            page=page,
            resolution_stack=resolution_stack,
        )
        if not isinstance(locator, LocatorLike):
            raise TypeError(
                "Фильтрация строки по where требует зарезолвленный локатор строки."
            )
        if not self._where_criteria:
            return locator

        table = self._require_parent_table()
        header_base = table._resolve_header_context(locator.page)
        header_locs = _header_locators_from_container(header_base)
        # Clean up whitespace and newlines for robust matching
        headers = [
            " ".join((h.text_content() or "").strip().split()) for h in header_locs
        ]

        if not headers:
            table_name = self.parent.name if self.parent is not None else self.name
            raise RuntimeError(
                f"Таблица '{table_name}' не содержит заголовков. "
                "Фильтр where требует явную шапку таблицы."
            )

        filtered = locator
        if not isinstance(base, LocatorLike):
            raise TypeError(
                "Фильтрация строки по where требует локатор таблицы, а не корневую страницу."
            )
        table_base = base
        for col_name, value in (self._where_criteria or {}).items():
            if not isinstance(col_name, (str, Enum)):
                raise TypeError(
                    "Ключ where-критерия таблицы должен быть строкой или Enum."
                )
            if not isinstance(value, (str, Enum)):
                raise TypeError(
                    "Значение where-критерия таблицы должно быть строкой или Enum."
                )
            # Resolve Enum to string
            col_str = col_name.value if isinstance(col_name, Enum) else str(col_name)
            val_str = value.value if isinstance(value, Enum) else str(value)

            try:
                col_index = headers.index(col_str)
            except ValueError as error:
                table_name = self.parent.name if self.parent is not None else self.name
                available_headers = ", ".join(headers)
                raise RuntimeError(
                    f"Колонка '{col_str}' не найдена в таблице '{table_name}'. "
                    f"Доступные заголовки: {available_headers}."
                ) from error

            # Используем XPath с position() для выбора конкретной ячейки ВНУТРИ строки.
            # Индексация XPath начинается с 1. Передаем этот локатор в has=.
            cell_xpath = f"./*[self::td or @role='cell' or self::th or @role='rowheader'][{col_index + 1}]"
            cell_in_row = table_base.page.locator(f"xpath={cell_xpath}").filter(
                has_text=val_str
            )
            filtered = filtered.filter(has=cell_in_row)
        return filtered

    def cell(self, column: int | str | Enum) -> "TableCell":
        col_str = _column_title(column)

        if isinstance(column, int):
            item = TableCell(name=f"cell_{column}", accessible_name="", index=column)
        else:
            item = TableCell(name="cell", accessible_name="", column_header=col_str)
        item.parent = self
        return item

    def _require_parent_table(self) -> "Table":
        if not isinstance(self.parent, Table):
            raise ValueError(
                f"Строка '{self.name}' должна принадлежать Table для typed API."
            )
        return self.parent

    def _require_declared_column(self, column: str | Enum) -> Enum:
        table = self._require_parent_table()
        return _resolve_column_member(table.columns, column)

    def _element_for_column(self, column: str | Enum) -> Element:
        table = self._require_parent_table()
        declared_column = self._require_declared_column(column)
        prototype = table._get_cell_binding(declared_column)
        if prototype is None:
            raise ValueError(
                f"Колонка '{declared_column.value}' таблицы '{table.name}' не содержит элемента ячейки."
            )
        bound_element = _clone_bound_element(prototype)
        bound_element.parent = self.cell(declared_column)
        return bound_element

    def _require_cell_element_type(
        self,
        column: str | Enum,
        expected_type: type[Element],
        *,
        method_name: str,
    ) -> Element:
        bound_element = self._element_for_column(column)
        if not isinstance(bound_element, expected_type):
            declared_column = self._require_declared_column(column)
            raise ValueError(
                f"Колонка '{declared_column.value}' не поддерживает метод '{method_name}'. "
                f"Ожидался элемент '{expected_type.__name__}', получен '{type(bound_element).__name__}'."
            )
        return bound_element

    def element(self, column: int | str | Enum) -> Element:
        if isinstance(column, int):
            raise TypeError("Метод 'element' требует строковую или Enum-колонку.")
        return self._element_for_column(column)

    def _get_bound_elements_namespace(self) -> Generic:
        existing_namespace = getattr(self, "_elements_namespace", None)
        if isinstance(existing_namespace, Generic):
            return existing_namespace

        namespace_prototype = getattr(type(self), "elements", None)
        if not isinstance(namespace_prototype, Generic):
            raise ValueError(
                f"Строка '{self.name}' не содержит typed alias namespace 'elements'."
            )

        namespace = _clone_bound_element(namespace_prototype)
        if namespace._elements is None:
            raise TypeError(
                f"Namespace 'elements' строки '{self.name}' должен содержать дочерние элементы."
            )

        table = self._require_parent_table()
        if table.columns is None:
            raise ValueError(
                f"Таблица '{table.name}' не содержит Enum колонок для namespace 'elements'."
            )

        column_by_alias = {
            _column_namespace_alias(member, namespace="elements"): member
            for member in table.columns
        }
        namespace_children = {
            child_name: child_value
            for child_name, child_value in namespace._elements.items()
            if isinstance(child_value, Element)
        }

        for alias, child in namespace_children.items():
            declared_column = column_by_alias.get(alias)
            if declared_column is None:
                raise ValueError(
                    f"Namespace 'elements' строки '{self.name}' содержит поле '{alias}', "
                    "которое не соответствует ни одной колонке таблицы."
                )
            bound_element = self._element_for_column(declared_column)
            if not isinstance(bound_element, type(child)):
                raise TypeError(
                    f"Namespace 'elements' строки '{self.name}' для поля '{alias}' "
                    f"ожидал '{type(child).__name__}', получен '{type(bound_element).__name__}'."
                )
            namespace._elements[alias] = bound_element
            setattr(namespace, alias, bound_element)

        self._elements_namespace = namespace
        return namespace

    def value(self, column: int | str | Enum, page: BrowserPageLike) -> str:
        if isinstance(column, int):
            raise TypeError("Метод 'value' требует строковую или Enum-колонку.")
        self._require_cell_element_type(
            column,
            Text,
            method_name="value",
        )
        locator = self.cell(column).resolve(page)
        raw_value = locator.evaluate("""el => {
                const clone = el.cloneNode(true);
                clone.querySelectorAll(
                    'input, select, button, svg, [role="button"], [role="switch"], [role="combobox"], [role="spinbutton"]'
                ).forEach(node => node.remove());
                return clone.textContent.trim().replace(/\\s+/g, ' ');
            }""")
        if not isinstance(raw_value, str):
            raise TypeError("Ячейка таблицы должна возвращать строковый текст.")
        return raw_value

    @property
    def details(self) -> "Generic":
        if hasattr(self, "_details"):
            details = self._details
            if isinstance(details, Generic):
                return details
            raise TypeError("Свойство '_details' должно быть Generic.")

        table = self._require_parent_table()
        details_cls = table.get_details_type()
        if details_cls is None:
            raise ValueError(
                f"Таблица '{table.name}' не поддерживает details для раскрытой строки."
            )

        details = details_cls(name="details")
        should_detach_parent = (
            details.aria_ref is not None or details.locator is not None
        )
        if details.aria_ref is None and details.locator is None:
            _configure_scope_locator(
                details,
                (
                    "xpath=following-sibling::*[self::tr or @role='row']"
                    "[count(./*[self::td or @role='cell' or self::th or @role='rowheader']) = 1][1]"
                ),
            )
            details.parent = self
        added = self.add_element(details, alias="_details")
        if not isinstance(added, Generic):
            raise TypeError("Ожидался Generic при добавлении '_details'.")
        if should_detach_parent:
            added.parent = None
        return added

    @details.setter
    def details(self, value: "Generic") -> None:
        self._details = value


@dataclass
class Table(Element):
    role: str = field(default="table", init=False)
    columns: type[Enum] | None = field(default=None, kw_only=True)
    row_type: type["TableRow"] = field(default=TableRow, kw_only=True)
    details_type: type["Generic"] | None = field(default=None, kw_only=True)
    header_ref: str | None = field(default=None, kw_only=True)
    header_index: int | None = field(default=None, kw_only=True)
    has_selection: bool = field(default=False, kw_only=True)
    has_expander: bool = field(default=False, kw_only=True)

    def __post_init__(self) -> None:
        super().__post_init__()

        declared_columns = self.columns or getattr(type(self), "Columns", None)
        if declared_columns is not None:
            if not isinstance(declared_columns, type) or not issubclass(
                declared_columns, Enum
            ):
                raise TypeError(
                    f"Таблица '{self.name}' должна содержать Columns как Enum-класс."
                )
            self.columns = declared_columns

        declared_row_type = getattr(type(self), "Row", None)
        if declared_row_type is not None:
            if not isinstance(declared_row_type, type) or not issubclass(
                declared_row_type, TableRow
            ):
                raise TypeError(
                    f"Таблица '{self.name}' должна содержать Row как подкласс TableRow."
                )
            self.row_type = declared_row_type

        if self.details_type is None:
            declared_details_type = getattr(type(self), "Details", None)
            if declared_details_type is not None:
                if not isinstance(declared_details_type, type) or not issubclass(
                    declared_details_type, Generic
                ):
                    raise TypeError(
                        f"Таблица '{self.name}' должна содержать Details как подкласс Generic."
                    )
                self.details_type = declared_details_type

        declared_selection = getattr(type(self), "selection", None)
        if isinstance(declared_selection, bool):
            self.has_selection = declared_selection

        declared_expansion = getattr(type(self), "expansion", None)
        if isinstance(declared_expansion, bool):
            self.has_expander = declared_expansion

    @property
    def rows(self) -> ElementList:
        existing_rows = getattr(self, "_rows", None)
        if isinstance(existing_rows, ElementList):
            return existing_rows

        # Priority: 1. Nested Row class, 2. row_type kwarg, 3. Default TableRow
        row_cls = getattr(self, "Row", self.row_type)
        prototype = row_cls(name="row", accessible_name="")

        return self.add_element_list(prototype, alias="_rows", overwrite=True)

    @property
    def body_rows(self) -> ElementList:
        """
        Возвращает список строк, исключая заголовок (thead).
        Использует фильтрацию по отсутствию предка thead.
        """
        existing_body_rows = getattr(self, "_body_rows", None)
        if isinstance(existing_body_rows, ElementList):
            return existing_body_rows

        row_cls = getattr(self, "Row", self.row_type)
        prototype = row_cls(name="row", accessible_name="")

        # Override strategy to use restrictive XPath
        # We target rows that are NOT inside a thead.
        # XPath: .//*[self::tr or @role="row"][not(ancestor::thead)]
        prototype.role = None  # Disable role strategy
        prototype.locator = 'xpath=.//*[self::tr or @role="row"][not(ancestor::thead)]'

        # Force LOCATOR strategy
        prototype._strategies = [Strategy.LOCATOR]

        return self.add_element_list(prototype, alias="_body_rows", overwrite=True)

    def row(
        self,
        index: int | None = None,
        *,
        where: TableWhereCriteria | None = None,
    ) -> "TableRow":
        # Priority: 1. Nested Row class, 2. row_type kwarg, 3. Default TableRow
        row_cls = getattr(self, "Row", self.row_type)

        if index is not None and where is None:
            item = row_cls(name=f"row_{index}", accessible_name="", index=index)
            item.parent = self
            return item
        if where is not None and index is None:
            item = row_cls(name="row_where", accessible_name="")
            setattr(item, "_where_criteria", where)
            item.parent = self
            return item

        raise ValueError("Must specify either index or where")

    def header(self, index: int | str | Enum) -> "ColumnHeader":
        col_str = _column_title(index)
        if isinstance(index, int):
            item = ColumnHeader(name=f"header_{index}", accessible_name="", index=index)
        else:
            item = ColumnHeader(name=f"header_{col_str}", accessible_name=col_str)
            setattr(item, "_table_column", index)
        item.parent = self
        return item

    @property
    def headers(self) -> ElementList:
        existing_headers = getattr(self, "_headers", None)
        if isinstance(existing_headers, ElementList):
            return existing_headers

        prototype = ColumnHeader(name="header", accessible_name="")
        return self.add_element_list(prototype, alias="_headers", overwrite=True)

    def cell(self, row_index: int, column_index: int) -> "TableCell":
        row_el = self.row(index=row_index)
        cell_el = TableCell(
            name=f"cell_{row_index}_{column_index}",
            accessible_name="",
            index=column_index,
        )
        cell_el.parent = row_el
        return cell_el

    @property
    def pagination(self) -> "Navigation":
        if hasattr(self, "_pagination"):
            pagination = self._pagination
            if not isinstance(pagination, Navigation):
                raise TypeError("Свойство '_pagination' должно быть Navigation.")
            return pagination

        nav = Navigation(name="pagination", accessible_name="")
        nav._strategies = [Strategy.LOCATOR]
        nav.locator = 'css=.ant-pagination, nav[aria-label="pagination"], .pagination'
        added = self.add_element(nav, alias="_pagination")
        if not isinstance(added, Navigation):
            raise TypeError("Ожидался Navigation при добавлении '_pagination'.")
        return added

    def get_details_type(self) -> type["Generic"] | None:
        if self.details_type is not None:
            return self.details_type
        details_cls = getattr(self, "Details", None)
        if isinstance(details_cls, type):
            if not issubclass(details_cls, Generic):
                raise TypeError(
                    f"Details таблицы '{self.name}' должен быть подклассом Generic."
                )
            return details_cls
        details_cls = getattr(self, "DETAILS_TYPE", None)
        if details_cls is None:
            return None
        if not isinstance(details_cls, type) or not issubclass(details_cls, Generic):
            raise TypeError(
                f"DETAILS_TYPE таблицы '{self.name}' должен быть подклассом Generic."
            )
        return details_cls

    def _resolve_header_context(self, page: BrowserPageLike) -> LocatorLike:
        if self.header_ref is None and self.header_index is None:
            return self.resolve(page)

        if self.header_ref is not None:
            header_context = Element(
                name=f"{self.name}_header_context",
                aria_ref=self.header_ref,
                index=self.header_index,
            )
            return header_context.resolve(page)

        if self.locator is not None:
            header_context = Element(
                name=f"{self.name}_header_context",
                locator=self.locator,
                index=self.header_index,
            )
            header_context._strategies = [Strategy.LOCATOR]
            return header_context.resolve(page)

        raise ValueError(
            f"Таблица '{self.name}' содержит header_index без header_ref/locator."
        )

    def _get_cell_binding(self, column: str | Enum) -> Element | None:
        declared_column = _resolve_column_member(self.columns, column)
        if not isinstance(declared_column, TableColumn):
            return None
        return _normalize_cell_prototype(declared_column.cell_prototype)

    def _get_filter_binding(
        self,
        column: str | Enum,
    ) -> "BaseColumnFilter" | None:
        declared_column = _resolve_column_member(self.columns, column)
        if not isinstance(declared_column, TableColumn):
            return None
        return _normalize_filter_prototype(declared_column.filter_prototype)

    def _require_table_column(self, column: str | Enum) -> Enum:
        return _resolve_column_member(self.columns, column)

    def _filter_for_column(self, column: int | str | Enum) -> "BaseColumnFilter":
        if isinstance(column, int):
            raise TypeError("Метод filter(column) требует строковую или Enum-колонку.")

        declared_column = self._require_table_column(column)
        filter_binding = self._get_filter_binding(declared_column)
        if filter_binding is not None:
            filter_binding.parent = self.header(declared_column)
            return filter_binding

        raise ValueError(
            f"Колонка '{declared_column.value}' таблицы '{self.name}' не содержит фильтра."
        )

    def filter(
        self,
        has_text: str | Enum | None = None,
        has_not_text: str | None = None,
        has: "Element" | LocatorLike | None = None,
        has_not: "Element" | LocatorLike | None = None,
    ) -> "Element":
        if has_text is not None and (
            has_not_text is not None or has is not None or has_not is not None
        ):
            raise ValueError(
                "Table.filter(column) не поддерживает одновременную передачу "
                "позиционной колонки и kwargs фильтрации. "
                "Для runtime-фильтрации используйте только именованные аргументы."
            )
        if has_text is None:
            return super().filter(
                has_text=has_text,
                has_not_text=has_not_text,
                has=has,
                has_not=has_not,
            )
        if isinstance(has_text, Enum):
            return self._filter_for_column(has_text)
        if isinstance(has_text, str):
            return self._filter_for_column(has_text)
        return super().filter(
            has_text=has_text,
            has_not_text=has_not_text,
            has=has,
            has_not=has_not,
        )

    @property
    def filters(self) -> Generic:
        existing_namespace = getattr(self, "_filters_namespace", None)
        if isinstance(existing_namespace, Generic):
            return existing_namespace

        filters_cls = getattr(type(self), "Filters", None)
        if filters_cls is None:
            raise ValueError(
                f"Таблица '{self.name}' не содержит typed alias namespace 'Filters'."
            )
        if not isinstance(filters_cls, type) or not issubclass(filters_cls, Generic):
            raise TypeError(
                f"Таблица '{self.name}' должна содержать Filters как подкласс Generic."
            )

        namespace = filters_cls(name="filters")
        if namespace._elements is None:
            raise TypeError(
                f"Namespace 'Filters' таблицы '{self.name}' должен содержать дочерние элементы."
            )
        if self.columns is None:
            raise ValueError(
                f"Таблица '{self.name}' не содержит Enum колонок для namespace 'Filters'."
            )

        declared_columns_with_filter = {
            _column_namespace_alias(member, namespace="filters"): member
            for member in self.columns
            if self._get_filter_binding(member) is not None
        }
        namespace_children = {
            child_name: child_value
            for child_name, child_value in namespace._elements.items()
            if isinstance(child_value, Element)
        }

        missing_aliases = sorted(
            alias
            for alias in declared_columns_with_filter
            if alias not in namespace_children
        )
        if missing_aliases:
            raise ValueError(
                f"Namespace 'Filters' таблицы '{self.name}' не содержит поля: {', '.join(missing_aliases)}."
            )

        for alias, child in namespace_children.items():
            declared_column = declared_columns_with_filter.get(alias)
            if declared_column is None:
                raise ValueError(
                    f"Namespace 'Filters' таблицы '{self.name}' содержит поле '{alias}', "
                    "которое не соответствует ни одной фильтруемой колонке."
                )
            bound_filter = self._filter_for_column(declared_column)
            if not isinstance(bound_filter, type(child)):
                raise TypeError(
                    f"Namespace 'Filters' таблицы '{self.name}' для поля '{alias}' "
                    f"ожидал '{type(child).__name__}', получен '{type(bound_filter).__name__}'."
                )
            namespace._elements[alias] = bound_filter
            setattr(namespace, alias, bound_filter)

        self._filters_namespace = namespace
        return namespace

    @property
    def select_all_checkbox(self) -> "Checkbox":
        if not self.has_selection:
            raise ValueError(
                f"Таблица '{self.name}' не поддерживает checkbox выбора всех строк."
            )
        if hasattr(self, "_select_all_checkbox"):
            checkbox = self._select_all_checkbox
            if isinstance(checkbox, Checkbox):
                return checkbox
            raise TypeError("Свойство '_select_all_checkbox' должно быть Checkbox.")

        checkbox = Checkbox(name="select_all_checkbox", accessible_name="")
        if self.header_ref is not None:
            header_position = (self.header_index or 0) + 1
            _configure_scope_locator(
                checkbox,
                (
                    f'xpath=(//*[@data-persona-id="{self.header_ref}"])[{header_position}]'
                    "//*[self::input[@type='checkbox'] or @role='checkbox'][1]"
                ),
            )
        else:
            _configure_scope_locator(
                checkbox,
                (
                    "css=thead input[type='checkbox'], "
                    ".ant-table-thead input[type='checkbox'], "
                    "[role='columnheader'] input[type='checkbox']"
                ),
            )
            checkbox.parent = self
        added = self.add_element(checkbox, alias="_select_all_checkbox")
        if not isinstance(added, Checkbox):
            raise TypeError("Ожидался Checkbox при добавлении '_select_all_checkbox'.")
        if self.header_ref is not None:
            added.parent = None
        return added

    def get_all_data(self, page: BrowserPageLike) -> list[dict[str, str]]:
        """
        Извлекает данные из таблицы в виде списка словарей.
        Использует логику чистых заголовков и очистки ячеек.
        """
        headers = self.get_headers_data(page)
        if not headers:
            return []

        base = self.resolve(page)
        # Getting all rows that are NOT in thead
        row_locs = base.locator("tbody tr, tbody [role=row], tr[role=row]").all()

        script = """el => {
            const clone = el.cloneNode(true);
            clone.querySelectorAll('input, select, button, svg, [role="button"], .ant-checkbox-wrapper, .ant-table-row-expand-icon').forEach(n => n.remove());
            return clone.textContent.trim().replace(/\\s+/g, ' ');
        }"""

        result: list[dict[str, str]] = []
        for row in row_locs:
            # For each row, get its cells
            cells = [
                str(c.evaluate(script))
                for c in row.locator("td, [role=cell], th, [role=rowheader]").all()
            ]

            # Match cells to headers
            row_data = {}
            for i in range(min(len(headers), len(cells))):
                row_data[headers[i]] = cells[i]

            if row_data:
                result.append(row_data)

        return result

    def get_headers_data(self, page: BrowserPageLike) -> list[str]:
        """
        Извлекает список заголовков из таблицы. Возвращает только "чистый" текст.
        """
        header_base = self._resolve_header_context(page)
        header_locs = _header_locators_from_container(header_base)
        script = """el => {
            const clone = el.cloneNode(true);
            clone.querySelectorAll('input, select, button, svg, [role="button"], .ant-checkbox-wrapper').forEach(n => n.remove());
            return clone.textContent.trim().replace(/\\s+/g, ' ');
        }"""
        return [str(h.evaluate(script)) for h in header_locs]

    def get_column_data(self, page: BrowserPageLike, column: object) -> list[str]:
        """
        Извлекает данные конкретной колонки в виде списка строк.
        """
        col_name = str(column.value) if hasattr(column, "value") else str(column)
        all_data = self.get_all_data(page)
        return [row.get(col_name, "") for row in all_data]

    def scroll(
        self,
        page: BrowserPageLike,
        direction: Literal["right", "left", "bottom", "top"] = "bottom",
        amount: int | str | None = None,
    ) -> None:
        """
        Скроллит таблицу в заданном направлении.
        """
        loc = self.resolve(page)
        amt_js = str(amount) if isinstance(amount, int) else "null"
        script = f"""
            el => {{
                let target = el.querySelector('.ant-table-body, .ant-table-content, .table-responsive') || el;
                let val = {amt_js};
                if ('{direction}' === 'bottom') target.scrollTop = val !== null ? (target.scrollTop + val) : target.scrollHeight;
                else if ('{direction}' === 'top') target.scrollTop = val !== null ? (target.scrollTop - val) : 0;
                else if ('{direction}' === 'right') target.scrollLeft = val !== null ? (target.scrollLeft + val) : target.scrollWidth;
                else if ('{direction}' === 'left') target.scrollLeft = val !== null ? (target.scrollLeft - val) : 0;
            }}
        """
        loc.evaluate(script)


@dataclass
class ListBox(Element):
    role: str = field(default="listbox", init=False)
    options_enum: type[Enum] | None = None

    def get_option(self, value: Enum | str) -> "Element":
        """
        Retrieves an Option element by its Enum value or string text.
        Dynamic lookup: does not require pre-generated child fields.
        """
        text_value = str(value.value) if isinstance(value, Enum) else str(value)

        # 1. Create Option Element
        # We assume the option is a child of the listbox (standard ARIA)
        opt = Option(
            name=f"option_{to_snake_case(text_value)}", accessible_name=text_value
        )
        opt.parent = self
        return opt

    def select_option(
        self,
        page: BrowserPageLike,
        value: str | Enum | None = None,
        label: str | Enum | None = None,
        index: int | None = None,
        force: bool = False,
        **kwargs: object,
    ) -> None:
        """
        Selects an option within the ListBox.
        """
        # Determine target text/value
        target_val = value or label
        if isinstance(target_val, Enum):
            target_val = str(target_val.value)

        target_option: Element | None = None

        if target_val:
            target_option = self.get_option(target_val)
        elif index is not None:
            raise ValueError(
                "ListBox.select_option не поддерживает выбор по индексу без явного описания option-элементов."
            )

        if target_option:
            # Resolve and Click
            loc = target_option.resolve(page)
            # Ensure visible
            loc.scroll_into_view_if_needed()
            loc.click(force=force)
            return

        raise ValueError(
            "ListBox: Could not select option. Specify value/label (index not fully supported yet)."
        )


@dataclass
class Slider(Element):
    role: str = field(default="slider", init=False)


@dataclass
class ProgressBar(Element):
    role: str = field(default="progressbar", init=False)


@dataclass
class SearchBox(Element):
    role: str = field(default="searchbox", init=False)


@dataclass
class SpinButton(Element):
    role: str = field(default="spinbutton", init=False)


@dataclass
class Switch(Element):
    role: str = field(default="switch", init=False)


@dataclass
class Code(Element):
    role: str = field(default="code", init=False)


@dataclass
@dataclass
class BlockQuote(Element):
    role: str = field(default="blockquote", init=False)


@dataclass
class TableCell(Element):
    role: str = field(default="cell", init=False)
    column_header: str | None = None

    def _get_playwright_locator(
        self,
        base: QueryContextLike,
        *,
        page: BrowserPageLike,
        resolution_stack: set[int],
    ) -> QueryContextLike:
        if self.column_header:
            if not isinstance(base, LocatorLike):
                raise TypeError(
                    "TableCell с column_header требует LocatorLike как базовый контекст."
                )
            if not isinstance(self.parent, TableRow) or not isinstance(
                self.parent.parent, Table
            ):
                raise ValueError(
                    "TableCell с column_header должен принадлежать TableRow внутри Table."
                )

            table = self.parent.parent
            header_base = table._resolve_header_context(base.page)
            header_locs = _header_locators_from_container(header_base)
            headers = [
                " ".join((header.text_content() or "").strip().split())
                for header in header_locs
            ]
            target_header = " ".join(self.column_header.strip().split())
            try:
                column_index = headers.index(target_header)
            except ValueError as error:
                available_headers = ", ".join(headers)
                raise RuntimeError(
                    f"Колонка '{self.column_header}' не найдена в таблице '{table.name}'. "
                    f"Доступные заголовки: {available_headers}."
                ) from error

            return base.locator(
                f"xpath=./*[self::td or @role='cell' or self::th or @role='rowheader'][{column_index + 1}]"
            )

        return super()._get_playwright_locator(
            base,
            page=page,
            resolution_stack=resolution_stack,
        )


@dataclass
class ColumnHeader(Element):
    role: str = field(default="columnheader", init=False)

    def __getattribute__(self, name: str) -> object:
        if name == "filter":
            return object.__getattribute__(self, "_get_bound_filter")()
        return super().__getattribute__(name)

    def _get_playwright_locator(
        self,
        base: QueryContextLike,
        *,
        page: BrowserPageLike,
        resolution_stack: set[int],
    ) -> QueryContextLike:
        if self._nav_type:
            return super()._get_playwright_locator(
                base,
                page=page,
                resolution_stack=resolution_stack,
            )

        if (
            isinstance(base, LocatorLike)
            and self.accessible_name
            and not self.locator
            and self.role == "columnheader"
        ):
            table = self.parent
            if not isinstance(table, Table):
                raise ValueError(f"Заголовок '{self.name}' должен принадлежать Table.")
            header_base = table._resolve_header_context(base.page)
            header_locators = _header_locators_from_container(header_base)
            matching_locators = [
                locator
                for locator in header_locators
                if self.accessible_name
                in " ".join((locator.text_content() or "").split())
            ]
            if not matching_locators:
                return header_base.locator("th, [role=columnheader]").filter(
                    has_text=self.accessible_name
                )
            result = matching_locators[0]
            for locator in matching_locators[1:]:
                result = result.or_(locator)
            return result

        return super()._get_playwright_locator(
            base,
            page=page,
            resolution_stack=resolution_stack,
        )

    @property
    def checkbox(self) -> "Checkbox":
        if hasattr(self, "_checkbox"):
            return self._checkbox
        cb = Checkbox(name="checkbox", accessible_name="")
        added = self.add_element(cb, alias="_checkbox")
        if not isinstance(added, Checkbox):
            raise TypeError("Ожидался Checkbox при добавлении '_checkbox'.")
        return added

    @checkbox.setter
    def checkbox(self, value: "Checkbox") -> None:
        self._checkbox = value

    @property
    def filter_input(self) -> "TextField":
        if hasattr(self, "_filter_input"):
            return self._filter_input
        inp = TextField(name="filter_input", accessible_name="")
        inp._strategies = [Strategy.LOCATOR]
        inp.locator = "css=input"
        added = self.add_element(inp, alias="_filter_input")
        if not isinstance(added, TextField):
            raise TypeError("Ожидался TextField при добавлении '_filter_input'.")
        return added

    @filter_input.setter
    def filter_input(self, value: "TextField") -> None:
        self._filter_input = value

    @property
    def filter_button(self) -> "Button":
        if hasattr(self, "_filter_button"):
            return self._filter_button
        btn = Button(name="filter_button", accessible_name="")
        btn._strategies = [Strategy.LOCATOR]
        # General enough to hit ant-design filter icons or buttons
        btn.locator = 'css=button.ant-btn-icon-only, [role="button"], button, .ant-table-filter-trigger'
        added = self.add_element(btn, alias="_filter_button")
        if not isinstance(added, Button):
            raise TypeError("Ожидался Button при добавлении '_filter_button'.")
        return added

    @filter_button.setter
    def filter_button(self, value: "Button") -> None:
        self._filter_button = value

    def _get_bound_filter(self) -> "BaseColumnFilter":
        table = self.parent
        if not isinstance(table, Table):
            raise ValueError(
                f"Заголовок '{self.name}' должен принадлежать Table для доступа к filter."
            )

        table_column = getattr(self, "_table_column", None)
        if not isinstance(table_column, (Enum, str)):
            raise ValueError(
                f"Заголовок '{self.name}' не привязан к объявленной колонке. Используйте table.filter(column)."
            )
        filter_element = table._filter_for_column(table_column)
        if not isinstance(filter_element, BaseColumnFilter):
            raise TypeError("Ожидался BaseColumnFilter для заголовка таблицы.")
        return filter_element

    def get_clean_text(self, page: BrowserPageLike) -> str:
        """
        Возвращает чистый текст заголовка, игнорируя содержимое инпутов, кнопок, чекбоксов.
        """
        loc = self.resolve(page)
        script = """el => {
            const clone = el.cloneNode(true);
            clone.querySelectorAll('input, select, button, svg, [role="button"], .ant-checkbox-wrapper').forEach(n => n.remove());
            return clone.textContent.trim().replace(/\\s+/g, ' ');
        }"""
        return str(loc.evaluate(script))


@dataclass
class RowHeader(Element):
    role: str = field(default="rowheader", init=False)


@dataclass
class Grid(Element):
    role: str = field(default="grid", init=False)


@dataclass
class GridCell(Element):
    role: str = field(default="gridcell", init=False)


@dataclass
class Navigation(Element):
    role: str = field(default="navigation", init=False)


@dataclass
class Main(Element):
    role: str = field(default="main", init=False)


@dataclass
class Banner(Element):
    role: str = field(default="banner", init=False)


@dataclass
class ContentInfo(Element):
    role: str = field(default="contentinfo", init=False)


@dataclass
class Region(Element):
    role: str = field(default="region", init=False)


@dataclass
class Search(Element):
    role: str = field(default="search", init=False)


@dataclass
class Complementary(Element):
    role: str = field(default="complementary", init=False)


@dataclass
class Article(Element):
    role: str = field(default="article", init=False)


@dataclass
class Image(Element):
    role: str = field(default="img", init=False)


@dataclass
class Figure(Element):
    role: str = field(default="figure", init=False)


@dataclass
class Form(Element):
    role: str = field(default="form", init=False)


@dataclass
class Group(Element):
    role: str = field(default="group", init=False)


@dataclass
class RadioGroup(Element):
    role: str = field(default="radiogroup", init=False)

    def choice(self, value: Enum | str) -> Radio:
        accessible_name = str(value.value) if isinstance(value, Enum) else str(value)
        radio = Radio(
            name=f"{self.name}_{to_snake_case(accessible_name)}",
            accessible_name=accessible_name,
        )
        radio.parent = self
        return radio

    def by_variant(self, value: Enum | str) -> Radio:
        return self.choice(value)

    def select(self, page: BrowserPageLike, value: Enum | str) -> None:
        self.choice(value).resolve(page).click()


@dataclass
class Dialog(Element):
    role: str = field(default="dialog", init=False)


@dataclass
class AlertDialog(Element):
    role: str = field(default="alertdialog", init=False)


@dataclass
class Alert(Element):
    role: str = field(default="alert", init=False)


@dataclass
class Status(Element):
    role: str = field(default="status", init=False)


@dataclass
class Log(Element):
    role: str = field(default="log", init=False)


@dataclass
class Timer(Element):
    role: str = field(default="timer", init=False)


@dataclass
class Menu(Element):
    role: str = field(default="menu", init=False)


@dataclass
class MenuBar(Element):
    role: str = field(default="menubar", init=False)


@dataclass
class MenuItem(Element):
    role: str = field(default="menuitem", init=False)


@dataclass
class MenuItemCheckbox(Element):
    role: str = field(default="menuitemcheckbox", init=False)


@dataclass
class MenuItemRadio(Element):
    role: str = field(default="menuitemradio", init=False)


@dataclass
class TabList(Element):
    role: str = field(default="tablist", init=False)


@dataclass
class Tab(Element):
    role: str = field(default="tab", init=False)


@dataclass
class TabPanel(Element):
    role: str = field(default="tabpanel", init=False)


@dataclass
class Tree(Element):
    role: str = field(default="tree", init=False)


@dataclass
class TreeItem(Element):
    role: str = field(default="treeitem", init=False)


@dataclass
class Meter(Element):
    role: str = field(default="meter", init=False)


@dataclass
class ScrollBar(Element):
    role: str = field(default="scrollbar", init=False)


@dataclass
class Separator(Element):
    role: str = field(default="separator", init=False)


@dataclass
class Toolbar(Element):
    role: str = field(default="toolbar", init=False)


@dataclass
class Tooltip(Element):
    role: str = field(default="tooltip", init=False)


@dataclass
class Caption(Element):
    role: str = field(default="caption", init=False)


@dataclass
class Definition(Element):
    role: str = field(default="definition", init=False)


@dataclass
class Deletion(Element):
    role: str = field(default="deletion", init=False)


@dataclass
class Directory(Element):
    role: str = field(default="directory", init=False)


@dataclass
class Document(Element):
    role: str = field(default="document", init=False)


@dataclass
class Emphasis(Element):
    role: str = field(default="emphasis", init=False)


@dataclass
class Feed(Element):
    role: str = field(default="feed", init=False)


@dataclass
class Generic(Element):
    role: str = field(default="generic", init=False)


@dataclass
class BaseColumnFilter(Generic):
    popup_type: type["Generic"] | None = None

    def __post_init__(self) -> None:
        super().__post_init__()
        if not self.locator:
            _configure_scope_locator(self)

    def _variants_definition(self) -> ElementVariants | None:
        if self.Options is not None:
            return self.Options
        return self.variants

    def _resolve_clear_button(self) -> "Button":
        button = Button(name="clear_button", accessible_name="")
        _configure_scope_locator(
            button,
            "css=.ant-input-clear-icon, .ant-picker-clear, .ant-select-clear, [aria-label='close-circle']",
        )
        button.parent = self
        return button


@dataclass
class TextColumnFilter(BaseColumnFilter):
    @property
    def input(self) -> "TextField":
        text_input = TextField(name="input")
        _configure_scope_locator(text_input, "css=input")
        text_input.parent = self
        return text_input

    def set(self, page: BrowserPageLike, value: str) -> None:
        self.input.resolve(page).fill(value)

    def clear(self, page: BrowserPageLike) -> None:
        self._resolve_clear_button().resolve(page).click()


@dataclass
class TimeRangeColumnFilter(BaseColumnFilter):
    @property
    def start(self) -> "TextField":
        start_input = TextField(name="start", index=0)
        _configure_scope_locator(start_input, "css=input")
        start_input.parent = self
        return start_input

    @property
    def end(self) -> "TextField":
        end_input = TextField(name="end", index=1)
        _configure_scope_locator(end_input, "css=input")
        end_input.parent = self
        return end_input

    @property
    def clear_start(self) -> "Button":
        clear_button = Button(name="clear_start", accessible_name="", index=0)
        _configure_scope_locator(
            clear_button, "css=.ant-picker-clear, .ant-input-clear-icon"
        )
        clear_button.parent = self
        return clear_button

    @property
    def clear_end(self) -> "Button":
        clear_button = Button(name="clear_end", accessible_name="", index=1)
        _configure_scope_locator(
            clear_button, "css=.ant-picker-clear, .ant-input-clear-icon"
        )
        clear_button.parent = self
        return clear_button

    def set(
        self,
        page: BrowserPageLike,
        *,
        start: str | None = None,
        end: str | None = None,
    ) -> None:
        if start is not None:
            self.start.resolve(page).fill(start)
        if end is not None:
            self.end.resolve(page).fill(end)


@dataclass
class NumberColumnFilter(BaseColumnFilter):
    @property
    def input(self) -> "SpinButton":
        spinbutton = SpinButton(name="input")
        _configure_scope_locator(
            spinbutton,
            "css=[role='spinbutton'], input[role='spinbutton'], input[type='number'], .ant-input-number-input, .ant-input-number",
        )
        spinbutton.parent = self
        return spinbutton

    def set(self, page: BrowserPageLike, value: int | str) -> None:
        target = self.input.resolve(page)
        value_str = str(value)
        if hasattr(target, "fill"):
            target.fill(value_str)
            return
        raise TypeError("SpinButton должен поддерживать fill().")


@dataclass
class SingleSelectColumnFilter(BaseColumnFilter):
    @property
    def control(self) -> "Select":
        select = Select(name="control", variants=self._variants_definition())
        _configure_scope_locator(select, "css=select, [role='combobox']")
        select.parent = self
        return select

    def select(self, page: BrowserPageLike, value: str | Enum) -> None:
        self.control.select_option(page, label=value)

    def clear(self, page: BrowserPageLike) -> None:
        self._resolve_clear_button().resolve(page).click()


@dataclass
class MultiSelectColumnFilter(BaseColumnFilter):
    @property
    def control(self) -> "MultiSelect":
        control = MultiSelect(
            name="control",
            popup_type=self.popup_type,
            variants=self._variants_definition(),
        )
        _configure_scope_locator(control)
        control.parent = self
        return control

    @property
    def popup(self) -> "Generic":
        if self.popup_type is None:
            raise ValueError(
                f"Фильтр '{self.name}' не содержит popup_type для мультиселекта."
            )
        popup = self.popup_type(name="popup")
        _configure_scope_locator(
            popup,
            "css=.ant-select-dropdown, [role='listbox'], [data-test-id^='dropdown-container_']",
        )
        popup.parent = self
        popup_options = getattr(popup, "options", None)
        if isinstance(popup_options, Element):
            variants_definition = self._variants_definition()
            if variants_definition is not None:
                popup_options.apply_variants(variants_definition)
        return popup

    def open(self, page: BrowserPageLike) -> None:
        control_locator = self.control.control.resolve(page)
        is_native_multi = control_locator.evaluate("""el => {
                if (el.tagName === 'SELECT') {
                    return el.multiple;
                }
                return el.getAttribute('role') === 'listbox';
            }""")
        if not isinstance(is_native_multi, bool):
            raise TypeError("Определение типа мультиселекта должно возвращать bool.")
        if is_native_multi:
            return
        control_locator.click()

    def select(
        self,
        page: BrowserPageLike,
        values: list[str | Enum],
    ) -> None:
        if self.popup_type is None:
            control_locator = self.control.control.resolve(page)
            tag_name_raw = control_locator.evaluate("el => el.tagName.toLowerCase()")
            if not isinstance(tag_name_raw, str):
                raise TypeError(
                    "Мультиселект без popup_type должен вернуть строковый tagName."
                )
            role_raw = control_locator.get_attribute("role")
            normalized_values = [
                str(value.value) if isinstance(value, Enum) else str(value)
                for value in values
            ]
            if tag_name_raw == "select":
                control_locator.select_option(label=normalized_values)
                return
            if role_raw == "listbox":
                options = ListBox(name="options")
                _configure_scope_locator(options)
                options.parent = self.control
                for value in values:
                    options.select_option(page, value=value)
                return
            raise ValueError(
                "Мультиселект без popup_type должен быть либо native <select multiple>, "
                "либо элементом с role='listbox'."
            )

        self.open(page)
        popup = self.popup
        popup_options = getattr(popup, "options", None)
        if not isinstance(popup_options, ListBox):
            raise TypeError(
                f"Popup '{popup.name}' должен содержать ListBox в поле 'options'."
            )
        options = popup_options
        for value in values:
            options.select_option(page, value=value)

    def clear(self, page: BrowserPageLike) -> None:
        if self.popup_type is None:
            control_locator = self.control.control.resolve(page)
            tag_name_raw = control_locator.evaluate("el => el.tagName.toLowerCase()")
            if not isinstance(tag_name_raw, str):
                raise TypeError(
                    "Мультиселект без popup_type должен вернуть строковый tagName."
                )
            if tag_name_raw == "select":
                control_locator.evaluate("""el => {
                        [...el.options].forEach(option => {
                            option.selected = false;
                        });
                        el.dispatchEvent(new Event('change', { bubbles: true }));
                    }""")
                return
            raise ValueError(
                "Очистка мультиселекта без popup_type поддерживается только для native <select multiple>."
            )
        self._resolve_clear_button().resolve(page).click()


@dataclass
class Marquee(Element):
    role: str = field(default="marquee", init=False)


@dataclass
class Math(Element):
    role: str = field(default="math", init=False)


@dataclass
class Text(Element):
    """
    Element strictly identified by text.
    Requires 'text' to be set during initialization.
    """

    role: str = field(default="text", init=False)

    def __post_init__(self) -> None:
        super().__post_init__()


@dataclass
class NoneElement(Element):
    role: str = field(default="none", init=False)


@dataclass
class Select(Element):
    """
    Standard HTML <select> element.
    """

    role: str = field(default="combobox", init=False)
    options_enum: type[Enum] | None = None  # Optional Enum for fixed values

    def select_option(
        self,
        page: BrowserPageLike,
        value: str | Enum | None = None,
        label: str | Enum | None = None,
        index: int | None = None,
        **kwargs: object,
    ) -> None:
        locator = self.resolve(page)

        # Resolve Enum values
        if isinstance(value, Enum):
            value = value.value
        if isinstance(label, Enum):
            # For label, we might want the name or value depending on convention.
            # Usually label implies the visible text.
            # If Enum value is the text, use value.
            label = str(label.value)

        select_kwargs: dict[str, object] = {}
        if value is not None:
            select_kwargs["value"] = value
        if label is not None:
            select_kwargs["label"] = label
        if index is not None:
            select_kwargs["index"] = index

        locator.select_option(**select_kwargs, **kwargs)


@dataclass
class MultiSelect(Generic):
    popup_type: type["Generic"] | None = None

    def __post_init__(self) -> None:
        super().__post_init__()
        if not self.locator:
            _configure_scope_locator(self)

    @property
    def control(self) -> "Element":
        control = Element(name="control", role="combobox")
        _configure_scope_locator(
            control,
            "css=[role='combobox'], [role='listbox'], select[multiple], .ant-select-selector, input",
        )
        control.parent = self
        return control

    @property
    def popup(self) -> "Generic":
        if self.popup_type is None:
            raise ValueError(
                f"Мультиселект '{self.name}' не содержит popup_type для доступа к popup."
            )
        popup = self.popup_type(name="popup")
        _configure_scope_locator(
            popup,
            "css=.ant-select-dropdown, [role='listbox'], [data-test-id^='dropdown-container_']",
        )
        popup.parent = self
        popup_options = getattr(popup, "options", None)
        if isinstance(popup_options, Element):
            variants_definition: ElementVariants | None
            if self.Options is not None:
                variants_definition = self.Options
            else:
                variants_definition = self.variants
            if variants_definition is not None:
                popup_options.apply_variants(variants_definition)
        return popup


@dataclass
class Dropdown(Element):
    """
    Custom Dropdown component (Trigger + Options List).
    Assumes interaction: Click Trigger -> Click Option.
    """

    role: str = field(default="combobox", init=False)
    options_enum: type[Enum] | None = None

    def select_option(
        self,
        page: BrowserPageLike,
        value: str | Enum | None = None,
        label: str | Enum | None = None,
        index: int | None = None,
        **kwargs: object,
    ) -> None:
        # Resolve Enums
        if isinstance(value, Enum):
            value = str(value.value)
        if isinstance(label, Enum):
            # If the Enum value IS the label (common), use it.
            # If the Enum name is the label, use .name.
            # We assume value for now as standard.
            label = str(label.value)

        target_val = value if value is not None else label

        # 1. Resolve element and Check mechanism
        element = self.resolve(page)

        # Check if it is a native <select>
        tag_name_raw = element.evaluate("el => el.tagName", timeout=500)
        if not isinstance(tag_name_raw, str):
            raise TypeError("Dropdown: evaluate('tagName') должен возвращать строку.")
        tag_name = tag_name_raw.lower()

        if tag_name == "select":
            # Native Select: Use Playwright's optimized select_option
            select_kwargs: dict[str, object] = {}
            if value:
                select_kwargs["value"] = value
            if label:
                select_kwargs["label"] = label
            if index is not None:
                select_kwargs["index"] = index

            element.select_option(**select_kwargs, **kwargs)
            return

        # Custom Dropdown Logic
        trigger = element
        trigger.scroll_into_view_if_needed()

        force_raw = kwargs.get("force", False)
        if not isinstance(force_raw, bool):
            raise TypeError("Dropdown: параметр 'force' должен быть bool.")
        force = force_raw
        trigger.click(force=force)

        # Wait slightly for animation/portal mounting if needed?
        # Playwright usually handles this, but for some JS frameworks a small tick helps.
        # page.wait_for_timeout(100)

        if target_val:
            # 2. Select the option using Element Resolution
            # Create a temporary Option element for searching.
            # If we don't set parent, it resolves globally (fine for portals/roots).
            # But we can try to find it via specific role/name.

            # Primary Strategy: Role=option, Name=Target
            target_option = Option(name="temp_option", accessible_name=target_val)

            # Resolve it
            # If resolution fails (which it shouldn't for creation, but check count)
            opt_loc = target_option.resolve(page)

        elif index is not None:
            # Index strategy via global option role (or scoped if we had a parent)
            # Since Dropdown often uses portals, global option role index *might* be risky if multiple open.
            # But without a specific container locator, it's the best we have.
            # We assume only one dropdown active.
            target_option = Option(name=f"option_index_{index}", index=index)
            opt_loc = target_option.resolve(page)

        if target_option and opt_loc.count() > 0:
            # We found it!
            # Use the ELEMENT's resolve logic (which we did manually above to check count)
            # But to be clean we just use the locator we got.
            opt_loc.scroll_into_view_if_needed()
            opt_loc.click(force=force)
            return

        raise ValueError(
            f"Dropdown: Could not find option with label/value='{target_val}' or index='{index}'"
        )


@dataclass
class Note(Element):
    role: str = field(default="note", init=False)


@dataclass
class Option(Element):
    role: str = field(default="option", init=False)


@dataclass
class Presentation(Element):
    role: str = field(default="presentation", init=False)


@dataclass
class RowGroup(Element):
    role: str = field(default="rowgroup", init=False)


@dataclass
class Term(Element):
    role: str = field(default="term", init=False)


# Alias ComboBox to Dropdown to use Enhanced Logic
ComboBox = Dropdown
