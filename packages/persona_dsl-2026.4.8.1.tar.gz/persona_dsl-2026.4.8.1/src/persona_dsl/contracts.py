from __future__ import annotations

from collections.abc import Callable, Mapping, MutableMapping
from dataclasses import dataclass
from enum import Enum
from typing import (
    TYPE_CHECKING,
    Generic,
    Literal,
    Protocol,
    TypeAlias,
    TypedDict,
    TypeVar,
)

if TYPE_CHECKING:
    from .persona import Persona

ResultT = TypeVar("ResultT")
ProducedT = TypeVar("ProducedT", covariant=True)
ActualT = TypeVar("ActualT", contravariant=True)

_CAPTURED_OUTCOME_ERRORS = (
    AssertionError,
    AttributeError,
    IndexError,
    KeyError,
    LookupError,
    OSError,
    RuntimeError,
    TypeError,
    ValueError,
)


class _MissingOutcomeValue:
    pass


_MISSING_OUTCOME_VALUE = _MissingOutcomeValue()


class SupportsStringValue(Protocol):
    value: str


class RetryPolicyConfig(TypedDict, total=False):
    max_attempts: int
    delay: float
    backoff_mode: Literal["linear", "exp"]
    backoff_factor: float
    jitter: float
    retry_on: tuple[type[Exception], ...]
    retry_if: Callable[[Exception], bool]
    on_retry_action: Callable[[], None]


SkillLookupKey: TypeAlias = str | Enum | SupportsStringValue
SkillInstance: TypeAlias = object
SkillEntry: TypeAlias = tuple[SkillLookupKey, str, SkillInstance]
SkillStore: TypeAlias = MutableMapping[str, MutableMapping[str, SkillInstance]]
MemoryStore: TypeAlias = MutableMapping[str, object]
RetryConfigMap: TypeAlias = Mapping[str, RetryPolicyConfig]


SkillProvider: TypeAlias = Callable[["Persona", object, str], SkillInstance]


@dataclass(frozen=True)
class ExecutionOutcome(Generic[ResultT]):
    value: ResultT | _MissingOutcomeValue = _MISSING_OUTCOME_VALUE
    error: Exception | None = None

    @property
    def succeeded(self) -> bool:
        return self.error is None

    @property
    def failed(self) -> bool:
        return self.error is not None

    def require_error(self) -> Exception:
        if self.error is None:
            raise RuntimeError("ExecutionOutcome не содержит ошибку.")
        return self.error

    def require_value(self) -> ResultT:
        if self.error is not None:
            raise RuntimeError(
                "ExecutionOutcome содержит ошибку и не может вернуть значение."
            )
        if isinstance(self.value, _MissingOutcomeValue):
            raise RuntimeError("ExecutionOutcome не содержит значения.")
        return self.value


def capture_outcome(action: Callable[[], ResultT]) -> ExecutionOutcome[ResultT]:
    try:
        return ExecutionOutcome(value=action())
    except _CAPTURED_OUTCOME_ERRORS as error:
        return ExecutionOutcome(error=error)


class SupportsMake(Protocol):
    def make(self, persona: Persona) -> None: ...


class SupportsExecute(Protocol[ProducedT]):
    def execute(
        self, persona: Persona, *args: object, **kwargs: object
    ) -> ProducedT: ...


class SupportsGet(Protocol[ProducedT]):
    def get(self, persona: Persona, *args: object, **kwargs: object) -> ProducedT: ...


class SupportsCheck(Protocol[ActualT]):
    def check(self, persona: Persona, actual_value: ActualT) -> None: ...
