from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Table, TableWhereCriteria


class TableRowData(Ops):
    """
    Извлекает данные конкретной строки таблицы в виде словаря.
    Удобно для создания снепшотов по конкретным строкам.

    Пример:
        row_data = persona.get(TableRowData(table, where={Columns.ID: "1"}))
        # Возвращает: {"ID": "1", "Status": "Active", ...}
    """

    def __init__(self, table: Table, where: TableWhereCriteria) -> None:
        self.table = table
        self.where = where

    def _get_step_description(self, persona: Persona) -> str:
        return "Получение данных строки таблицы"

    def _perform(
        self, persona: Persona, *args: object, **kwargs: object
    ) -> dict[str, str]:
        if args or kwargs:
            raise TypeError(
                "TableRowData не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)

        # Получаем чистые заголовки через метод таблицы
        headers = self.table.get_headers_data(page)

        if not headers:
            raise ValueError(
                f"Не удалось найти заголовки в таблице '{self.table.name}'."
            )

        # Находим нужную строку через стандартный метод Table
        row_element = self.table.row(where=self.where)
        row_locator = row_element.resolve(page)

        # Скрипт очистки ячеек от интерактивного мусора
        script = """el => {
            const clone = el.cloneNode(true);
            clone.querySelectorAll('input, select, button, svg, [role="button"], .ant-checkbox-wrapper, .ant-table-row-expand-icon').forEach(n => n.remove());
            return clone.textContent.trim().replace(/\\s+/g, ' ');
        }"""

        # Получаем ячейки найденной строки
        cells = [
            str(c.evaluate(script))
            for c in row_locator.locator("td, [role=cell], th, [role=rowheader]").all()
        ]

        if not cells:
            raise ValueError(
                f"Строка с условиями {self.where} найдена, но ячейки пусты."
            )

        row_data: dict[str, str] = {}
        for i in range(min(len(headers), len(cells))):
            row_data[headers[i]] = cells[i]

        return row_data
