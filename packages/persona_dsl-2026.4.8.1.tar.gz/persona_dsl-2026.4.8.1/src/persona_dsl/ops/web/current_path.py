from urllib.parse import urlparse

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page


def _require_page_url(page: object) -> str:
    page_url = getattr(page, "url", None)
    if not isinstance(page_url, str) or not page_url:
        raise TypeError(
            "Браузерная страница должна предоставлять непустой строковый url."
        )
    return page_url


class CurrentPath(Ops):
    """Бизнес-факт: текущий path активной страницы браузера."""

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} запрашивает текущий путь страницы"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> str:
        """Возвращает текущий путь URL."""
        if args or kwargs:
            raise TypeError(
                "CurrentPath не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        full_url = _require_page_url(page)
        return urlparse(full_url).path
