from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Element, get_element_ui_label


class ElementAttribute(Ops):
    """
    Бизнес-операция: получить значение HTML-атрибута у элемента.
    Пример: href для ссылок, src для изображений, data-* и т.д.
    """

    def __init__(self, element: Element, attribute_name: str) -> None:
        self.element = element
        self.attribute_name = attribute_name

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} запрашивает атрибут '{self.attribute_name}' у элемента '{get_element_ui_label(self.element)}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> str | None:
        if args or kwargs:
            raise TypeError(
                "ElementAttribute не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        locator = self.element.resolve(page)
        return locator.get_attribute(self.attribute_name)
