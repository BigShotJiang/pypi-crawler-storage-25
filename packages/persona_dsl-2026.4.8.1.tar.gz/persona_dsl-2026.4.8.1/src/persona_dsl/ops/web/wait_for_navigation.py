from typing import Literal, TypeAlias

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page

LoadState: TypeAlias = Literal["commit", "domcontentloaded", "load", "networkidle"]


class WaitForNavigation(Ops):
    """
    Атомарное действие: дождаться загрузки страницы/сети.

    По умолчанию ждём состояния 'networkidle' для стабильности перед дальнейшими действиями/генерацией.
    """

    def __init__(
        self,
        state: LoadState = "networkidle",
        timeout: float | None = 60000,
    ) -> None:
        self.state = state
        self.timeout = timeout

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} ожидает состояние загрузки страницы '{self.state}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "WaitForNavigation не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        page.wait_for_load_state(self.state, timeout=self.timeout)
