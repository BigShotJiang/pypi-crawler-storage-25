from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Element, get_element_ui_label


class InputValue(Ops):
    """
    Бизнес-операция: получить текущее значение из поля ввода (input/textarea/select).
    Использует Playwright Locator.input_value() для корректного чтения значения.
    """

    def __init__(self, element: Element) -> None:
        self.element = element

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} запрашивает значение поля ввода '{get_element_ui_label(self.element)}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> str:
        if args or kwargs:
            raise TypeError(
                "InputValue не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        locator = self.element.resolve(page)
        return locator.input_value()
