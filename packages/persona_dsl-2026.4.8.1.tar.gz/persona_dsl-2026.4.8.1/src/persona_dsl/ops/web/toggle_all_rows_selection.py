from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Table


class ToggleAllRowsSelection(Ops):
    """
    Атомарное действие: переключает состояние главного чекбокса ("Выбрать все") в заголовке таблицы.
    """

    def __init__(self, table: Table, state: bool = True) -> None:
        if not isinstance(table, Table):
            raise TypeError(f"Ожидается элемент Table, получено {type(table)}")
        self.table = table
        self.state = state

    def _get_step_description(self, persona: Persona) -> str:
        action = "Выбирает все строки" if self.state else "Снимает выбор со всех строк"
        return f"{persona} {action} в {self.table.name}"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "ToggleAllRowsSelection не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)

        checkbox_loc = self.table.select_all_checkbox.resolve(page)

        if checkbox_loc.count() == 0:
            raise RuntimeError(
                f"Не удалось найти чекбокс 'Выбрать все' в заголовках таблицы {self.table.name}"
            )

        is_checked = checkbox_loc.is_checked()

        if is_checked != self.state:
            if self.state:
                checkbox_loc.check(force=True)
            else:
                checkbox_loc.uncheck(force=True)
