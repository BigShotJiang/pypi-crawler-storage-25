from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.ops.web.expand_table_row import detect_table_row_expanded_state
from persona_dsl.pages.elements import TableRow


class ExpectTableRowExpanded(Ops):
    """
    Проверяет, что строка таблицы находится в ожидаемом состоянии раскрытия.
    """

    def __init__(self, table_row: TableRow, state: bool = True):
        self.table_row = table_row
        self.state = state

    def _get_step_description(self, persona: Persona) -> str:
        expected = "раскрыта" if self.state else "свернута"
        return f"{persona} проверяет, что {self.table_row.name} {expected}"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "ExpectTableRowExpanded не принимает дополнительные аргументы выполнения."
            )
        page = require_browser_page(persona)
        expander_loc = self.table_row.expander.resolve(page)

        if expander_loc.count() == 0:
            raise RuntimeError(
                f"Не удалось найти элемент раскрытия для строки {self.table_row.name}"
            )

        actual_state = detect_table_row_expanded_state(
            expander_loc,
            row_name=self.table_row.name,
        )
        if actual_state != self.state:
            raise AssertionError(
                f"Ожидалось состояние раскрытия {self.state}, "
                f"но текущее состояние = {actual_state}."
            )
