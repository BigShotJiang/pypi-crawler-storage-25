"""Богатый ARIA-снепшот с использованием Persona Runtime (JS Kernel)."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Literal, Protocol, TypeAlias

import allure

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.utils.artifacts import RuntimeArtifacts, persist_text_artifact

AriaScalar: TypeAlias = str | int | float | bool | None
AriaPropValue: TypeAlias = AriaScalar | list[AriaScalar]
AriaPropMap: TypeAlias = dict[str, AriaPropValue]
AriaSnapshotObject: TypeAlias = dict[str, object]
AriaSnapshotChild: TypeAlias = str | AriaSnapshotObject
AriaSnapshotTree: TypeAlias = AriaSnapshotObject | list[AriaSnapshotChild]
AriaToggleState: TypeAlias = bool | Literal["mixed"] | None


class OptionProbeLocatorLike(Protocol):
    def count(self) -> int: ...
    def nth(self, index: int) -> "OptionProbeLocatorLike": ...
    def evaluate(self, expression: str, arg: object | None = None) -> object: ...
    def click(self, *, force: bool = False) -> None: ...


class OptionProbePageLike(Protocol):
    def locator(self, selector: str) -> OptionProbeLocatorLike: ...
    def evaluate(self, expression: str, arg: object | None = None) -> object: ...


_OPTION_PROBE_SCRIPT = r"""(element) => {
    const normalize = (value) => String(value ?? "").replace(/\s+/g, " ").trim();
    const collectOptions = (root) => {
        if (!root) {
            return [];
        }
        if (root.tagName === "SELECT") {
            return Array.from(root.options)
                .map((option) => normalize(option.label || option.textContent))
                .filter(Boolean);
        }
        return Array.from(root.querySelectorAll('[role="option"], option'))
            .map((option) => normalize(option.getAttribute("aria-label") || option.textContent))
            .filter(Boolean);
    };
    const splitIds = (value) => value ? value.split(/\s+/).filter(Boolean) : [];
    const targetIds = Array.from(
        new Set([
            ...splitIds(element.getAttribute("aria-controls")),
            ...splitIds(element.getAttribute("aria-owns")),
        ])
    );

    return {
        directOptions: collectOptions(element),
        targetIds,
        targets: targetIds.map((id) => {
            const target = document.getElementById(id);
            return {
                id,
                exists: target !== null,
                role: target ? target.getAttribute("role") : null,
                options: target ? collectOptions(target) : [],
            };
        }),
        disabled: element.matches(':disabled,[disabled],[aria-disabled="true"]'),
        ariaExpanded: element.getAttribute("aria-expanded"),
    };
}"""

_PROBE_BIND_ATTRIBUTE = "data-persona-probe-ref"
_BIND_PROBE_TARGET_SCRIPT = r"""([ref, attrName]) => {
    const runtime = window.__PERSONA__;
    let element = null;

    if (runtime && typeof runtime.find === "function") {
        element = runtime.find(ref);
    }

    if (!element) {
        element = Array.from(document.querySelectorAll("[data-persona-id]")).find(
            (candidate) => candidate.getAttribute("data-persona-id") === ref
        ) || null;
    }

    if (!element) {
        return false;
    }

    element.setAttribute(attrName, ref);
    return true;
}"""


@dataclass(frozen=True, slots=True)
class _OptionProbeTarget:
    id: str
    exists: bool
    role: str | None
    options: list[str]


@dataclass(frozen=True, slots=True)
class _OptionProbe:
    direct_options: list[str]
    target_ids: list[str]
    targets: list[_OptionProbeTarget]
    disabled: bool
    aria_expanded: str | None


def _coerce_prop_value(raw_value: object, *, path: str) -> AriaPropValue:
    if raw_value is None or isinstance(raw_value, (str, int, float, bool)):
        return raw_value
    if not isinstance(raw_value, list):
        raise TypeError(
            f"{path} должен быть скалярным значением или списком скаляров, получено: {type(raw_value).__name__}."
        )

    values: list[AriaScalar] = []
    for index, item in enumerate(raw_value):
        if not (item is None or isinstance(item, (str, int, float, bool))):
            raise TypeError(
                f"{path}[{index}] должен быть скалярным значением, получено: {type(item).__name__}."
            )
        values.append(item)
    return values


def _coerce_props(raw_value: object, *, path: str) -> AriaPropMap:
    if raw_value is None:
        return {}
    if not isinstance(raw_value, Mapping):
        raise TypeError(f"{path} должен быть словарём свойств.")

    props: AriaPropMap = {}
    for key, value in raw_value.items():
        if not isinstance(key, str):
            raise TypeError(f"{path}: ключ свойства должен быть строкой.")
        props[key] = _coerce_prop_value(value, path=f"{path}.{key}")
    return props


def _format_prop_value(value: AriaPropValue) -> str:
    if isinstance(value, list):
        return repr(value)
    return str(value)


def _coerce_toggle_state(raw_value: object, *, path: str) -> AriaToggleState:
    if raw_value is None:
        return None
    if isinstance(raw_value, bool):
        return raw_value
    if raw_value == "mixed":
        return "mixed"
    raise TypeError(f"{path} должен быть bool, 'mixed' или null.")


def _coerce_optional_bool(raw_value: object, *, path: str) -> bool | None:
    if raw_value is None:
        return None
    if not isinstance(raw_value, bool):
        raise TypeError(f"{path} должен быть bool или null.")
    return raw_value


def _coerce_optional_int(raw_value: object, *, path: str) -> int | None:
    if raw_value is None:
        return None
    if not isinstance(raw_value, int) or isinstance(raw_value, bool):
        raise TypeError(f"{path} должен быть целым числом или null.")
    return raw_value


def _coerce_optional_str(raw_value: object, *, path: str) -> str | None:
    if raw_value is None:
        return None
    if not isinstance(raw_value, str):
        raise TypeError(f"{path} должен быть строкой или null.")
    return raw_value


def _coerce_child(raw_value: object, *, path: str) -> AriaSnapshotChild:
    if isinstance(raw_value, str):
        return raw_value
    return _coerce_node(raw_value, path=path)


def _coerce_children(raw_value: object, *, path: str) -> list[AriaSnapshotChild]:
    if raw_value is None:
        return []
    if not isinstance(raw_value, list):
        raise TypeError(f"{path} должен быть списком дочерних узлов.")
    return [
        _coerce_child(item, path=f"{path}[{index}]")
        for index, item in enumerate(raw_value)
    ]


def _coerce_node(raw_value: object, *, path: str) -> AriaSnapshotObject:
    if not isinstance(raw_value, Mapping):
        raise TypeError(f"{path} должен быть объектом ARIA-снепшота.")

    role = _coerce_optional_str(raw_value.get("role"), path=f"{path}.role")
    if role is None:
        role = "generic"

    node: AriaSnapshotObject = {"role": role}

    name = _coerce_optional_str(raw_value.get("name"), path=f"{path}.name")
    if name is not None:
        node["name"] = name

    ref = _coerce_optional_str(raw_value.get("ref"), path=f"{path}.ref")
    if ref is not None:
        node["ref"] = ref

    checked = _coerce_toggle_state(raw_value.get("checked"), path=f"{path}.checked")
    if checked is not None:
        node["checked"] = checked

    pressed = _coerce_toggle_state(raw_value.get("pressed"), path=f"{path}.pressed")
    if pressed is not None:
        node["pressed"] = pressed

    for field_name in ("disabled", "expanded", "selected", "hidden"):
        bool_value = _coerce_optional_bool(
            raw_value.get(field_name), path=f"{path}.{field_name}"
        )
        if bool_value is not None:
            node[field_name] = bool_value

    level = _coerce_optional_int(raw_value.get("level"), path=f"{path}.level")
    if level is not None:
        node["level"] = level

    props = _coerce_props(raw_value.get("props"), path=f"{path}.props")
    if props:
        node["props"] = props

    children = _coerce_children(raw_value.get("children"), path=f"{path}.children")
    if children:
        node["children"] = children

    return node


def _coerce_snapshot_tree(raw_value: object) -> AriaSnapshotTree:
    if isinstance(raw_value, list):
        return [
            _coerce_child(item, path=f"snapshot[{index}]")
            for index, item in enumerate(raw_value)
        ]
    return _coerce_node(raw_value, path="snapshot")


def _iter_snapshot_nodes(root: AriaSnapshotTree) -> list[AriaSnapshotObject]:
    nodes: list[AriaSnapshotObject] = []

    def collect(node: AriaSnapshotChild) -> None:
        if isinstance(node, str):
            return
        nodes.append(node)
        raw_children = node.get("children")
        if raw_children is None:
            return
        if not isinstance(raw_children, list):
            raise TypeError("snapshot.children должен быть списком дочерних узлов.")
        for child in raw_children:
            if not isinstance(child, (str, dict)):
                raise TypeError(
                    "snapshot.children должен содержать только строки или объекты узлов."
                )
            collect(child)

    if isinstance(root, list):
        for child in root:
            collect(child)
    else:
        collect(root)
    return nodes


def _coerce_option_values(raw_value: object, *, path: str) -> list[str]:
    if raw_value is None:
        return []
    if not isinstance(raw_value, list):
        raise TypeError(f"{path} должен быть списком строк.")

    values: list[str] = []
    for index, item in enumerate(raw_value):
        if not isinstance(item, str):
            raise TypeError(f"{path}[{index}] должен быть строкой.")
        normalized = " ".join(item.split()).strip()
        if not normalized:
            raise TypeError(f"{path}[{index}] должен быть непустой строкой.")
        values.append(normalized)
    return values


def _coerce_probe_target(raw_value: object, *, path: str) -> _OptionProbeTarget:
    if not isinstance(raw_value, Mapping):
        raise TypeError(f"{path} должен быть объектом с данными о popup-контейнере.")

    target_id = _coerce_optional_str(raw_value.get("id"), path=f"{path}.id")
    if target_id is None:
        raise TypeError(f"{path}.id должен быть непустой строкой.")

    exists_raw = raw_value.get("exists")
    if not isinstance(exists_raw, bool):
        raise TypeError(f"{path}.exists должен быть bool.")

    return _OptionProbeTarget(
        id=target_id,
        exists=exists_raw,
        role=_coerce_optional_str(raw_value.get("role"), path=f"{path}.role"),
        options=_coerce_option_values(raw_value.get("options"), path=f"{path}.options"),
    )


def _coerce_option_probe(raw_value: object, *, path: str) -> _OptionProbe:
    if not isinstance(raw_value, Mapping):
        raise TypeError(f"{path} должен быть объектом с данными о вариантах.")

    disabled_raw = raw_value.get("disabled")
    if not isinstance(disabled_raw, bool):
        raise TypeError(f"{path}.disabled должен быть bool.")

    targets_raw = raw_value.get("targets")
    if not isinstance(targets_raw, list):
        raise TypeError(f"{path}.targets должен быть списком.")

    return _OptionProbe(
        direct_options=_coerce_option_values(
            raw_value.get("directOptions"),
            path=f"{path}.directOptions",
        ),
        target_ids=_coerce_option_values(
            raw_value.get("targetIds"), path=f"{path}.targetIds"
        ),
        targets=[
            _coerce_probe_target(item, path=f"{path}.targets[{index}]")
            for index, item in enumerate(targets_raw)
        ],
        disabled=disabled_raw,
        aria_expanded=_coerce_optional_str(
            raw_value.get("ariaExpanded"),
            path=f"{path}.ariaExpanded",
        ),
    )


def _merge_option_sets(
    *,
    existing_options: list[str],
    discovered_options: list[str],
    context: str,
) -> list[str]:
    if not existing_options:
        return discovered_options
    if not discovered_options:
        return existing_options
    if existing_options == discovered_options:
        return existing_options

    existing_set = set(existing_options)
    discovered_set = set(discovered_options)
    if existing_set < discovered_set:
        return discovered_options
    if discovered_set < existing_set:
        return existing_options

    raise RuntimeError(
        f"{context}: снимок и live-DOM вернули конфликтующие наборы значений. "
        f"Snapshot={existing_options}, live={discovered_options}."
    )


def _resolve_probe_options(probe: _OptionProbe, *, context: str) -> list[str]:
    candidate_sets: list[list[str]] = []
    if probe.direct_options:
        candidate_sets.append(probe.direct_options)

    for target in probe.targets:
        if target.options:
            candidate_sets.append(target.options)

    if not candidate_sets:
        return []

    unique_sets: dict[tuple[str, ...], list[str]] = {}
    for option_values in candidate_sets:
        unique_sets.setdefault(tuple(option_values), option_values)

    if len(unique_sets) != 1:
        rendered = ", ".join(str(list(values)) for values in unique_sets)
        raise RuntimeError(
            f"{context}: найдено несколько несовместимых наборов значений: {rendered}."
        )
    return next(iter(unique_sets.values()))


def _wait_for_dom_settle(page: OptionProbePageLike) -> None:
    page.evaluate("() => new Promise((resolve) => setTimeout(resolve, 100))")


def _bind_probe_target(page: OptionProbePageLike, *, ref: str, context: str) -> str:
    direct_locator = page.locator(f'[data-persona-id="{ref}"]')
    if direct_locator.count() > 0:
        return f'[data-persona-id="{ref}"]'

    bound = page.evaluate(_BIND_PROBE_TARGET_SCRIPT, [ref, _PROBE_BIND_ATTRIBUTE])
    if not isinstance(bound, bool):
        raise RuntimeError(
            f"{context}: runtime-привязка ref={ref!r} вернула некорректный тип {type(bound).__name__}."
        )
    if not bound:
        raise RuntimeError(
            f"{context}: не удалось связать snapshot ref={ref!r} с live-DOM ни через runtime, ни через data-persona-id."
        )
    return f'[{_PROBE_BIND_ATTRIBUTE}="{ref}"]'


def _collect_dynamic_options_for_ref(
    page: OptionProbePageLike,
    *,
    ref: str,
    role: str,
    context: str,
    occurrence_index: int,
) -> list[str]:
    selector = _bind_probe_target(page, ref=ref, context=context)
    locator = page.locator(selector)
    count = locator.count()
    if count == 0:
        raise RuntimeError(f"{context}: элемент с ref={ref!r} отсутствует в live-DOM.")
    if occurrence_index < 0:
        raise RuntimeError(
            f"{context}: индекс вхождения ref={ref!r} не может быть отрицательным."
        )
    if occurrence_index >= count:
        raise RuntimeError(
            f"{context}: для ref={ref!r} запрошено вхождение #{occurrence_index}, "
            f"но в live-DOM найдено только {count} элементов."
        )

    target_locator = (
        locator
        if count == 1 and occurrence_index == 0
        else locator.nth(occurrence_index)
    )

    initial_probe = _coerce_option_probe(
        target_locator.evaluate(_OPTION_PROBE_SCRIPT),
        path=f"{context}.probe",
    )
    initial_options = _resolve_probe_options(initial_probe, context=context)
    if initial_options:
        return initial_options

    if role != "combobox" or not initial_probe.target_ids or initial_probe.disabled:
        return []

    target_locator.click(force=True)
    _wait_for_dom_settle(page)
    after_open_probe = _coerce_option_probe(
        target_locator.evaluate(_OPTION_PROBE_SCRIPT),
        path=f"{context}.probe_after_open",
    )
    discovered_options = _resolve_probe_options(after_open_probe, context=context)

    should_restore = (
        initial_probe.aria_expanded != "true"
        and after_open_probe.aria_expanded == "true"
    )
    if should_restore:
        target_locator.click(force=True)
        _wait_for_dom_settle(page)

    return discovered_options


def enrich_snapshot_with_dynamic_options(
    page: OptionProbePageLike,
    snapshot_tree: AriaSnapshotTree,
) -> AriaSnapshotTree:
    ref_occurrences: dict[str, int] = {}
    for node in _iter_snapshot_nodes(snapshot_tree):
        role = _coerce_optional_str(node.get("role"), path="snapshot.role")
        ref = _coerce_optional_str(node.get("ref"), path="snapshot.ref")
        if role not in {"combobox", "listbox", "radiogroup"} or ref is None:
            continue

        occurrence_index = ref_occurrences.get(ref, 0)
        ref_occurrences[ref] = occurrence_index + 1

        context = f"Активный сбор вариантов для role={role}, ref={ref}, occurrence={occurrence_index}"
        existing_options = _coerce_option_values(
            node.get("options_values"),
            path=f"{context}.options_values",
        )
        discovered_options = _collect_dynamic_options_for_ref(
            page,
            ref=ref,
            role=role,
            context=context,
            occurrence_index=occurrence_index,
        )
        merged_options = _merge_option_sets(
            existing_options=existing_options,
            discovered_options=discovered_options,
            context=context,
        )
        if not merged_options:
            continue

        node["has_options_enum"] = True
        node["options_values"] = merged_options

    return snapshot_tree


def _render_status_parts(node: AriaSnapshotObject) -> list[str]:
    status_parts: list[str] = []
    checked = node.get("checked")
    if checked is True:
        status_parts.append("[checked]")
    elif checked == "mixed":
        status_parts.append("[checked=mixed]")

    pressed = node.get("pressed")
    if pressed is True:
        status_parts.append("[pressed]")
    elif pressed == "mixed":
        status_parts.append("[pressed=mixed]")

    if node.get("disabled") is True:
        status_parts.append("[disabled]")
    if node.get("expanded") is True:
        status_parts.append("[expanded]")
    if node.get("selected") is True:
        status_parts.append("[selected]")
    if "level" in node:
        status_parts.append(f"[level={node['level']}]")
    if node.get("hidden") is True:
        status_parts.append("[hidden]")
    return status_parts


class RichAriaSnapshot(Ops):
    """
    Факт: получить богатый ARIA-снепшот всей страницы.
    Использует внедренное JS-ядро (window.__PERSONA__) для получения дерева,
    затем рендерит его в YAML-формат, совместимый с Playwright/MCP.
    """

    def __init__(self, timeout: float | None = None) -> None:
        self.timeout = timeout

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} получает богатый ARIA-снепшот страницы (через Runtime)"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> str:
        if args or kwargs:
            raise TypeError(
                "RichAriaSnapshot не принимает дополнительные аргументы выполнения."
            )

        snapshot_tree = self.get_tree(persona)
        snapshot_yaml = self.to_yaml(snapshot_tree)

        allure.attach(
            snapshot_yaml,
            name="rich-aria-page",
            attachment_type=allure.attachment_type.YAML,
        )

        return snapshot_yaml

    def _get_runtime_artifacts(
        self,
        value: object,
        timestamp: float,
    ) -> RuntimeArtifacts:
        if not isinstance(value, str) or not value.strip():
            return RuntimeArtifacts()
        path, url = persist_text_artifact(
            subdir="snapshots",
            component_name="rich-aria-snapshot",
            extension=".yaml",
            content=value,
            timestamp=timestamp,
        )
        return RuntimeArtifacts(snapshot_path=path, snapshot_url=url)

    def get_tree(self, persona: Persona) -> AriaSnapshotTree:
        """
        Получает сырое дерево элементов от Persona Runtime.
        Используется в генераторах кода как boundary-структура транспорта.
        """
        page = require_browser_page(persona)
        snapshot_tree = page.evaluate(
            "window.__PERSONA__ && window.__PERSONA__.getTreeForTransport && window.__PERSONA__.getTreeForTransport()"
        )

        if snapshot_tree is None:
            raise RuntimeError(
                "Persona Runtime не вернул JSON-дерево (getTreeForTransport). Убедитесь, что Runtime инициализирован."
            )

        coerced_snapshot = _coerce_snapshot_tree(snapshot_tree)
        return enrich_snapshot_with_dynamic_options(page, coerced_snapshot)

    @staticmethod
    def to_yaml(root: AriaSnapshotTree) -> str:
        lines: list[str] = []
        if isinstance(root, dict):
            lines.extend(RichAriaSnapshot._render_node_yaml(root, indent=0))
        else:
            for node in root:
                lines.extend(RichAriaSnapshot._render_node_yaml(node, indent=0))
        return "\n".join(lines)

    @staticmethod
    def _render_node_yaml(node: AriaSnapshotChild, indent: int) -> list[str]:
        if isinstance(node, str):
            return [f'{"  " * indent}- "{node}"']

        lines: list[str] = []
        prefix = "  " * indent

        role = node["role"]
        if not isinstance(role, str):
            raise TypeError("ARIA-узел должен содержать строковое поле role.")

        name = node.get("name")
        if name is not None and not isinstance(name, str):
            raise TypeError("ARIA-узел должен содержать строковое поле name.")

        ref = node.get("ref")
        if ref is not None and not isinstance(ref, str):
            raise TypeError("ARIA-узел должен содержать строковое поле ref.")

        safe_name = ""
        if name:
            escaped_name = name.replace("`", "").replace('"', '\\"')
            safe_name = f' "{escaped_name}"'

        ref_str = f" [ref={ref}]" if ref else ""
        status_parts = _render_status_parts(node)
        status_str = f" {' '.join(status_parts)}" if status_parts else ""
        header = f"{prefix}- {role}{safe_name}{ref_str}{status_str}:"

        children = node.get("children", [])
        if not isinstance(children, list):
            raise TypeError("ARIA-узел должен содержать список children.")

        props = node.get("props", {})
        if not isinstance(props, dict):
            raise TypeError("ARIA-узел должен содержать словарь props.")

        if not children and not props:
            lines.append(header.rstrip(":"))
            return lines

        lines.append(header)

        for key, value in props.items():
            if not isinstance(key, str):
                raise TypeError("Ключ props должен быть строкой.")
            if value is None:
                continue
            rendered_value = _format_prop_value(value).replace('"', '\\"')
            lines.append(f'{prefix}  - /{key}: "{rendered_value}"')

        for child in children:
            lines.extend(RichAriaSnapshot._render_node_yaml(child, indent + 1))

        return lines
