from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Table


class ExpectTableHeaders(Ops):
    """
    Ожидает, что заголовки таблицы соответствуют заданному списку.
    """

    def __init__(self, table: Table, expected_headers: list[str]):
        if not isinstance(table, Table):
            raise TypeError(f"Ожидается элемент Table, получено {type(table)}")
        if not all(isinstance(header, str) for header in expected_headers):
            raise TypeError("Ожидаемые заголовки таблицы должны быть списком строк.")
        self.table = table
        self.expected_headers = expected_headers

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} проверяет, что заголовки таблицы {self.table.name} равны {self.expected_headers}"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "ExpectTableHeaders не принимает дополнительные аргументы выполнения."
            )
        page = require_browser_page(persona)
        actual_headers = self.table.get_headers_data(page)

        if actual_headers != self.expected_headers:
            raise AssertionError(
                "Ожидаемые заголовки таблицы не совпадают.\n"
                f"Ожидалось: {self.expected_headers}\n"
                f"Фактически: {actual_headers}"
            )
