from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Table


class TableData(Ops):
    """
    Извлекает данные из таблицы в виде списка словарей.
    Ключи — заголовки столбцов, значения — текст ячеек.
    """

    def __init__(self, table_element: Table) -> None:
        self.table = table_element

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} извлекает данные из таблицы '{self.table.name}'"

    def _perform(
        self, persona: Persona, *args: object, **kwargs: object
    ) -> list[dict[str, str]]:
        if args or kwargs:
            raise TypeError(
                "TableData не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        return self.table.get_all_data(page)
