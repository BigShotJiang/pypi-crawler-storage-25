import os
from os import PathLike

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Element


class UploadFile(Ops):
    """
    Действие: Загрузить файл(ы) в input[type='file'].
    Wrapper for: locator.set_input_files(files)
    """

    def __init__(
        self,
        element: Element,
        files: str | PathLike[str] | list[str | PathLike[str]],
    ) -> None:
        self.element = element
        if isinstance(files, list):
            self.files: str | PathLike[str] | list[str | PathLike[str]] = [
                os.fspath(file_path) for file_path in files
            ]
        else:
            self.files = os.fspath(files)

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} загружает файлы в '{self.element}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "UploadFile не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        locator = self.element.resolve(page)
        locator.set_input_files(self.files)
