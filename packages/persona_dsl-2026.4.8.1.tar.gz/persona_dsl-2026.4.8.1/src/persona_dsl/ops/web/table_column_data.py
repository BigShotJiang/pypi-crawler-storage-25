from collections.abc import Generator
from enum import Enum

from persona_dsl.components.fact import Fact
from persona_dsl.persona import Persona
from persona_dsl.pages.elements import Table, TableRow
from persona_dsl.ops.web.element_text import ElementText
from persona_dsl.ops.web.elements_count import ElementsCount


class TableColumnData(Fact):
    """
    Факт для извлечения всех видимых на текущей странице значений из конкретной колонки.

    Полезно для сверки сортировки или работы фильтров (например, убедиться,
    что в колонке 'Статус' все значения равны 'Active').

    Аргументы:
        table: Элемент таблицы (PageObject/Element).
        column: Название колонки (поле модели строки или Enum), из которой нужно извлечь данные.

    Возвращает:
        list[str]: Список строк с текстом ячеек для заданной колонки (сверху вниз).
    """

    def __init__(self, table: Table, column: str | int | Enum) -> None:
        self.table = table
        self.column = column

    def _get_step_description(self, persona: Persona) -> str:
        col_name = (
            self.column.value if isinstance(self.column, Enum) else str(self.column)
        )
        return (
            f"Получить все значения из колонки '{col_name}' таблицы '{self.table.name}'"
        )

    def _run(
        self, persona: Persona, *args: object, **kwargs: object
    ) -> Generator[object, object, list[str]]:
        if args or kwargs:
            raise TypeError(
                "TableColumnData не принимает дополнительные аргументы выполнения."
            )

        result: list[str] = []

        rows_collection = self.table.body_rows
        row_count = yield ElementsCount(rows_collection)
        if not isinstance(row_count, int):
            raise TypeError(
                f"TableColumnData ожидает целочисленное количество строк, получено: {type(row_count)}."
            )

        for i in range(row_count):
            row_el = rows_collection.nth(i)
            if not isinstance(row_el, TableRow):
                raise TypeError(
                    f"TableColumnData ожидает строки типа TableRow, получено: {type(row_el)}."
                )
            cell = row_el.cell(self.column)

            text = yield ElementText(cell)
            if not isinstance(text, str):
                raise TypeError(
                    f"TableColumnData ожидает строковое содержимое ячейки, получено: {type(text)}."
                )
            result.append(text)

        return result
