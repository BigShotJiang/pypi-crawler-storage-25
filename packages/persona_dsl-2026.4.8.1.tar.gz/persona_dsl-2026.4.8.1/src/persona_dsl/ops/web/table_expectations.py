from enum import Enum

from persona_dsl.persona import Persona
from persona_dsl.components.expectation import Expectation
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Table, TableWhereCriteria


class TableCellHasText(Expectation):
    """
    Убеждается, что конкретная ячейка в строке (найденной по фильтру) содержит заданный текст.
    """

    def __init__(
        self,
        table: Table,
        where: TableWhereCriteria,
        column: str | Enum | int,
        text: str,
    ) -> None:
        self.table = table
        self.where = where
        self.column = column
        self.text = text

    def _get_step_description(self, persona: Persona) -> str:
        col_name = self.column.name if isinstance(self.column, Enum) else self.column
        where_str = ", ".join(
            f"'{k.name if isinstance(k, Enum) else k}'='{v}'"
            for k, v in self.where.items()
        )
        return f"{persona} проверяет, что ячейка '{col_name}' в строке где {where_str} содержит '{self.text}'"

    def _perform(
        self,
        persona: Persona,
        *args: object,
        **kwargs: object,
    ) -> None:
        if args or kwargs:
            raise TypeError(
                "TableCellHasText не принимает дополнительные аргументы выполнения."
            )

        row = self.table.row(where=self.where)
        cell = row.cell(self.column)

        from persona_dsl.expectations.web.have_text import HaveText

        expectation = HaveText(self.text)
        expectation._perform(persona, cell)
        return None


class TableHasRowCount(Expectation):
    """
    Проверяет, что в таблице ровно `count` строк (без учета заголовков).
    """

    def __init__(self, table: Table, count: int) -> None:
        self.table = table
        self.count = count

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} проверяет, что в таблице '{self.table.name}' ровно {self.count} строк"

    def _perform(
        self,
        persona: Persona,
        *args: object,
        **kwargs: object,
    ) -> None:
        if args or kwargs:
            raise TypeError(
                "TableHasRowCount не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)

        prototype = self.table.body_rows._make_item(None)
        rows_locator = prototype.resolve(page)
        actual_count = rows_locator.count()
        if actual_count != self.count:
            raise AssertionError(
                f"Ожидалось {self.count} строк, но найдено {actual_count}."
            )
        return None


class TableHasData(Expectation):
    """
    Проверяет эталонные данные (Snapshot-style).
    Сравнивает все данные на текущей странице таблицы с ожидаемым списком словарей.
    """

    def __init__(
        self,
        table: Table,
        expected_data: list[dict[str | Enum, str]],
        exclude_columns: list[str | Enum] | None = None,
        ignore_order: bool = False,
    ) -> None:
        self.table = table
        self.expected_data = expected_data
        self.exclude_columns = exclude_columns or []
        self.ignore_order = ignore_order

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} сверяет данные таблицы '{self.table.name}' с эталонным набором ({len(self.expected_data)} строк)"

    def _perform(
        self,
        persona: Persona,
        *args: object,
        **kwargs: object,
    ) -> None:
        if args or kwargs:
            raise TypeError(
                "TableHasData не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        actual_data = self.table.get_all_data(page)

        # Нормализация ожидаемых данных (приведение ключей Enum к строкам)
        normalized_expected: list[dict[str, str]] = []
        for expected_row in self.expected_data:
            norm_row: dict[str, str] = {}
            for k, v in expected_row.items():
                if isinstance(k, Enum):
                    key_str = str(k.value)
                else:
                    key_str = k
                norm_row[key_str] = v
            normalized_expected.append(norm_row)

        # Исключение колонок
        normalized_exclude: list[str] = []
        for col in self.exclude_columns:
            if isinstance(col, Enum):
                normalized_exclude.append(str(col.value))
            else:
                normalized_exclude.append(col)

        # Фильтрация колонок
        filtered_expected: list[dict[str, str]] = []
        for row in normalized_expected:
            filtered_expected.append(
                {k: v for k, v in row.items() if k not in normalized_exclude}
            )

        filtered_actual: list[dict[str, str]] = []
        for row in actual_data:
            filtered_actual.append(
                {k: v for k, v in row.items() if k not in normalized_exclude}
            )

        # Сравнение
        if self.ignore_order:
            # Сортируем списки словарей для независимого порядка (стабильная сортировка)
            import json

            exp_sorted = sorted(
                filtered_expected, key=lambda x: json.dumps(x, sort_keys=True)
            )
            act_sorted = sorted(
                filtered_actual, key=lambda x: json.dumps(x, sort_keys=True)
            )
            is_match = exp_sorted == act_sorted
            compare_exp = exp_sorted
            compare_act = act_sorted
        else:
            is_match = filtered_expected == filtered_actual
            compare_exp = filtered_expected
            compare_act = filtered_actual

        if not is_match:
            import difflib
            import json

            exp_json = json.dumps(
                compare_exp, ensure_ascii=False, indent=2
            ).splitlines()
            act_json = json.dumps(
                compare_act, ensure_ascii=False, indent=2
            ).splitlines()
            diff = "\\n".join(
                difflib.unified_diff(
                    exp_json,
                    act_json,
                    fromfile="Expected",
                    tofile="Actual",
                    lineterm="",
                )
            )

            # Прикрепляем Diff в Allure, если доступно
            try:
                import allure

                allure.attach(
                    diff,
                    name="Отличия в таблице (Diff)",
                    attachment_type=allure.attachment_type.TEXT,
                )
            except ImportError as error:
                raise RuntimeError(
                    "Для прикрепления diff требуется установленный пакет allure."
                ) from error

            raise AssertionError(
                f"Данные таблицы не совпадают с эталонными.\\nРазличия:\\n{diff}"
            )

        return None
