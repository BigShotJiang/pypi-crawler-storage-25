from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import LocatorLike, TableRow


def detect_table_row_expanded_state(
    expander_loc: LocatorLike,
    *,
    row_name: str,
) -> bool:
    class_attr = expander_loc.get_attribute("class") or ""
    aria_expanded = expander_loc.get_attribute("aria-expanded")

    detected_states: list[tuple[str, bool]] = []
    if aria_expanded is not None:
        if aria_expanded == "true":
            detected_states.append(("aria-expanded", True))
        elif aria_expanded == "false":
            detected_states.append(("aria-expanded", False))
        else:
            raise RuntimeError(
                f"Элемент раскрытия строки {row_name} содержит недопустимое aria-expanded={aria_expanded!r}."
            )

    if "expanded" in class_attr.split():
        detected_states.append(("css-class", True))

    if not detected_states:
        raise RuntimeError(
            f"Не удалось определить состояние раскрытия строки {row_name}: "
            "нет явного aria-expanded или CSS-признака expanded."
        )

    unique_states = {state for _, state in detected_states}
    if len(unique_states) != 1:
        signals = ", ".join(f"{source}={state}" for source, state in detected_states)
        raise RuntimeError(
            f"Элемент раскрытия строки {row_name} содержит противоречивые признаки состояния: {signals}."
        )

    return unique_states.pop()


class ExpandTableRow(Ops):
    """
    Атомарное действие: раскрывать или скрывать строку таблицы, нажимая на экспандер.
    Полезно для Master-Detail таблиц.
    """

    def __init__(self, table_row: TableRow, state: bool = True):
        self.table_row = table_row
        self.state = state

    def _get_step_description(self, persona: Persona) -> str:
        action = "раскрывает" if self.state else "скрывает"
        return f"{persona} {action} строку {self.table_row.name}"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "ExpandTableRow не принимает дополнительные аргументы выполнения."
            )
        page = require_browser_page(persona)
        expander_loc = self.table_row.expander.resolve(page)

        if expander_loc.count() == 0:
            raise RuntimeError(
                f"Не удалось найти элемент раскрытия для строки {self.table_row.name}"
            )

        actual_state = detect_table_row_expanded_state(
            expander_loc,
            row_name=self.table_row.name,
        )
        if actual_state != self.state:
            expander_loc.click()
