from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Table, TableRow, TableWhereCriteria


class GetTableRow(Ops):
    """
    Находит строку в таблице по заданному условию.

    Args:
        table_element: Элемент таблицы (Table).
        where: Словарь с условиями поиска (колонка: значение).
               Колонка может быть строкой или Enum таблицы.
        index: Индекс строки (если не используется where).
    """

    def __init__(
        self,
        table_element: Table,
        where: TableWhereCriteria | None = None,
        index: int | None = None,
    ) -> None:
        self.table = table_element
        self.where = where
        self.index = index
        self.result: TableRow | None = None

    def _get_step_description(self, persona: Persona) -> str:
        condition = self.where if self.where else f"index={self.index}"
        return f"{persona} находит строку в таблице '{self.table.name}' по условию: {condition}"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> TableRow:
        if args or kwargs:
            raise TypeError(
                "GetTableRow не принимает дополнительные аргументы выполнения."
            )

        row_element = self.table.row(where=self.where, index=self.index)

        # Verify it can be resolved (will raise timeout/error if not found)
        page = require_browser_page(persona)
        row_element.resolve(page)
        self.result = row_element
        return row_element
