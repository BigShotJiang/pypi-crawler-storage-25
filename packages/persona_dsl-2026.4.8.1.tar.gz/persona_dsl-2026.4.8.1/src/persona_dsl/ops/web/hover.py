from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Element


class Hover(Ops):
    """
    Действие: Навести курсор на элемент.
    """

    def __init__(self, element: Element) -> None:
        self.element = element

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} наводит курсор на '{self.element}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError("Hover не принимает дополнительные аргументы выполнения.")

        page = require_browser_page(persona)
        locator = self.element.resolve(page)
        locator.hover()
