from __future__ import annotations

import time

import allure

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Element, get_element_ui_label
from persona_dsl.utils.artifacts import (
    RuntimeArtifacts,
    runtime_file_artifact,
    sanitize_filename,
    screenshots_dir,
)


class PageScreenshot(Ops):
    """
    Факт: сделать скриншот текущей страницы.
    Возвращает путь к PNG-файлу.
    """

    def __init__(
        self, name: str, full_page: bool = False, omit_background: bool = False
    ) -> None:
        self.name = name
        self.full_page = full_page
        self.omit_background = omit_background

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} делает скриншот страницы '{self.name}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> str:
        if args or kwargs:
            raise TypeError(
                "PageScreenshot не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        ts = int(time.time() * 1000)
        base_name = sanitize_filename(self.name)
        path = screenshots_dir() / f"{ts}-{base_name}.png"
        page.screenshot(
            path=str(path),
            full_page=self.full_page,
            omit_background=self.omit_background,
        )
        allure.attach.file(
            str(path), name=base_name, attachment_type=allure.attachment_type.PNG
        )
        return str(path)

    def _get_runtime_artifacts(
        self,
        value: object,
        timestamp: float,
    ) -> RuntimeArtifacts:
        if not isinstance(value, str):
            raise TypeError("PageScreenshot должен вернуть строковый путь к файлу.")
        path, url = runtime_file_artifact(value, subdir="screenshots")
        return RuntimeArtifacts(screenshot_path=path, screenshot_url=url)


class ElementScreenshot(Ops):
    """
    Факт: сделать скриншот элемента.
    Возвращает путь к PNG-файлу.
    """

    def __init__(self, element: Element, name: str | None = None) -> None:
        self.element = element
        self.name = name or get_element_ui_label(element)

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} делает скриншот элемента '{get_element_ui_label(self.element)}' как '{self.name}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> str:
        if args or kwargs:
            raise TypeError(
                "ElementScreenshot не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        ts = int(time.time() * 1000)
        base_name = sanitize_filename(self.name)
        path = screenshots_dir() / f"{ts}-{base_name}.png"

        locator = self.element.resolve(page)
        locator.screenshot(path=str(path))
        allure.attach.file(
            str(path), name=base_name, attachment_type=allure.attachment_type.PNG
        )
        return str(path)

    def _get_runtime_artifacts(
        self,
        value: object,
        timestamp: float,
    ) -> RuntimeArtifacts:
        if not isinstance(value, str):
            raise TypeError("ElementScreenshot должен вернуть строковый путь к файлу.")
        path, url = runtime_file_artifact(value, subdir="screenshots")
        return RuntimeArtifacts(screenshot_path=path, screenshot_url=url)
