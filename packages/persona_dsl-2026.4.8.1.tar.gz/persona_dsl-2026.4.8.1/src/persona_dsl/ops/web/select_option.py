from collections.abc import Generator

from persona_dsl.components.step import Step
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.ops.web.click import Click
from persona_dsl.pages.elements import Dropdown, Element, ListBox, Select


class SelectOption(Step):
    """
    Выбирает опцию в выпадающем списке.
    Поддерживает как стандартные <select>, так и кастомные dropdowns (через клик).

    Args:
        element (Element): Элемент (Select/Dropdown/ComboBox)
        value (str, optional): Значение атрибута value опции.
        label (str, optional): Видимый текст опции (Accessible Name).
        text (str, optional): Алиас для label (предпочтительно для DSL читаемости).
        index (int, optional): Индекс опции (0-based).
        force (bool): Игнорировать проверки interactability.
    """

    def __init__(
        self,
        element: Element,
        value: str | None = None,
        label: str | None = None,
        index: int | None = None,
        force: bool = False,
    ) -> None:
        if not isinstance(element, Element):
            raise TypeError(
                f"SelectOption ожидает экземпляр Element, получено: {type(element)}"
            )
        self.element = element
        self.value = value
        self.label = label
        self.index = index
        self.force = force

        desc_parts = []
        if value:
            desc_parts.append(f"value='{value}'")
        if label:
            desc_parts.append(f"label='{label}'")
        if index is not None:
            desc_parts.append(f"index={index}")
        if force:
            desc_parts.append("force=True")

        self.description = f"Выбрать опцию в {element}: {', '.join(desc_parts)}"
        super().__init__()

    def _get_step_description(self, persona: Persona) -> str:
        return self.description

    def _run(
        self, persona: Persona, *args: object, **kwargs: object
    ) -> Generator[object, object, None]:
        if args or kwargs:
            raise TypeError(
                "SelectOption не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        if isinstance(self.element, (Select, Dropdown, ListBox)):
            self.element.select_option(
                page=page,
                value=self.value,
                label=self.label,
                index=self.index,
                force=self.force,
            )
            return

        yield Click(self.element)

        target_text = self.label or self.value
        if target_text is not None:
            target_option = self.element.get_option(target_text)
            opt_loc = target_option.resolve(page)

            if opt_loc.count() > 0:
                opt_loc.first.scroll_into_view_if_needed()
                opt_loc.first.click()
                return

            raise ValueError(
                f"SelectOption: Could not find option '{target_text}' in {self.element}."
            )

        if self.index is not None:
            target_option = self.element.get_option_by_index(self.index)
            opt_loc = target_option.resolve(page)

            if opt_loc.count() > 0:
                opt_loc.first.scroll_into_view_if_needed()
                opt_loc.first.click()
                return

            raise ValueError(
                f"SelectOption: Could not find option at index {self.index} in {self.element}."
            )

        raise ValueError(
            "SelectOption требует хотя бы один критерий выбора: value, label или index."
        )
