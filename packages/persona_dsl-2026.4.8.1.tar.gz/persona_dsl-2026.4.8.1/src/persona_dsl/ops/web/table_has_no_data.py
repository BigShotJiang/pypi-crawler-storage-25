from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Table


class TableHasNoData(Expectation):
    """
    Проверяет, что таблица пуста (не содержит строк с реальными данными).
    Полезно для верификации пустых состояний после фильтрации.

    Игнорирует строки заголовков (thead) и строки, содержащие только текст "заглушки"
    (например, "Нет данных", "No content").

    Args:
        table: Элемент таблицы
        empty_text_indicator: Строка, которая может находиться в пустой таблице (например, "Нет данных").
                              Если строка существует, но содержит только этот текст - таблица считается пустой.
    """

    def __init__(self, table: Table, empty_text_indicator: str = "") -> None:
        self.table = table
        self.empty_text_indicator = empty_text_indicator

    def _get_step_description(self, persona: Persona) -> str:
        return "Проверка пустого состояния таблицы"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "TableHasNoData не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        rows = self.table.body_rows.resolve_all(page)

        data_row_count = 0
        for row in rows:
            text = (row.text_content() or "").strip()
            if not text:
                continue
            if self.empty_text_indicator and self.empty_text_indicator in text:
                continue
            data_row_count += 1

        is_empty = data_row_count == 0

        if not is_empty:
            raise AssertionError(
                f"Ожидалось, что таблица '{self.table.name}' будет пустой, но в ней найдены данные."
            )

        return None
