from typing import TypedDict

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Element, get_element_ui_label


class PressOptions(TypedDict, total=False):
    delay: float
    timeout: float
    no_wait_after: bool


class PressKey(Ops):
    """
    Атомарное действие: нажать клавишу на элементе.
    По умолчанию Element.resolve() использует первую доступную стратегию
    в порядке `role` -> `label` -> `placeholder` -> `text` -> `alt_text`
    -> `title` -> `test_id` -> `ref` -> `link` -> `locator`.
    Полный проход по всем доступным стратегиям выполняется только при явном
    `Strategy.ALL`.
    Поддерживает проброс аргументов в Playwright (timeout, no_wait_after, etc).
    """

    def __init__(self, element: Element, key: str, **kwargs: float | bool) -> None:
        """
        Args:
            element: Экземпляр элемента, на котором нажимается клавиша.
            key: Имя клавиши для нажатия (например, 'Enter', 'Tab', 'ArrowDown').
            **kwargs: Дополнительные аргументы для Playwright locator.press().
        """
        if not isinstance(element, Element):
            raise TypeError(
                f"PressKey ожидает экземпляр Element, получено: {type(element)}"
            )
        self.element = element
        self.key = key
        self.kwargs: PressOptions = {}
        for name, value in kwargs.items():
            if name == "no_wait_after":
                if not isinstance(value, bool):
                    raise TypeError("Параметр PressKey.no_wait_after должен быть bool.")
                self.kwargs["no_wait_after"] = value
            elif name == "delay":
                if not isinstance(value, (int, float)) or isinstance(value, bool):
                    raise TypeError(f"Параметр PressKey.{name} должен быть числом.")
                self.kwargs["delay"] = float(value)
            elif name == "timeout":
                if not isinstance(value, (int, float)) or isinstance(value, bool):
                    raise TypeError(f"Параметр PressKey.{name} должен быть числом.")
                self.kwargs["timeout"] = float(value)
            else:
                raise TypeError(f"Неподдерживаемый параметр PressKey: '{name}'.")

    def _get_step_description(self, persona: Persona) -> str:
        extra = f" с параметрами {self.kwargs}" if self.kwargs else ""
        return f"{persona} нажимает клавишу '{self.key}' на элементе '{get_element_ui_label(self.element)}'{extra}"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "PressKey не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        locator = self.element.resolve(page)
        locator.press(self.key, **self.kwargs)
