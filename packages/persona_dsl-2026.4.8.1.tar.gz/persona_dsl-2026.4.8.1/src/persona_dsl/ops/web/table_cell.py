from enum import Enum

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import TableRow, TableCell


class GetTableCell(Ops):
    """
    Находит ячейку в строке таблицы по колонке (Enum или индекс).

    Args:
        row_element: Структура строки таблицы (TableRow).
        column: Колонка, значение Enum или строка с названием колонки.
    """

    def __init__(
        self,
        row_element: TableRow,
        column: str | Enum | int,
    ) -> None:
        self.row = row_element
        self.column = column
        self.result: TableCell | None = None

    def _get_step_description(self, persona: Persona) -> str:
        col_name = self.column.name if isinstance(self.column, Enum) else self.column
        return f"{persona} находит ячейку для колонки '{col_name}' в строке '{self.row.name}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> TableCell:
        if args or kwargs:
            raise TypeError(
                "GetTableCell не принимает дополнительные аргументы выполнения."
            )

        cell_element = self.row.cell(self.column)

        page = require_browser_page(persona)
        cell_element.resolve(page)
        self.result = cell_element
        return cell_element
