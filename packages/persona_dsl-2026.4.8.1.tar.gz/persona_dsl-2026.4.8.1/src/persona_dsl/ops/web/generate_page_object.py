from __future__ import annotations

from collections.abc import Mapping, Sequence
import time
from pathlib import Path
from typing import Literal, Protocol, TypeGuard
from urllib.parse import urlparse

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.generators import PageGenerator
from persona_dsl.generators.page.contracts import (
    ObjectMap,
    SnapshotNode,
    SnapshotNodeList,
    as_object_map,
)
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import BrowserPageLike
from persona_dsl.utils.config import Config
from persona_dsl.utils.naming import to_snake_case
from .rich_aria_snapshot import RichAriaSnapshot

LoadState = Literal["load", "domcontentloaded", "networkidle", "commit"]


class _PytestConfigLike(Protocol):
    def getoption(self, name: str) -> object: ...


class _PytestRequestLike(Protocol):
    config: _PytestConfigLike

    def getfixturevalue(self, name: str) -> object: ...


def _is_pytest_request_like(value: object) -> TypeGuard[_PytestRequestLike]:
    config = getattr(value, "config", None)
    return (
        config is not None
        and callable(getattr(config, "getoption", None))
        and callable(getattr(value, "getfixturevalue", None))
    )


def _require_pytest_request(persona: object) -> _PytestRequestLike | None:
    request = getattr(persona, "_pytest_request", None)
    if request is None:
        return None

    if not _is_pytest_request_like(request):
        raise TypeError(
            "Persona._pytest_request должен предоставлять config.getoption(...) и getfixturevalue(...)."
        )
    return request


def _fixture_names(request: _PytestRequestLike) -> tuple[str, ...]:
    raw_fixture_names = getattr(request, "fixturenames", ())
    if isinstance(raw_fixture_names, Sequence) and not isinstance(
        raw_fixture_names, str | bytes
    ):
        fixture_names = tuple(
            name for name in raw_fixture_names if isinstance(name, str)
        )
        return fixture_names
    return ()


def _is_generation_enabled(request: _PytestRequestLike | None) -> bool:
    if request is None:
        return False

    option_value = request.config.getoption("--generate-pages")
    if not isinstance(option_value, bool):
        raise TypeError(
            "Опция pytest --generate-pages должна возвращать булево значение."
        )
    return option_value


def _require_string_list(raw_value: object, *, field_name: str) -> list[str]:
    if raw_value is None:
        return []
    if not isinstance(raw_value, list):
        raise TypeError(f"{field_name} должен быть списком строк.")

    values: list[str] = []
    for index, item in enumerate(raw_value):
        if not isinstance(item, str) or not item:
            raise TypeError(
                f"{field_name}[{index}] должен быть непустой строкой, получено: {item!r}."
            )
        values.append(item)
    return values


def _load_portal_runtime_config(
    request: _PytestRequestLike | None,
) -> dict[str, list[str]] | None:
    if request is None or "config" not in _fixture_names(request):
        return None

    project_config = request.getfixturevalue("config")
    if not isinstance(project_config, Config):
        raise TypeError(
            "Фикстура 'config' должна возвращать persona_dsl.utils.config.Config."
        )

    portal_classes = _require_string_list(
        project_config.generator.get("portal_classes"),
        field_name="generator.portal_classes",
    )
    portal_patterns = _require_string_list(
        project_config.generator.get("portal_patterns"),
        field_name="generator.portal_patterns",
    )

    runtime_config: dict[str, list[str]] = {}
    if portal_classes:
        runtime_config["portalClasses"] = portal_classes
    if portal_patterns:
        runtime_config["portalPatterns"] = portal_patterns

    return runtime_config or None


def _apply_portal_runtime_config(
    page: BrowserPageLike,
    runtime_config: Mapping[str, list[str]],
) -> None:
    page.evaluate(
        """(config) => {
            window.__PERSONA_CONFIG__ = config;
            if (window.__PERSONA__ && typeof window.__PERSONA__.configure === "function") {
                window.__PERSONA__.configure(config);
            }
        }""",
        dict(runtime_config),
    )


def _require_page_url(page: object) -> str:
    page_url = getattr(page, "url", None)
    if not isinstance(page_url, str) or not page_url:
        raise TypeError(
            "Браузерная страница должна предоставлять непустой строковый url."
        )
    return page_url


def _coerce_snapshot_node(raw_node: object, *, context: str) -> SnapshotNode:
    if isinstance(raw_node, str):
        return raw_node

    node = as_object_map(raw_node)
    if node is None:
        raise TypeError(f"{context} должен быть строкой или объектом JSON-дерева.")

    children_raw = node.get("children")
    if children_raw is None:
        return dict(node)

    if not isinstance(children_raw, list):
        raise TypeError(f"{context}.children должен быть списком.")

    coerced_node: ObjectMap = dict(node)
    coerced_node["children"] = [
        _coerce_snapshot_node(child, context=f"{context}.children[{index}]")
        for index, child in enumerate(children_raw)
    ]
    return coerced_node


def _coerce_snapshot_tree(raw_tree: object) -> SnapshotNodeList | ObjectMap:
    if isinstance(raw_tree, list):
        return [
            _coerce_snapshot_node(node, context=f"snapshot[{index}]")
            for index, node in enumerate(raw_tree)
        ]

    tree = as_object_map(raw_tree)
    if tree is None:
        raise TypeError("ARIA snapshot должен быть JSON-объектом или списком узлов.")

    coerced_root = _coerce_snapshot_node(tree, context="snapshot")
    if isinstance(coerced_root, str):
        raise TypeError("Корневой узел ARIA snapshot не может быть строкой.")
    return coerced_root


class GeneratePageObject(Ops):
    """
    Бизнес-операция: сгенерировать и сохранить PageObject на основе текущего состояния страницы.
    Работает при запуске pytest с флагом --generate-pages (см. pytest_plugin.py).

    По умолчанию также сохраняет ARIA-снепшот в tests/pages/aria/<stem>_snapshot.yaml
    и прокидывает относительный путь в сгенерированный Page (static_aria_snapshot_path).

    Параметры ожидания перед генерацией регулируются аргументами:
      - wait_for_state: состояние загрузки Playwright ('load' | 'domcontentloaded' | 'networkidle' | 'commit')
      - wait_timeout: таймаут в миллисекундах; если None — используется дефолтный таймаут Playwright/страницы
      - sleep_before: если задано (в секундах), выполнить простую паузу перед генерацией и не ждать состояние загрузки
    """

    def __init__(
        self,
        class_name: str = "GeneratedPage",
        output_path: str | None = None,
        wait_for_state: LoadState | None = "networkidle",
        wait_timeout: float | None = None,
        sleep_before: float | None = None,
        debug_mode: bool = False,
        leaf_overrides: dict[str, list[str]] | None = None,
    ) -> None:
        self.class_name = class_name or "GeneratedPage"
        if output_path is None:
            file_name = f"{to_snake_case(self.class_name)}.py"
            # Дефолт как у клиента: tests/pages/
            self.output_path = Path("tests/pages") / file_name
        else:
            self.output_path = Path(output_path)
        self.wait_for_state = wait_for_state
        self.wait_timeout = wait_timeout
        self.sleep_before = sleep_before
        self.debug_mode = debug_mode
        self.leaf_overrides = leaf_overrides

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} генерирует PageObject '{self.class_name}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "GeneratePageObject не принимает дополнительные аргументы выполнения."
            )

        # Проверяем флаг в pytest (регистрируется в pytest_plugin.py)
        request = _require_pytest_request(persona)
        generate_enabled = _is_generation_enabled(request)

        if not generate_enabled:
            # Явный no-op без побочных эффектов
            return

        page = require_browser_page(persona)

        # Варианты ожидания перед генерацией: простая пауза или ожидание состояния
        if self.sleep_before is not None:
            time.sleep(self.sleep_before)
        elif self.wait_for_state:
            if self.wait_timeout is None:
                page.wait_for_load_state(self.wait_for_state)
            else:
                page.wait_for_load_state(self.wait_for_state, timeout=self.wait_timeout)

        # Получаем относительный путь URL
        page_path = urlparse(_require_page_url(page)).path

        # --- Inject Generator Configuration (Portal Classes) ---
        runtime_config = _load_portal_runtime_config(request)
        if runtime_config is not None:
            _apply_portal_runtime_config(page, runtime_config)

        # Используем rich ARIA snapshot вместо стандартного
        rich_snapshot_op = RichAriaSnapshot()
        snapshot_struct = _coerce_snapshot_tree(rich_snapshot_op.get_tree(persona))

        # Сохраняем ARIA снепшот на диск как YAML-строку
        assets_dir = self.output_path.parent / "aria"
        assets_dir.mkdir(parents=True, exist_ok=True)

        snapshot_file = f"{self.output_path.stem}_snapshot.yaml"
        snapshot_abs_path = assets_dir / snapshot_file

        snapshot_yaml: str = (
            RichAriaSnapshot.to_yaml(snapshot_struct) if snapshot_struct else ""
        )
        if snapshot_yaml:
            snapshot_abs_path.write_text(snapshot_yaml, encoding="utf-8")
        aria_snapshot_rel_path = f"aria/{snapshot_file}"

        generator = PageGenerator(
            debug_mode=self.debug_mode,
            leaf_overrides=self.leaf_overrides,
        )
        # Если файл уже существует — читаем его и выполняем умное обновление (merge)
        existing_code: str | None = None
        if self.output_path.exists():
            existing_code = self.output_path.read_text(encoding="utf-8")

        generated_code = generator.generate_or_update_from_aria_snapshot(
            snapshot=snapshot_struct,
            class_name=self.class_name,
            page_path=page_path,
            aria_snapshot_path=aria_snapshot_rel_path,
            existing_code=existing_code,
        )

        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        self.output_path.write_text(generated_code, encoding="utf-8")

        # 6. Write Deep Updates (Recursive)
        generator.apply_pending_updates()
