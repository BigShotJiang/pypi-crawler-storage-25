import copy
from typing import Protocol, TypeGuard

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import (
    Element,
    ElementList,
    QueryContextLike,
    Repeated,
    get_element_ui_label,
)


class CountableLocator(Protocol):
    def count(self) -> int: ...


def _is_countable_locator(value: object) -> TypeGuard[CountableLocator]:
    return hasattr(value, "count") and callable(getattr(value, "count"))


class ElementsCount(Ops):
    """
    Бизнес-операция: подсчитать количество элементов, соответствующих прототипу.

    Принимает:
      - Element: будет посчитано количество совпадений для данного описания элемента.
      - ElementList: используется его прототип для построения локатора и подсчёта.
      - Repeated: использует свой прототип для declarative repeatable-коллекций.
    """

    def __init__(self, element_or_list: Element | ElementList | Repeated) -> None:
        if isinstance(element_or_list, (ElementList, Repeated)):
            self._element = element_or_list._prototype
        elif isinstance(element_or_list, Element):
            self._element = element_or_list
        else:
            raise TypeError("ElementsCount ожидает Element, ElementList или Repeated")

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} подсчитывает количество элементов для '{get_element_ui_label(self._element)}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> int:
        if args or kwargs:
            raise TypeError(
                "ElementsCount не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        # Базовый локатор — родитель, если он есть; иначе вся страница
        base: QueryContextLike = (
            self._element.parent.resolve(page) if self._element.parent else page
        )

        # Строим локатор для всех совпадений (index=None)
        # Using copy and modifying the copy is safer and more robust than manual constructor
        probe = copy.copy(self._element)
        probe.index = None

        locator = probe._get_playwright_locator(
            base,
            page=page,
            resolution_stack=set(),
        )
        if not _is_countable_locator(locator):
            raise TypeError(
                f"Элемент '{probe.name}' не может быть использован для подсчёта без явной стратегии поиска."
            )
        return locator.count()
