from __future__ import annotations

from enum import Enum
from typing import Literal, TypeAlias

from playwright.sync_api import Error as PlaywrightError

from persona_dsl.components.action import Action
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import (
    Element,
    Table,
    TableWhereCriteria,
    get_element_ui_label,
)

TableColumn: TypeAlias = int | str | Enum
TableWhere: TypeAlias = TableWhereCriteria


class ScrollTable(Action):
    """
    Выполняет скроллинг контейнера таблицы.
    Полезно для виртуализированных таблиц или таблиц с горизонтальным скроллом.

    Args:
        table: Элемент таблицы. Скроллинг применяется к ближайшему скроллируемому контейнеру
               или к самой таблице (tbody).
        direction: Направление скролла ("right", "left", "bottom", "top").
        amount: Количество пикселей для скролла, или "max" для скролла до упора.
    """

    def __init__(
        self,
        table: Table,
        direction: Literal["right", "left", "bottom", "top"] = "bottom",
        amount: int | str | None = None,
        column: TableColumn | None = None,
        where: TableWhere | None = None,
    ) -> None:
        self.table = table
        self.direction = direction
        self.amount = amount
        self.column = column
        self.where = where

    def _get_step_description(self, persona: Persona) -> str:
        desc = "Скроллинг таблицы"
        if self.where and self.column:
            desc += f" до ячейки '{self.column}' в строке {self.where}"
        elif self.where:
            desc += f" до строки {self.where}"
        elif self.column:
            desc += f" до заголовка '{self.column}'"
        else:
            desc += f" {self.direction}"
        return desc

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "ScrollTable не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)

        target_element: Element | None = None
        if self.where and self.column:
            # Скроллинг до конкретной ячейки
            target_element = self.table.row(where=self.where).cell(self.column)
        elif self.where:
            # Скроллинг до конкретной строки
            target_element = self.table.row(where=self.where)
        elif self.column:
            # Скроллинг до заголовка колонки (горизонтальный скролл)
            target_element = self.table.header(self.column)

        if target_element:
            try:
                element_locator = target_element.resolve(page)
                element_locator.scroll_into_view_if_needed(timeout=2000)
                return None
            except (PlaywrightError, RuntimeError, TypeError, ValueError) as error:
                raise ValueError(
                    f"Не удалось найти элемент {get_element_ui_label(target_element)} для прокрутки. В виртуализированных таблицах элемент может отсутствовать в DOM."
                ) from error

        self.table.scroll(page, direction=self.direction, amount=self.amount)
        return None
