from enum import Enum
from typing import Optional

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page


class DialogAction(str, Enum):
    ACCEPT = "accept"
    DISMISS = "dismiss"


class HandleDialog(Ops):
    """
    Действие: Обработать следующий появившийся диалог (Alert/Confirm/Prompt).
    Настраивает одноразовый слушатель.
    """

    def __init__(
        self,
        action: DialogAction = DialogAction.ACCEPT,
        prompt_text: Optional[str] = None,
    ):
        self.action = action
        self.prompt_text = prompt_text

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} ожидает и обрабатывает диалог ({self.action})"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "HandleDialog не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        once_method = getattr(page, "once", None)
        if once_method is None or not callable(once_method):
            raise TypeError(
                "Активная браузерная страница должна поддерживать page.once(...)."
            )

        def handler(dialog: object) -> None:
            accept_method = getattr(dialog, "accept", None)
            dismiss_method = getattr(dialog, "dismiss", None)
            if not callable(accept_method) or not callable(dismiss_method):
                raise TypeError(
                    "Playwright page.once('dialog', ...) должен передавать объект с методами accept() и dismiss()."
                )
            if self.action == DialogAction.ACCEPT:
                accept_method(prompt_text=self.prompt_text)
            else:
                dismiss_method()

        # Применяем .once(), чтобы обработать только один следующий диалог
        once_method("dialog", handler)
