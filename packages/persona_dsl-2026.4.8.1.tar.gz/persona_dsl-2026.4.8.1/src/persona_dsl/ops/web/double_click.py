from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Element


class DoubleClick(Ops):
    """
    Действие: Двойной клик по элементу.
    """

    def __init__(self, element: Element) -> None:
        self.element = element

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} делает двойной клик по '{self.element}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "DoubleClick не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        locator = self.element.resolve(page)
        locator.dblclick()
