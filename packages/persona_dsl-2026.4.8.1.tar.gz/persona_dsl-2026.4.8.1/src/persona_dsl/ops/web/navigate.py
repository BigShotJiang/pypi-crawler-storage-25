from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.page import Page


class NavigateTo(Ops):
    """
    Атомарное действие: перейти по адресу.
    LCL-39: Поддержка build_url для Page.
    """

    def __init__(self, target: str | Page) -> None:
        self._target = target

    def _resolve_path(self) -> str:
        if isinstance(self._target, str):
            return self._target

        page_obj = self._target
        return page_obj.build_url()

    def _get_step_description(self, persona: Persona) -> str:
        if isinstance(self._target, str):
            path = self._target
        else:
            if not self._target.expected_path:
                raise ValueError(
                    "NavigateTo: у переданной страницы не задан expected_path."
                )
            path = self._target.expected_path
        return f"{persona} переходит по адресу '{path}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "NavigateTo не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        url_or_path = self._resolve_path()
        page.goto(url_or_path)
