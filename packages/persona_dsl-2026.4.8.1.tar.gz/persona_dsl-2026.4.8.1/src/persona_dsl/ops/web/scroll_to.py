from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Element, get_element_ui_label


class ScrollTo(Ops):
    """
    Атомарное действие: проскроллить до элемента, чтобы он стал видимым.
    """

    def __init__(self, element: Element, timeout: float | None = None) -> None:
        if not isinstance(element, Element):
            raise TypeError(
                f"ScrollTo ожидает экземпляр Element, получено: {type(element)}"
            )
        self.element = element
        self.timeout = timeout

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} скроллит до элемента '{get_element_ui_label(self.element)}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "ScrollTo не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        locator = self.element.resolve(page)
        locator.scroll_into_view_if_needed(timeout=self.timeout)
