from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import TableRow


class ToggleRowSelection(Ops):
    """
    Атомарное действие: переключает состояние чекбокса в конкретной строке таблицы.
    """

    def __init__(self, table_row: TableRow, state: bool = True) -> None:
        self.table_row = table_row
        self.state = state

    def _get_step_description(self, persona: Persona) -> str:
        action = "Выбирает строку" if self.state else "Снимает выбор со строки"
        return f"{persona} {action} {self.table_row.name}"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "ToggleRowSelection не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        checkbox_loc = self.table_row.checkbox.resolve(page)

        input_loc = checkbox_loc.locator("input[type='checkbox']")
        target = input_loc.first if input_loc.count() > 0 else checkbox_loc

        is_checked = target.is_checked()

        if is_checked != self.state:
            # Playwright's check/uncheck interacts well with standard checkboxes
            # We use force=True because AntD sometimes hides the actual input
            if self.state:
                target.check(force=True)
            else:
                target.uncheck(force=True)
