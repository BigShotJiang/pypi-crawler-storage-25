from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Element


class DragAndDrop(Ops):
    """
    Действие: Перетащить элемент (source) на целевой элемент (target).
    Wrapper for: locator.drag_to(target_locator)
    """

    def __init__(self, source: Element, target: Element) -> None:
        self.source = source
        self.target = target

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} перетаскивает '{self.source}' на '{self.target}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "DragAndDrop не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        source_locator = self.source.resolve(page)
        target_locator = self.target.resolve(page)

        source_locator.drag_to(target_locator)
