from typing import TypedDict

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Element, get_element_ui_label


class ClickOptions(TypedDict, total=False):
    force: bool
    timeout: float
    no_wait_after: bool
    trial: bool


class Click(Ops):
    """
    Атомарное действие: кликнуть по элементу.
    По умолчанию Element.resolve() использует первую доступную стратегию
    в порядке `role` -> `label` -> `placeholder` -> `text` -> `alt_text`
    -> `title` -> `test_id` -> `ref` -> `link` -> `locator`.
    Полный проход по всем доступным стратегиям выполняется только при явном
    `Strategy.ALL`.
    Поддерживает проброс аргументов в Playwright (force, timeout, etc).
    """

    def __init__(self, element: Element, **kwargs: float | bool):
        if not isinstance(element, Element):
            raise TypeError(
                f"Click ожидает экземпляр Element, получено: {type(element)}"
            )
        self.element = element
        self.kwargs: ClickOptions = {}
        for key, value in kwargs.items():
            if key == "force":
                if not isinstance(value, bool):
                    raise TypeError(f"Параметр Click.{key} должен быть bool.")
                self.kwargs["force"] = value
            elif key == "no_wait_after":
                if not isinstance(value, bool):
                    raise TypeError(f"Параметр Click.{key} должен быть bool.")
                self.kwargs["no_wait_after"] = value
            elif key == "trial":
                if not isinstance(value, bool):
                    raise TypeError(f"Параметр Click.{key} должен быть bool.")
                self.kwargs["trial"] = value
            elif key == "timeout":
                if not isinstance(value, (int, float)) or isinstance(value, bool):
                    raise TypeError("Параметр Click.timeout должен быть числом.")
                self.kwargs["timeout"] = float(value)
            else:
                raise TypeError(f"Неподдерживаемый параметр Click: '{key}'.")

    def _get_step_description(self, persona: Persona) -> str:
        extra = f" с параметрами {self.kwargs}" if self.kwargs else ""
        return f"{persona} кликает по элементу '{get_element_ui_label(self.element)}'{extra}"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError("Click не принимает дополнительные аргументы выполнения.")

        page = require_browser_page(persona)
        locator = self.element.resolve(page)
        locator.click(**self.kwargs)
