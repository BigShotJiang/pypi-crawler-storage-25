from __future__ import annotations

import re
from datetime import datetime
from enum import Enum
from typing import Literal, TypeAlias

from dateutil.parser import ParserError, parse

from persona_dsl.components.expectation import Expectation
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Table

SupportedColumn: TypeAlias = str | int | Enum


def _parse_number(
    raw_value: str, table_name: str, column_name: SupportedColumn
) -> float:
    cleaned_value = re.sub(r"[^\d\.\-]", "", raw_value)
    if not cleaned_value:
        raise ValueError(
            f"Колонка '{column_name}' таблицы '{table_name}' содержит непарсируемое числовое значение '{raw_value}'."
        )
    try:
        return float(cleaned_value)
    except ValueError as error:
        raise ValueError(
            f"Колонка '{column_name}' таблицы '{table_name}' содержит непарсируемое числовое значение '{raw_value}'."
        ) from error


def _parse_date(
    raw_value: str,
    table_name: str,
    column_name: SupportedColumn,
) -> datetime:
    try:
        return parse(raw_value)
    except (ParserError, TypeError, ValueError) as error:
        raise ValueError(
            f"Колонка '{column_name}' таблицы '{table_name}' содержит непарсируемую дату '{raw_value}'."
        ) from error


class TableColumnIsSorted(Expectation):
    """
    Проверяет, что колонка таблицы отсортирована в указанном порядке.
    """

    def __init__(
        self,
        table: Table,
        column: SupportedColumn,
        order: Literal["asc", "desc"] = "asc",
        data_type: Literal["string", "number", "date"] = "string",
    ) -> None:
        self.table = table
        self.column = column
        self.order = order
        self.data_type = data_type

    def _get_step_description(self, persona: Persona) -> str:
        return f"Проверка сортировки колонки '{self.column}' ({self.order})"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "TableColumnIsSorted не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        raw_values = self.table.get_column_data(page, self.column)

        if len(raw_values) <= 1:
            return None

        failed_at = -1
        if self.data_type == "number":
            parsed_number_values = [
                _parse_number(raw_value, self.table.name, self.column)
                for raw_value in raw_values
            ]
            failed_at = _find_float_sort_break(parsed_number_values, self.order)
        elif self.data_type == "date":
            parsed_date_values = [
                _parse_date(raw_value, self.table.name, self.column)
                for raw_value in raw_values
            ]
            failed_at = _find_datetime_sort_break(parsed_date_values, self.order)
        else:
            failed_at = _find_str_sort_break(raw_values, self.order)

        if failed_at >= 0:
            raise AssertionError(
                f"Таблица не отсортирована ({self.order}). Нарушение между "
                f"{raw_values[failed_at]} и {raw_values[failed_at + 1]}."
            )

        return None


def _find_str_sort_break(
    values: list[str],
    order: Literal["asc", "desc"],
) -> int:
    for index in range(len(values) - 1):
        if order == "asc" and values[index] > values[index + 1]:
            return index
        if order == "desc" and values[index] < values[index + 1]:
            return index
    return -1


def _find_float_sort_break(
    values: list[float],
    order: Literal["asc", "desc"],
) -> int:
    for index in range(len(values) - 1):
        if order == "asc" and values[index] > values[index + 1]:
            return index
        if order == "desc" and values[index] < values[index + 1]:
            return index
    return -1


def _find_datetime_sort_break(
    values: list[datetime],
    order: Literal["asc", "desc"],
) -> int:
    for index in range(len(values) - 1):
        if order == "asc" and values[index] > values[index + 1]:
            return index
        if order == "desc" and values[index] < values[index + 1]:
            return index
    return -1
