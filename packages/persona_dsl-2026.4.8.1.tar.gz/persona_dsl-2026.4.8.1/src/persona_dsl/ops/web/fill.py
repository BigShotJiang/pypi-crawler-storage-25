from typing import TypedDict

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Element, get_element_ui_label


class FillOptions(TypedDict, total=False):
    force: bool
    timeout: float
    no_wait_after: bool


class Fill(Ops):
    """
    Атомарное действие: заполнить поле текстом.
    По умолчанию Element.resolve() использует первую доступную стратегию
    в порядке `role` -> `label` -> `placeholder` -> `text` -> `alt_text`
    -> `title` -> `test_id` -> `ref` -> `link` -> `locator`.
    Полный проход по всем доступным стратегиям выполняется только при явном
    `Strategy.ALL`.
    Поддерживает проброс аргументов в Playwright (force, timeout, etc).
    """

    def __init__(self, element: Element, text: str, **kwargs: float | bool) -> None:
        if not isinstance(element, Element):
            raise TypeError(
                f"Fill ожидает экземпляр Element, получено: {type(element)}"
            )
        self.element = element
        self.text = text
        self.kwargs: FillOptions = {}
        for key, value in kwargs.items():
            if key == "force":
                if not isinstance(value, bool):
                    raise TypeError(f"Параметр Fill.{key} должен быть bool.")
                self.kwargs["force"] = value
            elif key == "no_wait_after":
                if not isinstance(value, bool):
                    raise TypeError(f"Параметр Fill.{key} должен быть bool.")
                self.kwargs["no_wait_after"] = value
            elif key == "timeout":
                if not isinstance(value, (int, float)) or isinstance(value, bool):
                    raise TypeError("Параметр Fill.timeout должен быть числом.")
                self.kwargs["timeout"] = float(value)
            else:
                raise TypeError(f"Неподдерживаемый параметр Fill: '{key}'.")

    def _get_step_description(self, persona: Persona) -> str:
        # Не логируем пароли и другие чувствительные данные
        text_to_log = self.text
        name_lower = self.element.name.lower()
        accessible_name_lower = (self.element.accessible_name or "").lower()
        if (
            "password" in name_lower
            or "pass" in name_lower
            or "парол" in accessible_name_lower
        ):
            text_to_log = "****"
        extra = f" с параметрами {self.kwargs}" if self.kwargs else ""
        return f"{persona} заполняет поле '{get_element_ui_label(self.element)}' текстом '{text_to_log}'{extra}"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError("Fill не принимает дополнительные аргументы выполнения.")

        page = require_browser_page(persona)
        locator = self.element.resolve(page)
        locator.fill(self.text, **self.kwargs)
