from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Element, get_element_ui_label


class ElementIsVisible(Ops):
    """
    Бизнес-факт: проверить видимость элемента.
    По умолчанию Element.resolve() использует первую доступную стратегию
    в порядке `role` -> `label` -> `placeholder` -> `text` -> `alt_text`
    -> `title` -> `test_id` -> `ref` -> `link` -> `locator`.
    Полный проход по всем доступным стратегиям выполняется только при явном
    `Strategy.ALL`.
    """

    def __init__(self, element: Element):
        if not isinstance(element, Element):
            raise TypeError(
                f"ElementIsVisible ожидает экземпляр Element, получено: {type(element)}"
            )
        self.element = element

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} проверяет видимость элемента '{get_element_ui_label(self.element)}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> bool:
        """Возвращает True, если элемент видим."""
        if args or kwargs:
            raise TypeError(
                "ElementIsVisible не принимает дополнительные аргументы выполнения."
            )

        page = require_browser_page(persona)
        return self.element.resolve(page).is_visible()
