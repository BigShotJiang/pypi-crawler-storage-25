import allure
from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Element, get_element_ui_label
from persona_dsl.utils.artifacts import RuntimeArtifacts, persist_text_artifact


class PageAriaSnapshot(Ops):
    """
    Факт: получить ARIA-снепшот всей страницы (page.locator("body").aria_snapshot()).
    Возвращает YAML-строку с ролями/именами/состояниями.
    """

    def __init__(self, timeout: float | None = None):
        """
        Args:
            timeout: Необязательный таймаут Playwright-операции.
        """
        self.timeout = timeout

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} получает ARIA-снепшот страницы"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> str:
        if args or kwargs:
            raise TypeError(
                "PageAriaSnapshot не принимает дополнительные аргументы выполнения."
            )
        page = require_browser_page(persona)
        body_locator = page.locator("body")
        if not hasattr(body_locator, "aria_snapshot"):
            raise RuntimeError(
                "Эта версия Playwright не поддерживает Locator.aria_snapshot(). Обновите до 1.55+."
            )
        snapshot = body_locator.aria_snapshot(timeout=self.timeout)
        allure.attach(
            snapshot,
            name="aria-page",
            attachment_type=allure.attachment_type.TEXT,
        )
        return snapshot

    def _get_runtime_artifacts(
        self,
        value: object,
        timestamp: float,
    ) -> RuntimeArtifacts:
        if not isinstance(value, str) or not value.strip():
            return RuntimeArtifacts()
        path, url = persist_text_artifact(
            subdir="snapshots",
            component_name="page-aria-snapshot",
            extension=".yaml",
            content=value,
            timestamp=timestamp,
        )
        return RuntimeArtifacts(snapshot_path=path, snapshot_url=url)


class ElementAriaSnapshot(Ops):
    """
    Факт: получить ARIA-снепшот элемента.
    Возвращает YAML-строку.
    """

    def __init__(
        self,
        element: Element,
        timeout: float | None = None,
    ):
        """
        Args:
            element: Экземпляр элемента страницы.
            timeout: Необязательный таймаут Playwright-операции.
        """
        self.element = element
        self.timeout = timeout

    def _get_step_description(self, persona: Persona) -> str:
        target = f"элемента '{get_element_ui_label(self.element)}'"
        return f"{persona} получает ARIA-снепшот {target}"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> str:
        if args or kwargs:
            raise TypeError(
                "ElementAriaSnapshot не принимает дополнительные аргументы выполнения."
            )
        page = require_browser_page(persona)
        locator = self.element.resolve(page)

        if not hasattr(locator, "aria_snapshot"):
            raise RuntimeError(
                "Эта версия Playwright не поддерживает Locator.aria_snapshot(). Обновите до 1.55+."
            )

        snapshot = locator.aria_snapshot(timeout=self.timeout)
        attach_name = f"aria-element:{get_element_ui_label(self.element)}"

        allure.attach(
            snapshot,
            name=attach_name,
            attachment_type=allure.attachment_type.TEXT,
        )
        return snapshot

    def _get_runtime_artifacts(
        self,
        value: object,
        timestamp: float,
    ) -> RuntimeArtifacts:
        if not isinstance(value, str) or not value.strip():
            return RuntimeArtifacts()
        path, url = persist_text_artifact(
            subdir="snapshots",
            component_name=f"element-aria-snapshot-{get_element_ui_label(self.element)}",
            extension=".yaml",
            content=value,
            timestamp=timestamp,
        )
        return RuntimeArtifacts(snapshot_path=path, snapshot_url=url)
