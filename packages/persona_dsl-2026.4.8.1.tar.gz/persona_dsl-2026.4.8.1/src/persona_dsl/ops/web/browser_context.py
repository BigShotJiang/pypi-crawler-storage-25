from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import TypeGuard

from playwright.sync_api import Locator
from persona_dsl.persona import Persona
from persona_dsl.pages.elements import BrowserPageLike, Element
from persona_dsl.skills.core.skill_definition import SkillId


def _is_browser_page_like(value: object) -> TypeGuard[BrowserPageLike]:
    required_attributes = (
        "goto",
        "locator",
        "get_by_test_id",
        "get_by_role",
        "get_by_label",
        "get_by_text",
        "get_by_placeholder",
        "get_by_alt_text",
        "get_by_title",
        "evaluate",
        "screenshot",
        "wait_for_load_state",
    )
    return all(hasattr(value, attribute) for attribute in required_attributes)


def _is_locator_like(value: object) -> TypeGuard[Locator]:
    required_attributes = (
        "locator",
        "filter",
        "count",
        "text_content",
        "get_attribute",
        "click",
        "fill",
        "press",
        "is_visible",
        "evaluate",
    )
    return all(hasattr(value, attribute) for attribute in required_attributes)


def require_browser_page(persona: Persona) -> BrowserPageLike:
    skill_method_obj = getattr(persona, "skill", None)
    if skill_method_obj is None or not callable(skill_method_obj):
        raise TypeError("Persona должна предоставлять вызываемый метод skill(...).")

    skill_method: Callable[[SkillId], object] = skill_method_obj
    skill = skill_method(SkillId.BROWSER)
    page = getattr(skill, "page", None)
    if not _is_browser_page_like(page):
        raise TypeError(
            "SkillId.BROWSER должен возвращать навык с доступной браузерной страницей."
        )
    return page


def require_target_locator(
    persona: Persona,
    args: tuple[object, ...],
    kwargs: Mapping[str, object],
    *,
    component_name: str,
) -> Locator:
    if kwargs:
        raise TypeError(
            f"{component_name} не принимает именованные аргументы выполнения."
        )
    if len(args) != 1:
        raise TypeError(
            f"{component_name} ожидает ровно один целевой Element или Playwright Locator."
        )

    target = args[0]
    page = require_browser_page(persona)
    if isinstance(target, Element):
        resolved_target = target.resolve(page)
        if _is_locator_like(resolved_target):
            return resolved_target
        raise TypeError(
            f"{component_name} не смог зарезолвить Element до Playwright Locator."
        )
    if _is_locator_like(target):
        return target

    raise TypeError(
        f"{component_name} ожидает Element или Playwright Locator, получено: {type(target)}."
    )
