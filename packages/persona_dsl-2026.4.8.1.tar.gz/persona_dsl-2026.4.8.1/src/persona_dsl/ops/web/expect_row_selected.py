from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import TableRow


class ExpectRowSelected(Ops):
    """
    Ожидает, что строка таблицы находится в определенном состоянии выделения (выбрана/не выбрана).
    Проверяет состояние через чекбокс или наличие класса `-selected`.
    """

    def __init__(self, table_row: TableRow, state: bool = True):
        self.table_row = table_row
        self.state = state

    def _get_step_description(self, persona: Persona) -> str:
        expected = "выбрана" if self.state else "не выбрана"
        return f"{persona} проверяет, что {self.table_row.name} {expected}"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "ExpectRowSelected не принимает дополнительные аргументы выполнения."
            )
        page = require_browser_page(persona)
        row_loc = self.table_row.resolve(page)

        class_attr = row_loc.get_attribute("class") or ""
        is_selected_by_class = "selected" in class_attr.split()
        aria_selected = row_loc.get_attribute("aria-selected")

        checkbox_loc = self.table_row.checkbox.resolve(page)
        input_loc = checkbox_loc.locator("input[type='checkbox']")
        detected_states: list[tuple[str, bool]] = []
        if input_loc.count() > 0:
            detected_states.append(("checkbox", input_loc.first.is_checked()))
        elif checkbox_loc.count() > 0:
            detected_states.append(("checkbox", checkbox_loc.is_checked()))

        if aria_selected is not None:
            if aria_selected == "true":
                detected_states.append(("aria-selected", True))
            elif aria_selected == "false":
                detected_states.append(("aria-selected", False))
            else:
                raise RuntimeError(
                    f"Строка {self.table_row.name} содержит недопустимое aria-selected={aria_selected!r}."
                )

        if is_selected_by_class:
            detected_states.append(("css-class", True))

        if not detected_states:
            raise RuntimeError(
                f"Не удалось определить состояние выделения строки {self.table_row.name}: "
                "нет явного checkbox, aria-selected или CSS-признака selected."
            )

        unique_states = {state for _, state in detected_states}
        if len(unique_states) != 1:
            signals = ", ".join(
                f"{source}={state}" for source, state in detected_states
            )
            raise RuntimeError(
                f"Строка {self.table_row.name} содержит противоречивые признаки выделения: {signals}."
            )

        actual_state = unique_states.pop()
        if actual_state != self.state:
            raise AssertionError(
                f"Ожидалось состояние 'выбрана' = {self.state}, "
                f"но текущее состояние = {actual_state}."
            )
