from typing import Literal

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.ops.web.browser_context import require_browser_page
from persona_dsl.pages.elements import Table


class ExpectTableSelectionState(Ops):
    """
    Ожидает определённого состояния главного чекбокса ("Выбрать все") в заголовке таблицы.
    state может быть "all" (выбрано), "none" (не выбрано), или "partial" (частичное выделение/indeterminate).
    """

    def __init__(self, table: Table, state: Literal["all", "none", "partial"]):
        if not isinstance(table, Table):
            raise TypeError(f"Ожидается элемент Table, получено {type(table)}")
        self.table = table
        self.state = state

    def _get_step_description(self, persona: Persona) -> str:
        state_ru = {
            "all": "выбраны все строки",
            "none": "нет выбранных строк",
            "partial": "частично выбраны (indeterminate)",
        }[self.state]
        return f"{persona} проверяет, что в {self.table.name} {state_ru}"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> None:
        if args or kwargs:
            raise TypeError(
                "ExpectTableSelectionState не принимает дополнительные аргументы выполнения."
            )
        page = require_browser_page(persona)
        checkbox_loc = self.table.select_all_checkbox.resolve(page)

        if checkbox_loc.count() == 0:
            raise RuntimeError(
                f"Не удалось найти чекбокс 'Выбрать все' в заголовках таблицы {self.table.name}"
            )

        is_checked = checkbox_loc.is_checked()
        is_indeterminate_value = checkbox_loc.evaluate(
            "el => el.indeterminate === true"
        )
        if not isinstance(is_indeterminate_value, bool):
            raise TypeError(
                "Проверка indeterminate должна возвращать логическое значение."
            )
        is_indeterminate = is_indeterminate_value

        if self.state == "all":
            if not is_checked or is_indeterminate:
                raise AssertionError(
                    "Ожидалось полное выделение (all), "
                    f"но is_checked={is_checked}, indeterminate={is_indeterminate}."
                )
            return

        if self.state == "partial":
            if not is_indeterminate:
                raise AssertionError(
                    "Ожидалось частичное выделение (partial), "
                    f"но indeterminate={is_indeterminate}, is_checked={is_checked}."
                )
            return

        if is_checked or is_indeterminate:
            raise AssertionError(
                "Ожидалось отсутствие выделения (none), "
                f"но is_checked={is_checked}, indeterminate={is_indeterminate}."
            )
