from __future__ import annotations

from collections.abc import Callable, Sequence

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_database import UseDatabase


def _require_database_skill(persona: Persona) -> UseDatabase:
    skill_method_obj = getattr(persona, "skill", None)
    if skill_method_obj is None or not callable(skill_method_obj):
        raise TypeError("Persona должна предоставлять вызываемый метод skill(...).")
    skill_method: Callable[[SkillId], object] = skill_method_obj
    skill = skill_method(SkillId.DB)
    if not isinstance(skill, UseDatabase):
        raise TypeError("SkillId.DB должен возвращать UseDatabase.")
    return skill


class FetchAll(Ops):
    """
    Низкоуровневая операция: выполняет SQL-запрос и возвращает все строки.
    """

    def __init__(
        self,
        query: str,
        params: Sequence[object] | object | None = None,
    ) -> None:
        self.query = query
        self.params = params

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} получает все записи по SQL-запросу: {self.query[:100]}"

    def _perform(
        self,
        persona: Persona,
        *args: object,
        **kwargs: object,
    ) -> list[object]:
        db = _require_database_skill(persona)
        conn = db.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(self.query, self.params if self.params is not None else ())
            return cursor.fetchall()
        finally:
            cursor.close()
