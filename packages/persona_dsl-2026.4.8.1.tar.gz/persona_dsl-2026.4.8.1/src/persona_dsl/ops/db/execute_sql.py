from __future__ import annotations

from collections.abc import Callable, Sequence

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_database import UseDatabase


def _require_database_skill(persona: Persona) -> UseDatabase:
    skill_method_obj = getattr(persona, "skill", None)
    if skill_method_obj is None or not callable(skill_method_obj):
        raise TypeError("Persona должна предоставлять вызываемый метод skill(...).")
    skill_method: Callable[[SkillId], object] = skill_method_obj
    skill = skill_method(SkillId.DB)
    if not isinstance(skill, UseDatabase):
        raise TypeError("SkillId.DB должен возвращать UseDatabase.")
    return skill


class ExecuteSQL(Ops):
    """
    Низкоуровневая операция: выполняет SQL-запрос без возврата результата.
    """

    def __init__(
        self,
        query: str,
        params: Sequence[object] | object | None = None,
    ) -> None:
        self.query = query
        self.params = params

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} выполняет SQL-запрос: {self.query[:100]}"

    def _perform(
        self,
        persona: Persona,
        *args: object,
        **kwargs: object,
    ) -> None:
        db = _require_database_skill(persona)
        db.execute(self.query, self.params)
