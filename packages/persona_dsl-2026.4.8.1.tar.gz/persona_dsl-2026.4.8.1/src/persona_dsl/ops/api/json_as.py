from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Generic, TypeVar

import requests

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_api import UseAPI

ResponseModelT = TypeVar("ResponseModelT")


def _require_api_skill(persona: Persona) -> UseAPI:
    skill_method_obj = getattr(persona, "skill", None)
    if skill_method_obj is None or not callable(skill_method_obj):
        raise TypeError("Persona должна предоставлять вызываемый метод skill(...).")
    skill_method: Callable[[SkillId], object] = skill_method_obj
    skill = skill_method(SkillId.API)
    if not isinstance(skill, UseAPI):
        raise TypeError("SkillId.API должен возвращать UseAPI.")
    return skill


class JsonAs(Ops, Generic[ResponseModelT]):
    """
    Низкоуровневая операция: делает HTTP-запрос и валидирует JSON-ответ как указанный тип.
    Использует типизированные методы UseAPI (get_json_as/post_json_as/...).
    Возвращает типизированный объект согласно model_type.
    """

    def __init__(
        self,
        method: str,
        path: str,
        model_type: type[ResponseModelT],
        json: object | None = None,
        params: Mapping[str, object] | None = None,
        headers: Mapping[str, str] | None = None,
        **kwargs: object,
    ) -> None:
        self.method = method
        self.path = path
        self.model_type = model_type
        self.json = json
        self.params = params
        self.headers = headers
        self.kwargs = kwargs

    def _get_step_description(self, persona: Persona) -> str:
        return (
            f"{persona} запрашивает {self.method.upper()} '{self.path}' "
            f"и парсит JSON как {self.model_type.__name__}"
        )

    def _perform(
        self,
        persona: Persona,
        *args: object,
        **kwargs: object,
    ) -> ResponseModelT:
        api = _require_api_skill(persona)
        m = self.method.upper()
        request_kwargs = {
            "params": self.params,
            "headers": self.headers,
            "json": self.json,
            **self.kwargs,
        }
        if m == "GET":
            response = api.get(self.path, **request_kwargs)
        elif m == "POST":
            response = api.post(self.path, **request_kwargs)
        elif m == "PUT":
            response = api.put(self.path, **request_kwargs)
        elif m == "PATCH":
            response = api.patch(self.path, **request_kwargs)
        elif m == "DELETE":
            response = api.delete(self.path, **request_kwargs)
        elif m == "HEAD":
            response = api.head(self.path, **request_kwargs)
        elif m == "OPTIONS":
            response = api.options(self.path, **request_kwargs)
        else:
            raise ValueError(f"JsonAs: неподдерживаемый метод {self.method}")

        if not response.text:
            payload: object = None
        else:
            try:
                payload = response.json()
            except requests.JSONDecodeError as error:
                raise ValueError(
                    f"{m} {self.path}: ответ не является валидным JSON: {error}"
                ) from error
        return api._validate_as(payload, self.model_type)
