from __future__ import annotations

from collections.abc import Callable, Mapping

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_api import UseAPI


def _require_api_skill(persona: Persona) -> UseAPI:
    skill_method_obj = getattr(persona, "skill", None)
    if skill_method_obj is None or not callable(skill_method_obj):
        raise TypeError("Persona должна предоставлять вызываемый метод skill(...).")
    skill_method: Callable[[SkillId], object] = skill_method_obj
    skill = skill_method(SkillId.API)
    if not isinstance(skill, UseAPI):
        raise TypeError("SkillId.API должен возвращать UseAPI.")
    return skill


class SendRequest(Ops):
    """
    Низкоуровневая операция: отправляет HTTP-запрос.
    """

    def __init__(
        self,
        method: str,
        path: str,
        json: object | None = None,
        params: Mapping[str, object] | None = None,
        headers: Mapping[str, str] | None = None,
        **kwargs: object,
    ) -> None:
        self.method = method
        self.path = path
        self.json = json
        self.params = params
        self.headers = headers
        self.kwargs = kwargs

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} отправляет {self.method.upper()} запрос на '{self.path}'"

    def _perform(
        self,
        persona: Persona,
        *args: object,
        **kwargs: object,
    ) -> None:
        api = _require_api_skill(persona)
        api._request(
            method=self.method,
            path=self.path,
            json=self.json,
            params=self.params,
            headers=self.headers,
            **self.kwargs,
        )
