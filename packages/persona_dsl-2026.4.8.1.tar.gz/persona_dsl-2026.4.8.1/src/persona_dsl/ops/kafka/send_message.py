from __future__ import annotations

from collections.abc import Callable

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.schema_runtime.registry import serialize_registered_model
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_kafka import UseKafka


def _require_kafka_skill(persona: Persona) -> UseKafka:
    skill_method_obj = getattr(persona, "skill", None)
    if skill_method_obj is None or not callable(skill_method_obj):
        raise TypeError("Persona должна предоставлять вызываемый метод skill(...).")
    skill_method: Callable[[SkillId], object] = skill_method_obj
    skill = skill_method(SkillId.KAFKA)
    if not isinstance(skill, UseKafka):
        raise TypeError("SkillId.KAFKA должен возвращать UseKafka.")
    return skill


class SendMessage(Ops):
    """
    Низкоуровневая операция: отправляет в Kafka bytes, str или schema-first объект.
    """

    def __init__(
        self,
        topic: str,
        value: object,
        key: bytes | None = None,
        headers: list[tuple[str, bytes]] | None = None,
    ) -> None:
        self.topic = topic
        self.value = value
        self.key = key
        self.headers = headers

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} отправляет сообщение в Kafka топик '{self.topic}'"

    def _perform(
        self,
        persona: Persona,
        *args: object,
        **kwargs: object,
    ) -> None:
        if args or kwargs:
            raise TypeError(
                "SendMessage не принимает дополнительные аргументы выполнения."
            )

        kafka = _require_kafka_skill(persona)
        if isinstance(self.value, bytes):
            payload = self.value
        elif isinstance(self.value, str):
            payload = self.value.encode("utf-8")
        else:
            try:
                payload = serialize_registered_model(self.value)
            except LookupError as error:
                raise TypeError(
                    f"Для типа '{type(self.value).__name__}' не зарегистрирован schema codec."
                ) from error

        kafka.send_message(
            topic=self.topic,
            message=payload,
            key=self.key,
            headers=self.headers,
        )
