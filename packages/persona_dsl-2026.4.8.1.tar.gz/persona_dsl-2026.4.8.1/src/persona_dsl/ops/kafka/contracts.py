from __future__ import annotations

from typing import Generic, TypeVar, TypedDict

from persona_dsl.json_types import JsonValue

ModelT = TypeVar("ModelT")


class KafkaMessageEnvelope(TypedDict):
    topic: str
    partition: int
    offset: int
    timestamp: int
    key: str | None
    value_raw: str | None
    value_json: JsonValue | None
    headers: dict[str, bytes]


class DecodedKafkaMessage(TypedDict, Generic[ModelT]):
    topic: str
    partition: int
    offset: int
    timestamp: int
    key: str | None
    value_raw: str | None
    value_model: ModelT
    headers: dict[str, bytes]
