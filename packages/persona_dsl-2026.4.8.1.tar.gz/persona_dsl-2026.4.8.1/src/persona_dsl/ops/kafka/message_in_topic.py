from __future__ import annotations

from collections.abc import Callable
import json
from typing import Generic, TypeAlias, TypeGuard, TypeVar

from persona_dsl.components.ops import Ops
from persona_dsl.ops.kafka.contracts import DecodedKafkaMessage, KafkaMessageEnvelope
from persona_dsl.persona import Persona
from persona_dsl.schema_runtime.registry import deserialize_registered_payload
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_kafka import ConsumedKafkaMessage, UseKafka

JsonScalar: TypeAlias = str | int | float | bool | None
JsonValue: TypeAlias = JsonScalar | list["JsonValue"] | dict[str, "JsonValue"]
ModelT = TypeVar("ModelT")
TopicMessage: TypeAlias = KafkaMessageEnvelope


def _require_kafka_skill(persona: Persona) -> UseKafka:
    skill_method_obj = getattr(persona, "skill", None)
    if skill_method_obj is None or not callable(skill_method_obj):
        raise TypeError("Persona должна предоставлять вызываемый метод skill(...).")
    skill_method: Callable[[SkillId], object] = skill_method_obj
    skill = skill_method(SkillId.KAFKA)
    if not isinstance(skill, UseKafka):
        raise TypeError("SkillId.KAFKA должен возвращать UseKafka.")
    return skill


def _is_json_value(value: object) -> TypeGuard[JsonValue]:
    if value is None or isinstance(value, str | int | float | bool):
        return True
    if isinstance(value, list):
        return all(_is_json_value(item) for item in value)
    if isinstance(value, dict):
        return all(
            isinstance(key, str) and _is_json_value(item) for key, item in value.items()
        )
    return False


def _decode_utf8(raw_value: bytes | None, *, field_name: str) -> str | None:
    if raw_value is None:
        return None
    return raw_value.decode("utf-8")


def _parse_json_value(raw_text: str | None) -> JsonValue | None:
    if raw_text is None:
        return None

    try:
        parsed_value = json.loads(raw_text)
    except json.JSONDecodeError:
        return None

    if not _is_json_value(parsed_value):
        raise TypeError("JSON payload Kafka-сообщения должен быть JSON-совместимым.")
    return parsed_value


class MessageInTopic(
    Ops[KafkaMessageEnvelope | DecodedKafkaMessage[ModelT] | None],
    Generic[ModelT],
):
    """
    Факт: получить сообщение из Kafka-топика.
    Опционально фильтрует по ключу и простому подмножеству полей JSON-пейлоада.
    Возвращает словарь:
      { topic, partition, offset, timestamp, key, value_raw, value_json, headers }.
    """

    def __init__(
        self,
        topic: str,
        key: str | None = None,
        filter: dict[str, JsonValue] | None = None,
        max_messages: int = 10,
        timeout: float | None = None,
        as_type: type[ModelT] | None = None,
    ) -> None:
        self.topic = topic
        self.key = key
        self.filter = filter
        self.max_messages = max_messages
        self.timeout = timeout
        self.as_type = as_type

    def _get_step_description(self, persona: Persona) -> str:
        base = f"{persona} читает сообщения из Kafka топика '{self.topic}'"
        if self.key:
            base += f" с ключом '{self.key}'"
        return base

    def _perform(
        self, persona: Persona, *args: object, **kwargs: object
    ) -> KafkaMessageEnvelope | DecodedKafkaMessage[ModelT] | None:
        if args or kwargs:
            raise TypeError(
                "MessageInTopic не принимает дополнительные аргументы выполнения."
            )
        if self.as_type is not None and self.filter is not None:
            raise TypeError(
                "MessageInTopic не поддерживает одновременное использование filter и as_type."
            )

        kafka = _require_kafka_skill(persona)
        messages = kafka.consume(
            self.topic, max_messages=self.max_messages, timeout=self.timeout
        )

        def _matches_filter(payload_obj: JsonValue | None) -> bool:
            if not self.filter:
                return True
            if not isinstance(payload_obj, dict):
                return False
            for field_name, expected_value in self.filter.items():
                if payload_obj.get(field_name) != expected_value:
                    return False
            return True

        for message in messages:
            typed_message: ConsumedKafkaMessage = message
            key_str = _decode_utf8(typed_message["key"], field_name="key")
            if self.key is not None and key_str != self.key:
                continue

            raw_value = typed_message["value"]
            text_value = _decode_utf8(typed_message["value"], field_name="value")
            if self.as_type is not None:
                if raw_value is None:
                    raise TypeError(
                        f"Kafka payload для '{self.as_type.__name__}' не может быть пустым."
                    )
                try:
                    value_model = deserialize_registered_payload(
                        raw_value, self.as_type
                    )
                except LookupError as error:
                    raise TypeError(
                        f"Для типа '{self.as_type.__name__}' не зарегистрирован schema codec."
                    ) from error
                return {
                    "topic": typed_message["topic"],
                    "partition": typed_message["partition"],
                    "offset": typed_message["offset"],
                    "timestamp": typed_message["timestamp"],
                    "key": key_str,
                    "value_raw": text_value,
                    "value_model": value_model,
                    "headers": typed_message["headers"],
                }

            parsed_value = _parse_json_value(text_value)
            if not _matches_filter(parsed_value):
                continue
            return {
                "topic": typed_message["topic"],
                "partition": typed_message["partition"],
                "offset": typed_message["offset"],
                "timestamp": typed_message["timestamp"],
                "key": key_str,
                "value_raw": text_value,
                "value_json": parsed_value,
                "headers": typed_message["headers"],
            }
        return None
