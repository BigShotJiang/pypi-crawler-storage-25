from __future__ import annotations

from collections.abc import Callable

from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_soap import UseSOAP


def _require_soap_skill(persona: Persona) -> UseSOAP:
    skill_method_obj = getattr(persona, "skill", None)
    if skill_method_obj is None or not callable(skill_method_obj):
        raise TypeError("Persona должна предоставлять вызываемый метод skill(...).")
    skill_method: Callable[[SkillId], object] = skill_method_obj
    skill = skill_method(SkillId.SOAP)
    if not isinstance(skill, UseSOAP):
        raise TypeError("SkillId.SOAP должен возвращать UseSOAP.")
    return skill


class CallOperation(Ops):
    """
    Низкоуровневая операция: вызывает SOAP-операцию без возврата результата.
    """

    def __init__(
        self,
        service: str,
        operation: str,
        *args: object,
        **kwargs: object,
    ) -> None:
        self.service = service
        self.operation = operation
        self.args = args
        self.kwargs = kwargs

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} вызывает SOAP операцию '{self.operation}' сервиса '{self.service}'"

    def _perform(
        self,
        persona: Persona,
        *args: object,
        **kwargs: object,
    ) -> None:
        soap = _require_soap_skill(persona)
        soap.call(self.service, self.operation, *self.args, **self.kwargs)
