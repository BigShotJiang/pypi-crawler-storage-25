from persona_dsl.components.ops import Ops
from persona_dsl.persona import Persona
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_soap import UseSOAP


class OperationResult(Ops):
    """
    Низкоуровневая операция: вызывает SOAP-операцию и возвращает результат.
    """

    def __init__(
        self,
        service: str,
        operation: str,
        *args: object,
        **kwargs: object,
    ) -> None:
        self.service = service
        self.operation = operation
        self.args = args
        self.kwargs = kwargs

    def _get_step_description(self, persona: Persona) -> str:
        return f"{persona} получает результат SOAP операции '{self.operation}' сервиса '{self.service}'"

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> object:
        if args or kwargs:
            raise TypeError(
                "OperationResult не принимает дополнительные аргументы выполнения."
            )

        skill_method_obj = getattr(persona, "skill", None)
        if skill_method_obj is None or not callable(skill_method_obj):
            raise TypeError("Persona должна предоставлять вызываемый метод skill(...).")

        soap = skill_method_obj(SkillId.SOAP)
        if not isinstance(soap, UseSOAP):
            raise TypeError("OperationResult требует наличия навыка UseSOAP.")
        return soap.call(self.service, self.operation, *self.args, **self.kwargs)
