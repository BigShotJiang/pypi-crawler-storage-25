from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from persona_dsl.discovery.project import (
    build_project_index,
    find_symbol_usages,
    get_discovery_diagnostics,
    get_knowledge_bundle,
    get_project_summary,
    get_symbol,
)


@dataclass(slots=True)
class ToolDefinition:
    name: str
    description: str
    input_schema: dict[str, object]
    handler: Callable[[Path, dict[str, object]], object]


def build_tool_definitions() -> list[ToolDefinition]:
    return [
        ToolDefinition(
            name="project_summary",
            description="Возвращает сводку по проекту Persona DSL.",
            input_schema={
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
            handler=lambda root, _args: get_project_summary(root).model_dump(
                mode="python"
            ),
        ),
        ToolDefinition(
            name="list_components",
            description="Возвращает каталог компонентов и операций проекта.",
            input_schema={
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
            handler=lambda root, _args: [
                item.model_dump(mode="python")
                for item in build_project_index(root).components
            ],
        ),
        ToolDefinition(
            name="get_component",
            description="Возвращает один компонент по id.",
            input_schema=_id_schema("component_id"),
            handler=lambda root, args: _dump_symbol(
                get_symbol(root, _require_str(args, "component_id"))
            ),
        ),
        ToolDefinition(
            name="find_component_descendants",
            description="Возвращает потомков компонента по id.",
            input_schema=_id_schema("component_id"),
            handler=lambda root, args: _find_component_descendants(
                root, _require_str(args, "component_id")
            ),
        ),
        ToolDefinition(
            name="list_tests",
            description="Возвращает каталог тестов проекта.",
            input_schema={
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
            handler=lambda root, _args: [
                item.model_dump(mode="python")
                for item in build_project_index(root).tests
            ],
        ),
        ToolDefinition(
            name="get_test",
            description="Возвращает один тест по id.",
            input_schema=_id_schema("test_id"),
            handler=lambda root, args: _dump_symbol(
                get_symbol(root, _require_str(args, "test_id"))
            ),
        ),
        ToolDefinition(
            name="list_pages",
            description="Возвращает каталог страниц проекта.",
            input_schema={
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
            handler=lambda root, _args: [
                item.model_dump(mode="python")
                for item in build_project_index(root).pages
            ],
        ),
        ToolDefinition(
            name="get_page",
            description="Возвращает одну страницу по id.",
            input_schema=_id_schema("page_id"),
            handler=lambda root, args: _dump_symbol(
                get_symbol(root, _require_str(args, "page_id"))
            ),
        ),
        ToolDefinition(
            name="list_skills",
            description="Возвращает каталог навыков проекта.",
            input_schema={
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
            handler=lambda root, _args: [
                item.model_dump(mode="python")
                for item in build_project_index(root).skills
            ],
        ),
        ToolDefinition(
            name="list_docs",
            description="Возвращает каталог документов проекта.",
            input_schema={
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
            handler=lambda root, _args: [
                item.model_dump(mode="python")
                for item in build_project_index(root).docs
            ],
        ),
        ToolDefinition(
            name="get_doc",
            description="Возвращает один документ по id.",
            input_schema=_id_schema("doc_id"),
            handler=lambda root, args: _dump_symbol(
                get_symbol(root, _require_str(args, "doc_id"))
            ),
        ),
        ToolDefinition(
            name="list_configs",
            description="Возвращает summary по доступным config/{env}.yaml.",
            input_schema={
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
            handler=lambda root, _args: [
                item.model_dump(mode="python")
                for item in build_project_index(root).configs
            ],
        ),
        ToolDefinition(
            name="get_principles",
            description="Возвращает knowledge bundle с принципами проекта.",
            input_schema={
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
            handler=lambda root, _args: get_knowledge_bundle(
                root, "project_principles"
            ).model_dump(mode="python"),
        ),
        ToolDefinition(
            name="get_knowledge_bundle",
            description="Возвращает один curated knowledge bundle.",
            input_schema={
                "type": "object",
                "properties": {
                    "bundle_id": {"type": "string"},
                },
                "required": ["bundle_id"],
                "additionalProperties": False,
            },
            handler=lambda root, args: get_knowledge_bundle(
                root, _require_str(args, "bundle_id")
            ).model_dump(mode="python"),
        ),
        ToolDefinition(
            name="find_symbol_usages",
            description="Возвращает reference symbol с определением и usages.",
            input_schema=_id_schema("symbol_id"),
            handler=lambda root, args: find_symbol_usages(
                root, _require_str(args, "symbol_id")
            ).model_dump(mode="python"),
        ),
        ToolDefinition(
            name="get_discovery_diagnostics",
            description="Возвращает диагностические сообщения discovery-слоя.",
            input_schema={
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
            handler=lambda root, _args: [
                item.model_dump(mode="python")
                for item in get_discovery_diagnostics(root)
            ],
        ),
    ]


def handle_request(
    *,
    project_root: Path,
    method: str,
    params: dict[str, object] | None,
) -> dict[str, object] | None:
    if method == "initialize":
        return {
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": "persona-mcp", "version": "0.1.0"},
        }
    if method == "shutdown":
        return {}
    if method == "exit":
        return None
    if method == "notifications/initialized":
        return None
    if method == "tools/list":
        return {
            "tools": [
                {
                    "name": tool.name,
                    "description": tool.description,
                    "inputSchema": tool.input_schema,
                }
                for tool in build_tool_definitions()
            ]
        }
    if method == "tools/call":
        if params is None:
            raise ValueError("tools/call требует params.")
        tool_name = _require_str(params, "name")
        arguments = params.get("arguments", {})
        if arguments is None:
            arguments = {}
        if not isinstance(arguments, dict):
            raise TypeError("tools/call.arguments должен быть объектом.")
        tool = next(
            (item for item in build_tool_definitions() if item.name == tool_name), None
        )
        if tool is None:
            raise ValueError(f"Неизвестный tool: {tool_name}")
        structured = tool.handler(project_root, arguments)
        return {
            "content": [
                {
                    "type": "text",
                    "text": json.dumps(
                        structured,
                        ensure_ascii=False,
                        indent=2,
                    ),
                }
            ],
            "structuredContent": structured,
        }
    raise ValueError(f"Unsupported MCP method: {method}")


def _require_str(data: dict[str, object], field_name: str) -> str:
    value = data.get(field_name)
    if not isinstance(value, str) or not value:
        raise TypeError(f"Поле {field_name} должно быть непустой строкой.")
    return value


def _id_schema(field_name: str) -> dict[str, object]:
    return {
        "type": "object",
        "properties": {
            field_name: {"type": "string"},
        },
        "required": [field_name],
        "additionalProperties": False,
    }


def _dump_symbol(symbol: object) -> dict[str, object]:
    model_dump = getattr(symbol, "model_dump", None)
    if callable(model_dump):
        dumped = model_dump(mode="python")
        if isinstance(dumped, dict):
            return dumped
    raise TypeError(f"Символ {symbol!r} не поддерживает model_dump(mode='python').")


def _find_component_descendants(
    project_root: Path, component_id: str
) -> list[dict[str, object]]:
    index = build_project_index(project_root)
    component = next(
        (item for item in index.components if item.id == component_id),
        None,
    )
    if component is None:
        raise ValueError(f"Компонент не найден: {component_id}")
    descendants = {
        item.id: item
        for item in index.components
        if item.id in component.descendant_ids
    }
    return [item.model_dump(mode="python") for item in descendants.values()]
