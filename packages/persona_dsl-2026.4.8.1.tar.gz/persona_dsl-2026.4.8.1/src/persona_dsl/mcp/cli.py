from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .server import handle_request


def main() -> int:
    parser = argparse.ArgumentParser(description="Persona MCP server")
    parser.add_argument(
        "--project-root",
        default=".",
        help="Путь к persona-проекту, который индексирует сервер.",
    )
    args = parser.parse_args()
    project_root = Path(args.project_root).resolve()

    while True:
        message = _read_message()
        if message is None:
            return 0
        response = _dispatch_message(project_root, message)
        if response is not None:
            _write_message(response)


def _dispatch_message(
    project_root: Path, message: dict[str, object]
) -> dict[str, object] | None:
    jsonrpc = message.get("jsonrpc")
    if jsonrpc != "2.0":
        raise ValueError("Поддерживается только JSON-RPC 2.0.")

    method = message.get("method")
    if not isinstance(method, str):
        raise TypeError("JSON-RPC request должен содержать строковое поле method.")

    request_id = message.get("id")
    params = message.get("params")
    typed_params: dict[str, object] | None
    if params is None:
        typed_params = None
    elif isinstance(params, dict):
        typed_params = params
    else:
        raise TypeError("JSON-RPC params должен быть объектом.")

    try:
        result = handle_request(
            project_root=project_root, method=method, params=typed_params
        )
    except (OSError, TypeError, ValueError) as error:
        if request_id is None:
            return None
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {
                "code": -32000,
                "message": str(error),
            },
        }

    if request_id is None or result is None:
        return None
    return {"jsonrpc": "2.0", "id": request_id, "result": result}


def _read_message() -> dict[str, object] | None:
    content_length: int | None = None
    while True:
        header_line = sys.stdin.buffer.readline()
        if header_line == b"":
            return None
        if header_line in {b"\r\n", b"\n"}:
            break
        name, _, value = header_line.decode("utf-8").partition(":")
        if name.lower() == "content-length":
            content_length = int(value.strip())

    if content_length is None:
        raise ValueError("Отсутствует заголовок Content-Length.")
    body = sys.stdin.buffer.read(content_length)
    if not body:
        return None
    message = json.loads(body.decode("utf-8"))
    if not isinstance(message, dict):
        raise TypeError("JSON-RPC message должен быть объектом.")
    return message


def _write_message(payload: dict[str, object]) -> None:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    sys.stdout.buffer.write(f"Content-Length: {len(body)}\r\n\r\n".encode("utf-8"))
    sys.stdout.buffer.write(body)
    sys.stdout.buffer.flush()


if __name__ == "__main__":
    raise SystemExit(main())
