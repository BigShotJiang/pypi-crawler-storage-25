from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, Literal, TypeGuard, overload

from .contracts import (
    MemoryStore,
    ResultT,
    RetryConfigMap,
    SkillEntry,
    SkillLookupKey,
    SkillProvider,
    SkillStore,
    SupportsCheck,
    SupportsExecute,
    SupportsGet,
    SupportsMake,
    SupportsStringValue,
)
from .skills.core.skill_definition import SkillId

# from .skills.core.skill_definition import SkillId  # Removed for lazy loading
from .utils.path import extract_by_path

if TYPE_CHECKING:
    from .skills.use_api import UseAPI
    from .skills.use_browser import UseBrowser
    from .skills.use_database import UseDatabase
    from .skills.use_kafka import UseKafka
    from .skills.use_soap import UseSOAP


class BaseRole(str, Enum):
    """Базовый класс для Enum'а с ролями, специфичными для проекта."""

    pass


def _has_string_value(candidate: object) -> TypeGuard[SupportsStringValue]:
    return isinstance(getattr(candidate, "value", None), str)


def _supports_get(candidate: object) -> TypeGuard[SupportsGet[object]]:
    return callable(getattr(candidate, "get", None))


def _supports_execute(candidate: object) -> TypeGuard[SupportsExecute[object]]:
    return callable(getattr(candidate, "execute", None))


def _supports_check(candidate: object) -> TypeGuard[SupportsCheck[object]]:
    return callable(getattr(candidate, "check", None))


def _normalize_skill_key(skill_type: object) -> str:
    if isinstance(skill_type, str):
        return skill_type

    if isinstance(skill_type, Enum):
        if not isinstance(skill_type.value, str):
            raise TypeError(
                "Идентификатор навыка на базе Enum должен содержать строковое value."
            )
        return skill_type.value

    if _has_string_value(skill_type):
        return skill_type.value

    raise TypeError(
        "Идентификатор навыка должен быть строкой, Enum или объектом со строковым полем value."
    )


class Persona:
    def __init__(self, name: str = "Персона") -> None:
        self.name = name
        self.skills: SkillStore = {}
        self.memory: MemoryStore = {}
        self._skill_provider: SkillProvider | None = None
        self.role_id: str = "default"
        self.params: dict[str, object] = {}
        self.secrets: dict[str, object] = {}
        self.retries_config: RetryConfigMap | None = {}

    def __str__(self) -> str:
        return self.name

    @classmethod
    def who_can(cls, *skills: SkillEntry) -> "Persona":
        persona = cls()
        persona.learn(*skills)
        return persona

    def learn(self, *skills_to_learn: SkillEntry) -> "Persona":
        """Наделяет Персону одним или несколькими навыками."""
        for skill_type, name, skill_instance in skills_to_learn:
            skill_key = _normalize_skill_key(skill_type)
            if skill_key not in self.skills:
                self.skills[skill_key] = {}
            self.skills[skill_key][name] = skill_instance
        return self

    def make(self, *goals: SupportsMake) -> "Persona":
        if not goals:
            raise ValueError("Persona.make requires at least one goal.")
        for goal in goals:
            goal.make(self)
        return self

    def set_skill_provider(self, provider: SkillProvider) -> None:
        """Регистрирует фабрику для ленивого создания навыков."""
        self._skill_provider = provider

    def param(self, path: str) -> object:
        """Извлекает параметр роли по dot/bracket-пути."""
        return extract_by_path(self.params, path, allow_attr=False)

    def secret(self, path: str) -> object:
        """Извлекает секрет роли по dot/bracket-пути."""
        return extract_by_path(self.secrets, path, allow_attr=False)

    def ctx(self, path: str) -> object:
        """
        Универсальный метод для извлечения данных из контекста персоны (params, secrets, memory).
        Приоритет: params -> secrets -> memory.
        """
        # Попробуем извлечь из params
        try:
            return extract_by_path(self.params, path, allow_attr=False)
        except (KeyError, IndexError, TypeError):
            pass

        # Попробуем извлечь из secrets
        try:
            return extract_by_path(self.secrets, path, allow_attr=False)
        except (KeyError, IndexError, TypeError):
            pass

        # Если нигде не нашли, извлекаем из memory (с жёсткой ошибкой, если там тоже нет)
        try:
            return extract_by_path(self.memory, path, allow_attr=False)
        except (KeyError, IndexError, TypeError) as e:
            raise KeyError(
                f"Путь '{path}' не найден в контексте персоны (params, secrets, memory)"
            ) from e

    @overload
    def skill(
        self, skill_type: Literal[SkillId.BROWSER, "browser"], name: str = "default"
    ) -> "UseBrowser": ...

    @overload
    def skill(
        self, skill_type: Literal[SkillId.API, "api"], name: str = "default"
    ) -> "UseAPI": ...

    @overload
    def skill(
        self, skill_type: Literal[SkillId.DB, "db"], name: str = "default"
    ) -> "UseDatabase": ...

    @overload
    def skill(
        self, skill_type: Literal[SkillId.KAFKA, "kafka"], name: str = "default"
    ) -> "UseKafka": ...

    @overload
    def skill(
        self, skill_type: Literal[SkillId.SOAP, "soap"], name: str = "default"
    ) -> "UseSOAP": ...

    @overload
    def skill(
        self, skill_type: SkillLookupKey | object, name: str = "default"
    ) -> object: ...

    def skill(
        self, skill_type: SkillLookupKey | object, name: str = "default"
    ) -> object:
        """
        Возвращает экземпляр навыка по его типу и, опционально, имени.
        Если навык не был изучен ранее, пытается создать его с помощью skill_provider (если он есть).

        Args:
            skill_type: Тип навыка (член SkillId).
            name: Имя навыка. Если не указано, используется 'default'.
        """
        skill_type_str = _normalize_skill_key(skill_type)
        skill_name_str = name

        # 1. Проверяем, изучен ли уже навык
        if (
            skill_type_str in self.skills
            and skill_name_str in self.skills[skill_type_str]
        ):
            return self.skills[skill_type_str][skill_name_str]

        # 2. Если нет — пытаемся создать через провайдер
        if self._skill_provider:
            skill_instance = self._skill_provider(self, skill_type, name)
            self.learn((skill_type_str, name, skill_instance))
            return skill_instance

        # 3. Если провайдера нет или он не смог — стандартная ошибка
        if skill_type_str not in self.skills:
            raise NameError(
                f"У Персоны нет навыков типа '{skill_type_str}'. Доступные типы: {list(self.skills.keys())}"
            )

        raise NameError(
            f"У Персоны нет навыка '{skill_name_str}' для типа '{skill_type_str}'. Доступные: {list(self.skills[skill_type_str].keys())}"
        )

    @overload
    def get(
        self, step: SupportsGet[ResultT], *args: object, **kwargs: object
    ) -> ResultT: ...

    @overload
    def get(
        self, step: SupportsExecute[ResultT], *args: object, **kwargs: object
    ) -> ResultT: ...

    def get(self, step: object, *args: object, **kwargs: object) -> object:
        """
        Возвращает значение, вычисленное шагом или операцией.
        """
        if _supports_get(step):
            return step.get(self, *args, **kwargs)
        if _supports_execute(step):
            return step.execute(self, *args, **kwargs)
        raise TypeError(
            f"Object {step} passed to 'get' must have 'get' or 'execute' method."
        )

    def check(self, actual_value: object, *assertions: object) -> None:
        """
        Проверяет фактическое значение на соответствие одному или нескольким ожиданиям.
        """
        if not assertions:
            raise ValueError("Persona.check требует хотя бы один Expectation.")
        for assertion in assertions:
            self.verify(assertion, actual_value)

    def verify(self, assertion: object, actual_value: object) -> None:
        """
        Проверяет утверждение (Expectation).
        Alias для assertion.check(self, actual_value) или execute.
        """
        if _supports_check(assertion):
            assertion.check(self, actual_value)
        elif _supports_execute(assertion):
            assertion.execute(self, actual_value)
        else:
            raise TypeError(
                f"Object {assertion} passed to 'verify' must have 'check' or 'execute' method."
            )
