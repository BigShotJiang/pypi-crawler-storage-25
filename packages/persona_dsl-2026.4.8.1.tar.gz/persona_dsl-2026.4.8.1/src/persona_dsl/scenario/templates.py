from __future__ import annotations

from copy import deepcopy
import json

from persona_dsl.json_types import is_json_array, is_json_object

from .models import ScenarioNodeList, ScenarioTemplate, clone_scenario_nodes

_TEMPLATES_JSON = """
[{"id":"web.smoke-login","name":"Web Smoke Login","description":"Smoke-шаблон: открыть страницу, залогиниться и проверить ключевое условие.","nodes":[{"component":{"name":"OpenLoginPage","type":"Action","path":"tests/actions/open_login_page.py","parameters":[],"description":null},"parameters":{}},{"component":{"name":"DoLogin","type":"Action","path":"tests/actions/do_login.py","parameters":[],"description":null},"parameters":{"username":{"kind":"var","name":"user","path":"name"},"password":{"kind":"var","name":"user","path":"password"}}},{"component":{"name":"CurrentPath","type":"Fact","path":"tests/facts/current_path.py","parameters":[],"description":null},"parameters":{}},{"component":{"name":"PathEqual","type":"Expectation","path":"tests/expectations/path_equal.py","parameters":[],"description":null},"parameters":{"expected":"/dashboard"}}]},{"id":"api.polling-ready","name":"API Polling Until Ready","description":"Опрос API через While + Fact/Expectation, затем финальная проверка.","nodes":[{"condition_fact":{"name":"OrderStatus","type":"Fact","path":"tests/facts/order_status.py","parameters":[],"description":null},"condition_params":{"order_id":{"kind":"var","name":"scenario","path":"order_id"}},"expectation":{"name":"IsEqual","type":"Expectation","path":"tests/expectations/is_equal.py","parameters":[],"description":null},"expectation_params":{"expected":"READY"},"steps":[{"component":{"name":"WaitForSeconds","type":"Action","path":"tests/actions/wait_for_seconds.py","parameters":[],"description":null},"parameters":{"seconds":1}}],"max_iterations":30},{"component":{"name":"OrderPayload","type":"Fact","path":"tests/facts/order_payload.py","parameters":[],"description":null},"parameters":{"order_id":{"kind":"var","name":"scenario","path":"order_id"}}},{"component":{"name":"HasEntries","type":"Expectation","path":"tests/expectations/has_entries.py","parameters":[],"description":null},"parameters":{"entries":{"status":"READY"}}}]},{"id":"ui.foreach-table-check","name":"UI ForEach Table Check","description":"Итерация по данным таблицы и проверка строк с fallback-ретраями.","nodes":[{"items_fact":{"name":"TableRowsData","type":"Fact","path":"tests/facts/table_rows_data.py","parameters":[],"description":null},"items_params":{"table":{"kind":"element","page":"UsersPage","element":"users_table"}},"steps":[{"retries":2,"interval":0.3,"backoff":"linear","jitter":0.1,"steps":[{"component":{"name":"AssertRowStatus","type":"Action","path":"tests/actions/assert_row_status.py","parameters":[],"description":null},"parameters":{"row":{"kind":"var","name":"row","path":""},"expected":"ACTIVE"}}]}]}]}]
""".strip()


def _load_templates() -> list[ScenarioTemplate]:
    raw_templates = json.loads(_TEMPLATES_JSON)
    if not is_json_array(raw_templates):
        raise ValueError("Встроенные шаблоны сценариев должны быть JSON-массивом.")

    templates: list[ScenarioTemplate] = []
    for index, raw_template in enumerate(raw_templates):
        if not is_json_object(raw_template):
            raise ValueError(
                f"Шаблон сценария с индексом {index} должен быть JSON-объектом."
            )
        templates.append(ScenarioTemplate.model_validate(raw_template))
    return templates


_TEMPLATES: list[ScenarioTemplate] = _load_templates()


def list_templates() -> list[ScenarioTemplate]:
    return [
        ScenarioTemplate.model_validate(t.model_dump(mode="python")) for t in _TEMPLATES
    ]


def get_template(template_id: str) -> ScenarioTemplate | None:
    for template in _TEMPLATES:
        if template.id == template_id:
            return ScenarioTemplate.model_validate(template.model_dump(mode="python"))
    return None


def clone_template_nodes(template_id: str) -> ScenarioNodeList:
    template = get_template(template_id)
    if template is None:
        raise ValueError(f"Шаблон сценария '{template_id}' не найден.")
    return clone_scenario_nodes(deepcopy(template.nodes))
