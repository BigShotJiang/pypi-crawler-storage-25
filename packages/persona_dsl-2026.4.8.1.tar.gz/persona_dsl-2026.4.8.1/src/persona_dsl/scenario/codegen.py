from __future__ import annotations

from collections.abc import Iterator, Mapping, Sequence
from dataclasses import dataclass
from itertools import count
from typing import TypeAlias

from persona_dsl.editors.base import CodeEditor
from persona_dsl.utils.path import tokenize_path

from .ir_parser import IR_END, IR_START
from .models import ScenarioNodeLike, dump_scenario_nodes

ScenarioMapping = Mapping[str, object]
RawScenarioNodeList: TypeAlias = list[dict[str, object]]


def _node_get(node: ScenarioMapping, key: str, default: object = None) -> object:
    return node.get(key, default)


def _require_str_field(node: ScenarioMapping, key: str, context: str) -> str:
    value = node.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"{context} должен содержать непустое строковое поле '{key}'.")
    return value


def _require_mapping(value: object, context: str) -> ScenarioMapping:
    if not isinstance(value, dict):
        raise ValueError(f"{context} должен быть объектом сценария.")
    return value


def _mapping_or_empty(value: object, context: str) -> ScenarioMapping:
    if value is None:
        return {}
    return _require_mapping(value, context)


def _require_node_list(value: object, context: str) -> RawScenarioNodeList:
    if not isinstance(value, list):
        raise ValueError(f"{context} должен быть списком узлов сценария.")
    nodes: RawScenarioNodeList = []
    for item in value:
        if not isinstance(item, dict):
            raise ValueError(f"{context} должен содержать только объекты сценария.")
        nodes.append(item)
    return nodes


def _component_name(component: ScenarioMapping) -> str:
    return _require_str_field(component, "name", "Компонент")


def _component_type(component: ScenarioMapping) -> str:
    return _require_str_field(component, "type", "Компонент")


def _component_path(component: ScenarioMapping) -> str:
    return _require_str_field(component, "path", "Компонент")


def _to_module_path(component_path: str) -> str:
    raw_module_path = component_path.removesuffix(".py").replace("/", ".")
    if raw_module_path.startswith("tests.") or raw_module_path.startswith(
        "persona_dsl."
    ):
        return raw_module_path
    return f"persona_dsl.{raw_module_path}"


def _normalize_backoff(backoff: object) -> str:
    if backoff == "linear":
        return "linear"
    if backoff == "exp":
        return "exp"
    raise ValueError(
        "Политика backoff должна быть 'linear' или 'exp' для генерации сценария."
    )


def _repr(value: object) -> str:
    return repr(value)


def _build_varref_expr(var_ref: ScenarioMapping) -> str:
    base = f"persona.memory[{_repr(_require_str_field(var_ref, 'name', 'Ссылка на память'))}]"
    path = var_ref.get("path")
    if not path:
        return base
    if not isinstance(path, str):
        raise ValueError("Поле 'path' в ссылке на память должно быть строкой.")
    expr = base
    for token in tokenize_path(path):
        if isinstance(token, int):
            expr += f"[{token}]"
        else:
            expr += f"[{_repr(token)}]"
    return expr


def _is_step_node(node: ScenarioMapping) -> bool:
    return _node_get(node, "component") is not None and (
        _node_get(node, "parameters") is not None
        or _node_get(node, "params") is not None
    )


def _is_if_node(node: ScenarioMapping) -> bool:
    return (
        _node_get(node, "condition_fact") is not None
        and _node_get(node, "expectation") is not None
        and _node_get(node, "then_steps") is not None
    )


def _is_foreach_node(node: ScenarioMapping) -> bool:
    return _node_get(node, "steps") is not None and (
        _node_get(node, "items_var") is not None
        or _node_get(node, "items_fact") is not None
    )


def _is_while_node(node: ScenarioMapping) -> bool:
    return (
        _node_get(node, "steps") is not None
        and _node_get(node, "condition_fact") is not None
        and _node_get(node, "expectation") is not None
        and _node_get(node, "max_iterations") is not None
    )


def _is_retry_node(node: ScenarioMapping) -> bool:
    return (
        _node_get(node, "steps") is not None and _node_get(node, "retries") is not None
    )


def _meta_filtered_params(parameters: ScenarioMapping) -> dict[str, object]:
    return {
        key: value
        for key, value in (parameters or {}).items()
        if key not in {"__wait__", "__role__"}
    }


@dataclass
class _CodegenCtx:
    imports: set[str]
    lines: list[str]
    used_system_funcs: set[str]
    page_imports: Mapping[str, str]
    name_counter: Iterator[int]

    def next_name(self, prefix: str) -> str:
        return f"_{prefix}_{next(self.name_counter)}"


def _expr_from_value(value: object, ctx: _CodegenCtx) -> str:
    if isinstance(value, dict) and value.get("kind") == "var" and "name" in value:
        return _build_varref_expr(value)

    if isinstance(value, dict) and value.get("kind") == "element":
        page_name = _require_str_field(value, "page", "Ссылка на элемент")
        element_name = _require_str_field(value, "element", "Ссылка на элемент")
        module_path = ctx.page_imports.get(page_name)
        if not module_path:
            raise ValueError(
                f"Unknown page '{page_name}' in ElementRef. "
                "Expected discovered PageObject class."
            )
        ctx.imports.add(f"from {module_path} import {page_name}")
        return f"{page_name}().{element_name}"

    if isinstance(value, dict) and value.get("kind") == "system" and "name" in value:
        func_name = _require_str_field(value, "name", "Системный провайдер")
        args_dict = _require_mapping(
            value.get("args", {}),
            "Аргументы системного провайдера",
        )
        arg_pairs = [
            f"{arg_name}={_expr_from_value(arg_value, ctx)}"
            for arg_name, arg_value in args_dict.items()
        ]
        args_str = ", ".join(arg_pairs)
        ctx.used_system_funcs.add(func_name)
        return f"{func_name}({args_str})" if args_str else f"{func_name}()"

    if value is None or isinstance(value, (str, bool, int, float)):
        return _repr(value)
    if isinstance(value, list):
        return "[" + ", ".join(_expr_from_value(item, ctx) for item in value) + "]"
    if isinstance(value, tuple):
        inner = ", ".join(_expr_from_value(item, ctx) for item in value)
        if len(value) == 1:
            inner += ","
        return f"({inner})"
    if isinstance(value, dict):
        items = ", ".join(
            f"{_expr_from_value(key, ctx)}: {_expr_from_value(item, ctx)}"
            for key, item in value.items()
        )
        return "{" + items + "}"
    raise ValueError(
        f"Неподдерживаемое значение для генерации сценария: {type(value).__name__}."
    )


def _import_component(component: ScenarioMapping, ctx: _CodegenCtx) -> None:
    module_path = _to_module_path(_component_path(component))
    ctx.imports.add(f"from {module_path} import {_component_name(component)}")


def _params_and_role(
    parameters: ScenarioMapping, ctx: _CodegenCtx
) -> tuple[str, str | None]:
    role_expr: str | None = None
    parts: list[str] = []
    for key, value in (parameters or {}).items():
        if key == "__wait__":
            continue
        if key == "__role__":
            role_expr = _expr_from_value(value, ctx)
            continue
        parts.append(f"{key}={_expr_from_value(value, ctx)}")
    return ", ".join(parts), role_expr


def _strict_int(value: object, *, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"Поле '{field_name}' должно быть целым числом.")
    return value


def _strict_number(value: object, *, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"Поле '{field_name}' должно быть числом.")
    return float(value)


def _merge_retry_cfg(policy: ScenarioMapping | None) -> tuple[int, float, str, float]:
    if not isinstance(policy, dict):
        return 0, 0.5, "linear", 0.0
    retries_value = policy.get("retries", 0)
    interval_value = policy.get("interval", 0.5)
    backoff_value = policy.get("backoff", "linear")
    jitter_value = policy.get("jitter", 0.0)

    retries = (
        0 if retries_value is None else _strict_int(retries_value, field_name="retries")
    )
    interval = (
        0.5
        if interval_value is None
        else _strict_number(interval_value, field_name="interval")
    )
    backoff = _normalize_backoff(backoff_value)
    jitter = (
        0.0
        if jitter_value is None
        else _strict_number(jitter_value, field_name="jitter")
    )
    return retries, interval, backoff, jitter


def _retry_policy_expr(
    *,
    retries: int,
    interval: float,
    backoff: str,
    jitter: float,
    ctx: _CodegenCtx,
) -> str:
    ctx.imports.add("from persona_dsl.utils.retry import RetryPolicy")
    return (
        "RetryPolicy("
        f"max_attempts={retries + 1}, "
        f"delay={_repr(interval)}, "
        f"backoff_mode={_repr(backoff)}, "
        "backoff_factor=2.0, "
        f"jitter={_repr(jitter)})"
    )


def _wrap_retryable_expr(
    *,
    expr: str,
    retries: int,
    interval: float,
    backoff: str,
    jitter: float,
    ctx: _CodegenCtx,
) -> str:
    if retries <= 0:
        return expr
    policy_expr = _retry_policy_expr(
        retries=retries,
        interval=interval,
        backoff=backoff,
        jitter=jitter,
        ctx=ctx,
    )
    return f"{expr}.with_retry({policy_expr})"


def _emit_if_block(
    node: ScenarioMapping, indent: str, ctx: _CodegenCtx, *, step_mode: bool
) -> None:
    condition_fact = _require_mapping(
        _node_get(node, "condition_fact"),
        "condition_fact",
    )
    expectation = _require_mapping(
        _node_get(node, "expectation"),
        "expectation",
    )

    _import_component(condition_fact, ctx)
    _import_component(expectation, ctx)

    cond_params, cond_role = _params_and_role(
        _mapping_or_empty(_node_get(node, "condition_params"), "condition_params"),
        ctx,
    )
    exp_params, _ = _params_and_role(
        _mapping_or_empty(
            _node_get(node, "expectation_params"),
            "expectation_params",
        ),
        ctx,
    )

    cond_val_var = ctx.next_name("cond_val")
    cond_result_var = ctx.next_name("cond_result")

    if step_mode:
        ctx.lines.append(
            f"{indent}{cond_val_var} = yield {_component_name(condition_fact)}({cond_params})"
        )
    else:
        role_prefix = f"{cond_role}, " if cond_role else ""
        ctx.lines.append(
            f"{indent}{cond_val_var} = persona.get({role_prefix}{_component_name(condition_fact)}({cond_params}))"
        )
    persona_arg = ", persona=persona" if step_mode else ""
    if step_mode:
        ctx.lines.append(
            f"{indent}{cond_result_var} = {_component_name(expectation)}({exp_params}).check_result({cond_val_var}{persona_arg})"
        )
    else:
        ctx.lines.append(
            f"{indent}{cond_result_var} = {_component_name(expectation)}({exp_params}).check_result({cond_val_var})"
        )
    ctx.lines.append(f"{indent}if {cond_result_var}.succeeded:")
    if step_mode:
        _emit_step_nodes(
            _require_node_list(_node_get(node, "then_steps"), "then_steps"),
            indent + "    ",
            ctx,
        )
    else:
        _emit_test_nodes(
            _require_node_list(_node_get(node, "then_steps"), "then_steps"),
            indent + "    ",
            ctx,
        )
    else_steps = _require_node_list(_node_get(node, "else_steps", []), "else_steps")
    if else_steps:
        ctx.lines.append(f"{indent}else:")
        if step_mode:
            _emit_step_nodes(else_steps, indent + "    ", ctx)
        else:
            _emit_test_nodes(else_steps, indent + "    ", ctx)


def _emit_foreach_block(
    node: ScenarioMapping, indent: str, ctx: _CodegenCtx, *, step_mode: bool
) -> None:
    iterator_expr = "[]"
    items_var = _node_get(node, "items_var")
    items_fact = _node_get(node, "items_fact")
    if items_var is not None:
        iterator_expr = _expr_from_value(items_var, ctx)
    elif items_fact is not None:
        items_fact_mapping = _require_mapping(items_fact, "items_fact")
        _import_component(items_fact_mapping, ctx)
        items_params, items_role = _params_and_role(
            _mapping_or_empty(_node_get(node, "items_params"), "items_params"),
            ctx,
        )
        items_var_name = ctx.next_name("items")
        if step_mode:
            ctx.lines.append(
                f"{indent}{items_var_name} = yield {_component_name(items_fact_mapping)}({items_params})"
            )
        else:
            role_prefix = f"{items_role}, " if items_role else ""
            ctx.lines.append(
                f"{indent}{items_var_name} = persona.get({role_prefix}{_component_name(items_fact_mapping)}({items_params}))"
            )
        iterator_expr = items_var_name
    loop_var = ctx.next_name("item")
    ctx.lines.append(f"{indent}for {loop_var} in {iterator_expr}:")
    if step_mode:
        _emit_step_nodes(
            _require_node_list(_node_get(node, "steps"), "steps"),
            indent + "    ",
            ctx,
        )
    else:
        _emit_test_nodes(
            _require_node_list(_node_get(node, "steps"), "steps"),
            indent + "    ",
            ctx,
        )


def _emit_while_block(
    node: ScenarioMapping, indent: str, ctx: _CodegenCtx, *, step_mode: bool
) -> None:
    condition_fact = _require_mapping(
        _node_get(node, "condition_fact"),
        "condition_fact",
    )
    expectation = _require_mapping(
        _node_get(node, "expectation"),
        "expectation",
    )
    _import_component(condition_fact, ctx)
    _import_component(expectation, ctx)

    cond_params, cond_role = _params_and_role(
        _mapping_or_empty(_node_get(node, "condition_params"), "condition_params"),
        ctx,
    )
    exp_params, _ = _params_and_role(
        _mapping_or_empty(
            _node_get(node, "expectation_params"),
            "expectation_params",
        ),
        ctx,
    )
    max_iterations = _strict_int(
        _node_get(node, "max_iterations"),
        field_name="max_iterations",
    )

    cond_ok_var = ctx.next_name("while_ok")
    cond_val_var = ctx.next_name("while_cond")
    cond_result_var = ctx.next_name("while_result")
    loop_var = ctx.next_name("while_i")

    ctx.lines.append(f"{indent}{cond_ok_var} = False")
    ctx.lines.append(f"{indent}for {loop_var} in range({max_iterations}):")
    if step_mode:
        ctx.lines.append(
            f"{indent}    {cond_val_var} = yield {_component_name(condition_fact)}({cond_params})"
        )
    else:
        role_prefix = f"{cond_role}, " if cond_role else ""
        ctx.lines.append(
            f"{indent}    {cond_val_var} = persona.get({role_prefix}{_component_name(condition_fact)}({cond_params}))"
        )
    persona_arg = ", persona=persona" if step_mode else ""
    if step_mode:
        ctx.lines.append(
            f"{indent}    {cond_result_var} = {_component_name(expectation)}({exp_params}).check_result({cond_val_var}{persona_arg})"
        )
    else:
        ctx.lines.append(
            f"{indent}    {cond_result_var} = {_component_name(expectation)}({exp_params}).check_result({cond_val_var})"
        )
    ctx.lines.append(f"{indent}    if {cond_result_var}.succeeded:")
    ctx.lines.append(f"{indent}        {cond_ok_var} = True")
    ctx.lines.append(f"{indent}        break")
    ctx.lines.append(f"{indent}    else:")
    if step_mode:
        _emit_step_nodes(
            _require_node_list(_node_get(node, "steps"), "steps"),
            indent + "        ",
            ctx,
        )
    else:
        _emit_test_nodes(
            _require_node_list(_node_get(node, "steps"), "steps"),
            indent + "        ",
            ctx,
        )
    ctx.lines.append(f"{indent}if not {cond_ok_var}:")
    ctx.lines.append(
        f"{indent}    raise AssertionError('Условие выхода цикла While не выполнено за max_iterations')"
    )


def _emit_retry_block(
    node: ScenarioMapping, indent: str, ctx: _CodegenCtx, *, step_mode: bool
) -> None:
    retries = _strict_int(_node_get(node, "retries"), field_name="retries")
    interval = _strict_number(_node_get(node, "interval"), field_name="interval")
    backoff = _normalize_backoff(_node_get(node, "backoff", "linear"))
    jitter = _strict_number(_node_get(node, "jitter"), field_name="jitter")
    steps = _require_node_list(_node_get(node, "steps"), "steps")

    if step_mode:
        ctx.imports.add("from persona_dsl.components.combined_step import CombinedStep")
        block_class_name = ctx.next_name("RetryBlock")
        policy_expr = _retry_policy_expr(
            retries=retries,
            interval=interval,
            backoff=backoff,
            jitter=jitter,
            ctx=ctx,
        )
        ctx.lines.append(f"{indent}class {block_class_name}(CombinedStep):")
        ctx.lines.append(
            f"{indent}    def _get_step_description(self, persona) -> str:"
        )
        ctx.lines.append(f"{indent}        return 'Сгенерированный retry-блок'")
        ctx.lines.append("")
        ctx.lines.append(f"{indent}    def _run(self, persona, *args, **kwargs):")
        _emit_step_nodes(steps, indent + "        ", ctx)
        if not steps:
            ctx.lines.append(f"{indent}        yield from ()")
        ctx.lines.append(
            f"{indent}yield {block_class_name}().with_retry({policy_expr})"
        )
        return

    ctx.imports.add("from persona_dsl.utils.retry import retry_call")
    block_name = ctx.next_name("retry_block")
    ctx.lines.append(f"{indent}def {block_name}() -> None:")
    _emit_test_nodes(steps, indent + "    ", ctx)
    if not steps:
        ctx.lines.append(f"{indent}    pass")
    ctx.lines.append(
        f"{indent}retry_call({block_name}, retries={retries}, interval={_repr(interval)}, "
        f"backoff={_repr(backoff)}, jitter={_repr(jitter)})"
    )


def _emit_test_nodes(
    nodes: RawScenarioNodeList,
    indent: str,
    ctx: _CodegenCtx,
) -> None:
    last_fact_variable: str | None = None
    last_fact_expr: str | None = None
    last_fact_role_expr: str | None = None

    for node in nodes or []:
        if _is_if_node(node):
            _emit_if_block(node, indent, ctx, step_mode=False)
            last_fact_variable = None
            last_fact_expr = None
            last_fact_role_expr = None
            continue

        if _is_foreach_node(node):
            _emit_foreach_block(node, indent, ctx, step_mode=False)
            last_fact_variable = None
            last_fact_expr = None
            last_fact_role_expr = None
            continue

        if _is_while_node(node):
            _emit_while_block(node, indent, ctx, step_mode=False)
            last_fact_variable = None
            last_fact_expr = None
            last_fact_role_expr = None
            continue

        if _is_retry_node(node):
            _emit_retry_block(node, indent, ctx, step_mode=False)
            last_fact_variable = None
            last_fact_expr = None
            last_fact_role_expr = None
            continue

        if not _is_step_node(node):
            raise ValueError(
                "Обнаружен неподдерживаемый узел сценария при генерации теста."
            )

        component = _require_mapping(_node_get(node, "component"), "component")
        _import_component(component, ctx)

        parameters = _mapping_or_empty(
            _node_get(node, "parameters", _node_get(node, "params")),
            "parameters",
        )
        params_str, role_expr = _params_and_role(parameters, ctx)

        comp_name = _component_name(component)
        comp_type = _component_type(component)
        policy_raw = _node_get(node, "policy")
        policy = policy_raw if isinstance(policy_raw, Mapping) else None
        retries, interval, backoff, jitter = _merge_retry_cfg(policy)

        if comp_type in {"Goal", "Action"}:
            role_prefix = f"{role_expr}, " if role_expr else ""
            component_expr = _wrap_retryable_expr(
                expr=f"{comp_name}({params_str})",
                retries=retries,
                interval=interval,
                backoff=backoff,
                jitter=jitter,
                ctx=ctx,
            )
            ctx.lines.append(f"{indent}persona.make({role_prefix}{component_expr})")
            last_fact_variable = None
            last_fact_expr = None
            last_fact_role_expr = None
            continue

        if comp_type == "Fact":
            fact_var = ctx.next_name("fact_result")
            fact_obj_var = ctx.next_name("fact_obj")
            constructor_expr = f"{comp_name}({params_str})"

            bindings = _node_get(node, "bindings")
            if isinstance(bindings, dict) and (
                bindings.get("save_as") is not None
                or bindings.get("extract") is not None
            ):
                ctx.lines.append(f"{indent}{fact_obj_var} = {constructor_expr}")
                if bindings.get("save_as") is not None:
                    ctx.lines.append(
                        f"{indent}{fact_obj_var}.save_as = {_repr(bindings.get('save_as'))}"
                    )
                if bindings.get("extract") is not None:
                    ctx.lines.append(
                        f"{indent}{fact_obj_var}.extract = {_repr(bindings.get('extract'))}"
                    )
                fact_call_expr = fact_obj_var
            else:
                fact_call_expr = constructor_expr

            role_prefix = f"{role_expr}, " if role_expr else ""
            retryable_fact_expr = _wrap_retryable_expr(
                expr=fact_call_expr,
                retries=retries,
                interval=interval,
                backoff=backoff,
                jitter=jitter,
                ctx=ctx,
            )
            ctx.lines.append(
                f"{indent}{fact_var} = persona.get({role_prefix}{retryable_fact_expr})"
            )
            last_fact_variable = fact_var
            # Для round-trip парсинга wait_until всегда используем канонический Fact(...)
            # вместо временной переменной fact_obj.
            last_fact_expr = constructor_expr
            last_fact_role_expr = role_expr
            continue

        if comp_type == "Expectation":
            wait_cfg = (
                parameters.get("__wait__") if isinstance(parameters, dict) else None
            )
            merged_wait_cfg: dict[str, object] = {}
            if isinstance(policy, dict):
                merged_wait_cfg.update(policy)
            if isinstance(wait_cfg, dict):
                merged_wait_cfg.update(wait_cfg)
            exp_params = ", ".join(
                f"{k}={_expr_from_value(v, ctx)}"
                for k, v in _meta_filtered_params(parameters).items()
            )
            if (
                isinstance(wait_cfg, dict)
                and wait_cfg.get("enabled")
                and last_fact_expr
            ):
                ctx.imports.add("from persona_dsl import wait_until")
                timeout = merged_wait_cfg.get("timeout", 10.0)
                interval_cfg = merged_wait_cfg.get("interval", 0.5)
                backoff_cfg = merged_wait_cfg.get("backoff", "linear")
                jitter_cfg = merged_wait_cfg.get("jitter", 0.0)
                on_timeout = merged_wait_cfg.get("on_timeout", "fail")
                domain = merged_wait_cfg.get("domain")
                role_prefix = f"{last_fact_role_expr}, " if last_fact_role_expr else ""
                domain_arg = f", domain={_repr(domain)}" if domain is not None else ""
                ctx.lines.append(
                    f"{indent}wait_until(fact=lambda: persona.get({role_prefix}{last_fact_expr}), "
                    f"expectation={comp_name}({exp_params}), "
                    f"timeout={_repr(timeout)}, interval={_repr(interval_cfg)}, "
                    f"backoff={_repr(backoff_cfg)}, jitter={_repr(jitter_cfg)}{domain_arg}, "
                    f"on_timeout={_repr(on_timeout)})"
                )
            elif last_fact_variable:
                expectation_expr = _wrap_retryable_expr(
                    expr=f"{comp_name}({exp_params})",
                    retries=retries,
                    interval=interval,
                    backoff=backoff,
                    jitter=jitter,
                    ctx=ctx,
                )
                ctx.lines.append(
                    f"{indent}persona.check({last_fact_variable}, {expectation_expr})"
                )
            else:
                raise ValueError(
                    f"Для ожидания '{comp_name}' не был получен предыдущий факт."
                )
            continue

        role_prefix = f"{role_expr}, " if role_expr else ""
        component_expr = _wrap_retryable_expr(
            expr=f"{comp_name}({params_str})",
            retries=retries,
            interval=interval,
            backoff=backoff,
            jitter=jitter,
            ctx=ctx,
        )
        ctx.lines.append(f"{indent}persona.make({role_prefix}{component_expr})")


def _emit_step_nodes(
    nodes: RawScenarioNodeList,
    indent: str,
    ctx: _CodegenCtx,
) -> None:
    last_fact_variable: str | None = None
    last_fact_expr: str | None = None

    for node in nodes or []:
        if _is_if_node(node):
            _emit_if_block(node, indent, ctx, step_mode=True)
            last_fact_variable = None
            last_fact_expr = None
            continue

        if _is_foreach_node(node):
            _emit_foreach_block(node, indent, ctx, step_mode=True)
            last_fact_variable = None
            last_fact_expr = None
            continue

        if _is_while_node(node):
            _emit_while_block(node, indent, ctx, step_mode=True)
            last_fact_variable = None
            last_fact_expr = None
            continue

        if _is_retry_node(node):
            _emit_retry_block(node, indent, ctx, step_mode=True)
            last_fact_variable = None
            last_fact_expr = None
            continue

        if not _is_step_node(node):
            raise ValueError(
                "Обнаружен неподдерживаемый узел сценария при генерации шага."
            )

        component = _require_mapping(_node_get(node, "component"), "component")
        _import_component(component, ctx)

        parameters = _mapping_or_empty(
            _node_get(node, "parameters", _node_get(node, "params")),
            "parameters",
        )
        params_str, _ = _params_and_role(parameters, ctx)
        comp_name = _component_name(component)
        comp_type = _component_type(component)
        policy_raw = _node_get(node, "policy")
        policy = policy_raw if isinstance(policy_raw, Mapping) else None
        retries, interval, backoff, jitter = _merge_retry_cfg(policy)

        if comp_type in {"Goal", "Action"}:
            component_expr = _wrap_retryable_expr(
                expr=f"{comp_name}({params_str})",
                retries=retries,
                interval=interval,
                backoff=backoff,
                jitter=jitter,
                ctx=ctx,
            )
            ctx.lines.append(f"{indent}yield {component_expr}")
            last_fact_variable = None
            last_fact_expr = None
            continue

        if comp_type == "Fact":
            fact_var = ctx.next_name("fact")
            fact_obj_var = ctx.next_name("fact_obj")
            constructor_expr = f"{comp_name}({params_str})"
            bindings = _node_get(node, "bindings")
            if isinstance(bindings, dict) and (
                bindings.get("save_as") is not None
                or bindings.get("extract") is not None
            ):
                ctx.lines.append(f"{indent}{fact_obj_var} = {constructor_expr}")
                if bindings.get("save_as") is not None:
                    ctx.lines.append(
                        f"{indent}{fact_obj_var}.save_as = {_repr(bindings.get('save_as'))}"
                    )
                if bindings.get("extract") is not None:
                    ctx.lines.append(
                        f"{indent}{fact_obj_var}.extract = {_repr(bindings.get('extract'))}"
                    )
                wrapped_fact_expr = _wrap_retryable_expr(
                    expr=fact_obj_var,
                    retries=retries,
                    interval=interval,
                    backoff=backoff,
                    jitter=jitter,
                    ctx=ctx,
                )
                ctx.lines.append(f"{indent}{fact_var} = yield {wrapped_fact_expr}")
                last_fact_expr = fact_obj_var
            else:
                wrapped_fact_expr = _wrap_retryable_expr(
                    expr=constructor_expr,
                    retries=retries,
                    interval=interval,
                    backoff=backoff,
                    jitter=jitter,
                    ctx=ctx,
                )
                ctx.lines.append(f"{indent}{fact_var} = yield {wrapped_fact_expr}")
                last_fact_expr = constructor_expr
            last_fact_variable = fact_var
            continue

        if comp_type == "Expectation":
            wait_cfg = (
                parameters.get("__wait__") if isinstance(parameters, dict) else None
            )
            exp_params = ", ".join(
                f"{k}={_expr_from_value(v, ctx)}"
                for k, v in _meta_filtered_params(parameters).items()
            )
            if (
                isinstance(wait_cfg, dict)
                and wait_cfg.get("enabled")
                and last_fact_expr
            ):
                timeout = wait_cfg.get("timeout", 10.0)
                interval_cfg = wait_cfg.get("interval", 0.5)
                backoff_cfg = wait_cfg.get("backoff", "linear")
                jitter_cfg = wait_cfg.get("jitter", 0.0)
                on_timeout = wait_cfg.get("on_timeout", "fail")
                domain = wait_cfg.get("domain")
                domain_arg = f", domain={_repr(domain)}" if domain is not None else ""
                ctx.imports.add("from persona_dsl import wait_until")
                ctx.lines.append(
                    f"{indent}wait_until(fact=lambda: persona.get({last_fact_expr}), "
                    f"expectation={comp_name}({exp_params}), timeout={_repr(timeout)}, "
                    f"interval={_repr(interval_cfg)}, backoff={_repr(backoff_cfg)}, "
                    f"jitter={_repr(jitter_cfg)}{domain_arg}, on_timeout={_repr(on_timeout)})"
                )
            elif last_fact_variable:
                expectation_expr = _wrap_retryable_expr(
                    expr=f"{comp_name}({exp_params})",
                    retries=retries,
                    interval=interval,
                    backoff=backoff,
                    jitter=jitter,
                    ctx=ctx,
                )
                ctx.lines.append(
                    f"{indent}{expectation_expr}.check(persona, {last_fact_variable})"
                )
            else:
                raise ValueError(
                    f"Для ожидания '{comp_name}' не был получен предыдущий факт."
                )
            continue

        component_expr = _wrap_retryable_expr(
            expr=f"{comp_name}({params_str})",
            retries=retries,
            interval=interval,
            backoff=backoff,
            jitter=jitter,
            ctx=ctx,
        )
        ctx.lines.append(f"{indent}yield {component_expr}")


def _render_source(imports: set[str], code_lines: list[str]) -> str:
    source = "\n".join(code_lines)
    if imports:
        editor = CodeEditor(source)
        editor.add_imports(sorted(imports))
        return editor.get_code(use_black=True)
    return CodeEditor(source).get_code(use_black=True)


def generate_test_code(
    *,
    test_name: str,
    steps: Sequence[ScenarioNodeLike],
    data_driven: Mapping[str, object] | None = None,
    page_imports: Mapping[str, str] | None = None,
) -> str:
    imports: set[str] = set()
    lines: list[str] = []
    used_system: set[str] = set()
    ctx = _CodegenCtx(
        imports=imports,
        lines=lines,
        used_system_funcs=used_system,
        page_imports=page_imports or {},
        name_counter=count(1),
    )

    if data_driven is not None:
        imports.add("from persona_dsl import data_driven")
        src_repr = _repr(data_driven.get("source"))
        decorator_args = [src_repr]
        if data_driven.get("is_file"):
            decorator_args.append("file=True")
        if data_driven.get("name_template"):
            decorator_args.append(
                f"name_template={_repr(data_driven.get('name_template'))}"
            )
        if data_driven.get("only"):
            decorator_args.append(f"only={_repr(data_driven.get('only'))}")
        lines.append(f"@data_driven({', '.join(decorator_args)})")

    lines.append(f"def {test_name}(persona):")
    lines.append('    """Тест, сгенерированный из редактора сценариев."""')
    lines.append(f"    {IR_START}")

    serialized_steps = dump_scenario_nodes(steps)
    _emit_test_nodes(serialized_steps, "    ", ctx)
    if not serialized_steps:
        lines.append("    pass")
    lines.append(f"    {IR_END}")

    if used_system:
        imports.add(
            "from persona_dsl.utils.data_providers import "
            + ", ".join(sorted(used_system))
        )

    return _render_source(imports, lines)


def generate_step_code(
    *,
    name: str,
    kind: str,
    nodes: Sequence[ScenarioNodeLike],
    docstring: str | None = None,
    page_imports: Mapping[str, str] | None = None,
) -> str:
    imports: set[str] = set()
    lines: list[str] = []
    used_system: set[str] = set()
    ctx = _CodegenCtx(
        imports=imports,
        lines=lines,
        used_system_funcs=used_system,
        page_imports=page_imports or {},
        name_counter=count(1),
    )

    base_kind = kind if kind in {"Action", "Goal", "Step", "CombinedStep"} else "Step"
    if base_kind == "CombinedStep":
        imports.add("from persona_dsl.components.combined_step import CombinedStep")
    else:
        imports.add(f"from persona_dsl import {base_kind}")

    lines.append(f"class {name}({base_kind}):")
    lines.append(f"    \"\"\"{docstring or 'Step composed from visual editor'}\"\"\"")
    lines.append("")
    lines.append("    def _get_step_description(self, persona) -> str:")
    lines.append(f"        return {_repr(docstring or name)}")
    lines.append("")
    lines.append("    def _run(self, persona, *args, **kwargs):")
    serialized_nodes = dump_scenario_nodes(nodes)
    _emit_step_nodes(serialized_nodes, "        ", ctx)
    if not serialized_nodes:
        lines.append("        yield from ()")

    if used_system:
        imports.add(
            "from persona_dsl.utils.data_providers import "
            + ", ".join(sorted(used_system))
        )

    return _render_source(imports, lines)


def default_step_target_dir(kind: str) -> str:
    if kind in {"Goal", "CombinedStep"}:
        return "tests/goals"
    return "tests/actions"
