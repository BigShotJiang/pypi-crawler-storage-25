from __future__ import annotations

from collections.abc import Mapping
from typing import Literal, Sequence, TypeGuard

from .models import (
    GraphIssue,
    ScenarioNodeLike,
    dump_scenario_node,
    is_scenario_node_instance,
)


def _issue(
    *,
    path: str,
    code: str,
    message: str,
    severity: Literal["error", "warning"] = "warning",
) -> GraphIssue:
    return GraphIssue(path=path, code=code, severity=severity, message=message)


def _is_mapping(value: object) -> TypeGuard[Mapping[str, object]]:
    return isinstance(value, Mapping) and all(isinstance(key, str) for key in value)


def _is_step(node: Mapping[str, object]) -> bool:
    return "component" in node and ("parameters" in node or "params" in node)


def _component_type(node: Mapping[str, object]) -> str:
    component = node.get("component") or {}
    if _is_mapping(component):
        component_type = component.get("type")
        if isinstance(component_type, str) and component_type:
            return component_type
    return "Action"


def _validate_step(node: Mapping[str, object], path: str) -> list[GraphIssue]:
    issues: list[GraphIssue] = []
    component = node.get("component")
    if not isinstance(component, dict):
        issues.append(
            _issue(
                path=path,
                code="step.component.missing",
                message="Step node must include component object",
                severity="error",
            )
        )
        return issues
    if not component.get("name"):
        issues.append(
            _issue(
                path=f"{path}.component.name",
                code="step.component.name.missing",
                message="Component name is required",
                severity="error",
            )
        )
    if not component.get("path"):
        issues.append(
            _issue(
                path=f"{path}.component.path",
                code="step.component.path.missing",
                message="Component path is required",
                severity="error",
            )
        )
    parameters = node.get("parameters")
    if parameters is None:
        parameters = node.get("params")
    if not isinstance(parameters, dict):
        issues.append(
            _issue(
                path=f"{path}.parameters",
                code="step.parameters.invalid",
                message="Step parameters must be an object",
                severity="error",
            )
        )
    policy = node.get("policy")
    if policy is not None and not isinstance(policy, dict):
        issues.append(
            _issue(
                path=f"{path}.policy",
                code="step.policy.invalid",
                message="Policy must be an object",
                severity="error",
            )
        )
    bindings = node.get("bindings")
    if bindings is not None and not isinstance(bindings, dict):
        issues.append(
            _issue(
                path=f"{path}.bindings",
                code="step.bindings.invalid",
                message="Bindings must be an object",
                severity="error",
            )
        )
    return issues


def _validate_foreach(node: Mapping[str, object], path: str) -> list[GraphIssue]:
    issues: list[GraphIssue] = []
    has_items_var = node.get("items_var") is not None
    has_items_fact = node.get("items_fact") is not None
    if has_items_var == has_items_fact:
        issues.append(
            _issue(
                path=path,
                code="foreach.source.invalid",
                message="ForEach must include exactly one source: items_var or items_fact",
                severity="error",
            )
        )
    steps = node.get("steps")
    if not isinstance(steps, list):
        issues.append(
            _issue(
                path=f"{path}.steps",
                code="foreach.steps.invalid",
                message="ForEach steps must be an array",
                severity="error",
            )
        )
    if has_items_fact and not isinstance(node.get("items_params", {}), dict):
        issues.append(
            _issue(
                path=f"{path}.items_params",
                code="foreach.items_params.invalid",
                message="ForEach items_params must be an object",
                severity="error",
            )
        )
    return issues


def _validate_while(node: Mapping[str, object], path: str) -> list[GraphIssue]:
    issues: list[GraphIssue] = []
    for field in ("condition_fact", "expectation"):
        if node.get(field) is None:
            issues.append(
                _issue(
                    path=f"{path}.{field}",
                    code="while.condition.missing",
                    message=f"While must include '{field}'",
                    severity="error",
                )
            )
    max_iterations = node.get("max_iterations")
    if not isinstance(max_iterations, int) or max_iterations <= 0:
        issues.append(
            _issue(
                path=f"{path}.max_iterations",
                code="while.max_iterations.invalid",
                message="max_iterations must be a positive integer",
                severity="error",
            )
        )
    if not isinstance(node.get("steps"), list):
        issues.append(
            _issue(
                path=f"{path}.steps",
                code="while.steps.invalid",
                message="While steps must be an array",
                severity="error",
            )
        )
    return issues


def _validate_retry(node: Mapping[str, object], path: str) -> list[GraphIssue]:
    issues: list[GraphIssue] = []
    retries = node.get("retries")
    if not isinstance(retries, int) or retries < 0:
        issues.append(
            _issue(
                path=f"{path}.retries",
                code="retry.retries.invalid",
                message="Retries must be an integer >= 0",
                severity="error",
            )
        )
    interval = node.get("interval")
    if not isinstance(interval, (float, int)) or float(interval) <= 0:
        issues.append(
            _issue(
                path=f"{path}.interval",
                code="retry.interval.invalid",
                message="Retry interval must be > 0",
                severity="error",
            )
        )
    backoff = node.get("backoff")
    if backoff not in {"linear", "exp"}:
        issues.append(
            _issue(
                path=f"{path}.backoff",
                code="retry.backoff.invalid",
                message="Retry backoff must be 'linear' or 'exp'",
                severity="error",
            )
        )
    jitter = node.get("jitter")
    if not isinstance(jitter, (float, int)) or float(jitter) < 0:
        issues.append(
            _issue(
                path=f"{path}.jitter",
                code="retry.jitter.invalid",
                message="Retry jitter must be >= 0",
                severity="error",
            )
        )
    if not isinstance(node.get("steps"), list):
        issues.append(
            _issue(
                path=f"{path}.steps",
                code="retry.steps.invalid",
                message="Retry steps must be an array",
                severity="error",
            )
        )
    return issues


def _validate_if(node: Mapping[str, object], path: str) -> list[GraphIssue]:
    issues: list[GraphIssue] = []
    for field in ("condition_fact", "expectation"):
        if node.get(field) is None:
            issues.append(
                _issue(
                    path=f"{path}.{field}",
                    code="if.condition.missing",
                    message=f"If block must include '{field}'",
                    severity="error",
                )
            )
    if not isinstance(node.get("then_steps"), list):
        issues.append(
            _issue(
                path=f"{path}.then_steps",
                code="if.then_steps.invalid",
                message="If then_steps must be an array",
                severity="error",
            )
        )
    else_steps = node.get("else_steps")
    if else_steps is not None and not isinstance(else_steps, list):
        issues.append(
            _issue(
                path=f"{path}.else_steps",
                code="if.else_steps.invalid",
                message="If else_steps must be an array",
                severity="error",
            )
        )
    return issues


def _validate_sequence(nodes: Sequence[object], path: str) -> list[GraphIssue]:
    issues: list[GraphIssue] = []
    last_fact_seen = False
    for idx, node in enumerate(nodes):
        current_path = f"{path}[{idx}]"
        raw_node: object = node
        if is_scenario_node_instance(node):
            scenario_node: ScenarioNodeLike = node
            raw_node = dump_scenario_node(scenario_node)
        if not _is_mapping(raw_node):
            issues.append(
                _issue(
                    path=current_path,
                    code="node.invalid_type",
                    message="Scenario node must be an object",
                    severity="error",
                )
            )
            continue

        if _is_step(raw_node):
            issues.extend(_validate_step(raw_node, current_path))
            ctype = _component_type(raw_node)
            if ctype == "Fact":
                last_fact_seen = True
            elif ctype == "Expectation":
                params_value = raw_node.get("parameters")
                params = params_value if _is_mapping(params_value) else None
                wait_cfg = params.get("__wait__") if params is not None else None
                has_wait = isinstance(wait_cfg, dict) and bool(wait_cfg.get("enabled"))
                if not last_fact_seen and not has_wait:
                    issues.append(
                        _issue(
                            path=current_path,
                            code="expectation.without_fact",
                            message="Expectation has no preceding Fact in this scope",
                            severity="warning",
                        )
                    )
                last_fact_seen = False
            else:
                last_fact_seen = False
            continue

        if (
            "condition_fact" in raw_node
            and "expectation" in raw_node
            and "then_steps" in raw_node
        ):
            issues.extend(_validate_if(raw_node, current_path))
            then_steps = raw_node.get("then_steps")
            if isinstance(then_steps, list):
                issues.extend(
                    _validate_sequence(then_steps, f"{current_path}.then_steps")
                )
            else_steps = raw_node.get("else_steps")
            if isinstance(else_steps, list):
                issues.extend(
                    _validate_sequence(
                        else_steps,
                        f"{current_path}.else_steps",
                    )
                )
            last_fact_seen = False
            continue

        if "items_fact" in raw_node or "items_var" in raw_node:
            issues.extend(_validate_foreach(raw_node, current_path))
            steps = raw_node.get("steps")
            if isinstance(steps, list):
                issues.extend(_validate_sequence(steps, f"{current_path}.steps"))
            last_fact_seen = False
            continue

        if (
            "condition_fact" in raw_node
            and "expectation" in raw_node
            and "max_iterations" in raw_node
            and "steps" in raw_node
        ):
            issues.extend(_validate_while(raw_node, current_path))
            steps = raw_node.get("steps")
            if isinstance(steps, list):
                issues.extend(_validate_sequence(steps, f"{current_path}.steps"))
            last_fact_seen = False
            continue

        if "retries" in raw_node and "steps" in raw_node:
            issues.extend(_validate_retry(raw_node, current_path))
            steps = raw_node.get("steps")
            if isinstance(steps, list):
                issues.extend(_validate_sequence(steps, f"{current_path}.steps"))
            last_fact_seen = False
            continue

        issues.append(
            _issue(
                path=current_path,
                code="node.unknown",
                message="Unknown scenario node type",
                severity="warning",
            )
        )
        last_fact_seen = False
    return issues


def validate_graph_nodes(
    nodes: Sequence[ScenarioNodeLike | object],
) -> list[GraphIssue]:
    return _validate_sequence(nodes, "steps")
