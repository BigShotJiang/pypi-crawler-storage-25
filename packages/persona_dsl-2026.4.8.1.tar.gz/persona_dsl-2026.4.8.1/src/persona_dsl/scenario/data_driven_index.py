from __future__ import annotations

import ast
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Sequence, TypeAlias, TypeGuard, TypedDict

_VARIANT_FILE_SUFFIXES = (".yaml", ".yml", ".json")
_VARIANT_FILE_DIR = Path("tests/data/variants")

DataDrivenScalar: TypeAlias = str | int | float | bool | None
DataDrivenValue: TypeAlias = (
    DataDrivenScalar | list["DataDrivenValue"] | dict[str, "DataDrivenValue"]
)
DataDrivenObject: TypeAlias = dict[str, DataDrivenValue]
DataDrivenItems: TypeAlias = list[DataDrivenObject]


class DataDrivenSpec(TypedDict, total=False):
    source: object
    is_file: bool
    name_template: str
    only: list[str]


@dataclass(slots=True)
class VariantSetUsage:
    file_path: str
    node_id: str
    test_name: str
    line: int
    column: int
    end_line: int
    end_column: int
    start_offset: int
    end_offset: int
    source: str
    context: str
    class_name: str | None = None
    name_template: str | None = None
    only: list[str] = field(default_factory=list)
    uses_full_set: bool = False


@dataclass(slots=True)
class VariantSetDefinition:
    set_name: str
    file_path: str
    extension: str
    line: int = 1
    column: int = 0
    end_line: int = 1
    end_column: int = 0
    start_offset: int = 0
    end_offset: int = 0
    context: str = ""


@dataclass(slots=True)
class VariantSetReferenceIndex:
    definitions: list[VariantSetDefinition] = field(default_factory=list)
    usages: list[VariantSetUsage] = field(default_factory=list)


@dataclass(slots=True)
class VariantSetImpact:
    set_name: str
    source_path: str
    summary: str
    usage_count: int = 0
    test_count: int = 0
    uses_full_set: bool = False
    referenced_variant_ids: list[str] = field(default_factory=list)
    missing_variant_ids: list[str] = field(default_factory=list)
    usages: list[VariantSetUsage] = field(default_factory=list)


@dataclass(slots=True)
class DataDrivenNameSample:
    test_id: str
    rendered_name: str


@dataclass(slots=True)
class DataDrivenCasePreview:
    total_count: int = 0
    active_count: int = 0
    filtered: bool = False
    all_ids: list[str] = field(default_factory=list)
    active_ids: list[str] = field(default_factory=list)
    missing_ids: list[str] = field(default_factory=list)
    preview_ids: list[str] = field(default_factory=list)
    hidden_count: int = 0
    name_samples: list[DataDrivenNameSample] = field(default_factory=list)


def extract_data_driven_spec(
    source_code: str,
    test_name: str | None = None,
) -> DataDrivenSpec | None:
    try:
        tree = ast.parse(source_code)
    except SyntaxError:
        return None

    extractor = _DataDrivenSpecExtractor(target_test_name=test_name)
    extractor.visit(tree)
    return extractor.spec


def build_data_driven_case_preview(
    items: Sequence[object],
    *,
    name_template: str | None = None,
    only: Sequence[str] | None = None,
    preview_limit: int = 8,
) -> DataDrivenCasePreview:
    normalized_items = _validate_data_driven_items(items)
    all_ids = [str(item["test_id"]) for item in normalized_items]
    requested_ids = [str(item).strip() for item in (only or []) if str(item).strip()]
    requested_set = set(requested_ids)
    filtered = only is not None and len(requested_ids) > 0
    active_items = (
        [item for item in normalized_items if str(item.get("test_id")) in requested_set]
        if filtered
        else normalized_items
    )
    active_ids = [str(item["test_id"]) for item in active_items]
    preview_items = active_items[:preview_limit]

    return DataDrivenCasePreview(
        total_count=len(normalized_items),
        active_count=len(active_items),
        filtered=filtered,
        all_ids=all_ids,
        active_ids=active_ids,
        missing_ids=(
            [test_id for test_id in requested_ids if test_id not in all_ids]
            if filtered
            else []
        ),
        preview_ids=active_ids[:preview_limit],
        hidden_count=max(len(active_ids) - preview_limit, 0),
        name_samples=[
            DataDrivenNameSample(
                test_id=str(item["test_id"]),
                rendered_name=_render_data_driven_name(item, name_template),
            )
            for item in preview_items
        ],
    )


def build_variant_set_reference_index(
    project_root: str | Path,
    set_name: str | None = None,
) -> VariantSetReferenceIndex:
    root = Path(project_root).resolve()
    normalized_filter = _normalize_variant_source(set_name) if set_name else None
    definitions = [
        definition
        for definition in _collect_variant_definitions(root)
        if normalized_filter is None or definition.set_name == normalized_filter
    ]
    usages: list[VariantSetUsage] = []
    for file_path in _iter_python_files(root):
        usages.extend(_collect_variant_usages(file_path, root, normalized_filter))
    return VariantSetReferenceIndex(definitions=definitions, usages=usages)


def build_variant_set_impact(
    project_root: str | Path,
    set_name: str,
    *,
    available_ids: Sequence[str] | None = None,
) -> VariantSetImpact:
    normalized_set_name = _normalize_variant_source(set_name)
    reference_index = build_variant_set_reference_index(
        project_root,
        set_name=normalized_set_name,
    )
    usages = reference_index.usages

    referenced_variant_ids = sorted(
        {
            variant_id
            for usage in usages
            for variant_id in usage.only
            if str(variant_id).strip()
        }
    )
    available_set = {
        str(item).strip() for item in available_ids or [] if str(item).strip()
    }
    missing_variant_ids = (
        sorted(
            variant_id
            for variant_id in referenced_variant_ids
            if variant_id not in available_set
        )
        if available_set
        else []
    )
    uses_full_set = any(usage.uses_full_set for usage in usages)
    test_count = len({usage.node_id for usage in usages})

    if usages:
        if uses_full_set:
            summary = (
                f"Набор {normalized_set_name} используется в {test_count} тестах "
                f"и хотя бы в одном месте подключён без фильтра only."
            )
        elif referenced_variant_ids:
            summary = (
                f"Набор {normalized_set_name} используется в {test_count} тестах "
                f"с явным фильтром по {len(referenced_variant_ids)} test_id."
            )
        else:
            summary = f"Набор {normalized_set_name} используется в {test_count} тестах."
    else:
        summary = f"Набор {normalized_set_name} пока не используется в тестах проекта."

    return VariantSetImpact(
        set_name=normalized_set_name,
        source_path=f"variants/{normalized_set_name}",
        summary=summary,
        usage_count=len(usages),
        test_count=test_count,
        uses_full_set=uses_full_set,
        referenced_variant_ids=referenced_variant_ids,
        missing_variant_ids=missing_variant_ids,
        usages=usages,
    )


def _iter_python_files(project_root: Path) -> Iterable[Path]:
    tests_root = project_root / "tests"
    search_root = tests_root if tests_root.is_dir() else project_root
    for path in search_root.rglob("*.py"):
        if any(part in {"__pycache__", ".venv", "node_modules"} for part in path.parts):
            continue
        yield path


def _iter_variant_set_files(project_root: Path) -> Iterable[Path]:
    variants_root = project_root / _VARIANT_FILE_DIR
    if not variants_root.is_dir():
        return
    for path in sorted(variants_root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in _VARIANT_FILE_SUFFIXES:
            continue
        yield path


def _collect_variant_definitions(project_root: Path) -> list[VariantSetDefinition]:
    definitions: list[VariantSetDefinition] = []
    for file_path in _iter_variant_set_files(project_root):
        rel_path = file_path.relative_to(project_root).as_posix()
        variants_root = project_root / _VARIANT_FILE_DIR
        rel_to_variants = file_path.relative_to(variants_root).as_posix()
        set_name = _normalize_variant_source(rel_to_variants)
        definitions.append(
            VariantSetDefinition(
                set_name=set_name,
                file_path=rel_path,
                extension=file_path.suffix.lower(),
                end_column=len(set_name),
                end_offset=len(set_name),
                context=f"variants/{set_name}",
            )
        )
    return definitions


def _collect_variant_usages(
    file_path: Path,
    project_root: Path,
    normalized_set_name: str | None,
) -> list[VariantSetUsage]:
    try:
        source = file_path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(file_path))
    except (OSError, SyntaxError):
        return []

    collector = _VariantUsageCollector(
        project_root=project_root,
        file_path=file_path,
        source=source,
        normalized_set_name=normalized_set_name,
    )
    collector.visit(tree)
    return collector.usages


def _normalize_variant_source(source: str | None) -> str:
    normalized = str(source or "").strip().replace("\\", "/")
    if normalized.startswith("./"):
        normalized = normalized[2:]
    if normalized.startswith("tests/data/"):
        normalized = normalized[len("tests/data/") :]
    if normalized.startswith("variants/"):
        normalized = normalized[len("variants/") :]
    for suffix in _VARIANT_FILE_SUFFIXES:
        if normalized.endswith(suffix):
            normalized = normalized[: -len(suffix)]
            break
    return normalized.strip("/")


def _is_json_value(value: object) -> TypeGuard[DataDrivenValue]:
    if value is None or isinstance(value, (str, int, float, bool)):
        return True
    if isinstance(value, list):
        return all(_is_json_value(item) for item in value)
    if isinstance(value, dict):
        return all(
            isinstance(key, str) and _is_json_value(item) for key, item in value.items()
        )
    return False


def _is_json_object(value: object) -> TypeGuard[DataDrivenObject]:
    return isinstance(value, dict) and all(
        isinstance(key, str) and _is_json_value(item) for key, item in value.items()
    )


def _validate_data_driven_items(items: Sequence[object]) -> DataDrivenItems:
    if not isinstance(items, Sequence) or isinstance(items, (str, bytes, bytearray)):
        raise ValueError("Данные для @data_driven должны быть списком словарей.")
    normalized_items: DataDrivenItems = []
    missing_indexes: list[int] = []
    for index, item in enumerate(items):
        if not _is_json_object(item):
            raise ValueError("Данные для @data_driven должны быть списком словарей.")
        test_id = item.get("test_id")
        if not isinstance(test_id, str) or not test_id.strip():
            missing_indexes.append(index)
        normalized_items.append(item)
    if missing_indexes:
        raise ValueError(
            "@data_driven: каждая вариация должна содержать поле 'test_id'. "
            f"Отсутствует в индексах: {missing_indexes}"
        )
    return normalized_items


def _render_data_driven_name(item: DataDrivenObject, name_template: str | None) -> str:
    test_id = str(item.get("test_id") or "")
    if isinstance(name_template, str) and name_template:
        try:
            return name_template.format(**item)
        except (IndexError, KeyError, ValueError) as error:
            raise ValueError(
                "@data_driven: шаблон имени вариации "
                f"'{name_template}' не может быть применён к сценарию "
                f"с test_id='{test_id}': {error}"
            ) from error
    return test_id


def _decorator_name(node: ast.AST) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return None


def _literal_value(node: ast.AST | None) -> object | None:
    if node is None:
        return None
    try:
        value: object = ast.literal_eval(node)
        return value
    except (ValueError, TypeError, SyntaxError):
        return None


def _build_line_offsets(source: str) -> list[int]:
    offsets = [0]
    running = 0
    for line in source.splitlines(keepends=True):
        running += len(line)
        offsets.append(running)
    return offsets


def _offset_for(line_offsets: list[int], line: int, column: int) -> int:
    return line_offsets[line - 1] + column


def _line_col_from_offset(line_offsets: list[int], offset: int) -> tuple[int, int]:
    line = 1
    for index, boundary in enumerate(line_offsets[1:], start=1):
        if offset < boundary:
            line = index
            break
    else:
        line = max(len(line_offsets) - 1, 1)
    return line, offset - line_offsets[line - 1]


def _parse_data_driven_decorator_parts(
    decorator: ast.AST,
) -> tuple[ast.AST | None, object | None, bool, str | None, list[str]] | None:
    if not isinstance(decorator, ast.Call):
        return None
    if _decorator_name(decorator.func) != "data_driven":
        return None

    source_value = None
    source_node: ast.AST | None = None
    is_file = False
    name_template = None
    only_values: list[str] = []

    if decorator.args:
        source_node = decorator.args[0]
        source_value = _literal_value(decorator.args[0])
    if len(decorator.args) > 1:
        is_file = bool(_literal_value(decorator.args[1]))

    for keyword in decorator.keywords:
        if keyword.arg == "source":
            source_node = keyword.value
            source_value = _literal_value(keyword.value)
        elif keyword.arg == "file":
            is_file = bool(_literal_value(keyword.value))
        elif keyword.arg == "name_template":
            literal = _literal_value(keyword.value)
            if isinstance(literal, str):
                name_template = literal
        elif keyword.arg == "only":
            literal = _literal_value(keyword.value)
            if isinstance(literal, (list, tuple, set)):
                only_values = [
                    str(item).strip() for item in literal if str(item).strip()
                ]
            elif isinstance(literal, str) and literal.strip():
                only_values = [literal.strip()]

    return source_node, source_value, is_file, name_template, only_values


class _DataDrivenSpecExtractor(ast.NodeVisitor):
    def __init__(self, *, target_test_name: str | None) -> None:
        self.target_test_name = target_test_name
        self.spec: DataDrivenSpec | None = None

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._collect_for_function(node)
        if self.spec is None:
            self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._collect_for_function(node)
        if self.spec is None:
            self.generic_visit(node)

    def _collect_for_function(
        self, node: ast.FunctionDef | ast.AsyncFunctionDef
    ) -> None:
        if self.spec is not None:
            return
        if self.target_test_name:
            if node.name != self.target_test_name:
                return
        elif not node.name.startswith("test_"):
            return

        for decorator in node.decorator_list:
            parts = _parse_data_driven_decorator_parts(decorator)
            if parts is None:
                continue
            _, source_value, is_file, name_template, only_values = parts
            if source_value is None:
                continue
            spec: DataDrivenSpec = {
                "source": source_value,
                "is_file": is_file,
            }
            if name_template is not None:
                spec["name_template"] = name_template
            if only_values:
                spec["only"] = only_values
            self.spec = spec
            return


class _VariantUsageCollector(ast.NodeVisitor):
    def __init__(
        self,
        *,
        project_root: Path,
        file_path: Path,
        source: str,
        normalized_set_name: str | None,
    ) -> None:
        self.project_root = project_root
        self.file_path = file_path
        self.rel_path = file_path.relative_to(project_root).as_posix()
        self.source = source
        self.line_offsets = _build_line_offsets(source)
        self.normalized_set_name = normalized_set_name
        self.class_stack: list[str] = []
        self.usages: list[VariantSetUsage] = []

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self.class_stack.append(node.name)
        self.generic_visit(node)
        self.class_stack.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._collect_for_function(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._collect_for_function(node)
        self.generic_visit(node)

    def _collect_for_function(
        self, node: ast.FunctionDef | ast.AsyncFunctionDef
    ) -> None:
        if not node.name.startswith("test_"):
            return
        for decorator in node.decorator_list:
            usage = self._parse_data_driven_decorator(node, decorator)
            if usage is not None:
                self.usages.append(usage)

    def _parse_data_driven_decorator(
        self,
        node: ast.FunctionDef | ast.AsyncFunctionDef,
        decorator: ast.AST,
    ) -> VariantSetUsage | None:
        parts = _parse_data_driven_decorator_parts(decorator)
        if parts is None:
            return None
        source_node, source_value, is_file, name_template, only_values = parts

        if not is_file or not isinstance(source_value, str) or source_node is None:
            return None

        normalized_source = _normalize_variant_source(source_value)
        if self.normalized_set_name and normalized_source != self.normalized_set_name:
            return None

        occurrence = self._build_source_occurrence(
            source_node=source_node,
            normalized_source=normalized_source,
        )
        if occurrence is None:
            return None

        class_name = self.class_stack[-1] if self.class_stack else None
        node_id = (
            f"{self.rel_path}::{class_name}::{node.name}"
            if class_name
            else f"{self.rel_path}::{node.name}"
        )
        context = (
            ast.get_source_segment(self.source, decorator)
            or f"@data_driven({source_value!r})"
        )

        return VariantSetUsage(
            file_path=self.rel_path,
            node_id=node_id,
            test_name=node.name,
            class_name=class_name,
            line=occurrence[0],
            column=occurrence[1],
            end_line=occurrence[2],
            end_column=occurrence[3],
            start_offset=occurrence[4],
            end_offset=occurrence[5],
            source=source_value,
            context=context,
            name_template=name_template,
            only=only_values,
            uses_full_set=len(only_values) == 0,
        )

    def _build_source_occurrence(
        self,
        *,
        source_node: ast.AST,
        normalized_source: str,
    ) -> tuple[int, int, int, int, int, int] | None:
        line = getattr(source_node, "lineno", None)
        column = getattr(source_node, "col_offset", None)
        end_line = getattr(source_node, "end_lineno", None)
        end_column = getattr(source_node, "end_col_offset", None)
        if not isinstance(line, int):
            return None
        if not isinstance(column, int):
            return None
        if not isinstance(end_line, int):
            return None
        if not isinstance(end_column, int):
            return None

        start_offset = _offset_for(self.line_offsets, line, column)
        end_offset = _offset_for(self.line_offsets, end_line, end_column)
        raw_text = self.source[start_offset:end_offset]
        needle = normalized_source.replace("\\", "/")
        raw_index = raw_text.find(needle)
        if raw_index < 0:
            return None

        occurrence_start = start_offset + raw_index
        occurrence_end = occurrence_start + len(needle)
        occurrence_line, occurrence_column = _line_col_from_offset(
            self.line_offsets,
            occurrence_start,
        )
        occurrence_end_line, occurrence_end_column = _line_col_from_offset(
            self.line_offsets,
            occurrence_end,
        )
        return (
            occurrence_line,
            occurrence_column,
            occurrence_end_line,
            occurrence_end_column,
            occurrence_start,
            occurrence_end,
        )
