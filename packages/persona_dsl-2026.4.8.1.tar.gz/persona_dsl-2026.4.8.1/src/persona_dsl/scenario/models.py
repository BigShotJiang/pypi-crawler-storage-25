from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Literal, Self, TypeAlias, TypeGuard

from persona_dsl.json_types import (
    JsonObject,
    JsonScalar,
    JsonValue,
    is_json_object,
    is_json_value,
)

BackoffMode: TypeAlias = Literal["linear", "exp"]


def _require_mapping(raw: object, model_name: str) -> Mapping[str, object]:
    if not isinstance(raw, Mapping):
        raise TypeError(f"{model_name} должен быть объектом.")
    return raw


def _require_string_keyed_mapping(
    raw: object,
    model_name: str,
) -> Mapping[str, object]:
    data = _require_mapping(raw, model_name)
    for key in data:
        if not isinstance(key, str):
            raise TypeError(f"{model_name} должен содержать только строковые ключи.")
    return data


def _require_str(data: Mapping[str, object], field_name: str, model_name: str) -> str:
    value = data.get(field_name)
    if not isinstance(value, str) or not value:
        raise TypeError(f"{model_name}.{field_name} должен быть непустой строкой.")
    return value


def _require_optional_str(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
) -> str | None:
    value = data.get(field_name)
    if value is None:
        return None
    if not isinstance(value, str):
        raise TypeError(f"{model_name}.{field_name} должен быть строкой или null.")
    return value


def _require_bool_with_default(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
    default: bool,
) -> bool:
    value = data.get(field_name, default)
    if not isinstance(value, bool):
        raise TypeError(f"{model_name}.{field_name} должен быть булевым значением.")
    return value


def _require_optional_int(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
) -> int | None:
    value = data.get(field_name)
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{model_name}.{field_name} должен быть целым числом или null.")
    return value


def _require_int(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
) -> int:
    value = data.get(field_name)
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{model_name}.{field_name} должен быть целым числом.")
    return value


def _require_non_negative_float(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
) -> float:
    value = data.get(field_name)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{model_name}.{field_name} должен быть числом.")
    return float(value)


def _require_backoff(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
    *,
    default: BackoffMode = "linear",
) -> BackoffMode:
    value = data.get(field_name, default)
    if value == "linear":
        return "linear"
    if value == "exp":
        return "exp"
    raise TypeError(f"{model_name}.{field_name} должен быть 'linear' или 'exp'.")


def _require_json_value(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
) -> JsonValue:
    value = data.get(field_name)
    if not is_json_value(value):
        raise TypeError(f"{model_name}.{field_name} должен быть JSON-значением.")
    return value


def _require_optional_json_object(
    data: Mapping[str, object],
    field_name: str,
    model_name: str,
) -> JsonObject | None:
    value = data.get(field_name)
    if value is None:
        return None
    if not is_json_object(value):
        raise TypeError(
            f"{model_name}.{field_name} должен быть JSON-объектом или null."
        )
    return value


def _require_python_mode(mode: str) -> None:
    if mode != "python":
        raise ValueError("Поддерживается только режим сериализации 'python'.")


@dataclass(slots=True)
class VarRef:
    name: str
    path: str = ""

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        kind = data.get("kind")
        if kind != "var":
            raise TypeError("VarRef.kind должен быть 'var'.")
        return cls(
            name=_require_str(data, "name", cls.__name__),
            path=_require_optional_str(data, "path", cls.__name__) or "",
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {"kind": "var", "name": self.name, "path": self.path}


@dataclass(slots=True)
class ElementRef:
    page: str
    element: str

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        kind = data.get("kind")
        if kind != "element":
            raise TypeError("ElementRef.kind должен быть 'element'.")
        return cls(
            page=_require_str(data, "page", cls.__name__),
            element=_require_str(data, "element", cls.__name__),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {"kind": "element", "page": self.page, "element": self.element}


@dataclass(slots=True)
class SystemRef:
    name: str
    args: ScenarioParameters = field(default_factory=dict)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        kind = data.get("kind")
        if kind != "system":
            raise TypeError("SystemRef.kind должен быть 'system'.")
        return cls(
            name=_require_str(data, "name", cls.__name__),
            args=_require_parameters(
                data.get("args", {}),
                f"{cls.__name__}.args",
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "kind": "system",
            "name": self.name,
            "args": dump_scenario_parameters(self.args),
        }


ScenarioParameterValue: TypeAlias = (
    JsonScalar
    | VarRef
    | ElementRef
    | list["ScenarioParameterValue"]
    | tuple["ScenarioParameterValue", ...]
    | dict[str, "ScenarioParameterValue"]
    | SystemRef
)
ScenarioParameters: TypeAlias = dict[str, ScenarioParameterValue]
ScenarioObject: TypeAlias = ScenarioParameters


def parse_scenario_parameter_value(
    raw: object,
    *,
    context: str,
) -> ScenarioParameterValue:
    if raw is None or isinstance(raw, (str, int, float, bool)):
        return raw

    if isinstance(raw, list):
        return [
            parse_scenario_parameter_value(item, context=f"{context}[{index}]")
            for index, item in enumerate(raw)
        ]

    if isinstance(raw, tuple):
        return tuple(
            parse_scenario_parameter_value(item, context=f"{context}[{index}]")
            for index, item in enumerate(raw)
        )

    data = _require_string_keyed_mapping(raw, context)
    kind = data.get("kind")
    if kind == "var":
        return VarRef.model_validate(data)
    if kind == "element":
        return ElementRef.model_validate(data)
    if kind == "system":
        return SystemRef.model_validate(data)

    parsed: ScenarioParameters = {}
    for key, value in data.items():
        parsed[key] = parse_scenario_parameter_value(
            value,
            context=f"{context}.{key}",
        )
    return parsed


def dump_scenario_parameter_value(
    value: ScenarioParameterValue,
) -> object:
    if isinstance(value, VarRef | ElementRef | SystemRef):
        return value.model_dump()
    if isinstance(value, list):
        return [dump_scenario_parameter_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple(dump_scenario_parameter_value(item) for item in value)
    if isinstance(value, dict):
        return {key: dump_scenario_parameter_value(item) for key, item in value.items()}
    return value


def _require_parameters(raw: object, context: str) -> ScenarioParameters:
    data = _require_string_keyed_mapping(raw, context)
    parsed: ScenarioParameters = {}
    for key, value in data.items():
        parsed[key] = parse_scenario_parameter_value(
            value,
            context=f"{context}.{key}",
        )
    return parsed


def dump_scenario_parameters(parameters: ScenarioParameters) -> dict[str, object]:
    return {
        key: dump_scenario_parameter_value(value) for key, value in parameters.items()
    }


@dataclass(slots=True)
class ComponentParameter:
    name: str
    type: str = "object"
    required: bool = True
    default: JsonValue = None
    json_schema: JsonObject | None = None

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        value_type = data.get("type", "object")
        if not isinstance(value_type, str):
            raise TypeError("ComponentParameter.type должен быть строкой.")
        return cls(
            name=_require_str(data, "name", cls.__name__),
            type=value_type,
            required=_require_bool_with_default(data, "required", cls.__name__, True),
            default=_require_json_value(data, "default", cls.__name__),
            json_schema=_require_optional_json_object(
                data, "json_schema", cls.__name__
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "name": self.name,
            "type": self.type,
            "required": self.required,
            "default": self.default,
            "json_schema": self.json_schema,
        }


@dataclass(slots=True)
class TestComponent:
    name: str
    type: str
    path: str
    parameters: list[ComponentParameter] = field(default_factory=list)
    description: str | None = None

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        raw_parameters = data.get("parameters", [])
        if not isinstance(raw_parameters, list):
            raise TypeError(f"{cls.__name__}.parameters должен быть списком.")
        return cls(
            name=_require_str(data, "name", cls.__name__),
            type=_require_str(data, "type", cls.__name__),
            path=_require_str(data, "path", cls.__name__),
            parameters=[
                ComponentParameter.model_validate(item) for item in raw_parameters
            ],
            description=_require_optional_str(data, "description", cls.__name__),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "name": self.name,
            "type": self.type,
            "path": self.path,
            "parameters": [
                parameter.model_dump(mode=mode) for parameter in self.parameters
            ],
            "description": self.description,
        }


@dataclass(slots=True)
class RetryPolicy:
    retries: int = 0
    interval: float = 0.5
    backoff: BackoffMode = "linear"
    jitter: float = 0.0

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        retries_raw = data.get("retries", 0)
        if isinstance(retries_raw, bool) or not isinstance(retries_raw, int):
            raise TypeError(f"{cls.__name__}.retries должен быть целым числом.")
        interval_raw = data.get("interval", 0.5)
        if isinstance(interval_raw, bool) or not isinstance(interval_raw, (int, float)):
            raise TypeError(f"{cls.__name__}.interval должен быть числом.")
        jitter_raw = data.get("jitter", 0.0)
        if isinstance(jitter_raw, bool) or not isinstance(jitter_raw, (int, float)):
            raise TypeError(f"{cls.__name__}.jitter должен быть числом.")
        return cls(
            retries=retries_raw,
            interval=float(interval_raw),
            backoff=_require_backoff(data, "backoff", cls.__name__),
            jitter=float(jitter_raw),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "retries": self.retries,
            "interval": self.interval,
            "backoff": self.backoff,
            "jitter": self.jitter,
        }


@dataclass(slots=True)
class StepBindings:
    save_as: str | None = None
    extract: str | None = None

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        return cls(
            save_as=_require_optional_str(data, "save_as", cls.__name__),
            extract=_require_optional_str(data, "extract", cls.__name__),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        dumped: dict[str, object] = {}
        if self.save_as is not None:
            dumped["save_as"] = self.save_as
        if self.extract is not None:
            dumped["extract"] = self.extract
        return dumped


@dataclass(slots=True)
class StepNode:
    component: TestComponent
    parameters: ScenarioParameters = field(default_factory=dict)
    policy: RetryPolicy | None = None
    bindings: StepBindings | None = None

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        raw_parameters = data.get("parameters", data.get("params", {}))
        return cls(
            component=TestComponent.model_validate(data.get("component")),
            parameters=_require_parameters(
                raw_parameters, f"{cls.__name__}.parameters"
            ),
            policy=(
                None
                if data.get("policy") is None
                else RetryPolicy.model_validate(data.get("policy"))
            ),
            bindings=(
                None
                if data.get("bindings") is None
                else StepBindings.model_validate(data.get("bindings"))
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        dumped: dict[str, object] = {
            "component": self.component.model_dump(mode=mode),
            "parameters": dump_scenario_parameters(self.parameters),
        }
        if self.policy is not None:
            dumped["policy"] = self.policy.model_dump(mode=mode)
        if self.bindings is not None:
            dumped["bindings"] = self.bindings.model_dump(mode=mode)
        return dumped


@dataclass(slots=True)
class IfNode:
    condition_fact: TestComponent
    condition_params: ScenarioParameters
    expectation: TestComponent
    expectation_params: ScenarioParameters
    then_steps: list["ScenarioNode"] = field(default_factory=list)
    else_steps: list["ScenarioNode"] = field(default_factory=list)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        return cls(
            condition_fact=TestComponent.model_validate(data.get("condition_fact")),
            condition_params=_require_parameters(
                data.get("condition_params", {}),
                f"{cls.__name__}.condition_params",
            ),
            expectation=TestComponent.model_validate(data.get("expectation")),
            expectation_params=_require_parameters(
                data.get("expectation_params", {}),
                f"{cls.__name__}.expectation_params",
            ),
            then_steps=_require_node_list(
                data.get("then_steps", []), f"{cls.__name__}.then_steps"
            ),
            else_steps=_require_node_list(
                data.get("else_steps", []), f"{cls.__name__}.else_steps"
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "condition_fact": self.condition_fact.model_dump(mode=mode),
            "condition_params": dump_scenario_parameters(self.condition_params),
            "expectation": self.expectation.model_dump(mode=mode),
            "expectation_params": dump_scenario_parameters(self.expectation_params),
            "then_steps": dump_scenario_nodes(self.then_steps),
            "else_steps": dump_scenario_nodes(self.else_steps),
        }


@dataclass(slots=True)
class WhileNode:
    condition_fact: TestComponent
    condition_params: ScenarioParameters
    expectation: TestComponent
    expectation_params: ScenarioParameters
    steps: list["ScenarioNode"] = field(default_factory=list)
    max_iterations: int = 1

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        return cls(
            condition_fact=TestComponent.model_validate(data.get("condition_fact")),
            condition_params=_require_parameters(
                data.get("condition_params", {}),
                f"{cls.__name__}.condition_params",
            ),
            expectation=TestComponent.model_validate(data.get("expectation")),
            expectation_params=_require_parameters(
                data.get("expectation_params", {}),
                f"{cls.__name__}.expectation_params",
            ),
            steps=_require_node_list(data.get("steps", []), f"{cls.__name__}.steps"),
            max_iterations=_require_int(data, "max_iterations", cls.__name__),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "condition_fact": self.condition_fact.model_dump(mode=mode),
            "condition_params": dump_scenario_parameters(self.condition_params),
            "expectation": self.expectation.model_dump(mode=mode),
            "expectation_params": dump_scenario_parameters(self.expectation_params),
            "steps": dump_scenario_nodes(self.steps),
            "max_iterations": self.max_iterations,
        }


@dataclass(slots=True)
class RetryNode:
    policy: RetryPolicy
    steps: list["ScenarioNode"] = field(default_factory=list)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        return cls(
            policy=RetryPolicy.model_validate(data),
            steps=_require_node_list(data.get("steps", []), f"{cls.__name__}.steps"),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        dumped = self.policy.model_dump(mode=mode)
        dumped["steps"] = dump_scenario_nodes(self.steps)
        return dumped


@dataclass(slots=True)
class ForEachFactNode:
    items_fact: TestComponent
    items_params: ScenarioParameters
    steps: list["ScenarioNode"] = field(default_factory=list)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        return cls(
            items_fact=TestComponent.model_validate(data.get("items_fact")),
            items_params=_require_parameters(
                data.get("items_params", {}),
                f"{cls.__name__}.items_params",
            ),
            steps=_require_node_list(data.get("steps", []), f"{cls.__name__}.steps"),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "items_fact": self.items_fact.model_dump(mode=mode),
            "items_params": dump_scenario_parameters(self.items_params),
            "steps": dump_scenario_nodes(self.steps),
        }


@dataclass(slots=True)
class ForEachVarNode:
    items_var: VarRef
    steps: list["ScenarioNode"] = field(default_factory=list)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        return cls(
            items_var=VarRef.model_validate(data.get("items_var")),
            steps=_require_node_list(data.get("steps", []), f"{cls.__name__}.steps"),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "items_var": self.items_var.model_dump(mode=mode),
            "steps": dump_scenario_nodes(self.steps),
        }


ScenarioNode: TypeAlias = (
    StepNode | IfNode | WhileNode | RetryNode | ForEachFactNode | ForEachVarNode
)
ScenarioNodeLike: TypeAlias = ScenarioNode | Mapping[str, object]
ScenarioNodeList: TypeAlias = list[ScenarioNode]
ScenarioModelNodeList: TypeAlias = ScenarioNodeList


def is_scenario_node_instance(value: object) -> TypeGuard[ScenarioNode]:
    return isinstance(
        value,
        StepNode | IfNode | WhileNode | RetryNode | ForEachFactNode | ForEachVarNode,
    )


def parse_scenario_node(raw: object) -> ScenarioNode:
    if isinstance(
        raw,
        StepNode | IfNode | WhileNode | RetryNode | ForEachFactNode | ForEachVarNode,
    ):
        return raw

    data = _require_string_keyed_mapping(raw, "ScenarioNode")

    if "component" in data and ("parameters" in data or "params" in data):
        return StepNode.model_validate(data)
    if "condition_fact" in data and "expectation" in data and "then_steps" in data:
        return IfNode.model_validate(data)
    if (
        "condition_fact" in data
        and "expectation" in data
        and "steps" in data
        and "max_iterations" in data
    ):
        return WhileNode.model_validate(data)
    if "retries" in data and "interval" in data and "steps" in data:
        return RetryNode.model_validate(data)
    if "items_fact" in data and "steps" in data:
        return ForEachFactNode.model_validate(data)
    if "items_var" in data and "steps" in data:
        return ForEachVarNode.model_validate(data)

    raise TypeError("Не удалось определить тип узла сценария.")


def dump_scenario_node(node: ScenarioNodeLike) -> dict[str, object]:
    parsed = parse_scenario_node(node)
    return parsed.model_dump(mode="python")


def _require_node_list(raw: object, context: str) -> ScenarioNodeList:
    if not isinstance(raw, list):
        raise TypeError(f"{context} должен быть списком узлов сценария.")
    return [parse_scenario_node(item) for item in raw]


def coerce_scenario_nodes(nodes: Sequence[ScenarioNodeLike]) -> ScenarioNodeList:
    return [parse_scenario_node(node) for node in nodes]


def dump_scenario_nodes(nodes: Sequence[ScenarioNodeLike]) -> list[dict[str, object]]:
    return [dump_scenario_node(node) for node in nodes]


def clone_scenario_nodes(nodes: Sequence[ScenarioNodeLike]) -> ScenarioNodeList:
    return [parse_scenario_node(dump_scenario_node(node)) for node in nodes]


@dataclass(slots=True)
class ParseDiagnostic:
    message: str
    lineno: int | None = None
    col: int | None = None
    context: str | None = None

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        return cls(
            message=_require_str(data, "message", cls.__name__),
            lineno=_require_optional_int(data, "lineno", cls.__name__),
            col=_require_optional_int(data, "col", cls.__name__),
            context=_require_optional_str(data, "context", cls.__name__),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "message": self.message,
            "lineno": self.lineno,
            "col": self.col,
            "context": self.context,
        }


@dataclass(slots=True)
class ParseCodeResponse:
    steps: ScenarioNodeList = field(default_factory=list)
    test_name: str | None = None
    diagnostics: list[ParseDiagnostic] = field(default_factory=list)
    data_driven: JsonObject | None = None

    def __post_init__(self) -> None:
        self.steps = coerce_scenario_nodes(self.steps)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        raw_diagnostics = data.get("diagnostics", [])
        if not isinstance(raw_diagnostics, list):
            raise TypeError(f"{cls.__name__}.diagnostics должен быть списком.")
        return cls(
            steps=_require_node_list(data.get("steps", []), f"{cls.__name__}.steps"),
            test_name=_require_optional_str(data, "test_name", cls.__name__),
            diagnostics=[
                ParseDiagnostic.model_validate(item) for item in raw_diagnostics
            ],
            data_driven=_require_optional_json_object(
                data, "data_driven", cls.__name__
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "steps": dump_scenario_nodes(self.steps),
            "test_name": self.test_name,
            "diagnostics": [
                diagnostic.model_dump(mode=mode) for diagnostic in self.diagnostics
            ],
            "data_driven": self.data_driven,
        }


@dataclass(slots=True)
class GraphIssue:
    path: str
    code: str
    severity: Literal["error", "warning"] = "warning"
    message: str = ""

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        severity = data.get("severity", "warning")
        if severity == "error":
            validated_severity: Literal["error", "warning"] = "error"
        elif severity == "warning":
            validated_severity = "warning"
        else:
            raise TypeError("GraphIssue.severity должен быть 'error' или 'warning'.")
        return cls(
            path=_require_str(data, "path", cls.__name__),
            code=_require_str(data, "code", cls.__name__),
            severity=validated_severity,
            message=_require_str(data, "message", cls.__name__),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "path": self.path,
            "code": self.code,
            "severity": self.severity,
            "message": self.message,
        }


@dataclass(slots=True)
class GraphDiffChange:
    op: Literal["add", "remove", "replace"]
    path: str
    before: object = None
    after: object = None
    message: str | None = None

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        op = data.get("op")
        if op == "add":
            validated_op: Literal["add", "remove", "replace"] = "add"
        elif op == "remove":
            validated_op = "remove"
        elif op == "replace":
            validated_op = "replace"
        else:
            raise TypeError("GraphDiffChange.op должен быть add, remove или replace.")
        return cls(
            op=validated_op,
            path=_require_str(data, "path", cls.__name__),
            before=data.get("before"),
            after=data.get("after"),
            message=_require_optional_str(data, "message", cls.__name__),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "op": self.op,
            "path": self.path,
            "before": self.before,
            "after": self.after,
            "message": self.message,
        }


@dataclass(slots=True)
class GraphDiffResult:
    changes: list[GraphDiffChange] = field(default_factory=list)
    summary: str = ""

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        raw_changes = data.get("changes", [])
        if not isinstance(raw_changes, list):
            raise TypeError(f"{cls.__name__}.changes должен быть списком.")
        return cls(
            changes=[GraphDiffChange.model_validate(item) for item in raw_changes],
            summary=_require_str(data, "summary", cls.__name__),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "changes": [change.model_dump(mode=mode) for change in self.changes],
            "summary": self.summary,
        }


@dataclass(slots=True)
class ScenarioTemplate:
    id: str
    name: str
    description: str
    nodes: ScenarioNodeList = field(default_factory=list)
    data_driven: JsonObject | None = None

    def __post_init__(self) -> None:
        self.nodes = coerce_scenario_nodes(self.nodes)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        return cls(
            id=_require_str(data, "id", cls.__name__),
            name=_require_str(data, "name", cls.__name__),
            description=_require_str(data, "description", cls.__name__),
            nodes=_require_node_list(data.get("nodes", []), f"{cls.__name__}.nodes"),
            data_driven=_require_optional_json_object(
                data, "data_driven", cls.__name__
            ),
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "nodes": dump_scenario_nodes(self.nodes),
            "data_driven": self.data_driven,
        }


@dataclass(slots=True)
class ScenarioRoundtripResult:
    generated_code: str
    parsed_steps: ScenarioNodeList = field(default_factory=list)
    diff: GraphDiffResult = field(default_factory=GraphDiffResult)
    issues: list[GraphIssue] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.parsed_steps = coerce_scenario_nodes(self.parsed_steps)

    @classmethod
    def model_validate(cls, raw: object) -> Self:
        if isinstance(raw, cls):
            return raw
        data = _require_string_keyed_mapping(raw, cls.__name__)
        raw_issues = data.get("issues", [])
        if not isinstance(raw_issues, list):
            raise TypeError(f"{cls.__name__}.issues должен быть списком.")
        return cls(
            generated_code=_require_str(data, "generated_code", cls.__name__),
            parsed_steps=_require_node_list(
                data.get("parsed_steps", []),
                f"{cls.__name__}.parsed_steps",
            ),
            diff=GraphDiffResult.model_validate(data.get("diff")),
            issues=[GraphIssue.model_validate(item) for item in raw_issues],
        )

    def model_dump(self, *, mode: str = "python") -> dict[str, object]:
        _require_python_mode(mode)
        return {
            "generated_code": self.generated_code,
            "parsed_steps": dump_scenario_nodes(self.parsed_steps),
            "diff": self.diff.model_dump(mode=mode),
            "issues": [issue.model_dump(mode=mode) for issue in self.issues],
        }
