from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import TypeGuard

from .models import (
    GraphDiffChange,
    GraphDiffResult,
    ScenarioNodeLike,
    dump_scenario_node,
    is_scenario_node_instance,
)


def _is_mapping(value: object) -> TypeGuard[Mapping[str, object]]:
    return isinstance(value, Mapping) and all(isinstance(key, str) for key in value)


def _node_title(node: object) -> str:
    if _is_mapping(node):
        component = node.get("component")
        if _is_mapping(component):
            name = component.get("name")
            if isinstance(name, str) and name:
                return name
        if "condition_fact" in node and "expectation" in node:
            return "if/while block"
        if "items_fact" in node or "items_var" in node:
            return "foreach block"
        if "retries" in node and "steps" in node:
            return "retry block"
    return "node"


def _summarize_change(change: GraphDiffChange) -> str:
    if change.op == "add":
        return f"Added {_node_title(change.after)} at {change.path}"
    if change.op == "remove":
        return f"Removed {_node_title(change.before)} at {change.path}"
    return f"Updated {change.path}"


def _diff(path: str, before: object, after: object, out: list[GraphDiffChange]) -> None:
    if type(before) is not type(after):
        out.append(GraphDiffChange(op="replace", path=path, before=before, after=after))
        return

    if _is_mapping(before):
        if not _is_mapping(after):
            out.append(
                GraphDiffChange(op="replace", path=path, before=before, after=after)
            )
            return
        keys = sorted(set(before.keys()) | set(after.keys()))
        for key in keys:
            next_path = f"{path}.{key}" if path else str(key)
            if key not in before:
                out.append(
                    GraphDiffChange(
                        op="add", path=next_path, before=None, after=after[key]
                    )
                )
                continue
            if key not in after:
                out.append(
                    GraphDiffChange(
                        op="remove", path=next_path, before=before[key], after=None
                    )
                )
                continue
            _diff(next_path, before[key], after[key], out)
        return

    if isinstance(before, list):
        if not isinstance(after, list):
            out.append(
                GraphDiffChange(op="replace", path=path, before=before, after=after)
            )
            return
        common = min(len(before), len(after))
        for idx in range(common):
            _diff(f"{path}[{idx}]", before[idx], after[idx], out)
        for idx in range(common, len(before)):
            out.append(
                GraphDiffChange(
                    op="remove", path=f"{path}[{idx}]", before=before[idx], after=None
                )
            )
        for idx in range(common, len(after)):
            out.append(
                GraphDiffChange(
                    op="add", path=f"{path}[{idx}]", before=None, after=after[idx]
                )
            )
        return

    if before != after:
        out.append(GraphDiffChange(op="replace", path=path, before=before, after=after))


def diff_graph_nodes(
    before_nodes: Sequence[ScenarioNodeLike], after_nodes: Sequence[ScenarioNodeLike]
) -> GraphDiffResult:
    before_raw = [_serialize_node(node) for node in before_nodes]
    after_raw = [_serialize_node(node) for node in after_nodes]
    changes: list[GraphDiffChange] = []
    _diff("steps", before_raw, after_raw, changes)
    for change in changes:
        change.message = _summarize_change(change)
    if not changes:
        summary = "No changes"
    else:
        adds = sum(1 for c in changes if c.op == "add")
        removes = sum(1 for c in changes if c.op == "remove")
        updates = sum(1 for c in changes if c.op == "replace")
        summary = f"{adds} added, {removes} removed, {updates} updated"
    return GraphDiffResult(changes=changes, summary=summary)


def _serialize_node(node: object) -> object:
    if is_scenario_node_instance(node):
        scenario_node: ScenarioNodeLike = node
        return dump_scenario_node(scenario_node)
    if _is_mapping(node):
        try:
            return dump_scenario_node(node)
        except TypeError:
            return dict(node)
    return node
