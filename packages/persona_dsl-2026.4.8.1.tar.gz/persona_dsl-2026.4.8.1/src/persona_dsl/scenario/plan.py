from __future__ import annotations

from collections.abc import Mapping
import json
import time
from typing import Iterable, Sequence, TypeAlias, TypeGuard

from .models import ScenarioNodeLike, dump_scenario_node, is_scenario_node_instance

StructureNode: TypeAlias = dict[str, object]


def _node_id(path: Iterable[object]) -> str:
    return "plan:" + ".".join(str(p) for p in path)


def _is_mapping(value: object) -> TypeGuard[Mapping[str, object]]:
    return isinstance(value, Mapping) and all(isinstance(key, str) for key in value)


def _mapping_or_empty(value: object) -> Mapping[str, object]:
    if _is_mapping(value):
        return value
    return {}


def _is_node_list(value: object) -> TypeGuard[list[Mapping[str, object]]]:
    return isinstance(value, list) and all(_is_mapping(item) for item in value)


def _format_value(value: object) -> str:
    if isinstance(value, bool):
        return "Да" if value else "Нет"
    if value is None:
        return "—"
    if isinstance(value, (str, int, float)):
        return str(value)
    if isinstance(value, list):
        return ", ".join(_format_value(item) for item in value)
    if _is_mapping(value):
        kind = value.get("kind")
        page = value.get("page")
        element = value.get("element")
        name = value.get("name")
        if kind in {"element", "page-element"} and page and element:
            return f"{page}.{element}"
        if kind in {"memory", "var", "var_ref"} and name:
            prefix = "memory" if kind == "memory" else "var"
            return f"{prefix}.{name}"
        if kind in {"system", "system_var"} and name:
            return f"system:{name}"
        if page and element:
            return f"{page}.{element}"
        if page:
            return str(page)
        if name and len(value) <= 2:
            return str(name)
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    return str(value)


def _first_value(params: Mapping[str, object], keys: tuple[str, ...]) -> str | None:
    for key in keys:
        if key in params:
            return _format_value(params[key])
    return None


def _primary_target(params: Mapping[str, object]) -> str | None:
    if "target" in params:
        return _format_value(params["target"])
    if "element" in params and "page" in params:
        return f"{_format_value(params['page'])}.{_format_value(params['element'])}"
    for key in ("element", "locator", "selector", "field", "page", "url"):
        if key in params:
            return _format_value(params[key])
    return None


def _component_name(node: Mapping[str, object], key: str = "component") -> str:
    component = node.get(key) or {}
    if _is_mapping(component):
        name = component.get("name")
        if isinstance(name, str) and name:
            return name
    return "Компонент"


def _kind_for_step(step: Mapping[str, object]) -> str:
    component = step.get("component") or {}
    comp_type = component.get("type") if _is_mapping(component) else None
    params = step.get("parameters")
    params_object = params if _is_mapping(params) else {}
    if comp_type == "Goal":
        return "goal"
    if comp_type == "Fact":
        return "fact"
    if comp_type == "Expectation":
        wait_cfg = params_object.get("__wait__")
        if isinstance(wait_cfg, dict) and wait_cfg.get("enabled"):
            return "wait"
        return "check"
    return "action"


def _desc_for_step(step: Mapping[str, object]) -> str:
    component = step.get("component") or {}
    comp_name = _component_name(step)
    comp_type = component.get("type") if _is_mapping(component) else None
    params_value = step.get("parameters")
    params = params_value if _is_mapping(params_value) else {}
    target = _primary_target(params)
    input_value = _first_value(
        params,
        (
            "text",
            "value",
            "option",
            "query",
            "username",
            "password",
            "email",
            "content",
        ),
    )
    expected_value = _first_value(
        params,
        (
            "expected",
            "contains",
            "equals",
            "status",
            "state",
            "count",
            "visible",
            "selected",
            "checked",
        ),
    )
    bindings_value = step.get("bindings")
    bindings = bindings_value if _is_mapping(bindings_value) else None
    save_as_value = bindings.get("save_as") if bindings is not None else None
    save_as = str(save_as_value) if save_as_value is not None else None

    if comp_type == "Goal":
        return (
            f"Подготавливает {target}"
            if target
            else f"Формирует цель через {comp_name}"
        )
    if comp_type == "Fact":
        if target and save_as:
            return f"Считывает данные из {target} и сохраняет в {save_as}"
        if target:
            return f"Считывает данные из {target}"
        if save_as:
            return f"Получает данные и сохраняет в {save_as}"
        return f"Получает данные через {comp_name}"
    if comp_type == "Expectation":
        wait_cfg = _mapping_or_empty(params.get("__wait__"))
        if wait_cfg.get("enabled"):
            if target and expected_value:
                return f"Ожидает, что {target} станет {expected_value}"
            if target:
                return f"Ожидает изменение {target}"
            return f"Ожидает выполнение условия {comp_name}"
        if target and expected_value:
            return f"Проверяет {target}: {expected_value}"
        if target:
            return f"Проверяет {target}"
        if expected_value:
            return f"Проверяет значение {expected_value}"
        return f"Проверяет {comp_name}"
    if "url" in params:
        return f"Открывает {_format_value(params['url'])}"
    if "option" in params and target:
        return f"Выбирает {_format_value(params['option'])} в {target}"
    if input_value and target:
        return f"Заполняет {target} значением {input_value}"
    if target:
        return f"Выполняет действие для {target}"
    return f"Выполняет {comp_name}"


def _step_node(
    step: Mapping[str, object], path: list[object], ts: float
) -> StructureNode:
    kind = _kind_for_step(step)
    component = step.get("component") or {}
    component_name = component.get("name") if _is_mapping(component) else None
    params_value = step.get("parameters")
    component_params: StructureNode = (
        dict(params_value) if _is_mapping(params_value) else {}
    )
    children: list[StructureNode] = []
    out: StructureNode = {
        "id": _node_id(path),
        "type": kind,
        "description": _desc_for_step(step),
        "timestamp": ts,
        "children": children,
        "component_name": component_name,
        "component_params": component_params,
    }
    policy = step.get("policy")
    if isinstance(policy, dict) and policy:
        out["policy"] = policy
    if kind == "fact" and isinstance(step.get("bindings"), dict):
        out["bindings"] = step.get("bindings")
    if kind == "wait":
        wait_cfg = _mapping_or_empty(component_params.get("__wait__"))
        if wait_cfg:
            out["domain"] = wait_cfg.get("domain")
    return out


def _allure(
    description: str,
    path: list[object],
    ts: float,
    children: list[StructureNode] | None = None,
) -> StructureNode:
    return {
        "id": _node_id(path),
        "type": "allure_step",
        "description": description,
        "timestamp": ts,
        "children": children or [],
    }


def _children(
    nodes: Sequence[object], path: list[object], ts: float
) -> list[StructureNode]:
    result: list[StructureNode] = []
    for idx, node in enumerate(nodes):
        cur_path = [*path, idx]
        raw_node: object = node
        if is_scenario_node_instance(node):
            scenario_node: ScenarioNodeLike = node
            raw_node = dump_scenario_node(scenario_node)
        if not _is_mapping(raw_node):
            result.append(
                _allure(
                    f"Не удалось показать узел сценария: {type(node).__name__}",
                    cur_path,
                    ts,
                    [],
                )
            )
            continue

        if "component" in raw_node and "parameters" in raw_node:
            result.append(_step_node(raw_node, cur_path, ts))
            continue

        if (
            "condition_fact" in raw_node
            and "expectation" in raw_node
            and "then_steps" in raw_node
        ):
            then_steps = raw_node.get("then_steps")
            if not isinstance(then_steps, list):
                result.append(
                    _allure(
                        "Некорректный if-блок: then_steps должен быть списком.",
                        cur_path,
                        ts,
                        [],
                    )
                )
                continue
            else_steps_value = raw_node.get("else_steps")
            if else_steps_value is not None and not isinstance(else_steps_value, list):
                result.append(
                    _allure(
                        "Некорректный if-блок: else_steps должен быть списком.",
                        cur_path,
                        ts,
                        [],
                    )
                )
                continue
            cond_fact = _component_name(raw_node, "condition_fact")
            expect = _component_name(raw_node, "expectation")
            then_items = _children(then_steps, [*cur_path, "then"], ts)
            branches = [_allure("Тогда", [*cur_path, "branch_then"], ts, then_items)]
            else_steps = else_steps_value if isinstance(else_steps_value, list) else []
            if else_steps:
                else_items = _children(else_steps, [*cur_path, "else"], ts)
                branches.append(
                    _allure("Иначе", [*cur_path, "branch_else"], ts, else_items)
                )
            result.append(
                _allure(
                    f"Если {cond_fact} подтверждает условие {expect}",
                    cur_path,
                    ts,
                    branches,
                )
            )
            continue

        if "items_fact" in raw_node or "items_var" in raw_node:
            steps = raw_node.get("steps")
            if not isinstance(steps, list):
                result.append(
                    _allure(
                        "Некорректный foreach-блок: steps должен быть списком.",
                        cur_path,
                        ts,
                        [],
                    )
                )
                continue
            source = "списка"
            if raw_node.get("items_fact") is not None:
                source = _component_name(raw_node, "items_fact")
            elif raw_node.get("items_var") is not None:
                source = _format_value(raw_node.get("items_var"))
            result.append(
                _allure(
                    f"Для каждого элемента из {source}",
                    cur_path,
                    ts,
                    _children(steps, [*cur_path, "body"], ts),
                )
            )
            continue

        if (
            "max_iterations" in raw_node
            and "condition_fact" in raw_node
            and "expectation" in raw_node
        ):
            steps = raw_node.get("steps")
            if not isinstance(steps, list):
                result.append(
                    _allure(
                        "Некорректный while-блок: steps должен быть списком.",
                        cur_path,
                        ts,
                        [],
                    )
                )
                continue
            cf = _component_name(raw_node, "condition_fact")
            ex = _component_name(raw_node, "expectation")
            max_iter = raw_node.get("max_iterations")
            result.append(
                _allure(
                    f"Повторять шаги до выполнения условия {ex} на основе {cf} (до {max_iter} итераций)",
                    cur_path,
                    ts,
                    _children(steps, [*cur_path, "body"], ts),
                )
            )
            continue

        if "retries" in raw_node and "steps" in raw_node:
            steps = raw_node.get("steps")
            if not isinstance(steps, list):
                result.append(
                    _allure(
                        "Некорректный retry-блок: steps должен быть списком.",
                        cur_path,
                        ts,
                        [],
                    )
                )
                continue
            retries_value = raw_node.get("retries")
            if not isinstance(retries_value, int):
                result.append(
                    _allure(
                        "Некорректный retry-блок: retries должен быть целым числом.",
                        cur_path,
                        ts,
                        [],
                    )
                )
                continue
            retries = retries_value
            attempts = retries + 1
            details: list[str] = [f"до {attempts} попыток"]
            if raw_node.get("interval") is not None:
                details.append(
                    f"интервал {_format_value(raw_node.get('interval'))} сек"
                )
            if raw_node.get("backoff"):
                details.append(f"стратегия {_format_value(raw_node.get('backoff'))}")
            result.append(
                _allure(
                    f"Повторить блок ({', '.join(details)})",
                    cur_path,
                    ts,
                    _children(steps, [*cur_path, "body"], ts),
                )
            )
            continue

        result.append(
            _allure(
                f"Не удалось показать узел сценария: {type(node).__name__}",
                cur_path,
                ts,
                [],
            )
        )

    return result


def build_test_structure_from_ir(
    node_id: str,
    test_name: str | None,
    steps: Sequence[ScenarioNodeLike | object],
) -> StructureNode:
    ts = time.time()
    label = (test_name or node_id.split("::")[-1] or node_id).strip()
    return {
        "id": _node_id(["root", node_id]),
        "type": "test",
        "description": label,
        "timestamp": ts,
        "node_id": node_id,
        "children": _children(steps, ["root", "steps"], ts),
    }
