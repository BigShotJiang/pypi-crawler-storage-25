from __future__ import annotations

import ast
from collections.abc import Mapping

from persona_dsl.utils import data_providers as dp

from .models import (
    BackoffMode,
    ElementRef,
    ForEachFactNode,
    IfNode,
    ParseCodeResponse,
    ParseDiagnostic,
    RetryNode,
    RetryPolicy,
    ScenarioModelNodeList,
    ScenarioParameterValue,
    ScenarioParameters,
    StepBindings,
    StepNode,
    SystemRef,
    TestComponent,
    VarRef,
    WhileNode,
)
from .data_driven_index import extract_data_driven_spec

IR_START = "# >>> IR-GENERATED-START"
IR_END = "# <<< IR-GENERATED-END"

ComponentCatalog = Mapping[str, object]


class IRParseError(ValueError):
    def __init__(
        self,
        message: str,
        lineno: int | None = None,
        col: int | None = None,
        context: str | None = None,
    ):
        parts = [message]
        if lineno is not None:
            parts.append(
                f"(line {lineno}" + (f", col {col}" if col is not None else "") + ")"
            )
        if context:
            parts.append(f": {context}")
        super().__init__(" ".join(parts))
        self.lineno = lineno
        self.col = col
        self.context = context


def _diag(
    message: str, node: ast.AST | None = None, context: str | None = None
) -> ParseDiagnostic:
    return ParseDiagnostic(
        message=message,
        lineno=getattr(node, "lineno", None) if node is not None else None,
        col=getattr(node, "col_offset", None) if node is not None else None,
        context=context,
    )


def _unparse_node(node: ast.AST) -> str | None:
    return ast.unparse(node) if hasattr(ast, "unparse") else None


def _scalar_literal_or_error(value: object, node: ast.AST) -> ScenarioParameterValue:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    raise IRParseError(
        "Literal expected (bool/int/float/str/list/dict/tuple)",
        getattr(node, "lineno", None),
        getattr(node, "col_offset", None),
        _unparse_node(node),
    )


def _persona_call(node: ast.AST, *attrs: str) -> ast.Call | None:
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr in attrs
    ):
        return node
    return None


def _range_call(node: ast.AST) -> ast.Call | None:
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "range"
    ):
        return node
    return None


def _single_int_range_limit(loop: ast.For) -> int | None:
    range_call = _range_call(loop.iter)
    if range_call is None:
        return None
    range_args = list(range_call.args)
    if (
        len(range_args) == 1
        and isinstance(range_args[0], ast.Constant)
        and isinstance(range_args[0].value, int)
    ):
        return int(range_args[0].value)
    return None


def _retry_count(loop: ast.For) -> int | None:
    range_call = _range_call(loop.iter)
    if range_call is None:
        return None
    range_args = list(range_call.args)
    if len(range_args) != 1:
        return None
    range_arg = range_args[0]
    if not (
        isinstance(range_arg, ast.BinOp)
        and isinstance(range_arg.op, ast.Add)
        and isinstance(range_arg.left, ast.Constant)
        and isinstance(range_arg.left.value, int)
        and isinstance(range_arg.right, ast.Constant)
        and range_arg.right.value == 1
    ):
        return None
    return int(range_arg.left.value)


def _strip_trailing_break(statements: list[ast.stmt]) -> list[ast.stmt]:
    if statements and isinstance(statements[-1], ast.Break):
        return statements[:-1]
    return statements


def _extract_retry_policy(
    handler_body: list[ast.stmt],
) -> tuple[float, BackoffMode, float]:
    interval = 0.5
    backoff: BackoffMode = "linear"
    jitter = 0.0
    for stmt in handler_body:
        if (
            isinstance(stmt, ast.Assign)
            and stmt.targets
            and isinstance(stmt.targets[0], ast.Name)
            and stmt.targets[0].id == "_delay"
            and isinstance(stmt.value, ast.IfExp)
        ):
            if isinstance(stmt.value.body, ast.Constant) and isinstance(
                stmt.value.body.value, (int, float)
            ):
                interval = float(stmt.value.body.value)
            if (
                isinstance(stmt.value.test, ast.Compare)
                and isinstance(stmt.value.test.left, ast.Constant)
                and isinstance(stmt.value.test.left.value, str)
            ):
                if stmt.value.test.left.value == "linear":
                    backoff = "linear"
                elif stmt.value.test.left.value == "exp":
                    backoff = "exp"
        if (
            isinstance(stmt, ast.If)
            and isinstance(stmt.test, ast.Compare)
            and isinstance(stmt.test.left, ast.Constant)
            and isinstance(stmt.test.left.value, (int, float))
        ):
            jitter = float(stmt.test.left.value)
    return interval, backoff, jitter


def _false_flag_assignment_name(statement: ast.stmt) -> str | None:
    if not (
        isinstance(statement, ast.Assign)
        and len(statement.targets) == 1
        and isinstance(statement.targets[0], ast.Name)
        and isinstance(statement.value, ast.Constant)
        and statement.value.value is False
    ):
        return None
    return statement.targets[0].id


def _true_flag_assignment_name(statement: ast.stmt) -> str | None:
    if not (
        isinstance(statement, ast.Assign)
        and len(statement.targets) == 1
        and isinstance(statement.targets[0], ast.Name)
        and isinstance(statement.value, ast.Constant)
        and statement.value.value is True
    ):
        return None
    return statement.targets[0].id


def _generated_while_guard_flag(statement: ast.stmt) -> str | None:
    if not isinstance(statement, ast.If):
        return None
    if not (
        isinstance(statement.test, ast.UnaryOp)
        and isinstance(statement.test.op, ast.Not)
        and isinstance(statement.test.operand, ast.Name)
    ):
        return None
    if len(statement.body) != 1 or not isinstance(statement.body[0], ast.Raise):
        return None
    error_call = statement.body[0].exc
    if not (
        isinstance(error_call, ast.Call)
        and isinstance(error_call.func, ast.Name)
        and error_call.func.id == "AssertionError"
        and error_call.args
        and isinstance(error_call.args[0], ast.Constant)
        and isinstance(error_call.args[0].value, str)
        and "Условие выхода цикла While" in error_call.args[0].value
    ):
        return None
    return statement.test.operand.id


def _is_generated_if_flag_init(statements: list[ast.stmt], index: int) -> bool:
    flag_name = _false_flag_assignment_name(statements[index])
    if flag_name is None or index + 2 >= len(statements):
        return False
    try_stmt = statements[index + 1]
    if_stmt = statements[index + 2]
    return (
        isinstance(try_stmt, ast.Try)
        and isinstance(if_stmt, ast.If)
        and isinstance(if_stmt.test, ast.Name)
        and if_stmt.test.id == flag_name
    )


def _is_generated_while_flag_init(statements: list[ast.stmt], index: int) -> bool:
    flag_name = _false_flag_assignment_name(statements[index])
    if flag_name is None or index + 2 >= len(statements):
        return False
    loop_stmt = statements[index + 1]
    guard_stmt = statements[index + 2]
    return (
        isinstance(loop_stmt, ast.For)
        and _generated_while_guard_flag(guard_stmt) == flag_name
    )


def _is_generated_if_try_statement(statements: list[ast.stmt], index: int) -> bool:
    if index == 0 or index + 1 >= len(statements):
        return False
    statement = statements[index]
    next_statement = statements[index + 1]
    flag_name = _false_flag_assignment_name(statements[index - 1])
    return (
        flag_name is not None
        and isinstance(statement, ast.Try)
        and isinstance(next_statement, ast.If)
        and isinstance(next_statement.test, ast.Name)
        and next_statement.test.id == flag_name
    )


def _is_generated_check_result_assignment(
    statements: list[ast.stmt],
    index: int,
) -> bool:
    if index + 1 >= len(statements):
        return False
    result_info = _check_result_assignment(statements[index])
    success_info = _succeeded_check_result_if(statements[index + 1])
    if result_info is None or success_info is None:
        return False
    result_name, _, _ = result_info
    success_name, _, _ = success_info
    return result_name == success_name


def _check_result_assignment(
    statement: ast.stmt,
) -> tuple[str, ast.Call, str] | None:
    if not (
        isinstance(statement, ast.Assign)
        and len(statement.targets) == 1
        and isinstance(statement.targets[0], ast.Name)
        and isinstance(statement.value, ast.Call)
        and isinstance(statement.value.func, ast.Attribute)
        and statement.value.func.attr == "check_result"
        and isinstance(statement.value.func.value, ast.Call)
        and statement.value.args
        and isinstance(statement.value.args[0], ast.Name)
    ):
        return None
    return (
        statement.targets[0].id,
        statement.value.func.value,
        statement.value.args[0].id,
    )


def _succeeded_check_result_if(
    statement: ast.stmt,
) -> tuple[str, list[ast.stmt], list[ast.stmt]] | None:
    if not isinstance(statement, ast.If):
        return None
    if not (
        isinstance(statement.test, ast.Attribute)
        and statement.test.attr == "succeeded"
        and isinstance(statement.test.value, ast.Name)
    ):
        return None
    return statement.test.value.id, statement.body, statement.orelse


def _parse_generated_while_loop(
    loop: ast.For,
    components_by_name: ComponentCatalog,
    diagnostics: list[ParseDiagnostic],
) -> WhileNode | None:
    max_iterations = _single_int_range_limit(loop)
    if max_iterations is None or len(loop.body) < 2:
        return None

    first_stmt = loop.body[0]
    if not (
        isinstance(first_stmt, ast.Assign)
        and len(first_stmt.targets) == 1
        and isinstance(first_stmt.targets[0], ast.Name)
    ):
        return None

    condition_call = _persona_call(first_stmt.value, "get")
    if condition_call is None:
        return None

    try:
        condition_fact = _parse_persona_get(condition_call, components_by_name)
    except IRParseError as error:
        diagnostics.append(_diag(str(error), first_stmt, _unparse_node(first_stmt)))
        return None

    expectation_component: TestComponent | None = None
    expectation_params: ScenarioParameters = {}
    inner_steps: ScenarioModelNodeList = []

    try_stmt = loop.body[1] if len(loop.body) >= 2 else None
    if isinstance(try_stmt, ast.Try):
        if not try_stmt.body:
            return None
        check_stmt = try_stmt.body[0]
        if not (
            isinstance(check_stmt, ast.Expr) and isinstance(check_stmt.value, ast.Call)
        ):
            return None

        check_call = check_stmt.value
        if not (
            isinstance(check_call.func, ast.Attribute)
            and check_call.func.attr == "check"
            and isinstance(check_call.func.value, ast.Call)
            and check_call.args
            and isinstance(check_call.args[-1], ast.Name)
            and check_call.args[-1].id == first_stmt.targets[0].id
        ):
            return None

        try:
            expectation_component, expectation_params = _call_to_component(
                check_call.func.value,
                components_by_name,
            )
        except IRParseError as error:
            diagnostics.append(_diag(str(error), check_stmt, _unparse_node(check_stmt)))
            return None

        handler_body = try_stmt.handlers[0].body if try_stmt.handlers else []
        inner_steps = _parse_block(handler_body, components_by_name, diagnostics)
    else:
        if len(loop.body) < 3:
            return None
        result_stmt = loop.body[1]
        if_stmt = loop.body[2]
        result_info = _check_result_assignment(result_stmt)
        if result_info is None:
            return None
        result_name, expectation_ctor, cond_var_name = result_info
        if cond_var_name != first_stmt.targets[0].id:
            return None

        success_info = _succeeded_check_result_if(if_stmt)
        if success_info is None:
            return None
        success_name, success_body, failure_body = success_info
        if success_name != result_name or len(success_body) != 2:
            return None
        if _true_flag_assignment_name(success_body[0]) is None:
            return None
        if not isinstance(success_body[1], ast.Break):
            return None

        try:
            expectation_component, expectation_params = _call_to_component(
                expectation_ctor,
                components_by_name,
            )
        except IRParseError as error:
            diagnostics.append(
                _diag(str(error), result_stmt, _unparse_node(result_stmt))
            )
            return None

        inner_steps = _parse_block(failure_body, components_by_name, diagnostics)

    if expectation_component is None:
        return None

    return WhileNode(
        condition_fact=condition_fact.component,
        condition_params=condition_fact.parameters,
        expectation=expectation_component,
        expectation_params=expectation_params,
        steps=inner_steps,
        max_iterations=max_iterations,
    )


def _parse_generated_retry_loop(
    loop: ast.For,
    components_by_name: ComponentCatalog,
    diagnostics: list[ParseDiagnostic],
) -> RetryNode | None:
    retries = _retry_count(loop)
    if retries is None or not loop.body or not isinstance(loop.body[0], ast.Try):
        return None

    try_stmt = loop.body[0]
    retry_steps = _parse_block(
        _strip_trailing_break(try_stmt.body),
        components_by_name,
        diagnostics,
    )
    handler_body = try_stmt.handlers[0].body if try_stmt.handlers else []
    interval, backoff, jitter = _extract_retry_policy(handler_body)
    return RetryNode(
        policy=RetryPolicy(
            retries=retries,
            interval=interval,
            backoff=backoff,
            jitter=jitter,
        ),
        steps=retry_steps,
    )


def _slice_ir_region(source_code: str) -> tuple[str, str | None]:
    lines = source_code.splitlines()
    start_idx = end_idx = None
    test_name = None
    def_idx = None

    for i, ln in enumerate(lines):
        stripped = ln.strip()
        if (
            stripped.startswith("def ")
            and "(" in stripped
            and stripped.endswith(":")
            and test_name is None
        ):
            header = stripped[4:]
            test_name = header.split("(")[0].strip()
            def_idx = i
        if IR_START in ln:
            start_idx = i
        if IR_END in ln:
            end_idx = i

    if start_idx is not None and end_idx is not None and end_idx > start_idx:
        return "\n".join(lines[start_idx + 1 : end_idx]), test_name

    if def_idx is not None:
        import textwrap

        region = textwrap.dedent("\n".join(lines[def_idx + 1 :]))
        return region, test_name

    raise IRParseError("IR markers are missing or malformed")


def _literal_from_ast(node: ast.AST) -> ScenarioParameterValue:
    if isinstance(node, ast.Constant):
        return _scalar_literal_or_error(node.value, node)
    if isinstance(node, ast.Dict):
        result: ScenarioParameters = {}
        for k, v in zip(node.keys, node.values):
            if k is None:
                continue
            key = _literal_from_ast(k)
            if not isinstance(key, str):
                raise IRParseError(
                    "Ключ объекта сценария должен быть строковым литералом.",
                    getattr(k, "lineno", None),
                    getattr(k, "col_offset", None),
                    _unparse_node(k),
                )
            result[key] = _literal_from_ast(v)
        return result
    if isinstance(node, ast.List):
        return [_literal_from_ast(elt) for elt in node.elts]
    if isinstance(node, ast.Tuple):
        return tuple(_literal_from_ast(elt) for elt in node.elts)
    raise IRParseError(
        "Literal expected (bool/int/float/str/list/dict/tuple)",
        getattr(node, "lineno", None),
        getattr(node, "col_offset", None),
        _unparse_node(node),
    )


def _keyword_arguments(call: ast.Call, context: str) -> dict[str, ast.AST]:
    kwargs: dict[str, ast.AST] = {}
    for keyword in call.keywords or []:
        if keyword.arg is None:
            raise IRParseError(
                f"{context}: распаковка kwargs не поддерживается",
                getattr(keyword, "lineno", None),
                getattr(keyword, "col_offset", None),
            )
        if keyword.arg in kwargs:
            raise IRParseError(
                f"{context}: аргумент '{keyword.arg}' передан несколько раз",
                getattr(keyword, "lineno", None),
                getattr(keyword, "col_offset", None),
            )
        kwargs[keyword.arg] = keyword.value
    return kwargs


def _require_int_literal(value: object, node: ast.AST, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise IRParseError(
            f"Поле '{field_name}' должно быть целым числом.",
            getattr(node, "lineno", None),
            getattr(node, "col_offset", None),
            _unparse_node(node),
        )
    return value


def _require_number_literal(value: object, node: ast.AST, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise IRParseError(
            f"Поле '{field_name}' должно быть числом.",
            getattr(node, "lineno", None),
            getattr(node, "col_offset", None),
            _unparse_node(node),
        )
    return float(value)


def _parse_generated_retry_policy_call(call: ast.Call) -> RetryPolicy:
    if not (isinstance(call.func, ast.Name) and call.func.id == "RetryPolicy"):
        raise IRParseError(
            "Ожидался вызов RetryPolicy(...)",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
            _unparse_node(call),
        )
    if call.args:
        raise IRParseError(
            "RetryPolicy в сгенерированном сценарии должен использовать только именованные аргументы.",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
            _unparse_node(call),
        )
    kwargs = _keyword_arguments(call, "RetryPolicy")
    expected_fields = {
        "max_attempts",
        "delay",
        "backoff_mode",
        "backoff_factor",
        "jitter",
    }
    if set(kwargs) != expected_fields:
        raise IRParseError(
            "RetryPolicy должен содержать ровно поля max_attempts, delay, backoff_mode, backoff_factor и jitter.",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
            _unparse_node(call),
        )

    max_attempts = _require_int_literal(
        _literal_from_ast(kwargs["max_attempts"]),
        kwargs["max_attempts"],
        "max_attempts",
    )
    if max_attempts < 1:
        raise IRParseError(
            "Поле 'max_attempts' должно быть >= 1.",
            getattr(kwargs["max_attempts"], "lineno", None),
            getattr(kwargs["max_attempts"], "col_offset", None),
            _unparse_node(kwargs["max_attempts"]),
        )
    delay = _require_number_literal(
        _literal_from_ast(kwargs["delay"]),
        kwargs["delay"],
        "delay",
    )
    backoff_mode_value = _literal_from_ast(kwargs["backoff_mode"])
    if backoff_mode_value not in {"linear", "exp"}:
        raise IRParseError(
            "Поле 'backoff_mode' должно быть 'linear' или 'exp'.",
            getattr(kwargs["backoff_mode"], "lineno", None),
            getattr(kwargs["backoff_mode"], "col_offset", None),
            _unparse_node(kwargs["backoff_mode"]),
        )
    _require_number_literal(
        _literal_from_ast(kwargs["backoff_factor"]),
        kwargs["backoff_factor"],
        "backoff_factor",
    )
    jitter = _require_number_literal(
        _literal_from_ast(kwargs["jitter"]),
        kwargs["jitter"],
        "jitter",
    )
    if backoff_mode_value == "linear":
        backoff: BackoffMode = "linear"
    elif backoff_mode_value == "exp":
        backoff = "exp"
    else:
        raise IRParseError(
            "Поле 'backoff_mode' должно быть 'linear' или 'exp'.",
            getattr(kwargs["backoff_mode"], "lineno", None),
            getattr(kwargs["backoff_mode"], "col_offset", None),
            _unparse_node(kwargs["backoff_mode"]),
        )
    return RetryPolicy(
        retries=max_attempts - 1,
        interval=delay,
        backoff=backoff,
        jitter=jitter,
    )


def _unwrap_retryable_component_call(
    expr: ast.AST,
) -> tuple[ast.Call, RetryPolicy | None]:
    if not isinstance(expr, ast.Call):
        raise IRParseError(
            "Ожидался вызов компонента.",
            getattr(expr, "lineno", None),
            getattr(expr, "col_offset", None),
            _unparse_node(expr),
        )
    if not (isinstance(expr.func, ast.Attribute) and expr.func.attr == "with_retry"):
        return expr, None
    if len(expr.args) != 1 or expr.keywords:
        raise IRParseError(
            "with_retry(...) в сгенерированном сценарии должен принимать ровно один аргумент RetryPolicy(...).",
            getattr(expr, "lineno", None),
            getattr(expr, "col_offset", None),
            _unparse_node(expr),
        )
    if not isinstance(expr.func.value, ast.Call):
        raise IRParseError(
            "with_retry(...) должен вызываться у конструктора компонента.",
            getattr(expr.func, "lineno", None),
            getattr(expr.func, "col_offset", None),
            _unparse_node(expr),
        )
    policy_expr = expr.args[0]
    if not isinstance(policy_expr, ast.Call):
        raise IRParseError(
            "with_retry(...) должен принимать RetryPolicy(...).",
            getattr(policy_expr, "lineno", None),
            getattr(policy_expr, "col_offset", None),
            _unparse_node(policy_expr),
        )
    policy = _parse_generated_retry_policy_call(policy_expr)
    return expr.func.value, policy


def _unwrap_retryable_name_reference(
    expr: ast.AST,
    *,
    expected_name: str,
) -> RetryPolicy | None:
    if isinstance(expr, ast.Name) and expr.id == expected_name:
        return None
    if not (
        isinstance(expr, ast.Call)
        and isinstance(expr.func, ast.Attribute)
        and expr.func.attr == "with_retry"
        and isinstance(expr.func.value, ast.Name)
        and expr.func.value.id == expected_name
    ):
        raise IRParseError(
            f"Ожидалась ссылка на '{expected_name}' или '{expected_name}.with_retry(RetryPolicy(...))'.",
            getattr(expr, "lineno", None),
            getattr(expr, "col_offset", None),
            _unparse_node(expr),
        )
    if len(expr.args) != 1 or expr.keywords:
        raise IRParseError(
            "with_retry(...) в сгенерированном сценарии должен принимать ровно один аргумент RetryPolicy(...).",
            getattr(expr, "lineno", None),
            getattr(expr, "col_offset", None),
            _unparse_node(expr),
        )
    policy_expr = expr.args[0]
    if not isinstance(policy_expr, ast.Call):
        raise IRParseError(
            "with_retry(...) должен принимать RetryPolicy(...).",
            getattr(policy_expr, "lineno", None),
            getattr(policy_expr, "col_offset", None),
            _unparse_node(policy_expr),
        )
    return _parse_generated_retry_policy_call(policy_expr)


def _parse_generated_retry_call(
    call: ast.Call,
    generated_blocks: dict[str, ast.FunctionDef],
    components_by_name: ComponentCatalog,
    diagnostics: list[ParseDiagnostic],
) -> RetryNode:
    if not (isinstance(call.func, ast.Name) and call.func.id == "retry_call"):
        raise IRParseError(
            "Ожидался вызов retry_call(...).",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
            _unparse_node(call),
        )
    if len(call.args) != 1 or not isinstance(call.args[0], ast.Name):
        raise IRParseError(
            "retry_call должен принимать именованную локальную функцию первым аргументом.",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
            _unparse_node(call),
        )
    block_name = call.args[0].id
    block_fn = generated_blocks.get(block_name)
    if block_fn is None:
        raise IRParseError(
            f"Не найдена функция retry-блока '{block_name}'.",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
            _unparse_node(call),
        )
    if (
        block_fn.args.posonlyargs
        or block_fn.args.args
        or block_fn.args.kwonlyargs
        or block_fn.args.vararg is not None
        or block_fn.args.kwarg is not None
    ):
        raise IRParseError(
            f"Функция retry-блока '{block_name}' не должна принимать аргументы.",
            getattr(block_fn, "lineno", None),
            getattr(block_fn, "col_offset", None),
            _unparse_node(block_fn),
        )

    kwargs = _keyword_arguments(call, "retry_call")
    expected_fields = {"retries", "interval", "backoff", "jitter"}
    if set(kwargs) != expected_fields:
        raise IRParseError(
            "retry_call должен содержать ровно поля retries, interval, backoff и jitter.",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
            _unparse_node(call),
        )
    retries = _require_int_literal(
        _literal_from_ast(kwargs["retries"]),
        kwargs["retries"],
        "retries",
    )
    interval = _require_number_literal(
        _literal_from_ast(kwargs["interval"]),
        kwargs["interval"],
        "interval",
    )
    backoff_value = _literal_from_ast(kwargs["backoff"])
    if backoff_value == "linear":
        backoff: BackoffMode = "linear"
    elif backoff_value == "exp":
        backoff = "exp"
    else:
        raise IRParseError(
            "Поле 'backoff' должно быть 'linear' или 'exp'.",
            getattr(kwargs["backoff"], "lineno", None),
            getattr(kwargs["backoff"], "col_offset", None),
            _unparse_node(kwargs["backoff"]),
        )
    jitter = _require_number_literal(
        _literal_from_ast(kwargs["jitter"]),
        kwargs["jitter"],
        "jitter",
    )
    retry_steps = _parse_block(block_fn.body, components_by_name, diagnostics)
    return RetryNode(
        policy=RetryPolicy(
            retries=retries,
            interval=interval,
            backoff=backoff,
            jitter=jitter,
        ),
        steps=retry_steps,
    )


def _varref_from_ast(node: ast.AST) -> VarRef | None:
    def collect_subscripts(n: ast.AST) -> tuple[list[ast.Subscript], ast.AST]:
        items: list[ast.Subscript] = []
        cur = n
        while isinstance(cur, ast.Subscript):
            items.append(cur)
            cur = cur.value
        return items, cur

    subs, base = collect_subscripts(node)
    if not subs:
        return None
    if not (
        isinstance(base, ast.Attribute)
        and base.attr == "memory"
        and isinstance(base.value, ast.Name)
        and base.value.id == "persona"
    ):
        return None

    def slice_value(s: ast.AST) -> ScenarioParameterValue | None:
        if isinstance(s, ast.Constant):
            return _scalar_literal_or_error(s.value, s)
        index_cls = getattr(ast, "Index", None)
        if index_cls is not None and isinstance(s, index_cls):
            index_value = getattr(s, "value", None)
            if isinstance(index_value, ast.Constant):
                return _scalar_literal_or_error(index_value.value, index_value)
        return None

    first = subs[0]
    name = slice_value(first.slice)
    if not isinstance(name, str):
        return None

    path_tokens: list[str | int] = []
    for sub in subs[1:]:
        v = slice_value(sub.slice)
        if isinstance(v, (str, int)):
            path_tokens.append(v)
        else:
            return None

    import re as _re

    parts: list[str] = []
    for token in path_tokens:
        if isinstance(token, int):
            parts.append(f"[{token}]")
        else:
            if _re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", token):
                parts.append("." + token)
            else:
                parts.append(f'["{token}"]')
    path = "".join(parts)
    if path.startswith("."):
        path = path[1:]
    return VarRef(name=name, path=path)


def _element_ref_from_ast(node: ast.AST) -> ElementRef | None:
    # PageClass().submit_button -> {kind:'element', page:'PageClass', element:'submit_button'}
    if not isinstance(node, ast.Attribute):
        return None
    if not isinstance(node.value, ast.Call):
        return None
    call = node.value
    if call.args or call.keywords:
        return None
    if not isinstance(call.func, ast.Name):
        return None
    return ElementRef(page=call.func.id, element=node.attr)


def _value_from_ast(node: ast.AST) -> ScenarioParameterValue:
    var_ref = _varref_from_ast(node)
    if var_ref is not None:
        return var_ref

    element_ref = _element_ref_from_ast(node)
    if element_ref is not None:
        return element_ref

    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
        func_name = node.func.id
        if hasattr(dp, func_name) and callable(getattr(dp, func_name)):
            if node.args:
                raise IRParseError(
                    "System provider supports only keyword arguments",
                    getattr(node, "lineno", None),
                    getattr(node, "col_offset", None),
                )
            args = {
                kw.arg: _value_from_ast(kw.value)
                for kw in (node.keywords or [])
                if kw.arg is not None
            }
            return SystemRef(name=func_name, args=args)

    if isinstance(node, ast.Constant):
        return _scalar_literal_or_error(node.value, node)
    if isinstance(node, ast.Dict):
        result: ScenarioParameters = {}
        for key_node, value_node in zip(node.keys, node.values):
            if key_node is None:
                continue
            key = _value_from_ast(key_node)
            if not isinstance(key, str):
                raise IRParseError(
                    "Ключ объекта сценария должен быть строковым литералом.",
                    getattr(key_node, "lineno", None),
                    getattr(key_node, "col_offset", None),
                    _unparse_node(key_node),
                )
            result[key] = _value_from_ast(value_node)
        return result
    if isinstance(node, ast.List):
        return [_value_from_ast(elt) for elt in node.elts]
    if isinstance(node, ast.Tuple):
        return tuple(_value_from_ast(elt) for elt in node.elts)

    raise IRParseError(
        "Unsupported value expression",
        getattr(node, "lineno", None),
        getattr(node, "col_offset", None),
        _unparse_node(node),
    )


def _component_from_catalog(
    name: str, components_by_name: ComponentCatalog
) -> TestComponent:
    if name not in components_by_name:
        raise IRParseError(f"Unknown component: {name}")
    return TestComponent.model_validate(components_by_name[name])


def _call_to_component(
    call: ast.Call,
    components_by_name: ComponentCatalog,
) -> tuple[TestComponent, ScenarioParameters]:
    if not isinstance(call.func, ast.Name):
        raise IRParseError(
            "Component constructor expected (ClassName(...))",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
        )
    component = _component_from_catalog(call.func.id, components_by_name)
    params: ScenarioParameters = {}
    param_names: list[str] = []
    for parameter in component.parameters:
        if parameter.name == "self":
            raise IRParseError(
                f"Component {component.name} must not expose parameter 'self'",
                getattr(call, "lineno", None),
                getattr(call, "col_offset", None),
            )
        param_names.append(parameter.name)

    if len(call.args or []) > len(param_names):
        raise IRParseError(
            (
                f"Component {component.name} expects at most {len(param_names)} "
                f"positional arguments, got {len(call.args or [])}"
            ),
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
            ast.unparse(call) if hasattr(ast, "unparse") else None,
        )

    for idx, arg in enumerate(call.args or []):
        params[param_names[idx]] = _value_from_ast(arg)

    for kw in call.keywords or []:
        if kw.arg is None:
            raise IRParseError(
                "Keyword unpacking is not supported in component constructor",
                getattr(kw, "lineno", None),
                getattr(kw, "col_offset", None),
            )
        if kw.arg in params:
            raise IRParseError(
                f"Argument '{kw.arg}' is passed both positionally and by keyword",
                getattr(kw, "lineno", None),
                getattr(kw, "col_offset", None),
                ast.unparse(call) if hasattr(ast, "unparse") else None,
            )
        if kw.arg not in param_names:
            raise IRParseError(
                f"Unknown parameter '{kw.arg}' for component {component.name}",
                getattr(kw, "lineno", None),
                getattr(kw, "col_offset", None),
                ast.unparse(call) if hasattr(ast, "unparse") else None,
            )
        params[kw.arg] = _value_from_ast(kw.value)
    return component, params


def _step(
    component: TestComponent,
    parameters: ScenarioParameters,
    *,
    policy: RetryPolicy | None = None,
    bindings: StepBindings | None = None,
) -> StepNode:
    return StepNode(
        component=component,
        parameters=parameters,
        policy=policy,
        bindings=bindings,
    )


def _parse_persona_make(
    call: ast.Call, components_by_name: ComponentCatalog
) -> ScenarioModelNodeList:
    args = list(call.args)
    role_value: str | None = None
    if args and isinstance(args[0], ast.Constant) and isinstance(args[0].value, str):
        role_value = args[0].value
        args = args[1:]

    result: ScenarioModelNodeList = []
    for arg in args:
        if not isinstance(arg, ast.Call):
            raise IRParseError(
                "persona.make expects Component(...) arguments",
                getattr(arg, "lineno", None),
                getattr(arg, "col_offset", None),
            )
        component_call, policy = _unwrap_retryable_component_call(arg)
        component, params = _call_to_component(component_call, components_by_name)
        if role_value is not None:
            params = {"__role__": role_value, **params}
        result.append(_step(component, params, policy=policy))
    return result


def _parse_persona_get(
    call: ast.Call, components_by_name: ComponentCatalog
) -> StepNode:
    args = list(call.args)
    role_value: str | None = None
    if args and isinstance(args[0], ast.Constant) and isinstance(args[0].value, str):
        role_value = args[0].value
        args = args[1:]

    if len(args) != 1 or not isinstance(args[0], ast.Call):
        raise IRParseError(
            "persona.get expects exactly one Fact(...) argument",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
        )

    component_call, policy = _unwrap_retryable_component_call(args[0])
    component, params = _call_to_component(component_call, components_by_name)
    if role_value is not None:
        params = {"__role__": role_value, **params}
    return _step(component, params, policy=policy)


def _parse_persona_check(
    call: ast.Call,
    components_by_name: ComponentCatalog,
    _last_fact_var: str | None,
) -> StepNode:
    if len(call.args) != 2:
        raise IRParseError(
            "persona.check expects exactly 2 arguments",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
        )
    lhs = call.args[0]
    if not isinstance(lhs, ast.Name):
        raise IRParseError(
            "First argument in persona.check must be variable name",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
            ast.unparse(call) if hasattr(ast, "unparse") else None,
        )

    exp_expr = call.args[1]
    if not isinstance(exp_expr, ast.Call):
        raise IRParseError(
            "Second argument in persona.check must be Expectation(...)",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
        )
    exp_call, policy = _unwrap_retryable_component_call(exp_expr)
    component, params = _call_to_component(exp_call, components_by_name)
    if "target" in params:
        raise IRParseError(
            "Expectation target must be passed via persona.check(...), not in constructor",
            getattr(exp_call, "lineno", None),
            getattr(exp_call, "col_offset", None),
            ast.unparse(exp_call) if hasattr(ast, "unparse") else None,
        )
    params["target"] = lhs.id
    return _step(component, params, policy=policy)


def _parse_persona_verify(
    call: ast.Call,
    components_by_name: ComponentCatalog,
) -> StepNode:
    args = list(call.args)
    if len(args) not in (1, 2):
        raise IRParseError(
            "persona.verify expects 1 or 2 arguments",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
        )

    exp_expr = args[0]
    if not isinstance(exp_expr, ast.Call):
        raise IRParseError(
            "First argument in persona.verify must be Expectation(...)",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
        )
    exp_arg, policy = _unwrap_retryable_component_call(exp_expr)
    component, params = _call_to_component(exp_arg, components_by_name)
    if "target" in params:
        raise IRParseError(
            "Expectation target must be passed via persona.verify(...), not in constructor",
            getattr(exp_arg, "lineno", None),
            getattr(exp_arg, "col_offset", None),
            ast.unparse(exp_arg) if hasattr(ast, "unparse") else None,
        )

    if len(args) >= 2:
        target = args[1]
        if isinstance(target, ast.Name):
            params["target"] = target.id
        else:
            params["target"] = _value_from_ast(target)

    return _step(component, params, policy=policy)


def _parse_wait_until(
    call: ast.Call, components_by_name: ComponentCatalog
) -> ScenarioModelNodeList:
    kwargs = {kw.arg: kw.value for kw in (call.keywords or []) if kw.arg}

    fact_expr = kwargs.get("fact")
    if not isinstance(fact_expr, ast.Lambda):
        raise IRParseError(
            "wait_until: 'fact' lambda expected",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
        )
    if not (
        isinstance(fact_expr.body, ast.Call)
        and isinstance(fact_expr.body.func, ast.Attribute)
        and fact_expr.body.func.attr == "get"
    ):
        raise IRParseError(
            "wait_until: lambda must call persona.get(...)",
            getattr(fact_expr, "lineno", None),
            getattr(fact_expr, "col_offset", None),
        )

    fact_step = _parse_persona_get(fact_expr.body, components_by_name)

    expectation_expr = kwargs.get("expectation")
    if not isinstance(expectation_expr, ast.Call):
        raise IRParseError(
            "wait_until: expectation=Expectation(...) expected",
            getattr(call, "lineno", None),
            getattr(call, "col_offset", None),
        )

    exp_component, exp_params = _call_to_component(expectation_expr, components_by_name)

    wait_cfg: ScenarioParameters = {"enabled": True}
    for field in ("timeout", "interval", "backoff", "jitter", "on_timeout", "domain"):
        if field in kwargs:
            kw_value = kwargs[field]
            try:
                wait_cfg[field] = _literal_from_ast(kw_value)
            except IRParseError:
                if isinstance(kw_value, ast.Constant):
                    wait_cfg[field] = _scalar_literal_or_error(kw_value.value, kw_value)

    exp_params = {"__wait__": wait_cfg, **exp_params}
    return [fact_step, _step(exp_component, exp_params)]


def _step_matches_fact(step: StepNode, fact_step: StepNode) -> bool:
    return (
        step.component == fact_step.component
        and step.parameters == fact_step.parameters
    )


def _is_fact_component_entry(raw_component: object) -> bool:
    return isinstance(raw_component, Mapping) and raw_component.get("type") == "Fact"


def _parse_block(
    statements: list[ast.stmt],
    components_by_name: ComponentCatalog,
    diagnostics: list[ParseDiagnostic],
) -> ScenarioModelNodeList:
    nodes: ScenarioModelNodeList = []
    last_fact_var: str | None = None
    assigned_facts: dict[str, StepNode] = {}
    generated_retry_blocks: dict[str, ast.FunctionDef] = {}

    i = 0
    n = len(statements)
    while i < n:
        s = statements[i]

        if (
            _is_generated_if_flag_init(statements, i)
            or _is_generated_while_flag_init(statements, i)
            or _is_generated_if_try_statement(statements, i)
            or _is_generated_check_result_assignment(statements, i)
        ):
            i += 1
            continue

        if isinstance(s, ast.Pass):
            i += 1
            continue

        if isinstance(s, ast.FunctionDef) and s.name.startswith("_retry_block_"):
            generated_retry_blocks[s.name] = s
            i += 1
            continue

        # temp_fact = Fact(...); temp_fact.save_as='x'; temp_fact.extract='a.b';
        # result = persona.get(temp_fact)
        if (
            isinstance(s, ast.Assign)
            and len(s.targets) == 1
            and isinstance(s.targets[0], ast.Name)
            and isinstance(s.value, ast.Call)
            and isinstance(s.value.func, ast.Name)
            and s.value.func.id in components_by_name
            and _is_fact_component_entry(components_by_name[s.value.func.id])
        ):
            fact_var = s.targets[0].id
            try:
                component, params = _call_to_component(s.value, components_by_name)
            except IRParseError as e:
                diagnostics.append(_diag(str(e), s))
                i += 1
                continue

            binding_fields: dict[str, str] = {}
            j = i + 1
            while j < n:
                stmt_j = statements[j]
                if (
                    isinstance(stmt_j, ast.Assign)
                    and len(stmt_j.targets) == 1
                    and isinstance(stmt_j.targets[0], ast.Attribute)
                ):
                    attr_t = stmt_j.targets[0]
                    if (
                        isinstance(attr_t.value, ast.Name)
                        and attr_t.value.id == fact_var
                        and attr_t.attr in ("save_as", "extract")
                    ):
                        try:
                            binding_value = _literal_from_ast(stmt_j.value)
                            if not isinstance(binding_value, str):
                                raise IRParseError(
                                    f"Значение '{attr_t.attr}' должно быть строковым литералом.",
                                    getattr(stmt_j.value, "lineno", None),
                                    getattr(stmt_j.value, "col_offset", None),
                                    _unparse_node(stmt_j.value),
                                )
                            binding_fields[attr_t.attr] = binding_value
                        except IRParseError as e:
                            diagnostics.append(_diag(str(e), stmt_j))
                        j += 1
                        continue
                break
            bindings = StepBindings(**binding_fields) if binding_fields else None

            if j < n:
                next_stmt = statements[j]
                if (
                    isinstance(next_stmt, ast.Assign)
                    and isinstance(next_stmt.value, ast.Call)
                    and isinstance(next_stmt.value.func, ast.Attribute)
                    and next_stmt.value.func.attr == "get"
                ):
                    call = next_stmt.value
                    args = list(call.args)
                    role = None
                    if (
                        args
                        and isinstance(args[0], ast.Constant)
                        and isinstance(args[0].value, str)
                    ):
                        role = args[0].value
                        args = args[1:]
                    if len(args) == 1:
                        try:
                            policy = _unwrap_retryable_name_reference(
                                args[0],
                                expected_name=fact_var,
                            )
                        except IRParseError as e:
                            diagnostics.append(_diag(str(e), next_stmt))
                            i = j + 1
                            continue
                        params2 = (
                            {"__role__": role, **params} if role is not None else params
                        )
                        node = _step(
                            component,
                            params2,
                            policy=policy,
                            bindings=bindings,
                        )
                        nodes.append(node)
                        if next_stmt.targets and isinstance(
                            next_stmt.targets[0], ast.Name
                        ):
                            last_fact_var = next_stmt.targets[0].id
                            assigned_facts[last_fact_var] = node
                        i = j + 1
                        continue
                if (
                    isinstance(next_stmt, ast.Expr)
                    and isinstance(next_stmt.value, ast.Call)
                    and isinstance(next_stmt.value.func, ast.Attribute)
                    and next_stmt.value.func.attr == "get"
                ):
                    call = next_stmt.value
                    args = list(call.args)
                    role = None
                    if (
                        args
                        and isinstance(args[0], ast.Constant)
                        and isinstance(args[0].value, str)
                    ):
                        role = args[0].value
                        args = args[1:]
                    if len(args) == 1:
                        try:
                            policy = _unwrap_retryable_name_reference(
                                args[0],
                                expected_name=fact_var,
                            )
                        except IRParseError as e:
                            diagnostics.append(_diag(str(e), next_stmt))
                            i = j + 1
                            continue
                        params2 = (
                            {"__role__": role, **params} if role is not None else params
                        )
                        nodes.append(
                            _step(
                                component,
                                params2,
                                policy=policy,
                                bindings=bindings,
                            )
                        )
                        last_fact_var = None
                        i = j + 1
                        continue

            diagnostics.append(
                _diag(
                    "Expected persona.get(tmp) after Fact save_as/extract setup",
                    s,
                    _unparse_node(s),
                )
            )
            i = j
            continue

        # persona.make(...)
        if (
            isinstance(s, ast.Expr)
            and isinstance(s.value, ast.Call)
            and isinstance(s.value.func, ast.Attribute)
            and s.value.func.attr == "make"
        ):
            try:
                nodes.extend(_parse_persona_make(s.value, components_by_name))
            except IRParseError as e:
                diagnostics.append(_diag(str(e), s))
            last_fact_var = None
            i += 1
            continue

        # var = persona.get(...)
        if (
            isinstance(s, ast.Assign)
            and isinstance(s.value, ast.Call)
            and isinstance(s.value.func, ast.Attribute)
            and s.value.func.attr == "get"
        ):
            if len(s.targets) != 1 or not isinstance(s.targets[0], ast.Name):
                diagnostics.append(
                    _diag(
                        "Expected simple assignment: var = persona.get(...)",
                        s,
                    )
                )
                i += 1
                continue
            try:
                fact_step = _parse_persona_get(s.value, components_by_name)
                nodes.append(fact_step)
                last_fact_var = s.targets[0].id
                assigned_facts[last_fact_var] = fact_step
            except IRParseError as e:
                diagnostics.append(_diag(str(e), s))
            i += 1
            continue

        # persona.check(var, Expectation(...))
        if (
            isinstance(s, ast.Expr)
            and isinstance(s.value, ast.Call)
            and isinstance(s.value.func, ast.Attribute)
            and s.value.func.attr == "check"
        ):
            try:
                nodes.append(
                    _parse_persona_check(s.value, components_by_name, last_fact_var)
                )
            except IRParseError as e:
                diagnostics.append(_diag(str(e), s))
            i += 1
            continue

        # persona.verify(Expectation(...), element)
        if (
            isinstance(s, ast.Expr)
            and isinstance(s.value, ast.Call)
            and isinstance(s.value.func, ast.Attribute)
            and s.value.func.attr == "verify"
        ):
            try:
                nodes.append(_parse_persona_verify(s.value, components_by_name))
            except IRParseError as e:
                diagnostics.append(_diag(str(e), s))
            i += 1
            continue

        # retry_call(_retry_block, ...)
        if (
            isinstance(s, ast.Expr)
            and isinstance(s.value, ast.Call)
            and isinstance(s.value.func, ast.Name)
            and s.value.func.id == "retry_call"
        ):
            try:
                nodes.append(
                    _parse_generated_retry_call(
                        s.value,
                        generated_retry_blocks,
                        components_by_name,
                        diagnostics,
                    )
                )
            except IRParseError as e:
                diagnostics.append(_diag(str(e), s))
            last_fact_var = None
            i += 1
            continue

        # wait_until(...)
        if (
            isinstance(s, ast.Expr)
            and isinstance(s.value, ast.Call)
            and isinstance(s.value.func, ast.Name)
            and s.value.func.id == "wait_until"
        ):
            try:
                nodes.extend(_parse_wait_until(s.value, components_by_name))
            except IRParseError as e:
                diagnostics.append(_diag(str(e), s))
            last_fact_var = None
            i += 1
            continue

        # for-loop patterns: While / Retry / ForEach
        if isinstance(s, ast.For):
            while_node = _parse_generated_while_loop(
                s,
                components_by_name,
                diagnostics,
            )
            if while_node is not None:
                nodes.append(while_node)
                i += 1
                continue

            retry_node = _parse_generated_retry_loop(
                s,
                components_by_name,
                diagnostics,
            )
            if retry_node is not None:
                nodes.append(retry_node)
                i += 1
                continue

            # ForEach pattern
            iter_items_fact = None
            if isinstance(s.iter, ast.Name) and s.iter.id in assigned_facts:
                iter_items_fact = assigned_facts[s.iter.id]
            inner = _parse_block(s.body, components_by_name, diagnostics)
            if iter_items_fact is not None:
                nodes.append(
                    ForEachFactNode(
                        items_fact=iter_items_fact.component,
                        items_params=iter_items_fact.parameters,
                        steps=inner,
                    )
                )
            else:
                diagnostics.append(
                    _diag(
                        "ForEach source is unsupported; expected variable from persona.get(...)",
                        s,
                        _unparse_node(s),
                    )
                )
            i += 1
            continue

        # if/else pattern generated by codegen (paired with previous try)
        if isinstance(s, ast.If):
            guard_flag = _generated_while_guard_flag(s)
            if (
                guard_flag is not None
                and i >= 2
                and _false_flag_assignment_name(statements[i - 2]) == guard_flag
                and isinstance(statements[i - 1], ast.For)
            ):
                i += 1
                continue

            prev_result_stmt = statements[i - 1] if i > 0 else None
            result_info = (
                _check_result_assignment(prev_result_stmt)
                if prev_result_stmt is not None
                else None
            )
            success_info = _succeeded_check_result_if(s)
            if result_info is not None and success_info is not None:
                result_name, expectation_ctor, cond_val_name = result_info
                success_name, then_body, else_body = success_info
                if success_name == result_name and cond_val_name in assigned_facts:
                    cond_fact = assigned_facts[cond_val_name]
                    try:
                        result_exp_component, result_exp_params = _call_to_component(
                            expectation_ctor,
                            components_by_name,
                        )
                    except IRParseError as error:
                        error_context = (
                            _unparse_node(prev_result_stmt)
                            if prev_result_stmt is not None
                            else None
                        )
                        diagnostics.append(
                            _diag(str(error), prev_result_stmt, error_context)
                        )
                        i += 1
                        continue

                    then_steps = _parse_block(
                        then_body, components_by_name, diagnostics
                    )
                    else_steps = _parse_block(
                        else_body, components_by_name, diagnostics
                    )

                    if nodes:
                        last = nodes[-1]
                        if isinstance(last, StepNode) and _step_matches_fact(
                            last, cond_fact
                        ):
                            nodes.pop()

                    nodes.append(
                        IfNode(
                            condition_fact=cond_fact.component,
                            condition_params=cond_fact.parameters,
                            expectation=result_exp_component,
                            expectation_params=result_exp_params,
                            then_steps=then_steps,
                            else_steps=else_steps,
                        )
                    )
                    i += 1
                    continue

            prev_try_stmt = statements[i - 1] if i > 0 else None
            prev_try: ast.Try | None = (
                prev_try_stmt if isinstance(prev_try_stmt, ast.Try) else None
            )

            if_exp_component: TestComponent | None = None
            if_exp_params: ScenarioParameters = {}
            if_cond_val_name: str | None = None

            if prev_try and prev_try.body:
                first_stmt = prev_try.body[0]
                if isinstance(first_stmt, ast.Expr) and isinstance(
                    first_stmt.value, ast.Call
                ):
                    call = first_stmt.value
                    if (
                        isinstance(call.func, ast.Attribute)
                        and isinstance(call.func.value, ast.Call)
                        and call.func.attr == "check"
                        and call.args
                        and isinstance(call.args[0], ast.Name)
                    ):
                        if_cond_val_name = call.args[0].id
                        try:
                            if_exp_component, if_exp_params = _call_to_component(
                                call.func.value, components_by_name
                            )
                        except IRParseError as e:
                            diagnostics.append(_diag(str(e), first_stmt))

            if (
                if_cond_val_name
                and if_cond_val_name in assigned_facts
                and if_exp_component is not None
            ):
                cond_fact = assigned_facts[if_cond_val_name]
                then_steps = _parse_block(s.body, components_by_name, diagnostics)
                else_steps = (
                    _parse_block(s.orelse, components_by_name, diagnostics)
                    if s.orelse
                    else []
                )

                if nodes:
                    last = nodes[-1]
                    if isinstance(last, StepNode) and _step_matches_fact(
                        last, cond_fact
                    ):
                        nodes.pop()

                nodes.append(
                    IfNode(
                        condition_fact=cond_fact.component,
                        condition_params=cond_fact.parameters,
                        expectation=if_exp_component,
                        expectation_params=if_exp_params,
                        then_steps=then_steps,
                        else_steps=else_steps,
                    )
                )
                i += 1
                continue

            diagnostics.append(
                _diag(
                    "Generic if-expression parsing is not supported; use codegen if-pattern",
                    s,
                    _unparse_node(s),
                )
            )
            i += 1
            continue

        diagnostics.append(
            _diag(
                "Unsupported expression in IR region",
                s,
                _unparse_node(s),
            )
        )
        i += 1

    return nodes


def parse_to_ir(
    source_code: str, components_by_name: ComponentCatalog
) -> tuple[ScenarioModelNodeList, str | None]:
    region, test_name = _slice_ir_region(source_code)
    wrapped = "def __f__():\n" + "\n".join(
        ("    " + line if line.strip() else line) for line in region.splitlines()
    )
    try:
        module = ast.parse(wrapped)
    except SyntaxError as e:
        raise IRParseError(f"Syntax error in IR block: {e.msg}", e.lineno, e.offset)

    fn = next(
        (
            n
            for n in module.body
            if isinstance(n, ast.FunctionDef) and n.name == "__f__"
        ),
        None,
    )
    if fn is None:
        raise IRParseError("Internal error: wrapped function AST is missing")

    diagnostics: list[ParseDiagnostic] = []
    nodes = _parse_block(fn.body, components_by_name, diagnostics)
    return nodes, test_name


def parse_to_ir_response(
    source_code: str, components_by_name: ComponentCatalog
) -> ParseCodeResponse:
    region, test_name = _slice_ir_region(source_code)
    wrapped = "def __f__():\n" + "\n".join(
        ("    " + line if line.strip() else line) for line in region.splitlines()
    )
    try:
        module = ast.parse(wrapped)
    except SyntaxError as e:
        raise IRParseError(f"Syntax error in IR block: {e.msg}", e.lineno, e.offset)

    fn = next(
        (
            n
            for n in module.body
            if isinstance(n, ast.FunctionDef) and n.name == "__f__"
        ),
        None,
    )
    if fn is None:
        raise IRParseError("Internal error: wrapped function AST is missing")

    diagnostics: list[ParseDiagnostic] = []
    nodes = _parse_block(fn.body, components_by_name, diagnostics)
    data_driven_spec = extract_data_driven_spec(source_code, test_name=test_name)
    return ParseCodeResponse.model_validate(
        {
            "steps": nodes,
            "test_name": test_name,
            "diagnostics": diagnostics,
            "data_driven": (
                dict(data_driven_spec) if data_driven_spec is not None else None
            ),
        }
    )
