from __future__ import annotations

from copy import deepcopy
from typing import Mapping, Sequence

from .codegen import generate_step_code, generate_test_code
from .diff import diff_graph_nodes
from .ir_parser import parse_to_ir_response
from .models import (
    GraphDiffResult,
    GraphIssue,
    JsonObject,
    JsonValue,
    ParseCodeResponse,
    ScenarioNodeLike,
    ScenarioRoundtripResult,
    ScenarioTemplate,
)
from .plan import build_test_structure_from_ir
from .templates import get_template, list_templates
from .validator import validate_graph_nodes


def parse_code_to_graph(
    source_code: str, components_by_name: dict[str, JsonObject]
) -> ParseCodeResponse:
    return parse_to_ir_response(source_code, components_by_name)


def validate_graph(
    nodes: Sequence[ScenarioNodeLike],
) -> list[GraphIssue]:
    return validate_graph_nodes(nodes)


def graph_to_test_code(
    *,
    test_name: str,
    nodes: Sequence[ScenarioNodeLike],
    data_driven: Mapping[str, JsonValue] | None = None,
    page_imports: Mapping[str, str] | None = None,
) -> str:
    return generate_test_code(
        test_name=test_name,
        steps=nodes,
        data_driven=data_driven,
        page_imports=page_imports,
    )


def graph_to_step_code(
    *,
    name: str,
    kind: str,
    nodes: Sequence[ScenarioNodeLike],
    docstring: str | None = None,
    page_imports: Mapping[str, str] | None = None,
) -> str:
    return generate_step_code(
        name=name,
        kind=kind,
        nodes=nodes,
        docstring=docstring,
        page_imports=page_imports,
    )


def graph_to_structure(
    *,
    node_id: str,
    test_name: str | None,
    nodes: Sequence[ScenarioNodeLike],
) -> dict[str, object]:
    return build_test_structure_from_ir(
        node_id=node_id, test_name=test_name, steps=nodes
    )


def diff_graphs(
    *,
    before_nodes: Sequence[ScenarioNodeLike],
    after_nodes: Sequence[ScenarioNodeLike],
) -> GraphDiffResult:
    return diff_graph_nodes(before_nodes, after_nodes)


def roundtrip_check(
    *,
    test_name: str,
    nodes: Sequence[ScenarioNodeLike],
    components_by_name: dict[str, JsonObject],
    data_driven: Mapping[str, JsonValue] | None = None,
    page_imports: Mapping[str, str] | None = None,
) -> ScenarioRoundtripResult:
    issues = validate_graph(nodes)
    code = graph_to_test_code(
        test_name=test_name,
        nodes=nodes,
        data_driven=data_driven,
        page_imports=page_imports,
    )
    parsed = parse_to_ir_response(code, components_by_name)
    diff = diff_graph_nodes(nodes, parsed.steps)
    return ScenarioRoundtripResult(
        generated_code=code,
        parsed_steps=deepcopy(parsed.steps),
        diff=diff,
        issues=issues,
    )


def list_graph_templates() -> list[ScenarioTemplate]:
    return list_templates()


def get_graph_template(template_id: str) -> ScenarioTemplate | None:
    return get_template(template_id)
