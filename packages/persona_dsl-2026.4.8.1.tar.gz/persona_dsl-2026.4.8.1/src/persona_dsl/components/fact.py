from ..contracts import ResultT
from .step import Step


class Fact(Step[ResultT]):
    """
    Алиас для Step, предназначенный для story-стиля.
    Не содержит собственной логики.
    """

    pass
