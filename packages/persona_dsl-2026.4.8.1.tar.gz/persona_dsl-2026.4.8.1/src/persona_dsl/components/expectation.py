from __future__ import annotations

from collections.abc import Iterator, MutableMapping
from typing import NoReturn

from ..persona import Persona
from ..contracts import (
    ExecutionOutcome,
    RetryConfigMap,
    capture_outcome,
)
from .step import Step


class _MissingMemoryStore(MutableMapping[str, object]):
    def _raise(self) -> NoReturn:
        raise RuntimeError(
            "Expectation.check_result требует persona для ожиданий, которые обращаются к контексту."
        )

    def __getitem__(self, key: str) -> object:
        self._raise()

    def __setitem__(self, key: str, value: object) -> None:
        self._raise()

    def __delitem__(self, key: str) -> None:
        self._raise()

    def __iter__(self) -> Iterator[str]:
        self._raise()

    def __len__(self) -> int:
        self._raise()


class _MissingPersona(Persona):
    def __init__(self) -> None:
        super().__init__(name="Отсутствующая персона")
        self.memory = _MissingMemoryStore()

    @property
    def retries_config(self) -> RetryConfigMap | None:
        raise RuntimeError(
            "Expectation.check_result требует persona для ожиданий, которые обращаются к retries_config."
        )

    @retries_config.setter
    def retries_config(self, value: object) -> None:
        self.__dict__["_missing_retries_config"] = value


def _build_missing_persona_context() -> Persona:
    return _MissingPersona()


_MISSING_PERSONA_CONTEXT = _build_missing_persona_context()


class Expectation(Step[None]):
    """
    Алиас для Step, предназначенный для story-стиля.
    Не содержит собственной логики.
    """

    def check_result(
        self,
        actual_value: object,
        *,
        persona: Persona | None = None,
    ) -> ExecutionOutcome[None]:
        context = persona if persona is not None else _MISSING_PERSONA_CONTEXT

        def execute_check() -> None:
            self._perform(context, actual_value)

        return capture_outcome(execute_check)

    def check(self, persona: Persona, actual_value: object) -> None:
        outcome = self.check_result(actual_value, persona=persona)
        if outcome.failed:
            raise outcome.require_error()
