from __future__ import annotations

import json
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import is_dataclass
from typing import TYPE_CHECKING, Generic, Protocol, TypeVar

from allure import step

from ..contracts import (
    ExecutionOutcome,
    MemoryStore,
    ResultT,
    RetryConfigMap,
    capture_outcome,
)
from ..json_types import to_json_value
from ..utils.artifacts import RuntimeArtifacts, artifacts_dir, runtime_artifact_url
from ..utils.metrics import metrics
from ..utils.path import extract_by_path
from ..utils.retry import RetryPolicy
from ..utils.taas_integration import publish_taas_event

if TYPE_CHECKING:
    from ..persona import Persona

logger = logging.getLogger(__name__)

BaseStepT = TypeVar("BaseStepT", bound="BaseStep[object]")
BASE_STEP_RETRY_POLICY = RetryPolicy(max_attempts=1)


class _SupportsRetryConfig(Protocol):
    retries_config: RetryConfigMap | None


class _SupportsMemoryStore(Protocol):
    memory: MemoryStore


class BaseStep(Generic[ResultT], ABC):
    """Единый базовый класс для всех исполняемых компонентов."""

    # Политика ретраев компонента, если конкретный шаг хочет переопределить базовый контракт.
    retry_policy: RetryPolicy | None = None
    # Должна существовать даже у наследников, которые не вызывают BaseStep.__init__.
    _instance_retry_policy: RetryPolicy | None = None
    # Явный базовый контракт для шагов без локальной и глобальной конфигурации.
    default_retry_policy: RetryPolicy = BASE_STEP_RETRY_POLICY

    def __init__(self, *args: object, **kwargs: object) -> None:
        self._instance_retry_policy: RetryPolicy | None = None

    def __repr__(self) -> str:
        params = {k: v for k, v in self.__dict__.items() if not k.startswith("_")}
        param_str = ", ".join(f"{k}={v!r}" for k, v in params.items())
        return f"{self.__class__.__name__}({param_str})"

    def with_retry(self: BaseStepT, policy: RetryPolicy) -> BaseStepT:
        """
        Возвращает копию шага с установленной политикой ретраев.
        Полезно для ad-hoc настройки надежности в конкретном сценарии.
        """
        import copy

        new_step = copy.copy(self)
        new_step._instance_retry_policy = policy
        return new_step

    def _get_effective_retry_policy(self, persona: _SupportsRetryConfig) -> RetryPolicy:
        """Определяет актуальную политику ретраев."""
        instance_policy = self._instance_retry_policy
        if instance_policy is not None:
            return instance_policy

        class_policy = self.__class__.__dict__.get("retry_policy")
        if isinstance(class_policy, RetryPolicy):
            return class_policy

        if class_policy is not None:
            raise TypeError(
                f"Атрибут retry_policy класса {self.__class__.__name__} должен быть RetryPolicy."
            )

        if persona.retries_config:
            default_cfg = persona.retries_config.get("default")
            if default_cfg is not None:
                return RetryPolicy(**default_cfg)

        return self.default_retry_policy

    def _get_component_type(self) -> str:
        """
        Определяет тип компонента на основе иерархии классов.
        """
        # Локальные импорты для разрыва циклической зависимости
        from .goal import Goal
        from .fact import Fact
        from .action import Action
        from .expectation import Expectation
        from .combined_step import CombinedStep
        from .step import Step
        from .ops import Ops

        if isinstance(self, Goal):
            return "goal"
        if isinstance(self, Fact):
            return "fact"
        if isinstance(self, Action):
            return "action"
        if isinstance(self, Expectation):
            return "check"
        if isinstance(self, CombinedStep):
            return "combined_step"
        if isinstance(self, Step):
            return "step"
        if isinstance(self, Ops):
            comp_type = getattr(self, "_component_type", None)
            if isinstance(comp_type, str):
                return comp_type
            return "ops"
        return "unknown"

    def _get_runtime_artifacts(
        self,
        value: object,
        timestamp: float,
    ) -> RuntimeArtifacts:
        """
        Возвращает runtime-артефакты, которые компонент хочет показать в TaaS.

        По умолчанию результат шага не считается артефактом. Компонент должен
        явно объявить screenshot/snapshot, если это часть его контракта.
        """
        return RuntimeArtifacts()

    def execute(self, persona: Persona, *args: object, **kwargs: object) -> ResultT:
        """
        Универсальная обертка для выполнения шага с поддержкой ретраев.
        """
        description = self._get_step_description(persona)
        start_time = time.time()
        component_type = self._get_component_type()
        policy = self._get_effective_retry_policy(persona)

        params = {k: v for k, v in self.__dict__.items() if not k.startswith("_")}
        publish_taas_event(
            {
                "event": "step_start",
                "type": component_type,
                "data": {
                    "description": description,
                    "timestamp": start_time,
                    "component_name": self.__class__.__name__,
                    "component_params": params,
                    "max_attempts": policy.max_attempts,
                },
            }
        )

        value: object | None = None
        status = "passed"
        attempt = 0
        execution_outcome: ExecutionOutcome[ResultT] = ExecutionOutcome[ResultT]()

        try:
            retry_outcome, attempt = self._execute_with_retry(
                persona,
                policy,
                description,
                *args,
                **kwargs,
            )
            execution_outcome = (
                retry_outcome
                if retry_outcome.failed
                else capture_outcome(
                    lambda: self._bind_execution_value(
                        persona,
                        retry_outcome.require_value(),
                    )
                )
            )
            status = "passed" if execution_outcome.succeeded else "failed"
            if execution_outcome.failed:
                raise execution_outcome.require_error()
            result = execution_outcome.require_value()
            value = result
            return result
        finally:
            end_time = time.time()
            duration = end_time - start_time
            metrics.gauge(
                "step.duration",
                duration,
                tags={
                    "type": component_type,
                    "name": self.__class__.__name__,
                    "status": status,
                },
            )

            event_data_end: dict[str, object] = {
                "description": description,
                "timestamp": end_time,
                "duration": duration,
                "status": status,
                "attempts_used": attempt,
            }

            result_raw: object | None = None
            result_raw_path: str | None = None
            result_raw_url: str | None = None
            result_screenshot_path: str | None = None
            result_screenshot_url: str | None = None
            result_snapshot_path: str | None = None
            result_snapshot_url: str | None = None
            should_capture_raw = isinstance(value, (dict, list, tuple)) or (
                is_dataclass(value) and not isinstance(value, type)
            )
            if should_capture_raw:
                raw_dir = artifacts_dir("result_raw")
                filename = f"{int(end_time * 1000)}-{self.__class__.__name__}.json"
                file_path = raw_dir / filename
                try:
                    result_raw = to_json_value(value)
                    with open(file_path, "w", encoding="utf-8") as f:
                        json.dump(result_raw, f, ensure_ascii=False, indent=2)
                    result_raw_path = str(file_path)
                    result_raw_url = runtime_artifact_url("result_raw", filename)
                except (IOError, TypeError) as e:
                    logger.warning(
                        f"Не удалось сохранить result_raw артефакт в {file_path}: {e}"
                    )
                    result_raw = None
            else:
                try:
                    runtime_artifacts = self._get_runtime_artifacts(value, end_time)
                except (OSError, TypeError, ValueError) as error:
                    logger.warning(
                        "Не удалось подготовить runtime-артефакты для %s: %s",
                        self.__class__.__name__,
                        error,
                    )
                    runtime_artifacts = RuntimeArtifacts()

                result_screenshot_path = runtime_artifacts.screenshot_path
                result_screenshot_url = runtime_artifacts.screenshot_url
                result_snapshot_path = runtime_artifacts.snapshot_path
                result_snapshot_url = runtime_artifacts.snapshot_url

            event_data_end.update(
                {
                    "result": str(value)[:100] if value is not None else "None",
                    "result_raw": result_raw,
                    "bindings": {
                        "save_as": getattr(self, "save_as", None),
                        "extract": getattr(self, "extract", None),
                    },
                    "result_raw_path": result_raw_path,
                    "result_raw_url": result_raw_url,
                    "result_screenshot_path": result_screenshot_path,
                    "result_screenshot_url": result_screenshot_url,
                    "result_snapshot_path": result_snapshot_path,
                    "result_snapshot_url": result_snapshot_url,
                }
            )

            publish_taas_event(
                {
                    "event": "step_end",
                    "type": component_type,
                    "data": event_data_end,
                }
            )

    def _capture_attempt(
        self,
        persona: Persona,
        policy: RetryPolicy,
        description: str,
        attempt: int,
        *args: object,
        **kwargs: object,
    ) -> ExecutionOutcome[ResultT]:
        def _run_attempt() -> ResultT:
            with step(
                description if attempt == 1 else f"{description} (попытка {attempt})"
            ):
                if attempt > 1 and policy.on_retry_action:
                    with step("Предварительное действие перед повтором"):
                        policy.execute_action()
                return self._perform(persona, *args, **kwargs)

        return capture_outcome(_run_attempt)

    def _execute_with_retry(
        self,
        persona: Persona,
        policy: RetryPolicy,
        description: str,
        *args: object,
        **kwargs: object,
    ) -> tuple[ExecutionOutcome[ResultT], int]:
        attempt = 0
        last_outcome: ExecutionOutcome[ResultT] = ExecutionOutcome[ResultT]()

        while True:
            attempt += 1
            last_outcome = self._capture_attempt(
                persona,
                policy,
                description,
                attempt,
                *args,
                **kwargs,
            )
            if last_outcome.succeeded:
                return last_outcome, attempt

            error = last_outcome.require_error()
            if not policy.should_retry(attempt, error):
                return last_outcome, attempt

            logger.warning(
                "Шаг '%s' упал (попытка %s/%s): %s. Ретрай через %sс.",
                description,
                attempt,
                policy.max_attempts,
                error,
                policy.delay,
            )
            policy.wait(attempt)

    def _bind_execution_value(
        self,
        persona: _SupportsMemoryStore,
        value: ResultT,
    ) -> ResultT:
        save_as = getattr(self, "save_as", None)
        extract = getattr(self, "extract", None)
        if save_as is not None and not isinstance(save_as, str):
            raise TypeError("Атрибут 'save_as' должен быть строкой.")
        if extract is not None and not isinstance(extract, str):
            raise TypeError("Атрибут 'extract' должен быть строкой.")
        if save_as is not None:
            bound_value = (
                extract_by_path(value, extract) if extract is not None else value
            )
            persona.memory[save_as] = bound_value

        if value is not None:
            with step(f"Получено значение: {str(value)[:100]}"):
                pass

        return value

    @abstractmethod
    def _get_step_description(self, persona: Persona) -> str:
        """Возвращает текстовое описание шага для Allure."""
        ...

    def make(self, persona: Persona) -> None:
        """
        Метод для story-стиля (Persona.make).
        По умолчанию просто вызывает execute.
        """
        self.execute(persona)

    @abstractmethod
    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> ResultT:
        """Содержит реальную логику выполнения шага."""
        ...
