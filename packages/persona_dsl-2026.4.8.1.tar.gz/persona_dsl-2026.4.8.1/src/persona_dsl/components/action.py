from .step import Step


class Action(Step[None]):
    """
    Алиас для Step, предназначенный для story-стиля.
    Не содержит собственной логики.
    """

    pass
