from .combined_step import CombinedStep


class Goal(CombinedStep[None]):
    """
    Алиас для CombinedStep, предназначенный для story-стиля.
    Не содержит собственной логики.
    """

    pass
