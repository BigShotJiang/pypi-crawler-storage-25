from ..contracts import ResultT
from .base_step import BaseStep


class Ops(BaseStep[ResultT]):
    """Базовый класс для всех низкоуровневых, исполняемых операций."""

    pass
