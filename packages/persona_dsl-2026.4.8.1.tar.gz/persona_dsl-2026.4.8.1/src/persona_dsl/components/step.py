from __future__ import annotations

from collections.abc import Generator
from typing import TYPE_CHECKING

from ..contracts import ResultT
from .base_step import BaseStep

if TYPE_CHECKING:
    from ..persona import Persona


class Step(BaseStep[ResultT]):
    """
    Базовый класс для доменно-ориентированных шагов (Steps),
    которые инкапсулируют бизнес-логику и состоят из последовательности
    низкоуровневых операций (Ops), управляемых через генератор.

    Предоставляет универсальные методы-обёртки для разных стилей написания:
    - perform_as(persona): story-стиль для действий
    - get(persona): story-стиль для фактов (возвращает значение)
    - check(persona, actual_value): story-стиль для проверок

    Основной контракт — реализация генераторного метода _run(), который
    позволяет описывать как простые последовательности Ops, так и сложную
    логику с передачей результатов между операциями.
    """

    def perform_as(self, persona: Persona) -> None:
        self.execute(persona)

    def get(self, persona: Persona) -> ResultT:
        return self.execute(persona)

    def check(self, persona: Persona, actual_value: object) -> None:
        self.execute(persona, actual_value)

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> ResultT:
        """
        Исполняет генераторный сценарий из `_run`, передавая результаты
        выполнения Ops обратно в генератор.
        """
        from .ops import Ops

        gen = self._run(persona, *args, **kwargs)
        try:
            # Первый вызов для запуска генератора и получения первой операции
            op_to_execute = gen.send(None)
            while True:
                # Проверяем, что из Step yield'ят только Ops
                if not isinstance(op_to_execute, Ops):
                    raise TypeError(
                        f"Компонент '{self.__class__.__name__}' (наследник Step) "
                        f"может yield'ить только объекты-наследники Ops, "
                        f"но был получен объект типа {type(op_to_execute).__name__}."
                    )

                # Выполняем полученную операцию
                current_result = op_to_execute.execute(persona)
                # Отправляем результат обратно в генератор и получаем следующую операцию
                op_to_execute = gen.send(current_result)
        except StopIteration as e:
            # Генератор завершился (оператором return), его результат в e.value
            result: ResultT = e.value
            return result

    def _run(
        self, persona: Persona, *args: object, **kwargs: object
    ) -> Generator[object, object, ResultT]:
        """
        Декларативно-императивный контракт.
        Yield'ит последовательность Ops и явно возвращает результат.

        По умолчанию выбрасывает NotImplementedError. Наследники должны либо:
        1. Реализовать этот метод (генераторный стиль).
        2. Переопределить _perform (императивный стиль).
        """
        raise NotImplementedError(
            f"Класс {self.__class__.__name__} должен реализовать метод '_run' (генераторный стиль) "
            f"или переопределить метод '_perform' (императивный стиль)."
        )
        # Этот yield нужен, чтобы Python считал метод генератором (даже если он сразу падает)
        # Это важно для статических анализаторов и некоторых проверок.
        if False:
            yield
