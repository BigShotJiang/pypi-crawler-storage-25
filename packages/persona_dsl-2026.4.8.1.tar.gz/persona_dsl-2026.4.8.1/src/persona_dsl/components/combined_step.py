from __future__ import annotations

from abc import abstractmethod
from collections.abc import Generator
from typing import TYPE_CHECKING

from ..contracts import ResultT
from .base_step import BaseStep

if TYPE_CHECKING:
    from ..persona import Persona


class CombinedStep(BaseStep[ResultT]):
    """
    Базовый класс для высокоуровневого, композитного шага (Combined Step),
    который объединяет последовательность других шагов (Steps) для достижения
    бизнес-цели. Управляется через генератор.

    Также предоставляет метод make(persona) для story-стиля, который
    просто вызывает execute(persona) без добавления логики.

    Основной контракт — реализация генераторного метода _run(), который
    позволяет описывать как простые последовательности Steps, так и сложную
    логику с передачей результатов между ними.
    """

    def make(self, persona: Persona) -> None:
        self.execute(persona)

    def _perform(self, persona: Persona, *args: object, **kwargs: object) -> ResultT:
        """
        Исполняет генераторный сценарий из `_run`, передавая результаты
        выполнения Steps обратно в генератор.
        """
        from .step import Step

        gen = self._run(persona, *args, **kwargs)
        try:
            # Первый вызов для запуска генератора и получения первого шага
            step_to_execute = gen.send(None)
            while True:
                # Проверяем, что из CombinedStep не yield'ят низко-уровневые Ops
                if not isinstance(step_to_execute, (Step, CombinedStep)):
                    raise TypeError(
                        f"Компонент '{self.__class__.__name__}' (наследник CombinedStep) "
                        f"может yield'ить только другие шаги (наследники Step/CombinedStep), "
                        f"но был получен объект типа {type(step_to_execute).__name__}."
                    )

                # Выполняем полученный шаг
                last_result = step_to_execute.execute(persona)
                # Отправляем результат обратно в генератор и получаем следующий шаг
                step_to_execute = gen.send(last_result)
        except StopIteration as e:
            # Генератор завершился (оператором return), его результат в e.value
            result: ResultT = e.value
            return result
        raise RuntimeError("CombinedStep._perform завершился без результата.")

    @abstractmethod
    def _get_step_description(self, persona: Persona) -> str:
        """Возвращает текстовое описание шага для Allure."""
        ...

    @abstractmethod
    def _run(
        self, persona: Persona, *args: object, **kwargs: object
    ) -> Generator[object, object, ResultT]:
        """
        Декларативно-императивный контракт.
        Yield'ит последовательность Steps и явно возвращает результат.
        """
        raise NotImplementedError(
            f"Класс {self.__class__.__name__} должен реализовать метод '_run'."
        )
        if False:
            yield
