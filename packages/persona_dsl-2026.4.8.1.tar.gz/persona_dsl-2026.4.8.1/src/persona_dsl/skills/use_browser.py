from pathlib import Path

from playwright.sync_api import Error as PlaywrightError, Page

from .core.base import Skill


class UseBrowser(Skill[Page]):
    """Навык, который предоставляет доступ к драйверу страницы Playwright.

    Хранит и применяет глобальные настройки таймаутов страницы:
      - default_timeout: общий таймаут ожиданий (мс) для всех операций
      - default_navigation_timeout: таймаут навигации/загрузки (мс)
      - inject_runtime: автоматически внедрять Persona Runtime JS (по умолчанию True)
    """

    def __init__(
        self,
        page: Page,
        base_url: str | None = None,
        default_timeout: float | None = None,
        default_navigation_timeout: float | None = None,
        inject_runtime: bool = True,
    ) -> None:
        super().__init__(page)
        self.base_url = base_url
        self._default_timeout = default_timeout
        self._default_navigation_timeout = default_navigation_timeout
        self._inject_runtime = inject_runtime

        # Применяем таймауты к странице, если заданы
        if self._default_timeout is not None:
            page.set_default_timeout(float(self._default_timeout))
        if self._default_navigation_timeout is not None:
            page.set_default_navigation_timeout(float(self._default_navigation_timeout))

        if self._inject_runtime:
            self._inject_persona_runtime(page)

    def _inject_persona_runtime(self, page: Page) -> None:
        """Внедряет JS-ядро Persona Runtime на страницу."""
        current_dir = Path(__file__).parent
        bundle_path = current_dir.parent / "runtime" / "dist" / "persona_bundle.js"
        if not bundle_path.is_file():
            raise FileNotFoundError(
                f"Persona Runtime bundle not found at {bundle_path}"
            )

        try:
            js_content = bundle_path.read_text(encoding="utf-8")
        except OSError as exc:
            raise RuntimeError(
                f"Не удалось прочитать Persona Runtime bundle {bundle_path}: {exc}"
            ) from exc

        page.add_init_script(js_content)
        try:
            page.evaluate(js_content)
        except PlaywrightError as exc:
            raise RuntimeError(
                f"Не удалось внедрить Persona Runtime в текущую страницу: {exc}"
            ) from exc

    @property
    def page(self) -> Page:
        driver = self.driver
        if driver is None:
            raise RuntimeError("Активная страница браузера не инициализирована.")
        return driver

    def switch_active_page(self, new_page: Page) -> None:
        """Меняет активную страницу (вкладку) и применяет необходимые настройки."""
        self.driver = new_page

        if self._default_timeout is not None:
            new_page.set_default_timeout(float(self._default_timeout))
        if self._default_navigation_timeout is not None:
            new_page.set_default_navigation_timeout(
                float(self._default_navigation_timeout)
            )

        if self._inject_runtime:
            self._inject_persona_runtime(new_page)

        # Bring tab to front physically if needed
        new_page.bring_to_front()

    @classmethod
    def from_page(
        cls,
        page: Page,
        base_url: str | None = None,
        default_timeout: float | None = None,
        default_navigation_timeout: float | None = None,
        inject_runtime: bool = True,
    ) -> "UseBrowser":
        return cls(
            page,
            base_url=base_url,
            default_timeout=default_timeout,
            default_navigation_timeout=default_navigation_timeout,
            inject_runtime=inject_runtime,
        )
