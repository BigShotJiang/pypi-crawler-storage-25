from __future__ import annotations

from typing import Protocol

from zeep import Client

from .core.base import Skill


class SoapOperation(Protocol):
    def __call__(self, *args: object, **kwargs: object) -> object: ...


class UseSOAP(Skill[Client]):
    """Навык для взаимодействия с SOAP API."""

    def __init__(self, wsdl_url: str):
        super().__init__(driver=None)
        self.wsdl_url = wsdl_url

    @staticmethod
    def at(wsdl_url: str) -> "UseSOAP":
        """Фабричный метод для создания экземпляра навыка.

        Args:
            wsdl_url: URL к WSDL-файлу сервиса.

        Returns:
            Экземпляр UseSOAP.
        """
        return UseSOAP(wsdl_url)

    def _get_client(self) -> Client:
        if self.driver is None:
            self.driver = Client(self.wsdl_url)
        return self.driver

    def call(
        self,
        service: str,
        operation: str,
        *args: object,
        **kwargs: object,
    ) -> object:
        """Вызывает операцию SOAP-сервиса."""
        client = self._get_client()

        if service not in client.wsdl.services:
            raise ValueError(
                f"Сервис '{service}' не найден в WSDL. Доступные: {list(client.wsdl.services.keys())}"
            )

        # Bind to the service, letting zeep choose the first available port.
        bound_service = client.bind(service, None)
        operation_callable = getattr(bound_service, operation, None)
        if operation_callable is None:
            raise ValueError(
                f"Операция '{operation}' не найдена в сервисе '{service}'."
            )
        if not callable(operation_callable):
            raise TypeError(
                f"Атрибут '{operation}' сервиса '{service}' не является вызываемой SOAP-операцией."
            )
        typed_operation: SoapOperation = operation_callable
        return typed_operation(*args, **kwargs)

    def release(self) -> None:
        """Освобождает ресурсы SOAP-клиента (если они есть)."""
        if self.driver is None:
            return
        transport = getattr(self.driver, "transport", None)
        if transport is None:
            return
        session = getattr(transport, "session", None)
        if session is None:
            return
        close_method = getattr(session, "close", None)
        if close_method is None:
            raise TypeError("SOAP session не поддерживает close().")
        if not callable(close_method):
            raise TypeError("SOAP session.close должен быть вызываемым объектом.")
        close_method()

    def forget(self) -> None:
        """Совместимость: делегирует в базовый Skill.forget()."""
        super().forget()
