from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from typing import NoReturn, Protocol, TypeAlias, TypeVar, overload, runtime_checkable

import allure
import requests
import time
from pydantic import TypeAdapter, ValidationError
from persona_dsl.utils.metrics import metrics
from .core.base import Skill

ResponseModelT = TypeVar("ResponseModelT")


@runtime_checkable
class SupportsModelDump(Protocol):
    def model_dump(self) -> object: ...


@runtime_checkable
class ReadableStream(Protocol):
    def read(self, size: int = -1, /) -> str | bytes: ...


RequestScalar: TypeAlias = str | bytes | int | float
RequestParamValue: TypeAlias = (
    RequestScalar | list[RequestScalar] | tuple[RequestScalar, ...] | None
)
RequestParams: TypeAlias = (
    dict[RequestScalar, RequestParamValue]
    | tuple[RequestScalar, RequestParamValue]
    | list[tuple[RequestScalar, RequestParamValue]]
    | str
    | bytes
)
RequestData: TypeAlias = (
    list[bytes]
    | str
    | bytes
    | ReadableStream
    | list[tuple[object, object]]
    | tuple[tuple[object, object], ...]
    | dict[object, object]
)
RequestHeaders: TypeAlias = dict[str, str | bytes | None]
RequestCookies: TypeAlias = requests.cookies.RequestsCookieJar | dict[str, str]
RequestFileContent: TypeAlias = ReadableStream | str | bytes
RequestFileSpec: TypeAlias = (
    RequestFileContent
    | tuple[str | None, RequestFileContent]
    | tuple[str | None, RequestFileContent, str]
    | tuple[str | None, RequestFileContent, str, dict[str, str]]
)
RequestFiles: TypeAlias = dict[str, RequestFileSpec] | list[tuple[str, RequestFileSpec]]
RequestAuth: TypeAlias = (
    tuple[str, str]
    | requests.auth.AuthBase
    | Callable[[requests.PreparedRequest], requests.PreparedRequest]
)
RequestHook: TypeAlias = Callable[[requests.Response], object]
RequestHooks: TypeAlias = dict[str, list[RequestHook] | RequestHook]
RequestProxies: TypeAlias = dict[str, str]
RequestTimeout: TypeAlias = float | tuple[float | None, float | None]
RequestVerify: TypeAlias = bool | str
RequestCert: TypeAlias = str | tuple[str, str]
RequestJsonScalar: TypeAlias = str | int | float | bool | None
RequestJson: TypeAlias = (
    RequestJsonScalar | list["RequestJson"] | dict[str, "RequestJson"]
)
RequestBody: TypeAlias = RequestJson | RequestData
ALLOWED_REQUEST_OPTION_NAMES = frozenset(
    {
        "params",
        "data",
        "headers",
        "cookies",
        "files",
        "auth",
        "timeout",
        "allow_redirects",
        "proxies",
        "hooks",
        "stream",
        "verify",
        "cert",
        "json",
    }
)


@dataclass(slots=True)
class RequestOptions:
    params: RequestParams | None = None
    data: RequestData | None = None
    headers: RequestHeaders | None = None
    cookies: RequestCookies | None = None
    files: RequestFiles | None = None
    auth: RequestAuth | None = None
    timeout: RequestTimeout | None = None
    allow_redirects: bool = True
    proxies: RequestProxies | None = None
    hooks: RequestHooks | None = None
    stream: bool | None = None
    verify: RequestVerify | None = None
    cert: RequestCert | None = None
    json: RequestJson | None = None

    @property
    def body(self) -> RequestBody | None:
        if self.json is not None:
            return self.json
        return self.data

    @classmethod
    def from_kwargs(
        cls,
        raw_kwargs: Mapping[str, object],
        *,
        default_timeout: float,
    ) -> RequestOptions:
        unknown_names = sorted(set(raw_kwargs) - ALLOWED_REQUEST_OPTION_NAMES)
        if unknown_names:
            unknown_values = ", ".join(unknown_names)
            raise TypeError(f"Неизвестные параметры HTTP-запроса: {unknown_values}.")

        options = cls(timeout=_timeout_value(default_timeout))
        if "params" in raw_kwargs:
            options.params = _params_value(raw_kwargs["params"])
        if "data" in raw_kwargs:
            options.data = _data_value(raw_kwargs["data"])
        if "headers" in raw_kwargs:
            options.headers = _headers_value(
                raw_kwargs["headers"], field_name="headers"
            )
        if "cookies" in raw_kwargs:
            options.cookies = _cookies_value(raw_kwargs["cookies"])
        if "files" in raw_kwargs:
            options.files = _files_value(raw_kwargs["files"])
        if "auth" in raw_kwargs:
            options.auth = _auth_value(raw_kwargs["auth"])
        if "timeout" in raw_kwargs:
            options.timeout = _timeout_value(raw_kwargs["timeout"])
        if "allow_redirects" in raw_kwargs:
            options.allow_redirects = _bool_value(
                raw_kwargs["allow_redirects"],
                field_name="allow_redirects",
            )
        if "proxies" in raw_kwargs:
            options.proxies = _proxies_value(raw_kwargs["proxies"])
        if "hooks" in raw_kwargs:
            options.hooks = _hooks_value(raw_kwargs["hooks"])
        if "stream" in raw_kwargs:
            options.stream = _optional_bool_value(
                raw_kwargs["stream"], field_name="stream"
            )
        if "verify" in raw_kwargs:
            options.verify = _verify_value(raw_kwargs["verify"])
        if "cert" in raw_kwargs:
            options.cert = _cert_value(raw_kwargs["cert"])
        if "json" in raw_kwargs:
            options.json = _json_value(raw_kwargs["json"], field_name="json")
        return options


@dataclass(slots=True)
class RequestFailure:
    error: requests.RequestException

    def reraise(self) -> NoReturn:
        raise self.error


def _to_request_payload(value: object) -> object:
    if isinstance(value, SupportsModelDump):
        return _to_request_payload(value.model_dump())
    if isinstance(value, dict):
        return {key: _to_request_payload(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_request_payload(item) for item in value]
    return value


def _headers_value(
    value: object,
    *,
    field_name: str,
) -> RequestHeaders | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise TypeError(f"{field_name} должны быть отображением заголовков.")
    normalized_headers: RequestHeaders = {}
    for key, item in value.items():
        if not isinstance(key, str):
            raise TypeError(f"{field_name} должны содержать только строковые ключи.")
        if item is not None and not isinstance(item, (str, bytes)):
            raise TypeError(
                f"{field_name}[{key!r}] должен быть строкой, bytes или null."
            )
        normalized_headers[key] = item
    return normalized_headers


def _merge_headers_for_logging(
    session_headers: Mapping[str, str | bytes] | None,
    request_headers: RequestHeaders | None,
) -> RequestHeaders:
    combined_headers: RequestHeaders = {}
    if session_headers is not None:
        combined_headers.update(session_headers)
    if request_headers is not None:
        combined_headers.update(request_headers)
    if "Authorization" in combined_headers:
        combined_headers["Authorization"] = "***"
    return combined_headers


def _bool_value(value: object, *, field_name: str) -> bool:
    if not isinstance(value, bool):
        raise TypeError(f"{field_name} должен быть bool.")
    return value


def _optional_bool_value(value: object, *, field_name: str) -> bool | None:
    if value is None:
        return None
    return _bool_value(value, field_name=field_name)


def _timeout_component(value: object, *, field_name: str) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{field_name} должен быть числом или null.")
    return float(value)


def _timeout_value(value: object) -> RequestTimeout:
    if isinstance(value, tuple):
        if len(value) != 2:
            raise ValueError("timeout-кортеж должен состоять из двух элементов.")
        return (
            _timeout_component(value[0], field_name="timeout[0]"),
            _timeout_component(value[1], field_name="timeout[1]"),
        )
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("timeout должен быть числом или кортежем из двух чисел.")
    return float(value)


def _param_scalar(value: object, *, field_name: str) -> RequestScalar:
    if isinstance(value, bool) or not isinstance(value, (str, bytes, int, float)):
        raise TypeError(f"{field_name} должен быть строкой, bytes, int или float.")
    return value


def _param_value(value: object, *, field_name: str) -> RequestParamValue:
    if value is None:
        return None
    if isinstance(value, bool):
        raise TypeError(f"{field_name} не должен быть bool.")
    if isinstance(value, (str, bytes, int, float)):
        return value
    if not isinstance(value, Iterable):
        raise TypeError(
            f"{field_name} должен быть скаляром, списком скаляров или null."
        )
    normalized_items: list[RequestScalar] = []
    for index, item in enumerate(value):
        normalized_items.append(
            _param_scalar(item, field_name=f"{field_name}[{index}]")
        )
    return normalized_items


def _params_value(value: object) -> RequestParams | None:
    if value is None:
        return None
    if isinstance(value, (str, bytes)):
        return value
    if isinstance(value, Mapping):
        normalized_params: dict[RequestScalar, RequestParamValue] = {}
        for key, item in value.items():
            normalized_key = _param_scalar(key, field_name="params key")
            normalized_params[normalized_key] = _param_value(
                item,
                field_name=f"params[{normalized_key!r}]",
            )
        return normalized_params
    if isinstance(value, tuple) and len(value) == 2:
        return (
            _param_scalar(value[0], field_name="params[0]"),
            _param_value(value[1], field_name="params[1]"),
        )
    if not isinstance(value, Iterable):
        raise TypeError(
            "params должен быть отображением, списком пар, парой, строкой или bytes."
        )
    normalized_pairs: list[tuple[RequestScalar, RequestParamValue]] = []
    for index, item in enumerate(value):
        if not isinstance(item, tuple) or len(item) != 2:
            raise TypeError(f"params[{index}] должен быть кортежем из двух элементов.")
        normalized_pairs.append(
            (
                _param_scalar(item[0], field_name=f"params[{index}][0]"),
                _param_value(item[1], field_name=f"params[{index}][1]"),
            )
        )
    return normalized_pairs


def _json_scalar_value(value: object, *, field_name: str) -> RequestJsonScalar:
    if value is None:
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    raise TypeError(f"{field_name} должен быть JSON-скаляром.")


def _json_value(value: object, *, field_name: str) -> RequestJson | None:
    payload = _to_request_payload(value)
    if payload is None:
        return None
    if isinstance(payload, (str, int, float, bool)):
        return _json_scalar_value(payload, field_name=field_name)
    if isinstance(payload, Mapping):
        normalized_object: dict[str, RequestJson] = {}
        for key, item in payload.items():
            if not isinstance(key, str):
                raise TypeError(
                    f"{field_name} должен содержать только строковые JSON-ключи."
                )
            normalized_object[key] = _json_value(
                item,
                field_name=f"{field_name}.{key}",
            )
        return normalized_object
    if isinstance(payload, list):
        return [
            _json_value(item, field_name=f"{field_name}[{index}]")
            for index, item in enumerate(payload)
        ]
    raise TypeError(f"{field_name} должен быть JSON-совместимым значением.")


def _data_value(value: object) -> RequestData | None:
    payload = _to_request_payload(value)
    if payload is None:
        return None
    if isinstance(payload, (str, bytes, ReadableStream)):
        return payload
    if isinstance(payload, Mapping):
        return dict(payload)
    if isinstance(payload, tuple):
        if all(isinstance(item, tuple) and len(item) == 2 for item in payload):
            return payload
        raise TypeError(
            "data в виде кортежа должен содержать только пары из двух элементов."
        )
    if isinstance(payload, list):
        if all(isinstance(item, bytes) for item in payload):
            return payload
        if all(isinstance(item, tuple) and len(item) == 2 for item in payload):
            return payload
        raise TypeError(
            "data в виде списка должен содержать либо bytes, либо пары из двух элементов."
        )
    raise TypeError(
        "data должен быть строкой, bytes, читаемым потоком, отображением или списком/кортежем допустимых значений."
    )


def _cookies_value(value: object) -> RequestCookies | None:
    if value is None:
        return None
    if isinstance(value, requests.cookies.RequestsCookieJar):
        return value
    if not isinstance(value, Mapping):
        raise TypeError("cookies должны быть отображением строковых cookie.")
    normalized_cookies: dict[str, str] = {}
    for key, item in value.items():
        if not isinstance(key, str) or not isinstance(item, str):
            raise TypeError(
                "cookies должны содержать только строковые пары ключ-значение."
            )
        normalized_cookies[key] = item
    return normalized_cookies


def _file_content_value(value: object, *, field_name: str) -> RequestFileContent:
    if isinstance(value, (str, bytes, ReadableStream)):
        return value
    raise TypeError(f"{field_name} должен быть bytes, строкой или читаемым потоком.")


def _file_headers_value(value: object, *, field_name: str) -> dict[str, str]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{field_name} должны быть отображением строковых заголовков.")
    normalized_headers: dict[str, str] = {}
    for key, item in value.items():
        if not isinstance(key, str) or not isinstance(item, str):
            raise TypeError(f"{field_name} должны содержать только строки.")
        normalized_headers[key] = item
    return normalized_headers


def _file_spec_value(value: object, *, field_name: str) -> RequestFileSpec:
    if isinstance(value, (str, bytes, ReadableStream)):
        return value
    if not isinstance(value, tuple):
        raise TypeError(
            f"{field_name} должен быть файлом или кортежем параметров файла."
        )
    if len(value) == 2:
        filename, content = value
        if filename is not None and not isinstance(filename, str):
            raise TypeError(f"{field_name}[0] должен быть строкой или null.")
        return (
            filename,
            _file_content_value(content, field_name=f"{field_name}[1]"),
        )
    if len(value) == 3:
        filename, content, content_type = value
        if filename is not None and not isinstance(filename, str):
            raise TypeError(f"{field_name}[0] должен быть строкой или null.")
        if not isinstance(content_type, str):
            raise TypeError(f"{field_name}[2] должен быть строкой content-type.")
        return (
            filename,
            _file_content_value(content, field_name=f"{field_name}[1]"),
            content_type,
        )
    if len(value) == 4:
        filename, content, content_type, headers = value
        if filename is not None and not isinstance(filename, str):
            raise TypeError(f"{field_name}[0] должен быть строкой или null.")
        if not isinstance(content_type, str):
            raise TypeError(f"{field_name}[2] должен быть строкой content-type.")
        return (
            filename,
            _file_content_value(content, field_name=f"{field_name}[1]"),
            content_type,
            _file_headers_value(headers, field_name=f"{field_name}[3]"),
        )
    raise TypeError(f"{field_name} должен быть кортежем длины 2, 3 или 4.")


def _files_value(value: object) -> RequestFiles | None:
    if value is None:
        return None
    if isinstance(value, Mapping):
        normalized_files: dict[str, RequestFileSpec] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError("files должны содержать только строковые ключи.")
            normalized_files[key] = _file_spec_value(
                item,
                field_name=f"files[{key!r}]",
            )
        return normalized_files
    if not isinstance(value, Iterable):
        raise TypeError("files должны быть отображением или списком пар.")
    normalized_pairs: list[tuple[str, RequestFileSpec]] = []
    for index, item in enumerate(value):
        if not isinstance(item, tuple) or len(item) != 2:
            raise TypeError(f"files[{index}] должен быть парой (name, spec).")
        name, spec = item
        if not isinstance(name, str):
            raise TypeError(f"files[{index}][0] должен быть строкой.")
        normalized_pairs.append(
            (
                name,
                _file_spec_value(spec, field_name=f"files[{index}][1]"),
            )
        )
    return normalized_pairs


def _auth_value(value: object) -> RequestAuth | None:
    if value is None:
        return None
    if isinstance(value, tuple):
        if len(value) != 2:
            raise TypeError("auth-кортеж должен содержать логин и пароль.")
        username, password = value
        if not isinstance(username, str) or not isinstance(password, str):
            raise TypeError("auth-кортеж должен содержать только строки.")
        return (username, password)
    if isinstance(value, requests.auth.AuthBase):
        return value
    if callable(value):
        return value
    raise TypeError("auth должен быть кортежем, AuthBase или вызываемым объектом.")


def _proxies_value(value: object) -> RequestProxies | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise TypeError("proxies должны быть отображением строковых значений.")
    normalized_proxies: dict[str, str] = {}
    for key, item in value.items():
        if not isinstance(key, str) or not isinstance(item, str):
            raise TypeError("proxies должны содержать только строки.")
        normalized_proxies[key] = item
    return normalized_proxies


def _hooks_value(value: object) -> RequestHooks | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise TypeError("hooks должны быть отображением.")
    normalized_hooks: RequestHooks = {}
    for key, item in value.items():
        if not isinstance(key, str):
            raise TypeError("hooks должны содержать только строковые ключи.")
        if callable(item):
            normalized_hooks[key] = item
            continue
        if not isinstance(item, Iterable):
            raise TypeError(
                f"hooks[{key!r}] должен быть callable или итерируемым набором callable."
            )
        hook_list: list[RequestHook] = []
        for index, hook in enumerate(item):
            if not callable(hook):
                raise TypeError(f"hooks[{key!r}][{index}] должен быть callable.")
            hook_list.append(hook)
        normalized_hooks[key] = hook_list
    return normalized_hooks


def _verify_value(value: object) -> RequestVerify | None:
    if value is None:
        return None
    if not isinstance(value, (bool, str)):
        raise TypeError("verify должен быть bool или строковым путём к сертификату.")
    return value


def _cert_value(value: object) -> RequestCert | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    if isinstance(value, tuple) and len(value) == 2:
        cert_path, key_path = value
        if not isinstance(cert_path, str) or not isinstance(key_path, str):
            raise TypeError("cert-кортеж должен содержать только строки.")
        return (cert_path, key_path)
    raise TypeError("cert должен быть строкой или кортежем из двух строк.")


class UseAPI(Skill[requests.Session]):
    """Навык для взаимодействия с REST API."""

    def __init__(
        self,
        session: requests.Session,
        base_url: str,
        verify_ssl: bool = True,
        timeout: float = 10.0,
        retries: int = 0,
        backoff: float = 0.5,
        log_bodies: bool = False,
    ):
        super().__init__(session)
        self.base_url = base_url
        self.timeout = timeout
        self.retries = retries
        self.backoff = backoff
        self.log_bodies = log_bodies

    @classmethod
    def at(
        cls,
        base_url: str,
        verify_ssl: bool = True,
        timeout: float = 10.0,
        retries: int = 0,
        backoff: float = 0.5,
        log_bodies: bool = False,
        default_headers: Mapping[str, str] | None = None,
    ) -> "UseAPI":
        session = requests.Session()
        session.verify = verify_ssl
        if default_headers:
            session.headers.update(dict(default_headers))
        inst = cls(session, base_url, verify_ssl, timeout, retries, backoff, log_bodies)
        return inst

    @property
    def session(self) -> requests.Session:
        session = self.driver
        if session is None:
            raise RuntimeError("HTTP session не инициализирована.")
        return session

    def _full_url(self, path: str) -> str:
        """Строит полный URL из базового и относительного пути."""
        if path.startswith("http://") or path.startswith("https://"):
            return path
        base = self.base_url.rstrip("/")
        rel = path if path.startswith("/") else f"/{path}"
        return f"{base}{rel}"

    def _request(self, method: str, path: str, **kwargs: object) -> requests.Response:
        """Обертка над requests с метриками, ретраями и опциональными вложениями в Allure."""
        url = self._full_url(path)
        status: int | None = None
        t0 = time.perf_counter()
        attempts = self.retries + 1
        request_options = RequestOptions.from_kwargs(
            kwargs, default_timeout=self.timeout
        )
        try:
            for attempt in range(attempts):
                outcome = self._send_request(
                    method=method,
                    url=url,
                    options=request_options,
                )
                if isinstance(outcome, RequestFailure):
                    status = -1
                    if attempt < self.retries:
                        time.sleep(self.backoff * (2**attempt))
                        continue
                    outcome.reraise()
                resp = outcome
                status = resp.status_code
                if 500 <= status < 600 and attempt < self.retries:
                    time.sleep(self.backoff * (2**attempt))
                    continue
                if self.log_bodies:
                    combined_headers = _merge_headers_for_logging(
                        self.session.headers,
                        request_options.headers,
                    )
                    allure.attach(
                        f"Request: {method.upper()} {url}\nheaders={combined_headers!r}\nbody={request_options.body!r}",
                        "HTTP Request",
                        allure.attachment_type.TEXT,
                    )
                    allure.attach(
                        f"Response: status={resp.status_code}\nheaders={dict(resp.headers)}\nbody={resp.text[:1000]}",
                        "HTTP Response",
                        allure.attachment_type.TEXT,
                    )
                return resp
        finally:
            duration = time.perf_counter() - t0
            tags = {"method": method.upper(), "endpoint": path, "status": status}
            metrics.gauge("api.request.duration", duration, tags)
            metrics.counter("api.request", tags).inc()
        # This code should be unreachable, as the loop will always either return a response
        # or raise an exception.
        raise RuntimeError("Unreachable code in UseAPI._request reached")

    def _send_request(
        self,
        *,
        method: str,
        url: str,
        options: RequestOptions,
    ) -> requests.Response | RequestFailure:
        try:
            return self.session.request(
                method=method.upper(),
                url=url,
                params=options.params,
                data=options.data,
                headers=options.headers,
                cookies=options.cookies,
                files=options.files,
                auth=options.auth,
                timeout=options.timeout,
                allow_redirects=options.allow_redirects,
                proxies=options.proxies,
                hooks=options.hooks,
                stream=options.stream,
                verify=options.verify,
                cert=options.cert,
                json=options.json,
            )
        except requests.RequestException as error:
            return RequestFailure(error=error)

    def get(self, path: str, **kwargs: object) -> requests.Response:
        return self._request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: object) -> requests.Response:
        return self._request("POST", path, **kwargs)

    def put(self, path: str, **kwargs: object) -> requests.Response:
        return self._request("PUT", path, **kwargs)

    def patch(self, path: str, **kwargs: object) -> requests.Response:
        return self._request("PATCH", path, **kwargs)

    def head(self, path: str, **kwargs: object) -> requests.Response:
        return self._request("HEAD", path, **kwargs)

    def options(self, path: str, **kwargs: object) -> requests.Response:
        return self._request("OPTIONS", path, **kwargs)

    def delete(self, path: str, **kwargs: object) -> requests.Response:
        return self._request("DELETE", path, **kwargs)

    @overload
    def _validate_as(
        self,
        data: object,
        model_type: type[ResponseModelT],
    ) -> ResponseModelT: ...

    @overload
    def _validate_as(
        self,
        data: object,
        model_type: object,
    ) -> object: ...

    def _validate_as(
        self,
        data: object,
        model_type: object,
    ) -> object:
        """
        Преобразует произвольный JSON в указанный тип с помощью Pydantic v2.
        Поддерживает сложные аннотации (например, list[MyModel]) через TypeAdapter.
        При ошибке валидации выбрасывает исключение с подробной диагностикой (без скрытых фолбеков).
        """
        try:
            return TypeAdapter(model_type).validate_python(data)
        except (ValidationError, TypeError) as e:
            raise ValueError(
                f"Валидация ответа API не прошла для типа {model_type}: {e}"
            ) from e

    @overload
    def get_json_as(
        self,
        path: str,
        model_type: type[ResponseModelT],
        **kwargs: object,
    ) -> ResponseModelT: ...

    @overload
    def get_json_as(
        self, path: str, model_type: object, **kwargs: object
    ) -> object: ...

    def get_json_as(self, path: str, model_type: object, **kwargs: object) -> object:
        """
        Делает GET и валидирует JSON-ответ как указанный тип (Pydantic v2).
        Пример: api.get_json_as('/users/1', User) или api.get_json_as('/users', list[User])
        """
        resp = self.get(path, **kwargs)
        return self._validate_as(resp.json(), model_type)

    @overload
    def post_json_as(
        self,
        path: str,
        model_type: type[ResponseModelT],
        **kwargs: object,
    ) -> ResponseModelT: ...

    @overload
    def post_json_as(
        self, path: str, model_type: object, **kwargs: object
    ) -> object: ...

    def post_json_as(self, path: str, model_type: object, **kwargs: object) -> object:
        """
        Делает POST и валидирует JSON-ответ как указанный тип (Pydantic v2).
        """
        resp = self.post(path, **kwargs)
        return self._validate_as(resp.json(), model_type)

    @overload
    def put_json_as(
        self,
        path: str,
        model_type: type[ResponseModelT],
        **kwargs: object,
    ) -> ResponseModelT: ...

    @overload
    def put_json_as(
        self, path: str, model_type: object, **kwargs: object
    ) -> object: ...

    def put_json_as(self, path: str, model_type: object, **kwargs: object) -> object:
        """
        Делает PUT и валидирует JSON-ответ как указанный тип (Pydantic v2).
        """
        resp = self.put(path, **kwargs)
        return self._validate_as(resp.json(), model_type)

    @overload
    def patch_json_as(
        self,
        path: str,
        model_type: type[ResponseModelT],
        **kwargs: object,
    ) -> ResponseModelT: ...

    @overload
    def patch_json_as(
        self, path: str, model_type: object, **kwargs: object
    ) -> object: ...

    def patch_json_as(self, path: str, model_type: object, **kwargs: object) -> object:
        """
        Делает PATCH и валидирует JSON-ответ как указанный тип (Pydantic v2).
        """
        resp = self.patch(path, **kwargs)
        return self._validate_as(resp.json(), model_type)

    @overload
    def delete_json_as(
        self,
        path: str,
        model_type: type[ResponseModelT],
        **kwargs: object,
    ) -> ResponseModelT: ...

    @overload
    def delete_json_as(
        self, path: str, model_type: object, **kwargs: object
    ) -> object: ...

    def delete_json_as(self, path: str, model_type: object, **kwargs: object) -> object:
        """
        Делает DELETE и валидирует JSON-ответ как указанный тип (Pydantic v2).
        """
        resp = self.delete(path, **kwargs)
        return self._validate_as(resp.json(), model_type)

    @overload
    def head_json_as(
        self,
        path: str,
        model_type: type[ResponseModelT],
        **kwargs: object,
    ) -> ResponseModelT | None: ...

    @overload
    def head_json_as(
        self,
        path: str,
        model_type: object,
        **kwargs: object,
    ) -> object | None: ...

    def head_json_as(
        self, path: str, model_type: object, **kwargs: object
    ) -> object | None:
        """
        Делает HEAD и валидирует JSON-ответ как указанный тип (если сервер всё же возвращает тело).
        Примечание: согласно спецификации, ответ HEAD не должен содержать тело; метод добавлен для полноты API.
        """
        resp = self.head(path, **kwargs)
        # Если тело ответа пустое — это валидный случай для HEAD-запроса.
        if not resp.text:
            return None
        try:
            data = resp.json()
        except requests.JSONDecodeError as e:
            raise ValueError(
                f"HEAD {path}: ответ содержит тело, но оно не является валидным JSON: {e}"
            ) from e
        return self._validate_as(data, model_type)

    @overload
    def options_json_as(
        self,
        path: str,
        model_type: type[ResponseModelT],
        **kwargs: object,
    ) -> ResponseModelT: ...

    @overload
    def options_json_as(
        self,
        path: str,
        model_type: object,
        **kwargs: object,
    ) -> object: ...

    def options_json_as(
        self,
        path: str,
        model_type: object,
        **kwargs: object,
    ) -> object:
        """
        Делает OPTIONS и валидирует JSON-ответ как указанный тип (Pydantic v2).
        """
        resp = self.options(path, **kwargs)
        return self._validate_as(resp.json(), model_type)

    def release(self) -> None:
        """Освобождает ресурсы HTTP-клиента (закрывает Session)."""
        self.session.close()

    def forget(self) -> None:
        """Совместимость: делегирует в базовый Skill.forget()."""
        super().forget()
