from __future__ import annotations

import time
from collections.abc import Sequence
from types import ModuleType
from urllib.parse import urlparse

from typing import Protocol

from persona_dsl.utils.metrics import metrics

from .core.base import Skill


class DatabaseCursor(Protocol):
    def execute(self, query: str, params: object = ()) -> object: ...
    def fetchone(self) -> object | None: ...
    def fetchall(self) -> list[object]: ...
    def close(self) -> None: ...


class DatabaseConnection(Protocol):
    closed: bool | int

    def cursor(self) -> DatabaseCursor: ...
    def commit(self) -> None: ...
    def close(self) -> None: ...
    def is_healthy(self) -> bool: ...


class DatabaseDriver(Protocol):
    __name__: str

    def connect(self, *args: object, **kwargs: object) -> DatabaseConnection: ...


def _database_error_types(
    driver: ModuleType | DatabaseDriver | None,
) -> tuple[type[BaseException], ...]:
    error_types: list[type[BaseException]] = [
        OSError,
        RuntimeError,
        TypeError,
        ValueError,
    ]
    if driver is not None:
        driver_error = getattr(driver, "Error", None)
        if isinstance(driver_error, type) and issubclass(driver_error, BaseException):
            error_types.append(driver_error)
    return tuple(error_types)


class UseDatabase(Skill):
    """Навык для взаимодействия с реляционными базами данных."""

    def __init__(self, dsn: str, driver: ModuleType | DatabaseDriver):
        super().__init__(driver)
        self.dsn = dsn
        self.connection: DatabaseConnection | None = None

    @staticmethod
    def with_dsn(dsn: str, driver: ModuleType | DatabaseDriver) -> "UseDatabase":
        """Фабричный метод для создания экземпляра навыка.

        Args:
            dsn: DSN-строка для подключения к базе данных.
            driver: Модуль-драйвер для работы с БД (например, psycopg или oracledb).

        Returns:
            Экземпляр UseDatabase.
        """
        return UseDatabase(dsn, driver)

    def get_connection(self) -> DatabaseConnection:
        """Возвращает активное соединение с базой данных.

        Если соединение отсутствует или закрыто, создает новое.

        Returns:
            Активное соединение с БД.
        """
        need_reconnect = (
            self.connection is None
            or getattr(self.connection, "closed", False)
            or (
                callable(getattr(self.connection, "is_healthy", None))
                and not self.connection.is_healthy()
            )
        )
        if need_reconnect:
            driver = self.driver
            if driver is None:
                raise RuntimeError("Драйвер базы данных не инициализирован.")
            # Поддерживаем корректные способы подключения драйверов:
            # - pg8000: требуем DSN в URL-формате postgresql://user:pass@host:port/db и конструируем именованные аргументы
            # - psycopg/psycopg2: принимают conninfo строкой (передаём как есть)
            # - oracledb: допускает строку вида "user/password@dsn" как позиционный аргумент
            drv_name = getattr(driver, "__name__", "") or ""
            if drv_name.startswith("pg8000"):
                u = urlparse(self.dsn)
                if u.scheme not in (
                    "postgresql",
                    "postgres",
                    "postgresql+pg8000",
                    "postgres+pg8000",
                ):
                    raise ValueError(
                        "Для драйвера pg8000 DSN должен быть в URL-формате: postgresql://user:pass@host:port/dbname"
                    )
                user = u.username or ""
                password = u.password or ""
                host = u.hostname or ""
                port = int(u.port or 5432)
                db = u.path.lstrip("/") if u.path else ""
                if not (user and host and db):
                    raise ValueError(
                        "pg8000: некорректный DSN URL (требуются user, host, database). Пример: postgresql://user:pass@localhost:5432/db"
                    )
                self.connection = driver.connect(
                    user=user, password=password, host=host, port=port, database=db
                )
            else:
                # Для остальных драйверов используем conninfo/позиционный аргумент согласно их API.
                self.connection = driver.connect(self.dsn)
        if self.connection is None:
            raise RuntimeError("Не удалось установить соединение с базой данных.")
        return self.connection

    def execute(
        self, query: str, params: Sequence[object] | object | None = None
    ) -> object | None:
        """Выполняет SQL-запрос с метриками и возвращает первую строку результата.

        Args:
            query: SQL-запрос.
            params: Параметры запроса.

        Returns:
            Первая строка результата (или None).
        """
        t0 = time.perf_counter()
        status = "ok"
        error_types = _database_error_types(self.driver)
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            try:
                cursor.execute(query, params or ())
                result = cursor.fetchone()
                conn.commit()
                return result
            finally:
                cursor.close()
        except error_types:
            status = "error"
            raise
        finally:
            duration = time.perf_counter() - t0
            driver = self.driver
            driver_name = driver.__name__ if driver is not None else "unknown"
            tags: dict[str, object] = {
                "driver": driver_name,
                "query": query.split()[0].upper() if query else "UNKNOWN",
                "status": status,
            }
            metrics.gauge("db.query.duration", duration, tags)
            metrics.counter("db.query", tags).inc()

    def release(self) -> None:
        """Закрывает соединение с БД, если оно открыто."""
        if self.connection:
            if hasattr(self.connection, "closed"):
                if not self.connection.closed:
                    self.connection.close()
            elif hasattr(self.connection, "close"):  # Для oracledb, где нет closed
                self.connection.close()
            self.connection = None

    def forget(self) -> None:
        """Совместимость: делегирует в базовый Skill.forget()."""
        super().forget()
