from typing import Generic, Self, TypeVar

DriverT = TypeVar("DriverT")


class Skill(Generic[DriverT]):
    """Базовый класс-обертка для навыка, который управляет экземпляром драйвера/клиента."""

    def __init__(self, driver: DriverT | None):
        self.driver = driver

    @property
    def driver(self) -> DriverT | None:
        return self._driver

    @driver.setter
    def driver(self, value: DriverT | None) -> None:
        self._driver = value

    @classmethod
    def from_driver(cls, driver: DriverT) -> Self:
        """Фабричный метод для создания экземпляра Навыка из готового драйвера/клиента."""
        return cls(driver)

    def acquire(self) -> None:
        """Опциональный хук для ленивого создания драйвера."""
        pass

    def release(self) -> None:
        """Опциональный хук для освобождения ресурсов драйвера."""
        pass

    def forget(self) -> None:
        """
        Единая точка освобождения ресурсов навыка.
        По умолчанию делегирует в release() и всегда сбрасывает драйвер.
        Ошибки release не подавляются.
        """
        try:
            self.release()
        finally:
            self.driver = None
