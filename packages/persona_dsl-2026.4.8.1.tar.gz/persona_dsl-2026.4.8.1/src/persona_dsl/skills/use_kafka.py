from __future__ import annotations

import importlib
import logging
from collections.abc import Iterator
from typing import Literal, Protocol, TypedDict, TypeGuard

from .core.base import Skill

logger = logging.getLogger(__name__)


class KafkaFuture(Protocol):
    def get(self, timeout: float | None = None) -> object: ...


class KafkaProducerProtocol(Protocol):
    def send(
        self,
        topic: str,
        *,
        key: bytes | None = None,
        value: bytes,
        headers: list[tuple[str, bytes]],
    ) -> KafkaFuture: ...
    def flush(self, timeout: float | None = None) -> None: ...
    def close(self) -> None: ...


class KafkaMessage(Protocol):
    topic: str
    partition: int
    offset: int
    timestamp: int
    key: bytes | None
    value: bytes | None
    headers: list[tuple[str, bytes]] | None


class KafkaConsumerProtocol(Protocol):
    def __iter__(self) -> Iterator[KafkaMessage]: ...
    def __next__(self) -> KafkaMessage: ...
    def close(self) -> None: ...


class KafkaProducerFactory(Protocol):
    def __call__(self, *, bootstrap_servers: str) -> KafkaProducerProtocol: ...


class KafkaConsumerFactory(Protocol):
    def __call__(
        self,
        topic: str,
        *,
        bootstrap_servers: str,
        group_id: str | None,
        enable_auto_commit: bool,
        auto_offset_reset: Literal["earliest", "latest"],
        consumer_timeout_ms: int,
    ) -> KafkaConsumerProtocol: ...


class KafkaModuleProtocol(Protocol):
    KafkaProducer: KafkaProducerFactory
    KafkaConsumer: KafkaConsumerFactory


class ConsumedKafkaMessage(TypedDict):
    topic: str
    partition: int
    offset: int
    timestamp: int
    key: bytes | None
    value: bytes | None
    headers: dict[str, bytes]


def _is_kafka_module(value: object) -> TypeGuard[KafkaModuleProtocol]:
    return callable(getattr(value, "KafkaProducer", None)) and callable(
        getattr(value, "KafkaConsumer", None)
    )


def _load_kafka_module() -> KafkaModuleProtocol:
    kafka_module = importlib.import_module("kafka")
    if not _is_kafka_module(kafka_module):
        raise TypeError(
            "Модуль kafka должен предоставлять вызываемые KafkaProducer и KafkaConsumer."
        )
    return kafka_module


def _kafka_error_types() -> tuple[type[Exception], ...]:
    error_types: list[type[Exception]] = [
        OSError,
        RuntimeError,
        TypeError,
        ValueError,
    ]
    kafka_module = importlib.import_module("kafka")
    kafka_errors = getattr(kafka_module, "errors", None)
    kafka_error = getattr(kafka_errors, "KafkaError", None)
    if isinstance(kafka_error, type) and issubclass(kafka_error, Exception):
        error_types.insert(0, kafka_error)
    return tuple(error_types)


class UseKafka(Skill):
    """Навык для взаимодействия с Kafka."""

    def __init__(
        self,
        bootstrap_servers: str,
        group_id: str | None = None,
        from_offset: Literal["earliest", "latest"] = "latest",
        timeout: float = 10.0,
    ):
        super().__init__(driver=None)
        self.bootstrap_servers = bootstrap_servers
        self.group_id = group_id
        if from_offset not in ("earliest", "latest"):
            raise ValueError(
                "UseKafka.from_offset должен быть 'earliest' или 'latest'."
            )
        self.from_offset = from_offset
        self.timeout = float(timeout)
        self._producer: KafkaProducerProtocol | None = None
        self._consumer: KafkaConsumerProtocol | None = None

    @staticmethod
    def with_servers(
        bootstrap_servers: str,
        group_id: str | None = None,
        from_offset: Literal["earliest", "latest"] = "latest",
        timeout: float = 10.0,
    ) -> "UseKafka":
        """Фабричный метод для создания экземпляра навыка."""
        return UseKafka(
            bootstrap_servers=bootstrap_servers,
            group_id=group_id,
            from_offset=from_offset,
            timeout=timeout,
        )

    def _get_producer(self) -> KafkaProducerProtocol:
        if self._producer is None:
            kafka_module = _load_kafka_module()
            self._producer = kafka_module.KafkaProducer(
                bootstrap_servers=self.bootstrap_servers
            )
        return self._producer

    def _get_consumer(self, topic: str) -> KafkaConsumerProtocol:
        if self._consumer is None:
            auto_offset_reset = self.from_offset
            consumer_timeout_ms = int(self.timeout * 1000)
            kafka_module = _load_kafka_module()
            self._consumer = kafka_module.KafkaConsumer(
                topic,
                bootstrap_servers=self.bootstrap_servers,
                group_id=self.group_id,
                enable_auto_commit=False,
                auto_offset_reset=auto_offset_reset,
                consumer_timeout_ms=consumer_timeout_ms,
            )
        return self._consumer

    def send_message(
        self,
        topic: str,
        message: bytes,
        key: bytes | None = None,
        headers: list[tuple[str, bytes]] | None = None,
    ) -> None:
        """Отправляет сообщение в указанный топик Kafka."""
        producer = self._get_producer()
        kafka_errors = _kafka_error_types()
        try:
            future = producer.send(topic, key=key, value=message, headers=headers or [])
            future.get(timeout=self.timeout)
            producer.flush(timeout=self.timeout)
        except kafka_errors as error:
            logger.exception(
                "[UseKafka] Ошибка при отправке сообщения в '%s': %s", topic, error
            )
            raise

    def consume(
        self,
        topic: str,
        max_messages: int = 1,
        timeout: float | None = None,
    ) -> list[ConsumedKafkaMessage]:
        """Читает сообщения из топика (до max_messages или до таймаута)."""
        consumer = self._get_consumer(topic)
        results: list[ConsumedKafkaMessage] = []
        end_after = timeout or self.timeout
        import time

        start = time.time()
        while len(results) < max_messages and (time.time() - start) < end_after:
            try:
                msg = next(consumer)
            except StopIteration:
                break
            results.append(
                {
                    "topic": msg.topic,
                    "partition": msg.partition,
                    "offset": msg.offset,
                    "timestamp": msg.timestamp,
                    "key": msg.key,
                    "value": msg.value,
                    "headers": dict(msg.headers or []),
                }
            )
        return results

    def _release_errors(self) -> tuple[type[BaseException], ...]:
        return _kafka_error_types()

    def release(self) -> None:
        """Закрывает все соединения и освобождает ресурсы."""
        errors: list[str] = []

        release_errors = self._release_errors()

        if self._producer is not None:
            try:
                self._producer.flush(timeout=self.timeout)
                self._producer.close()
                self._producer = None
            except release_errors as error:
                errors.append(f"producer: {error}")

        if self._consumer is not None:
            try:
                self._consumer.close()
                self._consumer = None
            except release_errors as error:
                errors.append(f"consumer: {error}")

        if errors:
            raise RuntimeError(
                "Не удалось корректно освободить Kafka-ресурсы: " + "; ".join(errors)
            )

    def forget(self) -> None:
        """Совместимость: делегирует в базовый Skill.forget()."""
        super().forget()
