from __future__ import annotations

import ast
from collections import defaultdict
from collections.abc import Iterable, Mapping, Sequence, Set as AbstractSet
from dataclasses import MISSING, Field, dataclass, is_dataclass
from enum import Enum
import importlib
import inspect
import os
import types
import shutil
import subprocess
import sys
import sysconfig
import tempfile
from pathlib import Path
import re
from typing import Union, get_type_hints
import xml.etree.ElementTree as ET

from persona_dsl.utils.naming import to_snake_case

_PROJECT_DEFAULTS_BEGIN = "# persona-schema-gen: begin project-defaults:"
_PROJECT_DEFAULTS_END = "# persona-schema-gen: end project-defaults:"
_XML_SCHEMA_NS = {"xs": "http://www.w3.org/2001/XMLSchema"}
_SCHEMA_DIR = "schema"
_MODELS_DIR = "models"
_BUILDERS_DIR = "builders"
_BUILTIN_TYPE_NAMES = {
    "str",
    "int",
    "float",
    "bool",
    "list",
    "dict",
    "tuple",
    "set",
    "object",
}


class XsdGenerator:
    """Генерирует schema-first package из XSD через xsdata."""

    def generate_from_schema(
        self,
        schema_path: str,
        output_dir: str,
        package: str | None = None,
    ) -> None:
        schema_file = Path(schema_path).resolve()
        if not schema_file.exists():
            raise FileNotFoundError(f"XSD схема не найдена: {schema_file}")
        if schema_file.suffix.lower() != ".xsd":
            raise ValueError(
                f"Генератор XSD принимает только .xsd файлы, получено: {schema_file.name}"
            )

        output_root, package_name, package_dir = self._resolve_generation_target(
            output_dir=Path(output_dir).resolve(),
            package=package,
        )
        preserved_defaults = self._read_project_defaults(package_dir)

        if package_dir.exists():
            shutil.rmtree(package_dir)
        output_root.mkdir(parents=True, exist_ok=True)
        self._ensure_package_chain(output_root=output_root, package_dir=package_dir)

        with tempfile.TemporaryDirectory(prefix="persona-schema-gen-") as staging_dir:
            staging_root = Path(staging_dir)
            staging_package_dir = staging_root / Path(*package_name.split("."))

            self._run_xsdata(
                schema_file=schema_file, output_dir=staging_root, package=package_name
            )
            self._rewrite_generated_imports(
                package_dir=staging_package_dir, package=package_name
            )
            schema_info = self._load_schema_info(
                schema_file=schema_file,
                output_root=staging_root,
                package=package_name,
            )
            raw_sources = self._load_raw_module_sources(
                package_dir=staging_package_dir,
                output_root=staging_root,
            )

            self._copy_schema_bundle(
                schema_file=schema_file,
                schema_dir=package_dir / _SCHEMA_DIR,
            )

            model_groups = self._model_groups(info=schema_info)
            self._write_model_packages(
                package_dir=package_dir,
                info=schema_info,
                groups=model_groups,
                raw_sources=raw_sources,
            )
            self._write_builder_packages(
                package_dir=package_dir,
                info=schema_info,
                model_groups=model_groups,
                preserved_defaults=preserved_defaults,
            )
            self._write_schema_meta(
                package_dir=package_dir,
                info=schema_info,
                schema_file_name=schema_file.name,
            )
            self._write_api(
                package_dir=package_dir,
                info=schema_info,
                model_groups=model_groups,
            )
            self._write_init(
                package_dir=package_dir,
                info=schema_info,
                model_groups=model_groups,
            )
            self._run_ruff_fix(package_dir=package_dir)
            self._drop_generated_modules(package_name)

    def _resolve_generation_target(
        self,
        output_dir: Path,
        package: str | None,
    ) -> tuple[Path, str, Path]:
        package_name = (package or "").strip()
        if package_name:
            output_root = output_dir
            package_dir = output_root / Path(*package_name.split("."))
            return output_root, package_name, package_dir

        if output_dir.name in {"", ".", ".."}:
            raise ValueError(
                "Если --package не указан, output_dir должен указывать на финальную директорию generated package."
            )
        output_root = output_dir.parent
        package_name = output_dir.name
        package_dir = output_dir
        return output_root, package_name, package_dir

    def _ensure_package_chain(self, output_root: Path, package_dir: Path) -> None:
        current = output_root
        for part in package_dir.relative_to(output_root).parts:
            current = current / part
            current.mkdir(parents=True, exist_ok=True)
            init_path = current / "__init__.py"
            if not init_path.exists():
                init_path.write_text(
                    "from __future__ import annotations\n",
                    encoding="utf-8",
                )

    def _run_xsdata(self, schema_file: Path, output_dir: Path, package: str) -> None:
        env = dict(os.environ)
        bin_candidates = [
            str(Path(sys.executable).parent),
            sysconfig.get_path("scripts"),
            str(Path(sys.executable).resolve().parent),
        ]
        path_parts = [candidate for candidate in bin_candidates if candidate]
        path_parts.append(env.get("PATH", ""))
        env["PATH"] = os.pathsep.join(path_parts)

        executable_name = "xsdata.exe" if os.name == "nt" else "xsdata"
        xsdata_executable = Path(sys.executable).parent / executable_name
        if xsdata_executable.exists():
            command = [str(xsdata_executable)]
        else:
            command = [sys.executable, "-m", "xsdata"]

        command.extend(
            [
                "generate",
                str(schema_file),
                "--package",
                package,
                "--output",
                "dataclasses",
                "--no-include-header",
                "--no-repr",
                "--no-eq",
                "--no-order",
                "--no-unsafe-hash",
                "--no-slots",
            ]
        )
        try:
            subprocess.run(
                command,
                cwd=output_dir,
                env=env,
                check=True,
                capture_output=True,
                text=True,
            )
        except FileNotFoundError as error:
            raise RuntimeError(
                "Для XSD генерации требуется установленный xsdata[cli] и ruff."
            ) from error
        except subprocess.CalledProcessError as error:
            stderr = error.stderr.strip() or error.stdout.strip()
            raise RuntimeError(f"xsdata завершился ошибкой: {stderr}") from error

    def _run_ruff_fix(self, package_dir: Path) -> None:
        command = [
            sys.executable,
            "-m",
            "ruff",
            "check",
            "--fix",
            "--no-cache",
            str(package_dir),
        ]
        try:
            subprocess.run(
                command,
                check=True,
                capture_output=True,
                text=True,
            )
            shutil.rmtree(package_dir / ".ruff_cache", ignore_errors=True)
            shutil.rmtree(package_dir.parent / ".ruff_cache", ignore_errors=True)
        except subprocess.CalledProcessError as error:
            stderr = error.stderr.strip() or error.stdout.strip()
            if "No module named ruff" in stderr:
                raise RuntimeError(
                    "Для XSD генерации требуется установленный xsdata[cli] и ruff."
                ) from error
            raise RuntimeError(f"ruff завершился ошибкой: {stderr}") from error

    def _load_schema_info(
        self,
        schema_file: Path,
        output_root: Path,
        package: str,
    ) -> "_SchemaPackageInfo":
        root_elements = self._root_elements(schema_file)
        if not root_elements:
            raise ValueError(
                f"В XSD '{schema_file}' не найдено ни одного корневого элемента."
            )

        package_root = output_root / Path(*package.split("."))
        package_dir = package_root
        module_names = sorted(
            ".".join(path.relative_to(output_root).with_suffix("").parts)
            for path in package_dir.rglob("*.py")
            if path.name != "__init__.py"
        )
        if not module_names:
            raise RuntimeError(
                f"xsdata не создал ни одного Python-модуля в '{package_dir}'."
            )

        imported_modules = self._import_generated_modules(
            output_root=output_root,
            module_names=module_names,
            package=package,
        )
        discovered_classes: list[type] = []
        for module in imported_modules:
            for _, raw_candidate in inspect.getmembers(module, inspect.isclass):
                candidate_module = getattr(raw_candidate, "__module__", None)
                if candidate_module != module.__name__:
                    continue
                if not isinstance(raw_candidate, type):
                    raise TypeError(
                        f"Ожидался Python class в модуле '{module.__name__}', получено '{raw_candidate!r}'."
                    )
                discovered_classes.append(raw_candidate)

        dataclass_types = [
            candidate for candidate in discovered_classes if is_dataclass(candidate)
        ]
        enum_types = [
            candidate
            for candidate in discovered_classes
            if inspect.isclass(candidate)
            and issubclass(candidate, Enum)
            and candidate is not Enum
        ]
        if not dataclass_types:
            raise RuntimeError("xsdata не сгенерировал ни одной dataclass модели.")

        root_classes: list[type[object]] = []
        root_element_type_names = {
            type_name for _, type_name in root_elements if type_name is not None
        }
        root_element_names = {element_name for element_name, _ in root_elements}
        meta_name_to_class = {
            self._meta_name(candidate): candidate
            for candidate in dataclass_types
            if self._meta_name(candidate) is not None
        }
        for element_name, _ in root_elements:
            root_class = meta_name_to_class.get(element_name)
            if root_class is None:
                raise RuntimeError(
                    f"Не удалось сопоставить XSD root element '{element_name}' с сгенерированным классом."
                )
            root_classes.append(root_class)

        root_type_classes = {
            candidate
            for candidate in dataclass_types
            if self._meta_name(candidate) in root_element_type_names
        }
        hidden_root_type_classes = self._hidden_root_type_classes(
            dataclass_types=dataclass_types,
            root_classes=root_classes,
            root_type_classes=root_type_classes,
        )
        public_dataclass_types = [
            candidate
            for candidate in dataclass_types
            if candidate not in hidden_root_type_classes
        ]
        builder_models = [
            candidate
            for candidate in public_dataclass_types
            if candidate not in root_type_classes
        ]
        primary_module_names = {
            candidate.__module__ for candidate in [*root_classes, *root_type_classes]
        }
        aliased_model_names = {
            base.__name__: root_class.__name__
            for root_class in root_classes
            for base in root_class.__bases__
            if base in hidden_root_type_classes
        }

        return _SchemaPackageInfo(
            package=package,
            module_names=module_names,
            all_model_classes=sorted(
                public_dataclass_types, key=lambda item: item.__name__
            ),
            builder_model_classes=sorted(
                builder_models, key=lambda item: item.__name__
            ),
            enum_classes=sorted(enum_types, key=lambda item: item.__name__),
            root_classes=sorted(root_classes, key=lambda item: item.__name__),
            root_element_names=root_element_names,
            hidden_model_names={
                candidate.__name__ for candidate in hidden_root_type_classes
            },
            primary_module_names=primary_module_names,
            aliased_model_names=aliased_model_names,
        )

    def _import_generated_modules(
        self,
        output_root: Path,
        module_names: list[str],
        package: str,
    ) -> list[types.ModuleType]:
        self._drop_generated_modules(package)

        imported_modules: list[types.ModuleType] = []
        output_root_str = str(output_root)
        sys.path.insert(0, output_root_str)
        try:
            importlib.invalidate_caches()
            for module_name in module_names:
                imported_modules.append(importlib.import_module(module_name))
        finally:
            sys.path.remove(output_root_str)
        return imported_modules

    def _drop_generated_modules(self, package: str) -> None:
        package_root = package.split(".", 1)[0]
        for module_name in list(sys.modules):
            if (
                module_name == package_root
                or module_name.startswith(f"{package_root}.")
                or module_name == package
                or module_name.startswith(f"{package}.")
            ):
                del sys.modules[module_name]

    def _root_elements(self, schema_file: Path) -> list[tuple[str, str | None]]:
        tree = ET.parse(schema_file)
        root = tree.getroot()
        elements: list[tuple[str, str | None]] = []
        for element in root.findall("./xs:element", _XML_SCHEMA_NS):
            element_name = element.attrib.get("name")
            if not element_name:
                raise ValueError(
                    f"Корневой xs:element в '{schema_file}' должен иметь атрибут name."
                )
            element_type = element.attrib.get("type")
            if element_type is not None and ":" in element_type:
                element_type = element_type.split(":", 1)[1]
            elements.append((element_name, element_type))
        return elements

    def _copy_schema_bundle(self, schema_file: Path, schema_dir: Path) -> None:
        copied_by_name: dict[str, Path] = {}
        visited: set[Path] = set()
        schema_dir.mkdir(parents=True, exist_ok=True)

        def _copy_recursive(current_schema: Path) -> None:
            current_schema = current_schema.resolve()
            if current_schema in visited:
                return

            destination = schema_dir / current_schema.name
            existing = copied_by_name.get(destination.name)
            if existing is not None and existing != current_schema:
                raise ValueError(
                    "Невозможно скопировать XSD bundle: несколько файлов "
                    f"с именем '{destination.name}' ({existing} и {current_schema})."
                )

            shutil.copy2(current_schema, destination)
            copied_by_name[destination.name] = current_schema
            visited.add(current_schema)

            for dependency in self._schema_dependencies(current_schema):
                _copy_recursive(dependency)

        _copy_recursive(schema_file)

    def _schema_dependencies(self, schema_file: Path) -> tuple[Path, ...]:
        tree = ET.parse(schema_file)
        root = tree.getroot()
        dependencies: list[Path] = []
        for tag_name in ("import", "include", "redefine"):
            for element in root.findall(f"./xs:{tag_name}", _XML_SCHEMA_NS):
                schema_location = element.attrib.get("schemaLocation")
                if schema_location is None:
                    continue
                if "://" in schema_location:
                    raise ValueError(
                        "Невозможно собрать локальный XSD bundle для удалённой зависимости: "
                        f"{schema_location}"
                    )
                dependency = (schema_file.parent / schema_location).resolve()
                if not dependency.exists():
                    raise FileNotFoundError(
                        f"Импортированная XSD схема не найдена: {dependency}"
                    )
                dependencies.append(dependency)
        return tuple(dependencies)

    def _rewrite_generated_imports(self, package_dir: Path, package: str) -> None:
        absolute_import_pattern = re.compile(
            rf"^from {re.escape(package)}\.(?P<module>[A-Za-z0-9_]+) import ",
            re.MULTILINE,
        )
        for module_path in package_dir.rglob("*.py"):
            original = module_path.read_text(encoding="utf-8")
            updated = absolute_import_pattern.sub(
                lambda match: f"from .{match.group('module')} import ",
                original,
            )
            if updated != original:
                module_path.write_text(updated, encoding="utf-8")

    def _write_model_packages(
        self,
        package_dir: Path,
        info: "_SchemaPackageInfo",
        groups: dict[tuple[str, ...], list[type[object]]],
        raw_sources: dict[str, "_RawModuleSource"],
    ) -> None:
        package_root = package_dir / _MODELS_DIR
        leaf_exports: dict[tuple[str, ...], list[str]] = {}
        symbol_to_group = {
            candidate.__name__: relative_module
            for relative_module, classes in groups.items()
            for candidate in classes
        }
        for relative_module, classes in sorted(groups.items()):
            file_path = package_root.joinpath(*relative_module).with_suffix(".py")
            file_path.parent.mkdir(parents=True, exist_ok=True)
            imports = self._render_model_import_blocks(
                current_module=(_MODELS_DIR, *relative_module),
                classes=classes,
                symbol_to_group=symbol_to_group,
                info=info,
                raw_sources=raw_sources,
            )
            module_namespace = self._module_namespace(
                classes=classes,
                raw_sources=raw_sources,
            )
            class_blocks = self._render_model_class_blocks(
                classes=classes,
                raw_sources=raw_sources,
            )
            content_parts = ["from __future__ import annotations"]
            if imports:
                content_parts.extend(["", imports])
            if module_namespace is not None:
                content_parts.extend(["", f"__NAMESPACE__ = {module_namespace!r}"])
            content_parts.extend(
                [
                    "",
                    class_blocks,
                    "",
                ]
            )
            file_path.write_text("\n".join(content_parts), encoding="utf-8")
            leaf_exports[relative_module] = sorted(
                candidate.__name__ for candidate in classes
            )
        self._write_package_tree_inits(
            package_root=package_root, leaf_exports=leaf_exports
        )

    def _load_raw_module_sources(
        self,
        package_dir: Path,
        output_root: Path,
    ) -> dict[str, "_RawModuleSource"]:
        result: dict[str, _RawModuleSource] = {}
        for module_path in sorted(package_dir.rglob("*.py")):
            if module_path.name == "__init__.py":
                continue
            module_name = ".".join(
                module_path.relative_to(output_root).with_suffix("").parts
            )
            source_text = module_path.read_text(encoding="utf-8")
            module_ast = ast.parse(source_text)
            class_nodes = {
                node.name: node
                for node in module_ast.body
                if isinstance(node, ast.ClassDef)
            }
            result[module_name] = _RawModuleSource(
                module_name=module_name,
                source_text=source_text,
                namespace=self._extract_namespace(module_ast),
                class_nodes=class_nodes,
                class_order=tuple(
                    node.name
                    for node in module_ast.body
                    if isinstance(node, ast.ClassDef)
                ),
            )
        return result

    def _extract_namespace(self, module_ast: ast.Module) -> str | None:
        for node in module_ast.body:
            if not isinstance(node, ast.Assign) or len(node.targets) != 1:
                continue
            target = node.targets[0]
            if not isinstance(target, ast.Name) or target.id != "__NAMESPACE__":
                continue
            if isinstance(node.value, ast.Constant) and isinstance(
                node.value.value, str
            ):
                return node.value.value
        return None

    def _module_namespace(
        self,
        classes: list[type[object]],
        raw_sources: dict[str, "_RawModuleSource"],
    ) -> str | None:
        namespaces = {
            raw_sources[candidate.__module__].namespace
            for candidate in classes
            if candidate.__module__ in raw_sources
            and raw_sources[candidate.__module__].namespace is not None
        }
        if not namespaces:
            return None
        if len(namespaces) != 1:
            raise ValueError(
                "Невозможно собрать semantic module: несколько namespace в одном файле."
            )
        return next(iter(namespaces))

    def _render_model_class_blocks(
        self,
        classes: list[type[object]],
        raw_sources: dict[str, "_RawModuleSource"],
    ) -> str:
        classes_by_module: dict[str, list[type[object]]] = defaultdict(list)
        for candidate in classes:
            classes_by_module[candidate.__module__].append(candidate)

        blocks: list[str] = []
        for module_name, module_classes in sorted(classes_by_module.items()):
            raw_source = raw_sources[module_name]
            ordered_names = [
                class_name
                for class_name in raw_source.class_order
                if any(candidate.__name__ == class_name for candidate in module_classes)
            ]
            module_candidates = {
                candidate.__name__: candidate for candidate in module_classes
            }
            for class_name in ordered_names:
                candidate = module_candidates[class_name]
                if issubclass(candidate, Enum):
                    blocks.append(raw_source.class_source(class_name))
                    continue
                if self._is_trivial_alias_class(candidate):
                    blocks.append(self._render_flattened_model_class(candidate))
                    continue
                blocks.append(raw_source.class_source(class_name))
        return "\n\n\n".join(blocks)

    def _render_model_import_blocks(
        self,
        current_module: tuple[str, ...],
        classes: list[type[object]],
        symbol_to_group: dict[str, tuple[str, ...]],
        info: "_SchemaPackageInfo",
        raw_sources: dict[str, "_RawModuleSource"],
    ) -> str:
        absolute_imports: dict[str, set[str]] = defaultdict(set)
        relative_imports: dict[str, set[str]] = defaultdict(set)
        local_symbols = {candidate.__name__ for candidate in classes}
        for candidate in classes:
            if issubclass(candidate, Enum):
                absolute_imports["enum"].add("Enum")
                continue

            absolute_imports["dataclasses"].update({"dataclass", "field"})
            for field_info in self._dataclass_fields(candidate):
                annotation = self._field_annotation(candidate, field_info.name)
                for type_name in self._annotation_type_names(annotation):
                    normalized_type_name = info.aliased_model_names.get(
                        type_name, type_name
                    )
                    if normalized_type_name in local_symbols:
                        continue
                    if normalized_type_name in _BUILTIN_TYPE_NAMES:
                        continue
                    if normalized_type_name == "Decimal":
                        absolute_imports["decimal"].add("Decimal")
                        continue
                    if normalized_type_name.startswith("Xml"):
                        absolute_imports["xsdata.models.datatype"].add(
                            normalized_type_name
                        )
                        continue
                    target_group = symbol_to_group.get(normalized_type_name)
                    if target_group is None or target_group == current_module[1:]:
                        continue
                    relative_imports[
                        f"{info.package}.{_MODELS_DIR}.{'.'.join(target_group)}"
                    ].add(normalized_type_name)
                if self._field_uses_decimal(field_info):
                    absolute_imports["decimal"].add("Decimal")
            raw_class_source = raw_sources[candidate.__module__].class_source(
                candidate.__name__
            )
            if "Decimal" in raw_class_source:
                absolute_imports["decimal"].add("Decimal")

            if self._is_trivial_alias_class(candidate):
                continue
            for base in candidate.__bases__:
                if base is object or not is_dataclass(base):
                    continue
                base_name = info.aliased_model_names.get(base.__name__, base.__name__)
                if base_name in local_symbols:
                    continue
                target_group = symbol_to_group.get(base_name)
                if target_group is None or target_group == current_module[1:]:
                    continue
                relative_imports[
                    f"{info.package}.{_MODELS_DIR}.{'.'.join(target_group)}"
                ].add(base_name)

        blocks: list[str] = []
        absolute_block = self._render_absolute_import_group(
            {
                module_name: sorted(names)
                for module_name, names in absolute_imports.items()
            }
        )
        if absolute_block:
            blocks.append(absolute_block)
        relative_block = self._render_relative_import_group(
            current_module=current_module,
            imports={
                module_name: sorted(names)
                for module_name, names in relative_imports.items()
            },
            package_depth=info.package_part_count,
        )
        if relative_block:
            blocks.append(relative_block)
        return "\n\n".join(blocks)

    def _is_trivial_alias_class(self, candidate: type[object]) -> bool:
        if not is_dataclass(candidate):
            return False
        own_annotations = candidate.__dict__.get("__annotations__", {})
        if own_annotations:
            return False
        return any(is_dataclass(base) for base in candidate.__bases__)

    def _render_flattened_model_class(self, candidate: type[object]) -> str:
        lines = [
            "@dataclass(repr=False, eq=False, kw_only=True)",
            f"class {candidate.__name__}:",
        ]
        docstring = inspect.cleandoc(candidate.__doc__ or "").strip()
        if docstring:
            lines.extend(
                [
                    '    """',
                    *[f"    {line}" if line else "" for line in docstring.splitlines()],
                    '    """',
                ]
            )

        meta_lines = self._render_meta_lines(candidate)
        if meta_lines:
            if len(lines) > 2:
                lines.append("")
            lines.extend(meta_lines)

        field_blocks = [
            self._render_field_definition(candidate, field_info)
            for field_info in self._dataclass_fields(candidate)
        ]
        if field_blocks:
            if len(lines) > 2:
                lines.append("")
            lines.append("\n\n".join(field_blocks))
        else:
            lines.append("    pass")
        return "\n".join(lines)

    def _render_meta_lines(self, candidate: type[object]) -> list[str]:
        meta = getattr(candidate, "Meta", None)
        if meta is None:
            return []

        lines: list[str] = []
        meta_name = getattr(meta, "name", None)
        meta_namespace = getattr(meta, "namespace", None)
        if meta_name is None and meta_namespace is None:
            return []

        lines.append("    class Meta:")
        if meta_name is not None:
            lines.append(f'        name = "{meta_name}"')
        if meta_namespace is not None:
            lines.append(f'        namespace = "{meta_namespace}"')
        return lines

    def _render_field_definition(
        self,
        model_class: type[object],
        field_info: Field[object],
    ) -> str:
        annotation = self._field_annotation(model_class, field_info.name)
        return (
            f"    {field_info.name}: {self._render_annotation(annotation)} = "
            f"{self._render_field_call(field_info)}"
        )

    def _render_annotation(self, annotation: object) -> str:
        origin = getattr(annotation, "__origin__", None)
        if origin is list:
            args = getattr(annotation, "__args__", ())
            if len(args) != 1:
                raise TypeError(
                    f"Список должен иметь один параметр типа: {annotation!r}"
                )
            item_annotation = next(iter(args), None)
            if item_annotation is None:
                raise TypeError(
                    f"Список должен иметь один параметр типа: {annotation!r}"
                )
            return f"list[{self._render_annotation(item_annotation)}]"
        if isinstance(annotation, types.UnionType) or origin is Union:
            parts = [
                self._render_annotation(item)
                for item in getattr(annotation, "__args__", ())
            ]
            if not parts:
                raise TypeError(f"Неподдерживаемая union-аннотация: {annotation!r}")
            return " | ".join(parts)
        if isinstance(annotation, type):
            if annotation is type(None):
                return "None"
            return annotation.__qualname__.replace(".<locals>.", ".")
        raise TypeError(f"Неподдерживаемая аннотация поля: {annotation!r}")

    def _annotation_type_names(self, annotation: object) -> tuple[str, ...]:
        origin = getattr(annotation, "__origin__", None)
        if origin is list:
            args = getattr(annotation, "__args__", ())
            if len(args) != 1:
                raise TypeError(
                    f"Список должен иметь один параметр типа: {annotation!r}"
                )
            item_annotation = next(iter(args), None)
            if item_annotation is None:
                raise TypeError(
                    f"Список должен иметь один параметр типа: {annotation!r}"
                )
            return self._annotation_type_names(item_annotation)
        if isinstance(annotation, types.UnionType) or origin is Union:
            result: list[str] = []
            for item in getattr(annotation, "__args__", ()):
                if item is type(None):
                    continue
                result.extend(self._annotation_type_names(item))
            return tuple(result)
        if isinstance(annotation, type):
            return (annotation.__qualname__.replace(".<locals>.", "."),)
        raise TypeError(f"Неподдерживаемая аннотация поля: {annotation!r}")

    def _render_field_call(self, field_info: Field[object]) -> str:
        arguments: list[str] = []
        if field_info.default is not MISSING:
            arguments.append(f"default={self._render_literal(field_info.default)}")
        if field_info.default_factory is not MISSING:
            arguments.append(
                f"default_factory={self._render_default_factory(field_info.default_factory)}"
            )
        if field_info.init is False:
            arguments.append("init=False")
        if field_info.repr is False:
            arguments.append("repr=False")
        if field_info.hash is not None:
            arguments.append(f"hash={field_info.hash!r}")
        if field_info.compare is False:
            arguments.append("compare=False")
        if field_info.metadata:
            arguments.append(
                "metadata={\n"
                + "\n".join(
                    f"            {key!r}: {self._render_literal(value)},"
                    for key, value in field_info.metadata.items()
                )
                + "\n        }"
            )
        if not arguments:
            return "field()"

        rendered_arguments: list[str] = []
        for argument in arguments:
            if argument.startswith("metadata="):
                rendered_arguments.append(
                    "        " + argument.replace("\n", "\n        ")
                )
                continue
            rendered_arguments.append(f"        {argument},")
        return "field(\n" + "\n".join(rendered_arguments) + "\n    )"

    def _render_default_factory(self, factory: object) -> str:
        if factory in {list, dict, set, tuple}:
            if isinstance(factory, type):
                return factory.__name__
        factory_name = getattr(factory, "__name__", None)
        if callable(factory) and isinstance(factory_name, str):
            return factory_name
        raise TypeError(
            f"Неподдерживаемый default_factory в generated модели: {factory!r}"
        )

    def _render_literal(self, value: object) -> str:
        if isinstance(value, Enum):
            return f"{value.__class__.__name__}.{value.name}"
        return repr(value)

    def _write_builder_packages(
        self,
        package_dir: Path,
        info: "_SchemaPackageInfo",
        model_groups: dict[tuple[str, ...], list[type[object]]],
        preserved_defaults: dict[str, str],
    ) -> None:
        package_root = package_dir / _BUILDERS_DIR
        group_models: dict[tuple[str, ...], list[type[object]]] = defaultdict(list)
        for relative_module, classes in model_groups.items():
            group_models[relative_module].extend(
                candidate
                for candidate in classes
                if candidate in info.builder_model_classes
            )

        leaf_exports: dict[tuple[str, ...], list[str]] = {}
        for relative_module, model_classes in sorted(group_models.items()):
            if not model_classes:
                continue

            file_path = package_root.joinpath(*relative_module).with_suffix(".py")
            file_path.parent.mkdir(parents=True, exist_ok=True)
            import_blocks = [
                self._render_relative_import_group(
                    current_module=(_BUILDERS_DIR, *relative_module),
                    imports={
                        f"{info.package}.{_MODELS_DIR}": sorted(
                            {
                                candidate.__name__
                                for candidate in self._builder_model_imports(
                                    model_classes=model_classes,
                                    info=info,
                                )
                            }
                        )
                    },
                    package_depth=info.package_part_count,
                )
            ]
            support_imports = self._render_builder_support_imports(
                model_classes=model_classes,
                info=info,
            )
            if support_imports:
                import_blocks.append(support_imports)
            builder_type_imports = self._render_builder_type_checking_imports(
                current_module=(_BUILDERS_DIR, *relative_module),
                model_classes=model_classes,
                info=info,
            )

            blocks: list[str] = []
            builder_names: list[str] = []
            factory_names: list[str] = []
            for model_class in model_classes:
                builder_name = f"{model_class.__name__}Builder"
                defaults_func = (
                    f"project_defaults_for_{to_snake_case(model_class.__name__)}"
                )
                builder_names.append(builder_name)

                preserved_block = preserved_defaults.get(defaults_func)
                if preserved_block is None:
                    defaults_body = f"def {defaults_func}() -> dict[str, object]:\n    return {{}}\n"
                else:
                    defaults_body = preserved_block.rstrip() + "\n"
                blocks.append(
                    f"{_PROJECT_DEFAULTS_BEGIN}{defaults_func}\n"
                    f"{defaults_body}"
                    f"{_PROJECT_DEFAULTS_END}{defaults_func}\n"
                )

                method_lines = [
                    f"class {builder_name}(SchemaBuilder[{model_class.__name__}]):",
                    "    def __init__(self) -> None:",
                    f"        super().__init__({model_class.__name__}, project_defaults_factory={defaults_func})",
                ]
                for field_info in self._dataclass_fields(model_class):
                    method_lines.extend(
                        self._render_builder_methods(
                            field_name=field_info.name,
                            annotation=self._field_annotation(
                                model_class, field_info.name
                            ),
                            info=info,
                        )
                    )
                method_lines.append("")
                blocks.append("\n".join(method_lines))

                if model_class in info.root_classes:
                    factory_name = f"{to_snake_case(model_class.__name__)}_builder"
                    factory_names.append(factory_name)
                    blocks.append(
                        "\n".join(
                            [
                                f"def {factory_name}() -> {builder_name}:",
                                f"    return {builder_name}()",
                                "",
                            ]
                        )
                    )

            content = "\n".join(
                [
                    "from __future__ import annotations",
                    "",
                    "from typing import TYPE_CHECKING, Self",
                    "",
                    "from persona_dsl.schema_runtime import SchemaBuilder",
                    "",
                    "\n\n".join(import_blocks),
                    "",
                    builder_type_imports,
                    "",
                    *blocks,
                    "",
                ]
            )
            file_path.write_text(content, encoding="utf-8")
            leaf_exports[relative_module] = sorted(builder_names + factory_names)
        self._write_package_tree_inits(
            package_root=package_root, leaf_exports=leaf_exports
        )

    def _write_schema_meta(
        self,
        package_dir: Path,
        info: "_SchemaPackageInfo",
        schema_file_name: str,
    ) -> None:
        root_import_lines = (
            "from .models import (\n"
            + "\n".join(
                f"    {root_class.__name__},"
                for root_class in sorted(
                    info.root_classes, key=lambda item: item.__name__
                )
            )
            + "\n)"
        )
        bindings_body = "\n".join(
            [
                "    XmlModelBinding(\n"
                f"        model_type={root_class.__name__},\n"
                "        schema_path=SCHEMA_PATH,\n"
                f"        root_name={self._meta_name(root_class)!r},\n"
                "    ),"
                for root_class in info.root_classes
            ]
        )
        root_models_body = ",\n".join(
            [
                f"    {self._meta_name(root_class)!r}: {root_class.__name__}"
                for root_class in info.root_classes
            ]
        )
        content = "\n".join(
            [
                "from __future__ import annotations",
                "",
                "from pathlib import Path",
                "",
                "from persona_dsl.schema_runtime import XmlModelBinding, register_xml_binding",
                "",
                root_import_lines,
                "",
                f'SCHEMA_PATH = Path(__file__).with_name("{_SCHEMA_DIR}") / "{schema_file_name}"',
                "",
                "ROOT_MODELS: dict[str, type[object]] = {",
                root_models_body,
                "}",
                "",
                "ROOT_BINDINGS: tuple[XmlModelBinding, ...] = (",
                bindings_body,
                ")",
                "",
                "def register_codecs() -> None:",
                "    for binding in ROOT_BINDINGS:",
                "        register_xml_binding(",
                "            model_type=binding.model_type,",
                "            schema_path=binding.schema_path,",
                "            root_name=binding.root_name,",
                "        )",
                "",
                '__all__ = ["SCHEMA_PATH", "ROOT_MODELS", "ROOT_BINDINGS", "register_codecs"]',
                "",
            ]
        )
        (package_dir / "schema_meta.py").write_text(content, encoding="utf-8")

    def _write_api(
        self,
        package_dir: Path,
        info: "_SchemaPackageInfo",
        model_groups: dict[tuple[str, ...], list[type[object]]],
    ) -> None:
        model_exports = self._public_api_model_exports(
            info=info,
            model_groups=model_groups,
        )
        builder_exports = self._public_api_builder_exports(
            info=info,
            public_model_exports=model_exports,
        )
        content = "\n".join(
            [
                "from __future__ import annotations",
                "",
                "from .models import (",
                *[f"    {name}," for name in model_exports],
                ")",
                "from .builders import (",
                *[f"    {name}," for name in builder_exports],
                ")",
                "",
                f"__all__ = {sorted(model_exports + builder_exports)!r}",
                "",
            ]
        )
        (package_dir / "api.py").write_text(content, encoding="utf-8")

    def _write_init(
        self,
        package_dir: Path,
        info: "_SchemaPackageInfo",
        model_groups: dict[tuple[str, ...], list[type[object]]],
    ) -> None:
        public_model_exports = self._public_api_model_exports(
            info=info,
            model_groups=model_groups,
        )
        public_builder_exports = self._public_api_builder_exports(
            info=info,
            public_model_exports=public_model_exports,
        )
        exports = sorted(
            public_model_exports
            + public_builder_exports
            + ["SCHEMA_PATH", "ROOT_MODELS", "ROOT_BINDINGS", "register_codecs"]
        )
        content = "\n".join(
            [
                "from __future__ import annotations",
                "",
                "from .api import (",
                *[
                    f"    {name},"
                    for name in sorted(public_model_exports + public_builder_exports)
                ],
                ")",
                "from .schema_meta import ROOT_BINDINGS, ROOT_MODELS, SCHEMA_PATH, register_codecs",
                "",
                "register_codecs()",
                "",
                f"__all__ = {exports!r}",
                "",
            ]
        )
        (package_dir / "__init__.py").write_text(content, encoding="utf-8")

    def _public_api_model_exports(
        self,
        info: "_SchemaPackageInfo",
        model_groups: dict[tuple[str, ...], list[type[object]]],
    ) -> list[str]:
        exports = {candidate.__name__ for candidate in info.enum_classes}
        for relative_module, classes in model_groups.items():
            if not relative_module or relative_module[0] not in {"messages", "domain"}:
                continue
            exports.update(candidate.__name__ for candidate in classes)
        return sorted(exports)

    def _public_api_builder_exports(
        self,
        info: "_SchemaPackageInfo",
        public_model_exports: Sequence[str],
    ) -> list[str]:
        exported_model_names = set(public_model_exports)
        return sorted(
            [
                f"{model_class.__name__}Builder"
                for model_class in info.builder_model_classes
                if model_class.__name__ in exported_model_names
            ]
            + [
                f"{to_snake_case(root_class.__name__)}_builder"
                for root_class in info.root_classes
            ]
        )

    def _render_builder_methods(
        self,
        field_name: str,
        annotation: object,
        info: "_SchemaPackageInfo",
    ) -> list[str]:
        list_item_type = self._list_item_type_name(annotation)
        if list_item_type is not None:
            parameter_type = self._builder_parameter_type(
                list_item_type,
                repeated=True,
                info=info,
            )
            method_name = f"add_{field_name}"
            return [
                "",
                f"    def {method_name}(self, value: {parameter_type}) -> Self:",
                f'        self._append("{field_name}", value)',
                "        return self",
            ]

        parameter_type = self._builder_parameter_type(
            self._annotation_type_name(annotation),
            repeated=False,
            info=info,
        )
        method_name = f"with_{field_name}"
        return [
            "",
            f"    def {method_name}(self, value: {parameter_type}) -> Self:",
            f'        self._set("{field_name}", value)',
            "        return self",
        ]

    def _builder_parameter_type(
        self,
        type_name: str,
        *,
        repeated: bool,
        info: "_SchemaPackageInfo",
    ) -> str:
        top_level_type_name = type_name.split(".", 1)[0]
        if type_name.endswith("Builder"):
            return type_name
        if type_name in {"str", "int", "float", "bool", "object"}:
            return type_name
        if type_name in info.enum_names or (
            "." not in type_name and top_level_type_name in info.enum_names
        ):
            return f"{type_name} | str"
        if type_name in info.builder_model_names:
            return f"{type_name} | {type_name}Builder"
        if top_level_type_name in info.all_model_names:
            return type_name
        return type_name

    def _field_annotation(self, model_class: type[object], field_name: str) -> object:
        try:
            return get_type_hints(model_class)[field_name]
        except NameError:
            module = sys.modules.get(model_class.__module__)
            namespace = vars(module) if module is not None else None
            return get_type_hints(
                model_class,
                globalns=namespace,
                localns=namespace,
            )[field_name]

    def _dataclass_fields(self, model_class: type[object]) -> tuple[Field[object], ...]:
        raw_fields = getattr(model_class, "__dataclass_fields__", None)
        if not isinstance(raw_fields, dict):
            raise TypeError(f"Ожидалась dataclass модель, получено '{model_class!r}'.")

        result: list[Field[object]] = []
        for field_info in raw_fields.values():
            if not isinstance(field_info, Field):
                raise TypeError(
                    f"Dataclass '{model_class.__name__}' содержит некорректное поле '{field_info!r}'."
                )
            result.append(field_info)
        return tuple(result)

    def _annotation_type_name(self, annotation: object) -> str:
        origin = getattr(annotation, "__origin__", None)
        if origin is list:
            args = getattr(annotation, "__args__", ())
            if len(args) != 1:
                raise TypeError(
                    f"Список должен иметь один параметр типа: {annotation!r}"
                )
            item_annotation = next(iter(args), None)
            if item_annotation is None:
                raise TypeError(
                    f"Список должен иметь один параметр типа: {annotation!r}"
                )
            return self._annotation_type_name(item_annotation)
        if isinstance(annotation, types.UnionType) or origin is Union:
            args = [
                item
                for item in getattr(annotation, "__args__", ())
                if item is not type(None)
            ]
            if len(args) != 1:
                raise TypeError(f"Неподдерживаемая union-аннотация: {annotation!r}")
            union_annotation = next(iter(args), None)
            if union_annotation is None:
                raise TypeError(f"Неподдерживаемая union-аннотация: {annotation!r}")
            return self._annotation_type_name(union_annotation)
        if isinstance(annotation, type):
            return annotation.__qualname__.replace(".<locals>.", ".")
        raise TypeError(f"Неподдерживаемая аннотация поля: {annotation!r}")

    def _list_item_type_name(self, annotation: object) -> str | None:
        origin = getattr(annotation, "__origin__", None)
        if origin is not list:
            return None
        args = getattr(annotation, "__args__", ())
        if len(args) != 1:
            raise TypeError(f"Список должен иметь один параметр типа: {annotation!r}")
        item_annotation = next(iter(args), None)
        if item_annotation is None:
            raise TypeError(f"Список должен иметь один параметр типа: {annotation!r}")
        return self._annotation_type_name(item_annotation)

    def _read_project_defaults(self, package_dir: Path) -> dict[str, str]:
        if not package_dir.exists():
            return {}
        pattern = re.compile(
            rf"{re.escape(_PROJECT_DEFAULTS_BEGIN)}(?P<name>[^\n]+)\n(?P<body>.*?){re.escape(_PROJECT_DEFAULTS_END)}(?P=name)",
            re.DOTALL,
        )
        preserved: dict[str, str] = {}
        for python_file in sorted(package_dir.rglob("*.py")):
            content = python_file.read_text(encoding="utf-8")
            for match in pattern.finditer(content):
                preserved[match.group("name")] = match.group("body")
        return preserved

    def _group_imports(self, classes: Iterable[type[object]]) -> dict[str, list[str]]:
        grouped: dict[str, list[str]] = defaultdict(list)
        for candidate in classes:
            grouped[candidate.__module__].append(candidate.__name__)
        return {module_name: sorted(names) for module_name, names in grouped.items()}

    def _render_builder_support_imports(
        self,
        model_classes: list[type[object]],
        info: "_SchemaPackageInfo",
    ) -> str:
        imports: dict[str, list[str]] = defaultdict(list)
        for model_class in model_classes:
            for field_info in self._dataclass_fields(model_class):
                annotation = self._field_annotation(model_class, field_info.name)
                for candidate in self._annotation_runtime_types(annotation):
                    if self._type_is_covered_by_models_import(candidate, info):
                        continue
                    if candidate.__module__ == "builtins":
                        continue
                    imports[candidate.__module__].append(candidate.__name__)
        rendered = self._render_absolute_import_group(
            {module_name: sorted(set(names)) for module_name, names in imports.items()}
        )
        return rendered

    def _render_builder_type_checking_imports(
        self,
        current_module: tuple[str, ...],
        model_classes: list[type[object]],
        info: "_SchemaPackageInfo",
    ) -> str:
        local_builder_names = {
            f"{model_class.__name__}Builder" for model_class in model_classes
        }
        referenced_builder_names: set[str] = set()
        for model_class in model_classes:
            for field_info in self._dataclass_fields(model_class):
                annotation = self._field_annotation(model_class, field_info.name)
                for candidate in self._annotation_runtime_types(annotation):
                    top_level_type_name = candidate.__qualname__.split(".", 1)[0]
                    if top_level_type_name not in info.builder_model_names:
                        continue
                    builder_name = f"{top_level_type_name}Builder"
                    if builder_name in local_builder_names:
                        continue
                    referenced_builder_names.add(builder_name)

        if not referenced_builder_names:
            return "if TYPE_CHECKING:\n    pass"

        imports = self._render_relative_import_group(
            current_module=current_module,
            imports={
                f"{info.package}.{_BUILDERS_DIR}": sorted(referenced_builder_names),
            },
            package_depth=info.package_part_count,
        )
        indented_imports = "\n".join(f"    {line}" for line in imports.splitlines())
        return "\n".join(
            [
                "if TYPE_CHECKING:",
                indented_imports,
            ]
        )

    def _annotation_runtime_types(self, annotation: object) -> tuple[type[object], ...]:
        origin = getattr(annotation, "__origin__", None)
        if origin is list:
            args = getattr(annotation, "__args__", ())
            if len(args) != 1:
                raise TypeError(
                    f"Список должен иметь один параметр типа: {annotation!r}"
                )
            item_annotation = next(iter(args), None)
            if item_annotation is None:
                raise TypeError(
                    f"Список должен иметь один параметр типа: {annotation!r}"
                )
            return self._annotation_runtime_types(item_annotation)
        if isinstance(annotation, types.UnionType) or origin is Union:
            args = [
                item
                for item in getattr(annotation, "__args__", ())
                if item is not type(None)
            ]
            result: list[type[object]] = []
            for item in args:
                result.extend(self._annotation_runtime_types(item))
            return tuple(result)
        if isinstance(annotation, type):
            return (annotation,)
        raise TypeError(f"Неподдерживаемая аннотация поля: {annotation!r}")

    def _type_is_covered_by_models_import(
        self,
        candidate: type[object],
        info: "_SchemaPackageInfo",
    ) -> bool:
        top_level_type_name = candidate.__qualname__.split(".", 1)[0]
        return (
            top_level_type_name in info.all_model_names
            or top_level_type_name in info.enum_names
        )

    def _render_import_group(self, imports: dict[str, list[str]]) -> str:
        lines: list[str] = []
        for module_name, names in sorted(imports.items()):
            relative_module = module_name.rsplit(".", 1)[-1]
            if len(names) == 1:
                lines.append(f"from .{relative_module} import {names[0]}")
                continue
            lines.append(f"from .{relative_module} import (")
            for name in names:
                lines.append(f"    {name},")
            lines.append(")")
        return "\n".join(lines)

    def _render_relative_import_group(
        self,
        current_module: tuple[str, ...],
        imports: dict[str, list[str]],
        package_depth: int,
    ) -> str:
        lines: list[str] = []
        dots = "." * len(current_module)
        for module_name, names in sorted(imports.items()):
            relative_parts = module_name.split(".")[package_depth:]
            target_module = f"{dots}{'.'.join(relative_parts)}"
            if len(names) == 1:
                lines.append(f"from {target_module} import {names[0]}")
                continue
            lines.append(f"from {target_module} import (")
            for name in names:
                lines.append(f"    {name},")
            lines.append(")")
        return "\n".join(lines)

    def _model_groups(
        self,
        info: "_SchemaPackageInfo",
    ) -> dict[tuple[str, ...], list[type[object]]]:
        groups: dict[tuple[str, ...], list[type[object]]] = defaultdict(list)
        family_owners = self._family_owners(info)
        for candidate in sorted(
            info.all_model_classes + info.enum_classes,
            key=lambda item: item.__name__,
        ):
            groups[self._model_group_for(candidate, info, family_owners)].append(
                candidate
            )
        return groups

    def _model_group_for(
        self,
        candidate: type[object],
        info: "_SchemaPackageInfo",
        family_owners: dict[str, set[str]] | None = None,
    ) -> tuple[str, ...]:
        if family_owners is None:
            family_owners = self._family_owners(info)
        if candidate.__module__ not in info.primary_module_names:
            return ("external", candidate.__module__.rsplit(".", 1)[-1])
        if candidate in info.root_classes:
            return (
                "messages",
                to_snake_case(self._message_family_name(candidate.__name__)),
            )
        owners = family_owners.get(candidate.__name__, set())
        if len(owners) == 1:
            return ("domain", next(iter(owners)))
        return ("domain", "shared")

    def _field_uses_decimal(self, field_info: Field[object]) -> bool:
        stack: list[object] = [field_info.default, field_info.metadata]
        while stack:
            value = stack.pop()
            if value is MISSING:
                continue
            if isinstance(value, Mapping):
                stack.extend(value.values())
                continue
            if isinstance(value, (list, tuple, set, frozenset)):
                stack.extend(value)
                continue
            if value.__class__.__name__ == "Decimal":
                return True
        return False

    def _message_group_for(
        self,
        class_name: str,
        info: "_SchemaPackageInfo",
    ) -> str | None:
        families = sorted(
            {
                self._message_family_name(root_class.__name__)
                for root_class in info.root_classes
            },
            key=len,
            reverse=True,
        )
        for family in families:
            if family and class_name.startswith(family):
                return to_snake_case(family)
        return None

    def _message_family_name(self, class_name: str) -> str:
        if class_name.endswith("Rq"):
            return class_name[:-2]
        if class_name.endswith("Rs"):
            return class_name[:-2]
        return class_name.removesuffix("Esbtype")

    def _family_owners(self, info: "_SchemaPackageInfo") -> dict[str, set[str]]:
        dependencies = self._model_dependency_graph(info)
        owners: dict[str, set[str]] = defaultdict(set)
        for root_class in info.root_classes:
            family = to_snake_case(self._message_family_name(root_class.__name__))
            stack = list(dependencies.get(root_class.__name__, set()))
            visited: set[str] = set()
            while stack:
                candidate_name = stack.pop()
                if candidate_name in visited:
                    continue
                visited.add(candidate_name)
                candidate_type = info.class_by_name.get(candidate_name)
                if candidate_type is None:
                    continue
                if candidate_type.__module__ not in info.primary_module_names:
                    continue
                if candidate_type in info.root_classes:
                    continue
                owners[candidate_name].add(family)
                stack.extend(dependencies.get(candidate_name, set()))
        return owners

    def _model_dependency_graph(
        self,
        info: "_SchemaPackageInfo",
    ) -> dict[str, set[str]]:
        graph: dict[str, set[str]] = {}
        for candidate in info.all_model_classes + info.enum_classes:
            dependencies: set[str] = set()
            for base in getattr(candidate, "__bases__", ()):
                if base is object or not isinstance(base, type):
                    continue
                base_name = info.aliased_model_names.get(base.__name__, base.__name__)
                if (
                    base_name in info.public_model_names
                    and base_name != candidate.__name__
                ):
                    dependencies.add(base_name)
            if is_dataclass(candidate):
                for field_info in self._dataclass_fields(candidate):
                    annotation = self._field_annotation(candidate, field_info.name)
                    for type_name in self._annotation_type_names(annotation):
                        normalized_type_name = info.aliased_model_names.get(
                            type_name, type_name
                        )
                        if (
                            normalized_type_name in info.public_model_names
                            and normalized_type_name != candidate.__name__
                        ):
                            dependencies.add(normalized_type_name)
            graph[candidate.__name__] = dependencies
        return graph

    def _hidden_root_type_classes(
        self,
        dataclass_types: Sequence[type[object]],
        root_classes: list[type[object]],
        root_type_classes: AbstractSet[type[object]],
    ) -> set[type[object]]:
        directly_wrapped_root_types = {
            base
            for root_class in root_classes
            for base in root_class.__bases__
            if base in root_type_classes
        }
        referenced_elsewhere: set[type[object]] = set()
        for candidate in dataclass_types:
            if candidate in root_classes:
                continue
            for base in getattr(candidate, "__bases__", ()):
                if base in directly_wrapped_root_types:
                    referenced_elsewhere.add(base)
            if not is_dataclass(candidate):
                continue
            for field_info in self._dataclass_fields(candidate):
                annotation = self._field_annotation(candidate, field_info.name)
                for runtime_type in self._annotation_runtime_types(annotation):
                    if runtime_type in directly_wrapped_root_types:
                        referenced_elsewhere.add(runtime_type)
        return directly_wrapped_root_types - referenced_elsewhere

    def _builder_model_imports(
        self,
        model_classes: list[type[object]],
        info: "_SchemaPackageInfo",
    ) -> list[type[object]]:
        imported: list[type[object]] = []
        seen: set[str] = set()
        for model_class in model_classes:
            if model_class.__name__ not in seen:
                imported.append(model_class)
                seen.add(model_class.__name__)
            for field_info in self._dataclass_fields(model_class):
                annotation = self._field_annotation(model_class, field_info.name)
                for candidate in self._annotation_runtime_types(annotation):
                    top_level_type_name = candidate.__qualname__.split(".", 1)[0]
                    if (
                        candidate.__module__ == "builtins"
                        or top_level_type_name not in info.all_model_names
                        and top_level_type_name not in info.enum_names
                    ):
                        continue
                    imported_name = top_level_type_name
                    if imported_name in seen:
                        continue
                    imported.append(
                        next(
                            item
                            for item in info.all_model_classes + info.enum_classes
                            if item.__name__ == imported_name
                        )
                    )
                    seen.add(imported_name)
        return imported

    def _write_package_tree_inits(
        self,
        package_root: Path,
        leaf_exports: dict[tuple[str, ...], list[str]],
    ) -> None:
        package_paths = {parts[:-1] for parts in leaf_exports}
        package_paths.add(tuple())
        package_exports: dict[tuple[str, ...], list[str]] = {}
        for package_parts in sorted(package_paths, key=len, reverse=True):
            imports: list[str] = []
            exports: list[str] = []

            direct_modules = {
                parts[-1]: names
                for parts, names in leaf_exports.items()
                if parts[:-1] == package_parts
            }
            direct_packages = sorted(
                {
                    parts[len(package_parts)]
                    for parts in leaf_exports
                    if len(parts) > len(package_parts) + 1
                    and parts[: len(package_parts)] == package_parts
                }
            )

            for module_name, names in sorted(direct_modules.items()):
                imports.extend(self._render_local_import_lines(module_name, names))
                exports.extend(names)

            for subpackage_name in direct_packages:
                names = package_exports[package_parts + (subpackage_name,)]
                imports.extend(self._render_local_import_lines(subpackage_name, names))
                exports.extend(names)

            init_path = package_root.joinpath(*package_parts, "__init__.py")
            init_path.parent.mkdir(parents=True, exist_ok=True)
            content_lines = ["from __future__ import annotations", ""]
            if imports:
                content_lines.extend(imports)
                content_lines.append("")
            content_lines.append(f"__all__ = {sorted(exports)!r}")
            content_lines.append("")
            init_path.write_text("\n".join(content_lines), encoding="utf-8")
            package_exports[package_parts] = sorted(exports)

    def _render_local_import_lines(
        self,
        module_name: str,
        names: list[str],
    ) -> list[str]:
        if len(names) == 1:
            return [f"from .{module_name} import {names[0]}"]
        lines = [f"from .{module_name} import ("]
        lines.extend(f"    {name}," for name in names)
        lines.append(")")
        return lines

    def _render_absolute_import_group(self, imports: dict[str, list[str]]) -> str:
        lines: list[str] = []
        for module_name, names in sorted(imports.items()):
            if len(names) == 1:
                lines.append(f"from {module_name} import {names[0]}")
                continue
            lines.append(f"from {module_name} import (")
            for name in names:
                lines.append(f"    {name},")
            lines.append(")")
        return "\n".join(lines)

    def _meta_name(self, candidate: type[object]) -> str | None:
        meta = getattr(candidate, "Meta", None)
        return getattr(meta, "name", None)


class _SchemaPackageInfo:
    def __init__(
        self,
        package: str,
        module_names: list[str],
        all_model_classes: list[type[object]],
        builder_model_classes: list[type[object]],
        enum_classes: list[type[object]],
        root_classes: list[type[object]],
        root_element_names: set[str],
        hidden_model_names: set[str] | None = None,
        primary_module_names: set[str] | None = None,
        aliased_model_names: dict[str, str] | None = None,
    ) -> None:
        self.package = package
        self.module_names = module_names
        self.all_model_classes = all_model_classes
        self.builder_model_classes = builder_model_classes
        self.enum_classes = enum_classes
        self.root_classes = root_classes
        self.root_element_names = root_element_names
        self.package_part_count = len(package.split("."))
        self.all_model_names = {candidate.__name__ for candidate in all_model_classes}
        self.public_model_names = self.all_model_names | {
            candidate.__name__ for candidate in enum_classes
        }
        self.builder_model_names = {
            candidate.__name__ for candidate in builder_model_classes
        }
        self.enum_names = {candidate.__name__ for candidate in enum_classes}
        self.hidden_model_names = hidden_model_names or set()
        self.primary_module_names = primary_module_names or {
            candidate.__module__ for candidate in all_model_classes
        }
        self.aliased_model_names = aliased_model_names or {}
        self.class_by_name = {
            candidate.__name__: candidate
            for candidate in all_model_classes + enum_classes
        }


@dataclass(frozen=True)
class _RawModuleSource:
    module_name: str
    source_text: str
    namespace: str | None
    class_nodes: dict[str, ast.ClassDef]
    class_order: tuple[str, ...]

    def class_source(self, class_name: str) -> str:
        node = self.class_nodes[class_name]
        source_lines = self.source_text.splitlines()
        decorator_lines = [decorator.lineno for decorator in node.decorator_list]
        start_line = min(decorator_lines) if decorator_lines else node.lineno
        source = "\n".join(source_lines[start_line - 1 : node.end_lineno])
        return source.strip()
