from typing import TYPE_CHECKING

__all__ = ["PageGenerator", "ApiGenerator", "XsdGenerator"]

if TYPE_CHECKING:
    from .api_generator import ApiGenerator
    from .page import PageGenerator
    from .schema import XsdGenerator


def __getattr__(name: str) -> object:
    if name == "PageGenerator":
        from .page import PageGenerator as _PageGenerator

        return _PageGenerator
    if name == "ApiGenerator":
        from .api_generator import ApiGenerator as _ApiGenerator

        return _ApiGenerator
    if name == "XsdGenerator":
        from .schema import XsdGenerator as _XsdGenerator

        return _XsdGenerator
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
