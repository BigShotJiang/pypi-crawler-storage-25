from __future__ import annotations

import json
import re
from collections.abc import Mapping
from pathlib import Path

import yaml

from persona_dsl.json_types import JsonObject, is_json_object
from persona_dsl.utils.naming import to_pascal_case, to_snake_case

_SUPPORTED_METHODS = {"get", "post", "put", "patch", "delete", "head", "options"}
_PRIMITIVE_TYPE_NAMES = {"str", "int", "float", "bool", "object"}


def _require_json_object(value: object, *, context: str) -> JsonObject:
    if not is_json_object(value):
        raise TypeError(f"{context} должен быть JSON-объектом.")
    return value


def _json_object_or_empty(value: object, *, context: str) -> JsonObject:
    if value is None:
        return {}
    return _require_json_object(value, context=context)


def _json_object_items(value: object, *, context: str) -> list[tuple[str, JsonObject]]:
    json_object = _json_object_or_empty(value, context=context)
    items: list[tuple[str, JsonObject]] = []
    for key, item in json_object.items():
        items.append(
            (
                key,
                _require_json_object(item, context=f"{context}.{key}"),
            )
        )
    return items


def _string_list(value: object, *, context: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise TypeError(f"{context} должен быть списком строк.")
    if not all(isinstance(item, str) for item in value):
        raise TypeError(f"{context} должен содержать только строки.")
    return value


def _schema_type(schema: JsonObject) -> str | None:
    schema_type = schema.get("type")
    if schema_type is None:
        return None
    if not isinstance(schema_type, str):
        raise TypeError("Поле schema.type должно быть строкой.")
    return schema_type


def _schema_properties(schema: JsonObject) -> list[tuple[str, JsonObject]]:
    return _json_object_items(schema.get("properties"), context="schema.properties")


def _schema_items(schema: JsonObject) -> JsonObject:
    return _require_json_object(schema.get("items"), context="schema.items")


def _parameter_objects(operation: JsonObject) -> list[JsonObject]:
    raw_parameters = operation.get("parameters")
    if raw_parameters is None:
        return []
    if not isinstance(raw_parameters, list):
        raise TypeError("Поле operation.parameters должно быть списком объектов.")
    return [
        _require_json_object(parameter, context="operation.parameters[]")
        for parameter in raw_parameters
    ]


def _response_or_request_type_name(op_id: str, role: str, schema: JsonObject) -> str:
    ref_value = schema.get("$ref")
    if ref_value is not None:
        if not isinstance(ref_value, str):
            raise TypeError("Поле $ref должно быть строкой.")
        return ref_value.split("/")[-1]

    schema_type = _schema_type(schema)
    if schema_type == "array":
        inner = _response_or_request_type_name(
            op_id, f"{role}Item", _schema_items(schema)
        )
        return f"list[{inner}]"
    if schema_type == "object" or schema.get("properties") is not None:
        return f"{to_pascal_case(op_id)}{role}"
    if schema.get("enum") is not None:
        return f"{to_pascal_case(op_id)}{role}Enum"
    return ""


def _collect_model_imports(*type_names: str) -> list[str]:
    imports: set[str] = set()
    for type_name in type_names:
        for candidate in re.findall(r"\b[A-Z][A-Za-z0-9_]*\b", type_name):
            imports.add(candidate)
    return sorted(imports)


class ApiGenerator:
    """Генерирует модели (Pydantic) и типизированные Step-классы API на основе OpenAPI."""

    def _load_spec(self, spec_path: str) -> JsonObject:
        path = Path(spec_path)
        if not path.exists():
            raise FileNotFoundError(f"Файл спецификации не найден: {spec_path}")

        loaded: object
        with open(path, "r", encoding="utf-8") as handle:
            if path.suffix.lower() in (".yaml", ".yml"):
                loaded = yaml.safe_load(handle)
            elif path.suffix.lower() == ".json":
                loaded = json.load(handle)
            else:
                raise ValueError(
                    f"Неподдерживаемый формат файла спецификации: {path.suffix}"
                )
        return _require_json_object(loaded, context="OpenAPI спецификация")

    def _ref_name(self, ref: str) -> str:
        if not ref.startswith("#/components/schemas/"):
            raise ValueError(
                f"Поддерживаются только $ref на components/schemas, получено: {ref}"
            )
        return ref.split("/")[-1]

    def _emit_enum(self, name: str, schema: Mapping[str, object]) -> str:
        schema_object = _require_json_object(dict(schema), context=f"schema {name}")
        base = "str" if _schema_type(schema_object) == "string" else "int"
        enum_values = schema_object.get("enum")
        if not isinstance(enum_values, list) or not enum_values:
            raise ValueError(f"Enum '{name}' должен содержать непустой массив 'enum'")

        lines = [f"class {name}({base}, Enum):"]
        for value in enum_values:
            if isinstance(value, str):
                member = to_snake_case(value).upper() or "VALUE"
                lines.append(f"    {member} = {value!r}")
                continue
            if isinstance(value, int) and not isinstance(value, bool):
                lines.append(f"    VALUE_{value} = {value}")
                continue
            raise TypeError(
                f"Enum '{name}' поддерживает только строковые и целочисленные значения."
            )
        return "\n".join(lines) + "\n"

    def _python_type(self, schema: Mapping[str, object]) -> str:
        schema_object = _require_json_object(dict(schema), context="schema")
        ref_value = schema_object.get("$ref")
        if ref_value is not None:
            if not isinstance(ref_value, str):
                raise TypeError("Поле $ref должно быть строкой.")
            return self._ref_name(ref_value)

        schema_type = _schema_type(schema_object)
        if schema_type == "string":
            return "str"
        if schema_type == "integer":
            return "int"
        if schema_type == "number":
            return "float"
        if schema_type == "boolean":
            return "bool"
        if schema_type == "array":
            return f"list[{self._python_type(_schema_items(schema_object))}]"
        if schema_type == "object":
            additional_properties = schema_object.get("additionalProperties")
            if additional_properties in (None, True):
                return "dict[str, object]"
            if additional_properties == {}:
                return "dict[str, object]"
            additional_schema = _require_json_object(
                additional_properties,
                context="schema.additionalProperties",
            )
            return f"dict[str, {self._python_type(additional_schema)}]"
        if schema.get("enum") is not None:
            raise ValueError("Enum без имени модели не поддержан в этом контексте")
        raise ValueError(f"Неподдерживаемая схема: {schema_object}")

    def _emit_model(
        self,
        name: str,
        schema: Mapping[str, object],
        generated: set[str],
        models: list[str],
    ) -> None:
        schema_object = _require_json_object(dict(schema), context=f"schema {name}")
        if name in generated:
            return

        if schema_object.get("enum") is not None:
            models.append(self._emit_enum(name, schema_object))
            generated.add(name)
            return

        if (
            _schema_type(schema_object) == "object"
            or schema_object.get("properties") is not None
        ):
            properties = _schema_properties(schema_object)
            required = set(
                _string_list(schema_object.get("required"), context="schema.required")
            )
            lines = [f"class {name}(BaseModel):"]
            if not properties:
                lines.append("    pass")

            for prop_name, prop_schema in properties:
                if prop_schema.get("$ref") is not None:
                    ref_value = prop_schema.get("$ref")
                    assert isinstance(ref_value, str)
                    annotation_type = self._ref_name(ref_value)
                elif (
                    _schema_type(prop_schema) == "object"
                    and prop_schema.get("properties") is not None
                ):
                    nested_name = f"{name}{to_pascal_case(prop_name)}"
                    self._emit_model(nested_name, prop_schema, generated, models)
                    annotation_type = nested_name
                elif _schema_type(prop_schema) == "array":
                    items_schema = _schema_items(prop_schema)
                    if items_schema.get("$ref") is not None:
                        ref_value = items_schema.get("$ref")
                        assert isinstance(ref_value, str)
                        inner_type = self._ref_name(ref_value)
                    elif (
                        _schema_type(items_schema) == "object"
                        and items_schema.get("properties") is not None
                    ):
                        inner_type = f"{name}{to_pascal_case(prop_name)}Item"
                        self._emit_model(inner_type, items_schema, generated, models)
                    else:
                        inner_type = self._python_type(items_schema)
                    annotation_type = f"list[{inner_type}]"
                elif prop_schema.get("enum") is not None:
                    enum_name = f"{name}{to_pascal_case(prop_name)}Enum"
                    models.append(self._emit_enum(enum_name, prop_schema))
                    annotation_type = enum_name
                else:
                    annotation_type = self._python_type(prop_schema)

                field_name = to_snake_case(prop_name)
                if prop_name in required:
                    lines.append(f"    {field_name}: {annotation_type}")
                else:
                    lines.append(f"    {field_name}: {annotation_type} | None = None")

            models.append("\n".join(lines) + "\n")
            generated.add(name)
            return

        generated.add(name)

    def _ensure_package(self, output_path: Path) -> None:
        (output_path / "__init__.py").write_text(
            "# Generated API package\n", encoding="utf-8"
        )

    def _select_response_schema(
        self, operation: Mapping[str, object]
    ) -> JsonObject | None:
        operation_object = _require_json_object(dict(operation), context="operation")
        responses = _json_object_or_empty(
            operation_object.get("responses"), context="responses"
        )
        for code in ("200", "201", "default"):
            response = responses.get(code)
            if response is None:
                continue
            response_object = _require_json_object(
                response, context=f"responses.{code}"
            )
            content = _json_object_or_empty(
                response_object.get("content"),
                context=f"responses.{code}.content",
            )
            app_json = content.get("application/json")
            if app_json is None:
                continue
            app_json_object = _require_json_object(
                app_json, context=f"responses.{code}.content.application/json"
            )
            schema = app_json_object.get("schema")
            if schema is None:
                return None
            return _require_json_object(
                schema, context=f"responses.{code}.content.application/json.schema"
            )
        return None

    def _request_body_schema(
        self, operation: Mapping[str, object]
    ) -> JsonObject | None:
        operation_object = _require_json_object(dict(operation), context="operation")
        request_body = _json_object_or_empty(
            operation_object.get("requestBody"), context="requestBody"
        )
        content = _json_object_or_empty(
            request_body.get("content"), context="requestBody.content"
        )
        app_json = content.get("application/json")
        if app_json is None:
            return None
        app_json_object = _require_json_object(
            app_json, context="requestBody.content.application/json"
        )
        schema = app_json_object.get("schema")
        if schema is None:
            return None
        return _require_json_object(
            schema, context="requestBody.content.application/json.schema"
        )

    def _resolve_type_for_operation(
        self,
        op_id: str,
        role: str,
        schema: Mapping[str, object],
        generated: set[str],
        models: list[str],
    ) -> str:
        schema_object = _require_json_object(dict(schema), context=f"schema {role}")
        ref_value = schema_object.get("$ref")
        if ref_value is not None:
            if not isinstance(ref_value, str):
                raise TypeError("Поле $ref должно быть строкой.")
            return self._ref_name(ref_value)

        schema_type = _schema_type(schema_object)
        if schema_type == "array":
            inner = self._resolve_type_for_operation(
                op_id, f"{role}Item", _schema_items(schema_object), generated, models
            )
            return f"list[{inner}]"
        if schema_type == "object" or schema_object.get("properties") is not None:
            model_name = f"{to_pascal_case(op_id)}{role}"
            self._emit_model(model_name, schema_object, generated, models)
            return model_name
        if schema_object.get("enum") is not None:
            enum_name = f"{to_pascal_case(op_id)}{role}Enum"
            models.append(self._emit_enum(enum_name, schema_object))
            generated.add(enum_name)
            return enum_name
        return self._python_type(schema_object)

    def _parameter_type(self, parameter: Mapping[str, object]) -> str:
        schema = _require_json_object(
            parameter.get("schema"), context="parameter.schema"
        )
        return self._python_type(schema)

    def _is_required_parameter(self, parameter: Mapping[str, object]) -> bool:
        required_value = parameter.get("required")
        if required_value is None:
            return parameter.get("in") == "path"
        if not isinstance(required_value, bool):
            raise TypeError("Поле parameter.required должно быть булевым.")
        return required_value

    def _generate_step_class(
        self, path: str, method: str, operation: Mapping[str, object]
    ) -> tuple[str, str]:
        operation_object = _require_json_object(dict(operation), context="operation")
        operation_id_value = operation_object.get("operationId")
        if operation_id_value is None:
            clean_path = re.sub(r"[^a-zA-Z0-9]", "_", path)
            operation_id = f"{method.lower()}{clean_path}"
        elif isinstance(operation_id_value, str):
            operation_id = operation_id_value
        else:
            raise TypeError("Поле operationId должно быть строкой.")

        class_name = to_pascal_case(operation_id)
        file_name = f"{to_snake_case(class_name)}.py"
        is_fact = method.upper() == "GET"
        base_class = "Fact" if is_fact else "Action"

        parameters = _parameter_objects(operation_object)
        path_params = [param for param in parameters if param.get("in") == "path"]
        query_params = [param for param in parameters if param.get("in") == "query"]
        header_params = [param for param in parameters if param.get("in") == "header"]

        summary_value = operation_object.get("summary")
        if summary_value is None:
            summary = f"Выполняет {method.upper()} {path}"
        elif isinstance(summary_value, str):
            summary = summary_value
        else:
            raise TypeError("Поле summary должно быть строкой.")

        formatted_path = path
        for parameter in path_params:
            param_name = parameter.get("name")
            if not isinstance(param_name, str):
                raise TypeError("Имя path-параметра должно быть строкой.")
            formatted_path = formatted_path.replace(
                f"{{{param_name}}}", f"{{self.{to_snake_case(param_name)}}}"
            )

        response_schema = self._select_response_schema(operation_object)
        response_type = "object"
        if response_schema is not None:
            response_type_name = _response_or_request_type_name(
                operation_id, "Response", response_schema
            )
            response_type = response_type_name or self._python_type(response_schema)

        request_schema = self._request_body_schema(operation_object)
        request_type: str | None = None
        if request_schema is not None:
            request_type_name = _response_or_request_type_name(
                operation_id, "Request", request_schema
            )
            request_type = request_type_name or self._python_type(request_schema)

        imports = [
            f"from persona_dsl.components.{'fact' if is_fact else 'action'} import {base_class}",
            "from persona_dsl.ops.api import JsonAs",
            "from persona_dsl.persona import Persona",
        ]
        model_imports = _collect_model_imports(response_type, request_type or "")
        if model_imports:
            imports.append("from .models import " + ", ".join(model_imports))
        imports_block = "\n".join(imports)

        init_args: list[str] = []
        init_body: list[str] = []
        for parameter in path_params + query_params + header_params:
            param_name = parameter.get("name")
            if not isinstance(param_name, str):
                raise TypeError("Имя параметра операции должно быть строкой.")
            python_name = to_snake_case(param_name)
            param_type = self._parameter_type(parameter)
            if self._is_required_parameter(parameter):
                init_args.append(f"{python_name}: {param_type}")
            else:
                init_args.append(f"{python_name}: {param_type} | None = None")
            init_body.append(f"        self.{python_name} = {python_name}")
        if request_type is not None:
            init_args.append(f"json_body: {request_type}")
            init_body.append("        self.json_body = json_body")

        if init_args:
            init_signature = ", ".join(["self", *init_args])
            init_lines = [f"    def __init__({init_signature}) -> None:"]
            init_lines.extend(init_body)
        else:
            init_lines = [
                "    def __init__(self) -> None:",
                "        pass",
            ]

        perform_args = [
            "        return JsonAs(",
            f"            method={method.upper()!r},",
            f"            path=f{formatted_path!r},",
            f"            model_type={response_type},",
        ]
        if query_params:
            params_dict = ", ".join(
                [
                    f"{parameter['name']!r}: self.{to_snake_case(str(parameter['name']))}"
                    for parameter in query_params
                ]
            )
            perform_args.append(f"            params={{ {params_dict} }},")
        if header_params:
            headers_dict = ", ".join(
                [
                    f"{parameter['name']!r}: self.{to_snake_case(str(parameter['name']))}"
                    for parameter in header_params
                ]
            )
            perform_args.append(f"            headers={{ {headers_dict} }},")
        if request_type is not None:
            perform_args.append("            json=self.json_body,")
        perform_args.append("        ).execute(persona)")

        lines = [
            imports_block,
            "",
            f"class {class_name}({base_class}):",
            '    """',
            f"    {summary}",
            '    """',
            "",
            *init_lines,
            "",
            "    def _get_step_description(self, persona: Persona) -> str:",
            f'        return f"{{persona}} {summary.lower()}"',
            "",
            "    def _perform(",
            "        self,",
            "        persona: Persona,",
            "        *args: object,",
            "        **kwargs: object,",
            "    ) -> object:",
            *perform_args,
            "",
        ]
        return file_name, "\n".join(lines)

    def generate_from_spec(self, spec_path: str, output_dir: str) -> None:
        spec = self._load_spec(spec_path)
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        self._ensure_package(output_path)

        generated: set[str] = set()
        models: list[str] = [
            "# Generated models\n",
            "from enum import Enum\n",
            "from pydantic import BaseModel\n",
            "\n",
        ]

        components = _json_object_or_empty(spec.get("components"), context="components")
        for name, schema in _json_object_items(
            components.get("schemas"), context="components.schemas"
        ):
            self._emit_model(name, schema, generated, models)

        for path, path_item in _json_object_items(spec.get("paths"), context="paths"):
            for method, operation in path_item.items():
                if method.lower() not in _SUPPORTED_METHODS:
                    continue
                operation_object = _require_json_object(
                    operation, context=f"paths.{path}.{method}"
                )
                operation_id_value = operation_object.get("operationId")
                if operation_id_value is not None and not isinstance(
                    operation_id_value, str
                ):
                    raise TypeError("Поле operationId должно быть строкой.")
                op_id = operation_id_value or (
                    f"{method.lower()}_"
                    f"{to_snake_case(path.strip('/').replace('/', '_'))}"
                )
                assert isinstance(op_id, str)

                response_schema = self._select_response_schema(operation_object)
                if response_schema is not None:
                    self._resolve_type_for_operation(
                        op_id, "Response", response_schema, generated, models
                    )
                request_schema = self._request_body_schema(operation_object)
                if request_schema is not None:
                    self._resolve_type_for_operation(
                        op_id, "Request", request_schema, generated, models
                    )

        (output_path / "models.py").write_text("\n".join(models), encoding="utf-8")
        print(f"Генерация API Steps из '{spec_path}' в '{output_dir}'...")

        for path, path_item in _json_object_items(spec.get("paths"), context="paths"):
            for method, operation in path_item.items():
                if method.lower() not in _SUPPORTED_METHODS:
                    continue
                operation_object = _require_json_object(
                    operation, context=f"paths.{path}.{method}"
                )
                try:
                    file_name, code = self._generate_step_class(
                        path, method, operation_object
                    )
                    (output_path / file_name).write_text(code, encoding="utf-8")
                    print(f"  - Создан файл: {file_name}")
                except (
                    AttributeError,
                    KeyError,
                    OSError,
                    TypeError,
                    ValueError,
                ) as error:
                    print(f"  - Ошибка генерации для {method.upper()} {path}: {error}")

        print("Генерация завершена.")
