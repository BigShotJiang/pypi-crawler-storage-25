import argparse
from copy import deepcopy
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

import yaml

from persona_dsl.json_types import JsonValue, is_json_value
from persona_dsl.ops.web.rich_aria_snapshot import enrich_snapshot_with_dynamic_options
from persona_dsl.utils.naming import to_pascal_case, to_snake_case
from unidecode import unidecode

from .api_generator import ApiGenerator
from .page.contracts import ObjectMap, SnapshotNodeList, as_object_map
from .page.generator import PageGenerator
from .schema import XsdGenerator

ENV_FILE_NAME = ".persona_gen.env"
ENV_KEY_HEADLESS = "PERSONA_GEN_HEADLESS"
ENV_KEY_BROWSER_EXEC = "PERSONA_GEN_BROWSER_EXECUTABLE"
ENV_KEY_DEFAULT_URL = "PERSONA_GEN_DEFAULT_URL"
_RUNTIME_BUNDLE_PATH = (
    Path(__file__).parent.parent / "runtime" / "dist" / "persona_bundle.js"
)
_ENTRYPOINT_TO_MAIN = {
    "persona-page-gen": "page",
    "persona-api-gen": "api",
    "persona-schema-gen": "xsd",
}
_ALLOWED_ENV_KEYS = frozenset(
    {
        ENV_KEY_HEADLESS,
        ENV_KEY_BROWSER_EXEC,
        ENV_KEY_DEFAULT_URL,
    }
)


@dataclass(slots=True)
class GeneratorEnvConfig:
    headless: bool = True
    browser_executable: str | None = None
    default_url: str | None = None


@dataclass(slots=True)
class SnapshotAssets:
    aria_snapshot_path: str | None = None
    screenshot_path: str | None = None
    axtree_snapshot_path: str | None = None


def _prompt_non_empty(prompt: str, default: str | None = None) -> str:
    while True:
        raw = input(prompt).strip()
        if raw:
            return raw
        if default is not None:
            return default
        print("Значение не может быть пустым. Повторите ввод.")


def _prompt_yes_no(prompt: str, default: bool = True) -> bool:
    suffix = "[Y/n]" if default else "[y/N]"
    while True:
        raw = input(f"{prompt} {suffix}: ").strip().lower()
        if not raw:
            return default
        if raw in ("y", "yes"):
            return True
        if raw in ("n", "no"):
            return False
        print("Введите 'y' или 'n'.")


def _suggest_class_name_from_title(title: str | None) -> str:
    if title:
        ascii_title = unidecode(title)
        candidate = to_pascal_case(ascii_title)
        if not candidate:
            candidate = "Generated"
        if not candidate.endswith("Page"):
            candidate += "Page"
        return candidate
    return "GeneratedPage"


def _normalize_optional_text(value: str) -> str | None:
    normalized = value.strip()
    return normalized or None


def _parse_env_bool(raw_value: str, *, env_path: Path, line_number: int) -> bool:
    normalized = raw_value.strip().lower()
    if normalized == "true":
        return True
    if normalized == "false":
        return False
    raise ValueError(
        f"Некорректное булево значение в {env_path}:{line_number} для {ENV_KEY_HEADLESS}: "
        f"ожидается 'true' или 'false', получено {raw_value!r}."
    )


def _load_env_config(env_path: Path) -> GeneratorEnvConfig:
    if not env_path.exists():
        return GeneratorEnvConfig()
    if not env_path.is_file():
        raise ValueError(f"Путь настроек {env_path} должен указывать на файл.")

    config = GeneratorEnvConfig()
    seen_keys: set[str] = set()
    with open(env_path, "r", encoding="utf-8") as handle:
        for line_number, raw_line in enumerate(handle, start=1):
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                raise ValueError(
                    f"Некорректная строка в {env_path}:{line_number}: ожидается KEY=VALUE."
                )
            key, raw_value = line.split("=", 1)
            env_key = key.strip()
            if not env_key:
                raise ValueError(
                    f"Пустое имя ключа в {env_path}:{line_number} недопустимо."
                )
            if env_key not in _ALLOWED_ENV_KEYS:
                raise ValueError(
                    f"Неизвестный ключ {env_key!r} в {env_path}:{line_number}."
                )
            if env_key in seen_keys:
                raise ValueError(
                    f"Дублирующийся ключ {env_key!r} в {env_path}:{line_number}."
                )
            seen_keys.add(env_key)

            if env_key == ENV_KEY_HEADLESS:
                config.headless = _parse_env_bool(
                    raw_value,
                    env_path=env_path,
                    line_number=line_number,
                )
            elif env_key == ENV_KEY_BROWSER_EXEC:
                config.browser_executable = _normalize_optional_text(raw_value)
            elif env_key == ENV_KEY_DEFAULT_URL:
                config.default_url = _normalize_optional_text(raw_value)

    return config


def _save_env_config(env_path: Path, cfg: GeneratorEnvConfig) -> None:
    lines = [
        "# Persona DSL Generators settings\n",
        f"{ENV_KEY_HEADLESS}={'true' if cfg.headless else 'false'}\n",
        f"{ENV_KEY_BROWSER_EXEC}={cfg.browser_executable or ''}\n",
        f"{ENV_KEY_DEFAULT_URL}={cfg.default_url or ''}\n",
    ]
    env_path.parent.mkdir(parents=True, exist_ok=True)
    with open(env_path, "w", encoding="utf-8") as handle:
        handle.writelines(lines)
    print(f"Настройки сохранены в {env_path}")


def _validate_transport_snapshot(raw_snapshot: object) -> SnapshotNodeList | ObjectMap:
    object_map = as_object_map(raw_snapshot)
    if object_map is not None:
        if not object_map:
            raise ValueError("ARIA-снепшот transport пустой.")
        return object_map

    if not isinstance(raw_snapshot, list):
        raise TypeError(
            "ARIA-снепшот transport должен быть объектом или списком узлов."
        )

    snapshot_items: SnapshotNodeList = []
    for index, item in enumerate(raw_snapshot):
        if isinstance(item, str):
            snapshot_items.append(item)
            continue
        child_map = as_object_map(item)
        if child_map is None:
            raise TypeError(
                f"ARIA-снепшот transport содержит некорректный узел по индексу {index}: "
                f"ожидается строка или объект."
            )
        snapshot_items.append(child_map)

    if not snapshot_items:
        raise ValueError("ARIA-снепшот transport пустой.")
    return snapshot_items


def _validate_json_payload(payload: object, *, label: str) -> JsonValue:
    if not is_json_value(payload):
        raise TypeError(f"{label} должен быть сериализуемым JSON/YAML-значением.")
    return payload


def _require_display_for_headed_mode(headless: bool) -> None:
    if not headless and not os.environ.get("DISPLAY"):
        raise RuntimeError(
            "Графический интерфейс (DISPLAY) недоступен. Для headed-режима требуется X-сервер."
        )


def _resolve_output_confirmation(output_path: Path) -> Path:
    final_output = input(
        f"Сохранить этот код в файл '{output_path}'? [Y/n] (или укажите другой путь): "
    ).strip()
    if final_output and final_output.lower() not in ("y", "yes", "n", "no"):
        candidate_path = Path(final_output)
        save_confirm = (
            input(f"Подтвердите сохранение в '{candidate_path}' [Y/n]: ")
            .lower()
            .strip()
            or "y"
        )
        if save_confirm not in ("y", "yes"):
            print("Сохранение отменено.")
            raise SystemExit(0)
        return candidate_path
    if not final_output or final_output.lower() in ("y", "yes"):
        return output_path
    print("Сохранение отменено.")
    raise SystemExit(0)


def page_main() -> None:
    """Entry point для persona-page-gen (интерактивный при отсутствии аргументов)."""
    parser = argparse.ArgumentParser(
        description="Генерация класса Page из ARIA-снепшота открытой страницы."
    )
    parser.add_argument("--url", help="URL страницы для анализа.")
    parser.add_argument(
        "--output-path", help="Путь для сохранения сгенерированного Python-файла."
    )
    parser.add_argument("--class-name", help="Имя для генерируемого класса страницы.")
    parser.add_argument(
        "--env-file",
        help=f"Путь к env-файлу настроек (по умолчанию ./{ENV_FILE_NAME}).",
    )
    args = parser.parse_args()

    try:
        from playwright.sync_api import (
            Error as PlaywrightError,
            TimeoutError as PlaywrightTimeoutError,
            sync_playwright,
        )
    except ImportError:
        print(
            "Ошибка: 'playwright' не установлен. Пожалуйста, установите его: pip install playwright",
            file=sys.stderr,
        )
        sys.exit(1)

    try:
        env_path = Path(args.env_file) if args.env_file else Path.cwd() / ENV_FILE_NAME
        config = _load_env_config(env_path)

        headless = _prompt_yes_no(
            "Запускать браузер в фоне (headless)?",
            default=config.headless,
        )
        _require_display_for_headed_mode(headless)

        current_exec = config.browser_executable or ""
        browser_executable_raw = input(
            "Укажите путь к исполняемому файлу браузера для Playwright "
            "(пусто — использовать встроенный):\n"
            f"[Текущее значение: '{current_exec or 'не задано'}'] "
            "Введите новое значение или оставьте пустым: "
        ).strip()
        browser_executable = (
            _normalize_optional_text(browser_executable_raw)
            or config.browser_executable
        )

        save_aria = _prompt_yes_no(
            "Сохранить ARIA-снепшот в отдельный файл?",
            default=True,
        )
        save_screenshot = _prompt_yes_no(
            "Сделать и сохранить скриншот страницы?",
            default=False,
        )

        config = GeneratorEnvConfig(
            headless=headless,
            browser_executable=browser_executable,
            default_url=config.default_url,
        )
        _save_env_config(env_path, config)

        url = args.url or _prompt_non_empty(
            f"Введите URL страницы для анализа [по умолчанию: '{config.default_url or 'не задан'}']: ",
            default=config.default_url,
        )

        config.default_url = url
        _save_env_config(env_path, config)

        print(f"Открытие страницы {url} в браузере...")
        with sync_playwright() as playwright_context:
            if browser_executable is None:
                browser = playwright_context.chromium.launch(headless=headless)
            else:
                browser = playwright_context.chromium.launch(
                    headless=headless,
                    executable_path=browser_executable,
                )
            page = browser.new_page()
            try:
                try:
                    page.goto(url, wait_until="domcontentloaded", timeout=60000)
                except (PlaywrightError, PlaywrightTimeoutError) as exc:
                    raise RuntimeError(
                        f"Не удалось открыть страницу {url}: {exc}"
                    ) from exc

                print("Страница открыта. Вы можете взаимодействовать с ней.")

                suggested_class_name = (
                    args.class_name or _suggest_class_name_from_title(page.title())
                )
                class_name = args.class_name or _prompt_non_empty(
                    f"Введите имя класса страницы [по умолчанию: {suggested_class_name}]: ",
                    default=suggested_class_name,
                )

                default_output = Path("tests/pages") / f"{to_snake_case(class_name)}.py"
                output_path_arg = args.output_path or _prompt_non_empty(
                    f"Введите путь для сохранения Python-файла [по умолчанию: {default_output}]: ",
                    default=str(default_output),
                )
                output_path = Path(output_path_arg)

                confirm_params = (
                    input(
                        "\nПараметры генерации:\n"
                        f"- Headless:           {headless}\n"
                        f"- Browser exe:        {browser_executable or 'builtin'}\n"
                        f"- URL:                {url}\n"
                        f"- Class name:         {class_name}\n"
                        f"- Output path:        {output_path}\n"
                        f"- Save ARIA snapshot: {save_aria}\n"
                        f"- Save screenshot:    {save_screenshot}\n"
                        "Продолжить с этими параметрами? [Y/n]: "
                    )
                    .lower()
                    .strip()
                    or "y"
                )
                if confirm_params not in ("y", "yes"):
                    print("Отменено пользователем.")
                    sys.exit(0)

                input(
                    "Нажмите Enter в этой консоли, когда будете готовы сделать ARIA-снепшот..."
                )

                print("Ожидание полной загрузки страницы (networkidle)...")
                try:
                    page.wait_for_load_state("networkidle", timeout=60000)
                except (PlaywrightError, PlaywrightTimeoutError) as exc:
                    raise RuntimeError(
                        f"Не удалось дождаться состояния 'networkidle': {exc}"
                    ) from exc

                print("Создание ARIA-снепшота transport...")
                runtime_path = _RUNTIME_BUNDLE_PATH
                if not runtime_path.exists():
                    raise FileNotFoundError(
                        f"Persona Runtime не найден по пути {runtime_path}."
                    )
                js_content = runtime_path.read_text(encoding="utf-8")
                try:
                    page.evaluate(js_content)
                except (PlaywrightError, PlaywrightTimeoutError) as exc:
                    raise RuntimeError(
                        f"Не удалось внедрить Persona Runtime: {exc}"
                    ) from exc

                try:
                    raw_snapshot = page.evaluate(
                        "window.__PERSONA__ && window.__PERSONA__.getTreeForTransport()"
                    )
                except (PlaywrightError, PlaywrightTimeoutError) as exc:
                    raise RuntimeError(
                        f"Не удалось получить ARIA-снепшот transport: {exc}"
                    ) from exc
                snapshot = _validate_transport_snapshot(raw_snapshot)
                print(
                    f"Получен ARIA-снепшот transport (тип: {type(snapshot).__name__})"
                )

                try:
                    axtree = _validate_json_payload(
                        page.accessibility.snapshot(),
                        label="AXTree snapshot",
                    )
                except (PlaywrightError, PlaywrightTimeoutError) as exc:
                    raise RuntimeError(
                        f"Не удалось получить AXTree snapshot: {exc}"
                    ) from exc
                print("AXTree snapshot получен.")

                assets = SnapshotAssets()
                assets_dir = output_path.parent / "aria"
                assets_dir.mkdir(parents=True, exist_ok=True)

                if save_screenshot:
                    screenshot_file = f"{output_path.stem}_screenshot.png"
                    screenshot_abs_path = assets_dir / screenshot_file
                    try:
                        page.screenshot(path=screenshot_abs_path, full_page=True)
                    except (PlaywrightError, PlaywrightTimeoutError) as exc:
                        raise RuntimeError(
                            f"Не удалось сохранить скриншот страницы: {exc}"
                        ) from exc
                    assets.screenshot_path = f"aria/{screenshot_file}"
                    print(f"Скриншот сохранен: {screenshot_abs_path}")

                if save_aria:
                    snapshot_file = f"{output_path.stem}_snapshot.yaml"
                    snapshot_abs_path = assets_dir / snapshot_file
                    with open(snapshot_abs_path, "w", encoding="utf-8") as handle:
                        yaml.safe_dump(
                            snapshot,
                            handle,
                            default_flow_style=False,
                            allow_unicode=True,
                            sort_keys=False,
                        )
                    assets.aria_snapshot_path = f"aria/{snapshot_file}"
                    print(f"ARIA-снепшот сохранен: {snapshot_abs_path}")

                    axtree_file = f"{output_path.stem}_axtree.yaml"
                    axtree_abs_path = assets_dir / axtree_file
                    with open(axtree_abs_path, "w", encoding="utf-8") as handle:
                        yaml.safe_dump(
                            axtree,
                            handle,
                            default_flow_style=False,
                            allow_unicode=True,
                            sort_keys=False,
                        )
                    assets.axtree_snapshot_path = f"aria/{axtree_file}"
                    print(f"AXTree-снепшот сохранен: {axtree_abs_path}")
            finally:
                browser.close()

        generation_snapshot = deepcopy(snapshot)
        enrich_snapshot_with_dynamic_options(page, generation_snapshot)

        generator = PageGenerator()
        page_path = urlparse(url).path
        existing_code = (
            output_path.read_text(encoding="utf-8") if output_path.exists() else None
        )
        generated_code = generator.generate_or_update_from_aria_snapshot(
            snapshot=generation_snapshot,
            class_name=class_name,
            page_path=page_path,
            aria_snapshot_path=assets.aria_snapshot_path,
            screenshot_path=assets.screenshot_path,
            existing_code=existing_code,
        )

        print("\n--- Сгенерированный код ---")
        print(generated_code)
        print("---------------------------\n")

        output_path = _resolve_output_confirmation(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(generated_code)
        print(f"Код успешно сохранен в {output_path}")
    except (
        FileNotFoundError,
        IsADirectoryError,
        OSError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as e:
        print(f"Ошибка: {e}", file=sys.stderr)
        sys.exit(1)


def api_main() -> None:
    """Entry point для persona-api-gen (интерактивные вопросы при отсутствии аргументов)."""
    parser = argparse.ArgumentParser(
        description="Генерация API Steps из спецификации OpenAPI."
    )
    parser.add_argument(
        "--spec", help="Путь к файлу спецификации OpenAPI (YAML или JSON)."
    )
    parser.add_argument(
        "--output-dir", help="Директория для сохранения сгенерированных файлов."
    )
    args = parser.parse_args()
    interactive = args.spec is None or args.output_dir is None

    spec_path_str = args.spec or _prompt_non_empty(
        "Введите путь к спецификации OpenAPI (YAML/JSON): "
    )
    spec_path = Path(spec_path_str)
    while not spec_path.exists() or not spec_path.is_file():
        print(f"Файл не найден: {spec_path}")
        spec_path_str = _prompt_non_empty(
            "Укажите корректный путь к спецификации OpenAPI: "
        )
        spec_path = Path(spec_path_str)

    output_dir_str = args.output_dir or _prompt_non_empty(
        "Введите директорию для генерации файлов (например, tests/api_steps): "
    )
    output_dir = Path(output_dir_str)

    print("\nПараметры генерации:")
    print(f"- Spec:       {spec_path}")
    print(f"- Output dir: {output_dir}")
    if interactive:
        confirm = input("Продолжить? [Y/n]: ").lower().strip() or "y"
        if confirm not in ("y", "yes"):
            print("Отменено пользователем.")
            sys.exit(0)

    generator = ApiGenerator()
    try:
        generator.generate_from_spec(
            spec_path=str(spec_path), output_dir=str(output_dir)
        )
        print("Завершено.")
    except (FileNotFoundError, ValueError) as e:
        print(f"Ошибка: {e}", file=sys.stderr)
        sys.exit(1)


def schema_main() -> None:
    """Entry point для persona-schema-gen."""
    parser = argparse.ArgumentParser(
        description="Генерация schema-first моделей и builders из XSD."
    )
    subparsers = parser.add_subparsers(dest="command")

    xsd_parser = subparsers.add_parser(
        "xsd",
        help="Генерация Python package из XSD схемы.",
    )
    xsd_parser.add_argument("--schema", help="Путь к XSD схеме.")
    xsd_parser.add_argument(
        "--output-dir",
        help=(
            "Директория генерации. Без --package это финальная директория generated package, "
            "с --package это корень, внутри которого будет создан package."
        ),
    )
    xsd_parser.add_argument(
        "--package",
        help="Необязательное имя Python package для generated кода.",
    )

    args = parser.parse_args()
    if args.command != "xsd":
        parser.print_help()
        sys.exit(1)
    interactive = args.schema is None or args.output_dir is None

    schema_path_str = args.schema or _prompt_non_empty("Введите путь к XSD схеме: ")
    schema_path = Path(schema_path_str)
    while not schema_path.exists() or not schema_path.is_file():
        print(f"Файл не найден: {schema_path}")
        schema_path_str = _prompt_non_empty("Укажите корректный путь к XSD схеме: ")
        schema_path = Path(schema_path_str)

    output_dir_str = args.output_dir or _prompt_non_empty(
        "Введите директорию для generated package: "
    )
    output_dir = Path(output_dir_str)

    package_name = args.package.strip() if args.package else None

    print("\nПараметры генерации:")
    print(f"- Schema:     {schema_path}")
    print(f"- Output dir: {output_dir}")
    if package_name is None:
        print(f"- Package:    <auto: {output_dir.name}>")
    else:
        print(f"- Package:    {package_name}")
    if interactive:
        confirm = input("Продолжить? [Y/n]: ").lower().strip() or "y"
        if confirm not in ("y", "yes"):
            print("Отменено пользователем.")
            sys.exit(0)

    generator = XsdGenerator()
    try:
        generator.generate_from_schema(
            schema_path=str(schema_path),
            output_dir=str(output_dir),
            package=package_name,
        )
        print("Завершено.")
    except (FileNotFoundError, RuntimeError, TypeError, ValueError) as error:
        print(f"Ошибка: {error}", file=sys.stderr)
        sys.exit(1)


def main() -> None:
    """Универсальная точка входа для модульного запуска генераторов."""
    program_name = Path(sys.argv[0]).name.removesuffix(".exe")
    command = _ENTRYPOINT_TO_MAIN.get(program_name)
    if command is None and len(sys.argv) > 1:
        command = sys.argv[1]

    if command == "page":
        if len(sys.argv) > 1 and sys.argv[1] == "page":
            del sys.argv[1]
        page_main()
        return
    if command == "api":
        if len(sys.argv) > 1 and sys.argv[1] == "api":
            del sys.argv[1]
        api_main()
        return
    if command == "xsd":
        if len(sys.argv) > 1 and sys.argv[1] == "xsd":
            del sys.argv[1]
        schema_main()
        return

    print(
        "Ошибка: используйте явную команду генератора: " "'page', 'api' или 'xsd'.",
        file=sys.stderr,
    )
    sys.exit(1)


if __name__ == "__main__":
    main()
