from __future__ import annotations

import os
import re

from .contracts import PageElementNode, as_object_map, get_element_children, get_str
from .utils import sanitize_name


def clean_header_text(name: str) -> str:
    """Removes common ARIA control noise (like sort icons or filters) from header names."""
    if not name:
        return name

    noise_patterns = [
        r"close-circle",
        r"search",
        r"Increase Value",
        r"Decrease Value",
        r"clock-circle",
        r"caret-up",
        r"caret-down",
        r"filter",
        r"—\s*$",
        r"^\s*—",
    ]

    cleaned = name
    for pattern in noise_patterns:
        cleaned = re.sub(pattern, "", cleaned, flags=re.IGNORECASE)

    return re.sub(r"\s+", " ", cleaned).strip()


def identify_table_prototypes(elements: list[PageElementNode]) -> None:
    """
    Analyzes Tables to detect repetitive Row patterns.
    If found, marks the Table as having a prototype and cleans up children.
    """
    for el in elements:
        role = get_str(el, "role")
        children = get_element_children(el)

        # Recurse
        if children:
            identify_table_prototypes(children)

        if role in ("table", "grid") and children:
            # Look for 'row' elements (could be direct or inside rowgroup)
            rows = []
            rowgroups = [c for c in children if get_str(c, "role") == "rowgroup"]
            direct_rows = [c for c in children if get_str(c, "role") == "row"]

            rows.extend(direct_rows)
            for rg in rowgroups:
                rows.extend(
                    [c for c in get_element_children(rg) if get_str(c, "role") == "row"]
                )

            # Filter out "header" rows (usually <th> inside).
            data_rows = []
            header_rows = []
            for r in rows:
                cells = get_element_children(r)
                has_headers = any(get_str(c, "role") == "columnheader" for c in cells)
                if has_headers:
                    header_rows.append(r)
                else:
                    data_rows.append(r)

            # Fallback for weird ARIA tables (like ag-grid) where ALL cells are marked as "columnheader".
            # If we found multiple rows but NO data rows, assume the first row is the header and the rest are data.
            if len(data_rows) == 0 and len(header_rows) > 1:
                data_rows = header_rows[1:]
                header_rows = [header_rows[0]]

            if len(data_rows) == 0 and len(header_rows) >= 1:
                # Potential Header-Only Table (Half of a Split-Table)
                el["is_header_only_table"] = True
                extracted: list[str] = []
                for hr in header_rows:
                    for cell in get_element_children(hr):
                        h_name = _get_label_value(cell)
                        h_name = clean_header_text(h_name)
                        if h_name:
                            extracted.append(h_name)
                el["extracted_headers"] = extracted

            if len(data_rows) >= 1:
                # Pick the last data row as prototype
                prototype_row = data_rows[-1]

                # Mark Table
                el["has_row_prototype"] = True
                el["row_prototype"] = prototype_row
                # Remove class_name_ref and is_complex_section forcing from Table elements so they stay flat.
                if "class_name_ref" in el:
                    del el["class_name_ref"]
                if "is_complex_section" in el:
                    del el["is_complex_section"]

                # SEMANTIC NAMING: Map Prototype Cells to Headers
                header_row = None
                if len(rows) > len(data_rows):
                    for r in rows:
                        if r not in data_rows:
                            cells = get_element_children(r)
                            if any(get_str(c, "role") == "columnheader" for c in cells):
                                header_row = r
                                break

                headers: list[str] = []
                if header_row and prototype_row:
                    # Extract Column Names
                    h_cells = get_element_children(header_row)
                    for cell in h_cells:
                        h_name = _get_label_value(cell)
                        h_name = clean_header_text(h_name)
                        if h_name:
                            headers.append(h_name)

                    # Set Enum Metadata for CodeGen
                    if headers:
                        el["has_columns_enum"] = True
                        el["columns_values"] = headers

                # Apply to Prototype (Always)
                p_cells = get_element_children(prototype_row)

                for i, cell in enumerate(p_cells):
                    if i < len(headers):
                        h_name = headers[i]
                        if h_name:
                            semantic_name = sanitize_name(h_name)

                            # Update cell definitions
                            cell["var_name"] = semantic_name
                            cell["name"] = semantic_name

                            init_kwargs = as_object_map(cell.get("init_kwargs"))
                            if init_kwargs is not None:
                                init_kwargs["name"] = semantic_name
                                if "accessible_name" in init_kwargs:
                                    del init_kwargs["accessible_name"]

                                # ADD ROBUST COLUMN HEADER
                                init_kwargs["column_header"] = h_name

                                # Remove index
                                if "index" in init_kwargs:
                                    del init_kwargs["index"]

                # Recursive Generalization of Internals
                for i, p_cell in enumerate(p_cells):
                    corresponding_cells = []
                    for r in data_rows:
                        r_children = get_element_children(r)
                        if i < len(r_children):
                            corresponding_cells.append(r_children[i])

                    generalize_children(p_cell, corresponding_cells)

                # Clean up children: remove generated rows and rowgroups from the table itself
                new_children = []
                for child in children:
                    c_role = get_str(child, "role")
                    if c_role in ("row", "rowgroup"):
                        continue
                    new_children.append(child)
                el["children"] = new_children

                # ALSO clean up rows from any rowgroups
                for rg in rowgroups:
                    rg_children = get_element_children(rg)
                    new_rg_children = []
                    for child in rg_children:
                        c_role = get_str(child, "role")
                        if c_role == "row":
                            continue
                        new_rg_children.append(child)
                    rg["children"] = new_rg_children

    # --- Split Table Merge Heuristic ---
    # Ant Design and others render Fixed Headers as one Table, and Data as a second Table.
    # If we find a Table with headers but no data, followed by a Table with data but no headers, merge their definitions!
    for i in range(len(elements) - 1):
        el1 = elements[i]
        el2 = elements[i + 1]

        if get_str(el1, "role") in ("table", "grid") and get_str(el2, "role") in (
            "table",
            "grid",
        ):
            if (
                el1.get("is_header_only_table")
                and el2.get("has_row_prototype")
                and not el2.get("has_columns_enum")
            ):
                # Transfer the headers from el1 to el2
                headers_obj = el1.get("extracted_headers")
                headers = (
                    [value for value in headers_obj if isinstance(value, str)]
                    if isinstance(headers_obj, list)
                    else []
                )
                if headers:
                    el2["has_columns_enum"] = True
                    el2["columns_values"] = headers

                    # We should also prune el1 so it doesn't generate a massive tree of raw headers!
                    el1["children"] = []
                    el1["is_header_only_table"] = False  # Handled

                    # Propagate semantic naming to el2's prototype
                    prototype_row_map = as_object_map(el2.get("row_prototype"))
                    if prototype_row_map is not None:
                        p_cells = get_element_children(prototype_row_map)
                        for idx, cell in enumerate(p_cells):
                            if idx < len(headers):
                                h_name = headers[idx]
                                if h_name:
                                    semantic_name = sanitize_name(h_name)
                                    cell["var_name"] = semantic_name
                                    cell["name"] = semantic_name
                                    init_kwargs = as_object_map(cell.get("init_kwargs"))
                                    if init_kwargs is not None:
                                        init_kwargs["name"] = semantic_name
                                        if "accessible_name" in init_kwargs:
                                            del init_kwargs["accessible_name"]
                                        init_kwargs["column_header"] = h_name
                                        if "index" in init_kwargs:
                                            del init_kwargs["index"]


def generalize_children(
    proto_el: PageElementNode, other_els: list[PageElementNode]
) -> None:
    p_children = get_element_children(proto_el)
    if not p_children:
        return

    for idx, p_child in enumerate(p_children):
        counterparts: list[PageElementNode] = []
        for other in other_els:
            o_children = get_element_children(other)
            if idx < len(o_children):
                counterparts.append(o_children[idx])

        if not counterparts:
            continue

        def get_acc(el: PageElementNode) -> str:
            accessible_name = get_str(el, "accessible_name")
            if accessible_name:
                return accessible_name
            init_kwargs = as_object_map(el.get("init_kwargs"))
            if init_kwargs is not None:
                init_accessible_name = get_str(init_kwargs, "accessible_name")
                if init_accessible_name:
                    return init_accessible_name
            text_value = get_str(el, "text")
            if text_value:
                return text_value
            return ""

        acc_names = [get_acc(p_child)] + [get_acc(c) for c in counterparts]
        acc_names = [a for a in acc_names if a]

        if not acc_names:
            generalize_children(p_child, counterparts)
            continue

        common = os.path.commonprefix(acc_names).strip()

        if len(common) >= 3:
            p_child["accessible_name"] = common
            init_kwargs = as_object_map(p_child.get("init_kwargs"))
            if init_kwargs is not None:
                init_kwargs["accessible_name"] = common

            new_name = sanitize_name(common)
            p_child["name"] = new_name
            p_child["var_name"] = new_name
            if init_kwargs is not None:
                init_kwargs["name"] = new_name
        else:
            p_child["accessible_name"] = None
            init_kwargs = as_object_map(p_child.get("init_kwargs"))
            if init_kwargs is not None and "accessible_name" in init_kwargs:
                del init_kwargs["accessible_name"]

        generalize_children(p_child, counterparts)


def _get_label_value(node: PageElementNode) -> str:
    accessible_name = get_str(node, "accessible_name")
    if accessible_name:
        return accessible_name
    name = get_str(node, "name")
    if name:
        return name
    return ""
