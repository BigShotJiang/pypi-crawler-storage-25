from __future__ import annotations

from collections import OrderedDict

import black

from persona_dsl.editors.page import PageEditor
from persona_dsl.pages.elements import Element
from persona_dsl.utils.naming import to_pascal_case, to_snake_case

from .contracts import (
    ExistingEnums,
    ObjectMap,
    PageElementNode,
    as_str_list,
    get_element_children,
    get_str,
    require_object_map,
    require_str,
)
from .enum_storage import EnumStorage

_REPEATED_INLINE_SCOPE_KWARGS = frozenset(
    {
        "accessible_name",
        "text",
        "label",
        "placeholder",
        "test_id",
        "alt_text",
        "title",
        "html_name",
        "locator",
        "exact",
        "description",
        "static_screenshot_path",
        "static_aria_snapshot_path",
        "aria_ref",
        "url",
        "role",
    }
)


class DeclarativeCodeGenerator:
    """
    Рендерит page object'ы в declarative-стиле через class attrs.

    Генератор больше не выпускает procedural `__init__` с `self.add_element(...)`
    для обычных страниц. В коде остаются только class attrs и top-level helper classes.
    """

    def __init__(self, debug_mode: bool = False) -> None:
        self.debug_mode = debug_mode
        self._required_imports: set[str] = set()
        self._custom_imports: dict[str, set[str]] = {}
        self._generated_wrappers: OrderedDict[str, list[str]] = OrderedDict()
        self._wrapper_signatures: dict[str, tuple[str, tuple[str, ...]]] = {}
        self._synthetic_enums: OrderedDict[str, list[str]] = OrderedDict()
        self._columns_enums: OrderedDict[str, list[str]] = OrderedDict()
        self._class_enum_dependencies: OrderedDict[str, list[str]] = OrderedDict()
        self._used_top_level_names: set[str] = set()
        self._reserved_field_names = {
            attr_name for attr_name in dir(Element) if not attr_name.startswith("_")
        }

    def generate_code(
        self,
        *,
        elements_tree: list[PageElementNode],
        class_name: str,
        page_path: str | None = None,
        aria_snapshot_path: str | None = None,
        screenshot_path: str | None = None,
        base_class: str = "Page",
        existing_enums: ExistingEnums | None = None,
        enum_storage: EnumStorage | None = None,
    ) -> str:
        self._required_imports = {base_class}
        self._custom_imports = {}
        self._generated_wrappers = OrderedDict()
        self._wrapper_signatures = {}
        self._synthetic_enums = OrderedDict()
        self._columns_enums = OrderedDict()
        self._class_enum_dependencies = OrderedDict()
        self._used_top_level_names = {class_name}

        page_lines = self._render_page_class(
            class_name=class_name,
            base_class=base_class,
            elements=elements_tree,
            page_path=page_path,
            aria_snapshot_path=aria_snapshot_path,
            screenshot_path=screenshot_path,
            enum_storage=enum_storage,
            existing_enums=existing_enums,
        )

        module_lines: list[str] = ["from __future__ import annotations", ""]
        local_class_names = set(self._generated_wrappers)
        used_enum_names = {
            enum_name
            for enum_names in self._class_enum_dependencies.values()
            for enum_name in enum_names
        }
        if used_enum_names:
            module_lines.extend(["from enum import Enum", ""])

        import_names = sorted(
            import_name
            for import_name in self._required_imports
            if import_name not in local_class_names
        )
        if import_names:
            module_lines.append("from persona_dsl.pages import (")
            for import_name in import_names:
                module_lines.append(f"    {import_name},")
            module_lines.extend([")", ""])

        for module_name, class_names in sorted(self._custom_imports.items()):
            module_lines.append(f"from {module_name} import (")
            for class_name_to_import in sorted(class_names):
                module_lines.append(f"    {class_name_to_import},")
            module_lines.extend([")", ""])

        for wrapper_lines in self._generated_wrappers.values():
            module_lines.extend(wrapper_lines)
            module_lines.extend(["", ""])

        module_lines.extend(page_lines)
        module_lines.append("")

        code = "\n".join(module_lines)
        return black.format_str(code, mode=black.Mode())

    def _render_page_class(
        self,
        *,
        class_name: str,
        base_class: str,
        elements: list[PageElementNode],
        page_path: str | None,
        aria_snapshot_path: str | None,
        screenshot_path: str | None,
        enum_storage: EnumStorage | None,
        existing_enums: ExistingEnums | None,
    ) -> list[str]:
        lines = [f"class {class_name}({base_class}):"]
        metadata_lines: list[str] = []
        field_lines: list[str] = []
        used_field_names: set[str] = set()
        emitted_enum_names: set[str] = set()

        if page_path is not None:
            metadata_lines.append(f"    expected_path = {page_path!r}")
        if aria_snapshot_path is not None:
            metadata_lines.append(
                f"    static_aria_snapshot_path = {aria_snapshot_path!r}"
            )
        if screenshot_path is not None:
            metadata_lines.append(f"    static_screenshot_path = {screenshot_path!r}")

        for element in elements:
            rendered = self._render_element_assignment(
                element,
                enum_storage=enum_storage,
                existing_enums=existing_enums,
                used_field_names=used_field_names,
                owner_class_name=class_name,
                emitted_enum_names=emitted_enum_names,
            )
            if not rendered:
                continue
            field_lines.extend(f"    {line}" for line in rendered)

        if not field_lines:
            if metadata_lines:
                lines.extend(metadata_lines)
            if not metadata_lines:
                lines.append("    pass")
            return lines

        if metadata_lines:
            lines.extend(metadata_lines)
            if field_lines:
                lines.append("")
        lines.extend(field_lines)
        return lines

    def _render_element_assignment(
        self,
        element: PageElementNode,
        *,
        enum_storage: EnumStorage | None,
        existing_enums: ExistingEnums | None,
        used_field_names: set[str],
        owner_class_name: str,
        emitted_enum_names: set[str],
    ) -> list[str]:
        raw_field_name = get_str(element, "var_name")
        role = get_str(element, "role")
        if raw_field_name is None or role is None:
            return []
        field_name = self._safe_field_name(raw_field_name, used_field_names)
        if element.get("is_collection_group"):
            return self._render_collection_group_assignment(
                element,
                field_name=field_name,
                enum_storage=enum_storage,
                existing_enums=existing_enums,
                owner_class_name=owner_class_name,
                emitted_enum_names=emitted_enum_names,
            )

        expression, constructor_kwargs, enum_names = self._render_element_expression(
            element,
            enum_storage=enum_storage,
            existing_enums=existing_enums,
            owner_class_name=owner_class_name,
        )
        lines: list[str] = []
        lines.extend(
            self._render_inline_enum_definitions(
                enum_names=enum_names,
                enum_storage=enum_storage,
                existing_enums=existing_enums,
                owner_class_name=owner_class_name,
                emitted_enum_names=emitted_enum_names,
                indent=0,
            )
        )
        if self._is_unstable_locator(element, constructor_kwargs):
            lines.append("# TODO: Unstable Locator")
        lines.append(f"{field_name} = {expression}")
        return lines

    def _render_element_expression(
        self,
        element: PageElementNode,
        *,
        enum_storage: EnumStorage | None,
        existing_enums: ExistingEnums | None,
        owner_class_name: str,
    ) -> tuple[str, OrderedDict[str, str], list[str]]:
        class_name, schema_type = self._resolve_element_class_names(element)
        children = self._renderable_children(element)
        force_wrapper = get_str(element, "class_name_ref") is not None
        should_generate_wrapper = (
            bool(children)
            or force_wrapper
            or self._should_generate_table_wrapper(element)
        )

        constructor_kwargs, enum_names = self._build_constructor_kwargs(
            element,
            schema_type=schema_type,
            enum_storage=enum_storage,
            existing_enums=existing_enums,
            owner_class_name=owner_class_name,
        )

        rendered_class_name = class_name
        if should_generate_wrapper:
            wrapper_class_name = self._ensure_wrapper_class(
                element,
                base_class_name=schema_type,
                children=children,
                enum_storage=enum_storage,
                existing_enums=existing_enums,
            )
            rendered_class_name = wrapper_class_name
            if self._wrapper_owns_options_enum(element):
                constructor_kwargs["variants"] = f"{wrapper_class_name}.Options"
                enum_names = []

        rendered_kwargs = ", ".join(
            f"{key}={value}" for key, value in constructor_kwargs.items()
        )
        relative_anchor_expr = get_str(element, "relative_anchor_expr")
        relative_index = element.get("relative_index")

        if rendered_kwargs:
            expression = f"{rendered_class_name}({rendered_kwargs})"
        else:
            expression = f"{rendered_class_name}()"

        if relative_anchor_expr is not None:
            if isinstance(relative_index, int) and relative_index > 0:
                expression = f"{expression}.relative_to({relative_anchor_expr}, index={relative_index})"
            else:
                expression = f"{expression}.relative_to({relative_anchor_expr})"

        return expression, constructor_kwargs, enum_names

    def _ensure_wrapper_class(
        self,
        element: PageElementNode,
        *,
        base_class_name: str,
        children: list[PageElementNode],
        enum_storage: EnumStorage | None,
        existing_enums: ExistingEnums | None,
    ) -> str:
        preferred_name = self._preferred_wrapper_class_name(element, base_class_name)
        if self._should_generate_table_wrapper(element):
            signature = (
                base_class_name,
                tuple(as_str_list(element.get("columns_values"))),
            )
        else:
            signature = (
                base_class_name,
                tuple(
                    require_str(child, "var_name", context="wrapper child")
                    for child in children
                ),
            )

        existing_signature = self._wrapper_signatures.get(preferred_name)
        if existing_signature is not None:
            if existing_signature != signature:
                raise ValueError(
                    f"Конфликт declarative wrapper '{preferred_name}'. "
                    f"Старый базовый класс/поля: {existing_signature}, новый: {signature}."
                )
            return preferred_name

        if self._should_generate_table_wrapper(element):
            wrapper_lines = self._render_table_wrapper_class(
                class_name=preferred_name,
                base_class_name=base_class_name,
                element=element,
            )
            self._generated_wrappers[preferred_name] = wrapper_lines
            self._wrapper_signatures[preferred_name] = signature
            self._used_top_level_names.add(preferred_name)
            return preferred_name

        wrapper_lines = [f"class {preferred_name}({base_class_name}):"]
        body_lines: list[str] = []
        if self._wrapper_owns_options_enum(element):
            option_values = self._merge_enum_values(
                self._wrapper_option_values(element),
                self._existing_enum_members(
                    existing_enums,
                    owner_class_name=preferred_name,
                    enum_name="Options",
                ),
            )
            body_lines.extend(
                self._render_inner_enum_definition(
                    enum_name="Options",
                    values=option_values,
                    existing_members=self._existing_enum_members(
                        existing_enums,
                        owner_class_name=preferred_name,
                        enum_name="Options",
                    ),
                    indent=4,
                )
            )
        used_field_names: set[str] = set()
        emitted_enum_names: set[str] = set()
        self._required_imports.add(base_class_name)

        for child in children:
            rendered_child = self._render_element_assignment(
                child,
                enum_storage=enum_storage,
                existing_enums=existing_enums,
                used_field_names=used_field_names,
                owner_class_name=preferred_name,
                emitted_enum_names=emitted_enum_names,
            )
            if not rendered_child:
                continue
            body_lines.extend(f"    {line}" for line in rendered_child)

        if not body_lines:
            body_lines.append("    pass")
        wrapper_lines.extend(body_lines)
        self._generated_wrappers[preferred_name] = wrapper_lines
        self._wrapper_signatures[preferred_name] = signature
        self._used_top_level_names.add(preferred_name)
        return preferred_name

    def _render_collection_group_assignment(
        self,
        element: PageElementNode,
        *,
        field_name: str,
        enum_storage: EnumStorage | None,
        existing_enums: ExistingEnums | None,
        owner_class_name: str,
        emitted_enum_names: set[str],
    ) -> list[str]:
        children = self._renderable_children(element)
        collection_role = get_str(element, "collection_item_role")
        if collection_role is None or not children:
            raise ValueError(
                f"Collection group '{field_name}' не содержит repeatable children."
            )
        if any(get_str(child, "role") != collection_role for child in children):
            raise ValueError(
                f"Collection group '{field_name}' содержит разнотипные children."
            )

        prototype_child = children[0]
        prototype_node = prototype_child.copy()
        prototype_kwargs = require_object_map(
            prototype_child,
            "init_kwargs",
            context="repeated collection prototype",
        ).copy()
        prototype_kwargs.pop("index", None)
        prototype_node["init_kwargs"] = prototype_kwargs

        prototype_expression, _, enum_names = self._render_element_expression(
            prototype_node,
            enum_storage=enum_storage,
            existing_enums=existing_enums,
            owner_class_name=owner_class_name,
        )

        self._required_imports.add("Repeated")
        lines: list[str] = []
        scope_expression: str | None = None
        inline_scope_kwargs: OrderedDict[str, str] = OrderedDict()
        scope_enum_names: list[str] = []
        if self._collection_group_requires_scope(element):
            scope_node = element.copy()
            scope_node["children"] = []
            inline_scope_kwargs = self._inline_collection_scope_kwargs(
                enum_storage=enum_storage,
                existing_enums=existing_enums,
                element=scope_node,
                owner_class_name=owner_class_name,
            )
            if not inline_scope_kwargs:
                (
                    scope_expression,
                    _scope_constructor_kwargs,
                    scope_enum_names,
                ) = self._render_element_expression(
                    scope_node,
                    enum_storage=enum_storage,
                    existing_enums=existing_enums,
                    owner_class_name=owner_class_name,
                )
        lines.extend(
            self._render_inline_enum_definitions(
                enum_names=[*enum_names, *scope_enum_names],
                enum_storage=enum_storage,
                existing_enums=existing_enums,
                owner_class_name=owner_class_name,
                emitted_enum_names=emitted_enum_names,
                indent=0,
            )
        )
        repeated_args = [prototype_expression, f"name={field_name!r}"]
        repeated_args.extend(
            f"{key}={value}" for key, value in inline_scope_kwargs.items()
        )
        if scope_expression is not None and not inline_scope_kwargs:
            repeated_args.append(f"scope={scope_expression}")
        lines.append(f"{field_name} = Repeated({', '.join(repeated_args)})")
        return lines

    def _inline_collection_scope_kwargs(
        self,
        *,
        enum_storage: EnumStorage | None,
        existing_enums: ExistingEnums | None,
        element: PageElementNode,
        owner_class_name: str,
    ) -> OrderedDict[str, str]:
        if get_str(element, "relative_anchor_expr") is not None:
            return OrderedDict()
        relative_index = element.get("relative_index")
        if isinstance(relative_index, int) and relative_index > 0:
            return OrderedDict()

        if self._resolve_variants_enum_name(
            element,
            enum_storage=enum_storage,
            existing_enums=existing_enums,
            owner_class_name=owner_class_name,
        ):
            return OrderedDict()
        if self._resolve_columns_enum_name(element) is not None:
            return OrderedDict()

        role = require_str(element, "role", context="collection scope inline kwargs")
        var_name = require_str(
            element,
            "var_name",
            context="collection scope inline kwargs",
        )
        flat_def = require_object_map(
            element,
            "init_kwargs",
            context=f"collection scope '{var_name}'",
        ).copy()
        flat_def["role"] = role
        flat_def["var_name"] = var_name
        if get_str(flat_def, "name") is None:
            flat_def["name"] = var_name

        normalized_kwargs = self._collect_scalar_init_kwargs(flat_def, "Element")
        normalized_kwargs.pop("diagnostic_reason", None)

        inline_kwargs: OrderedDict[str, str] = OrderedDict()
        for key, value in normalized_kwargs.items():
            if key == "name":
                continue
            if key == "role" and value in {"", "generic", "none", "presentation"}:
                continue
            if key not in _REPEATED_INLINE_SCOPE_KWARGS:
                return OrderedDict()
            inline_kwargs[key] = self._render_literal(value)
        return inline_kwargs

    def _collection_group_requires_scope(self, element: PageElementNode) -> bool:
        if get_str(element, "relative_anchor_expr") is not None:
            return True
        relative_index = element.get("relative_index")
        if isinstance(relative_index, int) and relative_index > 0:
            return True

        init_kwargs = require_object_map(
            element,
            "init_kwargs",
            context="collection group scope",
        )
        for key, value in init_kwargs.items():
            if key == "name":
                continue
            if value is None or value == "" or value is False:
                continue
            return True
        return False

    def _preferred_wrapper_class_name(
        self,
        element: PageElementNode,
        base_class_name: str,
    ) -> str:
        explicit_name = get_str(element, "class_name_ref")
        if explicit_name is not None:
            if explicit_name == base_class_name:
                raise ValueError(
                    f"Wrapper '{explicit_name}' конфликтует с базовым классом '{base_class_name}'."
                )
            return explicit_name

        field_name = require_str(
            element,
            "var_name",
            context=f"wrapper for {base_class_name}",
        )
        raw_name = to_pascal_case(field_name) or "GeneratedComponent"
        if base_class_name in {"Table", "Grid"} and not raw_name.endswith("Table"):
            raw_name = f"{raw_name}Table"
        import_conflict_names = set(self._required_imports)
        if raw_name == base_class_name or raw_name in import_conflict_names:
            raw_name = f"{raw_name}Component"

        final_name = raw_name
        counter = 1
        while final_name in self._reserved_top_level_class_names():
            counter += 1
            final_name = f"{raw_name}{counter}"
        return final_name

    def _reserved_top_level_class_names(self) -> set[str]:
        return {
            *self._required_imports,
            *self._used_top_level_names,
        }

    def _should_generate_table_wrapper(self, element: PageElementNode) -> bool:
        role = get_str(element, "role")
        if role not in {"table", "grid"}:
            return False
        return bool(element.get("has_columns_enum"))

    def _render_table_wrapper_class(
        self,
        *,
        class_name: str,
        base_class_name: str,
        element: PageElementNode,
    ) -> list[str]:
        column_values = as_str_list(element.get("columns_values"))
        if not column_values:
            raise ValueError(
                f"Таблица '{class_name}' помечена has_columns_enum=True, но columns_values пуст."
            )

        self._required_imports.add(base_class_name)
        self._required_imports.add("Column")
        self._required_imports.add("TableColumn")

        wrapper_lines = [
            f"class {class_name}({base_class_name}):",
            "    class Columns(TableColumn):",
        ]
        for column_value in column_values:
            wrapper_lines.append(
                f"        {self._enum_member_name(column_value)} = Column({column_value!r})"
            )
        return wrapper_lines

    def _build_constructor_kwargs(
        self,
        element: PageElementNode,
        *,
        schema_type: str,
        enum_storage: EnumStorage | None,
        existing_enums: ExistingEnums | None,
        owner_class_name: str,
    ) -> tuple[OrderedDict[str, str], list[str]]:
        role = require_str(element, "role", context="declarative element")
        var_name = require_str(
            element,
            "var_name",
            context=f"declarative element role={role}",
        )
        flat_def = require_object_map(
            element,
            "init_kwargs",
            context=f"declarative element '{var_name}'",
        ).copy()
        if (
            get_str(element, "forced_class_name") is None
            and get_str(element, "custom_import_module") is None
            and get_str(element, "class_name_ref") is None
        ):
            flat_def["role"] = role
        flat_def["var_name"] = var_name
        if get_str(flat_def, "name") is None:
            flat_def["name"] = var_name

        normalized_kwargs = self._collect_scalar_init_kwargs(flat_def, schema_type)
        normalized_kwargs.pop("diagnostic_reason", None)

        rendered_kwargs: OrderedDict[str, str] = OrderedDict()
        used_enum_names: list[str] = []
        for key, value in normalized_kwargs.items():
            rendered_kwargs[key] = self._render_literal(value)

        variants_enum_name = self._resolve_variants_enum_name(
            element,
            enum_storage=enum_storage,
            existing_enums=existing_enums,
            owner_class_name=owner_class_name,
        )
        if variants_enum_name is not None:
            self._register_enum_dependency(owner_class_name, variants_enum_name)
            rendered_kwargs["variants"] = variants_enum_name
            used_enum_names.append(variants_enum_name)

        if not self._should_generate_table_wrapper(element):
            columns_enum_name = self._resolve_columns_enum_name(element)
            if columns_enum_name is not None:
                self._register_enum_dependency(owner_class_name, columns_enum_name)
                rendered_kwargs["columns"] = columns_enum_name
                used_enum_names.append(columns_enum_name)

        return rendered_kwargs, used_enum_names

    def _resolve_variants_enum_name(
        self,
        element: PageElementNode,
        *,
        enum_storage: EnumStorage | None,
        existing_enums: ExistingEnums | None,
        owner_class_name: str,
    ) -> str | None:
        explicit_enum_name = get_str(element, "explicit_enum_name")
        if explicit_enum_name is not None:
            return explicit_enum_name

        values: list[str] = []
        if element.get("has_options_enum"):
            values = as_str_list(element.get("options_values"))
        if not values and element.get("has_text_enum"):
            text_value = get_str(element, "text_enum_value")
            if text_value is not None:
                values = [text_value]
        if not values:
            values = as_str_list(element.get("variants"))
        if not values:
            return None

        base_name = require_str(
            element,
            "var_name",
            context="variants enum base name",
        )
        existing_class_enums = (
            existing_enums.get(owner_class_name, {}) if existing_enums else {}
        )
        preferred_enum_name = self._find_existing_enum_name(
            existing_class_enums,
            values,
        )
        if enum_storage is not None:
            return enum_storage.get_enum_name(
                base_name=preferred_enum_name or base_name,
                options=values,
            )

        enum_name = preferred_enum_name or self._synthetic_enum_name(base_name)
        existing_values = self._synthetic_enums.get(enum_name)
        if existing_values is not None and existing_values != values:
            raise ValueError(
                f"Конфликт synthetic enum '{enum_name}'. "
                f"Старые значения: {existing_values}, новые: {values}."
            )
        self._synthetic_enums[enum_name] = values
        return enum_name

    def _resolve_columns_enum_name(self, element: PageElementNode) -> str | None:
        if not element.get("has_columns_enum"):
            return None
        values = as_str_list(element.get("columns_values"))
        if not values:
            raise ValueError(
                "Таблица помечена has_columns_enum=True, но columns_values пуст."
            )

        var_name = require_str(
            element,
            "var_name",
            context="table columns enum name",
        )
        enum_name = f"{to_pascal_case(var_name)}Columns"
        existing_values = self._columns_enums.get(enum_name)
        if existing_values is not None and existing_values != values:
            raise ValueError(
                f"Конфликт Columns enum '{enum_name}'. "
                f"Старые значения: {existing_values}, новые: {values}."
            )
        self._columns_enums[enum_name] = values
        return enum_name

    def _render_inline_enum_definitions(
        self,
        *,
        enum_names: list[str],
        enum_storage: EnumStorage | None,
        existing_enums: ExistingEnums | None,
        owner_class_name: str,
        emitted_enum_names: set[str],
        indent: int,
    ) -> list[str]:
        lines: list[str] = []
        for enum_name in enum_names:
            if enum_name in emitted_enum_names:
                continue
            values = self._lookup_enum_values(enum_name, enum_storage=enum_storage)
            existing_members = self._existing_enum_members(
                existing_enums,
                owner_class_name=owner_class_name,
                enum_name=enum_name,
            )
            merged_values = self._merge_enum_values(values, existing_members)
            lines.extend(
                self._render_inner_enum_definition(
                    enum_name=enum_name,
                    values=merged_values,
                    existing_members=existing_members,
                    indent=indent,
                )
            )
            emitted_enum_names.add(enum_name)
        return lines

    def _lookup_enum_values(
        self,
        enum_name: str,
        *,
        enum_storage: EnumStorage | None,
    ) -> list[str]:
        if enum_storage is not None:
            storage_values = enum_storage.get_all_enums().get(enum_name)
            if storage_values is not None:
                return storage_values
        synthetic_values = self._synthetic_enums.get(enum_name)
        if synthetic_values is not None:
            return synthetic_values
        column_values = self._columns_enums.get(enum_name)
        if column_values is not None:
            return column_values
        raise ValueError(f"Не найден Enum '{enum_name}' для declarative class attrs.")

    def _register_enum_dependency(
        self,
        owner_class_name: str,
        enum_name: str,
    ) -> None:
        dependencies = self._class_enum_dependencies.setdefault(owner_class_name, [])
        if enum_name not in dependencies:
            dependencies.append(enum_name)

    def _render_literal(self, value: object) -> str:
        if isinstance(value, (str, bool, int, float)) or value is None:
            return repr(value)
        raise TypeError(
            f"Declarative codegen не поддерживает литерал типа '{type(value).__name__}'."
        )

    def _is_unstable_locator(
        self,
        element: PageElementNode,
        constructor_kwargs: OrderedDict[str, str],
    ) -> bool:
        role = get_str(element, "role")
        if role in {"document", "generic", "row", "rowgroup"}:
            return False
        stable_keys = {
            "text",
            "accessible_name",
            "test_id",
            "placeholder",
            "html_name",
            "locator",
            "index",
            "column_header",
            "aria_ref",
            "label",
            "alt_text",
            "title",
            "url",
        }
        return not any(key in constructor_kwargs for key in stable_keys)

    def _resolve_element_class_names(
        self,
        element: PageElementNode,
    ) -> tuple[str, str]:
        role = require_str(element, "role", context="element class resolution")
        custom_import_module = get_str(element, "custom_import_module")
        if custom_import_module is not None:
            cls_obj = element.get("class")
            cls_name = getattr(cls_obj, "__name__", None)
            if not isinstance(cls_name, str) or not cls_name:
                raise ValueError(
                    f"Кастомный элемент для role='{role}' должен содержать валидный class.__name__."
                )
            self._custom_imports.setdefault(custom_import_module, set()).add(cls_name)
            return cls_name, cls_name

        forced_class_name = get_str(element, "forced_class_name")
        if forced_class_name is not None:
            self._required_imports.add(forced_class_name)
            return forced_class_name, forced_class_name

        class_name_ref = get_str(element, "class_name_ref")
        if class_name_ref is not None:
            base_schema_type = PageEditor.get_class_name_for_role(role)
            if base_schema_type == "Element":
                self._required_imports.add("Element")
            else:
                self._required_imports.add(base_schema_type)
            return class_name_ref, base_schema_type

        class_name = PageEditor.get_class_name_for_role(role)
        self._required_imports.add(class_name)
        return class_name, class_name

    def _renderable_children(self, element: PageElementNode) -> list[PageElementNode]:
        role = get_str(element, "role")
        children = get_element_children(element)
        if not children:
            return []

        if role in {"table", "img"}:
            return []

        if role in {"combobox", "listbox", "radiogroup", "menu"} and (
            element.get("has_options_enum") or get_str(element, "explicit_enum_name")
        ):
            semantic_children = [
                child
                for child in children
                if get_str(child, "role") not in {"option", "radio", "menuitem"}
            ]
            if not semantic_children:
                return []
            return semantic_children

        if role in {"button", "link"}:
            semantic_children = [
                child
                for child in children
                if not (
                    get_str(child, "role") == "img" and not get_element_children(child)
                )
            ]
            if not semantic_children:
                return []
            return semantic_children

        return children

    def _synthetic_enum_name(self, base_name: str) -> str:
        clean_name = to_pascal_case(base_name) or "Dynamic"
        if not clean_name.endswith("Enum"):
            clean_name = f"{clean_name}Enum"
        return clean_name

    def _enum_member_name(self, value: str) -> str:
        member_name = to_snake_case(value).upper()
        if not member_name:
            member_name = "VALUE"
        if member_name[0].isdigit():
            member_name = f"E{member_name}"
        return member_name

    def _wrapper_owns_options_enum(self, element: PageElementNode) -> bool:
        if get_str(element, "class_name_ref") is None:
            return False
        return bool(self._wrapper_option_values(element))

    def _wrapper_option_values(self, element: PageElementNode) -> list[str]:
        option_values = as_str_list(element.get("options_values"))
        if option_values:
            return option_values
        return as_str_list(element.get("variants"))

    def _existing_enum_members(
        self,
        existing_enums: ExistingEnums | None,
        *,
        owner_class_name: str,
        enum_name: str,
    ) -> dict[str, str]:
        if not existing_enums:
            return {}
        return dict(existing_enums.get(owner_class_name, {}).get(enum_name, {}))

    def _merge_enum_values(
        self,
        current_values: list[str],
        existing_members: dict[str, str],
    ) -> list[str]:
        merged_values = list(current_values)
        for existing_value in existing_members:
            if existing_value not in merged_values:
                merged_values.append(existing_value)
        return merged_values

    def _render_inner_enum_definition(
        self,
        *,
        enum_name: str,
        values: list[str],
        existing_members: dict[str, str],
        indent: int,
    ) -> list[str]:
        prefix = " " * indent
        child_prefix = " " * (indent + 4)
        lines = [f"{prefix}class {enum_name}(str, Enum):"]
        for value in values:
            member_name = existing_members.get(value, self._enum_member_name(value))
            lines.append(f"{child_prefix}{member_name} = {value!r}")
        lines.append("")
        return lines

    def _find_existing_enum_name(
        self,
        existing_class_enums: dict[str, dict[str, str]],
        values: list[str],
    ) -> str | None:
        if not existing_class_enums:
            return None
        current_value_set = set(values)
        for enum_name, members in existing_class_enums.items():
            existing_value_set = set(members)
            if current_value_set and current_value_set.issubset(existing_value_set):
                return enum_name
        return None

    def _safe_field_name(self, raw_name: str, used_field_names: set[str]) -> str:
        candidate = raw_name
        if candidate in self._reserved_field_names:
            candidate = f"{candidate}_element"

        if candidate not in used_field_names:
            used_field_names.add(candidate)
            return candidate

        base_name = candidate
        counter = 1
        while candidate in used_field_names:
            counter += 1
            candidate = f"{base_name}_{counter}"
        used_field_names.add(candidate)
        return candidate

    def _collect_scalar_init_kwargs(
        self,
        element_definition: ObjectMap,
        schema_type: str,
    ) -> dict[str, object]:
        normalized_source = {
            key: value
            for key, value in element_definition.items()
            if key not in {"variants", "columns"}
        }
        return dict(
            PageEditor.normalize_element_args(
                normalized_source,
                schema_type,
            ).items()
        )
