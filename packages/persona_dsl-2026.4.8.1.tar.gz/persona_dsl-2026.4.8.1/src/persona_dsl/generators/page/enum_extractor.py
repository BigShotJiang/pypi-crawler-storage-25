from __future__ import annotations

import ast
from typing import TypeAlias

EnumMembersByValue: TypeAlias = dict[str, str]
ClassEnums: TypeAlias = dict[str, EnumMembersByValue]
ExtractedEnums: TypeAlias = dict[str, ClassEnums]


def _is_enum_base(base: ast.expr) -> bool:
    return (
        isinstance(base, ast.Name)
        and base.id == "Enum"
        or isinstance(base, ast.Attribute)
        and base.attr == "Enum"
    )


def _is_enum_class(node: ast.ClassDef) -> bool:
    return any(_is_enum_base(base) for base in node.bases)


def _extract_enum_members(
    enum_node: ast.ClassDef,
    *,
    owner_name: str,
) -> EnumMembersByValue:
    members: EnumMembersByValue = {}
    for statement in enum_node.body:
        if not isinstance(statement, ast.Assign):
            continue
        if len(statement.targets) != 1 or not isinstance(
            statement.targets[0], ast.Name
        ):
            continue
        if not isinstance(statement.value, ast.Constant) or not isinstance(
            statement.value.value,
            str,
        ):
            line = getattr(statement, "lineno", "?")
            raise ValueError(
                f"Enum '{owner_name}.{enum_node.name}' должен содержать только строковые "
                f"константы (строка {line})."
            )
        members[statement.value.value] = statement.targets[0].id
    return members


def _collect_class_enums(
    class_node: ast.ClassDef,
    extracted_enums: ExtractedEnums,
) -> None:
    class_enums: ClassEnums = {}
    for child in class_node.body:
        if not isinstance(child, ast.ClassDef):
            continue
        if _is_enum_class(child):
            enum_members = _extract_enum_members(
                child,
                owner_name=class_node.name,
            )
            if enum_members:
                class_enums[child.name] = enum_members
            continue
        _collect_class_enums(child, extracted_enums)

    if class_enums:
        extracted_enums[class_node.name] = class_enums


def extract_enums_from_code(code: str) -> ExtractedEnums:
    """
    Возвращает существующие Enum по owning-классам:
    { "ClassName": { "EnumName": { "Значение": "ИМЯ_ЧЛЕНА" } } }.
    """
    if not code.strip():
        return {}

    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        raise ValueError(
            f"Не удалось разобрать код для извлечения Enum: {exc.msg} "
            f"(строка {exc.lineno}, столбец {exc.offset})"
        ) from exc

    extracted_enums: ExtractedEnums = {}
    for statement in tree.body:
        if isinstance(statement, ast.ClassDef):
            _collect_class_enums(statement, extracted_enums)

    return extracted_enums
