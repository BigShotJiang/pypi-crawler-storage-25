import re
from unidecode import unidecode

INTERESTING_ROLES = {
    "banner",
    "contentinfo",
    "main",
    "navigation",
    "form",
    "region",
    "search",
    "complementary",
    "dialog",
    "alertdialog",
    "bylocator",  # Special role
    # Strela FC Support
    "menu",
    "tablist",
}

INTERESTING_ROLES = {
    "banner",
    "contentinfo",
    "main",
    "navigation",
    "form",
    "region",
    "search",
    "complementary",
    "dialog",
    "alertdialog",
    "bylocator",  # Special role
    # Strela FC Support
    "menu",
    "tablist",
}


def sanitize_name(name: str) -> str:
    """
    Санитизация человекочитаемых имён в идентификаторы Python.

    Правила:
    * очистка от артефактов снепшота (типа [ref=...]);
    * транслитерация в ASCII;
    * удаление всего, кроме букв/цифр/подчёркиваний и пробелов;
    * схлопывание пробелов в подчёркивания;
    * гарантия корректного идентификатора Python.
    """
    if not name:
        return "element"

    # Remove references like [ref=154]
    name = re.sub(r"\[ref=\d+\]", "", name)

    # Transliterate to ASCII
    name = unidecode(name)

    # Keep only alphanumeric and spaces/underscores and hyphens
    name = re.sub(r"[^a-zA-Z0-9_\s-]", "", name)

    # Replace spaces/hyphens with underscore
    name = re.sub(r"[\s-]+", "_", name)

    # Remove surrounding underscores
    name = name.strip("_")

    if not name:
        return "element"

    if name[0].isdigit():
        name = f"_{name}"

    if name.lower() == "none":
        name = "none_el"

    # Valid Python keywords or Element reserved attributes
    # We avoid 'name', 'role', 'parent', 'children', 'elements' as they are Element properties.
    # 'cell' is a method on Table/TableRow.
    reserved = {
        "name",
        "role",
        "parent",
        "children",
        "elements",
        "test_id",
        "cell",
        "class",
        "def",
        "return",
        "import",
        "from",
        "global",
        "lambda",
    }
    if name.lower() in reserved:
        name = f"{name}_element"

    return name.lower()


def derive_base_name(
    role: str,
    aria_name: str,
    test_id: str | None,
    text_prop: str | None,
    placeholder: str | None,
    field_name_hint: str | None = None,
) -> str:
    """Определяет базовое имя для элемента (без суффикса уникальности)."""
    base_name = "element"

    # 0. Явный hint от строгой naming-спецификации генератора
    if field_name_hint:
        base_name = sanitize_name(field_name_hint)

    # 1. Test ID (highest priority)
    if base_name == "element" and test_id:
        base_name = sanitize_name(test_id)

    # 2. Locator role (bylocator)
    elif base_name == "element" and role == "bylocator":
        base_name = "element"

    # 3. Placeholder (Often more stable/descriptive than current value/aria-label)
    elif base_name == "element" and placeholder:
        base_name = sanitize_name(placeholder)

    # 4. Aria Name
    elif base_name == "element" and aria_name:
        # Avoid using values as names if possible (simple heuristic: if fully numeric or date-like)
        cleaned = sanitize_name(aria_name)

        # Regex for Date (DD.MM.YYYY, YYYY-MM-DD) - dates are dynamic/unstable names.
        is_date = re.search(r"\d{2}\.\d{2}\.\d{4}", aria_name) or re.search(
            r"\d{4}-\d{2}-\d{2}", aria_name
        )

        # Explicit check for Time (H:MM or HH:MM) purely.
        # We WANT to name elements "16:00" -> "_1600".
        is_time = re.search(r"^\d{1,2}:\d{2}$", aria_name)

        if is_time:
            # If it's pure time, use it!
            base_name = cleaned
        elif not is_date and not aria_name.replace(".", "").replace(":", "").isdigit():
            # If not date and not pure number, use it.
            base_name = cleaned

    # 5. Text
    if base_name == "element" and text_prop:
        cleaned = sanitize_name(text_prop)
        if len(cleaned) > 30:
            cleaned = cleaned[:30]
        if cleaned:
            base_name = cleaned

    # 6. Fallback
    if base_name == "element":
        base_name = sanitize_name(role) if role else "element"

    # Apply list suffix logic
    if (
        role == "list"
        and not base_name.endswith("list")
        and not base_name.endswith("List")
    ):
        return f"{base_name}_list"

    return base_name


def get_unique_name(base_name: str, used_names: set[str]) -> str:
    """Генерирует уникальное имя, добавляя суффикс при необходимости."""
    candidate = base_name
    counter = 1
    while candidate in used_names:
        candidate = f"{base_name}_{counter}"
        counter += 1
    # Note: caller should add candidate to used_names
    return candidate
