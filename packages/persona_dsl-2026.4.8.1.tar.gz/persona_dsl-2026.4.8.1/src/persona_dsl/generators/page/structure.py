from __future__ import annotations

import ast
import re

from .contracts import (
    ElementInitKwargs,
    ObjectMap,
    PageElementNode,
    SnapshotNodeList,
    get_bool,
    get_element_children,
    get_object_map,
    get_snapshot_children,
    get_str,
    get_str_list,
)
from .utils import INTERESTING_ROLES, derive_base_name, get_unique_name


def _node_children(value: object) -> SnapshotNodeList:
    node = {"children": value}
    return get_snapshot_children(node)


_VENDOR_CLASS_PREFIXES = (
    "ant-",
    "anticon",
    "mapgl_",
    "mapgl-",
    "mui",
    "rc-",
    "bp3-",
    "cdk-",
    "leaflet-",
)
_SEMANTIC_CLASS_SUFFIXES = (
    "-btn",
    "-button",
    "-icon",
    "-select",
    "-input",
    "-link",
    "-picker",
)
_CURRENT_VALUE_ONLY_SELECT_ROLES = frozenset({"combobox", "listbox"})
_INPUT_ROLES = frozenset({"textbox", "searchbox", "spinbutton"})
_GENERIC_LIKE_ROLES = frozenset({"generic", "", "none", "presentation"})
_REPEATABLE_WIDGET_ROLES = frozenset(
    {
        "textbox",
        "searchbox",
        "spinbutton",
        "combobox",
        "checkbox",
        "radio",
        "switch",
    }
)
_COLLECTION_LABEL_ROLES = frozenset({"text", "heading", "paragraph"})
_PLURAL_ROLE_FALLBACKS = {
    "checkbox": "checkboxes",
    "combobox": "comboboxes",
    "radio": "radios",
    "searchbox": "searchboxes",
    "spinbutton": "spinbuttons",
    "switch": "switches",
    "textbox": "textboxes",
}


class StructureParser:
    """
    Handles parsing of ARIA snapshots into a flat list of elements and
    structural analysis (sections identification).
    """

    def __init__(self, test_id_prefix: str | None = None):
        self._test_id_prefix = test_id_prefix

    def _extract_icon_semantic_name(self, node: ObjectMap) -> str | None:
        stack: list[ObjectMap] = [
            child
            for child in reversed(get_snapshot_children(node))
            if isinstance(child, dict)
        ]
        while stack:
            current = stack.pop()

            current_props = get_object_map(current, "props")
            current_role = get_str(current, "role") or ""
            current_name = get_str(current, "name") or ""
            current_aria_label = get_str(current_props, "aria-label") or ""
            current_data_icon = get_str(current_props, "dataIcon") or ""

            if current_role == "img":
                if current_name:
                    return current_name
                if current_aria_label:
                    return current_aria_label
                if current_data_icon:
                    return current_data_icon

            if current_data_icon:
                return current_data_icon

            children = get_snapshot_children(current)
            if children:
                stack.extend(
                    child for child in reversed(children) if isinstance(child, dict)
                )
        return None

    def _extract_icon_fragment(self, node: ObjectMap) -> str | None:
        stack = [node]
        while stack:
            current = stack.pop()
            if not isinstance(current, dict):
                continue

            current_props = get_object_map(current, "props")
            current_fragment = get_str(current_props, "iconFragment")
            if current_fragment:
                return current_fragment

            children = get_snapshot_children(current)
            if children:
                stack.extend(
                    child for child in reversed(children) if isinstance(child, dict)
                )
        return None

    def _extract_semantic_class_token(self, node: ObjectMap) -> str | None:
        props = get_object_map(node, "props")
        raw_class = get_str(props, "class") or ""
        if not raw_class:
            return None

        for class_token in raw_class.split():
            lowered = class_token.lower()
            if any(lowered.startswith(prefix) for prefix in _VENDOR_CLASS_PREFIXES):
                continue
            if not any(lowered.endswith(suffix) for suffix in _SEMANTIC_CLASS_SUFFIXES):
                continue

            normalized = lowered
            for suffix in _SEMANTIC_CLASS_SUFFIXES:
                if normalized.endswith(suffix):
                    normalized = normalized[: -len(suffix)]
                    break

            normalized = normalized.strip("-_")
            if normalized:
                return normalized

        return None

    def _button_name_should_use_text(
        self,
        *,
        node: ObjectMap,
        raw_name: str,
    ) -> bool:
        if not raw_name:
            return False

        props = get_object_map(node, "props")
        if get_str(props, "aria-label"):
            return False

        stack: list[ObjectMap] = [
            child
            for child in reversed(get_snapshot_children(node))
            if isinstance(child, dict)
        ]
        while stack:
            current = stack.pop()

            current_role = get_str(current, "role") or ""
            current_name = get_str(current, "name") or ""
            current_props = get_object_map(current, "props")

            if current_name == raw_name:
                if current_role in {"text", "paragraph", "generic"}:
                    return True
                if current_role == "img" and not (
                    get_str(current_props, "aria-label")
                    or get_str(current_props, "dataIcon")
                    or get_str(current_props, "iconFragment")
                ):
                    return True

            children = get_snapshot_children(current)
            if children:
                stack.extend(
                    child for child in reversed(children) if isinstance(child, dict)
                )

        return False

    def _button_name_is_inner_icon_text(
        self,
        *,
        node: ObjectMap,
        raw_name: str,
    ) -> bool:
        if not raw_name:
            return False

        stack: list[ObjectMap] = [
            child
            for child in reversed(get_snapshot_children(node))
            if isinstance(child, dict)
        ]
        while stack:
            current = stack.pop()
            current_role = get_str(current, "role") or ""
            current_name = get_str(current, "name") or ""
            current_props = get_object_map(current, "props")

            if (
                current_name == raw_name
                and current_role == "img"
                and not (
                    get_str(current_props, "aria-label")
                    or get_str(current_props, "dataIcon")
                    or get_str(current_props, "iconFragment")
                )
            ):
                return True

            for child in reversed(get_snapshot_children(current)):
                if isinstance(child, dict):
                    stack.append(child)

        return False

    def _resolve_field_name_hint(
        self,
        *,
        role: str,
        raw_name: str,
        html_name: str | None,
        cleaned_test_id: str | None,
        placeholder: str | None,
        explicit_label: str | None,
        node: ObjectMap,
    ) -> str | None:
        if raw_name or html_name or cleaned_test_id or placeholder:
            return None
        if role in _CURRENT_VALUE_ONLY_SELECT_ROLES and explicit_label:
            return explicit_label
        if role not in {"button", "img"}:
            return None

        semantic_class_token = self._extract_semantic_class_token(node)
        if semantic_class_token:
            return semantic_class_token

        props = get_object_map(node, "props")
        icon_aria_label = get_str(props, "aria-label")
        if icon_aria_label:
            return icon_aria_label
        direct_data_icon = get_str(props, "dataIcon")
        if direct_data_icon:
            return direct_data_icon

        icon_semantic_name = self._extract_icon_semantic_name(node)
        if icon_semantic_name:
            return icon_semantic_name

        icon_fragment = self._extract_icon_fragment(node)
        if icon_fragment:
            return icon_fragment

        return None

    def _is_select_name_unstable(
        self,
        *,
        role: str,
        raw_name: str,
        cleaned_test_id: str | None,
        html_name: str | None,
        placeholder: str | None,
        explicit_label: str | None,
        node: ObjectMap,
    ) -> bool:
        if role not in _CURRENT_VALUE_ONLY_SELECT_ROLES:
            return False
        if not raw_name:
            return False
        if cleaned_test_id or html_name or placeholder or explicit_label:
            return False
        props = get_object_map(node, "props")
        if get_str(props, "aria-label"):
            return False
        labelled_by_refs = get_str_list(props, "labelledByRefs") or get_str_list(
            node, "labelledByRefs"
        )
        if labelled_by_refs:
            return False
        return True

    def _resolve_unresolved_reason(
        self,
        *,
        role: str,
        node: ObjectMap,
        cleaned_test_id: str | None,
        html_name: str | None,
        placeholder: str | None,
        explicit_label: str | None,
        raw_name: str,
        field_name_hint: str | None,
        text: str | None,
    ) -> str | None:
        props = get_object_map(node, "props")
        labelled_by_refs = get_str_list(props, "labelledByRefs") or get_str_list(
            node, "labelledByRefs"
        )
        has_select_runtime_name = bool(
            cleaned_test_id
            or html_name
            or placeholder
            or explicit_label
            or get_str(props, "aria-label")
            or labelled_by_refs
        )
        if role in _CURRENT_VALUE_ONLY_SELECT_ROLES and not has_select_runtime_name:
            return "select_has_only_current_value"

        if self._is_select_name_unstable(
            role=role,
            raw_name=raw_name,
            cleaned_test_id=cleaned_test_id,
            html_name=html_name,
            placeholder=placeholder,
            explicit_label=explicit_label,
            node=node,
        ):
            return "select_has_only_current_value"

        hidden = get_bool(node, "hidden") is True
        if (
            role == "button"
            and not raw_name
            and not text
            and not (
                cleaned_test_id
                or html_name
                or placeholder
                or explicit_label
                or get_str(props, "aria-label")
            )
        ):
            if hidden:
                return "hidden_service_button"
            return "icon_only_without_runtime_name"

        if (
            role == "button"
            and raw_name
            and not (
                cleaned_test_id
                or html_name
                or placeholder
                or explicit_label
                or get_str(props, "aria-label")
            )
            and self._button_name_is_inner_icon_text(node=node, raw_name=raw_name)
        ):
            return "icon_only_without_runtime_name"

        has_stable_name = bool(
            cleaned_test_id or html_name or placeholder or explicit_label
        )
        if (
            role in _INPUT_ROLES
            and get_bool(node, "disabled") is True
            and not raw_name
            and not has_stable_name
        ):
            return "disabled_input_without_stable_name"

        return None

    def _node_has_user_facing_identity(self, node: ObjectMap) -> bool:
        props = get_object_map(node, "props")
        if get_str(node, "name") or get_str(node, "text"):
            return True
        if get_str(node, "placeholder") or get_str(node, "test_id"):
            return True
        if get_str(props, "placeholder") or get_str(props, "testId"):
            return True
        if get_str(props, "aria-label") or get_str(props, "label"):
            return True
        if get_str(props, "nameAttr") or get_str(props, "html_name"):
            return True
        if get_str(node, "label") or get_str(node, "accessible_name"):
            return True
        if get_str(node, "labelledByRefs") or get_str(props, "labelledByRefs"):
            return True
        return False

    def _collection_role_from_snapshot_node(self, node: ObjectMap) -> str | None:
        role = get_str(node, "role") or ""
        if role not in _GENERIC_LIKE_ROLES:
            return None

        child_roles: list[str] = []
        for child in get_snapshot_children(node):
            if not isinstance(child, dict):
                continue
            if get_bool(child, "hidden") is True:
                continue
            child_role = get_str(child, "role") or ""
            if child_role in _GENERIC_LIKE_ROLES:
                if self._node_has_user_facing_identity(child):
                    return None
                continue
            if child_role not in _REPEATABLE_WIDGET_ROLES:
                return None
            if self._node_has_user_facing_identity(child):
                return None
            child_roles.append(child_role)

        if len(child_roles) < 2:
            return None
        if len(set(child_roles)) != 1:
            return None
        return child_roles[0]

    def _collection_role_from_element(self, element: PageElementNode) -> str | None:
        raw_value = element.get("collection_item_role")
        if isinstance(raw_value, str) and raw_value:
            return raw_value
        return None

    def _is_collection_group_candidate(self, element: PageElementNode) -> bool:
        return self._collection_role_from_element(element) is not None

    def _is_simple_textual_element(self, element: PageElementNode) -> bool:
        role = get_str(element, "role") or ""
        if role not in _COLLECTION_LABEL_ROLES:
            return False
        if get_str(element, "test_id"):
            return False

        for child in get_element_children(element):
            child_role = get_str(child, "role") or ""
            if child_role not in _GENERIC_LIKE_ROLES and child_role not in {
                "inline_text_box",
                "InlineTextBox",
                "text",
            }:
                return False
        return True

    def _collection_label_text(self, element: PageElementNode) -> str | None:
        if not self._is_simple_textual_element(element):
            return None
        label_text = self._display_name_for_structural_dedup(element)
        if label_text is None:
            return None
        normalized_label = re.sub(r"\s*\([^)]*\d[^)]*\)\s*$", "", label_text).strip()
        if normalized_label:
            return normalized_label
        return label_text

    def _collection_fallback_name(self, role: str) -> str:
        return _PLURAL_ROLE_FALLBACKS.get(role, f"{role}s")

    def _strip_collection_item_runtime_refs(self, element: PageElementNode) -> None:
        collection_role = self._collection_role_from_element(element)
        if collection_role is None:
            return

        for child in get_element_children(element):
            if get_str(child, "role") != collection_role:
                continue
            init_kwargs = get_object_map(child, "init_kwargs")
            init_kwargs.pop("aria_ref", None)
            child.pop("aria_ref", None)

    def _is_anonymous_repeatable_control(self, element: PageElementNode) -> bool:
        role = get_str(element, "role") or ""
        if role not in _REPEATABLE_WIDGET_ROLES:
            return False
        if self._is_collection_group_candidate(element):
            return False
        if get_str(element, "name") or get_str(element, "text"):
            return False

        init_kwargs = get_object_map(element, "init_kwargs")
        user_facing_keys = (
            "accessible_name",
            "text",
            "label",
            "placeholder",
            "test_id",
            "html_name",
            "locator",
            "title",
            "alt_text",
        )
        return not any(get_str(init_kwargs, key) for key in user_facing_keys)

    def _build_synthetic_collection_group(
        self,
        collection_role: str,
        children: list[PageElementNode],
    ) -> PageElementNode:
        return {
            "var_name": f"{collection_role}_group",
            "role": "generic",
            "name": "",
            "text": None,
            "test_id": None,
            "original_test_id": None,
            "children": children,
            "init_kwargs": {"name": f"{collection_role}_group"},
            "node_ref": {"role": "generic"},
            "is_section": False,
            "is_complex_section": False,
            "collection_item_role": collection_role,
            "is_collection_group": True,
        }

    def identify_repeated_control_groups(
        self, elements: list[PageElementNode]
    ) -> list[PageElementNode]:
        normalized_elements: list[PageElementNode] = []
        for element in elements:
            children = get_element_children(element)
            if children and not self._is_collection_group_candidate(element):
                element["children"] = self.identify_repeated_control_groups(children)
            normalized_elements.append(element)

        grouped: list[PageElementNode] = []
        index = 0
        while index < len(normalized_elements):
            element = normalized_elements[index]

            if self._is_collection_group_candidate(element):
                label_text: str | None = None
                if grouped:
                    label_text = self._collection_label_text(grouped[-1])
                    if label_text is not None:
                        grouped.pop()

                if label_text is None:
                    collection_role = self._collection_role_from_element(element)
                    if collection_role is None:
                        raise ValueError(
                            "Collection-group candidate не содержит collection_item_role."
                        )
                    label_text = self._collection_fallback_name(collection_role)

                element["field_name_hint"] = label_text
                element["is_collection_group"] = True
                self._strip_collection_item_runtime_refs(element)
                grouped.append(element)
                index += 1
                continue

            if self._is_anonymous_repeatable_control(element):
                run: list[PageElementNode] = [element]
                collection_role = get_str(element, "role")
                if collection_role is None:
                    raise ValueError(
                        "Repeatable control ожидает непустую role при synthetic grouping."
                    )

                next_index = index + 1
                while next_index < len(normalized_elements):
                    next_element = normalized_elements[next_index]
                    if (
                        not self._is_anonymous_repeatable_control(next_element)
                        or get_str(next_element, "role") != collection_role
                    ):
                        break
                    run.append(next_element)
                    next_index += 1

                if len(run) >= 2:
                    synthetic_group = self._build_synthetic_collection_group(
                        collection_role,
                        run,
                    )
                    label_text = None
                    if grouped:
                        label_text = self._collection_label_text(grouped[-1])
                        if label_text is not None:
                            grouped.pop()
                    if label_text is None:
                        label_text = self._collection_fallback_name(collection_role)
                    synthetic_group["field_name_hint"] = label_text
                    self._strip_collection_item_runtime_refs(synthetic_group)
                    grouped.append(synthetic_group)
                    index = next_index
                    continue

            grouped.append(element)
            index += 1

        return grouped

    def _parse_concise_string(self, key: str, val: object) -> ObjectMap | None:
        """
        Parses concise string format: `role "name" [ref=...]`
        """
        # Heuristic: Must contain typical indicators to be concise?
        # 1. [attr]
        # 2. "name"
        # 3. Known role
        # OR we just try to parse.

        parsed_node: ObjectMap = {"children": [], "props": {}}
        parsed_props = get_object_map(parsed_node, "props")
        parsed_children = get_snapshot_children(parsed_node)

        # Extract Name: "..."
        name_match = re.search(r'"(.*?)"', key)
        if name_match:
            parsed_node["name"] = name_match.group(1)
            # Remove name from key for further parsing
            key_no_name = key.replace(f'"{parsed_node["name"]}"', "")
        else:
            key_no_name = key

        # Extract attributes [key=val] or [key]
        attrs = re.findall(r"\[(.*?)\]", key_no_name)
        has_attrs = len(attrs) > 0  # Indicator of concise format

        for attr in attrs:
            if "=" in attr:
                k, v = attr.split("=", 1)
                if k == "ref":
                    parsed_node["ref"] = v
                    parsed_node["aria_ref"] = v
                elif k == "testId":
                    parsed_node["test_id"] = v
                else:
                    parsed_props[k] = v
            else:
                # Boolean prop [hidden], [disabled]
                parsed_props[attr] = True

        # Remove attributes from key to get role
        # (Remove [...] blocks)
        key_clean = re.sub(r"\[.*?\]", "", key_no_name).strip()

        parts = key_clean.split()
        if not parts and not has_attrs and not name_match:
            # If no role, no attrs, no Name -> probably just text string
            return None

        if parts:
            parsed_node["role"] = parts[0]
        else:
            # If we have name/attrs but no role string? " [ref=...]"
            # Assume generic?
            parsed_node["role"] = "generic"

        # Process Value (list of children/props)
        if isinstance(val, list):
            for child in val:
                is_prop = False
                if isinstance(child, dict) and len(child) == 1:
                    ck = next(iter(child))
                    if ck.startswith("/"):
                        # It's a property: { "/url": "/" }
                        prop_name = ck[1:]
                        parsed_props[prop_name] = child[ck]
                        is_prop = True

                if not is_prop:
                    # It's a child node (or a text string?)
                    parsed_children.append(child)
        elif val is None:
            pass  # No children

        return parsed_node

    def parse_aria_node_recursive(
        self,
        nodes: SnapshotNodeList | ObjectMap,
        used_names: set[str],
        context: ObjectMap,
    ) -> list[PageElementNode]:
        """
        Строит внутреннее дерево элементов из JSON-структуры (от Runtime).
        """
        raw_nodes: SnapshotNodeList
        if isinstance(nodes, dict):
            raw_nodes = [nodes]
        else:
            raw_nodes = nodes

        result: list[PageElementNode] = []
        for node in raw_nodes:
            # --- 0. PRE-PROCESS CONCISE FORMAT (single key dict OR string) ---
            # If node is { "role name [ref=...]": [children/props] } OR "role name [ref=...]"

            parsed_concise: ObjectMap | None = None

            if isinstance(node, dict) and len(node) == 1:
                key = next(iter(node))
                val = node[key]
                if key not in (
                    "role",
                    "name",
                    "children",
                    "props",
                    "test_id",
                    "var_name",
                    "selector",
                    "locator",
                ):
                    parsed_concise = self._parse_concise_string(key, val)

            elif isinstance(node, str):
                # Try to parse string as concise node
                parsed_concise = self._parse_concise_string(node, None)

                # If parsing returned a generic text node because it failed to find a role,
                # we might want to keep it as simple text?
                # Actually _parse_concise_string defaults to role=text if no role found?
                # Let's check logic below.

            if parsed_concise:
                node = parsed_concise

            # If it was a string and failed to parse as concise role (e.g. just "Submit"),
            # _parse_concise_string might interpret "Submit" as role?
            # We need a whitelist of roles or check if first word is a known role?
            # OR we rely on the fact that concise format usually involves [ref] or quotes?

            if isinstance(node, str):
                # Fallback for simple strings that didn't parse into a rich element
                # (OR if _parse_concise_string wasn't confident)

                # Check if it was processed by _parse_concise_string?
                # If parsed_concise is None, it means it's still a string.

                result.append(
                    {
                        "role": "text",
                        "name": node,
                        "var_name": "text",
                        "init_kwargs": {"text": node},
                        "children": [],
                        "test_id": None,
                        "node_ref": {"text": node},
                    }
                )
                continue

            props = get_object_map(node, "props")
            role = get_str(node, "role") or ""
            raw_name = get_str(node, "name") or ""
            test_id = get_str(node, "test_id") or get_str(props, "testId")
            placeholder = get_str(node, "placeholder") or get_str(props, "placeholder")
            value = get_str(node, "value") or get_str(props, "value")
            text = get_str(node, "text") or get_str(props, "text")
            collection_item_role = self._collection_role_from_snapshot_node(node)
            html_name = (
                get_str(node, "html_name")
                or get_str(props, "html_name")
                or get_str(props, "nameAttr")
            )
            synthetic_name = False
            field_name_hint: str | None = None

            # --- 0. PORTAL DETECTION (Pre-Process) ---
            # Check for container classes (ant-select-dropdown) and assign name early prevents stripping.
            node_ref = get_object_map(node, "node_ref")
            node_props_raw = props or get_object_map(node_ref, "props")
            raw_class = get_str(node_props_raw, "class") or ""

            is_generic_like_role = role in ("generic", "", "none", "presentation")

            if is_generic_like_role and "ant-select-dropdown" in raw_class:
                raw_name = "Dropdown Layer"
                synthetic_name = True
            elif is_generic_like_role and any(
                x in raw_class for x in ["ant-dropdown", "MuiPopover", "bp3-portal"]
            ):
                raw_name = "Overlay"
                synthetic_name = True

            if role == "img" and not raw_name:
                explicit_aria_label = get_str(props, "aria-label")
                if explicit_aria_label:
                    raw_name = explicit_aria_label
                else:
                    field_name_hint = self._resolve_field_name_hint(
                        role=role,
                        raw_name=raw_name,
                        html_name=html_name,
                        cleaned_test_id=test_id,
                        placeholder=placeholder,
                        explicit_label=None,
                        node=node,
                    )
                    if field_name_hint:
                        synthetic_name = True

            if role == "button" and not raw_name:
                explicit_aria_label = get_str(props, "aria-label")
                if explicit_aria_label:
                    raw_name = explicit_aria_label
                else:
                    field_name_hint = self._resolve_field_name_hint(
                        role=role,
                        raw_name=raw_name,
                        html_name=html_name,
                        cleaned_test_id=test_id,
                        placeholder=placeholder,
                        explicit_label=None,
                        node=node,
                    )
                    if field_name_hint:
                        synthetic_name = True

            # --- 1. PRE-FILTERING ---

            # Пропускаем "служебные" узлы, если это Generic без имени/test_id
            if (
                role in ("generic", "", "none")
                and not raw_name
                and not test_id
                and collection_item_role is None
            ):
                # Но если у ноды есть дети, мы должны их обработать и поднять наверх
                children_snapshot = get_snapshot_children(node)
                if children_snapshot:
                    children = self.parse_aria_node_recursive(
                        children_snapshot, used_names, context
                    )
                    result.extend(children)
                continue

            # Игнорируем role="img" без имени (декоративные)
            if role == "img" and not raw_name and not field_name_hint:
                continue

            # --- 2. ATTRIBUTE EXTRACTION ---

            # Smart Logic for test_id prefix stripping
            # (Assuming context might have common prefix if calculated appropriately)
            # For now passing raw test_id. Prefix logic can be applied later or here.
            # Using self._test_id_prefix if available to clean it.
            cleaned_test_id = test_id
            if (
                test_id
                and self._test_id_prefix
                and test_id.startswith(f"{self._test_id_prefix}-")
            ):
                cleaned_test_id = test_id[len(self._test_id_prefix) + 1 :]
            elif (
                test_id
                and self._test_id_prefix
                and test_id.startswith(f"{self._test_id_prefix}_")
            ):
                cleaned_test_id = test_id[len(self._test_id_prefix) + 1 :]

            explicit_label = get_str(node, "label") or get_str(props, "label")
            if field_name_hint is None:
                field_name_hint = self._resolve_field_name_hint(
                    role=role,
                    raw_name=raw_name,
                    html_name=html_name,
                    cleaned_test_id=cleaned_test_id,
                    placeholder=placeholder,
                    explicit_label=explicit_label,
                    node=node,
                )
            unresolved_reason = self._resolve_unresolved_reason(
                role=role,
                node=node,
                cleaned_test_id=cleaned_test_id,
                html_name=html_name,
                placeholder=placeholder,
                explicit_label=explicit_label,
                raw_name=raw_name,
                field_name_hint=field_name_hint,
                text=text,
            )
            use_raw_name_for_field = (
                unresolved_reason != "select_has_only_current_value"
            )
            use_raw_name_for_accessible_name = unresolved_reason not in {
                "select_has_only_current_value",
                "icon_only_without_runtime_name",
                "hidden_service_button",
            }

            # --- 3. NAME GENERATION ---
            base_name = derive_base_name(
                role,
                raw_name if use_raw_name_for_field else "",
                cleaned_test_id,
                text,
                placeholder,
                field_name_hint,
            )

            # Генерируем уникальное имя
            unique_name = get_unique_name(base_name, used_names)
            used_names.add(unique_name)

            # --- 4. ATTRIBUTE PREPARATION ---
            # Формируем словарь для атрибутов __init__
            # role/name/test_id всегда идут как базовые
            init_kwargs: ElementInitKwargs = {"name": unique_name}

            if placeholder:
                init_kwargs["placeholder"] = placeholder
            if html_name:
                init_kwargs["html_name"] = html_name
            if value:
                # init_kwargs["value"] = value  # Element definition does not support value
                pass

            # Если есть accessible name
            # Check if name is dynamic (equals value) or looks like transient data (date/time)
            is_dynamic_name = False
            if value and raw_name == value:
                is_dynamic_name = True

            # Simple heuristic for dates (common sources of flakiness)
            # Matches DD.MM.YYYY, YYYY-MM-DD.
            # We ALLOW Time (HH:MM) as it is often static structure (calendar slots).
            if re.search(r"\d{2}\.\d{2}\.\d{4}", raw_name) or re.search(
                r"\d{4}-\d{2}-\d{2}", raw_name
            ):
                is_dynamic_name = True

            # Use name if valid, else try text prop
            acc_name = ""
            if not synthetic_name and use_raw_name_for_accessible_name:
                acc_name = raw_name
            if not acc_name and text and not value:
                # If name is missing but we have text (and it's not a value input), use text
                acc_name = text

            if acc_name and not is_dynamic_name:
                # FIX: For Generics/Text/Paragraph without explicit Aria Role (or just generic),
                # prefer 'text' strategy if the name essentially IS the text content.
                # This makes them interactable via Click(Generic(text="...")) which is robust.
                # RELAXED: TreeWalker doesn't always send 'text' prop, so if role is generic and we have a name,
                # we assume the name comes from text content.
                if role in ("generic", "text", "paragraph", "presentation", "none", ""):
                    # Use the explicit text if available, otherwise name
                    # (Name often IS the text, but if manually named, we want the content)
                    if text:
                        init_kwargs["text"] = text
                    else:
                        init_kwargs["text"] = acc_name

                    # Explicitly set role to 'text' for mapping if generic/none
                    if role in ("generic", "none", ""):
                        role = "text"
                elif role == "button" and self._button_name_should_use_text(
                    node=node,
                    raw_name=acc_name,
                ):
                    init_kwargs["text"] = acc_name
                else:
                    init_kwargs["accessible_name"] = acc_name

            if unresolved_reason:
                init_kwargs["diagnostic_reason"] = unresolved_reason

            if (
                role and role != "group"
            ):  # role is usually implicit by class, but allowed explicitly
                # However, Persona classes handle role internally usually.
                # Only if generic Element is used do we need role.
                # Note: PageGenerator codegen logic will decide class.
                pass

            if cleaned_test_id:
                init_kwargs["test_id"] = cleaned_test_id

            # EXPLICIT LOCATOR SUPPORT (for Page Editor)
            selector = get_str(node, "selector")
            locator = get_str(node, "locator")
            if selector:
                init_kwargs["locator"] = selector
            elif locator:
                init_kwargs["locator"] = locator

            # EXPLICIT ACCESSIBLE NAME SUPPORT
            # Only add if it wasn't already used as 'text' strategy
            # If init_kwargs has 'text' and it equals explicit accessible_name, skip adding accessible_name
            explicit_acc_name = get_str(node, "accessible_name")
            if explicit_acc_name:
                used_text = init_kwargs.get("text")
                # If we used text strategy, and the text is the same as accessible_name, don't duplicate
                if used_text and used_text == explicit_acc_name:
                    pass
                else:
                    init_kwargs["accessible_name"] = explicit_acc_name

            # --- EXTENDED ATTRIBUTES (Pass-through for Schema Validation) ---
            # Data-driven extraction to avoid repetition
            # --- EXTENDED ATTRIBUTES (Pass-through for Schema Validation) ---
            # Data-driven extraction, now checking against Element definitions where possible
            # Standard Element fields:
            # text, label, placeholder, test_id, alt_text, title, description, url, exact.

            ATTR_MAPPING = {
                "title": ["title", "/title"],
                "alt_text": ["alt", "alt_text", "/alt", "/alt_text"],
                "label": ["label", "aria-label", "/label", "/aria-label"],
                "html_name": ["html_name", "nameAttr", "/html_name", "/nameAttr"],
                "description": [
                    "description",
                    "aria-description",
                    "/description",
                    "/aria-description",
                ],
                "url": ["href", "url", "src", "/href", "/url", "/src"],
                "exact": ["exact", "/exact"],
                "value": ["value", "/value"],  # Some elements use value
                "checked": ["checked", "/checked"],
                "disabled": ["disabled", "/disabled"],
                "expanded": ["expanded", "/expanded"],
                "selected": ["selected", "/selected"],
                "variants": [
                    "variants",
                    "/variants",
                ],  # Allow passing explicit variants (for Enums)
            }

            # Helper to get prop
            def get_prop(keys: list[str]) -> object | None:
                for k in keys:
                    if k in node:
                        return node[k]
                    if k in props:
                        return props[k]
                return None

            for attr, keys in ATTR_MAPPING.items():
                val = get_prop(keys)
                if val is not None:
                    init_kwargs[attr] = val

            # --- 5. RECURSION ---
            children_list: list[PageElementNode] = []
            if get_snapshot_children(node):
                children_list = self.parse_aria_node_recursive(
                    get_snapshot_children(node), used_names, context
                )

            if (
                role in {"button", "link"}
                and field_name_hint
                and unresolved_reason
                in {"icon_only_without_runtime_name", "hidden_service_button"}
            ):
                children_list = []

            # --- 6. ELEMENT CONSTRUCTION ---
            element_def: PageElementNode = {
                "var_name": unique_name,
                "role": role,
                "name": raw_name,  # raw accessible name из runtime-снепшота
                "text": text,  # text content (if any)
                "test_id": cleaned_test_id,  # for logic
                "original_test_id": test_id,  # for prefix calc
                "children": children_list,
                "init_kwargs": init_kwargs,
                "node_ref": node,  # link to original node
                "is_section": False,  # Flag for wrapping
                "is_complex_section": raw_name
                in ("Dropdown Layer", "Overlay"),  # Flag for extracting to Class
            }
            if field_name_hint:
                element_def["field_name_hint"] = field_name_hint
            if unresolved_reason:
                element_def["unresolved_reason"] = unresolved_reason

            if "has_options_enum" in node:
                element_def["has_options_enum"] = node["has_options_enum"]
            if "options_values" in node:
                element_def["options_values"] = node["options_values"]
            if collection_item_role is not None:
                element_def["collection_item_role"] = collection_item_role
            for passthrough_key in (
                "class_name_ref",
                "forced_class_name",
                "custom_import_module",
                "custom_import_name",
                "explicit_enum_name",
                "class",
            ):
                if passthrough_key in node:
                    element_def[passthrough_key] = node[passthrough_key]

            # Extract aria_ref if present (support both ref and aria_ref keys)
            # STABLE ID: Re-enabled after fixing IdGenerator stability
            aria_ref = get_str(node, "ref") or get_str(node, "aria_ref")
            if aria_ref:
                init_kwargs["aria_ref"] = aria_ref
                element_def["aria_ref"] = (
                    aria_ref  # Ensure it is available for flattening check
                )

            result.append(element_def)

        return result

    def collect_consumed_refs(self, elements: list[PageElementNode]) -> set[str]:
        """Собирает все ID (aria_ref) элементов, которые используются как лейблы другими элементами."""
        refs = set()
        for el in elements:
            # Check if this element consumes refs?
            # (Logic depends on if 'labelled_by' is in element dict, usually extracted from Node)
            # Assuming node_ref has it
            node = get_object_map(el, "node_ref")

            # Check standard keys
            labelled_by = get_str(node, "labelledby")
            described_by = get_str(node, "describedby")
            if labelled_by:
                refs.add(labelled_by)
            if described_by:
                refs.add(described_by)

            # Check snapshot property keys (common in RichAriaSnapshot yaml/json)
            # Value might be list or string representation of list: "['ref1', 'ref2']"
            # Also check inside 'props' dictionary where properties often reside

            targets = [node]
            props = get_object_map(node, "props")
            if props:
                targets.append(props)

            for target in targets:
                for key in [
                    "/labelledByRefs",
                    "labelledByRefs",
                    "/describedByRefs",
                    "describedByRefs",
                ]:
                    val = target.get(key)
                    if val:
                        if isinstance(val, list):
                            refs.update(item for item in val if isinstance(item, str))
                        elif isinstance(val, str):
                            # Try to parse string list "['a', 'b']"
                            try:
                                parsed = ast.literal_eval(val)
                                if isinstance(parsed, list):
                                    refs.update(parsed)
                                else:
                                    refs.add(val)
                            except (SyntaxError, ValueError):
                                refs.add(val)

            children = get_element_children(el)
            if children:
                refs = refs.union(self.collect_consumed_refs(children))
        return refs

    def apply_label_relationships(self, elements: list[PageElementNode]) -> None:
        def extract_refs(value: object) -> list[str]:
            if isinstance(value, list) and all(isinstance(item, str) for item in value):
                return list(value)
            if isinstance(value, str):
                try:
                    parsed = ast.literal_eval(value)
                except (SyntaxError, ValueError):
                    return [value]
                if isinstance(parsed, list) and all(
                    isinstance(item, str) for item in parsed
                ):
                    return list(parsed)
            return []

        ref_to_label: dict[str, str] = {}

        def collect(nodes: list[PageElementNode]) -> None:
            for el in nodes:
                node = get_object_map(el, "node_ref")
                node_id = (
                    get_str(el, "aria_ref")
                    or get_str(node, "ref")
                    or get_str(node, "aria_ref")
                )
                init_kwargs = get_object_map(el, "init_kwargs")
                label_text = (
                    get_str(init_kwargs, "text")
                    or get_str(init_kwargs, "accessible_name")
                    or get_str(el, "name")
                    or get_str(el, "text")
                )
                if node_id and label_text:
                    ref_to_label[node_id] = label_text
                children = get_element_children(el)
                if children:
                    collect(children)

        def apply(nodes: list[PageElementNode]) -> None:
            for el in nodes:
                node = get_object_map(el, "node_ref")
                props = get_object_map(node, "props")
                ref_values = extract_refs(
                    props.get("labelledByRefs") or node.get("labelledByRefs")
                )
                if ref_values:
                    resolved_labels = [
                        ref_to_label[ref_value]
                        for ref_value in ref_values
                        if ref_value in ref_to_label
                    ]
                    unique_labels = list(dict.fromkeys(resolved_labels))
                    if len(unique_labels) == 1:
                        init_kwargs = get_object_map(el, "init_kwargs")
                        resolved_label = unique_labels[0]
                        existing_accessible_name = get_str(
                            init_kwargs, "accessible_name"
                        )
                        existing_text = get_str(init_kwargs, "text")
                        if (
                            not get_str(init_kwargs, "label")
                            and resolved_label != existing_accessible_name
                            and resolved_label != existing_text
                        ):
                            init_kwargs["label"] = resolved_label
                        if not get_str(el, "field_name_hint") and not get_str(
                            el, "name"
                        ):
                            el["field_name_hint"] = resolved_label
                children = get_element_children(el)
                if children:
                    apply(children)

        collect(elements)
        apply(elements)

    def flatten_tree_recursive(
        self, elements: list[PageElementNode], consumed_refs: set[str] | None = None
    ) -> list[PageElementNode]:
        """
        Рекурсивно проходит дерево и делает служебные generic-обёртки прозрачными.
        Также удаляет элементы, помеченные как "consumed" (лейблы) или как вспомогательные.
        """
        consumed_refs = consumed_refs or set()
        flat_list: list[PageElementNode] = []

        for el in elements:
            role = get_str(el, "role") or ""
            name = get_str(el, "name") or ""

            # 1. Скрываем consumed элементы (если они используются как лейблы)
            # Note: Need 'ref' from node (RichAriaSnapshot uses 'ref')
            node = get_object_map(el, "node_ref")
            node_id = (
                get_str(node, "ref") or get_str(node, "aria_ref") or get_str(node, "id")
            )

            if node_id and node_id in consumed_refs:
                # Skip adding this element to list, but process children?
                # Usually labels are leaf nodes. If not, we might lose children.
                # Heuristic: skip only if leaf or text-only logic
                if not get_element_children(el):
                    continue

            # 2. Generic-обёртки: если роль generic/none и нет полезных атрибутов -> поднимаем детей
            # We ignore 'name' for these roles because they are usually layout/content wrappers,
            # not semantic regions (use role='region' or 'group' for those).
            # FIX: Restoring named generics (user requirement). ONLY filter if name is empty.
            # But filter 'text'/'paragraph' even if named (usually just labels).
            # ALSO: If element has aria_ref, it is stable and should be preserved.
            has_ref = bool(
                el.get("aria_ref")
                or el.get("ref")
                or get_str(node, "ref")
                or get_str(node, "aria_ref")
            )
            is_collection_group = self._is_collection_group_candidate(el) or bool(
                el.get("is_collection_group")
            )

            if role in ("paragraph", "presentation"):
                is_uninteresting_generic = (
                    not el.get("test_id") and not has_ref and not is_collection_group
                )
            else:
                is_uninteresting_generic = (
                    (role in ("generic", "", "none"))
                    and not name
                    and not el.get("test_id")
                    and not has_ref
                    and not is_collection_group
                )

            if is_uninteresting_generic:
                children = get_element_children(el)
                if children:
                    # Recurse on children and add them to THIS level
                    flattened_children = self.flatten_tree_recursive(
                        children, consumed_refs
                    )
                    flat_list.extend(flattened_children)
            else:
                # Оставляем элемент, но его children тоже нужно "сплющить" внутри него
                children = get_element_children(el)
                if children:
                    el["children"] = self.flatten_tree_recursive(
                        children, consumed_refs
                    )
                flat_list.append(el)

        return flat_list

    def recalculate_names(self, elements: list[PageElementNode]) -> None:
        """
        Полностью пересчитывает имена (var_name) для списка элементов.
        Это нужно вызывать после фильтрации/схлопывания, чтобы освободившиеся
        красивые имена (например 'login' вместо 'login_1') достались оставшимся элементам.
        """
        # Scoped within each level
        # We need to traverse tree level by level and recalculate uniqueness per level

        def process_level(
            level_elements: list[PageElementNode], inherited_used_names: set[str]
        ) -> None:
            # Collect base names again
            current_level_names: set[str] = set()

            # 1. Locator Uniqueness Pass
            # We need to identify if elements will have identical locators.
            # Signature: (role, accessible_name, test_id, placeholder, text, html_name)
            # Note: We rely on init_kwargs primarily as that's what constructs the Element.
            locator_counts: dict[
                tuple[object, object, object, object, object, object], int
            ] = {}

            for el in level_elements:
                ik = get_object_map(el, "init_kwargs")
                # Build signature based on what Element uses for locating
                sig = (
                    el["role"],
                    ik.get("accessible_name"),
                    ik.get("test_id"),
                    ik.get("placeholder"),
                    ik.get("text"),
                    ik.get("html_name"),
                    # ik.get("aria_ref"), # aria_ref is unique but not used for locating, so we EXCLUDE it to detect collisions
                )
                locator_counts[sig] = locator_counts.get(sig, 0) + 1

            locator_current_indices: dict[
                tuple[object, object, object, object, object, object], int
            ] = {}

            # Prioritize interactive elements for better naming (e.g. login input > login text)
            # level_elements.sort(key=sort_key) # DISABLED: Preserving DOM order to prevent layout shifts

            for el in level_elements:
                ik = get_object_map(el, "init_kwargs")
                sig = (
                    el["role"],
                    ik.get("accessible_name"),
                    ik.get("test_id"),
                    ik.get("placeholder"),
                    ik.get("text"),
                    ik.get("html_name"),
                    # ik.get("aria_ref"),
                )

                # Assign Index if duplicates exist
                if locator_counts.get(sig, 0) > 1:
                    idx = locator_current_indices.get(sig, 0)
                    # Use 0-based or 1-based? Usually 0 is fine, locator.nth(0) matches first.
                    ik["index"] = idx
                    locator_current_indices[sig] = idx + 1

                # Double-check uniqueness logic
                # 'locator_counts' ensures we add indices to locators.
                # 'process_level' needs to ensure 'var_name' is unique.

                # Re-derive base name based on current data
                # (Logic implies re-running base_name derivation or storing it)
                # Re-running is safer.
                base_name = derive_base_name(
                    get_str(el, "role") or "",
                    get_str(el, "name") or "",
                    get_str(el, "test_id"),
                    (
                        get_str(get_object_map(el, "node_ref"), "text")
                        or get_str(
                            get_object_map(get_object_map(el, "node_ref"), "props"),
                            "text",
                        )
                    ),
                    (
                        get_str(get_object_map(el, "node_ref"), "placeholder")
                        or get_str(
                            get_object_map(get_object_map(el, "node_ref"), "props"),
                            "placeholder",
                        )
                    ),
                    get_str(el, "field_name_hint"),
                )

                # Unique in current context
                unique = get_unique_name(base_name, current_level_names)
                current_level_names.add(unique)

                el["var_name"] = unique
                ik["name"] = unique

                children = get_element_children(el)
                if children:
                    process_level(children, set())  # New scope for children

        process_level(elements, set())

    def collapse_redundant_headings_before_tables(
        self,
        elements: list[PageElementNode],
    ) -> list[PageElementNode]:
        collapsed: list[PageElementNode] = []
        index = 0

        while index < len(elements):
            element = elements[index]
            children = get_element_children(element)
            if children:
                element["children"] = self.collapse_redundant_headings_before_tables(
                    children
                )

            next_element = elements[index + 1] if index + 1 < len(elements) else None
            if self._is_redundant_heading_for_table(element, next_element):
                index += 1
                continue

            collapsed.append(element)
            index += 1

        return collapsed

    def _is_redundant_heading_for_table(
        self,
        heading: PageElementNode,
        table: PageElementNode | None,
    ) -> bool:
        if table is None:
            return False
        if get_str(heading, "role") != "heading":
            return False
        if get_element_children(heading):
            return False
        if get_str(table, "role") not in {"table", "grid"}:
            return False

        heading_name = self._display_name_for_structural_dedup(heading)
        table_name = self._display_name_for_structural_dedup(table)
        if heading_name is None or table_name is None:
            return False

        return heading_name == table_name

    def _display_name_for_structural_dedup(
        self,
        element: PageElementNode,
    ) -> str | None:
        init_kwargs = get_object_map(element, "init_kwargs")
        candidates = (
            get_str(init_kwargs, "accessible_name"),
            get_str(init_kwargs, "label"),
            get_str(init_kwargs, "text"),
            get_str(element, "name"),
            get_str(element, "text"),
        )
        for candidate in candidates:
            if candidate is None:
                continue
            normalized = candidate.strip()
            if normalized:
                return normalized
        return None

    def promote_semantic_wrappers(
        self, elements: list[PageElementNode], used_names: set[str]
    ) -> None:
        """
        Находит семантические группы (group, region, form, etc.) без имени.
        Пытается найти внутри них заголовок (Heading) и использовать его текст как имя группы.
        Если находит -> переименовывает группу и делает её 'named region'.
        """
        for el in elements:
            role = get_str(el, "role") or ""
            name = get_str(el, "name") or ""

            # Recurse first
            children = get_element_children(el)
            if children:
                self.promote_semantic_wrappers(children, used_names)

            # Logic: If un-named semantic container
            if role in ("group", "region", "form", "section", "article") and not name:
                heading_el = self._find_first_heading(el)
                heading_name = get_str(heading_el, "name") if heading_el else None
                if heading_name:
                    # Found a heading! Promote this wrapper.
                    new_name_text = heading_name

                    # Generate new var_name
                    base_name = derive_base_name(role, new_name_text, None, None, None)
                    unique = get_unique_name(base_name, used_names)
                    used_names.add(unique)

                    el["var_name"] = unique
                    el["name"] = new_name_text
                    init_kwargs = get_object_map(el, "init_kwargs")
                    init_kwargs["name"] = unique
                    init_kwargs["accessible_name"] = new_name_text

                    # Also, ideally, we might construct a 'locator' based on this heading
                    # This is advanced, sticking to Name promotion for now.

    def _find_first_heading(
        self, element: PageElementNode, depth: int = 0, max_depth: int = 2
    ) -> PageElementNode | None:
        """
        Рекурсивный поиск первого заголовка для именования секции.
        Останавливается, если встречает уже именованную семантическую группу.
        """
        if depth > max_depth:
            return None

        role = element.get("role")
        if role == "heading":
            return element

        for child in get_element_children(element):
            # Stop if child is a significant landmark itself
            if (
                child.get("role")
                in (
                    "region",
                    "form",
                    "banner",
                    "main",
                )
                and child.get("name")
                or child.get("is_semantic_group")
            ):
                continue

            found = self._find_first_heading(child, depth + 1, max_depth)
            if found:
                return found
        return None

    def identify_complex_sections(self, elements: list[PageElementNode]) -> None:
        """
        Identifies elements that should be extracted into nested classes.
        Criteria:
        1. Specific Role (banner, contentinfo, form, etc.)
        2. Complexity (e.g. > 1 meaningful children)
        """
        for el in elements:
            role = get_str(el, "role")
            children = get_element_children(el)

            # Recurse first
            if children:
                self.identify_complex_sections(children)

            # Check criteria
            # Check criteria
            is_interesting = role in INTERESTING_ROLES

            # Explicitly interesting if it has variants (User wants Enums)
            # Currently focused on ListBox/Select
            has_variants = False
            init_kwargs = get_object_map(el, "init_kwargs")
            if "variants" in init_kwargs and isinstance(init_kwargs["variants"], list):
                has_variants = True
                # If it has variants, we WANT a class to hold the Enum.

            if role in ("listbox", "combobox") and has_variants:
                is_interesting = True

            # STRUCTURAL GROUPING (User Request: "Tree Structure")
            # If it's a generic container with meaningful children (e.g. Label + Input),
            # we should treat it as a Component (Section).
            if role == "generic" and len(children) >= 2:
                # Filter out purely layout generics?
                # For now, if it has 2+ children, we assume it's a group.
                # Check if children are "widgets" (not just text leaf nodes?)
                # Actually, Label (text) + Input (widget) is exactly what we want.
                is_interesting = True

            # Count meaningful children (not pure layout wrappers if we have any left)
            # Essentially, if it has children that will generate code.
            # has_children = len(children) > 0  # Simple check

            # Additional heuristic: Don't extract simple wrappers with 1 child
            # unless it's a critical role like 'main' or 'banner'
            is_complex = len(children) >= 1

            # If it has variants, it is complex enough to warrant a class (for Enum)
            if has_variants:
                is_complex = True

            if is_interesting and is_complex:
                el["is_complex_section"] = True
                # If it's complex, we will generate a class for it.
                # The class name will be derived from var_name in codegen.

    def identify_table_prototypes(self, elements: list[PageElementNode]) -> None:
        """
        Analyzes Tables to detect repetitive Row patterns.
        Delegates to external analyzer.
        """
        from .table_analysis import identify_table_prototypes

        identify_table_prototypes(elements)

    def identify_dropdown_options(self, elements: list[PageElementNode]) -> None:
        """
        Analyzes Combobox/Select/Listbox elements to collect their Options.
        If options are found (either as children or via aria-controls),
        they are collected into 'options_data' attribute for Enum generation.
        """
        for el in elements:
            role = get_str(el, "role")

            # Recurse first? Or after?
            # Recurse first to ensure children are processed
            children = get_element_children(el)
            if children:
                self.identify_dropdown_options(children)

            if role in ("combobox", "listbox"):
                options = list(get_str_list(el, "options_values"))
                # Strategy:
                # 1. Look for 'option' children directly
                # 2. If Combobox, look for 'listbox' child, then options
                # 3. Future: Look for aria-controls (requires global lookup, might be hard in recursive pass without context)

                def collect_options(nodes: list[PageElementNode]) -> None:
                    for node in nodes:
                        if node.get("role") == "option":
                            # Extract text/value
                            opt_text = get_str(node, "text") or get_str(node, "name")
                            # We need a value for the Enum.
                            # If no text/name, skip?
                            if opt_text:
                                options.append(opt_text)

                        # Recurse into groups/generic/listbox inside combobox
                        nested_children = get_element_children(node)
                        if nested_children:
                            collect_options(nested_children)

                # Collect from children
                collect_options(children)

                # Also collect from 'variants' (if normalized or manually set)
                # This supports inline definitions: ListBox(variants=["A", "B"])
                init_kwargs = get_object_map(el, "init_kwargs")
                if "variants" in init_kwargs:
                    vars_val = init_kwargs["variants"]
                    if isinstance(vars_val, list):
                        options.extend(vars_val)
                    elif isinstance(vars_val, str):
                        options.append(vars_val)

                if options:
                    # Found options!
                    # Deduplicate preserving order
                    unique_options = list(dict.fromkeys(options))

                    if len(unique_options) > 0:
                        el["has_options_enum"] = True
                        el["options_values"] = unique_options

                        # Also, if it's a combobox, we might want to ensure it maps to Select or Dropdown class
                        # PageEditor maps combobox -> Select (or Dropdown if custom?)
                        # Logic needed: If basic structure -> Select? If complex -> Dropdown?
                        # For now, let PageEditor decide class, but we provide data for Enum.
                        pass

    def identify_text_enums(self, elements: list[PageElementNode]) -> None:
        """
        Analyzes Text elements. If a Text element has a static 'text' value,
        we can promote it to use an Enum for that value.
        """
        for el in elements:
            role = get_str(el, "role")
            text = get_str(el, "text") or get_str(
                get_object_map(el, "init_kwargs"), "text"
            )

            children = get_element_children(el)
            if children:
                self.identify_text_enums(children)

            if (
                role in ("text", "generic")
                and text
                and isinstance(text, str)
                and len(text) < 50
            ):
                el["has_text_enum"] = True
                el["text_enum_value"] = text
