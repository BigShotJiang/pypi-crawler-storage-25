from __future__ import annotations

import ast
from dataclasses import dataclass
import re

import black

from persona_dsl.editors.page import PageEditor
from persona_dsl.pages.elements import Element
from persona_dsl.utils.naming import to_pascal_case, to_snake_case

from .contracts import PageElementNode, as_object_map, get_element_children, get_str
from .table_analysis import clean_header_text


@dataclass(frozen=True)
class ColumnRenderSpec:
    member_name: str
    title: str
    filter_class_name: str | None = None
    cell_class_name: str = "Text"
    popup_class_name: str | None = None
    variants_enum_name: str | None = None


@dataclass(frozen=True)
class TableRenderSpec:
    field_name: str
    class_name: str
    row_class_name: str
    details_class_name: str | None
    constructor_kwargs: dict[str, str]
    columns: list[ColumnRenderSpec]
    has_selection: bool
    has_expander: bool


@dataclass(frozen=True)
class SimpleElementRenderSpec:
    field_name: str
    class_name: str
    kwargs: dict[str, str]
    diagnostic_reason: str | None = None
    variants_enum_name: str | None = None
    bindings: tuple["ElementBindingRenderSpec", ...] = ()


@dataclass(frozen=True)
class ElementBindingRenderSpec:
    target_path: tuple[str, ...]
    attribute_name: str
    value: str
    diagnostic_reason: str | None = None


@dataclass(frozen=True)
class EnumRenderSpec:
    class_name: str
    values: list[str]


@dataclass(frozen=True)
class DetailsRenderSpec:
    class_name: str
    kwargs: dict[str, str]
    fields: list[SimpleElementRenderSpec]


@dataclass(frozen=True)
class TableDslRenderResult:
    code: str
    unresolved_diagnostics: list[dict[str, object]]


@dataclass(frozen=True)
class TableStructure:
    header_table: PageElementNode
    body_table: PageElementNode
    header_row: PageElementNode
    header_cells: list[PageElementNode]
    data_rows: list[PageElementNode]
    expanded_rows: list[PageElementNode]


@dataclass(frozen=True)
class UnlabeledRadioGroupMatch:
    radio_nodes: list[PageElementNode]
    trailing_combobox: PageElementNode | None
    next_index: int


@dataclass(frozen=True)
class UnlabeledRadioGroupNamingSpec:
    group_field_name: str
    enum_base_name: str
    select_field_name: str | None = None


class EnumCollector:
    def __init__(self) -> None:
        self._values_by_name: dict[str, tuple[str, ...]] = {}

    def register(self, *, base_name: str, values: list[str]) -> str:
        unique_values = list(dict.fromkeys(values))
        if not unique_values:
            raise ValueError(
                f"Невозможно создать Enum для '{base_name}': список значений пуст."
            )

        class_name = f"{to_pascal_case(base_name)}Enum"
        normalized_values = tuple(unique_values)
        existing_values = self._values_by_name.get(class_name)
        if existing_values is not None and existing_values != normalized_values:
            raise ValueError(
                f"Конфликт значений для Enum '{class_name}'. "
                f"Старые значения: {list(existing_values)}, новые значения: {unique_values}."
            )

        self._values_by_name[class_name] = normalized_values
        return class_name

    def render_specs(self) -> list[EnumRenderSpec]:
        return [
            EnumRenderSpec(class_name=class_name, values=list(values))
            for class_name, values in self._values_by_name.items()
        ]


IGNORED_TOP_LEVEL_NAMES = frozenset(
    {
        "dropdown_layer",
        "double_left",
        "left_1",
        "right_1",
        "double_right",
        "combobox",
        "_30_na_str",
        "_3_iz_3_elementov",
        "reload",
    }
)

KNOWN_TABLE_FIELD_NAMES = {
    "Маршрут": "marshruty",
    "Номер заезда": "zaezdy",
}

SAVE_BUTTON_TITLES = frozenset({"Сохранить", "Save"})
CANCEL_BUTTON_TITLES = frozenset({"Отмена", "Cancel"})
KNOWN_MULTISELECT_TITLES = frozenset({"Тип заезда", "Теги"})
KNOWN_UNLABELED_RADIO_GROUPS: dict[frozenset[str], UnlabeledRadioGroupNamingSpec] = {
    frozenset(
        {"Без обеда", "Обед в КИЦ", "Обед вне КИЦ"}
    ): UnlabeledRadioGroupNamingSpec(
        group_field_name="tip_obeda",
        enum_base_name="tip_obeda",
        select_field_name="mesto_obeda",
    ),
}
_DIAGNOSTIC_REASON_UNSET = object()


def try_render_table_dsl_page(
    elements_tree: list[PageElementNode],
    class_name: str,
) -> TableDslRenderResult | None:
    enum_collector = EnumCollector()
    top_level_tables = [
        element for element in elements_tree if get_str(element, "role") == "table"
    ]
    structures = _analyze_top_level_structures(top_level_tables)
    complex_structures = [
        structure for structure in structures if _is_complex_table(structure)
    ]

    if not complex_structures:
        return None

    if len(complex_structures) > 1:
        raise ValueError(
            "Table DSL генератор поддерживает одну сложную корневую таблицу на страницу. "
            f"Найдено таблиц: {len(complex_structures)}."
        )

    root_structure = complex_structures[0]
    root_table_spec = _build_table_spec(root_structure, enum_collector)
    details_spec, nested_table_spec = _build_details_spec(
        root_structure, enum_collector
    )
    top_level_elements = _build_top_level_elements(elements_tree, root_structure)
    rendered_code = _render_page_module(
        class_name=class_name,
        enum_specs=enum_collector.render_specs(),
        top_level_elements=top_level_elements,
        root_table_spec=root_table_spec,
        details_spec=details_spec,
        nested_table_spec=nested_table_spec,
    )
    unresolved_diagnostics = _collect_table_dsl_unresolved_diagnostics(
        class_name=class_name,
        top_level_elements=top_level_elements,
        root_table_spec=root_table_spec,
        details_spec=details_spec,
    )
    return TableDslRenderResult(
        code=rendered_code,
        unresolved_diagnostics=unresolved_diagnostics,
    )


def _parse_rendered_string(value: str) -> str:
    parsed = ast.literal_eval(value)
    if not isinstance(parsed, str):
        raise ValueError(
            f"Table DSL expected string literal in rendered kwargs, got: {value}"
        )
    return parsed


def _extract_rendered_string(kwargs: dict[str, str], key: str) -> str | None:
    raw_value = kwargs.get(key)
    if raw_value is None:
        return None
    return _parse_rendered_string(raw_value)


def _collect_simple_element_unresolved_diagnostics(
    element: SimpleElementRenderSpec,
    *,
    prefix: str,
) -> list[dict[str, object]]:
    diagnostics: list[dict[str, object]] = []
    element_path = f"{prefix}.{element.field_name}"
    own_reason = element.diagnostic_reason
    if own_reason is not None:
        element_name = (
            _extract_rendered_string(element.kwargs, "name") or element.field_name
        )
        diagnostics.append(
            {
                "path": element_path,
                "element_type": element.class_name,
                "field_name": element.field_name,
                "element_name": element_name,
                "ui_label": (
                    _extract_rendered_string(element.kwargs, "accessible_name")
                    or _extract_rendered_string(element.kwargs, "text")
                    or _extract_rendered_string(element.kwargs, "label")
                    or element_name
                ),
                "available_hints": {
                    key: value
                    for key, value in (
                        (
                            key,
                            _extract_rendered_string(element.kwargs, key),
                        )
                        for key in (
                            "accessible_name",
                            "label",
                            "placeholder",
                            "text",
                            "title",
                            "test_id",
                            "url",
                            "html_name",
                            "locator",
                            "alt_text",
                            "aria_ref",
                        )
                    )
                    if value not in (None, "")
                },
                "reason": own_reason,
            }
        )

    _, child_configs = _split_binding_render_specs(element.bindings)
    child_reasons: dict[str, str] = {}
    for binding in element.bindings:
        if len(binding.target_path) != 1 or binding.diagnostic_reason is None:
            continue
        child_name = binding.target_path[0]
        existing_reason = child_reasons.get(child_name)
        if existing_reason is not None and existing_reason != binding.diagnostic_reason:
            raise ValueError(
                f"Конфликт unresolved-диагностики для child '{element_path}.{child_name}': "
                f"{existing_reason!r} != {binding.diagnostic_reason!r}."
            )
        child_reasons[child_name] = binding.diagnostic_reason

    for child_name, child_config in child_configs.items():
        child_reason = child_reasons.get(child_name)
        if child_reason is None:
            continue
        child_element_name = (
            _extract_rendered_string(child_config, "name") or child_name
        )
        diagnostics.append(
            {
                "path": f"{element_path}.{child_name}",
                "element_type": child_name,
                "field_name": child_name,
                "element_name": child_element_name,
                "ui_label": (
                    _extract_rendered_string(child_config, "accessible_name")
                    or _extract_rendered_string(child_config, "text")
                    or _extract_rendered_string(child_config, "label")
                    or child_element_name
                ),
                "available_hints": {
                    key: value
                    for key, value in (
                        (
                            key,
                            _extract_rendered_string(child_config, key),
                        )
                        for key in (
                            "accessible_name",
                            "label",
                            "placeholder",
                            "text",
                            "title",
                            "test_id",
                            "url",
                            "html_name",
                            "locator",
                            "alt_text",
                            "aria_ref",
                        )
                    )
                    if value not in (None, "")
                },
                "reason": child_reason,
            }
        )

    return diagnostics


def _collect_table_dsl_unresolved_diagnostics(
    *,
    class_name: str,
    top_level_elements: list[SimpleElementRenderSpec],
    root_table_spec: TableRenderSpec,
    details_spec: DetailsRenderSpec | None,
) -> list[dict[str, object]]:
    root_prefix = to_snake_case(class_name)
    diagnostics: list[dict[str, object]] = []

    for element in top_level_elements:
        diagnostics.extend(
            _collect_simple_element_unresolved_diagnostics(
                element,
                prefix=root_prefix,
            )
        )

    if details_spec is not None:
        details_prefix = f"{root_prefix}.{root_table_spec.field_name}.row.details"
        for element in details_spec.fields:
            diagnostics.extend(
                _collect_simple_element_unresolved_diagnostics(
                    element,
                    prefix=details_prefix,
                )
            )

    return diagnostics


def _render_page_module(
    *,
    class_name: str,
    enum_specs: list[EnumRenderSpec],
    top_level_elements: list[SimpleElementRenderSpec],
    root_table_spec: TableRenderSpec,
    details_spec: DetailsRenderSpec | None,
    nested_table_spec: TableRenderSpec | None,
) -> str:
    required_imports = _collect_required_imports(
        top_level_elements=top_level_elements,
        root_table_spec=root_table_spec,
        details_spec=details_spec,
        nested_table_spec=nested_table_spec,
    )
    module_lines: list[str] = [
        "from __future__ import annotations",
        "",
        "from enum import Enum",
        "",
    ]
    module_lines.append("from persona_dsl.pages import (")
    module_lines.extend(f"    {import_name}," for import_name in required_imports)
    module_lines.extend(
        [
            ")",
            "",
        ]
    )
    enum_specs_by_name = {enum_spec.class_name: enum_spec for enum_spec in enum_specs}
    emitted_enums: set[str] = set()

    if _table_spec_uses_popup(root_table_spec) or (
        nested_table_spec is not None and _table_spec_uses_popup(nested_table_spec)
    ):
        module_lines.extend(_render_multiselect_popup_class())

    if details_spec is not None and _details_uses_class(
        details_spec, "TimeIntervalField"
    ):
        module_lines.extend(_render_time_interval_field_class())

    if details_spec is not None and _details_uses_class(details_spec, "DurationField"):
        module_lines.extend(_render_duration_field_class())

    if nested_table_spec is not None:
        _append_enum_blocks(
            module_lines=module_lines,
            enum_specs_by_name=enum_specs_by_name,
            emitted_enums=emitted_enums,
            enum_names=_table_spec_enum_names(nested_table_spec),
        )
        module_lines.extend(_render_row_elements_class(nested_table_spec))
        module_lines.extend(_render_filters_class(nested_table_spec))
        module_lines.extend(_render_row_class(nested_table_spec))
        module_lines.extend(
            _render_table_class(nested_table_spec, include_details=False)
        )
    if details_spec is not None:
        _append_enum_blocks(
            module_lines=module_lines,
            enum_specs_by_name=enum_specs_by_name,
            emitted_enums=emitted_enums,
            enum_names=_details_enum_names(
                details_spec=details_spec,
                known_enum_names=frozenset(enum_specs_by_name),
            ),
        )
        module_lines.extend(_render_details_class(details_spec))
    _append_enum_blocks(
        module_lines=module_lines,
        enum_specs_by_name=enum_specs_by_name,
        emitted_enums=emitted_enums,
        enum_names=_table_spec_enum_names(root_table_spec),
    )
    module_lines.extend(_render_row_elements_class(root_table_spec))
    module_lines.extend(_render_filters_class(root_table_spec))
    module_lines.extend(_render_row_class(root_table_spec))
    module_lines.extend(
        _render_table_class(root_table_spec, include_details=details_spec is not None)
    )
    _append_enum_blocks(
        module_lines=module_lines,
        enum_specs_by_name=enum_specs_by_name,
        emitted_enums=emitted_enums,
        enum_names=_simple_element_enum_names(
            top_level_elements,
            known_enum_names=frozenset(enum_specs_by_name),
        ),
    )
    module_lines.extend(
        _render_page_class(class_name, top_level_elements, root_table_spec)
    )

    unused_enums = [name for name in enum_specs_by_name if name not in emitted_enums]
    if unused_enums:
        raise ValueError(
            "Не удалось разместить Enum рядом с использованием в table DSL page: "
            f"{unused_enums}."
        )

    code = "\n".join(module_lines)
    return black.format_str(code, mode=black.Mode())


def _collect_required_imports(
    *,
    top_level_elements: list[SimpleElementRenderSpec],
    root_table_spec: TableRenderSpec,
    details_spec: DetailsRenderSpec | None,
    nested_table_spec: TableRenderSpec | None,
) -> list[str]:
    required: set[str] = {
        "Column",
        "Page",
        "Table",
        "TableColumn",
        "TableRow",
    }
    required.update(_column_binding_imports(root_table_spec.columns))
    if nested_table_spec is not None:
        required.update(_column_binding_imports(nested_table_spec.columns))

    for element in top_level_elements:
        required.add(element.class_name)
        if any("Strategy." in value for value in element.kwargs.values()):
            required.add("Strategy")

    if _table_spec_has_alias_namespace(root_table_spec) or (
        nested_table_spec is not None
        and _table_spec_has_alias_namespace(nested_table_spec)
    ):
        required.add("Generic")

    if details_spec is not None:
        required.add("Generic")
        for field in details_spec.fields:
            if field.class_name in {
                "Button",
                "Image",
                "Radio",
                "RadioGroup",
                "Select",
                "SpinButton",
                "Switch",
                "Text",
                "TextField",
            }:
                required.add(field.class_name)
            if any("Strategy." in value for value in field.kwargs.values()):
                required.add("Strategy")

        if _details_uses_class(details_spec, "TimeIntervalField"):
            required.update({"Generic", "TextField"})
        if _details_uses_class(details_spec, "DurationField"):
            required.update({"Generic", "Select", "SpinButton"})

    if _table_spec_uses_popup(root_table_spec) or (
        nested_table_spec is not None and _table_spec_uses_popup(nested_table_spec)
    ):
        required.update({"Button", "Generic", "ListBox"})

    import_order = [
        "BaseColumnFilter",
        "Button",
        "Column",
        "Generic",
        "Image",
        "ListBox",
        "MultiSelect",
        "MultiSelectColumnFilter",
        "NumberColumnFilter",
        "Page",
        "Radio",
        "RadioGroup",
        "Select",
        "SingleSelectColumnFilter",
        "SpinButton",
        "Strategy",
        "Switch",
        "Table",
        "TableColumn",
        "TableRow",
        "Text",
        "TextColumnFilter",
        "TextField",
        "TimeRangeColumnFilter",
    ]
    return [import_name for import_name in import_order if import_name in required]


def _render_enums(enum_specs: list[EnumRenderSpec]) -> list[str]:
    lines: list[str] = []
    for enum_spec in enum_specs:
        lines.append(f"class {enum_spec.class_name}(str, Enum):")
        for value in enum_spec.values:
            lines.append(f"    {_enum_member_name(value)} = {value!r}")
        lines.extend(["", ""])
    return lines


def _append_enum_blocks(
    *,
    module_lines: list[str],
    enum_specs_by_name: dict[str, EnumRenderSpec],
    emitted_enums: set[str],
    enum_names: list[str],
) -> None:
    pending_specs = [
        enum_specs_by_name[enum_name]
        for enum_name in enum_names
        if enum_name in enum_specs_by_name and enum_name not in emitted_enums
    ]
    if not pending_specs:
        return
    module_lines.extend(_render_enums(pending_specs))
    emitted_enums.update(enum_spec.class_name for enum_spec in pending_specs)


def _unique_enum_names(enum_names: list[str]) -> list[str]:
    return list(dict.fromkeys(enum_names))


def _binding_enum_names(
    bindings: tuple[ElementBindingRenderSpec, ...],
    *,
    known_enum_names: frozenset[str],
) -> list[str]:
    names: list[str] = []
    for binding in bindings:
        if binding.value in known_enum_names:
            names.append(binding.value)
    return _unique_enum_names(names)


def _simple_element_enum_names(
    elements: list[SimpleElementRenderSpec],
    *,
    known_enum_names: frozenset[str],
) -> list[str]:
    names: list[str] = []
    for element in elements:
        if element.variants_enum_name is not None:
            names.append(element.variants_enum_name)
        names.extend(
            _binding_enum_names(
                element.bindings,
                known_enum_names=known_enum_names,
            )
        )
    return _unique_enum_names(names)


def _details_enum_names(
    *,
    details_spec: DetailsRenderSpec,
    known_enum_names: frozenset[str],
) -> list[str]:
    return _simple_element_enum_names(
        details_spec.fields,
        known_enum_names=known_enum_names,
    )


def _table_spec_enum_names(table_spec: TableRenderSpec) -> list[str]:
    names: list[str] = []
    for column in table_spec.columns:
        if column.variants_enum_name is not None:
            names.append(column.variants_enum_name)
    return _unique_enum_names(names)


def _table_spec_uses_popup(table_spec: TableRenderSpec) -> bool:
    return any(column.popup_class_name is not None for column in table_spec.columns)


def _table_spec_has_alias_namespace(table_spec: TableRenderSpec) -> bool:
    return _table_spec_has_filters(table_spec) or _table_spec_has_row_elements(
        table_spec
    )


def _table_spec_has_filters(table_spec: TableRenderSpec) -> bool:
    return any(column.filter_class_name is not None for column in table_spec.columns)


def _table_spec_has_row_elements(table_spec: TableRenderSpec) -> bool:
    return any(not _is_default_text_column(column) for column in table_spec.columns)


def _details_uses_class(details_spec: DetailsRenderSpec, class_name: str) -> bool:
    return any(field.class_name == class_name for field in details_spec.fields)


def _column_binding_imports(columns: list[ColumnRenderSpec]) -> set[str]:
    required: set[str] = set()
    for column in columns:
        if not _is_default_text_column(column):
            required.add(column.cell_class_name)
        if column.filter_class_name is not None:
            required.add(column.filter_class_name)
    return required


def _is_default_text_column(column: ColumnRenderSpec) -> bool:
    return column.cell_class_name == "Text"


def _namespace_alias(member_name: str, *, namespace: str) -> str:
    alias = to_snake_case(member_name)
    reserved_names = {
        attr_name for attr_name in dir(Element) if not attr_name.startswith("_")
    }
    if alias not in reserved_names:
        return alias
    suffix = "_filter" if namespace == "filters" else "_element"
    return f"{alias}{suffix}"


def _render_multiselect_popup_class() -> list[str]:
    return [
        "class MultiSelectPopup(Generic):",
        '    select_all = Button(name="select_all", accessible_name="Выбрать все")',
        '    clear_all = Button(name="clear_all", accessible_name="Очистить все")',
        '    options = ListBox(name="options")',
        "",
        "",
    ]


def _render_time_interval_field_class() -> list[str]:
    return [
        "class TimeIntervalField(Generic):",
        '    start_date = TextField(name="start_date")',
        '    start_time = TextField(name="start_time")',
        '    end_date = TextField(name="end_date")',
        '    end_time = TextField(name="end_time")',
        "",
        "",
    ]


def _render_duration_field_class() -> list[str]:
    return [
        "class DurationField(Generic):",
        '    value = SpinButton(name="value")',
        '    unit = Select(name="unit")',
        "",
        "",
    ]


def _render_row_class(table_spec: TableRenderSpec) -> list[str]:
    lines = [f"class {table_spec.row_class_name}(TableRow):"]
    if _table_spec_has_row_elements(table_spec):
        row_elements_class_name = (
            f"{table_spec.class_name.replace('Table', '')}RowElements"
        )
        lines.append(f"    elements = {row_elements_class_name}()")
    else:
        lines.append("    pass")
    lines.extend(["", ""])
    return lines


def _render_filters_class(table_spec: TableRenderSpec) -> list[str]:
    filter_columns = [
        column for column in table_spec.columns if column.filter_class_name is not None
    ]
    if not filter_columns:
        return []

    lines = [f"class {table_spec.class_name.replace('Table', '')}Filters(Generic):"]
    for column in filter_columns:
        filter_expression = _render_column_filter_only_expression(column)
        lines.append(
            f"    {_namespace_alias(column.member_name, namespace='filters')} = {filter_expression}"
        )
    lines.extend(["", ""])
    return lines


def _render_row_elements_class(table_spec: TableRenderSpec) -> list[str]:
    element_columns = [
        column for column in table_spec.columns if not _is_default_text_column(column)
    ]
    if not element_columns:
        return []

    lines = [f"class {table_spec.class_name.replace('Table', '')}RowElements(Generic):"]
    for column in element_columns:
        cell_expression = _render_column_cell_only_expression(column)
        lines.append(
            f"    {_namespace_alias(column.member_name, namespace='elements')} = {cell_expression}"
        )
    lines.extend(["", ""])
    return lines


def _render_column_filter_only_expression(column: ColumnRenderSpec) -> str:
    filter_class_name = column.filter_class_name
    if filter_class_name is None:
        raise ValueError(
            f"Колонка '{column.title}' не содержит фильтра для Filters namespace."
        )
    kwargs: list[str] = [
        f'name="{_namespace_alias(column.member_name, namespace="filters")}"'
    ]
    if column.popup_class_name is not None:
        kwargs.append(f"popup_type={column.popup_class_name}")
    if column.variants_enum_name is not None:
        kwargs.append(f"variants={column.variants_enum_name}")
    rendered_kwargs = ", ".join(kwargs)
    if rendered_kwargs:
        return f"{filter_class_name}({rendered_kwargs})"
    return f"{filter_class_name}()"


def _render_column_cell_only_expression(column: ColumnRenderSpec) -> str:
    cell_class_name = column.cell_class_name
    if cell_class_name == "Text":
        return (
            f'Text(name="{_namespace_alias(column.member_name, namespace="elements")}")'
        )
    kwargs: list[str] = [
        f'name="{_namespace_alias(column.member_name, namespace="elements")}"'
    ]
    if column.variants_enum_name is not None and cell_class_name in {
        "Select",
        "MultiSelect",
    }:
        kwargs.append(f"variants={column.variants_enum_name}")
    rendered_kwargs = ", ".join(kwargs)
    if rendered_kwargs:
        return f"{cell_class_name}({rendered_kwargs})"
    return f"{cell_class_name}()"


def _render_table_class(
    table_spec: TableRenderSpec,
    *,
    include_details: bool,
) -> list[str]:
    lines = [
        f"class {table_spec.class_name}(Table):",
        "    class Columns(TableColumn):",
    ]
    for column in table_spec.columns:
        lines.extend(_render_column_assignment(column))

    lines.extend(["", f"    Row = {table_spec.row_class_name}"])
    if include_details and table_spec.details_class_name is not None:
        lines.append(f"    Details = {table_spec.details_class_name}")
    if _table_spec_has_filters(table_spec):
        lines.append(
            f"    Filters = {table_spec.class_name.replace('Table', '')}Filters"
        )
    if table_spec.has_selection:
        lines.append("    selection = True")
    if table_spec.has_expander:
        lines.append("    expansion = True")
    lines.extend(["", ""])
    return lines


def _render_details_class(details_spec: DetailsRenderSpec) -> list[str]:
    helper_lines: list[str] = []
    rendered_fields: list[SimpleElementRenderSpec] = []
    for field in details_spec.fields:
        class_lines, rendered_field = _materialize_bound_element(field)
        helper_lines.extend(class_lines)
        rendered_fields.append(rendered_field)

    lines = helper_lines + [f"class {details_spec.class_name}(Generic):"]
    for field in rendered_fields:
        base_expr, bindings = _render_element_expression(field)
        lines.extend(
            _render_assigned_expression(
                lhs=field.field_name,
                base_expr=base_expr,
                bindings=bindings,
            )
        )
    lines.extend(["", ""])
    return lines


def _render_page_class(
    class_name: str,
    top_level_elements: list[SimpleElementRenderSpec],
    root_table_spec: TableRenderSpec,
) -> list[str]:
    helper_lines: list[str] = []
    rendered_elements: list[SimpleElementRenderSpec] = []
    for element in top_level_elements:
        class_lines, rendered_element = _materialize_bound_element(element)
        helper_lines.extend(class_lines)
        rendered_elements.append(rendered_element)

    lines = helper_lines + [f"class {class_name}(Page):"]
    for element in rendered_elements:
        base_expr, bindings = _render_element_expression(element)
        lines.extend(
            _render_assigned_expression(
                lhs=element.field_name,
                base_expr=base_expr,
                bindings=bindings,
            )
        )

    table_kwargs = dict(root_table_spec.constructor_kwargs)
    rendered_table_kwargs = _render_kwargs(table_kwargs)
    table_base_expr = (
        f"{root_table_spec.class_name}({rendered_table_kwargs})"
        if rendered_table_kwargs
        else f"{root_table_spec.class_name}()"
    )
    lines.extend(
        _render_assigned_expression(
            lhs=root_table_spec.field_name,
            base_expr=table_base_expr,
            bindings=(),
        )
    )
    lines.append("")
    return lines


def _render_element_bindings(
    target: str,
    bindings: tuple[ElementBindingRenderSpec, ...],
) -> list[str]:
    if not bindings:
        return []

    root_config, child_configs = _split_binding_render_specs(bindings)
    lines: list[str] = []

    if root_config:
        lines.append(f"        {target}.configure(")
        for key, value in root_config.items():
            lines.append(f"            {key}={value},")
        lines.append("        )")

    if child_configs:
        lines.append(f"        {target}.configure_children(")
        for child_name, config in child_configs.items():
            rendered_config = ", ".join(
                f"{key!r}: {value}" for key, value in config.items()
            )
            lines.append(f"            {child_name}={{ {rendered_config} }},")
        lines.append("        )")

    return lines


def _split_binding_render_specs(
    bindings: tuple[ElementBindingRenderSpec, ...],
) -> tuple[dict[str, str], dict[str, dict[str, str]]]:
    root_config: dict[str, str] = {}
    child_configs: dict[str, dict[str, str]] = {}

    for binding in bindings:
        key_name = _binding_attribute_name(binding.attribute_name)
        if not binding.target_path:
            root_config[key_name] = binding.value
            continue
        if len(binding.target_path) != 1:
            path = ".".join(binding.target_path)
            raise ValueError(
                f"Неподдерживаемая глубина binding path '{path}' для table DSL."
            )
        child_name = binding.target_path[0]
        if child_name not in child_configs:
            child_configs[child_name] = {}
        child_configs[child_name][key_name] = binding.value

    return root_config, child_configs


def _child_element_class_name(parent_class_name: str, child_name: str) -> str:
    child_classes: dict[str, dict[str, str]] = {
        "TimeIntervalField": {
            "start_date": "TextField",
            "start_time": "TextField",
            "end_date": "TextField",
            "end_time": "TextField",
        },
        "DurationField": {
            "value": "SpinButton",
            "unit": "Select",
        },
    }
    declared_children = child_classes.get(parent_class_name)
    if declared_children is None:
        raise ValueError(
            f"Невозможно строго вывести child element class для '{parent_class_name}'."
        )
    child_class_name = declared_children.get(child_name)
    if child_class_name is None:
        raise ValueError(
            f"Класс '{parent_class_name}' не содержит поддерживаемого child '{child_name}'."
        )
    return child_class_name


def _materialize_bound_element(
    element: SimpleElementRenderSpec,
) -> tuple[list[str], SimpleElementRenderSpec]:
    if not element.bindings:
        return [], element

    root_relative_bindings = tuple(
        binding
        for binding in element.bindings
        if not binding.target_path
        and binding.attribute_name in {"relative_to", "relative_index"}
    )
    root_config, child_configs = _split_binding_render_specs(element.bindings)
    root_config = dict(root_config)
    root_config.pop("relative_to", None)
    root_config.pop("relative_index", None)
    rendered_kwargs = dict(element.kwargs)
    rendered_kwargs.update(root_config)

    if not child_configs:
        return (
            [],
            SimpleElementRenderSpec(
                field_name=element.field_name,
                class_name=element.class_name,
                kwargs=rendered_kwargs,
                diagnostic_reason=element.diagnostic_reason,
                variants_enum_name=element.variants_enum_name,
                bindings=root_relative_bindings,
            ),
        )

    helper_class_name = f"{to_pascal_case(element.field_name)}Field"
    helper_lines = [f"class {helper_class_name}({element.class_name}):"]
    for child_name, config in child_configs.items():
        child_class_name = _child_element_class_name(element.class_name, child_name)
        child_config = dict(config)
        relative_anchor = child_config.pop("relative_to", None)
        relative_index = child_config.pop("relative_index", None)
        child_kwargs = ", ".join(
            f"{key}={value}" for key, value in child_config.items()
        )
        if child_kwargs:
            child_expr = f"{child_class_name}({child_kwargs})"
        else:
            child_expr = f"{child_class_name}()"
        if relative_anchor is not None:
            if relative_index is not None and relative_index != "0":
                child_expr = f"{child_expr}.relative_to({relative_anchor}, index={relative_index})"
            else:
                child_expr = f"{child_expr}.relative_to({relative_anchor})"
        helper_lines.append(f"    {child_name} = {child_expr}")
    helper_lines.extend(["", ""])

    return (
        helper_lines,
        SimpleElementRenderSpec(
            field_name=element.field_name,
            class_name=helper_class_name,
            kwargs=rendered_kwargs,
            diagnostic_reason=element.diagnostic_reason,
            variants_enum_name=element.variants_enum_name,
            bindings=(),
        ),
    )


def _binding_attribute_name(attribute_name: str) -> str:
    if attribute_name == "_strategies":
        return "strategies"
    if attribute_name == "apply_variants":
        return "variants"
    if attribute_name in {"relative_to", "relative_index"}:
        return attribute_name
    return attribute_name


def _render_kwargs(
    kwargs: dict[str, str],
    *,
    name: str | None = None,
) -> str:
    parts: list[str] = []
    if name is not None:
        parts.append(f'name="{name}"')
    parts.extend(f"{key}={value}" for key, value in kwargs.items())
    return ", ".join(parts)


def _render_assigned_expression(
    *,
    lhs: str,
    base_expr: str,
    bindings: tuple[ElementBindingRenderSpec, ...] = (),
    indent: int = 4,
) -> list[str]:
    prefix = " " * indent
    if not bindings:
        return [f"{prefix}{lhs} = {base_expr}"]

    root_config, child_configs = _split_binding_render_specs(bindings)
    relative_anchor = root_config.pop("relative_to", None)
    relative_index = root_config.pop("relative_index", None)
    lines = [
        f"{prefix}{lhs} = (",
        f"{prefix}    {base_expr}",
    ]

    if relative_anchor is not None:
        if relative_index is not None and relative_index != "0":
            lines.append(
                f"{prefix}    .relative_to({relative_anchor}, index={relative_index})"
            )
        else:
            lines.append(f"{prefix}    .relative_to({relative_anchor})")

    if root_config:
        lines.append(f"{prefix}    .configure(")
        for key, value in root_config.items():
            lines.append(f"{prefix}        {key}={value},")
        lines.append(f"{prefix}    )")

    if child_configs:
        lines.append(f"{prefix}    .configure_children(")
        for child_name, config in child_configs.items():
            rendered_config = ", ".join(
                f"{key!r}: {value}" for key, value in config.items()
            )
            lines.append(f"{prefix}        {child_name}={{ {rendered_config} }},")
        lines.append(f"{prefix}    )")

    lines.append(f"{prefix})")
    return lines


def _render_element_expression(
    element: SimpleElementRenderSpec,
) -> tuple[str, tuple[ElementBindingRenderSpec, ...]]:
    kwargs = dict(element.kwargs)
    kwargs.pop("name", None)
    if element.variants_enum_name is not None:
        kwargs["variants"] = element.variants_enum_name
    rendered_kwargs = _render_kwargs(kwargs, name=element.field_name)
    if rendered_kwargs:
        return f"{element.class_name}({rendered_kwargs})", element.bindings
    return f"{element.class_name}()", element.bindings


def _render_column_assignment(column: ColumnRenderSpec) -> list[str]:
    filter_class_name = column.filter_class_name
    cell_class_name = column.cell_class_name
    assignment_prefix = f"        {column.member_name} = "
    if filter_class_name is None and cell_class_name == "Text":
        return [f"{assignment_prefix}Column({column.title!r})"]

    lines = [f"{assignment_prefix}Column(", f"            {column.title!r},"]

    if filter_class_name is not None:
        filter_kwargs: list[tuple[str, str]] = []
        if column.popup_class_name is not None:
            filter_kwargs.append(("popup_type", column.popup_class_name))
        if column.variants_enum_name is not None:
            filter_kwargs.append(("variants", column.variants_enum_name))
        if not filter_kwargs:
            lines.append(f"            filter={filter_class_name}(),")
        elif len(filter_kwargs) == 1:
            key, value = filter_kwargs[0]
            lines.append(f"            filter={filter_class_name}({key}={value}),")
        else:
            lines.append(f"            filter={filter_class_name}(")
            for key, value in filter_kwargs:
                lines.append(f"                {key}={value},")
            lines.append("            ),")

    if cell_class_name != "Text":
        cell_kwargs: list[tuple[str, str]] = []
        if column.variants_enum_name is not None and cell_class_name in {
            "Select",
            "MultiSelect",
        }:
            cell_kwargs.append(("variants", column.variants_enum_name))
        if not cell_kwargs:
            lines.append(f"            cell={cell_class_name}(),")
        elif len(cell_kwargs) == 1:
            key, value = cell_kwargs[0]
            lines.append(f"            cell={cell_class_name}({key}={value}),")
        else:
            lines.append(f"            cell={cell_class_name}(")
            for key, value in cell_kwargs:
                lines.append(f"                {key}={value},")
            lines.append("            ),")

    lines.append("        )")
    return lines


def _build_top_level_elements(
    elements_tree: list[PageElementNode],
    root_structure: TableStructure,
) -> list[SimpleElementRenderSpec]:
    top_level_specs: list[SimpleElementRenderSpec] = []
    ignored_tables = {id(root_structure.header_table), id(root_structure.body_table)}

    for element in elements_tree:
        if id(element) in ignored_tables:
            continue
        role = get_str(element, "role")
        field_name = _get_node_name(element)
        if role is None or field_name is None:
            continue
        if field_name in IGNORED_TOP_LEVEL_NAMES:
            continue

        class_name = PageEditor.get_class_name_for_role(role)
        if class_name == "Element":
            continue

        kwargs = _build_constructor_kwargs(element)
        top_level_specs.append(
            SimpleElementRenderSpec(
                field_name=field_name,
                class_name=class_name,
                kwargs=kwargs,
                diagnostic_reason=_extract_diagnostic_reason(element),
            )
        )

    return top_level_specs


def _build_table_spec(
    structure: TableStructure,
    enum_collector: EnumCollector,
) -> TableRenderSpec:
    column_cells = _extract_semantic_header_cells(structure.header_cells)
    if not column_cells:
        raise ValueError("Не удалось извлечь семантические колонки таблицы.")

    sample_row = structure.data_rows[0]
    sample_cells = _extract_row_cells(sample_row)
    columns = [
        _build_column_spec(header_entry, sample_cells, enum_collector)
        for header_entry in column_cells
    ]

    first_title = column_cells[0][2]
    field_name = _determine_table_field_name(structure.body_table, first_title)
    class_base_name = to_pascal_case(field_name)
    details_class_name = (
        f"{class_base_name}Details" if structure.expanded_rows else None
    )
    constructor_kwargs = _build_constructor_kwargs(
        structure.body_table,
        forced_name=field_name,
    )
    if id(structure.header_table) != id(structure.body_table):
        header_init_kwargs = as_object_map(structure.header_table.get("init_kwargs"))
        if header_init_kwargs is None:
            raise ValueError("Таблица заголовков не содержит init_kwargs.")
        header_ref = get_str(header_init_kwargs, "aria_ref")
        if header_ref is None:
            raise ValueError("Split-table не содержит aria_ref у таблицы заголовков.")
        constructor_kwargs["header_ref"] = repr(header_ref)
        header_index = header_init_kwargs.get("index")
        if not isinstance(header_index, int):
            raise ValueError(
                "Split-table не содержит целочисленный index у таблицы заголовков."
            )
        constructor_kwargs["header_index"] = str(header_index)

    return TableRenderSpec(
        field_name=field_name,
        class_name=f"{class_base_name}Table",
        row_class_name=f"{class_base_name}Row",
        details_class_name=details_class_name,
        constructor_kwargs=constructor_kwargs,
        columns=columns,
        has_selection=_has_selection_column(structure.header_cells),
        has_expander=_has_expander_column(structure.header_cells),
    )


def _build_column_spec(
    header_cell_entry: tuple[int, PageElementNode, str],
    sample_cells: list[PageElementNode],
    enum_collector: EnumCollector,
) -> ColumnRenderSpec:
    header_index, cell, title = header_cell_entry
    if header_index >= len(sample_cells):
        raise ValueError(
            f"Колонка '{title}' отсутствует в строке-примере. "
            f"Ожидался индекс ячейки {header_index}, доступно ячеек: {len(sample_cells)}."
        )

    header_filter_class_name = _classify_header_filter_class(title, cell)
    body_cell_class_name = _classify_body_cell_class(title, sample_cells[header_index])
    filter_class_name = header_filter_class_name
    cell_class_name = (
        "Text" if header_filter_class_name is not None else body_cell_class_name
    )
    popup_class_name: str | None = None
    if filter_class_name == "MultiSelectColumnFilter" and _header_filter_uses_popup(
        cell
    ):
        popup_class_name = "MultiSelectPopup"
    variants_enum_name = _resolve_column_variants_enum(
        enum_collector=enum_collector,
        header_title=title,
        header_filter_class_name=header_filter_class_name,
        body_cell_class_name=body_cell_class_name,
        header_cell=cell,
        body_cell=sample_cells[header_index],
    )

    return ColumnRenderSpec(
        member_name=_enum_member_name(title),
        title=title,
        filter_class_name=filter_class_name,
        cell_class_name=cell_class_name,
        popup_class_name=popup_class_name,
        variants_enum_name=variants_enum_name,
    )


def _build_details_spec(
    root_structure: TableStructure,
    enum_collector: EnumCollector,
) -> tuple[DetailsRenderSpec | None, TableRenderSpec | None]:
    if not root_structure.expanded_rows:
        return None, None

    expanded_row = root_structure.expanded_rows[0]
    expanded_cells = _extract_row_cells(expanded_row)
    if len(expanded_cells) != 1:
        raise ValueError("Expanded-row должен содержать ровно одну ячейку.")

    expanded_cell = expanded_cells[0]
    nested_structure = _find_nested_table_structure(expanded_cell)
    nested_table_spec = (
        _build_table_spec(nested_structure, enum_collector)
        if nested_structure is not None
        else None
    )
    nested_table_ids = _collect_nested_table_node_ids(nested_structure)

    root_field_name = _determine_table_field_name(
        root_structure.body_table,
        _extract_semantic_header_cells(root_structure.header_cells)[0][2],
    )
    details_class_name = f"{to_pascal_case(root_field_name)}Details"
    fields = _build_details_fields(
        expanded_cell,
        nested_table_spec,
        nested_table_ids,
        enum_collector,
    )
    if not fields:
        return None, nested_table_spec

    details_kwargs = _build_constructor_kwargs(
        expanded_cell, include_accessible_name=False
    )
    return (
        DetailsRenderSpec(
            class_name=details_class_name,
            kwargs=details_kwargs,
            fields=fields,
        ),
        nested_table_spec,
    )


def _build_details_fields(
    expanded_cell: PageElementNode,
    nested_table_spec: TableRenderSpec | None,
    nested_table_ids: set[int],
    enum_collector: EnumCollector,
) -> list[SimpleElementRenderSpec]:
    fields: list[SimpleElementRenderSpec] = []
    children = get_element_children(expanded_cell)
    index = 0

    while index < len(children):
        child = children[index]
        child_role = get_str(child, "role")
        child_name = _get_node_name(child)

        if id(child) in nested_table_ids:
            index += 1
            continue

        if _is_popup_node(child):
            index += 1
            continue

        if child_role == "table":
            index += 1
            continue

        if child_role == "radio":
            radio_group_match = _match_unlabeled_radio_group(children, index)
            if radio_group_match is not None:
                fields.extend(
                    _build_unlabeled_radio_group_fields(
                        radio_nodes=radio_group_match.radio_nodes,
                        trailing_combobox=radio_group_match.trailing_combobox,
                        enum_collector=enum_collector,
                    )
                )
                index = radio_group_match.next_index
                continue

        if child_role == "text":
            label_text = get_str(child, "text") or get_str(child, "name") or ""
            if _is_label_text(label_text):
                label_name = _label_to_field_name(label_text)
                group_nodes: list[PageElementNode] = []
                next_index = index + 1
                while next_index < len(children):
                    candidate = children[next_index]
                    if id(candidate) in nested_table_ids or _is_popup_node(candidate):
                        break
                    candidate_role = get_str(candidate, "role")
                    candidate_text = (
                        get_str(candidate, "text") or get_str(candidate, "name") or ""
                    )
                    if candidate_role == "table":
                        break
                    if candidate_role == "text" and _is_label_text(candidate_text):
                        break
                    if candidate_role == "radio" and group_nodes:
                        break
                    if candidate_role == "button" and _is_action_button(candidate):
                        break
                    group_nodes.append(candidate)
                    next_index += 1

                fields.extend(
                    _build_labeled_group_fields(
                        label_name,
                        group_nodes,
                        enum_collector=enum_collector,
                    )
                )
                index = next_index
                continue

            index += 1
            continue

        if child_role == "radio":
            fields.append(
                SimpleElementRenderSpec(
                    field_name=child_name or "radio",
                    class_name="Radio",
                    kwargs=_build_constructor_kwargs(
                        child,
                        forced_name=child_name or "radio",
                    ),
                    diagnostic_reason=_extract_diagnostic_reason(child),
                )
            )
            index += 1
            continue

        if child_role == "button" and child_name is not None:
            normalized_name = _normalize_action_button_name(child_name, child)
            fields.append(
                SimpleElementRenderSpec(
                    field_name=normalized_name,
                    class_name="Button",
                    kwargs=_build_constructor_kwargs(
                        child,
                        forced_name=normalized_name,
                    ),
                    diagnostic_reason=_extract_diagnostic_reason(child),
                )
            )
            index += 1
            continue

        if child_role == "switch" and child_name is not None:
            fields.append(
                SimpleElementRenderSpec(
                    field_name=child_name,
                    class_name="Switch",
                    kwargs=_build_constructor_kwargs(
                        child,
                        forced_name=child_name,
                    ),
                    diagnostic_reason=_extract_diagnostic_reason(child),
                )
            )
            index += 1
            continue

        if child_role == "textbox" and child_name is not None:
            fields.append(
                SimpleElementRenderSpec(
                    field_name=child_name,
                    class_name="TextField",
                    kwargs=_build_constructor_kwargs(
                        child,
                        forced_name=child_name,
                    ),
                    diagnostic_reason=_extract_diagnostic_reason(child),
                )
            )
            index += 1
            continue

        if child_role == "combobox" and child_name is not None:
            variants_enum_name = _extract_variants_enum_for_node(
                child,
                enum_collector=enum_collector,
                base_name=child_name,
            )
            fields.append(
                SimpleElementRenderSpec(
                    field_name=child_name,
                    class_name="Select",
                    kwargs=_build_constructor_kwargs(
                        child,
                        forced_name=child_name,
                    ),
                    diagnostic_reason=_extract_diagnostic_reason(child),
                    variants_enum_name=variants_enum_name,
                )
            )
            index += 1
            continue

        if child_role == "spinbutton" and child_name is not None:
            fields.append(
                SimpleElementRenderSpec(
                    field_name=child_name,
                    class_name="SpinButton",
                    kwargs=_build_constructor_kwargs(
                        child,
                        forced_name=child_name,
                    ),
                    diagnostic_reason=_extract_diagnostic_reason(child),
                )
            )
            index += 1
            continue

        index += 1

    if nested_table_spec is not None:
        fields.append(
            SimpleElementRenderSpec(
                field_name=nested_table_spec.field_name,
                class_name=nested_table_spec.class_name,
                kwargs=dict(nested_table_spec.constructor_kwargs),
                diagnostic_reason=None,
            )
        )

    return fields


def _build_unlabeled_radio_group_fields(
    *,
    radio_nodes: list[PageElementNode],
    trailing_combobox: PageElementNode | None,
    enum_collector: EnumCollector,
) -> list[SimpleElementRenderSpec]:
    radio_values = [
        _require_accessible_name(radio, context="radio_group") for radio in radio_nodes
    ]
    naming_spec = _resolve_unlabeled_radio_group_naming(radio_values)
    if naming_spec is None:
        group_name = _derive_radio_group_field_name(radio_nodes)
        enum_base_name = group_name
    else:
        group_name = naming_spec.group_field_name
        enum_base_name = naming_spec.enum_base_name
    variants_enum_name = _register_enum_from_values(
        enum_collector,
        base_name=enum_base_name,
        values=radio_values,
    )

    fields = [
        SimpleElementRenderSpec(
            field_name=group_name,
            class_name="RadioGroup",
            kwargs={},
            variants_enum_name=variants_enum_name,
        )
    ]

    if trailing_combobox is not None:
        select_field_name: str
        if naming_spec is not None and naming_spec.select_field_name is not None:
            select_field_name = naming_spec.select_field_name
        else:
            trailing_name = _get_node_name(trailing_combobox)
            if trailing_name is not None and trailing_name != "combobox":
                select_field_name = trailing_name
            else:
                select_field_name = f"{group_name}_select"
        select_variants_enum_name = _extract_variants_enum_for_node(
            trailing_combobox,
            enum_collector=enum_collector,
            base_name=select_field_name,
        )
        fields.append(
            SimpleElementRenderSpec(
                field_name=select_field_name,
                class_name="Select",
                kwargs=_build_constructor_kwargs(
                    trailing_combobox,
                    forced_name=select_field_name,
                ),
                diagnostic_reason=None,
                variants_enum_name=select_variants_enum_name,
                bindings=_build_relative_binding_specs(
                    (),
                    anchor_expr=(
                        f"{group_name}.choice("
                        f"{variants_enum_name}.{_enum_member_name(radio_values[-1])}"
                        f")"
                    ),
                ),
            )
        )

    return fields


def _resolve_unlabeled_radio_group_naming(
    radio_values: list[str],
) -> UnlabeledRadioGroupNamingSpec | None:
    values_key = frozenset(radio_values)
    return KNOWN_UNLABELED_RADIO_GROUPS.get(values_key)


def _match_unlabeled_radio_group(
    children: list[PageElementNode],
    start_index: int,
) -> UnlabeledRadioGroupMatch | None:
    if get_str(children[start_index], "role") != "radio":
        return None

    radio_nodes: list[PageElementNode] = []
    next_index = start_index

    while next_index < len(children):
        candidate = children[next_index]
        candidate_role = get_str(candidate, "role")
        if candidate_role == "radio":
            radio_nodes.append(candidate)
            next_index += 1
            continue
        if (
            candidate_role == "text"
            and radio_nodes
            and _is_radio_caption_text(candidate, radio_nodes[-1])
        ):
            next_index += 1
            continue
        break

    if len(radio_nodes) < 2:
        return None

    trailing_combobox: PageElementNode | None = None
    if (
        next_index < len(children)
        and get_str(children[next_index], "role") == "combobox"
    ):
        trailing_combobox = children[next_index]
        next_index += 1
        if (
            next_index < len(children)
            and get_str(children[next_index], "role") == "text"
            and not _is_label_text(
                get_str(children[next_index], "text")
                or get_str(children[next_index], "name")
                or ""
            )
        ):
            next_index += 1

    return UnlabeledRadioGroupMatch(
        radio_nodes=radio_nodes,
        trailing_combobox=trailing_combobox,
        next_index=next_index,
    )


def _is_radio_caption_text(
    text_node: PageElementNode,
    radio_node: PageElementNode,
) -> bool:
    text_value = (
        get_str(text_node, "text") or get_str(text_node, "name") or ""
    ).strip()
    if not text_value:
        return False
    radio_text = _require_accessible_name(radio_node, context="radio_caption").strip()
    return text_value == radio_text


def _derive_radio_group_field_name(radio_nodes: list[PageElementNode]) -> str:
    normalized_names = [
        _normalize_radio_group_name_source(node) for node in radio_nodes
    ]
    common_stem = _longest_common_substring(normalized_names)
    trimmed_stem = common_stem.strip("_")
    if len(trimmed_stem) < 4:
        joined_names = ", ".join(normalized_names)
        raise ValueError(
            "Невозможно строго вывести имя unlabeled radio-group из snapshot. "
            f"Доступные источники: {joined_names}."
        )
    return trimmed_stem


def _normalize_radio_group_name_source(node: PageElementNode) -> str:
    node_name = _get_node_name(node)
    if node_name:
        return to_snake_case(node_name)
    return to_snake_case(_require_accessible_name(node, context="radio_group"))


def _longest_common_substring(values: list[str]) -> str:
    if not values:
        raise ValueError("Список значений для common substring пуст.")
    shortest = min(values, key=len)
    best_match = ""
    shortest_length = len(shortest)
    for start in range(shortest_length):
        for end in range(start + 1, shortest_length + 1):
            candidate = shortest[start:end]
            if len(candidate) <= len(best_match):
                continue
            if all(candidate in value for value in values):
                best_match = candidate
    return best_match


def _build_labeled_group_fields(
    label_name: str,
    group_nodes: list[PageElementNode],
    enum_collector: EnumCollector,
) -> list[SimpleElementRenderSpec]:
    textboxes = _collect_group_nodes_by_role(group_nodes, "textbox")
    comboboxes = _collect_group_nodes_by_role(group_nodes, "combobox")
    radios = _collect_group_nodes_by_role(group_nodes, "radio")
    switches = _collect_group_nodes_by_role(group_nodes, "switch")
    spinbuttons = _collect_group_nodes_by_role(group_nodes, "spinbutton")
    buttons = _collect_group_nodes_by_role(group_nodes, "button")

    if (
        len(textboxes) == 4
        and not comboboxes
        and not radios
        and not switches
        and not spinbuttons
    ):
        bindings = [
            *_build_child_binding_specs(("start_time",), textboxes[1]),
            *_build_child_binding_specs(
                ("start_date",),
                textboxes[0],
                diagnostic_reason_override=None,
            ),
            *_build_relative_binding_specs(
                ("start_date",),
                anchor_expr="start_time",
            ),
            *_build_child_binding_specs(("end_time",), textboxes[3]),
            *_build_child_binding_specs(
                ("end_date",),
                textboxes[2],
                diagnostic_reason_override=None,
            ),
            *_build_relative_binding_specs(
                ("end_date",),
                anchor_expr="end_time",
            ),
        ]
        return [
            SimpleElementRenderSpec(
                field_name=label_name,
                class_name="TimeIntervalField",
                kwargs=_build_group_root_kwargs(group_nodes),
                diagnostic_reason=None,
                bindings=tuple(bindings),
            )
        ]

    if (
        len(spinbuttons) == 1
        and len(comboboxes) == 1
        and not textboxes
        and not radios
        and not switches
    ):
        unit_variants_enum_name = _extract_variants_enum_for_node(
            comboboxes[0],
            enum_collector=enum_collector,
            base_name=f"{label_name}_unit",
        )
        bindings = [
            *_build_child_binding_specs(("value",), spinbuttons[0]),
            *_build_child_binding_specs(("unit",), comboboxes[0]),
        ]
        if unit_variants_enum_name is not None:
            bindings.append(
                ElementBindingRenderSpec(
                    ("unit",),
                    "apply_variants",
                    unit_variants_enum_name,
                )
            )
        return [
            SimpleElementRenderSpec(
                field_name=label_name,
                class_name="DurationField",
                kwargs=_build_group_root_kwargs(group_nodes),
                diagnostic_reason=None,
                bindings=tuple(bindings),
            )
        ]

    if (
        len(textboxes) == 1
        and not comboboxes
        and not radios
        and not switches
        and not spinbuttons
    ):
        fields = [
            SimpleElementRenderSpec(
                field_name=label_name,
                class_name="TextField",
                kwargs=_build_constructor_kwargs(
                    textboxes[0],
                    forced_name=label_name,
                ),
                diagnostic_reason=_extract_diagnostic_reason(textboxes[0]),
            )
        ]
        if len(buttons) == 1:
            fields.append(
                SimpleElementRenderSpec(
                    field_name=f"open_{label_name}",
                    class_name="Button",
                    kwargs=_build_constructor_kwargs(
                        buttons[0],
                        forced_name=f"open_{label_name}",
                    ),
                    diagnostic_reason=None,
                    bindings=_build_relative_binding_specs(
                        (),
                        anchor_expr=label_name,
                    ),
                )
            )
        elif len(buttons) > 1:
            raise ValueError(
                f"Группа '{label_name}' содержит несколько кнопок. "
                "Table DSL не поддерживает такую структуру."
            )
        return fields

    if (
        len(switches) == 1
        and not textboxes
        and not comboboxes
        and not radios
        and not spinbuttons
    ):
        return [
            SimpleElementRenderSpec(
                field_name=label_name,
                class_name="Switch",
                kwargs=_build_constructor_kwargs(
                    switches[0],
                    forced_name=label_name,
                ),
                diagnostic_reason=_extract_diagnostic_reason(switches[0]),
            )
        ]

    if (
        len(comboboxes) == 1
        and not textboxes
        and not radios
        and not switches
        and not spinbuttons
    ):
        variants_enum_name = _extract_variants_enum_for_node(
            comboboxes[0],
            enum_collector=enum_collector,
            base_name=label_name,
        )
        return [
            SimpleElementRenderSpec(
                field_name=label_name,
                class_name="Select",
                kwargs=_build_constructor_kwargs(
                    comboboxes[0],
                    forced_name=label_name,
                ),
                diagnostic_reason=_extract_diagnostic_reason(comboboxes[0]),
                variants_enum_name=variants_enum_name,
            )
        ]

    if (
        len(radios) >= 2
        and not textboxes
        and not comboboxes
        and not switches
        and not spinbuttons
    ):
        variants_enum_name = _register_enum_from_values(
            enum_collector,
            base_name=label_name,
            values=[
                _require_accessible_name(radio, context=label_name) for radio in radios
            ],
        )
        return [
            SimpleElementRenderSpec(
                field_name=label_name,
                class_name="RadioGroup",
                kwargs={},
                variants_enum_name=variants_enum_name,
            )
        ]

    if (
        len(spinbuttons) == 1
        and not textboxes
        and not comboboxes
        and not radios
        and not switches
    ):
        return [
            SimpleElementRenderSpec(
                field_name=label_name,
                class_name="SpinButton",
                kwargs=_build_constructor_kwargs(
                    spinbuttons[0],
                    forced_name=label_name,
                ),
                diagnostic_reason=_extract_diagnostic_reason(spinbuttons[0]),
            )
        ]

    if not group_nodes:
        return []

    roles = ", ".join(get_str(node, "role") or "unknown" for node in group_nodes)
    raise ValueError(
        f"Группа деталей '{label_name}' не поддерживается table DSL. "
        f"Роли элементов: {roles}."
    )


def _collect_group_nodes_by_role(
    group_nodes: list[PageElementNode],
    target_role: str,
) -> list[PageElementNode]:
    collected: list[PageElementNode] = []
    for node in group_nodes:
        collected.extend(_collect_descendants_by_role(node, target_role))
    return collected


def _build_constructor_kwargs(
    node: PageElementNode,
    *,
    include_accessible_name: bool = True,
    forced_name: str | None = None,
) -> dict[str, str]:
    init_kwargs = as_object_map(node.get("init_kwargs"))
    if init_kwargs is None:
        raise ValueError(
            f"Элемент role='{get_str(node, 'role')}' не содержит init_kwargs."
        )

    kwargs: dict[str, str] = {}
    if forced_name is not None:
        kwargs["name"] = repr(forced_name)
    string_keys = [
        "label",
        "placeholder",
        "text",
        "alt_text",
        "title",
        "html_name",
        "test_id",
        "aria_ref",
        "url",
        "locator",
    ]
    if include_accessible_name:
        string_keys.insert(0, "accessible_name")
    if forced_name is None:
        string_keys.insert(0, "name")
    for key in string_keys:
        raw_value = init_kwargs.get(key)
        if isinstance(raw_value, str) and raw_value:
            kwargs[key] = repr(raw_value)

    index_value = init_kwargs.get("index")
    has_only_ref_binding = "aria_ref" in kwargs and not any(
        key in kwargs
        for key in (
            "accessible_name",
            "label",
            "placeholder",
            "text",
            "alt_text",
            "title",
            "html_name",
            "test_id",
            "url",
            "locator",
        )
    )
    if isinstance(index_value, int) and not has_only_ref_binding:
        kwargs["index"] = str(index_value)

    return kwargs


def _build_child_binding_specs(
    target_path: tuple[str, ...],
    node: PageElementNode,
    *,
    include_accessible_name: bool = True,
    diagnostic_reason_override: str | None | object = _DIAGNOSTIC_REASON_UNSET,
) -> tuple[ElementBindingRenderSpec, ...]:
    kwargs = _build_constructor_kwargs(
        node,
        include_accessible_name=include_accessible_name,
        forced_name=target_path[-1],
    )
    diagnostic_reason = _extract_diagnostic_reason(node)
    if diagnostic_reason_override is not _DIAGNOSTIC_REASON_UNSET:
        if diagnostic_reason_override is not None and not isinstance(
            diagnostic_reason_override, str
        ):
            raise TypeError(
                "diagnostic_reason_override должен быть строкой, None или sentinel."
            )
        diagnostic_reason = diagnostic_reason_override
    return tuple(
        ElementBindingRenderSpec(
            target_path,
            key,
            value,
            diagnostic_reason=diagnostic_reason,
        )
        for key, value in kwargs.items()
    )


def _build_relative_binding_specs(
    target_path: tuple[str, ...],
    *,
    anchor_expr: str,
    index: int = 0,
) -> tuple[ElementBindingRenderSpec, ...]:
    specs = [
        ElementBindingRenderSpec(
            target_path=target_path,
            attribute_name="relative_to",
            value=anchor_expr,
            diagnostic_reason=None,
        )
    ]
    if index:
        specs.append(
            ElementBindingRenderSpec(
                target_path=target_path,
                attribute_name="relative_index",
                value=str(index),
                diagnostic_reason=None,
            )
        )
    return tuple(specs)


def _extract_diagnostic_reason(node: PageElementNode) -> str | None:
    init_kwargs = as_object_map(node.get("init_kwargs"))
    if init_kwargs is None:
        raise ValueError(
            f"Элемент role='{get_str(node, 'role')}' не содержит init_kwargs."
        )
    raw_reason = init_kwargs.get("diagnostic_reason")
    if raw_reason is None:
        return None
    if not isinstance(raw_reason, str) or not raw_reason:
        raise ValueError("diagnostic_reason должен быть непустой строкой.")
    return raw_reason


def _build_group_root_kwargs(group_nodes: list[PageElementNode]) -> dict[str, str]:
    if len(group_nodes) != 1:
        return {}
    return _build_constructor_kwargs(group_nodes[0], include_accessible_name=False)


def _get_options_values(node: PageElementNode) -> list[str]:
    raw_values = node.get("options_values")
    if not isinstance(raw_values, list):
        return []
    values: list[str] = []
    for index, raw_value in enumerate(raw_values):
        if not isinstance(raw_value, str) or not raw_value:
            raise ValueError(f"options_values[{index}] должен быть непустой строкой.")
        values.append(raw_value)
    return values


def _collect_option_sources(node: PageElementNode) -> list[PageElementNode]:
    sources: list[PageElementNode] = []

    def visit(current: PageElementNode) -> None:
        if _get_options_values(current):
            sources.append(current)
        for child in get_element_children(current):
            visit(child)

    visit(node)
    return sources


def _extract_variants_enum_for_node(
    node: PageElementNode,
    *,
    enum_collector: EnumCollector,
    base_name: str,
) -> str | None:
    option_sources = _collect_option_sources(node)
    if not option_sources:
        return None

    option_sets = {tuple(_get_options_values(source)) for source in option_sources}
    if len(option_sets) != 1:
        raise ValueError(
            f"Элемент '{base_name}' содержит несколько несовместимых наборов вариантов."
        )

    values = list(next(iter(option_sets)))
    return _register_enum_from_values(
        enum_collector,
        base_name=base_name,
        values=values,
    )


def _register_enum_from_values(
    enum_collector: EnumCollector,
    *,
    base_name: str,
    values: list[str],
) -> str:
    return enum_collector.register(base_name=base_name, values=values)


def _require_accessible_name(node: PageElementNode, *, context: str) -> str:
    init_kwargs = as_object_map(node.get("init_kwargs")) or {}
    accessible_name = get_str(init_kwargs, "accessible_name")
    if accessible_name:
        return accessible_name
    raw_name = get_str(node, "name")
    if raw_name:
        return raw_name
    raise ValueError(
        f"Элемент '{context}' не содержит accessible_name/name для генерации Enum."
    )


def _resolve_column_variants_enum(
    *,
    enum_collector: EnumCollector,
    header_title: str,
    header_filter_class_name: str | None,
    body_cell_class_name: str,
    header_cell: PageElementNode,
    body_cell: PageElementNode,
) -> str | None:
    filter_classes = {
        "SingleSelectColumnFilter",
        "MultiSelectColumnFilter",
    }
    body_cell_classes = {
        "Text",
        "Select",
        "MultiSelect",
    }

    if header_filter_class_name in filter_classes:
        return _extract_variants_enum_for_node(
            header_cell,
            enum_collector=enum_collector,
            base_name=f"{to_snake_case(header_title)}_filter",
        )

    if body_cell_class_name in body_cell_classes:
        return _extract_variants_enum_for_node(
            body_cell,
            enum_collector=enum_collector,
            base_name=to_snake_case(header_title),
        )

    return None


def _determine_table_field_name(table_node: PageElementNode, first_title: str) -> str:
    init_kwargs = as_object_map(table_node.get("init_kwargs")) or {}

    raw_name = get_str(init_kwargs, "name")
    if raw_name and not _is_generic_table_name(raw_name):
        return to_snake_case(raw_name)

    accessible_name = get_str(init_kwargs, "accessible_name")
    if accessible_name:
        normalized_accessible_name = to_snake_case(accessible_name)
        if normalized_accessible_name and not _is_generic_table_name(
            normalized_accessible_name
        ):
            return normalized_accessible_name

    return KNOWN_TABLE_FIELD_NAMES.get(first_title, to_snake_case(first_title))


def _is_generic_table_name(value: str) -> bool:
    return re.fullmatch(r"table(_\d+)?", value) is not None


def _get_node_name(node: PageElementNode) -> str | None:
    init_kwargs = as_object_map(node.get("init_kwargs")) or {}
    raw_name = get_str(init_kwargs, "name")
    if raw_name:
        return raw_name
    return get_str(node, "name")


def _require_aria_ref(node: PageElementNode, *, context: str) -> str:
    init_kwargs = as_object_map(node.get("init_kwargs")) or {}
    aria_ref = get_str(init_kwargs, "aria_ref")
    if aria_ref:
        return aria_ref
    raise ValueError(
        f"Элемент '{context}' не содержит aria_ref, необходимый для table DSL."
    )


def _normalize_action_button_name(raw_name: str, node: PageElementNode) -> str:
    accessible_name = get_str(
        as_object_map(node.get("init_kwargs")) or {}, "accessible_name"
    )
    if accessible_name in SAVE_BUTTON_TITLES:
        return "save"
    if accessible_name in CANCEL_BUTTON_TITLES:
        return "cancel"
    return raw_name


def _is_action_button(node: PageElementNode) -> bool:
    init_kwargs = as_object_map(node.get("init_kwargs")) or {}
    accessible_name = get_str(init_kwargs, "accessible_name")
    return accessible_name in SAVE_BUTTON_TITLES | CANCEL_BUTTON_TITLES


def _is_label_text(text: str) -> bool:
    return bool(text.strip().endswith(":"))


def _label_to_field_name(text: str) -> str:
    return to_snake_case(text.removesuffix(":").strip())


def _find_nested_table_structure(
    expanded_cell: PageElementNode,
) -> TableStructure | None:
    nested_tables = [
        node
        for node in _collect_descendants(expanded_cell)
        if get_str(node, "role") == "table"
    ]
    if not nested_tables:
        return None
    nested_structures = _analyze_top_level_structures(nested_tables)
    if not nested_structures:
        return None
    if len(nested_structures) > 1:
        raise ValueError(
            "Expanded-row содержит более одной вложенной таблицы. "
            "Table DSL пока не поддерживает такой случай."
        )
    return nested_structures[0]


def _collect_nested_table_node_ids(
    nested_structure: TableStructure | None,
) -> set[int]:
    if nested_structure is None:
        return set()
    return {
        id(nested_structure.header_table),
        id(nested_structure.body_table),
    }


def _is_popup_node(node: PageElementNode) -> bool:
    roles = _collect_roles(node)
    if "listbox" not in roles and "option" not in roles:
        return False
    return "button" in roles


def _analyze_top_level_structures(
    tables: list[PageElementNode],
) -> list[TableStructure]:
    structures: list[TableStructure] = []
    index = 0
    while index < len(tables):
        current_table = tables[index]
        current_kind = _classify_table_kind(current_table)

        if current_kind == "header_only":
            if index + 1 >= len(tables):
                raise ValueError(
                    "Split-table: найдена таблица заголовков без следующей body-таблицы."
                )
            body_table = tables[index + 1]
            body_kind = _classify_table_kind(body_table)
            if body_kind != "body_only":
                raise ValueError(
                    "Split-table: после таблицы заголовков ожидалась body-таблица."
                )
            _validate_split_table_pair(current_table, body_table)
            structures.append(_combine_split_tables(current_table, body_table))
            index += 2
            continue

        if current_kind == "body_only":
            raise ValueError(
                "Найдена body-таблица без предшествующей таблицы заголовков."
            )

        structures.append(_analyze_single_table(current_table))
        index += 1

    return structures


def _classify_table_kind(table: PageElementNode) -> str:
    rows = _collect_rows(table)
    header_row = _find_header_row(rows)
    normal_rows = _normal_data_rows(rows)
    if header_row is not None and not normal_rows:
        return "header_only"
    if header_row is None and normal_rows:
        return "body_only"
    if header_row is not None and normal_rows:
        return "self_contained"
    raise ValueError("Таблица не содержит ни заголовков, ни строк данных.")


def _validate_split_table_pair(
    header_table: PageElementNode,
    body_table: PageElementNode,
) -> None:
    header_rows = _collect_rows(header_table)
    header_row = _find_header_row(header_rows)
    if header_row is None:
        raise ValueError("Split-table: не найдена header-row в таблице заголовков.")

    body_rows = _collect_rows(body_table)
    normal_rows = _normal_data_rows(body_rows)
    if not normal_rows:
        raise ValueError("Split-table: не найдены строки данных в body-таблице.")

    header_cells = _extract_row_cells(header_row)
    first_body_cells = _extract_row_cells(normal_rows[0])
    if len(header_cells) == len(first_body_cells):
        return
    if len(header_cells) == len(first_body_cells) + 1 and _is_placeholder_cell(
        header_cells[-1]
    ):
        return
    if len(header_cells) != len(first_body_cells):
        raise ValueError(
            "Split-table: количество колонок в header/body таблицах не совпадает."
        )


def _is_placeholder_cell(cell: PageElementNode) -> bool:
    cell_name = (get_str(cell, "name") or "").strip()
    return cell_name == ""


def _combine_split_tables(
    header_table: PageElementNode,
    body_table: PageElementNode,
) -> TableStructure:
    header_rows = _collect_rows(header_table)
    header_row = _find_header_row(header_rows)
    if header_row is None:
        raise ValueError("Split-table: не найдена header-row в таблице заголовков.")

    body_rows = _collect_rows(body_table)
    data_rows = _normal_data_rows(body_rows)
    expanded_rows = _expanded_rows(body_rows)
    if not data_rows:
        raise ValueError("Split-table: не найдены строки данных в body-таблице.")

    return TableStructure(
        header_table=header_table,
        body_table=body_table,
        header_row=header_row,
        header_cells=_extract_row_cells(header_row),
        data_rows=data_rows,
        expanded_rows=expanded_rows,
    )


def _analyze_single_table(table: PageElementNode) -> TableStructure:
    rows = _collect_rows(table)
    header_row = _find_header_row(rows)
    if header_row is None:
        raise ValueError("Таблица не содержит header-row.")

    data_rows = _normal_data_rows(rows)
    if not data_rows:
        raise ValueError("Таблица не содержит строк данных.")

    return TableStructure(
        header_table=table,
        body_table=table,
        header_row=header_row,
        header_cells=_extract_row_cells(header_row),
        data_rows=data_rows,
        expanded_rows=_expanded_rows(rows),
    )


def _collect_rows(node: PageElementNode) -> list[PageElementNode]:
    rows: list[PageElementNode] = []
    for child in get_element_children(node):
        if get_str(child, "role") == "table":
            continue
        if get_str(child, "role") == "row":
            rows.append(child)
        rows.extend(_collect_rows(child))
    return rows


def _find_header_row(rows: list[PageElementNode]) -> PageElementNode | None:
    for row in rows:
        cells = _extract_row_cells(row)
        if any(get_str(cell, "role") == "columnheader" for cell in cells):
            return row
    return None


def _extract_row_cells(row: PageElementNode) -> list[PageElementNode]:
    return [
        child
        for child in get_element_children(row)
        if get_str(child, "role") in {"cell", "columnheader", "rowheader"}
    ]


def _normal_data_rows(rows: list[PageElementNode]) -> list[PageElementNode]:
    data_rows: list[PageElementNode] = []
    for row in rows:
        cells = _extract_row_cells(row)
        if not cells:
            continue
        if any(get_str(cell, "role") == "columnheader" for cell in cells):
            continue
        if _is_expanded_row(row):
            continue
        data_rows.append(row)
    return data_rows


def _expanded_rows(rows: list[PageElementNode]) -> list[PageElementNode]:
    return [row for row in rows if _is_expanded_row(row)]


def _is_expanded_row(row: PageElementNode) -> bool:
    cells = _extract_row_cells(row)
    if len(cells) != 1:
        return False
    return _contains_roles(
        cells[0],
        {"table", "switch", "radio", "combobox", "listbox", "spinbutton", "button"},
    )


def _contains_roles(node: PageElementNode, roles: set[str]) -> bool:
    node_role = get_str(node, "role")
    if node_role in roles:
        return True
    return any(_contains_roles(child, roles) for child in get_element_children(node))


def _extract_semantic_header_cells(
    header_cells: list[PageElementNode],
) -> list[tuple[int, PageElementNode, str]]:
    semantic_cells: list[tuple[int, PageElementNode, str]] = []
    for index, cell in enumerate(header_cells):
        title = _extract_header_title(cell)
        if title:
            semantic_cells.append((index, cell, title))
    return semantic_cells


def _extract_header_title(cell: PageElementNode) -> str:
    for child in get_element_children(cell):
        if get_str(child, "role") in {"heading", "text"}:
            label = clean_header_text(get_str(child, "name") or "")
            if label:
                return label

    if _contains_roles(cell, {"checkbox"}) or _contains_roles(cell, {"button"}):
        return ""

    accessible_name = clean_header_text(get_str(cell, "name") or "")
    return accessible_name


def _classify_header_filter_class(title: str, cell: PageElementNode) -> str | None:
    descendant_roles = _collect_roles(cell)
    textbox_count = len(_collect_descendants_by_role(cell, "textbox"))
    if "spinbutton" in descendant_roles:
        return "NumberColumnFilter"
    if textbox_count >= 2:
        return "TimeRangeColumnFilter"
    if textbox_count == 1:
        return "TextColumnFilter"
    if "listbox" in descendant_roles:
        return "MultiSelectColumnFilter"
    if "combobox" in descendant_roles:
        if _header_filter_uses_popup(cell) or title in KNOWN_MULTISELECT_TITLES:
            return "MultiSelectColumnFilter"
        return "SingleSelectColumnFilter"
    return None


def _classify_body_cell_class(title: str, cell: PageElementNode) -> str:
    descendant_roles = _collect_roles(cell)
    if "switch" in descendant_roles:
        return "Switch"
    if "spinbutton" in descendant_roles:
        return "SpinButton"
    if "listbox" in descendant_roles:
        return "MultiSelect"
    if "combobox" in descendant_roles:
        if title in KNOWN_MULTISELECT_TITLES:
            return "MultiSelect"
        return "Select"
    return "Text"


def _header_filter_uses_popup(cell: PageElementNode) -> bool:
    descendant_roles = _collect_roles(cell)
    if "listbox" in descendant_roles:
        return False
    return _has_test_id_container(cell)


def _collect_roles(node: PageElementNode) -> set[str]:
    roles: set[str] = set()
    role = get_str(node, "role")
    if role:
        roles.add(role)
    for child in get_element_children(node):
        roles.update(_collect_roles(child))
    return roles


def _collect_descendants_by_role(
    node: PageElementNode,
    target_role: str,
) -> list[PageElementNode]:
    matches: list[PageElementNode] = []
    if get_str(node, "role") == target_role:
        matches.append(node)
    for child in get_element_children(node):
        matches.extend(_collect_descendants_by_role(child, target_role))
    return matches


def _has_test_id_container(node: PageElementNode) -> bool:
    init_kwargs = as_object_map(node.get("init_kwargs"))
    test_id = get_str(init_kwargs or {}, "test_id")
    if test_id:
        return True
    return any(_has_test_id_container(child) for child in get_element_children(node))


def _has_selection_column(header_cells: list[PageElementNode]) -> bool:
    return any(_contains_roles(cell, {"checkbox"}) for cell in header_cells[:2])


def _has_expander_column(header_cells: list[PageElementNode]) -> bool:
    if not header_cells:
        return False
    first_title = _extract_header_title(header_cells[0])
    return not first_title


def _is_complex_table(structure: TableStructure) -> bool:
    semantic_header_cells = _extract_semantic_header_cells(structure.header_cells)
    if any(
        _classify_header_filter_class(title, cell) is not None
        for _, cell, title in semantic_header_cells
    ):
        return True
    if structure.expanded_rows:
        return True
    if _has_selection_column(structure.header_cells):
        return True
    if _has_expander_column(structure.header_cells):
        return True
    return False


def _collect_descendants(node: PageElementNode) -> list[PageElementNode]:
    descendants: list[PageElementNode] = []
    for child in get_element_children(node):
        descendants.append(child)
        descendants.extend(_collect_descendants(child))
    return descendants


def _enum_member_name(title: str) -> str:
    normalized = to_snake_case(title).upper()
    if not normalized:
        return "COLUMN"
    if normalized[0].isdigit():
        return f"COL_{normalized}"
    return normalized
