from __future__ import annotations

import ast
import importlib
import inspect
from pathlib import Path
import re

import black
import libcst as cst

from persona_dsl.utils.naming import to_snake_case

from .table_dsl_codegen import try_render_table_dsl_page
from .declarative_codegen import DeclarativeCodeGenerator
from .structure import StructureParser
from .codegen import CodeGenerator
from .contracts import (
    ComponentOverrides,
    ExistingElementDefinitions,
    ExistingEnums,
    ExistingLocalValues,
    ObjectMap,
    PageElementNode,
    SnapshotNodeList,
    add_unique_strings,
    as_str_list,
    element_children_as_snapshot,
    get_bool,
    get_element_children,
    get_snapshot_children,
    get_str,
    require_object_map,
)
from .enum_extractor import extract_enums_from_code
from .enum_storage import EnumStorage
from .utils import derive_base_name

ARCHIVED_ELEMENTS_START = "# persona-generator: archived-elements:start"
ARCHIVED_ELEMENTS_END = "# persona-generator: archived-elements:end"
UNRESOLVED_ELEMENTS_START = "# persona-generator: unresolved-elements:start"
UNRESOLVED_ELEMENTS_END = "# persona-generator: unresolved-elements:end"
FOOTER_NONE_LINE = "# none"
FOOTER_PATH_PREFIX = "# path: "
_RELATIVE_ELIGIBLE_REASONS = frozenset(
    {
        "icon_only_without_runtime_name",
        "select_has_only_current_value",
        "disabled_input_without_stable_name",
    }
)


class PageGenerator:
    """
    Генератор страниц 2.0 (Refactored).
    Orchestrates parsing (Structure) and rendering (Codegen).
    """

    def __init__(
        self,
        debug_mode: bool = False,
        test_id_prefix: str | None = None,
        leaf_overrides: dict[str, list[str]] | None = None,
    ) -> None:
        self.debug_mode = debug_mode
        self._test_id_prefix = test_id_prefix
        self.leaf_overrides = leaf_overrides or {}

        # State
        self._pending_updates: dict[str, str] = {}
        self._last_unresolved_diagnostics: list[dict[str, object]] = []

        # Sub-components
        self.structure_parser = StructureParser(test_id_prefix)
        self.code_generator = CodeGenerator(debug_mode)
        self.declarative_code_generator = DeclarativeCodeGenerator(debug_mode)

    def get_pending_updates(self) -> dict[str, str]:
        """Returns map of file_path -> new_code for referenced components."""
        return self._pending_updates

    def get_unresolved_diagnostics(self) -> list[dict[str, object]]:
        return list(self._last_unresolved_diagnostics)

    def apply_pending_updates(self) -> None:
        """Writes all pending component updates to disk."""
        for file_path, code in self._pending_updates.items():
            Path(file_path).write_text(code, encoding="utf-8")
            if self.debug_mode:
                print(f"Deep updated component: {file_path}")
        self._pending_updates.clear()

    def generate_from_aria_snapshot(
        self,
        snapshot: SnapshotNodeList | ObjectMap,
        class_name: str = "GeneratedPage",
        page_path: str | None = None,
        aria_snapshot_path: str | None = None,
        screenshot_path: str | None = None,
        leaf_overrides: dict[str, list[str]] | None = None,
        component_overrides: ComponentOverrides | None = None,
        existing_element_defs: ExistingElementDefinitions | None = None,
        base_class: str = "Page",
        extra_init_stmts: list[ast.stmt] | None = None,
        existing_enums: ExistingEnums | None = None,
        existing_local_vars: ExistingLocalValues | None = None,
        archived_paths: set[str] | None = None,
    ) -> str:
        """Оркестрация процесса генерации."""
        page_object_prefix = self._page_object_prefix(class_name)

        # 1. Parsing & Structure
        used_names: set[str] = set()
        elements_tree = self.structure_parser.parse_aria_node_recursive(
            snapshot, used_names, {}
        )
        self.structure_parser.apply_label_relationships(elements_tree)
        elements_tree = self.structure_parser.identify_repeated_control_groups(
            elements_tree
        )

        # 2. Structural Simplification (Flattening)
        # Collect consumed refs
        consumed_refs = self.structure_parser.collect_consumed_refs(elements_tree)
        elements_tree = self.structure_parser.flatten_tree_recursive(
            elements_tree, consumed_refs
        )
        elements_tree = self.structure_parser.collapse_redundant_headings_before_tables(
            elements_tree
        )

        # 3. Name Recalculation (LCL-Fix)
        self.structure_parser.recalculate_names(elements_tree)

        # 3.5 Reconcile with existing names (Smart Preservation)
        if existing_element_defs:
            self._reconcile_names(elements_tree, existing_element_defs)

        # 3.6 Normalize Text -> Variants (Global Enforcement)
        # Ensures all 'text' args are converted to 'variants', even if not reconciled.
        self._normalize_variants_recursive(elements_tree)

        # 4. Semantic Promotion
        # Need current names
        # Logic in structure parser handles recursions?
        # Promote sem wrappers needs 'used_names' to generate new unique ones.
        self.structure_parser.promote_semantic_wrappers(elements_tree, used_names)

        # 5. Apply Shared Components (Deep Update Logic)
        self._apply_components(elements_tree, component_overrides)

        # 5.5 Apply explicit archived paths from existing footer block.
        if archived_paths:
            elements_tree = self._filter_archived_elements(
                elements_tree,
                prefix=page_object_prefix,
                archived_paths=archived_paths,
            )

        # 6. Identify Complex Sections
        self.structure_parser.identify_complex_sections(elements_tree)
        self.structure_parser.identify_dropdown_options(elements_tree)

        table_dsl_result = try_render_table_dsl_page(elements_tree, class_name)
        if table_dsl_result is not None:
            self._last_unresolved_diagnostics = table_dsl_result.unresolved_diagnostics
            return self._finalize_generated_module(
                code=table_dsl_result.code,
                archived_paths=archived_paths or set(),
                unresolved_diagnostics=self._last_unresolved_diagnostics,
            )

        self._apply_relative_bindings_from_snapshot(elements_tree, snapshot)
        self._last_unresolved_diagnostics = self._collect_unresolved_diagnostics(
            elements_tree,
            prefix=page_object_prefix,
        )

        # 6.5 Identify Table Prototypes (Smart Tables)
        self.structure_parser.identify_table_prototypes(elements_tree)

        # [NEW] 6.6 Explicit Enum Generation
        # Replaces old identify_dropdown_options / identify_text_enums
        enum_storage = EnumStorage()
        self._identify_explicit_enums_recursive(elements_tree, enum_storage)

        # 7. Codegen
        generated_code = self.declarative_code_generator.generate_code(
            elements_tree=elements_tree,
            class_name=class_name,
            page_path=page_path,
            aria_snapshot_path=aria_snapshot_path,
            screenshot_path=screenshot_path,
            base_class=base_class,
            existing_enums=existing_enums,
            enum_storage=enum_storage,
        )
        return self._finalize_generated_module(
            code=generated_code,
            archived_paths=archived_paths or set(),
            unresolved_diagnostics=self._last_unresolved_diagnostics,
        )

    def _collect_unresolved_diagnostics(
        self,
        elements_tree: list[PageElementNode],
        *,
        prefix: str,
    ) -> list[dict[str, object]]:
        diagnostics: list[dict[str, object]] = []

        def walk(nodes: list[PageElementNode], path_prefix: str) -> None:
            for node in nodes:
                field_name = get_str(node, "var_name")
                if field_name is None:
                    raise ValueError(
                        "Generator unresolved diagnostics: отсутствует var_name."
                    )
                full_path = f"{path_prefix}.{field_name}"
                init_kwargs = require_object_map(
                    node,
                    "init_kwargs",
                    context=f"generator unresolved '{full_path}'",
                )
                reason = get_str(init_kwargs, "diagnostic_reason")
                if reason:
                    variants = init_kwargs.get("variants")
                    ui_label = get_str(init_kwargs, "accessible_name") or get_str(
                        init_kwargs, "text"
                    )
                    if not ui_label:
                        if isinstance(variants, list) and variants:
                            first_variant = variants[0]
                            if isinstance(first_variant, str):
                                ui_label = first_variant
                        elif isinstance(variants, str):
                            ui_label = variants
                    if not ui_label:
                        ui_label = get_str(init_kwargs, "label") or field_name
                    diagnostics.append(
                        {
                            "path": full_path,
                            "element_type": get_str(node, "role") or "Element",
                            "field_name": field_name,
                            "element_name": get_str(init_kwargs, "name") or field_name,
                            "ui_label": ui_label,
                            "available_hints": {
                                key: value
                                for key, value in init_kwargs.items()
                                if key
                                in {
                                    "accessible_name",
                                    "label",
                                    "placeholder",
                                    "text",
                                    "title",
                                    "test_id",
                                    "url",
                                    "html_name",
                                    "locator",
                                    "alt_text",
                                    "aria_ref",
                                    "variants",
                                }
                                and value not in (None, "")
                            },
                            "reason": reason,
                        }
                    )
                children = get_element_children(node)
                if children:
                    walk(children, full_path)

        walk(elements_tree, prefix)
        return diagnostics

    def _apply_relative_bindings_from_snapshot(
        self,
        elements_tree: list[PageElementNode],
        snapshot: SnapshotNodeList | ObjectMap,
    ) -> None:
        relation_index = self._build_snapshot_relation_index(snapshot)
        self._apply_relative_bindings_recursive(
            elements_tree,
            relation_index=relation_index,
            owner_ref=None,
        )

    def _apply_relative_bindings_recursive(
        self,
        elements: list[PageElementNode],
        *,
        relation_index: ObjectMap,
        owner_ref: str | None,
    ) -> None:
        for element_index, element in enumerate(elements):
            self._try_apply_relative_binding(
                target=element,
                previous_siblings=elements[:element_index],
                relation_index=relation_index,
                owner_ref=owner_ref,
            )

            next_owner_ref = self._resolve_relative_owner_ref(
                element,
                fallback_owner_ref=owner_ref,
            )
            children = get_element_children(element)
            if children:
                self._apply_relative_bindings_recursive(
                    children,
                    relation_index=relation_index,
                    owner_ref=next_owner_ref,
                )

    def _try_apply_relative_binding(
        self,
        *,
        target: PageElementNode,
        previous_siblings: list[PageElementNode],
        relation_index: ObjectMap,
        owner_ref: str | None,
    ) -> None:
        init_kwargs = require_object_map(
            target,
            "init_kwargs",
            context="generator relative target init kwargs",
        )
        unresolved_reason = get_str(init_kwargs, "diagnostic_reason")
        if unresolved_reason not in _RELATIVE_ELIGIBLE_REASONS:
            return

        target_role = get_str(target, "role")
        if not target_role:
            return

        target_ref = self._node_runtime_ref(target)
        if target_ref is None:
            return

        for anchor in reversed(previous_siblings):
            anchor_expr = get_str(anchor, "var_name")
            if not anchor_expr:
                continue

            anchor_ref = self._node_runtime_ref(anchor)
            if anchor_ref is None:
                continue

            relative_index = self._find_relative_index_for_pair(
                relation_index=relation_index,
                anchor_ref=anchor_ref,
                target_ref=target_ref,
                target_role=target_role,
                owner_ref=owner_ref,
            )
            if relative_index is None:
                continue

            target["relative_anchor_expr"] = anchor_expr
            if relative_index:
                target["relative_index"] = relative_index
            else:
                target.pop("relative_index", None)
            init_kwargs.pop("diagnostic_reason", None)
            target.pop("unresolved_reason", None)
            return

    def _resolve_relative_owner_ref(
        self,
        element: PageElementNode,
        *,
        fallback_owner_ref: str | None,
    ) -> str | None:
        element_ref = self._node_runtime_ref(element)
        if element_ref:
            return element_ref
        return fallback_owner_ref

    def _node_runtime_ref(self, element: PageElementNode) -> str | None:
        element_ref = get_str(element, "aria_ref")
        if element_ref:
            return element_ref

        init_kwargs = require_object_map(
            element,
            "init_kwargs",
            context="generator node runtime ref",
        )
        init_ref = get_str(init_kwargs, "aria_ref")
        if init_ref:
            return init_ref

        node_ref = require_object_map(
            element,
            "node_ref",
            context="generator node raw snapshot ref",
        )
        return get_str(node_ref, "ref") or get_str(node_ref, "aria_ref")

    def _build_snapshot_relation_index(
        self,
        snapshot: SnapshotNodeList | ObjectMap,
    ) -> ObjectMap:
        node_by_ref: dict[str, ObjectMap] = {}
        parent_by_ref: dict[str, str | None] = {}
        children_by_ref: dict[str | None, list[str]] = {}

        def append_child(parent_ref: str | None, child_ref: str) -> None:
            if parent_ref not in children_by_ref:
                children_by_ref[parent_ref] = []
            children_by_ref[parent_ref].append(child_ref)

        def walk(node: ObjectMap, nearest_parent_ref: str | None) -> None:
            node_ref = get_str(node, "ref") or get_str(node, "aria_ref")
            next_parent_ref = nearest_parent_ref
            if node_ref is not None:
                if node_ref not in node_by_ref:
                    node_by_ref[node_ref] = node
                    parent_by_ref[node_ref] = nearest_parent_ref
                    append_child(nearest_parent_ref, node_ref)
                next_parent_ref = node_ref

            for child in get_snapshot_children(node):
                if isinstance(child, dict):
                    walk(child, next_parent_ref)

        raw_nodes = [snapshot] if isinstance(snapshot, dict) else snapshot
        for raw_node in raw_nodes:
            if isinstance(raw_node, dict):
                walk(raw_node, None)

        return {
            "node_by_ref": node_by_ref,
            "parent_by_ref": parent_by_ref,
            "children_by_ref": children_by_ref,
        }

    def _relative_candidate_refs_for_scope(
        self,
        *,
        relation_index: ObjectMap,
        scope_ref: str,
        target_role: str,
        anchor_ref: str,
    ) -> list[str]:
        node_by_ref = relation_index["node_by_ref"]
        children_by_ref = relation_index["children_by_ref"]
        if not isinstance(node_by_ref, dict) or not isinstance(children_by_ref, dict):
            raise TypeError("Generator relative index повреждён: ожидались словари.")

        result: list[str] = []

        def collect(parent_ref: str) -> None:
            child_refs = children_by_ref.get(parent_ref, [])
            if not isinstance(child_refs, list):
                raise TypeError(
                    f"Generator relative index повреждён: children[{parent_ref!r}] должен быть list."
                )
            for child_ref in child_refs:
                if not isinstance(child_ref, str):
                    raise TypeError(
                        f"Generator relative index повреждён: children[{parent_ref!r}] содержит не-строку."
                    )
                child_node = node_by_ref.get(child_ref)
                if not isinstance(child_node, dict):
                    raise TypeError(
                        f"Generator relative index повреждён: отсутствует snapshot node для ref '{child_ref}'."
                    )
                if get_bool(child_node, "hidden") is True:
                    continue
                if (
                    child_ref != anchor_ref
                    and get_str(child_node, "role") == target_role
                ):
                    result.append(child_ref)
                collect(child_ref)

        collect(scope_ref)
        return result

    def _find_relative_index_for_pair(
        self,
        *,
        relation_index: ObjectMap,
        anchor_ref: str,
        target_ref: str,
        target_role: str,
        owner_ref: str | None,
    ) -> int | None:
        parent_by_ref = relation_index["parent_by_ref"]
        if not isinstance(parent_by_ref, dict):
            raise TypeError(
                "Generator relative index повреждён: отсутствует parent_by_ref."
            )

        scope_refs: list[str] = []
        current_ref = parent_by_ref.get(anchor_ref)
        while isinstance(current_ref, str) and current_ref:
            scope_refs.append(current_ref)
            if owner_ref and current_ref == owner_ref:
                break
            current_ref = parent_by_ref.get(current_ref)

        if owner_ref and owner_ref not in scope_refs:
            scope_refs.append(owner_ref)

        candidate_sets = [
            self._relative_candidate_refs_for_scope(
                relation_index=relation_index,
                scope_ref=scope_ref,
                target_role=target_role,
                anchor_ref=anchor_ref,
            )
            for scope_ref in scope_refs
        ]

        for scope_index, candidate_refs in enumerate(candidate_sets):
            for candidate_index, candidate_ref in enumerate(candidate_refs):
                if candidate_ref != target_ref:
                    continue
                if all(
                    len(previous_candidates) <= candidate_index
                    for previous_candidates in candidate_sets[:scope_index]
                ):
                    return candidate_index
        return None

    def _identify_explicit_enums_recursive(
        self, elements: list[PageElementNode], storage: EnumStorage
    ) -> None:
        """Traverses tree and registers variants with EnumStorage."""
        for el in elements:
            variants_list: list[str] = []

            # 1. Existing variants (e.g. from text normalization)
            variants = el.get("variants")
            if isinstance(variants, str):
                variants_list = [variants]
            else:
                variants_list = as_str_list(variants)

            if not variants_list and el.get("has_options_enum"):
                variants_list = as_str_list(el.get("options_values"))

            # 2. Extract from Children (ListBox, Select, RadioGroup)
            role = get_str(el, "role")
            if role in ("listbox", "combobox", "radiogroup"):
                # Collect options from children
                child_options: list[str] = []
                for child in get_element_children(el):
                    child_role = get_str(child, "role")
                    if child_role in ("option", "radio"):
                        # Use accessible name or text or variants
                        # Note: parser puts accessible_name in 'name' or 'accessible_name'
                        # But often text content is in 'variants' if it was a Text element...
                        # Wait, Option elements usually have 'name' or 'accessible_name'.
                        opt_text = get_str(child, "accessible_name") or get_str(
                            child, "name"
                        )

                        # Fallback to variants if it's a Text-like option
                        if not opt_text:
                            child_variants = as_str_list(child.get("variants"))
                            if child_variants:
                                opt_text = child_variants[0]

                        if opt_text:
                            child_options.append(opt_text)

                if child_options:
                    variants_list = child_options
                    el["options_values"] = child_options
                    el["has_options_enum"] = True

            # 3. Register with Storage if we have variants
            if variants_list:
                # Use name as hint
                hint = get_str(el, "name") or "Variant"

                # Check if it already exists to increment usage
                # EnumStorage.get_enum_name handles registration, but we need to know if it was *already* there
                # Actually, calling get_enum_name again returns the same name.
                # But we need to increment usage count for existing ones.
                # Does get_enum_name check existence? Yes.
                # We can just call get_enum_name, but that initializes it with count=1.
                # If we call it again, we want count+1.
                # Let's peek existence first or modify get_enum_name to return (name, is_new)?
                # Or just rely on get_enum_name always returning valid name, and then call increment?
                # But we don't know if it was new or not from the return value.

                # Let's update usage logic:
                # We can call get_enum_name. If it returns X, we immediately increment usage?
                # No, get_enum_name sets count to 1 on creation.
                # If we call it a second time, we should increment.

                # Alternative: Explicitly check existence in storage?
                # storage._variant_map key is needed.
                # Let's just use the public check if possible.

                # Simpler: Always call get_enum_name.
                # Then we need to know if we should increment.
                # Let's change get_enum_name to handle incrementing internally?
                # But get_enum_name is "get or create".
                # If it's a "get", it should increment?
                # If it's a "create", it inits to 1.

                # Let's modify EnumStorage.get_enum_name to increment if found.
                # But wait, looking at my previous edit to EnumStorage:
                # I added `self._usage_counts[unique_name] = 1` in the creation block.
                # I did NOT add increment logic in the "Check if exists" block (lines 46-47).
                # So I should update EnumStorage to increment there too!

                enum_name = storage.get_enum_name(base_name=hint, options=variants_list)
                el["explicit_enum_name"] = enum_name

            # Recurse
            children = get_element_children(el)
            if children:
                self._identify_explicit_enums_recursive(children, storage)

    def generate_or_update_from_aria_snapshot(
        self,
        snapshot: SnapshotNodeList | ObjectMap,
        class_name: str = "GeneratedPage",
        page_path: str | None = None,
        aria_snapshot_path: str | None = None,
        screenshot_path: str | None = None,
        existing_code: str | None = None,
    ) -> str:

        # 1. Parse existing code to find overrides/components
        existing_tree: ast.Module | None = None
        existing_class_node: ast.ClassDef | None = None
        base_class = "Page"
        replace_generated_module = False

        if existing_code:
            archived_paths = self._extract_archived_paths(existing_code)
            try:
                existing_tree = ast.parse(existing_code)
            except SyntaxError as exc:
                raise ValueError(
                    f"Не удалось разобрать существующий код страницы '{class_name}': {exc.msg} "
                    f"(строка {exc.lineno}, столбец {exc.offset})"
                ) from exc

            existing_class_node = next(
                (
                    n
                    for n in existing_tree.body
                    if isinstance(n, ast.ClassDef) and n.name == class_name
                ),
                None,
            )
            replace_generated_module = self._is_pure_generated_module(existing_tree)

            if existing_class_node and existing_class_node.bases:
                base_node = existing_class_node.bases[0]
                if isinstance(base_node, ast.Name):
                    base_class = base_node.id
                elif isinstance(base_node, ast.Attribute):
                    base_class = base_node.attr

        else:
            archived_paths = set()

        # 2. Extract mappings
        leaf_overrides: dict[str, list[str]] = {}
        existing_element_defs: ExistingElementDefinitions = {}
        extra_init_stmts: list[ast.stmt] = []

        local_vars: ExistingLocalValues = {}

        if existing_class_node:
            leaf_overrides = self.code_generator.extract_field_mappings(
                existing_class_node
            )
            # Extract attributes/statements that are NOT element assignments
            extra_init_stmts = self._extract_extra_init_statements(existing_class_node)

        if existing_tree:
            existing_element_defs, local_vars = self._extract_element_definitions(
                existing_tree
            )
            if self.debug_mode:
                # ... debug prints ...
                pass

        component_overrides = (
            self._extract_component_overrides(existing_tree) if existing_tree else {}
        )

        # Extract Enums
        existing_enums = extract_enums_from_code(existing_code) if existing_code else {}

        # 3. Generate
        new_code = self.generate_from_aria_snapshot(
            snapshot,
            class_name,
            page_path,
            aria_snapshot_path,
            screenshot_path,
            leaf_overrides,
            component_overrides,
            existing_element_defs=existing_element_defs,
            base_class=base_class,
            extra_init_stmts=extra_init_stmts,
            existing_enums=existing_enums,
            existing_local_vars=local_vars,
            archived_paths=archived_paths,
        )

        # 4. Merge using LibCST (Non-destructive)
        if existing_code:
            if replace_generated_module:
                return new_code
            merged_code = self._merge_all_classes_cst(
                existing_code=existing_code,
                new_code=new_code,
            )
            return self._finalize_generated_module(
                code=merged_code,
                archived_paths=archived_paths,
                unresolved_diagnostics=self._last_unresolved_diagnostics,
            )

        return new_code

    def _is_pure_generated_module(self, module: ast.Module) -> bool:
        saw_class = False
        for stmt in module.body:
            if isinstance(stmt, (ast.Import, ast.ImportFrom)):
                continue
            if (
                isinstance(stmt, ast.Expr)
                and isinstance(stmt.value, ast.Constant)
                and isinstance(stmt.value.value, str)
            ):
                continue
            if isinstance(stmt, ast.ClassDef):
                saw_class = True
                if not self._is_pure_generated_class(stmt):
                    return False
                continue
            return False
        return saw_class

    def _is_pure_generated_class(self, class_node: ast.ClassDef) -> bool:
        if not class_node.bases:
            return False
        for stmt in class_node.body:
            if (
                isinstance(stmt, ast.Expr)
                and isinstance(stmt.value, ast.Constant)
                and isinstance(stmt.value.value, str)
            ):
                continue
            if isinstance(stmt, (ast.Assign, ast.AnnAssign, ast.Pass, ast.ClassDef)):
                continue
            if isinstance(stmt, ast.FunctionDef):
                if stmt.name != "__init__":
                    return False
                if not self._is_generated_init_method(stmt):
                    return False
                continue
            return False
        return True

    def _is_generated_init_method(self, method_node: ast.FunctionDef) -> bool:
        for stmt in method_node.body:
            if (
                isinstance(stmt, ast.Expr)
                and isinstance(stmt.value, ast.Constant)
                and isinstance(stmt.value.value, str)
            ):
                continue
            if self._is_super_init_call(stmt):
                continue
            if self._is_generated_add_element_assignment(stmt):
                continue
            return False
        return True

    def _is_super_init_call(self, stmt: ast.stmt) -> bool:
        if not isinstance(stmt, ast.Expr) or not isinstance(stmt.value, ast.Call):
            return False
        call = stmt.value
        func = call.func
        if not isinstance(func, ast.Attribute) or func.attr != "__init__":
            return False
        owner = func.value
        if not isinstance(owner, ast.Call):
            return False
        owner_func = owner.func
        return isinstance(owner_func, ast.Name) and owner_func.id == "super"

    def _is_generated_add_element_assignment(self, stmt: ast.stmt) -> bool:
        if not isinstance(stmt, ast.Assign) or len(stmt.targets) != 1:
            return False
        target = stmt.targets[0]
        if not (
            isinstance(target, ast.Attribute)
            and isinstance(target.value, ast.Name)
            and target.value.id == "self"
        ):
            return False
        value = stmt.value
        if not isinstance(value, ast.Call):
            return False
        func = value.func
        if not (
            isinstance(func, ast.Attribute)
            and isinstance(func.value, ast.Name)
            and func.value.id == "self"
            and func.attr in {"add_element", "add_element_list"}
        ):
            return False
        if not value.args:
            return False
        return isinstance(value.args[0], ast.Call)

    def generate_from_tree(
        self,
        elements_tree: list[PageElementNode],
        class_name: str,
        base_class: str = "Page",
        page_path: str | None = None,
        existing_code: str | None = None,
        class_attributes: dict[str, str] | None = None,
    ) -> str:
        """
        Generates code from a standard Generator Tree (nested init_kwargs).
        Requires caller to prepare the structure correctly.
        """
        if existing_code:
            archived_paths = self._extract_archived_paths(existing_code)
            try:
                tree = ast.parse(existing_code)
            except SyntaxError as exc:
                raise ValueError(
                    f"Не удалось разобрать существующий код страницы '{class_name}': {exc.msg} "
                    f"(строка {exc.lineno}, столбец {exc.offset})"
                ) from exc
            cls_node = next(
                (
                    n
                    for n in tree.body
                    if isinstance(n, ast.ClassDef) and n.name == class_name
                ),
                None,
            )
            if cls_node is not None:
                self._extract_extra_init_statements(cls_node)
            self._extract_component_overrides(tree)
        else:
            archived_paths = set()

        # 1. Generate New Code
        new_code = self.declarative_code_generator.generate_code(
            elements_tree=elements_tree,
            class_name=class_name,
            base_class=base_class,
            page_path=page_path,
        )

        # 2. Merge (to preserve methods)
        final_code = new_code
        if existing_code:
            final_code = self._merge_all_classes_cst(existing_code, new_code)

        # 3. Apply Class Attributes (Post-Process)
        if class_attributes:
            from persona_dsl.editors.base import CodeEditor

            editor = CodeEditor(final_code)
            editor.update_class_attributes(class_name, class_attributes)
            final_code = editor.get_code(use_black=True)

        return self._finalize_generated_module(
            code=final_code,
            archived_paths=archived_paths,
            unresolved_diagnostics=[],
        )

    def _page_object_prefix(self, class_name: str) -> str:
        return to_snake_case(class_name)

    def _extract_archived_paths(self, code: str) -> set[str]:
        _, archived_paths = self._strip_generator_footer_sections(code)
        return archived_paths

    def _strip_generator_footer_sections(self, code: str) -> tuple[str, set[str]]:
        lines = code.splitlines()
        kept_lines: list[str] = []
        archived_paths: list[str] = []
        seen_archived_paths: set[str] = set()
        section: str | None = None
        saw_archived_none = False

        for line_number, line in enumerate(lines, start=1):
            stripped = line.strip()

            if stripped == ARCHIVED_ELEMENTS_START:
                if section is not None:
                    raise ValueError(
                        f"Некорректный footer generated page object: вложенная секция на строке {line_number}."
                    )
                section = "archived"
                continue

            if stripped == ARCHIVED_ELEMENTS_END:
                if section != "archived":
                    raise ValueError(
                        f"Некорректный footer generated page object: закрытие archived-секции без открытия на строке {line_number}."
                    )
                section = None
                continue

            if stripped == UNRESOLVED_ELEMENTS_START:
                if section is not None:
                    raise ValueError(
                        f"Некорректный footer generated page object: вложенная секция на строке {line_number}."
                    )
                section = "unresolved"
                continue

            if stripped == UNRESOLVED_ELEMENTS_END:
                if section != "unresolved":
                    raise ValueError(
                        f"Некорректный footer generated page object: закрытие unresolved-секции без открытия на строке {line_number}."
                    )
                section = None
                continue

            if section == "archived":
                if not stripped:
                    continue
                if stripped == FOOTER_NONE_LINE:
                    if archived_paths:
                        raise ValueError(
                            f"Некорректный archived footer: '# none' нельзя сочетать с path-строками (строка {line_number})."
                        )
                    saw_archived_none = True
                    continue
                if not stripped.startswith(FOOTER_PATH_PREFIX):
                    raise ValueError(
                        f"Некорректный archived footer: ожидалась строка '{FOOTER_PATH_PREFIX}<path>' на строке {line_number}."
                    )
                if saw_archived_none:
                    raise ValueError(
                        f"Некорректный archived footer: '# none' нельзя сочетать с path-строками (строка {line_number})."
                    )
                path = stripped.removeprefix(FOOTER_PATH_PREFIX).strip()
                if not path:
                    raise ValueError(
                        f"Некорректный archived footer: пустой path на строке {line_number}."
                    )
                if path in seen_archived_paths:
                    raise ValueError(
                        f"Некорректный archived footer: дублирующий path '{path}' на строке {line_number}."
                    )
                archived_paths.append(path)
                seen_archived_paths.add(path)
                continue

            if section == "unresolved":
                continue

            kept_lines.append(line)

        if section == "archived":
            raise ValueError(
                "Некорректный footer generated page object: archived-секция не закрыта."
            )
        if section == "unresolved":
            raise ValueError(
                "Некорректный footer generated page object: unresolved-секция не закрыта."
            )

        stripped_code = "\n".join(kept_lines).rstrip()
        return stripped_code, set(archived_paths)

    def _finalize_generated_module(
        self,
        *,
        code: str,
        archived_paths: set[str],
        unresolved_diagnostics: list[dict[str, object]],
    ) -> str:
        clean_code, existing_archived_paths = self._strip_generator_footer_sections(
            code
        )
        effective_archived_paths = list(
            sorted(existing_archived_paths | archived_paths)
        )
        footer_lines: list[str] = [
            ARCHIVED_ELEMENTS_START,
            *(
                [f"{FOOTER_PATH_PREFIX}{path}" for path in effective_archived_paths]
                if effective_archived_paths
                else [FOOTER_NONE_LINE]
            ),
            ARCHIVED_ELEMENTS_END,
            "",
            UNRESOLVED_ELEMENTS_START,
        ]
        if unresolved_diagnostics:
            for diagnostic in unresolved_diagnostics:
                hints = diagnostic.get("available_hints")
                if not isinstance(hints, dict):
                    raise ValueError(
                        "Generator unresolved footer: available_hints должен быть словарём."
                    )
                formatted_hints = ", ".join(
                    f"{key}={value!r}" for key, value in sorted(hints.items())
                )
                footer_lines.append(
                    "# path: "
                    f"{diagnostic['path']} | "
                    f"reason: {diagnostic['reason']} | "
                    f"type: {diagnostic['element_type']} | "
                    f"field_name: {diagnostic['field_name']} | "
                    f"element_name: {diagnostic['element_name']} | "
                    f"ui_label: {diagnostic['ui_label']} | "
                    f"hints: {formatted_hints or '-'}"
                )
        else:
            footer_lines.append(FOOTER_NONE_LINE)
        footer_lines.append(UNRESOLVED_ELEMENTS_END)

        if not clean_code:
            return "\n".join(footer_lines) + "\n"
        return clean_code.rstrip() + "\n\n" + "\n".join(footer_lines) + "\n"

    def _filter_archived_elements(
        self,
        elements_tree: list[PageElementNode],
        *,
        prefix: str,
        archived_paths: set[str],
    ) -> list[PageElementNode]:
        filtered_nodes: list[PageElementNode] = []

        for node in elements_tree:
            field_name = get_str(node, "var_name")
            if field_name is None:
                raise ValueError(
                    "Generator archived filtering: отсутствует var_name у элемента."
                )
            full_path = f"{prefix}.{field_name}"
            if full_path in archived_paths:
                continue

            children = get_element_children(node)
            if children:
                node["children"] = self._filter_archived_elements(
                    children,
                    prefix=full_path,
                    archived_paths=archived_paths,
                )
            filtered_nodes.append(node)

        return filtered_nodes

    def _extract_component_overrides(
        self, tree: ast.Module | None
    ) -> ComponentOverrides:
        """
        Parses the AST of the EXISTING page file to find which fields are using custom component classes.
        Returns: { 'var_name': ('ClassName', 'module.path') }
        """
        overrides: ComponentOverrides = {}
        if tree is None:
            return overrides

        # 1. Collect Imports: ClassName -> ModulePath
        imports_map: ComponentOverrides = {}
        for node in tree.body:
            if isinstance(node, ast.ImportFrom):
                module = node.module
                for name in node.names:
                    # name.name is the class name, name.asname is alias
                    cls_name = name.name
                    alias = name.asname or cls_name
                    if module:
                        imports_map[alias] = (cls_name, module)

        # 2. Find Page Class
        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                self._scan_class_for_components(node, imports_map, overrides)

        return overrides

    def _extract_extra_init_statements(
        self, class_node: ast.ClassDef
    ) -> list[ast.stmt]:
        """
        Extracts AST statements from __init__ that are NOT part of element definitions.
        e.g. self.path = "/", self.snapshot_path = "..."
        """
        init_method = next(
            (
                n
                for n in class_node.body
                if isinstance(n, ast.FunctionDef) and n.name == "__init__"
            ),
            None,
        )
        if not init_method:
            return []

        extras: list[ast.stmt] = []
        for stmt in init_method.body:
            # Skip super().__init__()
            if (
                isinstance(stmt, ast.Expr)
                and isinstance(stmt.value, ast.Call)
                and isinstance(stmt.value.func, ast.Attribute)  # super().item
                # simplified check for super check
            ):
                # Verify it is super().__init__
                # Usually: Expr(value=Call(func=Attribute(value=Call(func=Name(id='super')), attr='__init__')))
                # Let's assume the first call is super().__init__ and skip it if matched?
                # Or just skip it explicitly.
                # Check for super()
                is_super = False
                if (
                    isinstance(stmt.value.func, ast.Attribute)
                    and stmt.value.func.attr == "__init__"
                ):
                    if (
                        isinstance(stmt.value.func.value, ast.Call)
                        and isinstance(stmt.value.func.value.func, ast.Name)
                        and stmt.value.func.value.func.id == "super"
                    ):
                        is_super = True
                if is_super:
                    continue

            # Skip Element Assignments
            # self.var = self.add_element(...)
            is_element_add = False
            if isinstance(stmt, ast.Assign) and len(stmt.targets) == 1:
                if (
                    isinstance(stmt.value, ast.Call)
                    and isinstance(stmt.value.func, ast.Attribute)
                    and (stmt.value.func.attr in ("add_element", "add_element_list"))
                ):
                    is_element_add = True

            if not is_element_add:
                extras.append(stmt)

        return extras

    def _scan_class_for_components(
        self,
        class_node: ast.ClassDef,
        imports_map: ComponentOverrides,
        overrides: ComponentOverrides,
    ) -> None:
        init_method = next(
            (
                n
                for n in class_node.body
                if isinstance(n, ast.FunctionDef) and n.name == "__init__"
            ),
            None,
        )
        if not init_method:
            init_statements: list[ast.stmt] = []
        else:
            init_statements = init_method.body

        for stmt in init_statements:
            # Look for: self.var_name = self.add_element(ClassName(...))
            if isinstance(stmt, ast.Assign) and len(stmt.targets) == 1:
                target = stmt.targets[0]
                if (
                    isinstance(target, ast.Attribute)
                    and isinstance(target.value, ast.Name)
                    and target.value.id == "self"
                ):
                    var_name = target.attr

                    if (
                        isinstance(stmt.value, ast.Call)
                        and isinstance(stmt.value.func, ast.Attribute)
                        and stmt.value.func.attr == "add_element"
                    ):
                        if stmt.value.args and isinstance(stmt.value.args[0], ast.Call):
                            element_call = stmt.value.args[0]
                            if isinstance(element_call.func, ast.Name):
                                cls_name = element_call.func.id
                                # Check if this class is imported from components
                                if cls_name in imports_map:
                                    original_cls_name, module_path = imports_map[
                                        cls_name
                                    ]
                                    # Filter out standard persona imports
                                    # Also allow if explicitly from 'components'
                                    if (
                                        "components" in module_path
                                        or not module_path.startswith(
                                            "persona_dsl.pages"
                                        )
                                    ):
                                        overrides[var_name] = (
                                            original_cls_name,
                                            module_path,
                                        )

        for stmt in class_node.body:
            if isinstance(stmt, ast.Assign) and len(stmt.targets) == 1:
                target = stmt.targets[0]
                if not isinstance(target, ast.Name):
                    continue
                if not isinstance(stmt.value, ast.Call):
                    continue
                callable_name = self._extract_callable_name(stmt.value.func)
                if callable_name is None:
                    continue
                if callable_name not in imports_map:
                    continue
                original_cls_name, module_path = imports_map[callable_name]
                if "components" in module_path or not module_path.startswith(
                    "persona_dsl.pages"
                ):
                    overrides[target.id] = (
                        original_cls_name,
                        module_path,
                    )

    def _extract_element_definitions(
        self, tree: ast.Module
    ) -> tuple[ExistingElementDefinitions, ExistingLocalValues]:
        """
        Parses the existing module to find element definitions in ALL classes.
        Returns:
            definitions: Map of var_name -> kwargs
            local_vars: Map of local constant name -> value (e.g. {'PENDING': 'Pending'})
        """
        definitions: ExistingElementDefinitions = {}
        local_vars: ExistingLocalValues = {}

        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                vars_found = self._scan_class_for_definitions(node, definitions)
                if vars_found:
                    local_vars.update(vars_found)

        return definitions, local_vars

    def _scan_class_for_definitions(
        self,
        class_node: ast.ClassDef,
        definitions: ExistingElementDefinitions,
    ) -> ExistingLocalValues:
        init_method = next(
            (
                n
                for n in class_node.body
                if isinstance(n, ast.FunctionDef) and n.name == "__init__"
            ),
            None,
        )
        if not init_method:
            init_statements: list[ast.stmt] = []
        else:
            init_statements = init_method.body

        local_vars: ExistingLocalValues = {}

        for stmt in init_statements:
            # Match: var = "Value" (Local constant)
            if isinstance(stmt, ast.Assign) and len(stmt.targets) == 1:
                target = stmt.targets[0]
                if isinstance(target, ast.Name) and isinstance(
                    stmt.value, ast.Constant
                ):
                    # Store local constant: PENDING = "Pending"
                    local_vars[target.id] = stmt.value.value

            # Match: self.var_name = ... add_element(Class(kw=val...))
            if isinstance(stmt, ast.Assign) and len(stmt.targets) == 1:
                target = stmt.targets[0]
                var_name = None
                if isinstance(target, ast.Attribute):
                    var_name = target.attr

                if (
                    var_name
                    and isinstance(stmt.value, ast.Call)
                    and isinstance(stmt.value.func, ast.Attribute)
                    and stmt.value.func.attr == "add_element"
                    and stmt.value.args
                    and isinstance(stmt.value.args[0], ast.Call)
                ):
                    definitions[var_name] = self._extract_element_call_props(
                        stmt.value.args[0],
                        local_vars=local_vars,
                        include_role=True,
                    )

        for stmt in class_node.body:
            if not isinstance(stmt, ast.Assign) or len(stmt.targets) != 1:
                continue
            target = stmt.targets[0]
            if isinstance(target, ast.Name) and isinstance(stmt.value, ast.Constant):
                local_vars[target.id] = stmt.value.value

        for stmt in class_node.body:
            if not isinstance(stmt, ast.Assign) or len(stmt.targets) != 1:
                continue
            target = stmt.targets[0]
            if not isinstance(target, ast.Name):
                continue
            if not isinstance(stmt.value, ast.Call):
                continue
            definitions[target.id] = self._extract_element_call_props(
                stmt.value,
                local_vars=local_vars,
                include_role=False,
            )

        return local_vars

    def _extract_callable_name(self, node: ast.expr) -> str | None:
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            return node.attr
        return None

    def _unwrap_element_call(self, el_call: ast.Call) -> ast.Call:
        current_call = el_call
        while (
            isinstance(current_call.func, ast.Attribute)
            and isinstance(current_call.func.value, ast.Call)
            and current_call.func.attr
            in {"relative_to", "configure", "configure_children", "using"}
        ):
            nested_call = current_call.func.value
            if not isinstance(nested_call, ast.Call):
                break
            current_call = nested_call
        return current_call

    def _extract_element_call_props(
        self,
        el_call: ast.Call,
        *,
        local_vars: ExistingLocalValues,
        include_role: bool,
    ) -> ObjectMap:
        props: ObjectMap = {}
        base_call = self._unwrap_element_call(el_call)
        callable_name = self._extract_callable_name(base_call.func)
        if callable_name is not None:
            props["role_class"] = callable_name
        if include_role and callable_name is not None:
            props["role"] = callable_name

        for kw in base_call.keywords:
            if kw.arg is None:
                continue
            arg_name = "variants" if kw.arg == "text" else kw.arg
            if isinstance(kw.value, ast.Constant):
                props[arg_name] = kw.value.value
                continue
            if isinstance(kw.value, ast.Name) and kw.value.id in local_vars:
                props[arg_name] = local_vars[kw.value.id]
                continue
            if isinstance(kw.value, ast.List):
                values: list[object] = []
                for elt in kw.value.elts:
                    if isinstance(elt, ast.Constant):
                        values.append(elt.value)
                    elif isinstance(elt, ast.Name) and elt.id in local_vars:
                        values.append(local_vars[elt.id])
                props[arg_name] = values

        return props

    def _reconcile_names(
        self,
        elements: list[PageElementNode],
        existing_defs: ExistingElementDefinitions,
        consumed_vars: set[str] | None = None,
    ) -> None:
        """
        Matches new elements to existing variable names to preserve user renames.
        """
        if consumed_vars is None:
            consumed_vars = set()

        for el in elements:
            # Try to find a match in existing_defs
            # Priority: test_id > aria_ref > html_name > accessible_name > text

            match_var = None
            init_kwargs = require_object_map(
                el,
                "init_kwargs",
                context=f"generator reconcile '{get_str(el, 'var_name') or '?'}'",
            )
            diagnostic_reason = get_str(init_kwargs, "diagnostic_reason")
            strict_naming_required = diagnostic_reason in {
                "icon_only_without_runtime_name",
                "select_has_only_current_value",
                "disabled_input_without_stable_name",
                "hidden_service_button",
            }
            role = get_str(el, "role")
            current_var_name = get_str(el, "var_name")

            if (
                role in {"table", "grid"}
                and current_var_name is not None
                and current_var_name not in consumed_vars
                and self._existing_definition_semantically_matches_current(
                    init_kwargs=init_kwargs,
                    existing_props=existing_defs.get(current_var_name),
                )
            ):
                match_var = current_var_name

            # 1. By Test ID
            test_id = get_str(el, "test_id")
            if test_id and not strict_naming_required:
                for var, props in existing_defs.items():
                    if props.get("test_id") == test_id and var not in consumed_vars:
                        match_var = var
                        break

            # 1.5 By Aria Ref (Strongest Signal if present)
            target_ref = get_str(init_kwargs, "aria_ref")
            if not match_var and target_ref and not strict_naming_required:
                for var, props in existing_defs.items():
                    if props.get("aria_ref") == target_ref and var not in consumed_vars:
                        match_var = var
                        break

            target_html_name = get_str(init_kwargs, "html_name")
            if not match_var and target_html_name and not strict_naming_required:
                for var, props in existing_defs.items():
                    if (
                        props.get("html_name") == target_html_name
                        and var not in consumed_vars
                    ):
                        match_var = var
                        break

            # 1.75 By Existing Variable Name (Declarative attrs)
            if (
                not match_var
                and not strict_naming_required
                and current_var_name is not None
                and current_var_name in existing_defs
                and current_var_name not in consumed_vars
            ):
                match_var = current_var_name

            # 2. By Name/Text (if no match yet)
            if not match_var and not strict_naming_required:
                candidates = []
                name = get_str(el, "name")
                text = get_str(el, "text")
                if name:
                    candidates.append(name)
                if text:
                    candidates.append(text)

                found = False
                for c in candidates:
                    for var, props in existing_defs.items():
                        if var in consumed_vars:
                            continue

                        # Check accessible_name OR name kwarg
                        target_name = props.get("accessible_name")
                        if not target_name:
                            target_name = props.get("name")  # Fallback to name

                        if target_name and target_name == c:
                            match_var = var
                            found = True
                            break
                    if found:
                        break

            if match_var:
                # APPLY PRESERVATION
                el["var_name"] = match_var
                init_kwargs["name"] = match_var
                consumed_vars.add(match_var)

                # RESTORE PRESERVED TYPE
                existing_props = existing_defs.get(match_var, {})
                original_role_class = existing_props.get(
                    "role"
                )  # This stores Class Name e.g. "Heading"
                if original_role_class:
                    el["forced_class_name"] = original_role_class

                # RESTORE PRESERVED NAME KWARG (if different from var_name)
                # If the user explicitly named the element "Something" but variable is "something",
                # we should keep "Something" in the init_kwargs.
                original_name_arg = existing_props.get("name")
                if (
                    isinstance(original_name_arg, str)
                    and original_name_arg != match_var
                    and self._should_preserve_existing_name_arg(
                        original_name_arg=original_name_arg,
                        match_var=match_var,
                        existing_props=existing_props,
                    )
                ):
                    init_kwargs["name"] = original_name_arg
                else:
                    init_kwargs["name"] = match_var

                # SMART ATTRIBUTE SUPPRESSION (Clean Code)
                # If the existing element already has a strong locator (test_id, locator, text)
                # and did NOT typically use accessible_name, we should suppress accessible_name
                # from the new generation to avoid noise.
                # However, if accessible_name is the ONLY strategy, we must keep it.

                has_strong_locator = (
                    existing_props.get("test_id")
                    or existing_props.get("locator")
                    or existing_props.get("text")
                    or existing_props.get("html_name")
                    or existing_props.get("aria_ref")  # Ref is also strong
                )

                if (
                    "accessible_name" not in existing_props
                    and "accessible_name" in init_kwargs
                    and has_strong_locator
                ):
                    # User prefers other strategies, suppress noise
                    del init_kwargs["accessible_name"]

                # PRESERVE CRITICAL ATTRIBUTES (url, locator, html_name)
                for attr in ["url", "locator", "html_name"]:
                    if attr in existing_props and attr not in init_kwargs:
                        init_kwargs[attr] = existing_props[attr]

                # SMART TEXT ACCUMULATION (New Feature)
                gathered_values: set[str] = set()

                # Old values
                # Old values
                # Note: 'text' key is removed in _extract_element_definitions, so we look at 'variants'
                existing_variants = existing_props.get("variants")
                if isinstance(existing_variants, str):
                    gathered_values.add(existing_variants)
                else:
                    add_unique_strings(gathered_values, as_str_list(existing_variants))

                # New values (from init_kwargs text or variants)
                new_text = get_str(init_kwargs, "text")
                if new_text:
                    gathered_values.add(new_text)
                new_variants = init_kwargs.get("variants")
                if isinstance(new_variants, str):
                    gathered_values.add(new_variants)
                else:
                    add_unique_strings(gathered_values, as_str_list(new_variants))

                # DEBUG
                # print(f"DEBUG: Text Accumulation for '{match_var}': OldText={existing_props.get('text')}, NewText={new_text}, Gathered={gathered_values}")

                # 2. Logic: If multiple distinct values exist, USE VARIANTS
                # FORCE VARIANTS FOR TEXT ELEMENTS (User Request: "variants" param even for single value)
                if gathered_values:
                    # Sort for stability
                    sorted_vars = sorted(list(gathered_values))

                    # If single value, pass as string (if preferred by user) OR list?
                    # User: "Single value: text='Done', Multiple values: text=['Done', 'Pending'] ... why not variants?"
                    # Implies: variants="Done" / variants=["Done", "Pending"]

                    if len(sorted_vars) == 1 and not (
                        "variants" in existing_props
                        and isinstance(existing_props["variants"], list)
                    ):
                        # Single value -> variant="Value"
                        init_kwargs["variants"] = sorted_vars[0]
                    else:
                        # Multiple values -> variants=["A", "B"]
                        init_kwargs["variants"] = sorted_vars

                    # REMOVE 'text' arg completely
                    if "text" in init_kwargs:
                        del init_kwargs["text"]
                    if "text" in el:
                        del el["text"]

            # Recurse
            children = get_element_children(el)
            if children:
                self._reconcile_names(children, existing_defs, consumed_vars)

    def _existing_definition_semantically_matches_current(
        self,
        *,
        init_kwargs: ObjectMap,
        existing_props: ObjectMap | None,
    ) -> bool:
        if existing_props is None:
            return False

        current_candidates = {
            value
            for value in (
                get_str(init_kwargs, "accessible_name"),
                get_str(init_kwargs, "label"),
                get_str(init_kwargs, "name"),
            )
            if value
        }
        if not current_candidates:
            return False

        existing_candidates = {
            value
            for value in (
                get_str(existing_props, "accessible_name"),
                get_str(existing_props, "label"),
                get_str(existing_props, "name"),
            )
            if value
        }
        if not existing_candidates:
            return False

        return not current_candidates.isdisjoint(existing_candidates)

    def _should_preserve_existing_name_arg(
        self,
        *,
        original_name_arg: str,
        match_var: str,
        existing_props: ObjectMap,
    ) -> bool:
        if original_name_arg == match_var:
            return False

        auto_base_name = self._derive_existing_auto_base_name(existing_props)
        if auto_base_name is not None and (
            original_name_arg == auto_base_name
            or re.fullmatch(rf"{re.escape(auto_base_name)}_\d+", original_name_arg)
        ):
            return False

        return True

    def _derive_existing_auto_base_name(
        self,
        existing_props: ObjectMap,
    ) -> str | None:
        role = self._map_existing_role_class_to_snapshot_role(existing_props)
        if role is None:
            return None

        accessible_name = get_str(existing_props, "accessible_name") or ""
        test_id = get_str(existing_props, "test_id")
        placeholder = get_str(existing_props, "placeholder")
        text_value = get_str(existing_props, "text")
        field_name_hint = get_str(existing_props, "field_name_hint")
        return derive_base_name(
            role,
            accessible_name,
            test_id,
            text_value,
            placeholder,
            field_name_hint,
        )

    def _map_existing_role_class_to_snapshot_role(
        self,
        existing_props: ObjectMap,
    ) -> str | None:
        role_class = get_str(existing_props, "role_class") or get_str(
            existing_props, "role"
        )
        if role_class is None:
            return None

        role_map = {
            "Button": "button",
            "TextField": "textbox",
            "SearchField": "searchbox",
            "SpinButton": "spinbutton",
            "Switch": "switch",
            "Select": "combobox",
            "MultiSelect": "combobox",
            "ListBox": "listbox",
            "Radio": "radio",
            "RadioGroup": "radiogroup",
            "Link": "link",
            "Heading": "heading",
            "Text": "text",
            "Generic": "generic",
            "Table": "table",
        }
        mapped = role_map.get(role_class)
        if mapped is not None:
            return mapped

        if role_class.endswith("Table"):
            return "table"
        if role_class.endswith("Row"):
            return "row"
        if role_class.endswith("TextField"):
            return "textbox"
        if role_class.endswith("Select"):
            return "combobox"
        if role_class.endswith("Switch"):
            return "switch"
        if role_class.endswith("Button"):
            return "button"
        if role_class.endswith("SpinButton"):
            return "spinbutton"

        return None

    def _apply_components(
        self,
        elements: list[PageElementNode],
        component_overrides: ComponentOverrides | None = None,
    ) -> None:
        """
        Recursive Deep Update Logic.
        """
        component_overrides = component_overrides or {}

        for el in elements:
            var_name = get_str(el, "var_name")
            if var_name and component_overrides and var_name in component_overrides:
                cls_name, module_path = component_overrides[var_name]

                module = importlib.import_module(module_path)
                try:
                    component_cls = getattr(module, cls_name)
                except AttributeError as exc:
                    raise ValueError(
                        f"Не найден класс компонента '{cls_name}' в модуле '{module_path}'"
                    ) from exc

                el["class"] = component_cls
                el["custom_import_module"] = module_path

                source_file = inspect.getsourcefile(component_cls)
                children = get_element_children(el)
                if children:
                    if source_file is None:
                        raise ValueError(
                            f"Не удалось определить исходный файл компонента '{cls_name}'"
                        )

                    sub_generator = PageGenerator(debug_mode=self.debug_mode)
                    existing_comp_code = Path(source_file).read_text(encoding="utf-8")
                    new_comp_code = sub_generator.generate_or_update_from_aria_snapshot(
                        snapshot=element_children_as_snapshot(children),
                        class_name=cls_name,
                        existing_code=existing_comp_code,
                    )

                    self._pending_updates[str(source_file)] = new_comp_code
                    self._pending_updates.update(sub_generator.get_pending_updates())

                # Clear children from tree to avoid generating them in parent
                el["children"] = []

            # Recurse
            children = get_element_children(el)
            if children:
                self._apply_components(children, component_overrides)

    def _normalize_variants_recursive(self, elements: list[PageElementNode]) -> None:
        """
        Recursively ensures all 'text' arguments are converted to 'variants'.
        Standardizes 'variants' as the single source of truth for text content.
        """
        for el in elements:
            init_kwargs = require_object_map(
                el,
                "init_kwargs",
                context=f"generator normalize '{get_str(el, 'var_name') or '?'}'",
            )

            # Extract text
            text_val = init_kwargs.get("text")
            variants_val = init_kwargs.get("variants")

            gathered: set[str] = set()

            # Collect from variants
            if isinstance(variants_val, str):
                gathered.add(variants_val)
            else:
                add_unique_strings(gathered, as_str_list(variants_val))

            # Collect from text
            if isinstance(text_val, str):
                gathered.add(text_val)
            else:
                add_unique_strings(gathered, as_str_list(text_val))

            # Merge if needed
            if gathered:
                unique_sorted = sorted(gathered)

                # Assign back to variants
                if len(unique_sorted) == 1:
                    init_kwargs["variants"] = unique_sorted[0]
                    el["variants"] = unique_sorted[0]
                else:
                    init_kwargs["variants"] = unique_sorted
                    el["variants"] = unique_sorted

                # Remove text
                if "text" in init_kwargs:
                    del init_kwargs["text"]

            # Recurse
            children = get_element_children(el)
            if children:
                self._normalize_variants_recursive(children)

    def _merge_all_classes_cst(self, existing_code: str, new_code: str) -> str:
        """
        Merges ALL classes from new_code into existing_code.
        - Updates __init__ for existing classes.
        - Appends new classes.
        - Merges imports.
        """
        from persona_dsl.editors.base import CodeEditor

        try:
            editor = CodeEditor(existing_code)
            editor.merge_all_classes_from_other_code(new_code)
            return editor.get_code(use_black=True)
        except (black.InvalidInput, cst.ParserSyntaxError) as exc:
            raise RuntimeError(
                "Не удалось объединить существующий и новый код страницы"
            ) from exc
