from __future__ import annotations

from collections.abc import Iterable
from typing import TypeAlias

ObjectMap: TypeAlias = dict[str, object]
SnapshotNode: TypeAlias = str | ObjectMap
SnapshotNodeList: TypeAlias = list["SnapshotNode"]
ElementInitKwargs: TypeAlias = ObjectMap
PageElementNode: TypeAlias = ObjectMap
ExistingElementDefinition: TypeAlias = ObjectMap
ExistingElementDefinitions: TypeAlias = dict[str, ExistingElementDefinition]
ExistingLocalValues: TypeAlias = dict[str, object]
ExistingEnums: TypeAlias = dict[str, dict[str, dict[str, str]]]
ComponentOverride: TypeAlias = tuple[str, str]
ComponentOverrides: TypeAlias = dict[str, ComponentOverride]


def as_object_map(value: object) -> ObjectMap | None:
    if not isinstance(value, dict):
        return None
    if not all(isinstance(key, str) for key in value):
        return None
    return value


def get_object_map(node: ObjectMap, key: str) -> ObjectMap:
    value = as_object_map(node.get(key))
    if value is None:
        return {}
    return value


def require_object_map(node: ObjectMap, key: str, *, context: str) -> ObjectMap:
    value = as_object_map(node.get(key))
    if value is None:
        raise ValueError(f"{context}: ожидается объект в поле '{key}'")
    return value


def get_str(node: ObjectMap, key: str) -> str | None:
    value = node.get(key)
    if isinstance(value, str):
        return value
    return None


def require_str(node: ObjectMap, key: str, *, context: str) -> str:
    value = node.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"{context}: ожидается непустая строка в поле '{key}'")
    return value


def get_bool(node: ObjectMap, key: str) -> bool | None:
    value = node.get(key)
    if isinstance(value, bool):
        return value
    return None


def get_str_list(node: ObjectMap, key: str) -> list[str]:
    value = node.get(key)
    return as_str_list(value)


def require_str_list(node: ObjectMap, key: str, *, context: str) -> list[str]:
    values = as_str_list(node.get(key))
    if not values:
        raise ValueError(f"{context}: ожидается непустой список строк в поле '{key}'")
    return values


def as_str_list(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    if not all(isinstance(item, str) for item in value):
        return []
    return list(value)


def add_unique_strings(target: set[str], values: Iterable[object]) -> None:
    for value in values:
        if isinstance(value, str):
            target.add(value)


def get_snapshot_children(node: ObjectMap) -> SnapshotNodeList:
    value = node.get("children")
    if not isinstance(value, list):
        return []
    children: SnapshotNodeList = []
    for item in value:
        if isinstance(item, str):
            children.append(item)
            continue
        obj = as_object_map(item)
        if obj is not None:
            children.append(obj)
    return children


def get_element_children(node: PageElementNode) -> list[PageElementNode]:
    value = node.get("children")
    if not isinstance(value, list):
        return []
    children: list[PageElementNode] = []
    for item in value:
        child = as_object_map(item)
        if child is not None:
            children.append(child)
    return children


def element_children_as_snapshot(children: list[PageElementNode]) -> SnapshotNodeList:
    snapshot: SnapshotNodeList = []
    for child in children:
        snapshot.append(child)
    return snapshot
