# persona-dsl: фреймворк для автотестов на Python

`persona-dsl` — это библиотека для E2E-, API- и интеграционных тестов, построенная вокруг Screenplay-подхода и тесно связанная с runtime/discovery/tooling, которые использует TaaS.

## Установка

```bash
pip install persona-dsl
python -m playwright install --with-deps
```

## Базовая модель

Публичный слой строится вокруг:

- `Persona`
- `Ops`
- `Step`
- `CombinedStep`
- алиасов `Action`, `Fact`, `Expectation`, `Goal`
- `Page` и `Element`

```python
from __future__ import annotations

from persona_dsl import Goal
from persona_dsl.ops.web import Click, CurrentPath, Fill, NavigateTo
from persona_dsl.expectations.generic import IsEqualTo
from persona_dsl.pages import Button, Page, TextField


class LoginPage(Page):
    expected_path = "/login"

    username = TextField(name="username", accessible_name="Логин")
    password = TextField(name="password", accessible_name="Пароль")
    submit_button = Button(name="submit_button", accessible_name="Войти")


def test_login_flow(persona) -> None:
    login_page = LoginPage()

    persona.make(
        NavigateTo(login_page),
        Fill(login_page.username, "admin"),
        Fill(login_page.password, "secret"),
        Click(login_page.submit_button),
    )

    current_path = persona.get(CurrentPath())
    persona.check(current_path, IsEqualTo("/dashboard"))
```

## Страницы и элементы

`Page` наследуется от `Element` и добавляет:

- `expected_path`
- `default_query_params`
- `build_url(base_url=None)`

`Element` поддерживает:

- declarative class attrs
- `aria_ref`
- multi-strategy resolve
- `.using(...)`, `.robust()`, `.resolve_or(...)`
- `ElementList`
- `Table` и declarative table DSL

`VirtualPage` используется для динамической in-memory модели страницы.

## Генерация page object'ов

`PageGenerator` и `GeneratePageObject` генерируют **declarative** page objects.

Для обычных generated страниц текущий контракт такой:

- committed generated file не содержит `def __init__(...)`
- не содержит `self.add_element(...)`
- не содержит `self.add_element_list(...)`
- хранит `expected_path`, snapshot/screenshot paths и `aria_ref`
- для повторяющихся анонимных контролов может выпускать declarative group, доступную по индексу как `page.otp_kod[0]`
- внутри таких групп item-level `aria_ref` может намеренно отсутствовать, чтобы resolve шёл через container scope и `role + index`
- поддерживает merge/regeneration
- использует footer-секции unresolved/archived diagnostics

CLI:

```bash
persona-page-gen --url http://localhost:8080 --output tests/pages/home_page.py
```

Из теста:

```python
from persona_dsl.ops.web import GeneratePageObject, NavigateTo


def test_generate_home_page(persona) -> None:
    persona.make(NavigateTo("/"))
    persona.make(
        GeneratePageObject(
            class_name="HomePage",
            output_path="tests/pages/home_page.py",
            wait_for_state="networkidle",
            sleep_before=1,
        )
    )
```

## Таблицы

Актуальный table contract включает:

- `Column(...)`
- `TableColumn`
- `table.filters.*`
- `row.elements.*`
- `row.element(column)`
- `row.value(column)`
- `row.details`
- `table.select_all_checkbox`

Generator использует этот DSL и для обычных, и для сложных таблиц.

## Конфигурация

Конфигурация проекта живёт в `config/{env}.yaml` и `tests/conftest.py`. Для запуска:

```bash
pytest --env=dev tests/
```

Если нужен локальный генератор страниц или шаблонный проект, ориентируйтесь на `example_template`.

## Где смотреть дальше

- [Общее руководство по persona-dsl](/Users/pavelglyanenko/Documents/Projects/at_template_project/docs/persona_dsl_guide.md)
- [Генератор страниц](/Users/pavelglyanenko/Documents/Projects/at_template_project/docs/pages/LCL-Pac4dc66f__persona-dsl---генератор-страниц-pageobjects.md)
- [Архитектура базовых элементов](/Users/pavelglyanenko/Documents/Projects/at_template_project/docs/pages/LCL-P60abdc55__архитектура-базовых-элементов-persona-dsl.md)
- [Элементы, списки и таблицы](/Users/pavelglyanenko/Documents/Projects/at_template_project/docs/pages/LCL-P837e23bd__работа-с-элементами-списками-и-таблицами.md)
