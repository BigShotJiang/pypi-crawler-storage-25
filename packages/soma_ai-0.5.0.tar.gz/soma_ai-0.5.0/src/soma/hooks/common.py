"""Shared utilities for SOMA Claude Code hooks."""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

from soma.state import (  # noqa: F401
    PREDICTOR_PATH, FINGERPRINT_PATH, TASK_TRACKER_PATH, QUALITY_PATH,
    get_predictor, save_predictor,
    get_fingerprint_engine, save_fingerprint_engine,
    get_task_tracker, save_task_tracker,
    get_quality_tracker, save_quality_tracker,
)

SOMA_DIR = Path.home() / ".soma"
SESSIONS_DIR = SOMA_DIR / "sessions"
ENGINE_STATE_PATH = SOMA_DIR / "engine_state.json"
STATE_PATH = SOMA_DIR / "state.json"
ACTION_LOG_PATH = SOMA_DIR / "action_log.json"  # legacy fallback


def _action_log_path(agent_id: str = "") -> Path:
    """Session-scoped action log path."""
    if agent_id:
        return SESSIONS_DIR / agent_id / "action_log.json"
    return ACTION_LOG_PATH

CLAUDE_TOOLS = [
    "Bash", "Edit", "Read", "Write", "Grep", "Glob",
    "Agent", "WebSearch", "WebFetch", "Skill", "NotebookEdit",
]

# Maximum actions to keep in the log
ACTION_LOG_MAX = 20

# Default hook config (overridden by soma.toml [hooks] section)
DEFAULT_HOOK_CONFIG = {
    "verbosity": "normal",  # minimal, normal, verbose
    "validate_python": True,
    "validate_js": True,
    "lint_python": True,
    "predict": True,
    "fingerprint": True,
    "quality": True,
    "task_tracking": True,
}


def get_hook_config() -> dict:
    """Load hook configuration from soma.toml or use defaults."""
    try:
        from soma.cli.config_loader import load_config
        config = load_config()
        hook_cfg = config.get("hooks", {})
        merged = dict(DEFAULT_HOOK_CONFIG)
        merged.update(hook_cfg)
        return merged
    except Exception:
        return dict(DEFAULT_HOOK_CONFIG)


def get_guidance_thresholds() -> dict[str, float] | None:
    """Load guidance thresholds from soma.toml config."""
    try:
        from soma.cli.config_loader import load_config
        config = load_config()
        thresholds = config.get("thresholds")
        if thresholds and any(k in thresholds for k in ("guide", "warn", "block")):
            return thresholds
    except Exception:
        pass
    return None


def detect_workflow_mode() -> str:
    """Detect current GSD workflow mode. Delegates to soma.context."""
    try:
        from soma.context import detect_workflow_mode as _detect
        return _detect()
    except Exception:
        return ""


def read_action_log(agent_id: str = "") -> list[dict]:
    """Read recent action log for pattern analysis."""
    path = _action_log_path(agent_id)
    try:
        if path.exists():
            return json.loads(path.read_text())
    except (json.JSONDecodeError, IOError):
        pass
    return []


def append_action_log(tool_name: str, error: bool = False, file_path: str = "",
                      agent_id: str = "") -> list[dict]:
    """Append an action to the log and return updated log.

    Uses file locking to prevent race conditions when multiple
    PostToolUse hooks run concurrently.
    """
    import fcntl

    entry = {
        "tool": tool_name,
        "error": error,
        "file": file_path,
        "ts": time.time(),
    }

    path = _action_log_path(agent_id)

    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        lock_path = path.parent / "action_log.lock"

        with open(lock_path, "w") as lock_file:
            fcntl.flock(lock_file, fcntl.LOCK_EX)
            try:
                log = read_action_log(agent_id)
                log.append(entry)
                log = log[-ACTION_LOG_MAX:]
                path.write_text(json.dumps(log))
            finally:
                fcntl.flock(lock_file, fcntl.LOCK_UN)

        return log
    except Exception:
        # Fallback: try without lock
        log = read_action_log(agent_id)
        log.append(entry)
        log = log[-ACTION_LOG_MAX:]
        try:
            path.write_text(json.dumps(log))
        except IOError:
            pass
        return log


SESSION_ID_PATH = SOMA_DIR / "session_id"


def _get_session_agent_id() -> str:
    """Return a unique agent ID per Claude Code session.

    Uses PPID (the Claude Code process that spawned this hook) so each
    terminal/session gets isolated monitoring. Context compressions
    within the same session keep the same PPID, so state is preserved.

    Fallback to 'claude-code' if PPID detection fails.
    """
    import os
    try:
        ppid = os.getppid()
        if ppid > 1:  # 1 = init/launchd, not useful
            return f"cc-{ppid}"
    except Exception:
        pass
    return "claude-code"


_TOML_MIGRATED = False


def _maybe_migrate_soma_toml() -> None:
    """If soma.toml exists with old threshold keys, migrate in place."""
    global _TOML_MIGRATED
    if _TOML_MIGRATED:
        return
    _TOML_MIGRATED = True
    try:
        import tomllib
        toml_path = Path("soma.toml")
        if not toml_path.exists():
            return
        with open(toml_path, "rb") as f:
            config = tomllib.load(f)
        thresholds = config.get("thresholds", {})
        if any(k in thresholds for k in ("caution", "degrade", "quarantine")):
            from soma.cli.config_loader import migrate_config, save_config
            migrated = migrate_config(config)
            save_config(migrated, str(toml_path))
    except Exception:
        pass


def get_engine():
    """Load or create SOMA engine with session-scoped agent registered.

    Uses Claude Code optimized config (higher thresholds, relaxed sensitivity).
    Returns (engine, agent_id) tuple. Returns (None, None) on import failure.
    """
    _maybe_migrate_soma_toml()

    try:
        from soma.engine import SOMAEngine
        from soma.persistence import load_engine_state
        from soma.cli.config_loader import CLAUDE_CODE_CONFIG
    except ImportError:
        return None, None

    SOMA_DIR.mkdir(parents=True, exist_ok=True)

    engine = load_engine_state(str(ENGINE_STATE_PATH))
    if engine is None:
        engine = SOMAEngine(
            budget=CLAUDE_CODE_CONFIG["budget"],
            custom_weights=CLAUDE_CODE_CONFIG["weights"],
            custom_thresholds=CLAUDE_CODE_CONFIG["thresholds"],
        )

    # Always ensure Claude Code config is applied (may be lost on state reload)
    if engine._custom_weights is None:
        engine._custom_weights = CLAUDE_CODE_CONFIG["weights"]
    if engine._custom_thresholds is None:
        engine._custom_thresholds = CLAUDE_CODE_CONFIG["thresholds"]

    agent_id = _get_session_agent_id()
    try:
        engine.get_level(agent_id)
    except Exception:
        engine.register_agent(agent_id, tools=CLAUDE_TOOLS)

    return engine, agent_id


def _inherit_baseline(engine, new_agent_id: str) -> None:
    """Copy baseline from the most active previous session.

    This gives the new session a warm start — SOMA already knows what
    'normal' looks like for this user instead of starting cold.
    """
    try:
        best_id = None
        best_count = 0
        for aid, s in engine._agents.items():
            if aid == new_agent_id or aid == "default":
                continue
            if s.action_count > best_count:
                best_count = s.action_count
                best_id = aid

        if best_id and best_count >= 10:
            donor = engine._agents[best_id]
            new_agent = engine._agents[new_agent_id]

            # Copy baseline (the learned signal averages)
            from soma.baseline import Baseline
            new_agent.baseline = Baseline.from_dict(donor.baseline.to_dict())

            # Copy baseline behavior vector (for drift detection)
            if donor.baseline_vector is not None:
                new_agent.baseline_vector = list(donor.baseline_vector)

            # Copy known tools
            new_agent.known_tools = list(donor.known_tools)

            # Skip grace period — baseline is inherited, not cold
            # Set action_count to min_samples so pressure is applied immediately
            new_agent.action_count = new_agent.baseline.min_samples
    except Exception:
        pass  # Never crash


def _cleanup_old_agents(engine, current_id: str, keep: int = 2) -> None:
    """Remove old session agents, keeping only the N most active + current."""
    try:
        agents = {
            aid: s for aid, s in engine._agents.items()
            if aid != current_id and aid != "default"
        }
        if len(agents) <= keep:
            return

        # Sort by action_count descending, keep top N
        sorted_agents = sorted(agents.items(), key=lambda x: x[1].action_count, reverse=True)
        to_remove = [aid for aid, _ in sorted_agents[keep:]]
        for aid in to_remove:
            del engine._agents[aid]
            engine._graph._nodes.pop(aid, None)
    except Exception:
        pass  # Never crash


def save_state(engine):
    """Persist engine state for dashboard, Paperclip, and status line."""
    try:
        from soma.persistence import save_engine_state

        SOMA_DIR.mkdir(parents=True, exist_ok=True)
        engine.export_state(str(STATE_PATH))
        save_engine_state(engine, str(ENGINE_STATE_PATH))
    except Exception:
        pass



def read_stdin() -> dict:
    """Read JSON payload from stdin (Claude Code passes hook data this way)."""
    try:
        if not sys.stdin.isatty():
            raw = sys.stdin.read().strip()
            if raw:
                return json.loads(raw)
    except (json.JSONDecodeError, IOError):
        pass
    return {}
