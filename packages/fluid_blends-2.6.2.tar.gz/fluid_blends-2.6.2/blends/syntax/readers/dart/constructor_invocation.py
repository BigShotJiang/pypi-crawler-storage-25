from blends.models import (
    NId,
)
from blends.query import (
    match_ast_group,
)
from blends.syntax.builders.method_invocation import (
    DirectChildren,
    build_method_invocation_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    matches = match_ast_group(
        graph,
        args.n_id,
        "type_identifier",
        "identifier",
        "arguments",
    )
    type_ids = matches["type_identifier"]
    method_id = matches["identifier"][0] if matches["identifier"] else None
    args_id = matches["arguments"][0] if matches["arguments"] else None

    class_name = ".".join(node_to_str(graph, t) for t in type_ids)
    method_name = node_to_str(graph, method_id) if method_id is not None else ""
    expr = f"{class_name}.{method_name}" if method_name else class_name

    children: DirectChildren = {}
    if type_ids:
        children["object_id"] = type_ids[0]
    if method_id is not None:
        children["expression_id"] = method_id
    if args_id is not None:
        children["arguments_id"] = args_id

    return build_method_invocation_node(args, expr, children)
