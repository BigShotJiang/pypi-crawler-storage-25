from blends.models import VALID_SYNTAX_ATTRIBUTES

__all__ = ["VALID_SYNTAX_ATTRIBUTES"]
