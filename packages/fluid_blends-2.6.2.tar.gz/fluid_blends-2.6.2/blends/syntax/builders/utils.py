from blends.ast.node_attributes_types import (
    AstNodeAttrs,
)
from blends.models import (
    Graph,
    NId,
)
from blends.query import (
    adj_ast,
)
from blends.stack.attributes import (
    STACK_GRAPH_IS_REFERENCE,
)
from blends.stack.edges import (
    Edge,
    add_edge,
)
from blends.stack.node_helpers import (
    pop_scoped_symbol_node_attributes,
    pop_symbol_node_attributes,
    push_scoped_symbol_node_attributes,
    root_node_attributes,
)
from blends.stack.policies.registry import (
    get_export_policy,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)

_PATTERN_NODE_TYPES: frozenset[str] = frozenset(
    {"pattern_list", "tuple_pattern", "list_pattern", "list_splat_pattern"}
)


def _constructor_class_field_id(value_node: AstNodeAttrs) -> NId | None:
    label_type = value_node.get("label_type")
    if label_type == "call":
        return value_node.get("label_field_function")
    if label_type == "new_expression":
        return value_node.get("label_field_constructor")
    return None


def extract_constructor_class_name(ast_graph: Graph, value_id: NId | None) -> str | None:
    if value_id is None:
        return None
    field_id = _constructor_class_field_id(ast_graph.nodes.get(value_id, {}))
    if field_id is None:
        return None
    if ast_graph.nodes.get(field_id, {}).get("label_type") != "identifier":
        return None
    return node_to_str(ast_graph, field_id) or None


def wire_dot_gateway(
    args: SyntaxGraphArgs,
    node_id: NId,
    target_scope_nid: NId,
) -> None:
    dot_gateway_id = get_next_synthetic_node_id(args)
    dot_attrs = pop_symbol_node_attributes(symbol=".", is_definition=False)
    args.syntax_graph.add_node(dot_gateway_id, label_type="SyntheticDotGateway")
    if args.stack_graph is not None:
        args.stack_graph.add_node(dot_gateway_id, **dot_attrs)
    edge_to_gateway = Edge(source=node_id, sink=dot_gateway_id)
    if args.stack_graph is not None:
        add_edge(args.stack_graph, edge_to_gateway)
    edge_to_scope = Edge(source=dot_gateway_id, sink=target_scope_nid)
    if args.stack_graph is not None:
        add_edge(args.stack_graph, edge_to_scope)


def wire_class_scope_bridge(
    args: SyntaxGraphArgs,
    node_id: NId,
    class_name: str,
    ref_scope_nid: NId,
) -> None:
    if args.stack_graph is None:
        return
    push_class_id = get_next_synthetic_node_id(args)
    push_attrs = push_scoped_symbol_node_attributes(
        symbol=class_name,
        scope=ref_scope_nid,
        is_reference=True,
    )
    args.stack_graph.add_node(push_class_id, **push_attrs)
    add_edge(args.stack_graph, Edge(source=push_class_id, sink=ref_scope_nid))
    wire_dot_gateway(args, node_id, push_class_id)


def extract_pattern_identifier_symbols(
    args: SyntaxGraphArgs, *, pattern_id: NId
) -> list[tuple[NId, str]]:
    label_type = args.ast_graph.nodes.get(pattern_id, {}).get("label_type")
    if label_type == "identifier":
        symbol = node_to_str(args.ast_graph, pattern_id)
        return [(pattern_id, symbol)] if symbol else []
    if label_type in _PATTERN_NODE_TYPES:
        return [
            result
            for child_id in args.ast_graph.successors(pattern_id)
            for result in extract_pattern_identifier_symbols(args, pattern_id=child_id)
        ]
    return []


def add_pattern_binding_nodes(args: SyntaxGraphArgs, *, var_id: NId) -> None:
    scope_stack = args.metadata.setdefault("scope_stack", [])
    parent_scope = scope_stack[-1] if scope_stack else None
    for identifier_nid, symbol in extract_pattern_identifier_symbols(args, pattern_id=var_id):
        synthetic_nid = get_next_synthetic_node_id(args)
        precedence = get_next_binding_precedence(args)
        stack_attrs = pop_scoped_symbol_node_attributes(symbol=symbol, precedence=precedence)
        if args.stack_graph is not None:
            args.stack_graph.add_node(synthetic_nid, **stack_attrs)
        if parent_scope:
            edge = Edge(source=parent_scope, sink=synthetic_nid, precedence=precedence)
            if args.stack_graph is not None:
                add_edge(args.stack_graph, edge)
        if args.syntax_graph.nodes.get(identifier_nid) and args.stack_graph is not None:
            ref_attr: dict[str, object] = {STACK_GRAPH_IS_REFERENCE: False}
            args.stack_graph.add_node(identifier_nid, **ref_attr)


def _record_subpath(args: SyntaxGraphArgs, def_nid: NId) -> None:
    control_flow_stack = args.metadata.get("control_flow_stack", [])
    subpath = control_flow_stack[-1] if control_flow_stack else None
    args.syntax_graph.subpath_index[def_nid] = subpath


def register_multi_binding(args: SyntaxGraphArgs, var_id: NId, scope: NId) -> None:
    for child in adj_ast(args.syntax_graph, var_id, label_type="SymbolLookup"):
        if (sym := args.syntax_graph.nodes[child].get("symbol")) and sym != "_":
            args.syntax_graph.symbol_index.setdefault(sym, {}).setdefault(scope, []).append(
                args.n_id
            )
            _record_subpath(args, args.n_id)


def setup_scope_index_binding(args: SyntaxGraphArgs, var_id: NId) -> None:
    if not (scope_stack := args.metadata.get("scope_stack")):
        return
    if (symbol := bound_identifier_symbol(args, var_id=var_id)) is not None:
        args.syntax_graph.symbol_index.setdefault(symbol, {}).setdefault(
            scope_stack[-1], []
        ).append(args.n_id)
        _record_subpath(args, args.n_id)
    elif args.syntax_graph.nodes.get(var_id, {}).get("label_type") == "ArgumentList":
        register_multi_binding(args, var_id, scope_stack[-1])


def bound_identifier_symbol(args: SyntaxGraphArgs, *, var_id: NId) -> str | None:
    var_node = args.ast_graph.nodes.get(var_id, {})
    if var_node.get("label_type") != "identifier":
        return None
    symbol = node_to_str(args.ast_graph, var_id)
    return symbol or None


def get_next_binding_precedence(args: SyntaxGraphArgs) -> int:
    scope_stack = args.metadata.get("scope_stack", [])
    if not scope_stack:
        return 0
    return 1


def is_definition_exported(args: SyntaxGraphArgs) -> bool:
    policy = get_export_policy(args.language)
    scope_stack = args.metadata.get("scope_stack", [])
    parent_scope = scope_stack[-1] if scope_stack else None
    return policy.is_definition_exported(
        args.syntax_graph, args.stack_graph, args.n_id, parent_scope
    )


def find_import_bound_scope(args: SyntaxGraphArgs, symbol: str) -> int | None:
    scope_stack = args.metadata.get("scope_stack")
    if not scope_stack:
        return None
    symbol_data = args.syntax_graph.symbol_index.get(symbol, {})
    for scope in reversed(scope_stack):
        nodes_in_scope = symbol_data.get(scope, [])
        if not nodes_in_scope:
            continue
        for nid in nodes_in_scope:
            node = args.syntax_graph.nodes[nid]
            if node.get("label_type") == "Import" and node.get("expression") != "*":
                return scope
        return None
    return None


def get_next_synthetic_node_id(args: SyntaxGraphArgs) -> NId:
    current_id = args.metadata.get("next_synthetic_id")
    if current_id is None:
        msg = "next_synthetic_id not initialized in metadata"
        raise ValueError(msg)
    args.metadata["next_synthetic_id"] = current_id + 1
    return current_id


def get_enclosing_class_scope(args: SyntaxGraphArgs) -> NId | None:
    cms_stack = args.metadata.get("class_member_scope_stack")
    return cms_stack[-1][0] if cms_stack else None


def get_or_create_root_nid(args: SyntaxGraphArgs) -> NId:
    existing = args.metadata.get("root_nid")
    if existing is not None:
        return existing
    root_nid = get_next_synthetic_node_id(args)
    attrs = root_node_attributes()
    args.syntax_graph.add_node(root_nid)
    if args.stack_graph is not None:
        args.stack_graph.add_node(root_nid, **attrs)
    args.metadata["root_nid"] = root_nid
    return root_nid
