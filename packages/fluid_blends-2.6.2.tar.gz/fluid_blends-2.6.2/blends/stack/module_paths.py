_INDEX_STEMS: frozenset[str] = frozenset({"__init__", "index"})
