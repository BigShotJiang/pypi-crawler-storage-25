"""Tests for databricks_docs_mcp.utils module."""

import pytest

from databricks_docs_mcp.utils import (
    extract_content_from_html,
    extract_sections_from_html,
    format_documentation_result,
    is_html_content,
)


class TestIsHtmlContent:
    """Tests for is_html_content function."""

    def test_html_tag_in_content(self):
        assert is_html_content("<html><body>Test</body></html>", "") is True

    def test_html_content_type(self):
        assert is_html_content("Some content", "text/html; charset=utf-8") is True

    def test_non_html_content(self):
        assert is_html_content("Plain text content", "text/plain") is False

    def test_html_tag_case_insensitive(self):
        assert is_html_content("<HTML><BODY>Content</BODY></HTML>", "") is True

    def test_empty_content_and_content_type(self):
        assert is_html_content("", "") is False

    def test_html_tag_not_in_first_200_chars(self):
        # <html> appears past position 200, should not match
        padding = "x" * 201
        assert is_html_content(padding + "<html>", "") is False

    def test_json_content(self):
        assert is_html_content('{"key": "value"}', "application/json") is False


class TestFormatDocumentationResult:
    """Tests for format_documentation_result function."""

    def test_content_fits_within_max_length(self):
        content = "Short content"
        result = format_documentation_result("https://docs.databricks.com/test", content, 0, 100)
        assert "Short content" in result
        assert "Content truncated" not in result

    def test_content_truncated_adds_continuation_hint(self):
        content = "A" * 200
        result = format_documentation_result("https://docs.databricks.com/test", content, 0, 100)
        assert "Content truncated" in result
        assert "start_index=100" in result
        assert "100" in result  # remaining characters

    def test_pagination_with_start_index(self):
        content = "AAABBBCCC"
        result = format_documentation_result("https://docs.databricks.com/test", content, 3, 3)
        assert "BBB" in result
        assert "AAA" not in result

    def test_start_index_beyond_content_returns_empty(self):
        content = "Short"
        result = format_documentation_result("https://docs.databricks.com/test", content, 100, 100)
        assert result == ""

    def test_exact_fit_no_truncation_hint(self):
        content = "A" * 100
        result = format_documentation_result("https://docs.databricks.com/test", content, 0, 100)
        assert "Content truncated" not in result
        assert "A" * 100 in result

    def test_partial_read_with_more_remaining(self):
        content = "A" * 300
        result = format_documentation_result("https://docs.databricks.com/test", content, 100, 100)
        assert "start_index=200" in result
        assert "Content truncated" in result

    def test_partial_read_at_end_no_hint(self):
        content = "A" * 150
        result = format_documentation_result("https://docs.databricks.com/test", content, 100, 100)
        assert "Content truncated" not in result
        assert "A" * 50 in result

    def test_remaining_characters_count_in_hint(self):
        content = "A" * 500
        result = format_documentation_result("https://docs.databricks.com/test", content, 0, 100)
        assert "400" in result  # 400 characters remaining


class TestExtractContentFromHtml:
    """Tests for extract_content_from_html function."""

    def test_basic_html_returns_text(self):
        html = "<html><body><article><h1>Test Heading</h1><p>Content here.</p></article></body></html>"
        result = extract_content_from_html(html)
        assert "Test Heading" in result
        assert "Content here" in result

    def test_strips_nav_elements(self):
        html = (
            "<html><body>"
            "<nav>Navigation bar</nav>"
            "<article><p>Main content</p></article>"
            "</body></html>"
        )
        result = extract_content_from_html(html)
        assert "Main content" in result
        assert "Navigation bar" not in result

    def test_strips_script_tags(self):
        html = (
            "<html><body><article>"
            "<script>alert('evil')</script>"
            "<p>Real content</p>"
            "</article></body></html>"
        )
        result = extract_content_from_html(html)
        assert "Real content" in result
        assert "evil" not in result

    def test_strips_footer(self):
        html = (
            "<html><body>"
            "<article><p>Doc content</p></article>"
            "<footer>Footer text</footer>"
            "</body></html>"
        )
        result = extract_content_from_html(html)
        assert "Doc content" in result
        assert "Footer text" not in result

    def test_docusaurus_article_selector_preferred(self):
        html = (
            "<html><body>"
            "<div class='navbar'>Nav</div>"
            "<article><h1>Docs Title</h1><p>Page content.</p></article>"
            "</body></html>"
        )
        result = extract_content_from_html(html)
        assert "Page content" in result
        assert "Nav" not in result

    def test_returns_string(self):
        html = "<html><body><p>Hello</p></body></html>"
        result = extract_content_from_html(html)
        assert isinstance(result, str)

    def test_empty_html_returns_string(self):
        result = extract_content_from_html("")
        assert isinstance(result, str)


class TestExtractSectionsFromHtml:
    """Tests for extract_sections_from_html function."""

    def test_single_section_extracted(self):
        html = """<html><body>
            <h2>Introduction</h2><p>Intro text.</p>
            <h2>Main Section</h2><p>Main text.</p>
            <h2>Conclusion</h2><p>End text.</p>
        </body></html>"""
        result = extract_sections_from_html(html, ["Main Section"])
        assert "Main Section" in result
        assert "Main text" in result
        assert "Introduction" not in result
        assert "Conclusion" not in result

    def test_multiple_sections_extracted(self):
        html = """<html><body>
            <h2>Alpha</h2><p>Alpha content.</p>
            <h2>Beta</h2><p>Beta content.</p>
            <h2>Gamma</h2><p>Gamma content.</p>
        </body></html>"""
        result = extract_sections_from_html(html, ["Alpha", "Gamma"])
        assert "Alpha content" in result
        assert "Gamma content" in result
        assert "Beta content" not in result

    def test_case_insensitive_matching(self):
        html = "<html><body><h2>Main Section</h2><p>Content.</p></body></html>"
        result = extract_sections_from_html(html, ["MAIN SECTION"])
        assert "Content" in result

    def test_zero_width_space_stripped_from_headings(self):
        """Docusaurus appends U+200B to h2 heading anchors; matching must ignore it."""
        html = "<html><body><h2>Requirements\u200b</h2><p>Requirement text.</p></body></html>"
        result = extract_sections_from_html(html, ["Requirements"])
        assert "Requirement text" in result

    def test_no_match_raises_value_error(self):
        html = """<html><body>
            <h2>Existing Section</h2><p>Content.</p>
        </body></html>"""
        with pytest.raises(ValueError, match="No sections matched"):
            extract_sections_from_html(html, ["Nonexistent Section"])

    def test_error_message_lists_available_headings(self):
        html = """<html><body>
            <h2>Section A</h2><p>Content.</p>
            <h2>Section B</h2><p>Content.</p>
        </body></html>"""
        with pytest.raises(ValueError) as exc_info:
            extract_sections_from_html(html, ["Missing"])
        assert "Section A" in str(exc_info.value)
        assert "Section B" in str(exc_info.value)

    def test_section_at_end_of_document(self):
        html = """<html><body>
            <h2>First</h2><p>First content.</p>
            <h2>Last</h2><p>Last content.</p><p>More last.</p>
        </body></html>"""
        result = extract_sections_from_html(html, ["Last"])
        assert "Last content" in result
        assert "More last" in result
        assert "First content" not in result

    def test_partial_match_returns_found_sections(self):
        """When some sections are found and others are not, returns found sections without error."""
        html = """<html><body>
            <h2>Found Section</h2><p>Found content.</p>
        </body></html>"""
        result = extract_sections_from_html(html, ["Found Section", "Missing Section"])
        assert "Found content" in result

    def test_subsections_included_within_matched_section(self):
        html = """<html><body>
            <h2>Main Section</h2>
            <p>Main text.</p>
            <h3>Subsection</h3>
            <p>Sub text.</p>
            <h2>Next Section</h2>
            <p>Next text.</p>
        </body></html>"""
        result = extract_sections_from_html(html, ["Main Section"])
        assert "Main text" in result
        assert "Subsection" in result
        assert "Sub text" in result
        assert "Next text" not in result

    def test_wraps_result_in_div(self):
        html = "<html><body><h2>Test</h2><p>Content.</p></body></html>"
        result = extract_sections_from_html(html, ["Test"])
        assert result.startswith("<div>")
        assert result.endswith("</div>")
