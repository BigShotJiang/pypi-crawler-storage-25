"""Tests for databricks_docs_mcp.server module."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from databricks_docs_mcp.server import (
    read_documentation,
    read_sections,
    search_documentation,
)

# ── Helpers ────────────────────────────────────────────────────────────────────


def _make_response(status_code=200, text="<html><body><article><p>Content.</p></article></body></html>", content_type="text/html"):
    """Build a minimal mock httpx response."""
    mock_resp = MagicMock()
    mock_resp.status_code = status_code
    mock_resp.text = text
    mock_resp.headers = {"content-type": content_type}
    return mock_resp


def _mock_client(response):
    """Return a patched httpx.AsyncClient that yields *response* for any GET."""
    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=response)
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)
    return mock_client


@pytest.fixture()
def ctx():
    """A mock FastMCP Context with an async error method."""
    mock = MagicMock()
    mock.error = AsyncMock()
    return mock


# ── read_documentation ────────────────────────────────────────────────────────


class TestReadDocumentation:
    """Tests for read_documentation tool."""

    async def test_rejects_non_databricks_url(self, ctx):
        with pytest.raises(ValueError, match="docs.databricks.com"):
            await read_documentation(ctx, "https://example.com/page")

    async def test_successful_fetch_returns_markdown(self, ctx):
        html = "<html><body><article><h1>Clusters</h1><p>Create a cluster.</p></article></body></html>"
        response = _make_response(text=html)
        with patch("databricks_docs_mcp.server.httpx.AsyncClient", return_value=_mock_client(response)):
            result = await read_documentation(ctx, "https://docs.databricks.com/aws/en/clusters")
        assert "Clusters" in result
        assert "cluster" in result.lower()

    async def test_http_error_status_returns_error_message(self, ctx):
        response = _make_response(status_code=404)
        with patch("databricks_docs_mcp.server.httpx.AsyncClient", return_value=_mock_client(response)):
            result = await read_documentation(ctx, "https://docs.databricks.com/aws/en/missing")
        assert "<error>" in result
        ctx.error.assert_called_once()

    async def test_pagination_start_index(self, ctx):
        long_content = "X" * 10_000
        html = f"<html><body><article><p>{long_content}</p></article></body></html>"
        response = _make_response(text=html)
        with patch("databricks_docs_mcp.server.httpx.AsyncClient", return_value=_mock_client(response)):
            result = await read_documentation(
                ctx, "https://docs.databricks.com/aws/en/test", start_index=0, max_length=100
            )
        assert "Content truncated" in result
        assert "start_index=100" in result

    async def test_non_html_content_returned_as_is(self, ctx):
        plain = "Just plain text content"
        response = _make_response(text=plain, content_type="text/plain")
        with patch("databricks_docs_mcp.server.httpx.AsyncClient", return_value=_mock_client(response)):
            result = await read_documentation(ctx, "https://docs.databricks.com/aws/en/test")
        assert plain in result

    async def test_http_exception_returns_error_message(self, ctx):
        import httpx

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(side_effect=httpx.HTTPError("Connection failed"))
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)

        with patch("databricks_docs_mcp.server.httpx.AsyncClient", return_value=mock_client):
            result = await read_documentation(ctx, "https://docs.databricks.com/aws/en/test")
        assert "<error>" in result
        ctx.error.assert_called_once()


# ── search_documentation ──────────────────────────────────────────────────────


class TestSearchDocumentation:
    """Tests for search_documentation tool."""

    async def test_returns_json_with_results(self, ctx):
        mock_ddgs = MagicMock()
        mock_ddgs.return_value.text.return_value = [
            {"href": "https://docs.databricks.com/aws/en/clusters", "title": "Cluster configuration", "body": "Configure clusters."},
        ]
        with patch("databricks_docs_mcp.server.DDGS", mock_ddgs):
            result = await search_documentation(ctx, "cluster configuration")
        assert "docs.databricks.com" in result
        assert "Cluster configuration" in result

    async def test_no_results_returns_plain_message(self, ctx):
        mock_ddgs = MagicMock()
        mock_ddgs.return_value.text.return_value = []
        with patch("databricks_docs_mcp.server.DDGS", mock_ddgs):
            result = await search_documentation(ctx, "zzznomatch")
        assert "No documentation pages found" in result

    async def test_exception_returns_error_message(self, ctx):
        mock_ddgs = MagicMock()
        mock_ddgs.return_value.text.side_effect = Exception("Connection failed")
        with patch("databricks_docs_mcp.server.DDGS", mock_ddgs):
            result = await search_documentation(ctx, "clusters")
        assert "<error>" in result

    async def test_limit_caps_results(self, ctx):
        mock_ddgs = MagicMock()
        mock_ddgs.return_value.text.return_value = [
            {"href": f"https://docs.databricks.com/{i}", "title": f"Result {i}", "body": ""}
            for i in range(20)
        ]
        with patch("databricks_docs_mcp.server.DDGS", mock_ddgs):
            result = await search_documentation(ctx, "test", limit=3)
        import json

        data = json.loads(result)
        assert len(data["search_results"]) == 3

    async def test_filters_out_non_databricks_results(self, ctx):
        mock_ddgs = MagicMock()
        mock_ddgs.return_value.text.return_value = [
            {"href": "https://example.com/page", "title": "Example", "body": ""},
            {"href": "https://docs.databricks.com/test", "title": "Databricks", "body": ""},
        ]
        with patch("databricks_docs_mcp.server.DDGS", mock_ddgs):
            result = await search_documentation(ctx, "test")
        assert "example.com" not in result
        assert "docs.databricks.com" in result


# ── read_sections ─────────────────────────────────────────────────────────────


class TestReadSections:
    """Tests for read_sections tool."""

    async def test_rejects_non_databricks_url(self, ctx):
        with pytest.raises(ValueError, match="docs.databricks.com"):
            await read_sections(ctx, "https://example.com/page", ["Section"])

    async def test_rejects_empty_section_titles(self, ctx):
        with pytest.raises(ValueError, match="section_titles"):
            await read_sections(ctx, "https://docs.databricks.com/aws/en/test", [])

    async def test_extracts_requested_sections(self, ctx):
        html = """<html><body>
            <article>
                <h2>Overview</h2><p>Overview content.</p>
                <h2>Requirements</h2><p>Requirement details.</p>
                <h2>Examples</h2><p>Example code.</p>
            </article>
        </body></html>"""
        response = _make_response(text=html)
        with patch("databricks_docs_mcp.server.httpx.AsyncClient", return_value=_mock_client(response)):
            result = await read_sections(ctx, "https://docs.databricks.com/aws/en/test", ["Requirements"])
        assert "Requirement details" in result
        assert "Overview content" not in result
        assert "Example code" not in result

    async def test_section_not_found_raises_value_error(self, ctx):
        html = "<html><body><article><h2>Existing Section</h2><p>Content.</p></article></body></html>"
        response = _make_response(text=html)
        with patch("databricks_docs_mcp.server.httpx.AsyncClient", return_value=_mock_client(response)):
            with pytest.raises(ValueError):
                await read_sections(ctx, "https://docs.databricks.com/aws/en/test", ["Nonexistent"])

    async def test_http_error_returns_error_message(self, ctx):
        response = _make_response(status_code=503)
        with patch("databricks_docs_mcp.server.httpx.AsyncClient", return_value=_mock_client(response)):
            result = await read_sections(
                ctx, "https://docs.databricks.com/aws/en/test", ["Section"]
            )
        assert "<error>" in result

    async def test_non_html_response_returns_guidance(self, ctx):
        response = _make_response(text="plain text only", content_type="text/plain")
        with patch("databricks_docs_mcp.server.httpx.AsyncClient", return_value=_mock_client(response)):
            result = await read_sections(
                ctx, "https://docs.databricks.com/aws/en/test", ["Section"]
            )
        assert "read_documentation" in result

    async def test_zero_width_space_headings_matched(self, ctx):
        """Docusaurus appends U+200B to h2 anchors; read_sections must still match."""
        html = (
            "<html><body><article>"
            "<h2>Configuration\u200b</h2><p>Config text.</p>"
            "</article></body></html>"
        )
        response = _make_response(text=html)
        with patch("databricks_docs_mcp.server.httpx.AsyncClient", return_value=_mock_client(response)):
            result = await read_sections(
                ctx, "https://docs.databricks.com/aws/en/test", ["Configuration"]
            )
        assert "Config text" in result
