"""Pydantic models for Databricks Documentation MCP Server."""

from typing import List, Optional

from pydantic import BaseModel


class SearchResult(BaseModel):
    """A single search result entry."""

    rank_order: int
    url: str
    title: str
    context: Optional[str] = None
    sections: Optional[List[str]] = None


class SearchResponse(BaseModel):
    """Response returned by the search_documentation tool."""

    search_results: List[SearchResult]
