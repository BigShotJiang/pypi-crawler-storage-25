"""Databricks Documentation MCP Server.

Lightweight, stateless server that fetches docs.databricks.com pages live.

Tools:
  - search_documentation  — search for docs pages by keyword (live web search)
  - read_documentation    — read a page as markdown (live fetch)
  - read_sections         — extract specific sections from a page (live fetch)
"""

from __future__ import annotations

import asyncio
import os
import sys
from typing import Annotated, List, Optional

import httpx
from ddgs import DDGS
from fastmcp import Context, FastMCP
from pydantic import Field

from databricks_docs_mcp.models import SearchResponse, SearchResult
from databricks_docs_mcp.utils import (
    extract_content_from_html,
    extract_sections_from_html,
    format_documentation_result,
    is_html_content,
)

# ── Configuration ─────────────────────────────────────────────────────────────

DEFAULT_USER_AGENT = os.environ.get(
    "MCP_USER_AGENT",
    "Mozilla/5.0 (compatible; DatabricksDocsMCP/1.0)",
)

# ── MCP server ────────────────────────────────────────────────────────────────

mcp = FastMCP(
    name="DatabricksDocumentation",
    instructions="""
# Databricks Documentation MCP Server

Read and search docs.databricks.com content in real time.

## Tool Selection Guide
- `search_documentation` — find relevant pages by keyword or topic (use this first).
- `read_documentation`   — read any docs.databricks.com URL as markdown (live fetch).
- `read_sections`        — extract named h2 sections from a page (live fetch).

## Recommended Workflow
1. Call `search_documentation` with a topic to get matching page URLs.
2. Call `read_documentation` on a relevant URL to read its full content.
3. Optionally call `read_sections` to pull specific h2 sections in detail.

## Tips
- Databricks docs URLs follow the pattern:
  https://docs.databricks.com/<cloud>/en/<topic>/...
- For long pages, use `start_index` in `read_documentation` to paginate.
- Section titles for `read_sections` must match the h2 headings on the page.
""",
)

# ── Fetch helper ──────────────────────────────────────────────────────────────


async def _fetch_live(ctx: Context, url: str) -> Optional[str]:
    """Fetch a live Databricks docs page and return its markdown content."""
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(
                url,
                follow_redirects=True,
                headers={"User-Agent": DEFAULT_USER_AGENT},
                timeout=30,
            )
        except httpx.HTTPError as exc:
            await ctx.error(f"HTTP error fetching {url}: {exc}")
            return None

        if response.status_code >= 400:
            await ctx.error(f"HTTP {response.status_code} for {url}")
            return None

        page_raw = response.text
        content_type = response.headers.get("content-type", "")

        if is_html_content(page_raw, content_type):
            return extract_content_from_html(page_raw)
        return page_raw


# ── Tools ─────────────────────────────────────────────────────────────────────

_DOCS_BASE = "docs.databricks.com"


@mcp.tool()
async def search_documentation(
    ctx: Context,
    query: Annotated[
        str,
        Field(description="Search terms or topic to find in Databricks documentation"),
    ],
    limit: Annotated[
        int,
        Field(default=10, description="Maximum number of results to return", gt=0, le=30),
    ] = 10,
) -> str:
    """Search Databricks documentation and return matching page URLs with titles and snippets.

    Performs a real-time web search scoped to docs.databricks.com/aws/en and returns
    the most relevant pages for your query.

    Args:
        query: Topic or keywords to search for (e.g. "cluster policies", "Delta Live Tables").
        limit: Maximum results to return (default 10, max 30).
    """
    site_query = f"site:{_DOCS_BASE}/aws/en {query}"

    try:
        raw_results = await asyncio.to_thread(lambda: DDGS().text(site_query, max_results=limit))
    except Exception as exc:
        await ctx.error(f"Search request failed: {exc}")
        return "<error>Search request failed</error>"

    raw_results = raw_results[:limit]

    results: List[SearchResult] = []
    for rank, item in enumerate(raw_results, start=1):
        url = item.get("href", "")
        if not url or _DOCS_BASE not in url:
            continue
        results.append(
            SearchResult(
                rank_order=rank,
                url=url,
                title=item.get("title", ""),
                context=item.get("body"),
            )
        )

    if not results:
        return "No documentation pages found matching your query."

    return SearchResponse(search_results=results).model_dump_json(indent=2)


@mcp.tool()
async def read_documentation(
    ctx: Context,
    url: Annotated[
        str,
        Field(description="docs.databricks.com URL to read"),
    ],
    max_length: Annotated[
        int,
        Field(default=5000, description="Maximum characters to return", gt=0, le=1_000_000),
    ] = 5000,
    start_index: Annotated[
        int,
        Field(default=0, description="Character offset for pagination", ge=0),
    ] = 0,
) -> str:
    """Read a Databricks documentation page as markdown (live fetch).

    Fetches the page in real time and converts it to markdown.
    For long pages, use start_index and max_length to paginate.

    Args:
        url:         Full docs.databricks.com URL (must contain "docs.databricks.com").
        max_length:  Characters to return per call (default 5000).
        start_index: Starting character position for pagination (default 0).
    """
    if "docs.databricks.com" not in url:
        raise ValueError("URL must be from docs.databricks.com")

    content = await _fetch_live(ctx, url)
    if content is None:
        return f"<error>Could not retrieve {url}</error>"

    return format_documentation_result(url, content, start_index, max_length)


@mcp.tool()
async def read_sections(
    ctx: Context,
    url: Annotated[
        str,
        Field(description="docs.databricks.com URL of the page"),
    ],
    section_titles: Annotated[
        List[str],
        Field(description="List of section headings (h2) to extract (case-insensitive)"),
    ],
) -> str:
    """Extract specific named sections from a Databricks documentation page.

    Always fetches the page live so section content is current. Section
    matching is case-insensitive against <h2> headings.

    Use search_documentation first to find a URL, then read_documentation to
    discover available section headings, then call this tool to pull specific
    sections in detail.

    Args:
        url:            Full docs.databricks.com URL.
        section_titles: One or more h2 heading titles to extract.
    """
    if "docs.databricks.com" not in url:
        raise ValueError("URL must be from docs.databricks.com")
    if not section_titles:
        raise ValueError("section_titles must contain at least one entry")

    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(
                url,
                follow_redirects=True,
                headers={"User-Agent": DEFAULT_USER_AGENT},
                timeout=30,
            )
        except httpx.HTTPError as exc:
            error_msg = f"HTTP error fetching {url}: {exc}"
            await ctx.error(error_msg)
            return f"<error>{error_msg}</error>"

        if response.status_code >= 400:
            error_msg = f"HTTP {response.status_code} for {url}"
            await ctx.error(error_msg)
            return f"<error>{error_msg}</error>"

        page_raw = response.text
        content_type = response.headers.get("content-type", "")

    if not is_html_content(page_raw, content_type):
        return (
            "Page does not appear to be HTML. "
            "Use read_documentation instead to read the raw content."
        )

    try:
        section_html = extract_sections_from_html(page_raw, section_titles)
        return extract_content_from_html(section_html)
    except ValueError as exc:
        await ctx.error(str(exc))
        raise


# ── Entry point ───────────────────────────────────────────────────────────────


def main() -> None:
    """Run the MCP server (stdio transport)."""
    # Ensure UTF-8 on Windows so emoji/Unicode in any output doesn't crash
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")
    mcp.run()


if __name__ == "__main__":
    main()
