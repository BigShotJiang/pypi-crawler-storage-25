"""HTML extraction and formatting utilities for Databricks Documentation MCP Server.

Adapted from the AWS Documentation MCP Server (awslabs/mcp, Apache 2.0).
Databricks docs use Docusaurus, so content selectors differ from AWS docs.
"""

from typing import Optional

from bs4 import BeautifulSoup, Tag

# Docusaurus / Databricks docs content selectors (tried in order, first match wins)
_CONTENT_SELECTORS = [
    {"name": "article"},
    {"class_": "theme-doc-markdown"},
    {"class_": "markdown"},
    {"id": "__docusaurus"},
    {"role": "main"},
    {"name": "main"},
]

# Tags to strip entirely (including their children) before markdown conversion
_STRIP_TAGS = {
    "script", "style", "nav", "footer", "header",
    "aside", "noscript", "iframe", "form",
    # Docusaurus-specific chrome
    "div[class*='navbar']",
    "div[class*='sidebar']",
    "div[class*='tocCollapsible']",
    "div[class*='pagination']",
    "div[class*='docSidebarContainer']",
}

_STRIP_TAG_NAMES = {"script", "style", "nav", "footer", "header", "aside", "noscript", "iframe", "form"}
_STRIP_CLASS_FRAGMENTS = ["navbar", "sidebar", "tocCollapsible", "pagination", "docSidebarContainer", "DocSearch"]


def _strip_noise(soup: BeautifulSoup) -> None:
    """Remove navigation, sidebars, scripts, and other non-content elements."""
    for tag in soup.find_all(_STRIP_TAG_NAMES):
        tag.decompose()

    for tag in soup.find_all(True):
        if not hasattr(tag, "attrs") or tag.attrs is None:
            continue
        classes = tag.get("class") or []
        class_str = " ".join(classes) if isinstance(classes, list) else str(classes)
        if any(frag in class_str for frag in _STRIP_CLASS_FRAGMENTS):
            tag.decompose()


def extract_content_from_html(html: str) -> str:
    """Extract main content from a Databricks docs HTML page and convert to markdown.

    Args:
        html: Raw HTML string of a docs.databricks.com page.

    Returns:
        Cleaned markdown string.
    """
    try:
        import markdownify  # noqa: PLC0415
    except ImportError as exc:
        raise ImportError("markdownify is required: pip install markdownify") from exc

    soup = BeautifulSoup(html, "html.parser")
    _strip_noise(soup)

    # Find the primary content container
    content_el: Optional[Tag] = None
    for selector in _CONTENT_SELECTORS:
        found = soup.find(**selector)  # type: ignore[arg-type]
        if found:
            content_el = found  # type: ignore[assignment]
            break

    target = str(content_el) if content_el else str(soup)

    md: str = markdownify.markdownify(
        target,
        heading_style="ATX",
        bullets="-",
        strip=["a"],
    )

    # Collapse excessive blank lines
    import re  # noqa: PLC0415
    md = re.sub(r"\n{3,}", "\n\n", md)
    return md.strip()


def extract_sections_from_html(html: str, section_titles: list[str]) -> str:
    """Extract specific sections from a Databricks docs HTML page.

    Finds <h2> elements whose text matches any of *section_titles*
    (case-insensitive) and returns those sections as a partial HTML
    string suitable for passing to ``extract_content_from_html``.

    Args:
        html: Raw HTML of the page.
        section_titles: Section headings to extract.

    Returns:
        HTML string containing only the matched sections.

    Raises:
        ValueError: If no matching sections are found.
    """
    soup = BeautifulSoup(html, "html.parser")
    _strip_noise(soup)

    lower_titles = {t.strip().lower() for t in section_titles}
    collected: list[str] = []

    for h2 in soup.find_all("h2"):
        # Strip zero-width spaces that Docusaurus appends to heading anchors
        heading_text = h2.get_text(strip=True).replace("\u200b", "").lower()
        if heading_text in lower_titles:
            section_html = str(h2)
            for sibling in h2.find_next_siblings():
                if sibling.name == "h2":
                    break
                section_html += str(sibling)
            collected.append(section_html)

    if not collected:
        matched = [h2.get_text(strip=True) for h2 in soup.find_all("h2")]
        available = ", ".join(f'"{t}"' for t in matched[:20])
        raise ValueError(
            f"No sections matched {section_titles!r}. "
            f"Available h2 headings: {available or '(none found)'}"
        )

    return "<div>" + "\n".join(collected) + "</div>"


def format_documentation_result(
    url: str,
    content: str,
    start_index: int,
    max_length: int,
) -> str:
    """Paginate documentation content and append a continuation hint if needed.

    Args:
        url: Source URL (used in the continuation hint).
        content: Full markdown content string.
        start_index: Character offset to start from.
        max_length: Maximum characters to return in this chunk.

    Returns:
        Content slice with optional continuation hint.
    """
    end_index = start_index + max_length
    chunk = content[start_index:end_index]

    if end_index < len(content):
        remaining = len(content) - end_index
        chunk += (
            f"\n\n---\n*Content truncated. "
            f"{remaining:,} characters remaining. "
            f"Call read_documentation with start_index={end_index} to continue.*"
        )

    return chunk


def is_html_content(page_raw: str, content_type: str) -> bool:
    """Return True if the response looks like HTML rather than plain text/JSON.

    Args:
        page_raw: Raw response body string.
        content_type: Value of the Content-Type response header.

    Returns:
        True if the content appears to be HTML.
    """
    return "text/html" in content_type.lower() or "<html" in page_raw[:200].lower()
