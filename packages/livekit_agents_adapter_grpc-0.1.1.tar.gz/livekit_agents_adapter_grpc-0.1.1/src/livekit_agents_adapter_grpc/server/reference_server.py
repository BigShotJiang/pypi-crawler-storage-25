"""Reference gRPC server implementing the AgentBridge service.

This is a template — users subclass ``AgentBridgeServicer`` or provide
their own agent function to handle turns.
"""

from __future__ import annotations

import logging
from typing import Any, AsyncGenerator, AsyncIterable, AsyncIterator, Protocol, TypeVar

import grpc
import grpc.aio

from livekit_agents_adapter_grpc.generated import (
    agent_bridge_pb2 as _pb2,  # type: ignore[attr-defined]
)
from livekit_agents_adapter_grpc.generated import (
    agent_bridge_pb2_grpc as _pb2_grpc,  # type: ignore[attr-defined]
)

pb2: Any = _pb2
pb2_grpc: Any = _pb2_grpc

logger = logging.getLogger("livekit_agents_adapter.grpc.server")

T = TypeVar("T")


class AgentHandler(Protocol):
    """Protocol for agent turn handlers."""

    def handle_turn(self, request: Any) -> AsyncGenerator[Any, None]:
        """Process a chat turn and yield responses."""
        ...


class EchoAgent:
    """A trivial agent that echoes back the last user message."""

    async def handle_turn(self, request: Any) -> AsyncGenerator[Any, None]:
        last_user_msg = ""
        for item in request.chat_history:
            if item.role == "user":
                last_user_msg = item.content

        if last_user_msg:
            yield pb2.ChatStreamResponse(
                text_chunk=pb2.TextChunkMessage(
                    content=f"Echo: {last_user_msg}",
                    is_final=True,
                )
            )
        yield pb2.ChatStreamResponse(done=pb2.DoneMessage())


class AgentBridgeServicer(pb2_grpc.AgentBridgeServicer):
    """gRPC servicer that delegates to an :class:`AgentHandler`.

    Args:
        agent: An object implementing the :class:`AgentHandler` protocol.
    """

    def __init__(self, agent: AgentHandler) -> None:
        self._agent = agent

    async def Chat(
        self,
        request_iterator: AsyncIterable[Any],
        context: grpc.aio.ServicerContext[Any, Any],
    ) -> AsyncIterator[Any]:
        async for req in request_iterator:
            msg_type = req.WhichOneof("message")
            if msg_type == "chat_request":
                async for resp in self._agent.handle_turn(req.chat_request):
                    yield resp
            elif msg_type == "tool_result":
                logger.warning("tool_result received — not yet supported")


async def serve(
    host: str = "0.0.0.0",
    port: int = 50051,
    *,
    agent: AgentHandler | None = None,
    credentials: grpc.ServerCredentials | None = None,
) -> tuple[grpc.aio.Server, int]:
    if agent is None:
        resolved_agent: AgentHandler = EchoAgent()
    else:
        resolved_agent = agent

    server = grpc.aio.server()
    servicer = AgentBridgeServicer(resolved_agent)
    pb2_grpc.add_AgentBridgeServicer_to_server(servicer, server)

    if credentials:
        actual_port = server.add_secure_port(f"{host}:{port}", credentials)
    else:
        actual_port = server.add_insecure_port(f"{host}:{port}")

    await server.start()
    return server, actual_port
