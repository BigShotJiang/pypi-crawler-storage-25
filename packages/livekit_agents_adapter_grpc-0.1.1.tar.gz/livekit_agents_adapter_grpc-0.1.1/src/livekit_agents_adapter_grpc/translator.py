"""gRPC Translator — bridges LiveKit to any external agent service via gRPC."""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterable

import grpc.aio

from livekit_agents_adapter.translators.base import Translator

from .generated import agent_bridge_pb2 as _pb2  # type: ignore[attr-defined]
from .generated import agent_bridge_pb2_grpc as pb2_grpc  # type: ignore[attr-defined]

pb2: Any = _pb2

logger = logging.getLogger("livekit_agents_adapter.grpc")


class ApikeyInterceptor(
    grpc.aio.UnaryStreamClientInterceptor,
    grpc.aio.StreamStreamClientInterceptor,
):
    """Appends an API key to every outgoing gRPC call's metadata."""

    def __init__(self, api_key: str) -> None:
        self._api_key = api_key

    def _inject_metadata(self, client_call_details: Any) -> Any:
        metadata = list(client_call_details.metadata or [])
        metadata.append(("authorization", f"Bearer {self._api_key}"))
        return client_call_details._replace(metadata=metadata)

    async def intercept_unary_stream(
        self,
        continuation: Any,
        client_call_details: Any,
        request: Any,
    ) -> Any:
        return await continuation(self._inject_metadata(client_call_details), request)

    async def intercept_stream_stream(
        self,
        continuation: Any,
        client_call_details: Any,
        request_iterator: Any,
    ) -> Any:
        return await continuation(
            self._inject_metadata(client_call_details),
            request_iterator,
        )


class GRPCTranslator(Translator):
    """Translator that connects to an external agent service via gRPC streaming.

    Sends LiveKit ``ChatContext`` and tool definitions as a ``ChatRequest``
    proto on each :meth:`invoke` call and yields
    :class:`~livekit_agents_adapter.TextChunk`,
    :class:`~livekit_agents_adapter.ToolCall`, and
    :class:`~livekit_agents_adapter.Done` responses from the remote stream.

    The gRPC channel is opened in :meth:`on_enter` and closed in
    :meth:`on_exit`, keeping it alive across turns for minimal latency.

    Args:
        host: gRPC server hostname.
        port: gRPC server port.
        api_key: Optional API key injected as a Bearer token via
            :class:`ApikeyInterceptor`.
        ssl_credentials: Optional channel credentials for TLS. If ``None``,
            an insecure channel is used.
        timeout: Per-call timeout in seconds.
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 50051,
        *,
        api_key: str | None = None,
        ssl_credentials: grpc.ChannelCredentials | None = None,
        timeout: float = 30.0,
    ) -> None:
        super().__init__()
        self._host = host
        self._port = port
        self._api_key = api_key
        self._ssl_credentials = ssl_credentials
        self._timeout = timeout

        self._channel: grpc.aio.Channel | None = None
        self._stub: pb2_grpc.AgentBridgeStub | None = None

        self._collected_tool_calls: list[dict[str, Any]] = []
        self._collected_text: str = ""
        self._last_synced_offset: int = 0

    def reset(self) -> None:
        """Reset per-turn state for a new session.

        Clears accumulated text, tool calls, and the sync offset so that
        conversation history does not bleed between sessions. The gRPC
        channel and stub are intentionally preserved — the connection is
        reused across sessions and is only closed in :meth:`on_exit`.
        """
        self._collected_tool_calls = []
        self._collected_text = ""
        self._last_synced_offset = 0

    async def on_enter(self) -> None:
        if self._stub is not None:
            return
        interceptors: list[Any] = []
        if self._api_key:
            interceptors.append(ApikeyInterceptor(self._api_key))

        target = f"{self._host}:{self._port}"
        if self._ssl_credentials:
            self._channel = grpc.aio.secure_channel(
                target,
                credentials=self._ssl_credentials,
                interceptors=interceptors or None,
            )
        else:
            self._channel = grpc.aio.insecure_channel(
                target,
                interceptors=interceptors or None,
            )
        self._stub = pb2_grpc.AgentBridgeStub(self._channel)

    async def on_exit(self) -> None:
        if self._channel is not None:
            await self._channel.close()
            self._channel = None
            self._stub = None

    async def to_external_chat_ctx(self, chat_ctx: Any) -> Any:
        from livekit.agents.llm.chat_context import ChatMessage, FunctionCall, FunctionCallOutput

        items: list[pb2.ChatItemMessage] = []
        for item in chat_ctx.items:
            if isinstance(item, ChatMessage):
                role = getattr(item, "role", "user")
                text = _extract_text(item)
                if text:
                    items.append(pb2.ChatItemMessage(role=role, content=text))
            elif isinstance(item, FunctionCall):
                args_str = getattr(item, "arguments", "{}")
                items.append(
                    pb2.ChatItemMessage(
                        role="assistant",
                        content=f"[tool_call:{getattr(item, 'name', '')}({args_str})]",
                        name=getattr(item, "name", ""),
                        call_id=getattr(item, "call_id", ""),
                    )
                )
            elif isinstance(item, FunctionCallOutput):
                items.append(
                    pb2.ChatItemMessage(
                        role="tool",
                        content=getattr(item, "output", ""),
                        call_id=getattr(item, "call_id", ""),
                    )
                )
        return items

    async def to_external_tools(self, tools: Any) -> Any:
        from livekit_agents_adapter.translators.chat_context import build_tools_dict

        raw_tools = build_tools_dict(tools)
        defs: list[pb2.ToolDefinition] = []
        for t in raw_tools:
            params = t.get("parameters", {})
            defs.append(
                pb2.ToolDefinition(
                    name=t.get("name", ""),
                    description=t.get("description", ""),
                    parameters=json.dumps(params),
                )
            )
        return defs

    async def invoke(self, chat_ctx: Any, tools: Any) -> Any:
        from livekit_agents_adapter import Done, TextChunk, ToolCall

        if self._stub is None:
            yield Done(
                metadata={
                    "error": "NOT_CONNECTED",
                    "error_message": "gRPC stub not initialized",
                }
            )
            return

        self._collected_tool_calls = []
        self._collected_text = ""

        chat_request = pb2.ChatRequest(
            chat_history=chat_ctx,
            tools=tools,
            session_id="",
        )
        stream_req = pb2.ChatStreamRequest(chat_request=chat_request)

        async def _request_iterator() -> AsyncIterable[pb2.ChatStreamRequest]:
            yield stream_req

        try:
            call = self._stub.Chat(_request_iterator(), timeout=self._timeout)
            async for resp in call:
                msg_type = resp.WhichOneof("message")
                if msg_type == "text_chunk":
                    chunk = resp.text_chunk
                    self._collected_text += chunk.content
                    yield TextChunk(content=chunk.content, is_final=chunk.is_final)

                elif msg_type == "tool_call":
                    tc = resp.tool_call
                    args: dict[str, Any] = {}
                    if tc.arguments:
                        try:
                            args = json.loads(tc.arguments)
                        except json.JSONDecodeError:
                            args = {"_raw": tc.arguments}
                    self._collected_tool_calls.append(
                        {"name": tc.name, "arguments": args, "call_id": tc.call_id}
                    )
                    yield ToolCall(name=tc.name, arguments=args, call_id=tc.call_id)

                elif msg_type == "done":
                    yield Done(metadata=dict(resp.done.metadata))

                elif msg_type == "error":
                    err = resp.error
                    logger.error("Agent service error [%s]: %s", err.code, err.message)
                    yield Done(metadata={"error_code": err.code, "error_message": err.message})
                    return

        except grpc.aio.AioRpcError as e:
            logger.error("gRPC call failed: %s", e, exc_info=True)
            yield Done(
                metadata={
                    "error_code": e.code().name if e.code() else "UNKNOWN",
                    "error_message": str(e.details()) if e.details() else str(e),
                }
            )

    async def sync_back_messages(self, chat_ctx: Any) -> list[Any]:
        from livekit.agents.llm.chat_context import ChatMessage, FunctionCall

        new_items: list[Any] = []

        if self._collected_text:
            new_items.append(ChatMessage(role="assistant", content=[self._collected_text]))

        for tc in self._collected_tool_calls[self._last_synced_offset :]:
            args = tc.get("arguments", {})
            args_str = json.dumps(args) if isinstance(args, dict) else str(args)
            new_items.append(
                FunctionCall(
                    call_id=tc.get("call_id", ""),
                    name=tc.get("name", ""),
                    arguments=args_str,
                )
            )

        self._last_synced_offset = len(self._collected_tool_calls)
        return new_items


def _extract_text(item: Any) -> str:
    content = getattr(item, "content", "")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return " ".join(str(p) if isinstance(p, str) else str(p) for p in content)
    return str(content)
