# Changelog

## 0.1.0 (2026-03-27)

Full Changelog: [v0.0.2...v0.1.0](https://github.com/jssfy/stainless-sdk-demo/compare/v0.0.2...v0.1.0)

### Features

* **api:** manual updates ([27a2900](https://github.com/jssfy/stainless-sdk-demo/commit/27a2900b726c9bb981196573d3bf9a952c53be0b))
* **client:** add support for binary request streaming ([0b15a0f](https://github.com/jssfy/stainless-sdk-demo/commit/0b15a0fea5a140f688d3e9be0603bcb1a3f00f7f))


### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([305cb97](https://github.com/jssfy/stainless-sdk-demo/commit/305cb9765553039293203f74133d6d145c0c220a))
* **internal:** codegen related update ([4c4beba](https://github.com/jssfy/stainless-sdk-demo/commit/4c4beba5f4cf1bd85c870ea693feaabfed53494f))
* **internal:** codegen related update ([ca06ef5](https://github.com/jssfy/stainless-sdk-demo/commit/ca06ef5eb79bd044e45e06daf0562e814a7909e3))
* **internal:** codegen related update ([a1c022b](https://github.com/jssfy/stainless-sdk-demo/commit/a1c022b4ca2f7488e2af3feb8fb419edfc8bb602))
* **internal:** codegen related update ([247dc6a](https://github.com/jssfy/stainless-sdk-demo/commit/247dc6a762f3e9785c0fa52b1783afc463f1adab))
* **internal:** codegen related update ([3c5d111](https://github.com/jssfy/stainless-sdk-demo/commit/3c5d11110e530c34f9ec9e69b53833029cd515b5))
* **internal:** codegen related update ([447df63](https://github.com/jssfy/stainless-sdk-demo/commit/447df6318c0c48cb591201db74db23bcb9e65fdf))
* **internal:** update `actions/checkout` version ([4c199b7](https://github.com/jssfy/stainless-sdk-demo/commit/4c199b7fbd5965b5eef18b0f01f758b64b9541d4))

## 0.0.2 (2026-01-12)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/jssfy/stainless-sdk-demo/compare/v0.0.1...v0.0.2)

### Chores

* update SDK settings ([6f7530e](https://github.com/jssfy/stainless-sdk-demo/commit/6f7530e3fc2199800ce03b2cb3876efe5e65eee8))
* update SDK settings ([f7e897b](https://github.com/jssfy/stainless-sdk-demo/commit/f7e897b1a2b0df0e50b1c2c569715748250a851e))
