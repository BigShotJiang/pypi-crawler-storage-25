"""Load assets (fonts, SVGs) and encode them for inline HTML embedding."""

from __future__ import annotations

import base64
from pathlib import Path
from functools import lru_cache

ASSETS_DIR = Path(__file__).parent / "assets"
ICONS_DIR = ASSETS_DIR / "icons"
FONTS_DIR = ASSETS_DIR / "fonts"


@lru_cache(maxsize=None)
def font_base64(filename: str) -> str:
    """Return base64-encoded font data."""
    p = FONTS_DIR / filename
    if p.exists():
        return base64.b64encode(p.read_bytes()).decode()
    raise FileNotFoundError(f"Font not found: {filename}")


@lru_cache(maxsize=None)
def codicon_font_base64() -> str:
    """Return base64-encoded codicon.ttf."""
    p = ASSETS_DIR / "codicon.ttf"
    return base64.b64encode(p.read_bytes()).decode()


@lru_cache(maxsize=None)
def svg_data_uri(name: str) -> str:
    """Return data URI for an SVG icon."""
    p = ICONS_DIR / f"{name}.svg"
    if not p.exists():
        p = ICONS_DIR / "file.svg"
    svg_content = p.read_bytes()
    b64 = base64.b64encode(svg_content).decode()
    return f"data:image/svg+xml;base64,{b64}"


@lru_cache(maxsize=None)
def svg_inline(name: str) -> str:
    """Return raw SVG content for inline embedding."""
    p = ICONS_DIR / f"{name}.svg"
    if not p.exists():
        p = ICONS_DIR / "file.svg"
    return p.read_text(encoding="utf-8")


@lru_cache(maxsize=None)
def vscode_logo_data_uri() -> str:
    """Return data URI for VS Code logo."""
    p = ASSETS_DIR / "vscode-logo.svg"
    svg_content = p.read_bytes()
    b64 = base64.b64encode(svg_content).decode()
    return f"data:image/svg+xml;base64,{b64}"


# Map file extensions to Material Icon Theme SVG names
EXT_TO_ICON = {
    ".py": "python",
    ".js": "javascript",
    ".jsx": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".html": "html",
    ".htm": "html",
    ".css": "css",
    ".scss": "css",
    ".sass": "css",
    ".less": "css",
    ".json": "json",
    ".md": "markdown",
    ".mdx": "markdown",
    ".yml": "yaml",
    ".yaml": "yaml",
    ".toml": "toml",
    ".xml": "xml",
    ".svg": "svg",
    ".java": "java",
    ".c": "c",
    ".h": "c",
    ".cpp": "cpp",
    ".hpp": "cpp",
    ".cc": "cpp",
    ".rs": "rust",
    ".go": "go",
    ".sh": "bash",
    ".bash": "bash",
    ".zsh": "bash",
    ".lock": "lock",
    ".png": "image",
    ".jpg": "image",
    ".jpeg": "image",
    ".gif": "image",
    ".ico": "image",
    ".webp": "image",
    ".ttf": "font",
    ".otf": "font",
    ".woff": "font",
    ".woff2": "font",
    ".sql": "database",
    ".db": "database",
    ".sqlite": "database",
}

# Map exact filenames to icons
FILENAME_TO_ICON = {
    ".gitignore": "git",
    ".gitmodules": "git",
    ".gitattributes": "git",
    "dockerfile": "docker",
    "Dockerfile": "docker",
    "docker-compose.yml": "docker",
    "docker-compose.yaml": "docker",
    ".dockerignore": "docker",
    ".eslintrc": "eslint",
    ".eslintrc.js": "eslint",
    ".eslintrc.json": "eslint",
    "eslint.config.js": "eslint",
    "eslint.config.mjs": "eslint",
    ".prettierrc": "prettier",
    ".prettierrc.json": "prettier",
    "prettier.config.js": "prettier",
    "package.json": "npm",
    "package-lock.json": "lock",
    "yarn.lock": "lock",
    "pnpm-lock.yaml": "lock",
    "README.md": "readme",
    "readme.md": "readme",
    "LICENSE": "license",
    "LICENSE.md": "license",
    "webpack.config.js": "webpack",
    "rollup.config.js": "rollup",
    "vite.config.js": "vite",
    "vite.config.ts": "vite",
    "Makefile": "makefile",
    "makefile": "makefile",
}

# Map folder names to Material Icon Theme folder icons
FOLDER_TO_ICON = {
    # Source code
    "src": "folder-src",
    "source": "folder-src",
    "lib": "folder-src",
    "libs": "folder-src",
    "packages": "folder-src",
    # Distribution / build
    "dist": "folder-dist",
    "build": "folder-dist",
    "out": "folder-dist",
    "output": "folder-dist",
    "bin": "folder-dist",
    "target": "folder-dist",
    # Node
    "node_modules": "folder-node",
    # Tests
    "test": "folder-test",
    "tests": "folder-test",
    "__tests__": "folder-test",
    "spec": "folder-test",
    "specs": "folder-test",
    "e2e": "folder-test",
    "cypress": "folder-test",
    "__pycache__": "folder-test",
    # Documentation
    "docs": "folder-docs",
    "doc": "folder-docs",
    "documentation": "folder-docs",
    "wiki": "folder-docs",
    # Config
    "config": "folder-config",
    "conf": "folder-config",
    ".config": "folder-config",
    "settings": "folder-config",
    ".vscode": "folder-config",
    ".idea": "folder-config",
    ".claude": "folder-config",
    # API
    "api": "folder-api",
    "apis": "folder-api",
    "endpoints": "folder-api",
    "routes": "folder-api",
    "router": "folder-api",
    # App
    "app": "folder-app",
    "apps": "folder-app",
    "application": "folder-app",
    # Assets / resources
    "assets": "folder-assets",
    "resource": "folder-assets",
    "resources": "folder-assets",
    "res": "folder-assets",
    "static": "folder-assets",
    "public": "folder-assets",
    "media": "folder-assets",
    # Components
    "components": "folder-components",
    "component": "folder-components",
    "widgets": "folder-components",
    "ui": "folder-components",
    "elements": "folder-components",
    # Styles
    "styles": "folder-styles",
    "style": "folder-styles",
    "css": "folder-styles",
    "scss": "folder-styles",
    "sass": "folder-styles",
    "less": "folder-styles",
    # Images
    "images": "folder-images",
    "image": "folder-images",
    "img": "folder-images",
    "icons": "folder-images",
    "icon": "folder-images",
    "textures": "folder-images",
    "screenshots": "folder-images",
    # Fonts
    "fonts": "folder-fonts",
    "font": "folder-fonts",
    # Scripts
    "scripts": "folder-scripts",
    "script": "folder-scripts",
    "tools": "folder-scripts",
    "utils": "folder-scripts",
    "utilities": "folder-scripts",
    "helpers": "folder-scripts",
    "hooks": "folder-scripts",
    # Templates
    "templates": "folder-templates",
    "template": "folder-templates",
    "layouts": "folder-templates",
    "layout": "folder-templates",
    "views": "folder-templates",
    "pages": "folder-templates",
    # Database
    "database": "folder-database",
    "db": "folder-database",
    "migrations": "folder-database",
    "sql": "folder-database",
    "seeds": "folder-database",
    # Git
    ".git": "folder-git",
    ".github": "folder-git",
    ".gitlab": "folder-git",
    # Docker
    "docker": "folder-docker",
    ".docker": "folder-docker",
    # Server
    "server": "folder-server",
    "backend": "folder-server",
    "services": "folder-server",
    "service": "folder-server",
    "middleware": "folder-server",
    # Client
    "client": "folder-client",
    "frontend": "folder-client",
    "web": "folder-client",
    # Examples
    "examples": "folder-examples",
    "example": "folder-examples",
    "samples": "folder-examples",
    "demo": "folder-examples",
    "demos": "folder-examples",
    # Python
    "venv": "folder-config",
    ".venv": "folder-config",
    "env": "folder-config",
    ".env": "folder-config",
    "__pycache__": "folder-dist",
    # Miscellaneous
    "vendor": "folder-node",
    "tmp": "folder-dist",
    "temp": "folder-dist",
    "cache": "folder-dist",
    ".cache": "folder-dist",
    "logs": "folder-docs",
    "log": "folder-docs",
    "i18n": "folder-config",
    "locales": "folder-config",
    "locale": "folder-config",
    "lang": "folder-config",
    "plugins": "folder-app",
    "modules": "folder-src",
    "models": "folder-database",
    "model": "folder-database",
    "schemas": "folder-database",
    "types": "folder-src",
    "interfaces": "folder-src",
    "contexts": "folder-app",
    "store": "folder-app",
    "stores": "folder-app",
    "state": "folder-app",
    "redux": "folder-app",
    "actions": "folder-app",
    "reducers": "folder-app",
    "selectors": "folder-app",
    "features": "folder-app",
    "guards": "folder-config",
    "interceptors": "folder-config",
    "pipes": "folder-config",
    "decorators": "folder-config",
    "validators": "folder-config",
    "html_templates": "folder-templates",
    "mockshot": "folder-app",
    "syntax": "folder-src",
    "themes": "folder-styles",
}


def icon_for_file(filename: str) -> str:
    """Return SVG data URI for a filename based on extension."""
    # Check exact filename first
    if filename in FILENAME_TO_ICON:
        return svg_data_uri(FILENAME_TO_ICON[filename])
    # Then check extension
    ext = Path(filename).suffix.lower()
    if filename.startswith("."):
        icon_name = FILENAME_TO_ICON.get(filename, EXT_TO_ICON.get(filename, "file"))
    else:
        icon_name = EXT_TO_ICON.get(ext, "file")
    return svg_data_uri(icon_name)


def icon_for_folder(folder_name: str = "", opened: bool = False) -> str:
    """Return SVG data URI for a folder icon based on folder name."""
    base = FOLDER_TO_ICON.get(folder_name.lower(), "folder")
    if opened:
        # Try the -open variant, fall back to generic folder-open
        open_name = f"{base}-open"
        p = ICONS_DIR / f"{open_name}.svg"
        if p.exists():
            return svg_data_uri(open_name)
        return svg_data_uri("folder-open")
    return svg_data_uri(base)
