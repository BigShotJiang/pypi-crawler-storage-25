"""mockshot — Pixel-perfect fake screenshot generator."""

__version__ = "1.0.0"
