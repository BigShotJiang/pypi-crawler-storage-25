"""Scanner — generate VS Code project JSON from a real directory."""

from __future__ import annotations

import json
from pathlib import Path

# Directories to always skip
SKIP_DIRS = {
    "__pycache__", ".git", ".hg", ".svn", "node_modules", ".venv", "venv",
    "env", ".env", ".tox", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "dist", "build", ".eggs", "*.egg-info", ".idea", ".claude",
}

# Extensions to skip (binary/generated)
SKIP_EXTS = {
    ".pyc", ".pyo", ".so", ".o", ".a", ".dylib", ".dll", ".exe",
    ".class", ".jar", ".war",
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".webp", ".bmp", ".svg",
    ".ttf", ".otf", ".woff", ".woff2", ".eot",
    ".zip", ".tar", ".gz", ".bz2", ".xz", ".rar", ".7z",
    ".db", ".sqlite", ".sqlite3",
    ".mp3", ".mp4", ".wav", ".avi", ".mov",
    ".pdf", ".doc", ".docx", ".xls", ".xlsx",
}

# Extension to language mapping
EXT_TO_LANG = {
    ".py": "python", ".js": "javascript", ".jsx": "javascript",
    ".ts": "typescript", ".tsx": "typescript",
    ".html": "html", ".htm": "html", ".css": "css",
    ".json": "json", ".md": "markdown",
    ".sh": "bash", ".bash": "bash", ".zsh": "bash",
    ".java": "java", ".c": "c", ".h": "c",
    ".cpp": "cpp", ".cc": "cpp", ".hpp": "cpp",
    ".rs": "rust", ".go": "go",
    ".yml": "yaml", ".yaml": "yaml",
    ".toml": "toml", ".xml": "xml", ".sql": "sql",
    ".rb": "ruby", ".php": "php", ".swift": "swift",
    ".kt": "kotlin", ".scala": "scala",
}


def _should_skip_dir(name: str) -> bool:
    """Check if a directory should be skipped."""
    if name.startswith(".") and name not in (".github", ".vscode", ".gitignore"):
        return True
    return name in SKIP_DIRS or name.endswith(".egg-info")


def _should_skip_file(name: str) -> bool:
    """Check if a file should be skipped."""
    ext = Path(name).suffix.lower()
    return ext in SKIP_EXTS


def _scan_dir(directory: Path, max_depth: int = 4, depth: int = 0) -> list[dict]:
    """Recursively scan a directory into a tree structure."""
    if depth > max_depth:
        return []

    entries = []
    try:
        items = sorted(directory.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
    except PermissionError:
        return []

    dirs = []
    files = []

    for item in items:
        if item.is_dir():
            if not _should_skip_dir(item.name):
                dirs.append(item)
        elif item.is_file():
            if not _should_skip_file(item.name):
                files.append(item)

    # Add directories first
    for d in dirs:
        children = _scan_dir(d, max_depth, depth + 1)
        entry = {
            "name": d.name,
            "open": depth < 2,  # auto-open first 2 levels
            "children": children,
        }
        entries.append(entry)

    # Then files
    for f in files:
        entries.append({"name": f.name})

    return entries


def scan_project(
    directory: str | Path,
    active_file: str | None = None,
    git_branch: str = "main",
    visible_lines: tuple[int, int] | None = None,
    max_depth: int = 4,
) -> dict:
    """Scan a directory and generate a VS Code project JSON structure.

    Args:
        directory: Path to the project root directory
        active_file: Relative path to the file to show in the editor (optional)
        git_branch: Git branch name for the status bar
        visible_lines: Tuple of (start, end) line numbers to show
        max_depth: Maximum directory depth to scan

    Returns:
        dict: Project JSON structure ready for mockshot vscode --project
    """
    root = Path(directory).resolve()
    if not root.is_dir():
        raise click.BadParameter(f"Not a directory: {root}")

    tree = _scan_dir(root, max_depth)

    project = {
        "root": root.name,
        "git_branch": git_branch,
        "tree": tree,
    }

    # If active_file is specified, add it
    if active_file:
        active_path = root / active_file
        if active_path.exists():
            ext = active_path.suffix.lower()
            lang = EXT_TO_LANG.get(ext, "text")

            project["active_file"] = {
                "name": active_path.name,
                "language": lang,
                "content_path": str(active_path),
            }

            if visible_lines:
                project["active_file"]["visible_lines"] = list(visible_lines)

            # Auto-generate tabs from sibling files in same directory
            siblings = [
                f.name for f in active_path.parent.iterdir()
                if f.is_file() and not _should_skip_file(f.name)
            ]
            # Keep max 5 tabs, with active file included
            tabs = [active_path.name]
            for s in sorted(siblings):
                if s != active_path.name and len(tabs) < 5:
                    tabs.append(s)
            project["tabs"] = tabs

    return project


# Import click here to avoid circular import at module level
import click
