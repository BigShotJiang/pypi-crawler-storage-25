"""Layout engine for diagrams — Hybrid Sugiyama/Force-directed + A* routing.

CHANGELOG v2:
  Fix 1 — Segments port→stub : stubs adaptatifs (longueur = distance au nœud le
           plus proche sur cet axe), tous les segments sont vérifiés contre les
           obstacles et redirigés si nécessaire.
  Fix 2 — Trop de coudes : astar_bend_cost passé à 15, nouveau pass de
           post-processing _straighten_path() qui fusionne les segments colinéaires
           et tente de remplacer 2 segments par 1 ligne droite quand possible.
  Fix 3 — Compacité : coût bbox × 0.008 (×8), attraction ×1.5, gap réduit,
           SA démarre avec une disposition plus serrée.
  Fix 4 — 0 lignes droites : _try_direct_route() tente en premier une ligne
           parfaitement droite (même X ou même Y), puis L-route à 1 coude,
           avant de lancer A*.
  Fix 5 — Croisements : crossing_edge=800, ordre de routage amélioré (on route
           d'abord les paires de nœuds les plus proches pour minimiser la
           longueur globale), nudging orthogonal des segments qui se croisent.
"""

from __future__ import annotations

import math
import heapq
import random
from collections import deque
from dataclasses import dataclass, field


@dataclass
class Node:
    """A rectangular node in the diagram."""
    name: str
    x: float = 0.0
    y: float = 0.0
    w: float = 100.0
    h: float = 60.0

    @property
    def cx(self) -> float:
        return self.x + self.w / 2

    @property
    def cy(self) -> float:
        return self.y + self.h / 2

    @property
    def right(self) -> float:
        return self.x + self.w

    @property
    def bottom(self) -> float:
        return self.y + self.h

    def overlaps(self, other: "Node", margin: float = 0) -> bool:
        return not (self.right + margin <= other.x or
                    other.right + margin <= self.x or
                    self.bottom + margin <= other.y or
                    other.bottom + margin <= self.y)

    def contains_point(self, px: float, py: float, margin: float = 5) -> bool:
        return (self.x - margin <= px <= self.right + margin and
                self.y - margin <= py <= self.bottom + margin)


@dataclass
class Edge:
    """A connection between two nodes."""
    from_node: str
    to_node: str
    points: list[tuple[float, float]] = field(default_factory=list)


# ════════════════════════════════════════════════════════════
#  Default parameters
# ════════════════════════════════════════════════════════════

DEFAULT_PARAMS = {
    "collision_node": 50000,
    # Fix 5 — croisements : penalty beaucoup plus forte
    "crossing_edge": 800,
    # Fix 2 — coudes : bend_cost augmenté
    "bend_cost": 60,
    "side_flyover": 2000,
    "straight_bonus": 100,
    "closest_side_bonus": 60,
    "attraction": 0.45,
    "repulsion": 2.0,
    "gap_multiplier": 0.8,    # v3: plus d'espace entre nœuds
    "temp_decay": 0.95,
    # Fix 2 — coudes A* : coût de virage beaucoup plus élevé
    "astar_bend_cost": 15,
    "obstacle_margin": 40,    # v3: marge obstacle doublée (était 28)
    # Simulated Annealing params
    "sa_iterations": 400,
    "sa_cooling": 0.97,
    # Rip-up & Reroute
    "reroute_passes": 6,
    "bbox_cost": 0.004,       # v3: moins de compression au centre (était 0.008)
    "stub_base": 50,          # v4: stubs plus longs pour plus d'espace
    "stub_max": 120,          # v4: stubs max plus longs
}

GRID_SNAP = 20


# ════════════════════════════════════════════════════════════
#  Phase 1 — Node placement (Graphviz Sugiyama via `dot`)
# ════════════════════════════════════════════════════════════

def _graphviz_layout(nodes: list[Node], edges: list[Edge],
                     margin: float = 80, gap: float = 60,
                     engine: str = "dot") -> bool:
    """Use Graphviz to compute node positions.
    engine='dot' for hierarchical (UML), 'neato' for force-directed (MCD).
    Returns True on success, False if Graphviz is not available."""
    import subprocess, json as _json, shutil

    if not shutil.which(engine):
        return False

    if engine in ("neato", "fdp"):
        # Non-directed graph for force-directed layout
        lines = ['graph G {']
        lines.append('  graph [overlap=false, sep="+60", splines=false, pad="1.0"];')
        lines.append('  node [shape=box];')

        def _nid(name: str) -> str:
            return '"' + name.replace('"', '\\"') + '"'

        for nd in nodes:
            w_in = nd.w / 72
            h_in = nd.h / 72
            lines.append('  %s [width=%.3f, height=%.3f, fixedsize=true];' % (
                _nid(nd.name), w_in, h_in))

        seen = set()
        for e in edges:
            key = tuple(sorted([e.from_node, e.to_node]))
            if key not in seen:
                seen.add(key)
                # Edge length proportional to gap for better spacing
                lines.append('  %s -- %s [len=%.1f];' % (
                    _nid(e.from_node), _nid(e.to_node), gap / 20))

        lines.append('}')
    else:
        # Directed graph for hierarchical layout (dot)
        lines = ['digraph G {']
        lines.append('  graph [rankdir=TB, nodesep=%.2f, ranksep=%.2f];' % (
            (gap + 30) / 72, (gap + 50) / 72))
        lines.append('  node [shape=box];')

        def _nid(name: str) -> str:
            return '"' + name.replace('"', '\\"') + '"'

        for nd in nodes:
            w_in = nd.w / 72
            h_in = nd.h / 72
            lines.append('  %s [width=%.3f, height=%.3f, fixedsize=true];' % (
                _nid(nd.name), w_in, h_in))

        seen = set()
        for e in edges:
            key = (e.from_node, e.to_node)
            if key not in seen:
                seen.add(key)
                lines.append('  %s -> %s;' % (_nid(e.from_node), _nid(e.to_node)))

        lines.append('}')

    dot_src = '\n'.join(lines)

    try:
        proc = subprocess.run(
            [engine, '-Tjson'],
            input=dot_src, capture_output=True, text=True, timeout=10)
        if proc.returncode != 0:
            return False

        data = _json.loads(proc.stdout)
    except (subprocess.TimeoutExpired, _json.JSONDecodeError, FileNotFoundError):
        return False

    # Parse positions from Graphviz JSON output
    node_map = {nd.name: nd for nd in nodes}
    gv_nodes = data.get("objects", [])

    for gv_nd in gv_nodes:
        name = gv_nd.get("name", "")
        if name not in node_map:
            continue
        pos_str = gv_nd.get("pos", "")
        if not pos_str:
            continue
        # pos format: "x,y" in points (72 DPI)
        parts = pos_str.split(",")
        if len(parts) >= 2:
            gx = float(parts[0])
            gy = float(parts[1])
            nd = node_map[name]
            # Graphviz Y is bottom-up, we want top-down
            nd.x = gx - nd.w / 2
            nd.y = gy - nd.h / 2  # will be flipped below

    # Flip Y axis (Graphviz Y=0 is bottom)
    if nodes:
        max_y = max(nd.y + nd.h for nd in nodes)
        for nd in nodes:
            nd.y = max_y - nd.y - nd.h

    return True


def layout_nodes(nodes: list[Node], edges: list[Edge],
                 margin: float = 80, gap: float = 60,
                 iterations: int = 80, params: dict | None = None,
                 engine: str = "dot") -> None:
    """Place nodes using Graphviz layout.
    engine='dot' for hierarchical (UML), 'neato' for force-directed (MCD).
    Falls back to BFS-layered + force refinement if Graphviz unavailable."""
    p = dict(DEFAULT_PARAMS)
    if params:
        p.update(params)

    if len(nodes) <= 1:
        if nodes:
            nodes[0].x = margin
            nodes[0].y = margin
        return

    # ── Try Graphviz first ──
    if _graphviz_layout(nodes, edges, margin, gap, engine=engine):
        # Recentre with margin
        min_x = min(nd.x for nd in nodes)
        min_y = min(nd.y for nd in nodes)
        for nd in nodes:
            nd.x += margin - min_x
            nd.y += margin - min_y
        _snap_to_grid(nodes, GRID_SNAP)
        return

    # ── Fallback: BFS-layered + force refinement ──
    node_map = {n.name: n for n in nodes}
    adj: dict[str, set[str]] = {n.name: set() for n in nodes}
    for e in edges:
        if e.from_node in adj and e.to_node in adj:
            adj[e.from_node].add(e.to_node)
            adj[e.to_node].add(e.from_node)

    hub = max(nodes, key=lambda nd: len(adj[nd.name]))
    levels: dict[str, int] = {hub.name: 0}
    queue = deque([hub.name])
    while queue:
        name = queue.popleft()
        for nb in sorted(adj[name], key=lambda nb: -len(adj[nb])):
            if nb not in levels:
                levels[nb] = levels[name] + 1
                queue.append(nb)
    max_level = max(levels.values()) if levels else 0
    for nd in nodes:
        if nd.name not in levels:
            levels[nd.name] = max_level + 1

    level_groups: dict[int, list[str]] = {}
    for name, lv in levels.items():
        level_groups.setdefault(lv, []).append(name)
    for lv in level_groups:
        level_groups[lv].sort(key=lambda n: -len(adj[n]))

    max_w = max(nd.w for nd in nodes)
    max_h = max(nd.h for nd in nodes)
    col_w = max_w + gap
    row_h = max_h + gap
    max_per_row = max(len(grp) for grp in level_groups.values())
    total_w = max_per_row * col_w

    for lv, group in sorted(level_groups.items()):
        n_in_row = len(group)
        row_w = n_in_row * col_w
        x_start = margin + (total_w - row_w) / 2
        y = margin + lv * row_h
        for i, name in enumerate(group):
            nd = node_map[name]
            nd.x = x_start + i * col_w
            nd.y = y

    _force_refinement(nodes, adj, node_map, gap, iterations=200)
    _resolve_overlaps(nodes, gap)

    min_x = min(nd.x for nd in nodes)
    min_y = min(nd.y for nd in nodes)
    for nd in nodes:
        nd.x += margin - min_x
        nd.y += margin - min_y
    _resolve_overlaps(nodes, gap)
    _snap_to_grid(nodes, GRID_SNAP)


def _force_refinement(nodes: list[Node], adj: dict[str, set[str]],
                      node_map: dict[str, Node], gap: float,
                      iterations: int = 200) -> None:
    """Light force-directed refinement: attract neighbors, repel all."""
    ideal_dist = max(nd.w for nd in nodes) + gap

    for step in range(iterations):
        cooling = 1.0 - step / iterations
        move_scale = ideal_dist * 0.15 * cooling

        forces = {nd.name: [0.0, 0.0] for nd in nodes}

        # Repulsion between all nodes
        for i, a in enumerate(nodes):
            for b in nodes[i + 1:]:
                dx = a.cx - b.cx
                dy = a.cy - b.cy
                dist = math.hypot(dx, dy) or 1.0
                if dist < ideal_dist * 2:
                    f = (ideal_dist * 2 - dist) / dist * 0.5
                    forces[a.name][0] += dx * f
                    forces[a.name][1] += dy * f
                    forces[b.name][0] -= dx * f
                    forces[b.name][1] -= dy * f

        # Attraction between connected neighbors
        for name, neighbors in adj.items():
            a = node_map[name]
            for nb_name in neighbors:
                b = node_map[nb_name]
                dx = b.cx - a.cx
                dy = b.cy - a.cy
                dist = math.hypot(dx, dy) or 1.0
                if dist > ideal_dist:
                    f = (dist - ideal_dist) / dist * 0.3
                    forces[name][0] += dx * f
                    forces[name][1] += dy * f

        # Apply forces with damping
        for nd in nodes:
            fx, fy = forces[nd.name]
            mag = math.hypot(fx, fy) or 1.0
            scale = min(mag, move_scale) / mag
            nd.x += fx * scale
            nd.y += fy * scale


def _resolve_overlaps(nodes: list[Node], gap: float) -> None:
    """Push overlapping nodes apart."""
    margin_between = gap * 0.5  # v3: marge plus large (était 0.3)
    for _ in range(60):
        moved = False
        for i, a in enumerate(nodes):
            for b in nodes[i + 1:]:
                if a.overlaps(b, margin_between):
                    dx = a.cx - b.cx
                    dy = a.cy - b.cy
                    overlap_x = (a.w + b.w) / 2 + margin_between - abs(dx)
                    overlap_y = (a.h + b.h) / 2 + margin_between - abs(dy)
                    if overlap_x < overlap_y:
                        shift = overlap_x / 2 + 1
                        if dx >= 0:
                            a.x += shift; b.x -= shift
                        else:
                            a.x -= shift; b.x += shift
                    else:
                        shift = overlap_y / 2 + 1
                        if dy >= 0:
                            a.y += shift; b.y -= shift
                        else:
                            a.y -= shift; b.y += shift
                    moved = True
        if not moved:
            break

    min_x = min(n.x for n in nodes)
    min_y = min(n.y for n in nodes)
    if min_x < 40:
        for n in nodes:
            n.x += 40 - min_x
    if min_y < 40:
        for n in nodes:
            n.y += 40 - min_y


def _snap_to_grid(nodes: list[Node], grid: int = 40) -> None:
    for n in nodes:
        n.x = round(n.x / grid) * grid
        n.y = round(n.y / grid) * grid


# ════════════════════════════════════════════════════════════
#  Phase 2 — A* Orthogonal Edge Routing
# ════════════════════════════════════════════════════════════

def route_edges(nodes: list[Node], edges: list[Edge],
                params: dict | None = None) -> None:
    """Route edges with orthogonal paths avoiding all obstacles."""
    p = dict(DEFAULT_PARAMS)
    if params:
        p.update(params)

    node_map = {n.name: n for n in nodes}
    all_rects = [(n.x, n.y, n.w, n.h, n.name) for n in nodes]
    SIDES = ("top", "bottom", "left", "right")
    GRID = 10

    # ── Fix 1 : stub adaptatif ──────────────────────────────
    def _adaptive_stub_len(node: Node, side: str, obstacles: list) -> float:
        """Calcule une longueur de stub qui évite le nœud le plus proche
        sur l'axe perpendiculaire au côté."""
        base = p.get("stub_base", 20)
        stub_max = p.get("stub_max", 60)
        dx, dy = _side_direction(side)
        port = _port_at(node, side, 0.5)

        # Cherche l'obstacle le plus proche dans la direction du stub
        min_dist = stub_max
        for ox, oy, ow, oh in obstacles:
            # Boîte englobante dans la direction
            if dx != 0:
                dist = (ox - port[0]) * dx  # positif si dans la bonne direction
                if dist <= 0:
                    continue
                # bande verticale élargie (pas juste le nœud source)
                if oy - 20 < port[1] < oy + oh + 20:
                    min_dist = min(min_dist, dist)
            else:
                # Déplacement vertical
                if dy > 0:
                    edge_y = oy
                    dist = edge_y - port[1]
                else:
                    edge_y = oy + oh
                    dist = port[1] - edge_y
                if dist <= 0:
                    continue
                if ox < node.right + 10 and ox + ow > node.x - 10:
                    min_dist = min(min_dist, dist)

        # Le stub s'arrête à mi-chemin de l'obstacle le plus proche
        # avec un minimum de base
        stub_len = max(base, min(min_dist * 0.5, stub_max))
        return stub_len

    def _stub_point(node: Node, port: tuple, side: str, obstacles: list) -> tuple:
        """Stub point adaptatif, snappé sur la grille, garanti hors de la boîte."""
        stub_len = _adaptive_stub_len(node, side, obstacles)
        d = _side_direction(side)
        sx = port[0] + d[0] * stub_len
        sy = port[1] + d[1] * stub_len
        sx = round(sx / GRID) * GRID
        sy = round(sy / GRID) * GRID
        # v3: garantir que le stub est bien HORS de la boîte source
        margin = 8
        if side == "top" and sy > node.y - margin:
            sy = round((node.y - stub_len) / GRID) * GRID
        elif side == "bottom" and sy < node.bottom + margin:
            sy = round((node.bottom + stub_len) / GRID) * GRID
        elif side == "left" and sx > node.x - margin:
            sx = round((node.x - stub_len) / GRID) * GRID
        elif side == "right" and sx < node.right + margin:
            sx = round((node.right + stub_len) / GRID) * GRID
        return (sx, sy)

    def _make_route(node_a: Node, p1: tuple, sa: str,
                    node_b: Node, p2: tuple, sb: str,
                    obstacles: list) -> list | None:
        s1 = _stub_point(node_a, p1, sa, obstacles)
        s2 = _stub_point(node_b, p2, sb, obstacles)

        # Fix 4 — tente ligne droite / L-route avant A*
        direct = _try_direct_route(p1, sa, s1, p2, sb, s2, obstacles,
                                   node_a, node_b)
        if direct:
            return direct

        route = _astar_route(s1, s2, obstacles, all_rects,
                             obstacle_margin=p["obstacle_margin"],
                             bend_cost=p["astar_bend_cost"])
        if not route:
            return None

        full = [p1]
        if sa in ("top", "bottom"):
            if abs(p1[0] - s1[0]) > 0.5:
                full.append((p1[0], s1[1]))
            full.append(s1)
        else:
            if abs(p1[1] - s1[1]) > 0.5:
                full.append((s1[0], p1[1]))
            full.append(s1)
        for pt in route[1:-1]:
            full.append(pt)
        if sb in ("top", "bottom"):
            full.append(s2)
            if abs(p2[0] - s2[0]) > 0.5:
                full.append((p2[0], s2[1]))
        else:
            full.append(s2)
            if abs(p2[1] - s2[1]) > 0.5:
                full.append((s2[0], p2[1]))
        full.append(p2)
        return _clean_path(full)

    def _try_direct_route(p1, sa, s1, p2, sb, s2, obstacles, node_a=None, node_b=None):
        """Fix 4 — tente lignes droites et L-routes simples.
        Ordre : droite → L à 1 coude → Z à 2 coudes."""

        def clear(route):
            return not _any_seg_hits_node(route, obstacles, node_a, node_b)

        # 1. Ligne parfaitement droite (même X ou même Y)
        if abs(p1[0] - p2[0]) < 1:
            route = [(p1[0], p1[1]), (p2[0], p2[1])]
            if clear(route):
                return route
        if abs(p1[1] - p2[1]) < 1:
            route = [(p1[0], p1[1]), (p2[0], p2[1])]
            if clear(route):
                return route

        # 2. L-route à 1 coude (2 variantes)
        for corner in [(p1[0], p2[1]), (p2[0], p1[1])]:
            route = [p1, corner, p2]
            if clear(route):
                return route

        # 3. Z-route à 2 coudes via stubs (horizontal)
        if sa in ("left", "right") and sb in ("left", "right"):
            mid_x = (s1[0] + s2[0]) / 2
            mid_x = round(mid_x / GRID) * GRID
            route = [p1, (mid_x, p1[1]), (mid_x, p2[1]), p2]
            if clear(route):
                return route

        # 3b. Z-route vertical
        if sa in ("top", "bottom") and sb in ("top", "bottom"):
            mid_y = (s1[1] + s2[1]) / 2
            mid_y = round(mid_y / GRID) * GRID
            route = [p1, (p1[0], mid_y), (p2[0], mid_y), p2]
            if clear(route):
                return route

        # 4. L-routes croisées (côtés différents)
        if sa in ("top", "bottom") and sb in ("left", "right"):
            route = [p1, (p1[0], p2[1]), p2]
            if clear(route):
                return route
        if sa in ("left", "right") and sb in ("top", "bottom"):
            route = [p1, (p2[0], p1[1]), p2]
            if clear(route):
                return route

        return None

    def _any_seg_hits_node(route, obstacles, node_a=None, node_b=None):
        """Vérifie si un segment traverse un obstacle OU les boîtes source/dest.
        Chaque segment est vérifié contre TOUTES les boîtes sauf celle dont
        il part directement (premier segment = boîte A, dernier = boîte B)."""
        for i in range(len(route) - 1):
            for ox, oy, ow, oh in obstacles:
                if _seg_crosses_rect(route[i], route[i+1], ox, oy, ow, oh, margin=25):
                    return True
            # Vérifier contre la boîte B pour tous les segments sauf le dernier
            if node_b and i < len(route) - 1:
                if _seg_crosses_rect(route[i], route[i+1],
                                     node_b.x, node_b.y, node_b.w, node_b.h, margin=8):
                    return True
            # Vérifier contre la boîte A pour tous les segments sauf le premier
            if node_a and i > 0:
                if _seg_crosses_rect(route[i], route[i+1],
                                     node_a.x, node_a.y, node_a.w, node_a.h, margin=8):
                    return True
        return False

    def _score(route, edge_from, edge_to, routed_so_far):
        if not route:
            return float('inf')
        sc = 0.0
        for i in range(len(route) - 1):
            sc += math.hypot(route[i+1][0] - route[i][0],
                             route[i+1][1] - route[i][1])
        # Fix 2 — penalise chaque coude plus fortement
        bend_count = 0
        for i in range(1, len(route) - 1):
            dx1 = route[i][0] - route[i-1][0]
            dy1 = route[i][1] - route[i-1][1]
            dx2 = route[i+1][0] - route[i][0]
            dy2 = route[i+1][1] - route[i][1]
            if abs(dx1) + abs(dy1) > 0.1 and abs(dx2) + abs(dy2) > 0.1:
                h1 = abs(dx1) > abs(dy1)
                h2 = abs(dx2) > abs(dy2)
                if h1 != h2:
                    bend_count += 1
                    sc += p["bend_cost"]
        # Pénalité exponentielle pour les routes avec trop de coudes
        if bend_count > 2:
            sc += (bend_count - 2) * p["bend_cost"] * 2

        # Collision nœuds intermédiaires
        for i in range(len(route) - 1):
            for n in nodes:
                if n.name in (edge_from, edge_to):
                    continue
                if _seg_crosses_rect(route[i], route[i+1],
                                     n.x, n.y, n.w, n.h, margin=25):
                    sc += p["collision_node"]
        # Fix 5 — croisements avec arêtes déjà routées (penalty exponentielle)
        crossing_count = 0
        for other in routed_so_far:
            for i in range(len(route) - 1):
                for j in range(len(other) - 1):
                    pt = _seg_intersection(route[i], route[i+1],
                                           other[j], other[j+1])
                    if pt:
                        crossing_count += 1
        sc += crossing_count * p["crossing_edge"] * (1 + crossing_count * 0.5)
        # Parallel segment penalty — avoid segments running parallel within 10px
        for other in routed_so_far:
            for i in range(len(route) - 1):
                r1, r2 = route[i], route[i+1]
                r_horiz = abs(r1[1] - r2[1]) < 1
                r_vert = abs(r1[0] - r2[0]) < 1
                if not r_horiz and not r_vert:
                    continue
                for j in range(len(other) - 1):
                    o1, o2 = other[j], other[j+1]
                    if r_horiz and abs(o1[1] - o2[1]) < 1:
                        # Both horizontal — check if same Y within 10px
                        if abs(r1[1] - o1[1]) < 10:
                            rx_min, rx_max = min(r1[0], r2[0]), max(r1[0], r2[0])
                            ox_min, ox_max = min(o1[0], o2[0]), max(o1[0], o2[0])
                            overlap = min(rx_max, ox_max) - max(rx_min, ox_min)
                            if overlap > 20:
                                sc += 500
                    elif r_vert and abs(o1[0] - o2[0]) < 1:
                        # Both vertical — check if same X within 10px
                        if abs(r1[0] - o1[0]) < 10:
                            ry_min, ry_max = min(r1[1], r2[1]), max(r1[1], r2[1])
                            oy_min, oy_max = min(o1[1], o2[1]), max(o1[1], o2[1])
                            overlap = min(ry_max, oy_max) - max(ry_min, oy_min)
                            if overlap > 20:
                                sc += 500
        # Side flyover penalty
        a_node = node_map.get(edge_from)
        b_node = node_map.get(edge_to)
        for endpoint_node in (a_node, b_node):
            if not endpoint_node:
                continue
            nx, ny, nw, nh = endpoint_node.x, endpoint_node.y, endpoint_node.w, endpoint_node.h
            proximity = 15
            for i in range(1, len(route) - 1):
                px, py = route[i]
                if abs(py - ny) < proximity and nx - proximity <= px <= nx + nw + proximity:
                    sc += p["side_flyover"]
                if abs(py - (ny + nh)) < proximity and nx - proximity <= px <= nx + nw + proximity:
                    sc += p["side_flyover"]
                if abs(px - nx) < proximity and ny - proximity <= py <= ny + nh + proximity:
                    sc += p["side_flyover"]
                if abs(px - (nx + nw)) < proximity and ny - proximity <= py <= ny + nh + proximity:
                    sc += p["side_flyover"]
        return sc

    # ── Pass 1: Best side combo per edge ──
    edge_best_sides: dict[int, tuple[str, str]] = {}
    edge_best_routes: dict[int, list] = {}
    routed_so_far: list[list] = []

    node_degree: dict[str, int] = {}
    for e in edges:
        node_degree[e.from_node] = node_degree.get(e.from_node, 0) + 1
        node_degree[e.to_node] = node_degree.get(e.to_node, 0) + 1

    # Fix 5 — trie par degré combiné (hubs en premier) PUIS par distance (proches en premier)
    def _edge_priority(i):
        e = edges[i]
        a = node_map.get(e.from_node)
        b = node_map.get(e.to_node)
        degree = node_degree.get(e.from_node, 0) + node_degree.get(e.to_node, 0)
        dist = math.hypot(a.cx - b.cx, a.cy - b.cy) if a and b else 9999
        # Hubs d'abord, puis par distance croissante pour minimiser les croisements
        return (-degree, dist)

    edge_order = sorted(range(len(edges)), key=_edge_priority)

    for idx in edge_order:
        edge = edges[idx]
        a = node_map.get(edge.from_node)
        b = node_map.get(edge.to_node)
        if not a or not b:
            continue

        obstacles = [(x, y, w, h) for x, y, w, h, name in all_rects
                     if name not in (edge.from_node, edge.to_node)]

        best_sc = float('inf')
        best_route = None
        best_sides = ("right", "left")

        for sa in SIDES:
            p1 = _port_at(a, sa, 0.5)
            for sb in SIDES:
                p2 = _port_at(b, sb, 0.5)
                route = _make_route(a, p1, sa, b, p2, sb, obstacles)
                if not route:
                    continue
                sc = _score(route, edge.from_node, edge.to_node, routed_so_far)
                if sc < best_sc:
                    best_sc = sc
                    best_route = route
                    best_sides = (sa, sb)

        if not best_route:
            p1, sa = _best_port(a, b)
            p2, sb = _best_port(b, a)
            best_route = [p1, p2]
            best_sides = (sa, sb)

        edge_best_sides[idx] = best_sides
        edge_best_routes[idx] = best_route
        routed_so_far.append(best_route)

    # ── Pass 2: Balance sides then distribute ports, re-route ──
    # First, balance: if a node has edges crowded on one side while other sides
    # are free, move some edges to the free sides.
    side_usage: dict[tuple[str, str], list[int]] = {}
    for idx, (sa, sb) in edge_best_sides.items():
        e = edges[idx]
        a = node_map.get(e.from_node)
        b = node_map.get(e.to_node)
        if not a or not b:
            continue
        side_usage.setdefault((a.name, sa), []).append(idx)
        side_usage.setdefault((b.name, sb), []).append(idx)

    # For each node, check if sides are balanced
    for n in nodes:
        # Count edges per side for this node
        sides_count = {}
        sides_edges = {}
        for side in SIDES:
            key = (n.name, side)
            edges_on_side = side_usage.get(key, [])
            sides_count[side] = len(edges_on_side)
            sides_edges[side] = list(edges_on_side)

        total_edges = sum(sides_count.values())
        if total_edges <= 1:
            continue

        # Max edges per side: ceil(total / 4) but at least 1
        max_per_side = max(1, math.ceil(total_edges / 4))
        # Also consider side length — shorter sides get fewer edges
        side_capacity = {}
        for side in SIDES:
            side_len = n.w if side in ("top", "bottom") else n.h
            # At least 1, and proportional to length (min spacing ~25px)
            side_capacity[side] = max(1, int(side_len / 25))

        # Find overloaded sides and move excess edges to free sides
        for side in SIDES:
            cap = min(max_per_side, side_capacity[side])
            while sides_count[side] > cap:
                # Find the best free side to move an edge to
                # Pick the side with the most remaining capacity
                best_target = None
                best_room = -1
                for target in SIDES:
                    if target == side:
                        continue
                    room = min(max_per_side, side_capacity[target]) - sides_count[target]
                    if room > best_room:
                        best_room = room
                        best_target = target

                if best_target is None or best_room <= 0:
                    break

                # Move the last edge on this side to the target side
                eidx = sides_edges[side].pop()
                sides_count[side] -= 1

                # Update side_usage
                side_usage[(n.name, side)].remove(eidx)
                side_usage.setdefault((n.name, best_target), []).append(eidx)
                sides_edges[best_target].append(eidx)
                sides_count[best_target] += 1

                # Update edge_best_sides for this edge
                e = edges[eidx]
                old_sa, old_sb = edge_best_sides[eidx]
                if e.from_node == n.name:
                    edge_best_sides[eidx] = (best_target, old_sb)
                else:
                    edge_best_sides[eidx] = (old_sa, best_target)

    port_pos: dict[tuple[int, int], tuple[float, float]] = {}
    for (node_name, side), edge_indices in side_usage.items():
        n = node_map[node_name]
        count = len(edge_indices)
        # Garantir un espacement minimum entre ports — jamais le même point
        side_len = n.w if side in ("top", "bottom") else n.h
        min_spacing = max(20, side_len / (count + 2))  # au moins 20px entre ports
        for i, eidx in enumerate(edge_indices):
            t = (i + 1) / (count + 1)
            # Clamp t pour garder les ports loin des coins (min 15%, max 85%)
            t = 0.15 + t * 0.7
            port = _port_at(n, side, t)
            e = edges[eidx]
            key = 0 if e.from_node == node_name else 1
            port_pos[(eidx, key)] = port

    # ── Global port deduplication: no two edges share the same anchor point ──
    # Group all ports by node
    node_ports: dict[str, list[tuple[tuple[int, int], tuple[float, float]]]] = {}
    for (eidx, key), port in port_pos.items():
        e = edges[eidx]
        nname = e.from_node if key == 0 else e.to_node
        node_ports.setdefault(nname, []).append(((eidx, key), port))

    for nname, ports_list in node_ports.items():
        if len(ports_list) < 2:
            continue
        n = node_map[nname]
        # Check all pairs for duplicate/too-close ports (< 8px)
        for i in range(len(ports_list)):
            for j in range(i + 1, len(ports_list)):
                ki, pi = ports_list[i]
                kj, pj = ports_list[j]
                dist = math.hypot(pi[0] - pj[0], pi[1] - pj[1])
                if dist < 8:
                    # Shift the second port along the box side by 10px
                    # Determine which side this port is on
                    px, py = pj
                    if abs(px - n.x) < 2 or abs(px - n.right) < 2:
                        # On left or right side — shift vertically
                        new_py = py + 10
                        if new_py > n.bottom - 5:
                            new_py = py - 10
                        new_port = (px, max(n.y + 5, min(new_py, n.bottom - 5)))
                    else:
                        # On top or bottom side — shift horizontally
                        new_px = px + 10
                        if new_px > n.right - 5:
                            new_px = px - 10
                        new_port = (max(n.x + 5, min(new_px, n.right - 5)), py)
                    port_pos[kj] = new_port
                    ports_list[j] = (kj, new_port)

    for idx, edge in enumerate(edges):
        a = node_map.get(edge.from_node)
        b = node_map.get(edge.to_node)
        if not a or not b:
            continue

        p1 = port_pos.get((idx, 0))
        p2 = port_pos.get((idx, 1))
        sides = edge_best_sides.get(idx, ("right", "left"))

        if not p1:
            p1 = _port_at(a, sides[0], 0.5)
        if not p2:
            p2 = _port_at(b, sides[1], 0.5)

        obstacles = [(x, y, w, h) for x, y, w, h, name in all_rects
                     if name not in (edge.from_node, edge.to_node)]
        route = _make_route(a, p1, sides[0], b, p2, sides[1], obstacles)
        if route:
            edge.points = route
        else:
            edge.points = edge_best_routes.get(idx, [p1, p2])

    # ── Pass 3: Rip-up & Reroute ──
    reroute_passes = int(p.get("reroute_passes", 4))
    for _rip_pass in range(reroute_passes):
        all_routes = [e.points for e in edges if e.points]
        edge_scores = []
        for idx, edge in enumerate(edges):
            if not edge.points:
                continue
            other_routes = [e.points for i, e in enumerate(edges)
                           if i != idx and e.points]
            sc = _score(edge.points, edge.from_node, edge.to_node, other_routes)
            edge_scores.append((sc, idx))

        edge_scores.sort(reverse=True)
        improved = False

        for sc, idx in edge_scores:
            if sc <= 40:
                break
            edge = edges[idx]
            a = node_map.get(edge.from_node)
            b = node_map.get(edge.to_node)
            if not a or not b:
                continue

            old_route = edge.points
            old_sides = edge_best_sides.get(idx, ("right", "left"))
            other_routes = [e.points for i, e in enumerate(edges)
                           if i != idx and e.points]
            obstacles = [(x, y, w, h) for x, y, w, h, name in all_rects
                         if name not in (edge.from_node, edge.to_node)]

            best_sc = sc
            best_route = old_route
            best_combo = old_sides

            for sa in SIDES:
                p1 = port_pos.get((idx, 0), _port_at(a, sa, 0.5))
                if sa != old_sides[0]:
                    p1 = _port_at(a, sa, 0.5)
                for sb in SIDES:
                    p2 = port_pos.get((idx, 1), _port_at(b, sb, 0.5))
                    if sb != old_sides[1]:
                        p2 = _port_at(b, sb, 0.5)
                    route = _make_route(a, p1, sa, b, p2, sb, obstacles)
                    if not route:
                        continue
                    new_sc = _score(route, edge.from_node, edge.to_node,
                                    other_routes)
                    if new_sc < best_sc:
                        best_sc = new_sc
                        best_route = route
                        best_combo = (sa, sb)

            if best_route is not old_route:
                edge.points = best_route
                edge_best_sides[idx] = best_combo
                improved = True

        if not improved:
            break

    # ── Pass 4: Fix 2 — Straightening post-processing ──
    for edge in edges:
        if edge.points:
            edge.points = _straighten_path(edge.points, nodes, node_map,
                                           edge.from_node, edge.to_node)

    # ── Pass 5: Orthonormal collision detection ──
    # Use exact geometric intersection counting:
    # - 1 intersection with from/to box = port (OK)
    # - 2+ intersections with ANY box = line goes through (re-route)
    for _collision_pass in range(3):
        any_fixed = False
        for idx, edge in enumerate(edges):
            if not edge.points:
                continue
            a = node_map.get(edge.from_node)
            b = node_map.get(edge.to_node)
            if not a or not b:
                continue

            if not route_has_collision(edge.points, nodes,
                                       edge.from_node, edge.to_node):
                continue

            # Collision detected — try all side combos with increased margin
            obstacles = [(x, y, w, h) for x, y, w, h, name in all_rects
                         if name not in (edge.from_node, edge.to_node)]
            old_margin = p["obstacle_margin"]
            p["obstacle_margin"] = old_margin * (2 + _collision_pass)

            best_route = None
            best_intersections = 999
            for sa in SIDES:
                p1 = _port_at(a, sa, 0.5)
                for sb in SIDES:
                    p2 = _port_at(b, sb, 0.5)
                    route = _make_route(a, p1, sa, b, p2, sb, obstacles)
                    if not route:
                        continue
                    # Count total intersections across all boxes
                    total = 0
                    for n in nodes:
                        c = _count_rect_intersections(route, n)
                        if n.name in (edge.from_node, edge.to_node):
                            total += max(0, c - 1)  # 1 is OK (port)
                        else:
                            total += c
                    if total < best_intersections:
                        best_intersections = total
                        best_route = route
                    if total == 0:
                        break
                if best_intersections == 0:
                    break

            p["obstacle_margin"] = old_margin
            if best_route and best_intersections < 999:
                edge.points = best_route
                any_fixed = True

        if not any_fixed:
            break

    # ── Pass 6: Nudge crossing segments apart ──
    _nudge_crossings(edges, nodes)

    # ── Pass 7: Nudge parallel overlapping segments ──
    _nudge_parallel_segments(edges, nodes)

    # ── Pass 8: Enforce anchor rules ──
    # Rule 1: All ports on a node must be at least 5px apart
    # Rule 2: Line must leave perpendicular to the face
    # Rule 3: Min 10px from face to first bend
    for edge in edges:
        if not edge.points or len(edge.points) < 2:
            continue
        a = node_map.get(edge.from_node)
        b = node_map.get(edge.to_node)
        if not a or not b:
            continue
        edge.points[0] = _snap_point_to_border(edge.points[0], edge.points[1], a)
        edge.points[-1] = _snap_point_to_border(edge.points[-1], edge.points[-2], b)

        # Rule 2+3: Ensure perpendicular exit with min 10px stub
        _enforce_perpendicular_exit(edge.points, 0, a)
        _enforce_perpendicular_exit(edge.points, -1, b)

        # Verify no bend is tangent to a box
        for i in range(1, len(edge.points) - 1):
            px, py = edge.points[i]
            for n in nodes:
                if n.name in (edge.from_node, edge.to_node):
                    continue
                on_left = abs(px - n.x) < 2 and n.y - 2 <= py <= n.bottom + 2
                on_right = abs(px - n.right) < 2 and n.y - 2 <= py <= n.bottom + 2
                on_top = abs(py - n.y) < 2 and n.x - 2 <= px <= n.right + 2
                on_bottom = abs(py - n.bottom) < 2 and n.x - 2 <= px <= n.right + 2
                if on_left or on_right or on_top or on_bottom:
                    if on_left:
                        edge.points[i] = (px - 10, py)
                    elif on_right:
                        edge.points[i] = (px + 10, py)
                    elif on_top:
                        edge.points[i] = (px, py - 10)
                    elif on_bottom:
                        edge.points[i] = (px, py + 10)
                    break

    # Rule 1: Global port spacing — ensure all anchors on same node are 5px+ apart
    # Collect final port positions from routed edges
    final_ports: dict[str, list[tuple[int, tuple[float, float]]]] = {}
    for idx, edge in enumerate(edges):
        if not edge.points or len(edge.points) < 2:
            continue
        final_ports.setdefault(edge.from_node, []).append((idx, edge.points[0]))
        final_ports.setdefault(edge.to_node, []).append((idx, edge.points[-1]))

    for nname, ports in final_ports.items():
        if len(ports) < 2:
            continue
        n = node_map[nname]
        # Sort ports by position along each side
        # Check all pairs
        changed = True
        for _pass in range(5):
            if not changed:
                break
            changed = False
            for i in range(len(ports)):
                for j in range(i + 1, len(ports)):
                    idx_i, pi = ports[i]
                    idx_j, pj = ports[j]
                    dist = math.hypot(pi[0] - pj[0], pi[1] - pj[1])
                    if dist < 5:
                        # Shift pj along the face by 5px
                        # Determine face
                        on_top = abs(pj[1] - n.y) < 2
                        on_bot = abs(pj[1] - n.bottom) < 2
                        on_left = abs(pj[0] - n.x) < 2
                        on_right = abs(pj[0] - n.right) < 2

                        if on_top or on_bot:
                            # Shift horizontally
                            new_x = pj[0] + 5
                            if new_x > n.right - 5:
                                new_x = pj[0] - 5
                            new_x = max(n.x + 5, min(new_x, n.right - 5))
                            new_port = (new_x, pj[1])
                        elif on_left or on_right:
                            # Shift vertically
                            new_y = pj[1] + 5
                            if new_y > n.bottom - 5:
                                new_y = pj[1] - 5
                            new_y = max(n.y + 5, min(new_y, n.bottom - 5))
                            new_port = (pj[0], new_y)
                        else:
                            continue

                        # Update the edge endpoint
                        e = edges[idx_j]
                        if e.from_node == nname:
                            e.points[0] = new_port
                        else:
                            e.points[-1] = new_port
                        ports[j] = (idx_j, new_port)
                        changed = True


def _straighten_path(points: list, nodes: list[Node], node_map: dict,
                     from_name: str, to_name: str) -> list:
    """Fix 2 — Tente de remplacer des séquences de 3+ points par des lignes
    droites ou des L-routes à 1 coude quand aucun obstacle n'est en chemin."""
    if len(points) <= 3:
        return points

    obstacles = [(n.x, n.y, n.w, n.h) for n in nodes
                 if n.name not in (from_name, to_name)]

    def clear_segment(a, b):
        for ox, oy, ow, oh in obstacles:
            if _seg_crosses_rect(a, b, ox, oy, ow, oh, margin=25):
                return False
        return True

    changed = True
    iters = 0
    result = list(points)

    while changed and iters < 6:
        changed = False
        iters += 1
        i = 0
        while i < len(result) - 2:
            p_start = result[i]
            p_end = result[i + 2]

            # Tente une ligne droite entre result[i] et result[i+2]
            if (abs(p_start[0] - p_end[0]) < 1 or abs(p_start[1] - p_end[1]) < 1):
                if clear_segment(p_start, p_end):
                    result = result[:i+1] + result[i+2:]
                    changed = True
                    continue

            # Tente de sauter 2 points intermédiaires (shortcut plus long)
            if i + 3 < len(result):
                p_far = result[i + 3]
                for corner in [(p_start[0], p_far[1]), (p_far[0], p_start[1])]:
                    if (clear_segment(p_start, corner) and
                            clear_segment(corner, p_far)):
                        result = result[:i+1] + [corner] + result[i+3:]
                        changed = True
                        break
                if changed:
                    continue

            i += 1

    return result


def _nudge_crossings(edges: list[Edge], nodes: list[Node],
                     nudge: float = 12) -> None:
    """Fix 5 — Déplace légèrement les segments horizontaux/verticaux qui
    se croisent pour qu'ils ne se touchent plus.
    Stratégie : pour chaque paire (ei, ej) qui se croise, on décale le
    segment le plus court perpendiculairement de `nudge` pixels si la
    nouvelle position ne heurte pas un nœud."""
    node_rects = [(n.x, n.y, n.w, n.h) for n in nodes]

    def seg_is_clear(a, b):
        for rx, ry, rw, rh in node_rects:
            if _seg_crosses_rect(a, b, rx, ry, rw, rh, margin=12):
                return False
        return True

    for _ in range(3):  # quelques passes
        crossings = find_edge_crossings(edges)
        if not crossings:
            break

        for (ei, ej, cx, cy) in crossings:
            ea = edges[ei]
            eb = edges[ej]

            # Trouve les segments qui se croisent
            for si in range(len(ea.points) - 1):
                for sj in range(len(eb.points) - 1):
                    pt = _seg_intersection(ea.points[si], ea.points[si+1],
                                           eb.points[sj], eb.points[sj+1])
                    if not pt:
                        continue

                    # Détermine quel segment est horizontal/vertical
                    a1, a2 = ea.points[si], ea.points[si+1]
                    b1, b2 = eb.points[sj], eb.points[sj+1]
                    len_a = math.hypot(a2[0]-a1[0], a2[1]-a1[1])
                    len_b = math.hypot(b2[0]-b1[0], b2[1]-b1[1])

                    # Nudge le segment le plus court
                    if len_a <= len_b:
                        # Nudge ea segment si
                        if abs(a1[1] - a2[1]) < 1:  # horizontal
                            for dy in (nudge, -nudge):
                                na1 = (a1[0], a1[1] + dy)
                                na2 = (a2[0], a2[1] + dy)
                                if seg_is_clear(na1, na2):
                                    pts = list(ea.points)
                                    pts[si] = na1
                                    pts[si+1] = na2
                                    ea.points = _clean_path(pts)
                                    break
                        elif abs(a1[0] - a2[0]) < 1:  # vertical
                            for dx in (nudge, -nudge):
                                na1 = (a1[0] + dx, a1[1])
                                na2 = (a2[0] + dx, a2[1])
                                if seg_is_clear(na1, na2):
                                    pts = list(ea.points)
                                    pts[si] = na1
                                    pts[si+1] = na2
                                    ea.points = _clean_path(pts)
                                    break
                    else:
                        if abs(b1[1] - b2[1]) < 1:
                            for dy in (nudge, -nudge):
                                nb1 = (b1[0], b1[1] + dy)
                                nb2 = (b2[0], b2[1] + dy)
                                if seg_is_clear(nb1, nb2):
                                    pts = list(eb.points)
                                    pts[sj] = nb1
                                    pts[sj+1] = nb2
                                    eb.points = _clean_path(pts)
                                    break
                        elif abs(b1[0] - b2[0]) < 1:
                            for dx in (nudge, -nudge):
                                nb1 = (b1[0] + dx, b1[1])
                                nb2 = (b2[0] + dx, b2[1])
                                if seg_is_clear(nb1, nb2):
                                    pts = list(eb.points)
                                    pts[sj] = nb1
                                    pts[sj+1] = nb2
                                    eb.points = _clean_path(pts)
                                    break


def _nudge_parallel_segments(edges: list[Edge], nodes: list[Node],
                              nudge: float = 12, threshold: float = 10,
                              min_overlap: float = 20) -> None:
    """Nudge segments that run parallel (same Y or same X) over a long distance.

    Two horizontal segments with the same Y (within threshold) and overlapping
    X ranges (by at least min_overlap px) get one of them shifted vertically.
    Same logic for vertical segments sharing an X coordinate.
    """
    node_rects = [(n.x, n.y, n.w, n.h) for n in nodes]

    def seg_is_clear(a, b):
        for rx, ry, rw, rh in node_rects:
            if _seg_crosses_rect(a, b, rx, ry, rw, rh, margin=8):
                return False
        return True

    for _ in range(3):
        moved = False
        for i in range(len(edges)):
            ei = edges[i]
            if not ei.points:
                continue
            for si in range(len(ei.points) - 1):
                a1, a2 = ei.points[si], ei.points[si + 1]
                a_horiz = abs(a1[1] - a2[1]) < 1
                a_vert = abs(a1[0] - a2[0]) < 1
                if not a_horiz and not a_vert:
                    continue

                for j in range(i + 1, len(edges)):
                    ej = edges[j]
                    if not ej.points:
                        continue
                    for sj in range(len(ej.points) - 1):
                        b1, b2 = ej.points[sj], ej.points[sj + 1]

                        if a_horiz and abs(b1[1] - b2[1]) < 1:
                            # Both horizontal — check same Y
                            if abs(a1[1] - b1[1]) > threshold:
                                continue
                            # Check X overlap
                            ax_min, ax_max = min(a1[0], a2[0]), max(a1[0], a2[0])
                            bx_min, bx_max = min(b1[0], b2[0]), max(b1[0], b2[0])
                            overlap = min(ax_max, bx_max) - max(ax_min, bx_min)
                            if overlap < min_overlap:
                                continue
                            # Nudge the shorter segment
                            la = abs(a2[0] - a1[0])
                            lb = abs(b2[0] - b1[0])
                            target_edge = ej if lb <= la else ei
                            target_si = sj if lb <= la else si
                            for dy in (nudge, -nudge):
                                n1 = (target_edge.points[target_si][0],
                                      target_edge.points[target_si][1] + dy)
                                n2 = (target_edge.points[target_si + 1][0],
                                      target_edge.points[target_si + 1][1] + dy)
                                if seg_is_clear(n1, n2):
                                    pts = list(target_edge.points)
                                    pts[target_si] = n1
                                    pts[target_si + 1] = n2
                                    target_edge.points = _clean_path(pts)
                                    moved = True
                                    break

                        elif a_vert and abs(b1[0] - b2[0]) < 1:
                            # Both vertical — check same X
                            if abs(a1[0] - b1[0]) > threshold:
                                continue
                            ay_min, ay_max = min(a1[1], a2[1]), max(a1[1], a2[1])
                            by_min, by_max = min(b1[1], b2[1]), max(b1[1], b2[1])
                            overlap = min(ay_max, by_max) - max(ay_min, by_min)
                            if overlap < min_overlap:
                                continue
                            la = abs(a2[1] - a1[1])
                            lb = abs(b2[1] - b1[1])
                            target_edge = ej if lb <= la else ei
                            target_si = sj if lb <= la else si
                            for dx in (nudge, -nudge):
                                n1 = (target_edge.points[target_si][0] + dx,
                                      target_edge.points[target_si][1])
                                n2 = (target_edge.points[target_si + 1][0] + dx,
                                      target_edge.points[target_si + 1][1])
                                if seg_is_clear(n1, n2):
                                    pts = list(target_edge.points)
                                    pts[target_si] = n1
                                    pts[target_si + 1] = n2
                                    target_edge.points = _clean_path(pts)
                                    moved = True
                                    break

        if not moved:
            break


def _enforce_perpendicular_exit(points: list, end: int, node: Node,
                                 min_stub: float = 10) -> None:
    """Ensure the line leaves/arrives perpendicular to the box face.

    If end=0: check points[0]→points[1] direction.
    If end=-1: check points[-1]→points[-2] direction.

    The first segment from the anchor must be purely horizontal (if on top/bottom)
    or purely vertical (if on left/right), with at least min_stub px length.
    If not, insert a perpendicular stub point.
    """
    if end == 0:
        port = points[0]
        nxt = points[1]
        # Determine which face the port is on
        on_top = abs(port[1] - node.y) < 2
        on_bot = abs(port[1] - node.bottom) < 2
        on_left = abs(port[0] - node.x) < 2
        on_right = abs(port[0] - node.right) < 2

        if on_top:
            # Must go up (negative Y), perpendicular = same X
            stub_y = port[1] - max(min_stub, abs(nxt[1] - port[1]) * 0.3)
            if abs(nxt[0] - port[0]) > 1 or (nxt[1] - port[1]) > -min_stub:
                # Not perpendicular or too short — insert stub
                stub = (port[0], min(port[1] - min_stub, stub_y))
                points.insert(1, stub)
        elif on_bot:
            stub_y = port[1] + max(min_stub, abs(nxt[1] - port[1]) * 0.3)
            if abs(nxt[0] - port[0]) > 1 or (nxt[1] - port[1]) < min_stub:
                stub = (port[0], max(port[1] + min_stub, stub_y))
                points.insert(1, stub)
        elif on_left:
            stub_x = port[0] - max(min_stub, abs(nxt[0] - port[0]) * 0.3)
            if abs(nxt[1] - port[1]) > 1 or (nxt[0] - port[0]) > -min_stub:
                stub = (min(port[0] - min_stub, stub_x), port[1])
                points.insert(1, stub)
        elif on_right:
            stub_x = port[0] + max(min_stub, abs(nxt[0] - port[0]) * 0.3)
            if abs(nxt[1] - port[1]) > 1 or (nxt[0] - port[0]) < min_stub:
                stub = (max(port[0] + min_stub, stub_x), port[1])
                points.insert(1, stub)
    else:
        port = points[-1]
        nxt = points[-2]
        on_top = abs(port[1] - node.y) < 2
        on_bot = abs(port[1] - node.bottom) < 2
        on_left = abs(port[0] - node.x) < 2
        on_right = abs(port[0] - node.right) < 2

        if on_top:
            if abs(nxt[0] - port[0]) > 1 or (nxt[1] - port[1]) > -min_stub:
                stub = (port[0], port[1] - min_stub)
                points.insert(len(points) - 1, stub)
        elif on_bot:
            if abs(nxt[0] - port[0]) > 1 or (nxt[1] - port[1]) < min_stub:
                stub = (port[0], port[1] + min_stub)
                points.insert(len(points) - 1, stub)
        elif on_left:
            if abs(nxt[1] - port[1]) > 1 or (nxt[0] - port[0]) > -min_stub:
                stub = (port[0] - min_stub, port[1])
                points.insert(len(points) - 1, stub)
        elif on_right:
            if abs(nxt[1] - port[1]) > 1 or (nxt[0] - port[0]) < min_stub:
                stub = (port[0] + min_stub, port[1])
                points.insert(len(points) - 1, stub)


def _snap_point_to_border(port: tuple[float, float],
                          toward: tuple[float, float],
                          node: Node) -> tuple[float, float]:
    """Snap a point to the nearest border of a node box.

    Projects the point onto the closest side of the rectangle,
    keeping it on the line between port and toward.
    """
    px, py = port
    # If already on border (within 2px), keep it
    on_border = (abs(px - node.x) < 2 or abs(px - node.right) < 2 or
                 abs(py - node.y) < 2 or abs(py - node.bottom) < 2)
    in_range_x = node.x - 2 <= px <= node.right + 2
    in_range_y = node.y - 2 <= py <= node.bottom + 2
    if on_border and in_range_x and in_range_y:
        # Clamp to exact border
        if abs(px - node.x) < 2:
            return (node.x, max(node.y, min(py, node.bottom)))
        if abs(px - node.right) < 2:
            return (node.right, max(node.y, min(py, node.bottom)))
        if abs(py - node.y) < 2:
            return (max(node.x, min(px, node.right)), node.y)
        if abs(py - node.bottom) < 2:
            return (max(node.x, min(px, node.right)), node.bottom)

    # Not on border — find intersection of line (port→toward) with box border
    tx, ty = toward
    dx, dy = tx - px, ty - py

    best = port
    best_dist = float('inf')
    # Check all 4 sides
    sides = [
        (node.x, node.y, node.x, node.bottom),       # left
        (node.right, node.y, node.right, node.bottom), # right
        (node.x, node.y, node.right, node.y),         # top
        (node.x, node.bottom, node.right, node.bottom), # bottom
    ]
    for sx1, sy1, sx2, sy2 in sides:
        # Find intersection of ray from center of node through toward direction
        # with this side
        sdx, sdy = sx2 - sx1, sy2 - sy1
        denom = dx * sdy - dy * sdx
        if abs(denom) < 0.001:
            continue
        t = ((sx1 - px) * sdy - (sy1 - py) * sdx) / denom
        u = ((sx1 - px) * dy - (sy1 - py) * dx) / denom
        if 0 <= u <= 1:
            ix = sx1 + u * sdx
            iy = sy1 + u * sdy
            d = math.hypot(ix - node.cx, iy - node.cy)
            if d < best_dist:
                best_dist = d
                best = (ix, iy)

    return best


def _port_at(node: Node, side: str, t: float) -> tuple[float, float]:
    if side == "top":
        return (node.x + node.w * t, node.y)
    elif side == "bottom":
        return (node.x + node.w * t, node.bottom)
    elif side == "left":
        return (node.x, node.y + node.h * t)
    else:
        return (node.right, node.y + node.h * t)


def _best_port(from_node: Node, to_node: Node) -> tuple[tuple[float, float], str]:
    dx = to_node.cx - from_node.cx
    dy = to_node.cy - from_node.cy
    if abs(dx) > abs(dy):
        if dx > 0:
            return (from_node.right, from_node.cy), "right"
        else:
            return (from_node.x, from_node.cy), "left"
    else:
        if dy > 0:
            return (from_node.cx, from_node.bottom), "bottom"
        else:
            return (from_node.cx, from_node.y), "top"


def _astar_route(start, end, obstacles, all_rects, grid_size=10,
                 obstacle_margin=8, bend_cost=15):
    """A* orthogonal pathfinding on a grid."""
    all_coords = [start, end]
    for r in all_rects:
        all_coords.extend([(r[0], r[1]), (r[0] + r[2], r[1] + r[3])])

    min_gx = int(min(p[0] for p in all_coords) / grid_size) - 6
    min_gy = int(min(p[1] for p in all_coords) / grid_size) - 6
    max_gx = int(max(p[0] for p in all_coords) / grid_size) + 6
    max_gy = int(max(p[1] for p in all_coords) / grid_size) + 6

    cells = (max_gx - min_gx) * (max_gy - min_gy)
    if cells > 80000:
        grid_size = max(grid_size, int(math.sqrt(cells * grid_size * grid_size / 80000)))
        min_gx = int(min(p[0] for p in all_coords) / grid_size) - 4
        min_gy = int(min(p[1] for p in all_coords) / grid_size) - 4
        max_gx = int(max(p[0] for p in all_coords) / grid_size) + 4
        max_gy = int(max(p[1] for p in all_coords) / grid_size) + 4

    sx = int(round(start[0] / grid_size))
    sy = int(round(start[1] / grid_size))
    ex = int(round(end[0] / grid_size))
    ey = int(round(end[1] / grid_size))

    _obs_margin = obstacle_margin

    def is_blocked(gx, gy):
        px, py = gx * grid_size, gy * grid_size
        for ox, oy, ow, oh in obstacles:
            if (ox - _obs_margin <= px <= ox + ow + _obs_margin and
                    oy - _obs_margin <= py <= oy + oh + _obs_margin):
                return True
        return False

    DIRECTIONS = ((0, 1), (0, -1), (1, 0), (-1, 0))
    BEND_COST = bend_cost

    open_set = []
    heapq.heappush(open_set, (0.0, 0.0, sx, sy, -1))
    came_from = {}
    g_score = {(sx, sy): 0.0}

    step = 0
    while open_set and step < 50000:
        step += 1
        f, g, cx, cy, prev_dir = heapq.heappop(open_set)

        if (cx, cy) == (ex, ey):
            grid_path = [(cx, cy)]
            pos = (cx, cy)
            while pos in came_from:
                pos = came_from[pos]
                grid_path.append(pos)
            grid_path.reverse()
            pixel_path = [(gp[0] * grid_size, gp[1] * grid_size) for gp in grid_path]
            return _simplify_orthogonal(pixel_path)

        if g > g_score.get((cx, cy), float('inf')):
            continue

        for dir_idx, (ddx, ddy) in enumerate(DIRECTIONS):
            nx, ny = cx + ddx, cy + ddy
            if nx < min_gx or nx > max_gx or ny < min_gy or ny > max_gy:
                continue
            if is_blocked(nx, ny):
                continue

            bc = 0.0 if (prev_dir == dir_idx or prev_dir == -1) else BEND_COST
            new_g = g + 1 + bc

            if new_g < g_score.get((nx, ny), float('inf')):
                g_score[(nx, ny)] = new_g
                h = abs(nx - ex) + abs(ny - ey)
                came_from[(nx, ny)] = (cx, cy)
                heapq.heappush(open_set, (new_g + h, new_g, nx, ny, dir_idx))

    return None


def _simplify_orthogonal(path):
    if len(path) <= 2:
        return path
    result = [path[0]]
    for i in range(1, len(path) - 1):
        dx1 = path[i][0] - path[i - 1][0]
        dy1 = path[i][1] - path[i - 1][1]
        dx2 = path[i + 1][0] - path[i][0]
        dy2 = path[i + 1][1] - path[i][1]
        if (dx1, dy1) != (dx2, dy2):
            result.append(path[i])
    result.append(path[-1])
    return result


def _clean_path(points):
    """Remove duplicate points, merge colinear segments, remove U-turns."""
    if len(points) <= 2:
        return points

    cleaned = [points[0]]
    for pp in points[1:]:
        if abs(pp[0] - cleaned[-1][0]) > 1.0 or abs(pp[1] - cleaned[-1][1]) > 1.0:
            cleaned.append(pp)
    if len(cleaned) <= 2:
        return cleaned

    result = [cleaned[0]]
    for i in range(1, len(cleaned) - 1):
        p_prev = result[-1]
        p_cur = cleaned[i]
        p_next = cleaned[i + 1]
        if abs(p_prev[0] - p_cur[0]) < 1.0 and abs(p_cur[0] - p_next[0]) < 1.0:
            continue
        if abs(p_prev[1] - p_cur[1]) < 1.0 and abs(p_cur[1] - p_next[1]) < 1.0:
            continue
        result.append(p_cur)
    result.append(cleaned[-1])

    changed = True
    iters = 0
    while changed and len(result) > 3 and iters < 8:
        changed = False
        iters += 1
        i = 0
        while i < len(result) - 3:
            p0, p1, p2, p3 = result[i], result[i+1], result[i+2], result[i+3]
            dx1 = p1[0] - p0[0]; dy1 = p1[1] - p0[1]
            dx3 = p3[0] - p2[0]; dy3 = p3[1] - p2[1]
            if abs(dy1) < 1.0 and abs(dy3) < 1.0 and abs(dx1) > 1.0 and abs(dx3) > 1.0:
                if (dx1 > 0) != (dx3 > 0):
                    result = result[:i+1] + [(p0[0], p2[1])] + result[i+3:]
                    changed = True
                    continue
            if abs(dx1) < 1.0 and abs(dx3) < 1.0 and abs(dy1) > 1.0 and abs(dy3) > 1.0:
                if (dy1 > 0) != (dy3 > 0):
                    result = result[:i+1] + [(p2[0], p0[1])] + result[i+3:]
                    changed = True
                    continue
            i += 1

    return result


def _seg_crosses_rect(p1, p2, rx, ry, rw, rh, margin=3):
    x1, y1 = p1; x2, y2 = p2
    left = rx - margin; top = ry - margin
    right = rx + rw + margin; bottom = ry + rh + margin

    def code(x, y):
        c = 0
        if x < left: c |= 1
        elif x > right: c |= 2
        if y < top: c |= 4
        elif y > bottom: c |= 8
        return c

    c1, c2 = code(x1, y1), code(x2, y2)
    for _ in range(20):
        if not (c1 | c2): return True
        if c1 & c2: return False
        c = c1 or c2
        dx = (x2 - x1) or 1e-10; dy = (y2 - y1) or 1e-10
        if c & 8:   x = x1 + dx * (bottom - y1) / dy; y = bottom
        elif c & 4: x = x1 + dx * (top - y1) / dy;    y = top
        elif c & 2: y = y1 + dy * (right - x1) / dx;  x = right
        elif c & 1: y = y1 + dy * (left - x1) / dx;   x = left
        if c == c1: x1, y1 = x, y; c1 = code(x1, y1)
        else:       x2, y2 = x, y; c2 = code(x2, y2)
    return False


def _side_direction(side: str) -> tuple[float, float]:
    return {"right": (1, 0), "left": (-1, 0),
            "bottom": (0, 1), "top": (0, -1)}.get(side, (1, 0))


# ════════════════════════════════════════════════════════════
#  Geometric intersection detection (orthonormal)
# ════════════════════════════════════════════════════════════

def _seg_seg_intersection(a1: tuple, a2: tuple,
                          b1: tuple, b2: tuple) -> tuple | None:
    """Exact intersection point between two line segments, or None."""
    x1, y1 = a1; x2, y2 = a2
    x3, y3 = b1; x4, y4 = b2
    denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if abs(denom) < 1e-10:
        return None
    t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
    u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / denom
    if 0 <= t <= 1 and 0 <= u <= 1:
        return (x1 + t * (x2 - x1), y1 + t * (y2 - y1))
    return None


def _count_rect_intersections(points: list[tuple], node: "Node") -> int:
    """Count how many times a polyline crosses the border of a rectangle.

    Uses orthonormal geometry: the rectangle has 4 sides (segments).
    Each segment of the polyline is tested against each side.
    1 intersection = port (OK). 2+ = line goes through the box (BAD).
    """
    # 4 sides of the rectangle
    corners = [
        (node.x, node.y),                    # top-left
        (node.x + node.w, node.y),            # top-right
        (node.x + node.w, node.y + node.h),   # bottom-right
        (node.x, node.y + node.h),            # bottom-left
    ]
    sides = [
        (corners[0], corners[1]),  # top
        (corners[1], corners[2]),  # right
        (corners[2], corners[3]),  # bottom
        (corners[3], corners[0]),  # left
    ]

    intersection_points: list[tuple] = []
    for i in range(len(points) - 1):
        seg_a = points[i]
        seg_b = points[i + 1]
        for side_a, side_b in sides:
            pt = _seg_seg_intersection(seg_a, seg_b, side_a, side_b)
            if pt:
                # Avoid counting the same point twice (within tolerance)
                duplicate = False
                for existing in intersection_points:
                    if abs(pt[0] - existing[0]) < 2 and abs(pt[1] - existing[1]) < 2:
                        duplicate = True
                        break
                if not duplicate:
                    intersection_points.append(pt)

    return len(intersection_points)


def route_has_collision(points: list[tuple], nodes: list["Node"],
                        from_name: str, to_name: str) -> bool:
    """Check if a routed polyline collides with any box.

    Rules:
    - from/to boxes: exactly 1 intersection allowed (the port)
    - all other boxes: 0 intersections allowed
    - 2+ intersections on ANY box = collision
    """
    for n in nodes:
        count = _count_rect_intersections(points, n)
        if n.name in (from_name, to_name):
            if count > 1:
                return True  # Line enters and exits the source/dest box
        else:
            if count >= 2:
                return True  # Line passes through an unrelated box
    return False


def find_edge_crossings(edges: list[Edge]) -> list[tuple[int, int, float, float]]:
    """Find all crossing points between edges.

    Returns list of (jumper_edge_idx, other_edge_idx, cx, cy).
    The jumper is the edge whose crossing segment is LONGER (longer straight
    run before the next bend → it does the jump/arc).
    """
    crossings = []
    for i, ea in enumerate(edges):
        for j, eb in enumerate(edges):
            if j <= i:
                continue
            if (ea.from_node in (eb.from_node, eb.to_node) or
                    ea.to_node in (eb.from_node, eb.to_node)):
                continue
            for si in range(len(ea.points) - 1):
                for sj in range(len(eb.points) - 1):
                    pt = _seg_intersection(
                        ea.points[si], ea.points[si + 1],
                        eb.points[sj], eb.points[sj + 1])
                    if pt:
                        # Determine which segment is longer → that edge jumps
                        len_a = math.hypot(ea.points[si+1][0] - ea.points[si][0],
                                           ea.points[si+1][1] - ea.points[si][1])
                        len_b = math.hypot(eb.points[sj+1][0] - eb.points[sj][0],
                                           eb.points[sj+1][1] - eb.points[sj][1])
                        if len_a >= len_b:
                            crossings.append((i, j, pt[0], pt[1]))
                        else:
                            crossings.append((j, i, pt[0], pt[1]))
    return crossings


def _seg_intersection(p1, p2, p3, p4):
    x1, y1 = p1; x2, y2 = p2
    x3, y3 = p3; x4, y4 = p4
    denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if abs(denom) < 1e-10:
        return None
    t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
    u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / denom
    if 0.01 < t < 0.99 and 0.01 < u < 0.99:
        return (x1 + t * (x2 - x1), y1 + t * (y2 - y1))
    return None


def _route_around(p1, p2, obstacles):
    x1, y1 = p1; x2, y2 = p2
    for route in [
        [(x1, y1), (x2, y1), (x2, y2)],
        [(x1, y1), (x1, y2), (x2, y2)],
    ]:
        if not _route_hits_any(route, obstacles):
            return route
    mid_x, mid_y = (x1 + x2) / 2, (y1 + y2) / 2
    for route in [
        [(x1, y1), (mid_x, y1), (mid_x, y2), (x2, y2)],
        [(x1, y1), (x1, mid_y), (x2, mid_y), (x2, y2)],
    ]:
        if not _route_hits_any(route, obstacles):
            return route
    return [p1, p2]


def _route_hits_any(route, obstacles):
    for i in range(len(route) - 1):
        for obs in obstacles:
            if _segment_intersects_rect(route[i], route[i + 1], obs):
                return True
    return False


def _segment_intersects_rect(p1, p2, node, margin=8):
    x1, y1 = p1; x2, y2 = p2
    rx = node.x - margin; ry = node.y - margin
    rw = node.w + margin * 2; rh = node.h + margin * 2

    def code(x, y):
        c = 0
        if x < rx: c |= 1
        elif x > rx + rw: c |= 2
        if y < ry: c |= 4
        elif y > ry + rh: c |= 8
        return c

    c1, c2 = code(x1, y1), code(x2, y2)
    for _ in range(20):
        if not (c1 | c2): return True
        if c1 & c2: return False
        c = c1 or c2
        dx = (x2 - x1) or 1e-10; dy = (y2 - y1) or 1e-10
        if c & 8:   x = x1 + dx * (ry + rh - y1) / dy; y = ry + rh
        elif c & 4: x = x1 + dx * (ry - y1) / dy;      y = ry
        elif c & 2: y = y1 + dy * (rx + rw - x1) / dx; x = rx + rw
        elif c & 1: y = y1 + dy * (rx - x1) / dx;      x = rx
        if c == c1: x1, y1 = x, y; c1 = code(x1, y1)
        else:       x2, y2 = x, y; c2 = code(x2, y2)
    return False


# ════════════════════════════════════════════════════════════
#  Phase 3 — Label Placement
# ════════════════════════════════════════════════════════════

@dataclass
class Label:
    x: float
    y: float
    w: float
    h: float
    text: str

    def overlaps_node(self, node: Node, margin: float = 3) -> bool:
        return not (self.x + self.w + margin <= node.x or
                    node.right + margin <= self.x or
                    self.y + self.h + margin <= node.y or
                    node.bottom + margin <= self.y)

    def overlaps_label(self, other: "Label", margin: float = 3) -> bool:
        return not (self.x + self.w + margin <= other.x or
                    other.x + other.w + margin <= self.x or
                    self.y + self.h + margin <= other.y or
                    other.y + other.h + margin <= self.y)


def place_labels(nodes: list[Node], labels: list[Label],
                 edges: list[Edge] | None = None) -> None:
    """Place labels avoiding overlaps."""
    for label in labels:
        offsets = []
        for dist in [0, 8, 14, 20, 28, 36]:
            for angle_step in range(8):
                angle = angle_step * math.pi / 4
                dx = round(dist * math.cos(angle))
                dy = round(dist * math.sin(angle))
                if (dx, dy) not in offsets:
                    offsets.append((dx, dy))

        orig_x, orig_y = label.x, label.y
        best_pos = (orig_x, orig_y)
        best_score = float('inf')

        for dx, dy in offsets:
            label.x = orig_x + dx
            label.y = orig_y + dy

            score = 0
            for n in nodes:
                if label.overlaps_node(n, margin=2):
                    score += 10000
            for o in labels:
                if o is not label and label.overlaps_label(o, margin=2):
                    score += 100
            if edges and _label_hits_edge(label, edges):
                score += 10
            score += math.hypot(dx, dy) * 0.1

            if score < best_score:
                best_score = score
                best_pos = (label.x, label.y)

            if score == 0:
                break

        label.x, label.y = best_pos


def _label_hits_edge(label: Label, edges: list[Edge]) -> bool:
    ln = Node(name="__lbl__", x=label.x - 2, y=label.y - 2,
              w=label.w + 4, h=label.h + 4)
    for e in edges:
        for i in range(len(e.points) - 1):
            if _segment_intersects_rect(e.points[i], e.points[i + 1], ln, margin=2):
                return True
    return False