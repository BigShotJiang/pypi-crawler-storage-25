"""Diagrams package — hand-drawn style diagrams."""
