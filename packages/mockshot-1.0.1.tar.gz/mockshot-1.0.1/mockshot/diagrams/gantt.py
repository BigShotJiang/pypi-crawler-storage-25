"""Hand-drawn Gantt chart diagram."""

from __future__ import annotations

import json
from datetime import datetime, timedelta

from .sketch import SketchCanvas, measure_text


# Hatch colors for groups (subtle, hand-drawn feel)
GROUP_COLORS = [
    "#1e1e1e",  # black
    "#555555",  # dark gray
    "#888888",  # medium gray
    "#333333",  # charcoal
    "#666666",  # gray
]


def render(project_json: str, output: str = "gantt.svg", seed: int = 42) -> None:
    """Render a hand-drawn Gantt chart from JSON.

    JSON format:
    {
      "title": "Sprint 1",
      "tasks": [
        {"name": "Task", "start": "2024-03-01", "end": "2024-03-05", "group": "Phase 1", "progress": 60}
      ]
    }
    """
    proj = json.loads(project_json)
    title = proj.get("title", "Gantt Chart")
    tasks = proj.get("tasks", [])

    if not tasks:
        raise ValueError("No tasks provided")

    # Parse dates
    parsed = []
    for t in tasks:
        s = datetime.strptime(t["start"], "%Y-%m-%d")
        e = datetime.strptime(t["end"], "%Y-%m-%d")
        parsed.append({
            "name": t["name"],
            "start": s,
            "end": e,
            "group": t.get("group", ""),
            "progress": t.get("progress"),
        })

    # Date range
    min_date = min(t["start"] for t in parsed)
    max_date = max(t["end"] for t in parsed)
    total_days = (max_date - min_date).days or 1

    # Layout
    margin_left = 40
    margin_top = 70
    margin_right = 40
    margin_bottom = 40
    row_height = 40
    row_gap = 8

    # Calculate label width
    max_label = max(len(t["name"]) for t in parsed)
    label_width = max(int(max_label * 9.5), 120)

    chart_left = margin_left + label_width + 20
    chart_width = max(total_days * 35, 400)
    chart_width = min(chart_width, 900)  # cap

    width = chart_left + chart_width + margin_right
    height = margin_top + len(parsed) * (row_height + row_gap) + margin_bottom + 30

    canvas = SketchCanvas(width, height, seed=seed)

    # Title
    canvas.text(width / 2, 30, title, size=22, bold=True)

    # Date axis
    date_y = margin_top - 15

    # Determine date step based on total days
    if total_days <= 14:
        step = 1
    elif total_days <= 60:
        step = 7
    else:
        step = 14

    d = min_date
    while d <= max_date:
        day_offset = (d - min_date).days
        x = chart_left + (day_offset / total_days) * chart_width
        # Vertical grid line
        canvas.rough_line(x, margin_top - 5, x, height - margin_bottom,
                          stroke="#cccccc", stroke_width=0.5)
        # Date label
        label = d.strftime("%d/%m") if total_days <= 60 else d.strftime("%d/%m/%y")
        canvas.text(x, date_y, label, size=11, anchor="middle", fill="#666666")
        d += timedelta(days=step)

    # Horizontal baseline
    canvas.rough_line(chart_left, margin_top, chart_left + chart_width, margin_top,
                      stroke="#999999", stroke_width=1)

    # Group colors mapping
    groups = list(dict.fromkeys(t["group"] for t in parsed if t["group"]))
    group_color = {g: GROUP_COLORS[i % len(GROUP_COLORS)] for i, g in enumerate(groups)}

    # Draw tasks
    for i, task in enumerate(parsed):
        y = margin_top + i * (row_height + row_gap) + 15

        # Task name
        canvas.text(margin_left + label_width, y + row_height / 2,
                    task["name"], size=15, anchor="end")

        # Bar
        start_x = chart_left + ((task["start"] - min_date).days / total_days) * chart_width
        end_x = chart_left + ((task["end"] - min_date).days / total_days) * chart_width
        bar_w = max(end_x - start_x, 8)
        bar_h = row_height * 0.65
        bar_y = y + (row_height - bar_h) / 2

        # Fill with hatch
        fill_color = "rgba(0,0,0,0.04)"
        canvas.rough_rect(start_x, bar_y, bar_w, bar_h, fill=fill_color, hatch=True)

        # Progress overlay
        if task["progress"] is not None:
            prog_w = bar_w * task["progress"] / 100
            canvas.rough_rect(start_x, bar_y, prog_w, bar_h,
                              fill="rgba(0,0,0,0.12)")

    # Legend for groups (if any)
    if groups:
        legend_y = height - margin_bottom + 5
        legend_x = chart_left
        for g in groups:
            canvas.rough_rect(legend_x, legend_y, 16, 12, hatch=True)
            canvas.text(legend_x + 24, legend_y + 6, g, size=12, anchor="start")
            legend_x += measure_text(g, 12) + 50

    canvas.save(output)
