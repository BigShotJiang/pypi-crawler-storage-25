"""Hand-drawn UML Activity Diagram."""

from __future__ import annotations

import json
import math

from .sketch import SketchCanvas, measure_text
from .layout import Node, Edge, layout_nodes, find_edge_crossings
from .routing import angle_route


# ── Node sizing ──

def _node_size(node: dict, font_size: int = 13) -> tuple[float, float]:
    """Compute bounding box for a node based on its type."""
    ntype = node.get("type", "action")
    name = node.get("name", "")

    if ntype == "initial":
        return 24, 24
    if ntype == "final":
        return 28, 28
    if ntype in ("fork", "join"):
        return 100, 10
    if ntype == "decision":
        tw = measure_text(name, font_size)
        w = max(tw + 40, 100)
        h = max(w * 0.6, 60)
        return w, h
    # action (default)
    tw = measure_text(name, font_size)
    w = max(tw + 30, 120)
    h = 44
    return w, h


# ── Drawing helpers ──

def _draw_initial(canvas: SketchCanvas, cx: float, cy: float) -> None:
    """Filled black circle for initial node."""
    canvas.rough_ellipse(cx, cy, 8, 8, fill="#1e1e1e", stroke="#1e1e1e")


def _draw_final(canvas: SketchCanvas, cx: float, cy: float) -> None:
    """Bull's eye: filled circle inside a circle."""
    canvas.rough_ellipse(cx, cy, 12, 12)
    canvas.rough_ellipse(cx, cy, 7, 7, fill="#1e1e1e", stroke="#1e1e1e")


def _draw_action(canvas: SketchCanvas, x: float, y: float, w: float, h: float,
                 name: str) -> None:
    """Rounded rectangle with centered text."""
    canvas.rough_rounded_rect(x, y, w, h, radius=10, fill="rgba(0,0,0,0.02)")
    canvas.text(x + w / 2, y + h / 2 + 2, name, size=13)


def _draw_decision(canvas: SketchCanvas, cx: float, cy: float, w: float, h: float,
                   name: str) -> None:
    """Diamond with condition text."""
    canvas.rough_diamond(cx, cy, w, h, fill="rgba(0,0,0,0.02)")
    canvas.text(cx, cy + 2, name, size=12)


def _draw_fork_join(canvas: SketchCanvas, x: float, y: float, w: float) -> None:
    """Thick horizontal bar for fork/join."""
    bar_h = 4
    cy = y + 5
    canvas.rough_line(x, cy, x + w, cy, stroke_width=4)


# ── Main render ──

def render(project_json: str, output: str = "activity.svg", seed: int = 42,
           params: dict | None = None) -> None:
    """Render a hand-drawn UML Activity diagram from JSON."""
    proj = json.loads(project_json)
    node_defs = proj.get("nodes", [])
    flows = proj.get("flows", [])

    if not node_defs:
        raise ValueError("No nodes provided")

    # ── Build nodes & edges ──
    nodes = []
    node_types: dict[str, str] = {}

    for nd in node_defs:
        w, h = _node_size(nd)
        nodes.append(Node(name=nd["name"], w=w, h=h))
        node_types[nd["name"]] = nd.get("type", "action")

    edges = []
    for flow in flows:
        edges.append(Edge(from_node=flow["from"], to_node=flow["to"]))

    # ── Layout ──
    layout_nodes(nodes, edges, margin=60, gap=80, params=params, engine="neato")
    node_map = {n.name: n for n in nodes}
    angle_route(nodes, edges, node_map, margin=30)

    # ── Canvas size ──
    max_x = max(n.x + n.w for n in nodes)
    max_y = max(n.y + n.h for n in nodes)
    for e in edges:
        for px, py in e.points:
            max_x = max(max_x, px + 60)
            max_y = max(max_y, py + 40)

    total_w = int(max_x) + 80
    total_h = int(max_y) + 80

    canvas = SketchCanvas(total_w, total_h, seed=seed)

    # ════════════════════════════════════════════
    #  Draw nodes
    # ════════════════════════════════════════════
    for n in nodes:
        ntype = node_types[n.name]
        cx = n.x + n.w / 2
        cy = n.y + n.h / 2

        if ntype == "initial":
            _draw_initial(canvas, cx, cy)
        elif ntype == "final":
            _draw_final(canvas, cx, cy)
        elif ntype == "decision":
            _draw_decision(canvas, cx, cy, n.w, n.h, n.name)
        elif ntype in ("fork", "join"):
            _draw_fork_join(canvas, n.x, n.y, n.w)
        else:  # action
            _draw_action(canvas, n.x, n.y, n.w, n.h, n.name)

    # ════════════════════════════════════════════
    #  Draw flows
    # ════════════════════════════════════════════
    for idx, edge in enumerate(edges):
        if not edge.points:
            continue
        flow = flows[idx]
        label = flow.get("label", "")

        canvas.rough_polyline_arrow(edge.points, label=label if label else None,
                                    head_type="arrow")

    # ════════════════════════════════════════════
    #  Crossing notches
    # ════════════════════════════════════════════
    crossings = find_edge_crossings(edges)
    for jumper_idx, _other_idx, cx, cy in crossings:
        e_jump = edges[jumper_idx]
        for si in range(len(e_jump.points) - 1):
            sx1, sy1 = e_jump.points[si]
            sx2, sy2 = e_jump.points[si + 1]
            if (min(sx1, sx2) - 1 <= cx <= max(sx1, sx2) + 1 and
                    min(sy1, sy2) - 1 <= cy <= max(sy1, sy2) + 1):
                canvas.draw_crossing_notch(cx, cy, sx2 - sx1, sy2 - sy1)
                break

    canvas.save(output)
