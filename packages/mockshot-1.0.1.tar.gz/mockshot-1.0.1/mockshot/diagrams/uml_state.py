"""Hand-drawn UML State Machine Diagram."""

from __future__ import annotations

import json
import math

from .sketch import SketchCanvas, measure_text
from .layout import Node, Edge, layout_nodes, find_edge_crossings
from .routing import angle_route


# ── Sizing helpers ──

INITIAL_R = 8
FINAL_R_OUTER = 12
FINAL_R_INNER = 6
STATE_PADDING_X = 24
STATE_PADDING_Y = 16
ACTION_FONT = 11
NAME_FONT = 14
SEP_GAP = 6


def _state_size(state: dict) -> tuple[float, float]:
    """Compute bounding box for a state node."""
    stype = state.get("type", "state")
    if stype == "initial":
        d = INITIAL_R * 2 + 12
        return d, d
    if stype == "final":
        d = FINAL_R_OUTER * 2 + 12
        return d, d

    name = state["name"]
    actions = state.get("actions", [])
    name_w = measure_text(name, NAME_FONT)
    w = name_w + STATE_PADDING_X * 2

    # height: name row + optional separator + actions
    h = NAME_FONT + STATE_PADDING_Y * 2
    if actions:
        h += SEP_GAP
        for _a in actions:
            h += ACTION_FONT + 4
        # also widen if actions are longer
        for a in actions:
            aw = measure_text(a, ACTION_FONT) + STATE_PADDING_X * 2
            w = max(w, aw)

    w = max(w, 100)
    h = max(h, 44)
    return w, h


def render(project_json: str, output: str = "state.svg", seed: int = 42,
           params: dict | None = None) -> None:
    """Render a hand-drawn UML State Machine diagram from JSON."""
    proj = json.loads(project_json)
    states = proj.get("states", [])
    transitions = proj.get("transitions", [])

    if not states:
        raise ValueError("No states provided")

    # ── Build nodes & edges ──
    nodes: list[Node] = []
    state_map: dict[str, dict] = {}

    for s in states:
        w, h = _state_size(s)
        nodes.append(Node(name=s["name"], w=w, h=h))
        state_map[s["name"]] = s

    edges: list[Edge] = []
    for tr in transitions:
        edges.append(Edge(from_node=tr["from"], to_node=tr["to"]))

    # ── Layout ──
    layout_nodes(nodes, edges, margin=60, gap=80, params=params, engine="neato")
    node_map = {n.name: n for n in nodes}
    angle_route(nodes, edges, node_map, margin=30)

    # ── Canvas size ──
    max_x = max(n.x + n.w for n in nodes)
    max_y = max(n.y + n.h for n in nodes)
    for e in edges:
        for px, py in e.points:
            max_x = max(max_x, px + 60)
            max_y = max(max_y, py + 40)

    total_w = int(max_x) + 80
    total_h = int(max_y) + 80

    canvas = SketchCanvas(total_w, total_h, seed=seed)

    # ════════════════════════════════════════════
    #  Draw nodes
    # ════════════════════════════════════════════
    for n in nodes:
        s = state_map[n.name]
        stype = s.get("type", "state")
        cx = n.x + n.w / 2
        cy = n.y + n.h / 2

        if stype == "initial":
            # Filled black circle
            canvas.rough_ellipse(cx, cy, INITIAL_R, INITIAL_R,
                                 fill="#1e1e1e", stroke="#1e1e1e")

        elif stype == "final":
            # Bull's eye: outer circle + filled inner circle
            canvas.rough_ellipse(cx, cy, FINAL_R_OUTER, FINAL_R_OUTER)
            canvas.rough_ellipse(cx, cy, FINAL_R_INNER, FINAL_R_INNER,
                                 fill="#1e1e1e", stroke="#1e1e1e")

        else:
            # Regular state: rounded rect
            actions = s.get("actions", [])
            canvas.rough_rounded_rect(n.x, n.y, n.w, n.h,
                                       radius=14,
                                       fill="rgba(0,0,0,0.02)")

            if not actions:
                # Name centered
                canvas.text(cx, cy + 4, s["name"], size=NAME_FONT, bold=True)
            else:
                # Name in upper compartment
                name_y = n.y + STATE_PADDING_Y + NAME_FONT / 2
                canvas.text(cx, name_y, s["name"], size=NAME_FONT, bold=True)

                # Separator line
                sep_y = name_y + NAME_FONT / 2 + SEP_GAP
                canvas.rough_line(n.x + 6, sep_y, n.x + n.w - 6, sep_y)

                # Actions
                ay = sep_y + ACTION_FONT + 2
                for action in actions:
                    canvas.text(cx, ay, action, size=ACTION_FONT)
                    ay += ACTION_FONT + 4

    # ════════════════════════════════════════════
    #  Draw transitions
    # ════════════════════════════════════════════
    for idx, edge in enumerate(edges):
        if not edge.points:
            continue
        tr = transitions[idx]
        label = tr.get("label", "")
        canvas.rough_polyline_arrow(edge.points, label=label or None,
                                     head_type="arrow")

    # ════════════════════════════════════════════
    #  Crossing notches
    # ════════════════════════════════════════════
    crossings = find_edge_crossings(edges)
    for jumper_idx, _other_idx, cx, cy in crossings:
        e_jump = edges[jumper_idx]
        for si in range(len(e_jump.points) - 1):
            sx1, sy1 = e_jump.points[si]
            sx2, sy2 = e_jump.points[si + 1]
            if (min(sx1, sx2) - 1 <= cx <= max(sx1, sx2) + 1 and
                    min(sy1, sy2) - 1 <= cy <= max(sy1, sy2) + 1):
                canvas.draw_crossing_notch(cx, cy, sx2 - sx1, sy2 - sy1)
                break

    canvas.save(output)
