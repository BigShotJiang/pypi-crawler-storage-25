"""Hand-drawn UML Sequence Diagram."""

from __future__ import annotations

import json

from .sketch import SketchCanvas, measure_text


# ── Layout constants ──
PARTICIPANT_GAP = 160      # horizontal spacing between participants
PARTICIPANT_TOP = 40       # y of participant boxes
BOX_PAD_X = 16             # horizontal padding inside participant box
BOX_HEIGHT = 36            # participant box height
ACTOR_HEIGHT = 70          # stick figure total height (head+body+legs)
MSG_START_Y = 130          # y where first message arrow starts
MSG_STEP = 45              # vertical spacing between messages
SELF_LOOP_W = 40           # width of self-message loop
SELF_LOOP_H = 28           # height of self-message loop
ACTIVATION_W = 12          # width of activation box on lifeline
MARGIN_X = 60              # left margin
MARGIN_BOTTOM = 60         # bottom margin


def _draw_stick_figure(canvas: SketchCanvas, cx: float, top_y: float,
                       name: str) -> None:
    """Draw a hand-drawn stick figure with name below."""
    head_r = 8
    head_cy = top_y + head_r
    canvas.rough_ellipse(cx, head_cy, head_r, head_r)

    body_top = head_cy + head_r
    body_bottom = body_top + 22
    canvas.rough_line(cx, body_top, cx, body_bottom)

    arm_y = body_top + 8
    canvas.rough_line(cx - 14, arm_y, cx + 14, arm_y)

    canvas.rough_line(cx, body_bottom, cx - 12, body_bottom + 16)
    canvas.rough_line(cx, body_bottom, cx + 12, body_bottom + 16)

    canvas.text(cx, body_bottom + 28, name, size=13)


def render(project_json: str, output: str = "sequence.svg", seed: int = 42) -> None:
    """Render a hand-drawn UML Sequence diagram from JSON."""
    proj = json.loads(project_json)
    participants = proj.get("participants", [])
    messages = proj.get("messages", [])

    if not participants:
        raise ValueError("No participants provided")

    # ── Compute participant positions ──
    # Calculate box widths based on name length
    part_info: list[dict] = []
    for p in participants:
        name = p["name"]
        ptype = p.get("type", "object")
        tw = measure_text(name, 13)
        box_w = max(tw + BOX_PAD_X * 2, 80)
        part_info.append({"name": name, "type": ptype, "box_w": box_w})

    # Position participants evenly
    x_cursor = MARGIN_X
    name_to_x: dict[str, float] = {}
    for pi in part_info:
        cx = x_cursor + pi["box_w"] / 2
        pi["cx"] = cx
        name_to_x[pi["name"]] = cx
        x_cursor += pi["box_w"] + PARTICIPANT_GAP - pi["box_w"]  # simplify
        x_cursor = pi["cx"] + PARTICIPANT_GAP / 2 + pi["box_w"] / 2

    # Recalculate: just space them evenly
    for i, pi in enumerate(part_info):
        cx = MARGIN_X + pi["box_w"] / 2 + i * PARTICIPANT_GAP
        pi["cx"] = cx
        name_to_x[pi["name"]] = cx

    # ── Canvas dimensions ──
    max_x = max(pi["cx"] + pi["box_w"] / 2 for pi in part_info) + MARGIN_X
    lifeline_bottom = MSG_START_Y + len(messages) * MSG_STEP + MARGIN_BOTTOM
    total_w = int(max_x)
    total_h = int(lifeline_bottom)

    canvas = SketchCanvas(total_w, total_h, seed=seed)

    # ── Draw participant boxes / actors at top ──
    for pi in part_info:
        cx = pi["cx"]
        bw = pi["box_w"]
        if pi["type"] == "actor":
            _draw_stick_figure(canvas, cx, PARTICIPANT_TOP, pi["name"])
        else:
            bx = cx - bw / 2
            by = PARTICIPANT_TOP
            canvas.rough_rect(bx, by, bw, BOX_HEIGHT, fill="rgba(0,0,0,0.02)")
            canvas.text(cx, by + BOX_HEIGHT / 2 + 2, pi["name"], size=13)

    # ── Draw lifelines (dashed vertical lines) ──
    for pi in part_info:
        cx = pi["cx"]
        if pi["type"] == "actor":
            line_top = PARTICIPANT_TOP + ACTOR_HEIGHT + 10
        else:
            line_top = PARTICIPANT_TOP + BOX_HEIGHT
        canvas.rough_line(cx, line_top, cx, lifeline_bottom - 20, dash="6,4")

    # ── Track activations ──
    # Simple: a participant is "active" from receiving a sync until sending a reply
    # We won't do full activation tracking — just draw thin boxes for visual effect
    # when a sync message is received.

    # ── Draw messages ──
    for i, msg in enumerate(messages):
        y = MSG_START_Y + i * MSG_STEP
        from_name = msg["from"]
        to_name = msg["to"]
        label = msg.get("label", "")
        mtype = msg.get("type", "sync")

        from_x = name_to_x.get(from_name, 0)
        to_x = name_to_x.get(to_name, 0)

        if from_name == to_name:
            # Self message: small loop going right and back
            x = from_x
            pts = [
                (x, y),
                (x + SELF_LOOP_W, y),
                (x + SELF_LOOP_W, y + SELF_LOOP_H),
                (x, y + SELF_LOOP_H),
            ]
            dash = "6,4" if mtype == "reply" else None
            canvas.rough_polyline_arrow(pts, dash=dash, head_type="arrow", radius=6)
            # Label to the right of the loop
            canvas.text(x + SELF_LOOP_W + 6, y + SELF_LOOP_H / 2, label,
                        size=12, anchor="start")
        else:
            dash = "6,4" if mtype == "reply" else None
            head = "arrow"
            pts = [(from_x, y), (to_x, y)]
            canvas.rough_polyline_arrow(pts, dash=dash, head_type=head, radius=0)
            # Label above the arrow
            mx = (from_x + to_x) / 2
            canvas.text(mx, y - 10, label, size=12)

    canvas.save(output)
