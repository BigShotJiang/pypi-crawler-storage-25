"""Hand-drawn UML Class Diagram with smart layout."""

from __future__ import annotations

import json

from .sketch import SketchCanvas, measure_text
from .layout import Node, Edge, Label, layout_nodes, place_labels, find_edge_crossings
from .routing import angle_route


def _class_size(cls: dict, font_size: int = 14) -> tuple[float, float]:
    """Calculate class box size based on content with proper padding."""
    name = cls["name"]
    stereotype = cls.get("stereotype")
    attrs = cls.get("attrs", [])
    methods = cls.get("methods", [])
    pad = 6

    all_text = [name] + attrs + methods
    if stereotype:
        all_text.append(f"<<{stereotype}>>")
    max_text = max(all_text, key=len) if all_text else name
    # 12px left margin for attrs/methods + padding both sides
    w = max(measure_text(max_text, font_size) + 12 + pad * 2, 140)

    header_h = 36 if not stereotype else 50
    attrs_h = max(len(attrs) * 20 + pad * 2, 20 + pad)
    methods_h = max(len(methods) * 20 + pad * 2, 20 + pad)
    h = header_h + attrs_h + methods_h

    return w, h


def render(project_json: str, output: str = "class.svg", seed: int = 42, params: dict | None = None) -> None:
    """Render a hand-drawn UML class diagram from JSON."""
    proj = json.loads(project_json)
    classes = proj.get("classes", [])
    relations = proj.get("relations", [])

    if not classes:
        raise ValueError("No classes provided")

    # ── Phase 1: Build nodes & edges ──
    class_sizes = {c["name"]: _class_size(c) for c in classes}

    nodes = []
    for c in classes:
        w, h = class_sizes[c["name"]]
        nodes.append(Node(name=c["name"], w=w, h=h))

    edges = []
    for rel in relations:
        edges.append(Edge(from_node=rel["from"], to_node=rel["to"]))

    # ── Phase 2: Layout ──
    layout_nodes(nodes, edges, margin=40, gap=50, params=params, engine="neato")
    node_map = {n.name: n for n in nodes}
    angle_route(nodes, edges, node_map, margin=30)

    # ── Phase 3: Compute canvas size ──
    # Include routed edge points in bounds calculation
    max_x = max(n.x + n.w for n in nodes)
    max_y = max(n.y + n.h for n in nodes)
    for e in edges:
        for px, py in e.points:
            max_x = max(max_x, px)
            max_y = max(max_y, py)

    total_w = int(max_x) + 60
    total_h = int(max_y) + 60

    canvas = SketchCanvas(total_w, total_h, seed=seed)
    edge_map = {(e.from_node, e.to_node): e for e in edges}

    # ── Draw classes ──
    for c in classes:
        n = node_map[c["name"]]
        x, y, w, h = n.x, n.y, n.w, n.h
        stereotype = c.get("stereotype")
        attrs = c.get("attrs", [])
        methods = c.get("methods", [])

        canvas.rough_rect(x, y, w, h, fill="rgba(0,0,0,0.02)")

        header_h = 36 if not stereotype else 50

        if stereotype:
            canvas.text(x + w / 2, y + 15, f"«{stereotype}»", size=12)
            canvas.text(x + w / 2, y + 33, c["name"], size=16, bold=True)
        else:
            canvas.text(x + w / 2, y + 20, c["name"], size=16, bold=True)

        sep1_y = y + header_h
        canvas.rough_line(x, sep1_y, x + w, sep1_y)

        attr_y = sep1_y + 6
        for attr in attrs:
            attr_y += 18
            canvas.text(x + 12, attr_y, attr, size=13, anchor="start")

        sep2_y = sep1_y + max(len(attrs) * 20 + 10, 20)
        canvas.rough_line(x, sep2_y, x + w, sep2_y)

        method_y = sep2_y + 6
        for method in methods:
            method_y += 18
            canvas.text(x + 12, method_y, method, size=13, anchor="start")

    # ── Draw relations with routed edges ──
    labels_to_place: list[Label] = []

    for rel in relations:
        from_name = rel["from"]
        to_name = rel["to"]
        rel_type = rel.get("type", "association")

        edge = edge_map.get((from_name, to_name))
        if not edge or not edge.points:
            continue

        dash = "8,4" if rel_type in ("implementation", "dependency") else None

        # Head type
        head_map = {
            "inheritance": "triangle",
            "implementation": "triangle",
            "composition": "diamond_filled",
            "aggregation": "diamond",
            "dependency": "arrow",
        }
        head = head_map.get(rel_type, "none")

        canvas.rough_polyline_arrow(edge.points, label=rel.get("label"),
                                    dash=dash, head_type=head)

        # Cardinalities
        from_card = rel.get("from_card", "")
        to_card = rel.get("to_card", "")

        if from_card and len(edge.points) >= 2:
            p = edge.points[0]
            p_next = edge.points[1]
            ox, oy = _label_offset(p, p_next)
            lbl = Label(x=ox, y=oy, w=measure_text(from_card, 12), h=14, text=from_card)
            labels_to_place.append(lbl)

        if to_card and len(edge.points) >= 2:
            p = edge.points[-1]
            p_prev = edge.points[-2]
            ox, oy = _label_offset(p, p_prev)
            lbl = Label(x=ox, y=oy, w=measure_text(to_card, 12), h=14, text=to_card)
            labels_to_place.append(lbl)

    # ── Phase 4: Place labels without overlap ──
    place_labels(nodes, labels_to_place, edges)

    for lbl in labels_to_place:
        # White background behind cardinality for readability
        tw = lbl.w + 6
        th = lbl.h + 4
        canvas.elements.append(
            f'<rect x="{lbl.x - 3:.1f}" y="{lbl.y - lbl.h / 2 - 2:.1f}" '
            f'width="{tw:.1f}" height="{th:.1f}" '
            f'fill="white" stroke="none"/>')
        canvas.text(lbl.x, lbl.y, lbl.text, size=12, anchor="start")

    # ── Phase 5: Draw crossing notches ──
    crossings = find_edge_crossings(edges)
    for _ea_idx, _eb_idx, cx, cy in crossings:
        # Notch on the second edge (the one that goes "under")
        eb = edges[_eb_idx]
        # Find the segment direction at the crossing
        for si in range(len(eb.points) - 1):
            sx1, sy1 = eb.points[si]
            sx2, sy2 = eb.points[si + 1]
            # Check if crossing is on this segment
            if (min(sx1, sx2) - 1 <= cx <= max(sx1, sx2) + 1 and
                    min(sy1, sy2) - 1 <= cy <= max(sy1, sy2) + 1):
                canvas.draw_crossing_notch(cx, cy, sx2 - sx1, sy2 - sy1)
                break

    canvas.save(output)


def _label_offset(port: tuple[float, float],
                  toward: tuple[float, float]) -> tuple[float, float]:
    """Position cardinality label 2px from the line, near the port (box edge).

    - 12px along the edge direction (near the box)
    - 9px perpendicular to the line (2px gap + half label height)
    """
    import math
    dx = toward[0] - port[0]
    dy = toward[1] - port[1]
    dist = math.hypot(dx, dy) or 1

    along_x = port[0] + dx / dist * 12
    along_y = port[1] + dy / dist * 12

    perp_dist = 9
    nx = -dy / dist * perp_dist
    ny = dx / dist * perp_dist

    return along_x + nx, along_y + ny
