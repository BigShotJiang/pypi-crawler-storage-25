"""Hand-drawn MCD (Modèle Conceptuel de Données) — Merise diagram with smart layout."""

from __future__ import annotations

import json
import math

from .sketch import SketchCanvas, measure_text
from .layout import Node, Edge, Label, layout_nodes, find_edge_crossings
from .routing import angle_route, _seg_intersects_rect, _segments_cross


def _entity_size(entity: dict, font_size: int = 15) -> tuple[float, float]:
    """Calculate entity box size based on content with 6px padding."""
    name = entity["name"]
    attrs = entity.get("attrs", [])
    pad = 6  # padding

    max_text = max([name] + attrs, key=len)
    w = max(measure_text(max_text, font_size) + pad * 2 + 18, 120)  # 18 for left margin
    # Header (name 18px + pad) + separator + attrs (each 22px) + bottom pad
    header_h = 32
    attrs_h = len(attrs) * 22 + pad
    h = header_h + attrs_h + pad
    return w, max(h, 60)


def _assoc_size(assoc: dict, font_size: int = 14) -> tuple[float, float]:
    """Calculate association bounding box — always rounded rectangle."""
    name = assoc["name"]
    attrs = assoc.get("attrs", [])
    pad = 3

    name_w = measure_text(name, font_size)
    if attrs:
        max_attr_w = max(measure_text(a, 12) for a in attrs)
        w = max(name_w + pad * 4, max_attr_w + 18 + pad * 2, 100)
        header_h = 30
        attrs_h = len(attrs) * 18 + pad * 2
        h = header_h + attrs_h
        return w, h
    else:
        # Rounded rectangle without attrs (no separator)
        w = max(name_w + pad * 6, 80)
        h = 36
        return w, h


def render(project_json: str, output: str = "mcd.svg", seed: int = 42, params: dict | None = None) -> None:
    """Render a hand-drawn MCD diagram from JSON.

    Pipeline séquentiel:
      Étape 1 — Entités (rectangles)
      Étape 2 — Lignes entre entités (routage, collisions résolues)
      Étape 3 — Jumps/encoches aux croisements de lignes
      Étape 4 — Cardinalités sur les lignes (collisions résolues)
      Étape 5 — Noms des liaisons sur les lignes (collisions résolues)
    """
    proj = json.loads(project_json)
    entities = proj.get("entities", [])
    associations = proj.get("associations", [])

    if not entities:
        raise ValueError("No entities provided")

    # ── Build nodes & edges ──
    nodes = []
    for e in entities:
        w, h = _entity_size(e)
        nodes.append(Node(name=e["name"], w=w, h=h))

    edges = []
    for a in associations:
        edges.append(Edge(from_node=a["from"], to_node=a["to"]))

    # ── Layout (placement only, no routing) ──
    layout_nodes(nodes, edges, margin=60, gap=100, params=params, engine="neato")

    # ── Route with angle-based face selection + perpendicular projection ──
    node_map = {n.name: n for n in nodes}
    angle_route(nodes, edges, node_map, margin=30)

    # ── Canvas size ──
    max_x = max(n.x + n.w for n in nodes)
    max_y = max(n.y + n.h for n in nodes)
    for e in edges:
        for px, py in e.points:
            max_x = max(max_x, px + 60)
            max_y = max(max_y, py + 40)

    total_w = int(max_x) + 80
    total_h = int(max_y) + 80

    canvas = SketchCanvas(total_w, total_h, seed=seed)

    # ════════════════════════════════════════════
    #  ÉTAPE 1 — Dessiner les entités (rectangles)
    # ════════════════════════════════════════════
    for e in entities:
        n = node_map[e["name"]]
        x, y, w, h = n.x, n.y, n.w, n.h
        pk = e.get("pk")

        canvas.rough_rect(x, y, w, h, fill="rgba(0,0,0,0.02)")
        canvas.text(x + w / 2, y + 18, e["name"], size=16, bold=True)

        sep_y = y + 32
        canvas.rough_line(x, sep_y, x + w, sep_y)

        for i, attr in enumerate(e.get("attrs", [])):
            ay = sep_y + 14 + i * 22
            is_pk = (attr == pk)
            canvas.text(x + 14, ay, attr, size=14, anchor="start",
                        underline=is_pk)

    # ════════════════════════════════════════════
    #  ÉTAPE 2 — Dessiner les lignes
    # ════════════════════════════════════════════
    for edge in edges:
        if edge.points:
            canvas.rough_polyline(edge.points)

    # ════════════════════════════════════════════
    #  ÉTAPE 3 — Jumps/encoches aux croisements
    # ════════════════════════════════════════════
    crossings = find_edge_crossings(edges)
    crossing_points: list[tuple[float, float]] = []
    for jumper_idx, _other_idx, cx, cy in crossings:
        crossing_points.append((cx, cy))
        e_jump = edges[jumper_idx]
        for si in range(len(e_jump.points) - 1):
            sx1, sy1 = e_jump.points[si]
            sx2, sy2 = e_jump.points[si + 1]
            if (min(sx1, sx2) - 1 <= cx <= max(sx1, sx2) + 1 and
                    min(sy1, sy2) - 1 <= cy <= max(sy1, sy2) + 1):
                canvas.draw_crossing_notch(cx, cy, sx2 - sx1, sy2 - sy1)
                break

    # ════════════════════════════════════════════
    #  ÉTAPE 4 — Cardinalités (sur les lignes, sans collision)
    # ════════════════════════════════════════════
    placed_cards: list[tuple[float, float, float, float]] = []  # (cx, cy, tw, th)

    for idx, edge in enumerate(edges):
        if not edge.points:
            continue
        a = associations[idx]
        card_from = a.get("card_from", "")
        card_to = a.get("card_to", "")

        if card_from and len(edge.points) >= 2:
            tw = measure_text(card_from, 12) + 6
            cx, cy = _place_card_on_polyline(
                edge.points, 0, tw, 18, nodes, placed_cards,
                crossing_points)
            placed_cards.append((cx, cy, tw, 18))
            canvas.elements.append(
                f'<rect x="{cx - tw/2:.1f}" y="{cy - 9:.1f}" '
                f'width="{tw:.1f}" height="18" '
                f'fill="white" stroke="none"/>')
            canvas.text(cx, cy, card_from, size=12)

        if card_to and len(edge.points) >= 2:
            tw = measure_text(card_to, 12) + 6
            cx, cy = _place_card_on_polyline(
                edge.points, -1, tw, 18, nodes, placed_cards,
                crossing_points)
            placed_cards.append((cx, cy, tw, 18))
            canvas.elements.append(
                f'<rect x="{cx - tw/2:.1f}" y="{cy - 9:.1f}" '
                f'width="{tw:.1f}" height="18" '
                f'fill="white" stroke="none"/>')
            canvas.text(cx, cy, card_to, size=12)

    # ════════════════════════════════════════════
    #  ÉTAPE 5 — Noms des liaisons (sur les lignes, sans collision)
    # ════════════════════════════════════════════
    LBL_PAD = 3  # marge interne
    placed_labels: list[tuple[float, float, float, float]] = []  # (lx, ly, lw, lh)

    for idx, edge in enumerate(edges):
        if not edge.points:
            continue
        a = associations[idx]
        assoc_name = a["name"]
        assoc_attrs = a.get("attrs", [])

        # Compute label size with internal padding
        if assoc_attrs:
            name_w = measure_text(assoc_name, 13)
            max_attr_w = max(measure_text(attr, 11) for attr in assoc_attrs)
            lbl_w = max(name_w, max_attr_w) + LBL_PAD * 2 + 14
            lbl_h = 20 + len(assoc_attrs) * 16 + LBL_PAD * 2
        else:
            name_w = measure_text(assoc_name, 13)
            lbl_w = name_w + LBL_PAD * 2 + 14
            lbl_h = 16 + LBL_PAD * 2

        # Find valid position: no collision with entities, jumps, cards, other labels
        mid_x, mid_y = _slide_label_on_polyline(
            edge.points, lbl_w, lbl_h, nodes,
            placed_labels, placed_cards,
            crossing_points, min_gap=5)
        lx = mid_x - lbl_w / 2
        ly = mid_y - lbl_h / 2
        placed_labels.append((lx, ly, lbl_w, lbl_h))

        # Draw
        if assoc_attrs:
            canvas.elements.append(
                f'<rect x="{lx:.1f}" y="{ly:.1f}" '
                f'width="{lbl_w:.1f}" height="{lbl_h:.1f}" '
                f'fill="white" stroke="none"/>')
            canvas.rough_rounded_rect(lx, ly, lbl_w, lbl_h, radius=8,
                                      fill="rgba(0,0,0,0.02)")
            canvas.text(mid_x, ly + LBL_PAD + 10, assoc_name, size=13, bold=True)
            sep_y = ly + LBL_PAD + 20
            canvas.rough_line(lx, sep_y, lx + lbl_w, sep_y)
            for i, attr in enumerate(assoc_attrs):
                canvas.text(mid_x, sep_y + 10 + i * 16, attr, size=11)
        else:
            canvas.elements.append(
                f'<rect x="{lx:.1f}" y="{ly:.1f}" '
                f'width="{lbl_w:.1f}" height="{lbl_h:.1f}" '
                f'fill="white" stroke="none"/>')
            canvas.rough_rounded_rect(lx, ly, lbl_w, lbl_h, radius=8,
                                      fill="rgba(0,0,0,0.02)")
            canvas.text(mid_x, mid_y, assoc_name, size=13, bold=True)

    canvas.save(output)


def _polyline_midpoint(points: list[tuple[float, float]]) -> tuple[float, float]:
    """Find the exact midpoint along a polyline by walking its total length."""
    if len(points) < 2:
        return points[0] if points else (0, 0)

    # Calculate total length
    total_len = 0.0
    for i in range(len(points) - 1):
        total_len += math.hypot(points[i+1][0] - points[i][0],
                                points[i+1][1] - points[i][1])

    # Walk to the midpoint
    target = total_len / 2
    walked = 0.0
    for i in range(len(points) - 1):
        seg_len = math.hypot(points[i+1][0] - points[i][0],
                             points[i+1][1] - points[i][1])
        if walked + seg_len >= target:
            # Midpoint is on this segment
            t = (target - walked) / seg_len if seg_len > 0 else 0.5
            mx = points[i][0] + (points[i+1][0] - points[i][0]) * t
            my = points[i][1] + (points[i+1][1] - points[i][1]) * t
            return mx, my
        walked += seg_len

    # Fallback
    return points[-1]


def _nudge_label(lx: float, ly: float, lw: float, lh: float,
                 placed: list[tuple[float, float, float, float]],
                 max_tries: int = 20) -> tuple[float, float]:
    """Shift label position to avoid overlapping with previously placed labels."""
    def overlaps(ax, ay):
        for px, py, pw, ph in placed:
            if not (ax + lw + 4 < px or px + pw + 4 < ax or
                    ay + lh + 4 < py or py + ph + 4 < ay):
                return True
        return False

    if not overlaps(lx, ly):
        return lx, ly

    # Try shifting in expanding circles
    for r in range(1, max_tries):
        for dx, dy in [(0, -1), (0, 1), (-1, 0), (1, 0),
                       (-1, -1), (1, -1), (-1, 1), (1, 1)]:
            nx = lx + dx * r * 12
            ny = ly + dy * r * 12
            if not overlaps(nx, ny):
                return nx, ny

    return lx, ly  # fallback


def _slide_label_on_polyline(points: list[tuple[float, float]],
                              lbl_w: float, lbl_h: float,
                              nodes: list, placed_labels: list,
                              placed_cards: list,
                              crossing_points: list[tuple[float, float]],
                              min_gap: float = 5) -> tuple[float, float]:
    """Find the best position for a label centered ON its polyline.

    Walks along the polyline and returns the (cx, cy) position where:
    - The label rect doesn't collide with any entity box (min_gap clearance)
    - The label rect doesn't collide with any crossing/jump point (min_gap)
    - The label rect doesn't collide with any previously placed label (min_gap)
    - The label rect doesn't collide with any placed cardinality (min_gap)
    Starts from midpoint and expands outward in both directions.
    """
    # Compute total polyline length and sample positions every 3px
    total_len = 0.0
    seg_lengths = []
    for i in range(len(points) - 1):
        sl = math.hypot(points[i+1][0] - points[i][0],
                        points[i+1][1] - points[i][1])
        seg_lengths.append(sl)
        total_len += sl

    if total_len < 1:
        return points[0] if points else (0, 0)

    def point_at_dist(d: float) -> tuple[float, float]:
        """Get (x, y) at distance d along polyline."""
        walked = 0.0
        for i, sl in enumerate(seg_lengths):
            if walked + sl >= d:
                t = (d - walked) / sl if sl > 0 else 0.5
                return (points[i][0] + (points[i+1][0] - points[i][0]) * t,
                        points[i][1] + (points[i+1][1] - points[i][1]) * t)
            walked += sl
        return points[-1]

    def is_valid(cx, cy):
        lx, ly = cx - lbl_w / 2, cy - lbl_h / 2
        lx2, ly2 = lx + lbl_w, ly + lbl_h

        # Check entity box collision (min_gap clearance)
        for n in nodes:
            if not (lx2 + min_gap < n.x or n.x + n.w + min_gap < lx or
                    ly2 + min_gap < n.y or n.y + n.h + min_gap < ly):
                return False

        # Check crossing/jump collision (min_gap clearance)
        for cpx, cpy in crossing_points:
            if lx - min_gap <= cpx <= lx2 + min_gap and \
               ly - min_gap <= cpy <= ly2 + min_gap:
                return False

        # Check other placed labels collision (min_gap clearance)
        for px, py, pw, ph in placed_labels:
            if not (lx2 + min_gap < px or px + pw + min_gap < lx or
                    ly2 + min_gap < py or py + ph + min_gap < ly):
                return False

        # Check placed cardinalities collision (min_gap clearance)
        for ccx, ccy, cw, ch in placed_cards:
            cx1, cy1 = ccx - cw / 2, ccy - ch / 2
            cx2, cy2 = ccx + cw / 2, ccy + ch / 2
            if not (lx2 + min_gap < cx1 or cx2 + min_gap < lx or
                    ly2 + min_gap < cy1 or cy2 + min_gap < ly):
                return False

        return True

    # Start from midpoint, expand outward in both directions (step 3px)
    mid_d = total_len / 2
    # Keep labels away from the very ends (at least lbl_w/2 + 20 from endpoints)
    margin = lbl_w / 2 + 20
    for offset in range(0, int(total_len / 2), 3):
        for sign in (0, 1, -1) if offset == 0 else (1, -1):
            d = mid_d + sign * offset
            if d < margin or d > total_len - margin:
                continue
            cx, cy = point_at_dist(d)
            if is_valid(cx, cy):
                return cx, cy

    # Fallback: midpoint even if not perfect
    return point_at_dist(mid_d)


def _avoid_lines(lx: float, ly: float, lw: float, lh: float,
                 edges: list, own_idx: int) -> tuple[float, float]:
    """Shift label if a line from another edge passes through the label rect."""
    for idx, edge in enumerate(edges):
        if idx == own_idx or not edge.points:
            continue
        for si in range(len(edge.points) - 1):
            sx1, sy1 = edge.points[si]
            sx2, sy2 = edge.points[si + 1]
            # Check if segment intersects the label bounding box (with 3px margin)
            if _seg_intersects_rect(sx1, sy1, sx2, sy2,
                                     lx - 3, ly - 3, lw + 6, lh + 6):
                # Shift perpendicular to the segment
                if abs(sy2 - sy1) < abs(sx2 - sx1):
                    # Mostly horizontal line → shift label vertically
                    ly += 14
                else:
                    # Mostly vertical line → shift label horizontally
                    lx += 14
                return lx, ly
    return lx, ly


def _seg_intersects_rect(sx1: float, sy1: float, sx2: float, sy2: float,
                          rx: float, ry: float, rw: float, rh: float) -> bool:
    """Check if a line segment intersects a rectangle."""
    # Quick bounding box check
    seg_xmin, seg_xmax = min(sx1, sx2), max(sx1, sx2)
    seg_ymin, seg_ymax = min(sy1, sy2), max(sy1, sy2)
    if seg_xmax < rx or seg_xmin > rx + rw or seg_ymax < ry or seg_ymin > ry + rh:
        return False

    # Check if segment endpoints are inside rect
    def inside(px, py):
        return rx <= px <= rx + rw and ry <= py <= ry + rh
    if inside(sx1, sy1) or inside(sx2, sy2):
        return True

    # Check segment against all 4 rect edges
    rect_edges = [
        ((rx, ry), (rx + rw, ry)),           # top
        ((rx, ry + rh), (rx + rw, ry + rh)), # bottom
        ((rx, ry), (rx, ry + rh)),           # left
        ((rx + rw, ry), (rx + rw, ry + rh)), # right
    ]
    for (ex1, ey1), (ex2, ey2) in rect_edges:
        if _segments_cross(sx1, sy1, sx2, sy2, ex1, ey1, ex2, ey2):
            return True
    return False


def _segments_cross(ax1, ay1, ax2, ay2, bx1, by1, bx2, by2) -> bool:
    """Check if two segments cross (proper intersection)."""
    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    d1 = cross((bx1, by1), (bx2, by2), (ax1, ay1))
    d2 = cross((bx1, by1), (bx2, by2), (ax2, ay2))
    d3 = cross((ax1, ay1), (ax2, ay2), (bx1, by1))
    d4 = cross((ax1, ay1), (ax2, ay2), (bx2, by2))

    if ((d1 > 0 and d2 < 0) or (d1 < 0 and d2 > 0)) and \
       ((d3 > 0 and d4 < 0) or (d3 < 0 and d4 > 0)):
        return True
    return False


def _place_card_on_polyline(points: list[tuple[float, float]], end: int,
                            tw: float, th: float,
                            nodes: list,
                            placed_cards: list[tuple[float, float, float, float]],
                            crossing_points: list[tuple[float, float]] = None,
                            min_gap: float = 6) -> tuple[float, float]:
    """Place cardinality ON the polyline, near its box endpoint.

    end=0  → near first point (FROM entity)
    end=-1 → near last point (TO entity)

    Walks along the polyline from the port outward, pixel by pixel, and returns
    the first position where the cardinality rect:
    - Is fully outside ALL entity boxes (1px clearance)
    - Has at least min_gap px distance from all previously placed cardinalities
    - Doesn't collide with any crossing/jump point (5px clearance)
    Always stays ON the polyline.
    """
    if crossing_points is None:
        crossing_points = []

    # Build ordered list of segments from the port end
    if end == 0:
        segs = [(points[i], points[i + 1]) for i in range(len(points) - 1)]
    else:
        segs = [(points[i + 1], points[i]) for i in range(len(points) - 2, -1, -1)]

    def is_valid(cx, cy):
        x1, y1 = cx - tw / 2, cy - th / 2
        x2, y2 = cx + tw / 2, cy + th / 2
        # Check entity collision (1px clearance)
        for n in nodes:
            if not (x2 + 1 < n.x or n.x + n.w + 1 < x1 or
                    y2 + 1 < n.y or n.y + n.h + 1 < y1):
                return False
        # Check min_gap from other placed cardinalities
        for px, py, pw, ph in placed_cards:
            r1 = (x1, y1, x2, y2)
            r2 = (px - pw / 2, py - ph / 2, px + pw / 2, py + ph / 2)
            if not (r1[2] + min_gap < r2[0] or r2[2] + min_gap < r1[0] or
                    r1[3] + min_gap < r2[1] or r2[3] + min_gap < r1[1]):
                return False
        # Check crossing/jump collision (5px clearance)
        for cpx, cpy in crossing_points:
            if x1 - 5 <= cpx <= x2 + 5 and y1 - 5 <= cpy <= y2 + 5:
                return False
        return True

    # Walk along segments from the port, 1px at a time
    for p_start, p_end in segs:
        dx = p_end[0] - p_start[0]
        dy = p_end[1] - p_start[1]
        seg_len = math.hypot(dx, dy)
        if seg_len < 1:
            continue
        ux, uy = dx / seg_len, dy / seg_len

        for offset in range(0, int(seg_len) + 1):
            cx = p_start[0] + ux * offset
            cy = p_start[1] + uy * offset
            if is_valid(cx, cy):
                return cx, cy

    # Fallback: 15px from port along first segment
    p_start, p_end = segs[0]
    dx = p_end[0] - p_start[0]
    dy = p_end[1] - p_start[1]
    dist = math.hypot(dx, dy) or 1
    return p_start[0] + dx / dist * 15, p_start[1] + dy / dist * 15


def _card_on_line(port: tuple[float, float],
                  toward: tuple[float, float]) -> tuple[float, float]:
    """Position cardinality label centered ON the line, at 30% of the segment.

    Returns center point of the label — always on the line itself.
    """
    # Place at 30% of the segment from port toward the next point
    t = 0.3
    x = port[0] + (toward[0] - port[0]) * t
    y = port[1] + (toward[1] - port[1]) * t

    return x, y
