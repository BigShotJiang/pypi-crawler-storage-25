"""Hand-drawn UML Component Diagram."""

from __future__ import annotations

import json
import math

from .sketch import SketchCanvas, measure_text
from .layout import Node, Edge, layout_nodes, find_edge_crossings
from .routing import angle_route


def _component_size(comp: dict, font_size: int = 14) -> tuple[float, float]:
    """Bounding box for a component."""
    name = comp["name"]
    stereotype = comp.get("stereotype")
    tw = measure_text(name, font_size)
    w = max(tw + 50, 130)  # extra space for the component icon on left
    h = 60
    if stereotype:
        st_w = measure_text(f"«{stereotype}»", 11)
        w = max(w, st_w + 50)
        h = 72
    return w, h


def _draw_component_icon(canvas: SketchCanvas, x: float, y: float) -> None:
    """Draw a small UML component icon (rectangle with two small tabs on left)."""
    # Main small rect
    iw, ih = 16, 14
    canvas.rough_rect(x, y, iw, ih)
    # Two small tabs on the left edge
    tw, th = 8, 4
    canvas.rough_rect(x - tw / 2, y + 2, tw, th, fill="rgba(255,255,255,0.9)")
    canvas.rough_rect(x - tw / 2, y + ih - 6, tw, th, fill="rgba(255,255,255,0.9)")


def _draw_component(canvas: SketchCanvas, n: Node, comp: dict) -> None:
    """Draw a component box with icon and optional stereotype."""
    canvas.rough_rect(n.x, n.y, n.w, n.h, fill="rgba(0,0,0,0.02)")

    # Component icon in top-left area
    _draw_component_icon(canvas, n.x + 8, n.y + 6)

    cx = n.x + n.w / 2
    stereotype = comp.get("stereotype")
    if stereotype:
        canvas.text(cx, n.y + n.h / 2 - 6, f"«{stereotype}»", size=11)
        canvas.text(cx, n.y + n.h / 2 + 12, comp["name"], size=14, bold=True)
    else:
        canvas.text(cx, n.y + n.h / 2 + 4, comp["name"], size=14, bold=True)


def _draw_interface_lollipop(canvas: SketchCanvas, iface: dict,
                              comp_node: Node) -> None:
    """Draw a provided interface as a lollipop (line + small circle) on the component."""
    # Place on the right side of the component
    port_x = comp_node.x + comp_node.w
    port_y = comp_node.y + comp_node.h / 2
    line_len = 25
    end_x = port_x + line_len

    canvas.rough_line(port_x, port_y, end_x, port_y)
    canvas.rough_ellipse(end_x + 6, port_y, 6, 6, fill="rgba(255,255,255,0.9)")

    # Label
    canvas.text(end_x + 6, port_y - 14, iface["name"], size=11)


def render(project_json: str, output: str = "component.svg",
           seed: int = 42, params: dict | None = None) -> None:
    """Render a hand-drawn UML Component diagram from JSON."""
    proj = json.loads(project_json)
    components = proj.get("components", [])
    interfaces = proj.get("interfaces", [])
    dependencies = proj.get("dependencies", [])

    if not components:
        raise ValueError("No components provided")

    # ── Build nodes & edges ──
    nodes = []
    comp_map: dict[str, dict] = {}

    for comp in components:
        w, h = _component_size(comp)
        nodes.append(Node(name=comp["name"], w=w, h=h))
        comp_map[comp["name"]] = comp

    edges = []
    for dep in dependencies:
        edges.append(Edge(from_node=dep["from"], to_node=dep["to"]))

    # ── Layout ──
    layout_nodes(nodes, edges, margin=80, gap=100, params=params, engine="neato")
    node_map = {n.name: n for n in nodes}
    angle_route(nodes, edges, node_map, margin=30)

    # ── Canvas size ──
    max_x = max(n.x + n.w for n in nodes) if nodes else 400
    max_y = max(n.y + n.h for n in nodes) if nodes else 300
    for e in edges:
        for px, py in e.points:
            max_x = max(max_x, px + 60)
            max_y = max(max_y, py + 40)

    # Extra space for interface lollipops
    if interfaces:
        max_x += 60

    total_w = int(max_x) + 80
    total_h = int(max_y) + 80

    canvas = SketchCanvas(total_w, total_h, seed=seed)

    # ── Draw components ──
    for n in nodes:
        comp = comp_map[n.name]
        _draw_component(canvas, n, comp)

    # ── Draw interfaces (lollipops) ──
    for iface in interfaces:
        comp_name = iface.get("component")
        if comp_name and comp_name in node_map:
            _draw_interface_lollipop(canvas, iface, node_map[comp_name])

    # ── Draw dependencies (dashed arrows) ──
    for idx, edge in enumerate(edges):
        if not edge.points:
            continue
        dep = dependencies[idx]
        label = dep.get("label", "")
        canvas.rough_polyline_arrow(edge.points, label=label,
                                     dash="6,4", head_type="arrow")

    # ── Draw crossing notches ──
    crossings = find_edge_crossings(edges)
    for jumper_idx, _other_idx, cx, cy in crossings:
        e_jump = edges[jumper_idx]
        for si in range(len(e_jump.points) - 1):
            sx1, sy1 = e_jump.points[si]
            sx2, sy2 = e_jump.points[si + 1]
            if (min(sx1, sx2) - 1 <= cx <= max(sx1, sx2) + 1 and
                    min(sy1, sy2) - 1 <= cy <= max(sy1, sy2) + 1):
                canvas.draw_crossing_notch(cx, cy, sx2 - sx1, sy2 - sy1)
                break

    canvas.save(output)
