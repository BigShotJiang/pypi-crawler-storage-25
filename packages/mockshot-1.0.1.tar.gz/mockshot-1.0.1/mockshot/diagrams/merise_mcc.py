"""Hand-drawn MCC (Modèle Conceptuel de Communication) — Merise diagram."""

from __future__ import annotations

import json

from .sketch import SketchCanvas, measure_text
from .layout import Node, Edge, layout_nodes, find_edge_crossings
from .routing import angle_route


def _actor_size(actor: dict, font_size: int = 14) -> tuple[float, float]:
    """Ellipse size for an actor."""
    name = actor["name"]
    w = max(measure_text(name, font_size) + 30, 100)
    h = 50
    return w, h


def _domain_size(domain: dict, font_size: int = 14) -> tuple[float, float]:
    """Rounded rect size for a domain."""
    name = domain["name"]
    w = max(measure_text(name, font_size) + 30, 120)
    h = 50
    return w, h


def render(project_json: str, output: str = "mcc.svg", seed: int = 42, params: dict | None = None) -> None:
    """Render a hand-drawn MCC diagram from JSON."""
    proj = json.loads(project_json)
    actors = proj.get("actors", [])
    domains = proj.get("domains") or []
    flows = proj.get("flows", [])

    if not actors:
        raise ValueError("No actors provided")

    # ── Build nodes & edges ──
    nodes = []
    node_types: dict[str, str] = {}  # name → "actor" | "domain"

    for a in actors:
        w, h = _actor_size(a)
        nodes.append(Node(name=a["name"], w=w, h=h))
        node_types[a["name"]] = "actor"

    for d in domains:
        w, h = _domain_size(d)
        nodes.append(Node(name=d["name"], w=w, h=h))
        node_types[d["name"]] = "domain"

    edges = []
    for f in flows:
        edges.append(Edge(from_node=f["from"], to_node=f["to"]))

    # ── Layout ──
    layout_nodes(nodes, edges, margin=60, gap=100, params=params, engine="neato")
    node_map = {n.name: n for n in nodes}
    angle_route(nodes, edges, node_map, margin=30)

    # ── Canvas size ──
    max_x = max(n.x + n.w for n in nodes)
    max_y = max(n.y + n.h for n in nodes)
    for e in edges:
        for px, py in e.points:
            max_x = max(max_x, px + 60)
            max_y = max(max_y, py + 40)

    # If domains exist, add space for system frame
    sys_pad = 40 if domains else 0

    total_w = int(max_x) + 80 + sys_pad
    total_h = int(max_y) + 80 + sys_pad

    canvas = SketchCanvas(total_w, total_h, seed=seed)

    # ════════════════════════════════════════════
    #  System frame (if domains exist)
    # ════════════════════════════════════════════
    if domains:
        domain_nodes = [node_map[d["name"]] for d in domains]
        fx = min(n.x for n in domain_nodes) - 30
        fy = min(n.y for n in domain_nodes) - 40
        fw = max(n.x + n.w for n in domain_nodes) - fx + 30
        fh = max(n.y + n.h for n in domain_nodes) - fy + 30
        canvas.rough_rect(fx, fy, fw, fh, fill="rgba(0,0,0,0.01)")
        canvas.text(fx + fw / 2, fy + 14, "Système", size=14, bold=True)

    # ════════════════════════════════════════════
    #  Draw nodes
    # ════════════════════════════════════════════
    for n in nodes:
        ntype = node_types[n.name]
        cx = n.x + n.w / 2
        cy = n.y + n.h / 2

        if ntype == "actor":
            canvas.rough_ellipse(cx, cy, n.w / 2, n.h / 2,
                                 fill="rgba(0,0,0,0.02)")
            canvas.text(cx, cy + 4, n.name, size=14, bold=True)
        else:  # domain
            canvas.rough_rounded_rect(n.x, n.y, n.w, n.h, radius=10,
                                       fill="rgba(0,0,0,0.02)")
            canvas.text(cx, cy + 4, n.name, size=14, bold=True)

    # ════════════════════════════════════════════
    #  Draw flows (arrows with labels)
    # ════════════════════════════════════════════
    for idx, edge in enumerate(edges):
        if not edge.points:
            continue
        flow = flows[idx]
        label = flow.get("label", "")
        canvas.rough_polyline_arrow(edge.points, label=label,
                                     head_type="arrow")

    # ════════════════════════════════════════════
    #  Jumps
    # ════════════════════════════════════════════
    crossings = find_edge_crossings(edges)
    for jumper_idx, _other_idx, cx, cy in crossings:
        e_jump = edges[jumper_idx]
        for si in range(len(e_jump.points) - 1):
            sx1, sy1 = e_jump.points[si]
            sx2, sy2 = e_jump.points[si + 1]
            if (min(sx1, sx2) - 1 <= cx <= max(sx1, sx2) + 1 and
                    min(sy1, sy2) - 1 <= cy <= max(sy1, sy2) + 1):
                canvas.draw_crossing_notch(cx, cy, sx2 - sx1, sy2 - sy1)
                break

    canvas.save(output)
