"""Hand-drawn UML Deployment Diagram."""

from __future__ import annotations

import json
import math

from .sketch import SketchCanvas, measure_text
from .layout import Node, Edge, layout_nodes, find_edge_crossings
from .routing import angle_route


# ── Stereotypes ──
STEREOTYPE_LABELS = {
    "server": "«server»",
    "database": "«database»",
    "device": "«device»",
    "container": "«container»",
    "executionenv": "«executionEnvironment»",
    "cloud": "«cloud»",
}

# 3D box depth
DEPTH = 14


def _node_size(node: dict, font_size: int = 13) -> tuple[float, float]:
    """Compute bounding box for a deployment node (front face + 3D edges)."""
    name = node["name"]
    artifacts = node.get("artifacts", [])
    stereotype = node.get("stereotype", "")

    # Width: max of name, stereotype label, and artifact lines
    lines = [name]
    if stereotype and stereotype in STEREOTYPE_LABELS:
        lines.append(STEREOTYPE_LABELS[stereotype])
    lines.extend(artifacts)
    max_text_w = max(measure_text(line, font_size) for line in lines)
    w = max(max_text_w + 40, 140)

    # Height: stereotype + name + separator + artifacts
    h = 30  # top padding + name
    if stereotype:
        h += 18  # stereotype line
    if artifacts:
        h += 4  # separator gap
        h += len(artifacts) * 18  # each artifact
    h += 16  # bottom padding
    h = max(h, 60)

    return w, h


def _draw_3d_node(canvas: SketchCanvas, x: float, y: float,
                  w: float, h: float, node: dict,
                  font_size: int = 13) -> None:
    """Draw a 3D box node with stereotype, name, and artifacts."""
    d = DEPTH
    name = node["name"]
    artifacts = node.get("artifacts", [])
    stereotype = node.get("stereotype", "")
    stereo_label = STEREOTYPE_LABELS.get(stereotype, "")

    # Front face with light fill
    canvas.rough_rect(x, y, w, h, fill="rgba(0,0,0,0.02)")

    # 3D top edge (parallelogram top)
    canvas.rough_line(x, y, x + d, y - d)
    canvas.rough_line(x + d, y - d, x + w + d, y - d)
    canvas.rough_line(x + w + d, y - d, x + w, y)

    # 3D right edge (parallelogram right)
    canvas.rough_line(x + w, y, x + w + d, y - d)
    canvas.rough_line(x + w + d, y - d, x + w + d, y + h - d)
    canvas.rough_line(x + w + d, y + h - d, x + w, y + h)

    # Text positioning
    cx = x + w / 2
    text_y = y + 16

    # Stereotype
    if stereo_label:
        canvas.text(cx, text_y, stereo_label, size=11)
        text_y += 18

    # Node name (bold)
    canvas.text(cx, text_y, name, size=font_size, bold=True)
    text_y += 16

    # Separator + artifacts
    if artifacts:
        sep_y = text_y
        canvas.rough_line(x + 8, sep_y, x + w - 8, sep_y,
                          stroke_width=1)
        text_y += 12
        for artifact in artifacts:
            canvas.text(cx, text_y, artifact, size=11)
            text_y += 18


def render(project_json: str, output: str = "deployment.svg",
           seed: int = 42, params: dict | None = None) -> None:
    """Render a hand-drawn UML Deployment diagram from JSON."""
    proj = json.loads(project_json)
    dep_nodes = proj.get("nodes", [])
    connections = proj.get("connections", [])

    if not dep_nodes:
        raise ValueError("No nodes provided")

    # ── Build layout nodes & edges ──
    nodes = []
    for dn in dep_nodes:
        w, h = _node_size(dn)
        # Add extra space for 3D depth
        nodes.append(Node(name=dn["name"], w=w, h=h))

    edges = []
    for conn in connections:
        edges.append(Edge(from_node=conn["from"], to_node=conn["to"]))

    # ── Layout ──
    layout_nodes(nodes, edges, margin=80, gap=100, params=params, engine="neato")
    node_map = {n.name: n for n in nodes}
    angle_route(nodes, edges, node_map, margin=30)

    # ── Canvas size ──
    max_x = max(n.x + n.w + DEPTH + 20 for n in nodes)
    max_y = max(n.y + n.h + 20 for n in nodes)
    for e in edges:
        for px, py in e.points:
            max_x = max(max_x, px + 60)
            max_y = max(max_y, py + 40)

    total_w = int(max_x) + 80
    total_h = int(max_y) + 80

    # Ensure top 3D edges aren't clipped (nodes could have y near 0)
    min_y = min(n.y for n in nodes) - DEPTH
    if min_y < 20:
        offset = 20 - min_y
        for n in nodes:
            n.y += offset
        # Re-route after shifting
        angle_route(nodes, edges, node_map, margin=30)
        total_h += int(offset)

    canvas = SketchCanvas(total_w, total_h, seed=seed)

    # ── Lookup for node data ──
    dn_map = {dn["name"]: dn for dn in dep_nodes}

    # ════════════════════════════════════════════
    #  Draw nodes
    # ════════════════════════════════════════════
    for n in nodes:
        dn = dn_map[n.name]
        _draw_3d_node(canvas, n.x, n.y, n.w, n.h, dn)

    # ════════════════════════════════════════════
    #  Draw connections
    # ════════════════════════════════════════════
    for idx, edge in enumerate(edges):
        if not edge.points:
            continue
        conn = connections[idx]
        label = conn.get("label", "")
        canvas.rough_polyline_arrow(edge.points, label=label,
                                     head_type="none")

    # ════════════════════════════════════════════
    #  Jumps
    # ════════════════════════════════════════════
    crossings = find_edge_crossings(edges)
    for jumper_idx, _other_idx, cx, cy in crossings:
        e_jump = edges[jumper_idx]
        for si in range(len(e_jump.points) - 1):
            sx1, sy1 = e_jump.points[si]
            sx2, sy2 = e_jump.points[si + 1]
            if (min(sx1, sx2) - 1 <= cx <= max(sx1, sx2) + 1 and
                    min(sy1, sy2) - 1 <= cy <= max(sy1, sy2) + 1):
                canvas.draw_crossing_notch(cx, cy, sx2 - sx1, sy2 - sy1)
                break

    canvas.save(output)
