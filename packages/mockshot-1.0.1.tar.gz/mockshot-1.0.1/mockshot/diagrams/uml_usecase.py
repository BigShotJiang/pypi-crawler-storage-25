"""Hand-drawn UML Use Case Diagram."""

from __future__ import annotations

import json
import math

from .sketch import SketchCanvas, measure_text
from .layout import Node, Edge, layout_nodes, find_edge_crossings
from .routing import angle_route


def _usecase_size(uc: dict, font_size: int = 13) -> tuple[float, float]:
    """Ellipse bounding box for a use case."""
    name = uc["name"]
    w = max(measure_text(name, font_size) + 40, 120)
    h = 50
    return w, h


def _actor_size(actor: dict, font_size: int = 13) -> tuple[float, float]:
    """Bounding box for a stick figure actor (body + name below)."""
    name = actor["name"]
    tw = measure_text(name, font_size)
    w = max(tw + 10, 60)
    h = 80  # stick figure ~55px + name ~20px
    return w, h


def _draw_stick_figure(canvas: SketchCanvas, cx: float, top_y: float,
                        name: str) -> None:
    """Draw a hand-drawn stick figure with name below."""
    # Head
    head_r = 8
    head_cy = top_y + head_r
    canvas.rough_ellipse(cx, head_cy, head_r, head_r)

    # Body
    body_top = head_cy + head_r
    body_bottom = body_top + 22
    canvas.rough_line(cx, body_top, cx, body_bottom)

    # Arms
    arm_y = body_top + 8
    canvas.rough_line(cx - 14, arm_y, cx + 14, arm_y)

    # Legs
    canvas.rough_line(cx, body_bottom, cx - 12, body_bottom + 16)
    canvas.rough_line(cx, body_bottom, cx + 12, body_bottom + 16)

    # Name
    canvas.text(cx, body_bottom + 28, name, size=13)


def render(project_json: str, output: str = "usecase.svg", seed: int = 42, params: dict | None = None) -> None:
    """Render a hand-drawn UML Use Case diagram from JSON."""
    proj = json.loads(project_json)
    actors = proj.get("actors", [])
    usecases = proj.get("usecases", [])
    relations = proj.get("relations", [])
    system_name = proj.get("system", "")

    if not actors and not usecases:
        raise ValueError("No actors or usecases provided")

    # ── Build nodes & edges ──
    nodes = []
    node_types: dict[str, str] = {}  # name → "actor" | "usecase"

    for a in actors:
        w, h = _actor_size(a)
        nodes.append(Node(name=a["name"], w=w, h=h))
        node_types[a["name"]] = "actor"

    for uc in usecases:
        w, h = _usecase_size(uc)
        nodes.append(Node(name=uc["name"], w=w, h=h))
        node_types[uc["name"]] = "usecase"

    edges = []
    for rel in relations:
        edges.append(Edge(from_node=rel["from"], to_node=rel["to"]))

    # ── Layout ──
    layout_nodes(nodes, edges, margin=60, gap=80, params=params, engine="neato")
    node_map = {n.name: n for n in nodes}
    angle_route(nodes, edges, node_map, margin=30)

    # ── Canvas size ──
    max_x = max(n.x + n.w for n in nodes)
    max_y = max(n.y + n.h for n in nodes)
    for e in edges:
        for px, py in e.points:
            max_x = max(max_x, px + 60)
            max_y = max(max_y, py + 40)

    total_w = int(max_x) + 80
    total_h = int(max_y) + 80

    canvas = SketchCanvas(total_w, total_h, seed=seed)

    # ════════════════════════════════════════════
    #  System frame (around use cases)
    # ════════════════════════════════════════════
    uc_nodes = [node_map[uc["name"]] for uc in usecases]
    if uc_nodes and system_name:
        fx = min(n.x for n in uc_nodes) - 30
        fy = min(n.y for n in uc_nodes) - 40
        fw = max(n.x + n.w for n in uc_nodes) - fx + 30
        fh = max(n.y + n.h for n in uc_nodes) - fy + 30
        canvas.rough_rect(fx, fy, fw, fh, fill="rgba(0,0,0,0.01)")
        canvas.text(fx + fw / 2, fy + 16, system_name, size=15, bold=True)

    # ════════════════════════════════════════════
    #  Draw nodes
    # ════════════════════════════════════════════
    for n in nodes:
        ntype = node_types[n.name]
        cx = n.x + n.w / 2
        cy = n.y + n.h / 2

        if ntype == "actor":
            _draw_stick_figure(canvas, cx, n.y + 2, n.name)
        else:  # usecase
            canvas.rough_ellipse(cx, cy, n.w / 2, n.h / 2,
                                 fill="rgba(0,0,0,0.02)")
            canvas.text(cx, cy + 4, n.name, size=13)

    # ════════════════════════════════════════════
    #  Draw relations
    # ════════════════════════════════════════════
    for idx, edge in enumerate(edges):
        if not edge.points:
            continue
        rel = relations[idx]
        rel_type = rel.get("type", "association")

        dash = None
        head = "none"
        label = ""

        if rel_type == "include":
            dash = "6,4"
            head = "arrow"
            label = "«include»"
        elif rel_type == "extend":
            dash = "6,4"
            head = "arrow"
            label = "«extend»"
        elif rel_type == "generalization":
            head = "triangle"
        elif rel_type == "association":
            head = "none"

        canvas.rough_polyline_arrow(edge.points, label=label,
                                     dash=dash, head_type=head)

    # ════════════════════════════════════════════
    #  Jumps
    # ════════════════════════════════════════════
    crossings = find_edge_crossings(edges)
    for jumper_idx, _other_idx, cx, cy in crossings:
        e_jump = edges[jumper_idx]
        for si in range(len(e_jump.points) - 1):
            sx1, sy1 = e_jump.points[si]
            sx2, sy2 = e_jump.points[si + 1]
            if (min(sx1, sx2) - 1 <= cx <= max(sx1, sx2) + 1 and
                    min(sy1, sy2) - 1 <= cy <= max(sy1, sy2) + 1):
                canvas.draw_crossing_notch(cx, cy, sx2 - sx1, sy2 - sy1)
                break

    canvas.save(output)
