"""Hand-drawn SVG primitives — Excalidraw-style sketchy shapes."""

from __future__ import annotations

import math
import random
import xml.etree.ElementTree as ET
from pathlib import Path

from ..asset_loader import font_base64


class SketchCanvas:
    """SVG canvas that renders shapes with a hand-drawn, sketchy look.

    Every shape is drawn with slight coordinate perturbation (jitter)
    and double-pass strokes to mimic pen on paper, just like Excalidraw.
    """

    STROKE = "#1e1e1e"
    STROKE_WIDTH = 2
    FONT_FAMILY = "Virgil, Segoe Print, Comic Sans MS, cursive"
    BG = "#ffffff"

    def __init__(self, width: int = 800, height: int = 600, seed: int = 42):
        self.width = width
        self.height = height
        self.rng = random.Random(seed)
        self.elements: list[str] = []

    # ── Jitter helpers ──

    def _j(self, val: float, amount: float = 1.5) -> float:
        """Add random jitter to a coordinate."""
        return val + self.rng.uniform(-amount, amount)

    def _jp(self, x: float, y: float, amount: float = 1.5) -> tuple[float, float]:
        """Jitter a point."""
        return self._j(x, amount), self._j(y, amount)

    # ── Core path generation ──

    def _rough_line_path(self, x1: float, y1: float, x2: float, y2: float,
                         jitter: float = 1.5) -> str:
        """Generate a single sketchy line as SVG path data (cubic bezier).

        Splits the line into segments and adds slight curves.
        """
        segments = 3
        dx = (x2 - x1) / segments
        dy = (y2 - y1) / segments

        # Perturbation perpendicular to line direction
        length = math.hypot(x2 - x1, y2 - y1) or 1
        nx = -(y2 - y1) / length  # normal x
        ny = (x2 - x1) / length   # normal y

        points = [(self._j(x1, jitter * 0.5), self._j(y1, jitter * 0.5))]
        for i in range(1, segments):
            px = x1 + dx * i + nx * self.rng.uniform(-jitter, jitter)
            py = y1 + dy * i + ny * self.rng.uniform(-jitter, jitter)
            points.append((px, py))
        points.append((self._j(x2, jitter * 0.5), self._j(y2, jitter * 0.5)))

        d = f"M {points[0][0]:.1f} {points[0][1]:.1f}"
        for p in points[1:]:
            d += f" L {p[0]:.1f} {p[1]:.1f}"
        return d

    def _double_line(self, x1: float, y1: float, x2: float, y2: float,
                     jitter: float = 1.5, stroke: str | None = None,
                     stroke_width: float | None = None,
                     dash: str | None = None) -> None:
        """Draw a line with two passes for sketchy effect."""
        sw = stroke_width or self.STROKE_WIDTH
        s = stroke or self.STROKE
        for _ in range(2):
            d = self._rough_line_path(x1, y1, x2, y2, jitter)
            attrs = f'stroke="{s}" stroke-width="{sw}" fill="none"'
            if dash:
                attrs += f' stroke-dasharray="{dash}"'
            self.elements.append(f'<path d="{d}" {attrs}/>')

    # ── Public drawing methods ──

    def rough_line(self, x1: float, y1: float, x2: float, y2: float,
                   stroke: str | None = None, stroke_width: float | None = None,
                   dash: str | None = None) -> None:
        """Draw a sketchy line between two points."""
        self._double_line(x1, y1, x2, y2, stroke=stroke, stroke_width=stroke_width, dash=dash)

    def rough_polyline(self, points: list[tuple[float, float]],
                       stroke: str | None = None, stroke_width: float | None = None,
                       dash: str | None = None, radius: float = 15) -> None:
        """Draw a sketchy polyline with rounded corners at bends.

        Each bend point is replaced by a quadratic arc of the given radius.
        """
        if len(points) < 2:
            return
        s = stroke or self.STROKE
        sw = stroke_width or self.STROKE_WIDTH

        if len(points) == 2:
            self._double_line(*points[0], *points[1], stroke=s,
                              stroke_width=sw, jitter=1.0, dash=dash)
            return

        # Build SVG path with rounded corners
        for _pass in range(2):
            d = ""
            for i in range(len(points)):
                if i == 0:
                    # Start segment: from first point toward first bend
                    p_cur = points[0]
                    p_next = points[1]
                    # Shorten toward bend by radius
                    if len(points) > 2:
                        cut = self._corner_cut(p_cur, p_next, points[2], radius)
                        d = f"M {self._j(p_cur[0],0.8):.1f} {self._j(p_cur[1],0.8):.1f}"
                        d += f" L {self._j(cut[0],0.6):.1f} {self._j(cut[1],0.6):.1f}"
                    else:
                        d = f"M {self._j(p_cur[0],0.8):.1f} {self._j(p_cur[1],0.8):.1f}"
                        d += f" L {self._j(p_next[0],0.8):.1f} {self._j(p_next[1],0.8):.1f}"

                elif i == len(points) - 1:
                    # Last point: just line to it
                    p = points[i]
                    d += f" L {self._j(p[0],0.8):.1f} {self._j(p[1],0.8):.1f}"

                else:
                    # Bend point: arc from incoming cut to outgoing cut
                    p_prev = points[i - 1]
                    p_cur = points[i]
                    p_next = points[i + 1]

                    # Cut points before and after the bend
                    cut_in = self._corner_approach(p_prev, p_cur, radius)
                    cut_out = self._corner_depart(p_cur, p_next, radius)

                    # Quadratic bezier arc through the corner
                    bx, by = self._j(p_cur[0], 0.6), self._j(p_cur[1], 0.6)
                    d += f" Q {bx:.1f} {by:.1f} {self._j(cut_out[0],0.6):.1f} {self._j(cut_out[1],0.6):.1f}"

                    # Line to next cut (or end point)
                    if i < len(points) - 2:
                        next_cut = self._corner_cut(p_cur, p_next, points[i + 2], radius)
                        d += f" L {self._j(next_cut[0],0.6):.1f} {self._j(next_cut[1],0.6):.1f}"

            attrs = f'stroke="{s}" stroke-width="{sw}" fill="none"'
            if dash:
                attrs += f' stroke-dasharray="{dash}"'
            self.elements.append(f'<path d="{d}" {attrs}/>')

    def _corner_cut(self, p_before: tuple, p_corner: tuple,
                    p_after: tuple, radius: float) -> tuple[float, float]:
        """Point where we stop the line before a corner (radius px from corner)."""
        return self._corner_approach(p_before, p_corner, radius)

    def _corner_approach(self, p_from: tuple, p_corner: tuple,
                         radius: float) -> tuple[float, float]:
        """Point on segment p_from→p_corner, radius px before p_corner."""
        dx = p_corner[0] - p_from[0]
        dy = p_corner[1] - p_from[1]
        dist = math.hypot(dx, dy) or 1
        r = min(radius, dist * 0.4)  # don't overshoot short segments
        return (p_corner[0] - dx / dist * r, p_corner[1] - dy / dist * r)

    def _corner_depart(self, p_corner: tuple, p_to: tuple,
                       radius: float) -> tuple[float, float]:
        """Point on segment p_corner→p_to, radius px after p_corner."""
        dx = p_to[0] - p_corner[0]
        dy = p_to[1] - p_corner[1]
        dist = math.hypot(dx, dy) or 1
        r = min(radius, dist * 0.4)
        return (p_corner[0] + dx / dist * r, p_corner[1] + dy / dist * r)

    def rough_polyline_arrow(self, points: list[tuple[float, float]],
                             label: str | None = None,
                             stroke: str | None = None,
                             dash: str | None = None,
                             head_type: str = "arrow",
                             radius: float = 15) -> None:
        """Draw a sketchy polyline with rounded corners and an arrowhead."""
        if len(points) < 2:
            return
        self.rough_polyline(points, stroke=stroke, dash=dash, radius=radius)

        # Arrowhead at last segment
        s = stroke or self.STROKE
        x2, y2 = points[-1]
        x1, y1 = points[-2]
        angle = math.atan2(y2 - y1, x2 - x1)
        head_len = 12

        if head_type == "arrow":
            for da in [math.pi * 0.8, -math.pi * 0.8]:
                hx = x2 + head_len * math.cos(angle + da)
                hy = y2 + head_len * math.sin(angle + da)
                self._double_line(x2, y2, hx, hy, jitter=1.0, stroke=s)

        elif head_type == "triangle":
            pts = []
            for da in [math.pi * 0.85, -math.pi * 0.85]:
                hx = x2 + head_len * math.cos(angle + da)
                hy = y2 + head_len * math.sin(angle + da)
                pts.append((hx, hy))
            self._double_line(pts[0][0], pts[0][1], x2, y2, jitter=1.0, stroke=s)
            self._double_line(pts[1][0], pts[1][1], x2, y2, jitter=1.0, stroke=s)
            self._double_line(pts[0][0], pts[0][1], pts[1][0], pts[1][1], jitter=1.0, stroke=s)

        elif head_type in ("diamond", "diamond_filled"):
            dw, dh = 14, 10
            dx = math.cos(angle)
            dy = math.sin(angle)
            tip = (x2, y2)
            back = (x2 - dw * dx, y2 - dw * dy)
            mid = ((tip[0] + back[0]) / 2, (tip[1] + back[1]) / 2)
            nx, ny = -dy, dx
            p1 = (mid[0] + dh/2 * nx, mid[1] + dh/2 * ny)
            p2 = (mid[0] - dh/2 * nx, mid[1] - dh/2 * ny)
            if head_type == "diamond_filled":
                pts_str = (f"{tip[0]:.1f},{tip[1]:.1f} {p1[0]:.1f},{p1[1]:.1f} "
                           f"{back[0]:.1f},{back[1]:.1f} {p2[0]:.1f},{p2[1]:.1f}")
                self.elements.append(f'<polygon points="{pts_str}" fill="{s}" stroke="{s}" stroke-width="1"/>')
            else:
                self._double_line(*tip, *p1, jitter=0.8, stroke=s)
                self._double_line(*p1, *back, jitter=0.8, stroke=s)
                self._double_line(*back, *p2, jitter=0.8, stroke=s)
                self._double_line(*p2, *tip, jitter=0.8, stroke=s)

        if label:
            # Place label at midpoint of the whole polyline
            total = len(points)
            mid_idx = total // 2
            if total % 2 == 0:
                mx = (points[mid_idx - 1][0] + points[mid_idx][0]) / 2
                my = (points[mid_idx - 1][1] + points[mid_idx][1]) / 2
            else:
                mx, my = points[mid_idx]
            self.text(mx, my - 10, label, size=14)

    def rough_rect(self, x: float, y: float, w: float, h: float,
                   fill: str | None = None, stroke: str | None = None,
                   hatch: bool = False) -> None:
        """Draw a sketchy rectangle with optional fill/hatch."""
        if fill:
            # Light fill behind
            x1, y1 = self._jp(x, 0.5)
            x2, y2 = self._jp(x + w, 0.5)
            x3, y3 = self._jp(x + w, 0.5), self._jp(y + h, 0.5)
            x4, y4 = self._jp(x, 0.5), self._jp(y + h, 0.5)
            pts = f"{x1:.1f},{y1:.1f} {x2:.1f},{self._j(y, 0.5):.1f} " \
                  f"{self._j(x+w, 0.5):.1f},{self._j(y+h, 0.5):.1f} " \
                  f"{self._j(x, 0.5):.1f},{self._j(y+h, 0.5):.1f}"
            self.elements.append(
                f'<polygon points="{pts}" fill="{fill}" stroke="none"/>'
            )

        if hatch:
            self.hatch_fill_rect(x, y, w, h)

        # 4 edges, double pass
        s = stroke or self.STROKE
        self._double_line(x, y, x + w, y, stroke=s)        # top
        self._double_line(x + w, y, x + w, y + h, stroke=s)  # right
        self._double_line(x + w, y + h, x, y + h, stroke=s)  # bottom
        self._double_line(x, y + h, x, y, stroke=s)          # left

    def rough_ellipse(self, cx: float, cy: float, rx: float, ry: float,
                      fill: str | None = None, stroke: str | None = None) -> None:
        """Draw a sketchy ellipse."""
        s = stroke or self.STROKE
        if fill:
            self.elements.append(
                f'<ellipse cx="{cx:.1f}" cy="{cy:.1f}" rx="{rx:.1f}" ry="{ry:.1f}" '
                f'fill="{fill}" stroke="none"/>'
            )

        # Draw ellipse with two passes of imperfect arcs
        for _ in range(2):
            points = []
            num_pts = 36
            for i in range(num_pts + 1):
                angle = 2 * math.pi * i / num_pts
                px = cx + rx * math.cos(angle) + self.rng.uniform(-1.5, 1.5)
                py = cy + ry * math.sin(angle) + self.rng.uniform(-1.5, 1.5)
                points.append((px, py))

            d = f"M {points[0][0]:.1f} {points[0][1]:.1f}"
            for p in points[1:]:
                d += f" L {p[0]:.1f} {p[1]:.1f}"
            d += " Z"
            self.elements.append(
                f'<path d="{d}" stroke="{s}" stroke-width="{self.STROKE_WIDTH}" fill="none"/>'
            )

    def rough_diamond(self, cx: float, cy: float, w: float, h: float,
                      fill: str | None = None, stroke: str | None = None,
                      hatch: bool = False) -> None:
        """Draw a sketchy diamond (rhombus) — used for MCD associations."""
        hw, hh = w / 2, h / 2
        top = (cx, cy - hh)
        right = (cx + hw, cy)
        bottom = (cx, cy + hh)
        left = (cx - hw, cy)

        if fill:
            pts = (f"{self._j(top[0],0.5):.1f},{self._j(top[1],0.5):.1f} "
                   f"{self._j(right[0],0.5):.1f},{self._j(right[1],0.5):.1f} "
                   f"{self._j(bottom[0],0.5):.1f},{self._j(bottom[1],0.5):.1f} "
                   f"{self._j(left[0],0.5):.1f},{self._j(left[1],0.5):.1f}")
            self.elements.append(f'<polygon points="{pts}" fill="{fill}" stroke="none"/>')

        if hatch:
            self._hatch_fill_diamond(cx, cy, w, h)

        s = stroke or self.STROKE
        self._double_line(*top, *right, stroke=s)
        self._double_line(*right, *bottom, stroke=s)
        self._double_line(*bottom, *left, stroke=s)
        self._double_line(*left, *top, stroke=s)

    def rough_rounded_rect(self, x: float, y: float, w: float, h: float,
                           radius: float = 12, fill: str | None = None,
                           stroke: str | None = None) -> None:
        """Draw a sketchy rounded rectangle."""
        r = min(radius, w / 2, h / 2)
        if fill:
            # Fill polygon (simplified, no rounding for fill)
            pts = (f"{self._j(x+r,0.3):.1f},{self._j(y,0.3):.1f} "
                   f"{self._j(x+w-r,0.3):.1f},{self._j(y,0.3):.1f} "
                   f"{self._j(x+w,0.3):.1f},{self._j(y+r,0.3):.1f} "
                   f"{self._j(x+w,0.3):.1f},{self._j(y+h-r,0.3):.1f} "
                   f"{self._j(x+w-r,0.3):.1f},{self._j(y+h,0.3):.1f} "
                   f"{self._j(x+r,0.3):.1f},{self._j(y+h,0.3):.1f} "
                   f"{self._j(x,0.3):.1f},{self._j(y+h-r,0.3):.1f} "
                   f"{self._j(x,0.3):.1f},{self._j(y+r,0.3):.1f}")
            self.elements.append(f'<polygon points="{pts}" fill="{fill}" stroke="none"/>')

        s = stroke or self.STROKE
        sw = self.STROKE_WIDTH
        for _ in range(2):
            d = (f"M {self._j(x+r,0.8):.1f} {self._j(y,0.8):.1f}"
                 f" L {self._j(x+w-r,0.8):.1f} {self._j(y,0.8):.1f}"
                 f" Q {self._j(x+w,0.6):.1f} {self._j(y,0.6):.1f}"
                 f" {self._j(x+w,0.6):.1f} {self._j(y+r,0.6):.1f}"
                 f" L {self._j(x+w,0.8):.1f} {self._j(y+h-r,0.8):.1f}"
                 f" Q {self._j(x+w,0.6):.1f} {self._j(y+h,0.6):.1f}"
                 f" {self._j(x+w-r,0.6):.1f} {self._j(y+h,0.6):.1f}"
                 f" L {self._j(x+r,0.8):.1f} {self._j(y+h,0.8):.1f}"
                 f" Q {self._j(x,0.6):.1f} {self._j(y+h,0.6):.1f}"
                 f" {self._j(x,0.6):.1f} {self._j(y+h-r,0.6):.1f}"
                 f" L {self._j(x,0.8):.1f} {self._j(y+r,0.8):.1f}"
                 f" Q {self._j(x,0.6):.1f} {self._j(y,0.6):.1f}"
                 f" {self._j(x+r,0.6):.1f} {self._j(y,0.6):.1f} Z")
            self.elements.append(f'<path d="{d}" stroke="{s}" stroke-width="{sw}" fill="none"/>')

    def rough_arrow(self, x1: float, y1: float, x2: float, y2: float,
                    label: str | None = None, stroke: str | None = None,
                    dash: str | None = None,
                    head_type: str = "arrow") -> None:
        """Draw a sketchy arrow with optional label.

        head_type: 'arrow', 'triangle', 'diamond', 'diamond_filled', 'none'
        """
        s = stroke or self.STROKE
        self._double_line(x1, y1, x2, y2, stroke=s, dash=dash)

        # Arrowhead
        angle = math.atan2(y2 - y1, x2 - x1)
        head_len = 12

        if head_type == "arrow":
            for da in [math.pi * 0.8, -math.pi * 0.8]:
                hx = x2 + head_len * math.cos(angle + da)
                hy = y2 + head_len * math.sin(angle + da)
                self._double_line(x2, y2, hx, hy, jitter=1.0, stroke=s)

        elif head_type == "triangle":
            # Open triangle
            pts = []
            for da in [math.pi * 0.85, -math.pi * 0.85]:
                hx = x2 + head_len * math.cos(angle + da)
                hy = y2 + head_len * math.sin(angle + da)
                pts.append((hx, hy))
            self._double_line(pts[0][0], pts[0][1], x2, y2, jitter=1.0, stroke=s)
            self._double_line(pts[1][0], pts[1][1], x2, y2, jitter=1.0, stroke=s)
            self._double_line(pts[0][0], pts[0][1], pts[1][0], pts[1][1], jitter=1.0, stroke=s)

        elif head_type in ("diamond", "diamond_filled"):
            # Small diamond at the end
            dw, dh = 14, 10
            dx = math.cos(angle)
            dy = math.sin(angle)
            tip = (x2, y2)
            back = (x2 - dw * dx, y2 - dw * dy)
            mid = ((tip[0] + back[0]) / 2, (tip[1] + back[1]) / 2)
            nx, ny = -dy, dx
            p1 = (mid[0] + dh/2 * nx, mid[1] + dh/2 * ny)
            p2 = (mid[0] - dh/2 * nx, mid[1] - dh/2 * ny)

            if head_type == "diamond_filled":
                pts_str = (f"{tip[0]:.1f},{tip[1]:.1f} {p1[0]:.1f},{p1[1]:.1f} "
                           f"{back[0]:.1f},{back[1]:.1f} {p2[0]:.1f},{p2[1]:.1f}")
                self.elements.append(f'<polygon points="{pts_str}" fill="{s}" stroke="{s}" stroke-width="1"/>')
            else:
                self._double_line(*tip, *p1, jitter=0.8, stroke=s)
                self._double_line(*p1, *back, jitter=0.8, stroke=s)
                self._double_line(*back, *p2, jitter=0.8, stroke=s)
                self._double_line(*p2, *tip, jitter=0.8, stroke=s)

        if label:
            mx, my = (x1 + x2) / 2, (y1 + y2) / 2
            self.text(mx, my - 10, label, size=14)

    def text(self, x: float, y: float, content: str, size: int = 16,
             anchor: str = "middle", bold: bool = False,
             underline: bool = False, fill: str | None = None) -> None:
        """Draw text in Virgil font."""
        weight = "bold" if bold else "normal"
        f = fill or self.STROKE
        attrs = (f'x="{self._j(x, 0.5):.1f}" y="{self._j(y, 0.5):.1f}" '
                 f'font-family="{self.FONT_FAMILY}" font-size="{size}" '
                 f'font-weight="{weight}" fill="{f}" text-anchor="{anchor}" '
                 f'dominant-baseline="middle"')
        escaped = content.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        self.elements.append(f'<text {attrs}>{escaped}</text>')

        if underline:
            # Approximate text width
            char_w = size * 0.55
            text_w = len(content) * char_w
            if anchor == "middle":
                lx = x - text_w / 2
            elif anchor == "end":
                lx = x - text_w
            else:
                lx = x
            self.rough_line(lx, y + size * 0.35, lx + text_w, y + size * 0.35,
                            stroke_width=1.2)

    # ── Fill helpers ──

    def hatch_fill_rect(self, x: float, y: float, w: float, h: float,
                        angle: float = -41, gap: float = 10,
                        stroke: str | None = None) -> None:
        """Fill a rectangle area with diagonal hatch lines."""
        s = stroke or "#1e1e1e"
        rad = math.radians(angle)
        cos_a, sin_a = math.cos(rad), math.sin(rad)

        # Extend the sweep range to cover the whole rect
        diag = math.hypot(w, h)
        n_lines = int(diag / gap) + 2

        for i in range(-n_lines, n_lines):
            offset = i * gap
            # Line perpendicular sweep
            px = x + w / 2 + offset * cos_a
            py = y + h / 2 + offset * sin_a

            # Extend line far enough in both directions
            x1 = px - diag * sin_a
            y1 = py + diag * cos_a
            x2 = px + diag * sin_a
            y2 = py - diag * cos_a

            # Clip to rect bounds
            pts = self._clip_line_to_rect(x1, y1, x2, y2, x, y, x + w, y + h)
            if pts:
                lx1, ly1, lx2, ly2 = pts
                d = self._rough_line_path(lx1, ly1, lx2, ly2, jitter=0.8)
                self.elements.append(
                    f'<path d="{d}" stroke="{s}" stroke-width="1" fill="none" opacity="0.4"/>'
                )

    def _hatch_fill_diamond(self, cx: float, cy: float, w: float, h: float,
                            angle: float = -41, gap: float = 10) -> None:
        """Fill a diamond with hatch lines."""
        hw, hh = w / 2, h / 2
        # Use rect hatch clipped by diamond shape — approximate with rect inscribed
        self.hatch_fill_rect(cx - hw * 0.7, cy - hh * 0.7, w * 0.7, h * 0.7,
                             angle=angle, gap=gap)

    @staticmethod
    def _clip_line_to_rect(x1, y1, x2, y2, rx, ry, rx2, ry2):
        """Cohen-Sutherland line clipping to rectangle."""
        def code(x, y):
            c = 0
            if x < rx: c |= 1
            elif x > rx2: c |= 2
            if y < ry: c |= 4
            elif y > ry2: c |= 8
            return c

        c1, c2 = code(x1, y1), code(x2, y2)
        for _ in range(20):
            if not (c1 | c2):
                return x1, y1, x2, y2
            if c1 & c2:
                return None
            c = c1 or c2
            dx = x2 - x1 if x2 != x1 else 1e-10
            dy = y2 - y1 if y2 != y1 else 1e-10
            if c & 8:
                x = x1 + dx * (ry2 - y1) / dy
                y = ry2
            elif c & 4:
                x = x1 + dx * (ry - y1) / dy
                y = ry
            elif c & 2:
                y = y1 + dy * (rx2 - x1) / dx
                x = rx2
            elif c & 1:
                y = y1 + dy * (rx - x1) / dx
                x = rx
            if c == c1:
                x1, y1 = x, y
                c1 = code(x1, y1)
            else:
                x2, y2 = x, y
                c2 = code(x2, y2)
        return None

    def draw_crossing_notch(self, cx: float, cy: float,
                            dx: float, dy: float, radius: float = 8) -> None:
        """Draw a small semicircular notch at a line crossing point.

        (cx, cy) is the crossing point. (dx, dy) is the direction of the line
        that gets the notch (the one that 'goes under').
        The notch is a small arc perpendicular to (dx, dy).
        """
        dist = math.hypot(dx, dy) or 1
        # Normal perpendicular to the line direction
        nx = -dy / dist
        ny = dx / dist

        # Arc from one side to the other, bulging away
        p1 = (cx - dx / dist * radius, cy - dy / dist * radius)
        p2 = (cx + dx / dist * radius, cy + dy / dist * radius)
        # Control point for the arc (offset perpendicular)
        cp = (cx + nx * radius * 1.2, cy + ny * radius * 1.2)

        # White background to "erase" the crossing line
        d_bg = (f"M {p1[0]:.1f} {p1[1]:.1f} "
                f"Q {cp[0]:.1f} {cp[1]:.1f} {p2[0]:.1f} {p2[1]:.1f}")
        self.elements.append(
            f'<path d="{d_bg}" stroke="{self.BG}" stroke-width="6" fill="none"/>')

        # Sketchy arc on top
        d = (f"M {self._j(p1[0],0.5):.1f} {self._j(p1[1],0.5):.1f} "
             f"Q {self._j(cp[0],0.5):.1f} {self._j(cp[1],0.5):.1f} "
             f"{self._j(p2[0],0.5):.1f} {self._j(p2[1],0.5):.1f}")
        self.elements.append(
            f'<path d="{d}" stroke="{self.STROKE}" stroke-width="{self.STROKE_WIDTH}" fill="none"/>')

    # ── Output ──

    def to_svg(self) -> str:
        """Generate the complete SVG string with embedded Virgil font."""
        try:
            virgil_b64 = font_base64("Virgil.woff2")
            font_css = (
                "@font-face {"
                f"  font-family: 'Virgil';"
                f"  src: url('data:font/woff2;base64,{virgil_b64}') format('woff2');"
                "}"
            )
        except FileNotFoundError:
            font_css = ""

        style = f"<style>{font_css}</style>"

        svg_parts = [
            f'<svg xmlns="http://www.w3.org/2000/svg" '
            f'width="{self.width}" height="{self.height}" '
            f'viewBox="0 0 {self.width} {self.height}">',
            f'<defs>{style}</defs>',
            f'<rect width="{self.width}" height="{self.height}" fill="{self.BG}"/>',
        ]
        svg_parts.extend(self.elements)
        svg_parts.append('</svg>')
        return '\n'.join(svg_parts)

    def save(self, output_path: str) -> None:
        """Save as SVG, PNG, or PDF based on file extension."""
        from ..renderer import save_diagram
        svg = self.to_svg()
        save_diagram(svg, output_path, self.width, self.height)


def measure_text(text: str, size: int = 16) -> float:
    """Approximate text width in pixels for Virgil font."""
    return len(text) * size * 0.55
