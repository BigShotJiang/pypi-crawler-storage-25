"""Hand-drawn MCT (Modèle Conceptuel de Traitements) — Merise diagram."""

from __future__ import annotations

import json

from .sketch import SketchCanvas, measure_text
from .layout import Node, Edge, layout_nodes, find_edge_crossings
from .routing import angle_route


# ── Sizing helpers ──

def _event_size(event: dict, font_size: int = 14) -> tuple[float, float]:
    """Rounded rect (pill) size for an event or result."""
    name = event["name"]
    w = max(measure_text(name, font_size) + 40, 100)
    h = 40
    return w, h


def _process_size(proc: dict, font_size: int = 14) -> tuple[float, float]:
    """Rect size for a process box (name + operations list)."""
    name = proc["name"]
    ops = proc.get("operations", [])
    name_w = measure_text(name, font_size) + 30
    ops_w = max((measure_text(op, font_size - 1) for op in ops), default=0) + 30
    w = max(name_w, ops_w, 140)
    # header line + operations lines
    h = 36 + max(len(ops), 1) * 20 + 10
    return w, h


def _sync_size(sync: dict, font_size: int = 14) -> tuple[float, float]:
    """Small bar for synchronisation rule (ET / OU)."""
    label = sync.get("name", "ET")
    w = max(measure_text(label, font_size) + 30, 60)
    h = 30
    return w, h


def render(project_json: str, output: str = "mct.svg", seed: int = 42, params: dict | None = None) -> None:
    """Render a hand-drawn MCT diagram from JSON."""
    proj = json.loads(project_json)
    processes = proj.get("processes", [])
    events = proj.get("events", [])
    results = proj.get("results", [])
    flows = proj.get("flows", [])
    syncs = proj.get("sync", [])

    if not processes and not events:
        raise ValueError("No processes or events provided")

    # ── Build nodes & edges ──
    nodes = []
    node_types: dict[str, str] = {}  # name → "event" | "process" | "sync"

    for ev in events:
        w, h = _event_size(ev)
        nodes.append(Node(name=ev["name"], w=w, h=h))
        node_types[ev["name"]] = "event"

    for res in results:
        w, h = _event_size(res)
        nodes.append(Node(name=res["name"], w=w, h=h))
        node_types[res["name"]] = "event"

    for proc in processes:
        w, h = _process_size(proc)
        nodes.append(Node(name=proc["name"], w=w, h=h))
        node_types[proc["name"]] = "process"

    for sync in syncs:
        w, h = _sync_size(sync)
        sync_id = f"__sync__{sync['name']}__{id(sync)}"
        sync["_id"] = sync_id
        nodes.append(Node(name=sync_id, w=w, h=h))
        node_types[sync_id] = "sync"

    edges = []
    # Regular flows
    for f in flows:
        edges.append(Edge(from_node=f["from"], to_node=f["to"]))

    # Sync flows: inputs → sync bar → output
    for sync in syncs:
        sync_id = sync["_id"]
        for inp in sync.get("inputs", []):
            edges.append(Edge(from_node=inp, to_node=sync_id))
        out = sync.get("output", "")
        if out:
            edges.append(Edge(from_node=sync_id, to_node=out))

    # ── Layout ──
    layout_nodes(nodes, edges, margin=60, gap=100, params=params, engine="dot")
    node_map = {n.name: n for n in nodes}
    angle_route(nodes, edges, node_map, margin=30)

    # ── Canvas size ──
    max_x = max(n.x + n.w for n in nodes)
    max_y = max(n.y + n.h for n in nodes)
    for e in edges:
        for px, py in e.points:
            max_x = max(max_x, px + 60)
            max_y = max(max_y, py + 40)

    total_w = int(max_x) + 80
    total_h = int(max_y) + 80

    canvas = SketchCanvas(total_w, total_h, seed=seed)

    # Lookup for process operations
    proc_ops = {p["name"]: p.get("operations", []) for p in processes}
    # Lookup for sync labels
    sync_labels = {s["_id"]: s.get("name", "ET") for s in syncs}

    # ════════════════════════════════════════════
    #  Draw nodes
    # ════════════════════════════════════════════
    for n in nodes:
        ntype = node_types[n.name]
        cx = n.x + n.w / 2
        cy = n.y + n.h / 2

        if ntype == "event":
            # Pill / rounded rect
            canvas.rough_rounded_rect(n.x, n.y, n.w, n.h, radius=n.h / 2,
                                       fill="rgba(173,216,230,0.15)")
            canvas.text(cx, cy + 4, n.name, size=14, bold=True)

        elif ntype == "process":
            # Rectangle with separator between name and operations
            canvas.rough_rect(n.x, n.y, n.w, n.h,
                              fill="rgba(255,228,196,0.15)")
            # Name
            header_y = n.y + 24
            canvas.text(cx, header_y, n.name, size=14, bold=True)
            # Separator line
            sep_y = n.y + 34
            canvas.rough_line(n.x, sep_y, n.x + n.w, sep_y)
            # Operations
            ops = proc_ops.get(n.name, [])
            for i, op in enumerate(ops):
                op_y = sep_y + 18 + i * 20
                canvas.text(cx, op_y, op, size=12)

        elif ntype == "sync":
            # Horizontal bar with label
            label = sync_labels.get(n.name, "ET")
            canvas.rough_line(n.x, cy, n.x + n.w, cy)
            canvas.text(cx, cy - 10, label, size=12, bold=True)

    # ════════════════════════════════════════════
    #  Draw flows (arrows)
    # ════════════════════════════════════════════
    for edge in edges:
        if not edge.points:
            continue
        canvas.rough_polyline_arrow(edge.points, head_type="arrow")

    # ════════════════════════════════════════════
    #  Jumps (crossing notches)
    # ════════════════════════════════════════════
    crossings = find_edge_crossings(edges)
    for jumper_idx, _other_idx, cx, cy in crossings:
        e_jump = edges[jumper_idx]
        for si in range(len(e_jump.points) - 1):
            sx1, sy1 = e_jump.points[si]
            sx2, sy2 = e_jump.points[si + 1]
            if (min(sx1, sx2) - 1 <= cx <= max(sx1, sx2) + 1 and
                    min(sy1, sy2) - 1 <= cy <= max(sy1, sy2) + 1):
                canvas.draw_crossing_notch(cx, cy, sx2 - sx1, sy2 - sy1)
                break

    canvas.save(output)
