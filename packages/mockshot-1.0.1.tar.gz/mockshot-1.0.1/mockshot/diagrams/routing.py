"""Shared geometric routing for diagrams (angle-based face selection + perpendicular projection)."""

from __future__ import annotations

import math


def _seg_intersects_rect(sx1: float, sy1: float, sx2: float, sy2: float,
                          rx: float, ry: float, rw: float, rh: float) -> bool:
    """Check if a line segment intersects a rectangle."""
    seg_xmin, seg_xmax = min(sx1, sx2), max(sx1, sx2)
    seg_ymin, seg_ymax = min(sy1, sy2), max(sy1, sy2)
    if seg_xmax < rx or seg_xmin > rx + rw or seg_ymax < ry or seg_ymin > ry + rh:
        return False

    def inside(px, py):
        return rx <= px <= rx + rw and ry <= py <= ry + rh
    if inside(sx1, sy1) or inside(sx2, sy2):
        return True

    rect_edges = [
        ((rx, ry), (rx + rw, ry)),
        ((rx, ry + rh), (rx + rw, ry + rh)),
        ((rx, ry), (rx, ry + rh)),
        ((rx + rw, ry), (rx + rw, ry + rh)),
    ]
    for (ex1, ey1), (ex2, ey2) in rect_edges:
        if _segments_cross(sx1, sy1, sx2, sy2, ex1, ey1, ex2, ey2):
            return True
    return False


def _segments_cross(ax1, ay1, ax2, ay2, bx1, by1, bx2, by2) -> bool:
    """Check if two segments cross (proper intersection)."""
    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    d1 = cross((bx1, by1), (bx2, by2), (ax1, ay1))
    d2 = cross((bx1, by1), (bx2, by2), (ax2, ay2))
    d3 = cross((ax1, ay1), (ax2, ay2), (bx1, by1))
    d4 = cross((ax1, ay1), (ax2, ay2), (bx2, by2))

    if ((d1 > 0 and d2 < 0) or (d1 < 0 and d2 > 0)) and \
       ((d3 > 0 and d4 < 0) or (d3 < 0 and d4 > 0)):
        return True
    return False


def angle_route(nodes: list, edges: list, node_map: dict, margin: int = 30) -> None:
    """Route edges using angle-based face selection + perpendicular projection.

    1. Compute angle from center(A) to center(B)
    2. Choose face_A and face_B from the angle
    3. Distribute ports on each face (min 5px apart)
    4. Route: perpendicular projections meet at a bend point
    5. Post-pass: re-route edges that still collide
    """
    # ── Step 1: Choose faces via angle ──
    edge_faces: list[tuple[str, str]] = []
    for edge in edges:
        a = node_map[edge.from_node]
        b = node_map[edge.to_node]
        dx = b.cx - a.cx
        dy = b.cy - a.cy
        angle = math.atan2(dy, dx)
        deg = math.degrees(angle)

        if -45 <= deg <= 45:
            fa, fb = "right", "left"
        elif 45 < deg <= 135:
            fa, fb = "bottom", "top"
        elif deg > 135 or deg <= -135:
            fa, fb = "left", "right"
        else:
            fa, fb = "top", "bottom"

        edge_faces.append((fa, fb))

    # ── Step 2: Distribute ports per (node, side) ──
    side_usage: dict[tuple[str, str], list[int]] = {}
    for idx, (fa, fb) in enumerate(edge_faces):
        e = edges[idx]
        side_usage.setdefault((e.from_node, fa), []).append(idx)
        side_usage.setdefault((e.to_node, fb), []).append(idx)

    port_pos: dict[tuple[int, int], tuple[float, float]] = {}
    for (nname, side), eidxs in side_usage.items():
        n = node_map[nname]
        count = len(eidxs)

        def sort_key(eidx):
            e = edges[eidx]
            partner = node_map[e.to_node if e.from_node == nname else e.from_node]
            if side in ("top", "bottom"):
                return partner.cx
            else:
                return partner.cy
        eidxs_sorted = sorted(eidxs, key=sort_key)

        for i, eidx in enumerate(eidxs_sorted):
            t = (i + 1) / (count + 1)
            t = 0.15 + t * 0.7
            if side == "top":
                port = (n.x + n.w * t, n.y)
            elif side == "bottom":
                port = (n.x + n.w * t, n.y + n.h)
            elif side == "left":
                port = (n.x, n.y + n.h * t)
            else:
                port = (n.x + n.w, n.y + n.h * t)

            e = edges[eidx]
            key = 0 if e.from_node == nname else 1
            port_pos[(eidx, key)] = port

    # ── Step 3: Route — perpendicular projections with collision avoidance ──
    all_rects = [(n.x, n.y, n.w, n.h, n.name) for n in nodes]
    MARGIN = margin

    def _seg_hits_any_box(p1, p2, exclude=None):
        for rx, ry, rw, rh, name in all_rects:
            if exclude and name in exclude:
                continue
            sx_min, sx_max = min(p1[0], p2[0]), max(p1[0], p2[0])
            sy_min, sy_max = min(p1[1], p2[1]), max(p1[1], p2[1])
            if sx_max < rx - MARGIN or sx_min > rx + rw + MARGIN or sy_max < ry - MARGIN or sy_min > ry + rh + MARGIN:
                continue
            if _seg_intersects_rect(p1[0], p1[1], p2[0], p2[1],
                                     rx - MARGIN, ry - MARGIN, rw + MARGIN * 2, rh + MARGIN * 2):
                return True
        return False

    def _route_safe(pa, pb, fa, fb, from_name, to_name):
        exclude = {from_name, to_name}
        a_horiz = fa in ("left", "right")
        b_horiz = fb in ("left", "right")

        if a_horiz and b_horiz:
            if abs(pa[1] - pb[1]) < 2:
                route = [pa, pb]
                if not _seg_hits_any_box(pa, pb, exclude):
                    return route
            mid_x = (pa[0] + pb[0]) / 2
            route = [pa, (mid_x, pa[1]), (mid_x, pb[1]), pb]
            if not any(_seg_hits_any_box(route[i], route[i+1], exclude)
                       for i in range(len(route)-1)):
                return route
            a_dir = 1 if fa == "right" else -1
            for offset in range(20, 300, 10):
                mid_x = pa[0] + a_dir * offset
                route = [pa, (mid_x, pa[1]), (mid_x, pb[1]), pb]
                if not any(_seg_hits_any_box(route[i], route[i+1], exclude)
                           for i in range(len(route)-1)):
                    return route
            return [pa, ((pa[0]+pb[0])/2, pa[1]), ((pa[0]+pb[0])/2, pb[1]), pb]

        elif not a_horiz and not b_horiz:
            if abs(pa[0] - pb[0]) < 2:
                route = [pa, pb]
                if not _seg_hits_any_box(pa, pb, exclude):
                    return route
            mid_y = (pa[1] + pb[1]) / 2
            route = [pa, (pa[0], mid_y), (pb[0], mid_y), pb]
            if not any(_seg_hits_any_box(route[i], route[i+1], exclude)
                       for i in range(len(route)-1)):
                return route
            a_dir = 1 if fa == "bottom" else -1
            for offset in range(20, 300, 10):
                mid_y = pa[1] + a_dir * offset
                route = [pa, (pa[0], mid_y), (pb[0], mid_y), pb]
                if not any(_seg_hits_any_box(route[i], route[i+1], exclude)
                           for i in range(len(route)-1)):
                    return route
            return [pa, (pa[0], (pa[1]+pb[1])/2), (pb[0], (pa[1]+pb[1])/2), pb]

        else:
            if a_horiz:
                bend = (pb[0], pa[1])
            else:
                bend = (pa[0], pb[1])

            route = [pa, bend, pb]
            if not any(_seg_hits_any_box(route[i], route[i+1], exclude)
                       for i in range(len(route)-1)):
                return route

            if a_horiz:
                bend2 = (pa[0], pb[1])
            else:
                bend2 = (pb[0], pa[1])
            route2 = [pa, bend2, pb]
            if not any(_seg_hits_any_box(route2[i], route2[i+1], exclude)
                       for i in range(len(route2)-1)):
                return route2

            if a_horiz:
                a_dir = 1 if fa == "right" else -1
                for offset in range(20, 300, 10):
                    ext_x = pa[0] + a_dir * offset
                    route = [pa, (ext_x, pa[1]), (ext_x, pb[1]), pb]
                    if not any(_seg_hits_any_box(route[i], route[i+1], exclude)
                               for i in range(len(route)-1)):
                        return route
            else:
                a_dir = 1 if fa == "bottom" else -1
                for offset in range(20, 300, 10):
                    ext_y = pa[1] + a_dir * offset
                    route = [pa, (pa[0], ext_y), (pb[0], ext_y), pb]
                    if not any(_seg_hits_any_box(route[i], route[i+1], exclude)
                               for i in range(len(route)-1)):
                        return route

            return [pa, bend, pb]

    for idx, edge in enumerate(edges):
        fa, fb = edge_faces[idx]
        pa = port_pos.get((idx, 0))
        pb = port_pos.get((idx, 1))
        if not pa or not pb:
            edge.points = []
            continue
        edge.points = _route_safe(pa, pb, fa, fb, edge.from_node, edge.to_node)

    # ── Step 4 (couche 2): Post-pass — re-route edges that still collide ──
    def _reroute_strict(pa, pb, fa, fb, from_name, to_name):
        a_horiz = fa in ("left", "right")

        def route_ok(route):
            for si in range(len(route) - 1):
                exc = set()
                if si == 0:
                    exc.add(from_name)
                if si == len(route) - 2:
                    exc.add(to_name)
                if _seg_hits_any_box(route[si], route[si + 1], exc):
                    return False
            return True

        if a_horiz:
            a_dir = 1 if fa == "right" else -1
            for offset in range(15, 400, 8):
                for sign in (1, -1):
                    ext_x = pa[0] + a_dir * offset * sign
                    route = [pa, (ext_x, pa[1]), (ext_x, pb[1]), pb]
                    if route_ok(route):
                        return route
            b_dir = 1 if fb == "right" else -1
            for off_a in range(20, 300, 15):
                for off_b in range(20, 300, 15):
                    ext_x = pa[0] + a_dir * off_a
                    ext_x2 = pb[0] + b_dir * off_b
                    for mid_y in (min(pa[1], pb[1]) - 30, max(pa[1], pb[1]) + 30):
                        route = [pa, (ext_x, pa[1]), (ext_x, mid_y),
                                 (ext_x2, mid_y), (ext_x2, pb[1]), pb]
                        if route_ok(route):
                            return route
        else:
            a_dir = 1 if fa == "bottom" else -1
            for offset in range(15, 400, 8):
                for sign in (1, -1):
                    ext_y = pa[1] + a_dir * offset * sign
                    route = [pa, (pa[0], ext_y), (pb[0], ext_y), pb]
                    if route_ok(route):
                        return route
            b_dir = 1 if fb == "bottom" else -1
            for off_a in range(20, 300, 15):
                for off_b in range(20, 300, 15):
                    ext_y = pa[1] + a_dir * off_a
                    ext_y2 = pb[1] + b_dir * off_b
                    for mid_x in (min(pa[0], pb[0]) - 30, max(pa[0], pb[0]) + 30):
                        route = [pa, (pa[0], ext_y), (mid_x, ext_y),
                                 (mid_x, ext_y2), (pb[0], ext_y2), pb]
                        if route_ok(route):
                            return route

        return None

    for _pass in range(3):
        any_fixed = False
        for idx, edge in enumerate(edges):
            if not edge.points or len(edge.points) < 2:
                continue
            fa, fb = edge_faces[idx]
            pts = edge.points

            has_collision = False
            for si in range(len(pts) - 1):
                seg_exclude = set()
                if si == 0:
                    seg_exclude.add(edge.from_node)
                if si == len(pts) - 2:
                    seg_exclude.add(edge.to_node)
                if _seg_hits_any_box(pts[si], pts[si + 1], seg_exclude):
                    has_collision = True
                    break

            if has_collision:
                new_route = _reroute_strict(
                    pts[0], pts[-1], fa, fb, edge.from_node, edge.to_node)
                if new_route:
                    edge.points = new_route
                    any_fixed = True

        if not any_fixed:
            break
