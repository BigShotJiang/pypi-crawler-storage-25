"""Hand-drawn MLD (Modèle Logique de Données) — Merise diagram with smart layout."""

from __future__ import annotations

import json
import math

from .sketch import SketchCanvas, measure_text
from .layout import Node, Edge, layout_nodes, find_edge_crossings
from .routing import angle_route


def _table_size(table: dict, font_size: int = 14) -> tuple[float, float]:
    """Calculate table box size based on content."""
    name = table["name"]
    columns = table.get("columns", [])
    pad = 8

    # Column text: prefix + name + " : " + type
    col_texts = []
    for col in columns:
        prefix = ""
        if col.get("pk"):
            prefix = "🔑 "
        elif col.get("fk"):
            prefix = "# "
        col_texts.append(f"{prefix}{col['name']} : {col.get('type', '')}")

    max_text = max([name] + col_texts, key=len)
    w = max(measure_text(max_text, font_size) + pad * 2 + 20, 140)
    header_h = 34
    cols_h = len(columns) * 22 + pad
    h = header_h + cols_h + pad
    return w, max(h, 60)


def render(project_json: str, output: str = "mld.svg", seed: int = 42) -> None:
    """Render a hand-drawn MLD diagram from JSON."""
    proj = json.loads(project_json)
    tables = proj.get("tables", [])
    references = proj.get("references", [])

    if not tables:
        raise ValueError("No tables provided")

    # ── Build nodes & edges ──
    nodes = []
    for t in tables:
        w, h = _table_size(t)
        nodes.append(Node(name=t["name"], w=w, h=h))

    edges = []
    for ref in references:
        edges.append(Edge(from_node=ref["from"], to_node=ref["to"]))

    # ── Layout ──
    layout_nodes(nodes, edges, margin=60, gap=100, engine="neato")

    # ── Route ──
    node_map = {n.name: n for n in nodes}
    angle_route(nodes, edges, node_map, margin=30)

    # ── Canvas size ──
    max_x = max(n.x + n.w for n in nodes)
    max_y = max(n.y + n.h for n in nodes)
    for e in edges:
        for px, py in e.points:
            max_x = max(max_x, px + 60)
            max_y = max(max_y, py + 40)

    total_w = int(max_x) + 80
    total_h = int(max_y) + 80

    canvas = SketchCanvas(total_w, total_h, seed=seed)

    # ════════════════════════════════════════════
    #  ÉTAPE 1 — Dessiner les tables (rectangles)
    # ════════════════════════════════════════════
    for t in tables:
        n = node_map[t["name"]]
        x, y, w, h = n.x, n.y, n.w, n.h

        canvas.rough_rect(x, y, w, h, fill="rgba(0,0,0,0.02)")
        canvas.text(x + w / 2, y + 18, t["name"].upper(), size=16, bold=True)

        sep_y = y + 34
        canvas.rough_line(x, sep_y, x + w, sep_y)

        for i, col in enumerate(t.get("columns", [])):
            ay = sep_y + 14 + i * 22
            is_pk = col.get("pk", False)
            is_fk = col.get("fk")

            prefix = ""
            if is_pk:
                prefix = "🔑 "
            elif is_fk:
                prefix = "# "

            col_text = f"{prefix}{col['name']} : {col.get('type', '')}"

            canvas.text(x + 14, ay, col_text, size=14, anchor="start",
                        underline=is_pk)

    # ════════════════════════════════════════════
    #  ÉTAPE 2 — Dessiner les références (flèches)
    # ════════════════════════════════════════════
    ref_map = {(r["from"], r["to"]): r for r in references}

    for idx, edge in enumerate(edges):
        if not edge.points:
            continue
        canvas.rough_polyline_arrow(edge.points, head_type="arrow")

        # Cardinality labels
        ref = ref_map.get((edge.from_node, edge.to_node))
        if not ref:
            continue

        card_type = ref.get("type", "")
        if card_type:
            parts = card_type.split(":")
            if len(parts) == 2:
                card_from, card_to = parts[0].strip(), parts[1].strip()
            else:
                card_from, card_to = "", ""

            # Place cardinality near start (from)
            if card_from and len(edge.points) >= 2:
                p0 = edge.points[0]
                p1 = edge.points[1]
                dx = p1[0] - p0[0]
                dy = p1[1] - p0[1]
                dist = math.hypot(dx, dy) or 1
                cx = p0[0] + dx / dist * 25
                cy = p0[1] + dy / dist * 25
                tw = measure_text(card_from, 12) + 6
                canvas.elements.append(
                    f'<rect x="{cx - tw/2:.1f}" y="{cy - 9:.1f}" '
                    f'width="{tw:.1f}" height="18" '
                    f'fill="white" stroke="none"/>')
                canvas.text(cx, cy, card_from, size=12)

            # Place cardinality near end (to)
            if card_to and len(edge.points) >= 2:
                p_last = edge.points[-1]
                p_prev = edge.points[-2]
                dx = p_prev[0] - p_last[0]
                dy = p_prev[1] - p_last[1]
                dist = math.hypot(dx, dy) or 1
                cx = p_last[0] + dx / dist * 25
                cy = p_last[1] + dy / dist * 25
                tw = measure_text(card_to, 12) + 6
                canvas.elements.append(
                    f'<rect x="{cx - tw/2:.1f}" y="{cy - 9:.1f}" '
                    f'width="{tw:.1f}" height="18" '
                    f'fill="white" stroke="none"/>')
                canvas.text(cx, cy, card_to, size=12)

    # ════════════════════════════════════════════
    #  ÉTAPE 3 — Jumps/encoches aux croisements
    # ════════════════════════════════════════════
    crossings = find_edge_crossings(edges)
    for jumper_idx, _other_idx, cx, cy in crossings:
        e_jump = edges[jumper_idx]
        for si in range(len(e_jump.points) - 1):
            sx1, sy1 = e_jump.points[si]
            sx2, sy2 = e_jump.points[si + 1]
            if (min(sx1, sx2) - 1 <= cx <= max(sx1, sx2) + 1 and
                    min(sy1, sy2) - 1 <= cy <= max(sy1, sy2) + 1):
                canvas.draw_crossing_notch(cx, cy, sx2 - sx1, sy2 - sy1)
                break

    canvas.save(output)
