"""CLI entry point for mockshot."""

from __future__ import annotations

import sys
from pathlib import Path

import click

from .core import ScreenshotConfig

# Extensions that browsers can interpret/display
BROWSER_EXTS = {
    ".html", ".htm", ".xhtml",
    ".json", ".xml", ".svg",
    ".txt", ".csv", ".log",
    ".css", ".js",
}


def _resolve_project(value: str | None) -> str | None:
    """Resolve --project value: if it starts with '{' treat as inline JSON,
    otherwise treat as a file path and read it."""
    if not value:
        return None
    stripped = value.strip()
    if stripped.startswith("{"):
        return stripped
    p = Path(value)
    if not p.exists():
        raise click.BadParameter(f"File not found: {value}")
    return p.read_text(encoding="utf-8")


def _handle_output(output: str, fmt: str) -> None:
    """Handle output format: file (default), path, or base64."""
    import base64
    if fmt == "path":
        click.echo(str(Path(output).resolve()))
    elif fmt == "base64":
        click.echo(base64.b64encode(Path(output).read_bytes()).decode())
    else:
        click.echo(f"✓ Saved {output}")


@click.group()
@click.version_option(package_name="mockshot")
def main():
    """mockshot -- Generate pixel-perfect fake screenshots for university reports."""


# ═══════════════════════════════════════════════════════════
#  VS CODE
# ═══════════════════════════════════════════════════════════

@main.command()
@click.option("--project", "project_raw", default=None,
              help="JSON project file path or inline JSON string")
@click.option("--file", "file_path", type=click.Path(exists=True), help="Source code file (override JSON)")
@click.option("--code", type=str, help="Inline code string")
@click.option("--lang", default="python", help="Language (default: python)")
@click.option("--filename", default=None, help="Display filename in tab")
@click.option("--tabs", "tabs_str", default=None, help="Comma-separated tab filenames")
@click.option("--git-branch", default="main", help="Git branch in status bar")
@click.option("--width", default=1920)
@click.option("--height", default=1080)
@click.option("-o", "--output", default="screenshot.png")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]),
              help="Output format: file (default), path (absolute path), base64 (stdout)")
def vscode(project_raw, file_path, code, lang, filename, tabs_str, git_branch, width, height, output, fmt):
    """Generate a VS Code screenshot (always Dark+ theme).

    \b
    Use --project with a JSON file or inline JSON:
      mockshot vscode --project project.json
      mockshot vscode --project '{"root":"myapp","tree":[...]}'
    """
    from .templates.vscode import render

    if file_path:
        code = Path(file_path).read_text()
        if filename is None:
            filename = Path(file_path).name
    elif code is None:
        code = ""

    tree_json = _resolve_project(project_raw)

    tabs = None
    if tabs_str:
        tabs = [t.strip() for t in tabs_str.split(",")]

    config = ScreenshotConfig(width=width, height=height, theme="dark", output=output)
    render(code=code, language=lang, filename=filename, config=config,
           git_branch=git_branch, tree_json=tree_json, tabs=tabs)
    _handle_output(output, fmt)


@main.command()
@click.argument("file_path", type=click.Path(exists=True))
@click.option("--visible", default=None, help="Visible lines range, e.g. 25-70")
@click.option("--width", default=1920)
@click.option("--height", default=1080)
@click.option("-o", "--output", default="screenshot.png")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]),
              help="Output format: file (default), path (absolute path), base64 (stdout)")
def quick(file_path, visible, width, height, output, fmt):
    """Quick VS Code screenshot of a single file. No tree, no tabs.

    \b
    Examples:
      mockshot quick app.py
      mockshot quick src/main.rs -o main.png
      mockshot quick server.js --visible 10-50
    """
    from .templates.vscode import render, _detect_language

    path = Path(file_path)
    code = path.read_text(encoding="utf-8")
    filename = path.name
    language = _detect_language(filename)

    visible_lines = None
    if visible:
        parts = visible.split("-")
        if len(parts) == 2:
            visible_lines = (int(parts[0]), int(parts[1]))

    config = ScreenshotConfig(width=width, height=height, theme="dark", output=output)
    render(
        code=code,
        language=language,
        filename=filename,
        config=config,
        visible_lines=visible_lines,
    )
    _handle_output(output, fmt)


@main.command()
@click.argument("directory", type=click.Path(exists=True))
@click.option("--active", "active_file", default=None,
              help="Relative path to the active file in editor")
@click.option("--branch", default="main", help="Git branch name")
@click.option("--visible", default=None, help="Visible lines range, e.g. 25-70")
@click.option("--depth", default=4, help="Max directory scan depth")
@click.option("-o", "--output", default="project.json", help="Output JSON file path")
def scan(directory, active_file, branch, visible, depth, output):
    """Scan a directory and generate a VS Code project JSON.

    \b
    Examples:
      mockshot scan ./myproject -o project.json
      mockshot scan ./myproject --active src/main.py --visible 25-70
      mockshot scan . --active app.py --branch feature/api
    """
    import json
    from .scanner import scan_project

    visible_lines = None
    if visible:
        parts = visible.split("-")
        if len(parts) == 2:
            visible_lines = (int(parts[0]), int(parts[1]))

    project = scan_project(
        directory=directory,
        active_file=active_file,
        git_branch=branch,
        visible_lines=visible_lines,
        max_depth=depth,
    )

    Path(output).write_text(json.dumps(project, indent=2, ensure_ascii=False))
    click.echo(f"✓ Scanned {directory} → {output}")
    if active_file:
        click.echo(f"  Active file: {active_file}")
    click.echo(f"  Use: mockshot vscode --project {output} -o screenshot.png")


# ═══════════════════════════════════════════════════════════
#  TERMINAL
# ═══════════════════════════════════════════════════════════

@main.command()
@click.option("--project", "project_raw", default=None,
              help="JSON project file path or inline JSON string")
@click.option("--os", "os_type", default=None, type=click.Choice(["linux", "macos", "windows"]),
              help="OS type (override JSON)")
@click.option("--user", default=None, help="Username (override JSON)")
@click.option("--host", default=None, help="Hostname (override JSON)")
@click.option("--commands", type=click.Path(exists=True), help="Legacy: text file with $ prefix")
@click.option("--inline", type=str, help="Inline commands text")
@click.option("--cwd", default=None, help="Working directory (override JSON)")
@click.option("--width", default=1920)
@click.option("--height", default=1080)
@click.option("-o", "--output", default="screenshot.png")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]),
              help="Output format: file (default), path (absolute path), base64 (stdout)")
def terminal(project_raw, os_type, user, host, commands, inline, cwd, width, height, output, fmt):
    """Generate a terminal screenshot (Linux, macOS, or Windows).

    \b
    Use --project with a JSON file or inline JSON:
      mockshot terminal --project terminal.json
      mockshot terminal --project '{"os":"linux","user":"andil","commands":[...]}'

    The OS determines the look: GNOME (linux), Terminal.app (macos), Windows Terminal (windows).
    """
    from .templates.terminal import render

    project_json = _resolve_project(project_raw)
    text = ""

    if not project_json:
        if commands:
            text = Path(commands).read_text()
        elif inline:
            text = inline
        else:
            text = sys.stdin.read()

    config = ScreenshotConfig(width=width, height=height, theme="dark", output=output)
    render(
        commands_text=text,
        os_type=os_type or "linux",
        user=user or "user",
        host=host or "desktop",
        config=config,
        cwd=cwd or "~",
        project_json=project_json,
    )
    _handle_output(output, fmt)


# ═══════════════════════════════════════════════════════════
#  BROWSER (Chrome / Safari)
# ═══════════════════════════════════════════════════════════

def _validate_browser_content(file_path: str) -> str:
    """Validate that the file is a browser-interpretable format. Return content or raise."""
    path = Path(file_path)
    ext = path.suffix.lower()
    if ext not in BROWSER_EXTS:
        supported = ", ".join(sorted(BROWSER_EXTS))
        raise click.BadParameter(
            f"'{path.name}' is not a browser-interpretable file.\n"
            f"  Supported extensions: {supported}\n"
            f"  For code files, use: mockshot vscode or mockshot quick"
        )
    return path.read_text(encoding="utf-8")


@main.command()
@click.option("--project", "project_raw", default=None,
              help="JSON project file path or inline JSON string")
@click.option("--url", default=None, help="URL in address bar")
@click.option("--content", "content_path", type=click.Path(exists=True),
              help="Content file to display (json, html, xml, txt, csv...)")
@click.option("--text", type=str, help="Inline content text")
@click.option("--browser", default=None, type=click.Choice(["chrome", "safari"]))
@click.option("--title", "page_title", default=None, help="Page title in tab")
@click.option("--theme", default="light", type=click.Choice(["light", "dark"]),
              help="Browser theme (default: light)")
@click.option("--width", default=1920)
@click.option("--height", default=1080)
@click.option("-o", "--output", default="screenshot.png")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]),
              help="Output format: file (default), path (absolute path), base64 (stdout)")
def browser(project_raw, url, content_path, text, browser, page_title, theme, width, height, output, fmt):
    """Generate a browser screenshot (Chrome or Safari, light or dark).

    \b
    Accepts only browser-interpretable content:
      .html .htm .json .xml .svg .txt .csv .log .css .js

    \b
    Use --project with a JSON file or inline JSON:
      mockshot browser --project browser.json
      mockshot browser --project '{"browser":"chrome","url":"https://example.com"}'

    \b
    Or use flags:
      mockshot browser --url https://example.com --content response.json
      mockshot browser --url https://example.com --browser safari --theme dark
    """
    from .templates.browser import render

    project_json = _resolve_project(project_raw)
    content_text = ""

    if not project_json:
        if content_path:
            content_text = _validate_browser_content(content_path)
        elif text:
            content_text = text

    config = ScreenshotConfig(width=width, height=height, theme=theme, output=output)
    render(
        url=url or "https://example.com",
        content_text=content_text,
        browser=browser or "chrome",
        theme_name=theme,
        config=config,
        page_title=page_title,
        project_json=project_json,
    )
    _handle_output(output, fmt)


if __name__ == "__main__":
    main()


# ═══════════════════════════════════════════════════════════
#  GANTT
# ═══════════════════════════════════════════════════════════

@main.command()
@click.option("--project", "project_raw", default=None,
              help="JSON project file path or inline JSON string")
@click.option("-o", "--output", default="gantt.svg")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]),
              help="Output format: file (default), path (absolute path), base64 (stdout)")
@click.option("--seed", default=42, type=int, help="Random seed for hand-drawn style")
def gantt(project_raw, output, fmt, seed):
    """Generate a hand-drawn Gantt chart (Excalidraw style).

    \b
    Use --project with a JSON file or inline JSON:
      mockshot gantt --project gantt.json
      mockshot gantt --project '{"title":"Sprint","tasks":[{"name":"Dev","start":"2024-01-01","end":"2024-01-10"}]}'

    \b
    Output format is auto-detected from -o extension: .svg, .png, .pdf
    """
    from .diagrams.gantt import render

    project_json = _resolve_project(project_raw)
    if not project_json:
        raise click.BadParameter("--project is required")

    render(project_json=project_json, output=output, seed=seed)
    _handle_output(output, fmt)


# ═══════════════════════════════════════════════════════════
#  MERISE
# ═══════════════════════════════════════════════════════════

@main.group()
def merise():
    """Generate hand-drawn Merise diagrams (Excalidraw style)."""


@merise.command()
@click.option("--project", "project_raw", default=None,
              help="JSON project file path or inline JSON string")
@click.option("-o", "--output", default="mcd.svg")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]),
              help="Output format: file (default), path (absolute path), base64 (stdout)")
@click.option("--seed", default=42, type=int, help="Random seed for hand-drawn style")
def mcd(project_raw, output, fmt, seed):
    """Generate a hand-drawn MCD (Modèle Conceptuel de Données).

    \b
    Use --project with a JSON file or inline JSON:
      mockshot merise mcd --project mcd.json
      mockshot merise mcd --project '{"entities":[...],"associations":[...]}'
    """
    from .diagrams.merise_mcd import render

    project_json = _resolve_project(project_raw)
    if not project_json:
        raise click.BadParameter("--project is required")

    render(project_json=project_json, output=output, seed=seed)
    _handle_output(output, fmt)


@merise.command()
@click.option("--project", "project_raw", default=None,
              help="JSON project file path or inline JSON string")
@click.option("-o", "--output", default="mcc.svg")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]),
              help="Output format: file (default), path (absolute path), base64 (stdout)")
@click.option("--seed", default=42, type=int, help="Random seed for hand-drawn style")
def mcc(project_raw, output, fmt, seed):
    """Generate a hand-drawn MCC (Modèle Conceptuel de Communication).

    \b
    Use --project with a JSON file or inline JSON:
      mockshot merise mcc --project mcc.json
      mockshot merise mcc --project '{"actors":[...],"flows":[...]}'
    """
    from .diagrams.merise_mcc import render

    project_json = _resolve_project(project_raw)
    if not project_json:
        raise click.BadParameter("--project is required")

    render(project_json=project_json, output=output, seed=seed)
    _handle_output(output, fmt)


@merise.command()
@click.option("--project", "project_raw", default=None,
              help="JSON project file path or inline JSON string")
@click.option("-o", "--output", default="mct.svg")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]),
              help="Output format: file (default), path (absolute path), base64 (stdout)")
@click.option("--seed", default=42, type=int, help="Random seed for hand-drawn style")
def mct(project_raw, output, fmt, seed):
    """Generate a hand-drawn MCT (Modèle Conceptuel de Traitements).

    \b
    Use --project with a JSON file or inline JSON:
      mockshot merise mct --project mct.json
      mockshot merise mct --project '{"processes":[...],"events":[...],"flows":[...]}'
    """
    from .diagrams.merise_mct import render

    project_json = _resolve_project(project_raw)
    if not project_json:
        raise click.BadParameter("--project is required")

    render(project_json=project_json, output=output, seed=seed)
    _handle_output(output, fmt)


@merise.command()
@click.option("--project", "project_raw", default=None,
              help="JSON project file path or inline JSON string")
@click.option("-o", "--output", default="mld.svg")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]),
              help="Output format: file (default), path (absolute path), base64 (stdout)")
@click.option("--seed", default=42, type=int, help="Random seed for hand-drawn style")
def mld(project_raw, output, fmt, seed):
    """Generate a hand-drawn MLD (Modèle Logique de Données).

    \b
    Use --project with a JSON file or inline JSON:
      mockshot merise mld --project mld.json
      mockshot merise mld --project '{"tables":[...],"references":[...]}'
    """
    from .diagrams.merise_mld import render

    project_json = _resolve_project(project_raw)
    if not project_json:
        raise click.BadParameter("--project is required")

    render(project_json=project_json, output=output, seed=seed)
    _handle_output(output, fmt)


# ═══════════════════════════════════════════════════════════
#  UML
# ═══════════════════════════════════════════════════════════

@main.group()
def uml():
    """Generate hand-drawn UML diagrams (Excalidraw style)."""


@uml.command("class")
@click.option("--project", "project_raw", default=None,
              help="JSON project file path or inline JSON string")
@click.option("-o", "--output", default="class.svg")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]),
              help="Output format: file (default), path (absolute path), base64 (stdout)")
@click.option("--seed", default=42, type=int, help="Random seed for hand-drawn style")
def class_diagram(project_raw, output, fmt, seed):
    """Generate a hand-drawn UML class diagram.

    \b
    Use --project with a JSON file or inline JSON:
      mockshot uml class --project class.json
      mockshot uml class --project '{"classes":[...],"relations":[...]}'

    \b
    Relation types: association, aggregation, composition,
                    inheritance, implementation, dependency
    """
    from .diagrams.uml_class import render

    project_json = _resolve_project(project_raw)
    if not project_json:
        raise click.BadParameter("--project is required")

    render(project_json=project_json, output=output, seed=seed)
    _handle_output(output, fmt)


@uml.command("usecase")
@click.option("--project", "project_raw", default=None,
              help="JSON project file path or inline JSON string")
@click.option("-o", "--output", default="usecase.svg")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]),
              help="Output format: file (default), path (absolute path), base64 (stdout)")
@click.option("--seed", default=42, type=int, help="Random seed for hand-drawn style")
def usecase_diagram(project_raw, output, fmt, seed):
    """Generate a hand-drawn UML Use Case diagram.

    \b
    Use --project with a JSON file or inline JSON:
      mockshot uml usecase --project usecase.json
      mockshot uml usecase --project '{"actors":[...],"usecases":[...],"relations":[...]}'

    \b
    Relation types: association, include, extend, generalization
    """
    from .diagrams.uml_usecase import render

    project_json = _resolve_project(project_raw)
    if not project_json:
        raise click.BadParameter("--project is required")

    render(project_json=project_json, output=output, seed=seed)
    _handle_output(output, fmt)


@uml.command("activity")
@click.option("--project", "project_raw", default=None, help="JSON project file path or inline JSON string")
@click.option("-o", "--output", default="activity.svg")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]))
@click.option("--seed", default=42, type=int)
def activity_diagram(project_raw, output, fmt, seed):
    """Generate a hand-drawn UML Activity diagram."""
    from .diagrams.uml_activity import render

    project_json = _resolve_project(project_raw)
    if not project_json:
        raise click.BadParameter("--project is required")

    render(project_json=project_json, output=output, seed=seed)
    _handle_output(output, fmt)


@uml.command("sequence")
@click.option("--project", "project_raw", default=None,
              help="JSON project file path or inline JSON string")
@click.option("-o", "--output", default="sequence.svg")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]),
              help="Output format: file (default), path (absolute path), base64 (stdout)")
@click.option("--seed", default=42, type=int, help="Random seed for hand-drawn style")
def sequence_diagram(project_raw, output, fmt, seed):
    """Generate a hand-drawn UML Sequence diagram.

    \b
    Use --project with a JSON file or inline JSON:
      mockshot uml sequence --project sequence.json
      mockshot uml sequence --project '{"participants":[...],"messages":[...]}'

    \b
    Message types: sync, async, reply, self
    """
    from .diagrams.uml_sequence import render

    project_json = _resolve_project(project_raw)
    if not project_json:
        raise click.BadParameter("--project is required")

    render(project_json=project_json, output=output, seed=seed)
    _handle_output(output, fmt)


@uml.command("state")
@click.option("--project", "project_raw", default=None,
              help="JSON project file path or inline JSON string")
@click.option("-o", "--output", default="state.svg")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]))
@click.option("--seed", default=42, type=int)
def state_diagram(project_raw, output, fmt, seed):
    """Generate a hand-drawn UML State Machine diagram."""
    from .diagrams.uml_state import render
    project_json = _resolve_project(project_raw)
    if not project_json:
        raise click.BadParameter("--project is required")
    render(project_json=project_json, output=output, seed=seed)
    _handle_output(output, fmt)


@uml.command("component")
@click.option("--project", "project_raw", default=None)
@click.option("-o", "--output", default="component.svg")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]))
@click.option("--seed", default=42, type=int)
def component_diagram(project_raw, output, fmt, seed):
    """Generate a hand-drawn UML Component diagram."""
    from .diagrams.uml_component import render
    project_json = _resolve_project(project_raw)
    if not project_json:
        raise click.BadParameter("--project is required")
    render(project_json=project_json, output=output, seed=seed)
    _handle_output(output, fmt)


@uml.command("deployment")
@click.option("--project", "project_raw", default=None)
@click.option("-o", "--output", default="deployment.svg")
@click.option("--format", "fmt", default="file", type=click.Choice(["file", "path", "base64"]))
@click.option("--seed", default=42, type=int)
def deployment_diagram(project_raw, output, fmt, seed):
    """Generate a hand-drawn UML Deployment diagram."""
    from .diagrams.uml_deployment import render
    project_json = _resolve_project(project_raw)
    if not project_json:
        raise click.BadParameter("--project is required")
    render(project_json=project_json, output=output, seed=seed)
    _handle_output(output, fmt)
