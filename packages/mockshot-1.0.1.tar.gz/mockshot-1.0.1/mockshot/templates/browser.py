"""Browser screenshot template — Chrome & Safari, light/dark modes."""

from __future__ import annotations

import html
import json
from pathlib import Path

from jinja2 import Template

from ..core import ScreenshotConfig
from ..renderer import render_html_to_png
from ..asset_loader import font_base64

TEMPLATES_DIR = Path(__file__).parent.parent / "html_templates"


def _format_json_html(json_text: str) -> str:
    """Format JSON with syntax-colored spans."""
    try:
        data = json.loads(json_text)
        formatted = json.dumps(data, indent=4, ensure_ascii=False)
    except (json.JSONDecodeError, ValueError):
        return html.escape(json_text)

    result = []
    for line in formatted.split("\n"):
        stripped = line.lstrip()
        indent = len(line) - len(stripped)
        indent_html = "&nbsp;" * indent if indent else ""

        if not stripped:
            result.append("")
            continue

        if stripped.startswith('"') and '":' in stripped:
            colon_pos = stripped.find('":')
            key_part = stripped[:colon_pos + 1]
            rest = stripped[colon_pos + 1:]

            line_html = indent_html
            line_html += f'<span class="json-key">{html.escape(key_part)}</span>'

            sep = ": " if rest.startswith(": ") else ":"
            line_html += f'<span class="json-punct">{html.escape(sep)}</span>'
            rest = rest[len(sep):]

            line_html += _colorize_value(rest)
            result.append(line_html)
        else:
            result.append(indent_html + _colorize_value(stripped))

    return "\n".join(result)


def _colorize_value(text: str) -> str:
    """Return HTML span for a JSON value."""
    stripped = text.rstrip(",").strip()
    has_comma = text.rstrip().endswith(",")
    value_text = text.rstrip(",") if has_comma else text
    comma = '<span class="json-punct">,</span>' if has_comma else ""

    if stripped.startswith('"'):
        return f'<span class="json-string">{html.escape(value_text)}</span>{comma}'
    elif stripped in ("true", "false"):
        return f'<span class="json-bool">{html.escape(value_text)}</span>{comma}'
    elif stripped == "null":
        return f'<span class="json-null">{html.escape(value_text)}</span>{comma}'
    elif stripped in ("{", "}", "[", "]", "{}", "[]"):
        return f'<span class="json-punct">{html.escape(value_text)}</span>{comma}'
    else:
        try:
            float(stripped)
            return f'<span class="json-number">{html.escape(value_text)}</span>{comma}'
        except ValueError:
            return f'<span class="json-punct">{html.escape(value_text)}</span>{comma}'


def _parse_url(url: str) -> tuple[str, str, str]:
    """Parse URL into (domain, path, display)."""
    clean = url.replace("https://", "").replace("http://", "")
    parts = clean.split("/", 1)
    domain = parts[0]
    path = "/" + parts[1] if len(parts) > 1 else ""
    return domain, path, domain


def render(
    url: str = "https://example.com",
    content_text: str = "",
    browser: str = "chrome",
    theme_name: str = "dark",
    config: ScreenshotConfig | None = None,
    page_title: str | None = None,
    project_json: str | None = None,
) -> None:
    config = config or ScreenshotConfig()

    # ── Parse JSON project file if provided ──
    if project_json:
        proj = json.loads(project_json)
        url = proj.get("url", url)
        browser = proj.get("browser", browser)
        theme_name = proj.get("theme", theme_name)
        page_title = proj.get("title", page_title)

        content_path = proj.get("content_path")
        if content_path:
            p = Path(content_path)
            if p.exists():
                content_text = p.read_text(encoding="utf-8")

    url_domain, url_path, url_display = _parse_url(url)
    page_title = page_title or url_domain

    # Render content
    if content_text:
        stripped = content_text.strip()
        if stripped.startswith("{") or stripped.startswith("["):
            content_html = _format_json_html(content_text)
        else:
            content_html = html.escape(content_text)
    else:
        content_html = ""

    # Select template
    if browser == "safari":
        template_file = TEMPLATES_DIR / "safari.html"
    else:
        template_file = TEMPLATES_DIR / "chrome.html"

    template_str = template_file.read_text(encoding="utf-8")
    tmpl = Template(template_str)
    html_out = tmpl.render(
        width=config.width,
        height=config.height,
        theme=theme_name,
        url=url,
        url_domain=url_domain,
        url_path=url_path,
        url_display=url_display,
        page_title=page_title,
        content_html=content_html,
        jetbrains_mono_b64=font_base64("JetBrainsMono-Regular.ttf"),
    )

    render_html_to_png(html_out, config.output, config.width, config.height)
