"""Empty init for templates package."""
