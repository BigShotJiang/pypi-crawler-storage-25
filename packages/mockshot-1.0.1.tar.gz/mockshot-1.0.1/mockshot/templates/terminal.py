"""Terminal screenshot template — HTML/CSS + Playwright rendering."""

from __future__ import annotations

import html
import json
from pathlib import Path

from jinja2 import Template

from ..core import ScreenshotConfig
from ..renderer import render_html_to_png
from ..asset_loader import font_base64

TEMPLATE_PATH = Path(__file__).parent.parent / "html_templates" / "terminal.html"


def _parse_commands_txt(text: str) -> list[dict]:
    """Parse legacy commands file. $ prefix = command, else output."""
    blocks: list[dict] = []
    current: dict | None = None
    for line in text.split("\n"):
        if line.startswith("$ "):
            if current is not None:
                blocks.append(current)
            current = {"cmd": line[2:], "output": []}
        elif current is not None:
            if line.strip():  # skip blank lines
                current["output"].append(line)
        else:
            if line.strip():
                blocks.append({"cmd": None, "output": [line]})
    if current is not None:
        blocks.append(current)
    return blocks


def _classify_line(line: str) -> str:
    """Return CSS class for an output line."""
    lower = line.strip().lower()
    if "passed" in lower or " ok" in lower.split() or "✓" in line:
        return "success"
    elif "failed" in lower or "error" in lower or "✗" in line:
        return "error"
    return "output"


def render(
    commands_text: str = "",
    os_type: str = "linux",
    user: str = "user",
    host: str = "desktop",
    config: ScreenshotConfig | None = None,
    cwd: str = "~",
    project_json: str | None = None,
) -> None:
    config = config or ScreenshotConfig()

    # ── Parse JSON project file if provided ──
    if project_json:
        proj = json.loads(project_json)
        os_type = proj.get("os", os_type)
        user = proj.get("user", user)
        host = proj.get("host", host)
        cwd = proj.get("cwd", cwd)
        raw_blocks = proj.get("commands", [])
        # Normalize: JSON commands already have cmd/output structure
        for b in raw_blocks:
            if "output" not in b:
                b["output"] = []
    elif commands_text:
        raw_blocks = _parse_commands_txt(commands_text)
    else:
        raw_blocks = []

    # Build template-friendly blocks
    blocks = []
    total_lines = 0
    for b in raw_blocks:
        cmd = html.escape(b["cmd"]) if b.get("cmd") else None
        output_lines = []
        for line in b.get("output", []):
            css_class = _classify_line(line)
            output_lines.append({"text": html.escape(line), "css_class": css_class})
        blocks.append({"command": cmd, "output": output_lines})
        if cmd is not None:
            total_lines += 1
        total_lines += len(output_lines)

    # Calculate scrollbar height
    titlebar_h = {"macos": 28, "windows": 34}.get(os_type, 38)
    visible_lines = (config.height - titlebar_h - 16) // 20
    content_h = config.height - titlebar_h
    if total_lines > 0:
        scrollbar_height = max(30, int(content_h * min(1.0, visible_lines / max(total_lines, 1))))
    else:
        scrollbar_height = 30

    template_str = TEMPLATE_PATH.read_text(encoding="utf-8")
    tmpl = Template(template_str)
    html_content = tmpl.render(
        width=config.width,
        height=config.height,
        os_type=os_type,
        user=user,
        host=host,
        cwd=cwd,
        blocks=blocks,
        scrollbar_height=scrollbar_height,
        jetbrains_mono_b64=font_base64("JetBrainsMono-Regular.ttf"),
        jetbrains_mono_bold_b64=font_base64("JetBrainsMono-Bold.ttf"),
    )

    render_html_to_png(html_content, config.output, config.width, config.height)
