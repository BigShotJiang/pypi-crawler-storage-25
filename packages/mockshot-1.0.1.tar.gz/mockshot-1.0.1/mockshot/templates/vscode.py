"""VS Code screenshot template — HTML/CSS + Playwright rendering."""

from __future__ import annotations

import html
import json
import re
from pathlib import Path

from jinja2 import Template

from ..core import ScreenshotConfig
from ..renderer import render_html_to_png
from ..asset_loader import (
    font_base64, codicon_font_base64, icon_for_file, icon_for_folder,
    vscode_logo_data_uri,
)

TEMPLATE_PATH = Path(__file__).parent.parent / "html_templates" / "vscode.html"

LANG_DISPLAY = {
    "python": "Python",
    "javascript": "JavaScript",
    "html": "HTML",
    "css": "CSS",
    "json": "JSON",
    "bash": "Shell Script",
    "java": "Java",
    "c": "C",
    "cpp": "C++",
    "rust": "Rust",
    "go": "Go",
    "typescript": "TypeScript",
}

# Extension to language mapping
EXT_TO_LANG = {
    ".py": "python", ".js": "javascript", ".jsx": "javascript",
    ".ts": "typescript", ".tsx": "typescript",
    ".html": "html", ".htm": "html", ".css": "css",
    ".json": "json", ".md": "markdown",
    ".sh": "bash", ".bash": "bash", ".zsh": "bash",
    ".java": "java", ".c": "c", ".h": "c",
    ".cpp": "cpp", ".cc": "cpp", ".hpp": "cpp",
    ".rs": "rust", ".go": "go",
    ".yml": "yaml", ".yaml": "yaml",
    ".toml": "toml", ".xml": "xml",
    ".sql": "sql",
}

# Syntax color mapping for minimap blocks
MINIMAP_COLORS = {
    "keyword": "#569cd6",
    "string": "#ce9178",
    "comment": "#6a9955",
    "number": "#b5cea8",
    "function": "#dcdcaa",
    "type": "#4ec9b0",
    "default": "#d4d4d4",
    "operator": "#d4d4d4",
}


def _generate_minimap_lines(code: str, language: str) -> list[list[dict]]:
    """Generate minimap color blocks from code lines."""
    lines = code.split("\n")
    minimap_lines = []

    for line in lines:
        stripped = line.rstrip()
        if not stripped:
            minimap_lines.append([])
            continue

        blocks = []
        content = stripped.lstrip()

        if content.startswith("#") or content.startswith("//") or content.startswith("/*"):
            w = min(max(len(content) * 0.4, 3), 45)
            blocks.append({"width": round(w), "color": MINIMAP_COLORS["comment"]})
        elif content.startswith(("def ", "class ", "function ", "const ", "let ", "var ", "import ", "from ", "return ", "if ", "else", "for ", "while ", "try:", "except", "with ", "async ", "await ")):
            kw_len = content.split(" ")[0] if " " in content else content
            blocks.append({"width": max(round(len(kw_len) * 0.5), 2), "color": MINIMAP_COLORS["keyword"]})
            rest = content[len(kw_len):]
            if rest.strip():
                w = min(max(len(rest.strip()) * 0.35, 2), 40)
                if '"' in rest or "'" in rest:
                    blocks.append({"width": round(w), "color": MINIMAP_COLORS["string"]})
                else:
                    blocks.append({"width": round(w), "color": MINIMAP_COLORS["default"]})
        elif '"' in content or "'" in content:
            w = min(max(len(content) * 0.35, 3), 45)
            blocks.append({"width": round(w), "color": MINIMAP_COLORS["string"]})
        elif content.startswith("@"):
            w = min(max(len(content) * 0.4, 3), 40)
            blocks.append({"width": round(w), "color": MINIMAP_COLORS["function"]})
        else:
            words = content.split()
            total_w = min(max(len(content) * 0.35, 3), 45)
            if len(words) > 1:
                w1 = round(total_w * 0.4)
                w2 = round(total_w * 0.6)
                blocks.append({"width": max(w1, 2), "color": MINIMAP_COLORS["default"]})
                blocks.append({"width": max(w2, 2), "color": MINIMAP_COLORS["default"]})
            else:
                blocks.append({"width": round(total_w), "color": MINIMAP_COLORS["default"]})

        minimap_lines.append(blocks)

    return minimap_lines


def _flatten_tree(nodes: list[dict], active_file: str, depth: int = 0) -> list[dict]:
    """Flatten a nested tree structure into a list with depth for rendering."""
    result = []
    for node in nodes:
        children = node.get("children")
        is_dir = children is not None
        is_open = node.get("open", False) if is_dir else False
        name = node["name"]

        entry = {
            "name": name,
            "depth": depth,
            "is_dir": is_dir,
            "is_open": is_open,
            "is_active": (not is_dir and name == active_file),
            "has_chevron": is_dir,
        }

        if is_dir:
            entry["icon"] = icon_for_folder(folder_name=name, opened=is_open)
        else:
            entry["icon"] = icon_for_file(name)

        result.append(entry)

        if is_dir and is_open and children:
            result.extend(_flatten_tree(children, active_file, depth + 1))

    return result


def _find_breadcrumb_path(nodes: list[dict], target: str, path: list[str] | None = None) -> list[str] | None:
    """Find the path from root to the target file in the tree."""
    if path is None:
        path = []
    for node in nodes:
        children = node.get("children")
        is_dir = children is not None
        name = node["name"]
        if not is_dir and name == target:
            return path + [name]
        if is_dir and children and node.get("open", False):
            result = _find_breadcrumb_path(children, target, path + [name])
            if result is not None:
                return result
    return None


def _detect_language(filename: str) -> str:
    """Detect language from filename extension."""
    ext = Path(filename).suffix.lower()
    return EXT_TO_LANG.get(ext, "text")


def render(
    code: str = "",
    language: str = "python",
    filename: str | None = None,
    config: ScreenshotConfig | None = None,
    git_branch: str = "main",
    encoding: str = "UTF-8",
    tree_json: str | None = None,
    tabs: list[str] | None = None,
    active_line: int = 1,
    visible_lines: tuple[int, int] | None = None,
    # Legacy params (ignored)
    sidebar: bool = False,
    sidebar_files: list[str] | None = None,
) -> None:
    config = config or ScreenshotConfig()

    # ── Parse the unified JSON ──
    tree_data = []
    tree_nodes = []
    root_name = ""
    show_sidebar = False

    if tree_json:
        tree = json.loads(tree_json)
        root_name = tree.get("root", "")
        tree_nodes = tree.get("tree", [])

        # Extract active_file info from JSON
        active_file_info = tree.get("active_file")
        if active_file_info:
            filename = active_file_info["name"]
            language = active_file_info.get("language") or _detect_language(filename)

            # Read content from content_path if provided and code is empty
            if not code:
                content_path = active_file_info.get("content_path")
                if content_path:
                    p = Path(content_path)
                    if p.exists():
                        code = p.read_text(encoding="utf-8")
                    else:
                        code = f"# File not found: {content_path}"

            # Visible lines interval
            vl = active_file_info.get("visible_lines")
            if vl and len(vl) == 2:
                visible_lines = (vl[0], vl[1])

        # Extract tabs from JSON
        json_tabs = tree.get("tabs")
        if json_tabs and not tabs:
            tabs = json_tabs

        # Extract git_branch from JSON
        json_branch = tree.get("git_branch")
        if json_branch:
            git_branch = json_branch

        if tree_nodes:
            show_sidebar = True
            tree_data = _flatten_tree(tree_nodes, filename or "")

    # Fallback filename
    if filename is None:
        ext_map = {
            "python": "main.py", "javascript": "index.js", "html": "index.html",
            "css": "style.css", "json": "data.json", "bash": "script.sh",
            "c": "main.c", "java": "Main.java",
        }
        filename = ext_map.get(language, f"file.{language}")

    # ── Slice code to visible lines ──
    all_lines = code.split("\n")
    total_lines = len(all_lines)

    if visible_lines:
        start_line = max(1, visible_lines[0])
        end_line = min(total_lines, visible_lines[1])
        visible_code = "\n".join(all_lines[start_line - 1 : end_line])
        first_line_num = start_line
        line_count = end_line - start_line + 1
        # Active line = center of visible range
        active_line = (start_line + end_line) // 2
    else:
        visible_code = code
        first_line_num = 1
        line_count = total_lines

    # ── Build tabs ──
    tab_list = []
    if tabs:
        for t in tabs:
            tab_list.append({
                "name": t,
                "icon": icon_for_file(t),
                "active": (t == filename),
            })
    else:
        tab_list.append({
            "name": filename,
            "icon": icon_for_file(filename),
            "active": True,
        })

    # ── Breadcrumbs ──
    breadcrumbs = []
    if root_name:
        breadcrumbs.append({"name": root_name, "icon": icon_for_folder(root_name, opened=True)})
    if tree_json and tree_nodes:
        tree_path = _find_breadcrumb_path(tree_nodes, filename)
        if tree_path:
            for i, segment in enumerate(tree_path):
                is_last = (i == len(tree_path) - 1)
                if is_last:
                    breadcrumbs.append({"name": segment, "icon": icon_for_file(segment)})
                else:
                    breadcrumbs.append({"name": segment, "icon": icon_for_folder(segment, opened=True)})
        else:
            breadcrumbs.append({"name": filename, "icon": icon_for_file(filename)})
    else:
        breadcrumbs.append({"name": filename, "icon": icon_for_file(filename)})

    # ── Escape code for HTML ──
    code_escaped = html.escape(visible_code)

    # ── Generate minimap from FULL code (not just visible) ──
    minimap_lines = _generate_minimap_lines(code, language)

    language_display = LANG_DISPLAY.get(language, language.capitalize())
    hljs_lang = language

    # ── Build line numbers ──
    line_numbers = list(range(first_line_num, first_line_num + line_count))

    template_str = TEMPLATE_PATH.read_text(encoding="utf-8")
    tmpl = Template(template_str)
    html_content = tmpl.render(
        width=config.width,
        height=config.height,
        filename=filename,
        code=code_escaped,
        language=hljs_lang,
        language_display=language_display,
        line_count=line_count,
        line_numbers=line_numbers,
        first_line_num=first_line_num,
        show_sidebar=show_sidebar,
        root_name=root_name,
        tree_data=tree_data,
        tab_list=tab_list,
        breadcrumbs=breadcrumbs,
        git_branch=git_branch,
        encoding=encoding,
        active_line=active_line,
        minimap_lines=minimap_lines,
        total_lines=total_lines,
        jetbrains_mono_b64=font_base64("JetBrainsMono-Regular.ttf"),
        jetbrains_mono_bold_b64=font_base64("JetBrainsMono-Bold.ttf"),
        codicon_b64=codicon_font_base64(),
        vscode_logo=vscode_logo_data_uri(),
    )

    render_html_to_png(html_content, config.output, config.width, config.height)
