"""Core classes and utilities."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ScreenshotConfig:
    width: int = 1920
    height: int = 1080
    theme: str = "dark"
    output: str = "screenshot.png"
    shadow: bool = True
    border_radius: int = 8
