"""HTML to PNG renderer using Playwright with smart browser detection."""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path


# Browser channels to try, in order of preference
_CHANNELS = ["msedge", "chrome", "chromium"]


def _launch_browser(playwright):
    """Try system browsers first, fall back to Playwright's bundled Chromium.

    Order:
      1. msedge   — always available on Windows 10/11
      2. chrome   — often installed on macOS/Linux
      3. chromium — often installed on Linux via apt
      4. Playwright bundled Chromium (requires 'playwright install chromium')
    """
    # Try system browsers via channel
    for channel in _CHANNELS:
        try:
            return playwright.chromium.launch(channel=channel, headless=True)
        except Exception:
            continue

    # Try Playwright's own Chromium (needs 'playwright install chromium')
    try:
        return playwright.chromium.launch(headless=True)
    except Exception:
        pass

    # Nothing works
    _print_install_help()
    sys.exit(1)


def _print_install_help():
    """Print a helpful error message when no browser is found."""
    import platform
    os_name = platform.system()

    msg = "\n✗ No compatible browser found.\n\n"

    if os_name == "Windows":
        msg += (
            "  This is unexpected — Edge should be available on Windows 10/11.\n"
            "  Try installing Chromium manually:\n"
            "    playwright install chromium\n"
        )
    elif os_name == "Darwin":
        msg += (
            "  Install Google Chrome from https://www.google.com/chrome/\n"
            "  Or install Chromium via Playwright:\n"
            "    playwright install chromium\n"
        )
    else:
        msg += (
            "  Install a Chromium-based browser:\n"
            "    sudo apt install chromium-browser    # Ubuntu/Debian\n"
            "    sudo dnf install chromium            # Fedora\n"
            "  Or install via Playwright:\n"
            "    playwright install chromium\n"
        )

    print(msg, file=sys.stderr)


def render_html_to_png(
    html_content: str,
    output_path: str,
    width: int = 1920,
    height: int = 1080,
) -> None:
    """Render HTML content to a PNG screenshot using Playwright."""
    from playwright.sync_api import sync_playwright

    with tempfile.NamedTemporaryFile(suffix=".html", delete=False, mode="w", encoding="utf-8") as f:
        f.write(html_content)
        tmp_path = f.name

    try:
        with sync_playwright() as p:
            browser = _launch_browser(p)
            page = browser.new_page(viewport={"width": width, "height": height})
            page.goto(Path(tmp_path).as_uri())
            # Wait for fonts to load
            page.wait_for_load_state("networkidle")
            page.wait_for_timeout(500)
            page.screenshot(path=output_path, type="png")
            browser.close()
    finally:
        Path(tmp_path).unlink(missing_ok=True)


def render_svg_to_png(svg_content: str, output_path: str, width: int, height: int) -> None:
    """Render SVG content to PNG via Playwright."""
    html = (
        f'<!DOCTYPE html><html><head><meta charset="utf-8"></head>'
        f'<body style="margin:0;padding:0;background:white;'
        f'width:{width}px;height:{height}px;overflow:hidden">'
        f'{svg_content}</body></html>'
    )
    render_html_to_png(html, output_path, width, height)


def render_svg_to_pdf(svg_content: str, output_path: str, width: int, height: int) -> None:
    """Render SVG content to PDF via Playwright."""
    from playwright.sync_api import sync_playwright

    html = (
        f'<!DOCTYPE html><html><head><meta charset="utf-8"></head>'
        f'<body style="margin:0;padding:0;background:white;'
        f'width:{width}px;height:{height}px;overflow:hidden">'
        f'{svg_content}</body></html>'
    )

    with tempfile.NamedTemporaryFile(suffix=".html", delete=False, mode="w", encoding="utf-8") as f:
        f.write(html)
        tmp_path = f.name

    try:
        with sync_playwright() as p:
            browser = _launch_browser(p)
            page = browser.new_page(viewport={"width": width, "height": height})
            page.goto(Path(tmp_path).as_uri())
            page.wait_for_load_state("networkidle")
            page.wait_for_timeout(500)
            page.pdf(
                path=output_path,
                width=f"{width}px",
                height=f"{height}px",
                print_background=True,
            )
            browser.close()
    finally:
        Path(tmp_path).unlink(missing_ok=True)


def save_diagram(svg_content: str, output_path: str, width: int, height: int) -> None:
    """Save diagram — auto-detect format from file extension (.svg, .png, .pdf)."""
    ext = Path(output_path).suffix.lower()
    if ext == ".svg":
        Path(output_path).write_text(svg_content, encoding="utf-8")
    elif ext == ".pdf":
        render_svg_to_pdf(svg_content, output_path, width, height)
    else:
        render_svg_to_png(svg_content, output_path, width, height)
