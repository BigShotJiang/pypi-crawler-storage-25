# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Union, Optional
from typing_extensions import Literal, TypeAlias

from .._models import BaseModel
from .asset_spec import AssetSpec

__all__ = ["AssetClassification", "Regular", "NeptuneReceiptToken", "LiquidStakingToken"]


class Regular(BaseModel):
    kind: Literal["regular"]

    neptune_receipt_asset: Optional[AssetSpec] = None
    """Provides a unique identifier for an asset for use throughout the Neptune API.

    IDs are unique across asset domains (contract tokens, native denoms, etc)
    """


class NeptuneReceiptToken(BaseModel):
    kind: Literal["neptune_receipt_token"]

    origin_asset: AssetSpec
    """Provides a unique identifier for an asset for use throughout the Neptune API.

    IDs are unique across asset domains (contract tokens, native denoms, etc)
    """


class LiquidStakingToken(BaseModel):
    kind: Literal["liquid_staking_token"]

    origin_asset: Optional[AssetSpec] = None
    """Provides a unique identifier for an asset for use throughout the Neptune API.

    IDs are unique across asset domains (contract tokens, native denoms, etc)
    """


AssetClassification: TypeAlias = Union[Regular, NeptuneReceiptToken, LiquidStakingToken]
