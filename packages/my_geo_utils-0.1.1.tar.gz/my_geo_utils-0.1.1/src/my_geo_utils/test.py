from src.my_geo_utils import haversine_distance, validate_coordinates, format_coordinates

# Расстояние между Москвой и Санкт-Петербургом
distance = haversine_distance(55.7558, 37.6173, 59.9343, 30.3351)
print(f"Расстояние: {distance:.2f} км")

# Проверка координат
print(validate_coordinates(55.7558, 37.6173))  # True
print(validate_coordinates(100, 200))  # False

# Форматирование
print(format_coordinates(55.7558, 37.6173))
