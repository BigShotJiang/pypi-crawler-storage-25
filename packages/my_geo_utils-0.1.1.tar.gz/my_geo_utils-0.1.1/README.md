Утилиты для работы с географическими координатами.
```bash
pip install my-geo-utils

## Использование

from my_geo_utils import haversine_distance, validate_coordinates, format_coordinates

# Расстояние между Москвой и Санкт-Петербургом
distance = haversine_distance(55.7558, 37.6173, 59.9343, 30.3351)
print(f"Расстояние: {distance:.2f} км")

# Проверка координат
print(validate_coordinates(55.7558, 37.6173))  # True

# Форматирование
print(format_coordinates(55.7558, 37.6173))  # 55.7558° N, 37.6173° E

## Функции

- `haversine_distance(lat1, lon1, lat2, lon2)` — расстояние между точками в км
- `validate_coordinates(lat, lon)` — проверка корректности координат
- `format_coordinates(lat, lon)` — форматирование координат

## Лицензия

MIT