"""
Bitacorista v2 — Motor del portero.
Regex, embeddings, blast radius, detección de eventos, resumen.
"""

import os
import re
import logging
import sqlite3
from pathlib import Path

from . import db as store

logger = logging.getLogger("bitacorista.engine")

# --- Modelo de embeddings (lazy singleton) ---

_model = None
_tokenizer = None
_MODEL_NAME = "paraphrase-multilingual-MiniLM-L12-v2"
_MODEL_DIR = Path(
    os.environ.get("BITACORISTA_MODEL_DIR", "")
) if os.environ.get("BITACORISTA_MODEL_DIR") else (
    Path(__file__).parent / "model" if (Path(__file__).parent / "model").exists()
    else Path(__file__).parent.parent / "model"
)
_MAX_TOKENS = 128

# --- Umbrales de similaridad ---
# Más bajo = más estricto (requiere mayor similitud para matchear)
UMBRAL_DUPLICADO = 0.3      # process_exchange: descartar si ya existe algo muy similar
UMBRAL_DUPLICADO_SCAN = 0.4 # batch_scan: más permisivo porque escanea retroactivamente
UMBRAL_MERGE = 0.6          # detect_merge: umbral para sugerir fusión de entradas
UMBRAL_LATENTES = 0.5       # explorar_latentes: conexiones no evidentes
UMBRAL_BREAK = 0.5          # detect_break: cambio de tema entre exchanges


# --- Event callbacks ---

_event_callbacks: list = []


def on_event(callback) -> None:
    """Register a callback for event detection. Called after each entry is committed.

    The callback receives a dict with: id, tipo, resumen, estado, blast_radius.
    If the callback raises, the error is logged but does not break the flow.

    Note: deduplication uses object identity. Named functions deduplicate correctly.
    Lambdas are new objects each time — use a named function to avoid duplicates.
    """
    if callback not in _event_callbacks:
        _event_callbacks.append(callback)


def remove_event_callback(callback) -> None:
    """Remove a previously registered callback."""
    try:
        _event_callbacks.remove(callback)
    except ValueError:
        pass


def _notify_callbacks(entry: dict) -> None:
    """Notify all registered callbacks. Errors are logged, not raised."""
    for cb in list(_event_callbacks):  # copy to avoid mutation during iteration
        try:
            cb(entry)
        except Exception as e:
            logger.warning("Event callback error: %s", e)


def _load_model() -> bool:
    """Carga el modelo ONNX y tokenizer. Una sola vez."""
    global _model, _tokenizer
    if _model is not None:
        return True
    try:
        import onnxruntime as ort
        import tokenizers

        model_path = _MODEL_DIR / "model.onnx"
        tok_path = _MODEL_DIR / "tokenizer.json"
        if not model_path.exists():
            logger.debug("Modelo ONNX no encontrado en %s", model_path)
            return False
        _model = ort.InferenceSession(str(model_path))
        _tokenizer = tokenizers.Tokenizer.from_file(str(tok_path))
        logger.debug("Modelo cargado: %s", _MODEL_NAME)
        return True
    except (ImportError, Exception) as e:
        logger.debug("Modelo no disponible: %s", e)
        return False


def embed(text: str) -> list[float] | None:
    """Genera embedding de un texto. Devuelve lista de 384 floats o None."""
    if not _load_model():
        return None

    assert _tokenizer is not None
    assert _model is not None
    encoded = _tokenizer.encode(text)
    ids = encoded.ids[:_MAX_TOKENS]
    mask = [1] * len(ids)
    types = [0] * len(ids)

    # Pad
    pad = _MAX_TOKENS - len(ids)
    ids += [0] * pad
    mask += [0] * pad
    types += [0] * pad

    outputs = _model.run(None, {
        "input_ids": [ids],
        "attention_mask": [mask],
        "token_type_ids": [types],
    })

    # Mean pooling
    import numpy as np
    token_embs = np.array(outputs[0][0])
    mask_np = np.array(mask).reshape(-1, 1)
    pooled = (token_embs * mask_np).sum(axis=0) / mask_np.sum()

    # Normalize
    norm = np.linalg.norm(pooled)
    if norm > 0:
        pooled = pooled / norm

    return list(pooled.tolist())


def resolve_embedding(
    conn: sqlite3.Connection,
    query: str | None = None,
) -> list[float] | None:
    """Resuelve el embedding para get_resumen.

    - Con query string: embeddea el texto.
    - Sin query, >=3 exchanges: auto-query con últimos 3.
    - Sin query, <3 exchanges o sin modelo: devuelve None (fallback clásico).
    """
    if query is not None:
        return embed(query)

    total = store.count_exchanges(conn)
    if total < 3:
        return None

    recent = store.get_exchanges(conn, desde=total - 3)
    if not recent:
        return None

    context = " ".join(e["user_msg"] for e in recent if e.get("user_msg"))
    if not context.strip():
        return None

    return embed(context)


# --- Patrones regex para detección ---

PATTERNS = {
    "CORRECCIÓN": [
        # Español
        r"(?i)(no,?\s+(eso\s+)?est[aá]\s+mal)",
        r"(?i)(corrijo|corregí|correg[ií])",
        r"(?i)(me equivoqu[eé])",
        r"(?i)(en realidad\s+(es|era|sería))",
        r"(?i)(eso no\s+(es|era)\s+así)",
        # English
        r"(?i)(no,?\s+that'?s?\s+(wrong|incorrect|not right))",
        r"(?i)(I\s+(was|stand)\s+corrected)",
        r"(?i)(my\s+(mistake|bad))",
        r"(?i)(actually,?\s+(it'?s?|that'?s?))",
        r"(?i)(let me correct\s+(that|this|myself))",
    ],
    "DESCARTE": [
        # Español
        r"(?i)(descart[aáoóeé]|descartem(os)?)",
        r"(?i)(no\s+(vamos|quiero|queremos)\s+(con|a usar))",
        r"(?i)(olvidate\s+de)",
        r"(?i)(eso\s+no\s+(va|sirve|funciona))",
        r"(?i)(sacá\s+eso|sacalo|quitá)",
        r"(?i)(a la mierda(\s+con\s*)?)",
        # English
        r"(?i)(discard|scrap|drop)\s+(that|this|it)",
        r"(?i)(we'?re?\s+not\s+(going\s+with|using))",
        r"(?i)(forget\s+(about\s+)?(that|this|it))",
        r"(?i)(that\s+(doesn'?t|won'?t)\s+(work|fly|fit))",
        r"(?i)(remove\s+(that|this|it))",
        r"(?i)(scratch\s+(that|this))",
    ],
    "DECISIÓN": [
        # Español
        r"(?i)(decidimos|decidí|decid[ií])",
        r"(?i)(vamos\s+(con|por)\s+)",
        r"(?i)(elegimos|eleg[ií])",
        r"(?i)(confirmado:?\s+)",
        r"(?i)(aprobado:?\s+)",
        r"(?i)(dale\s+(con|para\s+adelante))",
        # English
        r"(?i)(we\s+decided|I\s+decided|we'?ve\s+decided)",
        r"(?i)(let'?s?\s+go\s+with)",
        r"(?i)(we'?ll\s+(use|go\s+with|pick|choose))",
        r"(?i)(confirmed:?\s+)",
        r"(?i)(approved:?\s+)",
        r"(?i)(the\s+decision\s+is)",
    ],
    "CAMBIO-DE-TEMA": [
        # Español
        r"(?i)(cambiando\s+de\s+tema)",
        r"(?i)(otra\s+cosa:?\s+)",
        r"(?i)(par[aá],?\s+(ahora\s+)?hablemos\s+de)",
        r"(?i)(dejemos\s+eso,?\s+)",
        # English
        r"(?i)(changing\s+(the\s+)?topic)",
        r"(?i)(switching\s+gears)",
        r"(?i)(on\s+a\s+different\s+note)",
        r"(?i)(let'?s?\s+talk\s+about)",
        r"(?i)(moving\s+on\s+to)",
    ],
    "ENTREGABLE": [
        # Español
        r"(?i)(cre[aáeé]\s+(el\s+)?archivo)",
        r"(?i)(escrib[ií]\s+(el|un)\s+)",
        r"(?i)(generá|genera)\s+(el|un)\s+",
        r"(?i)(listo\s+el\s+)",
        # English
        r"(?i)(create\s+(the|a)\s+(\w+\s+)?(file|document))",
        r"(?i)(write\s+(the|a)\s+)",
        r"(?i)(generate\s+(the|a)\s+)",
        r"(?i)(the\s+\w+\s+is\s+(ready|done|complete))",
    ],
    "DESCUBRIMIENTO": [
        # Español
        r"(?i)(descubr[ií]|encontr[eé])",
        r"(?i)(resulta\s+que)",
        r"(?i)(no\s+sab[ií]a\s+que)",
        r"(?i)(mirá\s+(esto|lo\s+que))",
        # English
        r"(?i)(I\s+(discovered|found(\s+out)?))",
        r"(?i)(turns?\s+out\s+(that)?)",
        r"(?i)(I\s+didn'?t\s+know\s+(that|about))",
        r"(?i)(look\s+at\s+(this|what))",
    ],
    "HIPÓTESIS": [
        # Español
        r"(?i)(mi\s+hip[oó]tesis\s+(es|ser[ií]a))",
        r"(?i)(supongo\s+que)",
        r"(?i)(mi\s+teor[ií]a\s+(es|ser[ií]a))",
        r"(?i)(podr[ií]a\s+ser\s+que)",
        # English
        r"(?i)(my\s+hypothesis\s+is)",
        r"(?i)(I\s+(hypothesize|suppose|theorize)\s+that)",
        r"(?i)(my\s+theory\s+is)",
        r"(?i)(it\s+could\s+be\s+that)",
    ],
    "FUENTE": [
        # Español
        r"(?i)(seg[uú]n\s+)",
        r"(?i)(de\s+acuerdo\s+(con|a)\s+)",
        r"(?i)(la\s+fuente\s+(es|dice|indica))",
        r"(?i)(en\s+el\s+(paper|art[ií]culo|libro|estudio)\s+de)",
        # English
        r"(?i)(according\s+to\s+)",
        r"(?i)(the\s+source\s+(is|says|indicates))",
        r"(?i)(based\s+on\s+(the\s+)?(paper|article|book|study))",
        r"(?i)(as\s+per\s+)",
    ],
    "PREGUNTA": [
        # Español
        r"(?i)(explicame\s+)",
        r"(?i)(qu[eé]\s+(es|son|significa|quer[eé]s\s+decir))",
        r"(?i)(c[oó]mo\s+(funciona|se\s+usa|hago))",
        r"(?i)(por\s+qu[eé]\s+)",
        r"(?i)(no\s+entiendo\s+)",
        r"(?i)(a\s+qu[eé]\s+te\s+refer[ií]s)",
        r"(?i)(qu[eé]\s+ser[ií]a\s+)",
        # English
        r"(?i)(explain\s+(to\s+me\s+)?)",
        r"(?i)(what\s+(is|are|does)\s+)",
        r"(?i)(how\s+does\s+)",
        r"(?i)(why\s+(does|is|did)\s+)",
        r"(?i)(I\s+don'?t\s+understand)",
        r"(?i)(what\s+do\s+you\s+mean)",
        r"(?i)(can\s+you\s+(clarify|explain))",
    ],
}

# Copy of core patterns for reset
_CORE_PATTERNS = {k: list(v) for k, v in PATTERNS.items()}

# Tipos que solo están disponibles en modo proyecto
TIPOS_PROYECTO = {"HIPÓTESIS", "FUENTE"}


def load_patterns(pack_name: str) -> None:
    """Load a domain pattern pack, extending the core patterns."""
    from .patterns import get_pack
    pack = get_pack(pack_name)
    for tipo, new_patterns in pack.items():
        if tipo in PATTERNS:
            # Extend existing type with new patterns (avoid duplicates)
            existing = set(PATTERNS[tipo])
            PATTERNS[tipo].extend(p for p in new_patterns if p not in existing)
        else:
            PATTERNS[tipo] = list(new_patterns)


def reset_patterns() -> None:
    """Reset patterns to core only (remove all loaded packs)."""
    PATTERNS.clear()
    for k, v in _CORE_PATTERNS.items():
        PATTERNS[k] = list(v)


_NEGATORS_ES = {"no", "ni", "tampoco", "nunca", "jamás", "jamas", "sin", "nadie", "ninguno"}
_NEGATORS_EN = {
    "no", "not", "don't", "doesn't", "won't", "didn't", "never", "neither",
    "without", "haven't", "hasn't", "hadn't", "can't", "couldn't",
    "shouldn't", "wouldn't", "nobody", "none", "nor",
    "dont", "didnt", "havent", "hasnt",  # typos comunes en chat
}
_NEGATORS = _NEGATORS_ES | _NEGATORS_EN

# Separadores que cortan la relación entre un negador y el match
_SEPARATORS = {",", ".", ";", "pero", "sin embargo", "however", "but", "although", "aunque"}


def _has_negation(text: str, match_start: int, window: int = 30) -> bool:
    """Checks if there's a negation word syntactically linked to the match.

    A negator is only counted if there's no grammatical separator
    (comma, period, 'pero', 'but', etc.) between it and the match.
    """
    prefix = text[max(0, match_start - window):match_start].lower()
    words = prefix.split()

    for i, word in enumerate(words):
        clean = word.rstrip(",:;.")
        if clean in _NEGATORS:
            # Check if there's a separator between this negator and the match
            after_negator = " ".join(words[i:])
            has_separator = any(sep in after_negator for sep in _SEPARATORS)
            if not has_separator:
                return True
    return False


def _match_has_builtin_negation(matched_text: str) -> bool:
    """Patterns like 'we're not going with' already include negation."""
    lower = matched_text.lower()
    return any(neg in lower for neg in ("not ", "no ", "ni ", "don't", "doesn't", "won't"))


def _in_non_event_context(text: str, match_start: int, match_end: int) -> bool:
    """Checks if the match is inside quotes, code, or other non-event context."""
    # Check for quotes by counting from start (odd count = inside quotes)
    text_before = text[:match_start]
    if text_before.count('"') % 2 == 1:
        return True
    # Single quotes: only count isolated ones (not apostrophes in contractions)
    # "don't" has an apostrophe but it's not a quote delimiter
    isolated_singles = len(re.findall(r"(?<!\w)'|'(?!\w)", text_before))
    if isolated_singles % 2 == 1:
        return True
    # Check for code-like context (underscores adjacent to match)
    if match_start > 0 and text[match_start - 1] == "_":
        return True
    if match_end < len(text) and text[match_end] == "_":
        return True
    # "confirmado: True/False" pattern (code output)
    after_text = text[match_end:match_end + 15].strip()
    if after_text.startswith(("True", "False", "true", "false", "null", "None")):
        return True
    return False


def detect_events(text: str, modo: str = "sesion") -> list[dict]:
    """Detecta eventos en un texto. Devuelve lista de (tipo, match, posición).
    En modo 'sesion', filtra HIPÓTESIS y FUENTE.
    Filtra falsos positivos por negación y contexto no-evento."""
    events: list[dict] = []
    for tipo, patterns in PATTERNS.items():
        if modo == "sesion" and tipo in TIPOS_PROYECTO:
            continue
        for pattern in patterns:
            for match in re.finditer(pattern, text):
                # Skip if negated (but not if the pattern itself includes negation)
                if not _match_has_builtin_negation(match.group()):
                    if _has_negation(text, match.start()):
                        continue
                # Skip if inside quotes, code, or non-event context
                if _in_non_event_context(text, match.start(), match.end()):
                    continue
                # PREGUNTA requires a question mark in the surrounding sentence
                if tipo == "PREGUNTA":
                    sentence = text[max(0, match.start() - 20):match.end() + 80]
                    if "?" not in sentence:
                        continue
                events.append({
                    "tipo": tipo,
                    "match": match.group(),
                    "start": match.start(),
                    "context": text[max(0, match.start() - 50):match.end() + 100],
                })
    # Deduplicar: si dos patrones del MISMO tipo matchean cerca (±20 chars)
    events.sort(key=lambda e: int(e["start"]))
    unique: list[dict] = []
    for e in events:
        if unique and e["tipo"] == unique[-1]["tipo"] and abs(int(e["start"]) - int(unique[-1]["start"])) < 20:
            continue
        unique.append(e)
    return unique


def classify_estado(text: str, tipo: str) -> str:
    """Determina el estado de una entrada basado en señales explícitas."""
    text_lower = text.lower()

    # Descartado: tipo DESCARTE siempre es DESCARTADO (es oro, no basura)
    if tipo == "DESCARTE":
        return "DESCARTADO"

    # Pregunta: siempre INFERIDO (una pregunta no es una decisión firme)
    if tipo == "PREGUNTA":
        return "INFERIDO"

    # Firme: el usuario dijo algo explícito
    firme_signals = [
        # Español
        "registrá", "anotá", "confirmado", "aprobado",
        "decidimos", "decidí", "elegimos", "vamos con",
        # English
        "confirmed", "approved", "we decided", "i decided",
        "let's go with", "the decision is", "we've decided",
    ]
    for signal in firme_signals:
        if signal in text_lower:
            return "FIRME"

    # Corrección con señal explícita = FIRME
    if tipo == "CORRECCIÓN" and any(s in text_lower for s in [
        "corregí", "corrijo", "me equivoqué",
        "i was wrong", "my mistake", "let me correct",
    ]):
        return "FIRME"

    # Inferido: el sistema lo detectó pero no hubo señal explícita
    return "INFERIDO"


def extract_contexto(text: str, match_pos: int) -> str:
    """Extrae contexto alrededor de un match para registrar como entrada."""
    start = max(0, match_pos - 100)
    end = min(len(text), match_pos + 200)
    fragment = text[start:end].strip()
    # Limpiar: quitar saltos de línea dobles
    fragment = re.sub(r"\n{2,}", " | ", fragment)
    return fragment


def extract_resumen(context: str, tipo: str, match_text: str | None = None) -> str:
    """Extrae un resumen limpio del contexto detectado.
    Prioriza la oración que contiene el match."""
    clean = re.sub(r"\s+", " ", context).strip()
    sentences = re.split(r"[.!?\n]", clean)
    valid = [s.strip() for s in sentences if 10 < len(s.strip()) < 200]

    # Preferir la oración que contiene el match
    if match_text and valid:
        match_lower = match_text.lower()
        for s in valid:
            if match_lower in s.lower():
                return s
    # Fallback: primera oración válida
    if valid:
        return valid[0]
    return clean[:150].strip()


# --- Pipeline principal ---


def process_exchange(
    conn: sqlite3.Connection,
    user_msg: str,
    asst_msg: str | None = None,
    exchange_n: int | None = None,
    session_id: str | None = None,
) -> list[dict]:
    """Procesa un intercambio completo. Detecta eventos, registra entradas.
    Devuelve lista de entradas registradas."""

    modo = store.get_meta(conn, "modo") or "sesion"

    # Detectar eventos en mensaje del usuario
    events = detect_events(user_msg, modo=modo)

    # Separar el mensaje en oraciones para asignar contexto preciso
    sentences = re.split(r"(?<=[.!?])\s+", user_msg)

    # --- Fase 1: preparación (sin lock de escritura) ---
    # Embeddings, dedup, blast radius — todo ANTES de la transacción
    prepared = []
    for event in events:
        tipo = event["tipo"]
        match_text = event["match"]
        best_sentence = user_msg  # fallback
        for s in sentences:
            if match_text.lower() in s.lower() or event["match"].lower() in s.lower():
                best_sentence = s
                break
        contexto = best_sentence.strip()
        resumen = extract_resumen(contexto, tipo, match_text=match_text)
        estado = classify_estado(contexto, tipo)

        # Embedding (potencialmente lento — fuera de transacción)
        emb = embed(resumen)

        # Duplicado check (solo lectura)
        if emb:
            dup = store.detect_duplicate(conn, emb, umbral=UMBRAL_DUPLICADO)
            if dup:
                logger.debug(
                    "Duplicado detectado para '%s' → %s", resumen, dup["id"]
                )
                continue

        # Blast radius (informativo, solo lectura)
        br_info = None
        if emb:
            br_info = store.blast_radius(conn, emb, k=3)
            logger.debug(
                "Blast radius para '%s': %d afectadas", resumen, br_info["total"]
            )

        prepared.append({
            "tipo": tipo, "resumen": resumen, "contexto": contexto,
            "estado": estado, "emb": emb, "br_info": br_info,
        })

    # --- Fase 2: escritura (lock mínimo) ---
    registradas = []
    local_embeddings: list[list[float]] = []  # tracking intra-transacción para dedup
    conn.execute("BEGIN IMMEDIATE")
    try:
        if exchange_n is not None:
            store.add_exchange(conn, exchange_n, user_msg, asst_msg,
                               session_id=session_id, _commit=False)

        for p in prepared:
            # Re-check dedup contra DB (previene TOCTOU race con otros writers)
            if p["emb"]:
                dup = store.detect_duplicate(conn, p["emb"], umbral=UMBRAL_DUPLICADO)
                if dup:
                    logger.debug(
                        "Duplicado detectado (re-check) para '%s' → %s",
                        p["resumen"], dup["id"]
                    )
                    continue
                # Dedup intra-transacción: sqlite-vec puede no ver inserts del mismo BEGIN
                sim_local = max(
                    (sum(a * b for a, b in zip(p["emb"], other))
                     for other in local_embeddings),
                    default=0.0,
                )
                if sim_local > (1.0 - UMBRAL_DUPLICADO):
                    logger.debug(
                        "Duplicado intra-tx para '%s' (sim=%.3f)",
                        p["resumen"], sim_local,
                    )
                    continue
                local_embeddings.append(p["emb"])

            entry_id = store.add_entry(
                conn,
                tipo=p["tipo"],
                resumen=p["resumen"],
                contexto=p["contexto"],
                estado=p["estado"],
                embedding=p["emb"],
                embedding_model=_MODEL_NAME if p["emb"] else None,
                session_id=session_id,
                _commit=False,
            )

            # Auto-conectar con entradas similares
            if p["emb"]:
                similares = store.buscar_similares(conn, p["emb"], k=3, umbral=1.0)
                for sim_id, dist in similares:
                    if sim_id != entry_id:
                        store.add_edge(conn, entry_id, sim_id, "INFERRED", 1.0 - dist, _commit=False)

            registradas.append({
                "id": entry_id,
                "tipo": p["tipo"],
                "resumen": p["resumen"],
                "estado": p["estado"],
                "blast_radius": p["br_info"]["total"] if p["br_info"] else 0,
            })

        conn.execute("COMMIT")
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except Exception:
            pass
        raise

    # Notify callbacks (outside transaction — failures don't affect data)
    for entry in registradas:
        _notify_callbacks(entry)

    return registradas


def process_batch(conn: sqlite3.Connection, exchanges: list[dict], session_id: str | None = None) -> list[dict]:
    """Procesa un lote de intercambios. Devuelve todas las entradas registradas."""
    all_entries = []
    for ex in exchanges:
        entries = process_exchange(
            conn,
            user_msg=ex.get("user_msg", ""),
            asst_msg=ex.get("asst_msg"),
            exchange_n=ex.get("n"),
            session_id=session_id,
        )
        all_entries.extend(entries)
    return all_entries


# --- Detección de cambio de tema ---


def detect_break(conn: sqlite3.Connection, n_recent: int = 3) -> bool:
    """Detecta si hubo cambio de tema comparando los últimos exchanges.
    Usa embeddings si están disponibles, keywords si no."""
    exchanges = store.get_exchanges(conn)
    if len(exchanges) < n_recent * 2:
        return False

    recent = exchanges[-n_recent:]
    previous = exchanges[-(n_recent * 2):-n_recent]

    recent_text = " ".join(e["user_msg"] for e in recent)
    prev_text = " ".join(e["user_msg"] for e in previous)

    emb_recent = embed(recent_text)
    emb_prev = embed(prev_text)

    if emb_recent and emb_prev:
        # Coseno via dot product (ya normalizados)
        similarity = sum(a * b for a, b in zip(emb_recent, emb_prev))
        is_break = similarity < UMBRAL_BREAK
        logger.debug("Topic similarity: %.3f (break=%s)", similarity, is_break)
        return is_break

    # Fallback: keyword overlap
    words_recent = set(recent_text.lower().split())
    words_prev = set(prev_text.lower().split())
    if not words_prev:
        return False
    overlap = len(words_recent & words_prev) / len(words_prev)
    is_break = overlap < 0.2
    logger.debug("Keyword overlap: %.3f (break=%s)", overlap, is_break)
    return is_break


# --- Detección de merge ---


def detect_merge(conn: sqlite3.Connection, umbral: float = UMBRAL_MERGE) -> list[tuple[str, str, float]]:
    """Encuentra pares de entradas que podrían ser el mismo tema.
    Usa sqlite-vec para búsqueda O(n*k) en vez de O(n²).
    Devuelve lista de (id_a, id_b, similitud)."""
    entries = store.get_entries(conn)
    if len(entries) < 2:
        return []

    merges = []
    seen_pairs = set()

    for a in entries:
        if not a.get("embedding"):
            continue
        emb_a = store._blob_to_floats(a["embedding"])
        similares = store.buscar_similares(conn, emb_a, k=5, umbral=1.0 - umbral)
        for sim_id, dist in similares:
            if sim_id == a["id"]:
                continue
            sim = 1.0 - dist
            if sim < umbral:
                continue
            pair = tuple(sorted([a["id"], sim_id]))
            if pair in seen_pairs:
                continue
            seen_pairs.add(pair)
            # Verificar que no tienen edge ya
            existing = store.get_edges(conn, a["id"])
            already_connected = any(
                (e["source"] == sim_id or e["target"] == sim_id)
                for e in existing
            )
            if not already_connected:
                merges.append((a["id"], sim_id, sim))

    return merges


# --- Explorador: conexiones latentes ---


def explorar_latentes(conn: sqlite3.Connection, umbral: float = UMBRAL_LATENTES) -> list[dict]:
    """Encuentra pares de entradas similares que no están conectadas.
    Usa sqlite-vec para búsqueda O(n*k) en vez de O(n²)."""
    entries = store.get_entries(conn)
    if len(entries) < 2:
        return []

    latentes = []
    seen_pairs = set()

    for a in entries:
        if not a.get("embedding"):
            continue
        emb_a = store._blob_to_floats(a["embedding"])
        similares = store.buscar_similares(conn, emb_a, k=5, umbral=1.0 - umbral)
        for sim_id, dist in similares:
            if sim_id == a["id"]:
                continue
            sim = 1.0 - dist
            if sim < umbral:
                continue
            pair = tuple(sorted([a["id"], sim_id]))
            if pair in seen_pairs:
                continue
            seen_pairs.add(pair)
            sim_entry = store.get_entry(conn, sim_id)
            latentes.append({
                "a": a["id"],
                "b": sim_id,
                "resumen_a": a["resumen"],
                "resumen_b": sim_entry["resumen"] if sim_entry else "",
                "similitud": sim,
            })

    return latentes


# --- Proyectar: descartes para reevaluar ---


def proyectar_descartes(conn: sqlite3.Connection) -> list[dict]:
    """Lista descartes con su contexto, para reevaluación."""
    descartes = store.get_entries(conn, estado="DESCARTADO")
    return [
        {
            "id": e["id"],
            "resumen": e["resumen"],
            "contexto": e.get("contexto", ""),
            "timestamp": e["timestamp"],
        }
        for e in descartes
    ]


# --- Batch scan: barrer exchanges por eventos no registrados ---


def batch_scan(conn: sqlite3.Connection) -> list[dict]:
    """Barre todos los exchanges buscando eventos que no se registraron."""
    exchanges = store.get_exchanges(conn)
    entries = store.get_entries(conn)
    registered_resumes = {e["resumen"].lower() for e in entries}

    modo = store.get_meta(conn, "modo") or "sesion"
    unregistered = []
    for ex in exchanges:
        events = detect_events(ex["user_msg"], modo=modo)
        for event in events:
            resumen = extract_resumen(event["context"], event["tipo"])
            if resumen.lower() not in registered_resumes:
                # Check semántico si hay embeddings
                emb = embed(resumen)
                if emb:
                    dup = store.detect_duplicate(conn, emb, umbral=UMBRAL_DUPLICADO_SCAN)
                    if dup:
                        continue
                unregistered.append({
                    "exchange_n": ex["n"],
                    "tipo": event["tipo"],
                    "resumen": resumen,
                    "context": event["context"],
                })

    return unregistered
