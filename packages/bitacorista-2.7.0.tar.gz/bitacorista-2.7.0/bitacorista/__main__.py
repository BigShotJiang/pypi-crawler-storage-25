"""Allow running as python -m bitacorista."""
from .cli import main

if __name__ == "__main__":
    main()
