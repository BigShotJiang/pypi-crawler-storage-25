"""
Bitacorista v2 — Capa de datos.
Única puerta a SQLite. Nadie más toca la DB directo.
"""

import sqlite3
import struct
import datetime
import logging
from collections import deque
from pathlib import Path

logger = logging.getLogger("bitacorista.db")

# --- Esquema ---

TIPOS_SESION = (
    "'DECISIÓN','DESCUBRIMIENTO','ENTREGABLE','IDEA',"
    "'CAMBIO-DE-TEMA','CORRECCIÓN','PREMISA','DESCARTE','PREGUNTA'"
)
TIPOS_PROYECTO = TIPOS_SESION + ",'HIPÓTESIS','FUENTE'"


def _build_schema(modo: str = "sesion") -> str:
    """Build SQL schema. Single source of truth for both modes."""
    is_proyecto = modo == "proyecto"
    tipos = TIPOS_PROYECTO if is_proyecto else TIPOS_SESION
    session_id_col = "    session_id TEXT,\n" if is_proyecto else ""
    exchanges_pk = "PRIMARY KEY (n, session_id)" if is_proyecto else ""
    exchanges_n = "n INTEGER NOT NULL" if is_proyecto else "n INTEGER PRIMARY KEY"
    exchanges_session = "    session_id TEXT,\n" if is_proyecto else ""

    sql = f"""
PRAGMA journal_mode=WAL;
PRAGMA busy_timeout=5000;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS entries (
    id TEXT PRIMARY KEY,
    tipo TEXT NOT NULL CHECK(tipo IN ({tipos})),
    resumen TEXT NOT NULL,
    contexto TEXT,
    estado TEXT NOT NULL DEFAULT 'INFERIDO' CHECK(estado IN (
        'FIRME','INFERIDO','DESCARTADO','OBSOLETO'
    )),
    conecta_raw TEXT,
{session_id_col}    timestamp TEXT NOT NULL,
    embedding BLOB,
    embedding_model TEXT
);

CREATE TABLE IF NOT EXISTS edges (
    source TEXT NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
    target TEXT NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
    edge_type TEXT NOT NULL DEFAULT 'EXTRACTED',
    peso REAL DEFAULT 1.0,
    PRIMARY KEY (source, target, edge_type)
);

CREATE TABLE IF NOT EXISTS exchanges (
    {exchanges_n},
{exchanges_session}    user_msg TEXT NOT NULL,
    asst_msg TEXT,
    timestamp TEXT NOT NULL{"," if exchanges_pk else ""}
    {exchanges_pk}
);

CREATE TABLE IF NOT EXISTS session_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_entries_tipo ON entries(tipo);
CREATE INDEX IF NOT EXISTS idx_entries_estado ON entries(estado);
CREATE INDEX IF NOT EXISTS idx_entries_timestamp ON entries(timestamp);
CREATE TABLE IF NOT EXISTS tags (
    entry_id TEXT NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
    tag TEXT NOT NULL,
    PRIMARY KEY (entry_id, tag)
);

CREATE INDEX IF NOT EXISTS idx_edges_source ON edges(source);
CREATE INDEX IF NOT EXISTS idx_edges_target ON edges(target);
CREATE INDEX IF NOT EXISTS idx_tags_tag ON tags(tag);
"""
    if is_proyecto:
        sql += """
CREATE TABLE IF NOT EXISTS sessions (
    session_id TEXT PRIMARY KEY,
    name TEXT,
    created TEXT NOT NULL,
    last_active TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_entries_session ON entries(session_id);
CREATE INDEX IF NOT EXISTS idx_exchanges_session ON exchanges(session_id);
"""
    return sql

EMBEDDING_DIM = 384
UMBRAL_DUPLICADO_EXACTO = 0.15  # detect_duplicate: umbral estricto para duplicados casi idénticos

# --- Conexión ---


def open_db(path: str, validate: bool = False) -> sqlite3.Connection:
    """Abre o crea la DB. Configura PRAGMAs y sqlite-vec.
    validate=True verifica que el schema exista (para DBs existentes).

    Transaction model: isolation_level=None puts the connection in autocommit
    mode. All writes use explicit BEGIN IMMEDIATE / COMMIT / ROLLBACK to
    minimize lock duration with WAL journaling. This is intentional — Python's
    default isolation level issues implicit BEGINs that conflict with
    sqlite-vec virtual table operations and make transaction boundaries
    invisible. Every function that writes must manage its own transaction
    via the _commit parameter pattern."""
    db = sqlite3.connect(path, isolation_level=None)
    db.row_factory = sqlite3.Row

    # PRAGMAs
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA busy_timeout=5000")
    db.execute("PRAGMA foreign_keys=ON")

    # sqlite-vec
    try:
        db.enable_load_extension(True)
        import sqlite_vec
        sqlite_vec.load(db)
        db.enable_load_extension(False)
        logger.debug("sqlite-vec cargado")
    except (ImportError, Exception) as e:
        logger.debug("sqlite-vec no disponible: %s", e)

    # Validar schema si se pide
    if validate:
        try:
            db.execute("SELECT 1 FROM session_meta LIMIT 1")
        except sqlite3.OperationalError:
            db.close()
            raise ValueError(
                f"'{path}' no es una DB de bitacorista válida. "
                "Usá 'init' para crear una sesión nueva."
            )

    # Migrate schema if needed (e.g. PREGUNTA type added in v2.5.0)
    _migrate_schema(db)

    return db


def _migrate_schema(db: sqlite3.Connection) -> None:
    """Apply schema migrations for DBs created with older versions."""
    # Only migrate if entries table exists (skip for fresh DBs)
    tables = {r[0] for r in db.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ).fetchall()}
    if "entries" not in tables:
        return

    # Check if PREGUNTA is in the tipo CHECK constraint by trying an insert+rollback
    try:
        db.execute("BEGIN")
        db.execute(
            "INSERT INTO entries (id, tipo, resumen, estado, timestamp) "
            "VALUES ('_migration_test', 'PREGUNTA', '_test', 'INFERIDO', '2000-01-01')"
        )
        db.execute("DELETE FROM entries WHERE id = '_migration_test'")
        db.execute("COMMIT")
    except sqlite3.IntegrityError:
        # CHECK constraint doesn't include PREGUNTA — need to recreate table
        try:
            db.execute("ROLLBACK")
        except Exception:
            pass
        _recreate_entries_table(db)

    # Ensure tags table exists (added in v2.6.0)
    if "tags" not in tables:
        db.execute("BEGIN IMMEDIATE")
        try:
            db.execute("""
                CREATE TABLE IF NOT EXISTS tags (
                    entry_id TEXT NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
                    tag TEXT NOT NULL,
                    PRIMARY KEY (entry_id, tag)
                )
            """)
            db.execute("CREATE INDEX IF NOT EXISTS idx_tags_tag ON tags(tag)")
            db.execute("COMMIT")
            logger.info("Schema migrated: tags table created")
        except Exception:
            try:
                db.execute("ROLLBACK")
            except Exception:
                pass
            raise


def _recreate_entries_table(db: sqlite3.Connection) -> None:
    """Recreate entries table with updated CHECK constraint (preserves data)."""
    tipos = TIPOS_SESION
    # Check if this is a proyecto DB (has HIPÓTESIS/FUENTE)
    try:
        db.execute("SELECT 1 FROM sessions LIMIT 1")
        tipos = TIPOS_PROYECTO
    except sqlite3.OperationalError:
        pass

    db.execute("BEGIN IMMEDIATE")
    try:
        db.execute("ALTER TABLE entries RENAME TO _entries_old")
        db.execute(f"""
            CREATE TABLE entries (
                id TEXT PRIMARY KEY,
                tipo TEXT NOT NULL CHECK(tipo IN ({tipos})),
                resumen TEXT NOT NULL,
                contexto TEXT,
                estado TEXT NOT NULL DEFAULT 'INFERIDO' CHECK(estado IN (
                    'FIRME','INFERIDO','DESCARTADO','OBSOLETO'
                )),
                conecta_raw TEXT,
                session_id TEXT,
                timestamp TEXT NOT NULL,
                embedding BLOB,
                embedding_model TEXT
            )
        """)
        # Copy data using only columns that exist in both tables
        old_cols = {r[1] for r in db.execute("PRAGMA table_info(_entries_old)").fetchall()}
        new_cols = [r[1] for r in db.execute("PRAGMA table_info(entries)").fetchall()]
        common = [c for c in new_cols if c in old_cols]
        cols_str = ", ".join(common)
        db.execute(f"INSERT INTO entries ({cols_str}) SELECT {cols_str} FROM _entries_old")
        db.execute("DROP TABLE _entries_old")
        db.execute("CREATE INDEX IF NOT EXISTS idx_entries_tipo ON entries(tipo)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_entries_estado ON entries(estado)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_entries_timestamp ON entries(timestamp)")
        db.execute("COMMIT")
        logger.info("Schema migrated: entries table CHECK constraint updated")
    except Exception:
        try:
            db.execute("ROLLBACK")
            # Try to restore if rename happened but insert failed
            try:
                db.execute("ALTER TABLE _entries_old RENAME TO entries")
            except Exception:
                pass
        except Exception:
            pass
        raise


def init_db(path: str, modo: str = "sesion") -> sqlite3.Connection:
    """Crea la DB con el esquema completo. Devuelve la conexión abierta.
    modo: 'sesion' (default) o 'proyecto'."""
    db = open_db(path)
    db.executescript(_build_schema(modo))

    # Tabla virtual para búsqueda vectorial (solo si sqlite-vec disponible)
    try:
        db.execute(
            f"CREATE VIRTUAL TABLE IF NOT EXISTS vec_entries "
            f"USING vec0(embedding float[{EMBEDDING_DIM}] distance_metric=cosine)"
        )
        logger.debug("Tabla vec_entries creada")
    except Exception as e:
        logger.debug("vec_entries no creada (sqlite-vec no disponible): %s", e)

    # Meta inicial
    _set_meta_if_missing(db, "next_id", "1")
    _set_meta_if_missing(db, "created", datetime.datetime.now().isoformat())
    _set_meta_if_missing(db, "modo", modo)

    return db


# --- Entries ---


def next_id(db: sqlite3.Connection, _commit: bool = True) -> str:
    """Genera el siguiente ID (E001, E002, ...).
    _commit=False permite que el caller maneje la transacción."""
    n = int(get_meta(db, "next_id") or "1")
    entry_id = f"E{n:03d}"
    set_meta(db, "next_id", str(n + 1), _commit=_commit)
    return entry_id


def add_entry(
    db: sqlite3.Connection,
    tipo: str,
    resumen: str,
    contexto: str | None = None,
    estado: str = "INFERIDO",
    conecta_raw: str | None = None,
    embedding: list[float] | None = None,
    embedding_model: str | None = None,
    session_id: str | None = None,
    _commit: bool = True,
) -> str:
    """Registra una entrada. Devuelve el ID asignado.
    _commit=False permite que el caller maneje la transacción."""
    # Si _commit=True, envolver en transacción propia para atomicidad
    if _commit:
        db.execute("BEGIN IMMEDIATE")

    try:
        entry_id = next_id(db, _commit=False)
        ts = datetime.datetime.now().isoformat()
        modo = get_meta(db, "modo") or "sesion"

        emb_blob = _floats_to_blob(embedding) if embedding else None

        if modo == "proyecto" and session_id:
            db.execute(
                "INSERT INTO entries (id, tipo, resumen, contexto, estado, conecta_raw, "
                "session_id, timestamp, embedding, embedding_model) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (entry_id, tipo, resumen, contexto, estado, conecta_raw,
                 session_id, ts, emb_blob, embedding_model),
            )
        else:
            db.execute(
                "INSERT INTO entries (id, tipo, resumen, contexto, estado, conecta_raw, "
                "timestamp, embedding, embedding_model) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (entry_id, tipo, resumen, contexto, estado, conecta_raw, ts,
                 emb_blob, embedding_model),
            )

        # Índice vectorial
        if emb_blob:
            try:
                rowid = db.execute(
                    "SELECT rowid FROM entries WHERE id = ?", (entry_id,)
                ).fetchone()[0]
                db.execute(
                    "INSERT INTO vec_entries (rowid, embedding) VALUES (?, ?)",
                    (rowid, emb_blob),
                )
            except Exception as e:
                logger.warning("vec_entries insert failed for %s: %s", entry_id, e)

        if _commit:
            db.execute("COMMIT")
    except Exception:
        if _commit:
            try:
                db.execute("ROLLBACK")
            except Exception:
                pass
        raise

    logger.debug("Entrada %s (%s) registrada [%s]", entry_id, tipo, estado)
    return entry_id


def get_entry(db: sqlite3.Connection, entry_id: str) -> dict | None:
    """Devuelve una entrada por ID."""
    row = db.execute("SELECT * FROM entries WHERE id = ?", (entry_id,)).fetchone()
    return dict(row) if row else None


def get_entries(
    db: sqlite3.Connection,
    tipo: str | None = None,
    estado: str | None = None,
) -> list[dict]:
    """Lista entradas, opcionalmente filtradas por tipo y/o estado."""
    query = "SELECT * FROM entries WHERE 1=1"
    params = []
    if tipo:
        query += " AND tipo = ?"
        params.append(tipo)
    if estado:
        query += " AND estado = ?"
        params.append(estado)
    query += " ORDER BY timestamp"
    return [dict(r) for r in db.execute(query, params).fetchall()]


def update_estado(db: sqlite3.Connection, entry_id: str, nuevo_estado: str) -> None:
    """Cambia el estado de una entrada."""
    db.execute("BEGIN IMMEDIATE")
    try:
        db.execute(
            "UPDATE entries SET estado = ? WHERE id = ?", (nuevo_estado, entry_id)
        )
        db.execute("COMMIT")
    except Exception:
        try:
            db.execute("ROLLBACK")
        except Exception:
            pass
        raise


# --- Edges ---


def add_edge(
    db: sqlite3.Connection,
    source: str,
    target: str,
    edge_type: str = "EXTRACTED",
    peso: float = 1.0,
    _commit: bool = True,
) -> None:
    """Agrega una conexión entre dos entradas.
    _commit=False permite que el caller maneje la transacción."""
    if _commit:
        db.execute("BEGIN IMMEDIATE")
    try:
        db.execute(
            "INSERT OR IGNORE INTO edges (source, target, edge_type, peso) "
            "VALUES (?, ?, ?, ?)",
            (source, target, edge_type, peso),
        )
        if _commit:
            db.execute("COMMIT")
    except Exception:
        if _commit:
            try:
                db.execute("ROLLBACK")
            except Exception:
                pass
        raise


def get_edges(db: sqlite3.Connection, entry_id: str | None = None) -> list[dict]:
    """Lista edges. Si se pasa entry_id, filtra por source o target."""
    if entry_id:
        rows = db.execute(
            "SELECT * FROM edges WHERE source = ? OR target = ?",
            (entry_id, entry_id),
        ).fetchall()
    else:
        rows = db.execute("SELECT * FROM edges").fetchall()
    return [dict(r) for r in rows]


# --- Tags ---


_MAX_TAG_LENGTH = 50


def _normalize_tag(tag: str) -> str:
    """Normaliza un tag: strip, lowercase, valida largo y contenido."""
    tag = tag.strip().lower()
    if not tag:
        raise ValueError("Tag vacío")
    if len(tag) > _MAX_TAG_LENGTH:
        raise ValueError(f"Tag demasiado largo (máx {_MAX_TAG_LENGTH} chars)")
    return tag


def add_tag(db: sqlite3.Connection, entry_id: str, tag: str) -> None:
    """Agrega un tag a una entry. Normaliza: strip + lowercase."""
    tag = _normalize_tag(tag)
    entry = get_entry(db, entry_id)
    if not entry:
        raise ValueError(f"Entry {entry_id} no encontrada")
    db.execute("BEGIN IMMEDIATE")
    try:
        db.execute(
            "INSERT OR IGNORE INTO tags (entry_id, tag) VALUES (?, ?)",
            (entry_id, tag),
        )
        db.execute("COMMIT")
    except Exception:
        try:
            db.execute("ROLLBACK")
        except Exception:
            pass
        raise


def remove_tag(db: sqlite3.Connection, entry_id: str, tag: str) -> None:
    """Quita un tag de una entry."""
    tag = _normalize_tag(tag)
    entry = get_entry(db, entry_id)
    if not entry:
        raise ValueError(f"Entry {entry_id} no encontrada")
    db.execute("BEGIN IMMEDIATE")
    try:
        db.execute(
            "DELETE FROM tags WHERE entry_id = ? AND tag = ?",
            (entry_id, tag),
        )
        db.execute("COMMIT")
    except Exception:
        try:
            db.execute("ROLLBACK")
        except Exception:
            pass
        raise


def get_tags(db: sqlite3.Connection, entry_id: str) -> list[str]:
    """Lista los tags de una entry."""
    rows = db.execute(
        "SELECT tag FROM tags WHERE entry_id = ? ORDER BY tag",
        (entry_id,),
    ).fetchall()
    return [r[0] for r in rows]


def get_entries_by_tag(db: sqlite3.Connection, tag: str) -> list[dict]:
    """Lista entries que tienen un tag específico."""
    tag = tag.strip().lower()
    rows = db.execute(
        "SELECT e.* FROM entries e "
        "JOIN tags t ON t.entry_id = e.id "
        "WHERE t.tag = ? ORDER BY e.timestamp",
        (tag,),
    ).fetchall()
    return [dict(r) for r in rows]


def list_tags(db: sqlite3.Connection) -> list[dict]:
    """Lista todos los tags con cantidad de entries."""
    rows = db.execute(
        "SELECT tag, COUNT(*) as count FROM tags GROUP BY tag ORDER BY count DESC, tag"
    ).fetchall()
    return [{"tag": r[0], "count": r[1]} for r in rows]


# --- Exchanges ---


def add_exchange(
    db: sqlite3.Connection,
    n: int,
    user_msg: str,
    asst_msg: str | None = None,
    session_id: str | None = None,
    _commit: bool = True,
) -> None:
    """Registra un intercambio.
    _commit=False permite que el caller maneje la transacción."""
    if _commit:
        db.execute("BEGIN IMMEDIATE")
    try:
        ts = datetime.datetime.now().isoformat()
        modo = get_meta(db, "modo") or "sesion"
        if modo == "proyecto" and session_id:
            db.execute(
                "INSERT OR REPLACE INTO exchanges (n, session_id, user_msg, asst_msg, timestamp) "
                "VALUES (?, ?, ?, ?, ?)",
                (n, session_id, user_msg, asst_msg, ts),
            )
        else:
            db.execute(
                "INSERT OR REPLACE INTO exchanges (n, user_msg, asst_msg, timestamp) "
                "VALUES (?, ?, ?, ?)",
                (n, user_msg, asst_msg, ts),
            )
        if _commit:
            db.execute("COMMIT")
    except Exception:
        if _commit:
            try:
                db.execute("ROLLBACK")
            except Exception:
                pass
        raise


def get_exchanges(db: sqlite3.Connection, desde: int = 0, session_id: str | None = None) -> list[dict]:
    """Lista intercambios desde el número indicado, opcionalmente por sesión."""
    if session_id:
        return [
            dict(r)
            for r in db.execute(
                "SELECT * FROM exchanges WHERE n >= ? AND session_id = ? ORDER BY n",
                (desde, session_id),
            ).fetchall()
        ]
    return [
        dict(r)
        for r in db.execute(
            "SELECT * FROM exchanges WHERE n >= ? ORDER BY n", (desde,)
        ).fetchall()
    ]


def count_exchanges(db: sqlite3.Connection) -> int:
    """Cuenta total de intercambios."""
    row = db.execute("SELECT COUNT(*) FROM exchanges").fetchone()
    return int(row[0]) if row else 0


# --- Session Meta ---


def set_meta(db: sqlite3.Connection, key: str, value: str, _commit: bool = True) -> None:
    """Guarda un valor de metadata.
    _commit=False permite que el caller maneje la transacción."""
    if _commit:
        db.execute("BEGIN IMMEDIATE")
    try:
        db.execute(
            "INSERT OR REPLACE INTO session_meta (key, value) VALUES (?, ?)",
            (key, value),
        )
        if _commit:
            db.execute("COMMIT")
    except Exception:
        if _commit:
            try:
                db.execute("ROLLBACK")
            except Exception:
                pass
        raise


def get_meta(db: sqlite3.Connection, key: str) -> str | None:
    """Lee un valor de metadata. Devuelve None si no existe."""
    row = db.execute(
        "SELECT value FROM session_meta WHERE key = ?", (key,)
    ).fetchone()
    return row[0] if row else None


def _set_meta_if_missing(db: sqlite3.Connection, key: str, value: str) -> None:
    """Solo escribe si la key no existe."""
    db.execute("BEGIN IMMEDIATE")
    try:
        db.execute(
            "INSERT OR IGNORE INTO session_meta (key, value) VALUES (?, ?)",
            (key, value),
        )
        db.execute("COMMIT")
    except Exception:
        try:
            db.execute("ROLLBACK")
        except Exception:
            pass
        raise


# --- Búsqueda semántica ---


def buscar_similares(
    db: sqlite3.Connection,
    embedding: list[float],
    k: int = 5,
    umbral: float | None = None,
) -> list[tuple[str, float]]:
    """Busca las k entradas más similares al embedding dado.
    Devuelve lista de (id, distancia). Requiere sqlite-vec."""
    emb_blob = _floats_to_blob(embedding)
    try:
        rows = db.execute(
            "SELECT e.id, v.distance FROM vec_entries v "
            "JOIN entries e ON e.rowid = v.rowid "
            "WHERE v.embedding MATCH ? AND k = ? "
            "ORDER BY v.distance",
            (emb_blob, k),
        ).fetchall()
        if umbral is not None:
            rows = [r for r in rows if r[1] <= umbral]
        return [(r[0], r[1]) for r in rows]
    except Exception as e:
        logger.warning("buscar_similares failed: %s", e)
        return []


def detect_duplicate(
    db: sqlite3.Connection,
    embedding: list[float],
    umbral: float = UMBRAL_DUPLICADO_EXACTO,
) -> dict | None:
    """Busca si ya existe una entrada muy similar. Devuelve la entrada o None."""
    resultados = buscar_similares(db, embedding, k=1, umbral=umbral)
    if resultados:
        entry_id, dist = resultados[0]
        return get_entry(db, entry_id)
    return None


# --- Grafo: BFS ---


def bfs(db: sqlite3.Connection, start_id: str, max_depth: int = 3) -> list[tuple[str, int]]:
    """BFS desde una entrada. Devuelve lista de (id, profundidad)."""
    visited = {start_id: 0}
    queue = deque([start_id])
    result = []

    while queue:
        current = queue.popleft()
        depth = visited[current]
        if depth > 0:
            result.append((current, depth))
        if depth >= max_depth:
            continue

        edges = db.execute(
            "SELECT source, target FROM edges WHERE source = ? OR target = ?",
            (current, current),
        ).fetchall()

        for edge in edges:
            neighbor = edge[1] if edge[0] == current else edge[0]
            if neighbor not in visited:
                visited[neighbor] = depth + 1
                queue.append(neighbor)

    return result


def blast_radius(
    db: sqlite3.Connection,
    embedding: list[float],
    k: int = 5,
    max_depth: int = 3,
) -> dict:
    """Calcula blast radius: encuentra entradas similares y recorre el grafo.
    Devuelve {entry_points: [...], affected: [...], total: int}."""
    similares = buscar_similares(db, embedding, k=k)
    affected: dict[str, int] = {}

    for entry_id, dist in similares:
        for node_id, depth in bfs(db, entry_id, max_depth):
            if node_id not in affected or affected[node_id] > depth:
                affected[node_id] = depth

    return {
        "entry_points": [(eid, d) for eid, d in similares],
        "affected": [(nid, depth) for nid, depth in affected.items()],
        "total": len(affected),
    }


# --- Resumen vivo ---


def get_stats(db: sqlite3.Connection) -> dict:
    """Genera estadísticas de la sesión."""
    total_entries = db.execute("SELECT COUNT(*) FROM entries").fetchone()[0]
    total_exchanges = count_exchanges(db)

    # Entries por tipo
    by_tipo: dict[str, int] = {}
    for row in db.execute("SELECT tipo, COUNT(*) FROM entries GROUP BY tipo ORDER BY COUNT(*) DESC"):
        by_tipo[row[0]] = row[1]

    # Entries por estado
    by_estado: dict[str, int] = {}
    for row in db.execute("SELECT estado, COUNT(*) FROM entries GROUP BY estado ORDER BY COUNT(*) DESC"):
        by_estado[row[0]] = row[1]

    # Entries más conectadas (top 5)
    top_connected: list[dict] = []
    for row in db.execute("""
        SELECT id, resumen, connections FROM (
            SELECT e.id, e.resumen, (
                SELECT COUNT(*) FROM edges WHERE source = e.id OR target = e.id
            ) as connections
            FROM entries e
        )
        WHERE connections > 0
        ORDER BY connections DESC
        LIMIT 5
    """):
        top_connected.append({"id": row[0], "resumen": row[1], "connections": row[2]})

    # Tasa de detección
    rate = round(total_entries / total_exchanges, 2) if total_exchanges > 0 else 0

    return {
        "entries": total_entries,
        "exchanges": total_exchanges,
        "detection_rate": rate,
        "by_tipo": by_tipo,
        "by_estado": by_estado,
        "top_connected": top_connected,
    }


def _superseded_ids(db: sqlite3.Connection) -> set[str]:
    """IDs de entries que fueron reemplazadas (target de un edge SUPERSEDES)."""
    rows = db.execute(
        "SELECT target FROM edges WHERE edge_type = 'SUPERSEDES'"
    ).fetchall()
    return {r[0] for r in rows}


def _active_contradicts(db: sqlite3.Connection, superseded: set[str]) -> list[dict]:
    """Edges CONTRADICTS donde ambos extremos están vigentes (no superados)."""
    rows = db.execute(
        "SELECT source, target FROM edges WHERE edge_type = 'CONTRADICTS'"
    ).fetchall()
    return [
        {"source": r[0], "target": r[1]}
        for r in rows
        if r[0] not in superseded and r[1] not in superseded
    ]


def get_stale_inferidos(
    db: sqlite3.Connection,
    threshold: int = 5,
) -> list[dict]:
    """INFERIDO entries con >= threshold exchanges posteriores a su creación.

    Devuelve lista de dicts con los campos de la entry + 'exchanges_since'.
    Usa una sola query (no N+1)."""
    rows = db.execute(
        "SELECT e.*, COUNT(x.n) AS exchanges_since "
        "FROM entries e "
        "LEFT JOIN exchanges x ON x.timestamp > e.timestamp "
        "WHERE e.estado = 'INFERIDO' "
        "GROUP BY e.id "
        "HAVING COUNT(x.n) >= ?",
        (threshold,),
    ).fetchall()
    return [dict(r) for r in rows]


def merge_entries(
    db: sqlite3.Connection,
    entry_a_id: str,
    entry_b_id: str,
    resumen: str,
    contexto: str | None = None,
) -> str:
    """Fusiona dos entries en una nueva.

    Crea entry nueva con el resumen dado, marca las originales OBSOLETO,
    crea edges SUPERSEDES, y copia edges existentes. Devuelve el ID de la nueva.
    """
    if entry_a_id == entry_b_id:
        raise ValueError("No se puede fusionar una entry consigo misma")

    a = get_entry(db, entry_a_id)
    b = get_entry(db, entry_b_id)
    if not a:
        raise ValueError(f"Entry {entry_a_id} no encontrada")
    if not b:
        raise ValueError(f"Entry {entry_b_id} no encontrada")

    for entry in (a, b):
        if entry["estado"] == "OBSOLETO":
            raise ValueError(f"Entry {entry['id']} ya es OBSOLETO (posiblemente ya fue mergeada)")

    # Tipo: el de la más reciente
    tipo = b["tipo"] if b["timestamp"] >= a["timestamp"] else a["tipo"]

    # Estado: FIRME si alguna era FIRME
    estado = "FIRME" if a["estado"] == "FIRME" or b["estado"] == "FIRME" else "INFERIDO"

    # Embedding: promedio renormalizado si ambos existen
    emb = None
    emb_model = None
    if a.get("embedding") and b.get("embedding"):
        floats_a = _blob_to_floats(a["embedding"])
        floats_b = _blob_to_floats(b["embedding"])
        emb = [(fa + fb) / 2.0 for fa, fb in zip(floats_a, floats_b)]
        # Renormalizar a norma 1 (MiniLM produce vectores normalizados)
        norm = sum(x * x for x in emb) ** 0.5
        if norm > 0:
            emb = [x / norm for x in emb]
        emb_model = a.get("embedding_model") or b.get("embedding_model")

    db.execute("BEGIN IMMEDIATE")
    try:
        # Crear nueva entry
        new_id = add_entry(
            db, tipo=tipo, resumen=resumen, contexto=contexto,
            estado=estado, embedding=emb, embedding_model=emb_model,
            _commit=False,
        )

        # Marcar originales como OBSOLETO
        db.execute("UPDATE entries SET estado = 'OBSOLETO' WHERE id = ?", (entry_a_id,))
        db.execute("UPDATE entries SET estado = 'OBSOLETO' WHERE id = ?", (entry_b_id,))

        # Crear edges SUPERSEDES
        add_edge(db, new_id, entry_a_id, edge_type="SUPERSEDES", _commit=False)
        add_edge(db, new_id, entry_b_id, edge_type="SUPERSEDES", _commit=False)

        # Copiar edges de a y b a la nueva (excepto edges entre a y b)
        old_ids = {entry_a_id, entry_b_id}
        for old_id in old_ids:
            edges = get_edges(db, old_id)
            for edge in edges:
                src, tgt, etype = edge["source"], edge["target"], edge["edge_type"]
                # No copiar edges entre las dos originales
                if src in old_ids and tgt in old_ids:
                    continue
                # No copiar SUPERSEDES (ya creamos los nuevos)
                if etype == "SUPERSEDES":
                    continue
                # Redirigir: reemplazar el old_id por new_id
                new_src = new_id if src == old_id else src
                new_tgt = new_id if tgt == old_id else tgt
                add_edge(db, new_src, new_tgt, edge_type=etype, peso=edge["peso"], _commit=False)

        db.execute("COMMIT")
    except Exception:
        try:
            db.execute("ROLLBACK")
        except Exception:
            pass
        raise

    logger.info("Merge %s + %s → %s", entry_a_id, entry_b_id, new_id)
    return new_id


def get_startup_alert(db: sqlite3.Connection) -> str | None:
    """Genera el texto de alerta para inicio de sesión.

    Combina resumen clásico (sin query, sin embeddings) + conteo de pendientes.
    Devuelve None si no hay datos (sesión nueva o DB vacía).
    """
    total = db.execute("SELECT COUNT(*) FROM entries").fetchone()[0]
    if total == 0:
        return None

    resumen = get_resumen(db)  # classic mode, no embedding
    stale = get_stale_inferidos(db)

    lines = ["BITACORISTA — Memoria de sesiones anteriores:", ""]
    lines.append(resumen)

    if stale:
        lines.append("")
        lines.append(f"Pendientes de revisión: {len(stale)} entries sin confirmar.")
        lines.append("Usá 'bitacorista pendientes' para revisarlos.")

    return "\n".join(lines)


def get_resumen(
    db: sqlite3.Connection,
    embedding: list[float] | None = None,
    fmt: str = "text",
    max_entries: int = 20,
) -> str | dict:
    """Genera el resumen vivo para inyectar al contexto de la IA.

    Args:
        embedding: vector de búsqueda (384 floats). Si se pasa, filtra por
            relevancia semántica. Si no, devuelve las últimas entries por estado.
        fmt: "text" (default) o "json".
        max_entries: máximo de entries a incluir (default 20).

    Returns:
        str si fmt="text", dict si fmt="json".
    """
    if max_entries < 1:
        max_entries = 1

    superseded = _superseded_ids(db)
    stale_ids = {e["id"] for e in get_stale_inferidos(db)}
    excluded = superseded | stale_ids

    if embedding is not None:
        # Modo semántico: buscar por relevancia
        similares = buscar_similares(db, embedding, k=max_entries * 2)
        # Filtrar superados/stale y armar lista
        entries_ranked = []
        for eid, dist in similares:
            if eid in excluded:
                continue
            entry = get_entry(db, eid)
            if entry:
                entry["_distance"] = dist
                entries_ranked.append(entry)
            if len(entries_ranked) >= max_entries:
                break
    else:
        # Modo clásico: últimas entries por estado, sin superados/stale
        all_entries = get_entries(db)
        entries_ranked = [e for e in all_entries if e["id"] not in excluded]
        entries_ranked = entries_ranked[-max_entries:]

    contradicts = _active_contradicts(db, superseded)

    total = db.execute("SELECT COUNT(*) FROM entries").fetchone()[0]
    exchanges = count_exchanges(db)

    if fmt == "json":
        return {
            "entries": [
                {
                    "id": e["id"],
                    "tipo": e["tipo"],
                    "estado": e["estado"],
                    "resumen": e["resumen"],
                    "contexto": e.get("contexto"),
                    "distance": e.get("_distance"),
                }
                for e in entries_ranked
            ],
            "contradicts": contradicts,
            "stale_count": len(stale_ids),
            "total_entries": total,
            "total_exchanges": exchanges,
            "mode": "semantic" if embedding is not None else "classic",
        }

    # fmt="text"
    lines: list[str] = []
    known_estados = {"FIRME", "DESCARTADO", "INFERIDO"}

    firmes = [e for e in entries_ranked if e["estado"] == "FIRME"]
    descartados = [e for e in entries_ranked if e["estado"] == "DESCARTADO"]
    inferidos = [e for e in entries_ranked if e["estado"] == "INFERIDO"]
    otros = [e for e in entries_ranked if e["estado"] not in known_estados]

    if firmes:
        lines.append("DECISIONES FIRMES:")
        for e in firmes:
            lines.append(f"  - [{e['tipo']}] {e['resumen']}")

    if descartados:
        lines.append("")
        lines.append("NO PROPONER (descartado):")
        for e in descartados:
            ctx = f" — {e['contexto']}" if e.get("contexto") else ""
            lines.append(f"  - {e['resumen']}{ctx}")

    if inferidos:
        lines.append("")
        lines.append("INFERIDO:")
        for e in inferidos:
            lines.append(f"  - {e['resumen']}")

    if otros:
        lines.append("")
        lines.append("OTROS:")
        for e in otros:
            lines.append(f"  - [{e['tipo']}] [{e['estado']}] {e['resumen']}")

    if contradicts:
        lines.append("")
        lines.append("CONFLICTOS ACTIVOS:")
        for c in contradicts:
            src = get_entry(db, c["source"])
            tgt = get_entry(db, c["target"])
            src_r = src["resumen"] if src else c["source"]
            tgt_r = tgt["resumen"] if tgt else c["target"]
            lines.append(f"  - \"{src_r}\" contradice \"{tgt_r}\"")

    lines.append("")
    lines.append(f"[{total} entradas, {exchanges} intercambios]")

    return "\n".join(lines)


# --- Proyecto: funciones cross-session ---


def create_session(db: sqlite3.Connection, name: str | None = None) -> str:
    """Crea una nueva sesión dentro de un proyecto. Devuelve session_id."""
    ts = datetime.datetime.now()
    session_id = f"S-{ts.strftime('%Y%m%d-%H%M%S-%f')}"
    db.execute("BEGIN IMMEDIATE")
    try:
        db.execute(
            "INSERT INTO sessions (session_id, name, created, last_active) "
            "VALUES (?, ?, ?, ?)",
            (session_id, name or session_id, ts.isoformat(), ts.isoformat()),
        )
        set_meta(db, "active_session", session_id, _commit=False)
        db.execute("COMMIT")
    except Exception:
        try:
            db.execute("ROLLBACK")
        except Exception:
            pass
        raise
    logger.debug("Sesión creada: %s", session_id)
    return session_id


def get_active_session(db: sqlite3.Connection) -> str | None:
    """Devuelve el session_id activo, o None."""
    return get_meta(db, "active_session")


def list_sessions(db: sqlite3.Connection) -> list[dict]:
    """Lista todas las sesiones del proyecto."""
    try:
        return [
            dict(r) for r in db.execute(
                "SELECT * FROM sessions ORDER BY created"
            ).fetchall()
        ]
    except sqlite3.OperationalError:
        return []


def touch_session(db: sqlite3.Connection, session_id: str) -> None:
    """Actualiza last_active de la sesión."""
    try:
        db.execute("BEGIN IMMEDIATE")
        db.execute(
            "UPDATE sessions SET last_active = ? WHERE session_id = ?",
            (datetime.datetime.now().isoformat(), session_id),
        )
        db.execute("COMMIT")
    except Exception as e:
        try:
            db.execute("ROLLBACK")
        except Exception:
            pass
        logger.warning("touch_session failed for %s: %s", session_id, e)


def evidencia(db: sqlite3.Connection, entry_id: str) -> dict:
    """Para una HIPÓTESIS, devuelve entries que la apoyan y contradicen.
    Devuelve {supports: [...], contradicts: [...]}."""
    supports = []
    contradicts = []
    edges = get_edges(db, entry_id)
    for edge in edges:
        other_id = edge["target"] if edge["source"] == entry_id else edge["source"]
        other = get_entry(db, other_id)
        if not other:
            continue
        if edge["edge_type"] == "SUPPORTS":
            supports.append(other)
        elif edge["edge_type"] == "CONTRADICTS":
            contradicts.append(other)
    return {"supports": supports, "contradicts": contradicts}


def versiones(db: sqlite3.Connection, entry_id: str) -> list[dict]:
    """Devuelve la cadena de versiones de una entry (via edges SUPERSEDES).
    Convención: source SUPERSEDES target (source es la más nueva).
    Más vieja primero."""
    entry = get_entry(db, entry_id)
    if not entry:
        return []
    chain = [entry]
    visited = {entry_id}
    current = entry_id

    # Buscar hacia atrás (versiones más viejas): current supersedes X → X es vieja
    while True:
        row = db.execute(
            "SELECT target FROM edges WHERE source = ? AND edge_type = 'SUPERSEDES'",
            (current,),
        ).fetchone()
        if not row or row[0] in visited:
            break
        current = row[0]
        visited.add(current)
        entry = get_entry(db, current)
        if entry:
            chain.insert(0, entry)

    # Buscar hacia adelante (versiones más nuevas): X supersedes current → X es nueva
    current = entry_id
    while True:
        row = db.execute(
            "SELECT source FROM edges WHERE target = ? AND edge_type = 'SUPERSEDES'",
            (current,),
        ).fetchone()
        if not row or row[0] in visited:
            break
        current = row[0]
        visited.add(current)
        entry = get_entry(db, current)
        if entry:
            chain.append(entry)

    return chain


def get_entries_cross_session(
    db: sqlite3.Connection,
    tipo: str | None = None,
    estado: str | None = None,
) -> list[dict]:
    """Lista entradas de TODAS las sesiones del proyecto."""
    return get_entries(db, tipo=tipo, estado=estado)


# --- Helpers ---


def _floats_to_blob(floats: list[float]) -> bytes:
    """Convierte lista de floats a BLOB para sqlite-vec."""
    return struct.pack(f"{len(floats)}f", *floats)


def _blob_to_floats(blob: bytes) -> list[float]:
    """Convierte BLOB a lista de floats."""
    n = len(blob) // 4
    return list(struct.unpack(f"{n}f", blob))
