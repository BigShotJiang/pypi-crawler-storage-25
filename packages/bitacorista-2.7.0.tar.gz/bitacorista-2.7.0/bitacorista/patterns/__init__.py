"""Pattern packs for bitacorista domain-specific detection."""

from importlib import import_module

# Registry of available packs
AVAILABLE_PACKS = {
    "dev": "bitacorista.patterns.dev",
}


def get_pack(name: str) -> dict[str, list[str]]:
    """Load a pattern pack by name. Returns dict of {tipo: [patterns]}."""
    if name not in AVAILABLE_PACKS:
        raise ValueError(
            f"Pack '{name}' not found. Available: {', '.join(AVAILABLE_PACKS)}"
        )
    module = import_module(AVAILABLE_PACKS[name])
    return module.PATTERNS


def list_packs() -> list[str]:
    """List available pattern pack names."""
    return list(AVAILABLE_PACKS.keys())
