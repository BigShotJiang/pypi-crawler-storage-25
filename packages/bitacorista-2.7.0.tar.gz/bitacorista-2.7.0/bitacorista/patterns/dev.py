"""
Pattern pack: dev (software development)

Extra regex patterns for programming conversations.
Extends core types — does not create new ones.
"""

PATTERNS: dict[str, list[str]] = {
    "DECISIÓN": [
        # Español
        r"(?i)(commiteamos|commitea)",
        r"(?i)(pusheamos|pushea)",
        r"(?i)(mergeamos|mergea)",
        r"(?i)(deployamos|deploye[aá])",
        r"(?i)(refactorizamos|refactoriz[aá])",
        r"(?i)(implementamos\s+eso)",
        r"(?i)(arrancamos\s+con)",
        # English
        r"(?i)(ship\s+it)",
        r"(?i)(let'?s?\s+(deploy|merge|refactor|implement))",
        r"(?i)(merge\s+(it|this|the\s+PR))",
        r"(?i)(commit\s+this)",
        r"(?i)(push\s+to\s+(master|main|prod))",
    ],
    "DESCARTE": [
        # Español
        r"(?i)(ese\s+approach\s+no\s+escala)",
        r"(?i)(eso\s+rompe)",
        r"(?i)(revert[ií]\s+eso)",
        r"(?i)(rollback)",
        # English
        r"(?i)(that\s+approach\s+doesn'?t\s+scale)",
        r"(?i)(revert\s+(that|this|it))",
        r"(?i)(that\s+breaks)",
        r"(?i)(won'?t\s+work\s+in\s+prod)",
    ],
    "ENTREGABLE": [
        # Español
        r"(?i)(los\s+tests?\s+pasan)",
        r"(?i)(pusheado|mergeado|commiteado|deployado)",
        r"(?i)(release\s+publicad[oa])",
        r"(?i)(PR\s+cread[oa])",
        # English
        r"(?i)(tests?\s+(are\s+)?passing)",
        r"(?i)((pushed|merged|deployed|released|committed)(\s+to)?)",
        r"(?i)(PR\s+created)",
        r"(?i)(build\s+(is\s+)?passing)",
    ],
    "DESCUBRIMIENTO": [
        # Español
        r"(?i)(hay\s+un\s+bug)",
        r"(?i)(encontr[eé]\s+un\s+error)",
        r"(?i)(eso\s+est[aá]\s+roto)",
        r"(?i)(falta\s+un\s+test)",
        r"(?i)(los\s+tests?\s+fallan)",
        # English
        r"(?i)(there'?s?\s+a\s+bug)",
        r"(?i)(found\s+(an?\s+)?error)",
        r"(?i)(that'?s?\s+broken)",
        r"(?i)(missing\s+test)",
        r"(?i)(test(s)?\s+(is|are)\s+failing)",
    ],
    "CORRECCIÓN": [
        # Español
        r"(?i)(arregl[eé]\s+eso)",
        r"(?i)(fixe[eé])",
        r"(?i)(correg[ií]\s+el\s+bug)",
        r"(?i)(parche[eé])",
        # English
        r"(?i)(fixed\s+(it|that|the\s+bug))",
        r"(?i)(patched)",
        r"(?i)(hotfix(ed)?)",
        r"(?i)(bug\s+fixed)",
    ],
    "PREGUNTA": [
        # Español — dev-specific
        r"(?i)(c[oó]mo\s+se\s+usa\s+)",
        r"(?i)(qu[eé]\s+hace\s+(esta|esa)\s+(funci[oó]n|clase|m[eé]todo))",
        r"(?i)(d[oó]nde\s+est[aá]\s+(el|la|ese|esa))",
        r"(?i)(por\s+qu[eé]\s+falla)",
        r"(?i)(qu[eé]\s+error\s+(es|da|tira))",
        # English — dev-specific
        r"(?i)(how\s+do\s+I\s+use\s+)",
        r"(?i)(what\s+does\s+this\s+(function|class|method)\s+do)",
        r"(?i)(where\s+is\s+(the|this))",
        r"(?i)(why\s+is\s+it\s+failing)",
        r"(?i)(what\s+error\s+is\s+(this|that))",
    ],
}
