"""
Downloads the ONNX model for bitacorista embeddings.
Model: paraphrase-multilingual-MiniLM-L12-v2 (~470MB)
"""

import sys
import os
import urllib.request
import json
from pathlib import Path

if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]

MODEL_DIR = Path(os.environ.get("BITACORISTA_MODEL_DIR", "")) if os.environ.get("BITACORISTA_MODEL_DIR") else Path(__file__).parent / "model"
REPO = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
BASE_URL = f"https://huggingface.co/{REPO}/resolve/main/onnx"

FILES = {
    "model.onnx": f"{BASE_URL}/model.onnx",
    "tokenizer.json": f"https://huggingface.co/{REPO}/resolve/main/tokenizer.json",
    "config.json": f"https://huggingface.co/{REPO}/resolve/main/config.json",
    "special_tokens_map.json": f"https://huggingface.co/{REPO}/resolve/main/special_tokens_map.json",
    "tokenizer_config.json": f"https://huggingface.co/{REPO}/resolve/main/tokenizer_config.json",
}


def download_file(url: str, dest: Path) -> None:
    """Downloads a file with progress indicator."""
    print(f"  Downloading {dest.name}...", end=" ", flush=True)

    def progress(block_num: int, block_size: int, total_size: int) -> None:
        if total_size > 0:
            pct = min(100, block_num * block_size * 100 // total_size)
            print(f"\r  Downloading {dest.name}... {pct}%", end="", flush=True)

    urllib.request.urlretrieve(url, str(dest), reporthook=progress)
    size_mb = dest.stat().st_size / (1024 * 1024)
    print(f"\r  {dest.name} — {size_mb:.1f} MB")


def main() -> None:
    auto_yes = "--yes" in sys.argv or "-y" in sys.argv

    print(f"Bitacorista — Model downloader")
    print(f"Model: {REPO}")
    print(f"Destination: {MODEL_DIR}")
    print()

    MODEL_DIR.mkdir(parents=True, exist_ok=True)

    # Check if already downloaded
    model_path = MODEL_DIR / "model.onnx"
    if model_path.exists():
        size_mb = model_path.stat().st_size / (1024 * 1024)
        print(f"Model already exists ({size_mb:.0f} MB).")
        if auto_yes:
            print("Skipped (already cached).")
            return
        resp = input("Re-download? [y/N] ").strip().lower()
        if resp != "y":
            print("Skipped.")
            return

    for filename, url in FILES.items():
        dest = MODEL_DIR / filename
        download_file(url, dest)

    # Verify
    print()
    if model_path.exists() and (MODEL_DIR / "tokenizer.json").exists():
        print("Done. Model ready.")
    else:
        print("ERROR: Some files are missing. Check your internet connection.")
        sys.exit(1)


if __name__ == "__main__":
    main()
