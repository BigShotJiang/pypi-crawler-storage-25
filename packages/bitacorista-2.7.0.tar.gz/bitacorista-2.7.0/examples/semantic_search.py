"""
Example: Semantic search over stored entries.

Requires the ONNX model. Download it first:
    python -m bitacorista.download_model --yes

Run:
    python examples/semantic_search.py
"""

from bitacorista import Session

DB_PATH = "search-demo.db"


def main():
    with Session(DB_PATH) as s:
        # Build up some context
        messages = [
            "We decided to use Vue.js for the frontend framework.",
            "SQLite is our database — it's part of Python's stdlib.",
            "Discarded React because of unnecessary complexity.",
            "The deploy will be on a VPS with nginx reverse proxy.",
            "Discovered that the API has rate limiting at 100 req/s.",
            "Create a Dockerfile for the production build.",
        ]

        print("Processing messages...")
        for msg in messages:
            entries = s.process(msg)
            for e in entries:
                print(f"  [{e['tipo']}] {e['resumen']}")

        # Now search semantically
        print("\n=== Search: 'what framework are we using?' ===")
        results = s.search("what framework are we using?", k=3)
        if results:
            for entry_id, distance in results:
                print(f"  {entry_id} (similarity: {1 - distance:.2f})")
        else:
            print("  (no results — ONNX model not installed)")

        print("\n=== Search: 'deployment infrastructure' ===")
        results = s.search("deployment infrastructure", k=3)
        if results:
            for entry_id, distance in results:
                print(f"  {entry_id} (similarity: {1 - distance:.2f})")
        else:
            print("  (no results — ONNX model not installed)")

    # Cleanup
    import os
    for ext in ["", "-wal", "-shm"]:
        try:
            os.unlink(DB_PATH + ext)
        except OSError:
            pass


if __name__ == "__main__":
    main()
