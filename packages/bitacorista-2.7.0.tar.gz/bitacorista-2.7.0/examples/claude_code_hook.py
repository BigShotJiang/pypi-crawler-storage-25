#!/usr/bin/env python3
"""
Claude Code hook for bitacorista — automatic exchange capture.

Receives JSON on stdin from Claude Code's Stop hook event.
Extracts the user message from the transcript and the assistant
message from the hook input, then passes both to bitacorista.

Setup:
  1. Copy this file to .claude/hooks/bitacorista_hook.py
  2. Add to .claude/settings.json:

  {
    "hooks": {
      "SessionStart": [
        {
          "hooks": [
            {
              "type": "command",
              "command": "python .claude/hooks/bitacorista_startup.py",
              "timeout": 10
            }
          ]
        }
      ],
      "Stop": [
        {
          "hooks": [
            {
              "type": "command",
              "command": "python .claude/hooks/bitacorista_hook.py",
              "timeout": 10
            }
          ]
        }
      ]
    }
  }

  3. Copy bitacorista_startup.py to .claude/hooks/ (for session start alerts).
  4. Run `bitacorista init` to create the session DB.
  5. Restart Claude Code. Hooks activate on the next session.
"""
import json
import sys
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent.parent / "sesion.db"


def get_last_user_msg(transcript_path: str) -> str | None:
    """Extract the last real user text from the Claude Code transcript.

    The transcript is JSONL where each line has a 'type' field.
    User messages have type="user" and message.content that can be:
    - A plain string (simple text input)
    - A list of objects with type="text", "tool_result", etc.
    """
    try:
        with open(transcript_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        for line in reversed(lines):
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            if entry.get("type") != "user":
                continue

            msg = entry.get("message", {})
            content = msg.get("content", [])

            # Content can be a plain string (simple user message)
            if isinstance(content, str):
                t = content.strip()
                if t and not t.startswith("<system-reminder>"):
                    return t
                continue

            if not isinstance(content, list):
                continue

            # Extract only text items (skip tool_result, tool_use, etc.)
            texts = []
            for item in content:
                if not isinstance(item, dict):
                    continue
                if item.get("type") == "text":
                    t = item.get("text", "").strip()
                    if t.startswith("<system-reminder>"):
                        continue
                    if t.startswith("Base directory for this skill:"):
                        continue
                    if t.startswith("# ") and len(t) > 500:
                        continue
                    if t:
                        texts.append(t)

            if texts:
                return "\n".join(texts)

    except Exception:
        pass
    return None


def main():
    raw = sys.stdin.read()
    if not raw.strip():
        return

    hook_input = json.loads(raw)

    # Assistant message comes directly in the hook input
    assistant_msg = hook_input.get("last_assistant_message")

    # User message: parse from transcript
    transcript_path = hook_input.get("transcript_path")
    user_msg = get_last_user_msg(transcript_path) if transcript_path else None

    if not user_msg and not assistant_msg:
        return

    # Truncate long messages (regex only needs the first lines)
    max_len = 2000
    if user_msg and len(user_msg) > max_len:
        user_msg = user_msg[:max_len]
    if assistant_msg and len(assistant_msg) > max_len:
        assistant_msg = assistant_msg[:max_len]

    try:
        from bitacorista import Session

        with Session(str(DB_PATH)) as s:
            entries = s.process(user_msg or "", assistant_msg)
            if entries:
                for e in entries:
                    print(f"  bitacorista: [{e['tipo']}] {e['resumen']}")
    except Exception as e:
        print(f"bitacorista hook error: {e}", file=sys.stderr)


if __name__ == "__main__":
    main()
