"""
Bitacorista quickstart — 10-line working example.

Run:
    pip install bitacorista
    python examples/quickstart.py
"""

from bitacorista import Session

with Session("demo.db") as s:
    # Process conversation messages — events are detected automatically
    s.process("We decided to use SQLite for the database.")
    s.process("Scrap that MongoDB idea, too complex for our scale.")
    s.process("Confirmed: REST API, not GraphQL.")
    s.process("Create the config file with environment variables.")
    s.process("Turns out the API has a 100 req/s rate limit.")

    # See what was captured
    print("=== Entries ===")
    for e in s.entries():
        print(f"  [{e['tipo']:>15}] {e['estado']:<10} {e['resumen']}")

    # Filter by type
    print("\n=== Decisions only ===")
    for e in s.entries(tipo="DECISIÓN"):
        print(f"  {e['resumen']}")

    # Full summary
    print("\n=== Summary ===")
    print(s.summary())

# Cleanup demo file
import os
for ext in ["", "-wal", "-shm"]:
    try:
        os.unlink("demo.db" + ext)
    except OSError:
        pass
