"""Adversarial tests for bitacorista regex detection.

These tests document where the current regex succeeds and fails.
Tests marked with `# KNOWN_ISSUE` are cases where the regex produces
incorrect results — they assert CURRENT behavior, not IDEAL behavior.

Run with: pytest tests/test_adversarial.py -v
"""

import pytest
from bitacorista import engine


def types_detected(text: str, modo: str = "sesion") -> set[str]:
    """Helper: returns set of event types detected in text."""
    return {e["tipo"] for e in engine.detect_events(text, modo)}


# ============================================================
# 1. NEGACIÓN — regex matchea pero el contexto niega
# ============================================================


class TestNegation:
    def test_no_descartamos_es(self):
        """'No descartamos React' — negation check filters this."""
        result = types_detected("No descartamos React, lo dejamos por ahora")
        assert "DESCARTE" not in result

    def test_no_decidimos_es(self):
        """'No decidimos nada todavía' — negation check filters this."""
        result = types_detected("No decidimos nada todavía")
        assert "DECISIÓN" not in result

    def test_nunca_elegimos_es(self):
        """'Nunca elegimos esa opción' — negation check filters this."""
        result = types_detected("Nunca elegimos esa opción")
        assert "DECISIÓN" not in result

    def test_didnt_decide_en(self):
        """'We didn't decide anything' — negation check filters this."""
        result = types_detected("We didn't decide anything yet")
        assert "DECISIÓN" not in result

    def test_not_going_with_en(self):
        """'We're not going with that' — DESCARTE pattern includes negation."""
        result = types_detected("We're not going with that approach")
        assert "DESCARTE" in result  # Pattern has builtin negation, not filtered

    def test_negation_with_separator_es(self):
        """'Dijo que no, decidimos usar Vue' — 'no' separated by comma, decision is real."""
        result = types_detected("Dijo que no, decidimos usar Vue")
        assert "DECISIÓN" in result  # Comma breaks negation link

    def test_double_negation_colloquial_es(self):
        """'No no, dale, vamos con React' — colloquial double-no = affirmation."""
        result = types_detected("No no, dale, vamos con React")
        assert "DECISIÓN" in result  # Comma breaks negation link

    def test_negation_pero_separator_es(self):
        """'No queríamos pero decidimos ir con Vue' — 'pero' breaks negation."""
        result = types_detected("No queríamos pero decidimos ir con Vue")
        assert "DECISIÓN" in result

    def test_not_going_with_after_previous_no(self):
        """'I said no. We're not going with that' — previous 'no' shouldn't kill DESCARTE."""
        result = types_detected("I said no. We're not going with that approach")
        assert "DESCARTE" in result  # Pattern has builtin negation


# ============================================================
# 2. CONDICIONAL / INCERTIDUMBRE — trigger sin firmeza
# ============================================================


class TestConditional:
    def test_podriamos_decidir_es(self):
        """'Podríamos decidir usar Vue' — should detect but NOT be FIRME."""
        result = types_detected("Podríamos decidir usar Vue, no sé")
        # Regex detects "decidir", classify_estado should NOT mark FIRME
        if "DECISIÓN" in result:
            estado = engine.classify_estado(
                "Podríamos decidir usar Vue, no sé", "DECISIÓN"
            )
            assert estado == "INFERIDO", f"Expected INFERIDO, got {estado}"

    def test_maybe_go_with_en(self):
        """'Maybe we should go with React' — should detect but NOT be FIRME."""
        result = types_detected("Maybe we should go with React")
        # "go with" is a trigger for DECISIÓN
        if "DECISIÓN" in result:
            estado = engine.classify_estado(
                "Maybe we should go with React", "DECISIÓN"
            )
            assert estado == "INFERIDO", f"Expected INFERIDO, got {estado}"

    def test_si_decidimos_es(self):
        """'Si decidimos usar SQLite, habría que...' — conditional.
        Known limitation: regex can't distinguish conditional from actual decision.
        classify_estado treats 'decidimos' as FIRME signal."""
        result = types_detected("Si decidimos usar SQLite, habría que migrar")
        if "DECISIÓN" in result:
            estado = engine.classify_estado(
                "Si decidimos usar SQLite, habría que migrar", "DECISIÓN"
            )
            if estado == "FIRME":
                pytest.xfail("Known limitation: 'Si decidimos...' treated as FIRME")


# ============================================================
# 3. REFERENCIA A PASADO — válido, debería detectar
# ============================================================


class TestPastReference:
    def test_ayer_decidimos_es(self):
        """'Ayer decidimos usar Python' — valid, should detect."""
        result = types_detected("Ayer decidimos usar Python para el backend")
        assert "DECISIÓN" in result

    def test_anterior_descartamos_es(self):
        """'En la reunión anterior descartamos MongoDB' — valid."""
        result = types_detected("En la reunión anterior descartamos MongoDB")
        assert "DESCARTE" in result

    def test_third_person_decided_en(self):
        """'He said they decided to use Java' — third person."""
        result = types_detected("He said they decided to use Java")
        # "decided" doesn't match "we decided" or "I decided" patterns
        # Third person is not in the pattern list
        if "DECISIÓN" not in result:
            pass  # Expected: third person not detected (by design)


# ============================================================
# 4. MEZCLA ES/EN — alternancia de idiomas
# ============================================================


class TestMixedLanguage:
    def test_decidimos_go_with(self):
        """'Decidimos go with Vue' — Spanish trigger, English continuation."""
        result = types_detected("Decidimos go with Vue para el frontend")
        assert "DECISIÓN" in result  # "decidimos" matches

    def test_lets_descartemos(self):
        """'Let's descartemos eso' — English frame, Spanish verb."""
        result = types_detected("Let's descartemos eso")
        assert "DESCARTE" in result  # "descartemos" matches


# ============================================================
# 5. FALSOS POSITIVOS — trigger en contexto no-evento
# ============================================================


class TestFalsePositives:
    def test_filename_decision(self):
        """'decision.txt' — filename, not an event."""
        # "decision" doesn't match any pattern (patterns need "decidimos", "we decided", etc.)
        result = types_detected("El archivo se llama decision.txt")
        assert "DECISIÓN" not in result

    def test_quoted_descartamos(self):
        """'Buscá en Google descartamos' — non-event context filter."""
        result = types_detected("Buscá en Google 'descartamos'")
        assert "DESCARTE" not in result

    def test_function_name_encontre(self):
        """'encontré_algo()' — non-event context filter (code identifier)."""
        result = types_detected("La función se llama encontré_algo()")
        assert "DESCUBRIMIENTO" not in result

    def test_confirmado_in_output(self):
        """'confirmado: True' — non-event context filter (code output)."""
        result = types_detected("El campo dice confirmado: True")
        assert "DECISIÓN" not in result

    def test_confirmado_real(self):
        """'confirmado: vamos con Vue' — real confirmation, not code."""
        result = types_detected("confirmado: vamos con Vue para el frontend")
        assert "DECISIÓN" in result

    def test_parenthesis_in_prose(self):
        """'(decidimos ir con Vue)' — parenthesis in prose, should detect."""
        result = types_detected("Como dijimos (decidimos ir con Vue), hay que migrar")
        assert "DECISIÓN" in result  # Parenthesis no longer filters

    def test_contraction_apostrophe_en(self):
        """'I don't think we've decided yet' — apostrophe is not a quote."""
        result = types_detected("I don't think we've decided yet")
        # "decided" doesn't match patterns ("we decided" does, but "we've decided" does)
        # The apostrophe in "don't" should not trigger false quote detection
        # "don't" has negation but "we've decided" is a separate clause
        # This is a complex case — just verify no crash and reasonable behavior
        assert True  # Documenting: complex case, no crash


# ============================================================
# 6. REFORMULACIONES — formas no cubiertas
# ============================================================


class TestReformulations:
    def test_queda_asi_es(self):
        """'Eso queda así' — implicit decision. Not covered by regex."""
        result = types_detected("Eso queda así, no lo toquemos más")
        # No pattern for "queda así"
        assert "DECISIÓN" not in result  # Expected: not detected (no pattern)

    def test_cerramos_tema_es(self):
        """'Listo, cerramos ese tema' — implicit decision or topic change."""
        result = types_detected("Listo, cerramos ese tema")
        # No pattern for "cerramos" as decision
        # Could argue it's CAMBIO-DE-TEMA but no pattern matches
        assert len(result) == 0  # Expected: nothing detected

    def test_ya_fue_es(self):
        """'Ya fue, no va más' — colloquial discard."""
        result = types_detected("Ya fue, no va más esa idea")
        # "no va" could match "eso no va" pattern? Let's see
        if "DESCARTE" in result:
            pass  # Good — pattern "eso no va" might catch "no va más"
        # If not detected, it's a gap
        if "DESCARTE" not in result:
            pass  # Expected gap: colloquial not covered

    def test_dale_adelante_es(self):
        """'Dale para adelante' — should detect as DECISIÓN."""
        result = types_detected("Dale para adelante con eso")
        assert "DECISIÓN" in result  # Pattern exists: "dale con|para adelante"
