"""Tests for embedding-dependent features. Skipped if model not available."""

import pytest
from bitacorista import db as store
from bitacorista import engine

# Mark entire module as requiring embeddings
pytestmark = [
    pytest.mark.embeddings,
    pytest.mark.skipif(not engine._load_model(), reason="ONNX model not available"),
]


def test_embed_returns_384_floats():
    emb = engine.embed("Decidimos usar SQLite")
    assert emb is not None
    assert len(emb) == 384
    assert all(isinstance(x, float) for x in emb)


def test_embed_is_normalized():
    emb = engine.embed("Test de normalización")
    norm = sum(x * x for x in emb) ** 0.5
    assert abs(norm - 1.0) < 0.01


def test_similar_texts_high_cosine():
    e1 = engine.embed("Decidimos usar SQLite como base de datos")
    e2 = engine.embed("Elegimos SQLite para almacenar datos")
    sim = sum(a * b for a, b in zip(e1, e2))
    assert sim > 0.7


def test_different_texts_low_cosine():
    e1 = engine.embed("Decidimos usar SQLite como base de datos")
    e2 = engine.embed("El clima en Buenos Aires está soleado hoy")
    sim = sum(a * b for a, b in zip(e1, e2))
    assert sim < 0.5


def test_spanish_embeddings():
    e1 = engine.embed("Descartamos React por complejidad innecesaria")
    e2 = engine.embed("React fue descartado porque era demasiado complejo")
    sim = sum(a * b for a, b in zip(e1, e2))
    assert sim > 0.6


def test_buscar_similares(db):
    conn, _ = db
    emb1 = engine.embed("Usar Vue como framework frontend")
    emb2 = engine.embed("SQLite es nuestra base de datos")
    emb3 = engine.embed("El deploy será en un VPS")
    store.add_entry(conn, tipo="DECISIÓN", resumen="Vue frontend", embedding=emb1, embedding_model="test")
    store.add_entry(conn, tipo="DECISIÓN", resumen="SQLite DB", embedding=emb2, embedding_model="test")
    store.add_entry(conn, tipo="DECISIÓN", resumen="Deploy VPS", embedding=emb3, embedding_model="test")
    q = engine.embed("qué framework usamos")
    results = store.buscar_similares(conn, q, k=3)
    if results:
        assert results[0][0] == "E001"


def test_detect_duplicate(db):
    conn, _ = db
    emb = engine.embed("Decidimos usar Vue como framework")
    store.add_entry(conn, tipo="DECISIÓN", resumen="Vue framework", embedding=emb, embedding_model="test")
    emb2 = engine.embed("Vue es el framework elegido")
    dup = store.detect_duplicate(conn, emb2, umbral=0.5)
    if dup:
        assert dup["id"] == "E001"


def test_blast_radius(db):
    conn, _ = db
    emb = engine.embed("test blast radius")
    store.add_entry(conn, tipo="DECISIÓN", resumen="test", embedding=emb, embedding_model="test")
    br = store.blast_radius(conn, emb)
    assert "entry_points" in br
    assert "affected" in br
    assert isinstance(br["total"], int)


def test_explorar_latentes(db):
    conn, _ = db
    emb1 = engine.embed("SQLite es la base de datos del proyecto")
    emb2 = engine.embed("Usamos SQLite porque es parte de la stdlib de Python")
    emb3 = engine.embed("El clima en Córdoba es templado")
    store.add_entry(conn, tipo="DECISIÓN", resumen="SQLite DB", embedding=emb1, embedding_model="test")
    store.add_entry(conn, tipo="DESCUBRIMIENTO", resumen="SQLite stdlib", embedding=emb2, embedding_model="test")
    store.add_entry(conn, tipo="IDEA", resumen="Clima Córdoba", embedding=emb3, embedding_model="test")
    latentes = engine.explorar_latentes(conn, umbral=0.5)
    if latentes:
        pairs = [(l["a"], l["b"]) for l in latentes]
        assert ("E001", "E002") in pairs or ("E002", "E001") in pairs


def test_process_exchange_end_to_end(db):
    conn, _ = db
    entries = engine.process_exchange(
        conn,
        "Confirmado: vamos con Vue para el frontend. Descartamos React por complejidad.",
        exchange_n=1,
    )
    assert len(entries) >= 2
    for e in entries:
        full = store.get_entry(conn, e["id"])
        assert full["embedding"] is not None
        assert full["embedding_model"] is not None
