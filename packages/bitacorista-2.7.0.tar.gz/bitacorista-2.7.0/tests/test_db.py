"""Tests for bitacorista.db — data layer."""

import pytest
from bitacorista import db as store


# --- Schema ---


def test_init_db_creates_tables(db):
    conn, _ = db
    tables = [r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    ).fetchall()]
    assert "entries" in tables
    assert "edges" in tables
    assert "exchanges" in tables
    assert "session_meta" in tables


# --- IDs ---


def test_next_id_increments(db):
    conn, _ = db
    assert store.next_id(conn) == "E001"
    assert store.next_id(conn) == "E002"
    assert store.next_id(conn) == "E003"


# --- Entries ---


def test_add_entry_and_get_entry(db):
    conn, _ = db
    eid = store.add_entry(conn, tipo="DECISIÓN", resumen="Usar SQLite", contexto="Por rendimiento")
    assert eid == "E001"
    entry = store.get_entry(conn, eid)
    assert entry["tipo"] == "DECISIÓN"
    assert entry["resumen"] == "Usar SQLite"
    assert entry["contexto"] == "Por rendimiento"
    assert entry["estado"] == "INFERIDO"


def test_add_entry_explicit_estado(db):
    conn, _ = db
    eid = store.add_entry(conn, tipo="DESCARTE", resumen="React descartado", estado="DESCARTADO")
    assert store.get_entry(conn, eid)["estado"] == "DESCARTADO"


def test_add_entry_rejects_invalid_tipo(db):
    conn, _ = db
    with pytest.raises(Exception):
        store.add_entry(conn, tipo="INVALIDO", resumen="test")


def test_add_entry_rejects_invalid_estado(db):
    conn, _ = db
    with pytest.raises(Exception):
        store.add_entry(conn, tipo="DECISIÓN", resumen="test", estado="MALO")


def test_get_entries_filters_by_tipo(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="D1")
    store.add_entry(conn, tipo="DESCARTE", resumen="X1", estado="DESCARTADO")
    store.add_entry(conn, tipo="DECISIÓN", resumen="D2")
    results = store.get_entries(conn, tipo="DECISIÓN")
    assert len(results) == 2
    assert all(r["tipo"] == "DECISIÓN" for r in results)


def test_get_entries_filters_by_estado(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="D1", estado="FIRME")
    store.add_entry(conn, tipo="DECISIÓN", resumen="D2", estado="INFERIDO")
    store.add_entry(conn, tipo="DECISIÓN", resumen="D3", estado="FIRME")
    assert len(store.get_entries(conn, estado="FIRME")) == 2


def test_update_estado(db):
    conn, _ = db
    eid = store.add_entry(conn, tipo="DECISIÓN", resumen="Test", estado="INFERIDO")
    store.update_estado(conn, eid, "FIRME")
    assert store.get_entry(conn, eid)["estado"] == "FIRME"


def test_get_entry_nonexistent_returns_none(db):
    conn, _ = db
    assert store.get_entry(conn, "E999") is None


def test_add_entry_rollback_on_invalid_preserves_next_id(db):
    conn, _ = db
    n_before = int(store.get_meta(conn, "next_id"))
    with pytest.raises(Exception):
        store.add_entry(conn, tipo="INVALIDO", resumen="Test")
    n_after = int(store.get_meta(conn, "next_id"))
    assert n_after == n_before


# --- Edges ---


def test_add_edge_and_get_edges(db):
    conn, _ = db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="A")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="B")
    store.add_edge(conn, e1, e2, "EXTRACTED", 1.0)
    edges = store.get_edges(conn, e1)
    assert len(edges) == 1
    assert edges[0]["source"] == e1
    assert edges[0]["target"] == e2


def test_add_edge_duplicate_is_ignored(db):
    conn, _ = db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="A")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="B")
    store.add_edge(conn, e1, e2, "EXTRACTED")
    store.add_edge(conn, e1, e2, "EXTRACTED")
    assert len(store.get_edges(conn)) == 1


def test_cascade_delete_removes_edges(db):
    conn, _ = db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="A")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="B")
    store.add_edge(conn, e1, e2, "EXTRACTED")
    conn.execute("DELETE FROM entries WHERE id = ?", (e1,))
    assert len(store.get_edges(conn)) == 0


# --- Exchanges ---


def test_add_exchange_and_get_exchanges(db):
    conn, _ = db
    store.add_exchange(conn, 1, "Hola", "Qué tal")
    store.add_exchange(conn, 2, "Siguiente", "Ok")
    exs = store.get_exchanges(conn)
    assert len(exs) == 2
    assert exs[0]["user_msg"] == "Hola"
    assert exs[1]["n"] == 2


def test_count_exchanges(db):
    conn, _ = db
    assert store.count_exchanges(conn) == 0
    store.add_exchange(conn, 1, "Hola")
    store.add_exchange(conn, 2, "Chau")
    assert store.count_exchanges(conn) == 2


# --- Meta ---


def test_set_meta_and_get_meta(db):
    conn, _ = db
    store.set_meta(conn, "test_key", "test_value")
    assert store.get_meta(conn, "test_key") == "test_value"
    assert store.get_meta(conn, "nonexistent") is None


# --- Graph ---


def test_bfs_traversal(db):
    conn, _ = db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="A")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="B")
    e3 = store.add_entry(conn, tipo="DECISIÓN", resumen="C")
    store.add_edge(conn, e1, e2, "EXTRACTED")
    store.add_edge(conn, e2, e3, "EXTRACTED")
    result = store.bfs(conn, e1, max_depth=3)
    depths = {r[0]: r[1] for r in result}
    assert depths[e2] == 1
    assert depths[e3] == 2


# --- Helpers ---


def test_floats_blob_roundtrip():
    original = [0.1, 0.2, 0.3, -0.5, 1.0]
    blob = store._floats_to_blob(original)
    recovered = store._blob_to_floats(blob)
    for a, b in zip(original, recovered):
        assert abs(a - b) < 1e-6


# --- Resumen ---


def test_get_resumen_format(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Usar Vue", estado="FIRME")
    store.add_entry(conn, tipo="DESCARTE", resumen="React descartado", estado="DESCARTADO")
    store.add_entry(conn, tipo="DESCUBRIMIENTO", resumen="Algo inferido", estado="INFERIDO")
    resumen = store.get_resumen(conn)
    assert "DECISIONES FIRMES:" in resumen
    assert "Usar Vue" in resumen
    assert "NO PROPONER" in resumen
    assert "3 entradas" in resumen


def test_get_resumen_format_json(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Usar Vue", estado="FIRME")
    store.add_entry(conn, tipo="DESCARTE", resumen="React descartado", estado="DESCARTADO")
    result = store.get_resumen(conn, fmt="json")
    assert isinstance(result, dict)
    assert "entries" in result
    assert "contradicts" in result
    assert "total_entries" in result
    assert "total_exchanges" in result
    assert result["total_entries"] == 2
    assert result["mode"] == "classic"
    ids = [e["id"] for e in result["entries"]]
    assert len(ids) == 2


def test_get_resumen_max_entries(db):
    conn, _ = db
    for i in range(10):
        store.add_entry(conn, tipo="DECISIÓN", resumen=f"Decision {i}", estado="FIRME")
    result = store.get_resumen(conn, fmt="json", max_entries=3)
    assert len(result["entries"]) == 3
    assert result["total_entries"] == 10


def test_get_resumen_filters_superseded(db):
    conn, _ = db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="Usar MongoDB", estado="FIRME")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="Usar SQLite en vez de MongoDB", estado="FIRME")
    store.add_edge(conn, e2, e1, edge_type="SUPERSEDES")
    result = store.get_resumen(conn, fmt="json")
    ids = [e["id"] for e in result["entries"]]
    assert e2 in ids
    assert e1 not in ids  # superado, no aparece


def test_get_resumen_shows_contradicts(db):
    conn, _ = db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="Usar React", estado="FIRME")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="No usar React", estado="FIRME")
    store.add_edge(conn, e1, e2, edge_type="CONTRADICTS")
    result = store.get_resumen(conn, fmt="json")
    assert len(result["contradicts"]) == 1
    assert result["contradicts"][0]["source"] == e1
    assert result["contradicts"][0]["target"] == e2
    # Text format also shows them
    text = store.get_resumen(conn)
    assert "CONFLICTOS ACTIVOS:" in text


def test_get_resumen_contradicts_excluded_if_superseded(db):
    conn, _ = db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="Usar React", estado="FIRME")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="No usar React", estado="FIRME")
    e3 = store.add_entry(conn, tipo="DECISIÓN", resumen="Usar Vue", estado="FIRME")
    store.add_edge(conn, e1, e2, edge_type="CONTRADICTS")
    store.add_edge(conn, e3, e1, edge_type="SUPERSEDES")  # e1 superado
    result = store.get_resumen(conn, fmt="json")
    # e1 is superseded, so the contradiction is no longer active
    assert len(result["contradicts"]) == 0


def test_get_resumen_fallback_no_embedding(db):
    """Without embedding, falls back to classic mode (last N by estado)."""
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Dec 1", estado="FIRME")
    store.add_entry(conn, tipo="DESCARTE", resumen="Desc 1", estado="DESCARTADO")
    result = store.get_resumen(conn, fmt="json")
    assert result["mode"] == "classic"
    assert len(result["entries"]) == 2


def test_get_resumen_json_empty_db(db):
    """JSON format on empty DB returns valid structure."""
    conn, _ = db
    result = store.get_resumen(conn, fmt="json")
    assert isinstance(result, dict)
    assert result["entries"] == []
    assert result["contradicts"] == []
    assert result["total_entries"] == 0
    assert result["mode"] == "classic"


def test_get_resumen_max_entries_zero(db):
    """max_entries=0 gets clamped to 1, returns the last entry."""
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Dec 1", estado="FIRME")
    store.add_entry(conn, tipo="DECISIÓN", resumen="Dec 2", estado="FIRME")
    result = store.get_resumen(conn, fmt="json", max_entries=0)
    assert len(result["entries"]) == 1
    assert result["entries"][0]["resumen"] == "Dec 2"  # la última, no la primera


def test_get_resumen_text_otros_estado(db):
    """Entries with non-standard estado appear in OTROS section."""
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Algo obsoleto", estado="OBSOLETO")
    store.add_entry(conn, tipo="DECISIÓN", resumen="Firme", estado="FIRME")
    text = store.get_resumen(conn)
    assert "OTROS:" in text
    assert "Algo obsoleto" in text
    assert "DECISIONES FIRMES:" in text


def test_get_resumen_contradicts_shows_resumenes(db):
    """CONTRADICTS in text format shows entry summaries, not just IDs."""
    conn, _ = db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="Usar React", estado="FIRME")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="No usar React", estado="FIRME")
    store.add_edge(conn, e1, e2, edge_type="CONTRADICTS")
    text = store.get_resumen(conn)
    assert "Usar React" in text.split("CONFLICTOS ACTIVOS:")[1]
    assert "No usar React" in text.split("CONFLICTOS ACTIVOS:")[1]


# --- Confidence Decay ---


def test_get_stale_inferidos_none_stale(db):
    """INFERIDO with <5 exchanges after → not stale."""
    conn, _ = db
    store.add_entry(conn, tipo="DESCUBRIMIENTO", resumen="Algo", estado="INFERIDO")
    # Only 3 exchanges after
    for i in range(1, 4):
        store.add_exchange(conn, n=i, user_msg=f"msg {i}", asst_msg="resp")
    stale = store.get_stale_inferidos(conn, threshold=5)
    assert len(stale) == 0


def test_get_stale_inferidos_is_stale(db):
    """INFERIDO with >=5 exchanges after → stale."""
    conn, _ = db
    store.add_entry(conn, tipo="DESCUBRIMIENTO", resumen="Algo viejo", estado="INFERIDO")
    for i in range(1, 7):
        store.add_exchange(conn, n=i, user_msg=f"msg {i}", asst_msg="resp")
    stale = store.get_stale_inferidos(conn, threshold=5)
    assert len(stale) == 1
    assert stale[0]["resumen"] == "Algo viejo"
    assert stale[0]["exchanges_since"] >= 5


def test_get_stale_only_inferido(db):
    """FIRME entries never decay, even with many exchanges after."""
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Firme viejo", estado="FIRME")
    for i in range(1, 10):
        store.add_exchange(conn, n=i, user_msg=f"msg {i}", asst_msg="resp")
    stale = store.get_stale_inferidos(conn)
    assert len(stale) == 0


def test_get_stale_custom_threshold(db):
    """Custom threshold works."""
    conn, _ = db
    store.add_entry(conn, tipo="DESCUBRIMIENTO", resumen="Algo", estado="INFERIDO")
    for i in range(1, 4):
        store.add_exchange(conn, n=i, user_msg=f"msg {i}", asst_msg="resp")
    assert len(store.get_stale_inferidos(conn, threshold=3)) == 1
    assert len(store.get_stale_inferidos(conn, threshold=5)) == 0


def test_get_resumen_excludes_stale(db):
    """Resumen hides stale INFERIDO entries."""
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Firme", estado="FIRME")
    store.add_entry(conn, tipo="DESCUBRIMIENTO", resumen="Viejo inferido", estado="INFERIDO")
    for i in range(1, 7):
        store.add_exchange(conn, n=i, user_msg=f"msg {i}", asst_msg="resp")
    text = store.get_resumen(conn)
    assert "Firme" in text
    assert "Viejo inferido" not in text


def test_get_resumen_json_stale_count(db):
    """JSON output includes stale_count."""
    conn, _ = db
    store.add_entry(conn, tipo="DESCUBRIMIENTO", resumen="Stale 1", estado="INFERIDO")
    store.add_entry(conn, tipo="DESCUBRIMIENTO", resumen="Stale 2", estado="INFERIDO")
    for i in range(1, 7):
        store.add_exchange(conn, n=i, user_msg=f"msg {i}", asst_msg="resp")
    result = store.get_resumen(conn, fmt="json")
    assert result["stale_count"] == 2
    assert len(result["entries"]) == 0  # both stale, none shown


# --- Merge ---


def test_merge_entries_creates_new(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Usar SQLite", estado="FIRME")
    store.add_entry(conn, tipo="DECISIÓN", resumen="SQLite para storage", estado="INFERIDO")
    new_id = store.merge_entries(conn, "E001", "E002", "Usar SQLite como storage")
    new = store.get_entry(conn, new_id)
    assert new is not None
    assert new["resumen"] == "Usar SQLite como storage"


def test_merge_entries_obsoletes_originals(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="A", estado="FIRME")
    store.add_entry(conn, tipo="DECISIÓN", resumen="B", estado="INFERIDO")
    store.merge_entries(conn, "E001", "E002", "AB")
    assert store.get_entry(conn, "E001")["estado"] == "OBSOLETO"
    assert store.get_entry(conn, "E002")["estado"] == "OBSOLETO"


def test_merge_entries_creates_supersedes(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="A", estado="FIRME")
    store.add_entry(conn, tipo="DECISIÓN", resumen="B", estado="INFERIDO")
    new_id = store.merge_entries(conn, "E001", "E002", "AB")
    edges = store.get_edges(conn, new_id)
    supersedes = [e for e in edges if e["edge_type"] == "SUPERSEDES"]
    assert len(supersedes) == 2
    targets = {e["target"] for e in supersedes}
    assert targets == {"E001", "E002"}


def test_merge_entries_copies_edges(db):
    conn, _ = db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="A", estado="FIRME")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="B", estado="INFERIDO")
    e3 = store.add_entry(conn, tipo="DESCUBRIMIENTO", resumen="C", estado="INFERIDO")
    store.add_edge(conn, e1, e3, edge_type="SUPPORTS")
    new_id = store.merge_entries(conn, e1, e2, "AB")
    edges = store.get_edges(conn, new_id)
    supports = [e for e in edges if e["edge_type"] == "SUPPORTS"]
    assert len(supports) == 1
    assert supports[0]["target"] == e3


def test_merge_entries_firme_wins(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="A", estado="INFERIDO")
    store.add_entry(conn, tipo="DECISIÓN", resumen="B", estado="FIRME")
    new_id = store.merge_entries(conn, "E001", "E002", "AB")
    assert store.get_entry(conn, new_id)["estado"] == "FIRME"


def test_merge_entries_inferido_if_no_firme(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="A", estado="INFERIDO")
    store.add_entry(conn, tipo="DECISIÓN", resumen="B", estado="INFERIDO")
    new_id = store.merge_entries(conn, "E001", "E002", "AB")
    assert store.get_entry(conn, new_id)["estado"] == "INFERIDO"


def test_merge_entries_nonexistent_fails(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="A", estado="FIRME")
    with pytest.raises(ValueError, match="no encontrada"):
        store.merge_entries(conn, "E001", "E999", "AB")


def test_merge_entries_self_merge_fails(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="A", estado="FIRME")
    with pytest.raises(ValueError, match="consigo misma"):
        store.merge_entries(conn, "E001", "E001", "AA")


def test_merge_entries_obsoleto_fails(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="A", estado="FIRME")
    store.add_entry(conn, tipo="DECISIÓN", resumen="B", estado="FIRME")
    store.add_entry(conn, tipo="DECISIÓN", resumen="C", estado="FIRME")
    # Merge A+B, making them OBSOLETO
    store.merge_entries(conn, "E001", "E002", "AB")
    # Try to merge OBSOLETO entry
    with pytest.raises(ValueError, match="OBSOLETO"):
        store.merge_entries(conn, "E001", "E003", "AC")


def test_merge_entries_tipo_from_recent(db):
    """Tipo comes from the more recent entry."""
    conn, _ = db
    store.add_entry(conn, tipo="DESCUBRIMIENTO", resumen="Hallazgo", estado="INFERIDO")
    store.add_entry(conn, tipo="DECISIÓN", resumen="Decidido", estado="FIRME")
    new_id = store.merge_entries(conn, "E001", "E002", "Combinada")
    # E002 is more recent, so tipo should be DECISIÓN
    assert store.get_entry(conn, new_id)["tipo"] == "DECISIÓN"


def test_merge_entries_contexto(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="A", estado="FIRME")
    store.add_entry(conn, tipo="DECISIÓN", resumen="B", estado="FIRME")
    new_id = store.merge_entries(conn, "E001", "E002", "AB", contexto="Contexto combinado")
    assert store.get_entry(conn, new_id)["contexto"] == "Contexto combinado"


def test_merge_entries_excluded_from_resumen(db):
    """After merge, originals are filtered by SUPERSEDES in resumen."""
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Vieja A", estado="FIRME")
    store.add_entry(conn, tipo="DECISIÓN", resumen="Vieja B", estado="FIRME")
    store.merge_entries(conn, "E001", "E002", "Nueva combinada")
    text = store.get_resumen(conn)
    assert "Nueva combinada" in text
    assert "Vieja A" not in text
    assert "Vieja B" not in text


# --- Migration ---


def test_migration_adds_pregunta(tmp_path):
    """DB created with old schema gets migrated to support PREGUNTA."""
    path = str(tmp_path / "old.db")
    # Create DB with old schema (without PREGUNTA, without session_id)
    import sqlite3
    db = sqlite3.connect(path, isolation_level=None)
    db.execute("""
        CREATE TABLE entries (
            id TEXT PRIMARY KEY,
            tipo TEXT NOT NULL CHECK(tipo IN (
                'DECISIÓN','DESCUBRIMIENTO','ENTREGABLE','IDEA',
                'CAMBIO-DE-TEMA','CORRECCIÓN','PREMISA','DESCARTE'
            )),
            resumen TEXT NOT NULL,
            contexto TEXT,
            estado TEXT NOT NULL DEFAULT 'INFERIDO' CHECK(estado IN (
                'FIRME','INFERIDO','DESCARTADO','OBSOLETO'
            )),
            conecta_raw TEXT,
            timestamp TEXT NOT NULL,
            embedding BLOB,
            embedding_model TEXT
        )
    """)
    db.execute("""
        CREATE TABLE session_meta (key TEXT PRIMARY KEY, value TEXT)
    """)
    db.execute("""
        CREATE TABLE exchanges (n INTEGER PRIMARY KEY, user_msg TEXT NOT NULL,
        asst_msg TEXT, timestamp TEXT NOT NULL)
    """)
    db.execute("""
        CREATE TABLE edges (source TEXT NOT NULL, target TEXT NOT NULL,
        edge_type TEXT NOT NULL DEFAULT 'EXTRACTED', peso REAL DEFAULT 1.0,
        PRIMARY KEY (source, target, edge_type))
    """)
    # Insert an existing entry and track next_id
    db.execute(
        "INSERT INTO entries (id, tipo, resumen, estado, timestamp) "
        "VALUES ('E001', 'DECISIÓN', 'Old entry', 'FIRME', '2026-01-01')"
    )
    db.execute("INSERT INTO session_meta (key, value) VALUES ('next_id', '2')")
    db.close()

    # Open with bitacorista — should migrate
    conn = store.open_db(path, validate=True)
    # Old entry preserved
    old = store.get_entry(conn, "E001")
    assert old is not None
    assert old["resumen"] == "Old entry"
    # Now PREGUNTA should work
    eid = store.add_entry(conn, tipo="PREGUNTA", resumen="Test question", estado="INFERIDO")
    assert store.get_entry(conn, eid)["tipo"] == "PREGUNTA"
    conn.close()


# --- Tags ---


def test_add_tag(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Test", estado="FIRME")
    store.add_tag(conn, "E001", "sprint-3")
    assert store.get_tags(conn, "E001") == ["sprint-3"]


def test_add_tag_duplicate(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Test", estado="FIRME")
    store.add_tag(conn, "E001", "sprint-3")
    store.add_tag(conn, "E001", "sprint-3")  # no error
    assert store.get_tags(conn, "E001") == ["sprint-3"]


def test_add_multiple_tags(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Test", estado="FIRME")
    store.add_tag(conn, "E001", "sprint-3")
    store.add_tag(conn, "E001", "urgente")
    tags = store.get_tags(conn, "E001")
    assert "sprint-3" in tags
    assert "urgente" in tags


def test_remove_tag(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Test", estado="FIRME")
    store.add_tag(conn, "E001", "sprint-3")
    store.remove_tag(conn, "E001", "sprint-3")
    assert store.get_tags(conn, "E001") == []


def test_get_entries_by_tag(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Tagged", estado="FIRME")
    store.add_entry(conn, tipo="DECISIÓN", resumen="Not tagged", estado="FIRME")
    store.add_tag(conn, "E001", "sprint-3")
    entries = store.get_entries_by_tag(conn, "sprint-3")
    assert len(entries) == 1
    assert entries[0]["resumen"] == "Tagged"


def test_list_tags(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="A", estado="FIRME")
    store.add_entry(conn, tipo="DECISIÓN", resumen="B", estado="FIRME")
    store.add_tag(conn, "E001", "sprint-3")
    store.add_tag(conn, "E002", "sprint-3")
    store.add_tag(conn, "E001", "urgente")
    tags = store.list_tags(conn)
    assert tags[0]["tag"] == "sprint-3"
    assert tags[0]["count"] == 2
    assert tags[1]["tag"] == "urgente"
    assert tags[1]["count"] == 1


def test_tag_nonexistent_entry(db):
    conn, _ = db
    with pytest.raises(ValueError, match="no encontrada"):
        store.add_tag(conn, "E999", "test")


def test_tag_normalizes_to_lowercase(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Test", estado="FIRME")
    store.add_tag(conn, "E001", "Sprint-3")
    assert store.get_tags(conn, "E001") == ["sprint-3"]


def test_tag_empty_rejected(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Test", estado="FIRME")
    with pytest.raises(ValueError, match="vacío"):
        store.add_tag(conn, "E001", "  ")


def test_tag_too_long_rejected(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Test", estado="FIRME")
    with pytest.raises(ValueError, match="largo"):
        store.add_tag(conn, "E001", "a" * 51)


def test_remove_tag_nonexistent_entry(db):
    conn, _ = db
    with pytest.raises(ValueError, match="no encontrada"):
        store.remove_tag(conn, "E999", "test")


# --- Startup Alert ---


def test_startup_alert_empty_db(db):
    conn, _ = db
    assert store.get_startup_alert(conn) is None


def test_startup_alert_with_entries(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Usar Vue", estado="FIRME")
    alert = store.get_startup_alert(conn)
    assert alert is not None
    assert "BITACORISTA" in alert
    assert "Usar Vue" in alert


def test_startup_alert_with_pendientes(db):
    conn, _ = db
    store.add_entry(conn, tipo="DESCUBRIMIENTO", resumen="Algo viejo", estado="INFERIDO")
    for i in range(1, 7):
        store.add_exchange(conn, n=i, user_msg=f"msg {i}", asst_msg="resp")
    alert = store.get_startup_alert(conn)
    assert "Pendientes de revisión" in alert
    assert "1 entries sin confirmar" in alert


def test_startup_alert_no_pendientes(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Firme", estado="FIRME")
    alert = store.get_startup_alert(conn)
    assert "Pendientes" not in alert


# --- Stats ---


def test_get_stats_empty(db):
    conn, _ = db
    stats = store.get_stats(conn)
    assert stats["entries"] == 0
    assert stats["exchanges"] == 0
    assert stats["detection_rate"] == 0
    assert stats["by_tipo"] == {}
    assert stats["by_estado"] == {}
    assert stats["top_connected"] == []


def test_get_stats_with_data(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Usar Vue", estado="FIRME")
    store.add_entry(conn, tipo="DESCARTE", resumen="React descartado", estado="DESCARTADO")
    store.add_entry(conn, tipo="DECISIÓN", resumen="SQLite DB", estado="FIRME")
    store.add_exchange(conn, n=1, user_msg="test", asst_msg="ok")
    store.add_exchange(conn, n=2, user_msg="test2", asst_msg="ok2")

    stats = store.get_stats(conn)
    assert stats["entries"] == 3
    assert stats["exchanges"] == 2
    assert stats["detection_rate"] == 1.5
    assert stats["by_tipo"]["DECISIÓN"] == 2
    assert stats["by_tipo"]["DESCARTE"] == 1
    assert stats["by_estado"]["FIRME"] == 2
    assert stats["by_estado"]["DESCARTADO"] == 1


def test_get_stats_top_connected(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="A")
    store.add_entry(conn, tipo="DECISIÓN", resumen="B")
    store.add_entry(conn, tipo="DECISIÓN", resumen="C")
    store.add_edge(conn, "E001", "E002")
    store.add_edge(conn, "E001", "E003")

    stats = store.get_stats(conn)
    assert len(stats["top_connected"]) > 0
    assert stats["top_connected"][0]["id"] == "E001"


# --- Proyecto mode ---


def test_proyecto_creates_sessions_table(proyecto_db):
    conn, _ = proyecto_db
    tables = [r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    ).fetchall()]
    assert "sessions" in tables
    assert store.get_meta(conn, "modo") == "proyecto"


def test_create_session_and_list(proyecto_db):
    conn, _ = proyecto_db
    sid = store.create_session(conn, name="brainstorm")
    sessions = store.list_sessions(conn)
    assert len(sessions) == 1
    assert store.get_active_session(conn) == sid


def test_proyecto_accepts_hipotesis_and_fuente(proyecto_db):
    conn, _ = proyecto_db
    e1 = store.add_entry(conn, tipo="HIPÓTESIS", resumen="Vue es mejor")
    e2 = store.add_entry(conn, tipo="FUENTE", resumen="Paper de Smith")
    assert store.get_entry(conn, e1)["tipo"] == "HIPÓTESIS"
    assert store.get_entry(conn, e2)["tipo"] == "FUENTE"


def test_sesion_mode_rejects_hipotesis(db):
    conn, _ = db
    with pytest.raises(Exception):
        store.add_entry(conn, tipo="HIPÓTESIS", resumen="test")


def test_evidencia(proyecto_db):
    conn, _ = proyecto_db
    h = store.add_entry(conn, tipo="HIPÓTESIS", resumen="Vue es mejor")
    s = store.add_entry(conn, tipo="FUENTE", resumen="Benchmark favorable")
    c = store.add_entry(conn, tipo="FUENTE", resumen="Benchmark desfavorable")
    store.add_edge(conn, h, s, "SUPPORTS")
    store.add_edge(conn, h, c, "CONTRADICTS")
    ev = store.evidencia(conn, h)
    assert len(ev["supports"]) == 1
    assert len(ev["contradicts"]) == 1


def test_versiones_chain(proyecto_db):
    conn, _ = proyecto_db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="Usar React", estado="OBSOLETO")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="Usar Vue", estado="FIRME")
    store.add_edge(conn, e2, e1, "SUPERSEDES")
    chain = store.versiones(conn, e2)
    assert len(chain) == 2
    assert chain[0]["id"] == e1
    assert chain[1]["id"] == e2


def test_versiones_cycle_no_infinite_loop(proyecto_db):
    conn, _ = proyecto_db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="A", estado="OBSOLETO")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="B", estado="FIRME")
    store.add_edge(conn, e2, e1, "SUPERSEDES")
    store.add_edge(conn, e1, e2, "SUPERSEDES")
    chain = store.versiones(conn, e1)
    assert 1 <= len(chain) <= 3


def test_versiones_nonexistent_returns_empty(proyecto_db):
    conn, _ = proyecto_db
    assert store.versiones(conn, "E999") == []


def test_add_entry_with_session_id(proyecto_db):
    conn, _ = proyecto_db
    sid = store.get_active_session(conn)
    eid = store.add_entry(conn, tipo="DECISIÓN", resumen="Test", session_id=sid)
    assert store.get_entry(conn, eid)["session_id"] == sid
