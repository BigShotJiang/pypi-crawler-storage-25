"""Tests for bitacorista.engine — detection, classification, pipeline."""

import time
from unittest.mock import patch
import pytest
from bitacorista import db as store
from bitacorista import engine


# --- Detection: Spanish ---


class TestDetectEventsSpanish:
    def test_decision(self):
        tipos = [e["tipo"] for e in engine.detect_events("Decidimos usar Vue para el frontend.")]
        assert "DECISIÓN" in tipos

    def test_descarte(self):
        tipos = [e["tipo"] for e in engine.detect_events("Descartamos React por complejidad.")]
        assert "DESCARTE" in tipos

    def test_correccion(self):
        tipos = [e["tipo"] for e in engine.detect_events("No, eso está mal. La API es REST, no GraphQL.")]
        assert "CORRECCIÓN" in tipos

    def test_cambio_de_tema(self):
        tipos = [e["tipo"] for e in engine.detect_events("Cambiando de tema, hablemos del deploy.")]
        assert "CAMBIO-DE-TEMA" in tipos

    def test_entregable(self):
        tipos = [e["tipo"] for e in engine.detect_events("Creá el archivo de configuración.")]
        assert "ENTREGABLE" in tipos

    def test_descubrimiento(self):
        tipos = [e["tipo"] for e in engine.detect_events("Descubrí que la API tiene rate limiting.")]
        assert "DESCUBRIMIENTO" in tipos

    def test_multiple_events(self):
        events = engine.detect_events("Decidimos usar Vue. Descartamos React.")
        tipos = [e["tipo"] for e in events]
        assert "DECISIÓN" in tipos
        assert "DESCARTE" in tipos
        assert len(events) >= 2

    def test_no_events_in_plain_text(self):
        assert len(engine.detect_events("El clima está lindo hoy.")) == 0

    def test_dedup_nearby(self):
        events = engine.detect_events("No, eso está mal, corregí esto.")
        corr = [e for e in events if e["tipo"] == "CORRECCIÓN"]
        assert 1 <= len(corr) <= 2


# --- Detection: English ---


class TestDetectEventsEnglish:
    def test_decision(self):
        tipos = [e["tipo"] for e in engine.detect_events("We decided to use PostgreSQL.")]
        assert "DECISIÓN" in tipos

    def test_descarte(self):
        tipos = [e["tipo"] for e in engine.detect_events("Scrap that, it doesn't work.")]
        assert "DESCARTE" in tipos

    def test_correccion(self):
        tipos = [e["tipo"] for e in engine.detect_events("No, that's wrong. The API uses REST.")]
        assert "CORRECCIÓN" in tipos

    def test_cambio_de_tema(self):
        tipos = [e["tipo"] for e in engine.detect_events("Switching gears, let's talk about deployment.")]
        assert "CAMBIO-DE-TEMA" in tipos

    def test_entregable(self):
        tipos = [e["tipo"] for e in engine.detect_events("Create the configuration file.")]
        assert "ENTREGABLE" in tipos

    def test_descubrimiento(self):
        tipos = [e["tipo"] for e in engine.detect_events("Turns out the API has rate limiting.")]
        assert "DESCUBRIMIENTO" in tipos

    def test_mixed(self):
        tipos = [e["tipo"] for e in engine.detect_events("We decided to use Vue. Drop that React idea.")]
        assert "DECISIÓN" in tipos
        assert "DESCARTE" in tipos


# --- Detection: Proyecto mode ---


class TestDetectEventsProyecto:
    def test_hipotesis_filtered_in_sesion(self):
        tipos = [e["tipo"] for e in engine.detect_events("Mi hipótesis es que funciona.", modo="sesion")]
        assert "HIPÓTESIS" not in tipos

    def test_hipotesis_included_in_proyecto(self):
        tipos = [e["tipo"] for e in engine.detect_events("Mi hipótesis es que funciona.", modo="proyecto")]
        assert "HIPÓTESIS" in tipos

    def test_english_hipotesis(self):
        tipos = [e["tipo"] for e in engine.detect_events("My hypothesis is that it works.", modo="proyecto")]
        assert "HIPÓTESIS" in tipos

    def test_fuente_in_proyecto(self):
        tipos = [e["tipo"] for e in engine.detect_events("Según el paper de Smith, es correcto.", modo="proyecto")]
        assert "FUENTE" in tipos

    def test_english_fuente(self):
        tipos = [e["tipo"] for e in engine.detect_events("According to the study, it works.", modo="proyecto")]
        assert "FUENTE" in tipos


# --- Classification ---


class TestClassifyEstado:
    def test_english_firme(self):
        assert engine.classify_estado("Confirmed: we use Vue", "DECISIÓN") == "FIRME"
        assert engine.classify_estado("We decided to go with SQLite", "DECISIÓN") == "FIRME"

    def test_descarte_always_descartado(self):
        assert engine.classify_estado("cualquier texto", "DESCARTE") == "DESCARTADO"

    def test_spanish_firme(self):
        assert engine.classify_estado("Confirmado: usamos Vue", "DECISIÓN") == "FIRME"
        assert engine.classify_estado("Decidimos ir con SQLite", "DECISIÓN") == "FIRME"

    def test_no_signal_is_inferido(self):
        assert engine.classify_estado("algo pasó", "DECISIÓN") == "INFERIDO"

    def test_descarte_beats_firme(self):
        assert engine.classify_estado("decidimos descartar React", "DESCARTE") == "DESCARTADO"


# --- Resumen extraction ---


def test_extract_resumen_clean():
    resumen = engine.extract_resumen("  Decidimos usar Vue para el frontend.  ", "DECISIÓN")
    assert 5 < len(resumen) < 200
    assert "\n" not in resumen


def test_extract_contexto_fragment():
    text = "A" * 50 + "MATCH" + "B" * 250
    contexto = engine.extract_contexto(text, 50)
    assert 0 < len(contexto) <= 350


# --- Pipeline ---


def test_process_exchange_registers_events(db):
    conn, _ = db
    entries = engine.process_exchange(conn, "Decidimos usar Vue. Descartamos React.", exchange_n=1)
    assert len(entries) >= 2
    tipos = [e["tipo"] for e in entries]
    assert "DECISIÓN" in tipos
    assert "DESCARTE" in tipos
    for e in entries:
        if e["tipo"] == "DESCARTE":
            assert e["estado"] == "DESCARTADO"


def test_process_exchange_stores_exchange(db):
    conn, _ = db
    engine.process_exchange(conn, "Hola mundo", exchange_n=1)
    exs = store.get_exchanges(conn)
    assert len(exs) == 1
    assert exs[0]["user_msg"] == "Hola mundo"


def test_process_exchange_no_events_for_plain_text(db):
    conn, _ = db
    assert len(engine.process_exchange(conn, "El clima está lindo.", exchange_n=1)) == 0


def test_process_batch(db):
    conn, _ = db
    exchanges = [
        {"user_msg": "Decidimos usar Python.", "n": 1},
        {"user_msg": "Descartamos Java.", "n": 2},
    ]
    assert len(engine.process_batch(conn, exchanges)) >= 2


def test_proyectar_descartes(db):
    conn, _ = db
    store.add_entry(conn, tipo="DESCARTE", resumen="React", estado="DESCARTADO")
    store.add_entry(conn, tipo="DECISIÓN", resumen="Vue", estado="FIRME")
    descartes = engine.proyectar_descartes(conn)
    assert len(descartes) == 1
    assert descartes[0]["resumen"] == "React"


def test_process_exchange_proyecto_hipotesis(proyecto_db):
    conn, _ = proyecto_db
    sid = store.get_active_session(conn)
    entries = engine.process_exchange(
        conn, "Mi hipótesis es que Vue es más rápido. Decidimos probar.",
        exchange_n=1, session_id=sid,
    )
    tipos = [e["tipo"] for e in entries]
    assert "HIPÓTESIS" in tipos
    assert "DECISIÓN" in tipos


# --- Timing ---


def test_full_cycle_under_10_seconds(db):
    conn, _ = db
    start = time.time()
    engine.process_exchange(conn, "Decidimos usar Python.", exchange_n=1)
    engine.process_exchange(conn, "Descartamos Java.", exchange_n=2)
    engine.process_exchange(conn, "Confirmado: SQLite como DB.", exchange_n=3)
    store.get_resumen(conn)
    store.get_entries(conn)
    store.get_edges(conn)
    engine.proyectar_descartes(conn)
    assert time.time() - start < 10


# --- PREGUNTA detection ---


def test_detect_pregunta_explicame_es():
    events = engine.detect_events("Explicame qué es un hook?")
    assert any(e["tipo"] == "PREGUNTA" for e in events)


def test_detect_pregunta_no_entiendo_es():
    events = engine.detect_events("No entiendo qué pasa con el deploy?")
    assert any(e["tipo"] == "PREGUNTA" for e in events)


def test_detect_pregunta_what_is_en():
    events = engine.detect_events("What is a webhook?")
    assert any(e["tipo"] == "PREGUNTA" for e in events)


def test_detect_pregunta_how_does_en():
    events = engine.detect_events("How does the hook system work?")
    assert any(e["tipo"] == "PREGUNTA" for e in events)


def test_pregunta_requires_question_mark():
    """PREGUNTA without ? is not detected (prevents false positives)."""
    events = engine.detect_events("What is interesting is that we decided to use Vue")
    assert not any(e["tipo"] == "PREGUNTA" for e in events)


def test_pregunta_false_positive_explain():
    """'Let me explain' is not a question."""
    events = engine.detect_events("Let me explain the architecture to you")
    assert not any(e["tipo"] == "PREGUNTA" for e in events)


def test_pregunta_false_positive_por_que_afirmacion():
    """'Por qué elegimos Vue es obvio' is a statement, not a question."""
    events = engine.detect_events("Por qué elegimos Vue es obvio")
    assert not any(e["tipo"] == "PREGUNTA" for e in events)


def test_pregunta_always_inferido():
    estado = engine.classify_estado("Explicame qué es un hook", "PREGUNTA")
    assert estado == "INFERIDO"


# --- Pattern packs ---


def test_load_patterns_dev():
    engine.reset_patterns()
    # Before loading: "commiteamos" not detected
    events = engine.detect_events("commiteamos esto")
    has_decision = any(e["tipo"] == "DECISIÓN" for e in events)
    # Load dev pack
    engine.load_patterns("dev")
    events_after = engine.detect_events("commiteamos esto")
    has_decision_after = any(e["tipo"] == "DECISIÓN" for e in events_after)
    assert has_decision_after
    engine.reset_patterns()


def test_reset_patterns():
    engine.load_patterns("dev")
    events = engine.detect_events("commiteamos esto")
    assert any(e["tipo"] == "DECISIÓN" for e in events)
    engine.reset_patterns()
    events = engine.detect_events("commiteamos esto")
    assert not any(e["tipo"] == "DECISIÓN" for e in events)


def test_load_invalid_pack():
    import pytest
    with pytest.raises(ValueError, match="not found"):
        engine.load_patterns("nonexistent")


def test_dev_pack_ship_it():
    engine.load_patterns("dev")
    events = engine.detect_events("Ship it, let's deploy")
    tipos = {e["tipo"] for e in events}
    assert "DECISIÓN" in tipos
    engine.reset_patterns()


def test_dev_pack_bug_found():
    engine.load_patterns("dev")
    events = engine.detect_events("There's a bug in the login flow")
    tipos = {e["tipo"] for e in events}
    assert "DESCUBRIMIENTO" in tipos
    engine.reset_patterns()


def test_dev_pack_tests_passing():
    engine.load_patterns("dev")
    events = engine.detect_events("Los tests pasan todos")
    tipos = {e["tipo"] for e in events}
    assert "ENTREGABLE" in tipos
    engine.reset_patterns()


# --- Event callbacks ---


@pytest.fixture(autouse=False)
def clean_callbacks():
    """Ensures _event_callbacks is clean before and after each callback test."""
    engine._event_callbacks.clear()
    yield
    engine._event_callbacks.clear()


def test_on_event_callback(db, clean_callbacks):
    conn, _ = db
    received = []
    engine.on_event(lambda e: received.append(e))
    engine.process_exchange(conn, "Decidimos usar Python.", exchange_n=1)
    assert len(received) > 0
    assert received[0]["tipo"] == "DECISIÓN"


def test_on_event_duplicate_registration(db, clean_callbacks):
    conn, _ = db
    received = []
    cb = lambda e: received.append(e)
    engine.on_event(cb)
    engine.on_event(cb)  # duplicate — should not register twice
    engine.process_exchange(conn, "Decidimos usar Vue.", exchange_n=1)
    assert len(received) == 1  # called once, not twice


def test_remove_event_callback(db, clean_callbacks):
    conn, _ = db
    received = []
    cb = lambda e: received.append(e)
    engine.on_event(cb)
    engine.remove_event_callback(cb)
    engine.process_exchange(conn, "Decidimos usar Java.", exchange_n=1)
    assert len(received) == 0


def test_callback_error_does_not_break(db, clean_callbacks):
    conn, _ = db
    good_received = []

    def bad_cb(e):
        raise RuntimeError("boom")

    engine.on_event(bad_cb)
    engine.on_event(lambda e: good_received.append(e))
    engine.process_exchange(conn, "Decidimos usar Go.", exchange_n=1)
    assert len(good_received) > 0


def test_no_callback_when_no_events(db, clean_callbacks):
    conn, _ = db
    received = []
    engine.on_event(lambda e: received.append(e))
    engine.process_exchange(conn, "Hola, cómo estás?", exchange_n=1)
    assert len(received) == 0


# --- resolve_embedding ---


FAKE_EMBEDDING = [0.1] * 384


def test_resolve_embedding_with_query(db):
    """With explicit query, embeds the query text."""
    conn, _ = db
    with patch.object(engine, "embed", return_value=FAKE_EMBEDDING) as mock:
        result = engine.resolve_embedding(conn, query="test query")
    assert result == FAKE_EMBEDDING
    mock.assert_called_once_with("test query")


def test_resolve_embedding_no_query_few_exchanges(db):
    """Without query and <3 exchanges, returns None (classic fallback)."""
    conn, _ = db
    engine.process_exchange(conn, "Hola", exchange_n=1)
    engine.process_exchange(conn, "Chau", exchange_n=2)
    result = engine.resolve_embedding(conn, query=None)
    assert result is None


def test_resolve_embedding_auto_query(db):
    """Without query and >=3 exchanges, auto-queries with last 3 user messages."""
    conn, _ = db
    engine.process_exchange(conn, "Decidimos usar Python.", exchange_n=1)
    engine.process_exchange(conn, "Descartamos Java.", exchange_n=2)
    engine.process_exchange(conn, "Confirmado SQLite.", exchange_n=3)
    with patch.object(engine, "embed", return_value=FAKE_EMBEDDING) as mock:
        result = engine.resolve_embedding(conn, query=None)
    assert result == FAKE_EMBEDDING
    # Verify it was called with the concatenated user messages
    call_text = mock.call_args[0][0]
    assert "Python" in call_text
    assert "Java" in call_text
    assert "SQLite" in call_text


def test_resolve_embedding_empty_user_msgs(db):
    """With >=3 exchanges but empty user_msg, returns None."""
    conn, _ = db
    # Add exchanges with empty user messages via direct SQL
    for i in range(1, 4):
        store.add_exchange(conn, n=i, user_msg="", asst_msg="response")
    result = engine.resolve_embedding(conn, query=None)
    assert result is None


def test_resolve_embedding_no_model(db):
    """When embed() returns None (no model), returns None."""
    conn, _ = db
    with patch.object(engine, "embed", return_value=None):
        result = engine.resolve_embedding(conn, query="anything")
    assert result is None
