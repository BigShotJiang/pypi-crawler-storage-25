"""Shared fixtures for bitacorista tests."""

import os
import tempfile
import pytest
from bitacorista import db as store


@pytest.fixture
def db():
    """Creates a temp DB, yields (conn, path), cleans up."""
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    os.unlink(path)
    conn = store.init_db(path)
    yield conn, path
    conn.close()
    for ext in ["", "-wal", "-shm"]:
        try:
            os.unlink(path + ext)
        except OSError:
            pass


@pytest.fixture
def proyecto_db():
    """Creates a temp proyecto DB, yields (conn, path), cleans up."""
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    os.unlink(path)
    conn = store.init_db(path, modo="proyecto")
    yield conn, path
    conn.close()
    for ext in ["", "-wal", "-shm"]:
        try:
            os.unlink(path + ext)
        except OSError:
            pass


@pytest.fixture
def db_path():
    """Temp DB path with cleanup (no connection — for CLI tests)."""
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    os.unlink(path)
    yield path
    for ext in ["", "-wal", "-shm"]:
        try:
            os.unlink(path + ext)
        except OSError:
            pass
