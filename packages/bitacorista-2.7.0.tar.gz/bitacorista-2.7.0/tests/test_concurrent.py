"""Tests for concurrent write access to bitacorista DB.

Validates that the transaction model (isolation_level=None + BEGIN IMMEDIATE
+ WAL journal) handles parallel writers correctly: no lost writes, no
duplicate IDs, no corruption.
"""

import os
import queue
import tempfile
import threading
import time
import sqlite3
import pytest
from bitacorista import db as store


@pytest.fixture
def shared_db():
    """Create a temp DB and return its path (not a connection).

    Each thread must open its own connection — SQLite connections
    are not thread-safe.
    """
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    os.unlink(path)
    # Initialize schema once
    conn = store.init_db(path)
    conn.close()
    yield path
    for ext in ["", "-wal", "-shm"]:
        try:
            os.unlink(path + ext)
        except OSError:
            pass


def _writer(path: str, n_entries: int, tipo: str, result_q: queue.Queue, error_q: queue.Queue):
    """Worker: open own connection, write n_entries, collect IDs."""
    try:
        conn = store.open_db(path)
        for i in range(n_entries):
            eid = store.add_entry(conn, tipo=tipo, resumen=f"{tipo}-{threading.current_thread().name}-{i}")
            result_q.put(eid)
        conn.close()
    except Exception as e:
        error_q.put(e)


def _drain(q: queue.Queue) -> list:
    """Drain a queue into a list."""
    items = []
    while not q.empty():
        items.append(q.get_nowait())
    return items


def _run_threads(targets_args: list, timeout: int = 30):
    """Start threads and join. Returns (result_q, error_q)."""
    result_q = queue.Queue()
    error_q = queue.Queue()
    threads = []
    for target, args, name in targets_args:
        t = threading.Thread(target=target, args=args, name=name)
        threads.append(t)
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=timeout)
    return result_q, error_q


class TestConcurrentWrites:
    def test_parallel_add_entry_no_lost_writes(self, shared_db):
        """10 threads x 10 entries = 100 entries, all persisted."""
        n_threads = 10
        n_per_thread = 10
        result_q = queue.Queue()
        error_q = queue.Queue()
        threads = []

        for i in range(n_threads):
            t = threading.Thread(
                target=_writer,
                args=(shared_db, n_per_thread, "DECISIÓN", result_q, error_q),
                name=f"w{i}",
            )
            threads.append(t)

        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)

        errors = _drain(error_q)
        assert not errors, f"Thread errors: {errors}"

        conn = store.open_db(shared_db)
        entries = store.get_entries(conn)
        conn.close()

        assert len(entries) == n_threads * n_per_thread

    def test_parallel_ids_unique(self, shared_db):
        """All IDs generated under concurrency are unique."""
        n_threads = 10
        n_per_thread = 10
        result_q = queue.Queue()
        error_q = queue.Queue()
        threads = []

        for i in range(n_threads):
            t = threading.Thread(
                target=_writer,
                args=(shared_db, n_per_thread, "DECISIÓN", result_q, error_q),
                name=f"w{i}",
            )
            threads.append(t)

        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)

        errors = _drain(error_q)
        results = _drain(result_q)
        assert not errors, f"Thread errors: {errors}"
        assert len(set(results)) == len(results), f"Duplicate IDs: {len(results)} total, {len(set(results))} unique"

    def test_parallel_ids_sequential(self, shared_db):
        """IDs form a contiguous sequence E001..E100 (no gaps)."""
        n_threads = 5
        n_per_thread = 20
        result_q = queue.Queue()
        error_q = queue.Queue()
        threads = []

        for i in range(n_threads):
            t = threading.Thread(
                target=_writer,
                args=(shared_db, n_per_thread, "IDEA", result_q, error_q),
                name=f"w{i}",
            )
            threads.append(t)

        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)

        errors = _drain(error_q)
        results = _drain(result_q)
        assert not errors, f"Thread errors: {errors}"

        total = n_threads * n_per_thread
        expected = {f"E{i:03d}" for i in range(1, total + 1)}
        assert set(results) == expected

    def test_parallel_mixed_tipos(self, shared_db):
        """Different tipos written concurrently all persist correctly."""
        tipos = ["DECISIÓN", "DESCARTE", "IDEA", "DESCUBRIMIENTO", "ENTREGABLE"]
        n_per_thread = 10
        result_q = queue.Queue()
        error_q = queue.Queue()
        threads = []

        for tipo in tipos:
            t = threading.Thread(
                target=_writer,
                args=(shared_db, n_per_thread, tipo, result_q, error_q),
                name=f"w-{tipo}",
            )
            threads.append(t)

        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)

        errors = _drain(error_q)
        assert not errors, f"Thread errors: {errors}"

        conn = store.open_db(shared_db)
        for tipo in tipos:
            entries = store.get_entries(conn, tipo=tipo)
            assert len(entries) == n_per_thread, f"{tipo}: expected {n_per_thread}, got {len(entries)}"
        conn.close()

    def test_parallel_exchange_writes(self, shared_db):
        """Concurrent add_exchange calls don't lose data."""
        n_threads = 10
        error_q = queue.Queue()

        def exchange_writer(path, thread_id):
            try:
                conn = store.open_db(path)
                for i in range(5):
                    n = thread_id * 100 + i
                    store.add_exchange(conn, n, f"msg-{thread_id}-{i}")
                conn.close()
            except Exception as e:
                error_q.put(e)

        threads = []
        for i in range(n_threads):
            t = threading.Thread(target=exchange_writer, args=(shared_db, i))
            threads.append(t)

        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)

        errors = _drain(error_q)
        assert not errors, f"Thread errors: {errors}"

        conn = store.open_db(shared_db)
        assert store.count_exchanges(conn) == n_threads * 5
        conn.close()

    def test_read_during_writes(self, shared_db):
        """Readers don't block writers and see consistent data (WAL benefit)."""
        error_q = queue.Queue()
        write_done = threading.Event()
        read_counts = queue.Queue()

        def writer(path):
            try:
                conn = store.open_db(path)
                for i in range(50):
                    store.add_entry(conn, tipo="DECISIÓN", resumen=f"entry-{i}")
                conn.close()
            except Exception as e:
                error_q.put(e)
            finally:
                write_done.set()

        def reader(path):
            try:
                conn = store.open_db(path)
                while not write_done.is_set():
                    entries = store.get_entries(conn)
                    read_counts.put(len(entries))
                # Writer is done — read until we see all 50
                for _ in range(10):
                    entries = store.get_entries(conn)
                    count = len(entries)
                    read_counts.put(count)
                    if count == 50:
                        break
                    time.sleep(0.01)
                conn.close()
            except Exception as e:
                error_q.put(e)

        tw = threading.Thread(target=writer, args=(shared_db,))
        tr = threading.Thread(target=reader, args=(shared_db,))

        tw.start()
        tr.start()
        tw.join(timeout=30)
        tr.join(timeout=30)

        errors = _drain(error_q)
        counts = _drain(read_counts)
        assert not errors, f"Errors: {errors}"
        # Reader should see monotonically increasing counts
        for i in range(1, len(counts)):
            assert counts[i] >= counts[i - 1], (
                f"Non-monotonic read: {counts[i-1]} -> {counts[i]}"
            )
        # Must eventually see all 50
        assert counts[-1] == 50

    def test_caller_managed_transactions(self, shared_db):
        """_commit=False with caller-managed BEGIN IMMEDIATE works under concurrency."""
        error_q = queue.Queue()
        result_q = queue.Queue()

        def batch_writer(path, batch_id):
            try:
                conn = store.open_db(path)
                conn.execute("BEGIN IMMEDIATE")
                ids = []
                for i in range(5):
                    eid = store.add_entry(
                        conn, tipo="DECISIÓN",
                        resumen=f"batch-{batch_id}-{i}",
                        _commit=False,
                    )
                    ids.append(eid)
                conn.execute("COMMIT")
                for eid in ids:
                    result_q.put(eid)
                conn.close()
            except Exception as e:
                try:
                    conn.execute("ROLLBACK")
                except Exception:
                    pass
                error_q.put(e)

        threads = []
        for i in range(10):
            t = threading.Thread(target=batch_writer, args=(shared_db, i), name=f"batch-{i}")
            threads.append(t)

        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)

        errors = _drain(error_q)
        results = _drain(result_q)
        assert not errors, f"Thread errors: {errors}"
        assert len(results) == 50
        assert len(set(results)) == 50, "Duplicate IDs in caller-managed transactions"

        # Verify all persisted
        conn = store.open_db(shared_db)
        entries = store.get_entries(conn)
        conn.close()
        assert len(entries) == 50

    def test_busy_timeout_respected(self, shared_db):
        """When a writer holds a long transaction, others wait up to busy_timeout."""
        error_q = queue.Queue()
        holder_started = threading.Event()
        holder_release = threading.Event()

        def long_holder(path):
            """Hold a transaction open for a while."""
            try:
                conn = store.open_db(path)
                conn.execute("BEGIN IMMEDIATE")
                store.add_entry(conn, tipo="DECISIÓN", resumen="held", _commit=False)
                holder_started.set()
                holder_release.wait(timeout=10)
                conn.execute("COMMIT")
                conn.close()
            except Exception as e:
                error_q.put(e)

        def waiter(path):
            """Try to write while holder has the lock."""
            try:
                conn = store.open_db(path)
                # Default busy_timeout is 5000ms — should be enough
                holder_started.wait(timeout=5)
                store.add_entry(conn, tipo="IDEA", resumen="waited")
                conn.close()
            except Exception as e:
                error_q.put(e)

        th = threading.Thread(target=long_holder, args=(shared_db,))
        tw = threading.Thread(target=waiter, args=(shared_db,))

        th.start()
        tw.start()

        # Let holder run for 0.5s then release
        time.sleep(0.5)
        holder_release.set()

        th.join(timeout=10)
        tw.join(timeout=10)

        errors = _drain(error_q)
        assert not errors, f"Errors: {errors}"

        conn = store.open_db(shared_db)
        entries = store.get_entries(conn)
        conn.close()
        assert len(entries) == 2
