# Contributing to Bitacorista

Thanks for considering a contribution. This guide covers the basics.

## Setup

```bash
git clone https://github.com/Fito-panda/bitacorista-py.git
cd bitacorista-py
pip install -e ".[dev]"
```

The `dev` extra includes test and type-checking dependencies plus the embedding stack (ONNX + tokenizers). If you only need core tests:

```bash
pip install -e ".[search]"
pip install pytest
```

## Running tests

```bash
# Core tests (no model needed)
pytest tests/ -v -m "not embeddings"

# All tests (requires model download)
python -m bitacorista.download_model
pytest tests/ -v
```

## Type checking

```bash
python -m mypy bitacorista/
```

Zero errors expected. Strict mode is on (`disallow_untyped_defs`).

## Project structure

```
bitacorista/
  db.py       <- SQLite layer. Only gate to the database.
  engine.py   <- Regex detection, embeddings, blast radius.
  cli.py      <- CLI commands.
```

Three files. If you're adding a feature, it goes in one of these.

## Code conventions

- **Python 3.10+** — use `str | None`, not `Optional[str]`
- **All functions typed** — mypy strict mode enforces this
- **Transactions** — every write function uses `BEGIN IMMEDIATE` / `COMMIT` / `ROLLBACK`. No bare `db.commit()`. See `db.py` for the pattern.
- **`_commit` parameter** — write functions accept `_commit=True`. When `False`, the caller manages the transaction. This enables composable writes.
- **No LLM at runtime** — detection is regex-only. Embeddings are optional and local (ONNX).
- **Dependencies** — the core has zero deps. Think twice before adding one.

## Adding a detection pattern

Event patterns live in `engine.py` inside `detect_events()`. Each pattern is a regex with a type and state. If you're adding support for a new language or improving detection:

1. Add the regex pattern to the appropriate section
2. Add a test in `tests/test_engine.py`
3. Make sure existing tests still pass

## Pull requests

- One logical change per PR
- Tests required for new functionality
- `mypy` must pass with zero errors
- Keep PRs small — large PRs take longer to review

## Reporting bugs

Use [GitHub Issues](https://github.com/Fito-panda/bitacorista-py/issues). Include:
- Python version
- OS
- Minimal reproduction steps
- Full error traceback

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
