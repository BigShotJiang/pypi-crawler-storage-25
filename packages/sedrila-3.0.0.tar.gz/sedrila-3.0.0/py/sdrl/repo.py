"""
Logic for handling information coming from git repos: 
effort commits, submissions, submission checks.
Knows about the respective format conventions.
"""
import contextlib
import datetime as dt
import enum
import os.path
import re
import subprocess as sp
import typing as tg

import yaml

import base as b
import sgit
import sdrl.constants as c
import sdrl.course
import sdrl.course_si


class ET(enum.StrEnum):  # EventType
    work = 'work'  # student worktime entry (via commit msg format)
    accept = 'accept'  # instructor accept (via signed submission.yaml commit)
    reject = 'reject'  # instructor accept (via signed submission.yaml commit)
    manual = 'manual'  # instructor manual timevalue booking (via signed "MANUAL" commit)


class Event(tg.NamedTuple):
    evtype: ET
    student: str  # username
    committer: str  # email
    when: dt.datetime
    content: str  # taskname or manual booking reason
    timevalue: float


class TaskCheckEntry(tg.NamedTuple):
    commit: sgit.Commit
    taskname: str
    tasknote: str


class ManualEntry(tg.NamedTuple):
    commit: sgit.Commit
    timevalue: float
    reason: str  # taskname or other description from commit message


class WorkEntry(tg.NamedTuple):
    commit: sgit.Commit
    taskname: str
    timevalue: float


class ReportEntry(tg.NamedTuple):
    taskname: str
    taskpath: str
    workhoursum: float
    timevalue: float
    rejections: int
    accepted: bool


def import_gpg_keys(instructors: tg.Sequence[b.StrAnyDict]):
    """Teach GPG to recognize the course instructors' public keys."""
    for instructor in instructors:
        if not(instructor.get('pubkey')):
            b.warning("No key present for " + instructor.get('nameish') + ", skipping")
            continue
        b.info("Importing key for " + instructor.get('nameish'))
        if type(instructor['pubkey']) is list:
            instructor['pubkey'] = "\n".join(instructor['pubkey'])
        if not instructor['pubkey'].startswith("-----"):
            instructor['pubkey'] = ("-----BEGIN PGP PUBLIC KEY BLOCK-----\n"
                                    f"\n{instructor['pubkey']}\n"
                                    "-----END PGP PUBLIC KEY BLOCK-----")
        sp.run(["gpg", "--import"], input=instructor['pubkey'], encoding='ascii')


def event_list(course: sdrl.course.Course, student_username: str, commits: tg.Sequence[sgit.Commit]) -> list[Event]:
    """All events that may be of interest to the evaluator role."""
    result = []
    instructor_commits = submission_checked_commits(course.instructors, commits)
    for tc_entry in taskcheck_entries_from_commits(instructor_commits):
        commit = tc_entry.commit
        taskname = tc_entry.taskname
        task = course.task(taskname)
        if not task:
            continue
        event = Event(ET.accept if is_accepted(tc_entry.tasknote) else ET.reject, 
                      student_username, commit.author_email, commit.author_date, 
                      taskname, task.timevalue)
        result.append(event)
    for work_entry in work_entries_from_commits(commits):
        commit = work_entry.commit
        event = Event(ET.work,
                      student_username, commit.author_email, commit.author_date,
                      work_entry.taskname, work_entry.timevalue)
        result.append(event)
    all_instructors = course.instructors + course.former_instructors
    for entry in manual_entries_from_commits(all_instructors, commits,
                                             course.manual_booking_types, course.taskdict,
                                             warn_if_invalid=False):
        commit = entry.commit
        event = Event(ET.manual,
                      student_username, commit.author_email, commit.author_date,
                      entry.reason, entry.timevalue)
        result.append(event)
    return result


def compute_student_work_so_far(course: sdrl.course_si.CourseSI, commits: tg.Sequence[sgit.Commit]):
    """
    Obtain per-task worktimes from student commits and
    per-task timevalues from submission checked commits.
    Store them in course.
    """
    _accumulate_student_workhours_per_task(commits, course)
    all_instructors = course.instructors + course.former_instructors  # treated equally for now
    instructor_commits = submission_checked_commits(all_instructors, commits)
    course.manual_bookings = manual_entries_from_commits(
        all_instructors, commits, course.manual_booking_types, course.taskdict, warn_if_invalid=True)
    taskcheck_entries = taskcheck_entries_from_commits(instructor_commits)
    _accumulate_timevalues_and_attempts(taskcheck_entries, course)


def _allowed_signers(instructors: tg.Sequence[tg.Mapping[str, str]]) -> set[str]:
    """Compute the set of allowed GPG fingerprints from instructor configs."""
    try:
        return {b.as_fingerprint(instructor['keyfingerprint'])
                for instructor in instructors if 'keyfingerprint' in instructor}
    except KeyError:
        b.critical("missing 'keyfingerprint' in configuration")
        return set()  # unreachable, but satisfies linter


def submission_checked_commits(instructors: tg.Sequence[tg.Mapping[str, str]],
                               commits: tg.Sequence[sgit.Commit]) -> list[sgit.Commit]:
    """The properly instructor-signed Commits of finished submission checks."""
    allowed_signers = _allowed_signers(instructors)
    result = []
    for commit in commits:
        b.debug(f"commit.subject, fpr: {commit.subject}, {commit.key_fingerprint}")
        right_subject = re.match(c.SUBMISSION_CHECKED_COMMIT_MSG, commit.subject) is not None
        if right_subject:
            if is_allowed_signer(commit, allowed_signers):
                result.append(commit)
            else:
                b.warning(f"Commit {commit.hash[:9]} '{commit.subject}' was not signed by an instructor")
    return result


def submission_state(workdir: str, instructor_fingerprints: set[str]) -> str:
    """Determines which of SUBMISSION_STATE_FRESH/CHECKING/CHECKED/OTHER applies to the repo in workdir."""
    with contextlib.chdir(workdir):
        # ----- make sure c.SUBMISSION_FILE exists:
        if not os.path.exists(c.SUBMISSION_FILE):
            b.warning(f"'{workdir}': file '{c.SUBMISSION_FILE}' does not exist.")
            return c.SUBMISSION_STATE_OTHER
        # ----- check for case CHECKING:
        if sgit.is_modified(c.SUBMISSION_FILE):
            return c.SUBMISSION_STATE_CHECKING
        # ----- check for case FRESH:
        regexp = '|'.join((re.escape(c.SUBMISSION_COMMIT_MSG), re.escape(c.SUBMISSION_CHECKED_COMMIT_MSG)))
        commit = sgit.find_most_recent_commit(regexp)
        if not commit:  # c.SUBMISSION_FILE was never checked in correctly
            b.warning(f"'{workdir}': No commit found with message  '{c.SUBMISSION_COMMIT_MSG}'.")
            return c.SUBMISSION_STATE_OTHER
        if commit.subject == c.SUBMISSION_COMMIT_MSG:
            return c.SUBMISSION_STATE_FRESH
        # ----- check for case CHECKED:
        assert commit.subject == c.SUBMISSION_CHECKED_COMMIT_MSG
        if commit.key_fingerprint in instructor_fingerprints:
            return c.SUBMISSION_STATE_CHECKED
        # ----- the final remaining case of OTHER:
        b.warning(f"'{workdir}': Commit with message  '{c.SUBMISSION_CHECKED_COMMIT_MSG}' is not signed by instructor.")
        return c.SUBMISSION_STATE_OTHER


def is_allowed_signer(commit: sgit.Commit, allowed_signers: set[str]) -> bool:
    return commit.key_fingerprint and b.as_fingerprint(commit.key_fingerprint) in allowed_signers  


def taskcheck_entries_from_commits(instructor_commits: list[sgit.Commit]) -> tg.Sequence[TaskCheckEntry]:
    """
    Collect the individual entries for all 'submission.yaml checked' commits.
    """
    result = []
    for commit in instructor_commits:
        checks = yaml.safe_load(sgit.contents_of_file_version(commit.hash, c.SUBMISSION_FILE, encoding='utf8'))
        for taskname, tasknote in checks.items():
            result.append(TaskCheckEntry(commit, taskname, tasknote))
    return result


def work_entries_from_commits(commits: tg.Iterable[sgit.Commit]) -> tg.Sequence[WorkEntry]:
    """
    Collect the individual entries for all commits conforming to the worktime format.
    """
    result = []
    for commit in commits:
        parts = _parse_taskname_workhours(commit.subject)
        if parts is None:  # this is no worktime commit
            continue
        taskname, worktime = parts  # unpack
        result.append(WorkEntry(commit, taskname, worktime))
    b.info(f"{len(result)} worktime entry commits")
    return result


def manual_entries_from_commits(instructors: tg.Sequence[tg.Mapping[str, str]],
                                commits: tg.Sequence[sgit.Commit],
                                booking_types: list[str],
                                taskdict: dict[str, 'sdrl.course.Task'],
                                warn_if_invalid: bool) -> list[ManualEntry]:
    """Collect valid ManualEntry objects from instructor-signed MANUAL booking commits.
    Returns empty list if booking_types is empty (manual bookings not configured)."""
    if not booking_types:
        return []
    allowed_signers = _allowed_signers(instructors)
    result = []
    for commit in commits:
        if not commit.subject.startswith(c.MANUAL_BOOKING_MARKER):
            continue
        if not is_allowed_signer(commit, allowed_signers):
            b.warning(f"Commit {commit.hash[:9]} '{commit.subject}' was not signed by an instructor")
            continue
        parsed = _parse_manual_booking(commit.subject)
        if parsed is None:
            continue
        timevalue, reason = parsed
        if reason in taskdict or reason in booking_types:
            result.append(ManualEntry(commit, timevalue, reason))
        elif warn_if_invalid:
            b.warning(f"Manual booking commit {commit.hash[:9]}: "
                      f"invalid reason '{reason}'. Ignored.")
    b.info(f"{len(result)} manual booking commits")
    return result


def student_work_so_far(course: sdrl.course_si.CourseSI) -> tg.Tuple[list[ReportEntry], float, float]:
    """
    Data for work report: 
    retrieve pre-computed per-task entries (worktime, attempts) and totals (workhours, timevalue)
    from a Course object previously filled by compute_student_work_so_far().
    """
    workhours_total = 0.0
    timevalue_total = 0.0
    result = []
    for taskname in sorted((t.name for t in course.taskdict.values())):
        task = course.taskdict[taskname]
        if task.workhours != 0.0:
            workhours_total += task.workhours
            if task.is_accepted:
                timevalue_total += task.timevalue
            result.append(ReportEntry(taskname, task.path, task.workhours, task.timevalue,
                                      task.rejections, task.is_accepted))
    timevalue_total += course.manual_timevalue
    return result, workhours_total, timevalue_total


def is_accepted(tasknote: str):
    return tasknote.startswith(c.SUBMISSION_ACCEPT_MARK)


def is_rejected(tasknote: str):
    return tasknote.startswith(c.SUBMISSION_REJECT_MARK)


def _accumulate_timevalues_and_attempts(checked_entries: tg.Sequence[TaskCheckEntry],
                                        course: sdrl.course.Course):
    """Reflect the checked_entries data in the course data structure."""
    for check in checked_entries:
        b.debug(f"tuple: {check.commit.hash}, {check.taskname}, {check.tasknote}")
        task = course.task(check.taskname)
        if not task:
            continue
        tasknote = check.tasknote
        if tasknote.startswith(c.SUBMISSION_ACCEPT_MARK):
            task.accept_date = check.commit.author_date
            b.debug(f"{check.taskname} accepted")
        elif tasknote.startswith(c.SUBMISSION_REJECT_MARK):  # catches both REJECT and REJECTOID
            if not task.is_accepted:
                task.rejections += 1
                b.debug(f"{check.taskname} rejected")
        else:
            pass  # unmodified entry: instructor has not checked it


def _accumulate_student_workhours_per_task(commits: tg.Iterable[sgit.Commit], course: sdrl.course.Course):
    """Reflect the workentries data in the course data structure."""
    num_commits = num_timeentries = 0
    for commit in commits:
        num_commits += 1
        parts = _parse_taskname_workhours(commit.subject)
        if parts is None:  # this is no worktime commit
            continue
        taskname, worktime = parts  # unpack
        if taskname in course.taskdict:
            task = course.taskdict[taskname]
            task.workhours += worktime
            num_timeentries += 1
        else:
            b.warning(f"Commit '{commit.subject}': Task '{taskname}' does not exist. Entry ignored.")
    b.info(f"read {num_commits} commit messages, found {num_timeentries} work time entries")


def _parse_manual_booking(commit_msg: str) -> tg.Optional[tg.Tuple[float, str]]:
    """Return (timevalue, reason) from a MANUAL booking commit message, or None."""
    mm = re.match(r"^MANUAL\s+(-?\d+(\.\d+)?)\s\s(.+)", commit_msg)
    if not mm:
        return None
    timevalue = float(mm.group(1))
    reason = mm.group(3)
    return timevalue, reason


def _parse_taskname_workhours(commit_msg: str) -> tg.Optional[tg.Tuple[str, float]]:  # taskname, workhours
    """Return pair of (taskname, workhours) from commit message if present, or None otherwise."""
    worktime_regexp = (r"\s*[#%](?P<name>[\w.-]+?)\s+"
                       r"(?:(?P<dectime>-?\d+(\.\d+)?)|"
                       r"(?P<hh>-?\d+):(?P<mm>\d\d)) ?h\b")  # %MyTask117 3.5h   %Some-Stuff 3:45h
    mm = re.match(worktime_regexp, commit_msg)
    if not mm:
        return None  # not the format we're looking for
    taskname = mm.group('name')
    if mm.group('dectime'):  # decimal time
        workhours = float(mm.group('dectime'))
    else:
        workhours = float(mm.group('hh')) + float(mm.group('mm')) / 60  # hh:mm format
    return taskname, workhours
