"""
Builder classes for course content: Taskbuilder, Chapterbuilder, Taskgroupbuilder,
Coursebuilder, MetadataDerivation. Used in author mode to build a course from source files.
"""
import csv
import functools
import glob
import graphlib
import importlib.resources
import itertools
import json
import numbers
import os
import re
import typing as tg

import jsonschema

import base as b
import mycrypt
import sdrl.constants as c
import sdrl.elements as el
import sdrl.glossary as glossary
import sdrl.html as h
import sdrl.macros as macros
import sdrl.partbuilder
from sdrl.course import Task, Taskgroup, Chapter, Course

sedrila_libdir = os.path.dirname(os.path.dirname(__file__))  # either 'py' (for dev install) or top-level
if sedrila_libdir.endswith('py'):  # we are a dev install and must go one more level up:
    sedrila_libdir = os.path.dirname(sedrila_libdir)


@functools.total_ordering
class Taskbuilder(sdrl.partbuilder.PartbuilderMixin, Task):
    TEMPLATENAME = "task.html"
    explains: list[str] = []  # terms (for backlinks in glossary)
    assumed_by: list[str] = []  # tasknames: inverse of assumes
    required_by: list[str] = []  # tasknames: inverse of requires

    taskgroup: 'Taskgroupbuilder'  # where the task belongs

    def __init__(self, name: str, **kwargs):
        super().__init__(name, **kwargs)
        self.directory.record_the(Task, self.name, self)
        self.make_std_dependencies(use_toc_of=self.taskgroup)
        self.make_dependency(el.LinkslistBottom, part=self)

    def __eq__(self, other):
        return other.name == self.name

    def __lt__(self, other):  # for sorting in Coursebuilder._taskordering_for_toc()
        if not isinstance(other, type(self)):
            return NotImplemented
        return (self.difficulty < other.difficulty or
                (self.difficulty == other.difficulty and self.name < other.name))

    def __hash__(self) -> int:
        return hash(self.name)

    @property
    def allowed_attempts(self) -> int:
        course = self.taskgroup.chapter.course
        return int(course.allowed_attempts_base + course.allowed_attempts_hourly*self.timevalue)

    @functools.cached_property
    def linkslist_bottom(self) -> str:
        return self._render_task_linkslist('assumed_by', 'required_by')

    @functools.cached_property
    def linkslist_top(self) -> str:
        return self._render_task_linkslist('assumes', 'requires')

    @property
    def remaining_attempts(self) -> int:
        return max(0, self.allowed_attempts - self.rejections)

    @property
    def to_be_skipped(self) -> bool:
        return (self.skipthis or
                self.taskgroup.to_be_skipped or self.taskgroup.chapter.to_be_skipped)

    @property
    def toc_link_text(self) -> str:
        href = f"href='{self.outputfile}'"
        titleattr = f"title=\"{self.title}\""
        diffsymbol = h.difficulty_symbol(self.difficulty)
        timevalue = ("<span class='timevalue-decoration' title='Timevalue: %s hours'>%s</span>" %
                     (self.timevalue, self.timevalue))
        refs = (self._taskrefs('assumed_by') + self._taskrefs('required_by') +
                self._taskrefs('assumes') + self._taskrefs('requires'))
        return f"<a {href} {titleattr}>{self.name}</a> {diffsymbol} {timevalue}{refs}"

    @property
    def toc(self) -> str:
        return self.taskgroup.toc

    def as_json(self) -> b.StrAnyDict:
        return dict(name=self.name, slug=self.name,  # slug for backwards compatibility, TODO 3: remove 2025-01
                    title=self.title, timevalue=self.timevalue, difficulty=self.difficulty,
                    assumes=self.assumes, requires=self.requires)

    def process_topmatter(self, sourcefile: str, topmatter: b.StrAnyDict, course: 'Coursebuilder'):
        b.copyattrs(sourcefile,
                    topmatter, self,
                    mustcopy_attrs='title, timevalue, difficulty',
                    cancopy_attrs='stage, explains, assumes, requires',
                    mustexist_attrs='',
                    typecheck=dict(timevalue=numbers.Number, difficulty=int))
        self.evaluate_stage(sourcefile, course)

        # ----- ensure explains/assumes/requires are lists:
        def _handle_strlist(attrname: str):
            attrvalue = getattr(self, attrname, None)
            if isinstance(attrvalue, str):
                setattr(self, attrname, re.split(r", *", attrvalue))
            elif not attrvalue:
                setattr(self, attrname, [])
            else:
                b.error(f"value of '{attrname}:' must be a (non-empty) string", file=sourcefile)
                setattr(self, attrname, [])

        _handle_strlist('explains')
        _handle_strlist('assumes')
        _handle_strlist('requires')
        # ----- add to glossary:
        if self.explains:
            for term in self.explains:
                course.glossary.explains(self.name, term)
        # ----- done:
        return self

    @classmethod
    def expand_diff(cls, call: macros.Macrocall) -> str:  # noqa
        assert call.macroname == "DIFF"
        level = int(call.arg1)
        diffrange = cls.DIFFICULTY_RANGE
        if level not in diffrange:
            call.error(f"Difficulty must be in range {min(diffrange)}..{max(diffrange)}")
            return ""
        return h.difficulty_symbol(level)

    def _taskrefs(self, attr_name: str) -> str:
        """Create a toc link dedoration for one set of related tasks."""
        attr_cssclass = "%s-decoration" % attr_name.replace("_", "-")
        attr_label = attr_name.replace("_", " ")
        refslist = getattr(self, attr_name)
        if len(refslist) == 0:
            return ""
        title = "%s: %s" % (attr_label, ", ".join(refslist))
        return ("<span class='%s' title='%s'>%s</span>" %
                (attr_cssclass, title, ""))  # label is provided by CSS

    def _render_task_linkslist(self, a_attr: str, r_attr: str) -> str:
        """HTML for the links to assumes/requires (or assumed_by/required_by) related tasks on a task page."""
        links = []
        a_links = sorted((f"[PARTREF::{part}]" for part in getattr(self, a_attr)))
        r_links = sorted((f"[PARTREF::{part}]" for part in getattr(self, r_attr)))
        a_cssname = a_attr.replace("_", "")
        r_cssname = r_attr.replace("_", "")
        any_links = a_links or r_links
        if any_links:
            links.append(f"\n<aside class='{a_cssname}-{r_cssname}-linkblock'>\n")
        if a_links:
            links.append(f" <div class='{a_cssname}-links'>\n   ")
            links.append("  " + macros.expand_macros("-", self.name, ", ".join(a_links)))
            links.append("\n </div>\n")
        if r_links:
            links.append(f" <div class='{r_cssname}-links'>\n")
            links.append("  " + macros.expand_macros("-", self.name, ", ".join(r_links)))
            links.append("\n </div>\n")
        if any_links:
            links.append("</aside>\n")
        return "".join(links)


class Chapterbuilder(sdrl.partbuilder.PartbuilderMixin, Chapter):
    TEMPLATENAME = "chapter.html"
    course: 'Coursebuilder'
    taskgroups: list['Taskgroupbuilder']

    @property
    def outputfile(self) -> str:
        return f"chapter-{self.name}.html"

    @property
    def sourcefile(self) -> str:
        return f"{self.course.chapterdir}/{self.name}/index.md"

    @property
    def to_be_skipped(self) -> bool:
        return self.skipthis

    @functools.cached_property
    def toc(self) -> str:
        return sdrl.partbuilder.toc(self)

    def as_json(self) -> b.StrAnyDict:
        result = dict(name=self.name, slug=self.name,  # slug for backwards compatibility, TODO 3: remove 2025-01
                      taskgroups=[taskgroup.as_json() for taskgroup in self.taskgroups])
        result.update(super().as_json())
        return result

    def process_topmatter(self, sourcefile: str, topmatter: b.StrAnyDict, course: 'Coursebuilder'):
        b.copyattrs(sourcefile,
                    topmatter, self,
                    mustcopy_attrs='title',
                    cancopy_attrs='stage',
                    mustexist_attrs='',
                    overwrite=True)
        self.evaluate_stage(sourcefile, course)

    def _init_from_dict(self, context: str, chapter: b.StrAnyDict):
        super()._init_from_dict(context, chapter)
        self.directory.record_the(Chapter, self.name, self)

    def _init_from_file(self, context: str, course: 'Coursebuilder'):
        self.make_std_dependencies(use_toc_of=self)
        self.find_zipdirs()


class Taskgroupbuilder(sdrl.partbuilder.PartbuilderMixin, Taskgroup):
    TEMPLATENAME = "taskgroup.html"
    chapter: Chapterbuilder
    tasks: list['Taskbuilder']

    @property
    def sourcefile(self) -> str:
        return f"{self.course.chapterdir}/{self.chapter.name}/{self.name}/index.md"

    @property
    def to_be_skipped(self) -> bool:
        return self.skipthis or self.chapter.to_be_skipped

    @functools.cached_property
    def toc(self) -> str:
        return sdrl.partbuilder.toc(self)

    def as_json(self) -> b.StrAnyDict:
        result = dict(name=self.name, slug=self.name,  # slug for backwards compatibility, TODO 3: remove 2025-01
                      tasks=[task.as_json() for task in self.tasks])
        result.update(super().as_json())
        return result

    def process_topmatter(self, sourcefile: str, topmatter: b.StrAnyDict, course: 'Coursebuilder'):
        b.copyattrs(sourcefile,
                    topmatter, self,
                    mustcopy_attrs='title',
                    cancopy_attrs='stage',
                    mustexist_attrs='',
                    overwrite=True)
        self.evaluate_stage(sourcefile, course)

    def _add_task(self, task: Taskbuilder):
        task.taskgroup = self
        self.tasks.append(task)

    def _create_tasks(self):
        """Finds and reads task files."""
        self.tasks = []
        filenames = glob.glob(f"{self.course.chapterdir}/{self.chapter.name}/{self.name}/*.md")
        for filename in sorted(filenames):
            if not filename.endswith("index.md"):
                name = os.path.basename(filename[:-3])  # remove .md suffix
                self._add_task(Taskbuilder(name, parent=self, taskgroup=self))

    def _init_from_dict(self, context: str, taskgroupdict: b.StrAnyDict):
        super()._init_from_dict(context, taskgroupdict)
        self.directory.record_the(Taskgroup, self.name, self)

    def _init_from_file(self, context, chapter):
        self.make_std_dependencies(use_toc_of=self)
        self.find_zipdirs()
        # ----- copy non-md files as resources:
        taskgroup_dir = f"{self.course.chapterdir}/{self.chapter.name}/{self.name}"
        for direntry in os.scandir(taskgroup_dir):
            if direntry.name.endswith('.md') or not direntry.is_file():
                continue  # we are interested in non-Markdown files only
            self.directory.make_the(el.Sourcefile, direntry.path)
            self.directory.make_the(el.CopiedFile, direntry.name,
                                    sourcefile=direntry.path,
                                    targetdir_s=self.course.targetdir_s,
                                    targetdir_i=self.course.targetdir_i)


class Coursebuilder(sdrl.partbuilder.PartbuilderMixin, Course):
    """Course with the additions required for author mode. (Chapter, Taskgroup, Task have both in one.)"""
    MUSTCOPY_ADDITIONAL = ', chapterdir, altdir, stages'
    CANCOPY_ADDITIONAL = (', baseresourcedir, itreedir, templatedir'
                          ', blockmacro_topmatter, htaccess_template, manual_bookings')
    TEMPLATENAME = "homepage.html"

    include_stage: str  # lowest stage that parts must have to be included in output
    targetdir_s: str  # where to render student output files
    targetdir_i: str  # where to render instructor output files

    baseresourcedir: str = f"{sedrila_libdir}/baseresources"
    chapterdir: str
    altdir: str
    itreedir: str | None
    templatedir: str = f"{sedrila_libdir}/templates"
    htaccess_template: str = None  # structure of .htaccess file generated in instructor website
    stages: list[str]  # list of allowed values of stage in parts

    course: 'Coursebuilder'
    chapters: list['Chapterbuilder']
    include_stage_index: int  # index in stages list, or len(stages) if include_stage is ""
    mtime: float  # in READ cache mode: tasks have changed if they are younger than this
    taskorder: list[Taskbuilder]  # If task B assumes or requires A, A will be before B in this list.
    glossary: glossary.Glossary

    def __init__(self, *, configfile: str, **kwargs):
        import datetime as dt
        self.configfile = self.context = configfile
        try:
            self.configdict = b.slurp_yaml(configfile, os.environ)
        except b.ExpansionException as exc:
            msg = f"undefined environment variables: {str(exc.missing)}"
            b.critical(msg, configfile)
        # YAML may auto-parse date strings as datetime.date; normalize to ISO strings for schema validation:
        for key in ('startdate', 'enddate'):
            if isinstance(self.configdict.get(key), dt.date):
                self.configdict[key] = self.configdict[key].isoformat()
        super().__init__(**kwargs)
        self.parttype = dict(Chapter=Chapterbuilder, Taskgroup=Taskgroupbuilder, Task=Taskbuilder)
        self._read_config(self.configdict)
        self._init_parts(self.configdict, self.include_stage)

    @property
    def breadcrumb_item(self) -> str:
        titleattr = f"title=\"{h.as_attribute(self.title)}\""
        return f"<a href='index.html' {titleattr}>{self.name}</a>"

    @property
    def has_participantslist(self) -> bool:
        return ('participants' in self.configdict and
                self.configdict['participants'].get('file', False) and
                self.configdict['participants'].get('file_column', False) and
                self.configdict['participants'].get('student_attribute', False))

    @property
    def outputfile(self) -> str:
        return "index.html"

    @property
    def sourcefile(self) -> str:
        return f"{self.chapterdir}/index.md"

    @functools.cached_property
    def toc(self) -> str:
        return sdrl.partbuilder.toc(self)

    def add_inverse_links(self):
        """add Task.required_by/Task.assumed_by lists."""
        for taskname, task in self.taskdict.items():
            task.assumed_by = []  # so we do not append to the class attribute
            task.required_by = []
        for taskname, task in self.taskdict.items():
            for assumed_taskname in task.assumes:
                assumed_task = self.task(assumed_taskname)
                if assumed_task:
                    assumed_task.assumed_by.append(taskname)
            for required_taskname in task.requires:
                required_task = self.task(required_taskname)
                if required_task:
                    required_task.required_by.append(taskname)

    def as_json(self) -> b.StrAnyDict:
        result = dict(title=self.title,
                      name=self.name, breadcrumb_title=self.name,
                      instructors=self.instructors, former_instructors=self.former_instructors,
                      student_yaml_attribute_prompts=getattr(self, 'student_yaml_attribute_prompts', dict()),
                      allowed_attempts=self.allowed_attempts,
                      startdate=str(self.startdate),
                      enddate=str(self.enddate),
                      participants=self.configdict.get('participants', None),
                      chapters=[chapter.as_json() for chapter in self.chapters])
        if self.has_participantslist:
            # hand through only the relevant part:
            result['participants'] = dict(student_attribute=self.configdict['participants']['student_attribute'])
        if self.bonusrules is not None:
            result['bonusrules'] = self.bonusrules
        if self.manual_booking_types:
            result['manual_bookings'] = self.configdict['manual_bookings']
        return result

    def check_links(self):
        """Check internal task dependencies (assumes/requires)."""
        for task in self.taskdict.values():
            for assumed in task.assumes:
                if not self.namespace.get(assumed, None):
                    b.error(f"assumed part '{assumed}' does not exist", file=task.sourcefile)
            for required in task.requires:
                if not self.namespace.get(required, None):
                    b.error(f"required part '{required}' does not exist", file=task.sourcefile)

    def compute_taskorder(self):
        """
        Set self.taskorder such that it respects the 'assumes' and 'requires'
        dependencies globally (across all taskgroups and chapters).
        The attribute will be used for ordering the tasks when rendering a taskgroup.
        """
        # ----- prepare dependency graph for topological sorting:
        graph = dict()  # maps a task to a set of tasks it depends on.
        for mytaskname, mytask in self.taskdict.items():
            dependencies = set()  # collection of all tasks required or assumed by mytask
            for assumedtask in mytask.assumes:
                if assumedtask in self.taskdict:
                    dependencies.add(self.taskdict[assumedtask])
            for requiredtask in mytask.requires:
                if requiredtask in self.taskdict:
                    dependencies.add(self.taskdict[requiredtask])
            graph[mytask] = dependencies
        # ----- compute taskorder (or report dependency cycle if one is found):
        self.taskorder = self._taskordering_for_toc(graph)

    def _add_baseresources(self):
        for direntry in os.scandir(self.baseresourcedir):
            if direntry.is_file():
                self.directory.make_the(el.Sourcefile, direntry.path)
                self.directory.make_the(el.CopiedFile, direntry.name, sourcefile=direntry.path,
                                        targetdir_s=self.targetdir_s, targetdir_i=self.targetdir_i)
            else:
                b.warning("is not a plain file. Ignored.", file=direntry)

    def _add_participantslist(self):
        if not self.has_participantslist:
            return  # nothing to do
        inputfile = self.configdict['participants']['file']
        keyfingerprints = [instructor['keyfingerprint']
                           for instructor in self.configdict['instructors']
                           if instructor.get('keyfingerprint', None)]
        if not inputfile:  # empty filename deactivates the participants functionality
            return
        if not os.path.exists(inputfile):
            b.critical(f"participants.file '{inputfile}' does not exist.", file=self.configfile)
        self.directory.make_the(el.Sourcefile, inputfile)
        self.directory.make_the(el.ParticipantsList, c.PARTICIPANTSLIST_FILE,
                                sourcefile=inputfile,
                                targetdir_s=self.targetdir_s, targetdir_i=self.targetdir_i,
                                transformation=self._transform_participantslist,
                                file_column=self.configdict['participants']['file_column'],
                                fingerprints=keyfingerprints)

    def _collect_zipdirs(self):
        for zf in self.directory.get_all(el.Zipfile):
            self.namespace_add(zf)

    @staticmethod
    def _transform_participantslist(elem: el.TransformedFile):
        with open(elem.sourcefile, newline='') as tsvfile:
            tsvreader = csv.DictReader(tsvfile, delimiter='\t')  # read tab-separated values
            participants = [entry[elem.file_column] for entry in tsvreader]
        participantslist = ("\n".join(participants)).encode('utf-8')
        encryptedlist = mycrypt.encrypt_gpg(participantslist, elem.fingerprints)
        b.spit_bytes(elem.outputfile_s, encryptedlist)
        b.spit_bytes(elem.outputfile_i, encryptedlist)

    def _prescan_prot_files(self):
        """Scan all Markdown files for [PROT::...] macros and pre-register ProtFiles."""
        import re
        prot_pattern = re.compile(r'\[PROT::([^\]]+)\]')
        keyfingerprints = [instructor['keyfingerprint']
                           for instructor in self.configdict.get('instructors', [])
                           if instructor.get('keyfingerprint', None) and instructor.get('pubkey', None)]
        if not keyfingerprints:
            return
        for root, dirs, files in os.walk(self.chapterdir):
            for filename in files:
                if not filename.endswith('.md'):
                    continue
                filepath = os.path.join(root, filename)
                try:
                    content = b.slurp(filepath)
                    for match in prot_pattern.finditer(content):
                        prot_arg = match.group(1)
                        resolved_path = self._resolve_prot_path(filepath, prot_arg)
                        if resolved_path and os.path.exists(resolved_path):
                            self._register_encrypted_prot_directly(resolved_path, keyfingerprints)
                except Exception:
                    pass

    def _read_config(self, configdict: b.StrAnyDict):
        schema_text = importlib.resources.files("sdrl.schema").joinpath("sedrila-yaml.schema.json").read_text()
        schema = json.loads(schema_text)
        validator = jsonschema.Draft202012Validator(schema)
        errors = sorted(validator.iter_errors(configdict), key=lambda e: e.json_path)
        if errors:
            b.error(f"Configuration file '{self.configfile}' is invalid. It has the following errors:")
            for err in errors:
                location = err.json_path if err.json_path != '$' else '(top level)'
                b.error(f"{location}: {err.message}")
            b.critical(f"{len(errors)} schema error(s).")
        super()._read_config(configdict)

    def _resolve_prot_path(self, context_file: str, prot_arg: str) -> str | None:
        """Resolve a [PROT::...] argument to an actual file path."""
        import re
        # Match: (ALT:)? (/)? (incfile)
        arg_re = r"(?P<kw>ALT:)?(?P<slash>/)?(?P<incfile>.*)"
        mm = re.fullmatch(arg_re, prot_arg)
        has_kw = mm.group("kw") is not None
        is_abs = mm.group("slash") is not None
        inc_filepath = mm.group("incfile")
        if has_kw:
            basedir = self.altdir
        else:
            basedir = self.chapterdir
        # Get context directory, converting between chapterdir/altdir if needed
        ctx_dirpath = os.path.dirname(context_file)
        if has_kw:
            rel_dirpath = ctx_dirpath.replace(self.chapterdir, self.altdir, 1)
        else:
            rel_dirpath = ctx_dirpath
        # Construct full path: either from root or from context directory
        if is_abs:
            fullpath = os.path.join(basedir, inc_filepath)
        else:
            fullpath = os.path.join(rel_dirpath, inc_filepath or os.path.basename(context_file).replace('.md', '.prot'))
        return fullpath

    def _register_encrypted_prot_directly(self, prot_filepath: str, keyfingerprints: list[str]):
        """Register a .prot file for encryption before directory.build()."""
        basename = os.path.basename(prot_filepath)
        outputname = f"{basename}.crypt"
        existing = self.directory.get_the(el.ProtFile, outputname)
        if existing:
            return
        self.directory.make_the(el.Sourcefile, prot_filepath)
        pubkey_data = self.instructor_pubkeys
        course = self
        def transform_with_pubkeys(elem):
            return Coursebuilder._transform_prot_file(elem, pubkey_data, course)
        self.directory.make_the(
            el.ProtFile,
            outputname,
            sourcefile=prot_filepath,
            targetdir_s=self.targetdir_s,
            targetdir_i=self.targetdir_i,
            transformation=transform_with_pubkeys,
            fingerprints=keyfingerprints
        )

    @staticmethod
    def _transform_prot_file(elem: el.TransformedFile, pubkey_data: dict | None = None,
                             course: 'Coursebuilder | None' = None):
        """Validate @PROT_SPEC annotations in .prot file, then encrypt it."""
        # Validate protocol annotations
        import sdrl.protocolchecker as protocolchecker
        validator = protocolchecker.ProtocolValidator()
        errors = validator.validate_file(elem.sourcefile)
        # Determine report level: error for tasks in stage filter, warning for excluded tasks
        report = b.error
        if course:
            prot_basename = os.path.splitext(os.path.basename(elem.sourcefile))[0]
            task = course.directory.get_the(Task, prot_basename)
            if task and getattr(task, 'skipthis', False):
                report = b.warning
        for error in errors:
            report(error, file=elem.sourcefile)

        # Encrypt the file
        with open(elem.sourcefile, 'rb') as f:
            plaintext = f.read()
        encrypted = mycrypt.encrypt_gpg(plaintext, elem.fingerprints, pubkey_data=pubkey_data)
        b.spit_bytes(elem.outputfile_s, encrypted)

    def _prepare_instructor_pubkeys(self):
        """Prepare instructor public keys from sedrila.yaml for encryption."""
        pubkey_data = {}
        for instructor in self.configdict.get('instructors', []):
            if 'pubkey' in instructor and 'keyfingerprint' in instructor:
                fp = instructor['keyfingerprint']
                pubkey_data[fp] = instructor['pubkey']
        return pubkey_data

    def _init_parts(self, configdict: dict, include_stage: str):
        self.directory.record_the(Course, self.name, self)
        self.namespace_add(self)
        self.make_std_dependencies(use_toc_of=self)
        # ----- prepare instructor pubkeys from sedrila.yaml (for isolated encryption):
        self.instructor_pubkeys = self._prepare_instructor_pubkeys()
        # ----- pre-register encrypted prot files:
        self._prescan_prot_files()
        # ----- handle include_stage:
        if include_stage in self.stages:
            self.include_stage = include_stage
            self.include_stage_index = self.stages.index(include_stage)
        else:
            if include_stage != '':  # empty is allowed
                b.error(f"'--include_stage {include_stage}' not allowed, must be one of {self.stages}")
            self.include_stage = ''  # include only parts with no stage
            self.include_stage_index = len(self.stages)
        # ----- create Chapters, Taskgroups, Tasks:
        self.chapters = [Chapterbuilder(ch['name'], parent=self, chapterdict=ch)
                         for ch in configdict['chapters']]
        # ----- create Zipdirs, Glossary:
        self.find_zipdirs()
        self._collect_zipdirs()  # TODO 3: collect only what gets referenced
        self.glossary = glossary.Glossary(c.AUTHOR_GLOSSARY_BASENAME, parent=self)
        self.directory.record_the(glossary.Glossary, self.glossary.name, self.glossary)
        self.namespace_add(self.glossary)
        # ----- create MetadataDerivation, validations, baseresources, participants list:
        self.directory.make_the(MetadataDerivation, self.name, part=self, course=self)
        self._add_baseresources()
        self._add_participantslist()

    @staticmethod
    def _taskordering_for_toc(graph) -> list[Taskbuilder]:
        sorter = graphlib.TopologicalSorter(graph)
        sorter.prepare()
        result = []
        try:
            while sorter.is_active():
                node_group = sorted(sorter.get_ready())
                result.extend(node_group)
                sorter.done(*node_group)
        except graphlib.CycleError as exc:
            msg = "Some tasks' 'assumes' or 'requires' dependencies form a cycle:\n"
            b.critical(msg + exc.args[1])
        return result


class MetadataDerivation(el.Step):
    """Copy Topmatter into Parts' attributes, compute assumedby/requiredby/taskorder, check links."""
    course: Coursebuilder

    def do_build(self):
        # ----- copy topmatter into Parts' attributes:
        dir = self.directory
        allparts = list(itertools.chain(dir.get_all(Chapter), dir.get_all(Taskgroup), dir.get_all(Task)))
        for part in allparts:
            topmatter = self.directory.get_the(el.Topmatter, part.name)
            part.process_topmatter(part.sourcefile, topmatter.value, self.course)
            part.evaluate_stage(part.sourcefile, part.course)
        # ----- compute and check stuff:
        self.course.add_inverse_links()
        self.course.compute_taskorder()
        self.course.check_links()
        import sdrl.programchecker as programchecker
        programchecker.check_test_spec_dependency_gaps(self.course)
