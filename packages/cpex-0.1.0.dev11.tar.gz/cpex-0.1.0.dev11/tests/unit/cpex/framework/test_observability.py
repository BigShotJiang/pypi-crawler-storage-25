# -*- coding: utf-8 -*-
"""Location: ./tests/unit/cpex/framework/test_observability.py
Copyright 2025
SPDX-License-Identifier: Apache-2.0
Authors: Fred Araujo

Tests for observability dependency injection in the plugin framework.
Verifies that a mock ObservabilityProvider can be injected into PluginManager
and that start_span/end_span are called during plugin execution.
"""

# Standard
from typing import Any, Dict, List, Optional, Tuple
from unittest.mock import patch

# Third-Party
import pytest

# First-Party
from cpex.framework import (
    GlobalContext,
    Plugin,
    PluginConfig,
    PluginManager,
    PluginResult,
    PromptHookType,
    PromptPrehookPayload,
)
from cpex.framework.base import HookRef
from cpex.framework.manager import PluginExecutor
from cpex.framework.observability import NullObservability, current_trace_id
from cpex.framework.registry import PluginRef


class RecordingObservability:
    """Mock observability provider that records all calls for assertions."""

    def __init__(self):
        self.spans: List[Tuple[str, dict]] = []
        self.ended_spans: List[Tuple[Optional[str], str, Optional[Dict[str, Any]]]] = []

    def start_span(
        self,
        trace_id: str,
        name: str,
        kind: str = "internal",
        resource_type: Optional[str] = None,
        resource_name: Optional[str] = None,
        attributes: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        span_id = f"span-{len(self.spans)}"
        self.spans.append(
            (
                span_id,
                {
                    "trace_id": trace_id,
                    "name": name,
                    "kind": kind,
                    "resource_type": resource_type,
                    "resource_name": resource_name,
                    "attributes": attributes,
                },
            )
        )
        return span_id

    def end_span(
        self,
        span_id: Optional[str],
        status: str = "ok",
        attributes: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.ended_spans.append((span_id, status, attributes))


class SimplePlugin(Plugin):
    """A minimal plugin that modifies the payload."""

    async def prompt_pre_fetch(self, payload, context):
        payload.args["traced"] = "yes"
        return PluginResult(continue_processing=True, modified_payload=payload)


class BlockingPlugin(Plugin):
    """A plugin that blocks the pipeline with a violation."""

    async def prompt_pre_fetch(self, payload, context):
        from cpex.framework.models import PluginViolation

        return PluginResult(
            continue_processing=False,
            violation=PluginViolation(code="BLOCKED", reason="test block", description="blocked for testing"),
        )


@pytest.mark.asyncio
async def test_observability_injection_via_plugin_manager():
    """Test that an ObservabilityProvider injected into PluginManager is invoked during hook execution."""
    recorder = RecordingObservability()
    trace_id = "test-trace-001"

    manager = PluginManager(
        "./tests/unit/cpex/fixtures/configs/valid_no_plugin.yaml",
        observability=recorder,
    )
    await manager.initialize()

    config = PluginConfig(
        name="TracedPlugin",
        description="Plugin for observability test",
        author="Test",
        version="1.0",
        tags=["test"],
        kind="TracedPlugin",
        hooks=["prompt_pre_fetch"],
        config={},
    )
    plugin = SimplePlugin(config)

    token = current_trace_id.set(trace_id)
    try:
        with patch.object(manager._registry, "get_hook_refs_for_hook") as mock_get:
            hook_ref = HookRef(PromptHookType.PROMPT_PRE_FETCH, PluginRef(plugin))
            mock_get.return_value = [hook_ref]

            payload = PromptPrehookPayload(prompt_id="test", args={})
            global_context = GlobalContext(request_id="req-1")

            result, _ = await manager.invoke_hook(
                PromptHookType.PROMPT_PRE_FETCH,
                payload,
                global_context=global_context,
            )

        assert result.continue_processing
        assert result.modified_payload is not None
        assert result.modified_payload.args["traced"] == "yes"

        # Verify start_span was called: hook-chain span + per-plugin span
        assert len(recorder.spans) == 2

        # First span: hook-chain span
        chain_span_id, chain_info = recorder.spans[0]
        assert chain_info["trace_id"] == trace_id
        assert chain_info["name"] == "plugin.hook.invoke"
        assert chain_info["kind"] == "internal"
        assert chain_info["attributes"]["plugin.hook.type"] == PromptHookType.PROMPT_PRE_FETCH
        assert chain_info["attributes"]["plugin.chain.length"] == 1

        # Second span: per-plugin execution span
        plugin_span_id, plugin_info = recorder.spans[1]
        assert plugin_info["trace_id"] == trace_id
        assert "TracedPlugin" in plugin_info["name"]
        assert plugin_info["kind"] == "internal"
        assert plugin_info["resource_type"] == "plugin"
        assert plugin_info["resource_name"] == "TracedPlugin"
        assert plugin_info["attributes"]["plugin.name"] == "TracedPlugin"

        # Verify end_span was called for both spans
        assert len(recorder.ended_spans) == 2

        # Per-plugin span ended first
        ended_plugin_id, plugin_status, plugin_end_attrs = recorder.ended_spans[0]
        assert ended_plugin_id == plugin_span_id
        assert plugin_status == "ok"
        assert plugin_end_attrs["plugin.had_violation"] is False
        assert plugin_end_attrs["plugin.modified_payload"] is True

        # Hook-chain span ended second
        ended_chain_id, chain_status, chain_end_attrs = recorder.ended_spans[1]
        assert ended_chain_id == chain_span_id
        assert chain_status == "ok"
        assert chain_end_attrs["plugin.executed_count"] == 1
        assert chain_end_attrs["plugin.skipped_count"] == 0
        assert chain_end_attrs["plugin.chain.stopped"] is False
    finally:
        current_trace_id.reset(token)
        await manager.shutdown()


@pytest.mark.asyncio
async def test_no_tracing_without_trace_id():
    """Test that observability is not invoked when no trace_id is set."""
    recorder = RecordingObservability()

    manager = PluginManager(
        "./tests/unit/cpex/fixtures/configs/valid_no_plugin.yaml",
        observability=recorder,
    )
    await manager.initialize()

    config = PluginConfig(
        name="UntracedPlugin",
        description="Plugin without trace",
        author="Test",
        version="1.0",
        tags=["test"],
        kind="UntracedPlugin",
        hooks=["prompt_pre_fetch"],
        config={},
    )
    plugin = SimplePlugin(config)

    # Do NOT set current_trace_id — it should default to None
    with patch.object(manager._registry, "get_hook_refs_for_hook") as mock_get:
        hook_ref = HookRef(PromptHookType.PROMPT_PRE_FETCH, PluginRef(plugin))
        mock_get.return_value = [hook_ref]

        payload = PromptPrehookPayload(prompt_id="test", args={})
        global_context = GlobalContext(request_id="req-2")

        result, _ = await manager.invoke_hook(
            PromptHookType.PROMPT_PRE_FETCH,
            payload,
            global_context=global_context,
        )

    assert result.continue_processing
    # No spans should have been created
    assert len(recorder.spans) == 0
    assert len(recorder.ended_spans) == 0

    await manager.shutdown()


@pytest.mark.asyncio
async def test_no_tracing_without_provider():
    """Test that plugin execution works when no observability provider is injected."""
    manager = PluginManager(
        "./tests/unit/cpex/fixtures/configs/valid_no_plugin.yaml",
        observability=None,
    )
    await manager.initialize()

    config = PluginConfig(
        name="NoProviderPlugin",
        description="Plugin without observability",
        author="Test",
        version="1.0",
        tags=["test"],
        kind="NoProviderPlugin",
        hooks=["prompt_pre_fetch"],
        config={},
    )
    plugin = SimplePlugin(config)

    token = current_trace_id.set("trace-no-provider")
    try:
        with patch.object(manager._registry, "get_hook_refs_for_hook") as mock_get:
            hook_ref = HookRef(PromptHookType.PROMPT_PRE_FETCH, PluginRef(plugin))
            mock_get.return_value = [hook_ref]

            payload = PromptPrehookPayload(prompt_id="test", args={})
            global_context = GlobalContext(request_id="req-3")

            result, _ = await manager.invoke_hook(
                PromptHookType.PROMPT_PRE_FETCH,
                payload,
                global_context=global_context,
            )

        # Plugin should still execute normally
        assert result.continue_processing
        assert result.modified_payload is not None
        assert result.modified_payload.args["traced"] == "yes"
    finally:
        current_trace_id.reset(token)
        await manager.shutdown()


@pytest.mark.asyncio
async def test_null_observability_default():
    """Test NullObservability no-op implementation."""
    null_obs = NullObservability()

    # start_span returns None
    span_id = null_obs.start_span(trace_id="t1", name="test_span")
    assert span_id is None

    # end_span does nothing (no error)
    null_obs.end_span(span_id=None, status="ok")
    null_obs.end_span(span_id="some-span", status="error", attributes={"key": "val"})


@pytest.mark.asyncio
async def test_executor_observability_injection():
    """Test that PluginExecutor correctly receives and uses an observability provider."""
    recorder = RecordingObservability()
    executor = PluginExecutor(observability=recorder)

    assert executor.observability is recorder

    # Also verify default is None
    default_executor = PluginExecutor()
    assert default_executor.observability is None


def test_protocol_method_bodies():
    """Verify that calling Protocol method stubs directly returns None."""
    # First-Party
    from cpex.framework.observability import ObservabilityProvider

    # Call the unbound protocol methods directly to exercise the `...` bodies
    result1 = ObservabilityProvider.start_span(None, trace_id="t", name="n")
    assert result1 is None

    result2 = ObservabilityProvider.end_span(None, span_id=None)
    assert result2 is None


def test_get_plugin_manager_creates_manager_when_enabled():
    """Test that get_plugin_manager creates a PluginManager when plugins_enabled is True."""
    # First-Party
    import cpex.framework as fw

    recorder = RecordingObservability()

    # Reset the module-level singleton
    original = fw._plugin_manager
    fw._plugin_manager = None
    try:
        with patch("cpex.framework.settings.settings") as mock_settings:
            mock_settings.enabled = True
            mock_settings.config_file = "./tests/unit/cpex/fixtures/configs/valid_no_plugin.yaml"
            pm = fw.get_plugin_manager(observability=recorder)

        assert pm is not None
        assert isinstance(pm, PluginManager)
    finally:
        fw._plugin_manager = original
        PluginManager.reset()


@pytest.mark.asyncio
async def test_hook_chain_span_records_stopped_by_on_halt():
    """Test that hook-chain span records stopped_by when pipeline is halted."""
    recorder = RecordingObservability()
    trace_id = "test-trace-halt"

    manager = PluginManager(
        "./tests/unit/cpex/fixtures/configs/valid_no_plugin.yaml",
        observability=recorder,
    )
    await manager.initialize()

    config = PluginConfig(
        name="BlockingPlugin",
        description="Blocks the pipeline",
        author="Test",
        version="1.0",
        tags=["test"],
        kind="BlockingPlugin",
        hooks=["prompt_pre_fetch"],
        config={},
    )
    plugin = BlockingPlugin(config)

    token = current_trace_id.set(trace_id)
    try:
        with patch.object(manager._registry, "get_hook_refs_for_hook") as mock_get:
            hook_ref = HookRef(PromptHookType.PROMPT_PRE_FETCH, PluginRef(plugin))
            mock_get.return_value = [hook_ref]

            payload = PromptPrehookPayload(prompt_id="test", args={})
            global_context = GlobalContext(request_id="req-halt")

            result, _ = await manager.invoke_hook(
                PromptHookType.PROMPT_PRE_FETCH,
                payload,
                global_context=global_context,
            )

        assert not result.continue_processing
        assert result.violation is not None

        # Verify hook-chain span records the halt
        assert len(recorder.ended_spans) == 2  # per-plugin + hook-chain

        # Hook-chain span is the last ended span
        ended_chain_id, chain_status, chain_end_attrs = recorder.ended_spans[-1]
        assert chain_status == "ok"
        assert chain_end_attrs["plugin.chain.stopped"] is True
        assert chain_end_attrs["plugin.chain.stopped_by"] == "BlockingPlugin"
        assert chain_end_attrs["plugin.executed_count"] == 1
        assert chain_end_attrs["plugin.skipped_count"] == 0
    finally:
        current_trace_id.reset(token)
        await manager.shutdown()
