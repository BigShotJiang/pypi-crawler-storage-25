# -*- coding: utf-8 -*-
"""Location: ./cpex/tools/cli.py
Copyright 2025
SPDX-License-Identifier: Apache-2.0
Authors: Fred Araujo

mcpplugins CLI ─ command line tools for authoring and packaging plugins
This module is exposed as a **console-script** via:

    [project.scripts]
    mcpplugins = "cpex.tools.cli:main"

so that a user can simply type `mcpplugins ...` to use the CLI.

Features
─────────
* bootstrap: Creates a new plugin project from template                                                           │
* install: Installs plugins into a Python environment                                                           │
* package: Builds an MCP server to serve plugins as tools

Typical usage
─────────────
```console
$ mcpplugins --help
```
"""

# Standard
import logging
import shutil
import subprocess  # nosec B404 # Safe: Used only for git commands with hardcoded args
from pathlib import Path

# Third-Party
import typer
from typing_extensions import Annotated

# First-Party
from cpex.framework.settings import settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration defaults
# ---------------------------------------------------------------------------
LOCAL_TEMPLATES_DIR = Path(__file__).resolve().parent.parent / "templates"
DEFAULT_TEMPLATE_URL = "https://github.com/contextforge-org/contextforge-plugins-framework.git"
DEFAULT_AUTHOR_NAME = "<changeme>"
DEFAULT_AUTHOR_EMAIL = "<changeme>"
DEFAULT_PROJECT_DIR = Path("./.")
DEFAULT_INSTALL_MANIFEST = Path("plugins/install.yaml")
DEFAULT_IMAGE_TAG = "contextforge-plugin:latest"  # TBD: add plugin name and version
DEFAULT_IMAGE_BUILDER = "docker"
DEFAULT_BUILD_CONTEXT = "."
DEFAULT_CONTAINERFILE_PATH = Path("docker/Dockerfile")
DEFAULT_VCS_REF = "main"
DEFAULT_INSTALLER = "uv pip install"

# ---------------------------------------------------------------------------
# CLI (overridable via environment variables)
# ---------------------------------------------------------------------------

markup_mode = settings.cli_markup_mode or typer.core.DEFAULT_MARKUP_MODE
app = typer.Typer(
    help="Command line tools for authoring and packaging plugins.",
    add_completion=settings.cli_completion,
    rich_markup_mode=None if markup_mode == "disabled" else markup_mode,
)

# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------


def command_exists(command_name: str) -> bool:
    """Check if a given command-line utility exists and is executable.

    Args:
        command_name: The name of the command to check (e.g., "ls", "git").

    Returns:
        True if the command exists and is executable, False otherwise.
    """
    return shutil.which(command_name) is not None


def git_user_name() -> str:
    """Return the current git user name from the environment.

    Returns:
        The git user name configured in the user's environment.

    Examples:
        >>> user_name = git_user_name()
        >>> isinstance(user_name, str)
        True
    """
    try:
        res = subprocess.run(["git", "config", "user.name"], stdout=subprocess.PIPE, check=False)  # nosec B607 B603 # Safe: hardcoded git command
        return res.stdout.strip().decode() if not res.returncode else DEFAULT_AUTHOR_NAME
    except Exception:
        return DEFAULT_AUTHOR_NAME


def git_user_email() -> str:
    """Return the current git user email from the environment.

    Returns:
        The git user email configured in the user's environment.

    Examples:
        >>> user_name = git_user_email()
        >>> isinstance(user_name, str)
        True
    """
    try:
        res = subprocess.run(["git", "config", "user.email"], stdout=subprocess.PIPE, check=False)  # nosec B607 B603 # Safe: hardcoded git command
        return res.stdout.strip().decode() if not res.returncode else DEFAULT_AUTHOR_EMAIL
    except Exception:
        return DEFAULT_AUTHOR_EMAIL


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------
@app.command(help="Creates a new plugin project from template.")
def bootstrap(
    destination: Annotated[
        Path, typer.Option("--destination", "-d", help="The directory in which to bootstrap the plugin project.")
    ] = DEFAULT_PROJECT_DIR,
    template_url: Annotated[
        str,
        typer.Option(
            "--template_url",
            "-u",
            help="The URL to the plugins cookiecutter template. Overrides local templates when provided.",
        ),
    ] = None,
    template_type: Annotated[
        str, typer.Option("--template_type", "-t", help="Plugin template type: native or external.")
    ] = "native",
    vcs_ref: Annotated[
        str,
        typer.Option("--vcs_ref", "-r", help="The version control system tag/branch/commit to use for the template."),
    ] = DEFAULT_VCS_REF,
    no_input: Annotated[bool, typer.Option("--no_input", help="Use defaults without prompting.")] = False,
    dry_run: Annotated[bool, typer.Option("--dry_run", help="Run but do not make any changes.")] = False,
) -> None:
    """Boostrap a new plugin project from a template.

    Args:
        destination: The directory in which to bootstrap the plugin project.
        template_url: The URL to the plugins cookiecutter template.
        template_type: Plugin template type (native or external).
        vcs_ref: The version control system tag/branch/commit to use for the template.
        no_input: Use defaults without prompting.
        dry_run: Run but do not make any changes.

    Raises:
        Exit: If cookiecutter is not installed.
    """
    try:
        # Third-Party
        from cookiecutter.main import cookiecutter  # pylint: disable=import-outside-toplevel
    except ImportError:
        logger.error("cookiecutter is not installed. Install with: pip install mcp-contextforge-gateway[templating]")
        raise typer.Exit(1)

    if dry_run:
        source = template_url if template_url is not None else str(LOCAL_TEMPLATES_DIR / template_type)
        logger.info(
            "Dry run: would create plugin project at %s from template %s (type=%s)",
            destination,
            source,
            template_type,
        )
        return

    try:
        output_dir = str(destination.parent) if destination.parent != destination else "."
        extra_context = {
            "plugin_slug": destination.name,
            "author": git_user_name(),
            "email": git_user_email(),
        }

        # Explicit URL overrides local templates; otherwise prefer local
        local_template_dir = LOCAL_TEMPLATES_DIR / template_type
        use_remote = template_url is not None

        if use_remote:
            if not command_exists("git"):
                logger.error("git is required to fetch remote templates but was not found.")
                raise typer.Exit(1)
            cookiecutter(
                template=template_url,
                checkout=vcs_ref,
                directory=f"cpex/templates/{template_type}",
                output_dir=output_dir,
                no_input=no_input,
                extra_context=extra_context,
            )
        elif local_template_dir.is_dir():
            cookiecutter(
                template=str(local_template_dir),
                output_dir=output_dir,
                no_input=no_input,
                extra_context=extra_context,
            )
        elif command_exists("git"):
            cookiecutter(
                template=DEFAULT_TEMPLATE_URL,
                checkout=vcs_ref,
                directory=f"cpex/templates/{template_type}",
                output_dir=output_dir,
                no_input=no_input,
                extra_context=extra_context,
            )
        else:
            logger.warning("No local templates found and git is not available to fetch remote template.")
    except (SystemExit, typer.Exit):
        raise
    except Exception:
        logger.exception("An error was caught while copying template.")


@app.callback()
def callback() -> None:  # pragma: no cover
    """This function exists to force 'bootstrap' to be a subcommand."""


# @app.command(help="Installs plugins into a Python environment.")
# def install(
#     install_manifest: Annotated[typer.FileText, typer.Option("--install_manifest", "-i", help="The install manifest describing which plugins to install.")] = DEFAULT_INSTALL_MANIFEST,
#     installer: Annotated[str, typer.Option("--installer", "-c", help="The install command to install plugins.")] = DEFAULT_INSTALLER,
# ):
#     typer.echo(f"Installing plugin packages from {install_manifest.name}")
#     data = yaml.safe_load(install_manifest)
#     manifest = InstallManifest.model_validate(data)
#     for pkg in manifest.packages:
#         typer.echo(f"Installing plugin package {pkg.package} from {pkg.repository}")
#         repository = os.path.expandvars(pkg.repository)
#         cmd = installer.split(" ")
#         if pkg.extras:
#             cmd.append(f"{pkg.package}[{','.join(pkg.extras)}]@{repository}")
#         else:
#             cmd.append(f"{pkg.package}@{repository}")
#         subprocess.run(cmd)


# @app.command(help="Builds an MCP server to serve plugins as tools.")
# def package(
#     image_tag: Annotated[str, typer.Option("--image_tag", "-t", help="The container image tag to generated container.")] = DEFAULT_IMAGE_TAG,
#     containerfile: Annotated[Path, typer.Option("--containerfile", "-c", help="The Dockerfile used to build the container.")] = DEFAULT_CONTAINERFILE_PATH,
#     builder: Annotated[str, typer.Option("--builder", "-b", help="The container builder, compatible with docker build.")] = DEFAULT_IMAGE_BUILDER,
#     build_context: Annotated[Path, typer.Option("--build_context", "-p", help="The container builder context, specified as a path.")] = DEFAULT_BUILD_CONTEXT,
# ):
#     typer.echo("Building MCP server image")
#     cmd = builder.split(" ")
#     cmd.extend(["-f", containerfile, "-t", image_tag, build_context])
#     subprocess.run(cmd)


def main() -> None:  # noqa: D401 - imperative mood is fine here
    """Entry point for the *mcpplugins* console script.

    Processes command line arguments, handles version requests, and forwards
    all other arguments to Uvicorn with sensible defaults injected.

    Environment Variables:
        PLUGINS_CLI_COMPLETION: Enable auto-completion for plugins CLI (default: false)
        PLUGINS_CLI_MARKUP_MODE: Set markup mode for plugins CLI (default: rich)
            Valid options:
                rich: use rich markup
                markdown: allow markdown in help strings
                disabled: disable markup
            If unset (commented out), uses "rich" if rich is detected, otherwise disables it.
    """
    app()


if __name__ == "__main__":  # pragma: no cover - executed only when run directly
    main()
