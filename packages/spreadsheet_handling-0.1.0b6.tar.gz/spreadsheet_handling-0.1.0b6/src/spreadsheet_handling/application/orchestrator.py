from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, Mapping

import logging

from ..io_backends.router import get_loader, get_saver
from ..pipeline.execution import run_pipeline
from ..pipeline.types import BoundStep, Frames

log = logging.getLogger("sheets.orchestrator")


# ---------------------------
# Small typed config holders
# ---------------------------

@dataclass(frozen=True)
class IODesc:
    kind: str
    path: str
    options: Dict[str, Any] | None = None


def _coerce_io(d: Mapping[str, Any] | None, role: str) -> IODesc:
    if not d:
        raise ValueError(f"Missing '{role}' I/O descriptor")
    kind = str(d.get("kind") or "").strip().lower()
    path = str(d.get("path") or "").strip()
    opts = dict(d.get("options") or {})
    if not kind or not path:
        raise ValueError(f"Invalid '{role}' I/O descriptor: need 'kind' and 'path'")
    return IODesc(kind=kind, path=path, options=opts or None)


# ---------------------------
# Backend routing
# ---------------------------

def _load_frames(inp: IODesc, *, header_levels: int = 1) -> Frames:
    try:
        loader = get_loader(inp.kind)
    except ValueError as exc:
        raise ValueError(f"Unsupported input kind: {inp.kind!r}") from exc
    return loader(inp.path, options=inp.options, header_levels=header_levels)

def _save_frames(out: IODesc, frames: Frames) -> None:
    try:
        saver = get_saver(out.kind)
    except ValueError as exc:
        raise ValueError(f"Unsupported output kind: {out.kind!r}") from exc
    saver(frames, out.path, options=out.options)


# ---------------------------
# Public API
# ---------------------------

def orchestrate(
    *,
    input: Mapping[str, Any],
    output: Mapping[str, Any],
    steps: Iterable[BoundStep] | None = None,
    header_levels: int = 1,
) -> Frames:
    """
    Unified execution engine for sheets-run and reference shortcut commands.

    - Loads frames from 'input' backend (csv_dir | json_dir | yaml_dir | xml_dir | xlsx | ods | calc).
    - Runs the given 'steps' (pure Frames→Frames, optional).
    - Writes frames to 'output' backend.
    - Returns the final frames for in-process reuse/testing.

    Parameters
    ----------
    input : Mapping[str, Any]
        { kind: "csv_dir"|"json_dir"|"yaml_dir"|"xml_dir"|"xlsx"|"ods"|"calc", path: str, options?: {...} }
    output : Mapping[str, Any]
        { kind: "csv_dir"|"json_dir"|"yaml_dir"|"xml_dir"|"xlsx"|"ods"|"calc", path: str, options?: {...} }
    steps : Iterable[BoundStep] | None
        List of bound steps (use factories from pipeline to build them).
    header_levels : int
        Desired header levels on read; 1 by default.

    Raises
    ------
    ValueError for invalid I/O descriptors or unknown kinds.
    """
    inp = _coerce_io(input, "input")
    out = _coerce_io(output, "output")

    log.info("orchestrate: loading input kind=%s path=%s", inp.kind, inp.path)
    frames = _load_frames(inp, header_levels=header_levels)

    if steps:
        step_list = list(steps)
        log.info("orchestrate: running %d step(s)", len(step_list))
        frames = run_pipeline(frames, step_list)

    log.info("orchestrate: writing output kind=%s path=%s", out.kind, out.path)
    _save_frames(out, frames)
    return frames
