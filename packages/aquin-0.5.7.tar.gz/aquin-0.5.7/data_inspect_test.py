"""
On-prem dataset inspection test using aquin.inspect_data().

Usage:
    pip install --upgrade aquin==0.5.3
    python data_inspect_test.py --api-key aq-xxxx

What it does:
    1. Loads dataset.jsonl from the same directory as this script
    2. Calls aquin.inspect_data() — streams session ID to dashboard
    3. Runs locally: PII scan · toxicity · bias surface · synthetic detection
    4. Builds audit trail (SHA-256 hash, timestamp, liability chain)
    5. Generates compliance report combining all checks
    6. All results stream to dashboard live as each check finishes

Open dashboard → dataset tab → SDK → enter your API key → Connect
then run this script.
"""

import argparse
import os

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

parser = argparse.ArgumentParser()
parser.add_argument("--api-key",  required=True, help="Your Aquin API key (aq-xxx)")
parser.add_argument("--dataset",  default=None, help="Path to dataset file (.jsonl, .csv, .tsv, .json) — defaults to dataset.jsonl next to this script")
parser.add_argument("--text-cols", default=None, help="Comma-separated column names to inspect (auto-detected if omitted)")
args = parser.parse_args()

dataset_path = args.dataset or os.path.join(_SCRIPT_DIR, "dataset.jsonl")

if not os.path.exists(dataset_path):
    raise FileNotFoundError(
        f"Dataset not found: {dataset_path}\n"
        "Place a dataset.jsonl file next to this script, or pass --dataset <path>."
    )

text_columns = [c.strip() for c in args.text_cols.split(",")] if args.text_cols else None

print(f"[data_inspect] Dataset: {dataset_path}")
print(f"[data_inspect] Text columns: {text_columns or '(auto-detect)'}")
print()
print(f"[data_inspect] Open dashboard → dataset tab → SDK → enter your API key → Connect")
print(f"[data_inspect] Then results will stream live as each check finishes")
print()

import aquin

session = aquin.inspect_data(
    dataset_path,
    api_key=args.api_key,
    text_columns=text_columns,
)

session.run()

print()
print(f"[data_inspect] Done. Check the dataset tab in your Aquin dashboard for full results.")