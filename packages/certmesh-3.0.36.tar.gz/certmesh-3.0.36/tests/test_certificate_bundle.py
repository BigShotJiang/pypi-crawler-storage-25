"""tests.test_certificate_bundle
==================================

Verify CertificateBundle construction and certificate utility functions
from ``certmesh.certificate_utils``.
"""

from __future__ import annotations

import base64
import datetime

import pytest
from cryptography import x509
from cryptography.hazmat.primitives.asymmetric import ec, rsa
from cryptography.x509.oid import NameOID

from certmesh.certificate_utils import (
    CertificateBundle,
    SubjectInfo,
    assemble_bundle,
    build_csr,
    create_pkcs12_bundle,
    csr_to_pem,
    generate_ec_private_key,
    generate_rsa_private_key,
    parse_pkcs12_bundle,
    private_key_to_pem,
)
from certmesh.exceptions import KeyGenerationError, PKCS12ParseError

# =============================================================================
# CertificateBundle construction
# =============================================================================


class TestCertificateBundleCreation:
    """Test the CertificateBundle dataclass."""

    def test_create_with_all_fields(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        now = datetime.datetime.now(datetime.timezone.utc)
        bundle = CertificateBundle(
            certificate_pem=self_signed_cert_pem.decode("utf-8"),
            private_key_pem=private_key_pem.decode("utf-8"),
            chain_pem="-----BEGIN CERTIFICATE-----\nfake\n-----END CERTIFICATE-----\n",
            certificate_pem_b64=base64.b64encode(self_signed_cert_pem).decode("utf-8"),
            serial_number="abcd1234",
            common_name="test.example.com",
            not_after=now,
            source_id="test-source-001",
        )
        assert bundle.common_name == "test.example.com"
        assert bundle.serial_number == "abcd1234"
        assert bundle.source_id == "test-source-001"
        assert bundle.chain_pem is not None
        assert bundle.not_after == now

    def test_create_with_none_chain(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        now = datetime.datetime.now(datetime.timezone.utc)
        bundle = CertificateBundle(
            certificate_pem=self_signed_cert_pem.decode("utf-8"),
            private_key_pem=private_key_pem.decode("utf-8"),
            chain_pem=None,
            certificate_pem_b64=base64.b64encode(self_signed_cert_pem).decode("utf-8"),
            serial_number="0",
            common_name="test.example.com",
            not_after=now,
            source_id="test-source-002",
        )
        assert bundle.chain_pem is None

    def test_bundle_is_frozen(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        now = datetime.datetime.now(datetime.timezone.utc)
        bundle = CertificateBundle(
            certificate_pem=self_signed_cert_pem.decode("utf-8"),
            private_key_pem=private_key_pem.decode("utf-8"),
            chain_pem=None,
            certificate_pem_b64="",
            serial_number="0",
            common_name="test.example.com",
            not_after=now,
            source_id="frozen-test",
        )
        with pytest.raises(AttributeError):
            bundle.common_name = "modified"  # type: ignore[misc]


# =============================================================================
# assemble_bundle
# =============================================================================


class TestAssembleBundle:
    """Test the assemble_bundle helper that parses PEM and builds a bundle."""

    def test_assemble_valid_bundle(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=None,
            source_id="assemble-test",
        )
        assert bundle.common_name == "test.example.com"
        assert bundle.source_id == "assemble-test"
        assert bundle.chain_pem is None
        assert len(bundle.serial_number) > 0
        assert bundle.certificate_pem.startswith("-----BEGIN CERTIFICATE-----")

    def test_assemble_bundle_with_chain(
        self,
        ca_signed_cert_pem: bytes,
        private_key_pem: bytes,
        ca_cert_pem: bytes,
    ) -> None:
        bundle = assemble_bundle(
            cert_pem=ca_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=ca_cert_pem,
            source_id="chain-test",
        )
        assert bundle.chain_pem is not None
        assert "BEGIN CERTIFICATE" in bundle.chain_pem

    def test_assemble_bundle_b64_roundtrip(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=None,
            source_id="b64-test",
        )
        decoded = base64.b64decode(bundle.certificate_pem_b64)
        assert decoded == self_signed_cert_pem


# =============================================================================
# PKCS#12 parsing
# =============================================================================


class TestParsePkcs12Bundle:
    """Test parse_pkcs12_bundle with valid and invalid inputs."""

    def test_parse_valid_bundle(self, pkcs12_bundle: bytes) -> None:
        cert_pem, key_pem, chain_pem = parse_pkcs12_bundle(pkcs12_bundle, "testpass")
        assert b"BEGIN CERTIFICATE" in cert_pem
        assert b"BEGIN RSA PRIVATE KEY" in key_pem or b"BEGIN PRIVATE KEY" in key_pem
        # The fixture has no chain certs
        assert chain_pem is None

    def test_parse_invalid_passphrase(self, pkcs12_bundle: bytes) -> None:
        with pytest.raises(PKCS12ParseError):
            parse_pkcs12_bundle(pkcs12_bundle, "wrongpassword")

    def test_parse_garbage_bytes(self) -> None:
        with pytest.raises(PKCS12ParseError):
            parse_pkcs12_bundle(b"not-a-pkcs12-bundle", None)


# =============================================================================
# PKCS#12 creation
# =============================================================================


class TestCreatePkcs12Bundle:
    """Test create_pkcs12_bundle and roundtrip."""

    def test_create_and_roundtrip(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        p12 = create_pkcs12_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=None,
            passphrase="roundtrip",
            friendly_name="test-cert",
        )
        assert isinstance(p12, bytes)
        assert len(p12) > 0

        # Roundtrip: parse back
        cert_out, _key_out, chain_out = parse_pkcs12_bundle(p12, "roundtrip")
        assert b"BEGIN CERTIFICATE" in cert_out
        assert chain_out is None

    def test_create_without_passphrase(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        p12 = create_pkcs12_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
        )
        assert isinstance(p12, bytes)
        cert_out, _key_out, _chain_out = parse_pkcs12_bundle(p12, None)
        assert b"BEGIN CERTIFICATE" in cert_out

    def test_create_with_chain(
        self,
        ca_signed_cert_pem: bytes,
        private_key_pem: bytes,
        ca_cert_pem: bytes,
    ) -> None:
        p12 = create_pkcs12_bundle(
            cert_pem=ca_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=ca_cert_pem,
            passphrase="chaintest",
        )
        cert_out, _key_out, chain_out = parse_pkcs12_bundle(p12, "chaintest")
        assert b"BEGIN CERTIFICATE" in cert_out
        assert chain_out is not None
        assert b"BEGIN CERTIFICATE" in chain_out


# =============================================================================
# Key generation
# =============================================================================


class TestGeneratePrivateKey:
    """Test RSA and EC key generation."""

    @pytest.mark.parametrize("key_size", [2048, 3072, 4096])
    def test_generate_rsa_valid_sizes(self, key_size: int) -> None:
        key = generate_rsa_private_key(key_size)
        assert isinstance(key, rsa.RSAPrivateKey)
        assert key.key_size == key_size

    def test_generate_rsa_invalid_size(self) -> None:
        with pytest.raises(KeyGenerationError):
            generate_rsa_private_key(1024)

    @pytest.mark.parametrize("curve", ["P-256", "P-384", "P-521"])
    def test_generate_ec_valid_curves(self, curve: str) -> None:
        key = generate_ec_private_key(curve)
        assert isinstance(key, ec.EllipticCurvePrivateKey)

    def test_generate_ec_invalid_curve(self) -> None:
        with pytest.raises(KeyGenerationError):
            generate_ec_private_key("P-128")


# =============================================================================
# CSR generation
# =============================================================================


class TestGenerateCSR:
    """Test build_csr with various subject configurations."""

    def test_csr_basic(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        subject = SubjectInfo(common_name="basic.example.com")
        csr = build_csr(rsa_private_key, subject)
        assert isinstance(csr, x509.CertificateSigningRequest)
        # CN should be in the subject
        cn_attrs = csr.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
        assert cn_attrs[0].value == "basic.example.com"

    def test_csr_with_full_subject(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        subject = SubjectInfo(
            common_name="full.example.com",
            organisation="Test Org",
            organisational_unit="Engineering",
            country="US",
            state="Maryland",
            locality="Baltimore",
        )
        csr = build_csr(rsa_private_key, subject)
        org_attrs = csr.subject.get_attributes_for_oid(NameOID.ORGANIZATION_NAME)
        assert org_attrs[0].value == "Test Org"

    def test_csr_with_dns_sans(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        subject = SubjectInfo(
            common_name="san.example.com",
            san_dns_names=["san.example.com", "www.san.example.com"],
        )
        csr = build_csr(rsa_private_key, subject)
        san_ext = csr.extensions.get_extension_for_class(x509.SubjectAlternativeName)
        dns_names = san_ext.value.get_values_for_type(x509.DNSName)
        assert "san.example.com" in dns_names
        assert "www.san.example.com" in dns_names

    def test_csr_with_ip_sans(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        subject = SubjectInfo(
            common_name="ip.example.com",
            san_ip_addresses=["10.0.0.1", "192.168.1.1"],
        )
        csr = build_csr(rsa_private_key, subject)
        san_ext = csr.extensions.get_extension_for_class(x509.SubjectAlternativeName)
        ip_addrs = san_ext.value.get_values_for_type(x509.IPAddress)
        assert len(ip_addrs) == 2

    def test_csr_auto_adds_cn_as_san(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        """When no SANs are specified, the CN should be added as a DNS SAN."""
        subject = SubjectInfo(common_name="auto-san.example.com")
        csr = build_csr(rsa_private_key, subject)
        san_ext = csr.extensions.get_extension_for_class(x509.SubjectAlternativeName)
        dns_names = san_ext.value.get_values_for_type(x509.DNSName)
        assert "auto-san.example.com" in dns_names


# =============================================================================
# PEM serialization roundtrips
# =============================================================================


class TestPEMSerialization:
    """Test private_key_to_pem and csr_to_pem roundtrips."""

    def test_private_key_to_pem_roundtrip(self) -> None:
        key = generate_rsa_private_key(2048)
        pem_bytes = private_key_to_pem(key)
        assert pem_bytes.startswith(b"-----BEGIN PRIVATE KEY-----")
        # Reload the key from PEM
        from cryptography.hazmat.primitives.serialization import load_pem_private_key

        reloaded = load_pem_private_key(pem_bytes, password=None)
        assert isinstance(reloaded, rsa.RSAPrivateKey)
        assert reloaded.key_size == 2048

    def test_ec_key_to_pem_roundtrip(self) -> None:
        key = generate_ec_private_key("P-256")
        pem_bytes = private_key_to_pem(key)
        assert b"BEGIN PRIVATE KEY" in pem_bytes
        from cryptography.hazmat.primitives.serialization import load_pem_private_key

        reloaded = load_pem_private_key(pem_bytes, password=None)
        assert isinstance(reloaded, ec.EllipticCurvePrivateKey)

    def test_csr_to_pem_roundtrip(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        subject = SubjectInfo(common_name="pem-roundtrip.example.com")
        csr = build_csr(rsa_private_key, subject)
        pem_str = csr_to_pem(csr)
        assert pem_str.startswith("-----BEGIN CERTIFICATE REQUEST-----")
        # Reload
        reloaded = x509.load_pem_x509_csr(pem_str.encode("utf-8"))
        cn = reloaded.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
        assert cn[0].value == "pem-roundtrip.example.com"


# =============================================================================
# Edge cases
# =============================================================================


class TestEdgeCases:
    """Edge-case tests for CertificateBundle and utilities."""

    def test_bundle_with_empty_serial(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        now = datetime.datetime.now(datetime.timezone.utc)
        bundle = CertificateBundle(
            certificate_pem=self_signed_cert_pem.decode("utf-8"),
            private_key_pem=private_key_pem.decode("utf-8"),
            chain_pem=None,
            certificate_pem_b64="",
            serial_number="",
            common_name="edge.example.com",
            not_after=now,
            source_id="edge-001",
        )
        assert bundle.serial_number == ""

    def test_assemble_bundle_extracts_serial(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        """assemble_bundle should parse the serial number from the cert."""
        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=None,
            source_id="serial-test",
        )
        # Serial should be a hex string
        assert len(bundle.serial_number) > 0
        int(bundle.serial_number, 16)  # must be valid hex

    def test_assemble_bundle_not_after_is_timezone_aware(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=None,
            source_id="tz-test",
        )
        assert bundle.not_after.tzinfo is not None
