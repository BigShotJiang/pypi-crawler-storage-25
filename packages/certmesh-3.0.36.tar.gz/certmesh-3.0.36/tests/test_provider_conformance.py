"""tests.test_provider_conformance
====================================

Verify that each provider module exports the functions declared in the
capability registry (``certmesh.providers.protocol``).
"""

from __future__ import annotations

import importlib
from typing import Any

import pytest

from certmesh.providers.protocol import (
    KNOWN_PROVIDERS,
    PROVIDER_CAPABILITIES,
    get_provider_capabilities,
    provider_function_mapping,
    supports_operation,
)

# ---------------------------------------------------------------------------
# Map provider registry names to their importable module paths
# ---------------------------------------------------------------------------

_PROVIDER_MODULES: dict[str, str] = {
    "acm": "certmesh.providers.acm_client",
    "digicert": "certmesh.providers.digicert_client",
    "venafi": "certmesh.providers.venafi_client",
    "letsencrypt": "certmesh.providers.letsencrypt_client",
    "vault-pki": "certmesh.backends.vault_client",
}


def _load_module(module_path: str) -> Any:
    return importlib.import_module(module_path)


# ---------------------------------------------------------------------------
# Build parametrize tuples: (provider_name, operation, function_name)
# ---------------------------------------------------------------------------


def _build_provider_function_params() -> list[tuple[str, str, str]]:
    mapping = provider_function_mapping()
    params: list[tuple[str, str, str]] = []
    for provider, ops in mapping.items():
        for operation, func_name in ops.items():
            params.append((provider, operation, func_name))
    return params


_PROVIDER_FUNC_PARAMS = _build_provider_function_params()


# ---------------------------------------------------------------------------
# Tests: function existence and callability
# ---------------------------------------------------------------------------


class TestProviderFunctionExistence:
    """Each function listed in provider_function_mapping() must exist in
    the corresponding module and be callable."""

    @pytest.mark.parametrize(
        "provider,operation,func_name",
        _PROVIDER_FUNC_PARAMS,
        ids=[f"{p}-{o}" for p, o, _ in _PROVIDER_FUNC_PARAMS],
    )
    def test_function_exists_in_module(
        self, provider: str, operation: str, func_name: str
    ) -> None:
        module_path = _PROVIDER_MODULES[provider]
        mod = _load_module(module_path)
        assert hasattr(mod, func_name), (
            f"Provider '{provider}' maps operation '{operation}' to function "
            f"'{func_name}', but module '{module_path}' has no such attribute."
        )

    @pytest.mark.parametrize(
        "provider,operation,func_name",
        _PROVIDER_FUNC_PARAMS,
        ids=[f"{p}-{o}-callable" for p, o, _ in _PROVIDER_FUNC_PARAMS],
    )
    def test_function_is_callable(self, provider: str, operation: str, func_name: str) -> None:
        module_path = _PROVIDER_MODULES[provider]
        mod = _load_module(module_path)
        obj = getattr(mod, func_name)
        assert callable(obj), f"'{module_path}.{func_name}' exists but is not callable."


# ---------------------------------------------------------------------------
# Tests: capability helpers
# ---------------------------------------------------------------------------


class TestCapabilityHelpers:
    """Verify get_provider_capabilities() and supports_operation()."""

    @pytest.mark.parametrize("provider", sorted(KNOWN_PROVIDERS))
    def test_get_provider_capabilities_returns_frozenset(self, provider: str) -> None:
        caps = get_provider_capabilities(provider)
        assert isinstance(caps, frozenset)
        assert len(caps) > 0, f"Provider '{provider}' has no capabilities registered."

    def test_get_provider_capabilities_unknown_returns_empty(self) -> None:
        assert get_provider_capabilities("nonexistent") == frozenset()

    @pytest.mark.parametrize("provider", sorted(KNOWN_PROVIDERS))
    def test_supports_operation_for_known_ops(self, provider: str) -> None:
        caps = get_provider_capabilities(provider)
        for op in caps:
            assert supports_operation(provider, op) is True

    @pytest.mark.parametrize("provider", sorted(KNOWN_PROVIDERS))
    def test_supports_operation_false_for_unknown_op(self, provider: str) -> None:
        assert supports_operation(provider, "totally_fake_operation") is False

    def test_supports_operation_unknown_provider(self) -> None:
        assert supports_operation("nonexistent", "request_certificate") is False


# ---------------------------------------------------------------------------
# Tests: KNOWN_PROVIDERS completeness
# ---------------------------------------------------------------------------


class TestKnownProviders:
    """KNOWN_PROVIDERS must contain all five providers."""

    EXPECTED: frozenset[str] = frozenset({"acm", "digicert", "venafi", "letsencrypt", "vault-pki"})

    def test_known_providers_has_all_five(self) -> None:
        assert frozenset(self.EXPECTED) == KNOWN_PROVIDERS

    def test_known_providers_count(self) -> None:
        assert len(KNOWN_PROVIDERS) == 5

    @pytest.mark.parametrize("provider", sorted(EXPECTED))
    def test_provider_in_known_providers(self, provider: str) -> None:
        assert provider in KNOWN_PROVIDERS


# ---------------------------------------------------------------------------
# Tests: mapping consistency
# ---------------------------------------------------------------------------


class TestMappingConsistency:
    """The function mapping must cover exactly the operations declared in
    PROVIDER_CAPABILITIES for each provider."""

    @pytest.mark.parametrize("provider", sorted(KNOWN_PROVIDERS))
    def test_mapping_keys_match_capabilities(self, provider: str) -> None:
        mapping = provider_function_mapping()
        mapped_ops = set(mapping.get(provider, {}).keys())
        declared_caps = PROVIDER_CAPABILITIES[provider]
        assert mapped_ops == declared_caps, (
            f"Provider '{provider}': mapping operations {sorted(mapped_ops)} "
            f"do not match declared capabilities {sorted(declared_caps)}."
        )
