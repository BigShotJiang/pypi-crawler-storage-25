"""Tests for certmesh.certificate_utils."""

from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa

from certmesh.certificate_utils import (
    CertificateBundle,
    SubjectInfo,
    assemble_bundle,
    build_csr,
    create_pkcs12_bundle,
    csr_to_pem,
    generate_ec_private_key,
    generate_rsa_private_key,
    parse_pkcs12_bundle,
    persist_bundle,
    private_key_to_pem,
    validate_bundle,
    verify_certificate_chain,
    verify_certificate_not_expired,
    verify_key_matches_certificate,
)
from certmesh.exceptions import (
    CertificateExportError,
    CertificateValidationError,
    ConfigurationError,
    KeyGenerationError,
    PKCS12ParseError,
)

JsonDict = dict[str, Any]


class TestGenerateRSAPrivateKey:
    @pytest.mark.parametrize("key_size", [2048, 3072, 4096])
    def test_valid_key_sizes(self, key_size: int) -> None:
        key = generate_rsa_private_key(key_size)
        assert isinstance(key, rsa.RSAPrivateKey)
        assert key.key_size == key_size

    def test_invalid_key_size_raises(self) -> None:
        with pytest.raises(KeyGenerationError, match="Unsupported"):
            generate_rsa_private_key(1024)


class TestGenerateECPrivateKey:
    @pytest.mark.parametrize("curve", ["P-256", "P-384", "P-521"])
    def test_valid_curves(self, curve: str) -> None:
        key = generate_ec_private_key(curve)
        assert isinstance(key, ec.EllipticCurvePrivateKey)
        assert key.key_size > 0

    def test_p256_key_size(self) -> None:
        key = generate_ec_private_key("P-256")
        assert key.key_size == 256

    def test_p384_key_size(self) -> None:
        key = generate_ec_private_key("P-384")
        assert key.key_size == 384

    def test_p521_key_size(self) -> None:
        key = generate_ec_private_key("P-521")
        assert key.key_size == 521

    def test_invalid_curve_raises(self) -> None:
        with pytest.raises(KeyGenerationError, match="Unsupported curve"):
            generate_ec_private_key("P-224")

    def test_default_curve_is_p256(self) -> None:
        key = generate_ec_private_key()
        assert key.key_size == 256


class TestPrivateKeyToPEM:
    def test_pem_output_rsa(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        pem = private_key_to_pem(rsa_private_key)
        # PKCS#8 format — header is "BEGIN PRIVATE KEY" (not algorithm-specific)
        assert b"-----BEGIN PRIVATE KEY-----" in pem
        assert b"-----END PRIVATE KEY-----" in pem

    def test_pem_output_ec(self) -> None:
        key = generate_ec_private_key("P-256")
        pem = private_key_to_pem(key)
        assert b"-----BEGIN PRIVATE KEY-----" in pem
        assert b"-----END PRIVATE KEY-----" in pem


class TestBuildCSR:
    def test_basic_csr(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        subject = SubjectInfo(
            common_name="test.example.com",
            organisation="Test Org",
            country="US",
        )
        csr = build_csr(rsa_private_key, subject)
        assert csr is not None
        pem = csr_to_pem(csr)
        assert "BEGIN CERTIFICATE REQUEST" in pem

    def test_csr_with_sans(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        subject = SubjectInfo(
            common_name="test.example.com",
            san_dns_names=["api.example.com", "web.example.com"],
        )
        csr = build_csr(rsa_private_key, subject)
        pem = csr_to_pem(csr)
        assert "BEGIN CERTIFICATE REQUEST" in pem

    def test_csr_no_sans_uses_cn(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        subject = SubjectInfo(common_name="test.example.com")
        csr = build_csr(rsa_private_key, subject)
        assert csr is not None

    def test_csr_with_ip_san(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        from cryptography import x509 as cx509

        subject = SubjectInfo(
            common_name="svc.internal",
            san_ip_addresses=["10.0.0.1", "192.168.1.100"],
        )
        csr = build_csr(rsa_private_key, subject)
        pem = csr_to_pem(csr)
        assert "BEGIN CERTIFICATE REQUEST" in pem
        # Verify IP SANs are embedded in the CSR extensions
        san_ext = csr.extensions.get_extension_for_class(cx509.SubjectAlternativeName)
        ip_sans = san_ext.value.get_values_for_type(cx509.IPAddress)
        assert len(ip_sans) == 2

    def test_csr_with_uri_san(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        from cryptography import x509 as cx509

        subject = SubjectInfo(
            common_name="svc.cluster.local",
            san_uris=["spiffe://cluster.local/ns/default/sa/my-service"],
        )
        csr = build_csr(rsa_private_key, subject)
        san_ext = csr.extensions.get_extension_for_class(cx509.SubjectAlternativeName)
        uri_sans = san_ext.value.get_values_for_type(cx509.UniformResourceIdentifier)
        assert len(uri_sans) == 1
        assert str(uri_sans[0]) == "spiffe://cluster.local/ns/default/sa/my-service"

    def test_csr_with_mixed_sans(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        from cryptography import x509 as cx509

        subject = SubjectInfo(
            common_name="mixed.example.com",
            san_dns_names=["alt.example.com"],
            san_ip_addresses=["10.1.2.3"],
            san_uris=["spiffe://example.com/workload"],
        )
        csr = build_csr(rsa_private_key, subject)
        san_ext = csr.extensions.get_extension_for_class(cx509.SubjectAlternativeName)
        assert len(san_ext.value.get_values_for_type(cx509.DNSName)) == 1
        assert len(san_ext.value.get_values_for_type(cx509.IPAddress)) == 1
        assert len(san_ext.value.get_values_for_type(cx509.UniformResourceIdentifier)) == 1

    def test_csr_invalid_ip_raises(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        from certmesh.exceptions import CSRGenerationError

        subject = SubjectInfo(
            common_name="test.example.com",
            san_ip_addresses=["not-an-ip"],
        )
        with pytest.raises(CSRGenerationError):
            build_csr(rsa_private_key, subject)

    def test_csr_with_ec_key(self) -> None:
        key = generate_ec_private_key("P-256")
        subject = SubjectInfo(
            common_name="ec.example.com",
            san_dns_names=["api.example.com"],
        )
        csr = build_csr(key, subject)
        pem = csr_to_pem(csr)
        assert "BEGIN CERTIFICATE REQUEST" in pem


class TestCreatePKCS12Bundle:
    def test_roundtrip_no_passphrase(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        p12 = create_pkcs12_bundle(self_signed_cert_pem, private_key_pem)
        assert isinstance(p12, bytes)
        assert len(p12) > 0
        # Verify it can be parsed back
        cert_out, _key_out, _chain_out = parse_pkcs12_bundle(p12, None)
        assert b"BEGIN CERTIFICATE" in cert_out
        assert _key_out is not None

    def test_roundtrip_with_passphrase(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        p12 = create_pkcs12_bundle(self_signed_cert_pem, private_key_pem, passphrase="secret")
        cert_out, _, _ = parse_pkcs12_bundle(p12, "secret")
        assert b"BEGIN CERTIFICATE" in cert_out

    def test_wrong_passphrase_raises(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        p12 = create_pkcs12_bundle(self_signed_cert_pem, private_key_pem, passphrase="correct")
        with pytest.raises(PKCS12ParseError):
            parse_pkcs12_bundle(p12, "wrong")

    def test_with_chain(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        # Use the leaf cert as a fake CA chain entry for the test
        p12 = create_pkcs12_bundle(
            self_signed_cert_pem,
            private_key_pem,
            chain_pem=self_signed_cert_pem,
        )
        assert isinstance(p12, bytes)

    def test_friendly_name(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        p12 = create_pkcs12_bundle(
            self_signed_cert_pem,
            private_key_pem,
            friendly_name="my-cert",
        )
        assert isinstance(p12, bytes)

    def test_invalid_cert_pem_raises(self, private_key_pem: bytes) -> None:
        with pytest.raises(PKCS12ParseError, match="certificate PEM"):
            create_pkcs12_bundle(b"not-a-cert", private_key_pem)

    def test_invalid_key_pem_raises(self, self_signed_cert_pem: bytes) -> None:
        with pytest.raises(PKCS12ParseError, match="private key PEM"):
            create_pkcs12_bundle(self_signed_cert_pem, b"not-a-key")


class TestParsePKCS12Bundle:
    def test_valid_bundle(self, pkcs12_bundle: bytes) -> None:
        cert_pem, key_pem, chain_pem = parse_pkcs12_bundle(pkcs12_bundle, "testpass")
        assert b"BEGIN CERTIFICATE" in cert_pem
        assert b"BEGIN RSA PRIVATE KEY" in key_pem
        # No chain certs in our test bundle
        assert chain_pem is None

    def test_wrong_passphrase_raises(self, pkcs12_bundle: bytes) -> None:
        with pytest.raises(PKCS12ParseError, match="passphrase"):
            parse_pkcs12_bundle(pkcs12_bundle, "wrong")

    def test_invalid_data_raises(self) -> None:
        with pytest.raises(PKCS12ParseError):
            parse_pkcs12_bundle(b"not-pkcs12", "pass")


class TestAssembleBundle:
    def test_basic_assembly(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=None,
            source_id="test-123",
        )
        assert bundle.common_name == "test.example.com"
        assert bundle.source_id == "test-123"
        assert bundle.certificate_pem.startswith("-----BEGIN CERTIFICATE-----")
        assert bundle.serial_number
        assert isinstance(bundle.not_after, datetime)
        assert bundle.certificate_pem_b64

    def test_with_chain(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=self_signed_cert_pem,  # reuse as fake chain
            source_id="test-456",
        )
        assert bundle.chain_pem is not None

    def test_invalid_cert_pem_raises(self, private_key_pem: bytes) -> None:
        with pytest.raises(CertificateExportError):
            assemble_bundle(
                cert_pem=b"not-a-cert",
                private_key_pem=private_key_pem,
                chain_pem=None,
                source_id="bad",
            )


class TestPersistBundle:
    def _make_bundle(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> CertificateBundle:
        return assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=self_signed_cert_pem,
            source_id="test-789",
        )

    def test_filesystem_persistence(
        self,
        tmp_path: Path,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        bundle = self._make_bundle(self_signed_cert_pem, private_key_pem)
        output_cfg: JsonDict = {
            "destination": "filesystem",
            "base_path": str(tmp_path / "certs"),
            "cert_filename": "{order_id}_cert.pem",
            "key_filename": "{order_id}_key.pem",
            "chain_filename": "{order_id}_chain.pem",
        }
        result = persist_bundle(bundle, output_cfg)
        assert "filesystem_cert" in result
        assert "filesystem_key" in result
        assert "filesystem_chain" in result

        cert_path = Path(result["filesystem_cert"])
        key_path = Path(result["filesystem_key"])
        assert cert_path.exists()
        assert key_path.exists()
        # Key should have restricted permissions
        assert oct(os.stat(key_path).st_mode)[-3:] == "600"

    def test_filesystem_pkcs12_output(
        self,
        tmp_path: Path,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        bundle = self._make_bundle(self_signed_cert_pem, private_key_pem)
        output_cfg: JsonDict = {
            "destination": "filesystem",
            "base_path": str(tmp_path / "certs"),
            "cert_filename": "{order_id}_cert.pem",
            "key_filename": "{order_id}_key.pem",
            "pkcs12_filename": "{order_id}.p12",
            "pkcs12_passphrase": "testpass",
        }
        result = persist_bundle(bundle, output_cfg)
        assert "filesystem_pkcs12" in result
        p12_path = Path(result["filesystem_pkcs12"])
        assert p12_path.exists()
        assert p12_path.suffix == ".p12"
        # PKCS#12 file should have restricted permissions
        assert oct(os.stat(p12_path).st_mode)[-3:] == "600"

    def test_filesystem_pkcs12_no_passphrase(
        self,
        tmp_path: Path,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        bundle = self._make_bundle(self_signed_cert_pem, private_key_pem)
        output_cfg: JsonDict = {
            "destination": "filesystem",
            "base_path": str(tmp_path / "certs"),
            "cert_filename": "{order_id}_cert.pem",
            "key_filename": "{order_id}_key.pem",
            "pkcs12_filename": "{order_id}.p12",
        }
        result = persist_bundle(bundle, output_cfg)
        assert "filesystem_pkcs12" in result
        p12_path = Path(result["filesystem_pkcs12"])
        assert p12_path.exists()


# =============================================================================
# Certificate validation
# =============================================================================


class TestVerifyKeyMatchesCertificate:
    def test_matching_key(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        assert verify_key_matches_certificate(private_key_pem, self_signed_cert_pem) is True

    def test_mismatched_key(
        self,
        self_signed_cert_pem: bytes,
        mismatched_private_key_pem: bytes,
    ) -> None:
        assert (
            verify_key_matches_certificate(mismatched_private_key_pem, self_signed_cert_pem)
            is False
        )

    def test_invalid_cert_raises(self, private_key_pem: bytes) -> None:
        with pytest.raises(CertificateValidationError, match="certificate PEM"):
            verify_key_matches_certificate(private_key_pem, b"not-a-cert")

    def test_invalid_key_raises(self, self_signed_cert_pem: bytes) -> None:
        with pytest.raises(CertificateValidationError, match="private key PEM"):
            verify_key_matches_certificate(b"not-a-key", self_signed_cert_pem)

    def test_ec_key_match(self) -> None:
        import datetime as dt

        from cryptography import x509 as cx509
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.x509.oid import NameOID as _NameOID

        key = ec.generate_private_key(ec.SECP256R1())
        key_pem = key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        subject = cx509.Name([cx509.NameAttribute(_NameOID.COMMON_NAME, "ec.test")])
        cert = (
            cx509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(subject)
            .public_key(key.public_key())
            .serial_number(cx509.random_serial_number())
            .not_valid_before(dt.datetime.now(dt.timezone.utc))
            .not_valid_after(dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=1))
            .sign(key, hashes.SHA256())
        )
        cert_pem = cert.public_bytes(serialization.Encoding.PEM)
        assert verify_key_matches_certificate(key_pem, cert_pem) is True


class TestVerifyCertificateChain:
    def test_valid_chain(
        self,
        ca_signed_cert_pem: bytes,
        ca_cert_pem: bytes,
    ) -> None:
        assert verify_certificate_chain(ca_signed_cert_pem, ca_cert_pem) is True

    def test_self_signed_no_chain(self, self_signed_cert_pem: bytes) -> None:
        assert verify_certificate_chain(self_signed_cert_pem, None) is True

    def test_wrong_chain(
        self,
        self_signed_cert_pem: bytes,
        ca_cert_pem: bytes,
    ) -> None:
        # self_signed_cert_pem was NOT issued by the CA, so chain should fail
        assert verify_certificate_chain(self_signed_cert_pem, ca_cert_pem) is False

    def test_empty_chain_bytes(self, self_signed_cert_pem: bytes) -> None:
        assert verify_certificate_chain(self_signed_cert_pem, b"") is True

    def test_invalid_cert_raises(self, ca_cert_pem: bytes) -> None:
        with pytest.raises(CertificateValidationError, match="leaf certificate"):
            verify_certificate_chain(b"bad-cert", ca_cert_pem)


class TestVerifyCertificateNotExpired:
    def test_valid_cert(self, self_signed_cert_pem: bytes) -> None:
        assert verify_certificate_not_expired(self_signed_cert_pem) is True

    def test_expired_cert(self, expired_cert_pem: bytes) -> None:
        assert verify_certificate_not_expired(expired_cert_pem) is False

    def test_invalid_pem_raises(self) -> None:
        with pytest.raises(CertificateValidationError, match="Cannot parse"):
            verify_certificate_not_expired(b"not-a-cert")


class TestValidateBundle:
    def test_valid_bundle_no_warnings(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        warnings = validate_bundle(self_signed_cert_pem, private_key_pem)
        assert warnings == []

    def test_mismatched_key_warns(
        self,
        self_signed_cert_pem: bytes,
        mismatched_private_key_pem: bytes,
    ) -> None:
        warnings = validate_bundle(self_signed_cert_pem, mismatched_private_key_pem)
        assert any("key" in w.lower() for w in warnings)

    def test_expired_cert_warns(
        self,
        expired_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        warnings = validate_bundle(expired_cert_pem, private_key_pem)
        assert any("validity period" in w.lower() for w in warnings)

    def test_valid_chain_no_chain_warning(
        self,
        ca_signed_cert_pem: bytes,
        private_key_pem: bytes,
        ca_cert_pem: bytes,
    ) -> None:
        warnings = validate_bundle(ca_signed_cert_pem, private_key_pem, ca_cert_pem)
        assert not any("chain" in w.lower() for w in warnings)

    def test_wrong_chain_warns(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
        ca_cert_pem: bytes,
    ) -> None:
        warnings = validate_bundle(self_signed_cert_pem, private_key_pem, ca_cert_pem)
        assert any("chain" in w.lower() for w in warnings)


class TestAssembleBundleStrict:
    def test_strict_raises_on_key_mismatch(
        self,
        self_signed_cert_pem: bytes,
        mismatched_private_key_pem: bytes,
    ) -> None:
        with pytest.raises(CertificateValidationError, match="validation failed"):
            assemble_bundle(
                cert_pem=self_signed_cert_pem,
                private_key_pem=mismatched_private_key_pem,
                chain_pem=None,
                source_id="strict-test",
                strict=True,
            )

    def test_nonstrict_returns_bundle_with_mismatch(
        self,
        self_signed_cert_pem: bytes,
        mismatched_private_key_pem: bytes,
    ) -> None:
        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=mismatched_private_key_pem,
            chain_pem=None,
            source_id="nonstrict-test",
            strict=False,
        )
        assert bundle.common_name == "test.example.com"

    def test_strict_passes_valid_bundle(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=None,
            source_id="strict-valid",
            strict=True,
        )
        assert bundle.source_id == "strict-valid"


# =============================================================================
# Full TLS lifecycle tests
# =============================================================================


class TestFullLifecycle:
    """End-to-end tests covering the complete TLS certificate lifecycle:
    key generation -> CSR -> (simulated) issuance -> bundle assembly ->
    persistence -> validation -> renewal check.
    """

    def test_rsa_lifecycle(self, tmp_path: Path) -> None:
        import datetime as dt

        from cryptography import x509 as cx509
        from cryptography.x509.oid import NameOID as _NameOID

        from certmesh.renewal import RenewalPolicy, should_renew

        # 1. Generate key
        key = generate_rsa_private_key(2048)
        key_pem = private_key_to_pem(key)
        assert b"BEGIN PRIVATE KEY" in key_pem

        # 2. Build CSR
        subject = SubjectInfo(
            common_name="lifecycle.example.com",
            organisation="Lifecycle Test Org",
            country="US",
            san_dns_names=["api.lifecycle.example.com"],
        )
        csr = build_csr(key, subject)
        csr_pem_str = csr_to_pem(csr)
        assert "BEGIN CERTIFICATE REQUEST" in csr_pem_str

        # 3. Simulate CA issuance (self-signed for test)
        cert_subject = cx509.Name(
            [
                cx509.NameAttribute(_NameOID.COMMON_NAME, "lifecycle.example.com"),
                cx509.NameAttribute(_NameOID.ORGANIZATION_NAME, "Lifecycle Test Org"),
            ]
        )
        cert = (
            cx509.CertificateBuilder()
            .subject_name(cert_subject)
            .issuer_name(cert_subject)
            .public_key(key.public_key())
            .serial_number(cx509.random_serial_number())
            .not_valid_before(dt.datetime.now(dt.timezone.utc))
            .not_valid_after(dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=365))
            .add_extension(
                cx509.SubjectAlternativeName([cx509.DNSName("api.lifecycle.example.com")]),
                critical=False,
            )
            .sign(key, hashes.SHA256())
        )
        cert_pem = cert.public_bytes(serialization.Encoding.PEM)

        # 4. Validate the bundle
        warnings = validate_bundle(cert_pem, key_pem)
        assert warnings == [], f"Unexpected validation warnings: {warnings}"

        # 5. Assemble bundle (strict mode)
        bundle = assemble_bundle(
            cert_pem=cert_pem,
            private_key_pem=key_pem,
            chain_pem=None,
            source_id="lifecycle-test",
            strict=True,
        )
        assert bundle.common_name == "lifecycle.example.com"
        assert bundle.serial_number

        # 6. Persist to filesystem
        output_cfg: JsonDict = {
            "destination": "filesystem",
            "base_path": str(tmp_path / "lifecycle_certs"),
            "cert_filename": "{order_id}_cert.pem",
            "key_filename": "{order_id}_key.pem",
        }
        result = persist_bundle(bundle, output_cfg)
        assert "filesystem_cert" in result
        assert "filesystem_key" in result

        # 7. Read back and verify
        cert_path = Path(result["filesystem_cert"])
        key_path = Path(result["filesystem_key"])
        assert cert_path.read_text().startswith("-----BEGIN CERTIFICATE-----")
        assert key_path.read_text().startswith("-----BEGIN PRIVATE KEY-----")
        assert oct(os.stat(key_path).st_mode)[-3:] == "600"

        # 8. Renewal check: fresh cert should NOT need renewal
        policy = RenewalPolicy(before_expiry=30, unit="day")
        assert should_renew(bundle.not_after, policy) is False

    def test_ec_lifecycle(self, tmp_path: Path) -> None:
        import datetime as dt

        from cryptography import x509 as cx509
        from cryptography.x509.oid import NameOID as _NameOID

        from certmesh.renewal import RenewalPolicy, should_renew

        key = generate_ec_private_key("P-256")
        key_pem = private_key_to_pem(key)

        subject = SubjectInfo(
            common_name="ec-lifecycle.example.com",
            san_dns_names=["ec-api.example.com"],
        )
        csr = build_csr(key, subject)
        assert csr is not None

        cert_subject = cx509.Name(
            [
                cx509.NameAttribute(_NameOID.COMMON_NAME, "ec-lifecycle.example.com"),
            ]
        )
        cert = (
            cx509.CertificateBuilder()
            .subject_name(cert_subject)
            .issuer_name(cert_subject)
            .public_key(key.public_key())
            .serial_number(cx509.random_serial_number())
            .not_valid_before(dt.datetime.now(dt.timezone.utc))
            .not_valid_after(dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=90))
            .sign(key, hashes.SHA256())
        )
        cert_pem = cert.public_bytes(serialization.Encoding.PEM)

        warnings = validate_bundle(cert_pem, key_pem)
        assert warnings == []

        bundle = assemble_bundle(
            cert_pem=cert_pem,
            private_key_pem=key_pem,
            chain_pem=None,
            source_id="ec-lifecycle",
            strict=True,
        )
        assert bundle.common_name == "ec-lifecycle.example.com"

        policy = RenewalPolicy(before_expiry=30, unit="day")
        assert should_renew(bundle.not_after, policy) is False

    def test_expired_cert_triggers_renewal(self) -> None:
        import datetime as dt

        from cryptography import x509 as cx509
        from cryptography.x509.oid import NameOID as _NameOID

        from certmesh.renewal import RenewalPolicy, should_renew

        key = generate_rsa_private_key(2048)
        key_pem = private_key_to_pem(key)

        subject = cx509.Name(
            [
                cx509.NameAttribute(_NameOID.COMMON_NAME, "expired-lifecycle.example.com"),
            ]
        )
        cert = (
            cx509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(subject)
            .public_key(key.public_key())
            .serial_number(cx509.random_serial_number())
            .not_valid_before(dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=365))
            .not_valid_after(dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=1))
            .sign(key, hashes.SHA256())
        )
        cert_pem = cert.public_bytes(serialization.Encoding.PEM)

        warnings = validate_bundle(cert_pem, key_pem)
        assert any("validity period" in w.lower() for w in warnings)

        bundle = assemble_bundle(
            cert_pem=cert_pem,
            private_key_pem=key_pem,
            chain_pem=None,
            source_id="expired-lifecycle",
            strict=False,
        )
        assert bundle.common_name == "expired-lifecycle.example.com"

        policy = RenewalPolicy(before_expiry=30, unit="day")
        assert should_renew(bundle.not_after, policy) is True

    def test_ca_signed_chain_lifecycle(
        self,
        tmp_path: Path,
        ca_signed_cert_pem: bytes,
        ca_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        """Full lifecycle with a CA-signed cert and chain validation."""
        from certmesh.renewal import RenewalPolicy, should_renew

        warnings = validate_bundle(ca_signed_cert_pem, private_key_pem, ca_cert_pem)
        assert not any("chain" in w.lower() for w in warnings)

        bundle = assemble_bundle(
            cert_pem=ca_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=ca_cert_pem,
            source_id="ca-chain-test",
            strict=True,
        )
        assert bundle.common_name == "leaf.example.com"
        assert bundle.chain_pem is not None
        assert "BEGIN CERTIFICATE" in bundle.chain_pem

        output_cfg: JsonDict = {
            "destination": "filesystem",
            "base_path": str(tmp_path / "chain_certs"),
            "cert_filename": "{order_id}_cert.pem",
            "key_filename": "{order_id}_key.pem",
            "chain_filename": "{order_id}_chain.pem",
        }
        result = persist_bundle(bundle, output_cfg)
        assert "filesystem_chain" in result

        policy = RenewalPolicy(before_expiry=30, unit="day")
        assert should_renew(bundle.not_after, policy) is False


# =============================================================================
# Vault / Secrets Manager persistence tests (Fix 5)
# =============================================================================


class TestPersistBundleVault:
    def test_vault_persistence(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        """Vault destination writes secret_data to correct path."""
        from unittest.mock import MagicMock, patch

        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=None,
            source_id="vault-test-001",
        )
        mock_vc = MagicMock()
        output_cfg: JsonDict = {
            "destination": "vault",
            "vault_path_template": "secret/certs/{order_id}",
            "kv_version": 2,
        }
        with patch("certmesh.backends.vault_client.write_secret_versioned") as mock_write:
            result = persist_bundle(bundle, output_cfg, vault_client=mock_vc)

        assert result["vault"] == "secret/certs/vault-test-001"
        mock_write.assert_called_once()
        call_args = mock_write.call_args
        assert call_args[0][0] is mock_vc  # vault client passed through
        assert call_args[0][1] == "secret/certs/vault-test-001"
        secret_data = call_args[0][2]
        assert "certificate_pem" in secret_data
        assert "private_key_pem" in secret_data
        assert secret_data["source_id"] == "vault-test-001"

    def test_vault_missing_client_raises(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        """Vault destination without vault_client raises ConfigurationError."""
        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=None,
            source_id="no-vault",
        )
        output_cfg: JsonDict = {
            "destination": "vault",
            "vault_path_template": "secret/certs/{order_id}",
        }
        with pytest.raises(ConfigurationError, match="vault_client must be provided"):
            persist_bundle(bundle, output_cfg, vault_client=None)

    def test_vault_path_template_expansion(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        """Path template placeholders are replaced with source_id."""
        from unittest.mock import MagicMock, patch

        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=None,
            source_id="my-id-123",
        )
        output_cfg: JsonDict = {
            "destination": "vault",
            "vault_path_template": "pki/{guid}/cert",
            "kv_version": 1,
        }
        with patch("certmesh.backends.vault_client.write_secret_versioned") as mock_write:
            result = persist_bundle(bundle, output_cfg, vault_client=MagicMock())

        assert result["vault"] == "pki/my-id-123/cert"
        call_kw = mock_write.call_args
        assert call_kw[1]["kv_version"] == 1


class TestPersistBundleSecretsManager:
    def test_sm_persistence(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        """Secrets Manager destination writes to correct secret name."""
        from unittest.mock import patch

        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=None,
            source_id="sm-test-001",
        )
        output_cfg: JsonDict = {
            "destination": "secrets_manager",
            "sm_secret_name_template": "certmesh/{order_id}",
            "sm_region": "us-east-1",
        }
        with patch("certmesh.backends.secrets_manager_client.write_secret") as mock_write:
            result = persist_bundle(bundle, output_cfg)

        assert result["secrets_manager"] == "certmesh/sm-test-001"
        mock_write.assert_called_once()
        call_args = mock_write.call_args[0]
        assert call_args[0] == "certmesh/sm-test-001"
        assert "certificate_pem" in call_args[1]
        assert call_args[2] == "us-east-1"

    def test_sm_missing_template_raises(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        """Missing sm_secret_name_template raises ConfigurationError."""
        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=None,
            source_id="no-template",
        )
        output_cfg: JsonDict = {
            "destination": "secrets_manager",
            "sm_region": "us-east-1",
        }
        with pytest.raises(ConfigurationError, match="sm_secret_name_template"):
            persist_bundle(bundle, output_cfg)

    def test_sm_missing_region_raises(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        """Missing sm_region raises ConfigurationError."""
        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=None,
            source_id="no-region",
        )
        output_cfg: JsonDict = {
            "destination": "secrets_manager",
            "sm_secret_name_template": "certmesh/{order_id}",
        }
        with pytest.raises(ConfigurationError, match="sm_region"):
            persist_bundle(bundle, output_cfg)


# =============================================================================
# Multi-depth chain validation (Fix 6)
# =============================================================================


class TestVerifyCertificateChainMultiDepth:
    def test_two_level_chain_valid(
        self,
        leaf_from_intermediate_pem: bytes,
        two_level_chain_pem: bytes,
    ) -> None:
        """Leaf signed by intermediate, chain = intermediate + root → valid."""
        assert verify_certificate_chain(leaf_from_intermediate_pem, two_level_chain_pem) is True

    def test_incomplete_chain_missing_intermediate(
        self,
        leaf_from_intermediate_pem: bytes,
        ca_cert_pem: bytes,
    ) -> None:
        """Leaf signed by intermediate, but only root CA in chain → invalid."""
        assert verify_certificate_chain(leaf_from_intermediate_pem, ca_cert_pem) is False

    def test_full_lifecycle_with_two_level_chain(
        self,
        leaf_from_intermediate_pem: bytes,
        two_level_chain_pem: bytes,
        private_key_pem: bytes,
        tmp_path: Path,
    ) -> None:
        """End-to-end: assemble + validate + persist with a 2-level chain."""
        from certmesh.renewal import RenewalPolicy, should_renew

        bundle = assemble_bundle(
            cert_pem=leaf_from_intermediate_pem,
            private_key_pem=private_key_pem,
            chain_pem=two_level_chain_pem,
            source_id="deep-chain-test",
        )
        assert bundle.common_name == "deep-leaf.example.com"
        assert bundle.chain_pem is not None

        warnings = validate_bundle(
            leaf_from_intermediate_pem, private_key_pem, two_level_chain_pem
        )
        assert not any("chain" in w.lower() for w in warnings)

        output_cfg: JsonDict = {
            "destination": "filesystem",
            "base_path": str(tmp_path / "deep_chain"),
            "cert_filename": "{order_id}_cert.pem",
            "key_filename": "{order_id}_key.pem",
            "chain_filename": "{order_id}_chain.pem",
        }
        result = persist_bundle(bundle, output_cfg)
        assert "filesystem_chain" in result

        policy = RenewalPolicy(before_expiry=30, unit="day")
        assert should_renew(bundle.not_after, policy) is False


# =============================================================================
# PKCS#12 full lifecycle (Fix 7)
# =============================================================================


class TestPKCS12FullLifecycle:
    def test_pkcs12_roundtrip_lifecycle(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
        rsa_private_key: rsa.RSAPrivateKey,
        tmp_path: Path,
    ) -> None:
        """Generate → assemble → persist → create P12 → parse back → validate."""
        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=None,
            source_id="p12-lifecycle",
        )
        assert verify_key_matches_certificate(private_key_pem, self_signed_cert_pem)
        assert verify_certificate_not_expired(self_signed_cert_pem)

        output_cfg: JsonDict = {
            "destination": "filesystem",
            "base_path": str(tmp_path / "p12_certs"),
            "cert_filename": "{order_id}_cert.pem",
            "key_filename": "{order_id}_key.pem",
        }
        persist_bundle(bundle, output_cfg)

        passphrase = "lifecycle-test-pass"
        p12_bytes = create_pkcs12_bundle(
            self_signed_cert_pem, private_key_pem, passphrase=passphrase
        )
        assert p12_bytes is not None
        assert len(p12_bytes) > 0

        p12_path = tmp_path / "lifecycle.p12"
        p12_path.write_bytes(p12_bytes)
        raw = p12_path.read_bytes()
        assert raw == p12_bytes

        cert_pem_out, key_pem_out, _chain_pem_out = parse_pkcs12_bundle(p12_bytes, passphrase)
        assert b"BEGIN CERTIFICATE" in cert_pem_out
        assert b"BEGIN" in key_pem_out

        assert verify_key_matches_certificate(key_pem_out, cert_pem_out)
        assert verify_certificate_not_expired(cert_pem_out)


# =============================================================================
# Filesystem write error cleanup
# =============================================================================


class TestFilesystemWriteErrorCleanup:
    """Verify partial file cleanup when writes fail mid-operation."""

    def _make_bundle(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> CertificateBundle:
        return assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=self_signed_cert_pem,
            source_id="cleanup-test",
        )

    def test_key_write_failure_cleans_up_cert_file(
        self,
        tmp_path: Path,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        """If cert writes OK but key write fails, the cert file is removed."""
        from certmesh.exceptions import CertificateExportError

        bundle = self._make_bundle(self_signed_cert_pem, private_key_pem)
        output_cfg: dict[str, Any] = {
            "destination": "filesystem",
            "base_path": str(tmp_path / "certs"),
            "cert_filename": "{order_id}_cert.pem",
            "key_filename": "{order_id}_key.pem",
        }

        _real_open = os.open
        call_count = 0

        def _failing_open(path: Any, flags: int, mode: int = 0o777) -> int:
            nonlocal call_count
            call_count += 1
            # Let cert write succeed (call 1), fail on key write (call 2)
            if call_count >= 2:
                raise OSError("Simulated disk full")
            return _real_open(path, flags, mode)

        with patch("certmesh.certificate_utils.os.open", side_effect=_failing_open):
            with pytest.raises(CertificateExportError, match="Failed to write"):
                persist_bundle(bundle, output_cfg)

        # The cert file should have been cleaned up
        cert_path = tmp_path / "certs" / "cleanup-test_cert.pem"
        assert not cert_path.exists(), "Partial cert file should be cleaned up"

    def test_mkdir_failure_raises_export_error(
        self,
        tmp_path: Path,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        """PermissionError on mkdir raises CertificateExportError."""
        from certmesh.exceptions import CertificateExportError

        bundle = self._make_bundle(self_signed_cert_pem, private_key_pem)
        output_cfg: dict[str, Any] = {
            "destination": "filesystem",
            "base_path": str(tmp_path / "noperm" / "certs"),
            "cert_filename": "{order_id}_cert.pem",
            "key_filename": "{order_id}_key.pem",
        }

        with patch.object(Path, "mkdir", side_effect=PermissionError("Permission denied")):
            with pytest.raises(CertificateExportError, match="Failed to write"):
                persist_bundle(bundle, output_cfg)
