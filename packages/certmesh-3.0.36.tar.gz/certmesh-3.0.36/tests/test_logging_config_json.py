"""Tests for certmesh.logging_config — JSON and text formatters."""

from __future__ import annotations

import json
import logging
import sys
from typing import Any
from unittest.mock import patch

from certmesh.logging_config import (
    _CertMeshJsonFormatter,
    configure_logging,
)


class TestCertMeshJsonFormatter:
    """Tests for the custom JSON formatter's add_fields method."""

    def _make_record(
        self,
        msg: str = "hello",
        level: int = logging.INFO,
        name: str = "certmesh.test",
    ) -> logging.LogRecord:
        return logging.LogRecord(
            name=name,
            level=level,
            pathname="test.py",
            lineno=1,
            msg=msg,
            args=(),
            exc_info=None,
        )

    def test_add_fields_sets_level(self) -> None:
        formatter = _CertMeshJsonFormatter()
        record = self._make_record(level=logging.WARNING)
        log_record: dict[str, Any] = {}
        formatter.add_fields(log_record, record, {})
        assert log_record["level"] == "warning"

    def test_add_fields_sets_logger(self) -> None:
        formatter = _CertMeshJsonFormatter()
        record = self._make_record(name="certmesh.acm")
        log_record: dict[str, Any] = {}
        formatter.add_fields(log_record, record, {})
        assert log_record["logger"] == "certmesh.acm"

    def test_add_fields_sets_timestamp(self) -> None:
        formatter = _CertMeshJsonFormatter()
        record = self._make_record()
        log_record: dict[str, Any] = {}
        formatter.add_fields(log_record, record, {})
        assert "timestamp" in log_record
        assert isinstance(log_record["timestamp"], str)

    def test_add_fields_removes_levelname(self) -> None:
        formatter = _CertMeshJsonFormatter()
        record = self._make_record()
        log_record: dict[str, Any] = {"levelname": "INFO"}
        formatter.add_fields(log_record, record, {})
        assert "levelname" not in log_record

    def test_add_fields_does_not_overwrite_existing_level(self) -> None:
        formatter = _CertMeshJsonFormatter()
        record = self._make_record(level=logging.ERROR)
        log_record: dict[str, Any] = {"level": "custom"}
        formatter.add_fields(log_record, record, {})
        assert log_record["level"] == "custom"

    def test_formatter_produces_valid_json(self) -> None:
        formatter = _CertMeshJsonFormatter("%(asctime)s %(levelname)s %(name)s %(message)s")
        record = self._make_record(msg="structured test")
        output = formatter.format(record)
        parsed = json.loads(output)
        assert parsed["message"] == "structured test"
        assert parsed["level"] == "info"
        assert "levelname" not in parsed


class TestConfigureLoggingJson:
    """Tests for configure_logging with JSON format."""

    def setup_method(self) -> None:
        root = logging.getLogger()
        root.handlers.clear()

    def test_json_format_uses_json_formatter(self) -> None:
        configure_logging(level="DEBUG", log_format="json")
        root = logging.getLogger()
        assert len(root.handlers) == 1
        handler = root.handlers[0]
        assert isinstance(handler.formatter, _CertMeshJsonFormatter)

    def test_json_format_handler_writes_to_stderr(self) -> None:
        configure_logging(level="INFO", log_format="json")
        handler = logging.getLogger().handlers[0]
        assert isinstance(handler, logging.StreamHandler)
        assert handler.stream is sys.stderr

    def test_json_format_sets_level(self) -> None:
        configure_logging(level="ERROR", log_format="json")
        root = logging.getLogger()
        assert root.level == logging.ERROR
        assert root.handlers[0].level == logging.ERROR


class TestConfigureLoggingText:
    """Tests for configure_logging with text format."""

    def setup_method(self) -> None:
        root = logging.getLogger()
        root.handlers.clear()

    def test_text_format_uses_standard_formatter(self) -> None:
        configure_logging(level="INFO", log_format="text")
        root = logging.getLogger()
        assert len(root.handlers) == 1
        handler = root.handlers[0]
        assert isinstance(handler.formatter, logging.Formatter)
        assert not isinstance(handler.formatter, _CertMeshJsonFormatter)

    def test_text_format_includes_expected_fields(self) -> None:
        configure_logging(level="INFO", log_format="text")
        fmt_str = logging.getLogger().handlers[0].formatter._fmt
        assert "%(asctime)s" in fmt_str
        assert "%(levelname)" in fmt_str
        assert "%(name)s" in fmt_str


class TestConfigureLoggingEnvFallback:
    """Tests for CM_LOG_FORMAT environment variable fallback."""

    def setup_method(self) -> None:
        root = logging.getLogger()
        root.handlers.clear()

    @patch.dict("os.environ", {"CM_LOG_FORMAT": "text"})
    def test_env_var_selects_text(self) -> None:
        configure_logging(level="INFO")
        handler = logging.getLogger().handlers[0]
        assert isinstance(handler.formatter, logging.Formatter)
        assert not isinstance(handler.formatter, _CertMeshJsonFormatter)

    @patch.dict("os.environ", {"CM_LOG_FORMAT": "json"})
    def test_env_var_selects_json(self) -> None:
        configure_logging(level="INFO")
        handler = logging.getLogger().handlers[0]
        assert isinstance(handler.formatter, _CertMeshJsonFormatter)

    @patch.dict("os.environ", {}, clear=True)
    def test_defaults_to_json_when_no_env(self) -> None:
        configure_logging(level="INFO")
        handler = logging.getLogger().handlers[0]
        assert isinstance(handler.formatter, _CertMeshJsonFormatter)


class TestConfigureLoggingNoisyLoggers:
    """Tests that noisy third-party loggers are quieted."""

    def setup_method(self) -> None:
        root = logging.getLogger()
        root.handlers.clear()

    def test_urllib3_set_to_warning(self) -> None:
        configure_logging(level="DEBUG", log_format="json")
        assert logging.getLogger("urllib3").level == logging.WARNING

    def test_botocore_set_to_warning(self) -> None:
        configure_logging(level="DEBUG", log_format="json")
        assert logging.getLogger("botocore").level == logging.WARNING


class TestImportFallback:
    """Test the ImportError fallback for older pythonjsonlogger."""

    def test_fallback_import_path(self) -> None:
        """Verify the module handles ImportError from pythonjsonlogger.json."""
        import importlib

        import certmesh.logging_config as mod

        # Simulate the fallback by forcing an ImportError on pythonjsonlogger.json
        real_import = (
            __builtins__.__import__ if hasattr(__builtins__, "__import__") else __import__
        )

        def fake_import(name: str, *args: Any, **kwargs: Any) -> Any:
            if name == "pythonjsonlogger.json":
                raise ImportError("no module named pythonjsonlogger.json")
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=fake_import):
            importlib.reload(mod)

        # After reload with the fallback, the formatter class should still work
        fmt = mod._CertMeshJsonFormatter()
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="check",
            args=(),
            exc_info=None,
        )
        output = fmt.format(record)
        parsed = json.loads(output)
        assert parsed["level"] == "info"

        # Restore original module state
        importlib.reload(mod)
