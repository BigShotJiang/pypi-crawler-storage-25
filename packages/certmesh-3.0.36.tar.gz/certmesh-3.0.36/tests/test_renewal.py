"""Tests for certmesh.renewal -- auto-renewal engine."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import pytest

from certmesh.exceptions import DigiCertError, LetsEncryptError, VaultError, VenafiError
from certmesh.renewal import (
    RenewalPolicy,
    RenewalResult,
    _check_digicert,
    _check_letsencrypt,
    _check_vault_pki,
    _check_venafi,
    _convert_to_seconds,
    _parse_iso_datetime,
    check_and_renew,
    should_renew,
)


class TestConvertToSeconds:
    def test_hour(self):
        assert _convert_to_seconds(1, "hour") == 3600

    def test_day(self):
        assert _convert_to_seconds(1, "day") == 86400

    def test_month(self):
        assert _convert_to_seconds(1, "month") == 2592000

    def test_year(self):
        assert _convert_to_seconds(1, "year") == 31536000

    def test_multiple_units(self):
        assert _convert_to_seconds(7, "day") == 604800

    def test_invalid_unit(self):
        with pytest.raises(ValueError, match="Invalid unit"):
            _convert_to_seconds(1, "minute")


class TestShouldRenew:
    def test_cert_expiring_within_window(self):
        not_after = datetime.now(timezone.utc) + timedelta(days=20)
        policy = RenewalPolicy(before_expiry=30, unit="day")
        assert should_renew(not_after, policy) is True

    def test_cert_not_expiring(self):
        not_after = datetime.now(timezone.utc) + timedelta(days=60)
        policy = RenewalPolicy(before_expiry=30, unit="day")
        assert should_renew(not_after, policy) is False

    def test_cert_already_expired(self):
        not_after = datetime.now(timezone.utc) - timedelta(days=1)
        policy = RenewalPolicy(before_expiry=30, unit="day")
        assert should_renew(not_after, policy) is True

    def test_none_not_after(self):
        policy = RenewalPolicy(before_expiry=30, unit="day")
        assert should_renew(None, policy) is False

    def test_naive_datetime_treated_as_utc(self):
        # Naive datetime (no tzinfo) should be treated as UTC
        not_after = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(days=20)
        policy = RenewalPolicy(before_expiry=30, unit="day")
        assert should_renew(not_after, policy) is True

    def test_hour_unit(self):
        not_after = datetime.now(timezone.utc) + timedelta(hours=5)
        policy = RenewalPolicy(before_expiry=12, unit="hour")
        assert should_renew(not_after, policy) is True

    def test_hour_unit_not_expiring(self):
        not_after = datetime.now(timezone.utc) + timedelta(hours=24)
        policy = RenewalPolicy(before_expiry=12, unit="hour")
        assert should_renew(not_after, policy) is False

    def test_exact_boundary(self):
        not_after = datetime.now(timezone.utc) + timedelta(days=30)
        policy = RenewalPolicy(before_expiry=30, unit="day")
        # At exactly 30 days, remaining == threshold, should renew (<=)
        assert should_renew(not_after, policy) is True


class TestRenewalPolicy:
    def test_defaults(self):
        policy = RenewalPolicy()
        assert policy.before_expiry == 30
        assert policy.unit == "day"
        assert policy.providers == ["all"]
        assert policy.dry_run is False

    def test_custom_values(self):
        policy = RenewalPolicy(
            before_expiry=7,
            unit="hour",
            providers=["acm", "venafi"],
            dry_run=True,
        )
        assert policy.before_expiry == 7
        assert policy.unit == "hour"
        assert policy.providers == ["acm", "venafi"]
        assert policy.dry_run is True


class TestRenewalResult:
    def test_basic_result(self):
        result = RenewalResult(
            provider="acm",
            identifier="arn:aws:acm:...",
            common_name="test.example.com",
            not_after=datetime.now(timezone.utc),
            needs_renewal=True,
            renewed=False,
        )
        assert result.provider == "acm"
        assert result.needs_renewal is True
        assert result.renewed is False
        assert result.error is None


class TestCheckAndRenew:
    def test_no_providers_configured(self):
        results = check_and_renew({}, RenewalPolicy())
        assert isinstance(results, list)

    def test_all_expands_to_all_providers(self):
        results = check_and_renew({}, RenewalPolicy(providers=["all"]))
        assert isinstance(results, list)

    def test_specific_provider(self):
        results = check_and_renew({}, RenewalPolicy(providers=["acm"]))
        assert isinstance(results, list)

    def test_dry_run_flag(self):
        policy = RenewalPolicy(dry_run=True)
        results = check_and_renew({}, policy)
        assert isinstance(results, list)


class TestParseIsoDatetime:
    def test_utc_z_suffix(self):
        dt = _parse_iso_datetime("2025-06-01T12:00:00Z")
        assert dt is not None
        assert dt.tzinfo is not None
        assert dt.year == 2025

    def test_utc_offset(self):
        dt = _parse_iso_datetime("2025-06-01T12:00:00+00:00")
        assert dt is not None
        assert dt.tzinfo is not None

    def test_empty_string_returns_none(self):
        assert _parse_iso_datetime("") is None

    def test_invalid_string_returns_none(self):
        assert _parse_iso_datetime("not-a-date") is None

    def test_naive_datetime_gets_utc(self):
        dt = _parse_iso_datetime("2025-06-01T12:00:00")
        assert dt is not None
        assert dt.tzinfo == timezone.utc


class TestCheckDigicert:
    def _make_summary(self, cert_id: int, order_id: int, cn: str, valid_till: str):
        from dataclasses import dataclass

        @dataclass
        class _Summary:
            certificate_id: int
            order_id: int
            common_name: str
            valid_till: str

        return _Summary(
            certificate_id=cert_id,
            order_id=order_id,
            common_name=cn,
            valid_till=valid_till,
        )

    def test_empty_cert_list(self):
        cfg = {"digicert": {"base_url": "https://example.com"}}
        with patch("certmesh.providers.digicert_client.list_issued_certificates", return_value=[]):
            results = _check_digicert(cfg, RenewalPolicy())
        assert results == []

    def test_cert_not_expiring(self):
        future = (datetime.now(timezone.utc) + timedelta(days=90)).strftime("%Y-%m-%d")
        summary = self._make_summary(1, 100, "example.com", future)
        cfg = {"digicert": {"base_url": "https://example.com"}}
        with patch(
            "certmesh.providers.digicert_client.list_issued_certificates",
            return_value=[summary],
        ):
            results = _check_digicert(cfg, RenewalPolicy(before_expiry=30, unit="day"))
        assert len(results) == 1
        assert results[0].needs_renewal is False
        assert results[0].renewed is False

    def test_cert_expiring_dry_run(self):
        soon = (datetime.now(timezone.utc) + timedelta(days=10)).strftime("%Y-%m-%d")
        summary = self._make_summary(1, 100, "example.com", soon)
        cfg = {"digicert": {"base_url": "https://example.com"}}
        with patch(
            "certmesh.providers.digicert_client.list_issued_certificates",
            return_value=[summary],
        ):
            results = _check_digicert(cfg, RenewalPolicy(before_expiry=30, dry_run=True))
        assert len(results) == 1
        assert results[0].needs_renewal is True
        assert results[0].renewed is False  # dry_run=True → no renewal action

    def test_cert_expiring_renews(self):
        soon = (datetime.now(timezone.utc) + timedelta(days=10)).strftime("%Y-%m-%d")
        summary = self._make_summary(1, 100, "example.com", soon)
        cfg = {"digicert": {"base_url": "https://example.com", "certificate": {"key_size": 2048}}}
        with (
            patch(
                "certmesh.providers.digicert_client.list_issued_certificates",
                return_value=[summary],
            ),
            patch(
                "certmesh.providers.digicert_client.duplicate_certificate",
                return_value={"id": 999},
            ),
        ):
            results = _check_digicert(cfg, RenewalPolicy(before_expiry=30, dry_run=False))
        assert results[0].renewed is True
        assert results[0].error is None

    def test_list_failure_returns_error_result(self):
        cfg = {"digicert": {"base_url": "https://example.com"}}
        with patch(
            "certmesh.providers.digicert_client.list_issued_certificates",
            side_effect=DigiCertError("API error"),
        ):
            results = _check_digicert(cfg, RenewalPolicy())
        assert len(results) == 1
        assert results[0].error == "API error"
        assert results[0].needs_renewal is False

    def test_renewal_failure_records_error(self):
        soon = (datetime.now(timezone.utc) + timedelta(days=10)).strftime("%Y-%m-%d")
        summary = self._make_summary(1, 100, "example.com", soon)
        cfg = {"digicert": {"base_url": "https://example.com", "certificate": {"key_size": 2048}}}
        with (
            patch(
                "certmesh.providers.digicert_client.list_issued_certificates",
                return_value=[summary],
            ),
            patch(
                "certmesh.providers.digicert_client.duplicate_certificate",
                side_effect=DigiCertError("duplicate failed"),
            ),
        ):
            results = _check_digicert(cfg, RenewalPolicy(before_expiry=30))
        assert results[0].needs_renewal is True
        assert results[0].renewed is False
        assert "duplicate failed" in results[0].error


class TestCheckVenafi:
    def _make_summary(self, guid: str, dn: str, approx_not_after: str):
        from dataclasses import dataclass

        @dataclass
        class _Summary:
            guid: str
            dn: str
            name: str = ""
            created_on: str = ""
            schema_class: str = ""
            approx_not_after: str = ""

        return _Summary(guid=guid, dn=dn, approx_not_after=approx_not_after)

    def test_empty_cert_list(self):
        cfg = {"venafi": {"base_url": "https://venafi.example.com", "auth_method": "oauth"}}
        mock_session = MagicMock()
        with (
            patch("certmesh.providers.venafi_client.authenticate", return_value=mock_session),
            patch("certmesh.providers.venafi_client.list_certificates", return_value=[]),
        ):
            results = _check_venafi(cfg, RenewalPolicy())
        assert results == []
        mock_session.close.assert_called_once()

    def test_cert_not_expiring(self):
        future = (datetime.now(timezone.utc) + timedelta(days=90)).isoformat()
        summary = self._make_summary("abc-123", "\\VED\\Policy\\test.example.com", future)
        cfg = {"venafi": {"base_url": "https://venafi.example.com", "auth_method": "oauth"}}
        mock_session = MagicMock()
        with (
            patch("certmesh.providers.venafi_client.authenticate", return_value=mock_session),
            patch("certmesh.providers.venafi_client.list_certificates", return_value=[summary]),
        ):
            results = _check_venafi(cfg, RenewalPolicy(before_expiry=30))
        assert results[0].needs_renewal is False
        mock_session.close.assert_called_once()

    def test_cert_expiring_dry_run(self):
        soon = (datetime.now(timezone.utc) + timedelta(days=5)).isoformat()
        summary = self._make_summary("abc-123", "\\VED\\Policy\\test.example.com", soon)
        cfg = {"venafi": {"base_url": "https://venafi.example.com", "auth_method": "oauth"}}
        mock_session = MagicMock()
        with (
            patch("certmesh.providers.venafi_client.authenticate", return_value=mock_session),
            patch("certmesh.providers.venafi_client.list_certificates", return_value=[summary]),
        ):
            results = _check_venafi(cfg, RenewalPolicy(before_expiry=30, dry_run=True))
        assert results[0].needs_renewal is True
        assert results[0].renewed is False

    def test_cert_expiring_renews(self):
        soon = (datetime.now(timezone.utc) + timedelta(days=5)).isoformat()
        summary = self._make_summary("abc-123", "\\VED\\Policy\\test.example.com", soon)
        cfg = {"venafi": {"base_url": "https://venafi.example.com", "auth_method": "oauth"}}
        mock_session = MagicMock()
        with (
            patch("certmesh.providers.venafi_client.authenticate", return_value=mock_session),
            patch("certmesh.providers.venafi_client.list_certificates", return_value=[summary]),
            patch("certmesh.providers.venafi_client.renew_and_download_certificate"),
        ):
            results = _check_venafi(cfg, RenewalPolicy(before_expiry=30))
        assert results[0].renewed is True

    def test_auth_failure_returns_error_result(self):
        cfg = {"venafi": {"base_url": "https://venafi.example.com", "auth_method": "oauth"}}
        with patch(
            "certmesh.providers.venafi_client.authenticate",
            side_effect=VenafiError("auth failed"),
        ):
            results = _check_venafi(cfg, RenewalPolicy())
        assert len(results) == 1
        assert results[0].error == "auth failed"

    def test_session_closed_on_list_failure(self):
        cfg = {"venafi": {"base_url": "https://venafi.example.com", "auth_method": "oauth"}}
        mock_session = MagicMock()
        with (
            patch("certmesh.providers.venafi_client.authenticate", return_value=mock_session),
            patch(
                "certmesh.providers.venafi_client.list_certificates",
                side_effect=VenafiError("list failed"),
            ),
        ):
            results = _check_venafi(cfg, RenewalPolicy())
        assert results[0].error == "list failed"
        mock_session.close.assert_called_once()


class TestCheckVaultPKI:
    def _make_pem_cert(self, cn: str, days_until_expiry: int) -> str:
        """Generate a minimal self-signed cert PEM for testing."""
        import datetime as dt

        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import NameOID

        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])
        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(dt.datetime.now(dt.timezone.utc))
            .not_valid_after(
                dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=days_until_expiry)
            )
            .sign(key, hashes.SHA256())
        )
        return cert.public_bytes(serialization.Encoding.PEM).decode()

    def test_empty_serial_list(self):
        cfg = {
            "vault": {
                "url": "https://vault.example.com",
                "auth_method": "approle",
                "pki": {"mount_point": "pki", "role_name": "test"},
            }
        }
        mock_client = MagicMock()
        with (
            patch(
                "certmesh.backends.vault_client.get_authenticated_client", return_value=mock_client
            ),
            patch("certmesh.backends.vault_client.list_pki_certificates", return_value=[]),
        ):
            results = _check_vault_pki(cfg, RenewalPolicy())
        assert results == []

    def test_cert_not_expiring(self):
        cert_pem = self._make_pem_cert("vault.example.com", 90)
        cfg = {
            "vault": {
                "url": "https://vault.example.com",
                "auth_method": "approle",
                "pki": {"mount_point": "pki", "role_name": "test"},
            }
        }
        mock_client = MagicMock()
        with (
            patch(
                "certmesh.backends.vault_client.get_authenticated_client", return_value=mock_client
            ),
            patch(
                "certmesh.backends.vault_client.list_pki_certificates", return_value=["aa:bb:cc"]
            ),
            patch(
                "certmesh.backends.vault_client.read_pki_certificate",
                return_value={"certificate": cert_pem, "revocation_time": 0},
            ),
        ):
            results = _check_vault_pki(cfg, RenewalPolicy(before_expiry=30))
        assert results[0].needs_renewal is False

    def test_revoked_cert_is_skipped(self):
        cfg = {
            "vault": {
                "url": "https://vault.example.com",
                "auth_method": "approle",
                "pki": {"mount_point": "pki", "role_name": "test"},
            }
        }
        mock_client = MagicMock()
        with (
            patch(
                "certmesh.backends.vault_client.get_authenticated_client", return_value=mock_client
            ),
            patch(
                "certmesh.backends.vault_client.list_pki_certificates", return_value=["aa:bb:cc"]
            ),
            patch(
                "certmesh.backends.vault_client.read_pki_certificate",
                return_value={"certificate": "", "revocation_time": 1700000000},
            ),
        ):
            results = _check_vault_pki(cfg, RenewalPolicy(before_expiry=30))
        assert results == []  # revoked certs are silently skipped

    def test_cert_expiring_dry_run(self):
        cert_pem = self._make_pem_cert("vault.example.com", 10)
        cfg = {
            "vault": {
                "url": "https://vault.example.com",
                "auth_method": "approle",
                "pki": {"mount_point": "pki", "role_name": "test"},
            }
        }
        mock_client = MagicMock()
        with (
            patch(
                "certmesh.backends.vault_client.get_authenticated_client", return_value=mock_client
            ),
            patch(
                "certmesh.backends.vault_client.list_pki_certificates", return_value=["aa:bb:cc"]
            ),
            patch(
                "certmesh.backends.vault_client.read_pki_certificate",
                return_value={"certificate": cert_pem, "revocation_time": 0},
            ),
        ):
            results = _check_vault_pki(cfg, RenewalPolicy(before_expiry=30, dry_run=True))
        assert results[0].needs_renewal is True
        assert results[0].renewed is False

    def test_cert_expiring_reissues(self):
        cert_pem = self._make_pem_cert("vault.example.com", 10)
        cfg = {
            "vault": {
                "url": "https://vault.example.com",
                "auth_method": "approle",
                "pki": {"mount_point": "pki", "role_name": "test"},
            }
        }
        mock_client = MagicMock()
        with (
            patch(
                "certmesh.backends.vault_client.get_authenticated_client", return_value=mock_client
            ),
            patch(
                "certmesh.backends.vault_client.list_pki_certificates", return_value=["aa:bb:cc"]
            ),
            patch(
                "certmesh.backends.vault_client.read_pki_certificate",
                return_value={"certificate": cert_pem, "revocation_time": 0},
            ),
            patch("certmesh.backends.vault_client.issue_pki_certificate", return_value={}),
        ):
            results = _check_vault_pki(cfg, RenewalPolicy(before_expiry=30))
        assert results[0].renewed is True

    def test_auth_failure_returns_error_result(self):
        cfg = {
            "vault": {
                "url": "https://vault.example.com",
                "auth_method": "approle",
                "pki": {"mount_point": "pki"},
            }
        }
        with patch(
            "certmesh.backends.vault_client.get_authenticated_client",
            side_effect=VaultError("vault unreachable"),
        ):
            results = _check_vault_pki(cfg, RenewalPolicy())
        assert len(results) == 1
        assert results[0].error == "vault unreachable"


class TestCheckLetsEncrypt:
    def _make_cert_file(self, tmp_path, cn: str, days_until_expiry: int) -> None:
        """Create a minimal self-signed cert PEM file in tmp_path."""
        import datetime as dt

        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import NameOID

        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])
        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(dt.datetime.now(dt.timezone.utc))
            .not_valid_after(
                dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=days_until_expiry)
            )
            .sign(key, hashes.SHA256())
        )
        cert_pem = cert.public_bytes(serialization.Encoding.PEM)
        (tmp_path / f"{cn}_cert.pem").write_bytes(cert_pem)

    def test_no_config_returns_empty(self):
        results = _check_letsencrypt({}, RenewalPolicy())
        assert results == []

    def test_no_base_path_returns_empty(self):
        cfg = {"letsencrypt": {"output": {}}}
        results = _check_letsencrypt(cfg, RenewalPolicy())
        assert results == []

    def test_nonexistent_dir_returns_empty(self):
        cfg = {"letsencrypt": {"output": {"base_path": "/nonexistent/path"}}}
        results = _check_letsencrypt(cfg, RenewalPolicy())
        assert results == []

    def test_no_cert_files_returns_empty(self, tmp_path):
        cfg = {"letsencrypt": {"output": {"base_path": str(tmp_path)}}}
        results = _check_letsencrypt(cfg, RenewalPolicy())
        assert results == []

    def test_cert_not_expiring(self, tmp_path):
        self._make_cert_file(tmp_path, "example.com", 90)
        cfg = {"letsencrypt": {"output": {"base_path": str(tmp_path)}}}
        results = _check_letsencrypt(cfg, RenewalPolicy(before_expiry=30, unit="day"))
        assert len(results) == 1
        assert results[0].needs_renewal is False
        assert results[0].common_name == "example.com"
        assert results[0].provider == "letsencrypt"

    def test_cert_expiring_dry_run(self, tmp_path):
        self._make_cert_file(tmp_path, "soon.example.com", 10)
        cfg = {"letsencrypt": {"output": {"base_path": str(tmp_path)}}}
        results = _check_letsencrypt(
            cfg, RenewalPolicy(before_expiry=30, unit="day", dry_run=True)
        )
        assert len(results) == 1
        assert results[0].needs_renewal is True
        assert results[0].renewed is False

    def test_cert_expiring_renews(self, tmp_path):
        self._make_cert_file(tmp_path, "renew.example.com", 5)
        cfg = {
            "letsencrypt": {
                "output": {"base_path": str(tmp_path)},
                "email": "test@example.com",
                "agree_tos": True,
            }
        }
        with (
            patch("certmesh.providers.letsencrypt_client.create_acme_client") as mock_create,
            patch("certmesh.providers.letsencrypt_client.request_certificate") as mock_request,
        ):
            mock_create.return_value = MagicMock()
            mock_request.return_value = {"certificate": "..."}
            results = _check_letsencrypt(cfg, RenewalPolicy(before_expiry=30))
        assert results[0].renewed is True
        assert results[0].error is None
        mock_create.assert_called_once()
        mock_request.assert_called_once()

    def test_renewal_failure_records_error(self, tmp_path):
        self._make_cert_file(tmp_path, "fail.example.com", 5)
        cfg = {
            "letsencrypt": {
                "output": {"base_path": str(tmp_path)},
                "email": "test@example.com",
                "agree_tos": True,
            }
        }
        with patch(
            "certmesh.providers.letsencrypt_client.create_acme_client",
            side_effect=LetsEncryptError("ACME unreachable"),
        ):
            results = _check_letsencrypt(cfg, RenewalPolicy(before_expiry=30))
        assert results[0].needs_renewal is True
        assert results[0].renewed is False
        assert "ACME unreachable" in results[0].error

    def test_multiple_certs(self, tmp_path):
        self._make_cert_file(tmp_path, "fresh.example.com", 90)
        self._make_cert_file(tmp_path, "expiring.example.com", 5)
        cfg = {"letsencrypt": {"output": {"base_path": str(tmp_path)}}}
        results = _check_letsencrypt(
            cfg, RenewalPolicy(before_expiry=30, unit="day", dry_run=True)
        )
        assert len(results) == 2
        cns = {r.common_name for r in results}
        assert "fresh.example.com" in cns
        assert "expiring.example.com" in cns
        expiring = next(r for r in results if r.common_name == "expiring.example.com")
        fresh = next(r for r in results if r.common_name == "fresh.example.com")
        assert expiring.needs_renewal is True
        assert fresh.needs_renewal is False


class TestPushgatewayMetrics:
    """Fix 8: check_and_renew pushes metrics when pushgateway_url is configured."""

    def test_check_and_renew_pushes_metrics(self):
        """When pushgateway_url is set, push_renewal_metrics is called."""
        cfg = {
            "pushgateway_url": "http://pushgw:9091",
            "providers": [],
        }
        policy = RenewalPolicy(before_expiry=30, unit="day", providers=["vault-pki"])
        with (
            patch("certmesh.renewal._check_provider", return_value=[]),
            patch("certmesh.renewal_metrics.push_renewal_metrics") as mock_push,
        ):
            check_and_renew(cfg, policy)
        mock_push.assert_called_once()
        assert mock_push.call_args[0][1] == "http://pushgw:9091"

    def test_check_and_renew_no_pushgateway(self):
        """Without pushgateway_url, push_renewal_metrics is NOT called."""
        cfg: dict = {}
        policy = RenewalPolicy(before_expiry=30, unit="day", providers=["vault-pki"])
        with (
            patch("certmesh.renewal._check_provider", return_value=[]),
            patch("certmesh.renewal_metrics.push_renewal_metrics") as mock_push,
        ):
            check_and_renew(cfg, policy)
        mock_push.assert_not_called()
