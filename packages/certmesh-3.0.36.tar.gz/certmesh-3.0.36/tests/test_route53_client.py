"""Tests for certmesh.backends.route53_client -- Route53 DNS record management.

Covers ``sync_validation_records`` and ``delete_validation_records`` with
mocked boto3 clients to achieve high branch coverage without requiring
real AWS credentials.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from botocore.exceptions import ClientError

from certmesh.backends.route53_client import (
    _DNS_VALIDATION_TTL,
    delete_validation_records,
    sync_validation_records,
)
from certmesh.exceptions import ACMValidationError

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ZONE_ID = "Z1234567890ABC"
_CERT_ARN = "arn:aws:acm:us-east-1:123456789012:certificate/abcd-1234"


def _acm_cfg(**overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {"region": "us-east-1"}
    base.update(overrides)
    return base


def _describe_cert_response(
    domain_validations: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Build a minimal ACM describe_certificate response."""
    if domain_validations is None:
        domain_validations = [
            {
                "DomainName": "example.com",
                "ResourceRecord": {
                    "Name": "_abc.example.com.",
                    "Type": "CNAME",
                    "Value": "_def.acm-validations.aws.",
                },
            },
        ]
    return {"Certificate": {"DomainValidationOptions": domain_validations}}


def _client_error(operation: str = "ChangeResourceRecordSets") -> ClientError:
    return ClientError(
        {"Error": {"Code": "InvalidInput", "Message": "bad input"}},
        operation,
    )


# ---------------------------------------------------------------------------
# sync_validation_records
# ---------------------------------------------------------------------------


class TestSyncValidationRecords:
    def test_single_record_synced(self) -> None:
        """Happy path: one validation record is upserted to Route53."""
        mock_acm = MagicMock()
        mock_acm.describe_certificate.return_value = _describe_cert_response()

        mock_r53 = MagicMock()

        with patch("certmesh.backends.route53_client.boto3.client") as mock_boto:
            mock_boto.side_effect = lambda svc, **kw: mock_acm if svc == "acm" else mock_r53
            count = sync_validation_records(_ZONE_ID, _CERT_ARN, _acm_cfg())

        assert count == 1
        mock_r53.change_resource_record_sets.assert_called_once()
        call_kwargs = mock_r53.change_resource_record_sets.call_args[1]
        assert call_kwargs["HostedZoneId"] == _ZONE_ID
        changes = call_kwargs["ChangeBatch"]["Changes"]
        assert len(changes) == 1
        assert changes[0]["Action"] == "UPSERT"
        rrs = changes[0]["ResourceRecordSet"]
        assert rrs["Name"] == "_abc.example.com."
        assert rrs["Type"] == "CNAME"
        assert rrs["TTL"] == _DNS_VALIDATION_TTL

    def test_multiple_records_synced(self) -> None:
        """Multiple SAN domains produce multiple upsert changes."""
        validations = [
            {
                "DomainName": "example.com",
                "ResourceRecord": {
                    "Name": "_a.example.com.",
                    "Type": "CNAME",
                    "Value": "_v1.acm.aws.",
                },
            },
            {
                "DomainName": "www.example.com",
                "ResourceRecord": {
                    "Name": "_b.www.example.com.",
                    "Type": "CNAME",
                    "Value": "_v2.acm.aws.",
                },
            },
        ]
        mock_acm = MagicMock()
        mock_acm.describe_certificate.return_value = _describe_cert_response(validations)

        mock_r53 = MagicMock()

        with patch("certmesh.backends.route53_client.boto3.client") as mock_boto:
            mock_boto.side_effect = lambda svc, **kw: mock_acm if svc == "acm" else mock_r53
            count = sync_validation_records(_ZONE_ID, _CERT_ARN, _acm_cfg())

        assert count == 2
        changes = mock_r53.change_resource_record_sets.call_args[1]["ChangeBatch"]["Changes"]
        assert len(changes) == 2

    def test_no_validation_records_returns_zero(self) -> None:
        """When ACM returns no ResourceRecord entries, return 0."""
        validations = [
            {"DomainName": "example.com"},  # no ResourceRecord key
        ]
        mock_acm = MagicMock()
        mock_acm.describe_certificate.return_value = _describe_cert_response(validations)

        mock_r53 = MagicMock()

        with patch("certmesh.backends.route53_client.boto3.client") as mock_boto:
            mock_boto.side_effect = lambda svc, **kw: mock_acm if svc == "acm" else mock_r53
            count = sync_validation_records(_ZONE_ID, _CERT_ARN, _acm_cfg())

        assert count == 0
        mock_r53.change_resource_record_sets.assert_not_called()

    def test_empty_domain_validations_returns_zero(self) -> None:
        """Empty DomainValidationOptions list returns 0."""
        mock_acm = MagicMock()
        mock_acm.describe_certificate.return_value = _describe_cert_response([])

        mock_r53 = MagicMock()

        with patch("certmesh.backends.route53_client.boto3.client") as mock_boto:
            mock_boto.side_effect = lambda svc, **kw: mock_acm if svc == "acm" else mock_r53
            count = sync_validation_records(_ZONE_ID, _CERT_ARN, _acm_cfg())

        assert count == 0

    def test_describe_certificate_client_error_raises(self) -> None:
        """ClientError from ACM describe_certificate wraps as ACMValidationError."""
        mock_acm = MagicMock()
        mock_acm.describe_certificate.side_effect = _client_error("DescribeCertificate")

        with (
            patch("certmesh.backends.route53_client.boto3.client", return_value=mock_acm),
            pytest.raises(ACMValidationError, match="Failed to describe certificate"),
        ):
            sync_validation_records(_ZONE_ID, _CERT_ARN, _acm_cfg())

    def test_route53_upsert_client_error_raises(self) -> None:
        """ClientError from Route53 change_resource_record_sets wraps as ACMValidationError."""
        mock_acm = MagicMock()
        mock_acm.describe_certificate.return_value = _describe_cert_response()

        mock_r53 = MagicMock()
        mock_r53.change_resource_record_sets.side_effect = _client_error()

        with (
            patch("certmesh.backends.route53_client.boto3.client") as mock_boto,
            pytest.raises(ACMValidationError, match="Failed to sync Route53 records"),
        ):
            mock_boto.side_effect = lambda svc, **kw: mock_acm if svc == "acm" else mock_r53
            sync_validation_records(_ZONE_ID, _CERT_ARN, _acm_cfg())

    def test_default_region_used_when_not_specified(self) -> None:
        """When region is absent from acm_cfg, us-east-1 is used."""
        mock_acm = MagicMock()
        mock_acm.describe_certificate.return_value = _describe_cert_response()
        mock_r53 = MagicMock()

        with patch("certmesh.backends.route53_client.boto3.client") as mock_boto:
            mock_boto.side_effect = lambda svc, **kw: mock_acm if svc == "acm" else mock_r53
            sync_validation_records(_ZONE_ID, _CERT_ARN, {})

        acm_call = mock_boto.call_args_list[0]
        assert acm_call[1].get("region_name") == "us-east-1"

    def test_custom_region_passed_to_acm_client(self) -> None:
        """Custom region in acm_cfg is forwarded to boto3.client."""
        mock_acm = MagicMock()
        mock_acm.describe_certificate.return_value = _describe_cert_response()
        mock_r53 = MagicMock()

        with patch("certmesh.backends.route53_client.boto3.client") as mock_boto:
            mock_boto.side_effect = lambda svc, **kw: mock_acm if svc == "acm" else mock_r53
            sync_validation_records(_ZONE_ID, _CERT_ARN, _acm_cfg(region="eu-west-1"))

        acm_call = mock_boto.call_args_list[0]
        assert acm_call[1].get("region_name") == "eu-west-1"

    def test_resource_record_none_is_skipped(self) -> None:
        """A domain validation with ResourceRecord explicitly set to None is skipped."""
        validations = [
            {
                "DomainName": "example.com",
                "ResourceRecord": None,
            },
            {
                "DomainName": "good.example.com",
                "ResourceRecord": {
                    "Name": "_g.good.example.com.",
                    "Type": "CNAME",
                    "Value": "_v.acm.aws.",
                },
            },
        ]
        mock_acm = MagicMock()
        mock_acm.describe_certificate.return_value = _describe_cert_response(validations)
        mock_r53 = MagicMock()

        with patch("certmesh.backends.route53_client.boto3.client") as mock_boto:
            mock_boto.side_effect = lambda svc, **kw: mock_acm if svc == "acm" else mock_r53
            count = sync_validation_records(_ZONE_ID, _CERT_ARN, _acm_cfg())

        assert count == 1

    def test_missing_certificate_key_returns_zero(self) -> None:
        """If response has no Certificate key, return 0."""
        mock_acm = MagicMock()
        mock_acm.describe_certificate.return_value = {}
        mock_r53 = MagicMock()

        with patch("certmesh.backends.route53_client.boto3.client") as mock_boto:
            mock_boto.side_effect = lambda svc, **kw: mock_acm if svc == "acm" else mock_r53
            count = sync_validation_records(_ZONE_ID, _CERT_ARN, _acm_cfg())

        assert count == 0

    def test_change_batch_comment_for_sync(self) -> None:
        """Verify the ChangeBatch comment for sync operations."""
        mock_acm = MagicMock()
        mock_acm.describe_certificate.return_value = _describe_cert_response()
        mock_r53 = MagicMock()

        with patch("certmesh.backends.route53_client.boto3.client") as mock_boto:
            mock_boto.side_effect = lambda svc, **kw: mock_acm if svc == "acm" else mock_r53
            sync_validation_records(_ZONE_ID, _CERT_ARN, _acm_cfg())

        call_kwargs = mock_r53.change_resource_record_sets.call_args[1]
        assert call_kwargs["ChangeBatch"]["Comment"] == "certmesh ACM DNS validation"


# ---------------------------------------------------------------------------
# delete_validation_records
# ---------------------------------------------------------------------------


class TestDeleteValidationRecords:
    def test_single_record_deleted(self) -> None:
        records = [
            {"Name": "_abc.example.com.", "Type": "CNAME", "Value": "_def.acm.aws."},
        ]
        mock_r53 = MagicMock()

        with patch("certmesh.backends.route53_client.boto3.client", return_value=mock_r53):
            count = delete_validation_records(_ZONE_ID, records)

        assert count == 1
        mock_r53.change_resource_record_sets.assert_called_once()
        call_kwargs = mock_r53.change_resource_record_sets.call_args[1]
        changes = call_kwargs["ChangeBatch"]["Changes"]
        assert changes[0]["Action"] == "DELETE"
        assert changes[0]["ResourceRecordSet"]["TTL"] == _DNS_VALIDATION_TTL

    def test_multiple_records_deleted(self) -> None:
        records = [
            {"Name": "_a.example.com.", "Type": "CNAME", "Value": "_v1.acm.aws."},
            {"Name": "_b.example.com.", "Type": "CNAME", "Value": "_v2.acm.aws."},
            {"Name": "_c.example.com.", "Type": "CNAME", "Value": "_v3.acm.aws."},
        ]
        mock_r53 = MagicMock()

        with patch("certmesh.backends.route53_client.boto3.client", return_value=mock_r53):
            count = delete_validation_records(_ZONE_ID, records)

        assert count == 3
        changes = mock_r53.change_resource_record_sets.call_args[1]["ChangeBatch"]["Changes"]
        assert all(c["Action"] == "DELETE" for c in changes)

    def test_empty_records_returns_zero(self) -> None:
        mock_r53 = MagicMock()

        with patch("certmesh.backends.route53_client.boto3.client", return_value=mock_r53):
            count = delete_validation_records(_ZONE_ID, [])

        assert count == 0
        mock_r53.change_resource_record_sets.assert_not_called()

    def test_route53_delete_client_error_raises(self) -> None:
        records = [
            {"Name": "_abc.example.com.", "Type": "CNAME", "Value": "_def.acm.aws."},
        ]
        mock_r53 = MagicMock()
        mock_r53.change_resource_record_sets.side_effect = _client_error()

        with (
            patch("certmesh.backends.route53_client.boto3.client", return_value=mock_r53),
            pytest.raises(ACMValidationError, match="Failed to delete Route53 records"),
        ):
            delete_validation_records(_ZONE_ID, records)

    def test_change_batch_comment(self) -> None:
        """Verify the ChangeBatch comment for cleanup operations."""
        records = [
            {"Name": "_abc.example.com.", "Type": "CNAME", "Value": "_def.acm.aws."},
        ]
        mock_r53 = MagicMock()

        with patch("certmesh.backends.route53_client.boto3.client", return_value=mock_r53):
            delete_validation_records(_ZONE_ID, records)

        call_kwargs = mock_r53.change_resource_record_sets.call_args[1]
        assert call_kwargs["ChangeBatch"]["Comment"] == "certmesh cleanup"

    def test_hosted_zone_id_passed_correctly(self) -> None:
        records = [
            {"Name": "_x.example.com.", "Type": "CNAME", "Value": "_y.acm.aws."},
        ]
        mock_r53 = MagicMock()
        custom_zone = "Z9876543210XYZ"

        with patch("certmesh.backends.route53_client.boto3.client", return_value=mock_r53):
            delete_validation_records(custom_zone, records)

        call_kwargs = mock_r53.change_resource_record_sets.call_args[1]
        assert call_kwargs["HostedZoneId"] == custom_zone


# ---------------------------------------------------------------------------
# Module constants
# ---------------------------------------------------------------------------


class TestModuleConstants:
    def test_dns_validation_ttl_value(self) -> None:
        assert _DNS_VALIDATION_TTL == 300
