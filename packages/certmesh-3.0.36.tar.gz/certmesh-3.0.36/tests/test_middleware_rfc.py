"""Unit tests for RFC 7807 error handling in middleware."""

import pytest

from certmesh.api.middleware import (
    _STATUS_ERROR_TYPES,
    _build_error_body,
    _resolve_status_code,
)
from certmesh.exceptions import (
    ACMRequestError,
    ACMValidationError,
    CertificateError,
    CircuitBreakerOpenError,
    ConfigurationError,
    DigiCertAPIError,
    DigiCertAuthenticationError,
    DigiCertCertificateNotReadyError,
    DigiCertOrderNotFoundError,
    DigiCertPollingTimeoutError,
    DigiCertRateLimitError,
    LetsEncryptChallengeError,
    LetsEncryptRateLimitError,
    VaultAuthenticationError,
    VaultPKIError,
    VaultSecretNotFoundError,
    VaultWriteError,
    VenafiAuthenticationError,
    VenafiCertificateNotFoundError,
    VenafiPollingTimeoutError,
    VenafiPrivateKeyExportError,
)


class TestResolveStatusCode:
    """Verify correct RFC HTTP status codes for each exception type."""

    @pytest.mark.parametrize(
        "exc_class,expected_code",
        [
            # 400 Bad Request
            (CertificateError, 400),
            (ACMValidationError, 400),
            # 401 Unauthorized
            (VaultAuthenticationError, 401),
            (DigiCertAuthenticationError, 401),
            (VenafiAuthenticationError, 401),
            # 403 Forbidden
            (VenafiPrivateKeyExportError, 403),
            # 404 Not Found
            (VaultSecretNotFoundError, 404),
            (DigiCertOrderNotFoundError, 404),
            (VenafiCertificateNotFoundError, 404),
            # 408 Request Timeout
            (DigiCertPollingTimeoutError, 408),
            (VenafiPollingTimeoutError, 408),
            # 409 Conflict
            (DigiCertCertificateNotReadyError, 409),
            (LetsEncryptChallengeError, 409),
            # 429 Too Many Requests
            (DigiCertRateLimitError, 429),
            (LetsEncryptRateLimitError, 429),
            # 500 Internal Server Error
            (ConfigurationError, 500),
            (VaultWriteError, 500),
            # 502 Bad Gateway
            (DigiCertAPIError, 502),
            (VaultPKIError, 502),
            (ACMRequestError, 502),
            # 503 Service Unavailable
            (CircuitBreakerOpenError, 503),
        ],
    )
    def test_exception_to_status_code(self, exc_class, expected_code):
        if exc_class == DigiCertRateLimitError:
            exc = exc_class("rate limited", retry_after="60")
        elif exc_class == DigiCertAPIError:
            exc = exc_class("api error", status_code=500, body="error")
        else:
            exc = exc_class("test error")
        assert _resolve_status_code(exc) == expected_code


class TestBuildErrorBody:
    def test_basic_error_body(self):
        body = _build_error_body(404, "Not found", "req-123")
        assert body["error"] == "not_found"
        assert body["status"] == 404
        assert body["detail"] == "Not found"
        assert body["request_id"] == "req-123"

    def test_error_body_with_retry_after(self):
        body = _build_error_body(429, "Rate limited", "req-456", retry_after="60")
        assert body["error"] == "too_many_requests"
        assert body["retry_after_seconds"] == 60

    def test_error_body_custom_error_type(self):
        body = _build_error_body(502, "Upstream fail", "req-789", error_type="DigiCertAPIError")
        assert body["error"] == "DigiCertAPIError"

    def test_all_rfc_status_codes_have_types(self):
        """Ensure all mapped status codes have human-readable error types."""
        for code in [400, 401, 403, 404, 408, 409, 422, 429, 500, 502, 503]:
            assert code in _STATUS_ERROR_TYPES

    def test_unknown_status_code_fallback(self):
        body = _build_error_body(418, "I'm a teapot", "req-000")
        assert body["error"] == "error"  # fallback


class TestSanitizeDetail:
    """SEC-15: Verify error details are sanitized to prevent information leaks."""

    def test_401_does_not_leak_vault_url(self):
        from certmesh.api.middleware import _sanitize_detail

        exc = VaultAuthenticationError(
            "Failed to auth at https://vault.internal.corp:8200/v1/auth/approle/login"
        )
        detail = _sanitize_detail(401, exc)
        assert "vault.internal.corp" not in detail
        assert "8200" not in detail
        assert "Authentication failed" in detail

    def test_404_does_not_leak_secret_path(self):
        from certmesh.api.middleware import _sanitize_detail

        exc = VaultSecretNotFoundError("Secret not found at secret/data/certmesh/digicert/api_key")
        detail = _sanitize_detail(404, exc)
        assert "secret/data" not in detail
        assert "digicert" not in detail
        assert "not found" in detail.lower()

    def test_403_does_not_leak_details(self):
        from certmesh.api.middleware import _sanitize_detail

        exc = VenafiPrivateKeyExportError(
            "Export denied for CN=internal.corp policy \\VED\\Policy\\certs"
        )
        detail = _sanitize_detail(403, exc)
        assert "internal.corp" not in detail
        assert "VED" not in detail
        assert "Access denied" in detail

    def test_500_returns_generic_message(self):
        from certmesh.api.middleware import _sanitize_detail

        exc = ConfigurationError("Vault URL https://vault.corp:8200 not reachable")
        detail = _sanitize_detail(500, exc)
        assert "vault.corp" not in detail
        assert "internal error" in detail.lower()

    def test_400_preserves_useful_detail(self):
        from certmesh.api.middleware import _sanitize_detail

        exc = CertificateError("Invalid certificate PEM: no BEGIN CERTIFICATE delimiter")
        detail = _sanitize_detail(400, exc)
        assert "BEGIN CERTIFICATE" in detail

    def test_429_preserves_rate_limit_detail(self):
        from certmesh.api.middleware import _sanitize_detail

        exc = DigiCertRateLimitError("Rate limited, retry after 60s")
        detail = _sanitize_detail(429, exc)
        assert "Rate limited" in detail


class TestRequestBodyLimitMiddleware:
    """SEC-16: Verify request body size limits are enforced."""

    def test_oversized_content_length_rejected(self):
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        from certmesh.api.middleware import RequestBodyLimitMiddleware

        app = FastAPI()
        app.add_middleware(RequestBodyLimitMiddleware, max_size=1024)

        @app.post("/test")
        async def _test_endpoint():
            return {"ok": True}

        client = TestClient(app)
        resp = client.post(
            "/test",
            content=b"x",
            headers={"Content-Length": "2048"},
        )
        assert resp.status_code == 413
        assert "too large" in resp.json()["detail"].lower()

    def test_normal_content_length_accepted(self):
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        from certmesh.api.middleware import RequestBodyLimitMiddleware

        app = FastAPI()
        app.add_middleware(RequestBodyLimitMiddleware, max_size=1024)

        @app.post("/test")
        async def _test_endpoint():
            return {"ok": True}

        client = TestClient(app)
        resp = client.post(
            "/test",
            content=b"hello",
            headers={"Content-Length": "5"},
        )
        assert resp.status_code == 200

    def test_no_content_length_passes_through(self):
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        from certmesh.api.middleware import RequestBodyLimitMiddleware

        app = FastAPI()
        app.add_middleware(RequestBodyLimitMiddleware, max_size=1024)

        @app.get("/test")
        async def _test_endpoint():
            return {"ok": True}

        client = TestClient(app)
        resp = client.get("/test")
        assert resp.status_code == 200


# =============================================================================
# _REQUEST_ID_RE — regex validation
# =============================================================================


class TestRequestIdRegex:
    """Verify the request ID regex rejects malicious patterns."""

    @pytest.fixture()
    def regex(self):
        from certmesh.api.middleware import _REQUEST_ID_RE

        return _REQUEST_ID_RE

    @pytest.mark.parametrize(
        "valid_id",
        [
            "abc-123",
            "req.456",
            "a_b_c",
            "A" * 128,
            "simple",
            "uuid-like-a1b2c3d4-e5f6",
        ],
    )
    def test_valid_request_ids_accepted(self, regex, valid_id: str) -> None:
        assert regex.match(valid_id) is not None

    def test_rejects_newlines(self, regex) -> None:
        assert regex.match("id\ninjected-log-line") is None

    def test_rejects_carriage_return(self, regex) -> None:
        assert regex.match("id\r\nX-Injected: true") is None

    def test_rejects_spaces(self, regex) -> None:
        assert regex.match("id with spaces") is None

    def test_rejects_too_long(self, regex) -> None:
        assert regex.match("A" * 200) is None

    def test_rejects_special_chars(self, regex) -> None:
        for char in "$(){};<>|&!@#%^*":
            assert regex.match(f"id{char}bad") is None, f"Should reject '{char}'"

    def test_rejects_empty_string(self, regex) -> None:
        assert regex.match("") is None

    def test_rejects_null_byte(self, regex) -> None:
        assert regex.match("id\x00suffix") is None
