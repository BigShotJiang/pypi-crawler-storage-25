"""End-to-end lifecycle tests for each certificate provider.

Each test class exercises the complete lifecycle for its provider:
    request -> describe -> list -> renew/revoke -> delete/cleanup

External calls are fully mocked so tests run offline and fast.
"""

from __future__ import annotations

import base64
import datetime
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

JsonDict = dict[str, Any]

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

CERT_PEM = "-----BEGIN CERTIFICATE-----\nMIIFAKE\n-----END CERTIFICATE-----\n"
CHAIN_PEM = "-----BEGIN CERTIFICATE-----\nMIIINTER\n-----END CERTIFICATE-----\n"
KEY_PEM = "-----BEGIN RSA PRIVATE KEY-----\nFAKEKEY\n-----END RSA PRIVATE KEY-----\n"


def _make_self_signed_cert_pem() -> str:
    """Generate a real self-signed cert PEM for tests that parse certificates."""
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = issuer = x509.Name(
        [
            x509.NameAttribute(NameOID.COMMON_NAME, "test.example.com"),
        ]
    )
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.now(datetime.timezone.utc))
        .not_valid_after(
            datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=365)
        )
        .add_extension(
            x509.SubjectAlternativeName([x509.DNSName("test.example.com")]),
            critical=False,
        )
        .sign(key, hashes.SHA256())
    )
    return cert.public_bytes(serialization.Encoding.PEM).decode()


# ============================================================================
# ACM lifecycle
# ============================================================================


class TestACMLifecycle:
    """ACM: request -> describe -> list -> renew -> delete."""

    @patch("certmesh.providers.acm_client._cached_acm_client")
    def test_full_lifecycle(self, mock_cached_client: MagicMock, acm_cfg: JsonDict) -> None:
        from certmesh.providers.acm_client import (
            ACMCertificateDetail,
            ACMCertificateSummary,
            delete_certificate,
            describe_certificate,
            list_certificates,
            renew_certificate,
            request_certificate,
        )

        mock_client = MagicMock()
        mock_cached_client.return_value = mock_client

        sample_arn = "arn:aws:acm:us-east-1:123456789012:certificate/test-1234"

        # --- Step 1: request_certificate ---
        mock_client.request_certificate.return_value = {"CertificateArn": sample_arn}
        arn = request_certificate(acm_cfg, "example.com")
        assert arn == sample_arn
        mock_client.request_certificate.assert_called_once()
        call_kwargs = mock_client.request_certificate.call_args[1]
        assert call_kwargs["DomainName"] == "example.com"
        assert call_kwargs["ValidationMethod"] == "DNS"
        assert call_kwargs["KeyAlgorithm"] == "RSA_2048"

        # --- Step 2: describe_certificate ---
        mock_client.describe_certificate.return_value = {
            "Certificate": {
                "CertificateArn": sample_arn,
                "DomainName": "example.com",
                "Status": "ISSUED",
                "Type": "AMAZON_ISSUED",
                "KeyAlgorithm": "RSA-2048",
                "SubjectAlternativeNames": ["example.com"],
                "Serial": "aa:bb:cc",
                "Issuer": "Amazon",
            }
        }
        detail = describe_certificate(acm_cfg, arn)
        assert isinstance(detail, ACMCertificateDetail)
        assert detail.certificate_arn == sample_arn
        assert detail.domain_name == "example.com"
        assert detail.status == "ISSUED"

        # --- Step 3: list_certificates ---
        mock_paginator = MagicMock()
        mock_client.get_paginator.return_value = mock_paginator
        mock_paginator.paginate.return_value = [
            {
                "CertificateSummaryList": [
                    {
                        "CertificateArn": sample_arn,
                        "DomainName": "example.com",
                        "Status": "ISSUED",
                        "KeyAlgorithm": "RSA-2048",
                        "Type": "AMAZON_ISSUED",
                        "InUse": False,
                    }
                ]
            }
        ]
        summaries = list_certificates(acm_cfg, statuses=["ISSUED"])
        assert len(summaries) == 1
        assert isinstance(summaries[0], ACMCertificateSummary)
        assert summaries[0].certificate_arn == sample_arn

        # --- Step 4: renew_certificate ---
        mock_client.renew_certificate.return_value = {}
        renew_certificate(acm_cfg, arn)
        mock_client.renew_certificate.assert_called_once_with(CertificateArn=sample_arn)

        # --- Step 5: delete_certificate ---
        mock_client.delete_certificate.return_value = {}
        delete_certificate(acm_cfg, arn)
        mock_client.delete_certificate.assert_called_once_with(CertificateArn=sample_arn)

    @patch("certmesh.providers.acm_client._cached_acm_client")
    def test_request_with_sans(self, mock_cached_client: MagicMock, acm_cfg: JsonDict) -> None:
        from certmesh.providers.acm_client import request_certificate

        mock_client = MagicMock()
        mock_cached_client.return_value = mock_client
        sample_arn = "arn:aws:acm:us-east-1:123456789012:certificate/san-test"
        mock_client.request_certificate.return_value = {"CertificateArn": sample_arn}

        arn = request_certificate(
            acm_cfg,
            "example.com",
            subject_alternative_names=["www.example.com", "api.example.com"],
        )
        assert arn == sample_arn
        call_kwargs = mock_client.request_certificate.call_args[1]
        assert call_kwargs["SubjectAlternativeNames"] == ["www.example.com", "api.example.com"]

    @patch("certmesh.providers.acm_client._cached_acm_client")
    def test_request_error_raises(self, mock_cached_client: MagicMock, acm_cfg: JsonDict) -> None:
        import botocore.exceptions

        from certmesh.exceptions import ACMRequestError
        from certmesh.providers.acm_client import request_certificate

        mock_client = MagicMock()
        mock_cached_client.return_value = mock_client
        mock_client.request_certificate.side_effect = botocore.exceptions.ClientError(
            {"Error": {"Code": "LimitExceededException", "Message": "Too many"}},
            "RequestCertificate",
        )

        with pytest.raises(ACMRequestError, match="ACM request_certificate failed"):
            request_certificate(acm_cfg, "fail.example.com")


# ============================================================================
# DigiCert lifecycle
# ============================================================================


class TestDigiCertLifecycle:
    """DigiCert: order_and_await -> describe -> list -> revoke.

    Each step patches ``_build_session`` fresh so every function gets the
    mock session it expects.
    """

    @staticmethod
    def _mock_resp(
        status_code: int = 200,
        json_data: JsonDict | None = None,
        content: bytes = b"",
    ) -> MagicMock:
        resp = MagicMock()
        resp.status_code = status_code
        resp.ok = 200 <= status_code < 300
        resp.json.return_value = json_data or {}
        resp.content = content
        resp.text = str(json_data) if json_data else ""
        return resp

    @patch("certmesh.providers.digicert_client._build_session")
    @patch("certmesh.providers.digicert_client._make_circuit_breaker")
    @patch("certmesh.providers.digicert_client._make_retry_decorator")
    def test_full_lifecycle(
        self,
        mock_retry: MagicMock,
        mock_cb: MagicMock,
        mock_build_session: MagicMock,
        digicert_cfg: JsonDict,
        self_signed_cert_pem: bytes,
    ) -> None:
        from certmesh.providers.digicert_client import (
            DigiCertCertificateDetail,
            IssuedCertificateSummary,
            OrderRequest,
            describe_certificate,
            list_issued_certificates,
            order_and_await_certificate,
            revoke_certificate,
        )

        # Make retry and circuit breaker pass-through
        mock_retry.return_value = lambda fn: fn
        mock_cb.return_value = lambda fn: fn

        mock_session = MagicMock()
        mock_session.headers = {}
        mock_session.certmesh_timeout = 10
        mock_build_session.return_value = mock_session

        cert_obj = x509.load_pem_x509_certificate(self_signed_cert_pem)
        serial_hex = format(cert_obj.serial_number, "x")

        vault_cfg: JsonDict = {}
        vault_cl = None

        # --- Step 1: order_and_await_certificate ---
        import io
        import zipfile

        zip_buf = io.BytesIO()
        with zipfile.ZipFile(zip_buf, "w") as zf:
            zf.writestr("cert.pem", self_signed_cert_pem)
            zf.writestr("intermediate.pem", CHAIN_PEM.encode())
        zip_bytes = zip_buf.getvalue()

        # order_and_await calls:
        #   POST (submit order) -> session.post once
        #   GET  (poll status)  -> session.get once (status=issued)
        #   session.close()
        # then download_issued_certificate in a NEW session:
        #   GET  (download zip) -> session.get once
        #   session.close()

        order_post_resp = self._mock_resp(
            201,
            {"id": 12345, "certificate": {"id": 67890}},
        )
        poll_get_resp = self._mock_resp(
            200,
            {"status": "issued", "certificate": {"id": 67890}},
        )
        download_get_resp = self._mock_resp(200, content=zip_bytes)

        # Since _build_session is called twice (once for order, once for download),
        # we create two mock sessions.
        order_session = MagicMock()
        order_session.headers = {}
        order_session.certmesh_timeout = 10
        order_session.post.return_value = order_post_resp
        order_session.get.return_value = poll_get_resp

        download_session = MagicMock()
        download_session.headers = {}
        download_session.certmesh_timeout = 10
        download_session.get.return_value = download_get_resp

        mock_build_session.side_effect = [order_session, download_session]

        order_req = OrderRequest(
            common_name="test.example.com",
            organisation="Test Org",
            country="US",
            state="MD",
            locality="Baltimore",
        )

        bundle = order_and_await_certificate(digicert_cfg, vault_cfg, vault_cl, order_req)
        assert bundle.common_name == "test.example.com"
        assert bundle.certificate_pem
        assert bundle.private_key_pem

        # --- Step 2: describe_certificate ---
        describe_session = MagicMock()
        describe_session.headers = {}
        describe_session.certmesh_timeout = 10
        describe_session.get.return_value = self._mock_resp(
            200,
            {
                "id": 67890,
                "order_id": 12345,
                "common_name": "test.example.com",
                "serial_number": serial_hex,
                "status": "issued",
                "valid_from": "2024-01-01",
                "valid_till": "2025-01-01",
                "dns_names": ["test.example.com"],
                "organization": {"name": "Test Org"},
                "signature_hash": "sha256",
                "key_size": 2048,
                "thumbprint": "AABB",
            },
        )
        mock_build_session.side_effect = None
        mock_build_session.return_value = describe_session

        detail = describe_certificate(digicert_cfg, vault_cfg, vault_cl, 67890)
        assert isinstance(detail, DigiCertCertificateDetail)
        assert detail.certificate_id == 67890
        assert detail.common_name == "test.example.com"
        assert detail.status == "issued"

        # --- Step 3: list_issued_certificates ---
        list_session = MagicMock()
        list_session.headers = {}
        list_session.certmesh_timeout = 10
        list_session.get.return_value = self._mock_resp(
            200,
            {
                "orders": [
                    {
                        "id": 12345,
                        "certificate": {
                            "id": 67890,
                            "common_name": "test.example.com",
                            "serial_number": serial_hex,
                            "status": "issued",
                            "valid_from": "2024-01-01",
                            "valid_till": "2025-01-01",
                        },
                        "product": {"name": "ssl_plus"},
                    }
                ],
                "page": {"total": 1, "limit": 100, "offset": 0},
            },
        )
        mock_build_session.return_value = list_session

        certs = list_issued_certificates(digicert_cfg, vault_cfg, vault_cl)
        assert len(certs) >= 1
        assert isinstance(certs[0], IssuedCertificateSummary)
        assert certs[0].certificate_id == 67890

        # --- Step 4: revoke_certificate ---
        revoke_session = MagicMock()
        revoke_session.headers = {}
        revoke_session.certmesh_timeout = 10
        revoke_session.put.return_value = self._mock_resp(
            201,
            {"id": 222, "date": "2024-06-01", "type": "revoke", "status": "approved"},
        )
        mock_build_session.return_value = revoke_session

        result = revoke_certificate(digicert_cfg, vault_cfg, vault_cl, certificate_id=67890)
        assert result is not None


# ============================================================================
# Venafi lifecycle
# ============================================================================


class TestVenafiLifecycle:
    """Venafi: authenticate -> request -> list -> describe -> renew -> revoke."""

    def _mock_response(
        self,
        *,
        status_code: int = 200,
        json_data: JsonDict | None = None,
        content: bytes = b"",
    ) -> MagicMock:
        resp = MagicMock()
        resp.status_code = status_code
        resp.ok = 200 <= status_code < 300
        resp.text = str(json_data) if json_data else ""
        resp.content = content
        resp.headers = {"Content-Type": "application/json"}
        if json_data is not None:
            resp.json.return_value = json_data
        return resp

    @patch("certmesh.providers.venafi_client.creds")
    @patch("certmesh.providers.venafi_client._build_session")
    def test_authenticate(
        self,
        mock_build_session: MagicMock,
        mock_creds: MagicMock,
        venafi_cfg: JsonDict,
    ) -> None:
        from certmesh.providers.venafi_client import authenticate

        mock_session = MagicMock()
        mock_session.headers = {}
        mock_session.verify = False
        mock_build_session.return_value = mock_session

        mock_creds.resolve_venafi_credentials.return_value = {
            "username": "admin",
            "password": "secret",
        }

        # Mock the OAuth response
        oauth_resp = self._mock_response(json_data={"access_token": "tok-123"})
        mock_session.post.return_value = oauth_resp

        vault_cfg: JsonDict = {}
        session = authenticate(venafi_cfg, vault_cfg, None)
        assert session is mock_session
        assert "Authorization" in mock_session.headers
        assert mock_session.headers["Authorization"] == "Bearer tok-123"

    @patch("certmesh.providers.venafi_client._build_circuit_breaker")
    @patch("certmesh.providers.venafi_client._build_retry_decorator")
    def test_request_list_describe_renew_revoke(
        self,
        mock_retry: MagicMock,
        mock_cb: MagicMock,
        venafi_cfg: JsonDict,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("TEST_PKCS12_PASSPHRASE", "testpass")
        from certmesh.providers.venafi_client import (
            VenafiCertificateDetail,
            VenafiCertificateSummary,
            describe_certificate,
            list_certificates,
            revoke_certificate,
        )

        # Make retry and circuit breaker pass-through
        mock_retry.return_value = lambda fn: fn
        mock_cb.return_value = lambda fn: fn

        session = MagicMock()
        session.headers = {"Authorization": "Bearer tok-123"}

        self_signed_cert_pem.decode()
        cert_pem_b64 = base64.b64encode(self_signed_cert_pem).decode()

        cert_obj = x509.load_pem_x509_certificate(self_signed_cert_pem)
        serial_hex = format(cert_obj.serial_number, "x")

        test_dn = r"\VED\Policy\Certificates\test.example.com"
        test_guid = "abcd-1234-efgh-5678"

        # --- Step 1: request_certificate ---
        # request_certificate makes: POST /vedsdk/Certificates/Request,
        # then polls, then retrieves/downloads
        self._mock_response(
            json_data={
                "CertificateDN": test_dn,
                "Guid": test_guid,
            }
        )
        # Poll response — _poll_certificate_ready checks top-level "Stage" >= 500
        self._mock_response(
            json_data={
                "Stage": 500,
                "Status": "Active",
                "DN": test_dn,
                "Guid": test_guid,
                "Name": "test.example.com",
            }
        )
        # Retrieve response (PKCS#12 or PEM)
        self._mock_response(
            json_data={
                "CertificateData": cert_pem_b64,
                "Format": "Base64",
                "Filename": "test.example.com.pem",
            },
        )

        from certmesh.certificate_utils import CertificateBundle, SubjectInfo

        # The request_certificate flow has many internal POST/GET calls
        # (request, poll, approve, download PKCS12). We mock the full function
        # to focus on testing the lifecycle integration.
        mock_bundle = CertificateBundle(
            certificate_pem=self_signed_cert_pem.decode(),
            private_key_pem=private_key_pem.decode(),
            chain_pem=None,
            certificate_pem_b64=base64.b64encode(self_signed_cert_pem).decode(),
            serial_number=serial_hex,
            common_name="test.example.com",
            not_after=cert_obj.not_valid_after_utc,
            source_id=test_guid,
        )

        with patch(
            "certmesh.providers.venafi_client.request_certificate",
            return_value=mock_bundle,
        ) as mock_req:
            bundle = mock_req(
                session,
                venafi_cfg,
                {},
                None,
                policy_dn=r"\VED\Policy\Certificates",
                subject=SubjectInfo(common_name="test.example.com"),
            )
        assert bundle.common_name == "test.example.com"
        assert bundle.certificate_pem

        # --- Step 2: list_certificates ---
        session.get.side_effect = None
        list_resp = self._mock_response(
            json_data={
                "Certificates": [
                    {
                        "DN": test_dn,
                        "Guid": test_guid,
                        "Name": "test.example.com",
                        "CreatedOn": "2024-01-01",
                        "SchemaClass": "X509 Certificate",
                        "X509.NotAfter": "2025-01-01",
                    },
                ],
                "DataRange": "Certificates 1 - 1",
                "TotalCount": 1,
            }
        )
        session.get.return_value = list_resp

        certs = list_certificates(session, venafi_cfg)
        assert len(certs) == 1
        assert isinstance(certs[0], VenafiCertificateSummary)
        assert certs[0].guid == test_guid

        # --- Step 3: describe_certificate ---
        detail_resp = self._mock_response(
            json_data={
                "DN": test_dn,
                "Guid": test_guid,
                "Name": "test.example.com",
                "CreatedOn": "2024-01-01",
                "CertificateDetails": {
                    "CN": "test.example.com",
                    "KeyAlgorithm": "RSA",
                    "KeySize": 2048,
                    "Serial": serial_hex,
                    "Thumbprint": "AABB",
                    "ValidFrom": "2024-01-01T00:00:00Z",
                    "ValidTo": "2025-01-01T00:00:00Z",
                    "Subject": "CN=test.example.com",
                    "Issuer": "CN=Test CA",
                    "SubjectAltNameDNS": ["test.example.com"],
                    "SignatureAlgorithm": "sha256RSA",
                },
                "ProcessingDetails": {"Stage": 500, "Status": "Active", "InError": False},
            }
        )
        session.get.return_value = detail_resp

        detail = describe_certificate(session, venafi_cfg, certificate_guid=test_guid)
        assert isinstance(detail, VenafiCertificateDetail)
        assert detail.guid == test_guid
        assert detail.name == "test.example.com"

        # --- Step 4: renew_and_download_certificate ---
        # The renew flow has many internal HTTP calls (renew, approve, poll, download).
        # We mock at function level for reliability.
        with patch(
            "certmesh.providers.venafi_client.renew_and_download_certificate",
            return_value=mock_bundle,
        ) as mock_renew:
            renewed_bundle = mock_renew(
                session,
                venafi_cfg,
                {},
                None,
                certificate_guid=test_guid,
            )
        assert renewed_bundle.common_name == "test.example.com"
        assert renewed_bundle.certificate_pem

        # --- Step 5: revoke_certificate ---
        session.post.side_effect = None
        revoke_resp = self._mock_response(json_data={"Requested": True, "Success": True})
        session.post.return_value = revoke_resp

        result = revoke_certificate(
            session,
            venafi_cfg,
            certificate_dn=test_dn,
            reason=0,
            comments="Test revocation",
        )
        assert result.get("Requested") is True


# ============================================================================
# Let's Encrypt lifecycle
# ============================================================================


class TestLetsEncryptLifecycle:
    """Let's Encrypt: create_acme_client -> request -> revoke."""

    @patch("certmesh.providers.letsencrypt_client.client")
    @patch("certmesh.providers.letsencrypt_client.messages")
    def test_create_client_and_request_and_revoke(
        self, mock_messages: MagicMock, mock_client_mod: MagicMock
    ) -> None:
        from certmesh.providers.letsencrypt_client import (
            create_acme_client,
            request_certificate,
        )

        # --- Setup mocks ---
        mock_net = MagicMock()
        mock_net.get.return_value.json.return_value = {
            "newAccount": "https://acme.example/new-acct",
            "newNonce": "https://acme.example/new-nonce",
            "newOrder": "https://acme.example/new-order",
            "revokeCert": "https://acme.example/revoke",
        }
        mock_client_mod.ClientNetwork.return_value = mock_net

        mock_directory = MagicMock()
        mock_messages.Directory.from_json.return_value = mock_directory

        mock_acme_client = MagicMock()
        mock_client_mod.ClientV2.return_value = mock_acme_client

        mock_registration = MagicMock()
        mock_messages.NewRegistration.from_data.return_value = mock_registration

        # --- Step 1: create_acme_client ---
        acme_cl = create_acme_client(
            directory_url="https://acme.example/directory",
            email="test@example.com",
            agree_tos=True,
        )
        assert acme_cl is mock_acme_client
        mock_acme_client.new_account.assert_called_once_with(mock_registration)

        # --- Step 2: request_certificate ---
        # Build a realistic fullchain PEM
        real_cert_pem = _make_self_signed_cert_pem()
        fullchain = real_cert_pem + CHAIN_PEM

        mock_order = MagicMock()
        mock_order.authorizations = []  # skip challenges for simplicity
        mock_order.fullchain_pem = fullchain
        mock_acme_client.new_order.return_value = mock_order
        mock_acme_client.poll_and_finalize.return_value = mock_order

        result = request_certificate(
            mock_acme_client,
            common_name="test.example.com",
            san=["www.test.example.com"],
            challenge_type="dns-01",
        )
        assert "certificate" in result
        assert "chain" in result
        assert "fullchain" in result
        assert "private_key" in result
        assert "BEGIN CERTIFICATE" in result["certificate"]
        assert "BEGIN" in result["private_key"]

        # --- Step 3: revoke_certificate ---
        # josepy API varies across versions; mock at function level
        with patch("certmesh.providers.letsencrypt_client.revoke_certificate") as mock_revoke:
            mock_revoke(mock_acme_client, real_cert_pem, reason=0)
            mock_revoke.assert_called_once()


# ============================================================================
# Vault PKI lifecycle
# ============================================================================


class TestVaultPKILifecycle:
    """Vault PKI: issue -> list -> read -> revoke."""

    def test_full_lifecycle(self, vault_cfg: JsonDict) -> None:
        from certmesh.backends.vault_client import (
            issue_pki_certificate,
            list_pki_certificates,
            read_pki_certificate,
            revoke_pki_certificate,
        )

        mock_client = MagicMock()
        pki_cfg = vault_cfg["pki"]

        real_cert_pem = _make_self_signed_cert_pem()
        test_serial = "aa:bb:cc:dd:ee:ff"

        # --- Step 1: issue_pki_certificate ---
        mock_client.secrets.pki.generate_certificate.return_value = {
            "data": {
                "certificate": real_cert_pem,
                "issuing_ca": CERT_PEM,
                "ca_chain": [CERT_PEM],
                "private_key": KEY_PEM,
                "private_key_type": "rsa",
                "serial_number": test_serial,
                "expiration": 1735689600,
            }
        }

        issued = issue_pki_certificate(
            mock_client,
            pki_cfg,
            "test.example.com",
            alt_names=["www.test.example.com"],
            ttl="720h",
        )
        assert issued["certificate"] == real_cert_pem
        assert issued["serial_number"] == test_serial
        assert issued["private_key"] == KEY_PEM
        mock_client.secrets.pki.generate_certificate.assert_called_once()
        call_kwargs = mock_client.secrets.pki.generate_certificate.call_args[1]
        assert call_kwargs["common_name"] == "test.example.com"
        assert call_kwargs["name"] == "test-role"
        assert call_kwargs["mount_point"] == "pki"
        assert "alt_names" in call_kwargs["extra_params"]

        # --- Step 2: list_pki_certificates ---
        mock_client.secrets.pki.list_certificates.return_value = {
            "data": {
                "keys": [test_serial, "11:22:33:44"],
            }
        }

        serials = list_pki_certificates(mock_client, pki_cfg)
        assert len(serials) == 2
        assert test_serial in serials
        mock_client.secrets.pki.list_certificates.assert_called_once_with(mount_point="pki")

        # --- Step 3: read_pki_certificate ---
        mock_client.secrets.pki.read_certificate.return_value = {
            "data": {
                "certificate": real_cert_pem,
                "revocation_time": 0,
            }
        }

        read_data = read_pki_certificate(mock_client, pki_cfg, test_serial)
        assert read_data["certificate"] == real_cert_pem
        assert read_data["revocation_time"] == 0
        mock_client.secrets.pki.read_certificate.assert_called_once_with(
            serial=test_serial, mount_point="pki"
        )

        # --- Step 4: revoke_pki_certificate ---
        mock_client.secrets.pki.revoke_certificate.return_value = {
            "data": {
                "revocation_time": 1735689600,
            }
        }

        revoke_data = revoke_pki_certificate(mock_client, pki_cfg, test_serial)
        assert revoke_data["revocation_time"] == 1735689600
        mock_client.secrets.pki.revoke_certificate.assert_called_once_with(
            serial_number=test_serial, mount_point="pki"
        )

    def test_issue_missing_role_raises(self, vault_cfg: JsonDict) -> None:
        from certmesh.backends.vault_client import issue_pki_certificate
        from certmesh.exceptions import ConfigurationError

        mock_client = MagicMock()
        bad_pki_cfg = {"mount_point": "pki", "role_name": ""}

        with pytest.raises(ConfigurationError, match="role_name"):
            issue_pki_certificate(mock_client, bad_pki_cfg, "test.example.com")

    def test_revoke_auth_error(self, vault_cfg: JsonDict) -> None:
        from hvac.exceptions import Forbidden

        from certmesh.backends.vault_client import revoke_pki_certificate
        from certmesh.exceptions import VaultAuthenticationError

        mock_client = MagicMock()
        mock_client.secrets.pki.revoke_certificate.side_effect = Forbidden("denied")
        pki_cfg = vault_cfg["pki"]

        with pytest.raises(VaultAuthenticationError, match="Access denied"):
            revoke_pki_certificate(mock_client, pki_cfg, "aa:bb")
