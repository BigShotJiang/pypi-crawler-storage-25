"""Tests for certmesh.remote_client — remote API management client."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from certmesh import __version__
from certmesh.exceptions import (
    CertMeshError,
    CircuitBreakerOpenError,
    ConfigurationError,
    RemoteConnectionError,
    VersionMismatchError,
)
from certmesh.remote_client import (
    CertMeshRemoteClient,
    _is_loopback,
    _resolve_ca_bundle,
    _safe_path,
)

# =============================================================================
# Helpers
# =============================================================================


def _mock_info_response(version=None, oauth2_enabled=False):
    """Create a mock httpx.Response for /api/v1/info."""
    if version is None:
        version = __version__
    resp = MagicMock()
    resp.status_code = 200
    resp.content = b'{"version": "x"}'
    resp.json.return_value = {
        "version": version,
        "oauth2_enabled": oauth2_enabled,
        "api_version": "v1",
        "providers": ["venafi"],
    }
    return resp


def _make_connected_client(
    base_url="http://127.0.0.1:8000",
    token=None,
    refresh_token=None,
    oauth2_enabled=False,
    version=None,
):
    """Create a CertMeshRemoteClient with mocked httpx.Client."""
    client = CertMeshRemoteClient(
        base_url=base_url,
        token=token,
        refresh_token=refresh_token,
    )
    mock_session = MagicMock()
    mock_session.request.return_value = _mock_info_response(
        version=version,
        oauth2_enabled=oauth2_enabled,
    )
    with patch("httpx.Client", return_value=mock_session):
        client.connect()
    # Replace session with fresh mock for subsequent calls
    client._session = mock_session
    return client, mock_session


# =============================================================================
# CA Bundle resolution
# =============================================================================


class TestResolveCABundle:
    def test_explicit_ca_cert(self, tmp_path):
        ca_file = tmp_path / "ca.pem"
        ca_file.write_text("cert")
        assert _resolve_ca_bundle(str(ca_file)) == str(ca_file)

    def test_ssl_cert_file(self, tmp_path, monkeypatch):
        ca_file = tmp_path / "ca.pem"
        ca_file.write_text("cert")
        monkeypatch.setenv("SSL_CERT_FILE", str(ca_file))
        assert _resolve_ca_bundle(None) == str(ca_file)

    def test_requests_ca_bundle(self, tmp_path, monkeypatch):
        ca_file = tmp_path / "ca.pem"
        ca_file.write_text("cert")
        monkeypatch.setenv("REQUESTS_CA_BUNDLE", str(ca_file))
        monkeypatch.delenv("SSL_CERT_FILE", raising=False)
        assert _resolve_ca_bundle(None) == str(ca_file)

    def test_curl_ca_bundle(self, tmp_path, monkeypatch):
        ca_file = tmp_path / "ca.pem"
        ca_file.write_text("cert")
        monkeypatch.setenv("CURL_CA_BUNDLE", str(ca_file))
        monkeypatch.delenv("SSL_CERT_FILE", raising=False)
        monkeypatch.delenv("REQUESTS_CA_BUNDLE", raising=False)
        assert _resolve_ca_bundle(None) == str(ca_file)

    def test_ssl_cert_dir(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SSL_CERT_DIR", str(tmp_path))
        monkeypatch.delenv("SSL_CERT_FILE", raising=False)
        monkeypatch.delenv("REQUESTS_CA_BUNDLE", raising=False)
        monkeypatch.delenv("CURL_CA_BUNDLE", raising=False)
        assert _resolve_ca_bundle(None) == str(tmp_path)

    def test_default_certifi(self, monkeypatch):
        for var in ("SSL_CERT_FILE", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE", "SSL_CERT_DIR"):
            monkeypatch.delenv(var, raising=False)
        assert _resolve_ca_bundle(None) is True


# =============================================================================
# Loopback detection
# =============================================================================


class TestIsLoopback:
    def test_localhost(self):
        assert _is_loopback("http://localhost:8000") is True

    def test_127(self):
        assert _is_loopback("http://127.0.0.1:8000") is True

    def test_ipv6_loopback(self):
        assert _is_loopback("http://[::1]:8000") is True

    def test_remote_host(self):
        assert _is_loopback("https://certmesh.prod.example.com") is False


# =============================================================================
# Version check
# =============================================================================


class TestVersionCheck:
    def test_version_match(self):
        _client, _ = _make_connected_client()
        # connect() already checked version — no error means match

    def test_version_mismatch(self):
        client = CertMeshRemoteClient(base_url="http://127.0.0.1:8000")
        mock_session = MagicMock()
        mock_session.request.return_value = _mock_info_response(version="9.9.9")
        with patch("httpx.Client", return_value=mock_session):
            with pytest.raises(VersionMismatchError, match="pip install certmesh==9.9.9"):
                client.connect()


# =============================================================================
# Auth detection
# =============================================================================


class TestAuthDetection:
    def test_oauth2_enabled_requires_token(self):
        client = CertMeshRemoteClient(base_url="http://127.0.0.1:8000")
        mock_session = MagicMock()
        mock_session.request.return_value = _mock_info_response(oauth2_enabled=True)
        with patch("httpx.Client", return_value=mock_session):
            with pytest.raises(ConfigurationError, match="OAuth2 enabled"):
                client.connect()

    def test_oauth2_disabled_ignores_token(self):
        client, _ = _make_connected_client(token="my-jwt", oauth2_enabled=False)
        assert client.token is None  # Token ignored

    def test_oauth2_enabled_with_token(self):
        client, _ = _make_connected_client(token="my-jwt", oauth2_enabled=True)
        assert client.token == "my-jwt"
        assert client.oauth2_enabled is True


# =============================================================================
# HTTPS warning
# =============================================================================


class TestHTTPSWarning:
    def test_warns_http_non_loopback_with_token(self, capsys):
        client = CertMeshRemoteClient(
            base_url="http://certmesh.example.com:8000",
            token="my-jwt",
        )
        mock_session = MagicMock()
        mock_session.request.return_value = _mock_info_response(oauth2_enabled=True)
        with patch("httpx.Client", return_value=mock_session):
            client.connect()
        captured = capsys.readouterr()
        assert "WARNING" in captured.err
        assert "unencrypted HTTP" in captured.err

    def test_no_warning_on_https(self, capsys):
        client = CertMeshRemoteClient(
            base_url="https://certmesh.example.com",
            token="my-jwt",
        )
        mock_session = MagicMock()
        mock_session.request.return_value = _mock_info_response(oauth2_enabled=True)
        with patch("httpx.Client", return_value=mock_session):
            client.connect()
        captured = capsys.readouterr()
        assert "WARNING" not in captured.err

    def test_no_warning_on_loopback(self, capsys):
        _client, _ = _make_connected_client(
            base_url="http://127.0.0.1:8000",
            token="my-jwt",
            oauth2_enabled=True,
        )
        captured = capsys.readouterr()
        assert "WARNING" not in captured.err


# =============================================================================
# HTTP error mapping
# =============================================================================


class TestErrorMapping:
    def _make_client(self):
        client = CertMeshRemoteClient(base_url="http://127.0.0.1:8000")
        client._session = MagicMock()
        client.oauth2_enabled = False
        return client

    def test_401_auth_error(self):
        client = self._make_client()
        resp = MagicMock()
        resp.status_code = 401
        resp.headers = {"WWW-Authenticate": "Bearer"}
        with pytest.raises(ConfigurationError, match="authentication failed"):
            client._handle_response(resp)

    def test_401_expired_token_no_refresh(self):
        client = self._make_client()
        resp = MagicMock()
        resp.status_code = 401
        resp.headers = {"WWW-Authenticate": 'Bearer error="invalid_token"'}
        with pytest.raises(ConfigurationError, match="expired"):
            client._handle_response(resp)

    def test_403_forbidden(self):
        client = self._make_client()
        resp = MagicMock()
        resp.status_code = 403
        resp.headers = {}
        with pytest.raises(ConfigurationError, match="forbidden"):
            client._handle_response(resp)

    def test_404_not_found(self):
        client = self._make_client()
        resp = MagicMock()
        resp.status_code = 404
        resp.json.return_value = {"detail": "Certificate not found"}
        with pytest.raises(CertMeshError, match="Certificate not found"):
            client._handle_response(resp)

    def test_503_circuit_breaker(self):
        client = self._make_client()
        resp = MagicMock()
        resp.status_code = 503
        resp.headers = {}
        with pytest.raises(CircuitBreakerOpenError, match="service unavailable"):
            client._handle_response(resp)

    def test_500_server_error(self):
        client = self._make_client()
        resp = MagicMock()
        resp.status_code = 500
        resp.headers = {}
        resp.text = "Internal Server Error"
        with pytest.raises(RemoteConnectionError, match="server error"):
            client._handle_response(resp)


# =============================================================================
# Provider method routing
# =============================================================================


class TestProviderRouting:
    def _make_client(self):
        client = CertMeshRemoteClient(base_url="http://127.0.0.1:8000")
        mock_session = MagicMock()
        resp = MagicMock()
        resp.status_code = 200
        resp.content = b"{}"
        resp.json.return_value = {}
        mock_session.request.return_value = resp
        client._session = mock_session
        client._portforward = None
        return client, mock_session

    def test_venafi_list(self):
        client, mock = self._make_client()
        client.venafi_list(limit=50, offset=10)
        call_args = mock.request.call_args
        assert call_args[0][0] == "GET"
        assert "/api/v1/venafi/certificates" in call_args[0][1]

    def test_venafi_renew(self):
        client, mock = self._make_client()
        client.venafi_renew("guid-123")
        call_args = mock.request.call_args
        assert call_args[0][0] == "POST"
        assert "guid-123/renew" in call_args[0][1]

    def test_vault_pki_list(self):
        client, mock = self._make_client()
        client.vault_pki_list()
        call_args = mock.request.call_args
        assert "/api/v1/vault-pki/certificates" in call_args[0][1]

    def test_acm_describe(self):
        client, mock = self._make_client()
        client.acm_describe("arn:aws:acm:eu-west-1:123:cert/abc")
        call_args = mock.request.call_args
        assert "/detail" in call_args[0][1]

    def test_health(self):
        client, mock = self._make_client()
        client.health()
        call_args = mock.request.call_args
        assert "/healthz" in call_args[0][1]

    def test_digicert_search(self):
        client, mock = self._make_client()
        client.digicert_search(common_name="test.example.com")
        call_args = mock.request.call_args
        assert call_args[0][0] == "POST"
        assert "/api/v1/digicert/certificates/search" in call_args[0][1]


# =============================================================================
# Proxy support
# =============================================================================


class TestProxySupport:
    def test_trust_env_enabled(self):
        """Verify httpx.Client is created with trust_env=True for proxy support."""
        client = CertMeshRemoteClient(base_url="https://certmesh.example.com")
        mock_session = MagicMock()
        mock_session.request.return_value = _mock_info_response()
        with patch("httpx.Client") as mock_httpx:
            mock_httpx.return_value = mock_session
            client.connect()
            call_kwargs = mock_httpx.call_args.kwargs
            assert call_kwargs.get("trust_env") is True


# =============================================================================
# Path traversal prevention
# =============================================================================


class TestSafePath:
    def test_encodes_slashes(self):
        assert _safe_path("../../admin") == "..%2F..%2Fadmin"

    def test_encodes_arn(self):
        encoded = _safe_path("arn:aws:acm:us-east-1:123:cert/abc")
        assert "/" not in encoded
        assert ":" not in encoded
        assert "%2F" in encoded
        assert "%3A" in encoded

    def test_int_converted(self):
        assert _safe_path(42) == "42"

    def test_normal_guid_unchanged(self):
        assert _safe_path("abc-123-def") == "abc-123-def"


class TestPathTraversalPrevented:
    def _make_client(self):
        client = CertMeshRemoteClient(base_url="http://127.0.0.1:8000")
        mock_session = MagicMock()
        resp = MagicMock()
        resp.status_code = 200
        resp.content = b"{}"
        resp.json.return_value = {}
        mock_session.request.return_value = resp
        client._session = mock_session
        client._portforward = None
        return client, mock_session

    def test_venafi_describe_encodes_guid(self):
        client, mock = self._make_client()
        client.venafi_describe("../../admin")
        path = mock.request.call_args[0][1]
        assert "../../admin" not in path
        assert "%2F" in path

    def test_acm_describe_encodes_arn(self):
        client, mock = self._make_client()
        client.acm_describe("arn:aws:acm:us-east-1:123:cert/abc")
        path = mock.request.call_args[0][1]
        assert "%3A" in path
        assert "%2F" in path


# =============================================================================
# Token refresh
# =============================================================================


class TestTokenRefresh:
    def test_429_includes_retry_after(self):
        client = CertMeshRemoteClient(base_url="http://127.0.0.1:8000")
        client._session = MagicMock()
        resp = MagicMock()
        resp.status_code = 429
        resp.headers = {"Retry-After": "120"}
        with pytest.raises(CertMeshError, match="120"):
            client._handle_response(resp)

    def test_token_refresh_success(self):
        client, mock_session = _make_connected_client(
            token="old-token",
            refresh_token="refresh-xyz",
            oauth2_enabled=True,
        )
        # Simulate: 401 with invalid_token -> refresh succeeds -> retry succeeds
        resp_401 = MagicMock()
        resp_401.status_code = 401
        resp_401.headers = {"WWW-Authenticate": 'Bearer error="invalid_token"'}

        resp_refresh = MagicMock()
        resp_refresh.status_code = 200
        resp_refresh.json.return_value = {"access_token": "new-token"}

        resp_ok = MagicMock()
        resp_ok.status_code = 200
        resp_ok.content = b'{"result": "ok"}'
        resp_ok.json.return_value = {"result": "ok"}

        mock_session.request.side_effect = [resp_401, resp_ok]
        mock_session.post.return_value = resp_refresh

        result = client._request("GET", "/api/v1/test")
        assert result == {"result": "ok"}
        assert client.token == "new-token"

    def test_token_refresh_blocked_over_http(self):
        client = CertMeshRemoteClient(base_url="http://remote.example.com:8000")
        client._session = MagicMock()
        client._effective_url = "http://remote.example.com:8000"
        client.refresh_token = "refresh-xyz"
        assert client._try_refresh_token() is False

    def test_token_refresh_allowed_on_loopback(self):
        client = CertMeshRemoteClient(base_url="http://127.0.0.1:8000")
        client._session = MagicMock()
        client._effective_url = "http://127.0.0.1:8000"
        client.refresh_token = "refresh-xyz"
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {"access_token": "new-token"}
        client._session.post.return_value = resp
        assert client._try_refresh_token() is True
        assert client.token == "new-token"


# =============================================================================
# Port-forward reconnection
# =============================================================================


class TestEnsurePortforward:
    def test_reconnect_when_dead(self):
        client = CertMeshRemoteClient(base_url="http://127.0.0.1:8000")
        client._session = MagicMock()
        client._effective_url = "http://127.0.0.1:8000"
        client._portforward = MagicMock()
        client._portforward.is_alive.return_value = False
        client._portforward.reconnect.return_value = "http://127.0.0.1:9999"
        client._ensure_portforward()
        client._portforward.reconnect.assert_called_once()
        assert client._effective_url == "http://127.0.0.1:9999"

    def test_no_reconnect_when_alive(self):
        client = CertMeshRemoteClient(base_url="http://127.0.0.1:8000")
        client._session = MagicMock()
        client._portforward = MagicMock()
        client._portforward.is_alive.return_value = True
        client._ensure_portforward()
        client._portforward.reconnect.assert_not_called()
