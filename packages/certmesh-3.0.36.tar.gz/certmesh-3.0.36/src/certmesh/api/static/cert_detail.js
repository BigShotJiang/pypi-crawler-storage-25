/**
 * certmesh Certificate Detail JavaScript
 *
 * Loads and renders detailed certificate information, renewal history,
 * and associated logs for a specific certificate.
 */

var CertMeshDetail = (function () {
    'use strict';

    var provider = '';
    var certId = '';
    var csrfToken = '';

    function init(p, id) {
        provider = p;
        certId = id;
        csrfToken = (document.querySelector('meta[name="csrf-token"]') || {}).content || '';

        loadCertificateDetail();
        loadHistory();
        loadAssociatedLogs();
        setupActions();
    }

    function loadCertificateDetail() {
        fetch('/dashboard/api/certificates/' + encodeURIComponent(provider) +
              '/' + encodeURIComponent(certId), {
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json' }
        })
        .then(function (resp) {
            if (resp.status === 401) {
                window.location.href = '/dashboard/login?error=session_expired';
                return null;
            }
            return resp.json();
        })
        .then(function (data) {
            if (!data) return;
            renderDetail(data);
        })
        .catch(function (err) {
            var body = document.getElementById('certDetailBody');
            if (body) {
                body.innerHTML = '<div class="alert alert-warning">Failed to load certificate details.</div>';
            }
        });
    }

    function renderDetail(cert) {
        var body = document.getElementById('certDetailBody');
        if (!body) return;

        var html = '<div class="row g-4">';

        // Left column - Identity
        html += '<div class="col-md-6">';
        html += '<h6 class="text-body-secondary mb-3">Identity</h6>';
        html += '<dl class="row mb-0">';
        html += renderField('Common Name', cert.common_name || cert.domain_name || cert.name || '--');
        html += renderField('Serial Number', cert.serial_number || cert.serial || cert.order_id || cert.guid || cert.certificate_arn || '--');
        html += renderField('Provider', provider);
        html += renderField('Status', cert.status || '--');

        // SAN / DNS Names
        var sans = cert.san_dns_names || cert.subject_alternative_names || [];
        if (sans.length > 0) {
            html += renderField('SAN DNS Names', sans.join(', '));
        }

        // Subject fields (CSR attributes)
        if (cert.subject) html += renderField('Subject', cert.subject);
        if (cert.issuer) html += renderField('Issuer', cert.issuer);
        if (cert.organisation) html += renderField('Organisation', cert.organisation);
        if (cert.organisational_unit) html += renderField('Organisational Unit', cert.organisational_unit);
        if (cert.country) html += renderField('Country', cert.country);
        if (cert.state) html += renderField('State', cert.state);
        if (cert.locality) html += renderField('Locality', cert.locality);
        html += '</dl></div>';

        // Right column - Validity & Crypto
        html += '<div class="col-md-6">';
        html += '<h6 class="text-body-secondary mb-3">Validity & Cryptography</h6>';
        html += '<dl class="row mb-0">';
        var notBefore = cert.valid_from || cert.not_before || cert.created_on || cert.created_at || '';
        var notAfter = cert.valid_till || cert.valid_to || cert.not_after || cert.approx_not_after || cert.expiration || '';
        html += renderField('Valid From', formatDate(notBefore));
        html += renderField('Valid Until', formatDate(notAfter));
        html += renderField('Days Remaining', daysRemaining(notAfter));

        if (cert.key_algorithm) html += renderField('Key Algorithm', cert.key_algorithm);
        if (cert.key_size) html += renderField('Key Size', cert.key_size + ' bits');
        if (cert.thumbprint) html += renderField('Thumbprint', cert.thumbprint);
        if (cert.dn) html += renderField('DN', cert.dn);

        // Renewal info
        if (cert.renewal_eligibility) html += renderField('Renewal Eligibility', cert.renewal_eligibility);
        if (cert.type) html += renderField('Type', cert.type);
        if (cert.in_use_by && cert.in_use_by.length > 0) {
            html += renderField('In Use By', cert.in_use_by.join(', '));
        }
        if (cert.failure_reason) html += renderField('Failure Reason', cert.failure_reason);

        // Next renewal estimate
        if (notAfter) {
            var daysLeft = daysRemainingNum(notAfter);
            if (daysLeft > 0 && daysLeft <= 90) {
                html += renderField('Next Renewal', 'Recommended within ' + Math.max(1, daysLeft - 30) + ' days');
            }
        }
        html += '</dl></div>';
        html += '</div>';

        body.innerHTML = html;
    }

    function renderField(label, value) {
        return '<dt class="col-sm-5 text-body-secondary">' + escapeHtml(label) + '</dt>' +
               '<dd class="col-sm-7">' + escapeHtml(String(value)) + '</dd>';
    }

    function formatDate(dateStr) {
        if (!dateStr) return '--';
        var d = new Date(dateStr);
        if (isNaN(d.getTime())) return dateStr;
        return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) +
               ' ' + d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
    }

    function daysRemainingNum(dateStr) {
        if (!dateStr) return -1;
        var d = new Date(dateStr);
        if (isNaN(d.getTime())) return -1;
        return Math.ceil((d.getTime() - Date.now()) / 86400000);
    }

    function daysRemaining(dateStr) {
        var days = daysRemainingNum(dateStr);
        if (days < 0) return 'Expired (' + Math.abs(days) + ' days ago)';
        if (days === 0) return 'Expires today';
        return days + ' days';
    }

    function loadHistory() {
        fetch('/dashboard/api/certificates/history?provider=' + encodeURIComponent(provider) +
              '&cert_id=' + encodeURIComponent(certId), {
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json' }
        })
        .then(function (resp) { return resp.json(); })
        .then(function (data) {
            renderHistory(data.history || []);
        })
        .catch(function () {
            var tbody = document.getElementById('historyTableBody');
            if (tbody) {
                tbody.innerHTML = '<tr><td colspan="5" class="text-center text-body-secondary">No history available</td></tr>';
            }
        });
    }

    function renderHistory(history) {
        var tbody = document.getElementById('historyTableBody');
        if (!tbody) return;

        if (history.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center py-3 text-body-secondary">No renewal history found</td></tr>';
            return;
        }

        var html = '';
        history.forEach(function (entry) {
            var statusClass = entry.status === 'success' ? 'text-success' : 'text-danger';
            html += '<tr>';
            html += '<td><small>' + formatDate(new Date(entry.timestamp * 1000).toISOString()) + '</small></td>';
            html += '<td><span class="badge bg-secondary bg-opacity-10 text-body">' + escapeHtml(entry.action || '') + '</span></td>';
            html += '<td><span class="' + statusClass + '">' + escapeHtml(entry.status || '') + '</span></td>';
            html += '<td><small>' + escapeHtml(entry.user || '--') + '</small></td>';
            html += '<td><small>' + escapeHtml(entry.detail || '') + '</small></td>';
            html += '</tr>';
        });
        tbody.innerHTML = html;
    }

    function loadAssociatedLogs() {
        var params = new URLSearchParams();
        params.set('search', certId);
        params.set('limit', '50');

        fetch('/dashboard/api/logs?' + params.toString(), {
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json' }
        })
        .then(function (resp) { return resp.json(); })
        .then(function (data) {
            renderAssociatedLogs(data.logs || []);
        })
        .catch(function () {
            var tbody = document.getElementById('certLogTableBody');
            if (tbody) {
                tbody.innerHTML = '<tr><td colspan="3" class="text-center text-body-secondary">No logs available</td></tr>';
            }
        });
    }

    function renderAssociatedLogs(logs) {
        var tbody = document.getElementById('certLogTableBody');
        if (!tbody) return;

        if (logs.length === 0) {
            tbody.innerHTML = '<tr><td colspan="3" class="text-center py-3 text-body-secondary">No associated logs found</td></tr>';
            return;
        }

        var html = '';
        logs.forEach(function (log) {
            var levelClass = getLevelClass(log.level || '');
            html += '<tr>';
            html += '<td><small>' + formatDate(log.timestamp || '') + '</small></td>';
            html += '<td><span class="badge cm-log-level ' + levelClass + '">' + escapeHtml(log.level || '') + '</span></td>';
            html += '<td>' + escapeHtml(log.message || '') + '</td>';
            html += '</tr>';
        });
        tbody.innerHTML = html;
    }

    function getLevelClass(level) {
        switch ((level || '').toUpperCase()) {
            case 'DEBUG': return 'cm-level-debug';
            case 'INFO': return 'cm-level-info';
            case 'WARNING': return 'cm-level-warning';
            case 'ERROR': return 'cm-level-error';
            case 'CRITICAL': return 'cm-level-critical';
            default: return 'cm-level-debug';
        }
    }

    function setupActions() {
        var container = document.getElementById('certActions');
        if (!container) return;

        var html = '';
        if (provider === 'venafi') {
            html += '<button class="btn btn-sm btn-outline-primary" id="btnRenew">' +
                    '<i class="bi bi-arrow-repeat me-1"></i>Renew</button>';
            html += '<button class="btn btn-sm btn-outline-danger" id="btnRevoke">' +
                    '<i class="bi bi-x-lg me-1"></i>Revoke</button>';
        } else if (provider === 'digicert') {
            html += '<button class="btn btn-sm btn-outline-danger" id="btnRevoke">' +
                    '<i class="bi bi-x-lg me-1"></i>Revoke</button>';
        } else if (provider === 'vault_pki') {
            html += '<button class="btn btn-sm btn-outline-danger" id="btnRevoke">' +
                    '<i class="bi bi-x-lg me-1"></i>Revoke</button>';
        } else {
            html += '<span class="text-body-secondary">No actions available for this provider</span>';
        }
        container.innerHTML = html;

        var renewBtn = document.getElementById('btnRenew');
        if (renewBtn) {
            renewBtn.addEventListener('click', function () {
                if (!confirm('Renew certificate ' + certId + '?')) return;
                doAction('renew');
            });
        }

        var revokeBtn = document.getElementById('btnRevoke');
        if (revokeBtn) {
            revokeBtn.addEventListener('click', function () {
                var modal = new bootstrap.Modal(document.getElementById('revokeModal'));
                modal.show();
            });
        }

        var confirmBtn = document.getElementById('confirmRevokeBtn');
        if (confirmBtn) {
            confirmBtn.addEventListener('click', function () {
                var modal = bootstrap.Modal.getInstance(document.getElementById('revokeModal'));
                if (modal) modal.hide();
                doAction('revoke');
            });
        }
    }

    function doAction(action) {
        fetch('/dashboard/api/certificates/' + encodeURIComponent(provider) +
              '/' + encodeURIComponent(certId) + '/' + action, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            }
        })
        .then(function (resp) { return resp.json(); })
        .then(function (data) {
            if (data.status === 'success') {
                showToast('Certificate ' + action + ' initiated successfully.', 'success');
                loadCertificateDetail();
                loadHistory();
            } else {
                showToast(action + ' failed: ' + (data.detail || 'Unknown error'), 'error');
            }
        })
        .catch(function (err) {
            showToast(action + ' request failed: ' + err.message, 'error');
        });
    }

    function showToast(message, type) {
        var container = document.getElementById('toastContainer');
        if (!container) return;
        var iconClass = type === 'success' ? 'bi-check-circle-fill text-success' :
                        'bi-x-circle-fill text-danger';
        var toastEl = document.createElement('div');
        toastEl.className = 'toast show cm-toast-' + (type || 'info');
        toastEl.setAttribute('role', 'alert');
        toastEl.innerHTML =
            '<div class="toast-header">' +
            '<i class="bi ' + iconClass + ' me-2"></i>' +
            '<strong class="me-auto">certmesh</strong>' +
            '<button type="button" class="btn-close" data-bs-dismiss="toast"></button>' +
            '</div>' +
            '<div class="toast-body">' + escapeHtml(message) + '</div>';
        container.appendChild(toastEl);
        setTimeout(function () {
            toastEl.classList.remove('show');
            setTimeout(function () { toastEl.remove(); }, 300);
        }, 5000);
    }

    function escapeHtml(str) {
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }

    return {
        init: init
    };
})();

// Self-initialise from data attributes (avoids inline script / CSP violation).
document.addEventListener('DOMContentLoaded', function () {
    var el = document.getElementById('certDetailInit');
    if (el) {
        CertMeshDetail.init(el.dataset.provider, el.dataset.certId);
    }
});
