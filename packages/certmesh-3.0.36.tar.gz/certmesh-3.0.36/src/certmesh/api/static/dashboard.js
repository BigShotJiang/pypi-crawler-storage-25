/**
 * certmesh Dashboard JavaScript
 *
 * Handles certificate data loading, search/filter, actions (renew/revoke),
 * auto-refresh, theme toggling, and HTMX event handling.
 */

const CertMeshDashboard = (function () {
    'use strict';

    let allCertificates = [];
    let currentProvider = 'all';
    let csrfToken = '';
    let refreshTimer = null;
    const REFRESH_INTERVAL = 60000; // 60 seconds

    // Log viewer state
    let logTerminal = null;
    let logFitAddon = null;
    let logEventSource = null;
    let logPaused = false;
    let logLevelFilter = 'ALL';
    let logProviderFilter = 'ALL';
    let logUserScrolled = false;
    let logInitialized = false;
    var logSeenProviders = {};  // track providers seen in the stream
    var logPlainLines = [];     // plain-text lines for export (no ANSI codes)

    // ── Initialisation ────────────────────────────────────────────────

    function init() {
        csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';

        // Load data
        loadCertificates();
        loadTimeline();

        // Set up event listeners
        setupProviderTabs();
        setupSearch();
        setupThemeToggle();
        setupAutoRefresh();
        setupCertActions();
        setupLogViewer();

        // Apply saved theme
        const saved = localStorage.getItem('cm-theme');
        if (saved) {
            document.documentElement.setAttribute('data-bs-theme', saved);
            updateThemeIcon(saved);
        }
    }

    // ── Data Loading ──────────────────────────────────────────────────

    function loadCertificates() {
        fetch('/dashboard/api/certificates', {
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json' }
        })
        .then(function (resp) {
            if (resp.status === 401) {
                window.location.href = '/dashboard/login?error=session_expired';
                return null;
            }
            return resp.json();
        })
        .then(function (data) {
            if (!data) return;
            allCertificates = data.certificates || [];
            updateSummary(data);
            renderCertificateTable(filterCertificates());
        })
        .catch(function (err) {
            console.error('Failed to load certificates:', err);
            showToast('Failed to load certificate data. Please try refreshing the page.', 'error');
        });
    }

    function loadTimeline() {
        fetch('/dashboard/api/timeline', {
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json' }
        })
        .then(function (resp) {
            if (resp.status === 401) return null;
            return resp.json();
        })
        .then(function (data) {
            if (!data) return;
            renderTimeline(data);
        })
        .catch(function (err) {
            console.error('Failed to load timeline:', err);
        });
    }

    // ── Summary Cards ─────────────────────────────────────────────────

    function updateSummary(data) {
        var total = data.total || 0;
        var errors = (data.errors || []).length;

        document.getElementById('totalCount').textContent = total;
        document.getElementById('errorCount').textContent = errors;

        // Count expiring and expired from certificates
        var expiring = 0;
        var expired = 0;
        var now = Date.now();

        (data.certificates || []).forEach(function (cert) {
            var expiryStr = cert.not_after || cert.valid_till || cert.valid_to ||
                            cert.approx_not_after || cert.expiration || '';
            if (!expiryStr) return;

            var expiryDate = new Date(expiryStr);
            if (isNaN(expiryDate.getTime())) return;

            var daysRemaining = (expiryDate.getTime() - now) / 86400000;
            if (daysRemaining < 0) {
                expired++;
            } else if (daysRemaining < 30) {
                expiring++;
            }
        });

        document.getElementById('expiringCount').textContent = expiring;
        document.getElementById('expiredCount').textContent = expired;
    }

    // ── Timeline ──────────────────────────────────────────────────────

    function renderTimeline(data) {
        var summary = data.summary || {};
        var total = data.total || 1; // avoid division by zero

        var buckets = {
            'Expired': { id: 'barExpired', count: summary.expired || 0 },
            'Critical': { id: 'barCritical', count: summary.critical || 0 },
            'Warning': { id: 'barWarning', count: summary.warning || 0 },
            'Attention': { id: 'barAttention', count: summary.attention || 0 },
            'Healthy': { id: 'barHealthy', count: summary.healthy || 0 }
        };

        Object.keys(buckets).forEach(function (key) {
            var bar = document.getElementById(buckets[key].id);
            if (!bar) return;
            var pct = Math.max((buckets[key].count / total) * 100, 0);
            bar.style.width = (pct > 0 ? Math.max(pct, 5) : 0) + '%';
            bar.textContent = buckets[key].count;
        });
    }

    // ── Certificate Table ─────────────────────────────────────────────

    function filterCertificates() {
        var search = (document.getElementById('certSearch')?.value || '').toLowerCase();
        return allCertificates.filter(function (cert) {
            if (currentProvider !== 'all' && cert.provider !== currentProvider) {
                return false;
            }
            if (search) {
                var cn = (cert.common_name || cert.domain_name || cert.name || '').toLowerCase();
                var serial = (cert.serial_number || cert.serial || cert.order_id || cert.guid ||
                              cert.certificate_arn || '').toLowerCase();
                var provider = (cert.provider || '').toLowerCase();
                return cn.indexOf(search) !== -1 ||
                       serial.indexOf(search) !== -1 ||
                       provider.indexOf(search) !== -1;
            }
            return true;
        });
    }

    function renderCertificateTable(certs) {
        var tbody = document.getElementById('certTableBody');
        if (!tbody) return;

        if (certs.length === 0) {
            tbody.innerHTML =
                '<tr><td colspan="6" class="text-center py-5 text-body-secondary">' +
                '<i class="bi bi-inbox me-2" style="font-size: 1.5rem;"></i><br>' +
                'No certificates found</td></tr>';
            return;
        }

        var html = '';
        certs.forEach(function (cert) {
            var cn = escapeHtml(cert.common_name || cert.domain_name || cert.name || '--');
            var serial = escapeHtml(cert.serial_number || cert.serial || cert.order_id ||
                                    cert.guid || cert.certificate_arn || '--');
            var provider = cert.provider || 'unknown';
            var expiry = cert.not_after || cert.valid_till || cert.valid_to ||
                         cert.approx_not_after || cert.expiration || '';
            var statusInfo = getStatusInfo(cert, expiry);
            var certId = cert.order_id || cert.guid || cert.serial_number ||
                         cert.certificate_arn || serial;

            html += '<tr data-provider="' + escapeHtml(provider) + '" class="cm-cert-row" style="cursor:pointer;">';
            html += '<td>' + statusInfo.badge + '</td>';
            html += '<td class="fw-medium"><a href="/dashboard/certificates/' +
                    encodeURIComponent(provider) + '/' + encodeURIComponent(certId) +
                    '" class="text-decoration-none text-body">' + cn + '</a></td>';
            html += '<td><span class="badge cm-provider-badge bg-secondary bg-opacity-10 text-body">' +
                    escapeHtml(provider) + '</span></td>';
            html += '<td class="text-body-secondary"><small>' + truncate(serial, 24) + '</small></td>';
            html += '<td>' + formatExpiry(expiry) + '</td>';
            html += '<td class="text-end">';
            html += '<div class="btn-group">';
            if (provider === 'venafi') {
                html += '<button class="btn btn-sm btn-outline-primary cm-action-btn" ' +
                        'data-action="renew" data-provider="' + escapeHtml(provider) +
                        '" data-cert-id="' + escapeHtml(certId) + '" title="Renew">' +
                        '<i class="bi bi-arrow-repeat"></i></button>';
            }
            if (provider === 'venafi' || provider === 'digicert') {
                html += '<button class="btn btn-sm btn-outline-danger cm-action-btn" ' +
                        'data-action="revoke" data-provider="' + escapeHtml(provider) +
                        '" data-cert-id="' + escapeHtml(certId) +
                        '" data-cn="' + escapeHtml(cn) + '" title="Revoke">' +
                        '<i class="bi bi-x-lg"></i></button>';
            }
            html += '</div>';
            html += '</td>';
            html += '</tr>';
        });

        tbody.innerHTML = html;
    }

    function getStatusInfo(cert, expiryStr) {
        var status = (cert.status || '').toLowerCase();
        if (status === 'revoked' || status === 'error' || cert.in_error) {
            return {
                badge: '<span class="cm-status cm-status-error">' +
                       '<span class="cm-status-dot"></span>Error</span>'
            };
        }

        if (!expiryStr) {
            return {
                badge: '<span class="cm-status cm-status-unknown">' +
                       '<span class="cm-status-dot"></span>Unknown</span>'
            };
        }

        var expiryDate = new Date(expiryStr);
        if (isNaN(expiryDate.getTime())) {
            return {
                badge: '<span class="cm-status cm-status-unknown">' +
                       '<span class="cm-status-dot"></span>Unknown</span>'
            };
        }

        var days = (expiryDate.getTime() - Date.now()) / 86400000;
        if (days < 0) {
            return {
                badge: '<span class="cm-status cm-status-expired">' +
                       '<span class="cm-status-dot"></span>Expired</span>'
            };
        }
        if (days < 30) {
            return {
                badge: '<span class="cm-status cm-status-expiring">' +
                       '<span class="cm-status-dot"></span>Expiring</span>'
            };
        }
        return {
            badge: '<span class="cm-status cm-status-valid">' +
                   '<span class="cm-status-dot"></span>Valid</span>'
        };
    }

    function formatExpiry(expiryStr) {
        if (!expiryStr) return '<span class="text-body-secondary">--</span>';
        var d = new Date(expiryStr);
        if (isNaN(d.getTime())) return escapeHtml(expiryStr);

        var days = Math.ceil((d.getTime() - Date.now()) / 86400000);
        var formatted = d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
        var suffix = '';
        if (days < 0) {
            suffix = ' <small class="text-danger">(' + Math.abs(days) + 'd ago)</small>';
        } else if (days < 30) {
            suffix = ' <small class="text-warning">(' + days + 'd)</small>';
        } else {
            suffix = ' <small class="text-body-secondary">(' + days + 'd)</small>';
        }
        return formatted + suffix;
    }

    // ── Provider Tabs ─────────────────────────────────────────────────

    function setupProviderTabs() {
        var tabs = document.querySelectorAll('#providerTabs button');
        tabs.forEach(function (tab) {
            tab.addEventListener('click', function () {
                currentProvider = this.getAttribute('data-provider') || 'all';
                renderCertificateTable(filterCertificates());
            });
        });
    }

    // ── Search ────────────────────────────────────────────────────────

    function setupSearch() {
        var input = document.getElementById('certSearch');
        if (!input) return;

        var debounceTimer = null;
        input.addEventListener('input', function () {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(function () {
                renderCertificateTable(filterCertificates());
            }, 250);
        });
    }

    // ── Certificate Action Delegation ─────────────────────────────────

    function setupCertActions() {
        var tbody = document.getElementById('certTableBody');
        if (!tbody) return;

        tbody.addEventListener('click', function (e) {
            var btn = e.target.closest('[data-action]');
            if (btn) {
                e.preventDefault();
                e.stopPropagation();
                var action = btn.getAttribute('data-action');
                var provider = btn.getAttribute('data-provider');
                var certId = btn.getAttribute('data-cert-id');

                if (action === 'renew') {
                    renewCert(provider, certId);
                } else if (action === 'revoke') {
                    var cn = btn.getAttribute('data-cn');
                    showRevoke(provider, certId, cn);
                }
                return;
            }

            // Row click navigates to certificate detail (unless clicking a link or button)
            if (e.target.closest('a') || e.target.closest('button')) return;
            var row = e.target.closest('tr.cm-cert-row');
            if (!row) return;
            var link = row.querySelector('a[href]');
            if (link) window.location.href = link.href;
        });
    }

    // ── Theme Toggle ──────────────────────────────────────────────────

    function setupThemeToggle() {
        var btn = document.getElementById('themeToggle');
        if (!btn) return;

        btn.addEventListener('click', function () {
            var current = document.documentElement.getAttribute('data-bs-theme') || 'light';
            var next = current === 'light' ? 'dark' : 'light';
            document.documentElement.setAttribute('data-bs-theme', next);
            localStorage.setItem('cm-theme', next);
            updateThemeIcon(next);
            updateLogTerminalTheme();
        });
    }

    function updateThemeIcon(theme) {
        var btn = document.getElementById('themeToggle');
        if (!btn) return;
        var icon = btn.querySelector('i');
        if (!icon) return;
        icon.className = theme === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-stars-fill';
    }

    // ── Auto-refresh ──────────────────────────────────────────────────

    function setupAutoRefresh() {
        function startRefreshTimer() {
            if (refreshTimer) return;
            refreshTimer = setInterval(function () {
                loadCertificates();
                loadTimeline();
            }, REFRESH_INTERVAL);
        }

        function stopRefreshTimer() {
            if (refreshTimer) {
                clearInterval(refreshTimer);
                refreshTimer = null;
            }
        }

        startRefreshTimer();

        // Pause auto-refresh when the tab is hidden to avoid wasting bandwidth.
        document.addEventListener('visibilitychange', function () {
            if (document.hidden) {
                stopRefreshTimer();
            } else {
                // Refresh immediately when the user returns, then resume the timer.
                loadCertificates();
                loadTimeline();
                startRefreshTimer();
            }
        });
    }

    // ── Certificate Actions ───────────────────────────────────────────

    function renewCert(provider, certId) {
        if (!confirm('Renew certificate ' + certId + '?')) return;

        fetch('/dashboard/api/certificates/' + encodeURIComponent(provider) +
              '/' + encodeURIComponent(certId) + '/renew', {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            }
        })
        .then(function (resp) {
            if (resp.status === 401) {
                window.location.href = '/dashboard/login?error=session_expired';
                return null;
            }
            return resp.json();
        })
        .then(function (data) {
            if (!data) return;
            if (data.status === 'success') {
                showToast('Certificate renewal initiated successfully.', 'success');
                loadCertificates();
            } else {
                showToast('Renewal failed: ' + (data.detail || 'Unknown error'), 'error');
            }
        })
        .catch(function (err) {
            showToast('Renewal request failed: ' + err.message, 'error');
        });
    }

    function showRevoke(provider, certId, commonName) {
        document.getElementById('revokeCommonName').textContent = commonName;
        document.getElementById('revokeProvider').textContent = provider;
        document.getElementById('revokeCertId').textContent = certId;

        var btn = document.getElementById('confirmRevokeBtn');
        // Remove old listener by cloning
        var newBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(newBtn, btn);

        newBtn.addEventListener('click', function () {
            revokeCert(provider, certId);
            var modal = bootstrap.Modal.getInstance(document.getElementById('revokeModal'));
            if (modal) modal.hide();
        });

        var modal = new bootstrap.Modal(document.getElementById('revokeModal'));
        modal.show();
    }

    function revokeCert(provider, certId) {
        fetch('/dashboard/api/certificates/' + encodeURIComponent(provider) +
              '/' + encodeURIComponent(certId) + '/revoke', {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            }
        })
        .then(function (resp) {
            if (resp.status === 401) {
                window.location.href = '/dashboard/login?error=session_expired';
                return null;
            }
            return resp.json();
        })
        .then(function (data) {
            if (!data) return;
            if (data.status === 'success') {
                showToast('Certificate revocation submitted.', 'success');
                loadCertificates();
            } else {
                showToast('Revocation failed: ' + (data.detail || 'Unknown error'), 'error');
            }
        })
        .catch(function (err) {
            showToast('Revocation request failed: ' + err.message, 'error');
        });
    }

    // ── Toasts ────────────────────────────────────────────────────────

    function showToast(message, type) {
        var container = document.getElementById('toastContainer');
        if (!container) return;

        var typeClass = 'cm-toast-' + (type || 'info');
        var iconClass = type === 'success' ? 'bi-check-circle-fill text-success' :
                        type === 'error'   ? 'bi-x-circle-fill text-danger' :
                                             'bi-info-circle-fill text-warning';

        var toastEl = document.createElement('div');
        toastEl.className = 'toast show ' + typeClass;
        toastEl.setAttribute('role', 'alert');
        toastEl.innerHTML =
            '<div class="toast-header">' +
            '<i class="bi ' + iconClass + ' me-2"></i>' +
            '<strong class="me-auto">certmesh</strong>' +
            '<button type="button" class="btn-close" data-bs-dismiss="toast"></button>' +
            '</div>' +
            '<div class="toast-body">' + escapeHtml(message) + '</div>';

        container.appendChild(toastEl);

        // Auto-remove after 5 seconds
        setTimeout(function () {
            toastEl.classList.remove('show');
            setTimeout(function () { toastEl.remove(); }, 300);
        }, 5000);
    }

    // ── Utility ───────────────────────────────────────────────────────

    function escapeHtml(str) {
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }

    function truncate(str, max) {
        if (!str || str.length <= max) return escapeHtml(str || '');
        return escapeHtml(str.substring(0, max)) + '&hellip;';
    }

    // ── Live Log Viewer ──────────────────────────────────────────────

    // ANSI colour codes for log levels.
    var LOG_COLOURS = {
        'ERROR':   '\x1b[1;31m',   // bold red
        'WARNING': '\x1b[1;33m',   // bold yellow
        'INFO':    '\x1b[32m',     // green
        'DEBUG':   '\x1b[90m',     // gray
        'CRITICAL':'\x1b[1;35m'    // bold magenta
    };
    var ANSI_RESET = '\x1b[0m';

    function getLogTheme() {
        var isDark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
        return isDark ? {
            background: '#1e1e2e',
            foreground: '#cdd6f4',
            cursor: '#f5e0dc',
            selectionBackground: '#45475a',
            black: '#45475a',
            red: '#f38ba8',
            green: '#a6e3a1',
            yellow: '#f9e2af',
            blue: '#89b4fa',
            magenta: '#f5c2e7',
            cyan: '#94e2d5',
            white: '#bac2de'
        } : {
            background: '#f8f9fa',
            foreground: '#212529',
            cursor: '#495057',
            selectionBackground: '#dee2e6',
            black: '#495057',
            red: '#dc3545',
            green: '#198754',
            yellow: '#fd7e14',
            blue: '#0d6efd',
            magenta: '#6f42c1',
            cyan: '#0dcaf0',
            white: '#adb5bd'
        };
    }

    function setupLogViewer() {
        var panel = document.getElementById('logPanelBody');
        if (!panel) return;

        // Initialise xterm.js when the panel is first expanded.
        panel.addEventListener('shown.bs.collapse', function () {
            if (!logInitialized) {
                initLogTerminal();
                logInitialized = true;
            }
            if (logFitAddon) logFitAddon.fit();
            connectLogStream();
        });

        panel.addEventListener('hidden.bs.collapse', function () {
            disconnectLogStream();
        });

        // Pause/resume button
        var pauseBtn = document.getElementById('logPauseBtn');
        if (pauseBtn) {
            pauseBtn.addEventListener('click', function () {
                logPaused = !logPaused;
                var icon = pauseBtn.querySelector('i');
                if (icon) {
                    icon.className = logPaused ? 'bi bi-play-fill' : 'bi bi-pause-fill';
                }
                pauseBtn.title = logPaused ? 'Resume' : 'Pause';
            });
        }

        // Clear button
        var clearBtn = document.getElementById('logClearBtn');
        if (clearBtn) {
            clearBtn.addEventListener('click', function () {
                if (logTerminal) logTerminal.clear();
                logPlainLines = [];
            });
        }

        // Level filter
        var levelSelect = document.getElementById('logLevelFilter');
        if (levelSelect) {
            levelSelect.addEventListener('change', function () {
                logLevelFilter = this.value;
            });
        }

        // Provider filter
        var providerSelect = document.getElementById('logProviderFilter');
        if (providerSelect) {
            providerSelect.addEventListener('change', function () {
                logProviderFilter = this.value;
            });
        }

        // Export / download button
        var exportBtn = document.getElementById('logExportBtn');
        if (exportBtn) {
            exportBtn.addEventListener('click', function () {
                if (!logPlainLines.length) return;
                var blob = new Blob([logPlainLines.join('\n') + '\n'], { type: 'text/plain' });
                var a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = 'certmesh-logs-' + new Date().toISOString().slice(0, 19).replace(/:/g, '') + '.log';
                a.click();
                URL.revokeObjectURL(a.href);
            });
        }
    }

    function initLogTerminal() {
        var container = document.getElementById('logTerminal');
        if (!container || typeof Terminal === 'undefined') return;

        logTerminal = new Terminal({
            cursorBlink: false,
            disableStdin: true,
            convertEol: true,
            scrollback: 5000,
            fontSize: 13,
            fontFamily: '"Cascadia Code", "Fira Code", "JetBrains Mono", "Consolas", monospace',
            theme: getLogTheme(),
            allowProposedApi: true
        });

        if (typeof FitAddon !== 'undefined') {
            logFitAddon = new FitAddon.FitAddon();
            logTerminal.loadAddon(logFitAddon);
        }

        logTerminal.open(container);
        if (logFitAddon) logFitAddon.fit();

        // Track whether user scrolled up (to disable auto-scroll).
        logTerminal.onScroll(function () {
            var buf = logTerminal.buffer.active;
            logUserScrolled = buf.viewportY < buf.baseY;
        });

        // Resize on window resize.
        var resizeTimer = null;
        window.addEventListener('resize', function () {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(function () {
                if (logFitAddon) logFitAddon.fit();
            }, 150);
        });
    }

    function connectLogStream() {
        if (logEventSource) return; // already connected

        updateLogStatus('reconnecting');
        logEventSource = new EventSource('/dashboard/api/logs/stream');

        logEventSource.onopen = function () {
            updateLogStatus('connected');
        };

        logEventSource.onmessage = function (evt) {
            if (logPaused || !logTerminal) return;
            try {
                var entry = JSON.parse(evt.data);
                if (logLevelFilter !== 'ALL' && entry.level !== logLevelFilter) return;
                // Track and filter by provider (from extra field).
                if (entry.provider) {
                    addProviderOption(entry.provider);
                }
                if (logProviderFilter !== 'ALL') {
                    var ep = (entry.provider || '').toLowerCase();
                    if (ep !== logProviderFilter.toLowerCase()) return;
                }
                writeLogEntry(entry);
            } catch (e) {
                // Ignore malformed messages.
            }
        };

        logEventSource.onerror = function () {
            updateLogStatus('reconnecting');
            // EventSource will auto-reconnect.
        };
    }

    function disconnectLogStream() {
        if (logEventSource) {
            logEventSource.close();
            logEventSource = null;
        }
        updateLogStatus('disconnected');
    }

    function writeLogEntry(entry) {
        if (!logTerminal) return;

        var ts = new Date(entry.timestamp * 1000);
        // Always display in UTC so times are consistent regardless of browser TZ.
        var h = String(ts.getUTCHours()).padStart(2, '0');
        var m = String(ts.getUTCMinutes()).padStart(2, '0');
        var s = String(ts.getUTCSeconds()).padStart(2, '0');
        var timeStr = h + ':' + m + ':' + s + 'Z';
        var level = (entry.level || 'INFO').toUpperCase();
        var colour = LOG_COLOURS[level] || '';
        var loggerStr = entry.logger || '';
        var providerTag = entry.provider ? ' \x1b[35m<' + entry.provider + '>' + ANSI_RESET : '';

        // Format: HH:MM:SSZ LEVEL [logger] <provider> message
        var line = '\x1b[90m' + timeStr + ANSI_RESET + ' ' +
                   colour + padRight(level, 8) + ANSI_RESET + ' ' +
                   '\x1b[36m[' + truncateLogger(loggerStr, 30) + ']' + ANSI_RESET +
                   providerTag + ' ' +
                   entry.message;

        logTerminal.writeln(line);

        // Store plain-text line for export (no ANSI codes).
        var plain = timeStr + ' ' + padRight(level, 8) + ' [' + loggerStr + ']' +
                    (entry.provider ? ' <' + entry.provider + '>' : '') + ' ' + entry.message;
        logPlainLines.push(plain);
        // Cap stored lines to prevent unbounded memory growth.
        if (logPlainLines.length > 10000) {
            logPlainLines = logPlainLines.slice(-5000);
        }

        // Auto-scroll to bottom unless user scrolled up.
        if (!logUserScrolled) {
            logTerminal.scrollToBottom();
        }
    }

    function updateLogStatus(state) {
        var el = document.getElementById('logStatus');
        if (!el) return;
        var dot = el.querySelector('.cm-status-dot');
        var label = el.querySelector('small');
        if (dot) {
            dot.className = 'cm-status-dot cm-dot-' + state;
        }
        if (label) {
            var labels = { connected: 'Connected', reconnecting: 'Reconnecting...', disconnected: 'Disconnected' };
            label.textContent = labels[state] || state;
        }
        el.title = state.charAt(0).toUpperCase() + state.slice(1);
    }

    function padRight(str, len) {
        while (str.length < len) str += ' ';
        return str;
    }

    function truncateLogger(name, max) {
        if (!name || name.length <= max) return name || '';
        // Show last segments: certmesh.api.routes.dashboard → c.a.r.dashboard
        var parts = name.split('.');
        if (parts.length <= 1) return name.substring(0, max);
        var last = parts[parts.length - 1];
        var abbreviated = parts.slice(0, -1).map(function(p) { return p.charAt(0); }).join('.') + '.' + last;
        return abbreviated.length <= max ? abbreviated : abbreviated.substring(0, max);
    }

    function addProviderOption(provider) {
        if (!provider || logSeenProviders[provider]) return;
        logSeenProviders[provider] = true;
        var sel = document.getElementById('logProviderFilter');
        if (!sel) return;
        var opt = document.createElement('option');
        opt.value = provider;
        // Capitalise first letter for display.
        opt.textContent = provider.charAt(0).toUpperCase() + provider.slice(1);
        sel.appendChild(opt);
    }

    function updateLogTerminalTheme() {
        if (logTerminal) {
            logTerminal.options.theme = getLogTheme();
        }
    }

    // ── HTMX Event Handlers ──────────────────────────────────────────

    document.addEventListener('htmx:afterRequest', function (evt) {
        if (evt.detail.pathInfo && evt.detail.pathInfo.requestPath === '/dashboard/api/timeline') {
            // Timeline was refreshed via HTMX; re-fetch and render
            loadTimeline();
        }
    });

    document.addEventListener('htmx:responseError', function (evt) {
        if (evt.detail.xhr && evt.detail.xhr.status === 401) {
            window.location.href = '/dashboard/login?error=session_expired';
        }
    });

    // ── Public API ────────────────────────────────────────────────────

    return {
        init: init,
        renewCert: renewCert,
        showRevoke: showRevoke,
        loadCertificates: loadCertificates,
        loadTimeline: loadTimeline
    };
})();
