"""
certmesh.api.dashboard_state
==============================

S3-backed state store for dashboard data with server-side encryption (KMS or AES-256).

Stores and retrieves dashboard state: certificate inventory snapshots,
renewal history, and user preferences.  Configurable via environment
variables:

- ``CM_DASHBOARD_S3_BUCKET`` -- S3 bucket name (required for persistence)
- ``CM_DASHBOARD_S3_PREFIX`` -- key prefix within the bucket (default ``certmesh/dashboard/``)

Thread-safe with proper locking.  Degrades gracefully to an in-memory-only
fallback when S3 is unavailable so the dashboard remains functional.
Transient S3 failures are retried with exponential backoff, and availability
is periodically re-checked after initial failure.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

# Interval (seconds) between S3 availability re-probes after a failure.
_S3_RECHECK_INTERVAL = 300  # 5 minutes

# Maximum number of retries for transient S3 errors.
_S3_MAX_RETRIES = 2

# Base delay (seconds) for exponential backoff between retries.
_S3_RETRY_BASE_DELAY = 0.5


@dataclass
class DashboardStateConfig:
    """Configuration for the S3 dashboard state store."""

    bucket: str = ""
    prefix: str = "certmesh/dashboard/"
    region: str = ""
    endpoint_url: str = ""
    kms_key_id: str = ""


def build_dashboard_state_config() -> DashboardStateConfig:
    """Build dashboard state config from environment variables."""
    return DashboardStateConfig(
        bucket=os.environ.get("CM_DASHBOARD_S3_BUCKET", ""),
        prefix=os.environ.get("CM_DASHBOARD_S3_PREFIX", "certmesh/dashboard/"),
        region=os.environ.get("CM_DASHBOARD_S3_REGION", ""),
        endpoint_url=os.environ.get("CM_DASHBOARD_S3_ENDPOINT_URL", ""),
        kms_key_id=os.environ.get("CM_DASHBOARD_S3_KMS_KEY_ID", ""),
    )


def _is_transient_s3_error(exc: Exception) -> bool:
    """Return True if *exc* looks like a transient S3 / network error worth retrying."""
    # Network-level errors
    if isinstance(exc, (ConnectionError, TimeoutError, OSError)):
        return True
    # botocore-specific transient errors
    cls_name = type(exc).__name__
    if cls_name in ("EndpointConnectionError", "ConnectTimeoutError", "ReadTimeoutError"):
        return True
    if cls_name == "ClientError":
        error_code = getattr(exc, "response", {}).get("Error", {}).get("Code", "")
        return error_code in ("Throttling", "RequestTimeout", "ServiceUnavailable", "SlowDown")
    return False


def _retry_s3(fn: Any, *, max_retries: int = _S3_MAX_RETRIES) -> Any:
    """Call *fn* with retry + exponential backoff for transient S3 errors."""
    last_exc: Exception | None = None
    for attempt in range(1 + max_retries):
        try:
            return fn()
        except Exception as exc:
            last_exc = exc
            if not _is_transient_s3_error(exc) or attempt >= max_retries:
                raise
            delay = _S3_RETRY_BASE_DELAY * (2**attempt)
            logger.debug(
                "Transient S3 error, retrying in %.1fs (attempt %d/%d)",
                delay,
                attempt + 1,
                max_retries,
            )
            time.sleep(delay)
    raise last_exc  # type: ignore[misc]  # unreachable but keeps mypy happy


class DashboardStateStore:
    """S3-backed state store with in-memory cache and graceful degradation.

    All S3 writes use server-side encryption: KMS (``aws:kms``) when
    ``kms_key_id`` is configured, otherwise AES-256 (SSE-S3).  Reads
    transparently decrypt KMS-encrypted objects via the S3 API.
    If S3 is unavailable, the store falls back to a local in-memory dict
    so the dashboard continues to function without persistence.

    Transient S3 errors (network timeouts, throttling) are retried with
    exponential backoff.  After an initial failure, S3 availability is
    periodically re-probed so recovery from temporary outages is automatic.

    Thread-safe: all reads/writes are protected by a ``threading.Lock``.
    """

    def __init__(self, config: DashboardStateConfig) -> None:
        self._config = config
        self._lock = threading.Lock()
        self._cache: dict[str, Any] = {}
        self._etags: dict[str, str] = {}  # S3 ETags for optimistic locking
        self._cache_timestamps: dict[str, float] = {}  # when each key was last fetched
        self._s3_client: Any | None = None
        self._s3_available = False
        self._last_s3_check: float = 0.0
        self._cache_ttl: float = 5.0  # seconds before cache is considered stale

        if config.bucket:
            try:
                import boto3
                from botocore.config import Config as BotoConfig

                kwargs: dict[str, Any] = {
                    "config": BotoConfig(
                        connect_timeout=5,
                        read_timeout=10,
                        retries={"max_attempts": 2},
                    ),
                }
                if config.region:
                    kwargs["region_name"] = config.region
                if config.endpoint_url:
                    kwargs["endpoint_url"] = config.endpoint_url
                self._s3_client = boto3.client("s3", **kwargs)
                # Probe the bucket with a HEAD request to verify connectivity.
                self._s3_client.head_bucket(Bucket=config.bucket)
                self._s3_available = True
                logger.info(
                    "Dashboard S3 state store connected",
                    extra={"bucket": config.bucket, "prefix": config.prefix},
                )
            except Exception:  # noqa: BLE001 - S3 graceful degradation; any failure → in-memory fallback
                logger.warning(
                    "Dashboard S3 state store unavailable, falling back to in-memory",
                    extra={"bucket": config.bucket},
                )
                self._s3_available = False
            self._last_s3_check = time.monotonic()

    # ── S3 key helpers ────────────────────────────────────────────────────

    def _s3_key(self, key: str) -> str:
        """Build the full S3 object key for a given logical key."""
        prefix = self._config.prefix.rstrip("/")
        return f"{prefix}/{key}.json"

    def _sse_kwargs(self) -> dict[str, str]:
        """Return server-side encryption kwargs for ``put_object`` calls.

        Uses KMS (``aws:kms``) when a KMS key ID is configured, otherwise
        falls back to S3-managed AES-256 (``AES256``).  S3 transparently
        decrypts KMS-encrypted objects on ``get_object`` provided the
        caller has ``kms:Decrypt`` permission, so reads need no changes.
        """
        if self._config.kms_key_id:
            return {
                "ServerSideEncryption": "aws:kms",
                "SSEKMSKeyId": self._config.kms_key_id,
            }
        return {"ServerSideEncryption": "AES256"}

    def _maybe_recheck_s3(self) -> None:
        """Re-probe S3 availability if enough time has passed since the last check.

        Must be called while ``self._lock`` is held.
        """
        if self._s3_available or self._s3_client is None:
            return
        now = time.monotonic()
        if now - self._last_s3_check < _S3_RECHECK_INTERVAL:
            return
        self._last_s3_check = now
        try:
            self._s3_client.head_bucket(Bucket=self._config.bucket)
            self._s3_available = True
            logger.info("Dashboard S3 state store recovered")
        except Exception:  # noqa: BLE001
            logger.debug("Dashboard S3 state store still unavailable")

    # ── Core operations ───────────────────────────────────────────────────

    def _is_cache_stale(self, key: str) -> bool:
        """Return True if the cache entry for *key* is older than the TTL."""
        ts = self._cache_timestamps.get(key, 0.0)
        return (time.monotonic() - ts) > self._cache_ttl

    def get(self, key: str, default: Any = None) -> Any:
        """Retrieve a value by *key*.

        Checks the in-memory cache first, then falls back to S3 if the
        value is not cached locally or the cache entry is stale.

        For multi-user consistency, cached values older than ``_cache_ttl``
        seconds are re-fetched from S3 so that changes made by other
        workers/pods become visible.

        Args:
            key: Logical key name (e.g. ``"inventory_snapshot"``).
            default: Value to return if *key* is not found.

        Returns:
            The stored value, or *default* if not found.
        """
        with self._lock:
            # Return cached value if fresh
            if key in self._cache and not self._is_cache_stale(key):
                return self._cache[key]

            self._maybe_recheck_s3()

            if self._s3_available and self._s3_client is not None:
                s3_key = self._s3_key(key)
                try:
                    resp = _retry_s3(
                        lambda: self._s3_client.get_object(
                            Bucket=self._config.bucket,
                            Key=s3_key,
                        )
                    )
                    data = json.loads(resp["Body"].read().decode("utf-8"))
                    self._cache[key] = data
                    self._cache_timestamps[key] = time.monotonic()
                    self._etags[key] = resp.get("ETag", "")
                    return data
                except Exception as exc:  # noqa: BLE001 - S3 graceful degradation; any failure → in-memory fallback
                    # NoSuchKey is expected for missing keys - don't warn.
                    if type(exc).__name__ != "NoSuchKey" and not (
                        hasattr(self._s3_client, "exceptions")
                        and isinstance(exc, self._s3_client.exceptions.NoSuchKey)
                    ):
                        logger.warning(
                            "Dashboard state S3 read failed, returning default",
                            extra={"key": key},
                        )
                    # Fall back to stale cache if available
                    if key in self._cache:
                        return self._cache[key]
                    return default

            # No S3 - return cached or default
            return self._cache.get(key, default)

    def put(self, key: str, value: Any) -> None:
        """Store a value under *key* with SSE-S3 encryption.

        Args:
            key: Logical key name.
            value: JSON-serialisable value.
        """
        with self._lock:
            self._cache[key] = value
            self._cache_timestamps[key] = time.monotonic()

            self._maybe_recheck_s3()

            if self._s3_available and self._s3_client is not None:
                s3_key = self._s3_key(key)
                body = json.dumps(value, default=str).encode("utf-8")
                try:
                    sse = self._sse_kwargs()
                    resp = _retry_s3(
                        lambda: self._s3_client.put_object(
                            Bucket=self._config.bucket,
                            Key=s3_key,
                            Body=body,
                            ContentType="application/json",
                            **sse,
                        )
                    )
                    if resp:
                        self._etags[key] = resp.get("ETag", "")
                except Exception:  # noqa: BLE001 - S3 graceful degradation; any failure → in-memory fallback
                    logger.warning(
                        "Dashboard state S3 write failed, data cached in-memory only",
                        extra={"key": key},
                    )

    def delete(self, key: str) -> None:
        """Remove a value by *key* from cache and S3.

        Args:
            key: Logical key name.
        """
        with self._lock:
            self._cache.pop(key, None)

            if self._s3_available and self._s3_client is not None:
                s3_key = self._s3_key(key)
                try:
                    _retry_s3(
                        lambda: self._s3_client.delete_object(
                            Bucket=self._config.bucket,
                            Key=s3_key,
                        )
                    )
                except Exception:  # noqa: BLE001 - S3 graceful degradation; any failure → in-memory fallback
                    logger.warning(
                        "Dashboard state S3 delete failed",
                        extra={"key": key},
                    )

    def list_keys(self, prefix: str = "") -> list[str]:
        """List all logical keys, optionally filtered by *prefix*.

        Args:
            prefix: Optional prefix filter applied to logical key names.

        Returns:
            List of matching key names (without the S3 prefix or ``.json`` suffix).
        """
        with self._lock:
            cached_keys = [k for k in self._cache if k.startswith(prefix)]

            if self._s3_available and self._s3_client is not None:
                try:
                    s3_prefix = self._s3_key(prefix)
                    resp = self._s3_client.list_objects_v2(
                        Bucket=self._config.bucket,
                        Prefix=s3_prefix,
                    )
                    base = self._config.prefix.rstrip("/") + "/"
                    for obj in resp.get("Contents", []):
                        raw_key = obj["Key"]
                        if raw_key.startswith(base) and raw_key.endswith(".json"):
                            logical = raw_key[len(base) : -len(".json")]
                            if logical not in cached_keys:
                                cached_keys.append(logical)
                except Exception:  # noqa: BLE001 - S3 graceful degradation; any failure → in-memory fallback
                    logger.warning("Dashboard state S3 list failed")

            return sorted(set(cached_keys))

    def append_to_list(self, key: str, item: Any, *, max_items: int = 100) -> None:
        """Atomically append *item* to a list stored under *key*.

        Reads the current value from S3 (bypassing cache) to reduce the
        window for lost updates when multiple workers append concurrently,
        appends *item*, trims to *max_items*, and writes back.

        Args:
            key: Logical key name storing a JSON list.
            item: JSON-serialisable value to append.
            max_items: Maximum number of items to retain (oldest trimmed first).
        """
        with self._lock:
            self._maybe_recheck_s3()

            current: list[Any] = []

            # Read directly from S3 (skip cache) to get the freshest state.
            if self._s3_available and self._s3_client is not None:
                s3_key = self._s3_key(key)
                try:
                    resp = _retry_s3(
                        lambda: self._s3_client.get_object(
                            Bucket=self._config.bucket,
                            Key=s3_key,
                        )
                    )
                    data = json.loads(resp["Body"].read().decode("utf-8"))
                    if isinstance(data, list):
                        current = data
                except Exception:  # noqa: BLE001 - fall through to cache
                    current = list(self._cache.get(key, []))
            else:
                current = list(self._cache.get(key, []))

            current.append(item)
            current = current[-max_items:]

            # Write back via the normal put path (updates cache + S3).
            self._cache[key] = current

            if self._s3_available and self._s3_client is not None:
                s3_key = self._s3_key(key)
                body = json.dumps(current, default=str).encode("utf-8")
                try:
                    sse = self._sse_kwargs()
                    _retry_s3(
                        lambda: self._s3_client.put_object(
                            Bucket=self._config.bucket,
                            Key=s3_key,
                            Body=body,
                            ContentType="application/json",
                            **sse,
                        )
                    )
                except Exception:  # noqa: BLE001 - S3 graceful degradation
                    logger.warning(
                        "Dashboard state S3 append write failed, data cached in-memory only",
                        extra={"key": key},
                    )

    @property
    def is_s3_available(self) -> bool:
        """Whether the S3 backend is reachable."""
        return self._s3_available


@dataclass
class CertificateSnapshot:
    """Point-in-time certificate inventory snapshot."""

    provider: str
    certificates: list[dict[str, Any]] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)
    total: int = 0
    expiring_soon: int = 0
    expired: int = 0
    errors: int = 0


@dataclass
class RenewalHistoryEntry:
    """Record of a certificate renewal or revocation action."""

    provider: str
    certificate_id: str
    action: str  # "renew" or "revoke"
    status: str  # "success" or "error"
    timestamp: float = field(default_factory=time.time)
    detail: str = ""
    user: str = ""
