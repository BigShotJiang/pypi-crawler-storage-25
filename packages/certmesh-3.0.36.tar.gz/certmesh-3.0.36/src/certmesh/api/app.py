"""
certmesh.api.app
=================

FastAPI application factory with lifespan context manager.

Production entrypoint (gunicorn)::

    gunicorn 'certmesh.api.app:create_app()' \\
        --worker-class uvicorn.workers.UvicornWorker \\
        --workers 4 \\
        --bind 0.0.0.0:8000
"""

from __future__ import annotations

import asyncio
import logging
import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from prometheus_client import make_asgi_app

from certmesh import __version__
from certmesh.api.apikeys import APIKeyConfig, APIKeyStore
from certmesh.api.auth import JWTBearer, OAuth2Config
from certmesh.api.compression import build_compression_config, register_compression
from certmesh.api.middleware import (
    RequestBodyLimitMiddleware,
    RequestIDMiddleware,
    register_exception_handlers,
)
from certmesh.api.rate_limiter import build_rate_limit_config, register_rate_limiter
from certmesh.api.routes import acm, digicert, health, info, vault_pki, venafi
from certmesh.api.routes.auth_routes import router as auth_router
from certmesh.exceptions import CertMeshError, ConfigurationError
from certmesh.logging_config import configure_logging as configure_structured_logging
from certmesh.settings import build_config, configure_logging, safe_bool, safe_int, validate_config

logger = logging.getLogger(__name__)


def _build_oauth2_config() -> OAuth2Config:
    """Build OAuth2 config from environment variables."""
    return OAuth2Config(
        enabled=safe_bool(os.environ.get("CM_OAUTH2_ENABLED"), default=False),
        issuer_url=os.environ.get("CM_OAUTH2_ISSUER_URL", ""),
        audience=os.environ.get("CM_OAUTH2_AUDIENCE", ""),
        jwks_uri=os.environ.get("CM_OAUTH2_JWKS_URI", ""),
        # CM_OAUTH2_REQUIRED_SCOPES env var name kept for backward compatibility;
        # semantics are OR (any one scope grants access), not AND.
        accepted_scopes=os.environ.get("CM_OAUTH2_REQUIRED_SCOPES", "").split(",")
        if os.environ.get("CM_OAUTH2_REQUIRED_SCOPES")
        else [],
        admin_scopes=os.environ.get("CM_OAUTH2_ADMIN_SCOPES", "").split(",")
        if os.environ.get("CM_OAUTH2_ADMIN_SCOPES")
        else [],
        write_scopes=os.environ.get("CM_OAUTH2_WRITE_SCOPES", "").split(",")
        if os.environ.get("CM_OAUTH2_WRITE_SCOPES")
        else [],
    )


def _build_api_key_config() -> APIKeyConfig:
    """Build API key exchange config from environment variables."""
    return APIKeyConfig(
        enabled=safe_bool(os.environ.get("CM_API_KEY_ENABLED"), default=True),
        default_ttl_seconds=safe_int(os.environ.get("CM_API_KEY_DEFAULT_TTL"), 900),
        max_ttl_seconds=safe_int(os.environ.get("CM_API_KEY_MAX_TTL"), 28800),
        max_active_keys=safe_int(os.environ.get("CM_API_KEY_MAX_ACTIVE"), 10000),
        max_keys_per_subject=safe_int(os.environ.get("CM_API_KEY_MAX_PER_SUBJECT"), 5),
    )


@asynccontextmanager
async def _lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Application lifespan: startup + shutdown."""
    # Structured JSON logging for the API — always JSON in production.
    configure_structured_logging(
        level=os.environ.get("CM_LOG_LEVEL", "INFO"),
        log_format="json",
    )

    config_file = os.environ.get("CM_CONFIG_FILE")
    cfg = build_config(config_file=config_file)
    configure_logging(cfg.get("logging", {}))

    app.state.config = cfg

    # Validate configuration early so misconfigurations surface at startup
    # rather than on the first request.  Warnings only — some validations
    # (e.g. vault.url required) may not apply when providers aren't in use.
    try:
        validate_config(cfg)
    except ConfigurationError as exc:
        logger.warning(
            "Configuration validation warning — some providers may not work",
            extra={"error": str(exc)},
        )

    # OAuth2
    oauth2_config = _build_oauth2_config()
    if oauth2_config.enabled:
        # SEC-16: Fail fast when OAuth2 is enabled but issuer/audience are
        # missing — without these, PyJWT silently skips validation and
        # accepts tokens from any issuer for any audience.
        if not oauth2_config.issuer_url:
            raise ConfigurationError(
                "CM_OAUTH2_ISSUER_URL is required when OAuth2 is enabled. "
                "Without it, JWT issuer validation is skipped."
            )
        if not oauth2_config.audience:
            raise ConfigurationError(
                "CM_OAUTH2_AUDIENCE is required when OAuth2 is enabled. "
                "Without it, JWT audience validation is skipped."
            )
    app.state.oauth2_config = oauth2_config
    app.state.jwt_bearer = JWTBearer(oauth2_config)

    # API key exchange
    api_key_config = _build_api_key_config()
    app.state.api_key_config = api_key_config
    app.state.api_key_store = APIKeyStore(
        max_keys=api_key_config.max_active_keys,
        max_keys_per_subject=api_key_config.max_keys_per_subject,
    )

    # Vault client (optional — used for KV secrets, not PKI TLS)
    vault_cfg = cfg.get("vault", {})
    app.state.vault_client = None
    if vault_cfg.get("url"):
        vault_url = vault_cfg["url"]
        vault_auth = vault_cfg.get("auth_method", "unknown")
        logger.info(
            "Initializing Vault client",
            extra={"vault_url": vault_url, "auth_method": vault_auth},
        )
        try:
            from certmesh.backends import vault_client as vc

            client = vc.get_authenticated_client(vault_cfg)
            app.state.vault_client = client
            logger.info(
                "Vault client initialized and authenticated",
                extra={"vault_url": vault_url, "auth_method": vault_auth},
            )
        except (CertMeshError, OSError) as exc:
            logger.warning(
                "Vault client initialization failed, continuing without Vault",
                extra={
                    "vault_url": vault_url,
                    "auth_method": vault_auth,
                    "error": str(exc),
                },
            )

    app.state.aws_required = False

    # Live log buffer for dashboard streaming
    from certmesh.api.log_buffer import BufferHandler, create_log_buffer

    log_buffer_size = safe_int(os.environ.get("CM_LOG_BUFFER_SIZE"), 1000)
    log_buffer = create_log_buffer(maxlen=log_buffer_size)
    log_buffer.set_event_loop(asyncio.get_running_loop())
    buffer_handler = BufferHandler(log_buffer)
    buffer_handler.setLevel(logging.DEBUG)
    logging.getLogger().addHandler(buffer_handler)
    app.state.log_buffer = log_buffer

    # Dashboard (disabled by default)
    dashboard_enabled = safe_bool(os.environ.get("CM_DASHBOARD_ENABLED"), default=False)
    app.state.dashboard_enabled = dashboard_enabled
    if dashboard_enabled:
        from certmesh.api.dashboard_state import DashboardStateStore, build_dashboard_state_config
        from certmesh.api.log_store import LogCapture, LogStore, build_log_store_config
        from certmesh.api.oauth2_flow import SessionManager, build_oauth2_flow_config

        oauth2_flow_config = build_oauth2_flow_config()
        app.state.oauth2_flow_config = oauth2_flow_config
        app.state.session_manager = SessionManager(
            secret=oauth2_flow_config.session_secret,
        )
        dashboard_state_config = build_dashboard_state_config()
        app.state.dashboard_state = DashboardStateStore(dashboard_state_config)

        # Log store for dashboard log viewer
        log_store_config = build_log_store_config()
        log_store = LogStore(log_store_config)
        app.state.log_store = log_store

        # Attach log capture handler to root logger
        log_handler = LogCapture(log_store)
        log_handler.setLevel(logging.DEBUG)
        logging.getLogger().addHandler(log_handler)

        # Jinja2 templates
        templates_dir = Path(__file__).parent / "templates"
        app.state.dashboard_templates = Jinja2Templates(directory=str(templates_dir))

        logger.info(
            "Dashboard enabled",
            extra={
                "oauth2_issuer": oauth2_flow_config.issuer_url or "(not set)",
                "s3_state_available": app.state.dashboard_state.is_s3_available,
                "log_store_enabled": log_store_config.enabled,
                "log_store_s3": log_store.is_s3_available,
            },
        )

    logger.info(
        "certmesh API started",
        extra={
            "oauth2_enabled": oauth2_config.enabled,
            "api_key_enabled": api_key_config.enabled,
            "rate_limiting": getattr(app.state, "rate_limit_enabled", True),
            "compression": os.environ.get("CM_COMPRESSION_ENABLED", "true"),
            "dashboard_enabled": dashboard_enabled,
        },
    )
    yield

    # Shutdown: clean up log buffer
    log_buffer.shutdown()
    logging.getLogger().removeHandler(buffer_handler)

    logger.info("certmesh API shutting down")


def create_app(**kwargs: Any) -> FastAPI:
    """FastAPI application factory."""
    # SEC-05: Disable OpenAPI docs in production unless explicitly enabled
    docs_enabled = safe_bool(os.environ.get("CM_DOCS_ENABLED"), default=False)

    app = FastAPI(
        title="certmesh",
        description="TLS certificate lifecycle management API",
        version=__version__,
        lifespan=_lifespan,
        docs_url="/docs" if docs_enabled else None,
        redoc_url="/redoc" if docs_enabled else None,
    )

    # Middleware (order matters — outermost first)
    app.add_middleware(RequestIDMiddleware)

    # SEC-16: Request body size limit (reject before deserialization)
    max_request_size = safe_int(os.environ.get("CM_API_MAX_REQUEST_SIZE"), 1_048_576)
    app.add_middleware(RequestBodyLimitMiddleware, max_size=max_request_size)

    # CORS
    cors_origins = os.environ.get("CM_API_CORS_ORIGINS", "").split(",")
    cors_origins = [o.strip() for o in cors_origins if o.strip()]
    if cors_origins:
        # SEC-06: Restrict CORS to specific methods and headers instead of wildcards
        cors_methods = os.environ.get("CM_API_CORS_METHODS", "GET,POST,PUT,DELETE,OPTIONS").split(
            ","
        )
        cors_methods = [m.strip() for m in cors_methods if m.strip()]
        cors_headers = os.environ.get(
            "CM_API_CORS_HEADERS",
            "Authorization,Content-Type,X-API-Key,X-Request-ID",
        ).split(",")
        cors_headers = [h.strip() for h in cors_headers if h.strip()]
        app.add_middleware(
            CORSMiddleware,
            allow_origins=cors_origins,
            allow_credentials=True,
            allow_methods=cors_methods,
            allow_headers=cors_headers,
        )

    # GZip compression (enabled by default)
    compression_config = build_compression_config()
    register_compression(app, compression_config)

    # Rate limiting (enabled by default, high limits)
    rate_limit_config = build_rate_limit_config()
    register_rate_limiter(app, rate_limit_config)
    app.state.rate_limit_enabled = rate_limit_config.enabled

    # Exception handlers (RFC 7807 compliant)
    register_exception_handlers(app)

    # Routes
    app.include_router(health.router)
    app.include_router(info.router)
    app.include_router(auth_router)
    app.include_router(digicert.router)
    app.include_router(venafi.router)
    app.include_router(vault_pki.router)
    app.include_router(acm.router)

    # Dashboard routes (conditionally enabled via CM_DASHBOARD_ENABLED)
    dashboard_enabled = safe_bool(os.environ.get("CM_DASHBOARD_ENABLED"), default=False)
    if dashboard_enabled:
        from certmesh.api.routes.dashboard import router as dashboard_router
        from certmesh.api.routes.logs import router as logs_router

        app.include_router(dashboard_router)
        app.include_router(logs_router)

        # Mount static files for dashboard CSS/JS
        static_dir = Path(__file__).parent / "static"
        app.mount(
            "/dashboard/static", StaticFiles(directory=str(static_dir)), name="dashboard_static"
        )

    # Prometheus metrics endpoint — unauthenticated by design (Prometheus scraping).
    # WARNING: Do not expose /metrics to untrusted networks. Use Kubernetes
    # NetworkPolicy or a reverse proxy to restrict access to the metrics endpoint.
    metrics_app = make_asgi_app()
    app.mount("/metrics", metrics_app)

    return app
