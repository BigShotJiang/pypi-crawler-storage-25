"""
certmesh.api.log_buffer
=========================

In-memory ring buffer for application logs with SSE subscriber support.

Captures log records via a standard :class:`logging.Handler` and makes
them available to dashboard SSE clients for near-real-time streaming.

Thread-safe: the logging handler may be called from any thread, while
SSE subscribers are async generators running on the event loop.
"""

from __future__ import annotations

import asyncio
import contextlib
import dataclasses
import logging
import threading
from collections import deque
from collections.abc import AsyncIterator
from typing import Any

logger = logging.getLogger(__name__)

# Maximum number of log entries retained in the ring buffer.
_DEFAULT_MAX_ENTRIES = 1000

# Maximum number of concurrent SSE subscribers.
_MAX_SUBSCRIBERS = 50

# Per-subscriber queue depth.  Entries beyond this are silently dropped
# for slow consumers (avoids unbounded memory growth).
_SUBSCRIBER_QUEUE_DEPTH = 200

# Fields that must not be overwritten by extra dict in LogEntry.to_dict().
_CORE_FIELDS = frozenset({"timestamp", "level", "logger", "message"})


@dataclasses.dataclass(frozen=True, slots=True)
class LogEntry:
    """Single log record captured from the Python logging system."""

    timestamp: float
    level: str
    logger_name: str
    message: str
    extra: dict[str, Any] = dataclasses.field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        # Build dict with extra first so core fields cannot be overwritten.
        d: dict[str, Any] = {k: v for k, v in self.extra.items() if k not in _CORE_FIELDS}
        d["timestamp"] = self.timestamp
        d["level"] = self.level
        d["logger"] = self.logger_name
        d["message"] = self.message
        return d


class LogBuffer:
    """Thread-safe ring buffer for log entries with async subscriber support.

    Log entries are appended from any thread (via :class:`BufferHandler`).
    SSE clients subscribe via :meth:`subscribe` and receive entries as an
    async iterator.
    """

    def __init__(self, maxlen: int = _DEFAULT_MAX_ENTRIES) -> None:
        self._buffer: deque[LogEntry] = deque(maxlen=maxlen)
        self._lock = threading.Lock()
        self._subscribers: set[asyncio.Queue[LogEntry | None]] = set()
        self._sub_lock = threading.Lock()
        self._loop: asyncio.AbstractEventLoop | None = None

    def set_event_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        """Store a reference to the running event loop for cross-thread notification."""
        self._loop = loop

    def append(self, entry: LogEntry) -> None:
        """Append a log entry and notify all active subscribers."""
        with self._lock:
            self._buffer.append(entry)

        # Broadcast to subscribers.  We use call_soon_threadsafe so that
        # queue.put_nowait runs on the event loop thread, avoiding any
        # race with async iteration.
        loop = self._loop
        if loop is not None and not loop.is_closed():
            with self._sub_lock:
                dead: list[asyncio.Queue[LogEntry | None]] = []
                for q in self._subscribers:
                    try:
                        loop.call_soon_threadsafe(q.put_nowait, entry)
                    except (asyncio.QueueFull, RuntimeError):
                        # QueueFull → slow consumer, drop entry.
                        # RuntimeError → loop closed during shutdown.
                        if loop.is_closed():
                            break
                        dead.append(q)
                for q in dead:
                    self._subscribers.discard(q)

    def get_recent(self, n: int = 100) -> list[LogEntry]:
        """Return the last *n* entries (oldest first)."""
        with self._lock:
            items = list(self._buffer)
        return items[-n:] if len(items) > n else items

    async def subscribe(self) -> AsyncIterator[LogEntry]:
        """Async generator yielding log entries as they arrive.

        Yields recent history first, then new entries in real time.
        Automatically unsubscribes on generator close or cancellation.
        """
        with self._sub_lock:
            if len(self._subscribers) >= _MAX_SUBSCRIBERS:
                raise RuntimeError("Too many log stream subscribers")
            q: asyncio.Queue[LogEntry | None] = asyncio.Queue(maxsize=_SUBSCRIBER_QUEUE_DEPTH)
            self._subscribers.add(q)
        try:
            # Yield buffered history so the client sees recent context.
            for entry in self.get_recent(100):
                yield entry

            # Stream new entries.
            while True:
                entry = await q.get()
                if entry is None:
                    # Shutdown sentinel.
                    break
                yield entry
        except (asyncio.CancelledError, GeneratorExit):
            pass
        finally:
            with self._sub_lock:
                self._subscribers.discard(q)

    def shutdown(self) -> None:
        """Signal all subscribers to stop and clear the buffer."""
        with self._sub_lock:
            loop = self._loop
            for q in self._subscribers:
                if loop is not None and not loop.is_closed():
                    with contextlib.suppress(asyncio.QueueFull, RuntimeError):
                        loop.call_soon_threadsafe(q.put_nowait, None)
            self._subscribers.clear()


class BufferHandler(logging.Handler):
    """Logging handler that feeds records into a :class:`LogBuffer`.

    Attach to the root logger to capture all application log output
    for the dashboard live-log viewer.
    """

    # Standard LogRecord attributes to exclude from extras.
    _STANDARD_KEYS = frozenset(logging.LogRecord("", 0, "", 0, "", (), None).__dict__.keys()) | {
        "message",
        "msg",
        "args",
    }

    def __init__(self, buffer: LogBuffer, level: int = logging.DEBUG) -> None:
        super().__init__(level)
        self._buffer = buffer

    def emit(self, record: logging.LogRecord) -> None:
        try:
            entry = LogEntry(
                timestamp=record.created,
                level=record.levelname,
                logger_name=record.name,
                message=self.format(record) if self.formatter else record.getMessage(),
                extra={
                    k: v
                    for k, v in record.__dict__.items()
                    if k not in self._STANDARD_KEYS and not k.startswith("_")
                },
            )
            self._buffer.append(entry)
        except Exception:  # noqa: BLE001 — logging handler must never raise
            self.handleError(record)


# ── Module-level singleton (set during app startup) ─────────────────────

_global_buffer: LogBuffer | None = None


def get_log_buffer() -> LogBuffer | None:
    """Return the application-wide LogBuffer, or ``None`` if not initialised."""
    return _global_buffer


def create_log_buffer(maxlen: int = _DEFAULT_MAX_ENTRIES) -> LogBuffer:
    """Create and register the application-wide LogBuffer."""
    global _global_buffer
    _global_buffer = LogBuffer(maxlen=maxlen)
    return _global_buffer
