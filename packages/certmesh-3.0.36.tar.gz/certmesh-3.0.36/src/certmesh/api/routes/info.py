"""
certmesh.api.routes.info
=========================

Server info endpoint for CLI remote management.

**No authentication required** — the CLI probes this endpoint before
authenticating to check version compatibility and detect whether
OAuth2 is enabled.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Request

from certmesh import __version__

logger = logging.getLogger(__name__)

router = APIRouter(tags=["info"])


@router.get("/api/v1/info")
async def server_info(request: Request) -> dict[str, Any]:
    """Return server version and configuration for CLI compatibility checks.

    This endpoint is intentionally unauthenticated so that the CLI can
    probe version compatibility and auth requirements before sending
    any credentials.
    """
    oauth2_cfg = getattr(request.app.state, "oauth2_config", None)
    return {
        "version": __version__,
        "oauth2_enabled": oauth2_cfg.enabled if oauth2_cfg else False,
        "api_version": "v1",
        "providers": ["digicert", "venafi", "vault-pki", "acm", "letsencrypt"],
    }
