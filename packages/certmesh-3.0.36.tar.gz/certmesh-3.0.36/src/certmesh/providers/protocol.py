"""
certmesh.providers.protocol
=============================

Provider interface documentation and capability registry.

This module defines the **CertificateProvider** protocol that documents the
expected function signatures for TLS CA provider modules.  It also provides
a **PROVIDER_CAPABILITIES** mapping that records which operations each
provider currently supports.

Adding a New Provider
~~~~~~~~~~~~~~~~~~~~~

1. Create ``src/certmesh/providers/<name>_client.py``
2. Implement the functions listed in :class:`CertificateProvider` that your
   provider supports.  Not all operations are required -- check
   ``PROVIDER_CAPABILITIES`` for the minimum viable set.
3. Create API routes in ``src/certmesh/api/routes/<name>.py``.
4. Add configuration defaults to ``src/certmesh/settings.py``.
5. Add tests in ``tests/test_<name>_client.py``.
6. Register capabilities in ``PROVIDER_CAPABILITIES`` below.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

# ---------------------------------------------------------------------------
# Provider interface (Protocol)
# ---------------------------------------------------------------------------

# We use a dataclass as a reference type rather than a typing.Protocol because
# the existing providers use plain functions (not methods) with heterogeneous
# signatures.  This dataclass documents the *conceptual* contract without
# requiring existing modules to adopt a class.


@dataclass(frozen=True)
class ProviderOperation:
    """Describes a single provider operation."""

    name: str
    description: str
    required: bool = False


# Canonical operations that a certificate provider may implement.
OPERATIONS = {
    "request_certificate": ProviderOperation(
        name="request_certificate",
        description="Request or order a new certificate from the CA.",
        required=True,
    ),
    "list_certificates": ProviderOperation(
        name="list_certificates",
        description="List certificates managed by this provider.",
    ),
    "describe_certificate": ProviderOperation(
        name="describe_certificate",
        description="Retrieve detailed metadata for a single certificate.",
    ),
    "download_certificate": ProviderOperation(
        name="download_certificate",
        description="Download certificate material (PEM/PKCS#12) from the CA.",
    ),
    "revoke_certificate": ProviderOperation(
        name="revoke_certificate",
        description="Revoke an issued certificate.",
    ),
    "renew_certificate": ProviderOperation(
        name="renew_certificate",
        description="Renew or re-issue an expiring certificate.",
    ),
    "search_certificates": ProviderOperation(
        name="search_certificates",
        description="Search certificates by CN, SAN, or other criteria.",
    ),
    "export_certificate": ProviderOperation(
        name="export_certificate",
        description="Export certificate + private key for external use.",
    ),
}


# ---------------------------------------------------------------------------
# Common return types (informational)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CertificateSummary:
    """Minimal certificate summary returned by list/search operations.

    Each provider may return a richer dataclass (e.g. ``ACMCertificateDetail``,
    ``DigiCertCertificateDetail``) but all include at least these fields.
    """

    identifier: str  # ARN, GUID, order ID, serial, etc.
    common_name: str
    not_after: datetime | None
    status: str = ""


# ---------------------------------------------------------------------------
# Provider capability registry
# ---------------------------------------------------------------------------

PROVIDER_CAPABILITIES: dict[str, frozenset[str]] = {
    "acm": frozenset(
        {
            "request_certificate",
            "list_certificates",
            "describe_certificate",
            "export_certificate",
            "renew_certificate",
            "delete_certificate",
        }
    ),
    "digicert": frozenset(
        {
            "request_certificate",
            "list_certificates",
            "describe_certificate",
            "download_certificate",
            "revoke_certificate",
            "search_certificates",
        }
    ),
    "venafi": frozenset(
        {
            "request_certificate",
            "list_certificates",
            "describe_certificate",
            "renew_certificate",
            "revoke_certificate",
            "search_certificates",
        }
    ),
    "letsencrypt": frozenset(
        {
            "request_certificate",
            "revoke_certificate",
        }
    ),
    "vault-pki": frozenset(
        {
            "request_certificate",
            "list_certificates",
            "describe_certificate",
            "revoke_certificate",
        }
    ),
}


def get_provider_capabilities(provider: str) -> frozenset[str]:
    """Return the set of supported operations for a provider.

    Returns an empty frozenset for unknown providers.
    """
    return PROVIDER_CAPABILITIES.get(provider, frozenset())


def supports_operation(provider: str, operation: str) -> bool:
    """Check whether *provider* supports *operation*."""
    return operation in PROVIDER_CAPABILITIES.get(provider, frozenset())


# All known provider names
KNOWN_PROVIDERS: frozenset[str] = frozenset(PROVIDER_CAPABILITIES)


def provider_function_mapping() -> dict[str, dict[str, str]]:
    """Return a mapping of provider -> operation -> actual function name.

    This documents the (sometimes inconsistent) function names across
    provider modules, enabling programmatic dispatch.
    """
    return {
        "acm": {
            "request_certificate": "request_certificate",
            "list_certificates": "list_certificates",
            "describe_certificate": "describe_certificate",
            "export_certificate": "export_certificate",
            "renew_certificate": "renew_certificate",
            "delete_certificate": "delete_certificate",
        },
        "digicert": {
            "request_certificate": "order_and_await_certificate",
            "list_certificates": "list_issued_certificates",
            "describe_certificate": "describe_certificate",
            "download_certificate": "download_issued_certificate",
            "revoke_certificate": "revoke_certificate",
            "search_certificates": "search_certificates",
        },
        "venafi": {
            "request_certificate": "request_certificate",
            "list_certificates": "list_certificates",
            "describe_certificate": "describe_certificate",
            "renew_certificate": "renew_and_download_certificate",
            "revoke_certificate": "revoke_certificate",
            "search_certificates": "search_certificates",
        },
        "letsencrypt": {
            "request_certificate": "request_certificate",
            "revoke_certificate": "revoke_certificate",
        },
        "vault-pki": {
            "request_certificate": "issue_pki_certificate",
            "list_certificates": "list_pki_certificates",
            "describe_certificate": "read_pki_certificate",
            "revoke_certificate": "revoke_pki_certificate",
        },
    }
