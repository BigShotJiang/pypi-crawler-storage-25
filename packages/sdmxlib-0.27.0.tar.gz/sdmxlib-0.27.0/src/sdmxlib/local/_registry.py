"""Registry — DuckDB-backed persistent SDMX artefact store.

All tables live in the ``sdmx`` DuckDB schema. The registry creates
a cursor with ``search_path = 'sdmx'`` for clean internal SQL.

Path-style construction: ``Registry(uri)`` is a cheap value object that
stashes the URI; the DuckDB connection is opened by ``open()`` /
``__enter__``. Use as a context manager::

    import sdmxlib as sl

    # Populate from a remote registry
    with sl.RestRegistry("https://sdmx.oecd.org/public/rest/") as remote:
        dsd = remote.DataStructure(agency="OECD", id="DSD_BLI").resolve()
        with sl.Registry("oecd.duckdb") as local:
            local.ingest(remote.registry)

    # Use later without network
    with sl.Registry("oecd.duckdb") as local:
        dsd = local.get(dsd_urn)
        cm = local.code_map(codelist_urn, lang="en")

    # Share an existing DuckDB connection (e.g. with cataloglib): use the
    # ``from_connection`` classmethod, which doesn't take ownership of the
    # connection's lifecycle.
    import duckdb

    conn = duckdb.connect("shared.duckdb")
    with sl.Registry.from_connection(conn) as local:
        local.add(...)
"""

from collections.abc import Iterable
from pathlib import Path
from typing import Any, Self

import attrs
import duckdb

from sdmxlib.model.collections import ItemList
from sdmxlib.model.ref import Ref
from sdmxlib.model.registry import InMemoryRegistry
from sdmxlib.model.urn import SdmxUrn
from sdmxlib.storage import readers, writers
from sdmxlib.storage.lazy import LazyCodelist, LazyHierarchy
from sdmxlib.storage.readers import _TYPE_REGISTRY
from sdmxlib.storage.schema import (
    SCHEMA_VERSION,
    get_schema_version,
    schema_exists,
)

# Map item-level artefact class -> (parent scheme type name, items attribute name)
_ITEM_TO_SCHEME: dict[str, tuple[str, str]] = {
    "Concept": ("ConceptScheme", "concepts"),
    "Code": ("Codelist", "codes"),
}


class Registry:
    """DuckDB-backed persistent SDMX artefact store.

    Path-style construction. ``Registry(uri)`` is cheap — it just stores
    the URI. The DuckDB connection is opened by ``open()`` (or implicitly
    by ``__enter__`` when used as a context manager) and closed on exit.

    Provides the same read interface as the read-only :class:`RegistryReader`
    Protocol, plus mutations (``add``, ``drop``, ``replace``) and direct SQL
    helpers (``code_map``, ``dsd_code_map``) that avoid creating Python
    objects.

    Typical usage::

        with Registry("store.duckdb") as reg:
            reg.add(codelist)
            cl = reg.get(codelist_urn)  # LazyCodelist

    Sharing an existing DuckDB connection (e.g. when co-located with a
    DuckLake catalog the caller already opened) is done via
    :meth:`from_connection`, which doesn't take ownership of the
    connection's lifecycle.
    """

    def __init__(
        self,
        uri: str | Path,
        *,
        source_registry: str | None = None,
    ) -> None:
        self._uri = Path(uri) if isinstance(uri, str) else uri
        self._source_registry = source_registry
        self._conn: duckdb.DuckDBPyConnection | None = None
        self._cursor: duckdb.DuckDBPyConnection | None = None
        self._owns_connection = True

    @property
    def uri(self) -> Path:
        """The URI this registry references. Available before opening."""
        return self._uri

    @property
    def connection(self) -> duckdb.DuckDBPyConnection:
        """The underlying DuckDB connection (for sharing).

        Raises:
            RuntimeError: If the registry hasn't been opened.
        """
        if self._conn is None:
            msg = (
                f"Registry({self._uri!r}) is not open. Use it as a context manager "
                "(``with Registry(uri) as reg: ...``) or call ``.open()`` first."
            )
            raise RuntimeError(msg)
        return self._conn

    def open(self) -> Self:
        """Open the DuckDB connection and run any pending schema migrations.

        Returns ``self`` so the call can be chained with a ``with``::

            with Registry("store.duckdb").open() as reg:
                ...

        Idempotent within a single open/close cycle; calling ``open()``
        on an already-open registry is a no-op.
        """
        if self._conn is not None:
            return self
        self._conn = duckdb.connect(str(self._uri))
        self._owns_connection = True
        self._initialise_schema()
        return self

    @classmethod
    def from_connection(
        cls,
        conn: duckdb.DuckDBPyConnection,
        *,
        source_registry: str | None = None,
    ) -> Self:
        """Wrap an existing DuckDB connection.

        The Registry does NOT take ownership of the connection — closing the
        Registry leaves the connection open. Use this when the connection
        is shared with another component (e.g. a co-located DuckLake catalog)
        that owns its lifecycle.
        """
        instance = cls.__new__(cls)
        instance._uri = Path(":connection:")  # noqa: SLF001 — alternate constructor sets private state
        instance._source_registry = source_registry  # noqa: SLF001
        instance._conn = conn  # noqa: SLF001
        instance._cursor = None  # noqa: SLF001
        instance._owns_connection = False  # noqa: SLF001
        instance._initialise_schema()  # noqa: SLF001
        return instance

    def _initialise_schema(self) -> None:
        """Migrate or open a cursor on the ``sdmx`` schema."""
        if self._conn is None:
            return
        version = get_schema_version(self._conn)
        if not schema_exists(self._conn) or version != SCHEMA_VERSION:
            from sdmxlib.storage.schema import migrate  # noqa: PLC0415

            self._cursor = migrate(self._conn)
        else:
            self._cursor = self._conn.cursor()
            self._cursor.execute("SET search_path = 'sdmx'")

    def __enter__(self) -> Self:
        if self._conn is None:
            self.open()
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def close(self) -> None:
        """Close the database connection (only if we own it).

        After ``close()``, the registry can be re-opened with ``open()``.
        """
        if self._conn is not None and self._owns_connection:
            self._conn.close()
        self._conn = None
        self._cursor = None

    @property
    def _c(self) -> duckdb.DuckDBPyConnection:
        """Internal accessor — returns the live cursor or raises a clear error.

        Replaces direct ``self._cursor`` use after the Path-style refactor;
        every method that touches the database routes through this so the
        error message points at the lifecycle problem instead of the
        downstream ``AttributeError`` you'd see with a bare ``None``.
        """
        if self._cursor is None:
            msg = (
                f"Registry({self._uri!r}) is not open. Use it as a context manager "
                "(``with Registry(uri) as reg: ...``) or call ``.open()`` first."
            )
            raise RuntimeError(msg)
        return self._cursor

    # ── Add ───────────────────────────────────────────────────────────────

    def add(self, artefact: Any, *, source_registry: str | None = None) -> None:
        """Add or replace an artefact in the store.

        ``source_registry`` overrides the registry-level default for this
        call. ``None`` (default) means "use the registry-level default."
        """
        tag = source_registry if source_registry is not None else self._source_registry
        writers.put_artefact(self._c, artefact, source_registry=tag)

    def add_all(
        self,
        artefacts: Iterable[Any],
        *,
        source_registry: str | None = None,
    ) -> None:
        """Add multiple artefacts."""
        for artefact in artefacts:
            self.add(artefact, source_registry=source_registry)

    # ── Get ───────────────────────────────────────────────────────────────

    def codelist(self, urn: "str | SdmxUrn[Any]") -> "LazyCodelist | None":
        """Return a LazyCodelist for tree navigation without materializing codes.

        Faster than ``get()`` for hierarchy traversal — skips ref resolution
        and only reads the codelist spine row::

            cl = local.codelist(geo_urn)
            cl.roots()  # top-level codes — SQL, no Python objects
            cl.narrower("1")  # direct children — SQL, only rows needed
        """
        from sdmxlib.storage.readers import make_lazy_codelist  # noqa: PLC0415

        return make_lazy_codelist(self._c, str(urn))

    def get[T](self, urn: "SdmxUrn[T]", *, eager: bool = False) -> "T | None":
        """Look up an artefact by URN.

        For Codelists, returns a ``LazyCodelist`` by default (codes not
        materialized). Pass ``eager=True`` to get a real ``Codelist``.

        All ``Ref`` fields on the returned artefact are resolved from
        DuckDB so that standard traversal syntax works::

            dsd = local.get(dsd_urn)
            dsd.dimensions["FREQ"].codelist()  # -> LazyCodelist
            dsd.code_map(lang="en")  # works
        """
        result = readers.get_artefact(self._c, str(urn), eager=eager)
        if result is None:
            return None
        if not isinstance(result, (LazyCodelist, LazyHierarchy)):
            self._resolve_refs(result, set())
        return result  # type: ignore[return-value]

    def get_all[T](self, artefact_type: "type[T]") -> "list[T]":
        """All artefacts of the given Python type."""
        results = readers.get_all(self._c, artefact_type)
        for r in results:
            if not isinstance(r, (LazyCodelist, LazyHierarchy)):
                self._resolve_refs(r, set())
        return results  # type: ignore[return-value]

    # ── Ref resolution ─────────────────────────────────────────────────

    def _resolve_refs(self, obj: Any, visited: set[int]) -> None:
        """Walk attrs fields, resolving ``Ref`` targets from DuckDB."""
        if not attrs.has(type(obj)) or isinstance(obj, type):
            return
        oid = id(obj)
        if oid in visited:
            return
        visited.add(oid)

        for f in attrs.fields(type(obj)):
            value = getattr(obj, f.name, None)
            if value is None:
                continue
            if isinstance(value, Ref):
                self._resolve_ref_field(obj, f.name, value)
            elif isinstance(value, ItemList):
                for item in value:
                    self._resolve_refs(item, visited)
            elif attrs.has(type(value)) and not isinstance(value, type):
                self._resolve_refs(value, visited)

    def _resolve_ref_field(self, obj: Any, name: str, ref: "Ref[Any]") -> None:
        """Resolve a single Ref field from DuckDB and set it on *obj*."""
        if ref._resolved is not None:  # noqa: SLF001
            return

        urn_str = str(ref.urn)
        target = self._resolve_target(urn_str)
        if target is not None:
            resolved = Ref.of(ref.urn, target)
            setattr(obj, name, resolved)

    def _resolve_target(self, urn_str: str) -> Any | None:
        """Load an artefact by URN string for Ref resolution."""
        parsed = SdmxUrn.parse(urn_str)
        if parsed.item_id is not None:
            return self._resolve_item_urn(parsed)

        return readers.get_artefact(self._c, urn_str)

    def _resolve_item_urn(self, parsed: "SdmxUrn[Any]") -> Any | None:
        """Resolve an item-level URN by loading its parent scheme."""
        scheme_info = _ITEM_TO_SCHEME.get(parsed.artefact_class)
        if scheme_info is None:
            return None

        scheme_class_name, items_attr = scheme_info
        scheme_cls = _TYPE_REGISTRY.get(scheme_class_name)
        if scheme_cls is None:
            return None

        parent_urn = SdmxUrn.make(
            scheme_cls,
            package=parsed.package,
            artefact_class=scheme_class_name,
            agency=parsed.agency,
            id=parsed.id,
            version=parsed.version,
        )
        parent_urn_str = str(parent_urn)

        # Try exact match first
        parent = readers.get_artefact(self._c, parent_urn_str, eager=True)

        # Fallback for version="latest" — find by agency+id
        if parent is None and parsed.version == "latest":
            row = self._c.execute(
                """
                SELECT urn FROM artefact
                WHERE artefact_type = ? AND agency_id = ? AND resource_id = ?
                """,
                [scheme_class_name, parsed.agency, parsed.id],
            ).fetchone()
            if row:
                parent = readers.get_artefact(self._c, row[0], eager=True)

        if parent is None:
            return None

        items = getattr(parent, items_attr, None)
        if items is None:
            return None

        return items.get(parsed.item_id) if hasattr(items, "get") else None

    # ── Ref ────────────────────────────────────────────────────────────────

    def ref[T](self, urn: "SdmxUrn[T]") -> "Ref[T]":
        """Return an unresolved Ref for this URN."""
        return Ref[T].unresolved(urn)

    # ── Contains / len ────────────────────────────────────────────────────

    def __contains__(self, urn: object) -> bool:
        if isinstance(urn, SdmxUrn):
            row = self._c.execute(
                "SELECT 1 FROM artefact WHERE urn = ?",
                [str(urn)],
            ).fetchone()
            return row is not None
        return False

    def __len__(self) -> int:
        row = self._c.execute("SELECT COUNT(*) FROM artefact").fetchone()
        return row[0]  # type: ignore[index]

    def __repr__(self) -> str:
        rows = self._c.execute("SELECT artefact_type, COUNT(*) FROM artefact GROUP BY artefact_type").fetchall()
        counts = ", ".join(f"{name}={cnt}" for name, cnt in rows)
        return f"Registry({counts or 'empty'})"

    # ── Mutations ─────────────────────────────────────────────────────────

    def drop(self, urn: "SdmxUrn[Any]") -> bool:
        """Remove an artefact by URN. Returns True if it existed."""
        return writers.drop_artefact(self._c, str(urn))

    def replace(self, old_urn: "SdmxUrn[Any]", new: Any) -> None:
        """Remove the old artefact and add the new one."""
        writers.drop_artefact(self._c, str(old_urn))
        self.add(new)

    # ── Direct SQL helpers ────────────────────────────────────────────────

    def code_map(self, codelist_urn: "str | SdmxUrn[Any]", *, lang: str) -> dict[str, str]:
        """Return {code_id: label} for a codelist without creating Code objects."""
        return readers.code_map(self._c, str(codelist_urn), lang=lang)

    def dsd_code_map(self, dsd_urn: "str | SdmxUrn[Any]", *, lang: str) -> dict[str, dict[str, str]]:
        """Return {component_id: {code_id: label}} for all enumerated dimensions."""
        return readers.code_map_for_dsd(self._c, str(dsd_urn), lang=lang)

    # ── Bulk ──────────────────────────────────────────────────────────────

    def ingest(
        self,
        registry: InMemoryRegistry,
        *,
        source_registry: str | None = None,
    ) -> None:
        """Copy all artefacts from an in-memory Registry into this store.

        ``source_registry`` overrides the registry-level default for this
        bulk import.
        """
        self.add_all(registry._store.values(), source_registry=source_registry)  # noqa: SLF001

    # ── Escape hatch ──────────────────────────────────────────────────────

    def to_registry(self) -> InMemoryRegistry:
        """Load everything into an in-memory Registry with full Ref interning."""
        reg = InMemoryRegistry()
        rows = self._c.execute("SELECT urn, artefact_type FROM artefact").fetchall()
        for urn_str, _artefact_type in rows:
            obj = readers.get_artefact(self._c, urn_str, eager=True)
            if obj is not None:
                reg.add(obj)
        return reg
