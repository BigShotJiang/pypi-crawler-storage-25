"""DuckDBDataStore — DuckDB-backed implementation of :class:`DataStore`.

Path-style: ``DuckDBDataStore(uri)`` is a cheap value object; the DuckDB
connection opens on ``open()`` / ``__enter__`` and closes on exit.

For the common case where a :class:`~sdmxlib.local.Registry` and the
data store share a single DuckDB session (so SQL can join SDMX codelists
to observation rows without cross-connection plumbing), use the
:meth:`from_registry` classmethod.

External catalogs (DuckLake, raw Parquet, S3 via httpfs) can be
``ATTACH``-ed at open time so cross-database joins work without
file-handle juggling.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import TYPE_CHECKING, Literal, Self

import duckdb
import polars as pl

from sdmxlib.model.binding import DataflowBinding

if TYPE_CHECKING:
    import pyarrow as pa

    from sdmxlib.local._registry import Registry
    from sdmxlib.rest import ComponentFilter

    # Sources that ``write_observations`` accepts. Type-checking only:
    # the runtime path branches on isinstance(), so a runtime alias isn't
    # needed (and pyarrow is an optional dependency).
    WriteSource = pl.DataFrame | pl.LazyFrame | pa.Table | duckdb.DuckDBPyRelation


class DuckDBDataStore:
    """A :class:`~sdmxlib.data_store.DataStore` backed by DuckDB.

    Two construction paths:

    1. ``DuckDBDataStore(uri)`` — Path-style. Opens its own DuckDB
       connection at ``open()`` / ``__enter__`` time. Use when the data
       store stands alone (no registry sharing).
    2. ``DuckDBDataStore.from_registry(reg, attach=, extensions=)`` —
       reuses a :class:`Registry`'s connection so the SDMX structural
       side and the observation side share a single DuckDB session.
       Lazy codelists keep working across queries, and queries can join
       across the two without cross-connection plumbing.

    The ``attach`` / ``extensions`` / ``azure_credentials`` knobs
    configure the DuckDB session at open time. ``attach`` maps
    ``alias → ATTACH spec`` (each executed as
    ``ATTACH <spec> AS <alias>``); ``extensions`` INSTALL+LOAD the
    listed extensions before any ATTACH. ``azure_credentials`` is a
    dict that drives a DuckDB ``CREATE SECRET`` for ADLSv2 access — see
    below.

    Azure credential dicts accept one of three shapes:

    * ``{"connection_string": "..."}`` → ``PROVIDER 'config'`` with
      ``CONNECTION_STRING``.
    * ``{"account_name": ..., "tenant_id": ..., "client_id": ...,
      "client_secret": ...}`` → ``PROVIDER 'service_principal'``.
    * ``{"chain": "cli"}`` (or ``"env"``, ``"managed_identity"``) →
      ``PROVIDER 'credential_chain'`` with the named chain.

    When ``azure_credentials`` is set, or any ATTACH spec contains
    ``abfss://``, the ``azure`` extension is auto-INSTALL+LOADed so
    DATA_PATH URIs like ``abfss://acct.dfs.core.windows.net/c/p/`` work
    out of the box.

    Example::

        with sl.Registry("sdmx.duckdb") as reg:
            store = sl.DuckDBDataStore.from_registry(
                reg,
                attach={"lake": "ducklake:'catalog.duckdb' (READ_ONLY)"},
                extensions=["ducklake"],
            )
            df = store.query(binding, where=["REF_AREA = ?"], params=["CA"])
    """

    def __init__(
        self,
        uri: str | Path,
        *,
        attach: dict[str, str | tuple[str, str]] | None = None,
        extensions: list[str] | None = None,
        azure_credentials: dict[str, str] | None = None,
    ) -> None:
        self._uri: Path = Path(uri) if isinstance(uri, str) else uri
        self._attach = attach
        self._extensions = extensions
        self._azure_credentials = azure_credentials
        self._registry: Registry | None = None
        self._conn: duckdb.DuckDBPyConnection | None = None
        self._owns_connection = True

    @property
    def uri(self) -> Path:
        """The URI this data store references. Available before opening."""
        return self._uri

    @property
    def connection(self) -> duckdb.DuckDBPyConnection:
        """The shared DuckDB connection.

        Raises:
            RuntimeError: If the data store hasn't been opened.
        """
        if self._conn is None:
            msg = (
                f"DuckDBDataStore({self._uri!r}) is not open. Use it as a context "
                "manager (``with DuckDBDataStore(uri) as store: ...``) or call "
                "``.open()`` first."
            )
            raise RuntimeError(msg)
        return self._conn

    @property
    def registry(self) -> Registry | None:
        """The :class:`Registry` whose connection is shared, or ``None``.

        Set when the data store was constructed via :meth:`from_registry`;
        ``None`` for standalone Path-style construction.
        """
        return self._registry

    def open(self) -> Self:
        """Open the DuckDB connection and apply ``extensions`` + ``attach``.

        Idempotent within a single open/close cycle.
        """
        if self._conn is not None:
            return self
        self._conn = duckdb.connect(str(self._uri))
        self._owns_connection = True
        self._configure_session()
        return self

    @classmethod
    def from_registry(
        cls,
        registry: Registry,
        *,
        attach: dict[str, str | tuple[str, str]] | None = None,
        extensions: list[str] | None = None,
        azure_credentials: dict[str, str] | None = None,
    ) -> Self:
        """Wrap a :class:`Registry`'s open connection.

        The data store does NOT take ownership of the connection — closing
        the data store leaves the registry's connection open. The registry
        must already be open (i.e. inside its ``with`` block).

        Args:
            registry: An open :class:`Registry`. Its connection is reused.
            attach: ``alias → ATTACH spec`` mapping. Executed at open time.
            extensions: DuckDB extensions to INSTALL+LOAD before any ATTACH.
            azure_credentials: Optional Azure secret config. See
                :meth:`__init__` for accepted keys.
        """
        instance = cls.__new__(cls)
        instance._uri = registry.uri  # noqa: SLF001 — alternate constructor sets private state
        instance._attach = attach  # noqa: SLF001
        instance._extensions = extensions  # noqa: SLF001
        instance._azure_credentials = azure_credentials  # noqa: SLF001
        instance._registry = registry  # noqa: SLF001
        instance._conn = registry.connection  # noqa: SLF001
        instance._owns_connection = False  # noqa: SLF001
        instance._configure_session()  # noqa: SLF001
        return instance

    def _configure_session(self) -> None:
        """Apply the configured extensions + ATTACH specs to the live connection."""
        if self._conn is None:
            return
        extensions = list(self._extensions or [])
        # Auto-load the azure extension if we need to talk to abfss:// or
        # have credentials configured. Callers can override by listing
        # "azure" in extensions themselves — INSTALL/LOAD are idempotent.
        if self._needs_azure() and "azure" not in extensions:
            extensions.append("azure")
        if extensions:
            for ext in extensions:
                self._conn.execute(f"INSTALL {_sql_identifier(ext)}")
                self._conn.execute(f"LOAD {_sql_identifier(ext)}")
            # Loading extensions can change the search_path; reset to
            # ``sdmx`` so any colocated Registry's internal queries stay clean.
            self._conn.execute("SET search_path = 'sdmx'")
        if self._azure_credentials:
            sql = _azure_create_secret_sql(self._azure_credentials)
            self._conn.execute(sql)
        if self._attach:
            for alias, spec in self._attach.items():
                url, options = _split_attach_spec(spec)
                sql = f"ATTACH {url} AS {_sql_identifier(alias)}"
                if options:
                    sql += f" {options}"
                self._conn.execute(sql)
            self._conn.execute("SET search_path = 'sdmx'")

    def _needs_azure(self) -> bool:
        """True if Azure secret/extension setup is required for this session."""
        if self._azure_credentials:
            return True
        if self._attach:
            for spec in self._attach.values():
                spec_text = spec if isinstance(spec, str) else " ".join(s for s in spec if s)
                if "abfss://" in spec_text:
                    return True
        return False

    def __enter__(self) -> Self:
        if self._conn is None:
            self.open()
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def close(self) -> None:
        """Close the database connection (only if we own it)."""
        if self._conn is not None and self._owns_connection:
            self._conn.close()
        self._conn = None

    # ── DataStore protocol ───────────────────────────────────────────────

    def query(
        self,
        binding: DataflowBinding,
        *,
        where: list[str] | None = None,
        params: list[object] | None = None,
        component_filter: ComponentFilter | None = None,
        columns: list[str] | None = None,
        order_by: str | None = None,
        limit: int | None = None,
    ) -> pl.DataFrame:
        """Run a SELECT against ``binding.table_location``.

        Filter clauses use SDMX dimension/measure ids; the binding's
        column maps determine the physical column names. For v1 we
        assume identity mapping (SDMX id == physical column) — when
        non-identity mappings are needed, this method is the seam to
        wire in the rename.

        When ``binding.series_attributes_location`` is set, the sidecar
        table is LEFT JOINed on the columns common to both tables (found
        via DuckDB ``DESCRIBE``). This is what makes
        ``binding.attribute_column_map`` columns reachable when the
        attributes live on a sibling table rather than denormalised into
        the fact table.
        """
        conn = self.connection
        sql, sql_params = _build_query(
            conn=conn,
            binding=binding,
            where=where,
            params=params,
            component_filter=component_filter,
            columns=columns,
            order_by=order_by,
            limit=limit,
        )
        cur = conn.execute(sql, sql_params)
        col_names = [d[0] for d in cur.description] if cur.description else []
        rows = cur.fetchall()
        if not rows:
            return pl.DataFrame(schema=col_names)
        return pl.from_records(rows, schema=col_names, orient="row")

    def write_observations(
        self,
        *,
        schema: str,
        table: str,
        source: WriteSource,
        partition_by: tuple[str, ...] = (),
        mode: Literal["overwrite", "append"] = "overwrite",
        lake_alias: str = "lake",
    ) -> None:
        """Materialise observation rows into a DuckLake-managed table.

        Routes through the ATTACHed lake (``lake_alias``, default ``lake``).
        Schema is created if missing. ``mode="overwrite"`` uses
        ``CREATE OR REPLACE TABLE``; ``mode="append"`` uses ``INSERT INTO``
        and requires the target table to already exist with a compatible
        schema. ``partition_by`` is currently informational — DuckLake
        infers partition columns from table definition; we record the
        layout on the matching :class:`DataflowBinding`.

        Args:
            schema: Target schema inside the lake (created if absent).
            table: Target table name. Together with ``schema`` and
                ``lake_alias`` this resolves to
                ``<lake_alias>.<schema>.<table>``.
            source: Rows to write. Anything DuckDB can register as a
                virtual relation — Polars frames, Arrow tables, or an
                existing DuckDB relation.
            partition_by: SDMX dimension ids the table is partitioned on.
            mode: ``"overwrite"`` replaces the table atomically;
                ``"append"`` inserts into an existing table.
            lake_alias: ATTACH alias of the target lake. Defaults to
                ``"lake"`` to match the conventional bundle layout.
        """
        if not _is_valid_identifier(schema):
            msg = f"Invalid schema identifier: {schema!r}"
            raise ValueError(msg)
        if not _is_valid_identifier(table):
            msg = f"Invalid table identifier: {table!r}"
            raise ValueError(msg)
        if not _is_valid_identifier(lake_alias):
            msg = f"Invalid lake alias: {lake_alias!r}"
            raise ValueError(msg)

        conn = self.connection
        # Register the source as a temporary view the CTAS can scan.
        view_name = f"__sdmxlib_write_obs_{id(source):x}"
        rel = _as_relation(conn, source)
        rel.create_view(view_name, replace=True)
        try:
            target = f"{lake_alias}.{schema}.{table}"
            conn.execute(f"CREATE SCHEMA IF NOT EXISTS {lake_alias}.{schema}")
            if mode == "overwrite":
                conn.execute(f"CREATE OR REPLACE TABLE {target} AS SELECT * FROM {view_name}")
            elif mode == "append":
                conn.execute(f"INSERT INTO {target} SELECT * FROM {view_name}")
            else:
                msg = f"Unknown mode: {mode!r} (expected 'overwrite' or 'append')"
                raise ValueError(msg)
        finally:
            conn.execute(f"DROP VIEW IF EXISTS {view_name}")
        _ = partition_by  # silence unused — see docstring

    def query_stream(
        self,
        binding: DataflowBinding,
        *,
        where: list[str] | None = None,
        params: list[object] | None = None,
        component_filter: ComponentFilter | None = None,
        columns: list[str] | None = None,
        order_by: str | None = None,
        chunk_rows: int = 10_000,
    ) -> Iterator[pa.RecordBatch]:
        """Stream the same scan as :meth:`query` as Arrow record batches.

        Uses DuckDB's Arrow integration (``to_arrow_reader``) so peak
        memory stays roughly proportional to ``chunk_rows`` rather than
        the full result size. See :meth:`sdmxlib.DataStore.query_stream`.
        """
        conn = self.connection
        sql, sql_params = _build_query(
            conn=conn,
            binding=binding,
            where=where,
            params=params,
            component_filter=component_filter,
            columns=columns,
            order_by=order_by,
            limit=None,
        )
        reader = conn.execute(sql, sql_params).to_arrow_reader(chunk_rows)
        yield from reader


# ── SQL helpers ─────────────────────────────────────────────────────────


def _build_query(
    *,
    conn: duckdb.DuckDBPyConnection,
    binding: DataflowBinding,
    where: list[str] | None,
    params: list[object] | None,
    component_filter: ComponentFilter | None,
    columns: list[str] | None,
    order_by: str | None,
    limit: int | None,
) -> tuple[str, list[object]]:
    """Build a parameterised SELECT + parameter list against the binding's table(s).

    Table names come from the binding (sdmxlib-controlled artefact) and
    are interpolated as-is. WHERE clauses are interpolated as-is too
    (callers compose them) but their values must be passed via ``params``
    for parameterisation — never f-stringed.

    When ``binding.series_attributes_location`` is set, the sidecar table
    is LEFT JOINed on the columns common to both tables. When
    ``component_filter`` is provided, it is translated to additional
    ``col IN (?, ?, ...)`` fragments via the binding's dimension and
    attribute column maps and ANDed in.
    """
    cols_sql = ", ".join(columns) if columns else "*"
    main = f"{binding.database_role}.{binding.table_location}"
    sidecar_loc = binding.series_attributes_location
    sidecar = f"{binding.database_role}.{sidecar_loc}" if sidecar_loc is not None else None
    if sidecar is None:
        sql = f"SELECT {cols_sql} FROM {main}"
    else:
        join_keys = _shared_columns(conn, main, sidecar)
        if not join_keys:
            msg = (
                f"DataflowBinding.series_attributes_location {sidecar!r} "
                f"shares no columns with {main!r}; cannot derive JOIN keys"
            )
            raise ValueError(msg)
        keys_sql = ", ".join(join_keys)
        sql = f"SELECT {cols_sql} FROM {main} LEFT JOIN {sidecar} USING ({keys_sql})"

    fragments = list(where or [])
    sql_params: list[object] = list(params or [])
    if component_filter is not None:
        cf_fragments, cf_params = component_filter.to_where_clauses(
            binding.dimension_column_map,
            binding.attribute_column_map,
        )
        fragments.extend(cf_fragments)
        sql_params.extend(cf_params)

    if fragments:
        sql += " WHERE " + " AND ".join(fragments)
    if order_by:
        sql += f" ORDER BY {order_by}"
    if limit is not None:
        sql += f" LIMIT {int(limit)}"
    return sql, sql_params


def _describe_columns(conn: duckdb.DuckDBPyConnection, table: str) -> list[str]:
    """Return column names for ``table`` via DuckDB ``DESCRIBE``."""
    rows = conn.execute(f"DESCRIBE {table}").fetchall()
    return [str(r[0]) for r in rows]


def _shared_columns(conn: duckdb.DuckDBPyConnection, table_a: str, table_b: str) -> list[str]:
    """Columns present in both tables, in ``table_a`` order."""
    cols_b = set(_describe_columns(conn, table_b))
    return [c for c in _describe_columns(conn, table_a) if c in cols_b]


def _sql_identifier(name: str) -> str:
    """Escape a SQL identifier (extension name, ATTACH alias).

    DuckDB identifiers are case-insensitive and may contain alphanumerics
    and underscores. Reject anything else to avoid SQL injection through
    extension/alias names.
    """
    if not _is_valid_identifier(name):
        msg = f"Invalid SQL identifier: {name!r}"
        raise ValueError(msg)
    return name


def _is_valid_identifier(name: str) -> bool:
    """True if ``name`` is a safe SQL identifier (alphanumeric + underscore)."""
    return bool(name) and all(c.isalnum() or c == "_" for c in name)


def _split_attach_spec(spec: object) -> tuple[str, str]:
    """Normalise an ATTACH spec into ``(url, options)``.

    Two shapes accepted:

    - ``"'ducklake:/path'"`` — connection URL only; no options.
    - ``("'ducklake:/path'", "(DATA_PATH '/p/')")`` — URL + trailing
      options clause that goes after ``AS alias``.

    Returns ``(url, options)`` strings; ``options`` is empty when none.
    """
    if isinstance(spec, str):
        return spec, ""
    if isinstance(spec, tuple) and len(spec) == 2:
        url, options = spec
        return str(url), str(options or "")
    msg = f"Unsupported ATTACH spec shape: {type(spec).__name__}"
    raise TypeError(msg)


def _azure_create_secret_sql(creds: dict[str, str]) -> str:
    """Render a DuckDB ``CREATE SECRET`` statement for an Azure credential dict.

    Three accepted shapes:

    * ``{"connection_string": "..."}`` → ``PROVIDER 'config'`` with
      ``CONNECTION_STRING``.
    * ``{"account_name": ..., "tenant_id": ..., "client_id": ...,
      "client_secret": ...}`` → ``PROVIDER 'service_principal'``.
    * ``{"chain": "cli"|"env"|"managed_identity"}`` →
      ``PROVIDER 'credential_chain'``.
    """
    name = "sdmxlib_azure"
    if "connection_string" in creds:
        cs = _sql_string_literal(creds["connection_string"])
        return f"CREATE OR REPLACE SECRET {name} (TYPE AZURE, PROVIDER 'config', CONNECTION_STRING {cs})"
    if "chain" in creds:
        chain = _sql_string_literal(creds["chain"])
        clauses = ["TYPE AZURE", "PROVIDER 'credential_chain'", f"CHAIN {chain}"]
        if "account_name" in creds:
            clauses.append(f"ACCOUNT_NAME {_sql_string_literal(creds['account_name'])}")
        return f"CREATE OR REPLACE SECRET {name} ({', '.join(clauses)})"
    required = {"account_name", "tenant_id", "client_id", "client_secret"}
    if required.issubset(creds):
        return (
            f"CREATE OR REPLACE SECRET {name} ("
            f"TYPE AZURE, PROVIDER 'service_principal', "
            f"TENANT_ID {_sql_string_literal(creds['tenant_id'])}, "
            f"CLIENT_ID {_sql_string_literal(creds['client_id'])}, "
            f"CLIENT_SECRET {_sql_string_literal(creds['client_secret'])}, "
            f"ACCOUNT_NAME {_sql_string_literal(creds['account_name'])}"
            f")"
        )
    msg = (
        "azure_credentials must be one of: "
        "{'connection_string': ...}, "
        "{'account_name': ..., 'tenant_id': ..., 'client_id': ..., 'client_secret': ...}, "
        "or {'chain': 'cli'|'env'|'managed_identity'}. "
        f"Got keys: {sorted(creds.keys())}"
    )
    raise ValueError(msg)


def _sql_string_literal(value: str) -> str:
    """Quote a value as a SQL string literal — single-quotes, doubled internals."""
    escaped = value.replace("'", "''")
    return f"'{escaped}'"


def _as_relation(
    conn: duckdb.DuckDBPyConnection,
    source: WriteSource,
) -> duckdb.DuckDBPyRelation:
    """Materialise ``source`` as a DuckDB relation the connection can scan.

    Handles Polars frames (eager + lazy), Arrow tables, and existing
    DuckDB relations uniformly. ``LazyFrame`` is collected to a DataFrame
    first — callers that need streaming behaviour for very large frames
    can pass an Arrow ``RecordBatchReader`` via :func:`pyarrow.Table.from_batches`.
    """
    if isinstance(source, duckdb.DuckDBPyRelation):
        return source
    if isinstance(source, pl.LazyFrame):
        source = source.collect()
    if isinstance(source, pl.DataFrame):
        return conn.from_arrow(source.to_arrow())
    # Last branch: pyarrow.Table. Imported lazily to keep pyarrow optional.
    return conn.from_arrow(source)
