"""FederatedRegistry — agency-routed dispatch across multiple sources.

The headline of #46. Composes any number of :class:`~sdmxlib.model.registry.Registry`
instances (in-memory, local DuckDB, REST) and dispatches each ``get(urn)``
call to the source responsible for the URN's maintenance agency. The user
sees a single registry that resolves URNs from many backends.

Cache-mode v1 — each agency has exactly one source. Peer-mode (multiple
sources cooperating to answer a single URN) is intentionally out of
scope; see #46 for that conversation.

Example:
    local = sl.Registry("cache.duckdb", source_registry="local")
    estat = sl.RestRegistry(sl.Provider.ESTAT, materialise_to=local)
    sdmx_global = sl.RestRegistry(sl.Provider.SDMX_GLOBAL, materialise_to=local)

    fed = sl.FederatedRegistry(
        routing={"ESTAT": estat, "SDMX": sdmx_global},
        default=local,  # locally-authored agencies dispatch here
    )

    # Routes by maintenance agency:
    dsd = fed.get(sl.DataStructure.urn(agency="ESTAT", id="X", version="1.0"))
    # → estat → HTTP fetch → materialise to local

    cl = fed.get(sl.Codelist.urn(agency="SDMX", id="CL_FREQ", version="2.1"))
    # → sdmx_global → HTTP fetch → materialise to local

    own = fed.get(sl.Codelist.urn(agency="MY_ORG", id="CL_X", version="1.0"))
    # → falls through to local (no routing entry)
"""

from typing import TYPE_CHECKING

import httpx

from sdmxlib.api.policy import FailurePolicy, RegistryUnavailable

if TYPE_CHECKING:
    from sdmxlib.model.registry import RegistryReader
    from sdmxlib.model.urn import SdmxUrn


class FederatedRegistry:
    """Read-side dispatcher across multiple Registry sources.

    Routes each URN-keyed lookup by maintenance agency. Configure with a
    ``routing`` map from agency id to a :class:`Registry` source, plus
    an optional ``default`` source for agencies absent from the map.

    Satisfies the :class:`~sdmxlib.model.registry.Registry` Protocol —
    a ``FederatedRegistry`` can itself be a source in another
    ``FederatedRegistry`` (composition).

    Args:
        routing: Mapping of agency id (e.g. ``"ESTAT"``, ``"SDMX"``) to a
            :class:`Registry` source. Lookup keys are matched against
            ``SdmxUrn.agency``.
        default: Optional fallback source for URNs whose agency is not
            in ``routing``. ``None`` (the default) means "no fallback":
            unrouted URNs raise :class:`KeyError`.
        failure: How to treat exceptions raised by a routed source.
            Defaults to :attr:`FailurePolicy.HARD_FAIL` — propagate the
            underlying error wrapped in :class:`RegistryUnavailable`.

    Note:
        FederatedRegistry is a *router*, not a *store*. It has no
        ``add()`` method — write to specific concrete registries
        (typically the local one in your routing chain).
    """

    def __init__(
        self,
        *,
        routing: "dict[str, RegistryReader]",
        default: "RegistryReader | None" = None,
        failure: FailurePolicy = FailurePolicy.HARD_FAIL,
    ) -> None:
        self._routing = dict(routing)
        self._default = default
        self._failure = failure

    @property
    def routing(self) -> "dict[str, RegistryReader]":
        """Read-only view of the agency → source map."""
        return dict(self._routing)

    @property
    def default(self) -> "RegistryReader | None":
        """The fallback source used when no routing entry matches."""
        return self._default

    @property
    def failure(self) -> FailurePolicy:
        """The configured failure policy."""
        return self._failure

    # ── Routing ──────────────────────────────────────────────────────────

    def _route(self, urn: "SdmxUrn[object]") -> "RegistryReader | None":
        """Pick the source responsible for ``urn``'s agency."""
        return self._routing.get(urn.agency, self._default)

    def source_for[T](self, urn: "SdmxUrn[T]") -> "RegistryReader | None":
        """Public version of the routing decision — useful for diagnostics."""
        return self._route(urn)

    # ── Registry Protocol ────────────────────────────────────────────────

    def get[T](self, urn: "SdmxUrn[T]") -> "T | None":
        """Resolve ``urn`` via the routed source.

        Routing rules:

        - URN agency in ``routing`` → dispatch to that source.
        - URN agency absent and ``default`` is set → dispatch to default.
        - URN agency absent and no default → raise ``KeyError``.

        Errors from the routed source are wrapped in
        :class:`RegistryUnavailable` when ``failure`` is
        :attr:`FailurePolicy.HARD_FAIL` (default), or swallowed (returning
        ``None``) when ``failure`` is :attr:`FailurePolicy.RETURN_NONE`.
        """
        source = self._route(urn)
        if source is None:
            err = (
                f"No source registered for agency {urn.agency!r} and no default — "
                "add an entry to routing or supply default=..."
            )
            raise KeyError(err)
        try:
            return source.get(urn)  # type: ignore[return-value]
        except (httpx.HTTPError, OSError, RegistryUnavailable) as exc:
            return self._on_failure(source, exc)

    def __contains__(self, urn: object) -> bool:
        """True if the routed source already has ``urn`` cached.

        Like the underlying Registry membership: never triggers a network
        round-trip. ``False`` if no source is routed for the URN's agency.
        """
        from sdmxlib.model.urn import SdmxUrn  # noqa: PLC0415

        if not isinstance(urn, SdmxUrn):
            return False
        source = self._route(urn)
        return source is not None and urn in source

    # ── Failure handling ─────────────────────────────────────────────────

    def _on_failure[T](self, source: "RegistryReader", exc: Exception) -> "T | None":
        """Apply the configured ``FailurePolicy`` to an upstream error."""
        source_id = getattr(source, "id", None)
        if self._failure is FailurePolicy.RETURN_NONE:
            return None
        # HARD_FAIL — wrap and re-raise
        raise RegistryUnavailable(source_id, exc) from exc

    def __repr__(self) -> str:
        agencies = ", ".join(sorted(self._routing))
        default = " +default" if self._default is not None else ""
        return f"FederatedRegistry(routes=[{agencies}]{default}, failure={self._failure.name})"


__all__ = ["FederatedRegistry"]
