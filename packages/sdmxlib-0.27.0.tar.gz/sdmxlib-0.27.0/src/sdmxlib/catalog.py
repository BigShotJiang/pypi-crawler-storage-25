"""FederatedCatalog — orchestrate structural metadata + bindings + data.

A :class:`FederatedCatalog` composes three roles into one query interface:

- ``structural`` — a :class:`~sdmxlib.model.registry.RegistryReader` for
  DSDs, codelists, concept schemes (typically a federation chain spanning
  remote registries plus local cache).
- ``bindings`` — a :class:`RegistryReader` holding
  :class:`~sdmxlib.model.binding.DataflowBinding` artefacts. Usually the
  same local store that caches structural artefacts; conceptually
  separate so users can split them.
- ``data`` — a :class:`~sdmxlib.data_store.DataStore` for observation
  rows.

Two construction paths:

1. ``FederatedCatalog(uri)`` — Path-style. Opens a co-located Registry +
   DuckLake DataStore against the bundle directory at ``uri``. The
   Registry serves as both ``structural`` and ``bindings``; the data
   store is a DuckLake-attached view over the bundle's parquet.
   Standard layout::

       <bundle>/
         meta.duckdb             # sdmx.* + pinax.* schemas
         lake.ducklake           # DuckLake catalog
         parquet/                # DuckLake-managed data (DATA_PATH)

2. ``FederatedCatalog.from_parts(structural=, bindings=, data=)`` —
   composition. For federated topologies (remote structural registry +
   local cache, split storage backends, etc.).

The catalog runs the five-stage query lifecycle:

1. **Binding lookup** — derive the binding's URN from the dataflow URN
   and read it from ``bindings``.
2. **Structural resolve** — pull the dataflow (and its DSD) from
   ``structural``, used for result annotation.
3. **Filter translation** — pass user-supplied WHERE clauses through
   to the data store. (v1 uses identity column mapping; richer
   translation hooks live on the binding.)
4. **Data scan** — execute against the binding's table.
5. **Result annotation** — apply ``slpl.label`` if requested, using the
   resolved DSD to turn code columns into labels in the requested
   language.

Example::

    # Path-style — single bundle
    with sl.FederatedCatalog("/srv/cenprof-2021").open() as cat:
        df = cat.query(dataflow_urn, where=["REF_AREA = ?"], params=["CA"])

    # Composition — federated structural side
    catalog = sl.FederatedCatalog.from_parts(
        structural=fed,  # FederatedRegistry
        bindings=local,  # holds DataflowBinding artefacts
        data=DuckDBDataStore.from_registry(local, attach={"lake": "..."}),
    )
    df = catalog.query(dataflow_urn, ...)
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import TYPE_CHECKING, Self

import polars as pl
from attrs import frozen

from sdmxlib.local._data_store import DuckDBDataStore
from sdmxlib.local._registry import Registry
from sdmxlib.model.binding import DataflowBinding
from sdmxlib.model.dataflow import Dataflow
from sdmxlib.model.datastructure import DataStructure
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.ref import Ref

if TYPE_CHECKING:
    import pyarrow as pa

    from sdmxlib.data_store import DataStore
    from sdmxlib.model.registry import RegistryReader
    from sdmxlib.model.urn import SdmxUrn
    from sdmxlib.rest import ComponentFilter


@frozen
class DataflowEntry:
    """One row of a :meth:`FederatedCatalog.browse` result.

    Attributes:
        dataflow_urn: URN of the bound dataflow.
        binding: The :class:`DataflowBinding` that links the dataflow to
            its observation table. Always present for v1 (browse only
            enumerates locally-bound dataflows).
        name: The dataflow's :class:`InternationalString` name when the
            structural side resolves the dataflow; ``None`` otherwise.
        source_registry: Provenance label from the binding —
            ``"local"`` for locally-authored, ``"ESTAT"`` /
            ``"ECB"`` / ... for remote-cached.
    """

    dataflow_urn: SdmxUrn[Dataflow]
    binding: DataflowBinding
    name: InternationalString | None
    source_registry: str | None


class FederatedCatalog:
    """Orchestrator that ties structural metadata + bindings + data together.

    Users see a single ``query(dataflow_urn, ...)`` entry point; the
    catalog does the binding lookup, DSD resolution, scan, and labelling
    behind the scenes.

    Path-style: ``FederatedCatalog(uri)`` is a cheap value object; the
    underlying Registry + DuckDBDataStore open on ``open()`` /
    ``__enter__`` and close on exit. For non-standard topologies
    (federated structural registry, split storage), use
    :meth:`from_parts` to compose pre-built components.
    """

    def __init__(self, uri: str | Path) -> None:
        self._uri: Path = Path(uri) if isinstance(uri, str) else uri
        self._owned_registry: Registry | None = None
        self._owned_data: DuckDBDataStore | None = None
        self._structural: RegistryReader | None = None
        self._bindings: RegistryReader | None = None
        self._data: DataStore | None = None

    @property
    def uri(self) -> Path:
        """The bundle URI this catalog references. Available before opening."""
        return self._uri

    def open(self) -> Self:
        """Open the bundle's Registry + DuckDBDataStore against the standard layout.

        Looks for ``<uri>/meta.duckdb`` (sdmx + pinax artefacts) and
        ``<uri>/lake.ducklake`` + ``<uri>/parquet/`` (DuckLake-managed
        observations). The Registry serves both ``structural`` and
        ``bindings`` roles. Idempotent within a single open/close cycle.
        """
        if self._structural is not None:
            return self
        registry_path = self._uri / "meta.duckdb"
        lake_path = self._uri / "lake.ducklake"
        parquet_path = self._uri / "parquet"
        registry = Registry(registry_path).open()
        attach_url = f"'ducklake:{lake_path}'"
        attach_options = f"(DATA_PATH '{parquet_path}/')"
        data = DuckDBDataStore.from_registry(
            registry,
            attach={"lake": (attach_url, attach_options)},
            extensions=["ducklake"],
        )
        self._owned_registry = registry
        self._owned_data = data
        self._structural = registry
        self._bindings = registry
        self._data = data
        return self

    @classmethod
    def from_parts(
        cls,
        *,
        structural: RegistryReader,
        bindings: RegistryReader,
        data: DataStore,
    ) -> Self:
        """Compose a catalog from pre-built components.

        Use for federated topologies: a remote structural registry plus
        a local bindings cache plus a DuckLake-backed data store, etc.
        The catalog does NOT take ownership of any component's lifecycle.

        Args:
            structural: Reader that resolves DSDs, codelists, dataflows.
            bindings: Reader that holds :class:`DataflowBinding` artefacts.
                May be the same instance as ``structural``.
            data: :class:`DataStore` for observations.
        """
        instance = cls.__new__(cls)
        instance._uri = Path(":parts:")  # noqa: SLF001 — alternate constructor sets private state
        instance._owned_registry = None  # noqa: SLF001
        instance._owned_data = None  # noqa: SLF001
        instance._structural = structural  # noqa: SLF001
        instance._bindings = bindings  # noqa: SLF001
        instance._data = data  # noqa: SLF001
        return instance

    def __enter__(self) -> Self:
        if self._structural is None:
            self.open()
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def close(self) -> None:
        """Close any components this catalog owns (Path-style construction).

        Components passed via :meth:`from_parts` are NOT closed — their
        lifecycle is the caller's responsibility.
        """
        if self._owned_registry is not None:
            self._owned_registry.close()
            self._owned_registry = None
        self._owned_data = None
        self._structural = None
        self._bindings = None
        self._data = None

    @property
    def structural(self) -> RegistryReader:
        """The structural-side registry (DSDs, codelists, dataflows)."""
        if self._structural is None:
            msg = self._not_open_msg()
            raise RuntimeError(msg)
        return self._structural

    @property
    def bindings(self) -> RegistryReader:
        """The registry holding :class:`DataflowBinding` artefacts."""
        if self._bindings is None:
            msg = self._not_open_msg()
            raise RuntimeError(msg)
        return self._bindings

    @property
    def data(self) -> DataStore:
        """The data plane."""
        if self._data is None:
            msg = self._not_open_msg()
            raise RuntimeError(msg)
        return self._data

    def _not_open_msg(self) -> str:
        return (
            f"FederatedCatalog({self._uri!r}) is not open. Use it as a context "
            "manager (``with FederatedCatalog(uri) as cat: ...``) or call "
            "``.open()`` first; or construct via ``FederatedCatalog.from_parts(...)``."
        )

    # ── Query lifecycle ──────────────────────────────────────────────────

    def query(
        self,
        dataflow_urn: SdmxUrn[Dataflow],
        *,
        where: list[str] | None = None,
        params: list[object] | None = None,
        component_filter: ComponentFilter | None = None,
        columns: list[str] | None = None,
        order_by: str | None = None,
        limit: int | None = None,
        with_labels: bool = False,
        lang: str | None = None,
    ) -> pl.DataFrame:
        """Run the five-stage query lifecycle for ``dataflow_urn``.

        Args:
            dataflow_urn: The dataflow whose observations to read. The
                catalog derives the binding URN from this and reads it
                from ``bindings``.
            where: Optional list of SQL WHERE-clause fragments.
            params: Positional parameters for the WHERE clauses.
            component_filter: Optional :class:`~sdmxlib.rest.ComponentFilter`
                parsed from an SDMX REST dotted key plus ``c[...]=...``
                query params. ANDed with ``where`` after translation via
                the binding's dimension and attribute column maps.
            columns: Optional column projection.
            order_by: Optional SQL ORDER BY clause.
            limit: Optional row cap.
            with_labels: When ``True``, attach human-readable label
                columns to enumerated dimensions/attributes via
                ``slpl.label``. Requires ``lang``.
            lang: BCP47 tag for label localisation. Required when
                ``with_labels=True``; otherwise ignored.

        Returns:
            A Polars DataFrame, optionally label-augmented.

        Raises:
            KeyError: If no binding exists for ``dataflow_urn``.
            TypeError: If ``with_labels=True`` but ``lang`` is missing.
        """
        # Stage 1 — Binding lookup
        binding_urn = DataflowBinding.urn(
            agency=dataflow_urn.agency,
            id=dataflow_urn.id,
            version=dataflow_urn.version,
        )
        binding = self.bindings.get(binding_urn)
        if binding is None:
            err = f"No DataflowBinding found for {dataflow_urn}. Add a binding to the bindings registry first."
            raise KeyError(err)
        if not isinstance(binding, DataflowBinding):
            err = f"Expected DataflowBinding for {binding_urn}, got {type(binding).__name__}"
            raise TypeError(err)

        # Stage 2 — Structural resolve (only needed for labelling)
        dsd: DataStructure | None = None
        if with_labels:
            if lang is None:
                err = "lang is required when with_labels=True — there is no default."
                raise TypeError(err)
            dsd = self._resolve_dsd(dataflow_urn, binding)

        # Stages 3 & 4 — Data scan
        df = self.data.query(
            binding,
            where=where,
            params=params,
            component_filter=component_filter,
            columns=columns,
            order_by=order_by,
            limit=limit,
        )

        # Stage 5 — Result annotation
        if with_labels and dsd is not None and len(df) > 0:
            from sdmxlib import polars as slpl  # noqa: PLC0415  # lazy: only when labelling

            # Narrow: ``lang`` is non-None here — guarded by the with_labels
            # branch above, which raises TypeError when lang is missing.
            assert lang is not None  # noqa: S101
            df = slpl.label(df.lazy(), dsd, lang=lang).collect()

        return df

    def query_stream(
        self,
        dataflow_urn: SdmxUrn[Dataflow],
        *,
        where: list[str] | None = None,
        params: list[object] | None = None,
        component_filter: ComponentFilter | None = None,
        columns: list[str] | None = None,
        order_by: str | None = None,
        chunk_rows: int = 10_000,
    ) -> Iterator[pa.RecordBatch]:
        """Stream observations as Arrow record batches.

        Mirrors :meth:`query` (binding lookup → scan) but skips the
        labelling step — labels are a DataFrame transform that doesn't
        compose cleanly with streaming. Callers that need labelled
        streaming output should join codelists themselves on the way to
        their sink.

        Args:
            dataflow_urn: As :meth:`query`.
            where: As :meth:`query`.
            params: As :meth:`query`.
            component_filter: As :meth:`query`.
            columns: As :meth:`query`.
            order_by: As :meth:`query`.
            chunk_rows: Target rows per emitted record batch.

        Yields:
            One :class:`pyarrow.RecordBatch` at a time, in scan order.

        Raises:
            KeyError: If no binding exists for ``dataflow_urn``.
        """
        binding_urn = DataflowBinding.urn(
            agency=dataflow_urn.agency,
            id=dataflow_urn.id,
            version=dataflow_urn.version,
        )
        binding = self.bindings.get(binding_urn)
        if binding is None:
            err = f"No DataflowBinding found for {dataflow_urn}. Add a binding to the bindings registry first."
            raise KeyError(err)
        if not isinstance(binding, DataflowBinding):
            err = f"Expected DataflowBinding for {binding_urn}, got {type(binding).__name__}"
            raise TypeError(err)
        yield from self.data.query_stream(
            binding,
            where=where,
            params=params,
            component_filter=component_filter,
            columns=columns,
            order_by=order_by,
            chunk_rows=chunk_rows,
        )

    def browse(self) -> list[DataflowEntry]:
        """Enumerate every locally-bound dataflow with provenance annotations.

        v1 lists dataflows that have a :class:`DataflowBinding` in
        ``bindings``. Each entry carries the binding plus the dataflow's
        resolved ``name`` if the structural side knows it. Remote-only
        dataflows (registered upstream but not bound locally) are not
        listed in v1 — that requires a richer Registry-protocol API for
        cross-source enumeration; deferred.

        Returns:
            One :class:`DataflowEntry` per binding, sorted by dataflow URN.

        Raises:
            TypeError: If the ``bindings`` registry doesn't support
                enumeration (no ``get_all`` method). All built-in
                registries do.
        """
        get_all = getattr(self._bindings, "get_all", None)
        if get_all is None:
            err = (
                f"bindings registry {type(self._bindings).__name__} does not "
                "support enumeration via get_all(DataflowBinding); browse() "
                "needs a registry that can list its DataflowBindings."
            )
            raise TypeError(err)
        bindings: list[DataflowBinding] = list(get_all(DataflowBinding))

        entries: list[DataflowEntry] = []
        for binding in bindings:
            flow = self.structural.get(binding.dataflow.urn)
            name = flow.name if isinstance(flow, Dataflow) else None
            entries.append(
                DataflowEntry(
                    dataflow_urn=binding.dataflow.urn,
                    binding=binding,
                    name=name,
                    source_registry=binding.source_registry,
                ),
            )
        entries.sort(key=lambda e: str(e.dataflow_urn))
        return entries

    def binding_for(self, dataflow_urn: SdmxUrn[Dataflow]) -> DataflowBinding | None:
        """Look up the binding associated with ``dataflow_urn``, or ``None``."""
        binding_urn = DataflowBinding.urn(
            agency=dataflow_urn.agency,
            id=dataflow_urn.id,
            version=dataflow_urn.version,
        )
        binding = self.bindings.get(binding_urn)
        return binding if isinstance(binding, DataflowBinding) else None

    # ── Internals ────────────────────────────────────────────────────────

    def _resolve_dsd(
        self,
        dataflow_urn: SdmxUrn[Dataflow],
        binding: DataflowBinding,
    ) -> DataStructure | None:
        """Best-effort resolution of the DSD for label annotation.

        Fetches the dataflow to learn the DSD URN, then fetches the DSD
        by URN directly. This second lookup is important: it triggers
        the registry's nested-Ref resolver on the DSD itself so that
        each dimension's ``representation: Ref[Codelist]`` is resolved
        — without that, ``slpl.label`` skips the column.

        Returns ``None`` if the DSD can't be resolved; the caller treats
        that as "labelling unavailable" rather than a hard error.
        """
        del binding  # may carry version hints in future; unused in v1
        flow = self.structural.get(dataflow_urn)
        if flow is None or not isinstance(flow, Dataflow) or flow.structure is None:
            return None
        structure_ref = flow.structure
        if not isinstance(structure_ref, Ref):
            return None
        # Fetch the DSD by URN so its nested Refs (codelist representations,
        # concept identities) get resolved by the registry's walker.
        dsd = self.structural.get(structure_ref.urn)
        return dsd if isinstance(dsd, DataStructure) else None

    def __repr__(self) -> str:
        return (
            f"FederatedCatalog.from_parts(structural={type(self._structural).__name__}, "
            f"bindings={type(self._bindings).__name__}, "
            f"data={type(self._data).__name__})"
        )


__all__ = ["DataflowEntry", "FederatedCatalog"]
