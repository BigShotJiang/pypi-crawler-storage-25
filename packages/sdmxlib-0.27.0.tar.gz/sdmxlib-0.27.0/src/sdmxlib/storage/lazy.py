"""LazyCodelist + LazyHierarchy — DuckDB-backed lazy artefact access.

Codes / hierarchy nodes are exposed via :class:`CodeQuery` /
:class:`HierarchyNodeQuery`, lazy SKOS/XKOS-aligned query types.
Hierarchy navigation (``roots``, ``leaves``, ``narrower``,
``narrower_transitive``, ``broader``, ``broader_transitive``,
``depth_of``) compiles to a single SQL statement against the
appropriate persisted table (``sdmx.code`` or ``sdmx.hierarchy_node``).
"""

import duckdb

from sdmxlib.model.code_query import (
    CodeQuery,
    _HasAncestor,
    _HasNoNarrower,
    _IsAncestorOf,
    code,
)
from sdmxlib.model.codelist import Code, Codelist
from sdmxlib.model.hierarchy import HierarchicalCode, Hierarchy, Level
from sdmxlib.model.hierarchy_query import (
    HierarchyNodeQuery,
)
from sdmxlib.model.hierarchy_query import (
    _HasAncestor as _NodeHasAncestor,
)
from sdmxlib.model.hierarchy_query import (
    _HasNoNarrower as _NodeHasNoNarrower,
)
from sdmxlib.model.hierarchy_query import (
    _IsAncestorOf as _NodeIsAncestorOf,
)
from sdmxlib.model.hierarchy_query import (
    node as node_accessor,
)
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.organisation import Agency
from sdmxlib.model.ref import Ref
from sdmxlib.model.urn import SdmxUrn


def _map_to_istring(m: dict[str, str] | None) -> InternationalString:
    if not m:
        return InternationalString()
    return InternationalString.of(m)


class LazyCodelist:
    """Codelist facade backed by DuckDB.

    Duck-types as ``Codelist`` for read operations. ``codes`` returns a
    :class:`CodeQuery` for SQL-pushed filtering and hierarchy navigation.
    """

    __slots__ = (
        "__weakref__",  # required so slpl.label's per-codelist cache can hold a weakref
        "_agency",
        "_conn",
        "_description",
        "_id",
        "_is_final",
        "_name",
        "_urn",
        "_version",
    )

    def __init__(
        self,
        *,
        urn: str,
        conn: duckdb.DuckDBPyConnection,
        id: str,  # noqa: A002
        agency: Agency,
        version: str,
        name: InternationalString,
        description: InternationalString,
        is_final: bool,
    ) -> None:
        self._urn = urn
        self._conn = conn
        self._id = id
        self._agency = agency
        self._version = version
        self._name = name
        self._description = description
        self._is_final = is_final

    # ── MaintainableArtefact-compatible properties ────────────────────────

    @property
    def id(self) -> str:  # noqa: D102
        return self._id

    @property
    def maintainer(self) -> Agency:  # noqa: D102
        return self._agency

    @property
    def agency_id(self) -> str:  # noqa: D102
        return self._agency.id

    @property
    def version(self) -> str:  # noqa: D102
        return self._version

    @property
    def name(self) -> InternationalString:  # noqa: D102
        return self._name

    @property
    def description(self) -> InternationalString:  # noqa: D102
        return self._description

    @property
    def is_final(self) -> bool:  # noqa: D102
        return self._is_final

    # ── SDMX class vars ──────────────────────────────────────────────────

    sdmx_package = "codelist"
    sdmx_class = "Codelist"

    # ── Code access (Layer 2: CodeQuery-returning) ───────────────────────

    @property
    def codes(self) -> CodeQuery:
        """All codes as a lazy :class:`CodeQuery`."""
        return CodeQuery(codelist_urn=self._urn, conn=self._conn)

    def __len__(self) -> int:
        row = self._conn.execute(
            "SELECT COUNT(*) FROM sdmx.code WHERE codelist_urn = ?",
            [self._urn],
        ).fetchone()
        return row[0] if row else 0  # type: ignore[index]

    def __contains__(self, key: object) -> bool:
        return key in self.codes

    def __getitem__(self, key: str | int) -> Code:
        return self.codes[key]

    # ── SKOS/XKOS hierarchy navigation ──────────────────────────────────

    def roots(self) -> CodeQuery:
        """Top-level codes (``broader IS NULL``)."""
        return self.codes.filter(code.parent_id.is_null())

    def leaves(self) -> CodeQuery:
        """Codes that no other code names as parent."""
        return self.codes.filter(_HasNoNarrower())

    def narrower(self, code_id: str) -> CodeQuery:
        """Direct children of ``code_id``."""
        return self.codes.filter(code.parent_id == code_id)

    def broader(self, code_id: str) -> Code | None:
        """Direct parent of ``code_id`` — at most one. Returns ``None`` for roots."""
        row = self._conn.execute(
            """
            SELECT parent.code_id, parent.parent_id, parent.depth, parent.name,
                   parent.code_urn, parent.description
            FROM sdmx.code child
            LEFT JOIN sdmx.code parent
              ON parent.codelist_urn = child.codelist_urn
             AND parent.code_id = child.parent_id
            WHERE child.codelist_urn = ?
              AND child.code_id = ?
            """,
            [self._urn, code_id],
        ).fetchone()
        if row is None or row[0] is None:
            return None
        from sdmxlib.model.annotations import Annotations  # noqa: PLC0415
        from sdmxlib.model.code_query import _fetch_annotations_for, _row_to_code  # noqa: PLC0415

        anns = _fetch_annotations_for(self._conn, [row[4]]).get(row[4], Annotations())
        return _row_to_code(row, anns)

    def narrower_transitive(self, code_id: str, *, depth: int | None = None) -> CodeQuery:
        """All descendants of ``code_id``.

        When ``depth`` is set, the query is bounded to ``depth`` hops; the
        starting code's absolute depth is fetched once so the SQL becomes
        a literal-int comparison.
        """
        max_absolute = None
        if depth is not None:
            max_absolute = self.depth_of(code_id) + depth
        return self.codes.filter(_HasAncestor(ancestor_id=code_id, max_absolute_depth=max_absolute))

    def broader_transitive(self, code_id: str, *, depth: int | None = None) -> CodeQuery:
        """All ancestors of ``code_id``.

        When ``depth`` is set, the query is bounded to ``depth`` hops.
        """
        min_absolute = None
        if depth is not None:
            min_absolute = self.depth_of(code_id) - depth
        return self.codes.filter(_IsAncestorOf(descendant_id=code_id, min_absolute_depth=min_absolute))

    def depth_of(self, code_id: str) -> int:
        """Depth of ``code_id`` in the codelist hierarchy (root = 0)."""
        row = self._conn.execute(
            "SELECT depth FROM sdmx.code WHERE codelist_urn = ? AND code_id = ?",
            [self._urn, code_id],
        ).fetchone()
        if row is None:
            msg = f"Code {code_id!r} not found in codelist {self._urn!r}"
            raise KeyError(msg)
        return int(row[0]) if row[0] is not None else 0

    # ── Bulk projections (one SQL each) ──────────────────────────────────

    def depths(self) -> dict[str, int]:
        """``{code_id: depth}`` for every code (root = 0). One SQL query."""
        rows = self._conn.execute(
            """
            SELECT code_id, depth
            FROM sdmx.code
            WHERE codelist_urn = ?
            """,
            [self._urn],
        ).fetchall()
        return {str(r[0]): int(r[1]) if r[1] is not None else 0 for r in rows}

    def broader_map(self) -> dict[str, str | None]:
        """``{code_id: parent_id}`` for every code. One SQL query."""
        rows = self._conn.execute(
            """
            SELECT code_id, parent_id
            FROM sdmx.code
            WHERE codelist_urn = ?
            """,
            [self._urn],
        ).fetchall()
        return {str(r[0]): (str(r[1]) if r[1] is not None else None) for r in rows}

    def narrower_map(self) -> dict[str, tuple[str, ...]]:
        """``{code_id: (child_id, ...)}`` for every code, ordered by position."""
        rows = self._conn.execute(
            """
            SELECT code_id, parent_id
            FROM sdmx.code
            WHERE codelist_urn = ?
            ORDER BY position NULLS LAST, code_id
            """,
            [self._urn],
        ).fetchall()
        children: dict[str, list[str]] = {str(r[0]): [] for r in rows}
        for r in rows:
            cid = str(r[0])
            pid = str(r[1]) if r[1] is not None else None
            if pid is not None and pid in children:
                children[pid].append(cid)
        return {k: tuple(v) for k, v in children.items()}

    def ancestors_map(self) -> dict[str, tuple[str, ...]]:
        """``{code_id: (ancestor_id, ...)}`` root-first. One SQL query.

        Reads the precomputed ``ancestor_ids`` column.
        """
        rows = self._conn.execute(
            """
            SELECT code_id, ancestor_ids
            FROM sdmx.code
            WHERE codelist_urn = ?
            """,
            [self._urn],
        ).fetchall()
        result: dict[str, tuple[str, ...]] = {}
        for r in rows:
            cid = str(r[0])
            ancestors = r[1]
            result[cid] = tuple(str(a) for a in ancestors) if ancestors else ()
        return result

    def descendants_map(self) -> dict[str, tuple[str, ...]]:
        """``{code_id: (descendant_id, ...)}`` in pre-order DFS, excluding self."""
        narrower = self.narrower_map()
        cache: dict[str, tuple[str, ...]] = {}

        def _desc(cid: str) -> tuple[str, ...]:
            if cid in cache:
                return cache[cid]
            out: list[str] = []
            for child_id in narrower.get(cid, ()):
                out.append(child_id)
                out.extend(_desc(child_id))
            cache[cid] = tuple(out)
            return cache[cid]

        return {cid: _desc(cid) for cid in narrower}

    def inherit_along_broader[T](self, values: dict[str, T]) -> dict[str, T]:
        """Propagate ``values`` down the parent chain. One SQL query.

        For each code, walk the broader chain (using ``ancestor_ids``) and
        assign the first explicit value encountered. Codes with no explicit
        value anywhere in their chain are omitted from the result.
        """
        rows = self._conn.execute(
            """
            SELECT code_id, ancestor_ids
            FROM sdmx.code
            WHERE codelist_urn = ?
            """,
            [self._urn],
        ).fetchall()
        result: dict[str, T] = {}
        for r in rows:
            cid = str(r[0])
            if cid in values:
                result[cid] = values[cid]
                continue
            ancestors = r[1] or ()
            # ancestor_ids is stored root-first; walk from immediate parent
            # (last entry) back toward the root for SKOS-correct inheritance.
            for ancestor in reversed(list(ancestors)):
                a = str(ancestor)
                if a in values:
                    result[cid] = values[a]
                    break
        return result

    # ── Direct SQL helpers ───────────────────────────────────────────────

    def code_map(self, *, lang: str) -> dict[str, str]:
        """Direct SQL: ``{code_id: label}`` without creating Code objects."""
        from sdmxlib.storage.readers import code_map  # noqa: PLC0415

        return code_map(self._conn, self._urn, lang=lang)

    def materialize(self) -> Codelist:
        """Load all codes and return a real :class:`Codelist`."""
        codes = self.codes.collect()
        return Codelist(
            id=self._id,
            maintainer=self._agency,
            version=self._version,
            name=self._name,
            description=self._description,
            is_final=self._is_final,
            codes=codes,
        )

    def __repr__(self) -> str:
        return f"LazyCodelist(id={self._id!r}, agency={self.agency_id!r}, codes=~{len(self)})"


class LazyHierarchy:
    """Hierarchy facade backed by DuckDB.

    Duck-types as :class:`Hierarchy` for read operations. ``nodes`` returns
    a :class:`HierarchyNodeQuery` for SQL-pushed filtering and tree
    navigation. SKOS verbs (``roots``/``leaves``/``narrower``/``broader``/
    ``*_transitive``/``depth_of``) and bulk projections (``depths``/
    ``broader_map``/...) mirror :class:`LazyCodelist` exactly.
    """

    __slots__ = (
        "__weakref__",
        "_agency",
        "_conn",
        "_description",
        "_id",
        "_is_final",
        "_is_leveled",
        "_levels",
        "_name",
        "_urn",
        "_version",
    )

    def __init__(
        self,
        *,
        urn: str,
        conn: duckdb.DuckDBPyConnection,
        id: str,  # noqa: A002
        agency: Agency,
        version: str,
        name: InternationalString,
        description: InternationalString,
        is_final: bool,
        is_leveled: bool,
        levels: tuple[Level, ...],
    ) -> None:
        self._urn = urn
        self._conn = conn
        self._id = id
        self._agency = agency
        self._version = version
        self._name = name
        self._description = description
        self._is_final = is_final
        self._is_leveled = is_leveled
        self._levels = levels

    # ── MaintainableArtefact-compatible properties ────────────────────────

    @property
    def id(self) -> str:  # noqa: D102
        return self._id

    @property
    def maintainer(self) -> Agency:  # noqa: D102
        return self._agency

    @property
    def agency_id(self) -> str:  # noqa: D102
        return self._agency.id

    @property
    def version(self) -> str:  # noqa: D102
        return self._version

    @property
    def name(self) -> InternationalString:  # noqa: D102
        return self._name

    @property
    def description(self) -> InternationalString:  # noqa: D102
        return self._description

    @property
    def is_final(self) -> bool:  # noqa: D102
        return self._is_final

    @property
    def is_leveled(self) -> bool:  # noqa: D102
        return self._is_leveled

    @property
    def levels(self) -> tuple[Level, ...]:  # noqa: D102
        return self._levels

    # ── SDMX class vars ──────────────────────────────────────────────────

    sdmx_package = "codelist"
    sdmx_class = "Hierarchy"

    # ── Node access ──────────────────────────────────────────────────────

    @property
    def nodes(self) -> HierarchyNodeQuery:
        """All nodes as a lazy :class:`HierarchyNodeQuery`."""
        return HierarchyNodeQuery(hierarchy_urn=self._urn, conn=self._conn)

    def __len__(self) -> int:
        row = self._conn.execute(
            "SELECT COUNT(*) FROM sdmx.hierarchy_node WHERE hierarchy_urn = ?",
            [self._urn],
        ).fetchone()
        return row[0] if row else 0  # type: ignore[index]

    def __contains__(self, key: object) -> bool:
        return key in self.nodes

    def __getitem__(self, key: str | int) -> HierarchicalCode:
        return self.nodes[key]

    # ── SKOS/XKOS hierarchy navigation ──────────────────────────────────

    def roots(self) -> HierarchyNodeQuery:
        """Top-level nodes (no parent)."""
        return self.nodes.filter(node_accessor.parent_id.is_null())

    def leaves(self) -> HierarchyNodeQuery:
        """Nodes that no other node names as parent."""
        return self.nodes.filter(_NodeHasNoNarrower())

    def narrower(self, node_id: str) -> HierarchyNodeQuery:
        """Direct children of ``node_id``."""
        return self.nodes.filter(node_accessor.parent_id == node_id)

    def broader(self, node_id: str) -> HierarchicalCode | None:
        """Direct parent of ``node_id``. ``None`` for roots."""
        row = self._conn.execute(
            """
            SELECT parent.node_id, parent.parent_node_id, parent.depth, parent.name,
                   parent.code_urn, parent.level_id, parent.node_urn, parent.description,
                   parent.valid_from, parent.valid_to
            FROM sdmx.hierarchy_node child
            LEFT JOIN sdmx.hierarchy_node parent
              ON parent.hierarchy_urn = child.hierarchy_urn
             AND parent.node_id = child.parent_node_id
            WHERE child.hierarchy_urn = ?
              AND child.node_id = ?
            """,
            [self._urn, node_id],
        ).fetchone()
        if row is None or row[0] is None:
            return None
        from sdmxlib.model.hierarchy_query import _row_to_node  # noqa: PLC0415

        return _row_to_node(row, Annotations())

    def narrower_transitive(self, node_id: str, *, depth: int | None = None) -> HierarchyNodeQuery:
        """All descendants of ``node_id``. ``depth`` bounds hops."""
        max_absolute = None
        if depth is not None:
            max_absolute = self.depth_of(node_id) + depth
        return self.nodes.filter(_NodeHasAncestor(ancestor_id=node_id, max_absolute_depth=max_absolute))

    def broader_transitive(self, node_id: str, *, depth: int | None = None) -> HierarchyNodeQuery:
        """All ancestors of ``node_id``. ``depth`` bounds hops."""
        min_absolute = None
        if depth is not None:
            min_absolute = self.depth_of(node_id) - depth
        return self.nodes.filter(_NodeIsAncestorOf(descendant_id=node_id, min_absolute_depth=min_absolute))

    def depth_of(self, node_id: str) -> int:
        """Depth of ``node_id`` in the hierarchy (root = 0)."""
        row = self._conn.execute(
            "SELECT depth FROM sdmx.hierarchy_node WHERE hierarchy_urn = ? AND node_id = ?",
            [self._urn, node_id],
        ).fetchone()
        if row is None:
            msg = f"Node {node_id!r} not found in hierarchy {self._urn!r}"
            raise KeyError(msg)
        return int(row[0]) if row[0] is not None else 0

    # ── Bulk projections (one SQL each) ──────────────────────────────────

    def depths(self) -> dict[str, int]:
        """``{node_id: depth}`` for every node (root = 0). One SQL query."""
        rows = self._conn.execute(
            """
            SELECT node_id, depth
            FROM sdmx.hierarchy_node
            WHERE hierarchy_urn = ?
            """,
            [self._urn],
        ).fetchall()
        return {str(r[0]): int(r[1]) if r[1] is not None else 0 for r in rows}

    def broader_map(self) -> dict[str, str | None]:
        """``{node_id: parent_id}`` for every node. One SQL query."""
        rows = self._conn.execute(
            """
            SELECT node_id, parent_node_id
            FROM sdmx.hierarchy_node
            WHERE hierarchy_urn = ?
            """,
            [self._urn],
        ).fetchall()
        return {str(r[0]): (str(r[1]) if r[1] is not None else None) for r in rows}

    def narrower_map(self) -> dict[str, tuple[str, ...]]:
        """``{node_id: (child_id, ...)}`` for every node."""
        rows = self._conn.execute(
            """
            SELECT node_id, parent_node_id
            FROM sdmx.hierarchy_node
            WHERE hierarchy_urn = ?
            ORDER BY node_id
            """,
            [self._urn],
        ).fetchall()
        children: dict[str, list[str]] = {str(r[0]): [] for r in rows}
        for r in rows:
            nid = str(r[0])
            pid = str(r[1]) if r[1] is not None else None
            if pid is not None and pid in children:
                children[pid].append(nid)
        return {k: tuple(v) for k, v in children.items()}

    def ancestors_map(self) -> dict[str, tuple[str, ...]]:
        """``{node_id: (ancestor_id, ...)}`` root-first. One SQL query."""
        rows = self._conn.execute(
            """
            SELECT node_id, ancestor_ids
            FROM sdmx.hierarchy_node
            WHERE hierarchy_urn = ?
            """,
            [self._urn],
        ).fetchall()
        result: dict[str, tuple[str, ...]] = {}
        for r in rows:
            nid = str(r[0])
            ancestors = r[1]
            result[nid] = tuple(str(a) for a in ancestors) if ancestors else ()
        return result

    def descendants_map(self) -> dict[str, tuple[str, ...]]:
        """``{node_id: (descendant_id, ...)}`` in pre-order DFS, excluding self."""
        narrower = self.narrower_map()
        cache: dict[str, tuple[str, ...]] = {}

        def _desc(nid: str) -> tuple[str, ...]:
            if nid in cache:
                return cache[nid]
            out: list[str] = []
            for child_id in narrower.get(nid, ()):
                out.append(child_id)
                out.extend(_desc(child_id))
            cache[nid] = tuple(out)
            return cache[nid]

        return {nid: _desc(nid) for nid in narrower}

    def inherit_along_broader[T](self, values: dict[str, T]) -> dict[str, T]:
        """Propagate ``values`` down the parent chain. One SQL query."""
        rows = self._conn.execute(
            """
            SELECT node_id, ancestor_ids
            FROM sdmx.hierarchy_node
            WHERE hierarchy_urn = ?
            """,
            [self._urn],
        ).fetchall()
        result: dict[str, T] = {}
        for r in rows:
            nid = str(r[0])
            if nid in values:
                result[nid] = values[nid]
                continue
            ancestors = r[1] or ()
            for ancestor in reversed(list(ancestors)):
                a = str(ancestor)
                if a in values:
                    result[nid] = values[a]
                    break
        return result

    def materialize(self) -> Hierarchy:
        """Load the full hierarchy tree and return a real :class:`Hierarchy`.

        Builds the tree bottom-up: leaves first, then parents. Each
        ``HierarchicalCode`` gets its children list at construction
        time — no post-construction mutation.
        """
        rows = self._conn.execute(
            """
            SELECT node_id, parent_node_id, code_urn, level_id, name, description,
                   valid_from, valid_to
            FROM sdmx.hierarchy_node
            WHERE hierarchy_urn = ?
            ORDER BY depth DESC, node_id
            """,
            [self._urn],
        ).fetchall()
        levels_by_id = {lv.id: lv for lv in self._levels}
        children_by_parent: dict[str | None, list[HierarchicalCode]] = {}
        for r in rows:
            node_id, parent_id, code_urn, level_id, name_map, desc_map, valid_from, valid_to = r
            nid = str(node_id)
            # Children of nid have already been built (deeper depths first).
            kids = children_by_parent.pop(nid, [])
            code_ref: Ref[Code] | None = None
            if code_urn is not None:
                code_ref = Ref[Code].unresolved(SdmxUrn.parse(str(code_urn)))
            level: Level | None = None
            if level_id is not None:
                level = levels_by_id.get(str(level_id), Level(id=str(level_id)))
            node = HierarchicalCode(
                id=nid,
                code=code_ref,
                name=_map_to_istring(name_map),
                description=_map_to_istring(desc_map),
                children=kids,
                valid_from=valid_from,
                valid_to=valid_to,
                level=level,
            )
            pkey = str(parent_id) if parent_id is not None else None
            children_by_parent.setdefault(pkey, []).append(node)
        roots = children_by_parent.get(None, [])
        return Hierarchy(
            id=self._id,
            maintainer=self._agency,
            version=self._version,
            name=self._name,
            description=self._description,
            is_final=self._is_final,
            levels=list(self._levels),
            tree=roots,
        )

    def __repr__(self) -> str:
        return f"LazyHierarchy(id={self._id!r}, agency={self.agency_id!r}, nodes=~{len(self)})"


# Late import needed by LazyHierarchy.broader (placed at module bottom to
# avoid a forward-reference cycle on Annotations).
from sdmxlib.model.annotations import Annotations  # noqa: E402

__all__ = ["LazyCodelist", "LazyHierarchy"]
