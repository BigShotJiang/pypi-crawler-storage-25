"""Hierarchy, HierarchicalCode, and Level — cross-codelist hierarchical views.

SDMX 3.0 artefact that replaces HierarchicalCodelist from 2.1.
SDMX 3.1 adds Level support for explicit level structures.
The 2.1 reader maps the older structure into this model.
"""

from datetime import datetime
from typing import ClassVar

from attrs import define, field

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.codelist import Code
from sdmxlib.model.collections import ItemList
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.organisation import Agency, _to_agency, _to_annotations, _to_istring
from sdmxlib.model.ref import Ref
from sdmxlib.model.urn import SdmxUrn


@define
class Level:
    """A named level in a Hierarchy (SDMX 3.1).

    Hierarchies that declare levels allow each ``HierarchicalCode`` node
    to explicitly state which structural level it belongs to — rather
    than inferring level from tree depth or code ID patterns.

    Example:
        hierarchy.levels["SECTOR"]        # Level lookup by id
        node.level                         # Level | None
    """

    id: str
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)


def _to_levels(v: "ItemList[Level] | list[Level]") -> "ItemList[Level]":
    return v if isinstance(v, ItemList) else ItemList(v)


def _to_hcode_ref(v: "Ref[Code] | SdmxUrn[Code] | None") -> "Ref[Code] | None":
    if isinstance(v, SdmxUrn):
        return Ref[Code].unresolved(v)
    return v


def _to_hcodes(v: "ItemList[HierarchicalCode] | list[HierarchicalCode]") -> "ItemList[HierarchicalCode]":
    return v if isinstance(v, ItemList) else ItemList(v)


def _to_tree(v: "ItemList[HierarchicalCode] | list[HierarchicalCode]") -> "ItemList[HierarchicalCode]":
    return v if isinstance(v, ItemList) else ItemList(v)


@define
class HierarchicalCode:
    """A node in a Hierarchy tree, referencing a code from a Codelist.

    Provides tree navigation via ``children`` and flat lookup via the
    parent ``Hierarchy.codes`` index.

    Example:
        node = hierarchy.tree["CANADA"]
        node.children["ON"]           # tree navigation
        hierarchy.codes["ON"]          # flat O(1) lookup
        node.code()                    # Ref[Code] unwrap → Code
    """

    id: str
    code: Ref[Code] | None = field(default=None, converter=_to_hcode_ref)
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    children: "ItemList[HierarchicalCode]" = field(factory=ItemList, converter=_to_hcodes)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    level: Level | None = None


def _flatten_nodes(nodes: ItemList["HierarchicalCode"]) -> ItemList["HierarchicalCode"]:
    """Recursively collect all nodes into a flat ItemList."""
    result: list[HierarchicalCode] = []

    def _walk(node: HierarchicalCode) -> None:
        result.append(node)
        for child in node.children:
            _walk(child)

    for node in nodes:
        _walk(node)
    return ItemList(result)


@define
class Hierarchy(MaintainableArtefact):
    """A standalone hierarchy of codes from one or more codelists.

    Provides two access patterns:

    - ``tree``: top-level entry points (roots) with ``children`` navigation
    - ``codes``: flat O(1) index over ALL nodes in the hierarchy

    Example:
        hierarchy.tree["CANADA"].children["ON"]  # tree navigation
        hierarchy.codes["OTTAWA"]                 # flat lookup
        hierarchy.codes["OTTAWA"].code()          # Ref[Code] unwrap → Code
    """

    sdmx_package: ClassVar[str] = "codelist"
    sdmx_class: ClassVar[str] = "Hierarchy"
    msg_field: ClassVar[str] = "hierarchies"

    id: str = ""
    maintainer: Agency = field(factory=lambda: Agency(id=""), converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    is_final: bool = False
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    levels: ItemList[Level] = field(factory=ItemList, converter=_to_levels)
    tree: ItemList[HierarchicalCode] = field(factory=ItemList, converter=_to_tree)
    _codes: ItemList[HierarchicalCode] = field(init=False, repr=False, factory=ItemList)
    _parent_of: dict[str, str | None] = field(init=False, repr=False, eq=False, factory=dict)

    def __attrs_post_init__(self) -> None:
        self._codes = _flatten_nodes(self.tree)
        parent: dict[str, str | None] = {n.id: None for n in self._codes}
        for node in self._codes:
            for child in node.children:
                parent[child.id] = node.id
        self._parent_of = parent

    @property
    def codes(self) -> ItemList[HierarchicalCode]:
        """Flat index of ALL nodes in the hierarchy. O(1) lookup by id."""
        return self._codes

    @property
    def is_leveled(self) -> bool:
        """True if this hierarchy declares explicit levels (SDMX 3.1)."""
        return len(self.levels) > 0

    # ── SKOS/XKOS hierarchy navigation ────────────────────────────────────

    def roots(self) -> ItemList[HierarchicalCode]:
        """Top-level nodes (no parent). Equivalent to ``self.tree``."""
        return self.tree

    def leaves(self) -> ItemList[HierarchicalCode]:
        """Nodes with no children."""
        return self._codes.filter(lambda n: len(n.children) == 0)

    def narrower(self, node_id: str) -> ItemList[HierarchicalCode]:
        """Direct children of ``node_id``."""
        target = self._codes.get(node_id)
        if target is None:
            return ItemList([])
        return ItemList(list(target.children))

    def broader(self, node_id: str) -> "HierarchicalCode | None":
        """Direct parent of ``node_id``. ``None`` for roots."""
        parent_id = self._parent_of.get(node_id)
        if parent_id is None:
            return None
        return self._codes.get(parent_id)

    def broader_transitive(self, node_id: str, *, depth: int | None = None) -> ItemList[HierarchicalCode]:
        """All ancestors of ``node_id``, root-first. ``depth`` bounds hops."""
        result: list[HierarchicalCode] = []
        current_id: str | None = node_id
        hops = 0
        while True:
            parent_id = self._parent_of.get(current_id) if current_id is not None else None
            if parent_id is None:
                break
            if depth is not None and hops >= depth:
                break
            parent = self._codes.get(parent_id)
            if parent is None:
                break
            result.append(parent)
            current_id = parent_id
            hops += 1
        result.reverse()  # root-first
        return ItemList(result)

    def narrower_transitive(self, node_id: str, *, depth: int | None = None) -> ItemList[HierarchicalCode]:
        """All descendants of ``node_id`` in pre-order DFS. ``depth`` bounds hops."""
        result: list[HierarchicalCode] = []
        target = self._codes.get(node_id)
        if target is None:
            return ItemList(result)

        def _walk(node: HierarchicalCode, hops: int) -> None:
            if depth is not None and hops >= depth:
                return
            for child in node.children:
                result.append(child)
                _walk(child, hops + 1)

        _walk(target, 0)
        return ItemList(result)

    def depth_of(self, node_id: str) -> int:
        """Depth of ``node_id`` in the tree (root = 0)."""
        if node_id not in self._parent_of:
            msg = f"Node {node_id!r} not in hierarchy {self.id!r}"
            raise KeyError(msg)
        depth = 0
        current: str | None = node_id
        while True:
            parent = self._parent_of.get(current) if current is not None else None
            if parent is None:
                break
            depth += 1
            current = parent
        return depth

    # ── Bulk projections ──────────────────────────────────────────────────

    def depths(self) -> dict[str, int]:
        """``{node_id: depth}`` for every node (root = 0)."""
        cache: dict[str, int] = {}

        def _depth(nid: str) -> int:
            if nid in cache:
                return cache[nid]
            parent = self._parent_of.get(nid)
            cache[nid] = 0 if parent is None else _depth(parent) + 1
            return cache[nid]

        return {n.id: _depth(n.id) for n in self._codes}

    def broader_map(self) -> dict[str, str | None]:
        """``{node_id: parent_id}`` for every node; ``None`` for roots."""
        return dict(self._parent_of)

    def narrower_map(self) -> dict[str, tuple[str, ...]]:
        """``{node_id: (child_id, ...)}`` for every node, in declaration order."""
        return {n.id: tuple(c.id for c in n.children) for n in self._codes}

    def ancestors_map(self) -> dict[str, tuple[str, ...]]:
        """``{node_id: (ancestor_id, ...)}`` root-first, excluding self."""
        cache: dict[str, tuple[str, ...]] = {}

        def _anc(nid: str) -> tuple[str, ...]:
            if nid in cache:
                return cache[nid]
            parent = self._parent_of.get(nid)
            cache[nid] = () if parent is None else (*_anc(parent), parent)
            return cache[nid]

        return {n.id: _anc(n.id) for n in self._codes}

    def descendants_map(self) -> dict[str, tuple[str, ...]]:
        """``{node_id: (descendant_id, ...)}`` in pre-order DFS, excluding self."""
        cache: dict[str, tuple[str, ...]] = {}

        def _desc(node: HierarchicalCode) -> tuple[str, ...]:
            if node.id in cache:
                return cache[node.id]
            out: list[str] = []
            for child in node.children:
                out.append(child.id)
                out.extend(_desc(child))
            cache[node.id] = tuple(out)
            return cache[node.id]

        return {n.id: _desc(n) for n in self._codes}

    def inherit_along_broader[T](self, values: dict[str, T]) -> dict[str, T]:
        """Propagate ``values`` down the parent chain.

        For each node, walk the broader chain and assign the first explicit
        value encountered. Nodes whose chain has no explicit value are
        omitted from the result.
        """
        result: dict[str, T] = {}
        for n in self._codes:
            cur_id: str | None = n.id
            while cur_id is not None:
                if cur_id in values:
                    result[n.id] = values[cur_id]
                    break
                cur_id = self._parent_of.get(cur_id)
        return result
