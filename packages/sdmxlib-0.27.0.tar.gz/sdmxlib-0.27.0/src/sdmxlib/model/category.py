"""CategoryScheme, Category, Categorisation — classification of artefacts."""

from datetime import datetime
from typing import ClassVar

from attrs import define, evolve, field

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.collections import ItemList
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.organisation import Agency, _to_agency, _to_annotations, _to_istring
from sdmxlib.model.ref import AnyRef


def _to_categories(v: "ItemList[Category] | list[Category]") -> "ItemList[Category]":
    return v if isinstance(v, ItemList) else ItemList(v)


@define
class Category:
    """A node in a classification hierarchy."""

    id: str
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    categories: "ItemList[Category]" = field(factory=ItemList, converter=_to_categories)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)


def _flatten_categories(roots: ItemList["Category"]) -> ItemList["Category"]:
    """Recursively collect all categories into a flat ItemList."""
    result: list[Category] = []

    def _walk(node: Category) -> None:
        result.append(node)
        for child in node.categories:
            _walk(child)

    for node in roots:
        _walk(node)
    return ItemList(result)


@define
class CategoryScheme(MaintainableArtefact):
    """A hierarchical classification scheme."""

    sdmx_package: ClassVar[str] = "categoryscheme"
    sdmx_class: ClassVar[str] = "CategoryScheme"
    msg_field: ClassVar[str] = "category_schemes"

    id: str
    maintainer: Agency = field(converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    categories: ItemList[Category] = field(factory=ItemList, converter=_to_categories)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    _flat: ItemList[Category] = field(init=False, repr=False, factory=ItemList)
    _parent_of: dict[str, str | None] = field(init=False, repr=False, eq=False, factory=dict)

    def __attrs_post_init__(self) -> None:
        self._flat = _flatten_categories(self.categories)
        parent: dict[str, str | None] = {n.id: None for n in self._flat}
        for node in self._flat:
            for child in node.categories:
                parent[child.id] = node.id
        self._parent_of = parent

    # ── SKOS/XKOS hierarchy navigation ────────────────────────────────────

    def roots(self) -> ItemList[Category]:
        """Top-level categories (no parent)."""
        return self.categories

    def leaves(self) -> ItemList[Category]:
        """Categories with no sub-categories."""
        return self._flat.filter(lambda n: len(n.categories) == 0)

    def narrower(self, category_id: str) -> ItemList[Category]:
        """Direct children of ``category_id``."""
        target = self._flat.get(category_id)
        if target is None:
            return ItemList([])
        return ItemList(list(target.categories))

    def broader(self, category_id: str) -> "Category | None":
        """Direct parent of ``category_id``. ``None`` for roots."""
        parent_id = self._parent_of.get(category_id)
        if parent_id is None:
            return None
        return self._flat.get(parent_id)

    def broader_transitive(self, category_id: str, *, depth: int | None = None) -> ItemList[Category]:
        """All ancestors of ``category_id``, root-first. ``depth`` bounds hops."""
        result: list[Category] = []
        current_id: str | None = category_id
        hops = 0
        while True:
            parent_id = self._parent_of.get(current_id) if current_id is not None else None
            if parent_id is None:
                break
            if depth is not None and hops >= depth:
                break
            parent = self._flat.get(parent_id)
            if parent is None:
                break
            result.append(parent)
            current_id = parent_id
            hops += 1
        result.reverse()
        return ItemList(result)

    def narrower_transitive(self, category_id: str, *, depth: int | None = None) -> ItemList[Category]:
        """All descendants of ``category_id`` in pre-order DFS. ``depth`` bounds hops."""
        result: list[Category] = []
        target = self._flat.get(category_id)
        if target is None:
            return ItemList(result)

        def _walk(node: Category, hops: int) -> None:
            if depth is not None and hops >= depth:
                return
            for child in node.categories:
                result.append(child)
                _walk(child, hops + 1)

        _walk(target, 0)
        return ItemList(result)

    def depth_of(self, category_id: str) -> int:
        """Depth of ``category_id`` in the tree (root = 0)."""
        if category_id not in self._parent_of:
            msg = f"Category {category_id!r} not in scheme {self.id!r}"
            raise KeyError(msg)
        depth = 0
        current: str | None = category_id
        while True:
            parent = self._parent_of.get(current) if current is not None else None
            if parent is None:
                break
            depth += 1
            current = parent
        return depth

    # ── Bulk projections ──────────────────────────────────────────────────

    def depths(self) -> dict[str, int]:
        """``{category_id: depth}`` for every category (root = 0)."""
        cache: dict[str, int] = {}

        def _depth(cid: str) -> int:
            if cid in cache:
                return cache[cid]
            parent = self._parent_of.get(cid)
            cache[cid] = 0 if parent is None else _depth(parent) + 1
            return cache[cid]

        return {n.id: _depth(n.id) for n in self._flat}

    def broader_map(self) -> dict[str, str | None]:
        """``{category_id: parent_id}`` for every category; ``None`` for roots."""
        return dict(self._parent_of)

    def narrower_map(self) -> dict[str, tuple[str, ...]]:
        """``{category_id: (child_id, ...)}`` for every category."""
        return {n.id: tuple(c.id for c in n.categories) for n in self._flat}

    def ancestors_map(self) -> dict[str, tuple[str, ...]]:
        """``{category_id: (ancestor_id, ...)}`` root-first, excluding self."""
        cache: dict[str, tuple[str, ...]] = {}

        def _anc(cid: str) -> tuple[str, ...]:
            if cid in cache:
                return cache[cid]
            parent = self._parent_of.get(cid)
            cache[cid] = () if parent is None else (*_anc(parent), parent)
            return cache[cid]

        return {n.id: _anc(n.id) for n in self._flat}

    def descendants_map(self) -> dict[str, tuple[str, ...]]:
        """``{category_id: (descendant_id, ...)}`` in pre-order DFS, excluding self."""
        cache: dict[str, tuple[str, ...]] = {}

        def _desc(node: Category) -> tuple[str, ...]:
            if node.id in cache:
                return cache[node.id]
            out: list[str] = []
            for child in node.categories:
                out.append(child.id)
                out.extend(_desc(child))
            cache[node.id] = tuple(out)
            return cache[node.id]

        return {n.id: _desc(n) for n in self._flat}

    def inherit_along_broader[T](self, values: dict[str, T]) -> dict[str, T]:
        """Propagate ``values`` down the parent chain."""
        result: dict[str, T] = {}
        for n in self._flat:
            cur_id: str | None = n.id
            while cur_id is not None:
                if cur_id in values:
                    result[n.id] = values[cur_id]
                    break
                cur_id = self._parent_of.get(cur_id)
        return result

    def add(self, categories: "Category | list[Category]") -> "CategoryScheme":
        """Return a new CategoryScheme with *categories* added.

        Accepts a single Category or a list of Categories.
        """
        new = [categories] if isinstance(categories, Category) else list(categories)
        return evolve(self, categories=[*self.categories, *new])

    def drop(self, category_ids: str | list[str]) -> "CategoryScheme":
        """Return a new CategoryScheme with the given category(ies) removed.

        Accepts a single id string or a list of id strings.
        Raises KeyError if any id is not present.
        """
        ids = [category_ids] if isinstance(category_ids, str) else list(category_ids)
        missing = [i for i in ids if i not in self.categories]
        if missing:
            raise KeyError(missing[0] if len(missing) == 1 else missing)
        id_set = set(ids)
        return evolve(self, categories=[c for c in self.categories if c.id not in id_set])


@define
class Categorisation(MaintainableArtefact):
    """Links an artefact (source) to a Category (target)."""

    sdmx_package: ClassVar[str] = "categoryscheme"
    sdmx_class: ClassVar[str] = "Categorisation"
    msg_field: ClassVar[str] = "categorisations"

    id: str
    maintainer: Agency = field(converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    source: AnyRef | None = None
    target: AnyRef | None = None
