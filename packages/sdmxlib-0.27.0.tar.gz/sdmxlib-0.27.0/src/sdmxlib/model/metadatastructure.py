"""MetadataStructure (MSD) and MetadataAttribute — structural template for reference metadata."""

from datetime import datetime
from typing import ClassVar

from attrs import define, evolve, field

from sdmxlib.model.annotations import Annotations
from sdmxlib.model.base import MaintainableArtefact
from sdmxlib.model.codelist import Codelist
from sdmxlib.model.collections import ItemList
from sdmxlib.model.concept import Concept
from sdmxlib.model.datastructure import ConceptIdentityMixin, RepresentationMixin
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.organisation import Agency, _to_agency, _to_annotations, _to_istring
from sdmxlib.model.ref import Ref
from sdmxlib.model.representation import Facet
from sdmxlib.model.urn import SdmxUrn


def _to_concept_ref(v: "Ref[Concept] | SdmxUrn[Concept] | None") -> "Ref[Concept] | None":
    if isinstance(v, SdmxUrn):
        return Ref[Concept].unresolved(v)
    return v


def _to_codelist_ref(
    v: "Ref[Codelist] | SdmxUrn[Codelist] | Codelist | Facet | None",
) -> "Ref[Codelist] | Facet | None":
    if isinstance(v, SdmxUrn):
        return Ref[Codelist].unresolved(v)
    if isinstance(v, Codelist):
        return Ref.to(v)
    return v


def _to_children(
    v: "ItemList[MetadataAttribute] | list[MetadataAttribute]",
) -> "ItemList[MetadataAttribute]":
    return v if isinstance(v, ItemList) else ItemList(v)


@define
class MetadataAttribute(ConceptIdentityMixin, RepresentationMixin):
    """A structural component of a MetadataStructure.

    Defines one slot in the metadata schema — what can be reported, with
    which representation (codelist or text), and how often.

    Children form a recursive tree (no parent back-reference). Cardinality
    is expressed via min_occurs and max_occurs (None = unbounded).

    Example:
        sl.MetadataAttribute(
            id="FOOTNOTE_TEXT",
            concept=cs.ref_to("FOOTNOTE_TEXT"),
            representation=Facet(type=DataType.String),
            min_occurs=0,
            max_occurs=1,
        )
    """

    id: str
    concept: Ref[Concept] | None = field(default=None, converter=_to_concept_ref)
    representation: Ref[Codelist] | Facet | None = field(default=None, converter=_to_codelist_ref)
    min_occurs: int = 0
    max_occurs: int | None = 1
    is_presentational: bool = False
    children: "ItemList[MetadataAttribute]" = field(factory=ItemList, converter=_to_children)
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)


def _to_attributes(
    v: "ItemList[MetadataAttribute] | list[MetadataAttribute]",
) -> "ItemList[MetadataAttribute]":
    return v if isinstance(v, ItemList) else ItemList(v)


def _flatten_attributes(roots: ItemList["MetadataAttribute"]) -> ItemList["MetadataAttribute"]:
    """Recursively collect all metadata attributes into a flat ItemList."""
    result: list[MetadataAttribute] = []

    def _walk(node: MetadataAttribute) -> None:
        result.append(node)
        for child in node.children:
            _walk(child)

    for node in roots:
        _walk(node)
    return ItemList(result)


@define
class MetadataStructure(MaintainableArtefact):
    """The structural definition of a reference-metadata schema (SDMX MSD).

    Holds a tree of MetadataAttribute components. Each MetadataAttribute
    declares one reportable slot — a concept, a representation (codelist
    or facet), and cardinality bounds.

    Example:
        msd = sl.MetadataStructure(
            id="MSD_FOOTNOTES", maintainer="STC_CP",
            attributes=[sl.MetadataAttribute(id="FOOTNOTE_TEXT", ...)],
        )
        msd.attributes["FOOTNOTE_TEXT"]  # MetadataAttribute by id
    """

    sdmx_package: ClassVar[str] = "metadatastructure"
    sdmx_class: ClassVar[str] = "MetadataStructure"
    msg_field: ClassVar[str] = "metadata_structures"

    id: str
    maintainer: Agency = field(converter=_to_agency)
    version: str = "1.0"
    name: InternationalString = field(factory=InternationalString, converter=_to_istring)
    description: InternationalString = field(factory=InternationalString, converter=_to_istring)
    is_final: bool = False
    annotations: Annotations = field(factory=Annotations, converter=_to_annotations)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    attributes: ItemList[MetadataAttribute] = field(factory=ItemList, converter=_to_attributes)
    _flat: ItemList[MetadataAttribute] = field(init=False, repr=False, factory=ItemList)
    _parent_of: dict[str, str | None] = field(init=False, repr=False, eq=False, factory=dict)

    def __attrs_post_init__(self) -> None:
        self._flat = _flatten_attributes(self.attributes)
        parent: dict[str, str | None] = {n.id: None for n in self._flat}
        for node in self._flat:
            for child in node.children:
                parent[child.id] = node.id
        self._parent_of = parent

    # ── SKOS/XKOS hierarchy navigation ────────────────────────────────────

    def roots(self) -> ItemList[MetadataAttribute]:
        """Top-level attributes (no parent)."""
        return self.attributes

    def leaves(self) -> ItemList[MetadataAttribute]:
        """Attributes with no children."""
        return self._flat.filter(lambda n: len(n.children) == 0)

    def narrower(self, attribute_id: str) -> ItemList[MetadataAttribute]:
        """Direct children of ``attribute_id``."""
        target = self._flat.get(attribute_id)
        if target is None:
            return ItemList([])
        return ItemList(list(target.children))

    def broader(self, attribute_id: str) -> "MetadataAttribute | None":
        """Direct parent of ``attribute_id``. ``None`` for roots."""
        parent_id = self._parent_of.get(attribute_id)
        if parent_id is None:
            return None
        return self._flat.get(parent_id)

    def broader_transitive(self, attribute_id: str, *, depth: int | None = None) -> ItemList[MetadataAttribute]:
        """All ancestors of ``attribute_id``, root-first. ``depth`` bounds hops."""
        result: list[MetadataAttribute] = []
        current_id: str | None = attribute_id
        hops = 0
        while True:
            parent_id = self._parent_of.get(current_id) if current_id is not None else None
            if parent_id is None:
                break
            if depth is not None and hops >= depth:
                break
            parent = self._flat.get(parent_id)
            if parent is None:
                break
            result.append(parent)
            current_id = parent_id
            hops += 1
        result.reverse()
        return ItemList(result)

    def narrower_transitive(self, attribute_id: str, *, depth: int | None = None) -> ItemList[MetadataAttribute]:
        """All descendants of ``attribute_id`` in pre-order DFS. ``depth`` bounds hops."""
        result: list[MetadataAttribute] = []
        target = self._flat.get(attribute_id)
        if target is None:
            return ItemList(result)

        def _walk(node: MetadataAttribute, hops: int) -> None:
            if depth is not None and hops >= depth:
                return
            for child in node.children:
                result.append(child)
                _walk(child, hops + 1)

        _walk(target, 0)
        return ItemList(result)

    def depth_of(self, attribute_id: str) -> int:
        """Depth of ``attribute_id`` in the tree (root = 0)."""
        if attribute_id not in self._parent_of:
            msg = f"Attribute {attribute_id!r} not in MSD {self.id!r}"
            raise KeyError(msg)
        depth = 0
        current: str | None = attribute_id
        while True:
            parent = self._parent_of.get(current) if current is not None else None
            if parent is None:
                break
            depth += 1
            current = parent
        return depth

    # ── Bulk projections ──────────────────────────────────────────────────

    def depths(self) -> dict[str, int]:
        """``{attribute_id: depth}`` for every attribute (root = 0)."""
        cache: dict[str, int] = {}

        def _depth(aid: str) -> int:
            if aid in cache:
                return cache[aid]
            parent = self._parent_of.get(aid)
            cache[aid] = 0 if parent is None else _depth(parent) + 1
            return cache[aid]

        return {n.id: _depth(n.id) for n in self._flat}

    def broader_map(self) -> dict[str, str | None]:
        """``{attribute_id: parent_id}`` for every attribute; ``None`` for roots."""
        return dict(self._parent_of)

    def narrower_map(self) -> dict[str, tuple[str, ...]]:
        """``{attribute_id: (child_id, ...)}`` for every attribute."""
        return {n.id: tuple(c.id for c in n.children) for n in self._flat}

    def ancestors_map(self) -> dict[str, tuple[str, ...]]:
        """``{attribute_id: (ancestor_id, ...)}`` root-first, excluding self."""
        cache: dict[str, tuple[str, ...]] = {}

        def _anc(aid: str) -> tuple[str, ...]:
            if aid in cache:
                return cache[aid]
            parent = self._parent_of.get(aid)
            cache[aid] = () if parent is None else (*_anc(parent), parent)
            return cache[aid]

        return {n.id: _anc(n.id) for n in self._flat}

    def descendants_map(self) -> dict[str, tuple[str, ...]]:
        """``{attribute_id: (descendant_id, ...)}`` in pre-order DFS, excluding self."""
        cache: dict[str, tuple[str, ...]] = {}

        def _desc(node: MetadataAttribute) -> tuple[str, ...]:
            if node.id in cache:
                return cache[node.id]
            out: list[str] = []
            for child in node.children:
                out.append(child.id)
                out.extend(_desc(child))
            cache[node.id] = tuple(out)
            return cache[node.id]

        return {n.id: _desc(n) for n in self._flat}

    def inherit_along_broader[T](self, values: dict[str, T]) -> dict[str, T]:
        """Propagate ``values`` down the parent chain."""
        result: dict[str, T] = {}
        for n in self._flat:
            cur_id: str | None = n.id
            while cur_id is not None:
                if cur_id in values:
                    result[n.id] = values[cur_id]
                    break
                cur_id = self._parent_of.get(cur_id)
        return result

    def add(self, attributes: "MetadataAttribute | list[MetadataAttribute]") -> "MetadataStructure":
        """Return a new MetadataStructure with *attributes* added."""
        new = [attributes] if isinstance(attributes, MetadataAttribute) else list(attributes)
        return evolve(self, attributes=[*self.attributes, *new])

    def drop(self, attribute_ids: str | list[str]) -> "MetadataStructure":
        """Return a new MetadataStructure with the given attribute(s) removed.

        Searches only the top-level attributes by id (children are not flattened).
        Raises KeyError if any id is not present.
        """
        ids = [attribute_ids] if isinstance(attribute_ids, str) else list(attribute_ids)
        missing = [i for i in ids if i not in self.attributes]
        if missing:
            raise KeyError(missing[0] if len(missing) == 1 else missing)
        id_set = set(ids)
        return evolve(self, attributes=[a for a in self.attributes if a.id not in id_set])
