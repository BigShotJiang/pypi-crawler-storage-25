"""StructureMessage and MetadataMessage — wire-format envelopes.

The wire formats split into two distinct envelopes:

- ``StructureMessage`` carries definitions (Codelists, DSDs, MSDs,
  Metadataflows, …). Maps to ``<mes:Structure>`` in SDMX-ML 3.0 and to
  the structure ``$schema`` in SDMX-JSON 2.0.
- ``MetadataMessage`` carries populated reference metadata
  (``MetadataSet`` instances). Maps to ``<mes:GenericMetadata>`` in
  SDMX-ML 3.0 and to the metadata ``$schema`` in SDMX-JSON 2.0.

The format layer auto-discriminates inbound messages and dispatches
outbound writes on the message type.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from attrs import field, frozen

from sdmxlib.model.collections import ArtefactList

if TYPE_CHECKING:
    from sdmxlib.model.category import Categorisation, CategoryScheme
    from sdmxlib.model.codelist import Codelist
    from sdmxlib.model.concept import ConceptScheme
    from sdmxlib.model.constraint import DataConstraint
    from sdmxlib.model.dataflow import Dataflow
    from sdmxlib.model.datastructure import DataStructure
    from sdmxlib.model.hierarchy import Hierarchy
    from sdmxlib.model.mapping import StructureSet
    from sdmxlib.model.metadataflow import Metadataflow
    from sdmxlib.model.metadataset import MetadataSet
    from sdmxlib.model.metadatastructure import MetadataStructure
    from sdmxlib.model.organisation import AgencyScheme, DataProviderScheme
    from sdmxlib.model.provision import ProvisionAgreement


def _to_artefact_list(v: Any) -> ArtefactList:  # type: ignore[type-arg]
    return v if isinstance(v, ArtefactList) else ArtefactList(v)


@frozen
class StructureMessage:
    """Wire-format envelope for SDMX structural definitions.

    Carries Codelists, DSDs, MSDs, Metadataflows, etc. Cross-references
    within the message are auto-resolved by the reader.

    Example:
        msg = parse(xml_bytes)
        dsd = msg.data_structures[0]
        cl = msg.codelists["SDMX:CL_FREQ(1.0)"]
    """

    codelists: ArtefactList[Codelist] = field(factory=ArtefactList, converter=_to_artefact_list)
    concept_schemes: ArtefactList[ConceptScheme] = field(factory=ArtefactList, converter=_to_artefact_list)
    data_structures: ArtefactList[DataStructure] = field(factory=ArtefactList, converter=_to_artefact_list)
    dataflows: ArtefactList[Dataflow] = field(factory=ArtefactList, converter=_to_artefact_list)
    category_schemes: ArtefactList[CategoryScheme] = field(factory=ArtefactList, converter=_to_artefact_list)
    categorisations: ArtefactList[Categorisation] = field(factory=ArtefactList, converter=_to_artefact_list)
    provision_agreements: ArtefactList[ProvisionAgreement] = field(factory=ArtefactList, converter=_to_artefact_list)
    agency_schemes: ArtefactList[AgencyScheme] = field(factory=ArtefactList, converter=_to_artefact_list)
    data_provider_schemes: ArtefactList[DataProviderScheme] = field(factory=ArtefactList, converter=_to_artefact_list)
    constraints: ArtefactList[DataConstraint] = field(factory=ArtefactList, converter=_to_artefact_list)
    structure_sets: ArtefactList[StructureSet] = field(factory=ArtefactList, converter=_to_artefact_list)
    hierarchies: ArtefactList[Hierarchy] = field(factory=ArtefactList, converter=_to_artefact_list)
    metadata_structures: ArtefactList[MetadataStructure] = field(factory=ArtefactList, converter=_to_artefact_list)
    metadataflows: ArtefactList[Metadataflow] = field(factory=ArtefactList, converter=_to_artefact_list)

    def all_artefacts(self) -> list[Any]:
        """Flat list of every artefact in the message."""
        return [
            *self.codelists,
            *self.concept_schemes,
            *self.data_structures,
            *self.dataflows,
            *self.category_schemes,
            *self.categorisations,
            *self.provision_agreements,
            *self.agency_schemes,
            *self.data_provider_schemes,
            *self.constraints,
            *self.structure_sets,
            *self.hierarchies,
            *self.metadata_structures,
            *self.metadataflows,
        ]

    @classmethod
    def containing(cls, artefact: Any) -> StructureMessage:
        """Wrap a single structural artefact in a fresh :class:`StructureMessage`.

        Dispatches on the artefact's runtime type to the matching
        collection slot (``Codelist`` → ``codelists``, ``Dataflow`` →
        ``dataflows``, …) using the artefact class's ``msg_field``
        ClassVar. Saves REST handlers from a long ``isinstance`` chain.

        Example:
            return StructureMessage.containing(dataflow)
            # equivalent to: StructureMessage(dataflows=[dataflow])

        Args:
            artefact: A maintainable artefact whose type maps to one of
                this message's slots.

        Raises:
            TypeError: If the artefact's class has no ``msg_field`` or
                its ``msg_field`` is not a slot on
                :class:`StructureMessage`.
        """
        slot = getattr(type(artefact), "msg_field", None)
        if not isinstance(slot, str):
            msg = (
                f"StructureMessage.containing: {type(artefact).__name__} has no "
                "msg_field — not a known maintainable artefact"
            )
            raise TypeError(msg)
        valid_slots = {a.name for a in cls.__attrs_attrs__}  # type: ignore[attr-defined]
        if slot not in valid_slots:
            msg = (
                f"StructureMessage.containing: {type(artefact).__name__} maps to "
                f"slot {slot!r} which is not a StructureMessage field "
                f"(valid: {sorted(valid_slots)})"
            )
            raise TypeError(msg)
        return cls(**{slot: [artefact]})


@frozen
class MetadataMessage:
    """Wire-format envelope for populated reference metadata.

    Carries MetadataSet instances. Maps to ``<mes:GenericMetadata>`` in
    SDMX-ML 3.0 and to the metadata ``$schema`` envelope in SDMX-JSON 2.0.

    Example:
        msg = parse(metadata_xml_bytes)
        for ms in msg.metadata_sets:
            for target in ms.targets:
                print(target.urn, ms.attributes.ids())
    """

    metadata_sets: ArtefactList[MetadataSet] = field(factory=ArtefactList, converter=_to_artefact_list)

    def all_artefacts(self) -> list[Any]:
        """Flat list of every artefact in the message."""
        return list(self.metadata_sets)
