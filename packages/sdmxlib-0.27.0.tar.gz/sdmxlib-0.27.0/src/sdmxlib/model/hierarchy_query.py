"""HierarchyNodeQuery — lazy, composable filter DSL over a Hierarchy's nodes.

Mirrors :mod:`sdmxlib.model.code_query` but compiles against
``sdmx.hierarchy_node``. Returned by :class:`LazyHierarchy` SKOS verbs
(``roots``/``narrower``/``broader_transitive``/...) so callers can
compose tree walks with predicate filters and either ``.collect()``
hydrated :class:`HierarchicalCode` objects or ``.ids()`` for node ids.

Example:
    h = local.hierarchy(geo_h_urn)
    h.narrower("CA").filter(node.level == "Province").ids()
    h.nodes.filter(node.depth <= 2).collect()
"""

from __future__ import annotations

from collections.abc import Iterator, Sequence
from typing import TYPE_CHECKING, Any, overload

import attrs

from sdmxlib.model.annotations import Annotation, Annotations
from sdmxlib.model.codelist import Code
from sdmxlib.model.hierarchy import HierarchicalCode, Level
from sdmxlib.model.istring import InternationalString
from sdmxlib.model.ref import Ref
from sdmxlib.model.urn import SdmxUrn

if TYPE_CHECKING:
    import duckdb


# ── Field expressions ────────────────────────────────────────────────────


class _FieldExpr:
    """Marker base for field expressions in the predicate AST."""


@attrs.frozen
class _NodeIdField(_FieldExpr):
    """The node's id (``node.id``)."""


@attrs.frozen
class _DepthField(_FieldExpr):
    """The node's depth in the hierarchy (``node.depth``)."""


@attrs.frozen
class _ParentNodeIdField(_FieldExpr):
    """The node's parent node id (``node.parent_id``)."""


@attrs.frozen
class _NameField(_FieldExpr):
    """A localised name (``node.name[lang]``)."""

    lang: str


@attrs.frozen
class _LevelField(_FieldExpr):
    """The node's level id (``node.level``)."""


@attrs.frozen
class _CodeUrnField(_FieldExpr):
    """The URN of the Code this node references (``node.code``)."""


@attrs.frozen
class _AnnotationField(_FieldExpr):
    """An annotation's ``title`` value (``node.annotations[type]``)."""

    type: str


# ── Predicate AST ───────────────────────────────────────────────────────


class Predicate:
    """Marker base for predicates the query compiler understands."""


@attrs.frozen
class _Eq(Predicate):
    field: _FieldExpr
    value: object
    negate: bool = False


@attrs.frozen
class _StringMatch(Predicate):
    field: _FieldExpr
    op: str  # "contains" | "starts_with" | "ends_with"
    value: str


@attrs.frozen
class _IsNull(Predicate):
    field: _FieldExpr
    negate: bool = False


@attrs.frozen
class _HasAncestor(Predicate):
    """The node's ``ancestor_ids`` array contains ``ancestor_id``."""

    ancestor_id: str
    max_absolute_depth: int | None = None


@attrs.frozen
class _IsAncestorOf(Predicate):
    """The node's id is in ``descendant_id``'s ``ancestor_ids`` array."""

    descendant_id: str
    min_absolute_depth: int | None = None


@attrs.frozen
class _HasNoNarrower(Predicate):
    """Leaf check — no other node names this node as parent."""


@attrs.frozen
class _AnyAncestorMatches(Predicate):
    """``EXISTS`` against the ancestors of this node."""

    sub_predicate: Predicate
    depth: int | None = None


@attrs.frozen
class _AnyDescendantMatches(Predicate):
    """``EXISTS`` against the descendants of this node."""

    sub_predicate: Predicate
    depth: int | None = None


# ── Sort keys ───────────────────────────────────────────────────────────


@attrs.frozen
class _SortKey:
    """One ORDER BY entry."""

    field: _FieldExpr
    ascending: bool = True


# ── Refs (returned by the ``node`` accessor) ────────────────────────────


class _Ref:
    """Base ref — supports equality predicates."""

    __slots__ = ()

    @property
    def _field(self) -> _FieldExpr:
        raise NotImplementedError

    def __eq__(self, value: object) -> Predicate:  # type: ignore[override]
        return _Eq(self._field, _coerce_value(self._field, value), negate=False)

    def __ne__(self, value: object) -> Predicate:  # type: ignore[override]
        return _Eq(self._field, _coerce_value(self._field, value), negate=True)

    __hash__ = None  # type: ignore[assignment]


def _coerce_value(field: _FieldExpr, value: object) -> object:
    """Convert convenient inputs (Ref[Code], Level, Hierarchy node) to comparable URN/id strings."""
    if isinstance(field, _CodeUrnField):
        if isinstance(value, Ref):
            return str(value.urn)
        if isinstance(value, SdmxUrn):
            return str(value)
        if isinstance(value, Code):
            from sdmxlib.model.in_memory_registry import artefact_urn  # noqa: PLC0415

            return str(artefact_urn(value))
    if isinstance(field, _LevelField) and isinstance(value, Level):
        return value.id
    return value


class _StringRef(_Ref):
    """String-typed ref. Adds polars-style string predicates."""

    __slots__ = ()

    def contains(self, value: str) -> Predicate:
        return _StringMatch(self._field, "contains", value)

    def starts_with(self, value: str) -> Predicate:
        return _StringMatch(self._field, "starts_with", value)

    def ends_with(self, value: str) -> Predicate:
        return _StringMatch(self._field, "ends_with", value)

    def is_null(self) -> Predicate:
        return _IsNull(self._field, negate=False)

    def is_not_null(self) -> Predicate:
        return _IsNull(self._field, negate=True)


class _NodeIdRef(_StringRef):
    __slots__ = ()

    @property
    def _field(self) -> _FieldExpr:
        return _NodeIdField()


class _DepthRef(_Ref):
    __slots__ = ()

    @property
    def _field(self) -> _FieldExpr:
        return _DepthField()

    # Numeric comparisons (mirror code_query._DepthRef shape if extended).


class _ParentNodeIdRef(_StringRef):
    __slots__ = ()

    @property
    def _field(self) -> _FieldExpr:
        return _ParentNodeIdField()


class _NameLangRef(_StringRef):
    __slots__ = ("lang",)

    def __init__(self, lang: str) -> None:
        self.lang = lang

    @property
    def _field(self) -> _FieldExpr:
        return _NameField(self.lang)


class _NameAccessor:
    __slots__ = ()

    def __getitem__(self, lang: str) -> _NameLangRef:
        return _NameLangRef(lang)


class _LevelRef(_StringRef):
    __slots__ = ()

    @property
    def _field(self) -> _FieldExpr:
        return _LevelField()


class _CodeRef(_StringRef):
    __slots__ = ()

    @property
    def _field(self) -> _FieldExpr:
        return _CodeUrnField()


class _AnnotationRef(_StringRef):
    __slots__ = ("type",)

    def __init__(self, annotation_type: str) -> None:
        self.type = annotation_type

    @property
    def _field(self) -> _FieldExpr:
        return _AnnotationField(self.type)


class _AnnotationsAccessor:
    __slots__ = ()

    def __getitem__(self, annotation_type: str) -> _AnnotationRef:
        return _AnnotationRef(annotation_type)


class _BroaderTransitiveSubRef:
    """Sub-query ref for the node's ancestor chain."""

    __slots__ = ("depth",)

    def __init__(self, depth: int | None = None) -> None:
        self.depth = depth

    def any(self, sub_predicate: Predicate) -> Predicate:
        """Predicate: at least one ancestor matches ``sub_predicate``."""
        return _AnyAncestorMatches(sub_predicate=sub_predicate, depth=self.depth)


class _NarrowerTransitiveSubRef:
    """Sub-query ref for the node's descendants."""

    __slots__ = ("depth",)

    def __init__(self, depth: int | None = None) -> None:
        self.depth = depth

    def any(self, sub_predicate: Predicate) -> Predicate:
        """Predicate: at least one descendant matches ``sub_predicate``."""
        return _AnyDescendantMatches(sub_predicate=sub_predicate, depth=self.depth)


class _NodeAccessor:
    """The ``node`` namespace — entry point for the predicate DSL."""

    __slots__ = ()

    @property
    def id(self) -> _NodeIdRef:
        return _NodeIdRef()

    @property
    def depth(self) -> _DepthRef:
        return _DepthRef()

    @property
    def parent_id(self) -> _ParentNodeIdRef:
        return _ParentNodeIdRef()

    @property
    def name(self) -> _NameAccessor:
        return _NameAccessor()

    @property
    def level(self) -> _LevelRef:
        return _LevelRef()

    @property
    def code(self) -> _CodeRef:
        return _CodeRef()

    @property
    def annotations(self) -> _AnnotationsAccessor:
        return _AnnotationsAccessor()

    def broader_transitive(self, depth: int | None = None) -> _BroaderTransitiveSubRef:
        return _BroaderTransitiveSubRef(depth=depth)

    def narrower_transitive(self, depth: int | None = None) -> _NarrowerTransitiveSubRef:
        return _NarrowerTransitiveSubRef(depth=depth)


node = _NodeAccessor()
"""Predicate accessor namespace for hierarchy nodes — exposed at the top level as ``sl.node``."""


# ── HierarchyNodeQuery ──────────────────────────────────────────────────


@attrs.frozen
class HierarchyNodeQuery:
    """Lazy, composable query against a hierarchy's nodes.

    Construct via :class:`LazyHierarchy` SKOS verbs. Composes via
    ``.filter()``; materialises via ``.collect()`` (hydrated
    :class:`HierarchicalCode` objects) or ``.ids()`` (node ids).
    """

    hierarchy_urn: str
    _conn: duckdb.DuckDBPyConnection = attrs.field(eq=False, repr=False, alias="conn")
    predicates: tuple[Predicate, ...] = ()
    sort_keys: tuple[_SortKey, ...] = ()
    limit_n: int | None = None
    annotation_types: tuple[str, ...] = ()

    # ── Composition ─────────────────────────────────────────────────────

    def filter(self, predicate: Predicate) -> HierarchyNodeQuery:
        """Return a new query with ``predicate`` AND-ed onto the chain."""
        return attrs.evolve(self, predicates=(*self.predicates, predicate))

    def sort_by(self, key: _Ref, *, ascending: bool = True) -> HierarchyNodeQuery:
        """Add an ORDER BY key."""
        sk = _SortKey(field=key._field, ascending=ascending)  # noqa: SLF001
        return attrs.evolve(self, sort_keys=(*self.sort_keys, sk))

    def limit(self, n: int) -> HierarchyNodeQuery:
        """Return a new query capped at ``n`` rows."""
        return attrs.evolve(self, limit_n=n)

    def with_annotations(self, *types: str) -> HierarchyNodeQuery:
        """Return a new query that hydrates the listed annotation types on collect."""
        return attrs.evolve(self, annotation_types=types)

    # ── Materialisation ─────────────────────────────────────────────────

    def collect(self) -> list[HierarchicalCode]:
        """Compile to SQL, execute, and return materialised :class:`HierarchicalCode` objects."""
        sql, params = _compile(self)
        rows = self._conn.execute(sql, params).fetchall()
        if not rows:
            return []
        if self.annotation_types:
            urns = [r[6] for r in rows]
            anns_by_urn = _fetch_annotations_for(self._conn, urns, types=self.annotation_types)
            return [_row_to_node(row, anns_by_urn.get(row[6], Annotations())) for row in rows]
        empty = Annotations()
        return [_row_to_node(row, empty) for row in rows]

    def ids(self) -> list[str]:
        """Compile to SQL, execute, and return just the node ids."""
        sql, params = _compile(self, select_clause="hn.node_id")
        rows = self._conn.execute(sql, params).fetchall()
        return [r[0] for r in rows]

    def to_sql(self) -> tuple[str, list[object]]:
        """Compile to SQL without executing — for use as a subquery."""
        return _compile(self, select_clause="hn.node_id", omit_order=True)

    # ── Sequence-like access ────────────────────────────────────────────

    def __iter__(self) -> Iterator[HierarchicalCode]:
        return iter(self.collect())

    def __len__(self) -> int:
        sql, params = _compile(self, select_clause="COUNT(*)", omit_order=True)
        row = self._conn.execute(sql, params).fetchone()
        return row[0] if row else 0  # type: ignore[index]

    @overload
    def __getitem__(self, key: int) -> HierarchicalCode: ...

    @overload
    def __getitem__(self, key: str) -> HierarchicalCode: ...

    def __getitem__(self, key: int | str) -> HierarchicalCode:
        if isinstance(key, str):
            row = self._conn.execute(
                """
                SELECT hn.node_id, hn.parent_node_id, hn.depth, hn.name,
                       hn.code_urn, hn.level_id, hn.node_urn, hn.description,
                       hn.valid_from, hn.valid_to
                FROM sdmx.hierarchy_node hn
                WHERE hn.hierarchy_urn = ? AND hn.node_id = ?
                """,
                [self.hierarchy_urn, key],
            ).fetchone()
            if row is None:
                raise KeyError(key)
            return _row_to_node(row, self._anns_for_one(row[6]))

        offset = key if key >= 0 else len(self) + key
        row = self._conn.execute(
            """
            SELECT hn.node_id, hn.parent_node_id, hn.depth, hn.name,
                   hn.code_urn, hn.level_id, hn.node_urn, hn.description,
                   hn.valid_from, hn.valid_to
            FROM sdmx.hierarchy_node hn
            WHERE hn.hierarchy_urn = ?
            ORDER BY hn.node_id
            LIMIT 1 OFFSET ?
            """,
            [self.hierarchy_urn, offset],
        ).fetchone()
        if row is None:
            raise IndexError(key)
        return _row_to_node(row, self._anns_for_one(row[6]))

    def _anns_for_one(self, node_urn: str) -> Annotations:
        if not self.annotation_types:
            return Annotations()
        return _fetch_annotations_for(self._conn, [node_urn], types=self.annotation_types).get(
            node_urn,
            Annotations(),
        )

    def __contains__(self, key: object) -> bool:
        if isinstance(key, str):
            row = self._conn.execute(
                "SELECT 1 FROM sdmx.hierarchy_node WHERE hierarchy_urn = ? AND node_id = ?",
                [self.hierarchy_urn, key],
            ).fetchone()
            return row is not None
        if isinstance(key, HierarchicalCode):
            return key.id in self
        return False

    def get(self, node_id: str) -> HierarchicalCode | None:
        """Look up a node by id, returning ``None`` if absent."""
        try:
            return self[node_id]
        except KeyError:
            return None


# ── SQL compiler ────────────────────────────────────────────────────────

_DEFAULT_SELECT = (
    "hn.node_id, hn.parent_node_id, hn.depth, hn.name, "
    "hn.code_urn, hn.level_id, hn.node_urn, hn.description, "
    "hn.valid_from, hn.valid_to"
)


def _compile(
    query: HierarchyNodeQuery,
    *,
    select_clause: str = _DEFAULT_SELECT,
    omit_order: bool = False,
) -> tuple[str, list[object]]:
    """Translate the predicate tree to a single ``sdmx.hierarchy_node`` query."""
    join_sqls: list[str] = []
    join_params: list[object] = []
    where_sqls: list[str] = ["hn.hierarchy_urn = ?"]
    where_params: list[object] = [query.hierarchy_urn]
    annotation_join_aliases: dict[str, str] = {}

    for pred in query.predicates:
        clause, params = _emit_predicate(
            pred,
            join_sqls=join_sqls,
            join_params=join_params,
            annotation_join_aliases=annotation_join_aliases,
        )
        where_sqls.append(clause)
        where_params.extend(params)

    sql_parts = [f"SELECT {select_clause} FROM sdmx.hierarchy_node hn"]
    if join_sqls:
        sql_parts.append(" ".join(join_sqls))
    sql_parts.append("WHERE " + " AND ".join(where_sqls))

    if not omit_order:
        order_sqls, order_params = _build_order_by(query.sort_keys)
        sql_parts.append("ORDER BY " + ", ".join(order_sqls))
    else:
        order_params = []

    if query.limit_n is not None:
        sql_parts.append(f"LIMIT {int(query.limit_n)}")

    sql = " ".join(sql_parts)
    return sql, [*join_params, *where_params, *order_params]


def _build_order_by(sort_keys: tuple[_SortKey, ...]) -> tuple[list[str], list[object]]:
    parts: list[str] = []
    params: list[object] = []
    for sk in sort_keys:
        frag, frag_params = _emit_sort_field(sk.field)
        parts.append(frag if sk.ascending else f"{frag} DESC")
        params.extend(frag_params)
    parts.append("hn.node_id")
    return parts, params


def _emit_sort_field(field: _FieldExpr) -> tuple[str, list[object]]:
    if isinstance(field, _NodeIdField):
        return "hn.node_id", []
    if isinstance(field, _DepthField):
        return "hn.depth", []
    if isinstance(field, _ParentNodeIdField):
        return "hn.parent_node_id", []
    if isinstance(field, _LevelField):
        return "hn.level_id", []
    if isinstance(field, _NameField):
        return "hn.name[?]", [field.lang]
    msg = (
        f"Unsupported field for sort_by: {type(field).__name__}. "
        "Annotation- or code-typed sort keys aren't supported; filter the query first."
    )
    raise NotImplementedError(msg)


def _emit_predicate(
    pred: Predicate,
    *,
    row_alias: str = "hn",
    join_sqls: list[str],
    join_params: list[object],
    annotation_join_aliases: dict[str, str],
) -> tuple[str, list[object]]:
    if isinstance(pred, _Eq):
        return _emit_eq(
            pred,
            row_alias=row_alias,
            join_sqls=join_sqls,
            join_params=join_params,
            annotation_join_aliases=annotation_join_aliases,
        )
    if isinstance(pred, _StringMatch):
        return _emit_string_match(
            pred,
            row_alias=row_alias,
            join_sqls=join_sqls,
            join_params=join_params,
            annotation_join_aliases=annotation_join_aliases,
        )
    if isinstance(pred, _IsNull):
        return _emit_is_null(pred, row_alias=row_alias)
    if isinstance(pred, _HasAncestor):
        return _emit_has_ancestor(pred, row_alias=row_alias)
    if isinstance(pred, _IsAncestorOf):
        return _emit_is_ancestor_of(pred, row_alias=row_alias)
    if isinstance(pred, _HasNoNarrower):
        clause = (
            f"NOT EXISTS ("
            f"SELECT 1 FROM sdmx.hierarchy_node child "
            f"WHERE child.hierarchy_urn = {row_alias}.hierarchy_urn "
            f"AND child.parent_node_id = {row_alias}.node_id)"
        )
        return clause, []
    if isinstance(pred, _AnyAncestorMatches):
        return _emit_any_ancestor_matches(pred, row_alias=row_alias)
    if isinstance(pred, _AnyDescendantMatches):
        return _emit_any_descendant_matches(pred, row_alias=row_alias)
    msg = f"Unsupported predicate kind: {type(pred).__name__}"
    raise NotImplementedError(msg)


def _emit_eq(
    pred: _Eq,
    *,
    row_alias: str,
    join_sqls: list[str],
    join_params: list[object],
    annotation_join_aliases: dict[str, str],
) -> tuple[str, list[object]]:
    op = "!=" if pred.negate else "="
    field = pred.field
    if isinstance(field, _NodeIdField):
        return f"{row_alias}.node_id {op} ?", [pred.value]
    if isinstance(field, _DepthField):
        return f"{row_alias}.depth {op} ?", [pred.value]
    if isinstance(field, _ParentNodeIdField):
        return f"{row_alias}.parent_node_id {op} ?", [pred.value]
    if isinstance(field, _LevelField):
        return f"{row_alias}.level_id {op} ?", [pred.value]
    if isinstance(field, _CodeUrnField):
        return f"{row_alias}.code_urn {op} ?", [pred.value]
    if isinstance(field, _NameField):
        return f"{row_alias}.name[?] {op} ?", [field.lang, pred.value]
    if isinstance(field, _AnnotationField):
        alias = _ensure_annotation_join(
            field.type,
            row_alias=row_alias,
            join_sqls=join_sqls,
            join_params=join_params,
            annotation_join_aliases=annotation_join_aliases,
        )
        return f"{alias}.title {op} ?", [pred.value]
    msg = f"Unsupported field for ==/!=: {type(field).__name__}"
    raise NotImplementedError(msg)


def _emit_string_match(
    pred: _StringMatch,
    *,
    row_alias: str,
    join_sqls: list[str],
    join_params: list[object],
    annotation_join_aliases: dict[str, str],
) -> tuple[str, list[object]]:
    pattern = _ilike_pattern(pred.op, pred.value)
    field = pred.field
    if isinstance(field, _NodeIdField):
        return f"{row_alias}.node_id ILIKE ?", [pattern]
    if isinstance(field, _ParentNodeIdField):
        return f"{row_alias}.parent_node_id ILIKE ?", [pattern]
    if isinstance(field, _LevelField):
        return f"{row_alias}.level_id ILIKE ?", [pattern]
    if isinstance(field, _CodeUrnField):
        return f"{row_alias}.code_urn ILIKE ?", [pattern]
    if isinstance(field, _NameField):
        return f"{row_alias}.name[?] ILIKE ?", [field.lang, pattern]
    if isinstance(field, _AnnotationField):
        alias = _ensure_annotation_join(
            field.type,
            row_alias=row_alias,
            join_sqls=join_sqls,
            join_params=join_params,
            annotation_join_aliases=annotation_join_aliases,
        )
        return f"{alias}.title ILIKE ?", [pattern]
    msg = f"Unsupported field for string match: {type(field).__name__}"
    raise NotImplementedError(msg)


def _emit_is_null(pred: _IsNull, *, row_alias: str) -> tuple[str, list[object]]:
    op = "IS NOT NULL" if pred.negate else "IS NULL"
    field = pred.field
    if isinstance(field, _ParentNodeIdField):
        return f"{row_alias}.parent_node_id {op}", []
    if isinstance(field, _NodeIdField):
        return f"{row_alias}.node_id {op}", []
    if isinstance(field, _LevelField):
        return f"{row_alias}.level_id {op}", []
    if isinstance(field, _CodeUrnField):
        return f"{row_alias}.code_urn {op}", []
    msg = f"Unsupported field for is_null: {type(field).__name__}"
    raise NotImplementedError(msg)


def _emit_has_ancestor(pred: _HasAncestor, *, row_alias: str) -> tuple[str, list[object]]:
    if pred.max_absolute_depth is None:
        return f"? = ANY({row_alias}.ancestor_ids)", [pred.ancestor_id]
    return (
        f"? = ANY({row_alias}.ancestor_ids) AND {row_alias}.depth <= ?",
        [pred.ancestor_id, pred.max_absolute_depth],
    )


def _emit_is_ancestor_of(pred: _IsAncestorOf, *, row_alias: str) -> tuple[str, list[object]]:
    if pred.min_absolute_depth is None:
        clause = (
            f"{row_alias}.node_id IN ("
            f"SELECT UNNEST(ancestor_ids) FROM sdmx.hierarchy_node "
            f"WHERE hierarchy_urn = {row_alias}.hierarchy_urn AND node_id = ?)"
        )
        return clause, [pred.descendant_id]
    clause = (
        f"{row_alias}.node_id IN ("
        f"SELECT UNNEST(ancestor_ids) FROM sdmx.hierarchy_node "
        f"WHERE hierarchy_urn = {row_alias}.hierarchy_urn AND node_id = ?)"
        f" AND {row_alias}.depth >= ?"
    )
    return clause, [pred.descendant_id, pred.min_absolute_depth]


def _emit_subquery_predicate(pred: Predicate, *, row_alias: str) -> tuple[str, list[object]]:
    inner_joins: list[str] = []
    inner_join_params: list[object] = []
    inner_aliases: dict[str, str] = {}
    clause, params = _emit_predicate(
        pred,
        row_alias=row_alias,
        join_sqls=inner_joins,
        join_params=inner_join_params,
        annotation_join_aliases=inner_aliases,
    )
    if inner_joins:
        msg = (
            "Annotation predicates inside .any(...) sub-predicates aren't supported — "
            "they would require annotation joins inside the EXISTS subquery. "
            "Use a top-level .filter(...) instead."
        )
        raise NotImplementedError(msg)
    return clause, params


def _emit_any_ancestor_matches(
    pred: _AnyAncestorMatches,
    *,
    row_alias: str,
) -> tuple[str, list[object]]:
    inner_alias = f"{row_alias}_anc"
    sub_clause, sub_params = _emit_subquery_predicate(pred.sub_predicate, row_alias=inner_alias)
    clause = (
        f"EXISTS ("
        f"SELECT 1 FROM sdmx.hierarchy_node {inner_alias} "
        f"WHERE {inner_alias}.hierarchy_urn = {row_alias}.hierarchy_urn "
        f"AND {inner_alias}.node_id = ANY({row_alias}.ancestor_ids) "
        f"AND ({sub_clause}))"
    )
    return clause, sub_params


def _emit_any_descendant_matches(
    pred: _AnyDescendantMatches,
    *,
    row_alias: str,
) -> tuple[str, list[object]]:
    inner_alias = f"{row_alias}_desc"
    sub_clause, sub_params = _emit_subquery_predicate(pred.sub_predicate, row_alias=inner_alias)
    clause = (
        f"EXISTS ("
        f"SELECT 1 FROM sdmx.hierarchy_node {inner_alias} "
        f"WHERE {inner_alias}.hierarchy_urn = {row_alias}.hierarchy_urn "
        f"AND {row_alias}.node_id = ANY({inner_alias}.ancestor_ids) "
        f"AND ({sub_clause}))"
    )
    return clause, sub_params


def _ensure_annotation_join(
    annotation_type: str,
    *,
    row_alias: str,
    join_sqls: list[str],
    join_params: list[object],
    annotation_join_aliases: dict[str, str],
) -> str:
    """Add a JOIN against ``sdmx.annotation`` for ``annotation_type`` once."""
    cached = annotation_join_aliases.get(annotation_type)
    if cached is not None:
        return cached
    alias = f"a{len(annotation_join_aliases) + 1}"
    join_sqls.append(
        f"JOIN sdmx.annotation {alias} ON {alias}.owner_urn = {row_alias}.node_urn AND {alias}.annotation_type = ?"
    )
    join_params.append(annotation_type)
    annotation_join_aliases[annotation_type] = alias
    return alias


def _ilike_pattern(op: str, value: str) -> str:
    escaped = value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    if op == "contains":
        return f"%{escaped}%"
    if op == "starts_with":
        return f"{escaped}%"
    if op == "ends_with":
        return f"%{escaped}"
    msg = f"Unsupported string op: {op}"
    raise NotImplementedError(msg)


# ── Row → HierarchicalCode construction ─────────────────────────────────


def _map_to_istring(m: dict[str, str] | None) -> InternationalString:
    if not m:
        return InternationalString()
    return InternationalString.of(m)


def _row_to_node(row: Sequence[Any], annotations: Annotations) -> HierarchicalCode:
    """Construct a HierarchicalCode from a HierarchyNodeQuery result row.

    Row layout: ``(node_id, parent_node_id, depth, name_map, code_urn,
    level_id, node_urn, description_map, valid_from, valid_to)``.
    """
    node_id, _parent_id, _depth, name_map, code_urn, level_id, _node_urn, desc_map, valid_from, valid_to = row
    code_ref: Ref[Code] | None = None
    if code_urn is not None:
        code_ref = Ref[Code].unresolved(SdmxUrn.parse(str(code_urn)))
    level: Level | None = None
    if level_id is not None:
        level = Level(id=str(level_id))
    return HierarchicalCode(
        id=str(node_id),
        code=code_ref,
        name=_map_to_istring(name_map),
        description=_map_to_istring(desc_map),
        annotations=annotations,
        valid_from=valid_from,
        valid_to=valid_to,
        level=level,
    )


def _fetch_annotations_for(
    conn: duckdb.DuckDBPyConnection,
    node_urns: list[str],
    *,
    types: tuple[str, ...] = ("*",),
) -> dict[str, Annotations]:
    """Bulk-load annotations for many node URNs in two queries."""
    if not node_urns:
        return {}
    placeholders = ", ".join("?" for _ in node_urns)
    sql_parts = [
        "SELECT id, owner_urn, annotation_id, title, annotation_type, url, ordinal",
        "FROM sdmx.annotation",
        f"WHERE owner_urn IN ({placeholders})",
    ]
    sql_params: list[object] = list(node_urns)
    if types and "*" not in types:
        type_placeholders = ", ".join("?" for _ in types)
        sql_parts.append(f"AND annotation_type IN ({type_placeholders})")
        sql_params.extend(types)
    sql_parts.append("ORDER BY owner_urn, ordinal")
    ann_rows = conn.execute(" ".join(sql_parts), sql_params).fetchall()
    if not ann_rows:
        return {}

    ann_ids = [r[0] for r in ann_rows]
    text_placeholders = ", ".join("?" for _ in ann_ids)
    text_rows = conn.execute(
        f"""
        SELECT annotation_id, lang, text
        FROM sdmx.annotation_text
        WHERE annotation_id IN ({text_placeholders})
        """,
        list(ann_ids),
    ).fetchall()
    text_by_ann: dict[Any, dict[str, str]] = {}
    for ann_id, lang, text in text_rows:
        text_by_ann.setdefault(ann_id, {})[lang] = text

    out: dict[str, list[Annotation]] = {}
    for db_id, owner_urn, ann_id, title, ann_type, url, _ord in ann_rows:
        text_map = text_by_ann.get(db_id)
        text = InternationalString.of(text_map) if text_map else InternationalString()
        out.setdefault(owner_urn, []).append(Annotation(id=ann_id, title=title, type=ann_type, url=url, text=text))
    return {urn: Annotations(anns) for urn, anns in out.items()}


__all__ = [
    "HierarchyNodeQuery",
    "Predicate",
    "node",
]
