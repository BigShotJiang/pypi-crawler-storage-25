"""CodeQuery — lazy, composable filter DSL over codelists.

Three-layer SKOS/XKOS-aligned API.

- **Layer 1** — predicate accessor (``sl.code``). Used inside ``.filter(...)``.
  Hierarchy ops return sub-query refs supporting ``.any(predicate)`` for
  correlated EXISTS composition.
- **Layer 2** — codelist-bound queries (``LazyCodelist.codes``,
  ``LazyCodelist.roots()``, ``LazyCodelist.narrower(id)``, ...). Each
  method returns a ``CodeQuery`` that compiles to a single SQL statement
  against ``sdmx.code`` when materialised.
- **Layer 3** — materialised ``Code`` (pure data, no traversal methods).
  Returned by ``.collect()``.

Example:
    cl = local.codelist(geo_urn)
    cl.codes
        .filter(sl.code.name["en"].contains("Toronto"))
        .filter(sl.code.broader_transitive().any(sl.code.id == "ON"))
        .collect()
"""

from __future__ import annotations

from collections.abc import Iterator, Sequence
from typing import TYPE_CHECKING, Any, overload

import attrs

from sdmxlib.model.annotations import Annotation, Annotations
from sdmxlib.model.codelist import Code
from sdmxlib.model.istring import InternationalString

if TYPE_CHECKING:
    import duckdb


# ── Field expressions (AST nodes) ───────────────────────────────────────


class _FieldExpr:
    """Marker base for field expressions in the predicate AST."""


@attrs.frozen
class _IdField(_FieldExpr):
    """The code's id (``code.id``)."""


@attrs.frozen
class _DepthField(_FieldExpr):
    """The code's hierarchy depth (``code.depth``)."""


@attrs.frozen
class _ParentIdField(_FieldExpr):
    """The code's parent id (``code.parent_id``)."""


@attrs.frozen
class _NameField(_FieldExpr):
    """A localised name (``code.name[lang]``)."""

    lang: str


@attrs.frozen
class _AnnotationField(_FieldExpr):
    """An annotation's ``title`` value (``code.annotations[type]``)."""

    type: str


# ── Predicate AST ───────────────────────────────────────────────────────


class Predicate:
    """Marker base for predicates the query compiler understands."""


@attrs.frozen
class _Eq(Predicate):
    field: _FieldExpr
    value: object
    negate: bool = False


@attrs.frozen
class _StringMatch(Predicate):
    field: _FieldExpr
    op: str  # "contains" | "starts_with" | "ends_with"
    value: str


@attrs.frozen
class _IsNull(Predicate):
    field: _FieldExpr
    negate: bool = False


@attrs.frozen
class _HasAncestor(Predicate):
    """The code's ``ancestor_ids`` array contains ``ancestor_id``.

    When ``max_absolute_depth`` is set, the row is also constrained by
    ``code.depth <= max_absolute_depth``. The Layer-2 helper pre-computes
    this from the user's ``depth=N`` argument so the emitted SQL is a
    literal-int comparison rather than a per-row correlated subquery.
    """

    ancestor_id: str
    max_absolute_depth: int | None = None


@attrs.frozen
class _IsAncestorOf(Predicate):
    """The code's id is in ``descendant_id``'s ``ancestor_ids`` array.

    When ``min_absolute_depth`` is set, the row is also constrained by
    ``code.depth >= min_absolute_depth``.
    """

    descendant_id: str
    min_absolute_depth: int | None = None


@attrs.frozen
class _HasNoNarrower(Predicate):
    """Leaf check — no other code names this code as parent."""


@attrs.frozen
class _AnyDescendantMatches(Predicate):
    """``EXISTS`` against the descendants of this code."""

    sub_predicate: Predicate
    depth: int | None = None


@attrs.frozen
class _AnyAncestorMatches(Predicate):
    """``EXISTS`` against the ancestors of this code."""

    sub_predicate: Predicate
    depth: int | None = None


@attrs.frozen
class _InHierarchy(Predicate):
    """The code is a node in a Hierarchy, optionally at a named Level.

    Compiles to ``EXISTS`` against ``sdmx.hierarchy_node`` joined on
    ``code_urn``. EXISTS (rather than INNER JOIN) preserves row identity
    when a code appears at multiple nodes in the same hierarchy.
    """

    hierarchy_urn: str
    level_id: str | None = None

    def level(self, level_id: str) -> _InHierarchy:
        """Narrow membership to a named Level within the same Hierarchy."""
        return attrs.evolve(self, level_id=level_id)


# ── Sort keys ───────────────────────────────────────────────────────────


@attrs.frozen
class _SortKey:
    """One ORDER BY entry."""

    field: _FieldExpr
    ascending: bool = True


# ── Refs (returned by the ``code`` accessor) ────────────────────────────


class _Ref:
    """Base ref — supports equality predicates."""

    __slots__ = ()

    @property
    def _field(self) -> _FieldExpr:
        raise NotImplementedError

    def __eq__(self, value: object) -> Predicate:  # type: ignore[override]
        return _Eq(self._field, value, negate=False)

    def __ne__(self, value: object) -> Predicate:  # type: ignore[override]
        return _Eq(self._field, value, negate=True)

    __hash__ = None  # type: ignore[assignment]


class _StringRef(_Ref):
    """String-typed ref. Adds polars-style string predicates."""

    __slots__ = ()

    def contains(self, value: str) -> Predicate:
        return _StringMatch(self._field, "contains", value)

    def starts_with(self, value: str) -> Predicate:
        return _StringMatch(self._field, "starts_with", value)

    def ends_with(self, value: str) -> Predicate:
        return _StringMatch(self._field, "ends_with", value)

    def is_null(self) -> Predicate:
        return _IsNull(self._field, negate=False)

    def is_not_null(self) -> Predicate:
        return _IsNull(self._field, negate=True)


class _IdRef(_StringRef):
    __slots__ = ()

    @property
    def _field(self) -> _FieldExpr:
        return _IdField()


class _DepthRef(_Ref):
    __slots__ = ()

    @property
    def _field(self) -> _FieldExpr:
        return _DepthField()


class _ParentIdRef(_StringRef):
    __slots__ = ()

    @property
    def _field(self) -> _FieldExpr:
        return _ParentIdField()


class _NameLangRef(_StringRef):
    __slots__ = ("lang",)

    def __init__(self, lang: str) -> None:
        self.lang = lang

    @property
    def _field(self) -> _FieldExpr:
        return _NameField(self.lang)


class _NameAccessor:
    """Indexed by language tag → returns a string-typed ref."""

    __slots__ = ()

    def __getitem__(self, lang: str) -> _NameLangRef:
        return _NameLangRef(lang)


class _AnnotationRef(_StringRef):
    __slots__ = ("type",)

    def __init__(self, annotation_type: str) -> None:
        self.type = annotation_type

    @property
    def _field(self) -> _FieldExpr:
        return _AnnotationField(self.type)


class _AnnotationsAccessor:
    """Indexed by annotation type → returns a string-typed ref against ``title``."""

    __slots__ = ()

    def __getitem__(self, annotation_type: str) -> _AnnotationRef:
        return _AnnotationRef(annotation_type)


class _BroaderTransitiveSubRef:
    """Sub-query ref for the code's ancestor chain.

    Returned by ``code.broader_transitive(depth=...)``. Supports
    ``.any(predicate)`` for EXISTS composition.
    """

    __slots__ = ("depth",)

    def __init__(self, depth: int | None = None) -> None:
        self.depth = depth

    def any(self, sub_predicate: Predicate) -> Predicate:
        """Predicate: at least one ancestor matches ``sub_predicate``."""
        return _AnyAncestorMatches(sub_predicate=sub_predicate, depth=self.depth)


class _NarrowerTransitiveSubRef:
    """Sub-query ref for the code's descendants. ``.any(predicate)`` → EXISTS."""

    __slots__ = ("depth",)

    def __init__(self, depth: int | None = None) -> None:
        self.depth = depth

    def any(self, sub_predicate: Predicate) -> Predicate:
        """Predicate: at least one descendant matches ``sub_predicate``."""
        return _AnyDescendantMatches(sub_predicate=sub_predicate, depth=self.depth)


class _CodeAccessor:
    """The ``code`` namespace — entry point for the predicate DSL.

    Use as ``sl.code.<field>...`` inside ``.filter(...)``.
    """

    __slots__ = ()

    @property
    def id(self) -> _IdRef:
        return _IdRef()

    @property
    def depth(self) -> _DepthRef:
        return _DepthRef()

    @property
    def parent_id(self) -> _ParentIdRef:
        return _ParentIdRef()

    @property
    def name(self) -> _NameAccessor:
        return _NameAccessor()

    @property
    def annotations(self) -> _AnnotationsAccessor:
        return _AnnotationsAccessor()

    def broader_transitive(self, depth: int | None = None) -> _BroaderTransitiveSubRef:
        """Sub-query ref for ancestors. Use ``.any(predicate)`` to compose."""
        return _BroaderTransitiveSubRef(depth=depth)

    def narrower_transitive(self, depth: int | None = None) -> _NarrowerTransitiveSubRef:
        """Sub-query ref for descendants. Use ``.any(predicate)`` to compose."""
        return _NarrowerTransitiveSubRef(depth=depth)

    def hierarchy(self, hierarchy: object) -> _InHierarchy:
        """Predicate: code is a node in ``hierarchy``.

        Accepts a URN string or any artefact with a maintainable URN
        (e.g. a :class:`Hierarchy`). Chain ``.level(level_id)`` to narrow
        to nodes at a specific Level:

            q.filter(code.hierarchy(h).level("Province"))

        Compiles to a single ``EXISTS`` against ``sdmx.hierarchy_node`` —
        no row multiplication when a code appears at multiple nodes.
        """
        if isinstance(hierarchy, str):
            urn = hierarchy
        else:
            from sdmxlib.model.in_memory_registry import artefact_urn  # noqa: PLC0415

            urn = str(artefact_urn(hierarchy))
        return _InHierarchy(hierarchy_urn=urn, level_id=None)


code = _CodeAccessor()
"""Predicate accessor namespace — exposed at the top level as ``sl.code``."""


# ── CodeQuery ───────────────────────────────────────────────────────────


@attrs.frozen
class CodeQuery:
    """Lazy, composable query against a codelist.

    Construct via ``LazyCodelist.codes`` (or via the codelist-level
    helpers ``roots()``, ``narrower(id)``, …). Build up filters with
    ``.filter()``; cap with ``.limit()``; sort with ``.sort_by()``;
    materialise with ``.collect()``.

    Most introspection ops (``len``, ``__iter__``, ``__getitem__`` by id)
    auto-execute against DuckDB. ``.collect()`` is the canonical
    materialisation entry point and returns ``list[Code]``.
    """

    codelist_urn: str
    _conn: duckdb.DuckDBPyConnection = attrs.field(eq=False, repr=False, alias="conn")
    predicates: tuple[Predicate, ...] = ()
    sort_keys: tuple[_SortKey, ...] = ()
    limit_n: int | None = None
    annotation_types: tuple[str, ...] = ()  # () = no annotations loaded

    # ── Composition ─────────────────────────────────────────────────────

    def filter(self, predicate: Predicate) -> CodeQuery:
        """Return a new query with ``predicate`` AND-ed onto the chain."""
        return attrs.evolve(self, predicates=(*self.predicates, predicate))

    def sort_by(self, key: _Ref, *, ascending: bool = True) -> CodeQuery:
        """Add an ORDER BY key.

        Accepts the same field-accessor expressions as ``.filter()`` —
        e.g. ``sl.code.id``, ``sl.code.depth``, ``sl.code.parent_id``,
        ``sl.code.name["en"]``. Annotation fields are not supported as
        sort keys; filter the query first.
        """
        sk = _SortKey(field=key._field, ascending=ascending)  # noqa: SLF001
        return attrs.evolve(self, sort_keys=(*self.sort_keys, sk))

    def limit(self, n: int) -> CodeQuery:
        """Return a new query capped at ``n`` rows."""
        return attrs.evolve(self, limit_n=n)

    def with_annotations(self, *types: str) -> CodeQuery:
        """Return a new query that hydrates the listed annotation types on collect.

        By default ``.collect()`` returns ``Code`` objects with empty
        annotations — loading them eagerly is expensive on large
        codelists (one round-trip + ``Annotation`` per row). Pass the
        annotation types you actually need:

            cl.codes.with_annotations("geo_level").collect()

        Pass no types to clear; pass ``"*"`` (a single asterisk) to load
        every annotation type for matched codes.
        """
        return attrs.evolve(self, annotation_types=types)

    # ── Materialisation ─────────────────────────────────────────────────

    def collect(self) -> list[Code]:
        """Compile to SQL, execute, and return materialised ``Code`` objects.

        ``Code.name`` and ``Code.description`` carry the full
        ``InternationalString``; no language is selected here.

        Annotations are **not** loaded by default. Call
        ``.with_annotations(*types)`` first to hydrate the types you
        need — loading every annotation for every code adds a second
        SQL round-trip and per-row Python object construction that
        dominates on large codelists.
        """
        sql, params = _compile(self)
        rows = self._conn.execute(sql, params).fetchall()
        if not rows:
            return []
        if self.annotation_types:
            urns = [r[4] for r in rows]
            anns_by_urn = _fetch_annotations_for(self._conn, urns, types=self.annotation_types)
            return [_row_to_code(row, anns_by_urn.get(row[4], Annotations())) for row in rows]
        empty = Annotations()
        return [_row_to_code(row, empty) for row in rows]

    def ids(self) -> list[str]:
        """Compile to SQL, execute, and return just the code ids."""
        sql, params = _compile(self, select_clause="c.code_id")
        rows = self._conn.execute(sql, params).fetchall()
        return [r[0] for r in rows]

    def to_sql(self) -> tuple[str, list[object]]:
        """Compile to SQL without executing — for use as a subquery.

        Returns a SELECT that produces one ``code_id`` column. Callers
        splice the SQL inline (typically inside ``WHERE col IN (...)``)
        and concatenate the params with the outer query's binds, so a
        large hierarchy traversal becomes one parameterless-IN clause
        rather than thousands of bind parameters.

        Satisfies :class:`~sdmxlib.data_store.SqlRelation`.
        """
        return _compile(self, select_clause="c.code_id", omit_order=True)

    # ── Sequence-like access ────────────────────────────────────────────

    def __iter__(self) -> Iterator[Code]:
        return iter(self.collect())

    def __len__(self) -> int:
        sql, params = _compile(self, select_clause="COUNT(*)", omit_order=True)
        row = self._conn.execute(sql, params).fetchone()
        return row[0] if row else 0  # type: ignore[index]

    @overload
    def __getitem__(self, key: int) -> Code: ...

    @overload
    def __getitem__(self, key: str) -> Code: ...

    def __getitem__(self, key: int | str) -> Code:
        if isinstance(key, str):
            row = self._conn.execute(
                """
                SELECT c.code_id, c.parent_id, c.depth, c.name, c.code_urn, c.description
                FROM sdmx.code c
                WHERE c.codelist_urn = ? AND c.code_id = ?
                """,
                [self.codelist_urn, key],
            ).fetchone()
            if row is None:
                raise KeyError(key)
            return _row_to_code(row, self._anns_for_one(row[4]))

        offset = key if key >= 0 else len(self) + key
        row = self._conn.execute(
            """
            SELECT c.code_id, c.parent_id, c.depth, c.name, c.code_urn, c.description
            FROM sdmx.code c
            WHERE c.codelist_urn = ?
            ORDER BY c.position NULLS LAST, c.code_id
            LIMIT 1 OFFSET ?
            """,
            [self.codelist_urn, offset],
        ).fetchone()
        if row is None:
            raise IndexError(key)
        return _row_to_code(row, self._anns_for_one(row[4]))

    def _anns_for_one(self, code_urn: str) -> Annotations:
        """Return annotations for a single code, honouring ``annotation_types``.

        Single-code reads (``cl.codes["A"]``) are cheap enough that we
        load whichever types the query is configured for. Default
        ``annotation_types=()`` skips the round-trip entirely.
        """
        if not self.annotation_types:
            return Annotations()
        return _fetch_annotations_for(self._conn, [code_urn], types=self.annotation_types).get(
            code_urn,
            Annotations(),
        )

    def __contains__(self, key: object) -> bool:
        if isinstance(key, str):
            row = self._conn.execute(
                "SELECT 1 FROM sdmx.code WHERE codelist_urn = ? AND code_id = ?",
                [self.codelist_urn, key],
            ).fetchone()
            return row is not None
        if isinstance(key, Code):
            return key.id in self
        return False

    def get(self, code_id: str) -> Code | None:
        """Look up a code by id, returning ``None`` if absent."""
        try:
            return self[code_id]
        except KeyError:
            return None


# ── SQL compiler ────────────────────────────────────────────────────────

_DEFAULT_SELECT = "c.code_id, c.parent_id, c.depth, c.name, c.code_urn, c.description"


def _compile(
    query: CodeQuery,
    *,
    select_clause: str = _DEFAULT_SELECT,
    omit_order: bool = False,
) -> tuple[str, list[object]]:
    """Translate the predicate tree to a single ``sdmx.code`` query."""
    join_sqls: list[str] = []
    join_params: list[object] = []
    where_sqls: list[str] = ["c.codelist_urn = ?"]
    where_params: list[object] = [query.codelist_urn]
    annotation_join_aliases: dict[str, str] = {}

    for pred in query.predicates:
        clause, params = _emit_predicate(
            pred,
            join_sqls=join_sqls,
            join_params=join_params,
            annotation_join_aliases=annotation_join_aliases,
        )
        where_sqls.append(clause)
        where_params.extend(params)

    sql_parts = [f"SELECT {select_clause} FROM sdmx.code c"]
    if join_sqls:
        sql_parts.append(" ".join(join_sqls))
    sql_parts.append("WHERE " + " AND ".join(where_sqls))

    if not omit_order:
        order_sqls, order_params = _build_order_by(query.sort_keys)
        sql_parts.append("ORDER BY " + ", ".join(order_sqls))
    else:
        order_params = []

    if query.limit_n is not None:
        sql_parts.append(f"LIMIT {int(query.limit_n)}")

    sql = " ".join(sql_parts)
    return sql, [*join_params, *where_params, *order_params]


def _build_order_by(sort_keys: tuple[_SortKey, ...]) -> tuple[list[str], list[object]]:
    """Build ORDER BY fragments from caller-supplied keys plus the default tiebreak."""
    parts: list[str] = []
    params: list[object] = []
    for sk in sort_keys:
        frag, frag_params = _emit_sort_field(sk.field)
        parts.append(frag if sk.ascending else f"{frag} DESC")
        params.extend(frag_params)
    parts.append("c.position NULLS LAST")
    parts.append("c.code_id")
    return parts, params


def _emit_sort_field(field: _FieldExpr) -> tuple[str, list[object]]:
    if isinstance(field, _IdField):
        return "c.code_id", []
    if isinstance(field, _DepthField):
        return "c.depth", []
    if isinstance(field, _ParentIdField):
        return "c.parent_id", []
    if isinstance(field, _NameField):
        return "c.name[?]", [field.lang]
    msg = (
        f"Unsupported field for sort_by: {type(field).__name__}. "
        "Annotation-typed sort keys aren't supported; use a top-level "
        ".filter(...) instead."
    )
    raise NotImplementedError(msg)


def _emit_predicate(
    pred: Predicate,
    *,
    row_alias: str = "c",
    join_sqls: list[str],
    join_params: list[object],
    annotation_join_aliases: dict[str, str],
) -> tuple[str, list[object]]:
    if isinstance(pred, _Eq):
        return _emit_eq(
            pred,
            row_alias=row_alias,
            join_sqls=join_sqls,
            join_params=join_params,
            annotation_join_aliases=annotation_join_aliases,
        )
    if isinstance(pred, _StringMatch):
        return _emit_string_match(
            pred,
            row_alias=row_alias,
            join_sqls=join_sqls,
            join_params=join_params,
            annotation_join_aliases=annotation_join_aliases,
        )
    if isinstance(pred, _IsNull):
        return _emit_is_null(pred, row_alias=row_alias)
    if isinstance(pred, _HasAncestor):
        return _emit_has_ancestor(pred, row_alias=row_alias)
    if isinstance(pred, _IsAncestorOf):
        return _emit_is_ancestor_of(pred, row_alias=row_alias)
    if isinstance(pred, _HasNoNarrower):
        clause = f"""
            NOT EXISTS (
                SELECT 1 FROM sdmx.code child
                WHERE child.codelist_urn = {row_alias}.codelist_urn
                AND child.parent_id = {row_alias}.code_id
            )
        """
        return clause, []
    if isinstance(pred, _AnyAncestorMatches):
        return _emit_any_ancestor_matches(pred, row_alias=row_alias)
    if isinstance(pred, _AnyDescendantMatches):
        return _emit_any_descendant_matches(pred, row_alias=row_alias)
    if isinstance(pred, _InHierarchy):
        return _emit_in_hierarchy(pred, row_alias=row_alias)
    msg = f"Unsupported predicate kind: {type(pred).__name__}"
    raise NotImplementedError(msg)


def _emit_in_hierarchy(pred: _InHierarchy, *, row_alias: str) -> tuple[str, list[object]]:
    """Compile a Hierarchy/Level membership predicate to an EXISTS clause."""
    inner = f"{row_alias}_hn"
    if pred.level_id is None:
        clause = f"""
            EXISTS (
                SELECT 1 FROM sdmx.hierarchy_node {inner}
                WHERE {inner}.code_urn = {row_alias}.code_urn
                AND {inner}.hierarchy_urn = ?
            )
        """
        return clause, [pred.hierarchy_urn]
    clause = f"""
        EXISTS (
            SELECT 1 FROM sdmx.hierarchy_node {inner}
            WHERE {inner}.code_urn = {row_alias}.code_urn
            AND {inner}.hierarchy_urn = ?
            AND {inner}.level_id = ?
        )
    """
    return clause, [pred.hierarchy_urn, pred.level_id]


def _emit_eq(
    pred: _Eq,
    *,
    row_alias: str,
    join_sqls: list[str],
    join_params: list[object],
    annotation_join_aliases: dict[str, str],
) -> tuple[str, list[object]]:
    op = "!=" if pred.negate else "="
    field = pred.field
    if isinstance(field, _IdField):
        return f"{row_alias}.code_id {op} ?", [pred.value]
    if isinstance(field, _DepthField):
        return f"{row_alias}.depth {op} ?", [pred.value]
    if isinstance(field, _ParentIdField):
        return f"{row_alias}.parent_id {op} ?", [pred.value]
    if isinstance(field, _NameField):
        return f"{row_alias}.name[?] {op} ?", [field.lang, pred.value]
    if isinstance(field, _AnnotationField):
        alias = _ensure_annotation_join(
            field.type,
            row_alias=row_alias,
            join_sqls=join_sqls,
            join_params=join_params,
            annotation_join_aliases=annotation_join_aliases,
        )
        return f"{alias}.title {op} ?", [pred.value]
    msg = f"Unsupported field for ==/!=: {type(field).__name__}"
    raise NotImplementedError(msg)


def _emit_string_match(
    pred: _StringMatch,
    *,
    row_alias: str,
    join_sqls: list[str],
    join_params: list[object],
    annotation_join_aliases: dict[str, str],
) -> tuple[str, list[object]]:
    pattern = _ilike_pattern(pred.op, pred.value)
    field = pred.field
    if isinstance(field, _IdField):
        return f"{row_alias}.code_id ILIKE ?", [pattern]
    if isinstance(field, _ParentIdField):
        return f"{row_alias}.parent_id ILIKE ?", [pattern]
    if isinstance(field, _NameField):
        return f"{row_alias}.name[?] ILIKE ?", [field.lang, pattern]
    if isinstance(field, _AnnotationField):
        alias = _ensure_annotation_join(
            field.type,
            row_alias=row_alias,
            join_sqls=join_sqls,
            join_params=join_params,
            annotation_join_aliases=annotation_join_aliases,
        )
        return f"{alias}.title ILIKE ?", [pattern]
    msg = f"Unsupported field for string match: {type(field).__name__}"
    raise NotImplementedError(msg)


def _emit_is_null(pred: _IsNull, *, row_alias: str) -> tuple[str, list[object]]:
    op = "IS NOT NULL" if pred.negate else "IS NULL"
    field = pred.field
    if isinstance(field, _ParentIdField):
        return f"{row_alias}.parent_id {op}", []
    if isinstance(field, _IdField):
        return f"{row_alias}.code_id {op}", []
    msg = f"Unsupported field for is_null: {type(field).__name__}"
    raise NotImplementedError(msg)


def _emit_has_ancestor(pred: _HasAncestor, *, row_alias: str) -> tuple[str, list[object]]:
    if pred.max_absolute_depth is None:
        return f"? = ANY({row_alias}.ancestor_ids)", [pred.ancestor_id]
    return (
        f"? = ANY({row_alias}.ancestor_ids) AND {row_alias}.depth <= ?",
        [pred.ancestor_id, pred.max_absolute_depth],
    )


def _emit_is_ancestor_of(pred: _IsAncestorOf, *, row_alias: str) -> tuple[str, list[object]]:
    if pred.min_absolute_depth is None:
        clause = f"""
            {row_alias}.code_id IN (
                SELECT UNNEST(ancestor_ids) FROM sdmx.code
                WHERE codelist_urn = {row_alias}.codelist_urn AND code_id = ?
            )
        """
        return clause, [pred.descendant_id]
    clause = f"""
        {row_alias}.code_id IN (
            SELECT UNNEST(ancestor_ids) FROM sdmx.code
            WHERE codelist_urn = {row_alias}.codelist_urn AND code_id = ?
        )
        AND {row_alias}.depth >= ?
    """
    return clause, [pred.descendant_id, pred.min_absolute_depth]


def _emit_subquery_predicate(pred: Predicate, *, row_alias: str) -> tuple[str, list[object]]:
    """Compile a sub-predicate inside an EXISTS clause.

    Restricted to scalar fields (id, name, parent_id, depth). Annotation
    predicates would require an annotation join inside the EXISTS subquery,
    which the emitter doesn't support; raise NotImplementedError so the
    caller can rephrase as a top-level filter.
    """
    inner_joins: list[str] = []
    inner_join_params: list[object] = []
    inner_aliases: dict[str, str] = {}
    clause, params = _emit_predicate(
        pred,
        row_alias=row_alias,
        join_sqls=inner_joins,
        join_params=inner_join_params,
        annotation_join_aliases=inner_aliases,
    )
    if inner_joins:
        msg = (
            "Annotation predicates inside .any(...) sub-predicates aren't "
            "supported — they would require annotation joins inside the EXISTS "
            "subquery. Use a top-level .filter(...) instead."
        )
        raise NotImplementedError(msg)
    return clause, params


def _emit_any_ancestor_matches(
    pred: _AnyAncestorMatches,
    *,
    row_alias: str,
) -> tuple[str, list[object]]:
    inner_alias = f"{row_alias}_anc"
    sub_clause, sub_params = _emit_subquery_predicate(pred.sub_predicate, row_alias=inner_alias)
    clause = f"""
        EXISTS (
            SELECT 1 FROM sdmx.code {inner_alias}
            WHERE {inner_alias}.codelist_urn = {row_alias}.codelist_urn
            AND {inner_alias}.code_id = ANY({row_alias}.ancestor_ids)
            AND ({sub_clause})
        )
    """
    return clause, sub_params


def _emit_any_descendant_matches(
    pred: _AnyDescendantMatches,
    *,
    row_alias: str,
) -> tuple[str, list[object]]:
    inner_alias = f"{row_alias}_desc"
    sub_clause, sub_params = _emit_subquery_predicate(pred.sub_predicate, row_alias=inner_alias)
    clause = f"""
        EXISTS (
            SELECT 1 FROM sdmx.code {inner_alias}
            WHERE {inner_alias}.codelist_urn = {row_alias}.codelist_urn
            AND {row_alias}.code_id = ANY({inner_alias}.ancestor_ids)
            AND ({sub_clause})
        )
    """
    return clause, sub_params


def _ensure_annotation_join(
    annotation_type: str,
    *,
    row_alias: str,
    join_sqls: list[str],
    join_params: list[object],
    annotation_join_aliases: dict[str, str],
) -> str:
    """Add a JOIN against ``sdmx.annotation`` for ``annotation_type`` once."""
    cached = annotation_join_aliases.get(annotation_type)
    if cached is not None:
        return cached
    alias = f"a{len(annotation_join_aliases) + 1}"
    join_sqls.append(
        f"JOIN sdmx.annotation {alias} ON {alias}.owner_urn = {row_alias}.code_urn AND {alias}.annotation_type = ?"
    )
    join_params.append(annotation_type)
    annotation_join_aliases[annotation_type] = alias
    return alias


def _ilike_pattern(op: str, value: str) -> str:
    """Translate ``contains`` / ``starts_with`` / ``ends_with`` into ILIKE."""
    escaped = value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    if op == "contains":
        return f"%{escaped}%"
    if op == "starts_with":
        return f"{escaped}%"
    if op == "ends_with":
        return f"%{escaped}"
    msg = f"Unsupported string op: {op}"
    raise NotImplementedError(msg)


# ── Row → Code construction ─────────────────────────────────────────────


def _map_to_istring(m: dict[str, str] | None) -> InternationalString:
    if not m:
        return InternationalString()
    return InternationalString.of(m)


def _row_to_code(row: Sequence[Any], annotations: Annotations) -> Code:
    """Construct a Code from a CodeQuery result row.

    Row layout: ``(code_id, parent_id, depth, name_map, code_urn, description_map)``.
    """
    code_id, parent_id, _depth, name_map, _code_urn, desc_map = row
    return Code(
        id=str(code_id),
        parent_id=str(parent_id) if parent_id is not None else None,
        name=_map_to_istring(name_map),
        description=_map_to_istring(desc_map),
        annotations=annotations,
    )


def _fetch_annotations_for(
    conn: duckdb.DuckDBPyConnection,
    code_urns: list[str],
    *,
    types: tuple[str, ...] = ("*",),
) -> dict[str, Annotations]:
    """Bulk-load annotations + their text for many code URNs in two queries.

    ``types`` filters which annotation types to load. ``("*",)`` (default)
    loads every type. Pass an explicit tuple of types to project just
    those, e.g. ``types=("geo_level",)``.
    """
    if not code_urns:
        return {}
    placeholders = ", ".join("?" for _ in code_urns)
    sql_parts = [
        "SELECT id, owner_urn, annotation_id, title, annotation_type, url, ordinal",
        "FROM sdmx.annotation",
        f"WHERE owner_urn IN ({placeholders})",
    ]
    sql_params: list[object] = list(code_urns)
    if types and "*" not in types:
        type_placeholders = ", ".join("?" for _ in types)
        sql_parts.append(f"AND annotation_type IN ({type_placeholders})")
        sql_params.extend(types)
    sql_parts.append("ORDER BY owner_urn, ordinal")
    ann_rows = conn.execute(" ".join(sql_parts), sql_params).fetchall()
    if not ann_rows:
        return {}

    ann_ids = [r[0] for r in ann_rows]
    text_placeholders = ", ".join("?" for _ in ann_ids)
    text_rows = conn.execute(
        f"""
        SELECT annotation_id, lang, text
        FROM sdmx.annotation_text
        WHERE annotation_id IN ({text_placeholders})
        """,
        list(ann_ids),
    ).fetchall()
    text_by_ann: dict[Any, dict[str, str]] = {}
    for ann_id, lang, text in text_rows:
        text_by_ann.setdefault(ann_id, {})[lang] = text

    out: dict[str, list[Annotation]] = {}
    for db_id, owner_urn, ann_id, title, ann_type, url, _ord in ann_rows:
        text_map = text_by_ann.get(db_id)
        text = InternationalString.of(text_map) if text_map else InternationalString()
        out.setdefault(owner_urn, []).append(Annotation(id=ann_id, title=title, type=ann_type, url=url, text=text))
    return {urn: Annotations(anns) for urn, anns in out.items()}
