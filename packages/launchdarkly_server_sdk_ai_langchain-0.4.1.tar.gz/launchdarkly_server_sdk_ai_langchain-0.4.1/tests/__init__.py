"""Tests for LangChain provider."""
