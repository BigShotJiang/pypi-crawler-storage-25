"""REST-backed specialty tools: cable tracing and capacity queries."""

from typing import Annotated, Any

from pydantic import Field

from netbox_agent_mcp.services.registry import get_services


def netbox_trace_path(endpoint_type: str, endpoint_id: int) -> Any:
    """Trace the full cable path from a device endpoint.

    Returns every segment from the given port/interface through every cable,
    through-port, and patch to the far endpoint.

    Args:
        endpoint_type: One of ``"interfaces"``, ``"console-ports"``,
            ``"console-server-ports"``, ``"power-ports"``, ``"power-outlets"``,
            ``"power-feeds"``.
        endpoint_id: The endpoint's numeric ID.

    Returns:
        List of path segments (NetBox's native trace format).
    """
    svc = get_services()
    return svc.trace.trace(endpoint_type, endpoint_id)


def netbox_get_available(
    resource_type: str,
    parent_id: int,
    count: Annotated[int, Field(ge=1, le=1000)] = 1,
) -> Any:
    """Fetch free capacity from NetBox (IPs, prefixes, VLANs, ASNs).

    Args:
        resource_type: One of:

            - ``"prefix.available-ips"`` — IPs free within a prefix
            - ``"prefix.available-prefixes"`` — sub-prefixes free within a prefix
            - ``"ip-range.available-ips"`` — IPs free within an IP range
            - ``"vlan-group.available-vlans"`` — VLAN IDs free within a group
            - ``"asn-range.available-asns"`` — ASNs free within a range
        parent_id: Numeric ID of the parent object.
        count: How many items to return (1-1000, default 1).

    Returns:
        List of free resources; shape depends on resource_type.
    """
    svc = get_services()
    return svc.availability.get_available(resource_type, parent_id=parent_id, count=count)


def netbox_find_ip_references(ip: str) -> dict[str, Any]:
    """Locate an IP: every place NetBox might know about it, in one call.

    **Use this as the default when the user asks "where is this IP?" /
    "what owns this IP?" / "what site is this address in?"** The tool
    understands that NetBox can track an address at three different layers,
    and searches all three so the agent doesn't have to orchestrate them.

    Three layers, checked in order of authority:

    1. **Per-host IPAM record** — ``ipam.ipaddress`` with a structured
       ``assigned_object`` (interface / VM interface / FHRP group). The
       canonical home when it exists.
    2. **Containment** — ``ipam.prefix`` and ``ipam.ip-range`` records whose
       network range contains the address. **This is the key case to
       understand:** most NetBox deployments track subnets densely but host
       records sparsely. An IP that has "no record" often really lives inside
       a tracked prefix whose site and role locate the address exactly.
    3. **Free-text descriptions** — ``vpn.tunnel.description``,
       ``dcim.interface.description``, ``ipam.prefix.description``. Catches
       importers (e.g. Palo Alto → NetBox tunnel imports) that write peer IPs
       into description text rather than structured fields.

    Args:
        ip: IP address. With or without CIDR suffix (``"10.0.0.1"`` or
            ``"10.0.0.1/32"``). Masks are stripped before the containment and
            text searches; the per-host IPAM lookup tries both forms.

    Returns::

        {
          "query": "192.0.2.84",
          "ipam_record": null,                  # no per-host record
          "containing_prefixes": [              # ← the IP lives inside this
            {"id": 12345, "prefix": "192.0.2.80/28", "status": "active",
             "site": {"id": 31, "name": "site-a"},
             "role": {"id": 5, "name": "infrastructure"},
             "description": "Auto-added via discovery on router-edge-a"}
          ],
          "containing_ip_ranges": [],
          "text_references": {"vpn.tunnel": [], "dcim.interface": [], "ipam.prefix": []},
          "summary": {
            "ipam_record_exists": false,
            "ipam_assigned_to_object": false,
            "containing_prefix_count": 1,
            "containing_ip_range_count": 0,
            "text_reference_count": 0,
            "hint": "No per-host IPAM record, but the address is contained by
                     prefix `192.0.2.80/28` at site `site-a`. ..."
          }
        }

    Resolution priority for the agent:

    1. If ``ipam_record.assigned_object`` is set → that's the authoritative
       device. Report it.
    2. Else if ``containing_prefixes`` or ``containing_ip_ranges`` are
       non-empty → report the address as *located at* the containing
       record's site. Do NOT say "not found" — the IP is tracked, just not
       as a per-host record.
    3. Else if ``text_references`` has hits → inspect them (tunnel names
       often encode the owning device).
    4. Else the IP is genuinely untracked.

    A common failure mode to avoid: reporting "IP not found in NetBox" when
    ``containing_prefixes`` has entries. The containing prefix IS the find.
    """
    svc = get_services()
    return svc.ip_reference.find_references(ip)


def netbox_device_profile(
    device_id: int | None = None,
    device_ids: list[int] | None = None,
    include: list[str] | None = None,
    max_per_category: Annotated[int, Field(ge=0, le=1000)] = 100,
    fields: list[str] | None = None,
) -> dict[str, Any]:
    """Composite view of one OR many devices: record + related objects + hints.

    NetBox's device record doesn't include interfaces, IPs, tunnel terminations,
    cables, inventory items, etc. inline — those are many-to-one and require
    separate queries. This tool fans out to ~5 NetBox endpoints per device and
    returns one consolidated payload so agents don't orchestrate the dance
    manually.

    **Prefer the batch form** (`device_ids=[...]`) whenever you have more than
    one device to profile — e.g. right after `netbox_get('dcim.device',
    {'site_id': N})` returned a list, or after `netbox_aggregate_by_device`
    gave you top-N device IDs. Batching runs profiles in parallel (~5x faster
    than N sequential calls) and returns one response the agent reasons over.

    Args:
        device_id: Numeric NetBox device ID. Scalar form — returns one profile.
        device_ids: List of numeric NetBox device IDs (max 50 per call). Batch
            form — returns `{profiles: [...], meta: {...}}`. Provide exactly
            one of `device_id` / `device_ids`.
        include: Subset of categories to include. Default = ``["interfaces",
            "ip_addresses", "tunnel_terminations", "inventory_items"]``.
            Valid values:

            - ``"interfaces"``          (dcim.interface)
            - ``"ip_addresses"``        (ipam.ipaddress via the device)
            - ``"tunnel_terminations"`` (vpn.tunneltermination via the device's interfaces)
            - ``"cable_terminations"``  (dcim.cabletermination via the device's interfaces)
            - ``"inventory_items"``     (dcim.inventoryitem)
            - ``"console_ports"``       (dcim.consoleport)
            - ``"power_ports"``         (dcim.powerport)
            - ``"module_bays"``         (dcim.modulebay)

        max_per_category: Cap on items returned per category per device
            (default 100, max 1000). **Pass ``0`` for summary mode** — only
            counts + hints, no item bodies. Strongly recommended for batches
            of 5+ devices to keep the response payload manageable.
        fields: Optional list of field names to project onto the top-level
            ``device`` record AND every item in every section. When set, the
            response is slimmed to just these fields (plus ``id`` and
            ``display``, which are always kept as navigation anchors). Use
            dotted paths like ``"site.name"`` to descend into nested dicts.
            Unknown fields are silently skipped — they might just not exist
            on this particular record.

            This cuts prompt tokens dramatically for batched calls. Example:
            to build a "devices at this site" table with just name + role +
            status + primary mgmt IP, pass ``fields=["name", "role",
            "status", "primary_ip4"]`` (``management`` field is populated
            unconditionally and is already compact).

    Returns::

        {
          "device": {...full device record from NetBox...},
          "counts": {"interfaces": 173, "ip_addresses": 42,
                     "tunnel_terminations": 42, "inventory_items": 0},
          "sections": {
            "interfaces":          {"total": 173, "returned": 100, "truncated": true,
                                    "items": [{...brief interface...}, ...]},
            "ip_addresses":        {...},
            "tunnel_terminations": {...},
            "inventory_items":     {...}
          },
          "hints": [
            "Interface sample (first 100/173) dominant types: 100 virtual",
            "~172 interfaces are named 'tunnel.*' but only 42 have structural
             vpn.tunneltermination records — 130 'orphaned' tunnel interfaces
             (imported from firewall config but never linked to a vpn.tunnel
             object)."
          ]
        }

    For the batch form, the response is::

        {
          "profiles": [
            {"device_id": 5, "device": {...}, "counts": {...}, "sections": {...},
             "hints": [...], "management": [...]},
            {"device_id": 8, "device": {...}, ...},
            {"device_id": 13, "error": "failed to fetch device 13: ..."}
          ],
          "meta": {"requested": 3, "returned": 3, "failed": 1}
        }

    Order of profiles in the response preserves the `device_ids` input order.
    Per-device failures are isolated — one 500 on NetBox won't abort the batch;
    the failing device gets an `error` field and the rest return normally.

    Related items are returned in NetBox ``?brief=1`` shape (id, url, display,
    name + per-type essentials) to keep the payload manageable. Use
    ``netbox_get`` for full objects if you need more.
    """
    if (device_id is None) == (device_ids is None):
        raise ValueError(
            "Provide exactly one of `device_id` (scalar) or `device_ids` "
            "(list). Use the list form whenever you have more than one "
            "device — it runs profiles in parallel and saves N-1 tool calls."
        )

    svc = get_services()
    if device_ids is not None:
        return svc.device_profile.profile_batch(
            device_ids=device_ids,
            include=include,
            max_per_category=max_per_category,
            fields=fields,
        )
    if device_id is not None:
        return svc.device_profile.profile(
            device_id=device_id,
            include=include,
            max_per_category=max_per_category,
            fields=fields,
        )
    raise RuntimeError("unreachable: XOR validation above guarantees one is set")


def netbox_aggregate_by_device(
    relation: str,
    top_n: Annotated[int, Field(ge=0, le=1000)] = 10,
    filters: dict[str, Any] | None = None,
    max_scan: Annotated[int, Field(ge=100, le=100_000)] = 10_000,
) -> dict[str, Any]:
    """Server-side 'top N devices by X' aggregation.

    Use this for questions like "top 10 devices by VPN tunnel count", "top 5
    devices by interface count", "top 20 devices by IP address count". The
    tool scans the underlying junction (or direct) endpoint server-side,
    aggregates counts in process, and returns ONLY the top N — never ships
    1000s of raw rows across the MCP wire.

    Why not just use ``netbox_get_all`` and count client-side? Because for
    large NetBoxes the raw junction set can be 1000s of rows. Shipping that
    through the MCP transport risks truncation, blows your context window,
    and wastes tokens when you only need 10 aggregated counts.

    Args:
        relation: Which relationship to aggregate. One of:

            - ``"tunnel_terminations"``  — vpn.tunneltermination via dcim.interface.device
              (answers 'top N devices by VPN tunnel count')
            - ``"cable_terminations"``   — dcim.cabletermination via dcim.interface.device
              (answers 'top N devices by cable count')
            - ``"interfaces"``           — dcim.interface by device_id
              (answers 'top N devices by interface count')
            - ``"inventory_items"``      — dcim.inventoryitem by device_id
              (answers 'top N devices by inventory item count')
            - ``"ip_addresses"``         — ipam.ipaddress via interface.device
              (only addresses structurally assigned to an interface)

        top_n: How many device entries to return (default 10). Pass 0 to
            return all devices found.
        filters: Optional filters applied to the underlying endpoint BEFORE
            aggregation. Uses the same NetBox REST filter grammar as
            ``netbox_get`` (e.g. ``{"role_id": 3}`` to restrict to firewalls,
            or ``{"site_id__in": [8, 17]}`` to scope by site).
        max_scan: Safety cap on how many junction rows to scan (default 10000,
            max 100000). If exceeded, ``truncated: true`` in the response —
            narrow your filters.

    Returns::

        {
          "relation": "tunnel_terminations",
          "total_items_scanned": 3147,
          "truncated": false,
          "unique_devices": 87,
          "top_devices": [
            {"device": {"id": 5, "name": "router-b"}, "count": 42},
            {"device": {"id": 8, "name": "router-c"}, "count": 37},
            ...
          ]
        }
    """
    svc = get_services()
    return svc.device_aggregation.aggregate_by_device(
        relation=relation,
        top_n=top_n,
        filters=filters,
        max_scan=max_scan,
    )
