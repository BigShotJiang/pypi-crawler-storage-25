"""One-shot composite view of a device and its most relevant related objects.

NetBox's device record does not include its interfaces, IP addresses, tunnel
terminations, or inventory items inline — those are many-to-one relationships
that require separate queries. This service fans out and assembles a
single consolidated payload so agents don't orchestrate 5+ calls just to
answer "what's on this device?".

Related-list payloads use NetBox's ``?brief=1`` mode (id, url, display, name,
plus a few per-type fields) to keep total size manageable on devices with
hundreds of interfaces. Agents can drill into specific items with
``netbox_get`` afterwards for full shapes.
"""

import re
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from netbox_agent_mcp.clients.rest import RestClient

# Cap on a single batch call. Above this we force the caller to either
# shard their own batches or use the scalar path repeatedly. NetBox rate-limits
# and MCP response sizes both become problems well before this ceiling.
MAX_BATCH_DEVICE_IDS = 50

# Thread pool width for parallel fan-out. Each device profile itself makes
# ~5 REST calls, so the effective concurrency against NetBox is ~5x this.
# Keeping it conservative to avoid tripping rate limits.
BATCH_MAX_WORKERS = 5

# Fields that are ALWAYS kept in a projection, even if the caller omits them.
# `id` is the navigation anchor (needed for follow-up tool calls); `display`
# is NetBox's universal human-readable label.
_ALWAYS_KEEP = ("id", "display")


def _project(obj: Any, fields: list[str] | None) -> Any:
    """Slim a dict to the caller-requested fields (plus always-kept anchors).

    Recurses into lists and nested dicts, because agents will ask for things
    like `"site.name"` — those dotted paths need us to descend into `site`
    and project that sub-dict too. Non-dict values are returned untouched.

    `fields=None` means "no projection" — return as-is. Unknown field names
    are silently ignored (they might just not be present on this record,
    not necessarily a caller error).
    """
    if fields is None:
        return obj
    if isinstance(obj, list):
        return [_project(x, fields) for x in obj]
    if not isinstance(obj, dict):
        return obj

    top_keep: set[str] = set(_ALWAYS_KEEP)
    nested: dict[str, list[str]] = {}
    for path in fields:
        if not path:
            continue
        head, _, tail = path.partition(".")
        top_keep.add(head)
        if tail:
            nested.setdefault(head, []).append(tail)

    out: dict[str, Any] = {}
    for k, v in obj.items():
        if k not in top_keep:
            continue
        if k in nested:
            out[k] = _project(v, nested[k])
        else:
            out[k] = v
    return out


# Matches interface names that look like a management / out-of-band port.
# Examples we want to catch: "management", "mgmt0", "mgmt.1", "oob", "OOB-1",
# "out-of-band", "MGMT_ETH", "fxp0" (Juniper mgmt convention).
_MGMT_INTERFACE_PATTERN = re.compile(r"(?i)^(mgmt|management|oob|out[-_ ]?of[-_ ]?band|fxp\d+)")

DEFAULT_INCLUDE: list[str] = [
    "interfaces",
    "ip_addresses",
    "tunnel_terminations",
    "inventory_items",
]

VALID_INCLUDE: set[str] = {
    "interfaces",
    "ip_addresses",
    "tunnel_terminations",
    "cable_terminations",
    "inventory_items",
    "console_ports",
    "power_ports",
    "module_bays",
}


class DeviceProfileService:
    def __init__(self, rest: RestClient) -> None:
        self._rest = rest

    def profile_batch(
        self,
        device_ids: list[int],
        include: list[str] | None = None,
        max_per_category: int = 100,
        fields: list[str] | None = None,
    ) -> dict[str, Any]:
        """Profile N devices in parallel, returning one envelope.

        Per-device failures are captured as an ``error`` field on that
        device's profile; they do not abort the batch. Order of results
        preserves the caller's ID order.

        ``fields`` projects the top-level device record and every item in
        every section down to the requested fields. See ``profile`` for
        the full projection semantics.
        """
        if not device_ids:
            return {
                "profiles": [],
                "meta": {"requested": 0, "returned": 0, "failed": 0},
            }

        if len(device_ids) > MAX_BATCH_DEVICE_IDS:
            raise ValueError(
                f"device_ids length {len(device_ids)} exceeds cap "
                f"{MAX_BATCH_DEVICE_IDS}. Shard your batches or use the scalar "
                f"`device_id` form in a loop."
            )

        results: list[dict[str, Any]] = [{}] * len(device_ids)
        workers = min(BATCH_MAX_WORKERS, len(device_ids))
        with ThreadPoolExecutor(max_workers=workers) as pool:
            future_to_idx = {
                pool.submit(self._profile_safe, did, include, max_per_category, fields): i
                for i, did in enumerate(device_ids)
            }
            for fut in future_to_idx:
                idx = future_to_idx[fut]
                results[idx] = fut.result()

        failed = sum(1 for r in results if r.get("error"))
        return {
            "profiles": results,
            "meta": {
                "requested": len(device_ids),
                "returned": len(results),
                "failed": failed,
            },
        }

    def _profile_safe(
        self,
        device_id: int,
        include: list[str] | None,
        max_per_category: int,
        fields: list[str] | None,
    ) -> dict[str, Any]:
        """Wrap ``profile`` so one device's crash doesn't poison the batch.

        Always attaches ``device_id`` at the top level so agents can index
        the batch result without cross-referencing by position.
        """
        try:
            result = self.profile(
                device_id=device_id,
                include=include,
                max_per_category=max_per_category,
                fields=fields,
            )
            result["device_id"] = device_id
            return result
        except Exception as exc:
            return {"device_id": device_id, "error": str(exc)}

    def profile(
        self,
        device_id: int,
        include: list[str] | None = None,
        max_per_category: int = 100,
        fields: list[str] | None = None,
    ) -> dict[str, Any]:
        categories = self._resolve_include(include)

        # Top-level try: if ANYTHING below raises, we still return a
        # well-shaped response with an error payload instead of taking down
        # the MCP transport.
        try:
            device = self._rest.get(f"dcim/devices/{device_id}")
        except Exception as exc:
            return {
                "device": None,
                "counts": {},
                "sections": {},
                "management": [],
                "hints": [],
                "error": f"failed to fetch device {device_id}: {exc}",
            }

        sections: dict[str, dict[str, Any]] = {}
        section_errors: dict[str, str] = {}
        interfaces_full: list[dict[str, Any]] = []

        def _safe(section_name: str, fn) -> None:
            try:
                sections[section_name] = fn()
            except Exception as exc:
                sections[section_name] = {
                    "total": None,
                    "returned": 0,
                    "truncated": False,
                    "error": str(exc),
                    "items": [],
                }
                section_errors[section_name] = str(exc)

        if "interfaces" in categories:
            try:
                iface_section, interfaces_full = self._fetch_interfaces(device_id, max_per_category)
                sections["interfaces"] = iface_section
            except Exception as exc:
                sections["interfaces"] = {
                    "total": None,
                    "returned": 0,
                    "truncated": False,
                    "error": str(exc),
                    "items": [],
                }
                section_errors["interfaces"] = str(exc)
                interfaces_full = []

        if "ip_addresses" in categories:
            _safe("ip_addresses", lambda: self._fetch_ip_addresses(device_id, max_per_category))

        if "tunnel_terminations" in categories:
            _safe(
                "tunnel_terminations",
                lambda: self._fetch_tunnel_terminations(interfaces_full, max_per_category),
            )

        if "cable_terminations" in categories:
            _safe(
                "cable_terminations",
                lambda: self._fetch_cable_terminations(interfaces_full, max_per_category),
            )

        if "inventory_items" in categories:
            _safe(
                "inventory_items",
                lambda: self._fetch_section(
                    "dcim/inventory-items",
                    {"device_id": device_id},
                    max_per_category,
                ),
            )

        if "console_ports" in categories:
            _safe(
                "console_ports",
                lambda: self._fetch_section(
                    "dcim/console-ports",
                    {"device_id": device_id},
                    max_per_category,
                ),
            )

        if "power_ports" in categories:
            _safe(
                "power_ports",
                lambda: self._fetch_section(
                    "dcim/power-ports",
                    {"device_id": device_id},
                    max_per_category,
                ),
            )

        if "module_bays" in categories:
            _safe(
                "module_bays",
                lambda: self._fetch_section(
                    "dcim/module-bays",
                    {"device_id": device_id},
                    max_per_category,
                ),
            )

        # Management probe: caught at function boundary and returns [] on
        # error; no exception ever bubbles.
        management = self._fetch_management_info(device_id)

        counts = {k: v.get("total") for k, v in sections.items()}
        try:
            hints = _compute_hints(sections)
        except Exception as exc:
            hints = [f"hint computation failed: {exc}"]
        hints.extend(_format_management_hints(management))

        # Agent-controlled projection: slim the top-level device record AND
        # every item in every section. Leaves counts/hints/management/meta
        # alone — those are already compact and dropping fields there would
        # break their contract (e.g. hints are strings, counts are ints).
        if fields is not None:
            device = _project(device, fields)
            for sec in sections.values():
                if isinstance(sec, dict) and isinstance(sec.get("items"), list):
                    sec["items"] = [_project(item, fields) for item in sec["items"]]

        out: dict[str, Any] = {
            "device": device,
            "counts": counts,
            "sections": sections,
            "management": management,
            "hints": hints,
        }
        if section_errors:
            out["section_errors"] = section_errors
        return out

    def _fetch_management_info(self, device_id: int) -> list[dict[str, Any]]:
        """Always-on management interface probe.

        Queries only interfaces whose name starts with a management pattern,
        so we don't pay the cost of fetching every interface on a dense device
        just to filter client-side. Typical devices have ≤ 3 mgmt-named
        interfaces, so the probe is cheap (one small REST call + one IP
        lookup if any matches exist).

        Independent of `include` / `max_per_category` so the agent always
        sees the answer to "what is this device's mgmt IP" regardless of
        how the profile was invoked.
        """
        # NetBox REST repeats `name__isw=<prefix>` when passed a list, giving
        # an OR match across all prefixes in one request.
        try:
            iface_resp = self._rest.get(
                "dcim/interfaces",
                params={
                    "device_id": device_id,
                    "name__isw": ["mgmt", "management", "oob", "out-of-band", "fxp"],
                    "limit": 50,
                    "fields": "id,name,type",
                },
            )
        except Exception:
            return []
        iface_items = iface_resp.get("results") or []
        # Extra client-side safety net — re-apply the pattern in case NetBox's
        # case-insensitive semantics don't match our own.
        mgmt_ifaces = [
            i
            for i in iface_items
            if isinstance(i, dict)
            and i.get("name")
            and _MGMT_INTERFACE_PATTERN.match(str(i["name"]))
        ]
        if not mgmt_ifaces:
            return []

        mgmt_ids = [i["id"] for i in mgmt_ifaces if "id" in i]
        iface_to_ips: dict[int, list[dict[str, Any]]] = {iid: [] for iid in mgmt_ids}
        if mgmt_ids:
            try:
                ip_resp = self._rest.get(
                    "ipam/ip-addresses",
                    params={
                        "interface_id": mgmt_ids,
                        "limit": 50,
                        "fields": "id,address,description,assigned_object,dns_name",
                    },
                )
            except Exception:
                ip_resp = {"results": []}
            for ip in ip_resp.get("results") or []:
                if not isinstance(ip, dict):
                    continue
                assigned = ip.get("assigned_object") or {}
                aid = assigned.get("id") if isinstance(assigned, dict) else None
                if aid is not None and aid in iface_to_ips:
                    iface_to_ips[int(aid)].append(ip)

        return [
            {"interface": iface, "ips": iface_to_ips.get(iface.get("id"), [])}
            for iface in mgmt_ifaces
        ]

    def _resolve_include(self, include: list[str] | None) -> set[str]:
        if include is None:
            return set(DEFAULT_INCLUDE)
        invalid = [c for c in include if c not in VALID_INCLUDE]
        if invalid:
            valid = ", ".join(sorted(VALID_INCLUDE))
            raise ValueError(f"Unknown include category(s) {invalid}. Valid: {valid}")
        return set(include)

    def _fetch_section(
        self,
        endpoint: str,
        filters: dict[str, Any],
        max_per_category: int,
    ) -> dict[str, Any]:
        # max_per_category=0 → summary mode: ask NetBox for count only, return
        # an empty items list. Costs one tiny request but yields counts + hints.
        limit_param = 1 if max_per_category == 0 else max_per_category
        params = dict(filters)
        params["limit"] = limit_param
        params["brief"] = 1
        try:
            response = self._rest.get(endpoint, params=params)
        except Exception as exc:
            return {
                "total": None,
                "returned": 0,
                "truncated": False,
                "error": str(exc),
                "items": [],
            }
        items = response.get("results") or []
        total = response.get("count")
        total_int = int(total) if total is not None else len(items)
        if max_per_category == 0:
            return {
                "total": total_int,
                "returned": 0,
                "truncated": total_int > 0,
                "items": [],
            }
        return {
            "total": total_int,
            "returned": len(items),
            "truncated": total_int > len(items),
            "items": items,
        }

    def _fetch_ip_addresses(self, device_id: int, max_per_category: int) -> dict[str, Any]:
        """Fetch IPs with assigned_object hydrated so the management-interface
        hint can cross-reference interface.id → ip.address. Still compact —
        ~400-500 bytes per row vs brief's ~80, acceptable for typical device
        IP counts.
        """
        limit_param = 1 if max_per_category == 0 else max_per_category
        params = {
            "device_id": device_id,
            "limit": limit_param,
            "fields": "id,address,dns_name,description,assigned_object,status",
        }
        try:
            response = self._rest.get("ipam/ip-addresses", params=params)
        except Exception as exc:
            return {
                "total": None,
                "returned": 0,
                "truncated": False,
                "error": str(exc),
                "items": [],
            }
        items = response.get("results") or []
        total = response.get("count")
        total_int = int(total) if total is not None else len(items)
        if max_per_category == 0:
            return {
                "total": total_int,
                "returned": 0,
                "truncated": total_int > 0,
                "items": [],
            }
        return {
            "total": total_int,
            "returned": len(items),
            "truncated": total_int > len(items),
            "items": items,
        }

    def _fetch_interfaces(
        self, device_id: int, max_per_category: int
    ) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        """Interfaces in brief mode for the section payload, and a full-mode
        fetch (just id + type + name) for hint computation and for the
        tunnel-termination and cable-termination lookups that need interface
        IDs. Kept lightweight."""
        brief_section = self._fetch_section(
            "dcim/interfaces", {"device_id": device_id}, max_per_category
        )

        full_params: dict[str, Any] = {
            "device_id": device_id,
            "limit": 1000,  # generous for hint math
            "fields": "id,name,type,cable",
        }
        try:
            full_response = self._rest.get("dcim/interfaces", params=full_params)
            interfaces_full = full_response.get("results") or []
        except Exception:
            interfaces_full = []

        return brief_section, interfaces_full

    def _fetch_tunnel_terminations(
        self, interfaces_full: list[dict[str, Any]], max_per_category: int
    ) -> dict[str, Any]:
        interface_ids = [i["id"] for i in interfaces_full if "id" in i]
        if not interface_ids:
            return {"total": 0, "returned": 0, "truncated": False, "items": []}
        # NetBox's vpn/tunnel-terminations supports termination_type +
        # termination_id filters; pass the full id list via repeated params.
        params: dict[str, Any] = {
            "termination_type": "dcim.interface",
            "termination_id": interface_ids,
            "limit": max_per_category,
            "brief": 1,
        }
        try:
            response = self._rest.get("vpn/tunnel-terminations", params=params)
        except Exception as exc:
            return {
                "total": None,
                "returned": 0,
                "truncated": False,
                "error": str(exc),
                "items": [],
            }
        items = response.get("results") or []
        total = response.get("count")
        total_int = int(total) if total is not None else len(items)
        return {
            "total": total_int,
            "returned": len(items),
            "truncated": total_int > len(items),
            "items": items,
        }

    def _fetch_cable_terminations(
        self, interfaces_full: list[dict[str, Any]], max_per_category: int
    ) -> dict[str, Any]:
        interface_ids = [i["id"] for i in interfaces_full if "id" in i]
        if not interface_ids:
            return {"total": 0, "returned": 0, "truncated": False, "items": []}
        params: dict[str, Any] = {
            "termination_type": "dcim.interface",
            "termination_id": interface_ids,
            "limit": max_per_category,
            "brief": 1,
        }
        try:
            response = self._rest.get("dcim/cable-terminations", params=params)
        except Exception as exc:
            return {
                "total": None,
                "returned": 0,
                "truncated": False,
                "error": str(exc),
                "items": [],
            }
        items = response.get("results") or []
        total = response.get("count")
        total_int = int(total) if total is not None else len(items)
        return {
            "total": total_int,
            "returned": len(items),
            "truncated": total_int > len(items),
            "items": items,
        }


def _compute_hints(sections: dict[str, dict[str, Any]]) -> list[str]:
    """Client-side summaries that help agents answer 'what's interesting here?'
    without re-querying. Kept short and factual."""
    hints: list[str] = []

    iface = sections.get("interfaces")
    if iface and iface.get("items"):
        type_counts: dict[str, int] = {}
        for row in iface["items"]:
            t = _interface_type_label(row)
            type_counts[t] = type_counts.get(t, 0) + 1
        if type_counts:
            top = sorted(type_counts.items(), key=lambda x: -x[1])[:3]
            summary = ", ".join(f"{n} {t}" for t, n in top)
            hints.append(
                f"Interface sample (first {iface['returned']}/{iface['total']}) "
                f"dominant types: {summary}"
            )

    tt = sections.get("tunnel_terminations")
    if iface and tt and iface.get("total") is not None and tt.get("total") is not None:
        tunnel_iface_count = sum(
            1
            for r in iface.get("items", [])
            if isinstance(r, dict) and str(r.get("name", "")).startswith("tunnel.")
        )
        # Scale up the brief-mode sample to the full interface count when possible.
        if iface["returned"] and iface["total"] and tunnel_iface_count:
            est_tunnel_ifaces = round(tunnel_iface_count * iface["total"] / iface["returned"])
            gap = est_tunnel_ifaces - tt["total"]
            if gap > 0:
                hints.append(
                    f"~{est_tunnel_ifaces} interfaces are named 'tunnel.*' but only "
                    f"{tt['total']} have structural vpn.tunneltermination records — "
                    f"{gap} 'orphaned' tunnel interfaces (imported from firewall "
                    f"config but never linked to a vpn.tunnel object)."
                )

    return hints


def _format_management_hints(
    management: list[dict[str, Any]],
) -> list[str]:
    """Turn the always-on management probe into hint strings."""
    if not management:
        return []
    hints: list[str] = []
    for entry in management:
        iface = entry.get("interface") or {}
        ips = entry.get("ips") or []
        name = iface.get("name")
        iid = iface.get("id")
        if ips:
            for ip in ips:
                addr = ip.get("address", "unknown")
                desc = ip.get("description") or ""
                suffix = f" ('{desc}')" if desc else ""
                hints.append(f"Management interface: {name} (id={iid}) → IP {addr}{suffix}")
        else:
            hints.append(f"Management interface: {name} (id={iid}) — no IP assigned")
    return hints


def _interface_type_label(row: dict[str, Any]) -> str:
    t = row.get("type")
    if isinstance(t, dict):
        return str(t.get("value") or t.get("label") or "unknown")
    if isinstance(t, str):
        return t
    return "unknown"
