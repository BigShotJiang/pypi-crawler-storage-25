"""Locate an IP address across every place NetBox might know about it.

NetBox tracks IP-to-device relationships in multiple layers:

1. **Structured IPAM record** — ``ipam.ipaddress`` with a polymorphic
   ``assigned_object`` FK (``dcim.interface``, ``virtualization.vminterface``,
   or ``ipam.fhrpgroup``). The canonical home.
2. **Containment** — ``ipam.prefix`` and ``ipam.ip-range`` can _contain_ an
   address without there being a per-host IPAM record. Many NetBox
   deployments only track prefixes and leave host records to auto-discovery;
   a "missing" IP is often really inside a tracked subnet whose site and
   owning device are known.
3. **Free-text** — descriptions on ``vpn.tunnel``, ``dcim.interface``, and
   ``ipam.prefix``. Common when importers (e.g., Palo Alto → NetBox tunnel
   imports) write peer IPs into descriptions rather than structured fields.

``IPReferenceService`` queries all three layers and returns a single
consolidated view so agents don't orchestrate five separate searches.
"""

import logging
from typing import Any

from netbox_agent_mcp.clients.rest import RestClient

logger = logging.getLogger(__name__)


def _strip_cidr(ip: str) -> str:
    """Return the host part of an IP, without any /mask suffix."""
    return ip.split("/", 1)[0]


class IPReferenceService:
    def __init__(self, rest: RestClient) -> None:
        self._rest = rest

    def find_references(self, ip: str) -> dict[str, Any]:
        host = _strip_cidr(ip)

        ipam_record = self._ipam_lookup(ip)
        containing_prefixes = self._containing("ipam/prefixes", host)
        containing_ip_ranges = self._containing("ipam/ip-ranges", host)
        tunnel_refs = self._text_search("vpn/tunnels", host)
        interface_refs = self._text_search("dcim/interfaces", host)
        prefix_desc_refs = self._text_search("ipam/prefixes", host)

        text_reference_count = len(tunnel_refs) + len(interface_refs) + len(prefix_desc_refs)
        ipam_assigned = bool(ipam_record and ipam_record.get("assigned_object_type"))

        summary: dict[str, Any] = {
            "ipam_record_exists": ipam_record is not None,
            "ipam_assigned_to_object": ipam_assigned,
            "containing_prefix_count": len(containing_prefixes),
            "containing_ip_range_count": len(containing_ip_ranges),
            "text_reference_count": text_reference_count,
        }
        summary["hint"] = self._hint(
            ipam_record=ipam_record,
            ipam_assigned=ipam_assigned,
            containing_prefixes=containing_prefixes,
            containing_ip_ranges=containing_ip_ranges,
            text_reference_count=text_reference_count,
        )

        return {
            "query": host,
            "ipam_record": ipam_record,
            "containing_prefixes": containing_prefixes,
            "containing_ip_ranges": containing_ip_ranges,
            "text_references": {
                "vpn.tunnel": tunnel_refs,
                "dcim.interface": interface_refs,
                "ipam.prefix": prefix_desc_refs,
            },
            "summary": summary,
        }

    def _ipam_lookup(self, ip: str) -> dict[str, Any] | None:
        """Look up the IP in ipam/ip-addresses. Try the input form first,
        then fall back to the bare host if the user included a /mask that
        doesn't exist as a stored record."""
        try:
            response = self._rest.get("ipam/ip-addresses", params={"address": ip, "limit": 1})
        except Exception:
            return None
        results = response.get("results") or []
        if results:
            return self._distill_ipam(results[0])

        host = _strip_cidr(ip)
        if host != ip:
            try:
                response = self._rest.get("ipam/ip-addresses", params={"address": host, "limit": 1})
            except Exception:
                return None
            results = response.get("results") or []
            if results:
                return self._distill_ipam(results[0])

        return None

    def _containing(self, endpoint: str, host: str) -> list[dict[str, Any]]:
        """Query NetBox's ``?contains=<ip>`` filter on prefixes and IP-ranges.

        Returns the list of enclosing records (usually small — a host IP is
        typically contained by a handful of prefixes across scope layers).
        Degrades gracefully if the endpoint 500s or the NetBox version
        doesn't support ``?contains=`` for this resource.
        """
        try:
            response = self._rest.get(endpoint, params={"contains": host, "limit": 20})
        except Exception as exc:
            logger.warning("%s ?contains=%s failed: %s", endpoint, host, exc)
            return []
        return [self._distill_container(r) for r in (response.get("results") or [])]

    def _distill_ipam(self, ip_record: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": ip_record.get("id"),
            "address": ip_record.get("address"),
            "display": ip_record.get("display"),
            "status": (ip_record.get("status") or {}).get("value"),
            "dns_name": ip_record.get("dns_name"),
            "description": ip_record.get("description"),
            "vrf": ip_record.get("vrf"),
            "tenant": ip_record.get("tenant"),
            "assigned_object_type": ip_record.get("assigned_object_type"),
            "assigned_object": ip_record.get("assigned_object"),
            "nat_inside": ip_record.get("nat_inside"),
            "nat_outside": ip_record.get("nat_outside"),
        }

    def _distill_container(self, record: dict[str, Any]) -> dict[str, Any]:
        """Slim a prefix or IP-range record to the fields that identify the
        location of the contained address."""
        site = record.get("site")
        role = record.get("role")
        vrf = record.get("vrf")
        tenant = record.get("tenant")
        return {
            "id": record.get("id"),
            "display": record.get("display"),
            "prefix": record.get("prefix"),
            "start_address": record.get("start_address"),
            "end_address": record.get("end_address"),
            "status": (record.get("status") or {}).get("value"),
            "description": record.get("description"),
            "site": {"id": site.get("id"), "name": site.get("name")}
            if isinstance(site, dict)
            else None,
            "role": {"id": role.get("id"), "name": role.get("name")}
            if isinstance(role, dict)
            else None,
            "vrf": {"id": vrf.get("id"), "name": vrf.get("name")}
            if isinstance(vrf, dict)
            else None,
            "tenant": {"id": tenant.get("id"), "name": tenant.get("name")}
            if isinstance(tenant, dict)
            else None,
            "url": record.get("url"),
        }

    def _text_search(self, endpoint: str, host: str) -> list[dict[str, Any]]:
        """Search `description` fields with case-insensitive contains."""
        try:
            response = self._rest.get(
                endpoint,
                params={"description__ic": host, "limit": 50},
            )
        except Exception:
            return []
        return [self._distill_ref(r) for r in (response.get("results") or [])]

    def _distill_ref(self, record: dict[str, Any]) -> dict[str, Any]:
        """Slim a NetBox record down to the fields an agent needs to identify
        the owning device without flooding tokens."""
        return {
            "id": record.get("id"),
            "display": record.get("display"),
            "name": record.get("name"),
            "description": record.get("description"),
            "device": (record.get("device") or {}).get("name")
            if isinstance(record.get("device"), dict)
            else None,
            "url": record.get("url"),
        }

    def _hint(
        self,
        *,
        ipam_record: dict[str, Any] | None,
        ipam_assigned: bool,
        containing_prefixes: list[dict[str, Any]],
        containing_ip_ranges: list[dict[str, Any]],
        text_reference_count: int,
    ) -> str:
        """Per-state instruction to the agent. The order matters: the most
        authoritative signal wins."""
        if ipam_assigned:
            return (
                "IPAM record is structurally assigned — follow "
                "`ipam_record.assigned_object` to the owning interface/VM/FHRP group."
            )

        prefix_summary = self._summarize_containers(containing_prefixes, kind="prefix")
        range_summary = self._summarize_containers(containing_ip_ranges, kind="IP range")

        if ipam_record and (containing_prefixes or containing_ip_ranges):
            return (
                "IPAM record exists but has no structural `assigned_object`. "
                f"The address is contained by {prefix_summary}"
                + (f" and {range_summary}" if containing_ip_ranges else "")
                + ". Use the containing record's `site` (and `description`) to "
                "locate the IP. If you need device-level context, filter "
                "`netbox_get('dcim.device', filters={'site_id': <site_id>})` "
                "to the prefix's site."
            )

        if ipam_record and text_reference_count > 0:
            return (
                "IPAM record exists but has no `assigned_object`. Free-text "
                "references were found — inspect `text_references` for "
                "tunnel/interface names that often encode the owning device."
            )

        if ipam_record:
            return (
                "IPAM record exists but has no `assigned_object`, no containing "
                "prefix/range, and no text references. The IP is registered in "
                "NetBox but not tied to anything — likely stale or placeholder."
            )

        if containing_prefixes or containing_ip_ranges:
            return (
                "No per-host IPAM record, but the address is contained by "
                f"{prefix_summary}"
                + (f" and {range_summary}" if containing_ip_ranges else "")
                + ". This is the common case when NetBox only tracks subnets, "
                "not every host. The IP's location is the containing record's "
                "`site`."
            )

        if text_reference_count > 0:
            return (
                "No IPAM record and no containing prefix/range, but text "
                "references were found (likely in tunnel/interface descriptions). "
                "Inspect those to find the referencing device(s)."
            )

        return (
            "No references to this IP found anywhere in NetBox — no IPAM "
            "record, no containing prefix or IP range, no text references. "
            "Likely not tracked at all, or a typo."
        )

    @staticmethod
    def _summarize_containers(records: list[dict[str, Any]], *, kind: str) -> str:
        if not records:
            return f"0 {kind}s"
        first = records[0]
        label = first.get("prefix") or first.get("display") or f"{kind} #{first.get('id')}"
        site_name = (first.get("site") or {}).get("name") if first.get("site") else None
        site_clause = f" at site `{site_name}`" if site_name else ""
        if len(records) == 1:
            return f"{kind} `{label}`{site_clause}"
        return f"{len(records)} {kind}s (e.g. `{label}`{site_clause})"
