# Changelog

## [0.1.5] — 2026-04-23

### Docs (agent-facing)

- **`netbox_get` filter grammar now documents the `"q"` free-text key.** Example: `netbox_get("dcim.site", {"q": "london"}, select=[...], ordering="-device_count")` — same `?q=` semantics as `netbox_search`, scoped to one type, with agent-chosen field projection and order-by. This is the efficient idiom for "find all [sites / devices / VLANs / circuits / racks] matching X" when the type is known.
- `netbox_search` docstring reworked to explicitly steer agents toward `netbox_get` when the type is known and richer columns are needed, and to keep `netbox_search` for type-unknown discovery and for responses where `suggested_filters` / per-type truncation signals matter.
- `SYSTEM_PROMPT.md` intent table updated with a dedicated row for scoped searches by type.

No code changes — this is pure prompt engineering. Agents running 0.1.4 with the old prompt already had this capability; 0.1.5 just makes them discover it reliably.

## [0.1.4] — 2026-04-23

### Added

- **`netbox_device_profile` now accepts a `fields=[...]` projection list** that slims the top-level `device` record and every item in every section down to just the requested fields (`id` + `display` are always kept as navigation anchors). Supports dotted paths like `"site.name"` for nested projection. Combined with batched `device_ids` + `max_per_category`, agents can now get N devices' worth of data with surgical token cost — e.g. for a "devices at site X" summary table, `fields=["name","role","status","primary_ip4.address"]` drops payload size by ~10x vs. the default brief shape.
- Docstring + `docs/SYSTEM_PROMPT.md` updated to instruct agents to always pass `fields` alongside `device_ids` for batched calls.

## [0.1.3] — 2026-04-23

### Added

- **`netbox_device_profile` now accepts a list of device IDs for batched, parallel profiling.** Call `netbox_device_profile(device_ids=[D1, D2, ...])` once instead of N sequential `device_id=Di` calls. Up to 50 devices per batch, fanned out across 5 parallel workers, with per-device failure isolation (one bad device doesn't abort the batch — it gets an `error` field in the response while the rest return normally). Response shape: `{profiles: [...], meta: {requested, returned, failed}}`; profile order preserves caller's `device_ids` order.
- Docstring + `docs/SYSTEM_PROMPT.md` updated to instruct agents to prefer the batch form whenever a list of devices is on hand (e.g., right after `netbox_get('dcim.device', ...)` or `netbox_aggregate_by_device`).

## [0.1.2] — 2026-04-23

### Fixed

- **Replaced real-world IP addresses, site codes, and device hostnames that had been copied verbatim from a user-provided debug trace into the 0.1.1 docstring + tests.** All now use RFC 5737 documentation addresses (`192.0.2.x`, `198.51.100.x`, `203.0.113.x`) and generic names (`site-a`, `site-b`, `router-edge-a`). **0.1.1 should be treated as recalled** — it contains placeholder but non-RFC-5737 data that resembles real infrastructure and should not be distributed.

## [0.1.1] — 2026-04-23 (YANKED)

### Fixed

- **`netbox_find_ip_references` now locates addresses inside tracked prefixes and IP ranges.** Previously the tool only checked per-host `ipam.ipaddress` records and free-text descriptions; agents reported "IP not found" for addresses that lived inside a known subnet (the common case in deployments that track prefixes densely but host records sparsely). The tool now also queries `ipam/prefixes?contains=<ip>` and `ipam/ip-ranges?contains=<ip>`, returns the enclosing records under `containing_prefixes` / `containing_ip_ranges` with site + role + description, and updates `summary.hint` to steer the agent at the containing record's site when there's no per-host match.
- Updated tool docstring and `docs/SYSTEM_PROMPT.md` to call out the multi-layer lookup and explicitly forbid "IP not found" answers before `containing_prefixes` has been read.

### Fixed

- **`netbox_find_ip_references` now locates addresses inside tracked prefixes and IP ranges.** Previously the tool only checked per-host `ipam.ipaddress` records and free-text descriptions; agents reported "IP not found" for addresses that lived inside a known subnet (the common case in deployments that track prefixes densely but host records sparsely). The tool now also queries `ipam/prefixes?contains=<ip>` and `ipam/ip-ranges?contains=<ip>`, returns the enclosing records under `containing_prefixes` / `containing_ip_ranges` with site + role + description, and updates `summary.hint` to steer the agent at the containing record's site when there's no per-host match.
- Updated tool docstring and `docs/SYSTEM_PROMPT.md` to call out the multi-layer lookup and explicitly forbid "IP not found" answers before `containing_prefixes` has been read.

### Docs

- MkDocs Material site auto-built + deployed to GitHub Pages at <https://magicboxlab-ai.github.io/netbox-agent-mcp/>. Adds `pyproject.toml` `[dependency-groups].docs`, `mkdocs.yml`, a landing page + thin wrappers for root-level docs, and `.github/workflows/pages.yml`. README now carries PyPI + Docs badges.

## [0.1.0] — 2026-04-22

First public release. Agentic MCP server for NetBox with ten read-only tools:
`netbox_search`, `netbox_get`, `netbox_get_all`, `netbox_aggregate_by_device`,
`netbox_device_profile`, `netbox_find_ip_references`, `netbox_trace_path`,
`netbox_get_available`, `netbox_inspect_type`, `netbox_query` (raw GraphQL).

### Docs

- Repo-level AI-assistant guide (git-ignored, personal-to-maintainer).
- `docs/DEVELOPMENT.md` consolidates design, implementation, testing, and extending in one developer guide.

### Repository hygiene

- Scrubbed realistic-looking hostnames and IPs from tests + one docstring (RFC 5737 addresses + generic `router-a` / `router-b` placeholders).
- `.pre-commit-config.yaml` (gitleaks + ruff + standard hooks) and `.gitleaks.toml` with an allowlist for synthetic `nbt_*` test tokens.
- `SECURITY.md` with a private vulnerability-reporting policy.
- `CONTRIBUTING.md` and `CODE_OF_CONDUCT.md` (Contributor Covenant v2.1 by reference).
- `.github/workflows/ci.yml` — ruff + pytest (3.11 / 3.12 / 3.13) + gitleaks on push + PR.
- `.github/workflows/publish.yml` — tag-triggered PyPI publish via trusted publishing (OIDC, no tokens).
- `.github/dependabot.yml` + `dependabot-auto-merge.yml` — weekly `uv` + `github-actions` updates, patch/minor auto-merged on green CI, majors flagged for manual review.
- Issue templates (bug / feature) and PR template.
- `pyproject.toml` `authors`, `urls`, `keywords`, and PyPI classifiers.
- README badges: CI, Python versions, license, pre-commit, Ruff.
- README install path leads with `uvx` and `uv tool install`; `git clone` moved to a **Development install** section.

### Code quality

- `__in` suffix-stripping filter translation centralized in `schema/filter_builder.filters_to_rest_params`; `QueryService` and `DeviceAggregationService` share it.
- Removed unreachable `last_exc` / `assert` dead code from `RestClient._request` and `GraphQLClient.query`.
- `server.main` closes the shared `httpx.Client` on shutdown; `build_services` returns `(registry, http)`.
- Deleted unreferenced GraphQL-first helpers: `schema/select_compiler.py` and the GraphQL portion of `schema/filter_builder.py` (`SUFFIX_MAP`, `build_filter_args`, support fns).
