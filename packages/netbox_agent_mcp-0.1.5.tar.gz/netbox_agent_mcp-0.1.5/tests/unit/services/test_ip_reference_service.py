from unittest.mock import MagicMock

from netbox_agent_mcp.services.ip_reference_service import IPReferenceService


def _make_rest(responses_by_endpoint: dict[str, dict]) -> MagicMock:
    rest = MagicMock()

    def get(endpoint: str, params=None):
        return responses_by_endpoint.get(endpoint, {"count": 0, "results": []})

    rest.get.side_effect = get
    return rest


def test_finds_structured_ipam_assignment():
    rest = _make_rest(
        {
            "ipam/ip-addresses": {
                "count": 1,
                "results": [
                    {
                        "id": 42,
                        "address": "10.0.0.1/24",
                        "display": "10.0.0.1/24",
                        "assigned_object_type": "dcim.interface",
                        "assigned_object": {"id": 9, "name": "eth0", "device": {"name": "r1"}},
                    }
                ],
            },
        }
    )
    svc = IPReferenceService(rest)
    result = svc.find_references("10.0.0.1/24")

    assert result["query"] == "10.0.0.1"
    assert result["ipam_record"]["id"] == 42
    assert result["ipam_record"]["assigned_object_type"] == "dcim.interface"
    assert result["summary"]["ipam_assigned_to_object"] is True
    assert "follow" in result["summary"]["hint"]


def test_surfaces_text_references_when_no_structured_assignment():
    """The 'Palo Alto tunnel import' case: IP exists in IPAM with no assignment,
    but tunnel descriptions reference it."""
    rest = _make_rest(
        {
            "ipam/ip-addresses": {
                "count": 1,
                "results": [
                    {
                        "id": 543,
                        "address": "198.51.100.1/32",
                        "display": "198.51.100.1/32",
                        "assigned_object_type": None,
                        "assigned_object": None,
                    }
                ],
            },
            "vpn/tunnels": {
                "count": 1,
                "results": [
                    {
                        "id": 77,
                        "display": "tunnel-demo :: router-a :: 198.51.100.1",
                        "name": "tunnel-demo :: router-a :: 198.51.100.1",
                        "description": "Imported from Palo Alto firewall router-a | Peer IP: 198.51.100.1",
                    }
                ],
            },
        }
    )
    svc = IPReferenceService(rest)
    result = svc.find_references("198.51.100.1")

    assert result["ipam_record"] is not None
    assert result["ipam_record"]["assigned_object_type"] is None
    assert result["summary"]["ipam_assigned_to_object"] is False
    assert result["summary"]["text_reference_count"] == 1
    assert len(result["text_references"]["vpn.tunnel"]) == 1
    tunnel = result["text_references"]["vpn.tunnel"][0]
    assert "router-a" in tunnel["name"]


def test_no_references_anywhere():
    rest = _make_rest({})  # all endpoints return empty
    svc = IPReferenceService(rest)
    result = svc.find_references("203.0.113.99")

    assert result["ipam_record"] is None
    assert result["summary"]["ipam_record_exists"] is False
    assert result["summary"]["containing_prefix_count"] == 0
    assert result["summary"]["containing_ip_range_count"] == 0
    assert result["summary"]["text_reference_count"] == 0
    assert "No references" in result["summary"]["hint"]


def test_containing_prefix_located_when_no_ipam_record():
    """REGRESSION: an IP with no per-host record but inside a tracked prefix
    should surface the containing prefix with its site — the address IS
    locatable. Previously the tool reported "not found" in this case."""
    rest = _make_rest(
        {
            "ipam/prefixes": {
                "count": 1,
                "results": [
                    {
                        "id": 12345,
                        "display": "192.0.2.80/28",
                        "prefix": "192.0.2.80/28",
                        "status": {"value": "active"},
                        "description": "Auto-added via discovery on router-edge-a",
                        "site": {"id": 31, "name": "site-a"},
                        "role": {"id": 5, "name": "infrastructure"},
                    }
                ],
            },
        }
    )
    result = IPReferenceService(rest).find_references("192.0.2.84")

    assert result["ipam_record"] is None
    assert len(result["containing_prefixes"]) == 1
    prefix = result["containing_prefixes"][0]
    assert prefix["prefix"] == "192.0.2.80/28"
    assert prefix["site"] == {"id": 31, "name": "site-a"}
    assert result["summary"]["containing_prefix_count"] == 1
    hint = result["summary"]["hint"]
    assert "192.0.2.80/28" in hint
    assert "site-a" in hint
    assert "not found" not in hint.lower()


def test_containing_prefix_uses_contains_filter():
    """Verify the request shape NetBox expects: ?contains=<host>."""
    captured = []

    def get(endpoint, params=None):
        captured.append((endpoint, dict(params or {})))
        return {"count": 0, "results": []}

    rest = MagicMock()
    rest.get.side_effect = get

    IPReferenceService(rest).find_references("192.0.2.84/32")

    prefix_calls = [c for c in captured if c[0] == "ipam/prefixes"]
    # One ?contains= call (containment) + one ?description__ic= call (text).
    contains_call = next(c for c in prefix_calls if "contains" in c[1])
    assert contains_call[1]["contains"] == "192.0.2.84"  # mask stripped

    range_calls = [c for c in captured if c[0] == "ipam/ip-ranges"]
    assert range_calls
    assert range_calls[0][1]["contains"] == "192.0.2.84"


def test_containing_ip_range_also_surfaced():
    rest = _make_rest(
        {
            "ipam/ip-ranges": {
                "count": 1,
                "results": [
                    {
                        "id": 42,
                        "display": "10.1.0.1-10.1.0.254",
                        "start_address": "10.1.0.1/24",
                        "end_address": "10.1.0.254/24",
                        "status": {"value": "active"},
                        "site": {"id": 7, "name": "dc-lax"},
                    }
                ],
            },
        }
    )
    result = IPReferenceService(rest).find_references("10.1.0.99")
    assert len(result["containing_ip_ranges"]) == 1
    assert result["containing_ip_ranges"][0]["start_address"] == "10.1.0.1/24"
    assert result["summary"]["containing_ip_range_count"] == 1
    assert "dc-lax" in result["summary"]["hint"]


def test_ipam_record_unassigned_but_contained_by_prefix():
    """Combined case: IP has a per-host record but no assigned_object, AND
    lives inside a tracked prefix. Hint should prioritize the containing
    prefix as the location signal."""
    rest = _make_rest(
        {
            "ipam/ip-addresses": {
                "count": 1,
                "results": [
                    {
                        "id": 99,
                        "address": "198.51.100.249/32",
                        "assigned_object_type": None,
                        "assigned_object": None,
                    }
                ],
            },
            "ipam/prefixes": {
                "count": 1,
                "results": [
                    {
                        "id": 127111,
                        "prefix": "198.51.100.248/29",
                        "status": {"value": "active"},
                        "site": {"id": 51, "name": "site-b"},
                    }
                ],
            },
        }
    )
    result = IPReferenceService(rest).find_references("198.51.100.249")
    assert result["ipam_record"] is not None
    assert result["summary"]["ipam_assigned_to_object"] is False
    assert result["summary"]["containing_prefix_count"] == 1
    hint = result["summary"]["hint"]
    assert "198.51.100.248/29" in hint
    assert "site-b" in hint


def test_falls_back_to_bare_host_when_masked_lookup_misses():
    """If user passes '10.0.0.1/32' but NetBox stores it as '10.0.0.1/24',
    retry with the bare host."""
    calls = {"n": 0}

    def get(endpoint, params=None):
        if endpoint == "ipam/ip-addresses":
            calls["n"] += 1
            if calls["n"] == 1:
                # First call with /32 returns nothing
                return {"count": 0, "results": []}
            # Second call with bare host finds it
            return {
                "count": 1,
                "results": [
                    {
                        "id": 99,
                        "address": "10.0.0.1/24",
                        "assigned_object_type": None,
                        "assigned_object": None,
                    }
                ],
            }
        return {"count": 0, "results": []}

    rest = MagicMock()
    rest.get.side_effect = get

    svc = IPReferenceService(rest)
    result = svc.find_references("10.0.0.1/32")
    assert result["ipam_record"] is not None
    assert result["ipam_record"]["id"] == 99
    assert calls["n"] == 2


def test_text_searches_use_description_ic():
    captured = []

    def get(endpoint, params=None):
        captured.append((endpoint, dict(params or {})))
        return {"count": 0, "results": []}

    rest = MagicMock()
    rest.get.side_effect = get

    IPReferenceService(rest).find_references("198.51.100.1")
    text_calls = [c for c in captured if "description__ic" in c[1]]
    # Three text searches: tunnels, interfaces, prefixes (description field).
    assert len(text_calls) == 3
    for endpoint, params in text_calls:
        assert params["description__ic"] == "198.51.100.1"
        assert endpoint in {"vpn/tunnels", "dcim/interfaces", "ipam/prefixes"}


def test_resilient_to_per_endpoint_failures():
    """If one endpoint errors, the rest should still return."""

    def get(endpoint, params=None):
        if endpoint == "vpn/tunnels":
            raise RuntimeError("simulated outage")
        if endpoint == "ipam/ip-addresses":
            return {
                "count": 1,
                "results": [{"id": 1, "address": "203.0.113.99/32", "assigned_object": None}],
            }
        return {"count": 0, "results": []}

    rest = MagicMock()
    rest.get.side_effect = get

    result = IPReferenceService(rest).find_references("203.0.113.99")
    assert result["ipam_record"]["id"] == 1
    assert result["text_references"]["vpn.tunnel"] == []  # failed gracefully
