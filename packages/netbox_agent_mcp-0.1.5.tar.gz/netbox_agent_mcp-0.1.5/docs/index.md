# NetBox Agent MCP

A read-only [Model Context Protocol](https://modelcontextprotocol.io/) server for [NetBox](https://netbox.dev/), designed for agentic LLM workflows.

[![PyPI](https://img.shields.io/pypi/v/netbox-agent-mcp)](https://pypi.org/project/netbox-agent-mcp/)
[![CI](https://github.com/magicboxlab-ai/netbox-agent-mcp/actions/workflows/ci.yml/badge.svg)](https://github.com/magicboxlab-ai/netbox-agent-mcp/actions/workflows/ci.yml)
[![Python](https://img.shields.io/badge/python-3.11%20%7C%203.12%20%7C%203.13-blue)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://github.com/magicboxlab-ai/netbox-agent-mcp/blob/main/LICENSE)

## Why this exists

The server is built around four patterns agents need most:

- **Deep relational queries** via dotted selection paths (`site.region.name`).
- **Pre-computed follow-up filters** in search and list responses — no hand-parsing IDs.
- **Live schema introspection** so agents don't guess at field names.
- **Hard-capped auto-pagination** — no "partial-result hallucinations."

## Quick start

```bash
# Zero install (always latest)
uvx netbox-agent-mcp

# Persistent install
uv tool install netbox-agent-mcp
```

Register with your MCP client (Claude Code example):

```bash
claude mcp add --transport stdio netbox \
  --env NETBOX_URL=https://netbox.example.com/ \
  --env NETBOX_TOKEN=<your-token> \
  -- uvx netbox-agent-mcp
```

Full install + client-configuration instructions are in the [README](https://github.com/magicboxlab-ai/netbox-agent-mcp#readme).

## Where to go next

<div class="grid cards" markdown>

-   :material-book-open-variant: **[Developer guide](DEVELOPMENT.md)**

    Design rationale, layer responsibilities, add-a-type / add-a-tool checklists, testing strategy, and extension procedures.

-   :material-robot-outline: **[Agent system prompt](SYSTEM_PROMPT.md)**

    Recommended system prompt for agents using this server — encodes the response-shape contract and intent routing.

-   :material-history: **[Changelog](changelog.md)**

    Release notes and version history.

-   :material-shield-check: **[Security](security.md)**

    How to report vulnerabilities privately, and what's in scope.

-   :material-handshake: **[Contributing](contributing.md)**

    Prerequisites, setup, workflow, and conventions for contributors.

-   :material-package-variant: **[PyPI](https://pypi.org/project/netbox-agent-mcp/)**

    All published versions, direct downloads, and release metadata.

</div>

## Ten read-only tools

| Intent | Tool |
|---|---|
| Free-text search across NetBox | `netbox_search` |
| Filtered list (bounded / exhaustive) | `netbox_get` / `netbox_get_all` |
| "Top N devices by X" structural aggregation | `netbox_aggregate_by_device` |
| Composite device view | `netbox_device_profile` |
| Cross-table IP fan-out (incl. free-text descriptions) | `netbox_find_ip_references` |
| Cable path tracing | `netbox_trace_path` |
| Free-capacity queries (IPs, prefixes, VLANs, ASNs) | `netbox_get_available` |
| Live schema introspection | `netbox_inspect_type` |
| Raw GraphQL escape hatch | `netbox_query` |

See the [README tool reference](https://github.com/magicboxlab-ai/netbox-agent-mcp#tools) for full argument shapes and worked examples. Tool docstrings are also visible to agents at runtime via MCP.

## Read-only by design

No create/update/delete tools. Writes are deliberately excluded to keep the attack surface minimal. Users who need writes call NetBox's REST or web UI directly.
