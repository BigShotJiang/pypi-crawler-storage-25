"""Semolina code generation engine."""
