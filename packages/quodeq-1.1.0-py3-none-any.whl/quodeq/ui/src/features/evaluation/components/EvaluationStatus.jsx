import LiveViolationsFeed from './LiveViolationsFeed.jsx';
import ScanProgress from './ScanProgress.jsx';
import CopyButton from '../../../components/CopyButton.jsx';
import { copyToClipboard } from '../../../utils/clipboard.js';
import { TermHeader } from '../../../components/terminal/index.js';
import JobStatStrip from './JobStatStrip.jsx';

const STATUS = { RUNNING: 'running', DONE: 'done', FAILED: 'failed', LOST: 'lost' };

function termNameForStatus(status) {
  if (status === STATUS.RUNNING) return 'evaluation_in_progress';
  if (status === STATUS.DONE)    return 'evaluation_complete';
  if (status === STATUS.FAILED)  return 'evaluation_failed';
  if (status === STATUS.LOST)    return 'evaluation_lost';
  return 'evaluation_cancelled';
}

function JobHeader({ job, projectLabel, onDismiss, onCancel }) {
  const isRunning = job.status === STATUS.RUNNING;
  const isDone = job.status === STATUS.DONE;
  return (
    <div className="evaluate-panel__top evaluate-panel__top--row">
      <TermHeader name={termNameForStatus(job.status)} sub={projectLabel || undefined} />
      <div className="evaluate-panel__top-actions">
        {isRunning && (
          <button type="button" className="term-btn term-btn--ghost" onClick={onCancel}>cancel</button>
        )}
        {!isRunning && isDone && (
          <button type="button" className="term-btn term-btn--primary" onClick={() => onDismiss('view')}>
            <span aria-hidden="true">▸</span> view results
          </button>
        )}
        {!isRunning && (
          <button type="button" className="term-btn term-btn--secondary" onClick={() => onDismiss('close')}>close</button>
        )}
      </div>
    </div>
  );
}

function JobIdLine({ jobId }) {
  return (
    <div className="evaluate-job-id-line">
      <span className="evaluate-job-id-line__label">job</span>
      <code>{jobId}</code>
      <CopyButton aria-label="Copy job ID" onClick={() => copyToClipboard(jobId)} />
    </div>
  );
}

export default function EvaluationStatus({ job, project, projectInfo, liveViolations = {}, onDismiss, onCancel, hasEvaluations }) {
  if (!job) return null;
  const projectLabel = projectInfo?.displayName || projectInfo?.name || project || null;

  return (
    <div className="panel evaluate-panel--terminal">
      <JobHeader job={job} projectLabel={projectLabel} onDismiss={onDismiss} onCancel={onCancel} />
      <JobStatStrip job={job} liveViolations={liveViolations} />
      <JobIdLine jobId={job.jobId} />
      <ScanProgress job={job} hasEvaluations={hasEvaluations} />
      <LiveViolationsFeed liveViolations={liveViolations} />
    </div>
  );
}
