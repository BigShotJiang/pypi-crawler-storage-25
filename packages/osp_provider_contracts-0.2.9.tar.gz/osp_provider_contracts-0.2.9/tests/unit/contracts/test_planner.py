import pytest

from osp_provider_contracts import validate_planner_result
from osp_provider_contracts.planner import PlanningDecision, PlanningState


def test_validate_planner_result_accepts_minimum_shape() -> None:
    validate_planner_result(
        {
            "normalized_request": {"name": "bucket-a"},
            "planning_state": PlanningState.COMPLETE,
            "decision": PlanningDecision.ALLOW,
            "gates": [],
            "violations": [],
        }
    )


def test_validate_planner_result_rejects_missing_keys() -> None:
    with pytest.raises(ValueError, match="missing required keys"):
        validate_planner_result({"normalized_request": {}})


def test_validate_planner_result_rejects_invalid_gate_reason() -> None:
    with pytest.raises(ValueError, match="gate_reason"):
        validate_planner_result(
            {
                "normalized_request": {"name": "bucket-a"},
                "planning_state": "complete",
                "decision": "approval",
                "gates": [{"gate_reason": "provider_approval_required"}],
                "violations": [],
            }
        )


def test_validate_planner_result_rejects_non_mapping_violation() -> None:
    with pytest.raises(ValueError, match="violations\\[0\\]"):
        validate_planner_result(
            {
                "normalized_request": {"name": "bucket-a"},
                "planning_state": "complete",
                "decision": "reject",
                "gates": [],
                "violations": ["bad"],
            }
        )
