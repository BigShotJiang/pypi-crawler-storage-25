from osp_provider_contracts import GateReason, gate_tags_for_reason, normalize_gate_reason


def test_normalize_gate_reason_maps_legacy_aliases() -> None:
    assert normalize_gate_reason("approval_required") is GateReason.EXCEPTION_REQUIRED
    assert normalize_gate_reason("authz_required") is GateReason.ACCESS_DENIED
    assert normalize_gate_reason("vlan_not_permitted") is GateReason.EXCEPTION_REQUIRED


def test_normalize_gate_reason_falls_back_to_exception_required() -> None:
    assert normalize_gate_reason("") is GateReason.EXCEPTION_REQUIRED
    assert normalize_gate_reason("unknown_future_value") is GateReason.EXCEPTION_REQUIRED


def test_gate_tags_for_reason_supports_canonical_and_legacy_inputs() -> None:
    assert gate_tags_for_reason(GateReason.ACCESS_DENIED) == ["access_denied", "permission", "acl"]
    assert gate_tags_for_reason("authz_required") == ["access_denied"]
