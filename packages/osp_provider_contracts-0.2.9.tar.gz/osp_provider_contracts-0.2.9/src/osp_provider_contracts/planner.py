"""Shared request-time planner result contract.

This module defines the minimum stable shape providers can use for request-time
planning results. It is intentionally narrower than any provider's internal
candidate model and is not the current execute/update wire format.

Contracts:
    - PlannerResult always includes normalized_request, planning_state,
      decision, gates, and violations.
    - planning_state is explicit so partial requests can be represented without
      pretending to be final allow decisions.
    - Gates reuse the shared approval vocabulary; violations reuse GateViolation.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from enum import StrEnum
from typing import Any, TypedDict

from .approval import GateReason, GateViolation


class PlanningState(StrEnum):
    """Whether the planner reached a final request-time evaluation."""

    COMPLETE = "complete"
    INCOMPLETE = "incomplete"


class PlanningDecision(StrEnum):
    """Planner outcome classification for a request."""

    ALLOW = "allow"
    APPROVAL = "approval"
    REJECT = "reject"


class PlannerGate(TypedDict, total=False):
    """Shared summary of one approval gate raised during planning."""

    gate_reason: GateReason
    message: str
    importance: int
    required_approvals: int
    tags: list[str]
    violations: list[GateViolation]


class PlannerResult(TypedDict):
    """Minimum shared request-time planner result shape."""

    normalized_request: dict[str, Any]
    planning_state: PlanningState
    decision: PlanningDecision
    gates: list[PlannerGate]
    violations: list[GateViolation]


def validate_planner_result(result: Mapping[str, Any]) -> None:
    """Validate the minimum shared planner result shape.

    This validator intentionally checks only the durable shared shape, not
    provider-local candidate details or preview transport semantics.
    """
    required = ("normalized_request", "planning_state", "decision", "gates", "violations")
    missing = [name for name in required if name not in result]
    if missing:
        raise ValueError(f"planner result missing required keys: {missing}")

    normalized_request = result["normalized_request"]
    if not isinstance(normalized_request, Mapping):
        raise ValueError("planner_result.normalized_request must be a mapping")

    planning_state = result["planning_state"]
    if planning_state not in {state.value for state in PlanningState}:
        raise ValueError("planner_result.planning_state must be 'complete' or 'incomplete'")

    decision = result["decision"]
    if decision not in {item.value for item in PlanningDecision}:
        raise ValueError("planner_result.decision must be 'allow', 'approval', or 'reject'")

    _validate_gates(result["gates"])
    _validate_violations(result["violations"], field_name="planner_result.violations")


def _validate_gates(gates: Any) -> None:
    if not isinstance(gates, Sequence) or isinstance(gates, (str, bytes)):
        raise ValueError("planner_result.gates must be a sequence")
    valid_gate_reasons = {reason.value for reason in GateReason}
    for index, gate in enumerate(gates):
        if not isinstance(gate, Mapping):
            raise ValueError(f"planner_result.gates[{index}] must be a mapping")
        gate_map = dict(gate)
        if "gate_reason" in gate_map and gate_map["gate_reason"] not in valid_gate_reasons:
            raise ValueError(f"planner_result.gates[{index}].gate_reason is invalid")
        if "message" in gate_map and not isinstance(gate_map["message"], str):
            raise ValueError(f"planner_result.gates[{index}].message must be a string")
        if "importance" in gate_map and not isinstance(gate_map["importance"], int):
            raise ValueError(f"planner_result.gates[{index}].importance must be an int")
        if "required_approvals" in gate_map and not isinstance(gate_map["required_approvals"], int):
            raise ValueError(f"planner_result.gates[{index}].required_approvals must be an int")
        if "tags" in gate_map:
            tags = gate_map["tags"]
            if (
                not isinstance(tags, Sequence)
                or isinstance(tags, (str, bytes))
                or any(not isinstance(tag, str) for tag in tags)
            ):
                raise ValueError(
                    f"planner_result.gates[{index}].tags must be a sequence of strings"
                )
        if "violations" in gate_map:
            _validate_violations(
                gate_map["violations"],
                field_name=f"planner_result.gates[{index}].violations",
            )


def _validate_violations(violations: Any, *, field_name: str) -> None:
    if not isinstance(violations, Sequence) or isinstance(violations, (str, bytes)):
        raise ValueError(f"{field_name} must be a sequence")
    for index, violation in enumerate(violations):
        if not isinstance(violation, Mapping):
            raise ValueError(f"{field_name}[{index}] must be a mapping")
