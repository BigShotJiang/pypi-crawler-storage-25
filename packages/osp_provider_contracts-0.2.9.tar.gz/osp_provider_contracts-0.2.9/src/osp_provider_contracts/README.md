# Package Structure

This document outlines the osp-provider-contracts module layout, invariants, and design constraints to keep the provider-orchestrator interface stable, explicit, and free of surprises.

## Audience

Maintainers and contributors working on contract-level API and wire compatibility.

## TL;DR (Critical Invariants)

- The package-root exports are the public contract; changes there are compatibility-sensitive.
- `GateReason` string values are wire format and must remain stable once released.
- Error `code`/`retryable` semantics are behavioral contract with orchestrator retry logic.
- `build_idempotency_key()` inputs and hashing behavior must stay deterministic.
- `assert_provider_conforms()` checks structure only; runtime behavior must be tested elsewhere.

## Quick Start

- **`__init__.py`**: Public re-export surface for core contracts.
  Import specialized test helpers from `conformance/`.
- **`types.py`**: Core frozen dataclasses (`RequestContext`, `ProviderRequest`, `ProviderResult`)
- **`protocol.py`**: `Provider` runtime-checkable protocol (`capabilities`, `execute`)
- **`errors.py`**: Canonical error taxonomy (`ProviderError` hierarchy with retry metadata)
- **`approval.py`**: Approval gate types (`GateReason`, `ApprovalRequiredExtra`, `ApprovalDetails`, ...)
- **`planner.py`**: Minimum shared planner result types (`PlannerResult`, `PlannerGate`,
  `PlanningState`, `PlanningDecision`, `validate_planner_result()`)
- **`provider_updates.py`**: Shared provider update envelope contract (`ProviderUpdateEnvelope`,
  `ProviderTaskEvent`, build/parse helpers)
- **`capabilities.py`**: `validate_capabilities()` — schema validation for capabilities documents
- **`idempotency.py`**: `build_idempotency_key()` — deterministic SHA256 deduplication key
- **`conformance/`**: `assert_provider_conforms()` — smoke-test assertion for provider test suites

## Architecture Principles

- **No external dependencies**: stdlib only (Python 3.13+). Safe to vendor; no transitive risk.
- **Immutable types**: `RequestContext`, `ProviderRequest`, `ProviderResult` are frozen dataclasses. Concurrent access is safe without locks.
- **Stable public surface**: Core contracts are re-exported from `__init__.py`.
  Import those from package root. Keep direct submodule imports for specialized
  modules like `conformance` only.
- **Explicit error taxonomy**: every error class has a fixed `code` and `retryable` flag. The orchestrator relies on these to decide retry vs. immediate failure.
- **Structured gate payloads**: approval-required flows use typed dicts so the orchestrator can route and render them without provider-specific knowledge.
- **Planner result is request-time only**: `PlannerResult` is a shared planning
  schema, not the current execute/update wire format.

## Compatibility Caveats

- `GateReason` string values are wire-format contract. Do not rename.
- Error `code` and `retryable` values are behavioral contract with orchestrator.
- Keep `__init__.py` exports stable unless making an intentional breaking change.
- Treat `build_idempotency_key()` input tuple/hash format as compatibility-sensitive.

**Import rules (inner → outer):**

- `types.py` — no intra-package imports (base types, nothing depends on)
- `errors.py` — no intra-package imports
- `approval.py` — no intra-package imports
- `planner.py` — imports `approval` only
- `capabilities.py` — no intra-package imports
- `idempotency.py` — imports `types` only
- `protocol.py` — imports `types` only
- `conformance/assertions.py` — imports `capabilities` only

```
types  ←  protocol
types  ←  idempotency
approval  ←  planner
capabilities  ←  conformance/assertions
```

---

## Layer Guides

### `types.py` (Core Request/Result Types)

**Purpose:** Frozen dataclasses defining what the orchestrator passes into
`execute()` and what the provider returns. The base layer everything else
builds on.

**Contains:**
- `RequestContext` — orchestrator-provided metadata per call: `task_id` (stable across retries), `request_id` (unique per attempt), optional `actor` and `metadata`. Do not mutate; use for logging and key generation.
- `ProviderRequest` — action request: `action`, `resource_kind`, `payload` (action-specific dict). Providers validate `payload` internally against their declared capabilities.
- `ProviderResult` — execution result: `success`, optional `external_id` (stored by orchestrator for future operations), `message`, `data`. Use `success=False` for idempotent no-ops rather than raising.

**Design Rules:**
- All three types are `frozen=True, slots=True`. Do not add mutable fields.
- `payload` and `data` are `Mapping[str, Any]` — read-only at the type level.
- `external_id` must be a stable provider-assigned identifier (e.g. VM UUID, instance ID). The orchestrator stores it and passes it back for update/delete operations.

**Avoids:** RabbitMQ, orchestrator internals, provider-specific logic.

---

### `protocol.py` (Provider Protocol)

**Purpose:** Define the two-method interface every OSP provider must implement.
Kept in one place so there is exactly one definition to audit and update.

**Contains:**
- `Provider` — `@runtime_checkable` Protocol with `capabilities()` and `execute(action, request, context)`.

**Design Rules:**
- `capabilities()` is called at startup and may be called later via RPC.
  Must return a stable mapping; avoid side effects and network calls.
- Capabilities are **advisory hints** for UI/CLI and can be stale. Providers
  must validate requests independently and reject invalid payloads even when
  capabilities claim a value is allowed.
- `execute()` is called concurrently for multiple tasks. Implementations must be thread-safe and idempotent (use `build_idempotency_key()`).
- `isinstance(obj, Provider)` works at runtime. Prefer `assert_provider_conforms(obj)` in tests — it also validates the capabilities document shape.

**Avoids:** Implementation details, transport knowledge, retry logic.

---

### `errors.py` (Error Taxonomy)

**Purpose:** Canonical, retryable-aware exception hierarchy. The orchestrator
reads `code` and `retryable` to route failures — retry with backoff, or move
the task to `FAILED` immediately.

**Contains:**

| Class | `code` | `retryable` | Use when |
|---|---|---|---|
| `ProviderError` | `provider_error` | No | Base class; always raise a subclass |
| `AuthError` | `auth_error` | No | Credentials invalid or expired |
| `NotFoundError` | `not_found` | No | Resource does not exist |
| `ConflictError` | `conflict` | No | Duplicate name, immutable field modified |
| `ValidationError` | `validation_error` | No | Bad payload, or approval required |
| `RateLimitError` | `rate_limited` | Yes | 429 / quota exceeded |
| `DependencyError` | `dependency_error` | Yes | Waiting on external state |
| `TransientError` | `transient_error` | Yes | Ephemeral network/API failure |

**Design Rules:**
- Always raise a specific subclass, never bare `ProviderError`.
- Approval gate: raise `ValidationError(detail="approval_required", extra=ApprovalRequiredExtra(...))`. The orchestrator detects this and moves the task to `WAITING_APPROVAL` instead of `FAILED`.
- `as_dict()` serializes the error for TaskEvent storage — include meaningful `detail` and `extra` for operator debugging.

**Avoids:** Transport details, retry scheduling, orchestrator internals.

---

### `approval.py` (Approval Gate Types)

**Purpose:** Typed structures for the approval-required error payload. The
orchestrator reads `gate_reason`, `importance`, and `required_approvals` to route
to the right approval authority and determine the quorum required.

**Contains:**
- `GateReason` — stable string enum. New reasons may be added; existing ones never change (wire format).
- `ApprovalRequiredExtra` — top-level `extra` dict for `ValidationError`. Required: `gate_reason`, `reason`. `importance` (1–5) sets a minimum quorum: 1 = 2 approvers, 2–5 = 1 approver. `required_approvals` can raise the quorum beyond importance defaults.
- `ApprovalDetails` — nested payload with `status_comment_lines` (rendered in UI) and `violations` (audit trail).
- `GateViolation` — single violation entry. `fingerprint` enables deduplication across gate evaluations.
- `ApprovalTargets` — optional routing hint (authority, groups, contacts).

**Gate reasons (stable strings):**

- `limits_exceeded` — capacity/quota exceeded but can be overridden
- `access_denied` — ACL/permission denied but can grant an exception
- `exception_required` — generic override required
- `destructive_action` — irreversible operation requiring explicit approval
- `resource_conflict` — resource locked/conflicting state requiring manual intervention

**Design Rules:**
- Providers must include at least `gate_reason` and `reason` in `ApprovalRequiredExtra`.
- `GateReason` values are stable strings — treat them as a versioned wire format.

**Avoids:** Orchestrator routing logic, approval UI rendering.

---

### `planner.py` (Minimum Shared Planner Result)

**Purpose:** Define the smallest durable request-time planning shape providers
can share without freezing a preview transport or a VMware-shaped candidate
framework.

**Contains:**
- `PlanningState` — `complete | incomplete`
- `PlanningDecision` — `allow | approval | reject`
- `PlannerGate` — gate summary using shared approval vocabulary
- `PlannerResult` — normalized request + planning state + decision + gates + violations
- `validate_planner_result(result)` — schema validation for local preview/planner tests

**Design Rules:**
- This is a request-time schema only.
- It is not the current `execute()` response contract.
- It does not define candidate or option-group transport yet.
- Providers can reuse `GateViolation` and `GateReason` instead of inventing a
  second approval vocabulary.

**Avoids:** Preview RPC design, provider-internal candidate scoring, transport
envelope changes.

---

### `capabilities.py` (Capabilities Validation)

**Purpose:** Validate the document a provider returns from `capabilities()`.
Called by the orchestrator on registration and by `assert_provider_conforms()`
in test suites.

**Contains:**
- `validate_capabilities(capabilities)` — raises `ValueError` on the first schema violation.

Required document shape:
```python
{
    "provider": "my-provider",    # non-empty str
    "version": "1.0.0",           # non-empty str
    "resources": [
        {"kind": "vm", "actions": ["create", "delete"]},
    ],
}
```

**Design Rules:**
- Fails fast on first violation — no partial validation result.
- Each resource must have at least one action (non-empty list of strings).

**Avoids:** Provider instantiation, `execute()` calls, network calls.

---

### `idempotency.py` (Idempotency Key Generation)

**Purpose:** Generate a stable, collision-resistant deduplication key to call
before any side-effecting API operation inside `execute()`.

**Contains:**
- `build_idempotency_key(*, context, action, resource_key) -> str` — 64-char SHA256 hex digest. Same inputs always produce the same key. Uses structured JSON encoding to avoid delimiter-collision ambiguities.

**Design Rules:**
- Call at the start of `execute()`, before the first external API call.
- `resource_key` must uniquely identify the resource within the action (hostname, UUID, etc.).
- Keys are globally unique across all tasks, requests, actions, and resource keys — same key from two different calls means the same logical operation.

**Avoids:** External state, network calls, side effects.

---

### `conformance/` (Conformance Assertions)

**Purpose:** Lightweight smoke-test assertions for provider test suites to
catch structural mismatches before integration. Not a pytest plugin.

**Contains:**
- `assert_provider_conforms(provider)` — checks callable methods, correct arity, valid capabilities document. Raises `AssertionError` with an actionable message on any violation.

**Design Rules:**
- No network calls, no side effects, no `execute()` calls.
- Does NOT check runtime behavior, idempotency, thread safety, or correct error handling — those need provider-specific tests.

**Avoids:** pika, orchestrator, runtime harness.

---

## Design Recipes

### Idempotent create

```python
def execute(self, action, request, context):
    key = build_idempotency_key(
        context=context, action=action,
        resource_key=request.payload["hostname"],
    )
    if self._store.exists(key):
        return ProviderResult(
            success=True,
            external_id=self._store.get(key),
            message="already exists (idempotent)",
        )
    result = self._api.create_vm(request.payload)
    self._store.set(key, result.id)
    return ProviderResult(success=True, external_id=result.id)
```

### Approval gate

```python
from osp_provider_contracts import (
    ApprovalDetails,
    ApprovalRequiredExtra,
    GateReason,
    ValidationError,
)

extra: ApprovalRequiredExtra = {
    "gate_reason": GateReason.EXCEPTION_REQUIRED,
    "importance": 2,
    "required_approvals": 2,
    "reason": "vlan_outside_policy",
    "details": ApprovalDetails(
        schema_version=2,
        status_comment_lines=["VLAN 42 is not in the permitted list."],
        violations=[{
            "layer": "network_policy",
            "message": "VLAN 42 not permitted",
            "reason_code": "vlan_not_permitted",
            "gate_reason": GateReason.EXCEPTION_REQUIRED,
            "importance": 2,
        }],
    ),
}
raise ValidationError("VLAN not permitted", detail="approval_required", extra=extra)
```

### Retryable vs. non-retryable errors

```python
try:
    self._api.create_vm(payload)
except ApiAuthExpired as e:
    raise AuthError("Token expired") from e        # non-retryable → task FAILED
except ApiRateLimit as e:
    raise RateLimitError("Quota exceeded") from e  # retryable → orchestrator retries
except ApiTimeout as e:
    raise TransientError("API timeout") from e     # retryable
```

---

## Common Issues

- **`validate_capabilities` raises on empty `actions`**: each resource entry requires a non-empty list of action strings.
- **`isinstance(obj, Provider)` returns `False`**: the object is missing `capabilities` or `execute` as callable attributes. Run `assert_provider_conforms(obj)` for a diagnostic message.
- **Approval gate not triggering**: `ValidationError` must have both `detail="approval_required"` and `extra["gate_reason"]` set to one of the known gate reasons. Both conditions are required.
- **Idempotency key collision**: `resource_key` must uniquely identify the resource — include the stable identifier (hostname, UUID), not just the action name.
- **`extra` not serializing**: pass a plain `dict` to `extra`; the runtime serializes it as JSON before publishing.

---

## Mini Cheat Sheet

- **Import anything?** Import core contracts from `osp_provider_contracts`.
  Import test helpers from `osp_provider_contracts.conformance`.
- **Implement a provider?** Implement `capabilities()` and `execute()`, then call `assert_provider_conforms(provider)` in tests.
- **Handle a retryable failure?** Raise `TransientError`, `RateLimitError`, or `DependencyError`.
- **Handle a permanent failure?** Raise `AuthError`, `NotFoundError`, `ConflictError`, or `ValidationError`.
- **Trigger approval flow?** Raise `ValidationError(detail="approval_required", extra=ApprovalRequiredExtra(...))`.
- **Deduplicate a side effect?** Call `build_idempotency_key()` before the external API call.
- **Validate a capabilities document?** Call `validate_capabilities(doc)` — raises `ValueError` on first violation.
