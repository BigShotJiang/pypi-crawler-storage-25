"""Approval gate protocol types with provider-agnostic gate reasons.

When a provider needs human approval before proceeding, it raises ValidationError
with detail="approval_required" and includes a structured extra payload conforming
to the types in this module. The orchestrator uses gate_reason plus quorum hints
to determine approval authority and required approvals.

Contracts:
    - GateReason values are stable strings.
    - ApprovalRequiredExtra.gate_reason controls approval routing.
    - importance sets a minimum quorum (1 => 2 approvers; 2-5 => 1 approver).
    - required_approvals can raise the quorum beyond importance/policy defaults.
    - ApprovalDetails.violations array contains provider-specific gate violation details.

Usage:
    Providers construct ApprovalRequiredExtra and raise ValidationError:

        extra = ApprovalRequiredExtra(
            gate_reason=GateReason.EXCEPTION_REQUIRED,
            importance=2,
            required_approvals=2,
            reason="vlan_outside_policy",
            details=ApprovalDetails(...),
        )
        raise ValidationError("VLAN not permitted", detail="approval_required", extra=extra)
"""

from __future__ import annotations

from enum import StrEnum
from typing import Any, Literal, TypedDict


class GateReason(StrEnum):
    """Provider-agnostic gate reason keys."""

    LIMITS_EXCEEDED = "limits_exceeded"
    ACCESS_DENIED = "access_denied"
    EXCEPTION_REQUIRED = "exception_required"
    DESTRUCTIVE_ACTION = "destructive_action"
    RESOURCE_CONFLICT = "resource_conflict"


_LEGACY_GATE_REASON_MAP: dict[str, GateReason] = {
    "approval_required": GateReason.EXCEPTION_REQUIRED,
    "provider_approval_required": GateReason.EXCEPTION_REQUIRED,
    "policy_exception_required": GateReason.EXCEPTION_REQUIRED,
    "placement_violation": GateReason.EXCEPTION_REQUIRED,
    "vlan_not_permitted": GateReason.EXCEPTION_REQUIRED,
    "authz_required": GateReason.ACCESS_DENIED,
}

_GATE_REASON_TAGS: dict[str, list[str]] = {
    GateReason.LIMITS_EXCEEDED.value: ["limits_exceeded", "capacity", "quota"],
    GateReason.ACCESS_DENIED.value: ["access_denied", "permission", "acl"],
    GateReason.EXCEPTION_REQUIRED.value: ["exception_required", "policy_exception"],
    GateReason.DESTRUCTIVE_ACTION.value: ["destructive_action", "irreversible", "delete"],
    GateReason.RESOURCE_CONFLICT.value: ["resource_conflict", "locked", "in_use"],
    "approval_required": ["exception_required"],
    "provider_approval_required": ["exception_required"],
    "policy_exception_required": ["exception_required"],
    "authz_required": ["access_denied"],
    "placement_violation": ["exception_required"],
}


def normalize_gate_reason(value: Any) -> GateReason:
    """Normalize canonical or legacy gate labels to the shared contract enum.

    Providers and orchestrator-facing helpers still encounter a few historical
    gate names while reading old policy or translating older error payloads.
    This helper owns that compatibility mapping so callers emit one stable
    gate vocabulary on the wire.
    """
    text = str(value or "").strip().lower()
    if not text:
        return GateReason.EXCEPTION_REQUIRED
    if text in _LEGACY_GATE_REASON_MAP:
        return _LEGACY_GATE_REASON_MAP[text]
    try:
        return GateReason(text)
    except ValueError:
        return GateReason.EXCEPTION_REQUIRED


def gate_tags_for_reason(value: Any) -> list[str]:
    """Return the default tag bundle associated with a gate reason.

    Tag derivation is part of the approval contract surface because UIs and
    automation may group or filter on these values. Legacy aliases resolve to
    the same tag bundle as their canonical reason.
    """
    text = str(value or "").strip().lower()
    if text in _GATE_REASON_TAGS:
        return list(_GATE_REASON_TAGS[text])
    return list(_GATE_REASON_TAGS[normalize_gate_reason(value).value])


CommentKind = Literal["planned", "requested", "effective", "comment"]
"""Category of status comment line for rendering approval details."""

ViolationKind = Literal[
    "access_denied",
    "limit_exceeded",
    "invalid_value",
    "missing_required",
    "policy_violation",
]
"""Small taxonomy for user-facing rendering of gate violations."""


class GateViolation(TypedDict, total=False):
    """Single gate violation detail for approval audit trail.

    Providers include violations in ApprovalDetails to explain why approval is needed.
    The canonical machine fields stay raw (`field`, `actual`, `expected_raw`) while
    optional display hints (`display_field`, `display_value`) help UIs render clearer
    copy without inventing provider semantics.
    """

    field: str
    actual: Any
    requested: Any
    expected: Any
    expected_raw: Any
    rule: str
    layer: str
    message: str
    hint: str
    kind: ViolationKind
    display_field: str
    display_value: str
    remediation: str
    reason: str
    reason_code: str
    gate_reason: GateReason
    importance: int
    fingerprint: str
    details: dict[str, Any]


class ApprovalTargets(TypedDict, total=False):
    """Routing hint for who should approve this gate.

    Providers may suggest authority (ORCHESTRATOR or PROVIDER), netgroups, or contacts.
    The orchestrator makes the final routing decision based on gate_reason.
    """

    authority: str
    groups: list[str]
    contacts: list[str]


class ApprovalDetails(TypedDict, total=False):
    """Structured payload for approval-required errors.

    This payload surfaces in the orchestrator UI and audit logs. status_comment_lines
    are rendered as human-readable text; violations provide structured audit data.
    """

    schema_version: int
    status_comment_lines: list[str]
    approval_targets: ApprovalTargets
    violations: list[GateViolation]
    violation_count_total: int
    truncated: bool


class ApprovalRequiredExtra(TypedDict, total=False):
    """Top-level extra payload for ValidationError with detail='approval_required'.

    The orchestrator reads gate_reason, importance, and required_approvals to determine
    approval authority and quorum. Providers must include at least gate_reason and reason.

    Fields:
        gate_reason: Preferred stable string reason key controlling approval routing.
        importance: Integer 1-5; importance 1 requires 2 approvers, 2-5 requires 1.
        required_approvals: Optional explicit quorum override (e.g., 2 for dual control).
        reason: Stable machine-readable reason string for filtering/reporting.
        reason_code: Optional legacy alias for reason.
        details: Structured payload with violations and status comments.
        progress_events: Optional provider-emitted progress updates for the UI.
    """

    gate_reason: GateReason
    importance: int
    required_approvals: int
    reason: str
    reason_code: str
    details: ApprovalDetails
    progress_events: list[dict[str, Any]]
