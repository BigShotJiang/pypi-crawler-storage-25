"""forgexa-cli — Forgexa command-line client."""
__version__ = "1.1.6"
