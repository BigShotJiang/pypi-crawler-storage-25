"""
RuntimeDaemon — standalone process that runs on the host machine.

Discovers locally installed Agent CLIs, registers with the API Server,
polls for tasks, executes them via CLI subprocesses, and reports results.

Usage:
    python -m app.daemon
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import platform
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import UUID

try:
    import httpx
except ImportError:
    # Auto-install httpx when running standalone (e.g., bundled with desktop app)
    subprocess.check_call(
        [sys.executable, "-m", "pip", "install", "--quiet", "httpx>=0.24"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
    )
    import httpx

# ── Settings: graceful fallback when running standalone (outside backend package) ──
try:
    from app.config import settings
except (ImportError, ModuleNotFoundError):
    # Running standalone (e.g., from desktop app bundle or forgexa-cli).
    # Provide a minimal settings object reading from environment variables.
    # Production default for end-user installs; server-side deployments
    # override via .env or systemd Environment= directives.
    _STANDALONE_DEFAULT_URL = "https://api.forgexa.net"

    class _StandaloneSettings:
        """Minimal settings shim for standalone daemon execution."""

        @property
        def DAEMON_ID(self) -> str:
            return os.environ.get("DAEMON_ID", "")

        @property
        def DAEMON_SERVER_URL(self) -> str:
            return os.environ.get("DAEMON_SERVER_URL", _STANDALONE_DEFAULT_URL)

        @property
        def DAEMON_SERVER_URLS(self) -> str:
            return os.environ.get("DAEMON_SERVER_URLS", "")

        @property
        def DAEMON_API_TOKEN(self) -> str:
            return os.environ.get("DAEMON_API_TOKEN", "")

        @property
        def DAEMON_POLL_INTERVAL(self) -> int:
            return int(os.environ.get("DAEMON_POLL_INTERVAL", "3"))

        @property
        def DAEMON_HEARTBEAT_INTERVAL(self) -> int:
            return int(os.environ.get("DAEMON_HEARTBEAT_INTERVAL", "15"))

        @property
        def DAEMON_MAX_CONCURRENT(self) -> int:
            return int(os.environ.get("DAEMON_MAX_CONCURRENT", "5"))

        @property
        def DAEMON_WORKSPACES_ROOT(self) -> str:
            return os.environ.get("DAEMON_WORKSPACES_ROOT", "")

        @property
        def AGENT_TIMEOUT(self) -> int:
            return int(os.environ.get("AGENT_TIMEOUT", "3600"))

        @property
        def AGENT_MAX_OUTPUT_SIZE(self) -> int:
            return int(os.environ.get("AGENT_MAX_OUTPUT_SIZE", "100000"))

        def get_daemon_workspaces_root(self) -> str:
            root = self.DAEMON_WORKSPACES_ROOT
            if not root:
                root = os.path.join(
                    os.environ.get("XDG_DATA_HOME", os.path.join(Path.home(), ".local", "share")),
                    "forgexa", "workspaces", "daemon",
                )
            return os.path.expanduser(root)

        def get_daemon_server_urls(self) -> list:
            if self.DAEMON_SERVER_URLS:
                return [u.strip() for u in self.DAEMON_SERVER_URLS.split(",") if u.strip()]
            return [self.DAEMON_SERVER_URL] if self.DAEMON_SERVER_URL else []

    settings = _StandaloneSettings()  # type: ignore[assignment]

# ── Logging — self-managed file handler ────────────────────────────────
# The daemon configures its own FileHandler so logs are written to
# ~/.forgexa/daemon/daemon.log regardless of how the daemon was launched
# (Makefile, Tauri desktop app, `forgexa daemon start --detach`, etc.).
# A StreamHandler is added only when stderr is a TTY (foreground mode)
# so logs are visible on the terminal without duplication.
_log_dir = Path.home() / ".forgexa" / "daemon"
_log_dir.mkdir(parents=True, exist_ok=True)
DAEMON_LOG_PATH = _log_dir / "daemon.log"

_log_handlers: list[logging.Handler] = [
    logging.FileHandler(DAEMON_LOG_PATH, mode="a", encoding="utf-8"),
]
if sys.stderr.isatty():
    _log_handlers.append(logging.StreamHandler(sys.stderr))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=_log_handlers,
)
logger = logging.getLogger("daemon")
logger.info("Daemon log: %s", DAEMON_LOG_PATH)


# ── Hardware ID — stable cross-IP machine fingerprint ──


def _get_machine_id() -> str | None:
    """Return OS-level stable machine identifier.

    Uses the established standard for each OS:
    - Linux/systemd:  /etc/machine-id  (UUID written at first boot, never changes)
    - macOS:          IOPlatformUUID   (from IOKit, tied to logic board)
    - Windows:        MachineGuid      (HKLM registry, set at OS install time)

    This is preferable to MAC address because:
    - Single authoritative value (no multi-NIC confusion)
    - Survives NIC replacement / USB adapter changes
    - Not randomized by OS privacy features (unlike WiFi MAC on modern systems)
    """
    # Linux & Docker
    for path in ["/etc/machine-id", "/var/lib/dbus/machine-id"]:
        try:
            content = Path(path).read_text().strip()
            if content and len(content) >= 16:
                return content
        except (OSError, IOError):
            pass

    # macOS — IOPlatformUUID via ioreg
    try:
        result = subprocess.run(
            ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
            capture_output=True, text=True, timeout=5,
        )
        match = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', result.stdout)
        if match:
            return match.group(1)
    except Exception:
        pass

    # Windows — MachineGuid from registry
    try:
        import winreg
        with winreg.OpenKey(  # type: ignore[attr-defined]
            winreg.HKEY_LOCAL_MACHINE,  # type: ignore[attr-defined]
            r"SOFTWARE\Microsoft\Cryptography",
        ) as key:
            value, _ = winreg.QueryValueEx(key, "MachineGuid")  # type: ignore[attr-defined]
            if value:
                return str(value)
    except Exception:
        pass

    return None


def _get_primary_mac() -> str | None:
    """Return MAC address of the primary non-virtual network interface.

    Used as a secondary fallback when machine-id is unavailable (e.g., minimal
    container environments). The MAC address is stable across IP changes on the
    same physical NIC, though it can change if the NIC is replaced.
    """
    try:
        import uuid as _uuid
        node = _uuid.getnode()
        # Bit 41 set = locally administered / randomly generated MAC — not reliable
        if node and not ((node >> 40) & 1):
            return ":".join(f"{(node >> (5 - i) * 8) & 0xff:02x}" for i in range(6))
    except Exception:
        pass
    return None


def get_hardware_id() -> str:
    """Generate a stable hardware fingerprint that survives IP changes and reboots.

    Strategy (in priority order):
    1. Machine-ID (most reliable — designed for exactly this purpose)
    2. Hashed combination of MAC address + hostname (fallback)
    3. Random UUID as last resort (provides uniqueness but no deduplication)

    The result is a 24-char hex string (SHA-256 truncated) that uniquely identifies
    the physical machine or OS installation across network changes.
    """
    machine_id = _get_machine_id()
    if machine_id:
        return hashlib.sha256(machine_id.encode()).hexdigest()[:24]

    # Fallback: MAC + hostname
    parts: list[str] = []
    mac = _get_primary_mac()
    if mac:
        parts.append(mac)
    parts.append(platform.node())
    if parts:
        return hashlib.sha256(":".join(parts).encode()).hexdigest()[:24]

    # Last resort: random (no deduplication benefit, but won't crash)
    import uuid
    return uuid.uuid4().hex[:24]


# ── Data Classes ──


@dataclass
class DiscoveredAgent:
    agent_id: str
    command: str
    version: str
    invoke_modes: list[str]
    compatibility_level: str


@dataclass
class TaskInfo:
    task_id: str
    graph_id: str
    node_type: str
    agent_type: str
    input_prompt: str
    input_data: dict
    timeout_seconds: int
    max_retries: int
    retry_count: int
    project: dict
    work_item: dict
    fallback_chain: list[str] = field(default_factory=list)
    requirement_workflow_id: str | None = None
    requirement_key: str | None = None
    graph_type: str = "execution"


@dataclass
class TaskResult:
    status: str  # success | failed | partial
    exit_code: int
    stdout: str
    stderr: str
    files_changed: list[str] = field(default_factory=list)
    lines_added: int = 0
    lines_removed: int = 0
    error: str = ""
    artifacts: list[dict] = field(default_factory=list)
    observations: list[dict] = field(default_factory=list)
    metrics: dict = field(default_factory=dict)
    git: dict = field(default_factory=dict)


# ── Agent Discovery ──


class AgentDiscovery:
    """Scans for locally installed Agent CLI tools."""

    AGENT_REGISTRY = {
        "claude-code": {
            "commands": ["claude"],
            "detect": "claude --version",
            "invoke_modes": ["print", "app-server"],
            "env_path_override": "FACTORY_CLAUDE_PATH",
            "env_model_override": "FACTORY_CLAUDE_MODEL",
            "compatibility_level": "L3",
        },
        "codex": {
            "commands": ["codex"],
            "detect": "codex --version",
            "invoke_modes": ["app-server"],
            "env_path_override": "FACTORY_CODEX_PATH",
            "env_model_override": "FACTORY_CODEX_MODEL",
            "compatibility_level": "L3",
        },
        "opencode": {
            "commands": ["opencode"],
            "detect": "opencode --version",
            "invoke_modes": ["cli"],
            "env_path_override": "FACTORY_OPENCODE_PATH",
            "env_model_override": "FACTORY_OPENCODE_MODEL",
            "compatibility_level": "L2",
        },
        "gemini": {
            "commands": ["gemini"],
            "detect": "gemini --version",
            "invoke_modes": ["cli"],
            "env_path_override": "FACTORY_GEMINI_PATH",
            "compatibility_level": "L1",
        },
        "kimi-code": {
            "commands": ["kimi"],
            "detect": "kimi --version",
            "invoke_modes": ["cli"],
            "env_path_override": "FACTORY_KIMI_PATH",
            "compatibility_level": "L2",
        },
        "hermes": {
            "commands": ["hermes"],
            "detect": "hermes --version",
            "invoke_modes": ["cli"],
            "env_path_override": "FACTORY_HERMES_PATH",
            "compatibility_level": "L1",
        },
    }

    @staticmethod
    def _expand_path():
        """Augment PATH with well-known agent CLI directories.

        GUI apps (macOS, Windows) and systemd services often have a
        minimal PATH that does not include user-installed CLI tools.
        We probe common installation directories for each platform so
        ``shutil.which`` can locate agent binaries.
        """
        home = Path.home()
        is_win = sys.platform == "win32"
        is_mac = sys.platform == "darwin"

        extra_dirs: list[Path] = []

        if is_win:
            # Windows: npm global, AppData installs, scoop, cargo, bun
            appdata = Path(os.environ.get("APPDATA", home / "AppData" / "Roaming"))
            localappdata = Path(os.environ.get("LOCALAPPDATA", home / "AppData" / "Local"))
            extra_dirs += [
                appdata / "npm",                         # npm -g installs
                localappdata / "Programs" / "Python" / "Scripts",
                home / ".opencode" / "bin",
                home / ".cargo" / "bin",
                home / ".bun" / "bin",
                home / "scoop" / "shims",                # scoop package manager
            ]
            # nvm-windows stores versions differently
            nvm_home = os.environ.get("NVM_HOME", "")
            if nvm_home:
                nvm_path = Path(nvm_home)
                nvm_symlink = os.environ.get("NVM_SYMLINK", "")
                if nvm_symlink:
                    extra_dirs.append(Path(nvm_symlink))
                elif nvm_path.is_dir():
                    versions = sorted(nvm_path.glob("v*/"), reverse=True)
                    if versions:
                        extra_dirs.append(versions[0])
        else:
            # macOS + Linux shared paths
            extra_dirs += [
                home / ".local" / "bin",         # pip / pipx installs, Claude Code
                home / ".opencode" / "bin",      # opencode
                home / ".cargo" / "bin",         # Rust / cargo installs
                home / ".bun" / "bin",           # bun
                home / ".volta" / "bin",         # volta (node version manager)
            ]
            if is_mac:
                # Homebrew Intel + Apple Silicon
                extra_dirs += [
                    Path("/usr/local/bin"),
                    Path("/opt/homebrew/bin"),
                ]
            # nvm (macOS + Linux)
            nvm_dir = os.environ.get("NVM_DIR", str(home / ".nvm"))
            nvm_path = Path(nvm_dir)
            if nvm_path.is_dir():
                versions = sorted(nvm_path.glob("versions/node/*/bin"), reverse=True)
                if versions:
                    extra_dirs.append(versions[0])

        current = os.environ.get("PATH", "")
        current_set = set(current.split(os.pathsep))
        additions = [str(d) for d in extra_dirs if d.is_dir() and str(d) not in current_set]
        if additions:
            os.environ["PATH"] = os.pathsep.join(additions) + os.pathsep + current
            logger.debug("Expanded PATH with: %s", ", ".join(additions))

    async def discover(self) -> list[DiscoveredAgent]:
        self._expand_path()
        available = []
        for agent_id, spec in self.AGENT_REGISTRY.items():
            custom_path = os.environ.get(spec.get("env_path_override", ""))
            cmd = custom_path or spec["commands"][0]
            resolved = shutil.which(cmd)
            if resolved:
                version = await self._get_version(spec["detect"])
                available.append(DiscoveredAgent(
                    agent_id=agent_id,
                    command=resolved,
                    version=version,
                    invoke_modes=spec["invoke_modes"],
                    compatibility_level=spec["compatibility_level"],
                ))
                logger.info("Discovered agent: %s v%s (%s)", agent_id, version, resolved)
        return available

    async def _get_version(self, detect_cmd: str) -> str:
        try:
            proc = await asyncio.create_subprocess_shell(
                detect_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=10)
            return stdout.decode().strip().split("\n")[0][:100]
        except Exception:
            return "unknown"


# ── Workspace Manager ──


class WorkspaceManager:
    """Manages isolated workspaces per task using git worktrees."""

    def __init__(self, root: str):
        self.root = Path(root).expanduser()
        self.root.mkdir(parents=True, exist_ok=True)
        self._ssh_keys: dict[str, str] = {}  # project_key -> PEM key content

    def set_ssh_key(self, project_key: str, ssh_private_key: str) -> None:
        """Register an SSH private key for a project."""
        self._ssh_keys[project_key] = ssh_private_key

    def _build_ssh_env(self, project_key: str) -> dict | None:
        """Build env dict with GIT_SSH_COMMAND if an SSH key is available."""
        key_content = self._ssh_keys.get(project_key)
        if not key_content:
            return None
        return key_content  # Return raw key content, _git will handle it

    async def prepare_workspace(self, project: dict, task: TaskInfo) -> Path:
        """Create or reuse a workspace for the given task.

        All nodes in the same execution graph share one workspace directory
        and git branch so that design→coding→testing→review can see each
        other's output files.
        """
        project_key = project.get("project_key", "default")
        repo_url = project.get("repo_url", "")
        default_branch = project.get("default_branch", "main")

        # Register SSH key if provided (per-project deploy key)
        ssh_key = project.get("ssh_private_key")
        if ssh_key:
            self.set_ssh_key(project_key, ssh_key)

        project_dir = self.root / project_key
        project_dir.mkdir(parents=True, exist_ok=True)

        # Use requirement_workflow_id as workspace key when available so that
        # analysis, execution, and fix graphs for the same requirement share
        # one directory and git worktree (C-2 / D-1 workspace reuse).
        # Fall back to graph_id for backward compatibility.
        if task.requirement_workflow_id:
            workspace_key = re.sub(r"[^a-zA-Z0-9_-]", "_", task.requirement_workflow_id)
        else:
            workspace_key = re.sub(r"[^a-zA-Z0-9_-]", "_", str(task.graph_id))

        # V5.4: Use human-readable branch name ai/{project_key}/{requirement_key}
        # when requirement_key is available; fallback to ai/{workspace_key}
        if task.requirement_key:
            branch_name = f"ai/{project_key}/{task.requirement_key}"
        else:
            branch_name = f"ai/{workspace_key}"

        # Determine whether this node is the "first" in a new graph that needs
        # a fresh base from the default branch.  Analysis nodes always start
        # fresh unless using "refine" mode which preserves the existing branch.
        analysis_mode = task.input_data.get("analysis_mode", "fresh")
        is_fresh_start = (
            task.node_type == "analysis"
            and analysis_mode != "refine"
        )

        if repo_url:
            ws_path = await self._create_worktree(
                project_dir, repo_url, default_branch, workspace_key, branch_name,
                fresh_start=is_fresh_start,
                project_key=project_key,
            )
            # Refine mode: ensure we're on the analysis branch with its history
            # (not reset to default_branch)
            if analysis_mode == "refine" and task.node_type == "analysis":
                try:
                    await self._git("fetch", "origin", cwd=ws_path, project_key=project_key)
                except RuntimeError:
                    pass
                try:
                    # Ensure we're on the correct branch
                    await self._git("checkout", branch_name, cwd=ws_path)
                except RuntimeError:
                    pass
                # Pull latest from remote branch if it exists (preserves prior commits)
                try:
                    await self._git(
                        "pull", "--ff-only", "origin", branch_name,
                        cwd=ws_path, project_key=project_key,
                    )
                except RuntimeError:
                    # Remote branch might not exist yet or has diverged; that's OK
                    pass
            return ws_path
        else:
            # No repo — create a directory with git init for change tracking
            ws_path = project_dir / workspace_key
            ws_path.mkdir(parents=True, exist_ok=True)
            # Init git if not already a repo so commits/branches work
            git_dir = ws_path / ".git"
            if not git_dir.exists():
                await self._git("init", cwd=ws_path)
                # Create initial commit so branches work
                readme = ws_path / "README.md"
                readme.write_text(f"# {project_key}\n\nInitialized by Forgexa.\n")
                await self._git("add", ".", cwd=ws_path)
                await self._git(
                    "-c", "user.name=Forgexa Agent",
                    "-c", "user.email=agent@forgexa.net",
                    "commit", "-m", "Initial commit",
                    cwd=ws_path,
                )
                # Create a working branch (V5.4: use human-readable name)
                await self._git("checkout", "-b", branch_name, cwd=ws_path)
            return ws_path

    async def _create_worktree(
        self, project_dir: Path, repo_url: str, default_branch: str,
        workspace_key: str, branch_name: str, *, fresh_start: bool = False,
        project_key: str = "default",
    ) -> Path:
        main_repo = project_dir / "_main"
        ws_path = project_dir / workspace_key

        if ws_path.exists():
            # Always fetch latest remote refs.
            try:
                await self._git("fetch", "origin", cwd=ws_path, project_key=project_key)
            except RuntimeError:
                pass

            if fresh_start:
                # This is the first node of a new graph (e.g. analysis).
                # Reset the worktree to the latest origin/default_branch so
                # that the AI works on up-to-date code.  Any previous AI
                # commits have already been pushed, so they are safe.
                logger.info("Fresh start: resetting %s to origin/%s", ws_path, default_branch)
                try:
                    await self._git("checkout", branch_name, cwd=ws_path)
                except RuntimeError:
                    pass  # Already on this branch
                try:
                    await self._git(
                        "reset", "--hard", f"origin/{default_branch}", cwd=ws_path,
                    )
                except RuntimeError as exc:
                    logger.warning("Failed to reset to origin/%s: %s", default_branch, exc)
            # For non-fresh-start (continuation nodes like coding→testing),
            # keep the working branch as-is so changes accumulate.
            return ws_path

        # Ensure _main repo is present and up-to-date
        if not main_repo.exists():
            await self._git("clone", repo_url, str(main_repo), timeout=600, project_key=project_key)
        else:
            await self._git("fetch", "--all", cwd=main_repo, timeout=300, project_key=project_key)

        # Fast-forward _main's local default branch to match origin so
        # that `git worktree add ... {default_branch}` uses latest code.
        # We fetch first, then update the local ref directly (avoids
        # needing to checkout default_branch which may conflict with worktrees).
        try:
            await self._git(
                "update-ref", f"refs/heads/{default_branch}",
                f"refs/remotes/origin/{default_branch}",
                cwd=main_repo,
            )
        except RuntimeError as exc:
            logger.warning("Could not fast-forward _main/%s: %s", default_branch, exc)

        # V5.4: branch_name is passed in (ai/{project_key}/{requirement_key} or ai/{workspace_key})
        # First check if the branch already exists on remote (for refine/continuation)
        branch_exists_remote = False
        try:
            check_proc = await asyncio.create_subprocess_exec(
                "git", "rev-parse", "--verify", f"refs/remotes/origin/{branch_name}",
                cwd=str(main_repo),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            await check_proc.communicate()
            branch_exists_remote = check_proc.returncode == 0
        except Exception:
            pass

        if branch_exists_remote and not fresh_start:
            # Branch exists on remote and we want to preserve it (refine mode)
            try:
                await self._git(
                    "worktree", "add", "--track", "-b", branch_name,
                    str(ws_path), f"origin/{branch_name}",
                    cwd=main_repo,
                )
            except Exception:
                try:
                    await self._git(
                        "worktree", "add", str(ws_path), branch_name,
                        cwd=main_repo,
                    )
                except Exception:
                    # Fallback: create from default_branch
                    try:
                        await self._git(
                            "worktree", "add", "-b", branch_name, str(ws_path), default_branch,
                            cwd=main_repo,
                        )
                    except Exception:
                        ws_path.mkdir(parents=True, exist_ok=True)
                        await self._git("clone", repo_url, str(ws_path), project_key=project_key)
        else:
            try:
                await self._git(
                    "worktree", "add", "-b", branch_name, str(ws_path), default_branch,
                    cwd=main_repo,
                )
            except Exception:
                # Branch might exist already
                try:
                    await self._git(
                        "worktree", "add", str(ws_path), branch_name,
                        cwd=main_repo,
                    )
                except Exception:
                    # Fallback to simple clone
                    ws_path.mkdir(parents=True, exist_ok=True)
                    await self._git("clone", repo_url, str(ws_path), project_key=project_key)

        return ws_path

    async def cleanup_workspace(self, workspace_path: Path):
        """Optional cleanup after task. For now, keep workspaces for debugging."""
        pass

    async def _git(self, *args: str, cwd: Path | str | None = None, timeout: int = 120,
                   project_key: str | None = None) -> str:
        """Run a git command safely using exec (no shell injection).

        If a project SSH key is registered, remote-touching commands
        (clone, fetch, pull, push) will use GIT_SSH_COMMAND.
        """
        env = None
        # Inject SSH key for commands that touch the remote
        remote_commands = {"clone", "fetch", "pull", "push"}
        if project_key and args and args[0] in remote_commands:
            key_content = self._ssh_keys.get(project_key)
            if key_content:
                import stat as stat_mod
                fd, key_path = tempfile.mkstemp(prefix="forgexa_ssh_", suffix=".key")
                try:
                    os.write(fd, key_content.encode() if isinstance(key_content, str) else key_content)
                    if not key_content.rstrip().endswith("\n"):
                        os.write(fd, b"\n")
                    os.close(fd)
                    os.chmod(key_path, stat_mod.S_IRUSR)
                    env = {
                        **os.environ,
                        "GIT_SSH_COMMAND": f"ssh -i {key_path} -o StrictHostKeyChecking=accept-new -o UserKnownHostsFile=/dev/null",
                    }
                except Exception:
                    try:
                        os.close(fd)
                    except OSError:
                        pass

        proc = await asyncio.create_subprocess_exec(
            "git", *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(cwd) if cwd else None,
            env=env,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except (TimeoutError, asyncio.TimeoutError):
            proc.kill()
            await proc.wait()
            raise RuntimeError(f"git {' '.join(args)} timed out after {timeout}s")
        finally:
            # Clean up temp SSH key file if created
            if env and "GIT_SSH_COMMAND" in env:
                import re as _re
                m = _re.search(r"-i\s+(\S+)", env["GIT_SSH_COMMAND"])
                if m:
                    try:
                        os.unlink(m.group(1))
                    except OSError:
                        pass
        if proc.returncode != 0:
            raise RuntimeError(f"git {' '.join(args)} failed:\n{stderr.decode()}")
        return stdout.decode()


# ── Process Manager ──


class ProcessManager:
    """Manages Agent CLI subprocess lifecycle."""

    # Patterns that indicate an agent hit its rate/usage limit
    RATE_LIMIT_PATTERNS = [
        "usage limit",
        "rate limit",
        "rate_limit",
        "429",
        "quota exceeded",
        "too many requests",
        "overloaded",
        "capacity",
        "try again",
        "credit",
    ]

    def __init__(self):
        self.active_processes: dict[str, asyncio.subprocess.Process] = {}

    @staticmethod
    def is_rate_limited(result: "TaskResult") -> bool:
        """Check if an agent failure was caused by a rate/usage limit."""
        if result.status == "success":
            return False
        combined = (result.stdout + result.stderr + result.error).lower()
        return any(p in combined for p in ProcessManager.RATE_LIMIT_PATTERNS)

    async def run_agent(
        self,
        agent: DiscoveredAgent,
        task: TaskInfo,
        workspace_path: Path,
        on_progress: Any = None,
        on_chunk: Any = None,
    ) -> TaskResult:
        """Execute an agent CLI and collect results."""
        prompt = self._build_prompt(task)
        timeout = task.timeout_seconds or settings.AGENT_TIMEOUT

        start_time = time.monotonic()

        if agent.agent_id == "claude-code":
            result = await self._run_claude(agent, prompt, workspace_path, timeout, task.task_id, on_chunk)
        elif agent.agent_id == "codex":
            result = await self._run_codex(agent, prompt, workspace_path, timeout, task.task_id, on_chunk)
        elif agent.agent_id == "opencode":
            result = await self._run_opencode(agent, prompt, workspace_path, timeout, task.task_id, on_chunk)
        elif agent.agent_id == "gemini":
            result = await self._run_gemini(agent, prompt, workspace_path, timeout, task.task_id, on_chunk)
        elif agent.agent_id == "kimi-code":
            result = await self._run_kimi_code(agent, prompt, workspace_path, timeout, task.task_id, on_chunk)
        else:
            result = await self._run_generic(agent, prompt, workspace_path, timeout, task.task_id, on_chunk)

        elapsed = time.monotonic() - start_time
        result.metrics["duration_seconds"] = round(elapsed, 2)

        # Collect git changes
        result.git = await self._collect_git_info(workspace_path)
        result.files_changed = result.git.get("files_changed", [])
        result.lines_added = result.git.get("lines_added", 0)
        result.lines_removed = result.git.get("lines_removed", 0)

        return result

    def _build_prompt(self, task: TaskInfo) -> str:
        """Build the prompt to send to the agent.

        Uses pre-built prompt from server if available (set by orchestrator
        via _build_agent_context), otherwise constructs from task data.
        """
        # Prefer server-built prompt (rich context from orchestrator)
        if task.input_prompt:
            prompt = task.input_prompt
        else:
            parts = []

            wi = task.work_item
            if wi and wi.get("title"):
                parts.append(f"\n\nWork Item: {wi['title']}")
                if wi.get("description"):
                    parts.append(f"Description: {wi['description']}")

            input_data = task.input_data or {}
            if input_data.get("context"):
                parts.append(f"\nContext: {input_data['context']}")
            if input_data.get("acceptance_criteria"):
                parts.append(f"\nAcceptance Criteria:\n{input_data['acceptance_criteria']}")

            prompt = "\n".join(parts) if parts else "No prompt provided."

        # Layer 3: Append CriticAgent reflection context if present
        reflection = (task.input_data or {}).get("reflection_context")
        if reflection:
            issues = reflection.get("issues", [])
            score = reflection.get("score", "N/A")
            issues_text = "\n".join(f"- {iss}" for iss in issues)
            prompt += (
                "\n\n## CriticAgent Feedback (MUST address before finishing)\n"
                f"Previous submission scored {score}. The following issues were identified:\n"
                f"{issues_text}\n\n"
                "Fix ALL listed issues. Focus on the specific problems above."
            )

        return prompt

    # ── Shared streaming helper ──

    async def _stream_process(
        self,
        proc: asyncio.subprocess.Process,
        stdin_input: bytes | None,
        timeout: int,
        task_id: str,
        on_chunk: Any,
    ) -> tuple[str, str, int]:
        """Stream stdout line-by-line from a subprocess, flushing to on_chunk.

        Returns (stdout_text, stderr_text, returncode).

        Design:
        - Stdout is read line-by-line so callers receive output in real time.
        - Stderr is consumed concurrently via a background task to avoid pipe
          deadlock when the process fills the stderr buffer.
        - on_chunk(lines) is called with each decoded line so the caller can
          forward to the progress reporter without waiting for completion.
        """
        # Write prompt and close stdin so the agent knows input is done.
        if stdin_input and proc.stdin:
            try:
                proc.stdin.write(stdin_input)
                await proc.stdin.drain()
            except Exception:
                pass
            proc.stdin.close()

        stdout_lines: list[str] = []
        stderr_chunks: list[bytes] = []

        async def _read_stderr():
            if proc.stderr:
                data = await proc.stderr.read()
                stderr_chunks.append(data)

        async def _read_stdout():
            if not proc.stdout:
                return
            while True:
                line_bytes = await proc.stdout.readline()
                if not line_bytes:
                    break
                line = line_bytes.decode(errors="replace").rstrip("\n")
                stdout_lines.append(line)
                if on_chunk:
                    try:
                        await on_chunk([line])
                    except Exception:
                        pass  # never let on_chunk crash the agent run

        try:
            await asyncio.wait_for(
                asyncio.gather(_read_stdout(), _read_stderr()),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            proc.kill()
            # Drain any remaining output after kill
            try:
                remaining, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
                if remaining:
                    for line in remaining.decode(errors="replace").split("\n"):
                        if line:
                            stdout_lines.append(line)
            except Exception:
                pass
            raise  # re-raise so callers can set result.error

        await proc.wait()
        stdout = "\n".join(stdout_lines)
        stderr = (stderr_chunks[0] if stderr_chunks else b"").decode(errors="replace")
        return stdout, stderr, proc.returncode or 0

    async def _run_claude(
        self, agent: DiscoveredAgent, prompt: str, cwd: Path, timeout: int, task_id: str,
        on_chunk: Any = None,
    ) -> TaskResult:
        """Run Claude Code CLI in print mode with auto-approve permissions.

        Uses stdin pipe for prompt delivery to avoid ARG_MAX limits.
        Uses --dangerously-skip-permissions for autonomous file operations.
        """
        cmd = [
            agent.command,
            "-p",
            "--output-format", "json",
            "--verbose",
            "--dangerously-skip-permissions",
        ]

        env = os.environ.copy()
        model_override = os.environ.get("FACTORY_CLAUDE_MODEL")
        if model_override:
            env["ANTHROPIC_MODEL"] = model_override

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                stdin=asyncio.subprocess.PIPE,
                cwd=str(cwd),
                env=env,
            )
            self.active_processes[task_id] = proc
            stdout, stderr, returncode = await self._stream_process(
                proc, prompt.encode(), timeout, task_id, on_chunk
            )

            # Parse Claude JSON output for metrics
            metrics = self._parse_claude_output(stdout)

            if returncode == 0:
                return TaskResult(
                    status="success",
                    exit_code=0,
                    stdout=stdout[-settings.AGENT_MAX_OUTPUT_SIZE:],
                    stderr=stderr[-10000:],
                    metrics=metrics,
                )
            else:
                return TaskResult(
                    status="failed",
                    exit_code=returncode,
                    stdout=stdout[-settings.AGENT_MAX_OUTPUT_SIZE:],
                    stderr=stderr[-10000:],
                    error=f"Claude exited with code {returncode}: {stderr[-500:]}",
                    metrics=metrics,
                )
        except asyncio.TimeoutError:
            if task_id in self.active_processes:
                self.active_processes[task_id].kill()
            return TaskResult(
                status="failed", exit_code=-1, stdout="", stderr="",
                error=f"Timed out after {timeout}s",
            )
        finally:
            self.active_processes.pop(task_id, None)

    async def _run_codex(
        self, agent: DiscoveredAgent, prompt: str, cwd: Path, timeout: int, task_id: str,
        on_chunk: Any = None,
    ) -> TaskResult:
        """Run Codex CLI in exec mode (non-interactive)."""
        cmd = [agent.command, "exec", "--full-auto", "--json", "-"]
        result = await self._run_cli(cmd, cwd, timeout, task_id, stdin_input=prompt, on_chunk=on_chunk)
        parsed_metrics = self._parse_agent_jsonl_output(result.stdout)
        result.metrics.update(parsed_metrics)
        return result

    async def _run_opencode(
        self, agent: DiscoveredAgent, prompt: str, cwd: Path, timeout: int, task_id: str,
        on_chunk: Any = None,
    ) -> TaskResult:
        """Run OpenCode CLI in non-interactive mode."""
        cmd = [agent.command, "run", "--format", "json", "--dangerously-skip-permissions", prompt]
        result = await self._run_cli(cmd, cwd, timeout, task_id, on_chunk=on_chunk)
        parsed_metrics = self._parse_agent_jsonl_output(result.stdout)
        result.metrics.update(parsed_metrics)
        return result

    async def _run_gemini(
        self, agent: DiscoveredAgent, prompt: str, cwd: Path, timeout: int, task_id: str,
        on_chunk: Any = None,
    ) -> TaskResult:
        """Run Gemini CLI in headless/prompt mode."""
        cmd = [agent.command, "--approval-mode", "yolo", "-p", ""]
        result = await self._run_cli(cmd, cwd, timeout, task_id, stdin_input=prompt, on_chunk=on_chunk)
        parsed_metrics = self._parse_agent_jsonl_output(result.stdout)
        result.metrics.update(parsed_metrics)
        return result

    async def _run_kimi_code(
        self, agent: DiscoveredAgent, prompt: str, cwd: Path, timeout: int, task_id: str,
        on_chunk: Any = None,
    ) -> TaskResult:
        """Run Kimi Code CLI in non-interactive, auto-approved mode."""
        cmd = [agent.command, "--print", "--yolo", "-p", prompt]
        result = await self._run_cli(cmd, cwd, timeout, task_id, on_chunk=on_chunk)
        parsed_metrics = self._parse_agent_jsonl_output(result.stdout)
        result.metrics.update(parsed_metrics)
        return result

    async def _run_generic(
        self, agent: DiscoveredAgent, prompt: str, cwd: Path, timeout: int, task_id: str,
        on_chunk: Any = None,
    ) -> TaskResult:
        """Run any generic agent CLI with stdin prompt."""
        cmd = [agent.command]
        return await self._run_cli(cmd, cwd, timeout, task_id, stdin_input=prompt, on_chunk=on_chunk)

    async def _run_cli(
        self, cmd: list[str], cwd: Path, timeout: int, task_id: str,
        stdin_input: str | None = None,
        on_chunk: Any = None,
    ) -> TaskResult:
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                stdin=asyncio.subprocess.PIPE if stdin_input else None,
                cwd=str(cwd),
                limit=10 * 1024 * 1024,  # 10MB line buffer for large agent output
            )
            self.active_processes[task_id] = proc
            stdin_bytes = stdin_input.encode() if stdin_input else None
            stdout, stderr, returncode = await self._stream_process(
                proc, stdin_bytes, timeout, task_id, on_chunk
            )
            status = "success" if returncode == 0 else "failed"
            return TaskResult(
                status=status,
                exit_code=returncode,
                stdout=stdout[-settings.AGENT_MAX_OUTPUT_SIZE:],
                stderr=stderr[-10000:],
                error="" if status == "success" else f"Exited with code {returncode}",
            )
        except asyncio.TimeoutError:
            if task_id in self.active_processes:
                self.active_processes[task_id].kill()
            return TaskResult(
                status="failed", exit_code=-1, stdout="", stderr="",
                error=f"Timed out after {timeout}s",
            )
        finally:
            self.active_processes.pop(task_id, None)

    def _parse_claude_output(self, stdout: str) -> dict:
        """Extract metrics from Claude JSON output.

        Claude CLI supports two output formats:
        - `--output-format json`: single JSON object (possibly multi-line)
        - `--output-format stream-json` / `--verbose`: JSONL (one JSON object per line)

        We handle both:
        1. Try line-by-line JSONL parsing first (streaming/verbose mode)
        2. Fall back to parsing entire stdout as a single JSON (json mode)
        3. As last resort, scan stderr-style summary lines with regex

        The authoritative metrics line has "type": "result" and contains:
          - usage.input_tokens / usage.output_tokens   (token counts)
          - total_cost_usd  (newer Claude >=1.x CLI)   or  cost_usd (older)
          - duration_ms
        """
        metrics: dict[str, Any] = {}
        parsed: list[dict] = []

        # ── 1. Try JSONL (line-by-line) parsing ──
        for raw in stdout.strip().split("\n"):
            raw = raw.strip()
            if not raw:
                continue
            try:
                data = json.loads(raw)
                if isinstance(data, dict):
                    parsed.append(data)
            except json.JSONDecodeError:
                continue

        # ── 2. If no JSONL objects found, try parsing entire stdout as single JSON ──
        if not parsed:
            try:
                data = json.loads(stdout.strip())
                if isinstance(data, dict):
                    parsed.append(data)
            except (json.JSONDecodeError, ValueError):
                pass

        def _extract_from(data: dict):
            """Extract token/cost metrics from a single parsed JSON object."""
            usage = data.get("usage") or {}
            if isinstance(usage, dict) and (usage.get("input_tokens") or usage.get("output_tokens")):
                metrics["token_input"] = int(usage.get("input_tokens") or 0)
                metrics["token_output"] = int(usage.get("output_tokens") or 0)
            # cost: try total_cost_usd first (newer Claude), then cost_usd (older)
            cost = data.get("total_cost_usd") or data.get("cost_usd")
            if cost and "cost_usd" not in metrics:
                try:
                    metrics["cost_usd"] = float(cost)
                except (TypeError, ValueError):
                    pass
            if data.get("duration_ms") and "duration_seconds" not in metrics:
                metrics["duration_seconds"] = data["duration_ms"] / 1000.0

        # ── 3. Prefer "result" type line — most authoritative ──
        for data in reversed(parsed):
            if data.get("type") == "result":
                _extract_from(data)
                break

        # ── 4. Fallback: scan all lines for any usage/cost data ──
        if "token_input" not in metrics:
            for data in reversed(parsed):
                if "usage" in data or "total_cost_usd" in data or "cost_usd" in data:
                    _extract_from(data)
                    if "token_input" in metrics:
                        break

        # ── 4b. Aggregate from assistant/turn messages if still missing ──
        if "token_input" not in metrics:
            total_in = 0
            total_out = 0
            for data in parsed:
                # Claude CLI: type=assistant with message.usage
                msg = data.get("message") or {}
                usage = msg.get("usage") if isinstance(msg, dict) else None
                if not usage:
                    usage = data.get("usage")
                if isinstance(usage, dict):
                    inp = int(usage.get("input_tokens") or 0)
                    out = int(usage.get("output_tokens") or 0)
                    # Claude reports cumulative in some modes, incremental in others
                    # Take the max seen as cumulative, or sum as incremental
                    total_in = max(total_in, inp) if inp > total_in else total_in
                    total_out += out  # output tokens are usually incremental
            if total_in or total_out:
                metrics["token_input"] = total_in
                metrics["token_output"] = total_out

        # ── 5. Model name extraction ──
        for data in parsed:
            if data.get("type") == "system" and isinstance(data.get("model"), str):
                metrics["model"] = data["model"]
                break
        if "model" not in metrics:
            for data in reversed(parsed):
                if isinstance(data.get("model"), str):
                    metrics["model"] = data["model"]
                    break

        return metrics

    def _parse_agent_jsonl_output(self, stdout: str) -> dict:
        """Extract token/cost metrics from JSONL output of any agent CLI.

        Handles three agent output formats:
        - Codex:    turn.completed events with usage.input_tokens / output_tokens
        - Claude:   top-level usage field with input_tokens / output_tokens
        - OpenCode: step_finish events with part.tokens.{total,input,output,cache}
                    and part.cost (cumulative running total — use last step_finish)
        """
        metrics: dict[str, Any] = {}
        total_input = 0
        total_output = 0
        found_usage = False

        # OpenCode accumulators (part.tokens.total is a running cumulative sum)
        oc_output_sum = 0
        oc_last_step: dict = {}
        oc_total_cost = 0.0
        oc_found = False

        for raw in stdout.strip().split("\n"):
            raw = raw.strip()
            if not raw:
                continue
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                continue
            if not isinstance(data, dict):
                continue

            ev_type = data.get("type")

            # ── OpenCode: step_finish carries cumulative token counters ────────
            if ev_type == "step_finish":
                part = data.get("part") or {}
                tokens = part.get("tokens") or {}
                if isinstance(tokens, dict) and tokens.get("total") is not None:
                    oc_last_step = tokens
                    oc_output_sum += int(tokens.get("output") or 0)
                    oc_found = True
                cost = part.get("cost")
                if cost is not None:
                    try:
                        oc_total_cost += float(cost)
                    except (TypeError, ValueError):
                        pass
                continue

            # ── Codex: turn.completed events with usage ────────────────────────
            if ev_type == "turn.completed":
                usage = data.get("usage") or {}
                if usage.get("input_tokens") or usage.get("output_tokens"):
                    total_input += int(usage.get("input_tokens") or 0)
                    total_output += int(usage.get("output_tokens") or 0)
                    found_usage = True

            # ── Claude: top-level usage field ─────────────────────────────────
            elif data.get("usage") and not found_usage:
                usage = data["usage"]
                if usage.get("input_tokens") or usage.get("output_tokens"):
                    total_input += int(usage.get("input_tokens") or 0)
                    total_output += int(usage.get("output_tokens") or 0)
                    found_usage = True

            # Cost extraction (Codex/Claude)
            cost = data.get("total_cost_usd") or data.get("cost_usd")
            if cost and "cost_usd" not in metrics:
                try:
                    metrics["cost_usd"] = float(cost)
                except (TypeError, ValueError):
                    pass

            # Model name
            if "model" not in metrics and isinstance(data.get("model"), str):
                metrics["model"] = data["model"]

        # ── Resolve final metrics ──────────────────────────────────────────────
        if oc_found and not found_usage:
            # OpenCode: use the last step_finish's running total.
            # total = input + output + cache.read + cache.write (all accumulated).
            # We report: token_output = sum of per-step outputs,
            #            token_input  = grand total minus output (includes cache reads).
            grand_total = int(oc_last_step.get("total") or 0)
            metrics["token_output"] = oc_output_sum
            metrics["token_input"] = max(0, grand_total - oc_output_sum)
            if oc_total_cost > 0 and "cost_usd" not in metrics:
                metrics["cost_usd"] = oc_total_cost
        elif found_usage:
            metrics["token_input"] = total_input
            metrics["token_output"] = total_output

        # ── Kimi Code: Python-repr StatusUpdate(...) format ───────────────────
        # Example line: StatusUpdate(token_usage=TokenUsage(input_other=326,
        #   output=538, input_cache_read=75264, input_cache_creation=0), ...)
        if "token_input" not in metrics:
            kimi_metrics = self._parse_kimi_output(stdout)
            if kimi_metrics:
                metrics.update(kimi_metrics)

        return metrics

    def _parse_kimi_output(self, stdout: str) -> dict:
        """Extract token usage from Kimi Code CLI Python-repr output.

        Kimi outputs StatusUpdate(...) lines containing a nested TokenUsage(...)
        object.  We parse all occurrences and use the last one (most complete).
        """
        import re as _re
        metrics: dict[str, Any] = {}
        # Match TokenUsage(...) blocks anywhere in stdout
        tu_pattern = _re.compile(
            r"TokenUsage\("
            r"(?:[^)]*\b)?input_other=(\d+)"
            r"(?:[^)]*\b)?output=(\d+)"
            r"(?:[^)]*\b)?input_cache_read=(\d+)"
            r"(?:[^)]*\b)?input_cache_creation=(\d+)",
            _re.DOTALL,
        )
        last_match = None
        for m in tu_pattern.finditer(stdout):
            last_match = m
        if last_match:
            input_other = int(last_match.group(1))
            output = int(last_match.group(2))
            cache_read = int(last_match.group(3))
            cache_creation = int(last_match.group(4))
            metrics["token_input"] = input_other + cache_read + cache_creation
            metrics["token_output"] = output
        return metrics

    async def _collect_git_info(self, cwd: Path) -> dict:
        """Collect git diff stats from workspace."""
        info: dict[str, Any] = {}
        try:
            proc = await asyncio.create_subprocess_exec(
                "git", "diff", "--stat", "--cached",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(cwd),
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=10)
            stat_output = stdout.decode()

            # Also check unstaged
            proc2 = await asyncio.create_subprocess_exec(
                "git", "diff", "--stat",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(cwd),
            )
            stdout2, _ = await asyncio.wait_for(proc2.communicate(), timeout=10)
            stat_output += stdout2.decode()

            # Parse changed files
            proc3 = await asyncio.create_subprocess_exec(
                "git", "diff", "--name-only", "HEAD",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(cwd),
            )
            stdout3, _ = await asyncio.wait_for(proc3.communicate(), timeout=10)
            files = [f for f in stdout3.decode().strip().split("\n") if f]
            info["files_changed"] = files

            # Parse insertions/deletions
            proc4 = await asyncio.create_subprocess_exec(
                "git", "diff", "--shortstat", "HEAD",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(cwd),
            )
            stdout4, _ = await asyncio.wait_for(proc4.communicate(), timeout=10)
            shortstat = stdout4.decode()
            added = re.search(r"(\d+) insertion", shortstat)
            removed = re.search(r"(\d+) deletion", shortstat)
            info["lines_added"] = int(added.group(1)) if added else 0
            info["lines_removed"] = int(removed.group(1)) if removed else 0

            # Get current branch
            proc5 = await asyncio.create_subprocess_exec(
                "git", "rev-parse", "--abbrev-ref", "HEAD",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(cwd),
            )
            stdout5, _ = await asyncio.wait_for(proc5.communicate(), timeout=10)
            info["branch"] = stdout5.decode().strip()

            # Get latest commit
            proc6 = await asyncio.create_subprocess_exec(
                "git", "rev-parse", "HEAD",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(cwd),
            )
            stdout6, _ = await asyncio.wait_for(proc6.communicate(), timeout=10)
            info["commit_sha"] = stdout6.decode().strip()

        except Exception as e:
            logger.debug("Git info collection failed: %s", e)

        return info

    async def _collect_git_info_vs_parent(self, cwd: Path) -> dict:
        """Collect git diff stats comparing HEAD vs merge-base with default branch.

        Uses merge-base to capture ALL changes on the feature branch, not just
        the last commit (agents like claude-code may create multiple commits).
        Falls back to HEAD~1 if merge-base detection fails.
        """
        info: dict[str, Any] = {}
        try:
            # Try to find merge-base with origin's default branch
            base_ref = "HEAD~1"
            for candidate in ("origin/master", "origin/main"):
                proc_mb = await asyncio.create_subprocess_exec(
                    "git", "merge-base", candidate, "HEAD",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(cwd),
                )
                mb_stdout, _ = await asyncio.wait_for(proc_mb.communicate(), timeout=10)
                if proc_mb.returncode == 0 and mb_stdout.strip():
                    base_ref = mb_stdout.decode().strip()
                    break

            # Changed files since branch point
            proc = await asyncio.create_subprocess_exec(
                "git", "diff", "--name-only", base_ref, "HEAD",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(cwd),
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=10)
            files = [f for f in stdout.decode().strip().split("\n") if f]
            info["files_changed"] = files

            # Lines added/removed since branch point
            proc2 = await asyncio.create_subprocess_exec(
                "git", "diff", "--shortstat", base_ref, "HEAD",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(cwd),
            )
            stdout2, _ = await asyncio.wait_for(proc2.communicate(), timeout=10)
            shortstat = stdout2.decode()
            added = re.search(r"(\d+) insertion", shortstat)
            removed = re.search(r"(\d+) deletion", shortstat)
            info["lines_added"] = int(added.group(1)) if added else 0
            info["lines_removed"] = int(removed.group(1)) if removed else 0

            # Branch name
            proc3 = await asyncio.create_subprocess_exec(
                "git", "rev-parse", "--abbrev-ref", "HEAD",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(cwd),
            )
            stdout3, _ = await asyncio.wait_for(proc3.communicate(), timeout=10)
            info["branch"] = stdout3.decode().strip()

            # Commit SHA
            proc4 = await asyncio.create_subprocess_exec(
                "git", "rev-parse", "HEAD",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(cwd),
            )
            stdout4, _ = await asyncio.wait_for(proc4.communicate(), timeout=10)
            info["commit_sha"] = stdout4.decode().strip()

        except Exception as e:
            logger.debug("Git info (vs parent) collection failed: %s", e)

        return info

    async def cancel(self, task_id: str):
        proc = self.active_processes.get(task_id)
        if proc:
            proc.kill()
            self.active_processes.pop(task_id, None)


# ── Progress Reporter ──


class ProgressReporter:
    """Reports task progress back to the server."""

    def __init__(self, client: httpx.AsyncClient, server_url: str, runtime_id: str):
        self.client = client
        self.server_url = server_url.rstrip("/")
        self.runtime_id = runtime_id

    async def report_progress(
        self,
        task_id: str,
        progress_percent: int,
        current_step: str,
        output_lines: list[str] | None = None,
        files_changed: list[str] | None = None,
        lines_added: int = 0,
        lines_removed: int = 0,
    ):
        try:
            await self.client.post(
                f"{self.server_url}/api/v1/runtimes/{self.runtime_id}/tasks/{task_id}/progress",
                json={
                    "progress_percent": progress_percent,
                    "current_step": current_step,
                    "output_lines": output_lines or [],
                    "files_changed": files_changed or [],
                    "lines_added": lines_added,
                    "lines_removed": lines_removed,
                },
                timeout=10,
            )
        except Exception as e:
            logger.warning("Failed to report progress for task %s: %s", task_id, e)

    async def report_complete(self, task_id: str, result: TaskResult):
        """Report task completion with retry."""
        payload = {
            "status": result.status,
            "exit_code": result.exit_code,
            "stdout_tail": result.stdout[-20000:] if result.stdout else "",
            "stderr_tail": result.stderr[-5000:] if result.stderr else "",
            "error": result.error,
            "files_changed": result.files_changed,
            "lines_added": result.lines_added,
            "lines_removed": result.lines_removed,
            "artifacts": result.artifacts,
            "observations": result.observations,
            "metrics": result.metrics,
            "git": result.git,
        }
        url = f"{self.server_url}/api/v1/runtimes/{self.runtime_id}/tasks/{task_id}/complete"
        max_attempts = 5
        for attempt in range(1, max_attempts + 1):
            try:
                resp = await self.client.post(url, json=payload, timeout=30)
                if resp.status_code < 500:
                    return  # success or 4xx (non-retryable)
                logger.warning(
                    "Server returned %d for completion of task %s (attempt %d/%d)",
                    resp.status_code, task_id, attempt, max_attempts,
                )
            except Exception as e:
                logger.warning(
                    "Failed to report completion for task %s (attempt %d/%d): %s",
                    task_id, attempt, max_attempts, e,
                )
            if attempt < max_attempts:
                await asyncio.sleep(min(2 ** attempt, 30))  # exponential backoff
        logger.error("Exhausted %d attempts to report completion for task %s", max_attempts, task_id)


# ── Heartbeat Service ──


class HeartbeatService:
    """Sends periodic heartbeats to the server."""

    def __init__(
        self,
        client: httpx.AsyncClient,
        server_url: str,
        runtime_id: str,
        daemon_id: str,
        interval: int = 15,
    ):
        self.client = client
        self.server_url = server_url.rstrip("/")
        self.runtime_id = runtime_id
        self.daemon_id = daemon_id
        self.interval = interval
        self._task: asyncio.Task | None = None
        self._active_tasks = 0
        self._agents: list[dict] = []

    def update(self, active_tasks: int, agents: list[dict]):
        self._active_tasks = active_tasks
        self._agents = agents

    async def start(self):
        self._task = asyncio.create_task(self._loop())

    async def stop(self):
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    async def _loop(self):
        while True:
            try:
                resp = await self.client.post(
                    f"{self.server_url}/api/v1/runtimes/{self.runtime_id}/heartbeat",
                    json={
                        "daemon_id": self.daemon_id,
                        "active_tasks": self._active_tasks,
                        "available_agents": self._agents,
                        "system_metrics": self._collect_system_metrics(),
                    },
                    timeout=10,
                )
                if resp.status_code != 200:
                    logger.warning("Heartbeat failed: %s %s", resp.status_code, resp.text)
            except Exception as e:
                logger.warning("Heartbeat error: %s", e)

            await asyncio.sleep(self.interval)

    def _collect_system_metrics(self) -> dict:
        """Basic system metrics."""
        try:
            import psutil
            return {
                "cpu_percent": psutil.cpu_percent(),
                "memory_percent": psutil.virtual_memory().percent,
                "disk_percent": psutil.disk_usage("/").percent,
            }
        except ImportError:
            return {}


# ── Task Poller ──


class TaskPoller:
    """Polls the server for assigned tasks."""

    def __init__(
        self,
        client: httpx.AsyncClient,
        server_url: str,
        runtime_id: str,
        interval: int = 3,
    ):
        self.client = client
        self.server_url = server_url.rstrip("/")
        self.runtime_id = runtime_id
        self.interval = interval

    async def poll(self) -> list[TaskInfo]:
        """Poll for tasks assigned to this daemon."""
        try:
            resp = await self.client.get(
                f"{self.server_url}/api/v1/runtimes/{self.runtime_id}/tasks/poll",
                timeout=10,
            )
            if resp.status_code != 200:
                return []

            data = resp.json()
            tasks = []
            for t in data.get("tasks", []):
                tasks.append(TaskInfo(
                    task_id=t["task_id"],
                    graph_id=t["graph_id"],
                    node_type=t["node_type"],
                    agent_type=t.get("agent_type", "claude-code"),
                    input_prompt=t.get("input_prompt", ""),
                    input_data=t.get("input_data", {}),
                    timeout_seconds=t.get("timeout_seconds", settings.AGENT_TIMEOUT),
                    max_retries=t.get("max_retries", 2),
                    retry_count=t.get("retry_count", 0),
                    project=t.get("project", {}),
                    work_item=t.get("work_item", {}),
                    fallback_chain=t.get("fallback_chain", []),
                    requirement_workflow_id=t.get("requirement_workflow_id"),
                    requirement_key=t.get("requirement_key"),
                    graph_type=t.get("graph_type", "execution"),
                ))
            return tasks
        except Exception as e:
            logger.warning("Task poll error: %s", e)
            return []


# ── Server Connection ──


class ServerConnection:
    """Manages connection to a single API server for multi-server daemon mode."""

    def __init__(
        self,
        server_url: str,
        api_token: str,
        daemon_id: str,
        hardware_id: str | None = None,
    ):
        self.server_url = server_url.rstrip("/")
        self.api_token = api_token
        self.daemon_id = daemon_id
        self.hardware_id = hardware_id
        self.runtime_id: str | None = None
        self.client = httpx.AsyncClient(
            headers={"Authorization": f"Bearer {api_token}"} if api_token else {},
        )
        self.heartbeat: HeartbeatService | None = None
        self.poller: TaskPoller | None = None
        self.reporter: ProgressReporter | None = None
        # Short label for logging
        from urllib.parse import urlparse
        parsed = urlparse(server_url)
        self.label = parsed.hostname or server_url

    async def register(self, agents: list[DiscoveredAgent], max_concurrent: int):
        """Register this daemon with the server."""
        agent_dicts = [
            {
                "agent_id": a.agent_id,
                "version": a.version,
                "invoke_modes": a.invoke_modes,
                "compatibility_level": a.compatibility_level,
            }
            for a in agents
        ]
        try:
            resp = await self.client.post(
                f"{self.server_url}/api/v1/runtimes/register",
                json={
                    "daemon_id": self.daemon_id,
                    "hardware_id": self.hardware_id,
                    "device_name": platform.node(),
                    "available_agents": agent_dicts,
                    "max_concurrent_tasks": max_concurrent,
                    "capabilities": {
                        "platform": platform.platform(),
                        "python_version": platform.python_version(),
                    },
                    "api_token": self.api_token,
                    "server_url": self.server_url,
                },
                timeout=15,
            )
            resp.raise_for_status()
            data = resp.json()
            self.runtime_id = data["runtime_id"]
            logger.info("[%s] Registered with server. runtime_id=%s", self.label, self.runtime_id)
        except Exception as e:
            logger.error("[%s] Failed to register with server: %s", self.label, e)
            raise

    def start_services(
        self,
        heartbeat_interval: int,
        poll_interval: int,
        agents: list[DiscoveredAgent],
    ):
        """Initialize heartbeat, poller, and reporter services."""
        self.heartbeat = HeartbeatService(
            self.client, self.server_url, self.runtime_id, self.daemon_id,
            heartbeat_interval,
        )
        self.heartbeat.update(0, [
            {
                "agent_id": a.agent_id,
                "version": a.version,
                "invoke_modes": a.invoke_modes,
                "compatibility_level": a.compatibility_level,
            }
            for a in agents
        ])
        self.poller = TaskPoller(
            self.client, self.server_url, self.runtime_id, poll_interval,
        )
        self.reporter = ProgressReporter(
            self.client, self.server_url, self.runtime_id,
        )

    async def start_heartbeat(self):
        if self.heartbeat:
            await self.heartbeat.start()

    async def stop(self):
        """Stop heartbeat and unregister."""
        if self.heartbeat:
            await self.heartbeat.stop()
        if self.runtime_id:
            try:
                await self.client.delete(
                    f"{self.server_url}/api/v1/runtimes/{self.runtime_id}",
                    timeout=5,
                )
            except Exception:
                pass
        await self.client.aclose()


# ── Main Daemon ──


class RuntimeDaemon:
    """Main Daemon orchestrator — runs on the host machine.

    Supports connecting to multiple API servers simultaneously (multi-server mode).
    Each server connection registers, heartbeats, and polls independently.
    Task execution is shared across all servers with a single concurrent task limit.
    """

    def __init__(self):
        # Compute stable hardware fingerprint from machine-id / MAC address.
        # This allows the server to identify the same physical machine even when
        # its IP address changes (e.g., DHCP reassignment, home vs. office).
        self.hardware_id = get_hardware_id()

        # daemon_id: prefer explicit config, fall back to hardware_id (stable),
        # then hostname. Using hardware_id as default instead of platform.node()
        # prevents duplicate registrations when the hostname changes.
        self.daemon_id = settings.DAEMON_ID or self.hardware_id or platform.node()
        self.server_urls = settings.get_daemon_server_urls()
        self.api_token = settings.DAEMON_API_TOKEN
        self.max_concurrent = settings.DAEMON_MAX_CONCURRENT
        self.poll_interval = settings.DAEMON_POLL_INTERVAL
        self.heartbeat_interval = settings.DAEMON_HEARTBEAT_INTERVAL
        self.workspaces_root = settings.get_daemon_workspaces_root()

        self.agents: list[DiscoveredAgent] = []
        self.active_tasks: dict[str, asyncio.Task] = {}
        # Track which ServerConnection owns each task (for reporting)
        self._task_connections: dict[str, ServerConnection] = {}
        self._shutdown = False

        self.connections: list[ServerConnection] = []
        self.agent_discovery = AgentDiscovery()
        self.workspace_manager = WorkspaceManager(self.workspaces_root)
        self.process_manager = ProcessManager()

    async def start(self):
        """Main entry point."""
        logger.info("Starting RuntimeDaemon (id=%s)", self.daemon_id)
        logger.info("Server URLs: %s", ", ".join(self.server_urls))
        logger.info("Workspaces root: %s", self.workspaces_root)

        if not self.server_urls:
            logger.error("No server URLs configured. Set DAEMON_SERVER_URL or DAEMON_SERVER_URLS.")
            raise SystemExit(1)

        # 1. Discover agents
        self.agents = await self.agent_discovery.discover()
        if not self.agents:
            logger.warning("No agent CLIs found. Daemon will run but cannot execute tasks.")
        else:
            logger.info("Discovered %d agent(s): %s", len(self.agents),
                       ", ".join(a.agent_id for a in self.agents))

        # 2. Register with all servers
        for url in self.server_urls:
            conn = ServerConnection(url, self.api_token, self.daemon_id, self.hardware_id)
            try:
                await conn.register(self.agents, self.max_concurrent)
                conn.start_services(self.heartbeat_interval, self.poll_interval, self.agents)
                await conn.start_heartbeat()
                self.connections.append(conn)
                logger.info("[%s] Connected and ready", conn.label)
            except Exception as e:
                logger.error("[%s] Failed to connect: %s — skipping this server", conn.label, e)
                await conn.client.aclose()

        if not self.connections:
            logger.error("Failed to connect to any server. Exiting.")
            raise SystemExit(1)

        logger.info("Daemon ready. Connected to %d server(s). Polling for tasks...",
                    len(self.connections))

        # 3. Main loop
        try:
            while not self._shutdown:
                await self._poll_and_execute()
                await asyncio.sleep(self.poll_interval)
        except asyncio.CancelledError:
            pass
        finally:
            await self._shutdown_gracefully()

    async def _poll_and_execute(self):
        """Poll for tasks from all connected servers and execute them."""
        # Clean up completed tasks
        for task_id in list(self.active_tasks):
            if self.active_tasks[task_id].done():
                del self.active_tasks[task_id]
                self._task_connections.pop(task_id, None)

        # Update heartbeat on all connections with total active count
        total_active = len(self.active_tasks)
        for conn in self.connections:
            if conn.heartbeat:
                conn.heartbeat.update(total_active, self._agents_as_dicts())

        # Check capacity
        if total_active >= self.max_concurrent:
            return

        # Poll from all connected servers
        for conn in self.connections:
            if total_active >= self.max_concurrent:
                break

            tasks = await conn.poller.poll()

            for task in tasks:
                if task.task_id in self.active_tasks:
                    continue  # Already running

                if len(self.active_tasks) >= self.max_concurrent:
                    break

                # Start task execution with this connection's reporter
                logger.info("[%s] Starting task %s (type=%s, agent=%s)",
                           conn.label, task.task_id, task.node_type, task.agent_type)
                self._task_connections[task.task_id] = conn
                self.active_tasks[task.task_id] = asyncio.create_task(
                    self._execute_task(task, conn)
                )

    async def _execute_task(self, task: TaskInfo, conn: ServerConnection):
        """Execute a single task, reporting to the originating server connection."""
        reporter = conn.reporter
        try:
            # 1. Find the right agent
            agent = self._select_agent(task.agent_type, task.fallback_chain)
            if not agent:
                logger.error("No agent found for type '%s'", task.agent_type)
                await reporter.report_complete(task.task_id, TaskResult(
                    status="failed", exit_code=-1, stdout="", stderr="",
                    error=f"No agent CLI available for type '{task.agent_type}'",
                ))
                return

            # Track which agents we've already tried (for rate-limit fallback)
            tried_agents: set[str] = set()

            # 2. Prepare workspace
            await reporter.report_progress(task.task_id, 5, "preparing_workspace")
            workspace_path = await self.workspace_manager.prepare_workspace(
                task.project, task
            )
            logger.info("Workspace ready: %s", workspace_path)

            # 3. Run agent with real-time output streaming + periodic progress heartbeat
            await reporter.report_progress(task.task_id, 10, "running_agent")

            # Buffer agent output lines between ticks; the ticker flushes them
            # every 10 seconds so the server accumulates a real-time log.
            _line_buffer: list[str] = []
            _task_start = time.monotonic()
            progress_stop = asyncio.Event()

            async def on_output_chunk(lines: list[str]):
                """Callback invoked per stdout line by _stream_process."""
                _line_buffer.extend(lines)

            async def _progress_ticker():
                """Flush buffered output lines + update progress % every 10 s."""
                import math as _math
                tick = 0
                while not progress_stop.is_set():
                    await asyncio.sleep(10)
                    if progress_stop.is_set():
                        break
                    tick += 1
                    pct = min(int(10 + 80 * (1 - 1 / (1 + tick / 8))), 90)
                    pid = self.process_manager.active_processes.get(task.task_id)
                    step = "running_agent"
                    if pid:
                        step = f"running_agent (pid={pid.pid})"
                    # Grab and clear the buffer atomically
                    lines_to_send = _line_buffer[:]
                    _line_buffer.clear()
                    await reporter.report_progress(
                        task.task_id, pct, step, output_lines=lines_to_send
                    )

            ticker_task = asyncio.create_task(_progress_ticker())

            try:
                result = await self.process_manager.run_agent(
                    agent, task, workspace_path, on_chunk=on_output_chunk,
                )
            finally:
                progress_stop.set()
                ticker_task.cancel()
                try:
                    await ticker_task
                except asyncio.CancelledError:
                    pass
                # Flush any remaining lines that weren't sent by the ticker
                if _line_buffer:
                    pid = self.process_manager.active_processes.get(task.task_id)
                    step = f"running_agent (pid={pid.pid})" if pid else "running_agent"
                    await reporter.report_progress(
                        task.task_id, 90, step, output_lines=_line_buffer[:]
                    )
                    _line_buffer.clear()

            tried_agents.add(agent.agent_id)

            # ── Rate-limit fallback: if agent hit usage/rate limit, try next agent ──
            if self.process_manager.is_rate_limited(result):
                logger.warning(
                    "Agent '%s' hit rate/usage limit for task %s, attempting fallback",
                    agent.agent_id, task.task_id,
                )
                fallback_agent = self._select_fallback_agent(
                    agent.agent_id, task.fallback_chain, tried_agents
                )
                while fallback_agent:
                    logger.info(
                        "Rate-limit fallback: switching from '%s' to '%s' for task %s",
                        agent.agent_id, fallback_agent.agent_id, task.task_id,
                    )
                    agent = fallback_agent
                    tried_agents.add(agent.agent_id)

                    await reporter.report_progress(
                        task.task_id, 10,
                        f"rate_limit_fallback: retrying with {agent.agent_id}",
                        output_lines=[f"[daemon] Agent rate-limited, switching to {agent.agent_id}"],
                    )

                    # Re-run with fallback agent
                    progress_stop2 = asyncio.Event()
                    _line_buffer.clear()

                    async def _progress_ticker2():
                        tick = 0
                        while not progress_stop2.is_set():
                            await asyncio.sleep(10)
                            if progress_stop2.is_set():
                                break
                            tick += 1
                            pct = min(int(10 + 80 * (1 - 1 / (1 + tick / 8))), 90)
                            pid = self.process_manager.active_processes.get(task.task_id)
                            step = f"running_agent:{agent.agent_id}"
                            if pid:
                                step += f" (pid={pid.pid})"
                            lines_to_send = _line_buffer[:]
                            _line_buffer.clear()
                            await reporter.report_progress(
                                task.task_id, pct, step, output_lines=lines_to_send
                            )

                    ticker2 = asyncio.create_task(_progress_ticker2())
                    try:
                        result = await self.process_manager.run_agent(
                            agent, task, workspace_path, on_chunk=on_output_chunk,
                        )
                    finally:
                        progress_stop2.set()
                        ticker2.cancel()
                        try:
                            await ticker2
                        except asyncio.CancelledError:
                            pass
                        if _line_buffer:
                            await reporter.report_progress(
                                task.task_id, 90, f"running_agent:{agent.agent_id}",
                                output_lines=_line_buffer[:],
                            )
                            _line_buffer.clear()

                    if not self.process_manager.is_rate_limited(result):
                        break  # Success or non-rate-limit failure

                    logger.warning(
                        "Fallback agent '%s' also rate-limited for task %s",
                        agent.agent_id, task.task_id,
                    )
                    fallback_agent = self._select_fallback_agent(
                        agent.agent_id, task.fallback_chain, tried_agents
                    )

                if self.process_manager.is_rate_limited(result):
                    result.error = (
                        f"All agents rate-limited (tried: {', '.join(tried_agents)}). "
                        f"Original error: {result.error}"
                    )

            # 4. Collect git info BEFORE commit (shows uncommitted changes)
            pre_commit_git = await self.process_manager._collect_git_info(workspace_path)

            # 4.1 Recovery: agent exited non-zero but already committed code
            # (e.g. OpenCode EBADF crash on exit after successful work)
            if result.status == "failed" and result.exit_code not in (None, -1):
                committed_git = await self.process_manager._collect_git_info_vs_parent(workspace_path)
                has_committed_changes = bool(committed_git.get("files_changed"))
                has_no_uncommitted = not pre_commit_git.get("files_changed")
                if has_committed_changes and has_no_uncommitted:
                    logger.warning(
                        "Task %s agent exited with code %s but has committed changes — "
                        "recovering as success (agent likely crashed during cleanup)",
                        task.task_id, result.exit_code,
                    )
                    result.status = "success"
                    result.error = ""
                    result.metrics["recovered_from_exit_code"] = result.exit_code

            # 4.5 Layer 2: Validation gate — check outputs before committing
            if result.status == "success":
                try:
                    result = await self._validate_and_retry(
                        agent, task, workspace_path, result,
                        reporter, on_output_chunk, max_retries=2,
                    )
                    # Re-collect git info if validation triggered retries
                    if result.metrics.get("validation_issues") is not None or True:
                        pre_commit_git = await self.process_manager._collect_git_info(workspace_path)
                except Exception:
                    logger.exception("Validation gate error for task %s (proceeding anyway)", task.task_id)

            # 4.6 For analysis nodes: attach output file contents as inline artifacts
            # so the backend always has the documents even if git push fails later.
            if result.status == "success" and task.node_type == "analysis":
                await self._collect_analysis_artifacts(workspace_path, task, result)

            # 5. Auto-commit and push if changes exist
            if result.status == "success":
                await self._auto_commit(workspace_path, task)
                # Re-collect git info after commit (compare with parent)
                post_commit_git = await self.process_manager._collect_git_info_vs_parent(workspace_path)
                # Merge: use the pre-commit file list if post-commit is empty
                result.git = post_commit_git
                if not result.git.get("files_changed") and pre_commit_git.get("files_changed"):
                    result.git["files_changed"] = pre_commit_git["files_changed"]
                    result.git["lines_added"] = pre_commit_git.get("lines_added", 0)
                    result.git["lines_removed"] = pre_commit_git.get("lines_removed", 0)
                result.files_changed = result.git.get("files_changed", [])
                result.lines_added = result.git.get("lines_added", 0)
                result.lines_removed = result.git.get("lines_removed", 0)
            else:
                result.git = pre_commit_git

            # 6. Report completion (include actual agent used if different from requested)
            result.metrics["actual_agent"] = agent.agent_id
            if agent.agent_id != task.agent_type:
                result.metrics["original_agent"] = task.agent_type
                result.metrics["fallback_reason"] = "rate_limit"
            await reporter.report_progress(task.task_id, 100, "completed" if result.status == "success" else "failed")
            await reporter.report_complete(task.task_id, result)

            logger.info("Task %s completed: %s (agent=%s)", task.task_id, result.status, agent.agent_id)

        except Exception as e:
            logger.exception("Task %s failed with exception", task.task_id)
            await reporter.report_complete(task.task_id, TaskResult(
                status="failed", exit_code=-1, stdout="", stderr="",
                error=str(e),
            ))

    def _select_fallback_agent(
        self, current_agent_id: str, fallback_chain: list[str] | None, tried: set[str]
    ) -> DiscoveredAgent | None:
        """Find the next untried agent from fallback chain or available agents."""
        # 1. Try fallback chain
        if fallback_chain:
            for fallback_id in fallback_chain:
                if fallback_id in tried:
                    continue
                for agent in self.agents:
                    if agent.agent_id == fallback_id:
                        return agent

        # 2. Try any available agent not yet tried (prefer opencode > gemini > claude-code)
        preferred_order = ["opencode", "gemini", "claude-code"]
        for preferred_id in preferred_order:
            if preferred_id in tried:
                continue
            for agent in self.agents:
                if agent.agent_id == preferred_id:
                    return agent
        # 3. Any remaining agent
        for agent in self.agents:
            if agent.agent_id not in tried:
                return agent

        return None

    def _select_agent(self, agent_type: str, fallback_chain: list[str] | None = None) -> DiscoveredAgent | None:
        """Find best matching agent for the requested type with fallback chain support."""
        # 1. Exact match
        for agent in self.agents:
            if agent.agent_id == agent_type:
                return agent

        # 2. Try fallback chain from policy
        if fallback_chain:
            for fallback_id in fallback_chain:
                if fallback_id == agent_type:
                    continue
                for agent in self.agents:
                    if agent.agent_id == fallback_id:
                        logger.info("Using fallback agent '%s' (requested '%s')", fallback_id, agent_type)
                        return agent

        # 3. Fallback: first available L3 agent
        for agent in self.agents:
            if agent.compatibility_level == "L3":
                return agent
        # 4. Any agent
        return self.agents[0] if self.agents else None

    # ── Layer 2: Validation Gate ──

    def _validate_outputs(
        self, workspace_path: Path, task: TaskInfo, result: TaskResult
    ) -> list[str]:
        """Run deterministic validations on agent output.

        Returns a list of issue descriptions.  Empty list = all OK.
        """
        import json as _json

        issues: list[str] = []
        node_type = task.node_type

        if node_type == "analysis":
            # Check required files exist
            doc_dir = (task.input_data or {}).get("output_dir", "")
            if doc_dir:
                base = workspace_path / doc_dir
            else:
                base = workspace_path
            for fname in ("PRD.md", "SDD.md", "TASKS.md", "analysis.json", "test-intent.json"):
                fpath = base / fname
                if not fpath.exists():
                    issues.append(f"Required file missing: {doc_dir}/{fname}")
                elif fpath.stat().st_size == 0:
                    issues.append(f"Required file is empty: {doc_dir}/{fname}")

            # Validate analysis.json
            json_path = base / "analysis.json"
            if json_path.exists() and json_path.stat().st_size > 0:
                try:
                    _json.loads(json_path.read_text(encoding="utf-8"))
                except _json.JSONDecodeError as e:
                    issues.append(f"analysis.json is not valid JSON: {e}")

            # Validate test-intent.json
            ti_path = base / "test-intent.json"
            if ti_path.exists() and ti_path.stat().st_size > 0:
                try:
                    ti_data = _json.loads(ti_path.read_text(encoding="utf-8"))
                    intents = ti_data.get("intents", [])
                    if not intents:
                        issues.append("test-intent.json contains no test intents")
                    for ti in intents[:20]:
                        if not ti.get("id") or not ti.get("title"):
                            issues.append(f"Test intent missing 'id' or 'title': {ti.get('id', '?')}")
                            break
                except _json.JSONDecodeError as e:
                    issues.append(f"test-intent.json is not valid JSON: {e}")

        elif node_type == "design":
            doc_dir = (task.input_data or {}).get("output_dir", "")
            if doc_dir:
                design_path = workspace_path / doc_dir / "design.md"
                if not design_path.exists():
                    issues.append(f"Design document missing: {doc_dir}/design.md")
                elif design_path.stat().st_size == 0:
                    issues.append(f"Design document is empty: {doc_dir}/design.md")

        elif node_type in ("coding", "testing"):
            # Syntax-check modified Python and JS/TS files
            for f in result.files_changed:
                fpath = workspace_path / f
                if not fpath.exists():
                    continue
                if f.endswith(".py"):
                    try:
                        import ast
                        ast.parse(fpath.read_text(encoding="utf-8"), filename=f)
                    except SyntaxError as e:
                        issues.append(f"Python syntax error in {f}: {e.msg} (line {e.lineno})")
                elif f.endswith((".js", ".ts", ".jsx", ".tsx")):
                    # Basic bracket/brace balance check
                    content = fpath.read_text(encoding="utf-8")
                    opens = content.count("{") + content.count("(") + content.count("[")
                    closes = content.count("}") + content.count(")") + content.count("]")
                    if abs(opens - closes) > 2:
                        issues.append(
                            f"Possible syntax issue in {f}: "
                            f"bracket imbalance (open={opens}, close={closes})"
                        )

            # Testing-specific: validate structured test assets
            if node_type == "testing":
                doc_dir = (task.input_data or {}).get("output_dir", "")
                if doc_dir:
                    base = workspace_path / doc_dir
                else:
                    base = workspace_path

                # --- test-cases.json validation ---
                tc_path = base / "test-cases.json"
                if tc_path.exists():
                    try:
                        tc_data = _json.loads(tc_path.read_text(encoding="utf-8"))
                        cases = tc_data.get("test_cases", [])
                        if not cases:
                            issues.append("test-cases.json exists but contains no test cases")
                        else:
                            for tc in cases[:20]:
                                if not tc.get("id") or not tc.get("title"):
                                    issues.append(f"Test case missing 'id' or 'title': {tc.get('id', '?')}")
                                    break
                                if not tc.get("steps"):
                                    issues.append(f"Test case {tc['id']} has no 'steps'")
                                    break
                            p0_cases = [c for c in cases if c.get("priority") == "P0"]
                            if not p0_cases:
                                issues.append("No P0 priority test cases found in test-cases.json")
                    except (_json.JSONDecodeError, UnicodeDecodeError) as e:
                        issues.append(f"test-cases.json is not valid JSON: {e}")
                else:
                    issues.append(f"test-cases.json not found in {doc_dir or 'workspace root'}")

                # --- coverage-matrix.json validation ---
                cm_path = base / "coverage-matrix.json"
                if cm_path.exists():
                    try:
                        cm_data = _json.loads(cm_path.read_text(encoding="utf-8"))
                        ac_list = cm_data.get("acceptance_criteria", [])
                        uncovered = [ac for ac in ac_list if ac.get("status") != "covered"]
                        if uncovered:
                            ids = ", ".join(ac.get("id", "?") for ac in uncovered[:5])
                            issues.append(f"Uncovered acceptance criteria in coverage-matrix.json: {ids}")
                    except (_json.JSONDecodeError, UnicodeDecodeError) as e:
                        issues.append(f"coverage-matrix.json is not valid JSON: {e}")
                else:
                    issues.append(f"coverage-matrix.json not found in {doc_dir or 'workspace root'}")

                # --- test-report.md validation ---
                report_path = base / "test-report.md"
                if not report_path.exists():
                    issues.append(f"test-report.md not found in {doc_dir or 'workspace root'}")

        return issues

    async def _validate_and_retry(
        self,
        agent: "DiscoveredAgent",
        task: TaskInfo,
        workspace_path: Path,
        result: TaskResult,
        reporter: "TaskReporter",
        on_chunk: Any,
        max_retries: int = 2,
    ) -> TaskResult:
        """Validate agent output and retry with fix prompt if issues found.

        Layer 2 of the reflection mechanism.  Runs deterministic checks
        (file existence, syntax, JSON validity) after agent completion but
        before git commit.  If issues are found, builds a fix prompt listing
        all problems and re-invokes the same agent.

        Returns the (possibly updated) TaskResult.
        """
        for attempt in range(max_retries):
            issues = self._validate_outputs(workspace_path, task, result)
            if not issues:
                return result  # All validations passed

            issues_text = "\n".join(f"- {iss}" for iss in issues)
            logger.warning(
                "Validation gate: %d issues found for task %s (attempt %d/%d):\n%s",
                len(issues), task.task_id, attempt + 1, max_retries, issues_text,
            )

            await reporter.report_progress(
                task.task_id, 92,
                f"validation_retry:{attempt + 1}/{max_retries}",
                output_lines=[
                    f"[daemon] Validation found {len(issues)} issue(s), retrying...",
                    *[f"  {iss}" for iss in issues],
                ],
            )

            # Build a targeted fix prompt
            fix_prompt = (
                "The previous execution produced output with validation errors.\n"
                "Please fix ALL of the following issues:\n\n"
                f"{issues_text}\n\n"
                "Fix the issues in-place. Do NOT recreate files that are already correct.\n"
                "Only fix the specific problems listed above."
            )

            # Override task prompt temporarily
            original_prompt = task.input_prompt
            task.input_prompt = fix_prompt

            try:
                result = await self.process_manager.run_agent(
                    agent, task, workspace_path, on_chunk=on_chunk,
                )
            finally:
                task.input_prompt = original_prompt

        # Final check after all retries
        remaining = self._validate_outputs(workspace_path, task, result)
        if remaining:
            logger.warning(
                "Validation gate: %d issues remain after %d retries for task %s (proceeding anyway)",
                len(remaining), max_retries, task.task_id,
            )
            result.metrics["validation_issues"] = remaining
        return result

    async def _collect_analysis_artifacts(
        self, workspace_path: Path, task: TaskInfo, result: TaskResult
    ) -> None:
        """Read analysis output files from disk and attach as inline artifacts.

        This runs BEFORE _auto_commit so that even if git push fails the backend
        always receives the file contents via the completion report and gate
        reviewers can see the analysis documents immediately.
        """
        doc_dir = (task.input_data or {}).get("output_dir", "")
        if not doc_dir:
            return

        base = workspace_path / doc_dir.lstrip("./")
        _ANALYSIS_FILES = ("PRD.md", "SDD.md", "TASKS.md", "analysis.json", "test-intent.json")
        existing_artifact_paths = {a.get("path", "") for a in result.artifacts}

        for fname in _ANALYSIS_FILES:
            fpath = base / fname
            if not fpath.exists() or fpath.stat().st_size == 0:
                continue
            try:
                rel_path = str(fpath.relative_to(workspace_path))
                if rel_path in existing_artifact_paths:
                    continue  # already attached
                content = fpath.read_text(encoding="utf-8", errors="replace")
                mime = "text/markdown" if fname.endswith(".md") else "application/json"
                result.artifacts.append({
                    "path": rel_path,
                    "content": content,
                    "type": mime,
                })
                logger.debug(
                    "Attached analysis artifact inline: %s (%d bytes)", rel_path, len(content)
                )
            except Exception as e:
                logger.warning("Failed to read analysis artifact %s: %s", fname, e)

    async def _auto_commit(self, workspace_path: Path, task: TaskInfo):
        """Auto-commit and push agent changes.

        Some agents (e.g. claude-code) commit changes internally, so we must
        also push even when the working directory is clean.

        Before pushing, we rebase onto the latest ``origin/{default_branch}``
        so that the PR is based on up-to-date code and avoids unnecessary
        merge conflicts.  If rebase fails (true conflict), we fall back to a
        merge.  If the merge also fails, we invoke the same AI agent to
        resolve the remaining conflicts automatically.
        """
        git = self.workspace_manager._git
        default_branch = task.project.get("default_branch", "main")
        project_key = task.project.get("project_key", "default")

        try:
            has_new_commit = False

            # Check for uncommitted changes
            proc = await asyncio.create_subprocess_exec(
                "git", "status", "--porcelain",
                cwd=str(workspace_path),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await proc.communicate()

            if stdout.strip():
                # Stage all changes
                proc = await asyncio.create_subprocess_exec(
                    "git", "add", "-A",
                    cwd=str(workspace_path),
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await proc.communicate()

                # Collect staged diff stats for rich commit message
                change_summary = await self._collect_staged_diff_stats(workspace_path)

                # Build display title: prefer human-readable title, fallback to req key or UUID
                wi_title = (
                    task.work_item.get("title")
                    or task.input_data.get("title")
                    or ""
                )
                req_key = task.requirement_key or task.work_item.get("requirement_key") or ""
                if req_key and wi_title:
                    display_title = f"{req_key}: {wi_title}"
                elif wi_title:
                    display_title = wi_title
                elif req_key:
                    display_title = req_key
                else:
                    display_title = task.task_id

                commit_msg = await self._build_auto_commit_message(
                    display_title, task.task_id, task.node_type,
                    task.agent_type, change_summary,
                    workspace_path=workspace_path,
                )
                proc = await asyncio.create_subprocess_exec(
                    "git", "commit", "-m", commit_msg,
                    cwd=str(workspace_path),
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    env={**os.environ, "GIT_AUTHOR_NAME": "Forgexa Agent", "GIT_AUTHOR_EMAIL": "agent@forgexa.net",
                         "GIT_COMMITTER_NAME": "Forgexa Agent", "GIT_COMMITTER_EMAIL": "agent@forgexa.net"},
                )
                await proc.communicate()
                has_new_commit = True
                logger.info("Auto-committed changes in %s", workspace_path)
            else:
                logger.info("No uncommitted changes in %s (agent may have committed directly)", workspace_path)

            # ── Pre-push rebase onto latest default branch ──
            # This ensures the AI's branch incorporates the latest remote
            # changes, dramatically reducing PR merge conflicts.
            await self._rebase_onto_latest(workspace_path, default_branch, task, project_key)

            # ── Push ──
            await self._push_branch(workspace_path, project_key)

        except Exception as e:
            logger.warning("Auto-commit failed: %s", e)

    async def _collect_staged_diff_stats(self, cwd: Path) -> dict:
        """Collect staged diff stats for building a rich commit message."""
        status_map: dict[str, str] = {}

        proc = await asyncio.create_subprocess_exec(
            "git", "diff", "--cached", "--name-status",
            cwd=str(cwd),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        out, _ = await proc.communicate()
        for line in out.decode(errors="replace").strip().splitlines():
            parts = line.split("\t", 1)
            if len(parts) == 2:
                status_map[parts[1].strip()] = parts[0].strip()

        files: list[dict] = []
        proc = await asyncio.create_subprocess_exec(
            "git", "diff", "--cached", "--numstat",
            cwd=str(cwd),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        out, _ = await proc.communicate()
        for line in out.decode(errors="replace").strip().splitlines():
            parts = line.split("\t")
            if len(parts) < 3:
                continue
            add_str, del_str, filepath = parts[0], parts[1], parts[2]
            additions = int(add_str) if add_str.isdigit() else 0
            deletions = int(del_str) if del_str.isdigit() else 0
            status = status_map.get(filepath, "M")
            files.append({
                "path": filepath,
                "status": status[0] if status else "M",
                "additions": additions,
                "deletions": deletions,
            })

        proc = await asyncio.create_subprocess_exec(
            "git", "diff", "--cached", "--stat",
            cwd=str(cwd),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        out, _ = await proc.communicate()
        stat_lines = out.decode(errors="replace").strip().splitlines()
        total_stat = stat_lines[-1].strip() if stat_lines else ""

        return {"files": files, "total_stat": total_stat}

    async def _build_auto_commit_message(
        self,
        title: str,
        task_id: str,
        node_type: str,
        agent_type: str,
        change_summary: dict,
        workspace_path: Path | None = None,
    ) -> str:
        """Build a rich, natural-language commit message for daemon auto-commits."""
        files = change_summary.get("files", [])
        total_stat = change_summary.get("total_stat", "")

        # Determine commit type
        if node_type in ("analysis", "planning", "review"):
            commit_type = "docs"
        elif files and all("test" in f["path"].lower() for f in files):
            commit_type = "test"
        elif files and all(
            f["path"].lower().endswith((".md", ".json", ".rst", ".txt"))
            or f["path"].lower().startswith("docs")
            for f in files
        ):
            commit_type = "docs"
        elif "fix" in title.lower():
            commit_type = "fix"
        else:
            commit_type = "feat"

        header = f"{commit_type}({node_type}): {title}"
        if len(header) > 72:
            header = header[:69] + "..."

        parts = [header, ""]

        # ── Analysis/planning phase: extract structured insights from analysis.json ──
        if node_type in ("analysis", "planning") and workspace_path:
            insights = await self._extract_analysis_insights(files, workspace_path)
            if insights:
                parts.extend(insights)
                parts.append("")

        # ── Group files into readable sections ──
        sections = self._group_commit_files(files)
        VERBS = {"A": "Add", "M": "Update", "D": "Remove", "R": "Rename"}
        for section_name, section_files in sections.items():
            parts.append(f"{section_name}:")
            for f in section_files[:15]:
                verb = VERBS.get(f["status"], "Change")
                stats = ""
                if f["additions"] and f["deletions"]:
                    stats = f" (+{f['additions']} \u2212{f['deletions']})"
                elif f["additions"]:
                    stats = f" (+{f['additions']})"
                elif f["deletions"]:
                    stats = f" (\u2212{f['deletions']})"
                parts.append(f"- {verb} {f['path']}{stats}")
            if len(section_files) > 15:
                parts.append(f"  ... and {len(section_files) - 15} more files")
            parts.append("")

        if total_stat:
            parts.append(total_stat)
            parts.append("")
        parts.append(f"Task: {task_id}")
        parts.append(f"Phase: {node_type}")
        parts.append(f"Agent: {agent_type}")

        return "\n".join(parts)

    async def _extract_analysis_insights(
        self, files: list[dict], workspace_path: Path
    ) -> list[str]:
        """Parse analysis.json to produce a natural-language summary for the commit body."""
        import json as _json

        # Locate analysis.json among staged files
        analysis_path: Path | None = None
        for f in files:
            if f["path"].endswith("analysis.json"):
                candidate = workspace_path / f["path"]
                if candidate.exists():
                    analysis_path = candidate
                    break

        if not analysis_path:
            return []

        try:
            data = _json.loads(analysis_path.read_text(encoding="utf-8"))
        except Exception:
            return []

        lines: list[str] = []

        # Summary — word-wrap at 78 chars
        summary = (data.get("summary") or "").strip()
        if summary:
            words = summary.split()
            current = ""
            for word in words:
                if current and len(current) + 1 + len(word) > 78:
                    lines.append(current)
                    current = word
                else:
                    current = (current + " " + word).strip()
            if current:
                lines.append(current)
            lines.append("")

        # Functional requirements
        frs: list = data.get("functional_requirements", [])
        if frs:
            lines.append(f"{len(frs)} functional requirement(s) defined:")
            for fr in frs[:5]:
                lines.append(f"- {str(fr)[:100]}")
            if len(frs) > 5:
                lines.append(f"  ... and {len(frs) - 5} more")

        # Non-functional requirements — count + first few keywords
        nfrs: list = data.get("non_functional_requirements", [])
        if nfrs:
            keywords: list[str] = []
            for nfr in nfrs[:4]:
                text = str(nfr)
                if ":" in text:
                    kw = text.split(":", 1)[1].strip().split()[0].rstrip(".,;").lower()
                    if kw and len(kw) > 2:
                        keywords.append(kw)
            suffix = ", ".join(keywords) + ("..." if len(nfrs) > len(keywords) else "")
            lines.append(
                f"{len(nfrs)} non-functional requirement(s)"
                + (f": {suffix}" if suffix else "")
            )

        # Risks
        risks: list = data.get("risks", [])
        if risks:
            high = [
                r for r in risks
                if isinstance(r, dict) and r.get("impact", "").lower() in ("high", "critical")
            ]
            if high:
                lines.append(f"{len(risks)} risk(s) identified ({len(high)} high-impact):")
                for r in high[:2]:
                    lines.append(f"  - {str(r.get('risk', ''))[:80]}")
            else:
                lines.append(f"{len(risks)} risk(s) identified")

        # Ambiguities
        ambiguities: list = data.get("ambiguities", [])
        if ambiguities:
            lines.append(f"{len(ambiguities)} ambiguity(ies) flagged for clarification")

        return lines

    @staticmethod
    def _group_commit_files(files: list[dict]) -> dict[str, list[dict]]:
        """Group changed files into logical sections for readable commit messages."""
        ORDER = [
            "Analysis deliverables",
            "Backend changes",
            "Frontend changes",
            "Tests",
            "Database / migrations",
            "Documentation",
            "Configuration",
            "Other changes",
        ]
        buckets: dict[str, list[dict]] = {k: [] for k in ORDER}

        for f in files[:30]:
            path = f["path"].lower()
            fname = path.rsplit("/", 1)[-1]
            if "docs/requirements" in path:
                buckets["Analysis deliverables"].append(f)
            elif (
                "_test" in fname or fname.startswith("test_")
                or "/tests/" in path or path.startswith("tests/")
                or fname.endswith((".test.ts", ".test.tsx", ".spec.ts", ".spec.tsx"))
            ):
                buckets["Tests"].append(f)
            elif "alembic" in path or "migration" in path or fname.endswith(".sql"):
                buckets["Database / migrations"].append(f)
            elif (
                path.startswith("frontend/")
                or fname.endswith((".tsx", ".ts", ".jsx", ".js", ".css", ".scss", ".vue"))
            ):
                buckets["Frontend changes"].append(f)
            elif fname.endswith(".py") and not path.startswith("docs/"):
                buckets["Backend changes"].append(f)
            elif fname.endswith((".md", ".rst")) or path.startswith("docs/"):
                buckets["Documentation"].append(f)
            elif fname.endswith((".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf", ".env")) or fname.startswith("."):
                buckets["Configuration"].append(f)
            else:
                buckets["Other changes"].append(f)

        return {k: v for k, v in buckets.items() if v}

    async def _rebase_onto_latest(
        self, workspace_path: Path, default_branch: str, task: TaskInfo,
        project_key: str = "default",
    ):
        """Rebase the current branch onto ``origin/{default_branch}``.

        Strategy (3-tier):
          1. ``git rebase origin/{default_branch}`` — cleanest; linear history.
          2. If rebase conflicts → abort, try ``git merge`` instead.
          3. If merge conflicts → use the AI agent to auto-resolve.
        """
        git = self.workspace_manager._git
        target = f"origin/{default_branch}"

        # Fetch latest remote state
        try:
            await git("fetch", "origin", cwd=workspace_path, timeout=300, project_key=project_key)
        except RuntimeError as exc:
            logger.warning("Pre-push fetch failed: %s — skipping rebase", exc)
            return

        # Check if rebase is needed (any commits on origin/default ahead of us?)
        try:
            behind = await git(
                "rev-list", "--count", f"HEAD..{target}", cwd=workspace_path,
            )
            if behind.strip() == "0":
                logger.info("Branch is already up-to-date with %s", target)
                return
            logger.info("Branch is %s commit(s) behind %s — rebasing", behind.strip(), target)
        except RuntimeError:
            # Can't determine — proceed with rebase anyway
            pass

        # ── Tier 1: rebase ──
        try:
            await git(
                "-c", "user.name=Forgexa Agent",
                "-c", "user.email=agent@forgexa.net",
                "rebase", target,
                cwd=workspace_path, timeout=120,
            )
            logger.info("Rebase onto %s succeeded", target)
            return  # done — clean linear history
        except RuntimeError:
            logger.info("Rebase onto %s had conflicts — aborting rebase", target)
            try:
                await git("rebase", "--abort", cwd=workspace_path)
            except RuntimeError:
                pass  # already aborted or not in rebase state

        # ── Tier 2: merge ──
        try:
            await git(
                "-c", "user.name=Forgexa Agent",
                "-c", "user.email=agent@forgexa.net",
                "merge", target, "--no-edit",
                cwd=workspace_path, timeout=120,
            )
            logger.info("Merge of %s succeeded (no conflicts)", target)
            return
        except RuntimeError:
            logger.info("Merge of %s had conflicts — attempting AI resolution", target)

        # ── Tier 3: AI-assisted conflict resolution ──
        await self._ai_resolve_conflicts(workspace_path, default_branch, task)

    async def _ai_resolve_conflicts(
        self, workspace_path: Path, default_branch: str, task: TaskInfo,
    ):
        """Let the AI agent resolve remaining merge conflicts.

        Reads the conflicted file list and conflict markers, builds a
        targeted prompt, invokes the same agent, then stages resolved files.
        If the agent fails to resolve, we abort the merge to keep the branch
        in a clean state and push whatever we had before.
        """
        git = self.workspace_manager._git

        # 1. List conflicted files
        try:
            diff_out = await git(
                "diff", "--name-only", "--diff-filter=U", cwd=workspace_path,
            )
        except RuntimeError:
            diff_out = ""
        conflicted_files = [f.strip() for f in diff_out.strip().splitlines() if f.strip()]

        if not conflicted_files:
            # No actual conflicts (merge completed or something unusual)
            try:
                await git(
                    "-c", "user.name=Forgexa Agent",
                    "-c", "user.email=agent@forgexa.net",
                    "merge", "--continue", cwd=workspace_path,
                )
            except RuntimeError:
                pass
            return

        logger.info(
            "AI conflict resolution: %d file(s) conflicted: %s",
            len(conflicted_files), ", ".join(conflicted_files[:10]),
        )

        # 2. Read conflict content (capped to avoid enormous prompts)
        conflict_snippets: list[str] = []
        MAX_SNIPPET_CHARS = 3000
        for fpath in conflicted_files[:10]:  # cap at 10 files
            full_path = workspace_path / fpath
            if full_path.exists():
                try:
                    content = full_path.read_text(errors="replace")
                    if len(content) > MAX_SNIPPET_CHARS:
                        content = content[:MAX_SNIPPET_CHARS] + "\n... (truncated)"
                    conflict_snippets.append(f"### {fpath}\n```\n{content}\n```")
                except Exception:
                    conflict_snippets.append(f"### {fpath}\n(could not read)")
            else:
                conflict_snippets.append(f"### {fpath}\n(file not found)")

        # 3. Build a focused prompt for conflict resolution
        resolve_prompt = (
            f"URGENT: There are merge conflicts in the following {len(conflicted_files)} file(s) "
            f"that need to be resolved.\n\n"
            f"The branch was being merged with `origin/{default_branch}`. "
            f"The conflict markers (<<<<<<< HEAD, =======, >>>>>>>) are present in these files.\n\n"
            f"Please resolve ALL conflicts by editing each conflicted file. "
            f"Choose the correct version or combine both sides as appropriate. "
            f"Remove all conflict markers. Do NOT add any new features — only resolve the conflicts.\n\n"
            f"Conflicted files:\n"
            + "\n".join(f"- {f}" for f in conflicted_files)
            + "\n\n"
            + "\n\n".join(conflict_snippets)
        )

        # 4. Find an agent to run the resolution
        agent = self._select_agent(task.agent_type, task.fallback_chain)
        if not agent:
            logger.warning("No agent available for conflict resolution — aborting merge")
            try:
                await git("merge", "--abort", cwd=workspace_path)
            except RuntimeError:
                pass
            return

        # 5. Run the agent with the conflict resolution prompt
        logger.info("Invoking %s to resolve %d conflict(s)...", agent.agent_id, len(conflicted_files))
        try:
            resolve_result = await self.process_manager.run_agent(
                agent,
                TaskInfo(
                    task_id=f"{task.task_id}-conflict-resolve",
                    graph_id=task.graph_id,
                    node_type="conflict_resolution",
                    agent_type=agent.agent_id,
                    input_prompt=resolve_prompt,
                    input_data={},
                    timeout_seconds=min(task.timeout_seconds, 300),  # cap at 5 min
                    max_retries=0,
                    retry_count=0,
                    project=task.project,
                    work_item=task.work_item,
                ),
                workspace_path,
            )

            # 6. Check if conflicts are resolved
            proc = await asyncio.create_subprocess_exec(
                "git", "diff", "--name-only", "--diff-filter=U",
                cwd=str(workspace_path),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await proc.communicate()
            remaining = [f.strip() for f in stdout.decode().strip().splitlines() if f.strip()]

            if remaining:
                logger.warning(
                    "AI agent could not resolve all conflicts (%d remaining) — aborting merge",
                    len(remaining),
                )
                try:
                    await git("merge", "--abort", cwd=workspace_path)
                except RuntimeError:
                    # Hard reset as last resort to get back to clean state
                    await git("reset", "--hard", "HEAD", cwd=workspace_path)
                return

            # 7. Stage resolved files and complete merge
            await git("add", "-A", cwd=workspace_path)
            try:
                await git(
                    "-c", "user.name=Forgexa Agent",
                    "-c", "user.email=agent@forgexa.net",
                    "commit", "--no-edit",
                    cwd=workspace_path,
                )
                logger.info("AI-assisted conflict resolution succeeded for %d file(s)", len(conflicted_files))
            except RuntimeError:
                # commit --no-edit may fail if merge already completed
                logger.info("Merge commit already completed")

        except Exception as exc:
            logger.warning("AI conflict resolution failed: %s — aborting merge", exc)
            try:
                await git("merge", "--abort", cwd=workspace_path)
            except RuntimeError:
                await git("reset", "--hard", "HEAD", cwd=workspace_path)

    async def _push_branch(self, workspace_path: Path, project_key: str = "default"):
        """Push the current branch to origin."""
        git = self.workspace_manager._git
        try:
            # Get current branch name
            branch = (await git("rev-parse", "--abbrev-ref", "HEAD", cwd=workspace_path)).strip()

            if branch and branch != "HEAD":
                # Check if there are unpushed commits
                try:
                    unpushed = (await git(
                        "log", f"origin/{branch}..HEAD", "--oneline", cwd=workspace_path,
                    )).strip()
                except RuntimeError:
                    # origin/{branch} might not exist yet (first push)
                    unpushed = "first-push"

                if unpushed:
                    logger.info("Found unpushed commits on %s, pushing...", branch)
                    try:
                        await git(
                            "push", "--force-with-lease", "-u", "origin", branch,
                            cwd=workspace_path, project_key=project_key,
                        )
                        logger.info("Pushed branch %s to origin", branch)
                    except RuntimeError as exc:
                        logger.warning("Push failed: %s", exc)
                else:
                    logger.info("No unpushed commits on %s", branch)
        except Exception as e:
            logger.warning("Push failed: %s", e)

    def _agents_as_dicts(self) -> list[dict]:
        return [
            {
                "agent_id": a.agent_id,
                "version": a.version,
                "invoke_modes": a.invoke_modes,
                "compatibility_level": a.compatibility_level,
            }
            for a in self.agents
        ]

    async def _shutdown_gracefully(self):
        """Graceful shutdown."""
        logger.info("Shutting down daemon...")
        self._shutdown = True

        # Cancel active tasks
        for task_id, task in self.active_tasks.items():
            task.cancel()
            await self.process_manager.cancel(task_id)

        # Stop all server connections (heartbeat + unregister)
        for conn in self.connections:
            await conn.stop()

        logger.info("Daemon stopped.")

    def handle_signal(self, sig):
        logger.info("Received signal %s", sig)
        self._shutdown = True


async def main():
    daemon = RuntimeDaemon()

    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, daemon.handle_signal, sig)

    await daemon.start()


def main_sync():
    """Synchronous entry point for CLI: forgexa-daemon"""
    asyncio.run(main())


if __name__ == "__main__":
    main_sync()
