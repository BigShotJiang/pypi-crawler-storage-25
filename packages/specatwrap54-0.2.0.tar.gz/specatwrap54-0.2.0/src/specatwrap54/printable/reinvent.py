import polars as pl

lf: pl.LazyFrame = None
# {{paste:begin}}

# {{paste:DIAG_initial_sorting}}

# {{paste:DIAG_stats}}

lf_buggy = (
    lf.with_columns(
        [
            (pl.col("TDiag") == "Death").any().over("case:PNR").alias("has_death"),
            (pl.col("TDiag").last().over("case:PNR") == "Death").alias("is_death_last"),
        ]
    )
    .filter(pl.col("has_death") & ~pl.col("is_death_last"))
    .group_by("case:PNR")
    .agg(pl.col("TDiag").str.join(" -> ").alias("trace"))
)

lf = lf.filter((pl.col("TDiag") == "Death").last().over("case:PNR"))

lf = lf.with_columns(
    (
        pl.col("TDiag") + pl.int_range(1, pl.len() + 1).over("TDiag").cast(pl.String)
    ).over("case:PNR")
)

lf = lf.with_columns(
    pl.when(pl.col("TDiag").str.starts_with("CANCER"))
    .then(
        pl.when(pl.col("TDiag").str.extract(r"(\d+)$").cast(pl.Int32) > 3)
        .then(pl.lit("CANCER3+"))
        .otherwise(pl.col("TDiag"))
    )
    .when(pl.col("TDiag").str.starts_with("CARDIOVASCULAR"))
    .then(
        pl.when(pl.col("TDiag").str.extract(r"(\d+)$").cast(pl.Int32) > 3)
        .then(pl.lit("CARDIOVASCULAR3+"))
        .otherwise(pl.col("TDiag"))
    )
    .when(pl.col("TDiag").str.starts_with("MUSCULOSKELETAL"))
    .then(
        pl.when(pl.col("TDiag").str.extract(r"(\d+)$").cast(pl.Int32) > 2)
        .then(pl.lit("MUSCULOSKELETAL2+"))
        .otherwise(pl.col("TDiag"))
    )
    .otherwise(pl.col("TDiag"))
    .alias("TDiag")
)
