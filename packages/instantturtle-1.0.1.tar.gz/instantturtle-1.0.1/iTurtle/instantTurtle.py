import turtle
import colorsys

t = turtle.Turtle()
c = turtle.Screen()
UIColumn = 0;
UIRow = 0;
maxUIColumn = 0;
maxUIRow = 0;
currentUIObjectPressed = None;
keylist = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
'(', ')', '*', '/', '!', '?', '[', ']', '{', '}']

c.tracer(0)
t.clear()
t.hideturtle()
t.penup()
t.setheading(0)

def drawRect(type, x, y, w, h, c):
    t.penup()
    t.color(colorsys.hsv_to_rgb(*c))
    t.goto(x, y)
    if type == "filled":
        for i in range(h):
            t.pendown()
            for j in range(w):
                t.forward(1)
            t.goto(x, t.ycor())
            t.right(90)
            t.forward(1)
            t.left(90)
        t.setheading(0)
    elif type == "outlined":
        t.forward(w)
        t.right(90)
        t.forward(h)
        t.right(90)
        t.forward(w)
        t.right(90)
        t.forward(h)
        t.right(90)

def drawCircle(x, y, w, h, c):
    t.goto(x, y)
    t.color(colorsys.hsv_to_rgb(*c))
    t.setheading(0)
    for i in range(400):
        t.forward(1)
        t.right(1)

def keyCheck(key):
    def func():
        return True
    c.onkey(func(), key)

def getKey():
    idx = 0
    key = None
    def setkey(i):
        key = i

    for idx in range(len(keylist)):
        t.onkey(setkey(keylist[idx]), keylist[idx])

    return key

def renderTexture(imgpath):
    c.register_shape(imgpath)
    t.shape(imgpath)
            
def renderText(text, x, y):
    t.goto(x, y)
    t.write(text)

def CreateUIObject(name, xp, yp, wb, hb, c, r):
    t.goto(xp, yp)
    if UIColumn == c and UIRow == r and keyCheck("enter"):
        currentUIObjectBeingPressed = name
        drawRect("outlined", xp, yp, wb, hb, [0, 0, 0])
    else:
        currentUIObjectBeingPressed = None



def mainLoop(logic):
    global UIColumn, UIRow

    t.onkey(lambda: [UIColumn := UIColumn + 1] if False else None, "Right")
    t.onkey(lambda: [UIColumn := UIColumn - 1] if False else None, "Left")

    t.onkey(lambda: [UIRow := UIRow + 1] if False else None, "Down")
    t.onkey(lambda: [UIRow := UIRow - 1] if False else None, "Up")

    logic()

    c.update()
   