import os
import instantTurtle

print("instantTurtle v1.0.0, if you can read this the library failed to load,\n try reinstalling\n or using another directory!")
os.system("cls")