import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, Union

import torch
from ax.core.arm import Arm
from ax.core.base_trial import BaseTrial
from ax.exceptions.core import DataRequiredError
from ax.service.ax_client import AxClient, ObjectiveProperties, TParameterization

from ax.core.metric import Metric
from ax.core.objective import MultiObjective as AxMultiObjective
from ax.core.objective import ScalarizedObjective as AxScalarizedObjective
from ax.core.optimization_config import (
    MultiObjectiveOptimizationConfig,
    OptimizationConfig,
)
from ax.core.outcome_constraint import (
    ObjectiveThreshold,
    OutcomeConstraint,
)
from ax.core.types import ComparisonOp

from flowboost.openfoam.case import Case
from flowboost.optimizer.backend import Backend, OptimizationComplete
from flowboost.optimizer.objectives import Objective, ScalarizedObjective
from flowboost.optimizer.scalars import coerce_objective_scalar
from flowboost.optimizer.search_space import Dimension

# Mirrors `ax.generation_strategy.dispatch_utils.DEFAULT_BAYESIAN_CONCURRENCY`.
# We re-declare it so the BO-step parallelism cap stays explicit after we
# disable `enforce_sequential_optimization` (see `AxBackend.initialize`).
DEFAULT_BO_CONCURRENCY = 3


class AxBackend(Backend):
    def __init__(self, stateless: bool = True):
        """Craete an Ax client for Bayesian optimization.

        Args:
            stateless (bool, optional): Re-initialize client on every invokation; slow when using SAASBO. Defaults to True.
        """
        # Inherit main properties from Backend ABC
        super().__init__()

        # Main Ax state
        self.client: AxClient = AxClient()
        self.stateless: bool = stateless

        # Ax-specific options
        self.use_GPU: bool = True
        self.SAASBO: bool = False
        self.max_parallelism: Optional[int] = None
        self.initialization_trials: Optional[int] = None
        self.random_seed: Optional[int] = None
        self.should_deduplicate: bool = True

        # Ax-specific constraints
        self._parameter_constraints: list[str] = []

        # Ax-specific features for noise
        self._SEM_by_objective: dict[str, Optional[float]] = {}
        self._trial_index_case_mapping: dict[Case, int] = {}

    def initialize(self):
        if not self.stateless:
            raise NotImplementedError("Stateful optimizer checkpoints not implemented")

        # Check objectives + dimensions
        self._verify_configuration()

        # Pass the user's full Sobol budget straight through. Ax's
        # `use_existing_trials_for_initialization=True` (default) already
        # counts previously-attached completed trials toward this budget, so
        # shrinking it ourselves here double-counts and silently starves the
        # initialization phase — e.g. `initialization_trials=5` running only
        # 3 Sobol trials before BO takes over, leaving the surrogate badly
        # under-sampled and prone to locking onto boundaries.
        num_init = (
            self.initialization_trials if self.initialization_trials is not None else 5
        )

        logging.info(f"Ax initialization: num_initialization_trials={num_init}")

        if self.max_parallelism is None:
            max_parallelism_override = DEFAULT_BO_CONCURRENCY
        else:
            max_parallelism_override = self.max_parallelism
            if max_parallelism_override > DEFAULT_BO_CONCURRENCY:
                logging.warning(
                    f"max_parallelism={max_parallelism_override} exceeds Ax's "
                    f"recommended BO concurrency ({DEFAULT_BO_CONCURRENCY}); "
                    "the surrogate benefits from more sequential observations."
                )

        # Create a stateless optimizer client. Outcome constraints aren't
        # passed via the string-DSL kwarg here — they're installed structurally
        # by `_install_optimization_config_overrides` once the experiment exists,
        # so the metric references stay typed (vs. parsed from strings).
        self.client.create_experiment(
            parameters=self._get_ax_search_space(),
            objectives=self._get_ax_objectives(),
            parameter_constraints=self._parameter_constraints,
            choose_generation_strategy_kwargs={
                "num_initialization_trials": num_init,
                "use_saasbo": self.SAASBO,
                "disable_progbar": False,
                "max_parallelism_override": max_parallelism_override,
                "random_seed": self.random_seed,
                "should_deduplicate": self.should_deduplicate,
                # Drops the Sobol step's `MaxTrialsAwaitingData` pausing
                # criterion, which otherwise starves low-`num_init` configs
                # after a reload attaches a pending RUNNING trial. Concurrency
                # is still bounded by `MaxGenerationParallelism` via
                # `max_parallelism_override`, and flowboost's Manager caps
                # total in-flight jobs externally.
                "enforce_sequential_optimization": False,
            },
        )

        self._install_optimization_config_overrides()

        # Outcome standardization is handled by Ax: the BoTorch generator's
        # default transform stack applies BilogY → StandardizeY before model
        # fit, and BoTorch's SingleTaskGP wraps outcomes in its own
        # Standardize. Some Ax versions also add Winsorize. Don't add a
        # normalization layer in your Objective.
        logging.info(
            "Ax handles outcome normalization (BilogY → StandardizeY → "
            "GP.Standardize; Winsorize may be present depending on Ax version). "
            "No flowboost-side transforms needed."
        )

        logging.info("Ax experiment initialized")
        self._initialized = True

    def produce_state_snapshot(self, save_in: Path) -> Path:
        """
        Produces a JSON file of the client's settings and state, so that it
        can be restored.

        Args:
            save_in (Path): Directory to produce a JSON file in.

        Raises:
            ValueError: If configuration is invalid

        Returns:
            Path: Path to the saved, time-stamped file
        """
        if not self.offload_acquisition:
            raise ValueError(
                "Acquisition offload not enabled (backend.offload_acquisition)"
            )

        json_path = Path(save_in, "ax_snapshot.json")
        self.client.save_to_json_file(str(json_path))

        logging.info(f"Saved Ax state snapshot [{json_path}]")
        return json_path

    @classmethod
    def offloaded_acquisition(
        cls,
        model_snapshot: Path,
        data_snapshot: Path,
        num_trials: int,
        output_path: Path,
    ):
        # Ensure all files exist
        for p in (model_snapshot, data_snapshot):
            if not p.exists():
                raise FileNotFoundError(f"File not found [{p}]")

        # Restore backend
        logging.info("Restoring Ax backend from state snapshot")
        ax = cls.restore_from_state_snapshot(model_snapshot)

        # Restore data
        with open(data_snapshot, "r") as json_f:
            data = json.load(json_f)

        # Ensure backend types match in data snapshot
        if data["optimizer"] != ax.type:
            raise ValueError(
                f"Optimizer mismatch in data: '{data['optimizer']}' != {ax.type}"
            )

        logging.info(f"Attaching from data snapshot ({data['created_at']})")

        # Attach finished trials to backend
        logging.info("Attaching finished trials")
        for case_name, data_dict in data["finished_cases"].items():
            idx = ax._attach_trial_with_case_name(
                parameters=data_dict["parametrization"],
                case_name=case_name,
            )

            # TODO support user's noise preference!
            raw_data = {
                obj_name: (
                    coerce_objective_scalar(
                        outcome,
                        label=f"Offloaded objective '{obj_name}' output",
                    ),
                    0.0,
                )
                for obj_name, outcome in data_dict["objectives"].items()
            }

            ax.client.complete_trial(trial_index=idx, raw_data=raw_data)

        # Attach pending trials to backend
        logging.info("Attaching pending trials")
        for case_name, data_dict in data["pending_cases"].items():
            idx = ax._attach_trial_with_case_name(
                parameters=data_dict["parametrization"],
                case_name=case_name,
            )

        # Run acquisition.  Note: unlike `_ask()`, we do NOT seed torch
        # here.  The restored backend has no access to the user's
        # `random_seed` (it is not part of the Ax JSON snapshot), and
        # offloaded acquisition runs in a separate process on a cluster
        # node where the global torch state is inherently uncontrolled.
        # Determinism across offloaded runs is not guaranteed.
        logging.info("Data loaded: running model update + acquisition")
        new_parametrizations, finished = ax.client.get_next_trials(
            max_trials=num_trials
        )

        if finished:
            # TODO add to json as a field
            logging.info("Optimization finished")

        logging.info(f"Received {len(new_parametrizations)} new trial(s) from Ax")

        snapshot = {
            "optimizer": ax.type,
            "created_at": datetime.now(tz=timezone.utc).isoformat(),
            "status_finished": finished,
            "parametrizations": new_parametrizations,
        }

        with open(output_path, "w") as json_f:
            json.dump(snapshot, json_f)

        logging.info(f"Wrote acquisition snapshot to file [{output_path}]")

    @classmethod
    def restore_from_state_snapshot(cls, from_file: Path) -> "AxBackend":
        """
        Restore Ax state from a json snapshot. Used for acquisition offloading.

        Args:
            from_file (Path): JSON file to restore from

        Raises:
            FileNotFoundError: If file not found

        Returns:
            AxBackend: Restored Ax client
        """
        ax = cls()
        if not from_file.exists():
            raise FileNotFoundError(f"Ax snapshot file not found: {from_file}")

        with open(from_file, "r") as json_f:
            json_d = json.load(json_f)
            ax.client = AxClient.from_json_snapshot(json_d)

        logging.info("Restored Ax state from json snapshot")
        return ax

    def _re_initialize_client(self):
        """Re-initialize the Ax client in order to re-build the surrogate
        function.

        Raises:
            ValueError: If stateless mode is not active
        """
        if not self.stateless:
            raise ValueError("Re-initialize should not be called when stateless=False")
        self.client = AxClient()
        self._trial_index_case_mapping = {}
        self.initialize()

    def set_objectives(
        self, objectives: Union[Objective, ScalarizedObjective, list[Objective]]
    ):
        if isinstance(objectives, (Objective, ScalarizedObjective)):
            objectives = [objectives]
        if (
            any(isinstance(o, ScalarizedObjective) for o in objectives)
            and len(objectives) > 1
        ):
            raise ValueError(
                "ScalarizedObjective must be the only top-level objective; "
                "mixing it with other objectives is not supported."
            )
        self.objectives = objectives

    def set_search_space(self, dimensions: list[Dimension]):
        if isinstance(dimensions, Dimension):
            dimensions = [dimensions]

        self.dimensions = dimensions

    def set_parameter_constraints(self, constraints: list[str]):
        """Allows setting parameter constraints using string-based mathematical
        expressions for range-parameters.

        Ax does not support parameter constraints on logarithmic dimensions.

        Examples: `"x3 >= x4"` or `"-x3 + 2*x4 - 3.5*x5 >= 2"`

        See Ax's documentation for `ParameterConstraint` for additional docs.

        Args:
            constraints (list[str]): Parameter constraints to apply on optimizer.
        """
        self._parameter_constraints = constraints

    def attach_pending_cases(self, cases: list[Case]):
        if cases:
            logging.info(f"Attaching {len(cases)} pending case(s) to the model")

        # Ensure all cases have been attached as trials to Ax
        self._ensure_attached(cases)

    def attach_failed_cases(self, cases: list[Case]):
        if not cases:
            return

        self._ensure_attached(cases)

        # Perform attach
        for case in cases:
            """
            "The difference between abandonment and failure is that the FAILED
            state is meant to express a possibly transient or retryable error,
            so trials in that state may be re-run and arm(s) in them may be
            resuggested by Ax models to be added to new trials."

            https://ax.dev/api/core.html#ax.core.base_trial.TrialStatus
            """
            if case not in self._trial_index_case_mapping:
                raise ValueError(
                    f"Case not in trial mapping, cannot mark failed [{case}]"
                )

            trial_idx = self._trial_index_case_mapping[case]
            trial = self.client.get_trial(trial_idx)

            if not self._can_abandon_trial(trial):
                continue

            logging.info(f"Marking as abandoned: {case}")
            self.client.abandon_trial(trial_idx)

    def tell_and_ask(
        self, cases: list[Case], max_cases: int
    ) -> list[dict[Dimension, Any]]:
        """
        A shorthand for first calling tell() and then ask().

        Args:
            cases (list[Case]): List of evaluated cases
            max_cases (int): Maximum number of cases to yield. May be less \
                during the initial Sobol' sequence seeding phase.

        Returns:
            list[dict[Dimension, Any]]: List of dictionaries, each dictionary \
                having Dimension-value kv-pairs ready to be generated into \
                a new case. One dictionary per case.
        """
        self.tell(cases)
        return self.ask(max_cases=max_cases)

    def _ask(self, max_cases: int) -> dict[int, TParameterization]:
        # Ax's `random_seed` only controls the Sobol engine; the BO
        # acquisition optimizer's random restarts consume from the global
        # PyTorch RNG, which makes results non-deterministic across
        # separate replay sessions.  Seeding torch here with a value
        # derived from `random_seed` and the current trial count makes
        # BO suggestions reproducible given the same experiment state.
        if self.random_seed is not None:
            n_trials = len(self.client.experiment.trials)
            torch.manual_seed(self.random_seed + n_trials)

        try:
            new_parametrizations, finished = self.client.get_next_trials(
                max_trials=max_cases
            )
        except DataRequiredError as exc:
            raise ValueError(
                "Cannot generate trials: the optimizer has no observations to "
                "fit a surrogate on. This happens when `initialization_trials="
                f"{self.initialization_trials}` is 0 (or too low) and no "
                "completed trials are attached. Either raise "
                "`initialization_trials` (5+ is a reasonable default), or "
                "feed cold-start trials via `Backend.tell(...)` before calling "
                "`ask()`."
            ) from exc

        if finished:
            logging.info("Optimization finished")
            raise OptimizationComplete(
                "Ax reports the optimization is finished; no further trials "
                "can be generated."
            )

        logging.info(f"Received {len(new_parametrizations)} new trial(s) from Ax")

        # Empty is a legitimate mid-run state — e.g. the current generation
        # node is at its parallelism cap and needs more completions before it
        # can advance. Return empty and let the caller decide (Session will
        # skip this cycle).
        return new_parametrizations

    def tell(self, cases: list[Case]):
        """
        Inform Ax of evaluated cases, updating the surrogate function and
        preparing the optimizer for the next acquisition event.

        The cases are expected to have been already evaluated by the
        objective functions.

        Args:
            cases (list[Case]): List of evaluated cases
        """
        if self.stateless:
            self._re_initialize_client()
        else:
            raise NotImplementedError("Stateful tell() not implemented")

        # TODO handle failure criteria here

        # Gather metric values for every registered objective AND constraint —
        # Ax expects raw_data to cover all metrics it knows about, including
        # tracking metrics referenced by outcome constraints. Missing any
        # one of them silently marks the trial failed.
        logging.info("Retrieving metric values for case completion")
        registered_metrics = [*self.objectives, *self.constraints]
        case_objective_outputs: dict[Case, dict] = {
            c: c.objective_function_outputs(registered_metrics) for c in cases
        }

        logging.info(f"Ax search space: {self._get_ax_search_space()}")

        # Ensure all cases have been attached as trials to Ax
        self._ensure_attached(cases)

        # Complete case trials
        self._complete_trials(cases, case_objective_outputs)

    def get_model_prediction(self, case: Case):
        if case not in self._trial_index_case_mapping:
            return None

        parametrization = self.client.get_trial_parameters(
            trial_index=self._trial_index_case_mapping[case]
        )

        # Get model's predictions for this parameterization
        logging.info("Getting model predictions for parameterization")

        try:
            prediction = self.client.get_model_predictions_for_parameterizations(
                parameterizations=[parametrization]
            )[0]
        except NotImplementedError:
            # Predictions are not implemented for Sobol generation phase: OK
            return None
        except Exception:
            logging.exception(
                f"Could not get model predictions for parameterization={parametrization}"
            )
            return None

        return prediction

    def _post_process_suggestion_parametrizations(
        self, parametrizations: dict[int, dict[str, Any]]
    ) -> list[dict[Dimension, Any]]:
        """
        Converts the list of string-keyed dictionaries, mapping search space
        dimensions to values to evaluate, to be keyed by Dimension objects.

        Args:
            parametrizations (dict): Trial indices mapped to parametrization \
                dictionaries.

        Returns:
            list[dict[Dimension, Any]]: Dimension-keyed list of \
                parametrizations.
        """
        processed: list[dict[Dimension, Any]] = []

        # For each parametrization, convert the str-keys to be Dimensions
        for trial_index, parametrization in parametrizations.items():
            new_suggestion: dict[Dimension, Any] = {}
            for str_key, val in parametrization.items():
                dim = self._dim_name_to_dimension(str_key)
                new_suggestion[dim] = val

            processed.append(new_suggestion)

        return processed

    def _ensure_attached(self, cases: list[Case]):
        """
        Attach creates new Trials from the Case objects by linking their
        points in the search space dimensions to the optimizer. Does not allow
        for cases to be attached more than once.

        Attachment can be done before the cases have been evaluated.

        Args:
            cases (list[Case]): Cases to attach as trials.
            parametrizations (dict[Case, dict], optional): Pre-computed \
                parametrizations for each case. Parametrizations are dicts, \
                mapping all search space dimension names to a value.
        """
        attached = 0
        skipped = 0
        for case in cases:
            if case in self._trial_index_case_mapping:
                logging.debug(f"Case already attached, skipping: {case}")
                skipped += 1
                continue

            # Generate parametrizations: these describe the search space for Ax.
            # Type coercion is handled by Case.parametrize_configuration().
            p = case.parametrize_configuration(self.dimensions)

            logging.debug(f"Attaching c={case.name}, p={p}")
            idx = self._attach_trial_with_case_name(parameters=p, case_name=case.name)

            # TODO if we were to run in stateful mode, we'd stash the index
            self._trial_index_case_mapping[case] = idx
            attached += 1

        if attached or skipped:
            logging.info(
                f"Attached {attached} trial(s), skipped {skipped} already-attached"
            )

    def _attach_trial_with_case_name(
        self, parameters: TParameterization, case_name: str
    ) -> int:
        """Attach a trial while preserving Ax's existing arm identity for duplicates."""
        arm_name = self._arm_name_for_attachment(
            parameters=parameters,
            case_name=case_name,
        )
        _, trial_index = self.client.attach_trial(
            parameters=parameters,
            arm_name=arm_name,
        )
        return trial_index

    def _arm_name_for_attachment(
        self, parameters: TParameterization, case_name: str
    ) -> str:
        """Return the correct arm name for this parameterization in the experiment."""
        existing_arm = self.client.experiment.arms_by_signature.get(
            Arm.md5hash(parameters)
        )
        if existing_arm is None:
            return case_name

        if existing_arm.name != case_name:
            logging.info(
                "Reusing existing arm '%s' for duplicate parameters from case '%s'",
                existing_arm.name,
                case_name,
            )
        return existing_arm.name

    def _can_abandon_trial(self, trial: BaseTrial) -> bool:
        if trial is None:
            return False

        # Check if trial is already complete, failed, or abandoned
        if (
            trial.status.is_terminal
            or trial.status.is_abandoned
            or trial.status.is_failed
            or trial.status.is_completed
        ):
            logging.warning(
                f"Trial {trial} is already terminal/abandoned/failed/completed"
            )
            return False

        return True

    def _complete_trials(
        self, cases: list[Case], objective_f_outputs: dict[Case, dict]
    ):
        for case in cases:
            if case not in self._trial_index_case_mapping:
                raise ValueError(
                    f"Case not in trial index mapping, cannot complete trial [{case}]"
                )

            # Construct tuple-based result for case: see Ax TEvaluationOutcome
            raw_data = {
                obj_name: (
                    coerce_objective_scalar(
                        outcome,
                        label=f"Objective '{obj_name}' output for Ax",
                    ),
                    self._SEM_by_objective.get(obj_name, 0.0),
                )
                for obj_name, outcome in objective_f_outputs[case].items()
            }

            self.client.complete_trial(
                trial_index=self._trial_index_case_mapping[case],
                raw_data=raw_data,
            )

    def _get_ax_objectives(self) -> dict[str, ObjectiveProperties]:
        """Build the per-metric registration passed to AxClient.create_experiment.

        For top-level Objectives, the objective is the metric. For a top-level
        ScalarizedObjective, each inner Objective is registered as its own
        metric so Ax models them independently; the single-objective scalarized
        OptimizationConfig is then installed by `_install_optimization_config_overrides`.
        """
        ax_objectives: dict[str, ObjectiveProperties] = {}
        for objective in self.objectives:
            if isinstance(objective, ScalarizedObjective):
                for inner in objective.objectives:
                    ax_objectives[inner.name] = ObjectiveProperties(
                        minimize=inner.minimize, threshold=inner.threshold
                    )
            else:
                ax_objectives[objective.name] = ObjectiveProperties(
                    minimize=objective.minimize, threshold=objective.threshold
                )

        return ax_objectives

    def _install_optimization_config_overrides(self) -> None:
        """Install structural overrides that AxClient.create_experiment can't
        express directly: native ScalarizedObjective for the optimization
        target, and OutcomeConstraints derived from gte/lte fields on
        Objectives or pure Constraint instances.

        For each Constraint, also registers a tracking metric on the
        experiment so Ax knows about the metric name when it appears in
        raw_data during tell(). Without this registration, the trial is
        silently marked failed by AxClient (it expects raw_data to cover
        only registered metrics).

        If neither overrides nor constraints are present, leaves Ax's default
        config in place.
        """
        scalarized = [o for o in self.objectives if isinstance(o, ScalarizedObjective)]
        bounded_objectives = list(self._iter_bounded_objectives())
        if not scalarized and not self.constraints and not bounded_objectives:
            return

        # Register Constraint metrics as tracking metrics so they exist in
        # experiment.metrics before we reference them in OutcomeConstraints
        # (and so AxClient expects their values in raw_data).
        for c in self.constraints:
            if c.name not in self.client.experiment.metrics:
                self.client.experiment.add_tracking_metric(Metric(name=c.name))

        # Register derived bound metrics for Objectives carrying gte/lte.
        # Ax rejects OutcomeConstraints attached to objective metrics, so the
        # bound is hung off a sibling tracking metric whose value mirrors the
        # objective's at tell() time.
        for obj in bounded_objectives:
            if obj.bound_metric_name not in self.client.experiment.metrics:
                self.client.experiment.add_tracking_metric(
                    Metric(name=obj.bound_metric_name)
                )

        # Pick the objective: existing one if no ScalarizedObjective override,
        # otherwise build an Ax-native ScalarizedObjective referencing the
        # already-registered inner metrics.
        if scalarized:
            flowboost_obj = scalarized[0]
            metrics = [
                self.client.experiment.metrics[inner.name]
                for inner in flowboost_obj.objectives
            ]
            ax_objective = AxScalarizedObjective(
                metrics=metrics,
                weights=flowboost_obj.weights,
                minimize=flowboost_obj.minimize,
            )
        else:
            ax_objective = self.client.experiment.optimization_config.objective

        outcome_constraints = self._build_outcome_constraints()

        # MultiObjective requires the MOO-flavored config (which carries the
        # objective_thresholds field). Keep any thresholds Ax inferred for us
        # at create_experiment time so we don't drop user-set ones.
        if isinstance(ax_objective, AxMultiObjective):
            existing = self.client.experiment.optimization_config
            existing_thresholds: list[ObjectiveThreshold] = list(
                getattr(existing, "objective_thresholds", []) or []
            )
            self.client.experiment.optimization_config = (
                MultiObjectiveOptimizationConfig(
                    objective=ax_objective,
                    outcome_constraints=outcome_constraints,
                    objective_thresholds=existing_thresholds,
                )
            )
        else:
            self.client.experiment.optimization_config = OptimizationConfig(
                objective=ax_objective,
                outcome_constraints=outcome_constraints,
            )

    def _build_outcome_constraints(self) -> list[OutcomeConstraint]:
        """Build OutcomeConstraints from the gte/lte on each registered
        Constraint and from the gte/lte on each bounded Objective (whose
        bounds are hung off a derived tracking metric named
        ``{obj.name}__bound``). Bounds are absolute (`relative=False`) — Ax
        defaults to relative, which would silently change the meaning of
        every constraint.

        Assumes the relevant tracking metrics have already been registered
        on the experiment.
        """
        constraints: list[OutcomeConstraint] = []
        for c in self.constraints:
            metric = self.client.experiment.metrics[c.name]
            if c.gte is not None:
                constraints.append(
                    OutcomeConstraint(
                        metric=metric, op=ComparisonOp.GEQ, bound=c.gte, relative=False
                    )
                )
            if c.lte is not None:
                constraints.append(
                    OutcomeConstraint(
                        metric=metric, op=ComparisonOp.LEQ, bound=c.lte, relative=False
                    )
                )
        for obj in self._iter_bounded_objectives():
            metric = self.client.experiment.metrics[obj.bound_metric_name]
            if obj.gte is not None:
                constraints.append(
                    OutcomeConstraint(
                        metric=metric,
                        op=ComparisonOp.GEQ,
                        bound=obj.gte,
                        relative=False,
                    )
                )
            if obj.lte is not None:
                constraints.append(
                    OutcomeConstraint(
                        metric=metric,
                        op=ComparisonOp.LEQ,
                        bound=obj.lte,
                        relative=False,
                    )
                )
        return constraints

    def _iter_bounded_objectives(self):
        """Walk every `Objective` carrying `gte`/`lte`, whether registered
        directly or as an inner term of a `ScalarizedObjective`. Each yielded
        Objective has `has_bounds == True` and a `bound_metric_name`."""
        for obj in self.objectives:
            if isinstance(obj, ScalarizedObjective):
                for inner in obj.objectives:
                    if inner.has_bounds:
                        yield inner
            elif isinstance(obj, Objective) and obj.has_bounds:
                yield obj

    def _dim_to_Ax_parameter_dict(self, dim: Dimension) -> dict[str, Any]:
        d: dict[str, Any] = {
            "name": dim.name,
            "type": dim.type,
            "value_type": dim.value_type,
        }

        match dim.type:
            case "range":
                d["bounds"] = dim.bounds
                d["log_scale"] = dim.log_scale
                d["digits"] = dim.digits
            case "choice":
                d["values"] = dim.values
                d["is_ordered"] = dim.is_ordered
            case "fixed":
                if not dim.values:
                    raise ValueError("Fixed dimension must have a specified value")

                d["value"] = dim.values[0]
            case _:
                raise ValueError(f"Dimension type '{dim.type} not supported'")

        return d

    def _get_ax_search_space(self):
        return [self._dim_to_Ax_parameter_dict(d) for d in self.dimensions]
