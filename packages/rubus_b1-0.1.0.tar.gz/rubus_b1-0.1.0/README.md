##Rubus

-->A tree-walking interpreter for the custom Rubus programming language, bundled with rubed, a lightweight, terminal-based text editor built specifically for writing and executing .rub files.
Overview

-->The Rubus ecosystem consists of a Python-like, indentation-based programming language and a dedicated command-line environment. The interpreter processes raw source code through a lexer and parser to build an Abstract Syntax Tree (AST), which is then directly executed without an intermediate compilation step or bytecode generation.
Features
##The Rubus Language

    -(if/elif/else, for, while).

    -support for integers, floats, booleans, strings, and f-strings.

    -Built-in lists, dictionaries, sets, and tuples.

    -List and dictionary comprehensions.

    -Custom struct definitions 

    -function definitions (def) and variable declarations (let).

    -lexical scoping and environment management for variables.

##The Rubus Editor (rubed)

    -->Terminal-Native: Built with curses for a seamless command-line workflow.

    Syntax Highlighting: Real-time colorization for keywords, types, strings, numbers, comments, and operators.

    Integrated Execution: Run your .rub scripts directly from within the editor.

    Core Keybindings:

        -->Ctrl+S: Save file

        -->Ctrl+R: Run the current file through the Rubus interpreter

        -->Ctrl+N: Open a new buffer

        -->Ctrl+O: Open an existing file

        -->Ctrl+Q: Quit (with unsaved changes prompt)

##Usage

-You can use rubed.py as both an interactive editor and a headless runner for your scripts.

Launch the editor with an empty buffer:
bash
```
python rubed.py

Open a specific file in the editor:
```
bash
```
python rubed.py path/to/script.rub

Run a script headlessly (no need for the editor):
```

python rubed.py path/to/script.rub --run

