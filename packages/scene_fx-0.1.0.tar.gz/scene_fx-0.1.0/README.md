# scene-fx

25 temporal video effects (speed ramp, slow-mo, beat sync, echo, strobe, boomerang, freeze zoom) plus 25 AI/CV effect stubs deferred to v0.2.

```python
from scene_fx import apply_temporal, apply_speed_ramp, beat_synced_effect, list_effects

# Speed ramp: slow down at midpoint, speed up
apply_speed_ramp("clip.mp4", ramp_curve=[(0.0, 1.0), (2.0, 0.25), (4.0, 1.0)], output="ramped.mp4")

# Beat-synced flash
beat_synced_effect("dance.mp4", audio="track.mp3", effect="beat_flash", output="rhythmic.mp4")

# Motion echo ghost trail
apply_temporal("raw.mp4", effect="motion_echo", output="echo.mp4")

# Discover effects
list_effects()                          # 25 active temporal effects
list_effects(include_deferred=True)     # 50 total (25 + 25 AI/CV stubs)
```

Part of the Trollfabriken video-effects family: `video-fx` · `watch-cast` · `overlay-cast` · `scene-fx`.

Built at Trollfabriken AITrix AB · PyPI: `opusmorale` · GitHub: `tomastimelock`
