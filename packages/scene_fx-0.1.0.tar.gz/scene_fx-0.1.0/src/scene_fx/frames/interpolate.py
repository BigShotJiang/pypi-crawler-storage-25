from __future__ import annotations

import numpy as np


def interpolate_frames(frame_a: np.ndarray, frame_b: np.ndarray, alpha: float) -> np.ndarray:
    """Blend two RGBA frames with weight alpha (0=a, 1=b)."""
    a = frame_a.astype(np.float32)
    b = frame_b.astype(np.float32)
    return np.clip(a * (1 - alpha) + b * alpha, 0, 255).astype(np.uint8)


def slow_motion_interpolate(frames: list[np.ndarray], factor: int) -> list[np.ndarray]:
    """Insert interpolated frames between each pair for slow-motion effect."""
    if factor <= 1 or len(frames) < 2:
        return list(frames)
    result = []
    for i in range(len(frames) - 1):
        result.append(frames[i])
        for j in range(1, factor):
            alpha = j / factor
            result.append(interpolate_frames(frames[i], frames[i + 1], alpha))
    result.append(frames[-1])
    return result
