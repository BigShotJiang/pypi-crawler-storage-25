from __future__ import annotations

from collections import deque

import numpy as np


class FrameRingBuffer:
    """Fixed-size ring buffer for frame echo/blend effects."""

    def __init__(self, capacity: int) -> None:
        self._buf: deque[np.ndarray] = deque(maxlen=capacity)
        self.capacity = capacity

    def push(self, frame: np.ndarray) -> None:
        self._buf.append(frame)

    def frames(self) -> list[np.ndarray]:
        return list(self._buf)

    def blend(self, current: np.ndarray, decay: float = 0.6) -> np.ndarray:
        """Blend current frame with buffered frames using exponential decay."""
        if not self._buf:
            return current
        result = current.astype(np.float32)
        weight = decay
        for frame in reversed(self._buf):
            result += frame.astype(np.float32) * weight
            weight *= decay
        return np.clip(result / (1 + decay), 0, 255).astype(np.uint8)
