from __future__ import annotations


class SceneFxError(Exception):
    pass


class EffectNotFoundError(SceneFxError):
    def __init__(self, slug: str) -> None:
        super().__init__(f"Effect not found: {slug!r}")
        self.slug = slug


class CatalogLoadError(SceneFxError):
    pass


class RenderError(SceneFxError):
    pass


class TemporalConfigError(SceneFxError):
    pass
