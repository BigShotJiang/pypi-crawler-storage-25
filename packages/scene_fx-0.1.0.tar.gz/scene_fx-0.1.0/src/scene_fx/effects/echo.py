from __future__ import annotations

import numpy as np

from scene_fx.config import TemporalConfig
from scene_fx.frames.buffer import FrameRingBuffer


def _rw(video_path: str):
    from video_fx.frames import read_frames, write_frames
    frames, info = read_frames(video_path)
    return frames, info, write_frames


def motion_echo(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    buf = FrameRingBuffer(config.echo_count)
    result = []
    for frame in frames:
        blended = buf.blend(frame, config.echo_decay)
        result.append(blended)
        buf.push(frame)
    write_frames(result, info, video_path, config.output)
    return config.output


def frame_blend(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    result = []
    for i in range(len(frames)):
        if i < len(frames) - 1:
            blended = np.clip(
                (frames[i].astype(np.float32) + frames[i + 1].astype(np.float32)) / 2,
                0, 255
            ).astype(np.uint8)
            result.append(blended)
        else:
            result.append(frames[i])
    write_frames(result, info, video_path, config.output)
    return config.output


def echo_delay(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    fps = info.get("fps", 25)
    delay = max(1, int(fps * 0.5))
    result = []
    for i, frame in enumerate(frames):
        delayed_idx = max(0, i - delay)
        delayed = frames[delayed_idx].astype(np.float32)
        blended = np.clip(
            frame.astype(np.float32) * 0.7 + delayed * 0.3, 0, 255
        ).astype(np.uint8)
        result.append(blended)
    write_frames(result, info, video_path, config.output)
    return config.output


def temporal_smear(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    n_avg = max(2, config.echo_count)
    result = []
    for i, frame in enumerate(frames):
        indices = range(max(0, i - n_avg // 2), min(len(frames), i + n_avg // 2 + 1))
        group = [frames[j].astype(np.float32) for j in indices]
        avg = np.mean(group, axis=0)
        result.append(np.clip(avg, 0, 255).astype(np.uint8))
    write_frames(result, info, video_path, config.output)
    return config.output
