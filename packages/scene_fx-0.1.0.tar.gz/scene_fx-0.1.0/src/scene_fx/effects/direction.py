from __future__ import annotations

import numpy as np

from scene_fx.config import TemporalConfig


def _rw(video_path: str):
    from video_fx.frames import read_frames, write_frames
    frames, info = read_frames(video_path)
    return frames, info, write_frames


def reverse(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    result = list(reversed(frames))
    write_frames(result, info, video_path, config.output)
    return config.output


def boomerang_loop(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    result = list(frames) + list(reversed(frames))
    write_frames(result, info, video_path, config.output)
    return config.output


def rewind_glitch(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    rng = np.random.default_rng(config.seed or 42)
    reversed_frames = list(reversed(frames))
    result = []
    fps = info.get("fps", 25)
    for i, frame in enumerate(reversed_frames):
        if i % max(1, int(fps * 0.25)) == 0:
            glitch = frame.copy()
            noise = rng.integers(-30, 30, glitch.shape, dtype=np.int16)
            glitch[:, :, :3] = np.clip(glitch[:, :, :3].astype(np.int16) + noise[:, :, :3], 0, 255).astype(np.uint8)
            # Horizontal shift
            shift = int(rng.integers(4, 16))
            glitch[:, shift:, :] = glitch[:, :-shift, :]
            result.append(glitch)
        else:
            result.append(frame)
    write_frames(result, info, video_path, config.output)
    return config.output
