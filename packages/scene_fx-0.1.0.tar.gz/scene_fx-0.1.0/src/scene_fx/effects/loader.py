from __future__ import annotations

import json
from pathlib import Path

from scene_fx.exceptions import CatalogLoadError, EffectNotFoundError

_CATALOG_PATH = Path(__file__).parent.parent / "data" / "temporal_catalog.json"
_catalog: dict[str, dict] | None = None


def _load() -> dict[str, dict]:
    global _catalog
    if _catalog is not None:
        return _catalog
    data = json.loads(_CATALOG_PATH.read_text(encoding="utf-8"))
    entries = data["transitions"]
    if len(entries) != 50:
        raise CatalogLoadError(f"Expected 50 effects, got {len(entries)}")
    _catalog = {e["slug"]: e for e in entries}
    return _catalog


def list_effects(include_deferred: bool = False) -> list[str]:
    cat = _load()
    if include_deferred:
        return sorted(cat.keys())
    return sorted(slug for slug, e in cat.items() if e.get("status") != "deferred_v0_2")


def get_effect(slug: str) -> dict:
    cat = _load()
    if slug not in cat:
        raise EffectNotFoundError(slug)
    return cat[slug]
