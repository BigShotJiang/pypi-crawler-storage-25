from __future__ import annotations

import cv2

from scene_fx.config import TemporalConfig


def _rw(video_path: str):
    from video_fx.frames import read_frames, write_frames
    frames, info = read_frames(video_path)
    return frames, info, write_frames


def time_freeze_subject(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    fps = info.get("fps", 25)
    mid = len(frames) // 2
    freeze_n = max(1, int(fps * config.freeze_duration))
    result = list(frames[:mid]) + [frames[mid]] * freeze_n + list(frames[mid:])
    write_frames(result, info, video_path, config.output)
    return config.output


def poster_frame_hold(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    fps = info.get("fps", 25)
    hold_n = max(1, int(fps * config.freeze_duration))
    result = list(frames) + [frames[-1]] * hold_n
    write_frames(result, info, video_path, config.output)
    return config.output


def freeze_zoom(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    fps = info.get("fps", 25)
    mid = len(frames) // 2
    freeze_n = max(1, int(fps * config.freeze_duration))
    h, w = frames[0].shape[:2]
    freeze_frames = []
    for j in range(freeze_n):
        t = j / max(1, freeze_n - 1)
        scale = 1.0 + 0.3 * t
        new_w, new_h = int(w * scale), int(h * scale)
        zoomed = cv2.resize(frames[mid][:, :, :3], (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        # Center crop back to original size
        ox = (new_w - w) // 2
        oy = (new_h - h) // 2
        cropped_rgb = zoomed[oy:oy + h, ox:ox + w]
        out = frames[mid].copy()
        out[:, :, :3] = cropped_rgb
        freeze_frames.append(out)
    result = list(frames[:mid]) + freeze_frames + list(frames[mid:])
    write_frames(result, info, video_path, config.output)
    return config.output


def instant_replay(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    fps = info.get("fps", 25)
    replay_n = max(1, int(fps * 1.0))
    tail = frames[-replay_n:]
    result = list(frames) + list(reversed(tail)) + list(tail)
    write_frames(result, info, video_path, config.output)
    return config.output
