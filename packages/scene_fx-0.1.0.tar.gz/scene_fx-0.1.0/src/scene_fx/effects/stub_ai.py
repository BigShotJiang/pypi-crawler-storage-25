from __future__ import annotations

DEFERRED_ALTERNATIVES: dict[str, list[str]] = {
    "background_blur": ["watch-cast face_blur_overlay (for faces)", "explicit mask via mask_image"],
    "background_replace": ["video-fx blend + manual mask"],
    "green_screen_key": ["ffmpeg chromakey filter directly"],
    "sky_replacement": ["color-based mask + video-fx blend"],
    "object_highlight": ["video-fx neon_edge + manual region"],
    "subject_outline": ["video-fx neon_edge"],
    "auto_reframe": ["manual crop via ffmpeg"],
    "face_mosaic": ["watch-cast face_blur_overlay"],
    "license_plate_blur": ["watch-cast plate_reader_camera with privacy mode"],
    "pose_skeleton_overlay": [],
    "object_tracker_label": ["watch-cast tracking_target_box (manual)"],
    "depth_fog": ["video-fx fog or haze"],
    "depth_parallax": [],
    "motion_trails_subject": ["scene-fx motion_echo (no mask)"],
    "rotoscope_cutout": [],
    "person_cutout_glow": ["video-fx neon_edge + manual mask"],
    "eye_zoom_auto": ["manual crop + scene-fx freeze_zoom"],
    "product_highlight": ["video-fx neon_edge + manual region"],
    "smart_scene_relight": ["video-fx cinematic_color presets"],
    "auto_color_match": [],
    "crowd_blur": ["video-fx background_blur with manual mask"],
    "document_redaction": ["overlay-cast redaction_bars"],
    "logo_detection_blur": ["watch-cast pixelated_privacy_mask"],
    "gesture_trigger_effect": [],
    "semantic_spotlight": ["video-fx light_layer + manual mask"],
}


def _make_deferred_message(slug: str, display_name: str, alternatives: list[str]) -> str:
    if alternatives:
        alt_str = ", ".join(f"'{a}'" for a in alternatives[:3])
        alt_part = f"For v0.1 alternatives: {alt_str}."
    else:
        alt_part = "No v0.1 alternative available yet."
    return (
        f"scene-fx effect '{slug}' ({display_name}) requires AI model integration "
        f"(MediaPipe/rembg), planned for v0.2. Track at "
        f"https://github.com/tomastimelock/scene-fx/issues. {alt_part}"
    )


def _make_stub(slug: str, display_name: str):
    def stub(*args, **kwargs):
        raise NotImplementedError(
            _make_deferred_message(slug, display_name, DEFERRED_ALTERNATIVES.get(slug, []))
        )
    stub.__name__ = slug
    stub.__doc__ = "Deferred to v0.2: requires AI model integration."
    return stub


background_blur = _make_stub("background_blur", "Background Blur")
background_replace = _make_stub("background_replace", "Background Replace")
green_screen_key = _make_stub("green_screen_key", "Green Screen Key")
sky_replacement = _make_stub("sky_replacement", "Sky Replacement")
object_highlight = _make_stub("object_highlight", "Object Highlight")
subject_outline = _make_stub("subject_outline", "Subject Outline")
auto_reframe = _make_stub("auto_reframe", "Auto Reframe")
face_mosaic = _make_stub("face_mosaic", "Face Mosaic")
license_plate_blur = _make_stub("license_plate_blur", "License Plate Blur")
pose_skeleton_overlay = _make_stub("pose_skeleton_overlay", "Pose Skeleton Overlay")
object_tracker_label = _make_stub("object_tracker_label", "Object Tracker Label")
depth_fog = _make_stub("depth_fog", "Depth Fog")
depth_parallax = _make_stub("depth_parallax", "Depth Parallax")
motion_trails_subject = _make_stub("motion_trails_subject", "Motion Trails Subject")
rotoscope_cutout = _make_stub("rotoscope_cutout", "Rotoscope Cutout")
person_cutout_glow = _make_stub("person_cutout_glow", "Person Cutout Glow")
eye_zoom_auto = _make_stub("eye_zoom_auto", "Eye Zoom Auto")
product_highlight = _make_stub("product_highlight", "Product Highlight")
smart_scene_relight = _make_stub("smart_scene_relight", "Smart Scene Relight")
auto_color_match = _make_stub("auto_color_match", "Auto Color Match")
crowd_blur = _make_stub("crowd_blur", "Crowd Blur")
document_redaction = _make_stub("document_redaction", "Document Redaction")
logo_detection_blur = _make_stub("logo_detection_blur", "Logo Detection Blur")
gesture_trigger_effect = _make_stub("gesture_trigger_effect", "Gesture Trigger Effect")
semantic_spotlight = _make_stub("semantic_spotlight", "Semantic Spotlight")
