from __future__ import annotations

import numpy as np

from scene_fx.config import TemporalConfig


def _rw(video_path: str):
    from video_fx.frames import read_frames, write_frames
    frames, info = read_frames(video_path)
    return frames, info, write_frames


def _get_beat_frame_indices(fps: float, n_frames: int, config: TemporalConfig) -> list[int]:
    from scene_fx.timing.audio_sync import get_beat_timestamps
    duration = n_frames / max(1, fps)
    beats = get_beat_timestamps(config.audio, config.manual_timestamps or None, duration)
    return [min(int(t * fps), n_frames - 1) for t in beats]


def beat_flash(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    fps = info.get("fps", 25)
    beat_indices = set(_get_beat_frame_indices(fps, len(frames), config))
    result = []
    for i, frame in enumerate(frames):
        if i in beat_indices:
            white = np.full_like(frame, 255)
            white[:, :, 3] = 255
            result.append(white)
            for _ in range(config.flash_duration_frames - 1):
                result.append(white)
        else:
            result.append(frame)
    write_frames(result, info, video_path, config.output)
    return config.output


def lyric_pulse_video(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    fps = info.get("fps", 25)
    beat_indices = set(_get_beat_frame_indices(fps, len(frames), config))
    h, w = frames[0].shape[:2]
    result = []
    for i, frame in enumerate(frames):
        if i in beat_indices:
            import cv2
            scale = 1.1
            new_w, new_h = int(w * scale), int(h * scale)
            zoomed = cv2.resize(frame[:, :, :3], (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            ox, oy = (new_w - w) // 2, (new_h - h) // 2
            out = frame.copy()
            out[:, :, :3] = zoomed[oy:oy + h, ox:ox + w]
            result.append(out)
        else:
            result.append(frame)
    write_frames(result, info, video_path, config.output)
    return config.output


def beat_shake(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    fps = info.get("fps", 25)
    beat_indices = set(_get_beat_frame_indices(fps, len(frames), config))
    result = []
    for i, frame in enumerate(frames):
        if i in beat_indices:
            shift = 6
            shaken = np.roll(frame, shift, axis=1)
            shaken[:, :shift, :] = frame[:, :shift, :]
            result.append(shaken)
        else:
            result.append(frame)
    write_frames(result, info, video_path, config.output)
    return config.output
