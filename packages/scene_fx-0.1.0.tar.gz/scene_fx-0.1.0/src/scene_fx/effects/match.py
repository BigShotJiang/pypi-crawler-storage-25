from __future__ import annotations

import numpy as np
from PIL import Image, ImageDraw

from scene_fx.config import TemporalConfig


def _rw(video_path: str):
    from video_fx.frames import read_frames, write_frames
    frames, info = read_frames(video_path)
    return frames, info, write_frames


def match_cut_assist(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    result = []
    for i, frame in enumerate(frames):
        img = Image.fromarray(frame, "RGBA")
        draw = ImageDraw.Draw(img)
        if i > 0:
            prev = frames[i - 1][:, :, :3]
            curr = frame[:, :, :3]
            diff = np.mean(np.abs(curr.astype(np.float32) - prev.astype(np.float32)))
            score = min(100, int(diff))
            draw.rectangle([0, 0, 80, 16], fill=(0, 0, 0, 180))
            draw.text((2, 2), f"Δ:{score:3d}", fill=(255, 255, 100, 230))
        result.append(np.array(img))
    write_frames(result, info, video_path, config.output)
    return config.output
