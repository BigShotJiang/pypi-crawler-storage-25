from __future__ import annotations

from scene_fx.effects.beat import beat_flash, beat_shake, lyric_pulse_video
from scene_fx.effects.direction import boomerang_loop, reverse, rewind_glitch
from scene_fx.effects.echo import echo_delay, frame_blend, motion_echo, temporal_smear
from scene_fx.effects.freeze import (
    freeze_zoom,
    instant_replay,
    poster_frame_hold,
    time_freeze_subject,
)
from scene_fx.effects.loop import loop_seam_smoother
from scene_fx.effects.match import match_cut_assist
from scene_fx.effects.speed import fast_forward, hyperlapse, slow_motion, speed_ramp, timelapse
from scene_fx.effects.strobe import flash_cut, strobe
from scene_fx.effects.stub_ai import (
    auto_color_match,
    auto_reframe,
    background_blur,
    background_replace,
    crowd_blur,
    depth_fog,
    depth_parallax,
    document_redaction,
    eye_zoom_auto,
    face_mosaic,
    gesture_trigger_effect,
    green_screen_key,
    license_plate_blur,
    logo_detection_blur,
    motion_trails_subject,
    object_highlight,
    object_tracker_label,
    person_cutout_glow,
    pose_skeleton_overlay,
    product_highlight,
    rotoscope_cutout,
    semantic_spotlight,
    sky_replacement,
    smart_scene_relight,
    subject_outline,
)
from scene_fx.effects.time_slice import jump_cut_stylizer, time_slice
from scene_fx.exceptions import EffectNotFoundError

EFFECT_REGISTRY: dict[str, object] = {
    # Active temporal effects (25)
    "speed_ramp": speed_ramp,
    "slow_motion": slow_motion,
    "fast_forward": fast_forward,
    "reverse": reverse,
    "boomerang_loop": boomerang_loop,
    "strobe": strobe,
    "flash_cut": flash_cut,
    "motion_echo": motion_echo,
    "frame_blend": frame_blend,
    "time_slice": time_slice,
    "time_freeze_subject": time_freeze_subject,
    "poster_frame_hold": poster_frame_hold,
    "jump_cut_stylizer": jump_cut_stylizer,
    "match_cut_assist": match_cut_assist,
    "beat_flash": beat_flash,
    "lyric_pulse_video": lyric_pulse_video,
    "loop_seam_smoother": loop_seam_smoother,
    "freeze_zoom": freeze_zoom,
    "instant_replay": instant_replay,
    "rewind_glitch": rewind_glitch,
    "hyperlapse": hyperlapse,
    "timelapse": timelapse,
    "echo_delay": echo_delay,
    "temporal_smear": temporal_smear,
    "beat_shake": beat_shake,
    # Deferred AI stubs (25)
    "background_blur": background_blur,
    "background_replace": background_replace,
    "green_screen_key": green_screen_key,
    "sky_replacement": sky_replacement,
    "object_highlight": object_highlight,
    "subject_outline": subject_outline,
    "auto_reframe": auto_reframe,
    "face_mosaic": face_mosaic,
    "license_plate_blur": license_plate_blur,
    "pose_skeleton_overlay": pose_skeleton_overlay,
    "object_tracker_label": object_tracker_label,
    "depth_fog": depth_fog,
    "depth_parallax": depth_parallax,
    "motion_trails_subject": motion_trails_subject,
    "rotoscope_cutout": rotoscope_cutout,
    "person_cutout_glow": person_cutout_glow,
    "eye_zoom_auto": eye_zoom_auto,
    "product_highlight": product_highlight,
    "smart_scene_relight": smart_scene_relight,
    "auto_color_match": auto_color_match,
    "crowd_blur": crowd_blur,
    "document_redaction": document_redaction,
    "logo_detection_blur": logo_detection_blur,
    "gesture_trigger_effect": gesture_trigger_effect,
    "semantic_spotlight": semantic_spotlight,
}


def get_recipe(slug: str):
    if slug not in EFFECT_REGISTRY:
        raise EffectNotFoundError(slug)
    return EFFECT_REGISTRY[slug]
