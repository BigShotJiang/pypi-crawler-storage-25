from __future__ import annotations

import numpy as np

from scene_fx.config import TemporalConfig


def _rw(video_path: str):
    from video_fx.frames import read_frames, write_frames
    frames, info = read_frames(video_path)
    return frames, info, write_frames


def strobe(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    fps = info.get("fps", 25)
    period = max(1, int(fps / max(0.1, config.strobe_rate)))
    result = []
    for i, frame in enumerate(frames):
        if i % period < config.flash_duration_frames:
            black = np.zeros_like(frame)
            black[:, :, 3] = 255
            result.append(black)
        else:
            result.append(frame)
    write_frames(result, info, video_path, config.output)
    return config.output


def flash_cut(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    fps = info.get("fps", 25)
    period = max(1, int(fps / max(0.1, config.strobe_rate)))
    result = []
    for i, frame in enumerate(frames):
        if i % period < config.flash_duration_frames:
            white = np.full_like(frame, 255)
            white[:, :, 3] = 255
            result.append(white)
        else:
            result.append(frame)
    write_frames(result, info, video_path, config.output)
    return config.output
