from __future__ import annotations

from scene_fx.config import TemporalConfig


def _rw(video_path: str):
    from video_fx.frames import read_frames, write_frames
    frames, info = read_frames(video_path)
    return frames, info, write_frames


def time_slice(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    # Take every 3rd frame, then fill gaps by repeating
    result = []
    for i, frame in enumerate(frames):
        result.append(frames[i - (i % 3)])
    write_frames(result, info, video_path, config.output)
    return config.output


def jump_cut_stylizer(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    fps = info.get("fps", 25)
    chunk = max(2, int(fps * 0.5))
    result = []
    i = 0
    keep = True
    while i < len(frames):
        end = min(i + chunk, len(frames))
        if keep:
            result.extend(frames[i:end])
        i = end
        keep = not keep
    if not result:
        result = [frames[0]]
    write_frames(result, info, video_path, config.output)
    return config.output
