from __future__ import annotations

from scene_fx.config import TemporalConfig


def _rw(video_path: str):
    from video_fx.frames import read_frames, write_frames
    frames, info = read_frames(video_path)
    return frames, info, write_frames


def speed_ramp(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    fps = info.get("fps", 25)
    if config.ramp_curve and len(config.ramp_curve) >= 2:
        from scene_fx.timing.ramp import build_output_frames
        result = build_output_frames(frames, config.ramp_curve, fps, config.easing)
    else:
        sf = max(0.1, config.speed_factor)
        if sf >= 1.0:
            step = max(1, int(sf))
            result = frames[::step]
        else:
            repeat = max(1, int(1.0 / sf))
            result = [f for f in frames for _ in range(repeat)]
    if not result:
        result = [frames[0]]
    write_frames(result, info, video_path, config.output)
    return config.output


def slow_motion(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    repeat = max(2, int(1.0 / max(0.01, config.speed_factor)))
    result = [f for f in frames for _ in range(repeat)]
    if not result:
        result = frames
    write_frames(result, info, video_path, config.output)
    return config.output


def fast_forward(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    step = max(2, int(config.speed_factor * 2))
    result = frames[::step]
    if not result:
        result = [frames[0]]
    write_frames(result, info, video_path, config.output)
    return config.output


def hyperlapse(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    step = max(4, int(config.speed_factor * 8))
    result = frames[::step]
    if not result:
        result = [frames[0]]
    write_frames(result, info, video_path, config.output)
    return config.output


def timelapse(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    step = max(8, int(config.speed_factor * 20))
    result = frames[::step]
    if not result:
        result = [frames[0]]
    write_frames(result, info, video_path, config.output)
    return config.output
