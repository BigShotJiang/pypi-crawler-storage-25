from __future__ import annotations

import numpy as np

from scene_fx.config import TemporalConfig


def _rw(video_path: str):
    from video_fx.frames import read_frames, write_frames
    frames, info = read_frames(video_path)
    return frames, info, write_frames


def loop_seam_smoother(video_path: str, config: TemporalConfig) -> str:
    frames, info, write_frames = _rw(video_path)
    if len(frames) < 4:
        write_frames(frames, info, video_path, config.output)
        return config.output
    blend_n = max(2, min(len(frames) // 4, int(info.get("fps", 25) * 0.5)))
    result = list(frames)
    # Blend tail into head for seamless loop
    for i in range(blend_n):
        alpha = i / blend_n
        blended = np.clip(
            frames[i].astype(np.float32) * alpha + frames[-(blend_n - i)].astype(np.float32) * (1 - alpha),
            0, 255
        ).astype(np.uint8)
        result[i] = blended
    write_frames(result, info, video_path, config.output)
    return config.output
