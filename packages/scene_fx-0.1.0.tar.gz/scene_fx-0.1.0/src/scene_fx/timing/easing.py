from __future__ import annotations


def linear(t: float) -> float:
    return t


def ease_in(t: float) -> float:
    return t * t


def ease_out(t: float) -> float:
    return 1 - (1 - t) ** 2


def ease_in_out(t: float) -> float:
    return t * t * (3 - 2 * t)


def ease_in_cubic(t: float) -> float:
    return t * t * t


def ease_out_cubic(t: float) -> float:
    return 1 - (1 - t) ** 3


_REGISTRY = {
    "linear": linear,
    "ease_in": ease_in,
    "ease-in": ease_in,
    "ease_out": ease_out,
    "ease-out": ease_out,
    "ease_in_out": ease_in_out,
    "ease-in-out": ease_in_out,
    "ease_in_cubic": ease_in_cubic,
    "ease_out_cubic": ease_out_cubic,
}


def get_easing(name: str):
    return _REGISTRY.get(name, linear)
