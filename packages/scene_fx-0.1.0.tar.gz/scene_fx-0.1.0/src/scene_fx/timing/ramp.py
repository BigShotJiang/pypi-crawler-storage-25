from __future__ import annotations


def compute_output_frame_indices(
    n_input: int,
    fps: float,
    ramp_curve: list[tuple[float, float]],
    easing: str = "linear",
) -> list[int]:
    """Return a list of source frame indices to include in the output (may repeat or skip)."""
    if not ramp_curve or len(ramp_curve) < 2:
        return list(range(n_input))

    # Build cumulative output time for each input frame
    output_indices: list[int] = []
    output_time = 0.0
    dt = 1.0 / fps

    for src_idx in range(n_input):
        src_time = src_idx / fps
        # Interpolate speed at this time from ramp_curve
        speed = _interp_speed(ramp_curve, src_time)
        output_time += dt / max(speed, 0.01)
        # Output frame index based on accumulated output time
        out_frame_idx = int(output_time * fps)
        output_indices.append(out_frame_idx)

    return output_indices


def build_output_frames(input_frames: list, ramp_curve: list[tuple[float, float]], fps: float, easing: str = "linear") -> list:
    if not ramp_curve:
        return list(input_frames)
    n = len(input_frames)
    out_indices = compute_output_frame_indices(n, fps, ramp_curve, easing)
    # Build output frame list
    if not out_indices:
        return list(input_frames)
    max_out = max(out_indices) + 1
    result = [None] * max_out
    for src_idx, out_idx in enumerate(out_indices):
        if out_idx < max_out:
            result[out_idx] = input_frames[src_idx]
    # Fill any gaps with nearest neighbor
    last = input_frames[0]
    for i in range(max_out):
        if result[i] is None:
            result[i] = last
        else:
            last = result[i]
    return [f for f in result if f is not None]


def _interp_speed(curve: list[tuple[float, float]], t: float) -> float:
    if t <= curve[0][0]:
        return curve[0][1]
    if t >= curve[-1][0]:
        return curve[-1][1]
    for i in range(len(curve) - 1):
        t0, s0 = curve[i]
        t1, s1 = curve[i + 1]
        if t0 <= t <= t1:
            alpha = (t - t0) / max(t1 - t0, 1e-6)
            return s0 + alpha * (s1 - s0)
    return 1.0
