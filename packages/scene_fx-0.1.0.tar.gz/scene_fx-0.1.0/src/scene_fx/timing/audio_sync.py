from __future__ import annotations

import warnings


def get_beat_timestamps(
    audio_path: str | None,
    manual_timestamps: list[float] | None = None,
    duration: float = 4.0,
) -> list[float]:
    """Return beat timestamps in seconds.

    Priority:
    1. manual_timestamps if provided
    2. audio-arrange if installed
    3. librosa if installed
    4. fallback: even 0.5s beats
    """
    if manual_timestamps:
        return list(manual_timestamps)

    if audio_path:
        try:
            import audio_arrange  # type: ignore
            return audio_arrange.detect_beats(audio_path)
        except ImportError:
            pass

        try:
            import librosa  # type: ignore
            y, sr = librosa.load(audio_path, sr=None)
            _, beat_frames = librosa.beat.beat_track(y=y, sr=sr)
            return librosa.frames_to_time(beat_frames, sr=sr).tolist()
        except ImportError:
            warnings.warn(
                "Neither audio-arrange nor librosa is installed; using evenly-spaced beats. "
                "Install audio-arrange or librosa for real beat detection.",
                stacklevel=3,
            )

    # Fallback: beat every 0.5s
    beats = []
    t = 0.5
    while t < duration:
        beats.append(t)
        t += 0.5
    return beats
