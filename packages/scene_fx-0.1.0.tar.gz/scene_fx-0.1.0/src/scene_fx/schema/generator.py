from __future__ import annotations

import json

from scene_fx.config import TemporalConfig


def generate_schema() -> dict:
    return TemporalConfig.model_json_schema()


def generate_schema_json() -> str:
    return json.dumps(generate_schema(), indent=2)
