from __future__ import annotations

import json

from pydantic import ValidationError

from scene_fx.config import TemporalConfig
from scene_fx.exceptions import TemporalConfigError


def parse_config(data: dict | str) -> TemporalConfig:
    if isinstance(data, str):
        data = json.loads(data)
    try:
        return TemporalConfig(**data)
    except (ValidationError, TypeError) as exc:
        raise TemporalConfigError(str(exc)) from exc
