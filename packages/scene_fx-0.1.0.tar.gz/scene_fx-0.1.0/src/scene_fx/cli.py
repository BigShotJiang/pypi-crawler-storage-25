from __future__ import annotations

import json

import typer

from scene_fx.api import apply_speed_ramp, apply_temporal, beat_synced_effect, list_effects
from scene_fx.schema.generator import generate_schema_json

app = typer.Typer(name="scene-fx", help="Temporal video effects: speed ramps, slow-mo, beat sync, and AI/CV stubs.")


@app.command()
def apply(
    video: str = typer.Option(..., "--video", "-v"),
    effect: str = typer.Option(..., "--effect", "-e"),
    intensity: float = typer.Option(0.75, "--intensity", "-i"),
    out: str = typer.Option("out.mp4", "--out", "-o"),
) -> None:
    result = apply_temporal(video, effect, output=out, intensity=intensity)
    typer.echo(result)


@app.command()
def ramp(
    video: str = typer.Option(..., "--video", "-v"),
    curve: str = typer.Option("0:1.0,2:0.5,4:1.0", "--curve", "-c"),
    easing: str = typer.Option("linear", "--easing"),
    out: str = typer.Option("ramped.mp4", "--out", "-o"),
) -> None:
    pts = []
    for seg in curve.split(","):
        t_str, s_str = seg.strip().split(":")
        pts.append((float(t_str), float(s_str)))
    result = apply_speed_ramp(video, output=out, ramp_curve=pts, easing=easing)
    typer.echo(result)


@app.command()
def beats(
    video: str = typer.Option(..., "--video", "-v"),
    audio: str = typer.Option(None, "--audio", "-a"),
    effect: str = typer.Option("beat_flash", "--effect", "-e"),
    out: str = typer.Option("rhythmic.mp4", "--out", "-o"),
) -> None:
    result = beat_synced_effect(video, audio=audio, effect=effect, output=out)
    typer.echo(result)


@app.command()
def hyperlapse_cmd(
    video: str = typer.Option(..., "--video", "-v"),
    speed: float = typer.Option(8.0, "--speed", "-s"),
    out: str = typer.Option("hyper.mp4", "--out", "-o"),
) -> None:
    result = apply_temporal(video, "hyperlapse", output=out, speed_factor=speed)
    typer.echo(result)


@app.command("list")
def list_cmd(
    include_deferred: bool = typer.Option(False, "--include-deferred"),
) -> None:
    for slug in list_effects(include_deferred=include_deferred):
        typer.echo(slug)


@app.command()
def info(slug: str = typer.Argument(...)) -> None:
    from scene_fx.api import get_effect_info
    entry = get_effect_info(slug)
    typer.echo(json.dumps(entry, indent=2))


@app.command()
def categories() -> None:
    typer.echo("transitions_and_temporal")
    typer.echo("ai_cv_effects")


@app.command()
def schema() -> None:
    typer.echo(generate_schema_json())


def main() -> None:
    app()


if __name__ == "__main__":
    main()
