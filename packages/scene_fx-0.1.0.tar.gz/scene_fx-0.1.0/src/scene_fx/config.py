from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class TemporalConfig(BaseModel):
    effect: str = ""
    output: str = "out.mp4"
    start_time: float = 0.0
    duration: float | None = None
    intensity: float = Field(default=0.75, ge=0.0, le=1.0)
    speed_factor: float = 1.0
    direction: Literal["forward", "reverse", "boomerang"] = "forward"
    echo_count: int = 3
    echo_decay: float = 0.6
    strobe_rate: float = 8.0
    flash_duration_frames: int = 3
    freeze_duration: float = 1.0
    audio: str | None = None
    sync_source: Literal["beat", "lyric", "manual", "none"] = "none"
    sync_offset: float = 0.0
    manual_timestamps: list[float] = Field(default_factory=list)
    fps: int | None = None
    blend_mode: Literal["normal", "screen", "add", "multiply"] = "normal"
    seed: int | None = None
    ramp_curve: list[tuple[float, float]] = Field(default_factory=list)
    easing: str = "linear"
    mask_image: str | None = None
    model_config = ConfigDict(extra="forbid")
