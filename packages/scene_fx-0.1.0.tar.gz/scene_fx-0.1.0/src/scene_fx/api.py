from __future__ import annotations

import logging

from scene_fx.config import TemporalConfig
from scene_fx.effects.loader import get_effect
from scene_fx.effects.loader import list_effects as _list_effects
from scene_fx.effects.recipes import get_recipe

logger = logging.getLogger(__name__)


def apply_temporal(
    video: str,
    effect: str,
    output: str = "out.mp4",
    config: TemporalConfig | None = None,
    **kwargs,
) -> str:
    if config is None:
        config = TemporalConfig(effect=effect, output=output, **kwargs)
    else:
        object.__setattr__(config, "output", output)
    recipe = get_recipe(effect)
    logger.info("Applying effect %r to %r -> %r", effect, video, output)
    return recipe(video, config)


def apply_speed_ramp(
    video: str,
    output: str = "out.mp4",
    ramp_curve: list[tuple[float, float]] | None = None,
    easing: str = "linear",
    **kwargs,
) -> str:
    return apply_temporal(
        video, "speed_ramp", output=output,
        ramp_curve=ramp_curve or [], easing=easing, **kwargs
    )


def beat_synced_effect(
    video: str,
    audio: str | None = None,
    effect: str = "beat_flash",
    output: str = "out.mp4",
    **kwargs,
) -> str:
    if audio:
        kwargs.setdefault("audio", audio)
        kwargs.setdefault("sync_source", "beat")
    return apply_temporal(video, effect, output=output, **kwargs)


def list_effects(include_deferred: bool = False) -> list[str]:
    return _list_effects(include_deferred=include_deferred)


def get_effect_info(slug: str) -> dict:
    return get_effect(slug)
