from scene_fx import list_effects

ACTIVE_SLUGS = {
    "speed_ramp", "slow_motion", "fast_forward", "reverse", "boomerang_loop",
    "strobe", "flash_cut", "motion_echo", "frame_blend", "time_slice",
    "time_freeze_subject", "poster_frame_hold", "jump_cut_stylizer", "match_cut_assist",
    "beat_flash", "lyric_pulse_video", "loop_seam_smoother", "freeze_zoom",
    "instant_replay", "rewind_glitch", "hyperlapse", "timelapse",
    "echo_delay", "temporal_smear", "beat_shake",
}

DEFERRED_SLUGS = {
    "background_blur", "background_replace", "green_screen_key", "sky_replacement",
    "object_highlight", "subject_outline", "auto_reframe", "face_mosaic",
    "license_plate_blur", "pose_skeleton_overlay", "object_tracker_label",
    "depth_fog", "depth_parallax", "motion_trails_subject", "rotoscope_cutout",
    "person_cutout_glow", "eye_zoom_auto", "product_highlight", "smart_scene_relight",
    "auto_color_match", "crowd_blur", "document_redaction", "logo_detection_blur",
    "gesture_trigger_effect", "semantic_spotlight",
}


def test_list_effects_active_25():
    effects = list_effects()
    assert len(effects) == 25


def test_list_effects_all_50():
    effects = list_effects(include_deferred=True)
    assert len(effects) == 50


def test_active_slugs_correct():
    assert set(list_effects()) == ACTIVE_SLUGS


def test_deferred_slugs_correct():
    all_slugs = set(list_effects(include_deferred=True))
    assert DEFERRED_SLUGS.issubset(all_slugs)
