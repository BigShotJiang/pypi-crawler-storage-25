from pathlib import Path

from scene_fx import beat_synced_effect


def test_beat_flash_with_manual_timestamps(tiny_video, tmp_path):
    out = str(tmp_path / "beat_flash.mp4")
    beat_synced_effect(
        str(tiny_video),
        effect="beat_flash",
        output=out,
        manual_timestamps=[0.5, 1.0, 1.5, 2.0, 2.5, 3.0],
    )
    assert Path(out).exists()
    assert Path(out).stat().st_size > 0


def test_beat_shake_with_manual_timestamps(tiny_video, tmp_path):
    out = str(tmp_path / "beat_shake.mp4")
    beat_synced_effect(
        str(tiny_video),
        effect="beat_shake",
        output=out,
        manual_timestamps=[0.5, 1.0, 1.5, 2.0],
    )
    assert Path(out).exists()
    assert Path(out).stat().st_size > 0


def test_beat_flash_no_audio_uses_fallback(tiny_video, tmp_path):
    out = str(tmp_path / "bf2.mp4")
    beat_synced_effect(str(tiny_video), effect="beat_flash", output=out)
    assert Path(out).exists()
