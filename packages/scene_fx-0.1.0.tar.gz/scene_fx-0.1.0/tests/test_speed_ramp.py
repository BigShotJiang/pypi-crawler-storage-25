from pathlib import Path

from scene_fx import apply_speed_ramp, apply_temporal


def test_simple_speed_ramp(tiny_video, tmp_path):
    out = str(tmp_path / "ramp.mp4")
    apply_speed_ramp(str(tiny_video), output=out, ramp_curve=[(0.0, 1.0), (2.0, 0.5), (4.0, 1.0)])
    assert Path(out).exists()
    assert Path(out).stat().st_size > 0


def test_speed_ramp_no_curve(tiny_video, tmp_path):
    out = str(tmp_path / "ramp2.mp4")
    apply_speed_ramp(str(tiny_video), output=out)
    assert Path(out).exists()


def test_slow_motion_more_frames(tiny_video, tmp_path):
    import cv2
    out = str(tmp_path / "slow.mp4")
    apply_temporal(str(tiny_video), effect="slow_motion", output=out, speed_factor=0.25)
    assert Path(out).exists()
    cap = cv2.VideoCapture(str(tiny_video))
    n_orig = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    cap.release()
    cap2 = cv2.VideoCapture(out)
    n_slow = int(cap2.get(cv2.CAP_PROP_FRAME_COUNT))
    cap2.release()
    assert n_slow >= n_orig


def test_fast_forward_fewer_frames(tiny_video, tmp_path):
    import cv2
    out = str(tmp_path / "fast.mp4")
    apply_temporal(str(tiny_video), effect="fast_forward", output=out, speed_factor=2.0)
    assert Path(out).exists()
    cap = cv2.VideoCapture(str(tiny_video))
    n_orig = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    cap.release()
    cap2 = cv2.VideoCapture(out)
    n_fast = int(cap2.get(cv2.CAP_PROP_FRAME_COUNT))
    cap2.release()
    assert n_fast <= n_orig
