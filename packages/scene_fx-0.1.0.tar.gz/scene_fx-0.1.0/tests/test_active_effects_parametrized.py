from pathlib import Path

import pytest

from scene_fx import apply_temporal

ACTIVE_SLUGS = [
    "speed_ramp", "slow_motion", "fast_forward", "reverse", "boomerang_loop",
    "strobe", "flash_cut", "motion_echo", "frame_blend", "time_slice",
    "time_freeze_subject", "poster_frame_hold", "jump_cut_stylizer", "match_cut_assist",
    "beat_flash", "lyric_pulse_video", "loop_seam_smoother", "freeze_zoom",
    "instant_replay", "rewind_glitch", "hyperlapse", "timelapse",
    "echo_delay", "temporal_smear", "beat_shake",
]

BEAT_SLUGS = {"beat_flash", "lyric_pulse_video", "beat_shake"}


@pytest.mark.parametrize("slug", ACTIVE_SLUGS)
def test_active_effect_renders(tiny_video, tmp_path, slug):
    out = str(tmp_path / f"{slug}.mp4")
    kwargs: dict = {}
    if slug in BEAT_SLUGS:
        kwargs["manual_timestamps"] = [0.5, 1.0, 1.5, 2.0, 2.5, 3.0]
    apply_temporal(str(tiny_video), effect=slug, output=out, **kwargs)
    assert Path(out).exists()
    assert Path(out).stat().st_size > 0
