from pathlib import Path

from typer.testing import CliRunner

from scene_fx.cli import app

runner = CliRunner()


def test_cli_list_25():
    result = runner.invoke(app, ["list"])
    assert result.exit_code == 0
    lines = [l for l in result.output.strip().splitlines() if l.strip()]
    assert len(lines) == 25


def test_cli_list_include_deferred_50():
    result = runner.invoke(app, ["list", "--include-deferred"])
    assert result.exit_code == 0
    lines = [l for l in result.output.strip().splitlines() if l.strip()]
    assert len(lines) == 50


def test_cli_schema():
    result = runner.invoke(app, ["schema"])
    assert result.exit_code == 0
    assert "TemporalConfig" in result.output or "effect" in result.output


def test_cli_categories():
    result = runner.invoke(app, ["categories"])
    assert result.exit_code == 0
    assert "transitions_and_temporal" in result.output
    assert "ai_cv_effects" in result.output


def test_cli_apply(tiny_video, tmp_path):
    out = str(tmp_path / "cli.mp4")
    result = runner.invoke(app, ["apply", "--video", str(tiny_video), "--effect", "reverse", "--out", out])
    assert result.exit_code == 0
    assert Path(out).exists()
