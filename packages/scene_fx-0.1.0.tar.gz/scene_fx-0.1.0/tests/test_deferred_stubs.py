import pytest

from scene_fx import apply_temporal

DEFERRED_SLUGS = [
    "background_blur", "background_replace", "green_screen_key", "sky_replacement",
    "object_highlight", "subject_outline", "auto_reframe", "face_mosaic",
    "license_plate_blur", "pose_skeleton_overlay", "object_tracker_label",
    "depth_fog", "depth_parallax", "motion_trails_subject", "rotoscope_cutout",
    "person_cutout_glow", "eye_zoom_auto", "product_highlight", "smart_scene_relight",
    "auto_color_match", "crowd_blur", "document_redaction", "logo_detection_blur",
    "gesture_trigger_effect", "semantic_spotlight",
]


@pytest.mark.parametrize("slug", DEFERRED_SLUGS)
def test_deferred_raises_not_implemented(tiny_video, tmp_path, slug):
    with pytest.raises(NotImplementedError) as exc:
        apply_temporal(str(tiny_video), effect=slug, output=str(tmp_path / "x.mp4"))
    msg = str(exc.value)
    assert "v0.2" in msg
    assert "AI model" in msg
    assert slug in msg


@pytest.mark.parametrize("slug", DEFERRED_SLUGS)
def test_deferred_error_has_v02_reference(tiny_video, tmp_path, slug):
    with pytest.raises(NotImplementedError) as exc:
        apply_temporal(str(tiny_video), effect=slug, output=str(tmp_path / "x.mp4"))
    assert "v0.2" in str(exc.value)
