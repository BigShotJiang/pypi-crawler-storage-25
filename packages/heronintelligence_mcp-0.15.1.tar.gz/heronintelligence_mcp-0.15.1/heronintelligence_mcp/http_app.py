"""HTTP transport wrapper for the Heron Intelligence MCP server.

Supports two authentication modes simultaneously:

  OAuth 2.0 (new):
    POST /mcp  →  Authorization: Bearer <token>
    Tokens are issued via the OAuth flow:
      GET  /.well-known/oauth-authorization-server
      GET  /oauth/authorize?client_id=hc-xxx&code_challenge=...
      POST /oauth/token { code, client_id, client_secret, code_verifier }

  Legacy URL key (backwards-compatible):
    POST /hk-abc123/mcp  →  api key extracted from URL path
    The key is injected as a Bearer token that the OAuth provider recognises.

Clients in Claude.ai:
  New:    URL = https://mcp.heron-intelligence.com/mcp
          OAuth Client ID     = hc-xxx   (from Sauron)
          OAuth Client Secret = cs-xxx   (from Sauron)
  Legacy: URL = https://mcp.heron-intelligence.com/hk-abc123/mcp
          (no OAuth fields required — still works)
"""
from __future__ import annotations

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from heronintelligence_mcp._context import _request_api_key
from heronintelligence_mcp.server import mcp

# Paths that must never require auth (OAuth endpoints + metadata).
# FastMCP mounts these at root level: /authorize, /token, /register, /revoke
_NO_AUTH_PREFIXES = ("/.well-known/", "/authorize", "/token", "/register", "/revoke")


class DualAuthMiddleware(BaseHTTPMiddleware):
    """Handles both OAuth Bearer tokens and legacy URL-path API keys.

    Evaluation order:
    1. Public OAuth / discovery paths  → pass through without auth
    2. Authorization: Bearer <token>   → FastMCP validates via OAuthProvider
    3. /{hk-key}/mcp URL path          → inject key as Bearer, rewrite path
    4. Anything else                   → 401
    """

    async def dispatch(self, request: Request, call_next):
        path = request.url.path

        # ── 1. Public OAuth paths ───────────────────────────────────────────
        if any(path.startswith(p) for p in _NO_AUTH_PREFIXES):
            return await call_next(request)

        # ── 2. Bearer token (OAuth) ─────────────────────────────────────────
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            # FastMCP's RequireAuthMiddleware (inside mcp.streamable_http_app())
            # will validate the token via HeronOAuthProvider.load_access_token().
            # That method sets _request_api_key for OAuth tokens and passes
            # legacy hk-* tokens directly.
            return await call_next(request)

        # ── 3. Legacy URL-path key (/hk-abc123/mcp) ────────────────────────
        parts = path.lstrip("/").split("/", 1)
        if len(parts) == 2 and parts[1].startswith("mcp"):
            api_key = parts[0]
            if api_key:
                # Rewrite path so FastMCP sees /mcp
                request.scope["path"] = "/" + parts[1]

                # Inject the raw api_key as a Bearer token.
                # HeronOAuthProvider.load_access_token() recognises hk-* tokens
                # as legacy and sets _request_api_key accordingly.
                raw_headers = [
                    (k, v)
                    for k, v in request.scope["headers"]
                    if k.lower() != b"authorization"
                ]
                raw_headers.append(
                    (b"authorization", f"Bearer {api_key}".encode())
                )
                request.scope["headers"] = raw_headers

                # Also set the ContextVar here as an early guard; the provider
                # will set it again during token validation.
                ctx_token = _request_api_key.set(api_key)
                try:
                    return await call_next(request)
                finally:
                    _request_api_key.reset(ctx_token)

        # ── 4. No valid auth ────────────────────────────────────────────────
        return JSONResponse(
            status_code=401,
            content={
                "error": "Authentication required. "
                "Use OAuth (Authorization: Bearer <token>) or the legacy URL format."
            },
        )


def create_app():
    """Factory function for uvicorn --factory.

    Returns the FastMCP Starlette app (which includes OAuth routes and
    RequireAuthMiddleware) wrapped with DualAuthMiddleware.
    """
    starlette_app = mcp.streamable_http_app()
    starlette_app.add_middleware(DualAuthMiddleware)
    return starlette_app
