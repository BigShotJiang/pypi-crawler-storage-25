"""Shared async context variables used across the MCP server."""
from __future__ import annotations

import contextvars

# Per-request API key — set by HTTP middleware before each MCP handler call.
# Empty-string default allows stdio mode to fall through to the HERON_API_KEY env var.
_request_api_key: contextvars.ContextVar[str] = contextvars.ContextVar(
    "heron_request_api_key", default=""
)
