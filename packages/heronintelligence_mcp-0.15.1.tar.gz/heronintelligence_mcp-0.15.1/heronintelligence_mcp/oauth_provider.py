"""OAuth 2.0 Authorization Server Provider for Heron Intelligence MCP.

Pre-registered clients only: each client receives an oauth_client_id + oauth_client_secret
generated in Sauron. Claude.ai presents these credentials when connecting.

Flow:
    1. GET /oauth/authorize?client_id=hc-xxx&code_challenge=...
       → Server validates client_id, auto-approves, redirects to Claude with auth code
    2. POST /oauth/token {code, client_id, client_secret, code_verifier}
       → Server validates client_secret + PKCE, issues Bearer token
    3. MCP requests use Authorization: Bearer <token>
       → Server maps token → hk-api-key → injects into _request_api_key ContextVar
"""
from __future__ import annotations

import os
import secrets
import time
from dataclasses import dataclass

import httpx
from mcp.server.auth.provider import (
    AuthorizationCode,
    AuthorizationParams,
    AccessToken,
    OAuthAuthorizationServerProvider,
)
from mcp.shared.auth import (
    InvalidRedirectUriError,
    OAuthClientInformationFull,
    OAuthToken,
)
from pydantic import AnyUrl

from heronintelligence_mcp._context import _request_api_key

_API_URL: str = os.environ.get(
    "HERON_BASE_URL", "https://ubjzp9xp6w.us-west-2.awsapprunner.com"
)
_SERVICE_KEY: str = os.environ.get("MCP_SERVICE_KEY", "6ad84cb0ebd6a92363c6463db53d954c7af1208975a82588b3bb7743c2906e35")
_TOKEN_TTL: int = int(os.environ.get("TOKEN_TTL_SECONDS", "86400"))   # 24 h
_CODE_TTL: int = int(os.environ.get("AUTH_CODE_TTL_SECONDS", "600"))  # 10 min


# ---------------------------------------------------------------------------
# Custom client info: overrides validate_redirect_uri to accept any URI.
# Safe because client identity is enforced via client_secret + PKCE.
# ---------------------------------------------------------------------------

class _HeronClientInfo(OAuthClientInformationFull):
    """Permissive redirect_uri validation for pre-registered clients."""

    def validate_redirect_uri(self, redirect_uri: AnyUrl | None) -> AnyUrl:  # type: ignore[override]
        if redirect_uri is None:
            raise InvalidRedirectUriError(
                "redirect_uri must be provided for Heron Intelligence clients"
            )
        return redirect_uri


# ---------------------------------------------------------------------------
# Internal data classes
# ---------------------------------------------------------------------------

@dataclass
class _ClientEntry:
    oauth_client_id: str
    oauth_client_secret: str
    hk_api_key: str
    full_name: str
    cached_at: float


@dataclass
class _CodeEntry:
    auth_code: AuthorizationCode
    hk_key: str


@dataclass
class _TokenEntry:
    access_token: AccessToken
    hk_key: str


# ---------------------------------------------------------------------------
# Provider
# ---------------------------------------------------------------------------

class HeronOAuthProvider(
    OAuthAuthorizationServerProvider[AuthorizationCode, None, AccessToken]
):
    """OAuth 2.0 authorization server provider backed by the Heron API."""

    _CLIENT_CACHE_TTL = 300  # seconds

    def __init__(self) -> None:
        self._clients: dict[str, _ClientEntry] = {}     # client_id → entry + cache
        self._auth_codes: dict[str, _CodeEntry] = {}    # code string → entry
        self._tokens: dict[str, _TokenEntry] = {}       # bearer token string → entry

    # ------------------------------------------------------------------
    # Client lookup (calls aura-core-ai internal endpoint)
    # ------------------------------------------------------------------

    async def _fetch_client(self, oauth_client_id: str) -> _ClientEntry | None:
        cached = self._clients.get(oauth_client_id)
        if cached and (time.time() - cached.cached_at) < self._CLIENT_CACHE_TTL:
            return cached

        async with httpx.AsyncClient(timeout=10.0) as http:
            try:
                resp = await http.get(
                    f"{_API_URL}/api/v1/auth/mcp-client",
                    params={"oauth_client_id": oauth_client_id},
                    headers={"X-Service-Key": _SERVICE_KEY},
                )
                if resp.status_code != 200:
                    return None
                data = resp.json()
            except Exception:
                return None

        entry = _ClientEntry(
            oauth_client_id=data["oauth_client_id"],
            oauth_client_secret=data["oauth_client_secret"],
            hk_api_key=data["api_key"],
            full_name=data["full_name"],
            cached_at=time.time(),
        )
        self._clients[oauth_client_id] = entry
        return entry

    # ------------------------------------------------------------------
    # OAuthAuthorizationServerProvider protocol
    # ------------------------------------------------------------------

    async def get_client(self, client_id: str) -> _HeronClientInfo | None:
        entry = await self._fetch_client(client_id)
        if not entry:
            return None
        return _HeronClientInfo.model_construct(
            client_id=entry.oauth_client_id,
            client_secret=entry.oauth_client_secret,
            client_id_issued_at=None,
            client_secret_expires_at=None,
            redirect_uris=None,   # validated permissively by _HeronClientInfo
            grant_types=["authorization_code"],
            response_types=["code"],
            token_endpoint_auth_method="client_secret_post",
            scope=None,
        )

    async def register_client(self, client_info: OAuthClientInformationFull) -> None:
        raise NotImplementedError(
            "Dynamic client registration is disabled. "
            "Use the oauth_client_id and oauth_client_secret provided by your admin."
        )

    async def authorize(
        self,
        client: OAuthClientInformationFull,
        params: AuthorizationParams,
    ) -> str:
        """Auto-approve: generate auth code and redirect immediately (no UI needed)."""
        entry = await self._fetch_client(client.client_id or "")
        if not entry:
            raise ValueError(f"Unknown client: {client.client_id}")

        code = secrets.token_hex(16)
        auth_code = AuthorizationCode(
            code=code,
            scopes=params.scopes or [],
            expires_at=time.time() + _CODE_TTL,
            client_id=client.client_id or "",
            code_challenge=params.code_challenge,
            redirect_uri=params.redirect_uri,
            redirect_uri_provided_explicitly=params.redirect_uri_provided_explicitly,
        )
        self._auth_codes[code] = _CodeEntry(auth_code=auth_code, hk_key=entry.hk_api_key)

        # Build redirect URL
        redirect = str(params.redirect_uri)
        sep = "&" if "?" in redirect else "?"
        redirect += f"{sep}code={code}"
        if params.state:
            redirect += f"&state={params.state}"
        return redirect

    async def load_authorization_code(
        self,
        client: OAuthClientInformationFull,
        authorization_code: str,
    ) -> AuthorizationCode | None:
        entry = self._auth_codes.get(authorization_code)
        if not entry:
            return None
        if time.time() > entry.auth_code.expires_at:
            del self._auth_codes[authorization_code]
            return None
        return entry.auth_code

    async def exchange_authorization_code(
        self,
        client: OAuthClientInformationFull,
        authorization_code: AuthorizationCode,
    ) -> OAuthToken:
        code_entry = self._auth_codes.pop(authorization_code.code, None)
        if not code_entry:
            raise ValueError("Authorization code not found or already used")

        bearer = secrets.token_hex(32)
        access_token = AccessToken(
            token=bearer,
            client_id=client.client_id or "",
            scopes=authorization_code.scopes,
            expires_at=int(time.time()) + _TOKEN_TTL,
        )
        self._tokens[bearer] = _TokenEntry(
            access_token=access_token,
            hk_key=code_entry.hk_key,
        )
        return OAuthToken(
            access_token=bearer,
            token_type="Bearer",
            expires_in=_TOKEN_TTL,
            scope=" ".join(authorization_code.scopes) if authorization_code.scopes else None,
        )

    async def load_access_token(self, token: str) -> AccessToken | None:
        # Legacy mode: raw hk-* keys passed as Bearer tokens by DualAuthMiddleware.
        if token.startswith("hk-"):
            _request_api_key.set(token)
            return AccessToken(
                token=token,
                client_id=f"legacy-{token}",
                scopes=[],
                expires_at=None,
            )

        entry = self._tokens.get(token)
        if not entry:
            return None
        if entry.access_token.expires_at and time.time() > entry.access_token.expires_at:
            del self._tokens[token]
            return None

        # Inject backend API key into this request's async context
        _request_api_key.set(entry.hk_key)
        return entry.access_token

    async def load_refresh_token(
        self,
        client: OAuthClientInformationFull,
        refresh_token: str,
    ) -> None:  # type: ignore[override]
        return None  # Refresh tokens not supported

    async def exchange_refresh_token(  # type: ignore[override]
        self,
        client: OAuthClientInformationFull,
        refresh_token: None,
        scopes: list[str],
    ) -> OAuthToken:
        raise NotImplementedError("Refresh tokens are not supported")

    async def revoke_token(
        self,
        token: AccessToken | None,
    ) -> None:
        if token and hasattr(token, "token"):
            self._tokens.pop(token.token, None)


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_provider: HeronOAuthProvider | None = None


def get_oauth_provider() -> HeronOAuthProvider:
    global _provider
    if _provider is None:
        _provider = HeronOAuthProvider()
    return _provider
