"""HeronIntelligence MCP — Financial Intelligence Layer for AI assistants."""
__version__ = "0.2.0"
