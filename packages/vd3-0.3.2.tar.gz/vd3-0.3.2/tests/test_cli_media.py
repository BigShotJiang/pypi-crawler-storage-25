"""Coverage for ``vd3 media`` CLI commands.

``media.py`` was the single biggest coverage hole (~20%) because its
verbs all shell out to DVC. We wire up the shared ``fake_dvc`` fixture
(see ``conftest.py``) which replaces both ``VD3Storage._get_dvc_manager``
and ``DVCManager`` itself, then drive the Typer app via ``CliRunner``
against the pre-populated ``shared_full_db``.
"""

from __future__ import annotations

from vd3storage.cli.app import app

# ---------------------------------------------------------------------------
# pull
# ---------------------------------------------------------------------------


class TestMediaPull:
    def test_pull_all(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "pull", "--all", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Pulled all assets" in result.output
        # storage.pull() with no scope → mgr.pull() with no args
        assert fake_dvc.pulled_paths == [None]

    def test_pull_no_scope_warns(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "pull", "--path", str(db_path)])
        assert result.exit_code == 1
        assert "Specify" in result.output
        # No DVC interaction
        assert fake_dvc.pulled_paths == []

    def test_pull_workset(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "pull", "--workset", "training", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Pulled assets for workset" in result.output

    def test_pull_unknown_workset(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "pull", "--workset", "nope", "--path", str(db_path)])
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_pull_asset_by_name(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "pull", "--asset", "clip-001", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Pulled" in result.output

    def test_pull_unknown_asset(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "pull", "--asset", "nope", "--path", str(db_path)])
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_pull_datasource(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "pull", "--datasource", "dashcam", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Pulled assets for datasource" in result.output


# ---------------------------------------------------------------------------
# push
# ---------------------------------------------------------------------------


class TestMediaPush:
    def test_push_all(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "push", "--all", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Pushed all assets" in result.output

    def test_push_no_scope_warns(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "push", "--path", str(db_path)])
        assert result.exit_code == 1
        assert "Specify" in result.output

    def test_push_workset(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "push", "--workset", "training", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Pushed assets for workset" in result.output

    def test_push_unknown_workset(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "push", "--workset", "nope", "--path", str(db_path)])
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_push_asset_by_name(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "push", "--asset", "clip-001", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Pushed" in result.output

    def test_push_unknown_asset(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "push", "--asset", "nope", "--path", str(db_path)])
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_push_datasource(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "push", "--datasource", "dashcam", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Pushed assets for datasource" in result.output


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


class TestMediaStatus:
    def test_status_no_remote(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        # fake_dvc has no configured remotes by default → has_remote() == False
        result = runner.invoke(app, ["media", "status", "--path", str(db_path)])
        assert result.exit_code == 0
        # Sample DB has 2 assets, both with media locally available, no remote configured.
        assert "Total" in result.output
        assert "Local only" in result.output
        # No "Synced" column when no remote
        assert "Synced" not in result.output

    def test_status_with_remote(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        # Configure a remote so has_remote() is True
        fake_dvc.configured_remotes["storage"] = "s3://bucket/prefix"
        result = runner.invoke(app, ["media", "status", "--path", str(db_path)])
        assert result.exit_code == 0
        # With a remote, the "Synced" column appears in the table
        assert "Synced" in result.output

    def test_status_list_all(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "status", "--list", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "All Assets" in result.output
        assert "clip-001" in result.output

    def test_status_reports_remote_only(self, cli_runner_with_db, fake_dvc):
        """When a media file is missing locally but has a .dvc pointer, it's remote-only."""
        runner, db_path = cli_runner_with_db
        # Remove the video file but leave the asset record intact
        from vd3storage import VD3Storage

        with VD3Storage(db_path) as s:
            video = next(a for a in s.list_assets() if a.asset_type == "video")
            (db_path / video.media_path).unlink()
        result = runner.invoke(app, ["media", "status", "--list", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "remote-only" in result.output


# ---------------------------------------------------------------------------
# remote set / show
# ---------------------------------------------------------------------------


class TestMediaRemote:
    def test_remote_show_when_empty(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["media", "remote", "show", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "No remote configured" in result.output

    def test_remote_set_records_url(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(
            app,
            ["media", "remote", "set", "s3://bucket/prefix", "--name", "prod", "--path", str(db_path)],
        )
        assert result.exit_code == 0
        assert "Remote set" in result.output
        # The fake should have a remote recorded
        assert ("prod", "s3://bucket/prefix", True) in fake_dvc.remotes

    def test_remote_show_after_set(self, cli_runner_with_db, fake_dvc):
        runner, db_path = cli_runner_with_db
        # Pre-configure on the fake
        fake_dvc.configured_remotes["storage"] = "gs://bucket/path"

        result = runner.invoke(app, ["media", "remote", "show", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "storage" in result.output
        assert "gs://bucket/path" in result.output

    def test_remote_set_replaces_existing(self, cli_runner_with_db, fake_dvc):
        """remote set removes any previously-configured remote before adding the new one."""
        runner, db_path = cli_runner_with_db
        fake_dvc.configured_remotes["old"] = "s3://old-bucket"

        result = runner.invoke(
            app,
            ["media", "remote", "set", "gs://new-bucket", "--path", str(db_path)],
        )
        assert result.exit_code == 0
        # The old remote should have been removed
        assert "old" in fake_dvc.removed_remotes
