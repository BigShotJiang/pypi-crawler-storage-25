"""Tests for imageset metadata, reader, and import."""

from pathlib import Path

import orjson
import pytest
from PIL import Image

from vd3storage.media.imageset_metadata import (
    ImageInfo,
    ImagesetMetadata,
    read_imageset_metadata,
    scan_imageset,
    write_imageset_metadata,
)
from vd3storage.media.imageset_reader import ImagesetReader


@pytest.fixture
def sample_images(tmp_path) -> Path:
    """Create a directory with 5 small test images of varying sizes."""
    img_dir = tmp_path / "test_images"
    img_dir.mkdir()
    sizes = [(64, 48), (64, 48), (128, 96), (32, 24), (64, 48)]
    for i, (w, h) in enumerate(sizes):
        img = Image.new("RGB", (w, h), color=(i * 50, 100, 200))
        img.save(img_dir / f"img_{i:04d}.jpg")
    return img_dir


class TestImagesetMetadata:
    def test_scan_imageset(self, sample_images):
        metadata = scan_imageset(sample_images)
        assert metadata.image_count == 5
        assert len(metadata.images) == 5
        # Should be sorted alphabetically
        assert metadata.images[0].filename == "img_0000.jpg"
        assert metadata.images[4].filename == "img_0004.jpg"
        # Check dimensions
        assert metadata.images[0].width == 64
        assert metadata.images[0].height == 48
        assert metadata.images[2].width == 128
        assert metadata.images[2].height == 96

    def test_scan_recursive(self, tmp_path):
        """Scanning should recurse into subdirectories and preserve relative paths."""
        img_dir = tmp_path / "nested_images"
        img_dir.mkdir()
        (img_dir / "cam01").mkdir()
        (img_dir / "cam02").mkdir()
        Image.new("RGB", (64, 48)).save(img_dir / "cam01" / "frame_001.jpg")
        Image.new("RGB", (64, 48)).save(img_dir / "cam01" / "frame_002.jpg")
        Image.new("RGB", (128, 96)).save(img_dir / "cam02" / "frame_001.jpg")
        Image.new("RGB", (32, 24)).save(img_dir / "top_level.png")

        metadata = scan_imageset(img_dir)
        assert metadata.image_count == 4
        filenames = [img.filename for img in metadata.images]
        # Should be sorted and include relative paths
        assert "cam01/frame_001.jpg" in filenames
        assert "cam02/frame_001.jpg" in filenames
        assert "top_level.png" in filenames

    def test_scan_empty_raises(self, tmp_path):
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()
        with pytest.raises(ValueError, match="No image files"):
            scan_imageset(empty_dir)

    def test_scan_nonexistent_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            scan_imageset(tmp_path / "nonexistent")

    def test_scan_filters_non_images(self, tmp_path):
        img_dir = tmp_path / "mixed"
        img_dir.mkdir()
        # Create one image and one non-image
        Image.new("RGB", (10, 10)).save(img_dir / "real.jpg")
        (img_dir / "readme.txt").write_text("not an image")
        (img_dir / "data.csv").write_text("a,b,c")
        metadata = scan_imageset(img_dir)
        assert metadata.image_count == 1
        assert metadata.images[0].filename == "real.jpg"

    def test_write_and_read(self, tmp_path):
        metadata = ImagesetMetadata(
            image_count=2,
            images=[
                ImageInfo(filename="a.jpg", width=100, height=200),
                ImageInfo(filename="b.png", width=300, height=400),
            ],
            extra={"source": "test"},
        )
        json_path = tmp_path / "imageset.json"
        write_imageset_metadata(json_path, metadata)
        assert json_path.exists()

        loaded = read_imageset_metadata(json_path)
        assert loaded.image_count == 2
        assert loaded.images[0].filename == "a.jpg"
        assert loaded.images[1].width == 300
        assert loaded.extra == {"source": "test"}

    def test_read_nonexistent_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            read_imageset_metadata(tmp_path / "nonexistent.json")


class TestImagesetReader:
    def test_read_image(self, sample_images):
        metadata = scan_imageset(sample_images)
        with ImagesetReader(sample_images, metadata) as reader:
            assert reader.frame_count == 5
            assert reader.image_count == 5

            data = reader.get_frame(0)
            assert isinstance(data, bytes)
            assert len(data) > 0

    def test_read_image_as_pil(self, sample_images):
        metadata = scan_imageset(sample_images)
        with ImagesetReader(sample_images, metadata) as reader:
            img = reader.get_frame_image(0)
            assert img.size == (64, 48)

            # Image at index 2 has different size
            img2 = reader.get_frame_image(2)
            assert img2.size == (128, 96)

    def test_get_image_info(self, sample_images):
        metadata = scan_imageset(sample_images)
        with ImagesetReader(sample_images, metadata) as reader:
            info = reader.get_image_info(2)
            assert info.filename == "img_0002.jpg"
            assert info.width == 128
            assert info.height == 96

    def test_out_of_range_raises(self, sample_images):
        metadata = scan_imageset(sample_images)
        with ImagesetReader(sample_images, metadata) as reader, pytest.raises(ValueError, match="out of range"):
            reader.get_frame(999)

    def test_iter_frames(self, sample_images):
        metadata = scan_imageset(sample_images)
        with ImagesetReader(sample_images, metadata) as reader:
            frames = list(reader.iter_frames(start=1, end=4))
            assert len(frames) == 3
            assert frames[0][0] == 1
            assert frames[2][0] == 3
            for _, data in frames:
                assert isinstance(data, bytes)
                assert len(data) > 0


class TestStorageImportImageset:
    def test_import_imageset(self, tmp_storage, sample_images):
        asset = tmp_storage.import_imageset(sample_images, datasource="test-ds")

        assert asset.name == "test_images"
        assert asset.datasource == "test-ds"
        assert asset.asset_type == "imageset"
        assert asset.frame_count == 5
        assert asset.media_path == "db/media/imagesets/test-ds/test_images"

        # Verify images copied
        media_dir = tmp_storage.path / asset.media_path
        assert media_dir.is_dir()
        assert len(list(media_dir.glob("*.jpg"))) == 5

        # Verify imageset.json created
        metadata_dir = tmp_storage.db_dir / "metadata" / "imagesets" / "test-ds" / "test_images"
        assert (metadata_dir / "imageset.json").exists()
        data = orjson.loads((metadata_dir / "imageset.json").read_bytes())
        assert data["image_count"] == 5

    def test_import_nested_directory(self, tmp_storage, tmp_path):
        """Importing a nested directory should preserve subdirectory layout."""
        img_dir = tmp_path / "nested"
        img_dir.mkdir()
        (img_dir / "cam01").mkdir()
        (img_dir / "cam02").mkdir()
        Image.new("RGB", (64, 48)).save(img_dir / "cam01" / "a.jpg")
        Image.new("RGB", (64, 48)).save(img_dir / "cam02" / "b.jpg")
        Image.new("RGB", (32, 24)).save(img_dir / "top.png")

        asset = tmp_storage.import_imageset(img_dir, datasource="ds1")
        assert asset.frame_count == 3

        # Verify subdirectory structure preserved in media
        media_dir = tmp_storage.path / asset.media_path
        assert (media_dir / "cam01" / "a.jpg").exists()
        assert (media_dir / "cam02" / "b.jpg").exists()
        assert (media_dir / "top.png").exists()

        # Verify reader can access images by index
        with tmp_storage.open_imageset(asset.asset_id) as reader:
            assert reader.frame_count == 3
            # Should be able to read all images
            for i in range(3):
                img = reader.get_frame_image(i)
                assert img.size[0] > 0

    def test_import_imageset_custom_name(self, tmp_storage, sample_images):
        asset = tmp_storage.import_imageset(sample_images, datasource="ds1", name="my-set")
        assert asset.name == "my-set"
        assert asset.media_path == "db/media/imagesets/ds1/my-set"

    def test_import_duplicate_raises(self, tmp_storage, sample_images):
        tmp_storage.import_imageset(sample_images, datasource="ds1", name="dup")
        with pytest.raises(ValueError, match="already exists"):
            tmp_storage.import_imageset(sample_images, datasource="ds1", name="dup")

    def test_import_nonexistent_raises(self, tmp_storage):
        with pytest.raises(FileNotFoundError):
            tmp_storage.import_imageset("/nonexistent", datasource="ds1")

    def test_open_imageset(self, tmp_storage, sample_images):
        asset = tmp_storage.import_imageset(sample_images, datasource="ds1")
        with tmp_storage.open_imageset(asset.asset_id) as reader:
            assert reader.frame_count == 5
            img = reader.get_frame_image(0)
            assert img.size == (64, 48)

    def test_get_frame_image_dispatches(self, tmp_storage, sample_images):
        """get_frame_image() should work for both videos and imagesets."""
        asset = tmp_storage.import_imageset(sample_images, datasource="ds1")
        img = tmp_storage.get_frame_image(asset.asset_id, 0)
        assert img.size == (64, 48)

    def test_export_coco_populates_file_name(self, tmp_storage, sample_images):
        """export_coco() on an imageset asset includes file_name on each image."""
        asset = tmp_storage.import_imageset(sample_images, datasource="ds1")

        # Add a small detection layer covering frame 0
        tmp_storage.add_annotation_layer(
            asset.asset_id,
            layer="det/test",
            display_name="Test",
            annotations={0: [{"class_name": "person", "bbox": [10, 20, 50, 60]}]},
            source="machine",
            layer_type="detections",
        )

        coco = tmp_storage.export_coco(asset.asset_id, "det/test")

        # Each emitted image dict carries file_name from ImagesetMetadata
        assert len(coco["images"]) > 0
        for img in coco["images"]:
            assert "file_name" in img, f"missing file_name on image: {img}"
            assert img["file_name"].endswith(".jpg")

        # The frame-0 image's file_name matches the alphabetical-first image
        # (img_0000.jpg from the sample_images fixture)
        frame0 = next(img for img in coco["images"] if img["frame_index"] == 0)
        assert frame0["file_name"] == "img_0000.jpg"

    def test_export_coco_populates_per_frame_dimensions(self, tmp_storage, sample_images):
        """Each image dict carries the per-frame width/height from ImagesetMetadata.

        Imageset assets leave ``asset.width`` / ``asset.height`` at 0 (sizes
        vary per image). The COCO export must source dims from the imageset
        metadata so downstream consumers (e.g. YOLOX) don't divide by zero.
        """
        asset = tmp_storage.import_imageset(sample_images, datasource="ds1")
        # Sanity: imageset assets carry no asset-level dimensions.
        assert asset.width == 0
        assert asset.height == 0

        tmp_storage.add_annotation_layer(
            asset.asset_id,
            layer="det/test",
            display_name="Test",
            annotations={0: [{"class_name": "person", "bbox": [10, 20, 50, 60]}]},
            source="machine",
            layer_type="detections",
        )

        coco = tmp_storage.export_coco(asset.asset_id, "det/test")

        # sample_images fixture sizes: (64,48), (64,48), (128,96), (32,24), (64,48)
        expected = {0: (64, 48), 1: (64, 48), 2: (128, 96), 3: (32, 24), 4: (64, 48)}
        for img in coco["images"]:
            w, h = expected[img["frame_index"]]
            assert img["width"] == w, img
            assert img["height"] == h, img

    def test_annotations_on_imageset(self, tmp_storage, sample_images):
        asset = tmp_storage.import_imageset(sample_images, datasource="ds1")

        tmp_storage.add_annotation_layer(
            asset.asset_id,
            layer="gt",
            display_name="Ground Truth",
            layer_type="detections",
            annotations={
                0: [{"class_name": "person", "confidence": 0.9, "bbox": [10, 20, 30, 40]}],
                1: [{"class_name": "car", "confidence": 0.8, "bbox": [50, 60, 70, 80]}],
            },
            source="machine",
        )

        layers = tmp_storage.list_annotation_layers(asset.asset_id)
        assert len(layers) == 1
        assert layers[0]["layer"] == "gt"
        assert layers[0]["frame_count"] == 2

        ann = tmp_storage.get_annotations(asset.asset_id, "gt", 0)
        assert ann is not None
        assert len(ann["objects"]) == 1
        assert ann["objects"][0]["class_name"] == "person"

    def test_delete_imageset(self, tmp_storage, sample_images):
        asset = tmp_storage.import_imageset(sample_images, datasource="ds1")
        media_path = tmp_storage.path / asset.media_path
        assert media_path.exists()

        tmp_storage.delete_asset(asset.asset_id, delete_media=True)
        assert not media_path.exists()
        assert tmp_storage.get_asset_by_id(asset.asset_id) is None
