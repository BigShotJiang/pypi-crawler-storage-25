"""In-memory replacement for ``DVCManager`` for tests.

Most ``DVCManager`` methods shell out to the real ``dvc`` binary. That's fine
for the dedicated ``test_dvc.py`` integration tests, but most code that uses
the manager (``VD3Storage.push``, ``.pull``, the CLI ``media`` verbs) only
cares that the *right paths* end up being added/pushed/pulled — not that
the subprocess actually ran. ``FakeDVCManager`` records every call so tests
can assert against the call history without spawning subprocesses.

Usage::

    fake = FakeDVCManager()
    monkeypatch.setattr(storage, "_get_dvc_manager", lambda: fake)
    storage.push(asset_ids=["..."])
    assert fake.pushed_paths == [...]
"""

from __future__ import annotations

from pathlib import Path


class FakeDVCManager:
    """Same protocol as :class:`vd3storage.dvc.manager.DVCManager` but in-memory.

    Attributes
    ----------
    added : list[list[Path]]
        Every ``add()`` call captured as the list of paths passed.
    pushed_paths : list[Path | None]
        Each ``push()`` call. ``None`` is the "no scope, push everything"
        invocation; a list is the scoped variant.
    pulled_paths : list[Path | None]
        Each ``pull()`` call. Same convention as ``pushed_paths``.
    remotes : list[tuple[str, str, bool]]
        Each ``add_remote(name, url, default=...)`` call.
    initialized : bool
        Toggle whether the fake reports as initialized. Defaults to ``True``.
    cloud_status_payload : dict[str, str]
        Returned from :meth:`cloud_status`. Default empty.
    """

    def __init__(self, *, initialized: bool = True) -> None:
        self.added: list[list[Path]] = []
        self.pushed_paths: list[list[Path] | None] = []
        self.pulled_paths: list[list[Path] | None] = []
        self.remotes: list[tuple[str, str, bool]] = []
        self.removed_remotes: list[str] = []
        self.initialized = initialized
        self.cloud_status_payload: dict[str, str] = {}
        self.configured_remotes: dict[str, str] = {}

    # -- protocol methods --------------------------------------------------

    def add(self, paths: Path | list[Path]) -> None:
        if isinstance(paths, Path):
            paths = [paths]
        self.added.append(list(paths))

    def push(self, paths: list[Path] | None = None) -> None:
        self.pushed_paths.append(list(paths) if paths is not None else None)

    def pull(self, paths: list[Path] | None = None) -> None:
        self.pulled_paths.append(list(paths) if paths is not None else None)

    def cloud_status(self) -> dict[str, str]:
        return dict(self.cloud_status_payload)

    def add_remote(self, name: str, url: str, default: bool = True) -> None:
        self.remotes.append((name, url, default))
        self.configured_remotes[name] = url

    def remove_remote(self, name: str) -> None:
        self.removed_remotes.append(name)
        self.configured_remotes.pop(name, None)

    def list_remotes(self) -> dict[str, str]:
        return dict(self.configured_remotes)

    def has_remote(self) -> bool:
        return bool(self.configured_remotes)

    def is_initialized(self) -> bool:
        return self.initialized

    # -- helpers for tests -------------------------------------------------

    @property
    def all_pushed_paths(self) -> list[Path]:
        """Flat list of every path passed to a scoped push() (None calls ignored)."""
        out: list[Path] = []
        for call in self.pushed_paths:
            if call is not None:
                out.extend(call)
        return out

    @property
    def all_pulled_paths(self) -> list[Path]:
        """Flat list of every path passed to a scoped pull() (None calls ignored)."""
        out: list[Path] = []
        for call in self.pulled_paths:
            if call is not None:
                out.extend(call)
        return out
