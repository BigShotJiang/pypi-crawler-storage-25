"""Hypothesis property tests for vd3 (Plan 05 Phase E).

Three property suites:

1. **Slug derivation** (``storage._slugify``) — slugs are URL-safe,
   non-empty when input has any word character, lowercase, idempotent.

2. **COCO image resolution** (``importers.coco._build_filename_index`` +
   ``_resolve_image_to_frame``) — resolution is independent of path
   separator, leading ``./``, redundant ``//``; exact relative path
   matches beat basename fallback; ambiguous basenames return None.

3. **COCO bbox round-trip** (``exporters.coco.export_annotation_layer_as_coco``
   forward ↔ ``importers.coco.parse_coco_json`` inverse) — exporting then
   re-parsing a bbox returns the original ``[x1, y1, x2, y2]``.

Hypothesis explores way more inputs than hand-written examples, which is
exactly what you want for these transformation functions where the
"interesting" case is rarely on the happy path.
"""

from __future__ import annotations

import string
from pathlib import Path

import hypothesis.strategies as st
from hypothesis import HealthCheck, assume, given, settings

from vd3storage.exporters.coco import export_annotation_layer_as_coco
from vd3storage.importers.coco import _build_filename_index, _resolve_image_to_frame
from vd3storage.media.imageset_metadata import ImageInfo, ImagesetMetadata
from vd3storage.storage import _slugify

# ---------------------------------------------------------------------------
# Slug derivation
# ---------------------------------------------------------------------------


@st.composite
def workset_names(draw: st.DrawFn) -> str:
    """A best-effort plausible workset name: word chars, spaces, punctuation."""
    alphabet = string.ascii_letters + string.digits + " _-./!@#$&'\"():;"
    return draw(st.text(alphabet=alphabet, min_size=1, max_size=80))


class TestSlugProperties:
    @given(workset_names())
    def test_slug_is_lowercase(self, name: str):
        assert _slugify(name).lower() == _slugify(name)

    @given(workset_names())
    def test_slug_chars_are_safe(self, name: str):
        slug = _slugify(name)
        # Only word chars and dashes survive — no spaces, no quotes, no slashes
        assert all(c.isalnum() or c == "-" for c in slug), f"unsafe chars in slug={slug!r}"

    @given(workset_names())
    def test_slug_has_no_consecutive_dashes(self, name: str):
        slug = _slugify(name)
        assert "--" not in slug

    @given(workset_names())
    def test_slug_has_no_leading_or_trailing_dash(self, name: str):
        slug = _slugify(name)
        assert not slug.startswith("-")
        assert not slug.endswith("-")

    @given(workset_names())
    def test_slug_is_idempotent(self, name: str):
        once = _slugify(name)
        twice = _slugify(once)
        assert once == twice

    @given(st.text(alphabet=string.ascii_letters + string.digits, min_size=1, max_size=40))
    def test_word_input_survives_at_least_once(self, name: str):
        """If input has any word characters, the slug shouldn't be empty."""
        slug = _slugify(name)
        assert len(slug) >= 1

    def test_unicode_strips_safely(self):
        """Non-ASCII letters get stripped by the [^\\w\\s-] filter — fine, just safe."""
        # \w in Python re matches Unicode by default, so ä survives. Pin the actual
        # behavior so a future regex tweak that breaks it gets caught.
        slug = _slugify("Café-Münchner")
        # Letters stay (Python \w is Unicode); spaces/hyphens normalized
        assert slug == "café-münchner"


# ---------------------------------------------------------------------------
# COCO image resolution
# ---------------------------------------------------------------------------


@st.composite
def imageset_filenames(draw: st.DrawFn) -> list[str]:
    """A small imageset with unique-basename files in flat or nested layouts."""
    n = draw(st.integers(min_value=1, max_value=8))
    basenames = draw(
        st.lists(
            st.text(alphabet=string.ascii_lowercase + string.digits, min_size=3, max_size=8),
            min_size=n,
            max_size=n,
            unique=True,
        )
    )
    return [f"{b}.jpg" for b in basenames]


def _metadata(filenames: list[str]) -> ImagesetMetadata:
    return ImagesetMetadata(
        image_count=len(filenames),
        images=[ImageInfo(filename=f, width=32, height=32) for f in filenames],
    )


class TestCocoPathResolution:
    @given(imageset_filenames())
    def test_exact_match_resolves(self, filenames: list[str]):
        """Every imageset filename matches itself."""
        meta = _metadata(filenames)
        full_idx, basename_idx = _build_filename_index(meta)
        for i, fn in enumerate(filenames):
            assert _resolve_image_to_frame(fn, full_idx, basename_idx) == i

    @given(imageset_filenames())
    def test_basename_match_when_unique(self, filenames: list[str]):
        """When the imageset has the file at the top level, a deeper path's basename still matches."""
        meta = _metadata(filenames)
        full_idx, basename_idx = _build_filename_index(meta)
        for i, fn in enumerate(filenames):
            # Pretend the COCO file_name has extra directory levels
            with_prefix = f"some/nested/path/{fn}"
            assert _resolve_image_to_frame(with_prefix, full_idx, basename_idx) == i

    @given(imageset_filenames())
    def test_leading_dot_slash_doesnt_break_match(self, filenames: list[str]):
        """`./foo.jpg` should resolve the same as `foo.jpg`."""
        meta = _metadata(filenames)
        full_idx, basename_idx = _build_filename_index(meta)
        for i, fn in enumerate(filenames):
            assert _resolve_image_to_frame(f"./{fn}", full_idx, basename_idx) == i

    @given(imageset_filenames())
    def test_redundant_separators_collapse(self, filenames: list[str]):
        """`foo//bar.jpg` should resolve via PurePosixPath normalization."""
        meta = _metadata(filenames)
        full_idx, basename_idx = _build_filename_index(meta)
        # Construct a path with redundant separators
        for i, fn in enumerate(filenames):
            messy = f".//./{fn}"
            assert _resolve_image_to_frame(messy, full_idx, basename_idx) == i

    def test_ambiguous_basename_returns_none(self):
        """Two images sharing a basename → basename fallback refuses to guess."""
        meta = _metadata(["cam01/frame_001.jpg", "cam02/frame_001.jpg"])
        full_idx, basename_idx = _build_filename_index(meta)
        # Exact path beats basename: cam01/frame_001.jpg resolves
        assert _resolve_image_to_frame("cam01/frame_001.jpg", full_idx, basename_idx) == 0
        # Bare basename is ambiguous → None
        assert _resolve_image_to_frame("frame_001.jpg", full_idx, basename_idx) is None
        # Even with leading ./, ambiguous basename refuses to guess.
        # (PurePosixPath stem keeps the trailing component, so this falls into basename match.)
        assert _resolve_image_to_frame("./frame_001.jpg", full_idx, basename_idx) is None


# ---------------------------------------------------------------------------
# COCO bbox round-trip
# ---------------------------------------------------------------------------


@st.composite
def vd3_bboxes(draw: st.DrawFn) -> tuple[float, float, float, float]:
    """A non-degenerate VD3 bbox [x1, y1, x2, y2] with x2 > x1 and y2 > y1.

    Values stay in 0–10000 so they comfortably exceed any sensible image dimension
    without floating-point precision pain.
    """
    x1 = draw(st.floats(min_value=0, max_value=9000, allow_nan=False, allow_infinity=False))
    y1 = draw(st.floats(min_value=0, max_value=9000, allow_nan=False, allow_infinity=False))
    w = draw(st.floats(min_value=0.001, max_value=1000, allow_nan=False, allow_infinity=False))
    h = draw(st.floats(min_value=0.001, max_value=1000, allow_nan=False, allow_infinity=False))
    return (x1, y1, x1 + w, y1 + h)


class TestCocoBboxRoundTrip:
    @given(bbox=vd3_bboxes())
    @settings(suppress_health_check=[HealthCheck.too_slow])
    def test_forward_inverse_matches(self, bbox: tuple[float, float, float, float]):
        """VD3 -> COCO -> VD3 returns the original bbox (modulo float precision)."""
        x1, y1, x2, y2 = bbox

        # Forward: VD3 -> COCO via the exporter
        layer_data = {
            "layer": "test",
            "display_name": "Test",
            "layer_type": "detections",
            "frames": {
                "0": [{"class_name": "person", "bbox": [x1, y1, x2, y2]}],
            },
        }
        coco = export_annotation_layer_as_coco(
            layer_data, width=10000, height=10000, categories=[{"id": 0, "name": "person"}]
        )

        # Inverse: COCO -> VD3 (mirror the importer's bbox conversion)
        x, y, w, h = coco["annotations"][0]["bbox"]
        recovered = [x, y, x + w, y + h]

        for original, restored in zip([x1, y1, x2, y2], recovered, strict=False):
            assert abs(original - restored) < 1e-9, f"{original=} {restored=}"

    @given(bbox=vd3_bboxes())
    def test_coco_width_height_are_non_negative(self, bbox: tuple[float, float, float, float]):
        """The exporter's [x, y, w, h] should always have non-negative w and h
        when the input is well-formed."""
        x1, y1, x2, y2 = bbox
        layer_data = {
            "layer": "test",
            "display_name": "Test",
            "layer_type": "detections",
            "frames": {
                "0": [{"class_name": "person", "bbox": [x1, y1, x2, y2]}],
            },
        }
        coco = export_annotation_layer_as_coco(
            layer_data, width=10000, height=10000, categories=[{"id": 0, "name": "person"}]
        )
        x, y, w, h = coco["annotations"][0]["bbox"]
        assert w >= 0
        assert h >= 0


# ---------------------------------------------------------------------------
# Resolve media path (storage method, indirectly tied to PurePosixPath logic)
# ---------------------------------------------------------------------------


class TestResolveMediaPathRoundTrip:
    """Smaller property: every video asset that is imported can be located via
    ``resolve_media_path``. Uses the factory + Hypothesis-style randomization."""

    @given(name=st.text(alphabet=string.ascii_lowercase + string.digits + "-_", min_size=1, max_size=20))
    @settings(max_examples=5, deadline=None, suppress_health_check=[HealthCheck.function_scoped_fixture])
    def test_resolve_after_import(self, tmp_storage, name: str):
        from tests.fixtures.factory import SAMPLE_VIDEO

        # Skip names that collide with the existing "tiny" import
        assume(name not in tmp_storage.list_assets())

        asset = tmp_storage.import_video(SAMPLE_VIDEO, datasource="ds", name=name, force=True)
        resolved = tmp_storage.resolve_media_path(asset)
        assert resolved.exists()
        assert resolved == Path(tmp_storage._path) / asset.media_path
