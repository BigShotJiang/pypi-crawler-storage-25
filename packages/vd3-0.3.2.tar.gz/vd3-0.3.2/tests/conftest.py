"""Shared test fixtures.

The empty ``tmp_storage`` fixture is the original baseline — used by
``test_storage.py`` and any test that only needs a fresh, empty DB.

The ``empty_db`` / ``minimal_db`` / ``sample_db`` / ``coco_db`` / ``layers_db``
fixtures dispatch to :func:`tests.fixtures.factory.build_sample_db`. They are
the recommended way to set up populated content databases — adding a new
shape of data is a single edit to ``factory.py`` rather than ad-hoc'ing
inline builders in each test file.

``shared_full_db`` is a session-scoped *read-only* path to a pre-built
"full" DB. Use ``cli_runner_with_db`` if you need a mutable per-test copy.
"""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest
from typer.testing import CliRunner

from tests.fakes.dvc import FakeDVCManager
from tests.fixtures.factory import build_sample_db
from vd3storage import VD3Storage


@pytest.fixture(autouse=True)
def _insulate_vd3_db_env(monkeypatch):
    """Unset VD3_DB for every test.

    The CLI honors VD3_DB as a fallback for --path. Tests that forget to
    pass --path should fail loudly rather than silently targeting whatever
    database a developer has exported (or set in .env). This autouse
    fixture clears the var unconditionally so the test environment is
    deterministic regardless of the host shell.
    """
    monkeypatch.delenv("VD3_DB", raising=False)


@pytest.fixture
def tmp_storage(tmp_path):
    """Original empty-DB fixture. Kept for backward compatibility."""
    storage = VD3Storage.init(tmp_path / "test-db", git_init=False, dvc_init=False)
    yield storage
    storage.save()
    storage._engine.close()


# ---------------------------------------------------------------------------
# Factory-backed fixtures (Plan 05 Phase B)
# ---------------------------------------------------------------------------


@pytest.fixture
def empty_db(tmp_path):
    """Fresh init, nothing in it. Equivalent to ``tmp_storage`` but goes
    through the factory so the surface stays uniform."""
    storage = build_sample_db(tmp_path / "db", scenario="empty")
    yield storage
    storage.save()
    storage._engine.close()


@pytest.fixture
def minimal_db(tmp_path):
    """One datasource, one video asset. No worksets, layers, or tags."""
    storage = build_sample_db(tmp_path / "db", scenario="minimal")
    yield storage
    storage.save()
    storage._engine.close()


@pytest.fixture
def sample_db(tmp_path):
    """The default populated DB. Two datasources (video + imageset), three
    worksets with packages, two annotation layers per asset (one human GT
    and one machine detection), namespaced tags, and datasource
    descriptions. Function-scoped so each test gets a fresh copy."""
    storage = build_sample_db(tmp_path / "db", scenario="full")
    yield storage
    storage.save()
    storage._engine.close()


@pytest.fixture
def coco_db(tmp_path):
    """Imageset asset with a COCO ground-truth layer imported from disk.
    Use this for COCO-specific tests so you're exercising the importer,
    not a hand-rolled layer."""
    storage = build_sample_db(tmp_path / "db", scenario="coco")
    yield storage
    storage.save()
    storage._engine.close()


@pytest.fixture
def layers_db(tmp_path):
    """Single asset carrying five distinct annotation layers (one human
    GT, two machine detection, two machine track). For layer-listing /
    layer-coverage code paths."""
    storage = build_sample_db(tmp_path / "db", scenario="layers")
    yield storage
    storage.save()
    storage._engine.close()


# ---------------------------------------------------------------------------
# Session-scoped shared DB + CLI runner
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def shared_full_db(tmp_path_factory) -> Path:
    """Built once per session at the ``full`` scenario. **Read-only**;
    tests that need to mutate the DB should depend on ``cli_runner_with_db``
    (or copy the path themselves)."""
    path = tmp_path_factory.mktemp("shared-full") / "db"
    storage = build_sample_db(path, scenario="full")
    storage.save()
    storage._engine.close()
    return path


@pytest.fixture
def cli_runner_with_db(shared_full_db, tmp_path) -> tuple[CliRunner, Path]:
    """Returns ``(runner, db_path)`` where ``db_path`` is a fresh per-test
    copy of the session-scoped ``shared_full_db``. Use this when you need
    to exercise the CLI against a populated DB without rebuilding the
    fixtures from scratch on every test."""
    db_copy = tmp_path / "db"
    shutil.copytree(shared_full_db, db_copy)
    return CliRunner(), db_copy


# ---------------------------------------------------------------------------
# DVC fake (Plan 05 Phase C onward)
# ---------------------------------------------------------------------------


@pytest.fixture
def fake_dvc(monkeypatch):
    """Replace every path that produces a ``DVCManager`` with a single shared
    :class:`tests.fakes.dvc.FakeDVCManager` for the duration of the test.

    The fake records every ``add`` / ``push`` / ``pull`` / ``add_remote`` /
    ``remove_remote`` / ``list_remotes`` / ``cloud_status`` call so tests
    can assert on the *intent* of DVC operations without spawning the real
    binary or contacting a remote.

    Two injection points are patched:

    * ``VD3Storage._get_dvc_manager`` — the path used by ``storage.push`` /
      ``storage.pull`` / ``storage.add_remote``.
    * The ``DVCManager`` class symbol in ``vd3storage.dvc.manager`` — every
      CLI command that does ``mgr = DVCManager(storage.path)`` resolves to
      the fake instead.
    """
    fake = FakeDVCManager()
    monkeypatch.setattr(VD3Storage, "_get_dvc_manager", lambda self: fake)

    import vd3storage.dvc.manager as dvc_module

    monkeypatch.setattr(dvc_module, "DVCManager", lambda *args, **kwargs: fake)
    return fake
