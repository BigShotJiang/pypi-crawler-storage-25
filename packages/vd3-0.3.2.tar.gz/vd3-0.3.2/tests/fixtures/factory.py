"""Build populated VD3Storage databases for tests, deterministically.

The factory is the *only* place tests should rely on for setting up
realistic content databases. Each test that needs more than an empty DB
calls :func:`build_sample_db` with a named scenario rather than
ad-hoc'ing its own builder inline. Adding a new shape of populated DB
is then a single function edit — every consumer benefits.

Scenarios
---------

empty
    Fresh ``VD3Storage.init`` with no assets, no worksets, no tags.
    Useful when the unit under test creates its own state.

minimal
    One datasource (``"dashcam"``) with a single video asset imported
    from ``tests/fixtures/media/tiny.mp4``. No worksets, no annotation
    layers, no tags.

full
    Two datasources (``"dashcam"`` video + ``"frontporch"`` imageset),
    three worksets (``validation``, ``training``, ``calibration``) with
    package folders, two annotation layers on each asset (one ``human``
    ground-truth, one ``machine`` detection), and namespaced tags.

coco
    Imageset asset only; an annotation layer is imported from
    ``tests/fixtures/data/sample.coco.json`` via the COCO importer.
    Exercises the imageset + COCO-layer plumbing without video.

layers
    A single video asset carrying five distinct annotation layers:
    ``gt`` (human / reviewed), ``det/yolov8n``, ``det/yolov8m``,
    ``tracks/sort``, ``tracks/bytetrack``. For layer-listing /
    layer-coverage code paths.

Sample media
------------

The committed binaries live under ``tests/fixtures/media/``:
* ``tiny.mp4`` — 1-second, 32×32, ~2.5 KB.
* ``imageset/000{1..5}.jpg`` — five solid-color 32×32 JPEGs, ~650 B each.

Regenerate them with ``uv run tests/fixtures/regenerate.py``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Final

from vd3storage import VD3Storage

FIXTURES_DIR: Final = Path(__file__).parent
MEDIA_DIR: Final = FIXTURES_DIR / "media"
DATA_DIR: Final = FIXTURES_DIR / "data"

SAMPLE_VIDEO: Final = MEDIA_DIR / "tiny.mp4"
SAMPLE_IMAGESET: Final = MEDIA_DIR / "imageset"
SAMPLE_COCO_JSON: Final = DATA_DIR / "sample.coco.json"
SAMPLE_VD3_JSON: Final = DATA_DIR / "sample.vd3.json"


SCENARIOS = ("empty", "minimal", "full", "coco", "layers")


def build_sample_db(path: Path, scenario: str = "full") -> VD3Storage:
    """Build a populated ``VD3Storage`` at ``path`` for the given scenario.

    Args:
        path: Where to create the database. The directory is created.
        scenario: One of :data:`SCENARIOS`.

    Returns:
        An open :class:`VD3Storage` instance. Caller is responsible for
        closing it (or letting it go out of scope; the conftest fixtures
        do this for tests).
    """
    if scenario not in SCENARIOS:
        raise ValueError(f"unknown scenario {scenario!r}; pick from {SCENARIOS}")

    storage = VD3Storage.init(path, git_init=False, dvc_init=False)

    if scenario == "empty":
        storage.save()
        return storage

    if scenario == "minimal":
        _populate_minimal(storage)
    elif scenario == "full":
        _populate_full(storage)
    elif scenario == "coco":
        _populate_coco(storage)
    elif scenario == "layers":
        _populate_layers(storage)

    storage.save()
    return storage


# ---------------------------------------------------------------------------
# Per-scenario population helpers
# ---------------------------------------------------------------------------


def _populate_minimal(storage: VD3Storage) -> None:
    storage.import_video(SAMPLE_VIDEO, datasource="dashcam", name="clip-001")


def _populate_full(storage: VD3Storage) -> None:
    video = storage.import_video(SAMPLE_VIDEO, datasource="dashcam", name="clip-001")
    imageset = storage.import_imageset(SAMPLE_IMAGESET, datasource="frontporch", name="porch-001")

    # Tags on both assets, namespaced per the project convention
    storage.add_tag(video.asset_id, "split:training")
    storage.add_tag(video.asset_id, "scene:urban")
    storage.add_tag(imageset.asset_id, "split:validation")
    storage.add_tag(imageset.asset_id, "scene:residential")

    # Datasource descriptions
    storage.set_datasource_description("dashcam", "Forward-facing 2024 dashcam clips")
    storage.set_datasource_description("frontporch", "Residential front-porch camera stills")

    # Worksets with packages
    validation = storage.create_workset("Validation V2", slug="validation", description="Held-out for evaluation")
    training = storage.create_workset("Training V1", slug="training", description="Primary training set")
    calibration = storage.create_workset("Calibration", slug="calibration", description="Camera calibration set")

    storage.add_asset_to_workset(validation.workset_id, imageset.asset_id, package="held-out")
    storage.add_asset_to_workset(training.workset_id, video.asset_id, package="day")
    storage.add_asset_to_workset(calibration.workset_id, video.asset_id, package="indoor")

    # Annotation layers — one human GT and one machine detection per asset.
    _add_human_gt_layer(storage, video.asset_id, frame_count=10)
    _add_machine_det_layer(storage, video.asset_id, frame_count=10, layer="det/yolov8n")
    _add_human_gt_layer(storage, imageset.asset_id, frame_count=5)
    _add_machine_det_layer(storage, imageset.asset_id, frame_count=5, layer="det/yolov8n")


def _populate_coco(storage: VD3Storage) -> None:
    """Imageset asset with a COCO ground-truth layer imported from disk."""
    imageset = storage.import_imageset(SAMPLE_IMAGESET, datasource="frontporch", name="porch-001")
    storage.import_coco(
        imageset.asset_id,
        SAMPLE_COCO_JSON,
        layer="gt",
        display_name="Ground Truth",
        source="human",
        reviewed_all=True,
    )


def _populate_layers(storage: VD3Storage) -> None:
    """Single video asset carrying five distinct annotation layers."""
    video = storage.import_video(SAMPLE_VIDEO, datasource="dashcam", name="clip-001")
    _add_human_gt_layer(storage, video.asset_id, frame_count=10)
    _add_machine_det_layer(storage, video.asset_id, frame_count=10, layer="det/yolov8n")
    _add_machine_det_layer(storage, video.asset_id, frame_count=10, layer="det/yolov8m")
    _add_machine_track_layer(storage, video.asset_id, frame_count=10, layer="tracks/sort")
    _add_machine_track_layer(storage, video.asset_id, frame_count=10, layer="tracks/bytetrack")


# ---------------------------------------------------------------------------
# Annotation-layer helpers
# ---------------------------------------------------------------------------


def _add_human_gt_layer(storage: VD3Storage, asset_id: str, *, frame_count: int) -> None:
    annotations = {i: [{"class_name": "person", "bbox": [i, i, i + 8, i + 8]}] for i in range(frame_count)}
    storage.add_annotation_layer(
        asset_id,
        layer="gt",
        display_name="Ground Truth",
        annotations=annotations,
        source="human",
        layer_type="detections",
        reviewed_frames=list(range(frame_count)),
    )


def _add_machine_det_layer(storage: VD3Storage, asset_id: str, *, frame_count: int, layer: str) -> None:
    annotations = {
        i: [{"class_name": "person", "confidence": 0.9, "bbox": [i, i, i + 8, i + 8]}] for i in range(frame_count)
    }
    storage.add_annotation_layer(
        asset_id,
        layer=layer,
        display_name=layer,
        annotations=annotations,
        source="machine",
        layer_type="detections",
    )


def _add_machine_track_layer(storage: VD3Storage, asset_id: str, *, frame_count: int, layer: str) -> None:
    annotations = {
        i: [{"class_name": "person", "track_id": 1, "bbox": [i, i, i + 8, i + 8]}] for i in range(frame_count)
    }
    storage.add_annotation_layer(
        asset_id,
        layer=layer,
        display_name=layer,
        annotations=annotations,
        source="machine",
        layer_type="tracks",
    )
