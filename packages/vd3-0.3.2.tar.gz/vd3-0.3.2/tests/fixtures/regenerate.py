#!/usr/bin/env python3
"""Regenerate the committed sample-media fixtures.

Run this once when the on-disk fixtures need to be (re)created. The output
is checked into the repo so individual test runs are deterministic and
don't require ffmpeg/encoding at test time — only ffprobe (which the
package itself depends on) for probe-on-import.

Output:
    tests/fixtures/media/tiny.mp4              (~2 KB, 32x32, 1 second @ 10 fps)
    tests/fixtures/media/imageset/0001.jpg     (~600 B each)
    tests/fixtures/media/imageset/0002.jpg
    tests/fixtures/media/imageset/0003.jpg
    tests/fixtures/media/imageset/0004.jpg
    tests/fixtures/media/imageset/0005.jpg

Usage:
    uv run tests/fixtures/regenerate.py
"""

from __future__ import annotations

import subprocess
from pathlib import Path

from PIL import Image

HERE = Path(__file__).parent
MEDIA = HERE / "media"
IMAGESET = MEDIA / "imageset"


def regenerate_video() -> None:
    """Tiny deterministic 32x32 video for video-asset tests."""
    out = MEDIA / "tiny.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "testsrc=duration=1:size=32x32:rate=10",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-tune",
            "stillimage",
            str(out),
        ],
        check=True,
        capture_output=True,
    )
    print(f"  wrote {out.relative_to(HERE.parent)} ({out.stat().st_size:,} bytes)")


def regenerate_imageset() -> None:
    """Five distinct 32x32 JPEGs with solid-color content."""
    IMAGESET.mkdir(parents=True, exist_ok=True)
    # Solid colors chosen to be visually distinct, not perceptually meaningful.
    colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0), (255, 0, 255)]
    for i, color in enumerate(colors, start=1):
        out = IMAGESET / f"{i:04d}.jpg"
        Image.new("RGB", (32, 32), color).save(out, "JPEG", quality=85)
        print(f"  wrote {out.relative_to(HERE.parent)} ({out.stat().st_size:,} bytes)")


def main() -> None:
    MEDIA.mkdir(parents=True, exist_ok=True)
    print("Regenerating tests/fixtures/media/...")
    regenerate_video()
    regenerate_imageset()
    print("Done.")


if __name__ == "__main__":
    main()
