"""Coverage for ``vd3 workset`` CLI verbs not already covered by test_cli.py.

The basic CRUD (create/list/show/delete) and add/remove/assets happy
paths exist there. This file targets the remaining branches:

- ``workset show`` with packages / --packages flag
- ``workset assets`` with --paths / --filenames / --package modifiers
- ``workset layers`` happy path against a populated DB
- error paths (unknown workset on every verb, ambiguous asset name)
"""

from __future__ import annotations

from vd3storage.cli.app import app

# ---------------------------------------------------------------------------
# show
# ---------------------------------------------------------------------------


class TestWorksetShow:
    def test_show_full(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["workset", "show", "training", "--path", str(db_path)])
        assert result.exit_code == 0
        # Header + metadata
        assert "training" in result.output
        # The factory's "training" workset has one asset under package "day"
        assert "day" in result.output

    def test_show_unknown_workset(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["workset", "show", "no-such", "--path", str(db_path)])
        assert result.exit_code == 1
        assert "not found" in result.output


# ---------------------------------------------------------------------------
# assets — modifiers
# ---------------------------------------------------------------------------


class TestWorksetAssets:
    def test_assets_default_table(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["workset", "assets", "training", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "clip-001" in result.output

    def test_assets_paths_modifier(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["workset", "assets", "training", "--paths", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "clip-001.mp4" in result.output
        # No table styling — just paths
        assert "Resolution" not in result.output

    def test_assets_filenames_modifier(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["workset", "assets", "training", "--filenames", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "clip-001.mp4" in result.output

    def test_assets_filter_by_package(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["workset", "assets", "training", "--package", "day", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "clip-001" in result.output

    def test_assets_empty_after_package_filter(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["workset", "assets", "training", "--package", "nope", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "No assets" in result.output

    def test_assets_unknown_workset(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["workset", "assets", "nope", "--path", str(db_path)])
        assert result.exit_code == 1
        assert "not found" in result.output


# ---------------------------------------------------------------------------
# layers — happy path against a populated DB
# ---------------------------------------------------------------------------


class TestWorksetLayers:
    def test_layers_populated(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        # Factory builds a workset with assets carrying gt + det/yolov8n
        result = runner.invoke(app, ["workset", "layers", "training", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "gt" in result.output or "yolov8n" in result.output

    def test_layers_unknown_workset(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["workset", "layers", "nope", "--path", str(db_path)])
        assert result.exit_code == 1
        assert "not found" in result.output


# ---------------------------------------------------------------------------
# add / remove / delete — error and edge branches
# ---------------------------------------------------------------------------


class TestWorksetAddRemoveErrors:
    def test_add_to_unknown_workset(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["workset", "add", "nope", "clip-001", "--path", str(db_path)])
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_add_unmatched_asset(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["workset", "add", "training", "no-such-asset", "--path", str(db_path)])
        assert result.exit_code == 1
        assert "No assets matched" in result.output or "No asset matched" in result.output

    def test_add_with_package(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        # First create a new workset so the add is non-trivial
        runner.invoke(app, ["workset", "create", "Extra", "--path", str(db_path)])
        result = runner.invoke(
            app,
            ["workset", "add", "extra", "clip-001", "--package", "pkg-a", "--path", str(db_path)],
        )
        assert result.exit_code == 0
        assert "package: pkg-a" in result.output

    def test_remove_unknown_workset(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["workset", "remove", "nope", "clip-001", "--path", str(db_path)])
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_remove_unknown_asset(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["workset", "remove", "training", "no-such", "--path", str(db_path)])
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_delete_unknown_workset(self, cli_runner_with_db):
        runner, db_path = cli_runner_with_db
        result = runner.invoke(app, ["workset", "delete", "nope", "--path", str(db_path)])
        assert result.exit_code == 1
        assert "not found" in result.output


# ---------------------------------------------------------------------------
# _resolve_assets glob/path/ambiguous branches
# ---------------------------------------------------------------------------


class TestWorksetAddResolution:
    """Exercise the asset-resolution branches of `workset add`."""

    def test_list_empty(self, tmp_path):
        """`workset list` against a brand-new DB hits the empty branch."""
        from typer.testing import CliRunner

        runner = CliRunner()
        db_path = tmp_path / "db"
        assert runner.invoke(app, ["db", "init", str(db_path), "--no-git", "--no-dvc"]).exit_code == 0
        result = runner.invoke(app, ["workset", "list", "--path", str(db_path)])
        assert result.exit_code == 0
        assert "No worksets" in result.output

    def test_add_by_media_path(self, cli_runner_with_db):
        """When the pattern points at a real media file inside the DB, resolution succeeds."""
        runner, db_path = cli_runner_with_db
        runner.invoke(app, ["workset", "create", "ByPath", "--path", str(db_path)])

        # The clip-001 media file is at db_path/db/media/videos/dashcam/clip-001/clip-001.mp4
        from vd3storage import VD3Storage

        with VD3Storage(db_path) as s:
            video = next(a for a in s.list_assets() if a.asset_type == "video")
            media_path = db_path / video.media_path

        result = runner.invoke(app, ["workset", "add", "bypath", str(media_path), "--path", str(db_path)])
        assert result.exit_code == 0
        assert "Added" in result.output

    def test_add_with_ambiguous_name(self, tmp_path):
        """Two assets sharing a name → user gets an ambiguity warning, exit 1."""
        from typer.testing import CliRunner

        from tests.fixtures.factory import SAMPLE_VIDEO
        from vd3storage import VD3Storage

        runner = CliRunner()
        db_path = tmp_path / "db"
        assert runner.invoke(app, ["db", "init", str(db_path), "--no-git", "--no-dvc"]).exit_code == 0

        # Create two assets with the same name in different datasources
        video1 = tmp_path / "a.mp4"
        video1.write_bytes(SAMPLE_VIDEO.read_bytes())
        video2 = tmp_path / "b.mp4"
        video2.write_bytes(SAMPLE_VIDEO.read_bytes() + b"\0")
        with VD3Storage(db_path) as s:
            s.import_video(video1, datasource="ds-a", name="dup")
            s.import_video(video2, datasource="ds-b", name="dup")

        runner.invoke(app, ["workset", "create", "Pick", "--path", str(db_path)])
        result = runner.invoke(app, ["workset", "add", "pick", "dup", "--path", str(db_path)])
        # The CLI prints the warning but still exits 1 because no assets resolved
        assert result.exit_code == 1
        assert "Multiple assets named" in result.output

    def test_add_multiple_assets_reports_count(self, cli_runner_with_db):
        """Adding more than one asset to a workset prints a final count line."""
        runner, db_path = cli_runner_with_db
        runner.invoke(app, ["workset", "create", "Multi", "--path", str(db_path)])
        result = runner.invoke(
            app,
            ["workset", "add", "multi", "clip-001", "porch-001", "--path", str(db_path)],
        )
        assert result.exit_code == 0
        assert "2 assets added" in result.output
