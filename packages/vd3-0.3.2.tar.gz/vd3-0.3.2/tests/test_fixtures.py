"""Validate that the test-fixture factory produces the shapes documented in
:mod:`tests.fixtures.factory`.

These tests don't exercise the package's behavior — they exercise the
*fixtures themselves* so that other tests can rely on them without writing
defensive assertions inline. If one of these fails, treat it as a fixture
regression and update the factory or the test in lockstep.
"""

from __future__ import annotations


class TestEmptyScenario:
    def test_no_assets(self, empty_db):
        assert empty_db.list_assets() == []

    def test_no_worksets(self, empty_db):
        assert empty_db.list_worksets() == []


class TestMinimalScenario:
    def test_one_video_asset(self, minimal_db):
        assets = minimal_db.list_assets()
        assert len(assets) == 1
        assert assets[0].asset_type == "video"
        assert assets[0].datasource == "dashcam"

    def test_no_worksets(self, minimal_db):
        assert minimal_db.list_worksets() == []

    def test_one_datasource(self, minimal_db):
        ds = minimal_db.list_datasources()
        assert len(ds) == 1
        assert ds[0]["name"] == "dashcam"


class TestFullScenario:
    def test_two_assets(self, sample_db):
        assets = sample_db.list_assets()
        assert len(assets) == 2
        types = {a.asset_type for a in assets}
        assert types == {"video", "imageset"}

    def test_three_worksets(self, sample_db):
        slugs = {w.slug for w in sample_db.list_worksets()}
        assert slugs == {"validation", "training", "calibration"}

    def test_two_datasources_with_descriptions(self, sample_db):
        ds = {row["name"]: row for row in sample_db.list_datasources()}
        assert set(ds) == {"dashcam", "frontporch"}
        assert "2024 dashcam" in ds["dashcam"]["description"]
        assert "front-porch" in ds["frontporch"]["description"]

    def test_namespaced_tags_present(self, sample_db):
        # Each asset has at least one split: and one scene: tag
        for asset in sample_db.list_assets():
            tags = sample_db.get_tags(asset.asset_id)
            namespaces = {t.split(":", 1)[0] for t in tags}
            assert "split" in namespaces
            assert "scene" in namespaces

    def test_two_annotation_layers_per_asset(self, sample_db):
        for asset in sample_db.list_assets():
            layers = sample_db.list_annotation_layers(asset.asset_id)
            assert len(layers) == 2
            sources = {layer["source"] for layer in layers}
            assert sources == {"human", "machine"}


class TestCocoScenario:
    def test_one_imageset_asset(self, coco_db):
        assets = coco_db.list_assets()
        assert len(assets) == 1
        assert assets[0].asset_type == "imageset"

    def test_coco_layer_imported(self, coco_db):
        asset = coco_db.list_assets()[0]
        layers = coco_db.list_annotation_layers(asset.asset_id)
        assert any(layer["layer"] == "gt" for layer in layers)


class TestLayersScenario:
    def test_five_distinct_layers(self, layers_db):
        asset = layers_db.list_assets()[0]
        layers = layers_db.list_annotation_layers(asset.asset_id)
        names = {layer["layer"] for layer in layers}
        assert names == {"gt", "det/yolov8n", "det/yolov8m", "tracks/sort", "tracks/bytetrack"}

    def test_mixed_sources(self, layers_db):
        asset = layers_db.list_assets()[0]
        layers = layers_db.list_annotation_layers(asset.asset_id)
        by_source = {layer["layer"]: layer["source"] for layer in layers}
        assert by_source["gt"] == "human"
        assert by_source["det/yolov8n"] == "machine"
        assert by_source["tracks/sort"] == "machine"


class TestSharedFullDb:
    def test_each_test_sees_its_own_copy(self, cli_runner_with_db, tmp_path):
        """The session-scoped DB is copied per test so mutations are isolated."""
        runner, db_path = cli_runner_with_db
        assert db_path.exists()
        assert (db_path / "db" / "tables" / "assets.csv").exists()
        # Confirm the path is under this test's tmp_path (i.e. a copy, not the session root).
        assert tmp_path in db_path.parents
