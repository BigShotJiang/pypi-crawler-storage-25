"""Coverage for the error branches of ``VD3Storage.init``.

The init flow calls ``subprocess.run(["git", "init"], ...)`` and
``subprocess.run(["dvc", "init"], ...)`` when those toggles are on. Both
calls can fail two ways:

1. ``FileNotFoundError`` — the binary isn't on PATH.
2. ``CalledProcessError`` — the binary ran but returned non-zero.

Both branches log a warning instead of raising. These tests pin down the
specific log messages so a refactor that swallows the warning silently
gets caught.

Coverage target: storage.py lines 178-186 (git) and 188-206 (dvc).
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path

from vd3storage import VD3Storage


def _patch_subprocess_run(monkeypatch, *, fails_for: str, mode: str, exists_in_stderr: bool = False) -> None:
    """Make subprocess.run raise/error for git or dvc init calls.

    ``mode`` is one of:
        "missing"   → FileNotFoundError (binary not on PATH)
        "fails"     → CalledProcessError, exit 1, empty stderr
        "exists"    → CalledProcessError, exit 1, stderr matches '.*exists.*'
    """
    real_run = subprocess.run

    def fake_run(cmd, *args, **kwargs):  # type: ignore[no-untyped-def]
        if not (isinstance(cmd, list) and len(cmd) >= 2 and cmd[0] == fails_for and cmd[1] == "init"):
            return real_run(cmd, *args, **kwargs)
        if mode == "missing":
            raise FileNotFoundError(2, "No such file or directory", fails_for)
        stderr_text = "already exists in this repository" if exists_in_stderr else "boom: something broke"
        raise subprocess.CalledProcessError(1, cmd, output=b"", stderr=stderr_text.encode())

    monkeypatch.setattr(subprocess, "run", fake_run)


class TestInitGitErrorPaths:
    def test_git_missing_logs_warning(self, tmp_path: Path, monkeypatch, caplog):
        _patch_subprocess_run(monkeypatch, fails_for="git", mode="missing")
        with caplog.at_level(logging.WARNING):
            VD3Storage.init(tmp_path / "db", git_init=True, dvc_init=False)
        assert any("git is not installed" in rec.message for rec in caplog.records)

    def test_git_failure_logs_warning(self, tmp_path: Path, monkeypatch, caplog):
        _patch_subprocess_run(monkeypatch, fails_for="git", mode="fails")
        with caplog.at_level(logging.WARNING):
            VD3Storage.init(tmp_path / "db", git_init=True, dvc_init=False)
        warnings = [rec.message for rec in caplog.records if rec.levelno == logging.WARNING]
        assert any("Failed to initialize git" in m for m in warnings)


class TestInitDvcErrorPaths:
    def test_dvc_missing_logs_warning(self, tmp_path: Path, monkeypatch, caplog):
        _patch_subprocess_run(monkeypatch, fails_for="dvc", mode="missing")
        with caplog.at_level(logging.WARNING):
            VD3Storage.init(tmp_path / "db", git_init=False, dvc_init=True)
        assert any("DVC is not installed" in rec.message for rec in caplog.records)

    def test_dvc_failure_logs_warning(self, tmp_path: Path, monkeypatch, caplog):
        _patch_subprocess_run(monkeypatch, fails_for="dvc", mode="fails")
        with caplog.at_level(logging.WARNING):
            VD3Storage.init(tmp_path / "db", git_init=False, dvc_init=True)
        warnings = [rec.message for rec in caplog.records if rec.levelno == logging.WARNING]
        assert any("Failed to initialize DVC" in m for m in warnings)

    def test_dvc_already_exists_special_cased(self, tmp_path: Path, monkeypatch, caplog):
        _patch_subprocess_run(monkeypatch, fails_for="dvc", mode="fails", exists_in_stderr=True)
        with caplog.at_level(logging.WARNING):
            VD3Storage.init(tmp_path / "db", git_init=False, dvc_init=True)
        warnings = [rec.message for rec in caplog.records if rec.levelno == logging.WARNING]
        # The "exists" branch emits a more specific message than the generic failure
        assert any("DVC is already initialized" in m for m in warnings)


class TestInitToggles:
    """Sanity: git_init=False / dvc_init=False skips the call entirely."""

    def test_skips_git_when_disabled(self, tmp_path: Path, monkeypatch, caplog):
        # Patch git to fail; init should never invoke it, so no warning.
        _patch_subprocess_run(monkeypatch, fails_for="git", mode="missing")
        with caplog.at_level(logging.WARNING):
            VD3Storage.init(tmp_path / "db", git_init=False, dvc_init=False)
        assert not any("git is not installed" in rec.message for rec in caplog.records)

    def test_skips_dvc_when_disabled(self, tmp_path: Path, monkeypatch, caplog):
        _patch_subprocess_run(monkeypatch, fails_for="dvc", mode="missing")
        with caplog.at_level(logging.WARNING):
            VD3Storage.init(tmp_path / "db", git_init=False, dvc_init=False)
        assert not any("DVC is not installed" in rec.message for rec in caplog.records)
