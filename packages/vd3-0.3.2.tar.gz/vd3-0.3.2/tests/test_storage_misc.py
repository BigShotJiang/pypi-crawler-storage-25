"""Coverage for the long tail of VD3Storage methods.

Each test class targets a specific small method or error branch on
``VD3Storage`` that isn't already covered by the focused suites
(``test_storage.py`` for happy-path CRUD, ``test_storage_push_pull.py``
for DVC scoping, ``test_storage_init_errors.py`` for init).
"""

from __future__ import annotations

import shutil
import tarfile
from pathlib import Path

import pytest

from tests.fixtures.factory import SAMPLE_IMAGESET


class TestResolveMediaPath:
    def test_resolves_by_asset_object(self, sample_db):
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        path = sample_db.resolve_media_path(video)
        assert path == sample_db._path / video.media_path

    def test_resolves_by_asset_id_string(self, sample_db):
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        path = sample_db.resolve_media_path(video.asset_id)
        assert path == sample_db._path / video.media_path

    def test_unknown_asset_id_raises(self, sample_db):
        with pytest.raises(ValueError, match="Asset not found"):
            sample_db.resolve_media_path("does-not-exist")

    def test_asset_with_no_media_path_raises(self, sample_db):
        # Add a bare asset with no media_path (no import_video, just add_asset)
        bare = sample_db.add_asset(name="meta-only", datasource="orphan")
        with pytest.raises(ValueError, match="no media_path"):
            sample_db.resolve_media_path(bare)


class TestListAnnotationLayers:
    def test_returns_layers_for_valid_asset(self, sample_db):
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        layers = sample_db.list_annotation_layers(video.asset_id)
        names = {layer["layer"] for layer in layers}
        assert "gt" in names
        assert "det/yolov8n" in names

    def test_unknown_asset_raises(self, sample_db):
        with pytest.raises(ValueError, match="not found"):
            sample_db.list_annotation_layers("does-not-exist")


class TestReadAnnotationLayer:
    def test_round_trip_human_gt(self, sample_db):
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        layer = sample_db.read_annotation_layer(video.asset_id, "gt")
        assert layer["layer"] == "gt"
        assert layer["layer_type"] == "detections"
        assert "frames" in layer
        # Factory writes 10 frames of GT
        assert len(layer["frames"]) == 10

    def test_unknown_asset_raises(self, sample_db):
        with pytest.raises(ValueError, match="not found"):
            sample_db.read_annotation_layer("does-not-exist", "gt")

    def test_missing_layer_raises_file_not_found(self, sample_db):
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        with pytest.raises(FileNotFoundError):
            sample_db.read_annotation_layer(video.asset_id, "no/such/layer")


class TestGetAnnotations:
    def test_returns_layer_frame(self, sample_db):
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        # Factory's GT layer has 10 frames keyed 0..9 with one detection each
        result = sample_db.get_annotations(video.asset_id, "gt", 0)
        assert result is not None
        # read_annotations_for_frame returns the per-frame annotation slice
        assert isinstance(result, (list, dict))

    def test_unknown_asset_raises(self, sample_db):
        with pytest.raises(ValueError, match="not found"):
            sample_db.get_annotations("does-not-exist", "gt", 0)


class TestListWorksetAssetsWithPackages:
    def test_empty_workset_returns_empty(self, sample_db):
        empty_ws = sample_db.create_workset("Empty Workset", slug="empty-ws")
        result = sample_db.list_workset_assets_with_packages(empty_ws.workset_id)
        assert result == []

    def test_returns_asset_package_pairs(self, sample_db):
        training = next(w for w in sample_db.list_worksets() if w.slug == "training")
        pairs = sample_db.list_workset_assets_with_packages(training.workset_id)
        assert len(pairs) == 1
        asset, package = pairs[0]
        assert asset.asset_type == "video"
        assert package == "day"

    def test_filter_by_package(self, sample_db):
        training = next(w for w in sample_db.list_worksets() if w.slug == "training")
        # Filter to the "day" package — should still return the one asset
        pairs = sample_db.list_workset_assets_with_packages(training.workset_id, package="day")
        assert len(pairs) == 1

        # Filter to a non-existent package
        none_pairs = sample_db.list_workset_assets_with_packages(training.workset_id, package="night")
        assert none_pairs == []


class TestImportImagesetFromTar:
    """Exercise the .tar branch of import_imageset (lines ~775-784)."""

    @pytest.fixture
    def imageset_tar(self, tmp_path: Path) -> Path:
        """Tar up the committed sample imageset into a single .tar archive."""
        # Tar a parent dir that contains the imageset so we exercise the
        # "single top-level dir" auto-strip in import_imageset.
        staging = tmp_path / "staging"
        staging.mkdir()
        shutil.copytree(SAMPLE_IMAGESET, staging / "imageset")

        tar_path = tmp_path / "sample.tar"
        with tarfile.open(tar_path, "w") as tar:
            tar.add(staging / "imageset", arcname="imageset")
        return tar_path

    def test_import_from_tar(self, sample_db, imageset_tar):
        asset = sample_db.import_imageset(imageset_tar, datasource="archived", name="from-tar")
        assert asset.asset_type == "imageset"
        # Five JPEGs in the archive → five-frame imageset
        assert asset.frame_count == 5

    def test_import_from_tar_rejects_non_archive_file(self, sample_db, tmp_path):
        bogus = tmp_path / "bogus.txt"
        bogus.write_text("not an archive")
        with pytest.raises(ValueError, match="directory or .tar archive"):
            sample_db.import_imageset(bogus, datasource="archived", name="x")


class TestSmallBranches:
    """Pin down a handful of leftover branches in storage.py."""

    def test_update_workset_persists_changes(self, sample_db):
        ws = sample_db.create_workset("Temp", slug="temp", description="initial")
        ws.description = "updated"
        sample_db.update_workset(ws)
        fresh = sample_db.get_workset_by_id(ws.workset_id)
        assert fresh is not None
        assert fresh.description == "updated"

    def test_add_asset_to_workset_reassigns_package(self, sample_db):
        """Re-adding an existing membership with a different package updates it."""
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        ws = next(w for w in sample_db.list_worksets() if w.slug == "validation")

        # Add the video to validation under "day"
        sample_db.add_asset_to_workset(ws.workset_id, video.asset_id, package="day")
        # Re-add the same video with a different package — should update, not duplicate
        sample_db.add_asset_to_workset(ws.workset_id, video.asset_id, package="night")

        pairs = sample_db.list_workset_assets_with_packages(ws.workset_id)
        video_pairs = [(a, p) for a, p in pairs if a.asset_id == video.asset_id]
        assert len(video_pairs) == 1
        assert video_pairs[0][1] == "night"

    def test_delete_asset_removes_dvc_pointer(self, sample_db):
        """delete_asset(delete_media=True) also unlinks any sidecar .dvc file."""
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        dvc_path = sample_db._path / f"{video.media_path}.dvc"
        dvc_path.parent.mkdir(parents=True, exist_ok=True)
        dvc_path.write_text("outs: []\n")

        sample_db.delete_asset(video.asset_id, delete_media=True)
        assert not dvc_path.exists()

    def test_import_video_force_replaces_by_name(self, sample_db, tmp_path):
        from tests.fixtures.factory import SAMPLE_VIDEO

        # The dashcam datasource already has clip-001. Re-import with force=True
        # under a different filename so the source_hash differs, exercising the
        # "duplicate by name (not by hash)" force branch.
        copy = tmp_path / "tiny-copy.mp4"
        copy.write_bytes((SAMPLE_VIDEO).read_bytes())
        # Tweak the file so source_hash differs
        copy.write_bytes(copy.read_bytes() + b"\0")

        with pytest.raises(ValueError, match="already exists"):
            sample_db.import_video(copy, datasource="dashcam", name="clip-001")

        # With force=True, it succeeds
        sample_db.import_video(copy, datasource="dashcam", name="clip-001", force=True)
        # Still one clip-001 in dashcam afterward
        videos = [a for a in sample_db.list_assets() if a.datasource == "dashcam" and a.name == "clip-001"]
        assert len(videos) == 1

    def test_import_imageset_force_replaces_by_name(self, sample_db, tmp_path):
        from tests.fixtures.factory import SAMPLE_IMAGESET

        # Copy the committed imageset to a temp dir so we can re-import
        copy = tmp_path / "imageset"
        copy.mkdir()
        for src in SAMPLE_IMAGESET.iterdir():
            (copy / src.name).write_bytes(src.read_bytes())

        # frontporch already has porch-001 from the factory
        with pytest.raises(ValueError, match="already exists"):
            sample_db.import_imageset(copy, datasource="frontporch", name="porch-001")

        sample_db.import_imageset(copy, datasource="frontporch", name="porch-001", force=True)
        assets = [a for a in sample_db.list_assets() if a.datasource == "frontporch" and a.name == "porch-001"]
        assert len(assets) == 1

    def test_import_coco_rejects_human_without_reviewed(self, coco_db, tmp_path):
        """import_coco with source='human' but no reviewed_frames / reviewed_all raises."""
        from tests.fixtures.factory import SAMPLE_COCO_JSON

        asset = coco_db.list_assets()[0]
        with pytest.raises(ValueError, match="reviewed_frames"):
            coco_db.import_coco(
                asset.asset_id,
                SAMPLE_COCO_JSON,
                layer="another",
                source="human",
            )


class TestRemoteStatus:
    """remote_status counts media-availability (local vs. remote-only)."""

    def test_all_media_present_locally(self, sample_db):
        status = sample_db.remote_status()
        assert status["total_assets"] == 2
        assert status["available"] == 2
        assert status["unavailable"] == 0

    def test_missing_media_shows_unavailable(self, sample_db):
        # Delete one asset's media on disk to simulate a remote-only state
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        media = sample_db._path / video.media_path
        media.unlink()
        status = sample_db.remote_status()
        assert status["available"] == 1
        assert status["unavailable"] == 1
