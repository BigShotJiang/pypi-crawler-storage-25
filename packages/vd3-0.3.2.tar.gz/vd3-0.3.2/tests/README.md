# vd3storage tests

The test suite is plain `pytest`. Run from the `vd3storage/` directory:

```bash
uv run pytest tests -q                       # full suite, quiet
uv run pytest tests/test_storage.py -q       # one file
uv run pytest tests -k "TestFullScenario"    # filter by name
./scripts/coverage.sh                        # full suite + line/branch coverage
```

## Layout

```
tests/
├── conftest.py             — shared fixtures (see catalog below)
├── fixtures/
│   ├── factory.py          — build_sample_db() with 5 named scenarios
│   ├── regenerate.py       — one-shot script to rebuild committed media
│   ├── media/
│   │   ├── tiny.mp4        — 32×32, 1 sec, ~2.5 KB (committed binary)
│   │   └── imageset/       — 5 solid-color 32×32 JPEGs (~650 B each)
│   └── data/
│       ├── sample.coco.json
│       └── sample.vd3.json
├── test_storage.py         — library API: VD3Storage CRUD, tags, worksets, …
├── test_cli.py             — Typer CLI surfaces (one test per verb)
├── test_coco_importer.py   — COCO file parsing
├── test_coco_roundtrip.py  — VD3 ↔ COCO export round-trips
├── test_dvc.py             — DVCManager wrapper
├── test_fixtures.py        — validates the factory itself produces the right shapes
├── test_imageset.py        — imageset metadata / readers
├── test_importer.py        — VD3 JSON importer
├── test_media.py           — video/imageset readers, frame extraction
├── test_models.py          — Pydantic model validation
├── test_orm.py             — Engine, Table, Query
└── test_reviewed_frames.py — annotation review-tracking
```

## Fixture catalog

All fixtures live in `tests/conftest.py`. Pick the smallest one that
covers the surface you're testing — defaulting to `sample_db` is fine
for integration-style tests where you don't care about every detail.

| Fixture | Scope | Scenario | What it gives you |
|---|---|---|---|
| `tmp_storage` | function | `empty` | Original empty-DB fixture, kept for backward compat with `test_storage.py`. Prefer `empty_db` for new code. |
| `empty_db` | function | `empty` | Fresh `VD3Storage.init` with nothing in it. |
| `minimal_db` | function | `minimal` | One datasource (`dashcam`) + one video asset (`clip-001`). |
| `sample_db` | function | `full` | Two datasources (video + imageset), three worksets with packages (`validation`/`training`/`calibration`), two annotation layers per asset (one human GT, one machine detection), namespaced tags, datasource descriptions. The default. |
| `coco_db` | function | `coco` | Imageset asset with a COCO ground-truth layer imported from `tests/fixtures/data/sample.coco.json`. |
| `layers_db` | function | `layers` | Single video asset carrying five distinct annotation layers (one human GT, two machine detection, two machine track). |
| `shared_full_db` | **session** | `full` | Path to a pre-built `full` DB built once per session. **Read-only**; mutating it pollutes downstream tests. Use `cli_runner_with_db` for a mutable per-test copy. |
| `cli_runner_with_db` | function | `full` | `(typer.testing.CliRunner, db_path)` where `db_path` is a fresh copy of `shared_full_db`. Use for CLI tests that need a populated DB. |

## Example

```python
def test_workset_listing_includes_descriptions(sample_db):
    rows = sample_db.list_worksets_with_stats()
    by_slug = {row["slug"]: row for row in rows}
    assert by_slug["validation"]["description"] == "Held-out for evaluation"
    assert by_slug["training"]["asset_count"] == 1


def test_cli_datasource_show_includes_description(cli_runner_with_db):
    runner, db_path = cli_runner_with_db
    result = runner.invoke(app, ["datasource", "show", "dashcam", "--path", str(db_path)])
    assert result.exit_code == 0
    assert "Forward-facing 2024" in result.output
```

## Sample media

The binaries under `tests/fixtures/media/` are committed so test runs are
deterministic and don't have to encode video on every invocation. If you
need to regenerate them (e.g. after changing the factory's expectations
about size or frame count):

```bash
uv run tests/fixtures/regenerate.py
```

The script is idempotent — re-running produces byte-identical output for
the JPEGs and bit-deterministic output for the MP4 modulo encoder
differences. ffmpeg and PIL must be installed (they already are via the
dev group).

## Why scenarios, not snapshots

The factory builds against the live `VD3Storage` API rather than checking
in a `.db/` snapshot directory because:

1. **Schema evolves.** `SCHEMA_VERSION` is currently 8. A committed
   snapshot would need a migration for every bump; a factory builds
   against the current schema for free.
2. **Diffs stay readable.** Hand-edited test data in `tests/fixtures/data/`
   shows up cleanly in PRs; a snapshot would mostly be binary churn.
3. **Adding a scenario is one function edit.** Add a new key to
   `SCENARIOS` and a `_populate_<name>` helper — done.

If a scenario gets expensive enough that per-test rebuild dominates suite
runtime (>1 s overhead), promote it to a session-scoped variant alongside
`shared_full_db`. None do today.
