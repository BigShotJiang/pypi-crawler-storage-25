"""Coverage for ``vd3 layer`` CLI verbs.

Both verbs (``add-coco`` and ``add-vd3``) need an existing asset to operate
on, so we drive them against ``cli_runner_with_db`` (full populated DB).
"""

from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

from tests.fixtures.factory import SAMPLE_COCO_JSON, SAMPLE_IMAGESET, SAMPLE_VD3_JSON, SAMPLE_VIDEO
from vd3storage.cli.app import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# _resolve_asset error branches (shared between both verbs)
# ---------------------------------------------------------------------------


class TestResolveAssetErrors:
    def test_unknown_asset_name(self, cli_runner_with_db, tmp_path: Path):
        runner_, db_path = cli_runner_with_db
        # Use add-vd3 — simpler args, doesn't need a valid coco file
        sample = tmp_path / "anns.vd3.json"
        sample.write_bytes(SAMPLE_VD3_JSON.read_bytes())
        result = runner_.invoke(
            app,
            ["layer", "add-vd3", "no-such-asset", "run-1", str(sample), "--path", str(db_path)],
        )
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_ambiguous_asset_name(self, tmp_path: Path):
        """Two assets with the same name in different datasources → must use ID."""
        # Build a fresh DB so we control the data
        db_path = tmp_path / "db"
        assert runner.invoke(app, ["db", "init", str(db_path), "--no-git", "--no-dvc"]).exit_code == 0

        video1 = tmp_path / "a.mp4"
        video1.write_bytes(SAMPLE_VIDEO.read_bytes())
        # Create two assets with the same logical name in different datasources.
        # We do this via the Python API to bypass the import-dedup logic.
        from vd3storage import VD3Storage

        with VD3Storage(db_path) as s:
            s.import_video(video1, datasource="ds-a", name="twin")
            video2 = tmp_path / "b.mp4"
            # Mutate so source_hash differs
            video2.write_bytes(SAMPLE_VIDEO.read_bytes() + b"\0")
            s.import_video(video2, datasource="ds-b", name="twin")

        vd3 = tmp_path / "anns.vd3.json"
        vd3.write_bytes(SAMPLE_VD3_JSON.read_bytes())
        result = runner.invoke(app, ["layer", "add-vd3", "twin", "run-1", str(vd3), "--path", str(db_path)])
        assert result.exit_code == 1
        assert "Multiple assets named" in result.output

    def test_resolve_by_asset_id_succeeds(self, cli_runner_with_db, tmp_path: Path):
        runner_, db_path = cli_runner_with_db
        from vd3storage import VD3Storage

        with VD3Storage(db_path) as s:
            video = next(a for a in s.list_assets() if a.asset_type == "video")

        vd3 = tmp_path / "anns.vd3.json"
        vd3.write_bytes(SAMPLE_VD3_JSON.read_bytes())
        result = runner_.invoke(
            app,
            ["layer", "add-vd3", video.asset_id, "run-1", str(vd3), "--path", str(db_path)],
        )
        assert result.exit_code == 0
        assert "Imported" in result.output


# ---------------------------------------------------------------------------
# add-vd3
# ---------------------------------------------------------------------------


class TestLayerAddVd3:
    def test_imports_all_layers_under_prefix(self, cli_runner_with_db, tmp_path: Path):
        runner_, db_path = cli_runner_with_db
        vd3 = tmp_path / "anns.vd3.json"
        vd3.write_bytes(SAMPLE_VD3_JSON.read_bytes())
        result = runner_.invoke(app, ["layer", "add-vd3", "clip-001", "run-1", str(vd3), "--path", str(db_path)])
        assert result.exit_code == 0
        # Sample VD3 file has two layers (det/yolov8n, tracks/sort); both prefixed with "run-1/"
        assert "run-1/det/yolov8n" in result.output
        assert "run-1/tracks/sort" in result.output

    def test_empty_file_reports_no_layers(self, cli_runner_with_db, tmp_path: Path):
        """A VD3 file with an empty `layers` list should report 'No layers in file'."""
        runner_, db_path = cli_runner_with_db
        empty = tmp_path / "empty.vd3.json"
        empty.write_text('{"layers": []}')
        result = runner_.invoke(app, ["layer", "add-vd3", "clip-001", "run", str(empty), "--path", str(db_path)])
        assert result.exit_code == 0
        assert "No layers" in result.output


# ---------------------------------------------------------------------------
# add-coco
# ---------------------------------------------------------------------------


class TestLayerAddCoco:
    @pytest.fixture
    def coco_workspace_db(self, tmp_path: Path) -> tuple[CliRunner, Path]:
        """Fresh DB with an imageset asset suitable for the sample COCO file."""
        db_path = tmp_path / "db"
        assert runner.invoke(app, ["db", "init", str(db_path), "--no-git", "--no-dvc"]).exit_code == 0

        # Copy the committed imageset and import it
        ws_imageset = tmp_path / "imageset"
        ws_imageset.mkdir()
        for src in SAMPLE_IMAGESET.iterdir():
            (ws_imageset / src.name).write_bytes(src.read_bytes())
        assert (
            runner.invoke(
                app,
                ["datasource", "add-imageset", "ds", str(ws_imageset), "--path", str(db_path)],
            ).exit_code
            == 0
        )
        return runner, db_path

    def test_basic_import(self, coco_workspace_db, tmp_path: Path):
        runner_, db_path = coco_workspace_db
        # The sample COCO JSON references 0001.jpg ... 0005.jpg — drop both alongside
        coco = tmp_path / "anns.coco.json"
        coco.write_bytes(SAMPLE_COCO_JSON.read_bytes())
        # Symlink the imageset images next to the coco file so the importer's
        # relative-path resolution works.
        for src in SAMPLE_IMAGESET.iterdir():
            (tmp_path / src.name).write_bytes(src.read_bytes())

        result = runner_.invoke(
            app,
            ["layer", "add-coco", "imageset", "gt", str(coco), "--path", str(db_path)],
        )
        assert result.exit_code == 0
        assert "Imported COCO annotations" in result.output

    def test_with_human_source_reviewed_all(self, coco_workspace_db, tmp_path: Path):
        runner_, db_path = coco_workspace_db
        coco = tmp_path / "anns.coco.json"
        coco.write_bytes(SAMPLE_COCO_JSON.read_bytes())
        for src in SAMPLE_IMAGESET.iterdir():
            (tmp_path / src.name).write_bytes(src.read_bytes())

        result = runner_.invoke(
            app,
            [
                "layer",
                "add-coco",
                "imageset",
                "gt",
                str(coco),
                "--source",
                "human",
                "--reviewed-all",
                "--path",
                str(db_path),
            ],
        )
        assert result.exit_code == 0

    def test_error_on_video_asset(self, cli_runner_with_db, tmp_path: Path):
        """add-coco against a video asset is rejected (COCO is for imagesets only)."""
        runner_, db_path = cli_runner_with_db
        coco = tmp_path / "anns.coco.json"
        coco.write_bytes(SAMPLE_COCO_JSON.read_bytes())

        result = runner_.invoke(
            app,
            ["layer", "add-coco", "clip-001", "gt", str(coco), "--path", str(db_path)],
        )
        assert result.exit_code == 1
        assert "Error" in result.output
