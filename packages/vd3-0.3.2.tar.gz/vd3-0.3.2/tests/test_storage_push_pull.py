"""Coverage for ``VD3Storage.push`` / ``.pull`` scope handling.

These methods select a set of assets, optionally auto-tracking untracked
media, then delegate to ``DVCManager.push/pull``. The DVC layer itself is
exercised by ``test_dvc.py`` against a real ``dvc`` binary; here we replace
``_get_dvc_manager()`` with :class:`tests.fakes.dvc.FakeDVCManager` so the
focus is the scope/dedup/untracked-discovery logic in ``storage.py``.

Coverage target: storage.py 1525-1602 (pull + push) and 1630-1660
(_resolve_dvc_files).
"""

from __future__ import annotations

from pathlib import Path

import pytest


def _fake_track_all(storage) -> dict[str, Path]:
    """Write a synthetic ``<media>.dvc`` pointer beside every asset's media.

    Returns ``{asset_id: dvc_path}`` so tests can assert against the exact paths
    that ``_resolve_dvc_files`` will produce.
    """
    pointers: dict[str, Path] = {}
    for asset in storage.list_assets():
        if not asset.media_path:
            continue
        dvc_path = storage._path / f"{asset.media_path}.dvc"
        dvc_path.parent.mkdir(parents=True, exist_ok=True)
        dvc_path.write_text("outs: []\n")
        pointers[asset.asset_id] = dvc_path
    return pointers


# ---------------------------------------------------------------------------
# push() — scope handling with tracked media
# ---------------------------------------------------------------------------


class TestPushScopesAllTracked:
    """Pre-create .dvc pointers so _resolve_dvc_files returns real paths."""

    def test_push_no_scope_pushes_everything(self, sample_db, fake_dvc):
        _fake_track_all(sample_db)
        sample_db.push()
        # The no-scope branch calls mgr.push() with no args — recorded as None.
        assert fake_dvc.pushed_paths == [None]
        # No untracked discovery since we pre-created .dvc files.
        assert fake_dvc.added == []

    def test_push_asset_ids(self, sample_db, fake_dvc):
        pointers = _fake_track_all(sample_db)
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        sample_db.push(asset_ids=[video.asset_id])

        assert len(fake_dvc.pushed_paths) == 1
        scoped = fake_dvc.pushed_paths[0]
        assert scoped == [pointers[video.asset_id]]

    def test_push_workset_id(self, sample_db, fake_dvc):
        pointers = _fake_track_all(sample_db)
        ws = next(w for w in sample_db.list_worksets() if w.slug == "training")
        sample_db.push(workset_id=ws.workset_id)

        # The 'training' workset has the video asset.
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        assert fake_dvc.pushed_paths[0] == [pointers[video.asset_id]]

    def test_push_datasource_scope(self, sample_db, fake_dvc):
        pointers = _fake_track_all(sample_db)
        sample_db.push(datasource="dashcam")

        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        assert fake_dvc.pushed_paths[0] == [pointers[video.asset_id]]

    def test_push_combined_scopes_deduplicates(self, sample_db, fake_dvc):
        """An asset reachable via both asset_ids and a workset should only be pushed once."""
        pointers = _fake_track_all(sample_db)
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        training = next(w for w in sample_db.list_worksets() if w.slug == "training")

        sample_db.push(asset_ids=[video.asset_id], workset_id=training.workset_id)

        scoped = fake_dvc.pushed_paths[-1]
        # The same .dvc file must not be passed twice.
        assert scoped == [pointers[video.asset_id]]

    def test_push_unknown_asset_id_silently_skipped(self, sample_db, fake_dvc):
        _fake_track_all(sample_db)
        sample_db.push(asset_ids=["does-not-exist"])
        # No real asset matched → resolved scope is empty → mgr.push([]) is called.
        assert fake_dvc.pushed_paths == [[]]


class TestPushUntrackedDiscovery:
    """``push()`` runs ``dvc add`` on any media file that lacks a ``.dvc`` pointer."""

    def test_missing_pointer_triggers_add(self, sample_db, fake_dvc):
        """Fresh sample_db has no .dvc files → both media paths get added before push."""
        sample_db.push()

        added_paths = {p for call in fake_dvc.added for p in call}
        media_paths = {sample_db._path / a.media_path for a in sample_db.list_assets()}
        assert added_paths == media_paths

    def test_existing_pointer_not_re_added(self, sample_db, fake_dvc):
        """When every asset already has a .dvc pointer, no add() is recorded."""
        _fake_track_all(sample_db)
        sample_db.push()
        assert fake_dvc.added == []

    def test_partial_tracking_only_adds_missing(self, sample_db, fake_dvc):
        """If one asset has a .dvc and the other doesn't, only the missing one gets added."""
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        dvc_path = sample_db._path / f"{video.media_path}.dvc"
        dvc_path.parent.mkdir(parents=True, exist_ok=True)
        dvc_path.write_text("outs: []\n")

        sample_db.push()
        added_paths = {p for call in fake_dvc.added for p in call}
        # The video already has a .dvc pointer → not added. The imageset does not → added.
        imageset = next(a for a in sample_db.list_assets() if a.asset_type == "imageset")
        assert added_paths == {sample_db._path / imageset.media_path}


# ---------------------------------------------------------------------------
# pull() — scope handling
# ---------------------------------------------------------------------------


class TestPullScopes:
    def test_pull_no_scope_pulls_everything(self, sample_db, fake_dvc):
        sample_db.pull()
        assert fake_dvc.pulled_paths == [None]

    def test_pull_asset_ids(self, sample_db, fake_dvc):
        pointers = _fake_track_all(sample_db)
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        sample_db.pull(asset_ids=[video.asset_id])

        assert fake_dvc.pulled_paths == [[pointers[video.asset_id]]]

    def test_pull_workset_id(self, sample_db, fake_dvc):
        pointers = _fake_track_all(sample_db)
        ws = next(w for w in sample_db.list_worksets() if w.slug == "training")
        sample_db.pull(workset_id=ws.workset_id)

        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        assert fake_dvc.pulled_paths == [[pointers[video.asset_id]]]

    def test_pull_datasource(self, sample_db, fake_dvc):
        pointers = _fake_track_all(sample_db)
        sample_db.pull(datasource="dashcam")
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        assert fake_dvc.pulled_paths == [[pointers[video.asset_id]]]

    def test_pull_empty_scope_falls_through_to_pull_all(self, sample_db, fake_dvc):
        """A scope that resolves to zero matching .dvc files ends up calling pull()."""
        sample_db.pull(asset_ids=["does-not-exist"])
        # _resolve_dvc_files returns [] → the "no files" branch triggers pull() with no scope.
        assert fake_dvc.pulled_paths == [None]


# ---------------------------------------------------------------------------
# is_media_available + add_remote (small wrappers)
# ---------------------------------------------------------------------------


class TestMediaAvailability:
    def test_video_present_locally(self, sample_db):
        video = next(a for a in sample_db.list_assets() if a.asset_type == "video")
        assert sample_db.is_media_available(video.asset_id) is True

    def test_unknown_asset_raises(self, sample_db):
        with pytest.raises(ValueError, match="not found"):
            sample_db.is_media_available("does-not-exist")


class TestAddRemoteDelegates:
    def test_add_remote_delegates_to_dvc_manager(self, sample_db, fake_dvc):
        sample_db.add_remote("s3-prod", "s3://bucket/prefix", default=True)
        assert fake_dvc.remotes == [("s3-prod", "s3://bucket/prefix", True)]
