#!/usr/bin/env bash
# Run the vd3 test suite with coverage measurement.
#
# Usage:
#   ./scripts/coverage.sh                  # term-missing + HTML + XML
#   ./scripts/coverage.sh --quick          # term-missing only, no HTML/XML write
#   ./scripts/coverage.sh --check          # CI mode: fail if below pyproject fail_under
#
# Output files:
#   htmlcov/index.html  (gitignored)       — interactive HTML report
#   coverage.xml        (gitignored)       — Cobertura XML for diff-cover / CI tooling
#
# This script is invoked by both the publish skill's quality gates and the
# GitHub Actions workflow (.github/workflows/test.yml), so the coverage
# measurement is identical locally and in CI.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_DIR"

MODE="${1:-full}"

case "$MODE" in
    full)
        uv run pytest tests \
            --cov=src/vd3storage \
            --cov-branch \
            --cov-report=term-missing \
            --cov-report=html \
            --cov-report=xml
        echo ""
        echo "HTML report: $PROJECT_DIR/htmlcov/index.html"
        echo "XML report:  $PROJECT_DIR/coverage.xml"
        ;;
    --quick)
        uv run pytest tests \
            --cov=src/vd3storage \
            --cov-branch \
            --cov-report=term-missing
        ;;
    --check)
        # CI / publish-gate mode: same as --quick but fail_under enforces the floor
        uv run pytest tests \
            --cov=src/vd3storage \
            --cov-branch \
            --cov-report=term
        ;;
    -h|--help)
        sed -n '2,15p' "$0"
        exit 0
        ;;
    *)
        echo "Unknown argument: $MODE" >&2
        echo "Try: ./scripts/coverage.sh --help" >&2
        exit 2
        ;;
esac
