#!/usr/bin/env python3
"""Build a populated VD3Storage at a known path so you can poke at it.

The test suite uses the same factory under ``tests/fixtures/factory.py``,
but its DBs live in pytest's ``tmp_path`` and disappear after the run.
This script lets you materialize the same scenarios to a stable path
and open them with the ``vd3`` CLI.

Usage:
    uv run scripts/build-sample-db.py /tmp/vd3-sample
    uv run scripts/build-sample-db.py /tmp/vd3-sample --scenario layers
    uv run scripts/build-sample-db.py /tmp/vd3-sample --force

Then inspect with:
    vd3 db info --path /tmp/vd3-sample
    vd3 datasource list --path /tmp/vd3-sample
    vd3 workset assets validation --path /tmp/vd3-sample
"""

from __future__ import annotations

import shutil
import sys
from pathlib import Path

import typer
from rich.console import Console

# Make ``tests.fixtures.factory`` importable when this script runs from the
# project root: we add ``<project-root>`` to sys.path so the ``tests`` package
# can be imported.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from tests.fixtures.factory import SCENARIOS, build_sample_db  # noqa: E402

console = Console()
app = typer.Typer(
    help=("Build a populated VD3 content database at a known path. Pick from the same scenarios the test suite uses."),
    add_completion=False,
    no_args_is_help=True,
)


@app.command()
def main(
    path: Path = typer.Argument(..., help="Where to build the database."),
    scenario: str = typer.Option(
        "full",
        "--scenario",
        "-s",
        help=f"Which scenario to build. One of: {', '.join(SCENARIOS)}",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Remove an existing directory at the target path before building.",
    ),
) -> None:
    """Build a populated VD3 content database at ``path``."""
    if scenario not in SCENARIOS:
        console.print(f"[red]Unknown scenario:[/] {scenario!r}")
        console.print(f"Pick from: {', '.join(SCENARIOS)}")
        raise typer.Exit(2)

    if path.exists():
        if not force:
            console.print(f"[red]Path already exists:[/] {path}\nPass [bold]--force[/] to remove it first.")
            raise typer.Exit(1)
        shutil.rmtree(path)
        console.print(f"[yellow]Removed existing[/] {path}")

    storage = build_sample_db(path, scenario=scenario)
    storage.save()
    storage._engine.close()

    console.print(
        f"[green]Built[/] [bold]{scenario}[/] scenario at [cyan]{path}[/]\n"
        f"\nInspect it with:\n"
        f"  [dim]vd3 db info --path {path}[/]\n"
        f"  [dim]vd3 datasource list --path {path}[/]\n"
        f"  [dim]vd3 workset list --path {path}[/]"
    )


if __name__ == "__main__":
    app()
