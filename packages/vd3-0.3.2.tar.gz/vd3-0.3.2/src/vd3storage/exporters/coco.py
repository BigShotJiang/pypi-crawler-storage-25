"""COCO annotation format exporter — converts VD3 annotation layers to COCO JSON.

Produces standard COCO detection format:
{
    "info": {"video_id": "...", "camera_id": "...", ...},
    "images": [{"id": 0, "frame_index": 0, "file_name": "...", "width": 640, "height": 480}, ...],
    "annotations": [{"id": 0, "image_id": 0, "category_id": 1, "bbox": [x, y, w, h], ...}, ...],
    "categories": [{"id": 0, "name": "person"}, ...]
}

Bbox conversion: VD3 [xmin, ymin, xmax, ymax] -> COCO [x, y, width, height]
Category mapping: VD3 class_name strings -> COCO integer category_id

The image ``file_name`` is the standard COCO spec field naming the image
file on disk relative to the dataset root. It is populated for imageset
assets where each frame is a separate file; it is omitted for video
assets where frames live inside a single MP4.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

# Default categories matching MLTK's convention
DEFAULT_CATEGORIES: list[dict[str, Any]] = [
    {"id": 0, "name": "person"},
    {"id": 1, "name": "vehicle"},
    {"id": 2, "name": "package"},
    {"id": 3, "name": "animal"},
]


def export_annotation_layer_as_coco(
    layer_data: dict[str, Any],
    *,
    width: int,
    height: int,
    categories: list[dict[str, Any]] | None = None,
    info: dict[str, Any] | None = None,
    image_filenames: dict[int, str] | None = None,
    image_dimensions: dict[int, tuple[int, int]] | None = None,
) -> dict[str, Any]:
    """Convert a VD3 annotation layer to COCO JSON format.

    Args:
        layer_data: Full VD3 annotation layer dict as returned by
                    ``annotation_store.read_annotation_layer()``. Expected keys:
                    ``layer``, ``display_name``, ``layer_type``, ``frames``.
        width: Image width in pixels — used as the fallback when
               ``image_dimensions`` does not cover a frame. For video assets
               every frame shares a single resolution and this is sufficient;
               for imageset assets pass per-frame sizes via ``image_dimensions``.
        height: Image height in pixels (see ``width``).
        categories: COCO category list. Each dict must have ``id`` (int) and
                    ``name`` (str). If None, uses the default 4-class set
                    (person, vehicle, package, animal).
        info: Optional dict to include as the COCO ``info`` block. Useful for
              embedding video_id, camera_id, video_path, etc.
        image_filenames: Optional mapping from frame index to image filename.
                         When provided, each emitted image entry carries a
                         ``file_name`` field (standard COCO spec). Frame
                         indices without a corresponding entry are silently
                         omitted from ``file_name`` population — useful for
                         partial mappings. Typically populated for imageset
                         assets from ``ImagesetMetadata``; left ``None`` for
                         video assets (no per-frame files on disk).
        image_dimensions: Optional mapping from frame index to
                          ``(width, height)``. Used for imageset assets
                          where each image can have its own resolution.
                          Frames without an entry fall back to the scalar
                          ``width`` / ``height``.

    Returns:
        Standard COCO dict with ``info``, ``images``, ``annotations``,
        and ``categories`` keys.
    """
    if categories is None:
        categories = DEFAULT_CATEGORIES

    # Build name -> id lookup
    name_to_id: dict[str, int] = {cat["name"]: cat["id"] for cat in categories}

    frames: dict[str, list[dict[str, Any]]] = layer_data.get("frames", {})

    # Build COCO images — use reviewed_frames when available (includes negatives),
    # otherwise fall back to frames dict keys (only annotated frames).
    coco_images: list[dict[str, Any]] = []
    if "reviewed_frames" in layer_data:
        frame_indices = sorted(layer_data["reviewed_frames"])
    else:
        frame_indices = sorted(int(k) for k in frames)

    for frame_idx in frame_indices:
        if image_dimensions is not None and frame_idx in image_dimensions:
            img_w, img_h = image_dimensions[frame_idx]
        else:
            img_w, img_h = width, height
        image: dict[str, Any] = {
            "id": frame_idx,
            "frame_index": frame_idx,
            "width": img_w,
            "height": img_h,
        }
        if image_filenames is not None and frame_idx in image_filenames:
            image["file_name"] = image_filenames[frame_idx]
        coco_images.append(image)

    # Build COCO annotations
    coco_annotations: list[dict[str, Any]] = []
    annotation_id = 0

    for frame_idx in frame_indices:
        objects = frames.get(str(frame_idx), [])
        for obj in objects:
            class_name = obj.get("class_name", "")
            category_id = name_to_id.get(class_name)
            if category_id is None:
                logger.warning(
                    "Unknown class_name %r in frame %d — skipping annotation",
                    class_name,
                    frame_idx,
                )
                continue

            # Convert VD3 bbox [xmin, ymin, xmax, ymax] -> COCO [x, y, w, h]
            vd3_bbox = obj["bbox"]
            x1, y1, x2, y2 = vd3_bbox
            coco_bbox = [x1, y1, x2 - x1, y2 - y1]

            ann: dict[str, Any] = {
                "id": annotation_id,
                "image_id": frame_idx,
                "category_id": category_id,
                "bbox": coco_bbox,
                "area": coco_bbox[2] * coco_bbox[3],
                "iscrowd": 0,
            }

            # Preserve optional VD3 fields
            if "confidence" in obj:
                ann["confidence"] = obj["confidence"]
            if "track_id" in obj:
                ann["track_id"] = obj["track_id"]
            # Use original area if present (more precise for non-rectangular regions)
            if "area" in obj:
                ann["area"] = obj["area"]

            coco_annotations.append(ann)
            annotation_id += 1

    coco: dict[str, Any] = {
        "info": info or {},
        "images": coco_images,
        "annotations": coco_annotations,
        "categories": categories,
    }

    annotated_count = sum(1 for idx in frame_indices if str(idx) in frames)
    logger.info(
        "Exported COCO: %d images (%d annotated, %d negative), %d annotations, %d categories from layer '%s'",
        len(coco_images),
        annotated_count,
        len(coco_images) - annotated_count,
        len(coco_annotations),
        len(categories),
        layer_data.get("layer", "?"),
    )

    return coco
