"""VD3Storage — DVC-backed media database for computer vision and ML developers.

The names re-exported here (and listed in ``__all__``) are the supported public API.
Anything reachable through other import paths — submodules without a leading
underscore included — is internal and may change without notice. See the
"Versioning & stability" section of the README for what counts as a breaking
change.
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

try:
    __version__ = _pkg_version("vd3")
except PackageNotFoundError:  # source tree without installed metadata
    __version__ = "0.0.0+unknown"

from vd3storage.models.asset import Asset
from vd3storage.models.tag import Tag
from vd3storage.models.workset import Workset
from vd3storage.models.workset_asset import WorksetAsset
from vd3storage.storage import AlreadyInitializedError, VD3Storage

__all__ = [
    "AlreadyInitializedError",
    "Asset",
    "Tag",
    "VD3Storage",
    "Workset",
    "WorksetAsset",
    "__version__",
]
