# Plan: Improve `vd3 init` with `--force` and better error handling

## Problem

Running `vd3 init .` on an already-initialized directory produces a misleading error:

```
Failed to initialize DVC (dvc not available?)
```

The real issue is that `.dvc/` already exists and `dvc init` refuses to overwrite it. The catch-all exception handler lumps "not installed" and "already initialized" into one message.

## Requirements

1. **Detect existing initialization** — before doing anything, check for vd3 artifacts (directories: `db/tables/`, `.dvc/`, `.git/`; files: `pyproject.toml`, `.gitignore`, `README.md`, `src/example.py`). If any are found, **fail with a clear error** listing what exists.
2. **Add `--force` / `-f`** — when passed, remove existing vd3 artifacts and reinitialize cleanly. Without `--force`, no existing files are overwritten.
3. **Improve error messages** — distinguish "DVC not installed" from "DVC already initialized" from other failures.

## Changes by file

### 1. `src/vd3storage/storage.py`

#### Add `AlreadyInitializedError` (after `logger = logging.getLogger(__name__)`, before `_ALL_MODELS`)

```python
class AlreadyInitializedError(ValueError):
    """Raised when init is called on a directory that already has vd3 artifacts."""
```

#### Add `force` parameter to `VD3Storage.init()` signature

```python
def init(
    cls,
    path: str | Path,
    git_init: bool = True,
    dvc_init: bool = True,
    dev: bool = False,
    force: bool = False,   # NEW
) -> VD3Storage:
```

Update the docstring to document `force` and `AlreadyInitializedError`.

#### Add artifact detection (after `root.mkdir(parents=True, exist_ok=True)`, before directory structure creation)

```python
# Detect existing initialization artifacts
existing_artifacts: list[str] = []

# Check directories
if (root / "db" / "tables").exists():
    existing_artifacts.append("db/tables/ (content database)")
if (root / ".dvc").exists():
    existing_artifacts.append(".dvc/ (DVC)")
if git_init and (root / ".git").exists():
    existing_artifacts.append(".git/ (git repository)")

# Check generated files
_GENERATED_FILES = ["pyproject.toml", ".gitignore", "README.md", "src/example.py"]
for rel_path in _GENERATED_FILES:
    if (root / rel_path).exists():
        existing_artifacts.append(f"{rel_path} (generated file)")

if existing_artifacts and not force:
    artifact_list = "\n  - ".join(existing_artifacts)
    raise AlreadyInitializedError(
        f"Directory already initialized at {root}. "
        f"Found existing artifacts:\n  - {artifact_list}\n"
        f"Use --force to reinitialize."
    )

# If force, remove existing vd3 artifacts before recreating
if force:
    db_dir = root / "db"
    if db_dir.exists():
        shutil.rmtree(db_dir)
        logger.info("Removed existing db/ directory")
    dvc_dir = root / ".dvc"
    if dvc_dir.exists():
        shutil.rmtree(dvc_dir)
        logger.info("Removed existing .dvc/ directory")
    for rel_path in _GENERATED_FILES:
        fp = root / rel_path
        if fp.exists():
            fp.unlink()
            logger.info("Removed existing %s", rel_path)
```

**Design decisions:**
- `.git/` is NOT removed during `--force` — `git init` on an existing repo is a safe no-op, and removing `.git/` would destroy commit history, which is too destructive.
- `.dvc/` IS removed — DVC's own `dvc init -f` does the same; cache can be rebuilt from remote.
- `db/` IS removed — the database needs a clean slate.
- Generated files (`pyproject.toml`, `.gitignore`, `README.md`, `src/example.py`) ARE detected and removed during `--force`. Without `--force`, their presence blocks `init` — this protects user modifications to these files from being silently overwritten.

**Note on `_GENERATED_FILES`:** Define this as a module-level constant (e.g. after `_ALL_MODELS`) so it can be referenced by both the detection and cleanup blocks. This also makes it easy to extend if `init()` generates additional files in the future.

#### Improve git init error handling (replace the existing git init block)

```python
if git_init:
    try:
        subprocess.run(["git", "init"], cwd=root, check=True, capture_output=True)
        logger.info("Initialized git repository")
    except FileNotFoundError:
        logger.warning(
            "git is not installed or not on PATH. "
            "Install git to enable version control."
        )
    except subprocess.CalledProcessError as e:
        stderr = e.stderr.decode() if isinstance(e.stderr, bytes) else (e.stderr or "")
        logger.warning("Failed to initialize git repository: %s", stderr.strip() or f"exit code {e.returncode}")
```

#### Improve DVC init error handling (replace the existing DVC init block)

```python
if dvc_init:
    try:
        subprocess.run(["dvc", "init"], cwd=root, check=True, capture_output=True)
        logger.info("Initialized DVC")
    except FileNotFoundError:
        logger.warning(
            "DVC is not installed or not on PATH. "
            "Install it with: pip install dvc"
        )
    except subprocess.CalledProcessError as e:
        stderr = e.stderr.decode() if isinstance(e.stderr, bytes) else (e.stderr or "")
        if "exists" in stderr.lower():
            logger.warning(
                "DVC is already initialized in %s. "
                "Use --force to reinitialize.",
                root,
            )
        else:
            logger.warning(
                "Failed to initialize DVC: %s",
                stderr.strip() or f"exit code {e.returncode}",
            )
```

---

### 2. `src/vd3storage/__init__.py`

Export the new exception:

```python
from vd3storage.storage import AlreadyInitializedError, VD3Storage

__all__ = ["AlreadyInitializedError", "VD3Storage", "__version__"]
```

---

### 3. `src/vd3storage/cli/commands/init.py`

Replace the entire file:

```python
"""vd3 init — initialize a new content database."""

from __future__ import annotations

from pathlib import Path

import typer

from vd3storage.cli.formatters import console


def init_command(
    path: Path = typer.Argument(..., help="Path where the content database will be created"),
    dev: bool = typer.Option(False, "--dev", help="Add local vd3storage source override for development"),
    no_git: bool = typer.Option(False, "--no-git", help="Skip git initialization"),
    no_dvc: bool = typer.Option(False, "--no-dvc", help="Skip DVC initialization"),
    force: bool = typer.Option(False, "--force", "-f", help="Reinitialize even if already initialized (destroys existing data)"),
) -> None:
    """Initialize a new VD3 content database."""
    from vd3storage import VD3Storage
    from vd3storage.storage import AlreadyInitializedError

    try:
        storage = VD3Storage.init(path, git_init=not no_git, dvc_init=not no_dvc, dev=dev, force=force)
    except AlreadyInitializedError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1) from None

    console.print(f"[green]Created content database at[/] [bold]{storage.path}[/]")
    storage._engine.close()
```

---

### 4. `tests/test_storage.py`

Add import:

```python
from vd3storage.storage import AlreadyInitializedError
```

Add these tests to `TestInit`:

```python
def test_init_existing_db_raises(self, tmp_path):
    """Re-initializing an existing database should raise AlreadyInitializedError."""
    db_path = tmp_path / "test-db"
    s1 = VD3Storage.init(db_path, git_init=False, dvc_init=False)
    s1._engine.close()

    with pytest.raises(AlreadyInitializedError, match="already initialized"):
        VD3Storage.init(db_path, git_init=False, dvc_init=False)

def test_init_existing_db_lists_artifacts(self, tmp_path):
    """Error message should list which artifacts already exist."""
    db_path = tmp_path / "test-db"
    s1 = VD3Storage.init(db_path, git_init=False, dvc_init=False)
    s1._engine.close()

    with pytest.raises(AlreadyInitializedError, match="db/tables/"):
        VD3Storage.init(db_path, git_init=False, dvc_init=False)

def test_init_existing_dvc_raises(self, tmp_path):
    """Directory with only .dvc/ should still be detected."""
    db_path = tmp_path / "test-db"
    db_path.mkdir()
    (db_path / ".dvc").mkdir()

    with pytest.raises(AlreadyInitializedError, match=".dvc/"):
        VD3Storage.init(db_path, git_init=False, dvc_init=False)

def test_init_existing_git_raises_when_git_init_requested(self, tmp_path):
    """Directory with .git/ should be detected only when git_init=True."""
    db_path = tmp_path / "test-db"
    db_path.mkdir()
    (db_path / ".git").mkdir()

    with pytest.raises(AlreadyInitializedError, match=".git/"):
        VD3Storage.init(db_path, git_init=True, dvc_init=False)

def test_init_existing_git_ignored_when_git_init_false(self, tmp_path):
    """Directory with .git/ should NOT be flagged when git_init=False."""
    db_path = tmp_path / "test-db"
    db_path.mkdir()
    (db_path / ".git").mkdir()

    storage = VD3Storage.init(db_path, git_init=False, dvc_init=False)
    storage._engine.close()

def test_init_force_reinitializes(self, tmp_path):
    """--force should allow reinitializing an existing database."""
    db_path = tmp_path / "test-db"
    s1 = VD3Storage.init(db_path, git_init=False, dvc_init=False)
    s1.add_asset("old_asset.mp4", "col1")
    s1.save()
    s1._engine.close()

    s2 = VD3Storage.init(db_path, git_init=False, dvc_init=False, force=True)
    assert len(s2.list_assets()) == 0
    s2._engine.close()

def test_init_force_removes_dvc(self, tmp_path):
    """--force should remove existing .dvc/ directory."""
    db_path = tmp_path / "test-db"
    db_path.mkdir()
    dvc_dir = db_path / ".dvc"
    dvc_dir.mkdir()
    (dvc_dir / "config").write_text("[core]\n")

    storage = VD3Storage.init(db_path, git_init=False, dvc_init=False, force=True)
    assert not (db_path / ".dvc").exists()
    storage._engine.close()

def test_init_force_preserves_git(self, tmp_path):
    """--force should NOT remove .git/ (too destructive)."""
    db_path = tmp_path / "test-db"
    db_path.mkdir()
    git_dir = db_path / ".git"
    git_dir.mkdir()
    (git_dir / "HEAD").write_text("ref: refs/heads/main\n")

    storage = VD3Storage.init(db_path, git_init=False, dvc_init=False, force=True)
    assert (db_path / ".git").exists()
    assert (db_path / ".git" / "HEAD").exists()
    storage._engine.close()

def test_init_existing_pyproject_raises(self, tmp_path):
    """A pre-existing pyproject.toml should block init without --force."""
    db_path = tmp_path / "test-db"
    db_path.mkdir()
    (db_path / "pyproject.toml").write_text("[project]\nname = 'custom'\n")

    with pytest.raises(AlreadyInitializedError, match="pyproject.toml"):
        VD3Storage.init(db_path, git_init=False, dvc_init=False)

def test_init_existing_gitignore_raises(self, tmp_path):
    """A pre-existing .gitignore should block init without --force."""
    db_path = tmp_path / "test-db"
    db_path.mkdir()
    (db_path / ".gitignore").write_text("*.log\n")

    with pytest.raises(AlreadyInitializedError, match=".gitignore"):
        VD3Storage.init(db_path, git_init=False, dvc_init=False)

def test_init_force_overwrites_generated_files(self, tmp_path):
    """--force should remove and regenerate pyproject.toml, .gitignore, README.md, src/example.py."""
    db_path = tmp_path / "test-db"
    s1 = VD3Storage.init(db_path, git_init=False, dvc_init=False)
    s1._engine.close()

    # Modify pyproject.toml to prove it gets regenerated
    pyproject = db_path / "pyproject.toml"
    pyproject.write_text("[project]\nname = 'tampered'\n")

    s2 = VD3Storage.init(db_path, git_init=False, dvc_init=False, force=True)
    s2._engine.close()

    # Should be regenerated, not the tampered version
    content = pyproject.read_text()
    assert "tampered" not in content
    assert "vd3" in content.lower()
```

---

### 5. `tests/test_cli.py`

Add these tests to `TestInitCommand`:

```python
def test_init_already_initialized(self, tmp_path):
    """Re-running init on same directory should fail with clear error."""
    db = tmp_path / "existing-db"
    result = runner.invoke(app, ["init", str(db), "--no-git", "--no-dvc"])
    assert result.exit_code == 0

    result = runner.invoke(app, ["init", str(db), "--no-git", "--no-dvc"])
    assert result.exit_code == 1
    assert "already initialized" in result.output

def test_init_force(self, tmp_path):
    """--force should allow reinitializing."""
    db = tmp_path / "force-db"
    result = runner.invoke(app, ["init", str(db), "--no-git", "--no-dvc"])
    assert result.exit_code == 0

    result = runner.invoke(app, ["init", str(db), "--no-git", "--no-dvc", "--force"])
    assert result.exit_code == 0
    assert "Created content database" in result.output
```

---

## Execution order

1. Edit `src/vd3storage/storage.py` — add exception, modify `init()` signature/body, improve error handling
2. Edit `src/vd3storage/__init__.py` — export `AlreadyInitializedError`
3. Edit `src/vd3storage/cli/commands/init.py` — add `--force` flag and error handling
4. Edit `tests/test_storage.py` — add storage-level tests
5. Edit `tests/test_cli.py` — add CLI-level tests
6. Run `pytest tests/test_storage.py tests/test_cli.py tests/test_dvc.py -v`

## Pitfalls

- **DVC stderr is bytes**: `capture_output=True` returns `bytes` for `stderr` — must `.decode()` before string operations.
- **Cleanup ordering**: `db/` and `.dvc/` must be removed BEFORE the directory structure creation code runs.
- **`.git/` check is conditional**: Only flag `.git/` when `git_init=True` — if user passes `--no-git`, existing `.git/` is irrelevant.
- **Ruff**: Project uses ruff with `["E", "F", "I", "UP", "B", "SIM"]`. All new code must pass.
- **`shutil` import**: `storage.py` may not import `shutil` yet — add it if missing.
- **Generated files list**: Define `_GENERATED_FILES` as a module-level constant so both the detection and cleanup blocks reference the same list. If `init()` gains new generated files in the future, only one place needs updating.
- **`src/` directory**: `--force` removes `src/example.py` but does NOT remove the `src/` directory itself — the user may have added other files there.
