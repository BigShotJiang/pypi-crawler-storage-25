import uuid
from typing import List, Optional, TYPE_CHECKING

from sqlmodel import SQLModel, Field, Relationship

if TYPE_CHECKING:
    from healthdatalayer.models.catalog.catalog import Catalog


class CatalogEntry(SQLModel, table=True):
    __tablename__ = "catalog_entry"

    catalog_entry_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)

    catalog_id: uuid.UUID = Field(
        foreign_key="catalog.catalog_id",
        index=True,
        nullable=False
    )

    parent_id: Optional[uuid.UUID] = Field(
        default=None,
        foreign_key="catalog_entry.catalog_entry_id",
        index=True
    )

    key: str = Field(index=True, max_length=100)
    label: str = Field(max_length=150)
    input_type: Optional[str] = Field(default=None, max_length=50)  

    display_order: Optional[int] = Field(default=None)

    is_active: bool = Field(default=True)

    
    catalog: Optional["Catalog"] = Relationship(back_populates="entries")

    parent: Optional["CatalogEntry"] = Relationship(
        sa_relationship_kwargs={"remote_side": "CatalogEntry.catalog_entry_id"},
        back_populates="children"
    )

    children: List["CatalogEntry"] = Relationship(back_populates="parent")