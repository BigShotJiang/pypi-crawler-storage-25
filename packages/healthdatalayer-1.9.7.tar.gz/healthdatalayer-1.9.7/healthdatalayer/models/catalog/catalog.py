import uuid
from typing import List, Optional, TYPE_CHECKING

from sqlmodel import SQLModel, Field, Relationship

if TYPE_CHECKING:
    from healthdatalayer.models.catalog.catalog_entry import CatalogEntry

class Catalog(SQLModel, table=True):
    __tablename__ = "catalog"

    catalog_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)

    key: str = Field(index=True, unique=True, max_length=100)
    name: str = Field(max_length=150)
    description: Optional[str] = Field(default=None, max_length=500)

    is_active: bool = Field(default=True)

    entries: List["CatalogEntry"] = Relationship(back_populates="catalog")