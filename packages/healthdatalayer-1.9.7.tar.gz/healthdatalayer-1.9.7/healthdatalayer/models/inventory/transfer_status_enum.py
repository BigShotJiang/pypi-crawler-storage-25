from enum import Enum

class TransferStatusEnum(str, Enum):
    SOLICITADO = "SOLICITADO"
    APROBADO   = "APROBADO"
    DESPACHADO = "DESPACHADO"
    RECIBIDO   = "RECIBIDO"
    RECHAZADO  = "RECHAZADO"
    CANCELADO  = "CANCELADO"