import uuid
from datetime import datetime
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship

if TYPE_CHECKING:
    from healthdatalayer.models.inventory.category import Category
    from healthdatalayer.models.inventory.stock_branch import StockBranch
    from healthdatalayer.models.inventory.lot import Lot
    from healthdatalayer.models.inventory.transaction import Transaction
    from healthdatalayer.models.inventory.transfer_detail import TransferDetail
    from healthdatalayer.models.inventory.alert import Alert
    from healthdatalayer.models.inventory.purchase_order_detail import PurchaseOrderDetail

class Supply(SQLModel, table=True):
    __tablename__ = "supply"
    
    supply_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    code: str
    name: str
    description: Optional[str] = None
    unit_measurement: str
    requires_cooling: bool = Field(default=False)
    days_until_expiration: Optional[int] = Field(default=90)
    is_active: bool = Field(default=True)
    category_id: Optional[uuid.UUID] = Field(default=None, foreign_key="category.category_id")
    created_at: Optional[datetime] = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = Field(default=None)

    category: Optional["Category"] = Relationship(back_populates="supplies")
    
    stock_branches: List["StockBranch"] = Relationship(back_populates="supply")
    
    lots: List["Lot"] = Relationship(back_populates="supply")
    
    transactions: List["Transaction"] = Relationship(back_populates="supply")
    
    transfer_details: List["TransferDetail"] = Relationship(back_populates="supply")
    
    purchase_order_details: List["PurchaseOrderDetail"] = Relationship(back_populates="supply")
    
    alerts: List["Alert"] = Relationship(back_populates="supply")