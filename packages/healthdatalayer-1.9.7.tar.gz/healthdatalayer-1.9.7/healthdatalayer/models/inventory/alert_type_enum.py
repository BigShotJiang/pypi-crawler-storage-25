from enum import Enum

class AlertTypeEnum(str, Enum):
    STOCK_MINIMO   = "STOCK_MINIMO"
    STOCK_MAXIMO   = "STOCK_MAXIMO"
    PROXIMO_VENCER = "PROXIMO_VENCER"
    LOTE_VENCIDO   = "LOTE_VENCIDO"
    REORDEN        = "REORDEN"