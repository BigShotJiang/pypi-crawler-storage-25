import uuid
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship

if TYPE_CHECKING:
    from healthdatalayer.models.inventory.supply import Supply


class Category(SQLModel, table = True):
    __tablename__ = "category"

    category_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    name: str = Field(max_length=255, nullable=False)
    description: Optional[str] = Field(default=None)
    parent_category_id: Optional[uuid.UUID] = Field(default=None, foreign_key="category.category_id")
    is_active: bool = Field(default=True)

    parent_category: Optional["Category"] = Relationship(
        sa_relationship_kwargs={"remote_side": "Category.category_id"}, back_populates="subcategories"
    )
    subcategories: List["Category"] = Relationship( back_populates="parent_category")
    supplies: List["Supply"] = Relationship(back_populates="category")