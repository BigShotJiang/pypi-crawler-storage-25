import uuid
from datetime import datetime
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship
from sqlalchemy import Column, Enum as SqlEnum



if TYPE_CHECKING:
    from healthdatalayer.models.inventory.transfer import Transfer
    from healthdatalayer.models.inventory.lot import Lot                   
    from healthdatalayer.models.inventory.supply import Supply                   

class TransferDetail(SQLModel, table=True):
    __tablename__ = "transfer_detail"

    transfer_detail_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    transfer_id: uuid.UUID = Field(foreign_key="transfer.transfer_id", index=True, nullable=False)
    supply_id: uuid.UUID = Field(foreign_key="supply.supply_id", index=True, nullable=False)
    lot_id: Optional[uuid.UUID] = Field(foreign_key="lot.lot_id", index=True, nullable=True)
    quantity_requested: int = Field(nullable=False)
    quantity_delivered: Optional[int] = Field(default=None)
    quantity_received: Optional[int] = Field(default=None)
    created_at: Optional[datetime] = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = Field(default=None)

    transfer: Optional["Transfer"] = Relationship(back_populates="details")
    lot: Optional["Lot"] = Relationship(back_populates="transfer_details")
    supply: Optional["Supply"] = Relationship(back_populates="transfer_details")
    
    @property
    def loss_difference(self) -> int | None:
        """Detect losses or discrepancies in transit."""
        if self.quantity_delivered is None or self.quantity_received is None:
            return None
        return self.quantity_delivered - self.quantity_received
    
    @property
    def dispatch_difference(self) -> int | None:
        """Detect between request and delivery."""
        if self.quantity_requested is None or self.quantity_delivered is None:
            return None
        return self.quantity_requested - self.quantity_delivered