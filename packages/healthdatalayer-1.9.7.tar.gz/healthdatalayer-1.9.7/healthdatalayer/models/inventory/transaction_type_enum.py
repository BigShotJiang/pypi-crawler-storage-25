from enum import Enum

class TransactionType(str, Enum):
    ENTRADA           = "ENTRADA"
    SALIDA            = "SALIDA"
    AJUSTE_POSITIVO   = "AJUSTE_POSITIVO"
    AJUSTE_NEGATIVO   = "AJUSTE_NEGATIVO"
    TRASPASO_SALIDA   = "TRASPASO_SALIDA"
    TRASPASO_ENTRADA  = "TRASPASO_ENTRADA"
    DEVOLUCION        = "DEVOLUCION"
    MERMA             = "MERMA"