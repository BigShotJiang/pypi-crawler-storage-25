from datetime import datetime
import uuid
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship
from sqlalchemy import Column, Enum as SqlEnum
from healthdatalayer.models.inventory.alert_type_enum import AlertTypeEnum
from healthdatalayer.models.bridge_area_floor_branch.branch import Branch

if TYPE_CHECKING:
    from healthdatalayer.models.inventory.supply import Supply

class Alert(SQLModel, table=True):
    __tablename__ = "alert"

    alert_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    branch_id: uuid.UUID = Field(foreign_key="branch.branch_id", index=True, nullable=False)
    supply_id: uuid.UUID = Field(foreign_key="supply.supply_id", index=True, nullable=False)
    type: AlertTypeEnum = Field(sa_column=Column(SqlEnum(AlertTypeEnum, native_enum=False), nullable=False))
    message: str = Field(max_length=300, nullable=False)
    is_read: bool = Field(default=False)
    created_at: Optional[datetime] = Field(default_factory=datetime.now)
    is_active: bool = Field(default=True)
    
    branch: Optional["Branch"] = Relationship(back_populates="alerts")
    supply: Optional["Supply"] = Relationship(back_populates="alerts")