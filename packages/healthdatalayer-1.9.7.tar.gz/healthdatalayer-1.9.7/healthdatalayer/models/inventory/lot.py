import uuid
from datetime import datetime
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship
from sqlalchemy import Column, Enum as SqlEnum, Transaction
from healthdatalayer.models.inventory.lot_status_enum import StatusLotEnum


if TYPE_CHECKING:
    from healthdatalayer.models.inventory.supply import Supply
    from healthdatalayer.models.inventory.transfer_detail import TransferDetail

class Lot(SQLModel, table=True):
    __tablename__ = "lot"

    lot_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    supply_id: uuid.UUID = Field(foreign_key="supply.supply_id", index=True, nullable=False)
    lot_number: str = Field(max_length=100, nullable=False)
    expiration_date: Optional[datetime] = Field(default=None)
    is_active: bool = Field(default=True)
    receipt_date: Optional[datetime] = Field(default=None)
    initial_quantity: Optional[int] = Field(default=None)
    current_quantity: Optional[int] = Field(default=None)
    created_at: Optional[datetime] = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = Field(default=None)
    status_lot: StatusLotEnum = Field(sa_column=Column(SqlEnum(StatusLotEnum, native_enum=False), nullable=False))
    
    supply: Optional["Supply"] = Relationship(back_populates="lots")
    
    transfer_details: List["TransferDetail"] = Relationship(back_populates="lot")
    transactions: List["Transaction"] = Relationship(back_populates="lot")
    
    @property
    def has_expired(self) -> bool:
        return self.expiration_date is not None and self.expiration_date < datetime.today()
    
    @property
    def days_until_expiration(self) -> Optional[int]:
        if self.expiration_date is None:
            return None
        delta = self.expiration_date - datetime.today()
        return delta.days