from typing import Optional, List
from uuid import UUID
from sqlmodel import select, and_
from sqlalchemy.orm import selectinload, joinedload

from healthdatalayer.models.inventory.stock_branch import StockBranch
from healthdatalayer.repositories.base_repository import BaseRepository


class StockBranchRepository(BaseRepository[StockBranch]):
    def __init__(self, tenant: str):
        super().__init__(tenant, StockBranch)

    def _detail_options(self):
        return (
            joinedload(StockBranch.supply),
            joinedload(StockBranch.branch),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def get_by_id_command(
        self, stock_branch_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[StockBranch]:
        with self._get_session() as session:
            statement = select(StockBranch).where(StockBranch.stock_branch_id == stock_branch_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_by_branch_and_supply_command(
        self, branch_id: UUID, supply_id: UUID, load_details: bool = False
    ) -> Optional[StockBranch]:
        """Get stock for a specific branch and supply combination."""
        with self._get_session() as session:
            statement = select(StockBranch).where(
                and_(
                    StockBranch.branch_id == branch_id,
                    StockBranch.supply_id == supply_id
                )
            )
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_or_create_command(
        self, branch_id: UUID, supply_id: UUID, 
        min_stock: int = 0, max_stock: Optional[int] = None
    ) -> StockBranch:
        """Get existing stock or create new if it doesn't exist."""
        with self._get_session() as session:
            statement = select(StockBranch).where(
                and_(
                    StockBranch.branch_id == branch_id,
                    StockBranch.supply_id == supply_id
                )
            )
            existing = session.exec(statement).first()
            
            if existing:
                return existing
            
            new_stock = StockBranch(
                branch_id=branch_id,
                supply_id=supply_id,
                min_stock=min_stock,
                max_stock=max_stock,
                current_quantity=0
            )
            session.add(new_stock)
            session.commit()
            session.refresh(new_stock)
            return new_stock

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[StockBranch]:
        with self._get_session() as session:
            statement = select(StockBranch)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_branch_command(
        self, branch_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[StockBranch]:
        """Get all stock records for a specific branch."""
        with self._get_session() as session:
            statement = select(StockBranch).where(StockBranch.branch_id == branch_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_supply_command(
        self, supply_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[StockBranch]:
        """Get all stock records for a specific supply across all branches."""
        with self._get_session() as session:
            statement = select(StockBranch).where(StockBranch.supply_id == supply_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_low_stock_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[StockBranch]:
        """Get all stock records where current_quantity <= min_stock."""
        with self._get_session() as session:
            statement = select(StockBranch).where(
                StockBranch.current_quantity <= StockBranch.min_stock,
                StockBranch.is_active == True
            )
            if branch_id:
                statement = statement.where(StockBranch.branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_reorder_needed_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[StockBranch]:
        """Get all stock records where current_quantity <= reorder point (early warning)."""
        with self._get_session() as session:
            statement = select(StockBranch).where(
                StockBranch.current_quantity <= StockBranch.min_stock,
                StockBranch.is_active == True
            )
            if branch_id:
                statement = statement.where(StockBranch.branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_overstock_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[StockBranch]:
        """Get all stock records where current_quantity >= max_stock."""
        with self._get_session() as session:
            statement = select(StockBranch).where(
                StockBranch.current_quantity >= StockBranch.max_stock,
                StockBranch.is_active == True,
                StockBranch.max_stock.isnot(None)
            )
            if branch_id:
                statement = statement.where(StockBranch.branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def update_quantity_command(
        self, stock_branch_id: UUID, new_quantity: int
    ) -> StockBranch:
        """Update the current quantity of a stock record."""
        with self._get_session() as session:
            stock = session.get(StockBranch, stock_branch_id)
            if not stock:
                raise ValueError(f"StockBranch with id {stock_branch_id} does not exist")
            
            stock.current_quantity = new_quantity
            session.add(stock)
            session.commit()
            session.refresh(stock)
            return stock

    def adjust_quantity_command(
        self, stock_branch_id: UUID, adjustment: int
    ) -> StockBranch:
        """Adjust the current quantity by adding (positive) or subtracting (negative)."""
        with self._get_session() as session:
            stock = session.get(StockBranch, stock_branch_id)
            if not stock:
                raise ValueError(f"StockBranch with id {stock_branch_id} does not exist")
            
            new_quantity = stock.current_quantity + adjustment
            if new_quantity < 0:
                raise ValueError("Stock cannot go negative")
            
            stock.current_quantity = new_quantity
            session.add(stock)
            session.commit()
            session.refresh(stock)
            return stock
