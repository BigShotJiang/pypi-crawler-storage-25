from typing import Optional, List
from uuid import UUID
from sqlmodel import select, and_
from sqlalchemy.orm import selectinload, joinedload

from healthdatalayer.models.inventory.transfer_detail import TransferDetail
from healthdatalayer.repositories.base_repository import BaseRepository


class TransferDetailRepository(BaseRepository[TransferDetail]):
    def __init__(self, tenant: str):
        super().__init__(tenant, TransferDetail)

    def _detail_options(self):
        return (
            joinedload(TransferDetail.transfer),
            joinedload(TransferDetail.supply),
            joinedload(TransferDetail.lot),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def get_by_id_command(
        self, transfer_detail_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[TransferDetail]:
        with self._get_session() as session:
            statement = select(TransferDetail).where(TransferDetail.transfer_detail_id == transfer_detail_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[TransferDetail]:
        with self._get_session() as session:
            statement = select(TransferDetail)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_transfer_command(
        self, transfer_id: UUID, load_details: bool = False
    ) -> List[TransferDetail]:
        """Get all details for a specific transfer."""
        with self._get_session() as session:
            statement = select(TransferDetail).where(
                TransferDetail.transfer_id == transfer_id
            )
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_supply_command(
        self, supply_id: UUID, load_details: bool = False
    ) -> List[TransferDetail]:
        """Get all transfer details for a specific supply."""
        with self._get_session() as session:
            statement = select(TransferDetail).where(
                TransferDetail.supply_id == supply_id
            )
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_lot_command(
        self, lot_id: UUID, load_details: bool = False
    ) -> List[TransferDetail]:
        """Get all transfer details for a specific lot."""
        with self._get_session() as session:
            statement = select(TransferDetail).where(
                TransferDetail.lot_id == lot_id
            )
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def update_dispatched_quantity_command(
        self, transfer_detail_id: UUID, dispatched_qty: int
    ) -> TransferDetail:
        """Update the quantity dispatched (set when transfer is dispatched)."""
        with self._get_session() as session:
            detail = session.get(TransferDetail, transfer_detail_id)
            if not detail:
                raise ValueError(f"TransferDetail with id {transfer_detail_id} does not exist")
            
            detail.quantity_delivered = dispatched_qty
            session.add(detail)
            session.commit()
            session.refresh(detail)
            return detail

    def update_received_quantity_command(
        self, transfer_detail_id: UUID, received_qty: int
    ) -> TransferDetail:
        """Update the quantity received (set when transfer is received)."""
        with self._get_session() as session:
            detail = session.get(TransferDetail, transfer_detail_id)
            if not detail:
                raise ValueError(f"TransferDetail with id {transfer_detail_id} does not exist")
            
            detail.quantity_received = received_qty
            session.add(detail)
            session.commit()
            session.refresh(detail)
            return detail
