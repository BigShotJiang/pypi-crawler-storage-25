from typing import Optional, List
from uuid import UUID
from sqlmodel import select, or_
from sqlalchemy.orm import selectinload, joinedload

from healthdatalayer.models.inventory.supply import Supply
from healthdatalayer.models.inventory.category import Category
from healthdatalayer.repositories.base_repository import BaseRepository


class SupplyRepository(BaseRepository[Supply]):
    def __init__(self, tenant: str):
        super().__init__(tenant, Supply)

    def _detail_options(self):
        return (
            joinedload(Supply.category),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def get_by_id_command(
        self, supply_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[Supply]:
        with self._get_session() as session:
            statement = select(Supply).where(Supply.supply_id == supply_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_by_code_command(self, code: str, active_only: bool = True) -> Optional[Supply]:
        with self._get_session() as session:
            statement = select(Supply).where(Supply.code == code)
            statement = self._apply_active_filter(statement, active_only)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[Supply]:
        with self._get_session() as session:
            statement = select(Supply)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_category_command(
        self, category_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[Supply]:
        """Get all supplies belonging to a specific category."""
        with self._get_session() as session:
            statement = select(Supply).where(Supply.category_id == category_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_category_tree_command(
        self, root_category_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[Supply]:
        """Get all supplies belonging to a category and all its subcategories."""
        with self._get_session() as session:
            # Get all category IDs in the tree (including the root)
            category_ids = [root_category_id]
            
            # Recursively get subcategory IDs
            def get_subcategory_ids(parent_id: UUID):
                statement = select(Category.category_id).where(
                    Category.parent_category_id == parent_id,
                    Category.is_active == True
                )
                subcategories = session.exec(statement).all()
                for sub_id in subcategories:
                    category_ids.append(sub_id)
                    get_subcategory_ids(sub_id)
            
            get_subcategory_ids(root_category_id)
            
            statement = select(Supply).where(Supply.category_id.in_(category_ids))
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def search_command(
        self, search_term: str, active_only: bool = True, load_details: bool = False
    ) -> List[Supply]:
        """Search supplies by code, name, or description."""
        with self._get_session() as session:
            statement = select(Supply).where(
                or_(
                    Supply.code.ilike(f"%{search_term}%"),
                    Supply.name.ilike(f"%{search_term}%"),
                    Supply.description.ilike(f"%{search_term}%")
                )
            )
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_requires_cooling_command(
        self, requires_cooling: bool = True, active_only: bool = True, load_details: bool = False
    ) -> List[Supply]:
        """Get supplies that require refrigeration."""
        with self._get_session() as session:
            statement = select(Supply).where(Supply.requires_cooling == requires_cooling)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()
