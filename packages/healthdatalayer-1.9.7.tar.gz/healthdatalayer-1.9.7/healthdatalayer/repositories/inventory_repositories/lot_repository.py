from typing import Optional, List
from uuid import UUID
from datetime import datetime, timedelta
from sqlmodel import select, and_
from sqlalchemy.orm import selectinload, joinedload

from healthdatalayer.models.inventory.lot import Lot
from healthdatalayer.models.inventory.lot_status_enum import StatusLotEnum
from healthdatalayer.repositories.base_repository import BaseRepository


class LotRepository(BaseRepository[Lot]):
    def __init__(self, tenant: str):
        super().__init__(tenant, Lot)

    def _detail_options(self):
        return (
            joinedload(Lot.supply),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def get_by_id_command(
        self, lot_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[Lot]:
        with self._get_session() as session:
            statement = select(Lot).where(Lot.lot_id == lot_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_by_lot_number_command(
        self, lot_number: str, supply_id: UUID, load_details: bool = False
    ) -> Optional[Lot]:
        """Get a lot by its lot number for a specific supply."""
        with self._get_session() as session:
            statement = select(Lot).where(
                and_(
                    Lot.lot_number == lot_number,
                    Lot.supply_id == supply_id
                )
            )
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[Lot]:
        with self._get_session() as session:
            statement = select(Lot)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_supply_command(
        self, supply_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[Lot]:
        """Get all lots for a specific supply."""
        with self._get_session() as session:
            statement = select(Lot).where(Lot.supply_id == supply_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_supply_and_branch_command(
        self, supply_id: UUID, branch_id: UUID, active_only: bool = True, 
        load_details: bool = False
    ) -> List[Lot]:
        """Get all lots for a specific supply at a specific branch."""
        with self._get_session() as session:
            statement = select(Lot).where(
                and_(
                    Lot.supply_id == supply_id,
                    Lot.branch_id == branch_id
                )
            )
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_active_by_supply_command(
        self, supply_id: UUID, load_details: bool = False
    ) -> List[Lot]:
        """Get all active (non-depleted) lots for a supply."""
        with self._get_session() as session:
            statement = select(Lot).where(
                and_(
                    Lot.supply_id == supply_id,
                    Lot.status_lot == StatusLotEnum.ACTIVO,
                    Lot.is_active == True
                )
            )
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_expired_command(
        self, supply_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[Lot]:
        """Get all expired lots."""
        with self._get_session() as session:
            today = datetime.today()
            statement = select(Lot).where(
                and_(
                    Lot.expiration_date < today,
                    Lot.status_lot != StatusLotEnum.VENCIDO,
                    Lot.is_active == True
                )
            )
            if supply_id:
                statement = statement.where(Lot.supply_id == supply_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_expiring_soon_command(
        self, days: int, supply_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[Lot]:
        """Get lots that will expire within the specified days."""
        with self._get_session() as session:
            today = datetime.today()
            future_date = today + timedelta(days=days)
            
            statement = select(Lot).where(
                and_(
                    Lot.expiration_date >= today,
                    Lot.expiration_date <= future_date,
                    Lot.status_lot == StatusLotEnum.ACTIVO,
                    Lot.is_active == True
                )
            )
            if supply_id:
                statement = statement.where(Lot.supply_id == supply_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_quarantined_command(
        self, supply_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[Lot]:
        """Get all quarantined lots."""
        with self._get_session() as session:
            statement = select(Lot).where(
                and_(
                    Lot.status_lot == StatusLotEnum.CUARENTENADO,
                    Lot.is_active == True
                )
            )
            if supply_id:
                statement = statement.where(Lot.supply_id == supply_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_depleted_command(
        self, supply_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[Lot]:
        """Get all depleted (quantity = 0) lots."""
        with self._get_session() as session:
            statement = select(Lot).where(
                and_(
                    Lot.current_quantity == 0,
                    Lot.is_active == True
                )
            )
            if supply_id:
                statement = statement.where(Lot.supply_id == supply_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def update_status_command(self, lot_id: UUID, status: StatusLotEnum) -> Lot:
        """Update the status of a lot."""
        with self._get_session() as session:
            lot = session.get(Lot, lot_id)
            if not lot:
                raise ValueError(f"Lot with id {lot_id} does not exist")
            
            lot.status_lot = status
            session.add(lot)
            session.commit()
            session.refresh(lot)
            return lot

    def update_quantity_command(self, lot_id: UUID, new_quantity: int) -> Lot:
        """Update the current quantity of a lot."""
        with self._get_session() as session:
            lot = session.get(Lot, lot_id)
            if not lot:
                raise ValueError(f"Lot with id {lot_id} does not exist")
            
            lot.current_quantity = new_quantity
            
            # Auto-update status based on quantity
            if new_quantity == 0:
                lot.status_lot = StatusLotEnum.AGOTADO
            
            session.add(lot)
            session.commit()
            session.refresh(lot)
            return lot

    def adjust_quantity_command(self, lot_id: UUID, adjustment: int) -> Lot:
        """Adjust the current quantity by adding (positive) or subtracting (negative)."""
        with self._get_session() as session:
            lot = session.get(Lot, lot_id)
            if not lot:
                raise ValueError(f"Lot with id {lot_id} does not exist")
            
            new_quantity = (lot.current_quantity or 0) + adjustment
            if new_quantity < 0:
                raise ValueError("Lot quantity cannot go negative")
            
            lot.current_quantity = new_quantity
            
            # Auto-update status based on quantity
            if new_quantity == 0:
                lot.status_lot = StatusLotEnum.AGOTADO
            
            session.add(lot)
            session.commit()
            session.refresh(lot)
            return lot

    def check_and_update_expired_command(self) -> List[Lot]:
        """Check all active lots and update status for expired ones. Returns updated lots."""
        with self._get_session() as session:
            today = datetime.today()
            
            # Find lots that have expired but are not marked as expired
            statement = select(Lot).where(
                and_(
                    Lot.expiration_date < today,
                    Lot.status_lot == StatusLotEnum.ACTIVO,
                    Lot.is_active == True
                )
            )
            expired_lots = session.exec(statement).all()
            
            for lot in expired_lots:
                lot.status_lot = StatusLotEnum.VENCIDO
                session.add(lot)
            
            session.commit()
            for lot in expired_lots:
                session.refresh(lot)
            
            return expired_lots
