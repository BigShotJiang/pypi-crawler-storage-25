from typing import Optional, List
from uuid import UUID
from datetime import datetime
from sqlmodel import select, and_
from sqlalchemy.orm import selectinload, joinedload

from healthdatalayer.models.inventory.transaction import Transaction
from healthdatalayer.models.inventory.transaction_type_enum import TransactionType
from healthdatalayer.repositories.base_repository import BaseRepository


class TransactionRepository(BaseRepository[Transaction]):
    def __init__(self, tenant: str):
        super().__init__(tenant, Transaction)

    def _detail_options(self):
        return (
            joinedload(Transaction.supply),
            joinedload(Transaction.branch),
            joinedload(Transaction.lot),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def get_by_id_command(
        self, transaction_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[Transaction]:
        with self._get_session() as session:
            statement = select(Transaction).where(Transaction.transaction_id == transaction_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False, limit: Optional[int] = None
    ) -> List[Transaction]:
        with self._get_session() as session:
            statement = select(Transaction)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            if limit:
                statement = statement.limit(limit)
            return session.exec(statement).all()

    def get_by_supply_command(
        self, supply_id: UUID, load_details: bool = False, limit: Optional[int] = None
    ) -> List[Transaction]:
        """Get all transactions for a specific supply."""
        with self._get_session() as session:
            statement = select(Transaction).where(Transaction.supply_id == supply_id)
            statement = self._apply_load_options(statement, load_details)
            if limit:
                statement = statement.limit(limit)
            return session.exec(statement).all()

    def get_by_branch_command(
        self, branch_id: UUID, load_details: bool = False, limit: Optional[int] = None
    ) -> List[Transaction]:
        """Get all transactions for a specific branch."""
        with self._get_session() as session:
            statement = select(Transaction).where(Transaction.branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            if limit:
                statement = statement.limit(limit)
            return session.exec(statement).all()

    def get_by_supply_and_branch_command(
        self, supply_id: UUID, branch_id: UUID, load_details: bool = False,
        limit: Optional[int] = None
    ) -> List[Transaction]:
        """Get all transactions for a specific supply at a specific branch."""
        with self._get_session() as session:
            statement = select(Transaction).where(
                and_(
                    Transaction.supply_id == supply_id,
                    Transaction.branch_id == branch_id
                )
            )
            statement = self._apply_load_options(statement, load_details)
            if limit:
                statement = statement.limit(limit)
            return session.exec(statement).all()

    def get_by_lot_command(
        self, lot_id: UUID, load_details: bool = False, limit: Optional[int] = None
    ) -> List[Transaction]:
        """Get all transactions for a specific lot."""
        with self._get_session() as session:
            statement = select(Transaction).where(Transaction.lot_id == lot_id)
            statement = self._apply_load_options(statement, load_details)
            if limit:
                statement = statement.limit(limit)
            return session.exec(statement).all()

    def get_by_type_command(
        self, transaction_type: TransactionType, load_details: bool = False,
        limit: Optional[int] = None
    ) -> List[Transaction]:
        """Get all transactions of a specific type."""
        with self._get_session() as session:
            statement = select(Transaction).where(
                Transaction.transaction_type == transaction_type
            )
            statement = self._apply_load_options(statement, load_details)
            if limit:
                statement = statement.limit(limit)
            return session.exec(statement).all()

    def get_by_reference_command(
        self, reference_id: UUID, reference_type: str, load_details: bool = False
    ) -> List[Transaction]:
        """Get all transactions linked to a specific reference (e.g., transfer, purchase order)."""
        with self._get_session() as session:
            statement = select(Transaction).where(
                and_(
                    Transaction.reference_id == reference_id,
                    Transaction.reference_type == reference_type
                )
            )
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_date_range_command(
        self, start_date: datetime, end_date: datetime,
        supply_id: Optional[UUID] = None, branch_id: Optional[UUID] = None,
        load_details: bool = False
    ) -> List[Transaction]:
        """Get transactions within a date range, optionally filtered by supply and/or branch."""
        with self._get_session() as session:
            statement = select(Transaction).where(
                and_(
                    Transaction.date >= start_date,
                    Transaction.date <= end_date
                )
            )
            if supply_id:
                statement = statement.where(Transaction.supply_id == supply_id)
            if branch_id:
                statement = statement.where(Transaction.branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_latest_by_supply_and_branch_command(
        self, supply_id: UUID, branch_id: UUID, load_details: bool = False
    ) -> Optional[Transaction]:
        """Get the most recent transaction for a supply at a branch."""
        with self._get_session() as session:
            statement = (
                select(Transaction)
                .where(
                    and_(
                        Transaction.supply_id == supply_id,
                        Transaction.branch_id == branch_id
                    )
                )
                .order_by(Transaction.date.desc())
                .limit(1)
            )
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_entry_transactions_command(
        self, supply_id: UUID, branch_id: UUID, load_details: bool = False
    ) -> List[Transaction]:
        """Get all entry transactions (ENTRADA) for a supply at a branch."""
        return self.get_by_type_and_supply_branch_command(
            [TransactionType.ENTRADA], supply_id, branch_id, load_details
        )

    def get_exit_transactions_command(
        self, supply_id: UUID, branch_id: UUID, load_details: bool = False
    ) -> List[Transaction]:
        """Get all exit transactions (SALIDA) for a supply at a branch."""
        return self.get_by_type_and_supply_branch_command(
            [TransactionType.SALIDA, TransactionType.MERMA, TransactionType.DEVOLUCION],
            supply_id, branch_id, load_details
        )

    def get_by_type_and_supply_branch_command(
        self, transaction_types: List[TransactionType], supply_id: UUID, 
        branch_id: UUID, load_details: bool = False
    ) -> List[Transaction]:
        """Get transactions by types for a specific supply at a branch."""
        with self._get_session() as session:
            statement = select(Transaction).where(
                and_(
                    Transaction.transaction_type.in_(transaction_types),
                    Transaction.supply_id == supply_id,
                    Transaction.branch_id == branch_id
                )
            )
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()
