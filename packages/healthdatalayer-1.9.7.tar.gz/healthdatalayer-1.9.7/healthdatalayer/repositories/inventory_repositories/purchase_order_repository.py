from typing import Optional, List
from uuid import UUID
from datetime import datetime
from sqlmodel import select, and_
from sqlalchemy.orm import selectinload, joinedload

from healthdatalayer.models.inventory.purchase_order import PurchaseOrder
from healthdatalayer.models.inventory.purchase_order_status_enum import PurchaseOrderStatus
from healthdatalayer.repositories.base_repository import BaseRepository


class PurchaseOrderRepository(BaseRepository[PurchaseOrder]):
    def __init__(self, tenant: str):
        super().__init__(tenant, PurchaseOrder)

    def _detail_options(self):
        return (
            joinedload(PurchaseOrder.branch),
            selectinload(PurchaseOrder.details),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def get_by_id_command(
        self, purchase_order_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[PurchaseOrder]:
        with self._get_session() as session:
            statement = select(PurchaseOrder).where(PurchaseOrder.purchase_order_id == purchase_order_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_by_order_number_command(
        self, order_number: str, load_details: bool = False
    ) -> Optional[PurchaseOrder]:
        """Get a purchase order by its unique order number."""
        with self._get_session() as session:
            statement = select(PurchaseOrder).where(
                PurchaseOrder.supplier_name.ilike(f"%{order_number}%")
            )
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[PurchaseOrder]:
        with self._get_session() as session:
            statement = select(PurchaseOrder)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_status_command(
        self, status: PurchaseOrderStatus, load_details: bool = False
    ) -> List[PurchaseOrder]:
        """Get all purchase orders with a specific status."""
        with self._get_session() as session:
            statement = select(PurchaseOrder).where(PurchaseOrder.status == status)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_branch_command(
        self, branch_id: UUID, load_details: bool = False
    ) -> List[PurchaseOrder]:
        """Get all purchase orders for a specific branch."""
        with self._get_session() as session:
            statement = select(PurchaseOrder).where(
                PurchaseOrder.branch_id == branch_id
            )
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_date_range_command(
        self, start_date: datetime, end_date: datetime,
        branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[PurchaseOrder]:
        """Get purchase orders within a date range."""
        with self._get_session() as session:
            statement = select(PurchaseOrder).where(
                and_(
                    PurchaseOrder.order_date >= start_date,
                    PurchaseOrder.order_date <= end_date
                )
            )
            if branch_id:
                statement = statement.where(PurchaseOrder.branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_draft_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[PurchaseOrder]:
        """Get all draft purchase orders."""
        with self._get_session() as session:
            statement = select(PurchaseOrder).where(
                PurchaseOrder.status == PurchaseOrderStatus.BORRADOR
            )
            if branch_id:
                statement = statement.where(PurchaseOrder.branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_pending_reception_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[PurchaseOrder]:
        """Get all purchase orders pending reception (SENT or PARTIAL)."""
        with self._get_session() as session:
            statement = select(PurchaseOrder).where(
                PurchaseOrder.status.in_([
                    PurchaseOrderStatus.ENVIADA,
                    PurchaseOrderStatus.PARCIAL
                ])
            )
            if branch_id:
                statement = statement.where(PurchaseOrder.branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def update_status_command(
        self, purchase_order_id: UUID, new_status: PurchaseOrderStatus
    ) -> PurchaseOrder:
        """Update the status of a purchase order."""
        with self._get_session() as session:
            purchase_order = session.get(PurchaseOrder, purchase_order_id)
            if not purchase_order:
                raise ValueError(f"PurchaseOrder with id {purchase_order_id} does not exist")
            
            purchase_order.status = new_status
            session.add(purchase_order)
            session.commit()
            session.refresh(purchase_order)
            return purchase_order

    def send_command(self, purchase_order_id: UUID) -> PurchaseOrder:
        """Send a purchase order (DRAFT -> SENT)."""
        return self.update_status_command(purchase_order_id, PurchaseOrderStatus.ENVIADA)

    def cancel_command(self, purchase_order_id: UUID) -> PurchaseOrder:
        """Cancel a purchase order."""
        return self.update_status_command(purchase_order_id, PurchaseOrderStatus.CANCELADA)
