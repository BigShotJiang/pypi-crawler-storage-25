from typing import List, Optional
from uuid import UUID
from sqlmodel import select
from sqlalchemy.orm import selectinload
from healthdatalayer.models import CatalogEntry
from healthdatalayer.repositories.base_repository import BaseRepository

class CatalogEntryRepository(BaseRepository[CatalogEntry]):
    def __init__(self, tenant: str):
        super().__init__(tenant, CatalogEntry)

    def _detail_options(self):
        return [
            selectinload(CatalogEntry.children)
        ]

    def _apply_load_options(self, statement, load_details: bool):
        options = []
        if load_details:
            options.extend(self._detail_options())
        if options:
            return statement.options(*options)
        return statement

    def get_by_id_command(self, catalog_entry_id: UUID, load_details: bool = False, active_only: bool = True) -> Optional[CatalogEntry]:
        with self._get_session() as session:
            statement = select(CatalogEntry).where(CatalogEntry.catalog_entry_id == catalog_entry_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def create_command(self, entity: CatalogEntry) -> Optional[CatalogEntry]:
        with self._get_session() as session:
            session.add(entity)
            session.commit()
            catalog_entry_id = entity.catalog_entry_id

        return self.get_by_id_command(catalog_entry_id, load_details=True)

    def list_by_catalog_id_command(self, catalog_id: UUID, active_only: bool = True, load_details: bool = False) -> List[CatalogEntry]:
        with self._get_session() as session:
            statement = select(CatalogEntry).where(CatalogEntry.catalog_id == catalog_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()