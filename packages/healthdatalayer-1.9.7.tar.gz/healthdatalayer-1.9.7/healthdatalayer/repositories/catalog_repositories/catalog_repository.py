from typing import List, Optional
from uuid import UUID

from sqlmodel import select

from sqlalchemy.orm import joinedload, selectinload

from healthdatalayer.models import Catalog, CatalogEntry
from healthdatalayer.repositories.base_repository import BaseRepository


class CatalogRepository(BaseRepository[Catalog]):
    def __init__(self, tenant: str):
        super().__init__(tenant, Catalog)
    
    def _detail_options(self):
        return [
            selectinload(Catalog.entries).selectinload(CatalogEntry.children)
        ]
    
    def _apply_load_options(self, statement, load_details: bool):
        options = []
        if load_details:
            options.extend(self._detail_options())
        if options:
            return statement.options(*options)
        return statement

    def get_by_id_command(
        self,
        catalog_id: UUID,
        load_details: bool = False,
        active_only: bool = True,
    ) -> Optional[Catalog]:
        with self._get_session() as session:
            statement = select(Catalog).where(Catalog.catalog_id == catalog_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()
        
    def list_all_command(
        self,
        active_only: bool = True,
        load_details: bool = False,
    ) -> List[Catalog]:
        with self._get_session() as session:
            statement = select(Catalog)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()
    
    def delete_command(self, entity_id, soft_delete = True, entries_delete_cascade = True, entries_soft_delete = True) -> bool:
        with self._get_session() as session:
            catalog = session.get(Catalog, entity_id)
            if not catalog:
                return False
            
            if entries_delete_cascade:
                if entries_soft_delete:
                    for entry in catalog.entries:
                        entry.is_active = False
                        session.add(entry)
                else:
                    for entry in catalog.entries:
                        session.delete(entry)

            if soft_delete:
                catalog.is_active = False
                session.add(catalog)
            else:
                session.delete(catalog)

            session.commit()
            return True