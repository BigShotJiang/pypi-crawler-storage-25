"""Pydantic models for RDAP API responses."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import List, Optional

from pydantic import BaseModel, Field

__all__ = [
    "AsnResponse",
    "BulkDomainResponse",
    "BulkDomainResult",
    "BulkDomainSummary",
    "Contact",
    "Dates",
    "DomainResponse",
    "Entities",
    "EntityAutnum",
    "EntityNetwork",
    "EntityResponse",
    "FieldAvailability",
    "IpAddresses",
    "IpResponse",
    "Meta",
    "NameserverResponse",
    "PublicId",
    "Registrar",
    "Remark",
    "TldEntry",
    "TldListMeta",
    "TldListResponse",
    "TldMeta",
    "TldResponse",
    "TldThresholds",
]


class Meta(BaseModel):
    """Metadata about the RDAP lookup."""

    rdap_server: str
    raw_rdap_url: str
    cached: bool
    cache_expires: str
    followed: Optional[bool] = None
    registrar_rdap_server: Optional[str] = None
    follow_error: Optional[str] = None


class Dates(BaseModel):
    """Registration dates."""

    registered: Optional[str] = None
    expires: Optional[str] = None
    updated: Optional[str] = None

    @staticmethod
    def _parse(value: Optional[str]) -> Optional[datetime]:
        if value is None:
            return None
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except (ValueError, TypeError):
            return None

    @property
    def registered_at(self) -> Optional[datetime]:
        """Parse ``registered`` into a timezone-aware :class:`~datetime.datetime`."""
        return self._parse(self.registered)

    @property
    def expires_at(self) -> Optional[datetime]:
        """Parse ``expires`` into a timezone-aware :class:`~datetime.datetime`."""
        return self._parse(self.expires)

    @property
    def updated_at(self) -> Optional[datetime]:
        """Parse ``updated`` into a timezone-aware :class:`~datetime.datetime`."""
        return self._parse(self.updated)

    @property
    def expires_in_days(self) -> Optional[int]:
        """Days until expiration, or ``None`` if no expiry date is available."""
        dt = self.expires_at
        if dt is None:
            return None
        return (dt - datetime.now(timezone.utc)).days


class Registrar(BaseModel):
    """Domain registrar information."""

    name: Optional[str] = None
    iana_id: Optional[str] = None
    abuse_email: Optional[str] = None
    abuse_phone: Optional[str] = None
    url: Optional[str] = None


class Contact(BaseModel):
    """Contact entity information."""

    handle: Optional[str] = None
    name: Optional[str] = None
    organization: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    contact_url: Optional[str] = None
    country_code: Optional[str] = None


class Entities(BaseModel):
    """Contact entities keyed by role."""

    registrant: Optional[Contact] = None
    administrative: Optional[Contact] = None
    technical: Optional[Contact] = None
    billing: Optional[Contact] = None
    abuse: Optional[Contact] = None


class Remark(BaseModel):
    """Remark from the registry."""

    title: Optional[str] = None
    description: str


class DomainResponse(BaseModel):
    """Response from a domain lookup."""

    domain: str
    unicode_name: Optional[str] = None
    handle: Optional[str] = None
    status: List[str] = Field(default_factory=list)
    registrar: Registrar
    dates: Dates
    nameservers: List[str] = Field(default_factory=list)
    dnssec: bool = False
    entities: Entities = Field(default_factory=Entities)
    meta: Meta


class IpAddresses(BaseModel):
    """IP addresses for a nameserver."""

    v4: List[str] = Field(default_factory=list)
    v6: List[str] = Field(default_factory=list)


class IpResponse(BaseModel):
    """Response from an IP address lookup."""

    handle: Optional[str] = None
    name: Optional[str] = None
    type: Optional[str] = None
    start_address: Optional[str] = None
    end_address: Optional[str] = None
    ip_version: Optional[str] = None
    parent_handle: Optional[str] = None
    country: Optional[str] = None
    status: List[str] = Field(default_factory=list)
    dates: Dates
    entities: Entities = Field(default_factory=Entities)
    cidr: List[str] = Field(default_factory=list)
    remarks: List[Remark] = Field(default_factory=list)
    port43: Optional[str] = None
    meta: Meta


class AsnResponse(BaseModel):
    """Response from an ASN lookup."""

    handle: Optional[str] = None
    name: Optional[str] = None
    type: Optional[str] = None
    start_autnum: Optional[int] = None
    end_autnum: Optional[int] = None
    status: List[str] = Field(default_factory=list)
    dates: Dates
    entities: Entities = Field(default_factory=Entities)
    remarks: List[Remark] = Field(default_factory=list)
    port43: Optional[str] = None
    meta: Meta


class NameserverResponse(BaseModel):
    """Response from a nameserver lookup."""

    ldh_name: str
    unicode_name: Optional[str] = None
    handle: Optional[str] = None
    ip_addresses: IpAddresses = Field(default_factory=IpAddresses)
    status: List[str] = Field(default_factory=list)
    dates: Dates
    entities: Entities = Field(default_factory=Entities)
    meta: Meta


class PublicId(BaseModel):
    """Public identifier (e.g. ARIN OrgID, IANA Registrar ID)."""

    type: Optional[str] = None
    identifier: Optional[str] = None


class EntityAutnum(BaseModel):
    """Autonomous system number owned by an entity."""

    handle: Optional[str] = None
    name: Optional[str] = None
    start_autnum: Optional[int] = None
    end_autnum: Optional[int] = None


class EntityNetwork(BaseModel):
    """IP network block owned by an entity."""

    handle: Optional[str] = None
    name: Optional[str] = None
    start_address: Optional[str] = None
    end_address: Optional[str] = None
    ip_version: Optional[str] = None
    cidr: List[str] = Field(default_factory=list)


class BulkDomainResult(BaseModel):
    """A single result within a bulk domain lookup response.

    When ``status`` is ``"success"``, ``data`` contains a full
    :class:`DomainResponse`.  When ``status`` is ``"error"``,
    ``error`` and ``message`` describe the failure.
    """

    domain: str
    status: str
    data: Optional[DomainResponse] = None
    error: Optional[str] = None
    message: Optional[str] = None


class BulkDomainSummary(BaseModel):
    """Summary counts for a bulk domain lookup."""

    total: int
    successful: int
    failed: int


class BulkDomainResponse(BaseModel):
    """Response from a bulk domain lookup."""

    results: List[BulkDomainResult]
    summary: BulkDomainSummary


class FieldAvailability(BaseModel):
    """How often each common domain field is populated in a TLD's RDAP responses.

    Each value is one of ``"always"``, ``"usually"``, ``"sometimes"``, or
    ``"never"``. See :class:`TldThresholds` for the percentage cutoffs.
    """

    registrar: str
    registered_at: str
    expires_at: str
    nameservers: str
    status: str


class TldEntry(BaseModel):
    """A single TLD entry from the ``/tlds`` catalog."""

    tld: str
    supported_since: str
    rdap_server_host: str
    rdap_server_url: str
    field_availability: Optional[FieldAvailability] = None


class TldThresholds(BaseModel):
    """Percentage cutoffs used to pick each availability label."""

    always: float
    usually: float
    sometimes: float


class TldListMeta(BaseModel):
    """Metadata for a TLD list response."""

    computed_at: str
    count: int
    coverage: float
    thresholds: TldThresholds


class TldMeta(BaseModel):
    """Metadata for a single-TLD response."""

    computed_at: str
    thresholds: TldThresholds


class TldListResponse(BaseModel):
    """Response from ``GET /tlds``."""

    data: List[TldEntry]
    meta: TldListMeta
    etag: Optional[str] = None


class TldResponse(BaseModel):
    """Response from ``GET /tlds/{tld}``."""

    data: TldEntry
    meta: TldMeta
    etag: Optional[str] = None


class EntityResponse(BaseModel):
    """Response from an entity lookup."""

    handle: Optional[str] = None
    name: Optional[str] = None
    organization: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    contact_url: Optional[str] = None
    country_code: Optional[str] = None
    roles: List[str] = Field(default_factory=list)
    status: List[str] = Field(default_factory=list)
    dates: Dates
    remarks: List[Remark] = Field(default_factory=list)
    port43: Optional[str] = None
    public_ids: List[PublicId] = Field(default_factory=list)
    entities: Entities = Field(default_factory=Entities)
    autnums: List[EntityAutnum] = Field(default_factory=list)
    networks: List[EntityNetwork] = Field(default_factory=list)
    meta: Meta
