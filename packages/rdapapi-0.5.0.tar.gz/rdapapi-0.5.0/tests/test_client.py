"""Tests for the synchronous RDAP API client."""

import httpx
import pytest
import respx

from rdapapi import (
    AuthenticationError,
    NotFoundError,
    NotSupportedError,
    RateLimitError,
    RdapApi,
    RdapApiError,
    SubscriptionRequiredError,
    TemporarilyUnavailableError,
    UpstreamError,
    ValidationError,
)
from rdapapi.models import BulkDomainResponse, TldListResponse, TldResponse

BASE_URL = "https://rdapapi.io/api/v1"

DOMAIN_RESPONSE = {
    "domain": "google.com",
    "unicode_name": None,
    "handle": "2138514_DOMAIN_COM-VRSN",
    "status": ["client delete prohibited"],
    "registrar": {
        "name": "MarkMonitor Inc.",
        "iana_id": "292",
        "abuse_email": "abusecomplaints@markmonitor.com",
        "abuse_phone": "+1.2086851750",
        "url": "http://www.markmonitor.com",
    },
    "dates": {
        "registered": "1997-09-15T04:00:00Z",
        "expires": "2028-09-14T04:00:00Z",
        "updated": "2019-09-09T15:39:04Z",
    },
    "nameservers": ["ns1.google.com", "ns2.google.com"],
    "dnssec": False,
    "entities": {},
    "meta": {
        "rdap_server": "https://rdap.verisign.com/com/v1/",
        "raw_rdap_url": "https://rdap.verisign.com/com/v1/domain/google.com",
        "cached": True,
        "cache_expires": "2026-02-24T15:30:00Z",
    },
}

IP_RESPONSE = {
    "handle": "NET-8-8-8-0-2",
    "name": "GOGL",
    "type": "DIRECT ALLOCATION",
    "start_address": "8.8.8.0",
    "end_address": "8.8.8.255",
    "ip_version": "v4",
    "parent_handle": "NET-8-0-0-0-0",
    "country": None,
    "status": ["active"],
    "dates": {"registered": "2023-12-28T17:24:33-05:00", "expires": None, "updated": "2023-12-28T17:24:56-05:00"},
    "entities": {},
    "cidr": ["8.8.8.0/24"],
    "remarks": [],
    "port43": "whois.arin.net",
    "meta": {
        "rdap_server": "https://rdap.arin.net/registry/",
        "raw_rdap_url": "https://rdap.arin.net/registry/ip/8.8.8.8",
        "cached": False,
        "cache_expires": "2026-02-24T15:30:00Z",
    },
}

ASN_RESPONSE = {
    "handle": "AS15169",
    "name": "GOOGLE",
    "type": None,
    "start_autnum": 15169,
    "end_autnum": 15169,
    "status": ["active"],
    "dates": {"registered": "2000-03-30T00:00:00-05:00", "expires": None, "updated": "2012-02-24T09:44:34-05:00"},
    "entities": {},
    "remarks": [],
    "port43": "whois.arin.net",
    "meta": {
        "rdap_server": "https://rdap.arin.net/registry/",
        "raw_rdap_url": "https://rdap.arin.net/registry/autnum/15169",
        "cached": False,
        "cache_expires": "2026-02-24T15:30:00Z",
    },
}

NS_RESPONSE = {
    "ldh_name": "ns1.google.com",
    "unicode_name": None,
    "handle": None,
    "ip_addresses": {"v4": ["216.239.32.10"], "v6": ["2001:4860:4802:32::a"]},
    "status": [],
    "dates": {"registered": None, "expires": None, "updated": None},
    "entities": {},
    "meta": {
        "rdap_server": "https://rdap.verisign.com/com/v1/",
        "raw_rdap_url": "https://rdap.verisign.com/com/v1/nameserver/ns1.google.com",
        "cached": False,
        "cache_expires": "2026-02-24T15:30:00Z",
    },
}

ENTITY_RESPONSE = {
    "handle": "GOGL",
    "name": "Google LLC",
    "organization": None,
    "email": None,
    "phone": None,
    "address": "1600 Amphitheatre Parkway\nMountain View\nCA\n94043\nUS",
    "contact_url": None,
    "country_code": None,
    "roles": [],
    "status": [],
    "dates": {"registered": "2000-03-30T00:00:00-04:00", "expires": None, "updated": "2019-10-31T15:45:45-04:00"},
    "remarks": [{"title": "Registration Comments", "description": "Please note..."}],
    "port43": "whois.arin.net",
    "public_ids": [{"type": "ARIN OrgID", "identifier": "GOGL"}],
    "entities": {
        "abuse": {
            "handle": "ABUSE5250-ARIN",
            "name": "Abuse",
            "organization": None,
            "email": "network-abuse@google.com",
            "phone": "+1-650-253-0000",
            "address": None,
            "contact_url": None,
            "country_code": None,
        },
    },
    "autnums": [{"handle": "AS15169", "name": "GOOGLE", "start_autnum": 15169, "end_autnum": 15169}],
    "networks": [
        {
            "handle": "NET-8-8-8-0-2",
            "name": "GOGL",
            "start_address": "8.8.8.0",
            "end_address": "8.8.8.255",
            "ip_version": "v4",
            "cidr": ["8.8.8.0/24"],
        },
    ],
    "meta": {
        "rdap_server": "https://rdap.arin.net/registry/",
        "raw_rdap_url": "https://rdap.arin.net/registry/entity/GOGL",
        "cached": False,
        "cache_expires": "2026-02-24T15:30:00Z",
    },
}


@respx.mock
def test_domain_lookup():
    respx.get(f"{BASE_URL}/domain/google.com").mock(return_value=httpx.Response(200, json=DOMAIN_RESPONSE))

    api = RdapApi("test-key", base_url=BASE_URL)
    result = api.domain("google.com")

    assert result.domain == "google.com"
    assert result.registrar.name == "MarkMonitor Inc."
    assert result.registrar.iana_id == "292"
    assert result.dates.registered == "1997-09-15T04:00:00Z"
    assert result.nameservers == ["ns1.google.com", "ns2.google.com"]
    assert result.dnssec is False
    assert result.meta.cached is True
    api.close()


@respx.mock
def test_domain_lookup_with_follow():
    route = respx.get(f"{BASE_URL}/domain/google.com", params={"follow": "true"}).mock(
        return_value=httpx.Response(200, json=DOMAIN_RESPONSE)
    )

    api = RdapApi("test-key", base_url=BASE_URL)
    api.domain("google.com", follow=True)

    assert route.called
    api.close()


@respx.mock
def test_ip_lookup():
    respx.get(f"{BASE_URL}/ip/8.8.8.8").mock(return_value=httpx.Response(200, json=IP_RESPONSE))

    api = RdapApi("test-key", base_url=BASE_URL)
    result = api.ip("8.8.8.8")

    assert result.handle == "NET-8-8-8-0-2"
    assert result.name == "GOGL"
    assert result.cidr == ["8.8.8.0/24"]
    assert result.ip_version == "v4"
    assert result.port43 == "whois.arin.net"
    api.close()


@respx.mock
def test_asn_lookup():
    respx.get(f"{BASE_URL}/asn/15169").mock(return_value=httpx.Response(200, json=ASN_RESPONSE))

    api = RdapApi("test-key", base_url=BASE_URL)
    result = api.asn(15169)

    assert result.handle == "AS15169"
    assert result.name == "GOOGLE"
    assert result.start_autnum == 15169
    api.close()


@respx.mock
def test_asn_accepts_string_with_prefix():
    respx.get(f"{BASE_URL}/asn/15169").mock(return_value=httpx.Response(200, json=ASN_RESPONSE))

    api = RdapApi("test-key", base_url=BASE_URL)
    result = api.asn("AS15169")

    assert result.handle == "AS15169"
    api.close()


@respx.mock
def test_nameserver_lookup():
    respx.get(f"{BASE_URL}/nameserver/ns1.google.com").mock(return_value=httpx.Response(200, json=NS_RESPONSE))

    api = RdapApi("test-key", base_url=BASE_URL)
    result = api.nameserver("ns1.google.com")

    assert result.ldh_name == "ns1.google.com"
    assert result.ip_addresses.v4 == ["216.239.32.10"]
    assert result.ip_addresses.v6 == ["2001:4860:4802:32::a"]
    api.close()


@respx.mock
def test_entity_lookup():
    respx.get(f"{BASE_URL}/entity/GOGL").mock(return_value=httpx.Response(200, json=ENTITY_RESPONSE))

    api = RdapApi("test-key", base_url=BASE_URL)
    result = api.entity("GOGL")

    assert result.handle == "GOGL"
    assert result.name == "Google LLC"
    assert result.entities.abuse is not None
    assert result.entities.abuse.email == "network-abuse@google.com"
    assert result.autnums[0].handle == "AS15169"
    assert result.networks[0].cidr == ["8.8.8.0/24"]
    assert result.public_ids[0].identifier == "GOGL"
    api.close()


@respx.mock
def test_context_manager():
    respx.get(f"{BASE_URL}/domain/google.com").mock(return_value=httpx.Response(200, json=DOMAIN_RESPONSE))

    with RdapApi("test-key", base_url=BASE_URL) as api:
        result = api.domain("google.com")
        assert result.domain == "google.com"


@respx.mock
def test_custom_base_url():
    respx.get("http://localhost/api/v1/domain/test.com").mock(return_value=httpx.Response(200, json=DOMAIN_RESPONSE))

    api = RdapApi("test-key", base_url="http://localhost/api/v1")
    result = api.domain("test.com")
    assert result.domain == "google.com"  # fixture data
    api.close()


@respx.mock
def test_authentication_error():
    respx.get(f"{BASE_URL}/domain/test.com").mock(
        return_value=httpx.Response(401, json={"error": "unauthenticated", "message": "Invalid or missing API token."})
    )

    api = RdapApi("bad-key", base_url=BASE_URL)
    with pytest.raises(AuthenticationError) as exc_info:
        api.domain("test.com")

    assert exc_info.value.status_code == 401
    assert exc_info.value.error == "unauthenticated"
    api.close()


@respx.mock
def test_subscription_required_error():
    respx.get(f"{BASE_URL}/domain/test.com").mock(
        return_value=httpx.Response(
            403, json={"error": "subscription_required", "message": "An active subscription is required."}
        )
    )

    api = RdapApi("test-key", base_url=BASE_URL)
    with pytest.raises(SubscriptionRequiredError) as exc_info:
        api.domain("test.com")

    assert exc_info.value.status_code == 403
    api.close()


@respx.mock
def test_not_found_error():
    respx.get(f"{BASE_URL}/domain/nonexistent.example").mock(
        return_value=httpx.Response(404, json={"error": "not_found", "message": "No RDAP data found."})
    )

    api = RdapApi("test-key", base_url=BASE_URL)
    with pytest.raises(NotFoundError) as exc_info:
        api.domain("nonexistent.example")

    assert exc_info.value.status_code == 404
    assert not isinstance(exc_info.value, NotSupportedError)
    api.close()


@respx.mock
def test_not_supported_error_raised_on_unsupported_tld():
    respx.get(f"{BASE_URL}/domain/example.nope").mock(
        return_value=httpx.Response(
            404,
            json={"error": "not_supported", "message": "The TLD '.nope' is not supported."},
        )
    )

    api = RdapApi("test-key", base_url=BASE_URL)
    with pytest.raises(NotSupportedError) as exc_info:
        api.domain("example.nope")

    assert exc_info.value.status_code == 404
    assert exc_info.value.error == "not_supported"
    # Backwards compatible: NotSupportedError IS a NotFoundError.
    assert isinstance(exc_info.value, NotFoundError)
    api.close()


@respx.mock
def test_not_supported_error_on_ip_lookup():
    respx.get(f"{BASE_URL}/ip/203.0.113.1").mock(
        return_value=httpx.Response(
            404,
            json={"error": "not_supported", "message": "No RIR covers this IP range."},
        )
    )

    api = RdapApi("test-key", base_url=BASE_URL)
    with pytest.raises(NotSupportedError):
        api.ip("203.0.113.1")
    api.close()


@respx.mock
def test_rate_limit_error():
    respx.get(f"{BASE_URL}/domain/test.com").mock(
        return_value=httpx.Response(
            429,
            json={"error": "rate_limit_exceeded", "message": "Rate limit exceeded."},
            headers={"Retry-After": "60"},
        )
    )

    api = RdapApi("test-key", base_url=BASE_URL)
    with pytest.raises(RateLimitError) as exc_info:
        api.domain("test.com")

    assert exc_info.value.status_code == 429
    assert exc_info.value.retry_after == 60
    api.close()


@respx.mock
def test_temporarily_unavailable_error():
    respx.get(f"{BASE_URL}/domain/test.com").mock(
        return_value=httpx.Response(
            503,
            json={"error": "temporarily_unavailable", "message": "Data for this domain is temporarily unavailable."},
            headers={"Retry-After": "300"},
        )
    )

    api = RdapApi("test-key", base_url=BASE_URL)
    with pytest.raises(TemporarilyUnavailableError) as exc_info:
        api.domain("test.com")

    assert exc_info.value.status_code == 503
    assert exc_info.value.retry_after == 300
    api.close()


@respx.mock
def test_temporarily_unavailable_error_without_retry_after():
    respx.get(f"{BASE_URL}/domain/test.com").mock(
        return_value=httpx.Response(
            503,
            json={"error": "temporarily_unavailable", "message": "Data for this domain is temporarily unavailable."},
        )
    )

    api = RdapApi("test-key", base_url=BASE_URL)
    with pytest.raises(TemporarilyUnavailableError) as exc_info:
        api.domain("test.com")

    assert exc_info.value.status_code == 503
    assert exc_info.value.retry_after is None
    api.close()


@respx.mock
def test_validation_error():
    respx.get(f"{BASE_URL}/domain/invalid").mock(
        return_value=httpx.Response(
            400, json={"error": "invalid_domain", "message": "The provided domain name is not valid."}
        )
    )

    api = RdapApi("test-key", base_url=BASE_URL)
    with pytest.raises(ValidationError) as exc_info:
        api.domain("invalid")

    assert exc_info.value.status_code == 400
    api.close()


@respx.mock
def test_upstream_error():
    respx.get(f"{BASE_URL}/domain/test.com").mock(
        return_value=httpx.Response(502, json={"error": "lookup_failed", "message": "RDAP lookup failed."})
    )

    api = RdapApi("test-key", base_url=BASE_URL)
    with pytest.raises(UpstreamError) as exc_info:
        api.domain("test.com")

    assert exc_info.value.status_code == 502
    api.close()


def test_empty_api_key_raises():
    with pytest.raises(ValueError, match="non-empty"):
        RdapApi("")


@respx.mock
def test_non_json_error_body():
    respx.get(f"{BASE_URL}/domain/test.com").mock(return_value=httpx.Response(500, text="Internal Server Error"))

    api = RdapApi("test-key", base_url=BASE_URL)
    with pytest.raises(RdapApiError) as exc_info:
        api.domain("test.com")

    assert exc_info.value.status_code == 500
    assert exc_info.value.error == "unknown_error"
    api.close()


@respx.mock
def test_auth_header_sent():
    route = respx.get(f"{BASE_URL}/domain/google.com").mock(return_value=httpx.Response(200, json=DOMAIN_RESPONSE))

    api = RdapApi("my-secret-key", base_url=BASE_URL)
    api.domain("google.com")

    assert route.calls[0].request.headers["authorization"] == "Bearer my-secret-key"
    api.close()


# === Bulk Domain Lookups ===

BULK_RESPONSE = {
    "results": [
        {
            "domain": "google.com",
            "status": "success",
            "data": {
                "domain": "google.com",
                "unicode_name": None,
                "handle": "2138514_DOMAIN_COM-VRSN",
                "status": ["client delete prohibited"],
                "registrar": {
                    "name": "MarkMonitor Inc.",
                    "iana_id": "292",
                    "abuse_email": None,
                    "abuse_phone": None,
                    "url": None,
                },
                "dates": {"registered": "1997-09-15T04:00:00Z", "expires": "2028-09-14T04:00:00Z", "updated": None},
                "nameservers": ["ns1.google.com", "ns2.google.com"],
                "dnssec": False,
                "entities": {},
            },
            "meta": {
                "rdap_server": "https://rdap.verisign.com/com/v1/",
                "raw_rdap_url": "https://rdap.verisign.com/com/v1/domain/google.com",
                "cached": False,
                "cache_expires": "2026-02-25T15:30:00Z",
            },
        },
        {
            "domain": "invalid..com",
            "status": "error",
            "error": "invalid_domain",
            "message": "The provided domain name is not valid.",
        },
    ],
    "summary": {"total": 2, "successful": 1, "failed": 1},
}


@respx.mock
def test_bulk_domains_lookup():
    respx.post(f"{BASE_URL}/domains/bulk").mock(return_value=httpx.Response(200, json=BULK_RESPONSE))

    api = RdapApi("test-key", base_url=BASE_URL)
    result = api.bulk_domains(["google.com", "invalid..com"])

    assert isinstance(result, BulkDomainResponse)
    assert result.summary.total == 2
    assert result.summary.successful == 1
    assert result.summary.failed == 1

    # Successful result has data as DomainResponse
    assert result.results[0].status == "success"
    assert result.results[0].data is not None
    assert result.results[0].data.domain == "google.com"
    assert result.results[0].data.registrar.name == "MarkMonitor Inc."
    assert result.results[0].data.meta.rdap_server == "https://rdap.verisign.com/com/v1/"

    # Error result has error info
    assert result.results[1].status == "error"
    assert result.results[1].error == "invalid_domain"
    assert result.results[1].data is None

    api.close()


@respx.mock
def test_bulk_domains_with_follow():
    route = respx.post(f"{BASE_URL}/domains/bulk").mock(return_value=httpx.Response(200, json=BULK_RESPONSE))

    api = RdapApi("test-key", base_url=BASE_URL)
    api.bulk_domains(["google.com"], follow=True)

    request = route.calls[0].request
    import json

    body = json.loads(request.content)
    assert body["domains"] == ["google.com"]
    assert body["follow"] is True
    api.close()


@respx.mock
def test_bulk_domains_without_follow_omits_key():
    route = respx.post(f"{BASE_URL}/domains/bulk").mock(return_value=httpx.Response(200, json=BULK_RESPONSE))

    api = RdapApi("test-key", base_url=BASE_URL)
    api.bulk_domains(["google.com"])

    request = route.calls[0].request
    import json

    body = json.loads(request.content)
    assert "follow" not in body
    api.close()


@respx.mock
def test_bulk_domains_plan_upgrade_required():
    respx.post(f"{BASE_URL}/domains/bulk").mock(
        return_value=httpx.Response(
            403, json={"error": "plan_upgrade_required", "message": "Bulk lookups require a Pro or Business plan."}
        )
    )

    api = RdapApi("test-key", base_url=BASE_URL)
    with pytest.raises(SubscriptionRequiredError) as exc_info:
        api.bulk_domains(["google.com"])

    assert exc_info.value.status_code == 403
    assert exc_info.value.error == "plan_upgrade_required"
    api.close()


@respx.mock
def test_bulk_domains_auth_error():
    respx.post(f"{BASE_URL}/domains/bulk").mock(
        return_value=httpx.Response(401, json={"error": "unauthenticated", "message": "Invalid or missing API token."})
    )

    api = RdapApi("bad-key", base_url=BASE_URL)
    with pytest.raises(AuthenticationError):
        api.bulk_domains(["google.com"])
    api.close()


@respx.mock
def test_bulk_domains_rate_limit_error():
    respx.post(f"{BASE_URL}/domains/bulk").mock(
        return_value=httpx.Response(
            429,
            json={"error": "rate_limit_exceeded", "message": "Rate limit exceeded."},
            headers={"Retry-After": "60"},
        )
    )

    api = RdapApi("test-key", base_url=BASE_URL)
    with pytest.raises(RateLimitError) as exc_info:
        api.bulk_domains(["google.com"])

    assert exc_info.value.retry_after == 60
    api.close()


# === TLDs ===

TLDS_RESPONSE = {
    "data": [
        {
            "tld": "com",
            "supported_since": "2026-03-07T00:00:00Z",
            "rdap_server_host": "rdap.verisign.com",
            "rdap_server_url": "https://rdap.verisign.com/com/v1/",
            "field_availability": {
                "registrar": "sometimes",
                "registered_at": "always",
                "expires_at": "always",
                "nameservers": "always",
                "status": "always",
            },
        },
        {
            "tld": "fr",
            "supported_since": "2026-03-07T00:00:00Z",
            "rdap_server_host": "rdap.nic.fr",
            "rdap_server_url": "https://rdap.nic.fr/",
            "field_availability": None,
        },
    ],
    "meta": {
        "computed_at": "2026-04-22T10:00:00Z",
        "count": 2,
        "coverage": 0.5,
        "thresholds": {"always": 0.99, "usually": 0.8, "sometimes": 0.0},
    },
}

TLD_RESPONSE = {
    "data": {
        "tld": "com",
        "supported_since": "2026-03-07T00:00:00Z",
        "rdap_server_host": "rdap.verisign.com",
        "rdap_server_url": "https://rdap.verisign.com/com/v1/",
        "field_availability": {
            "registrar": "sometimes",
            "registered_at": "always",
            "expires_at": "always",
            "nameservers": "always",
            "status": "always",
        },
    },
    "meta": {
        "computed_at": "2026-04-22T10:00:00Z",
        "thresholds": {"always": 0.99, "usually": 0.8, "sometimes": 0.0},
    },
}


@respx.mock
def test_tlds_list():
    respx.get(f"{BASE_URL}/tlds").mock(return_value=httpx.Response(200, json=TLDS_RESPONSE, headers={"ETag": '"abc"'}))

    api = RdapApi("test-key", base_url=BASE_URL)
    result = api.tlds()

    assert isinstance(result, TldListResponse)
    assert result.meta.count == 2
    assert result.meta.coverage == 0.5
    assert result.meta.thresholds.always == 0.99
    assert result.data[0].tld == "com"
    assert result.data[0].field_availability is not None
    assert result.data[0].field_availability.registered_at == "always"
    assert result.data[1].field_availability is None
    assert result.etag == '"abc"'
    api.close()


@respx.mock
def test_tlds_list_with_since_and_server():
    route = respx.get(f"{BASE_URL}/tlds").mock(return_value=httpx.Response(200, json=TLDS_RESPONSE))

    api = RdapApi("test-key", base_url=BASE_URL)
    api.tlds(since="2026-04-01T00:00:00Z", server="rdap.verisign.com")

    request = route.calls[0].request
    assert request.url.params["since"] == "2026-04-01T00:00:00Z"
    assert request.url.params["server"] == "rdap.verisign.com"
    api.close()


@respx.mock
def test_tlds_list_304_returns_none():
    respx.get(f"{BASE_URL}/tlds").mock(return_value=httpx.Response(304))

    api = RdapApi("test-key", base_url=BASE_URL)
    result = api.tlds(if_none_match='"abc"')

    assert result is None
    api.close()


@respx.mock
def test_tlds_list_sends_if_none_match_header():
    route = respx.get(f"{BASE_URL}/tlds").mock(return_value=httpx.Response(304))

    api = RdapApi("test-key", base_url=BASE_URL)
    api.tlds(if_none_match='"etag-value"')

    assert route.calls[0].request.headers["if-none-match"] == '"etag-value"'
    api.close()


@respx.mock
def test_tld_show():
    respx.get(f"{BASE_URL}/tlds/com").mock(
        return_value=httpx.Response(200, json=TLD_RESPONSE, headers={"ETag": '"com-1"'})
    )

    api = RdapApi("test-key", base_url=BASE_URL)
    result = api.tld("com")

    assert isinstance(result, TldResponse)
    assert result.data.tld == "com"
    assert result.meta.thresholds.usually == 0.8
    assert result.etag == '"com-1"'
    api.close()


@respx.mock
def test_tld_show_304_returns_none():
    respx.get(f"{BASE_URL}/tlds/com").mock(return_value=httpx.Response(304))

    api = RdapApi("test-key", base_url=BASE_URL)
    assert api.tld("com", if_none_match='"com-1"') is None
    api.close()


@respx.mock
def test_tld_show_not_found():
    respx.get(f"{BASE_URL}/tlds/nope").mock(
        return_value=httpx.Response(
            404, json={"error": "not_found", "message": "No RDAP server is registered for the TLD 'nope'."}
        )
    )

    api = RdapApi("test-key", base_url=BASE_URL)
    with pytest.raises(NotFoundError):
        api.tld("nope")
    api.close()
