from enum import Enum, unique
# from abc import ABC, abstractclassmethod  抽象
from operator import attrgetter
from typing import Generic, List, Dict, Literal, Type, Optional, TypeVar, Generator, Any

from co6co import K, V, T
E = TypeVar('E', bound='Base_Enum')
# class Base_Enum2 (Enum,Generic[K,T]):pass
# Base_Enum2Init=Base_Enum2[str,int]


@unique  # 帮助检查 保证没有重复值
class Base_Enum (Enum):
    """
    枚举[key, val]
    name:才是真正的Key,环境保证它的唯一性
    key: 为人为设置由用户保证它的唯一性
    """
    # key: K
    # val: V

    def __new__(cls, key: K, value: V):
        _value = len(cls.__members__) + 1  # 为每个成员分配一个递增的整数值
        obj = object.__new__(cls)
        obj.key = key
        obj.val = value  # value 为元组 (en_name,cn_name,val)
        obj._value_ = _value  # 设置枚举成员的值
        return obj

    @classmethod
    def to_dict_list(cls) -> List[Dict]:
        status = [{'uid': i.name, 'key': i.key, 'value': i.val} for i in cls]
        return status

    @classmethod
    def key2enum(cls: Type[E], key: K) -> Optional[E]:
        """
        key 转枚举 
        """
        for i in cls:
            if i.key == key:
                return i
        return None

    @classmethod
    def name2enum(cls: Type[E], name: str) -> Optional[E]:
        """
        name 转枚举 
        """
        for i in cls:
            if i.name == name:
                return i
        return None

    @classmethod
    def val2enum(cls: Type[E], val: V) -> Optional[E]:
        """
        val 转枚举 
        """
        for i in cls:
            if i.val == val:
                return i
        return None

    @classmethod
    def value2enum(cls: Type[E], value: int) -> Optional[E]:
        """
        val 转枚举 
        """
        for i in cls:
            if i._value_ == value:
                return i
        return None

    @classmethod
    def generator(cls: Type[E]) -> Generator[E, Any, None]:
        for _, v in cls.__members__.items():
            yield v

    @classmethod
    def _to_str(cls, attr) -> str:
        return ",".join([f"{i.val}:{getattr(i, attr)}" for i in cls])

    @classmethod
    def to_str(cls, attr: Literal["key", "name"]) -> str:
        return cls._to_str(attr)

    @classmethod
    def value_of(cls: Type[E], name: str, ignoreError: bool = True) -> Optional[E]:
        """
        枚举的字符串 转枚举
        demo(Base_Enum):
            chanel="ch",1
        字符串 为 chanel 
        """
        for k, v in cls.__members__.items():
            if k == name:
                return v
        else:
            if ignoreError:
                return None
            else:
                raise ValueError(f"'{cls.__name__}' enum not found for '{name}'")

    def __str__(self):
        """
        name value 原始枚举值
        """
        return f'name: {self.name}, value: {self.value}, key:{self.key},val:{self.val}'


@unique
class Base_EC_Enum(Base_Enum):
    """
    枚举[key:英文 ,label:中文 ,val:数字] 
    """
    key: K
    label: T
    val: V

    def __new__(cls, key: K, label: T, value: V):
        print(f"Creating enum member with key={key}, label={label}, value={value}")
        obj = object.__new__(cls)
        # obj = super().__new__( key,value)
        # obj.__init__(key,value)  # 调用初始化方法
        obj.key = key
        obj.label = label
        obj.val = value  # value 为元组 (en_name,cn_name,val)
        _value = len(cls.__members__) + 1  # 为每个成员分配一个递增的整数值
        obj._value_ = _value  # 设置枚举成员的值
        print(f"new end")
        return obj

    @classmethod
    def to_dict_list(cls) -> List[Dict]:
        status = [{'uid': i.name, "label": i.label, 'key': i.key, 'value': i.val} for i in cls]
        return status

    @classmethod
    def to_str(cls, attr: Literal["key", "name", 'label']) -> str:
        return cls._to_str(attr)

    @classmethod
    def to_labels_str(cls) -> str:
        return cls.to_str("label")

    def __str__(self):
        """
        name value 原始枚举值
        """
        return f'name: {self.name}, value: {self.value}, key:{self.key},label:{self.label},val:{self.val}'
