import multiprocessing
import time
from multiprocessing import Process, Pipe
from multiprocessing.connection import PipeConnection
from typing import Dict, Any, Callable, Optional
from enum import Enum
import json
from dataclasses import dataclass, asdict
import threading
from abc import ABC, abstractmethod
from ..enums import Base_Enum
from typing import TypeVar, Optional, Type


class EventType(Base_Enum):
    """事件类型"""
    TASK = "task", 0
    RESULT = "result", 1
    ERROR = "error", 2
    SHUTDOWN = "shutdown", 3
    HEARTBEAT = "heartbeat", 4

    @staticmethod
    def convert(keyOrVal: str | int):
        """根据键或值转换为枚举成员,如果失败则返回原始值"""
        result = EventType.key2enum(keyOrVal)
        if result is None:
            result = EventType.val2enum(keyOrVal)
        if result is None:
            return keyOrVal


@dataclass
class Event:
    """事件基类"""
    event_type: EventType | str | int
    data: Any
    source: str
    timestamp: float = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()

    def to_dict(self):
        return {
            "event_type": self.event_type.key if isinstance(self.event_type, EventType) else self.event_type,
            "data": self.data,
            "source": self.source,
            "timestamp": self.timestamp
        }

    @classmethod
    def from_dict(cls, data: Dict):
        return cls(
            event_type=EventType.convert(data["event_type"]),
            data=data["data"],
            source=data["source"],
            timestamp=data["timestamp"]
        )


class EventHandler(ABC):
    """事件处理器基类"""

    @abstractmethod
    def handle(self, event: Event) -> Optional[Event]:
        """处理事件，返回响应事件或None"""
        pass

    @property
    @abstractmethod
    def supported_events(self):
        return [EventType.ERROR]

    def is_supported(self, event_type: EventType) -> bool:
        """检查是否支持处理该事件类型"""
        return event_type in self.supported_events


T = TypeVar('T', bound='EventHandler')


class TaskHandler(EventHandler):
    """任务处理器"""

    def handle(self, event: Event) -> Optional[Event]:
        if self.is_supported(event.event_type):  # EventType.TASK
            print(f"[TaskHandler] 处理任务: {event.data}")
            # 模拟处理
            time.sleep(0.1)
            result = f"任务完成: {event.data}"

            return Event(
                event_type=EventType.RESULT,
                data=result,
                source="task_handler",
                timestamp=time.time()
            )
        return None

    @property
    def supported_events(self):
        return [EventType.TASK]


class ErrorHandler(EventHandler):
    """错误处理器"""

    def handle(self, event: Event) -> Optional[Event]:
        if self.is_supported(event.event_type):  # EventType.ERROR
            print(f"[ErrorHandler] 处理错误: {event.data}")
            # 可以记录日志、发送报警等
            return Event(
                event_type=EventType.RESULT,
                data=f"错误已处理: {event.data}",
                source="error_handler",
                timestamp=time.time()
            )
        return None

    @property
    def supported_events(self):
        return [EventType.ERROR]


class EventDispatcher:
    """事件分发器"""

    def __init__(self):
        self.handlers: Dict[EventType, list[EventHandler]] = {}

    def register_handler(self, event_type: EventType, handler: EventHandler):
        """注册事件处理器"""
        if event_type not in self.handlers:
            self.handlers[event_type] = []
        self.handlers[event_type].append(handler)

    def dispatch(self, event: Event) -> list[Event]:
        """分发事件给所有注册的处理器"""
        responses = []
        if event.event_type in self.handlers:
            for handler in self.handlers[event.event_type]:
                try:
                    response = handler.handle(event)
                    if response:
                        responses.append(response)
                except Exception as e:
                    error_event = Event(
                        event_type=EventType.ERROR,
                        data=str(e),
                        source="event_dispatcher",
                        timestamp=time.time()
                    )
                    responses.append(error_event)
        return responses


class EventDispatcherProcess:
    def __init__(self,  conn: PipeConnection, worker_id: int | str = "worker"):
        self.conn = conn
        self.isQuit = False
        self._is_running = False
        self.worker_id = worker_id
        self.handler_classes = []

    @property
    def is_running(self):
        return self._is_running

    def resgister_handler(self, *handler_claszes: Type[T]):
        """注册自定义事件处理器类"""

        self.handler_classes.extend(handler_claszes)

    def clear_handlers(self):
        self.handler_classes.clear()

    def stop(self):
        """发送关闭事件"""
        self.isQuit = True
        # shutdown_event = Event(
        #    event_type=EventType.SHUTDOWN,
        #    data=None,
        #    source=f"main_process",
        #    timestamp=time.time()
        # )
        # self.conn.send(shutdown_event.to_dict())
        # time.sleep(0.5)  # 等待子进程处理关闭事件
        self.conn.close()
        self.thread.join()

    def send(self, event: Event):
        """发送事件到主进程"""
        # 这里可以实现发送事件到主进程的逻辑，例如通过管道或队列
        self.conn.send(event.to_dict())

    def _worker(self):
        # 创建事件分发器
        dispatcher = EventDispatcher()
        # 注册默认处理器
        dispatcher.register_handler(EventType.TASK, TaskHandler())
        dispatcher.register_handler(EventType.ERROR, ErrorHandler())

        # 注册自定义处理器
        if self.handler_classes:
            for handler_class in self.handler_classes:
                handler = handler_class()

                # 根据处理器支持的事件类型注册
                if hasattr(handler, 'supported_events'):
                    for event_type in handler.supported_events:
                        dispatcher.register_handler(event_type, handler)

        worker_id = self.worker_id
        # 心跳处理器

        class HeartbeatHandler(EventHandler):
            def handle(self, event: Event) -> Optional[Event]:
                if event.event_type == EventType.HEARTBEAT:
                    return Event(
                        event_type=EventType.HEARTBEAT,
                        data={"worker_id": worker_id, "status": "alive"},
                        source=f"worker_{worker_id}",
                        timestamp=time.time()
                    )
                return None

            @property
            def supported_events(self):
                return [EventType.HEARTBEAT]

        dispatcher.register_handler(EventType.HEARTBEAT, HeartbeatHandler())
        # 主循环
        while True:
            try:
                if self.isQuit:
                    print(f"[Worker {self.worker_id}] 收到退出信号")
                    break
                event_dict = self.conn.recv()
                event = Event.from_dict(event_dict)
                if event.event_type == EventType.SHUTDOWN:
                    print(f"[Worker {self.worker_id}] 收到关闭事件")
                    break

                # 分发事件
                responses = dispatcher.dispatch(event)
                # 发送所有响应
                for response in responses:
                    self.conn.send(response.to_dict())

            except EOFError:
                print(f"[Worker {self.worker_id}] 连接中断")
                break
            except Exception as e:
                print(f"[Worker {self.worker_id}] 错误: {e}")
                error_event = Event(
                    event_type=EventType.ERROR,
                    data=str(e),
                    source=f"worker_{self.worker_id}",
                    timestamp=time.time()
                )
                self.conn.send(error_event.to_dict())

        print(f"[Worker {self.worker_id}] 退出")
        # self.conn.close()

    def start(self):
        """工作进程 - 使用事件驱动架构"""
        if self._is_running:
            print(f"[Worker {self.worker_id}] 已经在运行")
            return
        print(f"[Worker {self.worker_id}] 启动")
        self.thread = threading.Thread(target=self._worker, name=f"worker_{self.worker_id}")  # , args=(conn,)
        self.thread.start()
        self._is_running = True
