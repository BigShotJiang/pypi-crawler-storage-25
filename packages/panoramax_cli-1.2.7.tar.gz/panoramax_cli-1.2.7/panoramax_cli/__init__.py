"""
Panoramax client cli tool
"""

__version__ = "1.2.7"

USER_AGENT = f"PanoramaxCLI/{__version__}"
