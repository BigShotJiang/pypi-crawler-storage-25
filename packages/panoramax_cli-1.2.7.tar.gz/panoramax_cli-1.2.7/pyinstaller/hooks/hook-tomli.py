from PyInstaller.utils.hooks import collect_data_files, collect_dynamic_libs

# linked to https://github.com/hukkin/tomli/issues/255
MYPYC_WHEEL = "3c22db458360489351e4__mypyc"

binaries = collect_dynamic_libs("tomli", search_patterns=["*.dll", "*.so", "*.pyd"]) + collect_dynamic_libs(
    MYPYC_WHEEL, search_patterns=["*.dll", "*.so", "*.pyd"]
)
hiddenimports = ["tomli", MYPYC_WHEEL]
