from pathlib import Path

from vyasa.config import VyasaConfig
from vyasa.logging import configure_logging


def test_config_log_file_defaults_to_false(tmp_path):
    config = VyasaConfig(tmp_path / ".vyasa")

    assert config.get_log_file_enabled() is False


def test_configure_logging_adds_file_sink_only_when_enabled(monkeypatch, tmp_path):
    added_sinks = []

    class StubConfig:
        def __init__(self, enabled: bool):
            self.enabled = enabled

        def get_log_file_enabled(self) -> bool:
            return self.enabled

        def get_root_folder(self) -> Path:
            return tmp_path

    monkeypatch.setattr("vyasa.logging.logger.remove", lambda: None)
    monkeypatch.setattr("vyasa.logging.logger.add", lambda sink, **kwargs: added_sinks.append((sink, kwargs)))

    monkeypatch.setattr("vyasa.logging.get_config", lambda: StubConfig(False))
    configure_logging()
    assert [sink for sink, _ in added_sinks if sink == str(tmp_path / "vyasa.log")] == []

    added_sinks.clear()
    monkeypatch.setattr("vyasa.logging.get_config", lambda: StubConfig(True))
    configure_logging()
    assert [sink for sink, _ in added_sinks if sink == str(tmp_path / "vyasa.log")] == [str(tmp_path / "vyasa.log")]
