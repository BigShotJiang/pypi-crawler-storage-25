from fasthtml.common import to_xml

from vyasa.markdown_rendering import from_md


def test_cryptograph_block_renders_widget_data():
    md = """```cryptograph
---
title: Launch Memo
hint: Classic Caesar shift
answer: THE EAGLE LANDS AT MIDNIGHT
---
WKH HDJOH ODQGV DW PLGQLJKW
```"""

    html = to_xml(from_md(md))

    assert 'data-cryptograph-widget="true"' in html
    assert 'data-cryptograph-title="Launch Memo"' in html
    assert 'data-cryptograph-hint="Classic Caesar shift"' in html
    assert 'data-cryptograph-answer="THE EAGLE LANDS AT MIDNIGHT"' in html
    assert 'WKH HDJOH ODQGV DW PLGQLJKW' in html


def test_cryptograph_without_ciphertext_shows_warning():
    md = """```cryptograph
---
title: Broken
---
```"""

    html = to_xml(from_md(md))

    assert 'vyasa-callout-warning' in html
    assert 'Cryptograph blocks need ciphertext in the block body.' in html
