from vyasa.annotations_store import (
    AnnotationRow,
    delete_annotation,
    list_annotations,
    upsert_annotation,
)


def _row(annotation_id: str, *, path: str = "/docs/page/", comment: str = "First", created_at: str = "2026-04-06T10:00:00") -> AnnotationRow:
    return AnnotationRow(
        id=annotation_id,
        path=path,
        parent_id="",
        quote="Selected quote",
        prefix="",
        suffix="",
        anchor='{"start": 1, "end": 4}',
        comment=comment,
        author="tester",
        created_at=created_at,
        updated_at=created_at,
    )


def test_annotation_store_returns_empty_list_when_db_is_missing(tmp_path):
    cache = {"db": None, "tbl": None}

    assert list_annotations(tmp_path, cache, "/docs/page/") == []


def test_annotation_store_upsert_normalizes_path_and_updates_existing_row(tmp_path):
    cache = {"db": None, "tbl": None}
    first = _row("ann-1")
    updated = _row("ann-1", path="docs/page", comment="Updated", created_at="2026-04-06T11:00:00")

    upsert_annotation(tmp_path, cache, first)
    upsert_annotation(tmp_path, cache, updated)

    rows = list_annotations(tmp_path, cache, "docs/page")

    assert len(rows) == 1
    assert rows[0].path == "docs/page"
    assert rows[0].comment == "Updated"
    assert rows[0].created_at == "2026-04-06T11:00:00"


def test_annotation_store_lists_rows_sorted_by_created_at_and_deletes_by_id(tmp_path):
    cache = {"db": None, "tbl": None}
    later = _row("ann-2", comment="Later", created_at="2026-04-06T12:00:00")
    earlier = _row("ann-1", comment="Earlier", created_at="2026-04-06T09:00:00")

    upsert_annotation(tmp_path, cache, later)
    upsert_annotation(tmp_path, cache, earlier)

    rows = list_annotations(tmp_path, cache, "/docs/page/")

    assert [row.id for row in rows] == ["ann-1", "ann-2"]
    assert delete_annotation(tmp_path, cache, "ann-1") is True
    assert delete_annotation(tmp_path, cache, "missing") is False
    assert [row.id for row in list_annotations(tmp_path, cache, "docs/page")] == ["ann-2"]
