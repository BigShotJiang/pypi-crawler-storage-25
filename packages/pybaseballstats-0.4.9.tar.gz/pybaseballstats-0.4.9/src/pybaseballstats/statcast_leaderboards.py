import io
from datetime import datetime
from typing import Literal

import polars as pl
import requests
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright

from pybaseballstats.consts.statcast_leaderboard_consts import (
    ARM_STRENGTH_LEADERBOARD_URL,
    ARM_STRENGTH_POS_INPUT_MAP,
    PARK_FACTOR_DIMENSIONS_URL,
    PARK_FACTOR_DISTANCE_URL,
    PARK_FACTOR_YEARLY_URL,
    TIMER_INFRACTIONS_LEADERBOARD_URL,
    StatcastLeaderboardsTeams,
)

__all__ = [
    "park_factor_yearly_leaderboard",
    "park_factor_distance_leaderboard",
    "park_factor_dimensions_leaderboard",
    "timer_infractions_leaderboard",
    "arm_strength_leaderboard",
]


def park_factor_dimensions_leaderboard(
    season: int, metric: Literal["distance", "height"] = "distance"
):
    """Return Baseball Savant park-dimension leaderboard data.

    Args:
        season (int): Season year.
        metric (Literal["distance", "height"], optional): Fence metric set.

    Raises:
        ValueError: If ``metric`` is not ``"distance"`` or ``"height"``.
        ValueError: If ``season`` is outside valid supported years.

    Returns:
        pl.DataFrame: Park-dimension leaderboard data.
    """
    if metric not in ["distance", "height"]:
        raise ValueError("Metric must be either 'distance' or 'height'")
    curr_season = (
        datetime.now().year if datetime.now().month >= 3 else datetime.now().year - 1
    )
    if season < 2015 or season > curr_season:
        raise ValueError(f"Season must be between 2015 and {curr_season}")
    url = PARK_FACTOR_DIMENSIONS_URL.format(season=season, metric_type=metric)
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        try:
            page.goto(url)
            page.wait_for_selector("#parkFactors")

            table_html = page.inner_html("#parkFactors")
        finally:
            page.close()
            browser.close()

    table_soup = BeautifulSoup(table_html, "html.parser")

    table = table_soup.find("table")
    assert table is not None, "Could not find data table on page"
    table_data: dict[str, list[str]] = {}
    index_to_stat_mapping = {}
    thead = table.find("thead")
    assert thead is not None, "Could not find table header element"
    for tr in thead.find_all("tr"):
        tr_class = tr.get("class")
        if tr_class != ["tr-component-row"]:
            continue
        for th in tr.find_all("th"):
            if th.text.strip() == "Rk.":
                continue
            if metric == "distance":
                th_class = th.get("class")
                if (
                    th_class
                    and isinstance(th_class, list)
                    and "venue-info-height-col" in th_class
                ):
                    continue
            elif metric == "height":
                th_class = th.get("class")
                if (
                    th_class
                    and isinstance(th_class, list)
                    and "venue-info-dist-col" in th_class
                ):
                    continue
            table_data[th.text.strip()] = []
            index_to_stat_mapping[len(table_data) - 1] = th.text.strip()
    tbody = table.find("tbody")
    assert tbody is not None, "Could not find table body element"
    for row in tbody.find_all("tr"):
        row_class = row.get("class")
        if (
            not row_class
            or not isinstance(row_class, list)
            or "default-table-row" not in row_class
        ):  # skip non-data rows
            continue
        i = 0
        for td in row.find_all("td"):
            td_class = td.get("class")
            if td_class is None:
                continue  # skip if no class attribute
            if not isinstance(td_class, list):
                continue
            if "tr-data" in td_class:
                if (
                    "venue-info-height-col" in td_class
                    or "venue-info-dist-col" in td_class
                ):
                    if metric == "distance":
                        if (
                            "venue-info-height-col" in td_class
                        ):  # skip height column if we're looking at distance
                            continue
                    elif metric == "height":
                        if (
                            "venue-info-dist-col" in td_class
                        ):  # skip distance column if we're looking at height
                            continue
                stat_name = index_to_stat_mapping.get(i)
                if stat_name:
                    table_data[stat_name].append(td.text.strip())
                    i += 1
    df = pl.DataFrame(table_data)
    # renaming columns
    if metric == "distance":
        df = df.rename(
            {
                "LF Line": "lf_line_distance_ft",
                "LF Gap": "lf_gap_distance_ft",
                "CF": "cf_distance_ft",
                "RF Gap": "rf_gap_distance_ft",
                "RF Line": "rf_line_distance_ft",
                "DeepestPointDeepest point of park. May or may not be one of 5 standard points displayed.": "deepest_point_distance_ft",
                "Playing FieldArea (sq. ft.)Fair Territory Only": "playing_field_area_sq_ft",
                "Avg. Fence  Distance": "avg_fence_distance_ft",
                "Avg. Fence Height": "avg_fence_height_ft",
                "Avg. HREstimated by averaging the (fence distance + fence height) throughout the entire outfield.": "avg_hr_distance_ft",
            }
        )
        df = df.with_columns(
            pl.all().str.replace(r"\([-+]\s*\d+\)", "").str.strip_chars_end(" ")
            # .cast(pl.Int64)
        )
        df = df.with_columns(
            pl.col("playing_field_area_sq_ft")
            .str.replace(r",", "")
            .str.replace(r"\s*\([-+]?\d+\.?\d*%\)", "")
            .cast(pl.Int64)
        )
        int_columns = [
            "lf_line_distance_ft",
            "lf_gap_distance_ft",
            "cf_distance_ft",
            "rf_gap_distance_ft",
            "rf_line_distance_ft",
            "deepest_point_distance_ft",
            "playing_field_area_sq_ft",
            "avg_fence_distance_ft",
            "avg_hr_distance_ft",
            "Season",
        ]
        float_columns = ["avg_fence_height_ft"]
        df = df.with_columns(
            pl.col(int_columns).cast(pl.Int64),
            pl.col(float_columns).cast(pl.Float64),
        )
    elif metric == "height":
        df = df.rename(
            {
                "LF Line": "lf_line_height_ft",
                "LF Gap": "lf_gap_height_ft",
                "CF": "cf_height_ft",
                "RF Gap": "rf_gap_height_ft",
                "RF Line": "rf_line_height_ft",
                "HighestPointHighest height of the fence. May or may not be one of 5 standard points displayed.": "highest_point_height_ft",
                "Playing FieldArea (sq. ft.)Fair Territory Only": "playing_field_area_sq_ft",
                "Avg. Fence  Distance": "avg_fence_distance_ft",
                "Avg. Fence Height": "avg_fence_height_ft",
                "Avg. HREstimated by averaging the (fence distance + fence height) throughout the entire outfield.": "avg_hr_distance_ft",
            }
        )
        df = df.with_columns(
            pl.all().str.replace(r"\([-+]\s*\d+\)", "").str.strip_chars_end(" ")
            # .cast(pl.Int64)
        )
        df = df.with_columns(
            pl.col("playing_field_area_sq_ft")
            .str.replace(r",", "")
            .str.replace(r"\s*\([-+]?\d+\.?\d*%\)", "")
            .cast(pl.Int64)
        )
        int_columns = [
            "lf_line_height_ft",
            "lf_gap_height_ft",
            "cf_height_ft",
            "rf_gap_height_ft",
            "rf_line_height_ft",
            "highest_point_height_ft",
            "playing_field_area_sq_ft",
            "avg_fence_distance_ft",
            "avg_hr_distance_ft",
            "Season",
        ]
        float_columns = ["avg_fence_height_ft"]
        df = df.with_columns(
            pl.col(int_columns).cast(pl.Int64),
            pl.col(float_columns).cast(pl.Float64),
        )
    return df


def park_factor_yearly_leaderboard(
    season: int,
    bat_side: Literal["L", "R", ""] = "",
    conditions: Literal["All", "Day", "Night", "Open Air", "Roof Closed"] = "All",
    rolling_years: int = 3,  # 1,2,3
) -> pl.DataFrame:
    """Return Baseball Savant park-factor leaderboard data.

    Args:
        season (int): Season year.
        bat_side (Literal["L", "R", ""], optional): Batter-side filter.
        conditions (Literal["All", "Day", "Night", "Open Air", "Roof Closed"], optional):
            Game-condition filter.
        rolling_years (int, optional): Rolling-year window.

    Raises:
        ValueError: If ``bat_side`` is invalid.
        ValueError: If ``conditions`` is invalid.
        ValueError: If ``rolling_years`` is not 1, 2, or 3.
        ValueError: If ``season`` is outside valid supported years.

    Returns:
        pl.DataFrame: Park-factor leaderboard data.
    """
    if bat_side not in ["L", "R", ""]:
        raise ValueError("bat_side must be 'L', 'R', or ''")
    if conditions not in ["All", "Day", "Night", "Open Air", "Roof Closed"]:
        raise ValueError(
            "conditions must be one of 'All', 'Day', 'Night', 'Open Air', or 'Roof Closed'"
        )
    if rolling_years not in [1, 2, 3]:
        raise ValueError("rolling_years must be 1, 2, or 3")
    curr_season = (
        datetime.now().year if datetime.now().month >= 3 else datetime.now().year - 1
    )
    if season < 1999 or season > curr_season:
        raise ValueError(f"Season must be between 1999 and {curr_season}")

    url = PARK_FACTOR_YEARLY_URL.format(
        season=season,
        bat_side=bat_side,
        condition=conditions,
        rolling_years=rolling_years,
    )
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        try:
            page.goto(url)
            page.wait_for_selector("#parkFactors")

            table_html = page.inner_html("#parkFactors")
        finally:
            page.close()
            browser.close()

    table_soup = BeautifulSoup(table_html, "html.parser")

    table = table_soup.find("table")
    assert table is not None, "Could not find data table on page"
    table_data: dict[str, list[str | None]] = {}
    index_to_stat_mapping = {}
    thead = table.find("thead")
    assert thead is not None, "Could not find table header element"
    for tr in thead.find_all("tr"):
        tr_class = tr.get("class")
        if tr_class != ["tr-component-row"]:
            continue
        for th in tr.find_all("th"):
            if th.text.strip() == "Rk.":
                continue
            table_data[th.text.strip()] = []
            index_to_stat_mapping[len(table_data) - 1] = th.text.strip()
    tbody = table.find("tbody")
    assert tbody is not None, "Could not find table body element"
    for row in tbody.find_all("tr"):
        row_class = row.get("class")
        if (
            not row_class
            or not isinstance(row_class, list)
            or "default-table-row" not in row_class
        ):  # skip non-data rows
            continue
        i = 0
        for td in row.find_all("td"):
            td_class = td.get("class")
            if td_class is None:
                continue  # skip if no class attribute
            if not isinstance(td_class, list):
                continue
            if "tr-data" in td_class:
                stat_name = index_to_stat_mapping.get(i)
                if stat_name:
                    table_data[stat_name].append(
                        td.text.strip() if td.text.strip() != "" else None
                    )
                    i += 1
    df = pl.DataFrame(table_data)
    df = df.with_columns(
        pl.col(list(set(df.columns) - {"Team", "Year", "Venue", "PA"})).cast(pl.Int64)
    )
    return df


def park_factor_distance_leaderboard(season: int) -> pl.DataFrame:
    """Return Baseball Savant park-factor distance leaderboard data.

    Args:
        season (int): Season year.

    Raises:
        ValueError: If ``season`` is outside valid supported years.

    Returns:
        pl.DataFrame: Park-factor distance leaderboard data.
    """
    curr_season = (
        datetime.now().year if datetime.now().month >= 3 else datetime.now().year - 1
    )
    if season < 2016 or season > curr_season:
        raise ValueError(f"Season must be between 2016 and {curr_season}")

    url = PARK_FACTOR_DISTANCE_URL.format(season=season)
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        try:
            page.goto(url)
            page.wait_for_selector("#parkFactors")

            table_html = page.inner_html("#parkFactors")
        finally:
            page.close()
            browser.close()

    table_soup = BeautifulSoup(table_html, "html.parser")
    thead = table_soup.find("thead")
    assert thead is not None, "Could not find table header element"
    table_data: dict[str, list[str | None]] = {}
    index_to_stat_mapping = {}
    for tr in thead.find_all("tr", {"class": "tr-component-row"}):
        for th in tr.find_all("th"):
            if th.text.strip() == "Rk.":
                continue
            if th.text.strip() == "Elev" and "Elev" in table_data:
                col_name = "Elevation"
            else:
                col_name = th.text.strip()
            table_data[col_name] = []
            index_to_stat_mapping[len(table_data) - 1] = col_name
    tbody = table_soup.find("tbody")
    assert tbody is not None, "Could not find table body element"

    for row in tbody.find_all("tr"):
        row_class = row.get("class")
        if (
            not row_class
            or not isinstance(row_class, list)
            or "default-table-row" not in row_class
        ):  # skip non-data rows
            continue
        i = 0
        for td in row.find_all("td"):
            td_class = td.get("class")
            if td_class is None:
                continue  # skip if no class attribute
            if not isinstance(td_class, list):
                continue
            if "tr-data" not in td_class:
                continue
            stat_name = index_to_stat_mapping.get(i)
            if stat_name:
                table_data[stat_name].append(
                    td.text.strip() if td.text.strip() != "" else None
                )
                i += 1
    df = pl.DataFrame(table_data)
    df = df.rename(
        {
            "Total": "total_extra_distance_ft",
            "Temp": "extra_distance_temp_effect_ft",
            "Elev": "extra_distance_elevation_effect_ft",
            "Env": "extra_distance_environment_effect_ft",
            "Roof": "extra_distance_roof_effect_ft",
            "Avg Temp": "avg_stadium_temperature_f",
            "Elevation": "stadium_elevation_ft",
            "Roof %": "pct_stadium_roofed",
            "Day %": "pct_stadium_day_games",
        }
    )
    int_cols = [
        "stadium_elevation_ft",
        "pct_stadium_roofed",
        "pct_stadium_day_games",
    ]
    float_cols = [
        "total_extra_distance_ft",
        "extra_distance_temp_effect_ft",
        "extra_distance_elevation_effect_ft",
        "extra_distance_environment_effect_ft",
        "extra_distance_roof_effect_ft",
        "avg_stadium_temperature_f",
    ]
    df = df.with_columns(
        pl.col(int_cols).str.replace(r",", "").cast(pl.Int64),
        pl.col(float_cols).str.replace(r",", "").cast(pl.Float64),
    )
    return df


def timer_infractions_leaderboard(
    season: int,
    perspective: Literal["Pit", "Bat", "Cat", "Team"] = "Pit",
    min_pitches: int = 1,
) -> pl.DataFrame:
    """Return Baseball Savant pitch-timer infraction leaderboard data.

    Args:
        season (int): Season year.
        perspective (Literal["Pit", "Bat", "Cat", "Team"], optional):
            Leaderboard perspective.
        min_pitches (int, optional): Minimum pitch-count threshold.

    Raises:
        ValueError: If ``perspective`` is invalid.
        ValueError: If ``min_pitches`` is less than 1.
        ValueError: If ``season`` is outside valid supported years.

    Returns:
        pl.DataFrame: Timer-infraction leaderboard data.
    """
    if perspective not in ["Pit", "Bat", "Cat", "Team"]:
        raise ValueError("perspective must be one of 'Pit', 'Bat', 'Cat', or 'Team'")
    if min_pitches < 1:
        raise ValueError("min_pitches must be at least 1")
    curr_season = (
        datetime.now().year if datetime.now().month >= 3 else datetime.now().year - 1
    )
    if season < 2023 or season > curr_season:
        raise ValueError(f"Season must be between 2023 and {curr_season}")

    resp = requests.get(
        TIMER_INFRACTIONS_LEADERBOARD_URL.format(
            perspective=perspective, season=season, min_pitches=min_pitches
        )
    )
    df = pl.read_csv(io.StringIO(resp.text))
    df = df.rename(
        {
            "entity_name": "player_name"
            if perspective in ["Pit", "Bat", "Cat"]
            else "team_name",
            "entity_id": "player_id"
            if perspective in ["Pit", "Bat", "Cat"]
            else "team_id",
        }
    )
    return df


def arm_strength_leaderboard(
    stat_type: Literal["player", "team"] = "player",
    year: int | str = 2025,  # All for all years (9999) is passed in
    min_throws: int = 50,
    pos: Literal[
        "All", "2b_ss_3b", "outfield", "1b", "2b", "3b", "shortstop", "lf", "cf", "rf"
    ] = "All",
    team: StatcastLeaderboardsTeams | None = None,
) -> pl.DataFrame:
    """Return Baseball Savant arm-strength leaderboard data.

    Args:
        stat_type (Literal["player", "team"], optional): Aggregate by player or team.
        year (int | str, optional): Season year, or ``"All"`` for all available years.
        min_throws (int, optional): Minimum throw threshold.
        pos (Literal[...], optional): Position group filter.
        team (StatcastLeaderboardsTeams | None, optional): Optional team filter.

    Raises:
        ValueError: If ``stat_type`` is invalid.
        ValueError: If ``year`` is invalid.
        ValueError: If ``min_throws`` is less than 1.
        ValueError: If ``pos`` is invalid.
        ValueError: If ``team`` is not ``None`` or ``StatcastLeaderboardsTeams``.

    Returns:
        pl.DataFrame: Arm-strength leaderboard data.
    """
    if stat_type not in ["player", "team"]:
        raise ValueError("stat_type must be either 'player' or 'team'")
    if isinstance(year, int) and (year < 2020 or year > datetime.now().year):
        raise ValueError(f"year must be between 2020 and {datetime.now().year}")

    if isinstance(year, str) and year != "All":
        raise ValueError(
            "year must be an integer between 2020 and the current year, or 'All'"
        )
    if isinstance(year, str) and year == "All":
        year = 9999

    if min_throws < 1:
        raise ValueError("min_throws must be at least 1")
    if pos not in ARM_STRENGTH_POS_INPUT_MAP.keys():
        raise ValueError(
            f"pos must be one of {list(ARM_STRENGTH_POS_INPUT_MAP.keys())}"
        )
    if team is not None and not isinstance(team, StatcastLeaderboardsTeams):
        raise ValueError(
            "team must be an instance of StatcastLeaderboardsTeams or None"
        )
    team_value = team.value if team is not None else ""
    url = ARM_STRENGTH_LEADERBOARD_URL.format(
        stat_type=stat_type,
        year=year,
        min_throws=min_throws,
        pos=ARM_STRENGTH_POS_INPUT_MAP[pos],
        team=team_value,
    )
    resp = requests.get(url)
    df = pl.read_csv(io.StringIO(resp.text), truncate_ragged_lines=True)
    if stat_type == "player":
        df = df.drop(["team_name"])
    if stat_type == "team":
        df = df.drop(
            [
                "fielder_name",
                "player_id",
                "primary_position",
                "primary_position_name",
                "total_throws",
                "total_throws_inf",
                "total_throws_of",
                "arm_inf",
                "arm_of",
            ]
        )
    return df
