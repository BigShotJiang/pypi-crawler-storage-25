"""Utility helpers for MCPFuzz."""
