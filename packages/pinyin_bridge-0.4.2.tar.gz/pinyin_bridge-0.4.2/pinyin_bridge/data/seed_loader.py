"""Seed data loader. Only approved entries are ever returned — draft and deprecated
entries are intentionally invisible to callers. Use review_candidates for pre-approval
work and seed_status for auditing."""

from __future__ import annotations

import csv
from dataclasses import dataclass
from functools import lru_cache
from importlib import resources

from pinyin_bridge.data._pinyin_util import default_phrase_pinyin, normalize_pinyin_text

SEED_FILES = (
    "core_words.tsv",
    "manual_reviewed.tsv",
    "polyphonic_words.tsv",
    "places.tsv",
    "part1_characters_new.tsv",
    "part2_phrases_new.tsv",
    "hsk_vocab.tsv",
)
EXPECTED_HEADERS = ("text", "pinyin", "category", "priority", "source", "review_status", "source_ref", "notes")
ALLOWED_REVIEW_STATUSES = {"approved", "draft", "deprecated"}


@dataclass(frozen=True)
class SeedEntry:
    text: str
    pinyin: str
    category: str
    priority: int
    source: str
    review_status: str
    source_ref: str
    notes: str
    default_pinyin: str
    filename: str


# Aliases — shared utility provides the actual implementations
_pinyin = normalize_pinyin_text
_pdefault = default_phrase_pinyin


def _read_seed_file(filename: str) -> list[SeedEntry]:
    package_root = resources.files("pinyin_bridge.data")
    path = package_root.joinpath("seed", filename)
    rows: list[SeedEntry] = []
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        headers = tuple(reader.fieldnames or ())
        if headers != EXPECTED_HEADERS:
            raise ValueError(f"{filename}: expected headers {EXPECTED_HEADERS}, got {headers}")

        for line_number, row in enumerate(reader, start=2):
            text = (row["text"] or "").strip()
            category = (row["category"] or "").strip()
            source = (row["source"] or "").strip()
            review_status = (row["review_status"] or "").strip()
            source_ref = (row["source_ref"] or "").strip()
            notes = (row["notes"] or "").strip()
            if not text:
                raise ValueError(f"{filename}:{line_number}: text must not be empty")
            if not category:
                raise ValueError(f"{filename}:{line_number}: category must not be empty")
            if not source:
                raise ValueError(f"{filename}:{line_number}: source must not be empty")
            if review_status not in ALLOWED_REVIEW_STATUSES:
                raise ValueError(
                    f"{filename}:{line_number}: review_status must be one of {sorted(ALLOWED_REVIEW_STATUSES)}"
                )
            if review_status == "approved" and not source_ref:
                raise ValueError(f"{filename}:{line_number}: approved entries must provide source_ref")

            try:
                priority = int((row["priority"] or "").strip())
            except ValueError as exc:
                raise ValueError(f"{filename}:{line_number}: priority must be an integer") from exc
            if priority <= 0:
                raise ValueError(f"{filename}:{line_number}: priority must be greater than 0")

            pinyin = _pinyin((row["pinyin"] or "").strip())
            if len(text) != len(pinyin.split()):
                raise ValueError(
                    f"{filename}:{line_number}: text length {len(text)} does not match syllable count {len(pinyin.split())}"
                )
            default_pinyin = _pdefault(text)
            if review_status == "approved" and pinyin != default_pinyin and not notes:
                raise ValueError(
                    f"{filename}:{line_number}: approved override differs from pypinyin ({default_pinyin}) and requires notes"
                )

            rows.append(
                SeedEntry(
                    text=text,
                    pinyin=pinyin,
                    category=category,
                    priority=priority,
                    source=source,
                    review_status=review_status,
                    source_ref=source_ref,
                    notes=notes,
                    default_pinyin=default_pinyin,
                    filename=filename,
                )
            )
    return rows


@lru_cache(maxsize=1)
def load_seed_entries() -> tuple[SeedEntry, ...]:
    """Return only approved seed entries. Draft and deprecated entries are invisible to callers.

    Use load_review_candidates() for pre-approval candidates and
    seed_status.build_seed_status_report() for auditing.
    """
    chosen: dict[str, SeedEntry] = {}
    for filename in SEED_FILES:
        for entry in _read_seed_file(filename):
            if entry.review_status != "approved":
                continue
            current = chosen.get(entry.text)
            if current is None or entry.priority > current.priority:
                chosen[entry.text] = entry
                continue
            if entry.priority == current.priority and entry.pinyin != current.pinyin:
                raise ValueError(
                    f"Conflicting seed entries for {entry.text!r} with the same priority: "
                    f"{current.filename}={current.pinyin!r}, {entry.filename}={entry.pinyin!r}"
                )
    return tuple(sorted(chosen.values(), key=lambda item: (-item.priority, item.text)))


def clear_seed_cache():
    load_seed_entries.cache_clear()
    load_seed_phrase_entries.cache_clear()


@lru_cache(maxsize=1)
def load_seed_phrase_entries() -> dict[str, tuple[str, str]]:
    """All entries returned by load_seed_entries() are already approved."""
    return {
        entry.text: (entry.pinyin, f"seed:{entry.category}")
        for entry in load_seed_entries()
    }
