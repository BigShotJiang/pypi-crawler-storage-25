from __future__ import annotations

from typing import Any, Dict, List

from pinyin_bridge.core.analyzer import TextAnalysis, analyze as analyze_text
from pinyin_bridge.core.classifier import classify as classify_text
from pinyin_bridge.core.formatter import PinyinValue, pinyin_list
from pinyin_bridge.core.reverse import clear_reverse_cache, reverse as reverse_text
from pinyin_bridge.core import tokenizer
from pinyin_bridge.data import db

__version__ = "0.2.0"


def _invalidate_runtime_caches():
    tokenizer.clear_phrase_cache()
    clear_reverse_cache()


def analyze(text: str, *, segment: bool = True, heteronym: bool = False) -> TextAnalysis:
    return analyze_text(text, segment=segment, heteronym=heteronym)


def pinyin(
    text: str,
    *,
    style: str = "plain",
    unit: str = "char",
    segment: bool = True,
    heteronym: bool = False,
) -> List[PinyinValue]:
    return pinyin_list(
        analyze_text(text, segment=segment, heteronym=heteronym),
        style=style,
        unit=unit,
        heteronym=heteronym,
    )


def classify(text: str, *, kind: str = "all", segment: bool = True) -> Dict[str, Any] | List[Dict[str, Any]]:
    return classify_text(text, kind=kind, segment=segment)


def segment(text: str) -> List[str]:
    return tokenizer.segment(text)


def reverse(query: str, *, tone: str = "auto", scope: str = "all") -> List[Dict[str, str]]:
    return reverse_text(query, tone=tone, scope=scope)


def warmup():
    """预热库，加载所有数据到内存，加速首次调用"""
    return tokenizer.warmup()


def add_words(words, source: str = "user"):
    if isinstance(words, dict):
        words = list(words.items())
    db.add_words(words, source)
    _invalidate_runtime_caches()


def add_word(text: str, pinyin: str, source: str = "user"):
    db.add_word(text, pinyin, source)
    _invalidate_runtime_caches()


def delete_word(text: str, source: str = "user"):
    db.delete_word(text, source)
    _invalidate_runtime_caches()


def list_words(source: str = "user") -> List[Dict[str, str]]:
    return db.get_db().get_all_words(source)


def clear_words():
    db.clear_user_dict()
    _invalidate_runtime_caches()


__all__ = [
    "__version__",
    "add_word",
    "add_words",
    "analyze",
    "classify",
    "clear_words",
    "delete_word",
    "list_words",
    "pinyin",
    "reverse",
    "segment",
]
