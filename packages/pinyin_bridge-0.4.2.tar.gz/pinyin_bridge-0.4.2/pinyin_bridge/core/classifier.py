from __future__ import annotations

from typing import Any, Dict, List

from pinyin_bridge.core.analyzer import TextAnalysis, analyze
from pinyin_bridge.core.formatter import render_pronunciation
from pinyin_bridge.core.rules import FINAL_CATEGORIES, INITIAL_CATEGORIES, TONE_NAMES


def group_by_attr(analysis: TextAnalysis, attr: str, categories: Dict[str, List[str]]) -> List[Dict[str, Any]]:
    grouped = []
    for name, values in categories.items():
        detail = []
        for token in analysis.tokens:
            for char in token.chars:
                if char.chosen and getattr(char.chosen, attr) in values:
                    detail.append([char.char, render_pronunciation(char.chosen, "mark")])
        grouped.append({"name": name, "detail": detail})
    return grouped


def group_tones(analysis: TextAnalysis) -> List[Dict[str, Any]]:
    grouped = [{"name": label, "detail": []} for _, label in sorted(TONE_NAMES.items())]
    for token in analysis.tokens:
        for char in token.chars:
            if char.chosen and char.chosen.tone in TONE_NAMES:
                grouped[char.chosen.tone - 1]["detail"].append([char.char, render_pronunciation(char.chosen, "mark")])
    return grouped


def classify(text: str, *, kind: str = "all", segment: bool = True) -> Dict[str, Any] | List[Dict[str, Any]]:
    analysis = analyze(text, segment=segment)
    initials = group_by_attr(analysis, "initial", INITIAL_CATEGORIES)
    finals = group_by_attr(analysis, "final", FINAL_CATEGORIES)
    tones = group_tones(analysis)

    if kind == "initial":
        return initials
    if kind == "final":
        return finals
    if kind == "tone":
        return tones
    if kind == "all":
        return {"声母": initials, "韵母": finals, "声调": tones}
    raise ValueError(f"Unsupported kind: {kind}")
