# Kora IDV Python SDK

Official Python SDK for the [Kora IDV](https://korastratum.com/products/koraidv) identity verification API. Zero runtime dependencies — built on Python's standard library.

## Installation

```bash
pip install koraidv
```

Requires Python 3.10+.

## Quick start

```python
from koraidv import KoraIDVClient, VerificationTier

client = KoraIDVClient(
    api_key="kora_sandbox_xxxxx",
    tenant_id="your-tenant-uuid",
)

# Create a verification — the client SDK will use this externalId to launch
# the mobile or web flow on the user's device.
verification = client.create_verification(
    external_id="user-42",
    tier=VerificationTier.STANDARD,
)
print(verification.id, verification.status)

# Poll or fetch by ID
fetched = client.get_verification(verification.id)
print(fetched.scores.overall)
```

## Webhooks

Verify the HMAC-SHA256 signature on every event your endpoint receives:

```python
from koraidv import verify_webhook_signature, parse_webhook_payload

def handle_webhook(request):
    body = request.body  # raw bytes
    signature = request.headers["X-Korastratum-Signature"]

    if not verify_webhook_signature(body, signature, secret="whsec_xxx"):
        return 401

    event = parse_webhook_payload(body)
    if event.event_type == "verification.completed":
        process_verification(event.data)
    return 200
```

## Documentation

Full API reference and integration guides at
**[docs.korastratum.com/idv](https://docs.korastratum.com/idv)**.

Other Kora IDV SDKs:
- [`@koraidv/node`](https://www.npmjs.com/package/@koraidv/node) — Node.js / TypeScript
- [`koraidv-go`](https://github.com/badedokun/koraidv/tree/main/packages/go-sdk) — Go server SDK
- [`@koraidv/react-native`](https://www.npmjs.com/package/@koraidv/react-native) — React Native client
- [`@koraidv/core`](https://www.npmjs.com/package/@koraidv/core), [`@koraidv/react`](https://www.npmjs.com/package/@koraidv/react) — Web client

## License

MIT
