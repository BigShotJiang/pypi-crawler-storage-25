"""Webhook signature verification and payload parsing.

Uses ``hmac`` and ``hashlib`` from the standard library for HMAC-SHA256
signature verification with constant-time comparison.
"""

from __future__ import annotations

import hashlib
import hmac
import json
from typing import Union

from .types import WebhookPayload


def verify_webhook_signature(
    payload: bytes,
    signature: str,
    secret: str,
) -> bool:
    """Verify an HMAC-SHA256 webhook signature.

    The signature is the hex-encoded HMAC-SHA256 digest of *payload* using
    *secret* as the key.  Comparison is done in constant time via
    :func:`hmac.compare_digest` to prevent timing attacks.

    Args:
        payload:   Raw request body bytes.
        signature: The ``X-Signature`` header value (hex-encoded).
        secret:    The webhook signing secret.

    Returns:
        ``True`` if the signature is valid, ``False`` otherwise.
    """
    expected = hmac.new(
        secret.encode("utf-8"),
        payload,
        hashlib.sha256,
    ).hexdigest()

    return hmac.compare_digest(expected, signature)


def parse_webhook_payload(body: Union[str, bytes]) -> WebhookPayload:
    """Parse a webhook request body into a :class:`WebhookPayload`.

    Args:
        body: The raw request body as ``str`` or ``bytes``.

    Returns:
        A :class:`WebhookPayload` dataclass instance.

    Raises:
        ValueError: If *body* is not valid JSON.
    """
    if isinstance(body, bytes):
        body = body.decode("utf-8")

    try:
        data = json.loads(body)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid webhook payload JSON: {exc}") from exc

    return WebhookPayload.from_dict(data)
