"""Auth module tests."""
