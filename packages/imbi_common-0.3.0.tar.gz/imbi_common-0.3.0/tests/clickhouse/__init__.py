# Tests for ClickHouse client
