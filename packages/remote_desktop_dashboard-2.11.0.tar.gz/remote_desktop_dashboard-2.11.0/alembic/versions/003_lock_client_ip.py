"""Add lock_client_ip for RDP firewall guard

Revision ID: 003
Revises: 002
Create Date: 2026-05-15

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "003"
down_revision: Union[str, None] = "002"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table("machines") as batch_op:
        batch_op.add_column(sa.Column("lock_client_ip", sa.String(length=45), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table("machines") as batch_op:
        batch_op.drop_column("lock_client_ip")
