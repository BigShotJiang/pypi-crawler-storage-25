"""Initial machines table

Revision ID: 001
Revises:
Create Date: 2026-05-15

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "machines",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("name", sa.String(length=32), nullable=False),
        sa.Column("hostname", sa.String(length=255), nullable=False),
        sa.Column("ip_address", sa.String(length=45), nullable=False),
        sa.Column("is_online", sa.Boolean(), nullable=False, server_default="0"),
        sa.Column("last_seen", sa.DateTime(timezone=True), nullable=True),
        sa.Column("local_user", sa.String(length=128), nullable=True),
        sa.Column("rdp_users", sa.Text(), nullable=False, server_default="[]"),
        sa.Column("windows_app_users", sa.Text(), nullable=False, server_default="[]"),
        sa.Column("mobaxterm_user", sa.String(length=128), nullable=True),
        sa.Column("com_port_user", sa.String(length=128), nullable=True),
        sa.Column("etgui_user", sa.String(length=128), nullable=True),
        sa.Column("camera_user", sa.String(length=128), nullable=True),
        sa.Column("camera_tools", sa.Text(), nullable=False, server_default="[]"),
        sa.Column("agent_version", sa.String(length=32), nullable=True),
        sa.Column("raw_report", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("(CURRENT_TIMESTAMP)"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("(CURRENT_TIMESTAMP)"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_machines_name"), "machines", ["name"], unique=True)


def downgrade() -> None:
    op.drop_index(op.f("ix_machines_name"), table_name="machines")
    op.drop_table("machines")
