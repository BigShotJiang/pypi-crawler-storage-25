"""Add dashboard session lock columns

Revision ID: 002
Revises: 001
Create Date: 2026-05-15

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "002"
down_revision: Union[str, None] = "001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table("machines") as batch_op:
        batch_op.add_column(sa.Column("locked_by", sa.String(length=128), nullable=True))
        batch_op.add_column(sa.Column("locked_at", sa.DateTime(timezone=True), nullable=True))
        batch_op.add_column(
            sa.Column("lock_heartbeat_at", sa.DateTime(timezone=True), nullable=True)
        )
        batch_op.add_column(
            sa.Column("lock_rdp_username", sa.String(length=256), nullable=True)
        )
        batch_op.create_index("ix_machines_locked_by", ["locked_by"], unique=False)


def downgrade() -> None:
    with op.batch_alter_table("machines") as batch_op:
        batch_op.drop_index("ix_machines_locked_by")
        batch_op.drop_column("lock_rdp_username")
        batch_op.drop_column("lock_heartbeat_at")
        batch_op.drop_column("locked_at")
        batch_op.drop_column("locked_by")
