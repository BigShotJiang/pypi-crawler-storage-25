"""Stable paths for SQLite DB and secrets (works from any working directory)."""

from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path

from remote_desktop_dashboard.config import get_settings

logger = logging.getLogger(__name__)

DB_FILENAME = "remote_desktop_dashboard.db"


def default_data_dir() -> Path:
    """Writable per-user folder (safe for scheduled task / different cwd)."""
    local = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
    if local:
        return Path(local) / "RemoteDesktopDashboard"
    return Path.home() / "RemoteDesktopDashboard"


def resolve_data_dir() -> Path:
    settings = get_settings()
    configured = (settings.data_dir or "").strip()
    if configured:
        path = Path(configured).expanduser()
    else:
        path = default_data_dir()
    path = path.resolve()
    try:
        path.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise RuntimeError(
            f"Cannot create dashboard data folder {path}: {exc}. "
            f"Set RDD_DATA_DIR to a writable path."
        ) from exc
    return path


def _parse_sqlite_path(database_url: str) -> Path | None:
    if not database_url.startswith("sqlite"):
        return None
    raw = database_url.removeprefix("sqlite:///").removeprefix("sqlite://")
    raw = raw.strip()
    if not raw:
        return None
    # Windows: sqlite:///C:/path or sqlite:///./file.db
    if raw.startswith("./"):
        raw = raw[2:]
    return Path(raw)


def resolve_database_file() -> Path:
    """Absolute path to the SQLite file; directory is created if needed."""
    settings = get_settings()
    data_dir = resolve_data_dir()
    parsed = _parse_sqlite_path(settings.database_url)

    if parsed is not None and parsed.is_absolute():
        db_path = parsed.resolve()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        return db_path

    if parsed is not None and parsed.name:
        db_path = (data_dir / parsed.name).resolve()
    else:
        db_path = (data_dir / DB_FILENAME).resolve()

    db_path.parent.mkdir(parents=True, exist_ok=True)
    _migrate_legacy_database(db_path)
    return db_path


def sqlite_url_for(path: Path) -> str:
    return "sqlite:///" + path.resolve().as_posix()


def resolve_database_url() -> str:
    return sqlite_url_for(resolve_database_file())


def secret_key_file() -> Path:
    return resolve_database_file().parent / ".rdd_secret_key"


def _migrate_legacy_database(target: Path) -> None:
    if target.is_file():
        return
    candidates: list[Path] = [
        Path.cwd() / DB_FILENAME,
        Path.cwd() / "data" / DB_FILENAME,
    ]
    pkg_root = Path(__file__).resolve().parent
    candidates.append(pkg_root.parent.parent / DB_FILENAME)

    for src in candidates:
        try:
            if not src.is_file():
                continue
            if src.resolve() == target.resolve():
                continue
            shutil.copy2(src, target)
            logger.info("Migrated database from %s to %s", src, target)
            wal = Path(str(src) + "-wal")
            shm = Path(str(src) + "-shm")
            if wal.is_file():
                shutil.copy2(wal, Path(str(target) + "-wal"))
            if shm.is_file():
                shutil.copy2(shm, Path(str(target) + "-shm"))
            return
        except OSError as exc:
            logger.warning("Could not migrate database from %s: %s", src, exc)
