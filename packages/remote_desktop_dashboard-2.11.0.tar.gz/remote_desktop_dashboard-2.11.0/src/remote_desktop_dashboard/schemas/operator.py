"""Operator preference API schemas."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field


class OperatorPreferenceRead(BaseModel):
    display_name: str
    rdp_username: str | None = None
    rdp_domain: str | None = None
    use_hostname: bool | None = None
    last_used_at: datetime | None = None

    model_config = {"from_attributes": True}


class OperatorPreferenceWrite(BaseModel):
    display_name: str = Field(..., min_length=1, max_length=128)
    rdp_username: str | None = Field(None, max_length=256)
    rdp_domain: str | None = Field(None, max_length=128)
    use_hostname: bool | None = None
