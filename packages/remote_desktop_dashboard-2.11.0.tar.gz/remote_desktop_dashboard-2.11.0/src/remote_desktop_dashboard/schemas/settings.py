"""Server settings API schemas."""

from pydantic import BaseModel, Field


class MonitorSettingsRead(BaseModel):
    configured: bool
    domain: str = ""
    username: str = ""
    password_set: bool = False
    source: str = "none"  # none | database | environment


class MonitorSettingsWrite(BaseModel):
    domain: str = ""
    username: str = Field(..., min_length=1)
    password: str | None = None
    admin_pin: str | None = None


class MonitorSettingsTest(BaseModel):
    host: str = Field(..., min_length=1)
    admin_pin: str | None = None
