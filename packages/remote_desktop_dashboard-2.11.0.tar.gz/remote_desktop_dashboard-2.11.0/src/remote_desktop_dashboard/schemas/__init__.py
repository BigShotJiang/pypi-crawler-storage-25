from remote_desktop_dashboard.schemas.machine import (
    MachineCreate,
    MachineRead,
    MachineStatusReport,
    MachineUpdate,
)

__all__ = [
    "MachineCreate",
    "MachineRead",
    "MachineStatusReport",
    "MachineUpdate",
]
