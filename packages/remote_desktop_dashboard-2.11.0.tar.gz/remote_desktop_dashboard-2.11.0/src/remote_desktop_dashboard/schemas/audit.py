"""Audit event API schemas."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel


class AuditEventRead(BaseModel):
    id: int
    created_at: datetime
    action: str
    machine_name: str | None = None
    operator: str | None = None
    detail: str | None = None
    client_ip: str | None = None

    model_config = {"from_attributes": True}
