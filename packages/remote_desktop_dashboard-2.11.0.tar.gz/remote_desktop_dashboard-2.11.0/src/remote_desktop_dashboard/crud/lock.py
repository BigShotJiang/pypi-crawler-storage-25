"""Machine lock CRUD for dashboard remote sessions."""

from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.models.machine import Machine

settings = get_settings()


class LockError(Exception):
    def __init__(self, message: str, locked_by: str | None = None) -> None:
        super().__init__(message)
        self.locked_by = locked_by


def normalize_operator(operator: str) -> str:
    return operator.strip()


def operators_match(a: str, b: str) -> bool:
    return normalize_operator(a).casefold() == normalize_operator(b).casefold()


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _aware(dt: datetime | None) -> datetime | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def is_lock_expired(machine: Machine) -> bool:
    """Expire stale locks quickly when heartbeats stop (abandoned browser tab)."""
    if not machine.locked_by:
        return True
    now = _now()
    hb = _aware(machine.lock_heartbeat_at)
    if hb is not None:
        return (now - hb).total_seconds() > settings.lock_heartbeat_grace_seconds
    locked_at = _aware(machine.locked_at)
    if locked_at is None:
        return True
    return (now - locked_at).total_seconds() > settings.lock_timeout_seconds


def clear_lock(machine: Machine) -> None:
    machine.locked_by = None
    machine.locked_at = None
    machine.lock_heartbeat_at = None
    machine.lock_rdp_username = None
    machine.lock_client_ip = None


def refresh_expired_locks(db: Session, *, remote_firewall: bool = True) -> list[Machine]:
    from remote_desktop_dashboard.config import get_settings
    from remote_desktop_dashboard.crud.machine import list_machines
    from remote_desktop_dashboard.services.dashboard import bench_host
    from remote_desktop_dashboard.services.rdp_guard import (
        clear_rdp_guard,
        schedule_clear_rdp_guard,
    )

    released: list[Machine] = []
    prefer_ip = get_settings().poll_prefer_ip
    for machine in list_machines(db):
        if machine.locked_by and is_lock_expired(machine):
            allow: list[str] = []
            if machine.lock_client_ip:
                allow.append(machine.lock_client_ip)
            host = bench_host(machine, prefer_ip=prefer_ip)
            if remote_firewall:
                try:
                    clear_rdp_guard(host, allow)
                except Exception:
                    pass
            else:
                schedule_clear_rdp_guard(host, allow)
            clear_lock(machine)
            released.append(machine)
    if released:
        db.commit()
    return released


def is_locked_by_other(machine: Machine, operator: str) -> bool:
    if not machine.locked_by or is_lock_expired(machine):
        return False
    return not operators_match(machine.locked_by, operator)


def acquire_lock(
    db: Session,
    machine: Machine,
    operator: str,
    rdp_username: str | None = None,
    force: bool = False,
    client_ip: str | None = None,
    *,
    skip_expired_refresh: bool = False,
) -> Machine:
    operator = normalize_operator(operator)
    if not operator:
        raise LockError("Operator name is required")

    if not skip_expired_refresh:
        refresh_expired_locks(db, remote_firewall=False)
    db.refresh(machine)

    if is_locked_by_other(machine, operator) and not force:
        raise LockError(
            f"Machine is in use by {machine.locked_by}. They must click Release first.",
            locked_by=machine.locked_by,
        )

    now = _now()
    machine.locked_by = operator
    machine.locked_at = now
    machine.lock_heartbeat_at = now
    if rdp_username:
        machine.lock_rdp_username = rdp_username.strip()
    if client_ip:
        machine.lock_client_ip = client_ip.strip()
    db.commit()
    db.refresh(machine)
    return machine


def admin_force_release(db: Session, machine: Machine) -> Machine:
    """Clear lock regardless of operator (admin action)."""
    clear_lock(machine)
    db.commit()
    db.refresh(machine)
    return machine


def heartbeat_lock(db: Session, machine: Machine, operator: str) -> Machine:
    operator = normalize_operator(operator)
    if not machine.locked_by:
        raise LockError("Machine is not locked")
    if not operators_match(machine.locked_by, operator):
        raise LockError(
            f"Machine is locked by {machine.locked_by}",
            locked_by=machine.locked_by,
        )
    machine.lock_heartbeat_at = _now()
    db.commit()
    db.refresh(machine)
    return machine


def release_lock(db: Session, machine: Machine, operator: str) -> Machine:
    operator = normalize_operator(operator)
    if not machine.locked_by:
        return machine
    if not operators_match(machine.locked_by, operator):
        raise LockError(
            f"Only {machine.locked_by} can release this lock",
            locked_by=machine.locked_by,
        )
    clear_lock(machine)
    db.commit()
    db.refresh(machine)
    return machine
