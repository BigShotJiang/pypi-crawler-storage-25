"""Audit-event CRUD."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from remote_desktop_dashboard.models.audit import AuditEvent


def log_event(
    db: Session,
    *,
    action: str,
    machine_name: str | None = None,
    operator: str | None = None,
    detail: str | None = None,
    client_ip: str | None = None,
) -> AuditEvent:
    """Record an audit event. Caller is responsible for db.commit()."""
    event = AuditEvent(
        action=action.strip()[:64],
        machine_name=(machine_name or None),
        operator=(operator or None),
        detail=(detail or None),
        client_ip=(client_ip or None),
    )
    db.add(event)
    return event


def list_events(
    db: Session,
    *,
    machine_name: str | None = None,
    action: str | None = None,
    operator: str | None = None,
    limit: int = 200,
) -> list[AuditEvent]:
    stmt = select(AuditEvent).order_by(AuditEvent.created_at.desc())
    if machine_name:
        stmt = stmt.where(AuditEvent.machine_name == machine_name)
    if action:
        stmt = stmt.where(AuditEvent.action == action)
    if operator:
        stmt = stmt.where(AuditEvent.operator == operator)
    stmt = stmt.limit(max(1, min(limit, 1000)))
    return list(db.execute(stmt).scalars())
