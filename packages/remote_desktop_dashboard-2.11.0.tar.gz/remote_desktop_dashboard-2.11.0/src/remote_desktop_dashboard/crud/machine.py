"""CRUD operations for machines."""

import json
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.models.machine import Machine
from remote_desktop_dashboard.schemas.machine import MachineCreate, MachineStatusReport, MachineUpdate

settings = get_settings()


def _dump_list(items: list[str]) -> str:
    return json.dumps(items)


def get_machine(db: Session, machine_id: int) -> Machine | None:
    return db.get(Machine, machine_id)


def get_machine_by_name(db: Session, name: str) -> Machine | None:
    stmt = select(Machine).where(Machine.name == name.upper())
    return db.execute(stmt).scalar_one_or_none()


def list_machines(db: Session) -> list[Machine]:
    stmt = select(Machine).order_by(Machine.name)
    return list(db.execute(stmt).scalars().all())


def upsert_machine(db: Session, data: MachineCreate) -> tuple[Machine, str]:
    """Create or update hostname/IP for an existing machine name."""
    existing = get_machine_by_name(db, data.name)
    if existing:
        existing.hostname = data.hostname
        existing.ip_address = data.ip_address
        if data.description is not None:
            existing.description = data.description
        if data.board is not None:
            existing.board = data.board
        if data.access_note is not None:
            existing.access_note = data.access_note
        db.commit()
        db.refresh(existing)
        return existing, "updated"
    machine = Machine(
        name=data.name.upper(),
        hostname=data.hostname,
        ip_address=data.ip_address,
        description=data.description,
        board=data.board,
        access_note=data.access_note,
    )
    db.add(machine)
    db.commit()
    db.refresh(machine)
    return machine, "created"


def create_machine(db: Session, data: MachineCreate) -> Machine:
    machine = Machine(
        name=data.name.upper(),
        hostname=data.hostname,
        ip_address=data.ip_address,
        description=data.description,
        board=data.board,
        access_note=data.access_note,
    )
    db.add(machine)
    db.commit()
    db.refresh(machine)
    return machine


def update_machine(db: Session, machine: Machine, data: MachineUpdate) -> Machine:
    if data.hostname is not None:
        machine.hostname = data.hostname.strip()
    if data.ip_address is not None:
        machine.ip_address = data.ip_address.strip()
    if data.description is not None:
        machine.description = data.description.strip() or None
    if data.board is not None:
        machine.board = data.board.strip() or None
    if data.access_note is not None:
        machine.access_note = data.access_note.strip() or None
    machine.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(machine)
    return machine


def delete_machine(db: Session, machine: Machine) -> None:
    db.delete(machine)
    db.commit()


def apply_status_report(db: Session, report: MachineStatusReport) -> Machine:
    machine = get_machine_by_name(db, report.machine_name)
    if machine is None:
        raise ValueError(f"Unknown machine: {report.machine_name}")

    now = datetime.now(timezone.utc)
    machine.is_online = True
    machine.last_seen = now
    machine.local_user = report.local_user
    machine.rdp_users = _dump_list(report.rdp_users)
    machine.windows_app_users = _dump_list(report.windows_app_users)
    machine.mobaxterm_user = report.mobaxterm_user
    machine.com_port_user = report.com_port_user
    machine.etgui_user = report.etgui_user
    machine.camera_user = report.camera_user
    machine.camera_tools = _dump_list(report.camera_tools)
    machine.agent_version = report.agent_version
    if report.raw_report is not None:
        machine.raw_report = json.dumps(report.raw_report)

    db.commit()
    db.refresh(machine)
    return machine


def mark_poll_failure(db: Session, machine_name: str, error: str) -> Machine | None:
    """Record poll error without clearing last successful snapshot."""
    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        return None
    machine.raw_report = json.dumps({"source": "remote_poller", "error": error})
    db.commit()
    db.refresh(machine)
    return machine


def refresh_online_flags(db: Session) -> list[Machine]:
    """Mark machines offline when last_seen exceeds threshold."""
    now = datetime.now(timezone.utc)
    changed: list[Machine] = []
    for machine in list_machines(db):
        if not machine.is_online or machine.last_seen is None:
            continue
        last = machine.last_seen
        if last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)
        age = (now - last).total_seconds()
        if age > settings.offline_threshold_seconds:
            machine.is_online = False
            changed.append(machine)
    if changed:
        db.commit()
    return changed
