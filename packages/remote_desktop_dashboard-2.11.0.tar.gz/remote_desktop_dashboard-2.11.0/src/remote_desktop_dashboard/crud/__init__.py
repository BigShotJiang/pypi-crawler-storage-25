from remote_desktop_dashboard.crud import machine as machine_crud

__all__ = ["machine_crud"]
