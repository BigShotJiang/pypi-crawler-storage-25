"""Operator preference CRUD."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from remote_desktop_dashboard.models.operator import OperatorPreference


def _key(name: str) -> str:
    return (name or "").strip().lower()


def get_operator_pref(db: Session, name: str) -> OperatorPreference | None:
    k = _key(name)
    if not k:
        return None
    stmt = select(OperatorPreference).where(OperatorPreference.name_key == k)
    return db.execute(stmt).scalar_one_or_none()


def upsert_operator_pref(
    db: Session,
    *,
    display_name: str,
    rdp_username: str | None = None,
    rdp_domain: str | None = None,
    use_hostname: bool | None = None,
) -> OperatorPreference:
    """Create or update an operator's stored RDP defaults. Caller commits."""
    k = _key(display_name)
    pref = db.execute(
        select(OperatorPreference).where(OperatorPreference.name_key == k)
    ).scalar_one_or_none()
    if pref is None:
        pref = OperatorPreference(
            name_key=k,
            display_name=display_name.strip(),
        )
        db.add(pref)
    else:
        pref.display_name = display_name.strip()

    if rdp_username is not None:
        pref.rdp_username = rdp_username.strip() or None
    if rdp_domain is not None:
        pref.rdp_domain = rdp_domain.strip() or None
    if use_hostname is not None:
        pref.use_hostname = "1" if use_hostname else "0"
    return pref


def list_operator_prefs(db: Session, limit: int = 50) -> list[OperatorPreference]:
    stmt = (
        select(OperatorPreference)
        .order_by(OperatorPreference.last_used_at.desc())
        .limit(limit)
    )
    return list(db.execute(stmt).scalars())
