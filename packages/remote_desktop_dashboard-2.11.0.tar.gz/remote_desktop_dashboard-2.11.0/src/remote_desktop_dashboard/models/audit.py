"""Audit events \u2014 append-only log of meaningful actions on the dashboard.

Used by the Audit Log tab. Written by the API layer (api/routes.py) on lock
acquisition, release, force-kick, admin overrides, agent install/uninstall,
and machine create/edit/delete. The dashboard never deletes rows from this
table; old rows can be pruned by the operator from the UI if needed.
"""

from datetime import datetime

from sqlalchemy import DateTime, Index, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from remote_desktop_dashboard.database import Base


class AuditEvent(Base):
    __tablename__ = "audit_events"
    __table_args__ = (
        Index("ix_audit_events_machine_ts", "machine_name", "created_at"),
        Index("ix_audit_events_action_ts", "action", "created_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), index=True
    )
    action: Mapped[str] = mapped_column(String(64))
    machine_name: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    operator: Mapped[str | None] = mapped_column(String(128), nullable=True)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    client_ip: Mapped[str | None] = mapped_column(String(45), nullable=True)
