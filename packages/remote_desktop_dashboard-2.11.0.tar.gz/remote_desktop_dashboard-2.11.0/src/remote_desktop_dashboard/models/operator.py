"""Operator preferences \u2014 remembers each operator's last-used RDP details
so they don't have to retype them every time.

Keyed by operator display-name (case-insensitive). This is not a security
boundary; it's a convenience store. The dashboard itself has no operator
authentication (anyone on the LAN can hit it), so do not treat these rows
as authoritative identity.
"""

from datetime import datetime

from sqlalchemy import DateTime, String, func
from sqlalchemy.orm import Mapped, mapped_column

from remote_desktop_dashboard.database import Base


class OperatorPreference(Base):
    __tablename__ = "operator_preferences"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    name_key: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    display_name: Mapped[str] = mapped_column(String(128))
    rdp_username: Mapped[str | None] = mapped_column(String(256), nullable=True)
    rdp_domain: Mapped[str | None] = mapped_column(String(128), nullable=True)
    use_hostname: Mapped[str | None] = mapped_column(String(8), nullable=True)
    last_used_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
