"""Key-value application settings (encrypted values)."""

from sqlalchemy import String, Text
from sqlalchemy.orm import Mapped, mapped_column

from remote_desktop_dashboard.database import Base


class AppSetting(Base):
    __tablename__ = "app_settings"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value_encrypted: Mapped[str] = mapped_column(Text, nullable=False)
