"""Background poller — agentless monitoring from the dashboard server."""

from __future__ import annotations

import asyncio
import logging
import sys
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone

from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.crud.machine import (
    apply_status_report,
    get_machine_by_name,
    list_machines,
    mark_poll_failure,
)
from remote_desktop_dashboard.database import SessionLocal
from remote_desktop_dashboard.schemas.machine import MachineStatusReport
from remote_desktop_dashboard.services.connection_manager import manager
from remote_desktop_dashboard.services.dashboard import machines_payload
from remote_desktop_dashboard.services.remote_users import probe_logged_in_users
from remote_desktop_dashboard.services.reachability_cache import get_cached_reachability

logger = logging.getLogger(__name__)

_db_write_lock = threading.Lock()
_poller_thread: threading.Thread | None = None
_stop_event = threading.Event()
_main_loop: asyncio.AbstractEventLoop | None = None
_last_cycle: datetime | None = None
_last_stats: dict = {"ok": 0, "fail": 0, "skipped": 0, "total": 0}


def set_event_loop(loop: asyncio.AbstractEventLoop) -> None:
    global _main_loop
    _main_loop = loop


def get_poller_stats() -> dict:
    return {
        "last_cycle": _last_cycle.isoformat() if _last_cycle else None,
        **_last_stats,
    }


def poll_single_machine(machine_name: str) -> tuple[bool, str | None]:
    """Poll one machine immediately (used after connect / refresh button)."""
    settings = get_settings()
    db = SessionLocal()
    try:
        machine = get_machine_by_name(db, machine_name)
        if machine is None:
            return False, "Machine not found"
        host = machine.ip_address if settings.poll_prefer_ip else machine.hostname
    finally:
        db.close()
    _name, ok, err = _poll_one(machine_name.upper(), host)
    _broadcast_dashboard()
    return ok, err


def _poll_one(machine_name: str, host: str) -> tuple[str, bool, str | None]:
    try:
        snap = probe_logged_in_users(host)
        report = MachineStatusReport(
            machine_name=machine_name,
            local_user=snap.local_user,
            rdp_users=snap.rdp_users,
            windows_app_users=[],
            mobaxterm_user=None,
            com_port_user=None,
            etgui_user=None,
            camera_user=None,
            camera_tools=[],
            agent_version="poller-users",
            raw_report=snap.raw,
        )
        with _db_write_lock:
            db = SessionLocal()
            try:
                apply_status_report(db, report)
            finally:
                db.close()
        return machine_name, True, None
    except Exception as exc:
        err = str(exc)
        with _db_write_lock:
            db = SessionLocal()
            try:
                mark_poll_failure(db, machine_name, err)
            finally:
                db.close()
        if "unreachable" in err.lower() or "skipped" in err.lower():
            logger.debug("Poll skipped for %s (%s): %s", machine_name, host, err)
        else:
            logger.warning("Poll failed for %s (%s): %s", machine_name, host, err)
        return machine_name, False, err


def _broadcast_dashboard() -> None:
    if _main_loop is None:
        return
    db = SessionLocal()
    try:
        from remote_desktop_dashboard.crud.lock import refresh_expired_locks
        from remote_desktop_dashboard.crud.machine import refresh_online_flags

        refresh_online_flags(db)
        refresh_expired_locks(db)
        updated = list_machines(db)
        reach = get_cached_reachability(updated, allow_refresh=False)
        payload = machines_payload(updated, reachability=reach)
    finally:
        db.close()
    asyncio.run_coroutine_threadsafe(manager.broadcast(payload), _main_loop)


def run_poll_cycle() -> None:
    global _last_cycle, _last_stats

    if sys.platform != "win32":
        logger.warning("Remote poller only runs on Windows; skipping cycle")
        return

    settings = get_settings()
    db = SessionLocal()
    try:
        machines = list_machines(db)
    finally:
        db.close()

    if not machines:
        return

    ok = 0
    fail = 0
    skipped = 0
    workers = max(1, min(len(machines), settings.poll_max_workers))

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {
            pool.submit(
                _poll_one,
                m.name,
                m.ip_address if settings.poll_prefer_ip else m.hostname,
            ): m
            for m in machines
        }
        for future in as_completed(futures):
            _name, success, err = future.result()
            if success:
                ok += 1
            elif err and ("unreachable" in err.lower() or "skipped" in err.lower()):
                skipped += 1
            else:
                fail += 1

    _last_cycle = datetime.now(timezone.utc)
    _last_stats = {"ok": ok, "fail": fail, "skipped": skipped, "total": len(machines)}
    logger.info(
        "Poll cycle: %s ok, %s fail, %s skipped / %s machines",
        ok,
        fail,
        skipped,
        len(machines),
    )
    _broadcast_dashboard()


def _poller_loop() -> None:
    settings = get_settings()
    interval = settings.poll_interval_seconds
    delay = settings.poll_startup_delay_seconds
    if not _stop_event.is_set():
        try:
            logger.info("Poller running initial cycle immediately")
            run_poll_cycle()
        except Exception:
            logger.exception("Initial poll cycle error")
    if delay > 0 and not _stop_event.is_set():
        logger.info("Poller waiting %ss before next cycle", delay)
        _stop_event.wait(delay)
    while not _stop_event.is_set():
        _stop_event.wait(interval)
        if _stop_event.is_set():
            break
        try:
            run_poll_cycle()
        except Exception:
            logger.exception("Poll cycle error")


def start_poller() -> bool:
    global _poller_thread

    import os

    if os.environ.get("RDD_POLLER_ENABLED", "").lower() in ("0", "false", "no"):
        logger.info("Poller disabled (RDD_POLLER_ENABLED=false)")
        return False

    settings = get_settings()
    if not settings.poller_enabled:
        return False
    if sys.platform != "win32":
        logger.warning(
            "Agentless poller requires a Windows dashboard server (domain-joined recommended)."
        )
        return False
    if _poller_thread and _poller_thread.is_alive():
        return True

    _stop_event.clear()
    _poller_thread = threading.Thread(target=_poller_loop, daemon=True, name="rdd-poller")
    _poller_thread.start()
    logger.info(
        "Agentless poller started (every %ss, %s workers, delay %ss)",
        settings.poll_interval_seconds,
        settings.poll_max_workers,
        settings.poll_startup_delay_seconds,
    )
    return True


def stop_poller() -> None:
    _stop_event.set()
