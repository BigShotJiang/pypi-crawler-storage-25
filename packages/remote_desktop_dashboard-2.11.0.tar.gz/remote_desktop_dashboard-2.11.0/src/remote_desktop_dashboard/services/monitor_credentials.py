"""Parse monitor credentials from DB settings or RDD_MONITOR_* env."""

from __future__ import annotations

from dataclasses import dataclass

from remote_desktop_dashboard.config import get_settings


@dataclass(frozen=True)
class MonitorCredentials:
    """Credentials for remote query / tasklist / WMI."""

    domain: str
    username: str
    password: str
    qualified: str

    def tasklist_user_arg(self) -> str:
        r"""Argument for tasklist /U (DOMAIN\user)."""
        return self.qualified

    def net_use_user_arg(self) -> str:
        r"""Argument for net use /user:DOMAIN\user."""
        return f"/user:{self.qualified}"


def _build_qualified(domain: str, username: str) -> tuple[str, str, str]:
    domain = (domain or "").strip()
    username = username.strip()

    if "\\" in username:
        domain, _, username = username.partition("\\")
        domain = domain.strip()
        username = username.strip()
    elif "/" in username:
        domain, _, username = username.partition("/")
        domain = domain.strip()
        username = username.strip()
    elif "@" in username:
        username, _, upn_suffix = username.partition("@")
        username = username.strip()
        if not domain and upn_suffix:
            domain = upn_suffix.split(".")[0].upper()

    if not username:
        raise ValueError("empty username")

    if domain:
        domain = _normalize_domain(domain)
        qualified = f"{domain}\\{username}"
    else:
        qualified = username

    return domain or "", username, qualified


def _from_env() -> MonitorCredentials | None:
    settings = get_settings()
    raw_user = (settings.monitor_username or "").strip()
    password = settings.monitor_password or ""
    raw_domain = (settings.monitor_domain or "").strip()
    if not raw_user or not password:
        return None
    try:
        domain, username, qualified = _build_qualified(raw_domain, raw_user)
    except ValueError:
        return None
    return MonitorCredentials(
        domain=domain,
        username=username,
        password=password,
        qualified=qualified,
    )


def _from_database() -> MonitorCredentials | None:
    from remote_desktop_dashboard.services.settings_store import get_monitor_credentials_dict

    data = get_monitor_credentials_dict()
    if not data:
        return None
    try:
        domain, username, qualified = _build_qualified(
            data.get("domain", ""), data["username"]
        )
    except ValueError:
        return None
    return MonitorCredentials(
        domain=domain,
        username=username,
        password=data["password"],
        qualified=qualified,
    )


def resolve_monitor_credentials() -> MonitorCredentials | None:
    """Database settings take precedence over environment variables."""
    return _from_database() or _from_env()


def monitor_credentials_source() -> str:
    if _from_database():
        return "database"
    if _from_env():
        return "environment"
    return "none"


def credentials_hint() -> str:
    return (
        "Open Server settings and save domain, service username, and password "
        "(or set RDD_MONITOR_DOMAIN / RDD_MONITOR_USERNAME / RDD_MONITOR_PASSWORD in .env)."
    )


def _normalize_domain(domain: str) -> str:
    r"""Use NetBIOS-style short name (MYDOMAIN), not FQDN."""
    domain = domain.strip().rstrip("\\/")
    if "." in domain and not domain.startswith("."):
        return domain.split(".")[0].upper()
    return domain.upper() if domain.islower() and len(domain) <= 15 else domain
