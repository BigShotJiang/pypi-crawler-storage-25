"""Cached TCP reachability so API/WebSocket stay responsive."""

from __future__ import annotations

import logging
import threading
import time

from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.models.machine import Machine
from remote_desktop_dashboard.services.reachability import check_machines_reachability

logger = logging.getLogger(__name__)

_lock = threading.Lock()
_cache: dict[str, bool] = {}
_cache_mono: float = 0.0
_refresh_thread: threading.Thread | None = None
_stop = threading.Event()


def get_cached_reachability(
    machines: list[Machine],
    *,
    allow_refresh: bool = True,
) -> dict[str, bool]:
    """Return cached reachability; refresh synchronously when cache is empty."""
    if not machines:
        return {}

    settings = get_settings()
    if not settings.reachability_check:
        return {m.name: False for m in machines}

    now = time.monotonic()
    with _lock:
        stale = (now - _cache_mono) >= settings.reachability_cache_seconds
        if _cache and not stale:
            return {m.name: _cache.get(m.name, False) for m in machines}

    if allow_refresh:
        if not _cache or stale:
            if len(machines) <= 30:
                return refresh_reachability_sync(machines)
            _schedule_refresh(machines)

    with _lock:
        if _cache:
            return {m.name: _cache.get(m.name, False) for m in machines}
    return {m.name: False for m in machines}


def refresh_reachability_sync(machines: list[Machine]) -> dict[str, bool]:
    settings = get_settings()
    if not settings.reachability_check or not machines:
        return {}
    results = check_machines_reachability(machines)
    with _lock:
        _cache.clear()
        _cache.update(results)
        global _cache_mono
        _cache_mono = time.monotonic()
    logger.debug("Reachability refreshed for %s machines", len(machines))
    return results


def _schedule_refresh(machines: list[Machine]) -> None:
    def _run() -> None:
        try:
            refresh_reachability_sync(machines)
        except Exception:
            logger.exception("Reachability refresh failed")

    threading.Thread(target=_run, daemon=True, name="rdd-reachability").start()


def start_reachability_refresher() -> None:
    """Background loop: refresh reachability without blocking HTTP."""
    global _refresh_thread
    settings = get_settings()
    if not settings.reachability_check or not settings.reachability_background:
        return
    if _refresh_thread and _refresh_thread.is_alive():
        return

    def _loop() -> None:
        from remote_desktop_dashboard.database import SessionLocal
        from remote_desktop_dashboard.crud.machine import list_machines

        _stop.wait(3)
        while not _stop.is_set():
            db = SessionLocal()
            try:
                machines = list_machines(db)
                if machines:
                    refresh_reachability_sync(machines)
            except Exception:
                logger.exception("Reachability background refresh error")
            finally:
                db.close()
            _stop.wait(settings.reachability_cache_seconds)

    _stop.clear()
    _refresh_thread = threading.Thread(target=_loop, daemon=True, name="rdd-reach-bg")
    _refresh_thread.start()


def stop_reachability_refresher() -> None:
    _stop.set()
