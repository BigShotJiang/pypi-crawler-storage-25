"""Dashboard presentation helpers."""



import json

from datetime import datetime, timezone



from remote_desktop_dashboard.crud.lock import is_lock_expired, operators_match

from remote_desktop_dashboard.models.machine import Machine

from remote_desktop_dashboard.schemas.machine import DashboardMachine, MachineRead





def _relative_time(dt: datetime | None) -> str | None:

    if dt is None:

        return None

    if dt.tzinfo is None:

        dt = dt.replace(tzinfo=timezone.utc)

    now = datetime.now(timezone.utc)

    seconds = int((now - dt).total_seconds())

    if seconds < 60:

        return f"{seconds}s ago"

    if seconds < 3600:

        return f"{seconds // 60}m ago"

    return f"{seconds // 3600}h ago"





def _poll_error(machine: Machine) -> str | None:

    if not machine.raw_report:

        return None

    try:

        data = json.loads(machine.raw_report)

        if isinstance(data, dict) and data.get("error"):

            return str(data["error"])

    except json.JSONDecodeError:

        pass

    return None





def logged_in_users(machine: Machine) -> list[str]:

    """Console + RDP users currently on the bench."""

    seen: set[str] = set()

    users: list[str] = []

    if machine.local_user:

        seen.add(machine.local_user)

        users.append(machine.local_user)

    try:
        rdp_list = json.loads(machine.rdp_users or "[]")
    except json.JSONDecodeError:
        rdp_list = []
    for name in rdp_list if isinstance(rdp_list, list) else []:

        if name and name not in seen:

            seen.add(name)

            users.append(name)

    return users





def _has_user_data(machine: Machine) -> bool:

    return bool(logged_in_users(machine)) or machine.last_seen is not None





def _compute_status(

    machine: Machine,

    is_reachable: bool,

    current_operator: str | None = None,

    bench_agent_online: bool = False,

) -> tuple[str, str, bool]:

    """Return (label, display_string, show_as_up) for one machine.

    A machine counts as "online" if EITHER the active reachability cache
    confirms it OR the bench agent has heartbeated recently. Without this,
    machines whose only signal is the agent show up red even though they're
    clearly alive.
    """

    locked = bool(machine.locked_by) and not is_lock_expired(machine)

    reachable = bool(is_reachable) or bool(bench_agent_online)

    if locked:

        if current_operator and operators_match(machine.locked_by, current_operator):

            return "in_use", "In use by you", True

        return "in_use", f"In use: {machine.locked_by}", True



    if reachable:

        return "online", "Online", True

    if machine.last_seen is not None and _has_user_data(machine):

        return "offline", "Offline", False

    return "offline", "Offline", False





def to_dashboard_machine(

    machine: Machine,

    current_operator: str | None = None,

    is_reachable: bool = False,

) -> DashboardMachine:

    base = MachineRead.model_validate(machine)

    # Compute bench agent online flag UP-FRONT so _compute_status can use it.
    agent_online_early = False
    if machine.bench_agent_last_seen is not None:
        from remote_desktop_dashboard.config import get_settings as _gs
        last = machine.bench_agent_last_seen
        if last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)
        ago = (datetime.now(timezone.utc) - last).total_seconds()
        agent_online_early = ago <= max(15, _gs().bench_agent_offline_grace_seconds)

    status_label, status_display, show_as_up = _compute_status(

        machine, is_reachable, current_operator, bench_agent_online=agent_online_early

    )

    locked = bool(machine.locked_by) and not is_lock_expired(machine)

    lock_available = not locked or (

        current_operator is not None

        and operators_match(machine.locked_by, current_operator)

    )

    users = logged_in_users(machine)

    err = _poll_error(machine)



    data = base.model_dump()

    # Compute lock TTL (seconds until the lock auto-expires).
    ttl: int | None = None
    if locked and machine.lock_heartbeat_at is not None:
        from remote_desktop_dashboard.config import get_settings
        beat = machine.lock_heartbeat_at
        if beat.tzinfo is None:
            beat = beat.replace(tzinfo=timezone.utc)
        grace = int(get_settings().lock_heartbeat_grace_seconds)
        elapsed = int((datetime.now(timezone.utc) - beat).total_seconds())
        ttl = max(0, grace - elapsed)

    # Bench agent online flag (used by Status table + Inventory tab).
    agent_online = agent_online_early

    data.update(

        {

            "is_online": show_as_up,

            "status_label": status_label,

            "status_display": status_display,

            "is_reachable": is_reachable,

            "logged_in_users": users,

            "has_user_data": bool(users),

            "poll_error": err,

            "last_seen_relative": _relative_time(machine.last_seen),

            "is_locked": locked,

            "lock_available": lock_available,

            "lock_ttl_seconds": ttl,

            "bench_agent_online": agent_online,

        }

    )

    return DashboardMachine(**data)





def machines_payload(

    machines: list[Machine],

    current_operator: str | None = None,

    reachability: dict[str, bool] | None = None,

) -> dict:

    reachability = reachability or {}

    rows = [

        to_dashboard_machine(

            m, current_operator, reachability.get(m.name, False)

        ).model_dump(mode="json")

        for m in machines

    ]

    return {"type": "machines_update", "machines": rows}





def bench_host(machine: Machine, *, prefer_ip: bool = True) -> str:

    if prefer_ip:

        return machine.ip_address or machine.hostname

    return machine.hostname or machine.ip_address


