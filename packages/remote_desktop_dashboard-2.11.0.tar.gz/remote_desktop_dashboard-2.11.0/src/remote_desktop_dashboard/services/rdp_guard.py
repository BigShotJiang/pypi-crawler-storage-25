"""Block direct RDP to a bench while the dashboard holds a lock (Windows Firewall via remote netsh).

Strategy (Windows Firewall rule precedence: block > allow, no rule = blocked):

  apply:  1. disable built-in "Remote Desktop" group  (so default rules no longer allow 3389)
          2. add RDD-Guard-Allow-<ip> allow rule for the dashboard client IP(s) on TCP/3389
          -> only the listed IP(s) can reach 3389; everyone else gets no matching allow.

  clear:  1. delete RDD-Guard-Allow-* rules
          2. re-enable built-in "Remote Desktop" group  (restores normal behaviour)

We do NOT add any block rule — a generic block would override our IP-specific allow rule.
"""

from __future__ import annotations

import concurrent.futures
import logging
import re
import sys
import threading
import time

from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.services.monitor_credentials import (
    MonitorCredentials,
    resolve_monitor_credentials,
)
from remote_desktop_dashboard.services.windows_cmd import run_cmd, system32_exe

logger = logging.getLogger(__name__)

RULE_ALLOW_PREFIX = "RDD-Guard-Allow-"

RDP_GROUPS: tuple[str, ...] = (
    "Remote Desktop",
    "remote desktop",
    "@FirewallAPI.dll,-28752",
)

BUILTIN_RDP_RULES: tuple[str, ...] = (
    "RemoteDesktop-UserMode-In-TCP",
    "RemoteDesktop-UserMode-In-UDP",
    "RemoteDesktop-Shadow-In-TCP",
    "Remote Desktop - User Mode (TCP-In)",
    "Remote Desktop - User Mode (UDP-In)",
    "Remote Desktop - Shadow (TCP-In)",
    "Remote Desktop (TCP-In)",
)


def _sanitize_rule_suffix(ip: str) -> str:
    return re.sub(r"[^0-9A-Za-z]", "-", ip)


def _netsh_remote(
    host: str,
    creds: MonitorCredentials,
    subcommand: list[str],
    timeout: float,
) -> str:
    netsh = system32_exe("netsh.exe")
    args = [
        netsh,
        "-r",
        host.strip().strip("\\"),
        "-u",
        creds.tasklist_user_arg(),
        "-p",
        creds.password,
        *subcommand,
    ]
    return run_cmd(args, timeout)


def _delete_rule(host: str, creds: MonitorCredentials, name: str, timeout: float) -> None:
    try:
        _netsh_remote(
            host,
            creds,
            ["advfirewall", "firewall", "delete", "rule", f"name={name}"],
            timeout,
        )
    except Exception as exc:
        logger.debug("Delete firewall rule %s on %s: %s", name, host, exc)


def _set_rdp_group(
    host: str,
    creds: MonitorCredentials,
    enabled: bool,
    timeout: float,
    *,
    overall_deadline: float | None = None,
) -> bool:
    """Enable or disable built-in Remote Desktop firewall rules in parallel.

    Tries all group identifiers AND well-known rule names concurrently. As soon as
    one succeeds we record success but keep collecting other results so the overall
    state ends up consistent. Per-call timeout is short to avoid hangs; the overall
    operation is bounded by `overall_deadline`.

    Returns True if *anything* succeeded.
    """
    value = "yes" if enabled else "no"
    per_call = min(timeout, 12.0)
    if overall_deadline is None:
        overall_deadline = time.monotonic() + max(per_call * 2.5, 30.0)

    candidates: list[tuple[str, list[str]]] = []
    for group in RDP_GROUPS:
        candidates.append(
            (
                f"group={group}",
                [
                    "advfirewall",
                    "firewall",
                    "set",
                    "rule",
                    f"group={group}",
                    "new",
                    f"enable={value}",
                ],
            )
        )
    for name in BUILTIN_RDP_RULES:
        candidates.append(
            (
                f"name={name}",
                [
                    "advfirewall",
                    "firewall",
                    "set",
                    "rule",
                    f"name={name}",
                    "new",
                    f"enable={value}",
                ],
            )
        )

    any_ok = False
    errs: list[str] = []
    timeouts = 0
    EARLY_BAIL_TIMEOUTS = 3  # if 3 consecutive parallel calls timed out, the bench is unreachable

    def _attempt(label: str, args: list[str], call_timeout: float) -> tuple[str, bool, str | None]:
        try:
            _netsh_remote(host, creds, args, call_timeout)
            return label, True, None
        except Exception as exc:
            return label, False, str(exc)

    with concurrent.futures.ThreadPoolExecutor(
        max_workers=min(8, len(candidates)),
        thread_name_prefix="rdd-guard-attempt",
    ) as pool:
        futures = [
            pool.submit(_attempt, label, args, per_call) for label, args in candidates
        ]
        try:
            for fut in concurrent.futures.as_completed(futures, timeout=overall_deadline - time.monotonic()):
                try:
                    label, ok, err = fut.result()
                except Exception as exc:
                    errs.append(f"(executor error: {exc})")
                    continue
                if ok:
                    any_ok = True
                    timeouts = 0
                    if not enabled:
                        break
                else:
                    errs.append(f"{label}: {err}")
                    if err and "timed out" in err.lower():
                        timeouts += 1
                        if timeouts >= EARLY_BAIL_TIMEOUTS and not any_ok:
                            errs.append(
                                f"(bailed out after {timeouts} timeouts — bench is not responding to remote netsh)"
                            )
                            break
                if time.monotonic() > overall_deadline:
                    errs.append("(overall deadline reached)")
                    break
        except concurrent.futures.TimeoutError:
            errs.append("(overall deadline reached during as_completed)")
        finally:
            for fut in futures:
                fut.cancel()

    if not any_ok:
        logger.warning(
            "Could not %s built-in RDP firewall rules on %s. Attempts: %s",
            "enable" if enabled else "disable",
            host,
            "; ".join(errs) or "n/a",
        )
    elif errs:
        logger.debug(
            "%s built-in RDP rules on %s (%d attempts failed)",
            "Enabled" if enabled else "Disabled",
            host,
            len(errs),
        )
    return any_ok


def _collect_allow_ips(allow_ips: list[str] | None) -> list[str]:
    settings = get_settings()
    ips: list[str] = []
    for ip in allow_ips or []:
        s = (ip or "").strip()
        if s and not _is_loopback(s) and s not in ips:
            ips.append(s)
    for ip in settings.rdp_guard_extra_ips.split(","):
        s = ip.strip()
        if s and s not in ips:
            ips.append(s)
    return ips


def _is_loopback(ip: str) -> bool:
    ip = (ip or "").strip().lower()
    return ip in ("127.0.0.1", "::1", "localhost") or ip.startswith("127.")


def _delete_all_allow_rules(host: str, creds: MonitorCredentials, timeout: float) -> None:
    """Remove any leftover RDD-Guard-Allow-* rules (best effort)."""
    try:
        out = _netsh_remote(
            host,
            creds,
            ["advfirewall", "firewall", "show", "rule", "name=all"],
            timeout,
        )
    except Exception as exc:
        logger.debug("Could not list firewall rules on %s: %s", host, exc)
        return

    found: set[str] = set()
    for line in out.splitlines():
        line = line.strip()
        if line.lower().startswith("rule name:"):
            name = line.split(":", 1)[1].strip()
            if name.startswith(RULE_ALLOW_PREFIX):
                found.add(name)
    for name in found:
        _delete_rule(host, creds, name, timeout)


def clear_rdp_guard(host: str, allow_ips: list[str] | None = None) -> None:
    """Remove dashboard RDP firewall rules and re-enable built-in Remote Desktop group."""
    if sys.platform != "win32":
        return
    settings = get_settings()
    from remote_desktop_dashboard.services.settings_store import is_rdp_guard_enabled
    if not is_rdp_guard_enabled():
        return

    creds = resolve_monitor_credentials()
    if creds is None:
        return

    target = host.strip().strip("\\")
    timeout = settings.rdp_guard_timeout_seconds

    if allow_ips:
        for ip in _collect_allow_ips(allow_ips):
            _delete_rule(
                target,
                creds,
                f"{RULE_ALLOW_PREFIX}{_sanitize_rule_suffix(ip)}",
                timeout,
            )
    else:
        _delete_all_allow_rules(target, creds, timeout)

    _set_rdp_group(target, creds, enabled=True, timeout=timeout)
    logger.info("RDP guard cleared on %s (built-in RDP rules re-enabled)", target)


def apply_rdp_guard(host: str, allow_ips: list[str]) -> bool:
    """Disable built-in RDP allow rules, then allow only the dashboard client IP(s)."""
    if sys.platform != "win32":
        return False
    settings = get_settings()
    from remote_desktop_dashboard.services.settings_store import is_rdp_guard_enabled
    if not is_rdp_guard_enabled():
        return False

    creds = resolve_monitor_credentials()
    if creds is None:
        logger.warning("RDP guard skipped — no monitor credentials")
        return False

    ips = _collect_allow_ips(allow_ips)
    if not ips:
        logger.warning(
            "RDP guard skipped — no usable client IP to allow. "
            "If the dashboard runs on localhost, set RDD_RDP_GUARD_EXTRA_IPS in admin.env."
        )
        return False

    target = host.strip().strip("\\")
    timeout = settings.rdp_guard_timeout_seconds
    port = settings.rdp_port
    overall_deadline = time.monotonic() + max(timeout * 2.0, 45.0)
    per_call = min(timeout, 12.0)

    _delete_all_allow_rules(target, creds, per_call)

    # Step 1: disable the built-in "Remote Desktop" rules FIRST, so there is no
    # window where everyone can still reach 3389. Fail closed — if we cannot lock
    # down the bench, do not add an allow rule and report failure to the caller.
    disabled = _set_rdp_group(
        target,
        creds,
        enabled=False,
        timeout=per_call,
        overall_deadline=overall_deadline,
    )
    if not disabled:
        logger.warning(
            "RDP guard could not disable built-in RDP rules on %s — "
            "anyone with RDP access can still connect. Not applying allow rule.",
            target,
        )
        return False

    try:
        # Step 2: now that the default allow is gone, permit only the dashboard
        # client IP(s) back in on 3389. No matching allow == blocked by default.
        for ip in ips:
            if time.monotonic() > overall_deadline:
                raise TimeoutError("RDP guard overall deadline reached while adding allow rules")
            allow_name = f"{RULE_ALLOW_PREFIX}{_sanitize_rule_suffix(ip)}"
            _netsh_remote(
                target,
                creds,
                [
                    "advfirewall",
                    "firewall",
                    "add",
                    "rule",
                    f"name={allow_name}",
                    "dir=in",
                    "action=allow",
                    "protocol=TCP",
                    f"localport={port}",
                    f"remoteip={ip}",
                    "profile=any",
                    "enable=yes",
                ],
                per_call,
            )

        elapsed = time.monotonic() - (overall_deadline - max(timeout * 2.0, 45.0))
        logger.info(
            "RDP guard enabled on %s (allow: %s) in %.1fs", target, ", ".join(ips), elapsed
        )
        return True
    except Exception as exc:
        logger.warning("Could not enable RDP guard on %s: %s", target, exc)
        try:
            _set_rdp_group(target, creds, enabled=True, timeout=per_call)
        except Exception:
            pass
        return False


def schedule_apply_rdp_guard(host: str, allow_ips: list[str]) -> None:
    ips = list(allow_ips)

    def _run() -> None:
        try:
            apply_rdp_guard(host, ips)
        except Exception as exc:
            logger.warning("Background RDP guard failed on %s: %s", host, exc)

    threading.Thread(target=_run, name=f"rdd-guard-apply-{host}", daemon=True).start()


def schedule_clear_rdp_guard(host: str, allow_ips: list[str] | None = None) -> None:
    ips = list(allow_ips or [])

    def _run() -> None:
        try:
            clear_rdp_guard(host, ips)
        except Exception as exc:
            logger.debug("Background RDP guard clear on %s: %s", host, exc)

    threading.Thread(target=_run, name=f"rdd-guard-clear-{host}", daemon=True).start()
