"""Localhost HTTP helper that launches mstsc (credential prompt) on Windows."""

from __future__ import annotations

import logging
import sys
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse

from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.services.rdp_launch import launch_rdp_on_windows

logger = logging.getLogger(__name__)
_server: HTTPServer | None = None
_thread: threading.Thread | None = None


class _LaunchHandler(BaseHTTPRequestHandler):
    def log_message(self, format: str, *args) -> None:
        logger.debug("local_launcher: " + format, *args)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path not in ("/connect", "/"):
            self.send_error(404)
            return

        if parsed.path == "/":
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"Remote Desktop Dashboard local launcher OK\n")
            return

        params = parse_qs(parsed.query)
        host = (params.get("host") or [""])[0].strip()
        if not host:
            self.send_error(400, "Missing host")
            return

        port = int((params.get("port") or ["3389"])[0])
        username = (params.get("username") or [""])[0].strip() or None
        domain = (params.get("domain") or [""])[0].strip() or None

        try:
            client, _path = launch_rdp_on_windows(host, port, username, domain)
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            msg = f'{{"ok":true,"client":"{client}"}}'
            self.wfile.write(msg.encode())
        except Exception as exc:
            logger.exception("Launch failed")
            self.send_error(500, str(exc))

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.end_headers()


def start_local_launcher() -> bool:
    """Start localhost launcher thread (Windows only). Returns True if started."""
    global _server, _thread

    settings = get_settings()
    if not settings.local_launcher_enabled or sys.platform != "win32":
        return False
    if _server is not None:
        return True

    try:
        _server = HTTPServer(("127.0.0.1", settings.local_launcher_port), _LaunchHandler)
        _thread = threading.Thread(target=_server.serve_forever, daemon=True, name="rdd-launcher")
        _thread.start()
        logger.info("Local RDP launcher on http://127.0.0.1:%s", settings.local_launcher_port)
        return True
    except OSError as exc:
        logger.warning("Could not start local launcher: %s", exc)
        return False


def stop_local_launcher() -> None:
    global _server, _thread
    if _server:
        _server.shutdown()
        _server = None
    _thread = None
