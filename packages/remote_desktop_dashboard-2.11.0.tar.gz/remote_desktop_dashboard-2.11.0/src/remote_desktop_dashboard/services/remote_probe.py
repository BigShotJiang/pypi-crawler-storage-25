"""
Agentless remote monitoring from the dashboard server (Windows).

Uses remote tasklist and optionally quser/qwinsta.
Credentials: RDD_MONITOR_DOMAIN + RDD_MONITOR_USERNAME + RDD_MONITOR_PASSWORD
"""

from __future__ import annotations

import csv
import io
import logging
import re
import sys
import time
import threading
from contextlib import contextmanager
from typing import Any

from remote_desktop_dashboard.agent.monitor import MonitorSnapshot
from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.services.monitor_credentials import (
    MonitorCredentials,
    credentials_hint,
    resolve_monitor_credentials,
)
from remote_desktop_dashboard.services.process_catalog import (
    ALL_MONITORED_NAMES,
    ProcessInfo,
    analyze_sessions_and_processes,
    enrich_process_users,
    list_detected_tools,
    normalize_user,
    processes_missing_monitored_usernames,
)
from remote_desktop_dashboard.services.reachability import check_host_reachable
from remote_desktop_dashboard.services.windows_cmd import run_cmd, system32_exe

logger = logging.getLogger(__name__)

_net_use_lock = threading.Lock()  # only around net use /delete, not the whole probe


def _parse_query_user(text: str) -> list[dict[str, str]]:
    sessions: list[dict[str, str]] = []
    for line in text.splitlines()[1:]:
        line = line.strip()
        if not line:
            continue
        if line.startswith(">"):
            line = line[1:].strip()
        parts = re.split(r"\s{2,}|\s+", line)
        if len(parts) < 4:
            continue
        username = parts[0].lstrip(">")
        sessions.append(
            {
                "username": normalize_user(username) or username,
                "session": parts[1] if len(parts) > 1 else "",
                "state": parts[3] if len(parts) > 3 else "",
            }
        )
    return sessions


def _parse_query_session(text: str) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for line in text.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 4:
            continue
        session_name = parts[0].lstrip(">")
        username = parts[1] if parts[1] != "." else ""
        session_type = parts[2] if len(parts) > 2 else ""
        if username and username != "services":
            mapping[normalize_user(username) or username] = session_type
        if session_name:
            mapping[session_name.lower()] = session_type
    return mapping


@contextmanager
def _remote_auth(host: str, timeout: float, creds: MonitorCredentials | None):
    """Optional IPC$ session — only used if direct tasklist /U /P fails."""
    if creds is None:
        yield
        return

    unc = f"\\\\{host}\\IPC$"
    net_exe = system32_exe("net.exe")
    auth_timeout = min(timeout, 10.0)
    args = [
        net_exe,
        "use",
        unc,
        creds.password,
        creds.net_use_user_arg(),
        "/persistent:no",
    ]
    logger.debug("net use %s /user:%s", unc, creds.qualified)
    with _net_use_lock:
        try:
            run_cmd(args, auth_timeout)
        except Exception as exc:
            raise RuntimeError(
                f"Could not authenticate to {host} ({exc}). {credentials_hint()}"
            ) from exc
    try:
        yield
    finally:
        with _net_use_lock:
            try:
                run_cmd([net_exe, "use", unc, "/delete", "/y"], min(auth_timeout, 5.0))
            except Exception:
                pass


def _remote_query_user(host: str, timeout: float) -> list[dict[str, str]]:
    def _run_query(args: list[str]) -> list[dict[str, str]]:
        try:
            out = run_cmd(args, timeout)
            return _parse_query_user(out)
        except RuntimeError as exc:
            msg = str(exc).lower()
            if "no user" in msg or "no session" in msg or "not available" in msg:
                return []
            raise

    try:
        quser = system32_exe("quser.exe")
        return _run_query([quser, f"/server:{host}"])
    except FileNotFoundError:
        pass
    query = system32_exe("query.exe")
    return _run_query([query, "user", f"/server:{host}"])


def _remote_query_session(host: str, timeout: float) -> dict[str, str]:
    try:
        qwinsta = system32_exe("qwinsta.exe")
        out = run_cmd([qwinsta, f"/server:{host}"], timeout)
        return _parse_query_session(out)
    except FileNotFoundError:
        pass
    query = system32_exe("query.exe")
    out = run_cmd([query, "session", f"/server:{host}"], timeout)
    return _parse_query_session(out)


def _session_user_map(sessions: list[dict[str, str]]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for s in sessions:
        user = s.get("username")
        sess = (s.get("session") or "").strip()
        if not user:
            continue
        mapping[sess.lower()] = user
        if sess.isdigit():
            mapping[sess] = user
        mapping[sess.split("#")[0].lower()] = user
    return mapping


def _sessions_from_processes(processes: list[ProcessInfo]) -> list[dict[str, str]]:
    seen: set[str] = set()
    sessions: list[dict[str, str]] = []
    for proc in processes:
        user = proc.username
        if not user or user in seen:
            continue
        seen.add(user)
        sessions.append(
            {"username": user, "session": proc.session or "", "state": "active"}
        )
    return sessions


def _parse_tasklist_username(row: list[str]) -> str | None:
    if len(row) <= 6:
        return None
    raw = (row[6] or "").strip().strip('"')
    if not raw or raw.upper() in ("N/A", "UNKNOWN"):
        return None
    if raw.upper().endswith("$"):
        return None
    return normalize_user(raw) or raw


def _wmi_connect(host: str, creds: MonitorCredentials):
    import wmi  # type: ignore[import-untyped]

    return wmi.WMI(
        computer=host,
        user=creds.qualified,
        password=creds.password,
        namespace=r"root\cimv2",
    )


def _owner_from_wmi(proc: Any) -> str | None:
    try:
        owner = proc.GetOwner()
        user = owner.get("User") if owner else None
        domain = (owner.get("Domain") or "") if owner else ""
        if domain and user:
            qualified = f"{domain}\\{user}"
        else:
            qualified = user
        return normalize_user(qualified) or qualified
    except Exception:
        return None


def _wmi_enrich_monitored(
    host: str,
    creds: MonitorCredentials,
    processes: list[ProcessInfo],
    timeout: float,
) -> int:
    """Fill missing owners for monitored tools only (fast WQL, not full process scan)."""
    need = processes_missing_monitored_usernames(processes)
    if not need:
        return 0
    need_pids = {p.pid for p in need}

    try:
        conn = _wmi_connect(host, creds)
    except Exception as exc:
        logger.info("WMI owner enrichment unavailable for %s: %s", host, exc)
        return 0

    enriched = 0
    deadline = time.monotonic() + timeout
    clauses = " OR ".join(f"Name='{name}'" for name in sorted(ALL_MONITORED_NAMES))
    wql = f"SELECT ProcessId, Name FROM Win32_Process WHERE {clauses}"
    try:
        rows = conn.query(wql)
    except Exception:
        rows = conn.Win32_Process()

    for proc in rows:
        if time.monotonic() > deadline:
            break
        try:
            pid = int(proc.ProcessId or 0)
        except (TypeError, ValueError):
            continue
        if pid not in need_pids:
            continue
        username = _owner_from_wmi(proc)
        if not username:
            continue
        for p in processes:
            if p.pid == pid and not p.username:
                p.username = username
                enriched += 1
                need_pids.discard(pid)
                break
        if not need_pids:
            break
    return enriched


def _wmi_console_user(host: str, creds: MonitorCredentials, timeout: float) -> str | None:
    """Logged-on console user via Win32_ComputerSystem (works when quser fails)."""
    try:
        conn = _wmi_connect(host, creds)
    except Exception as exc:
        logger.debug("WMI console user unavailable for %s: %s", host, exc)
        return None

    deadline = time.monotonic() + min(timeout, 8.0)
    try:
        for cs in conn.Win32_ComputerSystem():
            if time.monotonic() > deadline:
                break
            raw = getattr(cs, "UserName", None) or ""
            if raw and "\\" in raw:
                return normalize_user(raw)
            if raw:
                return normalize_user(raw) or raw
    except Exception as exc:
        logger.debug("Win32_ComputerSystem failed on %s: %s", host, exc)
    return None


def _remote_tasklist_wmi(host: str, creds: MonitorCredentials, timeout: float) -> list[ProcessInfo]:
    """WMI fallback — often works when tasklist /U /P fails."""
    import wmi  # type: ignore[import-untyped]

    conn = wmi.WMI(
        computer=host,
        user=creds.qualified,
        password=creds.password,
        namespace=r"root\cimv2",
    )
    processes: list[ProcessInfo] = []
    for proc in conn.Win32_Process():
        try:
            owner = proc.GetOwner()
            user = owner.get("User") if owner else None
            domain = owner.get("Domain", "") if owner else ""
            if domain and user:
                username = f"{domain}\\{user}"
            else:
                username = user
        except Exception:
            username = None
        processes.append(
            ProcessInfo(
                name=(proc.Name or "").lower(),
                username=normalize_user(username),
                pid=int(proc.ProcessId or 0),
                cmdline=(proc.CommandLine or "").lower(),
                session=None,
            )
        )
    return processes


def _tasklist_args(
    tasklist: str,
    target: str,
    creds: MonitorCredentials,
    *,
    verbose: bool = False,
) -> list[str]:
    """Same as manual: tasklist /S ip /U DOMAIN\\user /P pass /FO CSV /NH (no /V)."""
    args = [
        tasklist,
        "/S",
        target,
        "/U",
        creds.tasklist_user_arg(),
        "/P",
        creds.password,
        "/FO",
        "CSV",
        "/NH",
    ]
    if verbose:
        args.append("/V")
    return args


def _remote_tasklist(
    host: str,
    timeout: float,
    session_users: dict[str, str],
    creds: MonitorCredentials | None,
    *,
    allow_wmi: bool = True,
) -> list[ProcessInfo]:
    tasklist = system32_exe("tasklist.exe")
    target = host.strip().strip("\\")

    if creds is None:
        raise RuntimeError(
            f"Cannot query {target} without monitor credentials. {credentials_hint()}"
        )

    last_exc: Exception | None = None
    out: str | None = None
    for verbose in (False, True):
        args = _tasklist_args(tasklist, target, creds, verbose=verbose)
        label = "verbose" if verbose else "standard"
        logger.debug("tasklist (%s) /S %s /U %s", label, target, creds.qualified)
        try:
            out = run_cmd(args, timeout)
            last_exc = None
            break
        except Exception as exc:
            last_exc = exc
            if verbose:
                break
            logger.info("Standard remote tasklist failed, retrying with /V: %s", exc)

    if out is None:
        exc = last_exc or RuntimeError("tasklist failed")
        if allow_wmi:
            logger.info("tasklist failed, trying WMI: %s", exc)
            try:
                return _remote_tasklist_wmi(target, creds, min(timeout, 20.0))
            except Exception as wmi_exc:
                raise RuntimeError(
                    f"Remote tasklist failed for {target}: {exc}; WMI: {wmi_exc}. "
                    f"{credentials_hint()}"
                ) from exc
        raise RuntimeError(
            f"Remote tasklist failed for {target}: {exc}. {credentials_hint()}"
        ) from exc

    processes: list[ProcessInfo] = []
    reader = csv.reader(io.StringIO(out))
    for row in reader:
        if len(row) < 5:
            continue
        name = (row[0] or "").strip().lower().strip('"')
        if not name or name == "image name":
            continue
        try:
            pid = int(row[1].strip().replace('"', ""))
        except ValueError:
            pid = 0
        session_name = row[2].strip().replace('"', "") if len(row) > 2 else ""
        session_id = row[3].strip().replace('"', "") if len(row) > 3 else ""
        username = _parse_tasklist_username(row)
        if not username:
            username = session_users.get(session_id) or session_users.get(session_id.lower())
        if not username and session_name:
            sn = session_name.lower()
            username = session_users.get(sn) or session_users.get(sn.split("#")[0])
        cmdline = row[-1].lower().strip('"') if len(row) > 6 else ""
        processes.append(
            ProcessInfo(
                name=name,
                username=normalize_user(username),
                pid=pid,
                cmdline=cmdline,
                session=session_name.lower() if session_name else None,
                session_id=session_id or None,
            )
        )
    return processes


def probe_remote_machine(host: str, *, quick: bool = False) -> MonitorSnapshot:
    if sys.platform != "win32":
        raise OSError("Remote probing requires the dashboard server to run on Windows")

    settings = get_settings()
    target = host.strip().strip("\\")
    creds = resolve_monitor_credentials()
    if creds is None:
        raise RuntimeError(
            "Monitor credentials not configured on the dashboard server. "
            f"{credentials_hint()}"
        )

    ping_timeout = settings.poll_ping_timeout_seconds
    if not check_host_reachable(target, settings.rdp_port, ping_timeout):
        raise RuntimeError(
            f"Host {target} not reachable on TCP port {settings.rdp_port} "
            f"(firewall, wrong IP, or machine offline)."
        )

    if quick:
        total_timeout = settings.settings_test_timeout_seconds
    else:
        total_timeout = settings.poll_timeout_seconds
    session_timeout = min(settings.poll_session_timeout_seconds, total_timeout)
    tasklist_timeout = total_timeout
    auth_timeout = min(10.0, total_timeout)

    wmi_timeout = min(30.0, max(12.0, tasklist_timeout * 0.5))
    allow_wmi = True

    def _collect() -> tuple[list[dict[str, str]], dict[str, str], list[ProcessInfo], str | None]:
        """IPC$ + quser first, then tasklist with session map, then targeted WMI owners."""
        sessions: list[dict[str, str]] = []
        session_types: dict[str, str] = {}
        session_error: str | None = None
        processes: list[ProcessInfo] = []

        def _apply_enrichment() -> int:
            session_users = _session_user_map(sessions)
            enrich_process_users(processes, session_users)
            wmi_n = _wmi_enrich_monitored(target, creds, processes, wmi_timeout)
            if wmi_n:
                logger.info("WMI enriched %s monitored process owners on %s", wmi_n, target)
            return wmi_n

        try:
            with _remote_auth(target, auth_timeout, creds):
                try:
                    sessions = _remote_query_user(target, session_timeout)
                    session_types = _remote_query_session(target, session_timeout)
                except Exception as exc:
                    session_error = str(exc)
                    logger.info("Remote session query failed for %s: %s", target, exc)
                session_users = _session_user_map(sessions)
                try:
                    processes = _remote_tasklist(
                        target,
                        tasklist_timeout,
                        session_users,
                        creds,
                        allow_wmi=allow_wmi,
                    )
                except Exception as exc:
                    logger.info("Remote tasklist under IPC$ failed for %s: %s", target, exc)
                    if session_error:
                        session_error = f"{session_error}; tasklist: {exc}"
                    else:
                        session_error = str(exc)
        except Exception as auth_exc:
            session_error = str(auth_exc)
            logger.info("IPC$ auth failed for %s, trying direct tasklist: %s", target, auth_exc)

        if not processes:
            try:
                processes = _remote_tasklist(
                    target,
                    tasklist_timeout,
                    _session_user_map(sessions),
                    creds,
                    allow_wmi=allow_wmi,
                )
            except Exception as exc:
                if session_error:
                    session_error = f"{session_error}; {exc}"
                else:
                    session_error = str(exc)
                raise RuntimeError(
                    f"Remote tasklist failed for {target}: {exc}. {credentials_hint()}"
                ) from exc

        _apply_enrichment()

        if not sessions:
            wmi_console = _wmi_console_user(target, creds, wmi_timeout)
            if wmi_console:
                sessions = [
                    {
                        "username": wmi_console,
                        "session": "console",
                        "state": "active",
                    }
                ]
                enrich_process_users(processes, _session_user_map(sessions))
                _wmi_enrich_monitored(target, creds, processes, wmi_timeout)

        return sessions, session_types, processes, session_error

    sessions, session_types, processes, session_error = _collect()

    if not processes:
        raise RuntimeError(
            session_error
            or f"tasklist returned no data for {target}. {credentials_hint()}"
        )

    if not sessions:
        sessions = _sessions_from_processes(processes)

    analyzed = analyze_sessions_and_processes(sessions, session_types, processes)
    tools = list_detected_tools(processes)
    raw: dict[str, Any] = {
        "source": "remote_poller",
        "target": target,
        "sessions": sessions,
        "session_types": session_types,
        "process_count": len(processes),
        "session_count": len(sessions),
        "session_error": session_error,
        "tools_running": tools,
        "auth_user": creds.qualified if creds else None,
    }

    return MonitorSnapshot(
        local_user=analyzed["local_user"],
        rdp_users=analyzed["rdp_users"],
        windows_app_users=analyzed["windows_app_users"],
        mobaxterm_user=analyzed["mobaxterm_user"],
        com_port_user=analyzed["com_port_user"],
        etgui_user=analyzed["etgui_user"],
        camera_user=analyzed["camera_user"],
        camera_tools=analyzed["camera_tools"],
        raw=raw,
    )
