"""Install dashboard as a self-healing Windows Scheduled Task.

The task fires every 5 minutes; a single-instance file lock in the dashboard
process (see ``cli._acquire_singleton_lock``) makes the duplicate fires no-op
when the dashboard is already running. So:

- Boot: task fires within ~5 min of logon -> dashboard starts.
- Crash / closed terminal: next scheduler tick (max 5 min away) restarts it.
- Already running: new instance acquires nothing, exits cleanly.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from typing import Optional

TASK_NAME = "RemoteDesktopDashboard"


def _dashboard_command() -> str:
    """Build the command the scheduler will run.

    We prefer ``pythonw.exe`` (windowless) so the user never sees a stray
    black console after logon. Fall back to ``python.exe`` if not present.
    """
    from remote_desktop_dashboard.paths import resolve_data_dir

    data_dir = resolve_data_dir()
    env_set = f'set RDD_DATA_DIR={data_dir}&& '

    # Prefer the windowless Python so no console flashes/stays open.
    pythonw = _pythonw_path()
    if pythonw:
        return (
            f'{env_set}"{pythonw}" -m remote_desktop_dashboard.cli '
            f"--no-browser --host 0.0.0.0"
        )

    exe = shutil.which("remote-desktop-dashboard")
    if exe:
        return f'{env_set}"{exe}" --no-browser --host 0.0.0.0'

    return (
        f'{env_set}"{sys.executable}" -m remote_desktop_dashboard.cli '
        f"--no-browser --host 0.0.0.0"
    )


def _pythonw_path() -> Optional[str]:
    """Locate pythonw.exe next to the current python.exe, if available."""
    if sys.platform != "win32":
        return None
    candidate = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    if os.path.isfile(candidate):
        return candidate
    found = shutil.which("pythonw")
    return found


def _resolve_user() -> str:
    return (
        os.environ.get("RDD_SERVICE_USER")
        or os.environ.get("USERNAME")
        or "SYSTEM"
    )


def install_autostart() -> None:
    """Register the dashboard as a self-healing Scheduled Task."""
    if sys.platform != "win32":
        print("Autostart is only supported on Windows.", file=sys.stderr)
        sys.exit(1)

    tr = _dashboard_command()
    user = _resolve_user()

    args = [
        "schtasks",
        "/Create",
        "/F",
        "/TN", TASK_NAME,
        "/TR", tr,
        "/SC", "MINUTE",
        "/MO", "5",
        "/RU", user,
        "/RL", "HIGHEST",
    ]
    if user.upper() != "SYSTEM":
        args.append("/IT")  # required so the desktop session sees the process

    try:
        subprocess.run(args, check=True)
    except subprocess.CalledProcessError as exc:
        print(f"Failed to create scheduled task: {exc}", file=sys.stderr)
        print("Hint: run this command from an elevated terminal.", file=sys.stderr)
        sys.exit(exc.returncode or 1)

    print(f"Installed scheduled task '{TASK_NAME}'.")
    print(f"  Trigger:  every 5 minutes (self-healing).")
    print(f"  Runs as:  {user}")
    print(f"  Command:  {tr}")
    print()
    print("Starting the dashboard now...")
    try:
        subprocess.run(["schtasks", "/Run", "/TN", TASK_NAME], check=False)
    except OSError:
        pass
    print()
    print("To check status:  remote-desktop-dashboard service-status")
    print("To remove:        remote-desktop-dashboard uninstall-autostart")


def uninstall_autostart() -> None:
    if sys.platform != "win32":
        sys.exit(1)
    try:
        subprocess.run(
            ["schtasks", "/Delete", "/F", "/TN", TASK_NAME], check=True
        )
        print(f"Removed scheduled task '{TASK_NAME}'.")
    except subprocess.CalledProcessError as exc:
        print(f"Could not remove scheduled task: {exc}", file=sys.stderr)
        sys.exit(exc.returncode or 1)


def service_status() -> None:
    """Print whether the scheduled task is installed + last result + next run."""
    if sys.platform != "win32":
        print("This command is Windows-only.")
        return
    res = subprocess.run(
        ["schtasks", "/Query", "/TN", TASK_NAME, "/V", "/FO", "LIST"],
        capture_output=True,
        text=True,
    )
    if res.returncode != 0:
        print(f"Scheduled task '{TASK_NAME}' is NOT installed.")
        print(
            "Install with:  remote-desktop-dashboard install-autostart\n"
            "(Run from an elevated PowerShell so the task can register HIGHEST run-level.)"
        )
        return
    interesting_keys = {
        "TaskName",
        "Status",
        "Last Run Time",
        "Last Result",
        "Next Run Time",
        "Task To Run",
        "Run As User",
    }
    for line in res.stdout.splitlines():
        if ":" in line:
            key = line.split(":", 1)[0].strip()
            if key in interesting_keys:
                print(line.strip())
    print()
    # Also check whether the dashboard is currently listening.
    from remote_desktop_dashboard.config import get_settings

    try:
        import socket

        port = get_settings().port
        with socket.create_connection(("127.0.0.1", int(port)), timeout=1.0):
            print(f"Dashboard is responding on http://127.0.0.1:{port}/")
    except OSError:
        print(
            "Dashboard is NOT currently listening locally — the scheduler will "
            "re-launch it on its next tick (within 5 minutes)."
        )
