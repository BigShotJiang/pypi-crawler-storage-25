r"""Push-install the bench agent onto a remote machine.

Uses the saved monitor credentials (which have local-admin rights on each
bench) to:
  1. Establish an SMB session via ``net use \\HOST\IPC$``.
  2. Write bench_agent.ps1 + config.json into ``\\HOST\C$\ProgramData\RDD-Bench-Agent\``.
  3. Register the scheduled task remotely via ``schtasks /create /s HOST``.
  4. Start it via ``schtasks /run``.
  5. Tear down the SMB session.

All work is local-to-bench except the SMB/RPC channel, which is the same
underlying transport that ``quser /server:`` already uses successfully.
"""

from __future__ import annotations

import json
import logging
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from remote_desktop_dashboard import __version__
from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.services.monitor_credentials import (
    MonitorCredentials,
    resolve_monitor_credentials,
)
from remote_desktop_dashboard.services.windows_cmd import (
    redact_cmd_args,
    run_cmd,
    system32_dir,
)

logger = logging.getLogger(__name__)

_AGENT_DATA = Path(__file__).resolve().parent.parent / "data"
_BENCH_AGENT = _AGENT_DATA / "bench_agent.ps1"

TASK_NAME = "RDD-Bench-Agent"
REMOTE_DIR = r"C:\ProgramData\RDD-Bench-Agent"


@dataclass
class PushResult:
    ok: bool
    host: str
    steps: list[dict] = field(default_factory=list)
    error: str | None = None

    def add(self, name: str, ok: bool, detail: str = "") -> None:
        self.steps.append({"step": name, "ok": ok, "detail": detail})


def _net_use(host: str, creds: MonitorCredentials, timeout: float) -> None:
    args = [
        str(system32_dir() / "net.exe"),
        "use",
        f"\\\\{host}\\IPC$",
        creds.password,
        creds.net_use_user_arg(),
        "/persistent:no",
    ]
    run_cmd(args, timeout=timeout)


def _net_use_delete(host: str, timeout: float) -> None:
    args = [str(system32_dir() / "net.exe"), "use", f"\\\\{host}\\IPC$", "/delete", "/y"]
    try:
        run_cmd(args, timeout=timeout)
    except Exception as exc:
        logger.debug("net use /delete %s failed (ignored): %s", host, exc)


def _smb_path(host: str, sub: str = "") -> Path:
    """Map remote `C:\\ProgramData\\RDD-Bench-Agent\\<sub>` to a UNC path."""
    base = f"\\\\{host}\\C$\\ProgramData\\RDD-Bench-Agent"
    return Path(base if not sub else f"{base}\\{sub}")


def _write_remote_file(host: str, name: str, content: bytes | str) -> None:
    target = _smb_path(host, name)
    target.parent.mkdir(parents=True, exist_ok=True)
    mode = "wb" if isinstance(content, (bytes, bytearray)) else "w"
    if mode == "w":
        target.write_text(content, encoding="utf-8")
    else:
        target.write_bytes(content)


def _schtasks_create(
    host: str,
    creds: MonitorCredentials,
    agent_path: str,
    timeout: float,
) -> None:
    """Register the scheduled task remotely.

    We use ``/sc minute /mo 5`` so the task self-restarts every 5 minutes if it
    exits for any reason. The agent script uses a per-machine file mutex
    (``running.lock``) to make sure only one instance runs at a time, so
    successive 5-minute triggers are no-ops while the long-running loop is
    alive but instantly recover from crashes.
    """
    pwsh = (
        "powershell.exe -NoProfile -ExecutionPolicy Bypass "
        f'-File "{agent_path}"'
    )
    args = [
        str(system32_dir() / "schtasks.exe"),
        "/create",
        "/s", host,
        "/u", creds.qualified,
        "/p", creds.password,
        "/tn", TASK_NAME,
        "/tr", pwsh,
        "/sc", "minute",
        "/mo", "5",
        "/sd", "01/01/2020",
        "/st", "00:00",
        "/ru", "SYSTEM",
        "/rl", "HIGHEST",
        "/f",
    ]
    run_cmd(args, timeout=timeout)


def _schtasks_run(host: str, creds: MonitorCredentials, timeout: float) -> None:
    args = [
        str(system32_dir() / "schtasks.exe"),
        "/run",
        "/s", host,
        "/u", creds.qualified,
        "/p", creds.password,
        "/tn", TASK_NAME,
    ]
    run_cmd(args, timeout=timeout)


def _schtasks_query(host: str, creds: MonitorCredentials, timeout: float) -> str:
    args = [
        str(system32_dir() / "schtasks.exe"),
        "/query",
        "/s", host,
        "/u", creds.qualified,
        "/p", creds.password,
        "/tn", TASK_NAME,
        "/fo", "LIST",
        "/v",
    ]
    return run_cmd(args, timeout=timeout)


def push_install(host: str, machine_name: str, dashboard_url: str) -> PushResult:
    """Install the bench agent on `host` using saved monitor credentials.

    `host`           — bench hostname or IP, resolvable from the dashboard server.
    `machine_name`   — the dashboard's name for this machine (goes into config.json).
    `dashboard_url`  — base URL the bench can use to reach this dashboard.
    """
    result = PushResult(ok=False, host=host)

    creds = resolve_monitor_credentials()
    if creds is None:
        result.error = (
            "No monitor credentials configured. Open Settings -> Server settings "
            "and save the service account first."
        )
        return result

    settings = get_settings()
    token = (settings.bench_agent_token or "").strip()
    if not token:
        result.error = "RDD_BENCH_AGENT_TOKEN is empty in admin.env."
        return result

    if not _BENCH_AGENT.is_file():
        result.error = f"bench_agent.ps1 missing from package data ({_BENCH_AGENT})."
        return result

    agent_text = _BENCH_AGENT.read_text(encoding="utf-8")
    config_text = json.dumps(
        {
            "dashboard_url": dashboard_url.rstrip("/"),
            "machine_name":  machine_name,
            "token":         token,
            "poll_seconds":  max(2, int(settings.bench_agent_poll_seconds)),
            "installer":     f"dashboard-push v{__version__}",
        },
        indent=2,
    )

    timeout_short = 15.0
    timeout_long  = 30.0
    connected = False

    try:
        try:
            _net_use(host, creds, timeout_short)
            connected = True
            result.add("smb_connect", True, f"\\\\{host}\\IPC$")
        except Exception as exc:
            result.add("smb_connect", False, str(exc))
            result.error = (
                f"Cannot reach \\\\{host}\\IPC$ as {creds.qualified}. "
                "The bench must allow SMB (port 445) from the dashboard server "
                "and the service account must be a local admin on the bench."
            )
            return result

        try:
            _write_remote_file(host, "bench_agent.ps1", agent_text)
            result.add("write_agent", True, _smb_path(host, "bench_agent.ps1").as_posix())
        except Exception as exc:
            result.add("write_agent", False, str(exc))
            result.error = f"Could not write bench_agent.ps1 to {host}: {exc}"
            return result

        try:
            _write_remote_file(host, "config.json", config_text)
            result.add("write_config", True, _smb_path(host, "config.json").as_posix())
        except Exception as exc:
            result.add("write_config", False, str(exc))
            result.error = f"Could not write config.json to {host}: {exc}"
            return result

        local_agent_path = f"{REMOTE_DIR}\\bench_agent.ps1"
        try:
            _schtasks_create(host, creds, local_agent_path, timeout_long)
            result.add("register_task", True, TASK_NAME)
        except Exception as exc:
            result.add("register_task", False, str(exc))
            result.error = (
                f"Could not register scheduled task '{TASK_NAME}' on {host}: {exc}. "
                "Most often this means the Task Scheduler service isn't reachable "
                "remotely. Try the manual one-liner option instead."
            )
            return result

        try:
            _schtasks_run(host, creds, timeout_short)
            result.add("start_task", True, "/run")
        except Exception as exc:
            result.add("start_task", False, str(exc))
            # Not fatal — task will fire at next boot anyway, and the dashboard
            # auto-creates a 5-minute repeat trigger via the install.ps1 path.
            result.error = (
                f"Files installed and task registered, but could not /run it now: "
                f"{exc}. It will start on the next reboot."
            )
            result.ok = True
            return result

        result.ok = True
        return result

    finally:
        if connected:
            _net_use_delete(host, timeout_short)


@dataclass
class DiagnosticReport:
    machine_name: str
    host: str
    smb_ok: bool = False
    smb_error: str | None = None
    config_present: bool = False
    config: dict | None = None
    config_error: str | None = None
    log_present: bool = False
    log_tail: list[str] = field(default_factory=list)
    log_error: str | None = None
    task_state: str | None = None
    task_last_run: str | None = None
    task_last_result: str | None = None
    task_next_run: str | None = None
    task_error: str | None = None
    verdict: str = "unknown"

    def to_dict(self) -> dict:
        from dataclasses import asdict
        return asdict(self)


def _parse_schtasks_query(text: str) -> dict[str, str]:
    """Parse `schtasks /query /fo LIST /v` output into a flat dict."""
    out: dict[str, str] = {}
    for line in text.splitlines():
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip()
        if key and value:
            out[key] = value
    return out


def diagnose(host: str, machine_name: str) -> DiagnosticReport:
    """Read everything we can from a bench to figure out why the agent
    isn't (or might not be) reporting in. Uses the saved monitor credentials.
    """
    rpt = DiagnosticReport(machine_name=machine_name, host=host)
    creds = resolve_monitor_credentials()
    if creds is None:
        rpt.verdict = "no monitor credentials saved (Server settings)"
        return rpt

    # SMB session ---------------------------------------------------------
    try:
        _net_use(host, creds, 15.0)
        rpt.smb_ok = True
    except Exception as exc:
        rpt.smb_error = str(exc)
        rpt.verdict = (
            f"Cannot reach \\\\{host}\\IPC$ from the dashboard server. "
            "Bench may be offline, firewalled, or the service account isn't "
            "a local admin there."
        )
        return rpt

    try:
        # config.json -----------------------------------------------------
        cfg_path = _smb_path(host, "config.json")
        if cfg_path.is_file():
            rpt.config_present = True
            try:
                raw = cfg_path.read_text(encoding="utf-8")
                cfg = json.loads(raw)
                # Strip the token before returning to the caller.
                cfg.pop("token", None)
                rpt.config = cfg
            except Exception as exc:
                rpt.config_error = f"config.json unreadable: {exc}"
        else:
            rpt.config_error = "config.json missing on bench"

        # log tail --------------------------------------------------------
        log_path = _smb_path(host, "bench-agent.log")
        if log_path.is_file():
            rpt.log_present = True
            try:
                lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
                rpt.log_tail = lines[-40:]
            except Exception as exc:
                rpt.log_error = f"log unreadable: {exc}"
        else:
            rpt.log_error = "bench-agent.log not yet created"

        # scheduled task state --------------------------------------------
        try:
            task_text = _schtasks_query(host, creds, 20.0)
            parsed = _parse_schtasks_query(task_text)
            rpt.task_state       = parsed.get("Status") or parsed.get("Scheduled Task State")
            rpt.task_last_run    = parsed.get("Last Run Time")
            rpt.task_last_result = parsed.get("Last Result")
            rpt.task_next_run    = parsed.get("Next Run Time")
        except Exception as exc:
            rpt.task_error = str(exc)
    finally:
        _net_use_delete(host, 10.0)

    # Compose verdict ---------------------------------------------------------
    if not rpt.config_present:
        rpt.verdict = (
            "Config not on the bench. The push install never finished writing "
            "files. Retry Push install."
        )
    elif rpt.config and rpt.config.get("machine_name") != machine_name:
        rpt.verdict = (
            f"Config machine_name='{rpt.config.get('machine_name')}' does not "
            f"match dashboard name='{machine_name}'. Heartbeats are landing "
            "under a different machine. Use Push install to fix (it writes the "
            "right name)."
        )
    elif rpt.task_error:
        rpt.verdict = (
            f"Scheduled task '{TASK_NAME}' could not be queried: {rpt.task_error}"
        )
    elif rpt.task_state and rpt.task_state.lower() in ("disabled",):
        rpt.verdict = f"Scheduled task '{TASK_NAME}' is Disabled — run Push install again."
    elif rpt.task_last_result and rpt.task_last_result not in ("0", "267009", "267011"):
        rpt.verdict = (
            f"Scheduled task '{TASK_NAME}' last exit code is {rpt.task_last_result} "
            "(non-zero). The agent script is crashing — see log_tail."
        )
    elif not rpt.log_present:
        rpt.verdict = (
            "Task is registered but bench-agent.log was never written. The "
            "PowerShell agent never actually started. Verify the bench can run "
            "PowerShell scripts (PSExecutionPolicy)."
        )
    elif rpt.log_tail and any("dashboard unreachable" in l for l in rpt.log_tail[-15:]):
        url = (rpt.config or {}).get("dashboard_url", "")
        rpt.verdict = (
            f"Agent is running on the bench but cannot reach the dashboard at "
            f"{url}. Check that this URL is reachable from the bench (try "
            f"`iwr {url}/health` on the bench)."
        )
    elif rpt.log_tail and any("Starting RDD bench agent" in l for l in rpt.log_tail):
        rpt.verdict = (
            "Agent is running and reporting normally. If the dashboard still "
            "shows 'no agent', check the agent panel — it may just need 5-10 "
            "more seconds for the next heartbeat to arrive."
        )
    else:
        rpt.verdict = "Indeterminate — see log_tail and task_state for details."

    return rpt


def uninstall(host: str) -> PushResult:
    """Remove the agent's scheduled task and config from the bench."""
    result = PushResult(ok=False, host=host)
    creds = resolve_monitor_credentials()
    if creds is None:
        result.error = "No monitor credentials configured."
        return result

    try:
        _net_use(host, creds, 15.0)
    except Exception as exc:
        result.add("smb_connect", False, str(exc))
        result.error = str(exc)
        return result

    try:
        args = [
            str(system32_dir() / "schtasks.exe"),
            "/delete", "/s", host,
            "/u", creds.qualified,
            "/p", creds.password,
            "/tn", TASK_NAME, "/f",
        ]
        try:
            run_cmd(args, timeout=15.0)
            result.add("delete_task", True, TASK_NAME)
        except Exception as exc:
            result.add("delete_task", False, str(exc))

        for name in ("bench_agent.ps1", "config.json", "baseline.json"):
            try:
                p = _smb_path(host, name)
                if p.exists():
                    p.unlink()
                result.add(f"delete_{name}", True, str(p))
            except Exception as exc:
                result.add(f"delete_{name}", False, str(exc))

        result.ok = True
    finally:
        _net_use_delete(host, 10.0)
    return result
