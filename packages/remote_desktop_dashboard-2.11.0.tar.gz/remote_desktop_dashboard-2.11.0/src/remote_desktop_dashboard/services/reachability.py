"""TCP reachability checks (RDP port) for machines without a running agent."""

from __future__ import annotations

import socket
from concurrent.futures import ThreadPoolExecutor, as_completed

from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.models.machine import Machine


def check_host_reachable(host: str, port: int, timeout: float) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def check_machines_reachability(machines: list[Machine]) -> dict[str, bool]:
    settings = get_settings()
    if not settings.reachability_check or not machines:
        return {}

    timeout = settings.reachability_timeout_seconds
    port = settings.rdp_port
    results: dict[str, bool] = {}

    def probe(machine: Machine) -> tuple[str, bool]:
        return machine.name, check_host_reachable(machine.ip_address, port, timeout)

    workers = min(len(machines), settings.reachability_max_workers)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(probe, m) for m in machines]
        for future in as_completed(futures):
            name, ok = future.result()
            results[name] = ok

    return results
