"""Resolve Windows system utilities and run them safely (never log credentials)."""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def system32_dir() -> Path:
    root = os.environ.get("SystemRoot") or os.environ.get("WINDIR") or r"C:\Windows"
    return Path(root) / "System32"


def system32_exe(*candidates: str) -> str:
    """Return the first existing executable under System32."""
    folder = system32_dir()
    for name in candidates:
        path = folder / name
        if path.is_file():
            return str(path)
    tried = ", ".join(candidates)
    raise FileNotFoundError(
        f"None of [{tried}] found in {folder}. "
        "Remote polling needs quser.exe/qwinsta.exe or query.exe, or falls back to tasklist only."
    )


# Flags that indicate the *next* argv element is a credential and must be redacted.
_PASSWORD_FLAGS: frozenset[str] = frozenset(
    {
        "/P",      # tasklist /P <password>
        "-P",      # alias
        "/PASS",   # alias
        "-p",      # netsh -p <password> / others
        "--password",
        "/password",
        "-password",
    }
)


def _redact_value(value: str) -> str:
    if not value:
        return value
    return "***"


def redact_cmd_args(args: list[str]) -> str:
    """Build a credential-safe string of an argv list for logs/errors."""
    redacted: list[str] = []
    i = 0
    while i < len(args):
        arg = args[i]
        redacted.append(arg)
        upper = arg.upper()

        # `-p secret` / `/P secret` / `--password secret`
        if (arg in _PASSWORD_FLAGS or upper in _PASSWORD_FLAGS) and i + 1 < len(args):
            redacted.append(_redact_value(args[i + 1]))
            i += 2
            continue

        # `--password=secret` or `/password:secret`
        if "=" in arg or ":" in arg:
            for sep in ("=", ":"):
                if sep in arg:
                    head, _, _ = arg.partition(sep)
                    if head.lower() in (
                        "--password",
                        "-password",
                        "/password",
                        "-p",
                        "/p",
                        "/pass",
                    ):
                        redacted[-1] = f"{head}{sep}***"
                        break

        # `net use \\HOST\IPC$ <password> /user:...`
        if "IPC$" in arg and i + 1 < len(args) and not args[i + 1].startswith("/"):
            redacted.append(_redact_value(args[i + 1]))
            i += 2
            continue

        i += 1
    return " ".join(redacted)


def run_cmd(args: list[str], timeout: float) -> str:
    """Run a command; return stdout. Raises on failure or timeout WITHOUT leaking credentials.

    Important: we catch `subprocess.TimeoutExpired` and re-raise as `RuntimeError`
    with a redacted message, because the default repr of TimeoutExpired includes
    the entire argv list (including any -p <password>).
    """
    safe_for_logs = redact_cmd_args(args)
    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            creationflags=CREATE_NO_WINDOW,
            shell=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            f"Command timed out after {exc.timeout:.1f} seconds: {safe_for_logs}"
        ) from None
    except FileNotFoundError as exc:
        raise RuntimeError(
            f"Executable not found ({exc.filename or args[0]!r}): {safe_for_logs}"
        ) from None
    except Exception as exc:
        raise RuntimeError(f"Command failed ({type(exc).__name__}): {safe_for_logs}") from None

    out = (result.stdout or "").strip()
    err = (result.stderr or "").strip()
    if result.returncode != 0 and not out:
        # Even err text from a remote tool can contain echoed argv — keep it,
        # but never include the raw command itself.
        raise RuntimeError(
            err or f"Command failed (exit {result.returncode}): {safe_for_logs}"
        )
    return result.stdout
