from remote_desktop_dashboard.cli import run_server

if __name__ == "__main__":
    run_server()
