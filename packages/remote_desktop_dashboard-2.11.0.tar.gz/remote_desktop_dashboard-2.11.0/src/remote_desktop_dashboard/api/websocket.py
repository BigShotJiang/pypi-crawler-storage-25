"""WebSocket endpoint for live dashboard."""

import asyncio

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from sqlalchemy.orm import Session

from remote_desktop_dashboard.crud.lock import refresh_expired_locks
from remote_desktop_dashboard.crud.machine import list_machines, refresh_online_flags
from remote_desktop_dashboard.database import SessionLocal
from remote_desktop_dashboard.services.connection_manager import manager
from remote_desktop_dashboard.services.dashboard import machines_payload
from remote_desktop_dashboard.services.reachability_cache import get_cached_reachability

router = APIRouter()


def _machines_with_reachability_sync() -> dict:
    """Build dashboard payload without blocking the event loop for long."""
    db: Session = SessionLocal()
    try:
        refresh_online_flags(db)
        refresh_expired_locks(db, remote_firewall=False)
        machines = list_machines(db)
        reach = get_cached_reachability(machines, allow_refresh=False)
        return machines_payload(machines, reachability=reach)
    finally:
        db.close()


@router.websocket("/ws/dashboard")
async def websocket_dashboard(websocket: WebSocket) -> None:
    await manager.connect(websocket)
    payload = await asyncio.to_thread(_machines_with_reachability_sync)
    await websocket.send_json(payload)

    try:
        while True:
            try:
                msg = await asyncio.wait_for(websocket.receive_text(), timeout=30.0)
                if msg.strip().lower() == "ping":
                    await websocket.send_json({"type": "pong"})
            except asyncio.TimeoutError:
                payload = await asyncio.to_thread(_machines_with_reachability_sync)
                await websocket.send_json(payload)
    except WebSocketDisconnect:
        pass
    finally:
        await manager.disconnect(websocket)
