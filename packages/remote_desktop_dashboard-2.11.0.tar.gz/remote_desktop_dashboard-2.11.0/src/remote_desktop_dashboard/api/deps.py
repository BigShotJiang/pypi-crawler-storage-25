"""API dependencies."""

from fastapi import Header, HTTPException, status

from remote_desktop_dashboard.config import get_settings


def verify_agent_key(x_api_key: str | None = Header(default=None)) -> None:
    settings = get_settings()
    if not settings.agent_api_key:
        return
    if x_api_key != settings.agent_api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing X-API-Key",
        )


def verify_bench_agent_token(
    authorization: str | None = Header(default=None),
    x_bench_token: str | None = Header(default=None),
) -> None:
    """Bench agent uses a separate token in `X-Bench-Token` or `Authorization: Bearer ...`."""
    settings = get_settings()
    expected = (settings.bench_agent_token or "").strip()
    if not expected:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Bench agent disabled: set RDD_BENCH_AGENT_TOKEN in admin.env.",
        )
    provided = x_bench_token
    if not provided and authorization and authorization.lower().startswith("bearer "):
        provided = authorization.split(None, 1)[1].strip()
    if provided != expected:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid bench agent token.",
        )
