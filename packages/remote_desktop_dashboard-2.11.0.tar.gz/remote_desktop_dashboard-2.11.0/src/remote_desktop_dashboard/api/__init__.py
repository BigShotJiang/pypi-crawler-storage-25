from remote_desktop_dashboard.api.routes import router

__all__ = ["router"]
