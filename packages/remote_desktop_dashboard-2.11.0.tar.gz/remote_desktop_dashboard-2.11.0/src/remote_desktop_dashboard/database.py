"""SQLAlchemy engine and session factory."""

from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from remote_desktop_dashboard.paths import resolve_database_url

connect_args: dict = {"check_same_thread": False, "timeout": 30}

engine = create_engine(
    resolve_database_url(),
    connect_args=connect_args,
    pool_pre_ping=False,
)

from sqlalchemy import event  # noqa: E402


@event.listens_for(engine, "connect")
def _sqlite_pragma(dbapi_conn, _connection_record) -> None:
    cursor = dbapi_conn.cursor()
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA busy_timeout=30000")
    cursor.close()


SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    pass


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    from remote_desktop_dashboard import models  # noqa: F401
    from remote_desktop_dashboard.services.bootstrap import upgrade_database_schema

    Base.metadata.create_all(bind=engine)
    upgrade_database_schema(engine)
