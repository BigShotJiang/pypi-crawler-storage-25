# RDD Bench Agent (PowerShell, runs as SYSTEM).
# Manages local "Remote Desktop Users" group + kicks unauthorized RDP sessions
# based on the current dashboard lock state.
#
# Config:   C:\ProgramData\RDD-Bench-Agent\config.json
# Baseline: C:\ProgramData\RDD-Bench-Agent\baseline.json
# Log:      C:\ProgramData\RDD-Bench-Agent\bench-agent.log

[CmdletBinding()]
param([switch]$Once)

$ErrorActionPreference = "Stop"
$AgentVersion = "2.1.0"
$GroupName    = "Remote Desktop Users"
$ConfigDir    = "C:\ProgramData\RDD-Bench-Agent"
$ConfigPath   = Join-Path $ConfigDir "config.json"
$BaselinePath = Join-Path $ConfigDir "baseline.json"
$LogPath      = Join-Path $ConfigDir "bench-agent.log"
$LockPath     = Join-Path $ConfigDir "running.lock"

if (-not (Test-Path $ConfigDir)) {
    New-Item -ItemType Directory -Path $ConfigDir -Force | Out-Null
}

# Single-instance lock: if another agent process is already running, exit cleanly.
# This lets us schedule the task /sc minute /mo 5 for auto-recovery without
# stacking multiple instances.
$global:LockFile = $null
try {
    $global:LockFile = [System.IO.File]::Open(
        $LockPath, [System.IO.FileMode]::OpenOrCreate,
        [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None
    )
} catch {
    Write-Host "Another RDD bench agent instance is already running. Exiting."
    exit 0
}

function Write-AgentLog {
    param([string]$Level, [string]$Message)
    try {
        $ts = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        $line = "$ts $Level $Message"
        Add-Content -Path $LogPath -Value $line -Encoding UTF8 -ErrorAction SilentlyContinue
        Write-Host $line
    } catch {}
}

function Get-Config {
    if (-not (Test-Path $ConfigPath)) {
        throw "Config not found at $ConfigPath. Re-run the installer."
    }
    return (Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json)
}

function Get-GroupMembers {
    try {
        $members = Get-LocalGroupMember -Group $GroupName -ErrorAction Stop
        return @($members | ForEach-Object { $_.Name })
    } catch {
        Write-AgentLog "WARN" "Get-LocalGroupMember failed: $($_.Exception.Message)"
        return @()
    }
}

function Save-Baseline {
    param([string[]]$Members)
    ($Members | ConvertTo-Json -Compress -Depth 3) |
        Set-Content -Path $BaselinePath -Encoding UTF8
}

function Get-Baseline {
    if (Test-Path $BaselinePath) {
        try {
            $raw = Get-Content -Raw -Path $BaselinePath
            if (-not $raw) { return $null }
            $parsed = $raw | ConvertFrom-Json
            if ($parsed -is [System.Array]) { return ,@($parsed) }
            return ,@($parsed)
        } catch { return $null }
    }
    return $null
}

function Initialize-Baseline {
    $existing = Get-Baseline
    if ($null -ne $existing) { return ,@($existing) }
    $current = Get-GroupMembers
    Save-Baseline -Members $current
    Write-AgentLog "INFO" "Baseline RDU members snapshotted: $($current -join ', ')"
    return ,@($current)
}

# ---------------------------------------------------------------------------
# Firewall enforcement.
# When locked: drop a Windows Firewall rule that only allows inbound 3389 from
# the lock owner's IP(s) and DISABLE the built-in "Remote Desktop" allow rules.
# Windows Firewall is implicit-deny: with the built-ins disabled and no other
# allow rule matching, all other source IPs are rejected at the TCP/IP layer —
# this is the ONLY way to block a local Administrator from RDPing, since
# Administrators bypass the "Remote Desktop Users" group requirement.
# When unlocked: delete our custom rule and re-enable the built-ins.
# ---------------------------------------------------------------------------
$script:FwRuleName    = "RDD-Bench-Agent-RDP-Allow"
# Built-in RDP rule "Name" (not DisplayName) — stable across locales.
$script:BuiltinRdpRules = @(
    "RemoteDesktop-UserMode-In-TCP",
    "RemoteDesktop-UserMode-In-UDP",
    "RemoteDesktop-UserMode-In-TCP-WS",
    "RemoteDesktop-UserMode-In-TCP-WSS"
)

function Apply-Firewall {
    param(
        [bool]$Locked,
        [bool]$Enabled,
        [string[]]$AllowIps
    )
    if (-not $Enabled) {
        try { Remove-NetFirewallRule -DisplayName $script:FwRuleName -ErrorAction SilentlyContinue } catch {}
        foreach ($n in $script:BuiltinRdpRules) {
            try { Enable-NetFirewallRule -Name $n -ErrorAction SilentlyContinue } catch {}
        }
        return @{ Mode = "off"; Applied = @() }
    }

    if ($Locked -and $AllowIps -and $AllowIps.Count -gt 0) {
        try { Remove-NetFirewallRule -DisplayName $script:FwRuleName -ErrorAction SilentlyContinue } catch {}
        New-NetFirewallRule `
            -DisplayName $script:FwRuleName `
            -Direction Inbound `
            -Protocol TCP `
            -LocalPort 3389 `
            -Action Allow `
            -Profile Any `
            -Enabled True `
            -RemoteAddress $AllowIps `
            -Description "Managed by RDD-Bench-Agent. Removed automatically on unlock." `
            -ErrorAction Stop | Out-Null
        foreach ($n in $script:BuiltinRdpRules) {
            try { Disable-NetFirewallRule -Name $n -ErrorAction SilentlyContinue } catch {}
        }
        return @{ Mode = "locked"; Applied = $AllowIps }
    }

    try { Remove-NetFirewallRule -DisplayName $script:FwRuleName -ErrorAction SilentlyContinue } catch {}
    foreach ($n in $script:BuiltinRdpRules) {
        try { Enable-NetFirewallRule -Name $n -ErrorAction SilentlyContinue } catch {}
    }
    return @{ Mode = "unlocked"; Applied = @() }
}

function Sync-Group {
    param(
        [string[]]$AllowUsers,
        [bool]$Locked,
        [string[]]$Baseline
    )
    $desired = if ($Locked) { @($AllowUsers) } else { @($Baseline) }

    $current     = Get-GroupMembers
    $desiredLow  = New-Object System.Collections.Generic.HashSet[string]
    foreach ($u in $desired) {
        if ($u) { [void]$desiredLow.Add($u.ToLower()) }
    }
    $currentMap  = @{}
    foreach ($m in $current) {
        if ($m) { $currentMap[$m.ToLower()] = $m }
    }

    $errors = @()

    foreach ($key in @($currentMap.Keys)) {
        if (-not $desiredLow.Contains($key)) {
            $orig = $currentMap[$key]
            try {
                Remove-LocalGroupMember -Group $GroupName -Member $orig -ErrorAction Stop
                Write-AgentLog "INFO" "Removed $orig from $GroupName"
            } catch {
                $errors += "remove ${orig}: $($_.Exception.Message)"
            }
        }
    }

    foreach ($u in $desired) {
        if (-not $u) { continue }
        if (-not $currentMap.ContainsKey($u.ToLower())) {
            try {
                Add-LocalGroupMember -Group $GroupName -Member $u -ErrorAction Stop
                Write-AgentLog "INFO" "Added $u to $GroupName"
            } catch {
                $errors += "add ${u}: $($_.Exception.Message)"
            }
        }
    }

    $finalMembers = Get-GroupMembers
    $errText = if ($errors.Count) { $errors -join "; " } else { $null }
    return @{ Members = $finalMembers; Error = $errText }
}

function Get-RdpSessions {
    try {
        $raw = & qwinsta.exe 2>$null
        if (-not $raw) { return @() }
        $sessions = @()
        $lines = @($raw -split "`r?`n" | Where-Object { $_ -and $_.Trim() })
        if ($lines.Count -lt 2) { return @() }
        for ($i = 1; $i -lt $lines.Count; $i++) {
            $line = $lines[$i].TrimEnd()
            $parts = ($line.Trim() -split '\s+')
            if ($parts.Count -lt 3) { continue }
            $first = $parts[0].TrimStart('>')
            if (-not $first.ToLower().StartsWith("rdp-")) { continue }
            if ($parts[1] -match '^\d+$') {
                $user = ""
                $sid  = $parts[1]
            } else {
                $user = $parts[1]
                $sid  = $parts[2]
            }
            if ($sid -match '^\d+$') {
                $sessions += [PSCustomObject]@{
                    Session = $first
                    User    = $user
                    Id      = [int]$sid
                }
            }
        }
        return $sessions
    } catch {
        return @()
    }
}

function Stop-UnauthorizedSessions {
    param(
        [string[]]$AllowUsers,
        [bool]$Locked
    )
    if (-not $Locked) { return }
    $allowFull = New-Object System.Collections.Generic.HashSet[string]
    $allowBare = New-Object System.Collections.Generic.HashSet[string]
    foreach ($u in $AllowUsers) {
        if (-not $u) { continue }
        [void]$allowFull.Add($u.ToLower())
        $bare = ($u.Split('\'))[-1].ToLower()
        [void]$allowBare.Add($bare)
    }
    foreach ($s in Get-RdpSessions) {
        if (-not $s.User) { continue }
        $lower = $s.User.ToLower()
        $bare  = ($lower.Split('\'))[-1]
        if ($allowFull.Contains($lower) -or $allowBare.Contains($bare)) { continue }
        Write-AgentLog "WARN" "Kicking unauthorized RDP session: $($s.User) (id=$($s.Id))"
        try { & logoff.exe $s.Id } catch {}
    }
}

function Invoke-Dashboard {
    param(
        [string]$Path,
        [string]$Method = "GET",
        [object]$Body = $null
    )
    $url = "$($script:Config.dashboard_url.TrimEnd('/'))$Path"
    $headers = @{
        "X-Bench-Token"   = $script:Config.token
        "Authorization"   = "Bearer $($script:Config.token)"
        "User-Agent"      = "RDD-Bench-Agent/$AgentVersion"
    }
    if ($Body) {
        $json = $Body | ConvertTo-Json -Compress -Depth 5
        return Invoke-RestMethod -Uri $url -Method $Method -Headers $headers `
            -Body $json -ContentType "application/json" -TimeoutSec 15
    }
    return Invoke-RestMethod -Uri $url -Method $Method -Headers $headers -TimeoutSec 15
}

function Get-Access {
    return Invoke-Dashboard `
        -Path "/api/v1/machines/$($script:Config.machine_name)/access"
}

function Send-Heartbeat {
    param(
        [string[]]$Applied,
        [string[]]$AppliedIps,
        [string]$FirewallMode,
        [object[]]$Sessions,
        [string]$ErrText
    )
    $users = @($Sessions | Where-Object { $_.User } | ForEach-Object { $_.User })
    $body = @{
        agent_version     = $AgentVersion
        applied_users     = $Applied
        applied_ips       = $AppliedIps
        firewall_mode     = $FirewallMode
        current_rdp_users = $users
        error             = $ErrText
        os                = "windows"
        hostname          = $env:COMPUTERNAME
    }
    try {
        Invoke-Dashboard `
            -Path "/api/v1/machines/$($script:Config.machine_name)/agent/heartbeat" `
            -Method POST -Body $body | Out-Null
    } catch {
        # Heartbeat failures are non-fatal.
    }
}

# Main loop ------------------------------------------------------------------

$script:Config = Get-Config
$pollSeconds   = [int]$script:Config.poll_seconds
if ($pollSeconds -lt 2) { $pollSeconds = 5 }
$baseline = Initialize-Baseline

Write-AgentLog "INFO" "Starting RDD bench agent v$AgentVersion for $($script:Config.machine_name) -> $($script:Config.dashboard_url)"

$lastState = $null

try {
    while ($true) {
        try {
            $errText = $null
            $applied = @()
            $access  = $null

            try {
                $access = Get-Access
                if ($access.poll_seconds) {
                    $pollSeconds = [int]$access.poll_seconds
                    if ($pollSeconds -lt 2) { $pollSeconds = 5 }
                }
            } catch {
                $errText = "dashboard unreachable: $($_.Exception.Message)"
                Write-AgentLog "WARN" $errText
            }

            $appliedIps  = @()
            $firewallMode = "off"

            if ($access) {
                $locked    = [bool]$access.locked
                $allow     = @($access.allow_users)
                $allowIps  = @($access.allow_ips)
                $fwEnabled = if ($null -eq $access.firewall_lock) { $true } else { [bool]$access.firewall_lock }
                $kick      = if ($null -eq $access.kick_other_sessions) { $true } else { [bool]$access.kick_other_sessions }
                $restoreNative = if ($null -eq $access.restore_native_rdp) { $false } else { [bool]$access.restore_native_rdp }

                if ($restoreNative) {
                    # Admin break-glass: undo everything we did, restore stock Windows RDP.
                    Write-AgentLog "WARN" "Admin requested emergency restore of native RDP. Disabling lock + firewall override."
                    $locked    = $false
                    $allow     = @()
                    $allowIps  = @()
                    $fwEnabled = $false
                    $kick      = $false
                }

                try {
                    $result = Sync-Group -AllowUsers $allow -Locked $locked -Baseline $baseline
                    $applied = $result.Members
                    if ($result.Error) { $errText = $result.Error }
                    if ($kick) { Stop-UnauthorizedSessions -AllowUsers $allow -Locked $locked }
                } catch {
                    $errText = "reconcile failed: $($_.Exception.Message)"
                    Write-AgentLog "ERROR" $errText
                }

                try {
                    $fw = Apply-Firewall -Locked $locked -Enabled $fwEnabled -AllowIps $allowIps
                    $firewallMode = $fw.Mode
                    $appliedIps   = @($fw.Applied)
                } catch {
                    $fwErr = "firewall update failed: $($_.Exception.Message)"
                    Write-AgentLog "ERROR" $fwErr
                    if (-not $errText) { $errText = $fwErr } else { $errText = "$errText; $fwErr" }
                }

                $stateKey = "$locked|$($allow -join ',')|$($allowIps -join ',')|$firewallMode"
                if ($stateKey -ne $lastState) {
                    Write-AgentLog "INFO" "State change: locked=$locked allow=[$($allow -join ',')] allow_ips=[$($allowIps -join ',')] fw=$firewallMode"
                    $lastState = $stateKey
                }
            }

            Send-Heartbeat -Applied $applied -AppliedIps $appliedIps -FirewallMode $firewallMode -Sessions (Get-RdpSessions) -ErrText $errText
        } catch {
            Write-AgentLog "ERROR" "Iteration failed (continuing): $($_.Exception.Message)"
        }

        if ($Once) { break }
        Start-Sleep -Seconds $pollSeconds
    }
} finally {
    if ($global:LockFile) {
        try { $global:LockFile.Close() } catch {}
        try { Remove-Item -Path $LockPath -Force -ErrorAction SilentlyContinue } catch {}
    }
}
