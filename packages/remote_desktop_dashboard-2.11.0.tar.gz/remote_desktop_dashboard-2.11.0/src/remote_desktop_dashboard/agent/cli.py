"""CLI for the Windows monitoring agent."""

import argparse
import os
import sys
import time

from remote_desktop_dashboard.agent.monitor import collect_snapshot
from remote_desktop_dashboard.agent.reporter import post_status


def run_agent() -> None:
    parser = argparse.ArgumentParser(
        description="Remote Desktop Dashboard agent — reports status from each Windows machine"
    )
    parser.add_argument(
        "--machine",
        default=os.environ.get("RDD_MACHINE_NAME", ""),
        help="Machine name (ATC1..ATC10). Env: RDD_MACHINE_NAME",
    )
    parser.add_argument(
        "--server",
        default=os.environ.get("RDD_SERVER_URL", "http://127.0.0.1:8080"),
        help="Dashboard base URL. Env: RDD_SERVER_URL",
    )
    parser.add_argument(
        "--api-key",
        default=os.environ.get("RDD_AGENT_API_KEY", ""),
        help="API key if server requires it. Env: RDD_AGENT_API_KEY",
    )
    parser.add_argument(
        "--interval",
        type=int,
        default=int(os.environ.get("RDD_AGENT_INTERVAL", "30")),
        help="Seconds between reports (loop mode)",
    )
    parser.add_argument(
        "--once",
        action="store_true",
        help="Send one report and exit",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print snapshot JSON without posting",
    )
    args = parser.parse_args()

    if not args.machine:
        print("Error: --machine or RDD_MACHINE_NAME is required", file=sys.stderr)
        sys.exit(1)

    if sys.platform != "win32":
        print("Warning: agent is intended for Windows hosts", file=sys.stderr)

    def send_once() -> None:
        if args.dry_run:
            snap = collect_snapshot()
            print(snap.to_report_dict())
            return
        result = post_status(args.server, args.machine, args.api_key)
        print(f"Reported OK: {args.machine} -> {result.get('name', args.machine)}")

    if args.once or args.dry_run:
        send_once()
        return

    while True:
        try:
            send_once()
        except Exception as exc:
            print(f"Report failed: {exc}", file=sys.stderr)
        time.sleep(args.interval)


if __name__ == "__main__":
    run_agent()
