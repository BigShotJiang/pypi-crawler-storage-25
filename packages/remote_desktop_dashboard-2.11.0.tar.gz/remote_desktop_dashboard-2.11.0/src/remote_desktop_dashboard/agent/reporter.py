"""Send monitoring snapshots to the dashboard API."""

from __future__ import annotations

import httpx

from remote_desktop_dashboard.agent.monitor import MonitorSnapshot, collect_snapshot
from remote_desktop_dashboard.schemas.machine import MachineStatusReport


def build_report(machine_name: str, snapshot: MonitorSnapshot | None = None) -> MachineStatusReport:
    snap = snapshot or collect_snapshot()
    return MachineStatusReport(
        machine_name=machine_name.upper(),
        local_user=snap.local_user,
        rdp_users=snap.rdp_users,
        windows_app_users=snap.windows_app_users,
        mobaxterm_user=snap.mobaxterm_user,
        com_port_user=snap.com_port_user,
        etgui_user=snap.etgui_user,
        camera_user=snap.camera_user,
        camera_tools=snap.camera_tools,
        raw_report=snap.raw,
    )


def post_status(
    base_url: str,
    machine_name: str,
    api_key: str = "",
    timeout: float = 15.0,
) -> dict:
    report = build_report(machine_name)
    url = f"{base_url.rstrip('/')}/api/v1/machines/{machine_name.upper()}/status"
    headers: dict[str, str] = {}
    if api_key:
        headers["X-API-Key"] = api_key
    with httpx.Client(timeout=timeout) as client:
        response = client.post(url, json=report.model_dump(mode="json"), headers=headers)
        response.raise_for_status()
        return response.json()
