"""Windows monitoring agent for ATC machines."""
