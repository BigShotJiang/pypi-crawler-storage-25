"""Windows session and process monitoring."""

from __future__ import annotations

import os
import re
import subprocess
import sys
from dataclasses import dataclass, field
from typing import Any

import psutil

# Process name -> category mapping
ETGUI_NAMES = {"etgui.exe"}
MOBAXTERM_NAMES = {"mobaxterm.exe", "mobaxterm personal edition.exe"}
WINDOWS_APP_NAMES = {
    "msrdc.exe",
    "msrdcw.exe",
    "windowsterminal.exe",
}
RDP_PROCESS_HINTS = {"rdpclip.exe", "rdpinput.exe", "mstsc.exe"}
CAMERA_PROCESS_NAMES = {
    "windowscamera.exe",
    "camera.exe",
    "webcam.exe",
    "obs64.exe",
    "obs32.exe",
    "manycam.exe",
    "yawcam.exe",
}
CAMERA_PYTHON_HINTS = ("opencv", "cv2", "pyqt5", "pyside2", "picamera")
COM_PORT_PROCESS_NAMES = {
    "putty.exe",
    "teraterm.exe",
    "ttermpro.exe",
    "securecrt.exe",
    "hyperterminal.exe",
    "realterm.exe",
    "docklight.exe",
    "hercules.exe",
    "com0com.exe",
}
COM_PORT_CMDLINE_HINTS = ("com", "serial", "\\\\.\\com")


@dataclass
class ProcessInfo:
    name: str
    username: str | None
    pid: int
    cmdline: str


@dataclass
class MonitorSnapshot:
    local_user: str | None = None
    rdp_users: list[str] = field(default_factory=list)
    windows_app_users: list[str] = field(default_factory=list)
    mobaxterm_user: str | None = None
    com_port_user: str | None = None
    etgui_user: str | None = None
    camera_user: str | None = None
    camera_tools: list[str] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)

    def to_report_dict(self) -> dict[str, Any]:
        return {
            "local_user": self.local_user,
            "rdp_users": self.rdp_users,
            "windows_app_users": self.windows_app_users,
            "mobaxterm_user": self.mobaxterm_user,
            "com_port_user": self.com_port_user,
            "etgui_user": self.etgui_user,
            "camera_user": self.camera_user,
            "camera_tools": self.camera_tools,
        }


def _normalize_user(username: str | None) -> str | None:
    if not username:
        return None
    if "\\" in username:
        return username.split("\\", 1)[-1]
    return username


def _iter_processes() -> list[ProcessInfo]:
    results: list[ProcessInfo] = []
    for proc in psutil.process_iter(["pid", "name", "username", "cmdline"]):
        try:
            info = proc.info
            cmdline = " ".join(info.get("cmdline") or [])
            results.append(
                ProcessInfo(
                    name=(info.get("name") or "").lower(),
                    username=_normalize_user(info.get("username")),
                    pid=info["pid"],
                    cmdline=cmdline.lower(),
                )
            )
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return results


def _query_user_sessions() -> list[dict[str, str]]:
    """Parse `query user` output on Windows."""
    if sys.platform != "win32":
        return []
    try:
        out = subprocess.check_output(
            ["query", "user"],
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        return []

    sessions: list[dict[str, str]] = []
    for line in out.splitlines()[1:]:
        line = line.strip()
        if not line:
            continue
        if line.startswith(">"):
            line = line[1:].strip()
        parts = re.split(r"\s{2,}|\s+", line)
        if len(parts) < 4:
            continue
        username = parts[0].lstrip(">")
        session_name = parts[1] if len(parts) > 1 else ""
        state = parts[3] if len(parts) > 3 else ""
        sessions.append(
            {
                "username": _normalize_user(username) or username,
                "session": session_name,
                "state": state,
            }
        )
    return sessions


def _query_session_types() -> dict[str, str]:
    """Map username -> session type using `query session`."""
    if sys.platform != "win32":
        return {}
    try:
        out = subprocess.check_output(
            ["query", "session"],
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        return {}

    mapping: dict[str, str] = {}
    for line in out.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 4:
            continue
        session_name = parts[0].lstrip(">")
        username = parts[1] if parts[1] != "." else ""
        session_type = parts[2] if len(parts) > 2 else ""
        if username and username != "services":
            mapping[_normalize_user(username) or username] = session_type
        if session_name and session_name.isdigit():
            mapping[session_name] = session_type
    return mapping


def _wmi_logged_in_users() -> list[str]:
    if sys.platform != "win32":
        return []
    try:
        import wmi  # type: ignore[import-untyped]

        c = wmi.WMI()
        users: list[str] = []
        for session in c.Win32_LogonSession():
            for assoc in session.associators("Win32_LoggedOnUser"):
                name = getattr(assoc, "Name", None)
                if name:
                    users.append(_normalize_user(name) or name)
        return sorted(set(users))
    except Exception:
        return []


def _owner_for_processes(
    processes: list[ProcessInfo], names: set[str]
) -> str | None:
    for proc in processes:
        if proc.name in names and proc.username:
            return proc.username
    return None


def _owners_for_processes(processes: list[ProcessInfo], names: set[str]) -> list[str]:
    users = {_normalize_user(p.username) for p in processes if p.name in names and p.username}
    return sorted(u for u in users if u)


def _detect_com_port_user(processes: list[ProcessInfo]) -> str | None:
    for proc in processes:
        if proc.name in COM_PORT_PROCESS_NAMES and proc.username:
            return proc.username
        if proc.username and any(h in proc.cmdline for h in COM_PORT_CMDLINE_HINTS):
            if proc.name in MOBAXTERM_NAMES:
                continue
            return proc.username
    return None


def _detect_camera(processes: list[ProcessInfo]) -> tuple[str | None, list[str]]:
    tools: list[str] = []
    user: str | None = None
    for proc in processes:
        matched = False
        if proc.name in CAMERA_PROCESS_NAMES:
            tools.append(proc.name)
            matched = True
        elif proc.name.startswith("python") and any(
            h in proc.cmdline for h in CAMERA_PYTHON_HINTS
        ):
            tools.append(f"python-camera ({proc.pid})")
            matched = True
        if matched and proc.username:
            user = proc.username
    return user, sorted(set(tools))


def collect_snapshot() -> MonitorSnapshot:
    processes = _iter_processes()
    sessions = _query_user_sessions()
    session_types = _query_session_types()

    active_users = [
        s["username"]
        for s in sessions
        if s.get("state", "").lower() in ("active", "running", "connected")
    ]
    wmi_users = _wmi_logged_in_users()

    local_user: str | None = None
    if active_users:
        local_user = active_users[0]
    elif wmi_users:
        local_user = wmi_users[0]
    else:
        local_user = _normalize_user(os.environ.get("USERNAME"))

    rdp_users: set[str] = set()
    windows_app_users: set[str] = set()

    for s in sessions:
        user = s.get("username")
        if not user:
            continue
        sess = (s.get("session") or "").lower()
        stype = session_types.get(user, session_types.get(s.get("session", ""), ""))
        if "rdp" in sess or stype in ("10", "rdp"):
            rdp_users.add(user)
        if any(p.name in WINDOWS_APP_NAMES for p in processes if p.username == user):
            windows_app_users.add(user)

    for proc in processes:
        if proc.name in RDP_PROCESS_HINTS and proc.username:
            rdp_users.add(proc.username)
        if proc.name in WINDOWS_APP_NAMES and proc.username:
            windows_app_users.add(proc.username)

    camera_user, camera_tools = _detect_camera(processes)

    snap = MonitorSnapshot(
        local_user=local_user,
        rdp_users=sorted(rdp_users),
        windows_app_users=sorted(windows_app_users),
        mobaxterm_user=_owner_for_processes(processes, MOBAXTERM_NAMES),
        com_port_user=_detect_com_port_user(processes),
        etgui_user=_owner_for_processes(processes, ETGUI_NAMES),
        camera_user=camera_user,
        camera_tools=camera_tools,
        raw={
            "sessions": sessions,
            "session_types": session_types,
            "wmi_users": wmi_users,
            "process_count": len(processes),
        },
    )
    return snap
