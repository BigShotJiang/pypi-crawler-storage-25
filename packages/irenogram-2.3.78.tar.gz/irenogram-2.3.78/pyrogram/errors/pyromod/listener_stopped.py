
class ListenerStopped(Exception):
    pass