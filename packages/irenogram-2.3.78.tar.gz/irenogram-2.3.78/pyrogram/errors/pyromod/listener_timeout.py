
class ListenerTimeout(Exception):
    pass