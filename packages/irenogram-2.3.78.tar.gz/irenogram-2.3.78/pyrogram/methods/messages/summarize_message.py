
from typing import Optional

import pyrogram
from pyrogram import raw, types


class SummarizeMessage:
    async def summarize_message(
        self: "pyrogram.Client",
        chat_id: str,
        message_id: int,
        translate_to_language_code: Optional[str] = None,
        tone: Optional[str] = None,
    ) -> "types.FormattedText":
        """Summarizes content of the message with non-empty summary_language_code.

        .. include:: /_includes/usable-by/users.rst

        Parameters:
            chat_id (``int`` | ``str``):
                Unique identifier (int) or username (str) of the target chat.
                For your personal cloud (Saved Messages) you can simply use "me" or "self".
                For a contact that exists in your Telegram address book you can use his phone number (str).

            message_id (``int``):
                Identifier of the message.

            translate_to_language_code (``str``, *optional*):
                Language code of the language to which the message is translated.
                Must be one of "af", "sq", "am", "ar", "hy", "az", "eu", "be", "bn", "bs", "bg", "ca", "ceb", "zh-CN", "zh", "zh-Hans", "zh-TW", "zh-Hant", "co", "hr", "cs", "da", "nl", "en", "eo", "et",
                "fi", "fr", "fy", "gl", "ka", "de", "el", "gu", "ht", "ha", "haw", "he", "iw", "hi", "hmn", "hu", "is", "ig", "id", "in", "ga", "it", "ja", "jv", "kn", "kk", "km", "rw", "ko",
                "ku", "ky", "lo", "la", "lv", "lt", "lb", "mk", "mg", "ms", "ml", "mt", "mi", "mr", "mn", "my", "ne", "no", "ny", "or", "ps", "fa", "pl", "pt", "pa", "ro", "ru", "sm", "gd", "sr",
                "st", "sn", "sd", "si", "sk", "sl", "so", "es", "su", "sw", "sv", "tl", "tg", "ta", "tt", "te", "th", "tr", "tk", "uk", "ur", "ug", "uz", "vi", "cy", "xh", "yi", "ji", "yo", "zu"
                Defaults to the client's language code.

            tone (``str``, *optional*):
                Tone of the summarization.
                Must be one of "formal", "neutral", "casual".

        Returns:
            :obj:`~pyrogram.types.FormattedText`: On success, information about the summarized text is returned.
        """
        r = await self.invoke(
            raw.functions.messages.SummarizeText(
                peer=await self.resolve_peer(chat_id),
                id=message_id,
                to_lang=translate_to_language_code or self.lang_code,
                tone=tone
            )
        )

        return types.FormattedText._parse(self, r)
