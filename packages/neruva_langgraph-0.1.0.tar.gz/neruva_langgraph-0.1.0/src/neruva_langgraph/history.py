"""Optional message-history wrapper for LangGraph + LangChain mixing.

LangGraph graphs are commonly built on top of LangChain Runnables. When
a node calls a chat model directly (instead of going through the graph
state), you may want per-thread chat history that's still substrate-
backed. This wrapper mirrors `neruva_langchain.NeruvaChatMessageHistory`
but lives here so consumers of `neruva-langgraph` don't have to install
the LangChain adapter package too.

If `langchain_core` is not installed, importing this module is a no-op
and `NeruvaMessageHistory` will not be available.
"""
from __future__ import annotations

from typing import List, Optional

try:
    from langchain_core.chat_history import BaseChatMessageHistory
    from langchain_core.messages import (
        AIMessage,
        BaseMessage,
        HumanMessage,
        SystemMessage,
    )
    _HAS_LC = True
except Exception:  # pragma: no cover - optional dep
    BaseChatMessageHistory = object  # type: ignore[misc,assignment]
    AIMessage = HumanMessage = SystemMessage = BaseMessage = None  # type: ignore[assignment]
    _HAS_LC = False

from neruva_langgraph._client import NeruvaClient


_KIND_USER = "user_prompt"
_KIND_AI = "assistant_turn"
_KIND_SYSTEM = "llm_turn"


class NeruvaMessageHistory(BaseChatMessageHistory):  # type: ignore[misc]
    """BaseChatMessageHistory backed by Neruva Records.

    Identical semantics to neruva_langchain.NeruvaChatMessageHistory --
    duplicated here so neruva-langgraph users only need one install."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        namespace: str = "agent",
        user_id: Optional[str] = None,
        load_limit: int = 200,
    ) -> None:
        if not _HAS_LC:
            raise RuntimeError(
                "NeruvaMessageHistory requires langchain_core. "
                "Install: pip install langchain-core"
            )
        self._client = NeruvaClient(api_key=api_key, base_url=base_url)
        self.namespace = namespace
        self.user_id = user_id
        self.load_limit = int(load_limit)

    @property
    def messages(self) -> List["BaseMessage"]:
        result = self._client.records_timeline(
            self.namespace,
            limit=self.load_limit,
            kinds=[_KIND_USER, _KIND_AI, _KIND_SYSTEM],
        )
        items = list(result.get("records") or result.get("items") or [])
        items.reverse()
        out: List[BaseMessage] = []
        for it in items:
            kind = str(it.get("kind", ""))
            text = str(it.get("text", ""))
            if kind == _KIND_USER:
                out.append(HumanMessage(content=text))
            elif kind == _KIND_AI:
                out.append(AIMessage(content=text))
            elif kind == _KIND_SYSTEM:
                out.append(SystemMessage(content=text))
        return out

    def add_message(self, message: "BaseMessage") -> None:
        if isinstance(message, HumanMessage):
            self._ingest(message.content, _KIND_USER)
        elif isinstance(message, AIMessage):
            self._ingest(message.content, _KIND_AI)
        elif isinstance(message, SystemMessage):
            self._ingest(message.content, _KIND_SYSTEM)
        else:
            self._ingest(
                str(message.content),
                _KIND_SYSTEM,
                extra_tags=[f"type:{type(message).__name__}"],
            )

    def clear(self) -> None:
        # See NeruvaChatMessageHistory: intentional no-op to avoid
        # accidental context loss. Use records_forget for hard delete.
        pass

    def _ingest(
        self,
        text: str,
        kind: str,
        extra_tags: Optional[List[str]] = None,
    ) -> None:
        if not text:
            return
        tags = ["langgraph", f"kind:{kind}"] + list(extra_tags or [])
        self._client.agent_remember(
            text=str(text),
            namespace=self.namespace,
            tags=tags,
            kind=kind,
            user_id=self.user_id,
        )
