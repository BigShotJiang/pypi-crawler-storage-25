"""Multi-namespace key-value store for LangGraph's BaseStore.

LangGraph's `langgraph.store.base.BaseStore` is the cross-thread memory
abstraction. Keys are tuples (namespace tuple, key), values are dicts.

Routing semantics:

  * LangGraph namespace tuple  -> joined with "/" into a Records namespace
                                  prefixed by `namespace_prefix`
  * LangGraph key              -> Records tag "k:<key>"
  * LangGraph value (dict)     -> meta["value"]; text field is a short summary

Get / list / search all map onto records_query + records_timeline.
Vector / semantic search uses agent_recall under the hood for queries.

Usage:

    from langgraph.store.base import BaseStore
    from neruva_langgraph import NeruvaContextStore

    store = NeruvaContextStore(api_key="nv_...")
    graph = builder.compile(store=store)
"""
from __future__ import annotations

import json
from typing import Any, Dict, Iterable, List, Optional, Tuple

from neruva_langgraph._client import NeruvaClient


# We try to import the LangGraph BaseStore + Item types. If they're not
# importable (older or newer LangGraph), we fall back to a duck-typed
# class that still implements the protocol. Tests in the consuming graph
# will catch shape mismatches.
try:  # pragma: no cover -- import shim
    from langgraph.store.base import BaseStore, Item  # type: ignore
    _HAS_STORE = True
except Exception:  # pragma: no cover -- import shim
    BaseStore = object  # type: ignore[misc,assignment]
    Item = dict  # type: ignore[misc,assignment]
    _HAS_STORE = False


_KIND_KV = "kv_store"
_TAG_KEY_PREFIX = "k:"


def _ns_to_str(namespace: Tuple[str, ...]) -> str:
    """Flatten a LangGraph namespace tuple into a Records namespace
    string. Records namespaces are flat strings, so we join with '/'."""
    return "/".join(str(p) for p in (namespace or ())) or "default"


def _make_item(namespace: Tuple[str, ...], key: str, value: Dict[str, Any],
               created_at: Any = None, updated_at: Any = None) -> Any:
    """Build a LangGraph Item if the real type is importable; else a
    dict that quacks the same."""
    if _HAS_STORE:
        try:
            return Item(  # type: ignore[call-arg]
                namespace=namespace,
                key=key,
                value=value,
                created_at=created_at,
                updated_at=updated_at,
            )
        except Exception:
            pass
    return {
        "namespace": namespace,
        "key": key,
        "value": value,
        "created_at": created_at,
        "updated_at": updated_at,
    }


class NeruvaContextStore(BaseStore):  # type: ignore[misc]
    """LangGraph-compatible BaseStore backed by Neruva Records.

    Cross-thread, multi-namespace key-value store. Values must be
    JSON-serializable dicts (LangGraph's BaseStore contract)."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        namespace_prefix: str = "store/",
        user_id: Optional[str] = None,
        load_limit: int = 200,
    ) -> None:
        self._client = NeruvaClient(api_key=api_key, base_url=base_url)
        self._namespace_prefix = namespace_prefix
        self._user_id = user_id
        self._load_limit = int(load_limit)

    # ---- helpers ------------------------------------------------------

    def _ns(self, namespace: Tuple[str, ...]) -> str:
        return f"{self._namespace_prefix}{_ns_to_str(namespace)}"

    def _record_to_item(self, namespace: Tuple[str, ...], rec: Dict[str, Any]) -> Any:
        meta = rec.get("meta") or {}
        key = ""
        for t in (rec.get("tags") or []):
            t = str(t)
            if t.startswith(_TAG_KEY_PREFIX):
                key = t[len(_TAG_KEY_PREFIX):]
                break
        value = meta.get("value") or {}
        return _make_item(
            namespace=namespace,
            key=key or str(rec.get("id", "")),
            value=value if isinstance(value, dict) else {"value": value},
            created_at=rec.get("ts"),
            updated_at=rec.get("ts"),
        )

    # ---- BaseStore interface ------------------------------------------

    def get(self, namespace: Tuple[str, ...], key: str) -> Optional[Any]:
        """Return the most-recent Item for (namespace, key), or None."""
        ns = self._ns(namespace)
        result = self._client.records_query(
            namespace=ns,
            top_k=1,
            kinds=[_KIND_KV],
            tags=[f"{_TAG_KEY_PREFIX}{key}"],
        )
        recs = result.get("records") or result.get("items") or []
        if not recs:
            return None
        return self._record_to_item(namespace, recs[0])

    def put(
        self,
        namespace: Tuple[str, ...],
        key: str,
        value: Dict[str, Any],
        index: Optional[Any] = None,
    ) -> None:
        """Upsert (namespace, key) -> value. Records is append-only, so
        a put writes a fresh record; get() returns the most recent."""
        if not isinstance(value, dict):
            raise TypeError(
                "NeruvaContextStore.put requires a dict value (LangGraph "
                f"BaseStore contract); got {type(value).__name__}."
            )
        ns = self._ns(namespace)
        # Human-readable summary; truncate to keep records skim-friendly.
        try:
            preview = json.dumps(value)[:500]
        except Exception:
            preview = str(value)[:500]
        text = f"kv key={key} value={preview}"
        meta_blob = {"value": value, "key": key, "namespace": list(namespace)}
        tags = ["langgraph-store", f"{_TAG_KEY_PREFIX}{key}"]
        self._client.agent_remember(
            text=text,
            namespace=ns,
            tags=tags,
            kind=_KIND_KV,
            user_id=self._user_id,
            meta=meta_blob,
        )

    def delete(self, namespace: Tuple[str, ...], key: str) -> None:
        """Records is append-only; we mark the key with a tombstone
        record. get() honors the most-recent write, so a tombstone
        effectively hides the value. Hard delete requires records_forget
        called directly via the REST API."""
        ns = self._ns(namespace)
        self._client.agent_remember(
            text=f"tombstone key={key}",
            namespace=ns,
            tags=["langgraph-store", f"{_TAG_KEY_PREFIX}{key}", "tombstone"],
            kind=_KIND_KV,
            user_id=self._user_id,
            meta={"value": None, "key": key, "tombstone": True},
        )

    def search(
        self,
        namespace_prefix: Tuple[str, ...],
        *,
        query: Optional[str] = None,
        filter: Optional[Dict[str, Any]] = None,
        limit: int = 10,
        offset: int = 0,
    ) -> List[Any]:
        """Semantic search over a namespace prefix.

        If `query` is provided we go through agent_recall (vector +
        federation). Otherwise we list the timeline and return the most
        recent N matching items."""
        ns = self._ns(namespace_prefix)
        if query:
            result = self._client.agent_recall(
                query=query,
                namespace=ns,
                top_k=int(limit) + int(offset),
                user_id=self._user_id,
            )
            recs = result.get("records") or []
        else:
            result = self._client.records_timeline(
                namespace=ns,
                limit=int(limit) + int(offset),
                kinds=[_KIND_KV],
            )
            recs = result.get("records") or result.get("items") or []
        items: List[Any] = []
        seen_keys = set()
        for r in recs:
            # filter out tombstones
            tags = [str(t) for t in (r.get("tags") or [])]
            if "tombstone" in tags:
                continue
            item = self._record_to_item(namespace_prefix, r)
            # dedupe by key (records is append-only)
            k = getattr(item, "key", None) or item.get("key")  # type: ignore[attr-defined]
            if k in seen_keys:
                continue
            seen_keys.add(k)
            items.append(item)
        return items[offset : offset + limit]

    def list_namespaces(
        self,
        *,
        prefix: Optional[Tuple[str, ...]] = None,
        suffix: Optional[Tuple[str, ...]] = None,
        max_depth: Optional[int] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Tuple[str, ...]]:
        """Return distinct namespace tuples seen under `prefix`.

        Records exposes a namespace per logical thread; we can't
        enumerate namespaces server-side without an index endpoint.
        For now we return [prefix] (or [()] if no prefix). Callers
        that need full enumeration should track namespaces app-side."""
        return [prefix or ()]

    # ---- async stubs --------------------------------------------------

    async def aget(self, namespace: Tuple[str, ...], key: str) -> Optional[Any]:
        return self.get(namespace, key)

    async def aput(
        self,
        namespace: Tuple[str, ...],
        key: str,
        value: Dict[str, Any],
        index: Optional[Any] = None,
    ) -> None:
        self.put(namespace, key, value, index=index)

    async def adelete(self, namespace: Tuple[str, ...], key: str) -> None:
        self.delete(namespace, key)

    async def asearch(
        self,
        namespace_prefix: Tuple[str, ...],
        *,
        query: Optional[str] = None,
        filter: Optional[Dict[str, Any]] = None,
        limit: int = 10,
        offset: int = 0,
    ) -> List[Any]:
        return self.search(
            namespace_prefix,
            query=query,
            filter=filter,
            limit=limit,
            offset=offset,
        )

    async def alist_namespaces(
        self,
        *,
        prefix: Optional[Tuple[str, ...]] = None,
        suffix: Optional[Tuple[str, ...]] = None,
        max_depth: Optional[int] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Tuple[str, ...]]:
        return self.list_namespaces(
            prefix=prefix,
            suffix=suffix,
            max_depth=max_depth,
            limit=limit,
            offset=offset,
        )

    # BaseStore in newer LangGraph requires batch/abatch. Default impl
    # delegates to per-op methods. We provide naive serial fallbacks.

    def batch(self, ops: Iterable[Any]) -> List[Any]:  # pragma: no cover - shape varies
        return [self._dispatch_op(op) for op in ops]

    async def abatch(self, ops: Iterable[Any]) -> List[Any]:  # pragma: no cover - shape varies
        return [self._dispatch_op(op) for op in ops]

    def _dispatch_op(self, op: Any) -> Any:  # pragma: no cover - shape varies
        # LangGraph ops are dataclasses with .namespace + .key + etc.
        # We duck-type for forward-compat.
        op_type = type(op).__name__.lower()
        if "get" in op_type:
            return self.get(op.namespace, op.key)
        if "put" in op_type:
            return self.put(op.namespace, op.key, op.value)
        if "search" in op_type:
            return self.search(
                getattr(op, "namespace_prefix", ()),
                query=getattr(op, "query", None),
                filter=getattr(op, "filter", None),
                limit=getattr(op, "limit", 10),
                offset=getattr(op, "offset", 0),
            )
        if "list" in op_type:
            return self.list_namespaces(
                prefix=getattr(op, "prefix", None),
                suffix=getattr(op, "suffix", None),
                max_depth=getattr(op, "max_depth", None),
                limit=getattr(op, "limit", 100),
                offset=getattr(op, "offset", 0),
            )
        raise NotImplementedError(f"Unsupported store op: {op_type}")
