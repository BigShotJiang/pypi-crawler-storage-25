"""LangGraph integration for Neruva agent memory.

Two primary plug points covering the LangGraph memory surface:

  NeruvaCheckpointSaver  -- subclass of langgraph.checkpoint.base
                            .BaseCheckpointSaver. Persists graph
                            checkpoints into Records substrate, one
                            namespace per thread_id.

  NeruvaContextStore     -- subclass of langgraph.store.base.BaseStore.
                            Cross-thread, multi-namespace KV store
                            backed by Records.

Optional, for graphs that mix raw LangChain calls inside nodes:

  NeruvaMessageHistory   -- BaseChatMessageHistory mirror of the same
                            wrapper in neruva-langchain.

Install:
    pip install neruva-langgraph

Usage (3 lines):
    from langgraph.graph import StateGraph
    from neruva_langgraph import NeruvaCheckpointSaver
    graph = builder.compile(checkpointer=NeruvaCheckpointSaver(api_key="nv_..."))
"""
from neruva_langgraph.checkpoint import NeruvaCheckpointSaver
from neruva_langgraph.store import NeruvaContextStore

try:
    from neruva_langgraph.history import NeruvaMessageHistory
    _OPTIONAL = ["NeruvaMessageHistory"]
except Exception:  # pragma: no cover - optional dep
    _OPTIONAL = []

__all__ = [
    "NeruvaCheckpointSaver",
    "NeruvaContextStore",
] + _OPTIONAL

__version__ = "0.1.0"
