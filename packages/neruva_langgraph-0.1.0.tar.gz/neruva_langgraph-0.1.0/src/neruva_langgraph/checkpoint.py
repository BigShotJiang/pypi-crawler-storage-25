"""Drop-in BaseCheckpointSaver for LangGraph.

Each LangGraph graph checkpoint is persisted as one Neruva Record with
kind="checkpoint", namespace=thread_id (so each conversation thread maps
to one Records namespace), serialized channel values + versions stored
in the record metadata.

Routing semantics:

  * thread_id           -> Records namespace
  * checkpoint_id       -> Records record id (returned by agent_remember)
  * channel_values      -> serialized as JSON inside record meta
  * parent checkpoint   -> meta["parent_checkpoint_id"]
  * pending writes      -> kind="checkpoint_write", tagged with the parent

Survives process restart. Multi-thread by construction (one namespace
per thread). Reads come from records_timeline (most-recent first) so
list() is the same call that the parent class expects.

Usage:

    from langgraph.graph import StateGraph
    from neruva_langgraph import NeruvaCheckpointSaver

    saver = NeruvaCheckpointSaver(api_key="nv_...")
    graph = builder.compile(checkpointer=saver)
    graph.invoke({"input": "hi"}, config={"configurable": {"thread_id": "alice"}})
"""
from __future__ import annotations

import json
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional, Sequence, Tuple

from langgraph.checkpoint.base import (
    BaseCheckpointSaver,
    ChannelVersions,
    Checkpoint,
    CheckpointMetadata,
    CheckpointTuple,
)

from neruva_langgraph._client import NeruvaClient


# Canonical Records kinds for LangGraph checkpoints. Stays inside the
# Records kind vocabulary so dashboards / cortex agents render them.
_KIND_CHECKPOINT = "checkpoint"
_KIND_CHECKPOINT_WRITE = "checkpoint_write"
_TAG_PREFIX_THREAD = "thread:"
_TAG_PREFIX_NS = "ns:"


def _ns_from_config(config: Dict[str, Any], default: str = "default") -> str:
    """LangGraph carries thread_id under config['configurable']['thread_id']."""
    cfg = (config or {}).get("configurable", {}) or {}
    return str(cfg.get("thread_id") or default)


def _checkpoint_ns_from_config(config: Dict[str, Any]) -> str:
    cfg = (config or {}).get("configurable", {}) or {}
    return str(cfg.get("checkpoint_ns") or "")


def _checkpoint_id_from_config(config: Dict[str, Any]) -> Optional[str]:
    cfg = (config or {}).get("configurable", {}) or {}
    cid = cfg.get("checkpoint_id")
    return str(cid) if cid else None


class NeruvaCheckpointSaver(BaseCheckpointSaver):
    """LangGraph-compatible checkpoint saver backed by Neruva Records.

    Each thread_id maps to one Records namespace. Each saved checkpoint
    is one Record with the checkpoint blob stored in meta + a human-
    readable summary in the text field so dashboards remain useful."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        namespace_prefix: str = "",
        user_id: Optional[str] = None,
        load_limit: int = 200,
        *,
        serde: Any = None,
    ) -> None:
        # Pass through serde to BaseCheckpointSaver so it owns the
        # serializer protocol; default JsonPlusSerializer covers most
        # graph state types.
        super().__init__(serde=serde) if serde is not None else super().__init__()
        self._client = NeruvaClient(api_key=api_key, base_url=base_url)
        self._namespace_prefix = namespace_prefix
        self._user_id = user_id
        self._load_limit = int(load_limit)

    # ---- namespace helpers --------------------------------------------

    def _ns(self, config: Dict[str, Any]) -> str:
        return f"{self._namespace_prefix}{_ns_from_config(config)}"

    # ---- canonical (de)serialization -----------------------------------

    def _dump(self, obj: Any) -> Any:
        """Best-effort JSON-safe encoding of arbitrary state."""
        try:
            return json.loads(json.dumps(obj, default=str))
        except Exception:
            return str(obj)

    # ---- BaseCheckpointSaver interface (sync) --------------------------

    def get_tuple(self, config: Dict[str, Any]) -> Optional[CheckpointTuple]:
        """Return the most-recent checkpoint for the thread (or a
        specific checkpoint_id if the caller pinned one)."""
        ns = self._ns(config)
        pinned_id = _checkpoint_id_from_config(config)
        result = self._client.records_timeline(
            ns,
            limit=self._load_limit,
            kinds=[_KIND_CHECKPOINT],
        )
        items = list(result.get("records") or result.get("items") or [])
        if not items:
            return None
        # records_timeline is most-recent-first; pick the head unless
        # the caller asked for a specific checkpoint_id.
        chosen: Optional[dict] = None
        for it in items:
            if pinned_id is None or str(it.get("id")) == pinned_id:
                chosen = it
                break
        if chosen is None:
            return None
        meta = chosen.get("meta") or {}
        try:
            checkpoint: Checkpoint = meta.get("checkpoint") or {}
            cp_meta: CheckpointMetadata = meta.get("checkpoint_meta") or {}
        except Exception:
            return None
        parent_id = meta.get("parent_checkpoint_id")
        parent_config = None
        if parent_id:
            parent_config = {
                "configurable": {
                    "thread_id": _ns_from_config(config),
                    "checkpoint_ns": _checkpoint_ns_from_config(config),
                    "checkpoint_id": parent_id,
                }
            }
        new_config = {
            "configurable": {
                "thread_id": _ns_from_config(config),
                "checkpoint_ns": _checkpoint_ns_from_config(config),
                "checkpoint_id": str(chosen.get("id")),
            }
        }
        return CheckpointTuple(
            config=new_config,
            checkpoint=checkpoint,
            metadata=cp_meta,
            parent_config=parent_config,
        )

    def list(
        self,
        config: Optional[Dict[str, Any]],
        *,
        filter: Optional[Dict[str, Any]] = None,
        before: Optional[Dict[str, Any]] = None,
        limit: Optional[int] = None,
    ) -> Iterator[CheckpointTuple]:
        """Iterate checkpoints for the thread (most-recent first).

        The LangGraph `before` / `filter` semantics are honoured best-
        effort -- Records doesn't have a native 'before checkpoint_id'
        cursor, so this client-side filters on the returned timeline."""
        ns = self._ns(config or {})
        cap = int(limit or self._load_limit)
        result = self._client.records_timeline(
            ns,
            limit=max(cap, self._load_limit),
            kinds=[_KIND_CHECKPOINT],
        )
        items = list(result.get("records") or result.get("items") or [])
        before_id: Optional[str] = None
        if before:
            before_id = _checkpoint_id_from_config(before)
        seen_before = before_id is None
        emitted = 0
        for it in items:
            cid = str(it.get("id"))
            if not seen_before:
                if cid == before_id:
                    seen_before = True
                continue
            meta = it.get("meta") or {}
            checkpoint: Checkpoint = meta.get("checkpoint") or {}
            cp_meta: CheckpointMetadata = meta.get("checkpoint_meta") or {}
            if filter:
                # Filter on metadata k/v
                if not all(cp_meta.get(k) == v for k, v in filter.items()):
                    continue
            parent_id = meta.get("parent_checkpoint_id")
            parent_config = None
            if parent_id:
                parent_config = {
                    "configurable": {
                        "thread_id": _ns_from_config(config or {}),
                        "checkpoint_ns": _checkpoint_ns_from_config(config or {}),
                        "checkpoint_id": parent_id,
                    }
                }
            new_config = {
                "configurable": {
                    "thread_id": _ns_from_config(config or {}),
                    "checkpoint_ns": _checkpoint_ns_from_config(config or {}),
                    "checkpoint_id": cid,
                }
            }
            yield CheckpointTuple(
                config=new_config,
                checkpoint=checkpoint,
                metadata=cp_meta,
                parent_config=parent_config,
            )
            emitted += 1
            if emitted >= cap:
                return

    def put(
        self,
        config: Dict[str, Any],
        checkpoint: Checkpoint,
        metadata: CheckpointMetadata,
        new_versions: ChannelVersions,
    ) -> Dict[str, Any]:
        """Persist a checkpoint. Returns the updated config carrying the
        new checkpoint_id."""
        ns = self._ns(config)
        thread_id = _ns_from_config(config)
        parent_id = _checkpoint_id_from_config(config)
        # Human-readable text summary so Records dashboards stay useful.
        summary_lines = [
            f"checkpoint thread={thread_id}",
            f"channels={list((checkpoint or {}).get('channel_values', {}).keys())}",
        ]
        text = "\n".join(summary_lines)
        meta_blob: Dict[str, Any] = {
            "checkpoint": self._dump(checkpoint),
            "checkpoint_meta": self._dump(metadata),
            "new_versions": self._dump(new_versions),
            "parent_checkpoint_id": parent_id,
            "checkpoint_ns": _checkpoint_ns_from_config(config),
        }
        tags = [
            "langgraph",
            f"{_TAG_PREFIX_THREAD}{thread_id}",
            f"{_TAG_PREFIX_NS}{ns}",
        ]
        resp = self._client.agent_remember(
            text=text,
            namespace=ns,
            tags=tags,
            kind=_KIND_CHECKPOINT,
            user_id=self._user_id,
            meta=meta_blob,
        )
        # agent_remember returns the record id (key varies by build);
        # accept the common shapes.
        new_id = (
            resp.get("id")
            or resp.get("record_id")
            or (resp.get("record") or {}).get("id")
            or ""
        )
        return {
            "configurable": {
                "thread_id": thread_id,
                "checkpoint_ns": _checkpoint_ns_from_config(config),
                "checkpoint_id": str(new_id),
            }
        }

    def put_writes(
        self,
        config: Dict[str, Any],
        writes: Sequence[Tuple[str, Any]],
        task_id: str,
        task_path: str = "",
    ) -> None:
        """Persist pending channel writes for a task in this checkpoint."""
        ns = self._ns(config)
        thread_id = _ns_from_config(config)
        cp_id = _checkpoint_id_from_config(config)
        text = f"writes task={task_id} count={len(writes)}"
        meta_blob = {
            "writes": [(c, self._dump(v)) for (c, v) in writes],
            "task_id": task_id,
            "task_path": task_path,
            "checkpoint_id": cp_id,
            "checkpoint_ns": _checkpoint_ns_from_config(config),
        }
        tags = [
            "langgraph",
            f"{_TAG_PREFIX_THREAD}{thread_id}",
            f"task:{task_id}",
            f"checkpoint:{cp_id or 'none'}",
        ]
        self._client.agent_remember(
            text=text,
            namespace=ns,
            tags=tags,
            kind=_KIND_CHECKPOINT_WRITE,
            user_id=self._user_id,
            meta=meta_blob,
        )

    # ---- async stubs --------------------------------------------------
    # LangGraph expects async variants. We provide thin wrappers around
    # the sync calls. Heavy callers should still prefer sync because the
    # underlying httpx.Client is synchronous; switching to AsyncClient
    # is a future enhancement.

    async def aget_tuple(self, config: Dict[str, Any]) -> Optional[CheckpointTuple]:
        return self.get_tuple(config)

    async def alist(
        self,
        config: Optional[Dict[str, Any]],
        *,
        filter: Optional[Dict[str, Any]] = None,
        before: Optional[Dict[str, Any]] = None,
        limit: Optional[int] = None,
    ) -> AsyncIterator[CheckpointTuple]:
        for t in self.list(config, filter=filter, before=before, limit=limit):
            yield t

    async def aput(
        self,
        config: Dict[str, Any],
        checkpoint: Checkpoint,
        metadata: CheckpointMetadata,
        new_versions: ChannelVersions,
    ) -> Dict[str, Any]:
        return self.put(config, checkpoint, metadata, new_versions)

    async def aput_writes(
        self,
        config: Dict[str, Any],
        writes: Sequence[Tuple[str, Any]],
        task_id: str,
        task_path: str = "",
    ) -> None:
        self.put_writes(config, writes, task_id, task_path)
