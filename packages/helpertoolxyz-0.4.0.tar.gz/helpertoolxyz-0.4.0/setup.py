from setuptools import setup, find_packages

setup(
    name="helpertoolxyz",
    version="0.4.0",
    packages=find_packages(),
    description="A curated collection.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering",
    ],
)
