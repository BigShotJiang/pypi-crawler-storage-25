"""Core module containing curated import strings and code templates by topic."""


class _Get:
    """Namespace for categorized import and code helpers."""

    def libs(self):
        """All commonly used imports for data science, ML, stats, and visualization."""
        print("""\
import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import seaborn as sns

from scipy import stats
from scipy.stats import norm                  # Z-test (normal distribution)
from scipy.stats import t                     # t-test (t-distribution)
from scipy.stats import binom                 # binomial distribution
from scipy.stats import poisson               # poisson distribution
from scipy.stats import bernoulli             # bernoulli distribution
from scipy.optimize import minimize           # optimization
from scipy.special import factorial           # factorial function
from numpy import maximum                     # element-wise max

from statistics import stdev                  # sample standard deviation

import statsmodels.api as sm
import statsmodels.formula.api as smf         # smf.ols(), smf.logit()
from statsmodels.formula.api import ols       # for ANOVA
from statsmodels.stats.proportion import proportions_ztest  # proportion z-test
from statsmodels.stats.outliers_influence import variance_inflation_factor  # VIF
from statsmodels.tools.tools import add_constant
import statsmodels.stats.multicomp as mc      # multiple comparison (Tukey)
from statsmodels.multivariate.manova import MANOVA  # MANOVA

import sklearn.linear_model as lm
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge, RidgeCV
from sklearn.linear_model import Lasso, LassoCV
from sklearn.linear_model import LogisticRegression

from sklearn import preprocessing
from sklearn.preprocessing import scale
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder

from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score

from sklearn.metrics import mean_squared_error
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score""")

    def hypothesis(self):
        """Hypothesis testing — all test types with examples."""
        print("""\
## ============================================================
## ALL HYPOTHESIS TESTING CODES - LAB 4 TO LAB 7
## ============================================================

import numpy as np
from scipy import stats
from scipy.stats import norm
from scipy.stats import t
from statistics import stdev
from statsmodels.stats.proportion import proportions_ztest


## ============================================================
## 1. ONE-SAMPLE Z-TEST (TWO-SIDED)
##    Population SD (sigma) KNOWN
##    Keywords: "differ", "same", "equal", "changed"
## ============================================================

mu = 84
xbar = 81.5
sigma = 10
n = 75
alpha = 0.01

se = sigma / np.sqrt(n)
Z_cal = (xbar - mu) / se

Z_pos = norm.ppf(1 - alpha/2)
Z_neg = norm.ppf(alpha/2)

print("=== 1. One-Sample Z-Test (Two-Sided) ===")
print(f"Z_cal = {Z_cal}")
print(f"Z_table = [{Z_neg}, {Z_pos}]")
print(f"p-value = {norm.cdf(Z_cal)}")
print(f"CI = [{mu + Z_neg * se}, {mu + Z_pos * se}]")
# Accept H0 if |Z_cal| < |Z_table|
# Accept H0 if p-value > alpha
# Accept H0 if xbar inside CI


## ============================================================
## 2. ONE-SAMPLE Z-TEST (ONE-SIDED LEFT)
##    Keywords: "less", "lower", "decreased"
## ============================================================

mu = 14500
xbar = 13000
sigma = 2100
n = 25
alpha = 0.01

se = sigma / np.sqrt(n)
Z_cal = (xbar - mu) / se

Z_neg = norm.ppf(alpha)

print("=== 2. One-Sample Z-Test (One-Sided Left) ===")
print(f"Z_cal = {Z_cal}")
print(f"Z_neg = {Z_neg}")
print(f"p-value = {norm.cdf(Z_cal)}")
print(f"Boundary = {mu + Z_neg * se}")
# Reject H0 if Z_cal < Z_neg
# Reject H0 if p-value < alpha
# Reject H0 if xbar < boundary


## ============================================================
## 3. ONE-SAMPLE Z-TEST (ONE-SIDED RIGHT)
##    Keywords: "greater", "higher", "increased"
## ============================================================

mu = 50
xbar = 55
sigma = 10
n = 36
alpha = 0.05

se = sigma / np.sqrt(n)
Z_cal = (xbar - mu) / se

Z_pos = norm.ppf(1 - alpha)

print("=== 3. One-Sample Z-Test (One-Sided Right) ===")
print(f"Z_cal = {Z_cal}")
print(f"Z_pos = {Z_pos}")
print(f"p-value = {1 - norm.cdf(Z_cal)}")
print(f"Boundary = {mu + Z_pos * se}")
# Reject H0 if Z_cal > Z_pos
# Reject H0 if p-value < alpha
# Reject H0 if xbar > boundary


## ============================================================
## 4. ONE-SAMPLE t-TEST (TWO-SIDED)
##    Population SD UNKNOWN, use sample SD
##    Keywords: "differ", "same", "equal"
## ============================================================

mu = 100
xbar = 95.8
s = 17.5
n = 100
df = n - 1
alpha = 0.05

se = s / np.sqrt(n)
t_cal = (xbar - mu) / se

t_pos = t.ppf(1 - alpha/2, df)
t_neg = t.ppf(alpha/2, df)

print("=== 4. One-Sample t-Test (Two-Sided) ===")
print(f"t_cal = {t_cal}")
print(f"t_table = [{t_neg}, {t_pos}]")
print(f"p-value = {t.cdf(t_cal, df) * 2}")
print(f"CI = [{mu + t_neg * se}, {mu + t_pos * se}]")
# Reject H0 if |t_cal| > |t_table|
# Reject H0 if p-value < alpha
# Reject H0 if xbar outside CI


## ============================================================
## 5. ONE-SAMPLE t-TEST (ONE-SIDED LEFT)
##    Keywords: "less", "lower", "decreased"
## ============================================================

mu = 100
xbar = 95.8
s = 17.5
n = 100
df = n - 1
alpha = 0.05

se = s / np.sqrt(n)
t_cal = (xbar - mu) / se

t_neg = t.ppf(alpha, df)

print("=== 5. One-Sample t-Test (One-Sided Left) ===")
print(f"t_cal = {t_cal}")
print(f"t_neg = {t_neg}")
print(f"p-value = {t.cdf(t_cal, df)}")
print(f"Boundary = {mu + t_neg * se}")
# Reject H0 if t_cal < t_neg
# Reject H0 if p-value < alpha
# Reject H0 if xbar < boundary


## ============================================================
## 6. ONE-SAMPLE t-TEST (ONE-SIDED RIGHT)
##    Keywords: "greater", "higher", "increased"
## ============================================================

mu = 100
xbar = 105
s = 17.5
n = 100
df = n - 1
alpha = 0.05

se = s / np.sqrt(n)
t_cal = (xbar - mu) / se

t_pos = t.ppf(1 - alpha, df)

print("=== 6. One-Sample t-Test (One-Sided Right) ===")
print(f"t_cal = {t_cal}")
print(f"t_pos = {t_pos}")
print(f"p-value = {1 - t.cdf(t_cal, df)}")
print(f"Boundary = {mu + t_pos * se}")
# Reject H0 if t_cal > t_pos
# Reject H0 if p-value < alpha
# Reject H0 if xbar > boundary


## ============================================================
## 7. ONE-SAMPLE t-TEST USING BUILT-IN (ttest_1samp)
##    When you have RAW DATA (not xbar and s)
## ============================================================

X = np.array([10, 12, 13, 14, 15, 2, 7, 8])

print("=== 7. ttest_1samp (Built-in) ===")
print("Two-sided:", stats.ttest_1samp(X, popmean=12, alternative='two-sided'))
print("Left:     ", stats.ttest_1samp(X, popmean=12, alternative='less'))
print("Right:    ", stats.ttest_1samp(X, popmean=12, alternative='greater'))
# Reject H0 if pvalue < alpha


## ============================================================
## 8. ONE-SAMPLE PROPORTION Z-TEST (TWO-SIDED)
##    Keywords: "differ", "same", "equal"
## ============================================================

p = 0.15
pbar = 22 / 120
n = 120
alpha = 0.02

se = np.sqrt((p * (1 - p)) / n)
Z_cal = (pbar - p) / se

Z_pos = norm.ppf(1 - alpha/2)
Z_neg = norm.ppf(alpha/2)

print("=== 8. One-Sample Proportion Z-Test (Two-Sided) ===")
print(f"Z_cal = {Z_cal}")
print(f"Z_table = [{Z_neg}, {Z_pos}]")
print(f"p-value = {norm.cdf(Z_cal)}")
print(f"CI = [{p + Z_neg * se}, {p + Z_pos * se}]")
# Accept H0 if |Z_cal| < |Z_table|
# Accept H0 if p-value > alpha
# Accept H0 if pbar inside CI


## ============================================================
## 9. ONE-SAMPLE PROPORTION Z-TEST (ONE-SIDED RIGHT)
##    Keywords: "increased", "greater", "more"
## ============================================================

p = 0.05
pbar = 335 / 6000
n = 6000
alpha = 0.02

se = np.sqrt((p * (1 - p)) / n)
Z_cal = (pbar - p) / se

Z_pos = norm.ppf(1 - alpha)

print("=== 9. One-Sample Proportion Z-Test (One-Sided Right) ===")
print(f"Z_cal = {Z_cal}")
print(f"Z_pos = {Z_pos}")
print(f"p-value = {1 - norm.cdf(Z_cal)}")
print(f"Boundary = {p + Z_pos * se}")
# Reject H0 if Z_cal > Z_pos
# Reject H0 if p-value < alpha
# Reject H0 if pbar > boundary


## ============================================================
## 10. ONE-SAMPLE PROPORTION USING BUILT-IN (proportions_ztest)
## ============================================================

print("=== 10. proportions_ztest (Built-in) ===")
print("Two-sided:", proportions_ztest(count=22, nobs=120, value=0.15, alternative='two-sided'))
print("Right:    ", proportions_ztest(count=335, nobs=6000, value=0.05, alternative='larger'))
print("Left:     ", proportions_ztest(count=22, nobs=120, value=0.15, alternative='smaller'))
# alternative: 'two-sided', 'smaller', 'larger'
# Reject H0 if pvalue < alpha


## ============================================================
## 11. TWO-SAMPLE Z-TEST FOR MEANS (TWO-SIDED)
##     Both sigma known
##     Keywords: "differ", "same", "equal"
## ============================================================

xbar1, xbar2 = 86, 82
sigma1, sigma2 = 6, 9
n1, n2 = 60, 75
alpha = 0.01

se = np.sqrt(sigma1**2/n1 + sigma2**2/n2)
Z_cal = ((xbar1 - xbar2) - 0) / se

Z_pos = norm.ppf(1 - alpha/2)
Z_neg = norm.ppf(alpha/2)

print("=== 11. Two-Sample Z-Test Means (Two-Sided) ===")
print(f"Z_cal = {Z_cal}")
print(f"Z_table = [{Z_neg}, {Z_pos}]")
print(f"p-value = {(1 - norm.cdf(Z_cal)) * 2}")
print(f"CI = [{0 + Z_neg * se}, {0 + Z_pos * se}]")
# Reject H0 if |Z_cal| > |Z_table|
# Reject H0 if p-value < alpha
# Reject H0 if (xbar1-xbar2) outside CI


## ============================================================
## 12. TWO-SAMPLE Z-TEST FOR MEANS (ONE-SIDED RIGHT)
##     Keywords: "greater", "higher", "increased"
## ============================================================

xbar1, xbar2 = 13.8, 9.1
sigma1, sigma2 = 18.9, 8.7
n1, n2 = 41, 35
alpha = 0.10

se = np.sqrt(sigma1**2/n1 + sigma2**2/n2)
Z_cal = ((xbar1 - xbar2) - 0) / se

Z_pos = norm.ppf(1 - alpha)

print("=== 12. Two-Sample Z-Test Means (One-Sided Right) ===")
print(f"Z_cal = {Z_cal}")
print(f"Z_pos = {Z_pos}")
print(f"p-value = {1 - norm.cdf(Z_cal)}")
print(f"Boundary = {0 + Z_pos * se}")
# Reject H0 if Z_cal > Z_pos
# Reject H0 if p-value < alpha
# Reject H0 if (xbar1-xbar2) > boundary


## ============================================================
## 13. TWO-SAMPLE t-TEST EQUAL VARIANCE (TWO-SIDED)
##     sigma unknown, use pooled SD
##     Keywords: "differ", "same", "equal"
## ============================================================

X = np.array([10, 12, 13, 14, 15, 2, 7, 8])
# Using built-in
print("=== 13. Two-Sample t-Test Equal Var (Built-in) ===")
a = np.array([56, 128.6, 12, 123.8, 64.34, 78, 763.3])
b = np.array([1.1, 2.9, 4.2])
print("Equal var: ", stats.ttest_ind(a, b, equal_var=True, alternative='two-sided'))
print("Unequal var:", stats.ttest_ind(a, b, equal_var=False, alternative='two-sided'))
# Reject H0 if pvalue < alpha


## ============================================================
## 14. TWO-SAMPLE t-TEST EQUAL VARIANCE (MANUAL - ONE-SIDED)
##     Pooled SD formula
## ============================================================

Bus = np.array([2.86, 2.77, 3.18, 2.80, 3.14, 2.87, 3.19, 3.24, 2.91, 3, 2.83])
As = np.array([3.35, 3.32, 3.36, 3.63, 3.41, 3.37, 3.45, 3.43, 3.44, 3.17, 3.26, 3.18, 3.41])

xbar1 = np.mean(Bus)
xbar2 = np.mean(As)
s1 = stdev(Bus)
s2 = stdev(As)
n1 = len(Bus)
n2 = len(As)
alpha = 0.02
hypothesized_diff = -0.25

# Pooled SD
sp = np.sqrt(((n1-1)*s1**2 + (n2-1)*s2**2) / (n1 + n2 - 2))
se = sp * np.sqrt(1/n1 + 1/n2)
df = n1 + n2 - 2

t_cal = ((xbar1 - xbar2) - hypothesized_diff) / se
t_neg = t.ppf(alpha, df)

print("=== 14. Two-Sample t-Test Pooled (One-Sided Left) ===")
print(f"Pooled SD = {sp}")
print(f"SE = {se}")
print(f"t_cal = {t_cal}")
print(f"t_neg = {t_neg}")
print(f"df = {df}")
print(f"p-value = {t.cdf(t_cal, df)}")
print(f"Boundary = {hypothesized_diff + t_neg * se}")
# Reject H0 if t_cal < t_neg
# Reject H0 if p-value < alpha


## ============================================================
## 15. TWO-SAMPLE t-TEST UNEQUAL VARIANCE (MANUAL - ONE-SIDED)
## ============================================================

xbar1, xbar2 = 27.2, 32.4
s1, s2 = 3.8, 4.3
n1, n2 = 12, 9
alpha = 0.01

sp = np.sqrt(((n1-1)*s1**2 + (n2-1)*s2**2) / (n1 + n2 - 2))
se = sp * np.sqrt(1/n1 + 1/n2)
df = n1 + n2 - 2

t_cal = ((xbar1 - xbar2) - 0) / se
t_neg = t.ppf(alpha, df)

print("=== 15. Two-Sample t-Test Unequal Var (One-Sided Left) ===")
print(f"t_cal = {t_cal}")
print(f"t_neg = {t_neg}")
print(f"p-value = {t.cdf(t_cal, df)}")
print(f"Boundary = {0 + t_neg * se}")
# Reject H0 if t_cal < t_neg
# Reject H0 if p-value < alpha


## ============================================================
## 16. TWO-SAMPLE t-TEST USING BUILT-IN (ttest_ind)
## ============================================================

a = np.array([56, 128.6, 12, 123.8, 64.34, 78, 763.3])
b = np.array([1.1, 2.9, 4.2])

print("=== 16. ttest_ind (Built-in) ===")
print("Two-sided equal:  ", stats.ttest_ind(a, b, equal_var=True, alternative='two-sided'))
print("Two-sided unequal:", stats.ttest_ind(a, b, equal_var=False, alternative='two-sided'))
print("Left equal:       ", stats.ttest_ind(a, b, equal_var=True, alternative='less'))
print("Right equal:      ", stats.ttest_ind(a, b, equal_var=True, alternative='greater'))
# equal_var=True  --> pooled (df = n1+n2-2)
# equal_var=False --> Welch's (fractional df)
# alternative: 'two-sided', 'less', 'greater'
# Reject H0 if pvalue < alpha


## ============================================================
## 17. TWO-SAMPLE PROPORTION Z-TEST (ONE-SIDED LEFT)
##     Keywords: "increased" but p1(old) - p2(new) < 0
## ============================================================

n1, n2 = 400, 380
p1 = 166 / 400
p2 = 205 / 380
alpha = 0.01

phat = (n1*p1 + n2*p2) / (n1 + n2)
se = np.sqrt(phat * (1 - phat) * (1/n1 + 1/n2))
Z_cal = ((p1 - p2) - 0) / se

Z_neg = norm.ppf(alpha)

print("=== 17. Two-Sample Proportion Z-Test (One-Sided Left) ===")
print(f"Pooled proportion = {phat}")
print(f"Z_cal = {Z_cal}")
print(f"Z_neg = {Z_neg}")
print(f"p-value = {norm.cdf(Z_cal)}")
print(f"Boundary = {0 + Z_neg * se}")
# Reject H0 if Z_cal < Z_neg
# Reject H0 if p-value < alpha
# Reject H0 if (p1-p2) < boundary


## ============================================================
## 18. TWO-SAMPLE PROPORTION USING BUILT-IN (proportions_ztest)
## ============================================================

count = np.array([166, 205])
nobs = np.array([400, 380])

print("=== 18. Two-Sample proportions_ztest (Built-in) ===")
stat, pval = proportions_ztest(count, nobs)
print(f"Two-sided: stat={stat:.4f}, pval={pval:.4f}")
# Reject H0 if pval < alpha


## ============================================================
## 19. PAIRED t-TEST (DEPENDENT SAMPLES) - MANUAL
##     Same subjects measured twice (before/after)
## ============================================================

a = np.array([56, 128, 12, 123, 64, 78, 763])
b = np.array([46, 100, 5, 121, 54, 80, 700])

c = a - b
xbar = np.mean(c)
sample_sd = stdev(c)
n = len(c)
df = n - 1
alpha = 0.05

se = sample_sd / np.sqrt(n)
t_cal = (xbar - 0) / se

t_pos = t.ppf(1 - alpha/2, df)
t_neg = t.ppf(alpha/2, df)

print("=== 19. Paired t-Test Manual (Two-Sided) ===")
print(f"Differences = {list(c)}")
print(f"Mean diff = {xbar}")
print(f"t_cal = {t_cal}")
print(f"t_table = [{t_neg}, {t_pos}]")
print(f"p-value = {(1 - t.cdf(t_cal, df)) * 2}")
# Accept H0 if |t_cal| < |t_table|
# Accept H0 if p-value > alpha


## ============================================================
## 20. PAIRED t-TEST USING BUILT-IN (ttest_rel)
## ============================================================

a = np.array([56, 128, 12, 123, 64, 78, 763])
b = np.array([46, 100, 5, 121, 54, 80, 700])

print("=== 20. ttest_rel (Built-in) ===")
print("Two-sided:", stats.ttest_rel(a, b, alternative='two-sided'))
print("Greater:  ", stats.ttest_rel(a, b, alternative='greater'))
print("Less:     ", stats.ttest_rel(a, b, alternative='less'))
# alternative: 'two-sided', 'less', 'greater'
# Reject H0 if pvalue < alpha""")

    def mle(self):
        """Maximum likelihood estimation — Normal, Binomial, Poisson."""
        print("""\
import numpy as np
from scipy.stats import norm, poisson
from scipy.optimize import minimize
from math import factorial


## ============================================================
## 1. MLE - NORMAL DISTRIBUTION
## ============================================================

def normal_dist(params,data):
    mu, sd = params
    log1 = norm.logpdf(data, mu, sd)
    lll = -np.sum(log1)
    return lll

initial_guess = [10, 3]
result = minimize(nll, initial_guess, args=(data,), bounds=((None, None), (1e-5, None)))
print("mean", result.x[0])
print("sd", result.x[1])


## ============================================================
## 2. MLE - BINOMIAL DISTRIBUTION
## ============================================================

hospital_data = [
    (100, 85),
    (150, 120),
    (200, 160),
    (250, 210),
    (300, 260)
]

inta = [0.1]
def binomial_dist(p,n,k):
    a1=factorial(n)/((factorial(n-k)*factorial(k)))
    a2=(p**k)*((1-p)**(n-k))
    ll = a1*a2
    logll = np.log(ll)
    return -logll
for n, k in hospital_data:
    result = minimize(BLL, inta, args=(n,k), bounds=[(0.00005, 0.99995)])
    print("prob", result.x[0])


## ============================================================
## 3. MLE - POISSON DISTRIBUTION
## ============================================================

def poisson_dist(lam, x):
    log=[]
    for i in x:
        logs = np.log(poisson.pmf(x[i], lam))
        log.append(logs)
    return np.sum(log)
lams = np.arange(0,12,1)
ls = []
for lam in lams:
    lsa = pd(lam, data)
    ls.append(lsa)
bestll = lams[np.argmax(ls)]
print(bestll)""")

    def nonpara(self):
        """Non-parametric tests — Mann-Whitney U, Kruskal-Wallis, Sign test."""
        print("""\
import numpy as np
from scipy.stats import mannwhitneyu
from scipy import stats


## ============================================================
## 1. MANN-WHITNEY U TEST
## ============================================================

a=np.array([])
b=np.array([])
u_stat,p_value=mannwhitneyu(a,b,alternative="")


## ============================================================
## 2. KRUSKAL-WALLIS H TEST
## ============================================================

a=np.array([])
b=np.array([])
results=stats.kruskal(a,b)


## ============================================================
## 3. SIGN TEST
## ============================================================

from statsmodels.stats.descriptivestats import sign_test
a=np.array([])
b=np.array([])
diff=a-b
stat_val,p_val=sign_test(diff)""")

    def linearregression(self):
        """Linear regression — Simple, Multiple, Polynomial, OLS, Train-Test, K-Fold."""
        print("""\
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import sklearn.linear_model as lm
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold, cross_val_score
from sklearn.preprocessing import StandardScaler
import statsmodels.formula.api as smf


## ============================================================
## 1. SIMPLE LINEAR REGRESSION (sklearn)
## ============================================================

df1 = pd.read_csv('Advertising.csv', index_col=0)

lr = LinearRegression()
X = df1['TV'].values.reshape(-1, 1)
Y = df1['sales']
lr.fit(X, Y)

print("=== 1. Simple Linear Regression ===")
print(f"Intercept = {lr.intercept_}")
print(f"Coefficient = {lr.coef_}")
print(f"Equation: sales = {lr.intercept_:.4f} + {lr.coef_[0]:.4f} * TV")

RSS = np.sum((lr.intercept_ + lr.coef_ * X - Y.values.reshape(-1, 1))**2)
print(f"RSS = {RSS}")


## ============================================================
## 2. OLS REGRESSION (statsmodels - gives summary)
## ============================================================

## Simple
lm_fit = smf.ols('sales ~ TV', df1).fit()
print(lm_fit.summary())

## Multiple
lm_fit2 = smf.ols('sales ~ TV + radio', df1).fit()
print(lm_fit2.summary().tables[1])

## With interaction
lm_fit3 = smf.ols('sales ~ TV * radio', df1).fit()
print(lm_fit3.summary().tables[1])


## ============================================================
## 3. POLYNOMIAL REGRESSION
## ============================================================

df1['TV2'] = df1['TV'].values ** 2

lm_fit_poly = smf.ols('sales ~ TV + TV2', df1).fit()
print(lm_fit_poly.summary())
# Check TV2 p-value: if > 0.05 --> polynomial NOT needed


## ============================================================
## 4. PREDICTION
## ============================================================

lm_fit = smf.ols('sales ~ TV', df1).fit()
predictions = lm_fit.predict(pd.DataFrame({'TV': [5, 10, 15]}))
print(f"Predictions for TV=[5,10,15]: {list(predictions)}")

## MSE
X = df1[['TV', 'radio']]
lm_fit3 = smf.ols('sales ~ TV * radio', df1).fit()
sales_pred = lm_fit3.predict(X)
mse = np.mean((df1['sales'] - sales_pred) ** 2)
print(f"MSE = {mse}")


## ============================================================
## 5. FEATURE SCALING (StandardScaler)
## ============================================================

df1 = pd.read_csv('Advertising.csv', index_col=0)
scaler = StandardScaler()
df1[['TVS', 'radioS']] = scaler.fit_transform(df1[['TV', 'radio']])
print(df1[['TV', 'TVS', 'radio', 'radioS']].head(2))

## MSE is same with or without scaling
fit_scaled = smf.ols('sales ~ TVS * radioS', df1).fit()
sales_p = fit_scaled.predict(df1[['TVS', 'radioS']])
mse_scaled = np.mean((df1['sales'] - sales_p) ** 2)
print(f"MSE (scaled) = {mse_scaled}")


## ============================================================
## 6. TRAIN-TEST SPLIT
## ============================================================

df1 = pd.read_csv('Advertising.csv', index_col=0)
X = df1[['TV', 'radio']]
Y = df1['sales']

X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, test_size=0.20, random_state=123
)
print(f"Train shape: {X_train.shape}")
print(f"Test shape:  {X_test.shape}")

## Train model
df_train = pd.concat([X_train, Y_train], axis=1)
fit = smf.ols('sales ~ TV * radio', df_train).fit()

## Train MSE
sales_train = fit.predict(X_train)
mse_train = np.mean((Y_train - sales_train) ** 2)
print(f"Train MSE = {mse_train}")

## Test MSE
sales_test = fit.predict(X_test)
mse_test = np.mean((Y_test - sales_test) ** 2)
print(f"Test MSE  = {mse_test}")


## ============================================================
## 7. K-FOLD CROSS VALIDATION
## ============================================================

X = df1[['TV', 'radio']]
Y = df1['sales']
model = lm.LinearRegression()

K = 10
kfold = KFold(K, random_state=0, shuffle=True)
mse_cv = cross_val_score(model, X, Y, cv=kfold, scoring='neg_mean_squared_error')

print(f"MSE per fold = {-mse_cv}")
print(f"Average MSE  = {np.mean(-mse_cv)}")

## Comparing two models with K-Fold
X1 = df1[['TV']]
X2 = df1[['TV', 'radio']]
mse_cv_1 = cross_val_score(model, X1, Y, cv=kfold, scoring='neg_mean_squared_error')
mse_cv_2 = cross_val_score(model, X2, Y, cv=kfold, scoring='neg_mean_squared_error')
print(f"Model 1 (TV only):    avg MSE = {np.mean(-mse_cv_1)}")
print(f"Model 2 (TV + radio): avg MSE = {np.mean(-mse_cv_2)}")
print("Lower MSE = better model")""")

    def ridge(self):
        """Ridge and Lasso regression — with CV and train-test split."""
        print("""\
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge, RidgeCV
from sklearn.linear_model import Lasso, LassoCV
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split


## ============================================================
## 1. RIDGE REGRESSION
## ============================================================

df3 = pd.read_csv('Auto.csv', na_values='?').dropna()
X = df3[['cylinders', 'displacement', 'horsepower', 'weight', 'acceleration', 'origin']]
Y = df3['mpg']

## Basic Ridge
ridge = Ridge(alpha=10)    # alpha = lambda (penalty strength)
ridge.fit(X, Y)
print("Ridge (alpha=10) coefficients:")
print(pd.Series(ridge.coef_, index=X.columns))


## ============================================================
## 2. LASSO REGRESSION
## ============================================================

lasso = Lasso(alpha=10)
lasso.fit(X, Y)
print("Lasso (alpha=10) coefficients:")
print(pd.Series(lasso.coef_, index=X.columns))
print("Notice: Lasso sets some coefficients to EXACTLY 0")


## ============================================================
## 3. RIDGE WITH TRAIN-TEST SPLIT
## ============================================================

df3 = pd.read_csv('Auto.csv', na_values='?').dropna()
df4 = pd.get_dummies(df3, columns=['origin', 'cylinders'])
y = df3['mpg']
X1 = df3.drop(['mpg', 'year', 'name', 'origin', 'cylinders'], axis=1).astype('float64')
X = pd.concat([X1, df4[['origin_1', 'origin_2', 'origin_3',
    'cylinders_3', 'cylinders_4', 'cylinders_5',
    'cylinders_6', 'cylinders_8']]], axis=1).astype('float64')

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5, random_state=1)

ridge = Ridge(alpha=2)
ridge.fit(X_train, y_train)
pred = ridge.predict(X_test)
print("Ridge (alpha=2) coefficients:")
print(pd.Series(ridge.coef_, index=X.columns))
print(f"Test MSE = {mean_squared_error(y_test, pred)}")


## ============================================================
## 4. RIDGECV - FIND BEST ALPHA AUTOMATICALLY
## ============================================================

alphas = 10 ** np.linspace(10, -2, 100) * 0.5

ridgecv = RidgeCV(alphas=alphas)
ridgecv.fit(X, y)
print(f"Best alpha = {ridgecv.alpha_}")

## Use best alpha
ridge_best = Ridge(alpha=ridgecv.alpha_)
ridge_best.fit(X_train, y_train)
pred_best = ridge_best.predict(X_test)
print(f"Test MSE (best alpha) = {mean_squared_error(y_test, pred_best)}")


## ============================================================
## 5. LASSO WITH TRAIN-TEST SPLIT
## ============================================================

lasso = Lasso(alpha=2)
lasso.fit(X_train, y_train)
pred_lasso = lasso.predict(X_test)
print("Lasso (alpha=2) coefficients:")
print(pd.Series(lasso.coef_, index=X.columns))
print(f"Test MSE = {mean_squared_error(y_test, pred_lasso)}")


## ============================================================
## 6. LASSOCV - FIND BEST ALPHA AUTOMATICALLY
## ============================================================

lassocv = LassoCV(alphas=alphas)
lassocv.fit(X_train, y_train)
print(f"Best alpha = {lassocv.alpha_}")

lasso_best = Lasso(alpha=lassocv.alpha_)
lasso_best.fit(X_train, y_train)
pred_lasso_best = lasso_best.predict(X_test)
print("Lasso (best alpha) coefficients:")
print(pd.Series(lasso_best.coef_, index=X.columns))
print(f"Test MSE (best alpha) = {mean_squared_error(y_test, pred_lasso_best)}")""")

    def logi(self):
        """Logistic regression with K-Fold and confusion matrix."""
        print("""\
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import KFold, cross_val_score
from sklearn.metrics import confusion_matrix, accuracy_score


X=df[['sl','pl','sw','pw']]
y=df['type']

K=5
kfold = KFold(K,random_state=0,shuffle=True)
mse_cv = cross_val_score(model,X,Y,cv=kfold,scoring='accuracy')
mse_cv
logit=LogisticRegression()
logit.fit(X,Y)
logit.coef_
logit.intercept_
y_pred=logit.predict(X)
print(confusion_matrix(y,y_pred))
print(accuracy_score(y,y_pred))""")

    def annova(self):
        """ANOVA — One-way, Two-way, and Tukey post-hoc."""
        print("""\
import pandas as pd
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.multicomp import pairwise_tukeyhsd


## ============================================================
## 1. ONE-WAY ANOVA
## ============================================================

df = pd.read_csv('data.csv')

df.head()
df.info()

oneway_fit = ols('target ~ factor', data=df).fit()
oneway_anova = sm.stats.anova_lm(oneway_fit, typ=1)
print(oneway_anova)

# IF 2 Factor variables are given they are to be compared individually

# If the P value of anova is less than 0.05 then Use Tukey for the Factor Variable.


## ============================================================
## 2. TWO-WAY ANOVA
## ============================================================

df2 = pd.read_csv('cars.csv')

twoway_fit = ols('target ~ C(factor1)+C(factor2)+C(factor1):C(factor2)', data=df2).fit()
twoway_anova = sm.stats.anova_lm(twoway_fit, typ=2)


## ============================================================
## 3. TUKEY POST-HOC TEST
## ============================================================

tukey = pairwise_tukeyhsd(df1["target"],groups=df1["factor"])
tukey._results_table""")

    def manova(self):
        """MANOVA — One-way and Two-way."""
        print("""\
import pandas as pd
from statsmodels.multivariate.manova import MANOVA


## ============================================================
## 1. ONE-WAY MANOVA
## ============================================================

url = 'https://vincentarelbundock.github.io/Rdatasets/csv/datasets/iris.csv'
df = pd.read_csv(url)
print(df.head())
df.columns = df.columns.str.replace(".", "_")
print(df.head())

maov = MANOVA.from_formula('target1 + target2 + target3 + ...  ~ factor', data=df)
print(maov.mv_test())


## ============================================================
## 2. TWO-WAY MANOVA
## ============================================================

maov = MANOVA.from_formula('target1 + target2 + target3 + ...  ~ factor1 + factor2', data=df)
print(maov.mv_test())


# IF P VALUE > 0.05, DO ANOVA.""")


get = _Get()
