"""
Standardized benchmark model configurations.

Provides canonical model architecture profiles and device-specific benchmark
parameters.  All benchmark scripts should derive their tensor shapes from these
shared configs rather than defining ad-hoc per-script constants.

Usage::

    from benchmark_model_configs import (
        get_benchmark_model_config,
        compute_seq_len_sweep_config,
        estimate_kernel_peak_memory,
    )

    args = parse_benchmark_script_args()
    model = get_benchmark_model_config(args.model)

    # Measure actual memory via a small probe, then compute sweep config
    peak_bytes = estimate_kernel_peak_memory(probe_fn=_probe)
    bpt = peak_bytes // probe_num_tokens
    config = compute_seq_len_sweep_config(model, kernel_bytes_per_token=bpt)
"""

import gc
import math

from dataclasses import dataclass
from typing import Callable
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import torch

from liger_kernel.utils import get_total_gpu_memory
from liger_kernel.utils import infer_device


@dataclass(frozen=True)
class ModelConfig:
    """Canonical model architecture profile.

    Each field corresponds to a standard LLM hyperparameter.  Benchmark scripts
    pick the fields they need (e.g. hidden_size for RMSNorm, vocab_size for
    CrossEntropy) while kernel-specific overrides (e.g. hidden_act for GEGLU)
    are applied locally in the benchmark script.
    """

    name: str
    hidden_size: int
    intermediate_size: int
    vocab_size: int
    num_attention_heads: int
    num_key_value_heads: int
    head_dim: int
    hidden_act: str
    max_position_embeddings: int = 8192
    rms_norm_eps: float = 1e-5
    dtype: torch.dtype = torch.bfloat16

    # ===== MoE-specific (optional) =====
    num_experts: Optional[int] = None
    topk: Optional[int] = None
    moe_intermediate_size: Optional[int] = None

    @property
    def is_moe(self) -> bool:
        return self.num_experts is not None


@dataclass(frozen=True)
class SeqLenSweepConfig:
    """Config for benchmarks that sweep sequence length (e.g. GEGLU, SwiGLU).

    Attributes:
        batch_size: Safe batch size for the sweep.
        seq_len: Max sequence length (upper bound for x_values).
    """

    batch_size: int
    seq_len: int


@dataclass(frozen=True)
class ModelConfigSweepConfig:
    """Config for benchmarks that sweep across model configs.

    Attributes:
        model_configs: Model configs to benchmark (as tuple for immutability).
        bt: Effective total tokens (batch_size * seq_len).
        batch_size: Safe batch size across all model configs.
        seq_len: Safe sequence length across all model configs.
    """

    model_configs: Tuple[ModelConfig, ...]
    bt: int
    batch_size: int
    seq_len: int


@dataclass(frozen=True)
class MoEModelConfig:
    """MoE model architecture profile for fused MoE benchmarks.

    EP-adjusted values should be baked in: T = total_tokens / ep_size,
    E = total_experts / ep_size.
    """

    name: str
    T: int  # tokens per GPU (EP-adjusted)
    E: int  # experts per GPU (EP-adjusted)
    H: int  # hidden size
    intermediate_dim: int  # expert intermediate size
    K: int  # top-k


# ── MoE Model Profiles ───────────────────────────────────────────────────────

QWEN3_MOE_30B = MoEModelConfig(
    name="qwen3_moe_30b",
    T=8192,
    E=128,
    H=2048,
    intermediate_dim=768,
    K=8,
)


# ── Dense Model Profiles ─────────────────────────────────────────────────────

LLAMA_2_7B = ModelConfig(
    name="llama_2_7b",
    hidden_size=4096,
    intermediate_size=11008,
    vocab_size=32000,
    num_attention_heads=32,
    num_key_value_heads=32,
    head_dim=128,
    hidden_act="silu",
    max_position_embeddings=4096,
)

LLAMA_3_8B = ModelConfig(
    name="llama_3_8b",
    hidden_size=4096,
    intermediate_size=14336,
    vocab_size=128256,
    num_attention_heads=32,
    num_key_value_heads=8,
    head_dim=128,
    hidden_act="silu",
    max_position_embeddings=8192,
)

QWEN_2_5_7B = ModelConfig(
    name="qwen2.5_7b",
    hidden_size=3584,
    intermediate_size=18944,
    vocab_size=152064,
    num_attention_heads=28,
    num_key_value_heads=4,
    head_dim=128,
    hidden_act="silu",
    max_position_embeddings=32768,
)

QWEN_2_5_14B = ModelConfig(
    name="qwen2.5_14b",
    hidden_size=5120,
    intermediate_size=13824,
    vocab_size=152064,
    num_attention_heads=40,
    num_key_value_heads=8,
    head_dim=128,
    hidden_act="silu",
    max_position_embeddings=32768,
)

QWEN_2_5_72B = ModelConfig(
    name="qwen2.5_72b",
    hidden_size=8192,
    intermediate_size=29568,
    vocab_size=152064,
    num_attention_heads=64,
    num_key_value_heads=8,
    head_dim=128,
    hidden_act="silu",
    max_position_embeddings=32768,
)

DEEPSEEK_V2_LITE = ModelConfig(
    name="deepseek_v2_lite",
    hidden_size=2048,
    intermediate_size=10944,
    vocab_size=102400,
    num_attention_heads=16,
    num_key_value_heads=16,
    head_dim=128,
    hidden_act="silu",
    max_position_embeddings=163840,
    moe_intermediate_size=1408,
    num_experts=64,
    topk=6,
)

DEEPSEEK_V3 = ModelConfig(
    name="deepseek_v3",
    hidden_size=7168,
    intermediate_size=18432,
    vocab_size=129280,
    num_attention_heads=128,
    num_key_value_heads=128,
    head_dim=128,
    hidden_act="silu",
    max_position_embeddings=163840,
    moe_intermediate_size=2048,
    num_experts=256,
    topk=8,
)

MODEL_REGISTRY: Dict[str, ModelConfig] = {
    "llama_2_7b": LLAMA_2_7B,
    "llama_3_8b": LLAMA_3_8B,
    "qwen2.5_7b": QWEN_2_5_7B,
    "qwen2.5_14b": QWEN_2_5_14B,
    "qwen2.5_72b": QWEN_2_5_72B,
    "deepseek_v2_lite": DEEPSEEK_V2_LITE,
    "deepseek_v3": DEEPSEEK_V3,
}

DEFAULT_MODEL_CONFIG = LLAMA_3_8B


def get_benchmark_model_config(model_name: Optional[str] = None) -> ModelConfig:
    """Resolve benchmark model config from name.

    Returns the canonical model architecture profile (hidden_size, vocab_size,
    dtype, etc.) for benchmark runs.  Use this to obtain model attributes
    when building benchmark tensors and shapes.

    Args:
        model_name: Registry key (e.g. ``llama_2_7b``, ``llama_3_8b``).
            If None, returns ``DEFAULT_MODEL_CONFIG``.
    """
    return MODEL_REGISTRY[model_name] if model_name else DEFAULT_MODEL_CONFIG


def estimate_kernel_peak_memory(probe_fn: Callable[[], torch.Tensor]) -> int:
    """Run a forward + backward probe to measure peak memory (bytes).

    Call this with the *pure PyTorch* (e.g. huggingface) implementation --
    that typically has the highest memory footprint and therefore gives a
    safe upper-bound estimate.  Returns the total peak bytes; divide by
    num_tokens if you need bytes-per-token for :func:`compute_seq_len_sweep_config`.

    The probe_fn performs setup and forward pass internally; cleanup is
    automatic, so callers do not need to manage tensor/layer lifecycle.

    Example::

        peak_bytes = estimate_kernel_peak_memory(probe_fn=_probe)
        kernel_bpt = peak_bytes // num_tokens  # if needed

    Args:
        probe_fn: Callable that performs setup, runs a forward pass, and
            returns an output tensor suitable for ``.backward()``.
    """
    device_str = infer_device()
    torch_device_mod = getattr(torch, device_str)

    gc.collect()
    torch_device_mod.empty_cache()
    torch_device_mod.memory.reset_peak_memory_stats()

    y = probe_fn()
    y.backward(torch.randn_like(y))

    peak_bytes = torch_device_mod.max_memory_allocated()

    del y
    gc.collect()
    torch_device_mod.empty_cache()

    return max(1, peak_bytes)


def compute_seq_len_sweep_config(
    model_cfg: ModelConfig,
    kernel_bytes_per_token: Optional[int] = None,
    memory_utilization: float = 0.4,
    max_seq_len: Optional[int] = None,
    max_batch_size: int = 32,
) -> SeqLenSweepConfig:
    """Compute safe batch_size and seq_len for sequence-length sweep (e.g. GEGLU).

    Peak memory is estimated as
    ``batch_size * seq_len * kernel_bytes_per_token`` and is capped at
    device memory * memory_utilization.  Device memory is obtained
    internally via :func:`~liger_kernel.utils.get_total_gpu_memory`.

    Prefer obtaining *kernel_bytes_per_token* via
    :func:`estimate_kernel_peak_memory` (divide by num_tokens) rather
    than hardcoding an analytical estimate.

    Args:
        model_cfg: Model architecture config.
        kernel_bytes_per_token: Peak memory **per token** (``batch * seq_len``
            axis).  Best obtained from :func:`estimate_kernel_peak_memory` / num_tokens.
            Falls back to a conservative heuristic
            (``hidden_size * dtype_bytes * 16``) when *None*.
        memory_utilization: Fraction of total device memory to target (0 to 1).
            Lower values are safer.  Default ``0.4`` leaves headroom for
            framework overhead and CUDA/NPU context.
        max_seq_len: Hard upper bound for sequence length.  Defaults to
            ``model_cfg.max_position_embeddings`` so the sweep never exceeds
            the model's native context window.
        max_batch_size: Hard upper bound for batch size.
    """
    total_memory_gb = get_total_gpu_memory()
    dtype_bytes = 2 if model_cfg.dtype in (torch.bfloat16, torch.float16) else 4

    if kernel_bytes_per_token is None:
        kernel_bytes_per_token = model_cfg.hidden_size * dtype_bytes * 16

    if max_seq_len is None:
        max_seq_len = model_cfg.max_position_embeddings

    usable_bytes = total_memory_gb * (1024**3) * memory_utilization
    max_tokens = max(1, int(usable_bytes / kernel_bytes_per_token))

    seq_len = min(max_seq_len, max_tokens)
    seq_len = 2 ** int(math.log2(seq_len)) if seq_len >= 1024 else 1024

    batch_size = max(1, min(max_tokens // seq_len, max_batch_size))

    return SeqLenSweepConfig(batch_size=batch_size, seq_len=seq_len)


def compute_model_config_sweep_config(
    model_configs: List[ModelConfig],
    probe_fn_factory: Callable[[ModelConfig, int], Callable[[], torch.Tensor]],
    bt: int = 2048,
    memory_utilization: float = 0.4,
) -> ModelConfigSweepConfig:
    """Find safe (batch_size, seq_len) that works across all model configs.

    Probes each model config at a small token count to measure peak memory,
    then picks the most conservative parameters that fit within device memory.

    Args:
        model_configs: Model configs to benchmark.
        probe_fn_factory: Factory ``(model_cfg, probe_seq_len) -> probe_fn``.
            The returned probe_fn should perform setup + forward pass and
            return a tensor suitable for ``.backward()``, same contract as
            :func:`estimate_kernel_peak_memory`'s *probe_fn*.
        bt: Target total tokens (batch_size * seq_len).
        memory_utilization: Fraction of device memory to use.
    """
    total_memory_gb = get_total_gpu_memory()
    usable_bytes = total_memory_gb * (1024**3) * memory_utilization

    probe_seq_len = min(bt, 1024)
    max_bytes_per_token = 0

    for model_cfg in model_configs:
        probe_fn = probe_fn_factory(model_cfg, probe_seq_len)
        peak_bytes = estimate_kernel_peak_memory(probe_fn)
        bpt = max(1, peak_bytes // probe_seq_len)
        max_bytes_per_token = max(max_bytes_per_token, bpt)

    max_tokens = max(1, int(usable_bytes / max_bytes_per_token))
    safe_bt = min(bt, max_tokens)

    seq_len = min(safe_bt, 8192)
    seq_len = 2 ** int(math.log2(seq_len)) if seq_len >= 1024 else 1024
    batch_size = max(1, safe_bt // seq_len)

    return ModelConfigSweepConfig(
        model_configs=tuple(model_configs),
        bt=batch_size * seq_len,
        batch_size=batch_size,
        seq_len=seq_len,
    )
