file_info = {"Images": [".png", ".jpg", ".jpeg"],
             "Documents": [".txt", ".pdf", ".docx"],
             "Videos": [".mp4", ".mov", ".ogv"],
             "Audio": [".mp3", ".wav"],
             "3D": [".obj", ".stl", ".amf"],
             "Code": [".py", ".java", ".cpp", ".c"]}