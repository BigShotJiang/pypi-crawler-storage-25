# antarraksha-langchain

Antarraksha AI Agent Enforcement SDK for LangChain.

## Installation

```bash
pip install antarraksha-langchain
```

## Quick Start

Attach Antarraksha as a callback handler on your LLM. Registration happens automatically on first use — no login, no API key, no signup required.

```python
from antarraksha_langchain import AntarrakshaCallbackHandler
from langchain_anthropic import ChatAnthropic

handler = AntarrakshaCallbackHandler(agent_id="my-langchain-agent")

llm = ChatAnthropic(model="claude-sonnet-4-5", callbacks=[handler])
print(llm.invoke("Hello").content)
```

Run your agent normally — every LLM call, tool call, and chain call is now enforced against Antarraksha policy.

## Tool Wrapping (optional)

Wrap individual LangChain tools for inline enforcement:

```python
from langchain_community.tools import ShellTool
from antarraksha_langchain import AntarrakshaSafeTool, AntarrakshaClient

client = AntarrakshaClient(agent_id="my-langchain-agent")
client.register()

safe_shell = AntarrakshaSafeTool(wrapped_tool=ShellTool(), antarraksha_client=client)
safe_shell.run("ls")
```

## Parameters

| Parameter | Default | Description |
|---|---|---|
| `agent_id` | `None` | Unique identifier for your agent. Triggers auto-registration on first use. |
| `base_url` | `"https://antarraksha.ai"` | Antarraksha endpoint. Override for self-hosted / dev. |
| `passport_id` | `None` | Optional pre-issued passport ID (e.g. `ANTK-PASS-xxx`). |
| `sdk_key` | `None` | Optional pre-issued SDK key. If omitted and `agent_id` is set, the SDK auto-registers and obtains one. |
| `fail_closed` | `True` | If `True`, deny on enforcement-server unreachable. Set `False` for fail-open during early integration. |
| `block_on_deny` | `True` | If `True`, raise `PermissionError` when Antarraksha returns DENY. |

## Enforcement Behavior

- **on_llm_start** fires before every LLM call. DENY raises `PermissionError`.
- **on_tool_start** fires before every tool invocation. DENY raises `PermissionError`.
- **on_chain_start** fires for every chain run (informational; no enforcement halt).
- Every call is logged and visible at `https://antarraksha.ai/registry`.

## Corporate Network Note

If you're behind a corporate TLS-inspection proxy and see `SSLCertVerificationError`, install:

```bash
pip install pip-system-certs
```

This makes Python trust your Windows / macOS system certificate store.
