"""LangChain callback handler for Antarraksha enforcement."""

from typing import Any, Dict, List, Optional, Union
from uuid import UUID

from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.outputs import LLMResult

from .client import AntarrakshaClient


class AntarrakshaCallbackHandler(BaseCallbackHandler):
    raise_error: bool = True  # tell LangChain to halt LLM call on fail-closed PermissionError
    """LangChain callback that enforces Antarraksha policy on every LLM and tool call.

    Usage:
        from antarraksha_langchain import AntarrakshaCallbackHandler

        handler = AntarrakshaCallbackHandler(
            base_url="https://antarraksha.ai",
            agent_id="my-agent",
            passport_id="ANTK-PASS-xxx",
        )
        llm = ChatOpenAI(callbacks=[handler])
    """

    def __init__(
        self,
        base_url: str = "https://antarraksha.ai",
        agent_id: Optional[str] = None,
        passport_id: Optional[str] = None,
        sdk_key: Optional[str] = None,
        fail_closed: bool = True,
        block_on_deny: bool = True,
    ):
        super().__init__()
        self.client = AntarrakshaClient(
            base_url=base_url,
            agent_id=agent_id,
            passport_id=passport_id,
            sdk_key=sdk_key,
            framework="langchain",
            fail_closed=fail_closed,
        )
        self.block_on_deny = block_on_deny
        self._denied_runs: set = set()

        if not sdk_key and agent_id:
            try:
                self.client.register()
            except Exception:
                pass

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        result = self.client.intercept(
            call_type="llm_call",
            call_name=serialized.get("id", ["unknown"])[-1] if isinstance(serialized.get("id"), list) else serialized.get("name", "unknown"),
            parameters={"prompt_count": len(prompts), "prompt_lengths": [len(p) for p in prompts]},
        )
        if result.get("decision") == "DENY" and self.block_on_deny:
            self._denied_runs.add(str(run_id))
            raise PermissionError(
                f"Antarraksha enforcement denied LLM call: {result.get('reason', 'Policy violation')}"
            )

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        tool_name = serialized.get("name", "unknown_tool")
        result = self.client.intercept(
            call_type="tool_call",
            call_name=tool_name,
            parameters={"input_length": len(input_str)},
        )
        if result.get("decision") == "DENY" and self.block_on_deny:
            self._denied_runs.add(str(run_id))
            raise PermissionError(
                f"Antarraksha enforcement denied tool '{tool_name}': {result.get('reason', 'Policy violation')}"
            )

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        chain_name = serialized.get("id", ["unknown"])[-1] if isinstance(serialized.get("id"), list) else "chain"
        self.client.intercept(
            call_type="chain_call",
            call_name=chain_name,
            parameters={"input_keys": list(inputs.keys()) if isinstance(inputs, dict) else []},
        )

    def on_llm_end(self, response: LLMResult, *, run_id: UUID, **kwargs: Any) -> None:
        pass

    def on_tool_end(self, output: Any, *, run_id: UUID, **kwargs: Any) -> None:
        pass
