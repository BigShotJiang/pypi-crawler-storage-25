"""Wrapper that adds Antarraksha enforcement to any LangChain tool."""

from typing import Any, Optional, Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel

from .client import AntarrakshaClient


class AntarrakshaSafeTool(BaseTool):
    """Wraps any LangChain tool with Antarraksha enforcement.

    Usage:
        from langchain_community.tools import ShellTool
        from antarraksha_langchain import AntarrakshaSafeTool, AntarrakshaClient

        client = AntarrakshaClient(agent_id="my-agent", passport_id="ANTK-PASS-xxx")
        client.register()

        safe_shell = AntarrakshaSafeTool(
            wrapped_tool=ShellTool(),
            antarraksha_client=client,
        )
    """

    name: str = "antarraksha_safe_tool"
    description: str = "Antarraksha-enforced tool"
    wrapped_tool: Any = None
    antarraksha_client: Any = None

    class Config:
        arbitrary_types_allowed = True

    def __init__(self, wrapped_tool: BaseTool, antarraksha_client: AntarrakshaClient, **kwargs: Any):
        super().__init__(
            name=f"safe_{wrapped_tool.name}",
            description=f"[Antarraksha-enforced] {wrapped_tool.description}",
            wrapped_tool=wrapped_tool,
            antarraksha_client=antarraksha_client,
            **kwargs,
        )

    def _run(self, *args: Any, **kwargs: Any) -> Any:
        result = self.antarraksha_client.intercept(
            call_type="tool_call",
            call_name=self.wrapped_tool.name,
            parameters={"args": str(args)[:200], "kwargs_keys": list(kwargs.keys())},
        )
        if result.get("decision") == "DENY":
            return f"[BLOCKED by Antarraksha] Tool '{self.wrapped_tool.name}' denied: {result.get('reason', 'Policy violation')}"
        return self.wrapped_tool._run(*args, **kwargs)

    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        result = self.antarraksha_client.intercept(
            call_type="tool_call",
            call_name=self.wrapped_tool.name,
            parameters={"args": str(args)[:200], "kwargs_keys": list(kwargs.keys())},
        )
        if result.get("decision") == "DENY":
            return f"[BLOCKED by Antarraksha] Tool '{self.wrapped_tool.name}' denied: {result.get('reason', 'Policy violation')}"
        return await self.wrapped_tool._arun(*args, **kwargs)
