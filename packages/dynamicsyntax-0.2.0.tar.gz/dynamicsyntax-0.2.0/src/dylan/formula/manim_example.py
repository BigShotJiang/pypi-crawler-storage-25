from manim import *

config.media_width = "75%"
config.verbosity = "WARNING"

%%manim -qm JohnArrives

class JohnArrives(Scene):
    def construct(self):
        # Color codes
        green_latest = "#49b372"
        blue_lines = "#9dfcf9"
        blue_font = "#1e6b69" # this has to be lighter
        wait_after_action = 1.4
        wait_after_effect = 2.1
        # actions = VGroup().arrange(DOWN, buff=0.25).shift(UP + RIGHT)
        title = Text("Here is a parse for the utterance\n \"John arrives\" in DS-TTR")#.scale(0.75)
        utterance = MarkupText("Utterance: ", weight=HEAVY).set_color(blue_font).scale(0.6).to_corner(UP + LEFT)
        hline = Line(start=np.array([-1.0, 0.0, 0.0]), end=np.array([19.0, 0.0, 0.0])).next_to(utterance, DOWN, buff=0.25).set_color(blue_lines)
        vline = Line(start=np.array([0.0, -1.0, 0.0]), end=np.array([0.0, 14.0, 0.0])).next_to(utterance, RIGHT, buff=9).set_color(blue_lines)
        actions = MarkupText("<u>Actions</u>", weight=HEAVY).set_color(blue_font).scale(0.6).next_to(vline, RIGHT, buff=0.2) # underline didn't work!
        # begin = Text("[Nothing yet]").scale(0.85).next_to(utterance, RIGHT, buff=0.25).set_color(WHITE)
        # utterance.add(begin)
        john = Tex("John").set_color(green_latest).scale(0.85).next_to(utterance, RIGHT, buff=0.25)
        john_sem = MathTex(r"\begin{bmatrix}x_{=john} : e\\head_{=x} : e\end{bmatrix}").scale(0.5)
        arrives = Tex("arrives").set_color(green_latest).scale(0.85).next_to(john, RIGHT, buff=0.1)
        arrives_sem = MathTex(r"\lambda r : \begin{bmatrix}head : e\end{bmatrix} . \qquad \\\begin{bmatrix}x_{=r.head} & : & e\\ e_{=arrive} & : & e_s\\ p_{=subj(e, x)} & : & t\\head_{=p} & : & t\end{bmatrix}").scale(0.5)
        final_sem = MathTex(r"\begin{bmatrix}x_{=john} & : & e\\ e_{=arrive} & : & e_s\\ p_{=subj(e, x)} & : & t\\head_{=p} & : & t\end{bmatrix}").scale(0.5)

        mother_node = VGroup(Tex("?Ty(t)").scale(0.85).set_color(green_latest)).shift(UP*2 + LEFT*2)
        ptr = MathTex(r"\diamondsuit").set_color(RED).scale(0.85).next_to(mother_node, RIGHT, buff=0.1)
        functorLeft_node = VGroup(MathTex(r"?Ty(e)").scale(0.85).set_color(green_latest)).next_to(mother_node)
        argumentRight_node = VGroup(MathTex(r"?Ty(e\rightarrow t)").scale(0.85).set_color(green_latest)).next_to(mother_node)
        functorLeft_node.generate_target()
        functorLeft_node.target.next_to(mother_node, DOWN*3+LEFT*3, buff=0.75)
        argumentRight_node.generate_target()
        argumentRight_node.target.next_to(mother_node, DOWN*3+RIGHT*3, buff=0.75)
        # ptr_left = MathTex(r"\diamondsuit").set_color(RED).scale(0.85).next_to(functorLeft_node, RIGHT, buff=0.1)
        # ptr_right = MathTex(r"\diamondsuit").set_color(RED).scale(0.85).next_to(argumentRight_node, RIGHT, buff=0.1)

        # mother_node.add(ptr)
        introduction_action = Tex("INTRODUCTION").scale(0.4).next_to(actions, DOWN, buff=0.25)
        introduction_effect = MathTex(r"?\langle\downarrow_0\rangle Ty(e), ?\langle\downarrow_1\rangle Ty(e\rightarrow t)").scale(0.7).next_to(mother_node, DOWN, buff=0.35)
        prediction = Tex("PREDICTION").scale(0.4).next_to(introduction_action, DOWN, buff=0.35)
        
        # ---------- Begin----------
        # self.play(FadeOut(begin))
        # self.play(Write(utterance)) # this is not working.
        # mother_node.add(ptr)
        self.play(Write(mother_node))
        self.play(Write(ptr))
        self.wait()
        # MISSING sth here
        # mother_node.remove(ptr)

        # ---------- INTRODUCTION ----------
        # actions.add(introduction)
        self.play(Write(introduction_action.set_color(green_latest)))
        self.wait(wait_after_action)
        self.play(Write(introduction_effect.set_color(green_latest)))
        self.wait(wait_after_effect)
        # actions.add(prediction)

        # ---------- PREDICTION ----------
        introduction_action.set_color(WHITE)
        introduction_effect.set_color(WHITE)
        functorLeft_node.set_color(green_latest)
        argumentRight_node.set_color(green_latest)
        mother_node.set_color(WHITE)
        # edge_l = Line(start=(-2,0,0), end=(-3,-1,0)).next_to(mother_node, DOWN, buff=0.0).set_color(WHITE)
        # edge_r = Line(start=np.array([0.0, -1.0, 0.0]), end=np.array([0.0, 14.0, 0.0])).next_to(mother_node, DOWN, buff=0.25).set_color(WHITE)
        self.play(Write(prediction.set_color(green_latest)),
                        MoveToTarget(functorLeft_node),# functorLeft_node.animate.next_to(mother_node, DOWN*3+LEFT*3, buff=0.75),
                        MoveToTarget(argumentRight_node))#,
                        # Create(edge_l))
        ptr.generate_target()
        u = Tex("John arrives").scale(0.85).next_to(mother_node, RIGHT, buff=0.4).set_color(BLUE)
        self.play(Write(mother_node+u))
        ptr.target.next_to(functorLeft_node, LEFT)#, LEFT*3+DOWN, buff=0.1)
        # self.play(Write(ptr.animate.next_to(), LEFT*2+DOWN, buff=0.1))
        self.play(MoveToTarget(ptr), Write(Tex(",").next_to(functorLeft_node, LEFT, buff=0.1)))#, Write(Tex(",").next_to(ptr, RIGHT, buff=0.05)))
        self.play(FadeOut(introduction_effect))
        # self.play(Write(Tex(",").next_to(functorLeft_node, LEFT, buff=0.1)))
        self.wait(wait_after_effect)
        prediction.set_color(WHITE)