import os
import shutil
from pathlib import Path

def create_project(project_name, template):
    base_dir = Path(__file__).parent
    template_dir = base_dir / "templates" / template

    target_dir = Path.cwd() / project_name

    if target_dir.exists():
        print("❌ Folder already exists")
        return

    shutil.copytree(template_dir, target_dir)