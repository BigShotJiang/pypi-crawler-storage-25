def query():
    question = input("Ask something: ")
    print(f"Answer: {question}")

if __name__ == "__main__":
    query()