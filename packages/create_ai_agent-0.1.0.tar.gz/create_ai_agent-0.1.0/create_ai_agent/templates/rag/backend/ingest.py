from langchain.document_loaders import TextLoader

def ingest():
    loader = TextLoader("data/sample.txt")
    docs = loader.load()
    print(f"Loaded {len(docs)} documents")

if __name__ == "__main__":
    ingest()