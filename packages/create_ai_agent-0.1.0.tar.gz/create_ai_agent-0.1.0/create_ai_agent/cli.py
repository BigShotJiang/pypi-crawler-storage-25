import click
from rich import print
from .generator import create_project

@click.command()
@click.argument("project_name", default="my-ai-app")
def main(project_name):
    print(f"\n🚀 Creating AI Agent: [bold]{project_name}[/bold]\n")

    template = click.prompt(
        "Select template",
        type=click.Choice(["rag"], case_sensitive=False),
        default="rag"
    )

    create_project(project_name, template)

    print("\n✅ Project created successfully!")
    print(f"\n👉 cd {project_name}")
    print("👉 pip install -r requirements.txt")
    print("👉 python backend/query.py\n")