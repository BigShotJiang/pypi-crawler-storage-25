from setuptools import setup, find_packages

setup(
    name="modulehub",
    version="1.0.1",
    author="Sviter",
    description="A library to install/publish modules",
    url="https://github.com/ISviterI/modulehub",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    project_urls={
        "Homepage": "https://github.com/ISviterI/modulehub",
        "Discord": "https://discord.gg/MXv3KTFmPE",
        "Wiki": "https://github.com/ISviterI/modulehub/wiki",
        "Documentation": "https://github.com/ISviterI/modulehub/wiki/Documentation",
    },
    packages=find_packages(),
    license="MIT",
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    keywords="modulehub,module,modules,module.py,hub,cool,peak,library,install,create,pip,py",
    install_requires=['requests']
)