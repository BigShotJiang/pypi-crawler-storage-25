# ModuleHub

[![PyPI version](https://img.shields.io/pypi/v/modulehub.svg)](https://pypi.org/project/modulehub/)
[![Python versions](https://img.shields.io/pypi/pyversions/modulehub.svg)](https://pypi.org/project/modulehub/)
[![License](https://img.shields.io/pypi/l/modulehub.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://img.shields.io/pypi/dm/modulehub.svg)](https://pypi.org/project/modulehub/)

**ModuleHub** — a marketplace for Python modules where you can install and publish scripts.

## Features

- Install modules — `modulehub.install({modulename})`
- Search — `modulehub.search({text})`
- Publish — `modulehub.publish({many arguments})`
- More info — `modulehub.more({modulename})`

### Installation
```bash
pip install modulehub
```