import requests
database_url = "https://pastebin.com/raw/y9jDpj9h"
def get_database():
    try:
        response = requests.get(database_url, timeout=10)
        response.raise_for_status()

        raw_data = response.text.strip()
        modules = []

        for item in raw_data.split(";^"):
            if not item:
                continue
            parts = item.split(":^")
            if parts[0].startswith("\r\n"):
                parts[0] = parts[0][2:]
            modules.append({
                "name": parts[0],
                "desc": parts[1] if len(parts) > 1 else "No description",
                "code": parts[2] if len(parts) > 2 else None,
                "version": parts[3] if len(parts) > 3 else "1.0.0",
                "discord_un": parts[4] if len(parts) > 4 else None,
                "documentation_link": parts[5] if len(parts) > 5 else "No documentation",
            })
        return modules
    except Exception as e:
        print(e)
        return []

def convert_to_mstring(name:str,desc:str,code:str,version:str="1.0.0",discord_un:str="No discord",documentation_link:str="No documentation"):
    mstr = ""
    length = 6
    added = 0
    def add(text):
        nonlocal mstr
        nonlocal added
        added += 1
        mstr += text
        if added == length:
            mstr += ";^"
        else:
            mstr += ":^"
    add(name)
    add(desc)
    add(code)
    add(version)
    add(discord_un)
    add(documentation_link)
    return mstr

def show(modules:list):
    mstr = "Modules:\n"
    for module in modules:
        #print(module)
        mstr += f"{module['name']}: Type `.more('{module['name']}')` to get more info\n"
    print(mstr)

def search(name:str):
    results = []
    for i in get_database():
        if i["name"].startswith(name):
            results.append(i)
    show(results)
    return results

def more(name:str):
    module = find(name)
    info = module["name"] + ":\n"
    info += f"Description: {module['desc']}\n"
    info += f"Version: {module['version']}\n"
    info += f"Documentation: {module['documentation_link']}\n"
    info += f"To install type: .install('{module["name"]}')"
    print(info)
    return info

def find(name:str):
    result = {}
    for i in get_database():
        if i["name"] == name:
            result = i
            break
    return result

def install(name:str):
    module = find(name)
    if module:
        with open(f"{module["name"]}.py", "w", encoding="utf-8") as f:
            f.write(module["code"])
            print(f"Installed {module['name']}")



def publish(name:str,desc:str,filename:str,version:str=None,discord_un:str=None,documentation_link:str=None):
    code = ""
    with open(filename, "r") as f:
        code = f.read()
    if code:
        mstring = convert_to_mstring(name, desc, code, version, discord_un, documentation_link)
        dcdata = {
            "content": name,
            "embeds": [{
                "title": "Extra",
                "description": "extra...",
                "color": 0x06ab00,
                "fields": [
                    {
                        "name": "String:",
                        "value": mstring,
                        "inline": False
                    },
                    {
                        "name": "Description:",
                        "value": desc,
                        "inline": False
                    },
                    {
                        "name": "Code:",
                        "value": code,
                        "inline": False
                    },
                    {
                        "name": "Version:",
                        "value": str(version),
                        "inline": False
                    },
                    {
                        "name": "Creator:",
                        "value": str(discord_un),
                        "inline": False
                    },
                    {
                        "name": "Documentation:",
                        "value": str(documentation_link),
                        "inline": False
                    },
                ]
            }]
        }
        print("Sending module's data to the check")
        response = requests.post("https://discord.com/api/webhooks/1492237771757195375/wdWXiaMGoBLBZKMPoeqB2jEu02DKfG4ZiDqIAPOQSEHgThTsiWKYkb9Tqy_a8UEcsMSe", json=dcdata, timeout=10)
        response.raise_for_status()
        print("Sent module's data to the check")
    else:
        print("No code found")
