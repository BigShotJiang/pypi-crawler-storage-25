"""Test L0 sensory layer — BM25 / FTS5 scoring."""
import sqlite3
import tempfile
import os
import pytest


def _create_fts_db(path: str, rows: list[tuple[str, str]]):
    """Create a temp SQLite DB with FTS5 table and insert rows."""
    conn = sqlite3.connect(path)
    conn.execute("CREATE VIRTUAL TABLE IF NOT EXISTS docs USING fts5(title, body)")
    conn.executemany("INSERT INTO docs(title, body) VALUES (?, ?)", rows)
    conn.commit()
    return conn


def _search(conn: sqlite3.Connection, query: str, limit: int = 10):
    """BM25-ranked search over FTS5 table."""
    cur = conn.execute(
        "SELECT title, body, rank FROM docs WHERE docs MATCH ? ORDER BY rank LIMIT ?",
        (query, limit),
    )
    return cur.fetchall()


class TestFTS5Search:
    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmpdir, "test.db")
        self.rows = [
            ("Memory Architecture", "Bio-inspired memory uses Hebbian learning and spreading activation"),
            ("Pruning Strategy", "Memory pruning removes low-confidence entries after decay"),
            ("Graph Layer", "Neo4j stores entity relationships for spreading activation queries"),
            ("Vector Search", "Qdrant provides approximate nearest neighbour search for embeddings"),
            ("Unrelated", "The weather today is sunny with clear skies"),
        ]
        self.conn = _create_fts_db(self.db_path, self.rows)

    def teardown_method(self):
        self.conn.close()

    def test_search_returns_results(self):
        results = _search(self.conn, "memory")
        assert len(results) >= 2
        titles = [r[0] for r in results]
        assert "Memory Architecture" in titles

    def test_search_ranking(self):
        results = _search(self.conn, "spreading activation")
        assert len(results) >= 2
        # Both memory architecture and graph layer mention spreading activation
        titles = [r[0] for r in results]
        assert "Memory Architecture" in titles
        assert "Graph Layer" in titles

    def test_search_no_results(self):
        results = _search(self.conn, "nonexistent_xyz_term")
        assert len(results) == 0

    def test_search_limit(self):
        results = _search(self.conn, "memory OR search OR activation", limit=2)
        assert len(results) <= 2

    def test_bm25_scores_are_negative(self):
        """FTS5 rank values are negative (lower = better match)."""
        results = _search(self.conn, "memory")
        for r in results:
            assert r[2] < 0  # rank column
