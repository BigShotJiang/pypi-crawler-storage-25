"""L2 Orchestrator — HybridRAG fusion across memory layers.

Bio-inspired analogy: **Prefrontal cortex** (executive function).
Coordinates parallel retrieval from available layers, extracts entities
from the query, fuses results with adaptive scoring, deduplicates by
content, and returns a unified ranked result set.

Core tier fuses 3 layers: L0 (keyword), L3 (graph), L4 (vector).
L1 (system files) provides context but is loaded separately.
"""

import concurrent.futures
import logging
import re
import time
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

GRAPH_PRIORITY_BOOST = 0.5
VECTOR_BASE_WEIGHT = 0.5


def extract_query_entities(query: str) -> List[str]:
    """Extract potential entities (proper nouns) from a query string."""
    words = [re.sub(r"[^\w\s-]", "", w).strip() for w in query.split()]
    words = [w for w in words if w]
    stop_words = {
        "what", "who", "where", "when", "how", "does", "did",
        "the", "and", "for", "with", "from", "about", "this", "that",
    }
    potential_entities: List[str] = []
    for word in words:
        if word.istitle() and len(word) > 2 and word.lower() not in stop_words:
            potential_entities.append(word)
    for i in range(len(words) - 1):
        if (
            words[i].istitle()
            and words[i + 1].istitle()
            and words[i].lower() not in stop_words
        ):
            potential_entities.append(f"{words[i]} {words[i + 1]}")
    return potential_entities


class L2Orchestrator:
    """HybridRAG orchestrator — fuses L0, L1, L3, L4 results.

    Args:
        config: Dict with optional ``enable_l0``, ``enable_l1``,
                ``enable_l3``, ``enable_l4`` booleans (default True).
        layers: Dict mapping layer names to layer instances.
                Expected keys: ``"l0"``, ``"l1"``, ``"l3"``, ``"l4"``.
    """

    LAYER_PRIORITIES = {
        "L1": 1.0,
        "L3": 0.95,
        "L4": 0.70,
        "L0": 0.70,
    }

    def __init__(self, config: Dict[str, Any], layers: Dict[str, Any]) -> None:
        self.config = config
        self.layers = layers

    def _is_enabled(self, key: str) -> bool:
        return self.config.get(f"enable_{key}", True)

    def search(
        self,
        query: str,
        limit: int = 16,
        namespace: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Search across all enabled layers with fusion and deduplication."""
        t0 = time.time()

        entities = extract_query_entities(query)

        # -- Parallel retrieval: L0, L1, L3 --
        l0_results: List[Dict] = []
        l1_results: List[Dict] = []
        graph_context: Dict[str, Any] = {"results": [], "entities": entities}

        def _run_l0():
            if self._is_enabled("l0") and "l0" in self.layers:
                return self.layers["l0"].search(query, limit=10)
            return []

        def _run_l1():
            if self._is_enabled("l1") and "l1" in self.layers:
                return self.layers["l1"].search(query, limit=8)
            return []

        def _run_l3():
            if self._is_enabled("l3") and "l3" in self.layers:
                return self.layers["l3"].search(query, limit=10, entities=entities)
            return {"results": [], "entities": entities}

        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            f_l0 = pool.submit(_run_l0)
            f_l1 = pool.submit(_run_l1)
            f_l3 = pool.submit(_run_l3)

            l0_results = f_l0.result(timeout=10) or []
            l1_results = f_l1.result(timeout=10) or []
            graph_context = f_l3.result(timeout=10) or {"results": [], "entities": entities}

        parallel_ms = (time.time() - t0) * 1000

        # Handle L3 returning a dict with results key
        if isinstance(graph_context, dict):
            l3_results = graph_context.get("results", [])
            entities = graph_context.get("entities", entities)
        else:
            l3_results = graph_context
            graph_context = {"results": l3_results, "entities": entities}

        # -- Sequential: L4 vector search (may use graph entities as cues) --
        l4_results: List[Dict] = []
        if self._is_enabled("l4") and "l4" in self.layers:
            try:
                l4_results = self.layers["l4"].search(
                    query, limit=10,
                    graph_context=graph_context,
                    namespace=namespace,
                ) or []
            except Exception as exc:
                log.warning("L4 search failed: %s", exc)

        log.info(
            f"Parallel retrieval: L0={len(l0_results)} L1={len(l1_results)} "
            f"L3={len(l3_results)} (parallel done in {parallel_ms:.0f}ms)"
        )

        # -- Fusion --
        all_results = l0_results + l1_results + l3_results + l4_results

        # Normalise into dicts
        normalised: List[Dict[str, Any]] = []
        for r in all_results:
            if isinstance(r, dict):
                normalised.append(r)
            elif hasattr(r, "__dict__"):
                normalised.append(vars(r))

        # Apply layer priority scoring
        for r in normalised:
            layer = r.get("layer", "")
            priority = self.LAYER_PRIORITIES.get(layer, 0.5)
            raw_score = r.get("score", 0.0)
            r["score"] = raw_score * priority

            # Graph entity boost
            if layer == "L3":
                r["score"] += GRAPH_PRIORITY_BOOST

        # Deduplicate by text content
        seen_texts: set = set()
        deduped: List[Dict[str, Any]] = []
        for r in normalised:
            text_key = r.get("text", "")[:200].strip().lower()
            if text_key and text_key not in seen_texts:
                seen_texts.add(text_key)
                deduped.append(r)

        # Sort by fused score
        deduped.sort(key=lambda r: r.get("score", 0.0), reverse=True)

        total_ms = (time.time() - t0) * 1000
        log.info(
            f"Fusion complete: {len(deduped)} results from "
            f"(L0={len(l0_results)}, L1={len(l1_results)}, "
            f"L3={len(l3_results)}, L4={len(l4_results)}) "
            f"in {total_ms:.0f}ms"
        )

        return deduped[:limit]
