"""L0 Full-Text Search — BM25/FTS5 keyword matching.

Bio-inspired analogy: **Reflexive pattern detection** (brainstem level).
The fastest, lowest-latency layer — sub-millisecond keyword matching over
pre-indexed workspace chunks. No network calls, no embeddings. Pure lexical
recall, like a startle reflex that fires before conscious processing begins.
"""

import logging
import sqlite3
from typing import Dict, List, Optional

log = logging.getLogger(__name__)

# Stop words filtered from queries to improve BM25 precision
_STOP_WORDS = frozenset({
    "the", "and", "for", "with", "that", "this", "from", "what",
    "how", "does", "have", "has", "are", "was", "were", "been",
})


class L0FullTextSearch:
    """BM25 keyword search over SQLite FTS5-indexed workspace chunks.

    Scores are normalised into [0, 0.70] using a dampened relevance formula
    so they sit below graph/vector layers in the fusion ranking.
    """

    def __init__(self, db_path: str) -> None:
        """Initialise with path to the SQLite database containing FTS5 tables.

        Args:
            db_path: Filesystem path to the SQLite DB (must have ``chunks_fts`` virtual table).
        """
        self.db_path = db_path

    def search(
        self,
        query: str,
        limit: int = 6,
        namespace: Optional[str] = None,
    ) -> List[Dict]:
        """Run BM25 keyword search.

        Args:
            query: Natural-language query string.
            limit: Maximum results to return.
            namespace: If set, restrict results to paths starting with this prefix.

        Returns:
            List of result dicts with keys: path, text, score, layer, source.
        """
        import os

        if not os.path.exists(self.db_path):
            return []

        try:
            tokens = query.lower().split()
            meaningful = [
                t for t in tokens
                if len(t) > 2 and t not in _STOP_WORDS
            ]
            if not meaningful:
                return []

            fts_query = " OR ".join(f'"{t}"' for t in meaningful)

            conn = sqlite3.connect(self.db_path, timeout=2)
            conn.execute("PRAGMA journal_mode=WAL")

            sql = """
                SELECT path, text, bm25(chunks_fts) as rank
                FROM chunks_fts
                WHERE chunks_fts MATCH ?
            """
            params: list = [fts_query]

            if namespace:
                sql += " AND path LIKE ? || '%'"
                params.append(namespace)

            sql += " ORDER BY rank ASC LIMIT ?"
            params.append(limit * 2)

            rows = conn.execute(sql, params).fetchall()
            conn.close()

            results: List[Dict] = []
            seen_paths: set = set()
            for path, text, rank in rows:
                if path in seen_paths:
                    continue
                seen_paths.add(path)

                # BM25 returns negative ranks; convert to positive relevance
                relevance = -rank if rank < 0 else 0.001
                # Dampened score capped at 0.70 so L0 doesn't outrank deeper layers
                score = min(relevance / (1 + relevance) * 0.75, 0.70)

                results.append({
                    "path": path,
                    "text": text[:600],
                    "score": round(score, 4),
                    "layer": "L0",
                    "source": "bm25",
                })
                if len(results) >= limit:
                    break

            return results

        except Exception as e:
            log.debug(f"L0 BM25 search error: {e}")
            return []
