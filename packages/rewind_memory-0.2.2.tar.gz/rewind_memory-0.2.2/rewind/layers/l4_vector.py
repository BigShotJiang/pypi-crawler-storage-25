"""L4 Vector — sqlite-vec semantic search informed by graph context.

Bio-inspired analogy: **Episodic memory** (hippocampus).
Dense vector similarity over experience chunks — the way the hippocampus
encodes episodes as distributed patterns and retrieves them by pattern
completion. Graph entities from L3 act as retrieval cues, boosting chunks
that mention known entities (context-dependent recall).
"""

import logging
import os
import sqlite3
import struct
from typing import Callable, Dict, List, Optional

log = logging.getLogger(__name__)

# Scoring weights (must match L2 orchestrator expectations)
VECTOR_BASE_WEIGHT = 0.5


class L4Vector:
    """Semantic search over pre-embedded chunks using sqlite-vec (vec0).

    Converts L2 distance to cosine similarity::

        cos_sim = 1.0 - (l2_dist ** 2) / 2.0

    Final score combines cosine similarity, entity boost from L3 graph
    context, and a small bonus for benchmark/fact paths::

        score = (cos_sim * VECTOR_BASE_WEIGHT) + entity_boost + fact_boost
    """

    def __init__(
        self,
        db_path: str,
        vec_extension_path: Optional[str] = None,
        embedding_fn: Optional[Callable[[str], List[float]]] = None,
    ) -> None:
        """Initialise vector search layer.

        Args:
            db_path: Path to the SQLite database with ``chunks`` and ``chunks_vec`` tables.
            vec_extension_path: Path to the ``vec0.so`` shared library. Auto-detected if *None*.
            embedding_fn: Callable that takes a string and returns a float list embedding.
        """
        self.db_path = db_path
        self.vec_extension_path = vec_extension_path
        self.embedding_fn = embedding_fn

    @staticmethod
    def _load_vec0(conn: sqlite3.Connection, vec0_path: Optional[str]) -> bool:
        """Load the sqlite-vec extension into *conn*. Returns True on success."""
        if vec0_path:
            try:
                conn.enable_load_extension(True)
                conn.load_extension(vec0_path)
                return True
            except Exception as e:
                log.warning(f"Failed to load vec0 from {vec0_path}: {e}")
                return False

        from rewind.utils import load_vec0
        return load_vec0(conn)

    def search(
        self,
        query: str,
        graph_context: Optional[Dict] = None,
        limit: int = 12,
        namespace: Optional[str] = None,
    ) -> List[Dict]:
        """Run vector similarity search, optionally boosted by L3 graph context.

        Args:
            query: Natural-language query string.
            graph_context: Dict with ``graph_entities`` list from L3. If provided,
                chunks mentioning those entities receive a score boost.
            limit: Maximum results to return.
            namespace: If set, post-filter results to paths starting with this prefix
                (benchmark paths are always included).

        Returns:
            List of result dicts with keys: path, text, score, source, layer,
            base_similarity, entity_boost, l2_distance.
        """
        if not os.path.exists(self.db_path):
            return []

        if graph_context is None:
            graph_context = {"graph_entities": []}

        # Build enhanced query embedding using graph entities as cues
        enhanced_query = query
        graph_entities = graph_context.get("graph_entities", [])
        if graph_entities:
            enhanced_query += " " + " ".join(graph_entities[:3])

        if self.embedding_fn is None:
            log.error("No embedding function configured for L4")
            return []

        query_embedding = self.embedding_fn(enhanced_query)
        if not query_embedding:
            query_embedding = self.embedding_fn(query)
        if not query_embedding:
            return []

        try:
            conn = sqlite3.connect(self.db_path, timeout=5)
            conn.row_factory = sqlite3.Row

            if not self._load_vec0(conn, self.vec_extension_path):
                log.error("vec0 unavailable — L4 vector search disabled")
                conn.close()
                return []

            # Over-fetch to allow namespace filtering and quality re-ranking
            fetch_k = max(limit * 8, 80)
            blob = struct.pack(f"{len(query_embedding)}f", *query_embedding)

            vec_rows = conn.execute(
                "SELECT rowid, distance FROM chunks_vec "
                "WHERE embedding MATCH ? AND k = ? ORDER BY distance",
                (blob, fetch_k),
            ).fetchall()

            results: List[Dict] = []
            for chunk_id, l2_dist in vec_rows:
                # Convert L2 distance to cosine similarity (for normalised vectors)
                cosine_sim = 1.0 - (l2_dist ** 2) / 2.0

                if cosine_sim < (0.0 if namespace else 0.15):
                    continue

                row = conn.execute(
                    "SELECT path, text, source FROM chunks WHERE id = ?",
                    (chunk_id,),
                ).fetchone()
                if not row:
                    continue

                path = row["path"]
                text = row["text"] or ""

                # Namespace filter (benchmark paths always pass)
                if namespace:
                    is_benchmark = (
                        "benchmark/facts/" in path
                        or "benchmark/conversations/" in path
                    )
                    if not path.startswith(namespace) and not is_benchmark:
                        continue

                # Entity boost from L3 graph context
                entity_boost = 0.0
                path_lower = path.lower()
                text_lower = text.lower()
                for entity in graph_entities:
                    if entity.lower() in path_lower or entity.lower() in text_lower:
                        entity_boost = 0.5  # GRAPH_PRIORITY_BOOST
                        break

                # Fact chunk boost
                fact_boost = 0.05 if "benchmark/facts/" in path else 0.0

                score = (cosine_sim * VECTOR_BASE_WEIGHT) + entity_boost + fact_boost

                results.append({
                    "path": path,
                    "text": text[:600],
                    "score": score,
                    "source": "vector",
                    "layer": "L4",
                    "base_similarity": round(cosine_sim, 4),
                    "entity_boost": entity_boost,
                    "l2_distance": round(l2_dist, 4),
                })

                if len(results) >= limit:
                    break

            conn.close()

            results.sort(key=lambda x: x["score"], reverse=True)
            if results:
                log.info(
                    f"L4 vec0 search: {len(results)} results "
                    f"(top sim={results[0]['base_similarity']:.3f})"
                )
            else:
                log.info("L4 vec0 search: 0 results")
            return results[:limit]

        except Exception as e:
            log.error(f"L4 vec0 search failed: {e}")
            return []
