"""Ollama embedding provider (768-dim, free tier)."""

from typing import List, Optional

import httpx

from .base import EmbeddingProvider


class OllamaProvider(EmbeddingProvider):
    """Embedding provider using Ollama's local ``nomic-embed-text`` model."""

    _DIMENSION = 768

    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        model: str = "nomic-embed-text",
        target_dim: int = 768,
        timeout: float = 15.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.target_dim = target_dim
        self.timeout = timeout

    @property
    def dimension(self) -> int:
        return self.target_dim

    def _pad(self, vec: List[float]) -> List[float]:
        """Zero-pad to target dimension if needed."""
        if len(vec) >= self.target_dim:
            return vec[: self.target_dim]
        return vec + [0.0] * (self.target_dim - len(vec))

    def embed(self, text: str) -> Optional[List[float]]:
        try:
            resp = httpx.post(
                f"{self.base_url}/api/embeddings",
                json={"model": self.model, "prompt": text[:2048]},
                timeout=self.timeout,
            )
            resp.raise_for_status()
            vec = resp.json().get("embedding")
            return self._pad(vec) if vec else None
        except Exception:
            return None

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        results: List[List[float]] = []
        for text in texts:
            vec = self.embed(text)
            results.append(vec if vec else [])
        return results
