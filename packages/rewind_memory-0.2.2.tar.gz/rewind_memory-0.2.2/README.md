# 🧠 Rewind Memory

**Bio-inspired persistent memory for AI agents.**

Rewind gives AI agents structured, persistent memory that works like biological memory — keyword search, knowledge graphs, semantic vectors, and score fusion. Runs fully local on SQLite with zero external dependencies.

## Architecture

```
┌─────────────────────────────────────────┐
│            L2 Orchestrator              │
│    (fusion · ranking · deduplication)   │
├─────────┬─────────┬─────────┬──────────┤
│   L0    │   L1    │   L3    │    L4    │
│Sensory  │ System  │  Graph  │  Vector  │
│ Buffer  │  Files  │         │  Search  │
│         │         │         │          │
│ SQLite  │  File   │ SQLite  │sqlite-vec│
│  FTS5   │ system  │  Graph  │ (vec0)   │
└─────────┴─────────┴─────────┴──────────┘
```

## Layers

| Layer | Name | Bio Analogy | Backend | Purpose |
|-------|------|-------------|---------|---------|
| **L0** | Sensory Buffer | Sensory cortex | SQLite FTS5 | Fast keyword search, BM25 ranking |
| **L1** | System Memory | Working memory | File system | Identity, preferences, context — loaded every session |
| **L2** | Orchestrator | Prefrontal cortex | In-process | Fuses keyword + graph + vector results |
| **L3** | Knowledge Graph | Association cortex | SQLite | Entity relationships, spreading activation, Hebbian learning |
| **L4** | Vector Search | Episodic memory | sqlite-vec | Semantic similarity via local embeddings (Ollama) |

## Quick Start

```bash
pip install rewind-memory
```

### Prerequisites

For vector search (L4), install a local embedding model:

```bash
# Install Ollama (https://ollama.com)
ollama pull nomic-embed-text  # ~274MB
```

### Usage

```python
from rewind.client import RewindClient
from rewind.config import default_config

client = RewindClient(default_config("free"))

# Search across all layers
results = client.search("what is Hebbian learning")
for r in results:
    print(f"{r.score:.2f} [{r.layer}] {r.text[:80]}")

# Ingest a document
client.ingest("notes/meeting.md")

# Health check
print(client.health())
```

### CLI

```bash
# Search
rewind search "memory consolidation" --limit 10

# Ingest files
rewind ingest ./documents/

# Health check
rewind health
```

### Integrations (Claude Code, Cursor, OpenClaw)

Rewind ships with an MCP server that works with any MCP-compatible tool:

```bash
# Start the API
rewind serve --port 8031
```

**Claude Code** — add to `~/.claude/settings.json`:
```json
{
  "mcpServers": {
    "rewind": {
      "command": "rewind-mcp",
      "env": { "REWIND_API_URL": "http://localhost:8031" }
    }
  }
}
```

**OpenClaw** — one command:
```bash
rewind-openclaw setup --url http://localhost:8031
```

**Cursor / Windsurf / Cline** — add `rewind-mcp` as an MCP server in settings.

See [docs/INTEGRATIONS.md](docs/INTEGRATIONS.md) for full setup guides.

### Memory Proxy (zero-config, works with any tool)

The proxy auto-injects memory into every LLM call. No MCP needed — just change your API URL:

```bash
pip install rewind-memory[proxy]

# Ingest your project first
rewind ingest ./my-project/

# Start the memory proxy
rewind proxy --port 8080
```

Then point your tool at it:

```bash
# Cursor
OPENAI_BASE_URL=http://localhost:8080/v1 cursor .

# Aider
OPENAI_API_BASE=http://localhost:8080/v1 aider

# Any OpenAI-compatible tool
export OPENAI_BASE_URL=http://localhost:8080/v1
```

The proxy:
- Searches memory on every prompt (keyword + graph + vector fusion)
- Injects relevant context into the system message
- Auto-budgets injection size based on model context limits
- Passes through your API key to the upstream provider
- Supports streaming responses
- Works with OpenAI, Anthropic, NVIDIA, any OpenAI-compatible API

```bash
# Point at Anthropic instead of OpenAI
rewind proxy --port 8080 --upstream https://api.anthropic.com/v1

# Point at a local model
rewind proxy --port 8080 --upstream http://localhost:11434/v1
```

## Configuration

```yaml
# ~/.rewind/config.yaml
tier: free
workspace_path: ~/my-project

embedding:
  provider: ollama
  model: nomic-embed-text
  url: http://localhost:11434

layers:
  l0_sensory: true
  l1_stm: true
  l3_graph: true
  l4_workspace: true
```

## Upgrading

Rewind Core is free and fully functional as a local memory stack. For additional layers (communications, documents, bio lifecycle) and cloud GPU embeddings, see [Rewind Pro](https://saraidefence.com/#pricing).

Pro extends the Core package via a plugin — install both and Pro layers activate automatically:

```python
client = RewindClient(default_config("pro"), api_key="rw_live_...")
```

| Feature | Core (Free) | Pro ($9/mo) | MOS (Custom) |
|---------|-------------|-------------|--------------|
| Keyword search (FTS5) | ✅ | ✅ | ✅ |
| System memory | ✅ | ✅ | ✅ |
| Knowledge graph (SQLite) | ✅ | ✅ | ✅ |
| Semantic vector search | ✅ local Ollama | ✅ cloud H100 GPU | ✅ custom GPU |
| HybridRAG fusion | ✅ 3-layer (keyword + graph + vector) | full 7-layer | full 7-layer |
| Communications memory (L5) | — | ✅ | ✅ |
| Document store (L6) | — | ✅ | ✅ |
| Cloud GPU embeddings | — | 100K/mo included | custom rates |
| Retrieval feedback learning | — | ✅ | ✅ |
| Migration assist (→ Neo4j/Qdrant) | — | ✅ | ✅ |
| Bio lifecycle (decay, pruning) | — | — | ✅ |
| Air-gapped deployment | — | — | ✅ |
| Dedicated engineer + SLA | — | — | ✅ |

## Development

```bash
git clone https://github.com/saraidefence/rewind-memory.git
cd rewind-memory
pip install -e ".[dev]"
pytest tests/
```

## Patent

The 7-layer bio-inspired memory architecture is patent pending.

## License

Apache License 2.0 — see [LICENSE](LICENSE).

---

Built by [SARAI Defence](https://saraidefence.com). Ukrainian-built. Patent pending.
