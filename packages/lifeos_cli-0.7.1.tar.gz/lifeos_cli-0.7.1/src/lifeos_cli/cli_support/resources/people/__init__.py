"""People resource CLI support."""
