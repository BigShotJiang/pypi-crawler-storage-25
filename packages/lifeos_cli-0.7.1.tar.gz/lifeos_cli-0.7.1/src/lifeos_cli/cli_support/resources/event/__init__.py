"""Event CLI resource package."""
