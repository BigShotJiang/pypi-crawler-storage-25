"""Vision resource CLI support."""
