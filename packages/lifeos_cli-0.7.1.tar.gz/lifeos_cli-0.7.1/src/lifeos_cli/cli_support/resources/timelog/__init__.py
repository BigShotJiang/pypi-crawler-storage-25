"""Timelog CLI resource package."""
