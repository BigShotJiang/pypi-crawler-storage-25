"""Note resource CLI support."""
