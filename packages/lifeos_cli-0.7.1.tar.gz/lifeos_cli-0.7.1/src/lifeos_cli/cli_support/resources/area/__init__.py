"""Area resource CLI support."""
