"""Habit CLI resource package."""
