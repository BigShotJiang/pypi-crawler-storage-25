"""Tag resource CLI support."""
