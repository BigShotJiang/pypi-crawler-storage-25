"""Task resource CLI support."""
