"""Schedule CLI resource package."""
