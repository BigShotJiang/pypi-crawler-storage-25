# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import copy
import datetime
import json
import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Union

from omni.asset_validator import (
    Capability,
    CapabilityRegistry,
    Issue,
    IssueSeverity,
    ProfileRegistry,
    RequirementsRegistry,
    ValidationEngine,
)
from pxr import Usd

from .impl.loader import load_validation_implementation


@dataclass
class AssetValidationResult:
    """Outcome of validating a single USD asset against a SimReady profile.

    Attributes:
        asset_path: Path to the validated USD file.
        profile_id: ID of the profile validated against
            (e.g. ``"Prop-Robotics-Neutral"``).
        profile_version: Version string of the profile (e.g. ``"2.0.0"``).
        features_summary: Per-feature result map keyed by feature ID. Each
            value contains at minimum ``"version"`` (str) and ``"passed"``
            (bool); failed features also include ``"failing requirements"``
            (str).
        issues: Raw list of failing :class:`omni.asset_validator.Issue`
            objects (severity ERROR or FAILURE) from the validation engine.
    """

    asset_path: str
    profile_id: str
    profile_version: str
    features_summary: dict[str, dict]
    issues: list[Issue]


@dataclass
class AssetValidationConfig:
    """Configuration for a single asset validation request.

    Attributes:
        asset_path: Path to the ``.usd`` or ``.usda`` file to validate.
        profile_id: ID of the SimReady profile to validate against. When
            ``None``, the profile is inferred from
            ``customLayerData["SimReady_Metadata"]["validation"]["profile"]``
            stamped in the asset's USD metadata.
        profile_version: Specific profile version to validate against. When
            ``None``, any registered version of ``profile_id`` is accepted.
            Ignored when ``profile_id`` is ``None``.
        write_metadata: When ``True``, stamp the validation outcome into the
            asset's ``customLayerData`` and save the file in place.
    """

    asset_path: str
    profile_id: str | None = None
    profile_version: str | None = None
    write_metadata: bool = False


logger = logging.getLogger("SimReady Validation")


def _validate_asset_with_profile(
    input: Union[Usd.Stage, str], profile_id: str, profile_version: str | None = None
) -> list[Issue]:
    """Validate the asset with the given profile"""
    stage = input if isinstance(input, Usd.Stage) else Usd.Stage.Open(input)

    profile = ProfileRegistry().find_profile(profile_id, profile_version)
    if not profile:
        return [
            Issue(
                f"Profile '{profile_id}' with version '{profile_version}' not found among registered profiles.",
                severity=IssueSeverity.ERROR,
                at=stage,
            )
        ]

    # Enable the validation rules for the profile
    engine = ValidationEngine(init_rules=False, variants=False)
    for capability in sorted(profile.capabilities, key=lambda c: c.id):
        logger.info(f"Validation feature: {capability.id} ({capability.version})")

        # copy the capability with all dependent requirements
        capability_copy, _ = _copy_capability_with_dependencies(capability, log=True)

        sorted_requirements = sorted(capability_copy.requirements, key=lambda r: r.code)
        for requirement in sorted_requirements:
            if rule := RequirementsRegistry().get_validator(requirement):
                logger.info(f"  Requirement: {requirement.code}: Rule: {rule}")
            else:
                logger.error(f"  Requirement: {requirement.code}: Rule not found")

        engine.enable_capability(capability_copy)

    results = engine.validate(stage)

    logger.info("Asset validation complete.")

    failure_issues = []
    for issue in results.issues().filter_by(lambda i: i.severity in (IssueSeverity.ERROR, IssueSeverity.FAILURE)):
        failure_issues.append(issue)

    return failure_issues


def _build_features_validation_summary(
    validation_results: list[Issue], profile_id: str, profile_version: str, include_failed_requirements: bool = True
) -> dict[str, dict]:
    """
    Build the features summary dictionary from the validation results
    """

    # Collect failed requirements
    issues_missing_requirement = set()
    failed_requirements = set()

    for issue in validation_results:
        if issue.requirement is None:
            if issue.rule is not None:
                logger.warning(f"Rule {issue.rule} did not specify a requirement for an issue.")
                issues_missing_requirement.add(issue.rule)
        else:
            failed_requirements.add(issue.requirement.code)

    try:
        profile = ProfileRegistry().find_profile(profile_id, profile_version)
        if profile is None:
            logger.warning(f"Profile {profile_id} not found.")
            return {}

        # Get a copy of features with all dependent requirements to avoid mutating original data
        features = []

        for capability in profile.capabilities:
            feature_copy, dependencies = _copy_capability_with_dependencies(capability)
            features.append(feature_copy)

            # Also add dependencies that are not already in features
            for dep in dependencies:
                if all(not (dep.id == f.id and dep.version == f.version) for f in features):
                    features.append(dep)

        for feature in features:
            for requirement in feature.requirements:
                # try to match requirementless issues with the requirements associated with its rule
                if RequirementsRegistry().get_validator(requirement) in issues_missing_requirement:
                    failed_requirements.add(requirement.code)

        # Build features summary
        features_summary = {}
        for feature in features:
            feature_id = feature.id
            feature_requirements = feature.requirements
            failed_feature_requirements = [req.code for req in feature_requirements if req.code in failed_requirements]

            features_summary[feature_id] = {
                "version": feature.version,
                "dependencies": str(feature.custom_data.get("dependencies", [])),
                "passed": not failed_feature_requirements,
            }

            if failed_feature_requirements:
                logger.info(f"Failed requirements {failed_feature_requirements} preclude feature {feature_id}.")

            if failed_feature_requirements and include_failed_requirements:
                features_summary[feature_id]["failing requirements"] = str(failed_feature_requirements)

        return features_summary
    except AttributeError as e:
        logger.warning(f"Unable to get features from the config: {e}")
        return {}


def _copy_capability_with_dependencies(capability: Capability, log: bool = False) -> tuple[Capability, set[Capability]]:
    """Copy a capability and collect all its dependent requirements recursively.

    This function creates a deep copy of the capability and recursively adds
    requirements from all feature dependencies without mutating the original data.

    Args:
        capability: The capability to copy

    Returns:
        A copy of the capability with all dependent requirements included
    """
    # copy the capability
    capability_copy = copy.copy(capability)
    feature_depency_set = set()

    # add the requirements of the feature dependencies
    if capability_copy.custom_data:
        # get the dependencies from the custom data, make sure its a copy
        feature_dependencies = list(capability_copy.custom_data.get("dependencies", []))
        processed_dependencies = set()  # Track processed dependencies to avoid infinite loops

        while feature_dependencies:
            current_dependency = feature_dependencies.pop(0)

            # Handle dependency format: {"FET_001": {"version": "0.1.0"}} (version is optional)
            try:
                dependency_id = list(current_dependency.keys())[0]
                dependency_version = list(current_dependency.values())[0].get("version", "")
            except Exception as e:
                logger.error(f"Error extracting dependency_id and version from dependency {current_dependency}: {e}")
                continue

            dependency_key = f"{dependency_id}_{dependency_version}"
            if dependency_key in processed_dependencies:
                continue

            processed_dependencies.add(dependency_key)

            feature_dependency = CapabilityRegistry().find(dependency_id, dependency_version)

            if feature_dependency:
                if log:
                    logger.info(f"  Feature dependency: {feature_dependency.id} ({feature_dependency.version})")
                feature_depency_set.add(feature_dependency)
                capability_copy.requirements.extend(feature_dependency.requirements)

                # add any new dependencies to the queue, already processed dependencies are skipped
                if feature_dependency.custom_data:
                    dependencies = feature_dependency.custom_data.get("dependencies", [])
                    for dependency in dependencies:
                        feature_dependencies.append(dependency)

            elif log:
                logger.error(f"  Feature dependency not found: {dependency_id}_{dependency_version}")
    # dedupe the requirements before returning
    capability_copy.requirements = list(set(capability_copy.requirements))

    return capability_copy, feature_depency_set


# TODO:
# Note: get/set validation metadata should be hoisted to a different library.


def get_simready_validation_metadata(stage: Usd.Stage) -> dict:
    """Return the SimReady validation metadata stored in a USD stage.

    Reads ``customLayerData["SimReady_Metadata"]["validation"]`` from the
    root layer of *stage*.

    Args:
        stage: An open :class:`pxr.Usd.Stage`.

    Returns:
        The validation sub-dict, or an empty dict when no SimReady metadata
        exists on the stage.
    """
    layer_metadata = stage.GetRootLayer().customLayerData
    simready_metadata = layer_metadata.get("SimReady_Metadata", {})
    return simready_metadata.get("validation", {})


def _set_simready_validation_metadata(stage: Usd.Stage, metadata: dict) -> None:
    layer_metadata = stage.GetRootLayer().customLayerData
    simready_metadata = layer_metadata.get("SimReady_Metadata", {})
    simready_metadata["validation"] = metadata
    layer_metadata["SimReady_Metadata"] = simready_metadata
    stage.GetRootLayer().customLayerData = layer_metadata


def _add_validator_results_to_asset_metadata(
    stage: Usd.Stage, profile_id: str, features_summary: dict[str, dict]
) -> None:
    validation_metadata = get_simready_validation_metadata(stage)
    validation_metadata["profile"] = profile_id
    validated_features = validation_metadata.get("validated_features", {})

    date_string = datetime.datetime.now().strftime("%Y-%m-%d")
    validated_features[date_string] = features_summary
    validation_metadata["validated_features"] = validated_features

    _set_simready_validation_metadata(stage, validation_metadata)


def _json_summary(results: list[AssetValidationResult], output_path: str) -> None:
    summary = {}
    for result in results:
        if not result:
            continue

        summary[result.asset_path] = {
            "profile_id": result.profile_id,
            "profile_version": result.profile_version,
            "features_summary": result.features_summary,
        }

    abs_output_path = os.path.abspath(output_path)

    os.makedirs(os.path.dirname(abs_output_path), exist_ok=True)

    existing_summary = {}

    if os.path.exists(abs_output_path):
        try:
            with open(abs_output_path, "r") as f:
                existing_summary = json.load(f)
        except Exception:
            existing_summary = {}

    # Merge existing summary with new results (new results override existing for same asset)
    existing_summary.update(summary)

    with open(abs_output_path, "w") as f:
        json.dump(existing_summary, f, sort_keys=True, indent=4)


def initialize(
    rules_and_requirements_paths: list,
    features_paths: list,
    profiles_paths: list,
) -> None:
    """Load SimReady profiles and validation rules from local paths.

    Must be called once before :func:`validate_asset` or
    :func:`validate_asset_list` when running outside a Kit environment.
    Calling ``initialize`` again replaces the previously loaded data.

    Args:
        rules_and_requirements_paths: Paths to directories containing
            capability and requirement definitions (YAML/JSON).
        features_paths: Paths to directories containing feature definitions.
        profiles_paths: Paths to profile TOML files
            (e.g. ``Path("specs/profiles/profiles.toml")``).

    Note:
        When running inside a Kit environment, profiles are registered
        automatically and this function can be omitted.
    """
    destroy()

    load_validation_implementation(
        rules_and_requirements_paths=rules_and_requirements_paths,
        features_paths=features_paths,
        profiles_paths=profiles_paths,
    )


def validate_asset(validation_config: AssetValidationConfig) -> AssetValidationResult | None:
    """Validate a single USD asset against a SimReady profile.

    Args:
        validation_config: Validation request. See :class:`AssetValidationConfig`
            for field details.

    Returns:
        An :class:`AssetValidationResult` on success, or ``None`` when:

        - The file does not exist.
        - The file extension is not ``.usd`` or ``.usda``.
        - No ``profile_id`` was provided and none is stamped in the asset's
          USD metadata.
        - An unexpected exception occurs while opening or validating the stage.

    Note:
        When ``validation_config.write_metadata`` is ``True``, the validation
        outcome is written into the asset's ``customLayerData`` and the file
        is saved in place.
    """
    asset_path_p: Path = Path(validation_config.asset_path)

    if not asset_path_p.is_file() or not asset_path_p.exists():
        return

    suffix = asset_path_p.suffix.lower()
    if suffix not in [".usd", ".usda"]:
        return None

    try:
        stage = Usd.Stage.Open(asset_path_p.as_posix())

        profile_id = validation_config.profile_id
        profile_version = validation_config.profile_version

        if not profile_id:
            validation_metadata = get_simready_validation_metadata(stage)
            profile_id = validation_metadata.get("profile", None)
            profile_version = validation_metadata.get("profile_version", None)

        if not profile_id:
            return None

        issues = _validate_asset_with_profile(stage, profile_id, profile_version)

        features_summary = _build_features_validation_summary(
            issues, profile_id, profile_version, include_failed_requirements=True
        )

        # Only save validation metadata is requested.
        if validation_config.write_metadata:
            _add_validator_results_to_asset_metadata(stage, profile_id, features_summary)

            stage.Save()

        return AssetValidationResult(
            validation_config.asset_path, profile_id, profile_version, features_summary, issues
        )
    except Exception:
        return None


def validate_asset_list(
    validation_configs: list[AssetValidationConfig],
    report_file_path: str | None = None,
) -> list[AssetValidationResult | None]:
    """Validate a list of USD assets and optionally write a JSON report.

    Args:
        validation_configs: Ordered list of validation requests. Each entry
            is processed independently by :func:`validate_asset`.
        report_file_path: If provided, results are merged into a JSON file at
            this path. The file is created when it does not exist; existing
            entries for the same ``asset_path`` are overwritten while all
            other entries are preserved. The parent directory must already
            exist.

    Returns:
        A list of results in the same order as *validation_configs*. Entries
        are ``None`` for assets that could not be validated (missing file,
        wrong extension, or no resolvable profile — same conditions as
        :func:`validate_asset`).
    """
    if not validation_configs:
        return []

    validation_results = [validate_asset(validation_config) for validation_config in validation_configs]

    if report_file_path:
        _json_summary(validation_results, report_file_path)

    return validation_results


def destroy() -> None:
    """Unload all registered profiles and validation rules.

    Resets the validation engine to its empty state. Useful for test
    isolation between test cases that each call :func:`initialize` with
    different spec data.
    """
    load_validation_implementation(
        rules_and_requirements_paths=[],
        features_paths=[],
        profiles_paths=[],
    )
