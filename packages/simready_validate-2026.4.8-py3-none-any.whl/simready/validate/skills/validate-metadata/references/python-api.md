# validate-metadata — Python API Reference

## AssetValidationConfig — stamping field

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `write_metadata` | `bool` | `False` | Stamp results into USD `customLayerData` on full pass (zero issues) |

All other `AssetValidationConfig` fields (`asset_path`, `profile_id`, `profile_version`) apply
normally — see the `validate-asset` skill for the full field table.

## Stamping behavior

When `write_metadata=True`, `validate_asset()` calls `stage.Save()` after writing the
validation outcome into `customLayerData`. This only fires when the result has **zero** issues.

The metadata is written under `customLayerData["SimReady_Metadata"]["validation"]`, keyed
by today's ISO date under `validated_features`:

```python
{
    "profile": "Prop-Robotics-Neutral",
    "profile_version": "2.0.0",
    "validated_features": {
        "2026-05-01": {
            "FET001_BASE_NEUTRAL": { "version": "1.0.0", "passed": True },
            "FET003_BASE_PHYSX":   { "version": "0.1.0", "passed": False,
                                     "failing requirements": "['REQ_COLLIDER_001']" },
        }
    }
}
```

## CLI equivalent

`--stamp-asset-validation` maps directly to `write_metadata=True`.

## Ownership rules

`simready.validate` owns only the `validation` sub-key of `SimReady_Metadata`:

```
customLayerData["SimReady_Metadata"]
├── asset_id          ← owned by simready.create
├── asset_class       ← owned by simready.create
├── validation        ← owned by simready.validate  ✓
└── runtime_tests     ← owned by simready.test
```
