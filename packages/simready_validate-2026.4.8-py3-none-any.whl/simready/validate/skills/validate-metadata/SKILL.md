---
name: validate-metadata
description: Stamp SimReady validation results into a USD asset's customLayerData after a successful validation run. Use when writing validation outcomes into a USD file's SimReady_Metadata.
license: LicenseRef-NvidiaProprietary
compatibility: Requires simready-validate (pip install simready-validate). Asset must be a .usd or .usda file.
metadata:
  author: NVIDIA
  library: simready.validate
  version: "2026.04"
---

## Stamp validation results into a USD (Python)

Pass `write_metadata=True` to `AssetValidationConfig`. Results are written only on a
**full pass** (zero validation issues). The file is saved in place.

```python
import simready.validate as sv

result = sv.validate_asset(sv.AssetValidationConfig(
    asset_path="/assets/crate_01.usd",
    profile_id="Prop-Robotics-Neutral",
    profile_version="2.0.0",
    write_metadata=True,
))

if result and all(f["passed"] for f in result.features_summary.values()):
    print("Validation metadata stamped into USD.")
else:
    print("Not stamped — asset did not fully pass.")
```

## Stamp validation results into a USD (CLI)

Use `--stamp-asset-validation`. Only writes on a full pass (zero issues).

```bash
simready-validate \
  --rules-path /specs/capabilities \
  --features-path /specs/features \
  --profiles-path /specs/profiles/profiles.toml \
  --profile Prop-Robotics-Neutral --version 2.0.0 \
  --stamp-asset-validation \
  /assets/crate_01.usd
```

Combine with `--asset_list` to stamp a batch:

```bash
simready-validate \
  --rules-path /specs/capabilities \
  --features-path /specs/features \
  --profiles-path /specs/profiles/profiles.toml \
  --profile Prop-Robotics-Neutral \
  --stamp-asset-validation \
  --asset_list assets.txt
```

## Metadata structure written into the USD

```
customLayerData["SimReady_Metadata"]["validation"] = {
    "profile": "Prop-Robotics-Neutral",
    "profile_version": "2.0.0",
    "validated_features": {
        "2026-05-01": {
            "FET001_BASE_NEUTRAL": { "version": "1.0.0", "passed": true },
            ...
        }
    }
}
```

Multiple runs accumulate entries under different date keys in `validated_features`.

## Key rules

- Stamping only fires when there are **zero** validation issues — partial passes do not write.
- If the asset fails any feature, the USD file is not modified.
- `simready.validate` owns the `validation` section only — it never writes
  `runtime_tests` or base fields (`asset_id`, `asset_class`, etc.).

For full API reference see [references/python-api.md](references/python-api.md).
