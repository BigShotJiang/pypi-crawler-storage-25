# validate-batch — Python API Reference

## validate_asset_list

```python
sv.validate_asset_list(
    configs: list[AssetValidationConfig],
    report_file_path: str | None = None,
) -> list[AssetValidationResult | None]
```

- Returns one entry per config, in the same order.
- Entry is `None` if the asset was not found, had the wrong extension, or had no profile.
- `report_file_path`: if set, results are merged into a JSON file at that path.
  The file is created if it does not exist. The parent directory must already exist.
  New results for the same `asset_path` override existing entries.

## AssetValidationConfig fields (relevant for batch)

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `asset_path` | `str` | required | Path to a `.usd` or `.usda` file |
| `profile_id` | `str \| None` | `None` | Profile ID. `None` → infer from USD metadata |
| `profile_version` | `str \| None` | `None` | Version. `None` → any registered version |
| `write_metadata` | `bool` | `False` | Stamp results into USD on full pass |

## Checking results

```python
for config, result in zip(configs, results):
    if result is None:
        print(f"SKIP  {config.asset_path}")
    elif all(f["passed"] for f in result.features_summary.values()):
        print(f"PASS  {config.asset_path}")
    else:
        failed = [fid for fid, d in result.features_summary.items() if not d["passed"]]
        print(f"FAIL  {config.asset_path} — {failed}")
```
