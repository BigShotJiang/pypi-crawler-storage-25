---
name: validate-batch
description: Validate multiple USD assets in bulk against a SimReady profile and optionally save a merged JSON report. Use when validating many assets at once, processing an asset list file, or generating a validation report.
license: LicenseRef-NvidiaProprietary
compatibility: Requires simready-validate (pip install simready-validate). Assets must be .usd or .usda files.
metadata:
  author: NVIDIA
  library: simready.validate
  version: "2026.04"
---

## Batch validate from a Python list

```python
from pathlib import Path
import simready.validate as sv

# initialize once (omit inside Kit)
specs = Path("/path/to/specs")
sv.initialize(
    rules_and_requirements_paths=[specs / "capabilities"],
    features_paths=[specs / "features"],
    profiles_paths=[specs / "profiles/profiles.toml"],
)

configs = [
    sv.AssetValidationConfig(
        asset_path=str(p),
        profile_id="Prop-Robotics-Neutral",
        profile_version="2.0.0",
    )
    for p in Path("/assets/props").rglob("*.usd")
]

results = sv.validate_asset_list(configs, report_file_path="/reports/neutral.json")

n_passed = sum(
    1 for r in results
    if r and all(f["passed"] for f in r.features_summary.values())
)
print(f"{n_passed}/{len(configs)} passed")

sv.destroy()
```

## Validate against multiple profiles per asset

```python
configs = [
    sv.AssetValidationConfig(asset_path=path, profile_id=pid, profile_version=ver)
    for path in asset_paths
    for pid, ver in [("Prop-Robotics-Neutral", "2.0.0"), ("Prop-Robotics-Physx", "2.0.0")]
]
results = sv.validate_asset_list(configs)
```

## CLI — asset list file with JSON report

```bash
simready-validate \
  --rules-path /specs/capabilities \
  --features-path /specs/features \
  --profiles-path /specs/profiles/profiles.toml \
  --profile Prop-Robotics-Neutral \
  --output /reports/neutral.json \
  --asset_list assets.txt
```

`assets.txt` format — one USD path per line, blank lines ignored:
```
/assets/props/crate_01/crate_01.usd
/assets/props/pallet_01/pallet_01.usd
```

## JSON report format

Results are **merged** into the output file — new results for the same asset path override
existing entries; other entries are preserved. Parent directory must exist.

```json
{
    "/assets/crate_01.usd": {
        "profile_id": "Prop-Robotics-Neutral",
        "profile_version": "2.0.0",
        "features_summary": {
            "FET001_BASE_NEUTRAL": { "version": "1.0.0", "passed": true },
            "FET003_BASE_PHYSX":   { "version": "0.1.0", "passed": false,
                                     "failing requirements": "['REQ_COLLIDER_001']" }
        }
    }
}
```

## Key rules

- `validate_asset_list` returns `None` entries (not raises) for missing files or missing profiles.
- Each `None` in the result list corresponds to the config at the same index.
- Exit code `1` if any asset in the list failed (CLI).

For full API reference see [references/python-api.md](references/python-api.md).
