# validate-asset — Python API Reference

## AssetValidationConfig

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `asset_path` | `str` | required | Absolute path to a `.usd` or `.usda` file |
| `profile_id` | `str \| None` | `None` | Profile to validate against. `None` → infer from USD metadata |
| `profile_version` | `str \| None` | `None` | Profile version. `None` → accept any registered version |
| `write_metadata` | `bool` | `False` | Stamp results into USD `customLayerData` on full pass (zero issues) |

## AssetValidationResult

| Field | Type | Description |
|-------|------|-------------|
| `asset_path` | `str` | Path of the validated asset |
| `profile_id` | `str` | Profile that was used |
| `profile_version` | `str` | Version of the profile |
| `features_summary` | `dict[str, dict]` | Per-feature pass/fail detail |
| `issues` | `list[Issue]` | Raw failing issues from the validation engine |

## features_summary structure

```python
{
    "FET001_BASE_NEUTRAL": {
        "version": "1.0.0",
        "dependencies": "[]",
        "passed": True,
    },
    "FET003_BASE_PHYSX": {
        "version": "0.1.0",
        "dependencies": "['FET001_BASE_NEUTRAL']",
        "passed": False,
        "failing requirements": "['REQ_COLLIDER_001', 'REQ_PHYSX_002']",
    }
}
```

## Functions

```python
sv.initialize(
    rules_and_requirements_paths: list[Path],
    features_paths: list[Path],
    profiles_paths: list[Path],
) -> None

sv.destroy() -> None

sv.validate_asset(config: AssetValidationConfig) -> AssetValidationResult | None
# Returns None if: file not found, wrong extension, or no profile in metadata and none given.

sv.validate_asset_list(
    configs: list[AssetValidationConfig],
    report_file_path: str | None = None,
) -> list[AssetValidationResult | None]
```

## Quick pass/fail helper

```python
def all_passed(result: sv.AssetValidationResult) -> bool:
    return bool(result.features_summary) and all(
        v["passed"] for v in result.features_summary.values()
    )
```
