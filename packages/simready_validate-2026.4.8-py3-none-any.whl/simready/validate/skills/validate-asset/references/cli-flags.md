# validate-asset — CLI Flags Reference

## Synopsis

```
simready-validate [--rules-path P] [--features-path P] [--profiles-path P]
                  [--profile ID] [--version VER]
                  [--stamp-asset-validation] [--output JSON] [-v]
                  ASSET_PATH | --asset_list FILE
```

## Flags

| Flag | Description |
|------|-------------|
| `ASSET_PATH` | Positional. Path to a single `.usd` or `.usda` file. Mutually exclusive with `--asset_list`. |
| `--asset_list FILE` | Text file with one asset path per line. Blank lines ignored. |
| `--profile ID` | Validate against this profile ID. Omit to infer from USD metadata. |
| `--version VER` | Profile version. Requires `--profile`. |
| `--rules-path PATH` | Rules/requirements directory. Repeatable. |
| `--features-path PATH` | Features directory. Repeatable. |
| `--profiles-path PATH` | Profiles TOML file. Repeatable. |
| `--stamp-asset-validation` | Write results into USD `customLayerData` on full pass. Python: `write_metadata=True`. |
| `--output JSON_FILE` | Append results to a JSON file. Merged — existing entries preserved. |
| `-v`, `--verbose` | Print per-issue detail (rule, severity, message, prim) on failure + DEBUG logging. |

## CLI flag → Python API mapping

| CLI flag | Python equivalent |
|----------|------------------|
| `--profile ID` | `AssetValidationConfig(profile_id=ID)` |
| `--version VER` | `AssetValidationConfig(profile_version=VER)` |
| `--stamp-asset-validation` | `AssetValidationConfig(write_metadata=True)` |
| `--output JSON` | `validate_asset_list(configs, report_file_path=JSON)` |
| `--rules-path` / `--features-path` / `--profiles-path` | `initialize(rules_and_requirements_paths, features_paths, profiles_paths)` |

## Exit codes

| Code | Meaning |
|------|---------|
| `0` | All assets passed |
| `1` | Any asset failed, was not found, or had no profile in metadata |
