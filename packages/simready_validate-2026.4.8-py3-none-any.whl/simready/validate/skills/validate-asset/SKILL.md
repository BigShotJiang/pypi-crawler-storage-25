---
name: validate-asset
description: Validate a single USD asset against a named SimReady profile and inspect per-feature pass/fail results. Use when checking whether a USD file conforms to a SimReady profile such as Prop-Robotics-Neutral or Prop-Robotics-Physx.
license: LicenseRef-NvidiaProprietary
compatibility: Requires simready-validate (pip install simready-validate). Asset must be a .usd or .usda file.
metadata:
  author: NVIDIA
  library: simready.validate
  version: "2026.04"
---

## Initialize the engine

Call `initialize()` once before any validation when running outside a Kit environment.
Omit it when running inside Kit (profiles are already registered).

```python
import simready.validate as sv
from pathlib import Path

specs = Path("/path/to/specs")
sv.initialize(
    rules_and_requirements_paths=[specs / "capabilities"],
    features_paths=[specs / "features"],
    profiles_paths=[specs / "profiles/profiles.toml"],
)
# ... validate ...
sv.destroy()
```

## Validate against an explicit profile

```python
result = sv.validate_asset(sv.AssetValidationConfig(
    asset_path="/assets/crate_01.usd",
    profile_id="Prop-Robotics-Neutral",
    profile_version="2.0.0",  # optional — omit to accept any registered version
))

if result is None:
    # file missing, wrong extension, or no profile in metadata and none given
    ...
else:
    passed = all(f["passed"] for f in result.features_summary.values())
    for feat_id, data in result.features_summary.items():
        if not data["passed"]:
            print(f"{feat_id}: failing {data.get('failing requirements')}")
```

## Validate using profile stored in the USD (inference mode)

Omit `profile_id` to read it from `SimReady_Metadata.validation` in the USD file.
Returns `None` if no profile is found in the asset.

```python
result = sv.validate_asset(sv.AssetValidationConfig(
    asset_path="/assets/crate_01.usd",
))
```

## CLI equivalent

```bash
simready-validate \
  --rules-path /specs/capabilities \
  --features-path /specs/features \
  --profiles-path /specs/profiles/profiles.toml \
  /assets/crate_01.usd
```

Exit code: `0` = passed, `1` = failed or asset not found.

## Available profiles

| Profile ID | Asset type | Stage |
|------------|------------|-------|
| `Prop-Robotics-Neutral` | Prop | Pre-derive (neutral) |
| `Prop-Robotics-Physx` | Prop | Derived — PhysX |
| `Prop-Robotics-Isaac` | Prop | Derived — Isaac Sim |
| `Robot-Body-Neutral` | Robot | Pre-derive (neutral) |
| `Robot-Body-Runnable` | Robot | Derived — PhysX joints |
| `Robot-Body-Isaac` | Robot | Derived — Isaac Sim |

## Key rules

- `validate_asset` returns `None` — never raises — on missing file or missing profile.
- `features_summary` is `{}` if `initialize()` was not called before validating.
- `validate_asset` only accepts `.usd` and `.usda` extensions.

For full parameter details see [references/python-api.md](references/python-api.md).
For all CLI flags see [references/cli-flags.md](references/cli-flags.md).
