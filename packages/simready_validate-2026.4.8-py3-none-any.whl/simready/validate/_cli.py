# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""CLI entry point for simready-validate.

Usage examples:
  # Validate against a specific profile and version
  simready-validate --profile Prop-Robotics-Physx --version 1.0.0 /path/to/asset.usd

  # Validate against all installed profiles and report which ones match
  simready-validate /path/to/asset.usd

  # Validate a list of assets (compatible with all other options)
  simready-validate --asset_list my_assets.txt
  simready-validate --asset_list my_assets.txt --profile Prop-Robotics-Physx --version 1.0.0

  # Load profiles from local paths before validating
  simready-validate --rules-path /path/to/rules --features-path /path/to/features \\
                    --profiles-path /path/to/profiles.toml /path/to/asset.usd
"""

import argparse
import logging
import sys
from pathlib import Path

logger = logging.getLogger(__name__)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="simready-validate",
        description="Validate USD assets against SimReady profiles.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )

    # Asset source: positional path OR --asset_list (not both)
    parser.add_argument(
        "asset_path",
        nargs="?",
        metavar="ASSET_PATH",
        help="Path to a single USD asset to validate.",
    )
    parser.add_argument(
        "--asset_list",
        metavar="FILE",
        help="Text file with one asset path per line. Compatible with all other options.",
    )

    # Profile selection
    parser.add_argument(
        "--profile",
        metavar="PROFILE_ID",
        help=(
            "Validate against this profile ID only. "
            "When omitted, the profile is tentatively inferred from the SimreadyAsset"
            " usd or the validation fails."
        ),
    )
    parser.add_argument(
        "--version",
        metavar="VERSION",
        help="Profile version to use.",
    )

    # Validation data paths — optional, repeatable
    parser.add_argument(
        "--rules-path",
        action="append",
        metavar="PATH",
        dest="rules_paths",
        help="Path to a rules/requirements directory or file. May be repeated.",
    )
    parser.add_argument(
        "--features-path",
        action="append",
        metavar="PATH",
        dest="features_paths",
        help="Path to a features directory or file. May be repeated.",
    )
    parser.add_argument(
        "--profiles-path",
        action="append",
        metavar="PATH",
        dest="profiles_paths",
        help="Path to a profiles TOML/JSON file. May be repeated.",
    )

    # Stamping
    parser.add_argument(
        "--stamp-asset-validation",
        action="store_true",
        help="Stamp validation results in the asset usd meta data.",
    )

    # Output
    parser.add_argument(
        "--output",
        metavar="JSON_FILE",
        help="Append JSON results to this file (created if it does not exist).",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Show per-feature validation details and debug logging.",
    )

    return parser


def _collect_assets(args: argparse.Namespace) -> list[str]:
    """Return asset paths from positional arg or --asset_list file."""
    if args.asset_list:
        list_file = Path(args.asset_list)

        if not list_file.is_file():
            print(f"Error: asset list file not found: {args.asset_list}", file=sys.stderr)
            sys.exit(1)

        return [line.strip() for line in list_file.read_text().splitlines() if line.strip()]

    return [args.asset_path]


def _passed(result) -> bool:
    """True iff every feature in the result's summary passed."""
    return bool(result.features_summary) and all(v.get("passed") for v in result.features_summary.values())


def _print_result(result, print_detailed_issues: bool = False) -> None:
    """Print a single profile result with feature-level detail on failure."""
    status = "PASSED" if _passed(result) else "FAILED"
    version_str = f" v{result.profile_version}" if result.profile_version else ""

    print(f"  [{status}] {result.profile_id}{version_str}")

    if not _passed(result):

        for feat_id, feat_data in result.features_summary.items():
            if not feat_data.get("passed"):
                failing = feat_data.get("failing requirements", "")
                print(f"           {feat_id}: failing requirements: {failing}")

        if print_detailed_issues and result.issues:
            print("\nValidation issues summary:\n")
            # Pretty print the failure details.
            for index, issue in enumerate(result.issues):
                print(f" - Issue {index}")
                print(f"      Rule: {issue.rule}")
                print(f"      Severity: {issue.severity}")
                print(f"      Message: {issue.message}")
                print(f"      At: {issue.at}")


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    # --- Argument validation ---
    if args.asset_path and args.asset_list:
        parser.error("Provide ASSET_PATH or --asset_list, not both.")
    if not args.asset_path and not args.asset_list:
        parser.error("Provide either ASSET_PATH or --asset_list.")
    if args.version and not args.profile:
        parser.error("--version requires --profile.")

    # --- Logging ---
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.WARNING,
        format="%(levelname)s: %(message)s",
    )

    # --- Deferred imports (keeps --help fast, avoids USD/omni startup cost) ---
    from simready.validate import (
        AssetValidationConfig,
        initialize,
        validate_asset_list,
    )

    # --- Optionally initialise the validation engine from provided paths ---
    if args.rules_paths or args.features_paths or args.profiles_paths:
        initialize(
            rules_and_requirements_paths=[Path(p) for p in (args.rules_paths or [])],
            features_paths=[Path(p) for p in (args.features_paths or [])],
            profiles_paths=[Path(p) for p in (args.profiles_paths or [])],
        )

    # --- Collect and filter assets ---
    asset_paths = _collect_assets(args)

    valid_paths: list[str] = []
    for p in asset_paths:
        if Path(p).exists():
            valid_paths.append(p)
        else:
            print(f"Warning: asset not found, skipping: {p}", file=sys.stderr)

    if not valid_paths:
        print("No valid assets to validate.", file=sys.stderr)
        sys.exit(1)

    overall_passed = True

    # -------------------------------------------------------------------------
    # Single-profile mode
    # -------------------------------------------------------------------------
    configs = [
        AssetValidationConfig(
            asset_path=p,
            profile_id=args.profile,
            profile_version=args.version,
            write_metadata=args.stamp_asset_validation,
        )
        for p in valid_paths
    ]

    results = validate_asset_list(configs, report_file_path=args.output)

    for asset_config, result in zip(configs, results):
        print(f"\nAsset: {asset_config.asset_path}")

        if result is None:
            if not args.profile:
                print("  [ERROR] Not a SimReady asset: no profile_id found in asset metadata.")
            overall_passed = False
            continue

        _print_result(result, args.verbose)

        if not _passed(result):
            overall_passed = False

    if args.output:
        print(f"\nResults written to: {args.output}")

    sys.exit(0 if overall_passed else 1)
