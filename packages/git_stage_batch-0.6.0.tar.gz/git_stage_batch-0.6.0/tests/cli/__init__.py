"""Tests for CLI modules."""
