"""Discard from batch command implementation."""

from __future__ import annotations

import sys
from typing import Optional

from ..batch.merge import discard_batch
from ..batch.metadata_validation import get_validated_baseline_commit, read_validated_batch_metadata
from ..batch.selection import (
    resolve_batch_file_scope,
    require_single_file_context_for_line_selection,
    select_batch_ownership_for_display_ids,
)
from ..batch.validation import batch_exists
from ..data.hunk_tracking import render_batch_file_display
from ..data.session import snapshot_file_if_untracked
from ..data.undo import undo_checkpoint
from ..exceptions import exit_with_error, MergeError, BatchMetadataError
from ..i18n import _
from ..utils.git import get_git_repository_root_path, require_git_repository, run_git_command


def _discard_binary_file_from_batch(file_path: str, baseline_commit: str) -> None:
    """Discard binary file by restoring it to baseline state.

    Binary files are atomic units. Discarding means restoring the entire file
    to its state at the batch baseline commit.

    Args:
        file_path: Path to binary file
        baseline_commit: Baseline commit SHA to restore from

    Raises:
        RuntimeError: If file operations fail
    """
    repo_root = get_git_repository_root_path()
    full_path = repo_root / file_path

    # Read file from baseline commit
    result = run_git_command(
        ["show", f"{baseline_commit}:{file_path}"],
        check=False,
        text_output=False
    )

    if result.returncode == 0:
        # File exists in baseline - restore it
        baseline_content = result.stdout
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_bytes(baseline_content)
        print(_("✓ Restored binary file to baseline: {file}").format(file=file_path), file=sys.stderr)
    else:
        # File doesn't exist in baseline - delete from working tree
        if full_path.exists():
            full_path.unlink()
            print(_("✓ Removed binary file (not in baseline): {file}").format(file=file_path), file=sys.stderr)
        else:
            # File already doesn't exist - no-op
            pass


def command_discard_from_batch(batch_name: str, line_ids: Optional[str] = None, file: Optional[str] = None) -> None:
    """Remove batch changes from working tree using structural merge.

    Args:
        batch_name: Name of batch to discard from
        line_ids: Optional line IDs to discard (requires single-file context)
        file: Optional file path to select from batch.
              If None, discards all files in batch.
    """
    require_git_repository()

    # Check batch exists
    if not batch_exists(batch_name):
        exit_with_error(_("Batch '{name}' does not exist").format(name=batch_name))

    # Read and validate batch metadata
    try:
        metadata = read_validated_batch_metadata(batch_name)
    except BatchMetadataError as e:
        exit_with_error(str(e))

    all_files = metadata.get("files", {})

    if not all_files:
        exit_with_error(_("Batch '{name}' is empty").format(name=batch_name))

    # Determine which files to operate on
    files = resolve_batch_file_scope(batch_name, all_files, file)

    # Parse line selection and enforce single-file context
    selected_ids = require_single_file_context_for_line_selection(
        batch_name, files, line_ids, "discard"
    )

    # Reject line selection for binary files (binary files are atomic units)
    if selected_ids:
        file_path_for_check = list(files.keys())[0]  # Single file context enforced above
        if files[file_path_for_check].get("file_type") == "binary":
            exit_with_error(_("Cannot use --lines with binary files. Binary files must be discarded as complete units."))

    # Translate gutter IDs to selection IDs if line selection is active
    selection_ids_to_discard = selected_ids
    if selected_ids:
        # Use pure render helper to get gutter ID mapping (no side effects)
        file_path_for_render = list(files.keys())[0]  # Single file context enforced above
        rendered = render_batch_file_display(batch_name, file_path_for_render)
        if rendered:
            # Translate gutter IDs (what user sees) to selection IDs (internal)
            selection_ids_to_discard = set()
            for gutter_id in selected_ids:
                if gutter_id in rendered.gutter_to_selection_id:
                    selection_ids_to_discard.add(rendered.gutter_to_selection_id[gutter_id])
                else:
                    exit_with_error(_("Line ID {id} not found or not individually mergeable").format(id=gutter_id))

    # Get baseline commit (raises BatchMetadataError with clear message if missing)
    try:
        baseline_commit = get_validated_baseline_commit(batch_name)
    except BatchMetadataError as e:
        exit_with_error(str(e))
    operation_parts = ["discard", "--from", batch_name]
    if line_ids is not None:
        operation_parts.extend(["--line", line_ids])
    if file is not None:
        operation_parts.extend(["--file", file])
    with undo_checkpoint(" ".join(operation_parts)):
        # Discard all files in batch
        repo_root = get_git_repository_root_path()
        failed_files = []

        for file_path, file_meta in files.items():
            try:
                # Snapshot file before modifying
                snapshot_file_if_untracked(file_path)

                # Binary files are atomic units - handle separately without ownership/merge logic
                if file_meta.get("file_type") == "binary":
                    _discard_binary_file_from_batch(file_path, baseline_commit)
                    continue

                # Get batch source commit content (as bytes)
                batch_source_commit = file_meta["batch_source_commit"]
                batch_source_result = run_git_command(
                    ["show", f"{batch_source_commit}:{file_path}"],
                    check=False,
                    text_output=False
                )
                if batch_source_result.returncode != 0:
                    failed_files.append(file_path)
                    continue
                batch_source_content = batch_source_result.stdout

                # Get baseline content (as bytes)
                baseline_result = run_git_command(
                    ["show", f"{baseline_commit}:{file_path}"],
                    check=False,
                    text_output=False
                )
                baseline_content = baseline_result.stdout if baseline_result.returncode == 0 else b""

                # Get selected working tree content (as bytes)
                full_path = repo_root / file_path
                if full_path.exists():
                    working_content = full_path.read_bytes()
                else:
                    working_content = b""

                # Get ownership from metadata, filtered by selected selection IDs if specified
                ownership = select_batch_ownership_for_display_ids(
                    file_meta, batch_source_content, selection_ids_to_discard
                )

                # If nothing selected for this file, skip it
                if ownership.is_empty():
                    continue

                # Perform structural discard (inverse of merge)
                discarded_content = discard_batch(
                    batch_source_content,
                    ownership,
                    working_content,
                    baseline_content
                )

                # Write to working tree (bytes)
                full_path.parent.mkdir(parents=True, exist_ok=True)
                full_path.write_bytes(discarded_content)

            except MergeError as e:
                print(_("Error discarding {file}: {error}").format(file=file_path, error=str(e)), file=sys.stderr)
                failed_files.append(file_path)
            except Exception as e:
                print(_("Error discarding {file}: {error}").format(file=file_path, error=str(e)), file=sys.stderr)
                failed_files.append(file_path)

    if failed_files:
        exit_with_error(
            _("Failed to discard changes for some files: {files}").format(files=", ".join(failed_files))
        )

    # Success message
    if line_ids:
        print(_("✓ Discarded selected lines from batch '{name}'").format(name=batch_name), file=sys.stderr)
    elif file is not None:
        print(_("✓ Discarded changes for {file} from batch '{name}'").format(file=list(files.keys())[0], name=batch_name), file=sys.stderr)
    else:
        print(_("✓ Discarded changes from batch '{name}'").format(name=batch_name), file=sys.stderr)

    print(_("Note: Batch '{name}' still exists (use 'drop' to delete it)").format(name=batch_name), file=sys.stderr)
