"""Line-level staging operations."""
