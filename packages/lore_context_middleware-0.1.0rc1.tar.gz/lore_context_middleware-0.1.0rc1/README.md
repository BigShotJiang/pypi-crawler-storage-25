# lore-context-middleware

Python SDK middleware for Lore Context — wraps `openai.OpenAI` / `anthropic.Anthropic` clients to auto-inject memory pre-LLM-call and auto-retain post-LLM-call without requiring the AI to call an MCP tool.

## Install

```bash
pip install lore-context-middleware lore-context openai
```

## Quick start

```python
import os
from openai import OpenAI
from lore_context import LoreContextApiClient
from lore_context_middleware import with_memory_hooks

lore = LoreContextApiClient(token=os.environ["LORE_API_KEY"])
openai_client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

client = with_memory_hooks(openai_client, lore, mode="hybrid")

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "What was that Postgres dump command?"}],
)
```

## Modes

| Mode | inject | retain | tools exposed |
|---|---|---|---|
| `hybrid` (default) | ✅ | ✅ | ✅ |
| `context` | ✅ | ✅ | ❌ |
| `tools` | ❌ | ❌ | ✅ |

See `docs/sdk/middleware-modes.md` in the lore-cloud repo for full mode semantics.

## License

MIT
