#  Copyright 2026 Zeppelin Bend Pty Ltd
#
#  This Source Code Form is subject to the terms of the Mozilla Public
#  License, v. 2.0. If a copy of the MPL was not distributed with this
#  file, You can obtain one at https://mozilla.org/MPL/2.0/.


from typing import Any, Optional, Union
import httpx

class GraphQLClientError(Exception):
    """Base exception."""

class GraphQLClientHttpError(GraphQLClientError):

    def __init__(self, status_code: int, response: httpx.Response) -> None:
        self.status_code = status_code
        self.response = response

    def __str__(self) -> str:
        return f'HTTP status code: {self.status_code}'

class GraphQLClientInvalidResponseError(GraphQLClientError):

    def __init__(self, response: httpx.Response) -> None:
        self.response = response

    def __str__(self) -> str:
        return 'Invalid response format.'

class GraphQLClientGraphQLError(GraphQLClientError):

    def __init__(self, message: str, locations: Optional[list[dict[str, int]]]=None, path: Optional[list[str]]=None, extensions: Optional[dict[str, object]]=None, original: Optional[dict[str, object]]=None):
        self.message = message
        self.locations = locations
        self.path = path
        self.extensions = extensions
        self.original = original

    def __str__(self) -> str:
        return self.message

    @classmethod
    def from_dict(cls, error: dict[str, Any]) -> 'GraphQLClientGraphQLError':
        return cls(message=error['message'], locations=error.get('locations'), path=error.get('path'), extensions=error.get('extensions'), original=error)

class GraphQLClientGraphQLMultiError(GraphQLClientError):

    def __init__(self, errors: list[GraphQLClientGraphQLError], data: Optional[dict[str, Any]]=None):
        self.errors = errors
        self.data = data

    def __str__(self) -> str:
        return '; '.join((str(e) for e in self.errors))

    @classmethod
    def from_errors_dicts(cls, errors_dicts: list[dict[str, Any]], data: Optional[dict[str, Any]]=None) -> 'GraphQLClientGraphQLMultiError':
        return cls(errors=[GraphQLClientGraphQLError.from_dict(e) for e in errors_dicts], data=data)

class GraphQLClientInvalidMessageFormat(GraphQLClientError):

    def __init__(self, message: Union[str, bytes]) -> None:
        self.message = message

    def __str__(self) -> str:
        return 'Invalid message format.'