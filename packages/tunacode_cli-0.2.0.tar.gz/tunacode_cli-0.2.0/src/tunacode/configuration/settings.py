"""
Module: tunacode.configuration.settings

Application settings management for the TunaCode CLI.
Handles configuration paths, model registries, and application metadata.
"""

from pathlib import Path

from tunacode.constants import APP_NAME, APP_VERSION, CONFIG_FILE_NAME, ToolName
from tunacode.types import ConfigFile, ConfigPath


class PathConfig:
    def __init__(self) -> None:
        self.config_dir: ConfigPath = Path.home() / ".config"
        self.config_file: ConfigFile = self.config_dir / CONFIG_FILE_NAME


class ApplicationSettings:
    def __init__(self) -> None:
        self.version = APP_VERSION
        self.name = APP_NAME
        self.paths = PathConfig()
        self.internal_tools: list[ToolName] = [
            ToolName.BASH,
            ToolName.DISCOVER,
            ToolName.READ_FILE,
            ToolName.HASHLINE_EDIT,
            ToolName.WEB_FETCH,
            ToolName.WRITE_FILE,
        ]
