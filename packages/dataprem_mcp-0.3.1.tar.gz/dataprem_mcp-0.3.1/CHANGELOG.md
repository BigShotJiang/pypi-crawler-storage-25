# Changelog

Notable changes to `dataprem-mcp`. Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) · semver.

## [0.3.1] — 2026-05-05

### Changed

- PyPI metadata: `authors`, `project.urls` (Homepage, Repository, Issues, Changelog), `keywords`, full `classifiers` (Development Status, Intended Audience, Python 3.11–3.13, Topic). Pure metadata bump; no runtime changes.

## [0.3.0] — 2026-05-04

### Added

- HTTP transport (`streamable-http`) so the chat backend (and any other server-side MCP client) can reach the server over an internal Docker network at `http://dataprem_mcp:8080/mcp`. Stdio transport via `uvx dataprem-mcp` is preserved for desktop clients (Claude Desktop, Cursor).
- Dockerfile + healthcheck endpoint for container deploys.

## [0.2.0] — 2026-05-04

### Changed

- `dataprem_catastro_lookup` no longer returns demo data: tool calls hit the real Catastro SOAP API via the DataPrem backend.

## [0.1.0] — Initial release

- Base MCP server scaffold with stub tools for Catastro, BORME, CENDOJ and Licitaciones; stdio transport.
