"""DataPrem MCP Server.

Exposes Spanish public data sources (Catastro, BORME, CENDOJ, Licitaciones)
as MCP tools for AI agents. Catastro is wired against the real DataPrem REST
API (`api.dataprem.com`); the rest are stubs scheduled by phase — see README
for the live status table.
"""

from __future__ import annotations

from typing import Any

from mcp.server.fastmcp import FastMCP

from dataprem_mcp.api_client import DatapremApiClient

mcp = FastMCP("DataPrem")


# ---------------------------------------------------------------------------
# Tool: Catastro — REAL (DataPrem API, no stub)
# ---------------------------------------------------------------------------


@mcp.tool()
def dataprem_catastro_lookup(
    refcat: str | None = None,
    address: str | None = None,
    city: str | None = None,
    province: str | None = None,
) -> dict[str, Any]:
    """Consulta datos catastrales de un inmueble en el Catastro español.

    Provee uno de los dos modos de búsqueda:

    * **Por referencia catastral** — pasar `refcat` (14, 18 o 20 caracteres).
    * **Por dirección** — pasar `address` + `city`, opcionalmente `province`.

    Devuelve la ficha catastral normalizada: clase, uso, superficies, año de
    construcción, dirección con códigos INE, y el desglose de construcciones
    (`constructions[]`) con planta, puerta y superficie por componente.

    El endpoint **no expone titular** (datos personales): el SOAP libre del
    Catastro no lo facilita y la API pública lo descarta por LOPD/GDPR.
    Consulta autorizada con certificado del titular en pipeline futuro.

    Args:
        refcat: Referencia catastral del inmueble.
        address: Dirección literal (tipo + nombre + número).
        city: Municipio.
        province: Provincia (opcional).
    """
    client = DatapremApiClient()
    return client.get_catastro_property(
        refcat=refcat, address=address, city=city, province=province
    )


# ---------------------------------------------------------------------------
# Tool: BORME — STUB (real implementation in Phase 3, TK-481)
# ---------------------------------------------------------------------------


@mcp.tool()
def dataprem_borme_search(
    company_name: str,
    date_from: str | None = None,
    date_to: str | None = None,
) -> dict[str, Any]:
    """Busca actos registrales en el BORME (Boletín Oficial del Registro Mercantil).

    Permite localizar inscripciones de constitución, nombramientos, ceses,
    ampliaciones de capital y otros actos mercantiles de una empresa.

    Args:
        company_name: Nombre o razón social de la empresa a buscar.
        date_from: Fecha de inicio de búsqueda (formato YYYY-MM-DD, opcional).
        date_to: Fecha de fin de búsqueda (formato YYYY-MM-DD, opcional).
    """
    return {
        "_status": "stub",
        "_eta_phase": "Fase 3 (TK-481)",
        "_message": "Datos de demostración. El conector real BORME llegará en Fase 3.",
        "empresa": company_name,
        "rango_fechas": {
            "desde": date_from or "2024-01-01",
            "hasta": date_to or "2026-03-13",
        },
        "resultados": [
            {
                "fecha": "2025-11-15",
                "seccion": "SECCIÓN PRIMERA",
                "provincia": "Madrid",
                "registro": "Registro Mercantil de Madrid",
                "acto": "Nombramientos",
                "detalle": (
                    f"Nombramiento de administrador único de {company_name}: "
                    "D. Carlos Ruiz Fernández."
                ),
                "borme_id": "BORME-A-2025-219",
            },
            {
                "fecha": "2025-06-02",
                "seccion": "SECCIÓN PRIMERA",
                "provincia": "Madrid",
                "registro": "Registro Mercantil de Madrid",
                "acto": "Ampliación de capital",
                "detalle": (
                    f"Ampliación de capital social de {company_name} "
                    "en 50.000 EUR mediante aportaciones dinerarias."
                ),
                "borme_id": "BORME-A-2025-105",
            },
        ],
        "total": 2,
        "fuente": "Boletín Oficial del Registro Mercantil (BORME)",
    }


# ---------------------------------------------------------------------------
# Tool: CENDOJ — STUB (real implementation in Phase 4, TK-487)
# ---------------------------------------------------------------------------


@mcp.tool()
def dataprem_cendoj_search(
    query: str,
    court: str | None = None,
    date_from: str | None = None,
) -> dict[str, Any]:
    """Busca resoluciones judiciales en el CENDOJ (Centro de Documentación Judicial).

    Permite buscar sentencias, autos y providencias de todos los órdenes
    jurisdiccionales españoles.

    Args:
        query: Términos de búsqueda (texto libre sobre la materia de la resolución).
        court: Órgano judicial (ej. "Tribunal Supremo", "Audiencia Provincial de Madrid"). Opcional.
        date_from: Fecha mínima de la resolución (formato YYYY-MM-DD, opcional).
    """
    return {
        "_status": "stub",
        "_eta_phase": "Fase 4 (TK-487)",
        "_message": "Datos de demostración. El conector real CENDOJ llegará en Fase 4 (RAG semántico).",
        "consulta": query,
        "organo_filtro": court,
        "fecha_desde": date_from,
        "resultados": [
            {
                "id_cendoj": "28079110012025100342",
                "organo": court or "Tribunal Supremo — Sala Primera",
                "fecha": "2025-09-18",
                "tipo_resolucion": "Sentencia",
                "ecli": "ECLI:ES:TS:2025:3421",
                "resumen": (
                    f"Resolución sobre {query}. Se estima parcialmente el recurso "
                    "de casación interpuesto contra la sentencia de la Audiencia "
                    "Provincial. Se fija doctrina jurisprudencial sobre la materia."
                ),
                "ponente": "Excmo. Sr. D. Antonio Martínez Pérez",
                "materias": ["Derecho Civil", "Obligaciones y contratos"],
            },
            {
                "id_cendoj": "28079140012025200187",
                "organo": "Audiencia Nacional — Sala de lo Contencioso-Administrativo",
                "fecha": "2025-07-04",
                "tipo_resolucion": "Sentencia",
                "ecli": "ECLI:ES:AN:2025:1872",
                "resumen": (
                    f"Recurso contencioso-administrativo relacionado con {query}. "
                    "Se desestima el recurso y se confirma la resolución impugnada."
                ),
                "ponente": "Ilmo. Sr. D. Elena Sánchez Moreno",
                "materias": ["Derecho Administrativo"],
            },
        ],
        "total": 2,
        "fuente": "Centro de Documentación Judicial (CENDOJ)",
    }


# ---------------------------------------------------------------------------
# Tool: Licitaciones públicas — STUB (real implementation in Phase 3, TK-482)
# ---------------------------------------------------------------------------


@mcp.tool()
def dataprem_tenders_search(
    query: str,
    location: str | None = None,
    status: str | None = None,
) -> dict[str, Any]:
    """Busca licitaciones y contratos públicos en España.

    Consulta la Plataforma de Contratación del Sector Público para encontrar
    licitaciones abiertas, adjudicadas o cerradas.

    Args:
        query: Términos de búsqueda sobre el objeto del contrato.
        location: Comunidad autónoma o provincia (opcional).
        status: Estado de la licitación: "open" (abierta), "closed" (cerrada) o "all" (todas). Por defecto "all".
    """
    effective_status = status or "all"
    return {
        "_status": "stub",
        "_eta_phase": "Fase 3 (TK-482)",
        "_message": "Datos de demostración. El conector real Contratación llegará en Fase 3.",
        "consulta": query,
        "ubicacion_filtro": location,
        "estado_filtro": effective_status,
        "resultados": [
            {
                "expediente": "CONT/2025/000847",
                "titulo": f"Servicio de {query} para la Administración General del Estado",
                "organo_contratacion": "Ministerio de Hacienda",
                "tipo_contrato": "Servicios",
                "procedimiento": "Abierto",
                "estado": "Abierta" if effective_status in ("open", "all") else "Adjudicada",
                "presupuesto_base_eur": 245_000.00,
                "fecha_publicacion": "2026-02-28",
                "fecha_limite_presentacion": "2026-04-15",
                "lugar_ejecucion": location or "Madrid",
                "url_plataforma": (
                    "https://contrataciondelestado.es/wps/poc?uri=deeplink:"
                    "detalle_licitacion&idEvl=placeholder"
                ),
            },
            {
                "expediente": "LIC/2025/003291",
                "titulo": f"Suministro y mantenimiento de {query} — Ayuntamiento de Barcelona",
                "organo_contratacion": "Ayuntamiento de Barcelona",
                "tipo_contrato": "Suministros",
                "procedimiento": "Abierto simplificado",
                "estado": "Adjudicada",
                "presupuesto_base_eur": 89_500.00,
                "fecha_publicacion": "2025-10-12",
                "fecha_adjudicacion": "2025-12-20",
                "adjudicatario": "Soluciones Técnicas del Mediterráneo S.L.",
                "lugar_ejecucion": location or "Barcelona",
                "url_plataforma": (
                    "https://contrataciondelestado.es/wps/poc?uri=deeplink:"
                    "detalle_licitacion&idEvl=placeholder2"
                ),
            },
        ],
        "total": 2,
        "fuente": "Plataforma de Contratación del Sector Público",
    }
