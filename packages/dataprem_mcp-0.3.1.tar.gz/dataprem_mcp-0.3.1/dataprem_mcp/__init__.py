"""DataPrem MCP Server — Acceso a datos públicos españoles via Model Context Protocol."""

__version__ = "0.1.0"
