"""HTTP client for the DataPrem REST API.

Thin wrapper around httpx that:
* reads `DATAPREM_API_URL` and `DATAPREM_API_KEY` from environment
* encodes the bearer token in every call
* normalises HTTP errors to a small set of dict shapes that the MCP tools
  can hand straight back to the LLM (no exceptions across the MCP boundary).
"""

from __future__ import annotations

import os
from typing import Any

import httpx

DEFAULT_BASE_URL = "https://api.dataprem.com"
DEFAULT_TIMEOUT = 20.0


class DatapremApiClient:
    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        resolved_url = base_url or os.getenv("DATAPREM_API_URL") or DEFAULT_BASE_URL
        self.base_url = resolved_url.rstrip("/")
        self.api_key = api_key or os.getenv("DATAPREM_API_KEY") or ""
        self.timeout = timeout

    def get_catastro_property(
        self,
        refcat: str | None = None,
        address: str | None = None,
        city: str | None = None,
        province: str | None = None,
    ) -> dict[str, Any]:
        """Look up a Spanish cadastral property by reference or by address.

        Returns one of:
        * `{"ok": True, "data": {...}}` on a successful match
        * `{"ok": False, "error": "...", "message": "..."}` otherwise
        """
        params: dict[str, str] = {}
        if refcat:
            params["refcat"] = refcat
        elif address and city:
            params["address"] = address
            params["city"] = city
            if province:
                params["province"] = province
        else:
            return {
                "ok": False,
                "error": "invalid_request",
                "message": (
                    "Either 'refcat' or both 'address' and 'city' are required."
                ),
            }

        return self._get_json("/v1/es/catastro/property", params=params)

    # ─── internal ───────────────────────────────────────────────────────────

    def _get_json(self, path: str, params: dict[str, str]) -> dict[str, Any]:
        if not self.api_key:
            return {
                "ok": False,
                "error": "missing_api_key",
                "message": (
                    "Set the DATAPREM_API_KEY environment variable in the MCP "
                    "client config (Authorization: Bearer dpa_...)."
                ),
            }

        url = f"{self.base_url}{path}"
        headers = {"Authorization": f"Bearer {self.api_key}"}

        try:
            response = httpx.get(
                url, params=params, headers=headers, timeout=self.timeout
            )
        except httpx.RequestError as exc:
            return {
                "ok": False,
                "error": "upstream_unreachable",
                "message": f"Could not reach DataPrem API at {self.base_url}: {exc}",
            }

        return self._handle_response(response)

    @staticmethod
    def _handle_response(response: httpx.Response) -> dict[str, Any]:
        status = response.status_code

        if status == 200:
            try:
                payload = response.json()
            except ValueError:
                return {
                    "ok": False,
                    "error": "bad_response",
                    "message": "DataPrem API returned non-JSON 200.",
                }
            return {"ok": True, "data": payload.get("data", payload)}

        if status == 401:
            return {
                "ok": False,
                "error": "unauthorized",
                "message": (
                    "API key invalid or revoked. Issue a new one with "
                    "`php bin/console app:api-token:create <email>` and update "
                    "DATAPREM_API_KEY."
                ),
            }

        if status == 404:
            return {
                "ok": False,
                "error": "not_found",
                "message": "No matching property in the Catastro for the given input.",
            }

        if status == 422:
            return {
                "ok": False,
                "error": "validation_error",
                "message": _safe_message(response, default="Catastro rejected the input as invalid."),
            }

        if status == 429:
            return {
                "ok": False,
                "error": "rate_limited",
                "message": (
                    "Rate limit reached for your DataPrem plan. Wait or upgrade tier."
                ),
            }

        if status >= 500:
            return {
                "ok": False,
                "error": "upstream_error",
                "message": f"DataPrem API returned HTTP {status}: temporary upstream issue.",
            }

        return {
            "ok": False,
            "error": "unexpected_status",
            "message": f"DataPrem API returned HTTP {status}.",
        }


def _safe_message(response: httpx.Response, *, default: str) -> str:
    try:
        body = response.json()
    except ValueError:
        return default
    if isinstance(body, dict) and isinstance(body.get("message"), str):
        return body["message"]
    return default
