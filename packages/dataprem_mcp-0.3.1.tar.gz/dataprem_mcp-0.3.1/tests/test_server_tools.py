"""Smoke tests on the four MCP tools: catastro real + 3 stubs.

These touch the tool callables directly (not the MCP wire protocol) — enough
to catch regressions in signatures, return shapes, and the stub flagging.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from dataprem_mcp import server


def test_catastro_tool_delegates_to_api_client() -> None:
    with patch.object(server, "DatapremApiClient") as cls:
        cls.return_value.get_catastro_property.return_value = {"ok": True, "data": {"x": 1}}

        result = server.dataprem_catastro_lookup(refcat="9872023VH5797S0001WX")

        assert result == {"ok": True, "data": {"x": 1}}
        cls.return_value.get_catastro_property.assert_called_once_with(
            refcat="9872023VH5797S0001WX",
            address=None,
            city=None,
            province=None,
        )


@pytest.mark.parametrize(
    "tool_callable,args,expected_phase",
    [
        (server.dataprem_borme_search, {"company_name": "ACME SL"}, "Fase 3"),
        (server.dataprem_cendoj_search, {"query": "despido improcedente"}, "Fase 4"),
        (server.dataprem_tenders_search, {"query": "limpieza"}, "Fase 3"),
    ],
)
def test_stub_tools_advertise_their_status(tool_callable, args, expected_phase) -> None:
    result = tool_callable(**args)
    assert result["_status"] == "stub"
    assert expected_phase in result["_eta_phase"]
    assert "demostración" in result["_message"].lower() or "demo" in result["_message"].lower()
    assert isinstance(result["resultados"], list) and result["resultados"]


def test_no_stub_tool_leaks_titular_field() -> None:
    """TK-207 decision: never expose the `titular` field on any tool. Belt-and-braces check."""
    payloads = [
        server.dataprem_borme_search(company_name="ACME"),
        server.dataprem_cendoj_search(query="x"),
        server.dataprem_tenders_search(query="x"),
    ]
    for payload in payloads:
        assert "titular" not in payload
        for row in payload.get("resultados", []):
            assert "titular" not in row
