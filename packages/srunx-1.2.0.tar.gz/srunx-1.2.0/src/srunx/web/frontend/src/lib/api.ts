import type {
  BrowseResult,
  CommandJob,
  ConfigPathInfo,
  Delivery,
  Endpoint,
  EnvVarInfo,
  HistoryStats,
  LogData,
  Mount,
  MountConfig,
  ProjectConfigResponse,
  ProjectInfo,
  ResourceSnapshot,
  ScriptPreviewRequest,
  ScriptPreviewResponse,
  SSHConnectResponse,
  SSHConnectionStatus,
  SSHMountConfig,
  SSHProfile,
  SSHProfilesResponse,
  SSHTestResult,
  SrunxConfig,
  Subscription,
  SweepCellRow,
  SweepRun,
  SyncResult,
  Watch,
  TemplateCreateRequest,
  TemplateDetail,
  TemplateListItem,
  TemplateUpdateRequest,
  Workflow,
  WorkflowCreateRequest,
  WorkflowRun,
  WorkflowRunOptions,
} from "./types.ts";

/* ── Helpers ─────────────────────────────────── */

type ValidationItem = { loc?: string[]; msg?: string };

/** Extract a human-readable message from a FastAPI error response body. */
function extractDetail(body: { detail?: unknown }, fallback: string): string {
  const detail = body.detail;
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) {
    const msgs = (detail as ValidationItem[]).map((e) =>
      e.loc && e.msg ? `${e.loc.join(".")}: ${e.msg}` : JSON.stringify(e),
    );
    return msgs.join("; ");
  }
  return fallback;
}

/* ── Jobs ─────────────────────────────────────── */

export const jobs = {
  list: async (): Promise<CommandJob[]> => {
    const res = await fetch("/api/jobs");
    if (!res.ok) throw new Error("Failed to fetch jobs");
    return res.json();
  },

  get: async (jobId: number): Promise<CommandJob> => {
    const res = await fetch(`/api/jobs/${jobId}`);
    if (!res.ok) throw new Error(`Failed to fetch job ${jobId}`);
    return res.json();
  },

  cancel: async (jobId: number): Promise<void> => {
    const res = await fetch(`/api/jobs/${jobId}`, { method: "DELETE" });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to cancel job"));
    }
  },

  submit: async (
    scriptContent: string,
    jobName: string,
    mountName?: string,
    notifySlack?: boolean,
    notifyOpts?: {
      notify?: boolean;
      endpointId?: number | null;
      preset?: string;
    },
  ): Promise<{ name: string; job_id: number | null; status: string }> => {
    const body: Record<string, unknown> = {
      name: jobName,
      script_content: scriptContent,
      job_name: jobName,
      mount_name: mountName,
      // DEPRECATED: retained for backward compatibility with the legacy
      // slack-only notification path; new endpoint/subscription fields below
      // supersede it when provided.
      notify_slack: notifySlack ?? false,
    };
    if (notifyOpts) {
      if (notifyOpts.notify !== undefined) body.notify = notifyOpts.notify;
      if (notifyOpts.endpointId !== undefined && notifyOpts.endpointId !== null)
        body.endpoint_id = notifyOpts.endpointId;
      if (notifyOpts.preset !== undefined) body.preset = notifyOpts.preset;
    }
    const res = await fetch("/api/jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to submit job"));
    }
    return res.json();
  },

  preview: async (
    body: ScriptPreviewRequest,
  ): Promise<ScriptPreviewResponse> => {
    const res = await fetch("/api/jobs/preview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to preview script"));
    }
    return res.json();
  },

  logs: async (
    jobId: number,
    offsets?: { stdout_offset?: number; stderr_offset?: number },
  ): Promise<LogData> => {
    const params = new URLSearchParams();
    if (offsets?.stdout_offset)
      params.set("stdout_offset", String(offsets.stdout_offset));
    if (offsets?.stderr_offset)
      params.set("stderr_offset", String(offsets.stderr_offset));
    const qs = params.toString();
    const res = await fetch(`/api/jobs/${jobId}/logs${qs ? `?${qs}` : ""}`);
    if (!res.ok) throw new Error(`Failed to fetch logs for job ${jobId}`);
    return res.json();
  },
};

/* ── Workflows ────────────────────────────────── */

export const workflows = {
  list: async (mount: string): Promise<Workflow[]> => {
    const params = new URLSearchParams({ mount });
    const res = await fetch(`/api/workflows?${params}`);
    if (!res.ok) throw new Error("Failed to fetch workflows");
    return res.json();
  },

  get: async (name: string, mount: string): Promise<Workflow> => {
    const params = new URLSearchParams({ mount });
    const res = await fetch(
      `/api/workflows/${encodeURIComponent(name)}?${params}`,
    );
    if (!res.ok) throw new Error(`Failed to fetch workflow "${name}"`);
    return res.json();
  },

  upload: async (
    yamlContent: string,
    filename: string,
    mount: string,
  ): Promise<Workflow> => {
    const res = await fetch("/api/workflows/upload", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ yaml: yamlContent, filename, mount }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to upload workflow"));
    }
    return res.json();
  },

  create: async (request: WorkflowCreateRequest): Promise<Workflow> => {
    const res = await fetch("/api/workflows/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to create workflow"));
    }
    return res.json();
  },

  run: async (
    name: string,
    mount: string,
    options?: WorkflowRunOptions,
  ): Promise<WorkflowRun | Record<string, unknown>> => {
    const params = new URLSearchParams({ mount });
    const res = await fetch(
      `/api/workflows/${encodeURIComponent(name)}/run?${params}`,
      {
        method: "POST",
        headers: options ? { "Content-Type": "application/json" } : {},
        body: options ? JSON.stringify(options) : undefined,
      },
    );
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to run workflow"));
    }
    return res.json();
  },

  getRun: async (runId: string): Promise<WorkflowRun> => {
    const res = await fetch(`/api/workflows/runs/${encodeURIComponent(runId)}`);
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to fetch run"));
    }
    return res.json();
  },

  delete: async (name: string, mount: string): Promise<void> => {
    const params = new URLSearchParams({ mount });
    const res = await fetch(
      `/api/workflows/${encodeURIComponent(name)}?${params}`,
      { method: "DELETE" },
    );
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to delete workflow"));
    }
  },

  cancelRun: async (runId: string): Promise<void> => {
    const res = await fetch(
      `/api/workflows/runs/${encodeURIComponent(runId)}/cancel`,
      { method: "POST" },
    );
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to cancel run"));
    }
  },
};

/* ── Resources ────────────────────────────────── */

export const resources = {
  snapshot: async (): Promise<ResourceSnapshot[]> => {
    const res = await fetch("/api/resources");
    if (!res.ok) throw new Error("Failed to fetch resources");
    return res.json();
  },
};

/* ── History ──────────────────────────────────── */

export const history = {
  stats: async (): Promise<HistoryStats> => {
    const res = await fetch("/api/history/stats");
    if (!res.ok) throw new Error("Failed to fetch history stats");
    return res.json();
  },
};

/* ── Files ────────────────────────────────── */

export const files = {
  mounts: async (): Promise<Mount[]> => {
    const res = await fetch("/api/files/mounts");
    if (!res.ok) throw new Error("Failed to fetch mounts");
    return res.json();
  },

  browse: async (mount: string, path: string = ""): Promise<BrowseResult> => {
    const params = new URLSearchParams({ mount });
    if (path) params.set("path", path);
    const res = await fetch(`/api/files/browse?${params}`);
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to browse files"));
    }
    return res.json();
  },

  sync: async (mount: string): Promise<SyncResult> => {
    const res = await fetch("/api/files/sync", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mount }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Sync failed"));
    }
    return res.json();
  },

  mountsConfig: async (): Promise<MountConfig[]> => {
    const res = await fetch("/api/files/mounts/config");
    if (!res.ok) throw new Error("Failed to fetch mount configuration");
    return res.json();
  },

  addMount: async (mount: MountConfig): Promise<MountConfig> => {
    const res = await fetch("/api/files/mounts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(mount),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to add mount"));
    }
    return res.json();
  },

  removeMount: async (name: string): Promise<void> => {
    const res = await fetch(`/api/files/mounts/${encodeURIComponent(name)}`, {
      method: "DELETE",
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to remove mount"));
    }
  },

  read: async (
    mount: string,
    path: string,
  ): Promise<{ content: string; path: string; mount: string }> => {
    const params = new URLSearchParams({ mount, path });
    const res = await fetch(`/api/files/read?${params}`);
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to read file"));
    }
    return res.json();
  },
};

/* ── Config ──────────────────────────────────── */

export const config = {
  get: async (): Promise<SrunxConfig> => {
    const res = await fetch("/api/config");
    if (!res.ok) throw new Error("Failed to fetch config");
    return res.json();
  },

  update: async (body: SrunxConfig): Promise<SrunxConfig> => {
    const res = await fetch("/api/config", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to update config"));
    }
    return res.json();
  },

  paths: async (): Promise<ConfigPathInfo[]> => {
    const res = await fetch("/api/config/paths");
    if (!res.ok) throw new Error("Failed to fetch config paths");
    return res.json();
  },

  reset: async (): Promise<SrunxConfig> => {
    const res = await fetch("/api/config/reset", { method: "POST" });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to reset config"));
    }
    return res.json();
  },

  /* SSH Profiles */

  sshProfiles: async (): Promise<SSHProfilesResponse> => {
    const res = await fetch("/api/config/ssh/profiles");
    if (!res.ok) throw new Error("Failed to fetch SSH profiles");
    return res.json();
  },

  addSSHProfile: async (body: {
    name: string;
    hostname: string;
    username: string;
    key_filename: string;
    port?: number;
    description?: string;
    ssh_host?: string;
    proxy_jump?: string;
  }): Promise<SSHProfile> => {
    const res = await fetch("/api/config/ssh/profiles", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to add SSH profile"));
    }
    return res.json();
  },

  updateSSHProfile: async (
    name: string,
    body: Partial<SSHProfile>,
  ): Promise<SSHProfile> => {
    const res = await fetch(
      `/api/config/ssh/profiles/${encodeURIComponent(name)}`,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      },
    );
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to update SSH profile"));
    }
    return res.json();
  },

  deleteSSHProfile: async (name: string): Promise<void> => {
    const res = await fetch(
      `/api/config/ssh/profiles/${encodeURIComponent(name)}`,
      { method: "DELETE" },
    );
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to delete SSH profile"));
    }
  },

  activateSSHProfile: async (name: string): Promise<void> => {
    const res = await fetch(
      `/api/config/ssh/profiles/${encodeURIComponent(name)}/activate`,
      { method: "POST" },
    );
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to activate SSH profile"));
    }
  },

  connectSSHProfile: async (name: string): Promise<SSHConnectResponse> => {
    const res = await fetch(
      `/api/config/ssh/profiles/${encodeURIComponent(name)}/connect`,
      { method: "POST" },
    );
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to connect SSH profile"));
    }
    return res.json();
  },

  testSSHProfile: async (name: string): Promise<SSHTestResult> => {
    const res = await fetch(
      `/api/config/ssh/profiles/${encodeURIComponent(name)}/test`,
      { method: "POST" },
    );
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to test SSH profile"));
    }
    return res.json();
  },

  sshStatus: async (): Promise<SSHConnectionStatus> => {
    const res = await fetch("/api/config/ssh/status");
    if (!res.ok) throw new Error("Failed to fetch SSH status");
    return res.json();
  },

  addSSHMount: async (
    profileName: string,
    mount: SSHMountConfig,
  ): Promise<SSHMountConfig> => {
    const res = await fetch(
      `/api/config/ssh/profiles/${encodeURIComponent(profileName)}/mounts`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(mount),
      },
    );
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to add mount"));
    }
    return res.json();
  },

  removeSSHMount: async (
    profileName: string,
    mountName: string,
  ): Promise<void> => {
    const res = await fetch(
      `/api/config/ssh/profiles/${encodeURIComponent(profileName)}/mounts/${encodeURIComponent(mountName)}`,
      { method: "DELETE" },
    );
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to remove mount"));
    }
  },

  /* Environment Variables */

  envVars: async (): Promise<EnvVarInfo[]> => {
    const res = await fetch("/api/config/env");
    if (!res.ok) throw new Error("Failed to fetch environment variables");
    return res.json();
  },

  /* Projects (mount-based) */

  listProjects: async (): Promise<ProjectInfo[]> => {
    const res = await fetch("/api/config/projects");
    if (!res.ok) throw new Error("Failed to fetch projects");
    return res.json();
  },

  getProject: async (mountName: string): Promise<ProjectConfigResponse> => {
    const res = await fetch(
      `/api/config/projects/${encodeURIComponent(mountName)}`,
    );
    if (!res.ok) throw new Error("Failed to fetch project config");
    return res.json();
  },

  updateProject: async (
    mountName: string,
    body: SrunxConfig,
  ): Promise<ProjectConfigResponse> => {
    const res = await fetch(
      `/api/config/projects/${encodeURIComponent(mountName)}`,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      },
    );
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to update project config"));
    }
    return res.json();
  },

  initProject: async (mountName: string): Promise<ProjectConfigResponse> => {
    const res = await fetch(
      `/api/config/projects/${encodeURIComponent(mountName)}/init`,
      { method: "POST" },
    );
    if (!res.ok) {
      const err = await res.json();
      throw new Error(
        extractDetail(err, "Failed to initialize project config"),
      );
    }
    return res.json();
  },
};

/* ── Templates ──────────────────────────────── */

export const templates = {
  list: async (): Promise<TemplateListItem[]> => {
    const res = await fetch("/api/templates");
    if (!res.ok) throw new Error("Failed to fetch templates");
    return res.json();
  },

  get: async (name: string): Promise<TemplateDetail> => {
    const res = await fetch(`/api/templates/${encodeURIComponent(name)}`);
    if (!res.ok) throw new Error(`Failed to fetch template "${name}"`);
    return res.json();
  },

  apply: async (
    name: string,
    body: {
      command: string[];
      job_name?: string;
      resources?: Record<string, unknown>;
      environment?: Record<string, unknown>;
      work_dir?: string;
      log_dir?: string;
      mount_name?: string;
      preview_only?: boolean;
    },
  ): Promise<Record<string, unknown>> => {
    const res = await fetch(
      `/api/templates/${encodeURIComponent(name)}/apply`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      },
    );
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to apply template"));
    }
    return res.json();
  },

  create: async (body: TemplateCreateRequest): Promise<TemplateListItem> => {
    const res = await fetch("/api/templates", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to create template"));
    }
    return res.json();
  },

  update: async (
    name: string,
    body: TemplateUpdateRequest,
  ): Promise<TemplateDetail> => {
    const res = await fetch(`/api/templates/${encodeURIComponent(name)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to update template"));
    }
    return res.json();
  },

  delete: async (name: string): Promise<void> => {
    const res = await fetch(`/api/templates/${encodeURIComponent(name)}`, {
      method: "DELETE",
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(extractDetail(err, "Failed to delete template"));
    }
  },
};

/* ── Endpoints ──────────────────────────────── */

export const endpoints = {
  list: async (opts?: {
    include_disabled?: boolean;
  }): Promise<Endpoint[]> => {
    const params = new URLSearchParams();
    if (opts?.include_disabled) params.set("include_disabled", "true");
    const qs = params.toString();
    const res = await fetch(`/api/endpoints${qs ? `?${qs}` : ""}`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, "Failed to fetch endpoints"));
    }
    return res.json();
  },

  create: async (body: {
    kind: string;
    name: string;
    config: object;
  }): Promise<Endpoint> => {
    const res = await fetch("/api/endpoints", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, "Failed to create endpoint"));
    }
    return res.json();
  },

  update: async (
    id: number,
    body: { name?: string; config?: object },
  ): Promise<Endpoint> => {
    const res = await fetch(`/api/endpoints/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, "Failed to update endpoint"));
    }
    return res.json();
  },

  disable: async (id: number): Promise<Endpoint> => {
    const res = await fetch(`/api/endpoints/${id}/disable`, { method: "POST" });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, "Failed to disable endpoint"));
    }
    return res.json();
  },

  enable: async (id: number): Promise<Endpoint> => {
    const res = await fetch(`/api/endpoints/${id}/enable`, { method: "POST" });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, "Failed to enable endpoint"));
    }
    return res.json();
  },

  delete: async (id: number): Promise<void> => {
    const res = await fetch(`/api/endpoints/${id}`, { method: "DELETE" });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, "Failed to delete endpoint"));
    }
  },
};

/* ── Subscriptions ──────────────────────────── */

export const subscriptions = {
  list: async (opts: {
    watch_id?: number;
    endpoint_id?: number;
  }): Promise<Subscription[]> => {
    const params = new URLSearchParams();
    if (opts.watch_id !== undefined)
      params.set("watch_id", String(opts.watch_id));
    if (opts.endpoint_id !== undefined)
      params.set("endpoint_id", String(opts.endpoint_id));
    const qs = params.toString();
    const res = await fetch(`/api/subscriptions${qs ? `?${qs}` : ""}`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, "Failed to fetch subscriptions"));
    }
    return res.json();
  },

  create: async (body: {
    watch_id: number;
    endpoint_id: number;
    preset: string;
  }): Promise<Subscription> => {
    const res = await fetch("/api/subscriptions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, "Failed to create subscription"));
    }
    return res.json();
  },

  delete: async (id: number): Promise<void> => {
    const res = await fetch(`/api/subscriptions/${id}`, { method: "DELETE" });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, "Failed to delete subscription"));
    }
  },
};

/* ── Watches ────────────────────────────────── */

export const watches = {
  list: async (opts?: {
    open?: boolean;
    kind?: string;
    target_ref?: string;
  }): Promise<Watch[]> => {
    const params = new URLSearchParams();
    if (opts?.open !== undefined) params.set("open", String(opts.open));
    if (opts?.kind) params.set("kind", opts.kind);
    if (opts?.target_ref) params.set("target_ref", opts.target_ref);
    const qs = params.toString();
    const res = await fetch(`/api/watches${qs ? `?${qs}` : ""}`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, "Failed to fetch watches"));
    }
    return res.json();
  },
};

/* ── Deliveries ─────────────────────────────── */

export const deliveries = {
  listBySubscription: async (
    subscriptionId: number,
    status?: string,
  ): Promise<Delivery[]> => {
    const params = new URLSearchParams({
      subscription_id: String(subscriptionId),
    });
    if (status) params.set("status", status);
    const res = await fetch(`/api/deliveries?${params.toString()}`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, "Failed to fetch deliveries"));
    }
    return res.json();
  },

  listRecent: async (opts?: {
    status?: string;
    limit?: number;
  }): Promise<Delivery[]> => {
    const params = new URLSearchParams();
    if (opts?.status) params.set("status", opts.status);
    if (opts?.limit !== undefined) params.set("limit", String(opts.limit));
    const qs = params.toString();
    const res = await fetch(`/api/deliveries${qs ? `?${qs}` : ""}`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, "Failed to fetch deliveries"));
    }
    return res.json();
  },

  countStuck: async (
    olderThanSec?: number,
  ): Promise<{ count: number; older_than_sec: number }> => {
    const params = new URLSearchParams();
    if (olderThanSec !== undefined)
      params.set("older_than_sec", String(olderThanSec));
    const qs = params.toString();
    const res = await fetch(`/api/deliveries/stuck${qs ? `?${qs}` : ""}`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, "Failed to fetch stuck count"));
    }
    return res.json();
  },
};

/* ── Sweep runs ─────────────────────────────── */

export const sweepRuns = {
  list: async (): Promise<SweepRun[]> => {
    const res = await fetch("/api/sweep_runs");
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, "Failed to fetch sweep runs"));
    }
    return res.json();
  },

  get: async (id: number): Promise<SweepRun> => {
    const res = await fetch(`/api/sweep_runs/${id}`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, `Failed to fetch sweep run ${id}`));
    }
    return res.json();
  },

  listCells: async (id: number): Promise<SweepCellRow[]> => {
    const res = await fetch(`/api/sweep_runs/${id}/cells`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(
        extractDetail(err, `Failed to fetch cells for sweep ${id}`),
      );
    }
    return res.json();
  },

  cancel: async (id: number): Promise<SweepRun> => {
    const res = await fetch(`/api/sweep_runs/${id}/cancel`, {
      method: "POST",
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(extractDetail(err, `Failed to cancel sweep run ${id}`));
    }
    return res.json();
  },
};
