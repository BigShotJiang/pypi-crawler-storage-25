"""Roxels MCP Server — tool definitions for AI agent integration."""

import asyncio
import json
import re
import textwrap
import webbrowser

from mcp.server.fastmcp import FastMCP

from .client import RoxelsClient

EMBED_JS_URL = "https://app.roxels.ai/embed.js"
ALLOWED_OPEN_ORIGINS = ("https://app.roxels.ai/",)


def _validate_join_url(url: str) -> None:
    """Ensure the URL points to a trusted Roxels origin before opening in browser."""
    if not any(url.startswith(origin) for origin in ALLOWED_OPEN_ORIGINS):
        raise ValueError(
            f"Refusing to open untrusted URL: {url}. "
            f"Expected origin: {ALLOWED_OPEN_ORIGINS[0]}"
        )

# ── Static reference data ──

TEMPLATE_SCHEMA_REFERENCE = {
    "goal_types": {
        "open": "Open-ended conversational goal — the AI explores a topic freely",
        "quantitative": "Extract specific numeric data points",
        "qualitative": "Extract opinions, feelings, subjective assessments",
        "structured": "Extract data matching a defined JSON schema",
        "context_dump": "User provides large amounts of context (docs, processes)",
        "walkthrough": "User walks through a process (often with screen sharing)",
    },
    "goal_fields": {
        "id": "string — unique ID for this goal. Required for goal-aware extraction (enables set_active_goal, onGoalTransition, per-goal understanding events).",
        "type": "string — one of the goal_types above",
        "prompt": "string — what the AI should explore/extract",
        "follow_up_depth": "string | null — how deep to probe",
        "schema": "object | null — extraction schema for this goal. When combined with an id, enables goal-focused extraction. Fields map names to types or {type, description} objects.",
        "extraction_mode": "string | null — 'cumulative' for full-state snapshots on each event. Default: additive deltas (each event carries only the delta since the last). Before setting this, check whether your backend endpoint clears all existing records before saving (replace-all) or merges new data into existing records (delta). If it clears, set 'cumulative' so each webhook fires a complete snapshot. If it merges, leave this unset.",
        "probing_areas": "string[] | null — specific areas to probe",
    },
    "settings_fields": {
        "language": "string — language code: en, es, pt, fr, de",
        "tone": "string — e.g. 'friendly-professional'",
        "max_session_duration_minutes": "int — default 30",
        "allow_screen_share": "bool — default true",
        "suggest_screen_sharing": "bool — default false",
        "multi_session": "bool — allow multiple sessions per interview, default true",
        "system_instructions": "string — custom instructions for the AI interviewer",
        "outputs": "array — output configurations (see output_types)",
        "skills": "string[] — skill UUIDs to attach",
        "skill_execution_mode": "string — 'observer' or 'inline'",
        "data_sources": "array — external lookup endpoints used to resolve free-text user input into structured objects (see configure_data_source and get_data_source_schema)",
        "embedded": "object — settings for the embedded widget: { skip_join_screen: bool (auto-join without showing the Join button, default true), auto_close: bool (close widget automatically after interview completes, default true), fab_anchor: 'viewport'|'container' (where the microphone FAB lives — 'viewport' floats fixed above everything, 'container' anchors inside a client-specified div, default 'viewport') }",
    },
    "schema_field_types": {
        "string": "Plain text value",
        "number": "Numeric value",
        "boolean": "True/false",
        "array": "List of values",
        "array of strings": "List of plain text values",
        "object": "Nested key-value structure",
        "resolved_reference": (
            "Special type — the AI extracts a plain string (e.g. 'Acme Corp'), then code automatically "
            "calls a configured data source to resolve it to a structured object "
            "(e.g. {accountId: 4712, name: 'Acme Corporation'}). Use when your webhook needs structured "
            "IDs that come from an external database. Requires a matching data source in settings.data_sources. "
            "See get_data_source_schema.\n\n"
            "Field spec options for resolved_reference fields:\n"
            "  data_source: (required) name matching a data source in settings.data_sources\n"
            "  default_params: extra query params sent with every lookup for this field. "
            "Values support {fieldName} syntax to pull from sibling fields — e.g. "
            "{\"level\": \"{level}\"} reads the sibling 'level' field from the same object. "
            "This is the correct way to pass dynamic filter params that vary per item "
            "(e.g. when metro vs. state vs. municipality requires a different level param). "
            "For array fields, {fieldName} resolves from the parent object, not each array item.\n"
            "  require_resolved: true — blocks commits if this field is still a plain string "
            "(resolution failed). Use when your webhook rejects string values.\n"
            "  required_before_commit: true — blocks commits if the field is missing entirely."
        ),
    },
    "output_types": {
        "webhook": {
            "description": "POST structured data to a URL during and after the interview",
            "config": {
                "url": "string — webhook endpoint URL. Supports {{context.fieldName}} interpolation from per-session context. Must use HTTPS in production.",
                "headers": "object — HTTP headers. Values support {{context.fieldName}} interpolation (e.g. {\"Authorization\": \"Bearer {{context.authToken}}\"})",
                "schema": "object — extraction schema. Simple: {field: 'type'} or with descriptions: {field: {type: 'string', description: 'format hint'}}. Descriptions guide the extraction model on expected format. Valid field types: string, number, boolean, array, array of strings, object, resolved_reference. Use resolved_reference when the field needs a live lookup against an external API (e.g. account IDs, product SKUs) — requires a matching entry in settings.data_sources. See get_data_source_schema. NOTE: The extraction model uses schema field descriptions for formatting, NOT system_instructions.",
                "streaming": "bool — if true, fires real-time events during the interview",
                "trigger_goal": "string | null — if set, this streaming webhook only fires for understanding events from this goal ID. Enables per-goal webhook routing (e.g. contact info goes to one endpoint, order details to another).",
                "raw_payload": "bool — if true, sends just the extracted data as the payload (e.g. {routes: [...]}) instead of the default envelope ({event, data, interview_id, timestamp}). Use when POSTing directly to APIs that expect a specific shape.",
            },
        },
        "structured": {
            "description": "Extract structured JSON matching a schema (stored in interview results). The extraction model uses schema field descriptions for formatting guidance, NOT system_instructions. Put format hints in descriptions.",
            "config": {
                "schema": "object — extraction schema. Simple: {field: 'type'} or with descriptions: {field: {type: 'string', description: 'format hint'}}.",
            },
        },
        "report": {
            "description": "Generate a written report summarizing the interview",
            "config": {},
        },
        "email": {
            "description": "Send interview results via email",
            "config": {
                "to": "string — recipient email",
                "subject_template": "string — email subject",
            },
        },
        "excel": {
            "description": "Generate an Excel file with extracted data mapped to cells",
            "config": {
                "schema": "object — field names to types",
                "cell_mapping": "object — maps field names to Excel cell references",
            },
        },
    },
}

DATA_SOURCE_REFERENCE = {
    "concept": (
        "Data sources solve a specific problem: your webhook needs structured objects (IDs, typed records), "
        "but users speak in natural language ('Acme Corp', 'the downtown branch', 'SKU-4872'). "
        "Without data sources, the webhook receives the raw string the user said. "
        "With data sources, the agent calls your external lookup API in real time and replaces "
        "the string with the structured object your backend expects.\n\n"
        "Example:\n"
        "  Without: user says 'Acme Corp'  →  webhook receives 'Acme Corp'\n"
        "  With:    user says 'Acme Corp'  →  webhook receives {\"accountId\": 4712, \"name\": \"Acme Corporation\", \"tier\": \"enterprise\"}"
    ),
    "when_to_use": (
        "Only when ALL of these are true:\n"
        "1. Your webhook receiver needs a structured object (not just a string)\n"
        "2. That object requires a live lookup against an external database\n"
        "3. The database is too large to pass as session context (hundreds or thousands of entries)\n\n"
        "Good use cases:\n"
        "- Customer or account IDs from a CRM\n"
        "- Product SKUs or catalog IDs from a product API\n"
        "- Geographic locations (states, cities, regions) from a geo API\n"
        "- Any canonical entity where the user names it but your system needs an ID\n\n"
        "Not needed for: plain strings, numbers, booleans, small enum lists (use context instead), "
        "or fields where the user's exact phrasing is what you want."
    ),
    "how_it_works": [
        "1. The AI extracts the user's phrasing as a plain string ('Acme Corp')",
        "2. Code detects the field is typed 'resolved_reference' in the goal schema",
        "3. An LLM generates 2-3 search query variations from the phrase (handles typos, abbreviations)",
        "4. All queries fire in parallel against your data source endpoint",
        "5. Results are deduplicated by id and a second LLM call picks the best match",
        "6. If confident: the string is replaced with the structured object before the webhook fires",
        "7. If ambiguous: the agent asks the user to clarify on the next turn, then retries",
        "8. If no results: the field retains the original string; webhook still fires",
    ],
    "data_source_definition": {
        "name": "string — unique identifier. Referenced by fields via 'data_source': 'name'",
        "description": "string — STRONGLY RECOMMENDED. Plain-English description of what the endpoint contains and what search terms it accepts. Injected into the query-generation prompt so the LLM generates domain-specific variations. Example: 'Company account directory — search by legal name, DBA name, or ticker symbol. Returns accounts your org has access to.'",
        "examples": (
            "array — STRONGLY RECOMMENDED. Few-shot examples of phrase → expected result mappings. "
            "Injected into both the query-generation prompt and the candidate-evaluation prompt. "
            "Each entry: {\"phrase\": \"<user phrasing>\", \"expected_result\": {<expected object or {\"name\": ...}>}}. "
            "Include 2-5 examples covering common phrasings, abbreviations, and ambiguous cases. "
            "Example: [{\"phrase\": \"Acme\", \"expected_result\": {\"id\": 42, \"name\": \"Acme Corporation\"}}, "
            "{\"phrase\": \"IBM\", \"expected_result\": {\"id\": 7, \"name\": \"International Business Machines\"}}]"
        ),
        "canonicalization_rules": (
            "string — RECOMMENDED when ambiguity is predictable. Plain-English rules the LLM follows "
            "when multiple candidates tie in the evaluation step. "
            "Example: 'When multiple accounts match the same name, prefer the one whose type matches "
            "the requested category param. If no category is specified, prefer the most recently active account.' "
            "These rules are injected verbatim into the disambiguation prompt."
        ),
        "cache_key_fields": (
            "array of strings — REQUIRED when a sibling field param changes which object is returned. "
            "Lists the default_params keys that should be included in the phrase-level resolution cache key. "
            "Without this, a phrase resolved for category='hardware' can be incorrectly returned from cache "
            "when the same phrase is later looked up with category='software'. "
            "Example: [\"category\"] — ensures the same product name resolves independently for each category value."
        ),
        "relaxable_params": (
            "array of strings — RECOMMENDED when default_params includes narrowing filter params. "
            "Lists the param names that are safe to drop on a 0-results retry. When a lookup returns "
            "0 candidates, the agent's recovery cascade automatically re-runs the request without "
            "these params to widen the search — catching cases where the extraction model set a filter "
            "to the wrong value. NEVER include tenancy or data-isolation params (account_id, org_id, "
            "customer_key, etc.) here — those guard data boundaries between customers and must never "
            "be relaxed. Only list domain-narrowing filters like 'type', 'category', 'tier'. "
            "Example: [\"category\"] — if a product lookup returns 0 at category=hardware, the cascade "
            "retries without the category filter and finds the product in a broader search."
        ),
        "endpoint": {
            "url": "string — GET endpoint URL. Supports {{context.fieldName}} interpolation from per-session context.",
            "method": "string — only 'GET' currently supported",
            "auth": {
                "type": "string — only 'bearer' currently supported",
                "token": "string — token value. Supports {{context.fieldName}} interpolation.",
            },
            "headers": "object — additional HTTP headers. Values support {{context.fieldName}} interpolation. Use this or endpoint.auth — both are supported.",
        },
        "default_params": "object — default query params merged into every request for this source. Per-field default_params (set in the field spec) take precedence over source-level defaults.",
        "output_schema": {
            "template": (
                "object — a post-processing TRANSFORMATION MAP applied to the raw API result AFTER the HTTP call. "
                "It is NOT shown to the extraction model and does NOT validate the response. "
                "It reshapes the raw result into the object your webhook expects.\n\n"
                "How to write a template:\n"
                "  - Static values pass through as-is: \"category\": \"product\"\n"
                "  - \"<field>\"          → result['field'] (from API response body)\n"
                "  - \"<nested.field>\"   → result['nested']['field'] (nested path)\n"
                "  - \"<$params.name>\"   → value of the named request param (e.g. the 'category' you sent)\n\n"
                "Example: {\"id\": \"<id>\", \"kind\": \"<$params.category>\", \"label\": \"<name>\"}\n"
                "  When called with category=hardware → {\"id\": 5, \"kind\": \"hardware\", \"label\": \"...\"}\n"
                "  Use <$params.X> when the API doesn't echo the filter param back in its response.\n\n"
                "Omit entirely to pass the raw API result object through unchanged.\n\n"
                "WRONG (this is a JSON Schema description, not a transformation map — it will be ignored):\n"
                "  {\"type\": \"array\", \"description\": \"list of items from the API\"}\n\n"
                "The template is applied to a single result object. Your endpoint must return a flat array "
                "of objects with a consistent shape regardless of query params."
            ),
        },
    },
    "field_spec": {
        "type": "'resolved_reference' — marks this field for data source resolution. MUST be set explicitly — putting 'resolve via source_name' in a description does nothing.",
        "data_source": "string — must exactly match a name in settings.data_sources",
        "default_params": (
            "object — extra query params sent with every GET request for this field. "
            "Merged with source-level default_params (field takes precedence). "
            "Values can reference sibling extracted fields using {fieldName} syntax — "
            "e.g. {\"type\": \"{category}\"} reads the extracted value of the category sibling field from the same object. "
            "Only string sibling fields are substituted; if the sibling is missing or not a string, the placeholder is passed as-is."
        ),
    },
    "array_of_resolved_references": {
        "description": (
            "To produce a flat array where each item IS a resolved object (not a wrapper object containing one), "
            "use item_type: 'resolved_reference' on the array field. "
            "data_source and default_params go directly on the array field, not inside an item_schema.\n\n"
            "Use this when your webhook expects [{id, type}, {id, type}, ...] — a flat list of resolved objects.\n\n"
            "{fieldName} in default_params resolves from the parent object's sibling fields (not from inside each item), "
            "so all items in the array share the same param value from their parent context."
        ),
        "schema_example": {
            "destinations": {
                "type": "array",
                "item_type": "resolved_reference",
                "data_source": "my_source",
                "default_params": {"category": "{category}"},
                "_note": "Each string the agent extracts becomes a resolved object. {category} comes from the sibling 'category' field in the parent object."
            }
        },
        "produces": [{"id": 1, "label": "Item A"}, {"id": 3, "label": "Item B"}],
        "vs_item_schema": (
            "item_schema approach: each item is {fieldName: resolvedObj} — a wrapper object. "
            "item_type approach: each item IS the resolved object directly. "
            "Use item_type when your webhook reads array items directly (e.g. dest.get('id'))."
        ),
    },
    "full_example": {
        "description": (
            "Example: resolving a customer account name to a structured CRM record. "
            "In the output_schema template, '<id>', '<display_name>', '<account_tier>' are placeholders — "
            "replace them with the actual field names your API returns. "
            "E.g. if your API returns {\"uuid\": ..., \"label\": ..., \"plan\": ...}, "
            "use \"<uuid>\", \"<label>\", \"<plan>\" instead."
        ),
        "settings.data_sources": [
            {
                "name": "account_lookup",
                "description": "Resolve customer name to structured account record",
                "endpoint": {
                    "url": "https://api.example.com/v1/accounts/search",
                    "method": "GET",
                    "auth": {"type": "bearer", "token": "{{context.authToken}}"},
                },
                "output_schema": {
                    "template": {
                        "accountId": "<id>",
                        "name": "<display_name>",
                        "tier": "<account_tier>",
                        "_note": "Replace <id>, <display_name>, <account_tier> with your API's actual field names"
                    }
                },
            }
        ],
        "goal_schema_field_single": {
            "account": {
                "type": "resolved_reference",
                "data_source": "account_lookup",
            }
        },
        "goal_schema_field_array_of_objects": {
            "orders": {
                "type": "array",
                "item_schema": {
                    "account": {
                        "type": "resolved_reference",
                        "data_source": "account_lookup",
                    },
                    "quantity": "number",
                }
            }
        },
        "webhook_receives": {
            "account": {"accountId": 4712, "name": "Acme Corporation", "tier": "enterprise"}
        },
    },
    "common_mistakes": [
        "1. WRONG type — using a text description like 'resolve via source_name' on a string field instead of setting type='resolved_reference'. The lookup will never trigger regardless of what the description says.",
        "2. WRONG output_template — writing a JSON Schema description {\"type\": \"array\", \"description\": \"...\"} instead of a transformation map {\"webhookField\": \"<apiResultField>\"}. The wrong form is silently ignored.",
        "3. MISSING item_schema for arrays — putting resolved_reference fields under 'items' instead of 'item_schema' inside an array spec. The resolver only walks item_schema.",
        "4. WRONG auth format — check whether your endpoint expects a header key (use endpoint.headers) or a Bearer token (use endpoint.auth.type=bearer + auth.token). Both patterns are supported; just be consistent.",
        "5. SOURCE NOT REGISTERED — referencing data_source='my_source' in a field spec without first calling configure_data_source with that name. Resolution silently skips unknown source names.",
        "6. MISSING description — the description field is used by the agent's search query generator to produce relevant query variations. Without it, the agent generates generic terms and may miss domain-specific abbreviations or synonyms. Always include a plain-English description of what the endpoint contains and what search terms it accepts. Example: 'Company account directory — search by legal name, DBA name, or ticker symbol.'",
        "7. MISSING examples — without few-shot examples the query generator uses generic variations and the candidate picker has no precedent to anchor decisions. Always include 2-5 examples per data source. This is the single most impactful reliability improvement after registering the endpoint.",
        "8. MISSING cache_key_fields when a sibling param varies — if your field uses any dynamic sibling param in default_params (e.g. {category}, {type}), and the same phrase can legitimately resolve to different objects depending on that param, you MUST set cache_key_fields to include that param name. Without it, the first resolution for a phrase is returned from cache for all subsequent lookups of the same phrase, even with a different param value.",
        "9. MISSING commit validation rules — resolved_reference fields can commit as plain strings if resolution fails. Always set require_resolved: true on any field that must be a structured object when it reaches your webhook. Call set_goal_commit_rules or add require_resolved directly in the field spec via set_goal_schema.",
    ],
    "setup_steps": [
        "0. Read your endpoint implementation before configuring. Verify the exact field names returned per query param value (field shapes can vary — e.g. a 'level' param may cause the response to return different fields depending on its value), which params are required vs. optional, and what the response looks like for edge-case inputs (0 results, ambiguous name). Do not write output_schema.template until you have seen a real response shape.",
        "1. Call configure_data_source with your endpoint details, description, examples, canonicalization_rules, and cache_key_fields → adds to settings.data_sources.",
        "2. Call set_goal_schema with your goal's schema. For each resolved_reference field, include require_resolved: true if the webhook needs a structured object (not a plain string).",
        "3. Call set_goal_commit_rules to set commit_policy and invariants (cross-field rules) per goal.",
        "4. Call guided_setup_questions to get a checklist of missing reliability rules — answer each question and apply the suggested calls.",
        "5. Call validate_template_data_sources to catch misconfiguration before running an interview.",
        "6. Call test_data_source to verify auth and response shape.",
        "7. Run a test interview and check webhook payload for resolved objects.",
    ],
}

VALIDATION_REFERENCE = {
    "concept": (
        "Layer 2 validation rules are template-level hard constraints that block a commit from firing "
        "if the extracted data doesn't meet the rules. They are expressed as data on the template "
        "(not as prose in system_instructions), so the code enforces them deterministically.\n\n"
        "All rules are opt-in and additive: a template without any validation rules behaves exactly "
        "as before. Rules only activate when explicitly set. Start with require_resolved on any "
        "resolved_reference field that must be a structured object when it reaches your webhook."
    ),
    "field_level_rules": {
        "require_resolved": (
            "boolean — set true on a resolved_reference field (or array with item_type='resolved_reference') "
            "to block the commit if that field is still a plain string (i.e., data source resolution failed or "
            "was ambiguous and the user didn't clarify). "
            "Without this, a field can commit as a raw string like 'Acme Corp' when the lookup "
            "found two candidates and never resolved. Your webhook would receive a string instead of "
            "the expected structured object.\n\n"
            "Set this on EVERY resolved_reference field whose webhook receiver expects an object. "
            "Example field spec:\n"
            "  {\"supplier\": {\"type\": \"resolved_reference\", \"data_source\": \"supplier_lookup\", "
            "\"require_resolved\": true}}"
        ),
        "required_before_commit": (
            "boolean — set true on any field (any type) that must be non-empty before committing. "
            "Blocks commits where the field is null, empty string, or empty list. "
            "Use for fields that are mandatory inputs to your webhook (required form fields). "
            "Example: {\"carrier_name\": {\"type\": \"string\", \"required_before_commit\": true}}"
        ),
    },
    "goal_level_rules": {
        "commit_policy": (
            "string — controls when the commit fires. One of:\n"
            "  'auto'               — default. Commits fire automatically after each extraction turn. "
            "No explicit user confirmation required.\n"
            "  'require_all_required' — auto-commits fire only when all required_before_commit fields "
            "are satisfied. User-confirmed commits always fire validation.\n"
            "  'human_confirm'      — auto-commits are suppressed entirely. Commit only fires when the "
            "user explicitly confirms via the two-phase propose → confirm flow.\n\n"
            "Set on the goal object (not inside the schema). "
            "Example goal: {\"id\": \"save_route\", \"type\": \"structured\", \"prompt\": \"...\", "
            "\"commit_policy\": \"require_all_required\", \"schema\": {...}}"
        ),
        "invariants": (
            "array — cross-field rules using a shape-match DSL: [{\"when\": {<field_path>: <value>}, \"then\": {<field_path>: <value>}}]. "
            "If the 'when' subset matches the committed payload, the 'then' subset must also hold. "
            "If it doesn't, the commit is blocked.\n\n"
            "FLAT OBJECT SCHEMAS — use dot-notation for nested fields:\n"
            "  [{\"when\": {\"order.status\": \"shipped\"}, \"then\": {\"order.tracking_id\": \"required\"}}]\n\n"
            "ARRAY SCHEMAS — when the goal schema produces an array of items (e.g., an orders array "
            "where each item has a category, product, and quantity), use [*] to express per-item rules. "
            "[*] means 'for each item in this array at the same index'. Both the 'when' and 'then' "
            "paths must reference the same array with [*]:\n"
            "  [{\"when\": {\"items[*].category\": \"hardware\"}, \"then\": {\"items[*].product.type\": \"hardware\"}}]\n"
            "This checks: for each item at index i, if items[i].category == 'hardware' then "
            "items[i].product.type must also be 'hardware'.\n\n"
            "LIMITATIONS:\n"
            "  - [*] may appear at most once per path (no nested array traversal)\n"
            "  - [*] in 'when' and 'then' must reference the same array key\n"
            "  - Mix of flat and [*] paths in the same invariant is not supported\n\n"
            "Set on the goal object alongside commit_policy. "
            "Call set_goal_commit_rules to configure."
        ),
    },
    "how_it_works": [
        "1. commit fires → before sending to backend, _validate_commit_data() walks the snapshot",
        "2. For each field spec with require_resolved=true: if the value is still a string, it's a violation",
        "3. For each field spec with required_before_commit=true: if the value is empty, it's a violation",
        "4. For each invariant: if 'when' matches the snapshot, 'then' must also match (supports [*] for arrays)",
        "5. If any violations: a self-correction pass runs automatically before routing to the user:",
        "   Step A — re-resolve unresolved DS fields (re-triggers the full DS lookup for plain-string values)",
        "   Step B — LLM correction call: given transcript + current snapshot + violations, produce a corrected snapshot",
        "   If self-correction passes re-validation, the corrected snapshot commits without user involvement.",
        "6. If self-correction cannot fix the violations: commit is blocked, agent asks user for clarification.",
        "7. Once all violations are cleared, the commit fires normally.",
    ],
    "common_mistakes": [
        "Using flat dot-notation invariants on array-typed goals — use [*] syntax: "
        "{'when': {'items[*].category': 'hardware'}, 'then': {'items[*].product.type': 'hardware'}}",
        "Putting [*] in 'when' but not in 'then' (or vice versa) — both sides must use [*] for the same array",
        "Expecting invariants to fire when 'when' conditions don't match — if 'when' doesn't match, the 'then' block is not checked (no violation)",
    ],
    "setup_with_mcp": (
        "To set validation rules on a template:\n"
        "  1. Call set_goal_schema with require_resolved: true on each resolved_reference field.\n"
        "  2. Call set_goal_commit_rules with commit_policy and invariants per goal.\n"
        "  3. Call guided_setup_questions to get a checklist of remaining gaps.\n"
        "  4. Call get_validation_schema to read this full reference."
    ),
    "worked_example_array_invariants": {
        "description": "Goal whose schema is an array of order items — each item has a category, product (resolved), and quantity",
        "goal_object": {
            "id": "save_order_items",
            "type": "structured",
            "prompt": "Collect the items in this order",
            "commit_policy": "require_all_required",
            "invariants": [
                {"when": {"items[*].category": "hardware"}, "then": {"items[*].product.type": "hardware"}},
                {"when": {"items[*].category": "software"}, "then": {"items[*].product.type": "software"}},
            ],
            "schema": {
                "type": "array",
                "item_schema": {
                    "category": {"type": "string", "required_before_commit": True},
                    "product": {
                        "type": "resolved_reference",
                        "data_source": "product_catalog",
                        "default_params": {"category": "{category}"},
                        "require_resolved": True,
                        "required_before_commit": True,
                    },
                    "quantity": {"type": "number", "required_before_commit": True},
                },
            },
        },
        "what_it_prevents": [
            "order item committed with category='hardware' but product.type='software' (category/type mismatch per item)",
            "any order item missing category or product",
            "product left as a plain string instead of a resolved catalog object",
        ],
    },
    "worked_example": {
        "goal_object": {
            "id": "save_supplier_contact",
            "type": "structured",
            "prompt": "Collect the supplier and their primary contact",
            "commit_policy": "require_all_required",
            "invariants": [
                {"when": {"supplier.tier": "gold"}, "then": {"contact.priority": "high"}},
            ],
            "schema": {
                "supplier": {
                    "type": "resolved_reference",
                    "data_source": "supplier_lookup",
                    "require_resolved": True,
                    "required_before_commit": True,
                },
                "contact": {
                    "type": "resolved_reference",
                    "data_source": "contact_lookup",
                    "require_resolved": True,
                    "required_before_commit": True,
                    "default_params": {"supplier_id": "{supplier.id}"},
                },
            },
        },
        "what_it_prevents": [
            "supplier committed as 'Acme Corp' (string) instead of {id: 42, name: 'Acme Corporation', tier: 'gold'}",
            "commit firing before supplier or contact is collected",
            "gold-tier supplier paired with a low-priority contact (tier/priority mismatch)",
        ],
    },
}

EMBED_CONFIG_REFERENCE = {
    "js_sdk_url": EMBED_JS_URL,
    "init_options": {
        "templateKey": "string — publishable embed key (rk_...). Required.",
        "onUnderstanding": "function — real-time data callback. Fires each conversation turn with extracted fields. Events are additive: merge keys into your state. Each event contains only fields that changed. A field can be overwritten by a later event but is never explicitly unset.",
        "onComplete": "function — final results: { summary, findings, duration_seconds, external_id }. Fires after backend processing completes (5-15 seconds after interview ends).",
        "onClose": "function — called when widget is closed by the user",
        "onError": "function — called with { error } on errors",
        "onGoalTransition": "function — called when the agent moves to a new interview goal. Receives { from_goal, to_goal }. Use this to navigate your UI to the corresponding form step.",
    },
    "open_options": {
        "mode": "string — 'modal' (centered dialog, 420x560px) or 'compact' (floating bottom-right panel). Default: 'modal'.",
        "personName": "string — name shown to the AI. Default: 'Guest'.",
        "externalId": "string — your identifier, echoed in all webhooks.",
        "sessionId": "string — pre-created session ID (advanced flow, skips session creation).",
        "context": "object — per-session reference data passed to the AI (e.g., valid equipment types, company-specific options). Max 64KB. The agent uses this to validate responses and suggest canonical values.",
    },
    "methods": ["Roxels.init(options)", "Roxels.open(options)", "Roxels.close()", "Roxels.destroy()", "Roxels.send(type, payload)"],
    "form_factors": {
        "modal": "Centered dialog (420x560px) with dimmed backdrop. Like a compact video call window.",
        "compact": "Floating panel in bottom-right corner. Non-obstructive. Collapses to a button when closed.",
    },
    "security_notes": [
        "Embed keys (rk_ prefix) are safe for client-side use — scoped to one template, can only create sessions.",
        "API keys (sk_) stay server-side — never put them in client code.",
        "The iframe loads from app.roxels.ai — no CORS configuration needed on your end.",
    ],
    "callback_notes": [
        "Callbacks use postMessage from an iframe. The widget DOM element must remain in the page for callbacks to fire.",
        "Cross-origin communication works automatically (uses '*' target origin).",
        "onComplete fires after server-side processing (5-15s after interview ends). If the user closes the browser tab before processing finishes, onComplete will not fire — use webhooks as a reliable server-side fallback.",
        "onUnderstanding events are additive: each event contains only the fields that changed. Merge them into your state object.",
    ],
}


def _interrogate_source(ds: dict, template_id: str) -> list[dict]:
    """Diagnose a data source and return blocking questions for any missing reliability fields.

    Called immediately after configure_data_source and from guided_setup_questions.
    Returns questions the calling agent must answer before the source is production-ready.
    """
    name = ds.get("name", "unnamed")
    default_params = ds.get("default_params", {})
    items = []

    if not ds.get("description"):
        items.append({
            "severity": "HIGH",
            "field": f"data_source '{name}' → description",
            "problem": "No description. The query generator is flying blind — it produces generic search variations and misses domain-specific abbreviations.",
            "answer_this": (
                f"What does the '{name}' endpoint search across? "
                f"What kinds of terms does it accept — full names, abbreviations, codes, colloquialisms? "
                f"What does a typical result object look like?"
            ),
            "then_call": f"configure_data_source(template_id='{template_id}', name='{name}', description='<your answer>')",
        })

    if not ds.get("examples"):
        items.append({
            "severity": "HIGH",
            "field": f"data_source '{name}' → examples",
            "problem": "No few-shot examples. Without anchors, the query generator and candidate picker make arbitrary choices on ambiguous phrases — semi-consistent behavior is guaranteed.",
            "answer_this": (
                f"Give 3–5 concrete examples of phrases a user might say that '{name}' should resolve, "
                f"and what the correct structured result is for each. "
                f"Include edge cases: abbreviations, colloquialisms, partial names, accented variants."
            ),
            "then_call": (
                f"configure_data_source(template_id='{template_id}', name='{name}', "
                f"examples=[{{\"phrase\": \"<phrase>\", \"expected_result\": {{\"id\": ..., \"name\": \"...\"}}}}])"
            ),
        })

    if not ds.get("canonicalization_rules"):
        items.append({
            "severity": "MEDIUM",
            "field": f"data_source '{name}' → canonicalization_rules",
            "problem": "No tiebreaker rules. When the endpoint returns multiple plausible candidates for the same phrase, the agent makes an arbitrary choice.",
            "answer_this": (
                f"When '{name}' returns multiple candidates for the same phrase, how should the agent choose? "
                f"Are there params (like 'type', 'category', 'tier') that determine which result is correct? "
                f"Are there preferred result types when ambiguous (e.g. prefer a more specific record over a more general one)?"
            ),
            "then_call": (
                f"configure_data_source(template_id='{template_id}', name='{name}', "
                f"canonicalization_rules='<your rules>')"
            ),
        })

    if default_params and not ds.get("cache_key_fields"):
        param_keys = list(default_params.keys())
        items.append({
            "severity": "MEDIUM",
            "field": f"data_source '{name}' → cache_key_fields",
            "problem": (
                f"Has default_params {param_keys} but no cache_key_fields. "
                f"If any param is filled from a sibling field (e.g. {{category}}), the same phrase resolved "
                f"with a different param value will get a stale cached result from a prior lookup."
            ),
            "answer_this": (
                f"Do any of these params — {param_keys} — change which object is the correct result "
                f"for the same phrase? For example, does 'Widget A' resolve differently when category=hardware "
                f"vs category=software? If yes, list which params matter."
            ),
            "then_call": (
                f"configure_data_source(template_id='{template_id}', name='{name}', "
                f"cache_key_fields=[\"<param_that_changes_the_result>\"])"
            ),
        })

    # relaxable_params — narrowing params safe to drop on 0-results retry
    if default_params and not ds.get("relaxable_params"):
        # Only surface this for params that look like narrowing filters (not context injections like {{context.*}})
        static_params = [
            k for k, v in default_params.items()
            if isinstance(v, str) and not v.startswith("{{context.")
        ]
        if static_params:
            items.append({
                "severity": "MEDIUM",
                "field": f"data_source '{name}' → relaxable_params",
                "problem": (
                    f"Has narrowing params {static_params} but no relaxable_params declared. "
                    f"When a lookup returns 0 results, the agent's recovery cascade can automatically "
                    f"drop declared params and retry — catching cases where the extraction model picked "
                    f"the wrong filter value. Without this, the cascade skips straight to world-knowledge "
                    f"fallback even if the entity exists in the database under a different filter value."
                ),
                "answer_this": (
                    f"Which of these params — {static_params} — are safe to omit on a retry? "
                    f"A param is safe to relax if omitting it broadens the search without leaking data "
                    f"across tenancy boundaries (e.g. a 'type' or 'category' filter is safe; an account_id "
                    f"or org_id that isolates data to one customer is NOT safe and must never be relaxed). "
                    f"List only the params that are narrowing filters, not tenancy guards."
                ),
                "then_call": (
                    f"configure_data_source(template_id='{template_id}', name='{name}', "
                    f"relaxable_params=[\"<safe_narrowing_param>\"])"
                ),
            })

    return items


def _interrogate_schema(goal: dict, template_id: str, data_sources: list[dict]) -> list[dict]:
    """Diagnose a goal schema and return blocking questions for any missing reliability fields.

    Called immediately after set_goal_schema and from guided_setup_questions.
    """
    gid = goal.get("id", "unknown")
    schema = goal.get("schema", {})
    items = []

    if not schema or not isinstance(schema, dict):
        return items

    # Determine if array schema and get the item schema to walk
    is_array = schema.get("type") == "array"
    field_map = schema.get("item_schema", {}) if is_array else schema

    def _walk_fields(fmap: dict, path_prefix: str = ""):
        for field_name, field_def in fmap.items():
            if not isinstance(field_def, dict):
                continue
            path = f"{path_prefix}{field_name}"
            ftype = field_def.get("type")

            # resolved_reference without require_resolved
            if ftype == "resolved_reference" and not field_def.get("require_resolved"):
                ds_name = field_def.get("data_source", "(unknown)")
                items.append({
                    "severity": "HIGH",
                    "field": f"goal '{gid}' → schema.{path} (resolved_reference)",
                    "problem": (
                        f"require_resolved is not set. If the '{ds_name}' lookup fails or is ambiguous, "
                        f"this field commits as a plain string. Your webhook receives a string instead "
                        f"of the structured object it expects — silent data corruption."
                    ),
                    "answer_this": (
                        f"Does your downstream endpoint require '{path}' to be a structured object "
                        f"(not a raw string)? If your API would reject or mishandle a string value "
                        f"here, set require_resolved: true."
                    ),
                    "then_call": (
                        f"Re-call set_goal_schema with require_resolved: true added to the '{path}' field spec."
                    ),
                })

            # resolved_reference without required_before_commit
            if ftype == "resolved_reference" and not field_def.get("required_before_commit"):
                items.append({
                    "severity": "MEDIUM",
                    "field": f"goal '{gid}' → schema.{path} (resolved_reference)",
                    "problem": (
                        f"required_before_commit is not set. A commit can fire with '{path}' missing entirely "
                        f"if the agent never collected it."
                    ),
                    "answer_this": (
                        f"Is '{path}' a required field in your downstream API? "
                        f"Would a commit without it be rejected or stored incorrectly?"
                    ),
                    "then_call": (
                        f"Re-call set_goal_schema with required_before_commit: true on the '{path}' field if required."
                    ),
                })

            # array with item_type=resolved_reference
            if ftype == "array" and field_def.get("item_type") == "resolved_reference" and not field_def.get("require_resolved"):
                ds_name = field_def.get("data_source", "(unknown)")
                items.append({
                    "severity": "HIGH",
                    "field": f"goal '{gid}' → schema.{path}[] (array of resolved_reference)",
                    "problem": (
                        f"require_resolved is not set on array field '{path}'. "
                        f"Array items that fail '{ds_name}' resolution commit as plain strings. "
                        f"Your webhook receives ['raw string'] instead of [{{id, ...}}]."
                    ),
                    "answer_this": (
                        f"Does your downstream endpoint require each item in '{path}' to be a structured object? "
                        f"If yes, set require_resolved: true."
                    ),
                    "then_call": (
                        f"Re-call set_goal_schema with require_resolved: true on the '{path}' array field spec."
                    ),
                })

            # recurse into item_schema
            if ftype == "array" and isinstance(field_def.get("item_schema"), dict):
                _walk_fields(field_def["item_schema"], path_prefix=f"{path}[].")

    _walk_fields(field_map, path_prefix="[*]." if is_array else "")

    # Goal-level: missing commit_policy when has resolved_references
    has_resolved = any(
        isinstance(fd, dict) and (
            fd.get("type") == "resolved_reference" or
            (fd.get("type") == "array" and fd.get("item_type") == "resolved_reference")
        )
        for fd in field_map.values()
        if isinstance(fd, dict)
    )
    if has_resolved and not goal.get("commit_policy"):
        items.append({
            "severity": "MEDIUM",
            "field": f"goal '{gid}' → commit_policy",
            "problem": (
                "No commit_policy set. With resolved_reference fields, auto-commits may fire "
                "before all required lookups complete or before the user has confirmed the data."
            ),
            "answer_this": (
                f"For goal '{gid}': should the commit fire automatically once data is collected, "
                f"only after ALL required fields are present, or only after explicit user confirmation? "
                f"Options: 'auto' | 'require_all_required' | 'human_confirm'."
            ),
            "then_call": (
                f"set_goal_commit_rules(template_id='{template_id}', goal_id='{gid}', "
                f"commit_policy='<your choice>')"
            ),
        })

    # Goal-level: missing invariants when array schema with resolved_references
    if is_array and has_resolved and not goal.get("invariants"):
        items.append({
            "severity": "MEDIUM",
            "field": f"goal '{gid}' → invariants",
            "problem": (
                "Array schema with resolved_reference fields but no cross-field invariants. "
                "If any resolved field depends on a sibling field's value (e.g. a category field determines "
                "which type of product is correct), mismatches will reach your endpoint silently."
            ),
            "answer_this": (
                f"Within each item in goal '{gid}': are there fields that must agree with each other? "
                f"For example, if an item has a 'category' field and a 'product' resolved_reference, "
                f"does category=hardware require product.type=hardware? List any such rules."
            ),
            "then_call": (
                f"set_goal_commit_rules(template_id='{template_id}', goal_id='{gid}', "
                f"invariants=[{{\"when\": {{\"[*].field\": \"value\"}}, \"then\": {{\"[*].other_field\": \"expected_value\"}}}}])"
            ),
        })

    return items


def create_server(client: RoxelsClient) -> FastMCP:
    """Create and configure the MCP server with all Roxels tools."""
    mcp = FastMCP("roxels")

    # ── Group A: Template Management ──

    @mcp.tool()
    async def list_templates() -> str:
        """List all active interview templates in your Roxels organization.

        Returns template names, IDs, goals, and settings. Use this to see what
        templates are available before running interviews or configuring outputs.
        """
        templates = await client.list_templates()
        return json.dumps(templates, indent=2, default=str)

    @mcp.tool()
    async def get_template(template_id: str) -> str:
        """Get full details of a specific template including goals, settings, and output configurations.

        Args:
            template_id: UUID of the template
        """
        template = await client.get_template(template_id)
        return json.dumps(template, indent=2, default=str)

    @mcp.tool()
    async def get_runtime_learnings(template_id: str) -> str:
        """Return a human-readable summary of what the system has learned from live interview sessions.

        Shows two types of learnings:
          1. Data source learnings — resolved examples (phrase → result) and synthesized
             do/don't rules for each configured data source.
          2. Webhook output learnings — do/don't rules derived from successful and failed
             webhook POST observations.

        Also returns suggested_actions: concrete MCP calls to consider making based on
        what has been learned. Use these to update the template configuration so that
        future sessions benefit from the learnings without relying on runtime injection.

        Args:
            template_id: UUID of the template
        """
        template = await client.get_template(template_id)
        settings_data = template.get("settings", {})
        goals = template.get("goals", [])
        learnings = template.get("learnings") or {}
        if isinstance(learnings, str):
            try:
                learnings = json.loads(learnings)
            except Exception:
                learnings = {}

        data_sources = settings_data.get("data_sources", [])
        outputs_config = settings_data.get("outputs", [])

        ds_learnings = learnings.get("data_sources", {})
        output_learnings = learnings.get("outputs", {})

        # Build structured data source section
        ds_section = {}
        for src in data_sources:
            src_name = src.get("name", "<unnamed>")
            src_entry = ds_learnings.get(src_name, {})
            examples = src.get("examples", [])
            ds_section[src_name] = {
                "examples_count": len(examples),
                "recent_example_phrases": [ex.get("phrase") for ex in examples[-5:] if ex.get("phrase")],
                "learned_rules": src_entry.get("_learned_rules", {"do": [], "dont": []}),
                "rules_last_synthesized": src_entry.get("_rules_last_synthesized"),
            }

        # Build structured webhook output section
        webhook_outputs = []
        for i, output in enumerate(outputs_config):
            if output.get("type") != "webhook":
                continue
            config = output.get("config", {})
            out_entry = output_learnings.get(str(i), {})
            webhook_outputs.append({
                "index": i,
                "url": config.get("url", ""),
                "trigger_goal": config.get("trigger_goal"),
                "learned_rules": out_entry.get("_learned_rules", {"do": [], "dont": []}),
                "rules_last_synthesized": out_entry.get("_rules_last_synthesized"),
            })

        # Build suggested_actions from what has been learned
        suggested_actions = []
        for src_name, src_data in ds_section.items():
            dont_rules = src_data["learned_rules"].get("dont", [])
            if dont_rules:
                suggested_actions.append({
                    "reason": (
                        f"'{src_name}' has {len(dont_rules)} don't rule(s) from live sessions. "
                        f"Consider updating canonicalization_rules or examples to bake these insights "
                        f"into the template config so they work even when LEARNINGS_ENABLED=false."
                    ),
                    "call": (
                        f"configure_data_source(template_id='{template_id}', name='{src_name}', "
                        f"canonicalization_rules='...<incorporate dont rules>...')"
                    ),
                })
            if src_data["examples_count"] > 0 and not src_data["learned_rules"].get("do") and not src_data["learned_rules"].get("dont"):
                suggested_actions.append({
                    "reason": (
                        f"'{src_name}' has accumulated {src_data['examples_count']} resolved examples "
                        f"but no synthesized rules yet. Consider running a test interview with intentional "
                        f"failures to surface don't rules that can be acted on."
                    ),
                    "call": f"test_data_source(template_id='{template_id}', source_name='{src_name}', params={{\"search\": \"<ambiguous phrase>\"}})",
                })

        for wh in webhook_outputs:
            dont_rules = wh["learned_rules"].get("dont", [])
            if dont_rules:
                suggested_actions.append({
                    "reason": (
                        f"Webhook output {wh['index']} ({wh['url']}) has {len(dont_rules)} don't rule(s). "
                        f"Review the rules and consider updating the goal schema or webhook config "
                        f"to prevent these payload errors at the source."
                    ),
                    "call": (
                        f"set_goal_schema(template_id='{template_id}', goal_id='<goal_id>', "
                        f"schema={{...updated to prevent known payload errors...}})"
                    ),
                })

        # Build human-readable summary
        template_name = template.get("name", "Unknown Template")
        summary_lines = [f"# Runtime Learnings — {template_name}\n"]

        if ds_section:
            summary_lines.append("## Data Sources\n")
            for src_name, src_data in ds_section.items():
                summary_lines.append(f"### {src_name}")
                summary_lines.append(f"- Examples accumulated: {src_data['examples_count']}")
                if src_data["recent_example_phrases"]:
                    summary_lines.append(f"- Recent phrases: {', '.join(repr(p) for p in src_data['recent_example_phrases'])}")
                do_rules = src_data["learned_rules"].get("do", [])
                dont_rules = src_data["learned_rules"].get("dont", [])
                if do_rules:
                    summary_lines.append("- DO rules:")
                    for r in do_rules:
                        summary_lines.append(f"  ✓ {r}")
                if dont_rules:
                    summary_lines.append("- DON'T rules:")
                    for r in dont_rules:
                        summary_lines.append(f"  ✗ {r}")
                if not do_rules and not dont_rules:
                    summary_lines.append("- No rules synthesized yet")
                summary_lines.append("")

        if webhook_outputs:
            summary_lines.append("## Webhook Outputs\n")
            for wh in webhook_outputs:
                summary_lines.append(f"### Output {wh['index']}: {wh['url']}")
                do_rules = wh["learned_rules"].get("do", [])
                dont_rules = wh["learned_rules"].get("dont", [])
                if do_rules:
                    summary_lines.append("- DO rules:")
                    for r in do_rules:
                        summary_lines.append(f"  ✓ {r}")
                if dont_rules:
                    summary_lines.append("- DON'T rules:")
                    for r in dont_rules:
                        summary_lines.append(f"  ✗ {r}")
                if not do_rules and not dont_rules:
                    summary_lines.append("- No rules synthesized yet")
                summary_lines.append("")

        if not ds_section and not webhook_outputs:
            summary_lines.append("No data sources or webhook outputs configured.\n")
        elif not any(
            src["examples_count"] > 0 or src["learned_rules"].get("do") or src["learned_rules"].get("dont")
            for src in ds_section.values()
        ) and not any(
            wh["learned_rules"].get("do") or wh["learned_rules"].get("dont")
            for wh in webhook_outputs
        ):
            summary_lines.append("_No learnings accumulated yet. Run live interviews to build up the knowledge base._\n")

        return json.dumps({
            "summary": "\n".join(summary_lines),
            "data_sources": ds_section,
            "webhook_outputs": webhook_outputs,
            "suggested_actions": suggested_actions,
        }, indent=2, default=str)

    @mcp.tool()
    async def clear_runtime_learnings(
        template_id: str,
        scope: str = "all",
    ) -> str:
        """Clear accumulated runtime learnings for a template.

        Use this when you've made structural changes to the template (new data source
        config, fixed endpoint params, updated schema) and want to start fresh so
        stale rules from the old config don't contaminate future sessions.

        IMPORTANT: This only clears the learnings column — it does NOT clear the
        'examples' list inside settings.data_sources. To clear accumulated examples
        you must update the template settings directly via update_template.

        Args:
            template_id: UUID of the template
            scope: What to clear. One of:
              "all" — clear all learnings (data sources + webhook outputs)
              "data_sources" — clear only data source rules
              "webhooks" — clear only webhook output rules
              "<source_name>" — clear rules for a specific data source by name
        """
        template = await client.get_template(template_id)
        learnings = template.get("learnings") or {}
        if isinstance(learnings, str):
            try:
                learnings = json.loads(learnings)
            except Exception:
                learnings = {}

        if scope == "all":
            learnings = {}
            cleared = "all learnings"
        elif scope == "data_sources":
            learnings.pop("data_sources", None)
            cleared = "all data source learnings"
        elif scope == "webhooks":
            learnings.pop("outputs", None)
            cleared = "all webhook output learnings"
        else:
            # Treat scope as a specific data source name
            ds_section = learnings.get("data_sources", {})
            if scope in ds_section:
                del ds_section[scope]
                learnings["data_sources"] = ds_section
                cleared = f"learnings for data source '{scope}'"
            else:
                return json.dumps({
                    "status": "not_found",
                    "message": f"No learnings found for scope '{scope}'. Known data sources: {list(ds_section.keys())}",
                }, indent=2)

        result = await client.update_template(template_id, {"learnings": learnings})
        return json.dumps({
            "status": "ok",
            "cleared": cleared,
            "template_id": template_id,
        }, indent=2)

    @mcp.tool()
    async def create_template(
        name: str,
        description: str = "",
        goals: list | str = "[]",
        settings: dict | str = "{}",
    ) -> str:
        """Create a new interview template programmatically.

        For complex templates, consider using create_template_interactive instead —
        it opens a voice conversation with the AI setup assistant that builds the
        template for you.

        Args:
            name: Template name (e.g. "Customer Onboarding Interview")
            description: Internal description (not shown during interviews)
            goals: Array of goal objects, or JSON string. Use get_template_schema to see valid goal types and fields.
            settings: Settings object, or JSON string. Use get_template_schema to see valid fields.
        """
        data = {
            "name": name,
            "description": description,
            "goals": json.loads(goals) if isinstance(goals, str) else goals,
            "settings": json.loads(settings) if isinstance(settings, str) else settings,
        }
        result = await client.create_template(data)
        return json.dumps(result, indent=2, default=str)

    @mcp.tool()
    async def update_template(
        template_id: str,
        name: str | None = None,
        description: str | None = None,
        goals: list | str | None = None,
        settings: dict | str | None = None,
        status: str | None = None,
    ) -> str:
        """Update an existing template's fields.

        Only provided fields are updated — omitted fields stay unchanged.

        Args:
            template_id: UUID of the template to update
            name: New template name
            description: New description
            goals: New goals array (or JSON string) — replaces all existing goals
            settings: New settings object (or JSON string) — replaces all settings
            status: "active" or "archived"
        """
        data = {}
        if name is not None:
            data["name"] = name
        if description is not None:
            data["description"] = description
        if goals is not None:
            data["goals"] = json.loads(goals) if isinstance(goals, str) else goals
        if settings is not None:
            data["settings"] = json.loads(settings) if isinstance(settings, str) else settings
        if status is not None:
            data["status"] = status
        result = await client.update_template(template_id, data)
        return json.dumps(result, indent=2, default=str)

    @mcp.tool()
    async def create_template_interactive(context: str = "") -> str:
        """Create a template by having a voice conversation with the Roxels AI setup assistant.

        This opens your browser to a voice interview where the AI asks you about
        what you want to build — who you'll interview, what data to collect, what
        tone to use, etc. When the conversation finishes, the template is
        automatically created.

        This is the recommended way to create templates. It's faster and produces
        better results than filling in fields manually.

        This tool will block until the interview is complete (up to 30 minutes).

        Args:
            context: Optional hint for the setup assistant about what you want to build
                     (e.g. "customer satisfaction survey for a logistics company")
        """
        session = await client.start_setup_assistant()
        join_url = session["join_url"]
        interview_id = str(session["interview_id"])

        _validate_join_url(join_url)
        webbrowser.open(join_url)

        timeout = 30 * 60  # 30 minutes
        poll_interval = 5
        elapsed = 0

        while elapsed < timeout:
            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

            interview = await client.get_interview(interview_id)
            interview_status = interview.get("status", "")

            if interview_status == "completed":
                ctx = interview.get("context", {})
                created_template_id = ctx.get("created_template_id")

                if created_template_id:
                    template = await client.get_template(str(created_template_id))
                    return json.dumps(
                        {
                            "status": "completed",
                            "template_id": str(created_template_id),
                            "template": template,
                            "interview_id": interview_id,
                        },
                        indent=2,
                        default=str,
                    )
                else:
                    return json.dumps(
                        {
                            "status": "completed",
                            "error": "Interview completed but no template was created. Check interview results.",
                            "interview_id": interview_id,
                        },
                        indent=2,
                        default=str,
                    )

            if interview_status == "processing_failed":
                return json.dumps(
                    {
                        "status": "processing_failed",
                        "error": "Interview processing failed. You can try create_template to build one programmatically.",
                        "interview_id": interview_id,
                    },
                    indent=2,
                    default=str,
                )

        return json.dumps(
            {
                "status": "timeout",
                "message": f"Setup interview was not completed within {timeout // 60} minutes. "
                f"You can rejoin at: {join_url}",
                "interview_id": interview_id,
                "join_url": join_url,
            },
            indent=2,
            default=str,
        )

    @mcp.tool()
    async def modify_template_interactive(template_id: str) -> str:
        """Modify an existing template by having a voice conversation with the AI.

        Opens your browser to a conversation where you can describe what you want
        to change. The AI knows the current template configuration and will update
        it based on your instructions.

        This tool will block until the conversation is complete (up to 30 minutes).

        Args:
            template_id: UUID of the template to modify
        """
        session = await client.start_modify_assistant(template_id)
        join_url = session["join_url"]
        interview_id = str(session["interview_id"])

        _validate_join_url(join_url)
        webbrowser.open(join_url)

        timeout = 30 * 60
        poll_interval = 5
        elapsed = 0

        while elapsed < timeout:
            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

            interview = await client.get_interview(interview_id)
            interview_status = interview.get("status", "")

            if interview_status == "completed":
                template = await client.get_template(template_id)
                return json.dumps(
                    {
                        "status": "completed",
                        "template_id": template_id,
                        "template": template,
                        "interview_id": interview_id,
                    },
                    indent=2,
                    default=str,
                )

            if interview_status == "processing_failed":
                return json.dumps(
                    {
                        "status": "processing_failed",
                        "error": "Modification failed. You can use update_template to make changes programmatically.",
                        "interview_id": interview_id,
                    },
                    indent=2,
                    default=str,
                )

        return json.dumps(
            {
                "status": "timeout",
                "message": f"Modify session was not completed within {timeout // 60} minutes. "
                f"You can rejoin at: {join_url}",
                "interview_id": interview_id,
                "join_url": join_url,
            },
            indent=2,
            default=str,
        )

    # ── Group B: Interview Operations ──

    @mcp.tool()
    async def list_interviews(
        template_id: str | None = None,
        person_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> str:
        """List interviews with optional filters.

        Args:
            template_id: Filter by template UUID
            person_id: Filter by person UUID
            status: Filter by status — "not_started", "in_progress", "processing", "completed", "processing_failed"
            limit: Max results (1-200, default 50)
            offset: Pagination offset
        """
        interviews = await client.list_interviews(
            template_id=template_id,
            person_id=person_id,
            status=status,
            limit=limit,
            offset=offset,
        )
        return json.dumps(interviews, indent=2, default=str)

    @mcp.tool()
    async def get_interview(interview_id: str) -> str:
        """Get full interview results including summary, structured findings, outputs, transcript, and attached files.

        Args:
            interview_id: UUID of the interview
        """
        interview = await client.get_interview(interview_id)
        return json.dumps(interview, indent=2, default=str)

    @mcp.tool()
    async def list_persons() -> str:
        """List all persons (interviewees) in your organization."""
        persons = await client.list_persons()
        return json.dumps(persons, indent=2, default=str)

    @mcp.tool()
    async def create_person(
        name: str,
        email: str | None = None,
        phone: str | None = None,
        metadata: dict | str = "{}",
    ) -> str:
        """Create a person record. Persons are the people being interviewed.

        Args:
            name: Full name
            email: Email address (used for deduplication)
            phone: Phone number
            metadata: Arbitrary key-value metadata (object or JSON string)
        """
        data: dict = {"name": name, "metadata": json.loads(metadata) if isinstance(metadata, str) else metadata}
        if email is not None:
            data["email"] = email
        if phone is not None:
            data["phone"] = phone
        result = await client.create_person(data)
        return json.dumps(result, indent=2, default=str)

    # ── Group C: Integration Setup ──

    @mcp.tool()
    async def configure_output(
        template_id: str,
        output_type: str,
        config: dict | str,
        replace: bool = True,
    ) -> str:
        """Add or replace an output configuration on a template.

        Outputs define what happens with interview data — webhooks, structured
        extraction, reports, emails, or Excel files. Use get_template_schema to
        see the config fields for each output type.

        Args:
            template_id: UUID of the template
            output_type: One of: "webhook", "structured", "report", "email", "excel"
            config: Output config object (or JSON string). For webhook: {url, headers, schema, streaming, trigger_goal}. For structured: {schema}.
            replace: If true (default), replaces any existing output of the same type. If false, adds alongside existing outputs.
        """
        template = await client.get_template(template_id)
        settings = template.get("settings", {})
        outputs = settings.get("outputs", [])

        new_output = {"type": output_type, "config": json.loads(config) if isinstance(config, str) else config}

        if replace:
            outputs = [o for o in outputs if o.get("type") != output_type]

        outputs.append(new_output)
        settings["outputs"] = outputs

        result = await client.update_template(template_id, {"settings": settings})
        return json.dumps(
            {
                "status": "configured",
                "template_id": template_id,
                "output_type": output_type,
                "total_outputs": len(outputs),
                "template": result,
            },
            indent=2,
            default=str,
        )

    @mcp.tool()
    async def patch_output(
        template_id: str,
        trigger_goal: str | None = None,
        url: str | None = None,
        headers: dict | str | None = None,
        schema: dict | str | None = None,
        streaming: bool | None = None,
        raw_payload: bool | None = None,
        goal_id: str | None = None,
        output_type: str = "webhook",
    ) -> str:
        """Update specific fields on an existing webhook output, leaving all other fields unchanged.

        Unlike configure_output (which replaces the entire output config), this tool merges
        only the provided fields into the existing output's config. Use this for incremental
        changes like updating a URL or adding a schema without reconstructing the full config.

        The output to update is identified by trigger_goal (for per-goal streaming webhooks)
        or output_type (for end-of-session outputs without a trigger_goal).

        Args:
            template_id: UUID of the template
            trigger_goal: The trigger_goal value that identifies the output to patch (use for streaming webhooks)
            url: New webhook URL (optional)
            headers: Updated headers dict (optional)
            schema: Updated extraction schema (optional)
            streaming: Updated streaming flag (optional)
            raw_payload: Updated raw_payload flag (optional)
            goal_id: Updated goal_id for data routing (optional)
            output_type: Output type to match when trigger_goal is not set (default: "webhook")
        """
        template = await client.get_template(template_id)
        settings = template.get("settings", {})
        outputs = settings.get("outputs", [])

        # Find the target output
        if trigger_goal is not None:
            target = next(
                (o for o in outputs if o.get("config", {}).get("trigger_goal") == trigger_goal),
                None,
            )
            identifier = f"trigger_goal='{trigger_goal}'"
        else:
            target = next(
                (o for o in outputs if o.get("type") == output_type and not o.get("config", {}).get("trigger_goal")),
                None,
            )
            identifier = f"output_type='{output_type}' (end-of-session)"

        if target is None:
            return json.dumps({
                "status": "error",
                "error": f"No output matching {identifier} found on template '{template_id}'. "
                         f"Use get_template to see configured outputs, or configure_output to create a new one.",
            }, indent=2)

        # Merge only the provided (non-None) fields into the existing config
        updated_config = dict(target.get("config", {}))
        if url is not None:
            updated_config["url"] = url
        if headers is not None:
            updated_config["headers"] = json.loads(headers) if isinstance(headers, str) else headers
        if schema is not None:
            updated_config["schema"] = json.loads(schema) if isinstance(schema, str) else schema
        if streaming is not None:
            updated_config["streaming"] = streaming
        if raw_payload is not None:
            updated_config["raw_payload"] = raw_payload
        if goal_id is not None:
            updated_config["goal_id"] = goal_id

        updated_output = {**target, "config": updated_config}
        outputs = [o for o in outputs if o is not target]
        outputs.append(updated_output)
        settings["outputs"] = outputs

        await client.update_template(template_id, {"settings": settings})

        return json.dumps({
            "status": "patched",
            "template_id": template_id,
            "identified_by": identifier,
            "updated_fields": [
                k for k, v in {
                    "url": url,
                    "headers": headers,
                    "schema": schema,
                    "streaming": streaming,
                    "raw_payload": raw_payload,
                    "goal_id": goal_id,
                }.items() if v is not None
            ],
            "output": updated_output,
        }, indent=2, default=str)

    @mcp.tool()
    async def get_embed_config() -> str:
        """Get the complete Roxels embed widget configuration reference.

        Returns the JS SDK URL, init/open options, available form factors,
        callbacks, and security notes. Use this to understand what the widget
        supports before generating embed code.
        """
        return json.dumps(EMBED_CONFIG_REFERENCE, indent=2)

    @mcp.tool()
    async def create_embed_key(
        template_id: str, allowed_domains: list | str = "[]"
    ) -> str:
        """Generate a publishable embed key for a template.

        Embed keys (rk_ prefix) are safe for client-side use. They're scoped to
        a single template and can only create interview sessions.

        Args:
            template_id: UUID of the template
            allowed_domains: Array of domains (or JSON string) — e.g. ["myapp.com", "staging.myapp.com"]. Empty array allows all domains.
        """
        domains = json.loads(allowed_domains) if isinstance(allowed_domains, str) else allowed_domains
        result = await client.create_embed_key(template_id, domains)
        return json.dumps(result, indent=2, default=str)

    @mcp.tool()
    async def list_embed_keys(template_id: str) -> str:
        """List all embed keys for a template, showing their IDs, allowed domains, and revocation status.

        Args:
            template_id: UUID of the template
        """
        keys = await client.list_embed_keys(template_id)
        return json.dumps(keys, indent=2, default=str)

    @mcp.tool()
    async def revoke_embed_key(key_id: str) -> str:
        """Revoke an embed key so it can no longer be used to create sessions.

        Args:
            key_id: UUID of the embed key (not the rk_ key itself — get the ID from list_embed_keys)
        """
        result = await client.revoke_embed_key(key_id)
        return json.dumps(result, indent=2, default=str)

    @mcp.tool()
    async def get_embed_code(
        template_key: str,
        mode: str = "modal",
        person_name: str = "Guest",
        redirect_url: str = "",
    ) -> str:
        """Generate a ready-to-paste HTML/JS snippet for embedding the Roxels interview widget.

        Args:
            template_key: The embed key (rk_...) — get one from create_embed_key
            mode: "modal" (centered dialog) or "compact" (floating corner panel)
            person_name: Default person name shown to the AI
            redirect_url: URL to navigate to after interview completes (e.g. "/thank-you"). If empty, stays on current page.
        """
        redirect_part = f", redirectUrl: '{redirect_url}'" if redirect_url else ""
        snippet = textwrap.dedent(f"""\
            <!-- Roxels Interview Widget -->
            <script src="{EMBED_JS_URL}"></script>
            <script>
              Roxels.init({{
                templateKey: "{template_key}",
                onUnderstanding: function(data) {{
                  // Real-time structured data — fires each conversation turn
                  console.log("Roxels extracted:", data);
                }},
                onComplete: function(results) {{
                  // Full results after interview processing
                  console.log("Roxels complete:", results);
                }},
                onError: function(err) {{
                  console.error("Roxels error:", err);
                }},
              }});
            </script>

            <button onclick="Roxels.open({{ mode: '{mode}', personName: '{person_name}'{redirect_part} }})">
              Start Interview
            </button>""")

        return json.dumps(
            {
                "snippet": snippet,
                "instructions": "Add the snippet to your HTML page. The button opens the interview widget. "
                "Customize the onUnderstanding callback to handle real-time data, and onComplete for final results. "
                "For React/Next.js, put the script tag in a useEffect and call Roxels.open() from your button handler.",
                "sdk_url": EMBED_JS_URL,
                "template_key": template_key,
            },
            indent=2,
        )

    @mcp.tool()
    async def get_data_source_schema() -> str:
        """Get the complete reference for configuring data sources and resolved_reference fields.

        Data sources let the agent look up structured records from your external APIs
        during the interview, so your webhook receives typed objects instead of raw strings.

        Classic problem this solves:
          Without data sources: user says "Acme Corp"  →  webhook gets "Acme Corp"
          With data sources:    user says "Acme Corp"  →  webhook gets {"accountId": 4712, "name": "Acme Corporation", "tier": "enterprise"}

        When to use:
          - Your webhook needs a structured object (an ID, a typed record) rather than a string
          - That object lives in an external database too large to pass as session context
          - Users refer to entries by name or natural language rather than exact IDs

        Common use cases: customer/account lookups, product catalog searches, any canonical
        entity your system stores that users name naturally.

        NOT needed for: plain strings, booleans, numbers, or small enum lists.
        For small lists, pass them as session context instead — it's simpler.

        Returns field definitions, auth options, output template format, dynamic param syntax,
        common mistakes, setup steps, and a full working example.
        """
        return json.dumps(DATA_SOURCE_REFERENCE, indent=2)

    @mcp.tool()
    async def get_validation_schema() -> str:
        """Get the complete reference for Layer 2 validation rules: require_resolved, required_before_commit, commit_policy, and invariants.

        Validation rules are template-level hard constraints that block a commit from firing if
        the extracted data doesn't meet the rules. They are opt-in and additive — a template
        without any rules behaves exactly as before.

        WHY THESE MATTER:
          Without rules: a resolved_reference field can commit as a plain string when resolution fails.
          With rules: the commit is blocked and the agent asks the user to clarify before saving.

          Without rules: a commit fires even if a required field is missing.
          With rules: the commit is held until all required fields are present.

        USE THIS TOOL when:
          - Setting up a template that writes to an external system (webhooks)
          - Any goal schema has resolved_reference fields
          - The downstream API has cross-field requirements (e.g. category and product type must agree)

        Returns VALIDATION_REFERENCE with worked examples and the full MCP setup flow.
        """
        return json.dumps(VALIDATION_REFERENCE, indent=2)

    @mcp.tool()
    async def set_goal_commit_rules(
        template_id: str,
        goal_id: str,
        commit_policy: str | None = None,
        invariants: list | str | None = None,
    ) -> str:
        """Set commit_policy and invariants on a goal (Layer 2 validation rules).

        commit_policy controls when the commit fires:
          'auto'                — default. Commits fire automatically after extraction.
          'require_all_required' — auto-commits fire only when all required_before_commit fields
                                  are satisfied.
          'human_confirm'       — auto-commits suppressed. Commit fires only after explicit user
                                  confirmation via the propose → confirm flow.

        invariants are cross-field rules using the shape-match DSL:
          [{\"when\": {\"field.path\": value}, \"then\": {\"other.path\": expected_value}}]
          If the 'when' subset matches the committed snapshot, the 'then' subset must also match.
          If it doesn't, the commit is blocked and the agent asks the user to fix it.

        Example invariant — category and product type must agree:
          [{\"when\": {\"item.category\": \"hardware\"}, \"then\": {\"item.product.type\": \"hardware\"}}]

        This does NOT replace the goal's schema. It adds goal-level policy alongside the schema.
        To set field-level rules (require_resolved, required_before_commit), use set_goal_schema.

        Args:
            template_id: UUID of the template
            goal_id: The 'id' field of the goal
            commit_policy: 'auto', 'require_all_required', or 'human_confirm'. Omit to leave unchanged.
            invariants: List of {when, then} dicts (or JSON string). Omit to leave unchanged.
        """
        template = await client.get_template(template_id)
        goals = template.get("goals", [])

        target = next((g for g in goals if g.get("id") == goal_id), None)
        if target is None:
            available = [g.get("id") for g in goals if g.get("id")]
            return json.dumps(
                {
                    "status": "not_found",
                    "goal_id": goal_id,
                    "available_goal_ids": available,
                    "hint": "Use list_templates or get_template to see goal IDs.",
                },
                indent=2,
            )

        if commit_policy is not None:
            target["commit_policy"] = commit_policy
        if invariants is not None:
            target["invariants"] = json.loads(invariants) if isinstance(invariants, str) else invariants

        result = await client.update_template(template_id, {"goals": goals})
        return json.dumps(
            {
                "status": "updated",
                "template_id": template_id,
                "goal_id": goal_id,
                "commit_policy": target.get("commit_policy"),
                "invariants": target.get("invariants"),
                "template": result,
            },
            indent=2,
            default=str,
        )

    @mcp.tool()
    async def guided_setup_questions(template_id: str) -> str:
        """Analyze a template and return a reliability checklist with recommended actions.

        Reads the template's current goals, schemas, and data sources, then returns a
        structured list of questions/recommendations for making the template reliable.

        A coding agent should read the recommendations, answer them using knowledge of the
        client's codebase and API contracts, then call the suggested tools to apply the answers.

        Use this AFTER configure_data_source + set_goal_schema and BEFORE running an interview.
        It surfaces missing Layer 1 (knowledge) and Layer 2 (validation) rules.

        Args:
            template_id: UUID of the template to analyze
        """
        template = await client.get_template(template_id)
        goals = template.get("goals", [])
        settings = template.get("settings", {})
        data_sources = settings.get("data_sources", [])
        outputs = settings.get("outputs", [])

        all_gaps: list[dict] = []

        for ds in data_sources:
            all_gaps.extend(_interrogate_source(ds, template_id))

        for goal in goals:
            if goal.get("id") and goal.get("schema"):
                all_gaps.extend(_interrogate_schema(goal, template_id, data_sources))

        # extraction_mode check: for any goal that has a trigger_goal webhook pointing at it
        # and no extraction_mode set, ask whether the endpoint is replace-all or delta.
        goals_with_streaming_webhook = {
            o.get("config", {}).get("trigger_goal")
            for o in outputs
            if o.get("type") == "webhook" and o.get("config", {}).get("trigger_goal")
        }
        for goal in goals:
            gid = goal.get("id")
            if gid and gid in goals_with_streaming_webhook and not goal.get("extraction_mode"):
                all_gaps.append({
                    "severity": "MEDIUM",
                    "field": f"goal '{gid}' → extraction_mode",
                    "problem": (
                        f"Goal '{gid}' has a streaming webhook (trigger_goal) but extraction_mode is not set. "
                        f"If the receiving endpoint replaces all existing records before saving, each webhook "
                        f"only delivers the delta from that turn — previous data is silently wiped."
                    ),
                    "answer_this": (
                        f"Does the endpoint receiving the '{gid}' webhook replace all existing records "
                        f"for this entity before saving (replace-all/upsert), or does it append/merge new "
                        f"data into existing records (delta)? "
                        f"If it replaces: set extraction_mode='cumulative' so each webhook fires a complete "
                        f"snapshot. If it merges: leave extraction_mode unset."
                    ),
                    "then_call": (
                        f"update_template(template_id='{template_id}', "
                        f"goals=[{{...existing goal '{gid}' fields..., 'extraction_mode': 'cumulative'}}]) "
                        f"— only if your endpoint is replace-all."
                    ),
                })

        if not all_gaps:
            return json.dumps({
                "status": "healthy",
                "message": (
                    "This template has no open reliability gaps. "
                    "All data sources and goal schemas look well-configured. "
                    "Consider running validate_template_data_sources as a final structural check."
                ),
                "template_id": template_id,
            }, indent=2)

        high = [g for g in all_gaps if g["severity"] == "HIGH"]
        medium = [g for g in all_gaps if g["severity"] == "MEDIUM"]

        return json.dumps({
            "status": "gaps_found",
            "template_id": template_id,
            "summary": (
                f"Found {len(high)} HIGH and {len(medium)} MEDIUM reliability gaps. "
                f"HIGH gaps mean commits can fire with corrupt or missing data. "
                f"Please work through each gap below: read 'answer_this', answer it using your "
                f"knowledge of the client's codebase and API, then call the tool in 'then_call' "
                f"with your answer. Start with HIGH severity."
            ),
            "how_to_proceed": (
                "For each gap: (1) read 'problem' to understand the risk, "
                "(2) read 'answer_this' — this is the specific question you need to answer "
                "from your codebase knowledge, (3) call 'then_call' with your answer. "
                "You have all the information needed to answer these — they refer to your "
                "API contracts, endpoint behavior, and field requirements."
            ),
            "gaps": all_gaps,
        }, indent=2, default=str)

    @mcp.tool()
    async def configure_data_source(
        template_id: str,
        name: str,
        endpoint_url: str,
        description: str = "",
        auth_type: str | None = None,
        auth_token: str | None = None,
        output_template: dict | str | None = None,
        default_params: dict | str | None = None,
        examples: list | str | None = None,
        canonicalization_rules: str | None = None,
        cache_key_fields: list | str | None = None,
        relaxable_params: list | str | None = None,
    ) -> str:
        """Add or update a data source on a template.

        A data source is an external HTTP GET endpoint the agent calls in real time to
        resolve a user's free-text phrase into a structured object from your database.
        The agent extracts what the user said as a plain string; the data source turns
        it into a typed record with IDs that your webhook backend can consume directly.

        IMPORTANT — two steps are required:
          1. Call configure_data_source to register the endpoint (this step)
          2. Call set_goal_schema to mark which fields trigger this lookup
             (fields must use type="resolved_reference", not a text description)

        The lookup is triggered ONLY by fields explicitly typed as "resolved_reference"
        in the goal schema. Putting "resolve via <source_name>" in a field description
        does nothing — the type must be set.

        RELIABILITY — include these Layer 1 knowledge fields for consistent resolution:
          - description: plain-English summary of what the endpoint contains and what terms work
          - examples: few-shot phrase→result pairs so the agent generates better queries
          - canonicalization_rules: tiebreaker rules when multiple candidates match
          - cache_key_fields: param names (e.g. ["category"]) whose values must be part of the
            cache key — prevents stale resolution when a sibling param changes
          - relaxable_params: narrowing filter param names (e.g. ["category", "type"]) that are safe
            to drop on a 0-results retry — enables the agent's automatic recovery cascade without
            asking the user to rephrase. NEVER include tenancy params (account_id, org_id) here.

        Auth:
          - Use auth_type="bearer" with auth_token for Bearer token auth
          - auth_token supports {{context.fieldName}} interpolation from per-session context

        Output template:
          - output_template is a TRANSFORMATION MAP, not a schema description
          - Use "<fieldName>" as a placeholder filled from the API result
          - Example: {"recordId": "<id>", "label": "<name>", "category": "product"}
          - If omitted, the raw API result object is passed through unchanged

        Args:
            template_id: UUID of the template
            name: Unique identifier for this data source (referenced by field specs via data_source="name")
            endpoint_url: GET endpoint URL. Supports {{context.fieldName}} interpolation.
            description: What the endpoint contains and what search terms it accepts. Used in query generation.
            auth_type: Auth type — "bearer" is the only supported type
            auth_token: Token value for bearer auth. Supports {{context.fieldName}} interpolation.
            output_template: Transformation map (object or JSON string). Omit to pass raw result.
            default_params: Default query params merged into every request (or JSON string).
            examples: Few-shot list of {phrase, expected_result} dicts (or JSON string).
                      Used in query generation and candidate evaluation prompts.
                      Example: [{"phrase": "Acme", "expected_result": {"id": 42, "name": "Acme Corporation"}}]
            canonicalization_rules: Plain-English tiebreaker rules when candidates are ambiguous.
                      Injected into the candidate evaluation prompt.
                      Example: "When multiple records match, prefer the one whose type matches the category param."
            cache_key_fields: List of default_params keys (or JSON string) to include in the
                      phrase-level cache key. Required when a sibling param (e.g. "category") changes
                      which object is returned for the same phrase.
                      Example: ["category"]
            relaxable_params: List of default_params keys (or JSON string) that are safe to drop
                      on a 0-results retry. When a lookup returns nothing, the agent's recovery
                      cascade re-runs the request without these params to widen the search. Only
                      list narrowing filter params (e.g. "type", "category") — NEVER include
                      tenancy or isolation params (account_id, org_id, etc.) that guard
                      data boundaries between customers.
                      Example: ["category"]
        """
        template = await client.get_template(template_id)
        settings = template.get("settings", {})
        data_sources = settings.get("data_sources", [])

        # Build data source definition
        source_def: dict = {
            "name": name,
            "endpoint": {
                "url": endpoint_url,
                "method": "GET",
            },
        }
        if description:
            source_def["description"] = description

        if auth_type:
            source_def["endpoint"]["auth"] = {"type": auth_type}
            if auth_token:
                source_def["endpoint"]["auth"]["token"] = auth_token

        if output_template is not None:
            parsed_template = json.loads(output_template) if isinstance(output_template, str) else output_template
            source_def["output_schema"] = {"template": parsed_template}

        if default_params is not None:
            source_def["default_params"] = json.loads(default_params) if isinstance(default_params, str) else default_params

        if examples is not None:
            source_def["examples"] = json.loads(examples) if isinstance(examples, str) else examples

        if canonicalization_rules:
            source_def["canonicalization_rules"] = canonicalization_rules

        if cache_key_fields is not None:
            source_def["cache_key_fields"] = json.loads(cache_key_fields) if isinstance(cache_key_fields, str) else cache_key_fields

        if relaxable_params is not None:
            source_def["relaxable_params"] = json.loads(relaxable_params) if isinstance(relaxable_params, str) else relaxable_params

        # Replace existing source with same name, or append
        data_sources = [s for s in data_sources if s.get("name") != name]
        data_sources.append(source_def)
        settings["data_sources"] = data_sources

        result = await client.update_template(template_id, {"settings": settings})

        # Run diagnosis on the source we just saved
        saved_source = next((s for s in data_sources if s.get("name") == name), source_def)
        gaps = _interrogate_source(saved_source, template_id)
        high_gaps = [g for g in gaps if g["severity"] == "HIGH"]
        med_gaps = [g for g in gaps if g["severity"] == "MEDIUM"]

        response: dict = {
            "status": "configured",
            "template_id": template_id,
            "data_source_name": name,
        }

        if gaps:
            response["reliability_diagnosis"] = {
                "summary": (
                    f"Data source '{name}' was saved, but {len(high_gaps)} high-priority and "
                    f"{len(med_gaps)} medium-priority reliability gaps were found. "
                    f"Please answer each question below and call the suggested tool with your answer "
                    f"before running an interview — these gaps are the leading cause of semi-consistent behavior."
                ),
                "gaps": gaps,
            }
        else:
            response["reliability_diagnosis"] = {
                "summary": f"Data source '{name}' looks well-configured. Proceed to set_goal_schema.",
            }

        response["next_steps"] = [
            {
                "step": 1,
                "action": "test_data_source",
                "required": True,
                "why": (
                    "Data sources have high setup entropy — auth tokens, URL patterns, required params, "
                    "and response shapes all vary. A misconfigured source fails silently during interviews "
                    "(the agent gets no results and cannot resolve locations/IDs). "
                    "Verify it works before wiring it into a schema."
                ),
                "call": (
                    f"test_data_source(template_id='{template_id}', source_name='{name}', "
                    f"params={{\"search\": \"<a real example value>\"}}"
                    + (", context={\"<context_key>\": \"<value>\"}" if "{{context." in endpoint_url + (auth_token or "") else "")
                    + ")"
                ),
                "success_criteria": "status_code=200 and result_count > 0 and template_applied_to_first_result looks correct",
            },
            {
                "step": 2,
                "action": "set_goal_schema",
                "required": True,
                "why": f"Wire '{name}' into a goal by adding resolved_reference fields pointing to it.",
                "note": "Include require_resolved: true on each field so commits are blocked if resolution fails.",
            },
        ]
        return json.dumps(response, indent=2, default=str)

    @mcp.tool()
    async def list_data_sources(template_id: str) -> str:
        """List all data sources configured on a template.

        Data sources are external lookup endpoints used to resolve user phrases
        (e.g. "Acme Corp") into structured objects (e.g. {accountId: 4712}) at extraction time.

        Use this to see what's configured before adding resolved_reference fields
        to a goal schema, or to verify a configure_data_source call worked.

        Args:
            template_id: UUID of the template
        """
        template = await client.get_template(template_id)
        settings = template.get("settings", {})
        data_sources = settings.get("data_sources", [])
        return json.dumps(
            {
                "template_id": template_id,
                "count": len(data_sources),
                "data_sources": data_sources,
                "hint": "Use configure_data_source to add/update sources. Use patch_data_source to update specific fields on an existing source without touching the rest. Use set_goal_schema to add resolved_reference fields that reference these sources.",
            },
            indent=2,
            default=str,
        )

    @mcp.tool()
    async def patch_data_source(
        template_id: str,
        source_name: str,
        description: str | None = None,
        examples: list | str | None = None,
        canonicalization_rules: list | None = None,
        cache_key_fields: list | str | None = None,
        relaxable_params: list | str | None = None,
        output_template: dict | str | None = None,
        default_params: dict | str | None = None,
    ) -> str:
        """Update specific fields on an existing data source, leaving all other fields unchanged.

        Unlike configure_data_source (which replaces the entire data source definition),
        this tool merges only the provided fields into the existing source. Use this for
        incremental changes like adding relaxable_params or updating examples without
        having to reconstruct the full source config.

        Args:
            template_id: UUID of the template
            source_name: Name of the existing data source to update
            description: Plain-English description of what the endpoint contains (optional)
            examples: Few-shot examples list [{phrase, expected_result}] (optional)
            canonicalization_rules: List of canonical form rules (optional)
            cache_key_fields: List of param names to include in the cache key (optional)
            relaxable_params: List of param names that can be dropped on retry (optional)
            output_template: Transformation map {webhookField: "<apiResultField>"} (optional)
            default_params: Default query params dict (optional)
        """
        template = await client.get_template(template_id)
        settings = template.get("settings", {})
        data_sources = settings.get("data_sources", [])

        existing = next((s for s in data_sources if s.get("name") == source_name), None)
        if existing is None:
            return json.dumps({
                "status": "error",
                "error": f"Data source '{source_name}' not found on template '{template_id}'. "
                         f"Use list_data_sources to see configured sources, or configure_data_source to create a new one.",
            }, indent=2)

        # Merge only the provided (non-None) fields
        updated = dict(existing)
        if description is not None:
            updated["description"] = description
        if examples is not None:
            updated["examples"] = json.loads(examples) if isinstance(examples, str) else examples
        if canonicalization_rules is not None:
            updated["canonicalization_rules"] = canonicalization_rules
        if cache_key_fields is not None:
            updated["cache_key_fields"] = json.loads(cache_key_fields) if isinstance(cache_key_fields, str) else cache_key_fields
        if relaxable_params is not None:
            updated["relaxable_params"] = json.loads(relaxable_params) if isinstance(relaxable_params, str) else relaxable_params
        if output_template is not None:
            parsed = json.loads(output_template) if isinstance(output_template, str) else output_template
            updated["output_schema"] = {**updated.get("output_schema", {}), "template": parsed}
        if default_params is not None:
            parsed_params = json.loads(default_params) if isinstance(default_params, str) else default_params
            updated["default_params"] = parsed_params

        data_sources = [s for s in data_sources if s.get("name") != source_name]
        data_sources.append(updated)
        settings["data_sources"] = data_sources

        await client.update_template(template_id, {"settings": settings})

        return json.dumps({
            "status": "patched",
            "template_id": template_id,
            "data_source_name": source_name,
            "updated_fields": [
                k for k, v in {
                    "description": description,
                    "examples": examples,
                    "canonicalization_rules": canonicalization_rules,
                    "cache_key_fields": cache_key_fields,
                    "relaxable_params": relaxable_params,
                    "output_template": output_template,
                    "default_params": default_params,
                }.items() if v is not None
            ],
            "source": updated,
        }, indent=2, default=str)

    @mcp.tool()
    async def test_data_source(
        template_id: str,
        source_name: str,
        params: dict | str = "{}",
        context: dict | str = "{}",
    ) -> str:
        """Call a configured data source endpoint directly and return the raw response.

        Use this to verify auth, URL, query params, and response shape before
        running a full interview. Much faster than burning a session to find out
        whether your endpoint returns the right structure.

        What it does:
          1. Loads the data source config from the template
          2. Interpolates any {{context.X}} placeholders using the context you provide
          3. Makes the GET request with your params
          4. Returns the raw response + shows what the output_schema template would
             produce when applied to the first result

        If the endpoint returns an unexpected shape (e.g. grouped instead of flat array),
        you'll see it here before it causes silent failures in a live interview.

        Args:
            template_id: UUID of the template
            source_name: Name of the data source to test (as set in configure_data_source)
            params: Query params to send (object or JSON string), e.g. {"search": "Acme Corp"}
            context: Session context values for {{context.X}} interpolation (object or JSON string),
                     e.g. {"authToken": "your-token-here"}
        """
        import httpx
        import re
        import time

        template = await client.get_template(template_id)
        settings = template.get("settings", {})
        data_sources = settings.get("data_sources", [])

        source_def = next((s for s in data_sources if s.get("name") == source_name), None)
        if not source_def:
            available = [s.get("name") for s in data_sources]
            return json.dumps(
                {"error": f"Data source '{source_name}' not found", "available_sources": available},
                indent=2,
            )

        parsed_params = json.loads(params) if isinstance(params, str) else params
        parsed_context = json.loads(context) if isinstance(context, str) else context

        endpoint = source_def.get("endpoint", {})
        url = endpoint.get("url", "")
        auth = endpoint.get("auth", {})

        # Interpolate {{context.X}} placeholders
        for key, val in parsed_context.items():
            url = url.replace(f"{{{{context.{key}}}}}", str(val))

        headers = {}
        # Support endpoint.headers (direct header map)
        for hk, hv in endpoint.get("headers", {}).items():
            for key, val in parsed_context.items():
                hv = hv.replace(f"{{{{context.{key}}}}}", str(val))
            headers[hk] = hv
        # Support endpoint.auth.type=bearer (alternative auth pattern)
        if auth.get("type") == "bearer":
            token = auth.get("token", "")
            for key, val in parsed_context.items():
                token = token.replace(f"{{{{context.{key}}}}}", str(val))
            headers["Authorization"] = f"Bearer {token}"

        unresolved = re.findall(r"\{\{context\.\w+\}\}", url + " ".join(headers.values()))

        start = time.time()
        try:
            async with httpx.AsyncClient(timeout=10) as http:
                resp = await http.get(url, params=parsed_params, headers=headers)
                elapsed_ms = int((time.time() - start) * 1000)
                raw_result = resp.json()
        except Exception as e:
            return json.dumps(
                {"error": str(e), "error_type": type(e).__name__, "url": url, "params": parsed_params},
                indent=2,
                default=str,
            )

        # Apply output_schema template to first result as a preview
        output_template = source_def.get("output_schema", {}).get("template")
        template_preview = None
        template_note = None
        if output_template:
            first = raw_result[0] if isinstance(raw_result, list) and raw_result else (raw_result if isinstance(raw_result, dict) else None)
            if first:
                out = {}
                for k, v in output_template.items():
                    if isinstance(v, str) and v.startswith("<") and v.endswith(">"):
                        path = v[1:-1].split(".")
                        val = first
                        for part in path:
                            val = val.get(part) if isinstance(val, dict) else None
                        out[k] = val
                    else:
                        out[k] = v
                template_preview = out
                if any(v is None for v in out.values()):
                    template_note = "Some template placeholders resolved to null — check that your API result keys match the template."
            else:
                template_note = "Could not apply template — response is not a non-empty array or object."

        result_count = len(raw_result) if isinstance(raw_result, list) else "object"
        is_success = resp.status_code == 200 and isinstance(raw_result, list) and len(raw_result) > 0
        template_ok = is_success and (template_preview is not None) and not template_note if output_template else True

        verified = is_success and template_ok and not unresolved

        result = {
            "status_code": resp.status_code,
            "url": str(resp.url),
            "elapsed_ms": elapsed_ms,
            "result_count": result_count,
            "raw_response_preview": raw_result[:3] if isinstance(raw_result, list) else raw_result,
            "template_applied_to_first_result": template_preview,
            "verification_status": "verified" if verified else "failed",
        }
        if template_note:
            result["template_warning"] = template_note
        if unresolved:
            result["unresolved_placeholders"] = unresolved
            result["hint"] = "Pass context={{...}} with the missing keys to resolve these placeholders."

        if not verified:
            reasons = []
            if resp.status_code != 200:
                reasons.append(f"HTTP {resp.status_code} (expected 200)")
            elif not isinstance(raw_result, list):
                reasons.append("response is not a list — endpoint must return a flat array")
            elif len(raw_result) == 0:
                reasons.append("result_count=0 — endpoint returned no matches for the given params")
            if template_note:
                reasons.append(f"output_schema issue: {template_note}")
            if unresolved:
                reasons.append(f"unresolved context placeholders: {unresolved}")
            result["verification_failure_reasons"] = reasons
            result["next_step"] = (
                "Fix the issues above and call test_data_source again. "
                "Do not proceed to set_goal_schema until verification_status='verified'."
            )

        # Persist test result back to the template so the verification state is visible
        # in list_data_sources, validate_template_data_sources, and future configure calls.
        import datetime as _dt
        _last_tested = {
            "timestamp": _dt.datetime.utcnow().isoformat() + "Z",
            "params": parsed_params,
            "status_code": resp.status_code,
            "result_count": result_count,
            "verified": verified,
        }
        try:
            _tmpl = await client.get_template(template_id)
            _settings = _tmpl.get("settings", {})
            _sources = _settings.get("data_sources", [])
            for _s in _sources:
                if _s.get("name") == source_name:
                    _s["_last_tested"] = _last_tested
                    break
            _settings["data_sources"] = _sources
            await client.update_template(template_id, {"settings": _settings})
        except Exception:
            pass  # Don't fail the test response if the persist fails

        # Record learning from this test (fire-and-forget — errors are silently swallowed)
        _search_phrase = parsed_params.get("search") or parsed_params.get("q") or parsed_params.get("query")
        if _search_phrase:
            try:
                if verified and template_preview:
                    # Success: teach the expected result for this phrase
                    await client.record_learning(template_id, {
                        "type": "data_source",
                        "source_name": source_name,
                        "phrase": str(_search_phrase),
                        "success": True,
                        "result": template_preview,
                    })
                elif isinstance(raw_result, list) and len(raw_result) == 0:
                    # 0-result failure: synthesize a don't rule from this test
                    await client.record_learning(template_id, {
                        "type": "data_source",
                        "source_name": source_name,
                        "phrase": str(_search_phrase),
                        "success": False,
                        "queries_tried": [parsed_params],
                    })
            except Exception:
                pass  # Never let learning errors affect the test response

        if verified:
            result["next_step"] = (
                "Verification passed. Proceed to set_goal_schema to wire this source into your goal fields."
            )

        return json.dumps(result, indent=2, default=str)

    @mcp.tool()
    async def remove_data_source(template_id: str, source_name: str) -> str:
        """Remove a data source from a template by name.

        This removes the data source definition from settings.data_sources.
        Any goal schema fields that reference this source (type='resolved_reference',
        data_source='source_name') will stop resolving and fall back to raw strings.

        Args:
            template_id: UUID of the template
            source_name: The name of the data source to remove (as set in configure_data_source)
        """
        template = await client.get_template(template_id)
        settings = template.get("settings", {})
        data_sources = settings.get("data_sources", [])

        before = len(data_sources)
        data_sources = [s for s in data_sources if s.get("name") != source_name]
        settings["data_sources"] = data_sources

        if len(data_sources) == before:
            return json.dumps(
                {"status": "not_found", "source_name": source_name, "template_id": template_id},
                indent=2,
            )

        result = await client.update_template(template_id, {"settings": settings})
        return json.dumps(
            {
                "status": "removed",
                "source_name": source_name,
                "template_id": template_id,
                "remaining_data_sources": len(data_sources),
                "template": result,
            },
            indent=2,
            default=str,
        )

    @mcp.tool()
    async def set_goal_schema(
        template_id: str,
        goal_id: str,
        schema: dict | str,
    ) -> str:
        """Set or replace the extraction schema for a specific goal.

        The schema maps field names to types or field spec objects. Simple:
            {"company_name": "string", "headcount": "number", "active": "boolean"}

        For arrays of plain strings:
            {"tags": "array of strings"}

        For arrays of objects, use item_schema to define the shape of each item:
            {
              "items": {
                "type": "array",
                "item_schema": {
                  "product_name": "string",
                  "quantity": "number"
                }
              }
            }

        For fields that require a live lookup against an external API, use
        type='resolved_reference'. This REPLACES the user's free-text phrase with
        the structured object your data source returns. You MUST have a matching
        entry in settings.data_sources (configure it first with configure_data_source).

        IMPORTANT: The lookup is triggered ONLY by fields explicitly typed as
        'resolved_reference'. Using a text description like "resolve via my_source"
        on a string field does nothing — the type must be set.

        Single resolved_reference field:
            {
              "account_id": {
                "type": "resolved_reference",
                "data_source": "my_source",
                "default_params": {"type": "account"}
              }
            }

        Dynamic params — reference a sibling field's extracted value using {fieldName}:
            {
              "category": "string",
              "product": {
                "type": "resolved_reference",
                "data_source": "my_source",
                "default_params": {"type": "{category}"}
              }
            }
        The agent extracts category (e.g. "electronics"), then calls my_source?type=electronics&search=...
        Any string sibling field in the same object can be referenced this way.

        Array of objects where each item has a resolved_reference field:
            {
              "line_items": {
                "type": "array",
                "item_schema": {
                  "category": "string",
                  "product": {
                    "type": "resolved_reference",
                    "data_source": "my_source",
                    "default_params": {"type": "{category}"}
                  },
                  "quantity": "number"
                }
              }
            }
        category is a sibling within each array item — each product lookup gets the
        category the agent extracted for that specific item.

        Flat array of resolved objects — use item_type: "resolved_reference" when your
        webhook needs [{id, label}, ...] directly (not [{fieldName: {id, label}}, ...]):
            {
              "category": "string",
              "items": {
                "type": "array",
                "item_type": "resolved_reference",
                "data_source": "my_source",
                "default_params": {"type": "{category}"}
              }
            }
        {category} resolves from the PARENT object (sibling of "items"), not from inside
        each item string. All items share the same param from their parent context.
        The output template on the data source can use <$params.type> to include the
        request param in the resolved object — useful when the API doesn't echo it back.

        See get_data_source_schema for the full resolved_reference reference.

        Args:
            template_id: UUID of the template
            goal_id: The 'id' field of the goal to update
            schema: Extraction schema object (or JSON string). Maps field names to types
                    or field spec objects. Replaces the goal's current schema.
        """
        template = await client.get_template(template_id)
        goals = template.get("goals", [])

        parsed_schema = json.loads(schema) if isinstance(schema, str) else schema

        target = next((g for g in goals if g.get("id") == goal_id), None)
        if target is None:
            available = [g.get("id") for g in goals if g.get("id")]
            return json.dumps(
                {
                    "status": "not_found",
                    "goal_id": goal_id,
                    "available_goal_ids": available,
                    "hint": "Use list_templates or get_template to see goal IDs.",
                },
                indent=2,
            )

        target["schema"] = parsed_schema

        result = await client.update_template(template_id, {"goals": goals})

        # Run diagnosis on the updated goal
        settings = template.get("settings", {})
        data_sources = settings.get("data_sources", [])
        gaps = _interrogate_schema(target, template_id, data_sources)
        high_gaps = [g for g in gaps if g["severity"] == "HIGH"]
        med_gaps = [g for g in gaps if g["severity"] == "MEDIUM"]

        response: dict = {
            "status": "updated",
            "template_id": template_id,
            "goal_id": goal_id,
            "schema_field_count": len(parsed_schema),
        }

        if gaps:
            response["reliability_diagnosis"] = {
                "summary": (
                    f"Schema for goal '{goal_id}' was saved, but {len(high_gaps)} high-priority and "
                    f"{len(med_gaps)} medium-priority reliability gaps were found. "
                    f"Each gap below includes the reason it matters and a specific question — please "
                    f"answer each one and apply the suggested call before running an interview."
                ),
                "gaps": gaps,
            }
            if high_gaps:
                response["reliability_diagnosis"]["blocking_note"] = (
                    "HIGH severity gaps mean commits can fire with corrupt or missing data reaching "
                    "your endpoint. Please address these first."
                )
        else:
            response["reliability_diagnosis"] = {
                "summary": f"Goal '{goal_id}' schema looks well-configured. Consider calling validate_template_data_sources as a final check.",
            }

        return json.dumps(response, indent=2, default=str)

    @mcp.tool()
    async def validate_template_data_sources(template_id: str) -> str:
        """Check a template's data source configuration for common errors before running an interview.

        Catches misconfigurations that silently prevent data source resolution:
          1. Goal schema fields referencing a data_source name that isn't registered
          2. Goal schema fields typed 'resolved_reference' inside arrays, but nested under
             'items' instead of 'item_schema' (a common schema structure mistake)
          3. Data sources registered in settings but no goal schema field uses them
             (the data source exists but is never triggered)
          4. output_schema.template values that look like JSON Schema descriptions
             (e.g. {"type": "array", "description": "..."}) instead of transformation maps
             (e.g. {"myField": "<api_result_key>"}) — the wrong form is silently ignored
          5. default_params {fieldName} placeholders that reference nonexistent sibling fields

        Use this after configure_data_source + set_goal_schema and before running a
        live interview. Also run it to diagnose why a data source isn't triggering.

        Structural checks are delegated to the backend validate endpoint so they stay
        in sync with PATCH validation. Runtime checks (DS testing status, suggestions)
        are performed here.

        Args:
            template_id: UUID of the template
        """
        # --- Structural violations from the backend (single source of truth) ---
        validate_result = await client.validate_template(template_id)
        structural_violations = validate_result.get("violations") or []

        errors = [v for v in structural_violations if v.get("rule") != "ds_items_vs_item_schema"]
        warnings = [
            {
                "goal_id": v.get("goal_id"),
                "field": v.get("field"),
                "warning": v["message"],
                "detail": (
                    "Change 'items' to 'item_schema' so the resolution code finds these fields."
                ),
            }
            for v in structural_violations
            if v.get("rule") == "ds_items_vs_item_schema"
        ]

        # Also fetch template for runtime checks (DS testing status, suggestions)
        template = await client.get_template(template_id)
        settings = template.get("settings", {})
        goals = template.get("goals", [])
        data_sources = settings.get("data_sources", [])
        registered_source_names = {s.get("name") for s in data_sources if s.get("name")}

        # Derive which sources are triggered by goal schemas (for unused-source check)
        triggered_sources: set[str] = set()
        for v in structural_violations:
            if v.get("rule") in ("ds_unknown_data_source",):
                pass  # reference exists but target doesn't — not triggered
        # Re-walk goals to find triggered sources (structural violations already caught bad refs)
        def _find_triggered(schema_obj: dict) -> None:
            if not isinstance(schema_obj, dict):
                return
            for fspec in schema_obj.values():
                if not isinstance(fspec, dict):
                    continue
                ftype = fspec.get("type")
                if ftype == "resolved_reference":
                    src = fspec.get("data_source")
                    if src and src in registered_source_names:
                        triggered_sources.add(src)
                elif ftype == "array":
                    if fspec.get("item_type") == "resolved_reference":
                        src = fspec.get("data_source")
                        if src and src in registered_source_names:
                            triggered_sources.add(src)
                    item = fspec.get("item_schema") or fspec.get("items") or {}
                    if isinstance(item, dict):
                        if item.get("type") == "resolved_reference":
                            src = item.get("data_source")
                            if src and src in registered_source_names:
                                triggered_sources.add(src)
                        else:
                            _find_triggered(item)
                elif "type" not in fspec or fspec.get("type") == "object":
                    _find_triggered(fspec)

        for goal in goals:
            schema_obj = goal.get("schema") or {}
            _find_triggered(schema_obj)

        # --- Check for registered sources with no goal field referencing them ---
        unused_sources = registered_source_names - triggered_sources
        for src_name in sorted(unused_sources):
            warnings.append({
                "source": src_name,
                "warning": "Data source is registered but no goal schema field references it",
                "detail": "No goal has a field with type='resolved_reference' and data_source='" + src_name + "'. "
                          "The source will never be called. Either add a resolved_reference field or remove the source.",
            })

        # --- Check for sources that have never been tested or whose last test failed ---
        for src in data_sources:
            src_name = src.get("name", "<unnamed>")
            last_tested = src.get("_last_tested")
            if not last_tested:
                warnings.append({
                    "source": src_name,
                    "warning": "Data source has never been tested",
                    "detail": (
                        "Call test_data_source to verify auth, params, and response shape before running interviews. "
                        "Untested sources commonly fail silently — the agent gets no results and cannot resolve values."
                    ),
                    "fix": f"test_data_source(template_id='{template_id}', source_name='{src_name}', params={{\"search\": \"<example value>\"}})",
                })
            elif not last_tested.get("verified"):
                warnings.append({
                    "source": src_name,
                    "warning": "Last test did not pass verification",
                    "detail": (
                        f"Tested at {last_tested.get('timestamp', '?')} — "
                        f"status_code={last_tested.get('status_code')}, "
                        f"result_count={last_tested.get('result_count')}, verified=False. "
                        "Fix the endpoint config and re-run test_data_source until verification_status='verified'."
                    ),
                    "last_tested_params": last_tested.get("params"),
                    "fix": f"test_data_source(template_id='{template_id}', source_name='{src_name}', params={{\"search\": \"<example value>\"}})",
                })

        # --- Suggestions: reliability improvements that aren't errors but reduce failure rate ---
        suggestions = []
        for src in data_sources:
            src_name = src.get("name", "<unnamed>")
            default_params = src.get("default_params", {})
            # Narrowing filter params: static values that aren't context injections
            static_narrowing = [
                k for k, v in default_params.items()
                if isinstance(v, str) and not v.startswith("{{context.")
            ]
            if static_narrowing and not src.get("relaxable_params"):
                suggestions.append({
                    "source": src_name,
                    "suggestion": "Consider declaring relaxable_params",
                    "detail": (
                        f"'{src_name}' has narrowing filter params {static_narrowing} but no relaxable_params set. "
                        f"When a lookup returns 0 results, the agent's recovery cascade can automatically drop "
                        f"these params and retry — catching cases where the extraction model picked the wrong "
                        f"filter value. Without relaxable_params the cascade skips straight to world-knowledge "
                        f"fallback (or silent skip), even if the entity exists in the database under a different "
                        f"filter value."
                    ),
                    "answer_this": (
                        f"Which of {static_narrowing} are safe to drop on a retry? "
                        f"A param is safe if omitting it broadens the search without leaking data across "
                        f"tenancy boundaries. Narrowing filters (type, category, tier) are usually safe. "
                        f"Tenancy guards (account_id, org_id) are NEVER safe."
                    ),
                    "fix": (
                        f"configure_data_source(template_id='{template_id}', name='{src_name}', "
                        f"relaxable_params=[\"<safe_narrowing_param>\"])"
                    ),
                })

        # --- Detect filter-narrower fields: schema fields that drive a lookup filter via {fieldname} ---
        # These fields classify an entity before the lookup runs — a wrong classification sends the
        # lookup to the wrong DB slice and returns 0 results. The agent's extraction prompt now
        # includes world-knowledge guidance for these fields, and the recovery cascade can sweep
        # other known values of the param. Examples in the data source make both smarter.
        def _collect_narrowers(node: dict, found: set) -> None:
            """Collect filter-narrower field names from a schema node."""
            if not isinstance(node, dict):
                return
            for fdef in node.values():
                if not isinstance(fdef, dict):
                    continue
                if fdef.get("type") == "resolved_reference":
                    for pv in fdef.get("default_params", {}).values():
                        if isinstance(pv, str):
                            for m in re.findall(r"\{(\w+)\}", pv):
                                found.add(m)
                elif fdef.get("type") == "array":
                    isc = fdef.get("item_schema") or fdef.get("items") or {}
                    if isinstance(isc, dict):
                        if isc.get("type") == "resolved_reference":
                            for pv in isc.get("default_params", {}).values():
                                if isinstance(pv, str):
                                    for m in re.findall(r"\{(\w+)\}", pv):
                                        found.add(m)
                        else:
                            _collect_narrowers(isc, found)
                elif "type" not in fdef or fdef.get("type") == "object":
                    _collect_narrowers(fdef, found)

        for goal in goals:
            goal_id = goal.get("id", "<no_id>")
            schema_obj = goal.get("schema") or {}

            narrowers: set[str] = set()
            _collect_narrowers(schema_obj, narrowers)

            for narrower in sorted(narrowers):
                # Check which data sources this goal uses and whether they have examples with the param
                for src in data_sources:
                    src_name = src.get("name", "<unnamed>")
                    src_examples = src.get("examples", [])
                    examples_with_param = [ex for ex in src_examples if narrower in ex]
                    if not examples_with_param:
                        suggestions.append({
                            "goal_id": goal_id,
                            "source": src_name,
                            "suggestion": f"Add examples that include '{narrower}' for better classification and enum-sweep recovery",
                            "detail": (
                                f"The goal schema has a filter-narrower field '{narrower}' — its value is passed as "
                                f"a '{{{narrower}}}' parameter to the '{src_name}' lookup. "
                                f"When the extraction model classifies '{narrower}' incorrectly, the lookup queries "
                                f"the wrong database slice and returns 0 results for real entities. "
                                f"Two mechanisms help avoid this:\n"
                                f"  1. The agent's extraction prompt now warns the LLM to use world knowledge "
                                f"     instead of generic defaults for filter-narrower fields.\n"
                                f"  2. The agent's recovery cascade can sweep other known values of '{narrower}' "
                                f"     in parallel when the initial lookup returns 0 — but only if it knows "
                                f"     what values to try, which it learns from examples.\n"
                                f"Without examples that include '{narrower}', mechanism 2 is disabled for "
                                f"this source — the cascade falls back to dropping the param entirely "
                                f"(which widens the search but may return irrelevant results)."
                            ),
                            "answer_this": (
                                f"What are the valid values for '{narrower}' on '{src_name}'? "
                                f"For each value, what is a representative phrase a user might say, "
                                f"and what does the expected result look like? "
                                f"Three to five examples with different '{narrower}' values is ideal."
                            ),
                            "example_format": {
                                "phrase": "<what a user would say>",
                                narrower: "<the correct filter value for this phrase>",
                                "expected_result": {"<key>": "<value>"},
                            },
                            "fix": (
                                f"configure_data_source(template_id='{template_id}', name='{src_name}', "
                                f"examples=[{{\"phrase\": \"...\", \"{narrower}\": \"<value>\", "
                                f"\"expected_result\": {{...}}}}])"
                            ),
                        })

        # --- Check for unacted-upon learned rules (from runtime learnings) ---
        learnings = template.get("learnings") or {}
        if isinstance(learnings, str):
            try:
                learnings = json.loads(learnings)
            except Exception:
                learnings = {}
        ds_learnings = learnings.get("data_sources", {})
        for src_name_lr, src_lr in ds_learnings.items():
            dont_rules = src_lr.get("_learned_rules", {}).get("dont", [])
            if dont_rules:
                suggestions.append({
                    "source": src_name_lr,
                    "suggestion": f"{len(dont_rules)} learned 'don't' rule(s) from live sessions not yet acted on",
                    "detail": (
                        f"'{src_name_lr}' has accumulated don't rules from real interview failures. "
                        f"These rules are automatically injected into future sessions (when LEARNINGS_ENABLED=true), "
                        f"but they represent failure modes that could be eliminated by updating the template config."
                    ),
                    "learned_dont_rules": dont_rules,
                    "fix": f"get_runtime_learnings(template_id='{template_id}') — then act on suggested_actions",
                })

        if not errors and not warnings and not suggestions:
            return json.dumps({
                "status": "ok",
                "message": "No issues found. Data source configuration looks correct.",
                "data_sources_registered": sorted(registered_source_names),
                "sources_triggered_by_goals": sorted(triggered_sources),
            }, indent=2)

        result: dict = {
            "status": "issues_found" if (errors or warnings) else "ok_with_suggestions",
            "error_count": len(errors),
            "warning_count": len(warnings),
            "suggestion_count": len(suggestions),
        }
        if errors:
            result["errors"] = errors
        if warnings:
            result["warnings"] = warnings
        if suggestions:
            result["suggestions"] = suggestions
        result["hint"] = (
            "Fix all errors before running an interview — errors silently prevent resolution. "
            "Warnings indicate likely misconfiguration. "
            "Suggestions are optional improvements that reduce the failure rate of data source resolution."
        )
        return json.dumps(result, indent=2, default=str)

    @mcp.tool()
    async def test_output(
        template_id: str,
        output_index: int = 0,
    ) -> str:
        """Test a configured output by firing it with realistic sample data.

        For webhooks: generates sample data matching the schema, POSTs to the URL,
        and returns the HTTP status + response body. Use this to verify your webhook
        endpoint works without running a full interview.

        For structured outputs: returns sample extracted data matching the schema.

        Args:
            template_id: UUID of the template
            output_index: Which output to test (0-based index in settings.outputs array). Default: 0.
        """
        result = await client.test_output(template_id, output_index)
        return json.dumps(result, indent=2, default=str)

    # ── Group D: Utilities ──

    @mcp.tool()
    async def get_template_schema() -> str:
        """Get the complete schema reference for creating and configuring templates.

        Returns all valid goal types, goal fields, settings fields, and output
        type configurations. Use this to understand what values are valid before
        calling create_template, update_template, or configure_output.
        """
        return json.dumps(TEMPLATE_SCHEMA_REFERENCE, indent=2)

    @mcp.tool()
    async def whoami() -> str:
        """Check that your API key is valid, see basic org info, and verify MCP version.

        Use this to verify your Roxels connection is working and check which version you're running.
        """
        from importlib.metadata import version as pkg_version
        try:
            mcp_version = pkg_version("roxels-mcp")
        except Exception:
            mcp_version = "unknown"
        result = await client.whoami()
        result["mcp_version"] = mcp_version
        return json.dumps(result, indent=2)

    return mcp
