import os
import subprocess
import time
import pandas as pd
import numpy as np
import pytest
from SharedData.Logger import Logger
from SharedData.IO.ClientAPI import ClientAPI

SERVER_HOST = "localhost"
SERVER_PORT = 8082
SERVER_URL = f"http://{SERVER_HOST}:{SERVER_PORT}"
SOURCE_FOLDER = os.environ["SOURCE_FOLDER"]
WAITRESS_LAUNCH = [
    f"{SOURCE_FOLDER}/SharedData/venv/bin/python",
    "-m", "SharedData.IO.ServerAPI",
    "--host", SERVER_HOST,
    "--port", str(SERVER_PORT)
]

@pytest.fixture(scope="session", autouse=True)
def run_test_server():
    """Start/stop the ServerAPI process for this test session."""
    Logger.connect(__file__)
    print("🚀 Starting ServerAPI subprocess for BIG table test...")
    proc = subprocess.Popen(WAITRESS_LAUNCH)
    try:
        import requests
        timeout = 60
        print("⏳ Waiting for server to respond to heartbeat...")
        for i in range(timeout):
            try:
                r = requests.get(f"{SERVER_URL}/api/heartbeat", timeout=3)
                if r.status_code == 200:
                    print("✅ Server API heartbeat OK!")
                    break
            except Exception as e:
                print(f"Heartbeat {i+1}/{timeout} failed: {e}")
            time.sleep(1)
        else:
            proc.terminate()
            pytest.fail("Server did not start within timeout.")
        yield
    finally:
        print("🛑 Terminating ServerAPI subprocess...")
        proc.terminate()
        proc.wait()
        print("✅ Server process cleaned up.")

def make_large_test_dicts(
    n: int = 1_000_000,
    num_dates: int = 100,
    num_symbols: int = 10_000
) -> list:
    """
    Generate a list of dictionaries with n unique (date, symbol) records.
    Raises ValueError if n > num_dates * num_symbols.
    """
    print(f"📊 Generating dictionary list with {n:,} records ({num_dates} dates x {num_symbols} symbols)...")
    dates = pd.date_range("2024-01-01", periods=num_dates)
    symbols = [f"SYM{i}" for i in range(num_symbols)]
    max_combos = len(dates) * len(symbols)
    if n > max_combos:
        raise ValueError(
            f"Cannot generate {n} unique (date, symbol) combinations. "
            f"Maximum is {max_combos}."
        )
    print("  🎲 Creating random combinations...")
    mesh = np.array(np.meshgrid(dates, symbols, indexing='ij'))
    date_vals = mesh[0].ravel()
    symbol_vals = mesh[1].ravel()
    indices = np.random.choice(max_combos, size=n, replace=False)
    date_vals = date_vals[indices]
    symbol_vals = symbol_vals[indices]
    
    print("  📈 Generating market data values...")
    open_vals = np.random.uniform(10, 5000, size=n).astype(np.float32)
    high_vals = open_vals + np.random.uniform(0, 20, size=n).astype(np.float32)
    low_vals = open_vals - np.random.uniform(0, 20, size=n).astype(np.float32)
    close_vals = open_vals + np.random.uniform(-10, 10, size=n).astype(np.float32)
    vwap_vals = (open_vals + high_vals + low_vals + close_vals) / 4
    volume_vals = np.random.randint(100_000, 2_000_000, size=n, dtype=np.int32)
    
    print("  🏗️ Building dictionary list...")
    records = []
    for i in range(n):
        record = {
            'date': pd.Timestamp(date_vals[i]),
            'symbol': symbol_vals[i],
            'open': float(open_vals[i]),
            'high': float(high_vals[i]),
            'low': float(low_vals[i]),
            'close': float(close_vals[i]),
            'vwap': float(vwap_vals[i]),
            'volume': int(volume_vals[i]),
        }
        records.append(record)
    
    print(f"✅ Dictionary list generation done - {len(records):,} records created.")
    return records

def test_table_roundtrip_big(run_test_server):
    print("\n🧪 Starting BIG Table Roundtrip Test (SCHEMALESS)")
    print("=" * 50)
    
    # 4,000,000 unique rows, exactly as your original script:
    n = 1_000_000
    num_dates = 1000
    num_symbols = 1000
    print(f"📋 Test Parameters: {n:,} records ({num_dates} dates x {num_symbols} symbols)")

    print("📊 Step 1: Creating source dictionary list...")
    records = make_large_test_dicts(n=n, num_dates=num_dates, num_symbols=num_symbols)

    print("🗑️ Step 2: Deleting existing table...")
    status = ClientAPI.delete_table(
        'MarketData', 'D1', 'TEST', 'TEST',
        endpoint=SERVER_URL,
    )
    print(f"✅ Delete status: {status}")

    print("📤 Step 3: Uploading with ClientAPI.post_table (schemaless)...")
    print("  📋 Table specs: schemaless mode, dynamic schema from records")
    ClientAPI.post_table(
        'MarketData', 'D1', 'TEST', 'TEST',
        value=records,
        is_schemaless=True,
        size=1_000_000,
        endpoint=SERVER_URL,
    )
    print("✅ Upload complete.")

    print("📥 Step 4: Downloading with ClientAPI.get_table (schemaless)...")
    response = ClientAPI.get_table(
        'MarketData', 'D1', 'TEST', 'TEST',
        endpoint=SERVER_URL,        
        load_all_pages=True,
        output_dataframe=False,  # Get dict list directly for schemaless tables
    )
    downloaded_records = response
    print("✅ Download complete.")

    print("🔍 Step 5: Checking roundtrip equality...")
    print(f"  📊 Original records: {len(records):,}")
    print(f"  📊 Downloaded records: {len(downloaded_records):,}")
    assert len(records) == len(downloaded_records)
    
    # Sort both lists by date and symbol for comparison
    records_sorted = sorted(records, key=lambda x: (x['date'], x['symbol']))
    downloaded_sorted = sorted(downloaded_records, key=lambda x: (x['date'], x['symbol']))
    
    # Check a sample of records
    print("  🔍 Verifying sample records...")
    for i in range(0, len(records_sorted), len(records_sorted) // 100):  # Check ~100 samples
        orig = records_sorted[i]
        down = downloaded_sorted[i]
        assert orig['date'] == down['date']
        # Handle bytes vs string comparison for symbol
        orig_symbol = orig['symbol']
        down_symbol = down['symbol'].decode('utf-8') if isinstance(down['symbol'], bytes) else down['symbol']
        assert orig_symbol == down_symbol
        assert abs(orig['open'] - down['open']) < 0.01
        assert abs(orig['close'] - down['close']) < 0.01
    print("✅ Roundtrip check passed.")

    print("🗑️ Step 6: Deleting table...")
    status = ClientAPI.delete_table(
        'MarketData', 'D1', 'TEST', 'TEST',
        endpoint=SERVER_URL,
    )
    assert status in (204, 200)
    print(f"✅ Table deleted (status: {status})")

    print("🔄 Step 7: Testing schema changes (removing 'vwap' field)...")
    print("  📤 Creating records without 'vwap' field...")
    records_no_vwap = []
    for rec in records[:100]:  # Use subset for faster testing
        new_rec = {k: v for k, v in rec.items() if k != 'vwap'}
        records_no_vwap.append(new_rec)
    
    ClientAPI.post_table(
        'MarketData', 'D1', 'TEST', 'TEST',
        value=records_no_vwap,
        is_schemaless=True,
        endpoint=SERVER_URL,
    )
    print("✅ Re-upload complete")

    print("  📥 Downloading and checking fields...")
    downloaded_no_vwap = ClientAPI.get_table(
        'MarketData', 'D1', 'TEST', 'TEST',    
        endpoint=SERVER_URL,        
        load_all_pages=True,
        output_dataframe=False,  # Get dict list directly for schemaless tables
    )

    assert len(downloaded_no_vwap) > 0
    assert 'vwap' not in downloaded_no_vwap[0]
    print("✅ Confirmed 'vwap' field not in downloaded data")

    # Verify other fields match
    for i, orig in enumerate(records_no_vwap[:10]):  # Sample check
        down = downloaded_no_vwap[i]
        for key in ['date', 'symbol', 'open', 'close']:
            if key in orig and key in down:
                orig_val = orig[key]
                down_val = down[key]
                # Decode bytes if necessary
                if isinstance(down_val, bytes):
                    down_val = down_val.decode('utf-8')
                # Compare values
                if key in ['open', 'close']:
                    assert abs(float(orig_val) - float(down_val)) < 0.01
                else:
                    assert orig_val == down_val
    print("✅ Non-vwap fields match correctly")

    print("📈 Step 8: Testing dynamic schema with new fields...")
    print("  📤 Adding new fields to records...")
    records_extended = []
    for i, rec in enumerate(records[:100]):
        new_rec = rec.copy()
        new_rec['trades'] = int(np.random.randint(100, 10000))
        new_rec['bid'] = float(rec['close'] - np.random.uniform(0, 1))
        new_rec['ask'] = float(rec['close'] + np.random.uniform(0, 1))
        records_extended.append(new_rec)
    
    ClientAPI.post_table(
        'MarketData', 'D1', 'TEST', 'TEST',
        value=records_extended,
        is_schemaless=True,
        endpoint=SERVER_URL,
    )
    print("✅ Upload with new fields complete")

    print("  🔍 Checking table metadata...")
    head = ClientAPI.head_table(
        'MarketData', 'D1', 'TEST', 'TEST',
        endpoint=SERVER_URL,
    )

    for key in head:
        print(f'  📊 {key}: {head[key]}')
    
    print("  📥 Verifying new fields in downloaded data...")
    downloaded_extended = ClientAPI.get_table(
        'MarketData', 'D1', 'TEST', 'TEST',
        endpoint=SERVER_URL,        
        load_all_pages=True,
        output_dataframe=False,  # Get dict list directly for schemaless tables
    )
    
    assert len(downloaded_extended) > 0
    first_rec = downloaded_extended[0]
    assert 'trades' in first_rec
    assert 'bid' in first_rec
    assert 'ask' in first_rec
    print("✅ New fields successfully stored and retrieved")
    
    print("\n🎉 BIG TABLE TEST COMPLETE (SCHEMALESS)! 🎉")
    print("=" * 50)