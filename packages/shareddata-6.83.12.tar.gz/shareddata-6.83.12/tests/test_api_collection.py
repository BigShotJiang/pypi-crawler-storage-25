import os
import subprocess
import time
import pandas as pd
import numpy as np
import pytest
from SharedData.Logger import Logger
from SharedData.IO.ClientAPI import ClientAPI

SERVER_HOST = "localhost"
SERVER_PORT = 8082
SERVER_URL = f"http://{SERVER_HOST}:{SERVER_PORT}"
SOURCE_FOLDER = os.environ["SOURCE_FOLDER"]
WAITRESS_LAUNCH = [
    f"{SOURCE_FOLDER}/SharedData/venv/bin/python",
    "-m", "SharedData.IO.ServerAPI",
    "--host", SERVER_HOST,
    "--port", str(SERVER_PORT)
]

@pytest.fixture(scope="session", autouse=True)
def run_test_server():
    """Start/stop the ServerAPI process for this test session."""
    Logger.connect(__file__)
    print("🚀 Starting ServerAPI subprocess for collection test...")
    proc = subprocess.Popen(WAITRESS_LAUNCH)
    try:
        import requests
        timeout = 60
        print("⏳ Waiting for server to respond to heartbeat...")
        for i in range(timeout):
            try:
                r = requests.get(f"{SERVER_URL}/api/heartbeat", timeout=3)
                if r.status_code == 200:
                    print("✅ Server API heartbeat OK!")
                    break
            except Exception as e:
                print(f"Heartbeat {i+1}/{timeout} failed: {e}")
            time.sleep(1)
        else:
            proc.terminate()
            pytest.fail("Server did not start within timeout.")
        yield
    finally:
        print("🛑 Terminating ServerAPI subprocess...")
        proc.terminate()
        proc.wait()
        print("✅ Server process cleaned up.")

@pytest.fixture
def sample_df() -> pd.DataFrame:
    """Fixture to generate test DataFrame."""
    print("📊 Creating sample DataFrame with 365 days of AAPL data...")
    df = pd.DataFrame({
        'date': pd.date_range('2024-07-01', periods=365, freq='D'),
        'portfolio': 'TEST',
        'symbol': 'AAPL',
        'open': 100,
        'high': 105,
        'low': 95,
    }).set_index(['date', 'portfolio', 'symbol'])
    print(f"✅ Sample DataFrame created with {len(df):,} rows")
    return df

def test_delete_collection_filter(sample_df: pd.DataFrame):
    """Test partial deletion via filter on collection using ClientAPI."""
    print("\n🧪 Starting Collection Filter Deletion Test")
    print("=" * 50)
    
    print("🔍 Step 1: Setting up filter query...")
    query = {
        'date': {'$gt': pd.Timestamp('2025-01-01')},
        'portfolio': 'TEST',
    }
    print(f"Query: {query}")

    print("📤 Step 2: Uploading sample data to collection...")
    ClientAPI.post_collection('Positions', 'D1', 'TEST', 'TEST', value=sample_df,
                              endpoint='http://localhost:8082')
    print("✅ Upload complete")

    print("📥 Step 3: Downloading and verifying initial data...")
    _df = ClientAPI.get_collection('Positions', 'D1', 'TEST', 'TEST')
    assert (_df[sample_df.columns] == sample_df).all().all()
    print(f"✅ Initial data verified: {len(_df):,} rows")

    print("🗑️ Step 4: Applying filter deletion (dates > 2025-01-01)...")
    ClientAPI.delete_collection('Positions', 'D1', 'TEST', 'TEST', query=query,
                                endpoint='http://localhost:8082')
    print("✅ Filter deletion complete")

    print("📥 Step 5: Downloading data after filter deletion...")
    _df_after = ClientAPI.get_collection('Positions', 'D1', 'TEST', 'TEST')
    print(f"📊 Rows after deletion: {len(_df_after):,}")

    print("🔍 Step 6: Verifying only correct data remains...")
    # Only dates <= 2025-01-01 should remain
    expected_df = sample_df.loc[:'2025']
    assert (_df_after[sample_df.columns] == expected_df).all().all()
    print(f"✅ Filter deletion verified: {len(expected_df):,} rows remain as expected")

    print("🗑️ Step 7: Deleting entire collection...")
    ClientAPI.delete_collection('Positions', 'D1', 'TEST', 'TEST',
                                endpoint='http://localhost:8082')
    print("✅ Collection deletion complete")

    print("📋 Step 8: Verifying collection is removed from listings...")
    collectionslist = ClientAPI.list_collections('Positions/D1/TEST',
                            endpoint='http://localhost:8082')

    success = collectionslist.empty
    if not success:
        success = 'master/Positions/D1/TEST/collection/TEST' not in collectionslist['path'].values
    print(f"📊 Collections list empty: {collectionslist.empty}")
    assert success
    print("✅ Collection successfully removed from listings")
    
    print("\n🎉 COLLECTION FILTER TEST PASSED! 🎉")
    print("=" * 50)