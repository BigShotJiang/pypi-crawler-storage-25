import numpy as np
import pandas as pd
import pytest
from SharedData.SharedData import SharedData

@pytest.fixture(scope="module")
def tbl():
    shdata = SharedData(__file__, user='master')
    tbl = shdata.table(
        'MarketData', 'D1', 'TEST', 'TEST',
        names=['date', 'symbol', 'open', 'high', 'low', 'close', 'volume'],
        formats=['<M8[ns]', '|S12', '<f8', '<f8', '<f8', '<f8', '<i8'],
        size=100, overwrite=True
    )
    return tbl

@pytest.fixture(scope="module")
def arr(tbl):
    arr = np.full((20,), dtype=tbl.dtype, fill_value=np.nan)
    for i in range(10):
        symbol = 'symbol' + str(i)
        if i % 2 == 0:
            date = np.datetime64(i + 10, 'D')
        else:
            date = np.datetime64(i-1 + 10, 'D')
        arr['date'][i] = date
        arr['symbol'][i] = symbol
        arr['open'][i] = np.random.randn()
        arr['volume'][i] = i

    tbl.upsert(arr[:10])

    for i in range(10, 20):
        symbol = 'symbol' + str(i)
        if i % 2 == 0:
            date = np.datetime64(i - 10, 'D')
        else:
            date = np.datetime64(i-1 -10, 'D')
        arr['date'][i] = date
        arr['symbol'][i] = symbol
        arr['open'][i] = np.random.randn()
        arr['volume'][i] = i

    tbl.upsert(arr[10:20])
    return arr

def test_index_values(tbl, arr):
    expvalue = [11, -1, 13, -1, 15, -1, 17, -1, 19, -1,  1, -1,  3, -1,  5, -1, 7, -1,  9, -1]
    assert (tbl.index.datelastidx[:20] == expvalue).all()

    expvalue = [-1,  0, -1,  2, -1,  4, -1,  6, -1,  8, -1, 10, -1, 12, -1, 14, -1, 16, -1, 18]
    assert (tbl.index.dateprevidx[:20] == expvalue).all()

def test_get_date_loc(tbl):
    loc = tbl.get_date_loc(tbl['date'][-1])
    assert (tbl[loc]['date'] == tbl['date'][-2:]).all()

    date = pd.Timestamp('1970-01-01')
    loc = tbl.get_date_loc(date)
    assert (tbl[loc]['date'] == date).all()

def test_get_date_loc_gte(tbl):
    startdate = pd.Timestamp('1970-01-01')
    loc = tbl.get_date_loc_gte(startdate)
    assert (np.diff(tbl[loc]['date'].astype(int)) >= 0).all()
    assert (tbl[loc]['date'] >= startdate).all()

def test_get_date_loc_lte(tbl):
    enddate = pd.Timestamp('1972-09-27')
    loc = tbl.get_date_loc_lte(enddate)
    assert (np.diff(tbl[loc]['date'].astype(int)) >= 0).all()
    assert (tbl[loc]['date'] <= enddate).all()

def test_get_date_loc_gte_lte(tbl):
    startdate = pd.Timestamp('1970-01-01')
    enddate = pd.Timestamp('1972-09-27')
    loc = tbl.get_date_loc_gte_lte(startdate, enddate)
    assert (np.diff(tbl[loc]['date'].astype(int)) >= 0).all()
    assert (tbl[loc]['date'] >= startdate).all()
    assert (tbl[loc]['date'] <= enddate).all()