import pandas as pd
import numpy as np
import pytest

from SharedData.SharedData import SharedData

@pytest.fixture
def tbl():
    shdata = SharedData(__file__, user='master')
    tbl = shdata.table(
        'MarketData', 'M1', 'TEST', 'TEST/202505',
        names=['date', 'symbol', 'open', 'high', 'low', 'close', 'volume'],
        formats=['<M8[ns]', '|S12', '<f8', '<f8', '<f8', '<f8', '<i8'],
        size=100, overwrite=True
    )
    return tbl

def test_marketdata_table(tbl):
    arr = np.full((20,), dtype=tbl.dtype, fill_value=np.nan)
    for i in range(10):
        if i % 2 == 0:
            arr['date'][i] = np.datetime64('2025-05-01', 'ns') + (10 + i) * np.timedelta64(1, 'm')
        else:
            arr['date'][i] = np.datetime64('2025-05-01', 'ns') + (10 + i - 1) * np.timedelta64(1, 'm')
        arr['symbol'][i] = 'TEST' + str(i)

    tbl.upsert(arr[:10])

    for i in range(10, 20):
        if i % 2 == 0:
            arr['date'][i] = np.datetime64('2025-05-01', 'ns') + (-10 + i) * np.timedelta64(1, 'm')
        else:
            arr['date'][i] = np.datetime64('2025-05-01', 'ns') + (-10 + i - 1) * np.timedelta64(1, 'm')
        arr['symbol'][i] = 'TEST' + str(i)

    tbl.upsert(arr[10:20])

    loc = tbl.get_date_loc(tbl['date'][-1])
    assert (tbl[loc]['date'] == tbl['date'][-2:]).all()

    startdate = pd.Timestamp('2025-05-01 00:02:00')
    enddate = pd.Timestamp('2025-05-01 00:16:00')
    loc = tbl.get_date_loc_gte_lte(startdate, enddate)
    assert len(loc) == 16
    assert (tbl[loc]['date'] >= startdate).all()
    assert (tbl[loc]['date'] <= enddate).all()