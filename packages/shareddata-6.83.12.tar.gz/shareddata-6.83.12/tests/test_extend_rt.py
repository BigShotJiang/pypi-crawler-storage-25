import pandas as pd          # kept, even though it isn’t used – “minimal changes”
import numpy as np

from SharedData.SharedData import SharedData


def test_marketdata_table_extend():
    """
    Re-runs the original script inside a pytest test.
    The only edits are:
      • wrapped everything in this function
      • put the file in a test_*.py file
    """

    shdata = SharedData(__file__, user="master")

    tbl = shdata.table(
        "MarketData",
        "RT",
        "TEST",
        "TEST",
        names=["date", "symbol", "open", "high", "low", "close", "volume"],
        formats=["<M8[ns]", "|S12", "<f8", "<f8", "<f8", "<f8", "<i8"],
        size=0,
        overwrite=True,
        hasindex=False,
    )

    # create 20-row structured array, fill with NaNs
    arr = np.full((20,), dtype=tbl.dtype, fill_value=np.nan)

    # first 10 rows (future-timestamp order)
    for i in range(10):
        if i % 2 == 0:
            arr["date"][i] = (
                np.datetime64("2025-05-01", "ns")
                + (10 + i) * np.timedelta64(1, "m")
                + np.timedelta64(30, "s")
            )
        else:
            arr["date"][i] = (
                np.datetime64("2025-05-01", "ns")
                + (10 + i - 1) * np.timedelta64(1, "m")
                + np.timedelta64(30, "s")
            )
        arr["symbol"][i] = f"TEST{i}"

    tbl = tbl.extend(arr[:10])

    # second 10 rows (earlier-timestamp order)
    for i in range(10, 20):
        if i % 2 == 0:
            arr["date"][i] = (
                np.datetime64("2025-05-01", "ns")
                + (-10 + i) * np.timedelta64(1, "m")
                + np.timedelta64(30, "s")
            )
        else:
            arr["date"][i] = (
                np.datetime64("2025-05-01", "ns")
                + (-10 + i - 1) * np.timedelta64(1, "m")
                + np.timedelta64(30, "s")
            )
        arr["symbol"][i] = f"TEST{i}"

    tbl = tbl.extend(arr[10:20])

    # original assertion – keeps the behaviour identical
    assert len(tbl[:]) == 20
