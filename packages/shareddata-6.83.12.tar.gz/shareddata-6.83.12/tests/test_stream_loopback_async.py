import pytest
import pandas as pd
import time
import asyncio
import random
import multiprocessing
from typing import Any
from SharedData.SharedData import SharedData
from SharedData.Logger import Logger

def make_symbols(n: int) -> list[str]:
    """Generate a list of unique symbol strings."""
    return [f"SYM{i:06d}" for i in range(n)]

async def consumer_task(consumerid,n_msgs) -> None:
    """Async Kafka consumer for the test stream, calculates latency and throughput."""
    shdata = SharedData(__file__, user='master')
    Logger.log.info(f"Starting consumer {consumerid}...")    
    stream = shdata.stream('MarketData', 'RT', 'TEST', 'TEST', 
                           use_aiokafka=True, partitions=2)
    cache = shdata.cache('MarketData', 'RT', 'TEST', 'TEST')    
    groupid = 'test_stream_loopback_async'
    await stream.async_subscribe(groupid=groupid, offset='earliest')
    cache.header_set(f'c{consumerid}->subscribed',1)
    Logger.log.info(f"Consumer {consumerid} started!")
    count = 0
    totalcount = 0
    totaltime_start = None
    mean_latency = 10
    t_start = time.time()
    while True:
        msgs = await stream.async_poll(groupid, timeout=1000)
        for msg in msgs:
            count += 1
            totalcount += 1            
            latency = (time.time_ns() - msg['mtime']) / 1e6
            mean_latency = mean_latency * 0.99 + latency * 0.01
            if totaltime_start is None:
                totaltime_start = time.time()
        
        if time.time() - t_start > 0.2:
            t_start = time.time()
            await cache.async_header_incrby(f'consumer->totalcount',count)
            await cache.async_header_incrby(f'c{consumerid}->count',count)
            cache.header_set(f'c{consumerid}->mean_latency',mean_latency)
            count = 0
            totalcount = int(cache.header_get('consumer->totalcount'))
            if totalcount >= n_msgs:
                break
    
    Logger.log.info(f"Consumer {consumerid} finished")

async def producer_task(producerid, n_msgs) -> None:
    """Async Kafka producer for the test stream."""
    shdata = SharedData(__file__, user='master')
    Logger.log.info(f"Starting producer{producerid}...")    
    stream = shdata.stream('MarketData', 'RT', 'TEST', 'TEST', 
                           use_aiokafka=True, partitions=2)    
    cache = shdata.cache('MarketData', 'RT', 'TEST', 'TEST')        
    num_unique_symbols = min(100_000, n_msgs)
    symbols = make_symbols(num_unique_symbols)
    count = 0
    t_start = time.time()
    for i in range(int(n_msgs/2)):
        payload = {
            "date": pd.Timestamp.now(),
            "symbol": random.choice(symbols),
            "mtime": time.time_ns(),
            "price": 100.0,
        }
        count += 1
        await stream.async_extend(payload)
        if time.time() - t_start > 0.2:
            await cache.async_header_incrby(f'producer->totalcount',count)
            await cache.async_header_incrby(f'p{producerid}->count',count)
            count = 0
            t_start = time.time()
    await stream.async_flush()
    Logger.log.info(f"Producer: DONE sending {int(n_msgs/2)} messages.")

def run_consumer(cid, n_msgs) -> None:
    """Entrypoint for consumer process; spawns its own event loop+shdata+stream."""
    asyncio.run(consumer_task(cid, n_msgs))

def run_producer(pid, n_msgs) -> None:
    """Entrypoint for producer process; spawns its own event loop+shdata+stream."""
    asyncio.run(producer_task(pid, n_msgs))

def test_stream_performance():
    shdata = SharedData(__file__, user='master')
    nmsgs = 10_000_000     # Do not modify as requested.
    cache = shdata.cache('MarketData', 'RT', 'TEST', 'TEST')
    cache.header_set('consumer->totalcount',0)
    cache.header_set(f'c1->count',0)
    cache.header_set(f'c1->subscribed',0)
    cache.header_set(f'c2->count',0)
    cache.header_set(f'c2->subscribed',0)
    
    cache.header_set(f'producer->totalcount',0)
    cache.header_set(f'p1->count',0)
    cache.header_set(f'p1->started',0)
    cache.header_set(f'p2->count',0)
    cache.header_set(f'p2->started',0)
    shdata.delete_stream('MarketData', 'RT', 'TEST', 'TEST')
    time.sleep(5)
    stream = shdata.stream('MarketData', 'RT', 'TEST', 'TEST', 
                           use_aiokafka=True, partitions=2)    
    
    # Start two separate processes
    consumer_proc1 = multiprocessing.Process(target=run_consumer, args=(1, nmsgs))
    consumer_proc2 = multiprocessing.Process(target=run_consumer, args=(2, nmsgs))
    producer_proc1 = multiprocessing.Process(target=run_producer, args=(1, nmsgs))
    producer_proc2 = multiprocessing.Process(target=run_producer, args=(2, nmsgs))
    consumer_proc1.start()
    consumer_proc2.start()
    while not (int(cache.header_get('c1->subscribed'))==1 and int(cache.header_get('c2->subscribed'))==1):
        Logger.log.info("Waiting for consumers to subscribe...")
        time.sleep(1)        
    producer_proc1.start()
    producer_proc2.start()
    Logger.log.info("Consumer and producer processes started. Press Ctrl+C to exit.")
    totalcount = int(cache.header_get('consumer->totalcount'))
    lastcount = totalcount
    lastprint = time.time()
    p1_lastcount = 0
    p2_lastcount = 0
    totaltime_start = time.time()
    while totalcount<nmsgs:
        totalcount = int(cache.header_get('consumer->totalcount'))
        c1_mean_latency = float(cache.header_get('c1->mean_latency'))
        c2_mean_latency = float(cache.header_get('c2->mean_latency'))
        p1_count = int(cache.header_get('p1->count'))
        p2_count = int(cache.header_get('p2->count'))
        mean_latency = (c1_mean_latency + c2_mean_latency) / 2 if c1_mean_latency and c2_mean_latency else 0
        
        msgs_per_sec = (totalcount - lastcount) / (time.time() - lastprint)
        p1_msgs_per_sec = (p1_count - p1_lastcount) / (time.time() - lastprint)
        p2_msgs_per_sec = (p2_count - p2_lastcount) / (time.time() - lastprint)
        Logger.log.info(            
            f"P:{msgs_per_sec:.2f} P1:{p1_msgs_per_sec:.2f} P2:{p1_msgs_per_sec:.2f} msg/s, "
            f"C:{mean_latency:.2f}, C1:{c1_mean_latency:.2f} C2:{c2_mean_latency:.2f} ms, "
            f"{totalcount}/{nmsgs} msgs, "
        )
        lastprint = time.time()
        lastcount = totalcount
        p1_lastcount = p1_count
        p2_lastcount = p2_count
        time.sleep(1)
    if mean_latency >= 100:
        raise AssertionError(f"Mean latency {mean_latency} ms is too high.")
    
    totaltime = time.time() - totaltime_start
    throughput = nmsgs / totaltime
    if throughput <= 70000:
        raise AssertionError(f"Throughput {throughput:.2f} msg/s is too low")
    try:
        producer_proc1.join()
        producer_proc2.join()
        consumer_proc1.join()
        consumer_proc2.join()
    except KeyboardInterrupt:
        print("Shutting down processes...")
        producer_proc1.terminate()
        producer_proc2.terminate()
        consumer_proc1.terminate()
        consumer_proc2.terminate()
    finally:
        # Clean up Kafka topic after test:
        shdata.delete_stream('MarketData', 'RT', 'TEST', 'TEST')