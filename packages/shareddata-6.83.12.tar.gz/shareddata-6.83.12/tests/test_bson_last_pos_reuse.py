"""
Test: BSON last-position reuse fix for SharedData schemaless tables.

Replicates the JOBS table ACTIVE_JOBS scenario where a single record 
(keyed by 'hash') is updated every ~15 seconds with varying BSON data sizes.
Without the fix, each update where new_size > old_size allocates new space at 
the end of the BSON file, causing continuous growth. The fix detects when the 
record's allocation is at the tail of the BSON file (old_ptr + old_size == next_bson_ptr)
and reuses the position in-place.

Test strategy:
1. Create a test schemaless table (Hashs/D1/TEST_BSON_REUSE/BSON_GROWTH_TEST)
2. Insert a record with BSON data (simulating initial ACTIVE_JOBS write)
3. Repeatedly update the same record with varying BSON sizes (simulating 15-second heartbeat)
4. Assert that next_bson_ptr does NOT grow unboundedly - it should track the single record's size
5. Verify data integrity after each update cycle
"""

import os
import sys
import time
import numpy as np
import pandas as pd
import shutil
from pathlib import Path

# Use the SharedData venv
sys.path.insert(0, os.path.join(os.environ.get('SOURCE_FOLDER', os.path.expanduser('~/src')), 'SharedData', 'src'))

from SharedData.SharedData import SharedData
from SharedData.Logger import Logger


def get_record_bson_info(records, hash_name):
    """Helper to get bson_ptr and bson_size for a record by hash."""
    buff = np.full((1,), dtype=records.dtype, fill_value=np.nan)
    buff['hash'] = hash_name
    loc = records.get_loc(buff)
    if loc[0] == -1:
        return None, None, None
    idx = loc[0]
    return idx, int(records[idx]['bson_ptr']), int(records[idx]['bson_size'])


def test_bson_last_pos_reuse():
    """
    Simulate the ACTIVE_JOBS update pattern and verify BSON file does NOT grow continuously.
    """
    Logger.connect(__file__)
    
    TABLE_SOURCE = 'TEST_BSON_REUSE'
    TABLE_NAME = 'BSON_GROWTH_TEST'
    DATABASE = 'Hashs'
    PERIOD = 'D1'
    NUM_ITERATIONS = 200  # Simulate 200 updates (~50 minutes of 15-second updates)
    
    print(f"\n{'='*70}")
    print(f"TEST: BSON Last-Position Reuse Fix")
    print(f"{'='*70}")
    print(f"Simulating {NUM_ITERATIONS} updates to a single ACTIVE_JOBS-like record")
    
    # Initialize SharedData
    shdata = SharedData(__file__, user='master')
    
    # Create test table (schemaless, like the JOBS table)
    print(f"\n[1] Creating test table: {DATABASE}/{PERIOD}/{TABLE_SOURCE}/{TABLE_NAME}")
    records = shdata.table(
        DATABASE, PERIOD, TABLE_SOURCE, TABLE_NAME,
        user='master',
        names=['hash', 'status'],
        formats=['|S64', '|S16'],
        is_schemaless=True,
        size=100,
        overwrite=True,
    )
    tbl = records.table  # The Table object with hdr
    
    # Initial record - simulates first ACTIVE_JOBS write
    print(f"\n[2] Inserting initial ACTIVE_JOBS record...")
    initial_jobs = {
        'hash': 'ACTIVE_JOBS',
        'status': 'ACTIVE',
        'jobs': {
            'job_001': {'repo': 'TestRepo', 'routine': 'Scripts/Test.py', 'status': 'running', 'started': time.time()},
            'job_002': {'repo': 'TestRepo', 'routine': 'Scripts/Test2.py', 'status': 'pending', 'started': time.time()},
        }
    }
    records = records.upsert(initial_jobs)
    tbl = records.table
    
    initial_next_bson_ptr = int(tbl.hdr['next_bson_ptr'])
    idx, initial_bson_ptr, initial_bson_size = get_record_bson_info(records, b'ACTIVE_JOBS')
    
    print(f"   Initial next_bson_ptr: {initial_next_bson_ptr}")
    print(f"   Initial bson_ptr:      {initial_bson_ptr}")
    print(f"   Initial bson_size:     {initial_bson_size}")
    print(f"   Tail check: bson_ptr({initial_bson_ptr}) + bson_size({initial_bson_size}) = {initial_bson_ptr + initial_bson_size}")
    assert initial_bson_ptr + initial_bson_size == initial_next_bson_ptr, \
        "Initial record should be at BSON file tail!"
    
    # Track metrics
    max_next_bson_ptr = initial_next_bson_ptr
    ptr_values = [initial_next_bson_ptr]
    bson_ptr_values = [initial_bson_ptr]
    
    # Simulate repeated updates (like WorkerPool heartbeat every 15 seconds)
    print(f"\n[3] Running {NUM_ITERATIONS} update iterations...")
    print(f"   (Simulating ACTIVE_JOBS updates with varying BSON sizes)")
    
    for i in range(NUM_ITERATIONS):
        # Simulate changing job data (varying size - jobs start, complete, new ones added)
        num_jobs = np.random.randint(1, 20)  # Varying number of active jobs
        jobs = {}
        for j in range(num_jobs):
            jobs[f'job_{i}_{j:03d}'] = {
                'repo': f'Repo_{j % 5}',
                'routine': f'Scripts/Routine_{j}.py',
                'status': np.random.choice(['running', 'pending', 'completed', 'error']),
                'started': time.time() - np.random.randint(0, 3600),
                'worker': f'TRADEBOT{j % 10:02d}-WS',
                'iteration': i,
            }
        
        update_record = {
            'hash': 'ACTIVE_JOBS',
            'status': 'ACTIVE',
            'jobs': jobs,
            'last_update': time.time(),
            'update_count': i + 1,
        }
        
        records = records.upsert(update_record)
        tbl = records.table
        
        current_next_bson_ptr = int(tbl.hdr['next_bson_ptr'])
        idx, current_bson_ptr, current_bson_size = get_record_bson_info(records, b'ACTIVE_JOBS')
        
        ptr_values.append(current_next_bson_ptr)
        bson_ptr_values.append(current_bson_ptr)
        
        if current_next_bson_ptr > max_next_bson_ptr:
            max_next_bson_ptr = current_next_bson_ptr
        
        # Verify the record is always at the tail
        assert current_bson_ptr + current_bson_size == current_next_bson_ptr, \
            f"Iteration {i}: Record should be at tail! " \
            f"bson_ptr({current_bson_ptr}) + bson_size({current_bson_size}) = {current_bson_ptr + current_bson_size} " \
            f"!= next_bson_ptr({current_next_bson_ptr})"
        
        # Verify the bson_ptr stays the same (position reuse!)
        assert current_bson_ptr == initial_bson_ptr, \
            f"Iteration {i}: bson_ptr should stay at {initial_bson_ptr} but is {current_bson_ptr}. " \
            f"Last-position reuse NOT working!"
        
        if (i + 1) % 50 == 0:
            print(f"   [{i+1}/{NUM_ITERATIONS}] next_bson_ptr={current_next_bson_ptr}, "
                  f"bson_ptr={current_bson_ptr}, bson_size={current_bson_size}")
    
    # Verify data integrity - read back the final record
    print(f"\n[4] Verifying data integrity...")
    dict_list = records.get_dict_list([0])
    assert len(dict_list) == 1
    final_data = dict_list[0]
    assert final_data['update_count'] == NUM_ITERATIONS
    assert 'jobs' in final_data
    print(f"   ✓ Final record has update_count={final_data['update_count']}")
    print(f"   ✓ Final record has {len(final_data['jobs'])} jobs")
    
    # Analyze growth
    final_next_bson_ptr = int(tbl.hdr['next_bson_ptr'])
    print(f"\n[5] Growth analysis:")
    print(f"   Initial next_bson_ptr: {initial_next_bson_ptr}")
    print(f"   Final next_bson_ptr:   {final_next_bson_ptr}")
    print(f"   Max next_bson_ptr:     {max_next_bson_ptr}")
    print(f"   bson_ptr constant at:  {initial_bson_ptr}")
    
    # WITHOUT the fix, next_bson_ptr would grow by ~initial_bson_size * NUM_ITERATIONS
    without_fix_estimate = initial_bson_size * NUM_ITERATIONS
    
    print(f"\n   Without fix, estimated growth: ~{without_fix_estimate:,} bytes ({without_fix_estimate/1024/1024:.2f} MB)")
    print(f"   With fix, actual max cursor:   {max_next_bson_ptr:,} bytes ({max_next_bson_ptr/1024:.2f} KB)")
    
    # The max cursor should be bounded by the maximum single-record BSON size
    max_reasonable_size = 50 * 1024  # 50 KB - generous bound for largest single record
    assert max_next_bson_ptr < max_reasonable_size, \
        f"BSON cursor grew to {max_next_bson_ptr} bytes which suggests " \
        f"last-position reuse is NOT working! Expected < {max_reasonable_size}"
    
    # All bson_ptr values should be the same (position reuse)
    unique_ptrs = set(bson_ptr_values)
    assert len(unique_ptrs) == 1, \
        f"Expected all bson_ptr values to be the same, got {len(unique_ptrs)} unique values: {unique_ptrs}"
    
    print(f"\n   ✓ All {NUM_ITERATIONS + 1} bson_ptr values are identical: {initial_bson_ptr}")
    print(f"   ✓ next_bson_ptr bounded at {max_next_bson_ptr} bytes (< {max_reasonable_size} limit)")
    
    # Cleanup
    print(f"\n[6] Cleaning up test table...")
    records.free()
    
    # Remove test files
    db_folder = shdata.dbfolders[0]
    test_path = Path(db_folder) / 'master' / DATABASE / PERIOD / TABLE_SOURCE
    if test_path.exists():
        shutil.rmtree(test_path)
        print(f"   ✓ Removed {test_path}")
    
    print(f"\n{'='*70}")
    print(f"TEST PASSED: BSON last-position reuse prevents continuous growth!")
    print(f"{'='*70}\n")


def test_bson_multiple_records_mixed():
    """
    Test with multiple records where only the LAST allocated one gets reused.
    Other records that grow should still allocate new space normally.
    """
    Logger.connect(__file__)
    
    TABLE_SOURCE = 'TEST_BSON_REUSE'
    TABLE_NAME = 'BSON_MULTI_TEST'
    DATABASE = 'Hashs'
    PERIOD = 'D1'
    
    print(f"\n{'='*70}")
    print(f"TEST: Multiple records - only last one reused")
    print(f"{'='*70}")
    
    shdata = SharedData(__file__, user='master')
    
    # Create table
    records = shdata.table(
        DATABASE, PERIOD, TABLE_SOURCE, TABLE_NAME,
        user='master',
        names=['hash', 'status'],
        formats=['|S64', '|S16'],
        is_schemaless=True,
        size=100,
        overwrite=True,
    )
    tbl = records.table
    
    # Insert 3 records: REC_A, REC_B, REC_C (in order)
    print(f"\n[1] Inserting 3 records...")
    for name in ['REC_A', 'REC_B', 'REC_C']:
        records = records.upsert({
            'hash': name,
            'status': 'ACTIVE',
            'data': {'key': f'value_for_{name}', 'counter': 0},
        })
        tbl = records.table
    
    # Get initial positions
    _, ptr_a, size_a = get_record_bson_info(records, b'REC_A')
    _, ptr_b, size_b = get_record_bson_info(records, b'REC_B')
    _, ptr_c, size_c = get_record_bson_info(records, b'REC_C')
    next_ptr = int(tbl.hdr['next_bson_ptr'])
    
    print(f"   REC_A bson_ptr: {ptr_a}, bson_size: {size_a}")
    print(f"   REC_B bson_ptr: {ptr_b}, bson_size: {size_b}")
    print(f"   REC_C bson_ptr: {ptr_c}, bson_size: {size_c}")
    print(f"   next_bson_ptr:  {next_ptr}")
    
    assert ptr_c + size_c == next_ptr, "REC_C should be at tail"
    
    # Update REC_C 50 times with growing data (should reuse position)
    print(f"\n[2] Updating REC_C 50 times (last-position reuse)...")
    for i in range(50):
        records = records.upsert({
            'hash': 'REC_C',
            'status': 'ACTIVE',
            'data': {'key': 'updated_C', 'counter': i, 'extra': 'x' * np.random.randint(10, 500)},
        })
        tbl = records.table
    
    _, new_ptr_c, _ = get_record_bson_info(records, b'REC_C')
    assert new_ptr_c == ptr_c, f"REC_C ptr should stay at {ptr_c}, got {new_ptr_c} (reuse broken!)"
    print(f"   ✓ REC_C bson_ptr unchanged at {ptr_c} after 50 updates")
    
    # Update REC_A (NOT at tail - should allocate new space when growing)
    print(f"\n[3] Updating REC_A with larger data (not at tail, should allocate new space)...")
    records = records.upsert({
        'hash': 'REC_A',
        'status': 'ACTIVE',
        'data': {'key': 'updated_A', 'big_field': 'X' * 10000},  # Much larger
    })
    tbl = records.table
    
    _, new_ptr_a, new_size_a = get_record_bson_info(records, b'REC_A')
    
    print(f"   REC_A old ptr: {ptr_a}, new ptr: {new_ptr_a}")
    # REC_A was NOT at the tail, so if it grew, it should get a new allocation
    assert new_ptr_a != ptr_a, "REC_A should have been reallocated (not at tail)"
    
    # Now REC_A is the last allocated. Update it - should use last-position reuse
    print(f"\n[4] Updating REC_A again (now at tail, should reuse)...")
    for i in range(20):
        records = records.upsert({
            'hash': 'REC_A',
            'status': 'ACTIVE',
            'data': {'key': 'updated_A_v2', 'iteration': i, 'extra': 'Y' * np.random.randint(100, 5000)},
        })
        tbl = records.table
    
    _, final_ptr_a, _ = get_record_bson_info(records, b'REC_A')
    assert final_ptr_a == new_ptr_a, f"REC_A should reuse position {new_ptr_a}, got {final_ptr_a}"
    print(f"   ✓ REC_A bson_ptr unchanged at {new_ptr_a} after 20 updates")
    
    # Verify all records still readable
    print(f"\n[5] Verifying data integrity for all records...")
    for name in [b'REC_A', b'REC_B', b'REC_C']:
        idx, _, _ = get_record_bson_info(records, name)
        assert idx is not None, f"Record {name} not found!"
        data = records.get_dict_list([idx])
        assert len(data) == 1
        assert 'data' in data[0]
        print(f"   ✓ {name.decode()}: readable, has 'data' field")
    
    # Cleanup
    records.free()
    db_folder = shdata.dbfolders[0]
    test_path = Path(db_folder) / 'master' / DATABASE / PERIOD / TABLE_SOURCE
    if test_path.exists():
        shutil.rmtree(test_path)
    
    print(f"\n{'='*70}")
    print(f"TEST PASSED: Multiple records behave correctly!")
    print(f"{'='*70}\n")


def test_bson_backwards_compatibility():
    """
    Verify the fix is backwards compatible with existing BSON files:
    1. Records NOT at the tail still work (in-place or new alloc)
    2. Records with bson_ptr=-1 or bson_size=0 (no BSON data) are unaffected
    3. The file format and header layout are unchanged
    4. Existing BSON data written by old code can still be read after the fix
    """
    Logger.connect(__file__)

    TABLE_SOURCE = 'TEST_BSON_REUSE'
    TABLE_NAME = 'BSON_COMPAT_TEST'
    DATABASE = 'Hashs'
    PERIOD = 'D1'

    print(f"\n{'='*70}")
    print(f"TEST: Backwards compatibility")
    print(f"{'='*70}")

    shdata = SharedData(__file__, user='master')

    records = shdata.table(
        DATABASE, PERIOD, TABLE_SOURCE, TABLE_NAME,
        user='master',
        names=['hash', 'status'],
        formats=['|S64', '|S16'],
        is_schemaless=True,
        size=100,
        overwrite=True,
    )
    tbl = records.table

    # --- Case 1: Insert multiple records to simulate old-format data ---
    print(f"\n[1] Inserting records to simulate pre-existing BSON file...")
    test_data = [
        {'hash': 'WORKER_01', 'status': 'ONLINE', 'info': {'host': 'TB01', 'cpu': 12}},
        {'hash': 'WORKER_02', 'status': 'ONLINE', 'info': {'host': 'TB02', 'cpu': 28}},
        {'hash': 'WORKER_03', 'status': 'OFFLINE', 'info': {'host': 'TB03', 'cpu': 16}},
        {'hash': 'ACTIVE_JOBS', 'status': 'ACTIVE', 'jobs': {'j1': {'repo': 'R1'}}},
        {'hash': 'WORKER_04', 'status': 'ONLINE', 'info': {'host': 'TB04', 'cpu': 16}},
    ]
    for d in test_data:
        records = records.upsert(d)
        tbl = records.table

    assert int(records.count) == 5
    ptr_before = {}
    for name in [b'WORKER_01', b'WORKER_02', b'WORKER_03', b'ACTIVE_JOBS', b'WORKER_04']:
        idx, ptr, sz = get_record_bson_info(records, name)
        ptr_before[name] = (idx, ptr, sz)
        print(f"   {name.decode():15s} idx={idx} bson_ptr={ptr} bson_size={sz}")

    # WORKER_04 should be at the tail
    idx_w4, ptr_w4, sz_w4 = ptr_before[b'WORKER_04']
    next_ptr = int(tbl.hdr['next_bson_ptr'])
    assert ptr_w4 + sz_w4 == next_ptr, "WORKER_04 should be at tail"

    # ACTIVE_JOBS is NOT at the tail (WORKER_04 is after it)
    idx_aj, ptr_aj, sz_aj = ptr_before[b'ACTIVE_JOBS']
    assert ptr_aj + sz_aj != next_ptr, "ACTIVE_JOBS should NOT be at tail for this test"

    # --- Case 2: Update ACTIVE_JOBS (not at tail) with smaller data ---
    print(f"\n[2] Updating ACTIVE_JOBS with smaller data (not at tail, in-place)...")
    records = records.upsert({
        'hash': 'ACTIVE_JOBS', 'status': 'ACTIVE', 'jobs': {},
    })
    tbl = records.table

    _, new_ptr_aj, new_sz_aj = get_record_bson_info(records, b'ACTIVE_JOBS')
    print(f"   ACTIVE_JOBS: ptr {ptr_aj}->{new_ptr_aj}, size {sz_aj}->{new_sz_aj}")
    assert new_ptr_aj == ptr_aj, "Should reuse same position (smaller data fits)"
    assert new_sz_aj <= sz_aj, "New size should be <= old size"

    # --- Case 3: Update ACTIVE_JOBS (not at tail) with LARGER data ---
    print(f"\n[3] Updating ACTIVE_JOBS with much larger data (not at tail, new alloc)...")
    records = records.upsert({
        'hash': 'ACTIVE_JOBS', 'status': 'ACTIVE',
        'jobs': {f'job_{i}': {'data': 'x' * 100} for i in range(50)},
    })
    tbl = records.table

    _, new_ptr_aj2, new_sz_aj2 = get_record_bson_info(records, b'ACTIVE_JOBS')
    print(f"   ACTIVE_JOBS: ptr {new_ptr_aj}->{new_ptr_aj2}, size {new_sz_aj}->{new_sz_aj2}")
    # Not at tail + grew => must allocate new space (old behavior preserved)
    assert new_ptr_aj2 != new_ptr_aj, "Should have new allocation (grew, not at tail)"

    # --- Case 4: Verify ALL records are still readable ---
    print(f"\n[4] Verifying all records are still readable...")
    for name in [b'WORKER_01', b'WORKER_02', b'WORKER_03', b'ACTIVE_JOBS', b'WORKER_04']:
        idx, ptr, sz = get_record_bson_info(records, name)
        assert idx is not None, f"{name.decode()} not found!"
        data = records.get_dict_list([idx])
        assert len(data) == 1
        # Verify BSON data survived
        if name == b'ACTIVE_JOBS':
            assert 'jobs' in data[0], "ACTIVE_JOBS should have 'jobs' field"
        elif name.startswith(b'WORKER_'):
            if name != b'WORKER_04':
                assert 'info' in data[0], f"{name.decode()} should have 'info' field"
        print(f"   ✓ {name.decode():15s} readable, bson_ptr={ptr}, bson_size={sz}")

    # --- Case 5: Records with no BSON data (bson_ptr=-1) should be unaffected ---
    print(f"\n[5] Testing record with empty dict (clears BSON)...")
    records = records.upsert({
        'hash': 'EMPTY_REC', 'status': 'EMPTY',
    })
    tbl = records.table
    idx_e, ptr_e, sz_e = get_record_bson_info(records, b'EMPTY_REC')
    # Empty dict passed through any2records gives no dict_list entry, so BSON stays at defaults
    print(f"   EMPTY_REC: bson_ptr={ptr_e}, bson_size={sz_e}")

    # --- Case 6: Verify header layout unchanged (check known field offsets) ---
    print(f"\n[6] Verifying header layout is unchanged...")
    hdr = tbl.hdr
    # These fields must exist in the header dtype (backwards compat)
    required_fields = ['count', 'recordssize', 'mtime', 'next_bson_ptr', 'hasindex',
                       'isidxcreated', 'isidxsorted', 'minchgid']
    for field in required_fields:
        assert field in hdr.dtype.names, f"Header field '{field}' missing!"
        print(f"   ✓ Header field '{field}' present")

    # Cleanup
    records.free()
    db_folder = shdata.dbfolders[0]
    test_path = Path(db_folder) / 'master' / DATABASE / PERIOD / TABLE_SOURCE
    if test_path.exists():
        shutil.rmtree(test_path)

    print(f"\n{'='*70}")
    print(f"TEST PASSED: Backwards compatible - no format changes!")
    print(f"{'='*70}\n")


if __name__ == '__main__':
    test_bson_last_pos_reuse()
    test_bson_multiple_records_mixed()
    test_bson_backwards_compatibility()
    print("\n🎉 ALL TESTS PASSED! 🎉")
