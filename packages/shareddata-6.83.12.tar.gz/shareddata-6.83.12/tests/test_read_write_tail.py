import pytest
import pandas as pd
from SharedData.SharedData import SharedData
from SharedData.IO.AWSS3 import S3GetMtime

@pytest.mark.integration
def test_tail_file_deleted_on_data_truncation():
    """
    Test that tail file is deleted on remote S3 when table data
    is overwritten such that previous years' data is removed.
    """
    shdata = SharedData(__file__, user='master')

    today = pd.Timestamp.now().normalize()
    lastyear = today - pd.Timedelta(days=365)

    # Create table with data for the last year
    shdata.delete_table('MarketData', 'D1', 'TEST', 'TEST')
    dates = pd.date_range(lastyear, today, freq='D')
    symbols = [f'SYM{i}' for i in range(10)]
    idx = pd.MultiIndex.from_product([dates, symbols], names=['date', 'symbol'])
    df = pd.DataFrame(index=idx)
    df['open'] = 100

    tbl = shdata.table('MarketData', 'D1', 'TEST', 'TEST', value=df)
    tbl.write()

    headmtime = S3GetMtime(str(tbl.table.headpath)+'.gzip', tbl.table.database_folder)
    tailmtime = S3GetMtime(str(tbl.table.tailpath)+'.gzip', tbl.table.database_folder)

    assert headmtime is not None, "head file should exist after initial write"
    assert tailmtime is not None, "tail file should exist after initial write"

    # Overwrite table with data for the current year only
    yearstart = today.replace(month=1, day=1)
    dates = pd.date_range(yearstart, today, freq='D')
    idx = pd.MultiIndex.from_product([dates, symbols], names=['date', 'symbol'])
    df = pd.DataFrame(index=idx)
    df['open'] = 100

    tbl = shdata.table('MarketData', 'D1', 'TEST', 'TEST', value=df, overwrite=True)
    tbl.write()

    headmtime = S3GetMtime(str(tbl.table.headpath)+'.gzip', tbl.table.database_folder)
    tailmtime = S3GetMtime(str(tbl.table.tailpath)+'.gzip', tbl.table.database_folder)

    assert headmtime is not None, "head file should still exist after overwrite"
    assert tailmtime is None, "tail file should have been deleted after truncation"
