"""
Smoke tests for the rewritten CacheRedis.

Requires REDIS_CLUSTER_NODES pointing at a live cluster (same env as the rest
of SharedData's integration tests).
"""
import asyncio
import os
import uuid
from datetime import datetime, timezone

import pytest

from SharedData.CacheRedis import CacheRedis, _deep_merge


def _unique_table() -> str:
    return f'TEST_{uuid.uuid4().hex[:12]}'


@pytest.fixture
def cache():
    if 'REDIS_CLUSTER_NODES' not in os.environ:
        pytest.skip('REDIS_CLUSTER_NODES not set')
    c = CacheRedis('MarketData', 'RT', 'IBKR', _unique_table())
    yield c
    c.clear()


def test_deep_merge_handles_nested_dicts():
    base = {'a': 1, 'nested': {'x': 1, 'y': 2}}
    _deep_merge(base, {'b': 2, 'nested': {'y': 20, 'z': 30}})
    assert base == {'a': 1, 'b': 2, 'nested': {'x': 1, 'y': 20, 'z': 30}}


def test_setitem_and_getitem_roundtrip(cache):
    cache['AAPL'] = {'symbol': 'AAPL', 'BID': 100.0, 'ASK': 100.5}
    got = cache['AAPL']
    assert got['symbol'] == 'AAPL'
    assert got['BID'] == 100.0
    assert got['ASK'] == 100.5


def test_getitem_missing_returns_empty(cache):
    assert cache['NOPE'] == {}


def test_at_raises_on_missing(cache):
    with pytest.raises(KeyError):
        cache.at('NOPE')


def test_setitem_merges(cache):
    cache['AAPL'] = {'symbol': 'AAPL', 'BID': 100.0}
    cache['AAPL'] = {'ASK': 101.0}
    got = cache['AAPL']
    assert got['BID'] == 100.0
    assert got['ASK'] == 101.0


def test_nested_merge_preserves_other_fields(cache):
    cache['AAPL'] = {'symbol': 'AAPL', 'IV_MODEL': {'IV': 0.2, 'DELTA': 0.5}}
    cache['AAPL'] = {'IV_MODEL': {'DELTA': 0.6}}
    iv = cache['AAPL']['IV_MODEL']
    assert iv['IV'] == 0.2
    assert iv['DELTA'] == 0.6


def test_datetime_roundtrips(cache):
    t = datetime.now(timezone.utc).replace(microsecond=0)
    cache['AAPL'] = {'symbol': 'AAPL', 'mtime': t, 'BID': 100.0}
    got = cache['AAPL']
    assert got['mtime'].replace(microsecond=0) == t


def test_apply_batch_conflates_same_pkey(cache):
    msgs = [
        {'symbol': 'AAPL', 'BID': 100.0},
        {'symbol': 'AAPL', 'ASK': 101.0},
        {'symbol': 'MSFT', 'BID': 300.0},
    ]
    written = asyncio.run(cache.apply_batch(msgs))
    assert written == 2
    assert cache['AAPL']['BID'] == 100.0
    assert cache['AAPL']['ASK'] == 101.0
    assert cache['MSFT']['BID'] == 300.0


def test_counter_increments_on_write(cache):
    before = int(cache.header.get('cache->counter', 0))
    cache['AAPL'] = {'symbol': 'AAPL', 'BID': 100.0}
    after = int(cache.header.get('cache->counter', 0))
    assert after == before + 1


def test_scan_returns_pkeys(cache):
    cache['AAPL'] = {'symbol': 'AAPL', 'BID': 100.0}
    cache['MSFT'] = {'symbol': 'MSFT', 'BID': 300.0}
    keys = set(cache.scan())
    assert {'AAPL', 'MSFT'} <= keys


def test_clear_removes_all(cache):
    cache['AAPL'] = {'symbol': 'AAPL', 'BID': 100.0}
    cache.clear()
    assert list(cache.scan()) == []


def test_pkey_of_missing_column_raises(cache):
    with pytest.raises(KeyError):
        cache.pkey_of({'BID': 100.0})  # no 'symbol'


def test_pkey_of_marketdata_excludes_date():
    """
    Regression: DATABASE_PKEYS['MarketData'] == ['date', 'symbol']. The cache
    pkey is derived from the entity columns only ('symbol','portfolio','tag'),
    so 'symbol' alone is used as the pkey — 'latest per symbol' semantics,
    matching the 6.80.7 behavior that existing Redis data was written under.
    """
    if 'REDIS_CLUSTER_NODES' not in os.environ:
        pytest.skip('REDIS_CLUSTER_NODES not set')
    c = CacheRedis('MarketData', 'RT', 'IBKR', _unique_table())
    try:
        assert c.pkey_columns == ['symbol']
        msg = {
            'symbol': 'AAPL',
            'date': datetime(2026, 4, 19, tzinfo=timezone.utc),
            'BID': 100.0,
        }
        assert c.pkey_of(msg) == 'AAPL'
    finally:
        c.clear()


def test_key_layout_matches_6_80_7(cache):
    """
    Writes must land under {path}:<pkey> and the pkey SET at {path}#pkeys.
    Existing data written by 6.80.7 readers must remain visible.
    """
    cache['AAPL'] = {'symbol': 'AAPL', 'BID': 100.0}
    tag = '{' + cache.path + '}'
    assert cache._redis.exists(f'{tag}:AAPL') == 1
    members = {
        m.decode() if isinstance(m, bytes) else m
        for m in cache._redis.smembers(f'{tag}#pkeys')
    }
    assert 'AAPL' in members


def test_list_keys_uses_smembers(cache):
    """list_keys must return the SET contents, not a SCAN result."""
    cache['AAPL'] = {'symbol': 'AAPL', 'BID': 100.0}
    cache['MSFT'] = {'symbol': 'MSFT', 'BID': 300.0}
    assert set(cache.list_keys('*')) >= {'AAPL', 'MSFT'}


def test_delete_removes_from_set(cache):
    cache['AAPL'] = {'symbol': 'AAPL', 'BID': 100.0}
    del cache['AAPL']
    assert 'AAPL' not in cache.list_keys('*')
    assert not cache.exists('AAPL')
