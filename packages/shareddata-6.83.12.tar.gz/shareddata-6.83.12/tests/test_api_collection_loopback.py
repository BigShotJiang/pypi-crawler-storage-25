import os
import subprocess
import time
import pytest
import pandas as pd
import numpy as np

from SharedData.IO.ClientAPI import ClientAPI

SERVER_HOST = "localhost"
SERVER_PORT = 8082
SERVER_URL = f"http://{SERVER_HOST}:{SERVER_PORT}"

# ====== Fixtures ======
@pytest.fixture(scope="session", autouse=True)
def launch_server():
    """Start & stop the API server subprocess."""
    print("🚀 Starting API server...")
    source_folder = os.environ["SOURCE_FOLDER"]
    launch_cmd = [
        f"{source_folder}/SharedData/venv/bin/python",
        "-m", "SharedData.IO.ServerAPI",
        "--host", SERVER_HOST,
        "--port", str(SERVER_PORT)
    ]
    proc = subprocess.Popen(launch_cmd)
    print("⏳ Waiting for server to start...")
    time.sleep(2)  # Allow server to launch (tune as needed)
    print("✅ Server should be ready")
    yield
    print("🛑 Shutting down server...")
    proc.terminate()
    proc.wait(timeout=5)
    print("✅ Server shutdown complete")

@pytest.fixture()
def clean_collection():
    """Ensure test collection is deleted before & after test."""
    print("🧹 Cleaning up test collection (before)...")
    ClientAPI.delete_collection('MarketData', 'D1', 'TEST', 'TEST', endpoint=SERVER_URL)
    yield
    print("🧹 Cleaning up test collection (after)...")
    ClientAPI.delete_collection('MarketData', 'D1', 'TEST', 'TEST', endpoint=SERVER_URL)

# ====== Helpers =======
def make_large_test_df(
    n: int = 1_000_000,
    num_dates: int = 100,
    num_symbols: int = 10_000
) -> pd.DataFrame:
    """Generate DataFrame with n unique (date, symbol) index combinations."""
    print(f"📊 Generating test DataFrame with {n:,} rows ({num_dates} dates x {num_symbols} symbols)...")
    dates = pd.date_range("2024-01-01", periods=num_dates)
    symbols = [f"SYM{i}" for i in range(num_symbols)]
    max_combos = len(dates) * len(symbols)
    if n > max_combos:
        raise ValueError(f"Cannot generate {n} unique (date, symbol) combinations. Maximum is {max_combos}.")
    
    print("  🎲 Creating random combinations...")
    print("  🎲 Creating random combinations...")
    mesh = np.array(np.meshgrid(dates, symbols, indexing='ij'))
    date_vals = mesh[0].ravel()
    symbol_vals = mesh[1].ravel()
    indices = np.random.choice(max_combos, size=n, replace=False)
    date_vals = date_vals[indices]
    symbol_vals = symbol_vals[indices]
    
    print("  📈 Generating market data...")
    open_vals = np.random.uniform(10, 5000, size=n).astype(np.float32)
    high_vals = open_vals + np.random.uniform(0, 20, size=n).astype(np.float32)
    low_vals = open_vals - np.random.uniform(0, 20, size=n).astype(np.float32)
    close_vals = open_vals + np.random.uniform(-10, 10, size=n).astype(np.float32)
    vwap_vals = (open_vals + high_vals + low_vals + close_vals) / 4
    volume_vals = np.random.randint(100_000, 2_000_000, size=n, dtype=np.int32)
    
    print("  🏗️ Building DataFrame...")
    df = pd.DataFrame({
        'date': date_vals,
        'symbol': symbol_vals,
        'open': open_vals,
        'high': high_vals,
        'low': low_vals,
        'close': close_vals,
        'vwap': vwap_vals,
        'volume': volume_vals,
    })
    df['date'] = pd.to_datetime(df['date'])
    print(f"✅ DataFrame created with {len(df):,} rows")
    return df.set_index(['date', 'symbol']).sort_index()

# ====== Tests ======
def test_collection_crud(clean_collection):
    """Test full API CRUD cycle for standard & subset columns, and head_collection."""
    print("\n🧪 Starting API Collection CRUD Test")
    print("=" * 50)
    
    print("📊 Step 1: Creating test data...")
    dfbars = make_large_test_df(n=500_000, num_dates=1000, num_symbols=1000)
    
    print("📤 Step 2: Uploading full dataset to collection...")
    # Post full df
    ClientAPI.post_collection(
        'MarketData', 'D1', 'TEST', 'TEST',
        value=dfbars,
        endpoint=SERVER_URL,
    )
    print("✅ Upload complete")
    
    print("📥 Step 3: Downloading and verifying data...")
    # Retrieve and verify all equal
    df = ClientAPI.get_collection(
        'MarketData', 'D1', 'TEST', 'TEST',
        endpoint=SERVER_URL,
        load_all_pages=True,
    )
    print("✅ Download complete")
    print("🔍 Step 4: Verifying data integrity...")
    pd.testing.assert_frame_equal(dfbars, df[dfbars.columns],check_dtype=False)
    print("✅ Data integrity verified")

    print("🗑️ Step 5: Deleting collection and re-uploading with fewer columns...")
    # Delete collection, re-upload with dropped column
    ClientAPI.delete_collection('MarketData', 'D1', 'TEST', 'TEST', endpoint=SERVER_URL)
    ClientAPI.post_collection(
        'MarketData', 'D1', 'TEST', 'TEST',
        value=dfbars[['open', 'high', 'low', 'close', 'volume']],
        endpoint=SERVER_URL,
    )
    print("✅ Re-upload with subset columns complete")
    
    print("📥 Step 6: Downloading and verifying subset data...")
    df2 = ClientAPI.get_collection(
        'MarketData', 'D1', 'TEST', 'TEST',
        endpoint=SERVER_URL,
        load_all_pages=True,
    )
    print("✅ Subset download complete")
    print("🔍 Step 7: Verifying subset data...")
    assert 'vwap' not in df2.columns
    expect_cols = [c for c in dfbars.columns if c != 'vwap']
    pd.testing.assert_frame_equal(dfbars[expect_cols], df2[expect_cols], check_dtype=False)
    print("✅ Subset data verified")

    print("➕ Step 8: Adding more rows to collection...")
    # Add rows to table
    ClientAPI.post_collection(
        'MarketData', 'D1', 'TEST', 'TEST',
        value=dfbars.iloc[:100],
        endpoint=SERVER_URL,
    )
    print("✅ Additional rows added")
    
    print("🔍 Step 9: Checking collection metadata...")
    head = ClientAPI.head_collection(
        'MarketData', 'D1', 'TEST', 'TEST',
        endpoint=SERVER_URL
    )
    count = int(head.get('Collection-Count', 0))
    print(f"📊 Collection count: {count:,}")
    assert count == 500000
    print("✅ Collection metadata verified")
    
    print("\n🎉 ALL TESTS PASSED! 🎉")
    print("=" * 50)