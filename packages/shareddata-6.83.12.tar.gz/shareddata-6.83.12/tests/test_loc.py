import pytest
import numpy as np
from SharedData.SharedData import SharedData

@pytest.fixture(scope="module")
def shdata():
    """Provides a SharedData instance."""
    return SharedData(__file__, user='master')

def is_struct_array(obj) -> bool:
    """Return True if obj has .dtype.names and supports __getitem__."""
    return hasattr(obj, 'dtype') and hasattr(obj.dtype, 'names') and hasattr(obj, '__getitem__')

def check_keys(result, keys):
    """Check that all required field names (columns) are present in the result dtype."""
    for key in keys:
        assert key in result.dtype.names, f"Expected field '{key}' not found. Found: {result.dtype.names}"

def check_value_in_field(result, field, value):
    """Check that value is present in the recarray column."""
    assert field in result.dtype.names, f"'{field}' field missing in dtype: {result.dtype.names}"
    values = result[field]
    # Handle bytes fields
    if isinstance(values[0], bytes) and not isinstance(value, bytes):
        value = value.encode()
    assert (values == value).any(), f"Value '{value}' not found in field '{field}'"

def check_any_value_in_field(result, field, value_list):
    """Check that each value in value_list exists in the recarray column."""
    for value in value_list:
        check_value_in_field(result, field, value)

def check_sorted_dates(result):
    """Ensure the 'date' field is sorted ascending, if present."""
    if 'date' in result.dtype.names:
        dates = np.array(result['date'])
        assert (dates[:-1] <= dates[1:]).all(), "Dates are not sorted ascending."

def test_market_data_queries(shdata):
    tbl = shdata.table('MarketData', 'M1', 'BVMF', 'QUOTES/202505')

    r = tbl.loc['PETR4']
    assert is_struct_array(r)
    check_keys(r, ['date', 'symbol', 'close'])
    check_value_in_field(r, 'symbol', 'PETR4')
    check_sorted_dates(r)

    r = tbl.loc[:, 'PETR4']
    assert is_struct_array(r)
    check_keys(r, ['date', 'symbol', 'close'])
    check_value_in_field(r, 'symbol', 'PETR4')
    check_sorted_dates(r)

    r = tbl.loc[:, ['PETR4', 'VALE3']]
    assert is_struct_array(r)
    check_keys(r, ['date', 'symbol', 'close'])
    check_any_value_in_field(r, 'symbol', ['PETR4', 'VALE3'])
    check_sorted_dates(r)

    r = tbl.loc['2025-05-02 15:00:00':, :][['date', 'symbol', 'close']]
    assert is_struct_array(r)
    check_keys(r, ['date', 'symbol', 'close'])
    check_sorted_dates(r)

    r = tbl.loc[:, :][['date', 'symbol', 'close']]
    assert is_struct_array(r)
    check_keys(r, ['date', 'symbol', 'close'])
    check_sorted_dates(r)

    r = tbl.loc['2025-05-02 14:00:00':, 'PETR4'][['date', 'symbol', 'close']]
    assert is_struct_array(r)
    check_keys(r, ['date', 'symbol', 'close'])
    check_value_in_field(r, 'symbol', 'PETR4')
    check_sorted_dates(r)

    r = tbl.loc['2025-05-02 14:00:00':, ['PETR4', 'VALE3']][['date', 'symbol', 'close']]
    assert is_struct_array(r)
    check_keys(r, ['date', 'symbol', 'close'])
    check_any_value_in_field(r, 'symbol', ['PETR4', 'VALE3'])
    check_sorted_dates(r)

    r = tbl.loc['2025-05-02 14:00:00':'2025-05-02 15:00:00', 'PETR4'][['date', 'symbol', 'close']]
    assert is_struct_array(r)
    check_keys(r, ['date', 'symbol', 'close'])
    check_value_in_field(r, 'symbol', 'PETR4')
    check_sorted_dates(r)

    r = tbl.loc[:'2025-05-02 15:00:00', 'PETR4']
    assert is_struct_array(r)
    check_keys(r, ['date', 'symbol', 'close'])
    check_value_in_field(r, 'symbol', 'PETR4')
    check_sorted_dates(r)

def test_portfolios_queries(shdata):
    tbl = shdata.table('Portfolios', 'D1', 'RISKFACTORS', 'OPT/202503')

    r = tbl.loc[:, 'SPY_1M_50DC']
    assert is_struct_array(r)
    check_keys(r, ['date', 'portfolio', 'm2m_pnl_usd'])
    check_value_in_field(r, 'portfolio', 'SPY_1M_50DC')
    check_sorted_dates(r)

    r = tbl.loc['2025-03-15':, ['SPY_1M_50DC', 'SPY_2M_50DC']]
    assert is_struct_array(r)
    check_keys(r, ['date', 'portfolio'])
    check_any_value_in_field(r, 'portfolio', ['SPY_1M_50DC', 'SPY_2M_50DC'])
    check_sorted_dates(r)

def test_positions_queries(shdata):
    tbl = shdata.table('Positions', 'D1', 'RISKFACTORS', 'OPT/202503')

    r = tbl.loc['2025-03-15':, 'SPY_1M_50DC']
    assert is_struct_array(r)
    check_keys(r, ['date', 'portfolio'])
    check_value_in_field(r, 'portfolio', 'SPY_1M_50DC')
    check_sorted_dates(r)

    r = tbl.loc['2025-03-15':, ['SPY_1M_50DC', 'SPY_2M_50DC']]
    assert is_struct_array(r)
    check_keys(r, ['date', 'portfolio'])
    check_any_value_in_field(r, 'portfolio', ['SPY_1M_50DC', 'SPY_2M_50DC'])
    check_sorted_dates(r)

    r = tbl.loc['2025-03-25':, :, 'SPY_20250425_C_569.0000']
    assert is_struct_array(r)
    check_keys(r, ['date', 'symbol'])
    check_value_in_field(r, 'symbol', 'SPY_20250425_C_569.0000')
    check_sorted_dates(r)

    r = tbl.loc['2025-03-25':, 'SPY_3W_35DC', 'SPY_20250425_C_569.0000']
    assert is_struct_array(r)
    check_keys(r, ['date', 'portfolio', 'symbol'])
    check_value_in_field(r, 'portfolio', 'SPY_3W_35DC')
    check_value_in_field(r, 'symbol', 'SPY_20250425_C_569.0000')
    check_sorted_dates(r)

    r = tbl.loc['2025-03-25':, :, ['SPY_20250425_C_569.0000', 'SPY_20250530_C_566.0000']]
    assert is_struct_array(r)
    check_keys(r, ['date', 'symbol'])
    check_any_value_in_field(r, 'symbol', ['SPY_20250425_C_569.0000', 'SPY_20250530_C_566.0000'])
    check_sorted_dates(r)

    r = tbl.loc['2025-03-25':, ['SPY_3W_35DC', 'SPY_2M_50DC'],
                 ['SPY_20250425_C_569.0000', 'SPY_20250530_C_566.0000']]
    assert is_struct_array(r)
    check_keys(r, ['date', 'portfolio', 'symbol'])
    check_any_value_in_field(r, 'portfolio', ['SPY_3W_35DC', 'SPY_2M_50DC'])
    check_any_value_in_field(r, 'symbol', ['SPY_20250425_C_569.0000', 'SPY_20250530_C_566.0000'])
    check_sorted_dates(r)