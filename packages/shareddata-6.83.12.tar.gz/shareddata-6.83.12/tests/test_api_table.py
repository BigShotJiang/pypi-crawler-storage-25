import os
import subprocess
import time
import pandas as pd
import numpy as np
import pytest
from SharedData.Logger import Logger
from SharedData.IO.ClientAPI import ClientAPI

SERVER_HOST = "localhost"
SERVER_PORT = 8082
SERVER_URL = f"http://{SERVER_HOST}:{SERVER_PORT}"
SOURCE_FOLDER = os.environ["SOURCE_FOLDER"]
WAITRESS_LAUNCH = [
    f"{SOURCE_FOLDER}/SharedData/venv/bin/python",
    "-m", "SharedData.IO.ServerAPI",
    "--host", SERVER_HOST,
    "--port", str(SERVER_PORT)
]

@pytest.fixture(scope="session", autouse=True)
def run_test_server():
    """Start/stop the ServerAPI process for this test session."""
    Logger.connect(__file__)
    print("🚀 Starting ServerAPI subprocess for BIG table test...")
    proc = subprocess.Popen(WAITRESS_LAUNCH)
    try:
        import requests
        timeout = 60
        print("⏳ Waiting for server to respond to heartbeat...")
        for i in range(timeout):
            try:
                r = requests.get(f"{SERVER_URL}/api/heartbeat", timeout=3)
                if r.status_code == 200:
                    print("✅ Server API heartbeat OK!")
                    break
            except Exception as e:
                print(f"Heartbeat {i+1}/{timeout} failed: {e}")
            time.sleep(1)
        else:
            proc.terminate()
            pytest.fail("Server did not start within timeout.")
        yield
    finally:
        print("🛑 Terminating ServerAPI subprocess...")
        proc.terminate()
        proc.wait()
        print("✅ Server process cleaned up.")

def make_large_test_df(
    n: int = 1_000_000,
    num_dates: int = 100,
    num_symbols: int = 10_000
) -> pd.DataFrame:
    """
    Generate a DataFrame with n unique (date, symbol) index combinations.
    Raises ValueError if n > num_dates * num_symbols.
    """
    print(f"📊 Generating DataFrame with {n:,} rows ({num_dates} dates x {num_symbols} symbols)...")
    dates = pd.date_range("2024-01-01", periods=num_dates)
    symbols = [f"SYM{i}" for i in range(num_symbols)]
    max_combos = len(dates) * len(symbols)
    if n > max_combos:
        raise ValueError(
            f"Cannot generate {n} unique (date, symbol) combinations. "
            f"Maximum is {max_combos}."
        )
    print("  🎲 Creating random combinations...")
    mesh = np.array(np.meshgrid(dates, symbols, indexing='ij'))
    date_vals = mesh[0].ravel()
    symbol_vals = mesh[1].ravel()
    indices = np.random.choice(max_combos, size=n, replace=False)
    date_vals = date_vals[indices]
    symbol_vals = symbol_vals[indices]
    
    print("  📈 Generating market data values...")
    open_vals = np.random.uniform(10, 5000, size=n).astype(np.float32)
    high_vals = open_vals + np.random.uniform(0, 20, size=n).astype(np.float32)
    low_vals = open_vals - np.random.uniform(0, 20, size=n).astype(np.float32)
    close_vals = open_vals + np.random.uniform(-10, 10, size=n).astype(np.float32)
    vwap_vals = (open_vals + high_vals + low_vals + close_vals) / 4
    volume_vals = np.random.randint(100_000, 2_000_000, size=n, dtype=np.int32)
    
    print("  🏗️ Building DataFrame...")
    df = pd.DataFrame({
        'date': date_vals,
        'symbol': symbol_vals,
        'open': open_vals,
        'high': high_vals,
        'low': low_vals,
        'close': close_vals,
        'vwap': vwap_vals,
        'volume': volume_vals,
    })
    df['date'] = pd.to_datetime(df['date'])
    print(f"✅ DataFrame generation done - {len(df):,} rows created.")
    return df.set_index(['date', 'symbol']).sort_index()

def test_table_roundtrip_big(run_test_server):
    print("\n🧪 Starting BIG Table Roundtrip Test")
    print("=" * 50)
    
    # 4,000,000 unique rows, exactly as your original script:
    n = 4_000_000
    num_dates = 2000
    num_symbols = 2000
    print(f"📋 Test Parameters: {n:,} rows ({num_dates} dates x {num_symbols} symbols)")

    print("📊 Step 1: Creating source DataFrame...")
    dfbars = make_large_test_df(n=n, num_dates=num_dates, num_symbols=num_symbols)

    print("🗑️ Step 2: Deleting existing table...")
    status = ClientAPI.delete_table(
        'MarketData', 'D1', 'TEST', 'TEST',
        endpoint=SERVER_URL,
    )
    print(f"✅ Delete status: {status}")

    print("📤 Step 3: Uploading with ClientAPI.post_table...")
    print("  📋 Table specs: 10M size, 8 columns with types")
    ClientAPI.post_table(
        'MarketData', 'D1', 'TEST', 'TEST',
        names=['date', 'symbol', 'open', 'high', 'low', 'close', 'vwap', 'volume'],
        formats=['<M8[ns]', '|S16', '<f4', '<f4', '<f4', '<f4', '<f4', '<i4'],
        size=int(10e6), value=dfbars,
        endpoint=SERVER_URL,
    )
    print("✅ Upload complete.")

    print("📥 Step 4: Downloading with ClientAPI.get_table...")
    df = ClientAPI.get_table(
        'MarketData', 'D1', 'TEST', 'TEST',
        endpoint=SERVER_URL,
        load_all_pages=True,
    )
    print("✅ Download complete.")

    print("🔍 Step 5: Checking roundtrip equality...")
    print(f"  📊 Original rows: {len(dfbars):,}")
    print(f"  📊 Downloaded rows: {len(df):,}")
    assert (dfbars == df[dfbars.columns]).all().all()
    print("✅ Roundtrip check passed.")

    print("🗑️ Step 6: Deleting table...")
    status = ClientAPI.delete_table(
        'MarketData', 'D1', 'TEST', 'TEST',
        endpoint=SERVER_URL,
    )
    assert status in (204, 200)
    print(f"✅ Table deleted (status: {status})")

    print("🔄 Step 7: Testing column changes...")
    print("  📤 Re-uploading without 'vwap' column...")
    ClientAPI.post_table(
        'MarketData', 'D1', 'TEST', 'TEST',
        names=['date', 'symbol', 'open', 'high', 'low', 'close',  'volume'],
        formats=['<M8[ns]', '|S16', '<f4', '<f4', '<f4', '<f4',  '<i4'],
        size=int(10e6), value=dfbars,
        endpoint='http://localhost:8082',
    )
    print("✅ Re-upload complete")

    print("  📥 Downloading and checking columns...")
    df = ClientAPI.get_table(
        'MarketData', 'D1', 'TEST', 'TEST',    
        endpoint='http://localhost:8082',
        load_all_pages=True,
    )

    assert 'vwap' not in df.columns
    print("✅ Confirmed 'vwap' column not in downloaded data")

    cols = dfbars.columns
    cols = cols[cols!='vwap']
    assert (dfbars[cols] == df[cols]).all().all()
    print("✅ Non-vwap columns match perfectly")

    print("📈 Step 8: Testing table size increase...")
    print("  📤 Increasing table size to 15M records...")
    ClientAPI.post_table(
        'MarketData', 'D1', 'TEST', 'TEST',
        names=['date', 'symbol', 'open', 'high', 'low', 'close',  'volume'],
        formats=['<M8[ns]', '|S16', '<f4', '<f4', '<f4', '<f4',  '<i4'],
        size=int(15e6), value=dfbars.iloc[:100],
        endpoint='http://localhost:8082',
    )
    print("✅ Size increase complete")

    print("  🔍 Checking table metadata...")
    head = ClientAPI.head_table(
        'MarketData', 'D1', 'TEST', 'TEST',
        endpoint='http://localhost:8082',)

    for key in head:
        print(f'  📊 {key}: {head[key]}')
    assert (int(head['Table-Count']) == 4e6)
    assert (int(head['Table-Recordssize']) == 15e6)
    print("✅ Table metadata verified")
    
    print("\n🎉 BIG TABLE TEST COMPLETE! 🎉")
    print("=" * 50)