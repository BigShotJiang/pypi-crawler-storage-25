import pandas as pd
import numpy as np
import pytest

from SharedData.SharedData import SharedData

@pytest.fixture
def get_test_table():
    shdata = SharedData(__file__, user='master')
    tbl = shdata.table(
        'Positions', 'M1', 'TEST', 'TEST/202505',
        names=['date', 'portfolio','symbol', 'open', 'high', 'low', 'close', 'volume'],
        formats=['<M8[ns]', '|S12','|S12', '<f8', '<f8', '<f8', '<f8', '<i8'],
        size=100, overwrite=True
    )
    arr = np.full((20,), dtype=tbl.dtype, fill_value=np.nan)
    for i in range(10):
        if i % 2 == 0:
            arr['date'][i] = np.datetime64('2025-05-01', 'ns') + (10 + i) * np.timedelta64(1, 'm') + np.timedelta64(30, 's')
        else:
            arr['date'][i] = np.datetime64('2025-05-01', 'ns') + (10 + i - 1) * np.timedelta64(1, 'm') + np.timedelta64(30, 's')
        arr['portfolio'][i] = 'test'
        arr['symbol'][i] = 'TEST' + str(i)
    tbl.upsert(arr[:10])
    for i in range(10, 20):
        if i % 2 == 0:
            arr['date'][i] = np.datetime64('2025-05-01', 'ns') + (-10 + i) * np.timedelta64(1, 'm') + np.timedelta64(30, 's')
        else:
            arr['date'][i] = np.datetime64('2025-05-01', 'ns') + (-10 + i - 1) * np.timedelta64(1, 'm') + np.timedelta64(30, 's')
        arr['portfolio'][i] = 'test'
        arr['symbol'][i] = 'TEST' + str(i)
    tbl.upsert(arr[10:20])
    return tbl

def test_get_date_loc(get_test_table):
    tbl = get_test_table
    loc = tbl.get_date_loc(tbl['date'][-1])
    assert (tbl[loc]['date'] == tbl['date'][-2:]).all()

def test_get_date_loc_gte_lte(get_test_table):
    tbl = get_test_table
    startdate = pd.Timestamp('2025-05-01 00:02:00')
    enddate = pd.Timestamp('2025-05-01 00:16:00')
    loc = tbl.get_date_loc_gte_lte(startdate, enddate)
    assert len(loc) == 16
    assert (tbl[loc]['date'] >= startdate).all()
    assert (tbl[loc]['date'] <= enddate).all()