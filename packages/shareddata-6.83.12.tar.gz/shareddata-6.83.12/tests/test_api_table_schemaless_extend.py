import os
import subprocess
import time
from typing import List, Dict, Any

import pandas as pd
import pytest

from SharedData.IO.ClientAPI import ClientAPI
from SharedData.Logger import Logger

SERVER_HOST = "localhost"
SERVER_PORT = 8082
SERVER_URL = f"http://{SERVER_HOST}:{SERVER_PORT}"
SOURCE_FOLDER = os.environ["SOURCE_FOLDER"]
WAITRESS_LAUNCH = [
    f"{SOURCE_FOLDER}/SharedData/venv/bin/python",
    "-m",
    "SharedData.IO.ServerAPI",
    "--host",
    SERVER_HOST,
    "--port",
    str(SERVER_PORT),
]


@pytest.fixture(scope="session", autouse=True)
def run_test_server():
    """Start and stop a dedicated ServerAPI instance for this test session."""
    Logger.connect(__file__)
    proc = subprocess.Popen(WAITRESS_LAUNCH)
    try:
        import requests

        for _ in range(60):
            try:
                response = requests.get(f"{SERVER_URL}/api/heartbeat", timeout=3)
                if response.status_code == 200:
                    break
            except Exception:
                time.sleep(1)
        else:
            proc.terminate()
            pytest.fail("Server did not respond to heartbeat within 60s")
        yield
    finally:
        proc.terminate()
        proc.wait()


def _post_sample_rows(include_new_field: bool = False) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for _ in range(3):
        record: Dict[str, Any] = {
            "date": pd.Timestamp.utcnow().tz_localize(None),
            "symbol": "TEST",
            "test": 123.45,
            "extra_field": "Hello World",
            "extra_nested_field": {"a": 1, "b": 2},
            "extra_list_field": [1, 2, 3, 4, 5],
        }
        if include_new_field:
            record["new_field"] = pd.Timestamp("2024-10-13")
        rows.append(record)
        time.sleep(0.001)

    ClientAPI.post_table(
        "MarketData",
        "RT",
        "TEST",
        "TEST_EXTEND/20251013",
        value=rows,
        is_schemaless=True,
        hasindex=False,
        endpoint=SERVER_URL,
    )
    return rows


def _fetch_rows() -> List[Dict[str, Any]]:
    return ClientAPI.get_table(
        "MarketData",
        "RT",
        "TEST",
        "TEST_EXTEND/20251013",
        load_all_pages=True,
        output_dataframe=False,
        endpoint=SERVER_URL,
    )


def _normalize_symbol(value: Any) -> str:
    return value.decode("utf-8") if isinstance(value, bytes) else value


def test_schemaless_table_extend(run_test_server):
    ClientAPI.delete_table(
        "MarketData",
        "RT",
        "TEST",
        "TEST_EXTEND/20251013",
        endpoint=SERVER_URL,
    )

    initial_rows = _post_sample_rows()
    fetched_initial = _fetch_rows()
    assert len(fetched_initial) == len(initial_rows)
    assert all("extra_nested_field" in row for row in fetched_initial)
    assert all("extra_list_field" in row for row in fetched_initial)

    extended_rows = _post_sample_rows(include_new_field=True)
    fetched_extended = _fetch_rows()

    assert len(fetched_extended) >= len(initial_rows) + len(extended_rows)
    assert any("new_field" in row for row in fetched_extended)

    expected_date = pd.Timestamp("2024-10-13")
    new_field_values = [
        row["new_field"]
        for row in fetched_extended
        if "new_field" in row and row["new_field"] is not None
    ]
    assert new_field_values, "Expected at least one row to contain new_field"

    for value in new_field_values:
        normalized_value = pd.Timestamp(value)
        assert normalized_value.normalize() == expected_date.normalize()

    for row in fetched_extended:
        symbol = _normalize_symbol(row.get("symbol"))
        assert symbol == "TEST"