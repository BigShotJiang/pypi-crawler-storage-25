"""Truva — Data curation engine for LLM fine-tuning."""

__version__ = "0.1.0"
