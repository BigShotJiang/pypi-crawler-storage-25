"""
VaultLayer — Compute Tier Markup Engine

Markup is tiered based on what the platform is actually doing for the user
on each leg. The harder we work, the more we earn.

──────────────────────────────────────────────────────────────────────────────
TIER 1 — "Standard"                                               20% markup
  Widely available GPUs. Platform routes to cheapest node.
  Classification: market price < $5/hr OR high availability across providers.
  Static fallback: A10G, A40, RTX4090, RTX3090, L40S, A6000, V100, T4
  Example: RunPod A10G at $1.00/hr → user billed $1.20/hr

TIER 2 — "Scarcity"                                               30% markup
  Premium/scarce GPUs that the platform sourced via multi-cloud procurement.
  Classification: market price >= $5/hr OR low availability across providers.
  Static fallback: H100_*, H200, B200
  Example: CoreWeave H100 at $2.50/hr → user billed $3.25/hr

TIER 3 — "Failover"                                               40% markup
  Applied when:
    a) failover_enabled=True (user opted in at job start), OR
    b) Any leg created by execute_migration() (interrupted/hot-swapped).
  Overrides GPU-based tier — the orchestration is what we're billing.
  Example: A10G fallback leg at $1.00/hr → user billed $1.40/hr
──────────────────────────────────────────────────────────────────────────────

Dynamic tier classification uses live market data from the Pricing Agent.
When market data is unavailable (cold start), falls back to static GPU sets.

AWS On-Demand comparison always shown to anchor price perception,
regardless of tier. Native users still see they're far below hyperscaler rates.
"""
from __future__ import annotations

# ── Tier definitions (from config/vaultlayer_data.json, overridable via env vars) ──
# Override at runtime: VL_TIER1_MARKUP=0.25 VL_TIER2_MARKUP=0.35 VL_TIER3_MARKUP=0.45

def _load_tier_config():
    """Load tier config from data JSON with env var overrides."""
    try:
        from shared.data_loader import get_tier_config
        return get_tier_config()
    except Exception:
        return {"tier_1_markup": 0.20, "tier_2_markup": 0.30,
                "tier_3_markup": 0.40, "scarcity_price_threshold": 5.00}

_tc = _load_tier_config()
TIER_1_MARKUP = _tc.get("tier_1_markup", 0.20)
TIER_2_MARKUP = _tc.get("tier_2_markup", 0.30)
TIER_3_MARKUP = _tc.get("tier_3_markup", 0.40)
SCARCITY_PRICE_THRESHOLD = _tc.get("scarcity_price_threshold", 5.00)

# ── Static fallback sets (used when market data is unavailable) ───────────────
# These are the "cold start" defaults. Once the Pricing Agent has run at least
# one poll cycle, market-based classification takes precedence.

TIER_2_GPUS = {
    "H100",
    "H100_PCIE",
    "H100_80GB_SXM",
    "H100_80GB_PCIE",
    "H100_80GB_NVL",
    "GH200",
    "H200",
    "B200",
    # A100 is borderline — static fallback keeps it in Tier 2 for safety,
    # but market classification may move it to Tier 1 if prices drop.
    "A100",
    "A100_40",
    "A100_80GB_SXM",
    "A100_40GB",
}

# Tier 1 is the default for everything else:
# A10G, A40, A6000, RTX4090, RTX3090, L40S, V100, T4, etc.

# Human-readable labels shown on invoices and in the UI
TIER_LABELS = {
    1: "Standard",
    2: "Scarcity",
    3: "Failover",
}

# AWS On-Demand reference rates ($/hr per GPU) — from config/vaultlayer_data.json
# Used for UI anchoring in all billing models (savings comparison)
def _load_aws_od_rates() -> dict[str, float]:
    try:
        from shared.data_loader import get_aws_od_rates
        rates = get_aws_od_rates()
        if rates:
            return rates
    except Exception:
        pass
    # Fallback if JSON not available
    return {"H100": 12.29, "A100": 4.10, "A10G": 3.21}

AWS_OD_RATES: dict[str, float] = _load_aws_od_rates()


def classify_gpu_tier_from_market(
    gpu_type: str,
    median_price: float,
    low_availability_ratio: float = 0.0,
) -> tuple[int, float, str]:
    """
    Dynamically classify a GPU into Tier 1 (Standard) or Tier 2 (Scarcity)
    based on live market data from the Pricing Agent.

    Args:
        gpu_type:               GPU type string (e.g. "H100_80GB_SXM")
        median_price:           Median $/hr across all available providers
        low_availability_ratio: Fraction of providers where this GPU is "low"
                                or "unavailable" (0.0 = everywhere available,
                                1.0 = nowhere available)

    Returns:
        (tier_num, markup, label) tuple — Tier 1 or Tier 2 only.
        Tier 3 is never returned here; it's applied by get_leg_tier() when
        failover_enabled=True or is_hop_leg=True.
    """
    # Scarcity: expensive OR hard to find
    if median_price >= SCARCITY_PRICE_THRESHOLD or low_availability_ratio > 0.5:
        return 2, TIER_2_MARKUP, TIER_LABELS[2]
    return 1, TIER_1_MARKUP, TIER_LABELS[1]


def get_job_tier(
    gpu_types: list[str],
    leg_count: int,
) -> tuple[int, float, str]:
    """
    Return the tier for the ENTIRE job (not per-leg).

    Tier is determined once at invoice time:
      - leg_count > 1 → Tier 3 (Failover). Platform managed at least
        one live migration. ALL legs bill at 40% regardless of GPU. The migration
        event itself shows as $0.00 — the premium covers the orchestration cost.
      - Any leg used a Tier 2 GPU → Tier 2 (Scarcity, 30%).
      - Otherwise → Tier 1 (Standard, 20%).

    Args:
        gpu_types:  List of GPU type strings, one per leg.
        leg_count:  Total number of legs (nodes) the job ran on.
    """
    if leg_count > 1:
        return 3, TIER_3_MARKUP, TIER_LABELS[3]

    if any(g in TIER_2_GPUS for g in gpu_types):
        return 2, TIER_2_MARKUP, TIER_LABELS[2]

    return 1, TIER_1_MARKUP, TIER_LABELS[1]


def get_leg_tier(
    gpu_type: str,
    is_hop_leg: bool,
    failover_enabled: bool = True,
    market_tier: int | None = None,
) -> tuple[int, float, str]:
    """
    Per-leg tier assignment. Called at provision time to set vl_margin_pct
    on the spend_ledger row so settle_instance() applies the correct markup.

    Priority:
      1. failover_enabled=True OR is_hop_leg → Tier 3 (40%)
      2. market_tier provided (from Pricing Agent) → use that
      3. Static TIER_2_GPUS fallback → Tier 2 if GPU is in the set
      4. Default → Tier 1 (20%)
    """
    if is_hop_leg or failover_enabled:
        return 3, TIER_3_MARKUP, TIER_LABELS[3]
    if market_tier is not None:
        if market_tier == 2:
            return 2, TIER_2_MARKUP, TIER_LABELS[2]
        return 1, TIER_1_MARKUP, TIER_LABELS[1]
    if gpu_type in TIER_2_GPUS:
        return 2, TIER_2_MARKUP, TIER_LABELS[2]
    return 1, TIER_1_MARKUP, TIER_LABELS[1]


def get_aws_od_rate(gpu_type: str) -> float:
    """Return AWS On-Demand $/hr for anchoring user-facing price comparison."""
    return AWS_OD_RATES.get(gpu_type, 0.0)


def markup_description(
    gpu_type: str,
    tier_num: int,
    tier_label: str,
    provider_rate: float,
    user_rate: float,
) -> str:
    """
    Return the one-line billing description shown on the invoice leg.
    Always anchors against AWS OD even for native cost_plus users.
    """
    aws_od = get_aws_od_rate(gpu_type)
    anchor = f"  |  AWS OD: ${aws_od:.2f}/hr" if aws_od > 0 else ""
    return (
        f"Tier {tier_num} — {tier_label}  "
        f"(provider ${provider_rate:.4f}/hr → your rate ${user_rate:.4f}/hr{anchor})"
    )
