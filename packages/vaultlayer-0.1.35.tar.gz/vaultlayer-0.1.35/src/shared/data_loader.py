"""
VaultLayer -- Data Loader
Single import point for all data tables (prices, GPU profiles).
All numbers live in config/vaultlayer_data.json -- not here.

Usage:
    from shared.data_loader import get_provider_prices, get_gpu_profiles, recommend_gpu
"""

import json
import os
import time
import logging
import threading
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_cache_lock = threading.Lock()

# Resolve config/vaultlayer_data.json relative to the repo root
# Works whether you run from src/ or from the repo root
_POSSIBLE_PATHS = [
    Path(__file__).parent / "vaultlayer_data.json",
    Path(__file__).parent.parent.parent / "config" / "vaultlayer_data.json",
    Path(__file__).parent.parent / "config" / "vaultlayer_data.json",
    Path("config/vaultlayer_data.json"),
]

_cache: Optional[dict] = None
_cache_loaded_at: float = 0.0

# TTL after which the in-process cache is re-read from disk. Each Python
# worker has its own `_cache`; without TTL a worker that happened to load
# the file at a moment when the config was partly written / being rewritten
# stays wrong forever. Observed on Railway 2026-04-21: Lambda Labs
# intermittently rejected with "not_in_included_providers" because half the
# workers had a stale in-process cache that pre-dated the allowlist addition.
# 60s is the right order of magnitude — long enough to matter for hot paths
# (pricing iteration during dispatch), short enough that a config rollout
# heals itself within a deploy window.
_CACHE_TTL_SECONDS = int(os.environ.get("VL_DATA_CACHE_TTL_SECONDS", "60"))


def _load() -> dict:
    """Load + cache the data file with a short TTL (see _CACHE_TTL_SECONDS)."""
    global _cache, _cache_loaded_at
    now = time.time()
    if _cache is not None and (now - _cache_loaded_at) < _CACHE_TTL_SECONDS:
        return _cache
    with _cache_lock:
        # Re-check under lock — another thread may have reloaded.
        if _cache is not None and (time.time() - _cache_loaded_at) < _CACHE_TTL_SECONDS:
            return _cache
        for p in _POSSIBLE_PATHS:
            if p.exists():
                with open(p) as f:
                    _cache = json.load(f)
                _cache_loaded_at = time.time()
                logger.debug(f"Loaded VaultLayer data from {p} (updated: {_cache['_meta'].get('last_updated','?')})")
                return _cache
        # Fallback: empty structure so callers don't crash. Don't cache-pin
        # this — the next TTL tick should retry.
        logger.warning("config/vaultlayer_data.json not found -- using empty data tables")
        _cache = {"provider_prices": {}, "gpu_profiles": {"tiers": []}, "gpu_aliases": {}}
        _cache_loaded_at = time.time()
        return _cache


def get_provider_prices() -> dict:
    """Return provider_prices dict keyed by provider name -> {GPU: price}."""
    return _load().get("provider_prices", {})


def get_gpu_aliases() -> dict:
    """Return gpu_aliases dict (normalises user input to canonical GPU key)."""
    return _load().get("gpu_aliases", {})


def get_gpu_profiles() -> list:
    """Return list of GPU tier dicts with qlora/lora/full VRAM requirements."""
    return _load().get("gpu_profiles", {}).get("tiers", [])



def get_instance_maps() -> dict:
    """Return provider_instance_maps -- {provider: {gpu_key: instance_string}}."""
    return _load().get("provider_instance_maps", {})


def get_instance_string(provider: str, gpu_key: str) -> str:
    """
    Return the provider-specific instance/type string for a GPU.
    gpu_key should be the canonical short form: H100, A100, A100_40, A10G, etc.
    Returns empty string if not found (caller should handle gracefully).

    Example:
        get_instance_string("RunPod", "H100") -> "NVIDIA H100 80GB HBM3"
        get_instance_string("Vast.ai", "B200") -> ""  # B200 not yet configured
    """
    maps = get_instance_maps()
    return maps.get(provider, {}).get(gpu_key, "")


def resolve_gpu_key(gpu_type_str: str) -> str:
    """
    Convert a GPUType enum value string to the canonical short key.
    "H100_80GB_SXM" -> "H100", "A100_40GB" -> "A100_40", etc.
    Falls back to checking gpu_aliases, then splits on _ and takes first 2 parts.
    """
    aliases = get_gpu_aliases()
    # Try direct alias lookup first
    if gpu_type_str in aliases:
        return aliases[gpu_type_str]
    # Try stripping common suffixes: H100_80GB_SXM -> H100
    short = gpu_type_str.split("_")[0]
    if short in aliases:
        return aliases[short]
    # A100_40GB -> A100_40
    if "40GB" in gpu_type_str:
        return "A100_40"
    return short


def resolve_gpu_enum(gpu_type_str: str, *, strict: bool = False):
    """Convert a GPU string (pricing key or alias) to a GPUType enum value.

    Handles: "H100" -> GPUType.H100_80GB_SXM, "A100_40" -> GPUType.A100_40GB, etc.
    Returns GPUType.A10G as fallback if nothing matches unless strict=True.

    Use this EVERYWHERE instead of inline _gpu_enum_map dicts.
    """
    from shared.models import GPUType

    # Direct match
    try:
        return GPUType(gpu_type_str)
    except ValueError:
        pass

    # Common pricing-key to enum mappings
    _MAP = {
        "A100_40": "A100_40GB", "A100": "A100_80GB_SXM",
        "H100": "H100_80GB_SXM", "H100_PCIE": "H100_80GB_PCIE",
        "V100": "V100_16GB",
        "RTX5090": "RTX5090",
        "GH200": "GH200",
        "H200": "H200",
        "B200": "B200",
    }
    mapped = _MAP.get(gpu_type_str)
    if mapped:
        try:
            return GPUType(mapped)
        except ValueError:
            pass

    # Try aliases
    resolved_key = resolve_gpu_key(gpu_type_str)
    try:
        return GPUType(resolved_key)
    except ValueError:
        pass
    mapped2 = _MAP.get(resolved_key)
    if mapped2:
        try:
            return GPUType(mapped2)
        except ValueError:
            pass

    if strict:
        raise ValueError(f"Unknown GPU type: {gpu_type_str}")
    return GPUType.A10G  # legacy fallback


def is_gpu_available(provider: str, gpu_key: str) -> bool:
    """
    Check if a GPU is currently available at a provider.
    Returns False if:
      - price is null  (GPU went unavailable, PricingAgent set it to null)
      - price is missing from the JSON entirely
      - provider is not tracked
    Returns True only if price is a positive number.

    This is the single availability check used by BrokerAgent before provisioning.
    No separate availability poll needed -- price absent = unavailable.
    """
    prices = get_provider_prices()
    price = prices.get(provider, {}).get(gpu_key)
    return isinstance(price, (int, float)) and price > 0


def get_available_providers_for_gpu(gpu_key: str) -> list:
    """
    Return list of provider names that currently have a non-null price for gpu_key.
    Used by Orchestration Agent to build the candidate list for job routing.
    """
    prices = get_provider_prices()
    return [
        p for p, gpus in prices.items()
        if not p.startswith("_") and isinstance(gpus.get(gpu_key), (int, float)) and gpus[gpu_key] > 0
    ]


def get_provider_meta() -> dict:
    """Return provider_meta dict with access requirements per provider."""
    return _load().get("provider_meta", {})


def is_provider_accessible(provider: str) -> bool:
    # NOTE: does NOT check capacity -- use is_provider_available_for_new_job() for that.
    """
    Return True if this provider can be used right now.
    A provider is inaccessible if:
      - requires_application is True AND its env_key is not set in the environment
    This prevents Voltage Park (invitation-only) from appearing in recommendations
    or find_opportunities() unless the user actually has a key configured.

    Example:
        is_provider_accessible("Voltage Park")  # False if VOLTAGE_PARK_API_KEY unset
        is_provider_accessible("RunPod")        # True (no application required)
    """
    import os
    meta = get_provider_meta()
    info = meta.get(provider, {})
    if not info.get("requires_application", False):
        return True  # open signup -- always accessible
    env_key = info.get("env_key", "")
    return bool(env_key and os.environ.get(env_key, "").strip())


def get_accessible_providers_for_gpu(gpu_key: str) -> list:
    """
    Like get_available_providers_for_gpu() but also filters out providers
    that require application/approval unless their API key is configured.
    This is the correct function to use for pre-flight recommendations.
    """
    return [
        p for p in get_available_providers_for_gpu(gpu_key)
        if is_provider_accessible(p)
    ]


def is_provider_available_for_new_job(provider: str) -> bool:
    """
    Full availability check for routing a NEW job to a provider.
    Returns False if:
      - Provider requires operator account and env key is not set
      - Provider is at its concurrent job capacity threshold
    Returns True only when both checks pass.

    This is the function to use in find_opportunities() and pre-flight.
    is_provider_accessible() only checks the operator key -- use this instead.
    """
    if not is_provider_accessible(provider):
        return False
    try:
        from shared.provider_capacity import is_provider_at_capacity
        if is_provider_at_capacity(provider):
            return False
    except ImportError:
        pass  # capacity guard not available -- allow all
    return True

def get_meta() -> dict:
    """Return _meta block (last_updated, update_notes)."""
    return _load().get("_meta", {})


def get_included_providers() -> list[str]:
    """Return the dispatcher's allowlist of provider display names.

    ONLY providers in this list are considered for provisioning + retry.
    Anything else (even priced in provider_prices) is treated as 'pending'
    and rejected at submit time. Source of truth: included_providers.providers
    in config/vaultlayer_data.json.

    Returns an empty list if the key is missing — callers MUST treat empty
    as "no allowlist configured" (legacy behavior: consider all priced
    providers). The current config sets it explicitly; emptiness is not
    expected in prod.
    """
    return list(_load().get("included_providers", {}).get("providers", []) or [])


def get_pending_providers() -> list[str]:
    """Return the parallel 'pending validation' list — providers that exist
    in price config but are not yet allowed by the dispatcher.

    Used by the submit-time validator to give a clearer 'X is currently in
    pending validation, included providers are: Y, Z' error.
    """
    return list(_load().get("included_providers", {}).get("pending", []) or [])


def get_testing_providers() -> list[str]:
    """Return the 'internal testing' list — providers that test users may
    name in preferred_providers, but regular users may not.

    Test users are identified via the VL_TEST_USER_IDS env var (comma-
    separated user_ids). Testing providers are NEVER added to a regular
    user's failover candidate pool — so a broken testing provider can't
    leak into production traffic. See user_can_use_testing_providers()
    in this module.

    Source of truth: included_providers.testing in config/vaultlayer_data.json.
    Returns [] if the key is missing (back-compat with the old two-state config).
    """
    return list(_load().get("included_providers", {}).get("testing", []) or [])


def get_test_user_ids() -> set[str]:
    """Return the set of user_ids permitted to route to `testing` providers.

    Source: VL_TEST_USER_IDS env var, comma-separated. Trimmed; empty
    entries dropped. Returns an empty set if unset, which means NO user
    can use testing providers (safe default).

    Example: `VL_TEST_USER_IDS=tester-vaulttester,vl-staging-bot`
    """
    import os
    raw = os.environ.get("VL_TEST_USER_IDS", "")
    return {x.strip() for x in raw.split(",") if x.strip()}


def user_can_use_testing_providers(user_id: str) -> bool:
    """True if `user_id` is allowed to name `testing`-state providers in
    preferred_providers and to have them included in failover candidate pool.
    """
    return bool(user_id) and user_id in get_test_user_ids()


def get_routable_regions() -> list[dict]:
    """Return list of region dicts {code, location, gpus} from routable_regions.regions.

    This is the canonical set of region codes the dispatcher can target. Used by:
      - src/cli/data.py:regions_list_all() for `vaultlayer regions list-all`
      - src/shared/suggestions.py:get_suggestions() for expand-consent UX
      - submit-flow validation to reject regions outside this set
    """
    return _load().get("routable_regions", {}).get("regions", [])


def get_routable_region_codes() -> list[str]:
    """Return just the region codes (sorted) from routable_regions."""
    return sorted(r["code"] for r in get_routable_regions() if "code" in r)


def get_region_adjacency() -> dict[str, list[str]]:
    """Return adjacency map {region_code: [nearby_region_codes]} for expand-consent suggestions."""
    raw = _load().get("region_adjacency", {})
    return {k: v for k, v in raw.items() if not k.startswith("_") and isinstance(v, list)}


def recommend_gpu(params_b: float, train_mode: str = "qlora") -> tuple:
    """
    Recommend a GPU based on model size and training mode.

    Args:
        params_b:   Model size in billions of parameters
        train_mode: "qlora" | "lora" | "full"  (default: qlora)

    Returns:
        (gpu_type: str, vram_gb: int, reason: str, multi_gpu: int)
    """
    mode = train_mode.lower().replace("-", "").replace("_", "")
    if mode not in ("qlora", "lora", "full"):
        mode = "qlora"

    tiers = get_gpu_profiles()
    for tier in tiers:
        if params_b <= tier["params_max_b"]:
            m = tier.get(mode, tier.get("qlora", {}))
            gpu   = m.get("gpu", "H100_80GB_SXM")
            vram  = m.get("vram_gb", 80)
            note  = m.get("note", "")
            multi = m.get("multi_gpu", 1)
            reason = f"{tier['label']} model ({mode}): needs ~{vram}GB VRAM. {note}".strip()
            return gpu, vram, reason, multi

    # 72B+ fallback
    return "H200", 160, "Large model -- use high-memory GPU capacity for QLoRA", 2


def reload():
    """Force a reload of the data file (useful after manual edits). Thread-safe."""
    global _cache
    with _cache_lock:
        _cache = None
    return _load()


# ── Dynamic configuration accessors (env var overrides supported) ────────────

def get_egress_rates() -> dict[str, float]:
    """Return egress rates in $/GB. Env vars VL_EGRESS_AWS_S3 etc. override JSON."""
    data = _load()
    rates = dict(data.get("egress_rates", {}))
    # Env var overrides
    for key in ["aws_s3", "gcp_gcs", "azure_blob", "r2", "aws_cross_az"]:
        env = os.environ.get(f"VL_EGRESS_{key.upper()}")
        if env:
            rates[key] = float(env)
    return {k: v for k, v in rates.items() if not k.startswith("_") and isinstance(v, (int, float))}


def get_aws_od_rates() -> dict[str, float]:
    """Return AWS On-Demand $/hr per GPU (for savings comparison on invoices)."""
    data = _load()
    rates = data.get("aws_on_demand_rates", {})
    return {k: v for k, v in rates.items() if not k.startswith("_") and isinstance(v, (int, float))}


def get_aws_od_rate(gpu_key: str) -> float:
    """Get AWS On-Demand rate for a specific GPU. Returns 0 if not found."""
    rates = get_aws_od_rates()
    # Try direct match, then resolve alias
    if gpu_key in rates:
        return rates[gpu_key]
    resolved = resolve_gpu_key(gpu_key)
    return rates.get(resolved, 0.0)


def get_tier_config() -> dict:
    """Return tier markup config. Env vars VL_TIER1_MARKUP etc. override JSON."""
    data = _load()
    cfg = dict(data.get("tier_config", {
        "tier_1_markup": 0.20, "tier_2_markup": 0.30,
        "tier_3_markup": 0.40, "scarcity_price_threshold": 5.00,
    }))
    overrides = {
        "VL_TIER1_MARKUP": "tier_1_markup",
        "VL_TIER2_MARKUP": "tier_2_markup",
        "VL_TIER3_MARKUP": "tier_3_markup",
        "VL_SCARCITY_THRESHOLD": "scarcity_price_threshold",
    }
    for env, key in overrides.items():
        val = os.environ.get(env)
        if val:
            cfg[key] = float(val)
    return cfg


def get_operational_config() -> dict:
    """Return operational thresholds. Env vars override JSON values."""
    data = _load()
    cfg = dict(data.get("operational", {
        "auto_migrate_savings_pct": 25.0,
        "migration_cooldown_secs": 21600,
        "payback_threshold_hours": 10.0,
        "pricing_margin": 1.15,
        "arbitrage_threshold": 10.0,
    }))
    overrides = {
        "VL_AUTO_MIGRATE_PCT": "auto_migrate_savings_pct",
        "VL_MIGRATION_COOLDOWN_SECS": "migration_cooldown_secs",
        "VL_PAYBACK_THRESHOLD_HRS": "payback_threshold_hours",
        "VL_PRICING_MARGIN": "pricing_margin",
        "VL_ARBITRAGE_THRESHOLD": "arbitrage_threshold",
    }
    for env, key in overrides.items():
        val = os.environ.get(env)
        if val:
            cfg[key] = float(val)
    return cfg


def invalidate_cache():
    """Called by pricing agent after writing new data to JSON."""
    global _cache
    with _cache_lock:
        _cache = None
