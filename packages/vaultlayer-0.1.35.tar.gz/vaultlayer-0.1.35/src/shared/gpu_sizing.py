"""Shared GPU sizing and fallback policy.

This module is intentionally dependency-light. It is imported by the CLI,
API submit path, and worker, so it must not load data tables or provider SDKs
at import time.
"""
from __future__ import annotations

import math
import re
import shlex
from collections import deque
from typing import Callable, Optional


# VRAM capacity (GB) for canonical GPUType values and pricing-cache keys.
# Ambiguous short keys are conservative. For example, provider price key
# "A100" can mean a 40GB Lambda/AWS shape, so the short key is treated as 40GB.
GPU_VRAM_GB: dict[str, float] = {
    "H100_80GB_SXM": 80.0,
    "H100_80GB_PCIE": 80.0,
    "H100_80GB_NVL": 80.0,
    "H100": 80.0,
    "H100_PCIE": 80.0,
    "H200": 141.0,
    "GH200": 96.0,
    "B200": 192.0,
    "A100_80GB_SXM": 80.0,
    "A100_40GB": 40.0,
    "A100_40": 40.0,
    "A100": 40.0,
    "L40S": 48.0,
    "L40": 48.0,
    "A40": 48.0,
    "A6000": 48.0,
    "A10G": 24.0,
    "A10": 24.0,
    "RTX5090": 32.0,
    "RTX4090": 24.0,
    "RTX3090": 24.0,
    "V100_16GB": 16.0,
    "V100": 16.0,
    "T4": 16.0,
}


# Fallback adjacency list used for auto-selected GPU correction and capacity
# retries. Keep this graph VRAM-monotonic enough that low-VRAM consumer GPUs
# reach 40GB/80GB production shapes quickly.
GPU_FALLBACK_CHAIN: dict[str, list[str]] = {
    "H100_80GB_SXM": ["H100_80GB_PCIE", "H100_80GB_NVL", "A100_80GB_SXM", "H100", "GH200", "H200", "B200", "A10G"],
    "H100_80GB_PCIE": ["H100_80GB_SXM", "H100_80GB_NVL", "A100_80GB_SXM", "H100", "GH200", "H200", "B200", "A10G"],
    "H100_80GB_NVL": ["H100_80GB_SXM", "H100_80GB_PCIE", "A100_80GB_SXM", "H100", "GH200", "H200", "B200", "A10G"],
    "H100": ["H100_80GB_SXM", "H100_80GB_PCIE", "H100_80GB_NVL", "A100_80GB_SXM", "GH200", "H200", "B200", "A10G"],
    "H100_PCIE": ["H100_80GB_PCIE", "H100_80GB_SXM", "A100_80GB_SXM", "H100", "GH200"],
    "H200": ["H100", "H100_80GB_SXM", "B200", "A100_80GB_SXM"],
    "GH200": ["H100", "H100_80GB_SXM", "H200", "B200"],
    "B200": ["H100", "H200", "A100_80GB_SXM"],
    "A100_80GB_SXM": ["H100", "H100_80GB_SXM", "A100_40GB", "A10G", "L40S", "A40"],
    "A100_40GB": ["L40S", "A40", "A100", "A100_40", "H100", "H100_80GB_SXM"],
    "A100_40": ["A100_40GB", "L40S", "A40", "H100"],
    "A100": ["A100_40GB", "L40S", "A40", "H100", "H100_80GB_SXM"],
    "L40S": ["A40", "A100_40GB", "A100", "H100"],
    "L40": ["L40S", "A40", "A100_40GB"],
    "A40": ["L40S", "A100_40GB", "A100", "H100"],
    "A6000": ["A40", "L40S", "A100_40GB"],
    "A10G": ["A40", "L40S", "A100_40GB", "H100"],
    "A10": ["A10G", "A40", "L40S", "A100_40GB"],
    "RTX4090": ["RTX5090", "A10G", "A40", "L40S", "A100_40GB", "H100"],
    "RTX3090": ["RTX4090", "RTX5090", "A10G", "A40", "L40S", "A100_40GB", "H100"],
    "RTX5090": ["A40", "L40S", "A100_40GB", "H100"],
    "V100_16GB": ["A10G", "A40", "L40S", "A100_40GB"],
    "V100": ["V100_16GB", "A10G", "A40", "L40S"],
    "T4": ["A10G", "A40", "L40S", "A100_40GB"],
}


def normalize_training_mode(training_mode: str | None) -> str:
    mode = (training_mode or "qlora").strip().lower()
    if mode in {"qlora", "q-lora", "4bit", "4-bit"}:
        return "qlora"
    if mode in {"lora", "peft"}:
        return "lora"
    if mode in {"full", "full-finetune", "full_finetune", "finetune", "fine-tune"}:
        return "full"
    return "qlora"


def min_vram_for_model(model_params_billion: float, training_mode: str = "qlora") -> float:
    """Return minimum single-GPU VRAM in GB for a model/training mode."""
    model_params = max(0.0, float(model_params_billion or 0.0))
    mode = normalize_training_mode(training_mode)
    if mode == "qlora":
        estimated = model_params * 0.5 + 4.0
        if model_params >= 70:
            return max(estimated, 96.0)
        if model_params > 34:
            return max(estimated, 80.0)
        if model_params >= 30:
            return max(estimated, 40.0)
        if model_params > 13:
            return max(estimated, 24.0)
        return estimated
    if mode == "lora":
        return model_params * 1.0 + 4.0
    return model_params * 2.0 + 8.0


def _round_up_gb(value: float, step_gb: int = 50) -> int:
    return int(math.ceil(float(value) / step_gb) * step_gb)


def disk_gb_for_model(model_params_billion: float | None, training_mode: str = "qlora") -> int:
    """Return recommended boot/container disk in GB for model downloads.

    VRAM sizing is not enough for large HF models: QLoRA still downloads the
    full sharded checkpoint before quantizing. A 72B model is roughly 140GB of
    safetensors, and Xet/HF cache needs extra temporary space while
    reconstructing shards. Keep <=13B jobs at the historical 100GB default and
    scale larger jobs conservatively in 50GB increments.
    """
    params = max(0.0, float(model_params_billion or 0.0))
    mode = normalize_training_mode(training_mode)
    if params <= 13:
        return 100
    if mode == "qlora":
        required = params * 2.5 + 100.0
    elif mode == "lora":
        required = params * 3.0 + 125.0
    else:
        required = params * 5.0 + 150.0
    return min(max(100, _round_up_gb(required)), 1000)


def gpu_vram_gb(gpu_type: str | None, unknown: float = float("inf")) -> float:
    if not gpu_type:
        return unknown
    return GPU_VRAM_GB.get(str(gpu_type), unknown)


def gpu_meets_vram(gpu_type: str | None, min_vram_gb: float) -> bool:
    return gpu_vram_gb(gpu_type) >= float(min_vram_gb or 0.0)


def bfs_gpu_fallback(
    start_gpu: str,
    min_vram_gb: float,
    check_candidate: Callable[[str], bool] | None = None,
) -> Optional[str]:
    """Find the nearest fallback GPU with enough VRAM.

    `check_candidate`, when supplied, must return True only for GPUs worth
    choosing in this context, such as those with a dispatchable provider.
    Low-VRAM nodes are skipped but their neighbors are still explored.
    """
    visited = {start_gpu}
    queue: deque[str] = deque(GPU_FALLBACK_CHAIN.get(start_gpu, []))
    while queue:
        candidate = queue.popleft()
        if candidate in visited:
            continue
        visited.add(candidate)
        if not gpu_meets_vram(candidate, min_vram_gb):
            for neighbor in GPU_FALLBACK_CHAIN.get(candidate, []):
                if neighbor not in visited:
                    queue.append(neighbor)
            continue
        if check_candidate is None or check_candidate(candidate):
            return candidate
        for neighbor in GPU_FALLBACK_CHAIN.get(candidate, []):
            if neighbor not in visited:
                queue.append(neighbor)
    return None


_MODEL_SIZE_RE = re.compile(r"(?<![A-Za-z0-9])(\d+(?:\.\d+)?)\s*[bB](?![A-Za-z0-9])")


def infer_model_params_billion(*texts: object) -> Optional[float]:
    """Infer model size from command/script/env text.

    Chooses the largest `NNB` token so a command containing both a model id
    like `Qwen2.5-32B-Instruct` and a generic script name like `3b_qlora.py`
    resolves to 32B.
    """
    found: list[float] = []
    for value in texts:
        if value is None:
            continue
        text = str(value)
        for match in _MODEL_SIZE_RE.finditer(text):
            try:
                found.append(float(match.group(1)))
            except ValueError:
                pass
        try:
            for token in shlex.split(text):
                if "=" in token:
                    _, rhs = token.split("=", 1)
                    for match in _MODEL_SIZE_RE.finditer(rhs):
                        try:
                            found.append(float(match.group(1)))
                        except ValueError:
                            pass
        except ValueError:
            pass
    return max(found) if found else None


def infer_training_mode(*texts: object, default: str = "qlora") -> str:
    joined = " ".join(str(t).lower() for t in texts if t is not None)
    if "qlora" in joined or "4bit" in joined or "4-bit" in joined:
        return "qlora"
    if "lora" in joined:
        return "lora"
    if "full" in joined:
        return "full"
    return normalize_training_mode(default)
