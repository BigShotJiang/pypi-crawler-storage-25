"""Upload user training scripts to R2 for onstart fetch (fixes issue #71).

Why this exists
----------------
Several providers cap the size of the onstart / UserData script they'll
accept from our API calls:

  * Vast.ai: `onstart` ≤ 16384 chars. Our 14 KB training script + VL
    bootstrap wrapper → rejected at bid time with `error 400/3471`.
  * AWS EC2 UserData: ≤ 16 KB (base64 encoded).
  * Other providers have no limit but we route through the same helper
    for uniformity.

Instead of embedding the user script inline (`VL_SCRIPT_B64` env var
carried in onstart), we:

  1. Upload the decoded script to R2 at `jobs/{job_id}/{script_name}`
  2. Generate a short-lived pre-signed URL (24 h default)
  3. Set `VL_SCRIPT_URL` on the container instead of `VL_SCRIPT_B64`
  4. The onstart shell script curls from the URL and execs it

Private customer code stays in our R2 (never in any repo, never in
provider logs beyond the signed URL which expires). The signed URL
is the only secret on the wire; exposure within the TTL only lets a
passive observer fetch the script, which they could already see in
the provider's onstart logs regardless.

API reference for pre-signed URLs with R2 (S3-compatible):
  https://developers.cloudflare.com/r2/api/s3/presigned-urls/
"""
from __future__ import annotations

import base64
import logging
import os
from typing import Optional

logger = logging.getLogger(__name__)


# Scripts smaller than this many *decoded* bytes stay inline — skipping the
# R2 round-trip for toy smokes that already fit under every provider's limit.
# Set just below Vast.ai's 16 KB onstart cap minus VL bootstrap overhead.
INLINE_THRESHOLD_BYTES = int(os.environ.get("VL_SCRIPT_INLINE_MAX", "4096"))

# Signed URL lifetime. Long enough to cover container boot + docker pull +
# any retry logic. Short enough that a leaked URL becomes useless before
# anyone can exploit it. 24 h also matches AWS S3's max presigned-URL TTL
# for sig v4 via master-key auth (7 d requires STS-scoped creds).
SIGNED_URL_TTL_SECONDS = int(os.environ.get("VL_SCRIPT_URL_TTL", str(24 * 3600)))

# The bucket we upload to. Distinct from vaultlayer-checkpoints (training
# state) and vaultlayer-namespace (datasets) so lifecycle policy can
# differ. Recommended R2 lifecycle: delete after 30 days.
#
# Fallback chain: R2_JOBS_BUCKET → R2_BUCKET (checkpoint bucket, different
# key prefix so no collision) → hard-coded default. R2_BUCKET is always set
# on Railway (vault agent uses it); R2_JOBS_BUCKET is optional. This avoids
# the "vaultlayer-jobs bucket doesn't exist yet" failure that caused AWS
# InvalidUserData.Malformed on the first job run.
JOBS_BUCKET = (
    os.environ.get("R2_JOBS_BUCKET")
    or os.environ.get("R2_BUCKET")
    or "vaultlayer-jobs"
)


# Module-scoped last-failure detail so the caller can surface it to
# the job record. Set by upload_script_and_sign on any non-success exit.
# Read once per submit; overwritten by the next upload attempt. This is
# a pragmatic alternative to Railway log access during prod debugging.
LAST_UPLOAD_ERROR: str = ""


def should_route_via_r2(script_b64: str) -> bool:
    """Decide whether this script needs R2 routing.

    Returns True if the decoded script exceeds INLINE_THRESHOLD_BYTES —
    in which case the caller should upload to R2 and use VL_SCRIPT_URL.
    Returns False for tiny scripts; caller uses the legacy VL_SCRIPT_B64
    inline path which is a cheaper single-hop.
    """
    if not script_b64:
        return False
    try:
        decoded_len = len(base64.b64decode(script_b64))
    except Exception:
        decoded_len = len(script_b64) * 3 // 4  # rough estimate
    return decoded_len > INLINE_THRESHOLD_BYTES


def upload_script_and_sign(
    job_id: str,
    script_b64: str,
    script_name: str = "script.py",
    ttl_seconds: int = SIGNED_URL_TTL_SECONDS,
) -> Optional[str]:
    """Upload the user script to R2 and return a pre-signed GET URL.

    Returns the signed URL on success, or None if:
      - R2 credentials aren't configured (caller should fall back to inline)
      - The upload fails for any reason

    Non-fatal: the caller MUST handle None by using the inline VL_SCRIPT_B64
    path. We never break provisioning if R2 is transiently down.
    """
    global LAST_UPLOAD_ERROR
    LAST_UPLOAD_ERROR = ""

    if not script_b64:
        LAST_UPLOAD_ERROR = "empty script_b64"
        return None

    endpoint = os.environ.get("R2_ENDPOINT", "") or os.environ.get("CLOUDFLARE_R2_ENDPOINT", "")
    access_key = os.environ.get("R2_ACCESS_KEY_ID", "") or os.environ.get("CLOUDFLARE_R2_ACCESS_KEY_ID", "")
    secret_key = os.environ.get("R2_SECRET_ACCESS_KEY", "") or os.environ.get("CLOUDFLARE_R2_SECRET_ACCESS_KEY", "")
    if not (endpoint and access_key and secret_key):
        missing = [
            n for n, v in (("R2_ENDPOINT", endpoint),
                           ("R2_ACCESS_KEY_ID", access_key),
                           ("R2_SECRET_ACCESS_KEY", secret_key)) if not v
        ]
        LAST_UPLOAD_ERROR = f"R2 creds missing: {','.join(missing)}"
        logger.debug(f"[script_upload] {LAST_UPLOAD_ERROR} — falling back to inline script path")
        return None

    # Normalize script_name so the extension survives (.py vs .sh etc.)
    safe_name = _sanitize_name(script_name)
    key = f"jobs/{job_id}/{safe_name}"

    try:
        import boto3
        from botocore.client import Config
        from botocore.exceptions import ClientError
        s3 = boto3.client(
            "s3",
            endpoint_url=endpoint,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            config=Config(signature_version="s3v4"),
            region_name="auto",
        )

        _ensure_bucket(s3, JOBS_BUCKET)

        payload = base64.b64decode(script_b64)
        s3.put_object(
            Bucket=JOBS_BUCKET,
            Key=key,
            Body=payload,
            ContentType=_content_type_for(safe_name),
            Metadata={
                "vaultlayer-job-id": job_id,
                "original-name":     script_name[:128],
            },
        )
        url = s3.generate_presigned_url(
            "get_object",
            Params={"Bucket": JOBS_BUCKET, "Key": key},
            ExpiresIn=ttl_seconds,
        )
        logger.info(
            f"[script_upload] uploaded {len(payload)}B to "
            f"{JOBS_BUCKET}/{key}, signed URL valid {ttl_seconds}s"
        )
        return url
    except Exception as e:
        LAST_UPLOAD_ERROR = f"{type(e).__name__}: {str(e)[:200]}"
        logger.warning(
            f"[script_upload] R2 upload failed for job {job_id} "
            f"(bucket={JOBS_BUCKET}, endpoint={endpoint}): {LAST_UPLOAD_ERROR}"
        )
        return None


def _ensure_bucket(s3_client, bucket_name: str) -> None:
    """Idempotently ensure `bucket_name` exists on the S3/R2 endpoint.

    No-ops when head_bucket already succeeds. Creates the bucket when
    head_bucket raises 404 / NoSuchBucket. Tolerates the common race where
    a concurrent worker creates the bucket between our head and create —
    R2 and S3 both surface that as BucketAlreadyOwnedByYou.

    Any other error (permission denied, network fail, etc.) propagates.
    """
    from botocore.exceptions import ClientError
    try:
        s3_client.head_bucket(Bucket=bucket_name)
        return
    except ClientError as head_err:
        code = (head_err.response.get("Error", {}) or {}).get("Code", "")
        # S3 uses "404" or "NoSuchBucket"; R2 has sometimes returned
        # "NoSuchBucket" with HTTP 404 in the envelope. We tolerate both.
        if code not in ("404", "NoSuchBucket", "NotFound"):
            raise
    logger.info(f"[script_upload] creating missing bucket {bucket_name}")
    try:
        s3_client.create_bucket(Bucket=bucket_name)
    except ClientError as create_err:
        code = (create_err.response.get("Error", {}) or {}).get("Code", "")
        # Another worker raced us to the create — that's fine.
        if code in ("BucketAlreadyOwnedByYou", "BucketAlreadyExists"):
            return
        raise


def _sanitize_name(name: str) -> str:
    """Strip path traversal, keep a single filename with extension."""
    import re
    # Keep only the basename
    base = name.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    # Replace anything weird with dashes
    safe = re.sub(r"[^A-Za-z0-9._-]", "-", base)
    # Cap length; preserve extension if present
    if len(safe) > 128:
        ext = ""
        if "." in safe:
            stem, ext = safe.rsplit(".", 1)
            ext = "." + ext[:8]
        safe = safe[:128 - len(ext)] + ext
    return safe or "script.py"


def _content_type_for(filename: str) -> str:
    if filename.endswith(".py"):
        return "text/x-python"
    if filename.endswith(".sh"):
        return "text/x-shellscript"
    return "application/octet-stream"
