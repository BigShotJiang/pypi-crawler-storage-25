"""
VaultLayer — Pricing API Routes

GET  /api/v1/pricing/gpu                      All GPUs — live rates + AWS OD anchoring
GET  /api/v1/pricing/gpu/{gpu_type}           Single GPU — best rate, tier, comparison banner
GET  /api/v1/pricing/compare                  Job-cost estimate for N hours
GET  /api/v1/pricing/gpu/{gpu_type}/availability  Availability check + fallback offer
POST /api/v1/jobs/{job_id}/hop-consent        Record user consent for GPU hot-swap

Live rates are pulled from the Redis price cache written every 60s by PricingAgent.
AWS On-Demand rates come from compute_tiers.AWS_OD_RATES (updated manually).
Tier markup is determined by compute_tiers.get_job_tier().

GPU Hot-Swap flow:
  1. User requests H100 → GET /availability → H100 unavailable, A100 offered as fallback
  2. UI shows pre-flight modal with dynamic billing terms (A100 rate → H100 rate on swap)
  3. User accepts → POST /hop-consent → job starts on A100 at A100 rate
  4. PricingAgent detects H100 available → publishes GPU_HOP_AVAILABLE event
  5. OrchestrationAgent triggers BrokerAgent migration → hot-swap to H100
  6. Invoice shows two legs: A100 (N hours at $X/hr) + H100 (M hours at $Y/hr)

Pricing endpoints are public — no auth required.
Hop-consent endpoint requires a valid VaultLayer token.
"""
from __future__ import annotations

import json
import logging
import os
from typing import Optional

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel

from api.auth import require_auth

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/pricing", tags=["pricing"])

# Separate router for job-scoped hop endpoints (lives under /api/v1/jobs)
jobs_router = APIRouter(prefix="/api/v1/jobs", tags=["pricing"])


# ── Response models ───────────────────────────────────────────────────────────

class ProviderRate(BaseModel):
    provider: str
    region: str
    price_per_hour: float           # raw provider spot rate (what VaultLayer pays)
    vaultlayer_rate: float          # price_per_hour × (1 + tier_markup)
    availability: str               # "high" | "medium" | "low" | "unavailable"
    is_spot: bool


class GPUPriceResponse(BaseModel):
    gpu_type: str
    compute_tier: int               # 1, 2, or 3
    compute_tier_label: str         # "Raw Match" | "Scarcity Hunt" | "Zero-Downtime Hop"
    tier_markup_pct: int            # 20, 30, or 40
    best_provider_rate: float       # cheapest raw rate across all providers
    best_vaultlayer_rate: float     # best_provider_rate × (1 + markup)
    aws_od_rate: float              # AWS On-Demand reference (for anchoring)
    discount_vs_aws_pct: float      # how much cheaper than AWS OD
    providers: list[ProviderRate]   # all providers offering this GPU, sorted cheapest first
    cache_age_seconds: Optional[int]
    note: str                       # UI display string e.g. "includes failover & orchestration"


class AllGPUPricesResponse(BaseModel):
    gpus: list[GPUPriceResponse]
    cache_age_seconds: Optional[int]
    total_providers_polled: int


# ── Redis helper ──────────────────────────────────────────────────────────────

async def _get_cached_prices() -> tuple[list[dict], Optional[int]]:
    """
    Read the latest price cache from Redis.
    Returns (prices, cache_age_seconds). prices=[] if Redis unavailable.
    """
    redis_url = os.environ.get("UPSTASH_REDIS_URL", "") or os.environ.get("REDIS_URL", "")
    if not redis_url:
        return [], None

    try:
        import redis.asyncio as aioredis
        r = aioredis.from_url(redis_url, socket_connect_timeout=2, socket_timeout=2)
        raw = await r.get("vaultlayer:prices:latest")
        ttl = await r.ttl("vaultlayer:prices:latest")
        await r.aclose()

        if not raw:
            return [], None

        prices = json.loads(raw)
        # Cache TTL is 120s; age = 120 - remaining TTL
        cache_age = max(0, 120 - ttl) if ttl and ttl > 0 else None
        return prices, cache_age
    except Exception as e:
        logger.warning(f"[pricing] Redis unavailable: {e}")
        return [], None


def _build_gpu_response(
    gpu_type: str,
    provider_rows: list[dict],
    cache_age: Optional[int],
) -> GPUPriceResponse:
    """Build a GPUPriceResponse for one GPU type from its provider rows."""
    from shared.compute_tiers import get_job_tier, get_aws_od_rate

    # Determine tier based on GPU type alone (leg_count=1, no active migration)
    tier_num, tier_markup, tier_label = get_job_tier(
        gpu_types=[gpu_type],
        leg_count=1,
    )
    aws_od = get_aws_od_rate(gpu_type)

    # Sort providers cheapest first, filter out unavailable
    available = [r for r in provider_rows if r.get("availability") != "unavailable"]
    available.sort(key=lambda r: r.get("price_per_hour", 9999))

    providers = [
        ProviderRate(
            provider=r.get("provider", ""),
            region=r.get("region", ""),
            price_per_hour=round(float(r.get("price_per_hour", 0)), 4),
            vaultlayer_rate=round(float(r.get("price_per_hour", 0)) * (1 + tier_markup), 4),
            availability=r.get("availability", "unknown"),
            is_spot=bool(r.get("is_spot", False)),
        )
        for r in available
    ]

    best_raw = providers[0].price_per_hour if providers else 0.0
    best_vl = providers[0].vaultlayer_rate if providers else 0.0
    discount_pct = round((1 - best_vl / aws_od) * 100, 1) if aws_od > 0 and best_vl > 0 else 0.0

    if tier_num == 3:
        note = "Tier 3 rate applies when job migrates across nodes. Migration itself is $0.00."
    elif tier_num == 2:
        note = "Includes multi-cloud procurement, capacity reservation, and automatic failover."
    else:
        note = "Includes environment replication, checkpoint wiring, and automatic failover."

    return GPUPriceResponse(
        gpu_type=gpu_type,
        compute_tier=tier_num,
        compute_tier_label=tier_label,
        tier_markup_pct=int(tier_markup * 100),
        best_provider_rate=best_raw,
        best_vaultlayer_rate=best_vl,
        aws_od_rate=aws_od,
        discount_vs_aws_pct=discount_pct,
        providers=providers,
        cache_age_seconds=cache_age,
        note=note,
    )


def _canonical_gpu_key(gpu_type: str) -> str:
    """Normalize a user/API GPU token to the provider-pricing key.

    Pricing rows use short keys such as H100, A100_40, A10G, and GH200,
    while older API docs and some clients pass GPUType enum values such as
    H100_80GB_SXM or A100_40GB. This helper is the contract boundary for
    pricing endpoints: accept either, but query rows by the pricing key.
    """
    from shared.data_loader import resolve_gpu_enum, resolve_gpu_key
    from shared.models import GPUType

    try:
        resolve_gpu_enum(gpu_type, strict=True)
    except ValueError:
        valid = sorted({g.value for g in GPUType})
        raise HTTPException(
            status_code=400,
            detail=f"Unknown gpu_type '{gpu_type}'. Valid values: {valid}",
        )
    return resolve_gpu_key(gpu_type)


def _row_gpu_key(row: dict) -> str:
    from shared.data_loader import resolve_gpu_key

    raw = row.get("gpu") or row.get("gpu_type") or ""
    return resolve_gpu_key(str(raw))


def _static_price_rows() -> list[dict]:
    from shared.data_loader import get_provider_prices

    rows: list[dict] = []
    for provider, gpu_map in get_provider_prices().items():
        if provider.startswith("_") or not isinstance(gpu_map, dict):
            continue
        if "Reserved" in provider or "On-Demand" in provider:
            continue
        for gpu_key, price in gpu_map.items():
            if price is None:
                continue
            rows.append({
                "gpu": gpu_key,
                "provider": provider,
                "price_per_hour": price,
                "availability": "available",
                "region": "",
                "is_spot": False,
            })
    return rows


# ── Routes ────────────────────────────────────────────────────────────────────

@router.get("/gpu", response_model=AllGPUPricesResponse)
async def list_gpu_prices(
    available_only: bool = Query(True, description="Exclude GPUs with no available providers"),
):
    """
    Return live VaultLayer rates for all GPU types, with AWS OD anchoring.

    Prices are updated every 60s by PricingAgent. If the cache is empty
    (PricingAgent not running), falls back to static reference rates.
    """
    from shared.compute_tiers import AWS_OD_RATES

    prices, cache_age = await _get_cached_prices()

    # Group rows by canonical pricing key. Redis rows may use either the short
    # provider-pricing key or a GPUType enum value; the public list should not
    # leak that inconsistency to the CLI.
    by_gpu: dict[str, list[dict]] = {}
    for row in prices:
        gpu = row.get("gpu") or row.get("gpu_type") or ""
        if gpu:
            by_gpu.setdefault(_row_gpu_key(row), []).append(row)

    # If Redis is empty, fall back to static prices from vaultlayer_data.json
    if not by_gpu:
        for row in _static_price_rows():
            by_gpu.setdefault(_row_gpu_key(row), []).append(row)

    results = []
    for gpu_type, rows in sorted(by_gpu.items()):
        resp = _build_gpu_response(gpu_type, rows, cache_age)
        if available_only and not resp.providers:
            continue
        results.append(resp)

    return AllGPUPricesResponse(
        gpus=results,
        cache_age_seconds=cache_age,
        total_providers_polled=len({r.get("provider") for r in prices}),
    )


@router.get("/gpu/{gpu_type}", response_model=GPUPriceResponse)
async def get_gpu_price(gpu_type: str):
    """
    Return the live VaultLayer rate for a single GPU type.

    Used by the job submission UI to show the comparison banner:
      💡 VaultLayer: $1.25/hr (Tier 2 — Scarcity Hunt, +30%)
      🏢 AWS On-Demand: $4.10/hr   →   You save 69.5%

    gpu_type may be either a pricing key (H100, A100_40, GH200) or a
    GPUType enum value / alias (H100_80GB_SXM, A100_40GB, a10g).
    """
    gpu_key = _canonical_gpu_key(gpu_type)

    prices, cache_age = await _get_cached_prices()
    if not prices:
        prices = _static_price_rows()

    # Filter to rows matching this GPU
    rows = [
        r for r in prices
        if _row_gpu_key(r) == gpu_key
    ]

    return _build_gpu_response(gpu_key, rows, cache_age)


@router.get("/compare", response_model=dict)
async def compare_gpu_prices(
    gpu_type: str = Query(..., description="GPUType value e.g. H100_80GB_SXM"),
    hours: float = Query(1.0, description="Estimated training hours"),
):
    """
    Return a job-cost comparison for a given GPU type and duration.
    Used for the pre-submission cost estimator modal.

    Example response for H100_80GB_SXM, 5 hours:
      {
        "gpu_type": "H100_80GB_SXM",
        "hours": 5,
        "vaultlayer_estimate_usd": 16.25,
        "aws_od_estimate_usd": 61.45,
        "you_save_usd": 45.20,
        "you_save_pct": 73.6,
        "tier": 2,
        "tier_label": "Scarcity Hunt",
        "markup_pct": 30
      }
    """
    gpu_resp = await get_gpu_price(gpu_type)

    vl_total = round(gpu_resp.best_vaultlayer_rate * hours, 4)
    aws_total = round(gpu_resp.aws_od_rate * hours, 4)
    save_usd = round(max(0.0, aws_total - vl_total), 4)
    save_pct = round(save_usd / aws_total * 100, 1) if aws_total > 0 else 0.0

    return {
        "gpu_type":               gpu_type,
        "hours":                  hours,
        "best_provider":          gpu_resp.providers[0].provider if gpu_resp.providers else "unavailable",
        "provider_raw_rate":      gpu_resp.best_provider_rate,
        "vaultlayer_rate":        gpu_resp.best_vaultlayer_rate,
        "vaultlayer_estimate_usd": vl_total,
        "aws_od_rate":            gpu_resp.aws_od_rate,
        "aws_od_estimate_usd":    aws_total,
        "you_save_usd":           save_usd,
        "you_save_pct":           save_pct,
        "tier":                   gpu_resp.compute_tier,
        "tier_label":             gpu_resp.compute_tier_label,
        "markup_pct":             gpu_resp.tier_markup_pct,
        "note":                   gpu_resp.note,
        # UI display strings
        "display": {
            "vaultlayer": f"${gpu_resp.best_vaultlayer_rate:.2f}/hr "
                          f"(Tier {gpu_resp.compute_tier} — {gpu_resp.compute_tier_label}, "
                          f"+{gpu_resp.tier_markup_pct}%)",
            "aws_od":     f"${gpu_resp.aws_od_rate:.2f}/hr",
            "savings":    f"Save {save_pct}% vs AWS On-Demand",
        },
    }


# ── GPU Availability + Fallback Offer ────────────────────────────────────────

from shared.gpu_sizing import GPU_FALLBACK_CHAIN as _FALLBACK_CHAIN


@router.get("/gpu/{gpu_type}/availability")
async def check_gpu_availability(gpu_type: str):
    """
    Check if a GPU is available right now and return options if not.

    Two options when the target GPU is unavailable:
      1. Start immediately on the best available fallback GPU, then hot-swap
         when the target becomes available (Zero-Downtime Hop, Tier 3 billing).
      2. Wait in queue — job stays pending until target GPU appears.

    The UI uses this to show the pre-flight modal:
      "H100 is currently unavailable. We can start you on an A100 immediately
       ($1.50/hr) and hot-swap you to the H100 ($3.00/hr) the moment it's free.
       Migration is free. You pay each GPU's rate for the time you use it."

    Returns:
      available: true  → GPU is available, show normal rate + start button
      available: false → show fallback offer + wait option
    """
    from shared.compute_tiers import get_job_tier, get_aws_od_rate

    gpu_key = _canonical_gpu_key(gpu_type)

    prices, cache_age = await _get_cached_prices()
    if not prices:
        prices = _static_price_rows()

    # Find providers offering the target GPU
    target_rows = [
        r for r in prices
        if _row_gpu_key(r) == gpu_key
        and r.get("availability") not in ("unavailable", "low")
    ]
    target_rows.sort(key=lambda r: r.get("price_per_hour", 9999))

    target_tier, target_markup, target_label = get_job_tier([gpu_key], leg_count=1)
    target_aws_od = get_aws_od_rate(gpu_key)

    if target_rows:
        # Target GPU is available — normal flow
        best = target_rows[0]
        raw_rate = float(best.get("price_per_hour", 0))
        vl_rate = round(raw_rate * (1 + target_markup), 4)
        return {
            "gpu_type":     gpu_key,
            "available":    True,
            "provider":     best.get("provider"),
            "region":       best.get("region", ""),
            "provider_rate_per_hr":    raw_rate,
            "vaultlayer_rate_per_hr":  vl_rate,
            "aws_od_rate_per_hr":      target_aws_od,
            "tier":         target_tier,
            "tier_label":   target_label,
            "markup_pct":   int(target_markup * 100),
            "fallback_offer": None,
            "wait_option":  None,
            "cache_age_seconds": cache_age,
        }

    # Target GPU is unavailable — find the best fallback
    fallback_chain = _FALLBACK_CHAIN.get(gpu_key, [])
    fallback_offer = None
    for fb_gpu in fallback_chain:
        fb_rows = [
            r for r in prices
            if _row_gpu_key(r) == fb_gpu
            and r.get("availability") not in ("unavailable",)
        ]
        if fb_rows:
            fb_rows.sort(key=lambda r: r.get("price_per_hour", 9999))
            best_fb = fb_rows[0]
            fb_raw = float(best_fb.get("price_per_hour", 0))
            # Fallback leg: Tier 3 markup (hot-swap job) regardless of GPU type
            fb_vl = round(fb_raw * (1 + 0.40), 4)
            target_vl = round(
                min((float(r.get("price_per_hour", 0)) for r in target_rows), default=0) * (1 + 0.40),
                4
            ) if target_rows else None
            fallback_offer = {
                "gpu_type":              fb_gpu,
                "provider":              best_fb.get("provider"),
                "region":                best_fb.get("region", ""),
                "provider_rate_per_hr":  fb_raw,
                "vaultlayer_rate_per_hr": fb_vl,
                "aws_od_rate_per_hr":    get_aws_od_rate(fb_gpu),
                "billing_note": (
                    f"You pay ${fb_vl:.2f}/hr on the {fb_gpu} while waiting. "
                    f"When {gpu_key} becomes available, we hot-swap you automatically "
                    f"and billing switches to the {gpu_key} rate. "
                    f"Migration itself is $0.00."
                ),
                # Pre-built modal strings for the UI
                "modal": {
                    "headline": f"{gpu_key} is currently unavailable",
                    "body": (
                        f"We'll start you on a {fb_gpu} immediately at "
                        f"${fb_vl:.2f}/hr and hot-swap you to the {gpu_key} "
                        f"the moment it becomes available. "
                        f"No progress lost. Migration is free."
                    ),
                    "billing_table": [
                        {
                            "phase":   f"{fb_gpu} (Fallback)",
                            "rate":    f"${fb_vl:.2f}/hr",
                            "note":    "Billed until hot-swap completes",
                        },
                        {
                            "phase":   f"{gpu_key} (Target)",
                            "rate":    f"~${round(target_aws_od * 0.35, 2):.2f}/hr (live rate at swap time)",
                            "note":    "Billed from the moment of hot-swap",
                        },
                        {
                            "phase":   "Migration Event",
                            "rate":    "$0.00",
                            "note":    "Included in Tier 3 orchestration premium",
                        },
                    ],
                    "cta_start_fallback": f"Start on {fb_gpu} now, auto-upgrade to {gpu_key}",
                    "cta_wait":           f"Wait for {gpu_key} (job stays queued)",
                },
            }
            break

    return {
        "gpu_type":       gpu_key,
        "available":      False,
        "provider":       None,
        "provider_rate_per_hr":   None,
        "vaultlayer_rate_per_hr": None,
        "aws_od_rate_per_hr":     target_aws_od,
        "tier":           3,   # always Tier 3 (Zero-Downtime Hop) when a hop is needed
        "tier_label":     "Zero-Downtime Hop",
        "markup_pct":     40,
        "fallback_offer": fallback_offer,
        "wait_option": {
            "description":   f"Keep job queued. Start automatically when {gpu_key} is available.",
            "check_interval": "60s",
            "note":          "PricingAgent polls all providers every 60s and triggers the job the moment capacity opens.",
        },
        "cache_age_seconds": cache_age,
    }


# ── GPU Hop Consent ───────────────────────────────────────────────────────────

class HopConsentRequest(BaseModel):
    fallback_gpu: str       # GPU being started on now (e.g. A100_40GB)
    target_gpu: str         # GPU to hot-swap to when available (e.g. H100_80GB_SXM)
    consented: bool         # must be True — the UI sends this after user clicks accept


@jobs_router.post("/{job_id}/hop-consent")
async def record_hop_consent(
    job_id: str,
    body: HopConsentRequest,
    user: dict = Depends(require_auth),
):
    """
    Record that the user accepted the GPU hot-swap dynamic billing terms.

    Called by the UI after the user clicks "Start on {fallback_gpu},
    auto-upgrade to {target_gpu}" in the pre-flight modal.

    Sets jobs.gpu_hop_consented = true, target_gpu, fallback_gpu.
    PricingAgent polls for rows where gpu_hop_consented = true and
    gpu_hop_completed = false to know which jobs need the upgrade trigger.

    Requires a valid VaultLayer token (Authorization: Bearer <token>).
    """
    from shared.models import GPUType

    if not body.consented:
        raise HTTPException(status_code=400, detail="consented must be true")

    valid = {g.value for g in GPUType}
    for field, val in [("fallback_gpu", body.fallback_gpu), ("target_gpu", body.target_gpu)]:
        if val not in valid:
            raise HTTPException(status_code=400, detail=f"Unknown {field}: '{val}'")

    try:
        from api.db import get_db, _db_call
        db = get_db()
        _db_call(
            lambda: db.table("jobs").update({
                "target_gpu":           body.target_gpu,
                "fallback_gpu":         body.fallback_gpu,
                "gpu_hop_consented":    True,
                "gpu_hop_consented_at": datetime.now(timezone.utc).isoformat(),
            }).eq("job_id", job_id).eq("user_id", user["user_id"]).execute(),
            label="hop_consent:update",
        )
    except Exception as e:
        logger.warning(f"[hop-consent] DB update failed for job {job_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to record consent")

    logger.info(
        f"[hop-consent] job={job_id} user={user['user_id']} "
        f"fallback={body.fallback_gpu} target={body.target_gpu}"
    )
    return {
        "job_id":       job_id,
        "fallback_gpu": body.fallback_gpu,
        "target_gpu":   body.target_gpu,
        "consented":    True,
        "message": (
            f"Consent recorded. Job will start on {body.fallback_gpu} and "
            f"automatically upgrade to {body.target_gpu} when available. "
            f"Migration is free. Billing switches to the {body.target_gpu} "
            f"rate at the moment of hot-swap."
        ),
    }


class HopCancelRequest(BaseModel):
    reason: str = "user_requested"


@jobs_router.post("/{job_id}/gpu-hop/cancel")
async def cancel_gpu_hop(
    job_id: str,
    body: HopCancelRequest = HopCancelRequest(),
    user: dict = Depends(require_auth),
):
    """
    Cancel a pending GPU hot-swap for a running job.

    The job continues running on its current (fallback) GPU at the current rate.
    PricingAgent will stop polling for the target GPU.
    """
    try:
        from api.db import get_db, _db_call
        db = get_db()

        # Verify the job exists, belongs to user, and has an active hop
        result = _db_call(
            lambda: db.table("jobs")
                .select("job_id, gpu_hop_consented, gpu_hop_completed, gpu_hop_cancelled")
                .eq("job_id", job_id)
                .eq("user_id", user["user_id"])
                .execute(),
            label="hop_cancel:fetch",
        )
        if not result.data:
            raise HTTPException(status_code=404, detail="Job not found")

        job = result.data[0]
        if not job.get("gpu_hop_consented"):
            raise HTTPException(status_code=400, detail="No active GPU hop to cancel")
        if job.get("gpu_hop_completed"):
            raise HTTPException(status_code=400, detail="GPU hop already completed")
        if job.get("gpu_hop_cancelled"):
            raise HTTPException(status_code=400, detail="GPU hop already cancelled")

        _db_call(
            lambda: db.table("jobs").update({
                "gpu_hop_cancelled": True,
                "gpu_hop_cancelled_at": datetime.now(timezone.utc).isoformat(),
                "gpu_hop_cancel_reason": body.reason,
            }).eq("job_id", job_id).execute(),
            label="hop_cancel:update",
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.warning(f"[hop-cancel] DB update failed for job {job_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to cancel GPU hop")

    logger.info(f"[hop-cancel] job={job_id} user={user['user_id']} reason={body.reason}")
    return {
        "job_id": job_id,
        "cancelled": True,
        "reason": body.reason,
        "message": (
            "GPU hot-swap cancelled. Your job will continue running on the "
            "current GPU at the current rate."
        ),
    }
