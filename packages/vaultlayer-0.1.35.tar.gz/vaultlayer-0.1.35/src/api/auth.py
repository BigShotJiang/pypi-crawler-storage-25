"""
Auth middleware and Clerk webhook handler.

Token validation flow:
  CLI sends  →  Authorization: Bearer vl_live_xxx
  API hashes →  SHA-256(token) → lookup in api_tokens table
  Returns    →  user_id, email, credit balance

Clerk webhook flow (user.created):
  Clerk calls  →  POST /api/v1/auth/clerk-webhook
  We create    →  user row + issue 200 immediate credits + generate API token
  Response     →  {token: "vl_live_xxx"} (shown once in dashboard)
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
from typing import Optional

from fastapi import Header, HTTPException, Request, status

from api.db import get_balance, get_db, get_user_by_token
from api.flags import TESTING_MODE, TESTING_USER, TESTING_CREDITS_BALANCE
from api.models import TokenValidateResponse

logger = logging.getLogger(__name__)

CLERK_WEBHOOK_SECRET = os.environ.get("CLERK_WEBHOOK_SECRET", "")



# ── Request-level token auth ──────────────────────────────────────────────────

async def require_auth(authorization: str = Header(...)) -> dict:
    """
    FastAPI dependency. Validates VAULTLAYER_TOKEN from Authorization header.
    Returns user row dict on success. Raises 401 on failure.

    Usage:
        @router.get("/credits")
        async def get_credits(user: dict = Depends(require_auth)):
            ...
    """
    # ── Testing mode: bypass all auth, return mock user ──────────────────────
    if TESTING_MODE:
        logger.debug("[auth] TESTING_MODE: skipping token validation")
        return TESTING_USER

    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="Authorization header must be: Bearer <token>")

    raw_token = authorization.removeprefix("Bearer ").strip()
    if not raw_token.startswith(("vl_live_", "vl_test_")):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="Invalid token format")

    try:
        user = await get_user_by_token(raw_token)
    except Exception as e:
        logger.error(f"[auth] Supabase lookup failed: {e}")
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                            detail="Auth service temporarily unavailable")
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="Token not found or revoked")

    return user


# ── Internal admin gate ───────────────────────────────────────────────────────
#
# Operator-only endpoints (instance cleanup, pod termination, worker
# diagnostics, test-email, provider-status) are gated by an internal token
# that is NEVER vended through any public API. Set VL_INTERNAL_ADMIN_TOKEN
# in Railway env vars; operators include `X-Internal-Admin-Token: <value>`
# on every admin call. If the env var is unset, every admin endpoint
# returns 503 — fail-closed by default. The proper long-term fix is to
# bind these routes to Railway's internal network or behind Cloudflare
# service auth (see CLAUDE.md security guardrails); this token gate is
# the code-only minimum to stop authenticated users from invoking them.
#
# The token is re-read from os.environ on every request, not cached at
# module-import time — operators rotating the token via Railway env
# change expect the new value to take effect immediately. (Railway
# restarts the worker on every env change today, so caching worked in
# practice; but relying on that was fragile. Tests patch the module
# attribute for override.)

INTERNAL_ADMIN_TOKEN_ENV_VAR = "VL_INTERNAL_ADMIN_TOKEN"

# Backwards-compat shim: some tests monkeypatch this module attribute to
# override the token. We check it first and fall back to the env var.
INTERNAL_ADMIN_TOKEN = os.environ.get(INTERNAL_ADMIN_TOKEN_ENV_VAR, "")


def _current_internal_admin_token() -> str:
    """Return the current internal admin token, reading env fresh each call."""
    # Honour a module-level override (tests use monkeypatch.setattr for this).
    if INTERNAL_ADMIN_TOKEN:
        return INTERNAL_ADMIN_TOKEN
    return os.environ.get(INTERNAL_ADMIN_TOKEN_ENV_VAR, "")


async def require_internal_admin(
    x_internal_admin_token: Optional[str] = Header(default=None, alias="X-Internal-Admin-Token"),
) -> None:
    """FastAPI dependency. Reject unless X-Internal-Admin-Token matches the
    server's VL_INTERNAL_ADMIN_TOKEN env var. If the env var is unset, the
    endpoint returns 503 — admin operations are disabled by default."""
    if TESTING_MODE:
        return
    token = _current_internal_admin_token()
    if not token:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Admin endpoints disabled. Operator must set VL_INTERNAL_ADMIN_TOKEN.",
        )
    if not x_internal_admin_token or not hmac.compare_digest(
        x_internal_admin_token, token
    ):
        # 404 (not 401/403) so this endpoint is invisible to attackers
        # without the token — they can't tell the difference between
        # "endpoint doesn't exist" and "you're not authorised".
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Not Found")


# ── Job ownership check ──────────────────────────────────────────────────────


def require_job_ownership(
    job_id: str,
    user: dict,
    _active_jobs: dict,
    *,
    allow_db_fallback: bool = False,
) -> dict:
    """Look up a job and verify the caller owns it.

    Primary lookup: in-memory _active_jobs (fast, always preferred for live jobs).
    Optional fallback: job_runs DB table for read-only callers that need to
    survive deploys or polling before _active_jobs is fully recovered (#127).

    Raises 404 (not 403) when the caller does not own the job — matching the
    "looks identical to a missing job" pattern that prevents enumeration of
    other users' job IDs. Returns the job dict on success.
    """
    job = _active_jobs.get(job_id)
    if not job:
        if not allow_db_fallback:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")

        # DB fallback: the job may be completed or the worker may have just
        # restarted and _active_jobs is not yet fully populated. Keep this
        # opt-in so mutation endpoints do not operate on reconstructed rows
        # that are not backed by live in-memory state.
        try:
            db = get_db()
            select_cols = (
                "job_id, account_id, status, provider, gpu_type, "
                "rate_per_hr, instance_id, created_at, provisioned_at, "
                "completed_at, failed_at, failure_reason, metadata, queue_state"
            )
            try:
                row = db.table("job_runs").select(select_cols).eq(
                    "job_id", job_id
                ).order("created_at", desc=True).limit(1).execute()
            except Exception as _select_err:
                if "queue_state" not in str(_select_err):
                    raise
                legacy_cols = select_cols.replace(", queue_state", "")
                row = db.table("job_runs").select(legacy_cols).eq(
                    "job_id", job_id
                ).order("created_at", desc=True).limit(1).execute()
            db_row = (row.data or [None])[0]
        except Exception as _db_err:
            logger.warning("[auth] DB fallback for job=%s failed: %s", job_id, _db_err)
            db_row = None

        if not db_row:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")

        if db_row.get("account_id") != user.get("user_id"):
            logger.warning(
                "[auth] Cross-tenant job access blocked (DB): user=%s tried to access job=%s owned by user=%s",
                user.get("user_id"), job_id, db_row.get("account_id"),
            )
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")

        # Reconstruct a minimal job dict compatible with status callers.
        _qs = db_row.get("queue_state") or {}
        _metadata = db_row.get("metadata") or {}
        job = {
            "job_id": job_id,
            "user_id": db_row.get("account_id", ""),
            "status": db_row.get("status", "unknown"),
            "provider": db_row.get("provider"),
            "gpu_type": db_row.get("gpu_type", ""),
            "actual_gpu_type": db_row.get("gpu_type", ""),
            "price_per_hr": db_row.get("rate_per_hr"),
            "instance_id": db_row.get("instance_id"),
            "error": db_row.get("failure_reason"),
            "completed_at": None,
            "duration": None,
            "log_line_count": 0,
            "checkpoint_step": None,
            "script_b64":  _qs.get("script_b64", ""),
            "script_name": _qs.get("script_name", ""),
            "script_args": _qs.get("script_args", ""),
            "environment": _qs.get("environment") or {},
            "docker_image": _qs.get("docker_image") or _metadata.get("docker_image", ""),
            "failover": bool(_qs.get("failover", True)),
            "_db_only": True,  # signal to callers that this job is not live
        }
        return job

    if job.get("user_id") != user.get("user_id"):
        # Same status code + message as the missing-job path so an attacker
        # cannot distinguish "not yours" from "doesn't exist".
        logger.warning(
            "[auth] Cross-tenant job access blocked: user=%s tried to access job=%s owned by user=%s",
            user.get("user_id"), job_id, job.get("user_id"),
        )
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")
    return job


async def validate_token(raw_token: str) -> TokenValidateResponse:
    """Standalone token check — used by CLI at `vaultlayer init` time."""
    # ── Testing mode: any token is valid ─────────────────────────────────────
    if TESTING_MODE:
        logger.debug("[auth] TESTING_MODE: validate_token returning mock user")
        return TokenValidateResponse(
            valid=True,
            user_id=TESTING_USER["user_id"],
            email=TESTING_USER["email"],
            balance_credits=TESTING_CREDITS_BALANCE,
        )

    if not raw_token.startswith(("vl_live_", "vl_test_")):
        return TokenValidateResponse(valid=False, message="Invalid token format")

    try:
        user = await get_user_by_token(raw_token)
    except Exception as e:
        logger.error(f"[auth] validate_token Supabase error: {e}")
        return TokenValidateResponse(valid=False, message="Auth service temporarily unavailable")

    if not user:
        return TokenValidateResponse(valid=False, message="Token not found or revoked")

    try:
        import asyncio
        bal = await asyncio.get_event_loop().run_in_executor(
            None, get_balance, user["user_id"]
        )
        balance_credits = bal["available_credits"]
    except Exception:
        balance_credits = 0

    return TokenValidateResponse(
        valid=True,
        user_id=user["user_id"],
        email=user["email"],
        balance_credits=balance_credits,
    )


# ── Clerk webhook verification ────────────────────────────────────────────────

# Svix recommends rejecting webhooks older than 5 minutes to bound replay
# windows. https://docs.svix.com/receiving/verifying-payloads/how
CLERK_WEBHOOK_MAX_AGE_SECONDS = 5 * 60

# In-process set of svix_id values we've already processed. This defends
# against replay within a single worker instance. For cross-worker
# protection, a DB-backed UNIQUE index on webhook_events(svix_id) is the
# durable solution; that's tracked separately. The set is bounded so
# memory doesn't grow unbounded — old entries age out once it exceeds
# _CLERK_SEEN_MAX.
_CLERK_SEEN_MAX = 10_000
_clerk_seen_ids: set[str] = set()
_clerk_seen_order: list[str] = []


def _record_clerk_id(svix_id: str) -> bool:
    """Return True if this svix_id is new (record it); False if it's a replay."""
    if not svix_id:
        return True  # signature path will reject this; let it through
    if svix_id in _clerk_seen_ids:
        return False
    _clerk_seen_ids.add(svix_id)
    _clerk_seen_order.append(svix_id)
    # Bound memory
    while len(_clerk_seen_order) > _CLERK_SEEN_MAX:
        old = _clerk_seen_order.pop(0)
        _clerk_seen_ids.discard(old)
    return True


def _verify_clerk_signature(payload_bytes: bytes, svix_id: str,
                              svix_timestamp: str, svix_signature: str) -> bool:
    """
    Verify Clerk webhook signature using Svix signing scheme.
    https://docs.svix.com/receiving/verifying-payloads/how
    """
    if not CLERK_WEBHOOK_SECRET:
        logger.error("CLERK_WEBHOOK_SECRET not configured — rejecting webhook (fail-closed)")
        return False

    signed_content = f"{svix_id}.{svix_timestamp}.{payload_bytes.decode()}".encode()
    secret_bytes = CLERK_WEBHOOK_SECRET.encode()
    expected = hmac.new(secret_bytes, signed_content, hashlib.sha256).digest()

    # svix_signature may be "v1,<base64>" — strip prefix
    import base64
    for sig_part in svix_signature.split(" "):
        if "," in sig_part:
            _, b64 = sig_part.split(",", 1)
        else:
            b64 = sig_part
        try:
            actual = base64.b64decode(b64)
            if hmac.compare_digest(expected, actual):
                return True
        except Exception:
            continue
    return False


async def parse_clerk_webhook(request: Request) -> Optional[dict]:
    """
    Parse and verify an incoming Clerk webhook. Returns event dict or None.
    Raises 400 on bad signature, stale timestamp, or replay.

    Layered defence:
      1. HMAC-SHA256 signature over svix_id.svix_timestamp.payload.
      2. Timestamp freshness: reject if svix_timestamp is more than
         CLERK_WEBHOOK_MAX_AGE_SECONDS (5 min) old. Previously the
         timestamp was included in the signed content but never checked
         absolutely — a stolen webhook was replayable days or weeks
         later and still passed signature verification.
      3. Idempotency: in-process set of seen svix_id values blocks
         replays of the same event within a worker. For cross-worker
         durability, callers should additionally enforce a UNIQUE
         constraint on (user_id) or a dedicated webhook_events table.
    """
    body = await request.body()
    svix_id        = request.headers.get("svix-id", "")
    svix_timestamp = request.headers.get("svix-timestamp", "")
    svix_signature = request.headers.get("svix-signature", "")

    if not _verify_clerk_signature(body, svix_id, svix_timestamp, svix_signature):
        raise HTTPException(status_code=400, detail="Invalid webhook signature")

    # Timestamp freshness — svix_timestamp is a Unix epoch in seconds.
    import time as _time
    try:
        ts = int(svix_timestamp)
    except (TypeError, ValueError):
        raise HTTPException(status_code=400, detail="Invalid svix-timestamp header")
    age = abs(_time.time() - ts)
    if age > CLERK_WEBHOOK_MAX_AGE_SECONDS:
        logger.warning(
            "[clerk] Rejecting stale webhook: age=%.1fs > %ds (svix_id=%s)",
            age, CLERK_WEBHOOK_MAX_AGE_SECONDS, svix_id,
        )
        raise HTTPException(status_code=400, detail="Webhook timestamp is too old")

    # Idempotency — svix_id uniquely identifies a single event delivery.
    if not _record_clerk_id(svix_id):
        logger.info("[clerk] Replay suppressed for svix_id=%s", svix_id)
        # 200 (not 400) — the sender gets "already processed" confirmation
        # and won't keep retrying. Return an empty event so the caller's
        # None-check early-outs without performing user.created work.
        return None

    return json.loads(body)
